# Lokad.Lython 0.11.0

Updated2026-11-06. Git-ignored; never force-add. Publication/tagging postponed.
Objective: coherent simplification and substantial complete-script performance.
Another isolated experiment, allocation reduction or local deletion does not
complete that objective. Current performance/qualification evidence is separate.

## Actual delivery state

- Last fully qualified runtime **9a152ee0** (R13 B). Terminal CI **42228235593**
  is GREEN/all eight major Windows/Ubuntu, .NET11/.NET10, package and original
  Stress gates. Cached in benchmarks/results/2026-11-06-deferred-contexts/.
  Never query that terminal run again; earlier terminal receipts remain cached.
- **abe0defb** updates the representative CPython guide. Its installed Release
  package consumers pass on actual.NET11RC3 and.NET10.0.8; core dependencies
  empty, optional adapter nonpackable. Outputs only in artifacts/nuget/. No publish.
- Current runtime **66ae029d** (R13 C) removes duplicate scope transport from
  publication. Both-target build0warnings; focused526internal/1,508public per
  actual runtime and B348 whole-script checks pass. Full B qualification does
  not qualify C. Batch C platform/stress/installed consumers with the next
  meaningful runtime delivery, rather than repeating unchanged full checks.
- R14 dictionary context is committed/pushed **62141d4d**: both-target build has
  zero warnings/errors; focused365internal/1,281public per actual runtime pass.
  B350's five complete-script jobs finished140.32s with all gates. Full local
  .NET11 suites pass4,260internal/16,187public. C+R14 delivery CI **42243450458**
  is running (Windows/Ubuntu, both runtimes, original Stress, installed packages).
  Local installed-package consumers pass on actual.NET11RC3/.NET10.0.8, core
  dependencies empty, adapter nonpackable. Artifacts only in artifacts/nuget/;
  package repository revision62141d4d. Do not duplicate full checks.
- B346–B350 collections are terminal, archived and verified; all workers joined
  and fixtures removed. Never query their terminal services again. Programs and
  storage outlive actual users. Source snapshots were not timestamp-restored.

Evidence/history: benchmarks/EXPERIMENTS.md and benchmarks/results/. Earlier plans
and source-gate notes are retained in .git/agent-notes/review-20261031/.
docs/ remains concise/current implementation, not experimental narrative.

## Completed work to preserve

| Milestones | Delivered implementation / evidence |
| --- | --- |
| Compiler facts, direct UTF8, native helper returns | Shared compiler/class-cell correction retained. Native returns allocation−19.92%/−19.31%, elapsed diagnostic; formatting allocation−8.67%, controlledB102 elapsed/CPU−5–8%, original adverse15.125ms unexplained. Historical qualified source pairs, not current-head allocation claims. |
| K01, F02–F05 | One dict/set entry authority; weak/scalar/reclamation machinery gone. One invocation/lexical context, final argument/local storage, shared scope facts, lazy namespaces, receiver/function in operands. No restored copy/arena layers. |
| Q01, R02/R04 | One contextual key preparation, active structural cycle path and final tuple backing. Their affected-workload gains do not compound into a broad CPU claim. |
| R03/R05, Q02, R07 | Shared whitespace/ASCII processing, actual builtin class semantics, async hash/native reads and one native-key proof. Async text debt remains source-scoped. |
| R06/R09/R10 | Shared class extraction, constructor sequence and existing frame runner; Python correctness/retained packets preserved. Original adverse class/source pairs and accepted debt retained. No constructor speedup claim. |
| R12, R13 A/B | Current allocation origins selected context work, not universal value rewriting. Executable frame base/constructors/hidden dispatch removed; one inline work state. B defers eligible helper contexts through the actual instruction switch and adopts existing IP/locals/storage. Native writes promote before growth/admission; one publication helper. No second interpreter/owner/pool. Fully qualified9a152ee0. |
| R13 C | Owned operand services replace the duplicate defining-scope publication argument. NoInlining/liveness, current lexical stores, first refusal and disposal order preserved. Keep the simpler transport; broad performance objective remains open. Focused/measurement qualified66ae029d. |
| R14 (delivery pending) | Explicit dictionary context removes native ambient installation/rediscovery; general assignment reuses existing funded no-growth writes. Structural/protocol keys own provenance at the query boundary. Outer provenance restores after cancellation; no new owner/table/policy. |

## Measurement state and explicit debt

Primary guide docs/BENCHMARKS.md measures **9a152ee0/B347**, frozen core1daf56c3
whose normalized production sources match the commit. Fresh Lython/CPython:
CSV1.37–1.38x, text1.88–1.94x, JSON1.20–1.24x, report1.46–1.51x. Compile, warm
and fresh are separate. Mediated RAM I/O, complete validation and prior-result
cleanup included; fresh adds compile/disposal. Startup/staging/reset/transport/
final teardown excluded. CPython imports persist, Lython imports are isolated.
Actual suspended-I/O latency, RSS and embedding latency remain unmeasured.

- **B346** original prototype:12jobs/228.43s, modest CSV gains, adverse text/JSON/
  report, conflicting CPU and18% identical compiler-control divergence. Original
  Slice failure (4,259internal pass;16,185public pass/one fail) and correction
  retained. Source/measurement refinement was justified; uncertainty was not
  treated as a failed design. Final Slice/shared-write/class-cell controls pass.
- **B347** corrected B:12jobs/328.10s, five-second warmup. CSV warm elapsed
  −5.85/−6.24%, fresh−5.53/−5.83% versus88; warm CSV CPU flat. Warm text
  +3.40/+6.45%, JSON mixed/adverse, report variable; identical roles still vary
  2–4% on several jobs. Retain architecture with explicit debt, not broad CPU gain.
- **B348** C:5jobs/139.83s versus9a. CSV effectively flat; text−1.93/−3.64%,
  JSON−1.14/−2.23%, report+2.63/+0.67% with1.91% identical-role split. Retain the
  deletion; uncertainty/report debt and the larger objective remain. Do not
  compound these source pairs or claim a measured allocation reduction.
- **B349** source gate: current text/CSV captures414/419 guest samples. Namespace
  mirroring is not dominant; preserve its annotation/lambda correctness. Actual
  native-query TLS callers selected R14; not all TLS/locks belong to accounting.
- **B350** R14: CSV warm+1.52/−1.81%, fresh−6.51/−7.46%; text−5.20/−7.80%,
  JSON−4.57/−5.79%, report−7.92/−1.54% with6.92% identical-role divergence.
  CPU ticks mixed/coarse. Retain simpler routing, no broad CPU/allocation claim.
  Brief service-status SSH observation retained; no adverse data excluded.
  Evidence: benchmarks/results/2026-11-06-dictionary-context/.

## Delivery boundary: R13 C + R14 dictionary context

B349 completed the bounded current-source gate: two approximately two-second
CPU captures, text/helpers896 and CSV/functions480, runtime66ae029d/frozen977da8d6.
Raw traces, own-process maps/listings and terminal receipt are verified locally;
all goldens, quietness, funding, worker joins and fixture cleanup passed.
These instrumented captures attribute cost; they do not measure an improvement.
Namespace mirroring is not a dominant sampled phase: defer that hypothesis and
preserve the annotation/lambda lifetime correction. CSV has30 leaf TLS samples
among419, including native dictionary/subscript work; text has6 among414.

Selected hypothesis: explicit dictionary reads and already-funded string-key
writes can own contextual provenance once, removing ambient installation and
rediscovery from native operations. Affected scripts: CSV aggregation and text
word counts. Remove caller PushAmbient/implicit lookup in these paths; keep the
existing table, key proof, protocol algorithms and general mutation route. This
does not justify universal value/frame changes or removing cancellation checks.

Acceptance: preserve hash/equality callback order and reentry, error spans and
cancelable missing-key rendering, async protocol I/O, first refusal, retained
aliases, iteration versions, cycles and cleanup. Use focused Release regressions
on both runtimes, then one short CSV warm/fresh plus text/JSON/report warm source
pair versus66 with unchanged controls. Decide explicitly on any regression debt.
Batch C+retainedR14 full platform/stress/package checks at that delivery boundary.

## R15 construction source gate: completed, proposed duplicate removals deferred

Use B349's actual parser/split/storage callers to select one coherent reduction
in full CSV/text/JSON processing. Source acceptance precedes a prototype: identify
which copies, descriptors or per-result admission calls disappear, the lifetime
that funds replacement/escaped results, and the old path to delete. Existing bulk
CSV construction and fused lower/upper+split already exist; do not repackage them.
Typical text fixture lines contain only three words, so removing dynamic split
range spill alone cannot explain its gap. Inspect file-line/result construction
and parser input/output transport together before choosing; do not presume every
lock is removable accounting overhead or add speculative memory infrastructure.
CSV already reads native lines into the parser's admitted input buffer and decodes
in place behind the consumed prefix; there is no separate native line copy to
remove. Text's output reservation already covers all split fragments/list together.
Do not reopen these completed source paths under new names.
The current gate therefore does not select another CSV input-copy or split-spill
prototype. Text-line batching would require additional prepaid-output lifetime
state; sampled locks alone do not justify that machinery. Keep the existing
per-result admission and independent strings. This defers these proposals, not
the performance objective; revisit only with a distinct removal/cost argument.

Bound this gate to current source plus preserved captures: no new broad profile
campaign. End with one implementable source contract or explicit deferral in favor
of the next evidenced roadmap item. If selected, preserve Unicode expansion/final
sigma, newline/size/seek semantics, CSV quoted/variable rows, alias lifetimes,
preallocation refusal and real cancellation/cleanup. Focused checks then one short
complete text/CSV pair with unchanged JSON/report controls; retain original adverse
conditions and decide remaining debt. No fixed percentage veto or automatic
promotion. Full refresh/qualification only after a meaningful retained redesign.

## Next: R16 coherent exact-integer production and transport design

Gate outcome: defer a new scalar object/representation for now. The finite source
contract must preserve canonical guest projection plus original host scalar
round trips, identity, numeric protocol order and all native proofs; a long-only
path would introduce new cliffs. Current distributed cost samples do not justify
that extra subsystem. This is a sourced deferral, not a permanent rejection.

## Active: R17 explicit text-operation provenance

Remove PyString's birth-span reference and the unused IPyGovernedValue marker,
which has no production consumers. Use existing explicit/current operation spans;
never overwrite a first structured refusal. Retain owners/capacities/cache rollback
and conservative admission estimates. No new metadata table or shared string
representation. Expected elimination: one reference per text object, historical
origin fallbacks and the dead interface/declarations. Measure actual shell size
and complete-script allocation independently of elapsed/CPU. Focused Unicode,
operation-origin, cancellation/retention/refusal checks both runtimes; one short
whole CSV/text/JSON/report source pair with unchanged controls. Decide remaining
debt before delivery. Private source contract: text-provenance-r17/contract.md.

### R16 retained design criteria (deferred)

Hypothesis: one ordinary machine-integer representation/production convention can
replace repeated boxed BigInteger construction and magnitude-oriented dispatch in
counters, ranges, indexing and aggregation, while preserving arbitrary precision
on overflow. Existing slots remain object references: avoid a universal tagged VM,
identity ledger, pool/arena or new memory policy. Current B349 AddExactIntegers has
13text leaf samples; allocation/barrier costs also exist but are not all integers.
This supports investigation, not a predicted whole-script speedup or dominance.

First bounded source contract: enumerate actual integer producers/consumer proofs
(45 runtime BigInteger type tests at this source), public projection and identity
constraints. Native ingress already accepts all CLR integral types, but executable
and NativeReturn proofs currently privilege BigInteger. A mere new long fast path
would leave inconsistent routing and is not the completion milestone. Decide on
one internal convention that preserves host scalar round trips and canonical guest
projection before writing a prototype. A small internal integer object is a design
candidate, not an approved second permanent numeric subsystem.

If selected, milestone completion includes literals/range/arithmetic/native helpers,
shared exact-integer recognition, overflow/magnitude admission and removal of the
displaced small-BigInteger packaging/type-selection routes. Preserve bool/int
distinctions, alias/is behavior, hash/equality, reflection/protocol order, formatting,
public scalar contracts, refusal/cancellation and actual async suspension. No limb
or unbounded integer work without existing preflights/checks. Check both APIs and
shared ownership, then one bounded complete CSV/text/JSON/report source pair plus
an existing integer-loop control. Separate allocations, CPU and elapsed; retain
all adverse conditions and decide temporary regression debt before delivery.
Gate ends with an implementable single-convention contract or explicit deferral;
do not start a broad representation audit or hide the unresolved performance gap.

## Further redesign choices (evidence required)

| Area | Current facts and bounded acceptance |
| --- | --- |
| Calls/frames | Arguments already bind final locals; ordinary constructors use existing frames. Text/JSON/report helpers already use NativeReturn, so always-promoting helper setup does not explain those controls. Do not add speculative CFG inventories/passes. Preserve dynamic binding, globals/class cells, real suspension and ownership. |
| Operand/scalar values | BigInteger boxes and dispatch exist, but small BigInteger magnitudes are compact. CPU dominance must select a contained removal before a tagged-value commitment. Preserve exact overflow promotion, identity/aliases and public projection. B61 call records and B69 arenas actually measured slower; do not rename/replay them. |
| Record construction | B150 bulk CSV retained (~10% variable width, peak+63,648B); original6–8% misses kept. B01 cached layouts flat/small, shared keys need substantial mutation/iterator machinery. Reopen only for distinct removable work; ordinary/variable CSV, JSON records and unchanged text controls, preserving order/reentry/aliases/overlap. |
| Text | NativeUTF8 JSON/formatting and fused case/whitespace splitting already exist. R12 allocation ticks are approximate triggering-type attribution, not exact/live/CPU fractions. Inspect actual remaining conversions/metadata; do not propose the same fusion again or reintroduce string-window retention debt. Unicode/callback/cancellation/ownership controls required. |
| Frontend/setup | Compiler facts shared/corrected; compilation is smaller than execution here. Assess immutable call layout/signatures separately from mutable defaults/namespaces. Remove actual per-definition rebuilding if selected; preserve annotations, closures, defaults mutation, diagnostics and compile cancellation. No speculative JIT/compiler rewrite. |
| Imports (already delivered) | PrepareImportedModule already compiles executable code (840621405,2026-10-20); both APIs execute it. Shared module dictionaries, code admission, grants, first failures and isolation remain. Remove the stale consolidation task; retain lowered evaluation for its real class/annotation/opcode callers. |

## Independent regex development

Active development checkpoint: immutable **0.5.0-dev.44** local Core/PythonRe
packages are available. Qualify the selected range-only/token-bridge variant
against current62141d4d on both actual runtimes using existing focused tests.
Record exact package/source/DLL identities; no inherited dev40 qualification or
normal-pin promotion. Then assess native caller-funded program/cache/working APIs
as a coherent replacement for adapter matching-size heuristics using existing
Lython budget hooks. Retain any missing one-shot/name bridges; no new memory
infrastructure, ledger, quotas or dependency edge to core. Development notes and
checks stay in .git/agent-notes/review-20261031/adapter44/.

Core owns one Python-specific nativeUTF8 contract across frontend/runtime/imports/
helpers: flags/effective capture analysis, names, byte/scalar ranges, original
windows, replacements/errors, cache ownership and current-operation cancellation.
Missing published producer APIs defer only affected final adapter qualification.
Development pins/adapter-local bridges are allowed; never add backend edges to core.

Normal adapter0.4 stays nonpackable. Private dev40 range-only source (producer
6f6fdab9; Core packageeb5d3ad4/PythonRe31c8d9f2) was qualified against runtime88,
not current HEAD:84internal/421public per actual runtime, real in-flight compile/
match/cursor cancellation, refusal/retention/reuse. Direct-token prototype allocated
+2.29%; selected range-only/local-token-bridge−22.81% on the same producer.
Elapsed diagnostic; no whole-script/released-backend/safety promotion claim.

Precise token gap: creation cancellation must not remain authority over independent
later advances. Creation validates whole input, so None+boundary checks is invalid.
Keep the local bridge until the producer distinguishes these operations. Native
UTF8 names still bridge strings; one-shot ranges/working/cache receipts/reversed
windows need exact API/semantic assessment, not inherited blanket blockers.
Dev40 XML/source assessment confirms only cursor range-result advances; one-shot
Match/Search/FullMatch still expose DetailedData and names still expose strings.
Do not emulate fullmatch by filtering a search result: alternative backtracking
would differ. Keep these bridges outside core until the precise native operations
exist; none blocks the existing core contract or independent R16 development.
Continue contract/core work independently; final adapter against an immutable
released package when available. No sibling edits or automatic promotion.

## Execution and experiment rules

Timeouts/unstable controls/inconclusive runs establish uncertainty. Allow bounded
confirmation, refinement and measurement correction with a concrete reason; retain
all original/adverse conditions. No blanket one-attempt/no-retiming/permanent bans.
Percentages inform decisions; distinguish simplification, allocations and CPU.

Use focused Release regressions, both runtimes when affected. Batch full Windows/
Ubuntu, original Stress and installed consumers at meaningful boundaries. No
overlapping local builds/tests; after timestamp-preserving source restoration force
a nonincremental build. Reuse valid qualification and cached terminal CI receipts.

Quiet VM lokad@20.166.121.73, key~/.ssh/id_lython-bench.pem. Lease/frozen worker/
actual loaded hashes/owned cleanup mandatory. Disk near full: preflight transfer,
expanded payload and archive headroom. Only hash-verified redundant owned transfers
with retained local copies/terminal owners may be removed; never sole evidence,
dependencies or runtime images. B348 setup had12.8MB free; preflight again next use.

Follow AGENTS.md. Fully managed/memory-safe: no unsafe/Unsafe/pointers/PInvoke/native
stack probing. Preserve managed stack/recursion, host capabilities/paths, cycles,
CancellationToken authority and borrowed shared admission/capacity/replacement/
retained aliases/pending users. No fuel, quotas/watchdogs/hidden caps, tracing/weak
reclamation/forced GC or new memory infrastructure. First refused admission is
terminal; never retry/fallback; await actual cleanup. Scope creation reserves
nothing; bounded host-driven streaming, no guest-heap tracing. No publication/tag.
