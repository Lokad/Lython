from pathlib import Path
import hashlib,shutil,subprocess,tarfile
payload=Path('/home/lokad/lython-bench-checks/b340-payload.tgz');root=Path('/home/lokad/lython-bench-checks/remaining-cost-b340-20261106')
assert not root.exists()
with tarfile.open(payload) as archive:
    assert shutil.disk_usage(root.parent).free>sum(x.size for x in archive.getmembers())+48*1024*1024
    root.mkdir();archive.extractall(root,filter='data')
subprocess.run(['python3',str(root/'setup.py')],check=True)
subprocess.run(['sudo','-n','systemd-run','--unit=lython-b340-remaining-cost-20261106','--property=User=lokad','--property=WorkingDirectory='+str(root),'--property=RuntimeMaxSec=90','--property=TimeoutStopSec=15','--property=KillMode=control-group','/bin/sh',str(root/'collect.sh')],check=True)
