from pathlib import Path
from textwrap import indent
import copy
import hashlib
import json
import os
import subprocess
import tarfile

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
donor = lab.parent / "machine-arithmetic-cpython-20261122"
previous = donor / "quiet"
current = lab / "quiet"

def read(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))

def digest(contents):
    return hashlib.sha256(contents).hexdigest()

def sha(path):
    return digest(path.read_bytes())

def write(path, source):
    if path.suffix == ".py":
        compile(source, str(path), "exec")
    path.write_text(source, encoding="utf-8", newline="\n")

config = read(previous / "config.json")
receipt = read(previous / "archive-receipt.json")
assert all(receipt[key] for key in ("complete", "quietBeforeAndAfter", "allWorkersJoined",
    "guestFixturesRemoved", "archivedAndVerifiedUnderLease"))
assert sha(previous / "observations.tgz") == receipt["archiveSHA256"]
assert read(previous / "terminal-status.json")["exitCode"] == "0"
identity = copy.deepcopy(config["identity"])
revision = identity["sourceRevision"]
subprocess.run(["git", "diff", "--exit-code", revision, "HEAD", "--", "src", "benchmarks/Lokad.Lython.Benchmarks"], cwd=repo, check=True)
image = donor / "frozen"
files = identity["imageFiles"]["candidate"]
assert len(files) == 32 and {name: sha(image / name) for name in files} == files
protocol = repo / "benchmarks/cpython-worker.py"
assert sha(protocol) == config["cpythonWorkerSHA256"]
base = read(previous / "representative.json")
original = next(case for case in base["cases"] if case["id"] == "scripts.ordinary-fully-supplied-helper")
definition, body = original["source"].split("\n\n")
body, publication = body.rsplit("print(total)\n", maxsplit=1)
assert not publication and body == (
    "total = 0\nfor index in range(2048):\n"
    "    total += evaluate(index, index % 11, index % 7 + 1)\n")
assert definition == "def evaluate(record, base, weight):\n    return (record + base) * weight"
inline = body.replace("    total += evaluate(index, index % 11, index % 7 + 1)\n",
    "    base = index % 11\n    weight = index % 7 + 1\n    total += (index + base) * weight\n")

def script(inner, function):
    prefix = definition + "\n\n"
    if function:
        return prefix + "def run():\n" + indent(inner + "return total\n", "    ") + "print(run())\n"
    return prefix + inner + "print(total)\n"

cases = []
for label, inner, function in (
    ("module-call", body, False), ("function-call", body, True),
    ("function-inline", inline, True), ("module-inline", inline, False)):
    case = copy.deepcopy(original)
    source = script(inner, function)
    compile(source, label, "exec")
    case.update(id="diagnostic.helper-placement." + label, category="helper-placement",
        source=source, sourceUtf8Bytes=len(source.encode("utf-8")), sourceSha256=digest(source.encode("utf-8")))
    if label == "module-call":
        assert source == original["source"] and case["sourceSha256"] == original["sourceSha256"]
    cases.append(case)

current.mkdir()
catalog = current / "representative.json"
write(catalog, json.dumps(dict(base, cases=cases, performanceQualified=False), ensure_ascii=False, indent=2) + "\n")
dotnet = Path.home() / ".dotnet11/dotnet.exe"
env = dict(os.environ, DOTNET_ROOT=str(dotnet.parent), DOTNET_ROOT_X64=str(dotnet.parent),
    PATH=str(dotnet.parent) + os.pathsep + os.environ["PATH"])
proof_path = lab / "verify.json"
subprocess.run([dotnet, image / "Lokad.Lython.Benchmarks.dll", "--compare", "verify", "--catalog", catalog,
    "--dotnet", dotnet, "--python", "C:/Python313/python.exe", "--python-worker", protocol, "--out", proof_path],
    env=env, check=True, timeout=95)
proof = read(proof_path)
assert proof["state"] == "Completed" and proof["caseCount"] == 4 and proof["catalogSha256"] == sha(catalog)
identity.update(purpose="Matched arithmetic at module and function scope", catalogSHA256=sha(catalog))
write(current / "identity.json", json.dumps(identity, indent=2) + "\n")

new_root = "/home/lokad/lython-bench-checks/module-helper-placement-b1363-20261122"
unit = "lython-b1363-module-helper-placement-20261122"
jobs = [(case["id"], "warm") for case in cases]
for name in ("collect.py", "archive-owned.py", "run.sh", "retrieve.py"):
    content = (previous / name).read_text(encoding="utf-8").replace(config["root"], new_root).replace(config["unit"], unit)
    content = content.replace("B1361", "B1363")
    if name == "collect.py":
        begin = content.index("    for case_id,lane in ")
        end = content.index("        assert time.monotonic()", begin)
        content = content[:begin] + f"    for case_id,lane in {jobs!r}:\n" + content[end:]
        content = content.replace("retained-source warm, compile-to-result and compilation comparison",
            "matched warm arithmetic and loop placement").replace("time.monotonic()-started<280", "time.monotonic()-started<230")
    elif name == "archive-owned.py":
        content = content.replace("len(raw['jobs'])==5", "len(raw['jobs'])==4").replace("jobs=5,", "jobs=4,")
    elif name == "retrieve.py":
        content = content.replace("['jobs']==5", "['jobs']==4")
        content = content.replace("Retained-source CPython", "Matched-scope CPython")
    write(current / name, content)
assert b"\r" not in (current / "run.sh").read_bytes()

parts = ("identity.json", "representative.json", "collect.py", "archive-owned.py", "run.sh")
payload = current / "payload.tgz"
with tarfile.open(payload, "w:gz") as archive:
    for name in parts:
        archive.add(current / name, arcname=name)
stage = dict(root=new_root, unit=unit, identity=identity, source=config["root"], sourceRole="candidate",
    sourceFiles=files, sourceCatalogSHA256=config["catalogSHA256"], donorArchiveSHA256=receipt["archiveSHA256"],
    catalogSHA256=identity["catalogSHA256"], retireGroups=[], cpythonWorkerSHA256=sha(protocol),
    payloadBytes=payload.stat().st_size, payloadSHA256=sha(payload),
    unpackedBytes=sum((current / name).stat().st_size for name in parts))
write(current / "config.json", json.dumps(stage, indent=2) + "\n")
remote = (previous / "remote-launch.py").read_text(encoding="utf-8")
begin = remote.index("\nc=") + 1
end = remote.index("\nb=Path(")
remote = remote[:begin] + "c=" + repr(stage) + remote[end:]
remote = remote.replace("lython-b1361-fixtures", "lython-b1363-fixtures")
remote = remote.replace("RuntimeMaxSec=340", "RuntimeMaxSec=285")
write(current / "remote-launch.py", remote)
launch = (donor / "launch.py").read_text(encoding="utf-8").replace("B1361 arithmetic and CSV against CPython", "B1363 matched helper placement")
write(lab / "launch.py", launch.replace("315", "270"))
print("Four matched scripts verify against the 32-file production image and stock CPython.")
