from pathlib import Path
import hashlib
import json
import statistics

lab = Path(__file__).resolve().parent
quiet = lab / "quiet"
donor = lab.parent / "machine-arithmetic-cpython-20261122"

def read(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

identity = read(quiet / "identity.json")
files = identity["imageFiles"]["candidate"]
assert len(files) == 32 and {n: sha(donor / "frozen" / n) for n in files} == files
terminal = read(quiet / "terminal-status.json")
receipt = read(quiet / "archive-receipt.json")
assert terminal["exitCode"] == "0" and terminal["receipt"] == receipt and receipt["jobs"] == 4
assert not terminal["remainingWorkers"] and not terminal["remainingTrace"]
assert all(receipt[key] for key in ("complete", "allWorkersJoined", "quietBeforeAndAfter",
    "guestFixturesRemoved", "archivedAndVerifiedUnderLease"))
assert sha(quiet / "observations.tgz") == receipt["archiveSHA256"]
catalog = quiet / "representative.json"
proof = read(lab / "verify.json")
assert proof["state"] == "Completed" and proof["caseCount"] == 4
assert proof["catalogSha256"] == sha(catalog) == identity["catalogSHA256"]
raw = read(quiet / "retrieved/confirmation/confirmation.json")
assert raw["complete"] and len(raw["jobs"]) == 4
previous = read(donor / "quiet/retrieved/confirmation/confirmation.json")
stock = previous["jobs"][0]["identities"]["CPython"]
roles = ("candidate", "candidate-control", "CPython", "CPython-control")
rows = {}

def bounds(values):
    return [min(values), max(values)]

for case, job in zip(read(catalog)["cases"], raw["jobs"], strict=True):
    assert case["id"] == job["case"] and case["size"] == 2048 and case["expectedOutput"] == "8421311\n"
    assert job["lanes"] == ["warm"] and job["workersJoinedAndFixturesRemoved"] and not job["diagnostic"]
    assert set(job["identities"]) == set(roles) and len(job["samples"]) == len(roles) * 7
    engines = {}
    for role in roles:
        observed = job["identities"][role]
        if role.startswith("CPython"):
            assert observed["version"] == stock["version"] and observed["version"].startswith("3.13.16 ")
            assert observed["executableSha256"] == stock["executableSha256"]
            assert observed["adapterSha256"] == identity["cpythonWorkerSHA256"]
        else:
            supplied = {Path(lib["path"]).name: lib["sha256"].lower()
                        for lib in observed["libraries"] if Path(lib["path"]).name in files}
            assert supplied["Lokad.Lython.dll"] == files["Lokad.Lython.dll"]
            assert all(files[name] == value for name,value in supplied.items())
        elapsed, cpu = [], []
        for round, sample in enumerate(s for s in job["samples"] if s["engine"] == role):
            assert sample["round"] == round and sample["lane"] == "warm"
            value = sample["response"]
            assert value["status"] == "Completed" and value["caseId"] == case["id"]
            assert value["sourceSha256"] == case["sourceSha256"] and value["fixtureSha256"] == case["fixtureSha256"]
            assert value["actualOutputSha256"] == case["expectedOutputSha256"]
            assert value.get("actualFilesSha256") == case.get("expectedFilesSha256")
            invocations = value["completedInvocations"]
            assert invocations > 0
            elapsed.append(1000 * value["elapsedTicks"] / value["clockFrequency"] / invocations)
            cpu.append(1000 * sample["externalProcessCpuTicks"] / sample["externalCpuFrequency"] / invocations)
        elapsed_median = statistics.median(elapsed)
        low, _, high = statistics.quantiles(elapsed, n=4, method="inclusive")
        engines[role] = dict(elapsedMs=elapsed_median, externalCpuMs=statistics.median(cpu),
            elapsedIQRPercent=100 * (high-low) / elapsed_median)
    lython = [engines[x]["elapsedMs"] for x in roles[:2]]
    cpython = [engines[x]["elapsedMs"] for x in roles[2:]]
    rows[case["id"].rsplit(".", 1)[-1]] = dict(sourceSHA256=case["sourceSha256"],
        lythonMs=bounds(lython), cpythonMs=bounds(cpython),
        ratio=bounds([l/c for l in lython for c in cpython]),
        workerSpreadPercent=[100*(max(sample)/min(sample)-1) for sample in (lython,cpython)],
        engines=engines)

effects = {}
for name, target, reference in (
    ("functionVersusModuleWithCall", "function-call", "module-call"),
    ("functionVersusModuleInline", "function-inline", "module-inline"),
    ("callVersusInlineAtModule", "module-call", "module-inline"),
    ("callVersusInlineInFunction", "function-call", "function-inline")):
    effects[name] = {}
    for label, group in (("lython", roles[:2]), ("cpython", roles[2:])):
        effect = {}
        for clock in ("elapsedMs", "externalCpuMs"):
            effect[clock] = bounds([100 * (rows[target]["engines"][to][clock] /
                               rows[reference]["engines"][frm][clock] - 1) for to in group for frm in group])
        effects[name][label] = effect

allocation = {}
for filename in ("allocation.json", "allocation-order.json"):
    for row in read(lab / filename)["rows"]:
        assert row["sharedBudgetBaselineRestored"]
        allocation[row["id"].rsplit(".", 1)[-1]] = dict(medianBytes=statistics.median(row["allocatedBytesPerInvocation"]),
            samples=row["allocatedBytesPerInvocation"],peakAllowanceBytes=row["peakExecutionMemoryBytes"],fullRefund=True)
for scope in ("module", "function"):
    assert allocation[scope + "-call"]["medianBytes"] - allocation[scope + "-inline"]["medianBytes"] == 65536
    assert allocation[scope + "-call"]["medianBytes"] - allocation[scope + "-call-read-after"]["medianBytes"] == 65504

summary = dict(revision=identity["sourceRevision"], coreSHA256=files["Lokad.Lython.dll"],
    sourceCatalogSHA256=sha(catalog), rows=rows, relativeChangesPercent=effects, localWindowsAllocation=allocation,
    verifiedBatches=112, elapsedSeconds=raw["elapsedSeconds"], rawSHA256=receipt["archiveSHA256"])
(lab / "summary.json").write_text(json.dumps(summary, indent=2) + "\n", encoding="utf-8", newline="\n")
for label, row in rows.items():
    print(label, {k: v for k,v in row.items() if k not in ("sourceSHA256", "engines")})
print(json.dumps(effects, indent=2))
