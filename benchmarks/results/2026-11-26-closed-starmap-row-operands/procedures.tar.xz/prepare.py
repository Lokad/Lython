from pathlib import Path

lab = Path(__file__).resolve().parent
prior = lab.with_name("starmap-frame-inputs-20261126")

def script(path, source, replacements):
    for old, new in replacements:
        assert source.count(old) == 1, old
        source = source.replace(old, new)
    compile(source, path.name, "exec")
    path.write_text(source, encoding="utf-8", newline="\n")

def read(path):
    return path.read_text(encoding="utf-8")

script(lab / "diagnose.py", read(prior / "diagnose.py"), [
    ('donor = lab.with_name("starmap-direct-sequence-packet-20261126")',
     'donor = lab.with_name("starmap-frame-inputs-20261126")'),
    ('assert subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=repo, text=True).strip() == base',
     'assert not subprocess.check_output(["git", "diff", base, "HEAD", "--", "src"], cwd=repo)'),
    ('    "src/Lokad.Lython/Runtime/LythonRuntime.Calls.cs",',
     '    "src/Lokad.Lython/Runtime/LythonRuntime.Executable.IntegerChains.cs",'),
    ('    "src/Lokad.Lython/Runtime/PyItertools.Transforms.cs",\n', ''),
    ('baseline = repo / "src/Lokad.Lython/bin/Release/net11.0" / core\n'
     'test_baseline = repo / "tests/Lokad.Lython.PublicApi.Tests/bin/Release/net11.0" / core\n'
     'assert digest(baseline) == digest(test_baseline)',
     'baseline = donor / "local/candidate" / core\n'
     'proved = read(donor / "comparison/quiet/terminal-status.json")["receipt"]\n'
     'assert proved["complete"] and digest(donor / "comparison/quiet/observations.tar.xz") == proved["archiveSHA256"]\n'
     'subprocess.run(["git", "apply", "--reverse", "--check", str(donor / "candidate.patch")], check=True, cwd=repo)'),
])
script(lab / "prepare-local.py", read(prior / "prepare-local.py"), [
    ('prior = lab.with_name("trim-truth-without-result-20261126")',
     'prior = lab.with_name("starmap-frame-inputs-20261126")'),
    ('    ["diagnostic.shipment-starmap-short-lists", "warm"],\n',
     '    ["diagnostic.shipment-starmap-short-lists", "warm"],\n'
     '    ["scripts.csv-meter-report.explicit-float", "warm"],\n'
     '    ["diagnostic.shipment-starmap-short-lists", "warm-async"],\n'),
    ('Fill wider exact starmap rows directly into the existing native callback frame.',
     'Read exact starmap row operands directly for callback returns that need no frame.'),
    ('collector.replace("assert len(jobs) == 5 and", "assert len(jobs) == 4 and")',
     'collector.replace("assert len(jobs) == 4 and", "assert len(jobs) == 6 and")'),
    ('collector.replace("lython-trim-truth-without-result-fixture-", "lython-starmap-frame-inputs-fixture-")',
     'collector.replace("lython-starmap-frame-inputs-fixture-", "lython-closed-starmap-row-operands-fixture-")'),
    ('(("receipt[\'warmJobs\'] == 5", "receipt[\'warmJobs\'] == 4"),\n'
     '                      ("len(raw[\'jobs\']) == 5", "len(raw[\'jobs\']) == 4"), ("timedBatches=140", "timedBatches=112")):',
     '(("receipt[\'warmJobs\'] == 4", "receipt[\'warmJobs\'] == 6"),\n'
     '                      ("len(raw[\'jobs\']) == 4", "len(raw[\'jobs\']) == 6"), ("timedBatches=112", "timedBatches=168")):'),
])
