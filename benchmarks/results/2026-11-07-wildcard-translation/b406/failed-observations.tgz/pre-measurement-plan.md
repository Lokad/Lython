# Lokad.Lython 0.11.0

Updated 2026-11-07. Git-ignored; never force-add. Publication/tagging postponed.
Objective: coherent simplification and substantial complete-script performance.
Completing one experiment or qualification checkpoint does not complete this objective.

## Delivery status

- **Fully qualified production8c9fd0d7:** CI42371564043 terminal GREEN on
  Windows/Ubuntu Release actual11/10, original Stress both targets and installed
  core consumers. Includes R44's twelve immediate duplicate checks and R45's
  admitted/cancellable UTF-8 integer parser. Receipt beside integer-parsing
  evidence. Earlier R43/R41 receipts remain cached; never query terminal runs again.
- **Committed/pushed documentationad74fa41:** B400 CPython refresh, exact8c9fd0d7
  production/frozen d3a6c778.21jobs/all gates,434.37s, raw archive601c0fe8 verified
  under lease and locally. Warm CSV1.22–1.23x, text1.73–1.77x, JSON1.03x,
  report1.50x, config1.25–1.29x; explicit affected CSV1.06–1.07x, numeric-string
  JSON1.69–1.70x. Separate compile/compile-to-result and included I/O/cleanup are
  in docs/BENCHMARKS.md; variable controls stay visible. No startup/RSS/tail claim.
- **R49 committed9990d591, fully qualified CI42379372181:** module declaration slots/publication,
  shared import facts, focused actual11/10 and bounded B404 elapsed checks pass.
  Extra48–96B admitted root capacity is explicit; no stack/cancellation policy change.
- **R50 committed/pushed80833f6e, delivery pending:** managed native integer width, focused both
  runtimes and real cancellation pass; B405 numeric-string elapsed/allocated gains
  and padded-CSV+1.1% tradeoff are recorded separately from current CPython tables.
- **R46 prototype withdrawn:** JSON sharing the general int kernel materially
  regresses allocation. Exact source restored and Release solution rebuilt
  nonincrementally, zero warnings/errors. No prototype/runtime branch survives.
  Evidence and initial failed test assertions remain outside docs/.
- **Independent regex:** core decoupled, optional nonpackable normal adapter0.4.0.
  Earlier immutable dev48/f6b2175e focused qualification is historical, not final
  current-source safety/performance certification. Publication/tagging postponed.

## Established evidence and unresolved debt

| Work | Established result | Limits / decision |
| --- | --- | --- |
| Shared compiler facts | Corrected shared inferred-value traversal eliminates exponential analysis; fully qualified | Preserve callback correction; no warm CPU claim. |
| Native helper returns | Allocation −19.92/−19.31%; fully qualified | Earlier elapsed gains remain diagnostic. No unchanged requalification. |
| Direct UTF-8 formatting/storage | Allocation −8.67%; controlled B102 elapsed/CPU −5–8% supports retention | Original adverse 15.125 ms remains unexplained and preserved. |
| R20/R25 records | Shared keys, independent values, completed CSV storage transfer; allocation −7.31/−6.55%, native warm −7.72–8.04% | Selectively replaces the old rigidly rejected 6–8% bulk-record attempt; controls mixed. |
| R35/R38 | Dynamic report allocation ~−15.35%, quiet warm −10–13%; compile allocation −4.38–8.94% | CSV possible debt +0.13–2.36%; R38 required full regex analysis preserved after three initial failures. |
| R40/R41 | Unicode cursor scaling −31–79%; shared receiver methods remove ten markers/guards and closures, regex allocation ~−29.47%, warm −8.64–10.80% | Not broad CPU/parity claims; ASCII and original CSV adverse controls remain possible debt. Fully qualified. |
| R42 cost gate | Text: 1,089 CPU samples, 44 unknown; prefix 229 self / 1,056 inclusive; scalar add 41 self | Self includes inlined work; inclusive totals overlap. No universal scalar rewrite or saved-CPU forecast. |
| R43 ordinary operands | Fewer instructions/smaller immutable payload; compile allocation +0.20–0.87%; full delivery green | Text warm −1.37 to +1.11%, fresh −2.23 to −0.15%; CSV variable, JSON −2.37 to +6.81%/6.66% identical-current spread, report −2.19 to −0.73%/3.92% IQR. No substantial CPU claim; debt stays. |

History, original failed conditions, rejected designs and complete qualification
live in benchmarks/EXPERIMENTS.md and immutable benchmarks/results/. R43 development
evidence stays outside docs/. Do not repeat unchanged completed qualification.

## Completed R44/R45 delivery checkpoint

R45 removes decoded copies/UTF-16 general int parsing, uses native accumulation
then admitted radix chunks, and corrects Unicode decimal semantics. B399 shows
affected padded CSV warm−12.49–13.41% and numeric-string JSON−41.43–41.98%.
Initial allocation−14.70/13.35% and−62.99/62.98% sync/async; ordinary controls
mixed. Final refinement removes one check; allocation was not replayed. Tiny
thresholds change; three conservative magnitudes fund promotion/replacement, with
existing small-scalar headroom. Individual BCL magnitude operations are atomic.
Focused, actual in-flight cancellation and full delivery pass. B400 closes the
external comparison gap. History: benchmarks/results/2026-11-07-integer-parsing/
and integer-cpython/. Do not repeat unchanged qualification or timing.

## Priority 1 — retain R49/R50, close delivery and choose the next coherent phase

R49 committed/pushed9990d591. CI42379372181 terminal GREEN on both platforms,
actual11/10, original Stress and installed consumers. Receipt committed4c739dcb;
never query it again. This qualifies only R49, not later R50. Native code/bench results
are frozen; do not re-run completed focused checks or B404. Namespace publication
past frame cleanup and the initial29failures remain documented and tested.

R50 retained: one managed UInt128 accumulator/DivRem guard, existing cancellable
chunks, explicit admission before every native>64bit BigInteger conversion. No
JSON parser, public integer type, ownership framework, unsafe code or quota change.
102internal/420public per actual11/10 pass, including329CPython cases/140new
128bit boundaries. Real in-flight cancellation Stress passes49/53ms (not a latency
guarantee), users joined before refund. Source/initial/refined/adverse evidence:
benchmarks/results/2026-11-07-native-integer-width/.

B405 terminal/all three gates,87.38s, raw2f2e6618 verified under lease/locally.
Numeric-string JSON warm−10.68–12.50%, allocation−12.492/12.487%sync/async.
Padded CSV+0.99–1.16% is explicit accepted debt (~0.047ms/job), not hidden behind
a second native tier. Ordinary JSON−0.90to+3.74%/3.25%current-role spread is a
variable control; its parser is unchanged. No async elapsed, isolated CPU, RSS,
tail, arbitrary-large scaling or universal speedup claim. Native admission timing/
tiny thresholds can change; retained payload stays funded. Preserve that tradeoff.

- R50 source/docs/evidence committed80833f6e. Batch full Windows/Ubuntu,
  actual11/10, original Stress and installed consumers once. Work independently
  while delivery runs; publication/tagging remains postponed. Do not query terminal
  jobs again or relabel the existing8c9fd0d7 CPython tables as later HEAD.
- At the combined retained delivery checkpoint refresh representative CPython
  compilation/warm/compile-to-result using existing workers, including explicit
  affected input labels and I/O/cleanup boundaries. One coherent refresh, not a
  new framework or another round of unchanged experiments.
- Independent regex source gate: inspect fnmatch/glob pattern translation and
  frontend consumers for remaining unnecessary UTF16/UTF8 conversion/copies.
  Select a shared native-UTF8 translation change only if the current source still
  demonstrates that work. Preserve Python bracket/escape/range/flags semantics,
  original subject coordinates, current-token work, admitted construction overlap
  and retained cache owners. Existing semantic/cooperating-provider tests decide;
  missing producer APIs defer only affected final adapter qualification. No sibling
  edits, silent dialect replacement, new policy or memory manager.

The larger non-regex boundaries below remain active. New profiles/prototypes need
real removable work and semantic/source acceptance before timing. R46's CLR-versus-
chunk lesson, R48's non-dominant admission samples and slower call-arena/control
designs remain evidence, not permanent bans. Full performance objective stays open.

### Selected R51 — one native UTF-8 wildcard translation path

Source gate confirms fnmatch/glob translation still decodes complete inputs,
builds UTF-16 output, re-encodes it, copies glob segments into List<string>, and
uses another builder per bracket class. Matching itself already stays UTF-8;
frontend consumers validate arguments and do not need a second translation route.
Hypothesis: remove that entire intermediate representation, not optimize matching.
Affected scripts generate filename/path regexes (Unicode, recursive/hidden paths);
ordinary CSV/text/JSON are unchanged controls, with no predicted broad CPU gain.

Replace both translation emitters and shared class/separator helpers with one
scalar-aware UTF-8 emitter into existing governed output storage. Iterate original
glob segment windows; emit classes directly, truncating only private output for
empty reversed ranges. Delete decoded scratch estimates, segment list/copies,
UTF-16 builders and final encoding. Existing builder admission funds capacity,
replacement overlap and transferred immutable output; no new owner/cache/policy.

Accept Python matching/search/end anchors, supplementary scalars, escapes/ranges,
empty/multiple separators, recursive/hidden segments, path-like coercion order,
both APIs and current cancellation through actual loops. Check refusal before
publication, retained output funding, cleanup/budget reuse and provider independence.
Use existing goldens plus focused ownership/cancellation controls; one bounded
before/after complete-script allocation/elapsed diagnostic with unchanged controls.
Retain adverse observations. Select retention on semantic/simplification evidence,
not a fixed percentage; unexpected CPU cost requires explicit debt/correction.
Full qualification batches after a coherent retained change; no adapter release
needed. Stop if semantics require a second translation backend or new infrastructure.

Initial source passes29internal/133public per actual11/10. Complete-script
translation allocation−21.17–22.75%; original clocks/controls mixed, async glob
+7.97–8.20% adverse. Baseline-only first collection failed Windows CRLF goldens
before samples; original source/catalog/error retained, explicit file newline and
canonical stdout fixed. One justified refinement preadmits input-sized byte
capacity/headroom to avoid repeated small reservation/growth phases; preserve
initial source/checks/cores/clocks and confirm once, not repeat until favorable.

Refinement retained: existing builder admits input-sized initial capacity plus
modest headroom once.29internal/133public per actual11/10 pass; two additional
actual in-flight separator scans per target cancel and join before refund.
Native output remains funded. Complete-script allocation fnmatch−25.029/25.017%,
glob−31.797/31.809%sync/async; controls within0.01%. Desktop elapsed remains
inconclusive: initial async glob+8%; refined sync fnmatch spans+0.59–23.83% with
23.1% identical-before drift, async glob−0.96to+7.09%/−7.51%control drift. No CPU
claim or assertion that the original cost is resolved. Evidence/initial failed
conditions: benchmarks/results/2026-11-07-wildcard-translation/. Retained source
now needs one batched delivery and quiet source-pair confirmation alongside the
representative CPython checkpoint, not another desktop retiming.

## Next redesign boundaries

Select a real dominant phase from current evidence; do not accumulate narrow cases.
For each selected milestone record the hypothesis, eliminated work/storage and
displaced code, affected scripts, semantic gates, bounded comparison and controls.

| Boundary | Evidence / acceptance / stopping criterion |
| --- | --- |
| Complete calls/frames | R39 CSV helper-inclusive totals are useful work, not proof of binding dominance. Existing borrowed operands/final slots/lazy contexts/native helpers stay. Select only a real removable phase; preserve binding, defaults, closures, exceptions, genuine I/O and owners. Slower call-arena/control designs require new evidence, not automatic retry. |
| Operand transport | R43 retained smaller code and fewer instructions, with CPU improvement unproved. No further leaf-specific rewrite without materially new evidence. |
| Completed-instruction guards | R44 completes twelve provably immediate duplicates. Wider opcode hoisting lacks a complete cancellation/refusal/error-order proof and is not selected. R42 prefix self is not guard CPU. Keep meaningful checkpoints; no replacement counters/quotas or weaker containment. |
| Per-record collections | Shared keys/R25 transfer and synchronous JSON already exist. Reassess bulk construction only where an actual extra copy/capacity phase remains; preserve hook/order/reentry/alias/overlap semantics. Original control regressions remain evidence. |
| Scalars and text | R42 scalar add alone is insufficient for universal tagged values. Bulk UTF-8 and prepared helpers already exist. R28 already tested newly owned packed split storage: allocation −6.94%, text variable, report +0.91–4.97% after refinement; withdrawn. Do not rediscover it as a new design or indiscriminately share refundable input windows. Select materially different remaining work; preserve promotion, identity, Unicode, hashes and cancellation. |
| Frontend/setup | Shared lexical/class/parameter facts, R38 demand pruning, shared builtins and executable imports already exist. Remove actual repeated analysis/storage; preserve dead-scope diagnostics, fresh mutable state and regex analysis. Compile separately, and include compile-to-result for config/new scripts. |

A justified redesign may temporarily regress. Its completion milestone must state
whether remaining debt is accepted, corrected or withdrawn. A source simplification,
an allocation reduction and a CPU improvement are distinct results.

## Independent regex track

Continue Lython-owned Python/native UTF-8 semantics: byte ranges, scalar positions,
original-subject windows, captures/replacements/errors/cache ownership and current
tokens through actual work. Development producers and adapter-local bridges may
support contract/semantic work; missing released capabilities defer only affected
final adapter qualification. They do not stop core or independent performance work.

Current precise producer gaps: DetailedData lacks a separate Prepare working owner;
native names lack enumeration; cursors mix creation/current token authority. Exact
dev48 supplies no documented removal of these limits. Keep conservative preflight,
adapter-local conversion and the qualified cancellation bridge where needed.
Qualify immutable released inputs and managed safety separately. No silent dialect
fallback, work/time quotas, sibling edits, abandoned matching or publication gate
on Lython development. Existing R40/R41 work needs no new producer release.

## Experimental and delivery policy

Timeouts, unstable unchanged controls and inconclusive observations establish
uncertainty, not permanent design rejection. Permit bounded justified confirmation,
refinement or measurement correction; never repeat until favorable. Size observations
for the quiet VM, preserve original conditions/adverse results and source/binary
provenance. Percentages inform decisions rather than automatically vetoing useful
simplification. Use focused correctness/cancellation/ownership checks while iterating;
batch full actual11/10 Windows/Ubuntu, original Stress and installed consumers at
meaningful retained delivery checkpoints. Publication remains postponed.

## Constraints / resources

AGENTS.md governs: fully managed/memory-safe, managed stack/nesting, host mediation,
current cancellation, borrowed shared allowance/preflights/overlap/escaping aliases
and awaited cleanup. First refused admission terminates the command. No unsafe,
tracing, weak reclamation, forced GC, fuel/quotas/caps or hidden allowance. Bounded
host-driven batches; XML depth constraint retained. No overlapping local tests,
builds or measurements. PLAN stays ignored; docs describe only current releases.

VM: lokad@20.166.121.73, key ~/.ssh/id_lython-bench.pem. B385–B405 terminal and
archived; never service-query again. B402 original failed conditions preserved;
B403/B404/B405 all gates, raw e8be5f91/9813698d/2f2e6618 verified under collection
lease and locally. No active VM users/fixtures/traces. Last launch free23.5MB;
before further collections retire only exact archive/Git-backed duplicate staging
under a fresh lease with all users ended, preserving originals and image references.
CI42379372181 and earlier runs terminal GREEN/cached. R50 delivery dispatch targets
4c739dcb (production80833f6e); observe no sooner than five minutes after dispatch.
Record future owner/
stop/margin; never restart on observation timeout. Persist/verify RAM archives before
removal. Producer6032b928/dev51 still has the precise missing semantics above;
no new package qualification or core-development blocker inferred.

R51 committed/pushed55e510ff; full CI dispatched14:48:09UTC, next>=14:53:10.
B406 selected coherent checkpoint:25jobs, seven ordinary complete scripts with
compile/warm/compile-run, two explicit integer warm cases, two wildcard source
pairs.600s owner+30s stop+30s margin, observe after660s. Source/worker/normal
profile/goldens/funding/cleanup/quiet/archive gates retained; no CPU claim yet.
Five exact archive-backed staging files retired under a separate lease, originals
verified against local archives and intact; free26.8MB before setup.
