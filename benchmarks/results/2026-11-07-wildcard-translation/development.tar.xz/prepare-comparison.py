from pathlib import Path
import base64,hashlib,json,os,shutil,struct,subprocess,tempfile
r=Path(__file__).parent;home=r.parent
focused=json.loads((r/'focused.json').read_text(encoding='utf-8'))
for p,digest in focused['productionSources'].items(): assert hashlib.sha256(Path(p).read_bytes()).hexdigest()==digest
target=r/'candidate-image';shutil.copytree(r/'before-image',target,copy_function=os.link)
(target/'Lokad.Lython.dll').unlink();shutil.copy2(r/'cores/net11.0/Lokad.Lython.dll',target/'Lokad.Lython.dll')
catalog=json.loads((home/'integer-utf8-r45/catalog.json').read_text(encoding='utf-8'))
template=catalog['cases'][0]
def digest(files):
 h=hashlib.sha256();h.update(struct.pack('>i',len(files)))
 for name,data in sorted(files.items()):
  name=name.encode();h.update(struct.pack('>i',len(name)));h.update(name);h.update(struct.pack('>i',len(data)));h.update(data)
 return h.hexdigest()
affected=[]
for module in ['fnmatch','glob']:
 options="" if module=='fnmatch' else ",recursive=True,include_hidden=False,seps='/😀'"
 source=f'''import {module}
patterns=[]
with open('patterns.txt') as source:
    for line in source:
        patterns.append({module}.translate(line.rstrip('\\n'){options}))
with open('report.txt','w') as target:
    target.write('\\n'.join(patterns)+'\\n')
print(len(patterns))
'''
 patterns=[f'g{i:04d}[α-ω]?é.txt' if module=='fnmatch' else f'src{i:04d}😀**/[α-ω]?é.txt' for i in range(512)]
 inputs={'patterns.txt':('\n'.join(patterns)+'\n').encode()}
 with tempfile.TemporaryDirectory(prefix='lython-r51-goldens-')as folder:
  root=Path(folder)
  for name,data in inputs.items():(root/name).write_bytes(data)
  run=subprocess.run(['C:/Python313/python.exe','-I','-S','-X','utf8','-c',source],cwd=root,capture_output=True,timeout=20)
  assert run.returncode==0,run.stderr.decode()
  outputs={'report.txt':(root/'report.txt').read_bytes()}
 fixture=dict(size=512,text=None,inputFiles={k:base64.b64encode(v).decode()for k,v in inputs.items()},outputFiles={k:base64.b64encode(v).decode()for k,v in outputs.items()})
 item=dict(template);item.update(id=f'scripts.{module}-translation.512',size=512,source=source,sourceSha256=hashlib.sha256(source.encode()).hexdigest(),fixtureJson=json.dumps(fixture,ensure_ascii=False,separators=(',',':')),expectedOutput=run.stdout.decode(),expectedOutputUtf8Bytes=len(run.stdout),expectedFilesSha256=digest(outputs),inputUtf8Bytes=sum(map(len,inputs.values())))
 affected.append(item)
 (r/(module+'-script.py')).write_text(source,encoding='utf-8',newline='\n')
controls=[c for c in catalog['cases']if c['id']in ['scripts.text-summary-helpers.large','scripts.csv-summary-functions.large','scripts.json-summary-helpers.large']]
assert len(controls)==3
catalog['cases']=affected+controls
(r/'catalog.json').write_text(json.dumps(catalog,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
(r/'goldens.json').write_text(json.dumps(dict(reference=subprocess.check_output(['C:/Python313/python.exe','--version'],text=True).strip(),cases=[dict(id=c['id'],inputUtf8Bytes=c.get('inputUtf8Bytes'),sourceSha256=c['sourceSha256'],expectedOutput=c['expectedOutput'],expectedFilesSha256=c['expectedFilesSha256'])for c in affected],boundaries='512 filename/path regexes, mediated input/output, full file/stdout goldens, retained list/result cleanup. Translation-only output generation, no matching CPU attribution.'),indent=2)+'\n',encoding='utf-8')
s=(home/'integer-width-r50/measure.py').read_text(encoding='utf-8').replace("r/'images/before/Lokad.Lython.Benchmarks.dll'","r/'before-image/Lokad.Lython.Benchmarks.dll'").replace("r/'images/candidate/Lokad.Lython.Benchmarks.dll'","r/'candidate-image/Lokad.Lython.Benchmarks.dll'")
(r/'measure.py').write_text(s,encoding='utf-8',newline='\n')
s=(home/'integer-width-r50/summarize.py').read_text(encoding='utf-8')
(r/'summarize.py').write_text(s,encoding='utf-8',newline='\n')
print('Two CPython-golden translation scripts and three original controls prepared; unchanged driver, no timing yet.')
