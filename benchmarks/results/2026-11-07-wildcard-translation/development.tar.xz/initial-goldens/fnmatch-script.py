import fnmatch
patterns=[]
with open('patterns.txt') as source:
    for line in source:
        patterns.append(fnmatch.translate(line.rstrip('\n')))
with open('report.txt','w') as target:
    target.write('\n'.join(patterns)+'\n')
print(len(patterns))
