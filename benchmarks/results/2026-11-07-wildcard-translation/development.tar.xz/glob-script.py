import glob
patterns=[]
with open('patterns.txt') as source:
    for line in source:
        patterns.append(glob.translate(line.rstrip('\n'),recursive=True,include_hidden=False,seps='/😀'))
with open('report.txt','w',newline='\n') as target:
    target.write('\n'.join(patterns)+'\n')
print(len(patterns))
