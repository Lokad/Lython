from pathlib import Path
p = Path('src/Lokad.Lython/Runtime/LythonRuntime.FnMatchModule.cs')
s = p.read_text(encoding='utf-8')
s = s.replace('''            using var scratch = context.MemoryGovernor.ReserveTemporary(checked(128L + 24L * pattern.Utf8Bytes.Length), span);
            return CreateString(TranslatePattern(pattern.AsString(), context.State.CancellationToken), context, span);''', '''            return TranslateWildcardPattern(pattern, context, span);''')
s = s[:s.index('        private static int ReadScalar(')] + '    }\n}\n'
s = s.replace('ReadScalar(', 'ReadWildcardScalar(')
for line in ['using System.Globalization;\n','using System.Numerics;\n','using System.Text.Encodings.Web;\n','using System.Text;\n','using System.Text.Json;\n']:
    s = s.replace(line, '')
p.write_text(s,encoding='utf-8',newline='\n')
p = Path('src/Lokad.Lython/Runtime/LythonRuntime.GlobModule.cs')
s = p.read_text(encoding='utf-8')
start = s.index('        using var scratch = PathOps.ReserveWorking(path, context, span, seps);')
end = s.index('\n    }',start)
s = s[:start] + '        return TranslateGlobPattern(path, recursive, hidden, seps, context, span);' + s[end:]
s = s[:s.index('    private static string TranslateGlobPattern(')] + '}\n'
s = s.replace('using System.Text;\n','')
p.write_text(s,encoding='utf-8',newline='\n')
