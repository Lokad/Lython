from pathlib import Path
import hashlib,json,os,shutil,subprocess,time
r=Path(__file__).parent
env=os.environ.copy();env['DOTNET_ROOT']='C:/Users/JoannesVermorel/.dotnet11';env['DOTNET_HOST_PATH']=env['DOTNET_ROOT']+'/dotnet.exe';env['PATH']=env['DOTNET_ROOT']+os.pathsep+'C:/Python313'+os.pathsep+env['PATH']
checks={}
for tfm in ['net11.0','net10.0']:
 for project,selection in [
  ('Lokad.Lython.Tests','Category!=Stress&(FullyQualifiedName~Wildcard|FullyQualifiedName~RegexCompilationAccounting|FullyQualifiedName~RegexCacheCapacityAccounting)'),
  ('Lokad.Lython.PublicApi.Tests','Category!=Stress&(FullyQualifiedName~Fnmatch|FullyQualifiedName~FnMatch|FullyQualifiedName~GlobTranslation|FullyQualifiedName~GlobModuleFunction|FullyQualifiedName~RegexProviderContract)')]:
  log=r/(project+'-'+tfm+'.log');started=time.monotonic()
  with log.open('w',encoding='utf-8')as stream:
   done=subprocess.run([env['DOTNET_HOST_PATH'],'test',f'tests/{project}/{project}.csproj','-c','Release','-f',tfm,'--filter',selection,'--logger','console;verbosity=minimal'],env=env,stdout=stream,stderr=subprocess.STDOUT)
  tail=log.read_text(encoding='utf-8')[-2500:];checks[log.name]=dict(exitCode=done.returncode,selection=selection,elapsedSeconds=time.monotonic()-started,tail=tail)
  (r/'focused.json').write_text(json.dumps(checks,indent=2)+'\n',encoding='utf-8')
  print(log.name,tail.splitlines()[-1],flush=True)
  assert done.returncode==0,tail
cores={}
for tfm in ['net11.0','net10.0']:
 folder=r/'cores'/tfm;folder.mkdir(parents=True)
 core=Path(f'src/Lokad.Lython/bin/Release/{tfm}/Lokad.Lython.dll');shutil.copy2(core,folder/core.name)
 cores[tfm]=hashlib.sha256(core.read_bytes()).hexdigest()
sources={str(p):hashlib.sha256(p.read_bytes()).hexdigest()for p in Path('src/Lokad.Lython').rglob('*.cs')if not any(part in ['obj','bin']for part in p.parts)}
(r/'focused.json').write_text(json.dumps(dict(checks=checks,cores=cores,productionSources=sources),indent=2)+'\n',encoding='utf-8')
print('Both actual targets, semantic/provider/ownership/cancellation checks passed; source and cores frozen.',flush=True)
