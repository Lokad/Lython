from pathlib import Path
import hashlib,json,shutil,subprocess,tarfile
r=Path(__file__).parent
out=Path('benchmarks/results/2026-11-07-wildcard-translation');out.mkdir(exist_ok=True)
focused=json.loads((r/'focused.json').read_text(encoding='utf-8'))
for p,h in focused['productionSources'].items():assert hashlib.sha256(Path(p).read_bytes()).hexdigest()==h
source=r/'source-current';source.mkdir()
for p in [*Path('src/Lokad.Lython/Runtime').glob('LythonRuntime.*MatchModule.cs'),Path('src/Lokad.Lython/Runtime/LythonRuntime.GlobModule.cs'),Path('src/Lokad.Lython/Runtime/LythonRuntime.WildcardTranslation.cs'),Path('tests/Lokad.Lython.Tests/WildcardTranslationOwnershipTests.cs'),Path('tests/Lokad.Lython.PublicApi.Tests/FnMatchStreamingScenarioTests.cs'),Path('tests/Lokad.Lython.PublicApi.Tests/GlobTranslationScenarioTests.cs')]:shutil.copy2(p,source/p.name)
for name in ['focused.json','inflight.json','baseline.json','local-summary.json','refined-local-summary.json','portable-goldens.json']:shutil.copy2(r/name,out/name)
identity=dict(baselineRevision='4c739dcb / production80833f6e; R50 frozen refined core, precommit informational revision9990d591',candidateRevision='4c739dcb plus R51, exact source inventory/frozen cores in focused.json',driver=dict(path='integer-utf8-r45/tool/out/complete-jobs.dll',sha256=hashlib.sha256((r.parent/'integer-utf8-r45/tool/out/complete-jobs.dll').read_bytes()).hexdigest(),historicalInternalCaption='Driver retains its R45 label; supplied scripts/images define this R51 comparison.'),beforeCore=hashlib.sha256((r/'before-image/Lokad.Lython.dll').read_bytes()).hexdigest(),candidateCore=focused['cores'],worker=hashlib.sha256((r/'candidate-image/Lokad.Lython.Benchmarks.dll').read_bytes()).hexdigest(),sourceAndBinaryFrozen=True,fullDeliveryPending=True,elapsedQualification=False)
(out/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8')
archive=out/'development.tar.xz'
with tarfile.open(archive,'w:xz')as a:
 for p in sorted(r.rglob('*')):
  relative=p.relative_to(r)
  if not p.is_file()or relative.parts[0]in ['before-image','candidate-image','b406']:continue
  a.add(p,arcname=str(relative).replace('\\','/'))
 for name in ['Program.cs','complete-jobs.csproj','out/complete-jobs.dll','out/complete-jobs.runtimeconfig.json']:
  p=r.parent/'integer-utf8-r45/tool'/name
  if p.is_file():a.add(p,arcname='driver/'+name)
decision=dict(retained=True,sourceOutcome='One native UTF-8 path, no decoded input/segment strings/UTF-16 output or bracket builders. Existing governed storage admission/overlap/transfer; matching and provider contract unchanged.',allocationPercent=dict(fnmatchSync=-25.029,fnmatchAsync=-25.017,globSync=-31.797,globAsync=-31.809),elapsed='Desktop diagnostic/inconclusive: initial async glob+8%; refined sync fnmatch+0.59to+23.83 with23.1% identical-before drift; glob async-0.96to+7.09 with-7.51% drift. No CPU improvement claim. Bounded quiet source-pair confirmation remains planned.',checks='29internal/133public per actual.NET11/10, plus2 actual in-flight separator scans per target; all goldens, funded retained output, refusal/current cancellation/cleanup/reusable allowance pass.',failedConditions='Initial Windows CPython CRLF golden failed unchanged baseline before sampling; original catalog/error preserved. Explicit file newline and canonical stdout correct fixture, not runtime.',archiveSHA256=hashlib.sha256(archive.read_bytes()).hexdigest(),fullDelivery='Pending; R50 CI separately active, does not qualify R51.',publication='postponed')
(out/'decision.json').write_text(json.dumps(decision,indent=2)+'\n',encoding='utf-8')
print(json.dumps(dict(archiveBytes=archive.stat().st_size,archiveSHA256=decision['archiveSHA256'],productionSources=len(focused['productionSources']))))
