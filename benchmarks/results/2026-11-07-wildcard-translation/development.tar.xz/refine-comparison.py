from pathlib import Path
import hashlib,json,shutil
r=Path(__file__).parent
focused=json.loads((r/'focused.json').read_text(encoding='utf-8'))
for p,digest in focused['productionSources'].items(): assert hashlib.sha256(Path(p).read_bytes()).hexdigest()==digest
image=r/'candidate-image'
(image/'Lokad.Lython.dll').unlink();shutil.copy2(r/'cores/net11.0/Lokad.Lython.dll',image/'Lokad.Lython.dll')
s=(r/'measure.py').read_text(encoding='utf-8').replace("folder=r/(phase+'-'+api)","folder=r/('refined-'+phase+'-'+api)")
(r/'measure-refined.py').write_text(s,encoding='utf-8',newline='\n')
s=(r/'summarize.py').read_text(encoding='utf-8').replace("r/phase/'measurements.json'","r/('refined-'+phase)/'measurements.json'").replace("r/'local-summary.json'","r/'refined-local-summary.json'")
(r/'summarize-refined.py').write_text(s,encoding='utf-8',newline='\n')
