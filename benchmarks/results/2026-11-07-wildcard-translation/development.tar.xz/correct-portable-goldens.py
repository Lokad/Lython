from pathlib import Path
import base64,hashlib,json,shutil,struct,subprocess,tempfile
r=Path(__file__).parent
original=r/'initial-goldens';original.mkdir()
for name in ['catalog.json','goldens.json','fnmatch-script.py','glob-script.py']:
 shutil.copy2(r/name,original/name)
shutil.move(r/'warm-sync',original/'warm-sync')
catalog=json.loads((r/'catalog.json').read_text(encoding='utf-8'))
for item in catalog['cases'][:2]:
 source=item['source'].replace("open('report.txt','w')","open('report.txt','w',newline='\\n')")
 fixture=json.loads(item['fixtureJson'])
 with tempfile.TemporaryDirectory(prefix='lython-r51-portable-')as folder:
  root=Path(folder)
  for name,encoded in fixture['inputFiles'].items():(root/name).write_bytes(base64.b64decode(encoded))
  run=subprocess.run(['C:/Python313/python.exe','-I','-S','-X','utf8','-c',source],cwd=root,capture_output=True,timeout=20)
  assert run.returncode==0,run.stderr.decode()
  output=(root/'report.txt').read_bytes();assert b'\r\n'not in output
 fixture['outputFiles']['report.txt']=base64.b64encode(output).decode()
 h=hashlib.sha256();path=b'report.txt'
 for data in [struct.pack('>i',1),struct.pack('>i',len(path)),path,struct.pack('>i',len(output)),output]:h.update(data)
 item.update(source=source,sourceSha256=hashlib.sha256(source.encode()).hexdigest(),expectedOutput=run.stdout.decode().replace('\r\n','\n'),expectedOutputUtf8Bytes=len(run.stdout.decode().replace('\r\n','\n').encode()),expectedFilesSha256=h.hexdigest(),fixtureJson=json.dumps(fixture,ensure_ascii=False,separators=(',',':')))
 (r/(item['id'].split('.')[1].split('-')[0]+'-script.py')).write_text(source,encoding='utf-8',newline='\n')
(r/'catalog.json').write_text(json.dumps(catalog,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
(r/'portable-goldens.json').write_text(json.dumps(dict(correction='Initial Windows CPython stdout/file CRLF goldens failed on unchanged baseline before any samples. Original catalog/scripts/error preserved. Use explicit file newline and canonical stdout LF; no runtime/measurement protocol change.',cases=[dict(id=c['id'],sourceSha256=c['sourceSha256'],expectedOutput=c['expectedOutput'],expectedFilesSha256=c['expectedFilesSha256'])for c in catalog['cases'][:2]]),indent=2)+'\n',encoding='utf-8')
