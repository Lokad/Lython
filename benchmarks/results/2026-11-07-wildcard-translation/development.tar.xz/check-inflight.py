from pathlib import Path
import hashlib,json,os,subprocess
r=Path(__file__).parent
env=os.environ.copy();env['DOTNET_ROOT']='C:/Users/JoannesVermorel/.dotnet11';env['DOTNET_HOST_PATH']=env['DOTNET_ROOT']+'/dotnet.exe';env['PATH']=env['DOTNET_ROOT']+os.pathsep+env['PATH']
checks={}
for tfm in ['net11.0','net10.0']:
 log=r/('inflight-'+tfm+'.log')
 with log.open('w',encoding='utf-8')as stream:
  done=subprocess.run([env['DOTNET_HOST_PATH'],'test','tests/Lokad.Lython.Tests/Lokad.Lython.Tests.csproj','-c','Release','-f',tfm,'--filter','FullyQualifiedName~WildcardTranslationOwnershipTests.SeparatorScanning','--logger','console;verbosity=minimal'],env=env,stdout=stream,stderr=subprocess.STDOUT)
 tail=log.read_text(encoding='utf-8')[-2000:];checks[tfm]=dict(exitCode=done.returncode,tail=tail)
 (r/'inflight.json').write_text(json.dumps(checks,indent=2)+'\n',encoding='utf-8')
 print(tfm,tail.splitlines()[-1],flush=True)
 assert done.returncode==0,tail
 assert hashlib.sha256(Path(f'src/Lokad.Lython/bin/Release/{tfm}/Lokad.Lython.dll').read_bytes()).hexdigest()==json.loads((r/'focused.json').read_text(encoding='utf-8'))['cores'][tfm]
