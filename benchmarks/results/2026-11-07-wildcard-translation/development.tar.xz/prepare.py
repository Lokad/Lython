from pathlib import Path
import hashlib, json, shutil, subprocess
r = Path(__file__).parent
assert not (r / 'before').exists()
(r / 'before').mkdir()
paths = [Path('src/Lokad.Lython/Runtime/LythonRuntime.FnMatchModule.cs'), Path('src/Lokad.Lython/Runtime/LythonRuntime.GlobModule.cs')]
for p in paths:
    shutil.copy2(p, r / 'before' / p.name)
image = r.parent / 'integer-width-r50/images/refined'
assert image.is_dir()
shutil.copytree(image, r / 'before-image')
(r / 'baseline.json').write_text(json.dumps(dict(head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(), sources={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in paths}, images={str(p.relative_to(r/'before-image')):hashlib.sha256(p.read_bytes()).hexdigest() for p in (r/'before-image').rglob('*') if p.is_file()}),indent=2)+'\n',encoding='utf-8')
