from pathlib import Path
import json,shutil
r=Path(__file__).parent
folder=r/'attempt1';folder.mkdir()
for name in ['focused.json','cores']:
 shutil.move(r/name,folder/name)
for p in r.glob('Lokad.Lython.*.log'):shutil.move(p,folder/p.name)
for p in Path('src/Lokad.Lython/Runtime').glob('LythonRuntime.*Translation.cs'):shutil.copy2(p,folder/p.name)
(folder/'decision.json').write_text(json.dumps(dict(reason='Initial UTF-8 pipeline reduces complete-script allocation21-23%; async glob desktop+8% with nearly stable identical-before. New builder starts at8bytes and repeatedly admits/replaces capacity for each short pattern. Refine only initial capacity using input bytes plus modest output headroom; existing checked growth handles expansions. No timing/acceptance guarantee. Preserve original source, cores, focused checks, all clocks and failed CRLF golden conditions.',iterationBudget='One refined local confirmation; no automatic VM campaign or unchanged retiming.'),indent=2)+'\n',encoding='utf-8')
