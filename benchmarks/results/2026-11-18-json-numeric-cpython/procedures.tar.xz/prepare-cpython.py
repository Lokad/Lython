from pathlib import Path
import ast
import hashlib
import json
import shutil
import subprocess
import tarfile

lab = Path(__file__).resolve().parent
previous = lab.parent / 'bindings-cpython-r522'
old = previous / 'quiet'
donor = lab / 'quiet'
work = lab / 'cpython'
out = work / 'quiet'
out.mkdir(parents=True)
read = lambda file: file.read_text(encoding='utf-8')
sha = lambda file: hashlib.sha256(file.read_bytes()).hexdigest()


def write(path, value):
    if path.suffix == '.py':
        ast.parse(value)
    path.write_text(value, encoding='utf-8', newline='\n')


config = json.loads(read(donor / 'config.json'))
catalog = lab / 'representative.json'
catalog_hash = sha(catalog)
files = config['identity']['imageFiles']['candidate']
assert len(files) == 32 and files['Lokad.Lython.dll'].startswith('40db9318')
assert all(sha(lab / 'frozen/candidate' / name) == digest for name, digest in files.items())
assert config['identity']['catalogSHA256'] == catalog_hash
receipt = json.loads(read(lab / 'candidate-verification.json'))
assert receipt
shutil.copyfile(catalog, work / 'catalog.json')
shutil.copyfile(lab / 'candidate-verification.json', work / 'preflight.json')
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip()
assert head.startswith('55fe3da03'), head
identity = dict(
    sourceRevision='R534/40db9318 on dd4c5165c. The measured JSON change is retained in ' + head +
        '. This frozen image predates the merged R533 regex change.',
    purpose='Complete floating report phases and warm JSON integer aggregation versus stock CPython.',
    coreSHA256={role: files['Lokad.Lython.dll'] for role in ('candidate', 'candidate-control')},
    imageFiles={'candidate': files},
    auxiliaryFiles={name: digest for name, digest in files.items() if name != 'Lokad.Lython.dll'},
    catalogSHA256=catalog_hash, normalAdapterPin='0.4.0', publicationHeld=True)
write(out / 'identity.json', json.dumps(identity, indent=2) + '\n')

jobs = [('scripts.numeric-squared-error.floating.large', phase)
        for phase in ('compile', 'warm', 'compile-run')]
jobs.append(('scripts.json-summary-helpers.large', 'warm'))
source = read(old / 'collect.py')
start, end = source.index('\njobs=') + 1, source.index('\nenv =')
source = source[:start] + 'jobs=' + repr(jobs) + '\nassert len(jobs)==4 and all(case in cases for case,lane in jobs)\n' + source[end:]
source = source.replace('warmupSeconds=6, compilationWarmupSeconds=6', 'warmupSeconds=8, compilationWarmupSeconds=8')
source = source.replace('min(warmed)<6', 'min(warmed)<8').replace('warmed[i]>=6', 'warmed[i]>=8')
write(out / 'collect.py', source)
write(out / 'archive-owned.py', read(old / 'archive-owned.py').replace(
    "len(raw['jobs'])==6", "len(raw['jobs'])==4").replace('jobs=6,elapsedSeconds', 'jobs=4,elapsedSeconds'))

old_config = json.loads(read(old / 'config.json'))
remote = '/home/lokad/lython-bench-checks/json-numeric-cpython-b966-20261118'
unit = 'lython-b966-json-numeric-cpython-20261118'
write(out / 'run.sh', read(old / 'run.sh').replace(old_config['root'], remote))
assert b'\r' not in (out / 'run.sh').read_bytes()
members = ['collect.py', 'archive-owned.py', 'run.sh', 'identity.json']
with tarfile.open(out / 'payload.tgz', 'w:gz') as archive:
    for name in members:
        archive.add(out / name, arcname=name)
settings = dict(root=remote, unit=unit, source=config['root'], sourceRole='candidate',
                sourceFiles=files, sourceCatalogSHA256=catalog_hash, catalogSHA256=catalog_hash,
                identity=identity, retireGroups=[], payloadBytes=(out / 'payload.tgz').stat().st_size,
                payloadSHA256=sha(out / 'payload.tgz'), unpackedBytes=sum((out / name).stat().st_size for name in members))
write(out / 'config.json', json.dumps(settings, indent=2) + '\n')
source = read(old / 'remote-launch.py')
start, end = source.index('\nc=') + 1, source.index('\nb=Path(')
source = source[:start] + 'c=' + repr(settings) + source[end:]
source = source.replace('lython-b952-fixtures', 'lython-b966-fixtures')
source = source.replace('Same six-case catalog already passed actual frozen-image verification.',
                        'The unchanged catalog already passed actual frozen-image verification.')
write(out / 'remote-launch.py', source)
write(out / 'retrieve.py', read(old / 'retrieve.py').replace("['jobs']==6", "['jobs']==4").replace('B936', 'B966'))
write(work / 'launch.py', read(previous / 'launch.py').replace('seconds=280', 'seconds=225').replace(
    'Six-job complete-agent checkpoint source comparison', 'Four-job JSON CPython comparison').replace('before280seconds', 'before225seconds'))
write(work / 'summarize.py', read(previous / 'summarize.py').replace("len(raw['jobs'])==6", "len(raw['jobs'])==4"))
print('Four phases staged for the frozen image and stock CPython.')
