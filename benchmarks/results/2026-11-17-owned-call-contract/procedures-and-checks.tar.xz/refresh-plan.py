from pathlib import Path
Path('D:/code/Lython/PLAN.md').write_text('''# Lokad.Lython 0.11.0

Updated 2026-11-17 UTC. Git-ignored; never force-add. Publication/tagging held.
Objective: coherent simplification and substantial complete-script performance,
including newly generated scripts in a warm host. An isolated experiment does
not finish the objective. Current contracts: docs/. History: benchmarks/EXPERIMENTS.md.

## Actual delivery status

| State | Milestone and limits |
| --- | --- |
| Committed / fully qualified | Shared compiler-fact/callback correction61237f58 and native helper returns8f07764a. Allocation−19–20%; original elapsed gains remain diagnostic. No unchanged qualification pending. |
| Committed / fully qualified | Direct UTF-8 formatting/storage: allocation−8.67%; controlled report elapsed/CPU5–8%lower. Original adverse15.125ms remains preserved/unexplained; controlled evidence supports retaining the design. |
| Committed / fully qualified | Prepared binding/direct operands, executable generators, shared builtin metadata/reused async workers, UTF-8 backing/casing, sequence constructionR460, receiver pipelineccf20ba3, floating transportdc480d38, generator-sum lifetimeabcbd9fd, unary result transportd8611c85. |
| Latest fully qualified runtime | Bulk UTF-8 scalar/UTF16 widthsdbdf8262/frozena95ff2a4. GREEN44080812207: Windows/Ubuntu actual11/10, original stress and installed Release consumers;16summaries/2381inputs/585production verified. Later commits through9d9fd1e9 are evidence/docs only. |
| Committed / failed qualification | Copied-call attemptf2cb4008/frozen384327c2 failed44091209377 on both platforms: two existing retained-array regressions each. Focused coverage missed the owned ABI. Original source/diagnostic/failed logs preserved; not qualified. |
| Active correction / focused validated | R487/frozen6c808cd8: owned arrays charged until execution/result-owner cleanup; borrowed wide scratch reclaims after actual users. Removes completion wrapper. Final nonincremental build; actual11/10 each99internal/239public. Two frozen goldens/allocation reuse pass; affected quiet comparison running. Full corrected delivery pending. |
| Withdrawn / no dormant alternative | R469JSON scan,R470call operands,R473module metadata,R474subscript entry,R479global binding,R481caller windows,R485wider two-span binding view. Preserve independent regressions and all adverse evidence. |
| Independent regex development | Core Python/native UTF-8 contract delivered; immutabledev105 focused checks complete. Normal optional/non-packable adapter0.4.0. Missing producer capabilities postpone affected final adapter qualification only. |

[R483 delivery](benchmarks/results/2026-11-17-utf8-widths/refined/delivery/README.md),
[R486 failure](benchmarks/results/2026-11-17-call-copy-ownership/delivery-first-failure/README.md),
[milestone history](benchmarks/EXPERIMENTS.md).

## First: close the owned-call correction, without restarting an audit

Owned callable arrays may be retained after success, failure or cancellation.
Reserve capacity before allocation, commit to the existing execution/result owner,
and never clear/refund at call return. Constructors preserve their multi-stage
owned packet. Wide executable scratch uses the borrowed entry and stays funded
until actual asynchronous completion, then clears/refunds. Existing direct function
binding remains. Remove the incorrect completion wrapper/pending-owner flags and
small-copy headroom exception; no new callable classification or ownership layer.

Compatibility: conservative opaque-array retention can deny earlier within one
long execution. Owner cleanup restores allowance; bounded host executions remain
the streaming boundary. Do not pretend that arbitrary withdrawal is exact reclamation.
Preserve public API, Python aliases/metadata/order, pending users, managed stack,
cancellation and terminal first admission refusal.

Acceptance: existing retainability regressions unchanged; short/wide unbound/bound
copy admission before effects; retained arrays unchanged after return/cancellation;
funding through awaited cleanup and beyond return until owner disposal; reuse at
actual owner end. Final focused actual11/10 pass. Preserve preliminary checks that
overlapped compilation; only post-final-build checks qualify frozen source.

One short affected bound-wide warm/fresh pair plus complete JSON-lines control.
Separate allocation, retained peak, CPU and elapsed; earlier B903 describes the
incorrect source only. Preserve original pre-mutation disk-floor refusals and
repair custody without changing measurement conditions. Then one full corrected
Windows/Ubuntu actual11/10, original stress and installed Release-package boundary.
Do not repeat unchanged R483 checks or query terminal failed44091209377.

## Continue the substantial redesign roadmap

| Deliverable / representative scripts | Removed work/storage, acceptance and bounded decision |
| --- | --- |
| Complete call/frame and operand transport: numeric helpers, file search, reports | R484 attributes ordinary prefix141/call43 of986 samples, overlapping useful work. Ordinary helpers already borrow/defer frames, fused locals carry slots. R485 still created packet entries per read and its wider ABI did not earn its complexity. Next gate must identify a whole remaining stage to remove, including displaced binder/frame/transport code; preserve defaults/keywords/cells/identity/effect/fault order and actual suspension without replay. Bounded source attribution or one narrower capture may resolve a named stage; no replay of rejected arenas/controllers/windows. Name changed whole scripts and control before prototype. |
| Per-record construction: CSV/JSON aggregates, manifests | Earlier6–8%CSV direction is integrated as aggregate admission/shared keys/final rows; R482 confirms funded-row adoption. JSON already shares cross-load layouts/default options and uses iterative construction. A revised design must remove real storage/construction, not add a duplicate cache. Preserve duplicate/short/wide rows, hooks, aliases, replacement peaks and terminal refusal. One controlled whole-script pair before retention. |
| Scalar/text publication: normalization, numeric reports | R483 removes scalar-width walking; R471/R477 remove boxing boundaries. Mutable slots need canonical aliases under withdrawal/mutation and displace direct-array adoption; tuple borrowing is insufficient. Text reads already share immutable UTF-8 windows: do not propose a second line-window system. Select actual conversions/storage removed, preserve Unicode/arithmetic/hooks/cancellation/ownership, then bounded pair. No universal tagged-value/identity-ledger redesign based on allocation estimates alone. |
| Frontend/setup: generated configuration/helper scripts | Binding facts/prepared metadata already shared. Compilation is not the dominant gap in current representative measurements. Prove remaining repeated analysis/retention before consolidation, preserve spans/classes/cells/lazy annotations and compile-to-result admission/cancellation. Remove displaced passes/representation; no speculative heavyweight JIT. |

R484 source corrections: spans are shared references; default JSON conversion is
synchronous; layouts already persist across loads. R469 bulk delimiter scanning
regressed JSON fresh with close controls; merely retrying the same scanner adds
no new removed work. Structural-guard context is ThreadStatic, not AsyncLocal,
and checks are throttled; an assumed per-character full check is unproved.
[Attribution](benchmarks/results/2026-11-17-json-record-costs/README.md).

Every redesign records hypothesis, eliminated implementation, affected complete
scripts, semantic/cancellation/ownership acceptance, bounded before/after controls,
and a retention/regression-debt decision. Temporary setbacks are acceptable within
an explicit completion milestone. No isolated experiment closes performance.

## Measurement gaps and debt

CPython is primary; each row names measured source, never automatically HEAD.
R483 text: warm1.75–1.81×,fresh1.66–1.67×,compile0.94–0.96× versus3.13.16;
warm CPython controls3.40%. R477 numeric CSV: warm0.89–0.92×,fresh0.92–0.95×,
compile1.25–1.27×. R475 floating JSON: warm1.95–2.00×,fresh1.83–1.88×.
Refresh an affected external baseline at a retained coherent checkpoint, separating
compile/warm/fresh; state mediated I/O, output validation and prior-result cleanup.
Phase medians are not additive; cross-collection ratios are not causal gains.

Retain R471 integer regression, R460 tuple peak+11.81%/asyncCSV+0.1–3.6%,
R481 corrected helper/text regression and withdrawn R485 mixed results. R483 first
CountAny dense+28%elapsed/+23%CPU was removed; refined ASCII/dense reference
movement7.17/6.77% limits magnitude. [Guide/boundaries](docs/BENCHMARKS.md).

Moving unchanged controls, timeouts and inconclusive results establish uncertainty,
not failed designs. Allow bounded justified confirmation/refinement/measurement
repair; preserve original failed/adverse conditions. Distinguish architectural
simplification, allocation reduction and demonstrated CPU gain. Percentages inform
decisions and never automatically veto a useful coherent change.

## Independent regex track

Continue the core-owned Python UTF-8 contract: original-subject byte ranges/scalar
windows, flags/names/captures/effective frontend analysis, explicit owners and
current tokens through actual provider/import/helper work. No backend types or
dialect fallback in core. Development producers/adapter bridges permit development;
separate contract tests, semantics and backend performance.

Read-only siblingfe67e13f changes boundary literals/endpoints, not the missing
facade capabilities: UTF-8 group-name enumeration, creation/preparation token
lifetime independent of retained cursors, separately funded per-match staging.
Keep detached later-pull bridge; effective flags do not replace initial Verbose
parsing. No pin change/requalification for unrelated source changes. Qualify a
changed immutable final package for semantics/windows/errors/flags, actual in-flight
interruption/unwind, aliases/reuse/dependencies and one affected pair. Only that
affected final adapter qualification waits on publication.

## Delivery and lasting constraints

Focused Release checks while iterating; full platform/stress/installed-package at
retained boundaries. Cache terminal/logs; live CI observations≥240s apart. Never
requery terminal44080812207,44050323147,44041981387,44022750002,44072440304,
failed44067803913/44091209377. Publication/tagging held.

[AGENTS](AGENTS.md)/[RUNTIME](docs/RUNTIME.md) govern all work: fully managed and
memory-safe; no unsafe/Unsafe/pointers/PInvoke/native probing. Preserve managed
stack, host capabilities, cancellation, borrowed shared admission, replacement
overlap and retained aliases/caches/pending users through awaited cleanup. First
refusal terminal. No fuel/quotas/hidden caps/allowances/tracing/weak reclamation/
forced GC/abandoned work. Bounded host-driven streaming remains.

Freeze copied complete images after nonincremental builds; verify actual catalog
workers before VM staging. Join/SHA-archive RAM before unmount. Retire only exact
committed replicas with fresh lease/path/UID/hash/link/all-alias proof; preserve
current qualified images/toolchains/canonicals and254/252MiB floors. Quiet VM:
lokad@20.166.121.73,~/.ssh/id_lython-bench.pem. Only core Release packages through
pack.ps1 into artifacts/nuget/; adapter remains non-packable.
''',encoding='utf-8',newline='\n')
