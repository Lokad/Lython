from pathlib import Path
import hashlib,json,subprocess
r=Path(__file__).parent;q=r/'quiet';root=Path('D:/code/Lython')
items=json.loads((r/'fresh-archive-candidates.json').read_text(encoding='utf-8'));choice=None
for item in items:
 matches=[p for p in(root/'benchmarks/results').rglob('observations.tgz')if p.stat().st_size==item['bytes']and hashlib.sha256(p.read_bytes()).hexdigest()==item['sha256']]
 if len(matches)==1:choice=item;canonical=matches[0].relative_to(root).as_posix();break
assert choice is not None
blob=subprocess.check_output(['git','show','HEAD:'+canonical],cwd=root);assert blob==(root/canonical).read_bytes()
c=json.loads((q/'config.json').read_text(encoding='utf-8'))
for name in ['config.json','remote-launch.py','launch.log']:
 dest=q/('floor-second-'+name);assert not dest.exists();dest.write_bytes((q/name).read_bytes())
c['retireGroups'].append(dict(paths=[choice['path']],bytes=choice['bytes'],links=choice['links'],sha256=choice['sha256'],canonical=canonical,canonicalSHA256=hashlib.sha256(blob).hexdigest(),member='whole-archive',committedBlobVerified=True))
(q/'config.json').write_text(json.dumps(c,indent=2)+'\n',encoding='utf-8',newline='\n')
s=(q/'remote-launch.py').read_text(encoding='utf-8');a=s.index('c=');b=s.index('\nb=Path(',a);s=s[:a]+'c='+repr(c)+s[b:]
(q/'remote-launch.py').write_text(s,encoding='utf-8',newline='\n')
assert(q/'launch.log').read_bytes()==(q/'floor-second-launch.log').read_bytes();(q/'launch.log').unlink()
print('Fresh exact committed archive proof:',choice['path'],canonical,choice['bytes'],flush=True)
