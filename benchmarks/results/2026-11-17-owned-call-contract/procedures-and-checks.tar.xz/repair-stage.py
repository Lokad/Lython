from pathlib import Path
import hashlib,json,shutil,subprocess
r=Path(__file__).parent;root=Path('D:/code/Lython');q=r/'quiet'
canonical='benchmarks/results/2026-11-17-unary-result-transport/first-pair/observations.tgz'
blob=subprocess.check_output(['git','show','HEAD:'+canonical],cwd=root);assert blob==(root/canonical).read_bytes()
old=json.loads((r.parent/'unary-slot-results-r477/quiet/config.json').read_text(encoding='utf-8'))
prefix=Path(old['root']).name
c=json.loads((q/'config.json').read_text(encoding='utf-8'))
for name in ['config.json','remote-launch.py','launch.log']:shutil.copyfile(q/name,q/('floor-first-'+name))
c['retireGroups'].append(dict(paths=[prefix+'/observations.tgz'],bytes=len(blob),links=1,sha256=hashlib.sha256(blob).hexdigest(),canonical=canonical,canonicalSHA256=hashlib.sha256(blob).hexdigest(),member='whole-archive',committedBlobVerified=True,optional=True))
(q/'config.json').write_text(json.dumps(c,indent=2)+'\n',encoding='utf-8',newline='\n')
s=(q/'remote-launch.py').read_text(encoding='utf-8');a=s.index('c=');b=s.index('\nb=Path(',a);s=s[:a]+'c='+repr(c)+s[b:]
(q/'remote-launch.py').write_text(s,encoding='utf-8',newline='\n')
assert (q/'launch.log').read_bytes()==(q/'floor-first-launch.log').read_bytes()
(q/'launch.log').unlink()
print('Original pre-mutation disk-floor refusal preserved. One more exact committed archive replica may be retired after fresh on-VM proof; same candidate/catalog/protocol/clocks.')
