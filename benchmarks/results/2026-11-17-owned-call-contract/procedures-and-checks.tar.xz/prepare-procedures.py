from pathlib import Path
import ast,json,shutil
r=Path(__file__).parent;old=r.parent/'copied-call-ownership-r486'
# Preserve the preliminary run: it overlapped a nonincremental build, so final
# checks are repeated only after the final build and final source changes.
prior=r/'preliminary-checks';prior.mkdir(exist_ok=False)
for name in ['checks.json','internal-net11.0.log','internal-net10.0.log','public-net11.0.log','public-net10.0.log']:
 shutil.copyfile(r/name,prior/name)
(prior/'README.txt').write_text('Preliminary focused tests overlapped compilation and preceded the final helper cleanup. Not final-source qualification. Final checks run after build-final.log completes.\n',encoding='utf-8')
s=(old/'freeze.py').read_text(encoding='utf-8').replace('R486 copied general/bound argument storage admission and pending cleanup only; borrowed-view prototype removed; four-file change on9d9fd1e9','R487 owned callable arrays retained under existing execution/result owner; borrowed wide scratch reclaimed after actual completion; correction onf2cb4008')
(r/'freeze.py').write_text(s,encoding='utf-8',newline='\n')
s=(old/'prepare-quiet.py').read_text(encoding='utf-8').replace("old=notes/'borrowed-binding-r485'","old=notes/'copied-call-ownership-r486'")
s=s.replace('benchmarks/results/2026-11-17-borrowed-binding/candidate-core.dll.gz','benchmarks/results/2026-11-17-call-copy-ownership/candidate-core.dll.gz')
a=s.index('for canonical,prefix,members in [');b=s.index(']:\n blob=',a)
groups=[('benchmarks/results/2026-11-17-call-copy-ownership/observations.tgz','call-copy-ownership-b903-20261117',['confirmation/confirmation.json','whole-archive']),('benchmarks/results/2026-11-17-utf8-widths/refined/observations.tgz','utf8-widths-b899-20261117',['whole-archive']),('benchmarks/results/2026-11-17-utf8-widths/first/observations.tgz','utf8-widths-b898-20261117',['whole-archive'])]
s=s[:a]+'for canonical,prefix,members in '+repr(groups)+s[b+1:]
s=s.replace('member=member,committedBlobVerified=True))','member=member,committedBlobVerified=True,optional=True))')
s=s.replace('WithdrawnR485912735fe; currentqualifieda95 preserved','FailedR486384327c2; currentqualifieda95 preserved')
# Only change the new root, not the old B903 retirement paths.
s=s.replace("remote='/home/lokad/lython-bench-checks/call-copy-ownership-b903-20261117'","remote='/home/lokad/lython-bench-checks/owned-call-contract-b904-20261117'")
s=s.replace("unit='lython-b903-call-copy-ownership-20261117'","unit='lython-b904-owned-call-contract-20261117'")
s=s.replace("'lython-b902-fixtures','lython-b903-fixtures'","'lython-b903-fixtures','lython-b904-fixtures'")
s=s.replace('R486 call-copy funding','R487 owned callable contract').replace('Four-fileR486on9d9fd1e9','Four-fileR487onf2cb4008')
s=s.replace('Copied callable packet/prepended receiver capacity admitted until all pending users/cleanup finish. Independent4tests fail qualified baseline/pass fix. Wider view fully removed.','Owned callable copies retained under execution/result owner; actual borrowed wide scratch clears/refunds after completion. First R486 failure preserved. Existing retainability plus10 focused ownership cases.')
(r/'prepare-quiet.py').write_text(s,encoding='utf-8',newline='\n')
for p in [r/'freeze.py',r/'prepare-quiet.py']:ast.parse(p.read_text(encoding='utf-8'))
print('Final-source check/freeze/short-affected-comparison procedures prepared; no mutation of benchmark workers or source.')
