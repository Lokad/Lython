from pathlib import Path
import gzip,hashlib,json,shutil,tarfile
r=Path(__file__).parent;root=Path('D:/code/Lython');dest=root/'benchmarks/results/2026-11-17-owned-call-contract';dest.mkdir(exist_ok=False)
for name in ['candidate-sources.tar.xz','catalog.json','summary.json','allocation-summary.json']:
 shutil.copyfile(r/name,dest/name)
shutil.copyfile(r/'frozen/identity.json',dest/'identity.json')
for name in ['archive-receipt.json','terminal-status.json','observations.tgz']:
 shutil.copyfile(r/'quiet'/name,dest/name)
for role in ['reference','candidate']:
 (dest/(role+'-core.dll.gz')).write_bytes(gzip.compress((r/'frozen'/role/'Lokad.Lython.dll').read_bytes(),mtime=0))
with tarfile.open(dest/'procedures-and-checks.tar.xz','w:xz') as archive:
 for p in sorted(r.rglob('*')):
  if not p.is_file():continue
  n=p.relative_to(r)
  if n.parts[0]=='frozen' and n.as_posix()!='frozen/identity.json':continue
  if n.parts[0]=='delivery' or 'retrieved' in n.parts or n.name in ['payload.tgz','candidate-sources.tar.xz','observations.tgz']:continue
  archive.add(p,arcname=n.as_posix())
decision=dict(retain=True,source='Four production files onf2cb4008; frozen6c808cd8,585production/2382inputs',contract='Owned arrays may be retained after success/fault/cancellation; admit before allocation and keep funded under existing execution/result owner. Borrowed scratch reclaims only after actual users finish.',removed='Incorrect CompleteOwnedArguments async wrapper, pending-owner flags and temporary-reservation objects for retained copies; no new layer.',compatibility='Conservative capacity stays charged until execution/result owner ends, so long executions with opaque retained-capable calls can reject earlier. Bounded host-driven batches remain required.',focused='Final nonincremental build; actual Windows11/10 each99internal/239public; includes unchanged retainability tests and10copy ownership cases. Actual copied32file workers and CPython3.13.2 verify both goldens; allocation diagnostics restore owner baseline.',comparison='116.43s source pair onquietVM: affected warm+2.19..+3.38%,CPU+3.47..+6.73%; fresh+2.11..+4.40%,CPU-0.52..+4.49%. JSONcontrol effectivelyflat. Allocationflat; affected accountedpeak3079->298471B after1025calls, as explicit retained funding requires.',fullDeliveryPending=True,broaderPerformanceObjectiveComplete=False,publicationHeld=True)
(dest/'decision.json').write_text(json.dumps(decision,indent=2)+'\n',encoding='utf-8',newline='\n')
(dest/'README.md').write_text('''# Owned callable arrays and borrowed scratch

R487/B904,2026-11-17UTC. Corrects the
[failed first delivery](../2026-11-17-call-copy-ownership/delivery-first-failure/README.md).
Qualifieddbdf8262/frozena95ff2a4 versus four-file source onf2cb4008/frozen6c808cd8;
585production/2382build-test inputs. No public API change or wider argument view.

The owned callable ABI permits retaining a fresh array after return, failure or
cancellation. Reserve before allocation and keep its charge with the existing
execution/result owner. Never clear/refund at call return. Ordinary wide calls
instead use the borrowed entry, with scratch funded through actual completion;
constructors keep their multi-stage owned packet. Direct function binding stays.
The incorrect completion wrapper, pending-owner flags and temporary-reservation
objects for retained copies disappear. No new lifetime layer, classification
switch, tracing, retry, quota or abandoned background work.

Conservative retained-capable copies accumulate charges until owner cleanup,
even if a particular callable did not retain its array. This can deny earlier in
one long command. Bounded host executions remain the ownership boundary; exact
withdrawal recovery is not claimed. Borrowed storage still reclaims after use.

Final nonincremental Release build succeeds. Actual Windows11/10 each pass
99internal/239public focused cases, including the unchanged retained-array checks,
ten copy ownership cases, constructors/protocols, real suspension, cancellation,
terminal refusal and cleanup. A preliminary check overlapped compilation and is
preserved separately, not used as final qualification. Both actual copied32file
workers pass catalog goldens versus CPython3.13.2 and owner-reuse diagnostics.

| Complete workload / phase | Elapsed change | Wider CPU change | Reference/candidate control spread |
| --- | ---: | ---: | ---: |
| Bound-wide max diagnostic / warm | +2.19..+3.38% | +3.47..+6.73% | 0.85/0.31% |
| Same / compile and run | +2.11..+4.40% | -0.52..+4.49% | 0.88/1.35% |
| JSON-lines helper aggregation / warm control | -0.28..+0.09% | -1.96..+0.73% | 0.12/0.25% |

Affected1025bound calls allocate essentially the same bytes (−24B), while accounted
peak rises3079→298471B because retained copies now stay charged. JSONallocation
changes−118B and accountedpeak+64B. All owner baselines restore. Accept this required
funding/retention cost explicitly; no CPU improvement claim or unchanged campaign.
Ranges combine four independent process medians, not confidence intervals.

Quiet AzureF4as_v7/Ubuntu24.04.4/.NET11RC3, normalGC/tiering,3jobs116.43seconds.
Six-second rotated warmups/five samples/four processes. Mediated I/O, complete
goldens and prior-result cleanup included; compilation only fresh. Startup,
fixture reset/protocol and final cache teardown excluded; wider CPU includes
request work outside the guest clock. All quiet/golden/Closed/exit/join/archive
gates pass; RAM archived/SHAverified before unmount, terminal cached.

Original disk-floor refusals occurred before mutations/measurement and remain
preserved. Staging repair retired only exact committed replicas after fresh
path/UID/hash/link/all-alias and idle-lease proof, including the failed384core and
one historical archive replica. Qualifieda95/toolchains/canonicals and254/252MiB
floors remain. Full corrected platform/stress/installed-package delivery is pending.
Publication held; the broader performance objective remains active.

[Decision](decision.json),[sources](candidate-sources.tar.xz),[catalog](catalog.json),
[summary](summary.json),[allocation](allocation-summary.json),[raw](observations.tgz),
[identity](identity.json),[checks/procedures](procedures-and-checks.tar.xz).
''',encoding='utf-8',newline='\n')
p=root/'benchmarks/EXPERIMENTS.md';s=p.read_text(encoding='utf-8');s+='\nR486 first delivery44091209377 failed: both platforms caught two existing retained-array regressions. [Exact failed inputs/logs](results/2026-11-17-call-copy-ownership/delivery-first-failure/README.md). Frozen384327c2 timings do not qualify the corrected design.\n\nR487/B904 [owned callable contract](results/2026-11-17-owned-call-contract/README.md): retainable arrays stay charged to existing execution/result owner; actual borrowed wide scratch reclaims after completion. Incorrect completion wrapper/pending-owner flags removed. Final nonincrementalbuild; actual11/10each99internal/239public; original retainability and10ownership cases pass. Short116.43s pair: affectedwarm+2.19..+3.38%/CPU+3.47..+6.73%,fresh+2.11..+4.40%; JSONcontrolflat. Allocationflat, affected accountedpeak3079→298471B for1025calls. Explicit conservative retention/earlier-denial tradeoff accepted, no speedupclaim. Original stage-floor refusals preserved/repaired with exact committed-replica custody. Full corrected delivery next; publication held/broader roadmap active.\n';p.write_text(s,encoding='utf-8',newline='\n')
print('Corrected ownership, explicit retention cost, focused validation and failed conditions preserved. Full delivery pending.')
