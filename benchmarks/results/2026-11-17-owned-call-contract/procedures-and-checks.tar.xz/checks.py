from pathlib import Path
import json,os,subprocess,time
r=Path(__file__).parent;r.mkdir(exist_ok=True);root=Path('D:/code/Lython')
dotnet=Path('C:/Users/JoannesVermorel/.dotnet11/dotnet.exe');env=os.environ.copy();env.update(DOTNET_ROOT=str(dotnet.parent),DOTNET_ROOT_X64=str(dotnet.parent));env['PATH']=str(dotnet.parent)+os.pathsep+env['PATH']
groups={
'internal':('tests/Lokad.Lython.Tests/Lokad.Lython.Tests.csproj','CallablePacketOwnershipTests|BoundMethodInvocationBoundaryTests|OrdinaryFunctionTransportTests|CallArgumentEvaluationTests|CallBindingSubsystemTests|ExpandedCallExecutableTests|ConstructorOwnershipTests|CompletedHelperCallOwnershipTests'),
'public':('tests/Lokad.Lython.PublicApi.Tests/Lokad.Lython.PublicApi.Tests.csproj','CallInputLifetimeTests|CallArgumentEvaluationTests|CallableInstanceProtocolTests|ConstructorSemanticsTests|ConstructorLifetimeTests|PreparedCallArgumentTests|OrdinaryFunctionCallTests|OrdinaryMethodCallTests|PositionalCallSemanticsTests|NativeCallbackArgumentsTests|NativeCallbackUnwindTests|AsyncInvocationOwnershipTests|WrapperOwnershipLifetimeTests|RepeatedExecutableCallTests|BuiltinCallbackLifetimeTests|NativeGeneratorSumTests|RepresentativeProtocolCancellationTests|SharedMemoryBudgetTests|TerminalMemoryAdmissionTests|CompiledFunctionContinuationTests|OrderedFunctionContinuationTests|DataclassCallbackContractTests')}
results=[]
for framework in ['net11.0','net10.0']:
 for name,(project,classes) in groups.items():
  filt='('+'|'.join('FullyQualifiedName~'+c for c in classes.split('|'))+')&Category!=Stress'
  command=[str(dotnet),'test',project,'-c','Release','-f',framework,'--no-build','--filter',filt,'--logger','console;verbosity=minimal']
  start=time.monotonic()
  with(r/(name+'-'+framework+'.log')).open('w',encoding='utf-8')as log:p=subprocess.run(command,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
  record=dict(framework=framework,group=name,command=command,exitCode=p.returncode,seconds=time.monotonic()-start);results.append(record)
  (r/'checks.json').write_text(json.dumps(results,indent=2)+'\n',encoding='utf-8',newline='\n')
  text=(r/(name+'-'+framework+'.log')).read_text(encoding='utf-8');print(framework,name,text.splitlines()[-1],flush=True)
  assert p.returncode==0,text[-6000:]
