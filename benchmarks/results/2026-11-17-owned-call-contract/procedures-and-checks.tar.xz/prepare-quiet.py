from pathlib import Path
import ast,gzip,hashlib,io,json,shutil,subprocess,tarfile
r=Path(__file__).parent;notes=r.parent;repo=Path('D:/code/Lython');q=r/'quiet';q.mkdir(exist_ok=False);old=notes/'copied-call-ownership-r486'
f=json.loads((r/'frozen/identity.json').read_text(encoding='utf-8'));prior=json.loads((old/'quiet/config.json').read_text(encoding='utf-8'))
canonical='benchmarks/results/2026-11-17-call-copy-ownership/candidate-core.dll.gz';blob=subprocess.check_output(['git','show','HEAD:'+canonical],cwd=repo);assert blob==(repo/canonical).read_bytes();data=gzip.decompress(blob);sha=hashlib.sha256(data).hexdigest()
s=(notes/'instruction-global-slots-r479/inspect-retirement.py').read_text(encoding='utf-8');a=s.index("code='''");b=s.index('ssh=');scope={'sha':sha};exec(s[a:b],scope)
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
p=subprocess.run(ssh+['python3 -'],input=scope['code'],text=True,encoding='utf-8',capture_output=True,timeout=60);assert p.returncode==0,p.stdout+p.stderr;selected=json.loads(p.stdout);assert selected['bytes']==len(data)
groups=[selected|dict(canonical=canonical,canonicalSHA256=hashlib.sha256(blob).hexdigest(),member='gzip-payload',committedBlobVerified=True,supersededQualifiedSource='FailedR486384327c2; currentqualifieda95 preserved')]
for canonical,prefix,members in [('benchmarks/results/2026-11-17-call-copy-ownership/observations.tgz', 'call-copy-ownership-b903-20261117', ['confirmation/confirmation.json', 'whole-archive']), ('benchmarks/results/2026-11-17-utf8-widths/refined/observations.tgz', 'utf8-widths-b899-20261117', ['whole-archive']), ('benchmarks/results/2026-11-17-utf8-widths/first/observations.tgz', 'utf8-widths-b898-20261117', ['whole-archive'])]:
 blob=subprocess.check_output(['git','show','HEAD:'+canonical],cwd=repo);assert blob==(repo/canonical).read_bytes()
 for member in members:
  data=blob
  if member!='whole-archive':
   with tarfile.open(fileobj=io.BytesIO(blob))as a:data=a.extractfile(member).read()
  groups.append(dict(paths=[prefix+'/'+('observations.tgz'if member=='whole-archive'else member)],bytes=len(data),links=1,sha256=hashlib.sha256(data).hexdigest(),canonical=canonical,canonicalSHA256=hashlib.sha256(blob).hexdigest(),member=member,committedBlobVerified=True,optional=True))
remote='/home/lokad/lython-bench-checks/owned-call-contract-b904-20261117';reference=f['imageFiles']['reference']['Lokad.Lython.dll'];candidate=f['imageFiles']['candidate']['Lokad.Lython.dll']
identity=dict(sourceRevision='Qualifieddbdf8262/frozena95ff2a4 versus four-fileR486on9d9fd1e9/frozen'+candidate,purpose='Owned callable copies retained under execution/result owner; actual borrowed wide scratch clears/refunds after completion. First R486 failure preserved. Existing retainability plus10 focused ownership cases. One short affected bound-wide diagnostic warm/fresh plus JSON-lines control; correctness required, no speedup forecast.',coreSHA256={'reference':reference,'reference-control':reference,'candidate':candidate,'candidate-control':candidate},imageFiles=f['imageFiles'],auxiliaryFiles={n:h for n,h in f['imageFiles']['reference'].items()if n!='Lokad.Lython.dll'},sourceInputsArchiveSHA256=hashlib.sha256((r/'candidate-sources.tar.xz').read_bytes()).hexdigest(),productionFiles=585,catalogSHA256=f['catalogSHA256'],normalAdapterPin='0.4.0',publicationHeld=True)
(q/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8')
s=(old/'quiet/collect.py').read_text(encoding='utf-8');a=s.index('jobs=');b=s.index('\nenv =',a);jobs=[['calls.bound-wide.cleanup','warm'],['calls.bound-wide.cleanup','compile-run'],['scripts.json-summary-helpers.large','warm']];s=s[:a]+'jobs='+repr(jobs)+'\nassert len(jobs)==3 and all(case in cases for case,lane in jobs)\n'+s[b:];s=s.replace('R485 borrowed binding','R487 owned callable contract').replace("< 250, 'Reserve60seconds","< 130, 'Reserve50seconds");(q/'collect.py').write_text(s,encoding='utf-8',newline='\n')
s=(old/'quiet/archive-owned.py').read_text(encoding='utf-8').replace("len(raw['jobs'])==6","len(raw['jobs'])==3").replace('jobs=6','jobs=3');(q/'archive-owned.py').write_text(s,encoding='utf-8',newline='\n')
(q/'run.sh').write_text((old/'quiet/run.sh').read_text(encoding='utf-8').replace(prior['root'],remote),encoding='utf-8',newline='\n')
(q/'candidate').mkdir();shutil.copyfile(r/'frozen/candidate/Lokad.Lython.dll',q/'candidate/Lokad.Lython.dll');shutil.copyfile(r/'catalog.json',q/'representative.json')
names=['collect.py','archive-owned.py','run.sh','identity.json','representative.json','candidate/Lokad.Lython.dll']
with tarfile.open(q/'payload.tgz','w:gz')as a:
 for n in names:a.add(q/n,arcname=n)
c=dict(root=remote,unit='lython-b904-owned-call-contract-20261117',source=prior['root'],sourceRole='reference',sourceFiles=f['imageFiles']['reference'],sourceCatalogSHA256=prior['catalogSHA256'],catalogSHA256=f['catalogSHA256'],identity=identity,retireGroups=groups,payloadBytes=(q/'payload.tgz').stat().st_size,payloadSHA256=hashlib.sha256((q/'payload.tgz').read_bytes()).hexdigest(),unpackedBytes=sum((q/n).stat().st_size for n in names));(q/'config.json').write_text(json.dumps(c,indent=2)+'\n',encoding='utf-8')
s=(old/'quiet/remote-launch.py').read_text(encoding='utf-8');a=s.index('c=');b=s.index('\nb=Path(',a);s=s[:a]+'c='+repr(c)+s[b:];s=s.replace('lython-b903-fixtures','lython-b904-fixtures').replace('RuntimeMaxSec=300','RuntimeMaxSec=180');(q/'remote-launch.py').write_text(s,encoding='utf-8',newline='\n')
(r/'launch.py').write_text((old/'launch.py').read_text(encoding='utf-8').replace('seconds=260','seconds=140').replace('before260seconds','before140seconds').replace('Six-job borrowed argument binding','Three-job copied-call ownership'),encoding='utf-8',newline='\n')
s=(old/'quiet/retrieve.py').read_text(encoding='utf-8').replace("['jobs']==6","['jobs']==3").replace('B902','B903');(q/'retrieve.py').write_text(s,encoding='utf-8',newline='\n')
s=(old/'summarize.py').read_text(encoding='utf-8').replace("len(raw['jobs'])==6","len(raw['jobs'])==3");(r/'summarize.py').write_text(s,encoding='utf-8',newline='\n')
for p in list(q.glob('*.py'))+[r/'launch.py',r/'summarize.py']:ast.parse(p.read_text(encoding='utf-8'))
print('Three-job final funding-only source pair prepared; copied2case image goldens passed; currentqualifieda95 preserved.')

