Preliminary focused tests overlapped compilation and preceded the final helper cleanup. Not final-source qualification. Final checks run after build-final.log completes.
