namespace Lokad.Lython.Frontend;

internal sealed partial class Parser
{
    private const string UnsupportedNamedUnicodeEscapeMessage =
        "Unsupported named Unicode escape '\\N{...}'; use a Unicode character or numeric '\\u'/'\\U' escapes instead.";
    private const string UnsupportedSurrogateStringMessage =
        "Unsupported surrogate code point in string literal; Lython strings contain Unicode scalar values.";

    private static string StringLiteralDiagnosticCode(string message)
        => message is UnsupportedNamedUnicodeEscapeMessage or UnsupportedSurrogateStringMessage ? "LA2000"
            : message == SyntaxNestingLimitMessage ? "LA0003"
            : "LA1007";

    private bool TryDecodeStringLiteral(ReadOnlySpan<char> literal, [MaybeNullWhen(false)] out string value, out string message)
        => TryDecodeStringLiteral(literal, out value, out message, true);

    private bool TryDecodeStringLiteral(
        ReadOnlySpan<char> literal,
        [MaybeNullWhen(false)] out string value,
        out string message,
        bool decodeUnicodeEscapes)
    {
        CheckCancellation();
        value = string.Empty;
        message = "Invalid string literal. Malformed literal body.";

        if (literal.Length < 2)
        {
            return false;
        }

        var index = 0;
        var isRaw = false;
        if (literal[0] is 'r' or 'R')
        {
            isRaw = true;
            index = 1;
        }

        if (index >= literal.Length)
        {
            return false;
        }

        var quote = literal[index];
        var isTriple = index + 2 < literal.Length &&
            literal[index + 1] == quote &&
            literal[index + 2] == quote;
        var prefixLength = isTriple ? 3 : 1;
        var start = index + prefixLength;
        var end = literal.Length - prefixLength;

        if ((quote != '"' && quote != '\'') || end < start)
        {
            return false;
        }

        if (!isTriple && literal[^1] != quote)
        {
            return false;
        }

        if (isTriple &&
            (literal[^1] != quote || literal[^2] != quote || literal[^3] != quote))
        {
            return false;
        }

        return TryDecodeStringBody(literal[start..end], isRaw, out value, out message, decodeUnicodeEscapes);
    }

    private bool TryDecodeStringBody(ReadOnlySpan<char> literal, bool isRaw,
        [MaybeNullWhen(false)] out string value, out string message, bool decodeUnicodeEscapes = true)
    {
        CheckCancellation();
        value = string.Empty;
        var start = 0;
        var end = literal.Length;
        // Borrow the token body until its one AST value is materialized. Only
        // actual escape decoding needs mutable output storage.
        if (isRaw || literal.IndexOf('\\') < 0)
        {
            if (!ValidateScalarString(literal, out message)) return false;
            value = literal.ToString();
            return true;
        }

        message = "Invalid string literal. Malformed literal body.";
        var builder = new System.Text.StringBuilder(end - start);
        for (var i = start; i < end; i++)
        {
            CheckCancellation(i - start);
            var c = literal[i];
            if (c != '\\')
            {
                builder.Append(c);
                continue;
            }

            if (i + 1 >= end)
            {
                message = "Invalid string literal. Unfinished escape sequence.";
                return false;
            }

            i++;
            switch (literal[i])
            {
                case '\n':
                    // An escaped physical newline contributes no character.
                    break;
                case '\\':
                    builder.Append('\\');
                    break;
                case '\'':
                    builder.Append('\'');
                    break;
                case '"':
                    builder.Append('"');
                    break;
                case 'n':
                    builder.Append('\n');
                    break;
                case 'a':
                    builder.Append('\a');
                    break;
                case 'b':
                    builder.Append('\b');
                    break;
                case 'f':
                    builder.Append('\f');
                    break;
                case 'r':
                    builder.Append('\r');
                    break;
                case 't':
                    builder.Append('\t');
                    break;
                case 'v':
                    builder.Append('\v');
                    break;
                case 'x':
                    if (i + 2 >= end ||
                        !byte.TryParse(literal.Slice(i + 1, 2), System.Globalization.NumberStyles.HexNumber, null, out var hex))
                    {
                        message = "Invalid string literal. Malformed \\x escape; expected two hexadecimal digits.";
                        return false;
                    }

                    builder.Append((char)hex);
                    i += 2;
                    break;
                case 'N' when decodeUnicodeEscapes:
                    message = UnsupportedNamedUnicodeEscapeMessage;
                    return false;
                case 'u' when decodeUnicodeEscapes:
                    if (!TryReadHexCodePoint(literal, i + 1, 4, end, out var shortCodePoint))
                    {
                        message = "Invalid string literal. Malformed \\u escape; expected four hexadecimal digits.";
                        return false;
                    }

                    if (shortCodePoint is >= 0xD800 and <= 0xDFFF)
                    {
                        message = UnsupportedSurrogateStringMessage;
                        return false;
                    }
                    builder.Append((char)shortCodePoint);
                    i += 4;
                    break;
                case 'U' when decodeUnicodeEscapes:
                    if (!TryReadHexCodePoint(literal, i + 1, 8, end, out var longCodePoint) ||
                        (uint)longCodePoint > 0x10FFFF)
                    {
                        message = "Invalid string literal. Malformed \\U escape; expected eight hexadecimal digits naming a Unicode code point.";
                        return false;
                    }

                    if (longCodePoint is >= 0xD800 and <= 0xDFFF)
                    {
                        message = UnsupportedSurrogateStringMessage;
                        return false;
                    }
                    if (longCodePoint <= char.MaxValue)
                    {
                        builder.Append((char)longCodePoint);
                    }
                    else
                    {
                        builder.Append(char.ConvertFromUtf32(longCodePoint));
                    }

                    i += 8;
                    break;
                default:
                    if (literal[i] is >= '0' and <= '7')
                    {
                        var octal = literal[i] - '0';
                        var digits = 1;
                        while (digits < 3 && i + 1 < end && literal[i + 1] is >= '0' and <= '7')
                        {
                            i++;
                            digits++;
                            octal = (octal * 8) + literal[i] - '0';
                        }

                        builder.Append((char)octal);
                    }
                    else
                    {
                        // Python preserves unknown escape sequences rather than silently
                        // dropping the backslash; diagnostics for those escapes are not fatal.
                        builder.Append('\\');
                        builder.Append(literal[i]);
                    }
                    break;
            }
        }

        value = builder.ToString();
        return ValidateScalarString(value, out message);
    }

    private bool ValidateScalarString(ReadOnlySpan<char> text, out string message)
    {
        for (var i = 0; i < text.Length; i++)
        {
            CheckCancellation(i);
            if (!char.IsSurrogate(text[i])) continue;
            if (char.IsHighSurrogate(text[i]) && i + 1 < text.Length && char.IsLowSurrogate(text[i + 1]))
            {
                i++;
                continue;
            }
            message = UnsupportedSurrogateStringMessage;
            return false;
        }
        message = string.Empty;
        return true;
    }

    private static bool TryReadHexCodePoint(
        ReadOnlySpan<char> literal,
        int start,
        int length,
        int end,
        out int codePoint)
    {
        codePoint = 0;
        if (start + length > end)
        {
            return false;
        }

        for (var i = start; i < start + length; i++)
        {
            var digit = literal[i] switch
            {
                >= '0' and <= '9' => literal[i] - '0',
                >= 'a' and <= 'f' => literal[i] - 'a' + 10,
                >= 'A' and <= 'F' => literal[i] - 'A' + 10,
                _ => -1
            };
            if (digit < 0)
            {
                return false;
            }

            codePoint = (codePoint * 16) + digit;
        }

        return true;
    }

    private static bool TryGetUnsupportedStringPrefix(string text, out string construct)
    {
        if (text.Length is > 0 and <= 3)
        {
            for (var i = 0; i < text.Length; i++)
            {
                if (text[i] is not ('r' or 'R' or 'b' or 'B' or 'f' or 'F' or 'u' or 'U'))
                {
                    construct = string.Empty;
                    return false;
                }
            }

            construct = text;
            return true;
        }

        construct = string.Empty;
        return false;
    }


    private static bool IsBytesStringPrefix(string text)
    {
        return text is "b" or "B" or "br" or "Br" or "bR" or "BR" or "rb" or "rB" or "Rb" or "RB";
    }

    private static bool IsFormattedStringPrefix(string text)
    {
        return text is "f" or "F" or "fr" or "Fr" or "fR" or "FR" or "rf" or "rF" or "Rf" or "RF";
    }

    private bool TryDecodeBytesLiteral(string literal, out byte[] value, out string message, bool isRaw = false)
    {
        CheckCancellation();
        value = Array.Empty<byte>();
        if (!TryExtractStringContent(literal, out var content))
        {
            message = "Invalid string literal. Malformed bytes literal body.";
            return false;
        }

        for (var i = 0; i < content.Length; i++)
        {
            CheckCancellation(i);
            if (content[i] > 0x7F)
            {
                message = "Invalid string literal. Bytes literals can only contain ASCII source characters.";
                return false;
            }
        }

        var decoded = content;
        message = string.Empty;
        if (!isRaw && !TryDecodeStringLiteral(literal, out decoded, out message, decodeUnicodeEscapes: false))
        {
            return false;
        }

        value = new byte[decoded.Length];
        for (var i = 0; i < decoded.Length; i++)
        {
            CheckCancellation(i);
            value[i] = (byte)decoded[i];
        }

        return true;
    }

    private static bool TryExtractStringContent(string literal, out string content)
    {
        content = string.Empty;
        if (literal.Length < 2)
        {
            return false;
        }

        if ((literal.StartsWith("\"\"\"", StringComparison.Ordinal) && literal.EndsWith("\"\"\"", StringComparison.Ordinal)) ||
            (literal.StartsWith("'''", StringComparison.Ordinal) && literal.EndsWith("'''", StringComparison.Ordinal)))
        {
            content = literal[3..^3];
            return true;
        }

        if ((literal[0] == '"' && literal[^1] == '"') || (literal[0] == '\'' && literal[^1] == '\''))
        {
            content = literal[1..^1];
            return true;
        }

        return false;
    }

    private bool TryDecodeEscapedText(string text, bool isRaw, [MaybeNullWhen(false)] out string value, out string message)
    {
        if (isRaw)
        {
            value = text;
            return ValidateScalarString(value, out message);
        }

        // A parsed f-string text segment already is a body, not another token.
        return TryDecodeStringBody(text, isRaw: false, out value, out message);
    }

}
