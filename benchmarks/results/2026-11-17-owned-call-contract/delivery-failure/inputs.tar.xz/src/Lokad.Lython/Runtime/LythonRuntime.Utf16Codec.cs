using System.Buffers;
using System.Runtime.InteropServices;
using System.Text;
using Lokad.Lython.Runtime.Text;

namespace Lokad.Lython.Runtime;

internal sealed partial class LythonRuntime
{
    private static bool IsUtf16Encoding(TextEncodingMode encoding)
        => encoding is TextEncodingMode.Utf16 or TextEncodingMode.Utf16LittleEndian or TextEncodingMode.Utf16BigEndian;

    private static ushort ReadUtf16Unit(ReadOnlySpan<byte> bytes, bool bigEndian)
        => bigEndian ? (ushort)((bytes[0] << 8) | bytes[1]) : (ushort)(bytes[0] | (bytes[1] << 8));

    // Whole byte codecs allow native-order data without a BOM. Text streams
    // require a BOM once a full unit exists, including when errors are ignored.
    private static TextEncodingMode ResolveUtf16ByteOrder(ref ReadOnlySpan<byte> source,
        TextEncodingMode encoding, bool stream, MemoryGovernor governor, ExecutionState? guards, LythonSourceSpan? span)
    {
        if (encoding != TextEncodingMode.Utf16) return encoding;
        if (source.Length >= 2)
        {
            if (source[0] == 0xff && source[1] == 0xfe)
            {
                source = source[2..];
                return TextEncodingMode.Utf16LittleEndian;
            }
            if (source[0] == 0xfe && source[1] == 0xff)
            {
                source = source[2..];
                return TextEncodingMode.Utf16BigEndian;
            }
            if (stream) throw DecodeError(source, "utf-16", 0, 2, "Stream does not start with BOM", governor, span, guards);
        }
        // Lython's sys.byteorder is little on every host.
        return TextEncodingMode.Utf16LittleEndian;
    }

    internal static PyString DecodeUtf16Text(ReadOnlySpan<byte> source, TextEncodingMode encoding,
        ExecutionContext context, LythonSourceSpan? span, TextErrorMode errors,
        TextNewlineMode newline, bool stream = false)
        => DecodeUtf16Text(source, encoding, context.State, span, errors, newline, stream);

    internal static PyString DecodeUtf16Text(ReadOnlySpan<byte> source, TextEncodingMode encoding,
        ExecutionState context, LythonSourceSpan? span, TextErrorMode errors,
        TextNewlineMode newline, bool stream = false)
    {
        var originalSource = source;
        var originalLength = source.Length;
        encoding = ResolveUtf16ByteOrder(ref source, encoding, stream, context.MemoryGovernor, context, span);
        var errorOffset = originalLength - source.Length;
        var bigEndian = encoding == TextEncodingMode.Utf16BigEndian;
        long length = 0;
        var work = 0;
        for (var index = 0; index < source.Length;)
        {
            if ((work++ & 1023) == 0) context.CheckExecution(span);
            if (TryDecodeUtf16Scalar(source[index..], bigEndian, out var scalar, out var consumed, out var reason))
            {
                length += new Rune(scalar).Utf8SequenceLength;
                if (scalar == '\r' && newline == TextNewlineMode.TranslateUniversal &&
                    index + consumed + 1 < source.Length && ReadUtf16Unit(source[(index + consumed)..], bigEndian) == '\n')
                    consumed += 2;
            }
            else
            {
                length += errors switch
                {
                    TextErrorMode.Ignore => 0,
                    TextErrorMode.Replace => 3,
                    TextErrorMode.BackslashReplace => 4L * consumed,
                    _ => throw DecodeError(originalSource, bigEndian ? "utf-16-be" : "utf-16-le", index + errorOffset, index + errorOffset + consumed, reason, context.MemoryGovernor, span, context),
                };
            }
            index += consumed;
        }
        if (length == 0) return PyString.Empty;
        using var storage = context.MemoryGovernor.ReserveTemporary(PyString.EstimateApproximateBytes(0) + length, span);
        if (length > int.MaxValue) throw RuntimeErrors.Runtime("UTF-16 decoded text exceeds the supported buffer size", span);
        var bytes = new byte[(int)length];
        var offset = 0;
        work = 0;
        const string hex = "0123456789abcdef";
        for (var index = 0; index < source.Length;)
        {
            if ((work++ & 1023) == 0) context.CheckExecution(span);
            if (TryDecodeUtf16Scalar(source[index..], bigEndian, out var scalar, out var consumed, out _))
            {
                if (scalar == '\r' && newline == TextNewlineMode.TranslateUniversal)
                {
                    scalar = '\n';
                    if (index + consumed + 1 < source.Length && ReadUtf16Unit(source[(index + consumed)..], bigEndian) == '\n')
                        consumed += 2;
                }
                offset += new Rune(scalar).EncodeToUtf8(bytes.AsSpan(offset));
            }
            else if (errors == TextErrorMode.Replace)
            {
                bytes[offset++] = 0xef; bytes[offset++] = 0xbf; bytes[offset++] = 0xbd;
            }
            else if (errors == TextErrorMode.BackslashReplace)
            {
                foreach (var value in source.Slice(index, consumed))
                {
                    bytes[offset++] = (byte)'\\'; bytes[offset++] = (byte)'x';
                    bytes[offset++] = (byte)hex[value >> 4]; bytes[offset++] = (byte)hex[value & 15];
                }
            }
            index += consumed;
        }
        return PyString.FromOwnedUtf8(bytes, context.MemoryGovernor, span, storage);
    }

    private static bool TryDecodeUtf16Scalar(ReadOnlySpan<byte> source, bool bigEndian,
        out int scalar, out int consumed, out string reason)
    {
        scalar = 0;
        consumed = Math.Min(2, source.Length);
        reason = "truncated data";
        if (source.Length < 2) return false;
        var first = ReadUtf16Unit(source, bigEndian);
        if (first is >= 0xdc00 and <= 0xdfff)
        {
            reason = "illegal encoding";
            return false;
        }
        if (first is < 0xd800 or > 0xdbff)
        {
            scalar = first;
            return true;
        }
        if (source.Length < 4)
        {
            consumed = source.Length;
            reason = "unexpected end of data";
            return false;
        }
        var second = ReadUtf16Unit(source[2..], bigEndian);
        if (second is < 0xdc00 or > 0xdfff)
        {
            reason = "illegal UTF-16 surrogate";
            return false;
        }
        scalar = 0x10000 + ((first - 0xd800) << 10) + second - 0xdc00;
        consumed = 4;
        return true;
    }

    private static void WriteUtf16Text(ReadOnlySpan<byte> source, Span<byte> destination, TextEncodingMode encoding,
        TextNewlineMode newline, ExecutionState context, LythonSourceSpan? span)
    {
        var offset = 0;
        var bigEndian = encoding == TextEncodingMode.Utf16BigEndian;
        if (encoding == TextEncodingMode.Utf16) PutUtf16Unit(destination, ref offset, bigEndian, 0xfeff);
        var translateNewlines = newline is TextNewlineMode.PreserveCarriageReturn or TextNewlineMode.PreserveCarriageReturnLineFeed;
        for (var index = 0; index < source.Length;)
        {
            context.CheckExecution(span);
            var end = index + Math.Min(1024, source.Length - index);
            while (end < source.Length && (source[end] & 0xc0) == 0x80) end--;
            if (translateNewlines)
            {
                var lineFeed = source[index..end].IndexOf((byte)'\n');
                if (lineFeed >= 0) end = index + lineFeed;
            }
            if (end != index)
            {
                // The destination already owns its exact UTF16 capacity. This
                // managed span view creates no intermediate character storage.
                var status = System.Text.Unicode.Utf8.ToUtf16(source[index..end],
                    MemoryMarshal.Cast<byte, char>(destination[offset..]), out var consumed, out var written,
                    replaceInvalidSequences: false);
                if (status != OperationStatus.Done || consumed != end - index)
                    throw new InvalidOperationException("UTF16 output received invalid or incorrectly sized UTF8 storage.");
                var byteCount = checked(2 * written);
                if (BitConverter.IsLittleEndian == bigEndian)
                    for (var position = offset; position < offset + byteCount; position += 2)
                        (destination[position], destination[position + 1]) = (destination[position + 1], destination[position]);
                offset += byteCount;
            }
            index = end;
            if (translateNewlines && index < source.Length && source[index] == (byte)'\n')
            {
                PutUtf16Unit(destination, ref offset, bigEndian, '\r');
                if (newline == TextNewlineMode.PreserveCarriageReturnLineFeed) PutUtf16Unit(destination, ref offset, bigEndian, '\n');
                index++;
            }
        }
    }

    private static void PutUtf16Unit(Span<byte> destination, ref int offset, bool bigEndian, ushort value)
    {
        destination[offset++] = (byte)(bigEndian ? value >> 8 : value & 255);
        destination[offset++] = (byte)(bigEndian ? value & 255 : value >> 8);
    }

    private static long Utf16EncodedLength(ReadOnlySpan<byte> source, TextEncodingMode encoding,
        TextNewlineMode newline, ExecutionState context, LythonSourceSpan? span)
    {
        long length = encoding == TextEncodingMode.Utf16 ? 2 : 0;
        var position = 0;
        for (var index = 0; index < source.Length;)
        {
            if ((position++ & 1023) == 0) context.CheckExecution(span);
            _ = Rune.DecodeFromUtf8(source[index..], out var rune, out var consumed);
            index += consumed;
            length += rune.Utf16SequenceLength * 2;
            if (rune.Value == '\n' && newline == TextNewlineMode.PreserveCarriageReturnLineFeed) length += 2;
        }
        return length;
    }
}
