from pathlib import Path
import hashlib, json, os, shutil, subprocess, tarfile

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
donor = lab.with_name("shared-comprehension-facts-20261124")
previous = donor / "comparison/quiet"
quiet = lab / "comparison/quiet"
quiet.mkdir(parents=True, exist_ok=True)
read = lambda p: json.loads(p.read_text(encoding="utf-8-sig"))
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
digest = lambda data: hashlib.sha256(data.encode("utf-8")).hexdigest()
save = lambda p, v: p.write_text(json.dumps(v, ensure_ascii=False, indent=2) + "\n", encoding="utf-8", newline="\n")
base = read(previous / "identity.json")
core = "Lokad.Lython.dll"
head = subprocess.check_output(["git","rev-parse","HEAD"],cwd=repo,text=True).strip()
assert head.startswith("9d50a1b1f")
assert subprocess.check_output(["git","diff","--binary",base["sourceRevision"],head,"--","src","tests"],cwd=repo)==(donor/"candidate.patch").read_bytes()
reference = base["imageFiles"]["candidate"]
assert {p.name:sha(p) for p in (donor/"candidate").iterdir()} == reference
current = lab/"windows/bin/Lokad.Lython/release_net11.0"/core
images = {"reference": reference, "candidate": reference | {core:sha(current)}}
assert images["candidate"][core] != reference[core]
for role, files in images.items():
    image=lab/role
    image.mkdir(exist_ok=True)
    for name in files:
        shutil.copyfile(current if role=="candidate" and name==core else donor/"candidate"/name,image/name)
    assert len(files)==32 and {p.name:sha(p) for p in image.iterdir()}==files

defaulted="scripts.rule-default-closures"
eager="scripts.annotated-rule-closures"
postponed="scripts.annotated-rule-closures.nested-factories.postponed"
quoted="scripts.csv-invoice.method-policy.quoted-control"
captured="scripts.captured-rule-closures"
report="diagnostic.text-summary.nonlocal-computed-width.large"
jobs=[[defaulted,"warm"],[eager,"warm"],[postponed,"warm"],[captured,"warm"],[defaulted,"compile-run"],[quoted,"warm"],[report,"warm"]]
first_catalog=read(lab.with_name("closed-definition-construction-20261124")/"comparison/quiet/representative.json")
catalog=read(lab.with_name("shared-prepared-definitions-20261124")/"comparison/quiet/representative.json")
rows={r["id"]:r for r in catalog["cases"] if r["id"] in (captured,report)}
rows.update({r["id"]:r for r in first_catalog["cases"]})
assert len(rows)==6
catalog["cases"]=[rows[key] for key in (defaulted,eager,postponed,captured,quoted,report)]
catalog["fixtureEncoding"]="Canonical base64 file maps for CSV and Unicode text. The rule scripts use no file fixture."
expected=quiet/"representative.json"
save(expected,catalog)
save(quiet/"jobs.json",{"warm":jobs})
python=Path("C:/Python313/python.exe")
patch=lab/"candidate.patch"
patch.write_bytes(subprocess.check_output(["git","diff","--binary","--","src","tests"],cwd=repo))
assert b"+        ref readonly var create = ref instructions[creation];" in patch.read_bytes()
identity=dict(sourceRevision=head,comparisonRevision=head,sourcePatchSHA256=sha(patch),
    purpose="Retain the proof of the first defaulted pair creation boundary",
    imageFiles=images,expectedCPythonSHA256=base["expectedCPythonSHA256"],cpythonWorkerSHA256=base["cpythonWorkerSHA256"],
    coreSHA256={role+suffix:files[core] for role,files in images.items() for suffix in ("","-control")},
    catalogs={name:{"sha256":sha(quiet/name)} for name in ("representative.json","jobs.json")})
save(quiet/"identity.json",identity)
collector=(previous/"collect.py").read_text(encoding="utf-8").replace("b1642-fixtures","b1645-fixtures").replace("len(jobs) == 4", "len(jobs) == 7")
compile(collector,"collect.py","exec")
(quiet/"collect.py").write_text(collector,encoding="utf-8",newline="\n")
shutil.copyfile(previous/"run.sh",quiet/"run.sh")
assert b"\r" not in (quiet/"run.sh").read_bytes()
sdk=Path.home()/".dotnet11"
dotnet=sdk/"dotnet.exe"
env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk))
worker=repo/"benchmarks/cpython-worker.py"
assert sha(worker)==identity["cpythonWorkerSHA256"]
for role in images:
    output=lab/"comparison"/(role+"-verify.json")
    subprocess.run([dotnet,lab/role/"Lokad.Lython.Benchmarks.dll","--compare","verify","--catalog",expected,
        "--dotnet",dotnet,"--python",python,"--python-worker",worker,"--out",output],env=env,cwd=repo,check=True,timeout=60)
    checked=read(output)
    assert checked["state"]=="Completed" and checked["caseCount"]==6
    assert checked["catalogSha256"]==sha(expected) and checked["launched"]["library"]["sha256"]==images[role][core]
staged=quiet/"payload.tar.gz"
with tarfile.open(staged,"w:gz",compresslevel=3) as archive:
    for name in ("identity.json","jobs.json","representative.json","collect.py","run.sh"):
        archive.add(quiet/name,arcname=name,recursive=False)
    archive.add(lab/"candidate"/core,arcname="candidate-core.dll",recursive=False)
save(quiet/"upload.json",dict(root="prepared-default-pair-boundaries-b1645-20261124",
    reference="shared-comprehension-facts-b1642-20261124",payloadSHA256=sha(staged),payloadBytes=staged.stat().st_size))
save(lab/"verified-raw-replicas.json",[])
launch=(donor/"quiet.py").read_text(encoding="utf-8")
receipt=read(previous/"terminal-status.json")["receipt"]
assert receipt["complete"] and sha(previous/"observations.tar.xz")==receipt["archiveSHA256"]
assert "f448b00857f22a384fdb36fa871de6d38a1001e06d08716e1197b9d69dab6154" in launch
launch=launch.replace("f448b00857f22a384fdb36fa871de6d38a1001e06d08716e1197b9d69dab6154",receipt["archiveSHA256"])
launch=launch.replace("lython-b1642-shared-comprehension-facts","lython-b1645-prepared-default-pair-boundaries").replace("b1642-","b1645-").replace("RuntimeMaxSec=207","RuntimeMaxSec=325").replace("seconds=146","seconds=238")
compile(launch,"quiet.py","exec")
(lab/"quiet.py").write_text(launch,encoding="utf-8",newline="\n")
print("Verified 32 files per image and six complete CPython goldens.")
