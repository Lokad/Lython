from pathlib import Path

lab = Path(__file__).resolve().parent
donor = lab.with_name("shared-comprehension-facts-20261124")
prepare = (donor / "prepare.py").read_text(encoding="utf-8")
prepare = prepare.replace('lab.with_name("regex-cursor-original-20261124")', 'lab.with_name("shared-comprehension-facts-20261124")')
prepare = prepare.replace('head.startswith("50e187921")', 'head.startswith("9d50a1b1f")')
start = prepare.index('generic="diagnostic.')
end = prepare.index('patch=lab/"candidate.patch"', start)
prepare = prepare[:start] + '''defaulted="scripts.rule-default-closures"
eager="scripts.annotated-rule-closures"
postponed="scripts.annotated-rule-closures.nested-factories.postponed"
quoted="scripts.csv-invoice.method-policy.quoted-control"
captured="scripts.captured-rule-closures"
report="diagnostic.text-summary.nonlocal-computed-width.large"
jobs=[[defaulted,"warm"],[eager,"warm"],[postponed,"warm"],[captured,"warm"],[defaulted,"compile-run"],[quoted,"warm"],[report,"warm"]]
first_catalog=read(lab.with_name("closed-definition-construction-20261124")/"comparison/quiet/representative.json")
catalog=read(lab.with_name("shared-prepared-definitions-20261124")/"comparison/quiet/representative.json")
rows={r["id"]:r for r in catalog["cases"] if r["id"] in (captured,report)}
rows.update({r["id"]:r for r in first_catalog["cases"]})
assert len(rows)==6
catalog["cases"]=[rows[key] for key in (defaulted,eager,postponed,captured,quoted,report)]
catalog["fixtureEncoding"]="Canonical base64 file maps for CSV and Unicode text. The rule scripts use no file fixture."
expected=quiet/"representative.json"
save(expected,catalog)
save(quiet/"jobs.json",{"warm":jobs})
python=Path("C:/Python313/python.exe")
'''+prepare[end:]
prepare = prepare.replace('b"+                    var facts = ComprehensionSyntaxFacts.PrepareBindings(expression, clauses,"', 'b"+        ref readonly var create = ref instructions[creation];"')
prepare = prepare.replace('Share comprehension scope bindings across validation, lexical preparation and lowering', 'Retain the proof of the first defaulted pair creation boundary')
prepare = prepare.replace('reference="regex-cursor-original-b1641-20261124"', 'reference="shared-comprehension-facts-b1642-20261124"')
prepare = prepare.replace('root="shared-comprehension-facts-b1642-20261124"', 'root="prepared-default-pair-boundaries-b1645-20261124"')
prepare = prepare.replace('replace("b1641-fixtures","b1642-fixtures")', 'replace("b1642-fixtures","b1645-fixtures").replace("len(jobs) == 4", "len(jobs) == 7")')
prepare = prepare.replace('f2a47dbcf304853599860ba0424b0fb8e37120b9b430a37e374dccda27ac5342', 'f448b00857f22a384fdb36fa871de6d38a1001e06d08716e1197b9d69dab6154')
prepare = prepare.replace('replace("lython-b1641-regex-cursor-original","lython-b1642-shared-comprehension-facts").replace("b1641-","b1642-")', 'replace("lython-b1642-shared-comprehension-facts","lython-b1645-prepared-default-pair-boundaries").replace("b1642-","b1645-").replace("RuntimeMaxSec=207","RuntimeMaxSec=325").replace("seconds=146","seconds=238")')
prepare = prepare.replace('checked["caseCount"]==3','checked["caseCount"]==6').replace('three complete CPython goldens','six complete CPython goldens')
archive = (donor / "archive.py").read_text(encoding="utf-8").replace('2026-11-24-shared-comprehension-facts', '2026-11-24-prepared-default-pair-boundaries')
archive = archive.replace('receipt["warmJobs"]==4', 'receipt["warmJobs"]==7').replace('timedBatches=112,lanes=4', 'timedBatches=196,lanes=7')
for name, code in (("prepare.py",prepare),("archive.py",archive), ("allocations.py",(donor / "allocations.py").read_text(encoding="utf-8")),
                   ("compile-allocation.py",(donor / "compile-allocation.py").read_text(encoding="utf-8"))):
    compile(code, name, "exec")
    (lab / name).write_text(code, encoding="utf-8", newline="\n")
