from pathlib import Path
import hashlib, json, shutil, subprocess, tarfile

refined = Path(__file__).resolve().parent
repo = refined.parents[3]
initial = refined.with_name("prepared-default-pair-boundaries-20261124")
destination = repo / "benchmarks/results/2026-11-24-prepared-default-pair-boundaries"
read = lambda path: json.loads(path.read_text(encoding="utf-8-sig"))
sha = lambda content: hashlib.sha256(content).hexdigest()
for lab, out, count in ((initial, destination, 7), (refined, destination / "refined", 5)):
    quiet = lab / "comparison/quiet"
    identity = read(quiet / "identity.json")
    patch = (lab / "candidate.patch").read_bytes()
    assert sha(patch) == identity["sourcePatchSHA256"]
    assert not subprocess.check_output(["git","diff",identity["sourceRevision"],"HEAD","--","src","tests"],cwd=repo)
    if lab == refined:
        assert patch == subprocess.check_output(["git","diff","--binary","--","src","tests"],cwd=repo)
    assert read(quiet / "terminal-status.json")["receipt"]["warmJobs"] == count
    for role, files in identity["imageFiles"].items():
        assert {path.name: sha(path.read_bytes()) for path in (lab / role).iterdir()} == files
        verify = read(lab / "comparison" / (role + "-verify.json"))
        assert verify["state"] == "Completed" and verify["caseCount"] == 6
        assert verify["launched"]["library"]["sha256"] == files["Lokad.Lython.dll"]
        assert read(lab / (role + "-compiler-owner.json"))["coreSHA256"] == files["Lokad.Lython.dll"]
    for path in (quiet / "identity.json", lab / "allocation-summary.json", lab / "compile-allocation-summary.json"):
        shutil.copyfile(path, out / path.name)
    names = ["make-trial.py", "prepare.py", "prepare.log", "quiet.py", "archive.py", "allocations.py", "compile-allocation.py",
             "candidate.patch", "reference-allocation.json", "candidate-allocation.json", "reference-compiler-owner.json",
             "candidate-compiler-owner.json", "comparison/reference-verify.json", "comparison/candidate-verify.json",
             "comparison/quiet/storage-custody.json"]
    if lab == initial:
        names.append("initial-prepare.log")
    if lab == refined:
        for platform, form, passed in (("windows","public",773),("ubuntu","white",848),("windows","net10",23),("ubuntu","net10",23)):
            name=f"{platform}-{form}.log"
            assert f"Passed:{passed:6}" in (lab / name).read_text(encoding="utf-8-sig"), name
            names.append(name)
        names.append("package-evidence.py")
    with tarfile.open(out / "procedures.tar.xz", "w:xz") as archive:
        for name in names:
            archive.add(lab / name, arcname=name, recursive=False)
    with tarfile.open(out / "procedures.tar.xz") as archive:
        assert {member.name: sha(archive.extractfile(member).read()) for member in archive} == {
            name: sha((lab / name).read_bytes()) for name in names}
print("Verified both exact source trials, worker images, goldens, allocations and archives.")
