from pathlib import Path

lab = Path(__file__).resolve().parent
initial = lab.with_name("prepared-default-pair-boundaries-20261124")
prepare = (initial / "prepare.py").read_text(encoding="utf-8")
prepare = prepare.replace('[[defaulted,"warm"],[eager,"warm"],[postponed,"warm"],[captured,"warm"],[defaulted,"compile-run"],[quoted,"warm"],[report,"warm"]]',
                          '[[defaulted,"warm"],[eager,"warm"],[captured,"warm"],[defaulted,"compile-run"],[report,"warm"]]')
prepare = prepare.replace('prepared-default-pair-boundaries-b1645', 'prepared-default-pair-boundaries-refined-b1646')
prepare = prepare.replace('lython-b1645-prepared-default-pair-boundaries', 'lython-b1646-prepared-default-pair-boundaries-refined')
prepare = prepare.replace('"b1645-fixtures"','"b1646-fixtures"').replace('"b1645-"','"b1646-"')
prepare = prepare.replace('"len(jobs) == 7"','"len(jobs) == 5"')
prepare = prepare.replace('RuntimeMaxSec=325','RuntimeMaxSec=260').replace('seconds=238','seconds=177')
prepare = prepare.replace('Retain the proof of the first defaulted pair creation boundary', 'Reuse the pair discriminator for the verified creation index')
archive = (initial / "archive.py").read_text(encoding="utf-8").replace('2026-11-24-prepared-default-pair-boundaries"', '2026-11-24-prepared-default-pair-boundaries/refined"')
archive = archive.replace('receipt["warmJobs"]==7', 'receipt["warmJobs"]==5').replace('timedBatches=196,lanes=7', 'timedBatches=140,lanes=5')
for name, code in (("prepare.py",prepare),("archive.py",archive), ("allocations.py",(initial / "allocations.py").read_text(encoding="utf-8")),
                   ("compile-allocation.py",(initial / "compile-allocation.py").read_text(encoding="utf-8"))):
    compile(code, name, "exec")
    (lab / name).write_text(code, encoding="utf-8", newline="\n")
