from pathlib import Path
import hashlib,json,shutil,subprocess,tarfile

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
quiet=lab/'external'
out=repo/'benchmarks/results/2026-11-25-deferred-locals-cpython'
read=lambda path:json.loads(path.read_text(encoding='utf-8-sig'))
sha=lambda path:hashlib.sha256(path.read_bytes()).hexdigest()
identity=read(quiet/'identity.json')
terminal=read(quiet/'terminal-status.json')
summary=read(quiet/'summary.json')
assert not terminal['live'] and not terminal['fixtures'] and terminal['exitCode']=='0'
receipt=terminal['receipt']
assert sha(quiet/'observations.tar.xz')==receipt['archiveSHA256']
assert all(receipt[key] for key in ('complete','allWorkersJoined','guestFixturesRemoved',
    'quietBeforeAndAfter','archivedAndVerifiedUnderLease'))
assert summary['source']==identity['sourceRevision'] and summary['timedBatches']==140
assert len(summary['rows'])==5 and {f.name:sha(f) for f in (lab/'candidate').iterdir()}==identity['imageFiles']['candidate']
retained=lab.with_name('deferred-callable-locals-refined-20261125')
paired=read(retained/'comparison/quiet/identity.json')
assert identity['sourcePatchSHA256']==paired['sourcePatchSHA256']
assert subprocess.check_output(['git','diff','--binary',paired['sourceRevision'],identity['sourceRevision'],'--','src'],cwd=repo)==(retained/'candidate.patch').read_bytes()
verified=read(quiet/'candidate-verify.json')
assert verified['caseCount']==2 and verified['state']=='Completed'
assert verified['launched']['library']['sha256']==identity['coreSHA256']['candidate']
out.mkdir(exist_ok=True)
for name in ('summary.json','identity.json','terminal-status.json','observations.tar.xz'):
    shutil.copyfile(quiet/name,out/name)
with tarfile.open(out/'procedures.tar.xz','w:xz') as bundle:
    for name in ('prepare.py','quiet.py','finish.py','prepare.log','launch-console.log','retrieve.log',
                 'external/collect.py','external/summarize.py','external/run.sh',
                 'external/candidate-verify.json','external/storage-custody.json','external/upload.json'):
        bundle.add(lab/name,arcname=name,recursive=False)
print('Verified five lanes, 140 batches, committed source, 32-file image and complete cleanup.')
