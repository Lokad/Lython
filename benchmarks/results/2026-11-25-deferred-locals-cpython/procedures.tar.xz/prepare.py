from pathlib import Path
import hashlib,json,shutil,tarfile,subprocess,os
p=Path('.git/agent-notes/review-20261031/deferred-callable-locals-cpython-20261125').resolve()
repo=p.parents[3]
d=p.with_name('deferred-callable-locals-refined-20261125')
template=p.with_name('direct-record-cpython-20261125')
q=p/'external'
q.mkdir(exist_ok=True)
read=lambda path:json.loads(path.read_text(encoding='utf-8-sig'))
sha=lambda path:hashlib.sha256(path.read_bytes()).hexdigest()
def write(path,text): path.write_text(text,encoding='utf-8',newline='\n')
def save(path,value): write(path,json.dumps(value,ensure_ascii=False,indent=2)+'\n')
old=read(p.with_name('ordinary-definition-effects-20261125')/'external/identity.json')
confirmation=read(d/'comparison/quiet/identity.json')
source=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo).decode().strip()
delta=subprocess.check_output(['git','diff','--binary',confirmation['sourceRevision'],source,'--','src'],cwd=repo)
assert delta==(d/'candidate.patch').read_bytes() and hashlib.sha256(delta).hexdigest()==confirmation['sourcePatchSHA256']
files=confirmation['imageFiles']['candidate']
assert len(files)==32 and {f.name:sha(f) for f in (d/'candidate').iterdir()}==files
image=p/'candidate'
image.mkdir(exist_ok=True)
for name in files: shutil.copyfile(d/'candidate'/name,image/name)
assert {f.name:sha(f) for f in image.iterdir()}==files
catalog=read(d/'comparison/quiet/representative.json')
ordinary,=[r for r in catalog['cases'] if r['id']=='diagnostic.generated-ordinary-definitions']
shipment,=[r for r in read(template/'external/representative.json')['cases'] if r['id']=='diagnostic.shipment-routing-callbacks']
catalog['cases']=[ordinary,shipment]
save(q/'representative.json',catalog)
jobs=[(ordinary['id'],lane) for lane in ('compile','warm','compile-run')]+[(shipment['id'],lane) for lane in ('warm','warm-async')]
save(q/'jobs.json',jobs)
server='deferred-callable-locals-cpython-b1736-20261125'
identity=old|{
 'sourceRevision':source,'productionSource':source,'candidate':source,
 'imageFiles':{'candidate':files},'coreSHA256':{role:files['Lokad.Lython.dll'] for role in ('candidate','candidate-control')},
 'sourcePatchSHA256':confirmation['sourcePatchSHA256'],
 'frozenImage':'/home/lokad/lython-bench-checks/'+server+'/candidate',
 'catalogs':{name:dict(sha256=sha(q/name)) for name in ('representative.json','jobs.json')},
 'purpose':'Retained deferred definitions and shipment callback report against CPython'}
save(q/'identity.json',identity)
sdk=Path.home()/'.dotnet11'
dotnet=sdk/'dotnet.exe'
env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk))
python_worker=repo/'benchmarks/cpython-worker.py'
assert sha(python_worker)==identity['cpythonWorkerSHA256']
evidence=q/'candidate-verify.json'
subprocess.run([dotnet,image/'Lokad.Lython.Benchmarks.dll','--compare','verify','--catalog',q/'representative.json',
  '--dotnet',dotnet,'--python','C:/Python313/python.exe','--python-worker',python_worker,'--out',evidence],
  cwd=repo, env=env, check=True, timeout=80)
verified=read(evidence)
assert verified['state']=='Completed' and verified['caseCount']==2
assert verified['catalogSha256']==identity['catalogs']['representative.json']['sha256']
assert verified['launched']['library']['sha256']==files['Lokad.Lython.dll']
assert {f.name:sha(f) for f in image.iterdir()}==files
old_terminal=read(d/'comparison/quiet/terminal-status.json')
assert old_terminal['receipt']['complete'] and sha(d/'comparison/quiet/observations.tar.xz')==old_terminal['receipt']['archiveSHA256']
for name in ('collect.py','summarize.py','run.sh'):
 s=(template/'external'/name).read_text(encoding='utf-8')
 s=s.replace('b1720-fixtures','b1736-fixtures').replace('Retained CSV record admission checkpoint against CPython','Retained deferred definitions and shipment callback report against CPython')
 s=s.replace('len(jobs) == 11','len(jobs) == 5').replace('started<440','started<245')
 s=s.replace('len(raw["jobs"])==11 and receipt["warmJobs"]==11','len(raw["jobs"])==5 and receipt["warmJobs"]==5')
 if name.endswith('.py'): compile(s,name,'exec')
 write(q/name,s)
assert b'\r' not in (q/'run.sh').read_bytes()
s=(template/'quiet.py').read_text(encoding='utf-8')
s=s.replace('lython-b1720-direct-record-cpython','lython-b1736-deferred-callable-locals-cpython').replace('b1720','b1736')
s=s.replace('seconds=390','seconds=225').replace('RuntimeMaxSec=490','RuntimeMaxSec=280')
a=s.index("assert donor['archiveSHA256']=='")
b=s.index('\n',a)
s=s[:a]+f"assert donor['archiveSHA256']=={old_terminal['receipt']['archiveSHA256']!r}"+s[b:]
compile(s,'quiet.py','exec')
write(p/'quiet.py',s)
shutil.copyfile(d/'verified-raw-replicas.json',p/'verified-raw-replicas.json')
bundle=q/'payload.tar.gz'
with tarfile.open(bundle,'w:gz',compresslevel=3) as tar:
 for name in ('identity.json','jobs.json','representative.json','collect.py','run.sh'):
  tar.add(q/name,arcname=name)
save(q/'upload.json',dict(root=server,reference=read(d/'comparison/quiet/upload.json')['root'],
 payloadSHA256=sha(bundle),payloadBytes=bundle.stat().st_size))
