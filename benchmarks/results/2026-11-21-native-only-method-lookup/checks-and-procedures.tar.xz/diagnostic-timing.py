from contextlib import ExitStack
import hashlib, importlib.util, json, os, statistics, subprocess, tempfile, time
from pathlib import Path

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
manifest=lab/'representative.json'
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
identity=load(lab/'identity.json')
spec=importlib.util.spec_from_file_location('protocol', repo/'benchmarks/cpython-worker.py')
protocol=importlib.util.module_from_spec(spec)
spec.loader.exec_module(protocol)
sdk=Path.home()/'.dotnet11'
dotnet=sdk/'dotnet.exe'
env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk),PATH=str(sdk)+os.pathsep+os.environ['PATH'])

def hash_files(role):
    return {name:hashlib.sha256((lab/'frozen'/role/name).read_bytes()).hexdigest() for name in identity['imageFiles'][role]}
assert all(hash_files(role)==identity['imageFiles'][role] for role in ('reference','candidate'))

class Worker:
    def __init__(self, stack, label, case):
        self.sequence=0
        self.case=case
        self.label=label
        role=label.removesuffix('-control')
        folder=stack.enter_context(tempfile.TemporaryDirectory(prefix='lython-comparison-files-'))
        error=stack.enter_context((lab/(case['id']+'-'+label+'.stderr')).open('wb'))
        self.child=subprocess.Popen([dotnet,lab/'frozen'/role/'Lokad.Lython.Benchmarks.dll','--compare','worker','--catalog',manifest],
                                    cwd=folder, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=error, env=env)
        stack.callback(self.close)
        self.ready=protocol.read_frame(self.child.stdout)
        assert self.ready['status']=='Ready' and self.ready['catalogSha256']==identity['catalogSHA256']
        libraries={Path(v['path']).name:v['sha256'].lower() for v in self.ready['libraries']}
        assert libraries['Lokad.Lython.dll']==identity['imageFiles'][role]['Lokad.Lython.dll']
        assert all(identity['imageFiles'][role][n]==h for n,h in libraries.items() if n in identity['imageFiles'][role])
        self.request('verify',2)

    def request(self, operation, count):
        self.sequence+=1
        checks={key:self.case[key] for key in ('sourceSha256','fixtureSha256','expectedOutputSha256')}
        protocol.write_frame(self.child.stdin,dict(protocolVersion=2,requestId=self.sequence,operation=operation,
             caseId=self.case['id'],lane='warm',iterations=count,**checks))
        result=protocol.read_frame(self.child.stdout)
        assert result['status']==('Equivalent' if operation=='verify' else 'Completed') and result['completedInvocations']==count
        for k,value in checks.items():assert result[k]==value
        assert result['actualOutputSha256']==self.case['expectedOutputSha256']
        assert result.get('actualFilesSha256')==self.case.get('expectedFilesSha256')
        return result

    def close(self):
        try:
            if self.child.poll() is None:
                self.sequence+=1
                protocol.write_frame(self.child.stdin,dict(protocolVersion=2,requestId=self.sequence,operation='quit'))
                assert protocol.read_frame(self.child.stdout)['status']=='Closed'
            assert self.child.wait(timeout=5)==0
        finally:
            if self.child.poll() is None:
                self.child.kill()
                self.child.wait(timeout=5)
            self.child.stdin.close()
            self.child.stdout.close()

rows=[]
labels=['reference','candidate','reference-control','candidate-control']
for case_index,case in enumerate(load(manifest)['cases']):
    with ExitStack() as stack:
        offset=case_index%len(labels)
        workers=[Worker(stack,label,case) for label in labels[offset:]+labels[:offset]]
        samples={w.label:[] for w in workers}
        warm={w.label:0 for w in workers}
        counts={w.label:8 for w in workers}
        while min(warm.values())<1.5:
            for worker in workers:
                start=time.perf_counter()
                worker.request('batch',counts[worker.label])
                seconds=time.perf_counter()-start
                warm[worker.label]+=seconds
                counts[worker.label]=max(1,min(4096,int(counts[worker.label]*.22/max(seconds,.001))))
        for round_ in range(5):
            rotation=round_%len(workers)
            for worker in workers[rotation:]+workers[:rotation]:
                samples[worker.label].append(worker.request('batch',counts[worker.label]))
        for worker in workers:worker.request('verify',2)
    medians={label:statistics.median(1000*s['elapsedTicks']/s['clockFrequency']/s['completedInvocations'] for s in samples[label]) for label in labels}
    changes=sorted(100*(medians[a]/medians[b]-1) for a in labels[1::2] for b in labels[::2])
    rows.append(dict(case=case['id'],medianMilliseconds=medians,changePercent=changes,warmSeconds=warm,samples=samples))
    print(case['id'],[round(changes[i],2) for i in (0,-1)],{k:round(v,2) for k,v in medians.items()},flush=True)
assert all(hash_files(role)==identity['imageFiles'][role] for role in ('reference','candidate'))
(lab/'local-timing.json').write_text(json.dumps(dict(identity=identity,boundary='Windows .NET 11 local warm diagnostic. Four independent exact workers, five rotated samples each. Includes goldens and prior-result cleanup.',rows=rows),indent=2)+'\n',encoding='utf-8')

