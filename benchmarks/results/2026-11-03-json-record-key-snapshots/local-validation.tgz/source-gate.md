## Priority 2 — JSON record-key construction B166 source gate

B138's last measured repeated-schema allocation−13.81%/warm9–13%gain carries
unique-key elapsed+31.50%/CPU+69.67%/allocation+27.99%debt. Historical source-pair
points, not HEAD claims. Mutable execution-wide name indexing still duplicates
key/dictionary work; B139/B153 hash variants withdrawn. No third blind hasher.

Bounded source assessment DONE: constants already hold immutable UTF-8 PyStrings,
but pools belong to separate code builders. Important report/JSON keys live in
helpers, not the caller parsing JSON; class/generator/import entries also prepare
separately. Literal-only lookup would need a new cross-code registry and would
penalize unknown schemas. Do not implement that workaround for this milestone.
Compiled disposal remains caller-owned after all runs/diagnostic aliases finish;
do not invent a new borrow graph. No new measurement is needed for this rejection.

Next candidate to prove: share only the previous completed native object's ordered
key sequence, as an immutable owned hint inside the existing JSON parser. Compare
each incoming key's actual UTF-8 before reusing an already-funded immutable key;
on mismatch perform normal owned decoding, never replay after effects/admission.
This covers unknown same-order schemas, unlike literal-only lookup. Expected
removal: ExecutionState.JsonKeys mutable dictionary, custom hasher, capacity/growth
and unique-name index retention; remove cache-architecture-only tests while keeping
observable ownership/semantics. No second parser, schema-specific dict backend,
trace/inventory, per-object/refcount ledger, pool, registry or policy limit.

Proof before coding: hints contain keys ONLY, never whole records/values; callbacks
may reenter/suspend and replace the active hint, so snapshots must remain immutable
and funded. Use existing execution ownership and document conservative retention
of replaced tiny hint arrays through the bounded host execution if needed; no new
reclamation layer. Reserve metadata/replacement before allocation, cancellation
through large copies, refused admission terminal (never skip cache publication to
recover). Verify dictionary duplicate-key identity and distinguish implementation
string-intern choices from promised semantics before changing any test/contract.

Acceptance/control set: report/JSON-lines/config, unknown repeated schema, changing/
reordered schema, unique names, nested/empty/duplicate/escaped Unicode keys, both
hooks with real suspension/reentry, cancellation, retained aliases, admission and
budget reuse. Preserve order/value/error behavior and independent UTF-8 bytes.
One bounded BOTH-API source pair with controls/allocation/peaks plus compile-only
control if frontend changes (none expected). Tradeoffs: reordered/changing layouts
may miss reuse and retain more tiny metadata; no general gain claim or fixed-percent
veto. If funding/identity proof requires a new owner graph or broader decoder, stop
and make an explicit simpler tradeoff decision. Complete/remove displaced index,
then retain/refine/withdraw with adverse controls preserved. Not yet implemented.

