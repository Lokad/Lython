import json
def key(value):
    return next(iter(value))
rows=json.loads('[{"field_name":1},{"field_name":2}]')
print(key(rows[0]) is key(rows[1]))
a=json.loads('{"field_name":1}')
b=json.loads('{"field_name":2}')
print(key(a) is key(b))
pairs=json.loads('{"field_name":1,"field_name":2}',object_pairs_hook=lambda items:items)
print(pairs[0][0] is pairs[1][0])
