#!/usr/bin/env bash
set -euo pipefail
repo=/mnt/d/code/Lython
cd "$repo/.git/agent-worktrees/shared-annotation-boundaries"
export DOTNET_ROOT="$HOME/.dotnet"
export PATH="$DOTNET_ROOT:$PATH"
logs="$repo/.git/agent-notes/review-20261031/shared-annotation-boundaries"
dotnet test tests/Lokad.Lython.PublicApi.Tests -c Release -f net10.0 --filter '(FullyQualifiedName~Annotation|FullyQualifiedName~StaticError|FullyQualifiedName~StaticAnalysis|FullyQualifiedName~SharedCompilerFact|FullyQualifiedName~Scope|FullyQualifiedName~RegexAnalysis|FullyQualifiedName~CompileCancellation)&Category!=Stress' -v quiet 2>&1 | tee "$logs/public-ubuntu.log"
dotnet test tests/Lokad.Lython.Tests -c Release -f net10.0 --filter '(FullyQualifiedName~Frontend|FullyQualifiedName~Static|FullyQualifiedName~Lexical|FullyQualifiedName~Compilation)&Category!=Stress' -v quiet 2>&1 | tee "$logs/white-ubuntu.log"