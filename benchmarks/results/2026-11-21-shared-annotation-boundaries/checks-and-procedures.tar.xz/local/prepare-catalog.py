from pathlib import Path
import json
lab=Path(__file__).resolve().parent
cases=lab.parent
read=lambda path:json.loads(path.read_text(encoding='utf-8-sig'))
catalog=read(cases/'private-compiled-annotation-payload/representative.json')
factory=next(row for row in catalog['cases'] if row['id']=='scripts.annotated-rule-closures.nested-factories.postponed')
dataclass=next(row for row in read(cases/'cpython-dataclass-factories/representative.json')['cases']
               if row['id']=='scripts.dataclass-inherited-configuration.generated')
validator=next(row for row in read(cases/'native-dict-item-cursor/representative.json')['cases']
               if row['id']=='scripts.config-generated-guards.medium.bad-0')
catalog['cases']=[factory,dataclass,validator]
(lab/'representative.json').write_text(json.dumps(catalog,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
