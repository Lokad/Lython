from pathlib import Path
import contextlib
import hashlib
import io
import json
import os
import random
import shutil
import subprocess
import tarfile

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
tree=repo/'.git/agent-worktrees/exact-unicode-float-20261124'
donor=lab.with_name('direct-match-expand-20261124')
comparison=lab/'comparison'
comparison.mkdir(exist_ok=True)


def read(path):
    return json.loads(path.read_text(encoding='utf-8'))


def sha(text):
    return hashlib.sha256(text.encode('utf-8')).hexdigest()


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def save(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2)+'\n',encoding='utf-8',newline='\n')


metadata=read(donor/'comparison/identity.json')
reference=metadata['candidate']
assert reference.startswith('83ae1e2fa')
subprocess.run(['git','diff','--exit-code',reference,'HEAD','--','src','tests'],cwd=repo,check=True)
assert not subprocess.check_output(['git','status','--porcelain','--','src','tests'],cwd=tree)
candidate=subprocess.check_output(['git','rev-parse','HEAD'],cwd=tree,text=True).strip()
assert candidate!=reference
prior=repo/'benchmarks/results/2026-11-24-typed-csv-text/observations.tar.xz'
with tarfile.open(prior) as bundle:
    catalog=json.load(bundle.extractfile('representative.json'))
assert [case['id'] for case in catalog['cases']]==[
    'scripts.csv-meter-report.typed-unicode','scripts.csv-meter-report.typed-unicode.observed',
    'scripts.csv-meter-report.explicit-float','scripts.csv-invoice.method-policy.quoted-control',
]
representative=comparison/'representative.json'
save(representative,catalog)
save(comparison/'jobs.json',{'warm':[[case['id'],'warm'] for case in catalog['cases']]})

generator=random.Random(1560)
bases=[0x30,0x660,0x6f0,0x966,0xff10,0x1d7ce,0x1e950]
sources=[]
for i in range(420):
    count=generator.randint(1,26)
    digits=[chr(generator.choice(bases)+generator.randrange(10)) for _ in range(count)]
    point=generator.randint(0,count) if i%5 else -1
    text=''
    for j,digit in enumerate(digits):
        if j==point:
            text+='.'
        elif j and generator.randrange(3)==0:
            text+='_'
        text+=digit
    if point==count:
        text+='.'
    if i%11==0:
        text+=generator.choice(('e','E'))+generator.choice(('-','+'))+generator.choice(('٧','２','300','999'))
    if i%3==0:
        text='-'+text
    if i%13==0:
        text='\u00a0'+text+'\u202f'
    sources.append(text)
sources.extend(['٣٠_٠','-.𝟘_０','𝟚.','._١','١_.٢','١._٢','١__٢','١_','١\0','١.٢.٣','١_²','－１'])
script=("import struct\nfor token in "+repr(sources)+":\n"
        "    try:\n        print(struct.pack('>d',float(token)).hex())\n"
        "    except ValueError:\n        print('invalid')\n")
output=io.StringIO()
with contextlib.redirect_stdout(output):
    exec(compile(script,'decimal-corpus.py','exec'),{'__name__':'__main__'})
stdout=output.getvalue()
assert stdout.count('invalid\n')==9 and len(stdout.splitlines())==len(sources)
fixture='{"size":'+str(len(sources))+',"text":null}'
case=dict(id='diagnostic.float.exact-short-decimal.corpus',family='scripts',category='whole-script',
    scale='medium',size=len(sources),source=script,fixtureJson=fixture,expectedOutput=stdout,
    sourceUtf8Bytes=len(script.encode('utf-8')),expectedOutputUtf8Bytes=len(stdout),
    fixtureTextUtf8Bytes=0,fixtureTextCodePoints=0,sourceSha256=sha(script),fixtureSha256=sha(fixture),
    expectedOutputSha256=sha(stdout))
corpus=comparison/'corpus.json'
save(corpus,dict(catalog,cases=[case]))

files=metadata['imageFiles']['candidate']
runtime=Path.home()/'.dotnet11'
dotnet=runtime/'dotnet.exe'
protocol=repo/'benchmarks/cpython-worker.py'
assert digest(protocol)==metadata['cpythonWorkerSHA256']
env=dict(os.environ,DOTNET_ROOT=str(runtime),DOTNET_ROOT_X64=str(runtime))
assert len(files)==32 and all(digest(donor/'candidate'/name)==expected for name,expected in files.items())
core='Lokad.Lython.dll'
images={}
helpers={}
for role in ('reference','candidate'):
    image=lab/role
    image.mkdir(exist_ok=True)
    for name in files:
        source=lab/'frozen/bin/Lokad.Lython/release_net11.0'/core if role=='candidate' and name==core else donor/'candidate'/name
        shutil.copyfile(source,image/name)
    for suffix in ('.dll','.deps.json','.runtimeconfig.json'):
        helper='ValidatedAllocation'+suffix
        shutil.copyfile(donor/'candidate'/helper,image/helper)
        helpers[helper]=digest(image/helper)
    observed={name:digest(image/name) for name in files}
    for catalog_file,tag,count in [(representative,'verify',4),(corpus,'corpus-verify',1)]:
        result=comparison/(role+'-'+tag+'.json')
        subprocess.run([dotnet,image/'Lokad.Lython.Benchmarks.dll','--compare','verify','--catalog',
            catalog_file,'--dotnet',dotnet,'--python','C:/Python313/python.exe','--python-worker',protocol,
            '--out',result],env=env,check=True,timeout=90)
        proof=read(result)
        assert proof['state']=='Completed' and proof['caseCount']==count and proof['launched']['library']['sha256']==observed[core]
    assert all(digest(image/name)==expected for name,expected in observed.items())
    assert all(digest(image/name)==expected for name,expected in helpers.items())
    images[role]=observed
assert files==images['reference']
assert [name for name in files if images['reference'][name]!=images['candidate'][name]]==[core]
save(comparison/'identity.json',dict(sourceRevision=reference,candidate=candidate,
    purpose='B1560 convert short Unicode decimals directly, eliminating buffer fill and general parsing',
    imageFiles=images,helperFiles=helpers,cpythonWorkerSHA256=metadata['cpythonWorkerSHA256'],
    expectedCPythonSHA256=metadata['expectedCPythonSHA256'],
    catalogs={name:dict(sha256=digest(comparison/name)) for name in ('representative.json','jobs.json','corpus.json')},
    coreSHA256={label:images[role][core] for role in images for label in (role,role+'-control')}))
shutil.copyfile(donor/'allocations.py',lab/'allocations.py')
