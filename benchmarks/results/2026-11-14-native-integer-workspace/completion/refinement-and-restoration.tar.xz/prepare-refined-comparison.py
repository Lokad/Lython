from pathlib import Path
import ast
r=Path(__file__).parent;out=r/'refined';s=(r/'prepare-comparison.py').read_text(encoding='utf-8').replace("r/'b751'", "r/'b752'").replace('native-word-loan-b751-20261114','native-word-cleanup-b752-20261114').replace('lython-b751-native-word-loan-20261114','lython-b752-native-word-cleanup-20261114').replace('B751','B752').replace('lython-b751-fixtures','lython-b752-fixtures').replace("r.parent/", "r.parent.parent/")
s=s.replace('Native integer working storage borrows existing one-idle-workspace lifetime policy.', 'Refined native integer working storage: source-proved mutually exclusive continuation/word cleanup removes the added nested finally; initial B751/adverse short controls preserved. Existing one-idle-workspace lifetime policy remains.')
ast.parse(s);(out/'prepare-comparison.py').write_text(s,encoding='utf-8',newline='\n')
print('Prepared one changed-source refinement comparison; launch only after frozen checks/controls finish.',flush=True)
