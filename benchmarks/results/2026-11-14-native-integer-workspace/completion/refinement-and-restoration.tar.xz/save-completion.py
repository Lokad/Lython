from pathlib import Path
import hashlib,json,shutil,tarfile
r=Path(__file__).parent;root=Path('benchmarks/results/2026-11-14-native-integer-workspace');out=root/'completion';out.mkdir();source=json.loads((r/'candidate-identity.json').read_text(encoding='utf-8'));assert all(hashlib.sha256(Path(n).read_bytes()).hexdigest()==h for n,h in source['sources'].items());status=json.loads((r/'refined/b752/terminal-status.json').read_text(encoding='utf-8'));assert status['exitCode']=='0' and status['receipt']['complete'] and not status['remainingWorkers'] and not status['remainingTrace'];assert hashlib.sha256((r/'refined/b752/observations.tgz').read_bytes()).hexdigest()==status['receipt']['archiveSHA256'];checks=json.loads((r/'restored-initial/checks.json').read_text(encoding='utf-8'));assert len(checks)==4 and all(x['exitCode']==0 for x in checks)
for n in ['source-proof.json','checks.json']:shutil.copyfile(r/'restored-initial'/n,out/('restored-'+n))
shutil.copyfile(r/'refined/b752/summary.json',out/'withdrawn-refinement-timing.json')
with tarfile.open(out/'refinement-and-restoration.tar.xz','w:xz')as t:
    for folder in ['refined','restored-initial']:
        for p in sorted((r/folder).rglob('*')):
            if p.is_file() and not any(x in {'reference','candidate','bin','obj'}for x in p.relative_to(r/folder).parts):t.add(p,arcname=p.relative_to(r).as_posix())
    for name in ['refine.py','restore-initial.py','save-completion.py','prepare-refined-comparison.py']:t.add(r/name,arcname=name)
decision=dict(retainedCore=source['coreSHA256']['candidate'],retainedVersion='InitialB751ff2b5d76, source restored exactly after withdrawing cleanup refinement',reason='14.57percentwholefulfillmentallocation reduction and removal of per-call temporary storage/reservation objects. Initial warm modest/mixed and freshmodestlylower; no substantial CPU claim. Accept explicit short-helper elapsed+0.62..+2.91percent/CPU+1.22..+2.71percent and observedelapsed+0.09..+1.06percent/CPUuncertain as0.11debt.',withdrawnRefinement='fb3185fb: smaller cleanup topology but shortelapsed+4.50..+6.91percent/CPU+3.47..+6.85percent, text+0.30..+4.23percentwith3.33percentspread, JSONmixed/slightlyadverse, no extraallocationbenefit. Entire variant removed; initialindependent cleanup restored. No crosscollection causal attribution or permanentarchitectureban.',ownership='Existing one-idle workspace policy charges idle/fullcapacity until eviction/executioncleanup, active loans until actual return. Majorpreflight/cancellationafteradmission/firstrefusal/materialization/awaitedcleanup preserved. Earlierdenial versus oldtemporarysize is explicit.',qualification='Initial698focused actual11/10,102Pythoncontrols,18goldens; refined204focused/102controls/18goldens; forcedrestoration56checks and582inputproof. Fullplatform/stress/installedpackage delivery next; not yet green.',publicationHeld=True,performanceObjectiveStillOpen=True)
(out/'decision.json').write_text(json.dumps(decision,indent=2)+'\n',encoding='utf-8',newline='\n')
(out/'README.md').write_text('''# Native working-storage completion — retained initial version

2026-11-14. Retain initial B751 `ff2b5d76` against qualified fa40/73a, with the
explicit independent cleanup, existing one-idle workspace policy and charged
native word capacity. Remove per-wide-call long[] and temporary reservation
objects. Initial allocation−14.57% is established separately from timing.
Accept recorded short-helper0.62–2.91%elapsed/1.22–2.71%CPU debt and observed
elapsed0.09–1.06%/mixedCPU as an explicit0.11decision. Whole-script performance
objective stays open; no large/universal CPU or embedding-latency claim.

## Cleanup refinement, not retained

B752 atfb3185fb restores a single mutually exclusive cleanup finally; source
facts prove native words and newly rented continuation storage cannot overlap.
Seven complete jobs finish269.786s with all image/catalog/golden/file/budget/
quiet/awaited-cleanup/persistent-archive gates. No users/fixtures remain.

| Complete script | Refined elapsed change | Wider CPU change |
| --- | ---: | ---: |
| Fulfillment, warm |−2.98..+0.39%|−3.53..−1.67%|
| Fulfillment, compile-to-result |−0.57..+0.07%|+0.21%|
| Invoice |−1.54..−0.26%|0.00%|
| Captured text |+0.30..+4.23%|+0.80..+3.96%|
| JSON helpers |−0.39..+3.49%|0.00..+3.57%|
| Short/zero helpers |+4.50..+6.91%|+3.47..+6.85%|
| Observed-value helpers |−1.82..+0.37%|−0.28..+2.25%|

All process-median pairings, not confidence intervals. Text candidate spread3.33%
and JSON2.58% limit precision; stable short adversity remains. Allocation retains
the same14.57% benefit and no additional saving. Source-proved EH simplification
does not prove CPU improvement or explain its measured cost. No attribution from
cross-collection differences. Same quiet F4as_v7/Ubuntu24.04.4/.NET11RC3,
normalGC/tiering, workers/0.4adapter/catalog/algorithms and full-request warmups/
five rotating0.5sbatches as B751. All initial/adverse conditions remain linked.

Withdraw this entire cleanup version; restore all582 initial source inputs before
forced nonincremental actual11/10 builds and56focused cleanup/lifetime checks
(14internal+14public each). No unchanged timing repeat. Independent explicit
cleanup remains robust across its owners. No new helper, compatibility option,
watchdog, abandoned work or dormant alternate route survives.

The ownership milestone is useful for allocation and admission simplification,
not closure of the broader representative CPU goal. Idle/native capacity stays
fully charged under the current existing policy until eviction/cleanup, with
outstanding loans funded until real users finish. Conservative retention/earlier
denial is intentional and documented. Full platform/original stress/installed
package qualification follows at this coherent retained boundary; publication held.

B752rawSHA256 `d3ba97f841c188f50de6c4861123dd388e3159d6aa1eca4ca3dbd355d39fd601`.
All evidence independently verifies under its lease before teardown. Current
images/catalog/toolchain and254/252MiBfloors preserved; no retirement.

[Decision](decision.json), [refined timing](withdrawn-refinement-timing.json),
[restored source](restored-source-proof.json), [restored checks](restored-checks.json),
[all refined source/binary/raw/restoration](refinement-and-restoration.tar.xz),
[initial retained observations](../README.md).
''',encoding='utf-8',newline='\n')
p=root/'README.md';s=p.read_text(encoding='utf-8').replace('# Native integer workspace lifetime — bounded cleanup refinement','# Native integer workspace lifetime — retained initial version',1);s=s.replace('R365/B751, 2026-11-14 UTC.', 'The [completion decision](completion/README.md) retains the initial source below,\nwithdraws its cleanup refinement, and preserves explicit short-helper debt. Full\ndelivery qualification remains separate/pending.\n\nR365/B751, 2026-11-14 UTC.',1).replace('## Selected cleanup refinement','## Historical selected cleanup refinement');p.write_text(s,encoding='utf-8',newline='\n')
p=Path('benchmarks/EXPERIMENTS.md');p.write_text(p.read_text(encoding='utf-8')+'''
R365 [completion](results/2026-11-14-native-integer-workspace/completion/README.md)
retains initialff2b,14.57%allocation reduction, modest/mixedfulfillmentclock,
explicitshort+0.62..+2.91%elapsed/CPU+1.22..+2.71%debt. Refinedfb31/B752sevenjobs
269.786s/allgates:short+4.50..+6.91%,text+0.30..+4.23%variable,noextraallocation
saving. Whole refinement withdrawn, all582initialinputs restored/forcedbuilds/
56checks pass; no unchanged retime or causal EH attribution. Full delivery next,
publication held, broader objective continues; all old/adverse/source/raw survive.
''',encoding='utf-8',newline='\n')
p=Path('docs/BENCHMARKS.md');s=p.read_text(encoding='utf-8');a=s.index('- Native primitive working storage:');s=s[:a]+'''- Native integer workspace reuse: a later fulfillment source pair allocates14.57%
  less per complete run. Warm elapsed is mixed/modestly lower, fresh modestly lower;
  short helpers regress0.6–2.9%. This is an allocation/ownership improvement, not
  a substantial CPU claim, and is excluded from the fa40 CPython table above.
  [Exact source, controls, debt and delivery status](../benchmarks/results/2026-11-14-native-integer-workspace/completion/README.md).
'''+s[a:];p.write_text(s,encoding='utf-8',newline='\n')
print('Retain initial explicit loan cleanup with measured allocation benefit and documented debt; all refinement/adverse evidence preserved.',flush=True)
