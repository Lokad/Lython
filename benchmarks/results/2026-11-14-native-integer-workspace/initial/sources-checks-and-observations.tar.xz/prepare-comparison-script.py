from pathlib import Path
import ast
r=Path(__file__).parent;s=(r.parent/'helper-activation-r364/prepare-comparison.py').read_text(encoding='utf-8')
s=s.replace('helper-entry-b750-20261114','native-word-loan-b751-20261114').replace('lython-b750-helper-entry-20261114','lython-b751-native-word-loan-20261114').replace('B750','B751').replace("r/'b750'", "r/'b751'")
s=s.replace('R364uncommitted/frozen','R365uncommitted/frozen')
s=s.replace('One synchronous helper activation entry across fixed and alreadybound storage: remove StartInline and nullable descriptor handoff. Same complete search/invoice warm+fresh/text/JSON/counter/short/observed scripts/settings. Allocation separate, no CPython or forecast.', 'Native integer working storage borrows existing one-idle-workspace lifetime policy. Remove per-wide-call long[]/temporary reservation allocation, retain conservative cache funding and active-user cleanup. Same complete fulfillment warm/fresh, invoice/text/JSON/short/observed controls. Allocation separate; no CPython or forecast.')
a=s.index('jobs=');b=s.index("\nroot=",a)
jobs=[['scripts.csv-fulfillment.large','warm'],['scripts.csv-fulfillment.large','compile-run'],['scripts.csv-invoice.large','warm'],['scripts.text-summary-helpers.nonlocal-counter.large','warm'],['scripts.json-summary-helpers.large','warm'],['diagnostic.loop-helper.short-zero.large','warm'],['diagnostic.loop-helper.observed.large','warm']]
s=s[:a]+'jobs='+repr(jobs)+s[b:]
s=s.replace("assert len(jobs)==8", "assert len(jobs)==7").replace("len(raw['jobs'])==8", "len(raw['jobs'])==7").replace('jobs=8','jobs=7').replace("['jobs']==8", "['jobs']==7").replace('eight-job','seven-job')
# The template's replacements operate on the six-job B745 collectors.
s=s.replace('==8\"','==7\"').replace("'jobs=8'", "'jobs=7'")
s=s.replace('Separate StartInline/nullable descriptor handoff; one fixed or supplied storage owner with existing bind/execute/transfer/cleanup. No new representation/controller/arena/owner/config.', 'Per-wide-helper long[]/temporary reservation objects removed; existing capacity-level workspace reuse retains all active/idle funding and allocation preflight/cancellation. No new allowance/controller/representation/framework.')
s=s.replace('lython-b750-fixtures','lython-b751-fixtures')
ast.parse(s);(r/'prepare-comparison.py').write_text(s,encoding='utf-8',newline='\n')
