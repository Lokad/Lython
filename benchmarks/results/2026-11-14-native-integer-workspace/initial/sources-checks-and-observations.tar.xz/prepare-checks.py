from pathlib import Path
import ast
r=Path(__file__).parent
s=(r.parent/'helper-activation-r364/check.py').read_text(encoding='utf-8').replace('r364-','r365-')
s=s.replace("['SimpleFunctionExecutionBoundaryTests'", "['NativeIntegerWorkspaceOwnershipTests','NativeFunctionRefundTests','SimpleFunctionExecutionBoundaryTests'")
s=s.replace("['OrdinaryFunctionCallTests'", "['IntegerPublicationTests','OrdinaryFunctionCallTests'")
s=s.replace("assert changed==['src/Lokad.Lython/Runtime/PyExecutableFunction.cs']", "assert set(changed)=={'src/Lokad.Lython/Runtime/PyExecutableFunction.cs','src/Lokad.Lython/Runtime/MemoryGovernor.cs'}")
s=s.replace('Only one production input changed; existing tests reused.','Only two production inputs changed; existing coverage plus four focused lifetime cases.')
ast.parse(s);(r/'check.py').write_text(s,encoding='utf-8',newline='\n')
