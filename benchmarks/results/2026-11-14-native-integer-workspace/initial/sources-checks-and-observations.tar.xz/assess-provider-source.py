from pathlib import Path
import hashlib,json,subprocess
r=Path('benchmarks/results/2026-11-14-regex-provider-capabilities');baseline=json.loads((r/'source-update-cd8eb5c7.json').read_text(encoding='utf-8'));repo='D:/code/utf8regex';head='8af3a56925866bd0f294fd431c522b64b5e025b2';files={}
for name,expected in baseline['integrationFiles'].items():
    body=subprocess.check_output(['git','-C',repo,'show',head+':src/Lokad.Utf8Regex.PythonRe/'+name]);files[name]=hashlib.sha256(body).hexdigest();assert files[name]==expected,name
changed=subprocess.check_output(['git','-C',repo,'diff','--name-only',baseline['sourceHead'],head,'--','src/Lokad.Utf8Regex.PythonRe'],text=True).splitlines();assert set(changed)=={'src/Lokad.Utf8Regex.PythonRe/PythonReScalarMatchState.cs','src/Lokad.Utf8Regex.PythonRe/README.md'}
d=dict(baseline,dateUTC='2026-11-14',sourceHead=head,baseline=baseline['sourceHead'],integrationFiles=files,changedIntegrationFiles=changed,implementationChange='Internal capture-root deadline-check cadence and captured-text decoder completion reuse. Three Lython-facing API entry blobs remain byte-identical; precise integration gaps unchanged. This is source contract inspection only, not qualification of those runtime changes.')
(r/'source-update-8af3a569.json').write_text(json.dumps(d,indent=2)+'\n',encoding='utf-8',newline='\n')
p=r/'README.md';p.write_text(p.read_text(encoding='utf-8')+'''
Read-only [8af3a569/dev92 source inspection](source-update-8af3a569.json) finds
internal capture-root deadline-check cadence and captured-text decoder completion
reuse. The same three API entry blobs and precise integration gaps are unchanged.
No package/source equivalence, semantics/interruption/performance/safety
qualification, normal adapter pin change or repeated dev80 checks follow.
Independent Lython implementation and adapter-local bridges remain available.
''',encoding='utf-8',newline='\n')
p=Path('PLAN.md');s=p.read_text(encoding='utf-8').replace('Source assessment through cd8eb5c7','Source assessment through 8af3a569');p.write_text(s,encoding='utf-8',newline='\n');print('Three API blobs unchanged through8af3a569; exact gaps retained, no repeated qualification/pin/core change.',flush=True)
