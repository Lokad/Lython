using System.Collections;
using System.Reflection;
using System.Runtime.Loader;
using System.Security.Cryptography;
using System.Text.Json;

// Reuse the existing read-only compiled-shape inspector, not a runtime tracer.
var path = Path.GetFullPath(args[0]);
var core = AssemblyLoadContext.Default.LoadFromAssemblyPath(path);
var engineType = core.GetType("Lokad.Lython.LythonEngine")!;
var engine = Activator.CreateInstance(engineType)!;
var compile = engineType.GetMethod("Compile", [typeof(string)])!;
using var catalog = JsonDocument.Parse(File.ReadAllText(args[1]));
var rows = new List<object>();
foreach (var item in catalog.RootElement.GetProperty("cases").EnumerateArray())
{
    if (item.GetProperty("id").GetString() is not ("scripts.csv-invoice.large" or "scripts.csv-fulfillment.large"
        or "diagnostic.loop-range.inside.large" or "scripts.file-search.large")) continue;
    using var script = (IDisposable)compile.Invoke(engine, [item.GetProperty("source").GetString()!])!;
    if (!(bool)Get(script, "IsValid")) throw new Exception("Invalid source");
    var runner = (Delegate)script.GetType().GetField("_runner", BindingFlags.Instance | BindingFlags.NonPublic)!.GetValue(script)!;
    var target = runner.Target!;
    var executable = target.GetType().GetFields(BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic)
        .Select(f => f.GetValue(target)).Single(v => v?.GetType().FullName == "Lokad.Lython.Frontend.ExecutableScript")!;
    var codeRows = new List<object>();
    Visit(Get(executable, "EntryPoint"));
    rows.Add(new { caseId = item.GetProperty("id").GetString(), code = codeRows });
    void Visit(object code)
    {
        var instructions = ((IEnumerable)Get(code, "Instructions")).Cast<object>().ToArray();
        var calls = ((IEnumerable)Get(code, "CallSites")).Cast<object>().ToArray();
        var callRows = new List<object>();
        for (var i = 0; i < instructions.Length; i++)
        {
            if (Get(instructions[i], "OpCode").ToString() != "Call") continue;
            var call = calls[(int)Get(instructions[i], "CallSiteIndex")];
            callRows.Add(new { instruction = i, arguments = Get(call, "ArgumentCount"), span = Get(call, "CallSpan"),
                inputStart = Get(instructions[i], "InputStart"),
                preceding = instructions[Math.Max(0, i - 4)..i].Select(v => new { op = Get(v, "OpCode").ToString(),
                    result = Get(v, "ResultSlot"), localResult = Get(v, "HasLocalResult") }).ToArray() });
        }
        codeRows.Add(new { name = Get(code, "Name"), valueCapacity = Get(code, "ValueStorageCapacity"),
            integerCapacity = Get(code, "NativeIntegerStorageCapacity"), nativeEligible = Get(code, "CanRunNativeInstructions"), calls = callRows });
        foreach (var function in (IEnumerable)Get(code, "Functions")) Visit(Get(function!, "CodeObject"));
    }
}
File.WriteAllText(args[2], JsonSerializer.Serialize(new { coreSHA256 = Convert.ToHexStringLower(SHA256.HashData(File.ReadAllBytes(path))),
    interpretation = "Read-only prepared storage/call shapes. Static occurrence and source ownership evidence only, no CPU or dynamic allocation attribution.", rows }, new JsonSerializerOptions { WriteIndented = true }));
Console.WriteLine("Recorded prepared native storage and call shapes; no runtime change or timing claim.");
static object Get(object target, string name) => target.GetType().GetProperty(name, BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic)!.GetValue(target)!;
