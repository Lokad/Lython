# Lokad.Lython 0.11.0

Updated 2026-11-14. Git-ignored; never force-add. Publication/tagging postponed.
Objective: coherent simplification and substantial complete-script performance,
including compile-once/run-once scripts. One experiment does not finish that
objective. Current contracts belong in `docs/`; history/evidence in
[EXPERIMENTS](benchmarks/EXPERIMENTS.md) and linked immutable results.

## Actual status

| State | Outcome / limits |
| --- | --- |
| Completed foundations | Shared compiler facts/nonlocal correction and lowered retention cleanup; direct UTF-8 formatting/storage; native helper returns; final argument slots/linear continuations; immutable builtin functions; owned/native loops, tuple returns and primitive working storage; shared arithmetic; CSV array adoption/shared keys; UTF-8 JSON/incremental XML. Preserve their correctness fixes and cached qualification. |
| Measurement gaps resolved within bounds | Helper returns: approximately 19–20% less allocation; original elapsed remains diagnostic. Formatting: allocation −8.67%, [controlled confirmation](benchmarks/results/2026-11-02-formatting-confirmation/README.md) supports report elapsed/CPU about −5–8%; original adverse 15.125 ms remains unexplained/preserved. Neither predicts current HEAD. |
| Fully qualified baseline | `98acaa5b` / `a4bfbfd8`, [43605198037 GREEN](benchmarks/results/2026-11-14-native-primitive-storage/delivery/README.md), all platforms/runtimes/original stress/installed consumers. Cached terminal/logs; never requery. R359 short/observed-helper and small JSON CPU debt stays explicit. |
| Latest external checkpoint | [B747](docs/BENCHMARKS.md), exact fa40/73a against stock CPython3.13.16: nine jobs/360.962s/all gates. Compile/warm/fresh/I/O/cleanup and source qualification separate, all adverse/variable observations retained. Full43625900419 independently pending. No unchanged replay or cross-collection attribution; R363 representative source gate next. |
| R360 withdrawn | [Frame primitive transport](benchmarks/results/2026-11-14-frame-primitive-storage/README.md) cuts allocation but regresses CSV/JSON/helpers. Entire migration removed, all 582 baseline inputs restored except independent matrix-routing fix. Retain public lifetimes/TypeError cases and meaningful callback refusal assertions. All original/refined failures/controls preserved; no dormant scalar frame backend. |
| R361 fully qualified | `3bc513b8` / frozen `ca1e2331`, [native-only range construction](benchmarks/results/2026-11-14-closed-range-construction/README.md): four inputs; ordinary router restored, constructors remain per execution. 176 final focused actual 11/10 checks, 70 Python controls, 16 worker goldens. Counter warm −31.8–33.2%, allocation −57.23%; short control adverse/variable, observed mixed. All 582 inputs match committed source. Full **43618009133 GREEN**, [receipt cached](benchmarks/results/2026-11-14-closed-range-construction/delivery/README.md); no requery. Later R362 excluded. |
| R362 committed; delivery active | Refined `73a1b233` [evidence](benchmarks/results/2026-11-14-range-iteration-stage/refined/README.md): counter warm −27.9–30.6%, fresh −27.6–27.9%, allocation −99.52%; generic cursor routes restored exactly. B745 text −2.1..+12.9% with 11.88% process spread. B746 bounded confirmation/all gates: −3.43..−0.07%; all six processes/image aggregate −1.33% elapsed/−1.55% CPU, descriptive only. Original adverse/cause remain; materialization allocation +1.26%. 142 further focused/90 Python controls/18 goldens/22 extreme checks pass; initial 536+2,298 preserved. Commit `fa40d674`, full **43625900419 active**; 582-input proof cached. B747 representative checkpoint complete/all gates; guide and raw evidence refreshed. |

## Prioritized deliverables

1. **Close R362 delivery and representative checkpoint.** Commit the retained
   three-file stage, prove all 582 frozen inputs, and batch Windows/Ubuntu actual
   .NET 11/10/original stress/installed Release consumers once. While CI runs,
   refresh the existing representative CPython checkpoint with separate compile,
   warm/fresh, I/O/validation/result cleanup/cache disposal boundaries. Preserve
   R359/R361 helper debt and R362 text uncertainty; no current external ratios
   inferred from earlier source. Completed CI receipts are cached, never requery.

2. **R362 retained: range iteration/boxed transport as one stage.** A shared explicit
   range enumerator replaces the generated `PyRange.Iterate` state machine.
   Existing cursor acquisition, position/EOF and cleanup serve object and native
   pulls. Native code uses primitive pulls only with already prepared integer
   working storage; no new compiler fact pass/array for unrelated loops.

   **Remove:** generated range MoveNext/object-current pipeline and per-yield
   boxes in eligible native numeric loops. Generic object iteration shares the
   same range state; do not retain a dormant alternate range engine.
   Keep PyRange's CLR/Python interfaces unchanged. Prefer one small iterable
   adapter and independent enumerators to global caches/thread-local reuse.
   Any added legacy acquisition cost must appear in materialization controls.
   Checked machine bounds/progression may use inline state; wider bounds and
   large-yield funding keep exact Python behavior. No new owner, pool, ledger,
   universal values, frame representation, controller or configuration.

   **Acceptance:** signed/int64/wider bounds/strides, empty/negative/huge lengths,
   stable identities/aliases, independent enumerators/Current/sticky EOF, explicit
   iterators, generators/closures, native-to-owned transfer, real I/O, early exit,
   cooperative cancellation, pre-effect first refusal/large-yield origin,
   retained results/shared-budget reuse and awaited cleanup. Preserve unsupported
   serialization/projection and generic object behavior. All surviving storage
   remains funded; no cumulative allocation counting or arbitrary reclamation.

   **Bound:** one coherent three-file prototype or concrete rejection. Focused
   actual .NET 11/10 and independent Python controls first; same-work counter
   warm/fresh, CSV, materializing range, short/observed controls on the quiet VM.
   Allocation separate from elapsed/CPU; decide retention/debt and delete displaced
   code. One current profile suffices for source selection; no new attribution
   inventory without a specific new question. Batch full delivery if retained.
   Initial/adverse B744 data and local archive-member failure stay preserved.
   Refined cursor creation/object pulls match baseline after removing only the
   added primitive method; no new generic route. B745 preserves all runtime
   images/catalogs/toolchains/floors. B745/B746 are terminal/cached; bounded confirmation supports retention with
   documented text uncertainty, not neutrality. No further unchanged replay.
   An obsolete 61 MB upload was compressed,
   SHA-verified and committed before retiring only its VM duplicate for space.

3. **Continue substantial representative-script redesigns.** Each selected design
   states hypothesis, eliminated stage/storage/code, affected scripts, semantic/
   ownership acceptance, bounded controls and final regression-debt decision.

   **R363 source gate complete; R364 selected:** [invoice/search profiles](benchmarks/results/2026-11-14-representative-call-cost/README.md)
   at fa40/73a find material helper entry work (including useful binding), not a
   missing generic frame. One synchronous activation owns fixed values/binding,
   execution and transfer cleanup across small/owned calls. **Delete StartInline
   and nullable BoundCallArguments handoff.** No controller/arena/pool/value model.
   Keep existing final slots, native optimization, managed stack, exact promotion,
   mutated defaults/protocols/receivers, evaluation/error order and suspended PC.
   Cancellation, first refusal, aliases and all cleanup remain funded/awaited.
   Focused actual11/10/Python controls, then one bounded complete search/invoice/
   text/JSON/counter/short/observed pair; separate allocation. Retain/debt or
   withdraw the whole stage; source-backed refinement allowed, no speed forecast.
   B748 failed before sampling; B749 corrected only collector inventory/preflight;
   both conditions and all raw/unknown/thread CPU remain. No further broad census.

   | Area / workloads | Evidence / selection standard |
   | --- | --- |
   | Calls/frames/operands / helpers, search, invoice | Final slots/native prefixes/tuple returns already remove packaging. Earlier owning profiles do not justify replaying slower call arenas/controllers. Remove a real remaining activation/copy; preserve defaults/keywords/receivers, closures, exact PCs, stack and genuine suspension. |
   | Records / CSV/JSON aggregates, reports | Bulk-record 6–8% evidence was reconsidered, not vetoed by threshold. R355 raw ranges were withdrawn for limited benefit/state/scratch costs; array adoption/shared keys remain. A new design must remove a complete stage and preserve callbacks, mutations/aliases, pre-effect admission and replacement overlap. |
   | Text / summary, search, report | Current casing/formatting already writes UTF-8 directly. Select a real conversion/build stage; profiles include useful mapping/probing. Preserve Unicode context/expansion, hooks, errors, token and funded output. |
   | Frontend / fresh scripts | Shared facts/lowered retention cleanup delivered. Invoice compile is about 0.1 ms versus 7–8 ms execution; pass count alone does not establish dominance. Remove demonstrated duplicate facts/IR, preserving scopes/nonlocals/diagnostics and admission. |

   Refresh representative CPython comparisons after a material retained milestone,
   separating compilation, warm execution, I/O, validation, result cleanup and
   compiled/cache disposal. Do not replay unchanged nine-job checkpoints for
   small corrections. R359/R361 call-heavy debt remains a release decision.

4. **Regex develops independently.** Core owns Python semantics, native UTF-8,
   original-subject windows, byte/scalar coordinates, captures/errors, explicit
   owners and active token. Development producers/adapter-local bridges remain
   acceptable; core stays backend-free. Optional non-packable adapter stays 0.4;
   completed dev80 checks cached. [Source assessment through cd8eb5c7](benchmarks/results/2026-11-14-regex-provider-capabilities/README.md)
   does not qualify package/safety/semantics/interruption/performance.
   Only affected final released-adapter checks wait for separately funded
   one-match scratch/escaping results, native UTF-8 group-name enumeration/copy,
   and token-independent cursor creation with cancellable preparation. Search
   filtering cannot implement anchored/fullmatch. Cached state never retains
   earlier tokens. These gaps stop no independent Lython implementation/testing.

## Measurement and lasting constraints

Simplification, allocation reduction and demonstrated CPU improvement are separate.
Timeouts/unstable controls/inconclusive data establish uncertainty. Allow bounded
confirmation/refinement/measurement correction when evidence justifies it; retain
all adverse samples and original failures. Percentages inform decisions rather
than vetoing useful changes. No blanket one-attempt/no-retiming/permanent rejection
rules and no open-ended campaign. Finish milestones with retention/debt or supported
withdrawal; the wider objective continues.

Use focused Release correctness/cancellation/ownership checks during iteration,
batch full platform/stress/installed consumers at meaningful checkpoints, and reuse
cached checks. Force nonincremental builds after restoration; freeze copies/verify
whole images. Persist/verify evidence before RAM teardown; keep current images,
catalogs/toolchains and 254/252 MiB VM floors. Startup, pending-I/O latency,
contention, heap/RSS peaks and embedding tail latency remain unmeasured.

[AGENTS.md](AGENTS.md) remains binding: fully managed/memory-safe, managed stack,
host mediation/original paths plus contained Cwd, cooperative host cancellation,
cycles, XML depth, checked bounds and bounded I/O chunks. No unsafe/Unsafe APIs,
pointers/PInvoke/native probing; no fuel/quotas, hidden caps/default allowance,
regex work/time policy, tracing, weak reclamation, forced GC or abandoned users.
Borrowed allowance funds capacity/overlap, retained aliases/results/caches and
pending users. First refusal is terminal with original structured origin; await
cleanup and never retry. Long streams use bounded host commands. Only core is
packaged; optional adapter is non-packable. Publication/tagging remain postponed.
