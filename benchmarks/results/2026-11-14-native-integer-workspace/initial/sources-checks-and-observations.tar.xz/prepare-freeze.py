from pathlib import Path
import ast
r=Path(__file__).parent;s=(r.parent/'helper-activation-r364/freeze.py').read_text(encoding='utf-8')
s=s.replace("assert changed==['src/Lokad.Lython/Runtime/PyExecutableFunction.cs']", "assert set(changed)=={'src/Lokad.Lython/Runtime/PyExecutableFunction.cs','src/Lokad.Lython/Runtime/MemoryGovernor.cs'}")
s=s.replace("['Separate StartInline activation entry','Nullable BoundCallArguments descriptor handoff between binding and execution']", "['Per-wide-native-call long[] allocation','Per-call native working-storage temporary reservation objects and resize/refund churn']")
s=s.replace('One existing fixed values buffer or already-owned workspace, binding semantics, native primitive storage, exact transfer PC, real continuation frame, active admission/stack/cancellation, deterministic cleanup.', 'Existing one-idle-workspace policy now serves private native long[] loans; fixed small stack words, binding, exact transfer PC, genuine I/O, active cancellation/admission and deterministic cleanup remain.')
s=s.replace('One native entry now declares the bounded fixed values buffer even for owned calls. Wider/short/observed/stack controls must expose regressions. No general frame/arena/value representation or performance forecast.', 'Native word capacity remains conservatively charged while idle until eviction/execution cleanup, including late active loans. Existing64+16*capacity estimate can deny earlier than the old32+8*capacity temporary estimate. No new allowance/controller/frame/value representation.')
s=s.replace("['scripts.csv-invoice.large','scripts.file-search.large','diagnostic.loop-helper.observed.large']", "['scripts.csv-invoice.large','scripts.csv-fulfillment.large','diagnostic.loop-helper.observed.large']")
s=s.replace('R364oneentry frozen','R365native workspace loan frozen')
s=s.replace("snippets.extend([", "snippets.append('def wide('+','.join('p'+str(i) for i in range(18))+'):\\n total=p0+p17\\n total*=2\\n return total\\nfor i in range(10):\\n assert wide('+','.join(str(i) for i in range(18))+')==34\\nprint(34)')\nsnippets.extend([")
ast.parse(s);(r/'freeze.py').write_text(s,encoding='utf-8',newline='\n')
