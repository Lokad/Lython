from pathlib import Path
import ast,base64,datetime,hashlib,json,subprocess,tarfile
r=Path(__file__).parent;out=r/'b751';out.mkdir();old=r.parent/'range-iteration-r362/refined/b745';source=json.loads((r/'candidate-identity.json').read_text(encoding='utf-8'));sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();assert all(sha(n)==h for n,h in source['sources'].items()) and json.loads((r/'python-controls.json').read_text(encoding='utf-8'))['complete'] and json.loads((r/'allocation-summary.json').read_text(encoding='utf-8'))['complete']
identity=dict(json.loads((old/'identity.json').read_text(encoding='utf-8')));identity.update(sourceRevision='R365uncommitted/frozen'+source['coreSHA256']['candidate'][:8]+' vs committedfa40d674/frozen73a1b233; baseline full43625900419 independent',purpose='Native integer working storage borrows existing one-idle-workspace lifetime policy. Remove per-wide-call long[]/temporary reservation allocation, retain conservative cache funding and active-user cleanup. Same complete fulfillment warm/fresh, invoice/text/JSON/short/observed controls. Allocation separate; no CPython or forecast.',coreSHA256={label:source['coreSHA256']['candidate'if label.startswith('candidate')else'reference']for label in ['reference','candidate','reference-control','candidate-control']},fullSourceIdentitySHA256=sha(r/'candidate-identity.json'),catalogSHA256=sha(r/'catalog.json'))
assert all(source['auxiliaryFiles'][role][n]==h for role in ['reference','candidate']for n,h in identity['auxiliaryFiles'].items());(out/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8',newline='\n')
jobs=[['scripts.csv-fulfillment.large', 'warm'], ['scripts.csv-fulfillment.large', 'compile-run'], ['scripts.csv-invoice.large', 'warm'], ['scripts.text-summary-helpers.nonlocal-counter.large', 'warm'], ['scripts.json-summary-helpers.large', 'warm'], ['diagnostic.loop-helper.short-zero.large', 'warm'], ['diagnostic.loop-helper.observed.large', 'warm']]
root='/home/lokad/lython-bench-checks/native-word-loan-b751-20261114';unit='lython-b751-native-word-loan-20261114'
for n in ['collect.py','archive-owned.py','run.sh','retrieve.py','summarize.py']:
    s=(old/n).read_text(encoding='utf-8').replace('range-complete-b745-20261114','native-word-loan-b751-20261114').replace('lython-b745-range-complete-20261114',unit).replace('B745','B751')
    if n=='collect.py':
        a=s.index('jobs=');b=s.index('\nenv =',a);s=s[:a]+'jobs='+repr(jobs)+'\nassert len(jobs)==7 and all(case in cases for case,lane in jobs)\n'+s[b:];s=s.replace('started < 300','started < 350').replace('Reserve60seconds','Reserve70seconds')
    elif n=='archive-owned.py':s=s.replace("len(raw['jobs'])==6","len(raw['jobs'])==7").replace('jobs=6','jobs=7')
    elif n=='retrieve.py':s=s.replace("['jobs']==6","['jobs']==7").replace("['elapsedSeconds']<360","['elapsedSeconds']<420").replace('B751 six-job','B751 seven-job')
    elif n=='summarize.py':s=s.replace("len(raw['jobs'])==6","len(raw['jobs'])==7").replace('jobs=6','jobs=7')
    if n.endswith('.py'):ast.parse(s)
    (out/n).write_text(s,encoding='utf-8',newline='\n')
(out/'prospective.json').write_text(json.dumps(dict(purpose=identity['purpose'],jobs=jobs,bound='One420sowner/350sstartguard,fourfreshprocesses/job,5sfullrequestwarmups/12stext,five0.5srotatingbatches,normalGC/tiering. Established worker/catalog protocol, exact outputs/files/budget/image/quiet/join/archive gates.',removed='Per-wide-helper long[]/temporary reservation objects removed; existing capacity-level workspace reuse retains all active/idle funding and allocation preflight/cancellation. No new allowance/controller/representation/framework.',stopping='One usable affected/control comparison or explicit uncertainty. Retain/debt/refine/withdraw from evidence, no automatic unchanged replay. Full platform/package qualification batched at coherent retention boundary; publication held.'),indent=2)+'\n',encoding='utf-8',newline='\n')
with tarfile.open(out/'payload.tgz','w:gz')as t:
    for n in ['identity.json','collect.py','archive-owned.py','run.sh','prospective.json']:t.add(out/n,arcname=n)
    t.add(r/'candidate-core.dll',arcname='candidate-core.dll');t.add(r/'catalog.json',arcname='representative.json')
with tarfile.open(out/'payload.tgz')as t:unpacked=sum(m.size for m in t.getmembers())
c=dict(root=root,sourceRoot='/home/lokad/lython-bench-checks/range-checkpoint-b747-20261114',unit=unit,identity=identity,payloadBytes=(out/'payload.tgz').stat().st_size,payloadSHA256=sha(out/'payload.tgz'),unpackedBytes=unpacked)
code=r'''from pathlib import Path
import ast,fcntl,hashlib,io,json,os,shutil,subprocess,sys,tarfile
c=CONFIG
base=Path('/home/lokad/lython-bench-checks').resolve();root=Path(c['root']);source=Path(c['sourceRoot']);sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert root.parent==base and source.parent==base and source.resolve()==source and not root.exists()
with(base/'comparison-vm.lock').open('a')as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record|[p]ython3.*cpython-worker.py'],capture_output=True).returncode==1
 assert(source/'exit-code.txt').read_text().strip()=='0' and json.loads((source/'archive-receipt.json').read_text())['complete'] and not(source/'guest-fixtures').exists()
 assert sha(source/'candidate/Lokad.Lython.dll')==c['identity']['coreSHA256']['reference']
 for name,digest in c['identity']['auxiliaryFiles'].items():assert sha(source/'candidate'/name)==digest
 payload=sys.stdin.buffer.read(c['payloadBytes']+1);assert len(payload)==c['payloadBytes'] and hashlib.sha256(payload).hexdigest()==c['payloadSHA256']
 before=shutil.disk_usage(base).free;assert before>254*1024*1024+c['unpackedBytes']+32768;root.mkdir()
 with tarfile.open(fileobj=io.BytesIO(payload),mode='r:gz')as t:t.extractall(root,filter='data')
 assert sha(root/'candidate-core.dll')==c['identity']['coreSHA256']['candidate'] and sha(root/'representative.json')==c['identity']['catalogSHA256']
 for role in ['reference','candidate']:
  (root/role).mkdir()
  for name in c['identity']['auxiliaryFiles']:os.link(source/'candidate'/name,root/role/name)
 os.link(source/'candidate/Lokad.Lython.dll',root/'reference/Lokad.Lython.dll');os.link(root/'candidate-core.dll',root/'candidate/Lokad.Lython.dll');os.link(source/'cpython-worker.py',root/'cpython-worker.py')
 for n in ['collect.py','archive-owned.py']:ast.parse((root/n).read_text())
 subprocess.run(['/bin/sh','-n',str(root/'run.sh')],check=True)
 fixture=root/'guest-fixtures';fixture.mkdir();assert shutil.disk_usage(base).free>254*1024*1024
 (root/'space-preflight.json').write_text(json.dumps(dict(beforeFreeBytes=before,afterFreeBytes=shutil.disk_usage(base).free,noRetirement=True,currentImagesCatalogsToolchainsPreserved=True,floorsUnchanged=True))+'\n')
 subprocess.run(['sudo','-n','mount','-t','tmpfs','-o','size=128m,mode=0700,uid=lokad,gid=lokad','lython-b751-fixtures',str(fixture)],check=True)
try:subprocess.run(['sudo','-n','systemd-run','--unit='+c['unit'],'--property=User=lokad','--property=WorkingDirectory='+str(root),'--property=RuntimeMaxSec=420','--property=TimeoutStopSec=30','--property=KillMode=control-group','/bin/sh',str(root/'run.sh')],check=True)
except BaseException:
 subprocess.run(['sudo','-n','umount',str(fixture)],check=True);fixture.rmdir();raise
print(subprocess.check_output(['systemctl','show',c['unit']+'.service','--property=ActiveState,MainPID,RuntimeMaxUSec'],text=True))
'''.replace('CONFIG',repr(c));ast.parse(code);(out/'launch-command.py').write_text(code,encoding='utf-8',newline='\n');(out/'config.json').write_text(json.dumps(c,indent=2)+'\n',encoding='utf-8',newline='\n')
(out/'launch-attempt.json').write_text(json.dumps(dict(attemptedUTC=datetime.datetime.now(datetime.timezone.utc).isoformat(),neverAutomaticallyRelaunch=True))+'\n',encoding='utf-8')
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73'];command="python3 -c 'import base64;exec(base64.b64decode(\""+base64.b64encode(code.encode()).decode()+"\"))'";done=subprocess.run(ssh+[command],input=(out/'payload.tgz').read_bytes(),capture_output=True,timeout=60);(out/'launch.log').write_bytes(done.stdout+done.stderr);assert done.returncode==0,(done.stdout+done.stderr).decode();now=datetime.datetime.now(datetime.timezone.utc);(out/'observe-not-before.json').write_text(json.dumps(dict(startedUTC=now.isoformat(),doNotObserveBeforeUTC=(now+datetime.timedelta(seconds=360)).isoformat(),ownerSeconds=420),indent=2)+'\n',encoding='utf-8',newline='\n');print(done.stdout.decode(),flush=True);print('Earliest observation',(now+datetime.timedelta(seconds=360)).isoformat(),flush=True)
