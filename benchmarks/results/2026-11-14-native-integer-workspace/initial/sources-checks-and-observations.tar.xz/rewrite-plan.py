from pathlib import Path
r=Path(__file__).parent;p=Path('PLAN.md');(r/'PLAN-before-checkpoint.md').write_bytes(p.read_bytes())
p.write_text('''# Lokad.Lython 0.11.0

Updated 2026-11-14. Git-ignored: never force-add. Publication/tagging postponed.
Objective: coherent simplification and substantial complete-script performance,
including compile-once/run-once. This objective stays open across individual
experiments. Current contracts belong in docs; history/evidence stays in
[EXPERIMENTS](benchmarks/EXPERIMENTS.md) and immutable linked results.

## Actual delivery status

| State | Outcome / limits |
| --- | --- |
| Completed foundations | Shared compiler facts/nonlocal correction and lowered retention cleanup; direct UTF-8 formatting/storage; native helper returns; final argument slots/linear continuations; immutable builtin functions; owned/native loops, tuple returns and primitive working storage; shared arithmetic; CSV adoption/shared keys; UTF-8 JSON/incremental XML. Preserve correctness fixes/cached qualification. |
| Closed measurement gaps | Helper returns: about19–20%less allocation, original elapsed diagnostic. Formatting: allocation−8.67%; [controlled confirmation](benchmarks/results/2026-11-02-formatting-confirmation/README.md) supports report elapsed/CPU−5–8%; original adverse15.125ms unexplained/preserved. Historical sources, not current HEAD. |
| Fully qualified current runtime | fa40d674/frozen73a1b233, [43625900419 GREEN](benchmarks/results/2026-11-14-range-iteration-stage/delivery/README.md): Windows/Ubuntu actual11/10,4,771internal+17,820public ordinary and original13/406stress each, installedRelease consumers.582sourceproof/16summaries/logs cached; never requery. Prior R359/R361 full receipts remain cached. |
| Retained R361/R362 | Native range construction keeps constructors per execution/ordinary router; shared explicit range state replaces generated iteration. R362 counter warm−27.9–30.6%,fresh−27.6–27.9%,allocation−99.52% versus R361; materialization allocation+1.26%. [All controls](benchmarks/results/2026-11-14-range-iteration-stage/refined/README.md): original text+12.91% preserved; bounded confirmation aggregate−1.33%elapsed/−1.55%CPU is descriptive, cause unresolved. No neutrality/universal/cumulative claim. |
| Representative CPython refreshed | [B747 guide](docs/BENCHMARKS.md), exact qualifiedfa40/73a versus stockCPython3.13.16, ninejobs360.962s/allgates. Invoicewarm1.26–1.31×,compile1.07–1.09×,fresh1.24–1.26×;text1.45–1.50×,JSON0.83–0.86×,search1.61–1.69×variable,report1.21–1.23×variable,fulfillment1.26–1.29×,for-CSV1.29–1.33×. Compile/warm/I/O/cleanup separate; old guides/adverse data retained. Counter gains do not predict these algorithms. |
| Withdrawn designs | [R360 frame scalar transport](benchmarks/results/2026-11-14-frame-primitive-storage/README.md) and [R364 merged activation](benchmarks/results/2026-11-14-helper-activation-entry/README.md) fully removed. R364allocationflat; invoicewarm+1.9–4.2%/JSON+1.3–3.0% withCPUadversity, searchuncertain.666focused/100Pythoncontrols/18goldens, then582restoredinputs/forcedbuilds/74checks preserved. No dormant routes; no permanent design ban. Preserve independent matrix/lifetime/refusal fixes. |
| Active R365 source selection | Read-only compiled-shape inspection at73a plus one short existing allocation diagnostic. Invoice price_line uses12existinginteger slots; only two private computed inputs precede its first rounding call. Fulfillment price uses23slots and currently allocates a long[]/temporary lease per row. Whole fulfillment6,745,180B/run;23-slot arrays alone884,736B/4,096rows, before lease objects. This is physical/source evidence, not measured CPU attribution. No prototype result yet. |

## Prioritized deliverables

1. **R365: consolidate native working-storage lifetime using existing reuse.**
   Reuse the current one-idle-workspace policy for a long[] loan, under the same
   execution owner/borrowed root. Small helpers retain their bounded managed stack
   words. **Remove** per-wide-helper long[] allocation and temporary reservation
   objects/admission churn on every row. No new allowance, owner hierarchy, pool
   framework, tracing, frame scalar representation, controller or configuration.

   **Ownership contract/tradeoff:** reserve full conservative capacity before new
   backing; keep old/replacement overlap funded. Idle cache remains charged until
   eviction or execution cleanup. Active loans survive ending idle reuse and
   refund only after their actual users end. Return after native materialization/
   transfer/disposal and binding cleanup. Existing generic workspace estimate may
   conservatively charge more than old8-byte words; document retention/earlier
   denial. Never refund still-borrowed storage or retry refused admission. Cache
   misses must preserve cancellation after admission and before allocation.

   **Acceptance:** repeated/nested wide helpers, reuse without stale values,
   aliases/results, exact promotion, real pending I/O transfer, cancellation and
   terminal first refusal before effects. Shared executions/budgets and cleanup
   return to baseline; late cleanup ends caches without abandoning active loans.
   Reuse focused actual11/10 coverage, add only missing lifetime assertions.
   Separate allocation, then bounded same-work fulfillment warm/fresh with invoice,
   text/JSON and short/observed controls on the quiet VM. Decide retention and debt
   or remove the whole migration. Batch full delivery at the next coherent
   retained checkpoint; do not repeat unchanged fa40 qualification.

2. **Continue call/operand redesign from proof, not source complexity.** R363
   [invoice/search profiles](benchmarks/results/2026-11-14-representative-call-cost/README.md)
   establish material native/ordinary dispatch and helper entry work, including
   useful operations. R364's simpler entry adds a fixed buffer to owned calls and
   widens its ABI; neither is a demonstrated causal CPU explanation. Existing
   split activation remains. Do not replay slower call arenas/controllers or
   ordinary-frame long arrays unchanged.

   **Next candidate after R365:** native-to-native operand publication. Source
   currently materializes private words before helper binding. First prove where
   stable identities/aliases require objects and quantify remaining private slots
   using existing compiled facts. Existing12/6-slot invoice helpers do not need
   new buffers. Only select a coherent ABI change if it removes a meaningful whole
   bridge; do not infer four private inputs or removable returned identities from
   Python source. No new fact pass/universal values/general frame rewrite.
   Semantic gate: defaults/keywords/receivers, repeated aliases, is/closures,
   unknown calls/protocols, wider overflow, exact transfer PC, callbacks/genuine I/O,
   managed stack, cancellation, first refusal and awaited funding. Complete
   invoice/fulfillment/search plus observed/short controls decide final debt.
   One offline proof to select a concrete stage or reject that hypothesis; no
   broad measurement campaign. Temporary redesign setbacks need an explicit
   completion milestone and final regression-debt decision.

3. **Other representative stages, evidence ordered.** Bulk CSV's original6–8%
   observations missed rigid historical gates; that is not a design rejection.
   Current code already bulk-admits fields/rows and shares/adopts keys/storage.
   R355's more recent raw-field-range design was reassessed with borrowed/escaped
   controls and withdrawn for limited benefit/state/scratch costs, not a fixed
   threshold. Keep failures/control regression and Python numeric/error timing.
   Current tuple construction copies directly to funded final backing and text
   reads share immutable windows: do not plan duplicate replacements. A selected
   collection/text redesign must remove a demonstrated conversion/build stage,
   preserve Unicode/hooks/aliases/reentry/overlap, and displace its old code.
   Frontend shared facts/retention cleanup is complete; invoicecompile≈0.1ms versus
   7–8msexecution does not support claiming passes dominate. Assess new expensive
   fresh-script shapes before selecting frontend consolidation. No heavyweight
   JIT, new benchmark framework or repeated unchanged nine-job snapshot.

4. **Regex development remains independent.** Core owns Python semantics, native
   UTF-8/original-subject windows, byte/scalar coordinates, captures/errors,
   explicit owners and current token. Development producers/adapter-local bridges
   are permitted; contract/semantic tests and backend performance stay distinct.
   Optional non-packable adapter remains0.4; completed dev80qualification cached.
   [Source assessment through cd8eb5c7](benchmarks/results/2026-11-14-regex-provider-capabilities/README.md)
   leaves only precise final released-adapter gaps: separately funded one-match
   scratch/escaping results, native UTF-8 group-name enumeration/copy, and token-
   independent cursor creation with cancellable preparation. Search filtering
   cannot replace anchored/fullmatch. Cached state never retains earlier tokens.
   These gaps defer only affected final adapter checks, not core development,
   correctness tests or independent performance work. No unchanged qualification.

## Evidence and lasting constraints

Architectural simplification, allocation reduction and demonstrated CPU gains are
separate. Timeouts/unstable unchanged controls/inconclusive measurements establish
uncertainty. Bounded confirmation/refinement/measurement correction is allowed when
evidence justifies it; preserve original failed conditions and every adverse point.
Percentages inform decisions, never automatically veto useful redesigns. No blanket
one-attempt/no-retiming/permanent-closure policy and no open-ended campaign. Finish
each milestone with retention/debt or supported withdrawal; the objective continues.

Focused Release correctness/cancellation/ownership during iteration; batch full
Windows/Ubuntu/bothframeworks/originalstress/installedconsumers at retained delivery
boundaries. Force nonincremental builds after restoration, freeze copies, prove
source/image identity. Cache terminal CI and space live queries240s apart. Persist
and verify evidence under its lease before RAM teardown; preserve current images/
catalog/toolchain and254/252MiBfloors. Startup, pending-I/O latency, contention,
heap/RSS peaks and embedding tail latency remain unmeasured.

[AGENTS.md](AGENTS.md) remains binding: fully managed/memory-safe; no unsafe/Unsafe,
pointers/PInvoke/native probes. Preserve managed stack, host mediation/original
paths plus contained Cwd, cooperative host cancellation, cycles/XMLdepth, checked
bounds/bounded I/O. No fuel/quotas, hidden caps/default allowances, regex work/time
policy, tracing, weak reclamation, forced GC or abandoned users. Borrowed allowance
funds capacity/overlap, retained aliases/results/caches and pending users. First
refusal is terminal with original structured origin; await cleanup, never retry.
Long streams use bounded host commands. Only core is packaged; adapter non-packable.
''',encoding='utf-8',newline='\n')
print('Concise0.11plan refreshed at full range-delivery safe checkpoint; R365explicit loan contract/deletions first, broader roadmap/regex independent.',flush=True)
