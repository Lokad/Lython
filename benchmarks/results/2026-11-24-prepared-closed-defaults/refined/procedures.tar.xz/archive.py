from pathlib import Path
import hashlib
import json
import shutil
import statistics
import subprocess
import tarfile

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
comparison = lab / 'comparison'
quiet = comparison / 'quiet'
output = repo / 'benchmarks/results/2026-11-24-prepared-closed-defaults/refined'
read = lambda path: json.loads(path.read_text(encoding='utf-8-sig'))
sha = lambda data: hashlib.sha256(data).hexdigest()
digest = lambda path: sha(path.read_bytes())
terminal = read(quiet/'terminal-status.json')
receipt = terminal['receipt']
assert not terminal['live'] and not terminal['fixtures'] and terminal['exitCode']=='0'
assert receipt['warmJobs']==6 and all(receipt[key] for key in (
    'complete','allWorkersJoined','guestFixturesRemoved','quietBeforeAndAfter','archivedAndVerifiedUnderLease'))
assert digest(quiet/'observations.tar.xz')==receipt['archiveSHA256']
assert '(4395008, 5410816, 11534336)' in (lab/'launch-insufficient-space.log').read_text(encoding='utf-8-sig')
compacted=[json.loads(line) for line in (lab/'compaction.jsonl').read_text(encoding='utf-8').splitlines()]
assert len(compacted)==3 and compacted[-1]['freeAfter']>=12*1024*1024
identity = read(comparison/'identity.json')
summary = read(quiet/'summary.json')
assert summary['timedBatches']==168 and summary['source']==identity['sourceRevision'] and summary['candidate']==identity['candidate']
assert [(r['case'],r['lane']) for r in summary['rows']]==[tuple(item) for item in read(comparison/'jobs.json')['warm']]
compiler_owner = {}
readiness = {}
for role, expected in identity['imageFiles'].items():
    assert len(expected)==32 and {path.name:digest(path) for path in (lab/role).iterdir()}==expected
    verified = read(comparison/(role+'-verify.json'))
    assert verified['caseCount']==6 and verified['state']=='Completed'
    assert verified['catalogSha256']==identity['catalogs']['representative.json']['sha256']
    assert verified['launched']['library']['sha256']==expected['Lokad.Lython.dll']
    for mode in ('sync','async'):
        rows = [json.loads(line) for line in (lab/f'oracle-{role}-{mode}.jsonl').read_text(encoding='utf-8').splitlines()]
        assert len(rows)==6 and all(row['Compared'] and row['Matches'] and row['Lython']['Success'] for row in rows)
    compiler_owner[role] = read(lab/f'{role}-compiler-owner.json')
    assert compiler_owner[role]['coreSHA256']==expected['Lokad.Lython.dll']
for host in ('windows','ubuntu'):
    readiness[host] = {}
    for suite, count in (('white',47),('public',199)):
        log = (lab/f'{host}-{suite}.log').read_text(encoding='utf-8-sig')
        assert f'Passed: {count:5d}' in log
        readiness[host][suite]=count
measures=[]
for ref,candidate in zip(compiler_owner['reference']['rows'],compiler_owner['candidate']['rows'],strict=True):
    assert ref['id']==candidate['id']
    measures.append(dict(case=ref['id'],allocatedBytes=[statistics.median(row['allocatedBytes']) for row in (ref,candidate)],
                         retainedAdmission=[row['retainedAdmission'] for row in (ref,candidate)]))
assert len(measures)==6
subprocess.run(['git','diff','--check',identity['sourceRevision'],identity['candidate'],'--','src','tests'], cwd=repo,check=True)
patch=subprocess.check_output(['git','diff','--binary',identity['sourceRevision'],identity['candidate'],'--','src','tests'],cwd=repo)
assert patch and patch.count(b'diff --git ')==4
(lab/'measured.patch').write_bytes(patch)
(lab/'compiler-owner-summary.json').write_text(json.dumps(measures,indent=2)+'\n',encoding='utf-8',newline='\n')
(lab/'focused-tests.json').write_text(json.dumps(readiness,indent=2)+'\n',encoding='utf-8',newline='\n')
output.mkdir(exist_ok=True)
for path in (comparison/'identity.json',quiet/'terminal-status.json',quiet/'summary.json',
             quiet/'observations.tar.xz',quiet/'storage-custody.json',lab/'allocation-summary-six.json',
             lab/'compiler-owner-summary.json',lab/'jit-summary.json',lab/'focused-tests.json',lab/'compaction.jsonl'):
    shutil.copyfile(path,output/path.name)
procedures = (
    'prepare.py','prepare-refinement.py','quiet.py','summarize.py','archive.py','oracle.py','oracle-input.json','test-ubuntu.sh',
    'compact-archived-cores.py','launch-insufficient-space.log',
    'compiler-owner/Program.cs','compiler-owner/Inspect.csproj','candidate-compiler-owner.json','reference-compiler-owner.json',
    'prepare-allocation.py','inspect-jit.py','candidate-runtime.asm','reference-runtime.asm','measured.patch',
    'comparison/candidate-verify.json','comparison/reference-verify.json','comparison/quiet/collect.py',
    'comparison/quiet/run.sh','comparison/quiet/launch.log','windows-frozen-build.log',
    'windows-white.log','windows-public.log','ubuntu-white.log','ubuntu-public.log',
    'oracle-reference-sync.jsonl','oracle-reference-async.jsonl','oracle-candidate-sync.jsonl','oracle-candidate-async.jsonl')
with tarfile.open(output/'procedures.tar.xz','w:xz') as archive:
    for item in procedures:
        archive.add(lab/item,arcname=item,recursive=False)
with tarfile.open(output/'procedures.tar.xz') as archive:
    assert {member.name:sha(archive.extractfile(member).read()) for member in archive} == {
       name:digest(lab/name) for name in procedures}
print('Archived B1607 with 168 verified timings, the exact patch and independent correctness receipts.')
