from pathlib import Path
import copy
import hashlib
import json
import os
import shutil
import subprocess
import tarfile

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
source = lab.with_name('prepared-closed-defaults-20261124') / 'source'
donor = lab.with_name('closed-capture-pair-seeded-20261124')
comparison = lab / 'comparison'
quiet = comparison / 'quiet'
quiet.mkdir(parents=True, exist_ok=True)
read = lambda path: json.loads(path.read_text(encoding='utf-8-sig'))
digest = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
write = lambda path, text: path.write_text(text, encoding='utf-8', newline='\n')
save = lambda path, value: write(path, json.dumps(value, indent=2) + '\n')
old_identity = read(donor / 'comparison/identity.json')
old_terminal = read(donor / 'comparison/quiet/terminal-status.json')['receipt']
assert old_terminal['complete'] and old_terminal['archivedAndVerifiedUnderLease']
assert digest(donor / 'comparison/quiet/observations.tar.xz') == old_terminal['archiveSHA256']
donor_image = donor / 'candidate'
old_files = old_identity['imageFiles']['candidate']
assert len(old_files) == 32 and {p.name:digest(p) for p in donor_image.iterdir()} == old_files
reference = subprocess.check_output(['git','rev-parse','f6d06f638'],cwd=repo,text=True).strip()
revision = subprocess.check_output(['git','rev-parse','HEAD'],cwd=source,text=True).strip()
assert revision.startswith('6816cfa1e')
assert not subprocess.check_output(['git','status','--porcelain'],cwd=source,text=True).strip()
subprocess.run(['git','diff','--exit-code',old_identity['candidate'],reference,'--','src','tests'],cwd=repo,check=True)
assert '0 Error(s)' in (lab / 'windows-frozen-build.log').read_text(encoding='utf-8-sig')
for host in ('windows','ubuntu'):
    for suite, count in (('white',47),('public',199)):
        assert f'Passed: {count:5d}' in (lab / f'{host}-{suite}.log').read_text(encoding='utf-8-sig')
core = lab / 'frozen-build/bin/Lokad.Lython/release_net11.0/Lokad.Lython.dll'
proved = {'reference':old_files.copy(), 'candidate':old_files|{core.name:digest(core)}}
for role, files in proved.items():
    image = lab / role
    image.mkdir(exist_ok=True)
    for name in files:
        shutil.copyfile(core if role=='candidate' and name == core.name else donor_image / name, image / name)
    assert {p.name:digest(p) for p in image.iterdir()} == files

shutil.copyfile(donor / 'comparison/representative.json', comparison / 'representative.json')
assert digest(comparison / 'representative.json') == old_identity['catalogs']['representative.json']['sha256']
jobs = read(donor / 'comparison/jobs.json')
profiles = ('scripts.rule-default-closures', 'scripts.annotated-rule-closures.nested-factories.postponed',
            'scripts.annotated-rule-closures', 'scripts.captured-rule-closures', 'scripts.csv-invoice.method-policy.quoted-control')
jobs['warm'] = [(case,'warm') for case in profiles]+[(profiles[0],'compile-run')]
save(comparison / 'jobs.json',jobs)
identity = dict(sourceRevision=reference, candidate=revision,
    purpose='Share prepared default writes while keeping the common call boundary free of a mutable cursor', imageFiles=proved,
    coreSHA256={label:proved[role][core.name] for role in proved for label in (role, role+'-control')},
    catalogs={name:dict(sha256=digest(comparison/name)) for name in ('representative.json','jobs.json')},
    expectedCPythonSHA256=old_identity['expectedCPythonSHA256'],cpythonWorkerSHA256=old_identity['cpythonWorkerSHA256'],
    donorArchiveSHA256=old_terminal['archiveSHA256'])
save(comparison / 'identity.json',identity)
old_verification = donor / 'comparison/candidate-verify.json'
shutil.copyfile(old_verification,comparison/'reference-verify.json')

sdk = Path.home()/'.dotnet11'
dotnet = sdk/'dotnet.exe'
environment = dict(os.environ, DOTNET_ROOT=str(sdk), DOTNET_ROOT_X64=str(sdk))
python_worker = repo/'benchmarks/cpython-worker.py'
assert digest(python_worker)==identity['cpythonWorkerSHA256']
subprocess.run([dotnet,lab/'candidate/Lokad.Lython.Benchmarks.dll','--compare','verify','--catalog',comparison/'representative.json',
    '--dotnet',dotnet,'--python','C:/Python313/python.exe','--python-worker',python_worker,'--out',comparison/'candidate-verify.json'],
    env=environment,cwd=repo,timeout=75,check=True)
for role, files in proved.items():
    result=read(comparison/(role+'-verify.json'))
    assert result['state']=='Completed' and result['caseCount']==6 and result['catalogSha256']==identity['catalogs']['representative.json']['sha256']
    assert result['launched']['library']['sha256']==files[core.name]
    assert {p.name:digest(p) for p in (lab/role).iterdir()}==files

collector=(donor/'comparison/quiet/collect.py').read_text(encoding='utf-8')
collector=collector.replace('b1603-fixtures','b1607-fixtures').replace('len(jobs) == 7','len(jobs) == 6')
collector=collector.replace('targetBatchSeconds=.50','targetBatchSeconds=.36').replace('counts[i]*.50','counts[i]*record[\'targetBatchSeconds\']')
collector=collector.replace('    for role, files in identity[\'imageFiles\'].items():\n        for name, sha in files.items():\n            assert digest(images[role]/name)==sha, (role,name)',
    '    for role, files in identity[\'imageFiles\'].items():\n        assert len(files)==32 and {p.name:digest(p) for p in images[role].iterdir()}==files, role')
compile(collector,'collect.py','exec')
write(quiet/'collect.py',collector)
shutil.copyfile(donor/'comparison/quiet/run.sh',quiet/'run.sh')
assert b'\r' not in (quiet/'run.sh').read_bytes()
with tarfile.open(quiet/'payload.tar.gz','w:gz',compresslevel=3) as package:
    for name in ('identity.json','representative.json','jobs.json'):
        package.add(comparison/name,arcname=name,recursive=False)
    for name in ('run.sh','collect.py'):
        package.add(quiet/name,arcname=name,recursive=False)
    package.add(lab/'candidate/Lokad.Lython.dll',arcname='candidate-core.dll',recursive=False)
config=dict(root='prepared-closed-defaults-refined-b1607-20261124',reference='closed-capture-seeded-b1603-20261124',
            payloadSHA256=digest(quiet/'payload.tar.gz'),payloadBytes=(quiet/'payload.tar.gz').stat().st_size)
save(quiet/'upload.json',config)

sources=read(donor/'verified-raw-replicas.json')
for row in sources:
    archive=repo/row['durableArchive']
    if not archive.is_file() or digest(archive)!=row['archiveSHA256']:continue
    tracked=subprocess.check_output(['git','show',f'origin/master:{row["durableArchive"]}'],cwd=repo)
    if hashlib.sha256(tracked).hexdigest()!=row['archiveSHA256']: continue
    with tarfile.open(archive) as package:
        member=package.extractfile('confirmation/confirmation.json')
        assert member is not None
        data=member.read()
        assert len(data)==row['bytes'] and hashlib.sha256(data).hexdigest()==row['rawSHA256']
    row['verifiedMember'] = True
sources=[row for row in sources if row.get('verifiedMember')]
assert len(sources)>15
save(lab/'verified-raw-replicas.json',sources)

launcher=(donor/'quiet.py').read_text(encoding='utf-8')
launcher=launcher.replace('lython-b1603-closed-capture-seeded','lython-b1607-prepared-closed-defaults-refined').replace('b1603-','b1607-')
launcher=launcher.replace("if (archived/'guest-fixtures').exists():continue", "if (archived/'guest-fixtures').exists() or not (archived/'archive-receipt.json').is_file():continue\n  archived_receipt=json.loads((archived/'archive-receipt.json').read_text())\n  if not archived_receipt.get('allWorkersJoined') or not archived_receipt.get('archivedAndVerifiedUnderLease'):continue")
launcher=launcher.replace("os.link(reference/'reference'/name,image/name)","os.link(reference/'candidate'/name,image/name)")
launcher=launcher.replace("assert donor['complete'] and digest(reference/'observations.tar.xz')==donor['archiveSHA256']",
    "assert donor['complete'] and digest(reference/'observations.tar.xz')==donor['archiveSHA256']\nassert donor['archiveSHA256']=="+repr(old_terminal['archiveSHA256']))
launcher=launcher.replace('seconds=405','seconds=309').replace('RuntimeMaxSec=460','RuntimeMaxSec=385')
compile(launcher,'quiet.py','exec')
write(lab/'quiet.py',launcher)
analyzer=(donor/'summarize.py').read_text(encoding='utf-8').replace('== 7\n','== 6\n').replace('timedBatches=196','timedBatches=168')
analyzer=analyzer.replace('len(warm["jobs"])==7','len(warm["jobs"])==len(jobs["warm"])')
compile(analyzer,'summarize.py','exec')
write(lab/'summarize.py',analyzer)
for name in ('prepare-allocation.py','inspect-jit.py'):
    shutil.copyfile(donor/name,lab/name)
print('Prepared six short complete-script lanes and six goldens.')