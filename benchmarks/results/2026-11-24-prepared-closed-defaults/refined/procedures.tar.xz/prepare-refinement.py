from pathlib import Path
import shutil

lab=Path(__file__).resolve().parent
initial=lab.with_name('prepared-closed-defaults-20261124')
read=lambda p:p.read_text(encoding='utf-8')
write=lambda path,text:path.write_text(text,encoding='utf-8',newline='\n')
prepare=read(initial/'prepare.py')
prepare=prepare.replace("source = lab / 'source'", "source = lab.with_name('prepared-closed-defaults-20261124') / 'source'")
prepare=prepare.replace("revision.startswith('bec00e82d')", "revision.startswith('6816cfa1e')")
a=prepare.index("assert len(jobs['warm'])"); b=prepare.index("save(comparison / 'jobs.json'",a)
prepare=prepare[:a]+'''profiles = ('scripts.rule-default-closures', 'scripts.annotated-rule-closures.nested-factories.postponed',
            'scripts.annotated-rule-closures', 'scripts.captured-rule-closures', 'scripts.csv-invoice.method-policy.quoted-control')
jobs['warm'] = [(case,'warm') for case in profiles]+[(profiles[0],'compile-run')]
'''+prepare[b:]
prepare=prepare.replace('Replace the duplicate direct definition readers with linked compiled default stores',
    'Share prepared default writes while keeping the common call boundary free of a mutable cursor')
prepare=prepare.replace('prepared-closed-defaults-b1606-', 'prepared-closed-defaults-refined-b1607-')
prepare=prepare.replace('lython-b1606-prepared-closed-defaults', 'lython-b1607-prepared-closed-defaults-refined')
prepare=prepare.replace("'b1606-'", "'b1607-'").replace("'b1606-fixtures'", "'b1607-fixtures'")
prepare=prepare.replace("'len(jobs) == 8'", "'len(jobs) == 6'").replace("'== 8\\n'", "'== 6\\n'")
prepare=prepare.replace("'timedBatches=224'", "'timedBatches=168'")
prepare=prepare.replace("launcher=launcher.replace('seconds=405','seconds=395')", "launcher=launcher.replace('seconds=405','seconds=309').replace('RuntimeMaxSec=460','RuntimeMaxSec=385')")
prepare=prepare.replace('Prepared eight short complete-script lanes', 'Prepared six short complete-script lanes')
assert 'RuntimeMaxSec=385' in prepare and 'len(jobs) == 6' in prepare
compile(prepare,'prepare.py','exec')
write(lab/'prepare.py',prepare)
for name in ('oracle.py','compiler-owner/Program.cs','compiler-owner/Inspect.csproj'):
    file=lab/name; file.parent.mkdir(parents=True,exist_ok=True); shutil.copyfile(initial/name,file)
archive=read(initial/'archive.py').replace("sourceRevision'],'", "sourceRevision'],'")
archive=archive.replace("/2026-11-24-prepared-closed-defaults'", "/2026-11-24-prepared-closed-defaults/refined'")
archive=archive.replace("'warmJobs']==8", "'warmJobs']==6").replace("['timedBatches']==224", "['timedBatches']==168")
archive=archive.replace('Archived B1606 with 224 verified timings', 'Archived B1607 with 168 verified timings')
compile(archive,'archive.py','exec')
write(lab/'archive.py',archive)
print('Prepared the bounded refinement procedures and archived-source checks.')