from pathlib import Path
import hashlib
import json
import shutil
import subprocess

lab=Path(__file__).resolve().parent
base=lab.with_name('closed-factory-pairs-entry-20261124')
area=lab/'allocation'
comparison=area/'comparison'
comparison.mkdir(parents=True,exist_ok=True)
read=lambda p:json.loads(p.read_text(encoding='utf-8'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
meta=read(lab/'comparison/identity.json')
helpers=read(base/'comparison/identity.json')['helperFiles']
for member in ('representative.json','identity.json'):
    shutil.copyfile(lab/'comparison'/member,comparison/member)
for role,files in meta['imageFiles'].items():
    dest=area/role
    dest.mkdir(exist_ok=True)
    for name,expected in (files|helpers).items():
        path=(base if name in helpers else lab)/role/name
        assert sha(path)==expected
        shutil.copyfile(path,dest/name)
    assert {p.name:sha(p) for p in dest.iterdir()}==files|helpers
shutil.copyfile(base/'allocations.py',area/'allocations.py')
subprocess.run(['C:/Python313/python.exe','-I','-X','utf8',area/'allocations.py'],check=True,timeout=95)
shutil.copyfile(area/'allocation-summary-six.json',lab/'allocation-summary-six.json')
