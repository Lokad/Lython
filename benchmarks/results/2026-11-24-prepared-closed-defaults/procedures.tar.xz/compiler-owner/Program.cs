using System.Security.Cryptography;
using System.Text.Json;
using Lokad.Lython;

using var catalog = JsonDocument.Parse(File.ReadAllBytes(args[0]));
var rows = new List<object>();
var engine = new LythonEngine();
foreach (var item in catalog.RootElement.GetProperty("cases").EnumerateArray())
{
    var source = item.GetProperty("source").GetString()!;
    var observed = new (long Bytes, long Admission)[9];
    for (int index = -6; index < observed.Length; index++)
    {
        var budget = new LythonMemoryBudget();
        var before = GC.GetAllocatedBytesForCurrentThread();
        long admission;
        using (var program = engine.Compile(source, budget))
        {
            if (!program.IsValid) throw new InvalidOperationException(string.Join("\n", program.Diagnostics));
            admission = budget.ReservedBytes;
        }
        var bytes = GC.GetAllocatedBytesForCurrentThread() - before;
        if (budget.ReservedBytes != 0) throw new InvalidOperationException("Compiler did not return allowance.");
        if (index >= 0) observed[index] = (bytes, admission);
    }
    rows.Add(new { id = item.GetProperty("id").GetString(),
        allocatedBytes = observed.Select(value => value.Bytes).ToArray(),
        retainedAdmission = observed.Select(value => value.Admission).Distinct().Single() });
}
var hash = Convert.ToHexStringLower(SHA256.HashData(File.ReadAllBytes(typeof(LythonEngine).Assembly.Location)));
File.WriteAllText(args[1], JsonSerializer.Serialize(new { coreSHA256 = hash, rows }, new JsonSerializerOptions { WriteIndented = true }));
