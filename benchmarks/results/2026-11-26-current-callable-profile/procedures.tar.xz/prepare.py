from pathlib import Path
import hashlib
import json
import os
import shutil
import subprocess
import tarfile

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
quiet = lab / 'comparison/quiet'
prior = lab.with_name('post-deferral-factory-cpu-20261126')
external = lab.with_name('post-row-cpython-20261126') / 'comparison/quiet'
donor = lab.with_name('fixed-row-local-bindings-20261126')
baseline = donor / 'comparison/quiet'
quiet.mkdir(parents=True)
read = lambda p:json.loads(p.read_text(encoding='utf-8'))
sha = lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
write = lambda p,s:p.write_text(s,encoding='utf-8',newline='\n')
save = lambda p,o:write(p,json.dumps(o,indent=2,ensure_ascii=False)+'\n')

def substitute(text, edits):
    for before, after in edits:
        assert text.count(before) == 1, before
        text = text.replace(before, after)
    return text

head = subprocess.check_output(['git','rev-parse','HEAD'], cwd=repo, text=True).strip()
snapshot = read(external / 'identity.json')
subprocess.run(['git','diff','--exit-code',snapshot['sourceRevision'],'--','src'], cwd=repo, check=True)
receipt = read(baseline / 'terminal-status.json')['receipt']
assert receipt['complete'] and receipt['allWorkersJoined'] and sha(baseline/'observations.tar.xz') == receipt['archiveSHA256']
assert snapshot['donorArchiveSHA256'] == receipt['archiveSHA256']
frozen = donor / 'local/candidate'
files = snapshot['imageFiles']['candidate']
assert len(files) == 32 and {p.name:sha(p) for p in frozen.iterdir()} == files

catalog = read(external/'representative.json')
profiles = [['ordinary-definitions','diagnostic.generated-ordinary-definitions','candidate'],
    ['escaping-defaulted-rules','scripts.rule-default-closures','candidate']]
catalog['cases'] = [next(c for c in catalog['cases'] if c['id']==case) for _,case,_ in profiles]
save(quiet/'catalog.json',catalog)
past = repo / 'benchmarks/results/2026-11-26-post-deferral-factory-cpu/observations.tar.xz'
with tarfile.open(past) as archive:
    prior_expanded = sum(m.size for m in archive if m.isfile())
assert prior_expanded == 1176687 and past.stat().st_size == 354348
identity = dict(sourceRevision=snapshot['sourceRevision'], inspectedHead=head, sourceDifference=[],
    imageFiles=dict(candidate=files),coreSHA256=dict(candidate=files['Lokad.Lython.dll']),
    profileCatalogSHA256=sha(quiet/'catalog.json'),cpythonWorkerSHA256=snapshot['cpythonWorkerSHA256'],
    donorArchiveSHA256=receipt['archiveSHA256'],expectedCPythonSHA256=snapshot['expectedCPythonSHA256'],
    referenceProfileFootprint=dict(expandedBytes=prior_expanded,archiveBytes=past.stat().st_size,minimumFreeAfterStaging=4194304),
    profiles=profiles,purpose='Locate remaining callable setup on the revision measured in B1784.')
save(quiet/'identity.json',identity)
template = prior / 'comparison/quiet'
for name in ('collect.py','ops-profile.py','analyze.py','run.sh'):
    source = (template/name).read_text(encoding='utf-8')
    if name == 'collect.py':
        assert source.count('boolean-increments-b1766-20261126') == 2
        source = source.replace('boolean-increments-b1766-20261126','fixed-row-local-bindings-b1783-20261126')
        source = substitute(source,[('b1769-fixtures','b1786-fixtures'),
            ('8*1024*1024-256*1024',"identity['referenceProfileFootprint']['minimumFreeAfterStaging']")])
    if name.endswith('.py'): compile(source,name,'exec')
    write(quiet/name,source)
assert b'\r' not in (quiet/'run.sh').read_bytes()

sdk = Path.home()/'.dotnet11'
worker = repo/'benchmarks/cpython-worker.py'
assert sha(worker)==identity['cpythonWorkerSHA256']
proof=quiet/'verification.json'
subprocess.run([sdk/'dotnet.exe',frozen/'Lokad.Lython.Benchmarks.dll','--compare','verify','--catalog',quiet/'catalog.json',
    '--dotnet',sdk/'dotnet.exe','--python','C:/Python313/python.exe','--python-worker',worker,'--out',proof],
    cwd=repo,env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk)),check=True,timeout=65)
saved=read(proof)
assert saved['state']=='Completed' and saved['caseCount']==2
assert saved['catalogSha256']==identity['profileCatalogSHA256']
assert saved['launched']['library']['sha256'] == files['Lokad.Lython.dll']

payload=quiet/'stage.tar.gz'
staged=('identity.json','catalog.json','collect.py','ops-profile.py','run.sh')
with tarfile.open(payload,'w:gz',compresslevel=6) as package:
    for name in staged: package.add(quiet/name,arcname=name,recursive=False)
save(quiet/'upload.json',dict(root='current-callable-profile-b1786-20261126',payloadSHA256=sha(payload),
    payloadBytes=payload.stat().st_size,expandedBytes=sum((quiet/name).stat().st_size for name in staged),
    expectedDonorArchiveSHA256=receipt['archiveSHA256']))
launch=substitute((prior/'quiet.py').read_text(encoding='utf-8'), [
    ('lython-b1769-post-deferral-factory-20261126','lython-b1786-current-callable-profile-20261126'),
    ('boolean-increments-b1766-20261126','fixed-row-local-bindings-b1783-20261126'),
    ("cfg['payloadBytes']+8*1024*1024", "cfg['payloadBytes']+cfg['expandedBytes']+4*1024*1024"),
])
compile(launch,'quiet.py','exec')
write(lab/'quiet.py',launch)
