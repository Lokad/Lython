from pathlib import Path
import re
base=Path('src/Lokad.Lython');runtime=base/'Runtime';front=base/'Frontend'
def read(p):return p.read_text(encoding='utf-8')
def write(p,s):p.write_text(s,encoding='utf-8',newline='\n')

# Existing native-body kind/type proof stays; the callable implementation has one
# immutable declaration shared with ordinary and exposed receiver calls.
p=runtime/'LythonRuntime.StringMembers.Basic.cs';s=read(p)
a=s.index('        private static readonly Func<PyString,');b=s.index('        internal static NativeReturnOperation?',a);s=s[:a]+s[b:]
a=s.index('        internal static Func<PyString,');b=s.index('        internal static ReceiverMethod? GetMethod',a);s=s[:a]+s[b:]
a=s.index('        internal static ReceiverMethod? GetMethod');b=s.index('        internal static PyString Lower',a)
seg=read(runtime/'LythonRuntime.StringMembers.Segmentation.cs');adv=read(runtime/'LythonRuntime.StringMembers.Advanced.cs')
segMap=seg[seg.index('        private static ReceiverMethod? GetSegmentationMethod'):];segMap=segMap[:segMap.index('        private static ValueTask')]
advMap=adv[adv.index('        private static ReceiverMethod? GetLayoutSearchMethod'):];advMap=advMap[:advMap.index('        private static ReceiverMethod CreatePaddingMethod')]
entries=re.findall(r'            "([^"]+)" => ([^,]+),',segMap+advMap)
entries += [('join','ReceiverMethods.StringJoin'),('replace','ReceiverMethods.StringReplace'),('startswith','ReceiverMethods.StringStartsWith'),('endswith','ReceiverMethods.StringEndsWith')]
kinds=[('strip','Strip',''),('lower','Lower','Lower'),('upper','Upper','Upper'),('islower','IsLower','IsLower'),('isupper','IsUpper','IsUpper'),('istitle','IsTitle','IsTitle'),('isalpha','IsAlpha','IsAlpha'),('isdigit','IsDigit','IsDigit'),('isalnum','IsAlnum','IsAlnum'),('isascii','IsAscii','IsAscii'),('isdecimal','IsDecimal','IsDecimal'),('isidentifier','IsIdentifier','IsIdentifier'),('isnumeric','IsNumeric','IsNumeric'),('isprintable','IsPrintable','IsPrintable'),('isspace','IsSpace','IsSpace')]
entries=[e for e in entries if e[0]!='strip']
entries += [(name,f'GetNoArgumentsMethod(NativeReturnOperation.{kind})')for name,kind,_ in kinds]
extras=[('capitalize','Capitalize'),('swapcase','SwapCase'),('title','Title'),('casefold','CaseFold')]
entries += [(name,'CasingMethods.'+op)for name,op in extras]+[('encode','EncodeMethod')]
assert len({n for n,_ in entries})==len(entries)
mapping='        internal static ReceiverMethod? GetMethod(string name)\n            => name switch\n            {\n'+''.join(f'                "{n}" => {v},\n'for n,v in entries)+'                _ => null,\n            };\n\n'
s=s[:a]+mapping+s[b:]
a=s.index('        internal static PyString Lower');b=s.index('        internal static PyString Replace',a);s=s[:a]+s[b:]
a=s.index('        private sealed class TextSemanticsMemberProvider');s=s[:a]+'''        private static readonly ReceiverMethod EncodeMethod = new(
            LythonCallableSignature.Create("str.encode", ["encoding", "errors"], 0),
            static (receiver, arguments, span, context) => Encode((PyString)receiver, arguments, span, context));

        private static object Encode(PyString text, ReadOnlyMemory<object?> arguments, LythonSourceSpan span, ExecutionContext context)
        {
            if (arguments.Length >= 1) RequireCodecNameType(arguments.Span[0]!, "str.encode()", "encoding", span);
            if (arguments.Length == 2) RequireCodecNameType(arguments.Span[1]!, "str.encode()", "errors", span);
            var encoding = arguments.Length >= 1 ? ParseTextEncoding(arguments.Span[0]!, "str.encode()", span) : TextEncodingMode.Utf8;
            var errors = arguments.Length == 2 ? ParseTextErrors(arguments.Span[1]!, "str.encode()", span) : TextErrorMode.Strict;
            return EncodeGuestBytes(text, encoding, errors, context, span);
        }
    }
}
''';write(p,s)
decl='''using Lokad.Lython.Frontend;
using Lokad.Lython.Runtime.Text;

namespace Lokad.Lython.Runtime;

internal sealed partial class LythonRuntime
{
    internal static partial class StringMembers
    {
        internal static ReceiverMethod GetNoArgumentsMethod(NativeReturnOperation kind)
            => CasingMethods.Native[(int)kind - (int)NativeReturnOperation.Strip];

        // Initialize shared declarations after the enclosing member inventory;
        // strip uses its existing optional-argument declaration in both paths.
        private static class CasingMethods
        {
            internal static readonly ReceiverMethod[] Native =
            [
                StripMethod,
'''
for name,kind,op in kinds[1:]:decl+=f'                new(LythonCallableSignature.Create("str.{name}", 0),\n                    static (receiver, _, span, context) => PyStringOps.{op}((PyString)receiver, context, span)),\n'
decl+='            ];\n\n'
for name,op in extras:decl+=f'            internal static readonly ReceiverMethod {op} = new(\n                LythonCallableSignature.Create("str.{name}", 0),\n                static (receiver, _, span, context) => PyStringOps.{op}((PyString)receiver, context, span));\n\n'
decl+='        }\n    }\n}\n';write(runtime/'LythonRuntime.StringMembers.Casing.cs',decl)
p=runtime/'LythonRuntime.StringMembers.Segmentation.cs';s=read(p);a=s.index('        internal static PyString StripWhitespace');b=s.index('        internal static PyList Split',a);s=s[:a]+s[b:];a=s.index('        private static ReceiverMethod? GetSegmentationMethod');b=s.index('        private static ValueTask',a);s=s[:a]+s[b:];write(p,s)
p=runtime/'LythonRuntime.StringMembers.Advanced.cs';s=read(p);a=s.index('        private static ReceiverMethod? GetLayoutSearchMethod');b=s.index('        private static ReceiverMethod CreatePaddingMethod',a);s=s[:a]+s[b:];write(p,s)
p=runtime/'LythonRuntime.StringMembers.cs';s=read(p);assert s.count('            TextSemanticsMemberProvider.Instance,')==1;write(p,s.replace('            TextSemanticsMemberProvider.Instance,\n',''))

p=runtime/'LythonRuntime.Members.cs';s=read(p);a=s.index('        internal static Func<PyDict,');b=s.index('        public static bool TryGetMember(PyDict dict',a)
decl=''
for name,view in [('keys','DictKeysView'),('values','DictValuesView'),('items','DictItemsView')]:
 decl+=f'''        private static readonly ReceiverMethod {view}Method = new(
            LythonCallableSignature.Create("dict.{name}", 0),
            static (receiver, _, span, context) =>
            {{
                using var storage = context.MemoryGovernor.ReserveTemporary(64L, span);
                context.CheckExecution(span);
                var view = new {view}((PyDict)receiver);
                storage.Commit(64L);
                return view;
            }});

'''
decl+='''        internal static ReceiverMethod? GetMethod(string name) => name switch
        {
            "get" => ReceiverMethods.DictionaryGet,
            "setdefault" => ReceiverMethods.DictionarySetDefault,
            "keys" => DictKeysViewMethod,
            "values" => DictValuesViewMethod,
            "items" => DictItemsViewMethod,
            _ => null,
        };

'''
s=s[:a]+decl+s[b:];a=s.index('        public static bool TryGetMember(PyDict dict');b=s.index('            value = name switch',a)
s=s[:b]+'''            if (GetMethod(name) is { } method)
            {
                value = method.Bind(dict);
                return true;
            }
'''+s[b:]
for name in ['get','setdefault','keys','values','items']:
 pattern=r'^                "'+name+r'" => (?:ReceiverMethods\.[^\n]+\.Bind\(dict\)|BoundCallable\.CreateNoArguments\(dict,[^\n]+),\n'
 s,n=re.subn(pattern,'',s,count=1,flags=re.M);assert n==1,name
write(p,s)

p=front/'ExecutableScript.Expressions.cs';s=read(p);a=s.index('            var nativeReceiver =');b=s.index('            var hasReceiver',a);s=s[:a]+s[b:];a=s.index('                AddInstruction(exitBlock, nativeReceiver');b=s.index('\n            }',a);s=s[:a]+'                AddInstruction(exitBlock, ExecutableInstruction.LoadCallMember(nameIndex, cacheIndex, member.Span));'+s[b:];write(p,s)
p=runtime/'LythonRuntime.Executable.Interpreter.cs';s=read(p);a=s.index('            object? operation = instruction.OpCode');b=s.index('            if (operation is null)',a);s=s[:a]+'''            object? operation = receiver switch
            {
                PyList when name == "append" => ReceiverMethods.ListAppend,
                PyDict => DictMembers.GetMethod(name),
                ExecutionContext.TextFileHandle when name == "write" => ReceiverMethods.TextWrite,
                ExecutionContext.BinaryFileHandle when name == "write" => ReceiverMethods.BinaryWrite,
                CsvWriterObject when name == "writerow" => ReceiverMethods.CsvWriterow,
                PyString => StringMembers.GetMethod(name),
                ReMatchObject => ReMatchMembers.GetMethod(name),
                _ => null,
            };
'''+s[b:];write(p,s)
p=runtime/'LythonRuntime.Executable.Calls.Invoke.cs';s=read(p);a=s.index('                    if (receiver is PyString text && target is Func<PyString');b=s.index('                    else return false;',a)
s=s[:a]+'''                    if (receiver is PyString or PyDict && target is ReceiverMethod method && method.AcceptsPositional(0))
                        result = InvokeReceiverMethod(method, receiver, ReadOnlyMemory<object?>.Empty, call.CallSpan, context);
'''+s[b:];write(p,s)
p=runtime/'LythonRuntime.Executable.NativeReturn.cs';s=read(p);s=s.replace('InvokeSingleInput(receiver, StringMembers.GetNoArgumentsOperation(value.Operation), site.CallSpan, context)','InvokeReceiverMethod(StringMembers.GetNoArgumentsMethod(value.Operation), receiver, ReadOnlyMemory<object?>.Empty, site.CallSpan, context)');write(p,s)

# All call-member loads now have the same operand shape and resolution contract.
for p in base.rglob('*.cs'):
 if {'bin','obj'}&set(p.parts):continue
 s=read(p)
 if 'LoadCallReceiver'not in s:continue
 s=s.replace('    LoadCallReceiver,\n','').replace('                case ExecutableOpCode.LoadCallReceiver:\n','')
 s=s.replace('ExecutableOpCode.LoadCallReceiver or ','').replace(' or ExecutableOpCode.LoadCallReceiver','')
 s=re.sub(r'    public static ExecutableInstruction LoadCallReceiver\([^\n]+\)\n        => new\([^\n]+\);\n\n','',s)
 assert 'LoadCallReceiver'not in s,p
 write(p,s)
p=Path('tests/Lokad.Lython.Tests/TextPredicateCancellationTests.cs');s=read(p).replace('StringMembers.GetNoArgumentsOperation(method)!','StringMembers.GetMethod(method)!').replace('operation(value, Span, context)','operation.Invoke(value, ReadOnlyMemory<object?>.Empty, Span, context)');write(p,s)
print('Canonical receiver declarations installed; typed call targets, special opcode/name heuristic and provider/family-routing scaffolding removed.')
