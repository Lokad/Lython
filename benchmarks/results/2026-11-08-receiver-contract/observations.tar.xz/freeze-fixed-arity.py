from pathlib import Path
import hashlib,json,os,shutil,subprocess
r=Path(__file__).resolve().parent;p=r/'fixed-arity';p.mkdir()
for n in ['catalog.json','independent-goldens.json']:shutil.copyfile(r/n,p/n)
for role in ['before','candidate']:shutil.copytree(r/'images/before',p/'images'/role,copy_function=os.link)
core=p/'images/candidate/Lokad.Lython.dll';core.unlink();shutil.copyfile('src/Lokad.Lython/bin/Release/net11.0/Lokad.Lython.dll',core)
inventory={str(f).replace('\\','/'):hashlib.sha256(f.read_bytes()).hexdigest()for f in Path('src/Lokad.Lython').rglob('*')if f.is_file()and not {'bin','obj'}&set(f.parts)}
(p/'identity.json').write_text(json.dumps(dict(baselineSource='91f15a3e',candidateSource='87862247 plus R85 canonical receivers/fixed-arity invocation',coreSHA256={role:hashlib.sha256((p/'images'/role/'Lokad.Lython.dll').read_bytes()).hexdigest()for role in ['before','candidate']},productionSources=inventory,qualification='2046public actual.NET11 after fixed-arity refinement; both-framework/internal final checks pending.'),indent=2)+'\n',encoding='utf-8')
(p/'source.patch').write_bytes(subprocess.check_output(['git','diff','--','src/Lokad.Lython','tests/Lokad.Lython.Tests/TextPredicateCancellationTests.cs']))
shutil.copyfile('src/Lokad.Lython/Runtime/LythonRuntime.StringMembers.Casing.cs',p/'LythonRuntime.StringMembers.Casing.cs')
(p/'measure.py').write_text((r/'measure.py').read_text(encoding='utf-8').replace("old=r.parent/'integer-utf8-r45'","old=r.parent.parent/'integer-utf8-r45'"),encoding='utf-8')
print('Fixed-arity source/cores frozen separately; original adverse source pair preserved.')
