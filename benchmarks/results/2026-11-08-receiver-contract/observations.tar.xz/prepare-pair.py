from pathlib import Path
import base64,copy,hashlib,json,os,shutil,struct,subprocess,tempfile
r=Path(__file__).resolve().parent;prior=r.parent/'operand-consumers-r82'
original=json.loads((prior/'catalog.json').read_text(encoding='utf-8'));byid={c['id']:c for c in original['cases']}
base=byid['scripts.text-summary-rsplit-helpers.large'];variants=[];goldens=[]
for method in ['casefold','title']:
 case=copy.deepcopy(base);case['source']=case['source'].replace('line.lower().rsplit()',f'line.{method}().split()');assert case['source']!=base['source']
 case['id']=f'scripts.text-summary-{method}-helpers.large';case['sourceSha256']=hashlib.sha256(case['source'].encode('utf-8')).hexdigest();case['sourceUtf8Bytes']=len(case['source'].encode('utf-8'))
 fixture=json.loads(case['fixtureJson'])
 with tempfile.TemporaryDirectory(prefix='lython-canonical-receiver-golden-')as folder:
  for name,value in fixture['inputFiles'].items():(Path(folder)/name).write_bytes(base64.b64decode(value))
  done=subprocess.run(['C:/Python313/python.exe','-I','-S','-X','utf8','-c',case['source']],cwd=folder,capture_output=True)
  assert done.returncode==0 and not done.stderr,(case['id'],done.stderr)
  case['expectedOutput']=done.stdout.decode('utf-8').replace('\r\n','\n');case['expectedOutputUtf8Bytes']=len(case['expectedOutput'].encode('utf-8'));case['expectedOutputSha256']=hashlib.sha256(case['expectedOutput'].encode('utf-8')).hexdigest()
  outputs={name:(Path(folder)/name).read_bytes()for name in fixture['outputFiles']}
  fixture['outputFiles']={name:base64.b64encode(data).decode('ascii')for name,data in outputs.items()}
  case['fixtureJson']=json.dumps(fixture,ensure_ascii=False);case['fixtureSha256']=hashlib.sha256(case['fixtureJson'].encode('utf-8')).hexdigest()
  h=hashlib.sha256();h.update(struct.pack('>i',len(outputs)))
  for name,data in sorted(outputs.items()):
   encoded=name.encode('utf-8');h.update(struct.pack('>i',len(encoded)));h.update(encoded);h.update(struct.pack('>i',len(data)));h.update(data)
  case['expectedFilesSha256']=h.hexdigest()
 assert not Path(folder).exists();variants.append(case);goldens.append(dict(case=case['id'],source=case['sourceSha256'],fullStdoutAndFiles=True,expectedFilesSHA256=case['expectedFilesSha256']))
d=copy.deepcopy(original);d['cases']=[*variants,base,byid['scripts.csv-summary-functions.large'],byid['scripts.report-render.large']];assert len(d['cases'])==5
for case in d['cases']:
 for field,digest in [('source','sourceSha256'),('fixtureJson','fixtureSha256'),('expectedOutput','expectedOutputSha256')]:assert hashlib.sha256(case[field].encode('utf-8')).hexdigest()==case[digest],(case['id'],digest)
(r/'catalog.json').write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');(r/'independent-goldens.json').write_text(json.dumps(goldens,indent=2)+'\n',encoding='utf-8')
for role in ['before','candidate']:shutil.copytree(prior/'images/candidate',r/'images'/role,copy_function=os.link)
p=r/'images/candidate/Lokad.Lython.dll';p.unlink();shutil.copyfile('src/Lokad.Lython/bin/Release/net11.0/Lokad.Lython.dll',p)
inventory={str(p).replace('\\','/'):hashlib.sha256(p.read_bytes()).hexdigest()for p in Path('src/Lokad.Lython').rglob('*')if p.is_file()and not {'bin','obj'}&set(p.parts)}
(r/'identity.json').write_text(json.dumps(dict(baselineSource='91f15a3e',candidateSource='87862247 plus R85 canonical receiver patch',coreSHA256={role:hashlib.sha256((r/'images'/role/'Lokad.Lython.dll').read_bytes()).hexdigest()for role in ['before','candidate']},productionSources=inventory,qualification='345internal first prototype,2046public actual.NET11 after explicit zero-argument signature correction; further focused/actual10/platform pending.'),indent=2)+'\n',encoding='utf-8')
(r/'source.patch').write_bytes(subprocess.check_output(['git','diff','--','src/Lokad.Lython','tests/Lokad.Lython.Tests/TextPredicateCancellationTests.cs']))
shutil.copyfile('src/Lokad.Lython/Runtime/LythonRuntime.StringMembers.Casing.cs',r/'LythonRuntime.StringMembers.Casing.cs')
(r/'measure.py').write_text((prior/'measure.py').read_text(encoding='utf-8'),encoding='utf-8')
print('Current source/cores frozen; five-case source pair with full independently generated CPython casefold/title file/stdout goldens and verified metadata hashes.')
