R85 coherent native receiver callable consolidation, baseline qualified91f15a3e.

Demonstrated source inconsistency: casing/predicates use typed zero-argument Func
targets, dictionary views use a second typed Func family, other native methods use
ReceiverMethod. The compiler selects LoadCallReceiver by method names solely for
those private delegate forms. casefold/capitalize/title/swapcase/encode go through
per-access provider closures and force a full context, although exact-string
zero-argument work cannot invoke guest protocols. R84 ordinary helper capture has
1107guest samples/5.58CPU-s,46unknown; no dominant binder allocation demonstrated.
No arena, tagged values, workspace bank or memory audit is selected.

Proposed simplification: canonical immutable ReceiverMethod declarations for string
text-semantics operations and dictionary views, shared by immediate calls, exposed
bound methods and existing native-return evaluation. One normal member-call load.
Remove typed Func call targets, their selection/accessors, LoadCallReceiver and
its compiler name heuristic, redundant method-name routing, TextSemantics provider
closures and orphaned wrappers. Preserve the existing native-body operation/type
proof and measured lower/upper split fusion; do not add per-name native-proof flags
or extend native-body eligibility merely to improve a selected benchmark.

Contract: no public API/intentional Python behavior change. Existing receiver,
argument, descriptor/metadata, keyword/arity/error and evaluation-order behavior
must hold. Dictionary-view factories keep preflight and rollback; current token,
first terminal admission refusal, retained aliases/caches/results, pending users,
awaited cleanup and managed stack admission remain. No new owner/pool/switch.

Affected complete scripts: ordinary casing/encoding helper reports; validate
casefold/title reports against CPython, plus rsplit, CSV and report controls.
Check immediate/exposed/unbound methods, all predicates/casing/encodings, Unicode
expansion/context, aliases and late binding, cancellation and refused admission.
Use focused Release tests and one existing five-case short source comparison;
one bounded quiet-VM confirmation if needed. Retain all adverse/failed conditions.
Decide retain/refine/reject from removed machinery, useful allocation and elapsed
observations; no fixed percentage veto or universal CPU claim. Batch full actual
11/10 Windows/Ubuntu, originalStress and installed consumers only on retention.
Publication stays postponed and independent regex development continues.

One controlled six-job source pair: casefold sync/async, title sync, rsplit sync,
CSV sync and report async. Source aa4acebe versus qualified4c072fed. Two old/two
candidate processes,5s warmup/role/job,seven rotated150ms rounds, normalGC/tiering,
quiet F4as_v7. Complete invocation/mediated RAM I/O/full validation/prior cleanup;
compile/startup/staging/reset/protocol/final cache teardown excluded. Actual
suspension/cancellation qualified separately. All source/core/aux/Ready/runtime/
golden/quiet/Closed/exit/join/fixture/archive gates retained; persistent evidence
separate owned128MiB RAM, archived underlease and verified locally.210s owner+
30stop+30margin;240MiB OS floor+7MiB evidence headroom. One byte-identical worker
companion library was atomically hardlinked under idle lease; all paths/bytes/
cores/sources/archives preserved with independent local proof.
Initial source6fdf allocation45–52%lower on affected scripts, rsplit desktop
elapsed+6–7%adverse preserved. Fixed-arity zero-argument call overload avoids empty
argument-memory transport within the same ReceiverMethod contract; no alternate
opcode, receiver-type dispatch or native-proof marker. Final desktop controls
remain variable/adverse(CSV+2.7–7.3%); no CPU claim before this confirmation.
Explicit retain/refine/reject and regression debt; objective/publication still open.
