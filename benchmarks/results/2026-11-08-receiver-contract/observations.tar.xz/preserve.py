from pathlib import Path
import hashlib,json,tarfile
r=Path(__file__).resolve().parent;out=Path('benchmarks/results/2026-11-08-receiver-contract');out.mkdir(exist_ok=True)
identity=json.loads((r/'fixed-arity/identity.json').read_text(encoding='utf-8'));assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==h for p,h in identity['productionSources'].items())
vm=json.loads((r/'b448/assessment.json').read_text(encoding='utf-8'));assert vm['complete']
d=dict(decision='Retain canonical receiver callable declarations and remove the special opcode/delegate target forms; fixed-arity invocation preserves zero-argument transport. No native-body eligibility expansion.',source=identity,focused=json.loads((r/'focused-final.json').read_text(encoding='utf-8')),vm=vm,limitations=['Rsplit control−0.90to+4.45%, candidate spread3.85%: inconclusive, possible adverse effect retained.','CSV−0.38to+2.70%, possible elapsed regression retained; earlier R76/R79/R82 debt remains separate.','Reportasync−4.14to−2.78%; no single mechanism attribution or universal CPU/CPython/embedding-tail claim.','Original6fdf desktop rsplit+6–7% and all variable/adverse original/refined observations retained.','Initial 17 semantic failures from minimum-only signature overload corrected with explicit fixed signatures and common no-argument diagnostics; original tests unchanged.','Full retained-source Windows/Ubuntu actual11/10/originalStress/installed qualification follows commit; focused checks are not that boundary.'])
(out/'assessment.json').write_text(json.dumps(d,indent=2)+'\n',encoding='utf-8')
with tarfile.open(out/'observations.tar.xz','w:xz')as a:
 for p in sorted(r.rglob('*')):
  if p.is_file()and not any(part in ['images','retrieved','__pycache__']for part in p.relative_to(r).parts)and p.name not in ['payload.tgz','current-core.dll','baseline-core.dll']:a.add(p,arcname=p.relative_to(r).as_posix())
 a.add(r/'images/candidate/Lokad.Lython.dll',arcname='original-prototype-core.dll')
with tarfile.open(out/'observations.tar.xz')as a:
 for m in a.getmembers():
  p=r/'images/candidate/Lokad.Lython.dll'if m.name=='original-prototype-core.dll'else r/m.name
  assert m.isfile()and hashlib.sha256(a.extractfile(m).read()).digest()==hashlib.sha256(p.read_bytes()).digest()
print('Canonical receiver source/cores/all original adverse, corrected signatures, focused checks and VM evidence archived and verified:',(out/'observations.tar.xz').stat().st_size)
