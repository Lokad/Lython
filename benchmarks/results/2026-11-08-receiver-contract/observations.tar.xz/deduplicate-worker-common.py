from pathlib import Path
import hashlib,json,subprocess
r=Path(__file__).resolve().parent;name='Microsoft.CodeAnalysis.dll';local=r/'images/before'/name;expected=hashlib.sha256(local.read_bytes()).hexdigest()
script=r'''from pathlib import Path
import fcntl,hashlib,json,os,shutil,stat,subprocess
base=Path('/home/lokad/lython-bench-checks');canonical=base/'method-binding-b441-20261108/candidate/Microsoft.CodeAnalysis.dll';note=base/'receiver-contract-b448-shared-worker-common.json'
with(base/'comparison-vm.lock').open('a')as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB);assert not note.exists()
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[c]ollector.dll|[p]erf record'],capture_output=True).returncode==1
 assert canonical.is_file()and not canonical.is_symlink()and hashlib.sha256(canonical.read_bytes()).hexdigest()=='DIGEST'
 reference=canonical.stat();before=shutil.disk_usage(base).free;changed=[];scanned=0
 for folder,dirs,files in os.walk(base,followlinks=False):
  if 'Microsoft.CodeAnalysis.dll'not in files:continue
  path=Path(folder)/'Microsoft.CodeAnalysis.dll';scanned+=1
  assert scanned<=256,'Bound this cleanup to one worker-library name.'
  if path.is_symlink()or not path.resolve().is_relative_to(base.resolve()):continue
  state=path.stat()
  if state.st_ino==reference.st_ino and state.st_dev==reference.st_dev:continue
  if state.st_size!=reference.st_size or stat.S_IMODE(state.st_mode)!=stat.S_IMODE(reference.st_mode):continue
  if hashlib.sha256(path.read_bytes()).hexdigest()!='DIGEST':continue
  temporary=path.with_name(path.name+'.b448-dedup.tmp');assert not temporary.exists()
  try:
   os.link(canonical,temporary);os.replace(temporary,path)
  finally:
   if temporary.exists():temporary.unlink()
  assert hashlib.sha256(path.read_bytes()).hexdigest()=='DIGEST'
  changed.append(dict(path=str(path),previousInode=state.st_ino,previousMtimeNs=state.st_mtime_ns,newInode=path.stat().st_ino))
  if shutil.disk_usage(base).free-before>=48*1024*1024:break
 assert hashlib.sha256(canonical.read_bytes()).hexdigest()=='DIGEST'
 result=dict(library=canonical.name,sha256='DIGEST',canonical=str(canonical),beforeFreeBytes=before,afterFreeBytes=shutil.disk_usage(base).free,scannedPaths=scanned,changed=changed,allOriginalPathsAndBytesRetained=True,independentLocalBytesVerified=True,ownedLease=True,noActiveWorkersOrCollectors=True,scope='Deduplicate one byte-identical managed worker library using atomic hardlink replacement; no source/core/archive/data deletion. Existing measurements continue to identify identical bytes.')
 note.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
'''.replace('DIGEST',expected)
compile(script,'dedup','exec');(r/'deduplicate-common-command.py').write_text(script,encoding='utf-8')
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
p=subprocess.run(ssh+['python3 -'],input=script,text=True,encoding='utf-8',capture_output=True);(r/'deduplication.log').write_text(p.stdout+'\n'+p.stderr,encoding='utf-8');assert p.returncode==0,p.stderr
(r/'shared-worker-common.json').write_text(p.stdout,encoding='utf-8');d=json.loads(p.stdout);print(json.dumps({k:d[k]for k in ['library','beforeFreeBytes','afterFreeBytes','scannedPaths','allOriginalPathsAndBytesRetained']}));print('Changed paths',len(d['changed']))
