from pathlib import Path
import ast,hashlib,json,shutil,tarfile
r=Path(__file__).resolve().parent;b=r/'b448';b.mkdir();old=r.parent/'operand-consumers-r82/b445';pair=r/'fixed-arity'
jobs=[['scripts.text-summary-casefold-helpers.large','warm'],['scripts.text-summary-casefold-helpers.large','warm-async'],['scripts.text-summary-title-helpers.large','warm'],['scripts.text-summary-rsplit-helpers.large','warm'],['scripts.csv-summary-functions.large','warm'],['scripts.report-render.large','warm-async']]
for n in ['collect.py','run.sh','retrieve.py','assess-vm.py','archive-owned.py','launch.py']:
 s=(old/n).read_text(encoding='utf-8').replace('operand-consumers-b445-20261108','receiver-contract-b448-20261108').replace('lython-b445-operand-consumers','lython-b448-receiver-contract').replace('operand-consumers-b445-launch.py','receiver-contract-b448-launch.py')
 if n=='collect.py':
  a=s.index('jobs=');z=s.index('\nassert len(jobs)',a);s=s[:a]+'jobs='+repr(jobs)+s[z:];s=s.replace('R82 prepared single-input consumers; affected complete scripts, report and identical-instruction arithmetic control','R85 canonical receiver callable consolidation with fixed-arity zero-argument invocation; casefold/title affected, rsplit/CSV/report controls')
 if n=='launch.py':s=s.replace("reference=base/'native-workstate-b443-20261108/candidate'","reference=base/'combined-cpython-b446-20261108/candidate'")
 s=s.replace('shared-worker-library.json','shared-worker-common.json')
 (b/n).write_text(s,encoding='utf-8',newline='\n')
 if n.endswith('.py'):ast.parse(s)
d=json.loads((pair/'identity.json').read_text(encoding='utf-8'));assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==h for p,h in d['productionSources'].items())
base=json.loads((old/'identity.json').read_text(encoding='utf-8'))
identity=dict(sourceRevision=d['candidateSource'],baselineSource='91f15a3e fully qualified CI42451722109',coreSHA256={role:d['coreSHA256']['before'if role.startswith('reference')else'candidate']for role in ['reference','reference-control','candidate','candidate-control']},auxiliaryFiles=base['auxiliaryFiles'],productionSources=d['productionSources'],baselineProductionSources=json.loads((r.parent/'operand-consumers-r82/identity.json').read_text(encoding='utf-8'))['productionSources'],jobs=jobs,included=base['included'],qualification='2046public actual.NET11 final refinement,345internal initial prototype; final focused actual11/10/platform pending. No new producer qualification.')
(b/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8')
(r/'focused-pre-vm.json').write_text(json.dumps(dict(net11Public=2046,net11InternalInitial=345,net10='pending',candidateCore=d['coreSHA256']['candidate']),indent=2)+'\n',encoding='utf-8')
for src,name in [(pair/'images/candidate/Lokad.Lython.dll','current-core.dll'),(pair/'images/before/Lokad.Lython.dll','baseline-core.dll'),(pair/'catalog.json','representative.json'),(pair/'source.patch','source.patch'),(r/'focused-pre-vm.json','focused.json'),(Path('PLAN.md'),'pre-measurement-plan.md'),(r/'shared-worker-common.json','shared-worker-common.json')]:shutil.copyfile(src,b/name)
contract=(r/'selection.md').read_text(encoding='utf-8')+'''
One controlled six-job source pair: casefold sync/async, title sync, rsplit sync,
CSV sync and report async. Source aa4acebe versus qualified4c072fed. Two old/two
candidate processes,5s warmup/role/job,seven rotated150ms rounds, normalGC/tiering,
quiet F4as_v7. Complete invocation/mediated RAM I/O/full validation/prior cleanup;
compile/startup/staging/reset/protocol/final cache teardown excluded. Actual
suspension/cancellation qualified separately. All source/core/aux/Ready/runtime/
golden/quiet/Closed/exit/join/fixture/archive gates retained; persistent evidence
separate owned128MiB RAM, archived underlease and verified locally.210s owner+
30stop+30margin;240MiB OS floor+7MiB evidence headroom. One byte-identical worker
companion library was atomically hardlinked under idle lease; all paths/bytes/
cores/sources/archives preserved with independent local proof.
Initial source6fdf allocation45–52%lower on affected scripts, rsplit desktop
elapsed+6–7%adverse preserved. Fixed-arity zero-argument call overload avoids empty
argument-memory transport within the same ReceiverMethod contract; no alternate
opcode, receiver-type dispatch or native-proof marker. Final desktop controls
remain variable/adverse(CSV+2.7–7.3%); no CPU claim before this confirmation.
Explicit retain/refine/reject and regression debt; objective/publication still open.
'''
(b/'contract.md').write_text(contract,encoding='utf-8');(b/'setup-contract.json').write_text(json.dumps(dict(jobs=jobs,ownerSeconds=210,stopSeconds=30,marginSeconds=30,osFreeFloorMiB=240,evidenceHeadroomMiB=7),indent=2)+'\n',encoding='utf-8')
with tarfile.open(b/'payload.tgz','w:gz')as a:
 for name in ['collect.py','run.sh','current-core.dll','baseline-core.dll','representative.json','identity.json','pre-measurement-plan.md','setup-contract.json','contract.md','focused.json','source.patch','shared-worker-common.json','archive-owned.py']:a.add(b/name,arcname=name)
print('One exact six-job source-pair confirmation prepared; original defects, adverse prototype and refinement retained.')
