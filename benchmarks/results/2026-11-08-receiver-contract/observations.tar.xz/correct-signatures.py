from pathlib import Path
import re
p=Path('src/Lokad.Lython/Runtime/LythonRuntime.StringMembers.Casing.cs');s=p.read_text(encoding='utf-8')
s,n=re.subn(r'LythonCallableSignature.Create\(("str\.[^"]+"), 0\)',r'LythonCallableSignature.Create(\1, [])',s);assert n==18,n
p.write_text(s,encoding='utf-8',newline='\n')
p=Path('src/Lokad.Lython/Runtime/LythonRuntime.Members.cs');s=p.read_text(encoding='utf-8')
s,n=re.subn(r'LythonCallableSignature.Create\(("dict\.(?:keys|values|items)"), 0\)',r'LythonCallableSignature.Create(\1, [])',s);assert n==3,n
p.write_text(s,encoding='utf-8',newline='\n')
for name in ['LythonRuntime.Executable.Interpreter.cs','LythonRuntime.Executable.Interpreter.Async.cs']:
 p=Path('src/Lokad.Lython/Runtime')/name;s=p.read_text(encoding='utf-8').replace('instruction.OpCode is not (ExecutableOpCode.LoadCallMember)','instruction.OpCode != ExecutableOpCode.LoadCallMember').replace('instruction.OpCode is ExecutableOpCode.LoadCallMember','instruction.OpCode == ExecutableOpCode.LoadCallMember');p.write_text(s,encoding='utf-8',newline='\n')
print('Explicit fixed zero-argument signatures installed, original public regressions retained unchanged.')
