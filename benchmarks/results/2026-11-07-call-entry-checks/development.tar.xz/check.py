from pathlib import Path
import hashlib,json,os,shutil,subprocess
r=Path(__file__).parent
env=os.environ.copy();env['DOTNET_ROOT']='C:/Users/JoannesVermorel/.dotnet11';env['DOTNET_HOST_PATH']=env['DOTNET_ROOT']+'/dotnet.exe';env['PATH']=env['DOTNET_ROOT']+os.pathsep+env['PATH']
filters={
 'Lokad.Lython.Tests':'Category!=Stress&('+'|'.join('FullyQualifiedName~'+n for n in ['InstructionFailureRouting','SimpleFunctionExecutionBoundary','CompletedHelperCallOwnership','DirectOperandOwnership','LocalAugmentedLifetime','NativeReturn','CallArgumentEvaluation','NativeCall','Constructor'])+')',
 'Lokad.Lython.PublicApi.Tests':'Category!=Stress&('+'|'.join('FullyQualifiedName~'+n for n in ['NativeCallback','ReceiverMethodSemantics','Constructor','MethodExposure','FileWriteCall','CsvWriterowCall','Cancellation','IntegerText','IntCall'])+')'}
checks={}
for project,selection in filters.items():
 name=project+'-net11.0.log'
 with (r/name).open('w',encoding='utf-8') as log:
  done=subprocess.run([env['DOTNET_HOST_PATH'],'test',f'tests/{project}/{project}.csproj','-c','Release','-f','net11.0','--filter',selection,'--nologo','-v','quiet'],env=env,stdout=log,stderr=subprocess.STDOUT)
 result=(r/name).read_text(encoding='utf-8')[-1500:];checks[name]=dict(exitCode=done.returncode,selection=selection,summary=result)
 print(project,done.returncode,result[-700:],flush=True);assert done.returncode==0,result
core=Path('src/Lokad.Lython/bin/Release/net11.0/Lokad.Lython.dll');(r/'candidate/net11.0').mkdir(parents=True)
shutil.copy2(core,r/'candidate/net11.0/Lokad.Lython.dll')
(r/'focused.json').write_text(json.dumps(dict(checks=checks,coreSHA256=hashlib.sha256(core.read_bytes()).hexdigest(),target='net11.0',fullDeliveryPending=True),indent=2)+'\n',encoding='utf-8',newline='\n')
