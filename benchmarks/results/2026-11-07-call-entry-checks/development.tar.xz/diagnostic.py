from pathlib import Path
import hashlib,json,os,shutil,subprocess
r=Path(__file__).parent;prior=r.parent/'operand-sources-r43';old=r.parent/'builtin-methods-r41'
env=os.environ.copy();env['DOTNET_ROOT']='C:/Users/JoannesVermorel/.dotnet11';env['DOTNET_HOST_PATH']=env['DOTNET_ROOT']+'/dotnet.exe';env['PATH']=env['DOTNET_ROOT']+os.pathsep+env['PATH']
for role,core in [('before',r/'baseline/net11.0/Lokad.Lython.dll'),('candidate',r/'candidate/net11.0/Lokad.Lython.dll')]:
 target=r/'images'/role;shutil.copytree(prior/'images/final',target,copy_function=os.link)
 (target/'Lokad.Lython.dll').unlink();shutil.copy2(core,target/'Lokad.Lython.dll')
shutil.copy2(prior/'catalog.json',r/'catalog.json')
folder=r/'warm-sync';folder.mkdir();witness=folder/'hash-witness.json';shutil.copy2(prior/'warm-sync/hash-witness.json',witness)
with (folder/'measurements.json').open('w',encoding='utf-8') as out,(folder/'stderr.txt').open('w',encoding='utf-8') as err:
 done=subprocess.run([env['DOTNET_HOST_PATH'],str(old/'tool/out/complete-jobs.dll'),str(r/'images/before/Lokad.Lython.Benchmarks.dll'),str(r/'images/candidate/Lokad.Lython.Benchmarks.dll'),str(r/'catalog.json'),str(witness),'reverse','warm','sync'],env=env,stdout=out,stderr=err)
assert done.returncode==0,(folder/'stderr.txt').read_text(encoding='utf-8')[-2000:]
data=json.loads((folder/'measurements.json').read_text());assert all(data[k] for k in ['allGoldensPassed','allBalancesZero','ownedFixturesRemoved','imageIsolationVerified'])
print('One short existing four-script diagnostic: all goldens/funding/isolation/cleanup pass. Desktop elapsed only; no VM campaign.')
