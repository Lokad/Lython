from pathlib import Path
import hashlib,json,re,shutil,subprocess
r=Path(__file__).parent
head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();assert head.startswith('5fb25354')
assert not subprocess.check_output(['git','diff','--','src'],text=True)
baseline=json.loads((r.parent/'operand-sources-r43/delivery-focused.json').read_text())
for target,digest in baseline['coreSHA256'].items():
 p=Path('src/Lokad.Lython/bin/Release',target,'Lokad.Lython.dll');assert hashlib.sha256(p.read_bytes()).hexdigest()==digest
 (r/'baseline'/target).mkdir(parents=True);shutil.copy2(p,r/'baseline'/target/p.name)
p=Path('src/Lokad.Lython/Runtime/LythonRuntime.Calls.cs');source=p.read_text(encoding='utf-8')
pattern=r'(        context\.EnterInterpreterFrame\((span|callSpan)\);\n        try\n        \{\n)            context\.CheckExecution\(\2\);\n'
sites=[source[:m.start()].count('\n')+1 for m in re.finditer(pattern,source)]
replacement,count=re.subn(pattern,r'\1',source)
assert count==12,sites
identity=dict(baselineSource=head,baselineCoreSHA256=baseline['coreSHA256'],sourceBeforeSHA256=hashlib.sha256(p.read_bytes()).hexdigest(),removedDuplicateCallLines=sites,
 sourceProof='EnterInterpreterFrame first checks refusal/token, then managed nesting/stack; immediate body duplicate has no intervening guest/admission/await. Constructor check after PyInstance allocation stays. Per-instruction/loop/long-operation/resume/publication checks stay.',
 qualification='R43 focused checks pass; full42365045704 still in progress. No performance claim.')
(r/'before.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8',newline='\n');shutil.copy2('PLAN.md',r/'pre-code-plan.md')
(r/'calls-before.cs').write_bytes(p.read_bytes());p.write_text(replacement,encoding='utf-8',newline='\n')
print('Deleted',count,'immediate duplicate checks. Managed stack/frame entry, finally, constructor/post-admission and opcode checks unchanged.')
