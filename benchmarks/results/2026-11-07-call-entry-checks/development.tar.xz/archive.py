from pathlib import Path
import hashlib,json,statistics,subprocess,tarfile
r=Path(__file__).parent;out=Path('benchmarks/results/2026-11-07-call-entry-checks');out.mkdir()
data=json.loads((r/'warm-sync/measurements.json').read_text());rows=[]
for item in data['observations']:
 grouped={k:[s for s in item['samples'] if s['image']==k]for k in ['before','candidate','before-control']}
 med=lambda role,key:statistics.median(s[key]/s['jobs'] for s in grouped[role])
 rows.append(dict(case=item['caseId'],allocatedBytes={role:med(role,'allocatedBytes')for role in grouped},elapsedMilliseconds={role:med(role,'elapsedMilliseconds')for role in grouped},admittedPeaks=item['admittedPeaks']))
summary=dict(rows=rows,allGoldensPassed=data['allGoldensPassed'],allBalancesZero=data['allBalancesZero'],ownedFixturesRemoved=data['ownedFixturesRemoved'],imageIsolationVerified=data['imageIsolationVerified'],limitation='One short existing complete-job diagnostic; desktop clocks/process GC/ALCs; no VM or CPU improvement claim.')
(out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8',newline='\n')
for name in ['before.json','focused.json']: (out/name).write_text((r/name).read_text(encoding='utf-8'),encoding='utf-8',newline='\n')
(out/'source.patch').write_bytes(subprocess.check_output(['git','-c','core.autocrlf=false','diff','--','src']))
with tarfile.open(out/'development.tar.xz','w:xz',preset=9) as a:
 for p in r.iterdir():
  if p.is_file():a.add(p,arcname=p.name)
 for folder in ['baseline','candidate','warm-sync']:
  for p in (r/folder).rglob('*'):
   if p.is_file():a.add(p,arcname=p.relative_to(r))
print(json.dumps(rows,indent=2));print('Development archive bytes', (out/'development.tar.xz').stat().st_size)
