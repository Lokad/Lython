#!/bin/bash
set -euo pipefail
lab=/mnt/d/code/Lython/.git/agent-notes/review-20261031/csv-dictwriter-row-loop-20261127
case "${1:-first}" in
    first) cd "$lab/comparison/with-control" ;;
    repeat) cd "$lab/comparison/repeat" ;;
    *) exit 2 ;;
esac
lease="$lab/comparison/local.lease"
flock -n "$lease" timeout --signal=TERM 275s taskset -c 27 bash ./run.sh
