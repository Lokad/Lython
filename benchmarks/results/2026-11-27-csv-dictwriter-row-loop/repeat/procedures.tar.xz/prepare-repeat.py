from hashlib import sha256
from pathlib import Path
import json
import shutil

lab = Path(__file__).resolve().parent
original = lab / 'comparison/with-control'
repeat = lab / 'comparison/repeat'
repeat.mkdir()
read = lambda path: json.loads(path.read_text(encoding='utf-8-sig'))
sha = lambda path: sha256(path.read_bytes()).hexdigest()
write = lambda path, value: path.write_text(json.dumps(value, indent=2, ensure_ascii=False) + '\n', encoding='utf-8', newline='\n')
identity = read(original / 'identity.json')
receipt = read(original / 'archive-receipt.json')
assert receipt['complete'] and receipt['allWorkersJoined'] and receipt['guestFixturesRemoved']
assert sha(original / 'observations.tar.xz') == receipt['archiveSHA256']
for role, expected in identity['imageFiles'].items():
    shutil.copytree(original / role, repeat / role)
    assert {p.name: sha(p) for p in (repeat / role).iterdir()} == expected
for name in ('representative.json', 'cpython-worker.py', 'run.sh'):
    shutil.copyfile(original / name, repeat / name)
assert b'\r' not in (repeat / 'run.sh').read_bytes()
assert sha(repeat / 'representative.json') == identity['catalogs']['representative.json']['sha256']
jobs = read(original / 'jobs.json')['warm']
write(repeat / 'jobs.json', {'warm': [jobs[-1], jobs[-2]]})
identity['catalogs']['jobs.json']['sha256'] = sha(repeat / 'jobs.json')
identity['firstArchiveSHA256'] = receipt['archiveSHA256']
identity['purpose'] = 'Repeat the unchanged file-fed control and the async dictionary report in reverse order.'
write(repeat / 'identity.json', identity)
collector = (original / 'collect.py').read_text(encoding='utf-8')
collector = collector.replace('len(jobs) == 4', 'len(jobs) == 2').replace('lython-b1867-writer-fixture-', 'lython-b1867-repeat-fixture-')
compile(collector, 'collect.py', 'exec')
(repeat / 'collect.py').write_text(collector, encoding='utf-8', newline='\n')
