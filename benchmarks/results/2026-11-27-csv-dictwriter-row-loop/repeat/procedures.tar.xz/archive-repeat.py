from hashlib import sha256
from pathlib import Path
from statistics import median
import json
import shutil
import tarfile

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
first = repo / 'benchmarks/results/2026-11-27-csv-dictwriter-row-loop'
repeat = lab / 'comparison/repeat'
out = first / 'repeat'
read = lambda path: json.loads(path.read_text(encoding='utf-8-sig'))
sha = lambda path: sha256(path.read_bytes()).hexdigest()
receipt = read(repeat / 'archive-receipt.json')
assert receipt['complete'] and receipt['allWorkersJoined'] and receipt['guestFixturesRemoved']
assert receipt['archivedAndVerifiedUnderLease'] and receipt['quietBeforeAndAfter'] is None
assert receipt['archiveSHA256'] == sha(repeat / 'observations.tar.xz')
assert (repeat / 'exit-code.txt').read_text().strip() == '0'
identity = read(repeat / 'identity.json')
original = read(first / 'identity.json')
assert identity['firstArchiveSHA256'] == sha(first / 'observations.tar.xz')
assert identity['imageFiles'] == original['imageFiles'] and identity['sourcePatchSHA256'] == original['sourcePatchSHA256']
assert identity['catalogs']['representative.json'] == original['catalogs']['representative.json']
for role, expected in identity['imageFiles'].items():
    assert len(expected) == 32 and {p.name: sha(p) for p in (repeat / role).iterdir()} == expected
with tarfile.open(repeat / 'observations.tar.xz') as archive:
    assert json.load(archive.extractfile('identity.json')) == identity
    for name, expected in identity['catalogs'].items():
        assert sha256(archive.extractfile(name).read()).hexdigest() == expected['sha256']
    raw = json.load(archive.extractfile('confirmation/confirmation.json'))
    assert raw['complete'] and receipt['warmJobs'] == len(raw['jobs']) == 2
    assert all(job['workersJoinedAndFixturesRemoved'] and len(job['samples']) == 28 for job in raw['jobs'])
    assert json.load(archive.extractfile('confirmation/machine-local.json'))['affinity'] == [27]

rows = []
for job in raw['jobs']:
    measures = {}
    for role, worker in job['identities'].items():
        binaries = {Path(entry['path']).name: entry['sha256'].lower() for entry in worker['libraries']}
        assert binaries['Lokad.Lython.dll'] == identity['coreSHA256'][role]
        samples = [item for item in job['samples'] if item['engine'] == role]
        assert len(samples) == 7
        elapsed, cpu = [], []
        for sample in samples:
            response = sample['response']
            assert response['status'] == 'Completed'
            count = response['completedInvocations']
            elapsed.append(1e6 * response['elapsedTicks'] / response['clockFrequency'] / count)
            cpu.append(1e6 * sample['externalProcessCpuTicks'] / sample['externalCpuFrequency'] / count)
        measures[role] = dict(elapsed=median(elapsed), cpu=median(cpu))
    change, spread = {}, {}
    for metric in ('elapsed', 'cpu'):
        before, after = ([measures[role][metric], measures[role + '-control'][metric]] for role in ('reference', 'candidate'))
        pairs = [100 * (new / old - 1) for old in before for new in after]
        change[metric] = [min(pairs), max(pairs)]
        spread[metric] = [100 * (max(source) / min(source) - 1) for source in (before, after)]
    rows.append(dict(case=job['case'], lane=job['lane'], percentChange=change, sameSourceSpreadPercent=spread, medianUs=measures))
    print(job['case'], job['lane'], change, spread, flush=True)
out.mkdir(exist_ok=True)
(out / 'summary.json').write_text(json.dumps(dict(timedBatches=56, quietQualified=False, collectionSeconds=raw['elapsedSeconds'], rows=rows), indent=2) + '\n', encoding='utf-8', newline='\n')
for name in ('identity.json', 'archive-receipt.json', 'observations.tar.xz', 'exit-code.txt'):
    shutil.copyfile(repeat / name, out / name)
files = {name: lab / name for name in ('prepare-repeat.py', 'archive-repeat.py', 'collect-local.sh', 'collection-repeat.log')}
with tarfile.open(out / 'procedures.tar.xz', 'w:xz') as archive:
    for name, path in files.items():
        archive.add(path, arcname=name)
with tarfile.open(out / 'procedures.tar.xz') as archive:
    assert set(archive.getnames()) == set(files)
    assert all(sha256(archive.extractfile(name).read()).hexdigest() == sha(path) for name, path in files.items())
