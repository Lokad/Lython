from pathlib import Path
from textwrap import dedent
import json
import subprocess
import tempfile

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
test = (repo / 'tests/Lokad.Lython.PublicApi.Tests/CsvTextStreamTests.cs').read_text(encoding='utf-8')
body = test.split('Task DictWriterKeepsLiveFieldsAndDiscardsAnInterruptedRow', 1)[1].split('"""', 2)[1]
source = dedent(body.lstrip('\n')).replace("open('/marker'", "open('marker'").replace("open('/out'", "open('out'")
python = Path('C:/Python313/python.exe')
with tempfile.TemporaryDirectory(prefix='lython-b1867-field-golden-') as location:
    root = Path(location)
    (root / 'marker').write_bytes(b'tail')
    (root / 'writer.py').write_text(source, encoding='utf-8', newline='\n')
    result = subprocess.run([python, '-I', '-X', 'utf8', root / 'writer.py'], cwd=root, check=True, capture_output=True, timeout=15)
    output = (root / 'out').read_bytes()
    assert not result.stdout and not result.stderr
    assert output == b'prefix,ok\n' + b'x' * 128 + b',tail:updated,updated\n'
    print(json.dumps({'python': subprocess.check_output([python, '--version'], text=True).strip(), 'file': output.decode('utf-8')}))
