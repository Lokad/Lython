from base64 import b64decode, b64encode
from hashlib import sha256
from pathlib import Path
from statistics import median
import csv
import importlib.util
import io
import json
import os
import shutil
import subprocess
import tempfile

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
prior = lab.parent / 'shared-iterable-call-arguments-20261127'
reference = prior / 'comparison/local'
comparison = lab / 'comparison/with-control'
allocation = lab / 'allocation-with-control'
comparison.mkdir(parents=True)
allocation.mkdir()
read = lambda path: json.loads(path.read_text(encoding='utf-8-sig'))
write = lambda path, value: path.write_text(json.dumps(value, indent=2, ensure_ascii=False) + '\n', encoding='utf-8', newline='\n')
sha = lambda path: sha256(path.read_bytes()).hexdigest()
image = lambda path: {p.name: sha(p) for p in path.iterdir()}
core = 'Lokad.Lython.dll'
worker = 'Lokad.Lython.Benchmarks.dll'
python = Path('C:/Python313/python.exe')
sdk = Path.home() / '.dotnet11'
dotnet = sdk / 'dotnet.exe'
env = dict(os.environ, DOTNET_ROOT=str(sdk), DOTNET_ROOT_X64=str(sdk))
base = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repo, text=True).strip()
assert base.startswith('f0c7b5ad6')
pinned = read(repo / 'benchmarks/results/2026-11-27-shared-iterable-call-arguments/identity.json')
assert image(reference / 'candidate') == pinned['imageFiles']['candidate']
assert sha256(subprocess.check_output(['git', 'diff', '--binary', pinned['sourceRevision'], base, '--', 'src'], cwd=repo)).hexdigest() == pinned['sourcePatchSHA256']
patch = subprocess.check_output(['git', 'diff', '--binary', 'HEAD', '--', 'src'], cwd=repo)
assert b'ValidateRowAsync' in patch and patch.count(b'diff --git ') == 3
(lab / 'candidate.patch').write_bytes(patch)
(lab / 'regression.patch').write_bytes(subprocess.check_output(['git', 'diff', '--binary', 'HEAD', '--', 'tests'], cwd=repo))
for role in ('reference', 'candidate'):
    shutil.copytree(reference / 'candidate', comparison / role)
fresh = repo / 'src/Lokad.Lython/bin/Release/net11.0' / core
assert sha(fresh) == sha(repo / 'tests/Lokad.Lython.PublicApi.Tests/bin/Release/net11.0' / core)
shutil.copyfile(fresh, comparison / 'candidate' / core)
images = {role: image(comparison / role) for role in ('reference', 'candidate')}
assert [name for name, digest in images['reference'].items() if images['candidate'][name] != digest] == [core]

for name in ('cpython-worker.py', 'run.sh'):
    shutil.copyfile(reference / name, comparison / name)
assert b'\r' not in (comparison / 'run.sh').read_bytes()
spec = importlib.util.spec_from_file_location('protocol', comparison / 'cpython-worker.py')
protocol = importlib.util.module_from_spec(spec)
spec.loader.exec_module(protocol)
catalog = read(reference / 'representative.json')
template = catalog['cases'][0]
map_control = next(case for case in catalog['cases'] if case['id'] == 'diagnostic.shipment-file-fed-map')
fixture = json.loads(template['fixtureJson'])
input_bytes = b64decode(fixture['inputFiles']['shipments.csv'])
fields = list(next(csv.reader(io.StringIO(input_bytes.decode('utf-8')))))
assert set(fields) == {'id', 'quantity', 'late', 'hold'}, fields
prefix = """import csv
fields = ['hold', 'id', 'quantity', 'late']
with open('shipments.csv', encoding='utf-8', newline='') as source, open('report.csv', 'w', encoding='utf-8', newline='') as target:
    rows = csv.DictReader(source)
"""
cases = {
    'diagnostic.shipment-dictwriter-report': prefix + """    writer = csv.DictWriter(target, fields, lineterminator='\\n')
    writer.writeheader()
    writer.writerows(rows)
print(rows.line_num)
""",
    'diagnostic.shipment-writer-report-control': prefix + """    writer = csv.writer(target, lineterminator='\\n')
    writer.writerow(fields)
    writer.writerows(([row['hold'], row['id'], row['quantity'], row['late']] for row in rows))
print(rows.line_num)
""",
}
catalog['cases'] = []
last_files = None
for case, source in cases.items():
    with tempfile.TemporaryDirectory(prefix='lython-b1867-goldens-') as location:
        folder = Path(location)
        (folder / 'report.py').write_bytes(source.encode('utf-8'))
        (folder / 'shipments.csv').write_bytes(input_bytes)
        stdout = subprocess.check_output([python, '-I', '-X', 'utf8', folder / 'report.py'], cwd=folder, timeout=15)
        assert sorted(p.name for p in folder.iterdir()) == ['report.csv', 'report.py', 'shipments.csv']
        assert (folder / 'shipments.csv').read_bytes() == input_bytes
        files = {'report.csv': (folder / 'report.csv').read_bytes()}
    assert last_files is None or files == last_files
    last_files = files
    fixture_text = json.dumps(dict(fixture, outputFiles={name: b64encode(data).decode('ascii') for name, data in files.items()}), separators=(',', ':'))
    output = stdout.decode('utf-8').replace('\r\n', '\n')
    catalog['cases'].append(dict(template, id=case, source=source, sourceUtf8Bytes=len(source.encode('utf-8')),
        sourceSha256=sha256(source.encode('utf-8')).hexdigest(), fixtureJson=fixture_text,
        fixtureSha256=sha256(fixture_text.encode('utf-8')).hexdigest(), expectedOutput=output,
        expectedOutputUtf8Bytes=len(output.encode('utf-8')), expectedOutputSha256=sha256(output.encode('utf-8')).hexdigest(),
        expectedFilesSha256=protocol.file_digest(files)))
    print(case, len(input_bytes), len(files['report.csv']), repr(output), flush=True)
catalog['cases'].append(map_control)

identity = dict(sourceRevision=base, sourcePatchSHA256=sha(lab / 'candidate.patch'), productionReference=base,
    imageFiles=images, coreSHA256={role + suffix: files[core] for role, files in images.items() for suffix in ('', '-control')},
    comparisonHostRevision=pinned['comparisonHostRevision'], cpythonWorkerSHA256=sha(comparison / 'cpython-worker.py'),
    independentCPythonVersion=subprocess.check_output([python, '--version'], text=True).strip(), verificationPythonSHA256=sha(python),
    purpose='Compare the shared DictWriter row loop with the original mapping iterator and a plain writer control.')
target, control = cases
write(comparison / 'representative.json', catalog)
write(comparison / 'jobs.json', {'warm': [[target, 'warm'], [control, 'warm-async'], [target, 'warm-async'],
    [map_control['id'], 'warm-async']]})
identity['catalogs'] = {name: {'sha256': sha(comparison / name)} for name in ('representative.json', 'jobs.json')}
write(comparison / 'identity.json', identity)
collector = (reference / 'collect.py').read_text(encoding='utf-8')
collector = collector.replace('lython-b1866-starred-fixture-', 'lython-b1867-writer-fixture-')
compile(collector, 'collect.py', 'exec')
(comparison / 'collect.py').write_text(collector, encoding='utf-8', newline='\n')
for role, files in images.items():
    report = comparison / f'{role}-verify.json'
    subprocess.run([dotnet, comparison / role / worker, '--compare', 'verify', '--catalog', comparison / 'representative.json',
        '--dotnet', dotnet, '--python', python, '--python-worker', comparison / 'cpython-worker.py', '--out', report], env=env, check=True, timeout=75)
    proof = read(report)
    assert proof['state'] == 'Completed' and proof['caseCount'] == len(catalog['cases'])
    assert proof['catalogSha256'] == identity['catalogs']['representative.json']['sha256']
    assert proof['launched']['adapter']['sha256'] == files[worker] and proof['launched']['library']['sha256'] == files[core]
    folder = allocation / role
    shutil.copytree(comparison / role, folder)
    for path in (prior / 'allocation/candidate').glob('ValidatedAllocation*'):
        shutil.copyfile(path, folder / path.name)
    assert all(sha(folder / name) == digest for name, digest in files.items())

rows = []
for mode in ('sync', 'async'):
    for case in catalog['cases']:
        case['runAsync'] = mode == 'async'
    selection = allocation / f'{mode}-catalog.json'
    write(selection, catalog)
    pair = []
    for role in images:
        folder = allocation / role
        report = allocation / f'{role}-{mode}.json'
        subprocess.run([dotnet, folder / 'ValidatedAllocation.dll', folder, selection, report], env=env, check=True, timeout=90)
        pair.append(read(report)['rows'])
    for before, after in zip(*pair, strict=True):
        assert before['id'] == after['id'] and before['sharedBudgetBaselineRestored'] and after['sharedBudgetBaselineRestored']
        row = dict(case=before['id'], mode=mode, clr=[median(r['allocatedBytesPerInvocation']) for r in (before, after)],
            peak=[r['peakExecutionMemoryBytes'] for r in (before, after)], compiled=[r['compiledReservedBytes'] for r in (before, after)])
        rows.append(row)
        print(row, flush=True)
write(allocation / 'summary.json', rows)
