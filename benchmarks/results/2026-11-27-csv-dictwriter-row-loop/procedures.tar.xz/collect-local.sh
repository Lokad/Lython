#!/bin/bash
set -euo pipefail
lab=/mnt/d/code/Lython/.git/agent-notes/review-20261031/csv-dictwriter-row-loop-20261127
cd "$lab/comparison/with-control"
lease="$lab/comparison/local.lease"
flock -n "$lease" timeout --signal=TERM 275s taskset -c 27 bash ./run.sh
