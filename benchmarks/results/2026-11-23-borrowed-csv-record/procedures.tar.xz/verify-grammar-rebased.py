from pathlib import Path
import base64, hashlib, importlib.util, json, os, subprocess, tempfile

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
pair=lab/"comparison-rebased"
out=lab/"borrowed-grammar-rebased"
out.mkdir()
def read(path): return json.loads(path.read_text(encoding="utf-8"))
def sha(data): return hashlib.sha256(data).hexdigest()
def digest(path): return sha(path.read_bytes())
protocol=repo/"benchmarks/cpython-worker.py"
spec=importlib.util.spec_from_file_location("proto",protocol)
proto=importlib.util.module_from_spec(spec)
spec.loader.exec_module(proto)
identity=read(pair/"identity.json")
assert digest(protocol)==identity["protocolSHA256"]
catalog=read(pair/"representative.json")
template=catalog["cases"][0]
python=Path("C:/Python313/python.exe")
source=(lab/"borrowed-grammar.py").read_text(encoding="utf-8")
data=b"paired defaults"
fields=[]
for mode in ("literal-csv",):
    text=source
    with tempfile.TemporaryDirectory(prefix="lython-default-order-") as temp:
        root=Path(temp)
        (root/"input.txt").write_bytes(data)
        (root/"script.py").write_text(text,encoding="utf-8",newline="\n")
        baseline=subprocess.run([python,"-I","-S","-X","utf8","script.py"],cwd=root,capture_output=True,
            check=True,timeout=20)
        assert not baseline.stderr
    output=baseline.stdout.decode("utf-8").replace("\r\n","\n")
    (out/f"{mode}-expected.txt").write_text(output,encoding="utf-8",newline="\n")
    fixture=json.dumps(dict(size=len(data),text=None,inputFiles={"input.txt":base64.b64encode(data).decode("ascii")},
        outputFiles={}),separators=(",",":"))
    fields.append(dict(template,id="diagnostic.borrowed-grammar."+mode,size=len(data),source=text,fixtureJson=fixture,
        expectedOutput=output,sourceUtf8Bytes=len(text.encode()),expectedOutputUtf8Bytes=len(output.encode()),
        sourceSha256=sha(text.encode()),fixtureSha256=sha(fixture.encode()),expectedOutputSha256=sha(output.encode()),
        expectedFilesSha256=proto.file_digest({})))
path=out/"catalog.json"
path.write_text(json.dumps({**catalog,"cases":fields},ensure_ascii=False,indent=2)+"\n",encoding="utf-8",newline="\n")
sdk=Path.home()/".dotnet11"
dotnet=sdk/"dotnet.exe"
env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk),PATH=str(sdk)+os.pathsep+os.environ["PATH"])
for role, files in identity["imageFiles"].items():
    image=pair/("frozen-"+role)
    assert {n:digest(image/n)for n in files}==files
    proof=out/f"{role}-verify.json"
    subprocess.run([dotnet,image/"Lokad.Lython.Benchmarks.dll","--compare","verify","--catalog",path,
        "--dotnet",dotnet,"--python",python,"--python-worker",protocol,"--out",proof],check=True,cwd=repo,
        env=env,timeout=90)
    result=read(proof)
    assert result["state"]=="Completed" and result["caseCount"]==1 and result["catalogSha256"]==digest(path)
