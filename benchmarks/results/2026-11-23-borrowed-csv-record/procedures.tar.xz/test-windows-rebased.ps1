$root = Join-Path $env:USERPROFILE '.dotnet11'
$env:DOTNET_ROOT = $root
$env:DOTNET_ROOT_X64 = $root
$env:PATH = "$root;$env:Path"
$env:DOTNET_HOST_PATH = Join-Path $root 'dotnet.exe'
$lab = $PSScriptRoot
Set-Location 'D:/code/Lython/.git/agent-worktrees/borrowed-csv-record-20261123'
$filter = 'Category!=Stress&(FullyQualifiedName~Csv|FullyQualifiedName~CooperativeCancellation|FullyQualifiedName~WordBufferLoan|FullyQualifiedName~ReceiverFunctionEntry)'
& $env:DOTNET_HOST_PATH test tests/Lokad.Lython.Tests -c Release -f net11.0 --artifacts-path "$lab/windows-rebased" --filter $filter > "$lab/white-rebased-windows.log" 2>&1
$code = $LASTEXITCODE
if ($code) { Get-Content "$lab/white-rebased-windows.log" -Encoding utf8 -Tail 38; exit $code }
& $env:DOTNET_HOST_PATH test tests/Lokad.Lython.PublicApi.Tests -c Release -f net11.0 --artifacts-path "$lab/windows-rebased" --filter $filter > "$lab/public-rebased-windows.log" 2>&1
$code = $LASTEXITCODE
if ($code) { Get-Content "$lab/public-rebased-windows.log" -Encoding utf8 -Tail 38; exit $code }
Get-Content "$lab/white-rebased-windows.log", "$lab/public-rebased-windows.log" -Encoding utf8 | Select-String 'Passed!'
