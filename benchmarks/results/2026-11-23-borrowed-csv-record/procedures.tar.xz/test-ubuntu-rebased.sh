#!/bin/bash
set -euo pipefail
cd /mnt/d/code/Lython/.git/agent-worktrees/borrowed-csv-record-20261123
export DOTNET_ROOT="$HOME/.dotnet"
export PATH="$DOTNET_ROOT:$PATH"
export DOTNET_HOST_PATH="$DOTNET_ROOT/dotnet"
lab=/mnt/d/code/Lython/.git/agent-notes/review-20261031/borrowed-csv-record-20261123
filter='Category!=Stress&(FullyQualifiedName~Csv|FullyQualifiedName~CooperativeCancellation|FullyQualifiedName~WordBufferLoan|FullyQualifiedName~ReceiverFunctionEntry)'
dotnet test tests/Lokad.Lython.Tests -c Release -f net10.0 --artifacts-path "$lab/ubuntu-rebased" --filter "$filter" > "$lab/white-rebased-ubuntu.log" 2>&1 || { tail -38 "$lab/white-rebased-ubuntu.log"; exit 1; }
dotnet test tests/Lokad.Lython.PublicApi.Tests -c Release -f net10.0 --artifacts-path "$lab/ubuntu-rebased" --filter "$filter" > "$lab/public-rebased-ubuntu.log" 2>&1 || { tail -38 "$lab/public-rebased-ubuntu.log"; exit 1; }
awk '/Passed!/{count++;print} END{exit count!=2}' "$lab/white-rebased-ubuntu.log" "$lab/public-rebased-ubuntu.log"
