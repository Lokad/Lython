#!/bin/bash
set -euo pipefail
cd /mnt/d/code/Lython/.git/agent-worktrees/borrowed-csv-record-20261123
export DOTNET_ROOT="$HOME/.dotnet"
export PATH="$DOTNET_ROOT:$PATH"
export DOTNET_HOST_PATH="$DOTNET_ROOT/dotnet"
lab=/mnt/d/code/Lython/.git/agent-notes/review-20261031/borrowed-csv-record-20261123
filter='Category!=Stress&(FullyQualifiedName~Csv|FullyQualifiedName~CooperativeCancellation|FullyQualifiedName~WordBufferLoan)'
dotnet test tests/Lokad.Lython.Tests -c Release -f net10.0 --artifacts-path "$lab/ubuntu" --filter "$filter" > "$lab/white-qualified-ubuntu.log" 2>&1 || { tail -38 "$lab/white-qualified-ubuntu.log"; exit 1; }
dotnet test tests/Lokad.Lython.PublicApi.Tests -c Release -f net10.0 --artifacts-path "$lab/ubuntu" --filter "$filter" > "$lab/public-qualified-ubuntu.log" 2>&1 || { tail -38 "$lab/public-qualified-ubuntu.log"; exit 1; }
awk '/Passed!/{count++;print} END{exit count!=2}' "$lab/white-qualified-ubuntu.log" "$lab/public-qualified-ubuntu.log"
