from pathlib import Path
import gzip
import hashlib
import io
import json
import shutil
import subprocess
import tarfile

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
tree = repo / ".git/agent-worktrees/borrowed-csv-record-20261123"
out = lab / "comparison-rebased"
previous = lab.parent / "nested-bound-operand-20261123" / "comparison"
quiet = out / "quiet"
quiet.mkdir(exist_ok=True)
assert not (quiet / 'launch.log').exists()
core = "Lokad.Lython.dll"
def read(p): return json.loads(p.read_text(encoding="utf-8-sig"))
def sha(data): return hashlib.sha256(data).hexdigest()
def digest(p): return sha(p.read_bytes())
def save(p, value): write(p, json.dumps(value, ensure_ascii=False, indent=2) + "\n")
def write(p, source):
    if p.suffix == ".py": compile(source, str(p), "exec")
    p.write_text(source, encoding="utf-8", newline="\n")
def git(*args, cwd=repo): return subprocess.check_output(["git", *args], cwd=cwd)
def published(folder, name): return git("show", f"origin/master:benchmarks/results/{folder}/{name}")
def archive(folder):
    receipt = json.loads(published(folder, "archive-receipt.json"))
    data = published(folder, "observations.tgz")
    assert all(receipt[k] for k in ("complete", "allWorkersJoined", "archivedAndVerifiedUnderLease"))
    assert sha(data) == receipt["archiveSHA256"]
    return receipt["archiveSHA256"]

template = read(previous / "quiet/config.json")
donor = "2026-11-23-nested-bound-operand"
prior = json.loads(published(donor, "source.json"))
assert prior["imageFiles"]["candidate"] == template["identity"]["imageFiles"]["candidate"]
before = read(out / "identity.json")
candidate = git("rev-parse", "HEAD", cwd=tree).decode().strip()
assert not git("status", "--porcelain", cwd=tree)
patch = git("diff", "--binary", before["patchBase"], candidate, "--", "src", "tests")
assert sha(patch) == before["sourcePatchSHA256"] and patch == (out/"source.patch").read_bytes()
files = before["imageFiles"]
assert prior["imageFiles"]["candidate"] == files["reference"] and len(files["reference"]) == 32
assert [n for n in files["reference"] if files["reference"][n] != files["candidate"][n]] == [core]

inventory = read(lab / "quiet-image-inventory.json")
def raw_catalog(folder):
    archive(folder)
    with tarfile.open(fileobj=io.BytesIO(published(folder,"observations.tgz")))as t:
        data=t.extractfile("representative.json").read()
    assert sha(data)==json.loads(published(folder,"source.json"))["catalogs"]["representative.json"]["sha256"]
    return data

def retirement_proof(paths, data, folders):
    stats=[inventory["files"][p]for p in paths]
    assert all(s["bytes"]==len(data) and s["links"]==len(paths) and
        (s["device"],s["inode"])==(stats[0]["device"],stats[0]["inode"]) for s in stats)
    return dict(paths=paths,bytes=len(data),sha256=sha(data),links=len(paths),
        archives={root+"/observations.tgz":archive(folder) for root,folder in folders.items()})

old="2026-11-23-materialized-cased-split-bounded"
before_core=gzip.decompress(published(old,"candidate-core.dll.gz"))
assert sha(before_core)==json.loads(published(old,"source.json"))["imageFiles"]["candidate"][core]
assert sha(before_core) not in (manifest[core] for manifest in files.values())
materialized="materialized-cased-split-b1436-20261123"
quoted="nested-bound-operand-b1439-20261123"
external="integrated-current-cpython-b1438-20261123"
preflight="single-owner-function-b1437-20261123"
retire=[retirement_proof([materialized+"/candidate/"+core, quoted+"/reference/"+core,
               external+"/candidate/"+core, preflight+"/reference/"+core],before_core,{
    materialized:old, quoted:donor, external:"2026-11-23-integrated-cpython-checkpoint",
    preflight:"2026-11-23-single-owner-function-preflight",
})]
for folder,root in (
    ("2026-11-23-integrated-cpython-checkpoint",external),
    ("2026-11-23-retained-cpython-checkpoint","retained-current-cpython-b1429-20261123"),
):
    retire.append(retirement_proof([root+"/representative.json"],raw_catalog(folder),{root:folder}))

catalog = out / "representative.json"
ids = [row["id"] for row in read(catalog)["cases"]]
assert len(ids) == 9
borrowed, = (name for name in ids if "fulfillment.borrowed" in name)
ascii, = (name for name in ids if name.endswith("typed-ascii"))
unicode, = (name for name in ids if name.endswith("typed-unicode"))
quote, = (name for name in ids if name.endswith("quoted-control"))
text, = (name for name in ids if "nonlocal" in name)
jobs = [(borrowed, "warm"),(ascii+".borrowed","warm"),(unicode+".borrowed","warm"),
        (ascii,"warm"),(unicode,"warm"),(quote,"warm"),(borrowed,"compile-run"),(text,"warm")]
assert len(jobs) == 8
save(out / "jobs.json", jobs)
shutil.copyfile(catalog, quiet / "representative.json")
for role, manifest in files.items():
    image = out / f"frozen-{role}"
    proof = read(out / f"{role}-verify.json")
    assert proof["state"] == "Completed" and proof["catalogSha256"] == digest(catalog) and proof["caseCount"] == len(ids)
    assert {n: digest(image / n) for n in manifest} == manifest

(quiet / "candidate").mkdir(exist_ok=True)
shutil.copyfile(out / "frozen-candidate" / core, quiet / "candidate" / core)
identity = {**before, "sourceRevision": before["reference"] + " versus " + candidate, "candidate": candidate,
    "purpose": "Parse literal CSV records from immutable input items before falling back to the owned record.",
    "normalAdapterPin": "0.4.0", "coreSHA256": {r+s:m[core] for r,m in files.items() for s in ("", "-control")},
    "catalogs": {"representative.json": {"sha256": digest(catalog)}}}
save(quiet / "identity.json", identity)
root = "/home/lokad/lython-bench-checks/borrowed-csv-record-b1440-20261123"
unit = "lython-b1440-borrowed-csv-record-20261123"
for name in ("collect.py", "run.sh", "archive-owned.py", "retrieve.py"):
    source = (previous / "quiet" / name).read_text(encoding="utf-8").replace(template["root"], root).replace(template["unit"], unit)
    if name == "collect.py":
        start, end = source.index("\njob_catalog ="), source.index("\nassert len(jobs)")
        source = source[:start] + "\njob_catalog = " + repr({id:"representative.json" for id in ids}) + "\njobs = " + repr(jobs) + source[end:]
        source = source.replace("if job_index % 2 != 0: labels.reverse()", "if job_index % 2 == 0: labels.reverse()").replace("len(jobs)==8", "len(jobs)==8")
    elif name == "archive-owned.py":
        source = source.replace("len(raw['jobs'])==8", "len(raw['jobs'])==8").replace("jobs=8,elapsedSeconds", "jobs=8,elapsedSeconds")
    elif name == "retrieve.py":
        source = source.replace("status['receipt']['jobs']==8", "status['receipt']['jobs']==8")
    write(quiet / name, source.replace("Nested bound returns", "Borrowed CSV records"))
assert b"\r" not in (quiet / "run.sh").read_bytes()
parts = ("identity.json", "representative.json", "collect.py", "run.sh", "archive-owned.py", "candidate/" + core)
payload = quiet / "payload.tgz"
with tarfile.open(payload, "w:gz") as bundle:
    for name in parts: bundle.add(quiet / name, arcname=name)
unpacked=sum((quiet / n).stat().st_size for n in parts)
minimum=176160768+unpacked+2*1024*1024+512*1024
if inventory["freeBytes"]+sum(v["bytes"] for v in retire)<=minimum:
    original="2026-11-23-materialized-cased-split"
    original_root="materialized-cased-split-b1435-20261123"
    data=raw_catalog(old)
    assert data==raw_catalog(original)
    retire.append(retirement_proof([materialized+"/representative.json",original_root+"/representative.json"],
        data,{materialized:old,original_root:original}))
assert inventory["freeBytes"]+sum(v["bytes"] for v in retire)>minimum
cfg = {**template, "root": root, "unit": unit, "identity": identity, "source": template["root"],
       "sourceFiles": files["reference"], "sourceCatalogSHA256": prior["catalogs"]["representative.json"]["sha256"],
       "donorArchiveSHA256": archive(donor), "retireGroups": retire, "payloadBytes": payload.stat().st_size,
       "payloadSHA256": digest(payload), "unpackedBytes": sum((quiet / n).stat().st_size for n in parts)}
save(quiet / "config.json", cfg)
seed = (previous / "quiet/remote-launch.py").read_text(encoding="utf-8")
a,b = seed.index("\nc=")+1, seed.index("\nb=Path(")
seed = (seed[:a] + "c=" + repr(cfg) + seed[b:]).replace("b1439-fixtures", "b1440-fixtures")
assert "b1440-fixtures" in seed
write(quiet / "remote-launch.py", seed)
launch = (previous / "launch.py").read_text(encoding="utf-8")
write(out / "launch.py", launch.replace("Nested bound returns", "Borrowed CSV records"))
summary = (previous / "summarize.py").read_text(encoding="utf-8")
write(out / "summarize.py", summary.replace("len(raw['jobs'])==8", "len(raw['jobs'])==8"))
print(candidate, root, cfg["unpackedBytes"], sum(group["bytes"] for group in retire))
