from pathlib import Path
import ast
import hashlib
import json
import os
import re
import shutil
import subprocess
import tarfile

lab = Path(__file__).resolve().parent
repo = Path.cwd()
prior = lab.parent / 'retained-dispatch-profile'
donor = lab.parent / 'funded-definition-construction'
read = lambda path: path.read_text(encoding='utf-8-sig')
load = lambda path: json.loads(read(path))
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()

def write(name, source):
    if name.endswith('.py'):
        ast.parse(source)
    (lab / name).write_text(source, encoding='utf-8', newline='\n')

def save(name, value):
    write(name, json.dumps(value, ensure_ascii=False, indent=2) + '\n')

revision = subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip()
assert revision.startswith('9b14997e4')
assert not subprocess.check_output(['git', 'status', '--porcelain'])
measured = load(donor / 'frozen-identity.json')['candidateCommit']
assert measured.startswith('02639bec8')
subprocess.run(['git','diff','--exit-code',measured,revision,'--','src','global.json','Directory.Build.props',
    'Directory.Packages.props','benchmarks/Lokad.Lython.Benchmarks','benchmarks/cpython-worker.py'],check=True)
old = load(donor / 'quiet/config.json')
terminal = load(donor / 'quiet/terminal-status.json')
receipt = load(donor / 'quiet/archive-receipt.json')
assert terminal['exitCode'] == '0' and terminal['receipt'] == receipt
assert all(receipt[name] for name in ('complete','allWorkersJoined','quietBeforeAndAfter','archivedAndVerifiedUnderLease'))
assert receipt['archiveSHA256'] == sha(donor/'quiet/observations.tgz')
source = donor/'frozen/candidate'
files = old['identity']['imageFiles']['candidate']
assert len(files) == 32 and {name:sha(source/name) for name in files} == files
image = lab/'candidate'
image.mkdir(exist_ok=True)
for name in files:
    shutil.copyfile(source/name,image/name)
assert {name:sha(image/name) for name in files} == files

catalog = load(donor/'catalog.json')
jobs = [('candidate-annotated','scripts.annotated-rule-closures','warm'),
        ('candidate-nested','scripts.annotated-rule-closures.nested-factories','warm')]
cases = {case['id']:case for case in catalog['cases']}
catalog['cases'] = [cases[case] for _,case,_ in jobs]
save('catalog.json',catalog)
catalog_path=lab/'catalog.json'
sdk = Path.home()/'.dotnet11'
dotnet = sdk/'dotnet.exe'
env = dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk),PATH=str(sdk)+os.pathsep+os.environ['PATH'])
with (lab/'verify.log').open('wb') as output:
    subprocess.run([dotnet,image/'Lokad.Lython.Benchmarks.dll','--compare','verify','--catalog',catalog_path,
                    '--dotnet',dotnet,'--python','C:/Python313/python.exe','--python-worker',repo/'benchmarks/cpython-worker.py',
                    '--out',lab/'verify.json'],env=env,stdout=output,stderr=subprocess.STDOUT,check=True,timeout=140)
verified = load(lab/'verify.json')
assert verified['state']=='Completed' and verified['catalogSha256']==sha(catalog_path)
assert {name:sha(image/name) for name in files}==files

root='/home/lokad/lython-bench-checks/factory-ownership-profile-b1170-20261120'
unit='lython-b1170-factory-ownership-profile-20261120'
original=load(prior/'config.json')
purpose='B1170 retained factory ownership and dispatch attribution'
core='Lokad.Lython.dll'
identity=dict(sourceRevision=revision,imageSource=measured,purpose=purpose,diagnosticOnly=True,
              imageFiles={'candidate':files},catalogSHA256=sha(catalog_path),coreSHA256={'candidate':files[core]})
save('identity.json',identity)
labels=[label for label,_,_ in jobs]
old_labels=['candidate-annotated','candidate-nested','candidate-forwarding','candidate-report']
old_labels_rendered=repr(old_labels)
profile_floor=168*1024*1024
headroom=1024*1024
for name in ('ops-profile.py','collect.py','run.sh','launch.py','retrieve.py','analyze.py'):
    body=read(prior/name).replace(original['root'],root).replace(original['identity']['purpose'],purpose)
    body=body.replace(old_labels_rendered,repr(labels)).replace('len(records)==4','len(records)==2')
    body=body.replace('182452224',str(profile_floor))
    if name=='ops-profile.py':
        a=body.index('    for name, case_id, lane in ')
        b=body.index('        role = name',a)
        body=body[:a]+'    for name, case_id, lane in '+repr(jobs)+':\n'+body[b:]
        body=body.replace('128 if name in {"candidate-forwarding", "candidate-report"} else 512','512')
        body=body.replace('total_capture_seconds > 26','total_capture_seconds > 14')
    if name=='collect.py':
        body=body.replace("str(root/'profiles')","str(root/'guest-fixtures/profiles')")
        body=body.replace("trace=root/'profiles'","trace=fixture/'profiles'")
        body=body.replace('p.relative_to(root).as_posix():hashlib.sha256','p.relative_to(fixture).as_posix():hashlib.sha256')
        body=body.replace('archive.add(root/name,arcname=name)','archive.add(fixture/name,arcname=name)')
    if name=='analyze.py':
        a=body.index(' focused={')
        body=body[:a]+''' focus.update({
     'prepared capture resolution':('CaptureExecutableCells','CaptureExecutableClosures','CanDefineWithoutInvocation','TransferCapturedCellCharge'),
     'retained closure ownership':('ChargeClosureRetention','CountOwnedModuleVariables'),
     'callable shell and annotation construction':('CreateFunctionValue','CopyAnnotationValues','AttachAdmittedAnnotations'),
     'default input transport':('StoreDefaultResult','SetPrivateDefault','AddDefinitionValue'),
     'definition operand retirement':('RetireExecutableDefinition','RetireTo','ClearNativeSlot'),
 })
'''+body[a:]
    if name=='launch.py':
        body=body.replace('seconds=90','seconds=65').replace('before 90 seconds','before 65 seconds')
    write(name,body)
assert repr(jobs) in read(lab/'ops-profile.py') and b'\r' not in (lab/'run.sh').read_bytes()

payload=lab/'payload.tgz'
names=('identity.json','catalog.json','ops-profile.py','collect.py','run.sh')
with tarfile.open(payload,'w:gz') as output:
    for name in names:
        output.add(lab/name,arcname=name)
expanded=sum((lab/name).stat().st_size for name in names)
config=dict(root=root,unit=unit,source=old['root'],sourceFiles={'candidate':files},
            sourceCatalogSHA256=old['catalogSHA256'],catalogSHA256=sha(catalog_path),identity=identity,retireGroups=[],
            payloadBytes=payload.stat().st_size,payloadSHA256=sha(payload),unpackedBytes=expanded,donorArchive=receipt['archiveSHA256'])
save('config.json',config)
launcher=read(prior/'remote-launch.py')
a,b=launcher.index('\nc=')+1,launcher.index('\nb=Path(')
launcher=launcher[:a]+'c='+repr(config)+launcher[b:]
launcher=launcher.replace('lython-b1159-fixtures','lython-b1170-fixtures')
launcher=launcher.replace('182452224',str(profile_floor)).replace('3145728',str(headroom)).replace('RuntimeMaxSec=205','RuntimeMaxSec=155')
write('remote-launch.py',launcher)
print('All 32 source-matched worker files and both CPython goldens verified. VM stages the immutable image from B1169.')
