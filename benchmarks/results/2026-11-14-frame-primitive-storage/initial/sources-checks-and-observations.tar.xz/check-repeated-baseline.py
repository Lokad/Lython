from pathlib import Path
import hashlib,json,os,shutil,subprocess
r=Path(__file__).parent;probe=Path('tools/LythonProbe/bin/Release/net11.0').resolve();out=r/'repeated-diagnostic';out.mkdir();sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
for role in ['reference','candidate']:shutil.copytree(probe,out/role)
shutil.copyfile(r.parent/'primitive-storage-r359/complete/candidate-core.dll',out/'reference/Lokad.Lython.dll');assert sha(out/'reference/Lokad.Lython.dll').startswith('a4bfbfd8')
original='def fold():\n    values=range(3)\n    total=0\n    for value in values:total+=value\n    return total\nfor ordinal in range(10000):result=fold()\nreturn result\n'
reused='def fold(values):\n    total=0\n    try:\n        for value in values:total+=value\n    finally:pass\n    return total\nvalues=(0,1,2)\nfor ordinal in range(10000):result=fold(values)\nreturn result\n'
snippets=[original,reused];env={k:v for k,v in os.environ.items()if k.lower()!='path'};env['DOTNET_ROOT']='C:/Users/JoannesVermorel/.dotnet11';env['PATH']=env['DOTNET_ROOT']+';C:/Python313;'+os.environ.get('PATH','');rows=[]
for role in ['reference','candidate']:
 done=subprocess.run([env['DOTNET_ROOT']+'/dotnet.exe',str((out/role/'LythonProbe.dll').resolve()),'--batch-json','--max-memory-bytes','524288'],input=json.dumps(snippets).encode(),capture_output=True,env=env,timeout=30);(out/(role+'.jsonl')).write_bytes(done.stdout);(out/(role+'.stderr')).write_bytes(done.stderr);cases=[json.loads(line)for line in done.stdout.splitlines()];assert len(cases)==2;rows.append(dict(role=role,coreSHA256=sha(out/role/'Lokad.Lython.dll'),cases=cases));print(role,[(c['Lython']['Success'],c['Lython']['Failure'])for c in cases],flush=True)
(out/'diagnosis.json').write_text(json.dumps(dict(sources=snippets,budgetBytes=524288,roles=rows),indent=2)+'\n',encoding='utf-8',newline='\n')
