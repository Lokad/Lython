from pathlib import Path
r=Path(__file__).parent;root=Path('src/Lokad.Lython')
def change(name,old,new):
 p=root/name;s=p.read_text(encoding='utf-8');assert s.count(old)==1,(name,old[:80],s.count(old));p.write_text(s.replace(old,new),encoding='utf-8',newline='\n')

name='Runtime/LythonRuntime.Executable.cs'
change(name,'''        private object[] _items;''','''        private object[] _items;
        private long[]? _integers;''')
change(name,'''            PyExecutableFunction? lookupOwner)
        {
            _state''','''            PyExecutableFunction? lookupOwner, int integerCapacity)
        {
            _integers = null;
            _state''')
change(name,'''            var bytes = checked(frameStorageBytes + (borrowedValues is null ? EstimateObjectArrayBytes(capacity) : 0));''','''            var bytes = checked(frameStorageBytes + (borrowedValues is null ? EstimateObjectArrayBytes(capacity) : 0)
                + (integerCapacity == 0 ? 0 : 32L + sizeof(long) * (long)integerCapacity));''')
change(name,'''            try { _items = borrowedValues ?? new object[capacity]; governor.Commit(bytes); }''','''            try
            {
                _items = borrowedValues ?? new object[capacity];
                _integers = integerCapacity == 0 ? null : new long[integerCapacity];
                governor.Commit(bytes);
            }''')
change(name,'''        internal object[] Values => _items;''','''        internal readonly object[] RawValues => _items;
        internal readonly ReadOnlySpan<long> IntegerValues => _integers;

        internal readonly object? Materialize(int slot) => MaterializeInteger(_items, _integers, slot);

        internal readonly void MaterializeRange(int start, int count)
        {
            if (_integers is null) return;
            for (var i = start; i < start + count; i++)
            {
                if ((i & 63) == 0) _state.CheckExecution(null);
                _ = Materialize(i);
            }
        }

        internal readonly void SetInteger(int slot, long value) => _integers![slot] = value;''')
change(name,'''            _items = [];
            _nativeIterationPositions = null;''','''            _items = [];
            _integers = null;
            _nativeIterationPositions = null;''')
change(name,'''            get => _items[index].RequireNotNull();''','''            readonly get => Materialize(index).RequireNotNull();''')
change(name,'''        internal void PublishValue(int resultSlot, int liveExtent, object result)''','''        internal void PublishValue(int resultSlot, int liveExtent, object result, long integer = 0)''')
change(name,'''            _items[resultSlot] = result;
            LiveExtent = liveExtent;''','''            if (ReferenceEquals(result, DeferredInteger)) SetInteger(resultSlot, integer);
            _items[resultSlot] = result;
            LiveExtent = liveExtent;''')
change(name,'''            var value = _items[inputSlot].RequireNotNull();''','''            var value = Materialize(inputSlot).RequireNotNull();''')
change(name,'''        public ReadOnlyMemory<object?> Slice(int start, int count) => _items.AsMemory(start, count);''','''        public readonly ReadOnlyMemory<object?> Slice(int start, int count)
        {
            MaterializeRange(start, count);
            return _items.AsMemory(start, count);
        }''')
change(name,'''            context, span, bytes, argumentsAreLocals ? boundArguments.Values : null, lookupOwner);''','''            context, span, bytes, argumentsAreLocals ? boundArguments.Values : null, lookupOwner,
            codeObject.IntegerStorageCapacity);''')

for name in ['Runtime/LythonRuntime.Executable.cs','Runtime/LythonRuntime.Executable.Inputs.cs','Runtime/LythonRuntime.Executable.Interpreter.cs','Runtime/LythonRuntime.Executable.Operations.cs','Runtime/LythonRuntime.Executable.Calls.Invoke.cs']:
 p=root/name;s=p.read_text(encoding='utf-8').replace('Stack.Values','Stack.RawValues').replace('stack.Values','stack.RawValues');p.write_text(s,encoding='utf-8',newline='\n')
change('Runtime/LythonRuntime.Executable.Operations.cs','''new PyTuple(stack.RawValues.AsSpan(start, count),''','''new PyTuple(stack.Slice(start, count).Span,''')

name='Runtime/LythonRuntime.Executable.Binding.cs'
change(name,'''    private static object? ReadLocalValue(object[] locals, int slot)
    {
        var value = locals[slot];''','''    private static object? ReadLocalValue(in ExecutableValueStorage storage, int slot)
    {
        var value = storage.Materialize(slot);''')
change(name,'''    private static object LoadLocal(ExecutableCodeObject codeObject, object[] locals, int slot, LythonSourceSpan span, ExecutionContext context)
    {
        var value = ReadLocalValue(locals, slot);''','''    private static object LoadLocal(ExecutableCodeObject codeObject, in ExecutableValueStorage storage, int slot, LythonSourceSpan span, ExecutionContext context)
    {
        var value = ReadLocalValue(in storage, slot);''')
for name in ['Runtime/LythonRuntime.Executable.cs','Runtime/LythonRuntime.Executable.Interpreter.cs','Runtime/LythonRuntime.Executable.Interpreter.Dispatch.cs']:
 p=root/name;s=p.read_text(encoding='utf-8').replace('ReadLocalValue(_execution.Locals,','ReadLocalValue(in _execution.Stack,').replace('ReadLocalValue(execution.Locals,','ReadLocalValue(in execution.Stack,').replace('LoadLocal(execution.Code, execution.Locals,','LoadLocal(execution.Code, in execution.Stack,');s=s.replace(': execution.Stack.RawValues[source]',': execution.Stack[source]');p.write_text(s,encoding='utf-8',newline='\n')

name='Runtime/LythonRuntime.Executable.Interpreter.cs'
change(name,'''            object[] locals,
            ExecutionContext? context,
            int slot,
            object value,
            LythonSourceSpan span)
        {
            var name = codeObject.LocalNames[slot];
            var guestName = !name.StartsWith('<');''','''            ref ExecutableValueStorage storage,
            ExecutionContext? context,
            int slot,
            object value,
            LythonSourceSpan span,
            long integer = 0)
        {
            var locals = storage.RawValues;
            var name = codeObject.LocalNames[slot];
            var guestName = !name.StartsWith('<');
            // Retirement may have reentered the host and exposed a namespace.
            // Decide using its current policy, immediately before publication.
            if (ReferenceEquals(value, DeferredInteger))
            {
                if (locals[slot] is ExecutableCell || guestName && (codeObject.RequiresLocalVariableMirroring
                    || context?.MirrorLocalStores == true || context?.GlobalNamespace is not null))
                    value = (System.Numerics.BigInteger)integer;
                else storage.SetInteger(slot, integer);
            }''')
change(name,'''StoreLocalValue(execution.Code, execution.Locals, invocation, instruction.LocalSlot,''','''StoreLocalValue(execution.Code, ref execution.Stack, invocation, instruction.LocalSlot,''')

name='Runtime/LythonRuntime.Executable.Results.cs'
change(name,'''            ExecutionContext? invocation, in ExecutableInstruction instruction, object value)''','''            ExecutionContext? invocation, in ExecutableInstruction instruction, object value, long integer = 0)''')
change(name,'''execution.Stack.PublishValue(instruction.ResultSlot, instruction.LiveExtent, value);''','''execution.Stack.PublishValue(instruction.ResultSlot, instruction.LiveExtent, value, integer);''')
change(name,'''else CompleteLocalResult(ref execution, invocation, instruction, value);''','''else CompleteLocalResult(ref execution, invocation, instruction, value, integer);''')
change(name,'''            ExecutionContext? invocation, in ExecutableInstruction instruction, object value)
        {''','''            ExecutionContext? invocation, in ExecutableInstruction instruction, object value, long integer)
        {''')
change(name,'''execution.Stack.PublishValue(instruction.ResultSlot, instruction.LiveExtent, value);''','''execution.Stack.PublishValue(instruction.ResultSlot, instruction.LiveExtent, value, integer);''')
change(name,'''StoreLocalValue(execution.Code, execution.Locals, invocation, store.LocalSlot, value, store.Span);''','''StoreLocalValue(execution.Code, ref execution.Stack, invocation, store.LocalSlot, value, store.Span, integer);''')

name='Runtime/LythonRuntime.Executable.DictionaryAccumulation.cs'
change(name,'''var priorTotal = hasTotal ? execution.Locals[total.InputStart] : null;''','''var priorTotal = hasTotal ? ReadLocalValue(in execution.Stack, total.InputStart) : null;''')
change(name,'''var increment = source < 0 ? execution.Code.Constants[~source] : execution.Locals[source];''','''var increment = source < 0 ? execution.Code.Constants[~source] : ReadLocalValue(in execution.Stack, source);''')

test=Path('tests/Lokad.Lython.Tests/WordBufferLoanTests.cs');s=test.read_text(encoding='utf-8');assert s.count('ExecutableValueStorage(1, 0, 0, context, Span, 0, null, null)')==1;test.write_text(s.replace('ExecutableValueStorage(1, 0, 0, context, Span, 0, null, null)','ExecutableValueStorage(1, 0, 0, context, Span, 0, null, null, 0)'),encoding='utf-8',newline='\n')
print('Frame primitive capacity/ownership and materialization boundaries installed; shared arithmetic integration pending.')
