from pathlib import Path
import json,os,subprocess,shutil,xml.etree.ElementTree as ET,tarfile,hashlib
r=Path(__file__).parent
with tarfile.open(r.parent/'primitive-storage-r359/complete/candidate-sources.tar.xz')as t:
 n='src/Lokad.Lython/Runtime/LythonRuntime.Executable.NativePrefix.cs';p=r/'baseline/Runtime/LythonRuntime.Executable.NativePrefix.cs';body=t.extractfile(n).read()
 if p.exists():assert p.read_bytes()==body
 else:p.write_bytes(body)
env={k:v for k,v in os.environ.items()if k.lower()!='path'};env['DOTNET_ROOT']='C:/Users/JoannesVermorel/.dotnet11';env['PATH']=env['DOTNET_ROOT']+';C:/Python313;'+os.environ.get('PATH','');sdk=env['DOTNET_ROOT']+'/dotnet.exe';rows=[]
filters={
'internal':'(Category!=Stress)&(FullyQualifiedName~Native|FullyQualifiedName~CasedSplitOwnershipTests|FullyQualifiedName~CapturedScalar|FullyQualifiedName~Stack|FullyQualifiedName~WordBufferLoanTests|FullyQualifiedName~IntegerBinaryAdmissionTests|FullyQualifiedName~ExecutableAugmentedIntegerBoundaryTests)',
'public':'(Category!=Stress)&(FullyQualifiedName~Native|FullyQualifiedName~Integer|FullyQualifiedName~NumericArithmetic|FullyQualifiedName~ForHelperExecutionTests|FullyQualifiedName~WhileHelperExecutionTests|FullyQualifiedName~LargeHelperExecutionTests|FullyQualifiedName~LoopLocalValueTests|FullyQualifiedName~Stack|FullyQualifiedName~RecursionDepthScenarioTests|FullyQualifiedName~Closure|FullyQualifiedName~Lambda|FullyQualifiedName~Generator|FullyQualifiedName~Comprehension|FullyQualifiedName~Local|FullyQualifiedName~Match|FullyQualifiedName~Scope|FullyQualifiedName~AdmissionFailureCommandTests|FullyQualifiedName~CooperativeCancellationTests|FullyQualifiedName~AsyncMidFlightCancellationTests)'}
for framework in ['net11.0','net10.0']:
 build=r/('probe-build-'+framework+'.log')
 with build.open('w',encoding='utf-8',newline='\n')as f:done=subprocess.run([sdk,'build','tools/LythonProbe/LythonProbe.csproj','-c','Release','-f',framework,'--no-restore','--disable-build-servers','-m:1','-v','quiet'],env=env,stdout=f,stderr=subprocess.STDOUT,timeout=180)
 assert done.returncode==0,build.read_text(encoding='utf-8')[-2500:]
 for label in ['internal','public']:
  project='Lokad.Lython.Tests'if label=='internal'else'Lokad.Lython.PublicApi.Tests';name='r360-'+label+'-'+framework+'.trx';log=r/(label+'-'+framework+'.log')
  with log.open('w',encoding='utf-8',newline='\n')as f:done=subprocess.run([sdk,'test','tests/'+project+'/'+project+'.csproj','-c','Release','-f',framework,'--no-restore','--filter',filters[label],'--logger','trx;LogFileName='+name,'-v','quiet'],env=env,stdout=f,stderr=subprocess.STDOUT,timeout=240)
  trx=Path('tests')/project/'TestResults'/name
  if trx.exists():
   counts=ET.parse(trx).find('.//{http://microsoft.com/schemas/VisualStudio/TeamTest/2010}Counters').attrib;shutil.copyfile(trx,r/name)
  else:counts=None
  rows.append(dict(framework=framework,label=label,exitCode=done.returncode,counters=counts));(r/'focused-checks.json').write_text(json.dumps(rows,indent=2)+'\n',encoding='utf-8',newline='\n')
  assert done.returncode==0,log.read_text(encoding='utf-8')[-5000:]
  print(label,framework,counts['passed'],'focused checks pass',flush=True)
