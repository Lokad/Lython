; Assembly listing for method Lokad.Lython.Runtime.LythonRuntime:TryMachineInstruction(Lokad.Lython.Frontend.ExecutableCodeObject,System.ReadOnlySpan`1[System.Object],System.ReadOnlySpan`1[long],int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,byref,byref):bool (Tier0)
; Emitting BLENDED_CODE for x64 + VEX + EVEX on Unix
; Tier0 code
; rbp based frame
; partially interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 160
       lea      rbp, [rsp+0xA0]
       xor      eax, eax
       mov      qword ptr [rbp-0x68], rax
       vxorps   xmm8, xmm8, xmm8
       vmovdqu  ymmword ptr [rbp-0x60], ymm8
       vmovdqa  xmmword ptr [rbp-0x40], xmm8
       mov      gword ptr [rbp-0x08], rdi
       mov      bword ptr [rbp-0x18], rsi
       mov      qword ptr [rbp-0x10], rdx
       mov      bword ptr [rbp-0x28], rcx
       mov      qword ptr [rbp-0x20], r8
       mov      dword ptr [rbp-0x2C], r9d
 
G_M000_IG02:                ;; offset=0x003D
       mov      rax, bword ptr [rbp+0x18]
       mov      ecx, dword ptr [rbp-0x2C]
       mov      dword ptr [rax], ecx
       mov      rax, 0x7B6259803130
       mov      rsi, gword ptr [rax]
       mov      rdi, bword ptr [rbp+0x20]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rax, bword ptr [rbp+0x28]
       xor      ecx, ecx
       mov      qword ptr [rax], rcx
       mov      rdi, gword ptr [rbp-0x08]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Instructions():Lokad.Lython.Frontend.ExecutableInstruction[]:this]
       mov      ecx, dword ptr [rbp-0x2C]
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG15
       mov      edx, ecx
       imul     rdx, rdx, 32
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      bword ptr [rbp-0x38], rax
       mov      rdi, bword ptr [rbp-0x38]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_OpCode():int:this]
       cmp      eax, 48
       jne      SHORT G_M000_IG03
       mov      rdi, bword ptr [rbp-0x38]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_AugmentedOperator():int:this]
       cmp      eax, 3
       jne      SHORT G_M000_IG03
       jmp      SHORT G_M000_IG04
 
G_M000_IG03:                ;; offset=0x00AC
       mov      rdi, bword ptr [rbp-0x38]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x58], eax
       lea      rax, [rbp-0x40]
       mov      qword ptr [rsp], rax
       mov      r9d, dword ptr [rbp-0x58]
       mov      rsi, bword ptr [rbp-0x18]
       mov      rdx, qword ptr [rbp-0x10]
       mov      rcx, bword ptr [rbp-0x28]
       mov      r8, qword ptr [rbp-0x20]
       mov      rdi, gword ptr [rbp-0x08]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryReadMachineOperand(Lokad.Lython.Frontend.ExecutableCodeObject,System.ReadOnlySpan`1[System.Object],System.ReadOnlySpan`1[long],int,byref):bool]
       test     eax, eax
       je       SHORT G_M000_IG04
       mov      rdi, bword ptr [rbp-0x38]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_SecondInput():int:this]
       mov      dword ptr [rbp-0x5C], eax
       lea      rax, [rbp-0x48]
       mov      qword ptr [rsp], rax
       mov      r9d, dword ptr [rbp-0x5C]
       mov      rsi, bword ptr [rbp-0x18]
       mov      rdx, qword ptr [rbp-0x10]
       mov      rcx, bword ptr [rbp-0x28]
       mov      r8, qword ptr [rbp-0x20]
       mov      rdi, gword ptr [rbp-0x08]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryReadMachineOperand(Lokad.Lython.Frontend.ExecutableCodeObject,System.ReadOnlySpan`1[System.Object],System.ReadOnlySpan`1[long],int,byref):bool]
       test     eax, eax
       jne      SHORT G_M000_IG06
 
G_M000_IG04:                ;; offset=0x011A
       xor      eax, eax
 
G_M000_IG05:                ;; offset=0x011C
       add      rsp, 160
       pop      rbp
       ret      
 
G_M000_IG06:                ;; offset=0x0125
       mov      rdi, bword ptr [rbp-0x38]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_OpCode():int:this]
       cmp      eax, 47
       jne      G_M000_IG11
       mov      rdi, bword ptr [rbp-0x38]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_BinaryOperator():int:this]
       mov      edi, eax
       call     [Lokad.Lython.Runtime.LythonRuntime:IsScalarComparison(int):bool]
       test     eax, eax
       je       SHORT G_M000_IG07
       mov      rdi, bword ptr [rbp-0x38]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x68], rax
       mov      rsi, gword ptr [rbp-0x68]
       mov      rdi, gword ptr [rbp+0x10]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CheckExecution(Lokad.Lython.LythonSourceSpan):this]
       mov      rdi, bword ptr [rbp-0x38]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_BinaryOperator():int:this]
       mov      dword ptr [rbp-0x50], eax
       lea      rdi, [rbp-0x40]
       mov      rsi, qword ptr [rbp-0x48]
       call     [System.Int64:CompareTo(long):int:this]
       mov      dword ptr [rbp-0x6C], eax
       mov      esi, dword ptr [rbp-0x6C]
       mov      edi, dword ptr [rbp-0x50]
       call     [Lokad.Lython.Runtime.LythonRuntime:CompareOrderedResult(int,int):bool]
       mov      edi, eax
       call     [Lokad.Lython.Runtime.LythonRuntime:RuntimeValue(bool):System.Object]
       mov      rsi, rax
       mov      rdi, bword ptr [rbp+0x20]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       jmp      SHORT G_M000_IG08
 
G_M000_IG07:                ;; offset=0x01AC
       mov      rax, qword ptr [rbp-0x40]
       mov      qword ptr [rsp], rax
       mov      rax, qword ptr [rbp-0x48]
       mov      qword ptr [rsp+0x08], rax
       mov      rax, gword ptr [rbp+0x10]
       mov      gword ptr [rsp+0x10], rax
       mov      rax, bword ptr [rbp+0x18]
       mov      bword ptr [rsp+0x18], rax
       mov      rax, bword ptr [rbp+0x28]
       mov      bword ptr [rsp+0x20], rax
       mov      rsi, bword ptr [rbp-0x18]
       mov      rdx, qword ptr [rbp-0x10]
       mov      rcx, bword ptr [rbp-0x28]
       mov      r8, qword ptr [rbp-0x20]
       mov      rdi, gword ptr [rbp-0x08]
       mov      r9d, dword ptr [rbp-0x2C]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryIntegerChain(Lokad.Lython.Frontend.ExecutableCodeObject,System.ReadOnlySpan`1[System.Object],System.ReadOnlySpan`1[long],int,long,long,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,byref):bool]
       test     eax, eax
       je       SHORT G_M000_IG10
 
G_M000_IG08:                ;; offset=0x01FA
       mov      eax, 1
 
G_M000_IG09:                ;; offset=0x01FF
       add      rsp, 160
       pop      rbp
       ret      
 
G_M000_IG10:                ;; offset=0x0208
       mov      rax, bword ptr [rbp+0x18]
       mov      ecx, dword ptr [rbp-0x2C]
       mov      dword ptr [rax], ecx
 
G_M000_IG11:                ;; offset=0x0211
       mov      rdi, bword ptr [rbp-0x38]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_OpCode():int:this]
       cmp      eax, 48
       je       SHORT G_M000_IG12
       mov      rdi, bword ptr [rbp-0x38]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_BinaryOperator():int:this]
       mov      dword ptr [rbp-0x4C], eax
       jmp      SHORT G_M000_IG13
 
G_M000_IG12:                ;; offset=0x022F
       mov      rdi, bword ptr [rbp-0x38]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_AugmentedOperator():int:this]
       mov      edi, eax
       call     [Lokad.Lython.Runtime.LythonRuntime:AugmentedBinaryOperator(int):int]
       mov      dword ptr [rbp-0x4C], eax
 
G_M000_IG13:                ;; offset=0x0244
       mov      edi, dword ptr [rbp-0x4C]
       mov      rsi, qword ptr [rbp-0x40]
       mov      rdx, qword ptr [rbp-0x48]
       mov      rcx, bword ptr [rbp+0x28]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryMachineBinary(int,long,long,byref):bool]
       mov      dword ptr [rbp-0x54], eax
       movzx    rax, byte  ptr [rbp-0x54]
 
G_M000_IG14:                ;; offset=0x0260
       add      rsp, 160
       pop      rbp
       ret      
 
G_M000_IG15:                ;; offset=0x0269
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
; Total bytes of code 623

; Assembly listing for method Lokad.Lython.Runtime.LythonRuntime:TryMachineInstruction(Lokad.Lython.Frontend.ExecutableCodeObject,System.ReadOnlySpan`1[System.Object],System.ReadOnlySpan`1[long],int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,byref,byref):bool (Instrumented Tier0)
; Emitting BLENDED_CODE for x64 + VEX + EVEX on Unix
; Instrumented Tier0 code
; rbp based frame
; partially interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 160
       lea      rbp, [rsp+0xA0]
       xor      eax, eax
       mov      qword ptr [rbp-0x68], rax
       vxorps   xmm8, xmm8, xmm8
       vmovdqu  ymmword ptr [rbp-0x60], ymm8
       vmovdqa  xmmword ptr [rbp-0x40], xmm8
       mov      gword ptr [rbp-0x08], rdi
       mov      bword ptr [rbp-0x18], rsi
       mov      qword ptr [rbp-0x10], rdx
       mov      bword ptr [rbp-0x28], rcx
       mov      qword ptr [rbp-0x20], r8
       mov      dword ptr [rbp-0x2C], r9d
 
G_M000_IG02:                ;; offset=0x003D
       mov      rax, bword ptr [rbp+0x18]
       mov      ecx, dword ptr [rbp-0x2C]
       mov      dword ptr [rax], ecx
       mov      rax, 0x7B6259803130
       mov      rsi, gword ptr [rax]
       mov      rdi, bword ptr [rbp+0x20]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rax, bword ptr [rbp+0x28]
       xor      ecx, ecx
       mov      qword ptr [rax], rcx
       mov      rdi, gword ptr [rbp-0x08]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Instructions():Lokad.Lython.Frontend.ExecutableInstruction[]:this]
       mov      ecx, dword ptr [rbp-0x2C]
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG18
       mov      edx, ecx
       imul     rdx, rdx, 32
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      bword ptr [rbp-0x38], rax
       mov      rdi, bword ptr [rbp-0x38]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_OpCode():int:this]
       cmp      eax, 48
       jne      SHORT G_M000_IG04
       mov      rdi, bword ptr [rbp-0x38]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_AugmentedOperator():int:this]
       cmp      eax, 3
       jne      SHORT G_M000_IG03
       mov      rdi, 0x7B6A395BBB10
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG07
 
G_M000_IG03:                ;; offset=0x00BE
       mov      rdi, 0x7B6A395BBB14
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG04:                ;; offset=0x00CD
       mov      rdi, bword ptr [rbp-0x38]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x58], eax
       lea      rax, [rbp-0x40]
       mov      qword ptr [rsp], rax
       mov      r9d, dword ptr [rbp-0x58]
       mov      rsi, bword ptr [rbp-0x18]
       mov      rdx, qword ptr [rbp-0x10]
       mov      rcx, bword ptr [rbp-0x28]
       mov      r8, qword ptr [rbp-0x20]
       mov      rdi, gword ptr [rbp-0x08]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryReadMachineOperand(Lokad.Lython.Frontend.ExecutableCodeObject,System.ReadOnlySpan`1[System.Object],System.ReadOnlySpan`1[long],int,byref):bool]
       test     eax, eax
       je       SHORT G_M000_IG06
       mov      rdi, bword ptr [rbp-0x38]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_SecondInput():int:this]
       mov      dword ptr [rbp-0x5C], eax
       lea      rax, [rbp-0x48]
       mov      qword ptr [rsp], rax
       mov      r9d, dword ptr [rbp-0x5C]
       mov      rsi, bword ptr [rbp-0x18]
       mov      rdx, qword ptr [rbp-0x10]
       mov      rcx, bword ptr [rbp-0x28]
       mov      r8, qword ptr [rbp-0x20]
       mov      rdi, gword ptr [rbp-0x08]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryReadMachineOperand(Lokad.Lython.Frontend.ExecutableCodeObject,System.ReadOnlySpan`1[System.Object],System.ReadOnlySpan`1[long],int,byref):bool]
       test     eax, eax
       jne      SHORT G_M000_IG09
 
G_M000_IG05:                ;; offset=0x013B
       mov      rdi, 0x7B6A395BBB18
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG06:                ;; offset=0x014A
       mov      rdi, 0x7B6A395BBB1C
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG07:                ;; offset=0x0159
       xor      eax, eax
 
G_M000_IG08:                ;; offset=0x015B
       add      rsp, 160
       pop      rbp
       ret      
 
G_M000_IG09:                ;; offset=0x0164
       mov      rdi, bword ptr [rbp-0x38]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_OpCode():int:this]
       cmp      eax, 47
       jne      G_M000_IG14
       mov      rdi, bword ptr [rbp-0x38]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_BinaryOperator():int:this]
       mov      edi, eax
       call     [Lokad.Lython.Runtime.LythonRuntime:IsScalarComparison(int):bool]
       test     eax, eax
       je       SHORT G_M000_IG10
       mov      rdi, 0x7B6A395BBB20
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, bword ptr [rbp-0x38]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x68], rax
       mov      rsi, gword ptr [rbp-0x68]
       mov      rdi, gword ptr [rbp+0x10]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CheckExecution(Lokad.Lython.LythonSourceSpan):this]
       mov      rdi, bword ptr [rbp-0x38]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_BinaryOperator():int:this]
       mov      dword ptr [rbp-0x50], eax
       lea      rdi, [rbp-0x40]
       mov      rsi, qword ptr [rbp-0x48]
       call     [System.Int64:CompareTo(long):int:this]
       mov      dword ptr [rbp-0x6C], eax
       mov      esi, dword ptr [rbp-0x6C]
       mov      edi, dword ptr [rbp-0x50]
       call     [Lokad.Lython.Runtime.LythonRuntime:CompareOrderedResult(int,int):bool]
       mov      edi, eax
       call     [Lokad.Lython.Runtime.LythonRuntime:RuntimeValue(bool):System.Object]
       mov      rsi, rax
       mov      rdi, bword ptr [rbp+0x20]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       jmp      SHORT G_M000_IG11
 
G_M000_IG10:                ;; offset=0x01FA
       mov      rax, qword ptr [rbp-0x40]
       mov      qword ptr [rsp], rax
       mov      rax, qword ptr [rbp-0x48]
       mov      qword ptr [rsp+0x08], rax
       mov      rax, gword ptr [rbp+0x10]
       mov      gword ptr [rsp+0x10], rax
       mov      rax, bword ptr [rbp+0x18]
       mov      bword ptr [rsp+0x18], rax
       mov      rax, bword ptr [rbp+0x28]
       mov      bword ptr [rsp+0x20], rax
       mov      rsi, bword ptr [rbp-0x18]
       mov      rdx, qword ptr [rbp-0x10]
       mov      rcx, bword ptr [rbp-0x28]
       mov      r8, qword ptr [rbp-0x20]
       mov      rdi, gword ptr [rbp-0x08]
       mov      r9d, dword ptr [rbp-0x2C]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryIntegerChain(Lokad.Lython.Frontend.ExecutableCodeObject,System.ReadOnlySpan`1[System.Object],System.ReadOnlySpan`1[long],int,long,long,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,byref):bool]
       test     eax, eax
       je       SHORT G_M000_IG13
       mov      rdi, 0x7B6A395BBB24
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG11:                ;; offset=0x0257
       mov      eax, 1
 
G_M000_IG12:                ;; offset=0x025C
       add      rsp, 160
       pop      rbp
       ret      
 
G_M000_IG13:                ;; offset=0x0265
       mov      rdi, 0x7B6A395BBB28
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x18]
       mov      ecx, dword ptr [rbp-0x2C]
       mov      dword ptr [rax], ecx
 
G_M000_IG14:                ;; offset=0x027D
       mov      rdi, bword ptr [rbp-0x38]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_OpCode():int:this]
       cmp      eax, 48
       je       SHORT G_M000_IG15
       mov      rdi, bword ptr [rbp-0x38]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_BinaryOperator():int:this]
       mov      dword ptr [rbp-0x4C], eax
       jmp      SHORT G_M000_IG16
 
G_M000_IG15:                ;; offset=0x029B
       mov      rdi, 0x7B6A395BBB2C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, bword ptr [rbp-0x38]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_AugmentedOperator():int:this]
       mov      edi, eax
       call     [Lokad.Lython.Runtime.LythonRuntime:AugmentedBinaryOperator(int):int]
       mov      dword ptr [rbp-0x4C], eax
 
G_M000_IG16:                ;; offset=0x02BF
       mov      rdi, 0x7B6A395BBB30
       call     CORINFO_HELP_COUNTPROFILE32
       mov      edi, dword ptr [rbp-0x4C]
       mov      rsi, qword ptr [rbp-0x40]
       mov      rdx, qword ptr [rbp-0x48]
       mov      rcx, bword ptr [rbp+0x28]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryMachineBinary(int,long,long,byref):bool]
       mov      dword ptr [rbp-0x54], eax
       movzx    rax, byte  ptr [rbp-0x54]
 
G_M000_IG17:                ;; offset=0x02EA
       add      rsp, 160
       pop      rbp
       ret      
 
G_M000_IG18:                ;; offset=0x02F3
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
; Total bytes of code 761

; Assembly listing for method Lokad.Lython.Runtime.LythonRuntime:TryMachineInstruction(Lokad.Lython.Frontend.ExecutableCodeObject,System.ReadOnlySpan`1[System.Object],System.ReadOnlySpan`1[long],int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,byref,byref):bool (Tier1)
; Emitting BLENDED_CODE for x64 + VEX + EVEX on Unix
; Tier1 code
; optimized code
; optimized using Synthesized PGO
; rbp based frame
; partially interruptible
; with Synthesized PGO: fgCalledCount is 71088
; 26 inlinees with PGO data; 34 single block inlinees; 1 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       push     r15
       push     r14
       push     r13
       push     r12
       push     rbx
       sub      rsp, 152
       lea      rbp, [rsp+0xC0]
       xor      eax, eax
       mov      qword ptr [rbp-0x50], rax
       mov      dword ptr [rbp-0x54], r8d
       mov      r15, rdi
       mov      r14, rsi
       mov      r13d, edx
       mov      r12, rcx
       mov      ebx, r9d
       mov      rdx, bword ptr [rbp+0x18]
       mov      rdi, bword ptr [rbp+0x20]
 
G_M000_IG02:                ;; offset=0x003A
       mov      bword ptr [rbp+0x18], rdx
       mov      dword ptr [rdx], ebx
       mov      rsi, 0x7B6259803130
       mov      r8, gword ptr [rsi]
       mov      rsi, r8
       mov      gword ptr [rbp-0x90], rsi
       mov      bword ptr [rbp+0x20], rdi
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       xor      esi, esi
       mov      rax, bword ptr [rbp+0x28]
       mov      qword ptr [rax], rsi
       mov      rsi, gword ptr [r15+0x50]
       cmp      ebx, dword ptr [rsi+0x08]
       jae      G_M000_IG86
       mov      edi, ebx
       shl      rdi, 5
       lea      rcx, bword ptr [rsi+rdi+0x10]
       mov      bword ptr [rbp-0x70], rcx
       cmp      dword ptr [rcx+0x1C], 48
       jne      SHORT G_M000_IG04
 
G_M000_IG03:                ;; offset=0x008B
       cmp      dword ptr [rcx+0x08], 3
       je       G_M000_IG81
 
G_M000_IG04:                ;; offset=0x0095
       mov      edx, dword ptr [rcx+0x10]
       mov      dword ptr [rbp-0x3C], edx
       test     edx, edx
       jl       G_M000_IG23
 
G_M000_IG05:                ;; offset=0x00A3
       cmp      edx, r13d
       jae      G_M000_IG86
       mov      esi, edx
       mov      rdi, gword ptr [r14+8*rsi]
 
G_M000_IG06:                ;; offset=0x00B2
       mov      rsi, gword ptr [rbp-0x90]
       cmp      rdi, rsi
       je       G_M000_IG42
 
G_M000_IG07:                ;; offset=0x00C2
       test     rdi, rdi
       jne      G_M000_IG25
 
G_M000_IG08:                ;; offset=0x00CB
       test     rdi, rdi
       jne      G_M000_IG27
 
G_M000_IG09:                ;; offset=0x00D4
       xor      r10d, r10d
       xor      edx, edx
 
G_M000_IG10:                ;; offset=0x00D9
       test     r10d, r10d
       je       G_M000_IG81
 
G_M000_IG11:                ;; offset=0x00E2
       mov      rcx, bword ptr [rbp-0x70]
       mov      r8d, dword ptr [rcx+0x0C]
       mov      dword ptr [rbp-0x44], r8d
       test     r8d, r8d
       jl       G_M000_IG43
 
G_M000_IG12:                ;; offset=0x00F7
       cmp      r8d, r13d
       jae      G_M000_IG86
       mov      r9d, r8d
       mov      r9, gword ptr [r14+8*r9]
 
G_M000_IG13:                ;; offset=0x0107
       mov      rsi, gword ptr [rbp-0x90]
       cmp      r9, rsi
       je       G_M000_IG63
 
G_M000_IG14:                ;; offset=0x0117
       test     r9, r9
       jne      G_M000_IG45
 
G_M000_IG15:                ;; offset=0x0120
       test     r9, r9
       jne      G_M000_IG47
 
G_M000_IG16:                ;; offset=0x0129
       xor      r11d, r11d
       xor      esi, esi
 
G_M000_IG17:                ;; offset=0x012E
       test     r11d, r11d
       mov      edi, dword ptr [rbp-0x54]
       je       G_M000_IG81
 
G_M000_IG18:                ;; offset=0x013A
       mov      rcx, bword ptr [rbp-0x70]
       cmp      dword ptr [rcx+0x1C], 47
       je       G_M000_IG64
 
G_M000_IG19:                ;; offset=0x0148
       cmp      dword ptr [rcx+0x1C], 48
       jne      G_M000_IG72
 
G_M000_IG20:                ;; offset=0x0152
       mov      qword ptr [rbp-0x30], rdx
       mov      qword ptr [rbp-0x38], rsi
       mov      edi, dword ptr [rcx+0x08]
       call     [Lokad.Lython.Runtime.LythonRuntime:AugmentedBinaryOperator(int):int]
       mov      rdx, qword ptr [rbp-0x30]
 
G_M000_IG21:                ;; offset=0x0167
       mov      edi, eax
       mov      rsi, rdx
       mov      rdx, qword ptr [rbp-0x38]
       mov      rcx, bword ptr [rbp+0x28]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryMachineBinary(int,long,long,byref):bool]
       movzx    rax, al
 
G_M000_IG22:                ;; offset=0x017D
       add      rsp, 152
       pop      rbx
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG23:                ;; offset=0x018F
       mov      rdi, gword ptr [r15+0x10]
       mov      rsi, 0x7B6A37C727A0
       cmp      qword ptr [rdi], rsi
       jne      G_M000_IG77
       mov      esi, edx
       not      esi
       cmp      dword ptr [rdi+0x08], esi
       jbe      G_M000_IG76
       mov      rdi, gword ptr [rdi+8*rsi+0x10]
 
G_M000_IG24:                ;; offset=0x01B8
       jmp      G_M000_IG06
 
G_M000_IG25:                ;; offset=0x01BD
       mov      rdx, 0x7B6A393F6810
       cmp      qword ptr [rdi], rdx
       jne      G_M000_IG08
 
G_M000_IG26:                ;; offset=0x01D0
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableCell:get_Value():System.Object:this]
       mov      rdi, rax
       test     rdi, rdi
       je       G_M000_IG09
 
G_M000_IG27:                ;; offset=0x01E2
       mov      rdx, 0x7B6A3909DE58
       cmp      qword ptr [rdi], rdx
       jne      G_M000_IG09
 
G_M000_IG28:                ;; offset=0x01F5
       mov      r8, gword ptr [rdi+0x08]
       mov      gword ptr [rbp-0x78], r8
       mov      r9d, dword ptr [rdi+0x10]
       mov      dword ptr [rbp-0x58], r9d
       test     r9d, r9d
       je       G_M000_IG36
 
G_M000_IG29:                ;; offset=0x020E
       test     r8, r8
       je       G_M000_IG39
 
G_M000_IG30:                ;; offset=0x0217
       cmp      r9d, -1
       je       G_M000_IG38
 
G_M000_IG31:                ;; offset=0x0221
       xor      r10d, r10d
       mov      r11d, dword ptr [r8+0x08]
       lea      edx, [r11-0x01]
       cmp      edx, r11d
       jae      G_M000_IG86
       mov      r11d, edx
       mov      r11, qword ptr [r8+8*r11+0x10]
       mov      edi, r10d
       mov      r9d, dword ptr [rbp-0x58]
 
G_M000_IG32:                ;; offset=0x0244
       xor      r10d, r10d
       lzcnt    r10, r11
       shr      r10d, 3
       mov      edx, r10d
       neg      edx
       add      edx, 7
       xor      r10d, r10d
       test     edx, edx
       cmovg    r10d, edx
 
G_M000_IG33:                ;; offset=0x0261
       lea      edx, [8*r10]
       shrx     rdx, r11, rdx
       movzx    rdx, dl
       and      edx, 128
       and      edi, 128
       cmp      edx, edi
       setne    dil
       movzx    rdi, dil
       test     edi, edi
       setne    dil
       movzx    rdi, dil
       lea      edi, [r10+rdi+0x01]
       test     r8, r8
       je       SHORT G_M000_IG35
 
G_M000_IG34:                ;; offset=0x029B
       mov      r11d, dword ptr [r8+0x08]
       sub      r11d, 1
       imul     edx, r11d, 8
       jo       G_M000_IG87
       add      edi, edx
       jo       G_M000_IG87
 
G_M000_IG35:                ;; offset=0x02B5
       cmp      edi, 8
       jg       G_M000_IG78
 
G_M000_IG36:                ;; offset=0x02BE
       mov      rdi, r8
       mov      esi, r9d
       call     [System.Numerics.BigInteger:op_Explicit(System.Numerics.BigInteger):long]
       mov      r10d, 1
 
G_M000_IG37:                ;; offset=0x02D0
       mov      rdx, rax
       jmp      G_M000_IG10
 
G_M000_IG38:                ;; offset=0x02D8
       mov      dword ptr [rbp-0x40], 255
       lea      rdi, bword ptr [r8+0x10]
       mov      r11d, dword ptr [r8+0x08]
       mov      dword ptr [rbp-0x60], r11d
       mov      edx, r11d
       xor      esi, esi
       call     [System.SpanHelpers:NonPackedIndexOfValueType[long,System.SpanHelpers+Negate`1[long]](byref,long,int):int]
       mov      r11d, dword ptr [rbp-0x60]
       lea      edx, [r11-0x01]
       cmp      edx, r11d
       jae      G_M000_IG86
       mov      r11d, edx
       mov      rsi, gword ptr [rbp-0x78]
       mov      rdi, qword ptr [rsi+8*r11+0x10]
       mov      r11, rdi
       not      r11
       lea      rdi, [r11+0x01]
       cmp      edx, eax
       cmove    r11, rdi
       mov      r8, rsi
       mov      edi, dword ptr [rbp-0x40]
       mov      r9d, dword ptr [rbp-0x58]
       jmp      SHORT G_M000_IG40
 
G_M000_IG39:                ;; offset=0x032F
       mov      r10d, 255
       xor      r11d, r11d
       test     r9d, r9d
       cmovge   r10d, r11d
       mov      edi, r10d
       movsxd   r11, r9d
 
G_M000_IG40:                ;; offset=0x0345
       test     edi, edi
       je       G_M000_IG32
 
G_M000_IG41:                ;; offset=0x034D
       mov      rdx, r11
       not      rdx
       lzcnt    rdx, rdx
       shr      edx, 3
       neg      edx
       add      edx, 7
       xor      r10d, r10d
       test     edx, edx
       cmovg    r10d, edx
       jmp      G_M000_IG33
 
G_M000_IG42:                ;; offset=0x036E
       cmp      edx, dword ptr [rbp-0x54]
       jae      G_M000_IG86
       mov      edx, edx
       mov      rdx, qword ptr [r12+8*rdx]
       mov      qword ptr [rbp-0x30], rdx
       jmp      G_M000_IG11
 
G_M000_IG43:                ;; offset=0x0386
       mov      r9, gword ptr [r15+0x10]
       mov      r10, 0x7B6A37C727A0
       cmp      qword ptr [r9], r10
       jne      G_M000_IG79
       mov      r10d, r8d
       not      r10d
       cmp      dword ptr [r9+0x08], r10d
       jbe      G_M000_IG76
       mov      r9, gword ptr [r9+8*r10+0x10]
 
G_M000_IG44:                ;; offset=0x03B2
       jmp      G_M000_IG13
 
G_M000_IG45:                ;; offset=0x03B7
       mov      rsi, 0x7B6A393F6810
       cmp      qword ptr [r9], rsi
       jne      G_M000_IG15
 
G_M000_IG46:                ;; offset=0x03CA
       mov      qword ptr [rbp-0x30], rdx
       mov      rdi, r9
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableCell:get_Value():System.Object:this]
       mov      r9, rax
       test     r9, r9
       mov      rdx, qword ptr [rbp-0x30]
       je       G_M000_IG16
 
G_M000_IG47:                ;; offset=0x03E7
       mov      rsi, 0x7B6A3909DE58
       cmp      qword ptr [r9], rsi
       jne      G_M000_IG16
 
G_M000_IG48:                ;; offset=0x03FA
       mov      r8, gword ptr [r9+0x08]
       mov      gword ptr [rbp-0x80], r8
       mov      r9d, dword ptr [r9+0x10]
       mov      dword ptr [rbp-0x5C], r9d
       test     r9d, r9d
       je       G_M000_IG60
 
G_M000_IG49:                ;; offset=0x0413
       test     r8, r8
       je       G_M000_IG57
 
G_M000_IG50:                ;; offset=0x041C
       cmp      r9d, -1
       je       G_M000_IG56
 
G_M000_IG51:                ;; offset=0x0426
       xor      r10d, r10d
       mov      r11d, dword ptr [r8+0x08]
       lea      esi, [r11-0x01]
       cmp      esi, r11d
       jae      G_M000_IG86
       mov      r11d, esi
       mov      r11, qword ptr [r8+8*r11+0x10]
       mov      dword ptr [rbp-0x48], r10d
       mov      r9d, dword ptr [rbp-0x5C]
 
G_M000_IG52:                ;; offset=0x044A
       xor      r10d, r10d
       lzcnt    r10, r11
       shr      r10d, 3
       neg      r10d
       add      r10d, 7
       xor      esi, esi
       test     r10d, r10d
       cmovg    esi, r10d
 
G_M000_IG53:                ;; offset=0x0466
       lea      r10d, [8*rsi]
       shrx     r10, r11, r10
       movzx    r10, r10b
       and      r10d, 128
       mov      r11d, dword ptr [rbp-0x48]
       and      r11d, 128
       cmp      r10d, r11d
       setne    r10b
       movzx    r10, r10b
       test     r10d, r10d
       setne    r10b
       movzx    r10, r10b
       lea      esi, [rsi+r10+0x01]
       test     r8, r8
       je       SHORT G_M000_IG55
 
G_M000_IG54:                ;; offset=0x04A9
       mov      r11d, dword ptr [r8+0x08]
       sub      r11d, 1
       imul     r10d, r11d, 8
       jo       G_M000_IG87
       add      esi, r10d
       jo       G_M000_IG87
 
G_M000_IG55:                ;; offset=0x04C4
       cmp      esi, 8
       jg       G_M000_IG80
       mov      qword ptr [rbp-0x30], rdx
       jmp      G_M000_IG61
 
G_M000_IG56:                ;; offset=0x04D6
       mov      qword ptr [rbp-0x30], rdx
       mov      dword ptr [rbp-0x48], 255
       lea      rsi, bword ptr [r8+0x10]
       mov      bword ptr [rbp-0x88], rsi
       mov      r11d, dword ptr [r8+0x08]
       mov      dword ptr [rbp-0x64], r11d
       mov      esi, r11d
       mov      rdi, bword ptr [rbp-0x88]
       mov      edx, esi
       xor      esi, esi
       call     [System.SpanHelpers:NonPackedIndexOfValueType[long,System.SpanHelpers+Negate`1[long]](byref,long,int):int]
       mov      r11d, dword ptr [rbp-0x64]
       lea      esi, [r11-0x01]
       cmp      esi, r11d
       jae      G_M000_IG86
       mov      r11d, esi
       mov      r8, gword ptr [rbp-0x80]
       mov      rdi, qword ptr [r8+8*r11+0x10]
       mov      r11, rdi
       not      r11
       lea      rdi, [r11+0x01]
       cmp      esi, eax
       cmove    r11, rdi
       mov      rdx, qword ptr [rbp-0x30]
       mov      esi, dword ptr [rbp-0x48]
       mov      r9d, dword ptr [rbp-0x5C]
       jmp      SHORT G_M000_IG58
 
G_M000_IG57:                ;; offset=0x0542
       mov      r10d, 255
       xor      r11d, r11d
       test     r9d, r9d
       cmovge   r10d, r11d
       mov      esi, r10d
       movsxd   r11, r9d
 
G_M000_IG58:                ;; offset=0x0558
       mov      dword ptr [rbp-0x48], esi
       test     esi, esi
       je       G_M000_IG52
 
G_M000_IG59:                ;; offset=0x0563
       mov      r10, r11
       not      r10
       lzcnt    r10, r10
       shr      r10d, 3
       neg      r10d
       add      r10d, 7
       xor      esi, esi
       test     r10d, r10d
       cmovg    esi, r10d
       jmp      G_M000_IG53
 
G_M000_IG60:                ;; offset=0x0587
       mov      qword ptr [rbp-0x30], rdx
 
G_M000_IG61:                ;; offset=0x058B
       mov      rdi, r8
       mov      esi, r9d
       call     [System.Numerics.BigInteger:op_Explicit(System.Numerics.BigInteger):long]
       mov      rcx, rax
       mov      r11d, 1
 
G_M000_IG62:                ;; offset=0x05A0
       mov      rsi, rcx
       mov      rdx, qword ptr [rbp-0x30]
       jmp      G_M000_IG17
 
G_M000_IG63:                ;; offset=0x05AC
       mov      edi, dword ptr [rbp-0x54]
       cmp      r8d, edi
       jae      G_M000_IG86
       mov      esi, r8d
       mov      rsi, qword ptr [r12+8*rsi]
       mov      qword ptr [rbp-0x38], rsi
       jmp      G_M000_IG18
 
G_M000_IG64:                ;; offset=0x05C8
       mov      r8d, dword ptr [rcx+0x08]
       add      r8d, -15
       cmp      r8d, 5
       ja       G_M000_IG71
 
G_M000_IG65:                ;; offset=0x05DA
       mov      r12, gword ptr [rcx]
       mov      r14, gword ptr [rbp+0x10]
       mov      rdi, gword ptr [r14+0xA0]
       mov      rax, gword ptr [rdi+0x88]
       mov      rax, gword ptr [rax+0x20]
       test     rax, rax
       jne      G_M000_IG83
       mov      qword ptr [rbp-0x30], rdx
       mov      qword ptr [rbp-0x38], rsi
       mov      rdi, gword ptr [rdi+0x178]
       mov      gword ptr [rbp-0x50], rdi
       lea      rdi, [rbp-0x50]
       call     [System.Threading.CancellationToken:get_IsCancellationRequested():bool:this]
       test     eax, eax
       jne      G_M000_IG84
 
G_M000_IG66:                ;; offset=0x0621
       mov      rdi, bword ptr [rbp-0x70]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_BinaryOperator():int:this]
       mov      edi, eax
       mov      r12, qword ptr [rbp-0x30]
       mov      rbx, qword ptr [rbp-0x38]
       cmp      r12, rbx
       jl       G_M000_IG85
 
G_M000_IG67:                ;; offset=0x063E
       cmp      r12, rbx
       setg     sil
       movzx    rsi, sil
 
G_M000_IG68:                ;; offset=0x0649
       call     [Lokad.Lython.Runtime.LythonRuntime:CompareOrderedResult(int,int):bool]
       mov      rdi, 0x7B6259803110
       mov      rsi, 0x7B6259803118
       test     eax, eax
       mov      rsi, gword ptr [rsi]
       cmovne   rsi, gword ptr [rdi]
       mov      rdi, bword ptr [rbp+0x20]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
 
G_M000_IG69:                ;; offset=0x0675
       mov      eax, 1
 
G_M000_IG70:                ;; offset=0x067A
       add      rsp, 152
       pop      rbx
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG71:                ;; offset=0x068C
       mov      qword ptr [rbp-0x30], rdx
       mov      qword ptr [rsp], rdx
       mov      qword ptr [rbp-0x38], rsi
       mov      qword ptr [rsp+0x08], rsi
       mov      r8, gword ptr [rbp+0x10]
       mov      gword ptr [rsp+0x10], r8
       mov      r10, bword ptr [rbp+0x18]
       mov      bword ptr [rsp+0x18], r10
       mov      rax, bword ptr [rbp+0x28]
       mov      bword ptr [rsp+0x20], rax
       mov      rcx, r12
       mov      r8d, edi
       mov      rsi, r14
       mov      edx, r13d
       mov      rdi, r15
       mov      r9d, ebx
       call     [Lokad.Lython.Runtime.LythonRuntime:TryIntegerChain(Lokad.Lython.Frontend.ExecutableCodeObject,System.ReadOnlySpan`1[System.Object],System.ReadOnlySpan`1[long],int,long,long,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,byref):bool]
       test     eax, eax
       jne      SHORT G_M000_IG69
       mov      r15, bword ptr [rbp+0x18]
       mov      dword ptr [r15], ebx
       mov      rcx, bword ptr [rbp-0x70]
       mov      rdx, qword ptr [rbp-0x30]
       mov      rsi, qword ptr [rbp-0x38]
       jmp      G_M000_IG19
 
G_M000_IG72:                ;; offset=0x06EC
       cmp      dword ptr [rcx+0x1C], 52
       jne      SHORT G_M000_IG75
 
G_M000_IG73:                ;; offset=0x06F2
       mov      edi, dword ptr [rcx+0x14]
 
G_M000_IG74:                ;; offset=0x06F5
       mov      qword ptr [rbp-0x38], rsi
       mov      eax, edi
       jmp      G_M000_IG21
 
G_M000_IG75:                ;; offset=0x0700
       mov      edi, dword ptr [rcx+0x08]
       jmp      SHORT G_M000_IG74
 
G_M000_IG76:                ;; offset=0x0705
       call     [System.ThrowHelper:ThrowArgumentOutOfRange_IndexMustBeLessException()]
       int3     
 
G_M000_IG77:                ;; offset=0x070C
       mov      esi, edx
       not      esi
       mov      r11, 0x7B6A36A52A58
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       mov      rdi, rax
       mov      edx, dword ptr [rbp-0x3C]
       jmp      G_M000_IG24
 
G_M000_IG78:                ;; offset=0x0728
       xor      edx, edx
       xor      r10d, r10d
       mov      rax, rdx
       jmp      G_M000_IG37
 
G_M000_IG79:                ;; offset=0x0735
       mov      qword ptr [rbp-0x30], rdx
       mov      esi, r8d
       not      esi
       mov      rdi, r9
       mov      r11, 0x7B6A36A52A80
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       mov      r9, rax
       mov      rdx, qword ptr [rbp-0x30]
       mov      r8d, dword ptr [rbp-0x44]
       jmp      G_M000_IG44
 
G_M000_IG80:                ;; offset=0x075E
       xor      r10d, r10d
       xor      r11d, r11d
       mov      qword ptr [rbp-0x30], rdx
       mov      rcx, r10
       jmp      G_M000_IG62
 
G_M000_IG81:                ;; offset=0x0770
       xor      eax, eax
 
G_M000_IG82:                ;; offset=0x0772
       add      rsp, 152
       pop      rbx
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG83:                ;; offset=0x0784
       mov      rdi, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG84:                ;; offset=0x078D
       mov      rdi, r12
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionCanceled(Lokad.Lython.LythonSourceSpan)]
       jmp      G_M000_IG66
 
G_M000_IG85:                ;; offset=0x079B
       mov      esi, -1
       jmp      G_M000_IG68
 
G_M000_IG86:                ;; offset=0x07A5
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG87:                ;; offset=0x07AB
       call     CORINFO_HELP_OVERFLOW
       int3     
 
; Total bytes of code 1969

