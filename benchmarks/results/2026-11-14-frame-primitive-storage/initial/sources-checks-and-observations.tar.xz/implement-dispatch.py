from pathlib import Path
root=Path('src/Lokad.Lython')
p=root/'Runtime/LythonRuntime.Executable.NativeIntegers.cs';p.write_text('''using Lokad.Lython.Frontend;

namespace Lokad.Lython.Runtime;

internal sealed partial class LythonRuntime
{
    internal ref partial struct NativeExecution
    {
        private bool TryIntegerOperation()
        {
            if (!TryMachineInstruction(Code, Values, _integers, Index, _scope,
                out var end, out var result, out var integer)) return false;
            Index = end;
            if (ReferenceEquals(result, DeferredInteger)) PublishInteger(Code.Instructions[end], integer);
            else Publish(Code.Instructions[end], result);
            return true;
        }

        private void PublishInteger(in ExecutableInstruction instruction, long value)
        {
            var slot = instruction.HasLocalResult ? Code.Instructions[Index + 1].LocalSlot : instruction.ResultSlot;
            Publish(instruction, DeferredInteger);
            _integers[slot] = value;
            _hasIntegers = true;
        }

        private object? Materialize(int slot) => MaterializeInteger(Values, _integers, slot);

        private void MaterializeRange(int start, int count)
        {
            if (!_hasIntegers) return;
            for (var i = start; i < start + count; i++) _ = Materialize(i);
        }
    }
}
''',encoding='utf-8',newline='\n')
p=root/'Runtime/LythonRuntime.Executable.NativePrefix.cs';s=p.read_text(encoding='utf-8');assert s.count('TryIntegerOperation(instruction)')==1;s=s.replace('TryIntegerOperation(instruction)','TryIntegerOperation()');assert s.count('TryIntegerComparison(instruction, out truth)')==1;s=s.replace('TryIntegerComparison(instruction, out truth)','TryMachineComparison(Code, Values, _integers, Index, _scope, out truth)');p.write_text(s,encoding='utf-8',newline='\n')
p=root/'Runtime/LythonRuntime.Executable.IntegerChains.cs';s=p.read_text(encoding='utf-8');start=s.index('    private static bool TryIntegerChain(');end=s.index('    private static bool TryIntegerChain(',start+1);s=s[:start]+s[end:];s=s.replace('// The caller boxes the one published value using existing minor-\n        // storage headroom. No object represents intermediate results.','// The caller publishes through its existing lifetime machinery. Only\n        // observation requires a guest object; intermediate results need none.');p.write_text(s,encoding='utf-8',newline='\n')
p=root/'Runtime/LythonRuntime.Executable.Inputs.cs';s=p.read_text(encoding='utf-8');old='''            nextCall = default;
            // A failed leaf read'''.replace('+','');new='''            nextCall = default;
            if (instruction.OpCode is ExecutableOpCode.Binary or ExecutableOpCode.Augmented
                && TryExecuteMachineInput(ref execution, scope, invocation, instruction))
                return InstructionPause.Continue;
            // A failed leaf read'''.replace('+','');assert s.count(old)==1;s=s.replace(old,new)
start=s.index('                if (instruction.OpCode == ExecutableOpCode.Binary\n');end=s.index('                if (instruction.OpCode is ExecutableOpCode.StoreSubscript',start);s=s[:start]+s[end:]
anchor='''        private async ValueTask ExecuteCapturedValueOperationAsync'''
helper='''        private static bool TryExecuteMachineInput(ref ExecutableWorkState execution, ExecutionContext scope,
            ExecutionContext? invocation, in ExecutableInstruction instruction)
        {
            try
            {
                if (!TryMachineInstruction(execution.Code, execution.Stack.RawValues, execution.Stack.IntegerValues,
                    execution.InstructionIndex, scope, out var end, out var result, out var integer)) return false;
                if (end != execution.InstructionIndex
                    && !execution.Stack.CanRetireWithoutCleanup(execution.Code.Instructions[end].LiveExtent)) return false;
                execution.InstructionIndex = end;
                PublishInstructionResult(ref execution, invocation, execution.Code.Instructions[end], result, integer);
                return true;
            }
            catch
            {
                execution.Stack.RetireTo(instruction.ResultSlot);
                throw;
            }
        }

''';assert s.count(anchor)==1;s=s.replace(anchor,helper+anchor);p.write_text(s,encoding='utf-8',newline='\n')
p=root/'Runtime/LythonRuntime.Executable.Comparisons.cs';s=p.read_text(encoding='utf-8');anchor='''            pendingSpan = null;
            var first'''.replace('+','');new='''            pendingSpan = null;
            try
            {
                if (TryMachineComparison(execution.Code, execution.Stack.RawValues, execution.Stack.IntegerValues,
                    execution.InstructionIndex, scope, out var integerTruth))
                {
                    pending = new(CompleteComparisonBranch(ref execution, scope, instruction, integerTruth));
                    return InstructionPause.Continue;
                }
            }
            catch { execution.Stack.RetireTo(instruction.LiveExtent); throw; }
            var first'''.replace('+','');assert s.count(anchor)==1;s=s.replace(anchor,new);p.write_text(s,encoding='utf-8',newline='\n')
print('Shared native/frame machine dispatch installed; displaced object-chain wrapper and duplicate native kernel removed.')
