from pathlib import Path
import hashlib,json,os,subprocess
r=Path(__file__).parent;probe=Path('tools/LythonProbe/bin/Release/net11.0/LythonProbe.dll').resolve();digest=hashlib.sha256((probe.parent/'Lokad.Lython.dll').read_bytes()).hexdigest();assert digest.startswith('a4bfbfd8')
snippets=[]
for token in ['@','@=']:
 operation='return left @ right' if token=='@' else 'left @= right\n    return left'
 snippets.append('def multiply(left,right):\n    '+operation+'\noriginal=13\ntry:\n multiply(original,2)\nexcept TypeError:\n print("caught",original)\n')
env={k:v for k,v in os.environ.items()if k.lower()!='path'};env['PATH']=os.environ.get('PATH','');env['DOTNET_ROOT']='C:/Users/JoannesVermorel/.dotnet11';rows=[]
for asynchronous in [False,True]:
 done=subprocess.run([env['DOTNET_ROOT']+'/dotnet.exe',str(probe),'--batch-json','--compare-python','--python','C:/Python313/python.exe']+(['--async']if asynchronous else[]),input=json.dumps(snippets).encode(),capture_output=True,env=env,timeout=30)
 (r/('baseline-matrix-'+str(asynchronous)+'.jsonl')).write_bytes(done.stdout);(r/('baseline-matrix-'+str(asynchronous)+'.stderr')).write_bytes(done.stderr);rows.append(dict(asynchronous=asynchronous,exitCode=done.returncode,results=[json.loads(line)for line in done.stdout.splitlines()]));print(asynchronous,[(x['Matches'],x['Lython']['Failure'])for x in rows[-1]['results']],flush=True)
(r/'baseline-matrix-characterization.json').write_text(json.dumps(dict(baselineCore=digest,controls=rows,sources=snippets),indent=2)+'\n',encoding='utf-8',newline='\n')
