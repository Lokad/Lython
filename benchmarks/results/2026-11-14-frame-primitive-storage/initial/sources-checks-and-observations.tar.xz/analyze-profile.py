from pathlib import Path
import ast,runpy,json
r=Path(__file__).parent;out=r/'b738';old=r.parent/'fulfillment-stage-r354/analyze-fulfillment.py';s=old.read_text(encoding='utf-8').replace('profiles/fulfillment','profiles/csv-while').replace('Committedf5817a15/frozen9cfb7d5b fulfillment complete-script CPU attribution','R360uncommitted/frozenb9ad2490 complete CSVwhile CPU attribution').replace('attribution-fulfillment.json','attribution-primitive.json');ast.parse(s);p=out/'analyze-primitive.py';p.write_text(s,encoding='utf-8',newline='\n');a=runpy.run_path(str(p))
for name,count in a['leaves'].most_common(22):print(count,name,flush=True)
print('Nearest owning frames:',flush=True)
for name,count in a['guest'].most_common(12):print(count,name,flush=True)
maps=[(hex(v[0]),v[1],v[2])for v in a['ranges']if 'TryMachineInstruction('in v[2]and'OptimizedTier1'in v[2]];print('Machine methodmaps',maps,flush=True)
(out/'leaf-census.json').write_text(json.dumps(dict(leaves=a['leaves'].most_common(),nearest=a['guest'].most_common(),sampleCount=a['leaves'].total(),interpretation='OwningCPUleaves/inlinedwork; not removable shares or timing forecasts.'),indent=2)+'\n',encoding='utf-8',newline='\n')
