from pathlib import Path
import json,hashlib,subprocess
r=Path(__file__).parent;root=Path('src/Lokad.Lython');names=['Frontend/ExecutableScript.cs','Frontend/ExecutableScript.NativeSegments.cs','Runtime/LythonRuntime.Executable.cs','Runtime/LythonRuntime.Executable.Binding.cs','Runtime/LythonRuntime.Executable.Interpreter.cs','Runtime/LythonRuntime.Executable.Interpreter.Dispatch.cs','Runtime/LythonRuntime.Executable.Operations.cs','Runtime/LythonRuntime.Executable.Calls.Invoke.cs','Runtime/LythonRuntime.Executable.Inputs.cs','Runtime/LythonRuntime.Executable.Comparisons.cs','Runtime/LythonRuntime.Executable.IntegerChains.cs','Runtime/LythonRuntime.Executable.NativeIntegers.cs','Runtime/LythonRuntime.Executable.Results.cs','Runtime/LythonRuntime.Executable.DictionaryAccumulation.cs','Runtime/PyExecutableFunction.cs']
base=r/'baseline';base.mkdir()
for name in names:
 p=base/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes((root/name).read_bytes())
test=Path('tests/Lokad.Lython.Tests/WordBufferLoanTests.cs');(r/'WordBufferLoanTests.baseline.cs').write_bytes(test.read_bytes())
(r/'baseline.json').write_text(json.dumps(dict(head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),sources={name:hashlib.sha256((root/name).read_bytes()).hexdigest()for name in names}),indent=2)+'\n',encoding='utf-8',newline='\n')
def replace(name,old,new):
 p=root/name;s=p.read_text(encoding='utf-8');assert s.count(old)==1,(name,old[:90],s.count(old));p.write_text(s.replace(old,new),encoding='utf-8',newline='\n')

replace(names[0],'''        PrepareNativeSegments(callSites);
        var integerStorageCapacity = 0;
        CanRunNativeInstructions = IsFunctionScope && !RequiresLocalVariableMirroring && capturedLocalSlots.Count == 0
            && exceptionRegions.Count == 0
            && PrepareInlineStorage(out integerStorageCapacity);
        NativeIntegerStorageCapacity = integerStorageCapacity;''','''        var nativeFacts = PrepareNativeSegments(callSites);
        CanRunNativeInstructions = IsFunctionScope && !RequiresLocalVariableMirroring && capturedLocalSlots.Count == 0
            && exceptionRegions.Count == 0 && nativeFacts.AllInline;
        IntegerStorageCapacity = nativeFacts.WritesIntegers ? ValueStorageCapacity : 0;''')
p=root/names[0];s=p.read_text(encoding='utf-8');start=s.index('    public int NativeIntegerStorageCapacity');end=s.index('    private bool CrossesExceptionBoundary',start);s=s[:start]+'    public int IntegerStorageCapacity { get; }\n\n'+s[end:];p.write_text(s,encoding='utf-8',newline='\n')
replace(names[1],'''    private void PrepareNativeSegments(ExecutableCallSite[] sites)
    {
        for (var index = 0; index + 2 < Instructions.Length; index++)
        {
            ref readonly var call = ref Instructions[index];''','''    private (bool AllInline, bool WritesIntegers) PrepareNativeSegments(ExecutableCallSite[] sites)
    {
        var allInline = true;
        var writesIntegers = false;
        for (var index = 0; index < Instructions.Length; index++)
        {
            ref readonly var call = ref Instructions[index];
            allInline &= IsInlineInstruction(call);
            writesIntegers |= call.OpCode == ExecutableOpCode.Binary
                && call.BinaryOperator is BinaryOperatorSyntax.Add or BinaryOperatorSyntax.Subtract
                    or BinaryOperatorSyntax.Multiply or BinaryOperatorSyntax.FloorDivide or BinaryOperatorSyntax.Modulo
                || call.OpCode == ExecutableOpCode.Augmented
                && call.AugmentedOperator is AugmentedAssignmentOperatorSyntax.Add or AugmentedAssignmentOperatorSyntax.Subtract
                    or AugmentedAssignmentOperatorSyntax.Multiply or AugmentedAssignmentOperatorSyntax.FloorDivide
                    or AugmentedAssignmentOperatorSyntax.Modulo;
            if (index + 2 >= Instructions.Length) continue;''')
replace(names[1],'''        bool IsUncapturedLocal(int slot)''','''        return (allInline, writesIntegers);

        bool IsUncapturedLocal(int slot)''')
p=root/names[-1];s=p.read_text(encoding='utf-8');assert s.count('NativeIntegerStorageCapacity')==1;p.write_text(s.replace('NativeIntegerStorageCapacity','IntegerStorageCapacity'),encoding='utf-8',newline='\n')

p=Path('PLAN.md');s=p.read_text(encoding='utf-8');anchor='   **Next source gate:**';start=s.index(anchor);end=s.index('\n\n2.',start);s=s[:start]+'''   **R360 selected: one coherent ordinary-frame primitive prototype.** Admit one
   optional primitive array together with the existing frame capacity; preserve
   final object-array/direct-span calls and existing cleanup ownership. Share
   machine operand reads, arithmetic and stable materialization with native
   prefixes. Fold storage-need/inline facts into segment preparation, deleting
   the separate fact pass and object-only chain wrapper. Do not add a backend,
   pool, hotness policy, tracing or public numeric representation.

   Materialize before calls, collection copies, snapshots, captured/mirrored
   stores and other observable publication. Keep private local values unboxed;
   retain original retirement/store checkpoints and asynchronous cleanup order.
   Preserve exact promotion, bool/float/protocol/errors, terminal refusal and
   funded aliases. Validate actual suspended I/O, captured/mirrored mutations,
   cancellation, admission before effects, retained results and budget reuse.

   **Bound:** one complete integrated prototype or supported rejection; focused
   actual .NET 11/10 plus independent Python controls, short allocation/source-
   pair checks of counter/CSV/text/JSON and short/observed controls, compilation
   separate. Decide retention and regression debt, remove displaced code, batch
   full qualification if retained. R359's helper debt remains unresolved; the
   broader representative objective stays active.''' + s[end:];p.write_text(s,encoding='utf-8',newline='\n')
(r/'prospective.json').write_text(json.dumps(dict(hypothesis='Extend proven native primitive invariant through existing frame owner to remove per-update boxes after range/protocol promotion, preserving object-array/direct-span call ABI.',eliminate='Separate compiler fact pass, duplicated native/frame primitive dispatch/materialization, object-only chain wrapper; private boxes for closed machine updates. No new evaluator/cell pool/hotness setting.',workloads='Complete inside-range100kcounter, CSVvalidation/fulfillment, capturedtext/JSON helpers and short-zero/observed controls. Compile-to-result separate. Identical source/data per compared runtime.',semantics='Captured/mirrored bindings get stable objects; private markers never escape through argument spans, tuple copies, pattern scratch or snapshots. Major arrays admitted with frame capacity before allocation; ownership lasts through pending binders/async cleanup. Exact overflow/protocol/order/cancellation/terminal refusal/funded aliases unchanged.',bound='One integrated prototype and focused actual11/10 plus independent Python controls; one short controlled source pair/allocation with explicit debt decision. Full delivery if retained; no isolated experiment completion claim.',base='98acaa5b/frozena4bfbfd8, full43605198037and completed externalB736independent; preserve exact baseline before editing.',publicationHeld=True),indent=2)+'\n',encoding='utf-8',newline='\n')
print('R360baseline saved; compiler facts consolidated into existing scan; PLANselects coherent bounded prototype.')
