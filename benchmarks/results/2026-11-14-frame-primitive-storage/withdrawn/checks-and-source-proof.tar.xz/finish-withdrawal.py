from pathlib import Path
import hashlib,json,tarfile
r=Path(__file__).parent;out=r/'withdrawn'
sha=lambda b:hashlib.sha256(b).hexdigest()
with tarfile.open(r.parent/'primitive-storage-r359/complete/candidate-sources.tar.xz')as t:
    base={m.name:t.extractfile(m).read()for m in t.getmembers()if m.isfile()}
assert len(base)==582 and all(Path(n).read_bytes()==b for n,b in base.items())
assert not Path('src/Lokad.Lython/Runtime/LythonRuntime.Executable.Integers.cs').exists()
p=Path('src/Lokad.Lython/Runtime/LythonRuntime.Executable.NativePrefix.cs');b=p.read_bytes()
old=b'                        if (TryIntegerOperation(instruction)) break;';assert b.count(old)==1
newline=b'\r\n'if b'\r\n'in b else b'\n'
guard=newline.join([b'                        if (instruction.OpCode == ExecutableOpCode.Augmented',b'                            && instruction.AugmentedOperator == AugmentedAssignmentOperatorSyntax.MatrixMultiply) return false;',b''])
p.write_bytes(b.replace(old,guard+old))
proof={n:dict(baselineSHA256=sha(b),restoredSHA256=sha(Path(n).read_bytes()),equal=Path(n).read_bytes()==b)for n,b in base.items()}
assert [n for n,v in proof.items()if not v['equal']]==[p.as_posix()]
(out/'source-proof.json').write_text(json.dumps(dict(restoredInputs=582,removedAddedInputs=['src/Lokad.Lython/Runtime/LythonRuntime.Executable.Integers.cs'],onlyIntentionalRuntimeChange=p.as_posix(),retainedTests=['MatrixOperatorsInHelpersKeepPythonErrors','FrameIntegerLifetimeTests','callback-entry-targeted terminal refusal'],sources=proof,forcedRebuildRequired=True,originalWithdrawalFailure='All582sources restored; final guard step expectedCRLFbut source archive hasLF. No rebuild/measurement before correcting newline detection. Originalwithdraw.py retained.',publicationHeld=True),indent=2)+'\n',encoding='utf-8',newline='\n')
print('582 source-byte proof complete; only matrix guard differs. No prototype storage remains.',flush=True)
