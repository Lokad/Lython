from pathlib import Path
import json,tarfile
r=Path(__file__).parent;out=Path('benchmarks/results/2026-11-14-frame-primitive-storage/withdrawn');out.mkdir()
checks=json.loads((r/'withdrawn/focused-checks.json').read_text(encoding='utf-8'));assert sum(int(v['counters']['passed'])for v in checks)==330 and all(v['exitCode']==0 for v in checks)
with tarfile.open(out/'checks-and-source-proof.tar.xz','w:xz')as t:
    for p in sorted((r/'withdrawn').iterdir()):
        if p.is_file():t.add(p,arcname=p.name)
    for n in ['withdraw.py','finish-withdrawal.py','check-withdrawal.py','record-withdrawal.py']:t.add(r/n,arcname=n)
p=Path('benchmarks/EXPERIMENTS.md');p.write_text(p.read_text(encoding='utf-8')+'''
R360 [refined B739 completion/withdrawal](results/2026-11-14-frame-primitive-storage/README.md)
at b868/A4 finishes six jobs/207.688 s/all gates. Counter remains flat despite
57.23% less allocation; CSVwarm +9.3–9.8%, observed +8.9–12.3%, JSON/short controls
remain adverse with magnitude uncertainty. Remove the whole frame representation
migration, including its shared kernel/array/branch/accounting state. All 582
production inputs restore before only the independently verified matrix-routing
guard. Forced actual 11/10 builds/330 focused restored checks pass; preserve four
public lifetime cases, two matrix cases and callback-entry refusal semantics.
No dormant prototype remains; all original/refined sources, binaries, adverse data,
profile, fixture mistakes and withdrawal newline failure survive. Full correction
delivery batches at the next coherent checkpoint. Whole-script objective stays
active; publication held.
''',encoding='utf-8',newline='\n')
p=Path('PLAN.md');old=p.read_text(encoding='utf-8');status=old.split('## Prioritized deliverables')[0]
start=status.index('| R360 uncommitted prototype, adverse initial timing |')
status=status[:start]+'''| R360 withdrawn, independent fixes retained | [Both comparisons/profile/source proofs](benchmarks/results/2026-11-14-frame-primitive-storage/README.md). Initial b9ad and refined b868 cut counter allocation 57.23% but leave elapsed flat and regress CSV/JSON/observed helpers. Remove the whole frame representation migration. All 582 baseline inputs restore except the independent two-line matrix-assignment guard. Forced actual .NET 11/10 builds/330 focused checks pass; retain six public cases and callback-entry refusal semantics. Full small-correction delivery batches at the next coherent checkpoint. |

'''
remaining='''## Prioritized deliverables

1. **Remove the native-to-ordinary cliff for closed builtin construction.**
   Selected next source/ownership design: range construction inside an otherwise
   eligible numeric helper currently promotes the entire remaining body. R356
   demonstrated this boundary before primitive native storage; R360 demonstrates
   that adding scalar state to every ordinary frame is not a useful correction.
   Assess sharing the existing range factory over evaluated argument storage,
   allowing exact integer/bool bounds to complete in the current native prefix.
   Preserve one factory and existing generic protocol path, not a new dispatcher,
   builtin framework, value representation, pool or reentry controller.

   **Eliminate:** argument repackaging and an entire avoidable invocation/frame
   transfer for closed range calls, rather than adding fast arithmetic branches
   throughout ordinary execution. Do not add a portfolio of unrelated builtin
   special cases. Inspect actual source/identity, admission, stack and protocol
   boundaries first; a concrete blocker ends this source gate without profiling.

   **Acceptance:** normal/rebound aliases, 0/1/2/3/4 argument errors, keyword/star
   behavior, negative/huge bounds, zero step, bool and custom index protocols,
   side-effect/error order, actual suspension, cancellation, terminal refusal
   before body effects, retained ranges/results and shared-budget cleanup. Calls
   requiring Python protocols keep the existing awaited path; no replay after
   admission. Borrowed spans never survive a suspension or pending user.

   **Bounded comparison:** same inside/outside-range complete counter scripts and
   short/observed helpers, with CSV/JSON control and compilation separate. Normal
   GC/tiering, existing quiet VM/workers/catalog, independent process controls;
   allocation separate from elapsed/CPU. Record a final retention/debt decision;
   no speedup forecast from allocation. Full platform/stress/installed consumers
   batch at a coherent retained milestone, including the matrix correction.

2. **Continue substantial whole-script redesigns from evidence.** Delivered final
   argument slots, native prefixes, tuple returns, shared arithmetic, compiler
   facts and direct UTF-8 output remain foundations. The latest external checkpoint
   above is complete and qualified; reuse it until a material retained milestone.
   Ordinary-frame unboxing is withdrawn, not an unresolved active measurement.
   Select complete stages, not successive call-site exceptions. Each selected
   design states its hypothesis, displaced work/storage/code, representative
   scripts, semantic/ownership criteria, controls and regression-debt decision.

   | Area / scripts | Work to eliminate; evidence and acceptance |
   | --- | --- |
   | Calls, frames, operand transport / helpers, search, invoice | An actual activation/copy beyond final slots. Closed construction is the current bounded target. Prior owning profiles do not justify replaying slower call arenas/controllers or adding a second argument representation. Preserve defaults/keywords/receiver errors, closures, exact PCs, managed stack and genuine suspension. |
   | Records / CSV/JSON aggregates and reports | A whole construction/copy stage beyond array adoption/shared keys. The earlier 6–8% bulk-record result was reconsidered; later R355 range storage was withdrawn with adverse controls. Require a simpler representation, callbacks, mutation/aliases, pre-effect admission and replacement peaks; delete the superseded constructor if retained. |
   | Text / summaries, search, reports | A real remaining conversion or build stage. Current casing/formatting already write UTF-8 directly. Inventories and profiles include useful mapping/probing; do not infer obsolete CLR conversions from method names. Preserve Unicode context/expansion, hooks/errors, cancellation and funded results. |
   | Frontend / fresh scripts | Demonstrated repeated facts or retained IR. Shared facts/lowered retention cleanup already delivered. Invoice compilation is about 0.1 ms versus 7–8 ms execution; pass count alone does not establish dominance. Preserve Python scope/nonlocals/diagnostics and admission. |

   After a material retained milestone refresh representative CPython comparisons,
   distinguishing compilation, warm execution, mediated I/O, validation, result
   cleanup and compiled/cache disposal. Small corrections do not require replaying
   an unchanged nine-job checkpoint. R359's accepted short/observed-helper and
   small JSON CPU debt remains a final 0.11 release decision, not silently settled.

3. **Keep regex development independent.** The core owns Python semantics, native
   UTF-8, original-subject windows, byte/scalar coordinates, captures/errors,
   explicit owners and the current token. Development producers and adapter-local
   bridges remain acceptable. No core backend dependency; normal optional
   non-packable adapter remains 0.4. Completed dev80 checks stay cached.
   [Latest source assessment](benchmarks/results/2026-11-14-regex-provider-capabilities/README.md)
   reaches cd8eb5c7; source assessment alone qualifies neither package nor safety,
   semantics, interruption or performance.

   Only affected final released-adapter qualification waits for separately funded
   one-match scratch/escaping results, native UTF-8 group-name enumeration/copy,
   and token-independent cursor creation with cancellable preparation. Search
   filtering cannot implement anchored/fullmatch. Cached patterns/cursors may
   not retain earlier tokens. Missing producer APIs stop no independent Lython
   implementation, contract/semantic testing or performance work.

## Measurement and delivery rules

Architectural simplification, allocation reduction and demonstrated CPU gains are
separate outcomes. Timeout, unstable unchanged control and inconclusive results
establish uncertainty. Allow bounded confirmation/refinement/measurement correction
when evidence justifies it, retaining all adverse samples and original failures.
Percentages inform decisions rather than automatically vetoing useful changes.
No blanket one-attempt, no-retiming or permanent-design-rejection rule; no open-ended
campaign. End each selected milestone with retention/debt or supported withdrawal.

Use focused Release correctness/cancellation/ownership checks during iteration.
Batch Windows/Ubuntu, actual .NET 11/10, original stress and installed Release
consumers at meaningful checkpoints. Do not repeat cached terminal runs. Force
nonincremental builds after restoration; freeze copies and verify entire images.
Persist/verify evidence before RAM teardown; preserve current images/catalogs/
toolchains and existing 254/252 MiB VM floors. Startup, pending-I/O latency,
contention, heap/RSS peaks and embedding tail latency remain unmeasured.
Publication and tagging stay postponed.

## Lasting constraints

[AGENTS.md](AGENTS.md) remains binding: fully managed and memory-safe, managed stack
admission, host mediation/original path plus contained Cwd, host cancellation,
cycles, XML depth, checked representation bounds and bounded I/O chunks. No unsafe,
Unsafe APIs, pointers/PInvoke/native probing; no fuel/quotas, hidden caps/default
allowance, regex work/time policy, tracing, weak reclamation, forced GC or abandoned
users. Borrowed allowance funds capacity/overlap, retained aliases/results/caches
and pending users. First refusal is terminal with its original structured origin;
await cleanup and never retry. Long streams use bounded host commands. Only core
is packaged; optional adapter remains non-packable.
'''
p.write_text(status+remaining,encoding='utf-8',newline='\n');print('Withdrawal evidence saved; concise active plan advances to the closed-construction boundary.',flush=True)
