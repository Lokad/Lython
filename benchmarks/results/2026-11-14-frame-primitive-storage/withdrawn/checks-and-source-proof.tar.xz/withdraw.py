from pathlib import Path
import hashlib,json,shutil,tarfile
r=Path(__file__).parent
out=r/'withdrawn';out.mkdir()
sha=lambda b:hashlib.sha256(b).hexdigest()
identity=json.loads((r/'handoff/candidate-identity.json').read_text(encoding='utf-8'))
assert all(sha(Path(n).read_bytes())==h for n,h in identity['sources'].items())
archive=Path('benchmarks/results/2026-11-14-frame-primitive-storage/handoff/sources-checks-and-observations.tar.xz')
assert archive.is_file()
with tarfile.open(archive) as t:
    assert sha(t.extractfile('candidate-core.dll').read())==identity['coreSHA256']['candidate']
with tarfile.open(r.parent/'primitive-storage-r359/complete/candidate-sources.tar.xz') as t:
    base={m.name:t.extractfile(m).read() for m in t.getmembers() if m.isfile()}
assert len(base)==582
changed=[]
for n,b in base.items():
    p=Path(n)
    if p.read_bytes()!=b:p.write_bytes(b);changed.append(n)
added=set(identity['sources'])-set(base)
assert added=={'src/Lokad.Lython/Runtime/LythonRuntime.Executable.Integers.cs'}
for n in added:Path(n).unlink()
assert all(Path(n).read_bytes()==b for n,b in base.items())
for n in ['WordBufferLoanTests','ExecutableOperandStackBoundaryTests']:
    shutil.copyfile(r/(n+'.baseline.cs'),Path('tests/Lokad.Lython.Tests')/(n+'.cs'))
# Independently confirmed baseline defect: matrix assignment must reach the
# existing Python operation rather than an arithmetic-only native mapper.
p=Path('src/Lokad.Lython/Runtime/LythonRuntime.Executable.NativePrefix.cs')
b=p.read_bytes();old=b'                        if (TryIntegerOperation(instruction)) break;'
assert b.count(old)==1
guard=b'                        if (instruction.OpCode == ExecutableOpCode.Augmented\r\n                            && instruction.AugmentedOperator == AugmentedAssignmentOperatorSyntax.MatrixMultiply) return false;\r\n'
assert b'\r\n' in b
p.write_bytes(b.replace(old,guard+old))
proof={n:dict(baselineSHA256=sha(b),restoredSHA256=sha(Path(n).read_bytes()),equal=Path(n).read_bytes()==b)for n,b in base.items()}
assert [n for n,v in proof.items()if not v['equal']]==[str(p).replace('\\','/')]
(out/'source-proof.json').write_text(json.dumps(dict(restoredInputs=582,removedAddedInputs=sorted(added),changedPrototypeInputs=len(changed),onlyIntentionalRuntimeChange=str(p).replace('\\','/'),retainedTests=['MatrixOperatorsInHelpersKeepPythonErrors','FrameIntegerLifetimeTests','callback-entry-targeted terminal refusal'],sources=proof,forcedRebuildRequired=True,publicationHeld=True),indent=2)+'\n',encoding='utf-8',newline='\n')
print('Entire prototype removed; 582 inputs restored except independent two-line matrix guard. Required forced rebuild follows.',flush=True)
