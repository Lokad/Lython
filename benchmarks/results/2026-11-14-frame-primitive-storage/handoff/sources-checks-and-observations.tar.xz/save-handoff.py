from pathlib import Path
import hashlib,json,shutil,tarfile
r=Path(__file__).parent/'handoff'
out=Path('benchmarks/results/2026-11-14-frame-primitive-storage/handoff')
out.mkdir()
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
status=json.loads((r/'b739/terminal-status.json').read_text(encoding='utf-8'))
assert status['exitCode']=='0' and status['receipt']['complete']
assert not status['remainingWorkers'] and not status['remainingFixtures'] and not status['remainingTrace']
assert sha(r/'b739/observations.tgz')==status['receipt']['archiveSHA256']
for name in ['candidate-identity.json','focused-checks.json','allocation-summary.json','python-controls.json','prospective.json']:
    shutil.copyfile(r/name,out/name)
shutil.copyfile(r/'b739/summary.json',out/'timing-summary.json')
with tarfile.open(out/'sources-checks-and-observations.tar.xz','w:xz') as t:
    for p in sorted(r.iterdir()):
        if p.is_file() and p.suffix in {'.py','.json','.jsonl','.stderr','.trx','.log','.xz','.dll'}:
            t.add(p,arcname=p.name)
    for p in sorted((r/'b739').rglob('*')):
        if p.is_file():t.add(p,arcname=p.relative_to(r).as_posix())
    t.add(Path(__file__),arcname='save-handoff.py')
print(json.dumps(dict(archived=True,archiveSHA256=sha(out/'sources-checks-and-observations.tar.xz'),rawSHA256=status['receipt']['archiveSHA256'])),flush=True)
