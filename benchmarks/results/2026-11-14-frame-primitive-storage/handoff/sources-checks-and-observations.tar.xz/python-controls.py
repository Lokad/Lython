from pathlib import Path
import hashlib,json,os,subprocess
r=Path(__file__).parent;snippets=json.loads((r.parent.parent/'primitive-storage-r359/python-control-sources.json').read_text(encoding='utf-8'));snippets+=json.loads((r.parent/'baseline-matrix-characterization.json').read_text(encoding='utf-8'))['sources']
snippets += [
'''def fold(seed):
    total=seed
    original=total
    for value in range(3):total+=value
    return original,total
assert fold(9223372036854775806)==(9223372036854775806,9223372036854775809)
print('ok')
''',
'''def fold():
    total=5000
    for value in range(3):total+=value
    snapshot=lambda saved=total:saved
    alias=total
    total+=1
    assert snapshot() is alias and alias==5003 and total==5004
fold()
print('ok')
''',
'''value=5000
value+=2
class Box:
    kept=value
assert Box.kept is value
value+=1
assert Box.kept==5002 and value==5003
print('ok')
''',
'''total=5000
total+=2
match [3]:
    case [item] if total==5002:total+=item
    case _:assert False
assert total==5005
print('ok')
''',
'''value=5000
value+=2
namespace=globals()
assert namespace['value'] is value
value+=1
assert namespace['value']==5003
print('ok')
''']
assert len(snippets)==23
(r/'python-control-sources.json').write_text(json.dumps(snippets,indent=2)+'\n',encoding='utf-8',newline='\n');identity=json.loads((r/'candidate-identity.json').read_text(encoding='utf-8'));probe=Path('tools/LythonProbe/bin/Release/net11.0/LythonProbe.dll').resolve();sha=hashlib.sha256((probe.parent/'Lokad.Lython.dll').read_bytes()).hexdigest();assert sha==identity['coreSHA256']['candidate']
env={k:v for k,v in os.environ.items()if k.lower()!='path'};env['DOTNET_ROOT']='C:/Users/JoannesVermorel/.dotnet11';env['PATH']=env['DOTNET_ROOT']+';C:/Python313;'+os.environ.get('PATH','');rows=[]
for asynchronous in [False,True]:
 done=subprocess.run([env['DOTNET_ROOT']+'/dotnet.exe',str(probe),'--batch-json','--compare-python','--python','C:/Python313/python.exe']+(['--async']if asynchronous else[]),input=json.dumps(snippets).encode(),capture_output=True,env=env,timeout=30);(r/('python-controls-'+str(asynchronous)+'.jsonl')).write_bytes(done.stdout);(r/('python-controls-'+str(asynchronous)+'.stderr')).write_bytes(done.stderr);assert done.returncode==0,(done.stdout+done.stderr).decode('utf-8');rows.append(dict(asynchronous=asynchronous,cases=23,matched=True));print(asynchronous,'23independent Python controls pass',flush=True)
(r/'python-controls.json').write_text(json.dumps(dict(complete=True,python='Isolated CPython3.13.2',coreSHA256=sha,controls=rows),indent=2)+'\n',encoding='utf-8',newline='\n')
