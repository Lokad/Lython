from pathlib import Path
import base64
import contextlib
import gzip
import hashlib
import importlib.util
import io
import json
import os
import shutil
import subprocess
import tarfile
import tempfile

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
tree = repo / '.git/agent-worktrees/json-encoding-settings-20261124'
donor = lab.with_name('typed-csv-text-20261124')
comparison = lab / 'comparison'
quiet = comparison / 'quiet'
quiet.mkdir(parents=True, exist_ok=True)
read = lambda file: json.loads(file.read_text(encoding='utf-8'))
sha = lambda data: hashlib.sha256(data).hexdigest()
digest = lambda file: sha(file.read_bytes())


def write(file, source):
    file.write_text(source, encoding='utf-8', newline='\n')


def save(file, data):
    write(file, json.dumps(data,ensure_ascii=False,indent=2)+'\n')


def from_archive(path):
    bundle, = (repo / 'benchmarks/results' / path).glob('observations.*')
    with tarfile.open(bundle) as archived:
        return json.load(archived.extractfile('representative.json'))


core='Lokad.Lython.dll'
archived='benchmarks/results/2026-11-24-json-encoding-settings/'
tracked=lambda name: subprocess.check_output(['git','show','origin/master:'+archived+name],cwd=repo)
receipt=json.loads(tracked('terminal-status.json'))['receipt']
assert receipt['complete'] and receipt['archivedAndVerifiedUnderLease']
assert sha(tracked('observations.tar.xz'))==receipt['archiveSHA256']
binary=sha(gzip.decompress(tracked('candidate-core.dll.gz')))
assert binary==json.loads(tracked('identity.json'))['imageFiles']['candidate'][core]
save(lab/'verified-replicas.json',[dict(path='json-encoding-settings-b1552-20261124/candidate/'+core,
    sha256=binary,observationSHA256=receipt['archiveSHA256'],trackedArchive=archived)])

source=donor/'comparison/quiet'
collector=(source/'collect.py').read_text(encoding='utf-8').replace('b1550-','b1553-')
collector=collector.replace("'combined-csv-cpython-b1549-20261124'/'candidate'","'typed-csv-text-b1550-20261124'/'candidate'")
compile(collector,'collect.py','exec')
write(quiet/'collect.py',collector)
(quiet/'run.sh').write_bytes((source/'run.sh').read_bytes())
assert b'\r' not in (quiet/'run.sh').read_bytes()
payload=quiet/'payload.tar.gz'
with tarfile.open(payload,'w:gz') as archive:
    for name in ('identity.json','representative.json','jobs.json'):
        archive.add(comparison/name,arcname=name)
    for name in ('collect.py','run.sh'):
        archive.add(quiet/name,arcname=name)
    archive.add(lab/'candidate'/core,arcname='candidate-core.dll')
save(quiet/'upload.json',dict(root='json-encoding-flags-b1553-20261124',reference='typed-csv-text-b1550-20261124',
    payloadSHA256=digest(payload),payloadBytes=payload.stat().st_size))
launch=(donor/'quiet.py').read_text(encoding='utf-8').replace('b1550-typed-csv-text','b1553-json-encoding-flags').replace('b1550-','b1553-')
compile(launch,'quiet.py','exec')
write(lab/'quiet.py',launch)
(lab/'summarize.py').write_bytes((donor/'summarize.py').read_bytes())
