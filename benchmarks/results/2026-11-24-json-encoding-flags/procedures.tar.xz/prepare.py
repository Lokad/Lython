from pathlib import Path
import base64
import contextlib
import gzip
import hashlib
import importlib.util
import io
import json
import os
import shutil
import subprocess
import tarfile
import tempfile

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
tree = repo / '.git/agent-worktrees/json-encoding-settings-20261124'
donor = lab.with_name('typed-csv-text-20261124')
comparison = lab / 'comparison'
quiet = comparison / 'quiet'
quiet.mkdir(parents=True, exist_ok=True)
read = lambda file: json.loads(file.read_text(encoding='utf-8'))
sha = lambda data: hashlib.sha256(data).hexdigest()
digest = lambda file: sha(file.read_bytes())


def write(file, source):
    file.write_text(source, encoding='utf-8', newline='\n')


def save(file, data):
    write(file, json.dumps(data,ensure_ascii=False,indent=2)+'\n')


def from_archive(path):
    bundle, = (repo / 'benchmarks/results' / path).glob('observations.*')
    with tarfile.open(bundle) as archived:
        return json.load(archived.extractfile('representative.json'))


candidate = subprocess.check_output(['git','rev-parse','HEAD'],cwd=tree).decode().strip()
assert candidate.startswith('eabbf02ed')
metadata = read(donor/'external/identity.json')
reference = metadata['candidate']
assert reference.startswith('b3c447420')
assert set(subprocess.check_output(['git','diff','--name-only',reference,candidate,'--','src'],cwd=tree).decode().splitlines()) == {
    'src/Lokad.Lython/Runtime/LythonRuntime.Json.Encoder.cs',
    'src/Lokad.Lython/Runtime/LythonRuntime.Json.Options.cs',
    'src/Lokad.Lython/Runtime/LythonRuntime.Json.Serialize.cs',
    'src/Lokad.Lython/Runtime/LythonRuntime.JsonModule.cs',
}
catalog=from_archive('2026-11-23-integrated-text-cpython')
expanded=next(item for item in catalog['cases'] if item['id']=='scripts.json-lines-shipment.expanded-options.large')
config=next(item for item in catalog['cases'] if item['id']=='scripts.config-edit.small')
positional=next(item for item in from_archive('2026-11-18-native-json-encoding-options')['cases'] if item['id']=='calls.positional.large')
default=dict(expanded)
default['id']='scripts.json-lines-shipment.default-options.large'
default['source']=expanded['source'].replace('options = {"ensure_ascii": False, "separators": (",", ":")}\n','')
default['source']=default['source'].replace('encode(record, **options)','encode(record)')
assert 'encode(record)' in default['source'] and 'options =' not in default['source']
fixture=json.loads(expanded['fixtureJson'])
assert list(fixture['inputFiles'])==['records.json'] and list(fixture['outputFiles'])==['shipments.jsonl']
with tempfile.TemporaryDirectory(prefix='lython-json-golden-') as temp:
    folder=Path(temp)
    (folder/'records.json').write_bytes(base64.b64decode(fixture['inputFiles']['records.json']))
    stdout=io.StringIO()
    with contextlib.chdir(folder),contextlib.redirect_stdout(stdout):
        exec(compile(default['source'],'default_json.py','exec'),{'__name__':'__main__'})
    result=(folder/'shipments.jsonl').read_bytes()
assert stdout.getvalue()==expanded['expectedOutput']
fixture['outputFiles']['shipments.jsonl']=base64.b64encode(result).decode('ascii')
default['fixtureJson']=json.dumps(fixture,ensure_ascii=False,separators=(',',':'))
default['fixtureSha256']=sha(default['fixtureJson'].encode('utf-8'))
default['sourceUtf8Bytes']=len(default['source'].encode('utf-8'))
default['sourceSha256']=sha(default['source'].encode('utf-8'))
protocol=repo/'benchmarks/cpython-worker.py'
provider=importlib.util.spec_from_file_location('comparison_protocol',protocol)
commands=importlib.util.module_from_spec(provider)
provider.loader.exec_module(commands)
default['expectedFilesSha256']=commands.file_digest({'shipments.jsonl':result})
catalog['cases']=[expanded,default,config,positional]
save(comparison/'representative.json',catalog)
save(comparison/'jobs.json',{'warm':[[case['id'],'warm'] for case in catalog['cases']]})

runtime=Path.home()/'.dotnet11'
dotnet=runtime/'dotnet.exe'
env=dict(os.environ,DOTNET_ROOT=str(runtime),DOTNET_ROOT_X64=str(runtime))
assert digest(protocol)==metadata['cpythonWorkerSHA256']
files=metadata['imageFiles']['candidate']
assert len(files)==32 and all(digest(donor/'candidate'/name)==expected for name,expected in files.items())
core='Lokad.Lython.dll'
images={}
helpers={}
for role in ('reference','candidate'):
    image=lab/role
    image.mkdir(exist_ok=True)
    for name,expected in files.items():
        path=lab/'frozen/bin/Lokad.Lython/release_net11.0'/core if role=='candidate' and name==core else donor/'candidate'/name
        shutil.copyfile(path,image/name)
    for suffix in ('.dll','.deps.json','.runtimeconfig.json'):
        helper='ValidatedAllocation'+suffix
        shutil.copyfile(donor/'candidate'/helper,image/helper)
        helpers[helper]=digest(donor/'candidate'/helper)
    observed={name:digest(image/name) for name in files}
    result=comparison/(role+'-verify.json')
    subprocess.run([dotnet,image/'Lokad.Lython.Benchmarks.dll','--compare','verify','--catalog',
        comparison/'representative.json','--dotnet',dotnet,'--python','C:/Python313/python.exe',
        '--python-worker',protocol,'--out',result],env=env,check=True,timeout=90)
    receipt=read(result)
    assert receipt['state']=='Completed' and receipt['caseCount']==4 and receipt['launched']['library']['sha256']==observed[core]
    assert all(digest(image/name)==expected for name,expected in observed.items())
    assert all(digest(image/name)==expected for name,expected in helpers.items())
    images[role]=observed
assert files==images['reference']
assert [name for name in files if images['reference'][name]!=images['candidate'][name]]==[core]
save(comparison/'identity.json',dict(sourceRevision=reference,candidate=candidate,purpose='B1553 share canonical JSON flags and retain the compact default iterator',
    imageFiles=images,helperFiles=helpers,cpythonWorkerSHA256=metadata['cpythonWorkerSHA256'],
    expectedCPythonSHA256=metadata['expectedCPythonSHA256'],
    catalogs={name:dict(sha256=digest(comparison/name)) for name in ('representative.json','jobs.json')},
    coreSHA256={label:images[role][core] for role in images for label in (role,role+'-control')}))
(lab/'allocations.py').write_bytes((donor/'allocations.py').read_bytes())

