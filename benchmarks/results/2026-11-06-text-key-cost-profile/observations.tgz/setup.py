from pathlib import Path
import hashlib,json,os,shutil
root=Path('/home/lokad/lython-bench-checks/operand-cost-b324-20261106')
base=Path('/home/lokad/lython-bench-checks/call-checkpoint-b320-20261106/candidate')
folder=root/'candidate';folder.mkdir()
for f in base.iterdir():
 if f.name=='Lokad.Lython.pdb':continue
 if f.name in ('Lokad.Lython.Benchmarks.dll','Lokad.Lython.Benchmarks.deps.json','Lokad.Lython.Benchmarks.runtimeconfig.json'):
  assert not f.is_symlink();os.link(f,folder/f.name)
 else:
  source=root/'core/Lokad.Lython.dll' if f.name=='Lokad.Lython.dll' else f
  (folder/f.name).symlink_to(source.resolve(),target_is_directory=source.is_dir())
for name,sha in json.loads((root/'identity.json').read_text())['files'].items():
 assert hashlib.sha256((folder/name).read_bytes()).hexdigest()==sha
assert shutil.disk_usage(root).free>32*1024*1024
print(json.dumps(dict(freeBytes=shutil.disk_usage(root).free)))
