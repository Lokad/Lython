from pathlib import Path
import hashlib
import json
import os
import shutil
import subprocess

lab=Path(__file__).resolve().parent
root=lab.parents[3]
identity=json.loads((lab/'comparison/identity.json').read_text(encoding='utf-8'))
source=lab.parent/'closed-default-evaluation-20261124/frozen-probe'
assert (source/'LythonProbe.dll').is_file()
sha=lambda path:hashlib.sha256(path.read_bytes()).hexdigest()
expected={p.name:sha(p) for p in source.iterdir() if p.is_file()}
variants=(
    ('seed + 9223372036854775807','seed % -7','seed * seed','seed % 11 == 0'),
    ('seed % 7','seed * 9223372036854775807','seed // -3','seed % 3 != 0'),
    ('7 // seed','seed % -5','-3 * seed','seed >= -11'),
    ('seed + 1','seed - 2','seed + 5','seed < 8'),
    ('seed * seed','seed % 5 + 1','seed - seed','seed // 2 > 1'),
    ('seed - 5 * seed','seed + 9223372036854775808','seed // 7','seed % -3 <= 2'),
)
cases=[f'''def make(seed):
    def left(value={positional}, *, factor={factor}, active={active}):
        return value, factor, active
    right = lambda value={other}, *, scale=2: (value, scale)
    return left, right
for seed in (0, 1, -11, 9223372036854775807, -9223372036854775808, 1 << 80):
    try:
        first, second = make(seed)
        value, factor, active = first()
        print(value, factor, active, value is first.__defaults__[0], second())
    except ZeroDivisionError:
        print('division by zero')
''' for positional,factor,other,active in variants]
cases.append('''events=[]
class Seed:
    def __mod__(self, value):
        events.append(value)
        return 4
    def __add__(self, value):
        events.append(value)
        return 7

def make(seed):
    def left(value=seed % 7):
        return value
    right=lambda value=(seed + 1) % 11: value
    return left,right
first,second=make(Seed())
print(first(),second(),events)
''')
request=json.dumps(cases)
(lab/'boundary-oracle-input.json').write_text(request+'\n',encoding='utf-8',newline='\n')
sdk=Path.home()/'.dotnet11'
env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk),PATH=str(sdk)+os.pathsep+os.environ['PATH'])
images={}
for role,image in identity['imageFiles'].items():
    probe=lab/('probe-'+role)
    probe.mkdir(exist_ok=True)
    for name,wanted in expected.items():
        shutil.copyfile(lab/role/name if name=='Lokad.Lython.dll' else source/name,probe/name)
        assert sha(probe/name)==image[name] if name=='Lokad.Lython.dll' else sha(probe/name)==wanted
    hashes={p.name:sha(p) for p in probe.iterdir()}
    assert hashes==expected|{'Lokad.Lython.dll':image['Lokad.Lython.dll']}
    images[role]=hashes
    run=subprocess.run([sdk/'dotnet.exe',probe/'LythonProbe.dll','--batch-json','--compare-python','--python','C:/Python313/python.exe'],
        input=request,env=env,timeout=100,capture_output=True,text=True,encoding='utf-8')
    (lab/(role+'-boundary-oracle.jsonl')).write_text(run.stdout,encoding='utf-8',newline='\n')
    assert run.returncode==0,(run.stdout,run.stderr)
    outputs=[json.loads(line) for line in run.stdout.splitlines()]
    assert len(outputs)==len(cases) and all(item['Compared'] and item['Matches'] and item['Lython']['Success'] for item in outputs)
    print(role,len(outputs),'programs match CPython')
(lab/'boundary-oracle-images.json').write_text(json.dumps(images,indent=2)+'\n',encoding='utf-8',newline='\n')
