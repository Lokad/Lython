#!/bin/bash
set -euo pipefail
cd /mnt/d/code/Lython/.git/agent-worktrees/closed-factory-pairs-20261124
export DOTNET_ROOT="$HOME/.dotnet"
export PATH="$DOTNET_ROOT:$PATH"
lab=/mnt/d/code/Lython/.git/agent-notes/review-20261031/closed-factory-pairs-refined-20261124
white='Category!=Stress&(FullyQualifiedName~ExecutableDefinitionPair|FullyQualifiedName~AnnotatedHelper|FullyQualifiedName~ExecutableCall|FullyQualifiedName~ExecutableStackAdmission|FullyQualifiedName~FunctionDefaultConstruction|FullyQualifiedName~ManagedStackGuard)'
public='Category!=Stress&(FullyQualifiedName~NativeDefinitionPair|FullyQualifiedName~AnnotatedHelper|FullyQualifiedName~PreparedFunctionDefaults|FullyQualifiedName~FunctionDefaultMetadata|FullyQualifiedName~NativeTupleReturn|FullyQualifiedName~SharedExecutionBudget|FullyQualifiedName~CooperativeCancellation|FullyQualifiedName~NativeIntegerChain)'
dotnet test tests/Lokad.Lython.Tests -c Release -f net11.0 --filter "$white" --artifacts-path "$lab/ubuntu" --nologo > "$lab/ubuntu-white.log" 2>&1 || { tail -42 "$lab/ubuntu-white.log"; exit 1; }
dotnet test tests/Lokad.Lython.PublicApi.Tests -c Release -f net11.0 --filter "$public" --artifacts-path "$lab/ubuntu" --nologo > "$lab/ubuntu-public.log" 2>&1 || { tail -42 "$lab/ubuntu-public.log"; exit 1; }
awk '/Passed!/{count++;print} END{exit count!=2}' "$lab/ubuntu-white.log" "$lab/ubuntu-public.log"
