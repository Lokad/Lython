from pathlib import Path
import gzip
import hashlib
import json
import shutil
import subprocess
import tarfile

lab=Path(__file__).resolve().parent
root=lab.parents[3]
comparison=lab/'comparison'
quiet=comparison/'quiet'
read=lambda path:json.loads(path.read_text(encoding='utf-8-sig'))
sha=lambda payload:hashlib.sha256(payload).hexdigest()
meta=read(comparison/'identity.json')
terminal=read(quiet/'terminal-status.json')
summary=read(quiet/'summary.json')
receipt=terminal['receipt']
assert not terminal['live'] and not terminal['fixtures'] and terminal['exitCode']=='0'
assert all(receipt[k] for k in ('complete','allWorkersJoined','guestFixturesRemoved','quietBeforeAndAfter','archivedAndVerifiedUnderLease'))
assert sha((quiet/'observations.tar.xz').read_bytes())==receipt['archiveSHA256']
assert summary['timedBatches']==196 and len(summary['rows'])==7
for role,files in meta['imageFiles'].items():
    result=read(comparison/(role+'-verify.json'))
    assert result['state']=='Completed' and result['caseCount']==6
    expected=files|meta['helperFiles']
    assert len(files)==32 and {p.name:sha(p.read_bytes()) for p in (lab/role).iterdir()}==expected
    oracle=[json.loads(line) for line in (lab/(role+'-boundary-oracle.jsonl')).read_text(encoding='utf-8').splitlines()]
    assert len(oracle)==7 and all(item['Matches'] and item['Compared'] and item['Lython']['Success'] for item in oracle)
route=next(row for row in read(lab/'route-counts.json')['rows'] if row['case']=='scripts.rule-default-closures')
assert route['routes']=={'direct-pair make_rules':8192}
for file,count in [('final-windows-white.log',57),('final-windows-public.log',152),('ubuntu-white.log',57),('ubuntu-public.log',152),
                   ('cancellation-windows.log',6),('cancellation-ubuntu.log',6)]:
    assert f'Passed: {count:5d}' in (lab/file).read_text(encoding='utf-8-sig')
out=root/'benchmarks/results/2026-11-24-closed-factory-pairs'
out.mkdir(exist_ok=True)
for role in ('reference','candidate'):
    core=(lab/role/'Lokad.Lython.dll').read_bytes()
    assert sha(core)==meta['coreSHA256'][role]
    path=out/(role+'-core.dll.gz')
    path.write_bytes(gzip.compress(core,mtime=0))
    assert sha(gzip.decompress(path.read_bytes()))==meta['coreSHA256'][role]
for source,name in {comparison/'identity.json':'identity.json',quiet/'terminal-status.json':'terminal-status.json',quiet/'summary.json':'summary.json',
                    quiet/'observations.tar.xz':'observations.tar.xz',lab/'allocation-summary-six.json':'allocation-summary.json',
                    lab/'route-counts.json':'route-counts.json',lab/'jit-summary.json':'jit-summary.json'}.items():
    shutil.copyfile(source,out/name)
(lab/'measured.patch').write_bytes(subprocess.check_output(['git','diff','--binary',meta['sourceRevision'],meta['candidate'],'--','src','tests'],cwd=root))
procedures=['prepare.py','stage.py','quiet.py','summarize.py','archive.py','allocations.py','verified-replicas.json','test-ubuntu.sh',
    'reference-allocation-six.json','candidate-allocation-six.json','comparison/reference-verify.json','comparison/candidate-verify.json',
    'comparison/quiet/launch.log','measured.patch','routes.py','route-diagnostic.patch','initial-route-stderr.log',
    'oracle.py','oracle.json','boundary-oracle.py','boundary-oracle-input.json','boundary-oracle-images.json',
    'reference-boundary-oracle.jsonl','candidate-boundary-oracle.jsonl','inspect-jit.py','reference-native.asm','candidate-native.asm','admission-cancellation-tests.patch',
    'final-windows-white.log','final-windows-public.log','ubuntu-white.log','ubuntu-public.log','cancellation-windows.log','cancellation-ubuntu.log']
with tarfile.open(out/'procedures.tar.xz','w:xz',preset=4) as tar:
    for name in procedures:tar.add(lab/name,arcname=name)
with tarfile.open(out/'procedures.tar.xz') as tar:
    assert all(sha(tar.extractfile(name).read())==sha((lab/name).read_bytes()) for name in procedures)
print('Archived B1594, 196 checked batches, exact source and route evidence')
