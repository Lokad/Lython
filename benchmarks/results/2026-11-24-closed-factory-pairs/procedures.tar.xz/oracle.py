import json
from pathlib import Path
import re
import subprocess
import textwrap

lab=Path(__file__).resolve().parent
root=lab.parents[3]
path=root/'.git/agent-worktrees/closed-factory-pairs-20261124/tests/Lokad.Lython.PublicApi.Tests/NativeDefinitionPairTests.cs'
source=path.read_text(encoding='utf-8')
fixtures=[textwrap.dedent(row).strip()+'\n' for row in re.findall(r'const string source = """\n(.*?)""";',source,re.S)]
expected=['33 10 False False\n22 33 33 True\n(6,) (0,)\n','old first old second\n2 5\n']
assert len(fixtures)==len(expected)
results=[]
for snippet,wanted in zip(fixtures,expected,strict=True):
    run=subprocess.run(['C:/Python313/python.exe','-I','-X','utf8','-'],input=snippet,encoding='utf-8',capture_output=True,timeout=15,check=True)
    assert not run.stderr and run.stdout==wanted,(run.returncode,run.stdout,run.stderr)
    results.append(dict(source=snippet,output=run.stdout))
(lab/'oracle.json').write_text(json.dumps(dict(results=results),indent=2)+'\n',encoding='utf-8',newline='\n')
print('Both new semantic fixtures match CPython 3.13.2')
