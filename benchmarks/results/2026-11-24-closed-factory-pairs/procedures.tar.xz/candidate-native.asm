; Assembly listing for method Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteNativeCall(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Frontend.ExecutableCallSite,int,System.Object,byref):bool (FullOpts)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; FullOpts code
; optimized code
; rbp based frame
; fully interruptible
; No PGO data
; 0 inlinees with PGO data; 107 single block inlinees; 34 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       push     r15
       push     r14
       push     r13
       push     r12
       push     rdi
       push     rsi
       push     rbx
       sub      rsp, 328
       lea      rbp, [rsp+0x180]
       xor      eax, eax
       mov      qword ptr [rbp-0x118], rax
       vxorps   xmm4, xmm4, xmm4
       vmovdqa  xmmword ptr [rbp-0x110], xmm4
       mov      rax, -192
 
G_M000_IG140:                ;; offset=0x003A
       vmovdqa  xmmword ptr [rbp+rax-0x40], xmm4
       vmovdqa  xmmword ptr [rbp+rax-0x30], xmm4
       vmovdqa  xmmword ptr [rbp+rax-0x20], xmm4
       add      rax, 48
       jne      SHORT G_M000_IG140
       mov      qword ptr [rbp-0x40], rax
       mov      bword ptr [rbp+0x10], rcx
       mov      gword ptr [rbp+0x18], rdx
       mov      gword ptr [rbp+0x28], r9
       mov      rsi, r8
       mov      rbx, r9
       mov      eax, dword ptr [rbp+0x30]
       mov      rdi, gword ptr [rbp+0x38]
       mov      r14, bword ptr [rbp+0x40]
 
G_M000_IG02:                ;; offset=0x0073
       xor      r8, r8
       mov      gword ptr [r14], r8
       test     rdi, rdi
       je       SHORT G_M000_IG05
 
G_M000_IG03:                ;; offset=0x007E
       mov      r8, 0x7FF9D7745CC0
       cmp      qword ptr [rdi], r8
       jne      SHORT G_M000_IG05
 
G_M000_IG04:                ;; offset=0x008D
       mov      gword ptr [rbp-0x120], rdi
       jmp      SHORT G_M000_IG06
 
G_M000_IG05:                ;; offset=0x0096
       xor      r8, r8
       mov      gword ptr [rbp-0x120], r8
 
G_M000_IG06:                ;; offset=0x00A0
       cmp      byte  ptr [rbx+0x30], 0
       je       SHORT G_M000_IG09
 
G_M000_IG07:                ;; offset=0x00A6
       mov      r8, gword ptr [rcx+0x20]
       cmp      eax, dword ptr [r8+0x08]
       jae      G_M000_IG126
       mov      r10d, eax
       shl      r10, 4
       lea      rcx, bword ptr [r8+r10+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Object():System.Object:this]
       mov      rdx, rax
       mov      rcx, 0x7FF9D77477E8
       call     [Lokad.Lython.Internal.NullabilityExtensions:RequireNotNull[System.__Canon](System.__Canon):System.__Canon]
       test     rax, rax
       je       SHORT G_M000_IG10
 
G_M000_IG08:                ;; offset=0x00DE
       mov      rcx, 0x7FF9D7649028
       cmp      qword ptr [rax], rcx
       jne      SHORT G_M000_IG10
 
G_M000_IG09:                ;; offset=0x00ED
       mov      rcx, bword ptr [rbp+0x10]
       mov      eax, dword ptr [rbp+0x30]
       xor      r15, r15
       jmp      SHORT G_M000_IG11
 
G_M000_IG10:                ;; offset=0x00F9
       mov      rcx, bword ptr [rbp+0x10]
       mov      r8, gword ptr [rcx+0x20]
       mov      eax, dword ptr [rbp+0x30]
       cmp      eax, dword ptr [r8+0x08]
       jae      G_M000_IG126
       mov      r10d, eax
       shl      r10, 4
       lea      rcx, bword ptr [r8+r10+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Object():System.Object:this]
       mov      rdx, rax
       mov      rcx, 0x7FF9D77477E8
       call     [Lokad.Lython.Internal.NullabilityExtensions:RequireNotNull[System.__Canon](System.__Canon):System.__Canon]
       mov      r15, rax
 
G_M000_IG11:                ;; offset=0x0136
       test     rdi, rdi
       je       SHORT G_M000_IG16
 
G_M000_IG12:                ;; offset=0x013B
       mov      r8, 0x7FF9D7774E98
       cmp      qword ptr [rdi], r8
       jne      SHORT G_M000_IG16
 
G_M000_IG13:                ;; offset=0x014A
       mov      r8, gword ptr [rdi+0x10]
       test     r8, r8
       je       SHORT G_M000_IG16
 
G_M000_IG14:                ;; offset=0x0153
       mov      rdx, 0x7FF9D7745CC0
       cmp      qword ptr [r8], rdx
       jne      SHORT G_M000_IG16
 
G_M000_IG15:                ;; offset=0x0162
       mov      gword ptr [rbp-0x120], r8
       mov      r15, gword ptr [rdi+0x08]
 
G_M000_IG16:                ;; offset=0x016D
       cmp      gword ptr [rbp-0x120], 0
       je       SHORT G_M000_IG18
 
G_M000_IG17:                ;; offset=0x0177
       test     rsi, rsi
       jne      G_M000_IG82
 
G_M000_IG18:                ;; offset=0x0180
       cmp      byte  ptr [rbx+0x30], 0
       je       SHORT G_M000_IG19
       cmp      byte  ptr [rbx+0x34], 0
       jne      G_M000_IG32
 
G_M000_IG19:                ;; offset=0x0190
       mov      rcx, bword ptr [rbp+0x10]
       mov      r8, gword ptr [rcx+0x20]
       test     r8, r8
       je       SHORT G_M000_IG20
       lea      rdx, bword ptr [r8+0x10]
       mov      r8d, dword ptr [r8+0x08]
       jmp      SHORT G_M000_IG21
 
G_M000_IG20:                ;; offset=0x01A7
       xor      rdx, rdx
       xor      r8d, r8d
 
G_M000_IG21:                ;; offset=0x01AC
       mov      bword ptr [rbp-0xF8], rdx
       mov      dword ptr [rbp-0xF0], r8d
       mov      rdx, gword ptr [rbp+0x18]
       mov      gword ptr [rsp+0x20], rdx
       test     rsi, rsi
       setne    r8b
       movzx    r8, r8b
       mov      dword ptr [rsp+0x28], r8d
       lea      r8, [rbp-0xB8]
       mov      qword ptr [rsp+0x30], r8
       lea      r8, [rbp-0xF8]
       mov      rdx, rdi
       mov      rcx, rbx
       mov      r9d, dword ptr [rbp+0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryInvokeBuiltinFromSlots(Lokad.Lython.Frontend.ExecutableCallSite,System.Object,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,bool,byref):bool]
       test     eax, eax
       je       G_M000_IG30
       mov      rdx, gword ptr [rbp-0xB8]
       mov      rcx, 0x7FF9D74D6808
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       mov      rdi, rax
       test     rdi, rdi
       jne      G_M000_IG28
       mov      rcx, bword ptr [rbp+0x10]
       mov      r9, gword ptr [rcx]
       mov      r9, gword ptr [r9+0x98]
       mov      edx, dword ptr [rcx+0x10]
       cmp      edx, dword ptr [r9+0x08]
       jae      G_M000_IG31
       shl      rdx, 5
       lea      r8, bword ptr [r9+rdx+0x10]
       mov      rdi, gword ptr [rbp-0xB8]
       mov      r14, qword ptr [rbp-0xB0]
       mov      ebx, dword ptr [r8+0x18]
       test     ebx, ebx
       jge      SHORT G_M000_IG22
       mov      gword ptr [rbp-0x108], rdi
       mov      qword ptr [rbp-0x100], r14
       lea      r9, [rbp-0x108]
       mov      rdx, rsi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CompleteResultConsumer(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot)]
       jmp      SHORT G_M000_IG29
 
G_M000_IG22:                ;; offset=0x027A
       lea      rsi, bword ptr [rcx+0x20]
       mov      edx, dword ptr [r8+0x1C]
       cmp      edx, 51
       ja       SHORT G_M000_IG25
 
G_M000_IG23:                ;; offset=0x0287
       mov      rax, 0x7FFFFFFFFF9FF
       bt       rax, rdx
       jb       SHORT G_M000_IG25
 
G_M000_IG24:                ;; offset=0x0297
       mov      r15d, ebx
       jmp      SHORT G_M000_IG26
 
G_M000_IG25:                ;; offset=0x029C
       mov      r15d, dword ptr [r8+0x14]
 
G_M000_IG26:                ;; offset=0x02A0
       cmp      ebx, dword ptr [rsi+0x40]
       jge      SHORT G_M000_IG27
       mov      rcx, rsi
       mov      edx, ebx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
 
G_M000_IG27:                ;; offset=0x02B0
       mov      rdx, gword ptr [rsi]
       cmp      r15d, dword ptr [rdx+0x08]
       jae      SHORT G_M000_IG31
       mov      eax, r15d
       shl      rax, 4
       lea      r15, bword ptr [rdx+rax+0x10]
       mov      rcx, r15
       mov      rdx, rdi
       call     CORINFO_HELP_ASSIGN_REF
       mov      qword ptr [r15+0x08], r14
       mov      dword ptr [rsi+0x40], ebx
       jmp      SHORT G_M000_IG29
 
G_M000_IG28:                ;; offset=0x02D9
       mov      rcx, bword ptr [rbp+0x10]
       add      rcx, 32
       mov      edx, dword ptr [rbp+0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
       mov      rcx, r14
       mov      rdx, rdi
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
 
G_M000_IG29:                ;; offset=0x02F5
       mov      eax, 1
       jmp      G_M000_IG123
 
G_M000_IG30:                ;; offset=0x02FF
       xor      eax, eax
       jmp      G_M000_IG123
 
G_M000_IG31:                ;; offset=0x0306
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG32:                ;; offset=0x030C
       test     rdi, rdi
       je       G_M000_IG124
 
G_M000_IG33:                ;; offset=0x0315
       mov      rcx, 0x7FF9D7775198
       cmp      qword ptr [rdi], rcx
       jne      G_M000_IG124
 
G_M000_IG34:                ;; offset=0x0328
       mov      r9, gword ptr [rbx+0x20]
       test     r9, r9
       je       SHORT G_M000_IG37
 
G_M000_IG35:                ;; offset=0x0331
       mov      rcx, 0x7FF9D77754A0
       cmp      qword ptr [r9], rcx
       jne      SHORT G_M000_IG37
 
G_M000_IG36:                ;; offset=0x0340
       mov      gword ptr [rsp+0x20], rbx
       mov      eax, dword ptr [rbp+0x30]
       mov      dword ptr [rsp+0x28], eax
       mov      gword ptr [rsp+0x30], rdi
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rbp+0x18]
       mov      r8, rsi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteTrimmedSplit(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Frontend.ExecutableTrimmedSplit,Lokad.Lython.Frontend.ExecutableCallSite,int,System.Object):bool]
       test     eax, eax
       jne      G_M000_IG76
 
G_M000_IG37:                ;; offset=0x036A
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rcx]
       mov      r8, gword ptr [rcx+0x20]
       test     r8, r8
       je       SHORT G_M000_IG38
       lea      r9, bword ptr [r8+0x10]
       mov      r8d, dword ptr [r8+0x08]
       jmp      SHORT G_M000_IG39
 
G_M000_IG38:                ;; offset=0x0384
       xor      r9, r9
       xor      r8d, r8d
 
G_M000_IG39:                ;; offset=0x038A
       lea      rax, bword ptr [rcx+0x10]
       mov      r10, rsi
       test     r10, r10
       cmove    r10, gword ptr [rbp+0x18]
       mov      bword ptr [rbp-0x118], r9
       mov      dword ptr [rbp-0x110], r8d
       mov      gword ptr [rsp+0x20], rbx
       mov      r11d, dword ptr [rbp+0x30]
       mov      dword ptr [rsp+0x28], r11d
       mov      gword ptr [rsp+0x30], r10
       lea      r8, [rbp-0xA0]
       mov      qword ptr [rsp+0x38], r8
       lea      r8, [rbp-0x118]
       mov      rcx, rdi
       mov      r9, rax
       call     [Lokad.Lython.Runtime.LythonRuntime:TryConsumePrivateStringResult(Lokad.Lython.Runtime.LythonRuntime+ReceiverMethod,Lokad.Lython.Frontend.ExecutableCodeObject,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,Lokad.Lython.Frontend.ExecutableCallSite,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       test     eax, eax
       jne      G_M000_IG69
       mov      rcx, bword ptr [rbp+0x10]
       mov      rax, gword ptr [rcx+0x20]
       mov      r11d, dword ptr [rbp+0x30]
       cmp      r11d, dword ptr [rax+0x08]
       jae      G_M000_IG81
       mov      edx, r11d
       shl      rdx, 4
       lea      rcx, bword ptr [rax+rdx+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Object():System.Object:this]
       mov      rdx, rax
       mov      rcx, 0x7FF9D77477E8
       call     [Lokad.Lython.Internal.NullabilityExtensions:RequireNotNull[System.__Canon](System.__Canon):System.__Canon]
       mov      r14, rax
       mov      rcx, bword ptr [rbp+0x10]
       lea      rdx, bword ptr [rcx+0x20]
       cmp      byte  ptr [rbx+0x30], 0
       setne    al
       movzx    rax, al
       mov      r11d, dword ptr [rbp+0x30]
       lea      r15d, [r11+rax+0x01]
       mov      r13d, dword ptr [rbx+0x28]
       mov      rdx, gword ptr [rdx]
       test     rdx, rdx
       je       G_M000_IG77
       mov      eax, r15d
       mov      r8d, r13d
       add      rax, r8
       mov      r8d, dword ptr [rdx+0x08]
       cmp      rax, r8
       ja       G_M000_IG77
       mov      rax, rdx
       xor      r12, r12
       xor      r8d, r8d
       test     rax, rax
 
G_M000_IG40:                ;; offset=0x046C
       je       SHORT G_M000_IG43
       mov      rdx, qword ptr [rax]
       test     dword ptr [rdx], 0xFFFFFFFF80000000
       jne      SHORT G_M000_IG41
       lea      rdx, [rbp-0xE8]
       mov      rcx, rax
       mov      rax, qword ptr [rax]
       mov      rax, qword ptr [rax+0x40]
       call     [rax+0x28]System.Buffers.MemoryManager`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:GetSpan():System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:this
       mov      r8d, dword ptr [rbp-0xE0]
       mov      r12, bword ptr [rbp-0xE8]
       mov      eax, r8d
       jmp      SHORT G_M000_IG42
 
G_M000_IG41:                ;; offset=0x04A0
       lea      r12, bword ptr [rax+0x10]
       mov      eax, dword ptr [rax+0x08]
 
G_M000_IG42:                ;; offset=0x04A7
       and      r15d, 0x7FFFFFFF
       mov      edx, r15d
       mov      r8d, r13d
       add      r8, rdx
       mov      eax, eax
       cmp      r8, rax
       ja       G_M000_IG77
       shl      rdx, 4
       add      r12, rdx
       mov      dword ptr [rbp-0xD4], r13d
       mov      r8d, dword ptr [rbp-0xD4]
 
G_M000_IG43:                ;; offset=0x04D7
       cmp      dword ptr [rbx+0x2C], 0
       je       G_M000_IG47
       test     byte  ptr [(reloc 0x7ff9d7775860)], 1
       je       G_M000_IG78
 
G_M000_IG44:                ;; offset=0x04EE
       mov      rdx, 0x143D6801D90
       cmp      rdi, gword ptr [rdx]
       jne      SHORT G_M000_IG47
       test     r14, r14
       je       SHORT G_M000_IG47
 
G_M000_IG45:                ;; offset=0x0502
       mov      rdx, 0x7FF9D759DAA0
       cmp      qword ptr [r14], rdx
       jne      SHORT G_M000_IG47
 
G_M000_IG46:                ;; offset=0x0511
       cmp      r8d, 2
       jg       SHORT G_M000_IG47
       mov      r11d, dword ptr [rbp+0x30]
       mov      dword ptr [rsp+0x20], r11d
       mov      gword ptr [rsp+0x28], r14
       mov      bword ptr [rbp-0x118], r12
       mov      dword ptr [rbp-0xD4], r8d
       mov      dword ptr [rbp-0x110], r8d
       lea      rdx, [rbp-0x118]
       mov      qword ptr [rsp+0x30], rdx
       mov      rdx, rsi
       mov      r8, gword ptr [rbp+0x18]
       mov      r9, rbx
       mov      rcx, bword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteSplitUnpack(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Frontend.ExecutableCallSite,int,Lokad.Lython.Runtime.Text.PyString,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):bool]
       test     eax, eax
       mov      r8d, dword ptr [rbp-0xD4]
       jne      G_M000_IG76
 
G_M000_IG47:                ;; offset=0x0569
       cmp      byte  ptr [rbx+0x33], 0
       jne      SHORT G_M000_IG49
 
G_M000_IG48:                ;; offset=0x056F
       mov      dword ptr [rbp-0xD4], r8d
       jmp      G_M000_IG61
 
G_M000_IG49:                ;; offset=0x057B
       cmp      r8d, 1
       je       SHORT G_M000_IG51
       mov      dword ptr [rbp-0xD4], r8d
       cmp      r8d, 2
       jne      G_M000_IG61
 
G_M000_IG50:                ;; offset=0x0592
       mov      r8d, dword ptr [rbp-0xD4]
 
G_M000_IG51:                ;; offset=0x0599
       test     byte  ptr [(reloc 0x7ff9d7775860)], 1
       je       G_M000_IG79
 
G_M000_IG52:                ;; offset=0x05A6
       mov      rax, 0x143D6801D60
       cmp      rdi, gword ptr [rax]
       je       SHORT G_M000_IG54
 
G_M000_IG53:                ;; offset=0x05B5
       mov      dword ptr [rbp-0xD4], r8d
       jmp      G_M000_IG61
 
G_M000_IG54:                ;; offset=0x05C1
       test     r14, r14
       je       G_M000_IG60
 
G_M000_IG55:                ;; offset=0x05CA
       mov      rax, 0x7FF9D76447D8
       cmp      qword ptr [r14], rax
       jne      SHORT G_M000_IG59
 
G_M000_IG56:                ;; offset=0x05D9
       mov      dword ptr [rbp-0xD4], r8d
       test     r8d, r8d
       je       G_M000_IG81
       mov      r15, r12
       mov      rcx, r15
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Object():System.Object:this]
       mov      rdx, rax
       mov      rcx, r14
       call     [Lokad.Lython.Runtime.PyDict:CanReadKeySynchronously(System.Object):bool:this]
       test     eax, eax
       je       SHORT G_M000_IG61
       mov      rcx, r15
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Object():System.Object:this]
       mov      rdx, rax
       test     rdx, rdx
       je       SHORT G_M000_IG58
 
G_M000_IG57:                ;; offset=0x0616
       mov      rcx, 0x7FF9D759DAA0
       cmp      qword ptr [rdx], rcx
       jne      G_M000_IG80
 
G_M000_IG58:                ;; offset=0x0629
       mov      gword ptr [rsp+0x28], rdx
       mov      rdx, gword ptr [rbp+0x18]
       mov      r8, rbx
       mov      r9d, dword ptr [rbp+0x30]
       mov      gword ptr [rsp+0x20], r14
       mov      rcx, bword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteDictionaryAccumulation(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Frontend.ExecutableCallSite,int,Lokad.Lython.Runtime.PyDict,Lokad.Lython.Runtime.Text.PyString):bool]
       test     eax, eax
       je       SHORT G_M000_IG61
       jmp      G_M000_IG76
 
G_M000_IG59:                ;; offset=0x0651
       mov      dword ptr [rbp-0xD4], r8d
       jmp      SHORT G_M000_IG61
 
G_M000_IG60:                ;; offset=0x065A
       mov      dword ptr [rbp-0xD4], r8d
 
G_M000_IG61:                ;; offset=0x0661
       mov      r9, gword ptr [rbx+0x18]
       mov      rdx, rsi
       test     rdx, rdx
       cmove    rdx, gword ptr [rbp+0x18]
       mov      bword ptr [rbp-0xF8], r12
       mov      r8d, dword ptr [rbp-0xD4]
       mov      dword ptr [rbp-0xF0], r8d
       mov      gword ptr [rsp+0x20], rdx
       lea      r8, [rbp-0xA8]
       mov      qword ptr [rsp+0x28], r8
       lea      r8, [rbp-0xF8]
       mov      rdx, r14
       mov      rcx, rdi
       call     [Lokad.Lython.Runtime.LythonRuntime:TryInvokeClosedReceiver(Lokad.Lython.Runtime.LythonRuntime+ReceiverMethod,System.Object,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       test     eax, eax
       je       G_M000_IG68
       mov      rcx, bword ptr [rbp+0x10]
       mov      r9, gword ptr [rcx]
       mov      r9, gword ptr [r9+0x98]
       mov      edx, dword ptr [rcx+0x10]
       cmp      edx, dword ptr [r9+0x08]
       jae      G_M000_IG81
       shl      rdx, 5
       lea      r8, bword ptr [r9+rdx+0x10]
       mov      rbx, gword ptr [rbp-0xA8]
       mov      edi, dword ptr [r8+0x18]
       test     edi, edi
       jge      SHORT G_M000_IG62
       mov      gword ptr [rbp-0x108], rbx
       xor      r9d, r9d
       mov      qword ptr [rbp-0x100], r9
       lea      r9, [rbp-0x108]
       mov      rdx, rsi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CompleteResultConsumer(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot)]
       jmp      G_M000_IG76
 
G_M000_IG62:                ;; offset=0x070A
       lea      rsi, bword ptr [rcx+0x20]
       mov      edx, dword ptr [r8+0x1C]
       cmp      edx, 51
       ja       SHORT G_M000_IG65
 
G_M000_IG63:                ;; offset=0x0717
       mov      rax, 0x7FFFFFFFFF9FF
       bt       rax, rdx
       jb       SHORT G_M000_IG65
 
G_M000_IG64:                ;; offset=0x0727
       mov      r14d, edi
       jmp      SHORT G_M000_IG66
 
G_M000_IG65:                ;; offset=0x072C
       mov      r14d, dword ptr [r8+0x14]
 
G_M000_IG66:                ;; offset=0x0730
       cmp      edi, dword ptr [rsi+0x40]
       jge      SHORT G_M000_IG67
       mov      rcx, rsi
       mov      edx, edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
 
G_M000_IG67:                ;; offset=0x0740
       mov      rdx, gword ptr [rsi]
       cmp      r14d, dword ptr [rdx+0x08]
       jae      G_M000_IG81
       mov      eax, r14d
       shl      rax, 4
       lea      r14, bword ptr [rdx+rax+0x10]
       mov      rcx, r14
       mov      rdx, rbx
       call     CORINFO_HELP_ASSIGN_REF
       xor      eax, eax
       mov      qword ptr [r14+0x08], rax
       mov      dword ptr [rsi+0x40], edi
       jmp      G_M000_IG76
 
G_M000_IG68:                ;; offset=0x0772
       xor      eax, eax
       jmp      G_M000_IG123
 
G_M000_IG69:                ;; offset=0x0779
       mov      rcx, bword ptr [rbp+0x10]
       mov      r9, gword ptr [rcx]
       mov      r9, gword ptr [r9+0x98]
       mov      edx, dword ptr [rcx+0x10]
       cmp      edx, dword ptr [r9+0x08]
       jae      G_M000_IG81
       shl      rdx, 5
       lea      r8, bword ptr [r9+rdx+0x10]
       mov      rbx, gword ptr [rbp-0xA0]
       mov      rdi, qword ptr [rbp-0x98]
       mov      r14d, dword ptr [r8+0x18]
       test     r14d, r14d
       jge      SHORT G_M000_IG70
       mov      gword ptr [rbp-0x108], rbx
       mov      qword ptr [rbp-0x100], rdi
       lea      r9, [rbp-0x108]
       mov      rdx, rsi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CompleteResultConsumer(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot)]
       jmp      SHORT G_M000_IG76
 
G_M000_IG70:                ;; offset=0x07D4
       lea      rsi, bword ptr [rcx+0x20]
       mov      edx, dword ptr [r8+0x1C]
       cmp      edx, 51
       ja       SHORT G_M000_IG73
 
G_M000_IG71:                ;; offset=0x07E1
       mov      rax, 0x7FFFFFFFFF9FF
       bt       rax, rdx
       jb       SHORT G_M000_IG73
 
G_M000_IG72:                ;; offset=0x07F1
       mov      r15d, r14d
       jmp      SHORT G_M000_IG74
 
G_M000_IG73:                ;; offset=0x07F6
       mov      r15d, dword ptr [r8+0x14]
 
G_M000_IG74:                ;; offset=0x07FA
       cmp      r14d, dword ptr [rsi+0x40]
       jge      SHORT G_M000_IG75
       mov      rcx, rsi
       mov      edx, r14d
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
 
G_M000_IG75:                ;; offset=0x080C
       mov      rdx, gword ptr [rsi]
       cmp      r15d, dword ptr [rdx+0x08]
       jae      G_M000_IG81
       mov      eax, r15d
       shl      rax, 4
       lea      r15, bword ptr [rdx+rax+0x10]
       mov      rcx, r15
       mov      rdx, rbx
       call     CORINFO_HELP_ASSIGN_REF
       mov      qword ptr [r15+0x08], rdi
       mov      dword ptr [rsi+0x40], r14d
 
G_M000_IG76:                ;; offset=0x0838
       mov      eax, 1
       jmp      G_M000_IG123
 
G_M000_IG77:                ;; offset=0x0842
       call     [System.ThrowHelper:ThrowArgumentOutOfRangeException()]
       int3     
 
G_M000_IG78:                ;; offset=0x0849
       mov      dword ptr [rbp-0xD4], r8d
       mov      rcx, 0x7FF9D77757F8
       call     CORINFO_HELP_GET_GCSTATIC_BASE
       mov      r8d, dword ptr [rbp-0xD4]
       jmp      G_M000_IG44
 
G_M000_IG79:                ;; offset=0x086B
       mov      dword ptr [rbp-0xD4], r8d
       mov      rcx, 0x7FF9D77757F8
       call     CORINFO_HELP_GET_GCSTATIC_BASE
       mov      r8d, dword ptr [rbp-0xD4]
       jmp      G_M000_IG52
 
G_M000_IG80:                ;; offset=0x088D
       mov      rdx, rax
       call     CORINFO_HELP_CHKCASTCLASS
       int3     
 
G_M000_IG81:                ;; offset=0x0896
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG82:                ;; offset=0x089C
       lea      r9, [rbp-0x40]
       mov      rcx, gword ptr [rbp-0x120]
       mov      rdx, rbx
       mov      r8, r15
       call     [Lokad.Lython.Runtime.PyExecutableFunction:TrySelectNativeCall(Lokad.Lython.Frontend.ExecutableCallSite,System.Object,byref):bool:this]
       test     eax, eax
       je       G_M000_IG124
       xor      ecx, ecx
       mov      dword ptr [rbp-0x44], ecx
 
G_M000_IG83:                ;; offset=0x08C0
       mov      rdx, gword ptr [rbx+0x18]
       mov      rax, gword ptr [rbp+0x18]
       mov      rcx, gword ptr [rax+0xA0]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.ExecutionState:EnterInterpreterFrame(Lokad.Lython.LythonSourceSpan):this]
       mov      dword ptr [rbp-0x44], 1
       mov      rdi, gword ptr [rbx+0x18]
       mov      rax, gword ptr [rbp+0x18]
       mov      r13, gword ptr [rax+0xA0]
       cmp      byte  ptr [r13], r13b
       mov      rcx, r13
       call     [Lokad.Lython.Runtime.ExecutionState:get_CanContinue():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG84
       mov      rcx, r13
       mov      rdx, rdi
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
 
G_M000_IG84:                ;; offset=0x090A
       mov      rcx, bword ptr [rbp+0x10]
       lea      rdx, bword ptr [rcx+0x20]
       cmp      byte  ptr [rbx+0x30], 0
       setne    al
       movzx    rax, al
       mov      r11d, dword ptr [rbp+0x30]
       lea      edi, [r11+rax+0x01]
       mov      r13d, dword ptr [rbx+0x28]
       mov      rdx, gword ptr [rdx]
       test     rdx, rdx
       je       SHORT G_M000_IG85
       mov      eax, edi
       mov      r8d, r13d
       add      rax, r8
       mov      r8d, dword ptr [rdx+0x08]
       cmp      rax, r8
       ja       G_M000_IG121
       mov      rax, rdx
       jmp      SHORT G_M000_IG86
 
G_M000_IG85:                ;; offset=0x094B
       mov      eax, edi
       or       eax, r13d
       jne      G_M000_IG121
       xor      rax, rax
       xor      edi, edi
       xor      r13d, r13d
 
G_M000_IG86:                ;; offset=0x095D
       xor      r12, r12
       xor      r8d, r8d
       test     rax, rax
       je       SHORT G_M000_IG89
       mov      rdx, qword ptr [rax]
       test     dword ptr [rdx], 0xFFFFFFFF80000000
       jne      SHORT G_M000_IG87
       lea      rdx, [rbp-0xD0]
       mov      rcx, rax
       mov      rax, qword ptr [rax]
       mov      rax, qword ptr [rax+0x40]
       call     [rax+0x28]System.Buffers.MemoryManager`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:GetSpan():System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:this
       mov      r8d, dword ptr [rbp-0xC8]
       mov      r12, bword ptr [rbp-0xD0]
       mov      eax, r8d
       jmp      SHORT G_M000_IG88
 
G_M000_IG87:                ;; offset=0x099A
       lea      r12, bword ptr [rax+0x10]
       mov      eax, dword ptr [rax+0x08]
 
G_M000_IG88:                ;; offset=0x09A1
       and      edi, 0x7FFFFFFF
       mov      r8d, edi
       mov      edx, r13d
       add      rdx, r8
       mov      eax, eax
       cmp      rdx, rax
       ja       G_M000_IG121
       shl      r8, 4
       add      r12, r8
       mov      eax, r13d
       mov      r8d, eax
 
G_M000_IG89:                ;; offset=0x09C8
       mov      bword ptr [rbp-0x118], r12
       mov      dword ptr [rbp-0xBC], r8d
       mov      dword ptr [rbp-0x110], r8d
       mov      rax, gword ptr [rbp+0x18]
       mov      gword ptr [rsp+0x20], rax
       movzx    rdx, byte  ptr [rbp-0x40]
       mov      dword ptr [rsp+0x28], edx
       lea      rdx, [rbp-0x58]
       mov      qword ptr [rsp+0x30], rdx
       lea      rdx, [rbp-0x60]
       mov      qword ptr [rsp+0x38], rdx
       lea      r8, [rbp-0x118]
       mov      rdx, rbx
       mov      rcx, gword ptr [rbp-0x120]
       mov      r9, r15
       call     [Lokad.Lython.Runtime.PyExecutableFunction:TryCompleteNativeCall(Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,bool,byref,byref):bool:this]
       test     eax, eax
       jne      G_M000_IG111
       lea      rcx, [rbp-0x78]
       mov      qword ptr [rsp+0x20], rcx
       lea      rcx, [rbp-0x70]
       mov      rdx, bword ptr [rbp+0x10]
       mov      r8, rbx
       mov      r9d, dword ptr [rbp+0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PrepareUnpackedCallReturn(byref,Lokad.Lython.Frontend.ExecutableCallSite,int,byref):System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]]
       cmp      dword ptr [rbp-0x68], 0
       jne      SHORT G_M000_IG90
       xor      edi, edi
       mov      r13d, dword ptr [rbp-0xBC]
       jmp      SHORT G_M000_IG93
 
G_M000_IG90:                ;; offset=0x0A51
       movzx    r9, byte  ptr [rbp-0x40]
       mov      bword ptr [rbp-0x118], r12
       mov      r13d, dword ptr [rbp-0xBC]
       mov      dword ptr [rbp-0x110], r13d
       mov      rcx, gword ptr [rbx+0x18]
 
G_M000_IG91:                ;; offset=0x0A6F
       vmovdqu  xmm0, xmmword ptr [rbp-0x70]
       vmovdqu  xmmword ptr [rbp-0xF8], xmm0
 
G_M000_IG92:                ;; offset=0x0A7C
       lea      rdx, [rbp-0x118]
       mov      gword ptr [rsp+0x20], rcx
       lea      rcx, [rbp-0xF8]
       mov      qword ptr [rsp+0x28], rcx
       mov      rcx, gword ptr [rbp-0x120]
       mov      r8, r15
       call     [Lokad.Lython.Runtime.PyExecutableFunction:TryReturnDefinitionPair(System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.Object,bool,Lokad.Lython.LythonSourceSpan,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):bool:this]
       mov      edi, eax
 
G_M000_IG93:                ;; offset=0x0AA6
       mov      dword ptr [rbp-0x80], edi
       xor      r8, r8
       mov      gword ptr [rbp-0x88], r8
       cmp      byte  ptr [rbp-0x80], 0
       jne      G_M000_IG99
       mov      r8, gword ptr [rbx+0x18]
       cmp      byte  ptr [rbx+0x31], 0
       je       SHORT G_M000_IG94
       mov      r9d, 1
       jmp      SHORT G_M000_IG96
 
G_M000_IG94:                ;; offset=0x0ACF
       mov      rdx, bword ptr [rbp+0x10]
       cmp      byte  ptr [rdx+0x14], 0
       jne      SHORT G_M000_IG95
       xor      r9d, r9d
       jmp      SHORT G_M000_IG96
 
G_M000_IG95:                ;; offset=0x0ADE
       movzx    r9, byte  ptr [rbx+0x32]
 
G_M000_IG96:                ;; offset=0x0AE3
       mov      bword ptr [rbp-0x118], r12
       mov      dword ptr [rbp-0x110], r13d
       mov      rax, gword ptr [rbp+0x18]
       mov      gword ptr [rsp+0x20], rax
       mov      gword ptr [rsp+0x28], r8
       mov      dword ptr [rsp+0x30], r9d
       movzx    r9, byte  ptr [rbp-0x40]
 
G_M000_IG97:                ;; offset=0x0B09
       vmovdqu  xmm0, xmmword ptr [rbp-0x70]
       vmovdqu  xmmword ptr [rbp-0xF8], xmm0
 
G_M000_IG98:                ;; offset=0x0B16
       lea      r8, [rbp-0x80]
       mov      qword ptr [rsp+0x48], r8
       lea      r8, [rbp-0x58]
       mov      qword ptr [rsp+0x50], r8
       lea      r8, [rbp-0x88]
       mov      qword ptr [rsp+0x58], r8
       lea      r8, [rbp-0x118]
       mov      dword ptr [rsp+0x38], r9d
       lea      r9, [rbp-0xF8]
       mov      qword ptr [rsp+0x40], r9
       mov      r9, r15
       mov      rdx, rbx
       mov      rcx, gword ptr [rbp-0x120]
       call     [Lokad.Lython.Runtime.PyExecutableFunction:StartNativeCall(Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,bool,bool,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,byref,byref):this]
 
G_M000_IG99:                ;; offset=0x0B5F
       cmp      byte  ptr [rbp-0x80], 0
       jne      SHORT G_M000_IG100
       mov      rdx, bword ptr [rbp+0x10]
       lea      rcx, bword ptr [rdx+0x20]
       mov      eax, dword ptr [rbp-0x78]
       mov      dword ptr [rcx+0x40], eax
 
G_M000_IG100:                ;; offset=0x0B73
       cmp      gword ptr [rbp-0x88], 0
       jne      G_M000_IG108
       mov      rax, gword ptr [rbp+0x18]
       mov      rcx, gword ptr [rax+0xA0]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.ExecutionState:LeaveInterpreterFrame():this]
       xor      r9d, r9d
       mov      dword ptr [rbp-0x44], r9d
       cmp      byte  ptr [rbp-0x80], 0
       jne      G_M000_IG107
       mov      rdx, bword ptr [rbp+0x10]
       mov      r9, gword ptr [rdx]
       mov      r9, gword ptr [r9+0x98]
       mov      r8d, dword ptr [rdx+0x10]
       cmp      r8d, dword ptr [r9+0x08]
       jae      G_M000_IG122
       shl      r8, 5
       lea      r8, bword ptr [r9+r8+0x10]
       mov      r14, gword ptr [rbp-0x58]
       mov      rdi, qword ptr [rbp-0x50]
       mov      r15d, dword ptr [r8+0x18]
       test     r15d, r15d
       jge      SHORT G_M000_IG101
       mov      gword ptr [rbp-0x108], r14
       mov      qword ptr [rbp-0x100], rdi
       lea      r9, [rbp-0x108]
       mov      rdx, rsi
       mov      rcx, bword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CompleteResultConsumer(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot)]
       jmp      G_M000_IG120
 
G_M000_IG101:                ;; offset=0x0C02
       mov      rdx, bword ptr [rbp+0x10]
       lea      rsi, bword ptr [rdx+0x20]
       mov      ecx, dword ptr [r8+0x1C]
       cmp      ecx, 51
       ja       SHORT G_M000_IG104
 
G_M000_IG102:                ;; offset=0x0C13
       mov      rax, 0x7FFFFFFFFF9FF
       bt       rax, rcx
       jb       SHORT G_M000_IG104
 
G_M000_IG103:                ;; offset=0x0C23
       mov      r13d, r15d
       jmp      SHORT G_M000_IG105
 
G_M000_IG104:                ;; offset=0x0C28
       mov      r13d, dword ptr [r8+0x14]
 
G_M000_IG105:                ;; offset=0x0C2C
       cmp      r15d, dword ptr [rsi+0x40]
       jge      SHORT G_M000_IG106
       mov      rcx, rsi
       mov      edx, r15d
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
 
G_M000_IG106:                ;; offset=0x0C3E
       mov      rcx, gword ptr [rsi]
       cmp      r13d, dword ptr [rcx+0x08]
       jae      G_M000_IG122
       mov      eax, r13d
       shl      rax, 4
       lea      r13, bword ptr [rcx+rax+0x10]
       mov      rcx, r13
       mov      rdx, r14
       call     CORINFO_HELP_ASSIGN_REF
       mov      qword ptr [r13+0x08], rdi
       mov      dword ptr [rsi+0x40], r15d
       jmp      G_M000_IG120
 
G_M000_IG107:                ;; offset=0x0C6F
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rbp+0x18]
       mov      r8d, dword ptr [rbp+0x30]
       mov      r9d, dword ptr [rbp-0x68]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CompleteUnpackedCallReturn(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,int,int)]
       jmp      G_M000_IG120
 
G_M000_IG108:                ;; offset=0x0C8A
       mov      rcx, gword ptr [rbp-0x88]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:EnterExecutableSlots():this]
       mov      rdi, gword ptr [rbp-0x88]
       mov      rcx, gword ptr [rbp-0x120]
       mov      rcx, gword ptr [rcx+0x28]
       mov      rcx, gword ptr [rcx+0xA0]
       mov      r15, gword ptr [rcx+0x88]
       lea      rcx, bword ptr [rsi+0x30]
       mov      rdx, rbx
       call     CORINFO_HELP_ASSIGN_REF
       xor      rcx, rcx
       mov      gword ptr [rsi+0x40], rcx
       mov      r9d, dword ptr [rbp+0x30]
       mov      dword ptr [rsi+0xF0], r9d
 
G_M000_IG109:                ;; offset=0x0CD6
       mov      dword ptr [rsi+0xF4], ecx
       lea      rcx, bword ptr [rdi+0x20]
       mov      rdx, rsi
       call     CORINFO_HELP_ASSIGN_REF
       lea      rcx, bword ptr [rdi+0x28]
       mov      rdx, r15
       call     CORINFO_HELP_ASSIGN_REF
       nop      
 
G_M000_IG110:                ;; offset=0x0CF5
       mov      rdx, gword ptr [rbp-0x88]
       mov      rcx, r14
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       xor      ecx, ecx
       mov      dword ptr [rbp-0x44], ecx
       jmp      G_M000_IG120
 
G_M000_IG111:                ;; offset=0x0D0E
       mov      rdx, gword ptr [rbp+0x18]
       mov      rcx, gword ptr [rdx+0xA0]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.ExecutionState:LeaveInterpreterFrame():this]
       xor      r9d, r9d
       mov      dword ptr [rbp-0x44], r9d
       cmp      byte  ptr [rbp-0x60], 0
       jne      G_M000_IG118
       mov      rdx, bword ptr [rbp+0x10]
       mov      r9, gword ptr [rdx]
       mov      r9, gword ptr [r9+0x98]
       mov      r8d, dword ptr [rdx+0x10]
       cmp      r8d, dword ptr [r9+0x08]
       jae      G_M000_IG122
       shl      r8, 5
       lea      r8, bword ptr [r9+r8+0x10]
       mov      rdi, gword ptr [rbp-0x58]
       mov      r14, qword ptr [rbp-0x50]
       mov      r15d, dword ptr [r8+0x18]
       test     r15d, r15d
       jge      SHORT G_M000_IG112
       mov      gword ptr [rbp-0x108], rdi
       mov      qword ptr [rbp-0x100], r14
       lea      r9, [rbp-0x108]
       mov      rdx, rsi
       mov      rcx, bword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CompleteResultConsumer(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot)]
       jmp      G_M000_IG120
 
G_M000_IG112:                ;; offset=0x0D8F
       mov      rdx, bword ptr [rbp+0x10]
       lea      rsi, bword ptr [rdx+0x20]
       mov      ecx, dword ptr [r8+0x1C]
       cmp      ecx, 51
       ja       SHORT G_M000_IG115
 
G_M000_IG113:                ;; offset=0x0DA0
       mov      rax, 0x7FFFFFFFFF9FF
       bt       rax, rcx
       jb       SHORT G_M000_IG115
 
G_M000_IG114:                ;; offset=0x0DB0
       mov      r13d, r15d
       jmp      SHORT G_M000_IG116
 
G_M000_IG115:                ;; offset=0x0DB5
       mov      r13d, dword ptr [r8+0x14]
 
G_M000_IG116:                ;; offset=0x0DB9
       cmp      r15d, dword ptr [rsi+0x40]
       jge      SHORT G_M000_IG117
       mov      rcx, rsi
       mov      edx, r15d
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
 
G_M000_IG117:                ;; offset=0x0DCB
       mov      rcx, gword ptr [rsi]
       cmp      r13d, dword ptr [rcx+0x08]
       jae      SHORT G_M000_IG122
       mov      eax, r13d
       shl      rax, 4
       lea      r13, bword ptr [rcx+rax+0x10]
       mov      rcx, r13
       mov      rdx, rdi
       call     CORINFO_HELP_ASSIGN_REF
       mov      qword ptr [r13+0x08], r14
       mov      dword ptr [rsi+0x40], r15d
       jmp      SHORT G_M000_IG120
 
G_M000_IG118:                ;; offset=0x0DF5
       vmovdqu  xmm0, xmmword ptr [rbp-0x58]
       vmovdqu  xmmword ptr [rbp-0x108], xmm0
 
G_M000_IG119:                ;; offset=0x0E02
       lea      r9, [rbp-0x108]
       mov      rdx, gword ptr [rbp+0x18]
       mov      r8, rsi
       mov      rcx, bword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PublishDirectIntegerCall(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot)]
 
G_M000_IG120:                ;; offset=0x0E1A
       mov      eax, 1
       jmp      SHORT G_M000_IG123
 
G_M000_IG121:                ;; offset=0x0E21
       call     [System.ThrowHelper:ThrowArgumentOutOfRangeException()]
       int3     
 
G_M000_IG122:                ;; offset=0x0E28
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG123:                ;; offset=0x0E2E
       add      rsp, 328
       pop      rbx
       pop      rsi
       pop      rdi
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG124:                ;; offset=0x0E42
       xor      eax, eax
 
G_M000_IG125:                ;; offset=0x0E44
       add      rsp, 328
       pop      rbx
       pop      rsi
       pop      rdi
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG126:                ;; offset=0x0E58
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG127:                ;; offset=0x0E5E
       sub      rsp, 104
 
G_M000_IG128:                ;; offset=0x0E62
       mov      r14, gword ptr [rbp-0x88]
       mov      rcx, gword ptr [rbp-0x120]
       call     [Lokad.Lython.Runtime.PyExecutableFunction:get_DefinitionContext():Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:this]
       mov      rcx, rax
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:get_MemoryGovernor():Lokad.Lython.Runtime.MemoryGovernor:this]
       mov      rdx, rax
       mov      rcx, r14
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:AbortPreparedCall(Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.MemoryGovernor)]
       call     CORINFO_HELP_RETHROW
       int3     
 
G_M000_IG129:                ;; offset=0x0E93
       sub      rsp, 104
 
G_M000_IG130:                ;; offset=0x0E97
       mov      rbx, rcx
       mov      rcx, bword ptr [rbp+0x10]
       cmp      byte  ptr [rcx], cl
       add      rcx, 32
       mov      edx, dword ptr [rbp+0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
       mov      rcx, gword ptr [rbp+0x28]
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_CallSpan():Lokad.Lython.LythonSourceSpan:this]
       mov      rdx, rax
       lea      r8, [rbp-0x90]
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime:TryTranslateCallableException(System.Exception,Lokad.Lython.LythonSourceSpan,byref):bool]
       test     eax, eax
       je       SHORT G_M000_IG131
       mov      rcx, gword ptr [rbp-0x90]
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG131:                ;; offset=0x0EDB
       call     CORINFO_HELP_RETHROW
       int3     
 
G_M000_IG132:                ;; offset=0x0EE1
       sub      rsp, 104
 
G_M000_IG133:                ;; offset=0x0EE5
       cmp      dword ptr [rbp-0x44], 0
       je       SHORT G_M000_IG134
       mov      rdx, gword ptr [rbp+0x18]
       mov      rcx, gword ptr [rdx+0xA0]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.ExecutionState:LeaveInterpreterFrame():this]
 
G_M000_IG134:                ;; offset=0x0EFE
       nop      
 
G_M000_IG135:                ;; offset=0x0EFF
       add      rsp, 104
       ret      
 
G_M000_IG136:                ;; offset=0x0F04
       sub      rsp, 104
 
G_M000_IG137:                ;; offset=0x0F08
       mov      rcx, bword ptr [rbp+0x10]
       cmp      byte  ptr [rcx], cl
       add      rcx, 32
       mov      edx, dword ptr [rbp+0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
       call     CORINFO_HELP_RETHROW
       int3     
 
G_M000_IG138:                ;; offset=0x0F21
       sub      rsp, 104
 
G_M000_IG139:                ;; offset=0x0F25
       mov      rcx, bword ptr [rbp+0x10]
       cmp      byte  ptr [rcx], cl
       add      rcx, 32
       mov      edx, dword ptr [rbp+0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
       call     CORINFO_HELP_RETHROW
       int3     
 
; Total bytes of code 3902

; Assembly listing for method Lokad.Lython.Runtime.PyExecutableFunction:TryReturnDefinitionPair(System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.Object,bool,Lokad.Lython.LythonSourceSpan,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):bool:this (FullOpts)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; FullOpts code
; optimized code
; rsp based frame
; partially interruptible
; No PGO data
; 0 inlinees with PGO data; 2 single block inlinees; 0 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       sub      rsp, 88
       xor      eax, eax
       mov      qword ptr [rsp+0x38], rax
       vxorps   xmm4, xmm4, xmm4
       vmovdqa  xmmword ptr [rsp+0x40], xmm4
       mov      qword ptr [rsp+0x50], rax
       mov      r10, bword ptr [rsp+0x88]
 
G_M000_IG02:                ;; offset=0x0022
       mov      r11, bword ptr [rdx]
       mov      eax, dword ptr [rdx+0x08]
       mov      rdx, gword ptr [rcx+0x40]
       cmp      byte  ptr [rdx+0xF1], 0
       jne      SHORT G_M000_IG04
 
G_M000_IG03:                ;; offset=0x0035
       xor      edx, edx
       jmp      SHORT G_M000_IG05
 
G_M000_IG04:                ;; offset=0x0039
       cmp      dword ptr [r10+0x08], 2
       sete     dl
       movzx    rdx, dl
 
G_M000_IG05:                ;; offset=0x0044
       movzx    r9, r9b
       test     edx, r9d
       je       SHORT G_M000_IG07
 
G_M000_IG06:                ;; offset=0x004D
       test     r8, r8
       jne      SHORT G_M000_IG07
       cmp      eax, 1
       je       SHORT G_M000_IG09
 
G_M000_IG07:                ;; offset=0x0057
       xor      eax, eax
 
G_M000_IG08:                ;; offset=0x0059
       add      rsp, 88
       ret      
 
G_M000_IG09:                ;; offset=0x005E
       vmovdqu  xmm0, xmmword ptr [r11]
       vmovdqu  xmmword ptr [rsp+0x38], xmm0
 
G_M000_IG10:                ;; offset=0x0069
       lea      r8, [rsp+0x48]
       mov      qword ptr [rsp+0x20], r8
       mov      bword ptr [rsp+0x28], r10
       lea      r8, [rsp+0x38]
       mov      r9, gword ptr [rsp+0x80]
       xor      rdx, rdx
       call     [Lokad.Lython.Runtime.PyExecutableFunction:TryReturnDefinition(Lokad.Lython.Frontend.ExecutableCreateFunction,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot,Lokad.Lython.LythonSourceSpan,byref,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):bool:this]
       nop      
 
G_M000_IG11:                ;; offset=0x008E
       add      rsp, 88
       ret      
 
; Total bytes of code 147

; Assembly listing for method Lokad.Lython.Runtime.PyExecutableFunction:StartNativeCall(Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,bool,bool,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,byref,byref):this (FullOpts)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; FullOpts code
; optimized code
; rbp based frame
; partially interruptible
; No PGO data
; 1 inlinees with PGO data; 11 single block inlinees; 5 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       push     r15
       push     r14
       push     rdi
       push     rsi
       push     rbx
       sub      rsp, 440
       lea      rbp, [rsp+0x1E0]
       vxorps   xmm4, xmm4, xmm4
       vmovdqa  xmmword ptr [rbp-0x190], xmm4
       mov      rax, -336
 
G_M000_IG16:                ;; offset=0x002D
       vmovdqa  xmmword ptr [rbp+rax-0x30], xmm4
       vmovdqa  xmmword ptr [rbp+rax-0x20], xmm4
       vmovdqa  xmmword ptr [rbp+rax-0x10], xmm4
       add      rax, 48
       jne      SHORT G_M000_IG16
       mov      qword ptr [rbp-0x30], rax
       mov      rbx, rcx
       mov      rdi, gword ptr [rbp+0x38]
       mov      rsi, bword ptr [rbp+0x50]
 
G_M000_IG02:                ;; offset=0x0054
       mov      rax, bword ptr [r8]
       mov      r14d, dword ptr [r8+0x08]
       mov      rcx, gword ptr [rbx+0x40]
       mov      r15d, dword ptr [rcx+0xE8]
       cmp      r15d, 16
       ja       G_M000_IG11
       cmp      byte  ptr [rbp+0x48], 0
       jne      G_M000_IG07
 
G_M000_IG03:                ;; offset=0x007A
       mov      rcx, gword ptr [rbx+0x08]
       mov      rcx, gword ptr [rcx+0x08]
       mov      ecx, dword ptr [rcx+0x08]
       cmp      ecx, r15d
       ja       G_M000_IG11
       lea      r8, bword ptr [rbp-0x128]
       mov      bword ptr [rbp-0x170], r8
       mov      dword ptr [rbp-0x168], ecx
       xor      rcx, rcx
       mov      bword ptr [rbp-0x180], rcx
 
G_M000_IG04:                ;; offset=0x00AB
       mov      dword ptr [rbp-0x178], ecx
       mov      rcx, gword ptr [rbp+0x30]
       mov      gword ptr [rsp+0x20], rcx
       xor      ecx, ecx
       mov      dword ptr [rsp+0x28], ecx
       mov      gword ptr [rsp+0x30], r9
       mov      gword ptr [rsp+0x38], rdx
       mov      bword ptr [rbp-0x190], rax
       mov      dword ptr [rbp-0x188], r14d
       lea      rcx, [rbp-0x170]
       lea      rdx, [rbp-0x180]
       lea      r9, [rbp-0x190]
       mov      qword ptr [rsp+0x40], r9
       mov      r9, rbx
       mov      r8, rdi
       call     [Lokad.Lython.Runtime.LythonRuntime:BindFunctionArgumentsInto(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.ReadOnlySpan`1[Lokad.Lython.Runtime.CallArgumentValue],Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.FunctionBindingPlan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,bool,System.Object,Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):int]
 
G_M000_IG05:                ;; offset=0x00FE
       vxorps   ymm0, ymm0, ymm0
       vmovdqu  ymmword ptr [rbp-0x160], ymm0
       lea      rdx, bword ptr [rbp-0x128]
       mov      bword ptr [rbp-0x170], rdx
       mov      dword ptr [rbp-0x168], r15d
       movzx    rdx, byte  ptr [rbp+0x40]
       mov      dword ptr [rsp+0x20], edx
       mov      bword ptr [rsp+0x28], rsi
       mov      rsi, bword ptr [rbp+0x58]
       mov      bword ptr [rsp+0x30], rsi
       mov      rsi, bword ptr [rbp+0x60]
       mov      bword ptr [rsp+0x38], rsi
       mov      rsi, bword ptr [rbp+0x68]
       mov      bword ptr [rsp+0x40], rsi
       lea      rdx, [rbp-0x140]
       mov      qword ptr [rsp+0x48], rdx
       lea      rdx, [rbp-0x170]
       lea      r8, [rbp-0x160]
       mov      rcx, rbx
       mov      r9, rdi
       call     [Lokad.Lython.Runtime.PyExecutableFunction:StartInline(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.Nullable`1[Lokad.Lython.Runtime.BoundFunctionArguments],Lokad.Lython.LythonSourceSpan,bool,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,byref,byref,byref):this]
       nop      
 
G_M000_IG06:                ;; offset=0x016E
       add      rsp, 440
       pop      rbx
       pop      rsi
       pop      rdi
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG07:                ;; offset=0x017E
       xor      ecx, ecx
       test     r9, r9
       je       SHORT G_M000_IG08
       mov      ecx, 1
       test     r15d, r15d
       je       G_M000_IG15
       mov      gword ptr [rbp-0x128], r9
       xor      edx, edx
       mov      qword ptr [rbp-0x120], rdx
 
G_M000_IG08:                ;; offset=0x01A3
       cmp      ecx, r15d
       ja       SHORT G_M000_IG11
       lea      rdx, bword ptr [rbp-0x128]
       mov      r8d, ecx
       shl      r8, 4
       add      r8, rdx
       mov      edx, r15d
       sub      edx, ecx
       cmp      r14d, edx
       ja       SHORT G_M000_IG14
 
G_M000_IG09:                ;; offset=0x01C3
       mov      ecx, r14d
       shl      rcx, 4
       mov      r10, rcx
       cmp      r10, 0x4000
       ja       SHORT G_M000_IG13
 
G_M000_IG10:                ;; offset=0x01D6
       mov      rcx, r8
       mov      rdx, rax
       mov      r8, r10
       call     System.Buffer:BulkMoveWithWriteBarrierInternal(byref,byref,nuint)
       cmp      dword ptr [(reloc 0x7ffa37082aa8)], 0
       je       G_M000_IG05
       jmp      SHORT G_M000_IG12
 
G_M000_IG11:                ;; offset=0x01F3
       call     [System.ThrowHelper:ThrowArgumentOutOfRangeException()]
       int3     
 
G_M000_IG12:                ;; offset=0x01FA
       call     CORINFO_HELP_POLL_GC
       jmp      G_M000_IG05
 
G_M000_IG13:                ;; offset=0x0204
       mov      rcx, r8
       mov      rdx, rax
       mov      r8, r10
       call     [System.Buffer:BulkMoveWithWriteBarrierBatch(byref,byref,nuint)]
       jmp      G_M000_IG05
 
G_M000_IG14:                ;; offset=0x0218
       call     [System.ThrowHelper:ThrowArgumentException_DestinationTooShort()]
       int3     
 
G_M000_IG15:                ;; offset=0x021F
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
; Total bytes of code 549

; Assembly listing for method Lokad.Lython.Runtime.PyExecutableFunction:TryReturnDefinition(Lokad.Lython.Frontend.ExecutableCreateFunction,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot,Lokad.Lython.LythonSourceSpan,byref,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):bool:this (FullOpts)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; FullOpts code
; optimized code
; rbp based frame
; fully interruptible
; No PGO data
; 0 inlinees with PGO data; 48 single block inlinees; 5 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       push     r15
       push     r14
       push     r13
       push     r12
       push     rdi
       push     rsi
       push     rbx
       sub      rsp, 104
       lea      rbp, [rsp+0xA0]
       vxorps   xmm4, xmm4, xmm4
       vmovdqu  ymmword ptr [rbp-0x60], ymm4
       xor      eax, eax
       mov      qword ptr [rbp-0x40], rax
       mov      gword ptr [rbp+0x10], rcx
       mov      gword ptr [rbp+0x28], r9
       mov      rbx, rcx
       mov      rsi, rdx
       mov      rdi, bword ptr [rbp+0x30]
       mov      rcx, bword ptr [rbp+0x38]
 
G_M000_IG02:                ;; offset=0x003D
       mov      r14, bword ptr [rcx]
       mov      r15d, dword ptr [rcx+0x08]
       mov      r13, gword ptr [r8]
       mov      r12, qword ptr [r8+0x08]
       xor      ecx, ecx
       mov      qword ptr [rdi], rcx
       mov      qword ptr [rdi+0x08], rcx
 
G_M000_IG03:                ;; offset=0x0054
       mov      gword ptr [rbp-0x68], rcx
       test     rsi, rsi
       jne      SHORT G_M000_IG05
 
G_M000_IG04:                ;; offset=0x005D
       xor      edx, edx
       mov      eax, edx
       jmp      SHORT G_M000_IG06
 
G_M000_IG05:                ;; offset=0x0063
       mov      rcx, rsi
       call     [Lokad.Lython.Frontend.ExecutableCreateFunction:get_InputCount():int:this]
       test     eax, eax
       sete     dl
       movzx    rdx, dl
       mov      eax, edx
 
G_M000_IG06:                ;; offset=0x0076
       mov      dword ptr [rbp-0x44], eax
       test     eax, eax
       jne      G_M000_IG22
 
G_M000_IG07:                ;; offset=0x0081
       mov      rdx, 0x143D6801CF0
       cmp      r13, gword ptr [rdx]
       je       SHORT G_M000_IG13
       test     r12, r12
       jle      SHORT G_M000_IG08
       mov      rdx, r13
       mov      rcx, 0x7FF9D76A88F0
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       jne      SHORT G_M000_IG09
 
G_M000_IG08:                ;; offset=0x00AC
       lea      rdx, [rbp-0x40]
       mov      rcx, r13
       call     [Lokad.Lython.Runtime.LythonRuntime:TryMachineInteger(System.Object,byref):bool]
       jmp      SHORT G_M000_IG10
 
G_M000_IG09:                ;; offset=0x00BB
       mov      rcx, rax
       lea      edx, [r12-0x01]
       lea      r8, [rbp-0x40]
       call     [Lokad.Lython.Runtime.PyTuple:TryReadInteger(int,byref):bool:this]
 
G_M000_IG10:                ;; offset=0x00CD
       test     eax, eax
       jne      SHORT G_M000_IG14
 
G_M000_IG11:                ;; offset=0x00D1
       xor      eax, eax
 
G_M000_IG12:                ;; offset=0x00D3
       add      rsp, 104
       pop      rbx
       pop      rsi
       pop      rdi
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG13:                ;; offset=0x00E4
       mov      qword ptr [rbp-0x40], r12
 
G_M000_IG14:                ;; offset=0x00E8
       mov      rcx, gword ptr [rbx+0x40]
       mov      rcx, gword ptr [rcx+0x80]
       mov      r11, 0x7FF9D7092198
       call     [r11]System.Collections.Generic.IReadOnlyCollection`1[System.__Canon]:get_Count():int:this
       test     eax, eax
       je       SHORT G_M000_IG22
       lea      rcx, bword ptr [rbx+0x58]
       mov      rdx, gword ptr [rcx]
       test     rdx, rdx
       je       SHORT G_M000_IG16
 
G_M000_IG15:                ;; offset=0x0110
       mov      rax, 0x7FF9D77466F0
       cmp      qword ptr [rdx], rax
       je       SHORT G_M000_IG19
 
G_M000_IG16:                ;; offset=0x011F
       test     rdx, rdx
       je       SHORT G_M000_IG18
 
G_M000_IG17:                ;; offset=0x0124
       mov      rax, 0x7FF9D7774510
       xor      r8, r8
       cmp      qword ptr [rdx], rax
       cmovne   rdx, r8
 
G_M000_IG18:                ;; offset=0x0138
       test     rdx, rdx
       je       SHORT G_M000_IG20
 
G_M000_IG19:                ;; offset=0x013D
       xor      rax, rax
       jmp      SHORT G_M000_IG21
 
G_M000_IG20:                ;; offset=0x0141
       mov      rax, gword ptr [rcx]
 
G_M000_IG21:                ;; offset=0x0144
       test     rax, rax
       mov      gword ptr [rbp-0x68], rax
       je       SHORT G_M000_IG11
 
G_M000_IG22:                ;; offset=0x014D
       mov      rcx, gword ptr [rbx+0x28]
       mov      rcx, gword ptr [rcx+0xA0]
       mov      rdx, gword ptr [rbp+0x28]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.ExecutionState:EnterFunctionCall(Lokad.Lython.LythonSourceSpan):this]
       mov      rdx, gword ptr [rbx+0x28]
       mov      r8, gword ptr [rdx+0xA0]
       mov      r8, gword ptr [r8+0x148]
       mov      gword ptr [rbp-0x70], r8
 
G_M000_IG23:                ;; offset=0x017A
       xor      r8d, r8d
       mov      dword ptr [rbp-0x50], r8d
       cmp      dword ptr [rbp-0x44], 0
       je       SHORT G_M000_IG24
       mov      gword ptr [rbp-0x60], r13
       mov      qword ptr [rbp-0x58], r12
       mov      r8, gword ptr [rbx+0x40]
       mov      r8, gword ptr [r8+0x98]
       cmp      dword ptr [r8+0x08], 0
       jbe      G_M000_IG33
       mov      r9, gword ptr [r8+0x10]
       lea      r8, [rbp-0x60]
       mov      rcx, rsi
       call     [Lokad.Lython.Runtime.LythonRuntime:CreateClosedFunctionDefinition(Lokad.Lython.Frontend.ExecutableCreateFunction,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.PyFunctionBase]
       mov      rsi, rax
       jmp      SHORT G_M000_IG25
 
G_M000_IG24:                ;; offset=0x01BB
       lea      rcx, [rbp-0x50]
       mov      qword ptr [rsp+0x20], rcx
       mov      rcx, gword ptr [rbx+0x40]
       mov      r8, qword ptr [rbp-0x40]
       mov      r9, gword ptr [rbp-0x68]
       call     [Lokad.Lython.Runtime.LythonRuntime:CreateClosedComputedDefinition(Lokad.Lython.Frontend.ExecutableCodeObject,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,long,System.Object,byref):Lokad.Lython.Runtime.PyFunctionBase]
       mov      rsi, rax
 
G_M000_IG25:                ;; offset=0x01D9
       mov      r13, rsi
       test     r15d, r15d
       je       G_M000_IG31
       mov      rcx, gword ptr [rbx+0x28]
       mov      rax, gword ptr [rbx+0x40]
       mov      rax, gword ptr [rax+0x98]
       mov      edx, dword ptr [rbp-0x50]
       mov      r8d, dword ptr [rbp-0x50]
       inc      r8d
       mov      dword ptr [rbp-0x50], r8d
       cmp      edx, dword ptr [rax+0x08]
       jae      G_M000_IG33
       shl      rdx, 5
       mov      rsi, gword ptr [rax+rdx+0x10]
       mov      rdi, gword ptr [rcx+0xA0]
       cmp      byte  ptr [rdi], dil
       mov      rcx, rdi
       call     [Lokad.Lython.Runtime.ExecutionState:get_CanContinue():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG26
       mov      rcx, rdi
       mov      rdx, rsi
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
 
G_M000_IG26:                ;; offset=0x0237
       lea      rcx, [rbp-0x50]
       mov      qword ptr [rsp+0x20], rcx
       mov      rcx, gword ptr [rbx+0x40]
       mov      rdx, gword ptr [rbx+0x28]
       mov      r8, qword ptr [rbp-0x40]
       xor      r9, r9
       call     [Lokad.Lython.Runtime.LythonRuntime:CreateClosedComputedDefinition(Lokad.Lython.Frontend.ExecutableCodeObject,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,long,System.Object,byref):Lokad.Lython.Runtime.PyFunctionBase]
       mov      rsi, rax
       mov      edi, dword ptr [rbp-0x50]
       mov      rcx, gword ptr [rbx+0x40]
       mov      rcx, gword ptr [rcx+0x98]
       cmp      dword ptr [rcx+0x08], edi
       jle      SHORT G_M000_IG30
 
G_M000_IG27:                ;; offset=0x026B
       mov      rcx, gword ptr [rbx+0x28]
       mov      rax, gword ptr [rbx+0x40]
       mov      rax, gword ptr [rax+0x98]
       mov      edx, dword ptr [rax+0x08]
       cmp      dword ptr [rbp-0x50], edx
       jae      G_M000_IG33
       mov      edx, dword ptr [rbp-0x50]
       shl      rdx, 5
       mov      rdi, gword ptr [rax+rdx+0x10]
       mov      r12, gword ptr [rcx+0xA0]
       cmp      byte  ptr [r12], r12b
       mov      rcx, r12
       call     [Lokad.Lython.Runtime.ExecutionState:get_CanContinue():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG29
 
G_M000_IG28:                ;; offset=0x02AA
       mov      rcx, r12
       mov      rdx, rdi
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
 
G_M000_IG29:                ;; offset=0x02B6
       mov      ecx, dword ptr [rbp-0x50]
       inc      ecx
       mov      dword ptr [rbp-0x50], ecx
       mov      edi, dword ptr [rbp-0x50]
       mov      rcx, gword ptr [rbx+0x40]
       mov      rcx, gword ptr [rcx+0x98]
       cmp      dword ptr [rcx+0x08], edi
       jg       SHORT G_M000_IG27
 
G_M000_IG30:                ;; offset=0x02D1
       cmp      r15d, 1
       jbe      G_M000_IG33
       lea      rdi, bword ptr [r14+0x10]
       mov      rcx, rdi
       mov      rdx, r13
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       xor      ecx, ecx
       mov      qword ptr [rdi+0x08], rcx
       mov      rcx, r14
       mov      rdx, rsi
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       xor      ecx, ecx
       mov      qword ptr [r14+0x08], rcx
       jmp      SHORT G_M000_IG34
 
G_M000_IG31:                ;; offset=0x0303
       mov      rcx, gword ptr [rbx+0x28]
       mov      rax, gword ptr [rbx+0x40]
       mov      rax, gword ptr [rax+0x98]
       mov      edx, dword ptr [rax+0x08]
       dec      edx
       cmp      edx, dword ptr [rax+0x08]
       jae      SHORT G_M000_IG33
       shl      rdx, 5
       mov      r14, gword ptr [rax+rdx+0x10]
       mov      r15, gword ptr [rcx+0xA0]
       cmp      byte  ptr [r15], r15b
       mov      rcx, r15
       call     [Lokad.Lython.Runtime.ExecutionState:get_CanContinue():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG32
       mov      rcx, r15
       mov      rdx, r14
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
 
G_M000_IG32:                ;; offset=0x0348
       mov      rcx, rdi
       mov      rdx, rsi
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       xor      ecx, ecx
       mov      qword ptr [rdi+0x08], rcx
       jmp      SHORT G_M000_IG34
 
G_M000_IG33:                ;; offset=0x035B
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG34:                ;; offset=0x0361
       mov      rcx, gword ptr [rbx+0x28]
       mov      rdi, gword ptr [rcx+0xA0]
       mov      rsi, rdi
       lea      rcx, bword ptr [rsi+0x148]
       mov      rdx, gword ptr [rbp-0x70]
       call     CORINFO_HELP_ASSIGN_REF
       mov      rcx, rdi
       call     [Lokad.Lython.Runtime.ExecutionState:LeaveFunctionCall():this]
       nop      
 
G_M000_IG35:                ;; offset=0x0389
       mov      eax, 1
 
G_M000_IG36:                ;; offset=0x038E
       add      rsp, 104
       pop      rbx
       pop      rsi
       pop      rdi
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG37:                ;; offset=0x039F
       sub      rsp, 40
 
G_M000_IG38:                ;; offset=0x03A3
       mov      rbx, rcx
       cmp      gword ptr [rbp-0x70], 0
       je       SHORT G_M000_IG39
       mov      rcx, rbx
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntimeException:get_OriginalPythonException():Lokad.Lython.Runtime.PyException:this]
       cmp      rax, gword ptr [rbp-0x70]
       je       SHORT G_M000_IG39
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntimeException:get_PythonContext():Lokad.Lython.Runtime.PyException:this]
       test     rax, rax
       jne      SHORT G_M000_IG39
       mov      rcx, rbx
       mov      rdx, gword ptr [rbp-0x70]
       call     [Lokad.Lython.Runtime.LythonRuntimeException:set_PythonContext(Lokad.Lython.Runtime.PyException):this]
 
G_M000_IG39:                ;; offset=0x03D9
       call     CORINFO_HELP_RETHROW
       int3     
 
G_M000_IG40:                ;; offset=0x03DF
       sub      rsp, 40
 
G_M000_IG41:                ;; offset=0x03E3
       mov      rbx, gword ptr [rbp+0x10]
       mov      rcx, gword ptr [rbx+0x28]
       mov      rsi, gword ptr [rcx+0xA0]
       lea      rcx, bword ptr [rsi+0x148]
       mov      rdx, gword ptr [rbp-0x70]
       call     CORINFO_HELP_ASSIGN_REF
       mov      rcx, gword ptr [rbx+0x28]
       mov      rcx, gword ptr [rcx+0xA0]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.ExecutionState:LeaveFunctionCall():this]
       nop      
 
G_M000_IG42:                ;; offset=0x0416
       add      rsp, 40
       ret      
 
G_M000_IG43:                ;; offset=0x041B
       sub      rsp, 40
 
G_M000_IG44:                ;; offset=0x041F
       mov      rbx, rcx
       mov      rcx, gword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.PyFunctionBase:get_Closure():Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:this]
       mov      rsi, rax
       mov      rcx, gword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.PyFunctionBase:get_Name():System.String:this]
       mov      r8, rax
       mov      rdx, rsi
       mov      rcx, rbx
       mov      r9, gword ptr [rbp+0x28]
       call     [Lokad.Lython.Runtime.PyFunctionBinding:AnnotateException(Lokad.Lython.Runtime.LythonRuntimeException,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,System.String,Lokad.Lython.LythonSourceSpan)]
       call     CORINFO_HELP_RETHROW
       int3     
 
; Total bytes of code 1106

; Assembly listing for method Lokad.Lython.Runtime.LythonRuntime:CreateClosedComputedDefinition(Lokad.Lython.Frontend.ExecutableCodeObject,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,long,System.Object,byref):Lokad.Lython.Runtime.PyFunctionBase (FullOpts)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; FullOpts code
; optimized code
; rbp based frame
; fully interruptible
; No PGO data
; 0 inlinees with PGO data; 36 single block inlinees; 5 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       push     r15
       push     r14
       push     r13
       push     r12
       push     rdi
       push     rsi
       push     rbx
       sub      rsp, 344
       lea      rbp, [rsp+0x190]
       xor      eax, eax
       mov      qword ptr [rbp-0xD8], rax
       vxorps   xmm4, xmm4, xmm4
       vmovdqu  ymmword ptr [rbp-0xD0], ymm4
       vmovdqu  ymmword ptr [rbp-0xB0], ymm4
       vmovdqu  ymmword ptr [rbp-0x90], ymm4
       vmovdqu  ymmword ptr [rbp-0x70], ymm4
       vmovdqa  xmmword ptr [rbp-0x50], xmm4
       mov      qword ptr [rbp-0x40], rax
       mov      gword ptr [rbp+0x18], rdx
       mov      rdi, rcx
       mov      rbx, rdx
       mov      r15, r8
       mov      r14, r9
       mov      rsi, bword ptr [rbp+0x30]
 
G_M000_IG02:                ;; offset=0x0062
       mov      r13, gword ptr [rdi+0x98]
       mov      r12d, dword ptr [rsi]
       lea      ecx, [r12+0x01]
       mov      dword ptr [rsi], ecx
       mov      eax, dword ptr [r13+0x08]
       mov      dword ptr [rbp-0xDC], eax
       cmp      r12d, eax
       jae      G_M000_IG55
       mov      ecx, r12d
       shl      rcx, 5
       lea      r12, bword ptr [r13+rcx+0x10]
       mov      rdx, gword ptr [rdi+0x30]
       mov      gword ptr [rbp-0x128], rdx
       mov      rcx, r12
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ConstantIndex():int:this]
       mov      rcx, gword ptr [rbp-0x128]
       cmp      eax, dword ptr [rcx+0x08]
       jae      G_M000_IG55
       mov      edx, eax
       mov      rdx, gword ptr [rcx+8*rdx+0x10]
       mov      rax, rdx
       test     rax, rax
       je       SHORT G_M000_IG04
 
G_M000_IG03:                ;; offset=0x00C5
       mov      rcx, 0x7FF9D759ABA8
       cmp      qword ptr [rax], rcx
       jne      G_M000_IG54
 
G_M000_IG04:                ;; offset=0x00D8
       mov      gword ptr [rbp-0xE8], rax
       mov      rcx, gword ptr [r12]
       mov      gword ptr [rsp+0x20], rcx
       lea      rcx, [rbp-0x50]
       mov      rdx, rax
       mov      r9, rbx
       xor      r8d, r8d
       call     [Lokad.Lython.Runtime.LythonRuntime:AllocateExecutableDefaults(Lokad.Lython.Frontend.FunctionParameterLayout,bool,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.FunctionDefaults]
       nop      
 
G_M000_IG05:                ;; offset=0x00FC
       xor      r12d, r12d
       mov      rax, gword ptr [rbp-0xE8]
       mov      rcx, gword ptr [rax+0x28]
       cmp      dword ptr [rcx+0x08], 0
       je       G_M000_IG23
 
G_M000_IG06:                ;; offset=0x0114
       mov      gword ptr [rsp+0x20], r14
       mov      bword ptr [rsp+0x28], rsi
       lea      rcx, [rbp-0x60]
       mov      rdx, rdi
       mov      r8, r15
       mov      r9, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime:EvaluateClosedDefault(Lokad.Lython.Frontend.ExecutableCodeObject,long,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,System.Object,byref):Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]
       mov      edx, dword ptr [rsi]
       lea      ecx, [rdx+0x01]
       mov      dword ptr [rsi], ecx
       cmp      edx, dword ptr [rbp-0xDC]
       jae      G_M000_IG51
       shl      rdx, 5
       lea      r8, bword ptr [r13+rdx+0x10]
       mov      bword ptr [rbp-0xF0], r8
       mov      r10, gword ptr [rbp-0xE8]
       cmp      r12d, dword ptr [r10+0x38]
       jl       G_M000_IG19
 
G_M000_IG07:                ;; offset=0x0165
       mov      rdx, gword ptr [rbp-0x48]
       mov      rcx, 0x7FF9D7152560
       call     CORINFO_HELP_ISINSTANCEOFARRAY
       mov      gword ptr [rbp-0xF8], rax
       test     rax, rax
       jne      G_M000_IG13
       mov      rdx, bword ptr [rbp-0xF0]
       mov      rax, gword ptr [rdx]
       mov      gword ptr [rbp-0x110], rax
       mov      rdx, gword ptr [rbx+0xA0]
       mov      gword ptr [rbp-0x118], rdx
       cmp      byte  ptr [rdx], dl
       mov      rcx, rdx
       call     [Lokad.Lython.Runtime.ExecutionState:get_CanContinue():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG08
       mov      rcx, gword ptr [rbp-0x118]
       mov      rdx, gword ptr [rbp-0x110]
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
 
G_M000_IG08:                ;; offset=0x01CA
       mov      rax, gword ptr [rbp-0x50]
       mov      gword ptr [rbp-0x120], rax
       movzx    rdx, byte  ptr [rbp-0x40]
       mov      byte  ptr [rbp-0x7C], dl
       mov      rcx, gword ptr [rbp-0x60]
       mov      r8, 0x143D6801CF0
       cmp      rcx, gword ptr [r8]
       je       SHORT G_M000_IG11
       mov      r8, 0x143D6801CF8
       cmp      rcx, gword ptr [r8]
       je       SHORT G_M000_IG10
       cmp      qword ptr [rbp-0x58], 0
       jne      SHORT G_M000_IG09
       jmp      SHORT G_M000_IG12
 
G_M000_IG09:                ;; offset=0x0207
       lea      rcx, [rbp-0x60]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishDeferredValue():System.Object:this]
       mov      rcx, rax
       jmp      SHORT G_M000_IG12
 
G_M000_IG10:                ;; offset=0x0216
       mov      rcx, 0x7FF9D7186488
       call     CORINFO_HELP_NEWSFAST
       vmovsd   xmm0, qword ptr [rbp-0x58]
       vmovsd   qword ptr [rax+0x08], xmm0
       mov      rcx, rax
       mov      gword ptr [rbp-0x60], rcx
       xor      eax, eax
       mov      qword ptr [rbp-0x58], rax
       jmp      SHORT G_M000_IG12
 
G_M000_IG11:                ;; offset=0x023E
       lea      rcx, [rbp-0x60]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishInteger():System.Object:this]
       mov      rcx, rax
 
G_M000_IG12:                ;; offset=0x024B
       call     [Lokad.Lython.Runtime.LythonRuntime:RuntimeValue(System.Object):System.Object]
       mov      rcx, gword ptr [rbp-0x120]
       mov      gword ptr [rbp-0x50], rcx
       mov      gword ptr [rbp-0x48], rax
       movzx    rcx, byte  ptr [rbp-0x7C]
       mov      byte  ptr [rbp-0x40], cl
       jmp      G_M000_IG22
 
G_M000_IG13:                ;; offset=0x026C
       mov      rdx, bword ptr [rbp-0xF0]
       mov      r8d, dword ptr [rdx+0x0C]
       mov      dword ptr [rbp-0x64], r8d
       mov      rcx, gword ptr [rbp-0x60]
       mov      r10, qword ptr [rbp-0x58]
       mov      r9, gword ptr [rbx+0xA0]
       mov      gword ptr [rbp-0x100], r9
       mov      gword ptr [rbp-0x78], rcx
       mov      qword ptr [rbp-0x70], r10
       mov      rdx, gword ptr [rdx]
       mov      gword ptr [rbp-0x108], rdx
       cmp      byte  ptr [r9], r9b
       mov      rcx, r9
       call     [Lokad.Lython.Runtime.ExecutionState:get_CanContinue():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG14
       mov      rcx, gword ptr [rbp-0x100]
       mov      rdx, gword ptr [rbp-0x108]
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
 
G_M000_IG14:                ;; offset=0x02C7
       mov      rcx, gword ptr [rbp-0x78]
       mov      rax, 0x143D6801CF0
       cmp      rcx, gword ptr [rax]
       je       SHORT G_M000_IG17
       mov      rcx, gword ptr [rbp-0x78]
       mov      rax, 0x143D6801CF8
       cmp      rcx, gword ptr [rax]
       je       SHORT G_M000_IG16
       cmp      qword ptr [rbp-0x70], 0
       jne      SHORT G_M000_IG15
       mov      rcx, gword ptr [rbp-0x78]
       jmp      SHORT G_M000_IG18
 
G_M000_IG15:                ;; offset=0x02FA
       lea      rcx, [rbp-0x78]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishDeferredValue():System.Object:this]
       mov      rcx, rax
       jmp      SHORT G_M000_IG18
 
G_M000_IG16:                ;; offset=0x0309
       mov      rcx, 0x7FF9D7186488
       call     CORINFO_HELP_NEWSFAST
       vmovsd   xmm0, qword ptr [rbp-0x70]
       vmovsd   qword ptr [rax+0x08], xmm0
       mov      rcx, rax
       mov      gword ptr [rbp-0x78], rcx
       xor      eax, eax
       mov      qword ptr [rbp-0x70], rax
       jmp      SHORT G_M000_IG18
 
G_M000_IG17:                ;; offset=0x0331
       lea      rcx, [rbp-0x78]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishInteger():System.Object:this]
       mov      rcx, rax
 
G_M000_IG18:                ;; offset=0x033E
       call     [Lokad.Lython.Runtime.LythonRuntime:RuntimeValue(System.Object):System.Object]
       mov      r8, rax
       movsxd   rdx, dword ptr [rbp-0x64]
       mov      rcx, gword ptr [rbp-0xF8]
       call     CORINFO_HELP_ARRADDR_ST
       jmp      SHORT G_M000_IG22
 
G_M000_IG19:                ;; offset=0x0359
       mov      rcx, gword ptr [rbp-0x50]
       mov      r8, bword ptr [rbp-0xF0]
       mov      edx, dword ptr [r8+0x0C]
 
G_M000_IG20:                ;; offset=0x0368
       vmovdqu  xmm0, xmmword ptr [rbp-0x60]
       vmovdqu  xmmword ptr [rbp-0x90], xmm0
 
G_M000_IG21:                ;; offset=0x0375
       mov      r8, gword ptr [r8]
       mov      gword ptr [rsp+0x20], r8
       lea      r8, [rbp-0x90]
       mov      r9, gword ptr [rbx+0xA0]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.PyTuple:SetPrivateDefault(int,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot,Lokad.Lython.Runtime.ExecutionState,Lokad.Lython.LythonSourceSpan):this]
 
G_M000_IG22:                ;; offset=0x0393
       inc      r12d
       mov      rax, gword ptr [rbp-0xE8]
       mov      rcx, gword ptr [rax+0x28]
       cmp      dword ptr [rcx+0x08], r12d
       jg       G_M000_IG06
 
G_M000_IG23:                ;; offset=0x03AB
       mov      edx, dword ptr [rsi]
       lea      ecx, [rdx+0x01]
       mov      dword ptr [rsi], ecx
       cmp      edx, dword ptr [rbp-0xDC]
       jae      G_M000_IG51
       mov      ecx, edx
       shl      rcx, 5
       lea      rsi, bword ptr [r13+rcx+0x10]
       mov      r14, gword ptr [rsi]
       mov      r15, gword ptr [rbx+0xA0]
       cmp      byte  ptr [r15], r15b
       mov      rcx, r15
       call     [Lokad.Lython.Runtime.ExecutionState:get_CanContinue():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG25
 
G_M000_IG24:                ;; offset=0x03E3
       mov      rcx, r15
       mov      rdx, r14
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
 
G_M000_IG25:                ;; offset=0x03EF
       mov      r14, gword ptr [rdi+0x30]
       mov      rcx, rsi
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ConstantIndex():int:this]
       cmp      eax, dword ptr [r14+0x08]
       jae      G_M000_IG51
       mov      r8d, eax
       mov      rdx, gword ptr [r14+8*r8+0x10]
       mov      r14, rdx
       test     r14, r14
       je       G_M000_IG38
 
G_M000_IG26:                ;; offset=0x041A
       mov      r8, 0x7FF9D7645060
       cmp      qword ptr [r14], r8
       jne      G_M000_IG38
 
G_M000_IG27:                ;; offset=0x042D
       mov      r8, gword ptr [r14+0x30]
       test     r8, r8
       je       SHORT G_M000_IG30
       mov      r9, gword ptr [rsi]
 
G_M000_IG28:                ;; offset=0x0439
       vmovdqu  xmm0, xmmword ptr [rbp-0x50]
       vmovdqu  xmmword ptr [rbp-0xA8], xmm0
       mov      rcx, qword ptr [rbp-0x40]
       mov      qword ptr [rbp-0x98], rcx
 
G_M000_IG29:                ;; offset=0x0451
       mov      gword ptr [rsp+0x20], r9
       lea      r9, [rbp-0xA8]
       mov      qword ptr [rsp+0x28], r9
       mov      r9, rbx
       mov      rcx, r14
       mov      rdx, rdi
       call     [Lokad.Lython.Runtime.LythonRuntime:CreateClosedEagerDefinition(Lokad.Lython.Frontend.ExecutableCreateFunction,Lokad.Lython.Frontend.ExecutableCodeObject,Lokad.Lython.Frontend.ExecutableInstruction[],Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.FunctionDefaults):Lokad.Lython.Runtime.PyFunctionBase]
       mov      rdi, rax
       jmp      G_M000_IG49
 
G_M000_IG30:                ;; offset=0x0479
       mov      rdi, gword ptr [r14+0x08]
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime:GetGlobalContext(Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):Lokad.Lython.Runtime.LythonRuntime+ExecutionContext]
       mov      r8, rax
       mov      rdx, gword ptr [rbp-0x50]
       mov      rcx, gword ptr [rbp-0x48]
       movzx    r9, byte  ptr [rbp-0x40]
       mov      rax, gword ptr [rsi]
       mov      r10, gword ptr [r14+0x28]
       mov      gword ptr [rbp-0xA8], rdx
       mov      gword ptr [rbp-0xA0], rcx
       mov      byte  ptr [rbp-0x98], r9b
       xor      edx, edx
       mov      dword ptr [rsp+0x28], edx
       mov      gword ptr [rsp+0x30], rbx
       mov      gword ptr [rsp+0x38], rax
 
G_M000_IG31:                ;; offset=0x04C2
       mov      bword ptr [rbp-0xB8], rdx
 
G_M000_IG32:                ;; offset=0x04C9
       mov      dword ptr [rbp-0xB0], edx
       mov      gword ptr [rsp+0x48], r10
 
G_M000_IG33:                ;; offset=0x04D4
       mov      gword ptr [rbp-0xC8], rdx
 
G_M000_IG34:                ;; offset=0x04DB
       mov      dword ptr [rbp-0xC0], edx
       mov      byte  ptr [rbp-0xBC], 0
 
G_M000_IG35:                ;; offset=0x04E8
       mov      dword ptr [rsp+0x58], edx
 
G_M000_IG36:                ;; offset=0x04EC
       mov      bword ptr [rbp-0xD8], rdx
 
G_M000_IG37:                ;; offset=0x04F3
       mov      dword ptr [rbp-0xD0], edx
       lea      rdx, [rbp-0xC8]
       mov      qword ptr [rsp+0x50], rdx
       lea      rdx, [rbp-0xA8]
       mov      qword ptr [rsp+0x20], rdx
       lea      rdx, [rbp-0xD8]
       mov      qword ptr [rsp+0x60], rdx
       lea      rdx, [rbp-0xB8]
       mov      qword ptr [rsp+0x40], rdx
       mov      rdx, rdi
       mov      rcx, gword ptr [rbp-0xE8]
       xor      r9, r9
       call     [Lokad.Lython.Runtime.LythonRuntime:CreateFunctionValue(Lokad.Lython.Frontend.FunctionParameterLayout,Lokad.Lython.Frontend.ExecutableCodeObject,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutableCaptures,Lokad.Lython.Runtime.FunctionDefaults,bool,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],Lokad.Lython.Runtime.Text.PyString[],System.ValueTuple`3[System.Object,int,bool],bool,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):Lokad.Lython.Runtime.PyFunctionBase]
       mov      rdi, rax
       jmp      G_M000_IG49
 
G_M000_IG38:                ;; offset=0x0544
       mov      rcx, r14
       test     rcx, rcx
       je       SHORT G_M000_IG40
 
G_M000_IG39:                ;; offset=0x054C
       mov      rax, 0x7FF9D76665B8
       cmp      qword ptr [rcx], rax
       jne      G_M000_IG50
 
G_M000_IG40:                ;; offset=0x055F
       mov      rdi, gword ptr [rcx+0x08]
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime:GetGlobalContext(Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):Lokad.Lython.Runtime.LythonRuntime+ExecutionContext]
       mov      r8, rax
       mov      rdx, gword ptr [rbp-0x50]
       mov      rcx, gword ptr [rbp-0x48]
       movzx    r9, byte  ptr [rbp-0x40]
       mov      rax, gword ptr [rsi]
       mov      gword ptr [rbp-0xA8], rdx
       mov      gword ptr [rbp-0xA0], rcx
       mov      byte  ptr [rbp-0x98], r9b
       xor      edx, edx
       mov      dword ptr [rsp+0x28], edx
       mov      gword ptr [rsp+0x30], rbx
       mov      gword ptr [rsp+0x38], rax
 
G_M000_IG41:                ;; offset=0x05A4
       mov      bword ptr [rbp-0xB8], rdx
 
G_M000_IG42:                ;; offset=0x05AB
       mov      dword ptr [rbp-0xB0], edx
 
G_M000_IG43:                ;; offset=0x05B1
       mov      gword ptr [rsp+0x48], rdx
 
G_M000_IG44:                ;; offset=0x05B6
       mov      gword ptr [rbp-0xC8], rdx
 
G_M000_IG45:                ;; offset=0x05BD
       mov      dword ptr [rbp-0xC0], edx
       mov      byte  ptr [rbp-0xBC], 0
 
G_M000_IG46:                ;; offset=0x05CA
       mov      dword ptr [rsp+0x58], edx
 
G_M000_IG47:                ;; offset=0x05CE
       mov      bword ptr [rbp-0xD8], rdx
 
G_M000_IG48:                ;; offset=0x05D5
       mov      dword ptr [rbp-0xD0], edx
       lea      rdx, [rbp-0xD8]
       mov      qword ptr [rsp+0x60], rdx
       lea      rdx, [rbp-0xA8]
       mov      qword ptr [rsp+0x20], rdx
       lea      rdx, [rbp-0xC8]
       mov      qword ptr [rsp+0x50], rdx
       lea      rdx, [rbp-0xB8]
       mov      qword ptr [rsp+0x40], rdx
       mov      rdx, rdi
       mov      rcx, gword ptr [rbp-0xE8]
       xor      r9, r9
       call     [Lokad.Lython.Runtime.LythonRuntime:CreateFunctionValue(Lokad.Lython.Frontend.FunctionParameterLayout,Lokad.Lython.Frontend.ExecutableCodeObject,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutableCaptures,Lokad.Lython.Runtime.FunctionDefaults,bool,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],Lokad.Lython.Runtime.Text.PyString[],System.ValueTuple`3[System.Object,int,bool],bool,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):Lokad.Lython.Runtime.PyFunctionBase]
       mov      rdi, rax
 
G_M000_IG49:                ;; offset=0x0621
       vxorps   xmm0, xmm0, xmm0
       vmovdqu  xmmword ptr [rbp-0x50], xmm0
       vmovdqu  xmmword ptr [rbp-0x48], xmm0
       jmp      SHORT G_M000_IG52
 
G_M000_IG50:                ;; offset=0x0631
       mov      rdx, r14
       mov      rcx, rax
       call     CORINFO_HELP_CHKCASTCLASS
       int3     
 
G_M000_IG51:                ;; offset=0x063D
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG52:                ;; offset=0x0643
       mov      rdx, gword ptr [rbx+0xA0]
       mov      rdx, gword ptr [rdx+0x88]
       lea      rcx, [rbp-0x50]
       call     [Lokad.Lython.Runtime.FunctionDefaults:RefundUnpublished(Lokad.Lython.Runtime.MemoryGovernor):this]
       mov      rax, rdi
 
G_M000_IG53:                ;; offset=0x065E
       add      rsp, 344
       pop      rbx
       pop      rsi
       pop      rdi
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG54:                ;; offset=0x0672
       call     CORINFO_HELP_CHKCASTCLASS
       int3     
 
G_M000_IG55:                ;; offset=0x0678
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG56:                ;; offset=0x067E
       sub      rsp, 104
 
G_M000_IG57:                ;; offset=0x0682
       mov      rbx, gword ptr [rbp+0x18]
       mov      rdx, gword ptr [rbx+0xA0]
       mov      rdx, gword ptr [rdx+0x88]
       lea      rcx, [rbp-0x50]
       call     [Lokad.Lython.Runtime.FunctionDefaults:RefundUnpublished(Lokad.Lython.Runtime.MemoryGovernor):this]
       nop      
 
G_M000_IG58:                ;; offset=0x069F
       add      rsp, 104
       ret      
 
; Total bytes of code 1700

; Assembly listing for method Lokad.Lython.Runtime.LythonRuntime:EvaluateClosedDefault(Lokad.Lython.Frontend.ExecutableCodeObject,long,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,System.Object,byref):Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot (FullOpts)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; FullOpts code
; optimized code
; rsp based frame
; partially interruptible
; No PGO data
; 1 inlinees with PGO data; 29 single block inlinees; 9 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     r15
       push     r14
       push     r13
       push     r12
       push     rdi
       push     rsi
       push     rbp
       push     rbx
       sub      rsp, 168
       vxorps   xmm4, xmm4, xmm4
       vmovdqu  ymmword ptr [rsp+0x30], ymm4
       vmovdqu  ymmword ptr [rsp+0x50], ymm4
       vmovdqu  ymmword ptr [rsp+0x70], ymm4
       vmovdqa  xmmword ptr [rsp+0x90], xmm4
       xor      eax, eax
       mov      qword ptr [rsp+0xA0], rax
       mov      rdi, rcx
       mov      rbx, r9
       mov      rsi, bword ptr [rsp+0x118]
 
G_M000_IG02:                ;; offset=0x004A
       mov      qword ptr [rsp+0xA0], r8
       mov      gword ptr [rsp+0x98], rdx
       mov      rcx, gword ptr [rsp+0x98]
       mov      rcx, gword ptr [rcx+0x98]
       mov      eax, dword ptr [rsi]
       cmp      eax, dword ptr [rcx+0x08]
       jae      G_M000_IG45
       shl      rax, 5
       lea      rbp, bword ptr [rcx+rax+0x10]
       cmp      dword ptr [rbp+0x1C], 46
       jne      G_M000_IG39
 
G_M000_IG03:                ;; offset=0x0087
       vxorps   xmm0, xmm0, xmm0
       vmovdqu  xmmword ptr [rsp+0x88], xmm0
       jmp      G_M000_IG25
 
G_M000_IG04:                ;; offset=0x0099
       mov      r14d, dword ptr [rbp+0x08]
       and      r14d, 0x7FFFFFFF
 
G_M000_IG05:                ;; offset=0x00A4
       mov      ecx, dword ptr [rbp+0x10]
       lea      rdx, [rsp+0x88]
       lea      r8, [rsp+0x80]
       lea      r9, [rsp+0x98]
       call     [Lokad.Lython.Runtime.LythonRuntime:<EvaluateClosedDefault>g__TryReadInteger|822_0(int,byref,byref,byref):bool]
       test     eax, eax
       je       SHORT G_M000_IG07
 
G_M000_IG06:                ;; offset=0x00C9
       mov      ecx, dword ptr [rbp+0x0C]
       lea      rdx, [rsp+0x88]
       lea      r8, [rsp+0x78]
       lea      r9, [rsp+0x98]
       call     [Lokad.Lython.Runtime.LythonRuntime:<EvaluateClosedDefault>g__TryReadInteger|822_0(int,byref,byref,byref):bool]
       test     eax, eax
       je       SHORT G_M000_IG07
       lea      r9, [rsp+0x70]
       mov      ecx, r14d
       mov      rdx, qword ptr [rsp+0x80]
       mov      r8, qword ptr [rsp+0x78]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryMachineBinary(int,long,long,byref):bool]
       test     eax, eax
       jne      G_M000_IG37
       lea      ecx, [r14-0x0F]
       cmp      ecx, 5
       jbe      G_M000_IG29
 
G_M000_IG07:                ;; offset=0x011B
       mov      r15d, dword ptr [rbp+0x10]
 
G_M000_IG08:                ;; offset=0x011F
       vmovdqu  xmm0, xmmword ptr [rsp+0x88]
       vmovdqu  xmmword ptr [rsp+0x60], xmm0
 
G_M000_IG09:                ;; offset=0x012E
       test     r15d, r15d
       jne      SHORT G_M000_IG10
       mov      rcx, 0x7FF9D752FD50
       call     CORINFO_HELP_NEWSFAST
       mov      r13, rax
       mov      rdx, qword ptr [rsp+0xA0]
       vxorps   xmm0, xmm0, xmm0
       vmovdqu  xmmword ptr [rsp+0x50], xmm0
       lea      rcx, [rsp+0x50]
       call     [System.Numerics.BigInteger:.ctor(long):this]
       lea      rcx, bword ptr [r13+0x08]
       mov      rdx, gword ptr [rsp+0x50]
       call     CORINFO_HELP_ASSIGN_REF
       mov      ecx, dword ptr [rsp+0x58]
       mov      dword ptr [r13+0x10], ecx
       jmp      G_M000_IG15
 
G_M000_IG10:                ;; offset=0x017D
       test     r15d, r15d
       jge      SHORT G_M000_IG11
       mov      rcx, gword ptr [rsp+0x98]
       mov      rcx, gword ptr [rcx+0x30]
       mov      eax, r15d
       not      eax
       cmp      eax, dword ptr [rcx+0x08]
       jae      G_M000_IG45
       mov      eax, r15d
       not      eax
       mov      r13, gword ptr [rcx+8*rax+0x10]
       jmp      G_M000_IG15
 
G_M000_IG11:                ;; offset=0x01AB
       mov      rcx, gword ptr [rsp+0x60]
       mov      rax, 0x143D6801CF0
       cmp      rcx, gword ptr [rax]
       je       SHORT G_M000_IG14
       mov      rcx, gword ptr [rsp+0x60]
       mov      rax, 0x143D6801CF8
       cmp      rcx, gword ptr [rax]
       je       SHORT G_M000_IG13
       cmp      qword ptr [rsp+0x68], 0
       jne      SHORT G_M000_IG12
       mov      r13, gword ptr [rsp+0x60]
       jmp      SHORT G_M000_IG15
 
G_M000_IG12:                ;; offset=0x01E2
       lea      rcx, [rsp+0x60]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishDeferredValue():System.Object:this]
       mov      r13, rax
       jmp      SHORT G_M000_IG15
 
G_M000_IG13:                ;; offset=0x01F2
       mov      rcx, 0x7FF9D7186488
       call     CORINFO_HELP_NEWSFAST
       vmovsd   xmm0, qword ptr [rsp+0x68]
       vmovsd   qword ptr [rax+0x08], xmm0
       mov      r13, rax
       mov      gword ptr [rsp+0x60], r13
       xor      ecx, ecx
       mov      qword ptr [rsp+0x68], rcx
       jmp      SHORT G_M000_IG15
 
G_M000_IG14:                ;; offset=0x021D
       lea      rcx, [rsp+0x60]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishInteger():System.Object:this]
       mov      r13, rax
 
G_M000_IG15:                ;; offset=0x022B
       mov      r15d, dword ptr [rbp+0x0C]
 
G_M000_IG16:                ;; offset=0x022F
       vmovdqu  xmm0, xmmword ptr [rsp+0x88]
       vmovdqu  xmmword ptr [rsp+0x40], xmm0
 
G_M000_IG17:                ;; offset=0x023E
       test     r15d, r15d
       jne      SHORT G_M000_IG18
       mov      rcx, 0x7FF9D752FD50
       call     CORINFO_HELP_NEWSFAST
       mov      r12, rax
       mov      rdx, qword ptr [rsp+0xA0]
       vxorps   xmm0, xmm0, xmm0
       vmovdqu  xmmword ptr [rsp+0x30], xmm0
       lea      rcx, [rsp+0x30]
       call     [System.Numerics.BigInteger:.ctor(long):this]
       lea      rcx, bword ptr [r12+0x08]
       mov      rdx, gword ptr [rsp+0x30]
       call     CORINFO_HELP_ASSIGN_REF
       mov      ecx, dword ptr [rsp+0x38]
       mov      dword ptr [r12+0x10], ecx
       mov      r8, r12
       jmp      G_M000_IG23
 
G_M000_IG18:                ;; offset=0x0292
       test     r15d, r15d
       jge      SHORT G_M000_IG19
       mov      r8, gword ptr [rsp+0x98]
       mov      rcx, gword ptr [r8+0x30]
       mov      eax, r15d
       not      eax
       cmp      eax, dword ptr [rcx+0x08]
       jae      G_M000_IG45
       mov      eax, r15d
       not      eax
       mov      r8, gword ptr [rcx+8*rax+0x10]
       jmp      G_M000_IG23
 
G_M000_IG19:                ;; offset=0x02C0
       mov      rcx, gword ptr [rsp+0x40]
       mov      rax, 0x143D6801CF0
       cmp      rcx, gword ptr [rax]
       je       SHORT G_M000_IG22
       mov      rcx, gword ptr [rsp+0x40]
       mov      rax, 0x143D6801CF8
       cmp      rcx, gword ptr [rax]
       je       SHORT G_M000_IG21
       cmp      qword ptr [rsp+0x48], 0
       jne      SHORT G_M000_IG20
       mov      r8, gword ptr [rsp+0x40]
       jmp      SHORT G_M000_IG23
 
G_M000_IG20:                ;; offset=0x02F7
       lea      rcx, [rsp+0x40]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishDeferredValue():System.Object:this]
       mov      r8, rax
       jmp      SHORT G_M000_IG23
 
G_M000_IG21:                ;; offset=0x0307
       mov      rcx, 0x7FF9D7186488
       call     CORINFO_HELP_NEWSFAST
       vmovsd   xmm0, qword ptr [rsp+0x48]
       vmovsd   qword ptr [rax+0x08], xmm0
       mov      r8, rax
       mov      gword ptr [rsp+0x40], r8
       xor      ecx, ecx
       mov      qword ptr [rsp+0x48], rcx
       jmp      SHORT G_M000_IG23
 
G_M000_IG22:                ;; offset=0x0332
       lea      rcx, [rsp+0x40]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishInteger():System.Object:this]
       mov      r8, rax
 
G_M000_IG23:                ;; offset=0x0340
       mov      rcx, gword ptr [rbp]
       mov      gword ptr [rsp+0x20], rcx
       mov      ecx, r14d
       mov      rdx, r13
       mov      r9, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime:EvaluateBinaryOperator(int,System.Object,System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):System.Object]
       mov      gword ptr [rsp+0x88], rax
 
G_M000_IG24:                ;; offset=0x0360
       xor      ecx, ecx
       mov      qword ptr [rsp+0x90], rcx
 
G_M000_IG25:                ;; offset=0x036A
       mov      rcx, gword ptr [rsp+0x98]
       mov      rcx, gword ptr [rcx+0x98]
       mov      eax, dword ptr [rsi]
       mov      edx, eax
       cmp      edx, dword ptr [rcx+0x08]
       jae      G_M000_IG45
       shl      rdx, 5
       lea      rbp, bword ptr [rcx+rdx+0x10]
       cmp      dword ptr [rbp+0x1C], 46
       jne      G_M000_IG38
       inc      eax
       mov      dword ptr [rsi], eax
       mov      r14, gword ptr [rbp]
       mov      r15, gword ptr [rbx+0xA0]
       cmp      byte  ptr [r15], r15b
       mov      rcx, r15
       call     [Lokad.Lython.Runtime.ExecutionState:get_CanContinue():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG27
 
G_M000_IG26:                ;; offset=0x03B8
       mov      rcx, r15
       mov      rdx, r14
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
 
G_M000_IG27:                ;; offset=0x03C4
       cmp      dword ptr [rbp+0x1C], 51
       jne      G_M000_IG04
 
G_M000_IG28:                ;; offset=0x03CE
       mov      r14d, dword ptr [rbp+0x14]
       jmp      G_M000_IG05
 
G_M000_IG29:                ;; offset=0x03D7
       mov      rcx, qword ptr [rsp+0x78]
       cmp      qword ptr [rsp+0x80], rcx
       jge      SHORT G_M000_IG32
 
G_M000_IG30:                ;; offset=0x03E6
       mov      edx, -1
 
G_M000_IG31:                ;; offset=0x03EB
       mov      ecx, r14d
       call     [Lokad.Lython.Runtime.LythonRuntime:CompareOrderedResult(int,int):bool]
       test     eax, eax
       jne      SHORT G_M000_IG35
       mov      rcx, 0x143D68013C8
       mov      rcx, gword ptr [rcx]
       jmp      SHORT G_M000_IG36
 
G_M000_IG32:                ;; offset=0x0407
       cmp      qword ptr [rsp+0x80], rcx
       jle      SHORT G_M000_IG34
 
G_M000_IG33:                ;; offset=0x0411
       mov      edx, 1
       jmp      SHORT G_M000_IG31
 
G_M000_IG34:                ;; offset=0x0418
       xor      edx, edx
       jmp      SHORT G_M000_IG31
 
G_M000_IG35:                ;; offset=0x041C
       mov      rcx, 0x143D68013C0
       mov      rcx, gword ptr [rcx]
 
G_M000_IG36:                ;; offset=0x0429
       mov      gword ptr [rsp+0x88], rcx
       jmp      G_M000_IG24
 
G_M000_IG37:                ;; offset=0x0436
       mov      rcx, qword ptr [rsp+0x70]
       mov      rax, 0x143D6801CF0
       mov      rax, gword ptr [rax]
       mov      gword ptr [rsp+0x88], rax
       mov      qword ptr [rsp+0x90], rcx
       jmp      G_M000_IG25
 
G_M000_IG38:                ;; offset=0x045D
       mov      rcx, gword ptr [rsp+0x88]
       mov      gword ptr [rdi], rcx
       mov      rcx, qword ptr [rsp+0x90]
       mov      qword ptr [rdi+0x08], rcx
       jmp      SHORT G_M000_IG43
 
G_M000_IG39:                ;; offset=0x0476
       inc      dword ptr [rsi]
       mov      rsi, gword ptr [rbp]
       mov      rbx, gword ptr [rbx+0xA0]
       cmp      byte  ptr [rbx], bl
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.ExecutionState:get_CanContinue():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG40
       mov      rcx, rbx
       mov      rdx, rsi
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
 
G_M000_IG40:                ;; offset=0x049E
       cmp      dword ptr [rbp+0x1C], 1
       jne      SHORT G_M000_IG41
       mov      rcx, gword ptr [rsp+0x98]
       mov      rbx, gword ptr [rcx+0x30]
       mov      rcx, rbp
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ConstantIndex():int:this]
       cmp      eax, dword ptr [rbx+0x08]
       jae      SHORT G_M000_IG45
       mov      ecx, eax
       mov      rdx, gword ptr [rbx+8*rcx+0x10]
       jmp      SHORT G_M000_IG42
 
G_M000_IG41:                ;; offset=0x04C7
       mov      rbx, gword ptr [rsp+0x110]
       mov      rdx, rbx
 
G_M000_IG42:                ;; offset=0x04D2
       mov      rcx, rdi
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       xor      eax, eax
       mov      qword ptr [rdi+0x08], rax
 
G_M000_IG43:                ;; offset=0x04E0
       mov      rax, rdi
 
G_M000_IG44:                ;; offset=0x04E3
       add      rsp, 168
       pop      rbx
       pop      rbp
       pop      rsi
       pop      rdi
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       ret      
 
G_M000_IG45:                ;; offset=0x04F7
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
; Total bytes of code 1277

