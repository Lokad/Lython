from pathlib import Path
import hashlib
import json
import os
import shutil
import subprocess

lab=Path(__file__).resolve().parent
root=lab.parents[3]
tree=root/'.git/agent-worktrees/closed-factory-pairs-20261124'
donor=lab.with_name('decoded-closed-defaults-20261124')
comparison=lab/'comparison'
comparison.mkdir(exist_ok=True)
read=lambda path:json.loads(path.read_text(encoding='utf-8-sig'))
sha=lambda path:hashlib.sha256(path.read_bytes()).hexdigest()
save=lambda path,data:path.write_text(json.dumps(data,indent=2,ensure_ascii=False)+'\n',encoding='utf-8',newline='\n')
git=lambda repo,*args:subprocess.check_output(['git',*args],cwd=repo,text=True).strip()
old=read(donor/'comparison/identity.json')
reference=git(root,'rev-parse','04f87924c')
candidate=git(tree,'rev-parse','HEAD')
assert git(tree,'rev-parse','HEAD^')==reference
assert not git(tree,'status','--porcelain','--','src','tests')
assert git(root,'rev-parse','HEAD')==reference and not git(root,'status','--porcelain','--','src','tests')
shutil.copyfile(donor/'comparison/representative.json',comparison/'representative.json')
catalog=comparison/'representative.json'
assert sha(catalog)==old['catalogs']['representative.json']['sha256']
defaulted='scripts.rule-default-closures'
case_ids=[case['id'] for case in read(catalog)['cases']]
assert len(case_ids)==6 and defaulted in case_ids
jobs=[(case,'warm') for case in case_ids]+[(defaulted,'compile-run')]
save(comparison/'jobs.json',{'warm':jobs})
protocol=root/'benchmarks/cpython-worker.py'
assert sha(protocol)==old['cpythonWorkerSHA256']
dotnet=Path.home()/'.dotnet11/dotnet.exe'
env=dict(os.environ,DOTNET_ROOT=str(dotnet.parent),DOTNET_ROOT_X64=str(dotnet.parent))
files=old['imageFiles']['candidate']
helpers=old['helperFiles']
assert len(files)==32
assert all(sha(donor/'candidate'/name)==expected for name,expected in (files|helpers).items())
images={}
for role in ('reference','candidate'):
    image=lab/role
    image.mkdir(exist_ok=True)
    for name in (files|helpers):
        src=lab/('frozen-'+role)/'bin/Lokad.Lython/release_net11.0'/name if name=='Lokad.Lython.dll' else donor/'candidate'/name
        shutil.copyfile(src,image/name)
    observed={name:sha(image/name) for name in files}
    receipt=comparison/(role+'-verify.json')
    subprocess.run([dotnet,image/'Lokad.Lython.Benchmarks.dll','--compare','verify','--catalog',catalog,
         '--dotnet',dotnet,'--python','C:/Python313/python.exe','--python-worker',protocol,'--out',receipt],
         env=env,check=True,timeout=100)
    check=read(receipt)
    assert check['state']=='Completed' and check['caseCount']==6 and check['launched']['library']['sha256']==observed['Lokad.Lython.dll']
    assert {p.name:sha(p) for p in image.iterdir()}==observed|helpers
    images[role]=observed
assert [name for name,value in images['reference'].items() if images['candidate'][name]!=value]==['Lokad.Lython.dll']
save(comparison/'identity.json',dict(sourceRevision=reference,candidate=candidate,purpose='Complete closed callable pairs in the caller-owned unpack window',
    imageFiles=images,helperFiles=helpers,cpythonWorkerSHA256=old['cpythonWorkerSHA256'],expectedCPythonSHA256=old['expectedCPythonSHA256'],
    catalogs={name:dict(sha256=sha(comparison/name)) for name in ('representative.json','jobs.json')},
    coreSHA256={role+suffix:files['Lokad.Lython.dll'] for role,files in images.items() for suffix in ('','-control')}))
shutil.copyfile(donor/'allocations.py',lab/'allocations.py')
print('Verified six complete scripts against the two frozen images')
