from pathlib import Path
import hashlib
import json
import os
import re
import subprocess

lab=Path(__file__).resolve().parent
identity=json.loads((lab/'comparison/identity.json').read_text(encoding='utf-8'))
sha=lambda path:hashlib.sha256(path.read_bytes()).hexdigest()
sdk=Path.home()/'.dotnet11'
rows={}
for role,files in identity['imageFiles'].items():
    image=lab/role
    expected=files|identity['helperFiles']
    assert {p.name:sha(p) for p in image.iterdir()}==expected
    trace=lab/(role+'-native.asm')
    observation=lab/(role+'-jit-checks.json')
    env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk),DOTNET_TieredCompilation='0',
        DOTNET_JitDisasm='StartNativeCall StartNativeWorkspace StartNativeFixedReturn TryExecuteNativeCall TryReturnDefinition TryReturnDefinitionPair CreateClosedComputedDefinition CreateClosedPairMember CompleteClosedDefinitionPair EvaluateClosedDefault',
        DOTNET_JitStdOutFile=str(trace))
    subprocess.run([sdk/'dotnet.exe',image/'ValidatedAllocation.dll',image,lab/'comparison/representative.json',observation],
        env=env,timeout=60,check=True)
    assert all(row['sharedBudgetBaselineRestored'] for row in json.loads(observation.read_text(encoding='utf-8-sig'))['rows'])
    methods={}
    for part in trace.read_text(encoding='utf-8-sig').split('; Assembly listing for method ')[1:]:
        signature,asm=part.split('\n',1)
        if 'Lokad.Lython.Runtime.' not in signature:continue
        method=signature.split(':',1)[-1].split('(',1)[0]
        frame=re.search(r'\bsub\s+rsp,\s*(\d+)\b',asm)
        size=re.search(r'Total bytes of code (\d+)',asm)
        methods[method]=dict(stackBytes=int(frame[1]) if frame else None,nativeBytes=int(size[1]))
    assert {'StartNativeCall','TryReturnDefinition','CreateClosedComputedDefinition'} <= set(methods)
    rows[role]=dict(methods=methods,coreSha=files['Lokad.Lython.dll'])
    print(role,methods)
(lab/'jit-summary.json').write_text(json.dumps(rows,indent=2)+'\n',encoding='utf-8',newline='\n')

