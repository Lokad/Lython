from pathlib import Path
import ast
import gzip
import hashlib
import json
import shutil
import subprocess
import tarfile

lab=Path(__file__).resolve().parent
root=lab.parents[3]
donor=lab.with_name('decoded-closed-defaults-20261124')
template=lab.with_name('closed-default-evaluation-20261124')
comparison=lab/'comparison'
quiet=comparison/'quiet'
quiet.mkdir(exist_ok=True)
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda payload:hashlib.sha256(payload).hexdigest()
write=lambda p,s:p.write_text(s,encoding='utf-8',newline='\n')
save=lambda p,data:write(p,json.dumps(data,indent=2)+'\n')
git=lambda path:subprocess.check_output(['git','show','origin/master:benchmarks/results/2026-11-24-'+path],cwd=root)

def retired(artifact,aliases):
    core=sha(gzip.decompress(git(artifact+'/candidate-core.dll.gz')))
    paths=[]
    for record,folder,role in aliases:
        meta=json.loads(git(record+'/identity.json'))
        assert core==meta['coreSHA256'][role]
        previous=json.loads(git(record+'/terminal-status.json'))
        receipt=previous['receipt']
        assert not previous['live'] and not previous['fixtures'] and previous['exitCode']=='0'
        assert all(receipt[k] for k in ('complete','allWorkersJoined','guestFixturesRemoved','archivedAndVerifiedUnderLease'))
        assert sha(git(record+'/observations.tar.xz'))==receipt['archiveSHA256']
        paths.append(dict(path=folder+'/'+role+'/Lokad.Lython.dll',observationSHA256=receipt['archiveSHA256'],source=record))
    return dict(sha256=core,coreArchive=artifact+'/candidate-core.dll.gz',aliases=paths)

replicas=[retired('closed-factory-pairs/refinement', [('closed-factory-pairs/refinement','closed-factory-pairs-refined-b1595-20261124','candidate')])]
save(lab/'verified-replicas.json',replicas)
identity=read(comparison/'identity.json')
old=read(donor/'comparison/identity.json')
for role, hashes in identity['imageFiles'].items():
    assert len(hashes)==32 and all(sha((lab/role/name).read_bytes())==digest for name,digest in hashes.items())
    assert {n:v for n,v in hashes.items() if n!='Lokad.Lython.dll'}=={n:v for n,v in old['imageFiles']['candidate'].items() if n!='Lokad.Lython.dll'}
    check=read(comparison/(role+'-verify.json'))
    assert check['state']=='Completed' and check['caseCount']==6
for name,meta in identity['catalogs'].items():
    assert sha((comparison/name).read_bytes())==meta['sha256']
collector=(template/'comparison/quiet/collect.py').read_text(encoding='utf-8').replace('b1590-','b1596-').replace('len(jobs) == 6','len(jobs) == 7').replace('started < 315','started < 382')
compile(collector,'collect.py','exec')
write(quiet/'collect.py',collector)
shutil.copyfile(template/'comparison/quiet/run.sh',quiet/'run.sh')
assert b'\r' not in (quiet/'run.sh').read_bytes()
payload=quiet/'payload.tar.gz'
with tarfile.open(payload,'w:gz') as package:
    for member in ('identity.json','representative.json','jobs.json'):
        package.add(comparison/member,arcname=member)
    for member in ('run.sh','collect.py'):
        package.add(quiet/member,arcname=member)
    package.add(lab/'candidate/Lokad.Lython.dll',arcname='candidate-core.dll')
save(quiet/'upload.json',dict(root='closed-factory-pairs-entry-b1596-20261124',reference='closed-factory-pairs-refined-b1595-20261124',
    payloadSHA256=sha(payload.read_bytes()),payloadBytes=payload.stat().st_size))
launcher=(template/'quiet.py').read_text(encoding='utf-8').replace('b1590-closed-default-evaluation','b1596-closed-factory-pairs-entry').replace('b1590-','b1596-')
allowed=[entry['path'] for group in replicas for entry in group['aliases']]
launcher=launcher.replace("assert archive==base/'captured-local-reads-b1589-20261124' and replica==archive/'candidate/Lokad.Lython.dll'",
                          'assert replica.relative_to(base).as_posix() in '+repr(allowed))
launcher=launcher.replace("os.link(reference/'candidate'/name,image/name)","os.link(reference/'reference'/name,image/name)")
launcher=launcher.replace('RuntimeMaxSec=411','RuntimeMaxSec=460').replace('seconds=336','seconds=405')
remote,=(n.value for n in ast.walk(ast.parse(launcher)) if isinstance(n,ast.Constant) and isinstance(n.value,str) and n.value.startswith('digest=lambda path:'))
compile(remote,'remote-stage','exec')
assert "reference/'reference'/name" in remote and 'captured-local-reads-b1589' not in remote
write(lab/'quiet.py',launcher)
summary=(template/'summarize.py').read_text(encoding='utf-8').replace('receipt["warmJobs"] == 6','receipt["warmJobs"] == 7').replace('len(warm["jobs"])==6','len(warm["jobs"])==7').replace('timedBatches=168','timedBatches=196')
compile(summary,'summarize.py','exec')
write(lab/'summarize.py',summary)
print('Prepared seven short lanes and',payload.stat().st_size,'bytes of frozen payload')
