; Assembly listing for method Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteNativeCall(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Frontend.ExecutableCallSite,int,System.Object,byref):bool (FullOpts)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; FullOpts code
; optimized code
; rbp based frame
; fully interruptible
; No PGO data
; 0 inlinees with PGO data; 103 single block inlinees; 34 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       push     r15
       push     r14
       push     r13
       push     r12
       push     rdi
       push     rsi
       push     rbx
       sub      rsp, 328
       lea      rbp, [rsp+0x180]
       xor      eax, eax
       mov      qword ptr [rbp-0x118], rax
       vxorps   xmm4, xmm4, xmm4
       vmovdqa  xmmword ptr [rbp-0x110], xmm4
       mov      rax, -192
 
G_M000_IG135:                ;; offset=0x003A
       vmovdqa  xmmword ptr [rbp+rax-0x40], xmm4
       vmovdqa  xmmword ptr [rbp+rax-0x30], xmm4
       vmovdqa  xmmword ptr [rbp+rax-0x20], xmm4
       add      rax, 48
       jne      SHORT G_M000_IG135
       mov      qword ptr [rbp-0x40], rax
       mov      bword ptr [rbp+0x10], rcx
       mov      gword ptr [rbp+0x18], rdx
       mov      gword ptr [rbp+0x28], r9
       mov      rsi, r8
       mov      rbx, r9
       mov      eax, dword ptr [rbp+0x30]
       mov      rdi, gword ptr [rbp+0x38]
       mov      r14, bword ptr [rbp+0x40]
 
G_M000_IG02:                ;; offset=0x0073
       xor      r8, r8
       mov      gword ptr [r14], r8
       test     rdi, rdi
       je       SHORT G_M000_IG05
 
G_M000_IG03:                ;; offset=0x007E
       mov      r8, 0x7FF9D7766248
       cmp      qword ptr [rdi], r8
       jne      SHORT G_M000_IG05
 
G_M000_IG04:                ;; offset=0x008D
       mov      gword ptr [rbp-0x120], rdi
       jmp      SHORT G_M000_IG06
 
G_M000_IG05:                ;; offset=0x0096
       xor      r8, r8
       mov      gword ptr [rbp-0x120], r8
 
G_M000_IG06:                ;; offset=0x00A0
       cmp      byte  ptr [rbx+0x30], 0
       je       SHORT G_M000_IG09
 
G_M000_IG07:                ;; offset=0x00A6
       mov      r8, gword ptr [rcx+0x20]
       cmp      eax, dword ptr [r8+0x08]
       jae      G_M000_IG121
       mov      r10d, eax
       shl      r10, 4
       lea      rcx, bword ptr [r8+r10+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Object():System.Object:this]
       mov      rdx, rax
       mov      rcx, 0x7FF9D7767D70
       call     [Lokad.Lython.Internal.NullabilityExtensions:RequireNotNull[System.__Canon](System.__Canon):System.__Canon]
       test     rax, rax
       je       SHORT G_M000_IG10
 
G_M000_IG08:                ;; offset=0x00DE
       mov      rcx, 0x7FF9D7669028
       cmp      qword ptr [rax], rcx
       jne      SHORT G_M000_IG10
 
G_M000_IG09:                ;; offset=0x00ED
       mov      rcx, bword ptr [rbp+0x10]
       mov      eax, dword ptr [rbp+0x30]
       xor      r15, r15
       jmp      SHORT G_M000_IG11
 
G_M000_IG10:                ;; offset=0x00F9
       mov      rcx, bword ptr [rbp+0x10]
       mov      r8, gword ptr [rcx+0x20]
       mov      eax, dword ptr [rbp+0x30]
       cmp      eax, dword ptr [r8+0x08]
       jae      G_M000_IG121
       mov      r10d, eax
       shl      r10, 4
       lea      rcx, bword ptr [r8+r10+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Object():System.Object:this]
       mov      rdx, rax
       mov      rcx, 0x7FF9D7767D70
       call     [Lokad.Lython.Internal.NullabilityExtensions:RequireNotNull[System.__Canon](System.__Canon):System.__Canon]
       mov      r15, rax
 
G_M000_IG11:                ;; offset=0x0136
       test     rdi, rdi
       je       SHORT G_M000_IG16
 
G_M000_IG12:                ;; offset=0x013B
       mov      r8, 0x7FF9D77954B8
       cmp      qword ptr [rdi], r8
       jne      SHORT G_M000_IG16
 
G_M000_IG13:                ;; offset=0x014A
       mov      r8, gword ptr [rdi+0x10]
       test     r8, r8
       je       SHORT G_M000_IG16
 
G_M000_IG14:                ;; offset=0x0153
       mov      rdx, 0x7FF9D7766248
       cmp      qword ptr [r8], rdx
       jne      SHORT G_M000_IG16
 
G_M000_IG15:                ;; offset=0x0162
       mov      gword ptr [rbp-0x120], r8
       mov      r15, gword ptr [rdi+0x08]
 
G_M000_IG16:                ;; offset=0x016D
       cmp      gword ptr [rbp-0x120], 0
       je       SHORT G_M000_IG18
 
G_M000_IG17:                ;; offset=0x0177
       test     rsi, rsi
       jne      G_M000_IG82
 
G_M000_IG18:                ;; offset=0x0180
       cmp      byte  ptr [rbx+0x30], 0
       je       SHORT G_M000_IG19
       cmp      byte  ptr [rbx+0x34], 0
       jne      G_M000_IG32
 
G_M000_IG19:                ;; offset=0x0190
       mov      rcx, bword ptr [rbp+0x10]
       mov      r8, gword ptr [rcx+0x20]
       test     r8, r8
       je       SHORT G_M000_IG20
       lea      rdx, bword ptr [r8+0x10]
       mov      r8d, dword ptr [r8+0x08]
       jmp      SHORT G_M000_IG21
 
G_M000_IG20:                ;; offset=0x01A7
       xor      rdx, rdx
       xor      r8d, r8d
 
G_M000_IG21:                ;; offset=0x01AC
       mov      bword ptr [rbp-0xF8], rdx
       mov      dword ptr [rbp-0xF0], r8d
       mov      rdx, gword ptr [rbp+0x18]
       mov      gword ptr [rsp+0x20], rdx
       test     rsi, rsi
       setne    r8b
       movzx    r8, r8b
       mov      dword ptr [rsp+0x28], r8d
       lea      r8, [rbp-0xB8]
       mov      qword ptr [rsp+0x30], r8
       lea      r8, [rbp-0xF8]
       mov      rdx, rdi
       mov      rcx, rbx
       mov      r9d, dword ptr [rbp+0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryInvokeBuiltinFromSlots(Lokad.Lython.Frontend.ExecutableCallSite,System.Object,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,bool,byref):bool]
       test     eax, eax
       je       G_M000_IG30
       mov      rdx, gword ptr [rbp-0xB8]
       mov      rcx, 0x7FF9D74F6808
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       mov      rdi, rax
       test     rdi, rdi
       jne      G_M000_IG28
       mov      rcx, bword ptr [rbp+0x10]
       mov      r9, gword ptr [rcx]
       mov      r9, gword ptr [r9+0x98]
       mov      edx, dword ptr [rcx+0x10]
       cmp      edx, dword ptr [r9+0x08]
       jae      G_M000_IG31
       shl      rdx, 5
       lea      r8, bword ptr [r9+rdx+0x10]
       mov      rdi, gword ptr [rbp-0xB8]
       mov      r14, qword ptr [rbp-0xB0]
       mov      ebx, dword ptr [r8+0x18]
       test     ebx, ebx
       jge      SHORT G_M000_IG22
       mov      gword ptr [rbp-0x108], rdi
       mov      qword ptr [rbp-0x100], r14
       lea      r9, [rbp-0x108]
       mov      rdx, rsi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CompleteResultConsumer(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot)]
       jmp      SHORT G_M000_IG29
 
G_M000_IG22:                ;; offset=0x027A
       lea      rsi, bword ptr [rcx+0x20]
       mov      edx, dword ptr [r8+0x1C]
       cmp      edx, 51
       ja       SHORT G_M000_IG25
 
G_M000_IG23:                ;; offset=0x0287
       mov      rax, 0x7FFFFFFFFF9FF
       bt       rax, rdx
       jb       SHORT G_M000_IG25
 
G_M000_IG24:                ;; offset=0x0297
       mov      r15d, ebx
       jmp      SHORT G_M000_IG26
 
G_M000_IG25:                ;; offset=0x029C
       mov      r15d, dword ptr [r8+0x14]
 
G_M000_IG26:                ;; offset=0x02A0
       cmp      ebx, dword ptr [rsi+0x40]
       jge      SHORT G_M000_IG27
       mov      rcx, rsi
       mov      edx, ebx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
 
G_M000_IG27:                ;; offset=0x02B0
       mov      rdx, gword ptr [rsi]
       cmp      r15d, dword ptr [rdx+0x08]
       jae      SHORT G_M000_IG31
       mov      eax, r15d
       shl      rax, 4
       lea      r15, bword ptr [rdx+rax+0x10]
       mov      rcx, r15
       mov      rdx, rdi
       call     CORINFO_HELP_ASSIGN_REF
       mov      qword ptr [r15+0x08], r14
       mov      dword ptr [rsi+0x40], ebx
       jmp      SHORT G_M000_IG29
 
G_M000_IG28:                ;; offset=0x02D9
       mov      rcx, bword ptr [rbp+0x10]
       add      rcx, 32
       mov      edx, dword ptr [rbp+0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
       mov      rcx, r14
       mov      rdx, rdi
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
 
G_M000_IG29:                ;; offset=0x02F5
       mov      eax, 1
       jmp      G_M000_IG118
 
G_M000_IG30:                ;; offset=0x02FF
       xor      eax, eax
       jmp      G_M000_IG118
 
G_M000_IG31:                ;; offset=0x0306
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG32:                ;; offset=0x030C
       test     rdi, rdi
       je       G_M000_IG119
 
G_M000_IG33:                ;; offset=0x0315
       mov      rcx, 0x7FF9D77957B8
       cmp      qword ptr [rdi], rcx
       jne      G_M000_IG119
 
G_M000_IG34:                ;; offset=0x0328
       mov      r9, gword ptr [rbx+0x20]
       test     r9, r9
       je       SHORT G_M000_IG37
 
G_M000_IG35:                ;; offset=0x0331
       mov      rcx, 0x7FF9D7795AC0
       cmp      qword ptr [r9], rcx
       jne      SHORT G_M000_IG37
 
G_M000_IG36:                ;; offset=0x0340
       mov      gword ptr [rsp+0x20], rbx
       mov      eax, dword ptr [rbp+0x30]
       mov      dword ptr [rsp+0x28], eax
       mov      gword ptr [rsp+0x30], rdi
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rbp+0x18]
       mov      r8, rsi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteTrimmedSplit(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Frontend.ExecutableTrimmedSplit,Lokad.Lython.Frontend.ExecutableCallSite,int,System.Object):bool]
       test     eax, eax
       jne      G_M000_IG76
 
G_M000_IG37:                ;; offset=0x036A
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rcx]
       mov      r8, gword ptr [rcx+0x20]
       test     r8, r8
       je       SHORT G_M000_IG38
       lea      r9, bword ptr [r8+0x10]
       mov      r8d, dword ptr [r8+0x08]
       jmp      SHORT G_M000_IG39
 
G_M000_IG38:                ;; offset=0x0384
       xor      r9, r9
       xor      r8d, r8d
 
G_M000_IG39:                ;; offset=0x038A
       lea      rax, bword ptr [rcx+0x10]
       mov      r10, rsi
       test     r10, r10
       cmove    r10, gword ptr [rbp+0x18]
       mov      bword ptr [rbp-0x118], r9
       mov      dword ptr [rbp-0x110], r8d
       mov      gword ptr [rsp+0x20], rbx
       mov      r11d, dword ptr [rbp+0x30]
       mov      dword ptr [rsp+0x28], r11d
       mov      gword ptr [rsp+0x30], r10
       lea      r8, [rbp-0xA0]
       mov      qword ptr [rsp+0x38], r8
       lea      r8, [rbp-0x118]
       mov      rcx, rdi
       mov      r9, rax
       call     [Lokad.Lython.Runtime.LythonRuntime:TryConsumePrivateStringResult(Lokad.Lython.Runtime.LythonRuntime+ReceiverMethod,Lokad.Lython.Frontend.ExecutableCodeObject,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,Lokad.Lython.Frontend.ExecutableCallSite,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       test     eax, eax
       jne      G_M000_IG69
       mov      rcx, bword ptr [rbp+0x10]
       mov      rax, gword ptr [rcx+0x20]
       mov      r11d, dword ptr [rbp+0x30]
       cmp      r11d, dword ptr [rax+0x08]
       jae      G_M000_IG81
       mov      edx, r11d
       shl      rdx, 4
       lea      rcx, bword ptr [rax+rdx+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Object():System.Object:this]
       mov      rdx, rax
       mov      rcx, 0x7FF9D7767D70
       call     [Lokad.Lython.Internal.NullabilityExtensions:RequireNotNull[System.__Canon](System.__Canon):System.__Canon]
       mov      r14, rax
       mov      rcx, bword ptr [rbp+0x10]
       lea      rdx, bword ptr [rcx+0x20]
       cmp      byte  ptr [rbx+0x30], 0
       setne    al
       movzx    rax, al
       mov      r11d, dword ptr [rbp+0x30]
       lea      r15d, [r11+rax+0x01]
       mov      r13d, dword ptr [rbx+0x28]
       mov      rdx, gword ptr [rdx]
       test     rdx, rdx
       je       G_M000_IG77
       mov      eax, r15d
       mov      r8d, r13d
       add      rax, r8
       mov      r8d, dword ptr [rdx+0x08]
       cmp      rax, r8
       ja       G_M000_IG77
       mov      rax, rdx
       xor      r12, r12
       xor      r8d, r8d
       test     rax, rax
 
G_M000_IG40:                ;; offset=0x046C
       je       SHORT G_M000_IG43
       mov      rdx, qword ptr [rax]
       test     dword ptr [rdx], 0xFFFFFFFF80000000
       jne      SHORT G_M000_IG41
       lea      rdx, [rbp-0xE8]
       mov      rcx, rax
       mov      rax, qword ptr [rax]
       mov      rax, qword ptr [rax+0x40]
       call     [rax+0x28]System.Buffers.MemoryManager`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:GetSpan():System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:this
       mov      r8d, dword ptr [rbp-0xE0]
       mov      r12, bword ptr [rbp-0xE8]
       mov      eax, r8d
       jmp      SHORT G_M000_IG42
 
G_M000_IG41:                ;; offset=0x04A0
       lea      r12, bword ptr [rax+0x10]
       mov      eax, dword ptr [rax+0x08]
 
G_M000_IG42:                ;; offset=0x04A7
       and      r15d, 0x7FFFFFFF
       mov      edx, r15d
       mov      r8d, r13d
       add      r8, rdx
       mov      eax, eax
       cmp      r8, rax
       ja       G_M000_IG77
       shl      rdx, 4
       add      r12, rdx
       mov      dword ptr [rbp-0xD4], r13d
       mov      r8d, dword ptr [rbp-0xD4]
 
G_M000_IG43:                ;; offset=0x04D7
       cmp      dword ptr [rbx+0x2C], 0
       je       G_M000_IG47
       test     byte  ptr [(reloc 0x7ff9d7795e80)], 1
       je       G_M000_IG78
 
G_M000_IG44:                ;; offset=0x04EE
       mov      rdx, 0x26B2A801D90
       cmp      rdi, gword ptr [rdx]
       jne      SHORT G_M000_IG47
       test     r14, r14
       je       SHORT G_M000_IG47
 
G_M000_IG45:                ;; offset=0x0502
       mov      rdx, 0x7FF9D75BDAA0
       cmp      qword ptr [r14], rdx
       jne      SHORT G_M000_IG47
 
G_M000_IG46:                ;; offset=0x0511
       cmp      r8d, 2
       jg       SHORT G_M000_IG47
       mov      r11d, dword ptr [rbp+0x30]
       mov      dword ptr [rsp+0x20], r11d
       mov      gword ptr [rsp+0x28], r14
       mov      bword ptr [rbp-0x118], r12
       mov      dword ptr [rbp-0xD4], r8d
       mov      dword ptr [rbp-0x110], r8d
       lea      rdx, [rbp-0x118]
       mov      qword ptr [rsp+0x30], rdx
       mov      rdx, rsi
       mov      r8, gword ptr [rbp+0x18]
       mov      r9, rbx
       mov      rcx, bword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteSplitUnpack(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Frontend.ExecutableCallSite,int,Lokad.Lython.Runtime.Text.PyString,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):bool]
       test     eax, eax
       mov      r8d, dword ptr [rbp-0xD4]
       jne      G_M000_IG76
 
G_M000_IG47:                ;; offset=0x0569
       cmp      byte  ptr [rbx+0x33], 0
       jne      SHORT G_M000_IG49
 
G_M000_IG48:                ;; offset=0x056F
       mov      dword ptr [rbp-0xD4], r8d
       jmp      G_M000_IG61
 
G_M000_IG49:                ;; offset=0x057B
       cmp      r8d, 1
       je       SHORT G_M000_IG51
       mov      dword ptr [rbp-0xD4], r8d
       cmp      r8d, 2
       jne      G_M000_IG61
 
G_M000_IG50:                ;; offset=0x0592
       mov      r8d, dword ptr [rbp-0xD4]
 
G_M000_IG51:                ;; offset=0x0599
       test     byte  ptr [(reloc 0x7ff9d7795e80)], 1
       je       G_M000_IG79
 
G_M000_IG52:                ;; offset=0x05A6
       mov      rax, 0x26B2A801D60
       cmp      rdi, gword ptr [rax]
       je       SHORT G_M000_IG54
 
G_M000_IG53:                ;; offset=0x05B5
       mov      dword ptr [rbp-0xD4], r8d
       jmp      G_M000_IG61
 
G_M000_IG54:                ;; offset=0x05C1
       test     r14, r14
       je       G_M000_IG60
 
G_M000_IG55:                ;; offset=0x05CA
       mov      rax, 0x7FF9D76647D8
       cmp      qword ptr [r14], rax
       jne      SHORT G_M000_IG59
 
G_M000_IG56:                ;; offset=0x05D9
       mov      dword ptr [rbp-0xD4], r8d
       test     r8d, r8d
       je       G_M000_IG81
       mov      r15, r12
       mov      rcx, r15
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Object():System.Object:this]
       mov      rdx, rax
       mov      rcx, r14
       call     [Lokad.Lython.Runtime.PyDict:CanReadKeySynchronously(System.Object):bool:this]
       test     eax, eax
       je       SHORT G_M000_IG61
       mov      rcx, r15
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Object():System.Object:this]
       mov      rdx, rax
       test     rdx, rdx
       je       SHORT G_M000_IG58
 
G_M000_IG57:                ;; offset=0x0616
       mov      rcx, 0x7FF9D75BDAA0
       cmp      qword ptr [rdx], rcx
       jne      G_M000_IG80
 
G_M000_IG58:                ;; offset=0x0629
       mov      gword ptr [rsp+0x28], rdx
       mov      rdx, gword ptr [rbp+0x18]
       mov      r8, rbx
       mov      r9d, dword ptr [rbp+0x30]
       mov      gword ptr [rsp+0x20], r14
       mov      rcx, bword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteDictionaryAccumulation(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Frontend.ExecutableCallSite,int,Lokad.Lython.Runtime.PyDict,Lokad.Lython.Runtime.Text.PyString):bool]
       test     eax, eax
       je       SHORT G_M000_IG61
       jmp      G_M000_IG76
 
G_M000_IG59:                ;; offset=0x0651
       mov      dword ptr [rbp-0xD4], r8d
       jmp      SHORT G_M000_IG61
 
G_M000_IG60:                ;; offset=0x065A
       mov      dword ptr [rbp-0xD4], r8d
 
G_M000_IG61:                ;; offset=0x0661
       mov      r9, gword ptr [rbx+0x18]
       mov      rdx, rsi
       test     rdx, rdx
       cmove    rdx, gword ptr [rbp+0x18]
       mov      bword ptr [rbp-0xF8], r12
       mov      r8d, dword ptr [rbp-0xD4]
       mov      dword ptr [rbp-0xF0], r8d
       mov      gword ptr [rsp+0x20], rdx
       lea      r8, [rbp-0xA8]
       mov      qword ptr [rsp+0x28], r8
       lea      r8, [rbp-0xF8]
       mov      rdx, r14
       mov      rcx, rdi
       call     [Lokad.Lython.Runtime.LythonRuntime:TryInvokeClosedReceiver(Lokad.Lython.Runtime.LythonRuntime+ReceiverMethod,System.Object,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       test     eax, eax
       je       G_M000_IG68
       mov      rcx, bword ptr [rbp+0x10]
       mov      r9, gword ptr [rcx]
       mov      r9, gword ptr [r9+0x98]
       mov      edx, dword ptr [rcx+0x10]
       cmp      edx, dword ptr [r9+0x08]
       jae      G_M000_IG81
       shl      rdx, 5
       lea      r8, bword ptr [r9+rdx+0x10]
       mov      rbx, gword ptr [rbp-0xA8]
       mov      edi, dword ptr [r8+0x18]
       test     edi, edi
       jge      SHORT G_M000_IG62
       mov      gword ptr [rbp-0x108], rbx
       xor      r9d, r9d
       mov      qword ptr [rbp-0x100], r9
       lea      r9, [rbp-0x108]
       mov      rdx, rsi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CompleteResultConsumer(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot)]
       jmp      G_M000_IG76
 
G_M000_IG62:                ;; offset=0x070A
       lea      rsi, bword ptr [rcx+0x20]
       mov      edx, dword ptr [r8+0x1C]
       cmp      edx, 51
       ja       SHORT G_M000_IG65
 
G_M000_IG63:                ;; offset=0x0717
       mov      rax, 0x7FFFFFFFFF9FF
       bt       rax, rdx
       jb       SHORT G_M000_IG65
 
G_M000_IG64:                ;; offset=0x0727
       mov      r14d, edi
       jmp      SHORT G_M000_IG66
 
G_M000_IG65:                ;; offset=0x072C
       mov      r14d, dword ptr [r8+0x14]
 
G_M000_IG66:                ;; offset=0x0730
       cmp      edi, dword ptr [rsi+0x40]
       jge      SHORT G_M000_IG67
       mov      rcx, rsi
       mov      edx, edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
 
G_M000_IG67:                ;; offset=0x0740
       mov      rdx, gword ptr [rsi]
       cmp      r14d, dword ptr [rdx+0x08]
       jae      G_M000_IG81
       mov      eax, r14d
       shl      rax, 4
       lea      r14, bword ptr [rdx+rax+0x10]
       mov      rcx, r14
       mov      rdx, rbx
       call     CORINFO_HELP_ASSIGN_REF
       xor      eax, eax
       mov      qword ptr [r14+0x08], rax
       mov      dword ptr [rsi+0x40], edi
       jmp      G_M000_IG76
 
G_M000_IG68:                ;; offset=0x0772
       xor      eax, eax
       jmp      G_M000_IG118
 
G_M000_IG69:                ;; offset=0x0779
       mov      rcx, bword ptr [rbp+0x10]
       mov      r9, gword ptr [rcx]
       mov      r9, gword ptr [r9+0x98]
       mov      edx, dword ptr [rcx+0x10]
       cmp      edx, dword ptr [r9+0x08]
       jae      G_M000_IG81
       shl      rdx, 5
       lea      r8, bword ptr [r9+rdx+0x10]
       mov      rbx, gword ptr [rbp-0xA0]
       mov      rdi, qword ptr [rbp-0x98]
       mov      r14d, dword ptr [r8+0x18]
       test     r14d, r14d
       jge      SHORT G_M000_IG70
       mov      gword ptr [rbp-0x108], rbx
       mov      qword ptr [rbp-0x100], rdi
       lea      r9, [rbp-0x108]
       mov      rdx, rsi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CompleteResultConsumer(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot)]
       jmp      SHORT G_M000_IG76
 
G_M000_IG70:                ;; offset=0x07D4
       lea      rsi, bword ptr [rcx+0x20]
       mov      edx, dword ptr [r8+0x1C]
       cmp      edx, 51
       ja       SHORT G_M000_IG73
 
G_M000_IG71:                ;; offset=0x07E1
       mov      rax, 0x7FFFFFFFFF9FF
       bt       rax, rdx
       jb       SHORT G_M000_IG73
 
G_M000_IG72:                ;; offset=0x07F1
       mov      r15d, r14d
       jmp      SHORT G_M000_IG74
 
G_M000_IG73:                ;; offset=0x07F6
       mov      r15d, dword ptr [r8+0x14]
 
G_M000_IG74:                ;; offset=0x07FA
       cmp      r14d, dword ptr [rsi+0x40]
       jge      SHORT G_M000_IG75
       mov      rcx, rsi
       mov      edx, r14d
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
 
G_M000_IG75:                ;; offset=0x080C
       mov      rdx, gword ptr [rsi]
       cmp      r15d, dword ptr [rdx+0x08]
       jae      G_M000_IG81
       mov      eax, r15d
       shl      rax, 4
       lea      r15, bword ptr [rdx+rax+0x10]
       mov      rcx, r15
       mov      rdx, rbx
       call     CORINFO_HELP_ASSIGN_REF
       mov      qword ptr [r15+0x08], rdi
       mov      dword ptr [rsi+0x40], r14d
 
G_M000_IG76:                ;; offset=0x0838
       mov      eax, 1
       jmp      G_M000_IG118
 
G_M000_IG77:                ;; offset=0x0842
       call     [System.ThrowHelper:ThrowArgumentOutOfRangeException()]
       int3     
 
G_M000_IG78:                ;; offset=0x0849
       mov      dword ptr [rbp-0xD4], r8d
       mov      rcx, 0x7FF9D7795E18
       call     CORINFO_HELP_GET_GCSTATIC_BASE
       mov      r8d, dword ptr [rbp-0xD4]
       jmp      G_M000_IG44
 
G_M000_IG79:                ;; offset=0x086B
       mov      dword ptr [rbp-0xD4], r8d
       mov      rcx, 0x7FF9D7795E18
       call     CORINFO_HELP_GET_GCSTATIC_BASE
       mov      r8d, dword ptr [rbp-0xD4]
       jmp      G_M000_IG52
 
G_M000_IG80:                ;; offset=0x088D
       mov      rdx, rax
       call     CORINFO_HELP_CHKCASTCLASS
       int3     
 
G_M000_IG81:                ;; offset=0x0896
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG82:                ;; offset=0x089C
       lea      r9, [rbp-0x40]
       mov      rcx, gword ptr [rbp-0x120]
       mov      rdx, rbx
       mov      r8, r15
       call     [Lokad.Lython.Runtime.PyExecutableFunction:TrySelectNativeCall(Lokad.Lython.Frontend.ExecutableCallSite,System.Object,byref):bool:this]
       test     eax, eax
       je       G_M000_IG119
       xor      ecx, ecx
       mov      dword ptr [rbp-0x44], ecx
 
G_M000_IG83:                ;; offset=0x08C0
       mov      rdx, gword ptr [rbx+0x18]
       mov      rax, gword ptr [rbp+0x18]
       mov      rcx, gword ptr [rax+0xA0]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.ExecutionState:EnterInterpreterFrame(Lokad.Lython.LythonSourceSpan):this]
       mov      dword ptr [rbp-0x44], 1
       mov      rdi, gword ptr [rbx+0x18]
       mov      rax, gword ptr [rbp+0x18]
       mov      r13, gword ptr [rax+0xA0]
       cmp      byte  ptr [r13], r13b
       mov      rcx, r13
       call     [Lokad.Lython.Runtime.ExecutionState:get_CanContinue():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG84
       mov      rcx, r13
       mov      rdx, rdi
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
 
G_M000_IG84:                ;; offset=0x090A
       mov      rcx, bword ptr [rbp+0x10]
       lea      rdx, bword ptr [rcx+0x20]
       cmp      byte  ptr [rbx+0x30], 0
       setne    al
       movzx    rax, al
       mov      r11d, dword ptr [rbp+0x30]
       lea      edi, [r11+rax+0x01]
       mov      r13d, dword ptr [rbx+0x28]
       mov      rdx, gword ptr [rdx]
       test     rdx, rdx
       je       SHORT G_M000_IG85
       mov      eax, edi
       mov      r8d, r13d
       add      rax, r8
       mov      r8d, dword ptr [rdx+0x08]
       cmp      rax, r8
       ja       G_M000_IG116
       mov      rax, rdx
       jmp      SHORT G_M000_IG86
 
G_M000_IG85:                ;; offset=0x094B
       mov      eax, edi
       or       eax, r13d
       jne      G_M000_IG116
       xor      rax, rax
       xor      edi, edi
       xor      r13d, r13d
 
G_M000_IG86:                ;; offset=0x095D
       xor      r12, r12
       xor      r8d, r8d
       test     rax, rax
       je       SHORT G_M000_IG89
       mov      rdx, qword ptr [rax]
       test     dword ptr [rdx], 0xFFFFFFFF80000000
       jne      SHORT G_M000_IG87
       lea      rdx, [rbp-0xD0]
       mov      rcx, rax
       mov      rax, qword ptr [rax]
       mov      rax, qword ptr [rax+0x40]
       call     [rax+0x28]System.Buffers.MemoryManager`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:GetSpan():System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:this
       mov      r8d, dword ptr [rbp-0xC8]
       mov      r12, bword ptr [rbp-0xD0]
       mov      eax, r8d
       jmp      SHORT G_M000_IG88
 
G_M000_IG87:                ;; offset=0x099A
       lea      r12, bword ptr [rax+0x10]
       mov      eax, dword ptr [rax+0x08]
 
G_M000_IG88:                ;; offset=0x09A1
       and      edi, 0x7FFFFFFF
       mov      r8d, edi
       mov      edx, r13d
       add      rdx, r8
       mov      eax, eax
       cmp      rdx, rax
       ja       G_M000_IG116
       shl      r8, 4
       add      r12, r8
       mov      eax, r13d
       mov      r8d, eax
 
G_M000_IG89:                ;; offset=0x09C8
       mov      bword ptr [rbp-0x118], r12
       mov      dword ptr [rbp-0xBC], r8d
       mov      dword ptr [rbp-0x110], r8d
       mov      rax, gword ptr [rbp+0x18]
       mov      gword ptr [rsp+0x20], rax
       movzx    rdx, byte  ptr [rbp-0x40]
       mov      dword ptr [rsp+0x28], edx
       lea      rdx, [rbp-0x58]
       mov      qword ptr [rsp+0x30], rdx
       lea      rdx, [rbp-0x60]
       mov      qword ptr [rsp+0x38], rdx
       lea      r8, [rbp-0x118]
       mov      rdx, rbx
       mov      rcx, gword ptr [rbp-0x120]
       mov      r9, r15
       call     [Lokad.Lython.Runtime.PyExecutableFunction:TryCompleteNativeCall(Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,bool,byref,byref):bool:this]
       test     eax, eax
       jne      G_M000_IG106
       lea      rcx, [rbp-0x78]
       mov      qword ptr [rsp+0x20], rcx
       lea      rcx, [rbp-0x70]
       mov      rdx, bword ptr [rbp+0x10]
       mov      r8, rbx
       mov      r9d, dword ptr [rbp+0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PrepareUnpackedCallReturn(byref,Lokad.Lython.Frontend.ExecutableCallSite,int,byref):System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]]
       mov      r8, gword ptr [rbx+0x18]
       cmp      byte  ptr [rbx+0x31], 0
       je       SHORT G_M000_IG90
       mov      r9d, 1
       jmp      SHORT G_M000_IG92
 
G_M000_IG90:                ;; offset=0x0A52
       mov      rdx, bword ptr [rbp+0x10]
       cmp      byte  ptr [rdx+0x14], 0
       jne      SHORT G_M000_IG91
       xor      r9d, r9d
       jmp      SHORT G_M000_IG92
 
G_M000_IG91:                ;; offset=0x0A61
       movzx    r9, byte  ptr [rbx+0x32]
 
G_M000_IG92:                ;; offset=0x0A66
       mov      bword ptr [rbp-0x118], r12
       mov      r13d, dword ptr [rbp-0xBC]
       mov      dword ptr [rbp-0x110], r13d
       mov      rax, gword ptr [rbp+0x18]
       mov      gword ptr [rsp+0x20], rax
       mov      gword ptr [rsp+0x28], r8
       mov      dword ptr [rsp+0x30], r9d
       movzx    r9, byte  ptr [rbp-0x40]
 
G_M000_IG93:                ;; offset=0x0A93
       vmovdqu  xmm0, xmmword ptr [rbp-0x70]
       vmovdqu  xmmword ptr [rbp-0xF8], xmm0
 
G_M000_IG94:                ;; offset=0x0AA0
       lea      r8, [rbp-0x80]
       mov      qword ptr [rsp+0x48], r8
       lea      r8, [rbp-0x58]
       mov      qword ptr [rsp+0x50], r8
       lea      r8, [rbp-0x88]
       mov      qword ptr [rsp+0x58], r8
       lea      r8, [rbp-0x118]
       mov      dword ptr [rsp+0x38], r9d
       lea      r9, [rbp-0xF8]
       mov      qword ptr [rsp+0x40], r9
       mov      r9, r15
       mov      rdx, rbx
       mov      rcx, gword ptr [rbp-0x120]
       call     [Lokad.Lython.Runtime.PyExecutableFunction:StartNativeCall(Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,bool,bool,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,byref,byref):this]
       cmp      byte  ptr [rbp-0x80], 0
       jne      SHORT G_M000_IG95
       mov      rdx, bword ptr [rbp+0x10]
       lea      rcx, bword ptr [rdx+0x20]
       mov      eax, dword ptr [rbp-0x78]
       mov      dword ptr [rcx+0x40], eax
 
G_M000_IG95:                ;; offset=0x0AFD
       cmp      gword ptr [rbp-0x88], 0
       jne      G_M000_IG103
       mov      rax, gword ptr [rbp+0x18]
       mov      rcx, gword ptr [rax+0xA0]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.ExecutionState:LeaveInterpreterFrame():this]
       xor      r9d, r9d
       mov      dword ptr [rbp-0x44], r9d
       cmp      byte  ptr [rbp-0x80], 0
       jne      G_M000_IG102
       mov      rdx, bword ptr [rbp+0x10]
       mov      r9, gword ptr [rdx]
       mov      r9, gword ptr [r9+0x98]
       mov      r8d, dword ptr [rdx+0x10]
       cmp      r8d, dword ptr [r9+0x08]
       jae      G_M000_IG117
       shl      r8, 5
       lea      r8, bword ptr [r9+r8+0x10]
       mov      r14, gword ptr [rbp-0x58]
       mov      rdi, qword ptr [rbp-0x50]
       mov      r15d, dword ptr [r8+0x18]
       test     r15d, r15d
       jge      SHORT G_M000_IG96
       mov      gword ptr [rbp-0x108], r14
       mov      qword ptr [rbp-0x100], rdi
       lea      r9, [rbp-0x108]
       mov      rdx, rsi
       mov      rcx, bword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CompleteResultConsumer(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot)]
       jmp      G_M000_IG115
 
G_M000_IG96:                ;; offset=0x0B8C
       mov      rdx, bword ptr [rbp+0x10]
       lea      rsi, bword ptr [rdx+0x20]
       mov      ecx, dword ptr [r8+0x1C]
       cmp      ecx, 51
       ja       SHORT G_M000_IG99
 
G_M000_IG97:                ;; offset=0x0B9D
       mov      rax, 0x7FFFFFFFFF9FF
       bt       rax, rcx
       jb       SHORT G_M000_IG99
 
G_M000_IG98:                ;; offset=0x0BAD
       mov      r13d, r15d
       jmp      SHORT G_M000_IG100
 
G_M000_IG99:                ;; offset=0x0BB2
       mov      r13d, dword ptr [r8+0x14]
 
G_M000_IG100:                ;; offset=0x0BB6
       cmp      r15d, dword ptr [rsi+0x40]
       jge      SHORT G_M000_IG101
       mov      rcx, rsi
       mov      edx, r15d
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
 
G_M000_IG101:                ;; offset=0x0BC8
       mov      rcx, gword ptr [rsi]
       cmp      r13d, dword ptr [rcx+0x08]
       jae      G_M000_IG117
       mov      eax, r13d
       shl      rax, 4
       lea      r13, bword ptr [rcx+rax+0x10]
       mov      rcx, r13
       mov      rdx, r14
       call     CORINFO_HELP_ASSIGN_REF
       mov      qword ptr [r13+0x08], rdi
       mov      dword ptr [rsi+0x40], r15d
       jmp      G_M000_IG115
 
G_M000_IG102:                ;; offset=0x0BF9
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rbp+0x18]
       mov      r8d, dword ptr [rbp+0x30]
       mov      r9d, dword ptr [rbp-0x68]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CompleteUnpackedCallReturn(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,int,int)]
       jmp      G_M000_IG115
 
G_M000_IG103:                ;; offset=0x0C14
       mov      rcx, gword ptr [rbp-0x88]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:EnterExecutableSlots():this]
       mov      rdi, gword ptr [rbp-0x88]
       mov      rcx, gword ptr [rbp-0x120]
       mov      rcx, gword ptr [rcx+0x28]
       mov      rcx, gword ptr [rcx+0xA0]
       mov      r15, gword ptr [rcx+0x88]
       lea      rcx, bword ptr [rsi+0x30]
       mov      rdx, rbx
       call     CORINFO_HELP_ASSIGN_REF
       xor      rcx, rcx
       mov      gword ptr [rsi+0x40], rcx
       mov      r9d, dword ptr [rbp+0x30]
       mov      dword ptr [rsi+0xF0], r9d
 
G_M000_IG104:                ;; offset=0x0C60
       mov      dword ptr [rsi+0xF4], ecx
       lea      rcx, bword ptr [rdi+0x20]
       mov      rdx, rsi
       call     CORINFO_HELP_ASSIGN_REF
       lea      rcx, bword ptr [rdi+0x28]
       mov      rdx, r15
       call     CORINFO_HELP_ASSIGN_REF
       nop      
 
G_M000_IG105:                ;; offset=0x0C7F
       mov      rdx, gword ptr [rbp-0x88]
       mov      rcx, r14
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       xor      ecx, ecx
       mov      dword ptr [rbp-0x44], ecx
       jmp      G_M000_IG115
 
G_M000_IG106:                ;; offset=0x0C98
       mov      rdx, gword ptr [rbp+0x18]
       mov      rcx, gword ptr [rdx+0xA0]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.ExecutionState:LeaveInterpreterFrame():this]
       xor      r9d, r9d
       mov      dword ptr [rbp-0x44], r9d
       cmp      byte  ptr [rbp-0x60], 0
       jne      G_M000_IG113
       mov      rdx, bword ptr [rbp+0x10]
       mov      r9, gword ptr [rdx]
       mov      r9, gword ptr [r9+0x98]
       mov      r8d, dword ptr [rdx+0x10]
       cmp      r8d, dword ptr [r9+0x08]
       jae      G_M000_IG117
       shl      r8, 5
       lea      r8, bword ptr [r9+r8+0x10]
       mov      rdi, gword ptr [rbp-0x58]
       mov      r14, qword ptr [rbp-0x50]
       mov      r15d, dword ptr [r8+0x18]
       test     r15d, r15d
       jge      SHORT G_M000_IG107
       mov      gword ptr [rbp-0x108], rdi
       mov      qword ptr [rbp-0x100], r14
       lea      r9, [rbp-0x108]
       mov      rdx, rsi
       mov      rcx, bword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CompleteResultConsumer(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot)]
       jmp      G_M000_IG115
 
G_M000_IG107:                ;; offset=0x0D19
       mov      rdx, bword ptr [rbp+0x10]
       lea      rsi, bword ptr [rdx+0x20]
       mov      ecx, dword ptr [r8+0x1C]
       cmp      ecx, 51
       ja       SHORT G_M000_IG110
 
G_M000_IG108:                ;; offset=0x0D2A
       mov      rax, 0x7FFFFFFFFF9FF
       bt       rax, rcx
       jb       SHORT G_M000_IG110
 
G_M000_IG109:                ;; offset=0x0D3A
       mov      r13d, r15d
       jmp      SHORT G_M000_IG111
 
G_M000_IG110:                ;; offset=0x0D3F
       mov      r13d, dword ptr [r8+0x14]
 
G_M000_IG111:                ;; offset=0x0D43
       cmp      r15d, dword ptr [rsi+0x40]
       jge      SHORT G_M000_IG112
       mov      rcx, rsi
       mov      edx, r15d
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
 
G_M000_IG112:                ;; offset=0x0D55
       mov      rcx, gword ptr [rsi]
       cmp      r13d, dword ptr [rcx+0x08]
       jae      SHORT G_M000_IG117
       mov      eax, r13d
       shl      rax, 4
       lea      r13, bword ptr [rcx+rax+0x10]
       mov      rcx, r13
       mov      rdx, rdi
       call     CORINFO_HELP_ASSIGN_REF
       mov      qword ptr [r13+0x08], r14
       mov      dword ptr [rsi+0x40], r15d
       jmp      SHORT G_M000_IG115
 
G_M000_IG113:                ;; offset=0x0D7F
       vmovdqu  xmm0, xmmword ptr [rbp-0x58]
       vmovdqu  xmmword ptr [rbp-0x108], xmm0
 
G_M000_IG114:                ;; offset=0x0D8C
       lea      r9, [rbp-0x108]
       mov      rdx, gword ptr [rbp+0x18]
       mov      r8, rsi
       mov      rcx, bword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PublishDirectIntegerCall(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot)]
 
G_M000_IG115:                ;; offset=0x0DA4
       mov      eax, 1
       jmp      SHORT G_M000_IG118
 
G_M000_IG116:                ;; offset=0x0DAB
       call     [System.ThrowHelper:ThrowArgumentOutOfRangeException()]
       int3     
 
G_M000_IG117:                ;; offset=0x0DB2
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG118:                ;; offset=0x0DB8
       add      rsp, 328
       pop      rbx
       pop      rsi
       pop      rdi
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG119:                ;; offset=0x0DCC
       xor      eax, eax
 
G_M000_IG120:                ;; offset=0x0DCE
       add      rsp, 328
       pop      rbx
       pop      rsi
       pop      rdi
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG121:                ;; offset=0x0DE2
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG122:                ;; offset=0x0DE8
       sub      rsp, 104
 
G_M000_IG123:                ;; offset=0x0DEC
       mov      r14, gword ptr [rbp-0x88]
       mov      rcx, gword ptr [rbp-0x120]
       call     [Lokad.Lython.Runtime.PyExecutableFunction:get_DefinitionContext():Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:this]
       mov      rcx, rax
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:get_MemoryGovernor():Lokad.Lython.Runtime.MemoryGovernor:this]
       mov      rdx, rax
       mov      rcx, r14
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:AbortPreparedCall(Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.MemoryGovernor)]
       call     CORINFO_HELP_RETHROW
       int3     
 
G_M000_IG124:                ;; offset=0x0E1D
       sub      rsp, 104
 
G_M000_IG125:                ;; offset=0x0E21
       mov      rbx, rcx
       mov      rcx, bword ptr [rbp+0x10]
       cmp      byte  ptr [rcx], cl
       add      rcx, 32
       mov      edx, dword ptr [rbp+0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
       mov      rcx, gword ptr [rbp+0x28]
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_CallSpan():Lokad.Lython.LythonSourceSpan:this]
       mov      rdx, rax
       lea      r8, [rbp-0x90]
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime:TryTranslateCallableException(System.Exception,Lokad.Lython.LythonSourceSpan,byref):bool]
       test     eax, eax
       je       SHORT G_M000_IG126
       mov      rcx, gword ptr [rbp-0x90]
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG126:                ;; offset=0x0E65
       call     CORINFO_HELP_RETHROW
       int3     
 
G_M000_IG127:                ;; offset=0x0E6B
       sub      rsp, 104
 
G_M000_IG128:                ;; offset=0x0E6F
       cmp      dword ptr [rbp-0x44], 0
       je       SHORT G_M000_IG129
       mov      rdx, gword ptr [rbp+0x18]
       mov      rcx, gword ptr [rdx+0xA0]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.ExecutionState:LeaveInterpreterFrame():this]
 
G_M000_IG129:                ;; offset=0x0E88
       nop      
 
G_M000_IG130:                ;; offset=0x0E89
       add      rsp, 104
       ret      
 
G_M000_IG131:                ;; offset=0x0E8E
       sub      rsp, 104
 
G_M000_IG132:                ;; offset=0x0E92
       mov      rcx, bword ptr [rbp+0x10]
       cmp      byte  ptr [rcx], cl
       add      rcx, 32
       mov      edx, dword ptr [rbp+0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
       call     CORINFO_HELP_RETHROW
       int3     
 
G_M000_IG133:                ;; offset=0x0EAB
       sub      rsp, 104
 
G_M000_IG134:                ;; offset=0x0EAF
       mov      rcx, bword ptr [rbp+0x10]
       cmp      byte  ptr [rcx], cl
       add      rcx, 32
       mov      edx, dword ptr [rbp+0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
       call     CORINFO_HELP_RETHROW
       int3     
 
; Total bytes of code 3784

; Assembly listing for method Lokad.Lython.Runtime.PyExecutableFunction:StartNativeCall(Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,bool,bool,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,byref,byref):this (FullOpts)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; FullOpts code
; optimized code
; rbp based frame
; partially interruptible
; No PGO data
; 0 inlinees with PGO data; 2 single block inlinees; 0 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       push     r15
       push     r14
       push     r13
       push     r12
       push     rdi
       push     rsi
       push     rbx
       sub      rsp, 152
       lea      rbp, [rsp+0xD0]
       xor      eax, eax
       mov      qword ptr [rbp-0x68], rax
       vxorps   xmm4, xmm4, xmm4
       vmovdqu  ymmword ptr [rbp-0x60], ymm4
       mov      qword ptr [rbp-0x40], rax
       mov      rbx, rcx
       mov      rdi, rdx
       mov      rsi, r9
       mov      r14, bword ptr [rbp+0x50]
 
G_M000_IG02:                ;; offset=0x003B
       mov      r15, bword ptr [r8]
       mov      r13d, dword ptr [r8+0x08]
       cmp      dword ptr [r14+0x08], 2
       je       SHORT G_M000_IG04
 
G_M000_IG03:                ;; offset=0x0049
       xor      r8d, r8d
       jmp      SHORT G_M000_IG05
 
G_M000_IG04:                ;; offset=0x004E
       mov      r8, gword ptr [rbx+0x40]
       movzx    r8, byte  ptr [r8+0xF1]
 
G_M000_IG05:                ;; offset=0x005A
       movzx    r12, byte  ptr [rbp+0x48]
       test     r8d, r12d
       je       SHORT G_M000_IG11
 
G_M000_IG06:                ;; offset=0x0064
       test     rsi, rsi
       jne      SHORT G_M000_IG11
       cmp      r13d, 1
       jne      SHORT G_M000_IG11
 
G_M000_IG07:                ;; offset=0x006F
       vmovdqu  xmm0, xmmword ptr [r15]
       vmovdqu  xmmword ptr [rbp-0x48], xmm0
 
G_M000_IG08:                ;; offset=0x0079
       mov      rax, bword ptr [rbp+0x60]
       mov      bword ptr [rsp+0x20], rax
 
G_M000_IG09:                ;; offset=0x0082
       vmovdqu  xmm0, xmmword ptr [r14]
       vmovdqu  xmmword ptr [rbp-0x58], xmm0
 
G_M000_IG10:                ;; offset=0x008C
       lea      r8, [rbp-0x58]
       mov      qword ptr [rsp+0x28], r8
       lea      r8, [rbp-0x48]
       mov      rcx, rbx
       mov      r9, gword ptr [rbp+0x38]
       xor      rdx, rdx
       call     [Lokad.Lython.Runtime.PyExecutableFunction:TryReturnDefinition(Lokad.Lython.Frontend.ExecutableCreateFunction,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot,Lokad.Lython.LythonSourceSpan,byref,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG12
 
G_M000_IG11:                ;; offset=0x00AC
       mov      bword ptr [rbp-0x68], r15
       mov      dword ptr [rbp-0x60], r13d
       mov      r15, gword ptr [rbp+0x30]
       mov      gword ptr [rsp+0x20], r15
       mov      r15, gword ptr [rbp+0x38]
       mov      gword ptr [rsp+0x28], r15
       movzx    r8, byte  ptr [rbp+0x40]
       mov      dword ptr [rsp+0x30], r8d
       mov      dword ptr [rsp+0x38], r12d
       mov      bword ptr [rsp+0x40], r14
       mov      r14, bword ptr [rbp+0x58]
       mov      bword ptr [rsp+0x48], r14
       mov      r14, bword ptr [rbp+0x60]
       mov      bword ptr [rsp+0x50], r14
       mov      r14, bword ptr [rbp+0x68]
       mov      bword ptr [rsp+0x58], r14
       lea      r8, [rbp-0x68]
       mov      rdx, rdi
       mov      rcx, rbx
       mov      r9, rsi
       call     [Lokad.Lython.Runtime.PyExecutableFunction:StartNativeWorkspace(Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,bool,bool,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,byref,byref):this]
       jmp      SHORT G_M000_IG13
 
G_M000_IG12:                ;; offset=0x010A
       mov      rbx, bword ptr [rbp+0x58]
       mov      byte  ptr [rbx], 1
       xor      rax, rax
       mov      r14, bword ptr [rbp+0x68]
       mov      gword ptr [r14], rax
 
G_M000_IG13:                ;; offset=0x011A
       add      rsp, 152
       pop      rbx
       pop      rsi
       pop      rdi
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
; Total bytes of code 302

; Assembly listing for method Lokad.Lython.Runtime.PyExecutableFunction:StartNativeWorkspace(Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,bool,bool,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,byref,byref):this (FullOpts)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; FullOpts code
; optimized code
; rbp based frame
; partially interruptible
; No PGO data
; 1 inlinees with PGO data; 11 single block inlinees; 5 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       push     r15
       push     r14
       push     rdi
       push     rsi
       push     rbx
       sub      rsp, 440
       lea      rbp, [rsp+0x1E0]
       vxorps   xmm4, xmm4, xmm4
       vmovdqa  xmmword ptr [rbp-0x190], xmm4
       mov      rax, -336
 
G_M000_IG16:                ;; offset=0x002D
       vmovdqa  xmmword ptr [rbp+rax-0x30], xmm4
       vmovdqa  xmmword ptr [rbp+rax-0x20], xmm4
       vmovdqa  xmmword ptr [rbp+rax-0x10], xmm4
       add      rax, 48
       jne      SHORT G_M000_IG16
       mov      qword ptr [rbp-0x30], rax
       mov      rbx, rcx
       mov      rdi, gword ptr [rbp+0x38]
       mov      rsi, bword ptr [rbp+0x50]
 
G_M000_IG02:                ;; offset=0x0054
       mov      rax, bword ptr [r8]
       mov      r14d, dword ptr [r8+0x08]
       mov      rcx, gword ptr [rbx+0x40]
       mov      r15d, dword ptr [rcx+0xE8]
       cmp      r15d, 16
       ja       G_M000_IG11
       cmp      byte  ptr [rbp+0x48], 0
       jne      G_M000_IG07
 
G_M000_IG03:                ;; offset=0x007A
       mov      rcx, gword ptr [rbx+0x08]
       mov      rcx, gword ptr [rcx+0x08]
       mov      ecx, dword ptr [rcx+0x08]
       cmp      ecx, r15d
       ja       G_M000_IG11
       lea      r8, bword ptr [rbp-0x128]
       mov      bword ptr [rbp-0x170], r8
       mov      dword ptr [rbp-0x168], ecx
       xor      rcx, rcx
       mov      bword ptr [rbp-0x180], rcx
 
G_M000_IG04:                ;; offset=0x00AB
       mov      dword ptr [rbp-0x178], ecx
       mov      rcx, gword ptr [rbp+0x30]
       mov      gword ptr [rsp+0x20], rcx
       xor      ecx, ecx
       mov      dword ptr [rsp+0x28], ecx
       mov      gword ptr [rsp+0x30], r9
       mov      gword ptr [rsp+0x38], rdx
       mov      bword ptr [rbp-0x190], rax
       mov      dword ptr [rbp-0x188], r14d
       lea      rcx, [rbp-0x170]
       lea      rdx, [rbp-0x180]
       lea      r9, [rbp-0x190]
       mov      qword ptr [rsp+0x40], r9
       mov      r9, rbx
       mov      r8, rdi
       call     [Lokad.Lython.Runtime.LythonRuntime:BindFunctionArgumentsInto(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.ReadOnlySpan`1[Lokad.Lython.Runtime.CallArgumentValue],Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.FunctionBindingPlan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,bool,System.Object,Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):int]
 
G_M000_IG05:                ;; offset=0x00FE
       vxorps   ymm0, ymm0, ymm0
       vmovdqu  ymmword ptr [rbp-0x160], ymm0
       lea      rdx, bword ptr [rbp-0x128]
       mov      bword ptr [rbp-0x170], rdx
       mov      dword ptr [rbp-0x168], r15d
       movzx    rdx, byte  ptr [rbp+0x40]
       mov      dword ptr [rsp+0x20], edx
       mov      bword ptr [rsp+0x28], rsi
       mov      rsi, bword ptr [rbp+0x58]
       mov      bword ptr [rsp+0x30], rsi
       mov      rsi, bword ptr [rbp+0x60]
       mov      bword ptr [rsp+0x38], rsi
       mov      rsi, bword ptr [rbp+0x68]
       mov      bword ptr [rsp+0x40], rsi
       lea      rdx, [rbp-0x140]
       mov      qword ptr [rsp+0x48], rdx
       lea      rdx, [rbp-0x170]
       lea      r8, [rbp-0x160]
       mov      rcx, rbx
       mov      r9, rdi
       call     [Lokad.Lython.Runtime.PyExecutableFunction:StartInline(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.Nullable`1[Lokad.Lython.Runtime.BoundFunctionArguments],Lokad.Lython.LythonSourceSpan,bool,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,byref,byref,byref):this]
       nop      
 
G_M000_IG06:                ;; offset=0x016E
       add      rsp, 440
       pop      rbx
       pop      rsi
       pop      rdi
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG07:                ;; offset=0x017E
       xor      ecx, ecx
       test     r9, r9
       je       SHORT G_M000_IG08
       mov      ecx, 1
       test     r15d, r15d
       je       G_M000_IG15
       mov      gword ptr [rbp-0x128], r9
       xor      edx, edx
       mov      qword ptr [rbp-0x120], rdx
 
G_M000_IG08:                ;; offset=0x01A3
       cmp      ecx, r15d
       ja       SHORT G_M000_IG11
       lea      rdx, bword ptr [rbp-0x128]
       mov      r8d, ecx
       shl      r8, 4
       add      r8, rdx
       mov      edx, r15d
       sub      edx, ecx
       cmp      r14d, edx
       ja       SHORT G_M000_IG14
 
G_M000_IG09:                ;; offset=0x01C3
       mov      ecx, r14d
       shl      rcx, 4
       mov      r10, rcx
       cmp      r10, 0x4000
       ja       SHORT G_M000_IG13
 
G_M000_IG10:                ;; offset=0x01D6
       mov      rcx, r8
       mov      rdx, rax
       mov      r8, r10
       call     System.Buffer:BulkMoveWithWriteBarrierInternal(byref,byref,nuint)
       cmp      dword ptr [(reloc 0x7ffa37082aa8)], 0
       je       G_M000_IG05
       jmp      SHORT G_M000_IG12
 
G_M000_IG11:                ;; offset=0x01F3
       call     [System.ThrowHelper:ThrowArgumentOutOfRangeException()]
       int3     
 
G_M000_IG12:                ;; offset=0x01FA
       call     CORINFO_HELP_POLL_GC
       jmp      G_M000_IG05
 
G_M000_IG13:                ;; offset=0x0204
       mov      rcx, r8
       mov      rdx, rax
       mov      r8, r10
       call     [System.Buffer:BulkMoveWithWriteBarrierBatch(byref,byref,nuint)]
       jmp      G_M000_IG05
 
G_M000_IG14:                ;; offset=0x0218
       call     [System.ThrowHelper:ThrowArgumentException_DestinationTooShort()]
       int3     
 
G_M000_IG15:                ;; offset=0x021F
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
; Total bytes of code 549

; Assembly listing for method Lokad.Lython.Runtime.PyExecutableFunction:TryReturnDefinition(Lokad.Lython.Frontend.ExecutableCreateFunction,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot,Lokad.Lython.LythonSourceSpan,byref,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):bool:this (FullOpts)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; FullOpts code
; optimized code
; rbp based frame
; fully interruptible
; No PGO data
; 0 inlinees with PGO data; 31 single block inlinees; 3 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       push     r15
       push     r14
       push     r13
       push     rdi
       push     rsi
       push     rbx
       sub      rsp, 80
       lea      rbp, [rsp+0x80]
       vxorps   xmm4, xmm4, xmm4
       vmovdqu  xmmword ptr [rbp-0x48], xmm4
       xor      eax, eax
       mov      qword ptr [rbp-0x38], rax
       mov      gword ptr [rbp+0x10], rcx
       mov      gword ptr [rbp+0x28], r9
       mov      rbx, rdx
       mov      rsi, bword ptr [rbp+0x30]
 
G_M000_IG02:                ;; offset=0x0034
       mov      rdi, gword ptr [r8]
       mov      r14, qword ptr [r8+0x08]
       xor      eax, eax
       mov      qword ptr [rsi], rax
       mov      qword ptr [rsi+0x08], rax
 
G_M000_IG03:                ;; offset=0x0044
       xor      r15, r15
       test     rbx, rbx
       jne      SHORT G_M000_IG05
 
G_M000_IG04:                ;; offset=0x004C
       xor      r13d, r13d
       jmp      SHORT G_M000_IG06
 
G_M000_IG05:                ;; offset=0x0051
       mov      rcx, rbx
       call     [Lokad.Lython.Frontend.ExecutableCreateFunction:get_InputCount():int:this]
       test     eax, eax
       sete     r13b
       movzx    r13, r13b
 
G_M000_IG06:                ;; offset=0x0064
       test     r13d, r13d
       jne      G_M000_IG22
 
G_M000_IG07:                ;; offset=0x006D
       mov      rdx, 0x26B2A801CF0
       cmp      rdi, gword ptr [rdx]
       je       SHORT G_M000_IG13
       test     r14, r14
       jle      SHORT G_M000_IG08
       mov      rdx, rdi
       mov      rcx, 0x7FF9D76C8A80
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       jne      SHORT G_M000_IG09
 
G_M000_IG08:                ;; offset=0x0098
       lea      rdx, [rbp-0x38]
       mov      rcx, rdi
       call     [Lokad.Lython.Runtime.LythonRuntime:TryMachineInteger(System.Object,byref):bool]
       jmp      SHORT G_M000_IG10
 
G_M000_IG09:                ;; offset=0x00A7
       lea      edx, [r14-0x01]
       lea      r8, [rbp-0x38]
       mov      rcx, rax
       call     [Lokad.Lython.Runtime.PyTuple:TryReadInteger(int,byref):bool:this]
 
G_M000_IG10:                ;; offset=0x00B8
       test     eax, eax
       jne      SHORT G_M000_IG14
 
G_M000_IG11:                ;; offset=0x00BC
       xor      eax, eax
 
G_M000_IG12:                ;; offset=0x00BE
       add      rsp, 80
       pop      rbx
       pop      rsi
       pop      rdi
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG13:                ;; offset=0x00CD
       mov      qword ptr [rbp-0x38], r14
 
G_M000_IG14:                ;; offset=0x00D1
       mov      rcx, gword ptr [rbp+0x10]
       mov      r11, gword ptr [rcx+0x40]
       mov      rcx, gword ptr [r11+0x80]
       mov      r11, 0x7FF9D70B2198
       call     [r11]System.Collections.Generic.IReadOnlyCollection`1[System.__Canon]:get_Count():int:this
       test     eax, eax
       je       SHORT G_M000_IG22
       mov      rcx, gword ptr [rbp+0x10]
       lea      rdx, bword ptr [rcx+0x58]
       mov      rax, gword ptr [rdx]
       test     rax, rax
       je       SHORT G_M000_IG16
 
G_M000_IG15:                ;; offset=0x0101
       mov      r8, 0x7FF9D7766C78
       cmp      qword ptr [rax], r8
       je       SHORT G_M000_IG19
 
G_M000_IG16:                ;; offset=0x0110
       test     rax, rax
       je       SHORT G_M000_IG18
 
G_M000_IG17:                ;; offset=0x0115
       mov      r8, 0x7FF9D7794B30
       xor      r10, r10
       cmp      qword ptr [rax], r8
       cmovne   rax, r10
 
G_M000_IG18:                ;; offset=0x0129
       test     rax, rax
       je       SHORT G_M000_IG20
 
G_M000_IG19:                ;; offset=0x012E
       xor      r15, r15
       jmp      SHORT G_M000_IG21
 
G_M000_IG20:                ;; offset=0x0133
       mov      r15, gword ptr [rdx]
 
G_M000_IG21:                ;; offset=0x0136
       test     r15, r15
       je       SHORT G_M000_IG11
 
G_M000_IG22:                ;; offset=0x013B
       mov      rcx, gword ptr [rbp+0x10]
       mov      rdx, gword ptr [rcx+0x28]
       mov      rcx, gword ptr [rdx+0xA0]
       mov      rdx, gword ptr [rbp+0x28]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.ExecutionState:EnterFunctionCall(Lokad.Lython.LythonSourceSpan):this]
       mov      rcx, gword ptr [rbp+0x10]
       mov      rdx, gword ptr [rcx+0x28]
       mov      r8, gword ptr [rdx+0xA0]
       mov      r8, gword ptr [r8+0x148]
       mov      gword ptr [rbp-0x50], r8
 
G_M000_IG23:                ;; offset=0x0170
       test     rbx, rbx
       je       G_M000_IG27
       test     r13d, r13d
       je       SHORT G_M000_IG24
       mov      gword ptr [rbp-0x48], rdi
       mov      qword ptr [rbp-0x40], r14
       mov      r8, gword ptr [rcx+0x40]
       mov      r8, gword ptr [r8+0x98]
       cmp      dword ptr [r8+0x08], 0
       jbe      G_M000_IG28
       mov      r9, gword ptr [r8+0x10]
       lea      r8, [rbp-0x48]
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime:CreateClosedFunctionDefinition(Lokad.Lython.Frontend.ExecutableCreateFunction,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.PyFunctionBase]
       mov      rdi, rax
       jmp      SHORT G_M000_IG25
 
G_M000_IG24:                ;; offset=0x01B2
       mov      gword ptr [rsp+0x20], r15
       mov      r8, rdx
       mov      rdx, gword ptr [rcx+0x40]
       mov      rcx, rbx
       mov      r9, qword ptr [rbp-0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime:CreateClosedComputedDefinition(Lokad.Lython.Frontend.ExecutableCreateFunction,Lokad.Lython.Frontend.ExecutableCodeObject,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,long,System.Object):Lokad.Lython.Runtime.PyFunctionBase]
       mov      rdi, rax
 
G_M000_IG25:                ;; offset=0x01CE
       mov      rcx, gword ptr [rbp+0x10]
       mov      rax, gword ptr [rcx+0x28]
       mov      rdx, gword ptr [rcx+0x40]
       mov      rdx, gword ptr [rdx+0x98]
       mov      r8d, dword ptr [rdx+0x08]
       lea      r10d, [r8-0x01]
       cmp      r10d, r8d
       jae      SHORT G_M000_IG28
       mov      r8d, r10d
       shl      r8, 5
       mov      rbx, gword ptr [rdx+r8+0x10]
       mov      r14, gword ptr [rax+0xA0]
       cmp      byte  ptr [r14], r14b
       mov      rcx, r14
       call     [Lokad.Lython.Runtime.ExecutionState:get_CanContinue():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG26
       mov      rcx, r14
       mov      rdx, rbx
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
 
G_M000_IG26:                ;; offset=0x021D
       mov      rcx, rsi
       mov      rdx, rdi
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       xor      ecx, ecx
       mov      qword ptr [rsi+0x08], rcx
       jmp      SHORT G_M000_IG29
 
G_M000_IG27:                ;; offset=0x0230
       mov      rcx, gword ptr [rcx+0x40]
       mov      r8, qword ptr [rbp-0x38]
       mov      r9, bword ptr [rbp+0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime:CompleteClosedDefinitionPair(Lokad.Lython.Frontend.ExecutableCodeObject,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,long,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot])]
       jmp      SHORT G_M000_IG29
 
G_M000_IG28:                ;; offset=0x0244
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG29:                ;; offset=0x024A
       mov      rcx, gword ptr [rbp+0x10]
       mov      rdx, gword ptr [rcx+0x28]
       mov      rsi, gword ptr [rdx+0xA0]
       mov      rbx, rsi
       lea      rcx, bword ptr [rbx+0x148]
       mov      rdx, gword ptr [rbp-0x50]
       call     CORINFO_HELP_ASSIGN_REF
       mov      rcx, rsi
       call     [Lokad.Lython.Runtime.ExecutionState:LeaveFunctionCall():this]
       nop      
 
G_M000_IG30:                ;; offset=0x0276
       mov      eax, 1
 
G_M000_IG31:                ;; offset=0x027B
       add      rsp, 80
       pop      rbx
       pop      rsi
       pop      rdi
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG32:                ;; offset=0x028A
       sub      rsp, 40
 
G_M000_IG33:                ;; offset=0x028E
       mov      rbx, rcx
       cmp      gword ptr [rbp-0x50], 0
       je       SHORT G_M000_IG34
       mov      rcx, rbx
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntimeException:get_OriginalPythonException():Lokad.Lython.Runtime.PyException:this]
       cmp      rax, gword ptr [rbp-0x50]
       je       SHORT G_M000_IG34
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntimeException:get_PythonContext():Lokad.Lython.Runtime.PyException:this]
       test     rax, rax
       jne      SHORT G_M000_IG34
       mov      rcx, rbx
       mov      rdx, gword ptr [rbp-0x50]
       call     [Lokad.Lython.Runtime.LythonRuntimeException:set_PythonContext(Lokad.Lython.Runtime.PyException):this]
 
G_M000_IG34:                ;; offset=0x02C4
       call     CORINFO_HELP_RETHROW
       int3     
 
G_M000_IG35:                ;; offset=0x02CA
       sub      rsp, 40
 
G_M000_IG36:                ;; offset=0x02CE
       mov      rcx, gword ptr [rbp+0x10]
       mov      rdx, gword ptr [rcx+0x28]
       mov      rbx, gword ptr [rdx+0xA0]
       lea      rcx, bword ptr [rbx+0x148]
       mov      rdx, gword ptr [rbp-0x50]
       call     CORINFO_HELP_ASSIGN_REF
       mov      rcx, gword ptr [rbp+0x10]
       mov      rax, gword ptr [rcx+0x28]
       mov      rcx, gword ptr [rax+0xA0]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.ExecutionState:LeaveFunctionCall():this]
       nop      
 
G_M000_IG37:                ;; offset=0x0305
       add      rsp, 40
       ret      
 
G_M000_IG38:                ;; offset=0x030A
       sub      rsp, 40
 
G_M000_IG39:                ;; offset=0x030E
       mov      rbx, rcx
       mov      rcx, gword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.PyFunctionBase:get_Closure():Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:this]
       mov      rsi, rax
       mov      rcx, gword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.PyFunctionBase:get_Name():System.String:this]
       mov      r8, rax
       mov      rdx, rsi
       mov      rcx, rbx
       mov      r9, gword ptr [rbp+0x28]
       call     [Lokad.Lython.Runtime.PyFunctionBinding:AnnotateException(Lokad.Lython.Runtime.LythonRuntimeException,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,System.String,Lokad.Lython.LythonSourceSpan)]
       call     CORINFO_HELP_RETHROW
       int3     
 
; Total bytes of code 833

; Assembly listing for method Lokad.Lython.Runtime.LythonRuntime:CompleteClosedDefinitionPair(Lokad.Lython.Frontend.ExecutableCodeObject,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,long,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]) (FullOpts)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; FullOpts code
; optimized code
; rsp based frame
; partially interruptible
; No PGO data
; 0 inlinees with PGO data; 9 single block inlinees; 2 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     r15
       push     r14
       push     r13
       push     r12
       push     rdi
       push     rsi
       push     rbp
       push     rbx
       sub      rsp, 72
       xor      eax, eax
       mov      qword ptr [rsp+0x40], rax
       mov      rsi, rcx
       mov      rbx, rdx
       mov      rdi, r8
 
G_M000_IG02:                ;; offset=0x0020
       mov      rbp, bword ptr [r9]
       mov      r14d, dword ptr [r9+0x08]
       lea      r9, [rsp+0x40]
       mov      rcx, rsi
       mov      rdx, rbx
       mov      r8, rdi
       call     [Lokad.Lython.Runtime.LythonRuntime:CreateClosedPairMember(Lokad.Lython.Frontend.ExecutableCodeObject,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,long,byref):Lokad.Lython.Runtime.PyFunctionBase]
       mov      r15, rax
       mov      r13, gword ptr [rsi+0x98]
       mov      ecx, dword ptr [rsp+0x40]
       mov      eax, dword ptr [rsp+0x40]
       inc      eax
       mov      dword ptr [rsp+0x40], eax
       mov      r12d, dword ptr [r13+0x08]
       cmp      ecx, r12d
       jae      G_M000_IG10
       shl      rcx, 5
       mov      rax, gword ptr [r13+rcx+0x10]
       mov      gword ptr [rsp+0x38], rax
       mov      rdx, gword ptr [rbx+0xA0]
       mov      gword ptr [rsp+0x30], rdx
       cmp      byte  ptr [rdx], dl
       mov      rcx, rdx
       call     [Lokad.Lython.Runtime.ExecutionState:get_CanContinue():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG04
 
G_M000_IG03:                ;; offset=0x0089
       mov      rcx, gword ptr [rsp+0x30]
       mov      rdx, gword ptr [rsp+0x38]
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
 
G_M000_IG04:                ;; offset=0x0099
       lea      r9, [rsp+0x40]
       mov      rcx, rsi
       mov      rdx, rbx
       mov      r8, rdi
       call     [Lokad.Lython.Runtime.LythonRuntime:CreateClosedPairMember(Lokad.Lython.Frontend.ExecutableCodeObject,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,long,byref):Lokad.Lython.Runtime.PyFunctionBase]
       mov      rsi, rax
       cmp      dword ptr [rsp+0x40], r12d
       jge      SHORT G_M000_IG08
 
G_M000_IG05:                ;; offset=0x00B7
       cmp      dword ptr [rsp+0x40], r12d
       jae      G_M000_IG10
       mov      ecx, dword ptr [rsp+0x40]
       shl      rcx, 5
       mov      rdi, gword ptr [r13+rcx+0x10]
       mov      rax, gword ptr [rbx+0xA0]
       mov      gword ptr [rsp+0x28], rax
       cmp      byte  ptr [rax], al
       mov      rcx, rax
       call     [Lokad.Lython.Runtime.ExecutionState:get_CanContinue():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG07
 
G_M000_IG06:                ;; offset=0x00EA
       mov      rcx, gword ptr [rsp+0x28]
       mov      rdx, rdi
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
 
G_M000_IG07:                ;; offset=0x00F8
       mov      ecx, dword ptr [rsp+0x40]
       inc      ecx
       mov      dword ptr [rsp+0x40], ecx
       cmp      dword ptr [rsp+0x40], r12d
       jl       SHORT G_M000_IG05
 
G_M000_IG08:                ;; offset=0x0109
       cmp      r14d, 1
       jbe      SHORT G_M000_IG10
       lea      rbx, bword ptr [rbp+0x10]
       mov      rcx, rbx
       mov      rdx, r15
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       xor      ecx, ecx
       mov      qword ptr [rbx+0x08], rcx
       mov      rcx, rbp
       mov      rdx, rsi
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       xor      eax, eax
       mov      qword ptr [rbp+0x08], rax
 
G_M000_IG09:                ;; offset=0x0135
       add      rsp, 72
       pop      rbx
       pop      rbp
       pop      rsi
       pop      rdi
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       ret      
 
G_M000_IG10:                ;; offset=0x0146
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
; Total bytes of code 332

; Assembly listing for method Lokad.Lython.Runtime.LythonRuntime:CreateClosedPairMember(Lokad.Lython.Frontend.ExecutableCodeObject,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,long,byref):Lokad.Lython.Runtime.PyFunctionBase (FullOpts)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; FullOpts code
; optimized code
; rbp based frame
; fully interruptible
; No PGO data
; 0 inlinees with PGO data; 42 single block inlinees; 6 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       push     r15
       push     r14
       push     r13
       push     r12
       push     rdi
       push     rsi
       push     rbx
       sub      rsp, 376
       lea      rbp, [rsp+0x1B0]
       xor      eax, eax
       mov      qword ptr [rbp-0xD8], rax
       vxorps   xmm4, xmm4, xmm4
       vmovdqu  ymmword ptr [rbp-0xD0], ymm4
       vmovdqu  ymmword ptr [rbp-0xB0], ymm4
       vmovdqu  ymmword ptr [rbp-0x90], ymm4
       vmovdqu  ymmword ptr [rbp-0x70], ymm4
       vmovdqa  xmmword ptr [rbp-0x50], xmm4
       mov      qword ptr [rbp-0x40], rax
       mov      gword ptr [rbp+0x18], rdx
       mov      rdi, rcx
       mov      rsi, rdx
       mov      r14, r8
       mov      rbx, r9
 
G_M000_IG02:                ;; offset=0x005E
       mov      r15, gword ptr [rdi+0x98]
       mov      r13d, dword ptr [rbx]
       lea      ecx, [r13+0x01]
       mov      dword ptr [rbx], ecx
       mov      r12d, dword ptr [r15+0x08]
       cmp      r13d, r12d
       jae      G_M000_IG59
       mov      ecx, r13d
       shl      rcx, 5
       lea      r13, bword ptr [r15+rcx+0x10]
       mov      rax, gword ptr [rdi+0x30]
       mov      gword ptr [rbp-0x138], rax
       mov      rcx, r13
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ConstantIndex():int:this]
       mov      rcx, gword ptr [rbp-0x138]
       cmp      eax, dword ptr [rcx+0x08]
       jae      G_M000_IG59
       mov      edx, eax
       mov      rdx, gword ptr [rcx+8*rdx+0x10]
       mov      rax, rdx
       test     rax, rax
       je       SHORT G_M000_IG04
 
G_M000_IG03:                ;; offset=0x00BA
       mov      rcx, 0x7FF9D75BABA8
       cmp      qword ptr [rax], rcx
       jne      G_M000_IG58
 
G_M000_IG04:                ;; offset=0x00CD
       mov      gword ptr [rbp-0xE0], rax
       mov      rcx, gword ptr [r13]
       mov      gword ptr [rsp+0x20], rcx
       lea      rcx, [rbp-0x50]
       mov      rdx, rax
       mov      r9, rsi
       xor      r8d, r8d
       call     [Lokad.Lython.Runtime.LythonRuntime:AllocateExecutableDefaults(Lokad.Lython.Frontend.FunctionParameterLayout,bool,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.FunctionDefaults]
       nop      
 
G_M000_IG05:                ;; offset=0x00F1
       xor      r13d, r13d
       mov      rax, gword ptr [rbp-0xE0]
       mov      rcx, gword ptr [rax+0x28]
       cmp      dword ptr [rcx+0x08], 0
       je       G_M000_IG27
 
G_M000_IG06:                ;; offset=0x0109
       mov      ecx, dword ptr [rbx]
       cmp      ecx, r12d
       jae      G_M000_IG55
       shl      rcx, 5
       lea      r10, bword ptr [r15+rcx+0x10]
       mov      bword ptr [rbp-0xE8], r10
       cmp      dword ptr [r10+0x1C], 1
       je       SHORT G_M000_IG08
 
G_M000_IG07:                ;; offset=0x012B
       mov      bword ptr [rsp+0x20], rbx
       lea      rcx, [rbp-0x60]
       mov      rdx, rdi
       mov      r8, r14
       mov      r9, rsi
       call     [Lokad.Lython.Runtime.LythonRuntime:EvaluateClosedDefault(Lokad.Lython.Frontend.ExecutableCodeObject,long,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]
       jmp      SHORT G_M000_IG10
 
G_M000_IG08:                ;; offset=0x0145
       inc      dword ptr [rbx]
       mov      rdx, gword ptr [r10]
       mov      gword ptr [rbp-0x108], rdx
       mov      r8, gword ptr [rsi+0xA0]
       mov      gword ptr [rbp-0x110], r8
       cmp      byte  ptr [r8], r8b
       mov      rcx, r8
       call     [Lokad.Lython.Runtime.ExecutionState:get_CanContinue():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG09
       mov      rcx, gword ptr [rbp-0x110]
       mov      rdx, gword ptr [rbp-0x108]
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
 
G_M000_IG09:                ;; offset=0x0183
       mov      rax, gword ptr [rdi+0x30]
       mov      gword ptr [rbp-0x140], rax
       mov      rcx, bword ptr [rbp-0xE8]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ConstantIndex():int:this]
       mov      rdx, gword ptr [rbp-0x140]
       cmp      eax, dword ptr [rdx+0x08]
       jae      G_M000_IG55
       mov      ecx, eax
       mov      rdx, gword ptr [rdx+8*rcx+0x10]
       mov      gword ptr [rbp-0x60], rdx
       xor      edx, edx
       mov      qword ptr [rbp-0x58], rdx
 
G_M000_IG10:                ;; offset=0x01BC
       mov      edx, dword ptr [rbx]
       lea      ecx, [rdx+0x01]
       mov      dword ptr [rbx], ecx
       cmp      edx, r12d
       jae      G_M000_IG55
       shl      rdx, 5
       lea      rax, bword ptr [r15+rdx+0x10]
       mov      bword ptr [rbp-0xF0], rax
       mov      r8, gword ptr [rbp-0xE0]
       cmp      r13d, dword ptr [r8+0x38]
       jl       G_M000_IG23
 
G_M000_IG11:                ;; offset=0x01ED
       mov      rdx, gword ptr [rbp-0x48]
       mov      rcx, 0x7FF9D7172560
       call     CORINFO_HELP_ISINSTANCEOFARRAY
       mov      gword ptr [rbp-0xF8], rax
       test     rax, rax
       jne      G_M000_IG17
       mov      rdx, bword ptr [rbp-0xF0]
       mov      rax, gword ptr [rdx]
       mov      gword ptr [rbp-0x120], rax
       mov      rdx, gword ptr [rsi+0xA0]
       mov      gword ptr [rbp-0x128], rdx
       cmp      byte  ptr [rdx], dl
       mov      rcx, rdx
       call     [Lokad.Lython.Runtime.ExecutionState:get_CanContinue():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG12
       mov      rcx, gword ptr [rbp-0x128]
       mov      rdx, gword ptr [rbp-0x120]
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
 
G_M000_IG12:                ;; offset=0x0252
       mov      rax, gword ptr [rbp-0x50]
       mov      gword ptr [rbp-0x130], rax
       movzx    rdx, byte  ptr [rbp-0x40]
       mov      byte  ptr [rbp-0x7C], dl
       mov      rcx, gword ptr [rbp-0x60]
       mov      r8, 0x26B2A801CF0
       cmp      rcx, gword ptr [r8]
       je       SHORT G_M000_IG15
       mov      r8, 0x26B2A801CF8
       cmp      rcx, gword ptr [r8]
       je       SHORT G_M000_IG14
       cmp      qword ptr [rbp-0x58], 0
       jne      SHORT G_M000_IG13
       jmp      SHORT G_M000_IG16
 
G_M000_IG13:                ;; offset=0x028F
       lea      rcx, [rbp-0x60]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishDeferredValue():System.Object:this]
       mov      rcx, rax
       jmp      SHORT G_M000_IG16
 
G_M000_IG14:                ;; offset=0x029E
       mov      rcx, 0x7FF9D71A6488
       call     CORINFO_HELP_NEWSFAST
       vmovsd   xmm0, qword ptr [rbp-0x58]
       vmovsd   qword ptr [rax+0x08], xmm0
       mov      rcx, rax
       mov      gword ptr [rbp-0x60], rcx
       xor      eax, eax
       mov      qword ptr [rbp-0x58], rax
       jmp      SHORT G_M000_IG16
 
G_M000_IG15:                ;; offset=0x02C6
       lea      rcx, [rbp-0x60]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishInteger():System.Object:this]
       mov      rcx, rax
 
G_M000_IG16:                ;; offset=0x02D3
       call     [Lokad.Lython.Runtime.LythonRuntime:RuntimeValue(System.Object):System.Object]
       mov      rcx, gword ptr [rbp-0x130]
       mov      gword ptr [rbp-0x50], rcx
       mov      gword ptr [rbp-0x48], rax
       movzx    rcx, byte  ptr [rbp-0x7C]
       mov      byte  ptr [rbp-0x40], cl
       jmp      G_M000_IG26
 
G_M000_IG17:                ;; offset=0x02F4
       mov      rdx, bword ptr [rbp-0xF0]
       mov      r8d, dword ptr [rdx+0x0C]
       mov      dword ptr [rbp-0x64], r8d
       mov      rcx, gword ptr [rbp-0x60]
       mov      r10, qword ptr [rbp-0x58]
       mov      r9, gword ptr [rsi+0xA0]
       mov      gword ptr [rbp-0x100], r9
       mov      gword ptr [rbp-0x78], rcx
       mov      qword ptr [rbp-0x70], r10
       mov      rdx, gword ptr [rdx]
       mov      gword ptr [rbp-0x118], rdx
       cmp      byte  ptr [r9], r9b
       mov      rcx, r9
       call     [Lokad.Lython.Runtime.ExecutionState:get_CanContinue():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG18
       mov      rcx, gword ptr [rbp-0x100]
       mov      rdx, gword ptr [rbp-0x118]
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
 
G_M000_IG18:                ;; offset=0x034F
       mov      rcx, gword ptr [rbp-0x78]
       mov      rax, 0x26B2A801CF0
       cmp      rcx, gword ptr [rax]
       je       SHORT G_M000_IG21
       mov      rcx, gword ptr [rbp-0x78]
       mov      rax, 0x26B2A801CF8
       cmp      rcx, gword ptr [rax]
       je       SHORT G_M000_IG20
       cmp      qword ptr [rbp-0x70], 0
       jne      SHORT G_M000_IG19
       mov      rcx, gword ptr [rbp-0x78]
       jmp      SHORT G_M000_IG22
 
G_M000_IG19:                ;; offset=0x0382
       lea      rcx, [rbp-0x78]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishDeferredValue():System.Object:this]
       mov      rcx, rax
       jmp      SHORT G_M000_IG22
 
G_M000_IG20:                ;; offset=0x0391
       mov      rcx, 0x7FF9D71A6488
       call     CORINFO_HELP_NEWSFAST
       vmovsd   xmm0, qword ptr [rbp-0x70]
       vmovsd   qword ptr [rax+0x08], xmm0
       mov      rcx, rax
       mov      gword ptr [rbp-0x78], rcx
       xor      eax, eax
       mov      qword ptr [rbp-0x70], rax
       jmp      SHORT G_M000_IG22
 
G_M000_IG21:                ;; offset=0x03B9
       lea      rcx, [rbp-0x78]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishInteger():System.Object:this]
       mov      rcx, rax
 
G_M000_IG22:                ;; offset=0x03C6
       call     [Lokad.Lython.Runtime.LythonRuntime:RuntimeValue(System.Object):System.Object]
       mov      r8, rax
       movsxd   rdx, dword ptr [rbp-0x64]
       mov      rcx, gword ptr [rbp-0xF8]
       call     CORINFO_HELP_ARRADDR_ST
       jmp      SHORT G_M000_IG26
 
G_M000_IG23:                ;; offset=0x03E1
       mov      rcx, gword ptr [rbp-0x50]
       mov      rax, bword ptr [rbp-0xF0]
       mov      edx, dword ptr [rax+0x0C]
 
G_M000_IG24:                ;; offset=0x03EF
       vmovdqu  xmm0, xmmword ptr [rbp-0x60]
       vmovdqu  xmmword ptr [rbp-0x90], xmm0
 
G_M000_IG25:                ;; offset=0x03FC
       mov      r9, gword ptr [rax]
       mov      gword ptr [rsp+0x20], r9
       lea      r8, [rbp-0x90]
       mov      r9, gword ptr [rsi+0xA0]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.PyTuple:SetPrivateDefault(int,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot,Lokad.Lython.Runtime.ExecutionState,Lokad.Lython.LythonSourceSpan):this]
 
G_M000_IG26:                ;; offset=0x041A
       inc      r13d
       mov      rax, gword ptr [rbp-0xE0]
       mov      rcx, gword ptr [rax+0x28]
       cmp      dword ptr [rcx+0x08], r13d
       jg       G_M000_IG06
 
G_M000_IG27:                ;; offset=0x0432
       mov      edx, dword ptr [rbx]
       lea      ecx, [rdx+0x01]
       mov      dword ptr [rbx], ecx
       cmp      edx, r12d
       jae      G_M000_IG55
       mov      ecx, edx
       shl      rcx, 5
       lea      rbx, bword ptr [r15+rcx+0x10]
       mov      r14, gword ptr [rbx]
       mov      r15, gword ptr [rsi+0xA0]
       cmp      byte  ptr [r15], r15b
       mov      rcx, r15
       call     [Lokad.Lython.Runtime.ExecutionState:get_CanContinue():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG29
 
G_M000_IG28:                ;; offset=0x0467
       mov      rcx, r15
       mov      rdx, r14
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
 
G_M000_IG29:                ;; offset=0x0473
       mov      r14, gword ptr [rdi+0x30]
       mov      rcx, rbx
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ConstantIndex():int:this]
       cmp      eax, dword ptr [r14+0x08]
       jae      G_M000_IG55
       mov      r8d, eax
       mov      rdx, gword ptr [r14+8*r8+0x10]
       mov      r14, rdx
       test     r14, r14
       je       G_M000_IG42
 
G_M000_IG30:                ;; offset=0x049E
       mov      r8, 0x7FF9D7665060
       cmp      qword ptr [r14], r8
       jne      G_M000_IG42
 
G_M000_IG31:                ;; offset=0x04B1
       mov      r8, gword ptr [r14+0x30]
       test     r8, r8
       je       SHORT G_M000_IG34
       mov      r9, gword ptr [rbx]
 
G_M000_IG32:                ;; offset=0x04BD
       vmovdqu  xmm0, xmmword ptr [rbp-0x50]
       vmovdqu  xmmword ptr [rbp-0xA8], xmm0
       mov      rcx, qword ptr [rbp-0x40]
       mov      qword ptr [rbp-0x98], rcx
 
G_M000_IG33:                ;; offset=0x04D5
       mov      gword ptr [rsp+0x20], r9
       lea      r9, [rbp-0xA8]
       mov      qword ptr [rsp+0x28], r9
       mov      r9, rsi
       mov      rcx, r14
       mov      rdx, rdi
       call     [Lokad.Lython.Runtime.LythonRuntime:CreateClosedEagerDefinition(Lokad.Lython.Frontend.ExecutableCreateFunction,Lokad.Lython.Frontend.ExecutableCodeObject,Lokad.Lython.Frontend.ExecutableInstruction[],Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.FunctionDefaults):Lokad.Lython.Runtime.PyFunctionBase]
       mov      rdi, rax
       jmp      G_M000_IG53
 
G_M000_IG34:                ;; offset=0x04FD
       mov      rdi, gword ptr [r14+0x08]
       mov      rcx, rsi
       call     [Lokad.Lython.Runtime.LythonRuntime:GetGlobalContext(Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):Lokad.Lython.Runtime.LythonRuntime+ExecutionContext]
       mov      r8, rax
       mov      rdx, gword ptr [rbp-0x50]
       mov      rcx, gword ptr [rbp-0x48]
       movzx    r9, byte  ptr [rbp-0x40]
       mov      rax, gword ptr [rbx]
       mov      r10, gword ptr [r14+0x28]
       mov      gword ptr [rbp-0xA8], rdx
       mov      gword ptr [rbp-0xA0], rcx
       mov      byte  ptr [rbp-0x98], r9b
       xor      edx, edx
       mov      dword ptr [rsp+0x28], edx
       mov      gword ptr [rsp+0x30], rsi
       mov      gword ptr [rsp+0x38], rax
 
G_M000_IG35:                ;; offset=0x0546
       mov      bword ptr [rbp-0xB8], rdx
 
G_M000_IG36:                ;; offset=0x054D
       mov      dword ptr [rbp-0xB0], edx
       mov      gword ptr [rsp+0x48], r10
 
G_M000_IG37:                ;; offset=0x0558
       mov      gword ptr [rbp-0xC8], rdx
 
G_M000_IG38:                ;; offset=0x055F
       mov      dword ptr [rbp-0xC0], edx
       mov      byte  ptr [rbp-0xBC], 0
 
G_M000_IG39:                ;; offset=0x056C
       mov      dword ptr [rsp+0x58], edx
 
G_M000_IG40:                ;; offset=0x0570
       mov      bword ptr [rbp-0xD8], rdx
 
G_M000_IG41:                ;; offset=0x0577
       mov      dword ptr [rbp-0xD0], edx
       lea      rdx, [rbp-0xC8]
       mov      qword ptr [rsp+0x50], rdx
       lea      rdx, [rbp-0xA8]
       mov      qword ptr [rsp+0x20], rdx
       lea      rdx, [rbp-0xD8]
       mov      qword ptr [rsp+0x60], rdx
       lea      rdx, [rbp-0xB8]
       mov      qword ptr [rsp+0x40], rdx
       mov      rdx, rdi
       mov      rcx, gword ptr [rbp-0xE0]
       xor      r9, r9
       call     [Lokad.Lython.Runtime.LythonRuntime:CreateFunctionValue(Lokad.Lython.Frontend.FunctionParameterLayout,Lokad.Lython.Frontend.ExecutableCodeObject,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutableCaptures,Lokad.Lython.Runtime.FunctionDefaults,bool,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],Lokad.Lython.Runtime.Text.PyString[],System.ValueTuple`3[System.Object,int,bool],bool,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):Lokad.Lython.Runtime.PyFunctionBase]
       mov      rdi, rax
       jmp      G_M000_IG53
 
G_M000_IG42:                ;; offset=0x05C8
       mov      rcx, r14
       test     rcx, rcx
       je       SHORT G_M000_IG44
 
G_M000_IG43:                ;; offset=0x05D0
       mov      rax, 0x7FF9D7686648
       cmp      qword ptr [rcx], rax
       jne      G_M000_IG54
 
G_M000_IG44:                ;; offset=0x05E3
       mov      rdi, gword ptr [rcx+0x08]
       mov      rcx, rsi
       call     [Lokad.Lython.Runtime.LythonRuntime:GetGlobalContext(Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):Lokad.Lython.Runtime.LythonRuntime+ExecutionContext]
       mov      r8, rax
       mov      rdx, gword ptr [rbp-0x50]
       mov      rcx, gword ptr [rbp-0x48]
       movzx    r9, byte  ptr [rbp-0x40]
       mov      rax, gword ptr [rbx]
       mov      gword ptr [rbp-0xA8], rdx
       mov      gword ptr [rbp-0xA0], rcx
       mov      byte  ptr [rbp-0x98], r9b
       xor      edx, edx
       mov      dword ptr [rsp+0x28], edx
       mov      gword ptr [rsp+0x30], rsi
       mov      gword ptr [rsp+0x38], rax
 
G_M000_IG45:                ;; offset=0x0628
       mov      bword ptr [rbp-0xB8], rdx
 
G_M000_IG46:                ;; offset=0x062F
       mov      dword ptr [rbp-0xB0], edx
 
G_M000_IG47:                ;; offset=0x0635
       mov      gword ptr [rsp+0x48], rdx
 
G_M000_IG48:                ;; offset=0x063A
       mov      gword ptr [rbp-0xC8], rdx
 
G_M000_IG49:                ;; offset=0x0641
       mov      dword ptr [rbp-0xC0], edx
       mov      byte  ptr [rbp-0xBC], 0
 
G_M000_IG50:                ;; offset=0x064E
       mov      dword ptr [rsp+0x58], edx
 
G_M000_IG51:                ;; offset=0x0652
       mov      bword ptr [rbp-0xD8], rdx
 
G_M000_IG52:                ;; offset=0x0659
       mov      dword ptr [rbp-0xD0], edx
       lea      rdx, [rbp-0xD8]
       mov      qword ptr [rsp+0x60], rdx
       lea      rdx, [rbp-0xA8]
       mov      qword ptr [rsp+0x20], rdx
       lea      rdx, [rbp-0xC8]
       mov      qword ptr [rsp+0x50], rdx
       lea      rdx, [rbp-0xB8]
       mov      qword ptr [rsp+0x40], rdx
       mov      rdx, rdi
       mov      rcx, gword ptr [rbp-0xE0]
       xor      r9, r9
       call     [Lokad.Lython.Runtime.LythonRuntime:CreateFunctionValue(Lokad.Lython.Frontend.FunctionParameterLayout,Lokad.Lython.Frontend.ExecutableCodeObject,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutableCaptures,Lokad.Lython.Runtime.FunctionDefaults,bool,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],Lokad.Lython.Runtime.Text.PyString[],System.ValueTuple`3[System.Object,int,bool],bool,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):Lokad.Lython.Runtime.PyFunctionBase]
       mov      rdi, rax
 
G_M000_IG53:                ;; offset=0x06A5
       vxorps   xmm0, xmm0, xmm0
       vmovdqu  xmmword ptr [rbp-0x50], xmm0
       vmovdqu  xmmword ptr [rbp-0x48], xmm0
       jmp      SHORT G_M000_IG56
 
G_M000_IG54:                ;; offset=0x06B5
       mov      rdx, r14
       mov      rcx, rax
       call     CORINFO_HELP_CHKCASTCLASS
       int3     
 
G_M000_IG55:                ;; offset=0x06C1
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG56:                ;; offset=0x06C7
       mov      rdx, gword ptr [rsi+0xA0]
       mov      rdx, gword ptr [rdx+0x88]
       lea      rcx, [rbp-0x50]
       call     [Lokad.Lython.Runtime.FunctionDefaults:RefundUnpublished(Lokad.Lython.Runtime.MemoryGovernor):this]
       mov      rax, rdi
 
G_M000_IG57:                ;; offset=0x06E2
       add      rsp, 376
       pop      rbx
       pop      rsi
       pop      rdi
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG58:                ;; offset=0x06F6
       call     CORINFO_HELP_CHKCASTCLASS
       int3     
 
G_M000_IG59:                ;; offset=0x06FC
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG60:                ;; offset=0x0702
       sub      rsp, 104
 
G_M000_IG61:                ;; offset=0x0706
       mov      rsi, gword ptr [rbp+0x18]
       mov      rdx, gword ptr [rsi+0xA0]
       mov      rdx, gword ptr [rdx+0x88]
       lea      rcx, [rbp-0x50]
       call     [Lokad.Lython.Runtime.FunctionDefaults:RefundUnpublished(Lokad.Lython.Runtime.MemoryGovernor):this]
       nop      
 
G_M000_IG62:                ;; offset=0x0723
       add      rsp, 104
       ret      
 
; Total bytes of code 1832

; Assembly listing for method Lokad.Lython.Runtime.LythonRuntime:EvaluateClosedDefault(Lokad.Lython.Frontend.ExecutableCodeObject,long,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot (FullOpts)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; FullOpts code
; optimized code
; rsp based frame
; partially interruptible
; No PGO data
; 1 inlinees with PGO data; 21 single block inlinees; 8 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     r15
       push     r14
       push     r13
       push     r12
       push     rdi
       push     rsi
       push     rbp
       push     rbx
       sub      rsp, 168
       vxorps   xmm4, xmm4, xmm4
       vmovdqu  ymmword ptr [rsp+0x30], ymm4
       vmovdqu  ymmword ptr [rsp+0x50], ymm4
       vmovdqu  ymmword ptr [rsp+0x70], ymm4
       vmovdqa  xmmword ptr [rsp+0x90], xmm4
       xor      eax, eax
       mov      qword ptr [rsp+0xA0], rax
       mov      rdi, rcx
       mov      rsi, r9
       mov      rbx, bword ptr [rsp+0x110]
 
G_M000_IG02:                ;; offset=0x004A
       mov      qword ptr [rsp+0xA0], r8
       mov      gword ptr [rsp+0x98], rdx
       jmp      G_M000_IG24
 
G_M000_IG03:                ;; offset=0x005F
       mov      r14d, dword ptr [rbp+0x08]
       and      r14d, 0x7FFFFFFF
 
G_M000_IG04:                ;; offset=0x006A
       mov      ecx, dword ptr [rbp+0x10]
       lea      rdx, [rsp+0x88]
       lea      r8, [rsp+0x80]
       lea      r9, [rsp+0x98]
       call     [Lokad.Lython.Runtime.LythonRuntime:<EvaluateClosedDefault>g__TryReadInteger|824_0(int,byref,byref,byref):bool]
       test     eax, eax
       je       SHORT G_M000_IG06
 
G_M000_IG05:                ;; offset=0x008F
       mov      ecx, dword ptr [rbp+0x0C]
       lea      rdx, [rsp+0x88]
       lea      r8, [rsp+0x78]
       lea      r9, [rsp+0x98]
       call     [Lokad.Lython.Runtime.LythonRuntime:<EvaluateClosedDefault>g__TryReadInteger|824_0(int,byref,byref,byref):bool]
       test     eax, eax
       je       SHORT G_M000_IG06
       lea      r9, [rsp+0x70]
       mov      ecx, r14d
       mov      rdx, qword ptr [rsp+0x80]
       mov      r8, qword ptr [rsp+0x78]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryMachineBinary(int,long,long,byref):bool]
       test     eax, eax
       jne      G_M000_IG37
       lea      ecx, [r14-0x0F]
       cmp      ecx, 5
       jbe      G_M000_IG29
 
G_M000_IG06:                ;; offset=0x00E1
       mov      r15d, dword ptr [rbp+0x10]
 
G_M000_IG07:                ;; offset=0x00E5
       vmovdqu  xmm0, xmmword ptr [rsp+0x88]
       vmovdqu  xmmword ptr [rsp+0x60], xmm0
 
G_M000_IG08:                ;; offset=0x00F4
       test     r15d, r15d
       jne      SHORT G_M000_IG09
       mov      rcx, 0x7FF9D754FD50
       call     CORINFO_HELP_NEWSFAST
       mov      r13, rax
       mov      rdx, qword ptr [rsp+0xA0]
       vxorps   xmm0, xmm0, xmm0
       vmovdqu  xmmword ptr [rsp+0x50], xmm0
       lea      rcx, [rsp+0x50]
       call     [System.Numerics.BigInteger:.ctor(long):this]
       lea      rcx, bword ptr [r13+0x08]
       mov      rdx, gword ptr [rsp+0x50]
       call     CORINFO_HELP_ASSIGN_REF
       mov      ecx, dword ptr [rsp+0x58]
       mov      dword ptr [r13+0x10], ecx
       jmp      G_M000_IG14
 
G_M000_IG09:                ;; offset=0x0143
       test     r15d, r15d
       jge      SHORT G_M000_IG10
       mov      rcx, gword ptr [rsp+0x98]
       mov      rcx, gword ptr [rcx+0x30]
       mov      eax, r15d
       not      eax
       cmp      eax, dword ptr [rcx+0x08]
       jae      G_M000_IG40
       mov      eax, r15d
       not      eax
       mov      r13, gword ptr [rcx+8*rax+0x10]
       jmp      G_M000_IG14
 
G_M000_IG10:                ;; offset=0x0171
       mov      rcx, gword ptr [rsp+0x60]
       mov      rax, 0x26B2A801CF0
       cmp      rcx, gword ptr [rax]
       je       SHORT G_M000_IG13
       mov      rcx, gword ptr [rsp+0x60]
       mov      rax, 0x26B2A801CF8
       cmp      rcx, gword ptr [rax]
       je       SHORT G_M000_IG12
       cmp      qword ptr [rsp+0x68], 0
       jne      SHORT G_M000_IG11
       mov      r13, gword ptr [rsp+0x60]
       jmp      SHORT G_M000_IG14
 
G_M000_IG11:                ;; offset=0x01A8
       lea      rcx, [rsp+0x60]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishDeferredValue():System.Object:this]
       mov      r13, rax
       jmp      SHORT G_M000_IG14
 
G_M000_IG12:                ;; offset=0x01B8
       mov      rcx, 0x7FF9D71A6488
       call     CORINFO_HELP_NEWSFAST
       vmovsd   xmm0, qword ptr [rsp+0x68]
       vmovsd   qword ptr [rax+0x08], xmm0
       mov      r13, rax
       mov      gword ptr [rsp+0x60], r13
       xor      ecx, ecx
       mov      qword ptr [rsp+0x68], rcx
       jmp      SHORT G_M000_IG14
 
G_M000_IG13:                ;; offset=0x01E3
       lea      rcx, [rsp+0x60]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishInteger():System.Object:this]
       mov      r13, rax
 
G_M000_IG14:                ;; offset=0x01F1
       mov      r15d, dword ptr [rbp+0x0C]
 
G_M000_IG15:                ;; offset=0x01F5
       vmovdqu  xmm0, xmmword ptr [rsp+0x88]
       vmovdqu  xmmword ptr [rsp+0x40], xmm0
 
G_M000_IG16:                ;; offset=0x0204
       test     r15d, r15d
       jne      SHORT G_M000_IG17
       mov      rcx, 0x7FF9D754FD50
       call     CORINFO_HELP_NEWSFAST
       mov      r12, rax
       mov      rdx, qword ptr [rsp+0xA0]
       vxorps   xmm0, xmm0, xmm0
       vmovdqu  xmmword ptr [rsp+0x30], xmm0
       lea      rcx, [rsp+0x30]
       call     [System.Numerics.BigInteger:.ctor(long):this]
       lea      rcx, bword ptr [r12+0x08]
       mov      rdx, gword ptr [rsp+0x30]
       call     CORINFO_HELP_ASSIGN_REF
       mov      ecx, dword ptr [rsp+0x38]
       mov      dword ptr [r12+0x10], ecx
       mov      r8, r12
       jmp      G_M000_IG22
 
G_M000_IG17:                ;; offset=0x0258
       test     r15d, r15d
       jge      SHORT G_M000_IG18
       mov      r8, gword ptr [rsp+0x98]
       mov      rcx, gword ptr [r8+0x30]
       mov      eax, r15d
       not      eax
       cmp      eax, dword ptr [rcx+0x08]
       jae      G_M000_IG40
       mov      eax, r15d
       not      eax
       mov      r8, gword ptr [rcx+8*rax+0x10]
       jmp      G_M000_IG22
 
G_M000_IG18:                ;; offset=0x0286
       mov      rcx, gword ptr [rsp+0x40]
       mov      rax, 0x26B2A801CF0
       cmp      rcx, gword ptr [rax]
       je       SHORT G_M000_IG21
       mov      rcx, gword ptr [rsp+0x40]
       mov      rax, 0x26B2A801CF8
       cmp      rcx, gword ptr [rax]
       je       SHORT G_M000_IG20
       cmp      qword ptr [rsp+0x48], 0
       jne      SHORT G_M000_IG19
       mov      r8, gword ptr [rsp+0x40]
       jmp      SHORT G_M000_IG22
 
G_M000_IG19:                ;; offset=0x02BD
       lea      rcx, [rsp+0x40]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishDeferredValue():System.Object:this]
       mov      r8, rax
       jmp      SHORT G_M000_IG22
 
G_M000_IG20:                ;; offset=0x02CD
       mov      rcx, 0x7FF9D71A6488
       call     CORINFO_HELP_NEWSFAST
       vmovsd   xmm0, qword ptr [rsp+0x48]
       vmovsd   qword ptr [rax+0x08], xmm0
       mov      r8, rax
       mov      gword ptr [rsp+0x40], r8
       xor      ecx, ecx
       mov      qword ptr [rsp+0x48], rcx
       jmp      SHORT G_M000_IG22
 
G_M000_IG21:                ;; offset=0x02F8
       lea      rcx, [rsp+0x40]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishInteger():System.Object:this]
       mov      r8, rax
 
G_M000_IG22:                ;; offset=0x0306
       mov      rcx, gword ptr [rbp]
       mov      gword ptr [rsp+0x20], rcx
       mov      ecx, r14d
       mov      rdx, r13
       mov      r9, rsi
       call     [Lokad.Lython.Runtime.LythonRuntime:EvaluateBinaryOperator(int,System.Object,System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):System.Object]
       mov      gword ptr [rsp+0x88], rax
 
G_M000_IG23:                ;; offset=0x0326
       xor      eax, eax
       mov      qword ptr [rsp+0x90], rax
 
G_M000_IG24:                ;; offset=0x0330
       mov      rcx, gword ptr [rsp+0x98]
       mov      rcx, gword ptr [rcx+0x98]
       mov      eax, dword ptr [rbx]
       mov      edx, eax
       cmp      edx, dword ptr [rcx+0x08]
       jae      G_M000_IG40
       shl      rdx, 5
       lea      rbp, bword ptr [rcx+rdx+0x10]
       cmp      dword ptr [rbp+0x1C], 46
       jne      G_M000_IG38
 
G_M000_IG25:                ;; offset=0x035F
       inc      eax
       mov      dword ptr [rbx], eax
       mov      r14, gword ptr [rbp]
       mov      r15, gword ptr [rsi+0xA0]
       cmp      byte  ptr [r15], r15b
       mov      rcx, r15
       call     [Lokad.Lython.Runtime.ExecutionState:get_CanContinue():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG27
 
G_M000_IG26:                ;; offset=0x037E
       mov      rcx, r15
       mov      rdx, r14
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
 
G_M000_IG27:                ;; offset=0x038A
       cmp      dword ptr [rbp+0x1C], 51
       jne      G_M000_IG03
 
G_M000_IG28:                ;; offset=0x0394
       mov      r14d, dword ptr [rbp+0x14]
       jmp      G_M000_IG04
 
G_M000_IG29:                ;; offset=0x039D
       mov      rcx, qword ptr [rsp+0x78]
       cmp      qword ptr [rsp+0x80], rcx
       jge      SHORT G_M000_IG32
 
G_M000_IG30:                ;; offset=0x03AC
       mov      edx, -1
 
G_M000_IG31:                ;; offset=0x03B1
       mov      ecx, r14d
       call     [Lokad.Lython.Runtime.LythonRuntime:CompareOrderedResult(int,int):bool]
       test     eax, eax
       jne      SHORT G_M000_IG35
       mov      rax, 0x26B2A8013C8
       mov      rax, gword ptr [rax]
       jmp      SHORT G_M000_IG36
 
G_M000_IG32:                ;; offset=0x03CD
       cmp      qword ptr [rsp+0x80], rcx
       jle      SHORT G_M000_IG34
 
G_M000_IG33:                ;; offset=0x03D7
       mov      edx, 1
       jmp      SHORT G_M000_IG31
 
G_M000_IG34:                ;; offset=0x03DE
       xor      edx, edx
       jmp      SHORT G_M000_IG31
 
G_M000_IG35:                ;; offset=0x03E2
       mov      rax, 0x26B2A8013C0
       mov      rax, gword ptr [rax]
 
G_M000_IG36:                ;; offset=0x03EF
       mov      gword ptr [rsp+0x88], rax
       jmp      G_M000_IG23
 
G_M000_IG37:                ;; offset=0x03FC
       mov      rax, qword ptr [rsp+0x70]
       mov      rcx, 0x26B2A801CF0
       mov      rcx, gword ptr [rcx]
       mov      gword ptr [rsp+0x88], rcx
       mov      qword ptr [rsp+0x90], rax
       jmp      G_M000_IG24
 
G_M000_IG38:                ;; offset=0x0423
       mov      rax, gword ptr [rsp+0x88]
       mov      gword ptr [rdi], rax
       mov      rax, qword ptr [rsp+0x90]
       mov      qword ptr [rdi+0x08], rax
       mov      rax, rdi
 
G_M000_IG39:                ;; offset=0x043D
       add      rsp, 168
       pop      rbx
       pop      rbp
       pop      rsi
       pop      rdi
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       ret      
 
G_M000_IG40:                ;; offset=0x0451
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
; Total bytes of code 1111

; Assembly listing for method Lokad.Lython.Runtime.LythonRuntime:CreateClosedComputedDefinition(Lokad.Lython.Frontend.ExecutableCreateFunction,Lokad.Lython.Frontend.ExecutableCodeObject,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,long,System.Object):Lokad.Lython.Runtime.PyFunctionBase (FullOpts)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; FullOpts code
; optimized code
; rbp based frame
; fully interruptible
; No PGO data
; 0 inlinees with PGO data; 30 single block inlinees; 5 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       push     r15
       push     r14
       push     r13
       push     r12
       push     rdi
       push     rsi
       push     rbx
       sub      rsp, 280
       lea      rbp, [rsp+0x150]
       xor      eax, eax
       mov      qword ptr [rbp-0xC8], rax
       vxorps   xmm4, xmm4, xmm4
       vmovdqu  ymmword ptr [rbp-0xC0], ymm4
       vmovdqu  ymmword ptr [rbp-0xA0], ymm4
       vmovdqu  ymmword ptr [rbp-0x80], ymm4
       vmovdqu  ymmword ptr [rbp-0x60], ymm4
       mov      qword ptr [rbp-0x40], rax
       mov      gword ptr [rbp+0x20], r8
       mov      rsi, rcx
       mov      rdi, rdx
       mov      rbx, r8
       mov      r14, r9
       mov      r15, gword ptr [rbp+0x30]
 
G_M000_IG02:                ;; offset=0x005A
       mov      r13, gword ptr [rdi+0x98]
       mov      rdx, gword ptr [rsi+0x10]
       mov      r12d, dword ptr [r13+0x08]
       test     r12d, r12d
       je       G_M000_IG31
       mov      rcx, gword ptr [r13+0x10]
       mov      gword ptr [rsp+0x20], rcx
       lea      rcx, [rbp-0x50]
       mov      r9, rbx
       xor      r8d, r8d
       call     [Lokad.Lython.Runtime.LythonRuntime:AllocateExecutableDefaults(Lokad.Lython.Frontend.FunctionParameterLayout,bool,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.FunctionDefaults]
       mov      rcx, gword ptr [rbp-0x50]
       mov      gword ptr [rbp-0xE0], rcx
       mov      rcx, gword ptr [rbp-0x48]
       mov      gword ptr [rbp-0xE8], rcx
       movzx    rcx, byte  ptr [rbp-0x40]
       mov      dword ptr [rbp-0x7C], ecx
 
G_M000_IG03:                ;; offset=0x00A8
       mov      dword ptr [rbp-0x58], 1
       lea      rcx, [rbp-0x58]
       mov      qword ptr [rsp+0x20], rcx
       lea      rcx, [rbp-0x68]
       mov      rdx, rdi
       mov      r8, r14
       mov      r9, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime:EvaluateClosedDefault(Lokad.Lython.Frontend.ExecutableCodeObject,long,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]
       mov      r9, gword ptr [rbx+0xA0]
       mov      r8d, dword ptr [rbp-0x58]
       mov      ecx, dword ptr [rbp-0x58]
       inc      ecx
       mov      dword ptr [rbp-0x58], ecx
       cmp      r8d, r12d
       jae      G_M000_IG28
       shl      r8, 5
       mov      r8, gword ptr [r13+r8+0x10]
       mov      gword ptr [rsp+0x20], r8
       lea      r8, [rbp-0x68]
       mov      rcx, gword ptr [rbp-0xE0]
       xor      edx, edx
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.PyTuple:SetPrivateDefault(int,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot,Lokad.Lython.Runtime.ExecutionState,Lokad.Lython.LythonSourceSpan):this]
       test     r15, r15
       je       SHORT G_M000_IG05
 
G_M000_IG04:                ;; offset=0x010F
       mov      ecx, dword ptr [rbp-0x58]
       mov      eax, dword ptr [rbp-0x58]
       inc      eax
       mov      dword ptr [rbp-0x58], eax
       cmp      ecx, r12d
       jae      G_M000_IG28
       shl      rcx, 5
       mov      r14, gword ptr [r13+rcx+0x10]
       mov      rax, gword ptr [rbx+0xA0]
       mov      gword ptr [rbp-0xD0], rax
       cmp      byte  ptr [rax], al
       mov      rcx, rax
       call     [Lokad.Lython.Runtime.ExecutionState:get_CanContinue():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG06
       mov      rcx, gword ptr [rbp-0xD0]
       mov      rdx, r14
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
       jmp      SHORT G_M000_IG06
 
G_M000_IG05:                ;; offset=0x015B
       lea      rcx, [rbp-0x58]
       mov      qword ptr [rsp+0x20], rcx
       lea      rcx, [rbp-0x78]
       mov      rdx, rdi
       mov      r8, r14
       mov      r9, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime:EvaluateClosedDefault(Lokad.Lython.Frontend.ExecutableCodeObject,long,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]
 
G_M000_IG06:                ;; offset=0x0177
       mov      ecx, dword ptr [rbp-0x58]
       mov      eax, dword ptr [rbp-0x58]
       inc      eax
       mov      dword ptr [rbp-0x58], eax
       cmp      ecx, r12d
       jae      G_M000_IG28
       shl      rcx, 5
       mov      r14, gword ptr [r13+rcx+0x10]
       mov      rax, gword ptr [rbx+0xA0]
       mov      gword ptr [rbp-0xD8], rax
       cmp      byte  ptr [rax], al
       mov      rcx, rax
       call     [Lokad.Lython.Runtime.ExecutionState:get_CanContinue():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG08
 
G_M000_IG07:                ;; offset=0x01B1
       mov      rcx, gword ptr [rbp-0xD8]
       mov      rdx, r14
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
 
G_M000_IG08:                ;; offset=0x01C1
       mov      rcx, r15
       test     rcx, rcx
       jne      SHORT G_M000_IG13
 
G_M000_IG09:                ;; offset=0x01C9
       mov      rcx, gword ptr [rbp-0x78]
       mov      rax, 0x26B2A801CF0
       cmp      rcx, gword ptr [rax]
       je       SHORT G_M000_IG12
       mov      rax, 0x26B2A801CF8
       cmp      rcx, gword ptr [rax]
       je       SHORT G_M000_IG11
       cmp      qword ptr [rbp-0x70], 0
       jne      SHORT G_M000_IG10
       jmp      SHORT G_M000_IG13
 
G_M000_IG10:                ;; offset=0x01F4
       lea      rcx, [rbp-0x78]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishDeferredValue():System.Object:this]
       mov      rcx, rax
       jmp      SHORT G_M000_IG13
 
G_M000_IG11:                ;; offset=0x0203
       lea      rcx, [rbp-0x78]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishDouble():System.Object:this]
       mov      rcx, rax
       jmp      SHORT G_M000_IG13
 
G_M000_IG12:                ;; offset=0x0212
       lea      rcx, [rbp-0x78]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishInteger():System.Object:this]
       mov      rcx, rax
 
G_M000_IG13:                ;; offset=0x021F
       call     [Lokad.Lython.Runtime.LythonRuntime:RuntimeValue(System.Object):System.Object]
       mov      r14, rax
       mov      rcx, gword ptr [rbp-0xE0]
       mov      gword ptr [rbp-0xE0], rcx
       mov      gword ptr [rbp-0xE8], r14
       movzx    rcx, byte  ptr [rbp-0x7C]
       mov      dword ptr [rbp-0x7C], ecx
       cmp      dword ptr [rbp-0x58], r12d
       jae      G_M000_IG28
       mov      ecx, dword ptr [rbp-0x58]
       shl      rcx, 5
       mov      r15, gword ptr [r13+rcx+0x10]
       mov      r13, gword ptr [rbx+0xA0]
       cmp      byte  ptr [r13], r13b
       mov      rcx, r13
       call     [Lokad.Lython.Runtime.ExecutionState:get_CanContinue():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG15
 
G_M000_IG14:                ;; offset=0x0272
       mov      rcx, r13
       mov      rdx, r15
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
 
G_M000_IG15:                ;; offset=0x027E
       mov      r8, gword ptr [rsi+0x30]
       test     r8, r8
       je       SHORT G_M000_IG17
 
G_M000_IG16:                ;; offset=0x0287
       mov      rcx, gword ptr [rbp-0xE0]
       mov      gword ptr [rbp-0x50], rcx
       mov      gword ptr [rbp-0x48], r14
       mov      ecx, dword ptr [rbp-0x7C]
       mov      byte  ptr [rbp-0x40], cl
       mov      gword ptr [rsp+0x20], r15
       lea      rcx, [rbp-0x50]
       mov      qword ptr [rsp+0x28], rcx
       mov      rcx, rsi
       mov      rdx, rdi
       mov      r9, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime:CreateClosedEagerDefinition(Lokad.Lython.Frontend.ExecutableCreateFunction,Lokad.Lython.Frontend.ExecutableCodeObject,Lokad.Lython.Frontend.ExecutableInstruction[],Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.FunctionDefaults):Lokad.Lython.Runtime.PyFunctionBase]
       jmp      G_M000_IG25
 
G_M000_IG17:                ;; offset=0x02BE
       mov      rdi, gword ptr [rsi+0x10]
       mov      r13, gword ptr [rsi+0x08]
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime:GetGlobalContext(Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):Lokad.Lython.Runtime.LythonRuntime+ExecutionContext]
       mov      r8, rax
       mov      rdx, gword ptr [rsi+0x28]
       mov      rcx, gword ptr [rbp-0xE0]
       mov      gword ptr [rbp-0x98], rcx
       mov      gword ptr [rbp-0x90], r14
       movzx    rcx, byte  ptr [rbp-0x7C]
       mov      byte  ptr [rbp-0x88], cl
       xor      ecx, ecx
       mov      dword ptr [rsp+0x28], ecx
       mov      gword ptr [rsp+0x30], rbx
       mov      gword ptr [rsp+0x38], r15
 
G_M000_IG18:                ;; offset=0x0305
       mov      bword ptr [rbp-0xA8], rcx
 
G_M000_IG19:                ;; offset=0x030C
       mov      dword ptr [rbp-0xA0], ecx
       mov      gword ptr [rsp+0x48], rdx
 
G_M000_IG20:                ;; offset=0x0317
       mov      gword ptr [rbp-0xB8], rcx
 
G_M000_IG21:                ;; offset=0x031E
       mov      dword ptr [rbp-0xB0], ecx
       mov      byte  ptr [rbp-0xAC], 0
 
G_M000_IG22:                ;; offset=0x032B
       mov      dword ptr [rsp+0x58], ecx
 
G_M000_IG23:                ;; offset=0x032F
       mov      bword ptr [rbp-0xC8], rcx
 
G_M000_IG24:                ;; offset=0x0336
       mov      dword ptr [rbp-0xC0], ecx
       lea      rdx, [rbp-0xB8]
       mov      qword ptr [rsp+0x50], rdx
       lea      rdx, [rbp-0x98]
       mov      qword ptr [rsp+0x20], rdx
       lea      rdx, [rbp-0xC8]
       mov      qword ptr [rsp+0x60], rdx
       lea      rdx, [rbp-0xA8]
       mov      qword ptr [rsp+0x40], rdx
       mov      rdx, r13
       mov      rcx, rdi
       xor      r9, r9
       call     [Lokad.Lython.Runtime.LythonRuntime:CreateFunctionValue(Lokad.Lython.Frontend.FunctionParameterLayout,Lokad.Lython.Frontend.ExecutableCodeObject,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutableCaptures,Lokad.Lython.Runtime.FunctionDefaults,bool,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],Lokad.Lython.Runtime.Text.PyString[],System.ValueTuple`3[System.Object,int,bool],bool,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):Lokad.Lython.Runtime.PyFunctionBase]
 
G_M000_IG25:                ;; offset=0x037B
       xor      rcx, rcx
       mov      gword ptr [rbp-0xE0], rcx
 
G_M000_IG26:                ;; offset=0x0384
       mov      gword ptr [rbp-0xE8], rcx
 
G_M000_IG27:                ;; offset=0x038B
       mov      dword ptr [rbp-0x7C], ecx
       jmp      SHORT G_M000_IG29
 
G_M000_IG28:                ;; offset=0x0390
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG29:                ;; offset=0x0396
       mov      rcx, gword ptr [rbx+0xA0]
       mov      ecx, dword ptr [rcx+0x88]
 
G_M000_IG30:                ;; offset=0x03A3
       add      rsp, 280
       pop      rbx
       pop      rsi
       pop      rdi
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG31:                ;; offset=0x03B7
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG32:                ;; offset=0x03BD
       sub      rsp, 104
 
G_M000_IG33:                ;; offset=0x03C1
       mov      rbx, gword ptr [rbp+0x20]
       mov      rcx, gword ptr [rbx+0xA0]
       mov      rbx, gword ptr [rcx+0x88]
       cmp      gword ptr [rbp-0xE0], 0
       je       SHORT G_M000_IG34
       mov      rcx, rbx
       mov      rdx, gword ptr [rbp-0xE0]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.MemoryGovernor:RefundUnpublishedValue(System.Object):this]
 
G_M000_IG34:                ;; offset=0x03EF
       cmp      byte  ptr [rbp-0x7C], 0
       je       SHORT G_M000_IG35
       mov      rcx, 0x7FF9D7662760
       call     CORINFO_HELP_GET_NONGCSTATIC_BASE
       mov      rdx, qword ptr [(reloc 0x7ff9d70ab120)]
       mov      rcx, rbx
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.MemoryGovernor:Release(long):this]
       jmp      SHORT G_M000_IG37
 
G_M000_IG35:                ;; offset=0x0418
       mov      rdx, gword ptr [rbp-0xE8]
       mov      rcx, 0x7FF9D7172560
       call     CORINFO_HELP_ISINSTANCEOFARRAY
       test     rax, rax
       je       SHORT G_M000_IG36
       mov      ecx, dword ptr [rax+0x08]
       call     [Lokad.Lython.Runtime.PyDict+RecordKeys:RecordBytes(int):long]
       mov      rdx, rax
       mov      rcx, rbx
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.MemoryGovernor:Release(long):this]
       jmp      SHORT G_M000_IG37
 
G_M000_IG36:                ;; offset=0x044C
       cmp      gword ptr [rbp-0xE8], 0
       je       SHORT G_M000_IG37
       mov      rcx, rbx
       mov      rdx, gword ptr [rbp-0xE8]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.MemoryGovernor:RefundUnpublishedValue(System.Object):this]
 
G_M000_IG37:                ;; offset=0x0468
       nop      
 
G_M000_IG38:                ;; offset=0x0469
       add      rsp, 104
       ret      
 
; Total bytes of code 1134

