from pathlib import Path
import gzip,hashlib,json,subprocess
lab=Path(".git/agent-notes/review-20261031/abstract-value-facts-r589")
space=json.loads((lab/'quiet-space-pending.json').read_text(encoding='utf-8'))
assert len(space['replicas'])==2
for p in space['replicas']:
    archived=subprocess.check_output(['git','show',f"origin/master:{p['canonical']}"])
    assert archived==Path(p['canonical']).read_bytes() and hashlib.sha256(archived).hexdigest()==p['canonicalSHA256']
    raw=gzip.decompress(archived)
    assert len(raw)==p['bytes'] and hashlib.sha256(raw).hexdigest()==p['sha256']
    p['committedBlobVerified']=True
(lab/'quiet-space.json').write_text(json.dumps(space,indent=2)+'\n',encoding='utf-8',newline='\n')
