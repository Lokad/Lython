from pathlib import Path
import gzip, hashlib, json, subprocess

lab=Path(__file__).resolve().parent
sha=lambda b:hashlib.sha256(b).hexdigest()
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
groups=[]
for donor,root,archive in [
    ('function-annotation-storage-r583','function-annotation-storage-b1009-20261118','2026-11-18-function-annotation-storage'),
    ('function-metadata-slots-r584','function-metadata-slots-b1010-20261118','2026-11-18-function-metadata-slots'),
]:
    donor=lab.parent/donor
    manifest=load(donor/'frozen-identity.json')['images']['candidate']
    image=donor/'frozen/candidate'
    assert len(manifest)==32 and all(sha((image/n).read_bytes())==h for n,h in manifest.items())
    core=(image/'Lokad.Lython.dll').read_bytes()
    canonical=Path('benchmarks/results')/archive/'candidate-core.dll.gz'
    blob=gzip.compress(core,6,mtime=0)
    assert gzip.decompress(blob)==core
    if canonical.exists(): assert canonical.read_bytes()==blob
    else: canonical.write_bytes(blob)
    groups.append(dict(source=root+'/candidate/Lokad.Lython.dll',bytes=len(core),sha256=sha(core),canonical=canonical.as_posix(),
                       canonicalSHA256=sha(blob),committedBlobVerified=False,kind='exact archived measured replica'))

remote=r"""
from pathlib import Path
import fcntl,hashlib,json,os,shutil,stat,subprocess
root=Path('/home/lokad/lython-bench-checks').resolve()
assert root==Path('/home/lokad/lython-bench-checks')
proofs=PROOFS
with (root/'comparison-vm.lock').open('a') as lock:
 fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert not subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record|[p]ython3.13.*cpython-worker.py'],capture_output=True).stdout
 assert not any(os.path.ismount(p) for p in root.glob('*/guest-fixtures'))
 all_paths=list(root.glob('*/*/Lokad.Lython.dll'))
 for proof in proofs:
  source=root/proof.pop('source')
  st=source.lstat()
  assert source.resolve()==source and source.is_relative_to(root) and stat.S_ISREG(st.st_mode)
  paths=[]
  for path in all_paths:
   info=path.lstat()
   if (info.st_dev,info.st_ino)!=(st.st_dev,st.st_ino): continue
   assert path.resolve()==path and path.is_relative_to(root) and stat.S_ISREG(info.st_mode)
   assert info.st_uid==os.getuid() and info.st_size==proof['bytes']
   assert hashlib.sha256(path.read_bytes()).hexdigest()==proof['sha256']
   paths.append(path.relative_to(root).as_posix())
  assert len(paths)==st.st_nlink
  proof.update(paths=sorted(paths),links=st.st_nlink)
 print(json.dumps(dict(freeBytes=shutil.disk_usage(root).free,replicas=proofs)))
""".replace('PROOFS',repr(groups))
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i',str(Path.home()/'.ssh/id_lython-bench.pem'),
     '-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
proof=json.loads(subprocess.check_output(ssh+['python3 -'],input=remote.encode(),timeout=30))
allowed={'function-annotation-storage-b1009-20261118','function-metadata-slots-b1010-20261118',
         'post-transport-attribution-b1011-20261118','trailing-keyword-operands-b1012-20261118'}
assert all(p.split('/')[0] in allowed for group in proof['replicas'] for p in group['paths'])
(lab/'quiet-space-pending.json').write_text(json.dumps(proof,indent=2)+'\n',encoding='utf-8',newline='\n')
print(proof['freeBytes'],[(g['sha256'][:8],g['paths']) for g in proof['replicas']])
