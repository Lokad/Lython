# R589 source gate

On faeec7e81, AbstractState.MatchesFactQuery has exactly three predicates:
reachable dictionary, reachable mutable collection, and whether arbitrary
Python callbacks are possible. The mutable predicates walk nested sequences,
dict items, class fields, instance fields and function binding snapshots.
The callback predicate immediately rejects any kind outside its current
whitelist, then checks the contents of supported explicit containers.
MaybeNone and ListType are callback-capable under the current model, even
when their child is a scalar. Non-dict mutable wrapper kinds remain distinct
from the dictionary-invalidation predicate.

AbstractValue.PayloadIdentity is only used by this query. Production creates
AbstractFunctionSummary in StaticBindingEngine.Functions.TryBuildSimpleFunctionSummary
after CloneForDeferredBody and removal of the declaration and shadowed type
parameters. ResolveArgumentValue reads those bindings and can memoize facts.
Invocation writes to a clone. Verify that no code can mutate the captured
value map through a creator or through default resolution. Verify all class,
instance and sequence payload publication points. Immutable summaries should
need no extra identity table or runtime owner.

Prototype boundary: compute the same three answers from child summaries
while finalizing owned compiler payloads. Preserve value-graph work bounds
and active-token checks on wide payload scans. Merge the common two
invalidation passes only after preserving deletion, sequence widening,
cache invalidation and branch effects. Keep the conservative work boundary
for actual tuple rebuilding until equivalence for that work is demonstrated.
Use differential diagnostics from the exact base and tests for shared
container facts, aliases, callback-capable values and cancellation/refusal.
