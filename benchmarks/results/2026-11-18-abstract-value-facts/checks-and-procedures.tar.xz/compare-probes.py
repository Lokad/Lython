from pathlib import Path
import json, os, subprocess

lab=Path(__file__).resolve().parent
repo=Path.cwd()
base=['import operator\n','from dataclasses import dataclass,replace\n','from collections import deque\n']
programs=[
 "d={'a': 1}\na=(d,)\noperator.setitem(a[0],'a','s')\nprint(a[0]['a'])",
 "d={'a':1}\na=((d,),)\noperator.setitem(a[0][0],'a','s')\nx: str = a[0][0]['a']\nprint(x)",
 "d={'a':1}\nvalues=[(d,)]\ncopy=list(values)\noperator.setitem(d,'a',9)\nprint(copy[0][0]['a'])",
 "numbers=[1]\nvalues=(numbers,)\noperator.setitem(numbers,0,'s')\nx: str=values[0][0]\nprint(x)",
 "class Callback:\n def __repr__(self): return 'hook'\na=(1,[Callback()],{'v':Callback()})\nprint(repr(a))",
 "class Callback:\n def __str__(self): return 'hook'\n values=None\nprint(str((Callback(),)))",
 "first={'a':1}\ndef read(): return first['a']\noperator.setitem(first,'a','s')\nx: str=read()\nprint(x)",
 "first=[1]\ndef read(index=0): return first[index]\nfirst[0]='s'\nprint(read())",
 "first={'a':1}\nsecond={'a':'s'}\nvalues=[first,second]\nprint(values.pop()['a'])",
 "d={'a': 1}\nvalues=[d]\nvalues2=list(values)\nprint(values2[0]['a'])",
 "x: int = 'error'\nprint(x)",
 "x: str = 42",
 "def f(value:int='bad')->int:\n return 'bad'\nprint(f())",
 "def f(flag):\n item={'a':[1]} if flag else {'a':[2]}\n return item\nprint(f(True))",
 "def f(flag):\n d={'a':1}\n if flag: d={'a':'s'}\n return d\nprint(f(False))",
 "def f(flag):\n if flag: return {'a':(1,)}\n return {'a':(2,)}\nprint(f(True))",
 "a = ({'k':1},)\nb = ({'k':2},)\nc = a+b\noperator.setitem(a[0],'k','v')\nprint(c[0]['k'])",
 "a=([],)\nb=[*a]\na[0].append('x')\nprint(b[0])",
 "@dataclass\nclass Box:\n item: object\nbox=Box({'x': [1]})\nchanged=replace(box,item={'x':['s']})\nprint(changed.item)",
 "@dataclass\nclass Box:\n item: object\nbox=Box(1)\nother=Box('s')\nprint((box.__class__.__name__, other.item))",
 "k=[1]\nitems=deque([k])\nk.append(2)\nprint(items[0])",
 "from __future__ import annotations\ndef f(arg: Missing = 7): return arg\nprint(f.__annotations__)",
 "import re\nm = re.search('(?P<g>a)', 'a')\nprint(m.group('g'))",
 "import re\nm = re.search('(a)', 'a')\nprint(m.group(4))",
]
source=[]
for p in programs:
 imports = [imp for key,imp in zip(['operator.', '@dataclass', 'deque('],base) if key in p]
 source.append(''.join(imports)+p)
source.append("d={'item':1}\nshape=(d,)\n"+("\n".join("shape=(shape,shape)" for _ in range(18)))+
              "\nprint(len(shape))")
(lab/'probes.json').write_text(json.dumps(source,ensure_ascii=False)+'\n',encoding='utf-8')
sdk=Path.home()/'.dotnet11'
env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk),PATH=str(sdk)+os.pathsep+os.environ['PATH'])
probes={
 'reference':repo/'tools/LythonProbe/bin/Release/net11.0/LythonProbe.dll',
 'candidate':repo/'.git/agent-worktrees/abstract-value-facts-r589/tools/LythonProbe/bin/Release/net11.0/LythonProbe.dll',
}
compared=[]
fields=('Success','StandardOutput','StandardError','ExitCode','Diagnostics','Failure')
for mode in ['sync','async']:
 rows={}
 for label,probe in probes.items():
  args=[str(sdk/'dotnet.exe'),str(probe),'--batch-json','--max-memory-bytes','4194304']
  if mode=='async':args+=['--async']
  actual=subprocess.run(args,env=env,input=(lab/'probes.json').read_bytes(),capture_output=True,timeout=90)
  (lab/f'{label}-{mode}.jsonl').write_bytes(actual.stdout)
  (lab/f'{label}-{mode}.stderr').write_bytes(actual.stderr)
  records=[json.loads(line) for line in actual.stdout.decode('utf-8-sig').splitlines()]
  assert len(records)==len(source),(label,mode,len(records),actual.stderr)
  rows[label]=[{k:r['Lython'].get(k) for k in fields} for r in records]
 differences=[i for i,(a,b) in enumerate(zip(rows['reference'],rows['candidate'])) if a!=b]
 compared.append(dict(mode=mode,matching=len(source)-len(differences),total=len(source),differences=differences))
(lab/'comparison.json').write_text(json.dumps(compared,indent=2)+'\n',encoding='utf-8')
print(compared)
assert all(not row['differences'] for row in compared)
