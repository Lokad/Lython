from pathlib import Path
import hashlib,json,subprocess,tarfile
root=Path(__file__).resolve().parent
status=json.loads((root/'terminal-status.json').read_text(encoding='utf-8'))
assert status['exitCode']=='1' and 'MainPID=0' in status['service'] and not status['remainingWorkers'] and not status['remainingFixtures']
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
script='''from pathlib import Path
import fcntl,json,os,subprocess
root=Path('/home/lokad/lython-bench-checks/current-cpu-b358-20261106')
with (root.parent/'comparison-vm.lock').open('a') as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert (root/'exit-code.txt').read_text().strip()=='1'
 assert not list(Path('/dev/shm').glob('lython-comparison-files-*'))
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record|[o]ps-profile.py'],capture_output=True).returncode==1
 for case in ['text-warm','report-warm']:
  record=json.loads((root/'perf'/case/'record.json').read_text());assert record['exitCode']==0 and record['closed']['status']=='Closed'
  p=root/'perf'/case/'perf.data';assert not p.is_symlink() and root in p.resolve().parents and p.stat().st_nlink==1
  subprocess.run(['sudo','-n','chown',f'{os.getuid()}:{os.getgid()}',str(p)],check=True)
 original=root/'archive.py';original.rename(root/'archive-original.py')
 (root/'observations.tgz').rename(root/'observations-incomplete.tgz')
 correction=dict(originalOwnerExitCode=1,allCapturesAndImmediateGatesCompleted=True,workloadsRetimed=False,
  reason='perf created root-owned0600 data; archive as lokad could not read it. Preserve original archiver/journal/partial archive; transfer only these2 ended-owned data files to lokad and archive under recovery lease.')
 (root/'archive-correction.json').write_text(json.dumps(correction,indent=2)+'\\n')
 source=(root/'archive-original.py').read_text().replace('performanceQualified=False)',
  'performanceQualified=False,originalOwnerExitCode=1,archiveRecoveredUnderLease=True)')
 original.write_text(source)
 subprocess.run(['python3',str(original)],check=True)
'''
r=subprocess.run([*ssh,'python3 -'],input=script,text=True,encoding='utf-8',capture_output=True)
(root/'archive-recovery.log').write_text(r.stdout+r.stderr,encoding='utf-8');assert r.returncode==0,r.stdout+r.stderr
scp=['C:/Windows/System32/OpenSSH/scp.exe','-i',ssh[2],'-o','BatchMode=yes','-o','ConnectTimeout=15']
for name in ['observations.tgz','archive-receipt.json']:
    r=subprocess.run([*scp,'lokad@20.166.121.73:/home/lokad/lython-bench-checks/current-cpu-b358-20261106/'+name,str(root/name)],capture_output=True,text=True);assert r.returncode==0,r.stderr
receipt=json.loads((root/'archive-receipt.json').read_text(encoding='utf-8'));assert receipt['complete']
assert hashlib.sha256((root/'observations.tgz').read_bytes()).hexdigest()==receipt['archiveSHA256']
dest=root/'retrieved';dest.mkdir()
with tarfile.open(root/'observations.tgz') as a:a.extractall(dest,filter='data')
for case in ['text-warm','report-warm']:
    d=json.loads((dest/'perf'/case/'guest-cpu-leaves.json').read_text(encoding='utf-8'))
    print(case,d['samples'],d['cpuSeconds'],d['topLeafCpuSamples'][:10],flush=True)
print(receipt,flush=True)
