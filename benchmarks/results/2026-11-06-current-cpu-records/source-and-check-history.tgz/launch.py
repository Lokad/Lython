from pathlib import Path
import ast,fcntl,hashlib,io,json,shutil,subprocess,sys,tarfile
base=Path('/home/lokad/lython-bench-checks');root=base/'current-cpu-b358-20261106';old=base/'whole-script-cpu-b191-20261104'
with (base/'comparison-vm.lock').open('a') as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert not root.exists() and not list(Path('/dev/shm').glob('lython-comparison-files-*'))
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record|[o]ps-profile.py'],capture_output=True).returncode==1
 payload=sys.stdin.buffer.read(17740+1);assert len(payload)==17740 and hashlib.sha256(payload).hexdigest()=='7eee6af0312d8f3bc4ae62eba4e08e09ff2f5aba772df08397cbcc839915857a'
 with tarfile.open(fileobj=io.BytesIO(payload),mode='r:gz') as a:
  proof=json.loads(a.extractfile('old-expanded-proof.json').read())
  removed=[]
  for name,check in proof.items():
   archive=old/name
   if not archive.exists():continue
   assert hashlib.sha256(archive.read_bytes()).hexdigest()==check['archiveSHA256']
   files=[]
   for relative,digest in check['files'].items():
    p=old/relative
    if not p.exists():continue
    assert not p.is_symlink() and old in p.resolve().parents and p.stat().st_nlink==1
    actual=subprocess.check_output(['sudo','-n','sha256sum',str(p)],text=True).split()[0]
    assert actual==digest;files.append(p)
   for p in files:p.unlink();removed.append(str(p))
  assert shutil.disk_usage(base).free>sum(m.size for m in a.getmembers())+10*1024*1024,shutil.disk_usage(base).free
  root.mkdir();a.extractall(root,filter='data')
 (root/'candidate').symlink_to(base/'delivery-comparison-b352-20261106/candidate',target_is_directory=True)
 identity=json.loads((root/'identity.json').read_text())
 assert hashlib.sha256((root/'candidate/Lokad.Lython.dll').read_bytes()).hexdigest()==identity['files']['Lokad.Lython.dll']
 for name in ['ops-profile.py','analyze-cpu-guest.py','archive.py']:ast.parse((root/name).read_text())
 assert b'\r' not in (root/'run.sh').read_bytes();subprocess.run(['/bin/sh','-n',str(root/'run.sh')],check=True)
 free=shutil.disk_usage(base).free;assert free>10*1024*1024
 record=dict(retiredOnlyVerifiedExpandedProfileCopies=removed,localAndRemoteArchivesVerified=True,freeBytes=free,
  profilerMode='PerfMapEnabled3: no duplicate jit dumps',observer='No status/profiler SSH until150s owner plus30s stop bound')
 (root/'setup.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record))
subprocess.run(['sudo','-n','systemd-run','--unit=lython-b358-current-cpu-20261106','--property=User=lokad','--property=WorkingDirectory='+str(root),'--property=RuntimeMaxSec=150','--property=TimeoutStopSec=30','--property=KillMode=control-group','/bin/sh',str(root/'run.sh')],check=True)
