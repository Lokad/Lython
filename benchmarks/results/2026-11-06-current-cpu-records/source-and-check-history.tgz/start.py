from pathlib import Path
import hashlib,subprocess
root=Path(__file__).resolve().parent;data=(root/'payload.tgz').read_bytes()
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
scp=['C:/Windows/System32/OpenSSH/scp.exe','-i',ssh[2],'-o','BatchMode=yes','-o','ConnectTimeout=15']
script='''from pathlib import Path
import ast,fcntl,hashlib,io,json,shutil,subprocess,sys,tarfile
base=Path('/home/lokad/lython-bench-checks');root=base/'current-cpu-b358-20261106';old=base/'whole-script-cpu-b191-20261104'
with (base/'comparison-vm.lock').open('a') as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert not root.exists() and not list(Path('/dev/shm').glob('lython-comparison-files-*'))
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record|[o]ps-profile.py'],capture_output=True).returncode==1
 payload=sys.stdin.buffer.read(PAYLOADBYTES+1);assert len(payload)==PAYLOADBYTES and hashlib.sha256(payload).hexdigest()=='PAYLOADHASH'
 with tarfile.open(fileobj=io.BytesIO(payload),mode='r:gz') as a:
  proof=json.loads(a.extractfile('old-expanded-proof.json').read())
  removed=[]
  for name,check in proof.items():
   archive=old/name
   if not archive.exists():continue
   assert hashlib.sha256(archive.read_bytes()).hexdigest()==check['archiveSHA256']
   files=[]
   for relative,digest in check['files'].items():
    p=old/relative
    if not p.exists():continue
    assert not p.is_symlink() and old in p.resolve().parents and p.stat().st_nlink==1
    actual=subprocess.check_output(['sudo','-n','sha256sum',str(p)],text=True).split()[0]
    assert actual==digest;files.append(p)
   for p in files:p.unlink();removed.append(str(p))
  assert shutil.disk_usage(base).free>sum(m.size for m in a.getmembers())+10*1024*1024,shutil.disk_usage(base).free
  root.mkdir();a.extractall(root,filter='data')
 (root/'candidate').symlink_to(base/'delivery-comparison-b352-20261106/candidate',target_is_directory=True)
 identity=json.loads((root/'identity.json').read_text())
 assert hashlib.sha256((root/'candidate/Lokad.Lython.dll').read_bytes()).hexdigest()==identity['files']['Lokad.Lython.dll']
 for name in ['ops-profile.py','analyze-cpu-guest.py','archive.py']:ast.parse((root/name).read_text())
 assert b'\\r' not in (root/'run.sh').read_bytes();subprocess.run(['/bin/sh','-n',str(root/'run.sh')],check=True)
 free=shutil.disk_usage(base).free;assert free>10*1024*1024
 record=dict(retiredOnlyVerifiedExpandedProfileCopies=removed,localAndRemoteArchivesVerified=True,freeBytes=free,
  profilerMode='PerfMapEnabled3: no duplicate jit dumps',observer='No status/profiler SSH until150s owner plus30s stop bound')
 (root/'setup.json').write_text(json.dumps(record,indent=2)+'\\n');print(json.dumps(record))
subprocess.run(['sudo','-n','systemd-run','--unit=lython-b358-current-cpu-20261106','--property=User=lokad','--property=WorkingDirectory='+str(root),'--property=RuntimeMaxSec=150','--property=TimeoutStopSec=30','--property=KillMode=control-group','/bin/sh',str(root/'run.sh')],check=True)
'''.replace('PAYLOADBYTES',str(len(data))).replace('PAYLOADHASH',hashlib.sha256(data).hexdigest())
(root/'launch.py').write_text(script,encoding='utf-8')
r=subprocess.run([*scp,str(root/'launch.py'),'lokad@20.166.121.73:/home/lokad/lython-bench-checks/b358-launch.py'],capture_output=True,text=True);assert r.returncode==0,r.stderr
r=subprocess.run([*ssh,'python3 /home/lokad/lython-bench-checks/b358-launch.py'],input=data,capture_output=True)
(root/'launch.log').write_bytes(r.stdout+r.stderr);assert r.returncode==0,(r.stdout+r.stderr).decode('utf-8')
print(r.stdout.decode('utf-8')+r.stderr.decode('utf-8'),flush=True)
