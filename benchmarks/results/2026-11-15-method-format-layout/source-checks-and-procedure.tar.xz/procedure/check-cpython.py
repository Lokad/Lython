from pathlib import Path
import json,re,subprocess,tempfile,textwrap
r=Path(__file__).parent;p=Path('tests/Lokad.Lython.PublicApi.Tests/FormatTemplateTests.cs');s=p.read_text(encoding='utf-8');sources=re.findall('"""\n(.*?)\n\s*"""',s,re.S);assert len(sources)==2
src=textwrap.dedent(sources[0]);mapped=src.replace('{0','{v').replace('method=template.format','method=template.format_map').replace("d}'.format","d}'.format_map").replace('method(Field(),width=4)',"method({'v':Field(),'width':4})").replace('method(Field())',"method({'v':Field()})")
rows=[]
for label,source in [('errors',src),('mapping-errors',mapped),('types-nested',textwrap.dedent(sources[1]))]:
 with tempfile.TemporaryDirectory(prefix='lython-format-goldens-') as d:
  Path(d,'value').write_text('ok',encoding='utf-8');code='def check():\n'+textwrap.indent(source,'    ')+"\nassert check()=='ok'\n"
  done=subprocess.run(['C:/Python313/python.exe','-I','-S','-X','utf8','-c',code],cwd=d,capture_output=True,timeout=10);rows.append(dict(label=label,source=code,exitCode=done.returncode,stderr=done.stderr.decode('utf-8')));assert done.returncode==0,rows[-1]
(r/'cpython-goldens.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n');print('Independent CPython: all3new semantic/error-order programs pass.')
