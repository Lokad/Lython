from pathlib import Path
import ast,datetime,hashlib,io,json,shlex,subprocess,tarfile
repo=Path.cwd();r=Path(__file__).parent;q=r/'quiet';q.mkdir();old=r.parent/'prepared-stores-r413/corrected';root='/home/lokad/lython-bench-checks/format-layout-b812-20261115';unit='lython-b812-format-layout-20261115';head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();f=json.loads((r/'frozen/identity.json').read_text(encoding='utf-8'));keys=set(json.loads((old/'config.json').read_text(encoding='utf-8'))['identity']['imageFiles']['candidate']);images={role:{n:h for n,h in files.items()if n in keys}for role,files in f['images'].items()}
identity=dict(sourceRevision='R418 uncommitted9d071eba versus qualifiedb06b8593/frozen8afb146e',purpose='Execution-owned reusable method-format template/field/native-spec layout; complete report warm/fresh plus unchanged f-string/CSV controls. Semantic/async/ownership checks separate.',coreSHA256={label:images['candidate'if label.startswith('candidate')else'reference']['Lokad.Lython.dll']for label in ['candidate','candidate-control','reference','reference-control']},imageFiles=images,prototype=True,publicationHeld=True,candidateSourceIdentitySHA256=hashlib.sha256((r/'frozen/identity.json').read_bytes()).hexdigest())
(q/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8',newline='\n');catalog=json.loads((r/'catalog.json').read_text(encoding='utf-8'));catalog['cases']=[c for c in catalog['cases']if c['id']=='scripts.report-render.format-method.large'];(q/'additional.json').write_text(json.dumps(catalog,ensure_ascii=False,separators=(',',':'))+'\n',encoding='utf-8',newline='\n')
for n in ['collect.py','archive-owned.py','run.sh','retrieve.py']:
 s=(old/n).read_text(encoding='utf-8').replace('prepared-stores-b806-20261115','format-layout-b812-20261115').replace('lython-b806-prepared-stores-20261115',unit).replace('B806','B812')
 s=s.replace("len(raw['jobs'])==5","len(raw['jobs'])==4").replace("['jobs']==5","['jobs']==4").replace('jobs=5,','jobs=4,').replace("elapsedSeconds']<330","elapsedSeconds']<240")
 if n=='collect.py':
  a=s.index('jobs=');b=s.index('\nenv =',a);s=s[:a]+"jobs=[['scripts.report-render.format-method.large','warm'],['scripts.report-render.format-method.large','compile-run'],['scripts.report-render.large','warm'],['scripts.csv-invoice.large','warm']]\ncases.update({c['id']:c for c in json.loads((root/'additional.json').read_text())['cases']})\nassert len(jobs)==4 and all(case in cases for case,lane in jobs)\n"+s[b:]
  s=s.replace("catalog = root/('additional.json' if case_id=='scripts.text-summary.inline.large' else 'representative.json')","catalog = root/('additional.json' if case_id=='scripts.report-render.format-method.large' else 'representative.json')")
  s=s.replace(' < 280,',' < 190,').replace('compilationWarmupSeconds=8, ','')
 if n.endswith('.py'):ast.parse(s)
 (q/n).write_text(s,encoding='utf-8',newline='\n')
proof=json.loads((r/'historical-aliases.json').read_text(encoding='utf-8'));custody=proof['custody'];raw=(repo/custody['archive']).read_bytes();assert subprocess.check_output(['git','show',custody['commit']+':'+custody['archive']])==raw
with tarfile.open(fileobj=io.BytesIO(raw)) as t:core=t.extractfile(custody['member']).read()
assert hashlib.sha256(raw).hexdigest()==custody['archiveSHA256'] and hashlib.sha256(core).hexdigest()==proof['sha256'] and len(core)==proof['bytes'] and proof['links']==len(proof['paths'])
groups=[proof]
canonical='benchmarks/results/2026-11-15-method-format-attribution/observations.tgz';raw=(repo/canonical).read_bytes();assert subprocess.check_output(['git','show',head+':'+canonical])==raw
groups.append(dict(paths=['format-program-b811-20261115/observations.tgz'],bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest(),links=1,optional=True,custody=dict(commit=head,archive=canonical,archiveSHA256=hashlib.sha256(raw).hexdigest(),member=None)))
with tarfile.open(q/'payload.tgz','w:gz')as t:
 for n in ['identity.json','collect.py','archive-owned.py','run.sh']:t.add(q/n,arcname=n)
 t.add(r/'frozen/candidate/Lokad.Lython.dll',arcname='candidate/Lokad.Lython.dll')
with tarfile.open(q/'payload.tgz')as t:size=sum(m.size for m in t if m.isfile())
c=dict(root=root,unit=unit,source='/home/lokad/lython-bench-checks/format-sinks-b809-20261115',sourceFiles=images['reference'],sourceCatalogSHA256=hashlib.sha256((r.parent/'prepared-stores-r413/checkpoint/retrieved/representative.json').read_bytes()).hexdigest(),identity=identity,retireGroups=groups,payloadBytes=(q/'payload.tgz').stat().st_size,payloadSHA256=hashlib.sha256((q/'payload.tgz').read_bytes()).hexdigest(),unpackedBytes=size)
(q/'config.json').write_text(json.dumps(c,indent=2)+'\n',encoding='utf-8',newline='\n')
tree=ast.parse((r.parent/'regex-producer-050-r409/launch-vm.py').read_text(encoding='utf-8'));node=next(n for n in tree.body if isinstance(n,ast.Assign)and any(isinstance(t,ast.Name)and t.id=='code'for t in n.targets));code=node.value.func.value.value
a=code.index(" proof=c['retire'];");b=code.index(' root.mkdir()',a)
retirement=''' present=[];absent=[];paths=[];inodes={}
 for proof in c['retireGroups']:
  ps=[b/n for n in proof['paths']]
  if proof.get('optional')and not any(p.exists()for p in ps):absent.append(proof);continue
  m=ps[0].lstat();key=(m.st_dev,m.st_ino);assert key not in inodes;inodes[key]=[]
  for p in ps:
   v=p.lstat();assert p.resolve()==p and p.is_relative_to(b)and stat.S_ISREG(v.st_mode)and v.st_uid==os.getuid()and v.st_size==proof['bytes']and v.st_nlink==proof['links']and(v.st_dev,v.st_ino)==key and sha(p)==proof['sha256']
  paths.extend(ps);present.append(proof)
 for base,dirs,names in os.walk(b):
  for n in names:
   p=Path(base)/n;m=p.lstat()
   if(m.st_dev,m.st_ino)in inodes:inodes[m.st_dev,m.st_ino].append(str(p.relative_to(b)))
 assert sorted(n for aliases in inodes.values()for n in aliases)==sorted(n for proof in present for n in proof['paths'])
 before=shutil.disk_usage(b).free
 assert before+sum(v['bytes']for v in present)>254*1024*1024+c['unpackedBytes']+65536,(before,present,c['unpackedBytes'])
 for p in paths:p.unlink()
'''
code=code[:a]+retirement+code[b:]
code=code.replace(" for role in ['reference','candidate']:\n"," for role in ['reference','candidate']:\n  (root/role).mkdir(exist_ok=True)\n").replace("os.link(root/'backend'/n if n in ['Lokad.Utf8Regex.dll','Lokad.Utf8Regex.PythonRe.dll']else source/'candidate'/n,p)","os.link(source/'candidate'/n,p)")
code=code.replace(" for n,h in c['sourceFiles'].items():assert sha(source/'candidate'/n)==h,n"," for n,h in c['sourceFiles'].items():assert sha(source/'candidate'/n)==h,n\n assert sha(source/'representative.json')==c['sourceCatalogSHA256']")
code=code.replace(" os.link(source/'cpython-worker.py',root/'cpython-worker.py')"," os.link(source/'cpython-worker.py',root/'cpython-worker.py');os.link(source/'representative.json',root/'representative.json');os.link(source/'additional.json',root/'additional.json')")
code=code.replace('retiredOnly=proof','retiredOnly=present,alreadyAbsent=absent').replace('lython-b798-fixtures','lython-b809-fixtures').replace('RuntimeMaxSec=150','RuntimeMaxSec=240').replace('CONFIG',repr(c));ast.parse(code);(q/'remote-launch.py').write_text(code,encoding='utf-8',newline='\n')
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73'];p=subprocess.run(ssh+['python3 -c '+shlex.quote(code)],input=(q/'payload.tgz').read_bytes(),capture_output=True,timeout=45);(q/'launch.log').write_bytes(p.stdout+p.stderr);assert p.returncode==0,(p.stdout+p.stderr).decode('utf-8','replace')
now=datetime.datetime.now(datetime.timezone.utc);(q/'observe-not-before.json').write_text(json.dumps(dict(launchedUTC=now.isoformat(),doNotObserveBeforeUTC=(now+datetime.timedelta(seconds=200)).isoformat()),indent=2)+'\n',encoding='utf-8',newline='\n');print(p.stdout.decode('utf-8'),flush=True)
