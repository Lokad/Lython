from pathlib import Path
import hashlib,json,shutil,subprocess,tarfile
r=Path(__file__).parent;f=r/'frozen';f.mkdir();base=r.parent/'format-sinks-r416/frozen/candidate';images={};sources={}
for role in ['reference','candidate']:
 d=f/role;shutil.copytree(base,d)
 if role=='candidate':shutil.copyfile('src/Lokad.Lython/bin/Release/net11.0/Lokad.Lython.dll',d/'Lokad.Lython.dll')
 images[role]={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in d.iterdir() if p.is_file()}
assert images['reference']['Lokad.Lython.dll']=='8afb146e835dcd2692150026e4beb6566b2a483349b2a8b5c24b5e6eba58e6ed'
assert all(images['candidate'][n]==h for n,h in images['reference'].items() if n!='Lokad.Lython.dll')
paths=subprocess.check_output(['git','ls-files','src/Lokad.Lython'],text=True).splitlines()+['src/Lokad.Lython/Runtime/Text/PyStringOps.FormatTemplate.cs','Directory.Build.props','Directory.Packages.props','NuGet.Config','global.json','tests/Lokad.Lython.Tests/FormatStorageTests.cs','tests/Lokad.Lython.Tests/StringFormatPrimitiveTests.cs','tests/Lokad.Lython.PublicApi.Tests/FormatTemplateTests.cs']
with tarfile.open(f/'sources-and-checks.tar.xz','w:xz') as a:
 for n in sorted(set(paths)):
  p=Path(n);sources[n]=hashlib.sha256(p.read_bytes()).hexdigest();a.add(p,arcname=n)
 for p in (r/'checks').iterdir():
  if p.is_file():a.add(p,arcname='checks/'+p.name)
(f/'identity.json').write_text(json.dumps(dict(baseCommit=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),prototype=True,images=images,sources=sources,contracts='One prepared layout on execution-owned format/map bound methods; no literal/global cache or stored token. Deferred errors, current tokens, native shared spec parser/sink; coarse layout capacity retained until execution cleanup. Original per-call template/field scan displaced. Argument copies/frame promotion remain.'),indent=2)+'\n',encoding='utf-8',newline='\n')
d=r/'allocation';d.mkdir();shutil.copyfile(r.parent/'format-sinks-r416/allocation/catalog.json',d/'catalog.json')
for p in (r.parent/'format-sinks-r416/allocation/bin/Release/net11.0').glob('ValidatedAllocation.*'):
 dst=d/'bin/Release/net11.0'/p.name;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,dst)
s=(r.parent/'format-sinks-r416/measure-allocation.py').read_text(encoding='utf-8')
(r/'measure-allocation.py').write_text(s,encoding='utf-8',newline='\n')
print({role:v['Lokad.Lython.dll'] for role,v in images.items()})
