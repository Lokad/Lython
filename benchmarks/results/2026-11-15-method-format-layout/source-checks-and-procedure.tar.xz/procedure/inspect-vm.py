from pathlib import Path
import json,shlex,subprocess,tarfile,hashlib,io
r=Path(__file__).parent;head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();archive='benchmarks/results/2026-11-15-fused-cased-preparation/refined/sources-checks-and-procedures.tar.xz';raw=Path(archive).read_bytes();assert subprocess.check_output(['git','show',head+':'+archive])==raw
with tarfile.open(fileobj=io.BytesIO(raw)) as a:core=a.extractfile('refined-core.dll').read()
sha=hashlib.sha256(core).hexdigest();size=len(core)
old=r.parent/'format-sinks-r416/inspect-vm.py'
s=old.read_text(encoding='utf-8').replace('arithmetic-b790-20261115/candidate','cased-preparation-b795-20261115/candidate').replace('9e890d187e5ff2af2b335b1e7dfe0cf1edd9de6a55b389bef1df6e469993e7f8',sha)
(r/'inspect-vm-generated.py').write_text(s,encoding='utf-8',newline='\n')
p=subprocess.run(['C:/Python313/python.exe','-X','utf8',str(r/'inspect-vm-generated.py')],capture_output=True,timeout=45);assert p.returncode==0,p.stderr
v=json.loads((r/'historical-aliases.json').read_text(encoding='utf-8'));assert v['sha256']==sha and v['bytes']==size
v['custody']=dict(commit=head,archive=archive,archiveSHA256=hashlib.sha256(raw).hexdigest(),member='refined-core.dll')
(r/'historical-aliases.json').write_text(json.dumps(v,indent=2)+'\n',encoding='utf-8',newline='\n');print(json.dumps(v))
