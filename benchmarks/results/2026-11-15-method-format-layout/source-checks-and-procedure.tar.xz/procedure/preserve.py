from pathlib import Path
import hashlib,json,shutil,tarfile,xml.etree.ElementTree as E
r=Path(__file__).parent;q=r/'quiet';out=Path('benchmarks/results/2026-11-15-method-format-layout');out.mkdir();ns={'t':'http://microsoft.com/schemas/VisualStudio/TeamTest/2010'}
for src,n in [(r/'summary.json','summary.json'),(r/'allocation-summary.json','allocation-summary.json'),(r/'cpython-goldens.json','cpython-goldens.json'),(r/'frozen/identity.json','identity.json'),(q/'observations.tgz','observations.tgz'),(q/'archive-receipt.json','archive-receipt.json'),(q/'terminal-status.json','terminal-status.json')]:shutil.copyfile(src,out/n)
checks={}
with tarfile.open(out/'source-checks-and-procedure.tar.xz','w:xz') as a:
 for n in ['sources-and-checks.tar.xz','reference/Lokad.Lython.dll','candidate/Lokad.Lython.dll']:a.add(r/'frozen'/n,arcname='frozen/'+n)
 for p in r.iterdir():
  if p.is_file() and p.name!='catalog.json':a.add(p,arcname='procedure/'+p.name)
 a.add(r.parent/'format-program-r417/migrate-r418.py',arcname='procedure/migrate-r418.py')
 for p in q.iterdir():
  if p.is_file() and p.name not in ['observations.tgz','payload.tgz']:a.add(p,arcname='quiet/'+p.name)
 for p in (r/'allocation').iterdir():
  if p.is_file():a.add(p,arcname='allocation/'+p.name)
 for p in (r/'allocation/bin/Release/net11.0').glob('ValidatedAllocation.*'):a.add(p,arcname='allocation/driver/'+p.name)
 for p in (r/'checks').iterdir():
  if p.is_file():
   a.add(p,arcname='checks/'+p.name)
   if p.suffix=='.trx':checks[p.name]=E.parse(p).find('.//t:Counters',ns).attrib
 for p in (r/'original').rglob('*'):
  if p.is_file():a.add(p,arcname='original/'+p.relative_to(r/'original').as_posix())
(out/'checks.json').write_text(json.dumps(dict(checks=checks,cleanNonincrementalReleaseSolutionBuildEachActualFramework=True,independentCPythonNewSemanticPrograms=3,allVMOutputAndFileGoldensPassed=True,allocationBudgetReuseAndCleanupPassed=True,publicApiChange=False,publicationHeld=True),indent=2)+'\n',encoding='utf-8',newline='\n')
p=out/'summary.json';v=json.loads(p.read_text(encoding='utf-8'));v.update(retentionDecisionPending=False,retained=True,fullQualificationPending=True,reason='Complete method template/field/native-spec construction reused through one executor;18.47%less allocation and17–20%whole-script elapsed/CPU support. Moving/adverse controls and conservative retained cache charge accepted explicitly. No external CPython speedup inferred.');p.write_text(json.dumps(v,indent=2)+'\n',encoding='utf-8',newline='\n')
(out/'README.md').write_text('''# Reusable method-format layouts

R418, retained prototype**9d071eba**, qualified baseline**b06b8593 /8afb146e**.
Same complete JSON-to-Markdown report,1,024records/189,441B JSON; final stdout/file
goldens match the original f-string variant. No CPython source-change claim.

One execution-owned bound-method layout replaces per-call UTF8 template/field
scans, decoded root/suffix/spec strings and constant native spec descriptors.
Both str.format/map use one layout executor and the existing native formatter.
Literal byte runs append in bulk. The old async parser/executor interleaving is
removed; no parallel grammar, global/literal cache, new owner, allowance or policy.
Actual root/attribute/item lookup, value validation and hooks stay at execution.
Grammar errors are stored at their original position, preserving earlier effects;
custom hooks still receive native-invalid raw specs. No caller token is cached.
Long native numeric scans use the active operation token. Argument packet/copies,
native-to-durable promotion and dynamic nested spec materialization remain debt.

**Whole report allocation−18.47%**,7,046,314→5,745,137B/invocation; f-string control
flat(+8B). Same strengthened natural-GC driver checks full stdout/file hashes and
budget baseline after cleanup. Compilation/startup excluded. Baseline byte counts
are not compared across separate collections as if exact constants.

**B812 succeeds142.308s**: warm elapsed**17.42–19.28%lower** /CPU15.58–16.41%lower;
compile-to-result elapsed**18.24–19.83%lower** /CPU17.14–20.56%lower. Source control
spreads warm0.48/1.81%,fresh0.07/1.92%. F-string elapsed−7.00..−0.62%,CPU−7.66..+0.59%
with moving3.20/3.55%controls; CSVelapsed−0.03..+2.79%,CPU−0.64..+2.74%,controls1.67/1.13%.
Retain that adverse/uncertain control debt, not neutrality or a universal gain.
No unchanged rerun merely to erase it; justified different designs remain eligible.

Layouts reserve conservative part/field/name/spec/capacity/replacement headroom
before allocation, charged until execution/result cleanup. They are separate from
compiled literals and refresh when an internal method receives another owner.
Many distinct one-use methods can reject earlier, even after references disappear;
bounded host executions remain the ownership boundary. Operation scratch and argument
copies remain funded through pending callbacks; returned strings retain ownership.
No heap tracing, forced GC, retry, abandoned work or exact tiny-threshold promise.

Focused**12internal/682public each actual.NET11/10** pass after clean nonincremental
Release solution builds. New repeated error-order/type/nested programs independently
pass CPython3.13.2. Existing held-format hooks pass success, in-flight cancellation,
terminal refusal and awaited file cleanup before allowance reuse. Three semantic
public cases and two ownership/admission internal cases added; original assertions
remain. Initial mechanical parser-extraction compile errors and helper-signature
migration were corrected before freezing; no failing timing result discarded.

Quiet AzureF4as_v7/Ubuntu24.04.4,4EPYC9V45vCPUs,16GiB/no swap,.NET11RC3 normal
tiering/workstationGC. Two processes/source,5s full-request warmup,five rotated~0.5s
batches. Warm includesRun/mediatedRAM I/O/goldens/prior-result cleanup; excludes
compile/startup/reset/protocol/finalcache teardown. Fresh includescompile/compiled-owner
disposal; widerCPU includesreset/protocol. No standalone compile, pending-I/O,RSS or
embedding-tail claim. Every identity/golden/budget/quiet/Closed/exit/join/archive gate
passes. Evidence persists/hash-verifies under lease; no workers or RAM fixtures remain.
254/252MiB floors preserved. Exact archived historical0ed core's12aliases and committed
B811working trace archive retired only after fresh UID/path/hash/link/all-alias proof;
current8afb/preceding55ba images and canonical evidence retained. Terminal cached forever.

**Full platform/stress/package delivery pending; publication held.**
[Prior attribution](../2026-11-15-method-format-attribution/README.md),
[medians/all controls](summary.json),[allocations](allocation-summary.json),
[source/image identity](identity.json),[checks](checks.json),
[raw](observations.tgz),[source/binaries/procedures](source-checks-and-procedure.tar.xz).
The broader call/frame/frontend and independent regex roadmap remains active.
''',encoding='utf-8',newline='\n')
p=Path('docs/BENCHMARKS.md');s=p.read_text(encoding='utf-8');needle='| Final-output field sink / method-format report |';a=s.index(needle);s=s[:a]+'| Reused method-format layout / complete report | Warm elapsed17.4–19.3%lower; compile-to-result18.2–19.8%lower, supporting CPU | −18.47% | Retained9d071eba/8afb; moving f-string controls/CSVup to2.8%slower and conservative retained layout charges remain. [Source pair/limits](../benchmarks/results/2026-11-15-method-format-layout/README.md); full delivery pending. |\n'+s[a:];p.write_text(s,encoding='utf-8',newline='\n')
p=Path('benchmarks/EXPERIMENTS.md');s=p.read_text(encoding='utf-8');s+='\n\n[R418 reusable method-format layout](results/2026-11-15-method-format-layout/README.md), retained9d071eba/8afb. One execution-owned layout replaces repeated scans/metadata/native specs for format/map; deferred errors/current tokens and existing ownership.12internal/682public each actual11/10 pass;3CPython programs.18.47%less report allocation,warm17.4–19.3%/fresh18.2–19.8%lower elapsed with CPU support. Moving f-string/adverse CSV controls and conservative retained charge accepted; full delivery pending, publication held. B812all gates/cleanup pass; original0edalias custody retained. Broader roadmap active.\n';p.write_text(s,encoding='utf-8',newline='\n')
print('R418 coherent replacement/source/images/controls/ownership tradeoffs preserved; full delivery remains pending.')
