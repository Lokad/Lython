from pathlib import Path
import ast,shutil
r=Path(__file__).parent;old=r.parent/'format-sinks-r416';shutil.copyfile(old/'catalog.json',r/'catalog.json')
s=(old/'prepare-vm.py').read_text(encoding='utf-8')
s=s.replace('format-sinks-b809-20261115','format-layout-b812-20261115').replace('lython-b809-format-sinks-20261115','lython-b812-format-layout-20261115').replace('B809','B812')
s=s.replace('R416 uncommitted8afb146e versus qualified2865f619/frozen55ba4c8a','R418 uncommitted9d071eba versus qualifiedb06b8593/frozen8afb146e')
s=s.replace('Single field append contract and operation-owned metadata; complete format-method report warm/fresh plus f-string report and CSV controls. Actual async contract covered separately by tests.','Execution-owned reusable method-format template/field/native-spec layout; complete report warm/fresh plus unchanged f-string/CSV controls. Semantic/async/ownership checks separate.')
a=s.index("proof=json.loads((r/'historical-aliases.json')");b=s.index('with tarfile.open(q/',a)
s=s[:a]+'''proof=json.loads((r/'historical-aliases.json').read_text(encoding='utf-8'));custody=proof['custody'];raw=(repo/custody['archive']).read_bytes();assert subprocess.check_output(['git','show',custody['commit']+':'+custody['archive']])==raw
with tarfile.open(fileobj=io.BytesIO(raw)) as t:core=t.extractfile(custody['member']).read()
assert hashlib.sha256(raw).hexdigest()==custody['archiveSHA256'] and hashlib.sha256(core).hexdigest()==proof['sha256'] and len(core)==proof['bytes'] and proof['links']==len(proof['paths'])
groups=[proof]
canonical='benchmarks/results/2026-11-15-method-format-attribution/observations.tgz';raw=(repo/canonical).read_bytes();assert subprocess.check_output(['git','show',head+':'+canonical])==raw
groups.append(dict(paths=['format-program-b811-20261115/observations.tgz'],bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest(),links=1,optional=True,custody=dict(commit=head,archive=canonical,archiveSHA256=hashlib.sha256(raw).hexdigest(),member=None)))
'''+s[b:]
s=s.replace("['identity.json','additional.json','collect.py','archive-owned.py','run.sh']","['identity.json','collect.py','archive-owned.py','run.sh']")
s=s.replace("source='/home/lokad/lython-bench-checks/stores-cpython-b807-20261115'","source='/home/lokad/lython-bench-checks/format-sinks-b809-20261115'")
s=s.replace("os.link(source/'representative.json',root/'representative.json')","os.link(source/'representative.json',root/'representative.json');os.link(source/'additional.json',root/'additional.json')")
ast.parse(s);(r/'launch-vm.py').write_text(s,encoding='utf-8',newline='\n')
t=(old/'summarize.py').read_text(encoding='utf-8');(r/'summarize.py').write_text(t,encoding='utf-8',newline='\n')
print('Prepared existing four-job source pair; current8afb and preceding55ba remain. Retire archived0ed aliases and committed B811 working archive only with fresh proof.')
