from pathlib import Path
import shutil
r=Path(__file__).parent.parent/'format-layout-r418';r.mkdir()
files=['src/Lokad.Lython/Runtime/Text/PyStringOps.Formatting.cs','src/Lokad.Lython/Runtime/LythonRuntime.StringMembers.AffixFormat.cs','src/Lokad.Lython/Runtime/LythonRuntime.Operations.Formatting.cs','tests/Lokad.Lython.Tests/FormatStorageTests.cs','tests/Lokad.Lython.Tests/StringFormatPrimitiveTests.cs','tests/Lokad.Lython.Tests/PyStringOpsPrimitiveTests.cs']
for n in files:
 p=r/'original'/n;p.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(n,p)
p=Path(files[0]);s=p.read_text(encoding='utf-8')
s=s.replace('Func<GovernedByteBuilder, object, char?, string?, ValueTask>','Func<GovernedByteBuilder, object, char?, string?, LythonRuntime.InterpolatedFormatSpecifier?, ValueTask>')
s=s.replace('Func<string, ValueTask<object>>? resolveKeyword = null)','Func<string, ValueTask<object>>? resolveKeyword = null,\n        FormatTemplate? prepared = null)')
s=s.replace('        var state = new FormatState(','''        using var layoutStorage = prepared is null ? governor?.ReserveTemporary(EstimateFormatTemplateBytes(template, cancellationToken), span) : null;
        prepared ??= ParseFormatTemplate(template.Utf8Bytes, 0, null, span, cancellationToken);
        var state = new FormatState(''')
s=s.replace('AppendFormatTemplateAsync(state, template.Utf8Bytes, builder)','AppendFormatTemplateAsync(state, prepared, builder)')
a=s.index('    private static async ValueTask AppendFormatTemplateAsync(');b=s.index('    private static async ValueTask AppendFormatFieldAsync(',a)
s=s[:a]+'''    private static async ValueTask AppendFormatTemplateAsync(
        FormatState state, FormatTemplate template, GovernedByteBuilder builder)
    {
        foreach (var part in template.Parts)
        {
            state.CancellationToken.ThrowIfCancellationRequested();
            if (part.Error is { } error) throw new InvalidOperationException(error);
            if (part.Field is { } field)
                await AppendFormatFieldAsync(state, field, builder).ConfigureAwait(false);
            else builder.Append(part.Literal.Span);
        }
    }

'''+s[b:]
a=s.index('    private static async ValueTask AppendFormatFieldAsync(');b=s.index('        object selected;',a)
scan=s[a:b]
scan=scan[scan.index('        var end ='):]
cut=scan.index('        // Keep operation-owned metadata')
scan=scan[:cut]
scan=scan.replace('state.CancellationToken','token')
parse='''    private static FormatField ParseFormatField(ReadOnlyMemory<byte> fieldBytes, int depth,
        MemoryGovernor? owner, LythonSourceSpan? span, CancellationToken token)
    {
'''+scan+'''        var root = Encoding.UTF8.GetString(fieldBytes.Span[..rootEnd]);
        var suffixEnd = fieldNameEnd;
        if (trailing)
        {
            Rune.DecodeFromUtf8(fieldBytes.Span[fieldNameEnd..], out _, out var width);
            suffixEnd += width;
        }
        var suffix = Encoding.UTF8.GetString(fieldBytes.Span[rootEnd..suffixEnd]);
        string? spec = null;
        FormatTemplate? nested = null;
        var recursive = false;
        if (specStart >= 0 && specStart < end)
        {
            var rawSpec = fieldBytes[specStart..];
            if (rawSpec.Span.Contains((byte)'{') || rawSpec.Span.Contains((byte)'}'))
            {
                recursive = depth >= 1;
                if (!recursive) nested = ParseFormatTemplate(rawSpec, depth + 1, owner, span, token);
            }
            else spec = Encoding.UTF8.GetString(rawSpec.Span);
        }
        var prepared = LythonRuntime.PrepareConstantFormatSpecifier(spec, span ?? new(0, 0, 0, 0));
        return new(root, suffix, conversion, spec, nested, recursive, prepared);
    }

'''
q=Path('src/Lokad.Lython/Runtime/Text/PyStringOps.FormatTemplate.cs');t=q.read_text(encoding='utf-8');pos=t.rfind('\n}');t=t[:pos]+'\n'+parse+t[pos:];q.write_text(t,encoding='utf-8',newline='\n')
s=s[:a]+'''    private static async ValueTask AppendFormatFieldAsync(
        FormatState state, FormatField field, GovernedByteBuilder builder)
    {
        state.CancellationToken.ThrowIfCancellationRequested();
        var root = field.Root;
        var conversion = field.Conversion;
'''+s[b:]
a=s.index('        // The suffix carries');b=s.index('        if (suffix.Length != 0)',a)
s=s[:a]+'        var suffix = field.Suffix;\n'+s[b:]
a=s.index('        string? spec = null;',s.index('private static async ValueTask AppendFormatFieldAsync'));b=s.index('        if (conversion is null && spec is null',a)
s=s[:a]+'''        var spec = field.Spec;
        if (field.RecursiveSpec) throw new InvalidOperationException("Max string recursion exceeded");
        if (field.NestedSpec is { } nestedTemplate)
        {
            var nested = CreateBuilder(state.Governor, state.Span);
            try
            {
                await AppendFormatTemplateAsync(state, nestedTemplate, nested).ConfigureAwait(false);
                state.AdmitMetadata(checked(32L + 2L * nested.Length));
                spec = Encoding.UTF8.GetString(nested.WrittenSpan);
            }
            finally { nested.Release(); }
        }

'''+s[b:]
s=s.replace('        public int Depth;\n','')
s=s.replace(' : null, spec).ConfigureAwait(false)', ' : null, spec, field.PreparedSpec).ConfigureAwait(false)')
p.write_text(s,encoding='utf-8',newline='\n')
# Both runtime method routes share one lazy execution-owned layout. An internal
# callable reused with another owner prepares storage admitted by that new owner.
p=Path(files[1]);s=p.read_text(encoding='utf-8');a=s.index('                    "format" =>');b=s.index('                    _ =>',a)
s=s[:a]+'''                    "format" => CreateFormattingMethod(false),
                    "format_map" => CreateFormattingMethod(true),
'''+s[b:]
a=s.index('                BoundCallable CreatePartitionMethod(')
s=s[:a]+'''                ICallable CreateFormattingMethod(bool mapping)
                {
                    PyStringOps.FormatTemplate? prepared = null;
                    PyStringOps.FormatTemplate Prepare(ExecutionContext context, LythonSourceSpan span)
                    {
                        context.CheckExecution(span);
                        if (!ReferenceEquals(prepared?.Owner, context.MemoryGovernor))
                            prepared = PyStringOps.PrepareFormatTemplate(text, context.MemoryGovernor, span, context.State.CancellationToken);
                        return prepared!;
                    }
                    return mapping
                        ? BoundCallable.Create(
                            (arguments, span, context) => FormatMappingAsync(text, arguments[0], span, context, false, Prepare(context, span)).GetAwaiter().GetResult(),
                            StrFormatMapSignature,
                            (arguments, span, context) => FormatMappingAsync(text, arguments[0], span, context, true, Prepare(context, span)))
                        : new CustomMethodCallable(
                            (arguments, span, context) => FormatStringAsync(text, arguments, span, context, false, Prepare(context, span)).GetAwaiter().GetResult(),
                            (arguments, span, context) => FormatStringAsync(text, arguments, span, context, true, Prepare(context, span)));
                }

'''+s[a:]
s=s.replace('ExecutionContext context, bool asynchronous)\n        {','ExecutionContext context, bool asynchronous, PyStringOps.FormatTemplate prepared)\n        {',2)
s=s.replace('(output, value, conversion, spec) =>','(output, value, conversion, spec, nativeSpec) =>')
s=s.replace('spec, context, span, asynchronous)', 'spec, context, span, asynchronous, nativeSpec)')
s=s.replace('cancellationToken: context.State.CancellationToken).ConfigureAwait(false)', 'cancellationToken: context.State.CancellationToken, prepared: prepared).ConfigureAwait(false)')
s=s.replace('resolveKeyword: ResolveKeyword).ConfigureAwait(false)', 'resolveKeyword: ResolveKeyword, prepared: prepared).ConfigureAwait(false)')
p.write_text(s,encoding='utf-8',newline='\n')
p=Path(files[2]);s=p.read_text(encoding='utf-8');s=s.replace('LythonSourceSpan span, bool asynchronous)\n    {\n        if (value is PyInstance instance)','LythonSourceSpan span, bool asynchronous,\n        InterpolatedFormatSpecifier? prepared = null)\n    {\n        if (value is PyInstance instance)');s=s.replace('else AppendInterpolatedStringPart(output, value, conversion, specifier, context, span);','else AppendInterpolatedStringPart(output, value, conversion, specifier, context, span, prepared);');p.write_text(s,encoding='utf-8',newline='\n')
print('R418 production migration written; test callback signatures/build remain.')
