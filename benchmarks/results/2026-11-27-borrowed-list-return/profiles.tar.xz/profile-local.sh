set -eu
src="$1"
target=$(mktemp -d "$HOME/lython-borrowed-list-profile-XXXXXX")
cp -r "$src/current" "$src/profile-identity.json" "$src/representative.json" "$src/cpython-worker.py" "$src/profile.py" "$target"
printf '%s\n' "$target"
python3 "$target/profile.py" shipment
python3 "$target/profile.py" file-fed
