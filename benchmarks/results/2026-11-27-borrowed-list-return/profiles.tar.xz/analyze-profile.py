from pathlib import Path
import json
lab=Path(__file__).resolve().parent
markers=['ExecuteInstructionPrefix','PyStarmapIterator','StartStagedListYield','TryStartDirectOperandReturn','PyMapIterator','TryEvaluateDirectFieldCallReturn','UnpackNextAsync']
rows=[]
for label in ('shipment','file-fed'):
    folder=lab/label
    capture=json.loads((folder/'capture.json').read_text(encoding='utf-8'))
    trace=json.loads((folder/'observed.speedscope.json').read_text(encoding='utf-8'))
    names=[entry['name'] for entry in trace['shared']['frames']]
    counts=dict.fromkeys(markers,0.0)
    total=0.0
    for profile in trace['profiles']:
        assert profile['type']=='evented' and profile['unit']=='milliseconds'
        stack=[]
        last=profile['startValue']
        for event in profile['events']:
            dt=event['at']-last
            assert dt>=0
            if stack:
                total+=dt
                for name in markers:
                    if any(name in names[i] for i in stack): counts[name]+=dt
            last=event['at']
            if event['type']=='O': stack.append(event['frame'])
            else: assert stack.pop()==event['frame']
        assert not stack
    row=dict(workload=capture['case'],verifiedInvocations=capture['observedInvocations'],
             sampledThreadMilliseconds=total,ancestryThreadMilliseconds=counts)
    rows.append(row)
    print(row)
(lab/'profile-times.json').write_text(json.dumps(rows,indent=2)+'\n',encoding='utf-8',newline='\n')
