from hashlib import sha256
from pathlib import Path
import importlib.util
import json
import os
import subprocess
import tempfile
import time

lab=Path(__file__).resolve().parent
import sys
label=sys.argv[1]
output=lab/label
output.mkdir()
pin=json.loads((lab/'profile-identity.json').read_text())
image=lab/'current'
sha=lambda obj:sha256(obj.read_bytes()).hexdigest()
assert {p.name:sha(p) for p in image.iterdir()}==pin['imageFiles']
catalog=lab/'representative.json'
assert sha(catalog)==pin['catalogSHA256']
python=lab/'cpython-worker.py'
assert sha(python)==pin['cpythonWorkerSHA256']
spec=importlib.util.spec_from_file_location('protocol',python)
protocol=importlib.util.module_from_spec(spec)
spec.loader.exec_module(protocol)
lookup={'shipment': 'diagnostic.shipment-starmap-wide-lists', 'file-fed': 'diagnostic.shipment-file-fed-map'}
case,=[row for row in json.loads(catalog.read_text())['cases'] if row['id']==lookup[label]]
fields={key:case[key] for key in ('sourceSha256','fixtureSha256','expectedOutputSha256')}
sdk=Path.home()/'.dotnet'
env=dict(os.environ,DOTNET_ROOT=str(sdk))
sequence=0
trace=output/'observed.nettrace'
with tempfile.TemporaryDirectory(dir='/dev/shm',prefix='lython-first-line-') as ram, (output/'worker.log').open('wb') as errors:
    assert os.stat(ram).st_dev!=os.stat(lab).st_dev
    folder=tempfile.mkdtemp(dir=ram,prefix='lython-comparison-files-')
    child=subprocess.Popen([sdk/'dotnet',image/'Lokad.Lython.Benchmarks.dll','--compare','worker','--catalog',catalog],
                           cwd=folder,env=dict(env,TMPDIR=ram),stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=errors)
    with child:
        def request(op, count):
            global sequence
            sequence+=1
            protocol.write_frame(child.stdin,dict(fields,protocolVersion=2,requestId=sequence,operation=op,caseId=case['id'],lane='warm-async',iterations=count))
            reply=protocol.read_frame(child.stdout)
            assert reply['requestId']==sequence and reply['status']==('Equivalent' if op=='verify' else 'Completed')
            assert reply['actualOutputSha256']==case['expectedOutputSha256'] and reply['actualFilesSha256']==case['expectedFilesSha256']
            assert reply['completedInvocations']==count
            return reply
        try:
            identity=protocol.read_frame(child.stdout)
            assert identity['status']=='Ready' and identity['catalogSha256']==pin['catalogSHA256']
            assert pin['imageFiles']['Lokad.Lython.dll']==next(i['sha256'] for i in identity['libraries'] if Path(i['path']).name=='Lokad.Lython.dll')
            request('verify',2)
            start=time.monotonic()
            while time.monotonic()-start<4: request('batch',128)
            with (output/'collection.log').open('wb') as collector:
                profiler=subprocess.Popen([sdk/'tools/dotnet-trace','collect','-p',str(child.pid),'--format','Speedscope','--profile','dotnet-sampled-thread-time','--duration','00:00:00:06','--buffersize','32','-o',trace],env=dict(env,TMPDIR=ram),stdout=collector,stderr=collector,stdin=subprocess.DEVNULL)
                replies=[]
                limit=time.monotonic()+18
                try:
                    while profiler.poll() is None and time.monotonic()<limit:
                        replies.append(request('batch',128))
                    profiler.wait(timeout=6)
                    assert profiler.returncode==0
                finally:
                    if profiler.poll() is None: profiler.terminate();profiler.wait(timeout=6)
            request('verify',2)
            (output/'capture.json').write_text(json.dumps(dict(identity=identity,case=case['id'],observedInvocations=sum(x['completedInvocations'] for x in replies),elapsedTicks=sum(x['elapsedTicks'] for x in replies),batches=len(replies),clock=replies[0]['clockFrequency'],captureSha256=sha(trace)),indent=2)+'\n')
        finally:
            if child.poll() is None:
                sequence+=1
                protocol.write_frame(child.stdin, dict(protocolVersion=2,requestId=sequence,operation='quit'))
                assert protocol.read_frame(child.stdout)['status']=='Closed'
            assert child.wait(timeout=6)==0
with (output/'top.txt').open('w') as result:
    subprocess.run([sdk/'tools/dotnet-trace','report',trace,'topN','-n','30'],stdout=result,text=True,env=env,timeout=25,check=True)
print((output/'top.txt').read_text())
