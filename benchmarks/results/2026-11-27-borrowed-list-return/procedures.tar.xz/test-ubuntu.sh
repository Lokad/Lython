set -eu
source_root=/mnt/d/code/Lython
target_root="$HOME/lython-starmap-rows-8066Vm"
test -d "$target_root"
for file in src/Lokad.Lython/Runtime/LythonRuntime.Executable.Interpreter.cs src/Lokad.Lython/Runtime/LythonRuntime.Generators.cs src/Lokad.Lython/Runtime/PyExecutableFunction.cs tests/Lokad.Lython.PublicApi.Tests/StarmapMaterializationParityTests.cs; do
    cp -- "$source_root/$file" "$target_root/$file"
    cmp -- "$source_root/$file" "$target_root/$file"
done
cd "$target_root"
filter='Category!=Stress&(FullyQualifiedName~Starmap|FullyQualifiedName~IteratorAdapter|FullyQualifiedName~DelayedHostComposition|FullyQualifiedName~NativeGenerator|FullyQualifiedName~CallablePacketOwnership)'
for suite in Lokad.Lython.PublicApi.Tests Lokad.Lython.Tests; do
    "$HOME/.dotnet/dotnet" test "tests/$suite/$suite.csproj" -c Release -f net10.0 --no-restore --filter "$filter"
done
