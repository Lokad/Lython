set -eu
source_root=/mnt/d/code/Lython
target_root="$HOME/lython-starmap-rows-8066Vm"
test -d "$target_root"
for file in src/Lokad.Lython/Runtime/LythonRuntime.Executable.Interpreter.cs src/Lokad.Lython/Runtime/LythonRuntime.Generators.cs src/Lokad.Lython/Runtime/PyExecutableFunction.cs tests/Lokad.Lython.PublicApi.Tests/StarmapMaterializationParityTests.cs; do
    cp -- "$source_root/$file" "$target_root/$file"
    cmp -- "$source_root/$file" "$target_root/$file"
done
cd "$target_root"
filter='FullyQualifiedName~StagedSelectorKeepsAliasAndRetiresRowBeforeTruthProtocol'
"$HOME/.dotnet/dotnet" test tests/Lokad.Lython.PublicApi.Tests/Lokad.Lython.PublicApi.Tests.csproj -c Release -f net10.0 --no-restore --filter "$filter"
