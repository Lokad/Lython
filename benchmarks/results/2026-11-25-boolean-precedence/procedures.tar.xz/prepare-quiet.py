from pathlib import Path
import hashlib
import json
import shutil
import tarfile

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
base = lab.with_name("closed-iteration-call-20261125")
quiet = lab / "comparison/quiet"
baseline = base / "comparison/quiet"
output = quiet / "payload.tar.gz"
read = lambda path: json.loads(path.read_text(encoding="utf-8-sig"))
digest = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
save = lambda path, data: path.write_text(json.dumps(data, indent=2) + "\n", encoding="utf-8", newline="\n")
write = lambda path, text: path.write_text(text, encoding="utf-8", newline="\n")
identity = read(quiet / "identity.json")
donor = read(baseline / "identity.json")
receipt = read(baseline / "terminal-status.json")["receipt"]
assert receipt["complete"] and receipt["quietBeforeAndAfter"]
assert digest(baseline / "observations.tar.xz") == receipt["archiveSHA256"]
assert identity["imageFiles"]["reference"] == donor["imageFiles"]["candidate"]
for role, files in identity["imageFiles"].items():
    assert {p.name: digest(p) for p in (lab / role).iterdir()} == files
    assert read(lab / "comparison" / (role + "-verify.json"))["state"] == "Completed"
sparse="scripts.config-generated-guards.medium.bad-0.sparse-lexical"
mixed="diagnostic.config-mixed-boolean-guards"
manifest="scripts.config-manifest.small"
jobs=[
    [sparse,"compile"], [mixed,"compile"], [manifest,"compile"], [sparse,"compile-run"],
    ["diagnostic.generated-ordinary-definitions","compile"], [mixed,"compile-run"],
    [manifest,"compile-run"], ["scripts.csv-invoice.method-policy.quoted-control","warm"],
]
save(quiet / "jobs.json", dict(warm=jobs))
identity["catalogs"]["jobs.json"] = dict(sha256=digest(quiet / "jobs.json"))
save(quiet / "identity.json", identity)
shutil.copyfile(baseline / "run.sh", quiet / "run.sh")
assert b"\r" not in (quiet / "run.sh").read_bytes()
collect = (baseline / "collect.py").read_text(encoding="utf-8").replace("len(jobs) == 10", "len(jobs) == 8")
collect = collect.replace(" < 454,", " < 394,").replace("b1687-fixtures", "b1690-fixtures")
assert "len(jobs) == 8" in collect
compile(collect, "collect.py", "exec")
write(quiet / "collect.py", collect)
with tarfile.open(output, "w:gz", compresslevel=3) as archive:
    for name in ("identity.json", "jobs.json", "representative.json", "run.sh", "collect.py"):
        archive.add(quiet / name, arcname=name)
    archive.add(lab / "candidate/Lokad.Lython.dll", arcname="candidate-core.dll")
save(quiet / "upload.json", dict(root="boolean-precedence-b1690-20261125", reference="closed-iteration-call-b1687-20261125",
                                 payloadSHA256=digest(output), payloadBytes=output.stat().st_size))
save(lab / "verified-raw-replicas.json", [])
launcher = (base / "quiet.py").read_text(encoding="utf-8").replace("b1687", "b1690")
launcher = launcher.replace("lython-b1690-closed-iteration-call", "lython-b1690-boolean-precedence")
launcher = launcher.replace("65310f8a64f5438e044e291c6eed16c86bb15990eee4ce1a5fa90f4cd20ab3c5", receipt["archiveSHA256"])
launcher = launcher.replace("seconds=431", "seconds=352").replace("RuntimeMaxSec=485", "RuntimeMaxSec=415")
compile(launcher, "quiet.py", "exec")
write(lab / "quiet.py", launcher)
report = (base / "archive.py").read_text(encoding="utf-8").replace("2026-11-25-closed-iteration-call", "2026-11-25-boolean-precedence")
report = report.replace("==10", "==8").replace("timedBatches=280,lanes=10", "timedBatches=224,lanes=8")
compile(report, "archive.py", "exec")
write(lab / "archive.py", report)
print("Eight quiet lanes prepared and complete worker images verified.")
