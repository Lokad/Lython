from pathlib import Path
import base64
import hashlib
import json
import subprocess
import tempfile

lab=Path(__file__).resolve().parent
prior=lab.with_name("shared-function-local-slots-20261125")
current=lab.with_name("closed-iteration-call-20261125")
read=lambda path: json.loads(path.read_text(encoding="utf-8-sig"))
cat=read(prior/"comparison/quiet/representative.json")
for item in read(current/"comparison/quiet/representative.json")["cases"]:
    if item["id"]=="diagnostic.generated-ordinary-definitions":
        cat["cases"].append(item)
cat["cases"]=[item for item in cat["cases"] if item["id"]!="diagnostic.generated-record-classifier"]
sparse=next(item for item in cat["cases"] if item["id"]=="scripts.config-generated-guards.medium.bad-0.sparse-lexical")
assert sparse["source"].count("if value < 0:")==96
source=sparse["source"].replace("if value < 0:", "if value < 0 or value > 25 and value % 2 == 0:")
with tempfile.TemporaryDirectory(prefix="lython-boolean-golden-") as folder:
    fixture=json.loads(sparse["fixtureJson"])
    assert list(fixture["inputFiles"])==["config.json"]
    (Path(folder)/"config.json").write_bytes(base64.b64decode(fixture["inputFiles"]["config.json"]))
    output=subprocess.check_output(["C:/Python313/python.exe","-I","-X","utf8","-c",source],cwd=folder,encoding="utf-8")
assert output != sparse["expectedOutput"]
digest=lambda text:hashlib.sha256(text.encode("utf-8")).hexdigest()
cat["cases"].append(sparse | dict(id="diagnostic.config-mixed-boolean-guards",source=source,
    sourceUtf8Bytes=len(source.encode("utf-8")),sourceSha256=digest(source),
    expectedOutput=output,expectedOutputSha256=digest(output),expectedOutputUtf8Bytes=len(output.encode("utf-8"))))
assert len(cat["cases"])==6
(lab/"input-catalog.json").write_text(json.dumps(cat,ensure_ascii=False,indent=2)+"\n",encoding="utf-8",newline="\n")
