from pathlib import Path
import ast,datetime,hashlib,io,json,shlex,subprocess,tarfile
r=Path(__file__).parent.parent/'normalization-cost-r434';q=r/'profile';q.mkdir(parents=True)
old=r.parent/'calls-current-r420/profile';base=r.parent/'completed-async-r433/quiet'
remote='/home/lokad/lython-bench-checks/normalization-cost-b831-20261116';unit='lython-b831-normalization-cost-20261116';source=json.loads((base/'config.json').read_text(encoding='utf-8'))
image=source['identity']['imageFiles']['reference'];identity=dict(sourceRevision='86d9344e/frozenecd9e956',runtimeCommit='86d9344e654e94eeab738c8156bd2b7f95c12576',purpose='R434 one current complete normalization CPU profile after R429/R430. Attribute generator/call advancement, text/storage, admission and host/cleanup work before selecting a coherent displacement; not a timing comparison.',coreSHA256=dict(candidate=image['Lokad.Lython.dll']),auxiliaryFiles={n:h for n,h in image.items()if n!='Lokad.Lython.dll'},catalogSHA256=source['sourceCatalogSHA256'],qualification='43805966777GREEN Windows/Ubuntu actual11/10 ordinary/stress/installed Release consumers; unchanged production. R433 runtime withdrawn; terminal cached.',publicationHeld=True)
(q/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8',newline='\n')
for n in ['ops-profile.py','collect.py','run.sh','retrieve.py']:
 s=(old/n).read_text(encoding='utf-8').replace('current-calls-b815-20261115','normalization-cost-b831-20261116').replace('lython-b815-current-calls-20261115',unit).replace('B815','B831')
 s=s.replace("['report']","['normalization']").replace("[('report','scripts.report-render.format-method.large','warm')]","[('normalization','scripts.text-normalization.large','warm')]")
 s=s.replace('count = 128 # Complete report; ~0.7s batches, one bounded capture.', 'count = 512 # Complete normalization; bounded batches/capture, no timing comparison.')
 s=s.replace('Committedc023042d/frozen0393331a; R420 current complete method-report call attribution','Qualified86d9344e/frozenecd9e956; R434 complete normalization attribution')
 if n.endswith('.py'):ast.parse(s)
 (q/n).write_text(s,encoding='utf-8',newline='\n')
archive='benchmarks/results/2026-11-16-completed-async-entry/procedure-and-prototype.tar.xz';raw=Path(archive).read_bytes();commit=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();assert raw==subprocess.check_output(['git','show',commit+':'+archive])
member='frozen/candidate/Lokad.Lython.dll'
with tarfile.open(fileobj=io.BytesIO(raw))as a:core=a.extractfile(member).read()
proof=dict(sha256=hashlib.sha256(core).hexdigest(),bytes=len(core),links=1,paths=['completed-async-b830-20261116/candidate/Lokad.Lython.dll'],custody=dict(commit=commit,archive=archive,archiveSHA256=hashlib.sha256(raw).hexdigest(),member=member))
assert proof['sha256']=='7c59206631c3670004abaa83c237c4f939f4b6a15e8e76d934275e38dd163a6d'
with tarfile.open(q/'payload.tgz','w:gz')as a:
 for n in ['identity.json','ops-profile.py','collect.py','run.sh']:a.add(q/n,arcname=n)
with tarfile.open(q/'payload.tgz')as a:unpacked=sum(m.size for m in a if m.isfile())
c=dict(root=remote,unit=unit,source=source['root'],sourceFiles=image,sourceCatalogSHA256=identity['catalogSHA256'],identity=identity,retireGroups=[proof],payloadBytes=(q/'payload.tgz').stat().st_size,payloadSHA256=hashlib.sha256((q/'payload.tgz').read_bytes()).hexdigest(),unpackedBytes=unpacked)
(q/'config.json').write_text(json.dumps(c,indent=2)+'\n',encoding='utf-8',newline='\n')
s=(old/'launch-command.py').read_text(encoding='utf-8');tree=ast.parse(s);node=next(n for n in tree.body if isinstance(n,ast.Assign)and any(isinstance(t,ast.Name)and t.id=='c'for t in n.targets));lines=s.splitlines(keepends=True);s=''.join(lines[:node.lineno-1])+'c='+repr(c)+'\n'+''.join(lines[node.end_lineno:])
s=s.replace("source/'candidate'","source/'reference'").replace("source/'additional.json'","source/'representative.json'").replace('lython-b815-fixtures','lython-b831-fixtures');ast.parse(s)
(q/'launch-command.py').write_text(s,encoding='utf-8',newline='\n')
p=Path('PLAN.md');text=p.read_text(encoding='utf-8');a=text.index('4. **Next substantial-cost selection');b=text.index('\nR429retains',a)
text=text[:a]+'''4. **R434 active: current complete normalization CPU attribution.** One bounded
   perf capture on the existing quiet VM, fully qualifiedecd9 source/image and
   unchanged catalog/goldens. Different workload from R420report. Eight guest
   seconds warmup/five-second capture, existing199Hz CPU-clock/frame-pointer tooling;
   retain unmapped and other-thread samples. Diagnostic perf-map override, no timing
   comparison. Separate nearest/exclusive frames from inclusive useful work; host
   reset/I/O/goldens/cleanup are included in broader worker sampling. Investigate
   generator/call transitions, native text/storage and admission. Stop with either
   a concrete displaced representation and semantic gates for an integrated redesign,
   or an explicit unresolved attribution with changed evidence needed. No invented
   wrapper/arena, repeated report capture, fixed-percent veto or performance claim
   from source counts. Current ratios and CPython process-initialization uncertainty
   remain; this does not complete the broader performance objective.
'''+text[b:];p.write_text(text,encoding='utf-8',newline='\n')
print(json.dumps(dict(prepared=True,source=identity['sourceRevision'],retireOnlyWithdrawnPrototype=proof['paths'],reserveMiB=2.5,publicationHeld=True)))
