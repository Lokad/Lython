from pathlib import Path
import datetime,json,shlex,subprocess
q=Path(__file__).parent.parent/'normalization-cost-r434/profile';assert not(q/'launch.log').exists()
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
p=subprocess.run(ssh+['python3 -c '+shlex.quote((q/'launch-command.py').read_text(encoding='utf-8'))],input=(q/'payload.tgz').read_bytes(),capture_output=True,timeout=60);(q/'launch.log').write_bytes(p.stdout+p.stderr);assert p.returncode==0,p.stdout+p.stderr
now=datetime.datetime.now(datetime.timezone.utc);(q/'observe-not-before.json').write_text(json.dumps(dict(launchedUTC=now.isoformat(),doNotObserveBeforeUTC=(now+datetime.timedelta(seconds=75)).isoformat()),indent=2)+'\n',encoding='utf-8',newline='\n');print(p.stdout.decode())
