from pathlib import Path
r=Path(__file__).parent
s=(r.parent/'calls-current-r420/analyze.py').read_text(encoding='utf-8').replace("['report']","['normalization']")
a=s.index(" groups={");b=s.index('\n inclusive=',a)
s=s[:a]+''' groups={'generator/iteration':['PyGenerator::','Advance','MoveNext','PyIteration+Cursor','ReadResult','EnterFrame','LeaveFrame'],'instruction dispatch':['ExecuteInstructionPrefix','ExecuteUntilCall','CompleteCallFrame'],'call/binding':['BeginFunctionCall','InvokeExecutableGeneralTarget','PrepareExecutableCallArguments','InvokeBorrowedCallableTarget','BindFunctionArguments'],'native text and byte storage':['PyStringOps','GovernedByteBuilder','PyString::','WriteNativeUtf8'],'admission/checks':['MemoryGovernor::Reserve','TryResize','CheckExecution','ReserveTemporary','ReleaseReserved'],'host/file/projection':['FileModule','PyFile','ComparisonFileHost','LythonValueProjector','ComparisonInvocation','Project']}
'''+s[b:]
(r/'analyze.py').write_text(s,encoding='utf-8',newline='\n')
