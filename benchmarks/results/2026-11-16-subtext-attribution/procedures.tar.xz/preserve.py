from pathlib import Path
import hashlib,json,shutil,tarfile
r=Path(__file__).parent;q=r/'profile';out=Path('benchmarks/results/2026-11-16-subtext-attribution');out.mkdir()
receipt=json.loads((q/'archive-receipt.json').read_text(encoding='utf-8'));assert receipt['complete']and receipt['quietBeforeAndAfter']and receipt['allWorkersJoined']and receipt['ramTraceArchivedAndVerifiedBeforeUnmount'];assert hashlib.sha256((q/'observations.tgz').read_bytes()).hexdigest()==receipt['archiveSHA256']
for name in ['identity.json','archive-receipt.json','terminal-status.json','observations.tgz']:shutil.copyfile(q/name,out/name)
shutil.copyfile(r/'attribution.json',out/'attribution.json')
with tarfile.open(out/'procedures.tar.xz','w:xz')as a:
 for folder in [r,q]:
  for p in sorted(folder.iterdir()):
   if p.is_file()and p.name not in ['observations.tgz','payload.tgz','attribution.json']:a.add(p,arcname=p.relative_to(r).as_posix())
 a.add(r.parent/'completed-async-r433/prepare-next-profile.py',arcname='prepare.py');a.add(r.parent/'completed-async-r433/launch-next-profile.py',arcname='launch.py')
(out/'README.md').write_text('''# Current complete-normalization attribution

R434/B831,2026-11-16UTC, fully qualified **86d9344e /ecd9e956**.
Unchanged complete4,096line/52,224B normalization, stdout/file goldens and
existing worker. Eight guest seconds warmup,199Hz perf CPU-clock/frame-pointer,
4.828guest seconds/4,096invocations sampled. Same quiet F4as_v7/Ubuntu24.04.4,
four EPYC9V45vCPUs,16GiB/no swap,.NET11RC3 natural workstation GC/normal
tiering. Diagnostic perf-map override; **no timing comparison or speedup**.

926active-thread samples,138unmapped leaves,0ambiguous map matches; all retained.
Nearest Lython frames:120ordinary instruction prefix,69string-method operation,
58expandtabs,40splitlines,39rstrip,36split,33Reserve,30native-call selection,
26generator Advance,26replace. Exclusive mapped leaves include119instruction
prefix,69SpanHelpers search,35memmove,33string method,32rstrip,30native-call
selection,27expandtabs and25Advance. Inlining limits exact attribution.

Inclusive groups overlap:531generator/iteration,303text/storage,33admission,
59host/file/projection,50call/binding and913instruction dispatch. These include
useful operations and cannot be added or called removable overhead. Active worker
4.67CPU seconds; background GC.11/JIT.03; all other-thread CPU/samples retained.
Sampling includes mediated RAM I/O, reset/protocol/goldens and prior-result cleanup,
wider than guest timing. It does not separately measure compilation/startup, heap,
pending-I/O latency, contention or embedding tails.

Admission is not established as the dominant cost; do not introduce a reservation
cache or budget policy from this profile. Generator work dominates inclusively,
but exclusive advancement alone does not justify a second generator backend.
Unifying stack-local and persistent operand execution remains a larger open design;
a stack-only Span view cannot simply be retained across suspension.

**Next selected source hypothesis:** ordinary subtext construction still allocates
independent UTF8 arrays/copies, while existing same-owner JSON windows already
preserve immutable backing funding without identity tracing. Consolidate slices
and ordinary split fragments onto that existing representation, preserving aggregate
admission and independent foreign/unowned copies. Remove a storage stage rather
than a collection of method-specific tricks. Current source establishes duplicate
payload construction; these samples do not predict its CPU magnitude. Require
semantic/Unicode tests, retained backing/aliases, refusal before publication,
current cancellation and cleanup, then allocation plus one complete-script pair
with synchronous controls. Conservative sibling retention is an explicit tradeoff.

All image/golden/quiet/Closed/exit/join/archive gates pass. RAM trace bytes verified
persistently before unmount, no users remain, terminal cached. Only the withdrawn
prototype's exact committed core replica was retired, with fresh lease/path/UID/
hash/all-alias proof. Current runtime/catalogs/toolchains and254/252MiB floors kept.
No production source change or repeated unchanged full qualification. Publication
held; the substantial whole-script objective is open.

[All samples/unknowns](attribution.json),[exact image](identity.json),
[raw capture](observations.tgz),[procedures/custody](procedures.tar.xz).
''',encoding='utf-8',newline='\n')
p=Path('benchmarks/EXPERIMENTS.md');s=p.read_text(encoding='utf-8');s+='\n\n[R434/B831 complete normalization attribution](results/2026-11-16-subtext-attribution/README.md):qualified86d9344e/ecd9e956,926active samples/138unknown leaves,4.828guest seconds. Instruction prefix119exclusive leaves; generator531inclusive overlaps useful text303, admission33not dominant. No ABI/backend or admission-cache rewrite justified by inclusive totals. Select existing same-owner immutable UTF8 windows for ordinary split/slice storage; concrete payload duplication remains, CPU magnitude unknown. All image/golden/quiet/join/archive gates pass; terminal cached. No runtime edit/speedup or repeated full qualification.\n';p.write_text(s,encoding='utf-8',newline='\n')
p=Path('PLAN.md');s=p.read_text(encoding='utf-8');s=s.replace('Commit this correction/evidence;','Correction/evidence committed/pushed **81474cb7**;');a=s.index('4. **R434 active:');b=s.index('\nR429retains',a)
s=s[:a]+'''4. **R434 attribution complete; R435 selected: shared immutable subtext storage.**
   [Normalization profile](benchmarks/results/2026-11-16-subtext-attribution/README.md)
   at qualifiedecd9:926active samples/138unmapped leaves; ordinary instruction
   prefix119exclusive leaves. Generator531inclusive overlaps text303; admission33
   does not establish a dominant budget cost. No new reservation cache or second
   generator backend. Complete call/frame/operand unification remains open.

   **Hypothesis/displacement:** ordinary slices and split fragments still construct
   independent UTF8 arrays/copies while same-owner JSON already shares admitted
   immutable windows. Consolidate on that existing representation; remove per-fragment
   payload construction for those owned ranges and the duplicate sharing transition.
   Keep short inline, unowned/foreign-source and transformed-output construction.
   No new owners, caches, identity ledgers or tracing; aggregate split admission stays
   before allocation, with source backing/header funded before the first view escapes.
   This is a storage redesign across subtext operations, not another format special case.

   **Affected scripts/acceptance:** complete normalization, captured text/file processing,
   JSON/CSV controls; Unicode/scalar boundaries, nested trims/splits, mutation/identity,
   hashing, output/error order, cancellation, terminal refusal and rollback. Surviving
   aliases retain the full source backing through pending work and scope cleanup;
   foreign-owner input is copied. Conservative sibling retention/earlier rejection
   and changed tiny-budget thresholds are intentional, documented tradeoffs. Use
   focused actual11/10 tests, one short allocation diagnostic and one bounded source
   pair with unchanged controls. Separate removed arrays, allocation and CPU claims.
   Stop with retain/refine/remove and debt explicit; batch full delivery only if retained.
   The broader performance objective remains open after this milestone.
'''+s[b:];p.write_text(s,encoding='utf-8',newline='\n');print('R434 preserved; PLAN selects existing-window subtext storage with explicit limits/acceptance.')
