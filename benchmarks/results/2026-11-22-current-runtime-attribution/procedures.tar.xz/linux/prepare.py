from pathlib import Path
import gzip
import hashlib
import io
import json
import os
import subprocess
import tarfile

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
notes = lab.parent
template = notes / "retained-call-cpu-profile-20261122"
donor = notes / "uniform-eager-annotation-20261122/comparison"
base = "/home/lokad/lython-bench-checks"
root = base + "/current-retained-runtime-b1399-20261122"
unit = "lython-b1399-current-retained-runtime-20261122"
ssh = ["C:/Windows/System32/OpenSSH/ssh.exe", "-i", str(Path.home() / ".ssh/id_lython-bench.pem"),
       "-o", "BatchMode=yes", "-o", "ConnectTimeout=15", "lokad@20.166.121.73"]

def load(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))

def sha(data):
    return hashlib.sha256(data).hexdigest()

def write(path, data):
    if path.suffix == ".py":
        compile(data, str(path), "exec")
    path.write_text(data, encoding="utf-8", newline="\n")

def save(path, obj):
    write(path, json.dumps(obj, indent=2) + "\n")

def pushed(path):
    return subprocess.check_output(["git", "show", "origin/master:" + path.as_posix()], cwd=repo)

def archived_catalog(folder):
    path = Path("benchmarks/results") / folder / "observations.tgz"
    with tarfile.open(fileobj=io.BytesIO(pushed(path)), mode="r:gz") as a:
        return json.load(a.extractfile("representative.json"))

cases = (
    ("candidate-text-summary", "diagnostic.text-summary.nonlocal-computed-width.large", "2026-11-22-retained-source-cpython"),
    ("candidate-postponed", "scripts.annotated-rule-closures.nested-factories.postponed", "2026-11-22-retained-source-cpython"),
)
catalogs = {folder: archived_catalog(folder) for folder in dict.fromkeys(folder for _, _, folder in cases)}
catalog = catalogs[cases[0][2]].copy()
catalog["cases"] = [next(row for row in catalogs[folder]["cases"] if row["id"] == case)
                    for _, case, folder in cases]
catalog["performanceQualified"] = False
save(lab / "catalog.json", catalog)
assert all(sha(row["source"].encode("utf-8")) == row["sourceSha256"] for row in catalog["cases"])

archive_dir = Path("benchmarks/results/2026-11-22-repeated-eager-annotations")
receipt = json.loads(pushed(archive_dir / "archive-receipt.json"))
assert all(receipt[k] for k in ("complete", "allWorkersJoined", "archivedAndVerifiedUnderLease"))
assert sha(pushed(archive_dir / "observations.tgz")) == receipt["archiveSHA256"]
prior = json.loads(pushed(archive_dir / "source.json"))
donor_cfg = load(donor / "quiet/config.json")
files = prior["imageFiles"]["candidate"]
image = donor / "frozen-candidate"
assert len(files) == 32 and {name: sha((image / name).read_bytes()) for name in files} == files
assert files == donor_cfg["identity"]["imageFiles"]["candidate"]
sdk = Path.home() / ".dotnet11"
dotnet = sdk / "dotnet.exe"
env = dict(os.environ, DOTNET_ROOT=str(sdk), DOTNET_ROOT_X64=str(sdk), PATH=str(sdk)+os.pathsep+os.environ["PATH"])
protocol = repo / "benchmarks/cpython-worker.py"
assert sha(protocol.read_bytes()) == prior["protocolSHA256"]
subprocess.run([dotnet, image/"Lokad.Lython.Benchmarks.dll", "--compare", "verify", "--catalog", lab/"catalog.json",
                "--dotnet", dotnet, "--python", "C:/Python313/python.exe", "--python-worker", protocol,
                "--out", lab/"verification.json"], env=env, cwd=repo, check=True, timeout=100)
assert {name: sha((image / name).read_bytes()) for name in files} == files
proof = load(lab/"verification.json")
catalog_sha = sha((lab/"catalog.json").read_bytes())
assert proof["state"] == "Completed" and proof["caseCount"] == 2 and proof["catalogSha256"] == catalog_sha
identity = dict(sourceRevision=prior["candidate"], productionRevision=prior["retainedRevision"],
                purpose="Attribute current postponed factory and nonlocal word-count runtime costs",
                normalAdapterPin="0.4.0", coreSHA256={"candidate": files["Lokad.Lython.dll"]},
                catalogSHA256=catalog_sha, imageFiles={"candidate": files})
save(lab/"identity.json",identity)

old = load(template/"config.json")
jobs = [(name, case, "warm") for name, case, _ in cases]
jobs.append(("candidate-postponed-fresh",cases[1][1],"compile-run"))
for name in ("ops-profile.py","collect.py","run.sh","retrieve.py","launch.py"):
    data=(template/name).read_text(encoding="utf-8").replace(old["root"],root).replace(old["unit"],unit).replace("B1370","B1399")
    if name == "ops-profile.py":
        first, end = data.index("    for name, case_id, lane in "), data.index("\n        role = ")
        data = data[:first] + f"    for name, case_id, lane in {jobs!r}:" + data[end:]
        data = data.replace('else 512','else 64')
        data = data.replace(
            '            record["identity"] = frame()',
            '            record["identity"] = frame()\n'
            '            assert record["identity"]["catalogSha256"] == expected_image["catalogSHA256"]')
        data = data.replace(
            '            if operation != "quit":',
            '            if operation != "quit":\n'
            '                assert response["completedInvocations"] == count, response')
    elif name == "collect.py":
        data = data.replace("['reference-mixed', 'candidate-function-helper', 'candidate-mixed']",repr([name for name, _, _ in jobs]))
        data = data.replace("len(records)==3", "len(records)==3").replace(old["identity"]["purpose"],identity["purpose"])
    elif name == "launch.py":
        data = data.replace("seconds=95","seconds=102").replace("95 seconds","102 seconds")
        data = data.replace("Mixed first-use and function-helper attribution","Current postponed factory and word-count CPU attribution")
    write(lab/name,data)
assert b"\r" not in (lab/"run.sh").read_bytes()

parts = ("identity.json","catalog.json","collect.py","ops-profile.py","run.sh")
payload = lab/"payload.tgz"
with tarfile.open(payload, "w:gz") as a:
    for name in parts:
        a.add(lab/name, arcname=name)
unpacked = sum((lab/name).stat().st_size for name in parts)
threshold = 176160768 + unpacked + 1152 * 1024
available = {}
for path in (repo/"benchmarks/results").glob("*/observations.tgz"):
    if path.stat().st_size < 100000:
        continue
    try:
        info = load(path.parent/"archive-receipt.json")
    except FileNotFoundError:
        continue
    if not all(info.get(k) for k in ("complete","allWorkersJoined","archivedAndVerifiedUnderLease")):
        continue
    available.setdefault(path.stat().st_size, []).append(
        (info["archiveSHA256"],path.relative_to(repo).as_posix()))
inventory = json.loads(subprocess.check_output(ssh+["python3 -"], input=f"""
from pathlib import Path
import fcntl, hashlib, os, shutil, stat, json
root = Path({base!r})
known = {available!r}
with (root/'comparison-vm.lock').open('a') as lease:
 fcntl.flock(lease, fcntl.LOCK_EX | fcntl.LOCK_NB)
 assert not any(p.is_mount() for p in root.glob('*/guest-fixtures'))
 matches = []
 for p in root.glob('*/observations.tgz'):
  if p.parent.name=="uniform-eager-annotation-b1398-20261122":continue
  meta = p.lstat()
  if meta.st_size not in known or p.resolve()!=p or meta.st_nlink!=1 or not stat.S_ISREG(meta.st_mode) or meta.st_uid!=os.getuid():continue
  digest=hashlib.sha256(p.read_bytes()).hexdigest()
  for expected,canonical in known[meta.st_size]:
   if expected==digest:matches.append((meta.st_size,str(p.relative_to(root)),digest,canonical))
 print(json.dumps(dict(free=shutil.disk_usage(root).free,matches=matches)))
""".encode(), timeout=33))
save(lab/"inventory.json",inventory)
free = inventory["free"]
retire = []
for size,path,digest,canonical in sorted(inventory["matches"], reverse=True):
    if free > threshold:
        break
    published = Path(canonical)
    info = json.loads(pushed(published.parent/"archive-receipt.json"))
    assert all(info[k] for k in ("complete","allWorkersJoined","archivedAndVerifiedUnderLease"))
    assert digest == info["archiveSHA256"] == sha(pushed(published))
    retire.append(dict(paths=[path],archives={},links=1,bytes=size,sha256=digest))
    free += size
if free <= threshold:
    # The prior exact image remains in the published archive. Only its idle
    # working copies may be retired, with every inode alias checked twice.
    old="2026-11-22-retained-source-cpython"
    previous_root=Path("benchmarks/results")/old
    binary=gzip.decompress(pushed(previous_root/"candidate-core.dll.gz"))
    signature=sha(binary)
    old_id=json.loads(pushed(previous_root/"source.json"))
    assert signature==old_id["imageFiles"]["candidate"]["Lokad.Lython.dll"]
    roots={
        "retained-source-cpython-b1397-20261122":old,
        "uniform-eager-annotation-b1398-20261122":"2026-11-22-repeated-eager-annotations",
    }
    raw={}
    for owner,canonical in roots.items():
        path=Path("benchmarks/results")/canonical
        witness=json.loads(pushed(path/"archive-receipt.json"))
        assert all(witness[k] for k in ("complete","allWorkersJoined","archivedAndVerifiedUnderLease"))
        raw[owner+"/observations.tgz"]=sha(pushed(path/"observations.tgz"))
        assert raw[owner+"/observations.tgz"]==witness["archiveSHA256"]
    paths=["retained-source-cpython-b1397-20261122/candidate/Lokad.Lython.dll",
           "uniform-eager-annotation-b1398-20261122/reference/Lokad.Lython.dll"]
    retire=[dict(paths=paths,archives=raw,links=len(paths),bytes=len(binary),sha256=signature)]
    free=inventory["free"]+len(binary)

assert free > threshold, (inventory,threshold)
stage = dict(root=root, unit=unit, identity=identity, source=donor_cfg["root"], sourceFiles={"candidate":files},
             catalogSHA256=catalog_sha, donorArchive=receipt["archiveSHA256"], retireGroups=retire, payloadBytes=payload.stat().st_size,
             payloadSHA256=sha(payload.read_bytes()), unpackedBytes=unpacked)
save(lab/"config.json",stage)
data=(template/"remote-launch.py").read_text(encoding="utf-8").replace("lython-b1370-fixtures","lython-b1399-fixtures")
first,end=data.index("\nc=")+1,data.index("\nb=Path(")
data=data[:first]+"c="+repr(stage)+data[end:]
old_check=" assert sha(source/'representative.json')==c['sourceCatalogSHA256']\n"
if old_check in data:
    data = data.replace(old_check, "")
assert " for role in ['candidate','reference']:" in data
data=data.replace(" for role in ['candidate','reference']:"," for role in ['candidate']:")
data=data.replace(" os.link(source/'representative.json',root/'catalog.json')\n","")
assert " os.link(source/" not in data
data=data.replace("176160768+c['unpackedBytes']+4*1024*1024","176160768+c['unpackedBytes']+1152*1024")
data=data.replace("RuntimeMaxSec=125","RuntimeMaxSec=160").replace("RuntimeMaxSec=140","RuntimeMaxSec=160")
write(lab/"remote-launch.py",data)
print("Verified complete frozen image, two catalog goldens and reserved diagnostic staging space.")
