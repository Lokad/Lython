from pathlib import Path
from collections import Counter
import bisect
import gzip
import json
import re

lab = Path(__file__).resolve().parent
header = re.compile(r"^.*?\s(\d+)\s+\d+\.\d+:\s+\d+\s+cpu-clock:")
frame = re.compile(r"^\s+([0-9a-f]+)\s+(.*)$")
module = re.compile(r"\s+\([^()]*\)$")

def classify(name):
    if re.search(r"Csv(?:Record|Reader|DictReader|Writer|DictWriter)", name):
        return "CSV parser, rows and writers"
    if any(word in name for word in ("TextFileHandle", "TextLineScanning", "TextLineReader", "StreamingTextReader")):
        return "Text windows, decoder and file operations"
    if any(word in name for word in ("ApplyDefinition", "CreateInlineDefinition", "CreateFunctionValue",
                                     "CreateLexicalFunctionValue", "StartExecutableDefaults", "CaptureExecutableCells",
                                     "SetPrivateDefault", "ChargeClosureRetention")):
        return "Callable construction"
    if any(word in name for word in ("TryExecuteDictionaryLoop", "TryAccumulate", "CasedWhitespaceIteration")):
        return "Prepared word iteration and accumulation"
    if any(word in name for word in ("PyString", "GovernedByteBuilder", "PythonWhitespace", "Unicode")):
        return "UTF-8 strings and builders"
    if any(word in name for word in ("MemoryGovernor", "MemoryScope", "MemoryReservation", "MemoryBudget")):
        return "Memory ownership"
    if any(word in name for word in ("ExecuteInstructionPrefix","ExecutableSlot","LythonExecutable")):
        return "Interpreter dispatch and slots"
    if any(word in name for word in ("ExecuteOrdinaryCall","TryExecuteNativeCall","NativeCall","DirectIntegerReturn","TryInvoke","InvokeCallable")):
        return "Calls"
    if any(word in name for word in ("ParseFloat","ParseInt","ParseNativeNumber","Numeric")):
        return "Numeric conversion and builtins"
    if any(word in name for word in ("PyDict","PyList","PyTuple")):
        return "Collections"
    return "Other method"

def summarize(folder):
    record = json.loads((folder/"record.json").read_text(encoding="utf-8"))
    assert record["exitCode"] == 0 and record["closed"]["status"] == "Closed"
    assert record["verificationBefore"]["status"] == record["verificationAfter"]["status"] == "Equivalent"
    entries = set()
    with gzip.open(folder/"perf.map.gz","rt",encoding="utf-8") as rows:
        for line in rows:
            a, size, name = line.rstrip().split(" ", 2)
            start, count = int(a,16), int(size,16)
            entries.add((start,start+count,name.split("(",1)[0]))
    entries = sorted(entries)
    starts = [row[0] for row in entries]
    max_end = []
    for _, end, _ in entries:
        max_end.append(max(max_end[-1],end) if max_end else end)

    def resolve(address, fallback):
        index = bisect.bisect_right(starts,address) - 1
        names = set()
        while index >= 0 and max_end[index] > address:
            start,end,name = entries[index]
            if start <= address < end:
                names.add(name)
            index -= 1
        if len(names) == 1:
            return next(iter(names))
        if names:
            return "[ambiguous JIT map]"
        return module.sub("",fallback).split("(",1)[0]

    samples = []
    with gzip.open(folder/"all-thread-stacks.txt.gz","rt",encoding="utf-8") as rows:
        for line in rows:
            if header.match(line):
                samples.append([])
                continue
            m = frame.match(line)
            if samples and m:
                samples[-1].append(resolve(int(m[1],16),m[2]))
    assert len(samples) > 500 and all(samples)
    leaves = Counter(stack[0] for stack in samples)
    nearest = Counter()
    nearest_domain = Counter()
    inclusive = Counter()
    reserve_callers = Counter()
    Lython = ("Lokad.Lython.Runtime.","Lokad.Lython.Memory.","Lokad.Lython.Frontend.","LythonEngine.")
    for stack in samples:
        name = next((name for name in stack if any(prefix in name for prefix in Lython)), "[no Lython frame]")
        nearest[name] += 1
        nearest_domain[classify(name) if name != "[no Lython frame]" else name] += 1
        inclusive.update({name for name in stack if any(prefix in name for prefix in Lython)})
        reserve = next((i for i, method in enumerate(stack) if "MemoryGovernor::Reserve" in method), None)
        if reserve is not None:
            caller = next((method for method in stack[reserve+1:]
                           if "Lokad.Lython." in method
                           and not any(owner in method for owner in ("MemoryGovernor", "TemporaryMemoryReservation"))),
                          "[no resolved caller]")
            reserve_callers[caller] += 1

    response = record["response"]
    return dict(label=folder.name,workload=record["workload"],samples=len(samples),batches=len(record["batches"]),
                invocations=response["completedInvocations"],workerThreads=record["threadCpuSeconds"],
                guestElapsedSeconds=response["elapsedTicks"]/response["clockFrequency"],
                nearestDomain=nearest_domain.most_common(),nearestRuntime=nearest.most_common(35),
                inclusiveRuntime=inclusive.most_common(35),reserveCallers=reserve_callers.most_common(),leaf=leaves.most_common(25))

results = [summarize(lab/"retrieved/profiles"/("candidate-"+name))
           for name in ("text-summary","postponed","postponed-fresh")]
for row in results:
    print(row["label"],row["samples"],row["batches"],row["reserveCallers"])
    for name, count in row["nearestRuntime"][:17]:
        print(f"   {count:4d}",name)
report = dict(rows=results,scope="One process per case and boundary with perf overrides. Attribution only. Inclusive attribution overlaps.",performanceQualified=False)
(lab/"attribution.json").write_text(json.dumps(report,indent=2)+"\n",encoding="utf-8",newline="\n")
