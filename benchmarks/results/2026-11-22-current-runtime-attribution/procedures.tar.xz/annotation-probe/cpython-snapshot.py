Alias = {"old": True}
def factory():
    def f(first: Alias, second: Alias) -> Alias:
        return first
    return f
a = factory()
original = Alias
Alias = {"new": True}
b = factory()
old_dict = a.__annotations__
print(list(old_dict), all(v is original for v in old_dict.values()))
print(all(v is Alias for v in b.__annotations__.values()))
a.__annotations__ = {}
print(len(old_dict), len(a.__annotations__))
del Alias
try:
    factory()
except NameError as error:
    print(type(error).__name__, "Alias" in str(error))
