from pathlib import Path
from statistics import median
import base64
import hashlib
import json
import os
import shutil
import subprocess

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
prior = lab.with_name('deferred-site-placement-20261126')
history = lab.with_name('exact-utf8-copy-20261126')
local = lab / 'local'
core = 'Lokad.Lython.dll'
candidate = lab / 'windows/bin/Lokad.Lython/release_net11.0' / core
read = lambda path: json.loads(path.read_text(encoding='utf-8-sig'))
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
manifest = lambda path: {p.name: sha(p) for p in path.iterdir()}

def save(path, value):
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False)+'\n', encoding='utf-8', newline='\n')

head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repo, text=True).strip()
assert head == 'e74c6ceaa80bf3a08de581147eb481af9479f748'
previous = read(prior / 'comparison/quiet/identity.json')
reference = prior / 'local/candidate'
assert previous['imageFiles']['candidate'] == manifest(reference) and len(manifest(reference)) == 32
previous_patch = subprocess.check_output(['git','diff','--binary',previous['sourceRevision'],head,'--','src'],cwd=repo)
assert hashlib.sha256(previous_patch).hexdigest() == previous['sourcePatchSHA256']
patch = subprocess.check_output(['git', 'diff', '--binary', head, '--', 'src'], cwd=repo)
assert patch.count(b'diff --git ') == 1 and b'Json.Deserialize.cs' in patch and b'FromAsciiCharacter' in patch
(lab/'candidate.patch').write_bytes(patch)
(lab/'regression.patch').write_bytes(subprocess.check_output(['git','diff','--binary',head,'--','tests'],cwd=repo))

local.mkdir()
images = {}
for role in ('reference', 'candidate'):
    folder = local / role
    shutil.copytree(reference, folder)
    if role == 'candidate':
        shutil.copyfile(candidate, folder / core)
    images[role] = manifest(folder)
assert [name for name,digest in images['reference'].items() if images['candidate'][name]!=digest] == [core]
for name in ('cpython-worker.py','run.sh'):
    shutil.copyfile(prior / 'local' / name, local / name)
assert sha(local / 'cpython-worker.py') == previous['cpythonWorkerSHA256']
assert b'\r' not in (local / 'run.sh').read_bytes()
document = 'diagnostic.json-service-quantity-totals'
lines = 'scripts.json-summary-helpers.large'
unicode = 'diagnostic.text-summary.nonlocal-computed-width.large'
escaped = 'diagnostic.report-render.escaped-unicode.large'
catalog = read(history / 'local/representative.json')
catalog['cases'] = [case for case in catalog['cases'] if case['id'] in (document, lines, unicode)]
old = read(lab.with_name('json-string-single-validation') / 'catalog.json')
catalog['cases'].append(next(case for case in old['cases'] if case['id']==escaped))
assert {c['id'] for c in catalog['cases']} == {document,lines,unicode,escaped}
source = next(c for c in catalog['cases'] if c['id']==document)
fixture = json.loads(source['fixtureJson'])
records = json.loads(base64.b64decode(fixture['inputFiles']['shipments.json']))
single_byte_values = sum(len(value)==1 and value.isascii() for row in records for value in row.values())
assert len(records)==2048 and single_byte_values==802
save(local/'representative.json',catalog)
save(local/'jobs.json', {'warm': [[document,'warm'],[unicode,'warm'],[lines,'warm-async'],
                                 [escaped,'warm'],[document,'warm-async']]})
identity = dict(sourceRevision=head, sourcePatchSHA256=sha(lab/'candidate.patch'), imageFiles=images,
    coreSHA256={role+label:files[core] for role,files in images.items() for label in ('','-control')},
    cpythonWorkerSHA256=previous['cpythonWorkerSHA256'],expectedCPythonSHA256=previous['expectedCPythonSHA256'],
    catalogs={name:{'sha256':sha(local/name)} for name in ('representative.json','jobs.json')},
    purpose='Reuse existing immutable ASCII values after ordinary JSON string validation.')
save(local/'identity.json',identity)
collector=(history/'local/collect.py').read_text(encoding='utf-8')
assert collector.count('lython-exact-utf8-copy-fixture-')==1
collector=collector.replace('lython-exact-utf8-copy-fixture-','lython-json-ascii-character-fixture-')
compile(collector,'collect.py','exec')
(local/'collect.py').write_text(collector,encoding='utf-8',newline='\n')

sdk = Path.home()/'.dotnet11'
dotnet = sdk/'dotnet.exe'
env = dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk))
allocation_tool=lab.with_name('json-traversal-20261124')/'reference'
allocations={}
for role,files in images.items():
    image=local/role
    verification=lab/(role+'-verify.json')
    subprocess.run([dotnet,image/'Lokad.Lython.Benchmarks.dll','--compare','verify','--catalog',
        local/'representative.json','--dotnet',dotnet,'--python','C:/Python313/python.exe',
        '--python-worker',local/'cpython-worker.py','--out',verification],cwd=repo,env=env,check=True,timeout=100)
    proof=read(verification)
    assert proof['state']=='Completed' and proof['caseCount']==4
    assert proof['catalogSha256']==identity['catalogs']['representative.json']['sha256']
    assert proof['launched']['library']['sha256']==files[core]
    allocated=lab/(role+'-allocated')
    shutil.copytree(image,allocated)
    for file in allocation_tool.glob('ValidatedAllocation*'):
        shutil.copyfile(file,allocated/file.name)
    output=lab/(role+'-allocation.json')
    subprocess.run([dotnet,allocated/'ValidatedAllocation.dll',allocated,local/'representative.json',output],
                   cwd=repo,env=env,check=True,timeout=102)
    allocations[role]=read(output)['rows']
rows=[]
for before,after in zip(allocations['reference'],allocations['candidate'],strict=True):
    assert before['id']==after['id'] and before['sharedBudgetBaselineRestored'] and after['sharedBudgetBaselineRestored']
    rows.append(dict(case=before['id'],allocatedBytes=[median(row['allocatedBytesPerInvocation']) for row in (before,after)],
                      peak=[row['peakExecutionMemoryBytes'] for row in (before,after)],
                      admittedCompilerBytes=[row['compiledReservedBytes'] for row in (before,after)]))
save(lab/'allocation-summary.json',dict(documentSingleByteValues=single_byte_values,rows=rows))
print(json.dumps(rows))
