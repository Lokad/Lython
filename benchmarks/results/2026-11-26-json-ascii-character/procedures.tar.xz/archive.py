from pathlib import Path
import hashlib
import json
import shutil
import subprocess
import tarfile

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
local=lab/'local'
first=lab/'comparison/quiet'
quiet=lab/'comparison/repeat'
target=repo/'benchmarks/results/2026-11-26-json-ascii-character'
read=lambda path:json.loads(path.read_text(encoding='utf-8-sig'))
sha=lambda path:hashlib.sha256(path.read_bytes()).hexdigest()
identity,summary,status=(read(quiet/name) for name in ('identity.json','summary.json','terminal-status.json'))
original=read(local/'identity.json')
assert original==read(first/'identity.json')
assert identity.keys()==original.keys()
assert all(value==identity[key] for key,value in original.items() if key!='catalogs')
assert identity['catalogs']['representative.json']==original['catalogs']['representative.json']
failed=read(first/'terminal-status.json')
failed_receipt=failed['receipt']
assert failed['exitCode']=='1' and not failed['fixtures'] and not failed['live']
assert not failed_receipt['complete'] and 'No space left on device' in failed['journal']
assert failed_receipt['archiveSHA256']==sha(first/'observations.tar.xz')
with tarfile.open(first/'observations.tar.xz') as archive:
    partial=json.load(archive.extractfile('confirmation/confirmation.json'))
assert len(partial['jobs'])==1 and len(partial['jobs'][0]['samples'])==28
receipt=status['receipt']
assert status['exitCode']=='0' and not status['fixtures'] and not status['live']
assert all(receipt[key] for key in ('complete','quietBeforeAndAfter','allWorkersJoined','guestFixturesRemoved',
                                   'archivedAndVerifiedUnderLease'))
assert receipt['archiveSHA256']==sha(quiet/'observations.tar.xz') and receipt['warmJobs']==4
assert summary['timedBatches']==112 and identity['sourcePatchSHA256']==summary['sourcePatchSHA256']==sha(lab/'candidate.patch')
for role,path in [('reference',lab/'reference-verify.json'),('candidate',lab/'candidate-verify.json'),
                  ('candidate',first/'remote-verify.json')]:
    proof=read(path)
    assert proof['state']=='Completed' and proof['caseCount']==4
    assert proof['catalogSha256']==identity['catalogs']['representative.json']['sha256']
    assert proof['launched']['library']['sha256']==identity['coreSHA256'][role]
for folder,name in [('src','candidate.patch'),('tests','regression.patch')]:
    patch=subprocess.check_output(['git','diff','--binary',identity['sourceRevision'],'--',folder],cwd=repo)
    assert patch==(lab/name).read_bytes()
allocation=read(lab/'allocation-summary.json')
assert allocation['documentSingleByteValues']==802
doc=allocation['rows'][0]
assert doc['case']=='diagnostic.json-service-quantity-totals'
assert doc['allocatedBytes'][0]-doc['allocatedBytes'][1]==44912
assert doc['peak'][0]-doc['peak'][1]==802*129
assert all(row['peak'][0]==row['peak'][1] for row in allocation['rows'][1:])

target.mkdir(exist_ok=True)
for name in ('identity.json','summary.json','observations.tar.xz','terminal-status.json'):
    shutil.copyfile(quiet/name,target/name)
for name in ('candidate.patch','allocation-summary.json'):
    shutil.copyfile(lab/name,target/name)
original_attempt=target/'initial'
original_attempt.mkdir(exist_ok=True)
for name in ('identity.json','observations.tar.xz','terminal-status.json'):
    shutil.copyfile(first/name,original_attempt/name)
with tarfile.open(target/'procedures.tar.xz','w:xz') as archive:
    for name in ('prepare.py','prepare.log','prepare-quiet.py','quiet.py','preserve-cores.py',
                 'summarize-quiet.py','archive.py','launch-console.log','retrieve-quiet.log',
                 'reference-verify.json','candidate-verify.json','reference-allocation.json','candidate-allocation.json',
                 'check-cpython.py','check-cpython.log','regression.patch','test-windows.ps1','test-ubuntu.sh',
                 'compact-for-retry.py','preserve-retry-core.py','repeat.py','summarize-repeat.py','repeat-launch.log',
                 'recheck-ubuntu.sh','recheck-win11.log','recheck-ubuntu10.log'):
        archive.add(lab/name,arcname=name)
    for path in sorted(lab.glob('Lokad.Lython.*.log')):
        archive.add(path,arcname=path.name)
    for name in ('duplicate-core-preview.json','duplicate-core-reclaim.json','upload.json',
                 'launch.log','remote-verify.json','observe-not-before','storage-preview-18mb.log',
                 'storage-preview.log','storage-compact.log','retry-core-preview.json','retry-core-reclaim.json'):
        archive.add(first/name,arcname='original/'+name)
    for path in sorted(quiet.glob('*.log')):
        archive.add(path,arcname='repeat/'+path.name)
print('Archived exact source, allocation evidence, goldens and quiet comparison')
