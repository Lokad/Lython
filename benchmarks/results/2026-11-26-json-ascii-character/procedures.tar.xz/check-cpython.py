from pathlib import Path
from textwrap import dedent, indent
import sys
p=Path('tests/Lokad.Lython.PublicApi.Tests/JsonStringTokenBoundaryTests.cs')
source=p.read_text(encoding='utf-8').split('JsonSingleAsciiCharacterReusesTheSameValue',1)[1].split('"""')[1]
scope={}
exec('def check():\n'+indent(dedent(source).strip(),'    '),scope)
assert scope['check']()==['a','\n','\0']
print(sys.version)
print('CPython independently matches identity, contents and end position')
