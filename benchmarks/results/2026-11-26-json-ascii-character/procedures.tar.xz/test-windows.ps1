$ErrorActionPreference='Stop'
$lab='.git/agent-notes/review-20261031/json-ascii-character-20261126'
$env:DOTNET_ROOT=Join-Path $env:USERPROFILE '.dotnet11'
$dotnet=Join-Path $env:DOTNET_ROOT 'dotnet.exe'
$filter='Category!=Stress&(FullyQualifiedName~Json|FullyQualifiedName~GovernedMemoryContract|FullyQualifiedName~SharedTextStorage)'
foreach ($suite in 'Lokad.Lython.Tests','Lokad.Lython.PublicApi.Tests') {
    $log=Join-Path $lab "$suite-win11.log"
    & $dotnet test "tests/$suite/$suite.csproj" -c Release -f net11.0 --artifacts-path "$lab/windows" --filter $filter *> $log
    if ($LASTEXITCODE -ne 0) { Get-Content $log -Tail 60 -Encoding utf8; exit 1 }
    Get-Content $log -Tail 6 -Encoding utf8
}
