set -eu
export DOTNET_ROOT="$HOME/.dotnet"
export PATH="$DOTNET_ROOT:$PATH"
lab="$PWD/.git/agent-notes/review-20261031/json-ascii-character-20261126"
suite=Lokad.Lython.PublicApi.Tests
filter='FullyQualifiedName~JsonStringTokenBoundaryTests|FullyQualifiedName~OriginalSubclassConstructionScale'
dotnet test "tests/$suite/$suite.csproj" -c Release -f net10.0 --artifacts-path "$lab/ubuntu" --filter "$filter"