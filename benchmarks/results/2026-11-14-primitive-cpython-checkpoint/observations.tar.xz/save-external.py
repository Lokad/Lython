from pathlib import Path
import hashlib,json,shutil,tarfile
r=Path(__file__).parent;run=r/'b736';out=Path('benchmarks/results/2026-11-14-primitive-cpython-checkpoint');out.mkdir();status=json.loads((run/'terminal-status.json').read_text(encoding='utf-8'));summary=json.loads((run/'summary.json').read_text(encoding='utf-8'));assert status['receipt']['complete']and summary['complete']and summary['jobs']==9 and not status['remainingWorkers']and not status['remainingFixtures']and not status['remainingTrace'];assert hashlib.sha256((run/'observations.tgz').read_bytes()).hexdigest()==status['receipt']['archiveSHA256']
guide=Path('docs/BENCHMARKS.md');shutil.copyfile(guide,out/'prior-BENCHMARKS.md')
for name in ['identity.json','summary.json','terminal-status.json','archive-receipt.json','prospective.json']:shutil.copyfile(run/name,out/name)
shutil.copyfile(r/'complete/delivery/source-proof.json',out/'measured-source-proof.json')
with tarfile.open(out/'observations.tar.xz','w:xz')as t:
 for p in sorted(run.rglob('*')):
  if p.is_file():t.add(p,arcname=p.relative_to(run).as_posix())
 t.add(Path(__file__),arcname='save-external.py')
rows={(v['case'],v['lane']):v for v in summary['timing']}
ids={'CSV invoice / pricing helpers':'scripts.csv-invoice.large','Text / captured helper and counter':'scripts.text-summary-helpers.nonlocal-counter.large','JSON-lines / aggregation helpers':'scripts.json-summary-helpers.large','File search / keyword-default helper':'scripts.file-search.large','JSON-to-Markdown report':'scripts.report-render.large','CSV fulfillment / pricing and validation':'scripts.csv-fulfillment.large','CSV validation / for-loop checksum':'scripts.csv-check-digits.for-text.large'}
def elapsed(row,prefix):
 a,b=sorted(v for n,v in row['medianMilliseconds'].items() if n.startswith(prefix))
 unit='µs' if b<1 else 'ms'
 factor=1000 if b<1 else 1
 return f'{a*factor:.3f}–{b*factor:.3f} {unit}'
def cells(row,label):
 low,high=min(row['ratioRange']),max(row['ratioRange']);return [elapsed(row,'candidate'),elapsed(row,'CPython'),f'{low:.2f}–{high:.2f}×',f'{label}; spreads{row["lythonControlPercent"]:.2f}/{row["cpythonControlPercent"]:.2f}%; maxIQR{row["maxIqrPercent"]:.2f}%']
lines=[]
for line in guide.read_text(encoding='utf-8').splitlines():
 if line.startswith('|'):
  parts=[s.strip()for s in line.strip('|').split('|')];name=parts[0]
  if name in ids:parts=parts[:2]+cells(rows[ids[name],'warm'],'Variable'if name in ['JSON-lines / aggregation helpers','JSON-to-Markdown report']else'Diagnostic');line='| '+'|'.join(parts)+'|'
  elif name in ['Invoice compilation alone','Invoice compile and execute once']:
   lane='compile'if name=='Invoice compilation alone'else'compile-run';parts=[name]+cells(rows['scripts.csv-invoice.large',lane],'Diagnostic');line='| '+'|'.join(parts)+'|'
 lines.append(line)
s='\n'.join(lines)+'\n';start=s.index('First seven rows measured');end=s.index('The96 B configuration row',start)
s=s[:start]+'''First seven rows measured 2026-11-14 UTC: **98acaa5b / frozen a4bfbfd8**,
against stock **CPython 3.13.16**. Full Windows/Ubuntu actual .NET 11/10,
original stress and installed-package qualification is
[running at this exact source](https://github.com/Lokad/Lython/actions/runs/43605198037).
[Exact sources, raw/wider CPU and controls](../benchmarks/results/2026-11-14-primitive-cpython-checkpoint/README.md).
JSON's Lython process spread is 4.04%; report maximum IQR is 4.13%. Keep both
variable cases visible. The [previous qualified snapshot](../benchmarks/results/2026-11-14-literal-cpython-checkpoint/README.md)
and [previous guide](../benchmarks/results/2026-11-14-primitive-cpython-checkpoint/prior-BENCHMARKS.md)
retain their exact source, evidence and adverse conditions. Cross-collection
differences do not attribute individual changes.
'''+s[end:]
guide.write_text(s,encoding='utf-8',newline='\n')
(out/'README.md').write_text('''# Representative CPython checkpoint after native primitive storage

2026-11-14 UTC, committed `98acaa5b` / frozen `a4bfbfd8`, versus stock
CPython 3.13.16. [Full platform/stress/package qualification](https://github.com/Lokad/Lython/actions/runs/43605198037)
is pending independently. The [current guide](../../../docs/BENCHMARKS.md) leads
with the representative table; this artifact preserves the exact measured source.

Quiet Azure Standard F4as_v7, Ubuntu 24.04.4, four EPYC 9V45 vCPUs, 16 GiB/no
swap, .NET 11 RC3, ordinary GC/tiering and CPython GIL/GC. B736 completes all nine
jobs in 360.622 seconds with unchanged catalog, workers, toolchains and timing
boundaries. Four fresh processes/job, full-request warmups and five rotating
0.5-second batches. Every image, catalog, stdout/file golden, budget cleanup,
quiet endpoint, joined-user and archive gate passes. No workers or RAM fixtures
remain. Raw SHA256:
`755c49043e2bfe85b6b17c55cd65178a3e496a13f5302c81e7f90ee5aa127f51`.

Invoice warm 1.22–1.24× CPython; compile alone 1.09–1.10×; compile-to-result
1.22–1.23×. Captured text 1.48–1.49×, JSON 0.83–0.87× (variable), file search
1.64–1.68×, report 1.21–1.23× (variable), fulfillment 1.25–1.26×, maintained
for-loop CSV validation 1.29–1.32×. Ratio is Lython elapsed / CPython elapsed.
JSON's Lython process spread is 4.04%; report maximum IQR is 4.13%. These remain
uncertainty, not omitted cases or failed designs. No cross-collection attribution,
universal gain or claim the separate diagnostic CSVwhile speedup applies to the
different maintained algorithm. The broad performance objective remains open.

Warm elapsed includes mediated RAM-file I/O, complete stdout/file validation and
result cleanup; excludes compilation, startup, fixture reset/protocol and final
cache disposal. Compile-to-result adds compilation and compiled-owner disposal.
Wider process CPU includes reset/protocol. Ranges are process medians/all pairings,
not confidence intervals. Startup, real pending I/O, shared-budget contention,
RSS/heap peaks and embedding tail latency remain unmeasured.

All 582 frozen input files match the measured commit with explicit newline
normalization; this does not infer independently rebuilt binary byte identity.
Exact [runtime sources/binary](../2026-11-14-native-primitive-storage/refined/sources-checks-and-observations.tar.xz)
and [source proof](measured-source-proof.json) are preserved. Only one duplicate
completed old B435 raw archive was retired after exact committed canonical-byte,
path/kind/UID/link proof under a fresh idle lease. All current images, catalogs,
toolchains and 254/252 MiB floors remain; no new core/catalog upload or rerun.

[All medians/controls](summary.json), [identity](identity.json),
[terminal status](terminal-status.json), [prospective plan](prospective.json),
[all tools/receipts/raw](observations.tar.xz), [prior guide](prior-BENCHMARKS.md).
Publication/tagging and final adapter qualification remain separate and postponed.
''',encoding='utf-8',newline='\n')
p=Path('benchmarks/EXPERIMENTS.md');p.write_text(p.read_text(encoding='utf-8')+'''
## R359 external checkpoint — exact committed source

[B736](results/2026-11-14-primitive-cpython-checkpoint/README.md) at `98acaa5b` /
frozen `a4bfbfd8` completes nine jobs in 360.622 s/all gates against CPython 3.13.16.
Invoice warm 1.22–1.24×, compile 1.09–1.10×, fresh 1.22–1.23×; captured text
1.48–1.49×, JSON 0.83–0.87× (4.04% Lython spread), search 1.64–1.68×, report
1.21–1.23× (max IQR4.13%), fulfillment 1.25–1.26× and maintained for-CSV
1.29–1.32×. Boundaries/controls unchanged; no cross-collection attribution or
extrapolation from the different diagnostic CSVwhile algorithm. Full43605198037
is pending independently. Old guide and all raw/adverse evidence preserved;
publication held, ordinary-frame transport source gate and wider roadmap active.
''',encoding='utf-8',newline='\n')
p=Path('PLAN.md');s=p.read_text(encoding='utf-8');start=s.index('| Latest external checkpoint |');end=s.index('\n',start);s=s[:start]+'''| Latest external checkpoint | B736 at `98acaa5b` / frozen `a4bfbfd8`, stock CPython 3.13.16, all nine jobs/360.622 s/all gates. Invoice warm 1.22–1.24×, compile 1.09–1.10×, fresh 1.22–1.23×; text 1.48–1.49×, JSON 0.83–0.87× (variable), search 1.64–1.68×, report 1.21–1.23× (variable), fulfillment 1.25–1.26×, maintained for-CSV 1.29–1.32×. [Guide](docs/BENCHMARKS.md) separates clocks/I/O/cleanup and source qualification, which remains pending. Previous guide/raw/adverse evidence preserved; no cross-collection attribution. |'''+s[end:]
start=s.index('   B736 is active');end=s.index('\n\n   Continue the substantial roadmap',start);s=s[:start]+'''   B736 completes all nine jobs/360.622 seconds with all gates at exact `98acaa5b`.
   Current guide and immutable evidence are refreshed; no workers/fixtures remain.
   JSON/report uncertainty and all original data stay visible. Full delivery
   runs independently. Do not requery B736 or repeat unchanged measurements.
   Next: the bounded R360 ordinary-frame primitive-transport source gate, sharing
   existing owners/publication/direct spans, with captured/mirrored/async boundaries
   inspected before implementation. Findings are recorded privately; no code yet.'''+s[end:];p.write_text(s,encoding='utf-8',newline='\n')
print('B736exact-source external guide refreshed; all raw/controls and prior guide preserved, fullCIindependent.',flush=True)
