from pathlib import Path
import ast
import hashlib
import json
import os
import shutil
import subprocess
import tarfile

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
quiet=lab/"comparison/quiet"
quiet.mkdir(parents=True)
prior=lab.with_name("record-field-cpython-20261126-retry")
template=prior/"comparison/quiet"
comparison=lab.with_name("converted-dictionary-update-20261126")
donor=comparison/"comparison/quiet"
read=lambda p:json.loads(p.read_text(encoding="utf-8"))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
write=lambda p,t:p.write_text(t,encoding="utf-8",newline="\n")
save=lambda p,v:write(p,json.dumps(v,indent=2,ensure_ascii=False)+"\n")

head=subprocess.check_output(["git","rev-parse","HEAD"],cwd=repo).decode().strip()
assert not subprocess.check_output(["git","status","--porcelain","--","src"],cwd=repo)
patch=comparison/"candidate.patch"
names={line[6:] for line in patch.read_text(encoding="utf-8").splitlines() if line.startswith("+++ b/")}
changed=subprocess.check_output(["git","diff","--name-only","26841dca3",head,"--","src"],cwd=repo).decode().splitlines()
assert len(names)==6 and set(changed)==names
assert all((repo/name).read_text(encoding="utf-8")==
           (comparison/"candidate-source"/name).read_text(encoding="utf-8") for name in names)
previous=read(donor/"identity.json")
receipt=read(donor/"terminal-status.json")["receipt"]
assert receipt["complete"] and receipt["allWorkersJoined"] and receipt["guestFixturesRemoved"]
assert sha(donor/"observations.tar.xz")==receipt["archiveSHA256"] and sha(patch)==previous["sourcePatchSHA256"]
image=comparison/"frozen/candidate"
files=previous["imageFiles"]["candidate"]
assert len(files)==32 and {p.name:sha(p) for p in image.iterdir()}==files
catalog=read(donor/"representative.json")
shipment="diagnostic.shipment-routing-callbacks"
quantity="diagnostic.json-service-quantity-totals"
catalog["cases"]=[case for case in catalog["cases"] if case["id"] in {shipment,quantity}]
assert len(catalog["cases"])==2
save(quiet/"representative.json",catalog)
save(quiet/"jobs.json",[[shipment,"warm-async"],[quantity,"warm"],[shipment,"warm"],
                      [shipment,"compile"],[shipment,"compile-run"]])
worker=repo/"benchmarks/cpython-worker.py"
shutil.copyfile(worker,quiet/"cpython-worker.py")
assert sha(worker)==previous["cpythonWorkerSHA256"]
remote_root="converted-update-cpython-b1764-20261126"
identity=dict(sourceRevision=head,productionSource=head,candidate=head,
              frozenImage=f"/home/lokad/lython-bench-checks/{remote_root}/candidate",
              auxiliaryFiles={name:digest for name,digest in files.items() if name!="Lokad.Lython.dll"},
              imageFiles={"candidate":files},coreSHA256={role:files["Lokad.Lython.dll"] for role in ("candidate","candidate-control")},
              donorArchiveSHA256=receipt["archiveSHA256"],sourcePatchSHA256=previous["sourcePatchSHA256"],
              cpythonWorkerSHA256=previous["cpythonWorkerSHA256"],expectedCPythonSHA256=previous["expectedCPythonSHA256"],
              catalogs={name:{"sha256":sha(quiet/name)} for name in ("representative.json","jobs.json")},
              purpose="Compare the retained dictionary-update revision against CPython.")
save(quiet/"identity.json",identity)
for name in ("collect.py","summarize.py","run.sh"):
    src=(template/name).read_text(encoding="utf-8").replace("lython-b1760b-fixtures","lython-b1764-fixtures")
    src=src.replace("len(jobs) == 6","len(jobs) == 5")
    src=src.replace('len(raw["jobs"])==6','len(raw["jobs"])==5').replace('receipt["warmJobs"]==6','receipt["warmJobs"]==5')
    src=src.replace("Compare current CSV conversion and shipment workloads against CPython.",identity["purpose"])
    if name.endswith(".py"):
        tree=ast.parse(src)
        compile(tree,name,"exec")
        if name=="collect.py":
            keys={node.slice.value for node in ast.walk(tree) if isinstance(node,ast.Subscript) and isinstance(node.value,ast.Name)
                  and node.value.id=="identity" and isinstance(node.slice,ast.Constant)}
            assert keys<=identity.keys(),sorted(keys-identity.keys())
    write(quiet/name,src)
assert b"\r" not in (quiet/"run.sh").read_bytes()

sdk=Path.home()/".dotnet11"
dotnet=sdk/"dotnet.exe"
verify=quiet/"candidate-verify.json"
env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk))
subprocess.run([dotnet,image/"Lokad.Lython.Benchmarks.dll","--compare","verify","--catalog",quiet/"representative.json",
                "--dotnet",dotnet,"--python","C:/Python313/python.exe","--python-worker",worker,"--out",verify],
               cwd=repo,env=env,check=True,timeout=85)
proof=read(verify)
assert proof["state"]=="Completed" and proof["caseCount"]==2 and proof["catalogSha256"]==identity["catalogs"]["representative.json"]["sha256"]
assert proof["launched"]["library"]["sha256"]==files["Lokad.Lython.dll"]
payload=quiet/"stage.tar.gz"
with tarfile.open(payload,"w:gz",compresslevel=6) as package:
    for name in ("identity.json","jobs.json","representative.json","collect.py","run.sh","cpython-worker.py"):
        package.add(quiet/name,arcname=name,recursive=False)
save(quiet/"upload.json",dict(root=remote_root,payloadSHA256=sha(payload),payloadBytes=payload.stat().st_size))
body=(prior/"quiet.py").read_text(encoding="utf-8")
replacements={
    "lython-b1760b-record-field-cpython-20261126":"lython-b1764-converted-update-cpython-20261126",
    "base/'direct-record-helper-b1759-20261126'":"base/'converted-dictionary-update-b1763-20261126'",
    "RuntimeMaxSec=290":"RuntimeMaxSec=248",
    "seconds=235":"seconds=205",
}
for old,new in replacements.items():
    assert body.count(old)==1,old
    body=body.replace(old,new)
compile(body,"quiet.py","exec")
write(lab/"quiet.py",body)
