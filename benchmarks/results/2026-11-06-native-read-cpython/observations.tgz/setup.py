from pathlib import Path
import hashlib,json,os,shutil
root=Path('/home/lokad/lython-bench-checks/native-read-checkpoint-b338-20261106')
previous=Path('/home/lokad/lython-bench-checks/native-read-prefix-b336-20261106')
base=previous/'candidate'
for label in ['candidate','reference']:
    folder=root/label
    if label=='reference':folder.symlink_to(previous/'reference',target_is_directory=True);continue
    folder.mkdir()
    for file in base.iterdir():
        if file.name=='Lokad.Lython.dll':(folder/file.name).symlink_to(root/'core/Lokad.Lython.dll')
        else:(folder/file.name).symlink_to(file.resolve(),target_is_directory=file.is_dir())
identity=json.loads((root/'identity.json').read_text(encoding='utf-8'))
for label in ['candidate','control','reference']:
    folder=root/('candidate' if label=='control' else label)
    assert hashlib.sha256((folder/'Lokad.Lython.dll').read_bytes()).hexdigest()==identity['coreSHA256'][label]
    for name,digest in identity['auxiliaryFiles'].items():assert hashlib.sha256((folder/name).read_bytes()).hexdigest()==digest
assert shutil.disk_usage(root).free>24*1024*1024
print(json.dumps(dict(freeBytes=shutil.disk_usage(root).free,coreSHA256=identity['coreSHA256'])))
