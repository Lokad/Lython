def make():
    def label(value: int = 7) -> int:
        "café"
        return value
    return label
f, other = make(), make()
original = f.__annotations__
attrs = {"__name__": "shadow", "tag": []}
f.__dict__ = attrs
print(f.__name__, f.__qualname__, f.__module__, f.__doc__, f.tag is attrs['tag'])
print(original is f.__annotations__, f.__annotations__ is other.__annotations__)
f.__name__ = 'changed'
f.__qualname__ = "top.label"
f.__module__ = "tools"
f.__annotations__ = {'custom': attrs['tag']}
print(f.__name__, f.__qualname__, f.__module__, f.__annotations__['custom'] is f.tag)
del f.__doc__
del f.__module__
del f.__annotations__
print(f.__doc__, f.__module__, f.__annotations__, list(original), f(), other(), f.__dict__ is attrs)
def generic[T](value: T) -> T: return value
tokens = generic.__type_params__
print(generic.__type_params__ is tokens, generic.__annotations__['value'] is tokens[0])
