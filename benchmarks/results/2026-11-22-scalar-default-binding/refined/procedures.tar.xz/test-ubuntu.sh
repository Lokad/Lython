#!/bin/bash
set -euo pipefail
cd /mnt/d/code/Lython/.git/agent-worktrees/closed-default-scalar-bind-20261122
export DOTNET_ROOT="$HOME/.dotnet"
export PATH="$DOTNET_ROOT:$PATH"
export DOTNET_HOST_PATH="$DOTNET_ROOT/dotnet"
dir=/mnt/d/code/Lython/.git/agent-notes/review-20261031/closed-default-scalar-bind-confirmed-20261122
artifact="$dir/ubuntu"
filter='Category!=Stress&(FullyQualifiedName~FunctionDefault|FullyQualifiedName~FunctionBinding|FullyQualifiedName~NativeReturn|FullyQualifiedName~Unpack|FullyQualifiedName~NativeCall|FullyQualifiedName~CallTransfer|FullyQualifiedName~StackGuard|FullyQualifiedName~CooperativeCancellation)'
dotnet test tests/Lokad.Lython.Tests -c Release -f net10.0 --filter "$filter" --artifacts-path "$artifact" --nologo > "$dir/white-ubuntu.log" 2>&1 || { tail -55 "$dir/white-ubuntu.log"; exit 1; }
dotnet test tests/Lokad.Lython.PublicApi.Tests -c Release -f net10.0 --filter "$filter" --artifacts-path "$artifact" --nologo > "$dir/public-ubuntu.log" 2>&1 || { tail -55 "$dir/public-ubuntu.log"; exit 1; }
awk '/Passed!/{count++;print} END{exit count!=2}' "$dir/white-ubuntu.log" "$dir/public-ubuntu.log"
