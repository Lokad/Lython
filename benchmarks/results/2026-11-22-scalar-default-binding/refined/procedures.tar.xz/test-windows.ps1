param([string]$Worktree,[string]$Directory,[string]$PinnedDotnet,[string]$Filter)
Push-Location $Worktree
$env:DOTNET_ROOT=Split-Path $PinnedDotnet
$env:DOTNET_HOST_PATH=$PinnedDotnet
$env:Path="$env:DOTNET_ROOT;$env:Path"
foreach ($case in @(@('white','Lokad.Lython.Tests'),@('public','Lokad.Lython.PublicApi.Tests'))) {
    $log="$Directory/$($case[0])-windows.log"
    & $PinnedDotnet test "tests/$($case[1])" -c Release -f net11.0 --filter $Filter --artifacts-path "$Directory/windows" --nologo *> $log
    $code = $LASTEXITCODE
    Get-Content -Encoding utf8 $log | Select-Object -Last 14
    if ($code) { exit $code }
}
Pop-Location
