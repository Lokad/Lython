from pathlib import Path
import hashlib, json, os, subprocess

lab = Path(__file__).resolve().parent
comparison = lab / "comparison"
images = json.loads((comparison / "images.json").read_text(encoding="utf-8"))
sdk = Path.home() / ".dotnet11"
base = dict(os.environ, DOTNET_ROOT=str(sdk), DOTNET_ROOT_X64=str(sdk), PATH=str(sdk) + os.pathsep + os.environ["PATH"])
for mode in ["normal", "tierless"]:
    for role in ["reference", "candidate"]:
        image = comparison / ("frozen-" + role)
        assert {name: hashlib.sha256((image / name).read_bytes()).hexdigest()
                for name in images["imageFiles"][role]} == images["imageFiles"][role]
        capture = lab / f"{role}-{mode}-entry.txt"
        env = dict(base, DOTNET_JitDisasm="*StartNativeCall* *TryStartDefaultIntegerReturn*", DOTNET_JitStdOutFile=str(capture))
        if mode == "tierless": env["DOTNET_TieredCompilation"] = "0"
        subprocess.run([
            sdk / "dotnet.exe", image / "ValidatedAllocation.dll", image, comparison / "catalog.json",
            comparison / f"{role}-{mode}-jit-diagnostic.json",
        ], env=env, check=True, timeout=60)
        if not capture.exists():
            print(role, mode, "no entry disassembly")
            continue
        for line in capture.read_text(encoding="utf-8").splitlines():
            if line.startswith("; Assembly listing") or line.startswith("; Total bytes") or "sub      rsp" in line:
                print(role, mode, line)
