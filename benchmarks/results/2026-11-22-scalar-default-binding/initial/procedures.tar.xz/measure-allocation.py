from pathlib import Path
import hashlib, json, os, shutil, subprocess

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
out = lab / "comparison"
catalog = out / "catalog.json"
read=lambda p: json.loads(p.read_text(encoding="utf-8-sig"))
ids=[case["id"] for case in read(catalog)["cases"]]
info=read(out/"images.json")
sha=lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
assert len(ids)==5 and info["catalogSHA256"]==sha(catalog)
sdk=Path.home()/".dotnet11"
dotnet=sdk/"dotnet.exe"
env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk),PATH=str(sdk)+os.pathsep+os.environ["PATH"])
python=Path("C:/Python313/python.exe")
protocol=repo/"benchmarks/cpython-worker.py"
assert info["protocolSHA256"]==sha(protocol)
roles=("reference","candidate")
images={role:out/f"frozen-{role}" for role in roles}
donor=lab.parent/"inline-cased-word-headers-20261122/comparison/frozen-candidate"
bench="Lokad.Lython.Benchmarks.dll"
def verify(role):
    assert {n:sha(images[role]/n) for n in info["imageFiles"][role]}==info["imageFiles"][role]
for role in roles:
    verify(role)
    for suffix in (".dll",".deps.json",".runtimeconfig.json"):
        name="ValidatedAllocation"+suffix
        shutil.copyfile(donor/name,images[role]/name)
    report=out/f"{role}-allocation.json"
    subprocess.run([dotnet,images[role]/"ValidatedAllocation.dll",images[role],catalog,report],env=env,check=True,timeout=85)
    rows=read(report)["rows"]
    assert {row["id"] for row in rows}==set(ids) and all(row["sharedBudgetBaselineRestored"] for row in rows)
    print(role,[ (row["id"],row["allocatedBytesPerInvocation"],row["peakExecutionMemoryBytes"]) for row in rows],flush=True)
    verify(role)
