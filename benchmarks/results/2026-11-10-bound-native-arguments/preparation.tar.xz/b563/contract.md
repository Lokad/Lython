# R214 current bound-helper cost gate

One existing complete class-renderer report, exact source/fixtures/goldens from
R198; current qualified e543/0e core. Existing six-second warm CPU collector and
worker, normal GC/tiering plus perf-map logging. R195 predates R198's material
context simplification. No new elapsed pair, CPython or backend qualification.
Keep all raw/unknown/thread CPU and wider reset/protocol/full-check boundaries.
Assess native binder/argument construction before selecting a contiguous operand
borrow. No guessed removable tax or predicted speedup. 90sowner/30stop/30margin,
all source/output/quiet/join/Closed/map-SHA/archive/cleanup gates unchanged.
