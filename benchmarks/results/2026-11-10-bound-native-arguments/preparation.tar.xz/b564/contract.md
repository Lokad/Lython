# R214 bounded native operand borrow comparison

Two existing complete scripts: bound Words.from_line text target and ordinary text
control. Sync warm only; async/compile/allocation desktop diagnostics retained with
original adversity and unchanged-code movement. Current reference0e versus frozen
candidate2f9, identical workers/auxiliary bits/protocol/goldens. Four independent
source roles,5s warmup,7rotated400msrounds,normalGC/tiering. No speedup forecast,
allocation gain or fixed threshold. Decide retain/refine/withdraw from usable
evidence; preserve adverse/control/unknown results. 120sowner/30stop/30margin.
Whole command-v2 includes mediated I/O, full per-invocation output checks and prior
result cleanup; excludes compile/reset/separate verify/protocol/final caches.
No pending-I/O latency, CPython, embedding-tail or final producer qualification.
