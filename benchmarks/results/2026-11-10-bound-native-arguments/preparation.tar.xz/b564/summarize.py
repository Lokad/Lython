from pathlib import Path
import json,statistics
p=Path(__file__).parent
raw=json.loads((p/'retrieved/confirmation/confirmation.json').read_text(encoding='utf-8'))
assert raw['complete']and len(raw['jobs'])==2
rows=[]
for job in raw['jobs']:
    labels=list(job['identities'])
    values={k:[1000*s['response']['elapsedTicks']/s['response']['clockFrequency']/s['response']['completedInvocations']for s in job['samples']if s['engine']==k]for k in labels}
    med={k:statistics.median(v)for k,v in values.items()}
    cpu={k:statistics.median(1000*s['externalProcessCpuTicks']/s['externalCpuFrequency']/s['response']['completedInvocations']for s in job['samples']if s['engine']==k)for k in labels}
    iqr={k:100*(statistics.quantiles(v,n=4)[2]-statistics.quantiles(v,n=4)[0])/med[k]for k,v in values.items()}
    changes={f'{a}/{b}':100*(med[a]/med[b]-1)for a in ['candidate','candidate-control']for b in ['reference','reference-control']}
    cpuChanges={f'{a}/{b}':100*(cpu[a]/cpu[b]-1)for a in ['candidate','candidate-control']for b in ['reference','reference-control']}
    spreads={kind:100*abs(med[kind+'-control']/med[kind]-1)for kind in ['reference','candidate']}
    rows.append(dict(case=job['case'],lane=job['lane'],medianMilliseconds=med,processCpuMedianMilliseconds=cpu,iqrPercent=iqr,controlSpreadPercent=spreads,changePercent=changes,processCpuChangePercent=cpuChanges,limits='Four independent source-pair processes; ranges are not confidence intervals. External CPU includes wider reset/protocol work and coarse ticks. Stability describes evidence, not a design veto.'))
    print(job['case'],job['lane'],'elapsed',min(changes.values()),max(changes.values()),'CPU',min(cpuChanges.values()),max(cpuChanges.values()),'spreads',spreads,'maxIQR',max(iqr.values()),flush=True)
identity=json.loads((p/'identity.json').read_text(encoding='utf-8'))
(p/'summary.json').write_text(json.dumps(dict(complete=True,jobs=2,elapsedSeconds=raw['elapsedSeconds'],sourceRevision=identity['sourceRevision'],coreSHA256=identity['coreSHA256'],timing=rows),indent=2)+'\n',encoding='utf-8')
