from pathlib import Path
import bisect,collections,datetime,hashlib,json,re,shutil,tarfile
h=Path(__file__).parent;repo=Path('D:/code/Lython');dest=repo/'benchmarks/results/2026-11-10-bound-native-arguments';dest.mkdir(exist_ok=False)
def write(path,text):path.write_text(text,encoding='utf-8',newline='\n')
decision=json.loads((h/'withdrawal.json').read_text(encoding='utf-8'))
checks=json.loads((h/'restored-validation.json').read_text(encoding='utf-8'));assert len(checks)==4 and all(c['exitCode']==0 for c in checks)
decision['restoredValidation']={f"{c['kind']}-{c['target']}":c['passed']for c in checks}
decision['restoredCoreSHA256']={target:hashlib.sha256((repo/f'src/Lokad.Lython/bin/Release/{target}/Lokad.Lython.dll').read_bytes()).hexdigest()for target in ['net11.0','net10.0']}
decision['restoredBinaryLimit']='Fresh forced-build identities after restoring qualified source; not the timed0e image. Runtime sources match e543, test additions remain.'
write(dest/'decision.json',json.dumps(decision,indent=2)+'\n')

profile=dest/'profile';profile.mkdir();p=h/'b563'
for name in ['observations.tgz','identity.json','archive-receipt.json','terminal-status.json','extraction.json']:
    shutil.copyfile(p/name,profile/name)
r=p/'retrieved/profiles/class-report-warm';record=json.loads((r/'record.json').read_text(encoding='utf-8'));original=json.loads((r/'guest-cpu-leaves.json').read_text(encoding='utf-8'))
ranges=[]
for line in(r/'perf.map').read_text(encoding='utf-8').splitlines():
    start,size,name=line.split(' ',2);ranges.append((int(start,16),int(size,16),name))
ranges.sort();starts=[a for a,n,name in ranges];counts=collections.Counter();tids=set(record['guestTids'])
for line in(r/'perf-leaves.txt').read_text(encoding='utf-8').splitlines():
    m=re.match(r'\s*(\d+)/(\d+)\s+([0-9a-fx]+)\s*(.*)',line)
    if not m or m[2]not in tids:continue
    address=int(m[3],16);i=bisect.bisect_right(starts,address)-1;symbol=m[4]
    if i>=0 and address<ranges[i][0]+ranges[i][1]:symbol=ranges[i][2]
    counts[symbol]+=1
assert counts.total()==original['samples']==1093 and counts['[unknown]']==73
write(profile/'attribution.json',json.dumps(dict(samples=1093,unknown=73,selectedThreadCPUSeconds=original['cpuSeconds'],
    workerExecutionSeconds=json.loads((p/'archive-receipt.json').read_text())['capturedSeconds'],allThreads=record['threadCpuSeconds'],allLeaves=counts.most_common(),
    limitation='Managed leaf IPs mapped using the saved CLR map. Raw frame-pointer stacks remain unresolved unless mapped; absence of textual names in raw stacks is not absence of work. Useful/inlined work and wider reset/protocol/full checks remain. No elapsed or CPU-speedup comparison.',
    relevance='Current renderer multi-field fstring reaches ordinary executable work, not the native-return binder. This workload mismatch is retained; it does not disprove the separate native-bound hypothesis.'),indent=2)+'\n')

quiet=dest/'quiet';quiet.mkdir();p=h/'b564'
for name in ['observations.tgz','identity.json','summary.json','archive-receipt.json','terminal-status.json','extraction.json']:
    shutil.copyfile(p/name,quiet/name)
shutil.copyfile(p/'retrieved/space-recovery.json',quiet/'space-recovery.json')
assert hashlib.sha256((quiet/'observations.tgz').read_bytes()).hexdigest()=='47bc3643bbb6ea2d38fd43fdb8d5c7f86b75727396e1a27db67c6eaee5868a3b'
local=dest/'desktop';local.mkdir()
for phase in ['warm','warm-corrected','warm-async-corrected','compile-corrected']:
    shutil.copytree(h/'diagnostic'/phase,local/phase)
for name in ['identity.json','identity-corrected.json','catalog-four-cases.json','hash-witness.json']:
    shutil.copyfile(h/'diagnostic'/name,local/name)
with tarfile.open(dest/'preparation.tar.xz','w:xz')as archive:
    for path in h.rglob('*'):
        parts=path.relative_to(h).parts
        if path.is_file()and not any(n in parts for n in ['images','retrieved'])and path.name not in ['observations.tgz','payload.tgz']:
            archive.add(path,arcname=path.relative_to(h).as_posix())
    for name in ['src/Lokad.Lython/Runtime/LythonRuntime.Executable.Calls.Invoke.cs','src/Lokad.Lython/Runtime/LythonRuntime.Executable.Calls.cs','src/Lokad.Lython/Runtime/PyFunctionBase.cs']:
        archive.add(repo/name,arcname='restored-source/'+name)
summary=json.loads((quiet/'summary.json').read_text(encoding='utf-8'))
rows=[]
for t in summary['timing']:
    e=list(t['changePercent'].values());c=list(t['processCpuChangePercent'].values());sp=t['controlSpreadPercent']
    rows.append(f"| {t['case']} | {min(e):+.2f}..{max(e):+.2f}% | {min(c):+.2f}..{max(c):+.2f}% | {sp['reference']:.2f}% / {sp['candidate']:.2f}% |")
write(dest/'README.md','''# R214 — bound native operand borrowing, withdrawn

**Withdraw the complete production variant.** Exact restored runtime matches all
568 normalized C# sources of fully qualified e543bf15. Keep the independently
checked positional-method/default/alias case and exact-positional retained-result
coverage; no target-mutation path, new helper/backend or compatibility stub remains.
[Decision and restored checks](decision.json), [source/commands/builds/tests/original conditions](preparation.tar.xz).

The candidate extended existing exact positional borrowing to bound native helpers.
Its evaluated receiver temporarily occupied the target slot immediately preceding
arguments, restored in finally before fallback/error/publication. This skipped
native buffer filling, assignment-presence binding and clearing for that shape.
The general binder remained necessary. No allocation or ownership representation
change, new cache/map/packet, quota or unsafe code. Current-token, stack and terminal
refusal semantics remained active; the borrowed span could not cross suspension.

Forced Release builds pass without warnings/errors. **155 internal / 224 public
focused checks pass per actual .NET 11 and .NET 10** on both candidate and restored
source, including receiver/descriptor/default/keyword/error semantics, aliases,
genuine pending host protocols, cancellation, terminal refusal and budget reuse.
The new method-default output was independently checked under local CPython3.13.2.
Restoration used owned-file hash guards and a fresh nonincremental build. No
unchanged full-platform/package qualification was repeated; exact e543 source's
cached GREEN42898279287 remains authoritative. No candidate delivery is claimed.

## Measurements and decision

Reference fresh postcommit0e2bc55b (e543), candidate2f9b100e (f1c850fb plus preserved
patch). Both exact DLLs survive in [quiet raw evidence](quiet/observations.tgz).
2026-11-10, F4as_v7/Ubuntu24.04.4/.NET11RC3, ordinary GC/tiering, existing worker
and optional adapter0.4. Two complete sync-warm jobs **75.696 seconds**; four
independent source roles,5s warmup each,7rotated400msrounds. All source/fixture/full
output, ownership, quiet, Closed/join, RAM removal, archive-under-lease and local
SHA gates pass. [All medians/IQR/CPU](quiet/summary.json), [receipt](quiet/archive-receipt.json).

| Existing complete workload | Elapsed change | Wider process CPU | Reference / candidate spread |
| --- | ---: | ---: | ---: |
'''+ '\n'.join(rows)+'''

The bound-method target has a small favorable elapsed result with supporting wider
CPU. Ordinary text retains possible small CPU regression debt; allocation and
compilation bytes are flat. Ranges include all four source pairings, not confidence
intervals. Max IQR is0.98%target/1.51%control. CPU includes reset/protocol and coarse
ticks; no general equivalence, async improvement or embedding latency is established.

The added mutable-target/finally route and extra hot-selector branch do not remove
the binder globally. The useful measured gain does not justify this narrower path
and unresolved ordinary-call debt for the current simplification milestone. This
is a complexity/whole-script decision, not a fixed-percentage veto or permanent ban
on a different calling convention. Do not automatically revive the unchanged variant.

[Desktop diagnostics](desktop/) retain all adverse results: bound sync+2.95..5.03%,
async+3.23..6.91%, unchanged compilation+5.52..8.91%, with moving controls. Other
controls' favorable/adverse values survive unchanged. These timings do not isolate
the cause of the original adversity. The first four-case setup failed at the
unchanged driver's five-case guard before any workload; its empty output/error and
catalog survive. The correction added an existing CSV control and changed no core,
driver/settings. Quiet used only target and ordinary-text control. No failed clock
was erased or selectively relabelled as a current HEAD gain.

## Initial workload relevance

One current class-renderer report capture, before any code edit, has1093execution-
thread samples/73unmapped6.68%,5.51threadCPU seconds and5.767worker execution seconds.
[Mapped leaves/all threads](profile/attribution.json), [raw maps/stacks/current core](profile/observations.tgz).
Its multi-field formatted helper uses ordinary executable work, so it does not
exercise the intended native binder. The existing R145/R192 bound Words.from_line
text helper supplies the corrected target; no new script framework or extra CPU
capture. Keep this original mismatch separate from the actual source pair.
Current numeric formatting already uses .NET11 UTF-8 TryFormat; an internal
FormatBigInteger symbol alone does not establish a temporary CLR string.

All owned users ended; no VM workers/RAM remain. Staging advanced the protected
snapshot to fully qualified0e, retiring superseded101/Dbe inode groups and one exact
raw-map duplicate only after committed canonical/all-alias/UID/path/hash proof and
verified replacement payload. [Recovery](quiet/space-recovery.json). Their immutable
R207/R211 archives remain unchanged; do not probe retired aliases. Final free space
262,758,400B, fixed240MiBfloor/12MiBsetup headroom intact. Publication is postponed;
the broader runtime and independent regex work continue.
''')
print('R214 complete source/evidence/restoration recorded; no production variant retained.')
