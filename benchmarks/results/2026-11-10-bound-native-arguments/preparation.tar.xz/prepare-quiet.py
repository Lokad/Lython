from pathlib import Path
import ast,hashlib,io,json,subprocess,tarfile
h=Path(__file__).parent;repo=Path('D:/code/Lython');old=h.parent/'tuple-value-construction-r208/b560';p=h/'b564';p.mkdir(exist_ok=False)
def write(path,text):path.write_text(text,encoding='utf-8',newline='\n')
diag=json.loads((h/'diagnostic/identity-corrected.json').read_text(encoding='utf-8'))
base=json.loads((h.parent/'cpython-construction-r209/b561/identity.json').read_text(encoding='utf-8'))
identity=dict(sourceRevision='Qualified e543bf15/0e reference; f1c850fb+R214 exact bound native operand borrowing candidate2f9b100e. Focused155internal/224public eachactual11/10 pass; no retained/platform decision yet. Desktop original target adversity preserved, compile/controls move. No allocation gain.',
    coreSHA256={'reference':diag['cores']['before'],'reference-control':diag['cores']['before'],'candidate':diag['cores']['candidate'],'candidate-control':diag['cores']['candidate']},auxiliaryFiles=base['auxiliaryFiles'],performanceQualified=False)
catalog=json.loads((h/'diagnostic/catalog.json').read_text(encoding='utf-8'))
ids=['scripts.text-summary-helpers.class-callable.large','scripts.text-summary-helpers.large']
catalog['cases']=[next(c for c in catalog['cases']if c['id']==name)for name in ids]
write(p/'representative.json',json.dumps(catalog,ensure_ascii=False,indent=2)+'\n')
identity['catalogSHA256']=hashlib.sha256((p/'representative.json').read_bytes()).hexdigest();write(p/'identity.json',json.dumps(identity,indent=2)+'\n')
for name in ['collect.py','archive-owned.py','run.sh','retrieve.py','summarize.py']:
    s=(old/name).read_text(encoding='utf-8').replace('tuple-constructors-b560-20261110','bound-borrow-b564-20261110').replace('lython-b560-tuple-constructors-20261110','lython-b564-bound-borrow-20261110')
    s=s.replace('len(jobs)==3','len(jobs)==2').replace("len(raw['jobs'])==3","len(raw['jobs'])==2").replace('jobs=3','jobs=2').replace("['jobs']==3","['jobs']==2").replace("'jobs')==3","'jobs')==2").replace("['elapsedSeconds']<150","['elapsedSeconds']<120")
    if name=='collect.py':
        lines=s.splitlines();at=next(i for i,line in enumerate(lines)if line.startswith('jobs='));lines[at]='jobs='+repr([[name,'warm']for name in ids]);s='\n'.join(lines)+'\n'
        s=s.replace("time.monotonic()-started < 110","time.monotonic()-started < 80")
        a=s.index("purpose='");b=s.index("',\n",a)
        s=s[:a]+"purpose='R214 bound method text target plus ordinary text control, same qualified0e versus candidate2f9. Exact positional calls borrow existing receiver-prefixed operands, original target restored; no buffer or mapping layer. Original desktop adversity retained"+s[b:]
    if name=='retrieve.py':s=s.replace('B560 three-job','B564 two-job')
    if name.endswith('.py'):ast.parse(s)
    write(p/name,s)
write(p/'contract.md','''# R214 bounded native operand borrow comparison

Two existing complete scripts: bound Words.from_line text target and ordinary text
control. Sync warm only; async/compile/allocation desktop diagnostics retained with
original adversity and unchanged-code movement. Current reference0e versus frozen
candidate2f9, identical workers/auxiliary bits/protocol/goldens. Four independent
source roles,5s warmup,7rotated400msrounds,normalGC/tiering. No speedup forecast,
allocation gain or fixed threshold. Decide retain/refine/withdraw from usable
evidence; preserve adverse/control/unknown results. 120sowner/30stop/30margin.
Whole command-v2 includes mediated I/O, full per-invocation output checks and prior
result cleanup; excludes compile/reset/separate verify/protocol/final caches.
No pending-I/O latency, CPython, embedding-tail or final producer qualification.
''')
retire=[]
canonical='benchmarks/results/2026-11-10-lexical-loop-cleanup/observations.tgz'
data=(repo/canonical).read_bytes();assert data==subprocess.check_output(['git','show','HEAD:'+canonical],cwd=repo)
with tarfile.open(fileobj=io.BytesIO(data))as archive:
    for member,known in [('baseline-core.dll','transient-split-b555-20261110/candidate/Lokad.Lython.dll'),('current-core.dll','lexical-loop-b558-20261110/candidate/Lokad.Lython.dll')]:
        core=archive.extractfile(member).read();retire.append(dict(knownPath=known,canonical=canonical,member=member,bytes=len(core),sha256=hashlib.sha256(core).hexdigest()))
write(p/'superseded-cores.json',json.dumps(retire,indent=2)+'\n')
canonical='benchmarks/results/2026-11-10-current-text-construction-cost/observations.tgz'
data=(repo/canonical).read_bytes();assert data==subprocess.check_output(['git','show','HEAD:'+canonical],cwd=repo)
member='profiles/text-warm/perf.map'
with tarfile.open(fileobj=io.BytesIO(data))as archive:blob=archive.extractfile(member).read()
exact=dict(path='current-text-b562-20261110/'+member,canonical=canonical,member=member,bytes=len(blob),sha256=hashlib.sha256(blob).hexdigest())
write(p/'exact-copy.json',json.dumps(exact,indent=2)+'\n')
core=h/'diagnostic/images/candidate/Lokad.Lython.dll';assert hashlib.sha256(core.read_bytes()).hexdigest()==diag['cores']['candidate']
with tarfile.open(p/'payload.tgz','w:gz')as archive:
    for name in ['representative.json','identity.json','collect.py','archive-owned.py','run.sh','contract.md']:archive.add(p/name,arcname=name)
    archive.add(core,arcname='current-core.dll')
with tarfile.open(p/'payload.tgz')as archive:footprint=sum(((m.size+4095)//4096)*4096 for m in archive.getmembers()if m.isfile())+128*1024
size=(p/'payload.tgz').stat().st_size
write(p/'footprint.json',json.dumps(dict(payloadBytes=size,footprintBytes=footprint,requiredFreeBytes=(240+12)*1024*1024+max(footprint,3*size)),indent=2)+'\n')
launch=(old/'launch.py').read_text(encoding='utf-8')
launch=launch.replace('tuple-constructors-b560-20261110','bound-borrow-b564-20261110').replace('lython-b560-tuple-constructors-20261110','lython-b564-bound-borrow-20261110').replace('tuple-constructors-b560-launch.py','bound-borrow-b564-launch.py').replace('lython-b560-fixtures','lython-b564-fixtures')
launch=launch.replace("source=base/'lexical-loop-b558-20261110/candidate'","source=base/'construction-cpython-b561-20261110/candidate'")
launch=launch.replace("stable=base/'transient-split-b555-20261110/candidate/Lokad.Lython.dll'","stable=source/'Lokad.Lython.dll'").replace('101ba9d3e5237b8d0da09689a94abf9b7dbbe276634becedac61e859e84ac897',diag['cores']['before'])
launch=launch.replace('qualified101AndBeforeDbePreserved=True','fullyQualified0ePreserved=True').replace('jobs=3,ownerSeconds=150','jobs=2,ownerSeconds=120').replace('RuntimeMaxSec=150','RuntimeMaxSec=120').replace('seconds=210','seconds=180').replace('ownerSeconds=150','ownerSeconds=120')
launch=launch.replace("expectedCores=json.loads((r/'identity.json').read_text(encoding='utf-8'))['coreSHA256'])","expectedCores=json.loads((r/'identity.json').read_text(encoding='utf-8'))['coreSHA256'],exact=json.loads((r/'exact-copy.json').read_text(encoding='utf-8')))")
needle="   reclaim+=first.st_blocks*512;retired.append(dict(proof,paths=aliases,allocatedBytes=first.st_blocks*512,allHardlinkAliasesVerified=True))\n"
assert needle in launch
launch=launch.replace(needle,needle+"  exact=config['exact'];path=base/exact['path'];st=path.lstat()\n  assert path.resolve(strict=True).is_relative_to(base)and stat.S_ISREG(st.st_mode)and st.st_uid==os.getuid()and st.st_nlink==1\n  assert st.st_size==exact['bytes']and hashlib.sha256(path.read_bytes()).hexdigest()==exact['sha256']\n  reclaim+=st.st_blocks*512;retired.append(dict(exact,paths=[exact['path']],allocatedBytes=st.st_blocks*512,allHardlinkAliasesVerified=True))\n")
ast.parse(launch);write(p/'launch.py',launch)
print('Prepared two-job quiet comparison, superseded snapshot/canonical proofs; no VM mutation yet.')
