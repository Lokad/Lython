from pathlib import Path
import json
import subprocess
import sys

lab = Path(__file__).resolve().parent
old = lab.parent / 'function-binding-inline-r712'
catalog = json.loads((lab.parent/'one-abstract-fact-map-r672/catalog.json').read_text(encoding='utf-8'))
assert len(catalog['cases']) == 5
(lab/'catalog.json').write_text(json.dumps(catalog, indent=2, ensure_ascii=False)+'\n', encoding='utf-8', newline='\n')
source = (old/'freeze-and-verify.py').read_text(encoding='utf-8')
source = source.replace('function-binding-inline-r712','selected-abstract-path-r713')
source = source.replace("git('rev-parse','65926a62d')", "git('rev-parse','ee057fd12')")
assert "trial=repo/'.git/agent-worktrees/selected-abstract-path-r713'" in source
assert "git('rev-parse','ee057fd12')" in source
(lab/'freeze-and-verify.py').write_text(source,encoding='utf-8',newline='\n')
subprocess.run([sys.executable,'-X','utf8',lab/'freeze-and-verify.py'],check=True)
measurement = lab.parent/'postfix-statement-r699/measure-compile-allocation.py'
subprocess.run([sys.executable,'-X','utf8',measurement,lab],check=True)

