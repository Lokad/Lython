from pathlib import Path
import hashlib
import gzip
import json
import shutil
import statistics
import subprocess
import sys
import tarfile

lab = Path(__file__).resolve().parent
out = Path("benchmarks/results/2026-11-19-selected-abstract-paths")
def load(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))
def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
def save(path, data):
    path.write_text(json.dumps(data, indent=2) + "\n", encoding="utf-8")

pair = load(lab / "frozen-identity.json")
images = pair["images"]
base = pair["referenceCommit"]
candidate = pair["candidateCommit"]
retained = sys.argv[1]
if retained != "private":
    def changed(left, right, *paths):
        return subprocess.check_output(["git", "diff", "--name-only", left, right, "--", *paths]).decode().splitlines()
    measured_files = changed(base, candidate, "src", "tests")
    assert measured_files and all(name.startswith(("src/Lokad.Lython/", "tests/")) for name in measured_files)
    # The separately verified CSV search preparation was retained between the
    # measured base and the application of this function layout change.
    composed = subprocess.check_output(["git", "merge-tree", "--write-tree", retained+"^", candidate]).decode().strip()
    subprocess.run(["git", "diff", "--exit-code", composed, retained, "--", "src", "tests"], check=True)
cases = {case["id"]: case for case in load(lab / "catalog.json")["cases"]}
assert digest(lab / "catalog.json") == pair["casesSHA256"]

def verify(folder, jobs, summary):
    scan = lab / folder
    identity = load(scan / "identity.json")
    assert identity["imageFiles"] == images and identity["catalogSHA256"] == pair["casesSHA256"]
    assert digest(scan / "representative.json") == pair["casesSHA256"]
    for role, files in images.items():
        frozen = lab / "frozen" / role
        assert len(files) == 32
        assert {entry.name: digest(entry) for entry in frozen.iterdir() if entry.is_file() and entry.name in files} == files
    receipt = load(scan / "archive-receipt.json")
    terminal = load(scan / "terminal-status.json")
    assert terminal["receipt"] == receipt and terminal["exitCode"] == "0"
    assert not terminal["remainingWorkers"] and not terminal["remainingTrace"]
    assert all(receipt[key] for key in ("complete", "allWorkersJoined", "guestFixturesRemoved",
                                        "quietBeforeAndAfter", "archivedAndVerifiedUnderLease"))
    assert receipt["jobs"] == jobs and receipt["archiveSHA256"] == digest(scan / "observations.tgz")
    raw = load(scan / "retrieved/confirmation/confirmation.json")
    assert raw["complete"] and len(raw["jobs"]) == jobs
    for job in raw["jobs"]:
        case = cases[job["case"]]
        assert job["workersJoinedAndFixturesRemoved"] and len(job["samples"]) == 20
        assert set(job["identities"]) == set(identity["coreSHA256"])
        for role, worker in job["identities"].items():
            image = images[role.removesuffix("-control")]
            relevant = {Path(lib["path"]).name: lib["sha256"].lower() for lib in worker["libraries"]
                        if Path(lib["path"]).name in image}
            assert "Lokad.Lython.dll" in relevant
            assert all(image[name] == value for name, value in relevant.items())
            assert sorted(row["round"] for row in job["samples"] if row["engine"] == role) == list(range(5))
        for row in job["samples"]:
            value = row["response"]
            assert value["status"] == "Completed" and value["completedInvocations"] > 0
            for key in ("sourceSha256", "fixtureSha256", "expectedOutputSha256"):
                assert value[key] == case[key]
            for field, golden in (("actualOutputSha256", "expectedOutputSha256"), ("actualFilesSha256", "expectedFilesSha256")):
                assert value.get(field) == (None if job["lane"] == "compile" else case.get(golden))
    result = load(lab / summary)
    result.update(referenceRuntime=base, measuredPrototype=candidate, cores=identity["coreSHA256"],
        archiveSHA256=receipt["archiveSHA256"], retentionDecisionPending=False, retained=retained != "private")
    if retained != "private":
        result["retainedCommit"] = retained
    return result

initial = verify("quiet", 6, "quiet-summary.json")
allocations = []
before = load(lab / "reference-allocation.json")["rows"]
after = load(lab / "candidate-allocation.json")["rows"]
for left, right in zip(before, after, strict=True):
    assert left["id"] == right["id"] and left["sharedBudgetBaselineRestored"] and right["sharedBudgetBaselineRestored"]
    a = statistics.median(left["allocatedBytesPerInvocation"])
    b = statistics.median(right["allocatedBytesPerInvocation"])
    allocations.append(dict(case=left["id"], allocatedBytes=[a,b], allocatedChangePercent=100*(b/a-1),
        accountedPeak=[left["peakExecutionMemoryBytes"],right["peakExecutionMemoryBytes"]]))
initial["localAllocation"] = allocations

compile_rows = []
before = load(lab / 'reference-compile-allocation.json')['rows']
after = load(lab / 'candidate-compile-allocation.json')['rows']
for left, right in zip(before, after, strict=True):
    assert left['id'] == right['id'] and left['characters'] == right['characters']
    reference_bytes, candidate_bytes = (statistics.median(row['bytes']) for row in (left,right))
    compile_rows.append(dict(case=left['id'], allocatedBytes=[reference_bytes, candidate_bytes],
                             allocatedChangePercent=100*(candidate_bytes/reference_bytes-1)))
initial['localCompilationAllocation'] = compile_rows
initial['stagingConditions'] = [load(lab / filename) for filename in
    ('initial-insufficient-space.json', 'second-insufficient-space.json', 'frozen-copy-receipt.json')]
assert initial['stagingConditions'][2]['changed']
out.mkdir(exist_ok=False)
save(out / 'summary.json', initial)
for name in ('observations.tgz', 'archive-receipt.json', 'terminal-status.json'):
    shutil.copyfile(lab / 'quiet' / name, out / name)
reference = lab / "frozen/reference/Lokad.Lython.dll"
assert digest(reference) == images["reference"][reference.name]
(out / "reference-core.dll.gz").write_bytes(gzip.compress(reference.read_bytes(), mtime=0))
core = lab / "frozen/candidate/Lokad.Lython.dll"
assert digest(core) == images["candidate"][core.name]
(out / "measured-core.dll.gz").write_bytes(gzip.compress(core.read_bytes(),mtime=0))
with tarfile.open(out / 'checks-and-procedures.tar.xz', 'w:xz', preset=6) as tar:
    for name in (
        'measured-source.patch', 'catalog.json', 'frozen-identity.json', 'freeze-and-verify.py',
        'reference-verify.json', 'candidate-verify.json', 'reference-allocation.json', 'candidate-allocation.json',
        'reference-compile-allocation.json', 'candidate-compile-allocation.json', 'reference-build.log',
        'public-windows.log', 'white-windows.log', 'public-ubuntu.log', 'white-ubuntu.log', 'source-pair.log',
        'prepare-pair.py', 'prepare-quiet.py', 'prove-quiet-space.py', 'stage-quiet.py', 'preflight.json',
        'initial-insufficient-space.json', 'second-insufficient-space.json', 'compact-frozen-copies.py',
        'frozen-copy-preflight.json', 'frozen-copy-receipt.json', 'quiet-space.json', 'summarize-quiet.py',
        'launch-quiet.py', 'retrieval.log', 'prepare-evidence.py', 'archive-evidence.py',
    ):
        tar.add(lab / name, arcname=name)
    for name in ('config.json', 'identity.json', 'remote-launch.py', 'retrieve.py', 'observe-not-before.json',
                 'launch.log', 'collect.py', 'archive-owned.py', 'run.sh'):
        tar.add(lab / 'quiet' / name, arcname='quiet/' + name)
print('Archived six lanes, complete image identities and all staging conditions.')
