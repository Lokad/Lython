from pathlib import Path
import json
import subprocess
import sys

lab = Path(__file__).resolve().parent
template = lab.parent/'function-binding-inline-r712'
stage = (template/'stage-quiet.py').read_text(encoding='utf-8')
stage = stage.replace('function-binding-inline-b1142','selected-abstract-path-b1144')
stage = stage.replace('lython-b1142-function-binding-inline','lython-b1144-selected-abstract-path')
stage = stage.replace('lython-b1142-fixtures','lython-b1144-fixtures')
stage = stage.replace('R712 inline live function binding state','R713 selected abstract binding paths')
stage = stage.replace('Inline function binding state','Selected abstract binding paths')
start = stage.index('        jobs = [')
end = stage.index('\n', start)
cases = {case['id'] for case in json.loads((lab/'catalog.json').read_text(encoding='utf-8'))['cases']}
validator = 'scripts.config-generated-guards.medium'
manifest = 'scripts.config-manifest.small'
report = 'scripts.report-render.format-selectors.large'
jobs = [(validator,'compile'),(manifest,'compile'),(report,'compile'),
        (validator,'compile-run'),(manifest,'compile-run'),(report,'warm')]
assert all(case in cases for case,_ in jobs)
stage = stage[:start] + '        jobs = ' + repr(jobs) + stage[end:]
stage = stage.replace('five-case, six-job','three-case, six-job').replace('}) == 5','}) == 3')
proof = (template/'prove-quiet-space.py').read_text(encoding='utf-8')
a,b = proof.index('pairs = '),proof.index('\n',proof.index('pairs = '))
# The archive is a prerequisite for safely rotating the latest working copy.
pairs = [('function-binding-inline-r712/quiet','2026-11-19-inline-function-binding-state','reference','reference-core.dll.gz'),
         ('function-binding-inline-r712/quiet','2026-11-19-inline-function-binding-state','candidate','measured-core.dll.gz'),
         ('csv-rule-cpython-b1143','2026-11-19-csv-rule-cpython-checkpoint','candidate','measured-core.dll.gz'),
         ('parse-annotation-frontiers-r708/quiet','2026-11-19-parser-annotation-bounds','candidate','measured-core.dll.gz'),
         ('retained-annotations-r700/quiet','2026-11-19-retained-annotation-values','candidate','measured-core.dll.gz'),
         ('trim-range-split-r676/quiet','2026-11-19-trim-range-split','candidate','measured-core.dll.gz'),
         ('proven-record-keywords-r694/quiet','2026-11-19-proven-record-keywords','candidate','measured-core.dll.gz')]
proof = proof[:a] + 'pairs = ' + repr(pairs) + proof[b:]
for name,value in [('prove-quiet-space.py',proof),('stage-quiet.py',stage)]:
    (lab/name).write_text(value,encoding='utf-8',newline='\n')
    subprocess.run([sys.executable,'-X','utf8',lab/name],check=True)

