from pathlib import Path
import json
import subprocess
import sys

lab = Path(__file__).resolve().parent
template = lab.parent / 'function-binding-inline-r712' / 'archive-r712.py'
source = template.read_text(encoding='utf-8')
source = source.replace('2026-11-19-inline-function-binding-state', '2026-11-19-selected-abstract-paths')
start = source.index('confirmation = verify')
end = source.index('allocations = []')
source = source[:start] + source[end:]
start = source.index('out.mkdir(exist_ok=False)')
end = source.index('reference = lab /')
source = source[:start] + '''compile_rows = []
before = load(lab / 'reference-compile-allocation.json')['rows']
after = load(lab / 'candidate-compile-allocation.json')['rows']
for left, right in zip(before, after, strict=True):
    assert left['id'] == right['id'] and left['characters'] == right['characters']
    reference_bytes, candidate_bytes = (statistics.median(row['bytes']) for row in (left,right))
    compile_rows.append(dict(case=left['id'], allocatedBytes=[reference_bytes, candidate_bytes],
                             allocatedChangePercent=100*(candidate_bytes/reference_bytes-1)))
initial['localCompilationAllocation'] = compile_rows
initial['stagingConditions'] = [load(lab / filename) for filename in
    ('initial-insufficient-space.json', 'second-insufficient-space.json', 'frozen-copy-receipt.json')]
assert initial['stagingConditions'][2]['changed']
out.mkdir(exist_ok=False)
save(out / 'summary.json', initial)
for name in ('observations.tgz', 'archive-receipt.json', 'terminal-status.json'):
    shutil.copyfile(lab / 'quiet' / name, out / name)
''' + source[end:]
start = source.index('with tarfile.open(out / "checks-and-procedures.tar.xz"')
source = source[:start] + '''with tarfile.open(out / 'checks-and-procedures.tar.xz', 'w:xz', preset=6) as tar:
    for name in (
        'measured-source.patch', 'catalog.json', 'frozen-identity.json', 'freeze-and-verify.py',
        'reference-verify.json', 'candidate-verify.json', 'reference-allocation.json', 'candidate-allocation.json',
        'reference-compile-allocation.json', 'candidate-compile-allocation.json', 'reference-build.log',
        'public-windows.log', 'white-windows.log', 'public-ubuntu.log', 'white-ubuntu.log', 'source-pair.log',
        'prepare-pair.py', 'prepare-quiet.py', 'prove-quiet-space.py', 'stage-quiet.py', 'preflight.json',
        'initial-insufficient-space.json', 'second-insufficient-space.json', 'compact-frozen-copies.py',
        'frozen-copy-preflight.json', 'frozen-copy-receipt.json', 'quiet-space.json', 'summarize-quiet.py',
        'launch-quiet.py', 'retrieval.log', 'prepare-evidence.py', 'archive-evidence.py',
    ):
        tar.add(lab / name, arcname=name)
    for name in ('config.json', 'identity.json', 'remote-launch.py', 'retrieve.py', 'observe-not-before.json',
                 'launch.log', 'collect.py', 'archive-owned.py', 'run.sh'):
        tar.add(lab / 'quiet' / name, arcname='quiet/' + name)
print('Archived six lanes, complete image identities and all staging conditions.')
'''
(lab / 'archive-evidence.py').write_text(source, encoding='utf-8', newline='\n')
subprocess.run([sys.executable, '-X', 'utf8', lab / 'archive-evidence.py', sys.argv[1]], check=True)
