from pathlib import Path
import fcntl
import hashlib
import json
import os
import shutil
import stat
import subprocess
import sys

root = Path('/home/lokad/lython-bench-checks').resolve()
paths = [
    'allocation-current-20261101-ae22392d/worker',
    'current-text-cpu-20261101-830c6251/candidate',
    'representative-checkpoint-20261101/candidate',
    'sigma-properties-20261101/baseline',
    'sigma-properties-20261101/candidate',
]
files = {
    'Microsoft.CodeAnalysis.dll': '42c9ce7891470f430267e2dc02d03571f9d046a7e7e121107754bee58d344613',
    'Microsoft.CodeAnalysis.CSharp.dll': '1af1de8a162d2312eb2f6b781f5edbe8cec7d5cd268c7e4de24396225e54260f',
}

def fingerprint(path, digest):
    assert path.resolve() == path and path.is_relative_to(root)
    details = path.lstat()
    assert stat.S_ISREG(details.st_mode) and details.st_uid == os.getuid()
    assert hashlib.sha256(path.read_bytes()).hexdigest() == digest
    attributes = {name: os.getxattr(path, name).hex() for name in os.listxattr(path)}
    return dict(mode=details.st_mode, uid=details.st_uid, gid=details.st_gid,
                size=details.st_size, mtime_ns=details.st_mtime_ns, xattrs=attributes)

with (root / 'comparison-vm.lock').open('a') as lease:
    fcntl.flock(lease, fcntl.LOCK_EX | fcntl.LOCK_NB)
    command = ['pgrep', '-af', '[d]otnet.* --compare worker|[p]erf record|[p]ython3.*cpython-worker.py']
    live = subprocess.run(command, capture_output=True, text=True)
    assert live.returncode in (0, 1)
    assert all(line.split(maxsplit=1)[0] in (str(os.getpid()), str(os.getppid())) for line in live.stdout.splitlines())
    assert not any(os.path.ismount(path) for path in root.glob('*/guest-fixtures'))
    before = shutil.disk_usage(root).free
    replacements = []
    for name, digest in files.items():
        source = root / paths[0] / name
        expected = fingerprint(source, digest)
        for group in paths[1:]:
            target = root / group / name
            assert fingerprint(target, digest) == expected
            detail = target.lstat()
            assert detail.st_nlink == 1 and detail.st_dev == source.lstat().st_dev
            replacements.append((source, target, digest, expected, detail.st_ino))

    receipt = [dict(source=str(source.relative_to(root)), target=str(target.relative_to(root)),
                    bytes=expected['size'], originalInode=old, sha256=digest, metadata=expected)
               for source, target, digest, expected, old in replacements]
    if len(sys.argv) == 2 and sys.argv[1] == 'apply':
        for source, target, digest, expected, old in replacements:
            assert target.lstat().st_ino == old and target.lstat().st_nlink == 1
            temporary = target.with_name(target.name + '.verified-frozen-copy')
            os.link(source, temporary)
            try:
                os.replace(temporary, target)
            finally:
                if temporary.exists():
                    temporary.unlink()
            assert target.samefile(source) and fingerprint(target, digest) == expected
        changed = True
    else:
        changed = False
    print(json.dumps(dict(changed=changed, freeBeforeBytes=before,
                          freeAfterBytes=shutil.disk_usage(root).free, files=receipt), indent=2))
