from pathlib import Path
import hashlib,json,os,shutil
root=Path('/home/lokad/lython-bench-checks/result-transport-refined-b294-20261105')
base=Path('/home/lokad/lython-bench-checks/runtime-cost-b278-20261105/candidate')
assert base.is_dir()
for label in ('candidate','reference'):
 folder=root/label;folder.mkdir()
 for f in base.iterdir():
  if f.name=='Lokad.Lython.pdb':continue
  if f.name in ('Lokad.Lython.Benchmarks.dll','Lokad.Lython.Benchmarks.deps.json','Lokad.Lython.Benchmarks.runtimeconfig.json'):
   assert not f.is_symlink();os.link(f,folder/f.name)
  else:
   source=root/('core' if label=='candidate' else 'baseline')/'Lokad.Lython.dll' if f.name=='Lokad.Lython.dll' else f
   (folder/f.name).symlink_to(source.resolve(),target_is_directory=source.is_dir())
i=json.loads((root/'identity.json').read_text())
for label in ('candidate','control','reference'):
 folder=root/('candidate' if label=='control' else label)
 assert hashlib.sha256((folder/'Lokad.Lython.dll').read_bytes()).hexdigest()==i['coreSHA256'][label]
 for name,digest in i['auxiliaryFiles'].items():assert hashlib.sha256((folder/name).read_bytes()).hexdigest()==digest
assert shutil.disk_usage(root).free>24*1024*1024
print(json.dumps(dict(freeBytes=shutil.disk_usage(root).free,coreSHA256=i['coreSHA256'])))
