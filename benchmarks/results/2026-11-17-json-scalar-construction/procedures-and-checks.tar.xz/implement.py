from pathlib import Path
r = Path('D:/code/Lython/.git/agent-worktrees/json-scalars-r492')
p = r / 'src/Lokad.Lython/Runtime/LythonRuntime.Json.Deserialize.cs'
s = p.read_text(encoding='utf-8')
start = s.index('            context.CheckExecution(span);', s.index('private ValueTask<(object Value, int End)> ReadJsonValueExactAsync'))
end = s.index('        private static async ValueTask<(object Value, int End)> CompleteJsonScalarAsync(', start)
s = s[:start] + '''            var bytes = input.Utf8Span;
            if (position < bytes.Length && bytes[position] is (byte)'{' or (byte)'[')
            {
                return ReadJsonContainerAsync(input, options, context, span, position, bytes[position] == (byte)'{', asynchronous);
            }

            return TryReadJsonScalar(input, options, context, span, position, asynchronous, out var result, out var pending)
                ? new(result) : pending;
        }

        // Default scalar values go straight into construction. Only an actual
        // suspended callback needs a task carrying the value and its end offset.
        private static bool TryReadJsonScalar(PyString input, JsonLoadOptions options,
            ExecutionContext context, LythonSourceSpan span, int position, bool asynchronous,
            out (object Value, int End) result, out ValueTask<(object Value, int End)> pending)
        {
            context.CheckExecution(span);
            var bytes = input.Utf8Span;
            pending = default;
            if (position >= bytes.Length)
                throw CreateJsonExpectingError(input, bytes.Length, JsonIncompleteExpectation.Value, span, context);

            var first = bytes[position];
            if (first == (byte)'"')
            {
                var (value, stringEnd) = ReadJsonString(input, (bool)options.Strict, position, context, span);
                result = (value, stringEnd);
                return true;
            }
            if (first is (byte)'t' or (byte)'f' or (byte)'n')
            {
                if (TryMatchJsonLiteral(bytes, position, "true", out var literalEnd))
                    result = (true, literalEnd);
                else if (TryMatchJsonLiteral(bytes, position, "false", out literalEnd))
                    result = (false, literalEnd);
                else if (TryMatchJsonLiteral(bytes, position, "null", out literalEnd))
                    result = (PyNone.Instance, literalEnd);
                else throw CreateJsonExpectingError(input, position, JsonIncompleteExpectation.Value, span, context);
                return true;
            }

            object? callback;
            PyString argument;
            int end;
            if (TryMatchJsonConstant(bytes, position, out var constant, out end))
            {
                callback = options.ParseConstant;
                if (callback is null)
                {
                    result = (constant switch
                    {
                        "NaN" => PythonNaN,
                        "Infinity" => double.PositiveInfinity,
                        _ => double.NegativeInfinity,
                    }, end);
                    return true;
                }
                argument = CreateString(constant, context, span);
            }
            else if (TryMatchJsonNumber(bytes, position, context, span, out end))
            {
                var raw = bytes.Slice(position, end - position);
                var isFloat = raw.IndexOfAny((byte)'.', (byte)'e', (byte)'E') >= 0;
                callback = isFloat ? options.ParseFloat : options.ParseInt;
                if (callback is null)
                {
                    result = (ConvertJsonNumberText(raw, isFloat, context, span), end);
                    return true;
                }
                // Callback text remains execution/result-owned even on failure:
                // user code may retain it before returning, suspending or raising.
                argument = CreateUtf8String(input.Utf8Bytes.Slice(position, end - position), context, span);
            }
            else throw CreateJsonExpectingError(input, position, JsonIncompleteExpectation.Value, span, context);

            var converted = InvokeJsonCallbackCoreAsync(callback, argument, context, span, asynchronous);
            if (converted.IsCompleted)
            {
                result = (converted.GetAwaiter().GetResult(), end);
                return true;
            }
            result = default;
            pending = CompleteJsonScalarAsync(converted, end);
            return false;
        }

''' + s[end:]
start = s.index('        // Converts an already-matched constant literal:')
end = s.index('        private static int SkipJsonWhitespace', start)
s = s[:start] + s[end:]
start = s.index('        // Converts an already-matched NUMBER_RE token:')
end = s.index('            if (!isFloat)', start)
s = s[:start] + '''        // Default conversion of a validated native NUMBER_RE token. Hook
        // dispatch lives at the scalar boundary; this path cannot suspend.
        private static object ConvertJsonNumberText(ReadOnlySpan<byte> raw, bool isFloat,
            ExecutionContext context, LythonSourceSpan span)
        {
''' + s[end:]
s = s.replace('long.TryParse(raw.Span,', 'long.TryParse(raw,')
s = s.replace('return new(new BigInteger(integer));', 'return new BigInteger(integer);')
s = s.replace('return new(OwnFreshInteger(BigInteger.Parse(Encoding.UTF8.GetString(raw.Span), CultureInfo.InvariantCulture), context.MemoryGovernor, span));', 'return OwnFreshInteger(BigInteger.Parse(Encoding.UTF8.GetString(raw), CultureInfo.InvariantCulture), context.MemoryGovernor, span);')
s = s.replace('Utf8Parser.TryParse(raw.Span,', 'Utf8Parser.TryParse(raw,')
s = s.replace('return new(floating);', 'return floating;')
p.write_text(s, encoding='utf-8', newline='\n')
p = r / 'src/Lokad.Lython/Runtime/LythonRuntime.Json.Construction.cs'
s = p.read_text(encoding='utf-8')
s = s.replace('''        // One construction loop owns both parent and child containers. Scalar
        // checks/decoders are unchanged; only real callbacks transfer this work.''', '''        // One construction loop owns both parent and child containers. Default
        // scalars arrive directly; only real callbacks transfer this work.''')
old = '''                var child = ReadJsonValueExactAsync(input, options, context, span, position, state.Asynchronous);
                if (!child.IsCompleted)
                {
                    state.AwaitingContainer = false;
                    result = default;
                    pending = child;
                    return false;
                }
                var decoded = child.GetAwaiter().GetResult();
'''
new = '''                if (!TryReadJsonScalar(input, options, context, span, position, state.Asynchronous,
                    out var decoded, out pending))
                {
                    state.AwaitingContainer = false;
                    result = default;
                    return false;
                }
'''
assert old in s
s = s.replace(old, new)
p.write_text(s, encoding='utf-8', newline='\n')
print('Private two-file scalar migration applied; original parser/admission algorithms retained.')
