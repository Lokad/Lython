from pathlib import Path
import gzip, hashlib, json, os, shutil, subprocess, tarfile
r = Path(__file__).parent
root = Path('D:/code/Lython')
work = root / '.git/agent-worktrees/json-scalars-r492'
previous = r.parent / 'call-cost-gate-r488'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
prior = json.loads((previous / 'main-frozen-identity.json').read_text(encoding='utf-8'))
files = prior['imageFiles']
source_names = json.loads((previous / 'frozen/identity.json').read_text(encoding='utf-8'))['sourceInputs']
assert len(files) == 32
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=work, text=True).strip().startswith('6aa0fcd2')
changed = subprocess.check_output(['git', 'diff', '--name-only'], cwd=work, text=True).splitlines()
assert changed == ['src/Lokad.Lython/Runtime/LythonRuntime.Json.Construction.cs', 'src/Lokad.Lython/Runtime/LythonRuntime.Json.Deserialize.cs'], changed
shutil.copyfile(previous / 'checkpoint-catalog.json', r / 'catalog.json')
frozen = r / 'frozen'
frozen.mkdir(exist_ok=False)
for role in ['reference', 'candidate']:
    image = frozen / role
    image.mkdir()
    for name, h in files.items():
        assert sha(previous / 'main-frozen' / name) == h
        shutil.copyfile(previous / 'main-frozen' / name, image / name)
    for p in (previous / 'main-frozen').glob('ValidatedAllocation.*'):
        shutil.copyfile(p, image / p.name)
    if role == 'candidate':
        shutil.copyfile(work / 'src/Lokad.Lython/bin/Release/net11.0/Lokad.Lython.dll', image / 'Lokad.Lython.dll')
images = {role: {name: sha(frozen/role/name) for name in files} for role in ['reference', 'candidate']}
assert [n for n in files if images['reference'][n] != images['candidate'][n]] == ['Lokad.Lython.dll']
inputs = {name: sha(work/name) for name in source_names}
with tarfile.open(r / 'candidate-sources.tar.xz', 'w:xz') as archive:
    for name in inputs: archive.add(work/name, arcname=name)
patch = subprocess.check_output(['git', 'diff', '--'] + changed, cwd=work)
(r / 'prototype.patch.gz').write_bytes(gzip.compress(patch, mtime=0))
identity = dict(referenceSource='Fully qualified557381fe/d739132f; GREEN44116196658', candidateSource='PrivateR492 scalar JSON direct construction on6aa0fcd2; no promotion', imageFiles=images, sourceInputs=inputs, productionFiles=585, changedProductionFiles=changed, catalogSHA256=sha(r/'catalog.json'), normalAdapterPin='0.4.0', publicationHeld=True)
(frozen / 'identity.json').write_text(json.dumps(identity, indent=2)+'\n', encoding='utf-8', newline='\n')
dotnet = Path('C:/Users/JoannesVermorel/.dotnet11/dotnet.exe')
env = os.environ.copy()
env.update(DOTNET_ROOT=str(dotnet.parent), DOTNET_ROOT_X64=str(dotnet.parent))
env['PATH'] = str(dotnet.parent)+os.pathsep+env['PATH']
shutil.copyfile(previous / 'main-preflight.json', r / 'reference-preflight-reused.json')
for role in ['reference', 'candidate']:
    image = frozen / role
    commands = []
    if role == 'candidate':
        commands.append(('preflight', [str(dotnet), str(image/'Lokad.Lython.Benchmarks.dll'), '--compare', 'verify', '--catalog', str(r/'catalog.json'), '--dotnet', str(dotnet), '--python', 'C:/Python313/python.exe', '--python-worker', str(root/'benchmarks/cpython-worker.py'), '--out', str(r/'candidate-preflight.json')]))
    commands.append(('allocation', [str(dotnet), str(image/'ValidatedAllocation.dll'), str(image), str(r/'catalog.json'), str(r/(role+'-allocation.json'))]))
    for label, command in commands:
        with (r / (role+'-'+label+'.log')).open('w', encoding='utf-8') as log:
            p = subprocess.run(command, env=env, stdout=log, stderr=subprocess.STDOUT)
        assert p.returncode == 0, (r/(role+'-'+label+'.log')).read_text(encoding='utf-8')
        print(role, label, 'pass', flush=True)
print('Five actual candidate-worker goldens and both allocation/budget reuse checks complete;', images['candidate']['Lokad.Lython.dll'], flush=True)
