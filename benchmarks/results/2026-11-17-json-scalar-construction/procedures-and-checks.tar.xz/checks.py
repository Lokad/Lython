from pathlib import Path
import json, os, subprocess, time
r = Path(__file__).parent
work = Path('D:/code/Lython/.git/agent-worktrees/json-scalars-r492')
dotnet = Path('C:/Users/JoannesVermorel/.dotnet11/dotnet.exe')
env = os.environ.copy()
env.update(DOTNET_ROOT=str(dotnet.parent), DOTNET_ROOT_X64=str(dotnet.parent))
env['PATH'] = str(dotnet.parent) + os.pathsep + env['PATH']
records = []
for framework in ['net11.0', 'net10.0']:
    for label, project in [('internal', 'Lokad.Lython.Tests'), ('public', 'Lokad.Lython.PublicApi.Tests')]:
        name = label + '-' + framework
        filt = '(FullyQualifiedName~Json|FullyQualifiedName~BuiltinCancellationTests|FullyQualifiedName~AdmissionFailureCommandTests)&Category!=Stress'
        command = [str(dotnet), 'test', f'tests/{project}/{project}.csproj', '-c', 'Release', '-f', framework, '--no-build', '--filter', filt, '--logger', 'console;verbosity=minimal']
        start = time.monotonic()
        with (r / (name + '.log')).open('w', encoding='utf-8') as log:
            p = subprocess.run(command, cwd=work, env=env, stdout=log, stderr=subprocess.STDOUT)
        records.append(dict(name=name, command=command, exitCode=p.returncode, seconds=time.monotonic()-start))
        (r / 'checks.json').write_text(json.dumps(records, indent=2)+'\n', encoding='utf-8', newline='\n')
        output = (r / (name + '.log')).read_text(encoding='utf-8')
        print(name, output.splitlines()[-1], flush=True)
        assert p.returncode == 0, output[-5000:]
