from pathlib import Path
import gzip, hashlib, json, shutil, subprocess, tarfile
r=Path(__file__).parent;root=Path('D:/code/Lython');dest=root/'benchmarks/results/2026-11-17-json-scalar-construction'
assert json.loads((r/'confirm/quiet/archive-receipt.json').read_text(encoding='utf-8'))['complete']
candidate=json.loads((r/'frozen/identity.json').read_text(encoding='utf-8'))
with tarfile.open(r/'candidate-sources.tar.xz')as archive:
 for name in candidate['sourceInputs']:
  if not name.startswith('src/Lokad.Lython/'):continue
  content=archive.extractfile(name).read().decode('utf-8-sig').replace('\r\n','\n')
  if name in candidate['changedProductionFiles']:(root/name).write_text(content,encoding='utf-8',newline='\n')
  assert(root/name).read_text(encoding='utf-8-sig')==content,name
confirmation=dest/'confirmation';confirmation.mkdir(exist_ok=False)
for name in ['summary.json','allocation-summary.json']:shutil.copyfile(r/'confirm'/name,confirmation/name)
for name in ['observations.tgz','archive-receipt.json','terminal-status.json','identity.json']:shutil.copyfile(r/'confirm/quiet'/name,confirmation/name)
decision=dict(retained=True,mechanism='Direct scalar parsing into iterative JSON construction; two displaced helpers/default ValueTask repackaging removed. Actual hooks retain real async completion.',allocationReductionEstablished=False,accountedPeaksUnchanged=True,sharedBudgetBaselinesRestored=True,firstWarmFloatingReferenceSpreadPercent=9.309434999698919,confirmedWarmFloatingUncertain=True,confirmedFloatingFreshElapsedChangePercent=[-6.192300166341069,-3.620936812328679],confirmedHelperWarmRegressionPercent=[1.2787685320766462,1.4892642188382155],regressionDebt='Accept confirmed helper+1.3..1.5% for simpler shared scalar path and favorable floating fresh observation. Warm floating magnitude unresolved. Reassess if next representative redesign/checkpoint reproduces/materially increases adversity; no claim of broad or substantial CPU gain.',fullDeliveryPending=True,publicationHeld=True,broaderPerformanceObjectiveActive=True)
(dest/'decision.json').write_text(json.dumps(decision,indent=2)+'\n',encoding='utf-8',newline='\n')
p=dest/'README.md';s=p.read_text(encoding='utf-8').replace('**Private prototype; retention undecided.**','**Retained simplification; full changed-source delivery pending.**')
s+='''
## B911 confirmation and retention

Same32file images/five-case catalog; eight-second rotated warmups/five rounds,
four jobs188.23seconds. No source tuning, forced GC or new allocation measurements.

| Complete script | Phase | Elapsed change | Wider CPU change | Reference/candidate process spread |
| --- | --- | ---: | ---: | ---: |
| Floating numerical JSON report | Warm | −5.50..+8.49% | −4.21..+7.82% | **7.45/6.85**% |
| Same | Compile and execute once | **−6.19..−3.62%** | **−6.10..−4.44%** | 2.22/0.51% |
| JSON-lines helper aggregation | Warm | **+1.28..+1.49%** | **+0.71..+2.00%** | 0.10/0.10% |
| Unchanged positional-call control | Warm | −2.03..+0.28% | −2.02..−0.40% | 2.16/0.19% |

Retain the simpler shared scalar path: no extra parser, cache, policy or owner,
with a favorable floating fresh observation. Accept the stable helper regression
as explicit debt; warm floating remains inconclusive despite longer warmup.
Allocation effectivelyflat; no broad/substantial CPU gain established. This is a
design tradeoff, not a percentage veto or uncertainty relabeled as failure.
Reassess debt with later representative work; no further unchanged campaign is
needed for this decision. Larger execution/operand improvements remain active.

Confirmation staging first refused below the254MiB floor before mutation/work;
repair used fresh exact committed first-pair archive and raw-JSON replica proofs,
including all inode aliases. Earlier preparation named already removed RAM files
and failed read-only. Original failed conditions remain in procedures. Latest
qualifiedd739/candidate images, primary catalog/toolchains/canonical evidence
preserved. Both collections pass all gates/users joined/SHAarchive before RAM
removal; terminal states cached. Publication remains held.

[Confirmation](confirmation/summary.json),[raw](confirmation/observations.tgz),
[decision/debt](decision.json). Full platform/stress/installed-package delivery is
pending; no unchanged qualification was repeated.
'''
p.write_text(s,encoding='utf-8',newline='\n')
with tarfile.open(dest/'confirmation-procedures.tar.xz','w:xz')as archive:
 for p in sorted(r.rglob('*')):
  if not p.is_file():continue
  n=p.relative_to(r)
  if {'retrieved','frozen','candidate'}&set(n.parts)or n.name in ['payload.tgz','observations.tgz','candidate-sources.tar.xz']:continue
  archive.add(p,arcname=n.as_posix())
p=root/'benchmarks/EXPERIMENTS.md'
with p.open('a',encoding='utf-8',newline='\n')as log:
 log.write('\nR492/B911 [unchanged-image confirmation](results/2026-11-17-json-scalar-construction/README.md): four jobs188.23s/8secondwarmups. Floatingwarm−5.50..+8.49% remains uncertain with7.45/6.85%controls; fresh−6.19..−3.62%/CPU−6.10..−4.44%; helperwarm+1.28..+1.49%/CPU+0.71..+2.00%with0.10/0.10%controls. Retain simpler two-file scalar path, accept stable helper debt, do not claim substantial/broad CPU or allocation gain. Full qualification next; all original adversity/pre-mutation staging failures preserved. All usersjoined/RAMSHAarchive gates pass. Larger roadmap active, publicationheld.\n')
print('Two production files retained and all585production texts verified against measured source; helper regression/warm uncertainty explicit, full delivery pending.')
