from pathlib import Path
import hashlib, io, json, shutil, subprocess, tarfile
r=Path(__file__).parent;q=r/'confirm/quiet';root=Path('D:/code/Lython')
for name in ['config.json','remote-launch.py','launch.log']:
 shutil.copyfile(q/name,q/('floor-first-'+name))
canonical='benchmarks/results/2026-11-17-json-scalar-construction/first/observations.tgz'
blob=subprocess.check_output(['git','show','HEAD:'+canonical],cwd=root);assert blob==(root/canonical).read_bytes()
with tarfile.open(fileobj=io.BytesIO(blob))as archive:
 member='confirmation/confirmation.json';data=archive.extractfile(member).read()
subject=dict(path='json-scalars-b910-20261117/'+member,bytes=len(data),sha256=hashlib.sha256(data).hexdigest(),canonical=canonical,canonicalSHA256=hashlib.sha256(blob).hexdigest(),member=member,committedBlobVerified=True)
s=(r/'prepare-confirmation.py').read_text(encoding='utf-8');a=s.index("code='''")+len("code='''");b=s.index("'''.replace",a);code=s[a:b].replace('SUBJECTS',repr([subject]))
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
p=subprocess.run(ssh+['python3 -'],input=code,text=True,encoding='utf-8',capture_output=True,timeout=60);assert p.returncode==0,p.stdout+p.stderr
groups=json.loads(p.stdout);c=json.loads((q/'config.json').read_text(encoding='utf-8'));c['retireGroups']+=groups
(q/'config.json').write_text(json.dumps(c,indent=2)+'\n',encoding='utf-8',newline='\n')
s=(q/'remote-launch.py').read_text(encoding='utf-8');a=s.index('c=');b=s.index('\nb=Path(',a);s=s[:a]+'c='+repr(c)+s[b:];(q/'remote-launch.py').write_text(s,encoding='utf-8',newline='\n')
(q/'launch.log').rename(q/'floor-refusal.log')
print('Fresh exact committed raw JSON replica proof adds',subject['bytes'],'bytes; prior floor refusal preserved, no measured work had begun.')
