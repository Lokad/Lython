from pathlib import Path
import ast, hashlib, io, json, subprocess, tarfile
r=Path(__file__).parent;old=r/'quiet';parent=r/'confirm';parent.mkdir(exist_ok=True);q=parent/'quiet';q.mkdir(exist_ok=True);assert not list(q.iterdir())
root=Path('D:/code/Lython')
prior=json.loads((old/'config.json').read_text(encoding='utf-8'))
receipt=json.loads((old/'archive-receipt.json').read_text(encoding='utf-8'));assert receipt['complete']and receipt['jobs']==4 and receipt['allWorkersJoined']and receipt['guestFixturesRemoved']
canonical='benchmarks/results/2026-11-17-json-scalar-construction/first/observations.tgz'
blob=subprocess.check_output(['git','show','HEAD:'+canonical],cwd=root);assert blob==(root/canonical).read_bytes()
subjects=[dict(path='json-scalars-b910-20261117/observations.tgz',bytes=len(blob),sha256=hashlib.sha256(blob).hexdigest(),canonical=canonical,canonicalSHA256=hashlib.sha256(blob).hexdigest(),member='whole-archive',committedBlobVerified=True)]
code='''from pathlib import Path
import fcntl,hashlib,json,os,stat,subprocess
b=Path('/home/lokad/lython-bench-checks');subjects=SUBJECTS
with(b/'comparison-vm.lock').open('a')as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 workers=subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record|[p]ython3.*cpython-worker.py'],capture_output=True,text=True).stdout
 own={str(os.getpid()),str(os.getppid())};assert all(line.split(maxsplit=1)[0]in own for line in workers.splitlines()),workers
 assert not any(os.path.ismount(p)for p in b.glob('*/guest-fixtures'))
 proofs=[]
 for item in subjects:
  p=b/item['path'];m=p.lstat()
  assert p.resolve()==p and p.is_relative_to(b)and stat.S_ISREG(m.st_mode)and m.st_uid==os.getuid()and m.st_size==item['bytes']and hashlib.sha256(p.read_bytes()).hexdigest()==item['sha256']
  aliases=[]
  for base,dirs,names in os.walk(b):
   for name in names:
    target=Path(base)/name;v=target.lstat()
    if(v.st_dev,v.st_ino)==(m.st_dev,m.st_ino):aliases.append(str(target.relative_to(b)))
  assert len(aliases)==m.st_nlink
  proofs.append(item|dict(paths=aliases,links=m.st_nlink))
 print(json.dumps(proofs))
'''.replace('SUBJECTS',repr(subjects))
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
p=subprocess.run(ssh+['python3 -'],input=code,text=True,encoding='utf-8',capture_output=True,timeout=60);assert p.returncode==0,p.stdout+p.stderr
groups=json.loads(p.stdout)
(q/'retirement-proofs.json').write_text(json.dumps(groups,indent=2)+'\n',encoding='utf-8',newline='\n')
remote='/home/lokad/lython-bench-checks/json-scalar-confirm-b911-20261117'
identity=dict(prior['identity']);identity['purpose']='Bounded confirmation of unchanged R492 images/catalog; first floating reference spread9.31%, helper candidate6.21%, fresh candidate3.58%. Four same affected/control jobs;8second rotated warmups instead of6, five rounds. Preserve every first adverse observation. No source change or promotion.'
(q/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8',newline='\n')
s=(old/'collect.py').read_text(encoding='utf-8').replace('while min(warmed)<6:', 'while min(warmed)<8:').replace('if warmed[i]>=6:continue','if warmed[i]>=8:continue')
assert s!=(old/'collect.py').read_text(encoding='utf-8')
(q/'collect.py').write_text(s,encoding='utf-8',newline='\n')
(q/'archive-owned.py').write_text((old/'archive-owned.py').read_text(encoding='utf-8'),encoding='utf-8',newline='\n')
(q/'run.sh').write_text((old/'run.sh').read_text(encoding='utf-8').replace(prior['root'],remote),encoding='utf-8',newline='\n')
names=['identity.json','collect.py','archive-owned.py','run.sh']
with tarfile.open(q/'payload.tgz','w:gz')as archive:
 for name in names:archive.add(q/name,arcname=name)
c=dict(root=remote,unit='lython-b911-json-scalar-confirm-20261117',source=prior['root'],sourceRole='reference',sourceFiles=identity['imageFiles']['reference'],sourceCatalogSHA256=prior['catalogSHA256'],catalogSHA256=prior['catalogSHA256'],identity=identity,retireGroups=groups,payloadBytes=(q/'payload.tgz').stat().st_size,payloadSHA256=hashlib.sha256((q/'payload.tgz').read_bytes()).hexdigest(),unpackedBytes=sum((q/name).stat().st_size for name in names))
(q/'config.json').write_text(json.dumps(c,indent=2)+'\n',encoding='utf-8',newline='\n')
s=(old/'remote-launch.py').read_text(encoding='utf-8');a=s.index('c=');b=s.index('\nb=Path(',a);s=s[:a]+'c='+repr(c)+s[b:]
needle=" for n,h in c['sourceFiles'].items():assert sha(source/c['sourceRole']/n)==h,n";assert needle in s
s=s.replace(needle," for role,files in c['identity']['imageFiles'].items():\n  for n,h in files.items():assert sha(source/role/n)==h,(role,n)")
needle="if not p.exists():os.link(source/c['sourceRole']/n,p)";assert needle in s;s=s.replace(needle,"if not p.exists():os.link(source/role/n,p)")
s=s.replace('lython-b910-fixtures','lython-b911-fixtures')
(q/'remote-launch.py').write_text(s,encoding='utf-8',newline='\n')
s=(r/'launch.py').read_text(encoding='utf-8').replace('seconds=180','seconds=230').replace('before180seconds','before230seconds').replace('Four-job scalar JSON comparison','Four-job unchanged-image confirmation')
(parent/'launch.py').write_text(s,encoding='utf-8',newline='\n')
(q/'retrieve.py').write_text((old/'retrieve.py').read_text(encoding='utf-8').replace('B910','B911'),encoding='utf-8',newline='\n')
s=(r/'summarize.py').read_text(encoding='utf-8').replace("r/'reference-allocation.json'","r.parent/'reference-allocation.json'").replace("r/'candidate-allocation.json'","r.parent/'candidate-allocation.json'")
(parent/'summarize.py').write_text(s,encoding='utf-8',newline='\n')
for p in list(q.glob('*.py'))+list(parent.glob('*.py')):ast.parse(p.read_text(encoding='utf-8'))
print('Four-job unchanged-image8second confirmation prepared; first observations preserved, only exactly committed completed raw replicas eligible for retirement.')
