def run():
    def values():
        try: raise KeyError('inner')
        except KeyError as original:
            try: sum(g)
            except ValueError as error: assert str(error) == 'generator already executing'
            else: assert False
            for i in range(37):
                try: next(g)
                except ValueError as error: assert str(error) == 'generator already executing'
                else: assert False
                try: raise
                except KeyError as error: assert error is original
                yield i
        try: raise
        except ValueError as error: assert str(error) == 'caller'
    g = values()
    try: raise ValueError('caller')
    except ValueError as original:
        assert sum(g) == sum(range(37))
        try: raise
        except ValueError as error: assert error is original
    return 'ok'
print(run())
