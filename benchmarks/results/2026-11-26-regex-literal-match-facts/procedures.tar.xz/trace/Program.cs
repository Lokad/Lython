using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Text.Json;
using Lokad.Lython;
using Lokad.Lython.Utf8Regex;

using var catalog = JsonDocument.Parse(File.ReadAllText(args[0]));
var image = Path.GetFullPath(args[1]);
var fixture = Assembly.LoadFrom(Path.Combine(image, "Lokad.Lython.Benchmarks.dll"));
var hostClass = fixture.GetType("Lokad.Lython.Benchmarks.Comparison.ComparisonHost", true)!;
var rows = new List<object>();
foreach (var specification in catalog.RootElement.GetProperty("cases").EnumerateArray())
{
    var id = specification.GetProperty("id").GetString()!;
    if (!id.StartsWith("diagnostic.regex-subject-", StringComparison.Ordinal) && id != "diagnostic.generated-regex-record-selectors") continue;
    var host = (ILythonHost)Activator.CreateInstance(hostClass, nonPublic: true)!;
    var budget = new LythonMemoryBudget(32 * 1024 * 1024);
    var provider = new TrackingProvider();
    using (var script = new LythonEngine(provider).Compile(specification.GetProperty("source").GetString()!, budget))
    {
        if (!script.IsValid) throw new InvalidDataException(string.Join("\n", script.Diagnostics));
        var retained = budget.ReservedBytes;
        provider.Phase = "run";
        using (var result = script.Run(host))
        {
            if (!result.Success || result.StandardOutput != specification.GetProperty("expectedOutput").GetString())
                throw new InvalidDataException(result.Failure?.Message ?? result.StandardOutput);
        }
        if (retained != budget.ReservedBytes) throw new InvalidDataException("Unexpected execution ownership.");
    }
    if (budget.ReservedBytes != 0) throw new InvalidDataException("Unexpected compiled owner.");
    rows.Add(new { id, provider.Observations, provider.MatchPhases });
}
Console.WriteLine(JsonSerializer.Serialize(new {
    coreSHA256 = Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(typeof(LythonEngine).Assembly.Location))).ToLowerInvariant(),
    rows
}, new JsonSerializerOptions { WriteIndented = true }));

sealed class TrackingProvider : ILythonRegexProvider
{
    public record Observation(string Phase, int Backing, int Length, LythonRegexWindow Window, string[] AnalysisFrames);
    private sealed record BackingId(int Value);
    private readonly ConditionalWeakTable<byte[], BackingId> _backingIds = new();
    private int _nextId;
    internal string Phase = "compile";
    internal List<Observation> Observations { get; } = [];
    internal List<string> MatchPhases { get; } = [];

    public ILythonRegexPattern Compile(ReadOnlyMemory<byte> pattern, LythonRegexOptions options,
        ILythonMemoryBudget owner, CancellationToken token)
        => new Pattern(this, Utf8RegexProvider.Instance.Compile(pattern, options, owner, token));

    private sealed class Pattern(TrackingProvider trace, ILythonRegexPattern inner) : ILythonRegexPattern
    {
        public int Flags => inner.Flags;
        public int CaptureSlotCount => inner.CaptureSlotCount;
        public IReadOnlyList<LythonRegexNamedGroup> NamedGroups => inner.NamedGroups;
        public ReadOnlyMemory<byte>? ProgramEqualityKey => inner.ProgramEqualityKey;
        public ILythonRegexSubject Prepare(ReadOnlyMemory<byte> subject, LythonRegexWindow window,
            ILythonMemoryBudget owner, CancellationToken token)
        {
            if (!MemoryMarshal.TryGetArray(subject, out var segment) || segment.Array is null)
                throw new InvalidDataException("Trace requires array-backed input.");
            // Keep only the identity number. The witness never owns the borrow.
            var identity = trace._backingIds.GetValue(segment.Array, _ => new(++trace._nextId)).Value;
            var methods = new System.Diagnostics.StackTrace().GetFrames().Select(frame => frame.GetMethod()).Where(method => method?.DeclaringType?.Namespace == "Lokad.Lython.Frontend").Select(method => method!.DeclaringType!.Name + "." + method.Name).ToArray();
            trace.Observations.Add(new(trace.Phase, identity, subject.Length, window, methods));
            return new Subject(trace, inner.Prepare(subject, window, owner, token));
        }
        public void Dispose() => inner.Dispose();
    }
    private sealed class Subject(TrackingProvider trace, ILythonRegexSubject inner) : ILythonRegexSubject
    {
        public bool TryMatch(LythonRegexMatchMode mode, Span<LythonRegexCapture?> captures, out int? lastIndex, CancellationToken token)
        {
            trace.MatchPhases.Add(trace.Phase);
            return inner.TryMatch(mode, captures, out lastIndex, token);
        }
        public ILythonRegexCursor Find(CancellationToken token) => inner.Find(token);
        public void Dispose() => inner.Dispose();
    }
}
