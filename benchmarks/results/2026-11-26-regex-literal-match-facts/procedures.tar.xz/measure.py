from pathlib import Path
from statistics import median
import json,os,shutil,subprocess,hashlib

lab=Path(__file__).resolve().parent
sdk=Path.home()/'.dotnet11'
env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk))
dotnet=sdk/'dotnet.exe'
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
roles={}
for name in ('reference','prototype'):
 image=lab/f'peak-{name}'
 image.mkdir(exist_ok=True)
 for file in (lab/'measure/bin/Release/net11.0').iterdir():shutil.copyfile(file,image/file.name)
 core=lab/f'{name}-measure/Lokad.Lython.dll'
 shutil.copyfile(core,image/core.name)
 roles[name]=[image,sha(core)]
points=[]
for order in [('reference','prototype'),('prototype','reference'),('reference','prototype')]:
 for role in order:
  image,core=roles[role]
  result=subprocess.run([dotnet,image/'SubjectTrace.dll',lab/'measure-catalog.json'],env=env,timeout=45,encoding='utf-8',capture_output=True)
  with (lab/'peak-observations.jsonl').open('a',encoding='utf-8') as output:
   print(json.dumps(dict(role=role,code=result.returncode,output=result.stdout,error=result.stderr)),file=output)
  result.check_returncode()
  row=json.loads(result.stdout)
  assert row['coreSHA256']==core
  points.append((role,row))
for index, row in enumerate(points[0][1]['rows']):
 print(row['id'])
 for role in roles:
  values=[(v['frequency'],v['rows'][index]) for name,v in points if name==role]
  assert all(item['id']==row['id'] for _,item in values)
  print(role,[int(median(d['samples'])) for _,d in values],[d['peakAdmission'] for _,d in values],
        [round(1000*median(d['elapsed'])/frequency,3) for frequency,d in values])
