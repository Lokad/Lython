from hashlib import sha256
from pathlib import Path
from shutil import copy2, copytree
from subprocess import check_output
import json
import tarfile

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
previous = lab.parent / 'ownership-cpython-b1963-20261128'
old = previous / 'comparison/quiet'
matched = lab.parent / 'record-comparison-sum-direct-b1973-20261128/comparison'
donor = matched / 'quiet'
quiet = lab / 'comparison/quiet'
core = 'Lokad.Lython.dll'
stage = 'script-cpython-shipment-b1974-20261128'
read = lambda path: json.loads(path.read_bytes())
digest = lambda path: sha256(path.read_bytes()).hexdigest()
hash_image = lambda path: {p.name: digest(p) for p in path.iterdir()}


def save(path, content):
    path.write_text(content, encoding='utf-8', newline='\n')
    assert b'\r' not in path.read_bytes()


def write(path, data):
    save(path, json.dumps(data, indent=2) + '\n')


def git(*args):
    return check_output(['git', *args], cwd=repo)


head = git('rev-parse', 'HEAD').decode().strip()
assert head.startswith('486bad1ee') and not git('status', '--porcelain')
identity = read(donor / 'identity.json')
patch = git('diff', '--binary', identity['referenceRevision'], 'HEAD', '--', 'src', 'tests')
assert sha256(patch).hexdigest() == identity['sourcePatchSHA256']
terminal = read(donor / 'terminal-status.json')
receipt = terminal['receipt']
assert not terminal['live'] and not terminal['fixtures'] and terminal['exitCode'] == '0'
assert receipt['complete'] and receipt['allWorkersJoined'] and receipt['quietBeforeAndAfter']
assert digest(donor / 'observations.tar.xz') == receipt['archiveSHA256']
image = identity['imageFiles']['candidate']
assert len(image) == 32 and hash_image(matched / 'candidate') == image

quiet.mkdir(parents=True)
frozen = quiet / 'local-image'
copytree(matched / 'candidate', frozen)
assert hash_image(frozen) == image
assert all(not p.samefile(matched / 'candidate' / p.name) for p in frozen.iterdir())
assert digest(donor / 'representative.json') == identity['catalogs']['representative.json']['sha256']
catalog = read(donor / 'representative.json')
ids = {'diagnostic.shipment-row-generator-reduction', 'diagnostic.shipment-row-explicit-reduction'}
catalog['cases'] = [case for case in catalog['cases'] if case['id'] in ids]
assert len(catalog['cases']) == 2
write(quiet / 'representative.json', catalog)
copy2(donor / 'cpython-worker.py', quiet / 'cpython-worker.py')
copy2(old / 'run.sh', quiet / 'run.sh')
assert digest(quiet / 'cpython-worker.py') == identity['cpythonWorkerSHA256']
assert b'\r' not in (quiet / 'run.sh').read_bytes()
jobs = [job for job in read(old / 'jobs.json') if job[0] in ids]
assert len(jobs) == 4
write(quiet / 'jobs.json', jobs)
write(quiet / 'identity.json', dict(sourceRevision=head, productionHead=head,
    purpose='Refresh sync, async and compile-to-result for tuple shipment, with the same-file explicit loop.',
    imageFiles={'candidate': image}, coreSHA256={role: image[core] for role in ('candidate', 'candidate-control')},
    auxiliaryFiles={name: checksum for name, checksum in image.items() if name != core},
    frozenImage=f'/home/lokad/lython-bench-checks/{stage}/candidate',
    catalogs={name: {'sha256': digest(quiet / name)} for name in ('representative.json', 'jobs.json')},
    expectedCPythonSHA256=identity['expectedCPythonSHA256'], cpythonWorkerSHA256=identity['cpythonWorkerSHA256'],
    donorArchiveSHA256=receipt['archiveSHA256'], measuredCorePatchSHA256=identity['sourcePatchSHA256']))
collector = (old / 'collect.py').read_text(encoding='utf-8')
assert collector.count('len(jobs) == 7') == collector.count('lython-b1963-cpython-fixtures') == 1
save(quiet / 'collect.py', collector.replace('len(jobs) == 7', 'len(jobs) == 4')
     .replace('lython-b1963-cpython-fixtures', 'lython-b1974-shipment-fixtures'))
paths = {name: quiet / name for name in ('identity.json', 'representative.json', 'jobs.json',
    'cpython-worker.py', 'run.sh', 'collect.py')}
payload = quiet / 'stage.tar.gz'
with tarfile.open(payload, 'w:gz') as archive:
    for name, path in paths.items():
        archive.add(path, arcname=name)
with tarfile.open(payload) as archive:
    assert all(sha256(archive.extractfile(name).read()).hexdigest() == digest(path) for name, path in paths.items())
manifest = {name: dict(length=path.stat().st_size, sha256=digest(path)) for name, path in paths.items()}
write(quiet / 'upload.json', dict(root=stage, donor=read(donor / 'upload.json')['root'], donorFiles=image,
    donorArchive=receipt['archiveSHA256'], payloadSHA256=digest(payload), files=manifest,
    expandedBytes=sum(row['length'] for row in manifest.values()), minimumAfterStageBytes=5*1024*1024, caseCount=2))
launch = (previous / 'quiet-vm.py').read_text(encoding='utf-8')
save(lab / 'quiet-vm.py', launch.replace('lython-b1963-ownership-cpython', 'lython-b1974-shipment-cpython')
     .replace('RuntimeMaxSec=535', 'RuntimeMaxSec=230'))
verify = (previous / 'verify.sh').read_text(encoding='utf-8')
save(lab / 'verify.sh', verify.replace(previous.name, lab.name))
summary = (previous / 'summarize.py').read_text(encoding='utf-8')
save(lab / 'summarize.py', summary.replace('0b50e6fda5f9ac8fa994ee08ca67da306b813a40', head)
     .replace('==7', '==4').replace('==196', '==112').replace('["caseCount"]==5', '["caseCount"]==2')
     .replace('{"donor":31}', '{"donor":32}').replace('16*1024*1024', '5*1024*1024'))
print(head, len(jobs), 'quiet lanes with two expected output and file goldens')