import ast
import gzip
import hashlib
import json
from pathlib import Path
import subprocess

lab = Path(__file__).resolve().parent
prior = lab.parent / 'one-abstract-fact-map-r672'
read = lambda p: p.read_text(encoding='utf-8-sig')
load = lambda p: json.loads(read(p))
stage = read(prior / 'stage-quiet.py')
stage = stage.replace('R672 single branch-state map for abstract facts', 'R673 source coordinates and numeric adjacency during tokenization')
stage = stage.replace('one-abstract-fact-map-b1104', 'token-source-transport-b1105')
stage = stage.replace('b1104-one-abstract-fact-map', 'b1105-token-source-transport').replace('b1104-fixtures','b1105-fixtures')
stage = stage.replace('five-case, six-job', 'five-case, five-job')
stage = stage.replace('len(jobs)==6","len(jobs)==6','len(jobs)==6","len(jobs)==5')
stage = stage.replace('len(raw[\'jobs\'])==6","len(raw[\'jobs\'])==6','len(raw[\'jobs\'])==6","len(raw[\'jobs\'])==5')
stage = stage.replace('jobs=6,","jobs=6,','jobs=6,","jobs=5,')
stage = stage.replace("[\'jobs\']==6\",\"[\'jobs\']==6", "[\'jobs\']==6\",\"[\'jobs\']==5")
stage = stage.replace('.replace("==6","==6")', '.replace("==6","==5")').replace('347','296')
stage = stage.replace('Single abstract-fact map source pair','Source coordinates and numeric adjacency source pair')
marker = 'collector = read(quiet'
a = stage.index(marker)
stage = stage[:a] + stage[a:].replace('==6', '==5').replace('jobs=6,','jobs=5,')
jobs = [
    ('scripts.config-generated-guards.medium', 'compile'),
    ('scripts.config-manifest.small', 'compile'),
    ('scripts.config-generated-guards.medium', 'compile-run'),
    ('scripts.config-manifest.small', 'compile-run'),
    ('scripts.report-render.format-selectors.large', 'warm'),
]
a, b = stage.index('        jobs = '), stage.index('        source=source[:a]')
stage = stage[:a] + "        jobs = " + repr(jobs) + "\n" + stage[b:]
stage = stage.replace('}) == 4','}) == 3')
assert {case for case,lane in jobs} <= {row['id'] for row in load(lab / 'catalog.json')['cases']}
ast.parse(stage)
(lab / 'stage-quiet.py').write_text(stage, encoding='utf-8', newline='\n')
receipt = load(prior / 'quiet/archive-receipt.json')
assert receipt['complete'] and receipt['archivedAndVerifiedUnderLease']

evidence = 'benchmarks/results/2026-11-19-prepared-integer-prefix'
base = 'prepared-integer-prefix-b1103-20261119'
commit = '1b3f8f6ea'
read_commit = lambda path: subprocess.check_output(['git','show',f'{commit}:{evidence}/{path}'])
core = gzip.decompress(read_commit('measured-core.dll.gz'))
digest = hashlib.sha256(core).hexdigest()
assert digest == json.loads(read_commit('summary.json'))['cores']['candidate']
assert hashlib.sha256(read_commit('observations.tgz')).hexdigest() == json.loads(read_commit('archive-receipt.json'))['archiveSHA256']
replica = dict(bytes=len(core), links=1, paths=[base+'/candidate/Lokad.Lython.dll'], sha256=digest,
               committedBlobVerified=True, canonicalCommit=commit, canonicalPath=evidence+'/measured-core.dll.gz')
(lab / 'quiet-space.json').write_text(json.dumps(dict(freeBytes=receipt['freeBytesAfterArchive'], replicas=[replica])) + '\n',
                                    encoding='utf-8', newline='\n')
