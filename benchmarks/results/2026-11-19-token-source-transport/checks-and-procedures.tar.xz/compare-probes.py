from pathlib import Path
import hashlib
import json
import os
import shutil
import subprocess

lab = Path(__file__).resolve().parent
sdk = Path.home()/'.dotnet11'
env = dict(os.environ, DOTNET_ROOT=str(sdk), DOTNET_ROOT_X64=str(sdk), PATH=str(sdk)+os.pathsep+os.environ['PATH'])
source = [
    "x = 1name\ny = 2jother\n",
    "x = 0xFG\n",
    "x = 0b01102\n",
    "x = .2jmore\n",
    "print(1in[1, 2])\n",
    "print(1j in [1, 2j])\n",
    "x = 1e-3 name\n",
    "x = 10f'bad'\n",
    "print(f'{2jother}')\n",
    "print(f'{f\"{1x}\"}')\n",
    "x = (2\n  # trailing comment\n",
    "x = '''😀\nseveral\nphysical lines'''\nprint(x)\n",
    "if True:\r\n    value = f'{1 + 2}'\r\n\r\nprint(value)\r\n",
    "if True:\n    value = (1 + \\\n        2)\n\nprint(value)\n",
    "\ufeffprint(1)\n",
    "def f():\n    return f'😀{unknown}'\nf()\n",
    "def f():\n    return f'''line\n{unknown}'''\nf()\n",
    "print((1,\n       2,\n       3))\n",
    "if True:\n    a = 1\n  b = 2\n",
    "if True:\n\ta = 1\n        b = 2\n",
]
(lab/'probes.json').write_text(json.dumps(source,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
inputs = (lab/'probes.json').read_bytes()
driver = Path('tools/LythonProbe/bin/Release/net11.0')
identity = json.loads((lab/'frozen-identity.json').read_text(encoding='utf-8'))['images']
work = lab/'probe'
work.mkdir(exist_ok=True)
digest = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
def all_hashes(path):
    return {entry.name:digest(entry) for entry in path.iterdir() if entry.is_file()}
matches=[]
for role in ('reference','candidate'):
    image = work/role
    image.mkdir(exist_ok=True)
    for entry in driver.iterdir():
        if entry.is_file() and entry.suffix != '.pdb': shutil.copyfile(entry,image/entry.name)
    for name in ['Lokad.Lython.dll','Lokad.Lython.Utf8Regex.dll','Lokad.Utf8Regex.dll','Lokad.Utf8Regex.PythonRe.dll']:
        shutil.copyfile(lab/'frozen'/role/name, image/name)
        assert digest(image/name)==identity[role][name]
common=all_hashes(work/'reference')
assert common | {'Lokad.Lython.dll':identity['candidate']['Lokad.Lython.dll']} == all_hashes(work/'candidate')
for mode in ('sync','async'):
    results=[]
    for role in ('reference','candidate'):
        args=[sdk/'dotnet.exe',work/role/'LythonProbe.dll','--batch-json']+(['--async'] if mode=='async' else [])
        completed=subprocess.run(args,env=env,input=inputs,capture_output=True,timeout=60)
        (lab/f'probe-{role}-{mode}.jsonl').write_bytes(completed.stdout)
        (lab/f'probe-{role}-{mode}.stderr').write_bytes(completed.stderr)
        records=[json.loads(line) for line in completed.stdout.decode('utf-8-sig').splitlines()]
        assert len(records)==len(source), (role, mode, completed.returncode, completed.stderr)
        results.append([record['Lython'] for record in records])
    assert results[0]==results[1], [i for i,pair in enumerate(zip(*results)) if pair[0]!=pair[1]]
    matches.append(dict(mode=mode, matching=len(source)))
(lab/'probe-summary.json').write_text(json.dumps(dict(results=matches, referenceImage=common),indent=2)+'\n',encoding='utf-8',newline='\n')
print(matches)
