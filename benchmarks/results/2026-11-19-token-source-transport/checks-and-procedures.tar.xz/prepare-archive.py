from pathlib import Path

lab = Path(__file__).resolve().parent
read = lambda p: p.read_text(encoding='utf-8-sig')
old = read(lab.parent / 'one-abstract-fact-map-r672/archive.py')
old = old.replace('2026-11-19-one-abstract-fact-map','2026-11-19-token-source-transport')
old = old.replace("verify('quiet', 6,", "verify('quiet', 5,").replace('Verified 120 batches','Verified 100 batches')
old = old.replace("'local-targets.json', 'local-pair.log',", "'ubuntu-net10.log', 'local-pair.log',")
(lab / 'archive.py').write_text(old, encoding='utf-8', newline='\n')
(lab / 'measure-compile-allocation.py').write_bytes((lab.parent / 'prepared-integer-prefix-r671' / 'measure-compile-allocation.py').read_bytes())
