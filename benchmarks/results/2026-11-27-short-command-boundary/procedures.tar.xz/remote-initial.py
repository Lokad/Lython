from base64 import b64encode
from datetime import datetime, timezone
from hashlib import sha256
from pathlib import Path
import io, json, os, subprocess, sys, tarfile

lab=Path(__file__).resolve().parent
run=lab/'local'
remote='/home/lokad/lython-bench-checks'
name='short-command-boundary-b1827-20261127'
unit='lython-b1827-short-command-boundary-20261127'
vm=os.environ['LYTHON_BENCH_HOST']
args=['-i',os.environ['LYTHON_BENCH_IDENTITY'],'-o','BatchMode=yes','-o','ConnectTimeout=12']
names=['identity.json','jobs.json','representative.json','collect.py','run.sh','cpython-worker.py','cpython-phases.py',
       'instrumented/Lokad.Lython.Benchmarks.dll']
source=lab.with_name('compiled-prefix-search-20261126')/'comparison/quiet'
previous=json.loads((source/'terminal-status.json').read_text(encoding='utf-8'))
config={'base':remote,'name':name,'unit':unit,'previousArchiveSHA256':previous['receipt']['archiveSHA256'],
        'expandedBytes':sum((run/path).stat().st_size for path in names), 'minimumAfterStage':4_150_000}
prefix='cfg='+repr(config)+"""
from pathlib import Path
from hashlib import sha256
from base64 import b64decode
import fcntl, io, json, os, shutil, subprocess, tarfile
base=Path(cfg['base'])
root=base/cfg['name']
unit=cfg['unit']
assert root.parent==base and root.resolve()==root and base.resolve()==base
digest=lambda p:sha256(p.read_bytes()).hexdigest()
"""
def ssh(code):
    return subprocess.check_output(['ssh',*args,vm,'python3 -'],input=prefix+code,encoding='utf-8',timeout=90)
if sys.argv[1]=='launch':
    image=io.BytesIO()
    with tarfile.open(fileobj=image,mode='w:gz') as bundle:
        for path in names: bundle.add(run/path,arcname=path,recursive=False)
    payload=b64encode(image.getvalue()).decode('ascii')
    payload_hash=sha256(image.getvalue()).hexdigest()
    stage='encoded='+repr(payload)+'\nexpected='+repr(payload_hash)+'\nrequired='+repr(names)+'''
with (base/'comparison-vm.lock').open('a') as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 raw=b64decode(encoded)
 assert sha256(raw).hexdigest()==expected
 free=shutil.disk_usage(base).free
 assert not root.exists() and free>=cfg['expandedBytes']+cfg['minimumAfterStage'],free
 donor=base/'compiled-prefix-cpython-b1815-20261127'
 previous=json.loads((donor/'archive-receipt.json').read_text(encoding='utf-8'))
 assert previous['complete'] and previous['allWorkersJoined']
 assert previous['archiveSHA256']==cfg['previousArchiveSHA256']==digest(donor/'observations.tar.xz')
 origin=donor/'candidate'
 assert origin.resolve()==origin
 with tarfile.open(fileobj=io.BytesIO(raw),mode='r:gz') as bundle:
  frames=bundle.getmembers()
  assert len(frames)==len(required) and set(required)=={f.name for f in frames} and all(f.isfile() for f in frames)
  assert sum(f.size for f in frames)==cfg['expandedBytes']
  root.mkdir()
  bundle.extractall(root,filter='data')
 identity=json.loads((root/'identity.json').read_text(encoding='utf-8'))
 control=identity['imageFiles']['control']
 assert len(control)==32 and {p.name:digest(p) for p in origin.iterdir()}==control
 (root/'control').mkdir()
 for role,expected in identity['imageFiles'].items():
  image=root/role
  for name,sha in expected.items():
   path=image/name
   if not path.exists():
    assert sha==control[name]
    os.link(origin/name,path)
  assert {p.name:digest(p) for p in image.iterdir()}==expected
 for path,digest_expected in (identity['pythonWorkers']|identity['catalogs']).items():
  assert digest(root/path)==digest_expected
 assert b'\r' not in (root/'run.sh').read_bytes()
 python=Path.home()/'lython-bench-toolchains/cpython/3.13.16/bin/python3.13'
 dotnet=Path.home()/'lython-bench-toolchains/dotnet/11.0.100-rc.3.26522.148/dotnet'
 assert digest(python)==identity['expectedVMCPythonSHA256']
 for role,adapter in [('control','cpython-worker.py'),('instrumented','cpython-phases.py')]:
  receipt=root/f'{role}-vm-verify.json'
  subprocess.run([dotnet,root/role/'Lokad.Lython.Benchmarks.dll','--compare','verify',
      '--catalog',root/'representative.json','--dotnet',dotnet,'--python',python,
      '--python-worker',root/adapter,'--out',receipt],
      env=dict(os.environ,DOTNET_ROOT=str(dotnet.parent)),check=True,timeout=25)
  proof=json.loads(receipt.read_text(encoding='utf-8'))
  assert proof['state']=='Completed' and proof['caseCount']==3
  assert proof['catalogSha256']==identity['catalogs']['representative.json']
  assert proof['launched']['library']['sha256']==control['Lokad.Lython.dll']
 print(json.dumps({'freeBeforeStage':free,'freeAfterStage':shutil.disk_usage(base).free,'expandedBytes':cfg['expandedBytes']}),flush=True)
subprocess.run(['sudo','-n','systemd-run','--unit='+unit,'--property=User=lokad',
 '--property=WorkingDirectory='+str(root),'--property=RuntimeMaxSec=245',
 '--property=TimeoutStopSec=20','--property=KillMode=control-group','/bin/sh',str(root/'run.sh')],check=True)
'''
    result=ssh(stage)
    (lab/'launch.log').write_text(result,encoding='utf-8',newline='\n')
    print(result)
else:
    assert sys.argv[1]=='retrieve'
    result=json.loads(ssh("""
service=subprocess.run(['systemctl','show',unit+'.service','--property=ActiveState,SubState,MainPID,Result,ExecMainStatus'],
                       check=False,capture_output=True,text=True).stdout
if 'ActiveState=active' in service:
 print(json.dumps({'live':True,'service':service}))
else:
 with (base/'comparison-vm.lock').open('a') as lease:
  fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
  receipt=root/'archive-receipt.json'
  code=root/'exit-code.txt'
  print(json.dumps({'live':False,'service':service,'exitCode':code.read_text().strip() if code.exists() else None,
   'receipt':json.loads(receipt.read_text()) if receipt.exists() else None,'guestFixturesRemain':(root/'guest-fixtures').exists(),
   'journal':subprocess.run(['journalctl','-u',unit+'.service','-n','36','--no-pager'],capture_output=True,text=True).stdout}))
"""))
    p=lab/f"status-{datetime.now(timezone.utc):%H%M%S}.json"
    p.write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8',newline='\n')
    if not result['live'] and result['receipt']:
        retrieved=lab/'retrieved'
        retrieved.mkdir(exist_ok=True)
        for item in ('observations.tar.xz','control-vm-verify.json','instrumented-vm-verify.json'):
            subprocess.run(['scp',*args,f'{vm}:{remote}/{name}/{item}',retrieved/item],check=True,timeout=60)
        assert sha256((retrieved/'observations.tar.xz').read_bytes()).hexdigest()==result['receipt']['archiveSHA256']
        (retrieved/'terminal-status.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8',newline='\n')
    print(json.dumps(result,indent=2))
