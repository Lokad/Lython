from pathlib import Path
from hashlib import sha256
import json, os, shutil, subprocess, difflib

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
frozen=lab.with_name('compiled-prefix-search-20261126')
profile=lab.with_name('current-short-script-profile-20261127')/'comparison/quiet'
run=lab/'local'
run.mkdir()
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
def digest(p): return sha256(p.read_bytes()).hexdigest()
def write(p,t): p.write_text(t,encoding='utf-8',newline='\n')
def replace(t,a,b):
    assert t.count(a)==1, a
    return t.replace(a,b)
def patch(old,new,name):
    return ''.join(difflib.unified_diff(old.splitlines(keepends=True),new.splitlines(keepends=True),
        'a/'+name,'b/'+name))
source=read(frozen/'comparison/quiet/identity.json')
origin=frozen/'corrected/candidate'
files=source['imageFiles']['candidate']
assert len(files)==32 and {p.name:digest(p) for p in origin.iterdir()}==files
assert not subprocess.check_output(['git','diff',source['productionSource'],'HEAD','--','benchmarks/Lokad.Lython.Benchmarks','benchmarks/cpython-worker.py'],cwd=repo)
shutil.copytree(origin,run/'control')
shutil.copytree(origin,run/'instrumented')
benchmark=repo/'benchmarks/Lokad.Lython.Benchmarks'
worker=benchmark/'Comparison/LythonComparisonWorker.cs'
original=worker.read_bytes()
text=worker.read_text(encoding='utf-8')
changes=(
    ('private long _fixtureResetTicks;', 'private long _fixtureResetTicks;\n    private long _executionTicks;\n    private long _verificationTicks;'),
    ('var resetBefore = _fixtureResetTicks;', 'var resetBefore = _fixtureResetTicks;\n        var executionBefore = _executionTicks;\n        var verificationBefore = _verificationTicks;'),
    ('return Response(workload, requestId, "Completed", completed, elapsedTicks, actual);',
     '''return Response(workload, requestId, "Completed", completed, elapsedTicks, actual) with
            {
                PhaseTicks = new(_executionTicks - executionBefore, _verificationTicks - verificationBefore),
            };'''),
    ('        _lastFiles = null;', '        var invokeStarted = Stopwatch.GetTimestamp();\n        var resetBefore = _fixtureResetTicks;\n        _lastFiles = null;'),
    ('_lastResult = result;\n        if (!result.Success)',
     '''_lastResult = result;
        var verifyStarted = Stopwatch.GetTimestamp();
        _executionTicks += verifyStarted - invokeStarted - (_fixtureResetTicks - resetBefore);
        if (!result.Success)'''),
    ('return result.StandardOutput;', '_verificationTicks += Stopwatch.GetTimestamp() - verifyStarted;\n        return result.StandardOutput;'),
    ('string? ActualFilesSha256 = null);', '''string? ActualFilesSha256 = null)
{
    [System.Text.Json.Serialization.JsonIgnore(Condition = System.Text.Json.Serialization.JsonIgnoreCondition.WhenWritingNull)]
    public WorkerPhaseTicks? PhaseTicks { get; init; }
}

internal sealed record WorkerPhaseTicks(long Execution, long Verification);'''),
)
trial=text
for before,after in changes:
    trial=replace(trial,before,after)
write(run/'worker.patch',patch(text,trial,worker.relative_to(repo).as_posix()))
sdk=Path.home()/'.dotnet11'
dotnet=sdk/'dotnet.exe'
env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk))
try:
    write(worker,trial)
    subprocess.run([dotnet,'build',benchmark/'Lokad.Lython.Benchmarks.csproj','-c','Release','-f','net11.0','--no-restore'],
                   cwd=repo,env=env,check=True,timeout=180)
    overlay=benchmark/'bin/Release/net11.0/Lokad.Lython.Benchmarks.dll'
    shutil.copyfile(overlay,run/'instrumented'/overlay.name)
finally:
    worker.write_bytes(original)
assert not subprocess.check_output(['git','diff','--','benchmarks/Lokad.Lython.Benchmarks'],cwd=repo)

python=repo/'benchmarks/cpython-worker.py'
control=python.read_text(encoding='utf-8')
trial=control
parts=(
    ('_fixture_reset_ns = 0', '_fixture_reset_ns = 0\n_execution_ns = 0\n_verification_ns = 0'),
    ('global _fixture_reset_ns\n', 'global _fixture_reset_ns, _execution_ns, _verification_ns\n    invoke_started = time.perf_counter_ns()\n    reset_before = _fixture_reset_ns\n'),
    ("actual = stdout.getvalue()\n    if actual != case['expectedOutput']",
     "actual = stdout.getvalue()\n    verify_started = time.perf_counter_ns()\n    _execution_ns += verify_started - invoke_started - (_fixture_reset_ns - reset_before)\n    if actual != case['expectedOutput']"),
    ('return (actual, read_file_outputs(case, stage)) if stage is not None else actual',
     'verified = (actual, read_file_outputs(case, stage)) if stage is not None else actual\n    _verification_ns += time.perf_counter_ns() - verify_started\n    return verified'),
    ('reset_before = _fixture_reset_ns\n                for _ in range(iterations):',
     'reset_before = _fixture_reset_ns\n                execution_before, verification_before = _execution_ns, _verification_ns\n                for _ in range(iterations):'),
    ('write_frame(output_stream, response(case, request_id, status, completed, elapsed, actual))',
     """reply = response(case, request_id, status, completed, elapsed, actual)
            if operation == 'batch':
                reply['phaseTicks'] = {'execution': _execution_ns - execution_before,
                                       'verification': _verification_ns - verification_before}
            write_frame(output_stream, reply)"""),
)
for before,after in parts:
    trial=replace(trial,before,after)
compile(trial,'cpython-phases.py','exec')
shutil.copyfile(python,run/'cpython-worker.py')
assert digest(run/'cpython-worker.py')==source['cpythonWorkerSHA256']
write(run/'cpython-phases.py',trial)
write(run/'cpython-worker.patch',patch(control,trial,'benchmarks/cpython-worker.py'))
catalog=read(profile/'catalog.json')
early='diagnostic.file-search-first-line'
late='scripts.file-search.large'
config='scripts.config-edit.small'
catalog['cases'] += [x for x in read(frozen/'comparison/quiet/representative.json')['cases'] if x['id']==late]
assert {x['id'] for x in catalog['cases']}=={early,late,config}
write(run/'representative.json',json.dumps(catalog,ensure_ascii=False,indent=2)+'\n')
write(run/'jobs.json',json.dumps([early,config,late],indent=2)+'\n')
images={role:{p.name:digest(p) for p in (run/role).iterdir()} for role in ('control','instrumented')}
assert images['control']==files and [p for p in files if images['instrumented'][p]!=files[p]]==['Lokad.Lython.Benchmarks.dll']
identity=dict(sourceRevision=source['productionSource'],buildRevision=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip(),
              imageFiles=images, pythonWorkers={name:digest(run/name) for name in ('cpython-worker.py','cpython-phases.py')},
              patches={name:digest(run/name) for name in ('worker.patch','cpython-worker.patch')},
              expectedVMCPythonSHA256=source['expectedCPythonSHA256'],
              catalogs={name:digest(run/name) for name in ('representative.json','jobs.json')})
write(run/'identity.json',json.dumps(identity,indent=2)+'\n')
for role, adapter in [('control','cpython-worker.py'),('instrumented','cpython-phases.py')]:
    receipt=run/f'{role}-verify.json'
    subprocess.run([dotnet,run/role/'Lokad.Lython.Benchmarks.dll','--compare','verify','--catalog',run/'representative.json',
        '--dotnet',dotnet,'--python','C:/Python313/python.exe','--python-worker',run/adapter,'--out',receipt],
        cwd=repo,env=env,check=True,timeout=60)
    info=read(receipt)
    assert info['state']=='Completed' and info['caseCount']==3 and info['catalogSha256']==identity['catalogs']['representative.json']
    assert info['launched']['library']['sha256']==files['Lokad.Lython.dll']
