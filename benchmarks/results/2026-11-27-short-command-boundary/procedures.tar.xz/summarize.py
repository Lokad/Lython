from itertools import product
from hashlib import sha256
from pathlib import Path
from statistics import median
import json
import tarfile

lab=Path(__file__).resolve().parent
out=lab/'retrieved'
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
identity=read(lab/'local/identity.json')
terminal=read(out/'terminal-status.json')
receipt=terminal['receipt']
assert terminal['exitCode']=='0' and not terminal['guestFixturesRemain']
assert all(receipt[k] for k in ('complete','allWorkersJoined','guestFixturesRemoved','quietBeforeAndAfter','archivedAndVerifiedUnderLease'))
archive=out/'observations.tar.xz'
assert sha256(archive.read_bytes()).hexdigest()==receipt['archiveSHA256']
assert receipt['warmJobs']==3
for role in ('control','instrumented'):
    verified=read(out/f'{role}-vm-verify.json')
    assert verified['state']=='Completed' and verified['caseCount']==3
    assert verified['catalogSha256']==identity['catalogs']['representative.json']
    assert verified['launched']['library']['sha256']==identity['imageFiles'][role]['Lokad.Lython.dll']
with tarfile.open(archive) as bundle:
    raw=json.load(bundle.extractfile('confirmation/confirmation.json'))
    assert json.load(bundle.extractfile('identity.json'))==identity
    for name,digest in (identity['catalogs']|identity['pythonWorkers']).items():
        assert sha256(bundle.extractfile(name).read()).hexdigest()==digest
    for point in ('before','after'):
        assert json.load(bundle.extractfile(f'confirmation/machine-{point}.json'))['gate']['quiet']
assert raw['complete'] and len(raw['jobs'])==3
def interval(xs):
    xs=list(xs)
    return [min(xs),max(xs)]
def compare(a,b,action):
    return interval(action(l,r) for l,r in product(a,b))
rows=[]
for job in raw['jobs']:
    assert job['workersJoinedAndFixturesRemoved'] and len(job['samples'])==56
    values={}
    for role, identity_worker in job['identities'].items():
        assigned=[x for x in job['samples'] if x['engine']==role]
        assert len(assigned)==7
        measured={}
        for sample in assigned:
            res=sample['response']
            assert res['status']=='Completed' and res['completedInvocations']>0
            scale=1e6/res['clockFrequency']/res['completedInvocations']
            row={'command':res['elapsedTicks']*scale,
                 'processCpu':sample['externalProcessCpuTicks']*1e6/sample['externalCpuFrequency']/res['completedInvocations']}
            phases=res.get('phaseTicks')
            assert bool(phases)==('-instrumented-' in role)
            if phases:
                row.update(execution=phases['execution']*scale,
                           verification=phases['verification']*scale,
                           beforeVerification=(res['elapsedTicks']-phases['verification'])*scale,
                           other=(res['elapsedTicks']-phases['verification']-phases['execution'])*scale)
                assert row['other']>0 and row['verification']>0
            for key,value in row.items():
                measured.setdefault(key,[]).append(value)
        values[role]={k:median(v) for k,v in measured.items()}
    result={'case':job['case'],'workerMedianUs':values}
    # Compare the per-worker medians and retain all four pairs.
    changes={}
    for source in ('Lython','CPython'):
        control=[values[f'{source}-control-{worker}']['command'] for worker in (1,2)]
        probe=[values[f'{source}-instrumented-{worker}']['command'] for worker in (1,2)]
        changes[source]=compare(probe,control,lambda a,b:100*(a/b-1))
    result['instrumentedCommandChangePercent']=changes
    lython_control=[values[f'Lython-control-{worker}']['command'] for worker in (1,2)]
    python_control=[values[f'CPython-control-{worker}']['command'] for worker in (1,2)]
    result['commandControlRatio']=compare(lython_control,python_control,lambda a,b:a/b)
    result['commandControlGapUs']=compare(lython_control,python_control,lambda a,b:a-b)
    for phase in ('command','execution','verification','beforeVerification','other'):
        lython=[values[f'Lython-instrumented-{worker}'][phase] for worker in (1,2)]
        python=[values[f'CPython-instrumented-{worker}'][phase] for worker in (1,2)]
        result[phase]={'lythonUs':interval(lython),'cpythonUs':interval(python),
                        'ratio':compare(lython,python,lambda a,b:a/b),
                        'gapUs':compare(lython,python,lambda a,b:a-b)}
    rows.append(result)
summary=dict(sourceRevision=identity['sourceRevision'],machine='Azure F4as_v7 Ubuntu 24.04.4',reference='CPython 3.13.16',
             timedBatches=168,collectionSeconds=raw['elapsedSeconds'],rows=rows)
(out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8',newline='\n')
for result in rows:
    print(result['case'],f"control={result['commandControlRatio']}")
    print('probeControlShift',result['instrumentedCommandChangePercent'])
    for part in ('command','execution','verification','beforeVerification','other'):
        print(part,result[part])
