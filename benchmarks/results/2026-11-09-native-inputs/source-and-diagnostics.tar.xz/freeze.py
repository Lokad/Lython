from pathlib import Path
import hashlib,json,shutil,subprocess
r=Path(__file__).parent;prior=r.parent/'literal-construction-r129';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
cores=[Path(p)/'bin/Release/net11.0/Lokad.Lython.dll'for p in ['src/Lokad.Lython','tests/Lokad.Lython.Tests','tests/Lokad.Lython.PublicApi.Tests']]
assert len({sha(p)for p in cores})==1
for role in ['before','candidate']:shutil.copytree(prior/'images-verified/candidate',r/'images-verified'/role)
assert sha(r/'images-verified/before/Lokad.Lython.dll')=='1be2a325f98e06e0c874142c9a173f13c56da5680a2d48c5f95fbf50d09faf27'
shutil.copyfile(cores[0],r/'images-verified/candidate/Lokad.Lython.dll')
catalog=json.loads((prior/'catalog.json').read_text(encoding='utf8'));search=json.loads((r.parent/'agent-workloads-r130/representative.json').read_text(encoding='utf8'))['cases'];integer=json.loads((r.parent/'primitive-helpers-r113/catalog.json').read_text(encoding='utf8'))['cases']
allcases=catalog['cases']+search+integer
ids=['scripts.file-search.large','scripts.text-summary-helpers.large','scripts.report-render.large','scripts.csv-integer-accounting.large','scripts.csv-validated-records.large']
catalog['cases']=[next(c for c in allcases if c['id']==key)for key in ids];assert len(catalog['cases'])==5
(r/'catalog.json').write_text(json.dumps(catalog,indent=2)+'\n',encoding='utf8')
for name in ['measure.py','compile-diagnostic.py']:shutil.copyfile(prior/name,r/name)
s=(prior/'assess-local.py').read_text(encoding='utf8');at=s.index("out['limitations']=");end=s.index("\n(r/'assessment-local",at)
s=s[:at]+"out['limitations']='R132 consumed native local/constant leaves use direct sources; no new owner/array/engine. Before459/core1be2, working candidate. Five unchanged complete search/text/report/numeric/validatedCSV scripts, bothAPIs/fullgoldens/budgets/cleanup. Warm excludescompile; compile separate. SharedALCs/CoreLib/processGC, elapsed diagnostic, actual allocation not admission reduction; source/binary gates explicit.'"+s[end:];(r/'assess-local.py').write_text(s,encoding='utf8')
changed=subprocess.check_output(['git','diff','--name-only','--','src','tests'],text=True).splitlines()
i=dict(baseline='Committed459813a3/core1be2; full source CI42545629905success cached, never requery',candidate='R132 direct native inputs and immutable local prefix after57266452',coreSHA256={role:sha(r/'images-verified'/role/'Lokad.Lython.dll')for role in ['before','candidate']},changedSources={p:sha(Path(p))for p in changed},patchBase='57266452 (production459)',qualification='87internal/394public eachactual11/10 pass, no tests/assertions changed',contract='No new storage owner/array/engine/API/limit; native operation/return checkpoints replace consumed pure-leaf checks, no checkpoint count/fuel contract; guard-before-effects/mutable field rereads and compiled/runtime owners retained')
(r/'identity.json').write_text(json.dumps(i,indent=2)+'\n',encoding='utf8');(r/'source.patch').write_bytes(subprocess.check_output(['git','diff','--','src','tests']));shutil.copyfile('PLAN.md',r/'pre-measurement-plan.md')
tool=r/'census';tool.mkdir(exist_ok=True);old=r.parent/'call-operands-r37/census'
for n in ['census.csproj','packages.lock.json']:shutil.copyfile(old/n,tool/n)
s=(old/'Program.cs').read_text(encoding='utf8').replace('MemberCacheCount','LookupCacheCount')
s=s.replace('''        codes.Add(new { name = Get(code, "Name"),''','''        var native = Get(code, "NativeBody");
        var nodes = native is null ? [] : Items(native, "Values");
        var nativeNodes = nodes.Select(node => new { operation = Get(node,"Operation")!.ToString(),
            first = Get(node,"First"), second=Get(node,"Second"), third=Get(node,"Third"),
            read = Get(node,"Operation")!.ToString()=="Read" ? Get(Get(node,"Instruction")!,"OpCode")!.ToString() : null }).ToArray();
        codes.Add(new { nativeNodes, firstTemporarySlot=Get(code,"FirstTemporarySlot"),
            nativeRoot=native is null?null:Get(native,"Root"), name = Get(code, "Name"),''')
(tool/'Program.cs').write_text(s,encoding='utf8');print(i['coreSHA256'])
