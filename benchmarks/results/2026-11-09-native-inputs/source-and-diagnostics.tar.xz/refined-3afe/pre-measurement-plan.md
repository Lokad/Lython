# Lokad.Lython 0.11.0

Updated 2026-11-09 (Paris). Git-ignored: never force-add. Publication/tagging postponed.
Objective: coherent design simplification and substantial complete-script performance.
Current contracts live in docs. Completed source pairs, prototypes, original failed/
adverse conditions and qualification receipts live in [experimental history](benchmarks/EXPERIMENTS.md)
and immutable results. Finishing an experiment does not finish this objective.

## Actual delivery status

- **Fully qualified:** R119–R121 runtime6f76/coreC617 +typed-fixture correctiond97,
  cachedCI42527042378; R125 text-read borrow/awaited-cleanup3109/core004e,
  cachedCI42536319061; R126 five obsolete CLR-liveness NoInlining fences9f2e/core85e,
  cachedCI42538659198. Windows/Ubuntu full Release actual11/10, original stress both,
  installed-core consumers pass. Terminal receipts cached: never query/replay unchanged.
- **Fully qualified R127:** 8472935f/coreac6b. One declaration-owned flat signature/
  generator fact; removed role arrays, per-shape maps/body rescans and synthetic
  lowered parameters. Focused both targets/B487 pass; compileallocation−0.10..−0.32%,
  warm neutral. CachedCI42543394041success observedNov9 01:37:39UTC verifies full
  Windows/Ubuntu actual11/10, original stress both and installed-core consumers.
  No requery/unchanged replay. Later459 is separate.
- **Fully qualified R129:** 459813a3/core1be2, borrowed literal spans,
  canonical body decoder, lazy concatenation/parts, no synthetic f-string delimiters.
 42internal/529public focused peractual11/10 pass, no test/assertion changes.
  Compilation allocation−2.94..−9.89% (config−11408B); coarse admission unchanged.
  B489 sixjobs167.303s: configcompile elapsed−4.79..−3.66%/CPU−5.54..−5.00%, complete
  config−3.35..−1.08%, supportingCPU; text/JSON/report compile variable/modestly faster.
  Warm allocation neutralwithin0.023%, warmtext+0.36..+1.01%possible debt. Allgates,
  joined users, RAM removal/archive/localverification pass; terminal cached.
- **Completed foundations preserved:** shared compiler-fact correction, direct UTF8
  formatting/storage, native helper returns, primitive result facts, native JSON,
  record capacity/adoption, flat lookup storage and execution-owned function facts.
  Native-return allocation−19.92/−19.31% established, original elapsed diagnostic;
  delivered code fully qualified, no replay. R128/B488 compiler attribution complete:
  config/helper parsing43/26%, abstract19/29%, executable19/19%, lexical7/8%, lowering
  2/4%; leaf unknown14/16% and inlining/stack limits explicit. No dominant duplicate
  phase justifies a general compiler rewrite. No production change for attribution.
- **Held R124:** prepared named maps/default consolidation added registry/guard while
  general binding remained; compileallocation+0.20–0.25%, no stable CPU gain.
  Prototype/adverse evidence preserved, production restored with fresh builds;
  useful semantic/lifetime cases retained. No permanent ban or percentage veto.

**Measurement debts remain distinct:** formatting allocation−8.67%, controlledB102
elapsed/CPU−5–8% supports retention; original adverse15.125ms unexplained/preserved.
R127 quiet validatedCSV+0.36..+1.06%possible cost; text improves, JSON/report mixed.
R129 desktop compiletext+13..15%/JSON+3..7%not reproduced by quiet run, warmtext~1%
possible debt remains. R126 reportCPU uncertainty and earlier custom/config/async-
float debts remain in history; separate source-pair results are not additive.

**CPython:** [current guide](docs/BENCHMARKS.md), R122/B481 names6f76/C617 explicitly:
validatedCSV compile-to-result1.17x, CSV1.01–1.03variable, text1.52–1.53, JSON0.91–0.96
variable, report1.32–1.33 versus3.13.16. Compile/warm separate. Mediated RAM-file I/O,
full validation/prior-result cleanup included; startup/staging/reset/final cache
teardown excluded. Config/search/manifest still historical726. No HEAD relabeling.

## Prioritized deliverables

1. **Deliver retained declaration/literal consolidation.** CommitR129 with exact
   source/binary/diagnostic evidence, documentation and explicit CPU limitations.
   R127 andR129 full delivery complete/cached:42543394041/42545629905. R129 receipt
   verifies459/core1be2 only; R132 prototype needs its own later coherent qualification.
   Batch Windows/Ubuntu actual11/10, original stress both and installed-core checks
   at this coherent boundary. Work continues while CI runs; no repeated local full
   suite before the same CI. R127's separate receipt does not qualify later source.

2. **R130 targeted representative CPython refresh and next runtime selection.**
   Config edit, protected file search and copy/checksum/manifest are material stale
   cases and useful agent-script shapes. Reuse existing scripts/catalog/goldens,
   workers/protocol and quiet VM. Nine short jobs: eachcompile/warm/compile-to-result,
   CPython3.13.16 plus two independent current Lython processes, normalGC/tiering,
   five-second warmup/role and seven rotated150msrounds. Expected~190–210s; finite
   270sowner+30stop+30observation. Same included I/O/validation/prior-result cleanup;
   compilation/startup separate. Preserve adverse/inconclusive observations and
   historical rows, no new framework or unchanged five-case replay. Refresh guide
   with per-row named source/status; source qualification remains separate.
   B490 complete193.226s/allgates/archive/localpass, terminalcached. Guide refreshed
   with nine new459 rows and15 retained6f76 rows, mixedsources explicit. Complete
   config1.09–1.10xVariable(maxIQR3.95%), search1.40–1.41x, manifest1.47–1.48x;
   warm1.26–1.27/1.69–1.71/1.56–1.59x, compile1.08–1.09/.96–.97/1.25–1.27x.
   Manifest has only two small files, not large-tree throughput. NextR131: two~6s
   current warm config/search CPU samples through the existing perf/worker setup;
   actual active caller/guest workers and raw thread CPU retained. Attribute
   real runtime/host work separately from fixture reset/protocol/validation; sampling
   boundary is wider than worker execution clocks, not an elapsed comparison.
   B491 terminalcached/verified; no repeated observation.
   B491 complete/allgates/archive/localpass, no users/RAM; terminalcached. Corrected
   offline actual thread names exclude tiering (original active filter retained).
   Guestconfig549samples: host281, builtininit13; guestsearch875samples: prefix326,
   nativecallprep109/eval104/guard74/host121/admission63. Wider batch reset/protocol
   separated, unknown/inlined/truncated frames explicit. Native guard/eval15.54%leaf
   or20.34%innermost-observed phase includes useful work, not removable tax.
   No prototype until a coherent removable phase is demonstrated. One180sowner+60
   stop/observation, all users/RAM/archive proof. Stop after attribution/source gate
   and choose at most one design; no broad capture or unchanged retiming campaign.
   Stop collection after verified joined-user/RAM/archive/local gates. Use these
   completed scripts to select at most one dominant runtime phase with a bounded
   existing CPU capture only where current evidence is missing. A ratio alone does
   not attribute cost or justify speculative machinery. This is a selection step,
   not completion of the performance objective.

3. **Complete call/frame/operand redesign, source-gated.** Consolidate canonical
   preparation to remove an entire repeated phase, rather than accumulating cases.
   R123 helper/inline5.1/3.3ms includes useful work; binding/workspace4.97%leaf,
   preparation4.14%, tuple0.99%, context0. Existing linear caller-return engine/lazy
   context promotion, borrowed locals/tuple unpack, adopted final tuple/CSV arrays,
   shared layouts and inline presence bits are real; do not invent missing copies.
   Generic variadic staging exists but is absent from the profiled primary helper.
   Inspect complete ordinary argument/local initialization and shared defaults against
   R127's canonical declaration facts before another prepared-map prototype. Select
   only a design naming work/storage eliminated, displaced implementation removed,
   affected validatedCSV/report/JSON/text scripts and a bounded before/after control.
   No new arena, call-control carrier, owner, evaluator, dispatcher, cache registry or
   compatibility option. Preserve defaults/closures/recursion/order, real suspension,
   current cancellation/first refusal and retained aliases. Slower call-arena/control
   designs remain evidence; do not revive unchanged. If a justified redesign takes
   an intermediate regression, name its implementation-completion milestone and debt
   decision. If no coherent removal is established, record that and use independent work.

   **R132 selected: native helper inputs use the existing direct-operand convention.**
   Ordinary executable values already encode constants/locals directly; native return
   trees still allocate full Read nodes for consumed immutable constants and bound
   arguments, recursively dispatching those leaves in both proof and evaluation.
   Forward these leaves through existing input fields (negative constant index,
   local slot, operation references above the local prefix); keep real root Read
   metadata and mutable global/name reads. No new proof engine, registry, cache,
   frame, scratch array, owner, option or supported-syntax restriction.
   Remove consumed leaf nodes and their recursive read dispatch, update private
   native-argument source/sentinel plumbing instead of retaining old index aliases.
   Keep guard-before-all-effects, original mutable reads and actual field re-reads
   after admission, root/operation/return spans, selected-branch semantics, defaults/
   protocols/async fallbacks, managed depth and effective cancellation at operations.
   Eliminated pure leaf checkpoints are not a fuel/checkpoint-count contract; no
   cancellation interval may become unbounded. Unbound local errors keep ordinary
   executable diagnostics. Admission/refusal/alias funding and cleanup unchanged.
   Initial4f7 passes87internal/394public peractual11/10, census proves wanted3→1,
   words2→1, charge9→4 nodes and ordinary instruction metadata unchanged. Compile
   allocation neutral-to−1.19%; warm neutralwithin0.058%. Desktop elapsed controls
   driftup43.63% and adverse text+57%sync/+34%async remain preserved. Source refinement
   before quiet timing folds direct input handling into the existing two visitors,
   removing temporary GuardNativeInput/EvaluateNativeInput forwarding wrappers and
   duplicate format-shape checks; not a new measurement-selected specialization.
   Affected: wanted/startswith file search, text/cased-split, numeric and formatting
   helpers; validatedCSV lacking nativebody and config remain controls. Acceptance:
   source/census confirms no consumed local/constant Read nodes; focused both-target
   native/helper/conditional/format/default/rebinding/protocol/cancellation/refusal/
   retained-alias tests. Separate compile allocation from warm; bounded normal VM
   comparison search/text/numeric/helper plus unchanged controls, preserve adverse
   results. Completion: one operand convention without displaced leaf transport;
   decide retain/refine/restore and remaining debt from evidence, then resume roadmap.

4. **Bulk/text/frontend follow-through.** R128 attributes parsing/abstract/executable
   work, not a reason to delete valid diagnostics. R129 removes actual literal staging;
   retain AST/static-string semantics and managed runtimeUTF8 contracts. Lexical walks
   requiring complete parent facts are not automatically duplicates. Current CSV
   adopts rows/bulk-admits fields; JSON constructs native/shared-layout values. The old
   CSV6–8%copy premise is gone, not automatically promoted. Existing text native casing,
   cased split/final-buffer formatting/hash caching and R125 pending-borrow funding
   remain. Select the next complete-script cost from current evidence; no universal
   tagged values, JIT, VM-stack or string-view project from inclusive samples alone.
   Each selected milestone records hypothesis, removed work/storage/code, semantic
   acceptance, compile/warm/I/O/cleanup boundaries and one bounded controlled comparison.

## Independent regex track

Core Python/nativeUTF8 contract is independent of producer publication: byte captures,
scalar positions/original windows, effectiveflags/errors/replacements, current tokens,
one frontend/runtime/import provider and explicit owners. Continue core implementation/
contract tests with adapter-local bridges or pinned development producers as needed.
Ordinary optional nonpackable adapter pin0.4; Dev55/d6067925 focused86internal/514public
peractual11/10 already passed, no unchanged replay or sibling edits/builds. Final
selected-package qualification still needs DetailedData with distinct preparation/
working owners, native-name enumeration and cursor creation without an earlier token.
Only affected final adapter checks defer; no blanket development stop. Contract
forwarding/unwind, Python semantics and actual backend performance are separate evidence.

## Iteration and invariants

Bounded confirmation/refinement/measurement correction is allowed for justified
uncertainty. Timeout, unstable unchanged controls and inconclusive results are not
failed designs or permanent closure. Size runs for useful VM observations; percentages
inform decisions, not automatic vetoes. Preserve original failed/adverse conditions.
Architectural simplification, allocation reduction and demonstrated CPU gains differ.
Focused Release semantics/cancellation/ownership during iteration; full checks batched.

AGENTS.md governs fully managed memory safety/stack admission, host mediation, current
CancellationToken, coarse borrowed shared admission/preflight/replacement overlap,
funded aliases/results/caches/pending users and awaited cleanup. Refusal terminal.
No unsafe/Unsafe/native probes, heap tracing/weak reclaim/forcedGC, caps/fuel/quotas,
hidden allowance, silent regex fallback or abandoned work. No localbuild/test/timing
overlap. Fresh nonincremental builds after source restoration; explicitUTF8. Only core
Release packages to artifacts/nuget; publication remains postponed.

VM lokad@20.166.121.73, key ~/.ssh/id_lython-bench.pem. Persistent workers/catalog/raw,
owned RAM guest fixtures separate; join/verify/unmount/archive under lease then verify
locally. ThroughB491 terminal/cached/verified, no users/fixtures; never requery. New CI
observations>=5min apart; cache terminal. Space recovery only fresh idle exact-byte
proof, all inode aliases/SHA/permitted canonical ownership/writable parents and a
persisted pre-mutation plan. Preserve every historical path/byte/archive and refusal.
