from pathlib import Path
p=Path('src/Lokad.Lython/Frontend/ExecutableScript.NativeReturns.cs');s=p.read_text(encoding='utf8')
s=s.replace('return new(values.ToArray(), proof.Value.Root);','return new(values.ToArray(), proof.Value.Root - FirstTemporarySlot);')
s=s.replace('int MemberName, int Producer)>','int MemberName, int Producer, LythonSourceSpan? ReadSpan)>')
s=s.replace('return (values.Count - 1, conditionalDepth);','return (FirstTemporarySlot + values.Count - 1, conditionalDepth);')
s=s.replace('''                        values[root.Value] = values[root.Value] with { ReturnSpan = instruction.Span };''','''                        if (root.Value < FirstTemporarySlot)
                        {
                            // A real return keeps its source/exit metadata. Consumed
                            // pure leaves need no node in the native operation tree.
                            var read = root.Value < 0
                                ? ExecutableInstruction.LoadConst(~root.Value, root.ReadSpan!)
                                : ExecutableInstruction.LoadLocal(root.Value, root.ReadSpan!);
                            values.Add(new(NativeReturnOperation.Read, read, -1, -1,
                                ReturnSpan: instruction.Span));
                            return (FirstTemporarySlot + values.Count - 1, root.Depth);
                        }
                        var rootIndex = root.Value - FirstTemporarySlot;
                        values[rootIndex] = values[rootIndex] with { ReturnSpan = instruction.Span };''')
s=s.replace('return (values.Count - 1, 1);','return (FirstTemporarySlot + values.Count - 1, 1);')
s=s.replace('''                    case ExecutableOpCode.LoadConst:
                        break;''','''                    case ExecutableOpCode.LoadConst:
                        var source = instruction.OpCode == ExecutableOpCode.LoadConst
                            ? ~instruction.ConstantIndex : instruction.LocalSlot;
                        stack.Add((source, null, 1, -1, sourceIndex, instruction.Span));
                        continue;''')
s=s.replace('stack[^1].Producer);','stack[^1].Producer, stack[^1].ReadSpan);')
s=s.replace('''                        while (values[formattedInput].Operation is NativeReturnOperation.ConvertFormat or NativeReturnOperation.FormatValue)
                            formattedInput = values[formattedInput].First;
                        if (values[formattedInput].Operation == NativeReturnOperation.Subscript) readsFormatStorage = true;''','''                        while (formattedInput >= FirstTemporarySlot &&
                            values[formattedInput - FirstTemporarySlot].Operation is NativeReturnOperation.ConvertFormat or NativeReturnOperation.FormatValue)
                            formattedInput = values[formattedInput - FirstTemporarySlot].First;
                        if (formattedInput >= FirstTemporarySlot &&
                            values[formattedInput - FirstTemporarySlot].Operation == NativeReturnOperation.Subscript) readsFormatStorage = true;''')
s=s.replace('site.ArgumentCount != 1 || values[first].Operation != NativeReturnOperation.Read','site.ArgumentCount != 1 || first >= FirstTemporarySlot && values[first - FirstTemporarySlot].Operation != NativeReturnOperation.Read')
s=s.replace('first == values.Count - 1','first >= FirstTemporarySlot && first - FirstTemporarySlot == values.Count - 1')
s=s.replace('values[first].Operation == NativeReturnOperation.StringMethod','values[first - FirstTemporarySlot].Operation == NativeReturnOperation.StringMethod').replace('var producer = values[first];','var producer = values[first - FirstTemporarySlot];')
s=s.replace('NativeValueIndex =','NativeInput =').replace('stack.Add((values.Count - 1, null, depth, -1, sourceIndex));','stack.Add((FirstTemporarySlot + values.Count - 1, null, depth, -1, sourceIndex, null));')
p.write_text(s,encoding='utf8')
p=Path('src/Lokad.Lython/Frontend/ExecutableScript.cs');s=p.read_text(encoding='utf8').replace('NativeValueIndex = -1','NativeInput = int.MaxValue').replace('NativeValueIndex','NativeInput').replace('NativeArgumentIndex','NativeArgumentSource').replace('? Arguments[index].NativeInput : -1','? Arguments[index].NativeInput : int.MaxValue')
s=s.replace('// Executable argument forms retain native value indexes for eligible bodies;', '// Executable argument forms retain direct native sources for eligible bodies;')
p.write_text(s,encoding='utf8')
p=Path('src/Lokad.Lython/Runtime/LythonRuntime.Executable.NativeReturn.cs');s=p.read_text(encoding='utf8')
# Operation-tree entries retain raw array indexes. Their inputs reuse ordinary
# operand domains: negative constants, local prefix, then native operation nodes.
at=s.index('    private static bool GuardNativeReturn(')
helpers='''    private static bool TryReadNativeInput(int source, ExecutableCodeObject code, NativeReturnValue[] values,
        ReadOnlySpan<object?> arguments, ExecutionContext context, out object? value)
    {
        if (source < 0) { value = code.Constants[~source]; return true; }
        if (source < code.FirstTemporarySlot)
        {
            var bound = (uint)source < (uint)arguments.Length;
            value = bound ? arguments[source] : null;
            return bound;
        }
        return TryReadNativeOperand(code, values[source - code.FirstTemporarySlot].Instruction, arguments, context, out value);
    }

    private static bool GuardNativeInput(int source, ExecutableCodeObject code, NativeReturnValue[] values,
        ReadOnlySpan<object?> arguments, ExecutionContext context, out NativeReturnShape shape)
    {
        if (source >= code.FirstTemporarySlot)
            return GuardNativeReturn(source - code.FirstTemporarySlot, code, values, arguments, context, out shape);
        shape = NativeReturnShape.Other;
        if (!TryReadNativeInput(source, code, values, arguments, context, out var value)) return false;
        shape = ReturnShape(value);
        return true;
    }

    private static object EvaluateNativeInput(int source, ExecutableCodeObject code, NativeReturnValue[] values,
        ReadOnlySpan<object?> arguments, ExecutionContext context, PyException? entryException)
    {
        if (source >= code.FirstTemporarySlot)
            return EvaluateNativeReturn(source - code.FirstTemporarySlot, code, values, arguments, context, entryException);
        // The complete guard established bound arguments before any effects.
        // Parent operations retain cancellation/refusal checks and source spans.
        return RuntimeValue(source < 0 ? code.Constants[~source] : arguments[source]);
    }

'''
s=s[:at]+helpers+s[at:]
# Replace child recursion, retaining raw operation-array entry functions.
start=s.index('    private static bool GuardNativeReturn(');end=s.index('    private static bool GuardNativeFormattedValue',start)
part=s[start:end].replace('GuardNativeReturn(', 'GuardNativeInput(');part=part.replace('private static bool GuardNativeInput(int index,','private static bool GuardNativeReturn(int index,',1)
part=part.replace('''                ref readonly var targetValue = ref values[value.First];
                if (!TryReadNativeOperand(code, targetValue.Instruction, arguments, context, out var target)''','''                if (!TryReadNativeInput(value.First, code, values, arguments, context, out var target)''')
part=part.replace('NativeArgumentIndex','NativeArgumentSource').replace('''                ref readonly var argument = ref values[argumentIndex];
''','')
part=part.replace('if (argument.Operation == NativeReturnOperation.Read)','if (argumentIndex < code.FirstTemporarySlot || values[argumentIndex - code.FirstTemporarySlot].Operation == NativeReturnOperation.Read)')
part=part.replace('TryReadNativeOperand(code, argument.Instruction, arguments, context, out actual)','TryReadNativeInput(argumentIndex, code, values, arguments, context, out actual)')
part=part.replace(' is >= 0 and var ', ' is not int.MaxValue and var ')
s=s[:start]+part+s[end:]
start=s.index('    private static bool GuardNativeFormattedValue');end=s.index('    private static object EvaluateNativeReturn',start)
part=s[start:end]
part=part.replace('''        ref readonly var value = ref values[index];''','''        if (index < code.FirstTemporarySlot)
        {
            if (!TryReadNativeInput(index, code, values, arguments, context, out var direct)) return false;
            return ReturnShape(direct) is NativeReturnShape.None or NativeReturnShape.Integer or NativeReturnShape.Float
                or NativeReturnShape.Boolean or NativeReturnShape.String or NativeReturnShape.Bytes;
        }
        ref readonly var value = ref values[index - code.FirstTemporarySlot];''',1)
part=part.replace('GuardNativeReturn(index,','GuardNativeInput(index,')
marker=part.index('    private static bool TryReadNativeFormattedValue')
head,tail=part[:marker],part[marker:]
tail=tail.replace('''        ref readonly var value = ref values[index];''','''        if (index < code.FirstTemporarySlot)
            return TryReadNativeInput(index, code, values, arguments, context, out result);
        ref readonly var value = ref values[index - code.FirstTemporarySlot];''',1)
s=s[:start]+head+tail+s[end:]
start=s.index('    private static object EvaluateNativeReturn');end=s.index('    // Zero operands',start)
part=s[start:end].replace('EvaluateNativeReturn(','EvaluateNativeInput(').replace('private static object EvaluateNativeInput(int index,','private static object EvaluateNativeReturn(int index,',1)
part=part.replace('CheckNativeReturnExit(selected, values, context)','CheckNativeReturnExit(selected - code.FirstTemporarySlot, values, context)')
part=part.replace('NativeArgumentIndex','NativeArgumentSource').replace(' is >= 0 and var ',' is not int.MaxValue and var ')
s=s[:start]+part+s[end:]
p.write_text(s,encoding='utf8')
p=Path('src/Lokad.Lython/Frontend/ExecutableNativeBody.cs');s=p.read_text(encoding='utf8');s=s.replace('// its own physical operands and source spans; only eligible helpers own nodes.','''// its own physical operands and source spans; only eligible helpers own nodes.
// Inputs use the existing operand domains: negative constant indexes, the local
// prefix, then operation indexes offset by that prefix. Consumed local/constant
// leaves need no Read node; real roots and mutable name reads retain metadata.''');p.write_text(s,encoding='utf8')
print('Consumed native local/constant leaves forwarded; no new owner/array/engine')
