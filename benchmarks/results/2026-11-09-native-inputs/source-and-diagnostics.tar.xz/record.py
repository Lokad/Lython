from pathlib import Path
import hashlib,json,shutil,tarfile
r=Path(__file__).parent;dest=Path('benchmarks/results/2026-11-09-native-inputs');dest.mkdir(exist_ok=True)
identity=json.loads((r/'identity.json').read_text(encoding='utf8'))
for p,h in identity['changedSources'].items():assert hashlib.sha256(Path(p).read_bytes()).hexdigest()==h
for n in ['identity.json','assessment-local.json','compile-assessment.json','census-assessment.json']:shutil.copyfile(r/n,dest/n)
for number,prefix in [('b492','before-prefix-'),('b493','')]:
 b=r/number;t=json.loads((b/'terminal.json').read_text(encoding='utf8'))
 assert hashlib.sha256((b/'observations.tgz').read_bytes()).hexdigest()==t['receipt']['archiveSHA256']
 for n in ['assessment.json','observations.tgz']:shutil.copyfile(b/n,dest/(prefix+n))
 (dest/(prefix+'archive-receipt.json')).write_text(json.dumps(t,indent=2)+'\n',encoding='utf8')
validation=dict(actualFrameworks=['net11.0','net10.0'],eachTarget=dict(internal=87,public=394),eachVariant='Initial4f7, refined3afe and final95fc pass after actual source changes; no test/assertion/timeout changes',ordinaryInstructionMetadata='Identical with fixed local-prefix counts; wanted3to1, words2to1, charge9to4 native nodes',fullDelivery='Pending coherent candidate delivery; reference459/core1be2 cachedCI42545629905success',decision='Retain canonical native operand representation and one immutable prefix fact. Syncsearch elapsed−2.45..−3.40% in B493; CPU not consistently supportive, textCPU debt/control uncertainty remains; no general CPU gain claim')
(dest/'focused-validation.json').write_text(json.dumps(validation,indent=2)+'\n',encoding='utf8')
with tarfile.open(dest/'source-and-diagnostics.tar.xz','w:xz')as a:
 for folder,label in [(r,''),(r/'initial-4f7','initial-4f7'),(r/'refined-3afe','refined-3afe')]:
  for p in sorted(folder.iterdir()):
   if p.is_file()and p.suffix in ['.py','.ps1','.log','.json','.md','.patch']:a.add(p,arcname='/'.join(x for x in [label,p.name]if x))
  for name in ['warm-sync','warm-async','compile-sync']:a.add(folder/name,arcname='/'.join(x for x in [label,name]if x))
  a.add(folder/'images-verified/candidate/Lokad.Lython.dll',arcname='/'.join(x for x in [label,'candidate-core.dll']if x))
 for n in ['Program.cs','census.csproj','packages.lock.json']:a.add(r/'census'/n,arcname='census/'+n)
 for number in ['b492','b493']:
  for n in ['launch.py','launch.log','launch-command.py','terminal.json','terminal-observation.log','identity.json','observe-not-before.json']:a.add(r/number/n,arcname=number+'/'+n)
p=Path('benchmarks/EXPERIMENTS.md');s=p.read_text(encoding='utf8');s+='''

## Native helper direct inputs and fixed local prefix (2026-11-09 Paris)

[R132](results/2026-11-09-native-inputs/README.md), qualified459/core1be2 versus
final95fc. Native helper inputs reuse ordinary direct constant/local domains;
consumed leaves no longer allocate/recursively dispatch full Read nodes. Real roots/
mutable names keep metadata; old NativeValueIndex/NativeArgumentIndex plumbing removed.
Guard-before-effects, field re-reads, operation/member/root/return cancellation,
managed depth and borrowed funding remain. Fixed compiler local prefix published once.
No new frame, array, owner, cache, engine, option or syntax restriction. Each of4f7/
3afe/95fc passes87internal/394public peractual11/10 after source changes; no test changes.
Census wanted3→1/words2→1/charge9→4 nodes, ordinary instruction metadata/prefix counts
identical. Final compileallocation−.018..−1.18%affected, report+.014%small metadata;
warmwithin.038%. Original desktop text+57%/search+34%/control drift43.63% preserved.
B492 sixjobs169.786s: mixed/search−2.05..+1.43%/textCPU+1.25..5.33%/reportelapsed
+1.85..4.64%. Source refinement removes repeated interface Count for immutable prefix.
B493 sixjobs169.776s/allgates/archive/localpass: syncsearch−3.40..−2.45%, close controls;
text−.05..+.98%/CPU0..+5.35%, report−2.86..+.95%candidateSpread3.65%, numeric
−3.47..+1.32%spread3.64%, validatedCSV−5.65..+.69%reference/candidate~3%, asyncsearch
−4.96..+.87%candidateSpread5.53%. CPU includes wider reset/protocol boundary, coarse
ticks; no generalCPUgain/universalneutrality claim. Retain coherent representation
and bounded syncsearch elapsed benefit; explicit textCPU/debt/control uncertainty.
No further unchanged retiming selected, not permanent closure. Both archives verified,
all users joined/RAM removed/terminalcached; qualified catalog reused by owned SHA link,
no disk recovery/floor relaxation. Full candidate delivery pending; objective open.
''';p.write_text(s,encoding='utf8');print('R132 retained evidence archived; all three variants and adverse controls preserved')
