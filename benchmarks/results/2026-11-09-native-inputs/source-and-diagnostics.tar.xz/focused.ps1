$env:DOTNET_ROOT = 'C:/Users/JoannesVermorel/.dotnet11'
$env:DOTNET_HOST_PATH = "$env:DOTNET_ROOT/dotnet.exe"
$env:PATH = "$env:DOTNET_ROOT;C:/Python313;$env:PATH"
$logs = '.git/agent-notes/review-20261031/native-inputs-r132'
foreach ($target in @('net11.0', 'net10.0')) {
    dotnet test tests/Lokad.Lython.Tests/Lokad.Lython.Tests.csproj -c Release -f $target --no-restore --filter '(Category!=Stress)&(FullyQualifiedName~SimpleFunctionExecutionBoundary|FullyQualifiedName~FunctionWorkspaceOwnership|FullyQualifiedName~ReentrantAdmissionOwnership|FullyQualifiedName~DirectOperandOwnership|FullyQualifiedName~CallBindingSubsystem|FullyQualifiedName~FunctionLookupLifetime|FullyQualifiedName~DeferredFunctionOwnership|FullyQualifiedName~StaticFactCancellation)' *> "$logs/internal-$target.log"
    if ($LASTEXITCODE -ne 0) { Get-Content -LiteralPath "$logs/internal-$target.log" -Encoding utf8 -Tail 30; exit $LASTEXITCODE }
    Get-Content -LiteralPath "$logs/internal-$target.log" -Encoding utf8 -Tail 2
    dotnet test tests/Lokad.Lython.PublicApi.Tests/Lokad.Lython.PublicApi.Tests.csproj -c Release -f $target --no-restore --filter '(Category!=Stress)&(FullyQualifiedName~NativeReturnFunction|FullyQualifiedName~NativeConditionalHelper|FullyQualifiedName~FormattedHelperReturn|FullyQualifiedName~NativeWorkStateDispatch|FullyQualifiedName~AsyncFunctionHosting|FullyQualifiedName~OrdinaryFunctionCall|FullyQualifiedName~PreparedFunction|FullyQualifiedName~FunctionDefault|FullyQualifiedName~ParameterLocalOrder|FullyQualifiedName~NativeScalarDispatch|FullyQualifiedName~NativeStorageTransfer|FullyQualifiedName~StringAffix|FullyQualifiedName~StringPredicateCall)' *> "$logs/public-$target.log"
    if ($LASTEXITCODE -ne 0) { Get-Content -LiteralPath "$logs/public-$target.log" -Encoding utf8 -Tail 40; exit $LASTEXITCODE }
    Get-Content -LiteralPath "$logs/public-$target.log" -Encoding utf8 -Tail 2
}
