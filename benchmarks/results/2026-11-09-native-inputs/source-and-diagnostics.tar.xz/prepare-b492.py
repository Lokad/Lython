from pathlib import Path
import hashlib,json,shutil,tarfile
r=Path(__file__).parent;b=r/'b492';b.mkdir();old=r.parent/'literal-construction-r129/b489';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
identity=json.loads((r/'identity.json').read_text(encoding='utf8'))
for p,h in identity['changedSources'].items():assert sha(Path(p))==h
root='native-inputs-b492-20261109';unit='lython-b492-native-inputs-20261109'
for name in ['collect.py','archive-owned.py','run.sh','launch.py']:
 s=(old/name).read_text(encoding='utf8').replace('literal-construction-b489-20261109',root).replace('lython-b489-literal-construction-20261109',unit).replace('literal-construction-b489-launch.py','native-inputs-b492-launch.py')
 if name=='collect.py':
  at=s.index('jobs=');end=s.index('\nassert len(jobs)',at)
  keys=['scripts.file-search.large','scripts.text-summary-helpers.large','scripts.report-render.large','scripts.csv-integer-accounting.large','scripts.csv-validated-records.large']
  s=s[:at]+'jobs='+repr([[key,'warm']for key in keys]+[['scripts.file-search.large','warm-async']])+s[end:]
  at=s.index("purpose='R129");end=s.index("',\n",at)
  s=s[:at]+"purpose='R132 direct native inputs. Qualified459/core1be2 versus refined3afe, five complete warm scripts plus asyncsearch, four process controls. Native wanted3to1/words2to1/charge9to4 nodes, ordinary instruction metadata unchanged. Initial4f7 adverse/control drift retained; compile/allocation separate"+s[end:]
 if name=='launch.py':s=s.replace("reference=base/'declaration-layout-b487-20261109/candidate'","reference=base/'literal-construction-b489-20261109/candidate'")
 (b/name).write_text(s,encoding='utf8',newline='\n')
shutil.copyfile(r/'images-verified/candidate/Lokad.Lython.dll',b/'current-core.dll');shutil.copyfile(r/'catalog.json',b/'representative.json')
i=dict(sourceRevision='R132 refined working prototype after0e7c1e17, frozen3afe',coreSHA256={role:identity['coreSHA256']['before'if role.startswith('reference')else'candidate']for role in ['reference','reference-control','candidate','candidate-control']},auxiliaryFiles={p.name:sha(p)for p in (r/'images-verified/before').glob('*.dll')if p.name!='Lokad.Lython.dll'},catalogSHA256=sha(b/'representative.json'))
(b/'identity.json').write_text(json.dumps(i,indent=2)+'\n',encoding='utf8')
for name,path in [('pre-measurement-plan.md',Path('PLAN.md')),('source.patch',r/'source.patch')]:shutil.copyfile(path,b/name)
for name,data in {'baseline-source.json':identity,'focused.json':dict(eachTarget=dict(internal=87,public=394),actualTargets=['net11.0','net10.0'],testsChanged=0,baselineQualification='cachedCI42545629905success; never requery'), 'setup-contract.json':dict(roles=4,jobs=6,ownerSeconds=240,stopSeconds=30,marginSeconds=30,normalGcAndTiering=True,publication=False),'sizing.json':dict(jobs=6,warmupPerRoleSeconds=5,rounds=7,targetBatchSeconds=.15,expectedSeconds=180,ownerSeconds=240)}.items():(b/name).write_text(json.dumps(data,indent=2)+'\n',encoding='utf8')
(b/'contract.md').write_text('R132 native helper consumed bound-local/constant leaves use ordinary direct operand domains; no new scratch/owner/frame/cache/engine/limit. Real roots/mutable reads, guard-before-effects, field re-reads, effective operation/return cancellation, managed depth/refusal/aliases preserved. Initial4f7 source/binary/adverse desktop observations retained, refined3afe removes forwarding wrappers before quiet comparison. Qualified1be2 reference, same worker/auxiliary/pins, six complete warm jobs/fourprocesscontrols/fullgoldens/budgets/cleanup. Compile/startup/reset/protocol/finalcacheteardown excluded; guestIO/fullvalidation/priorcleanup retained.240sowner+30stop+30observation, joinedusers/ownedRAM/archiveunderlease/localverification.\n',encoding='utf8')
with tarfile.open(b/'payload.tgz','w:gz')as a:
 for name in ['collect.py','archive-owned.py','run.sh','current-core.dll','representative.json','identity.json','pre-measurement-plan.md','baseline-source.json','source.patch','focused.json','setup-contract.json','sizing.json','contract.md']:a.add(b/name,arcname=name)
for name in ['collect.py','archive-owned.py','launch.py']:compile((b/name).read_text(encoding='utf8'),name,'exec')
s=(r.parent/'literal-construction-r129/retrieve-b489.py').read_text(encoding='utf8').replace('b489','b492').replace('literal-construction-b492-20261109',root).replace('lython-b492-literal-construction-20261109',unit).replace('B489','B492')
(r/'retrieve-b492.py').write_text(s,encoding='utf8');compile(s,'retrieve','exec');print('Prepared bounded B492',i['coreSHA256']['candidate'])
