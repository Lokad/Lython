#!/usr/bin/env bash
set -euo pipefail
export DOTNET_ROOT="$HOME/.dotnet"
export PATH="$DOTNET_ROOT:$PATH"
cd /mnt/d/code/Lython
lab="$PWD/.git/agent-notes/review-20261031/json-list-initial-admission-b1913-20261128"
export NUGET_PACKAGES="$PWD/.git/agent-notes/review-20261031/regex-released-050-20261127/packages-ubuntu"
filter='Category!=Stress&(FullyQualifiedName~Json|FullyQualifiedName~ListGrowth|FullyQualifiedName~ListStorage|FullyQualifiedName~AdmissionFailureCommandTests|FullyQualifiedName~RepresentativeScript)'
for suite in Lokad.Lython.PublicApi.Tests Lokad.Lython.Tests; do
    dotnet test "tests/$suite/$suite.csproj" -c Release -f net11.0 --artifacts-path "$lab/ubuntu-artifacts" --filter "$filter" 2>&1 | tee "$lab/ubuntu-$suite-net11.0.log"
done
