from hashlib import sha256
from pathlib import Path
from shutil import copyfile, copytree
import json
import os
import subprocess

lab = Path(__file__).resolve().parent
pair = lab / "comparison"
witness = lab.parent / "private-definition-admission-20261125/admission-probe/bin/Release/net11.0"
destination = lab / "admission"
destination.mkdir()
read = lambda path: json.loads(path.read_bytes())
digest = lambda path: sha256(path.read_bytes()).hexdigest()
identity = read(pair / "identity.json")
sdk = Path.home() / ".dotnet11"
dotenv = dict(os.environ, DOTNET_ROOT=str(sdk), DOTNET_ROOT_X64=str(sdk))
results = []
for role, files in identity["imageFiles"].items():
    folder = destination / role
    copytree(pair / role, folder)
    for name in ("AdmissionWitness.dll", "AdmissionWitness.deps.json", "AdmissionWitness.runtimeconfig.json"):
        copyfile(witness / name, folder / name)
    assert all(digest(folder / name) == checksum for name, checksum in files.items())
    output = destination / (role + ".json")
    subprocess.run([sdk / "dotnet.exe", folder / "AdmissionWitness.dll", folder, pair / "representative.json", output],
                   env=dotenv, cwd=folder, check=True, timeout=80)
    result = read(output)
    assert result["coreSHA256"] == files["Lokad.Lython.dll"]
    results.append(result["rows"])
rows = []
for left, right in zip(*results, strict=True):
    assert left["id"] == right["id"] and left["asynchronous"] == right["asynchronous"]
    assert left["allowanceReturned"] and right["allowanceReturned"]
    row = dict(case=left["id"], asynchronous=left["asynchronous"],
               requests=[left["resizeGrowths"], right["resizeGrowths"]],
               peak=[left["peakExecutionMemoryBytes"], right["peakExecutionMemoryBytes"]])
    rows.append(row)
    print(row)
(destination / "summary.json").write_text(json.dumps(rows, indent=2) + "\n", encoding="utf-8", newline="\n")

baseline_suite = lab / "baseline-suite"
repo = lab.parents[3]
copytree(repo / "tests/Lokad.Lython.PublicApi.Tests/bin/Release/net11.0", baseline_suite)
baseline_core = baseline_suite / "Lokad.Lython.dll"
copyfile(pair / "reference" / baseline_core.name, baseline_core)
assert digest(baseline_core) == identity["imageFiles"]["reference"][baseline_core.name]
baseline = subprocess.run([sdk / "dotnet.exe", "vstest", baseline_suite / "Lokad.Lython.PublicApi.Tests.dll",
                           "/TestCaseFilter:FullyQualifiedName~RefusedListBackingPrecedesFirstParseHook"],
                          env=dotenv, cwd=repo, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, timeout=40)
(lab / "baseline-regression.log").write_bytes(baseline.stdout)
print(f"Baseline first-refusal case exited {baseline.returncode}")
print(baseline.stdout.decode("utf-8",errors="replace"))
