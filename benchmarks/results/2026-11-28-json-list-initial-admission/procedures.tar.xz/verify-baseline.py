from hashlib import sha256
from pathlib import Path
from shutil import copyfile, copytree
import json
import os
import subprocess

lab = Path(__file__).resolve().parent
pair = lab / "comparison"
read = lambda path: json.loads(path.read_bytes())
digest = lambda path: sha256(path.read_bytes()).hexdigest()
identity = read(pair / "identity.json")
sdk = Path.home() / ".dotnet11"
dotenv = dict(os.environ, DOTNET_ROOT=str(sdk), DOTNET_ROOT_X64=str(sdk))
baseline_suite = lab / "baseline-suite-final"
repo = lab.parents[3]
copytree(repo / "tests/Lokad.Lython.PublicApi.Tests/bin/Release/net11.0", baseline_suite)
baseline_core = baseline_suite / "Lokad.Lython.dll"
copyfile(pair / "reference" / baseline_core.name, baseline_core)
assert digest(baseline_core) == identity["imageFiles"]["reference"][baseline_core.name]
baseline = subprocess.run([sdk / "dotnet.exe", "vstest", baseline_suite / "Lokad.Lython.PublicApi.Tests.dll",
                           "/TestCaseFilter:FullyQualifiedName~ArrayBackingIsFundedWhileFirstParseHookRuns"],
                          env=dotenv, cwd=repo, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, timeout=40)
(lab / "baseline-regression.log").write_bytes(baseline.stdout)
print(f"Baseline first-refusal case exited {baseline.returncode}")
print(baseline.stdout.decode("utf-8",errors="replace"))
assert baseline.returncode == 1 and b"Failed:     2" in baseline.stdout and b"Scalar:" in baseline.stdout
