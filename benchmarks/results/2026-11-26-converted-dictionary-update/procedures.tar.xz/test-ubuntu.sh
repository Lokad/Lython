set -eu
export DOTNET_ROOT="$HOME/.dotnet"
export PATH="$DOTNET_ROOT:$PATH"
lab="$PWD/.git/agent-notes/review-20261031/converted-dictionary-update-20261126"
cd "$lab/candidate-source"
for suite in Lokad.Lython.Tests Lokad.Lython.PublicApi.Tests; do
  if [ "$suite" = Lokad.Lython.Tests ]; then
    filter='Category!=Stress&(FullyQualifiedName~Dictionary|FullyQualifiedName~RecordField|FullyQualifiedName~Preflight|FullyQualifiedName~NativeOperand)'
  else
    filter='Category!=Stress&(FullyQualifiedName~ConvertedDictionaryUpdate|FullyQualifiedName~Dictionary|FullyQualifiedName~RecordField|FullyQualifiedName~CsvDelayedHost|FullyQualifiedName~StackAdmission)'
  fi
  log="$lab/$suite-ubuntu10.log"
  if dotnet test "tests/$suite/$suite.csproj" -c Release -f net10.0 --artifacts-path "$lab/ubuntu" --filter "$filter" > "$log" 2>&1; then
    tail -5 "$log"
  else
    tail -40 "$log"
    exit 1
  fi
done
