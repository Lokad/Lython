from pathlib import Path
import ast
import hashlib
import json
import os
import shutil
import subprocess
import tarfile

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
quiet = lab/"comparison/quiet"
quiet.mkdir(parents=True)
parent = lab.with_name("direct-record-helper-20261126")
old = lab.with_name("csv-window-source-gate-20261126")
template = old/"comparison/quiet"
route = lab.with_name("converted-dictionary-update-routes-20261126")
read = lambda p:json.loads(p.read_text(encoding="utf-8"))
sha = lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
write = lambda p,t:p.write_text(t,encoding="utf-8",newline="\n")
save = lambda p,data:write(p,json.dumps(data,indent=2,ensure_ascii=False)+"\n")
identity = read(lab/"frozen-identity.json")
assert sha(lab/"candidate.patch")==identity["sourcePatchSHA256"]
assert all(item["routes"]["CompletedConvertedUpdates"] == (0 if "file-fed" in item["id"] else 2046)
           for item in read(route/"routes.json")["rows"])
catalog = read(lab/"representative.json")
text_id = "diagnostic.text-summary.nonlocal-computed-width.large"
text = [row for row in read(old/"local/representative.json")["cases"] if row["id"]==text_id]
assert len(text)==1
catalog["cases"] += text
assert len({row["id"] for row in catalog["cases"]})==5
save(quiet/"representative.json",catalog)
save(quiet/"jobs.json",{"warm":[
    ["diagnostic.shipment-routing-callbacks","warm-async"],
    ["diagnostic.json-service-quantity-totals","warm"],
    [text_id,"warm"],
    ["diagnostic.shipment-bound-starmap","warm"],
    ["diagnostic.shipment-file-fed-map","warm-async"],
    ["diagnostic.shipment-routing-callbacks","warm"],
]})
worker=repo/"benchmarks/cpython-worker.py"
shutil.copyfile(worker,quiet/"cpython-worker.py")
assert sha(worker)==identity["cpythonWorkerSHA256"]
identity["catalogs"]={name:{"sha256":sha(quiet/name)} for name in ("representative.json","jobs.json")}
identity["purpose"]="Test a complete dictionary update with a short integer field conversion."
identity["expectedCPythonSHA256"]=read(template/"identity.json")["expectedCPythonSHA256"]
save(quiet/"identity.json",identity)
sdk=Path.home()/".dotnet11"
dotnet=sdk/"dotnet.exe"
env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk))
for role,files in identity["imageFiles"].items():
    image=lab/"frozen"/role
    assert len(files)==32 and {p.name:sha(p) for p in image.iterdir()}==files
    proof=quiet/(role+"-verify.json")
    subprocess.run([dotnet,image/"Lokad.Lython.Benchmarks.dll","--compare","verify","--catalog",quiet/"representative.json",
                    "--dotnet",dotnet,"--python","C:/Python313/python.exe","--python-worker",worker,"--out",proof],
                   cwd=repo,env=env,check=True,timeout=88)
    verified=read(proof)
    assert verified["state"]=="Completed" and verified["caseCount"]==5
    assert verified["catalogSha256"]==identity["catalogs"]["representative.json"]["sha256"]
    assert verified["launched"]["library"]["sha256"]==files["Lokad.Lython.dll"]

source=(template/"collect.py").read_text(encoding="utf-8")
for a,b in (("len(jobs) == 5","len(jobs) == 6"),("lython-b1762-fixtures","lython-b1763-fixtures"),
            ("warmupSeconds=7, targetBatchSeconds=.48","warmupSeconds=5, targetBatchSeconds=.44")):
    assert source.count(a)==1,a
    source=source.replace(a,b)
tree=ast.parse(source)
keys={node.slice.value for node in ast.walk(tree) if isinstance(node,ast.Subscript) and isinstance(node.value,ast.Name)
      and node.value.id=="identity" and isinstance(node.slice,ast.Constant)}
assert keys<=identity.keys(),sorted(keys-identity.keys())
compile(tree,"collect.py","exec")
write(quiet/"collect.py",source)
shutil.copyfile(template/"run.sh",quiet/"run.sh")
assert b"\r" not in (quiet/"run.sh").read_bytes()
files=[("new-core.dll",lab/"frozen/candidate/Lokad.Lython.dll")]
files += [(name,quiet/name) for name in ("identity.json","representative.json","jobs.json","collect.py","run.sh","cpython-worker.py")]
payload=quiet/"stage.tar.gz"
with tarfile.open(payload,"w:gz",compresslevel=6) as package:
    for name,path in files:package.add(path,arcname=name,recursive=False)
root="converted-dictionary-update-b1763-20261126"
donor=parent/"comparison/quiet"
donor_receipt=read(donor/"terminal-status.json")["receipt"]
assert donor_receipt["complete"] and sha(donor/"observations.tar.xz")==donor_receipt["archiveSHA256"]
save(quiet/"upload.json",dict(root=root,payloadSHA256=sha(payload),payloadBytes=payload.stat().st_size,
                             donorSHA256=donor_receipt["archiveSHA256"]))
body=(old/"quiet.py").read_text(encoding="utf-8").replace(
    "lython-b1762-buffered-csv-line-scan-20261126","lython-b1763-converted-dictionary-update-20261126")
assert "RuntimeMaxSec=278" in body and "seconds=233" in body
compile(body,"quiet.py","exec")
write(lab/"quiet.py",body)
summary=(old/"summarize-quiet.py").read_text(encoding="utf-8").replace(
    "['warmJobs'] == 5","['warmJobs'] == 6").replace("len(raw['jobs']) == 5","len(raw['jobs']) == 6")
summary=summary.replace("timedBatches=140","timedBatches=168")
compile(summary,"summarize-quiet.py","exec")
write(lab/"summarize-quiet.py",summary)

assert (old/"archive-confirmation.py").is_file()
old_receipt=read(template/"terminal-status.json")["receipt"]
assert old_receipt["complete"] and old_receipt["allWorkersJoined"] and old_receipt["guestFixturesRemoved"]
assert sha(template/"observations.tar.xz")==old_receipt["archiveSHA256"]
old_files=read(old/"local/identity.json")["imageFiles"]["candidate"]
assert len(old_files)==32 and {p.name:sha(p) for p in (old/"local/candidate").iterdir()}==old_files
minimum=payload.stat().st_size+sum(path.stat().st_size for _,path in files)+12*1024*1024
retire=[dict(root="buffered-csv-line-scan-b1762-20261126",unit="lython-b1762-buffered-csv-line-scan-20261126",
             files=old_files,raw=old_receipt["archiveSHA256"])]
tail=(old/"verify-staging-custody.py").read_text(encoding="utf-8").split("\n",1)[1]
custody="cfg="+repr(dict(retire=retire,minimum=minimum))+"\n"+tail
write(lab/"verify-staging-custody.py",custody)
remote=["ssh","-i",os.environ["LYTHON_BENCH_IDENTITY"],"-o","BatchMode=yes","-o","ConnectTimeout=12",
        os.environ["LYTHON_BENCH_HOST"],"python3 -"]
result=subprocess.check_output(remote,input=custody,encoding="utf-8",timeout=46)
save(lab/"quiet-custody.json",json.loads(result))
print(result,end="")
