from difflib import unified_diff
from pathlib import Path
import subprocess
import zipfile

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
source = lab / "candidate-source"
source.mkdir()
snapshot = lab / "candidate-source.zip"
subprocess.run(["git","archive","--format=zip","--output",snapshot,"26841dca3","--","src","tests","tools/LythonProbe",
                "benchmarks/Lokad.Lython.Benchmarks","benchmarks/scripts","benchmarks/cpython-worker.py",
                "Directory.Build.props","Directory.Build.targets","Directory.Build.rsp","Directory.Packages.props",
                "global.json","NuGet.Config"],cwd=repo,check=True)
with zipfile.ZipFile(snapshot) as archive:
    assert all(not Path(name).is_absolute() and ".." not in Path(name).parts for name in archive.namelist())
    archive.extractall(source)

patch = []
def change(name, changes):
    relative = "src/Lokad.Lython/" + name
    path = source / relative
    before = path.read_text(encoding="utf-8")
    after = before
    for old,new in changes:
        assert after.count(old)==1,(name,old)
        after = after.replace(old,new)
    path.write_text(after,encoding="utf-8",newline="\n")
    patch.extend(unified_diff(before.splitlines(keepends=True),after.splitlines(keepends=True),"a/"+relative,"b/"+relative))

change("Frontend/ExecutableScript.NativeSegments.cs", [
    ("""            if (call.OpCode != ExecutableOpCode.Call || call.HasResultConsumer
                || add.OpCode != ExecutableOpCode.Binary""",
     """            if (call.OpCode == ExecutableOpCode.Call && !call.HasResultConsumer &&
                add.OpCode == ExecutableOpCode.LoadGlobal && CanPrepareConvertedDictionaryUpdate(index, call, sites))
            {
                sites[call.CallSiteIndex] = sites[call.CallSiteIndex] with { AccumulatesDictionary = true };
                continue;
            }

            if (call.OpCode != ExecutableOpCode.Call || call.HasResultConsumer
                || add.OpCode != ExecutableOpCode.Binary"""),
    ("""    private bool CanPrepareClosureArithmetic(""",
     """    private bool CanPrepareConvertedDictionaryUpdate(int index, in ExecutableInstruction get,
        ExecutableCallSite[] sites)
    {
        if (index + 5 >= Instructions.Length ||
            sites[get.CallSiteIndex] is not { HasReceiver: true, IsPositionalOnly: true, ArgumentCount: 2 } ||
            get.HasForwardedCallOperands) return false;
        ref readonly var target = ref Instructions[index + 1];
        ref readonly var field = ref Instructions[index + 2];
        ref readonly var convert = ref Instructions[index + 3];
        ref readonly var add = ref Instructions[index + 4];
        ref readonly var store = ref Instructions[index + 5];
        if (target.HasResultConsumer || field.HasResultConsumer || convert.HasResultConsumer || add.HasResultConsumer ||
            field.OpCode != ExecutableOpCode.Subscript || !IsOrdinaryLocal(field.InputStart) ||
            (uint)~field.SecondInput >= (uint)Constants.Length || Constants[~field.SecondInput] is not PyString ||
            convert.OpCode != ExecutableOpCode.Call || convert.HasForwardedCallOperands ||
            add.OpCode != ExecutableOpCode.Binary || add.BinaryOperator != BinaryOperatorSyntax.Add ||
            store.OpCode != ExecutableOpCode.StoreSubscript || !IsOrdinaryLocal(store.SecondInput) ||
            !IsOrdinaryLocal(store.ThirdInput)) return false;

        var right = get.ResultSlot + 1;
        var conversion = sites[convert.CallSiteIndex];
        return conversion is { HasReceiver: false, IsPositionalOnly: true, ArgumentCount: 1, UnpackedReturnCount: 0 } &&
            get.LiveExtent == right && convert.ResultSlot == right && target.ResultSlot == right + conversion.TargetOffset &&
            field.ResultSlot == right + conversion.ArgumentOffset && convert.LiveExtent == right + 1 &&
            add.InputStart == get.ResultSlot && add.SecondInput == right && add.ResultSlot == get.ResultSlot &&
            add.LiveExtent == right && store.InputStart == get.ResultSlot && store.LiveExtent == get.ResultSlot &&
            !CrossesExceptionBoundary(index, index + 5);

        bool IsOrdinaryLocal(int slot) => (uint)slot < (uint)FirstTemporarySlot && !CapturedLocalSlots.Contains(slot);
    }

    private bool CanPrepareClosureArithmetic(""")
])
change("Runtime/PyDict.Accumulation.cs", [
    ("""    private bool TryAccumulateAt(int index, PyString key, uint hash, object fallback, BigInteger increment)
    {
        // Both checked query entries established native storage and exclude
        // callbacks/admission. Complete one finite update without redundant polls.
        if (index < 0 && (_recordKeys is not null || _nativeCount == _nativeItems!.Length)) return false;
        long prior;
        if (index >= 0 && _recordKeys is null && _nativeValues![index] is null)
        {
            prior = _nativeItems![index].Integer;
            if (prior < -(1L << 55) || prior >= (1L << 55)) return false;
        }
        else
        {
            var value = index < 0 ? fallback : ReadNativeValue(index);
            if (value is not BigInteger integer || integer.GetByteCount() >= 8) return false;
            prior = (long)integer;
        }

        // Both signed operands fit seven bytes. The exact result fits long;
        // wider subsequent updates retain the ordinary promotion/admission path.
        var sum = prior + (long)increment;
        var before = _nativeCount;""",
     """    // The exact get owns this probe. Its position remains usable only while
    // the interpreter proves the remaining expression cannot call or admit.
    internal bool TryPrepareConvertedAccumulation(PyString key, object fallback,
        LythonRuntime.ExecutionContext context, LythonSourceSpan span, out (int Index, uint Hash, long Prior) update)
    {
        update = default;
        if (!CanAccumulateBorrowedWords(context)) return false;
        var hash = HashNativeString(key, context, span);
        var index = FindNativeIndex(key, hash, context, span);
        if (!TryReadAccumulationValue(index, fallback, out var prior)) return false;
        update = (index, hash, prior);
        return true;
    }

    internal void CompleteConvertedAccumulation(PyString key, (int Index, uint Hash, long Prior) update, long increment)
        => StoreAccumulationValue(update.Index, key, update.Hash, update.Prior + increment);

    private bool TryReadAccumulationValue(int index, object fallback, out long prior)
    {
        prior = 0;
        if (index < 0 && (_recordKeys is not null || _nativeCount == _nativeItems!.Length)) return false;
        if (index >= 0 && _recordKeys is null && _nativeValues![index] is null)
        {
            prior = _nativeItems![index].Integer;
            return prior >= -(1L << 55) && prior < (1L << 55);
        }

        var value = index < 0 ? fallback : ReadNativeValue(index);
        if (value is not BigInteger integer || integer.GetByteCount() >= 8) return false;
        prior = (long)integer;
        return true;
    }

    private bool TryAccumulateAt(int index, PyString key, uint hash, object fallback, BigInteger increment)
    {
        // Both signed operands fit seven bytes. The exact result fits long.
        if (!TryReadAccumulationValue(index, fallback, out var prior)) return false;
        StoreAccumulationValue(index, key, hash, prior + (long)increment);
        return true;
    }

    private void StoreAccumulationValue(int index, PyString key, uint hash, long sum)
    {
        var before = _nativeCount;"""),
    ("""        if (_nativeCount != before) _version++;
        return true;
""","""        if (_nativeCount != before) _version++;
""")
])
change("Runtime/PyDict.Storage.cs", [
    ("""    // Raw scans are live; Python iteration separately checks dictionary version.""",
     """    // The caller retains the dictionary. A speculative field read does not
    // publish a native integer that would otherwise remain private.
    internal PyString? ReadNativeTextField(PyString key, LythonRuntime.ExecutionContext context, LythonSourceSpan span)
    {
        if (!SupportsNativeStringReads || _nativeValues is null) return null;
        var index = FindNativeIndex(key, HashNativeString(key, context, span), context, span);
        return index < 0 ? null : _nativeValues[index] as PyString;
    }

    // Raw scans are live; Python iteration separately checks dictionary version.""")
])
change("Runtime/PyExecutableFunction.cs", [
    ("""    private LythonRuntime.ExecutableLookupCache[]? _lookupCaches;""",
     """    private LythonRuntime.ExecutableLookupCache[]? _lookupCaches;
    internal LythonRuntime.ExecutableLookupCache[]? ExistingLookupCaches => _lookupCaches;""")
])
change("Runtime/LythonRuntime.Executable.cs", [
    ("""        internal ExecutableLookupCache[] GetLookupCaches(int count, LythonSourceSpan span)""",
     """        internal readonly ExecutableLookupCache[]? ExistingLookupCaches
            => _lookupStorage is PyExecutableFunction owner ? owner.ExistingLookupCaches : _lookupStorage as ExecutableLookupCache[];

        internal ExecutableLookupCache[] GetLookupCaches(int count, LythonSourceSpan span)""")
])
change("Runtime/LythonRuntime.Executable.DictionaryAccumulation.cs", [
    ("""            ref readonly var add = ref execution.Code.Instructions[execution.InstructionIndex + 1];
            ref readonly var store = ref execution.Code.Instructions[execution.InstructionIndex + 2];
            // Future inputs""",
     """            ref readonly var add = ref execution.Code.Instructions[execution.InstructionIndex + 1];
            if (add.OpCode == ExecutableOpCode.LoadGlobal)
                return TryExecuteConvertedDictionaryUpdate(ref execution, context, call, start, dictionary, key);

            ref readonly var store = ref execution.Code.Instructions[execution.InstructionIndex + 2];
            // Future inputs"""),
    ("""            execution.InstructionIndex += 2;
            return true;
        }
    }""",
     """            execution.InstructionIndex += 2;
            return true;
        }

        [System.Runtime.CompilerServices.MethodImpl(System.Runtime.CompilerServices.MethodImplOptions.NoInlining)]
        private static bool TryExecuteConvertedDictionaryUpdate(ref ExecutableWorkState execution, ExecutionContext context,
            ExecutableCallSite get, int start, PyDict dictionary, PyString key)
        {
            var code = execution.Code;
            var index = execution.InstructionIndex;
            ref readonly var store = ref code.Instructions[index + 5];
            if (!ReferenceEquals(execution.Locals[store.SecondInput].Reference, dictionary) ||
                !ReferenceEquals(execution.Locals[store.ThirdInput].Reference, key)) return false;

            // Read the original left operand before resolving the converter.
            // The probe and small-decimal conversion cannot admit or call
            // Python. Any other work resumes the unchanged instruction tape.
            var fallback = execution.Stack[start + get.ArgumentOffset + 1];
            (int Index, uint Hash, long Prior) update;
            context.EnterInterpreterFrame(get.CallSpan);
            try
            {
                if (!dictionary.TryPrepareConvertedAccumulation(key, fallback, context, get.CallSpan, out update)) return false;
            }
            finally { context.LeaveInterpreterFrame(); }

            ref readonly var target = ref code.Instructions[index + 1];
            context.CheckExecution(target.Span);
            if (!TryResolveExecutableGlobal(code, target.NameIndex, context, out var converter) ||
                converter is not BuiltinCallable { Name: "int" }) return false;

            ref readonly var field = ref code.Instructions[index + 2];
            context.CheckExecution(field.Span);
            if (execution.Locals[field.InputStart].Reference is not PyDict { SupportsNativeStringReads: true } record)
                return false;
            var fieldName = (PyString)code.Constants[~field.SecondInput]!;
            PyString? value;
            if (record.HasSharedRecordKeys && field.LookupCacheIndex >= 0)
            {
                // The ordinary instruction owns first admission and any
                // reentry. Only borrow its already established backing.
                if (execution.Stack.ExistingLookupCaches is not { } caches ||
                    !record.TryReadRecordValue(fieldName, ref caches[field.LookupCacheIndex], context, field.Span,
                        out var cached)) return false;
                value = cached as PyString;
            }
            else value = record.ReadNativeTextField(fieldName, context, field.Span);
            if (value is null) return false;

            ref readonly var convert = ref code.Instructions[index + 3];
            var conversion = code.CallSites[convert.CallSiteIndex];
            context.CheckExecution(convert.Span);
            long increment;
            context.EnterInterpreterFrame(conversion.CallSpan);
            try
            {
                if (!TryParseShortDecimal(value.Utf8Span, out increment) || increment < -(1L << 55) ||
                    increment >= (1L << 55)) return false;
            }
            finally { context.LeaveInterpreterFrame(); }

            context.CheckExecution(code.Instructions[index + 4].Span);
            context.CheckExecution((LythonSourceSpan)code.Constants[store.TargetSpanIndex]!);
            dictionary.CompleteConvertedAccumulation(key, update, increment);
            execution.Stack.RetireTo(store.LiveExtent);
            execution.InstructionIndex = index + 5;
            return true;
        }
    }""")
])
(lab/"candidate.patch").write_text("".join(patch),encoding="utf-8",newline="\n")
