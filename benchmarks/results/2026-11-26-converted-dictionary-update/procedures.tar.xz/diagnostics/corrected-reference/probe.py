from difflib import unified_diff
from pathlib import Path
import base64
import csv
import hashlib
import io
import json
import os
import shutil
import subprocess
import tempfile
import zipfile

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
previous = lab.with_name("shipment-integer-store-20261126")
frozen = lab.with_name("csv-window-source-gate-20261126") / "local"
read = lambda p: json.loads(p.read_text(encoding="utf-8"))
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
write = lambda p, text: p.write_text(text, encoding="utf-8", newline="\n")
dump = lambda data: json.dumps(data, ensure_ascii=False, separators=(",", ":"))
digest_text = lambda text: hashlib.sha256(text.encode("utf-8")).hexdigest()
git = lambda *args: subprocess.check_output(["git", *args], cwd=repo)
revision = git("rev-parse", "HEAD").decode().strip()
reference = read(frozen / "identity.json")
assert not git("diff", reference["sourceRevision"], revision, "--", "src")
original = reference["imageFiles"]["reference"]
assert len(original) == 32 and {p.name:sha(p) for p in (frozen / "reference").iterdir()} == original

catalog = read(previous / "representative.json")
cases = {row["id"]: row for row in catalog["cases"]}
ordinary = cases["diagnostic.shipment-routing-callbacks"]
fixture = json.loads(ordinary["fixtureJson"])
assert set(fixture["inputFiles"]) == {"shipments.csv"} and not fixture["outputFiles"]
csv_text = base64.b64decode(fixture["inputFiles"]["shipments.csv"]).decode("utf-8")
records = []
for row in csv.DictReader(io.StringIO(csv_text)):
    service = "review" if row["hold"] == "yes" else "priority" if row["late"] == "yes" else "standard"
    records.append({"service": service, "quantity": row["quantity"]})
assert len(records) == 2048
json_text = dump(records)
script = """import json

def tally(source):
    totals = {}
    for row in json.load(source):
        service = row['service']
        totals[service] = totals.get(service, 0) + int(row['quantity'])
    return totals

with open('shipments.json', encoding='utf-8') as source:
    totals = tally(source)
for name in sorted(totals):
    print(name, totals[name])
"""
with tempfile.TemporaryDirectory(prefix="lython-derived-fixture-") as directory:
    (Path(directory)/"shipments.json").write_bytes(json_text.encode("utf-8"))
    output = subprocess.check_output(["C:/Python313/python.exe","-I","-S","-X","utf8","-c",script],
                                     cwd=directory).decode("utf-8").replace("\r\n","\n")
new_fixture = dump(fixture | {"inputFiles":{"shipments.json":base64.b64encode(json_text.encode("utf-8")).decode("ascii")}})
derived = ordinary | dict(id="diagnostic.json-service-quantity-totals",
                          source=script, expectedOutput=output, fixtureJson=new_fixture,
                          sourceSha256=digest_text(script), sourceUtf8Bytes=len(script.encode("utf-8")),
                          expectedOutputSha256=digest_text(output), expectedOutputUtf8Bytes=len(output.encode("utf-8")),
                          fixtureSha256=digest_text(new_fixture))
cases = [ordinary, cases["diagnostic.shipment-bound-starmap"], derived, cases["diagnostic.shipment-file-fed-map"]]
catalog["cases"] = cases
write(lab/"representative.json", dump(catalog))
write(lab/"cases.json", dump(catalog | {"cases":[row|dict(runAsync=mode) for row in cases for mode in (False,True)]}))

snapshot=lab/"source.zip"
subprocess.run(["git","archive","--format=zip","--output",snapshot,revision,"--","src","Directory.Build.props",
                "Directory.Build.targets","Directory.Build.rsp","Directory.Packages.props","global.json","NuGet.Config"],cwd=repo,check=True)
source=lab/"source"
with zipfile.ZipFile(snapshot) as archive:
    assert all(not Path(name).is_absolute() and ".." not in Path(name).parts for name in archive.namelist())
    archive.extractall(source)

runtime = "src/Lokad.Lython/Runtime/"
patch = []
def insert(name, changes):
    name = runtime+name
    path = source/name
    old_text = path.read_text(encoding="utf-8")
    edited = old_text
    for before, after in changes:
        assert edited.count(before)==1, (name,before)
        edited = edited.replace(before,after)
    write(path,edited)
    patch.extend(unified_diff(old_text.splitlines(keepends=True),edited.splitlines(keepends=True),"a/"+name,"b/"+name))

names = ["ConvertedFrameGetSites","ConvertedNativePrefixGetSites","NativeGet","NativeGetIntegers",
         "ShortIntText","TemporaryIntegerStores","NativePrefixIntegerStores","LazyDictionaryIntegerReads"]
fields = "".join(f"    internal static int Diagnostic{name};\n" for name in names)
frame_site = "                    var receiver = execution.Stack[start];"
insert("LythonRuntime.Executable.Calls.Invoke.cs", [
    ("    internal sealed partial class ExecutionContext\n", fields + """
    private static bool DiagnosticConvertedGetTape(ExecutableCodeObject code, int index)
    {
        if (index + 5 >= code.Instructions.Length) return false;
        var tail = code.Instructions.AsSpan(index + 1, 5);
        return tail[0].OpCode == ExecutableOpCode.LoadGlobal && tail[1].OpCode == ExecutableOpCode.Subscript
            && tail[2].OpCode == ExecutableOpCode.Call && tail[3].OpCode == ExecutableOpCode.Binary
            && tail[3].BinaryOperator == BinaryOperatorSyntax.Add && tail[4].OpCode == ExecutableOpCode.StoreSubscript;
    }

    internal sealed partial class ExecutionContext
"""),
    (frame_site, frame_site + """
                    if (ReferenceEquals(method, ReceiverMethods.DictionaryGet) &&
                        DiagnosticConvertedGetTape(execution.Code, execution.InstructionIndex))
                        Interlocked.Increment(ref DiagnosticConvertedFrameGetSites);""")
])
native_site = "                    var receiver = Values[start].Object!;"
native_store = """            // Growth and protocol keys transfer before the dictionary is changed.
            var first = Read(instruction.InputStart, 0);"""
insert("LythonRuntime.Executable.NativePrefix.cs", [
    (native_site,native_site+"""
                    if (ReferenceEquals(method, ReceiverMethods.DictionaryGet) && DiagnosticConvertedGetTape(Code, Index))
                        Interlocked.Increment(ref DiagnosticConvertedNativePrefixGetSites);"""),
    (native_store, """            // Growth and protocol keys transfer before the dictionary is changed.
            var valueSlot = instruction.ValueLast ? instruction.ThirdInput : instruction.InputStart;
            if (valueSlot >= Code.FirstTemporarySlot && Values[valueSlot].IsUnpublishedInteger)
                Interlocked.Increment(ref DiagnosticNativePrefixIntegerStores);
            var first = Read(instruction.InputStart, 0);""")
])
store = """            pendingSpan = null;
            var first = ReadOperand(ref execution, instruction.InputStart, scope, 0);"""
insert("LythonRuntime.Executable.Inputs.cs", [
    (store, """            pendingSpan = null;
            var valueSlot = instruction.ValueLast ? instruction.ThirdInput : instruction.InputStart;
            if (valueSlot >= execution.Code.FirstTemporarySlot && execution.Stack.Values[valueSlot].IsUnpublishedInteger)
                Interlocked.Increment(ref DiagnosticTemporaryIntegerStores);
            var first = ReadOperand(ref execution, instruction.InputStart, scope, 0);""")
])
insert("LythonRuntime.Calls.cs", [
    ("            return DictMembers.Get(receiver, key, fallback, span, context);", """            var value = DictMembers.Get(receiver, key, fallback, span, context);
            if (key is PyString && receiver.SupportsBorrowedTextKeys)
            {
                Interlocked.Increment(ref DiagnosticNativeGet);
                if (value is System.Numerics.BigInteger)
                    Interlocked.Increment(ref DiagnosticNativeGetIntegers);
            }
            return value;""")
])
insert("LythonRuntime.Builtins.cs", [
    ("        if (TryParseShortDecimal(utf8, out var small)) return ExecutableSlot.FromInteger(small);",
     """        if (TryParseShortDecimal(utf8, out var small))
        {
            Interlocked.Increment(ref DiagnosticShortIntText);
            return ExecutableSlot.FromInteger(small);
        }""")
])
insert("PyDict.Storage.cs", [
    ("            : _nativeValues[index] ??= new BigInteger(_nativeItems![index].Integer);",
     """            : _nativeValues[index] ??= DiagnosticBoxNativeInteger(_nativeItems![index].Integer);

    private static object DiagnosticBoxNativeInteger(long value)
    {
        Interlocked.Increment(ref LythonRuntime.DiagnosticLazyDictionaryIntegerReads);
        return new BigInteger(value);
    }""")
])
write(lab/"diagnostic.patch","".join(patch))

program=(previous/"Program.cs").read_text(encoding="utf-8")
program=program.replace('["IntegerStoreCandidates", "IntegerStoreExisting", "IntegerStoreNativePrefix", "IntegerStorePackedKeys"]',
                        json.dumps(names)).replace("Lokad.Lython.Runtime.LythonRuntime+ExecutionContext",
                                                   "Lokad.Lython.Runtime.LythonRuntime")
write(lab/"Program.cs",program)
shutil.copyfile(previous/"RouteProbe.csproj",lab/"RouteProbe.csproj")
image=lab/"image"
image.mkdir()
for name, digest in original.items():
    shutil.copyfile(frozen/"reference"/name,image/name)
    assert sha(image/name)==digest
sdk=Path.home()/".dotnet11"
dotnet=sdk/"dotnet.exe"
env=dict(os.environ,DOTNET_ROOT=str(sdk))
def run(args,log):
    with (lab/log).open("wb") as stream:
        subprocess.run([dotnet,*args],stdout=stream,stderr=subprocess.STDOUT,env=env,cwd=repo,check=True,timeout=180)
run(["build",source/"src/Lokad.Lython/Lokad.Lython.csproj","-c","Release","-f","net11.0","--no-incremental",
     "-o",lab/"core"],"core.log")
shutil.copyfile(lab/"core/Lokad.Lython.dll",image/"Lokad.Lython.dll")
run(["build",lab/"RouteProbe.csproj","-c","Release","-o",lab/"probe"],"probe.log")
for item in (lab/"probe").glob("RouteProbe*"):
    shutil.copyfile(item,image/item.name)
run([image/"RouteProbe.dll",image,lab/"cases.json",lab/"routes.json"],"verify.log")
record=dict(referenceRevision=revision,runtimeRevision=reference["sourceRevision"],baseImage=original,
            diagnosticCoreSHA256=sha(image/"Lokad.Lython.dll"), patchSHA256=sha(lab/"diagnostic.patch"),
            casesSHA256=sha(lab/"cases.json"), catalogSHA256=sha(lab/"representative.json"))
write(lab/"identity.json",json.dumps(record,indent=2)+"\n")
for row in read(lab/"routes.json")["rows"]:
    print(row["id"],row["asynchronous"],row["routes"])
