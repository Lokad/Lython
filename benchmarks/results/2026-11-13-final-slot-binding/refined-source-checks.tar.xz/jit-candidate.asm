; Assembly listing for method Lokad.Lython.Runtime.PyExecutableFunction:StartNativeCall(Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[System.Object],System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,bool,bool,System.Span`1[System.Object],byref,byref,byref):this (Instrumented Tier0)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; Instrumented Tier0 code
; rbp based frame
; partially interruptible
; compiling with minopt

G_M000_IG01:
       push     rbp
       sub      rsp, 656
       lea      rbp, [rsp+0x290]
       xor      eax, eax
       mov      qword ptr [rbp-0x238], rax
       vxorps   xmm4, xmm4, xmm4
       vmovdqa  xmmword ptr [rbp-0x230], xmm4
       mov      rax, -480
 
G_M000_IG27:
       vmovdqa  xmmword ptr [rbp+rax-0x40], xmm4
       vmovdqa  xmmword ptr [rbp+rax-0x30], xmm4
       vmovdqa  xmmword ptr [rbp+rax-0x20], xmm4
       add      rax, 48
       jne      SHORT G_M000_IG27
       mov      qword ptr [rbp-0x40], rax
       mov      gword ptr [rbp+0x10], rcx
       mov      gword ptr [rbp+0x18], rdx
       mov      bword ptr [rbp+0x20], r8
       mov      gword ptr [rbp+0x28], r9
 
G_M000_IG02:
       mov      dword ptr [rbp-0x174], 0x3E8
       vxorps   ymm0, ymm0, ymm0
       vmovdqu  ymmword ptr [rbp-0xB8], ymm0
       vmovdqu  ymmword ptr [rbp-0x98], ymm0
       vmovdqu  ymmword ptr [rbp-0x78], ymm0
       vmovdqu  ymmword ptr [rbp-0x58], ymm0
       lea      r8, [rbp-0xB8]
       lea      rcx, [rbp-0xC8]
       mov      rdx, 0xD1FFAB1E
       mov      r9d, 16
       call     [<PrivateImplementationDetails>:InlineArrayAsSpan[Lokad.Lython.Runtime.PyExecutableFunction+NativeValues,System.__Canon](byref,int):System.Span`1[System.__Canon]]
       mov      rax, gword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax+0x68]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_ValueStorageCapacity():int:this]
       mov      dword ptr [rbp-0x178], eax
       mov      eax, dword ptr [rbp-0x178]
       mov      dword ptr [rsp+0x20], eax
       lea      rcx, [rbp-0xC8]
       lea      rdx, [rbp-0xC8]
       mov      r8, 0xD1FFAB1E
       xor      r9d, r9d
       call     [System.Span`1[System.__Canon]:Slice(int,int):System.Span`1[System.__Canon]:this]
       mov      rcx, gword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.PyFunctionBase:get_BindingPlan():Lokad.Lython.Runtime.FunctionBindingPlan:this]
       mov      rcx, rax
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_ParameterCount():int:this]
       mov      dword ptr [rbp-0x17C], eax
       mov      edx, dword ptr [rbp-0x17C]
       lea      rcx, [rbp-0xE0]
       call     [Lokad.Lython.Runtime.ArgumentPresence:.ctor(int):this]
       movzx    rax, byte  ptr [rbp+0x48]
       test     eax, eax
       je       G_M000_IG09
 
G_M000_IG03:
       vmovdqu  xmm0, xmmword ptr [rbp-0xC8]
       vmovdqu  xmmword ptr [rbp-0x190], xmm0
 
G_M000_IG04:
       lea      r8, [rbp-0x190]
       mov      rcx, bword ptr [rbp+0x20]
       mov      rdx, 0xD1FFAB1E
       call     [System.ReadOnlySpan`1[System.__Canon]:CopyTo(System.Span`1[System.__Canon]):this]
       xor      eax, eax
       mov      dword ptr [rbp-0xE4], eax
       jmp      SHORT G_M000_IG06
 
G_M000_IG05:
       mov      rcx, 0xD1FFAB1E
       call     CORINFO_HELP_COUNTPROFILE32
       lea      rcx, [rbp-0xE0]
       mov      edx, dword ptr [rbp-0xE4]
       mov      r8d, 1
       call     [Lokad.Lython.Runtime.ArgumentPresence:set_Item(int,bool):this]
       mov      eax, dword ptr [rbp-0xE4]
       inc      eax
       mov      dword ptr [rbp-0xE4], eax
 
G_M000_IG06:
       mov      eax, dword ptr [rbp-0x174]
       dec      eax
       mov      dword ptr [rbp-0x174], eax
       cmp      dword ptr [rbp-0x174], 0
       jg       SHORT G_M000_IG08
 
G_M000_IG07:
       lea      rcx, [rbp-0x174]
       mov      edx, 85
       call     CORINFO_HELP_PATCHPOINT
       jmp      rax
 
G_M000_IG08:
       lea      rcx, [rbp-0xE0]
       call     [Lokad.Lython.Runtime.ArgumentPresence:get_Length():int:this]
       cmp      eax, dword ptr [rbp-0xE4]
       jg       SHORT G_M000_IG05
       jmp      G_M000_IG16
 
G_M000_IG09:
       mov      rcx, 0xD1FFAB1E
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, gword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.PyFunctionBase:get_BindingPlan():Lokad.Lython.Runtime.FunctionBindingPlan:this]
       mov      rcx, rax
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_ParameterCount():int:this]
       mov      dword ptr [rbp-0x194], eax
       mov      eax, dword ptr [rbp-0x194]
       mov      dword ptr [rsp+0x20], eax
       lea      rcx, [rbp-0xC8]
       lea      rdx, [rbp-0x138]
       mov      r8, 0xD1FFAB1E
       xor      r9d, r9d
       call     [System.Span`1[System.__Canon]:Slice(int,int):System.Span`1[System.__Canon]:this]
       vxorps   xmm0, xmm0, xmm0
       vmovdqu  xmmword ptr [rbp-0xF8], xmm0
 
G_M000_IG10:
       vmovdqu  xmm0, xmmword ptr [rbp-0xF8]
       vmovdqu  xmmword ptr [rbp-0x148], xmm0
 
G_M000_IG11:
       vmovdqu  xmm0, xmmword ptr [rbp-0x138]
       vmovdqu  xmmword ptr [rbp-0x1A8], xmm0
 
G_M000_IG12:
       vmovdqu  xmm0, xmmword ptr [rbp-0x148]
       vmovdqu  xmmword ptr [rbp-0x1B8], xmm0
 
G_M000_IG13:
       mov      rcx, gword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.PyFunctionBase:get_BindingPlan():Lokad.Lython.Runtime.FunctionBindingPlan:this]
       mov      gword ptr [rbp-0x1D0], rax
       mov      rax, gword ptr [rbp+0x30]
       mov      gword ptr [rsp+0x28], rax
       xor      eax, eax
       mov      dword ptr [rsp+0x30], eax
       mov      rax, gword ptr [rbp+0x28]
       mov      gword ptr [rsp+0x38], rax
       mov      rax, gword ptr [rbp+0x18]
       mov      gword ptr [rsp+0x40], rax
       mov      rax, bword ptr [rbp+0x20]
 
G_M000_IG14:
       vmovdqu  xmm0, xmmword ptr [rax]
       vmovdqu  xmmword ptr [rbp-0x1C8], xmm0
 
G_M000_IG15:
       mov      rax, gword ptr [rbp-0x1D0]
       mov      gword ptr [rsp+0x20], rax
       lea      r8, [rbp-0x1B8]
       lea      rcx, [rbp-0x1A8]
       lea      rax, [rbp-0x1C8]
       mov      qword ptr [rsp+0x48], rax
       lea      rdx, [rbp-0xE0]
       mov      r9, gword ptr [rbp+0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime:BindFunctionArgumentsInto(System.Span`1[System.Object],byref,System.ReadOnlySpan`1[Lokad.Lython.Runtime.CallArgumentValue],Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.FunctionBindingPlan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,bool,System.Object,Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[System.Object])]
 
G_M000_IG16:
       mov      rcx, 0xD1FFAB1E
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG17:
       vmovdqu  xmm0, xmmword ptr [rbp-0xC8]
       vmovdqu  xmmword ptr [rbp-0x158], xmm0
 
G_M000_IG18:
       vmovdqu  xmm0, xmmword ptr [rbp-0xE0]
       vmovdqu  xmmword ptr [rbp-0x170], xmm0
       mov      rax, qword ptr [rbp-0xD0]
       mov      qword ptr [rbp-0x160], rax
 
G_M000_IG19:
       vxorps   ymm0, ymm0, ymm0
       vmovdqu  ymmword ptr [rbp-0x128], ymm0
       vmovdqu  xmmword ptr [rbp-0x108], xmm0
 
G_M000_IG20:
       vmovdqu  xmm0, xmmword ptr [rbp-0x158]
       vmovdqu  xmmword ptr [rbp-0x1E0], xmm0
 
G_M000_IG21:
       vmovdqu  xmm0, xmmword ptr [rbp-0x170]
       vmovdqu  xmmword ptr [rbp-0x1F8], xmm0
       mov      rax, qword ptr [rbp-0x160]
       mov      qword ptr [rbp-0x1E8], rax
 
G_M000_IG22:
       vmovdqu  ymm0, ymmword ptr [rbp-0x128]
       vmovdqu  ymmword ptr [rbp-0x228], ymm0
       vmovdqu  xmm0, xmmword ptr [rbp-0x108]
       vmovdqu  xmmword ptr [rbp-0x208], xmm0
 
G_M000_IG23:
       mov      rax, gword ptr [rbp+0x38]
       mov      gword ptr [rsp+0x20], rax
       movzx    rax, byte  ptr [rbp+0x40]
       mov      dword ptr [rsp+0x28], eax
       mov      rax, bword ptr [rbp+0x50]
 
G_M000_IG24:
       vmovdqu  xmm0, xmmword ptr [rax]
       vmovdqu  xmmword ptr [rbp-0x238], xmm0
 
G_M000_IG25:
       mov      rax, bword ptr [rbp+0x58]
       mov      bword ptr [rsp+0x38], rax
       mov      rax, bword ptr [rbp+0x60]
       mov      bword ptr [rsp+0x40], rax
       mov      rax, bword ptr [rbp+0x68]
       mov      bword ptr [rsp+0x48], rax
       lea      rdx, [rbp-0x1E0]
       lea      r8, [rbp-0x1F8]
       lea      r9, [rbp-0x228]
       lea      rax, [rbp-0x238]
       mov      qword ptr [rsp+0x30], rax
       mov      rcx, gword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.PyExecutableFunction:StartInline(System.Span`1[System.Object],Lokad.Lython.Runtime.ArgumentPresence,System.Nullable`1[Lokad.Lython.Runtime.BoundCallArguments],Lokad.Lython.LythonSourceSpan,bool,System.Span`1[System.Object],byref,byref,byref):this]
       nop      
 
G_M000_IG26:
       vzeroupper 
       add      rsp, 656
       pop      rbp
       ret      
 
; Total bytes of code 1006

; Assembly listing for method Lokad.Lython.Runtime.LythonRuntime:BindFunctionArgumentsInto(System.Span`1[System.Object],byref,System.ReadOnlySpan`1[Lokad.Lython.Runtime.CallArgumentValue],Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.FunctionBindingPlan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,bool,System.Object,Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[System.Object]) (Instrumented Tier0)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; Instrumented Tier0 code
; rbp based frame
; fully interruptible
; compiling with minopt

G_M000_IG01:
       push     rbp
       sub      rsp, 576
       lea      rbp, [rsp+0x240]
       vxorps   xmm4, xmm4, xmm4
       vmovdqa  xmmword ptr [rbp-0x1E0], xmm4
       vmovdqa  xmmword ptr [rbp-0x1D0], xmm4
       mov      rax, -384
 
G_M000_IG56:
       vmovdqa  xmmword ptr [rbp+rax-0x40], xmm4
       vmovdqa  xmmword ptr [rbp+rax-0x30], xmm4
       vmovdqa  xmmword ptr [rbp+rax-0x20], xmm4
       add      rax, 48
       jne      SHORT G_M000_IG56
       mov      qword ptr [rbp-0x40], rax
       mov      bword ptr [rbp+0x10], rcx
       mov      bword ptr [rbp+0x18], rdx
       mov      bword ptr [rbp+0x20], r8
       mov      gword ptr [rbp+0x28], r9
 
G_M000_IG02:
       mov      dword ptr [rbp-0x16C], 0x3E8
       xor      rax, rax
       mov      gword ptr [rbp-0x40], rax
       xor      rax, rax
       mov      gword ptr [rbp-0x48], rax
       xor      eax, eax
       mov      dword ptr [rbp-0x4C], eax
       mov      rcx, gword ptr [rbp+0x30]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_VariadicListIndex():int:this]
       test     eax, eax
       jge      SHORT G_M000_IG04
       cmp      gword ptr [rbp+0x50], 0
       jne      SHORT G_M000_IG03
       mov      rcx, bword ptr [rbp+0x20]
       call     [System.ReadOnlySpan`1[Lokad.Lython.Runtime.CallArgumentValue]:get_IsEmpty():bool:this]
       mov      dword ptr [rbp-0xF4], eax
       jmp      SHORT G_M000_IG05
 
G_M000_IG03:
       mov      rcx, 0xD1FFAB1E
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, gword ptr [rbp+0x50]
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_IsPositionalOnly():bool:this]
       mov      dword ptr [rbp-0xF4], eax
       jmp      SHORT G_M000_IG05
 
G_M000_IG04:
       mov      rcx, 0xD1FFAB1E
       call     CORINFO_HELP_COUNTPROFILE32
       xor      eax, eax
       mov      dword ptr [rbp-0xF4], eax
 
G_M000_IG05:
       cmp      dword ptr [rbp-0xF4], 0
       je       G_M000_IG13
       cmp      gword ptr [rbp+0x48], 0
       setne    al
       movzx    rax, al
       mov      dword ptr [rbp-0x50], eax
       mov      rax, bword ptr [rbp+0x58]
       mov      eax, dword ptr [rax+0x08]
       mov      dword ptr [rbp-0x154], eax
       mov      rcx, gword ptr [rbp+0x30]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_PositionalCount():int:this]
       sub      eax, dword ptr [rbp-0x50]
       cmp      eax, dword ptr [rbp-0x154]
       jge      SHORT G_M000_IG07
 
G_M000_IG06:
       mov      rcx, gword ptr [rbp+0x30]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_CallableKind():int:this]
       mov      dword ptr [rbp-0x168], eax
       mov      rcx, gword ptr [rbp+0x30]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_CallableName():System.String:this]
       mov      gword ptr [rbp-0x178], rax
       mov      rdx, gword ptr [rbp-0x178]
       mov      ecx, dword ptr [rbp-0x168]
       mov      r8, gword ptr [rbp+0x28]
       call     [Lokad.Lython.Runtime.CallErrors:TooManyPositional(int,System.String,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.LythonRuntimeException]
       mov      rcx, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG07:
       cmp      gword ptr [rbp+0x48], 0
       je       SHORT G_M000_IG08
       mov      rcx, 0xD1FFAB1E
       call     CORINFO_HELP_COUNTPROFILE32
       mov      eax, dword ptr [rbp-0x4C]
       mov      dword ptr [rbp-0x164], eax
       mov      eax, dword ptr [rbp-0x4C]
       inc      eax
       mov      dword ptr [rbp-0x4C], eax
       mov      rax, bword ptr [rbp+0x10]
       mov      eax, dword ptr [rax+0x08]
       cmp      dword ptr [rbp-0x164], eax
       jae      G_M000_IG52
       mov      rax, bword ptr [rbp+0x10]
       mov      rax, bword ptr [rax]
       mov      ecx, dword ptr [rbp-0x164]
       lea      rcx, bword ptr [rax+8*rcx]
       mov      rdx, gword ptr [rbp+0x48]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
 
G_M000_IG08:
       xor      eax, eax
       mov      dword ptr [rbp-0x54], eax
       jmp      G_M000_IG10
 
G_M000_IG09:
       mov      rcx, 0xD1FFAB1E
       call     CORINFO_HELP_COUNTPROFILE32
       mov      eax, dword ptr [rbp-0x4C]
       mov      dword ptr [rbp-0x158], eax
       mov      eax, dword ptr [rbp-0x4C]
       inc      eax
       mov      dword ptr [rbp-0x4C], eax
       mov      rax, bword ptr [rbp+0x10]
       mov      eax, dword ptr [rax+0x08]
       cmp      dword ptr [rbp-0x158], eax
       jae      G_M000_IG52
       mov      rax, bword ptr [rbp+0x10]
       mov      rax, bword ptr [rax]
       mov      ecx, dword ptr [rbp-0x158]
       lea      rax, bword ptr [rax+8*rcx]
       mov      bword ptr [rbp-0x160], rax
       mov      rax, bword ptr [rbp+0x58]
       mov      eax, dword ptr [rax+0x08]
       cmp      dword ptr [rbp-0x54], eax
       jae      G_M000_IG52
       mov      rax, bword ptr [rbp+0x58]
       mov      rax, bword ptr [rax]
       mov      ecx, dword ptr [rbp-0x54]
       mov      rdx, gword ptr [rax+8*rcx]
       mov      rcx, 0xD1FFAB1E
       call     [Lokad.Lython.Internal.NullabilityExtensions:RequireNotNull[System.__Canon](System.__Canon):System.__Canon]
       mov      rdx, rax
       mov      rcx, bword ptr [rbp-0x160]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      eax, dword ptr [rbp-0x54]
       inc      eax
       mov      dword ptr [rbp-0x54], eax
 
G_M000_IG10:
       mov      eax, dword ptr [rbp-0x16C]
       dec      eax
       mov      dword ptr [rbp-0x16C], eax
       cmp      dword ptr [rbp-0x16C], 0
       jg       SHORT G_M000_IG12
 
G_M000_IG11:
       lea      rcx, [rbp-0x16C]
       mov      edx, 144
       call     CORINFO_HELP_PATCHPOINT
       jmp      rax
 
G_M000_IG12:
       mov      rax, bword ptr [rbp+0x58]
       mov      eax, dword ptr [rax+0x08]
       cmp      eax, dword ptr [rbp-0x54]
       jg       G_M000_IG09
       mov      rcx, bword ptr [rbp+0x18]
       mov      r8d, dword ptr [rbp-0x4C]
       xor      edx, edx
       call     [Lokad.Lython.Runtime.ArgumentPresence:MarkRange(int,int):this]
       jmp      G_M000_IG20
 
G_M000_IG13:
       mov      rcx, 0xD1FFAB1E
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x10]
 
G_M000_IG14:
       vmovdqu  xmm0, xmmword ptr [rax]
       vmovdqu  xmmword ptr [rbp-0x188], xmm0
 
G_M000_IG15:
       mov      rax, bword ptr [rbp+0x20]
 
G_M000_IG16:
       vmovdqu  xmm0, xmmword ptr [rax]
       vmovdqu  xmmword ptr [rbp-0x198], xmm0
 
G_M000_IG17:
       mov      rax, gword ptr [rbp+0x30]
       mov      gword ptr [rsp+0x20], rax
       mov      rax, gword ptr [rbp+0x38]
       mov      gword ptr [rsp+0x28], rax
       mov      rax, gword ptr [rbp+0x48]
       mov      gword ptr [rsp+0x30], rax
       mov      rax, gword ptr [rbp+0x50]
       mov      gword ptr [rsp+0x38], rax
       mov      rax, bword ptr [rbp+0x58]
 
G_M000_IG18:
       vmovdqu  xmm0, xmmword ptr [rax]
       vmovdqu  xmmword ptr [rbp-0x1A8], xmm0
 
G_M000_IG19:
       lea      rax, [rbp-0x40]
       mov      qword ptr [rsp+0x48], rax
       lea      rax, [rbp-0x48]
       mov      qword ptr [rsp+0x50], rax
       lea      rcx, [rbp-0x188]
       lea      r8, [rbp-0x198]
       lea      rax, [rbp-0x1A8]
       mov      qword ptr [rsp+0x40], rax
       mov      r9, gword ptr [rbp+0x28]
       mov      rdx, bword ptr [rbp+0x18]
       call     [Lokad.Lython.Runtime.LythonRuntime:BindSuppliedFunctionArguments(System.Span`1[System.Object],byref,System.ReadOnlySpan`1[Lokad.Lython.Runtime.CallArgumentValue],Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.FunctionBindingPlan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,System.Object,Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[System.Object],byref,byref)]
 
G_M000_IG20:
       xor      eax, eax
       mov      dword ptr [rbp-0x58], eax
       jmp      G_M000_IG24
 
G_M000_IG21:
       mov      rcx, bword ptr [rbp+0x18]
       mov      edx, dword ptr [rbp-0x58]
       call     [Lokad.Lython.Runtime.ArgumentPresence:get_Item(int):bool:this]
       test     eax, eax
       jne      G_M000_IG23
       mov      rcx, gword ptr [rbp+0x30]
       mov      edx, dword ptr [rbp-0x58]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:NameAt(int):System.String:this]
       mov      gword ptr [rbp-0x60], rax
       lea      r8, [rbp-0x68]
       mov      rcx, gword ptr [rbp+0x30]
       mov      edx, dword ptr [rbp-0x58]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:TryGetPositionalDefault(int,byref):bool:this]
       test     eax, eax
       je       SHORT G_M000_IG22
       mov      rcx, 0xD1FFAB1E
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x10]
       mov      eax, dword ptr [rax+0x08]
       cmp      dword ptr [rbp-0x58], eax
       jae      G_M000_IG52
       mov      rax, bword ptr [rbp+0x10]
       mov      rax, bword ptr [rax]
       mov      ecx, dword ptr [rbp-0x58]
       lea      rcx, bword ptr [rax+8*rcx]
       mov      rdx, gword ptr [rbp-0x68]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       jmp      SHORT G_M000_IG23
 
G_M000_IG22:
       mov      rcx, gword ptr [rbp+0x30]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_CallableKind():int:this]
       mov      dword ptr [rbp-0xF8], eax
       mov      rcx, gword ptr [rbp+0x30]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_CallableName():System.String:this]
       mov      gword ptr [rbp-0x1B0], rax
       mov      rdx, gword ptr [rbp-0x1B0]
       mov      ecx, dword ptr [rbp-0xF8]
       mov      r8, gword ptr [rbp-0x60]
       mov      r9, gword ptr [rbp+0x28]
       call     [Lokad.Lython.Runtime.CallErrors:MissingArgument(int,System.String,System.String,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.LythonRuntimeException]
       mov      rcx, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG23:
       mov      rcx, 0xD1FFAB1E
       call     CORINFO_HELP_COUNTPROFILE32
       mov      eax, dword ptr [rbp-0x58]
       inc      eax
       mov      dword ptr [rbp-0x58], eax
 
G_M000_IG24:
       mov      eax, dword ptr [rbp-0x16C]
       dec      eax
       mov      dword ptr [rbp-0x16C], eax
       cmp      dword ptr [rbp-0x16C], 0
       jg       SHORT G_M000_IG26
 
G_M000_IG25:
       lea      rcx, [rbp-0x16C]
       mov      edx, 270
       call     CORINFO_HELP_PATCHPOINT
       jmp      rax
 
G_M000_IG26:
       mov      rcx, gword ptr [rbp+0x30]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_PositionalCount():int:this]
       cmp      eax, dword ptr [rbp-0x58]
       jg       G_M000_IG21
       xor      eax, eax
       mov      dword ptr [rbp-0x6C], eax
       jmp      G_M000_IG32
 
G_M000_IG27:
       mov      rcx, gword ptr [rbp+0x30]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_PositionalCount():int:this]
       add      eax, dword ptr [rbp-0x6C]
       mov      dword ptr [rbp-0x70], eax
       mov      rcx, bword ptr [rbp+0x18]
       mov      edx, dword ptr [rbp-0x70]
       call     [Lokad.Lython.Runtime.ArgumentPresence:get_Item(int):bool:this]
       test     eax, eax
       jne      G_M000_IG31
       mov      rcx, gword ptr [rbp+0x30]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_PositionalCount():int:this]
       add      eax, dword ptr [rbp-0x6C]
       mov      dword ptr [rbp-0x1B4], eax
       mov      edx, dword ptr [rbp-0x1B4]
       mov      rcx, gword ptr [rbp+0x30]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:NameAt(int):System.String:this]
       mov      gword ptr [rbp-0x78], rax
       mov      rcx, gword ptr [rbp+0x30]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_KeywordDefaultStorage():Lokad.Lython.Runtime.PyDict:this]
       mov      gword ptr [rbp-0x80], rax
       cmp      gword ptr [rbp-0x80], 0
       je       G_M000_IG30
       mov      rcx, gword ptr [rbp+0x30]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_KeywordDefaultNames():Lokad.Lython.Runtime.Text.PyString[]:this]
       mov      ecx, dword ptr [rbp-0x6C]
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG52
       mov      edx, ecx
       lea      rax, bword ptr [rax+8*rdx+0x10]
       mov      rax, gword ptr [rax]
       mov      gword ptr [rbp-0x1C0], rax
       mov      rax, gword ptr [rbp+0x28]
       mov      gword ptr [rsp+0x20], rax
       mov      rdx, gword ptr [rbp-0x1C0]
       lea      r8, [rbp-0x88]
       mov      rcx, gword ptr [rbp-0x80]
       mov      r9, gword ptr [rbp+0x38]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.PyDict:TryGetValue(System.Object,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):bool:this]
       test     eax, eax
       je       SHORT G_M000_IG29
       mov      rcx, 0xD1FFAB1E
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x10]
       mov      eax, dword ptr [rax+0x08]
       cmp      dword ptr [rbp-0x70], eax
       jae      G_M000_IG52
       mov      rax, bword ptr [rbp+0x10]
 
G_M000_IG28:
       mov      rax, bword ptr [rax]
       mov      ecx, dword ptr [rbp-0x70]
       lea      rcx, bword ptr [rax+8*rcx]
       mov      rdx, gword ptr [rbp-0x88]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       jmp      SHORT G_M000_IG31
 
G_M000_IG29:
       mov      rcx, 0xD1FFAB1E
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG30:
       mov      rcx, gword ptr [rbp+0x30]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_CallableKind():int:this]
       mov      dword ptr [rbp-0x150], eax
       mov      rcx, gword ptr [rbp+0x30]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_CallableName():System.String:this]
       mov      gword ptr [rbp-0x1C8], rax
       mov      rdx, gword ptr [rbp-0x1C8]
       mov      ecx, dword ptr [rbp-0x150]
       mov      r8, gword ptr [rbp-0x78]
       mov      r9, gword ptr [rbp+0x28]
       call     [Lokad.Lython.Runtime.CallErrors:MissingArgument(int,System.String,System.String,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.LythonRuntimeException]
       mov      rcx, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG31:
       mov      rcx, 0xD1FFAB1E
       call     CORINFO_HELP_COUNTPROFILE32
       mov      eax, dword ptr [rbp-0x6C]
       inc      eax
       mov      dword ptr [rbp-0x6C], eax
 
G_M000_IG32:
       movzx    rax, byte  ptr [rbp+0x40]
       test     eax, eax
       jne      SHORT G_M000_IG36
       mov      eax, dword ptr [rbp-0x16C]
       dec      eax
       mov      dword ptr [rbp-0x16C], eax
       cmp      dword ptr [rbp-0x16C], 0
       jg       SHORT G_M000_IG34
 
G_M000_IG33:
       lea      rcx, [rbp-0x16C]
       mov      edx, 411
       call     CORINFO_HELP_PATCHPOINT
       jmp      rax
 
G_M000_IG34:
       mov      rcx, gword ptr [rbp+0x30]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_KeywordOnlyCount():int:this]
       cmp      eax, dword ptr [rbp-0x6C]
       jg       G_M000_IG27
 
G_M000_IG35:
       mov      rcx, 0xD1FFAB1E
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG36:
       mov      rcx, gword ptr [rbp+0x30]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_VariadicListIndex():int:this]
       test     eax, eax
       jl       G_M000_IG42
       mov      rcx, 0xD1FFAB1E
       call     CORINFO_HELP_NEWSFAST
       mov      gword ptr [rbp-0x110], rax
       mov      rcx, gword ptr [rbp-0x110]
       call     [Lokad.Lython.Runtime.LythonRuntime+<>c__DisplayClass332_0:.ctor():this]
       mov      rax, gword ptr [rbp-0x110]
       mov      gword ptr [rbp-0x90], rax
       mov      rcx, gword ptr [rbp+0x30]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_VariadicListIndex():int:this]
       mov      dword ptr [rbp-0x94], eax
       mov      rax, gword ptr [rbp-0x90]
       lea      rcx, bword ptr [rax+0x08]
       mov      rdx, gword ptr [rbp-0x40]
       call     CORINFO_HELP_ASSIGN_REF
       mov      rax, gword ptr [rbp-0x90]
       cmp      gword ptr [rax+0x08], 0
       je       SHORT G_M000_IG38
       mov      rax, gword ptr [rbp-0x90]
       mov      rcx, gword ptr [rax+0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.PyList:get_Count():int:this]
       test     eax, eax
       jne      G_M000_IG40
 
G_M000_IG37:
       mov      rcx, 0xD1FFAB1E
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG38:
       mov      rax, bword ptr [rbp+0x10]
       mov      eax, dword ptr [rax+0x08]
       cmp      dword ptr [rbp-0x94], eax
       jae      G_M000_IG52
       mov      rax, bword ptr [rbp+0x10]
       mov      rax, bword ptr [rax]
       mov      ecx, dword ptr [rbp-0x94]
       lea      rax, bword ptr [rax+8*rcx]
       mov      bword ptr [rbp-0x120], rax
       mov      rax, 0xD1FFAB1E
       mov      rax, gword ptr [rax]
       mov      gword ptr [rbp-0x118], rax
       mov      rax, bword ptr [rbp-0x120]
       mov      bword ptr [rbp-0x128], rax
       xor      eax, eax
       mov      dword ptr [rbp-0x12C], eax
       mov      rax, gword ptr [rbp-0x118]
       mov      gword ptr [rbp-0x138], rax
       cmp      gword ptr [rbp-0x118], 0
       jne      SHORT G_M000_IG39
       mov      rcx, 0xD1FFAB1E
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, 0xD1FFAB1E
       call     CORINFO_HELP_NEWSFAST
       mov      gword ptr [rbp-0x140], rax
       mov      rax, 0xD1FFAB1E
       mov      rdx, gword ptr [rax]
       mov      rcx, gword ptr [rbp-0x140]
       mov      r8, 0xD1FFAB1E
       call     [System.Delegate:CtorClosed(System.Object,nint):this]
       mov      rdx, gword ptr [rbp-0x140]
       mov      rcx, 0xD1FFAB1E
       call     CORINFO_HELP_ASSIGN_REF
       mov      rax, gword ptr [rbp-0x140]
       mov      gword ptr [rbp-0x138], rax
 
G_M000_IG39:
       mov      ecx, dword ptr [rbp-0x12C]
       mov      rdx, gword ptr [rbp-0x138]
       mov      r8, gword ptr [rbp+0x38]
       mov      r9, gword ptr [rbp+0x28]
       call     [Lokad.Lython.Runtime.LythonRuntime:CreateTuple(int,System.Func`2[int,System.Object],Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.PyTuple]
       mov      rdx, rax
       mov      rcx, bword ptr [rbp-0x128]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       jmp      G_M000_IG41
 
G_M000_IG40:
       mov      rcx, 0xD1FFAB1E
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, 0xD1FFAB1E
       call     CORINFO_HELP_NEWSFAST
       mov      gword ptr [rbp-0x148], rax
       mov      rax, gword ptr [rbp-0x90]
       mov      rcx, gword ptr [rax+0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.PyList:get_Count():int:this]
       mov      dword ptr [rbp-0x14C], eax
       mov      rcx, gword ptr [rbp-0x148]
       mov      rdx, gword ptr [rbp-0x90]
       mov      r8, 0xD1FFAB1E
       call     [System.Delegate:CtorClosed(System.Object,nint):this]
       mov      ecx, dword ptr [rbp-0x14C]
       mov      rdx, gword ptr [rbp-0x148]
       mov      r8, gword ptr [rbp+0x38]
       mov      r9, gword ptr [rbp+0x28]
       call     [Lokad.Lython.Runtime.LythonRuntime:CreateTuple(int,System.Func`2[int,System.Object],Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.PyTuple]
       mov      gword ptr [rbp-0xA0], rax
       mov      rax, bword ptr [rbp+0x10]
       mov      eax, dword ptr [rax+0x08]
       cmp      dword ptr [rbp-0x94], eax
       jae      G_M000_IG52
       mov      rax, bword ptr [rbp+0x10]
       mov      rax, bword ptr [rax]
       mov      ecx, dword ptr [rbp-0x94]
       lea      rcx, bword ptr [rax+8*rcx]
       mov      rdx, gword ptr [rbp-0xA0]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
 
G_M000_IG41:
       mov      rcx, 0xD1FFAB1E
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp+0x18]
       mov      edx, dword ptr [rbp-0x94]
       mov      r8d, 1
       call     [Lokad.Lython.Runtime.ArgumentPresence:set_Item(int,bool):this]
 
G_M000_IG42:
       mov      rcx, gword ptr [rbp+0x30]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_VariadicDictionaryIndex():int:this]
       test     eax, eax
       jl       G_M000_IG50
       mov      rcx, 0xD1FFAB1E
       call     CORINFO_HELP_NEWSFAST
       mov      gword ptr [rbp-0x100], rax
       mov      rcx, gword ptr [rbp+0x38]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:get_MemoryGovernor():Lokad.Lython.Runtime.MemoryGovernor:this]
       mov      gword ptr [rbp-0x1D0], rax
       mov      rdx, gword ptr [rbp-0x1D0]
       mov      rcx, gword ptr [rbp-0x100]
       mov      r8, gword ptr [rbp+0x28]
       call     [Lokad.Lython.Runtime.PyDict:.ctor(Lokad.Lython.Runtime.MemoryGovernor,Lokad.Lython.LythonSourceSpan):this]
       mov      rax, gword ptr [rbp-0x100]
       mov      gword ptr [rbp-0xA8], rax
       cmp      gword ptr [rbp-0x48], 0
       je       G_M000_IG49
       lea      rdx, [rbp-0xD8]
       mov      rcx, gword ptr [rbp-0x48]
       cmp      dword ptr [rcx], ecx
       call     [System.Collections.Generic.Dictionary`2[System.__Canon,System.__Canon]:GetEnumerator():System.Collections.Generic.Dictionary`2+Enumerator[System.__Canon,System.__Canon]:this]
       nop      
 
G_M000_IG43:
       jmp      G_M000_IG45
 
G_M000_IG44:
       mov      rcx, 0xD1FFAB1E
       call     CORINFO_HELP_COUNTPROFILE32
       lea      rdx, [rbp-0xE8]
       lea      rcx, [rbp-0xD8]
       mov      r8, 0xD1FFAB1E
       call     [System.Collections.Generic.Dictionary`2+Enumerator[System.__Canon,System.__Canon]:get_Current():System.Collections.Generic.KeyValuePair`2[System.__Canon,System.__Canon]:this]
       lea      rcx, [rbp-0xE8]
       mov      rdx, 0xD1FFAB1E
       call     [System.Collections.Generic.KeyValuePair`2[System.__Canon,System.__Canon]:get_Key():System.__Canon:this]
       mov      gword ptr [rbp-0x108], rax
       mov      rcx, gword ptr [rbp+0x38]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:get_MemoryGovernor():Lokad.Lython.Runtime.MemoryGovernor:this]
       mov      gword ptr [rbp-0x1D8], rax
       mov      rdx, gword ptr [rbp-0x1D8]
       mov      rcx, gword ptr [rbp-0x108]
       mov      r8, gword ptr [rbp+0x28]
       call     [Lokad.Lython.Runtime.Text.PyString:FromString(System.String,Lokad.Lython.Runtime.MemoryGovernor,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.Text.PyString]
       mov      gword ptr [rbp-0xF0], rax
       lea      rcx, [rbp-0xE8]
       mov      rdx, 0xD1FFAB1E
       call     [System.Collections.Generic.KeyValuePair`2[System.__Canon,System.__Canon]:get_Value():System.__Canon:this]
       mov      gword ptr [rbp-0x1E0], rax
       mov      r8, gword ptr [rbp-0x1E0]
       mov      rdx, gword ptr [rbp-0xF0]
       mov      rcx, gword ptr [rbp-0xA8]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.PyDict:SetItem(System.Object,System.Object):this]
 
G_M000_IG45:
       mov      eax, dword ptr [rbp-0x16C]
       dec      eax
       mov      dword ptr [rbp-0x16C], eax
       cmp      dword ptr [rbp-0x16C], 0
       jg       SHORT G_M000_IG47
 
G_M000_IG46:
       lea      rcx, [rbp-0x16C]
       mov      edx, 681
       call     CORINFO_HELP_PATCHPOINT
       jmp      rax
 
G_M000_IG47:
       lea      rcx, [rbp-0xD8]
       mov      rdx, 0xD1FFAB1E
       call     [System.Collections.Generic.Dictionary`2+Enumerator[System.__Canon,System.__Canon]:MoveNext():bool:this]
       test     eax, eax
       jne      G_M000_IG44
       mov      rcx, 0xD1FFAB1E
       call     CORINFO_HELP_COUNTPROFILE32
       nop      
 
G_M000_IG48:
       call     G_M000_IG53
       nop      
 
G_M000_IG49:
       mov      rcx, 0xD1FFAB1E
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, gword ptr [rbp+0x30]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_VariadicDictionaryIndex():int:this]
       mov      dword ptr [rbp-0xAC], eax
       mov      rax, bword ptr [rbp+0x10]
       mov      eax, dword ptr [rax+0x08]
       cmp      dword ptr [rbp-0xAC], eax
       jae      SHORT G_M000_IG52
       mov      rax, bword ptr [rbp+0x10]
       mov      rax, bword ptr [rax]
       mov      ecx, dword ptr [rbp-0xAC]
       lea      rcx, bword ptr [rax+8*rcx]
       mov      rdx, gword ptr [rbp-0xA8]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rcx, bword ptr [rbp+0x18]
       mov      edx, dword ptr [rbp-0xAC]
       mov      r8d, 1
       call     [Lokad.Lython.Runtime.ArgumentPresence:set_Item(int,bool):this]
 
G_M000_IG50:
       mov      rcx, 0xD1FFAB1E
       call     CORINFO_HELP_COUNTPROFILE32
       nop      
 
G_M000_IG51:
       add      rsp, 576
       pop      rbp
       ret      
 
G_M000_IG52:
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG53:
       sub      rsp, 88
 
G_M000_IG54:
       mov      rcx, 0xD1FFAB1E
       call     CORINFO_HELP_COUNTPROFILE32
       lea      rcx, [rbp-0xD8]
       mov      rdx, 0xD1FFAB1E
       call     [System.Collections.Generic.Dictionary`2+Enumerator[System.__Canon,System.__Canon]:Dispose():this]
       nop      
 
G_M000_IG55:
       add      rsp, 88
       ret      
 
; Total bytes of code 2798

; Assembly listing for method Lokad.Lython.Runtime.PyExecutableFunction:StartNativeCall(Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[System.Object],System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,bool,bool,System.Span`1[System.Object],byref,byref,byref):this (Instrumented Tier0)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; Instrumented Tier0 code
; rbp based frame
; partially interruptible
; compiling with minopt

G_M000_IG01:
       push     rbp
       sub      rsp, 656
       lea      rbp, [rsp+0x290]
       xor      eax, eax
       mov      qword ptr [rbp-0x238], rax
       vxorps   xmm4, xmm4, xmm4
       vmovdqa  xmmword ptr [rbp-0x230], xmm4
       mov      rax, -480
 
G_M000_IG27:
       vmovdqa  xmmword ptr [rbp+rax-0x40], xmm4
       vmovdqa  xmmword ptr [rbp+rax-0x30], xmm4
       vmovdqa  xmmword ptr [rbp+rax-0x20], xmm4
       add      rax, 48
       jne      SHORT G_M000_IG27
       mov      qword ptr [rbp-0x40], rax
       mov      gword ptr [rbp+0x10], rcx
       mov      gword ptr [rbp+0x18], rdx
       mov      bword ptr [rbp+0x20], r8
       mov      gword ptr [rbp+0x28], r9
 
G_M000_IG02:
       mov      dword ptr [rbp-0x174], 0x3E8
       vxorps   ymm0, ymm0, ymm0
       vmovdqu  ymmword ptr [rbp-0xB8], ymm0
       vmovdqu  ymmword ptr [rbp-0x98], ymm0
       vmovdqu  ymmword ptr [rbp-0x78], ymm0
       vmovdqu  ymmword ptr [rbp-0x58], ymm0
       lea      r8, [rbp-0xB8]
       lea      rcx, [rbp-0xC8]
       mov      rdx, 0xD1FFAB1E
       mov      r9d, 16
       call     [<PrivateImplementationDetails>:InlineArrayAsSpan[Lokad.Lython.Runtime.PyExecutableFunction+NativeValues,System.__Canon](byref,int):System.Span`1[System.__Canon]]
       mov      rax, gword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax+0x68]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_ValueStorageCapacity():int:this]
       mov      dword ptr [rbp-0x178], eax
       mov      eax, dword ptr [rbp-0x178]
       mov      dword ptr [rsp+0x20], eax
       lea      rcx, [rbp-0xC8]
       lea      rdx, [rbp-0xC8]
       mov      r8, 0xD1FFAB1E
       xor      r9d, r9d
       call     [System.Span`1[System.__Canon]:Slice(int,int):System.Span`1[System.__Canon]:this]
       mov      rcx, gword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.PyFunctionBase:get_BindingPlan():Lokad.Lython.Runtime.FunctionBindingPlan:this]
       mov      rcx, rax
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_ParameterCount():int:this]
       mov      dword ptr [rbp-0x17C], eax
       mov      edx, dword ptr [rbp-0x17C]
       lea      rcx, [rbp-0xE0]
       call     [Lokad.Lython.Runtime.ArgumentPresence:.ctor(int):this]
       movzx    rax, byte  ptr [rbp+0x48]
       test     eax, eax
       je       G_M000_IG09
 
G_M000_IG03:
       vmovdqu  xmm0, xmmword ptr [rbp-0xC8]
       vmovdqu  xmmword ptr [rbp-0x190], xmm0
 
G_M000_IG04:
       lea      r8, [rbp-0x190]
       mov      rcx, bword ptr [rbp+0x20]
       mov      rdx, 0xD1FFAB1E
       call     [System.ReadOnlySpan`1[System.__Canon]:CopyTo(System.Span`1[System.__Canon]):this]
       xor      eax, eax
       mov      dword ptr [rbp-0xE4], eax
       jmp      SHORT G_M000_IG06
 
G_M000_IG05:
       mov      rcx, 0xD1FFAB1E
       call     CORINFO_HELP_COUNTPROFILE32
       lea      rcx, [rbp-0xE0]
       mov      edx, dword ptr [rbp-0xE4]
       mov      r8d, 1
       call     [Lokad.Lython.Runtime.ArgumentPresence:set_Item(int,bool):this]
       mov      eax, dword ptr [rbp-0xE4]
       inc      eax
       mov      dword ptr [rbp-0xE4], eax
 
G_M000_IG06:
       mov      eax, dword ptr [rbp-0x174]
       dec      eax
       mov      dword ptr [rbp-0x174], eax
       cmp      dword ptr [rbp-0x174], 0
       jg       SHORT G_M000_IG08
 
G_M000_IG07:
       lea      rcx, [rbp-0x174]
       mov      edx, 85
       call     CORINFO_HELP_PATCHPOINT
       jmp      rax
 
G_M000_IG08:
       lea      rcx, [rbp-0xE0]
       call     [Lokad.Lython.Runtime.ArgumentPresence:get_Length():int:this]
       cmp      eax, dword ptr [rbp-0xE4]
       jg       SHORT G_M000_IG05
       jmp      G_M000_IG16
 
G_M000_IG09:
       mov      rcx, 0xD1FFAB1E
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, gword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.PyFunctionBase:get_BindingPlan():Lokad.Lython.Runtime.FunctionBindingPlan:this]
       mov      rcx, rax
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_ParameterCount():int:this]
       mov      dword ptr [rbp-0x194], eax
       mov      eax, dword ptr [rbp-0x194]
       mov      dword ptr [rsp+0x20], eax
       lea      rcx, [rbp-0xC8]
       lea      rdx, [rbp-0x138]
       mov      r8, 0xD1FFAB1E
       xor      r9d, r9d
       call     [System.Span`1[System.__Canon]:Slice(int,int):System.Span`1[System.__Canon]:this]
       vxorps   xmm0, xmm0, xmm0
       vmovdqu  xmmword ptr [rbp-0xF8], xmm0
 
G_M000_IG10:
       vmovdqu  xmm0, xmmword ptr [rbp-0xF8]
       vmovdqu  xmmword ptr [rbp-0x148], xmm0
 
G_M000_IG11:
       vmovdqu  xmm0, xmmword ptr [rbp-0x138]
       vmovdqu  xmmword ptr [rbp-0x1A8], xmm0
 
G_M000_IG12:
       vmovdqu  xmm0, xmmword ptr [rbp-0x148]
       vmovdqu  xmmword ptr [rbp-0x1B8], xmm0
 
G_M000_IG13:
       mov      rcx, gword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.PyFunctionBase:get_BindingPlan():Lokad.Lython.Runtime.FunctionBindingPlan:this]
       mov      gword ptr [rbp-0x1D0], rax
       mov      rax, gword ptr [rbp+0x30]
       mov      gword ptr [rsp+0x28], rax
       xor      eax, eax
       mov      dword ptr [rsp+0x30], eax
       mov      rax, gword ptr [rbp+0x28]
       mov      gword ptr [rsp+0x38], rax
       mov      rax, gword ptr [rbp+0x18]
       mov      gword ptr [rsp+0x40], rax
       mov      rax, bword ptr [rbp+0x20]
 
G_M000_IG14:
       vmovdqu  xmm0, xmmword ptr [rax]
       vmovdqu  xmmword ptr [rbp-0x1C8], xmm0
 
G_M000_IG15:
       mov      rax, gword ptr [rbp-0x1D0]
       mov      gword ptr [rsp+0x20], rax
       lea      r8, [rbp-0x1B8]
       lea      rcx, [rbp-0x1A8]
       lea      rax, [rbp-0x1C8]
       mov      qword ptr [rsp+0x48], rax
       lea      rdx, [rbp-0xE0]
       mov      r9, gword ptr [rbp+0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime:BindFunctionArgumentsInto(System.Span`1[System.Object],byref,System.ReadOnlySpan`1[Lokad.Lython.Runtime.CallArgumentValue],Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.FunctionBindingPlan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,bool,System.Object,Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[System.Object])]
 
G_M000_IG16:
       mov      rcx, 0xD1FFAB1E
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG17:
       vmovdqu  xmm0, xmmword ptr [rbp-0xC8]
       vmovdqu  xmmword ptr [rbp-0x158], xmm0
 
G_M000_IG18:
       vmovdqu  xmm0, xmmword ptr [rbp-0xE0]
       vmovdqu  xmmword ptr [rbp-0x170], xmm0
       mov      rax, qword ptr [rbp-0xD0]
       mov      qword ptr [rbp-0x160], rax
 
G_M000_IG19:
       vxorps   ymm0, ymm0, ymm0
       vmovdqu  ymmword ptr [rbp-0x128], ymm0
       vmovdqu  xmmword ptr [rbp-0x108], xmm0
 
G_M000_IG20:
       vmovdqu  xmm0, xmmword ptr [rbp-0x158]
       vmovdqu  xmmword ptr [rbp-0x1E0], xmm0
 
G_M000_IG21:
       vmovdqu  xmm0, xmmword ptr [rbp-0x170]
       vmovdqu  xmmword ptr [rbp-0x1F8], xmm0
       mov      rax, qword ptr [rbp-0x160]
       mov      qword ptr [rbp-0x1E8], rax
 
G_M000_IG22:
       vmovdqu  ymm0, ymmword ptr [rbp-0x128]
       vmovdqu  ymmword ptr [rbp-0x228], ymm0
       vmovdqu  xmm0, xmmword ptr [rbp-0x108]
       vmovdqu  xmmword ptr [rbp-0x208], xmm0
 
G_M000_IG23:
       mov      rax, gword ptr [rbp+0x38]
       mov      gword ptr [rsp+0x20], rax
       movzx    rax, byte  ptr [rbp+0x40]
       mov      dword ptr [rsp+0x28], eax
       mov      rax, bword ptr [rbp+0x50]
 
G_M000_IG24:
       vmovdqu  xmm0, xmmword ptr [rax]
       vmovdqu  xmmword ptr [rbp-0x238], xmm0
 
G_M000_IG25:
       mov      rax, bword ptr [rbp+0x58]
       mov      bword ptr [rsp+0x38], rax
       mov      rax, bword ptr [rbp+0x60]
       mov      bword ptr [rsp+0x40], rax
       mov      rax, bword ptr [rbp+0x68]
       mov      bword ptr [rsp+0x48], rax
       lea      rdx, [rbp-0x1E0]
       lea      r8, [rbp-0x1F8]
       lea      r9, [rbp-0x228]
       lea      rax, [rbp-0x238]
       mov      qword ptr [rsp+0x30], rax
       mov      rcx, gword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.PyExecutableFunction:StartInline(System.Span`1[System.Object],Lokad.Lython.Runtime.ArgumentPresence,System.Nullable`1[Lokad.Lython.Runtime.BoundCallArguments],Lokad.Lython.LythonSourceSpan,bool,System.Span`1[System.Object],byref,byref,byref):this]
       nop      
 
G_M000_IG26:
       vzeroupper 
       add      rsp, 656
       pop      rbp
       ret      
 
; Total bytes of code 1006

; Assembly listing for method Lokad.Lython.Runtime.LythonRuntime:BindFunctionArgumentsInto(System.Span`1[System.Object],byref,System.ReadOnlySpan`1[Lokad.Lython.Runtime.CallArgumentValue],Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.FunctionBindingPlan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,bool,System.Object,Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[System.Object]) (Instrumented Tier0)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; Instrumented Tier0 code
; rbp based frame
; fully interruptible
; compiling with minopt

G_M000_IG01:
       push     rbp
       sub      rsp, 576
       lea      rbp, [rsp+0x240]
       vxorps   xmm4, xmm4, xmm4
       vmovdqa  xmmword ptr [rbp-0x1E0], xmm4
       vmovdqa  xmmword ptr [rbp-0x1D0], xmm4
       mov      rax, -384
 
G_M000_IG56:
       vmovdqa  xmmword ptr [rbp+rax-0x40], xmm4
       vmovdqa  xmmword ptr [rbp+rax-0x30], xmm4
       vmovdqa  xmmword ptr [rbp+rax-0x20], xmm4
       add      rax, 48
       jne      SHORT G_M000_IG56
       mov      qword ptr [rbp-0x40], rax
       mov      bword ptr [rbp+0x10], rcx
       mov      bword ptr [rbp+0x18], rdx
       mov      bword ptr [rbp+0x20], r8
       mov      gword ptr [rbp+0x28], r9
 
G_M000_IG02:
       mov      dword ptr [rbp-0x16C], 0x3E8
       xor      rax, rax
       mov      gword ptr [rbp-0x40], rax
       xor      rax, rax
       mov      gword ptr [rbp-0x48], rax
       xor      eax, eax
       mov      dword ptr [rbp-0x4C], eax
       mov      rcx, gword ptr [rbp+0x30]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_VariadicListIndex():int:this]
       test     eax, eax
       jge      SHORT G_M000_IG04
       cmp      gword ptr [rbp+0x50], 0
       jne      SHORT G_M000_IG03
       mov      rcx, bword ptr [rbp+0x20]
       call     [System.ReadOnlySpan`1[Lokad.Lython.Runtime.CallArgumentValue]:get_IsEmpty():bool:this]
       mov      dword ptr [rbp-0xF4], eax
       jmp      SHORT G_M000_IG05
 
G_M000_IG03:
       mov      rcx, 0xD1FFAB1E
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, gword ptr [rbp+0x50]
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_IsPositionalOnly():bool:this]
       mov      dword ptr [rbp-0xF4], eax
       jmp      SHORT G_M000_IG05
 
G_M000_IG04:
       mov      rcx, 0xD1FFAB1E
       call     CORINFO_HELP_COUNTPROFILE32
       xor      eax, eax
       mov      dword ptr [rbp-0xF4], eax
 
G_M000_IG05:
       cmp      dword ptr [rbp-0xF4], 0
       je       G_M000_IG13
       cmp      gword ptr [rbp+0x48], 0
       setne    al
       movzx    rax, al
       mov      dword ptr [rbp-0x50], eax
       mov      rax, bword ptr [rbp+0x58]
       mov      eax, dword ptr [rax+0x08]
       mov      dword ptr [rbp-0x154], eax
       mov      rcx, gword ptr [rbp+0x30]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_PositionalCount():int:this]
       sub      eax, dword ptr [rbp-0x50]
       cmp      eax, dword ptr [rbp-0x154]
       jge      SHORT G_M000_IG07
 
G_M000_IG06:
       mov      rcx, gword ptr [rbp+0x30]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_CallableKind():int:this]
       mov      dword ptr [rbp-0x168], eax
       mov      rcx, gword ptr [rbp+0x30]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_CallableName():System.String:this]
       mov      gword ptr [rbp-0x178], rax
       mov      rdx, gword ptr [rbp-0x178]
       mov      ecx, dword ptr [rbp-0x168]
       mov      r8, gword ptr [rbp+0x28]
       call     [Lokad.Lython.Runtime.CallErrors:TooManyPositional(int,System.String,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.LythonRuntimeException]
       mov      rcx, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG07:
       cmp      gword ptr [rbp+0x48], 0
       je       SHORT G_M000_IG08
       mov      rcx, 0xD1FFAB1E
       call     CORINFO_HELP_COUNTPROFILE32
       mov      eax, dword ptr [rbp-0x4C]
       mov      dword ptr [rbp-0x164], eax
       mov      eax, dword ptr [rbp-0x4C]
       inc      eax
       mov      dword ptr [rbp-0x4C], eax
       mov      rax, bword ptr [rbp+0x10]
       mov      eax, dword ptr [rax+0x08]
       cmp      dword ptr [rbp-0x164], eax
       jae      G_M000_IG52
       mov      rax, bword ptr [rbp+0x10]
       mov      rax, bword ptr [rax]
       mov      ecx, dword ptr [rbp-0x164]
       lea      rcx, bword ptr [rax+8*rcx]
       mov      rdx, gword ptr [rbp+0x48]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
 
G_M000_IG08:
       xor      eax, eax
       mov      dword ptr [rbp-0x54], eax
       jmp      G_M000_IG10
 
G_M000_IG09:
       mov      rcx, 0xD1FFAB1E
       call     CORINFO_HELP_COUNTPROFILE32
       mov      eax, dword ptr [rbp-0x4C]
       mov      dword ptr [rbp-0x158], eax
       mov      eax, dword ptr [rbp-0x4C]
       inc      eax
       mov      dword ptr [rbp-0x4C], eax
       mov      rax, bword ptr [rbp+0x10]
       mov      eax, dword ptr [rax+0x08]
       cmp      dword ptr [rbp-0x158], eax
       jae      G_M000_IG52
       mov      rax, bword ptr [rbp+0x10]
       mov      rax, bword ptr [rax]
       mov      ecx, dword ptr [rbp-0x158]
       lea      rax, bword ptr [rax+8*rcx]
       mov      bword ptr [rbp-0x160], rax
       mov      rax, bword ptr [rbp+0x58]
       mov      eax, dword ptr [rax+0x08]
       cmp      dword ptr [rbp-0x54], eax
       jae      G_M000_IG52
       mov      rax, bword ptr [rbp+0x58]
       mov      rax, bword ptr [rax]
       mov      ecx, dword ptr [rbp-0x54]
       mov      rdx, gword ptr [rax+8*rcx]
       mov      rcx, 0xD1FFAB1E
       call     [Lokad.Lython.Internal.NullabilityExtensions:RequireNotNull[System.__Canon](System.__Canon):System.__Canon]
       mov      rdx, rax
       mov      rcx, bword ptr [rbp-0x160]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      eax, dword ptr [rbp-0x54]
       inc      eax
       mov      dword ptr [rbp-0x54], eax
 
G_M000_IG10:
       mov      eax, dword ptr [rbp-0x16C]
       dec      eax
       mov      dword ptr [rbp-0x16C], eax
       cmp      dword ptr [rbp-0x16C], 0
       jg       SHORT G_M000_IG12
 
G_M000_IG11:
       lea      rcx, [rbp-0x16C]
       mov      edx, 144
       call     CORINFO_HELP_PATCHPOINT
       jmp      rax
 
G_M000_IG12:
       mov      rax, bword ptr [rbp+0x58]
       mov      eax, dword ptr [rax+0x08]
       cmp      eax, dword ptr [rbp-0x54]
       jg       G_M000_IG09
       mov      rcx, bword ptr [rbp+0x18]
       mov      r8d, dword ptr [rbp-0x4C]
       xor      edx, edx
       call     [Lokad.Lython.Runtime.ArgumentPresence:MarkRange(int,int):this]
       jmp      G_M000_IG20
 
G_M000_IG13:
       mov      rcx, 0xD1FFAB1E
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x10]
 
G_M000_IG14:
       vmovdqu  xmm0, xmmword ptr [rax]
       vmovdqu  xmmword ptr [rbp-0x188], xmm0
 
G_M000_IG15:
       mov      rax, bword ptr [rbp+0x20]
 
G_M000_IG16:
       vmovdqu  xmm0, xmmword ptr [rax]
       vmovdqu  xmmword ptr [rbp-0x198], xmm0
 
G_M000_IG17:
       mov      rax, gword ptr [rbp+0x30]
       mov      gword ptr [rsp+0x20], rax
       mov      rax, gword ptr [rbp+0x38]
       mov      gword ptr [rsp+0x28], rax
       mov      rax, gword ptr [rbp+0x48]
       mov      gword ptr [rsp+0x30], rax
       mov      rax, gword ptr [rbp+0x50]
       mov      gword ptr [rsp+0x38], rax
       mov      rax, bword ptr [rbp+0x58]
 
G_M000_IG18:
       vmovdqu  xmm0, xmmword ptr [rax]
       vmovdqu  xmmword ptr [rbp-0x1A8], xmm0
 
G_M000_IG19:
       lea      rax, [rbp-0x40]
       mov      qword ptr [rsp+0x48], rax
       lea      rax, [rbp-0x48]
       mov      qword ptr [rsp+0x50], rax
       lea      rcx, [rbp-0x188]
       lea      r8, [rbp-0x198]
       lea      rax, [rbp-0x1A8]
       mov      qword ptr [rsp+0x40], rax
       mov      r9, gword ptr [rbp+0x28]
       mov      rdx, bword ptr [rbp+0x18]
       call     [Lokad.Lython.Runtime.LythonRuntime:BindSuppliedFunctionArguments(System.Span`1[System.Object],byref,System.ReadOnlySpan`1[Lokad.Lython.Runtime.CallArgumentValue],Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.FunctionBindingPlan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,System.Object,Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[System.Object],byref,byref)]
 
G_M000_IG20:
       xor      eax, eax
       mov      dword ptr [rbp-0x58], eax
       jmp      G_M000_IG24
 
G_M000_IG21:
       mov      rcx, bword ptr [rbp+0x18]
       mov      edx, dword ptr [rbp-0x58]
       call     [Lokad.Lython.Runtime.ArgumentPresence:get_Item(int):bool:this]
       test     eax, eax
       jne      G_M000_IG23
       mov      rcx, gword ptr [rbp+0x30]
       mov      edx, dword ptr [rbp-0x58]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:NameAt(int):System.String:this]
       mov      gword ptr [rbp-0x60], rax
       lea      r8, [rbp-0x68]
       mov      rcx, gword ptr [rbp+0x30]
       mov      edx, dword ptr [rbp-0x58]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:TryGetPositionalDefault(int,byref):bool:this]
       test     eax, eax
       je       SHORT G_M000_IG22
       mov      rcx, 0xD1FFAB1E
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x10]
       mov      eax, dword ptr [rax+0x08]
       cmp      dword ptr [rbp-0x58], eax
       jae      G_M000_IG52
       mov      rax, bword ptr [rbp+0x10]
       mov      rax, bword ptr [rax]
       mov      ecx, dword ptr [rbp-0x58]
       lea      rcx, bword ptr [rax+8*rcx]
       mov      rdx, gword ptr [rbp-0x68]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       jmp      SHORT G_M000_IG23
 
G_M000_IG22:
       mov      rcx, gword ptr [rbp+0x30]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_CallableKind():int:this]
       mov      dword ptr [rbp-0xF8], eax
       mov      rcx, gword ptr [rbp+0x30]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_CallableName():System.String:this]
       mov      gword ptr [rbp-0x1B0], rax
       mov      rdx, gword ptr [rbp-0x1B0]
       mov      ecx, dword ptr [rbp-0xF8]
       mov      r8, gword ptr [rbp-0x60]
       mov      r9, gword ptr [rbp+0x28]
       call     [Lokad.Lython.Runtime.CallErrors:MissingArgument(int,System.String,System.String,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.LythonRuntimeException]
       mov      rcx, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG23:
       mov      rcx, 0xD1FFAB1E
       call     CORINFO_HELP_COUNTPROFILE32
       mov      eax, dword ptr [rbp-0x58]
       inc      eax
       mov      dword ptr [rbp-0x58], eax
 
G_M000_IG24:
       mov      eax, dword ptr [rbp-0x16C]
       dec      eax
       mov      dword ptr [rbp-0x16C], eax
       cmp      dword ptr [rbp-0x16C], 0
       jg       SHORT G_M000_IG26
 
G_M000_IG25:
       lea      rcx, [rbp-0x16C]
       mov      edx, 270
       call     CORINFO_HELP_PATCHPOINT
       jmp      rax
 
G_M000_IG26:
       mov      rcx, gword ptr [rbp+0x30]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_PositionalCount():int:this]
       cmp      eax, dword ptr [rbp-0x58]
       jg       G_M000_IG21
       xor      eax, eax
       mov      dword ptr [rbp-0x6C], eax
       jmp      G_M000_IG32
 
G_M000_IG27:
       mov      rcx, gword ptr [rbp+0x30]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_PositionalCount():int:this]
       add      eax, dword ptr [rbp-0x6C]
       mov      dword ptr [rbp-0x70], eax
       mov      rcx, bword ptr [rbp+0x18]
       mov      edx, dword ptr [rbp-0x70]
       call     [Lokad.Lython.Runtime.ArgumentPresence:get_Item(int):bool:this]
       test     eax, eax
       jne      G_M000_IG31
       mov      rcx, gword ptr [rbp+0x30]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_PositionalCount():int:this]
       add      eax, dword ptr [rbp-0x6C]
       mov      dword ptr [rbp-0x1B4], eax
       mov      edx, dword ptr [rbp-0x1B4]
       mov      rcx, gword ptr [rbp+0x30]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:NameAt(int):System.String:this]
       mov      gword ptr [rbp-0x78], rax
       mov      rcx, gword ptr [rbp+0x30]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_KeywordDefaultStorage():Lokad.Lython.Runtime.PyDict:this]
       mov      gword ptr [rbp-0x80], rax
       cmp      gword ptr [rbp-0x80], 0
       je       G_M000_IG30
       mov      rcx, gword ptr [rbp+0x30]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_KeywordDefaultNames():Lokad.Lython.Runtime.Text.PyString[]:this]
       mov      ecx, dword ptr [rbp-0x6C]
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG52
       mov      edx, ecx
       lea      rax, bword ptr [rax+8*rdx+0x10]
       mov      rax, gword ptr [rax]
       mov      gword ptr [rbp-0x1C0], rax
       mov      rax, gword ptr [rbp+0x28]
       mov      gword ptr [rsp+0x20], rax
       mov      rdx, gword ptr [rbp-0x1C0]
       lea      r8, [rbp-0x88]
       mov      rcx, gword ptr [rbp-0x80]
       mov      r9, gword ptr [rbp+0x38]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.PyDict:TryGetValue(System.Object,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):bool:this]
       test     eax, eax
       je       SHORT G_M000_IG29
       mov      rcx, 0xD1FFAB1E
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x10]
       mov      eax, dword ptr [rax+0x08]
       cmp      dword ptr [rbp-0x70], eax
       jae      G_M000_IG52
       mov      rax, bword ptr [rbp+0x10]
 
G_M000_IG28:
       mov      rax, bword ptr [rax]
       mov      ecx, dword ptr [rbp-0x70]
       lea      rcx, bword ptr [rax+8*rcx]
       mov      rdx, gword ptr [rbp-0x88]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       jmp      SHORT G_M000_IG31
 
G_M000_IG29:
       mov      rcx, 0xD1FFAB1E
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG30:
       mov      rcx, gword ptr [rbp+0x30]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_CallableKind():int:this]
       mov      dword ptr [rbp-0x150], eax
       mov      rcx, gword ptr [rbp+0x30]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_CallableName():System.String:this]
       mov      gword ptr [rbp-0x1C8], rax
       mov      rdx, gword ptr [rbp-0x1C8]
       mov      ecx, dword ptr [rbp-0x150]
       mov      r8, gword ptr [rbp-0x78]
       mov      r9, gword ptr [rbp+0x28]
       call     [Lokad.Lython.Runtime.CallErrors:MissingArgument(int,System.String,System.String,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.LythonRuntimeException]
       mov      rcx, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG31:
       mov      rcx, 0xD1FFAB1E
       call     CORINFO_HELP_COUNTPROFILE32
       mov      eax, dword ptr [rbp-0x6C]
       inc      eax
       mov      dword ptr [rbp-0x6C], eax
 
G_M000_IG32:
       movzx    rax, byte  ptr [rbp+0x40]
       test     eax, eax
       jne      SHORT G_M000_IG36
       mov      eax, dword ptr [rbp-0x16C]
       dec      eax
       mov      dword ptr [rbp-0x16C], eax
       cmp      dword ptr [rbp-0x16C], 0
       jg       SHORT G_M000_IG34
 
G_M000_IG33:
       lea      rcx, [rbp-0x16C]
       mov      edx, 411
       call     CORINFO_HELP_PATCHPOINT
       jmp      rax
 
G_M000_IG34:
       mov      rcx, gword ptr [rbp+0x30]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_KeywordOnlyCount():int:this]
       cmp      eax, dword ptr [rbp-0x6C]
       jg       G_M000_IG27
 
G_M000_IG35:
       mov      rcx, 0xD1FFAB1E
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG36:
       mov      rcx, gword ptr [rbp+0x30]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_VariadicListIndex():int:this]
       test     eax, eax
       jl       G_M000_IG42
       mov      rcx, 0xD1FFAB1E
       call     CORINFO_HELP_NEWSFAST
       mov      gword ptr [rbp-0x110], rax
       mov      rcx, gword ptr [rbp-0x110]
       call     [Lokad.Lython.Runtime.LythonRuntime+<>c__DisplayClass332_0:.ctor():this]
       mov      rax, gword ptr [rbp-0x110]
       mov      gword ptr [rbp-0x90], rax
       mov      rcx, gword ptr [rbp+0x30]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_VariadicListIndex():int:this]
       mov      dword ptr [rbp-0x94], eax
       mov      rax, gword ptr [rbp-0x90]
       lea      rcx, bword ptr [rax+0x08]
       mov      rdx, gword ptr [rbp-0x40]
       call     CORINFO_HELP_ASSIGN_REF
       mov      rax, gword ptr [rbp-0x90]
       cmp      gword ptr [rax+0x08], 0
       je       SHORT G_M000_IG38
       mov      rax, gword ptr [rbp-0x90]
       mov      rcx, gword ptr [rax+0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.PyList:get_Count():int:this]
       test     eax, eax
       jne      G_M000_IG40
 
G_M000_IG37:
       mov      rcx, 0xD1FFAB1E
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG38:
       mov      rax, bword ptr [rbp+0x10]
       mov      eax, dword ptr [rax+0x08]
       cmp      dword ptr [rbp-0x94], eax
       jae      G_M000_IG52
       mov      rax, bword ptr [rbp+0x10]
       mov      rax, bword ptr [rax]
       mov      ecx, dword ptr [rbp-0x94]
       lea      rax, bword ptr [rax+8*rcx]
       mov      bword ptr [rbp-0x120], rax
       mov      rax, 0xD1FFAB1E
       mov      rax, gword ptr [rax]
       mov      gword ptr [rbp-0x118], rax
       mov      rax, bword ptr [rbp-0x120]
       mov      bword ptr [rbp-0x128], rax
       xor      eax, eax
       mov      dword ptr [rbp-0x12C], eax
       mov      rax, gword ptr [rbp-0x118]
       mov      gword ptr [rbp-0x138], rax
       cmp      gword ptr [rbp-0x118], 0
       jne      SHORT G_M000_IG39
       mov      rcx, 0xD1FFAB1E
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, 0xD1FFAB1E
       call     CORINFO_HELP_NEWSFAST
       mov      gword ptr [rbp-0x140], rax
       mov      rax, 0xD1FFAB1E
       mov      rdx, gword ptr [rax]
       mov      rcx, gword ptr [rbp-0x140]
       mov      r8, 0xD1FFAB1E
       call     [System.Delegate:CtorClosed(System.Object,nint):this]
       mov      rdx, gword ptr [rbp-0x140]
       mov      rcx, 0xD1FFAB1E
       call     CORINFO_HELP_ASSIGN_REF
       mov      rax, gword ptr [rbp-0x140]
       mov      gword ptr [rbp-0x138], rax
 
G_M000_IG39:
       mov      ecx, dword ptr [rbp-0x12C]
       mov      rdx, gword ptr [rbp-0x138]
       mov      r8, gword ptr [rbp+0x38]
       mov      r9, gword ptr [rbp+0x28]
       call     [Lokad.Lython.Runtime.LythonRuntime:CreateTuple(int,System.Func`2[int,System.Object],Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.PyTuple]
       mov      rdx, rax
       mov      rcx, bword ptr [rbp-0x128]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       jmp      G_M000_IG41
 
G_M000_IG40:
       mov      rcx, 0xD1FFAB1E
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, 0xD1FFAB1E
       call     CORINFO_HELP_NEWSFAST
       mov      gword ptr [rbp-0x148], rax
       mov      rax, gword ptr [rbp-0x90]
       mov      rcx, gword ptr [rax+0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.PyList:get_Count():int:this]
       mov      dword ptr [rbp-0x14C], eax
       mov      rcx, gword ptr [rbp-0x148]
       mov      rdx, gword ptr [rbp-0x90]
       mov      r8, 0xD1FFAB1E
       call     [System.Delegate:CtorClosed(System.Object,nint):this]
       mov      ecx, dword ptr [rbp-0x14C]
       mov      rdx, gword ptr [rbp-0x148]
       mov      r8, gword ptr [rbp+0x38]
       mov      r9, gword ptr [rbp+0x28]
       call     [Lokad.Lython.Runtime.LythonRuntime:CreateTuple(int,System.Func`2[int,System.Object],Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.PyTuple]
       mov      gword ptr [rbp-0xA0], rax
       mov      rax, bword ptr [rbp+0x10]
       mov      eax, dword ptr [rax+0x08]
       cmp      dword ptr [rbp-0x94], eax
       jae      G_M000_IG52
       mov      rax, bword ptr [rbp+0x10]
       mov      rax, bword ptr [rax]
       mov      ecx, dword ptr [rbp-0x94]
       lea      rcx, bword ptr [rax+8*rcx]
       mov      rdx, gword ptr [rbp-0xA0]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
 
G_M000_IG41:
       mov      rcx, 0xD1FFAB1E
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp+0x18]
       mov      edx, dword ptr [rbp-0x94]
       mov      r8d, 1
       call     [Lokad.Lython.Runtime.ArgumentPresence:set_Item(int,bool):this]
 
G_M000_IG42:
       mov      rcx, gword ptr [rbp+0x30]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_VariadicDictionaryIndex():int:this]
       test     eax, eax
       jl       G_M000_IG50
       mov      rcx, 0xD1FFAB1E
       call     CORINFO_HELP_NEWSFAST
       mov      gword ptr [rbp-0x100], rax
       mov      rcx, gword ptr [rbp+0x38]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:get_MemoryGovernor():Lokad.Lython.Runtime.MemoryGovernor:this]
       mov      gword ptr [rbp-0x1D0], rax
       mov      rdx, gword ptr [rbp-0x1D0]
       mov      rcx, gword ptr [rbp-0x100]
       mov      r8, gword ptr [rbp+0x28]
       call     [Lokad.Lython.Runtime.PyDict:.ctor(Lokad.Lython.Runtime.MemoryGovernor,Lokad.Lython.LythonSourceSpan):this]
       mov      rax, gword ptr [rbp-0x100]
       mov      gword ptr [rbp-0xA8], rax
       cmp      gword ptr [rbp-0x48], 0
       je       G_M000_IG49
       lea      rdx, [rbp-0xD8]
       mov      rcx, gword ptr [rbp-0x48]
       cmp      dword ptr [rcx], ecx
       call     [System.Collections.Generic.Dictionary`2[System.__Canon,System.__Canon]:GetEnumerator():System.Collections.Generic.Dictionary`2+Enumerator[System.__Canon,System.__Canon]:this]
       nop      
 
G_M000_IG43:
       jmp      G_M000_IG45
 
G_M000_IG44:
       mov      rcx, 0xD1FFAB1E
       call     CORINFO_HELP_COUNTPROFILE32
       lea      rdx, [rbp-0xE8]
       lea      rcx, [rbp-0xD8]
       mov      r8, 0xD1FFAB1E
       call     [System.Collections.Generic.Dictionary`2+Enumerator[System.__Canon,System.__Canon]:get_Current():System.Collections.Generic.KeyValuePair`2[System.__Canon,System.__Canon]:this]
       lea      rcx, [rbp-0xE8]
       mov      rdx, 0xD1FFAB1E
       call     [System.Collections.Generic.KeyValuePair`2[System.__Canon,System.__Canon]:get_Key():System.__Canon:this]
       mov      gword ptr [rbp-0x108], rax
       mov      rcx, gword ptr [rbp+0x38]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:get_MemoryGovernor():Lokad.Lython.Runtime.MemoryGovernor:this]
       mov      gword ptr [rbp-0x1D8], rax
       mov      rdx, gword ptr [rbp-0x1D8]
       mov      rcx, gword ptr [rbp-0x108]
       mov      r8, gword ptr [rbp+0x28]
       call     [Lokad.Lython.Runtime.Text.PyString:FromString(System.String,Lokad.Lython.Runtime.MemoryGovernor,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.Text.PyString]
       mov      gword ptr [rbp-0xF0], rax
       lea      rcx, [rbp-0xE8]
       mov      rdx, 0xD1FFAB1E
       call     [System.Collections.Generic.KeyValuePair`2[System.__Canon,System.__Canon]:get_Value():System.__Canon:this]
       mov      gword ptr [rbp-0x1E0], rax
       mov      r8, gword ptr [rbp-0x1E0]
       mov      rdx, gword ptr [rbp-0xF0]
       mov      rcx, gword ptr [rbp-0xA8]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.PyDict:SetItem(System.Object,System.Object):this]
 
G_M000_IG45:
       mov      eax, dword ptr [rbp-0x16C]
       dec      eax
       mov      dword ptr [rbp-0x16C], eax
       cmp      dword ptr [rbp-0x16C], 0
       jg       SHORT G_M000_IG47
 
G_M000_IG46:
       lea      rcx, [rbp-0x16C]
       mov      edx, 681
       call     CORINFO_HELP_PATCHPOINT
       jmp      rax
 
G_M000_IG47:
       lea      rcx, [rbp-0xD8]
       mov      rdx, 0xD1FFAB1E
       call     [System.Collections.Generic.Dictionary`2+Enumerator[System.__Canon,System.__Canon]:MoveNext():bool:this]
       test     eax, eax
       jne      G_M000_IG44
       mov      rcx, 0xD1FFAB1E
       call     CORINFO_HELP_COUNTPROFILE32
       nop      
 
G_M000_IG48:
       call     G_M000_IG53
       nop      
 
G_M000_IG49:
       mov      rcx, 0xD1FFAB1E
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, gword ptr [rbp+0x30]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_VariadicDictionaryIndex():int:this]
       mov      dword ptr [rbp-0xAC], eax
       mov      rax, bword ptr [rbp+0x10]
       mov      eax, dword ptr [rax+0x08]
       cmp      dword ptr [rbp-0xAC], eax
       jae      SHORT G_M000_IG52
       mov      rax, bword ptr [rbp+0x10]
       mov      rax, bword ptr [rax]
       mov      ecx, dword ptr [rbp-0xAC]
       lea      rcx, bword ptr [rax+8*rcx]
       mov      rdx, gword ptr [rbp-0xA8]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rcx, bword ptr [rbp+0x18]
       mov      edx, dword ptr [rbp-0xAC]
       mov      r8d, 1
       call     [Lokad.Lython.Runtime.ArgumentPresence:set_Item(int,bool):this]
 
G_M000_IG50:
       mov      rcx, 0xD1FFAB1E
       call     CORINFO_HELP_COUNTPROFILE32
       nop      
 
G_M000_IG51:
       add      rsp, 576
       pop      rbp
       ret      
 
G_M000_IG52:
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG53:
       sub      rsp, 88
 
G_M000_IG54:
       mov      rcx, 0xD1FFAB1E
       call     CORINFO_HELP_COUNTPROFILE32
       lea      rcx, [rbp-0xD8]
       mov      rdx, 0xD1FFAB1E
       call     [System.Collections.Generic.Dictionary`2+Enumerator[System.__Canon,System.__Canon]:Dispose():this]
       nop      
 
G_M000_IG55:
       add      rsp, 88
       ret      
 
; Total bytes of code 2798

; Assembly listing for method Lokad.Lython.Runtime.PyExecutableFunction:StartNativeCall(Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[System.Object],System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,bool,bool,System.Span`1[System.Object],byref,byref,byref):this (Tier1)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; Tier1 code
; optimized code
; optimized using Synthesized PGO
; rbp based frame
; fully interruptible
; with Synthesized PGO: fgCalledCount is 38640
; 28 inlinees with PGO data; 72 single block inlinees; 2 inlinees without PGO data

G_M000_IG01:
       push     rbp
       push     r15
       push     r14
       push     r13
       push     r12
       push     rdi
       push     rsi
       push     rbx
       sub      rsp, 680
       lea      rbp, [rsp+0x2E0]
       xor      eax, eax
       mov      qword ptr [rbp-0x1E8], rax
       vxorps   xmm4, xmm4, xmm4
       vmovdqa  xmmword ptr [rbp-0x1E0], xmm4
       vmovdqa  xmmword ptr [rbp-0x1D0], xmm4
       mov      rax, -384
 
G_M000_IG110:
       vmovdqa  xmmword ptr [rbp+rax-0x40], xmm4
       vmovdqa  xmmword ptr [rbp+rax-0x30], xmm4
       vmovdqa  xmmword ptr [rbp+rax-0x20], xmm4
       add      rax, 48
       jne      SHORT G_M000_IG110
       mov      qword ptr [rbp-0x40], rax
       mov      rbx, rcx
       mov      rdi, rdx
       mov      rsi, r9
       mov      r13, gword ptr [rbp+0x30]
       mov      r14, gword ptr [rbp+0x38]
 
G_M000_IG02:
       mov      r12, bword ptr [r8]
       mov      eax, dword ptr [r8+0x08]
       mov      dword ptr [rbp-0x194], eax
       mov      rdx, gword ptr [rbx+0x68]
       mov      r8d, dword ptr [rdx+0x9C]
       mov      ecx, dword ptr [rdx+0x98]
       mov      r10d, 4
       cmp      ecx, 4
       cmovg    r10d, ecx
       add      r8d, r10d
       jo       G_M000_IG103
       add      r8d, dword ptr [rdx+0xA4]
       jo       G_M000_IG103
       cmp      r8d, 16
       ja       G_M000_IG70
       mov      dword ptr [rbp-0x198], r8d
       mov      rdx, gword ptr [rbx+0x08]
       mov      r10, gword ptr [rdx+0x08]
       mov      gword ptr [rbp-0x280], r10
       mov      r9, gword ptr [r10+0x08]
       mov      gword ptr [rbp-0x278], r9
       mov      edx, dword ptr [r9+0x08]
       mov      dword ptr [rbp-0xC0], edx
       xor      ecx, ecx
       mov      qword ptr [rbp-0xC8], rcx
       cmp      edx, 64
       jg       G_M000_IG71
       mov      r11, 0xD1FFAB1E
 
G_M000_IG03:
       mov      gword ptr [rbp-0xD0], r11
       cmp      byte  ptr [rbp+0x48], 0
       jne      G_M000_IG72
 
G_M000_IG04:
       mov      r9, gword ptr [rbp-0x278]
       mov      r9d, dword ptr [r9+0x08]
       cmp      r9d, dword ptr [rbp-0x198]
       ja       G_M000_IG70
       mov      dword ptr [rbp-0x19C], r9d
       mov      r11, gword ptr [rbx+0x08]
       mov      gword ptr [rbp-0x1F0], r11
       mov      rcx, r12
       mov      bword ptr [rbp-0x260], rcx
       mov      eax, dword ptr [rbp-0x194]
       mov      edx, eax
       xor      rax, rax
       mov      gword ptr [rbp-0x108], rax
 
G_M000_IG05:
       mov      gword ptr [rbp-0x110], rax
 
G_M000_IG06:
       mov      r10, gword ptr [rbp-0x280]
       cmp      dword ptr [r10+0x28], 0
       jge      G_M000_IG76
       test     rdi, rdi
       je       SHORT G_M000_IG08
 
G_M000_IG07:
       movzx    r15, byte  ptr [rdi+0x34]
       test     r15d, r15d
       je       G_M000_IG76
 
G_M000_IG08:
       mov      r10d, dword ptr [r10+0x18]
       test     rsi, rsi
       setne    dil
       movzx    rdi, dil
       sub      r10d, edi
       cmp      r10d, edx
       jl       G_M000_IG78
       test     rsi, rsi
       jne      G_M000_IG79
 
G_M000_IG09:
       test     edx, edx
       je       SHORT G_M000_IG12
 
G_M000_IG10:
       xor      esi, esi
       mov      r12d, edx
 
G_M000_IG11:
       lea      edx, [rax+0x01]
       mov      edi, edx
       cmp      eax, r9d
       jae      G_M000_IG104
       lea      rdx, bword ptr [rbp-0xB8]
       mov      eax, eax
       lea      rax, bword ptr [rdx+8*rax]
       mov      rdx, gword ptr [rcx+rsi]
       test     rdx, rdx
       je       G_M000_IG80
       mov      rcx, rax
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       add      rsi, 8
       dec      r12d
       mov      eax, edi
       mov      rcx, bword ptr [rbp-0x260]
       mov      r9d, dword ptr [rbp-0x19C]
       jne      SHORT G_M000_IG11
 
G_M000_IG12:
       xor      ecx, ecx
       test     eax, eax
       jle      SHORT G_M000_IG15
 
G_M000_IG13:
       mov      edx, dword ptr [rbp-0xC0]
       cmp      ecx, edx
       jae      G_M000_IG81
       cmp      ecx, 64
       jge      G_M000_IG82
       mov      rdx, qword ptr [rbp-0xC8]
       bts      rdx, rcx
       mov      qword ptr [rbp-0xC8], rdx
 
G_M000_IG14:
       inc      ecx
       cmp      ecx, eax
       jl       SHORT G_M000_IG13
 
G_M000_IG15:
       xor      r12d, r12d
       mov      r11, gword ptr [rbp-0x1F0]
       mov      rcx, gword ptr [r11+0x08]
       cmp      dword ptr [rcx+0x18], 0
       jle      SHORT G_M000_IG18
 
G_M000_IG16:
       mov      edx, dword ptr [rbp-0xC0]
       cmp      r12d, edx
       jae      G_M000_IG83
       cmp      r12d, 64
       jge      G_M000_IG84
       mov      rcx, qword ptr [rbp-0xC8]
       bt       rcx, r12
       jae      G_M000_IG85
 
G_M000_IG17:
       inc      r12d
       mov      rcx, gword ptr [r11+0x08]
       cmp      r12d, dword ptr [rcx+0x18]
       jl       SHORT G_M000_IG16
 
G_M000_IG18:
       xor      r12d, r12d
       jmp      G_M000_IG57
 
G_M000_IG19:
       mov      rcx, rax
       mov      rdx, r9
       mov      r8, r13
       mov      r9, r14
       call     [Lokad.Lython.Runtime.PyDict:PrepareQueryKey(System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):System.ValueTuple`2[uint,bool]:this]
       mov      qword ptr [rbp-0x168], rax
       mov      eax, dword ptr [rbp-0x168]
       mov      dword ptr [rbp-0x16C], eax
       movzx    rdx, byte  ptr [rbp-0x164]
       mov      dword ptr [rbp-0x170], edx
       mov      r8, gword ptr [rbp-0x1F8]
       cmp      gword ptr [r8+0x28], 0
       je       G_M000_IG31
       cmp      dword ptr [r8+0x50], 0
       jne      G_M000_IG45
 
G_M000_IG20:
       cmp      dword ptr [rbp-0x170], 0
       jne      G_M000_IG45
       mov      r10, gword ptr [r8+0x28]
       mov      gword ptr [rbp-0x218], r10
       cmp      dword ptr [r8+0x4C], 0
       je       G_M000_IG44
 
G_M000_IG21:
       mov      ecx, dword ptr [r10+0x08]
       blsr     edx, ecx
       jne      G_M000_IG32
       dec      ecx
       and      ecx, dword ptr [rbp-0x168]
 
G_M000_IG22:
       cmp      ecx, dword ptr [r10+0x08]
       jae      G_M000_IG50
       mov      ecx, ecx
       lea      rcx, [rcx+4*rcx]
       mov      edx, dword ptr [r10+8*rcx+0x30]
       dec      edx
       js       G_M000_IG44
 
G_M000_IG23:
       cmp      edx, dword ptr [r10+0x08]
       jae      G_M000_IG50
       mov      ecx, edx
       lea      rcx, [rcx+4*rcx]
       lea      r9, bword ptr [r10+8*rcx+0x10]
       mov      bword ptr [rbp-0x220], r9
       cmp      gword ptr [r8+0x20], 0
       jne      G_M000_IG33
 
G_M000_IG24:
       mov      eax, dword ptr [rbp-0x16C]
       cmp      dword ptr [r9+0x18], eax
       jne      G_M000_IG34
       mov      rcx, 0xD1FFAB1E
       mov      r11, gword ptr [rcx]
       mov      gword ptr [rbp-0x228], r11
       mov      rcx, gword ptr [r9]
       mov      gword ptr [rbp-0x230], rcx
       mov      r11, r13
       test     r11, r11
       je       G_M000_IG35
 
G_M000_IG25:
       mov      rcx, r14
       test     rcx, rcx
       je       G_M000_IG36
 
G_M000_IG26:
       mov      rax, gword ptr [rbp-0x210]
       cmp      gword ptr [rbp-0x230], rax
       jne      G_M000_IG37
       test     rax, rax
       mov      r9, bword ptr [rbp-0x220]
       je       G_M000_IG34
 
G_M000_IG27:
       mov      eax, edx
 
G_M000_IG28:
       test     eax, eax
       jl       G_M000_IG52
       mov      r10, gword ptr [r8+0x30]
       test     r10, r10
       je       G_M000_IG51
       cmp      gword ptr [r8+0x20], 0
       jne      G_M000_IG49
       mov      gword ptr [rbp-0x248], r10
       cmp      eax, dword ptr [r10+0x08]
       jae      G_M000_IG50
       mov      edx, eax
       mov      r9, gword ptr [r10+8*rdx+0x10]
       test     r9, r9
       je       G_M000_IG48
 
G_M000_IG29:
       mov      rcx, r9
 
G_M000_IG30:
       mov      gword ptr [rbp-0x120], rcx
       not      eax
       shr      eax, 31
       mov      dword ptr [rbp-0x174], eax
       jmp      G_M000_IG53
 
G_M000_IG31:
       mov      rcx, gword ptr [r8+0x08]
       mov      r11, 0xD1FFAB1E
       call     [r11]Lokad.Lython.Runtime.IPyDictStorage:get_HasProtocolKeys():bool:this
       test     eax, eax
       mov      r8, gword ptr [rbp-0x1F8]
       jne      G_M000_IG45
       jmp      G_M000_IG20
 
G_M000_IG32:
       mov      eax, dword ptr [rbp-0x168]
       xor      edx, edx
       div      edx:eax, ecx
       mov      ecx, edx
       jmp      G_M000_IG22
 
G_M000_IG33:
       mov      rcx, gword ptr [r8+0x30]
       cmp      dword ptr [rcx+0x08], edx
       jbe      SHORT G_M000_IG34
       mov      rcx, gword ptr [r8+0x30]
       cmp      edx, dword ptr [rcx+0x08]
       jae      G_M000_IG50
       mov      dword ptr [rbp-0x17C], edx
       mov      r11d, edx
       cmp      gword ptr [rcx+8*r11+0x10], 0
       setne    cl
       movzx    rcx, cl
       test     ecx, ecx
       mov      edx, dword ptr [rbp-0x17C]
       mov      r8, gword ptr [rbp-0x1F8]
       jne      G_M000_IG24
 
G_M000_IG34:
       mov      rdx, r14
       test     rdx, rdx
       je       G_M000_IG42
       jmp      G_M000_IG43
 
G_M000_IG35:
       mov      dword ptr [rbp-0x17C], edx
       mov      ecx, 12
       call     [CORINFO_HELP_GETDYNAMIC_GCTHREADSTATIC_BASE_NOCTOR_OPTIMIZED]
       mov      r11, gword ptr [rax+0x18]
       mov      rax, r11
       mov      r11, rax
       mov      edx, dword ptr [rbp-0x17C]
       mov      r8, gword ptr [rbp-0x1F8]
       jmp      G_M000_IG25
 
G_M000_IG36:
       mov      rcx, gword ptr [r8+0x18]
       mov      gword ptr [rbp-0x240], rcx
       mov      rcx, gword ptr [rbp-0x240]
       mov      r8, gword ptr [rbp-0x1F8]
       jmp      G_M000_IG26
 
G_M000_IG37:
       mov      gword ptr [rbp-0x238], r11
       test     r11, r11
       mov      dword ptr [rbp-0x17C], edx
       mov      gword ptr [rbp-0x240], rcx
       je       SHORT G_M000_IG38
       mov      rdx, gword ptr [rbp-0x230]
       mov      rcx, 0xD1FFAB1E
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG39
       mov      r10, gword ptr [rbp-0x210]
       mov      rdx, r10
       test     rdx, rdx
       jne      SHORT G_M000_IG40
       mov      rax, gword ptr [rbp-0x210]
 
G_M000_IG38:
       mov      rcx, gword ptr [rbp-0x228]
       mov      rdx, gword ptr [rbp-0x230]
       mov      r8, rax
       call     [Lokad.Lython.Runtime.PyValueComparer:Equals(System.Object,System.Object):bool:this]
       jmp      SHORT G_M000_IG41
 
G_M000_IG39:
       mov      rax, gword ptr [rbp-0x210]
       jmp      SHORT G_M000_IG38
 
G_M000_IG40:
       mov      rcx, rax
       mov      r8, gword ptr [rbp-0x238]
       mov      r9, gword ptr [rbp-0x240]
       call     [Lokad.Lython.Runtime.Text.PyString:Equals(Lokad.Lython.Runtime.Text.PyString,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):bool:this]
 
G_M000_IG41:
       test     eax, eax
       mov      edx, dword ptr [rbp-0x17C]
       mov      r8, gword ptr [rbp-0x1F8]
       mov      r9, bword ptr [rbp-0x220]
       je       G_M000_IG34
       jmp      G_M000_IG27
 
G_M000_IG42:
       mov      rdx, gword ptr [r8+0x18]
 
G_M000_IG43:
       mov      rcx, r13
       call     [Lokad.Lython.Runtime.PyStructuralGuard:NoteWork(Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan)]
       mov      rcx, bword ptr [rbp-0x220]
       mov      edx, dword ptr [rcx+0x1C]
       dec      edx
       mov      eax, edx
       test     eax, eax
       mov      edx, eax
       mov      r8, gword ptr [rbp-0x1F8]
       mov      r10, gword ptr [rbp-0x218]
       jge      G_M000_IG23
 
G_M000_IG44:
       mov      eax, -1
       jmp      G_M000_IG28
 
G_M000_IG45:
       test     r13, r13
       jne      SHORT G_M000_IG47
       mov      rcx, r8
       mov      rdx, gword ptr [rbp-0x210]
       call     [Lokad.Lython.Runtime.PyDict:FindNativeIdentity(System.Object):int:this]
       test     eax, eax
       jge      SHORT G_M000_IG46
       xor      rcx, rcx
       mov      gword ptr [rsp+0x20], rcx
       mov      rcx, gword ptr [rbp-0x1F8]
       mov      rdx, gword ptr [rbp-0x210]
       mov      r8d, dword ptr [rbp-0x168]
       xor      r9, r9
       call     [Lokad.Lython.Runtime.PyDict:FindNativeIndex(System.Object,uint,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):int:this]
       mov      r8, gword ptr [rbp-0x1F8]
       jmp      G_M000_IG28
 
G_M000_IG46:
       mov      r8, gword ptr [rbp-0x1F8]
       jmp      G_M000_IG28
 
G_M000_IG47:
       mov      gword ptr [rsp+0x20], r13
       mov      gword ptr [rsp+0x28], r14
       xor      ecx, ecx
       mov      dword ptr [rsp+0x30], ecx
       mov      rcx, r8
       mov      rdx, gword ptr [rbp-0x210]
       mov      r8d, dword ptr [rbp-0x168]
       mov      r9d, dword ptr [rbp-0x170]
       call     [Lokad.Lython.Runtime.PyDict:ResolveContextualKey(System.Object,uint,bool,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,bool):int:this]
       mov      r8, gword ptr [rbp-0x1F8]
       jmp      G_M000_IG28
 
G_M000_IG48:
       vxorps   xmm0, xmm0, xmm0
       vmovdqu  xmmword ptr [rbp-0x190], xmm0
       mov      rdx, gword ptr [r8+0x28]
       cmp      eax, dword ptr [rdx+0x08]
       jae      G_M000_IG50
       mov      dword ptr [rbp-0x178], eax
       mov      ecx, eax
       lea      rcx, [rcx+4*rcx]
       mov      rdx, qword ptr [rdx+8*rcx+0x20]
       lea      rcx, [rbp-0x190]
       call     [System.Numerics.BigInteger:.ctor(long):this]
       mov      rcx, 0xD1FFAB1E
       call     CORINFO_HELP_NEWSFAST
       mov      gword ptr [rbp-0x250], rax
       lea      rcx, bword ptr [rax+0x08]
       mov      rdx, gword ptr [rbp-0x190]
       call     CORINFO_HELP_ASSIGN_REF
       mov      edx, dword ptr [rbp-0x188]
       mov      rax, gword ptr [rbp-0x250]
       mov      dword ptr [rax+0x10], edx
       mov      gword ptr [rbp-0x258], rax
       mov      edx, dword ptr [rbp-0x178]
       mov      rcx, gword ptr [rbp-0x248]
       mov      r8, rax
       call     CORINFO_HELP_ARRADDR_ST
       mov      rcx, gword ptr [rbp-0x258]
       mov      eax, dword ptr [rbp-0x178]
       jmp      G_M000_IG30
 
G_M000_IG49:
       mov      rcx, r10
       cmp      eax, dword ptr [rcx+0x08]
       jae      SHORT G_M000_IG50
       mov      edx, eax
       mov      rcx, gword ptr [rcx+8*rdx+0x10]
       jmp      G_M000_IG30
 
G_M000_IG50:
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG51:
       mov      rcx, 0xD1FFAB1E
       mov      r9, gword ptr [rcx]
       jmp      G_M000_IG29
 
G_M000_IG52:
       mov      rcx, 0xD1FFAB1E
       mov      rcx, gword ptr [rcx]
       jmp      G_M000_IG30
 
G_M000_IG53:
       cmp      byte  ptr [rbp-0x1A0], 0
       jne      G_M000_IG92
 
G_M000_IG54:
       mov      eax, dword ptr [rbp-0x174]
 
G_M000_IG55:
       test     eax, eax
       je       G_M000_IG93
       mov      esi, dword ptr [rbp-0x19C]
       cmp      edi, esi
       jae      G_M000_IG104
       lea      rcx, bword ptr [rbp-0xB8]
       mov      edx, edi
       lea      rcx, bword ptr [rcx+8*rdx]
       mov      rdx, gword ptr [rbp-0x120]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      r9d, esi
       mov      r11, gword ptr [rbp-0x1F0]
 
G_M000_IG56:
       inc      r12d
 
G_M000_IG57:
       mov      rsi, gword ptr [r11+0x08]
       cmp      r12d, dword ptr [rsi+0x1C]
       jge      G_M000_IG62
 
G_M000_IG58:
       mov      ecx, r12d
       add      ecx, dword ptr [rsi+0x18]
       mov      edi, ecx
       mov      edx, dword ptr [rbp-0xC0]
       cmp      edi, edx
       jae      G_M000_IG87
       cmp      edi, 64
       jge      G_M000_IG88
       mov      rax, qword ptr [rbp-0xC8]
       bt       rax, rdi
       jb       SHORT G_M000_IG56
 
G_M000_IG59:
       mov      rax, gword ptr [rsi+0x08]
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG104
       mov      ecx, ecx
       mov      rsi, gword ptr [rax+8*rcx+0x10]
       mov      rcx, r11
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_KeywordDefaultStorage():Lokad.Lython.Runtime.PyDict:this]
       mov      gword ptr [rbp-0x1F8], rax
       test     rax, rax
       je       G_M000_IG93
       mov      r10, gword ptr [rbp-0x1F0]
       mov      rcx, gword ptr [r10+0x28]
       cmp      r12d, dword ptr [rcx+0x08]
       jae      G_M000_IG104
       mov      r9, gword ptr [rcx+8*r12+0x10]
       mov      gword ptr [rbp-0x210], r9
       cmp      gword ptr [rax+0x28], 0
       je       G_M000_IG89
       test     r9, r9
       je       G_M000_IG91
       mov      r9, gword ptr [rbp-0x210]
       cmp      dword ptr [rax+0x50], 0
       setne    cl
       movzx    rcx, cl
       test     ecx, ecx
       jne      G_M000_IG90
 
G_M000_IG60:
       mov      rax, gword ptr [rbp-0x1F8]
       xor      r11, r11
       xor      r8, r8
       xor      edx, edx
 
G_M000_IG61:
       mov      gword ptr [rbp-0x268], r11
       mov      gword ptr [rbp-0x270], r8
       mov      byte  ptr [rbp-0x1A0], dl
       jmp      G_M000_IG19
 
G_M000_IG62:
       cmp      dword ptr [rsi+0x28], 0
       jge      G_M000_IG94
 
G_M000_IG63:
       mov      rcx, gword ptr [r11+0x08]
       cmp      dword ptr [rcx+0x2C], 0
       jge      G_M000_IG99
 
G_M000_IG64:
       xor      rcx, rcx
       mov      gword ptr [rbp-0x108], rcx
 
G_M000_IG65:
       mov      gword ptr [rbp-0x110], rcx
 
G_M000_IG66:
       mov      gword ptr [rbp-0x118], rcx
 
G_M000_IG67:
       mov      gword ptr [rbp-0x120], rcx
 
G_M000_IG68:
       mov      rdx, gword ptr [rbp-0xD0]
       mov      r9, qword ptr [rbp-0xC8]
       mov      ecx, dword ptr [rbp-0xC0]
       vxorps   ymm0, ymm0, ymm0
       vmovdqu  ymmword ptr [rbp-0x100], ymm0
       vmovdqu  xmmword ptr [rbp-0xE0], xmm0
       lea      rax, bword ptr [rbp-0xB8]
       mov      bword ptr [rbp-0x1B0], rax
       mov      r8d, dword ptr [rbp-0x198]
       mov      dword ptr [rbp-0x1A8], r8d
       mov      gword ptr [rbp-0x1E8], rdx
       mov      qword ptr [rbp-0x1E0], r9
       mov      dword ptr [rbp-0x1D8], ecx
       mov      gword ptr [rsp+0x20], r14
       movzx    rdx, byte  ptr [rbp+0x40]
       mov      dword ptr [rsp+0x28], edx
       mov      r15, bword ptr [rbp+0x50]
       mov      bword ptr [rsp+0x30], r15
       mov      rsi, bword ptr [rbp+0x58]
       mov      bword ptr [rsp+0x38], rsi
       mov      rsi, bword ptr [rbp+0x60]
       mov      bword ptr [rsp+0x40], rsi
       mov      rsi, bword ptr [rbp+0x68]
       mov      bword ptr [rsp+0x48], rsi
       lea      rdx, [rbp-0x1B0]
       lea      r8, [rbp-0x1E8]
       lea      r9, [rbp-0x100]
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.PyExecutableFunction:StartInline(System.Span`1[System.Object],Lokad.Lython.Runtime.ArgumentPresence,System.Nullable`1[Lokad.Lython.Runtime.BoundCallArguments],Lokad.Lython.LythonSourceSpan,bool,System.Span`1[System.Object],byref,byref,byref):this]
       nop      
 
G_M000_IG69:
       add      rsp, 680
       pop      rbx
       pop      rsi
       pop      rdi
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG70:
       call     [System.ThrowHelper:ThrowArgumentOutOfRangeException()]
       int3     
 
G_M000_IG71:
       add      edx, -64
       mov      rcx, 0xD1FFAB1E
       call     CORINFO_HELP_NEWARR_1_VC
       mov      r11, rax
       jmp      G_M000_IG03
 
G_M000_IG72:
       mov      eax, dword ptr [rbp-0x194]
       mov      r8d, dword ptr [rbp-0x198]
       cmp      eax, r8d
       ja       SHORT G_M000_IG73
       mov      ecx, eax
       lea      r8, [8*rcx]
       lea      rcx, bword ptr [rbp-0xB8]
       mov      rdx, r12
       call     [System.Buffer:BulkMoveWithWriteBarrier(byref,byref,nuint)]
       xor      esi, esi
       jmp      SHORT G_M000_IG75
 
G_M000_IG73:
       call     [System.ThrowHelper:ThrowArgumentException_DestinationTooShort()]
       int3     
 
G_M000_IG74:
       lea      rcx, [rbp-0xD0]
       mov      edx, esi
       mov      r8d, 1
       call     [Lokad.Lython.Runtime.ArgumentPresence:set_Item(int,bool):this]
       inc      esi
 
G_M000_IG75:
       cmp      esi, dword ptr [rbp-0xC0]
       jl       SHORT G_M000_IG74
       jmp      G_M000_IG68
 
G_M000_IG76:
       lea      rcx, bword ptr [rbp-0xB8]
       mov      bword ptr [rbp-0x1B0], rcx
       mov      dword ptr [rbp-0x1A8], r9d
       xor      rcx, rcx
       mov      bword ptr [rbp-0x1C0], rcx
 
G_M000_IG77:
       mov      dword ptr [rbp-0x1B8], ecx
       mov      r11, gword ptr [rbp-0x1F0]
       mov      gword ptr [rsp+0x20], r11
       mov      gword ptr [rsp+0x28], r13
       mov      gword ptr [rsp+0x30], rsi
       mov      gword ptr [rsp+0x38], rdi
       mov      bword ptr [rbp-0x1D0], r12
       mov      r12d, dword ptr [rbp-0x194]
       mov      dword ptr [rbp-0x1C8], r12d
       lea      rcx, [rbp-0x108]
       mov      qword ptr [rsp+0x48], rcx
       lea      rcx, [rbp-0x110]
       mov      qword ptr [rsp+0x50], rcx
       lea      rcx, [rbp-0x1B0]
       lea      r8, [rbp-0x1C0]
       lea      rdx, [rbp-0x1D0]
       mov      qword ptr [rsp+0x40], rdx
       lea      rdx, [rbp-0xD0]
       mov      r9, r14
       call     [Lokad.Lython.Runtime.LythonRuntime:BindSuppliedFunctionArguments(System.Span`1[System.Object],byref,System.ReadOnlySpan`1[Lokad.Lython.Runtime.CallArgumentValue],Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.FunctionBindingPlan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,System.Object,Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[System.Object],byref,byref)]
       mov      r9d, dword ptr [rbp-0x19C]
       jmp      G_M000_IG15
 
G_M000_IG78:
       mov      r11, gword ptr [rbp-0x1F0]
       mov      ecx, dword ptr [r11+0x30]
       mov      rdx, gword ptr [r11+0x10]
       mov      r8, r14
       call     [Lokad.Lython.Runtime.CallErrors:TooManyPositional(int,System.String,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.LythonRuntimeException]
       mov      rcx, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG79:
       mov      eax, 1
       test     r9d, r9d
       je       G_M000_IG104
       mov      gword ptr [rbp-0xB8], rsi
       jmp      G_M000_IG09
 
G_M000_IG80:
       mov      rcx, 0xD1FFAB1E
       call     CORINFO_HELP_NEWSFAST
       mov      r14, rax
       mov      rcx, r14
       mov      rdx, 0xD1FFAB1E
       call     [System.InvalidOperationException:.ctor(System.String):this]
       mov      rcx, r14
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG81:
       mov      r8, 0xD1FFAB1E
       call     [System.ArgumentOutOfRangeException:ThrowGreaterEqual[uint](uint,uint,System.String)]
       int3     
 
G_M000_IG82:
       lea      edx, [rcx-0x40]
       mov      r10, gword ptr [rbp-0xD0]
       cmp      edx, dword ptr [r10+0x08]
       jae      G_M000_IG104
       mov      rdx, gword ptr [rbp-0xD0]
       lea      r10d, [rcx-0x40]
       mov      byte  ptr [rdx+r10+0x10], 1
       jmp      G_M000_IG14
 
G_M000_IG83:
       mov      ecx, r12d
       mov      r8, 0xD1FFAB1E
       call     [System.ArgumentOutOfRangeException:ThrowGreaterEqual[uint](uint,uint,System.String)]
       int3     
 
G_M000_IG84:
       lea      ecx, [r12-0x40]
       mov      rdx, gword ptr [rbp-0xD0]
       cmp      ecx, dword ptr [rdx+0x08]
       jae      G_M000_IG104
       mov      rcx, gword ptr [rbp-0xD0]
       lea      edx, [r12-0x40]
       movzx    rcx, byte  ptr [rcx+rdx+0x10]
       test     ecx, ecx
       jne      G_M000_IG17
 
G_M000_IG85:
       mov      rcx, gword ptr [r11+0x08]
       mov      rcx, gword ptr [rcx+0x08]
       cmp      r12d, dword ptr [rcx+0x08]
       jae      G_M000_IG104
       mov      rsi, gword ptr [rcx+8*r12+0x10]
       lea      r8, [rbp-0x118]
       mov      rcx, r11
       mov      edx, r12d
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:TryGetPositionalDefault(int,byref):bool:this]
       test     eax, eax
       je       SHORT G_M000_IG86
       cmp      r12d, dword ptr [rbp-0x19C]
       jae      G_M000_IG104
       lea      rcx, bword ptr [rbp-0xB8]
       lea      rcx, bword ptr [rcx+8*r12]
       mov      rdx, gword ptr [rbp-0x118]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      r9d, dword ptr [rbp-0x19C]
       mov      r11, gword ptr [rbp-0x1F0]
       jmp      G_M000_IG17
 
G_M000_IG86:
       mov      r15, gword ptr [rbp-0x1F0]
       mov      ecx, dword ptr [r15+0x30]
       mov      rdx, gword ptr [r15+0x10]
       mov      r8, rsi
       mov      r9, r14
       call     [Lokad.Lython.Runtime.CallErrors:MissingArgument(int,System.String,System.String,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.LythonRuntimeException]
       mov      rcx, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG87:
       mov      ecx, edi
       mov      r8, 0xD1FFAB1E
       call     [System.ArgumentOutOfRangeException:ThrowGreaterEqual[uint](uint,uint,System.String)]
       int3     
 
G_M000_IG88:
       lea      eax, [rdi-0x40]
       mov      rdx, gword ptr [rbp-0xD0]
       cmp      eax, dword ptr [rdx+0x08]
       jae      G_M000_IG104
       mov      rax, gword ptr [rbp-0xD0]
       lea      edx, [rdi-0x40]
       movzx    rax, byte  ptr [rax+rdx+0x10]
       test     eax, eax
       jne      G_M000_IG56
       jmp      G_M000_IG59
 
G_M000_IG89:
       lea      rcx, [rbp-0x120]
       mov      qword ptr [rsp+0x20], rcx
       mov      rcx, rax
       mov      rdx, r9
       mov      r8, r13
       mov      r9, r14
       call     [Lokad.Lython.Runtime.PyDict:TryGetBridgeValue(System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,byref):bool:this]
       jmp      G_M000_IG55
 
G_M000_IG90:
       lea      rcx, [rbp-0x160]
       mov      rdx, r13
       mov      r8, r14
       call     [Lokad.Lython.Runtime.PyStructuralGuard:PushAmbient(Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.PyStructuralGuard+AmbientScope]
       mov      r11, gword ptr [rbp-0x160]
       mov      r8, gword ptr [rbp-0x158]
       movzx    rdx, byte  ptr [rbp-0x150]
       mov      rax, gword ptr [rbp-0x1F8]
       mov      r9, gword ptr [rbp-0x210]
       jmp      G_M000_IG61
 
G_M000_IG91:
       jmp      SHORT G_M000_IG90
 
G_M000_IG92:
       mov      ecx, 12
       call     [CORINFO_HELP_GETDYNAMIC_GCTHREADSTATIC_BASE_NOCTOR_OPTIMIZED]
       lea      rcx, bword ptr [rax+0x18]
       mov      rdx, gword ptr [rbp-0x268]
       call     CORINFO_HELP_ASSIGN_REF
       mov      ecx, 12
       call     [CORINFO_HELP_GETDYNAMIC_GCTHREADSTATIC_BASE_NOCTOR_OPTIMIZED]
       lea      rcx, bword ptr [rax+0x20]
       mov      rdx, gword ptr [rbp-0x270]
       call     CORINFO_HELP_ASSIGN_REF
       jmp      G_M000_IG54
 
G_M000_IG93:
       mov      r15, gword ptr [rbp-0x1F0]
       mov      ecx, dword ptr [r15+0x30]
       mov      rdx, gword ptr [r15+0x10]
       mov      r8, rsi
       mov      r9, r14
       call     [Lokad.Lython.Runtime.CallErrors:MissingArgument(int,System.String,System.String,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.LythonRuntimeException]
       mov      rcx, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG94:
       mov      rcx, 0xD1FFAB1E
       call     CORINFO_HELP_NEWSFAST
       mov      rdi, rax
       mov      esi, dword ptr [rsi+0x28]
       lea      rcx, bword ptr [rdi+0x08]
       mov      rdx, gword ptr [rbp-0x108]
       call     CORINFO_HELP_ASSIGN_REF
       cmp      gword ptr [rdi+0x08], 0
       je       SHORT G_M000_IG95
       mov      rcx, gword ptr [rdi+0x08]
       cmp      dword ptr [rcx+0x28], 0
       jne      G_M000_IG97
 
G_M000_IG95:
       cmp      esi, dword ptr [rbp-0x19C]
       jae      G_M000_IG104
       lea      rcx, bword ptr [rbp-0xB8]
       mov      eax, esi
       lea      r12, bword ptr [rcx+8*rax]
       mov      rcx, 0xD1FFAB1E
       mov      rdx, gword ptr [rcx]
       test     rdx, rdx
       jne      SHORT G_M000_IG96
       mov      rcx, 0xD1FFAB1E
       call     CORINFO_HELP_NEWSFAST
       mov      gword ptr [rbp-0x200], rax
       mov      rcx, 0xD1FFAB1E
       mov      rdx, gword ptr [rcx]
       mov      rcx, gword ptr [rbp-0x200]
       mov      r8, 0xD1FFAB1E
       call     [System.Delegate:CtorClosed(System.Object,nint):this]
       mov      rcx, 0xD1FFAB1E
       mov      rdx, gword ptr [rbp-0x200]
       call     CORINFO_HELP_ASSIGN_REF
       mov      rdx, gword ptr [rbp-0x200]
 
G_M000_IG96:
       mov      r9, r14
       mov      r8, r13
       xor      ecx, ecx
       call     [Lokad.Lython.Runtime.LythonRuntime:CreateTuple(int,System.Func`2[int,System.Object],Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.PyTuple]
       mov      rdx, rax
       mov      rcx, r12
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       jmp      SHORT G_M000_IG98
 
G_M000_IG97:
       mov      r12, gword ptr [rdi+0x08]
       mov      rcx, 0xD1FFAB1E
       call     CORINFO_HELP_NEWSFAST
       mov      gword ptr [rbp-0x208], rax
       mov      r12d, dword ptr [r12+0x28]
       mov      rcx, rax
       mov      rdx, rdi
       mov      r8, 0xD1FFAB1E
       call     [System.Delegate:CtorClosed(System.Object,nint):this]
       mov      ecx, r12d
       mov      rdx, gword ptr [rbp-0x208]
       mov      r8, r13
       mov      r9, r14
       call     [Lokad.Lython.Runtime.LythonRuntime:CreateTuple(int,System.Func`2[int,System.Object],Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.PyTuple]
       mov      edi, dword ptr [rbp-0x19C]
       cmp      esi, edi
       jae      G_M000_IG104
       lea      rcx, bword ptr [rbp-0xB8]
       mov      edx, esi
       lea      rcx, bword ptr [rcx+8*rdx]
       mov      rdx, rax
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
 
G_M000_IG98:
       lea      rcx, [rbp-0xD0]
       mov      edx, esi
       mov      r8d, 1
       call     [Lokad.Lython.Runtime.ArgumentPresence:set_Item(int,bool):this]
       mov      r9d, dword ptr [rbp-0x19C]
       mov      r11, gword ptr [rbp-0x1F0]
       jmp      G_M000_IG63
 
G_M000_IG99:
       mov      rsi, gword ptr [r13+0xA0]
       mov      rcx, 0xD1FFAB1E
       call     CORINFO_HELP_NEWSFAST
       mov      rdi, rax
       xor      r8d, r8d
       mov      dword ptr [rsp+0x20], r8d
       mov      r8, gword ptr [rsi+0x88]
       mov      rcx, rdi
       mov      r9, r14
       xor      edx, edx
       call     [Lokad.Lython.Runtime.PyDict:.ctor(int,Lokad.Lython.Runtime.MemoryGovernor,Lokad.Lython.LythonSourceSpan,bool):this]
       cmp      gword ptr [rbp-0x110], 0
       je       SHORT G_M000_IG102
       lea      rdx, [rbp-0x148]
       mov      rcx, gword ptr [rbp-0x110]
       cmp      dword ptr [rcx], ecx
       call     [System.Collections.Generic.Dictionary`2[System.__Canon,System.__Canon]:GetEnumerator():System.Collections.Generic.Dictionary`2+Enumerator[System.__Canon,System.__Canon]:this]
       jmp      SHORT G_M000_IG101
 
G_M000_IG100:
       mov      rcx, gword ptr [rbp-0x130]
       mov      rsi, gword ptr [rbp-0x128]
       mov      rdx, gword ptr [r13+0xA0]
       mov      rdx, gword ptr [rdx+0x88]
       mov      r8, r14
       call     [Lokad.Lython.Runtime.Text.PyString:FromString(System.String,Lokad.Lython.Runtime.MemoryGovernor,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.Text.PyString]
       mov      rdx, rax
       mov      rcx, rdi
       mov      r8, rsi
       call     [Lokad.Lython.Runtime.PyDict:SetItem(System.Object,System.Object):this]
 
G_M000_IG101:
       lea      rcx, [rbp-0x148]
       mov      rdx, 0xD1FFAB1E
       call     [System.Collections.Generic.Dictionary`2+Enumerator[System.__Canon,System.__Canon]:MoveNext():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG100
 
G_M000_IG102:
       mov      rsi, gword ptr [rbp-0x1F0]
       mov      rcx, gword ptr [rsi+0x08]
       mov      esi, dword ptr [rcx+0x2C]
       cmp      esi, dword ptr [rbp-0x19C]
       jae      SHORT G_M000_IG104
       lea      rcx, bword ptr [rbp-0xB8]
       mov      edx, esi
       lea      rcx, bword ptr [rcx+8*rdx]
       mov      rdx, rdi
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       lea      rcx, [rbp-0xD0]
       mov      edx, esi
       mov      r8d, 1
       call     [Lokad.Lython.Runtime.ArgumentPresence:set_Item(int,bool):this]
       jmp      G_M000_IG64
 
G_M000_IG103:
       call     CORINFO_HELP_OVERFLOW
       int3     
 
G_M000_IG104:
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG105:
       sub      rsp, 88
 
G_M000_IG106:
       cmp      byte  ptr [rbp-0x1A0], 0
       je       SHORT G_M000_IG108
 
G_M000_IG107:
       mov      ecx, 12
       call     [CORINFO_HELP_GETDYNAMIC_GCTHREADSTATIC_BASE_NOCTOR_OPTIMIZED]
       lea      rcx, bword ptr [rax+0x18]
       mov      rdx, gword ptr [rbp-0x268]
       call     CORINFO_HELP_ASSIGN_REF
       mov      ecx, 12
       call     [CORINFO_HELP_GETDYNAMIC_GCTHREADSTATIC_BASE_NOCTOR_OPTIMIZED]
       lea      rcx, bword ptr [rax+0x20]
       mov      rdx, gword ptr [rbp-0x270]
       call     CORINFO_HELP_ASSIGN_REF
 
G_M000_IG108:
       nop      
 
G_M000_IG109:
       add      rsp, 88
       ret      
 
; Total bytes of code 3979

; Assembly listing for method Lokad.Lython.Runtime.LythonRuntime:BindFunctionArgumentsInto(System.Span`1[System.Object],byref,System.ReadOnlySpan`1[Lokad.Lython.Runtime.CallArgumentValue],Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.FunctionBindingPlan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,bool,System.Object,Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[System.Object]) (Tier1)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; Tier1 code
; optimized code
; optimized using Synthesized PGO
; rbp based frame
; fully interruptible
; with Synthesized PGO: fgCalledCount is 39304
; 21 inlinees with PGO data; 52 single block inlinees; 1 inlinees without PGO data

G_M000_IG01:
       push     rbp
       push     r15
       push     r14
       push     r13
       push     r12
       push     rdi
       push     rsi
       push     rbx
       sub      rsp, 456
       lea      rbp, [rsp+0x200]
       vxorps   xmm4, xmm4, xmm4
       mov      rax, -192
 
G_M000_IG96:
       vmovdqa  xmmword ptr [rbp+rax-0x40], xmm4
       vmovdqa  xmmword ptr [rbp+rax-0x30], xmm4
       vmovdqa  xmmword ptr [rbp+rax-0x20], xmm4
       add      rax, 48
       jne      SHORT G_M000_IG96
       mov      qword ptr [rbp-0x40], rax
       mov      rbx, rdx
       mov      rdi, r9
       mov      rsi, gword ptr [rbp+0x30]
       mov      r14d, dword ptr [rbp+0x40]
       mov      rax, gword ptr [rbp+0x48]
       mov      r10, gword ptr [rbp+0x50]
       mov      rdx, bword ptr [rbp+0x58]
 
G_M000_IG02:
       mov      r13, bword ptr [rdx]
       mov      r12d, dword ptr [rdx+0x08]
       mov      r9, bword ptr [rcx]
       mov      bword ptr [rbp-0x190], r9
       mov      r11d, dword ptr [rcx+0x08]
       mov      dword ptr [rbp-0xDC], r11d
       xor      ecx, ecx
       mov      rdx, gword ptr [rsi+0x08]
       cmp      dword ptr [rdx+0x28], 0
       jge      G_M000_IG64
       test     r10, r10
       je       G_M000_IG62
 
G_M000_IG03:
       movzx    r15, byte  ptr [r10+0x34]
       test     r15d, r15d
       je       G_M000_IG64
 
G_M000_IG04:
       mov      edx, dword ptr [rdx+0x18]
       test     rax, rax
       setne    r8b
       movzx    r8, r8b
       sub      edx, r8d
       cmp      edx, r12d
       jl       G_M000_IG65
       test     rax, rax
       jne      G_M000_IG66
 
G_M000_IG05:
       test     r12d, r12d
       je       SHORT G_M000_IG08
 
G_M000_IG06:
       xor      eax, eax
 
G_M000_IG07:
       lea      edx, [rcx+0x01]
       mov      dword ptr [rbp-0x4C], edx
       cmp      ecx, r11d
       jae      G_M000_IG90
       mov      ecx, ecx
       lea      rcx, bword ptr [r9+8*rcx]
       mov      qword ptr [rbp-0x110], rax
       mov      rdx, gword ptr [rax+r13]
       test     rdx, rdx
       je       G_M000_IG67
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rax, qword ptr [rbp-0x110]
       add      rax, 8
       dec      r12d
       mov      ecx, dword ptr [rbp-0x4C]
       mov      r9, bword ptr [rbp-0x190]
       mov      r11d, dword ptr [rbp-0xDC]
       jne      SHORT G_M000_IG07
 
G_M000_IG08:
       xor      edx, edx
       test     ecx, ecx
       jle      G_M000_IG63
 
G_M000_IG09:
       mov      r8d, dword ptr [rbx+0x10]
       cmp      edx, r8d
       jae      G_M000_IG68
       cmp      edx, 64
       jge      G_M000_IG69
       mov      r8, qword ptr [rbx+0x08]
       bts      r8, rdx
       mov      qword ptr [rbx+0x08], r8
 
G_M000_IG10:
       inc      edx
       cmp      edx, ecx
       jl       SHORT G_M000_IG09
 
G_M000_IG11:
       mov      r15, gword ptr [rbp+0x38]
 
G_M000_IG12:
       xor      r13d, r13d
       mov      r8, gword ptr [rsi+0x08]
       cmp      dword ptr [r8+0x18], 0
       jle      SHORT G_M000_IG15
 
G_M000_IG13:
       mov      edx, dword ptr [rbx+0x10]
       cmp      r13d, edx
       jae      G_M000_IG70
       cmp      r13d, 64
       jge      G_M000_IG71
       mov      r8, qword ptr [rbx+0x08]
       bt       r8, r13
       jae      G_M000_IG72
 
G_M000_IG14:
       inc      r13d
       mov      rcx, gword ptr [rsi+0x08]
       cmp      r13d, dword ptr [rcx+0x18]
       jl       SHORT G_M000_IG13
 
G_M000_IG15:
       xor      r13d, r13d
 
G_M000_IG16:
       test     r14b, r14b
       jne      G_M000_IG59
 
G_M000_IG17:
       mov      r12, gword ptr [rsi+0x08]
       cmp      r13d, dword ptr [r12+0x1C]
       jge      G_M000_IG59
 
G_M000_IG18:
       mov      ecx, r13d
       add      ecx, dword ptr [r12+0x18]
       mov      eax, ecx
       mov      dword ptr [rbp-0x5C], eax
       mov      edx, dword ptr [rbx+0x10]
       cmp      eax, edx
       jae      G_M000_IG74
       cmp      eax, 64
       jge      G_M000_IG75
       mov      rdx, qword ptr [rbx+0x08]
       bt       rdx, rax
       jb       G_M000_IG58
 
G_M000_IG19:
       mov      rdx, gword ptr [r12+0x08]
       cmp      ecx, dword ptr [rdx+0x08]
       jae      G_M000_IG90
       mov      ecx, ecx
       mov      r12, gword ptr [rdx+8*rcx+0x10]
       mov      gword ptr [rbp-0x118], r12
       mov      rcx, rsi
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_KeywordDefaultStorage():Lokad.Lython.Runtime.PyDict:this]
       mov      gword ptr [rbp-0x120], rax
       test     rax, rax
       mov      r12, gword ptr [rbp-0x118]
       je       G_M000_IG80
       mov      rcx, gword ptr [rsi+0x28]
       cmp      r13d, dword ptr [rcx+0x08]
       jae      G_M000_IG90
       mov      r10, gword ptr [rcx+8*r13+0x10]
       mov      gword ptr [rbp-0x140], r10
       cmp      gword ptr [rax+0x28], 0
       je       G_M000_IG76
       test     r10, r10
       je       G_M000_IG78
       mov      r10, gword ptr [rbp-0x140]
       cmp      dword ptr [rax+0x50], 0
       setne    cl
       movzx    rcx, cl
       test     ecx, ecx
       jne      G_M000_IG77
 
G_M000_IG20:
       mov      rax, gword ptr [rbp-0x120]
       xor      r9, r9
       xor      r11, r11
       xor      r8d, r8d
 
G_M000_IG21:
       mov      gword ptr [rbp-0x198], r9
       mov      gword ptr [rbp-0x1A0], r11
       mov      byte  ptr [rbp-0xE0], r8b
 
G_M000_IG22:
       mov      rcx, rax
       mov      rdx, r10
       mov      r8, r15
       mov      r9, rdi
       call     [Lokad.Lython.Runtime.PyDict:PrepareQueryKey(System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):System.ValueTuple`2[uint,bool]:this]
       mov      qword ptr [rbp-0xB0], rax
       mov      eax, dword ptr [rbp-0xB0]
       mov      dword ptr [rbp-0xB4], eax
       movzx    rdx, byte  ptr [rbp-0xAC]
       mov      dword ptr [rbp-0xB8], edx
       mov      r8, gword ptr [rbp-0x120]
       cmp      gword ptr [r8+0x28], 0
       je       G_M000_IG34
       cmp      dword ptr [r8+0x50], 0
       jne      G_M000_IG47
 
G_M000_IG23:
       cmp      dword ptr [rbp-0xB8], 0
       jne      G_M000_IG47
       mov      r10, gword ptr [r8+0x28]
       mov      gword ptr [rbp-0x148], r10
       cmp      dword ptr [r8+0x4C], 0
       je       G_M000_IG46
 
G_M000_IG24:
       mov      r9d, dword ptr [r10+0x08]
       mov      dword ptr [rbp-0x104], r9d
       mov      ecx, r9d
       blsr     edx, ecx
       jne      G_M000_IG35
       dec      ecx
       and      ecx, dword ptr [rbp-0xB0]
 
G_M000_IG25:
       cmp      ecx, r9d
       jae      G_M000_IG52
       mov      ecx, ecx
       lea      rcx, [rcx+4*rcx]
       mov      edx, dword ptr [r10+8*rcx+0x30]
       dec      edx
       js       G_M000_IG46
 
G_M000_IG26:
       cmp      edx, r9d
       jae      G_M000_IG52
       mov      ecx, edx
       lea      rcx, [rcx+4*rcx]
       lea      r11, bword ptr [r10+8*rcx+0x10]
       mov      bword ptr [rbp-0x150], r11
       cmp      gword ptr [r8+0x20], 0
       jne      G_M000_IG36
 
G_M000_IG27:
       mov      eax, dword ptr [rbp-0xB4]
       cmp      dword ptr [r11+0x18], eax
       jne      G_M000_IG37
       mov      rcx, 0xD1FFAB1E
       mov      rcx, gword ptr [rcx]
       mov      gword ptr [rbp-0x158], rcx
       mov      rcx, gword ptr [r11]
       mov      gword ptr [rbp-0x160], rcx
       mov      rax, r15
       test     rax, rax
       je       G_M000_IG38
 
G_M000_IG28:
       mov      rcx, rdi
       test     rcx, rcx
       je       G_M000_IG39
 
G_M000_IG29:
       mov      r12, gword ptr [rbp-0x140]
       cmp      gword ptr [rbp-0x160], r12
       jne      G_M000_IG40
       test     r12, r12
       mov      r11, bword ptr [rbp-0x150]
       mov      r12, gword ptr [rbp-0x118]
       je       G_M000_IG37
 
G_M000_IG30:
       mov      eax, edx
 
G_M000_IG31:
       test     eax, eax
       jl       G_M000_IG54
       mov      r10, gword ptr [r8+0x30]
       test     r10, r10
       je       G_M000_IG53
       cmp      gword ptr [r8+0x20], 0
       jne      G_M000_IG51
       mov      gword ptr [rbp-0x178], r10
       cmp      eax, dword ptr [r10+0x08]
       jae      G_M000_IG52
       mov      edx, eax
       mov      r9, gword ptr [r10+8*rdx+0x10]
       test     r9, r9
       je       G_M000_IG50
 
G_M000_IG32:
       mov      rcx, r9
 
G_M000_IG33:
       mov      gword ptr [rbp-0x68], rcx
       not      eax
       shr      eax, 31
       mov      dword ptr [rbp-0xBC], eax
       jmp      G_M000_IG55
 
G_M000_IG34:
       mov      rcx, gword ptr [r8+0x08]
       mov      r11, 0xD1FFAB1E
       call     [r11]Lokad.Lython.Runtime.IPyDictStorage:get_HasProtocolKeys():bool:this
       test     eax, eax
       mov      r8, gword ptr [rbp-0x120]
       jne      G_M000_IG47
       jmp      G_M000_IG23
 
G_M000_IG35:
       mov      eax, dword ptr [rbp-0xB0]
       xor      edx, edx
       div      edx:eax, ecx
       mov      ecx, edx
       jmp      G_M000_IG25
 
G_M000_IG36:
       mov      rcx, gword ptr [r8+0x30]
       cmp      dword ptr [rcx+0x08], edx
       jbe      SHORT G_M000_IG37
       mov      rcx, gword ptr [r8+0x30]
       mov      gword ptr [rbp-0x1A8], rcx
       cmp      edx, dword ptr [rcx+0x08]
       jae      G_M000_IG52
       mov      dword ptr [rbp-0xC4], edx
       mov      ecx, edx
       mov      rax, gword ptr [rbp-0x1A8]
       cmp      gword ptr [rax+8*rcx+0x10], 0
       setne    cl
       movzx    rcx, cl
       test     ecx, ecx
       mov      edx, dword ptr [rbp-0xC4]
       mov      r8, gword ptr [rbp-0x120]
       jne      G_M000_IG27
 
G_M000_IG37:
       mov      rdx, rdi
       test     rdx, rdx
       je       G_M000_IG44
       jmp      G_M000_IG45
 
G_M000_IG38:
       mov      dword ptr [rbp-0xC4], edx
       mov      ecx, 12
       call     [CORINFO_HELP_GETDYNAMIC_GCTHREADSTATIC_BASE_NOCTOR_OPTIMIZED]
       mov      rax, gword ptr [rax+0x18]
       mov      edx, dword ptr [rbp-0xC4]
       mov      r8, gword ptr [rbp-0x120]
       jmp      G_M000_IG28
 
G_M000_IG39:
       mov      rcx, gword ptr [r8+0x18]
       mov      gword ptr [rbp-0x170], rcx
       mov      rcx, gword ptr [rbp-0x170]
       mov      r8, gword ptr [rbp-0x120]
       jmp      G_M000_IG29
 
G_M000_IG40:
       mov      gword ptr [rbp-0x168], rax
       test     rax, rax
       mov      dword ptr [rbp-0xC4], edx
       mov      gword ptr [rbp-0x170], rcx
       je       SHORT G_M000_IG41
       mov      rdx, gword ptr [rbp-0x160]
       mov      rcx, 0xD1FFAB1E
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG41
       mov      rdx, r12
       test     rdx, rdx
       jne      SHORT G_M000_IG42
 
G_M000_IG41:
       mov      rcx, gword ptr [rbp-0x158]
       mov      rdx, gword ptr [rbp-0x160]
       mov      r8, r12
       call     [Lokad.Lython.Runtime.PyValueComparer:Equals(System.Object,System.Object):bool:this]
       jmp      SHORT G_M000_IG43
 
G_M000_IG42:
       mov      rcx, rax
       mov      r8, gword ptr [rbp-0x168]
       mov      r9, gword ptr [rbp-0x170]
       call     [Lokad.Lython.Runtime.Text.PyString:Equals(Lokad.Lython.Runtime.Text.PyString,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):bool:this]
 
G_M000_IG43:
       test     eax, eax
       mov      edx, dword ptr [rbp-0xC4]
       mov      r8, gword ptr [rbp-0x120]
       mov      r11, bword ptr [rbp-0x150]
       mov      r12, gword ptr [rbp-0x118]
       je       G_M000_IG37
       jmp      G_M000_IG30
 
G_M000_IG44:
       mov      rdx, gword ptr [r8+0x18]
 
G_M000_IG45:
       mov      rcx, r15
       call     [Lokad.Lython.Runtime.PyStructuralGuard:NoteWork(Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan)]
       mov      rcx, bword ptr [rbp-0x150]
       mov      edx, dword ptr [rcx+0x1C]
       dec      edx
       mov      eax, edx
       test     eax, eax
       mov      edx, eax
       mov      r8, gword ptr [rbp-0x120]
       mov      r9d, dword ptr [rbp-0x104]
       mov      r10, gword ptr [rbp-0x148]
       jge      G_M000_IG26
 
G_M000_IG46:
       mov      eax, -1
       jmp      G_M000_IG31
 
G_M000_IG47:
       test     r15, r15
       jne      SHORT G_M000_IG49
       mov      rcx, r8
       mov      rdx, gword ptr [rbp-0x140]
       call     [Lokad.Lython.Runtime.PyDict:FindNativeIdentity(System.Object):int:this]
       test     eax, eax
       jge      SHORT G_M000_IG48
       xor      rcx, rcx
       mov      gword ptr [rsp+0x20], rcx
       mov      rcx, gword ptr [rbp-0x120]
       mov      rdx, gword ptr [rbp-0x140]
       mov      r8d, dword ptr [rbp-0xB0]
       xor      r9, r9
       call     [Lokad.Lython.Runtime.PyDict:FindNativeIndex(System.Object,uint,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):int:this]
       mov      r8, gword ptr [rbp-0x120]
       jmp      G_M000_IG31
 
G_M000_IG48:
       mov      r8, gword ptr [rbp-0x120]
       jmp      G_M000_IG31
 
G_M000_IG49:
       mov      gword ptr [rsp+0x20], r15
       mov      gword ptr [rsp+0x28], rdi
       xor      ecx, ecx
       mov      dword ptr [rsp+0x30], ecx
       mov      rcx, r8
       mov      rdx, gword ptr [rbp-0x140]
       mov      r8d, dword ptr [rbp-0xB0]
       mov      r9d, dword ptr [rbp-0xB8]
       call     [Lokad.Lython.Runtime.PyDict:ResolveContextualKey(System.Object,uint,bool,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,bool):int:this]
       mov      r8, gword ptr [rbp-0x120]
       jmp      G_M000_IG31
 
G_M000_IG50:
       vxorps   xmm0, xmm0, xmm0
       vmovdqu  xmmword ptr [rbp-0xD8], xmm0
       mov      rdx, gword ptr [r8+0x28]
       cmp      eax, dword ptr [rdx+0x08]
       jae      G_M000_IG52
       mov      dword ptr [rbp-0xC0], eax
       mov      ecx, eax
       lea      rcx, [rcx+4*rcx]
       mov      rdx, qword ptr [rdx+8*rcx+0x20]
       lea      rcx, [rbp-0xD8]
       call     [System.Numerics.BigInteger:.ctor(long):this]
       mov      rcx, 0xD1FFAB1E
       call     CORINFO_HELP_NEWSFAST
       mov      gword ptr [rbp-0x180], rax
       lea      rcx, bword ptr [rax+0x08]
       mov      rdx, gword ptr [rbp-0xD8]
       call     CORINFO_HELP_ASSIGN_REF
       mov      edx, dword ptr [rbp-0xD0]
       mov      rax, gword ptr [rbp-0x180]
       mov      dword ptr [rax+0x10], edx
       mov      gword ptr [rbp-0x188], rax
       mov      edx, dword ptr [rbp-0xC0]
       mov      rcx, gword ptr [rbp-0x178]
       mov      r8, rax
       call     CORINFO_HELP_ARRADDR_ST
       mov      rcx, gword ptr [rbp-0x188]
       mov      eax, dword ptr [rbp-0xC0]
       jmp      G_M000_IG33
 
G_M000_IG51:
       mov      rcx, r10
       cmp      eax, dword ptr [rcx+0x08]
       jae      SHORT G_M000_IG52
       mov      edx, eax
       mov      rcx, gword ptr [rcx+8*rdx+0x10]
       jmp      G_M000_IG33
 
G_M000_IG52:
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG53:
       mov      rcx, 0xD1FFAB1E
       mov      r9, gword ptr [rcx]
       jmp      G_M000_IG32
 
G_M000_IG54:
       mov      rcx, 0xD1FFAB1E
       mov      rcx, gword ptr [rcx]
       jmp      G_M000_IG33
 
G_M000_IG55:
       cmp      byte  ptr [rbp-0xE0], 0
       jne      G_M000_IG79
 
G_M000_IG56:
       mov      eax, dword ptr [rbp-0xBC]
 
G_M000_IG57:
       test     eax, eax
       je       G_M000_IG80
       mov      r12d, dword ptr [rbp-0x5C]
       cmp      r12d, dword ptr [rbp-0xDC]
       jae      G_M000_IG90
       mov      ecx, r12d
       mov      r12, bword ptr [rbp-0x190]
       lea      rcx, bword ptr [r12+8*rcx]
       mov      rdx, gword ptr [rbp-0x68]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      r9, r12
       mov      r11d, dword ptr [rbp-0xDC]
 
G_M000_IG58:
       inc      r13d
       jmp      G_M000_IG16
 
G_M000_IG59:
       mov      r12, gword ptr [rsi+0x08]
       cmp      dword ptr [r12+0x28], 0
       jge      G_M000_IG81
 
G_M000_IG60:
       mov      rcx, gword ptr [rsi+0x08]
       cmp      dword ptr [rcx+0x2C], 0
       jge      G_M000_IG86
 
G_M000_IG61:
       add      rsp, 456
       pop      rbx
       pop      rsi
       pop      rdi
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG62:
       cmp      dword ptr [r8+0x08], 0
       jne      SHORT G_M000_IG64
       jmp      G_M000_IG04
 
G_M000_IG63:
       mov      r15, gword ptr [rbp+0x38]
       jmp      G_M000_IG12
 
G_M000_IG64:
       mov      bword ptr [rbp-0xF0], r9
       mov      dword ptr [rbp-0xE8], r11d
       mov      gword ptr [rsp+0x20], rsi
       mov      r15, gword ptr [rbp+0x38]
       mov      gword ptr [rsp+0x28], r15
       mov      gword ptr [rsp+0x30], rax
       mov      gword ptr [rsp+0x38], r10
       mov      bword ptr [rbp-0x100], r13
       mov      dword ptr [rbp-0xF8], r12d
       lea      rcx, [rbp-0x40]
       mov      qword ptr [rsp+0x48], rcx
       lea      rcx, [rbp-0x48]
       mov      qword ptr [rsp+0x50], rcx
       lea      rcx, [rbp-0xF0]
       lea      rdx, [rbp-0x100]
       mov      qword ptr [rsp+0x40], rdx
       mov      r9, rdi
       mov      rdx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime:BindSuppliedFunctionArguments(System.Span`1[System.Object],byref,System.ReadOnlySpan`1[Lokad.Lython.Runtime.CallArgumentValue],Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.FunctionBindingPlan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,System.Object,Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[System.Object],byref,byref)]
       mov      r9, bword ptr [rbp-0x190]
       mov      r11d, dword ptr [rbp-0xDC]
       jmp      G_M000_IG12
 
G_M000_IG65:
       mov      ecx, dword ptr [rsi+0x30]
       mov      rdx, gword ptr [rsi+0x10]
       mov      r8, rdi
       call     [Lokad.Lython.Runtime.CallErrors:TooManyPositional(int,System.String,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.LythonRuntimeException]
       mov      rcx, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG66:
       mov      dword ptr [rbp-0x4C], 1
       test     r11d, r11d
       je       G_M000_IG90
       mov      rcx, r9
       mov      rdx, rax
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      ecx, dword ptr [rbp-0x4C]
       mov      r9, bword ptr [rbp-0x190]
       mov      r11d, dword ptr [rbp-0xDC]
       jmp      G_M000_IG05
 
G_M000_IG67:
       mov      rcx, 0xD1FFAB1E
       call     CORINFO_HELP_NEWSFAST
       mov      rsi, rax
       mov      rcx, rsi
       mov      rdx, 0xD1FFAB1E
       call     [System.InvalidOperationException:.ctor(System.String):this]
       mov      rcx, rsi
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG68:
       mov      ecx, edx
       mov      edx, r8d
       mov      r8, 0xD1FFAB1E
       call     [System.ArgumentOutOfRangeException:ThrowGreaterEqual[uint](uint,uint,System.String)]
       int3     
 
G_M000_IG69:
       mov      r8, gword ptr [rbx]
       lea      eax, [rdx-0x40]
       cmp      eax, dword ptr [r8+0x08]
       jae      G_M000_IG90
       lea      eax, [rdx-0x40]
       mov      byte  ptr [r8+rax+0x10], 1
       jmp      G_M000_IG10
 
G_M000_IG70:
       mov      ecx, r13d
       mov      r8, 0xD1FFAB1E
       call     [System.ArgumentOutOfRangeException:ThrowGreaterEqual[uint](uint,uint,System.String)]
       int3     
 
G_M000_IG71:
       mov      r8, gword ptr [rbx]
       lea      ecx, [r13-0x40]
       cmp      ecx, dword ptr [r8+0x08]
       jae      G_M000_IG90
       lea      ecx, [r13-0x40]
       movzx    r8, byte  ptr [r8+rcx+0x10]
       test     r8d, r8d
       jne      G_M000_IG14
 
G_M000_IG72:
       mov      r8, gword ptr [rsi+0x08]
       mov      r8, gword ptr [r8+0x08]
       cmp      r13d, dword ptr [r8+0x08]
       jae      G_M000_IG90
       mov      r12, gword ptr [r8+8*r13+0x10]
       lea      r8, [rbp-0x58]
       mov      rcx, rsi
       mov      edx, r13d
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:TryGetPositionalDefault(int,byref):bool:this]
       test     eax, eax
       je       SHORT G_M000_IG73
       cmp      r13d, dword ptr [rbp-0xDC]
       jae      G_M000_IG90
       mov      rax, bword ptr [rbp-0x190]
       lea      rcx, bword ptr [rax+8*r13]
       mov      rdx, gword ptr [rbp-0x58]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      r9, bword ptr [rbp-0x190]
       mov      r11d, dword ptr [rbp-0xDC]
       jmp      G_M000_IG14
 
G_M000_IG73:
       mov      ecx, dword ptr [rsi+0x30]
       mov      rdx, gword ptr [rsi+0x10]
       mov      r8, r12
       mov      r9, rdi
       call     [Lokad.Lython.Runtime.CallErrors:MissingArgument(int,System.String,System.String,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.LythonRuntimeException]
       mov      rcx, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG74:
       mov      ecx, eax
       mov      r8, 0xD1FFAB1E
       call     [System.ArgumentOutOfRangeException:ThrowGreaterEqual[uint](uint,uint,System.String)]
       int3     
 
G_M000_IG75:
       mov      rdx, gword ptr [rbx]
       lea      r8d, [rax-0x40]
       cmp      r8d, dword ptr [rdx+0x08]
       jae      G_M000_IG90
       lea      r8d, [rax-0x40]
       movzx    rdx, byte  ptr [rdx+r8+0x10]
       test     edx, edx
       jne      G_M000_IG58
       jmp      G_M000_IG19
 
G_M000_IG76:
       lea      rcx, [rbp-0x68]
       mov      qword ptr [rsp+0x20], rcx
       mov      rcx, rax
       mov      rdx, r10
       mov      r8, r15
       mov      r9, rdi
       call     [Lokad.Lython.Runtime.PyDict:TryGetBridgeValue(System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,byref):bool:this]
       jmp      G_M000_IG57
 
G_M000_IG77:
       lea      rcx, [rbp-0xA8]
       mov      rdx, r15
       mov      r8, rdi
       call     [Lokad.Lython.Runtime.PyStructuralGuard:PushAmbient(Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.PyStructuralGuard+AmbientScope]
       mov      r9, gword ptr [rbp-0xA8]
       mov      r11, gword ptr [rbp-0xA0]
       movzx    r8, byte  ptr [rbp-0x98]
       mov      rax, gword ptr [rbp-0x120]
       mov      r10, gword ptr [rbp-0x140]
       jmp      G_M000_IG21
 
G_M000_IG78:
       jmp      SHORT G_M000_IG77
 
G_M000_IG79:
       mov      ecx, 12
       call     [CORINFO_HELP_GETDYNAMIC_GCTHREADSTATIC_BASE_NOCTOR_OPTIMIZED]
       lea      rcx, bword ptr [rax+0x18]
       mov      rdx, gword ptr [rbp-0x198]
       call     CORINFO_HELP_ASSIGN_REF
       mov      ecx, 12
       call     [CORINFO_HELP_GETDYNAMIC_GCTHREADSTATIC_BASE_NOCTOR_OPTIMIZED]
       lea      rcx, bword ptr [rax+0x20]
       mov      rdx, gword ptr [rbp-0x1A0]
       call     CORINFO_HELP_ASSIGN_REF
       jmp      G_M000_IG56
 
G_M000_IG80:
       mov      ecx, dword ptr [rsi+0x30]
       mov      rdx, gword ptr [rsi+0x10]
       mov      r8, r12
       mov      r9, rdi
       call     [Lokad.Lython.Runtime.CallErrors:MissingArgument(int,System.String,System.String,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.LythonRuntimeException]
       mov      rcx, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG81:
       mov      rcx, 0xD1FFAB1E
       call     CORINFO_HELP_NEWSFAST
       mov      r14, rax
       mov      r13d, dword ptr [r12+0x28]
       lea      rcx, bword ptr [r14+0x08]
       mov      rdx, gword ptr [rbp-0x40]
       call     CORINFO_HELP_ASSIGN_REF
       cmp      gword ptr [r14+0x08], 0
       je       SHORT G_M000_IG82
       mov      rcx, gword ptr [r14+0x08]
       cmp      dword ptr [rcx+0x28], 0
       jne      G_M000_IG84
 
G_M000_IG82:
       cmp      r13d, dword ptr [rbp-0xDC]
       jae      G_M000_IG90
       mov      ecx, r13d
       mov      r14, bword ptr [rbp-0x190]
       lea      rax, bword ptr [r14+8*rcx]
       mov      bword ptr [rbp-0x128], rax
       mov      rcx, 0xD1FFAB1E
       mov      rdx, gword ptr [rcx]
       test     rdx, rdx
       jne      SHORT G_M000_IG83
       mov      rcx, 0xD1FFAB1E
       call     CORINFO_HELP_NEWSFAST
       mov      gword ptr [rbp-0x130], rax
       mov      rcx, 0xD1FFAB1E
       mov      rdx, gword ptr [rcx]
       mov      rcx, gword ptr [rbp-0x130]
       mov      r8, 0xD1FFAB1E
       call     [System.Delegate:CtorClosed(System.Object,nint):this]
       mov      rcx, 0xD1FFAB1E
       mov      rdx, gword ptr [rbp-0x130]
       call     CORINFO_HELP_ASSIGN_REF
       mov      rdx, gword ptr [rbp-0x130]
 
G_M000_IG83:
       mov      r9, rdi
       mov      r8, r15
       xor      ecx, ecx
       call     [Lokad.Lython.Runtime.LythonRuntime:CreateTuple(int,System.Func`2[int,System.Object],Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.PyTuple]
       mov      rdx, rax
       mov      rcx, bword ptr [rbp-0x128]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       jmp      SHORT G_M000_IG85
 
G_M000_IG84:
       mov      r12, gword ptr [r14+0x08]
       mov      rcx, 0xD1FFAB1E
       call     CORINFO_HELP_NEWSFAST
       mov      gword ptr [rbp-0x138], rax
       mov      r12d, dword ptr [r12+0x28]
       mov      rcx, rax
       mov      rdx, r14
       mov      r8, 0xD1FFAB1E
       call     [System.Delegate:CtorClosed(System.Object,nint):this]
       mov      ecx, r12d
       mov      rdx, gword ptr [rbp-0x138]
       mov      r8, r15
       mov      r9, rdi
       call     [Lokad.Lython.Runtime.LythonRuntime:CreateTuple(int,System.Func`2[int,System.Object],Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.PyTuple]
       mov      r12d, dword ptr [rbp-0xDC]
       cmp      r13d, r12d
       jae      G_M000_IG90
       mov      ecx, r13d
       mov      r14, bword ptr [rbp-0x190]
       lea      rcx, bword ptr [r14+8*rcx]
       mov      rdx, rax
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
 
G_M000_IG85:
       mov      rcx, rbx
       mov      edx, r13d
       mov      r8d, 1
       call     [Lokad.Lython.Runtime.ArgumentPresence:set_Item(int,bool):this]
       mov      r9, bword ptr [rbp-0x190]
       mov      r11d, dword ptr [rbp-0xDC]
       jmp      G_M000_IG60
 
G_M000_IG86:
       mov      r14, gword ptr [r15+0xA0]
       mov      rcx, 0xD1FFAB1E
       call     CORINFO_HELP_NEWSFAST
       mov      r13, rax
       xor      r8d, r8d
       mov      dword ptr [rsp+0x20], r8d
       mov      r8, gword ptr [r14+0x88]
       mov      rcx, r13
       mov      r9, rdi
       xor      edx, edx
       call     [Lokad.Lython.Runtime.PyDict:.ctor(int,Lokad.Lython.Runtime.MemoryGovernor,Lokad.Lython.LythonSourceSpan,bool):this]
       cmp      gword ptr [rbp-0x48], 0
       je       SHORT G_M000_IG89
       lea      rdx, [rbp-0x90]
       mov      rcx, gword ptr [rbp-0x48]
       cmp      dword ptr [rcx], ecx
       call     [System.Collections.Generic.Dictionary`2[System.__Canon,System.__Canon]:GetEnumerator():System.Collections.Generic.Dictionary`2+Enumerator[System.__Canon,System.__Canon]:this]
       jmp      SHORT G_M000_IG88
 
G_M000_IG87:
       mov      rcx, gword ptr [rbp-0x78]
       mov      r14, gword ptr [rbp-0x70]
       mov      rdx, gword ptr [r15+0xA0]
       mov      rdx, gword ptr [rdx+0x88]
       mov      r8, rdi
       call     [Lokad.Lython.Runtime.Text.PyString:FromString(System.String,Lokad.Lython.Runtime.MemoryGovernor,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.Text.PyString]
       mov      rdx, rax
       mov      rcx, r13
       mov      r8, r14
       call     [Lokad.Lython.Runtime.PyDict:SetItem(System.Object,System.Object):this]
 
G_M000_IG88:
       lea      rcx, [rbp-0x90]
       mov      rdx, 0xD1FFAB1E
       call     [System.Collections.Generic.Dictionary`2+Enumerator[System.__Canon,System.__Canon]:MoveNext():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG87
 
G_M000_IG89:
       mov      rcx, gword ptr [rsi+0x08]
       mov      esi, dword ptr [rcx+0x2C]
       cmp      esi, dword ptr [rbp-0xDC]
       jae      SHORT G_M000_IG90
       mov      ecx, esi
       mov      r14, bword ptr [rbp-0x190]
       lea      rcx, bword ptr [r14+8*rcx]
       mov      rdx, r13
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rcx, rbx
       mov      edx, esi
       mov      r8d, 1
       call     [Lokad.Lython.Runtime.ArgumentPresence:set_Item(int,bool):this]
       jmp      G_M000_IG61
 
G_M000_IG90:
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG91:
       sub      rsp, 88
 
G_M000_IG92:
       cmp      byte  ptr [rbp-0xE0], 0
       je       SHORT G_M000_IG94
 
G_M000_IG93:
       mov      ecx, 12
       call     [CORINFO_HELP_GETDYNAMIC_GCTHREADSTATIC_BASE_NOCTOR_OPTIMIZED]
       lea      rcx, bword ptr [rax+0x18]
       mov      rdx, gword ptr [rbp-0x198]
       call     CORINFO_HELP_ASSIGN_REF
       mov      ecx, 12
       call     [CORINFO_HELP_GETDYNAMIC_GCTHREADSTATIC_BASE_NOCTOR_OPTIMIZED]
       lea      rcx, bword ptr [rax+0x20]
       mov      rdx, gword ptr [rbp-0x1A0]
       call     CORINFO_HELP_ASSIGN_REF
 
G_M000_IG94:
       nop      
 
G_M000_IG95:
       add      rsp, 88
       ret      
 
; Total bytes of code 3388

