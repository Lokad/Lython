from pathlib import Path
import ast
r = Path(__file__).parent
out = r / 'refined'; out.mkdir()
for name in ['check.py', 'check-protocols.py', 'freeze.py', 'inspect-jit.py']:
    s = (r / name).read_text(encoding='utf-8')
    s = s.replace("r.parent / 'word-buffer-loan-r324'", "r.parent.parent / 'word-buffer-loan-r324'")
    s = s.replace("r.parent / 'word-buffer-loan-r324/catalog.json'", "r.parent.parent / 'word-buffer-loan-r324/catalog.json'")
    ast.parse(s)
    (out / name).write_text(s, encoding='utf-8', newline='\n')
