from pathlib import Path
p = Path('src/Lokad.Lython/Runtime/LythonRuntime.Calls.Binding.cs')
s = p.read_text(encoding='utf-8')
a = s.index('        // A bound receiver follows exactly the same positional/overflow rules,')
b = s.index('\n        for (var i = 0; i < plan.PositionalCount; i++)', a)
supplied = s[a:b].replace('!flatPositional && argumentIndex < argumentCount', 'argumentIndex < argumentCount')
s = s[:a] + '''        else BindSuppliedFunctionArguments(values, ref assigned, arguments, span, plan, context,
            receiver, callSite, operands, out extraPositional, out extraKeywords);
''' + s[b:]
a = s.index('    // Constructed function objects retain a wrapper plus binding plan')
helper = '''    // Named and variadic calls interpret their supplied forms here. Ordinary
    // flat calls keep their direct fill and live-default completion together;
    // the shared binder need not inline this larger dynamic parsing branch.
    private static void BindSuppliedFunctionArguments(Span<object> values, ref ArgumentPresence assigned,
        ReadOnlySpan<CallArgumentValue> arguments, LythonSourceSpan span, FunctionBindingPlan plan,
        ExecutionContext context, object? receiver, ExecutableCallSite? callSite,
        ReadOnlySpan<object?> operands, out PyList? extraPositional,
        out Dictionary<string, object>? extraKeywords)
    {
        extraPositional = null;
        extraKeywords = null;
        var positionalIndex = 0;
''' + supplied + '''
    }

'''
s = s[:a] + helper + s[a:]
p.write_text(s, encoding='utf-8', newline='\n')
print('Moved existing dynamic supplied-argument parsing out of shared default completion; no logic duplicated.', flush=True)
