from pathlib import Path
import subprocess
r = Path(__file__).parent / 'refined'
for name in ['check.py', 'check-protocols.py', 'freeze.py', 'inspect-jit.py']:
    subprocess.run(['python', '-X', 'utf8', str(r / name)], check=True)
