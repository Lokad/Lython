from pathlib import Path
import hashlib, json, os, subprocess
r = Path(__file__).parent
identity = json.loads((r / 'candidate-identity.json').read_text(encoding='utf-8'))
catalog = json.loads((r.parent.parent / 'word-buffer-loan-r324/catalog.json').read_text(encoding='utf-8'))
catalog['cases'] = [c for c in catalog['cases'] if c['id'] == 'scripts.file-search.large']
assert len(catalog['cases']) == 1
(r / 'jit-catalog.json').write_text(json.dumps(catalog, ensure_ascii=False) + '\n', encoding='utf-8', newline='\n')
env = dict(os.environ)
env['DOTNET_ROOT'] = 'C:/Users/JoannesVermorel/.dotnet11'
env['PATH'] = env['DOTNET_ROOT'] + ';C:/Python313;' + env['PATH']
env['DOTNET_JitDisasm'] = '*StartNativeCall* *BindFunctionArgumentsInto*'
env['DOTNET_JitDisasmDiffable'] = '1'
fixture = (r / 'jit-fixtures').resolve(); fixture.mkdir()
env['TEMP'] = env['TMP'] = str(fixture)
for role in ['reference', 'candidate']:
    image = (r / role).resolve()
    assert hashlib.sha256((image / 'Lokad.Lython.dll').read_bytes()).hexdigest() == identity['coreSHA256'][role]
    disassembly = (r / ('jit-' + role + '.asm')).resolve()
    assert not disassembly.exists()
    env['DOTNET_JitStdOutFile'] = str(disassembly)
    with (r / ('jit-' + role + '.log')).open('w', encoding='utf-8', newline='\n') as f:
        done = subprocess.run([env['DOTNET_ROOT'] + '/dotnet.exe', str(image / 'Allocation.dll'), str(image), str((r / 'jit-catalog.json').resolve()), str((r / ('jit-' + role + '.json')).resolve())], env=env, stdout=f, stderr=subprocess.STDOUT, timeout=40)
    assert done.returncode == 0, (r / ('jit-' + role + '.log')).read_text(encoding='utf-8')[-2000:]
    s = disassembly.read_text(encoding='utf-8')
    assert 'Assembly listing for method' in s and 'StartNativeCall' in s and 'BindFunctionArgumentsInto' in s
    print(role, '\n'.join(line for line in s.splitlines() if 'Assembly listing' in line or 'Total bytes' in line or ('call' in line and 'BindFunctionArgumentsInto' in line)), flush=True)
assert not list(fixture.iterdir())
fixture.rmdir()
