from pathlib import Path
import os, subprocess
r = Path(__file__).parent
env = dict(os.environ)
env['DOTNET_ROOT'] = 'C:/Users/JoannesVermorel/.dotnet11'
env['PATH'] = env['DOTNET_ROOT'] + ';C:/Python313;' + env['PATH']
for framework in ['net11.0', 'net10.0']:
    for label, project, selection in [('internal', 'tests/Lokad.Lython.Tests/Lokad.Lython.Tests.csproj', 'FullyQualifiedName~CallBindingSubsystemTests|FullyQualifiedName~CallArgumentEvaluationTests|FullyQualifiedName~RawDescriptorGetDispatchTests|FullyQualifiedName~DescriptorMethodBindingTests'), ('public', 'tests/Lokad.Lython.PublicApi.Tests/Lokad.Lython.PublicApi.Tests.csproj', 'FullyQualifiedName~ClassSubscriptionTests|FullyQualifiedName~ClassSubscriptionLifetimeTests|FullyQualifiedName~RawDescriptorGetTests|FullyQualifiedName~PreparedCallArgumentTests|FullyQualifiedName~CallArgumentEvaluationTests')]:
        log = r / ('protocol-' + label + '-' + framework + '.log')
        with log.open('w', encoding='utf-8', newline='\n') as f:
            done = subprocess.run([env['DOTNET_ROOT'] + '/dotnet.exe', 'test', project, '-c', 'Release', '-f', framework, '--filter', selection, '--nologo'], stdout=f, stderr=subprocess.STDOUT, env=env)
        print(framework, label, done.returncode, '\n'.join(log.read_text(encoding='utf-8').splitlines()[-4:]), flush=True)
        assert done.returncode == 0
