from pathlib import Path
import ast, hashlib, json, subprocess, tarfile
r = Path(__file__).parent
canonical = 'benchmarks/results/2026-11-13-json-byte-input/source-checks.tar.xz'
p = Path(canonical)
assert subprocess.check_output(['git', 'show', 'HEAD:' + canonical]) == p.read_bytes()
with tarfile.open(p) as t: data = t.extractfile('final/candidate-core.dll').read()
sha = hashlib.sha256(data).hexdigest()
assert sha == 'bff487b5c1f452479b5a36cec08a478e1a85b1940e0c7e1a605a79a8d70085af'
proof = dict(path='word-buffer-loan-b690-20261113/reference/Lokad.Lython.dll', canonical=canonical, member='final/candidate-core.dll', sha256=sha, bytes=len(data))
s = (r.parent / 'checkpoint-cpython-r318/inspect-command.py').read_text(encoding='utf-8')
a = s.index('proof='); b = s.index('\nwith(', a)
s = s[:a] + 'proof=' + repr(proof) + s[b:]
s = s.replace("all('builtin-setup'not in x for x in aliases)", "all('word-buffer-loan-b690' in x or 'word-buffer-loan-b691' in x for x in aliases)")
ast.parse(s)
ssh = ['C:/Windows/System32/OpenSSH/ssh.exe', '-i', 'C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem', '-o', 'BatchMode=yes', '-o', 'ConnectTimeout=15', 'lokad@20.166.121.73']
done = subprocess.run(ssh + ['python3 -'], input=s, text=True, encoding='utf-8', capture_output=True)
assert done.returncode == 0, done.stderr
d = json.loads(done.stdout)
(r / 'retirement-inspection.json').write_text(json.dumps(d['retire'], indent=2) + '\n', encoding='utf-8', newline='\n')
print('Read-only: proved olderbff working image', d['retire']['allocatedBytes'], 'bytes,', d['retire']['links'], 'aliases; current9d and earlier CPython checkpoint images preserved.', flush=True)
