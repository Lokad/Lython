from pathlib import Path
import ast, hashlib, json, tarfile
r = Path(__file__).parent
prior = r.parent / 'word-buffer-loan-r324/b691'
out = r / 'b693'; out.mkdir()
oldroot = '/home/lokad/lython-bench-checks/word-buffer-loan-b691-20261113'
root = '/home/lokad/lython-bench-checks/final-slot-binding-b693-20261113'
unit = 'lython-b693-final-slot-binding-20261113'
source = json.loads((r / 'candidate-identity.json').read_text(encoding='utf-8'))
identity = json.loads((prior / 'identity.json').read_text(encoding='utf-8'))
identity['sourceRevision'] = 'R326 frozenb3b13da2 vs R324 frozen9d157bb2; one final-slot binder; fixed B685 workers and optional0.4 adapter'
identity['purpose'] = 'Complete search with keyword-only default and captured-text control; no new cache/arena or allocation-reduction claim'
identity['coreSHA256'] = {label: source['coreSHA256']['candidate' if label.startswith('candidate') else 'reference'] for label in ['reference', 'candidate', 'reference-control', 'candidate-control']}
(out / 'identity.json').write_text(json.dumps(identity, indent=2) + '\n', encoding='utf-8', newline='\n')
for name in ['collect.py', 'archive-owned.py', 'run.sh', 'retrieve.py', 'summarize.py']:
    s = (prior / name).read_text(encoding='utf-8').replace(oldroot, root).replace('lython-b691-word-buffer-loan-20261113', unit).replace('B691', 'B693')
    if name.endswith('.py'): ast.parse(s)
    (out / name).write_text(s, encoding='utf-8', newline='\n')
with tarfile.open(out / 'payload.tgz', 'w:gz') as t:
    for name in ['identity.json', 'collect.py', 'archive-owned.py', 'run.sh']: t.add(out / name, arcname=name)
    t.add(prior / 'representative.json' if (prior / 'representative.json').exists() else prior.parent / 'b690/representative.json', arcname='representative.json')
    t.add(r / 'candidate-core.dll', arcname='candidate-core.dll')
    t.add(r / 'candidate-identity.json', arcname='source-identity.json')
with tarfile.open(out / 'payload.tgz') as t: unpacked = sum(m.size for m in t.getmembers())
config = dict(root=root, sourceRoot='/home/lokad/lython-bench-checks/word-buffer-loan-b690-20261113', unit=unit, identity=identity, retire=[json.loads((r / 'retirement-inspection.json').read_text(encoding='utf-8'))], payloadBytes=(out / 'payload.tgz').stat().st_size, payloadSHA256=hashlib.sha256((out / 'payload.tgz').read_bytes()).hexdigest(), unpackedBytes=unpacked)
(out / 'config.json').write_text(json.dumps(config, indent=2) + '\n', encoding='utf-8', newline='\n')
s = (prior.parent / 'b690/launch.py').read_text(encoding='utf-8')
s = s.replace("'reference-core.dll',", '').replace(",'reference-source-identity.json'", '')
s = s.replace(" assert digest(root/'representative.json')", " os.link(source/'source-identity.json',root/'reference-source-identity.json')\n assert digest(root/'representative.json')")
s = s.replace("  assert digest(root/(role+'-core.dll'))", "  if role=='reference':os.link(source/'candidate/Lokad.Lython.dll',root/'reference-core.dll')\n  assert digest(root/(role+'-core.dll'))")
s = s.replace("assert all('positional-zip-b685'not in name and 'whole-script-profile-b686'not in name for name in aliases)", "assert all('word-buffer-loan-b690' in name or 'word-buffer-loan-b691' in name for name in aliases)")
s = s.replace('lython-b690-fixtures', 'lython-b693-fixtures')
ast.parse(s)
(out / 'launch.py').write_text(s, encoding='utf-8', newline='\n')
print('Prepared two complete scripts/four Lython roles,12s warmups,1s rotating batches,180s owner; one new core image, older archivedbff aliases retire under lease.', flush=True)
