from pathlib import Path
import ast,base64,datetime,hashlib,json,subprocess,tarfile
r=Path(__file__).parent;config=json.loads((r/'config.json').read_text(encoding='utf-8'));source=json.loads((r.parent/'refined/candidate-identity.json').read_text(encoding='utf-8'))
assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==sha for p,sha in source['sources'].items())
for old in config['retire']:
 p=Path(old['canonical']);assert subprocess.check_output(['git','show','HEAD:'+p.as_posix()])==p.read_bytes()
 if old['member']is None:data=p.read_bytes()
 else:
  with tarfile.open(p)as t:data=t.extractfile(old['member']).read()
 assert hashlib.sha256(data).hexdigest()==old['sha256']and len(data)==old['bytes']
code=r'''from pathlib import Path
import ast,fcntl,hashlib,io,json,os,shutil,stat,subprocess,sys,tarfile
config=CONFIG
base=Path('/home/lokad/lython-bench-checks').resolve();root=Path(config['root']);source=Path(config['sourceRoot'])
assert root.parent==base and source.parent==base and source.resolve()==source and not root.exists()
digest=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
with(base/'comparison-vm.lock').open('a')as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert not(source/'guest-fixtures').exists()
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[d]otnet.*complete-jobs.dll|[p]erf record|[p]ython3.*cpython-worker.py'],capture_output=True).returncode==1
 for name,sha in config['identity']['candidateAuxiliaryFiles'].items():assert digest(source/'candidate'/name)==sha
 payload=sys.stdin.buffer.read(config['payloadBytes']+1);assert len(payload)==config['payloadBytes']and hashlib.sha256(payload).hexdigest()==config['payloadSHA256']
 before=shutil.disk_usage(base).free
 for old in config['retire']:
  p=base/old['path'];s=p.lstat();assert p.resolve(strict=True)==p and p.is_relative_to(base)and stat.S_ISREG(s.st_mode)and s.st_uid==os.getuid()
  assert(s.st_dev,s.st_ino,s.st_nlink,s.st_size)==(old['device'],old['inode'],old['links'],old['bytes'])and digest(p)==old['sha256']
  aliases=[]
  for folder,dirs,files in os.walk(base,followlinks=False):
   for name in files:
    q=Path(folder)/name;t=q.lstat()
    if(t.st_dev,t.st_ino)==(s.st_dev,s.st_ino):aliases.append(str(q.relative_to(base)))
  assert sorted(aliases)==sorted(old['aliases'])and len(aliases)==s.st_nlink
  assert all('final-slot-binding-b693' in name for name in aliases)
 assert before+sum(x['allocatedBytes']for x in config['retire'])>254*1024*1024+config['unpackedBytes']
 for old in config['retire']:
  for name in old['aliases']:
   q=base/name;t=q.lstat();assert q.resolve(strict=True)==q and q.is_relative_to(base)and(t.st_dev,t.st_ino)==(old['device'],old['inode'])
   q.unlink()
 root.mkdir()
 with tarfile.open(fileobj=io.BytesIO(payload),mode='r:gz')as t:
  assert set(t.getnames())=={'identity.json','representative.json','collect.py','archive-owned.py','run.sh','candidate-core.dll','source-identity.json'}
  t.extractall(root,filter='data')
 os.link(source/'cpython-worker.py',root/'cpython-worker.py')
 for role in ['candidate','reference']:
  (root/role).mkdir()
  for name,sha in config['identity'][role+'AuxiliaryFiles'].items():
   assert digest(source/'candidate'/name)==sha;os.link(source/'candidate'/name,root/role/name)
  if role=='reference':os.link(source/'candidate/Lokad.Lython.dll',root/'reference-core.dll')
  assert digest(root/(role+'-core.dll'))==config['identity']['coreSHA256'][role]
  os.link(root/(role+'-core.dll'),root/role/'Lokad.Lython.dll')
 os.link(source/'source-identity.json',root/'reference-source-identity.json')
 assert digest(root/'representative.json')==config['identity']['catalogSHA256']
 for name in ['collect.py','archive-owned.py']:ast.parse((root/name).read_text())
 subprocess.run(['/bin/sh','-n',str(root/'run.sh')],check=True)
 after=shutil.disk_usage(base).free;assert after>254*1024*1024
 (root/'space-preflight.json').write_text(json.dumps(dict(freshIdleLease=True,beforeFreeBytes=before,afterStagingFreeBytes=after,osFloorMiB=240,evidenceHeadroomMiB=12,additionalArchiveHeadroomMiB=2,retiredByteProvedHistoricalWorkingCopies=config['retire']))+'\n')
 fixture=root/'guest-fixtures';fixture.mkdir();subprocess.run(['sudo','-n','mount','-t','tmpfs','-o','size=128m,mode=0700,uid=lokad,gid=lokad','lython-b694-fixtures',str(fixture)],check=True)
try:subprocess.run(['sudo','-n','systemd-run','--unit='+config['unit'],'--property=User=lokad','--property=WorkingDirectory='+str(root),'--property=RuntimeMaxSec=180','--property=TimeoutStopSec=30','--property=KillMode=control-group','/bin/sh',str(root/'run.sh')],check=True)
except BaseException:
 subprocess.run(['sudo','-n','umount',str(fixture)],check=True);fixture.rmdir();raise
print(subprocess.check_output(['systemctl','show',config['unit']+'.service','--property=ActiveState,MainPID,RuntimeMaxUSec'],text=True))
'''.replace('CONFIG',repr(config))
ast.parse(code);(r/'launch-command.py').write_text(code,encoding='utf-8',newline='\n');ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
done=subprocess.run(ssh+["python3 -c 'import base64;exec(base64.b64decode(\""+base64.b64encode(code.encode()).decode()+"\"))'"],input=(r/'payload.tgz').read_bytes(),capture_output=True)
(r/'launch.log').write_bytes(done.stdout+done.stderr);print((done.stdout+done.stderr).decode(),flush=True);assert done.returncode==0
now=datetime.datetime.now(datetime.timezone.utc);(r/'observe-not-before.json').write_text(json.dumps(dict(startedUTC=now.isoformat(),doNotObserveBeforeUTC=(now+datetime.timedelta(seconds=160)).isoformat(),ownerSeconds=180,stopSeconds=30),indent=2)+'\n',encoding='utf-8',newline='\n')
