from pathlib import Path
import ast, hashlib, json, tarfile
r = Path(__file__).parent
prior = r / 'b693'; out = r / 'b694'; out.mkdir()
source = json.loads((r / 'refined/candidate-identity.json').read_text(encoding='utf-8'))
assert source['coreSHA256']['candidate'].startswith('660a0338')
identity = json.loads((prior / 'identity.json').read_text(encoding='utf-8'))
identity['sourceRevision'] = 'R326 refined660a0338 vs R324 frozen9d157bb2; shared final-slot completion with dynamic supplied-argument parsing kept out of line; fixed workers/adapter0.4'
identity['purpose'] += '; bounded changed-source confirmation after local JIT proves restored common-binder inlining, without a forced-inline attribute'
identity['coreSHA256'] = {label: source['coreSHA256']['candidate' if label.startswith('candidate') else 'reference'] for label in ['reference', 'candidate', 'reference-control', 'candidate-control']}
(out / 'identity.json').write_text(json.dumps(identity, indent=2) + '\n', encoding='utf-8', newline='\n')
oldroot = '/home/lokad/lython-bench-checks/final-slot-binding-b693-20261113'
root = oldroot.replace('b693', 'b694'); unit = 'lython-b694-final-slot-binding-20261113'
for name in ['collect.py', 'archive-owned.py', 'run.sh', 'retrieve.py', 'summarize.py']:
    s = (prior / name).read_text(encoding='utf-8').replace(oldroot, root).replace('lython-b693-final-slot-binding-20261113', unit).replace('B693', 'B694')
    if name.endswith('.py'): ast.parse(s)
    (out / name).write_text(s, encoding='utf-8', newline='\n')
with tarfile.open(out / 'payload.tgz', 'w:gz') as t:
    for name in ['identity.json', 'collect.py', 'archive-owned.py', 'run.sh']: t.add(out / name, arcname=name)
    t.add(r.parent / 'word-buffer-loan-r324/b690/representative.json', arcname='representative.json')
    t.add(r / 'refined/candidate-core.dll', arcname='candidate-core.dll')
    t.add(r / 'refined/candidate-identity.json', arcname='source-identity.json')
with tarfile.open(out / 'payload.tgz') as t: unpacked = sum(m.size for m in t.getmembers())
config = dict(root=root, sourceRoot='/home/lokad/lython-bench-checks/word-buffer-loan-b690-20261113', unit=unit, identity=identity, retire=json.loads((r / 'refined-retirement-inspection.json').read_text(encoding='utf-8')), payloadBytes=(out / 'payload.tgz').stat().st_size, payloadSHA256=hashlib.sha256((out / 'payload.tgz').read_bytes()).hexdigest(), unpackedBytes=unpacked)
(out / 'config.json').write_text(json.dumps(config, indent=2) + '\n', encoding='utf-8', newline='\n')
s = (prior / 'launch.py').read_text(encoding='utf-8').replace("r.parent/'candidate-identity.json'", "r.parent/'refined/candidate-identity.json'")
s = s.replace(" with tarfile.open(p)as t:data=t.extractfile(old['member']).read()", " if old['member']is None:data=p.read_bytes()\n else:\n  with tarfile.open(p)as t:data=t.extractfile(old['member']).read()")
s = s.replace("all('word-buffer-loan-b690' in name or 'word-buffer-loan-b691' in name for name in aliases)", "all('final-slot-binding-b693' in name for name in aliases)")
s = s.replace('lython-b693-fixtures', 'lython-b694-fixtures')
ast.parse(s)
(out / 'launch.py').write_text(s, encoding='utf-8', newline='\n')
print('Prepared changed-source confirmation: same scripts/workers/12s warmups/1s batches/180s owner; archived first prototype remains in Git.', flush=True)
