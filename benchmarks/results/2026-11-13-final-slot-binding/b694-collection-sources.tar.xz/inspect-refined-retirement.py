from pathlib import Path
import ast, hashlib, json, subprocess, tarfile
r = Path(__file__).parent
specs = [('benchmarks/results/2026-11-13-final-slot-binding/first-source-checks.tar.xz', 'candidate-core.dll', 'final-slot-binding-b693-20261113/candidate-core.dll'), ('benchmarks/results/2026-11-13-final-slot-binding/b693-observations.tgz', None, 'final-slot-binding-b693-20261113/observations.tgz')]
template = (r.parent / 'checkpoint-cpython-r318/inspect-command.py').read_text(encoding='utf-8')
ssh = ['C:/Windows/System32/OpenSSH/ssh.exe', '-i', 'C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem', '-o', 'BatchMode=yes', '-o', 'ConnectTimeout=15', 'lokad@20.166.121.73']
rows = []
for canonical, member, relative in specs:
    p = Path(canonical)
    assert subprocess.check_output(['git', 'show', 'HEAD:' + canonical]) == p.read_bytes()
    if member:
        with tarfile.open(p) as t: data = t.extractfile(member).read()
    else: data = p.read_bytes()
    proof = dict(path=relative, canonical=canonical, member=member, sha256=hashlib.sha256(data).hexdigest(), bytes=len(data))
    s = template; a = s.index('proof='); b = s.index('\nwith(', a)
    s = s[:a] + 'proof=' + repr(proof) + s[b:]
    s = s.replace("all('builtin-setup'not in x for x in aliases)", "all('final-slot-binding-b693' in x for x in aliases)")
    ast.parse(s)
    done = subprocess.run(ssh + ['python3 -'], input=s, text=True, encoding='utf-8', capture_output=True)
    assert done.returncode == 0, done.stderr
    d = json.loads(done.stdout)['retire']; rows.append(d)
    print('Read-only byte proof:', d['allocatedBytes'], 'bytes;', d['links'], 'old prototype aliases;9d preserved.', flush=True)
(r / 'refined-retirement-inspection.json').write_text(json.dumps(rows, indent=2) + '\n', encoding='utf-8', newline='\n')
