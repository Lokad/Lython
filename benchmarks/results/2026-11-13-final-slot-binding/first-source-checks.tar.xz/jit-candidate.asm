; Assembly listing for method Lokad.Lython.Runtime.PyExecutableFunction:StartNativeCall(Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[System.Object],System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,bool,bool,System.Span`1[System.Object],byref,byref,byref):this (Instrumented Tier0)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; Instrumented Tier0 code
; rbp based frame
; partially interruptible
; compiling with minopt

G_M000_IG01:
       push     rbp
       sub      rsp, 656
       lea      rbp, [rsp+0x290]
       xor      eax, eax
       mov      qword ptr [rbp-0x238], rax
       vxorps   xmm4, xmm4, xmm4
       vmovdqa  xmmword ptr [rbp-0x230], xmm4
       mov      rax, -480
 
G_M000_IG27:
       vmovdqa  xmmword ptr [rbp+rax-0x40], xmm4
       vmovdqa  xmmword ptr [rbp+rax-0x30], xmm4
       vmovdqa  xmmword ptr [rbp+rax-0x20], xmm4
       add      rax, 48
       jne      SHORT G_M000_IG27
       mov      qword ptr [rbp-0x40], rax
       mov      gword ptr [rbp+0x10], rcx
       mov      gword ptr [rbp+0x18], rdx
       mov      bword ptr [rbp+0x20], r8
       mov      gword ptr [rbp+0x28], r9
 
G_M000_IG02:
       mov      dword ptr [rbp-0x174], 0x3E8
       vxorps   ymm0, ymm0, ymm0
       vmovdqu  ymmword ptr [rbp-0xB8], ymm0
       vmovdqu  ymmword ptr [rbp-0x98], ymm0
       vmovdqu  ymmword ptr [rbp-0x78], ymm0
       vmovdqu  ymmword ptr [rbp-0x58], ymm0
       lea      r8, [rbp-0xB8]
       lea      rcx, [rbp-0xC8]
       mov      rdx, 0xD1FFAB1E
       mov      r9d, 16
       call     [<PrivateImplementationDetails>:InlineArrayAsSpan[Lokad.Lython.Runtime.PyExecutableFunction+NativeValues,System.__Canon](byref,int):System.Span`1[System.__Canon]]
       mov      rax, gword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax+0x68]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_ValueStorageCapacity():int:this]
       mov      dword ptr [rbp-0x178], eax
       mov      eax, dword ptr [rbp-0x178]
       mov      dword ptr [rsp+0x20], eax
       lea      rcx, [rbp-0xC8]
       lea      rdx, [rbp-0xC8]
       mov      r8, 0xD1FFAB1E
       xor      r9d, r9d
       call     [System.Span`1[System.__Canon]:Slice(int,int):System.Span`1[System.__Canon]:this]
       mov      rcx, gword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.PyFunctionBase:get_BindingPlan():Lokad.Lython.Runtime.FunctionBindingPlan:this]
       mov      rcx, rax
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_ParameterCount():int:this]
       mov      dword ptr [rbp-0x17C], eax
       mov      edx, dword ptr [rbp-0x17C]
       lea      rcx, [rbp-0xE0]
       call     [Lokad.Lython.Runtime.ArgumentPresence:.ctor(int):this]
       movzx    rax, byte  ptr [rbp+0x48]
       test     eax, eax
       je       G_M000_IG09
 
G_M000_IG03:
       vmovdqu  xmm0, xmmword ptr [rbp-0xC8]
       vmovdqu  xmmword ptr [rbp-0x190], xmm0
 
G_M000_IG04:
       lea      r8, [rbp-0x190]
       mov      rcx, bword ptr [rbp+0x20]
       mov      rdx, 0xD1FFAB1E
       call     [System.ReadOnlySpan`1[System.__Canon]:CopyTo(System.Span`1[System.__Canon]):this]
       xor      eax, eax
       mov      dword ptr [rbp-0xE4], eax
       jmp      SHORT G_M000_IG06
 
G_M000_IG05:
       mov      rcx, 0xD1FFAB1E
       call     CORINFO_HELP_COUNTPROFILE32
       lea      rcx, [rbp-0xE0]
       mov      edx, dword ptr [rbp-0xE4]
       mov      r8d, 1
       call     [Lokad.Lython.Runtime.ArgumentPresence:set_Item(int,bool):this]
       mov      eax, dword ptr [rbp-0xE4]
       inc      eax
       mov      dword ptr [rbp-0xE4], eax
 
G_M000_IG06:
       mov      eax, dword ptr [rbp-0x174]
       dec      eax
       mov      dword ptr [rbp-0x174], eax
       cmp      dword ptr [rbp-0x174], 0
       jg       SHORT G_M000_IG08
 
G_M000_IG07:
       lea      rcx, [rbp-0x174]
       mov      edx, 85
       call     CORINFO_HELP_PATCHPOINT
       jmp      rax
 
G_M000_IG08:
       lea      rcx, [rbp-0xE0]
       call     [Lokad.Lython.Runtime.ArgumentPresence:get_Length():int:this]
       cmp      eax, dword ptr [rbp-0xE4]
       jg       SHORT G_M000_IG05
       jmp      G_M000_IG16
 
G_M000_IG09:
       mov      rcx, 0xD1FFAB1E
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, gword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.PyFunctionBase:get_BindingPlan():Lokad.Lython.Runtime.FunctionBindingPlan:this]
       mov      rcx, rax
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_ParameterCount():int:this]
       mov      dword ptr [rbp-0x194], eax
       mov      eax, dword ptr [rbp-0x194]
       mov      dword ptr [rsp+0x20], eax
       lea      rcx, [rbp-0xC8]
       lea      rdx, [rbp-0x138]
       mov      r8, 0xD1FFAB1E
       xor      r9d, r9d
       call     [System.Span`1[System.__Canon]:Slice(int,int):System.Span`1[System.__Canon]:this]
       vxorps   xmm0, xmm0, xmm0
       vmovdqu  xmmword ptr [rbp-0xF8], xmm0
 
G_M000_IG10:
       vmovdqu  xmm0, xmmword ptr [rbp-0xF8]
       vmovdqu  xmmword ptr [rbp-0x148], xmm0
 
G_M000_IG11:
       vmovdqu  xmm0, xmmword ptr [rbp-0x138]
       vmovdqu  xmmword ptr [rbp-0x1A8], xmm0
 
G_M000_IG12:
       vmovdqu  xmm0, xmmword ptr [rbp-0x148]
       vmovdqu  xmmword ptr [rbp-0x1B8], xmm0
 
G_M000_IG13:
       mov      rcx, gword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.PyFunctionBase:get_BindingPlan():Lokad.Lython.Runtime.FunctionBindingPlan:this]
       mov      gword ptr [rbp-0x1D0], rax
       mov      rax, gword ptr [rbp+0x30]
       mov      gword ptr [rsp+0x28], rax
       xor      eax, eax
       mov      dword ptr [rsp+0x30], eax
       mov      rax, gword ptr [rbp+0x28]
       mov      gword ptr [rsp+0x38], rax
       mov      rax, gword ptr [rbp+0x18]
       mov      gword ptr [rsp+0x40], rax
       mov      rax, bword ptr [rbp+0x20]
 
G_M000_IG14:
       vmovdqu  xmm0, xmmword ptr [rax]
       vmovdqu  xmmword ptr [rbp-0x1C8], xmm0
 
G_M000_IG15:
       mov      rax, gword ptr [rbp-0x1D0]
       mov      gword ptr [rsp+0x20], rax
       lea      r8, [rbp-0x1B8]
       lea      rcx, [rbp-0x1A8]
       lea      rax, [rbp-0x1C8]
       mov      qword ptr [rsp+0x48], rax
       lea      rdx, [rbp-0xE0]
       mov      r9, gword ptr [rbp+0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime:BindFunctionArgumentsInto(System.Span`1[System.Object],byref,System.ReadOnlySpan`1[Lokad.Lython.Runtime.CallArgumentValue],Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.FunctionBindingPlan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,bool,System.Object,Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[System.Object])]
 
G_M000_IG16:
       mov      rcx, 0xD1FFAB1E
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG17:
       vmovdqu  xmm0, xmmword ptr [rbp-0xC8]
       vmovdqu  xmmword ptr [rbp-0x158], xmm0
 
G_M000_IG18:
       vmovdqu  xmm0, xmmword ptr [rbp-0xE0]
       vmovdqu  xmmword ptr [rbp-0x170], xmm0
       mov      rax, qword ptr [rbp-0xD0]
       mov      qword ptr [rbp-0x160], rax
 
G_M000_IG19:
       vxorps   ymm0, ymm0, ymm0
       vmovdqu  ymmword ptr [rbp-0x128], ymm0
       vmovdqu  xmmword ptr [rbp-0x108], xmm0
 
G_M000_IG20:
       vmovdqu  xmm0, xmmword ptr [rbp-0x158]
       vmovdqu  xmmword ptr [rbp-0x1E0], xmm0
 
G_M000_IG21:
       vmovdqu  xmm0, xmmword ptr [rbp-0x170]
       vmovdqu  xmmword ptr [rbp-0x1F8], xmm0
       mov      rax, qword ptr [rbp-0x160]
       mov      qword ptr [rbp-0x1E8], rax
 
G_M000_IG22:
       vmovdqu  ymm0, ymmword ptr [rbp-0x128]
       vmovdqu  ymmword ptr [rbp-0x228], ymm0
       vmovdqu  xmm0, xmmword ptr [rbp-0x108]
       vmovdqu  xmmword ptr [rbp-0x208], xmm0
 
G_M000_IG23:
       mov      rax, gword ptr [rbp+0x38]
       mov      gword ptr [rsp+0x20], rax
       movzx    rax, byte  ptr [rbp+0x40]
       mov      dword ptr [rsp+0x28], eax
       mov      rax, bword ptr [rbp+0x50]
 
G_M000_IG24:
       vmovdqu  xmm0, xmmword ptr [rax]
       vmovdqu  xmmword ptr [rbp-0x238], xmm0
 
G_M000_IG25:
       mov      rax, bword ptr [rbp+0x58]
       mov      bword ptr [rsp+0x38], rax
       mov      rax, bword ptr [rbp+0x60]
       mov      bword ptr [rsp+0x40], rax
       mov      rax, bword ptr [rbp+0x68]
       mov      bword ptr [rsp+0x48], rax
       lea      rdx, [rbp-0x1E0]
       lea      r8, [rbp-0x1F8]
       lea      r9, [rbp-0x228]
       lea      rax, [rbp-0x238]
       mov      qword ptr [rsp+0x30], rax
       mov      rcx, gword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.PyExecutableFunction:StartInline(System.Span`1[System.Object],Lokad.Lython.Runtime.ArgumentPresence,System.Nullable`1[Lokad.Lython.Runtime.BoundCallArguments],Lokad.Lython.LythonSourceSpan,bool,System.Span`1[System.Object],byref,byref,byref):this]
       nop      
 
G_M000_IG26:
       vzeroupper 
       add      rsp, 656
       pop      rbp
       ret      
 
; Total bytes of code 1006

; Assembly listing for method Lokad.Lython.Runtime.LythonRuntime:BindFunctionArgumentsInto(System.Span`1[System.Object],byref,System.ReadOnlySpan`1[Lokad.Lython.Runtime.CallArgumentValue],Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.FunctionBindingPlan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,bool,System.Object,Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[System.Object]) (Instrumented Tier0)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; Instrumented Tier0 code
; rbp based frame
; fully interruptible
; compiling with minopt

G_M000_IG01:
       push     rbp
       sub      rsp, 768
       lea      rbp, [rsp+0x300]
       xor      eax, eax
       mov      qword ptr [rbp-0x2D8], rax
       vxorps   xmm4, xmm4, xmm4
       vmovdqa  xmmword ptr [rbp-0x2D0], xmm4
       vmovdqa  xmmword ptr [rbp-0x2C0], xmm4
       mov      rax, -624
 
G_M000_IG87:
       vmovdqa  xmmword ptr [rbp+rax-0x40], xmm4
       vmovdqa  xmmword ptr [rbp+rax-0x30], xmm4
       vmovdqa  xmmword ptr [rbp+rax-0x20], xmm4
       add      rax, 48
       jne      SHORT G_M000_IG87
       mov      qword ptr [rbp-0x40], rax
       mov      bword ptr [rbp+0x10], rcx
       mov      bword ptr [rbp+0x18], rdx
       mov      bword ptr [rbp+0x20], r8
       mov      gword ptr [rbp+0x28], r9
 
G_M000_IG02:
       mov      dword ptr [rbp-0x22C], 0x3E8
       xor      rax, rax
       mov      gword ptr [rbp-0x40], rax
       xor      rax, rax
       mov      gword ptr [rbp-0x48], rax
       xor      eax, eax
       mov      dword ptr [rbp-0x4C], eax
       mov      rcx, gword ptr [rbp+0x30]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_VariadicListIndex():int:this]
       test     eax, eax
       jge      SHORT G_M000_IG04
       cmp      gword ptr [rbp+0x50], 0
       jne      SHORT G_M000_IG03
       mov      rcx, bword ptr [rbp+0x20]
       call     [System.ReadOnlySpan`1[Lokad.Lython.Runtime.CallArgumentValue]:get_IsEmpty():bool:this]
       mov      dword ptr [rbp-0x12C], eax
       jmp      SHORT G_M000_IG05
 
G_M000_IG03:
       mov      rcx, 0xD1FFAB1E
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, gword ptr [rbp+0x50]
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_IsPositionalOnly():bool:this]
       mov      dword ptr [rbp-0x12C], eax
       jmp      SHORT G_M000_IG05
 
G_M000_IG04:
       mov      rcx, 0xD1FFAB1E
       call     CORINFO_HELP_COUNTPROFILE32
       xor      eax, eax
       mov      dword ptr [rbp-0x12C], eax
 
G_M000_IG05:
       movzx    rax, byte  ptr [rbp-0x12C]
       mov      dword ptr [rbp-0x50], eax
       cmp      dword ptr [rbp-0x50], 0
       je       G_M000_IG13
       cmp      gword ptr [rbp+0x48], 0
       setne    al
       movzx    rax, al
       mov      dword ptr [rbp-0x58], eax
       mov      rax, bword ptr [rbp+0x58]
       mov      eax, dword ptr [rax+0x08]
       mov      dword ptr [rbp-0x20C], eax
       mov      rcx, gword ptr [rbp+0x30]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_PositionalCount():int:this]
       sub      eax, dword ptr [rbp-0x58]
       cmp      eax, dword ptr [rbp-0x20C]
       jge      SHORT G_M000_IG07
 
G_M000_IG06:
       mov      rcx, gword ptr [rbp+0x30]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_CallableKind():int:this]
       mov      dword ptr [rbp-0x220], eax
       mov      rcx, gword ptr [rbp+0x30]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_CallableName():System.String:this]
       mov      gword ptr [rbp-0x238], rax
       mov      rdx, gword ptr [rbp-0x238]
       mov      ecx, dword ptr [rbp-0x220]
       mov      r8, gword ptr [rbp+0x28]
       call     [Lokad.Lython.Runtime.CallErrors:TooManyPositional(int,System.String,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.LythonRuntimeException]
       mov      rcx, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG07:
       cmp      gword ptr [rbp+0x48], 0
       je       SHORT G_M000_IG08
       mov      rcx, 0xD1FFAB1E
       call     CORINFO_HELP_COUNTPROFILE32
       mov      eax, dword ptr [rbp-0x4C]
       mov      dword ptr [rbp-0x21C], eax
       mov      eax, dword ptr [rbp-0x4C]
       inc      eax
       mov      dword ptr [rbp-0x4C], eax
       mov      rax, bword ptr [rbp+0x10]
       mov      eax, dword ptr [rax+0x08]
       cmp      dword ptr [rbp-0x21C], eax
       jae      G_M000_IG83
       mov      rax, bword ptr [rbp+0x10]
       mov      rax, bword ptr [rax]
       mov      ecx, dword ptr [rbp-0x21C]
       lea      rcx, bword ptr [rax+8*rcx]
       mov      rdx, gword ptr [rbp+0x48]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
 
G_M000_IG08:
       xor      eax, eax
       mov      dword ptr [rbp-0x5C], eax
       jmp      G_M000_IG10
 
G_M000_IG09:
       mov      rcx, 0xD1FFAB1E
       call     CORINFO_HELP_COUNTPROFILE32
       mov      eax, dword ptr [rbp-0x4C]
       mov      dword ptr [rbp-0x210], eax
       mov      eax, dword ptr [rbp-0x4C]
       inc      eax
       mov      dword ptr [rbp-0x4C], eax
       mov      rax, bword ptr [rbp+0x10]
       mov      eax, dword ptr [rax+0x08]
       cmp      dword ptr [rbp-0x210], eax
       jae      G_M000_IG83
       mov      rax, bword ptr [rbp+0x10]
       mov      rax, bword ptr [rax]
       mov      ecx, dword ptr [rbp-0x210]
       lea      rax, bword ptr [rax+8*rcx]
       mov      bword ptr [rbp-0x218], rax
       mov      rax, bword ptr [rbp+0x58]
       mov      eax, dword ptr [rax+0x08]
       cmp      dword ptr [rbp-0x5C], eax
       jae      G_M000_IG83
       mov      rax, bword ptr [rbp+0x58]
       mov      rax, bword ptr [rax]
       mov      ecx, dword ptr [rbp-0x5C]
       mov      rdx, gword ptr [rax+8*rcx]
       mov      rcx, 0xD1FFAB1E
       call     [Lokad.Lython.Internal.NullabilityExtensions:RequireNotNull[System.__Canon](System.__Canon):System.__Canon]
       mov      rdx, rax
       mov      rcx, bword ptr [rbp-0x218]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      eax, dword ptr [rbp-0x5C]
       inc      eax
       mov      dword ptr [rbp-0x5C], eax
 
G_M000_IG10:
       mov      eax, dword ptr [rbp-0x22C]
       dec      eax
       mov      dword ptr [rbp-0x22C], eax
       cmp      dword ptr [rbp-0x22C], 0
       jg       SHORT G_M000_IG12
 
G_M000_IG11:
       lea      rcx, [rbp-0x22C]
       mov      edx, 148
       call     CORINFO_HELP_PATCHPOINT
       jmp      rax
 
G_M000_IG12:
       mov      rax, bword ptr [rbp+0x58]
       mov      eax, dword ptr [rax+0x08]
       cmp      eax, dword ptr [rbp-0x5C]
       jg       G_M000_IG09
       mov      rcx, 0xD1FFAB1E
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp+0x18]
       mov      r8d, dword ptr [rbp-0x4C]
       xor      edx, edx
       call     [Lokad.Lython.Runtime.ArgumentPresence:MarkRange(int,int):this]
 
G_M000_IG13:
       cmp      gword ptr [rbp+0x50], 0
       jne      SHORT G_M000_IG15
       mov      rcx, bword ptr [rbp+0x20]
       call     [System.ReadOnlySpan`1[Lokad.Lython.Runtime.CallArgumentValue]:get_IsEmpty():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG14
       mov      rax, bword ptr [rbp+0x20]
       mov      eax, dword ptr [rax+0x08]
       mov      dword ptr [rbp-0x130], eax
       jmp      SHORT G_M000_IG16
 
G_M000_IG14:
       mov      rcx, 0xD1FFAB1E
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x58]
       mov      eax, dword ptr [rax+0x08]
       mov      dword ptr [rbp-0x130], eax
       jmp      SHORT G_M000_IG16
 
G_M000_IG15:
       mov      rcx, 0xD1FFAB1E
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, gword ptr [rbp+0x50]
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_ArgumentCount():int:this]
       mov      dword ptr [rbp-0x130], eax
 
G_M000_IG16:
       mov      eax, dword ptr [rbp-0x130]
       mov      dword ptr [rbp-0x54], eax
       cmp      gword ptr [rbp+0x48], 0
       je       SHORT G_M000_IG17
       mov      dword ptr [rbp-0x134], -1
       jmp      SHORT G_M000_IG18
 
G_M000_IG17:
       mov      rcx, 0xD1FFAB1E
       call     CORINFO_HELP_COUNTPROFILE32
       xor      eax, eax
       mov      dword ptr [rbp-0x134], eax
 
G_M000_IG18:
       mov      eax, dword ptr [rbp-0x134]
       mov      dword ptr [rbp-0x60], eax
       jmp      G_M000_IG47
 
G_M000_IG19:
       cmp      dword ptr [rbp-0x60], 0
       jl       G_M000_IG27
       cmp      gword ptr [rbp+0x50], 0
       je       G_M000_IG23
       mov      rcx, gword ptr [rbp+0x50]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_Arguments():Lokad.Lython.Frontend.CallArgumentForm[]:this]
       mov      ecx, dword ptr [rbp-0x60]
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG83
       mov      edx, ecx
       imul     rdx, rdx, 16
       lea      rax, bword ptr [rax+rdx+0x10]
 
G_M000_IG20:
       vmovdqu  xmm0, xmmword ptr [rax]
       vmovdqu  xmmword ptr [rbp-0x208], xmm0
 
G_M000_IG21:
       vmovdqu  xmm0, xmmword ptr [rbp-0x208]
       vmovdqu  xmmword ptr [rbp-0x248], xmm0
 
G_M000_IG22:
       mov      rax, bword ptr [rbp+0x58]
       mov      eax, dword ptr [rax+0x08]
       cmp      dword ptr [rbp-0x60], eax
       jae      G_M000_IG83
       mov      rax, bword ptr [rbp+0x58]
       mov      rax, bword ptr [rax]
       mov      ecx, dword ptr [rbp-0x60]
       mov      rdx, gword ptr [rax+8*rcx]
       mov      rcx, 0xD1FFAB1E
       call     [Lokad.Lython.Internal.NullabilityExtensions:RequireNotNull[System.__Canon](System.__Canon):System.__Canon]
       mov      gword ptr [rbp-0x250], rax
       mov      r8, gword ptr [rbp-0x250]
       lea      rdx, [rbp-0x248]
       lea      rcx, [rbp-0x1A8]
       call     [Lokad.Lython.Runtime.LythonRuntime:CreateExecutableCallArgument(Lokad.Lython.Frontend.CallArgumentForm,System.Object):Lokad.Lython.Runtime.CallArgumentValue]
       jmp      G_M000_IG28
 
G_M000_IG23:
       mov      rcx, bword ptr [rbp+0x20]
       call     [System.ReadOnlySpan`1[Lokad.Lython.Runtime.CallArgumentValue]:get_IsEmpty():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG26
       mov      rcx, 0xD1FFAB1E
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x20]
       mov      eax, dword ptr [rax+0x08]
       cmp      dword ptr [rbp-0x60], eax
       jae      G_M000_IG83
       mov      rax, bword ptr [rbp+0x20]
       mov      rax, bword ptr [rax]
       mov      ecx, dword ptr [rbp-0x60]
       lea      rcx, [rcx+2*rcx]
 
G_M000_IG24:
       vmovdqu  xmm0, xmmword ptr [rax+8*rcx]
       vmovdqu  xmmword ptr [rbp-0x1A8], xmm0
       mov      rdx, qword ptr [rax+8*rcx+0x10]
       mov      qword ptr [rbp-0x198], rdx
 
G_M000_IG25:
       jmp      SHORT G_M000_IG28
 
G_M000_IG26:
       mov      rcx, 0xD1FFAB1E
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x58]
       mov      eax, dword ptr [rax+0x08]
       cmp      dword ptr [rbp-0x60], eax
       jae      G_M000_IG83
       mov      rax, bword ptr [rbp+0x58]
       mov      rax, bword ptr [rax]
       mov      ecx, dword ptr [rbp-0x60]
       mov      rdx, gword ptr [rax+8*rcx]
       mov      rcx, 0xD1FFAB1E
       call     [Lokad.Lython.Internal.NullabilityExtensions:RequireNotNull[System.__Canon](System.__Canon):System.__Canon]
       mov      gword ptr [rbp-0x258], rax
       mov      rdx, gword ptr [rbp-0x258]
       lea      rcx, [rbp-0x1A8]
       call     [Lokad.Lython.Runtime.CallArgumentValue:Positional(System.Object):Lokad.Lython.Runtime.CallArgumentValue]
       jmp      SHORT G_M000_IG28
 
G_M000_IG27:
       mov      rcx, 0xD1FFAB1E
       call     CORINFO_HELP_COUNTPROFILE32
       lea      rcx, [rbp-0x1A8]
       mov      rdx, gword ptr [rbp+0x48]
       call     [Lokad.Lython.Runtime.CallArgumentValue:Positional(System.Object):Lokad.Lython.Runtime.CallArgumentValue]
 
G_M000_IG28:
       vmovdqu  xmm0, xmmword ptr [rbp-0x1A8]
       vmovdqu  xmmword ptr [rbp-0x78], xmm0
       mov      rax, qword ptr [rbp-0x198]
       mov      qword ptr [rbp-0x68], rax
 
G_M000_IG29:
       lea      rcx, [rbp-0x78]
       call     [Lokad.Lython.Runtime.CallArgumentValue:get_IsPositional():bool:this]
       test     eax, eax
       je       G_M000_IG34
       mov      rcx, gword ptr [rbp+0x30]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_PositionalCount():int:this]
       cmp      eax, dword ptr [rbp-0x4C]
       jg       G_M000_IG33
       mov      rcx, gword ptr [rbp+0x30]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_VariadicListIndex():int:this]
       test     eax, eax
       jge      SHORT G_M000_IG31
 
G_M000_IG30:
       mov      rcx, gword ptr [rbp+0x30]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_CallableKind():int:this]
       mov      dword ptr [rbp-0x1F4], eax
       mov      rcx, gword ptr [rbp+0x30]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_CallableName():System.String:this]
       mov      gword ptr [rbp-0x260], rax
       mov      rdx, gword ptr [rbp-0x260]
       mov      ecx, dword ptr [rbp-0x1F4]
       mov      r8, gword ptr [rbp+0x28]
       call     [Lokad.Lython.Runtime.CallErrors:TooManyPositional(int,System.String,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.LythonRuntimeException]
       mov      rcx, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG31:
       cmp      gword ptr [rbp-0x40], 0
       jne      SHORT G_M000_IG32
       mov      rcx, 0xD1FFAB1E
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, 0xD1FFAB1E
       call     [System.Array:Empty[System.__Canon]():System.__Canon[]]
       mov      gword ptr [rbp-0x1E8], rax
       mov      rcx, 0xD1FFAB1E
       call     CORINFO_HELP_NEWSFAST
       mov      gword ptr [rbp-0x1F0], rax
       mov      rcx, gword ptr [rbp+0x38]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:get_MemoryGovernor():Lokad.Lython.Runtime.MemoryGovernor:this]
       mov      gword ptr [rbp-0x268], rax
       mov      r8, gword ptr [rbp-0x268]
       mov      rdx, gword ptr [rbp-0x1E8]
       mov      rcx, gword ptr [rbp-0x1F0]
       mov      r9, gword ptr [rbp+0x28]
       call     [Lokad.Lython.Runtime.PyList:.ctor(System.Collections.Generic.IEnumerable`1[System.Object],Lokad.Lython.Runtime.MemoryGovernor,Lokad.Lython.LythonSourceSpan):this]
       mov      rax, gword ptr [rbp-0x1F0]
       mov      gword ptr [rbp-0x40], rax
 
G_M000_IG32:
       lea      rcx, [rbp-0x78]
       call     [Lokad.Lython.Runtime.CallArgumentValue:get_Value():System.Object:this]
       mov      gword ptr [rbp-0x270], rax
       mov      rdx, gword ptr [rbp-0x270]
       mov      rcx, gword ptr [rbp-0x40]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.PyList:Add(System.Object):this]
       jmp      G_M000_IG46
 
G_M000_IG33:
       mov      rcx, 0xD1FFAB1E
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x10]
       mov      eax, dword ptr [rax+0x08]
       cmp      dword ptr [rbp-0x4C], eax
       jae      G_M000_IG83
       mov      rax, bword ptr [rbp+0x10]
       mov      rax, bword ptr [rax]
       mov      ecx, dword ptr [rbp-0x4C]
       lea      rax, bword ptr [rax+8*rcx]
       mov      bword ptr [rbp-0x1E0], rax
       lea      rcx, [rbp-0x78]
       call     [Lokad.Lython.Runtime.CallArgumentValue:get_Value():System.Object:this]
       mov      rdx, rax
       mov      rcx, bword ptr [rbp-0x1E0]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rcx, bword ptr [rbp+0x18]
       mov      edx, dword ptr [rbp-0x4C]
       mov      r8d, 1
       call     [Lokad.Lython.Runtime.ArgumentPresence:set_Item(int,bool):this]
       mov      eax, dword ptr [rbp-0x4C]
       inc      eax
       mov      dword ptr [rbp-0x4C], eax
       jmp      G_M000_IG46
 
G_M000_IG34:
       lea      rcx, [rbp-0x78]
       call     [Lokad.Lython.Runtime.CallArgumentValue:get_KeywordName():System.String:this]
       mov      gword ptr [rbp-0x80], rax
       mov      rcx, gword ptr [rbp+0x30]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_LayoutParameterIndex():System.Collections.Generic.IReadOnlyDictionary`2[System.String,int]:this]
       mov      gword ptr [rbp-0x228], rax
       mov      rcx, gword ptr [rbp-0x228]
       mov      rdx, 0xD1FFAB1E
       call     CORINFO_HELP_CLASSPROFILE32
       mov      rax, gword ptr [rbp-0x228]
       mov      gword ptr [rbp-0x278], rax
       mov      rcx, gword ptr [rbp-0x278]
       lea      r8, [rbp-0x88]
       mov      rdx, gword ptr [rbp-0x80]
       mov      r11, 0xD1FFAB1E
       call     [r11]System.Collections.Generic.IReadOnlyDictionary`2[System.__Canon,int]:TryGetValue(System.__Canon,byref):bool:this
       test     eax, eax
       je       SHORT G_M000_IG36
       mov      eax, dword ptr [rbp-0x88]
       mov      dword ptr [rbp-0x1C0], eax
       mov      rcx, gword ptr [rbp+0x30]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_NamedLayoutCount():int:this]
       cmp      eax, dword ptr [rbp-0x1C0]
       jle      G_M000_IG38
       mov      eax, dword ptr [rbp-0x88]
       mov      dword ptr [rbp-0x1C4], eax
       mov      rcx, gword ptr [rbp+0x30]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_PositionalOnlyCount():int:this]
       cmp      eax, dword ptr [rbp-0x1C4]
       jle      G_M000_IG43
 
G_M000_IG35:
       mov      rcx, 0xD1FFAB1E
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG36:
       mov      rcx, gword ptr [rbp+0x30]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_VariadicDictionaryIndex():int:this]
       test     eax, eax
       jge      SHORT G_M000_IG39
 
G_M000_IG37:
       mov      rcx, gword ptr [rbp+0x30]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_CallableKind():int:this]
       mov      dword ptr [rbp-0x1BC], eax
       mov      rcx, gword ptr [rbp+0x30]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_CallableName():System.String:this]
       mov      gword ptr [rbp-0x280], rax
       mov      rdx, gword ptr [rbp-0x280]
       mov      ecx, dword ptr [rbp-0x1BC]
       mov      r8, gword ptr [rbp-0x80]
       mov      r9, gword ptr [rbp+0x28]
       call     [Lokad.Lython.Runtime.CallErrors:UnexpectedKeyword(int,System.String,System.String,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.LythonRuntimeException]
       mov      rcx, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG38:
       mov      rcx, 0xD1FFAB1E
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG36
 
G_M000_IG39:
       cmp      gword ptr [rbp-0x48], 0
       jne      SHORT G_M000_IG40
       mov      rcx, 0xD1FFAB1E
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, 0xD1FFAB1E
       call     CORINFO_HELP_NEWSFAST
       mov      gword ptr [rbp-0x1B8], rax
       call     [System.StringComparer:get_Ordinal():System.StringComparer]
       mov      gword ptr [rbp-0x288], rax
       mov      rdx, gword ptr [rbp-0x288]
       mov      rcx, gword ptr [rbp-0x1B8]
       call     [System.Collections.Generic.Dictionary`2[System.__Canon,System.__Canon]:.ctor(System.Collections.Generic.IEqualityComparer`1[System.__Canon]):this]
       mov      rax, gword ptr [rbp-0x1B8]
       mov      gword ptr [rbp-0x48], rax
 
G_M000_IG40:
       lea      rcx, [rbp-0x78]
       call     [Lokad.Lython.Runtime.CallArgumentValue:get_Value():System.Object:this]
       mov      gword ptr [rbp-0x290], rax
       mov      r8, gword ptr [rbp-0x290]
       mov      rdx, gword ptr [rbp-0x80]
       mov      rcx, gword ptr [rbp-0x48]
       cmp      dword ptr [rcx], ecx
       call     [System.Collections.Generic.Dictionary`2[System.__Canon,System.__Canon]:TryAdd(System.__Canon,System.__Canon):bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG42
 
G_M000_IG41:
       mov      rcx, gword ptr [rbp+0x30]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_CallableKind():int:this]
       mov      dword ptr [rbp-0x1AC], eax
       mov      rcx, gword ptr [rbp+0x30]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_CallableName():System.String:this]
       mov      gword ptr [rbp-0x298], rax
       mov      rdx, gword ptr [rbp-0x298]
       mov      ecx, dword ptr [rbp-0x1AC]
       mov      r8, gword ptr [rbp-0x80]
       mov      r9, gword ptr [rbp+0x28]
       call     [Lokad.Lython.Runtime.CallErrors:MultipleValues(int,System.String,System.String,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.LythonRuntimeException]
       mov      rcx, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG42:
       mov      rcx, 0xD1FFAB1E
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG46
 
G_M000_IG43:
       mov      rcx, bword ptr [rbp+0x18]
       mov      edx, dword ptr [rbp-0x88]
       call     [Lokad.Lython.Runtime.ArgumentPresence:get_Item(int):bool:this]
       test     eax, eax
       je       SHORT G_M000_IG45
 
G_M000_IG44:
       mov      rcx, gword ptr [rbp+0x30]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_CallableKind():int:this]
       mov      dword ptr [rbp-0x1D4], eax
       mov      rcx, gword ptr [rbp+0x30]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_CallableName():System.String:this]
       mov      gword ptr [rbp-0x2A0], rax
       mov      rdx, gword ptr [rbp-0x2A0]
       mov      ecx, dword ptr [rbp-0x1D4]
       mov      r8, gword ptr [rbp-0x80]
       mov      r9, gword ptr [rbp+0x28]
       call     [Lokad.Lython.Runtime.CallErrors:MultipleValues(int,System.String,System.String,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.LythonRuntimeException]
       mov      rcx, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG45:
       mov      rcx, 0xD1FFAB1E
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x10]
       mov      eax, dword ptr [rax+0x08]
       cmp      dword ptr [rbp-0x88], eax
       jae      G_M000_IG83
       mov      rax, bword ptr [rbp+0x10]
       mov      rax, bword ptr [rax]
       mov      ecx, dword ptr [rbp-0x88]
       lea      rax, bword ptr [rax+8*rcx]
       mov      bword ptr [rbp-0x1D0], rax
       lea      rcx, [rbp-0x78]
       call     [Lokad.Lython.Runtime.CallArgumentValue:get_Value():System.Object:this]
       mov      rdx, rax
       mov      rcx, bword ptr [rbp-0x1D0]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rcx, bword ptr [rbp+0x18]
       mov      edx, dword ptr [rbp-0x88]
       mov      r8d, 1
       call     [Lokad.Lython.Runtime.ArgumentPresence:set_Item(int,bool):this]
 
G_M000_IG46:
       mov      rcx, 0xD1FFAB1E
       call     CORINFO_HELP_COUNTPROFILE32
       mov      eax, dword ptr [rbp-0x60]
       inc      eax
       mov      dword ptr [rbp-0x60], eax
 
G_M000_IG47:
       cmp      dword ptr [rbp-0x50], 0
       jne      SHORT G_M000_IG51
       mov      eax, dword ptr [rbp-0x22C]
       dec      eax
       mov      dword ptr [rbp-0x22C], eax
       cmp      dword ptr [rbp-0x22C], 0
       jg       SHORT G_M000_IG49
 
G_M000_IG48:
       lea      rcx, [rbp-0x22C]
       mov      edx, 650
       call     CORINFO_HELP_PATCHPOINT
       jmp      rax
 
G_M000_IG49:
       mov      eax, dword ptr [rbp-0x60]
       cmp      eax, dword ptr [rbp-0x54]
       jl       G_M000_IG19
 
G_M000_IG50:
       mov      rcx, 0xD1FFAB1E
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG51:
       xor      eax, eax
       mov      dword ptr [rbp-0x8C], eax
       jmp      G_M000_IG55
 
G_M000_IG52:
       mov      rcx, bword ptr [rbp+0x18]
       mov      edx, dword ptr [rbp-0x8C]
       call     [Lokad.Lython.Runtime.ArgumentPresence:get_Item(int):bool:this]
       test     eax, eax
       jne      G_M000_IG54
       mov      rcx, gword ptr [rbp+0x30]
       mov      edx, dword ptr [rbp-0x8C]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:NameAt(int):System.String:this]
       mov      gword ptr [rbp-0x98], rax
       lea      r8, [rbp-0xA0]
       mov      rcx, gword ptr [rbp+0x30]
       mov      edx, dword ptr [rbp-0x8C]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:TryGetPositionalDefault(int,byref):bool:this]
       test     eax, eax
       je       SHORT G_M000_IG53
       mov      rcx, 0xD1FFAB1E
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x10]
       mov      eax, dword ptr [rax+0x08]
       cmp      dword ptr [rbp-0x8C], eax
       jae      G_M000_IG83
       mov      rax, bword ptr [rbp+0x10]
       mov      rax, bword ptr [rax]
       mov      ecx, dword ptr [rbp-0x8C]
       lea      rcx, bword ptr [rax+8*rcx]
       mov      rdx, gword ptr [rbp-0xA0]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       jmp      SHORT G_M000_IG54
 
G_M000_IG53:
       mov      rcx, gword ptr [rbp+0x30]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_CallableKind():int:this]
       mov      dword ptr [rbp-0x138], eax
       mov      rcx, gword ptr [rbp+0x30]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_CallableName():System.String:this]
       mov      gword ptr [rbp-0x2A8], rax
       mov      rdx, gword ptr [rbp-0x2A8]
       mov      ecx, dword ptr [rbp-0x138]
       mov      r8, gword ptr [rbp-0x98]
       mov      r9, gword ptr [rbp+0x28]
       call     [Lokad.Lython.Runtime.CallErrors:MissingArgument(int,System.String,System.String,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.LythonRuntimeException]
       mov      rcx, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG54:
       mov      rcx, 0xD1FFAB1E
       call     CORINFO_HELP_COUNTPROFILE32
       mov      eax, dword ptr [rbp-0x8C]
       inc      eax
       mov      dword ptr [rbp-0x8C], eax
 
G_M000_IG55:
       mov      eax, dword ptr [rbp-0x22C]
       dec      eax
       mov      dword ptr [rbp-0x22C], eax
       cmp      dword ptr [rbp-0x22C], 0
       jg       SHORT G_M000_IG57
 
G_M000_IG56:
       lea      rcx, [rbp-0x22C]
       mov      edx, 741
       call     CORINFO_HELP_PATCHPOINT
       jmp      rax
 
G_M000_IG57:
       mov      rcx, gword ptr [rbp+0x30]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_PositionalCount():int:this]
       cmp      eax, dword ptr [rbp-0x8C]
       jg       G_M000_IG52
       xor      eax, eax
       mov      dword ptr [rbp-0xA4], eax
       jmp      G_M000_IG63
 
G_M000_IG58:
       mov      rcx, gword ptr [rbp+0x30]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_PositionalCount():int:this]
       add      eax, dword ptr [rbp-0xA4]
       mov      dword ptr [rbp-0xA8], eax
       mov      rcx, bword ptr [rbp+0x18]
       mov      edx, dword ptr [rbp-0xA8]
       call     [Lokad.Lython.Runtime.ArgumentPresence:get_Item(int):bool:this]
       test     eax, eax
       jne      G_M000_IG62
       mov      rcx, gword ptr [rbp+0x30]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_PositionalCount():int:this]
       add      eax, dword ptr [rbp-0xA4]
       mov      dword ptr [rbp-0x2AC], eax
       mov      edx, dword ptr [rbp-0x2AC]
       mov      rcx, gword ptr [rbp+0x30]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:NameAt(int):System.String:this]
       mov      gword ptr [rbp-0xB0], rax
       mov      rcx, gword ptr [rbp+0x30]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_KeywordDefaultStorage():Lokad.Lython.Runtime.PyDict:this]
       mov      gword ptr [rbp-0xB8], rax
       cmp      gword ptr [rbp-0xB8], 0
       je       G_M000_IG61
       mov      rcx, gword ptr [rbp+0x30]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_KeywordDefaultNames():Lokad.Lython.Runtime.Text.PyString[]:this]
       mov      ecx, dword ptr [rbp-0xA4]
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG83
       mov      edx, ecx
       lea      rax, bword ptr [rax+8*rdx+0x10]
       mov      rax, gword ptr [rax]
       mov      gword ptr [rbp-0x2B8], rax
       mov      rax, gword ptr [rbp+0x28]
       mov      gword ptr [rsp+0x20], rax
       mov      rdx, gword ptr [rbp-0x2B8]
       lea      r8, [rbp-0xC0]
       mov      rcx, gword ptr [rbp-0xB8]
       mov      r9, gword ptr [rbp+0x38]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.PyDict:TryGetValue(System.Object,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):bool:this]
       test     eax, eax
       je       SHORT G_M000_IG60
       mov      rcx, 0xD1FFAB1E
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x10]
       mov      eax, dword ptr [rax+0x08]
       cmp      dword ptr [rbp-0xA8], eax
       jae      G_M000_IG83
       mov      rax, bword ptr [rbp+0x10]
 
G_M000_IG59:
       mov      rax, bword ptr [rax]
       mov      ecx, dword ptr [rbp-0xA8]
       lea      rcx, bword ptr [rax+8*rcx]
       mov      rdx, gword ptr [rbp-0xC0]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       jmp      SHORT G_M000_IG62
 
G_M000_IG60:
       mov      rcx, 0xD1FFAB1E
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG61:
       mov      rcx, gword ptr [rbp+0x30]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_CallableKind():int:this]
       mov      dword ptr [rbp-0x190], eax
       mov      rcx, gword ptr [rbp+0x30]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_CallableName():System.String:this]
       mov      gword ptr [rbp-0x2C0], rax
       mov      rdx, gword ptr [rbp-0x2C0]
       mov      ecx, dword ptr [rbp-0x190]
       mov      r8, gword ptr [rbp-0xB0]
       mov      r9, gword ptr [rbp+0x28]
       call     [Lokad.Lython.Runtime.CallErrors:MissingArgument(int,System.String,System.String,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.LythonRuntimeException]
       mov      rcx, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG62:
       mov      rcx, 0xD1FFAB1E
       call     CORINFO_HELP_COUNTPROFILE32
       mov      eax, dword ptr [rbp-0xA4]
       inc      eax
       mov      dword ptr [rbp-0xA4], eax
 
G_M000_IG63:
       movzx    rax, byte  ptr [rbp+0x40]
       test     eax, eax
       jne      SHORT G_M000_IG67
       mov      eax, dword ptr [rbp-0x22C]
       dec      eax
       mov      dword ptr [rbp-0x22C], eax
       cmp      dword ptr [rbp-0x22C], 0
       jg       SHORT G_M000_IG65
 
G_M000_IG64:
       lea      rcx, [rbp-0x22C]
       mov      edx, 882
       call     CORINFO_HELP_PATCHPOINT
       jmp      rax
 
G_M000_IG65:
       mov      rcx, gword ptr [rbp+0x30]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_KeywordOnlyCount():int:this]
       cmp      eax, dword ptr [rbp-0xA4]
       jg       G_M000_IG58
 
G_M000_IG66:
       mov      rcx, 0xD1FFAB1E
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG67:
       mov      rcx, gword ptr [rbp+0x30]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_VariadicListIndex():int:this]
       test     eax, eax
       jl       G_M000_IG73
       mov      rcx, 0xD1FFAB1E
       call     CORINFO_HELP_NEWSFAST
       mov      gword ptr [rbp-0x150], rax
       mov      rcx, gword ptr [rbp-0x150]
       call     [Lokad.Lython.Runtime.LythonRuntime+<>c__DisplayClass332_0:.ctor():this]
       mov      rax, gword ptr [rbp-0x150]
       mov      gword ptr [rbp-0xC8], rax
       mov      rcx, gword ptr [rbp+0x30]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_VariadicListIndex():int:this]
       mov      dword ptr [rbp-0xCC], eax
       mov      rax, gword ptr [rbp-0xC8]
       lea      rcx, bword ptr [rax+0x08]
       mov      rdx, gword ptr [rbp-0x40]
       call     CORINFO_HELP_ASSIGN_REF
       mov      rax, gword ptr [rbp-0xC8]
       cmp      gword ptr [rax+0x08], 0
       je       SHORT G_M000_IG69
       mov      rax, gword ptr [rbp-0xC8]
       mov      rcx, gword ptr [rax+0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.PyList:get_Count():int:this]
       test     eax, eax
       jne      G_M000_IG71
 
G_M000_IG68:
       mov      rcx, 0xD1FFAB1E
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG69:
       mov      rax, bword ptr [rbp+0x10]
       mov      eax, dword ptr [rax+0x08]
       cmp      dword ptr [rbp-0xCC], eax
       jae      G_M000_IG83
       mov      rax, bword ptr [rbp+0x10]
       mov      rax, bword ptr [rax]
       mov      ecx, dword ptr [rbp-0xCC]
       lea      rax, bword ptr [rax+8*rcx]
       mov      bword ptr [rbp-0x160], rax
       mov      rax, 0xD1FFAB1E
       mov      rax, gword ptr [rax]
       mov      gword ptr [rbp-0x158], rax
       mov      rax, bword ptr [rbp-0x160]
       mov      bword ptr [rbp-0x168], rax
       xor      eax, eax
       mov      dword ptr [rbp-0x16C], eax
       mov      rax, gword ptr [rbp-0x158]
       mov      gword ptr [rbp-0x178], rax
       cmp      gword ptr [rbp-0x158], 0
       jne      SHORT G_M000_IG70
       mov      rcx, 0xD1FFAB1E
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, 0xD1FFAB1E
       call     CORINFO_HELP_NEWSFAST
       mov      gword ptr [rbp-0x180], rax
       mov      rax, 0xD1FFAB1E
       mov      rdx, gword ptr [rax]
       mov      rcx, gword ptr [rbp-0x180]
       mov      r8, 0xD1FFAB1E
       call     [System.Delegate:CtorClosed(System.Object,nint):this]
       mov      rdx, gword ptr [rbp-0x180]
       mov      rcx, 0xD1FFAB1E
       call     CORINFO_HELP_ASSIGN_REF
       mov      rax, gword ptr [rbp-0x180]
       mov      gword ptr [rbp-0x178], rax
 
G_M000_IG70:
       mov      ecx, dword ptr [rbp-0x16C]
       mov      rdx, gword ptr [rbp-0x178]
       mov      r8, gword ptr [rbp+0x38]
       mov      r9, gword ptr [rbp+0x28]
       call     [Lokad.Lython.Runtime.LythonRuntime:CreateTuple(int,System.Func`2[int,System.Object],Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.PyTuple]
       mov      rdx, rax
       mov      rcx, bword ptr [rbp-0x168]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       jmp      G_M000_IG72
 
G_M000_IG71:
       mov      rcx, 0xD1FFAB1E
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, 0xD1FFAB1E
       call     CORINFO_HELP_NEWSFAST
       mov      gword ptr [rbp-0x188], rax
       mov      rax, gword ptr [rbp-0xC8]
       mov      rcx, gword ptr [rax+0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.PyList:get_Count():int:this]
       mov      dword ptr [rbp-0x18C], eax
       mov      rcx, gword ptr [rbp-0x188]
       mov      rdx, gword ptr [rbp-0xC8]
       mov      r8, 0xD1FFAB1E
       call     [System.Delegate:CtorClosed(System.Object,nint):this]
       mov      ecx, dword ptr [rbp-0x18C]
       mov      rdx, gword ptr [rbp-0x188]
       mov      r8, gword ptr [rbp+0x38]
       mov      r9, gword ptr [rbp+0x28]
       call     [Lokad.Lython.Runtime.LythonRuntime:CreateTuple(int,System.Func`2[int,System.Object],Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.PyTuple]
       mov      gword ptr [rbp-0xD8], rax
       mov      rax, bword ptr [rbp+0x10]
       mov      eax, dword ptr [rax+0x08]
       cmp      dword ptr [rbp-0xCC], eax
       jae      G_M000_IG83
       mov      rax, bword ptr [rbp+0x10]
       mov      rax, bword ptr [rax]
       mov      ecx, dword ptr [rbp-0xCC]
       lea      rcx, bword ptr [rax+8*rcx]
       mov      rdx, gword ptr [rbp-0xD8]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
 
G_M000_IG72:
       mov      rcx, 0xD1FFAB1E
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp+0x18]
       mov      edx, dword ptr [rbp-0xCC]
       mov      r8d, 1
       call     [Lokad.Lython.Runtime.ArgumentPresence:set_Item(int,bool):this]
 
G_M000_IG73:
       mov      rcx, gword ptr [rbp+0x30]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_VariadicDictionaryIndex():int:this]
       test     eax, eax
       jl       G_M000_IG81
       mov      rcx, 0xD1FFAB1E
       call     CORINFO_HELP_NEWSFAST
       mov      gword ptr [rbp-0x140], rax
       mov      rcx, gword ptr [rbp+0x38]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:get_MemoryGovernor():Lokad.Lython.Runtime.MemoryGovernor:this]
       mov      gword ptr [rbp-0x2C8], rax
       mov      rdx, gword ptr [rbp-0x2C8]
       mov      rcx, gword ptr [rbp-0x140]
       mov      r8, gword ptr [rbp+0x28]
       call     [Lokad.Lython.Runtime.PyDict:.ctor(Lokad.Lython.Runtime.MemoryGovernor,Lokad.Lython.LythonSourceSpan):this]
       mov      rax, gword ptr [rbp-0x140]
       mov      gword ptr [rbp-0xE0], rax
       cmp      gword ptr [rbp-0x48], 0
       je       G_M000_IG80
       lea      rdx, [rbp-0x110]
       mov      rcx, gword ptr [rbp-0x48]
       cmp      dword ptr [rcx], ecx
       call     [System.Collections.Generic.Dictionary`2[System.__Canon,System.__Canon]:GetEnumerator():System.Collections.Generic.Dictionary`2+Enumerator[System.__Canon,System.__Canon]:this]
       nop      
 
G_M000_IG74:
       jmp      G_M000_IG76
 
G_M000_IG75:
       mov      rcx, 0xD1FFAB1E
       call     CORINFO_HELP_COUNTPROFILE32
       lea      rdx, [rbp-0x120]
       lea      rcx, [rbp-0x110]
       mov      r8, 0xD1FFAB1E
       call     [System.Collections.Generic.Dictionary`2+Enumerator[System.__Canon,System.__Canon]:get_Current():System.Collections.Generic.KeyValuePair`2[System.__Canon,System.__Canon]:this]
       lea      rcx, [rbp-0x120]
       mov      rdx, 0xD1FFAB1E
       call     [System.Collections.Generic.KeyValuePair`2[System.__Canon,System.__Canon]:get_Key():System.__Canon:this]
       mov      gword ptr [rbp-0x148], rax
       mov      rcx, gword ptr [rbp+0x38]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:get_MemoryGovernor():Lokad.Lython.Runtime.MemoryGovernor:this]
       mov      gword ptr [rbp-0x2D0], rax
       mov      rdx, gword ptr [rbp-0x2D0]
       mov      rcx, gword ptr [rbp-0x148]
       mov      r8, gword ptr [rbp+0x28]
       call     [Lokad.Lython.Runtime.Text.PyString:FromString(System.String,Lokad.Lython.Runtime.MemoryGovernor,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.Text.PyString]
       mov      gword ptr [rbp-0x128], rax
       lea      rcx, [rbp-0x120]
       mov      rdx, 0xD1FFAB1E
       call     [System.Collections.Generic.KeyValuePair`2[System.__Canon,System.__Canon]:get_Value():System.__Canon:this]
       mov      gword ptr [rbp-0x2D8], rax
       mov      r8, gword ptr [rbp-0x2D8]
       mov      rdx, gword ptr [rbp-0x128]
       mov      rcx, gword ptr [rbp-0xE0]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.PyDict:SetItem(System.Object,System.Object):this]
 
G_M000_IG76:
       mov      eax, dword ptr [rbp-0x22C]
       dec      eax
       mov      dword ptr [rbp-0x22C], eax
       cmp      dword ptr [rbp-0x22C], 0
       jg       SHORT G_M000_IG78
 
G_M000_IG77:
       lea      rcx, [rbp-0x22C]
       mov      edx, 0x480
       call     CORINFO_HELP_PATCHPOINT
       jmp      rax
 
G_M000_IG78:
       lea      rcx, [rbp-0x110]
       mov      rdx, 0xD1FFAB1E
       call     [System.Collections.Generic.Dictionary`2+Enumerator[System.__Canon,System.__Canon]:MoveNext():bool:this]
       test     eax, eax
       jne      G_M000_IG75
       mov      rcx, 0xD1FFAB1E
       call     CORINFO_HELP_COUNTPROFILE32
       nop      
 
G_M000_IG79:
       call     G_M000_IG84
       nop      
 
G_M000_IG80:
       mov      rcx, 0xD1FFAB1E
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, gword ptr [rbp+0x30]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_VariadicDictionaryIndex():int:this]
       mov      dword ptr [rbp-0xE4], eax
       mov      rax, bword ptr [rbp+0x10]
       mov      eax, dword ptr [rax+0x08]
       cmp      dword ptr [rbp-0xE4], eax
       jae      SHORT G_M000_IG83
       mov      rax, bword ptr [rbp+0x10]
       mov      rax, bword ptr [rax]
       mov      ecx, dword ptr [rbp-0xE4]
       lea      rcx, bword ptr [rax+8*rcx]
       mov      rdx, gword ptr [rbp-0xE0]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rcx, bword ptr [rbp+0x18]
       mov      edx, dword ptr [rbp-0xE4]
       mov      r8d, 1
       call     [Lokad.Lython.Runtime.ArgumentPresence:set_Item(int,bool):this]
 
G_M000_IG81:
       mov      rcx, 0xD1FFAB1E
       call     CORINFO_HELP_COUNTPROFILE32
       nop      
 
G_M000_IG82:
       add      rsp, 768
       pop      rbp
       ret      
 
G_M000_IG83:
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG84:
       sub      rsp, 40
 
G_M000_IG85:
       mov      rcx, 0xD1FFAB1E
       call     CORINFO_HELP_COUNTPROFILE32
       lea      rcx, [rbp-0x110]
       mov      rdx, 0xD1FFAB1E
       call     [System.Collections.Generic.Dictionary`2+Enumerator[System.__Canon,System.__Canon]:Dispose():this]
       nop      
 
G_M000_IG86:
       add      rsp, 40
       ret      
 
; Total bytes of code 4537

; Assembly listing for method Lokad.Lython.Runtime.PyExecutableFunction:StartNativeCall(Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[System.Object],System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,bool,bool,System.Span`1[System.Object],byref,byref,byref):this (Instrumented Tier0)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; Instrumented Tier0 code
; rbp based frame
; partially interruptible
; compiling with minopt

G_M000_IG01:
       push     rbp
       sub      rsp, 656
       lea      rbp, [rsp+0x290]
       xor      eax, eax
       mov      qword ptr [rbp-0x238], rax
       vxorps   xmm4, xmm4, xmm4
       vmovdqa  xmmword ptr [rbp-0x230], xmm4
       mov      rax, -480
 
G_M000_IG27:
       vmovdqa  xmmword ptr [rbp+rax-0x40], xmm4
       vmovdqa  xmmword ptr [rbp+rax-0x30], xmm4
       vmovdqa  xmmword ptr [rbp+rax-0x20], xmm4
       add      rax, 48
       jne      SHORT G_M000_IG27
       mov      qword ptr [rbp-0x40], rax
       mov      gword ptr [rbp+0x10], rcx
       mov      gword ptr [rbp+0x18], rdx
       mov      bword ptr [rbp+0x20], r8
       mov      gword ptr [rbp+0x28], r9
 
G_M000_IG02:
       mov      dword ptr [rbp-0x174], 0x3E8
       vxorps   ymm0, ymm0, ymm0
       vmovdqu  ymmword ptr [rbp-0xB8], ymm0
       vmovdqu  ymmword ptr [rbp-0x98], ymm0
       vmovdqu  ymmword ptr [rbp-0x78], ymm0
       vmovdqu  ymmword ptr [rbp-0x58], ymm0
       lea      r8, [rbp-0xB8]
       lea      rcx, [rbp-0xC8]
       mov      rdx, 0xD1FFAB1E
       mov      r9d, 16
       call     [<PrivateImplementationDetails>:InlineArrayAsSpan[Lokad.Lython.Runtime.PyExecutableFunction+NativeValues,System.__Canon](byref,int):System.Span`1[System.__Canon]]
       mov      rax, gword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax+0x68]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_ValueStorageCapacity():int:this]
       mov      dword ptr [rbp-0x178], eax
       mov      eax, dword ptr [rbp-0x178]
       mov      dword ptr [rsp+0x20], eax
       lea      rcx, [rbp-0xC8]
       lea      rdx, [rbp-0xC8]
       mov      r8, 0xD1FFAB1E
       xor      r9d, r9d
       call     [System.Span`1[System.__Canon]:Slice(int,int):System.Span`1[System.__Canon]:this]
       mov      rcx, gword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.PyFunctionBase:get_BindingPlan():Lokad.Lython.Runtime.FunctionBindingPlan:this]
       mov      rcx, rax
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_ParameterCount():int:this]
       mov      dword ptr [rbp-0x17C], eax
       mov      edx, dword ptr [rbp-0x17C]
       lea      rcx, [rbp-0xE0]
       call     [Lokad.Lython.Runtime.ArgumentPresence:.ctor(int):this]
       movzx    rax, byte  ptr [rbp+0x48]
       test     eax, eax
       je       G_M000_IG09
 
G_M000_IG03:
       vmovdqu  xmm0, xmmword ptr [rbp-0xC8]
       vmovdqu  xmmword ptr [rbp-0x190], xmm0
 
G_M000_IG04:
       lea      r8, [rbp-0x190]
       mov      rcx, bword ptr [rbp+0x20]
       mov      rdx, 0xD1FFAB1E
       call     [System.ReadOnlySpan`1[System.__Canon]:CopyTo(System.Span`1[System.__Canon]):this]
       xor      eax, eax
       mov      dword ptr [rbp-0xE4], eax
       jmp      SHORT G_M000_IG06
 
G_M000_IG05:
       mov      rcx, 0xD1FFAB1E
       call     CORINFO_HELP_COUNTPROFILE32
       lea      rcx, [rbp-0xE0]
       mov      edx, dword ptr [rbp-0xE4]
       mov      r8d, 1
       call     [Lokad.Lython.Runtime.ArgumentPresence:set_Item(int,bool):this]
       mov      eax, dword ptr [rbp-0xE4]
       inc      eax
       mov      dword ptr [rbp-0xE4], eax
 
G_M000_IG06:
       mov      eax, dword ptr [rbp-0x174]
       dec      eax
       mov      dword ptr [rbp-0x174], eax
       cmp      dword ptr [rbp-0x174], 0
       jg       SHORT G_M000_IG08
 
G_M000_IG07:
       lea      rcx, [rbp-0x174]
       mov      edx, 85
       call     CORINFO_HELP_PATCHPOINT
       jmp      rax
 
G_M000_IG08:
       lea      rcx, [rbp-0xE0]
       call     [Lokad.Lython.Runtime.ArgumentPresence:get_Length():int:this]
       cmp      eax, dword ptr [rbp-0xE4]
       jg       SHORT G_M000_IG05
       jmp      G_M000_IG16
 
G_M000_IG09:
       mov      rcx, 0xD1FFAB1E
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, gword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.PyFunctionBase:get_BindingPlan():Lokad.Lython.Runtime.FunctionBindingPlan:this]
       mov      rcx, rax
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_ParameterCount():int:this]
       mov      dword ptr [rbp-0x194], eax
       mov      eax, dword ptr [rbp-0x194]
       mov      dword ptr [rsp+0x20], eax
       lea      rcx, [rbp-0xC8]
       lea      rdx, [rbp-0x138]
       mov      r8, 0xD1FFAB1E
       xor      r9d, r9d
       call     [System.Span`1[System.__Canon]:Slice(int,int):System.Span`1[System.__Canon]:this]
       vxorps   xmm0, xmm0, xmm0
       vmovdqu  xmmword ptr [rbp-0xF8], xmm0
 
G_M000_IG10:
       vmovdqu  xmm0, xmmword ptr [rbp-0xF8]
       vmovdqu  xmmword ptr [rbp-0x148], xmm0
 
G_M000_IG11:
       vmovdqu  xmm0, xmmword ptr [rbp-0x138]
       vmovdqu  xmmword ptr [rbp-0x1A8], xmm0
 
G_M000_IG12:
       vmovdqu  xmm0, xmmword ptr [rbp-0x148]
       vmovdqu  xmmword ptr [rbp-0x1B8], xmm0
 
G_M000_IG13:
       mov      rcx, gword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.PyFunctionBase:get_BindingPlan():Lokad.Lython.Runtime.FunctionBindingPlan:this]
       mov      gword ptr [rbp-0x1D0], rax
       mov      rax, gword ptr [rbp+0x30]
       mov      gword ptr [rsp+0x28], rax
       xor      eax, eax
       mov      dword ptr [rsp+0x30], eax
       mov      rax, gword ptr [rbp+0x28]
       mov      gword ptr [rsp+0x38], rax
       mov      rax, gword ptr [rbp+0x18]
       mov      gword ptr [rsp+0x40], rax
       mov      rax, bword ptr [rbp+0x20]
 
G_M000_IG14:
       vmovdqu  xmm0, xmmword ptr [rax]
       vmovdqu  xmmword ptr [rbp-0x1C8], xmm0
 
G_M000_IG15:
       mov      rax, gword ptr [rbp-0x1D0]
       mov      gword ptr [rsp+0x20], rax
       lea      r8, [rbp-0x1B8]
       lea      rcx, [rbp-0x1A8]
       lea      rax, [rbp-0x1C8]
       mov      qword ptr [rsp+0x48], rax
       lea      rdx, [rbp-0xE0]
       mov      r9, gword ptr [rbp+0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime:BindFunctionArgumentsInto(System.Span`1[System.Object],byref,System.ReadOnlySpan`1[Lokad.Lython.Runtime.CallArgumentValue],Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.FunctionBindingPlan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,bool,System.Object,Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[System.Object])]
 
G_M000_IG16:
       mov      rcx, 0xD1FFAB1E
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG17:
       vmovdqu  xmm0, xmmword ptr [rbp-0xC8]
       vmovdqu  xmmword ptr [rbp-0x158], xmm0
 
G_M000_IG18:
       vmovdqu  xmm0, xmmword ptr [rbp-0xE0]
       vmovdqu  xmmword ptr [rbp-0x170], xmm0
       mov      rax, qword ptr [rbp-0xD0]
       mov      qword ptr [rbp-0x160], rax
 
G_M000_IG19:
       vxorps   ymm0, ymm0, ymm0
       vmovdqu  ymmword ptr [rbp-0x128], ymm0
       vmovdqu  xmmword ptr [rbp-0x108], xmm0
 
G_M000_IG20:
       vmovdqu  xmm0, xmmword ptr [rbp-0x158]
       vmovdqu  xmmword ptr [rbp-0x1E0], xmm0
 
G_M000_IG21:
       vmovdqu  xmm0, xmmword ptr [rbp-0x170]
       vmovdqu  xmmword ptr [rbp-0x1F8], xmm0
       mov      rax, qword ptr [rbp-0x160]
       mov      qword ptr [rbp-0x1E8], rax
 
G_M000_IG22:
       vmovdqu  ymm0, ymmword ptr [rbp-0x128]
       vmovdqu  ymmword ptr [rbp-0x228], ymm0
       vmovdqu  xmm0, xmmword ptr [rbp-0x108]
       vmovdqu  xmmword ptr [rbp-0x208], xmm0
 
G_M000_IG23:
       mov      rax, gword ptr [rbp+0x38]
       mov      gword ptr [rsp+0x20], rax
       movzx    rax, byte  ptr [rbp+0x40]
       mov      dword ptr [rsp+0x28], eax
       mov      rax, bword ptr [rbp+0x50]
 
G_M000_IG24:
       vmovdqu  xmm0, xmmword ptr [rax]
       vmovdqu  xmmword ptr [rbp-0x238], xmm0
 
G_M000_IG25:
       mov      rax, bword ptr [rbp+0x58]
       mov      bword ptr [rsp+0x38], rax
       mov      rax, bword ptr [rbp+0x60]
       mov      bword ptr [rsp+0x40], rax
       mov      rax, bword ptr [rbp+0x68]
       mov      bword ptr [rsp+0x48], rax
       lea      rdx, [rbp-0x1E0]
       lea      r8, [rbp-0x1F8]
       lea      r9, [rbp-0x228]
       lea      rax, [rbp-0x238]
       mov      qword ptr [rsp+0x30], rax
       mov      rcx, gword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.PyExecutableFunction:StartInline(System.Span`1[System.Object],Lokad.Lython.Runtime.ArgumentPresence,System.Nullable`1[Lokad.Lython.Runtime.BoundCallArguments],Lokad.Lython.LythonSourceSpan,bool,System.Span`1[System.Object],byref,byref,byref):this]
       nop      
 
G_M000_IG26:
       vzeroupper 
       add      rsp, 656
       pop      rbp
       ret      
 
; Total bytes of code 1006

; Assembly listing for method Lokad.Lython.Runtime.LythonRuntime:BindFunctionArgumentsInto(System.Span`1[System.Object],byref,System.ReadOnlySpan`1[Lokad.Lython.Runtime.CallArgumentValue],Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.FunctionBindingPlan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,bool,System.Object,Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[System.Object]) (Instrumented Tier0)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; Instrumented Tier0 code
; rbp based frame
; fully interruptible
; compiling with minopt

G_M000_IG01:
       push     rbp
       sub      rsp, 768
       lea      rbp, [rsp+0x300]
       xor      eax, eax
       mov      qword ptr [rbp-0x2D8], rax
       vxorps   xmm4, xmm4, xmm4
       vmovdqa  xmmword ptr [rbp-0x2D0], xmm4
       vmovdqa  xmmword ptr [rbp-0x2C0], xmm4
       mov      rax, -624
 
G_M000_IG87:
       vmovdqa  xmmword ptr [rbp+rax-0x40], xmm4
       vmovdqa  xmmword ptr [rbp+rax-0x30], xmm4
       vmovdqa  xmmword ptr [rbp+rax-0x20], xmm4
       add      rax, 48
       jne      SHORT G_M000_IG87
       mov      qword ptr [rbp-0x40], rax
       mov      bword ptr [rbp+0x10], rcx
       mov      bword ptr [rbp+0x18], rdx
       mov      bword ptr [rbp+0x20], r8
       mov      gword ptr [rbp+0x28], r9
 
G_M000_IG02:
       mov      dword ptr [rbp-0x22C], 0x3E8
       xor      rax, rax
       mov      gword ptr [rbp-0x40], rax
       xor      rax, rax
       mov      gword ptr [rbp-0x48], rax
       xor      eax, eax
       mov      dword ptr [rbp-0x4C], eax
       mov      rcx, gword ptr [rbp+0x30]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_VariadicListIndex():int:this]
       test     eax, eax
       jge      SHORT G_M000_IG04
       cmp      gword ptr [rbp+0x50], 0
       jne      SHORT G_M000_IG03
       mov      rcx, bword ptr [rbp+0x20]
       call     [System.ReadOnlySpan`1[Lokad.Lython.Runtime.CallArgumentValue]:get_IsEmpty():bool:this]
       mov      dword ptr [rbp-0x12C], eax
       jmp      SHORT G_M000_IG05
 
G_M000_IG03:
       mov      rcx, 0xD1FFAB1E
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, gword ptr [rbp+0x50]
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_IsPositionalOnly():bool:this]
       mov      dword ptr [rbp-0x12C], eax
       jmp      SHORT G_M000_IG05
 
G_M000_IG04:
       mov      rcx, 0xD1FFAB1E
       call     CORINFO_HELP_COUNTPROFILE32
       xor      eax, eax
       mov      dword ptr [rbp-0x12C], eax
 
G_M000_IG05:
       movzx    rax, byte  ptr [rbp-0x12C]
       mov      dword ptr [rbp-0x50], eax
       cmp      dword ptr [rbp-0x50], 0
       je       G_M000_IG13
       cmp      gword ptr [rbp+0x48], 0
       setne    al
       movzx    rax, al
       mov      dword ptr [rbp-0x58], eax
       mov      rax, bword ptr [rbp+0x58]
       mov      eax, dword ptr [rax+0x08]
       mov      dword ptr [rbp-0x20C], eax
       mov      rcx, gword ptr [rbp+0x30]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_PositionalCount():int:this]
       sub      eax, dword ptr [rbp-0x58]
       cmp      eax, dword ptr [rbp-0x20C]
       jge      SHORT G_M000_IG07
 
G_M000_IG06:
       mov      rcx, gword ptr [rbp+0x30]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_CallableKind():int:this]
       mov      dword ptr [rbp-0x220], eax
       mov      rcx, gword ptr [rbp+0x30]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_CallableName():System.String:this]
       mov      gword ptr [rbp-0x238], rax
       mov      rdx, gword ptr [rbp-0x238]
       mov      ecx, dword ptr [rbp-0x220]
       mov      r8, gword ptr [rbp+0x28]
       call     [Lokad.Lython.Runtime.CallErrors:TooManyPositional(int,System.String,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.LythonRuntimeException]
       mov      rcx, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG07:
       cmp      gword ptr [rbp+0x48], 0
       je       SHORT G_M000_IG08
       mov      rcx, 0xD1FFAB1E
       call     CORINFO_HELP_COUNTPROFILE32
       mov      eax, dword ptr [rbp-0x4C]
       mov      dword ptr [rbp-0x21C], eax
       mov      eax, dword ptr [rbp-0x4C]
       inc      eax
       mov      dword ptr [rbp-0x4C], eax
       mov      rax, bword ptr [rbp+0x10]
       mov      eax, dword ptr [rax+0x08]
       cmp      dword ptr [rbp-0x21C], eax
       jae      G_M000_IG83
       mov      rax, bword ptr [rbp+0x10]
       mov      rax, bword ptr [rax]
       mov      ecx, dword ptr [rbp-0x21C]
       lea      rcx, bword ptr [rax+8*rcx]
       mov      rdx, gword ptr [rbp+0x48]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
 
G_M000_IG08:
       xor      eax, eax
       mov      dword ptr [rbp-0x5C], eax
       jmp      G_M000_IG10
 
G_M000_IG09:
       mov      rcx, 0xD1FFAB1E
       call     CORINFO_HELP_COUNTPROFILE32
       mov      eax, dword ptr [rbp-0x4C]
       mov      dword ptr [rbp-0x210], eax
       mov      eax, dword ptr [rbp-0x4C]
       inc      eax
       mov      dword ptr [rbp-0x4C], eax
       mov      rax, bword ptr [rbp+0x10]
       mov      eax, dword ptr [rax+0x08]
       cmp      dword ptr [rbp-0x210], eax
       jae      G_M000_IG83
       mov      rax, bword ptr [rbp+0x10]
       mov      rax, bword ptr [rax]
       mov      ecx, dword ptr [rbp-0x210]
       lea      rax, bword ptr [rax+8*rcx]
       mov      bword ptr [rbp-0x218], rax
       mov      rax, bword ptr [rbp+0x58]
       mov      eax, dword ptr [rax+0x08]
       cmp      dword ptr [rbp-0x5C], eax
       jae      G_M000_IG83
       mov      rax, bword ptr [rbp+0x58]
       mov      rax, bword ptr [rax]
       mov      ecx, dword ptr [rbp-0x5C]
       mov      rdx, gword ptr [rax+8*rcx]
       mov      rcx, 0xD1FFAB1E
       call     [Lokad.Lython.Internal.NullabilityExtensions:RequireNotNull[System.__Canon](System.__Canon):System.__Canon]
       mov      rdx, rax
       mov      rcx, bword ptr [rbp-0x218]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      eax, dword ptr [rbp-0x5C]
       inc      eax
       mov      dword ptr [rbp-0x5C], eax
 
G_M000_IG10:
       mov      eax, dword ptr [rbp-0x22C]
       dec      eax
       mov      dword ptr [rbp-0x22C], eax
       cmp      dword ptr [rbp-0x22C], 0
       jg       SHORT G_M000_IG12
 
G_M000_IG11:
       lea      rcx, [rbp-0x22C]
       mov      edx, 148
       call     CORINFO_HELP_PATCHPOINT
       jmp      rax
 
G_M000_IG12:
       mov      rax, bword ptr [rbp+0x58]
       mov      eax, dword ptr [rax+0x08]
       cmp      eax, dword ptr [rbp-0x5C]
       jg       G_M000_IG09
       mov      rcx, 0xD1FFAB1E
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp+0x18]
       mov      r8d, dword ptr [rbp-0x4C]
       xor      edx, edx
       call     [Lokad.Lython.Runtime.ArgumentPresence:MarkRange(int,int):this]
 
G_M000_IG13:
       cmp      gword ptr [rbp+0x50], 0
       jne      SHORT G_M000_IG15
       mov      rcx, bword ptr [rbp+0x20]
       call     [System.ReadOnlySpan`1[Lokad.Lython.Runtime.CallArgumentValue]:get_IsEmpty():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG14
       mov      rax, bword ptr [rbp+0x20]
       mov      eax, dword ptr [rax+0x08]
       mov      dword ptr [rbp-0x130], eax
       jmp      SHORT G_M000_IG16
 
G_M000_IG14:
       mov      rcx, 0xD1FFAB1E
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x58]
       mov      eax, dword ptr [rax+0x08]
       mov      dword ptr [rbp-0x130], eax
       jmp      SHORT G_M000_IG16
 
G_M000_IG15:
       mov      rcx, 0xD1FFAB1E
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, gword ptr [rbp+0x50]
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_ArgumentCount():int:this]
       mov      dword ptr [rbp-0x130], eax
 
G_M000_IG16:
       mov      eax, dword ptr [rbp-0x130]
       mov      dword ptr [rbp-0x54], eax
       cmp      gword ptr [rbp+0x48], 0
       je       SHORT G_M000_IG17
       mov      dword ptr [rbp-0x134], -1
       jmp      SHORT G_M000_IG18
 
G_M000_IG17:
       mov      rcx, 0xD1FFAB1E
       call     CORINFO_HELP_COUNTPROFILE32
       xor      eax, eax
       mov      dword ptr [rbp-0x134], eax
 
G_M000_IG18:
       mov      eax, dword ptr [rbp-0x134]
       mov      dword ptr [rbp-0x60], eax
       jmp      G_M000_IG47
 
G_M000_IG19:
       cmp      dword ptr [rbp-0x60], 0
       jl       G_M000_IG27
       cmp      gword ptr [rbp+0x50], 0
       je       G_M000_IG23
       mov      rcx, gword ptr [rbp+0x50]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_Arguments():Lokad.Lython.Frontend.CallArgumentForm[]:this]
       mov      ecx, dword ptr [rbp-0x60]
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG83
       mov      edx, ecx
       imul     rdx, rdx, 16
       lea      rax, bword ptr [rax+rdx+0x10]
 
G_M000_IG20:
       vmovdqu  xmm0, xmmword ptr [rax]
       vmovdqu  xmmword ptr [rbp-0x208], xmm0
 
G_M000_IG21:
       vmovdqu  xmm0, xmmword ptr [rbp-0x208]
       vmovdqu  xmmword ptr [rbp-0x248], xmm0
 
G_M000_IG22:
       mov      rax, bword ptr [rbp+0x58]
       mov      eax, dword ptr [rax+0x08]
       cmp      dword ptr [rbp-0x60], eax
       jae      G_M000_IG83
       mov      rax, bword ptr [rbp+0x58]
       mov      rax, bword ptr [rax]
       mov      ecx, dword ptr [rbp-0x60]
       mov      rdx, gword ptr [rax+8*rcx]
       mov      rcx, 0xD1FFAB1E
       call     [Lokad.Lython.Internal.NullabilityExtensions:RequireNotNull[System.__Canon](System.__Canon):System.__Canon]
       mov      gword ptr [rbp-0x250], rax
       mov      r8, gword ptr [rbp-0x250]
       lea      rdx, [rbp-0x248]
       lea      rcx, [rbp-0x1A8]
       call     [Lokad.Lython.Runtime.LythonRuntime:CreateExecutableCallArgument(Lokad.Lython.Frontend.CallArgumentForm,System.Object):Lokad.Lython.Runtime.CallArgumentValue]
       jmp      G_M000_IG28
 
G_M000_IG23:
       mov      rcx, bword ptr [rbp+0x20]
       call     [System.ReadOnlySpan`1[Lokad.Lython.Runtime.CallArgumentValue]:get_IsEmpty():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG26
       mov      rcx, 0xD1FFAB1E
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x20]
       mov      eax, dword ptr [rax+0x08]
       cmp      dword ptr [rbp-0x60], eax
       jae      G_M000_IG83
       mov      rax, bword ptr [rbp+0x20]
       mov      rax, bword ptr [rax]
       mov      ecx, dword ptr [rbp-0x60]
       lea      rcx, [rcx+2*rcx]
 
G_M000_IG24:
       vmovdqu  xmm0, xmmword ptr [rax+8*rcx]
       vmovdqu  xmmword ptr [rbp-0x1A8], xmm0
       mov      rdx, qword ptr [rax+8*rcx+0x10]
       mov      qword ptr [rbp-0x198], rdx
 
G_M000_IG25:
       jmp      SHORT G_M000_IG28
 
G_M000_IG26:
       mov      rcx, 0xD1FFAB1E
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x58]
       mov      eax, dword ptr [rax+0x08]
       cmp      dword ptr [rbp-0x60], eax
       jae      G_M000_IG83
       mov      rax, bword ptr [rbp+0x58]
       mov      rax, bword ptr [rax]
       mov      ecx, dword ptr [rbp-0x60]
       mov      rdx, gword ptr [rax+8*rcx]
       mov      rcx, 0xD1FFAB1E
       call     [Lokad.Lython.Internal.NullabilityExtensions:RequireNotNull[System.__Canon](System.__Canon):System.__Canon]
       mov      gword ptr [rbp-0x258], rax
       mov      rdx, gword ptr [rbp-0x258]
       lea      rcx, [rbp-0x1A8]
       call     [Lokad.Lython.Runtime.CallArgumentValue:Positional(System.Object):Lokad.Lython.Runtime.CallArgumentValue]
       jmp      SHORT G_M000_IG28
 
G_M000_IG27:
       mov      rcx, 0xD1FFAB1E
       call     CORINFO_HELP_COUNTPROFILE32
       lea      rcx, [rbp-0x1A8]
       mov      rdx, gword ptr [rbp+0x48]
       call     [Lokad.Lython.Runtime.CallArgumentValue:Positional(System.Object):Lokad.Lython.Runtime.CallArgumentValue]
 
G_M000_IG28:
       vmovdqu  xmm0, xmmword ptr [rbp-0x1A8]
       vmovdqu  xmmword ptr [rbp-0x78], xmm0
       mov      rax, qword ptr [rbp-0x198]
       mov      qword ptr [rbp-0x68], rax
 
G_M000_IG29:
       lea      rcx, [rbp-0x78]
       call     [Lokad.Lython.Runtime.CallArgumentValue:get_IsPositional():bool:this]
       test     eax, eax
       je       G_M000_IG34
       mov      rcx, gword ptr [rbp+0x30]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_PositionalCount():int:this]
       cmp      eax, dword ptr [rbp-0x4C]
       jg       G_M000_IG33
       mov      rcx, gword ptr [rbp+0x30]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_VariadicListIndex():int:this]
       test     eax, eax
       jge      SHORT G_M000_IG31
 
G_M000_IG30:
       mov      rcx, gword ptr [rbp+0x30]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_CallableKind():int:this]
       mov      dword ptr [rbp-0x1F4], eax
       mov      rcx, gword ptr [rbp+0x30]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_CallableName():System.String:this]
       mov      gword ptr [rbp-0x260], rax
       mov      rdx, gword ptr [rbp-0x260]
       mov      ecx, dword ptr [rbp-0x1F4]
       mov      r8, gword ptr [rbp+0x28]
       call     [Lokad.Lython.Runtime.CallErrors:TooManyPositional(int,System.String,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.LythonRuntimeException]
       mov      rcx, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG31:
       cmp      gword ptr [rbp-0x40], 0
       jne      SHORT G_M000_IG32
       mov      rcx, 0xD1FFAB1E
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, 0xD1FFAB1E
       call     [System.Array:Empty[System.__Canon]():System.__Canon[]]
       mov      gword ptr [rbp-0x1E8], rax
       mov      rcx, 0xD1FFAB1E
       call     CORINFO_HELP_NEWSFAST
       mov      gword ptr [rbp-0x1F0], rax
       mov      rcx, gword ptr [rbp+0x38]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:get_MemoryGovernor():Lokad.Lython.Runtime.MemoryGovernor:this]
       mov      gword ptr [rbp-0x268], rax
       mov      r8, gword ptr [rbp-0x268]
       mov      rdx, gword ptr [rbp-0x1E8]
       mov      rcx, gword ptr [rbp-0x1F0]
       mov      r9, gword ptr [rbp+0x28]
       call     [Lokad.Lython.Runtime.PyList:.ctor(System.Collections.Generic.IEnumerable`1[System.Object],Lokad.Lython.Runtime.MemoryGovernor,Lokad.Lython.LythonSourceSpan):this]
       mov      rax, gword ptr [rbp-0x1F0]
       mov      gword ptr [rbp-0x40], rax
 
G_M000_IG32:
       lea      rcx, [rbp-0x78]
       call     [Lokad.Lython.Runtime.CallArgumentValue:get_Value():System.Object:this]
       mov      gword ptr [rbp-0x270], rax
       mov      rdx, gword ptr [rbp-0x270]
       mov      rcx, gword ptr [rbp-0x40]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.PyList:Add(System.Object):this]
       jmp      G_M000_IG46
 
G_M000_IG33:
       mov      rcx, 0xD1FFAB1E
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x10]
       mov      eax, dword ptr [rax+0x08]
       cmp      dword ptr [rbp-0x4C], eax
       jae      G_M000_IG83
       mov      rax, bword ptr [rbp+0x10]
       mov      rax, bword ptr [rax]
       mov      ecx, dword ptr [rbp-0x4C]
       lea      rax, bword ptr [rax+8*rcx]
       mov      bword ptr [rbp-0x1E0], rax
       lea      rcx, [rbp-0x78]
       call     [Lokad.Lython.Runtime.CallArgumentValue:get_Value():System.Object:this]
       mov      rdx, rax
       mov      rcx, bword ptr [rbp-0x1E0]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rcx, bword ptr [rbp+0x18]
       mov      edx, dword ptr [rbp-0x4C]
       mov      r8d, 1
       call     [Lokad.Lython.Runtime.ArgumentPresence:set_Item(int,bool):this]
       mov      eax, dword ptr [rbp-0x4C]
       inc      eax
       mov      dword ptr [rbp-0x4C], eax
       jmp      G_M000_IG46
 
G_M000_IG34:
       lea      rcx, [rbp-0x78]
       call     [Lokad.Lython.Runtime.CallArgumentValue:get_KeywordName():System.String:this]
       mov      gword ptr [rbp-0x80], rax
       mov      rcx, gword ptr [rbp+0x30]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_LayoutParameterIndex():System.Collections.Generic.IReadOnlyDictionary`2[System.String,int]:this]
       mov      gword ptr [rbp-0x228], rax
       mov      rcx, gword ptr [rbp-0x228]
       mov      rdx, 0xD1FFAB1E
       call     CORINFO_HELP_CLASSPROFILE32
       mov      rax, gword ptr [rbp-0x228]
       mov      gword ptr [rbp-0x278], rax
       mov      rcx, gword ptr [rbp-0x278]
       lea      r8, [rbp-0x88]
       mov      rdx, gword ptr [rbp-0x80]
       mov      r11, 0xD1FFAB1E
       call     [r11]System.Collections.Generic.IReadOnlyDictionary`2[System.__Canon,int]:TryGetValue(System.__Canon,byref):bool:this
       test     eax, eax
       je       SHORT G_M000_IG36
       mov      eax, dword ptr [rbp-0x88]
       mov      dword ptr [rbp-0x1C0], eax
       mov      rcx, gword ptr [rbp+0x30]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_NamedLayoutCount():int:this]
       cmp      eax, dword ptr [rbp-0x1C0]
       jle      G_M000_IG38
       mov      eax, dword ptr [rbp-0x88]
       mov      dword ptr [rbp-0x1C4], eax
       mov      rcx, gword ptr [rbp+0x30]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_PositionalOnlyCount():int:this]
       cmp      eax, dword ptr [rbp-0x1C4]
       jle      G_M000_IG43
 
G_M000_IG35:
       mov      rcx, 0xD1FFAB1E
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG36:
       mov      rcx, gword ptr [rbp+0x30]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_VariadicDictionaryIndex():int:this]
       test     eax, eax
       jge      SHORT G_M000_IG39
 
G_M000_IG37:
       mov      rcx, gword ptr [rbp+0x30]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_CallableKind():int:this]
       mov      dword ptr [rbp-0x1BC], eax
       mov      rcx, gword ptr [rbp+0x30]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_CallableName():System.String:this]
       mov      gword ptr [rbp-0x280], rax
       mov      rdx, gword ptr [rbp-0x280]
       mov      ecx, dword ptr [rbp-0x1BC]
       mov      r8, gword ptr [rbp-0x80]
       mov      r9, gword ptr [rbp+0x28]
       call     [Lokad.Lython.Runtime.CallErrors:UnexpectedKeyword(int,System.String,System.String,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.LythonRuntimeException]
       mov      rcx, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG38:
       mov      rcx, 0xD1FFAB1E
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG36
 
G_M000_IG39:
       cmp      gword ptr [rbp-0x48], 0
       jne      SHORT G_M000_IG40
       mov      rcx, 0xD1FFAB1E
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, 0xD1FFAB1E
       call     CORINFO_HELP_NEWSFAST
       mov      gword ptr [rbp-0x1B8], rax
       call     [System.StringComparer:get_Ordinal():System.StringComparer]
       mov      gword ptr [rbp-0x288], rax
       mov      rdx, gword ptr [rbp-0x288]
       mov      rcx, gword ptr [rbp-0x1B8]
       call     [System.Collections.Generic.Dictionary`2[System.__Canon,System.__Canon]:.ctor(System.Collections.Generic.IEqualityComparer`1[System.__Canon]):this]
       mov      rax, gword ptr [rbp-0x1B8]
       mov      gword ptr [rbp-0x48], rax
 
G_M000_IG40:
       lea      rcx, [rbp-0x78]
       call     [Lokad.Lython.Runtime.CallArgumentValue:get_Value():System.Object:this]
       mov      gword ptr [rbp-0x290], rax
       mov      r8, gword ptr [rbp-0x290]
       mov      rdx, gword ptr [rbp-0x80]
       mov      rcx, gword ptr [rbp-0x48]
       cmp      dword ptr [rcx], ecx
       call     [System.Collections.Generic.Dictionary`2[System.__Canon,System.__Canon]:TryAdd(System.__Canon,System.__Canon):bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG42
 
G_M000_IG41:
       mov      rcx, gword ptr [rbp+0x30]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_CallableKind():int:this]
       mov      dword ptr [rbp-0x1AC], eax
       mov      rcx, gword ptr [rbp+0x30]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_CallableName():System.String:this]
       mov      gword ptr [rbp-0x298], rax
       mov      rdx, gword ptr [rbp-0x298]
       mov      ecx, dword ptr [rbp-0x1AC]
       mov      r8, gword ptr [rbp-0x80]
       mov      r9, gword ptr [rbp+0x28]
       call     [Lokad.Lython.Runtime.CallErrors:MultipleValues(int,System.String,System.String,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.LythonRuntimeException]
       mov      rcx, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG42:
       mov      rcx, 0xD1FFAB1E
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG46
 
G_M000_IG43:
       mov      rcx, bword ptr [rbp+0x18]
       mov      edx, dword ptr [rbp-0x88]
       call     [Lokad.Lython.Runtime.ArgumentPresence:get_Item(int):bool:this]
       test     eax, eax
       je       SHORT G_M000_IG45
 
G_M000_IG44:
       mov      rcx, gword ptr [rbp+0x30]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_CallableKind():int:this]
       mov      dword ptr [rbp-0x1D4], eax
       mov      rcx, gword ptr [rbp+0x30]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_CallableName():System.String:this]
       mov      gword ptr [rbp-0x2A0], rax
       mov      rdx, gword ptr [rbp-0x2A0]
       mov      ecx, dword ptr [rbp-0x1D4]
       mov      r8, gword ptr [rbp-0x80]
       mov      r9, gword ptr [rbp+0x28]
       call     [Lokad.Lython.Runtime.CallErrors:MultipleValues(int,System.String,System.String,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.LythonRuntimeException]
       mov      rcx, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG45:
       mov      rcx, 0xD1FFAB1E
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x10]
       mov      eax, dword ptr [rax+0x08]
       cmp      dword ptr [rbp-0x88], eax
       jae      G_M000_IG83
       mov      rax, bword ptr [rbp+0x10]
       mov      rax, bword ptr [rax]
       mov      ecx, dword ptr [rbp-0x88]
       lea      rax, bword ptr [rax+8*rcx]
       mov      bword ptr [rbp-0x1D0], rax
       lea      rcx, [rbp-0x78]
       call     [Lokad.Lython.Runtime.CallArgumentValue:get_Value():System.Object:this]
       mov      rdx, rax
       mov      rcx, bword ptr [rbp-0x1D0]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rcx, bword ptr [rbp+0x18]
       mov      edx, dword ptr [rbp-0x88]
       mov      r8d, 1
       call     [Lokad.Lython.Runtime.ArgumentPresence:set_Item(int,bool):this]
 
G_M000_IG46:
       mov      rcx, 0xD1FFAB1E
       call     CORINFO_HELP_COUNTPROFILE32
       mov      eax, dword ptr [rbp-0x60]
       inc      eax
       mov      dword ptr [rbp-0x60], eax
 
G_M000_IG47:
       cmp      dword ptr [rbp-0x50], 0
       jne      SHORT G_M000_IG51
       mov      eax, dword ptr [rbp-0x22C]
       dec      eax
       mov      dword ptr [rbp-0x22C], eax
       cmp      dword ptr [rbp-0x22C], 0
       jg       SHORT G_M000_IG49
 
G_M000_IG48:
       lea      rcx, [rbp-0x22C]
       mov      edx, 650
       call     CORINFO_HELP_PATCHPOINT
       jmp      rax
 
G_M000_IG49:
       mov      eax, dword ptr [rbp-0x60]
       cmp      eax, dword ptr [rbp-0x54]
       jl       G_M000_IG19
 
G_M000_IG50:
       mov      rcx, 0xD1FFAB1E
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG51:
       xor      eax, eax
       mov      dword ptr [rbp-0x8C], eax
       jmp      G_M000_IG55
 
G_M000_IG52:
       mov      rcx, bword ptr [rbp+0x18]
       mov      edx, dword ptr [rbp-0x8C]
       call     [Lokad.Lython.Runtime.ArgumentPresence:get_Item(int):bool:this]
       test     eax, eax
       jne      G_M000_IG54
       mov      rcx, gword ptr [rbp+0x30]
       mov      edx, dword ptr [rbp-0x8C]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:NameAt(int):System.String:this]
       mov      gword ptr [rbp-0x98], rax
       lea      r8, [rbp-0xA0]
       mov      rcx, gword ptr [rbp+0x30]
       mov      edx, dword ptr [rbp-0x8C]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:TryGetPositionalDefault(int,byref):bool:this]
       test     eax, eax
       je       SHORT G_M000_IG53
       mov      rcx, 0xD1FFAB1E
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x10]
       mov      eax, dword ptr [rax+0x08]
       cmp      dword ptr [rbp-0x8C], eax
       jae      G_M000_IG83
       mov      rax, bword ptr [rbp+0x10]
       mov      rax, bword ptr [rax]
       mov      ecx, dword ptr [rbp-0x8C]
       lea      rcx, bword ptr [rax+8*rcx]
       mov      rdx, gword ptr [rbp-0xA0]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       jmp      SHORT G_M000_IG54
 
G_M000_IG53:
       mov      rcx, gword ptr [rbp+0x30]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_CallableKind():int:this]
       mov      dword ptr [rbp-0x138], eax
       mov      rcx, gword ptr [rbp+0x30]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_CallableName():System.String:this]
       mov      gword ptr [rbp-0x2A8], rax
       mov      rdx, gword ptr [rbp-0x2A8]
       mov      ecx, dword ptr [rbp-0x138]
       mov      r8, gword ptr [rbp-0x98]
       mov      r9, gword ptr [rbp+0x28]
       call     [Lokad.Lython.Runtime.CallErrors:MissingArgument(int,System.String,System.String,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.LythonRuntimeException]
       mov      rcx, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG54:
       mov      rcx, 0xD1FFAB1E
       call     CORINFO_HELP_COUNTPROFILE32
       mov      eax, dword ptr [rbp-0x8C]
       inc      eax
       mov      dword ptr [rbp-0x8C], eax
 
G_M000_IG55:
       mov      eax, dword ptr [rbp-0x22C]
       dec      eax
       mov      dword ptr [rbp-0x22C], eax
       cmp      dword ptr [rbp-0x22C], 0
       jg       SHORT G_M000_IG57
 
G_M000_IG56:
       lea      rcx, [rbp-0x22C]
       mov      edx, 741
       call     CORINFO_HELP_PATCHPOINT
       jmp      rax
 
G_M000_IG57:
       mov      rcx, gword ptr [rbp+0x30]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_PositionalCount():int:this]
       cmp      eax, dword ptr [rbp-0x8C]
       jg       G_M000_IG52
       xor      eax, eax
       mov      dword ptr [rbp-0xA4], eax
       jmp      G_M000_IG63
 
G_M000_IG58:
       mov      rcx, gword ptr [rbp+0x30]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_PositionalCount():int:this]
       add      eax, dword ptr [rbp-0xA4]
       mov      dword ptr [rbp-0xA8], eax
       mov      rcx, bword ptr [rbp+0x18]
       mov      edx, dword ptr [rbp-0xA8]
       call     [Lokad.Lython.Runtime.ArgumentPresence:get_Item(int):bool:this]
       test     eax, eax
       jne      G_M000_IG62
       mov      rcx, gword ptr [rbp+0x30]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_PositionalCount():int:this]
       add      eax, dword ptr [rbp-0xA4]
       mov      dword ptr [rbp-0x2AC], eax
       mov      edx, dword ptr [rbp-0x2AC]
       mov      rcx, gword ptr [rbp+0x30]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:NameAt(int):System.String:this]
       mov      gword ptr [rbp-0xB0], rax
       mov      rcx, gword ptr [rbp+0x30]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_KeywordDefaultStorage():Lokad.Lython.Runtime.PyDict:this]
       mov      gword ptr [rbp-0xB8], rax
       cmp      gword ptr [rbp-0xB8], 0
       je       G_M000_IG61
       mov      rcx, gword ptr [rbp+0x30]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_KeywordDefaultNames():Lokad.Lython.Runtime.Text.PyString[]:this]
       mov      ecx, dword ptr [rbp-0xA4]
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG83
       mov      edx, ecx
       lea      rax, bword ptr [rax+8*rdx+0x10]
       mov      rax, gword ptr [rax]
       mov      gword ptr [rbp-0x2B8], rax
       mov      rax, gword ptr [rbp+0x28]
       mov      gword ptr [rsp+0x20], rax
       mov      rdx, gword ptr [rbp-0x2B8]
       lea      r8, [rbp-0xC0]
       mov      rcx, gword ptr [rbp-0xB8]
       mov      r9, gword ptr [rbp+0x38]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.PyDict:TryGetValue(System.Object,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):bool:this]
       test     eax, eax
       je       SHORT G_M000_IG60
       mov      rcx, 0xD1FFAB1E
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x10]
       mov      eax, dword ptr [rax+0x08]
       cmp      dword ptr [rbp-0xA8], eax
       jae      G_M000_IG83
       mov      rax, bword ptr [rbp+0x10]
 
G_M000_IG59:
       mov      rax, bword ptr [rax]
       mov      ecx, dword ptr [rbp-0xA8]
       lea      rcx, bword ptr [rax+8*rcx]
       mov      rdx, gword ptr [rbp-0xC0]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       jmp      SHORT G_M000_IG62
 
G_M000_IG60:
       mov      rcx, 0xD1FFAB1E
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG61:
       mov      rcx, gword ptr [rbp+0x30]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_CallableKind():int:this]
       mov      dword ptr [rbp-0x190], eax
       mov      rcx, gword ptr [rbp+0x30]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_CallableName():System.String:this]
       mov      gword ptr [rbp-0x2C0], rax
       mov      rdx, gword ptr [rbp-0x2C0]
       mov      ecx, dword ptr [rbp-0x190]
       mov      r8, gword ptr [rbp-0xB0]
       mov      r9, gword ptr [rbp+0x28]
       call     [Lokad.Lython.Runtime.CallErrors:MissingArgument(int,System.String,System.String,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.LythonRuntimeException]
       mov      rcx, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG62:
       mov      rcx, 0xD1FFAB1E
       call     CORINFO_HELP_COUNTPROFILE32
       mov      eax, dword ptr [rbp-0xA4]
       inc      eax
       mov      dword ptr [rbp-0xA4], eax
 
G_M000_IG63:
       movzx    rax, byte  ptr [rbp+0x40]
       test     eax, eax
       jne      SHORT G_M000_IG67
       mov      eax, dword ptr [rbp-0x22C]
       dec      eax
       mov      dword ptr [rbp-0x22C], eax
       cmp      dword ptr [rbp-0x22C], 0
       jg       SHORT G_M000_IG65
 
G_M000_IG64:
       lea      rcx, [rbp-0x22C]
       mov      edx, 882
       call     CORINFO_HELP_PATCHPOINT
       jmp      rax
 
G_M000_IG65:
       mov      rcx, gword ptr [rbp+0x30]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_KeywordOnlyCount():int:this]
       cmp      eax, dword ptr [rbp-0xA4]
       jg       G_M000_IG58
 
G_M000_IG66:
       mov      rcx, 0xD1FFAB1E
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG67:
       mov      rcx, gword ptr [rbp+0x30]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_VariadicListIndex():int:this]
       test     eax, eax
       jl       G_M000_IG73
       mov      rcx, 0xD1FFAB1E
       call     CORINFO_HELP_NEWSFAST
       mov      gword ptr [rbp-0x150], rax
       mov      rcx, gword ptr [rbp-0x150]
       call     [Lokad.Lython.Runtime.LythonRuntime+<>c__DisplayClass332_0:.ctor():this]
       mov      rax, gword ptr [rbp-0x150]
       mov      gword ptr [rbp-0xC8], rax
       mov      rcx, gword ptr [rbp+0x30]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_VariadicListIndex():int:this]
       mov      dword ptr [rbp-0xCC], eax
       mov      rax, gword ptr [rbp-0xC8]
       lea      rcx, bword ptr [rax+0x08]
       mov      rdx, gword ptr [rbp-0x40]
       call     CORINFO_HELP_ASSIGN_REF
       mov      rax, gword ptr [rbp-0xC8]
       cmp      gword ptr [rax+0x08], 0
       je       SHORT G_M000_IG69
       mov      rax, gword ptr [rbp-0xC8]
       mov      rcx, gword ptr [rax+0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.PyList:get_Count():int:this]
       test     eax, eax
       jne      G_M000_IG71
 
G_M000_IG68:
       mov      rcx, 0xD1FFAB1E
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG69:
       mov      rax, bword ptr [rbp+0x10]
       mov      eax, dword ptr [rax+0x08]
       cmp      dword ptr [rbp-0xCC], eax
       jae      G_M000_IG83
       mov      rax, bword ptr [rbp+0x10]
       mov      rax, bword ptr [rax]
       mov      ecx, dword ptr [rbp-0xCC]
       lea      rax, bword ptr [rax+8*rcx]
       mov      bword ptr [rbp-0x160], rax
       mov      rax, 0xD1FFAB1E
       mov      rax, gword ptr [rax]
       mov      gword ptr [rbp-0x158], rax
       mov      rax, bword ptr [rbp-0x160]
       mov      bword ptr [rbp-0x168], rax
       xor      eax, eax
       mov      dword ptr [rbp-0x16C], eax
       mov      rax, gword ptr [rbp-0x158]
       mov      gword ptr [rbp-0x178], rax
       cmp      gword ptr [rbp-0x158], 0
       jne      SHORT G_M000_IG70
       mov      rcx, 0xD1FFAB1E
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, 0xD1FFAB1E
       call     CORINFO_HELP_NEWSFAST
       mov      gword ptr [rbp-0x180], rax
       mov      rax, 0xD1FFAB1E
       mov      rdx, gword ptr [rax]
       mov      rcx, gword ptr [rbp-0x180]
       mov      r8, 0xD1FFAB1E
       call     [System.Delegate:CtorClosed(System.Object,nint):this]
       mov      rdx, gword ptr [rbp-0x180]
       mov      rcx, 0xD1FFAB1E
       call     CORINFO_HELP_ASSIGN_REF
       mov      rax, gword ptr [rbp-0x180]
       mov      gword ptr [rbp-0x178], rax
 
G_M000_IG70:
       mov      ecx, dword ptr [rbp-0x16C]
       mov      rdx, gword ptr [rbp-0x178]
       mov      r8, gword ptr [rbp+0x38]
       mov      r9, gword ptr [rbp+0x28]
       call     [Lokad.Lython.Runtime.LythonRuntime:CreateTuple(int,System.Func`2[int,System.Object],Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.PyTuple]
       mov      rdx, rax
       mov      rcx, bword ptr [rbp-0x168]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       jmp      G_M000_IG72
 
G_M000_IG71:
       mov      rcx, 0xD1FFAB1E
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, 0xD1FFAB1E
       call     CORINFO_HELP_NEWSFAST
       mov      gword ptr [rbp-0x188], rax
       mov      rax, gword ptr [rbp-0xC8]
       mov      rcx, gword ptr [rax+0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.PyList:get_Count():int:this]
       mov      dword ptr [rbp-0x18C], eax
       mov      rcx, gword ptr [rbp-0x188]
       mov      rdx, gword ptr [rbp-0xC8]
       mov      r8, 0xD1FFAB1E
       call     [System.Delegate:CtorClosed(System.Object,nint):this]
       mov      ecx, dword ptr [rbp-0x18C]
       mov      rdx, gword ptr [rbp-0x188]
       mov      r8, gword ptr [rbp+0x38]
       mov      r9, gword ptr [rbp+0x28]
       call     [Lokad.Lython.Runtime.LythonRuntime:CreateTuple(int,System.Func`2[int,System.Object],Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.PyTuple]
       mov      gword ptr [rbp-0xD8], rax
       mov      rax, bword ptr [rbp+0x10]
       mov      eax, dword ptr [rax+0x08]
       cmp      dword ptr [rbp-0xCC], eax
       jae      G_M000_IG83
       mov      rax, bword ptr [rbp+0x10]
       mov      rax, bword ptr [rax]
       mov      ecx, dword ptr [rbp-0xCC]
       lea      rcx, bword ptr [rax+8*rcx]
       mov      rdx, gword ptr [rbp-0xD8]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
 
G_M000_IG72:
       mov      rcx, 0xD1FFAB1E
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp+0x18]
       mov      edx, dword ptr [rbp-0xCC]
       mov      r8d, 1
       call     [Lokad.Lython.Runtime.ArgumentPresence:set_Item(int,bool):this]
 
G_M000_IG73:
       mov      rcx, gword ptr [rbp+0x30]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_VariadicDictionaryIndex():int:this]
       test     eax, eax
       jl       G_M000_IG81
       mov      rcx, 0xD1FFAB1E
       call     CORINFO_HELP_NEWSFAST
       mov      gword ptr [rbp-0x140], rax
       mov      rcx, gword ptr [rbp+0x38]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:get_MemoryGovernor():Lokad.Lython.Runtime.MemoryGovernor:this]
       mov      gword ptr [rbp-0x2C8], rax
       mov      rdx, gword ptr [rbp-0x2C8]
       mov      rcx, gword ptr [rbp-0x140]
       mov      r8, gword ptr [rbp+0x28]
       call     [Lokad.Lython.Runtime.PyDict:.ctor(Lokad.Lython.Runtime.MemoryGovernor,Lokad.Lython.LythonSourceSpan):this]
       mov      rax, gword ptr [rbp-0x140]
       mov      gword ptr [rbp-0xE0], rax
       cmp      gword ptr [rbp-0x48], 0
       je       G_M000_IG80
       lea      rdx, [rbp-0x110]
       mov      rcx, gword ptr [rbp-0x48]
       cmp      dword ptr [rcx], ecx
       call     [System.Collections.Generic.Dictionary`2[System.__Canon,System.__Canon]:GetEnumerator():System.Collections.Generic.Dictionary`2+Enumerator[System.__Canon,System.__Canon]:this]
       nop      
 
G_M000_IG74:
       jmp      G_M000_IG76
 
G_M000_IG75:
       mov      rcx, 0xD1FFAB1E
       call     CORINFO_HELP_COUNTPROFILE32
       lea      rdx, [rbp-0x120]
       lea      rcx, [rbp-0x110]
       mov      r8, 0xD1FFAB1E
       call     [System.Collections.Generic.Dictionary`2+Enumerator[System.__Canon,System.__Canon]:get_Current():System.Collections.Generic.KeyValuePair`2[System.__Canon,System.__Canon]:this]
       lea      rcx, [rbp-0x120]
       mov      rdx, 0xD1FFAB1E
       call     [System.Collections.Generic.KeyValuePair`2[System.__Canon,System.__Canon]:get_Key():System.__Canon:this]
       mov      gword ptr [rbp-0x148], rax
       mov      rcx, gword ptr [rbp+0x38]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:get_MemoryGovernor():Lokad.Lython.Runtime.MemoryGovernor:this]
       mov      gword ptr [rbp-0x2D0], rax
       mov      rdx, gword ptr [rbp-0x2D0]
       mov      rcx, gword ptr [rbp-0x148]
       mov      r8, gword ptr [rbp+0x28]
       call     [Lokad.Lython.Runtime.Text.PyString:FromString(System.String,Lokad.Lython.Runtime.MemoryGovernor,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.Text.PyString]
       mov      gword ptr [rbp-0x128], rax
       lea      rcx, [rbp-0x120]
       mov      rdx, 0xD1FFAB1E
       call     [System.Collections.Generic.KeyValuePair`2[System.__Canon,System.__Canon]:get_Value():System.__Canon:this]
       mov      gword ptr [rbp-0x2D8], rax
       mov      r8, gword ptr [rbp-0x2D8]
       mov      rdx, gword ptr [rbp-0x128]
       mov      rcx, gword ptr [rbp-0xE0]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.PyDict:SetItem(System.Object,System.Object):this]
 
G_M000_IG76:
       mov      eax, dword ptr [rbp-0x22C]
       dec      eax
       mov      dword ptr [rbp-0x22C], eax
       cmp      dword ptr [rbp-0x22C], 0
       jg       SHORT G_M000_IG78
 
G_M000_IG77:
       lea      rcx, [rbp-0x22C]
       mov      edx, 0x480
       call     CORINFO_HELP_PATCHPOINT
       jmp      rax
 
G_M000_IG78:
       lea      rcx, [rbp-0x110]
       mov      rdx, 0xD1FFAB1E
       call     [System.Collections.Generic.Dictionary`2+Enumerator[System.__Canon,System.__Canon]:MoveNext():bool:this]
       test     eax, eax
       jne      G_M000_IG75
       mov      rcx, 0xD1FFAB1E
       call     CORINFO_HELP_COUNTPROFILE32
       nop      
 
G_M000_IG79:
       call     G_M000_IG84
       nop      
 
G_M000_IG80:
       mov      rcx, 0xD1FFAB1E
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, gword ptr [rbp+0x30]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_VariadicDictionaryIndex():int:this]
       mov      dword ptr [rbp-0xE4], eax
       mov      rax, bword ptr [rbp+0x10]
       mov      eax, dword ptr [rax+0x08]
       cmp      dword ptr [rbp-0xE4], eax
       jae      SHORT G_M000_IG83
       mov      rax, bword ptr [rbp+0x10]
       mov      rax, bword ptr [rax]
       mov      ecx, dword ptr [rbp-0xE4]
       lea      rcx, bword ptr [rax+8*rcx]
       mov      rdx, gword ptr [rbp-0xE0]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rcx, bword ptr [rbp+0x18]
       mov      edx, dword ptr [rbp-0xE4]
       mov      r8d, 1
       call     [Lokad.Lython.Runtime.ArgumentPresence:set_Item(int,bool):this]
 
G_M000_IG81:
       mov      rcx, 0xD1FFAB1E
       call     CORINFO_HELP_COUNTPROFILE32
       nop      
 
G_M000_IG82:
       add      rsp, 768
       pop      rbp
       ret      
 
G_M000_IG83:
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG84:
       sub      rsp, 40
 
G_M000_IG85:
       mov      rcx, 0xD1FFAB1E
       call     CORINFO_HELP_COUNTPROFILE32
       lea      rcx, [rbp-0x110]
       mov      rdx, 0xD1FFAB1E
       call     [System.Collections.Generic.Dictionary`2+Enumerator[System.__Canon,System.__Canon]:Dispose():this]
       nop      
 
G_M000_IG86:
       add      rsp, 40
       ret      
 
; Total bytes of code 4537

; Assembly listing for method Lokad.Lython.Runtime.PyExecutableFunction:StartNativeCall(Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[System.Object],System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,bool,bool,System.Span`1[System.Object],byref,byref,byref):this (Tier1)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; Tier1 code
; optimized code
; optimized using Synthesized PGO
; rbp based frame
; partially interruptible
; with Synthesized PGO: fgCalledCount is 30844
; 6 inlinees with PGO data; 20 single block inlinees; 1 inlinees without PGO data

G_M000_IG01:
       push     rbp
       push     r15
       push     r14
       push     r13
       push     r12
       push     rdi
       push     rsi
       push     rbx
       sub      rsp, 376
       lea      rbp, [rsp+0x1B0]
       vxorps   xmm4, xmm4, xmm4
       vmovdqa  xmmword ptr [rbp-0x150], xmm4
       vmovdqa  xmmword ptr [rbp-0x140], xmm4
       mov      rax, -240
 
G_M000_IG15:
       vmovdqa  xmmword ptr [rbp+rax-0x40], xmm4
       vmovdqa  xmmword ptr [rbp+rax-0x30], xmm4
       vmovdqa  xmmword ptr [rbp+rax-0x20], xmm4
       add      rax, 48
       jne      SHORT G_M000_IG15
       mov      qword ptr [rbp-0x40], rax
       mov      rbx, rcx
       mov      rsi, rdx
       mov      rdi, r9
       mov      r15, gword ptr [rbp+0x38]
       mov      r14, bword ptr [rbp+0x50]
 
G_M000_IG02:
       mov      r13, bword ptr [r8]
       mov      r12d, dword ptr [r8+0x08]
       mov      rdx, gword ptr [rbx+0x68]
       mov      eax, dword ptr [rdx+0x9C]
       mov      ecx, dword ptr [rdx+0x98]
       mov      r8d, 4
       cmp      ecx, 4
       cmovg    r8d, ecx
       add      eax, r8d
       jo       G_M000_IG14
       add      eax, dword ptr [rdx+0xA4]
       jo       G_M000_IG14
       cmp      eax, 16
       ja       G_M000_IG08
       mov      dword ptr [rbp-0x104], eax
       mov      r8, gword ptr [rbx+0x08]
       mov      r10, r8
       mov      gword ptr [rbp-0x160], r10
       mov      rdx, gword ptr [r10+0x08]
       mov      r8, gword ptr [rdx+0x08]
       mov      gword ptr [rbp-0x158], r8
       mov      edx, dword ptr [r8+0x08]
       mov      dword ptr [rbp-0xC0], edx
       xor      ecx, ecx
       mov      qword ptr [rbp-0xC8], rcx
       cmp      edx, 64
       jg       G_M000_IG09
       mov      r9, 0xD1FFAB1E
 
G_M000_IG03:
       mov      gword ptr [rbp-0xD0], r9
       cmp      byte  ptr [rbp+0x48], 0
       jne      G_M000_IG10
 
G_M000_IG04:
       mov      r8, gword ptr [rbp-0x158]
       mov      ecx, dword ptr [r8+0x08]
       cmp      ecx, dword ptr [rbp-0x104]
       ja       G_M000_IG08
       lea      r8, bword ptr [rbp-0xB8]
       mov      bword ptr [rbp-0x118], r8
       mov      dword ptr [rbp-0x110], ecx
       xor      rcx, rcx
       mov      bword ptr [rbp-0x128], rcx
 
G_M000_IG05:
       mov      dword ptr [rbp-0x120], ecx
       mov      r10, gword ptr [rbp-0x160]
       mov      rcx, gword ptr [rbp+0x30]
       mov      gword ptr [rsp+0x28], rcx
       xor      ecx, ecx
       mov      dword ptr [rsp+0x30], ecx
       mov      gword ptr [rsp+0x38], rdi
       mov      gword ptr [rsp+0x40], rsi
       mov      bword ptr [rbp-0x138], r13
       mov      dword ptr [rbp-0x130], r12d
       lea      rcx, [rbp-0x118]
       lea      r8, [rbp-0x128]
       mov      gword ptr [rsp+0x20], r10
       lea      rdx, [rbp-0x138]
       mov      qword ptr [rsp+0x48], rdx
       lea      rdx, [rbp-0xD0]
       mov      r9, r15
       call     [Lokad.Lython.Runtime.LythonRuntime:BindFunctionArgumentsInto(System.Span`1[System.Object],byref,System.ReadOnlySpan`1[Lokad.Lython.Runtime.CallArgumentValue],Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.FunctionBindingPlan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,bool,System.Object,Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[System.Object])]
 
G_M000_IG06:
       mov      rdx, gword ptr [rbp-0xD0]
       mov      r8, qword ptr [rbp-0xC8]
       mov      r9d, dword ptr [rbp-0xC0]
       vxorps   ymm0, ymm0, ymm0
       vmovdqu  ymmword ptr [rbp-0x100], ymm0
       vmovdqu  xmmword ptr [rbp-0xE0], xmm0
       lea      rcx, bword ptr [rbp-0xB8]
       mov      bword ptr [rbp-0x118], rcx
       mov      esi, dword ptr [rbp-0x104]
       mov      dword ptr [rbp-0x110], esi
       mov      gword ptr [rbp-0x150], rdx
       mov      qword ptr [rbp-0x148], r8
       mov      dword ptr [rbp-0x140], r9d
       mov      gword ptr [rsp+0x20], r15
       movzx    rdx, byte  ptr [rbp+0x40]
       mov      dword ptr [rsp+0x28], edx
       mov      bword ptr [rsp+0x30], r14
       mov      rsi, bword ptr [rbp+0x58]
       mov      bword ptr [rsp+0x38], rsi
       mov      rsi, bword ptr [rbp+0x60]
       mov      bword ptr [rsp+0x40], rsi
       mov      rsi, bword ptr [rbp+0x68]
       mov      bword ptr [rsp+0x48], rsi
       lea      rdx, [rbp-0x118]
       lea      r8, [rbp-0x150]
       lea      r9, [rbp-0x100]
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.PyExecutableFunction:StartInline(System.Span`1[System.Object],Lokad.Lython.Runtime.ArgumentPresence,System.Nullable`1[Lokad.Lython.Runtime.BoundCallArguments],Lokad.Lython.LythonSourceSpan,bool,System.Span`1[System.Object],byref,byref,byref):this]
       nop      
 
G_M000_IG07:
       add      rsp, 376
       pop      rbx
       pop      rsi
       pop      rdi
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG08:
       call     [System.ThrowHelper:ThrowArgumentOutOfRangeException()]
       int3     
 
G_M000_IG09:
       add      edx, -64
       mov      rcx, 0xD1FFAB1E
       call     CORINFO_HELP_NEWARR_1_VC
       mov      r9, rax
       jmp      G_M000_IG03
 
G_M000_IG10:
       mov      eax, dword ptr [rbp-0x104]
       cmp      r12d, eax
       ja       SHORT G_M000_IG11
       mov      r8d, r12d
       shl      r8, 3
       lea      rcx, bword ptr [rbp-0xB8]
       mov      rdx, r13
       call     [System.Buffer:BulkMoveWithWriteBarrier(byref,byref,nuint)]
       xor      esi, esi
       jmp      SHORT G_M000_IG13
 
G_M000_IG11:
       call     [System.ThrowHelper:ThrowArgumentException_DestinationTooShort()]
       int3     
 
G_M000_IG12:
       lea      rcx, [rbp-0xD0]
       mov      edx, esi
       mov      r8d, 1
       call     [Lokad.Lython.Runtime.ArgumentPresence:set_Item(int,bool):this]
       inc      esi
 
G_M000_IG13:
       cmp      esi, dword ptr [rbp-0xC0]
       jl       SHORT G_M000_IG12
       jmp      G_M000_IG06
 
G_M000_IG14:
       call     CORINFO_HELP_OVERFLOW
       int3     
 
; Total bytes of code 713

; Assembly listing for method Lokad.Lython.Runtime.LythonRuntime:BindFunctionArgumentsInto(System.Span`1[System.Object],byref,System.ReadOnlySpan`1[Lokad.Lython.Runtime.CallArgumentValue],Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.FunctionBindingPlan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,bool,System.Object,Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[System.Object]) (Tier1)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; Tier1 code
; optimized code
; optimized using Synthesized PGO
; rbp based frame
; fully interruptible
; with Synthesized PGO: fgCalledCount is 30908
; 21 inlinees with PGO data; 89 single block inlinees; 1 inlinees without PGO data

G_M000_IG01:
       push     rbp
       push     r15
       push     r14
       push     r13
       push     r12
       push     rdi
       push     rsi
       push     rbx
       sub      rsp, 552
       lea      rbp, [rsp+0x260]
       xor      eax, eax
       mov      qword ptr [rbp-0x128], rax
       vxorps   xmm4, xmm4, xmm4
       vmovdqa  xmmword ptr [rbp-0x120], xmm4
       mov      rax, -192
 
G_M000_IG124:
       vmovdqa  xmmword ptr [rbp+rax-0x50], xmm4
       vmovdqa  xmmword ptr [rbp+rax-0x40], xmm4
       vmovdqa  xmmword ptr [rbp+rax-0x30], xmm4
       add      rax, 48
       jne      SHORT G_M000_IG124
       mov      qword ptr [rbp-0x50], rax
       mov      rbx, rdx
       mov      rdi, r9
       mov      rsi, gword ptr [rbp+0x30]
       mov      r12, gword ptr [rbp+0x38]
       mov      r15, gword ptr [rbp+0x48]
       mov      r14, gword ptr [rbp+0x50]
       mov      rdx, bword ptr [rbp+0x58]
 
G_M000_IG02:
       mov      rax, bword ptr [rdx]
       mov      bword ptr [rbp-0x208], rax
       mov      r10d, dword ptr [rdx+0x08]
       mov      dword ptr [rbp-0x114], r10d
       mov      r9, bword ptr [r8]
       mov      bword ptr [rbp-0x200], r9
       mov      r8d, dword ptr [r8+0x08]
       mov      dword ptr [rbp-0x110], r8d
       mov      r11, bword ptr [rcx]
       mov      bword ptr [rbp-0x1F8], r11
       mov      ecx, dword ptr [rcx+0x08]
       mov      dword ptr [rbp-0x10C], ecx
       xor      rdx, rdx
       mov      gword ptr [rbp-0x148], rdx
       xor      r13, r13
       mov      gword ptr [rbp-0x150], r13
       xor      r13d, r13d
       mov      r9, gword ptr [rsi+0x08]
       cmp      dword ptr [r9+0x28], 0
       jge      G_M000_IG72
       test     r14, r14
       je       G_M000_IG10
 
G_M000_IG03:
       movzx    rdx, byte  ptr [r14+0x34]
 
G_M000_IG04:
       mov      dword ptr [rbp-0x40], edx
       test     edx, edx
       je       G_M000_IG14
 
G_M000_IG05:
       mov      r9d, dword ptr [r9+0x18]
       test     r15, r15
       setne    r8b
       movzx    r8, r8b
       sub      r9d, r8d
       cmp      r9d, r10d
       jl       G_M000_IG73
       test     r15, r15
       jne      G_M000_IG74
 
G_M000_IG06:
       mov      r10d, dword ptr [rbp-0x114]
       test     r10d, r10d
       je       G_M000_IG11
 
G_M000_IG07:
       xor      r8d, r8d
       mov      dword ptr [rbp-0x13C], r10d
 
G_M000_IG08:
       lea      eax, [r13+0x01]
       mov      dword ptr [rbp-0x3C], eax
       cmp      r13d, ecx
       jae      G_M000_IG118
       mov      r13d, r13d
       lea      r13, bword ptr [r11+8*r13]
       mov      r11, bword ptr [rbp-0x208]
       mov      qword ptr [rbp-0x138], r8
       mov      r11, gword ptr [r11+r8]
       test     r11, r11
       je       G_M000_IG75
       mov      rcx, r13
       mov      rdx, r11
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      r13, qword ptr [rbp-0x138]
       add      r13, 8
       mov      r9d, dword ptr [rbp-0x13C]
       dec      r9d
       mov      dword ptr [rbp-0x13C], r9d
       mov      r8, r13
       je       SHORT G_M000_IG12
 
G_M000_IG09:
       mov      ecx, dword ptr [rbp-0x10C]
       mov      r11, bword ptr [rbp-0x1F8]
       mov      r13d, dword ptr [rbp-0x3C]
       jmp      SHORT G_M000_IG08
 
G_M000_IG10:
       test     r8d, r8d
       sete     dl
       movzx    rdx, dl
       mov      r8d, dword ptr [rbp-0x110]
       jmp      G_M000_IG04
 
G_M000_IG11:
       mov      dword ptr [rbp-0x3C], r13d
 
G_M000_IG12:
       xor      ecx, ecx
       mov      r13d, dword ptr [rbp-0x3C]
       test     r13d, r13d
       jg       G_M000_IG68
 
G_M000_IG13:
       mov      ecx, dword ptr [rbp-0x10C]
       mov      r8d, dword ptr [rbp-0x110]
       mov      r10d, dword ptr [rbp-0x114]
       mov      r11, bword ptr [rbp-0x1F8]
 
G_M000_IG14:
       test     r14, r14
       je       G_M000_IG71
 
G_M000_IG15:
       mov      r9d, dword ptr [r14+0x28]
 
G_M000_IG16:
       mov      dword ptr [rbp-0x44], r9d
       xor      r8d, r8d
       mov      eax, -1
       test     r15, r15
       cmovne   r8d, eax
       mov      eax, r8d
 
G_M000_IG17:
       cmp      dword ptr [rbp-0x40], 0
       je       G_M000_IG95
 
G_M000_IG18:
       xor      r14d, r14d
       mov      r8, gword ptr [rsi+0x08]
       cmp      dword ptr [r8+0x18], 0
       jle      SHORT G_M000_IG21
 
G_M000_IG19:
       mov      edx, dword ptr [rbx+0x10]
       cmp      r14d, edx
       jae      G_M000_IG98
       cmp      r14d, 64
       jge      G_M000_IG99
       mov      r8, qword ptr [rbx+0x08]
       bt       r8, r14
       jae      G_M000_IG100
 
G_M000_IG20:
       inc      r14d
       mov      rax, gword ptr [rsi+0x08]
       cmp      r14d, dword ptr [rax+0x18]
       jl       SHORT G_M000_IG19
 
G_M000_IG21:
       xor      r14d, r14d
 
G_M000_IG22:
       movzx    r13, byte  ptr [rbp+0x40]
       test     r13b, r13b
       jne      G_M000_IG65
 
G_M000_IG23:
       mov      r15, gword ptr [rsi+0x08]
       cmp      r14d, dword ptr [r15+0x1C]
       jge      G_M000_IG65
 
G_M000_IG24:
       mov      eax, r14d
       add      eax, dword ptr [r15+0x18]
       mov      edx, eax
       mov      dword ptr [rbp-0x74], edx
       mov      r8d, dword ptr [rbx+0x10]
       cmp      edx, r8d
       jae      G_M000_IG102
       cmp      edx, 64
       jge      G_M000_IG103
       mov      r8, qword ptr [rbx+0x08]
       bt       r8, rdx
       jb       G_M000_IG64
 
G_M000_IG25:
       mov      r8, gword ptr [r15+0x08]
       cmp      eax, dword ptr [r8+0x08]
       jae      G_M000_IG118
       mov      eax, eax
       mov      r15, gword ptr [r8+8*rax+0x10]
       mov      gword ptr [rbp-0x160], r15
       mov      rcx, rsi
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_KeywordDefaultStorage():Lokad.Lython.Runtime.PyDict:this]
       mov      gword ptr [rbp-0x168], rax
       test     rax, rax
       mov      r15, gword ptr [rbp-0x160]
       je       G_M000_IG108
       mov      rcx, gword ptr [rsi+0x28]
       cmp      r14d, dword ptr [rcx+0x08]
       jae      G_M000_IG118
       mov      r10, gword ptr [rcx+8*r14+0x10]
       mov      gword ptr [rbp-0x1A8], r10
       cmp      gword ptr [rax+0x28], 0
       je       G_M000_IG104
       test     r10, r10
       je       G_M000_IG106
       mov      r10, gword ptr [rbp-0x1A8]
       cmp      dword ptr [rax+0x50], 0
       setne    cl
       movzx    rcx, cl
       test     ecx, ecx
       jne      G_M000_IG105
 
G_M000_IG26:
       mov      rax, gword ptr [rbp-0x168]
       xor      r9, r9
       xor      r11, r11
       xor      r8d, r8d
 
G_M000_IG27:
       mov      gword ptr [rbp-0x210], r9
       mov      gword ptr [rbp-0x218], r11
       mov      byte  ptr [rbp-0x118], r8b
 
G_M000_IG28:
       mov      rcx, rax
       mov      rdx, r10
       mov      r8, r12
       mov      r9, rdi
       call     [Lokad.Lython.Runtime.PyDict:PrepareQueryKey(System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):System.ValueTuple`2[uint,bool]:this]
       mov      qword ptr [rbp-0xE0], rax
       mov      eax, dword ptr [rbp-0xE0]
       mov      dword ptr [rbp-0xE4], eax
       movzx    rdx, byte  ptr [rbp-0xDC]
       mov      dword ptr [rbp-0xE8], edx
       mov      r8, gword ptr [rbp-0x168]
       cmp      gword ptr [r8+0x28], 0
       je       G_M000_IG40
       cmp      dword ptr [r8+0x50], 0
       jne      G_M000_IG53
 
G_M000_IG29:
       cmp      dword ptr [rbp-0xE8], 0
       jne      G_M000_IG53
       mov      r10, gword ptr [r8+0x28]
       mov      gword ptr [rbp-0x1B0], r10
       cmp      dword ptr [r8+0x4C], 0
       je       G_M000_IG52
 
G_M000_IG30:
       mov      r9d, dword ptr [r10+0x08]
       mov      dword ptr [rbp-0x12C], r9d
       mov      ecx, r9d
       blsr     edx, ecx
       jne      G_M000_IG41
       dec      ecx
       and      ecx, dword ptr [rbp-0xE0]
 
G_M000_IG31:
       cmp      ecx, r9d
       jae      G_M000_IG58
       mov      ecx, ecx
       lea      rcx, [rcx+4*rcx]
       mov      edx, dword ptr [r10+8*rcx+0x30]
       dec      edx
       js       G_M000_IG52
 
G_M000_IG32:
       cmp      edx, r9d
       jae      G_M000_IG58
       mov      ecx, edx
       lea      rcx, [rcx+4*rcx]
       lea      r11, bword ptr [r10+8*rcx+0x10]
       mov      bword ptr [rbp-0x1B8], r11
       cmp      gword ptr [r8+0x20], 0
       jne      G_M000_IG42
 
G_M000_IG33:
       mov      eax, dword ptr [rbp-0xE4]
       cmp      dword ptr [r11+0x18], eax
       jne      G_M000_IG43
       mov      rcx, 0xD1FFAB1E
       mov      rcx, gword ptr [rcx]
       mov      gword ptr [rbp-0x1C0], rcx
       mov      rcx, gword ptr [r11]
       mov      gword ptr [rbp-0x1C8], rcx
       mov      rax, r12
       test     rax, rax
       je       G_M000_IG44
 
G_M000_IG34:
       mov      rcx, rdi
       test     rcx, rcx
       je       G_M000_IG45
 
G_M000_IG35:
       mov      r15, gword ptr [rbp-0x1A8]
       cmp      gword ptr [rbp-0x1C8], r15
       jne      G_M000_IG46
       test     r15, r15
       mov      r11, bword ptr [rbp-0x1B8]
       mov      r15, gword ptr [rbp-0x160]
       je       G_M000_IG43
 
G_M000_IG36:
       mov      eax, edx
 
G_M000_IG37:
       test     eax, eax
       jl       G_M000_IG60
       mov      r10, gword ptr [r8+0x30]
       test     r10, r10
       je       G_M000_IG59
       cmp      gword ptr [r8+0x20], 0
       jne      G_M000_IG57
       mov      gword ptr [rbp-0x1E0], r10
       cmp      eax, dword ptr [r10+0x08]
       jae      G_M000_IG58
       mov      edx, eax
       mov      r9, gword ptr [r10+8*rdx+0x10]
       test     r9, r9
       je       G_M000_IG56
 
G_M000_IG38:
       mov      rcx, r9
 
G_M000_IG39:
       mov      gword ptr [rbp-0x80], rcx
       not      eax
       shr      eax, 31
       mov      dword ptr [rbp-0xEC], eax
       jmp      G_M000_IG61
 
G_M000_IG40:
       mov      rcx, gword ptr [r8+0x08]
       mov      r11, 0xD1FFAB1E
       call     [r11]Lokad.Lython.Runtime.IPyDictStorage:get_HasProtocolKeys():bool:this
       test     eax, eax
       mov      r8, gword ptr [rbp-0x168]
       jne      G_M000_IG53
       jmp      G_M000_IG29
 
G_M000_IG41:
       mov      eax, dword ptr [rbp-0xE0]
       xor      edx, edx
       div      edx:eax, ecx
       mov      ecx, edx
       jmp      G_M000_IG31
 
G_M000_IG42:
       mov      rcx, gword ptr [r8+0x30]
       cmp      dword ptr [rcx+0x08], edx
       jbe      SHORT G_M000_IG43
       mov      rcx, gword ptr [r8+0x30]
       mov      gword ptr [rbp-0x228], rcx
       cmp      edx, dword ptr [rcx+0x08]
       jae      G_M000_IG58
       mov      dword ptr [rbp-0xF4], edx
       mov      ecx, edx
       mov      rax, gword ptr [rbp-0x228]
       cmp      gword ptr [rax+8*rcx+0x10], 0
       setne    cl
       movzx    rcx, cl
       test     ecx, ecx
       mov      edx, dword ptr [rbp-0xF4]
       mov      r8, gword ptr [rbp-0x168]
       jne      G_M000_IG33
 
G_M000_IG43:
       mov      rdx, rdi
       test     rdx, rdx
       je       G_M000_IG50
       jmp      G_M000_IG51
 
G_M000_IG44:
       mov      dword ptr [rbp-0xF4], edx
       mov      ecx, 12
       call     [CORINFO_HELP_GETDYNAMIC_GCTHREADSTATIC_BASE_NOCTOR_OPTIMIZED]
       mov      rax, gword ptr [rax+0x18]
       mov      edx, dword ptr [rbp-0xF4]
       mov      r8, gword ptr [rbp-0x168]
       jmp      G_M000_IG34
 
G_M000_IG45:
       mov      rcx, gword ptr [r8+0x18]
       mov      gword ptr [rbp-0x1D8], rcx
       mov      rcx, gword ptr [rbp-0x1D8]
       mov      r8, gword ptr [rbp-0x168]
       jmp      G_M000_IG35
 
G_M000_IG46:
       mov      gword ptr [rbp-0x1D0], rax
       test     rax, rax
       mov      dword ptr [rbp-0xF4], edx
       mov      gword ptr [rbp-0x1D8], rcx
       je       SHORT G_M000_IG47
       mov      rdx, gword ptr [rbp-0x1C8]
       mov      rcx, 0xD1FFAB1E
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG47
       mov      rdx, r15
       test     rdx, rdx
       jne      SHORT G_M000_IG48
 
G_M000_IG47:
       mov      rcx, gword ptr [rbp-0x1C0]
       mov      rdx, gword ptr [rbp-0x1C8]
       mov      r8, r15
       call     [Lokad.Lython.Runtime.PyValueComparer:Equals(System.Object,System.Object):bool:this]
       jmp      SHORT G_M000_IG49
 
G_M000_IG48:
       mov      rcx, rax
       mov      r8, gword ptr [rbp-0x1D0]
       mov      r9, gword ptr [rbp-0x1D8]
       call     [Lokad.Lython.Runtime.Text.PyString:Equals(Lokad.Lython.Runtime.Text.PyString,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):bool:this]
 
G_M000_IG49:
       test     eax, eax
       mov      edx, dword ptr [rbp-0xF4]
       mov      r8, gword ptr [rbp-0x168]
       mov      r11, bword ptr [rbp-0x1B8]
       mov      r15, gword ptr [rbp-0x160]
       je       G_M000_IG43
       jmp      G_M000_IG36
 
G_M000_IG50:
       mov      rdx, gword ptr [r8+0x18]
 
G_M000_IG51:
       mov      rcx, r12
       call     [Lokad.Lython.Runtime.PyStructuralGuard:NoteWork(Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan)]
       mov      rcx, bword ptr [rbp-0x1B8]
       mov      edx, dword ptr [rcx+0x1C]
       dec      edx
       mov      eax, edx
       test     eax, eax
       mov      edx, eax
       mov      r8, gword ptr [rbp-0x168]
       mov      r9d, dword ptr [rbp-0x12C]
       mov      r10, gword ptr [rbp-0x1B0]
       jge      G_M000_IG32
 
G_M000_IG52:
       mov      eax, -1
       jmp      G_M000_IG37
 
G_M000_IG53:
       test     r12, r12
       jne      SHORT G_M000_IG55
       mov      rcx, r8
       mov      rdx, gword ptr [rbp-0x1A8]
       call     [Lokad.Lython.Runtime.PyDict:FindNativeIdentity(System.Object):int:this]
       test     eax, eax
       jge      SHORT G_M000_IG54
       xor      rcx, rcx
       mov      gword ptr [rsp+0x20], rcx
       mov      rcx, gword ptr [rbp-0x168]
       mov      rdx, gword ptr [rbp-0x1A8]
       mov      r8d, dword ptr [rbp-0xE0]
       xor      r9, r9
       call     [Lokad.Lython.Runtime.PyDict:FindNativeIndex(System.Object,uint,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):int:this]
       mov      r8, gword ptr [rbp-0x168]
       jmp      G_M000_IG37
 
G_M000_IG54:
       mov      r8, gword ptr [rbp-0x168]
       jmp      G_M000_IG37
 
G_M000_IG55:
       mov      gword ptr [rsp+0x20], r12
       mov      gword ptr [rsp+0x28], rdi
       xor      ecx, ecx
       mov      dword ptr [rsp+0x30], ecx
       mov      rcx, r8
       mov      rdx, gword ptr [rbp-0x1A8]
       mov      r8d, dword ptr [rbp-0xE0]
       mov      r9d, dword ptr [rbp-0xE8]
       call     [Lokad.Lython.Runtime.PyDict:ResolveContextualKey(System.Object,uint,bool,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,bool):int:this]
       mov      r8, gword ptr [rbp-0x168]
       jmp      G_M000_IG37
 
G_M000_IG56:
       vxorps   xmm0, xmm0, xmm0
       vmovdqu  xmmword ptr [rbp-0x108], xmm0
       mov      rdx, gword ptr [r8+0x28]
       cmp      eax, dword ptr [rdx+0x08]
       jae      G_M000_IG58
       mov      dword ptr [rbp-0xF0], eax
       mov      ecx, eax
       lea      rcx, [rcx+4*rcx]
       mov      rdx, qword ptr [rdx+8*rcx+0x20]
       lea      rcx, [rbp-0x108]
       call     [System.Numerics.BigInteger:.ctor(long):this]
       mov      rcx, 0xD1FFAB1E
       call     CORINFO_HELP_NEWSFAST
       mov      gword ptr [rbp-0x1E8], rax
       lea      rcx, bword ptr [rax+0x08]
       mov      rdx, gword ptr [rbp-0x108]
       call     CORINFO_HELP_ASSIGN_REF
       mov      edx, dword ptr [rbp-0x100]
       mov      rax, gword ptr [rbp-0x1E8]
       mov      dword ptr [rax+0x10], edx
       mov      gword ptr [rbp-0x1F0], rax
       mov      edx, dword ptr [rbp-0xF0]
       mov      rcx, gword ptr [rbp-0x1E0]
       mov      r8, rax
       call     CORINFO_HELP_ARRADDR_ST
       mov      rcx, gword ptr [rbp-0x1F0]
       mov      eax, dword ptr [rbp-0xF0]
       jmp      G_M000_IG39
 
G_M000_IG57:
       mov      rcx, r10
       cmp      eax, dword ptr [rcx+0x08]
       jae      SHORT G_M000_IG58
       mov      edx, eax
       mov      rcx, gword ptr [rcx+8*rdx+0x10]
       jmp      G_M000_IG39
 
G_M000_IG58:
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG59:
       mov      rcx, 0xD1FFAB1E
       mov      r9, gword ptr [rcx]
       jmp      G_M000_IG38
 
G_M000_IG60:
       mov      rcx, 0xD1FFAB1E
       mov      rcx, gword ptr [rcx]
       jmp      G_M000_IG39
 
G_M000_IG61:
       cmp      byte  ptr [rbp-0x118], 0
       jne      G_M000_IG107
 
G_M000_IG62:
       mov      eax, dword ptr [rbp-0xEC]
 
G_M000_IG63:
       test     eax, eax
       je       G_M000_IG108
       mov      r15d, dword ptr [rbp-0x74]
       cmp      r15d, dword ptr [rbp-0x10C]
       jae      G_M000_IG118
       mov      ecx, r15d
       mov      r15, bword ptr [rbp-0x1F8]
       lea      rcx, bword ptr [r15+8*rcx]
       mov      rdx, gword ptr [rbp-0x80]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      r11, r15
       mov      ecx, dword ptr [rbp-0x10C]
 
G_M000_IG64:
       inc      r14d
       mov      dword ptr [rbp+0x40], r13d
       jmp      G_M000_IG22
 
G_M000_IG65:
       mov      r15, gword ptr [rsi+0x08]
       cmp      dword ptr [r15+0x28], 0
       jge      G_M000_IG109
 
G_M000_IG66:
       mov      rax, gword ptr [rsi+0x08]
       cmp      dword ptr [rax+0x2C], 0
       jge      G_M000_IG114
 
G_M000_IG67:
       add      rsp, 552
       pop      rbx
       pop      rsi
       pop      rdi
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG68:
       mov      edx, dword ptr [rbx+0x10]
       cmp      ecx, edx
       jae      G_M000_IG76
       cmp      ecx, 64
       jge      G_M000_IG77
       mov      rdx, qword ptr [rbx+0x08]
       bts      rdx, rcx
       mov      qword ptr [rbx+0x08], rdx
 
G_M000_IG69:
       inc      ecx
       cmp      ecx, r13d
       jl       SHORT G_M000_IG68
 
G_M000_IG70:
       mov      ecx, dword ptr [rbp-0x10C]
       mov      r8d, dword ptr [rbp-0x110]
       mov      r10d, dword ptr [rbp-0x114]
       mov      r11, bword ptr [rbp-0x1F8]
       jmp      G_M000_IG14
 
G_M000_IG71:
       test     r8d, r8d
       mov      r9d, r8d
       cmove    r9d, r10d
       jmp      G_M000_IG16
 
G_M000_IG72:
       xor      edx, edx
       jmp      G_M000_IG04
 
G_M000_IG73:
       mov      ecx, dword ptr [rsi+0x30]
       mov      rdx, gword ptr [rsi+0x10]
       mov      r8, rdi
       call     [Lokad.Lython.Runtime.CallErrors:TooManyPositional(int,System.String,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.LythonRuntimeException]
       mov      rcx, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG74:
       mov      r13d, 1
       test     ecx, ecx
       je       G_M000_IG118
       mov      rcx, r11
       mov      rdx, r15
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      ecx, dword ptr [rbp-0x10C]
       mov      r11, bword ptr [rbp-0x1F8]
       jmp      G_M000_IG06
 
G_M000_IG75:
       mov      rcx, 0xD1FFAB1E
       call     CORINFO_HELP_NEWSFAST
       mov      rbx, rax
       mov      rcx, rbx
       mov      rdx, 0xD1FFAB1E
       call     [System.InvalidOperationException:.ctor(System.String):this]
       mov      rcx, rbx
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG76:
       mov      r8, 0xD1FFAB1E
       call     [System.ArgumentOutOfRangeException:ThrowGreaterEqual[uint](uint,uint,System.String)]
       int3     
 
G_M000_IG77:
       mov      rdx, gword ptr [rbx]
       lea      r8d, [rcx-0x40]
       cmp      r8d, dword ptr [rdx+0x08]
       jae      G_M000_IG118
       lea      r8d, [rcx-0x40]
       mov      byte  ptr [rdx+r8+0x10], 1
       jmp      G_M000_IG69
 
G_M000_IG78:
       test     eax, eax
       jl       G_M000_IG85
       test     r14, r14
       je       SHORT G_M000_IG81
       mov      r8, gword ptr [r14+0x08]
       mov      gword ptr [rbp-0x220], r8
       cmp      eax, dword ptr [r8+0x08]
       jae      G_M000_IG118
       mov      r8d, eax
       shl      r8, 4
 
G_M000_IG79:
       mov      r9, gword ptr [rbp-0x220]
       vmovdqu  xmm0, xmmword ptr [r9+r8+0x10]
       vmovdqu  xmmword ptr [rbp-0x128], xmm0
 
G_M000_IG80:
       cmp      eax, r10d
       jae      G_M000_IG118
       mov      dword ptr [rbp-0x48], eax
       mov      r8d, eax
       mov      r9, bword ptr [rbp-0x208]
       mov      rdx, gword ptr [r9+8*r8]
       mov      rcx, 0xD1FFAB1E
       call     [Lokad.Lython.Internal.NullabilityExtensions:RequireNotNull[System.__Canon](System.__Canon):System.__Canon]
       mov      r8, rax
       lea      rdx, [rbp-0x128]
       lea      rcx, [rbp-0xC0]
       call     [Lokad.Lython.Runtime.LythonRuntime:CreateExecutableCallArgument(Lokad.Lython.Frontend.CallArgumentForm,System.Object):Lokad.Lython.Runtime.CallArgumentValue]
       jmp      G_M000_IG86
 
G_M000_IG81:
       mov      r8d, dword ptr [rbp-0x110]
       test     r8d, r8d
       je       SHORT G_M000_IG84
       cmp      eax, r8d
       jae      G_M000_IG118
       mov      dword ptr [rbp-0x48], eax
       mov      eax, eax
       lea      rax, [rax+2*rax]
 
G_M000_IG82:
       mov      r8, bword ptr [rbp-0x200]
       vmovdqu  xmm0, xmmword ptr [r8+8*rax]
       vmovdqu  xmmword ptr [rbp-0xC0], xmm0
       mov      r9, qword ptr [r8+8*rax+0x10]
       mov      qword ptr [rbp-0xB0], r9
 
G_M000_IG83:
       jmp      SHORT G_M000_IG86
 
G_M000_IG84:
       cmp      eax, r10d
       jae      G_M000_IG118
       mov      dword ptr [rbp-0x48], eax
       mov      eax, eax
       mov      r9, bword ptr [rbp-0x208]
       mov      rdx, gword ptr [r9+8*rax]
       mov      rcx, 0xD1FFAB1E
       call     [Lokad.Lython.Internal.NullabilityExtensions:RequireNotNull[System.__Canon](System.__Canon):System.__Canon]
       mov      rdx, rax
       lea      rcx, [rbp-0xC0]
       call     [Lokad.Lython.Runtime.CallArgumentValue:Positional(System.Object):Lokad.Lython.Runtime.CallArgumentValue]
       jmp      SHORT G_M000_IG86
 
G_M000_IG85:
       mov      dword ptr [rbp-0x48], eax
       lea      rcx, [rbp-0xC0]
       mov      rdx, r15
       call     [Lokad.Lython.Runtime.CallArgumentValue:Positional(System.Object):Lokad.Lython.Runtime.CallArgumentValue]
 
G_M000_IG86:
       vmovdqu  xmm0, xmmword ptr [rbp-0xC0]
       vmovdqu  xmmword ptr [rbp-0x60], xmm0
       mov      rcx, qword ptr [rbp-0xB0]
       mov      qword ptr [rbp-0x50], rcx
 
G_M000_IG87:
       cmp      dword ptr [rbp-0x50], 0
       jne      G_M000_IG90
       mov      rcx, gword ptr [rsi+0x08]
       cmp      r13d, dword ptr [rcx+0x18]
       jl       G_M000_IG89
       mov      rcx, gword ptr [rsi+0x08]
       cmp      dword ptr [rcx+0x28], 0
       jl       G_M000_IG73
       mov      rax, gword ptr [rbp-0x148]
       test     rax, rax
       jne      SHORT G_M000_IG88
       mov      rcx, 0xD1FFAB1E
       mov      rax, gword ptr [rcx]
       mov      gword ptr [rbp-0x190], rax
       mov      rdx, gword ptr [r12+0xA0]
       mov      gword ptr [rbp-0x1A0], rdx
       mov      rcx, 0xD1FFAB1E
       call     CORINFO_HELP_NEWSFAST
       mov      gword ptr [rbp-0x198], rax
       mov      r8, gword ptr [rbp-0x1A0]
       mov      r8, gword ptr [r8+0x88]
       mov      rcx, rax
       mov      rdx, gword ptr [rbp-0x190]
       mov      r9, rdi
       call     [Lokad.Lython.Runtime.PyList:.ctor(System.Collections.Generic.IEnumerable`1[System.Object],Lokad.Lython.Runtime.MemoryGovernor,Lokad.Lython.LythonSourceSpan):this]
       mov      rax, gword ptr [rbp-0x198]
 
G_M000_IG88:
       mov      gword ptr [rbp-0x148], rax
       mov      rcx, rax
       mov      rdx, gword ptr [rbp-0x58]
       call     [Lokad.Lython.Runtime.PyList:Add(System.Object):this]
       jmp      G_M000_IG94
 
G_M000_IG89:
       cmp      r13d, dword ptr [rbp-0x10C]
       jae      G_M000_IG118
       mov      ecx, r13d
       mov      r8, bword ptr [rbp-0x1F8]
       lea      rcx, bword ptr [r8+8*rcx]
       mov      rdx, gword ptr [rbp-0x58]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rcx, rbx
       mov      edx, r13d
       mov      r8d, 1
       call     [Lokad.Lython.Runtime.ArgumentPresence:set_Item(int,bool):this]
       inc      r13d
       jmp      G_M000_IG94
 
G_M000_IG90:
       lea      rcx, [rbp-0x60]
       call     [Lokad.Lython.Runtime.CallArgumentValue:get_KeywordName():System.String:this]
       mov      gword ptr [rbp-0x158], rax
       mov      rcx, gword ptr [rsi+0x08]
       mov      rcx, gword ptr [rcx+0x10]
       lea      r8, [rbp-0x68]
       mov      rdx, rax
       mov      r11, 0xD1FFAB1E
       call     [r11]System.Collections.Generic.IReadOnlyDictionary`2[System.__Canon,int]:TryGetValue(System.__Canon,byref):bool:this
       test     eax, eax
       je       SHORT G_M000_IG91
       mov      ecx, dword ptr [rbp-0x68]
       mov      rdx, gword ptr [rsi+0x08]
       cmp      ecx, dword ptr [rdx+0x20]
       jge      SHORT G_M000_IG91
       mov      ecx, dword ptr [rbp-0x68]
       mov      rdx, gword ptr [rsi+0x08]
       cmp      ecx, dword ptr [rdx+0x24]
       jge      SHORT G_M000_IG93
 
G_M000_IG91:
       mov      rcx, gword ptr [rsi+0x08]
       cmp      dword ptr [rcx+0x2C], 0
       jl       G_M000_IG96
       mov      rax, gword ptr [rbp-0x150]
       test     rax, rax
       jne      SHORT G_M000_IG92
       mov      rcx, 0xD1FFAB1E
       call     CORINFO_HELP_NEWSFAST
       mov      gword ptr [rbp-0x188], rax
       mov      r8, 0xD1FFAB1E
       mov      r8, gword ptr [r8]
       mov      rcx, rax
       xor      edx, edx
       call     [System.Collections.Generic.Dictionary`2[System.__Canon,System.__Canon]:.ctor(int,System.Collections.Generic.IEqualityComparer`1[System.__Canon]):this]
       mov      rax, gword ptr [rbp-0x188]
 
G_M000_IG92:
       mov      r8, gword ptr [rbp-0x58]
       mov      gword ptr [rbp-0x150], rax
       mov      rcx, rax
       mov      rdx, gword ptr [rbp-0x158]
       xor      r9d, r9d
       call     [System.Collections.Generic.Dictionary`2[System.__Canon,System.__Canon]:TryInsert(System.__Canon,System.__Canon,byte):bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG94
       jmp      G_M000_IG97
 
G_M000_IG93:
       mov      rcx, rbx
       mov      edx, dword ptr [rbp-0x68]
       call     [Lokad.Lython.Runtime.ArgumentPresence:get_Item(int):bool:this]
       test     eax, eax
       jne      G_M000_IG97
       mov      eax, dword ptr [rbp-0x10C]
       cmp      dword ptr [rbp-0x68], eax
       jae      G_M000_IG118
       mov      ecx, dword ptr [rbp-0x68]
       mov      r8, bword ptr [rbp-0x1F8]
       lea      rcx, bword ptr [r8+8*rcx]
       mov      rdx, gword ptr [rbp-0x58]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rcx, rbx
       mov      edx, dword ptr [rbp-0x68]
       mov      r8d, 1
       call     [Lokad.Lython.Runtime.ArgumentPresence:set_Item(int,bool):this]
 
G_M000_IG94:
       mov      eax, dword ptr [rbp-0x48]
       inc      eax
       mov      ecx, dword ptr [rbp-0x10C]
       mov      r9d, dword ptr [rbp-0x44]
       mov      r10d, dword ptr [rbp-0x114]
       mov      r11, bword ptr [rbp-0x1F8]
       jmp      G_M000_IG17
 
G_M000_IG95:
       cmp      eax, r9d
       jl       G_M000_IG78
       jmp      G_M000_IG18
 
G_M000_IG96:
       mov      ecx, dword ptr [rsi+0x30]
       mov      rdx, gword ptr [rsi+0x10]
       mov      r8, gword ptr [rbp-0x158]
       mov      r9, rdi
       call     [Lokad.Lython.Runtime.CallErrors:UnexpectedKeyword(int,System.String,System.String,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.LythonRuntimeException]
       mov      rcx, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG97:
       mov      ecx, dword ptr [rsi+0x30]
       mov      rdx, gword ptr [rsi+0x10]
       mov      r8, gword ptr [rbp-0x158]
       mov      r9, rdi
       call     [Lokad.Lython.Runtime.CallErrors:MultipleValues(int,System.String,System.String,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.LythonRuntimeException]
       mov      rcx, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG98:
       mov      ecx, r14d
       mov      r8, 0xD1FFAB1E
       call     [System.ArgumentOutOfRangeException:ThrowGreaterEqual[uint](uint,uint,System.String)]
       int3     
 
G_M000_IG99:
       mov      r8, gword ptr [rbx]
       lea      edx, [r14-0x40]
       cmp      edx, dword ptr [r8+0x08]
       jae      G_M000_IG118
       lea      edx, [r14-0x40]
       movzx    r8, byte  ptr [r8+rdx+0x10]
       test     r8d, r8d
       jne      G_M000_IG20
 
G_M000_IG100:
       mov      r8, gword ptr [rsi+0x08]
       mov      r8, gword ptr [r8+0x08]
       cmp      r14d, dword ptr [r8+0x08]
       jae      G_M000_IG118
       mov      r15, gword ptr [r8+8*r14+0x10]
       lea      r8, [rbp-0x70]
       mov      rcx, rsi
       mov      edx, r14d
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:TryGetPositionalDefault(int,byref):bool:this]
       test     eax, eax
       je       SHORT G_M000_IG101
       cmp      r14d, dword ptr [rbp-0x10C]
       jae      G_M000_IG118
       mov      r13, bword ptr [rbp-0x1F8]
       lea      rcx, bword ptr [r13+8*r14]
       mov      rdx, gword ptr [rbp-0x70]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      ecx, dword ptr [rbp-0x10C]
       mov      r11, bword ptr [rbp-0x1F8]
       jmp      G_M000_IG20
 
G_M000_IG101:
       mov      ecx, dword ptr [rsi+0x30]
       mov      rdx, gword ptr [rsi+0x10]
       mov      r8, r15
       mov      r9, rdi
       call     [Lokad.Lython.Runtime.CallErrors:MissingArgument(int,System.String,System.String,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.LythonRuntimeException]
       mov      rcx, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG102:
       mov      ecx, edx
       mov      edx, r8d
       mov      r8, 0xD1FFAB1E
       call     [System.ArgumentOutOfRangeException:ThrowGreaterEqual[uint](uint,uint,System.String)]
       int3     
 
G_M000_IG103:
       mov      r8, gword ptr [rbx]
       lea      r10d, [rdx-0x40]
       cmp      r10d, dword ptr [r8+0x08]
       jae      G_M000_IG118
       lea      r10d, [rdx-0x40]
       movzx    r8, byte  ptr [r8+r10+0x10]
       test     r8d, r8d
       jne      G_M000_IG64
       jmp      G_M000_IG25
 
G_M000_IG104:
       lea      rcx, [rbp-0x80]
       mov      qword ptr [rsp+0x20], rcx
       mov      rcx, rax
       mov      rdx, r10
       mov      r8, r12
       mov      r9, rdi
       call     [Lokad.Lython.Runtime.PyDict:TryGetBridgeValue(System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,byref):bool:this]
       jmp      G_M000_IG63
 
G_M000_IG105:
       lea      rcx, [rbp-0xD8]
       mov      rdx, r12
       mov      r8, rdi
       call     [Lokad.Lython.Runtime.PyStructuralGuard:PushAmbient(Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.PyStructuralGuard+AmbientScope]
       mov      r9, gword ptr [rbp-0xD8]
       mov      r11, gword ptr [rbp-0xD0]
       movzx    r8, byte  ptr [rbp-0xC8]
       mov      rax, gword ptr [rbp-0x168]
       mov      r10, gword ptr [rbp-0x1A8]
       jmp      G_M000_IG27
 
G_M000_IG106:
       jmp      SHORT G_M000_IG105
 
G_M000_IG107:
       mov      ecx, 12
       call     [CORINFO_HELP_GETDYNAMIC_GCTHREADSTATIC_BASE_NOCTOR_OPTIMIZED]
       lea      rcx, bword ptr [rax+0x18]
       mov      rdx, gword ptr [rbp-0x210]
       call     CORINFO_HELP_ASSIGN_REF
       mov      ecx, 12
       call     [CORINFO_HELP_GETDYNAMIC_GCTHREADSTATIC_BASE_NOCTOR_OPTIMIZED]
       lea      rcx, bword ptr [rax+0x20]
       mov      rdx, gword ptr [rbp-0x218]
       call     CORINFO_HELP_ASSIGN_REF
       jmp      G_M000_IG62
 
G_M000_IG108:
       mov      ecx, dword ptr [rsi+0x30]
       mov      rdx, gword ptr [rsi+0x10]
       mov      r8, r15
       mov      r9, rdi
       call     [Lokad.Lython.Runtime.CallErrors:MissingArgument(int,System.String,System.String,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.LythonRuntimeException]
       mov      rcx, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG109:
       mov      rcx, 0xD1FFAB1E
       call     CORINFO_HELP_NEWSFAST
       mov      r14, rax
       mov      r15d, dword ptr [r15+0x28]
       lea      rcx, bword ptr [r14+0x08]
       mov      rdx, gword ptr [rbp-0x148]
       call     CORINFO_HELP_ASSIGN_REF
       cmp      gword ptr [r14+0x08], 0
       je       SHORT G_M000_IG110
       mov      rcx, gword ptr [r14+0x08]
       cmp      dword ptr [rcx+0x28], 0
       jne      G_M000_IG112
 
G_M000_IG110:
       cmp      r15d, dword ptr [rbp-0x10C]
       jae      G_M000_IG118
       mov      ecx, r15d
       mov      r13, bword ptr [rbp-0x1F8]
       lea      rax, bword ptr [r13+8*rcx]
       mov      bword ptr [rbp-0x170], rax
       mov      rcx, 0xD1FFAB1E
       mov      rdx, gword ptr [rcx]
       test     rdx, rdx
       jne      SHORT G_M000_IG111
       mov      rcx, 0xD1FFAB1E
       call     CORINFO_HELP_NEWSFAST
       mov      gword ptr [rbp-0x178], rax
       mov      rcx, 0xD1FFAB1E
       mov      rdx, gword ptr [rcx]
       mov      rcx, gword ptr [rbp-0x178]
       mov      r8, 0xD1FFAB1E
       call     [System.Delegate:CtorClosed(System.Object,nint):this]
       mov      rcx, 0xD1FFAB1E
       mov      rdx, gword ptr [rbp-0x178]
       call     CORINFO_HELP_ASSIGN_REF
       mov      rdx, gword ptr [rbp-0x178]
 
G_M000_IG111:
       mov      r9, rdi
       mov      r8, r12
       xor      ecx, ecx
       call     [Lokad.Lython.Runtime.LythonRuntime:CreateTuple(int,System.Func`2[int,System.Object],Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.PyTuple]
       mov      rdx, rax
       mov      rcx, bword ptr [rbp-0x170]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       jmp      SHORT G_M000_IG113
 
G_M000_IG112:
       mov      r13, gword ptr [r14+0x08]
       mov      rcx, 0xD1FFAB1E
       call     CORINFO_HELP_NEWSFAST
       mov      gword ptr [rbp-0x180], rax
       mov      r13d, dword ptr [r13+0x28]
       mov      rcx, rax
       mov      rdx, r14
       mov      r8, 0xD1FFAB1E
       call     [System.Delegate:CtorClosed(System.Object,nint):this]
       mov      ecx, r13d
       mov      rdx, gword ptr [rbp-0x180]
       mov      r8, r12
       mov      r9, rdi
       call     [Lokad.Lython.Runtime.LythonRuntime:CreateTuple(int,System.Func`2[int,System.Object],Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.PyTuple]
       mov      r14d, dword ptr [rbp-0x10C]
       cmp      r15d, r14d
       jae      G_M000_IG118
       mov      ecx, r15d
       mov      r13, bword ptr [rbp-0x1F8]
       lea      rcx, bword ptr [r13+8*rcx]
       mov      rdx, rax
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
 
G_M000_IG113:
       mov      rcx, rbx
       mov      edx, r15d
       mov      r8d, 1
       call     [Lokad.Lython.Runtime.ArgumentPresence:set_Item(int,bool):this]
       mov      ecx, dword ptr [rbp-0x10C]
       mov      r11, bword ptr [rbp-0x1F8]
       jmp      G_M000_IG66
 
G_M000_IG114:
       mov      r14, gword ptr [r12+0xA0]
       mov      rcx, 0xD1FFAB1E
       call     CORINFO_HELP_NEWSFAST
       mov      r15, rax
       xor      r8d, r8d
       mov      dword ptr [rsp+0x20], r8d
       mov      r8, gword ptr [r14+0x88]
       mov      rcx, r15
       mov      r9, rdi
       xor      edx, edx
       call     [Lokad.Lython.Runtime.PyDict:.ctor(int,Lokad.Lython.Runtime.MemoryGovernor,Lokad.Lython.LythonSourceSpan,bool):this]
       mov      r13, gword ptr [rbp-0x150]
       test     r13, r13
       je       SHORT G_M000_IG117
       lea      rdx, [rbp-0xA8]
       mov      rcx, r13
       call     [System.Collections.Generic.Dictionary`2[System.__Canon,System.__Canon]:GetEnumerator():System.Collections.Generic.Dictionary`2+Enumerator[System.__Canon,System.__Canon]:this]
       jmp      SHORT G_M000_IG116
 
G_M000_IG115:
       mov      rcx, gword ptr [rbp-0x90]
       mov      r14, gword ptr [rbp-0x88]
       mov      rdx, gword ptr [r12+0xA0]
       mov      rdx, gword ptr [rdx+0x88]
       mov      r8, rdi
       call     [Lokad.Lython.Runtime.Text.PyString:FromString(System.String,Lokad.Lython.Runtime.MemoryGovernor,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.Text.PyString]
       mov      rdx, rax
       mov      rcx, r15
       mov      r8, r14
       call     [Lokad.Lython.Runtime.PyDict:SetItem(System.Object,System.Object):this]
 
G_M000_IG116:
       lea      rcx, [rbp-0xA8]
       mov      rdx, 0xD1FFAB1E
       call     [System.Collections.Generic.Dictionary`2+Enumerator[System.__Canon,System.__Canon]:MoveNext():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG115
 
G_M000_IG117:
       mov      rcx, gword ptr [rsi+0x08]
       mov      esi, dword ptr [rcx+0x2C]
       cmp      esi, dword ptr [rbp-0x10C]
       jae      SHORT G_M000_IG118
       mov      ecx, esi
       mov      r13, bword ptr [rbp-0x1F8]
       lea      rcx, bword ptr [r13+8*rcx]
       mov      rdx, r15
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rcx, rbx
       mov      edx, esi
       mov      r8d, 1
       call     [Lokad.Lython.Runtime.ArgumentPresence:set_Item(int,bool):this]
       jmp      G_M000_IG67
 
G_M000_IG118:
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG119:
       sub      rsp, 56
 
G_M000_IG120:
       cmp      byte  ptr [rbp-0x118], 0
       je       SHORT G_M000_IG122
 
G_M000_IG121:
       mov      ecx, 12
       call     [CORINFO_HELP_GETDYNAMIC_GCTHREADSTATIC_BASE_NOCTOR_OPTIMIZED]
       lea      rcx, bword ptr [rax+0x18]
       mov      rdx, gword ptr [rbp-0x210]
       call     CORINFO_HELP_ASSIGN_REF
       mov      ecx, 12
       call     [CORINFO_HELP_GETDYNAMIC_GCTHREADSTATIC_BASE_NOCTOR_OPTIMIZED]
       lea      rcx, bword ptr [rax+0x20]
       mov      rdx, gword ptr [rbp-0x218]
       call     CORINFO_HELP_ASSIGN_REF
 
G_M000_IG122:
       nop      
 
G_M000_IG123:
       add      rsp, 56
       ret      
 
; Total bytes of code 4453

