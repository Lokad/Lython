; Assembly listing for method Lokad.Lython.Runtime.PyExecutableFunction:StartNativeCall(Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[System.Object],System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,bool,bool,System.Span`1[System.Object],byref,byref,byref):this (Instrumented Tier0)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; Instrumented Tier0 code
; rbp based frame
; partially interruptible
; compiling with minopt

G_M000_IG01:
       push     rbp
       sub      rsp, 656
       lea      rbp, [rsp+0x290]
       xor      eax, eax
       mov      qword ptr [rbp-0x238], rax
       vxorps   xmm4, xmm4, xmm4
       vmovdqa  xmmword ptr [rbp-0x230], xmm4
       mov      rax, -480
 
G_M000_IG27:
       vmovdqa  xmmword ptr [rbp+rax-0x40], xmm4
       vmovdqa  xmmword ptr [rbp+rax-0x30], xmm4
       vmovdqa  xmmword ptr [rbp+rax-0x20], xmm4
       add      rax, 48
       jne      SHORT G_M000_IG27
       mov      qword ptr [rbp-0x40], rax
       mov      gword ptr [rbp+0x10], rcx
       mov      gword ptr [rbp+0x18], rdx
       mov      bword ptr [rbp+0x20], r8
       mov      gword ptr [rbp+0x28], r9
 
G_M000_IG02:
       mov      dword ptr [rbp-0x174], 0x3E8
       vxorps   ymm0, ymm0, ymm0
       vmovdqu  ymmword ptr [rbp-0xB8], ymm0
       vmovdqu  ymmword ptr [rbp-0x98], ymm0
       vmovdqu  ymmword ptr [rbp-0x78], ymm0
       vmovdqu  ymmword ptr [rbp-0x58], ymm0
       lea      r8, [rbp-0xB8]
       lea      rcx, [rbp-0xC8]
       mov      rdx, 0xD1FFAB1E
       mov      r9d, 16
       call     [<PrivateImplementationDetails>:InlineArrayAsSpan[Lokad.Lython.Runtime.PyExecutableFunction+NativeValues,System.__Canon](byref,int):System.Span`1[System.__Canon]]
       mov      rax, gword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax+0x68]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_ValueStorageCapacity():int:this]
       mov      dword ptr [rbp-0x178], eax
       mov      eax, dword ptr [rbp-0x178]
       mov      dword ptr [rsp+0x20], eax
       lea      rcx, [rbp-0xC8]
       lea      rdx, [rbp-0xC8]
       mov      r8, 0xD1FFAB1E
       xor      r9d, r9d
       call     [System.Span`1[System.__Canon]:Slice(int,int):System.Span`1[System.__Canon]:this]
       mov      rcx, gword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.PyFunctionBase:get_BindingPlan():Lokad.Lython.Runtime.FunctionBindingPlan:this]
       mov      rcx, rax
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_ParameterCount():int:this]
       mov      dword ptr [rbp-0x17C], eax
       mov      edx, dword ptr [rbp-0x17C]
       lea      rcx, [rbp-0xE0]
       call     [Lokad.Lython.Runtime.ArgumentPresence:.ctor(int):this]
       movzx    rax, byte  ptr [rbp+0x48]
       test     eax, eax
       je       G_M000_IG09
 
G_M000_IG03:
       vmovdqu  xmm0, xmmword ptr [rbp-0xC8]
       vmovdqu  xmmword ptr [rbp-0x190], xmm0
 
G_M000_IG04:
       lea      r8, [rbp-0x190]
       mov      rcx, bword ptr [rbp+0x20]
       mov      rdx, 0xD1FFAB1E
       call     [System.ReadOnlySpan`1[System.__Canon]:CopyTo(System.Span`1[System.__Canon]):this]
       xor      eax, eax
       mov      dword ptr [rbp-0xE4], eax
       jmp      SHORT G_M000_IG06
 
G_M000_IG05:
       mov      rcx, 0xD1FFAB1E
       call     CORINFO_HELP_COUNTPROFILE32
       lea      rcx, [rbp-0xE0]
       mov      edx, dword ptr [rbp-0xE4]
       mov      r8d, 1
       call     [Lokad.Lython.Runtime.ArgumentPresence:set_Item(int,bool):this]
       mov      eax, dword ptr [rbp-0xE4]
       inc      eax
       mov      dword ptr [rbp-0xE4], eax
 
G_M000_IG06:
       mov      eax, dword ptr [rbp-0x174]
       dec      eax
       mov      dword ptr [rbp-0x174], eax
       cmp      dword ptr [rbp-0x174], 0
       jg       SHORT G_M000_IG08
 
G_M000_IG07:
       lea      rcx, [rbp-0x174]
       mov      edx, 85
       call     CORINFO_HELP_PATCHPOINT
       jmp      rax
 
G_M000_IG08:
       lea      rcx, [rbp-0xE0]
       call     [Lokad.Lython.Runtime.ArgumentPresence:get_Length():int:this]
       cmp      eax, dword ptr [rbp-0xE4]
       jg       SHORT G_M000_IG05
       jmp      G_M000_IG16
 
G_M000_IG09:
       mov      rcx, 0xD1FFAB1E
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, gword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.PyFunctionBase:get_BindingPlan():Lokad.Lython.Runtime.FunctionBindingPlan:this]
       mov      rcx, rax
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_ParameterCount():int:this]
       mov      dword ptr [rbp-0x194], eax
       mov      eax, dword ptr [rbp-0x194]
       mov      dword ptr [rsp+0x20], eax
       lea      rcx, [rbp-0xC8]
       lea      rdx, [rbp-0x138]
       mov      r8, 0xD1FFAB1E
       xor      r9d, r9d
       call     [System.Span`1[System.__Canon]:Slice(int,int):System.Span`1[System.__Canon]:this]
       vxorps   xmm0, xmm0, xmm0
       vmovdqu  xmmword ptr [rbp-0xF8], xmm0
 
G_M000_IG10:
       vmovdqu  xmm0, xmmword ptr [rbp-0xF8]
       vmovdqu  xmmword ptr [rbp-0x148], xmm0
 
G_M000_IG11:
       vmovdqu  xmm0, xmmword ptr [rbp-0x138]
       vmovdqu  xmmword ptr [rbp-0x1A8], xmm0
 
G_M000_IG12:
       vmovdqu  xmm0, xmmword ptr [rbp-0x148]
       vmovdqu  xmmword ptr [rbp-0x1B8], xmm0
 
G_M000_IG13:
       mov      rcx, gword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.PyFunctionBase:get_BindingPlan():Lokad.Lython.Runtime.FunctionBindingPlan:this]
       mov      gword ptr [rbp-0x1D0], rax
       mov      rax, gword ptr [rbp+0x30]
       mov      gword ptr [rsp+0x28], rax
       xor      eax, eax
       mov      dword ptr [rsp+0x30], eax
       mov      rax, gword ptr [rbp+0x28]
       mov      gword ptr [rsp+0x38], rax
       mov      rax, gword ptr [rbp+0x18]
       mov      gword ptr [rsp+0x40], rax
       mov      rax, bword ptr [rbp+0x20]
 
G_M000_IG14:
       vmovdqu  xmm0, xmmword ptr [rax]
       vmovdqu  xmmword ptr [rbp-0x1C8], xmm0
 
G_M000_IG15:
       mov      rax, gword ptr [rbp-0x1D0]
       mov      gword ptr [rsp+0x20], rax
       lea      r8, [rbp-0x1B8]
       lea      rcx, [rbp-0x1A8]
       lea      rax, [rbp-0x1C8]
       mov      qword ptr [rsp+0x48], rax
       lea      rdx, [rbp-0xE0]
       mov      r9, gword ptr [rbp+0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime:BindFunctionArgumentsInto(System.Span`1[System.Object],byref,System.ReadOnlySpan`1[Lokad.Lython.Runtime.CallArgumentValue],Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.FunctionBindingPlan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,bool,System.Object,Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[System.Object])]
 
G_M000_IG16:
       mov      rcx, 0xD1FFAB1E
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG17:
       vmovdqu  xmm0, xmmword ptr [rbp-0xC8]
       vmovdqu  xmmword ptr [rbp-0x158], xmm0
 
G_M000_IG18:
       vmovdqu  xmm0, xmmword ptr [rbp-0xE0]
       vmovdqu  xmmword ptr [rbp-0x170], xmm0
       mov      rax, qword ptr [rbp-0xD0]
       mov      qword ptr [rbp-0x160], rax
 
G_M000_IG19:
       vxorps   ymm0, ymm0, ymm0
       vmovdqu  ymmword ptr [rbp-0x128], ymm0
       vmovdqu  xmmword ptr [rbp-0x108], xmm0
 
G_M000_IG20:
       vmovdqu  xmm0, xmmword ptr [rbp-0x158]
       vmovdqu  xmmword ptr [rbp-0x1E0], xmm0
 
G_M000_IG21:
       vmovdqu  xmm0, xmmword ptr [rbp-0x170]
       vmovdqu  xmmword ptr [rbp-0x1F8], xmm0
       mov      rax, qword ptr [rbp-0x160]
       mov      qword ptr [rbp-0x1E8], rax
 
G_M000_IG22:
       vmovdqu  ymm0, ymmword ptr [rbp-0x128]
       vmovdqu  ymmword ptr [rbp-0x228], ymm0
       vmovdqu  xmm0, xmmword ptr [rbp-0x108]
       vmovdqu  xmmword ptr [rbp-0x208], xmm0
 
G_M000_IG23:
       mov      rax, gword ptr [rbp+0x38]
       mov      gword ptr [rsp+0x20], rax
       movzx    rax, byte  ptr [rbp+0x40]
       mov      dword ptr [rsp+0x28], eax
       mov      rax, bword ptr [rbp+0x50]
 
G_M000_IG24:
       vmovdqu  xmm0, xmmword ptr [rax]
       vmovdqu  xmmword ptr [rbp-0x238], xmm0
 
G_M000_IG25:
       mov      rax, bword ptr [rbp+0x58]
       mov      bword ptr [rsp+0x38], rax
       mov      rax, bword ptr [rbp+0x60]
       mov      bword ptr [rsp+0x40], rax
       mov      rax, bword ptr [rbp+0x68]
       mov      bword ptr [rsp+0x48], rax
       lea      rdx, [rbp-0x1E0]
       lea      r8, [rbp-0x1F8]
       lea      r9, [rbp-0x228]
       lea      rax, [rbp-0x238]
       mov      qword ptr [rsp+0x30], rax
       mov      rcx, gword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.PyExecutableFunction:StartInline(System.Span`1[System.Object],Lokad.Lython.Runtime.ArgumentPresence,System.Nullable`1[Lokad.Lython.Runtime.BoundCallArguments],Lokad.Lython.LythonSourceSpan,bool,System.Span`1[System.Object],byref,byref,byref):this]
       nop      
 
G_M000_IG26:
       vzeroupper 
       add      rsp, 656
       pop      rbp
       ret      
 
; Total bytes of code 1006

; Assembly listing for method Lokad.Lython.Runtime.LythonRuntime:BindFunctionArgumentsInto(System.Span`1[System.Object],byref,System.ReadOnlySpan`1[Lokad.Lython.Runtime.CallArgumentValue],Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.FunctionBindingPlan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,bool,System.Object,Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[System.Object]) (Instrumented Tier0)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; Instrumented Tier0 code
; rbp based frame
; fully interruptible
; compiling with minopt

G_M000_IG01:
       push     rbp
       sub      rsp, 720
       lea      rbp, [rsp+0x2D0]
       xor      eax, eax
       mov      qword ptr [rbp-0x2A8], rax
       vxorps   xmm4, xmm4, xmm4
       vmovdqa  xmmword ptr [rbp-0x2A0], xmm4
       vmovdqa  xmmword ptr [rbp-0x290], xmm4
       mov      rax, -576
 
G_M000_IG72:
       vmovdqa  xmmword ptr [rbp+rax-0x40], xmm4
       vmovdqa  xmmword ptr [rbp+rax-0x30], xmm4
       vmovdqa  xmmword ptr [rbp+rax-0x20], xmm4
       add      rax, 48
       jne      SHORT G_M000_IG72
       mov      qword ptr [rbp-0x40], rax
       mov      bword ptr [rbp+0x10], rcx
       mov      bword ptr [rbp+0x18], rdx
       mov      bword ptr [rbp+0x20], r8
       mov      gword ptr [rbp+0x28], r9
 
G_M000_IG02:
       mov      dword ptr [rbp-0x20C], 0x3E8
       xor      rax, rax
       mov      gword ptr [rbp-0x40], rax
       xor      rax, rax
       mov      gword ptr [rbp-0x48], rax
       xor      eax, eax
       mov      dword ptr [rbp-0x4C], eax
       cmp      gword ptr [rbp+0x50], 0
       jne      SHORT G_M000_IG03
       mov      rax, bword ptr [rbp+0x20]
       mov      eax, dword ptr [rax+0x08]
       mov      dword ptr [rbp-0x124], eax
       jmp      SHORT G_M000_IG04
 
G_M000_IG03:
       mov      rcx, 0xD1FFAB1E
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, gword ptr [rbp+0x50]
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_ArgumentCount():int:this]
       mov      dword ptr [rbp-0x124], eax
 
G_M000_IG04:
       mov      eax, dword ptr [rbp-0x124]
       mov      dword ptr [rbp-0x50], eax
       cmp      gword ptr [rbp+0x48], 0
       je       SHORT G_M000_IG05
       mov      dword ptr [rbp-0x128], -1
       jmp      SHORT G_M000_IG06
 
G_M000_IG05:
       mov      rcx, 0xD1FFAB1E
       call     CORINFO_HELP_COUNTPROFILE32
       xor      eax, eax
       mov      dword ptr [rbp-0x128], eax
 
G_M000_IG06:
       mov      eax, dword ptr [rbp-0x128]
       mov      dword ptr [rbp-0x54], eax
       jmp      G_M000_IG34
 
G_M000_IG07:
       cmp      dword ptr [rbp-0x54], 0
       jl       G_M000_IG14
       cmp      gword ptr [rbp+0x50], 0
       je       G_M000_IG11
       mov      rcx, gword ptr [rbp+0x50]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_Arguments():Lokad.Lython.Frontend.CallArgumentForm[]:this]
       mov      ecx, dword ptr [rbp-0x54]
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG68
       mov      edx, ecx
       imul     rdx, rdx, 16
       lea      rax, bword ptr [rax+rdx+0x10]
 
G_M000_IG08:
       vmovdqu  xmm0, xmmword ptr [rax]
       vmovdqu  xmmword ptr [rbp-0x1A0], xmm0
 
G_M000_IG09:
       vmovdqu  xmm0, xmmword ptr [rbp-0x1A0]
       vmovdqu  xmmword ptr [rbp-0x220], xmm0
 
G_M000_IG10:
       mov      rax, bword ptr [rbp+0x58]
       mov      eax, dword ptr [rax+0x08]
       cmp      dword ptr [rbp-0x54], eax
       jae      G_M000_IG68
       mov      rax, bword ptr [rbp+0x58]
       mov      rax, bword ptr [rax]
       mov      ecx, dword ptr [rbp-0x54]
       mov      rdx, gword ptr [rax+8*rcx]
       mov      rcx, 0xD1FFAB1E
       call     [Lokad.Lython.Internal.NullabilityExtensions:RequireNotNull[System.__Canon](System.__Canon):System.__Canon]
       mov      gword ptr [rbp-0x228], rax
       mov      r8, gword ptr [rbp-0x228]
       lea      rdx, [rbp-0x220]
       lea      rcx, [rbp-0x140]
       call     [Lokad.Lython.Runtime.LythonRuntime:CreateExecutableCallArgument(Lokad.Lython.Frontend.CallArgumentForm,System.Object):Lokad.Lython.Runtime.CallArgumentValue]
       jmp      SHORT G_M000_IG15
 
G_M000_IG11:
       mov      rcx, 0xD1FFAB1E
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x20]
       mov      eax, dword ptr [rax+0x08]
       cmp      dword ptr [rbp-0x54], eax
       jae      G_M000_IG68
       mov      rax, bword ptr [rbp+0x20]
       mov      rax, bword ptr [rax]
       mov      ecx, dword ptr [rbp-0x54]
       lea      rcx, [rcx+2*rcx]
 
G_M000_IG12:
       vmovdqu  xmm0, xmmword ptr [rax+8*rcx]
       vmovdqu  xmmword ptr [rbp-0x140], xmm0
       mov      rdx, qword ptr [rax+8*rcx+0x10]
       mov      qword ptr [rbp-0x130], rdx
 
G_M000_IG13:
       jmp      SHORT G_M000_IG15
 
G_M000_IG14:
       mov      rcx, 0xD1FFAB1E
       call     CORINFO_HELP_COUNTPROFILE32
       lea      rcx, [rbp-0x140]
       mov      rdx, gword ptr [rbp+0x48]
       call     [Lokad.Lython.Runtime.CallArgumentValue:Positional(System.Object):Lokad.Lython.Runtime.CallArgumentValue]
 
G_M000_IG15:
       vmovdqu  xmm0, xmmword ptr [rbp-0x140]
       vmovdqu  xmmword ptr [rbp-0x70], xmm0
       mov      rax, qword ptr [rbp-0x130]
       mov      qword ptr [rbp-0x60], rax
 
G_M000_IG16:
       lea      rcx, [rbp-0x70]
       call     [Lokad.Lython.Runtime.CallArgumentValue:get_IsPositional():bool:this]
       test     eax, eax
       je       G_M000_IG21
       mov      rcx, gword ptr [rbp+0x30]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_PositionalCount():int:this]
       cmp      eax, dword ptr [rbp-0x4C]
       jg       G_M000_IG20
       mov      rcx, gword ptr [rbp+0x30]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_VariadicListIndex():int:this]
       test     eax, eax
       jge      SHORT G_M000_IG18
 
G_M000_IG17:
       mov      rcx, gword ptr [rbp+0x30]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_CallableKind():int:this]
       mov      dword ptr [rbp-0x18C], eax
       mov      rcx, gword ptr [rbp+0x30]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_CallableName():System.String:this]
       mov      gword ptr [rbp-0x230], rax
       mov      rdx, gword ptr [rbp-0x230]
       mov      ecx, dword ptr [rbp-0x18C]
       mov      r8, gword ptr [rbp+0x28]
       call     [Lokad.Lython.Runtime.CallErrors:TooManyPositional(int,System.String,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.LythonRuntimeException]
       mov      rcx, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG18:
       cmp      gword ptr [rbp-0x40], 0
       jne      SHORT G_M000_IG19
       mov      rcx, 0xD1FFAB1E
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, 0xD1FFAB1E
       call     [System.Array:Empty[System.__Canon]():System.__Canon[]]
       mov      gword ptr [rbp-0x180], rax
       mov      rcx, 0xD1FFAB1E
       call     CORINFO_HELP_NEWSFAST
       mov      gword ptr [rbp-0x188], rax
       mov      rcx, gword ptr [rbp+0x38]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:get_MemoryGovernor():Lokad.Lython.Runtime.MemoryGovernor:this]
       mov      gword ptr [rbp-0x238], rax
       mov      r8, gword ptr [rbp-0x238]
       mov      rdx, gword ptr [rbp-0x180]
       mov      rcx, gword ptr [rbp-0x188]
       mov      r9, gword ptr [rbp+0x28]
       call     [Lokad.Lython.Runtime.PyList:.ctor(System.Collections.Generic.IEnumerable`1[System.Object],Lokad.Lython.Runtime.MemoryGovernor,Lokad.Lython.LythonSourceSpan):this]
       mov      rax, gword ptr [rbp-0x188]
       mov      gword ptr [rbp-0x40], rax
 
G_M000_IG19:
       lea      rcx, [rbp-0x70]
       call     [Lokad.Lython.Runtime.CallArgumentValue:get_Value():System.Object:this]
       mov      gword ptr [rbp-0x240], rax
       mov      rdx, gword ptr [rbp-0x240]
       mov      rcx, gword ptr [rbp-0x40]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.PyList:Add(System.Object):this]
       jmp      G_M000_IG33
 
G_M000_IG20:
       mov      rcx, 0xD1FFAB1E
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x10]
       mov      eax, dword ptr [rax+0x08]
       cmp      dword ptr [rbp-0x4C], eax
       jae      G_M000_IG68
       mov      rax, bword ptr [rbp+0x10]
       mov      rax, bword ptr [rax]
       mov      ecx, dword ptr [rbp-0x4C]
       lea      rax, bword ptr [rax+8*rcx]
       mov      bword ptr [rbp-0x178], rax
       lea      rcx, [rbp-0x70]
       call     [Lokad.Lython.Runtime.CallArgumentValue:get_Value():System.Object:this]
       mov      rdx, rax
       mov      rcx, bword ptr [rbp-0x178]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rcx, bword ptr [rbp+0x18]
       mov      edx, dword ptr [rbp-0x4C]
       mov      r8d, 1
       call     [Lokad.Lython.Runtime.ArgumentPresence:set_Item(int,bool):this]
       mov      eax, dword ptr [rbp-0x4C]
       inc      eax
       mov      dword ptr [rbp-0x4C], eax
       jmp      G_M000_IG33
 
G_M000_IG21:
       lea      rcx, [rbp-0x70]
       call     [Lokad.Lython.Runtime.CallArgumentValue:get_KeywordName():System.String:this]
       mov      gword ptr [rbp-0x78], rax
       mov      rcx, gword ptr [rbp+0x30]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_LayoutParameterIndex():System.Collections.Generic.IReadOnlyDictionary`2[System.String,int]:this]
       mov      gword ptr [rbp-0x208], rax
       mov      rcx, gword ptr [rbp-0x208]
       mov      rdx, 0xD1FFAB1E
       call     CORINFO_HELP_CLASSPROFILE32
       mov      rax, gword ptr [rbp-0x208]
       mov      gword ptr [rbp-0x248], rax
       mov      rcx, gword ptr [rbp-0x248]
       lea      r8, [rbp-0x80]
       mov      rdx, gword ptr [rbp-0x78]
       mov      r11, 0xD1FFAB1E
       call     [r11]System.Collections.Generic.IReadOnlyDictionary`2[System.__Canon,int]:TryGetValue(System.__Canon,byref):bool:this
       test     eax, eax
       je       SHORT G_M000_IG23
       mov      eax, dword ptr [rbp-0x80]
       mov      dword ptr [rbp-0x158], eax
       mov      rcx, gword ptr [rbp+0x30]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_NamedLayoutCount():int:this]
       cmp      eax, dword ptr [rbp-0x158]
       jle      G_M000_IG25
       mov      eax, dword ptr [rbp-0x80]
       mov      dword ptr [rbp-0x15C], eax
       mov      rcx, gword ptr [rbp+0x30]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_PositionalOnlyCount():int:this]
       cmp      eax, dword ptr [rbp-0x15C]
       jle      G_M000_IG30
 
G_M000_IG22:
       mov      rcx, 0xD1FFAB1E
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG23:
       mov      rcx, gword ptr [rbp+0x30]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_VariadicDictionaryIndex():int:this]
       test     eax, eax
       jge      SHORT G_M000_IG26
 
G_M000_IG24:
       mov      rcx, gword ptr [rbp+0x30]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_CallableKind():int:this]
       mov      dword ptr [rbp-0x154], eax
       mov      rcx, gword ptr [rbp+0x30]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_CallableName():System.String:this]
       mov      gword ptr [rbp-0x250], rax
       mov      rdx, gword ptr [rbp-0x250]
       mov      ecx, dword ptr [rbp-0x154]
       mov      r8, gword ptr [rbp-0x78]
       mov      r9, gword ptr [rbp+0x28]
       call     [Lokad.Lython.Runtime.CallErrors:UnexpectedKeyword(int,System.String,System.String,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.LythonRuntimeException]
       mov      rcx, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG25:
       mov      rcx, 0xD1FFAB1E
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG23
 
G_M000_IG26:
       cmp      gword ptr [rbp-0x48], 0
       jne      SHORT G_M000_IG27
       mov      rcx, 0xD1FFAB1E
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, 0xD1FFAB1E
       call     CORINFO_HELP_NEWSFAST
       mov      gword ptr [rbp-0x150], rax
       call     [System.StringComparer:get_Ordinal():System.StringComparer]
       mov      gword ptr [rbp-0x258], rax
       mov      rdx, gword ptr [rbp-0x258]
       mov      rcx, gword ptr [rbp-0x150]
       call     [System.Collections.Generic.Dictionary`2[System.__Canon,System.__Canon]:.ctor(System.Collections.Generic.IEqualityComparer`1[System.__Canon]):this]
       mov      rax, gword ptr [rbp-0x150]
       mov      gword ptr [rbp-0x48], rax
 
G_M000_IG27:
       lea      rcx, [rbp-0x70]
       call     [Lokad.Lython.Runtime.CallArgumentValue:get_Value():System.Object:this]
       mov      gword ptr [rbp-0x260], rax
       mov      r8, gword ptr [rbp-0x260]
       mov      rdx, gword ptr [rbp-0x78]
       mov      rcx, gword ptr [rbp-0x48]
       cmp      dword ptr [rcx], ecx
       call     [System.Collections.Generic.Dictionary`2[System.__Canon,System.__Canon]:TryAdd(System.__Canon,System.__Canon):bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG29
 
G_M000_IG28:
       mov      rcx, gword ptr [rbp+0x30]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_CallableKind():int:this]
       mov      dword ptr [rbp-0x144], eax
       mov      rcx, gword ptr [rbp+0x30]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_CallableName():System.String:this]
       mov      gword ptr [rbp-0x268], rax
       mov      rdx, gword ptr [rbp-0x268]
       mov      ecx, dword ptr [rbp-0x144]
       mov      r8, gword ptr [rbp-0x78]
       mov      r9, gword ptr [rbp+0x28]
       call     [Lokad.Lython.Runtime.CallErrors:MultipleValues(int,System.String,System.String,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.LythonRuntimeException]
       mov      rcx, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG29:
       mov      rcx, 0xD1FFAB1E
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG33
 
G_M000_IG30:
       mov      rcx, bword ptr [rbp+0x18]
       mov      edx, dword ptr [rbp-0x80]
       call     [Lokad.Lython.Runtime.ArgumentPresence:get_Item(int):bool:this]
       test     eax, eax
       je       SHORT G_M000_IG32
 
G_M000_IG31:
       mov      rcx, gword ptr [rbp+0x30]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_CallableKind():int:this]
       mov      dword ptr [rbp-0x16C], eax
       mov      rcx, gword ptr [rbp+0x30]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_CallableName():System.String:this]
       mov      gword ptr [rbp-0x270], rax
       mov      rdx, gword ptr [rbp-0x270]
       mov      ecx, dword ptr [rbp-0x16C]
       mov      r8, gword ptr [rbp-0x78]
       mov      r9, gword ptr [rbp+0x28]
       call     [Lokad.Lython.Runtime.CallErrors:MultipleValues(int,System.String,System.String,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.LythonRuntimeException]
       mov      rcx, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG32:
       mov      rcx, 0xD1FFAB1E
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x10]
       mov      eax, dword ptr [rax+0x08]
       cmp      dword ptr [rbp-0x80], eax
       jae      G_M000_IG68
       mov      rax, bword ptr [rbp+0x10]
       mov      rax, bword ptr [rax]
       mov      ecx, dword ptr [rbp-0x80]
       lea      rax, bword ptr [rax+8*rcx]
       mov      bword ptr [rbp-0x168], rax
       lea      rcx, [rbp-0x70]
       call     [Lokad.Lython.Runtime.CallArgumentValue:get_Value():System.Object:this]
       mov      rdx, rax
       mov      rcx, bword ptr [rbp-0x168]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rcx, bword ptr [rbp+0x18]
       mov      edx, dword ptr [rbp-0x80]
       mov      r8d, 1
       call     [Lokad.Lython.Runtime.ArgumentPresence:set_Item(int,bool):this]
 
G_M000_IG33:
       mov      rcx, 0xD1FFAB1E
       call     CORINFO_HELP_COUNTPROFILE32
       mov      eax, dword ptr [rbp-0x54]
       inc      eax
       mov      dword ptr [rbp-0x54], eax
 
G_M000_IG34:
       mov      eax, dword ptr [rbp-0x20C]
       dec      eax
       mov      dword ptr [rbp-0x20C], eax
       cmp      dword ptr [rbp-0x20C], 0
       jg       SHORT G_M000_IG36
 
G_M000_IG35:
       lea      rcx, [rbp-0x20C]
       mov      edx, 436
       call     CORINFO_HELP_PATCHPOINT
       jmp      rax
 
G_M000_IG36:
       mov      eax, dword ptr [rbp-0x54]
       cmp      eax, dword ptr [rbp-0x50]
       jl       G_M000_IG07
       xor      eax, eax
       mov      dword ptr [rbp-0x84], eax
       jmp      G_M000_IG40
 
G_M000_IG37:
       mov      rcx, bword ptr [rbp+0x18]
       mov      edx, dword ptr [rbp-0x84]
       call     [Lokad.Lython.Runtime.ArgumentPresence:get_Item(int):bool:this]
       test     eax, eax
       jne      G_M000_IG39
       mov      rcx, gword ptr [rbp+0x30]
       mov      edx, dword ptr [rbp-0x84]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:NameAt(int):System.String:this]
       mov      gword ptr [rbp-0x90], rax
       lea      r8, [rbp-0x98]
       mov      rcx, gword ptr [rbp+0x30]
       mov      edx, dword ptr [rbp-0x84]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:TryGetPositionalDefault(int,byref):bool:this]
       test     eax, eax
       je       SHORT G_M000_IG38
       mov      rcx, 0xD1FFAB1E
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x10]
       mov      eax, dword ptr [rax+0x08]
       cmp      dword ptr [rbp-0x84], eax
       jae      G_M000_IG68
       mov      rax, bword ptr [rbp+0x10]
       mov      rax, bword ptr [rax]
       mov      ecx, dword ptr [rbp-0x84]
       lea      rcx, bword ptr [rax+8*rcx]
       mov      rdx, gword ptr [rbp-0x98]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       jmp      SHORT G_M000_IG39
 
G_M000_IG38:
       mov      rcx, gword ptr [rbp+0x30]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_CallableKind():int:this]
       mov      dword ptr [rbp-0x1A4], eax
       mov      rcx, gword ptr [rbp+0x30]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_CallableName():System.String:this]
       mov      gword ptr [rbp-0x278], rax
       mov      rdx, gword ptr [rbp-0x278]
       mov      ecx, dword ptr [rbp-0x1A4]
       mov      r8, gword ptr [rbp-0x90]
       mov      r9, gword ptr [rbp+0x28]
       call     [Lokad.Lython.Runtime.CallErrors:MissingArgument(int,System.String,System.String,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.LythonRuntimeException]
       mov      rcx, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG39:
       mov      rcx, 0xD1FFAB1E
       call     CORINFO_HELP_COUNTPROFILE32
       mov      eax, dword ptr [rbp-0x84]
       inc      eax
       mov      dword ptr [rbp-0x84], eax
 
G_M000_IG40:
       mov      eax, dword ptr [rbp-0x20C]
       dec      eax
       mov      dword ptr [rbp-0x20C], eax
       cmp      dword ptr [rbp-0x20C], 0
       jg       SHORT G_M000_IG42
 
G_M000_IG41:
       lea      rcx, [rbp-0x20C]
       mov      edx, 526
       call     CORINFO_HELP_PATCHPOINT
       jmp      rax
 
G_M000_IG42:
       mov      rcx, gword ptr [rbp+0x30]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_PositionalCount():int:this]
       cmp      eax, dword ptr [rbp-0x84]
       jg       G_M000_IG37
       xor      eax, eax
       mov      dword ptr [rbp-0x9C], eax
       jmp      G_M000_IG48
 
G_M000_IG43:
       mov      rcx, gword ptr [rbp+0x30]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_PositionalCount():int:this]
       add      eax, dword ptr [rbp-0x9C]
       mov      dword ptr [rbp-0xA0], eax
       mov      rcx, bword ptr [rbp+0x18]
       mov      edx, dword ptr [rbp-0xA0]
       call     [Lokad.Lython.Runtime.ArgumentPresence:get_Item(int):bool:this]
       test     eax, eax
       jne      G_M000_IG47
       mov      rcx, gword ptr [rbp+0x30]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_PositionalCount():int:this]
       add      eax, dword ptr [rbp-0x9C]
       mov      dword ptr [rbp-0x27C], eax
       mov      edx, dword ptr [rbp-0x27C]
       mov      rcx, gword ptr [rbp+0x30]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:NameAt(int):System.String:this]
       mov      gword ptr [rbp-0xA8], rax
       mov      rcx, gword ptr [rbp+0x30]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_KeywordDefaultStorage():Lokad.Lython.Runtime.PyDict:this]
       mov      gword ptr [rbp-0xB0], rax
       cmp      gword ptr [rbp-0xB0], 0
       je       G_M000_IG46
       mov      rcx, gword ptr [rbp+0x30]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_KeywordDefaultNames():Lokad.Lython.Runtime.Text.PyString[]:this]
       mov      ecx, dword ptr [rbp-0x9C]
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG68
       mov      edx, ecx
       lea      rax, bword ptr [rax+8*rdx+0x10]
       mov      rax, gword ptr [rax]
       mov      gword ptr [rbp-0x288], rax
       mov      rax, gword ptr [rbp+0x28]
       mov      gword ptr [rsp+0x20], rax
       mov      rdx, gword ptr [rbp-0x288]
       lea      r8, [rbp-0xB8]
       mov      rcx, gword ptr [rbp-0xB0]
       mov      r9, gword ptr [rbp+0x38]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.PyDict:TryGetValue(System.Object,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):bool:this]
       test     eax, eax
       je       SHORT G_M000_IG45
       mov      rcx, 0xD1FFAB1E
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x10]
       mov      eax, dword ptr [rax+0x08]
       cmp      dword ptr [rbp-0xA0], eax
       jae      G_M000_IG68
       mov      rax, bword ptr [rbp+0x10]
 
G_M000_IG44:
       mov      rax, bword ptr [rax]
       mov      ecx, dword ptr [rbp-0xA0]
       lea      rcx, bword ptr [rax+8*rcx]
       mov      rdx, gword ptr [rbp-0xB8]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       jmp      SHORT G_M000_IG47
 
G_M000_IG45:
       mov      rcx, 0xD1FFAB1E
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG46:
       mov      rcx, gword ptr [rbp+0x30]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_CallableKind():int:this]
       mov      dword ptr [rbp-0x200], eax
       mov      rcx, gword ptr [rbp+0x30]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_CallableName():System.String:this]
       mov      gword ptr [rbp-0x290], rax
       mov      rdx, gword ptr [rbp-0x290]
       mov      ecx, dword ptr [rbp-0x200]
       mov      r8, gword ptr [rbp-0xA8]
       mov      r9, gword ptr [rbp+0x28]
       call     [Lokad.Lython.Runtime.CallErrors:MissingArgument(int,System.String,System.String,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.LythonRuntimeException]
       mov      rcx, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG47:
       mov      rcx, 0xD1FFAB1E
       call     CORINFO_HELP_COUNTPROFILE32
       mov      eax, dword ptr [rbp-0x9C]
       inc      eax
       mov      dword ptr [rbp-0x9C], eax
 
G_M000_IG48:
       movzx    rax, byte  ptr [rbp+0x40]
       test     eax, eax
       jne      SHORT G_M000_IG52
       mov      eax, dword ptr [rbp-0x20C]
       dec      eax
       mov      dword ptr [rbp-0x20C], eax
       cmp      dword ptr [rbp-0x20C], 0
       jg       SHORT G_M000_IG50
 
G_M000_IG49:
       lea      rcx, [rbp-0x20C]
       mov      edx, 667
       call     CORINFO_HELP_PATCHPOINT
       jmp      rax
 
G_M000_IG50:
       mov      rcx, gword ptr [rbp+0x30]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_KeywordOnlyCount():int:this]
       cmp      eax, dword ptr [rbp-0x9C]
       jg       G_M000_IG43
 
G_M000_IG51:
       mov      rcx, 0xD1FFAB1E
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG52:
       mov      rcx, gword ptr [rbp+0x30]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_VariadicListIndex():int:this]
       test     eax, eax
       jl       G_M000_IG58
       mov      rcx, 0xD1FFAB1E
       call     CORINFO_HELP_NEWSFAST
       mov      gword ptr [rbp-0x1C0], rax
       mov      rcx, gword ptr [rbp-0x1C0]
       call     [Lokad.Lython.Runtime.LythonRuntime+<>c__DisplayClass333_0:.ctor():this]
       mov      rax, gword ptr [rbp-0x1C0]
       mov      gword ptr [rbp-0xC0], rax
       mov      rcx, gword ptr [rbp+0x30]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_VariadicListIndex():int:this]
       mov      dword ptr [rbp-0xC4], eax
       mov      rax, gword ptr [rbp-0xC0]
       lea      rcx, bword ptr [rax+0x08]
       mov      rdx, gword ptr [rbp-0x40]
       call     CORINFO_HELP_ASSIGN_REF
       mov      rax, gword ptr [rbp-0xC0]
       cmp      gword ptr [rax+0x08], 0
       je       SHORT G_M000_IG54
       mov      rax, gword ptr [rbp-0xC0]
       mov      rcx, gword ptr [rax+0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.PyList:get_Count():int:this]
       test     eax, eax
       jne      G_M000_IG56
 
G_M000_IG53:
       mov      rcx, 0xD1FFAB1E
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG54:
       mov      rax, bword ptr [rbp+0x10]
       mov      eax, dword ptr [rax+0x08]
       cmp      dword ptr [rbp-0xC4], eax
       jae      G_M000_IG68
       mov      rax, bword ptr [rbp+0x10]
       mov      rax, bword ptr [rax]
       mov      ecx, dword ptr [rbp-0xC4]
       lea      rax, bword ptr [rax+8*rcx]
       mov      bword ptr [rbp-0x1D0], rax
       mov      rax, 0xD1FFAB1E
       mov      rax, gword ptr [rax]
       mov      gword ptr [rbp-0x1C8], rax
       mov      rax, bword ptr [rbp-0x1D0]
       mov      bword ptr [rbp-0x1D8], rax
       xor      eax, eax
       mov      dword ptr [rbp-0x1DC], eax
       mov      rax, gword ptr [rbp-0x1C8]
       mov      gword ptr [rbp-0x1E8], rax
       cmp      gword ptr [rbp-0x1C8], 0
       jne      SHORT G_M000_IG55
       mov      rcx, 0xD1FFAB1E
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, 0xD1FFAB1E
       call     CORINFO_HELP_NEWSFAST
       mov      gword ptr [rbp-0x1F0], rax
       mov      rax, 0xD1FFAB1E
       mov      rdx, gword ptr [rax]
       mov      rcx, gword ptr [rbp-0x1F0]
       mov      r8, 0xD1FFAB1E
       call     [System.Delegate:CtorClosed(System.Object,nint):this]
       mov      rdx, gword ptr [rbp-0x1F0]
       mov      rcx, 0xD1FFAB1E
       call     CORINFO_HELP_ASSIGN_REF
       mov      rax, gword ptr [rbp-0x1F0]
       mov      gword ptr [rbp-0x1E8], rax
 
G_M000_IG55:
       mov      ecx, dword ptr [rbp-0x1DC]
       mov      rdx, gword ptr [rbp-0x1E8]
       mov      r8, gword ptr [rbp+0x38]
       mov      r9, gword ptr [rbp+0x28]
       call     [Lokad.Lython.Runtime.LythonRuntime:CreateTuple(int,System.Func`2[int,System.Object],Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.PyTuple]
       mov      rdx, rax
       mov      rcx, bword ptr [rbp-0x1D8]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       jmp      G_M000_IG57
 
G_M000_IG56:
       mov      rcx, 0xD1FFAB1E
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, 0xD1FFAB1E
       call     CORINFO_HELP_NEWSFAST
       mov      gword ptr [rbp-0x1F8], rax
       mov      rax, gword ptr [rbp-0xC0]
       mov      rcx, gword ptr [rax+0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.PyList:get_Count():int:this]
       mov      dword ptr [rbp-0x1FC], eax
       mov      rcx, gword ptr [rbp-0x1F8]
       mov      rdx, gword ptr [rbp-0xC0]
       mov      r8, 0xD1FFAB1E
       call     [System.Delegate:CtorClosed(System.Object,nint):this]
       mov      ecx, dword ptr [rbp-0x1FC]
       mov      rdx, gword ptr [rbp-0x1F8]
       mov      r8, gword ptr [rbp+0x38]
       mov      r9, gword ptr [rbp+0x28]
       call     [Lokad.Lython.Runtime.LythonRuntime:CreateTuple(int,System.Func`2[int,System.Object],Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.PyTuple]
       mov      gword ptr [rbp-0xD0], rax
       mov      rax, bword ptr [rbp+0x10]
       mov      eax, dword ptr [rax+0x08]
       cmp      dword ptr [rbp-0xC4], eax
       jae      G_M000_IG68
       mov      rax, bword ptr [rbp+0x10]
       mov      rax, bword ptr [rax]
       mov      ecx, dword ptr [rbp-0xC4]
       lea      rcx, bword ptr [rax+8*rcx]
       mov      rdx, gword ptr [rbp-0xD0]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
 
G_M000_IG57:
       mov      rcx, 0xD1FFAB1E
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp+0x18]
       mov      edx, dword ptr [rbp-0xC4]
       mov      r8d, 1
       call     [Lokad.Lython.Runtime.ArgumentPresence:set_Item(int,bool):this]
 
G_M000_IG58:
       mov      rcx, gword ptr [rbp+0x30]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_VariadicDictionaryIndex():int:this]
       test     eax, eax
       jl       G_M000_IG66
       mov      rcx, 0xD1FFAB1E
       call     CORINFO_HELP_NEWSFAST
       mov      gword ptr [rbp-0x1B0], rax
       mov      rcx, gword ptr [rbp+0x38]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:get_MemoryGovernor():Lokad.Lython.Runtime.MemoryGovernor:this]
       mov      gword ptr [rbp-0x298], rax
       mov      rdx, gword ptr [rbp-0x298]
       mov      rcx, gword ptr [rbp-0x1B0]
       mov      r8, gword ptr [rbp+0x28]
       call     [Lokad.Lython.Runtime.PyDict:.ctor(Lokad.Lython.Runtime.MemoryGovernor,Lokad.Lython.LythonSourceSpan):this]
       mov      rax, gword ptr [rbp-0x1B0]
       mov      gword ptr [rbp-0xD8], rax
       cmp      gword ptr [rbp-0x48], 0
       je       G_M000_IG65
       lea      rdx, [rbp-0x108]
       mov      rcx, gword ptr [rbp-0x48]
       cmp      dword ptr [rcx], ecx
       call     [System.Collections.Generic.Dictionary`2[System.__Canon,System.__Canon]:GetEnumerator():System.Collections.Generic.Dictionary`2+Enumerator[System.__Canon,System.__Canon]:this]
       nop      
 
G_M000_IG59:
       jmp      G_M000_IG61
 
G_M000_IG60:
       mov      rcx, 0xD1FFAB1E
       call     CORINFO_HELP_COUNTPROFILE32
       lea      rdx, [rbp-0x118]
       lea      rcx, [rbp-0x108]
       mov      r8, 0xD1FFAB1E
       call     [System.Collections.Generic.Dictionary`2+Enumerator[System.__Canon,System.__Canon]:get_Current():System.Collections.Generic.KeyValuePair`2[System.__Canon,System.__Canon]:this]
       lea      rcx, [rbp-0x118]
       mov      rdx, 0xD1FFAB1E
       call     [System.Collections.Generic.KeyValuePair`2[System.__Canon,System.__Canon]:get_Key():System.__Canon:this]
       mov      gword ptr [rbp-0x1B8], rax
       mov      rcx, gword ptr [rbp+0x38]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:get_MemoryGovernor():Lokad.Lython.Runtime.MemoryGovernor:this]
       mov      gword ptr [rbp-0x2A0], rax
       mov      rdx, gword ptr [rbp-0x2A0]
       mov      rcx, gword ptr [rbp-0x1B8]
       mov      r8, gword ptr [rbp+0x28]
       call     [Lokad.Lython.Runtime.Text.PyString:FromString(System.String,Lokad.Lython.Runtime.MemoryGovernor,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.Text.PyString]
       mov      gword ptr [rbp-0x120], rax
       lea      rcx, [rbp-0x118]
       mov      rdx, 0xD1FFAB1E
       call     [System.Collections.Generic.KeyValuePair`2[System.__Canon,System.__Canon]:get_Value():System.__Canon:this]
       mov      gword ptr [rbp-0x2A8], rax
       mov      r8, gword ptr [rbp-0x2A8]
       mov      rdx, gword ptr [rbp-0x120]
       mov      rcx, gword ptr [rbp-0xD8]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.PyDict:SetItem(System.Object,System.Object):this]
 
G_M000_IG61:
       mov      eax, dword ptr [rbp-0x20C]
       dec      eax
       mov      dword ptr [rbp-0x20C], eax
       cmp      dword ptr [rbp-0x20C], 0
       jg       SHORT G_M000_IG63
 
G_M000_IG62:
       lea      rcx, [rbp-0x20C]
       mov      edx, 937
       call     CORINFO_HELP_PATCHPOINT
       jmp      rax
 
G_M000_IG63:
       lea      rcx, [rbp-0x108]
       mov      rdx, 0xD1FFAB1E
       call     [System.Collections.Generic.Dictionary`2+Enumerator[System.__Canon,System.__Canon]:MoveNext():bool:this]
       test     eax, eax
       jne      G_M000_IG60
       mov      rcx, 0xD1FFAB1E
       call     CORINFO_HELP_COUNTPROFILE32
       nop      
 
G_M000_IG64:
       call     G_M000_IG69
       nop      
 
G_M000_IG65:
       mov      rcx, 0xD1FFAB1E
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, gword ptr [rbp+0x30]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_VariadicDictionaryIndex():int:this]
       mov      dword ptr [rbp-0xDC], eax
       mov      rax, bword ptr [rbp+0x10]
       mov      eax, dword ptr [rax+0x08]
       cmp      dword ptr [rbp-0xDC], eax
       jae      SHORT G_M000_IG68
       mov      rax, bword ptr [rbp+0x10]
       mov      rax, bword ptr [rax]
       mov      ecx, dword ptr [rbp-0xDC]
       lea      rcx, bword ptr [rax+8*rcx]
       mov      rdx, gword ptr [rbp-0xD8]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rcx, bword ptr [rbp+0x18]
       mov      edx, dword ptr [rbp-0xDC]
       mov      r8d, 1
       call     [Lokad.Lython.Runtime.ArgumentPresence:set_Item(int,bool):this]
 
G_M000_IG66:
       mov      rcx, 0xD1FFAB1E
       call     CORINFO_HELP_COUNTPROFILE32
       nop      
 
G_M000_IG67:
       add      rsp, 720
       pop      rbp
       ret      
 
G_M000_IG68:
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG69:
       sub      rsp, 40
 
G_M000_IG70:
       mov      rcx, 0xD1FFAB1E
       call     CORINFO_HELP_COUNTPROFILE32
       lea      rcx, [rbp-0x108]
       mov      rdx, 0xD1FFAB1E
       call     [System.Collections.Generic.Dictionary`2+Enumerator[System.__Canon,System.__Canon]:Dispose():this]
       nop      
 
G_M000_IG71:
       add      rsp, 40
       ret      
 
; Total bytes of code 3781

; Assembly listing for method Lokad.Lython.Runtime.PyExecutableFunction:StartNativeCall(Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[System.Object],System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,bool,bool,System.Span`1[System.Object],byref,byref,byref):this (Instrumented Tier0)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; Instrumented Tier0 code
; rbp based frame
; partially interruptible
; compiling with minopt

G_M000_IG01:
       push     rbp
       sub      rsp, 656
       lea      rbp, [rsp+0x290]
       xor      eax, eax
       mov      qword ptr [rbp-0x238], rax
       vxorps   xmm4, xmm4, xmm4
       vmovdqa  xmmword ptr [rbp-0x230], xmm4
       mov      rax, -480
 
G_M000_IG27:
       vmovdqa  xmmword ptr [rbp+rax-0x40], xmm4
       vmovdqa  xmmword ptr [rbp+rax-0x30], xmm4
       vmovdqa  xmmword ptr [rbp+rax-0x20], xmm4
       add      rax, 48
       jne      SHORT G_M000_IG27
       mov      qword ptr [rbp-0x40], rax
       mov      gword ptr [rbp+0x10], rcx
       mov      gword ptr [rbp+0x18], rdx
       mov      bword ptr [rbp+0x20], r8
       mov      gword ptr [rbp+0x28], r9
 
G_M000_IG02:
       mov      dword ptr [rbp-0x174], 0x3E8
       vxorps   ymm0, ymm0, ymm0
       vmovdqu  ymmword ptr [rbp-0xB8], ymm0
       vmovdqu  ymmword ptr [rbp-0x98], ymm0
       vmovdqu  ymmword ptr [rbp-0x78], ymm0
       vmovdqu  ymmword ptr [rbp-0x58], ymm0
       lea      r8, [rbp-0xB8]
       lea      rcx, [rbp-0xC8]
       mov      rdx, 0xD1FFAB1E
       mov      r9d, 16
       call     [<PrivateImplementationDetails>:InlineArrayAsSpan[Lokad.Lython.Runtime.PyExecutableFunction+NativeValues,System.__Canon](byref,int):System.Span`1[System.__Canon]]
       mov      rax, gword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax+0x68]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_ValueStorageCapacity():int:this]
       mov      dword ptr [rbp-0x178], eax
       mov      eax, dword ptr [rbp-0x178]
       mov      dword ptr [rsp+0x20], eax
       lea      rcx, [rbp-0xC8]
       lea      rdx, [rbp-0xC8]
       mov      r8, 0xD1FFAB1E
       xor      r9d, r9d
       call     [System.Span`1[System.__Canon]:Slice(int,int):System.Span`1[System.__Canon]:this]
       mov      rcx, gword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.PyFunctionBase:get_BindingPlan():Lokad.Lython.Runtime.FunctionBindingPlan:this]
       mov      rcx, rax
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_ParameterCount():int:this]
       mov      dword ptr [rbp-0x17C], eax
       mov      edx, dword ptr [rbp-0x17C]
       lea      rcx, [rbp-0xE0]
       call     [Lokad.Lython.Runtime.ArgumentPresence:.ctor(int):this]
       movzx    rax, byte  ptr [rbp+0x48]
       test     eax, eax
       je       G_M000_IG09
 
G_M000_IG03:
       vmovdqu  xmm0, xmmword ptr [rbp-0xC8]
       vmovdqu  xmmword ptr [rbp-0x190], xmm0
 
G_M000_IG04:
       lea      r8, [rbp-0x190]
       mov      rcx, bword ptr [rbp+0x20]
       mov      rdx, 0xD1FFAB1E
       call     [System.ReadOnlySpan`1[System.__Canon]:CopyTo(System.Span`1[System.__Canon]):this]
       xor      eax, eax
       mov      dword ptr [rbp-0xE4], eax
       jmp      SHORT G_M000_IG06
 
G_M000_IG05:
       mov      rcx, 0xD1FFAB1E
       call     CORINFO_HELP_COUNTPROFILE32
       lea      rcx, [rbp-0xE0]
       mov      edx, dword ptr [rbp-0xE4]
       mov      r8d, 1
       call     [Lokad.Lython.Runtime.ArgumentPresence:set_Item(int,bool):this]
       mov      eax, dword ptr [rbp-0xE4]
       inc      eax
       mov      dword ptr [rbp-0xE4], eax
 
G_M000_IG06:
       mov      eax, dword ptr [rbp-0x174]
       dec      eax
       mov      dword ptr [rbp-0x174], eax
       cmp      dword ptr [rbp-0x174], 0
       jg       SHORT G_M000_IG08
 
G_M000_IG07:
       lea      rcx, [rbp-0x174]
       mov      edx, 85
       call     CORINFO_HELP_PATCHPOINT
       jmp      rax
 
G_M000_IG08:
       lea      rcx, [rbp-0xE0]
       call     [Lokad.Lython.Runtime.ArgumentPresence:get_Length():int:this]
       cmp      eax, dword ptr [rbp-0xE4]
       jg       SHORT G_M000_IG05
       jmp      G_M000_IG16
 
G_M000_IG09:
       mov      rcx, 0xD1FFAB1E
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, gword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.PyFunctionBase:get_BindingPlan():Lokad.Lython.Runtime.FunctionBindingPlan:this]
       mov      rcx, rax
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_ParameterCount():int:this]
       mov      dword ptr [rbp-0x194], eax
       mov      eax, dword ptr [rbp-0x194]
       mov      dword ptr [rsp+0x20], eax
       lea      rcx, [rbp-0xC8]
       lea      rdx, [rbp-0x138]
       mov      r8, 0xD1FFAB1E
       xor      r9d, r9d
       call     [System.Span`1[System.__Canon]:Slice(int,int):System.Span`1[System.__Canon]:this]
       vxorps   xmm0, xmm0, xmm0
       vmovdqu  xmmword ptr [rbp-0xF8], xmm0
 
G_M000_IG10:
       vmovdqu  xmm0, xmmword ptr [rbp-0xF8]
       vmovdqu  xmmword ptr [rbp-0x148], xmm0
 
G_M000_IG11:
       vmovdqu  xmm0, xmmword ptr [rbp-0x138]
       vmovdqu  xmmword ptr [rbp-0x1A8], xmm0
 
G_M000_IG12:
       vmovdqu  xmm0, xmmword ptr [rbp-0x148]
       vmovdqu  xmmword ptr [rbp-0x1B8], xmm0
 
G_M000_IG13:
       mov      rcx, gword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.PyFunctionBase:get_BindingPlan():Lokad.Lython.Runtime.FunctionBindingPlan:this]
       mov      gword ptr [rbp-0x1D0], rax
       mov      rax, gword ptr [rbp+0x30]
       mov      gword ptr [rsp+0x28], rax
       xor      eax, eax
       mov      dword ptr [rsp+0x30], eax
       mov      rax, gword ptr [rbp+0x28]
       mov      gword ptr [rsp+0x38], rax
       mov      rax, gword ptr [rbp+0x18]
       mov      gword ptr [rsp+0x40], rax
       mov      rax, bword ptr [rbp+0x20]
 
G_M000_IG14:
       vmovdqu  xmm0, xmmword ptr [rax]
       vmovdqu  xmmword ptr [rbp-0x1C8], xmm0
 
G_M000_IG15:
       mov      rax, gword ptr [rbp-0x1D0]
       mov      gword ptr [rsp+0x20], rax
       lea      r8, [rbp-0x1B8]
       lea      rcx, [rbp-0x1A8]
       lea      rax, [rbp-0x1C8]
       mov      qword ptr [rsp+0x48], rax
       lea      rdx, [rbp-0xE0]
       mov      r9, gword ptr [rbp+0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime:BindFunctionArgumentsInto(System.Span`1[System.Object],byref,System.ReadOnlySpan`1[Lokad.Lython.Runtime.CallArgumentValue],Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.FunctionBindingPlan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,bool,System.Object,Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[System.Object])]
 
G_M000_IG16:
       mov      rcx, 0xD1FFAB1E
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG17:
       vmovdqu  xmm0, xmmword ptr [rbp-0xC8]
       vmovdqu  xmmword ptr [rbp-0x158], xmm0
 
G_M000_IG18:
       vmovdqu  xmm0, xmmword ptr [rbp-0xE0]
       vmovdqu  xmmword ptr [rbp-0x170], xmm0
       mov      rax, qword ptr [rbp-0xD0]
       mov      qword ptr [rbp-0x160], rax
 
G_M000_IG19:
       vxorps   ymm0, ymm0, ymm0
       vmovdqu  ymmword ptr [rbp-0x128], ymm0
       vmovdqu  xmmword ptr [rbp-0x108], xmm0
 
G_M000_IG20:
       vmovdqu  xmm0, xmmword ptr [rbp-0x158]
       vmovdqu  xmmword ptr [rbp-0x1E0], xmm0
 
G_M000_IG21:
       vmovdqu  xmm0, xmmword ptr [rbp-0x170]
       vmovdqu  xmmword ptr [rbp-0x1F8], xmm0
       mov      rax, qword ptr [rbp-0x160]
       mov      qword ptr [rbp-0x1E8], rax
 
G_M000_IG22:
       vmovdqu  ymm0, ymmword ptr [rbp-0x128]
       vmovdqu  ymmword ptr [rbp-0x228], ymm0
       vmovdqu  xmm0, xmmword ptr [rbp-0x108]
       vmovdqu  xmmword ptr [rbp-0x208], xmm0
 
G_M000_IG23:
       mov      rax, gword ptr [rbp+0x38]
       mov      gword ptr [rsp+0x20], rax
       movzx    rax, byte  ptr [rbp+0x40]
       mov      dword ptr [rsp+0x28], eax
       mov      rax, bword ptr [rbp+0x50]
 
G_M000_IG24:
       vmovdqu  xmm0, xmmword ptr [rax]
       vmovdqu  xmmword ptr [rbp-0x238], xmm0
 
G_M000_IG25:
       mov      rax, bword ptr [rbp+0x58]
       mov      bword ptr [rsp+0x38], rax
       mov      rax, bword ptr [rbp+0x60]
       mov      bword ptr [rsp+0x40], rax
       mov      rax, bword ptr [rbp+0x68]
       mov      bword ptr [rsp+0x48], rax
       lea      rdx, [rbp-0x1E0]
       lea      r8, [rbp-0x1F8]
       lea      r9, [rbp-0x228]
       lea      rax, [rbp-0x238]
       mov      qword ptr [rsp+0x30], rax
       mov      rcx, gword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.PyExecutableFunction:StartInline(System.Span`1[System.Object],Lokad.Lython.Runtime.ArgumentPresence,System.Nullable`1[Lokad.Lython.Runtime.BoundCallArguments],Lokad.Lython.LythonSourceSpan,bool,System.Span`1[System.Object],byref,byref,byref):this]
       nop      
 
G_M000_IG26:
       vzeroupper 
       add      rsp, 656
       pop      rbp
       ret      
 
; Total bytes of code 1006

; Assembly listing for method Lokad.Lython.Runtime.LythonRuntime:BindFunctionArgumentsInto(System.Span`1[System.Object],byref,System.ReadOnlySpan`1[Lokad.Lython.Runtime.CallArgumentValue],Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.FunctionBindingPlan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,bool,System.Object,Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[System.Object]) (Instrumented Tier0)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; Instrumented Tier0 code
; rbp based frame
; fully interruptible
; compiling with minopt

G_M000_IG01:
       push     rbp
       sub      rsp, 720
       lea      rbp, [rsp+0x2D0]
       xor      eax, eax
       mov      qword ptr [rbp-0x2A8], rax
       vxorps   xmm4, xmm4, xmm4
       vmovdqa  xmmword ptr [rbp-0x2A0], xmm4
       vmovdqa  xmmword ptr [rbp-0x290], xmm4
       mov      rax, -576
 
G_M000_IG72:
       vmovdqa  xmmword ptr [rbp+rax-0x40], xmm4
       vmovdqa  xmmword ptr [rbp+rax-0x30], xmm4
       vmovdqa  xmmword ptr [rbp+rax-0x20], xmm4
       add      rax, 48
       jne      SHORT G_M000_IG72
       mov      qword ptr [rbp-0x40], rax
       mov      bword ptr [rbp+0x10], rcx
       mov      bword ptr [rbp+0x18], rdx
       mov      bword ptr [rbp+0x20], r8
       mov      gword ptr [rbp+0x28], r9
 
G_M000_IG02:
       mov      dword ptr [rbp-0x20C], 0x3E8
       xor      rax, rax
       mov      gword ptr [rbp-0x40], rax
       xor      rax, rax
       mov      gword ptr [rbp-0x48], rax
       xor      eax, eax
       mov      dword ptr [rbp-0x4C], eax
       cmp      gword ptr [rbp+0x50], 0
       jne      SHORT G_M000_IG03
       mov      rax, bword ptr [rbp+0x20]
       mov      eax, dword ptr [rax+0x08]
       mov      dword ptr [rbp-0x124], eax
       jmp      SHORT G_M000_IG04
 
G_M000_IG03:
       mov      rcx, 0xD1FFAB1E
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, gword ptr [rbp+0x50]
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_ArgumentCount():int:this]
       mov      dword ptr [rbp-0x124], eax
 
G_M000_IG04:
       mov      eax, dword ptr [rbp-0x124]
       mov      dword ptr [rbp-0x50], eax
       cmp      gword ptr [rbp+0x48], 0
       je       SHORT G_M000_IG05
       mov      dword ptr [rbp-0x128], -1
       jmp      SHORT G_M000_IG06
 
G_M000_IG05:
       mov      rcx, 0xD1FFAB1E
       call     CORINFO_HELP_COUNTPROFILE32
       xor      eax, eax
       mov      dword ptr [rbp-0x128], eax
 
G_M000_IG06:
       mov      eax, dword ptr [rbp-0x128]
       mov      dword ptr [rbp-0x54], eax
       jmp      G_M000_IG34
 
G_M000_IG07:
       cmp      dword ptr [rbp-0x54], 0
       jl       G_M000_IG14
       cmp      gword ptr [rbp+0x50], 0
       je       G_M000_IG11
       mov      rcx, gword ptr [rbp+0x50]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_Arguments():Lokad.Lython.Frontend.CallArgumentForm[]:this]
       mov      ecx, dword ptr [rbp-0x54]
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG68
       mov      edx, ecx
       imul     rdx, rdx, 16
       lea      rax, bword ptr [rax+rdx+0x10]
 
G_M000_IG08:
       vmovdqu  xmm0, xmmword ptr [rax]
       vmovdqu  xmmword ptr [rbp-0x1A0], xmm0
 
G_M000_IG09:
       vmovdqu  xmm0, xmmword ptr [rbp-0x1A0]
       vmovdqu  xmmword ptr [rbp-0x220], xmm0
 
G_M000_IG10:
       mov      rax, bword ptr [rbp+0x58]
       mov      eax, dword ptr [rax+0x08]
       cmp      dword ptr [rbp-0x54], eax
       jae      G_M000_IG68
       mov      rax, bword ptr [rbp+0x58]
       mov      rax, bword ptr [rax]
       mov      ecx, dword ptr [rbp-0x54]
       mov      rdx, gword ptr [rax+8*rcx]
       mov      rcx, 0xD1FFAB1E
       call     [Lokad.Lython.Internal.NullabilityExtensions:RequireNotNull[System.__Canon](System.__Canon):System.__Canon]
       mov      gword ptr [rbp-0x228], rax
       mov      r8, gword ptr [rbp-0x228]
       lea      rdx, [rbp-0x220]
       lea      rcx, [rbp-0x140]
       call     [Lokad.Lython.Runtime.LythonRuntime:CreateExecutableCallArgument(Lokad.Lython.Frontend.CallArgumentForm,System.Object):Lokad.Lython.Runtime.CallArgumentValue]
       jmp      SHORT G_M000_IG15
 
G_M000_IG11:
       mov      rcx, 0xD1FFAB1E
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x20]
       mov      eax, dword ptr [rax+0x08]
       cmp      dword ptr [rbp-0x54], eax
       jae      G_M000_IG68
       mov      rax, bword ptr [rbp+0x20]
       mov      rax, bword ptr [rax]
       mov      ecx, dword ptr [rbp-0x54]
       lea      rcx, [rcx+2*rcx]
 
G_M000_IG12:
       vmovdqu  xmm0, xmmword ptr [rax+8*rcx]
       vmovdqu  xmmword ptr [rbp-0x140], xmm0
       mov      rdx, qword ptr [rax+8*rcx+0x10]
       mov      qword ptr [rbp-0x130], rdx
 
G_M000_IG13:
       jmp      SHORT G_M000_IG15
 
G_M000_IG14:
       mov      rcx, 0xD1FFAB1E
       call     CORINFO_HELP_COUNTPROFILE32
       lea      rcx, [rbp-0x140]
       mov      rdx, gword ptr [rbp+0x48]
       call     [Lokad.Lython.Runtime.CallArgumentValue:Positional(System.Object):Lokad.Lython.Runtime.CallArgumentValue]
 
G_M000_IG15:
       vmovdqu  xmm0, xmmword ptr [rbp-0x140]
       vmovdqu  xmmword ptr [rbp-0x70], xmm0
       mov      rax, qword ptr [rbp-0x130]
       mov      qword ptr [rbp-0x60], rax
 
G_M000_IG16:
       lea      rcx, [rbp-0x70]
       call     [Lokad.Lython.Runtime.CallArgumentValue:get_IsPositional():bool:this]
       test     eax, eax
       je       G_M000_IG21
       mov      rcx, gword ptr [rbp+0x30]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_PositionalCount():int:this]
       cmp      eax, dword ptr [rbp-0x4C]
       jg       G_M000_IG20
       mov      rcx, gword ptr [rbp+0x30]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_VariadicListIndex():int:this]
       test     eax, eax
       jge      SHORT G_M000_IG18
 
G_M000_IG17:
       mov      rcx, gword ptr [rbp+0x30]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_CallableKind():int:this]
       mov      dword ptr [rbp-0x18C], eax
       mov      rcx, gword ptr [rbp+0x30]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_CallableName():System.String:this]
       mov      gword ptr [rbp-0x230], rax
       mov      rdx, gword ptr [rbp-0x230]
       mov      ecx, dword ptr [rbp-0x18C]
       mov      r8, gword ptr [rbp+0x28]
       call     [Lokad.Lython.Runtime.CallErrors:TooManyPositional(int,System.String,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.LythonRuntimeException]
       mov      rcx, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG18:
       cmp      gword ptr [rbp-0x40], 0
       jne      SHORT G_M000_IG19
       mov      rcx, 0xD1FFAB1E
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, 0xD1FFAB1E
       call     [System.Array:Empty[System.__Canon]():System.__Canon[]]
       mov      gword ptr [rbp-0x180], rax
       mov      rcx, 0xD1FFAB1E
       call     CORINFO_HELP_NEWSFAST
       mov      gword ptr [rbp-0x188], rax
       mov      rcx, gword ptr [rbp+0x38]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:get_MemoryGovernor():Lokad.Lython.Runtime.MemoryGovernor:this]
       mov      gword ptr [rbp-0x238], rax
       mov      r8, gword ptr [rbp-0x238]
       mov      rdx, gword ptr [rbp-0x180]
       mov      rcx, gword ptr [rbp-0x188]
       mov      r9, gword ptr [rbp+0x28]
       call     [Lokad.Lython.Runtime.PyList:.ctor(System.Collections.Generic.IEnumerable`1[System.Object],Lokad.Lython.Runtime.MemoryGovernor,Lokad.Lython.LythonSourceSpan):this]
       mov      rax, gword ptr [rbp-0x188]
       mov      gword ptr [rbp-0x40], rax
 
G_M000_IG19:
       lea      rcx, [rbp-0x70]
       call     [Lokad.Lython.Runtime.CallArgumentValue:get_Value():System.Object:this]
       mov      gword ptr [rbp-0x240], rax
       mov      rdx, gword ptr [rbp-0x240]
       mov      rcx, gword ptr [rbp-0x40]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.PyList:Add(System.Object):this]
       jmp      G_M000_IG33
 
G_M000_IG20:
       mov      rcx, 0xD1FFAB1E
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x10]
       mov      eax, dword ptr [rax+0x08]
       cmp      dword ptr [rbp-0x4C], eax
       jae      G_M000_IG68
       mov      rax, bword ptr [rbp+0x10]
       mov      rax, bword ptr [rax]
       mov      ecx, dword ptr [rbp-0x4C]
       lea      rax, bword ptr [rax+8*rcx]
       mov      bword ptr [rbp-0x178], rax
       lea      rcx, [rbp-0x70]
       call     [Lokad.Lython.Runtime.CallArgumentValue:get_Value():System.Object:this]
       mov      rdx, rax
       mov      rcx, bword ptr [rbp-0x178]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rcx, bword ptr [rbp+0x18]
       mov      edx, dword ptr [rbp-0x4C]
       mov      r8d, 1
       call     [Lokad.Lython.Runtime.ArgumentPresence:set_Item(int,bool):this]
       mov      eax, dword ptr [rbp-0x4C]
       inc      eax
       mov      dword ptr [rbp-0x4C], eax
       jmp      G_M000_IG33
 
G_M000_IG21:
       lea      rcx, [rbp-0x70]
       call     [Lokad.Lython.Runtime.CallArgumentValue:get_KeywordName():System.String:this]
       mov      gword ptr [rbp-0x78], rax
       mov      rcx, gword ptr [rbp+0x30]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_LayoutParameterIndex():System.Collections.Generic.IReadOnlyDictionary`2[System.String,int]:this]
       mov      gword ptr [rbp-0x208], rax
       mov      rcx, gword ptr [rbp-0x208]
       mov      rdx, 0xD1FFAB1E
       call     CORINFO_HELP_CLASSPROFILE32
       mov      rax, gword ptr [rbp-0x208]
       mov      gword ptr [rbp-0x248], rax
       mov      rcx, gword ptr [rbp-0x248]
       lea      r8, [rbp-0x80]
       mov      rdx, gword ptr [rbp-0x78]
       mov      r11, 0xD1FFAB1E
       call     [r11]System.Collections.Generic.IReadOnlyDictionary`2[System.__Canon,int]:TryGetValue(System.__Canon,byref):bool:this
       test     eax, eax
       je       SHORT G_M000_IG23
       mov      eax, dword ptr [rbp-0x80]
       mov      dword ptr [rbp-0x158], eax
       mov      rcx, gword ptr [rbp+0x30]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_NamedLayoutCount():int:this]
       cmp      eax, dword ptr [rbp-0x158]
       jle      G_M000_IG25
       mov      eax, dword ptr [rbp-0x80]
       mov      dword ptr [rbp-0x15C], eax
       mov      rcx, gword ptr [rbp+0x30]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_PositionalOnlyCount():int:this]
       cmp      eax, dword ptr [rbp-0x15C]
       jle      G_M000_IG30
 
G_M000_IG22:
       mov      rcx, 0xD1FFAB1E
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG23:
       mov      rcx, gword ptr [rbp+0x30]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_VariadicDictionaryIndex():int:this]
       test     eax, eax
       jge      SHORT G_M000_IG26
 
G_M000_IG24:
       mov      rcx, gword ptr [rbp+0x30]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_CallableKind():int:this]
       mov      dword ptr [rbp-0x154], eax
       mov      rcx, gword ptr [rbp+0x30]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_CallableName():System.String:this]
       mov      gword ptr [rbp-0x250], rax
       mov      rdx, gword ptr [rbp-0x250]
       mov      ecx, dword ptr [rbp-0x154]
       mov      r8, gword ptr [rbp-0x78]
       mov      r9, gword ptr [rbp+0x28]
       call     [Lokad.Lython.Runtime.CallErrors:UnexpectedKeyword(int,System.String,System.String,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.LythonRuntimeException]
       mov      rcx, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG25:
       mov      rcx, 0xD1FFAB1E
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG23
 
G_M000_IG26:
       cmp      gword ptr [rbp-0x48], 0
       jne      SHORT G_M000_IG27
       mov      rcx, 0xD1FFAB1E
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, 0xD1FFAB1E
       call     CORINFO_HELP_NEWSFAST
       mov      gword ptr [rbp-0x150], rax
       call     [System.StringComparer:get_Ordinal():System.StringComparer]
       mov      gword ptr [rbp-0x258], rax
       mov      rdx, gword ptr [rbp-0x258]
       mov      rcx, gword ptr [rbp-0x150]
       call     [System.Collections.Generic.Dictionary`2[System.__Canon,System.__Canon]:.ctor(System.Collections.Generic.IEqualityComparer`1[System.__Canon]):this]
       mov      rax, gword ptr [rbp-0x150]
       mov      gword ptr [rbp-0x48], rax
 
G_M000_IG27:
       lea      rcx, [rbp-0x70]
       call     [Lokad.Lython.Runtime.CallArgumentValue:get_Value():System.Object:this]
       mov      gword ptr [rbp-0x260], rax
       mov      r8, gword ptr [rbp-0x260]
       mov      rdx, gword ptr [rbp-0x78]
       mov      rcx, gword ptr [rbp-0x48]
       cmp      dword ptr [rcx], ecx
       call     [System.Collections.Generic.Dictionary`2[System.__Canon,System.__Canon]:TryAdd(System.__Canon,System.__Canon):bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG29
 
G_M000_IG28:
       mov      rcx, gword ptr [rbp+0x30]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_CallableKind():int:this]
       mov      dword ptr [rbp-0x144], eax
       mov      rcx, gword ptr [rbp+0x30]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_CallableName():System.String:this]
       mov      gword ptr [rbp-0x268], rax
       mov      rdx, gword ptr [rbp-0x268]
       mov      ecx, dword ptr [rbp-0x144]
       mov      r8, gword ptr [rbp-0x78]
       mov      r9, gword ptr [rbp+0x28]
       call     [Lokad.Lython.Runtime.CallErrors:MultipleValues(int,System.String,System.String,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.LythonRuntimeException]
       mov      rcx, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG29:
       mov      rcx, 0xD1FFAB1E
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG33
 
G_M000_IG30:
       mov      rcx, bword ptr [rbp+0x18]
       mov      edx, dword ptr [rbp-0x80]
       call     [Lokad.Lython.Runtime.ArgumentPresence:get_Item(int):bool:this]
       test     eax, eax
       je       SHORT G_M000_IG32
 
G_M000_IG31:
       mov      rcx, gword ptr [rbp+0x30]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_CallableKind():int:this]
       mov      dword ptr [rbp-0x16C], eax
       mov      rcx, gword ptr [rbp+0x30]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_CallableName():System.String:this]
       mov      gword ptr [rbp-0x270], rax
       mov      rdx, gword ptr [rbp-0x270]
       mov      ecx, dword ptr [rbp-0x16C]
       mov      r8, gword ptr [rbp-0x78]
       mov      r9, gword ptr [rbp+0x28]
       call     [Lokad.Lython.Runtime.CallErrors:MultipleValues(int,System.String,System.String,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.LythonRuntimeException]
       mov      rcx, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG32:
       mov      rcx, 0xD1FFAB1E
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x10]
       mov      eax, dword ptr [rax+0x08]
       cmp      dword ptr [rbp-0x80], eax
       jae      G_M000_IG68
       mov      rax, bword ptr [rbp+0x10]
       mov      rax, bword ptr [rax]
       mov      ecx, dword ptr [rbp-0x80]
       lea      rax, bword ptr [rax+8*rcx]
       mov      bword ptr [rbp-0x168], rax
       lea      rcx, [rbp-0x70]
       call     [Lokad.Lython.Runtime.CallArgumentValue:get_Value():System.Object:this]
       mov      rdx, rax
       mov      rcx, bword ptr [rbp-0x168]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rcx, bword ptr [rbp+0x18]
       mov      edx, dword ptr [rbp-0x80]
       mov      r8d, 1
       call     [Lokad.Lython.Runtime.ArgumentPresence:set_Item(int,bool):this]
 
G_M000_IG33:
       mov      rcx, 0xD1FFAB1E
       call     CORINFO_HELP_COUNTPROFILE32
       mov      eax, dword ptr [rbp-0x54]
       inc      eax
       mov      dword ptr [rbp-0x54], eax
 
G_M000_IG34:
       mov      eax, dword ptr [rbp-0x20C]
       dec      eax
       mov      dword ptr [rbp-0x20C], eax
       cmp      dword ptr [rbp-0x20C], 0
       jg       SHORT G_M000_IG36
 
G_M000_IG35:
       lea      rcx, [rbp-0x20C]
       mov      edx, 436
       call     CORINFO_HELP_PATCHPOINT
       jmp      rax
 
G_M000_IG36:
       mov      eax, dword ptr [rbp-0x54]
       cmp      eax, dword ptr [rbp-0x50]
       jl       G_M000_IG07
       xor      eax, eax
       mov      dword ptr [rbp-0x84], eax
       jmp      G_M000_IG40
 
G_M000_IG37:
       mov      rcx, bword ptr [rbp+0x18]
       mov      edx, dword ptr [rbp-0x84]
       call     [Lokad.Lython.Runtime.ArgumentPresence:get_Item(int):bool:this]
       test     eax, eax
       jne      G_M000_IG39
       mov      rcx, gword ptr [rbp+0x30]
       mov      edx, dword ptr [rbp-0x84]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:NameAt(int):System.String:this]
       mov      gword ptr [rbp-0x90], rax
       lea      r8, [rbp-0x98]
       mov      rcx, gword ptr [rbp+0x30]
       mov      edx, dword ptr [rbp-0x84]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:TryGetPositionalDefault(int,byref):bool:this]
       test     eax, eax
       je       SHORT G_M000_IG38
       mov      rcx, 0xD1FFAB1E
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x10]
       mov      eax, dword ptr [rax+0x08]
       cmp      dword ptr [rbp-0x84], eax
       jae      G_M000_IG68
       mov      rax, bword ptr [rbp+0x10]
       mov      rax, bword ptr [rax]
       mov      ecx, dword ptr [rbp-0x84]
       lea      rcx, bword ptr [rax+8*rcx]
       mov      rdx, gword ptr [rbp-0x98]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       jmp      SHORT G_M000_IG39
 
G_M000_IG38:
       mov      rcx, gword ptr [rbp+0x30]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_CallableKind():int:this]
       mov      dword ptr [rbp-0x1A4], eax
       mov      rcx, gword ptr [rbp+0x30]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_CallableName():System.String:this]
       mov      gword ptr [rbp-0x278], rax
       mov      rdx, gword ptr [rbp-0x278]
       mov      ecx, dword ptr [rbp-0x1A4]
       mov      r8, gword ptr [rbp-0x90]
       mov      r9, gword ptr [rbp+0x28]
       call     [Lokad.Lython.Runtime.CallErrors:MissingArgument(int,System.String,System.String,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.LythonRuntimeException]
       mov      rcx, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG39:
       mov      rcx, 0xD1FFAB1E
       call     CORINFO_HELP_COUNTPROFILE32
       mov      eax, dword ptr [rbp-0x84]
       inc      eax
       mov      dword ptr [rbp-0x84], eax
 
G_M000_IG40:
       mov      eax, dword ptr [rbp-0x20C]
       dec      eax
       mov      dword ptr [rbp-0x20C], eax
       cmp      dword ptr [rbp-0x20C], 0
       jg       SHORT G_M000_IG42
 
G_M000_IG41:
       lea      rcx, [rbp-0x20C]
       mov      edx, 526
       call     CORINFO_HELP_PATCHPOINT
       jmp      rax
 
G_M000_IG42:
       mov      rcx, gword ptr [rbp+0x30]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_PositionalCount():int:this]
       cmp      eax, dword ptr [rbp-0x84]
       jg       G_M000_IG37
       xor      eax, eax
       mov      dword ptr [rbp-0x9C], eax
       jmp      G_M000_IG48
 
G_M000_IG43:
       mov      rcx, gword ptr [rbp+0x30]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_PositionalCount():int:this]
       add      eax, dword ptr [rbp-0x9C]
       mov      dword ptr [rbp-0xA0], eax
       mov      rcx, bword ptr [rbp+0x18]
       mov      edx, dword ptr [rbp-0xA0]
       call     [Lokad.Lython.Runtime.ArgumentPresence:get_Item(int):bool:this]
       test     eax, eax
       jne      G_M000_IG47
       mov      rcx, gword ptr [rbp+0x30]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_PositionalCount():int:this]
       add      eax, dword ptr [rbp-0x9C]
       mov      dword ptr [rbp-0x27C], eax
       mov      edx, dword ptr [rbp-0x27C]
       mov      rcx, gword ptr [rbp+0x30]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:NameAt(int):System.String:this]
       mov      gword ptr [rbp-0xA8], rax
       mov      rcx, gword ptr [rbp+0x30]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_KeywordDefaultStorage():Lokad.Lython.Runtime.PyDict:this]
       mov      gword ptr [rbp-0xB0], rax
       cmp      gword ptr [rbp-0xB0], 0
       je       G_M000_IG46
       mov      rcx, gword ptr [rbp+0x30]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_KeywordDefaultNames():Lokad.Lython.Runtime.Text.PyString[]:this]
       mov      ecx, dword ptr [rbp-0x9C]
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG68
       mov      edx, ecx
       lea      rax, bword ptr [rax+8*rdx+0x10]
       mov      rax, gword ptr [rax]
       mov      gword ptr [rbp-0x288], rax
       mov      rax, gword ptr [rbp+0x28]
       mov      gword ptr [rsp+0x20], rax
       mov      rdx, gword ptr [rbp-0x288]
       lea      r8, [rbp-0xB8]
       mov      rcx, gword ptr [rbp-0xB0]
       mov      r9, gword ptr [rbp+0x38]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.PyDict:TryGetValue(System.Object,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):bool:this]
       test     eax, eax
       je       SHORT G_M000_IG45
       mov      rcx, 0xD1FFAB1E
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x10]
       mov      eax, dword ptr [rax+0x08]
       cmp      dword ptr [rbp-0xA0], eax
       jae      G_M000_IG68
       mov      rax, bword ptr [rbp+0x10]
 
G_M000_IG44:
       mov      rax, bword ptr [rax]
       mov      ecx, dword ptr [rbp-0xA0]
       lea      rcx, bword ptr [rax+8*rcx]
       mov      rdx, gword ptr [rbp-0xB8]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       jmp      SHORT G_M000_IG47
 
G_M000_IG45:
       mov      rcx, 0xD1FFAB1E
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG46:
       mov      rcx, gword ptr [rbp+0x30]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_CallableKind():int:this]
       mov      dword ptr [rbp-0x200], eax
       mov      rcx, gword ptr [rbp+0x30]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_CallableName():System.String:this]
       mov      gword ptr [rbp-0x290], rax
       mov      rdx, gword ptr [rbp-0x290]
       mov      ecx, dword ptr [rbp-0x200]
       mov      r8, gword ptr [rbp-0xA8]
       mov      r9, gword ptr [rbp+0x28]
       call     [Lokad.Lython.Runtime.CallErrors:MissingArgument(int,System.String,System.String,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.LythonRuntimeException]
       mov      rcx, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG47:
       mov      rcx, 0xD1FFAB1E
       call     CORINFO_HELP_COUNTPROFILE32
       mov      eax, dword ptr [rbp-0x9C]
       inc      eax
       mov      dword ptr [rbp-0x9C], eax
 
G_M000_IG48:
       movzx    rax, byte  ptr [rbp+0x40]
       test     eax, eax
       jne      SHORT G_M000_IG52
       mov      eax, dword ptr [rbp-0x20C]
       dec      eax
       mov      dword ptr [rbp-0x20C], eax
       cmp      dword ptr [rbp-0x20C], 0
       jg       SHORT G_M000_IG50
 
G_M000_IG49:
       lea      rcx, [rbp-0x20C]
       mov      edx, 667
       call     CORINFO_HELP_PATCHPOINT
       jmp      rax
 
G_M000_IG50:
       mov      rcx, gword ptr [rbp+0x30]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_KeywordOnlyCount():int:this]
       cmp      eax, dword ptr [rbp-0x9C]
       jg       G_M000_IG43
 
G_M000_IG51:
       mov      rcx, 0xD1FFAB1E
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG52:
       mov      rcx, gword ptr [rbp+0x30]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_VariadicListIndex():int:this]
       test     eax, eax
       jl       G_M000_IG58
       mov      rcx, 0xD1FFAB1E
       call     CORINFO_HELP_NEWSFAST
       mov      gword ptr [rbp-0x1C0], rax
       mov      rcx, gword ptr [rbp-0x1C0]
       call     [Lokad.Lython.Runtime.LythonRuntime+<>c__DisplayClass333_0:.ctor():this]
       mov      rax, gword ptr [rbp-0x1C0]
       mov      gword ptr [rbp-0xC0], rax
       mov      rcx, gword ptr [rbp+0x30]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_VariadicListIndex():int:this]
       mov      dword ptr [rbp-0xC4], eax
       mov      rax, gword ptr [rbp-0xC0]
       lea      rcx, bword ptr [rax+0x08]
       mov      rdx, gword ptr [rbp-0x40]
       call     CORINFO_HELP_ASSIGN_REF
       mov      rax, gword ptr [rbp-0xC0]
       cmp      gword ptr [rax+0x08], 0
       je       SHORT G_M000_IG54
       mov      rax, gword ptr [rbp-0xC0]
       mov      rcx, gword ptr [rax+0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.PyList:get_Count():int:this]
       test     eax, eax
       jne      G_M000_IG56
 
G_M000_IG53:
       mov      rcx, 0xD1FFAB1E
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG54:
       mov      rax, bword ptr [rbp+0x10]
       mov      eax, dword ptr [rax+0x08]
       cmp      dword ptr [rbp-0xC4], eax
       jae      G_M000_IG68
       mov      rax, bword ptr [rbp+0x10]
       mov      rax, bword ptr [rax]
       mov      ecx, dword ptr [rbp-0xC4]
       lea      rax, bword ptr [rax+8*rcx]
       mov      bword ptr [rbp-0x1D0], rax
       mov      rax, 0xD1FFAB1E
       mov      rax, gword ptr [rax]
       mov      gword ptr [rbp-0x1C8], rax
       mov      rax, bword ptr [rbp-0x1D0]
       mov      bword ptr [rbp-0x1D8], rax
       xor      eax, eax
       mov      dword ptr [rbp-0x1DC], eax
       mov      rax, gword ptr [rbp-0x1C8]
       mov      gword ptr [rbp-0x1E8], rax
       cmp      gword ptr [rbp-0x1C8], 0
       jne      SHORT G_M000_IG55
       mov      rcx, 0xD1FFAB1E
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, 0xD1FFAB1E
       call     CORINFO_HELP_NEWSFAST
       mov      gword ptr [rbp-0x1F0], rax
       mov      rax, 0xD1FFAB1E
       mov      rdx, gword ptr [rax]
       mov      rcx, gword ptr [rbp-0x1F0]
       mov      r8, 0xD1FFAB1E
       call     [System.Delegate:CtorClosed(System.Object,nint):this]
       mov      rdx, gword ptr [rbp-0x1F0]
       mov      rcx, 0xD1FFAB1E
       call     CORINFO_HELP_ASSIGN_REF
       mov      rax, gword ptr [rbp-0x1F0]
       mov      gword ptr [rbp-0x1E8], rax
 
G_M000_IG55:
       mov      ecx, dword ptr [rbp-0x1DC]
       mov      rdx, gword ptr [rbp-0x1E8]
       mov      r8, gword ptr [rbp+0x38]
       mov      r9, gword ptr [rbp+0x28]
       call     [Lokad.Lython.Runtime.LythonRuntime:CreateTuple(int,System.Func`2[int,System.Object],Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.PyTuple]
       mov      rdx, rax
       mov      rcx, bword ptr [rbp-0x1D8]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       jmp      G_M000_IG57
 
G_M000_IG56:
       mov      rcx, 0xD1FFAB1E
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, 0xD1FFAB1E
       call     CORINFO_HELP_NEWSFAST
       mov      gword ptr [rbp-0x1F8], rax
       mov      rax, gword ptr [rbp-0xC0]
       mov      rcx, gword ptr [rax+0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.PyList:get_Count():int:this]
       mov      dword ptr [rbp-0x1FC], eax
       mov      rcx, gword ptr [rbp-0x1F8]
       mov      rdx, gword ptr [rbp-0xC0]
       mov      r8, 0xD1FFAB1E
       call     [System.Delegate:CtorClosed(System.Object,nint):this]
       mov      ecx, dword ptr [rbp-0x1FC]
       mov      rdx, gword ptr [rbp-0x1F8]
       mov      r8, gword ptr [rbp+0x38]
       mov      r9, gword ptr [rbp+0x28]
       call     [Lokad.Lython.Runtime.LythonRuntime:CreateTuple(int,System.Func`2[int,System.Object],Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.PyTuple]
       mov      gword ptr [rbp-0xD0], rax
       mov      rax, bword ptr [rbp+0x10]
       mov      eax, dword ptr [rax+0x08]
       cmp      dword ptr [rbp-0xC4], eax
       jae      G_M000_IG68
       mov      rax, bword ptr [rbp+0x10]
       mov      rax, bword ptr [rax]
       mov      ecx, dword ptr [rbp-0xC4]
       lea      rcx, bword ptr [rax+8*rcx]
       mov      rdx, gword ptr [rbp-0xD0]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
 
G_M000_IG57:
       mov      rcx, 0xD1FFAB1E
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp+0x18]
       mov      edx, dword ptr [rbp-0xC4]
       mov      r8d, 1
       call     [Lokad.Lython.Runtime.ArgumentPresence:set_Item(int,bool):this]
 
G_M000_IG58:
       mov      rcx, gword ptr [rbp+0x30]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_VariadicDictionaryIndex():int:this]
       test     eax, eax
       jl       G_M000_IG66
       mov      rcx, 0xD1FFAB1E
       call     CORINFO_HELP_NEWSFAST
       mov      gword ptr [rbp-0x1B0], rax
       mov      rcx, gword ptr [rbp+0x38]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:get_MemoryGovernor():Lokad.Lython.Runtime.MemoryGovernor:this]
       mov      gword ptr [rbp-0x298], rax
       mov      rdx, gword ptr [rbp-0x298]
       mov      rcx, gword ptr [rbp-0x1B0]
       mov      r8, gword ptr [rbp+0x28]
       call     [Lokad.Lython.Runtime.PyDict:.ctor(Lokad.Lython.Runtime.MemoryGovernor,Lokad.Lython.LythonSourceSpan):this]
       mov      rax, gword ptr [rbp-0x1B0]
       mov      gword ptr [rbp-0xD8], rax
       cmp      gword ptr [rbp-0x48], 0
       je       G_M000_IG65
       lea      rdx, [rbp-0x108]
       mov      rcx, gword ptr [rbp-0x48]
       cmp      dword ptr [rcx], ecx
       call     [System.Collections.Generic.Dictionary`2[System.__Canon,System.__Canon]:GetEnumerator():System.Collections.Generic.Dictionary`2+Enumerator[System.__Canon,System.__Canon]:this]
       nop      
 
G_M000_IG59:
       jmp      G_M000_IG61
 
G_M000_IG60:
       mov      rcx, 0xD1FFAB1E
       call     CORINFO_HELP_COUNTPROFILE32
       lea      rdx, [rbp-0x118]
       lea      rcx, [rbp-0x108]
       mov      r8, 0xD1FFAB1E
       call     [System.Collections.Generic.Dictionary`2+Enumerator[System.__Canon,System.__Canon]:get_Current():System.Collections.Generic.KeyValuePair`2[System.__Canon,System.__Canon]:this]
       lea      rcx, [rbp-0x118]
       mov      rdx, 0xD1FFAB1E
       call     [System.Collections.Generic.KeyValuePair`2[System.__Canon,System.__Canon]:get_Key():System.__Canon:this]
       mov      gword ptr [rbp-0x1B8], rax
       mov      rcx, gword ptr [rbp+0x38]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:get_MemoryGovernor():Lokad.Lython.Runtime.MemoryGovernor:this]
       mov      gword ptr [rbp-0x2A0], rax
       mov      rdx, gword ptr [rbp-0x2A0]
       mov      rcx, gword ptr [rbp-0x1B8]
       mov      r8, gword ptr [rbp+0x28]
       call     [Lokad.Lython.Runtime.Text.PyString:FromString(System.String,Lokad.Lython.Runtime.MemoryGovernor,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.Text.PyString]
       mov      gword ptr [rbp-0x120], rax
       lea      rcx, [rbp-0x118]
       mov      rdx, 0xD1FFAB1E
       call     [System.Collections.Generic.KeyValuePair`2[System.__Canon,System.__Canon]:get_Value():System.__Canon:this]
       mov      gword ptr [rbp-0x2A8], rax
       mov      r8, gword ptr [rbp-0x2A8]
       mov      rdx, gword ptr [rbp-0x120]
       mov      rcx, gword ptr [rbp-0xD8]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.PyDict:SetItem(System.Object,System.Object):this]
 
G_M000_IG61:
       mov      eax, dword ptr [rbp-0x20C]
       dec      eax
       mov      dword ptr [rbp-0x20C], eax
       cmp      dword ptr [rbp-0x20C], 0
       jg       SHORT G_M000_IG63
 
G_M000_IG62:
       lea      rcx, [rbp-0x20C]
       mov      edx, 937
       call     CORINFO_HELP_PATCHPOINT
       jmp      rax
 
G_M000_IG63:
       lea      rcx, [rbp-0x108]
       mov      rdx, 0xD1FFAB1E
       call     [System.Collections.Generic.Dictionary`2+Enumerator[System.__Canon,System.__Canon]:MoveNext():bool:this]
       test     eax, eax
       jne      G_M000_IG60
       mov      rcx, 0xD1FFAB1E
       call     CORINFO_HELP_COUNTPROFILE32
       nop      
 
G_M000_IG64:
       call     G_M000_IG69
       nop      
 
G_M000_IG65:
       mov      rcx, 0xD1FFAB1E
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, gword ptr [rbp+0x30]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_VariadicDictionaryIndex():int:this]
       mov      dword ptr [rbp-0xDC], eax
       mov      rax, bword ptr [rbp+0x10]
       mov      eax, dword ptr [rax+0x08]
       cmp      dword ptr [rbp-0xDC], eax
       jae      SHORT G_M000_IG68
       mov      rax, bword ptr [rbp+0x10]
       mov      rax, bword ptr [rax]
       mov      ecx, dword ptr [rbp-0xDC]
       lea      rcx, bword ptr [rax+8*rcx]
       mov      rdx, gword ptr [rbp-0xD8]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rcx, bword ptr [rbp+0x18]
       mov      edx, dword ptr [rbp-0xDC]
       mov      r8d, 1
       call     [Lokad.Lython.Runtime.ArgumentPresence:set_Item(int,bool):this]
 
G_M000_IG66:
       mov      rcx, 0xD1FFAB1E
       call     CORINFO_HELP_COUNTPROFILE32
       nop      
 
G_M000_IG67:
       add      rsp, 720
       pop      rbp
       ret      
 
G_M000_IG68:
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG69:
       sub      rsp, 40
 
G_M000_IG70:
       mov      rcx, 0xD1FFAB1E
       call     CORINFO_HELP_COUNTPROFILE32
       lea      rcx, [rbp-0x108]
       mov      rdx, 0xD1FFAB1E
       call     [System.Collections.Generic.Dictionary`2+Enumerator[System.__Canon,System.__Canon]:Dispose():this]
       nop      
 
G_M000_IG71:
       add      rsp, 40
       ret      
 
; Total bytes of code 3781

; Assembly listing for method Lokad.Lython.Runtime.PyExecutableFunction:StartNativeCall(Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[System.Object],System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,bool,bool,System.Span`1[System.Object],byref,byref,byref):this (Tier1)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; Tier1 code
; optimized code
; optimized using Synthesized PGO
; rbp based frame
; fully interruptible
; with Synthesized PGO: fgCalledCount is 32468
; 34 inlinees with PGO data; 107 single block inlinees; 4 inlinees without PGO data

G_M000_IG01:
       push     rbp
       push     r15
       push     r14
       push     r13
       push     r12
       push     rdi
       push     rsi
       push     rbx
       sub      rsp, 904
       lea      rbp, [rsp+0x3C0]
       vxorps   xmm4, xmm4, xmm4
       vmovdqa  xmmword ptr [rbp-0x240], xmm4
       vmovdqa  xmmword ptr [rbp-0x230], xmm4
       mov      rax, -480
 
G_M000_IG124:
       vmovdqa  xmmword ptr [rbp+rax-0x40], xmm4
       vmovdqa  xmmword ptr [rbp+rax-0x30], xmm4
       vmovdqa  xmmword ptr [rbp+rax-0x20], xmm4
       add      rax, 48
       jne      SHORT G_M000_IG124
       mov      qword ptr [rbp-0x40], rax
       mov      rsi, rcx
       mov      rbx, rdx
       mov      rdi, r9
       mov      r15, gword ptr [rbp+0x30]
       mov      r14, gword ptr [rbp+0x38]
 
G_M000_IG02:
       mov      r11, bword ptr [r8]
       mov      bword ptr [rbp-0x330], r11
       mov      r8d, dword ptr [r8+0x08]
       mov      dword ptr [rbp-0x20C], r8d
       mov      rdx, gword ptr [rsi+0x68]
       mov      ecx, dword ptr [rdx+0x9C]
       mov      r12d, dword ptr [rdx+0x98]
       mov      r13d, 4
       cmp      r12d, 4
       cmovg    r13d, r12d
       add      r13d, ecx
       jo       G_M000_IG117
       add      r13d, dword ptr [rdx+0xA4]
       jo       G_M000_IG117
       cmp      r13d, 16
       ja       G_M000_IG67
       mov      rdx, gword ptr [rsi+0x08]
       mov      rdx, gword ptr [rdx+0x08]
       mov      r12, gword ptr [rdx+0x08]
       mov      edx, dword ptr [r12+0x08]
       mov      dword ptr [rbp-0xC0], edx
       xor      ecx, ecx
       mov      qword ptr [rbp-0xC8], rcx
       cmp      edx, 64
       jg       G_M000_IG68
       mov      rcx, 0xD1FFAB1E
 
G_M000_IG03:
       mov      gword ptr [rbp-0xD0], rcx
       cmp      byte  ptr [rbp+0x48], 0
       jne      G_M000_IG69
 
G_M000_IG04:
       mov      r12d, dword ptr [r12+0x08]
       cmp      r12d, r13d
       ja       G_M000_IG67
       xor      rdx, rdx
       mov      bword ptr [rbp-0x338], rdx
       mov      rcx, gword ptr [rsi+0x08]
       mov      gword ptr [rbp-0x270], rcx
       mov      r11, bword ptr [rbp-0x330]
       mov      bword ptr [rbp-0x340], r11
       mov      r8d, dword ptr [rbp-0x20C]
       mov      dword ptr [rbp-0x210], r8d
       xor      rdx, rdx
       mov      gword ptr [rbp-0x258], rdx
       xor      rdx, rdx
       mov      gword ptr [rbp-0x260], rdx
       xor      edx, edx
       mov      dword ptr [rbp-0x104], edx
       test     rbx, rbx
       je       G_M000_IG73
 
G_M000_IG05:
       mov      eax, dword ptr [rbx+0x28]
 
G_M000_IG06:
       mov      dword ptr [rbp-0x108], eax
       xor      r9d, r9d
       mov      r10d, -1
       test     rdi, rdi
       cmovne   r9d, r10d
       mov      r10d, r9d
       cmp      r10d, eax
       jge      G_M000_IG15
       jmp      SHORT G_M000_IG08
 
G_M000_IG07:
       mov      r8d, dword ptr [rbp-0x210]
 
G_M000_IG08:
       test     r10d, r10d
       jl       G_M000_IG76
       test     rbx, rbx
       je       G_M000_IG75
       mov      r9, gword ptr [rbx+0x08]
       cmp      r10d, dword ptr [r9+0x08]
       jae      G_M000_IG118
       mov      r11, r10
       shl      r11, 4
       lea      r9, bword ptr [r9+r11+0x10]
       mov      r11, gword ptr [r9]
       mov      r9d, dword ptr [r9+0x08]
       cmp      r10d, r8d
       jae      G_M000_IG118
       mov      r8, bword ptr [rbp-0x340]
       mov      qword ptr [rbp-0x250], r10
       mov      r8, gword ptr [r8+8*r10]
       mov      gword ptr [rbp-0x2C8], r8
       test     r8, r8
       je       G_M000_IG88
       mov      gword ptr [rbp-0x198], r11
       mov      dword ptr [rbp-0x190], r9d
       vxorps   ymm0, ymm0, ymm0
       vmovdqu  ymmword ptr [rbp-0x1C0], ymm0
       vmovdqu  xmmword ptr [rbp-0x1A8], xmm0
       mov      r9d, dword ptr [rbp-0x190]
       test     r9d, r9d
       jne      G_M000_IG74
 
G_M000_IG09:
       mov      r11, 0xD1FFAB1E
       xor      r9d, r9d
 
G_M000_IG10:
       mov      r8, gword ptr [rbp-0x2C8]
 
G_M000_IG11:
       mov      gword ptr [rbp-0x138], r11
       mov      gword ptr [rbp-0x130], r8
       mov      dword ptr [rbp-0x128], r9d
       cmp      dword ptr [rbp-0x128], 0
       jne      G_M000_IG82
       mov      rcx, gword ptr [rbp-0x270]
       mov      r8, gword ptr [rcx+0x08]
       mov      edx, dword ptr [rbp-0x104]
       cmp      edx, dword ptr [r8+0x18]
       jge      G_M000_IG77
 
G_M000_IG12:
       cmp      edx, r12d
       jae      G_M000_IG118
       lea      r8, bword ptr [rbp-0xB8]
       mov      dword ptr [rbp-0x104], edx
       mov      r9d, edx
       lea      rcx, bword ptr [r8+8*r9]
       mov      rdx, gword ptr [rbp-0x130]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      edx, dword ptr [rbp-0xC0]
       mov      ecx, dword ptr [rbp-0x104]
       cmp      ecx, edx
       jae      G_M000_IG80
       cmp      ecx, 64
       jge      G_M000_IG81
       mov      rax, qword ptr [rbp-0xC8]
       bts      rax, rcx
       mov      qword ptr [rbp-0xC8], rax
 
G_M000_IG13:
       inc      ecx
       mov      dword ptr [rbp-0x104], ecx
 
G_M000_IG14:
       mov      rdx, qword ptr [rbp-0x250]
       inc      edx
       mov      r8d, dword ptr [rbp-0x108]
       cmp      edx, r8d
       mov      r10, rdx
       jl       G_M000_IG07
 
G_M000_IG15:
       xor      ebx, ebx
       mov      rdi, gword ptr [rbp-0x270]
       mov      r8, gword ptr [rdi+0x08]
       cmp      dword ptr [r8+0x18], 0
       jle      SHORT G_M000_IG18
 
G_M000_IG16:
       mov      edx, dword ptr [rbp-0xC0]
       cmp      ebx, edx
       jae      G_M000_IG97
       cmp      ebx, 64
       jge      G_M000_IG98
       mov      r8, qword ptr [rbp-0xC8]
       bt       r8, rbx
       jae      G_M000_IG99
 
G_M000_IG17:
       inc      ebx
       mov      rcx, gword ptr [rdi+0x08]
       cmp      ebx, dword ptr [rcx+0x18]
       jl       SHORT G_M000_IG16
 
G_M000_IG18:
       xor      ebx, ebx
 
G_M000_IG19:
       mov      rax, gword ptr [rdi+0x08]
       mov      gword ptr [rbp-0x370], rax
       cmp      ebx, dword ptr [rax+0x1C]
       jge      G_M000_IG61
 
G_M000_IG20:
       mov      ecx, ebx
       add      ecx, dword ptr [rax+0x18]
       mov      edx, ecx
       mov      dword ptr [rbp-0x14C], edx
       mov      r8d, dword ptr [rbp-0xC0]
       cmp      edx, r8d
       jae      G_M000_IG101
       cmp      edx, 64
       jge      G_M000_IG102
       mov      r8, qword ptr [rbp-0xC8]
       bt       r8, rdx
       jb       G_M000_IG60
 
G_M000_IG21:
       mov      rax, gword ptr [rax+0x08]
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG118
       mov      ecx, ecx
       mov      rax, gword ptr [rax+8*rcx+0x10]
       mov      gword ptr [rbp-0x298], rax
       mov      rcx, rdi
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_KeywordDefaultStorage():Lokad.Lython.Runtime.PyDict:this]
       mov      gword ptr [rbp-0x2A0], rax
       test     rax, rax
       je       G_M000_IG107
       mov      rcx, gword ptr [rdi+0x28]
       cmp      ebx, dword ptr [rcx+0x08]
       jae      G_M000_IG118
       mov      r10, gword ptr [rcx+8*rbx+0x10]
       mov      gword ptr [rbp-0x2D8], r10
       cmp      gword ptr [rax+0x28], 0
       je       G_M000_IG103
       test     r10, r10
       je       G_M000_IG105
       mov      r10, gword ptr [rbp-0x2D8]
       cmp      dword ptr [rax+0x50], 0
       setne    cl
       movzx    rcx, cl
       test     ecx, ecx
       jne      G_M000_IG104
       mov      rax, gword ptr [rbp-0x2A0]
       xor      r9, r9
       xor      r11, r11
       xor      r8d, r8d
 
G_M000_IG22:
       mov      gword ptr [rbp-0x350], r9
       mov      gword ptr [rbp-0x358], r11
       mov      byte  ptr [rbp-0x214], r8b
 
G_M000_IG23:
       mov      rcx, rax
       mov      rdx, r10
       mov      r8, r15
       mov      r9, r14
       call     [Lokad.Lython.Runtime.PyDict:PrepareQueryKey(System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):System.ValueTuple`2[uint,bool]:this]
       mov      qword ptr [rbp-0x1E0], rax
       mov      eax, dword ptr [rbp-0x1E0]
       mov      dword ptr [rbp-0x1E4], eax
       movzx    rdx, byte  ptr [rbp-0x1DC]
       mov      dword ptr [rbp-0x1E8], edx
       mov      r8, gword ptr [rbp-0x2A0]
       cmp      gword ptr [r8+0x28], 0
       je       G_M000_IG35
       cmp      dword ptr [r8+0x50], 0
       jne      G_M000_IG49
 
G_M000_IG24:
       cmp      dword ptr [rbp-0x1E8], 0
       jne      G_M000_IG49
       mov      r10, gword ptr [r8+0x28]
       mov      gword ptr [rbp-0x2E0], r10
       cmp      dword ptr [r8+0x4C], 0
       je       G_M000_IG48
 
G_M000_IG25:
       mov      r9d, dword ptr [r10+0x08]
       mov      dword ptr [rbp-0x244], r9d
       mov      ecx, r9d
       blsr     edx, ecx
       jne      G_M000_IG36
       dec      ecx
       and      ecx, dword ptr [rbp-0x1E0]
 
G_M000_IG26:
       cmp      ecx, r9d
       jae      G_M000_IG54
       mov      ecx, ecx
       lea      rcx, [rcx+4*rcx]
       mov      edx, dword ptr [r10+8*rcx+0x30]
       dec      edx
       js       G_M000_IG48
 
G_M000_IG27:
       cmp      edx, r9d
       jae      G_M000_IG54
       mov      ecx, edx
       lea      rcx, [rcx+4*rcx]
       lea      r11, bword ptr [r10+8*rcx+0x10]
       mov      bword ptr [rbp-0x2E8], r11
       cmp      gword ptr [r8+0x20], 0
       jne      G_M000_IG37
 
G_M000_IG28:
       mov      eax, dword ptr [rbp-0x1E4]
       cmp      dword ptr [r11+0x18], eax
       jne      G_M000_IG38
       mov      rcx, 0xD1FFAB1E
       mov      rcx, gword ptr [rcx]
       mov      gword ptr [rbp-0x2F0], rcx
       mov      rcx, gword ptr [r11]
       mov      gword ptr [rbp-0x2F8], rcx
       mov      rax, r15
       test     rax, rax
       je       G_M000_IG39
 
G_M000_IG29:
       mov      rcx, r14
       test     rcx, rcx
       je       G_M000_IG40
 
G_M000_IG30:
       mov      r11, gword ptr [rbp-0x2D8]
       cmp      gword ptr [rbp-0x2F8], r11
       jne      G_M000_IG41
       test     r11, r11
       mov      r11, bword ptr [rbp-0x2E8]
       je       G_M000_IG38
 
G_M000_IG31:
       mov      eax, edx
 
G_M000_IG32:
       test     eax, eax
       jl       G_M000_IG56
       mov      r10, gword ptr [r8+0x30]
       test     r10, r10
       je       G_M000_IG55
       cmp      gword ptr [r8+0x20], 0
       jne      G_M000_IG53
       mov      gword ptr [rbp-0x310], r10
       cmp      eax, dword ptr [r10+0x08]
       jae      G_M000_IG54
       mov      edx, eax
       mov      r9, gword ptr [r10+8*rdx+0x10]
       test     r9, r9
       je       G_M000_IG52
 
G_M000_IG33:
       mov      rcx, r9
 
G_M000_IG34:
       mov      gword ptr [rbp-0x158], rcx
       not      eax
       shr      eax, 31
       mov      dword ptr [rbp-0x1EC], eax
       jmp      G_M000_IG57
 
G_M000_IG35:
       mov      rcx, gword ptr [r8+0x08]
       mov      r11, 0xD1FFAB1E
       call     [r11]Lokad.Lython.Runtime.IPyDictStorage:get_HasProtocolKeys():bool:this
       test     eax, eax
       mov      r8, gword ptr [rbp-0x2A0]
       jne      G_M000_IG49
       jmp      G_M000_IG24
 
G_M000_IG36:
       mov      eax, dword ptr [rbp-0x1E0]
       xor      edx, edx
       div      edx:eax, ecx
       mov      ecx, edx
       jmp      G_M000_IG26
 
G_M000_IG37:
       mov      rcx, gword ptr [r8+0x30]
       cmp      dword ptr [rcx+0x08], edx
       jbe      SHORT G_M000_IG38
       mov      rcx, gword ptr [r8+0x30]
       mov      gword ptr [rbp-0x368], rcx
       cmp      edx, dword ptr [rcx+0x08]
       jae      G_M000_IG54
       mov      dword ptr [rbp-0x1F4], edx
       mov      ecx, edx
       mov      rax, gword ptr [rbp-0x368]
       cmp      gword ptr [rax+8*rcx+0x10], 0
       setne    cl
       movzx    rcx, cl
       test     ecx, ecx
       mov      edx, dword ptr [rbp-0x1F4]
       mov      r8, gword ptr [rbp-0x2A0]
       jne      G_M000_IG28
 
G_M000_IG38:
       mov      rdx, r14
       test     rdx, rdx
       je       G_M000_IG46
       jmp      G_M000_IG47
 
G_M000_IG39:
       mov      dword ptr [rbp-0x1F4], edx
       mov      ecx, 12
       call     [CORINFO_HELP_GETDYNAMIC_GCTHREADSTATIC_BASE_NOCTOR_OPTIMIZED]
       mov      rax, gword ptr [rax+0x18]
       mov      edx, dword ptr [rbp-0x1F4]
       mov      r8, gword ptr [rbp-0x2A0]
       jmp      G_M000_IG29
 
G_M000_IG40:
       mov      rcx, gword ptr [r8+0x18]
       mov      gword ptr [rbp-0x308], rcx
       mov      rcx, gword ptr [rbp-0x308]
       mov      r8, gword ptr [rbp-0x2A0]
       jmp      G_M000_IG30
 
G_M000_IG41:
       mov      gword ptr [rbp-0x300], rax
       test     rax, rax
       mov      dword ptr [rbp-0x1F4], edx
       mov      gword ptr [rbp-0x308], rcx
       je       SHORT G_M000_IG42
       mov      rdx, gword ptr [rbp-0x2F8]
       mov      rcx, 0xD1FFAB1E
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG43
       mov      r10, gword ptr [rbp-0x2D8]
       mov      rdx, r10
       test     rdx, rdx
       jne      SHORT G_M000_IG44
       mov      r11, gword ptr [rbp-0x2D8]
 
G_M000_IG42:
       mov      rcx, gword ptr [rbp-0x2F0]
       mov      rdx, gword ptr [rbp-0x2F8]
       mov      r8, r11
       call     [Lokad.Lython.Runtime.PyValueComparer:Equals(System.Object,System.Object):bool:this]
       jmp      SHORT G_M000_IG45
 
G_M000_IG43:
       mov      r11, gword ptr [rbp-0x2D8]
       jmp      SHORT G_M000_IG42
 
G_M000_IG44:
       mov      rcx, rax
       mov      r8, gword ptr [rbp-0x300]
       mov      r9, gword ptr [rbp-0x308]
       call     [Lokad.Lython.Runtime.Text.PyString:Equals(Lokad.Lython.Runtime.Text.PyString,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):bool:this]
 
G_M000_IG45:
       test     eax, eax
       mov      edx, dword ptr [rbp-0x1F4]
       mov      r8, gword ptr [rbp-0x2A0]
       mov      r11, bword ptr [rbp-0x2E8]
       je       G_M000_IG38
       jmp      G_M000_IG31
 
G_M000_IG46:
       mov      rdx, gword ptr [r8+0x18]
 
G_M000_IG47:
       mov      rcx, r15
       call     [Lokad.Lython.Runtime.PyStructuralGuard:NoteWork(Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan)]
       mov      rcx, bword ptr [rbp-0x2E8]
       mov      edx, dword ptr [rcx+0x1C]
       dec      edx
       mov      eax, edx
       test     eax, eax
       mov      edx, eax
       mov      r8, gword ptr [rbp-0x2A0]
       mov      r9d, dword ptr [rbp-0x244]
       mov      r10, gword ptr [rbp-0x2E0]
       jge      G_M000_IG27
 
G_M000_IG48:
       mov      eax, -1
       jmp      G_M000_IG32
 
G_M000_IG49:
       test     r15, r15
       jne      SHORT G_M000_IG51
       mov      rcx, r8
       mov      rdx, gword ptr [rbp-0x2D8]
       call     [Lokad.Lython.Runtime.PyDict:FindNativeIdentity(System.Object):int:this]
       test     eax, eax
       jge      SHORT G_M000_IG50
       xor      rcx, rcx
       mov      gword ptr [rsp+0x20], rcx
       mov      rcx, gword ptr [rbp-0x2A0]
       mov      rdx, gword ptr [rbp-0x2D8]
       mov      r8d, dword ptr [rbp-0x1E0]
       xor      r9, r9
       call     [Lokad.Lython.Runtime.PyDict:FindNativeIndex(System.Object,uint,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):int:this]
       mov      r8, gword ptr [rbp-0x2A0]
       jmp      G_M000_IG32
 
G_M000_IG50:
       mov      r8, gword ptr [rbp-0x2A0]
       jmp      G_M000_IG32
 
G_M000_IG51:
       mov      gword ptr [rsp+0x20], r15
       mov      gword ptr [rsp+0x28], r14
       xor      ecx, ecx
       mov      dword ptr [rsp+0x30], ecx
       mov      rcx, r8
       mov      rdx, gword ptr [rbp-0x2D8]
       mov      r8d, dword ptr [rbp-0x1E0]
       mov      r9d, dword ptr [rbp-0x1E8]
       call     [Lokad.Lython.Runtime.PyDict:ResolveContextualKey(System.Object,uint,bool,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,bool):int:this]
       mov      r8, gword ptr [rbp-0x2A0]
       jmp      G_M000_IG32
 
G_M000_IG52:
       vxorps   xmm0, xmm0, xmm0
       vmovdqu  xmmword ptr [rbp-0x208], xmm0
       mov      rdx, gword ptr [r8+0x28]
       cmp      eax, dword ptr [rdx+0x08]
       jae      G_M000_IG54
       mov      dword ptr [rbp-0x1F0], eax
       mov      ecx, eax
       lea      rcx, [rcx+4*rcx]
       mov      rdx, qword ptr [rdx+8*rcx+0x20]
       lea      rcx, [rbp-0x208]
       call     [System.Numerics.BigInteger:.ctor(long):this]
       mov      rcx, 0xD1FFAB1E
       call     CORINFO_HELP_NEWSFAST
       mov      gword ptr [rbp-0x318], rax
       lea      rcx, bword ptr [rax+0x08]
       mov      rdx, gword ptr [rbp-0x208]
       call     CORINFO_HELP_ASSIGN_REF
       mov      edx, dword ptr [rbp-0x200]
       mov      rax, gword ptr [rbp-0x318]
       mov      dword ptr [rax+0x10], edx
       mov      gword ptr [rbp-0x320], rax
       mov      edx, dword ptr [rbp-0x1F0]
       mov      rcx, gword ptr [rbp-0x310]
       mov      r8, rax
       call     CORINFO_HELP_ARRADDR_ST
       mov      rcx, gword ptr [rbp-0x320]
       mov      eax, dword ptr [rbp-0x1F0]
       jmp      G_M000_IG34
 
G_M000_IG53:
       mov      rcx, r10
       cmp      eax, dword ptr [rcx+0x08]
       jae      SHORT G_M000_IG54
       mov      edx, eax
       mov      rcx, gword ptr [rcx+8*rdx+0x10]
       jmp      G_M000_IG34
 
G_M000_IG54:
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG55:
       mov      rcx, 0xD1FFAB1E
       mov      r9, gword ptr [rcx]
       jmp      G_M000_IG33
 
G_M000_IG56:
       mov      rcx, 0xD1FFAB1E
       mov      rcx, gword ptr [rcx]
       jmp      G_M000_IG34
 
G_M000_IG57:
       cmp      byte  ptr [rbp-0x214], 0
       jne      G_M000_IG106
 
G_M000_IG58:
       mov      eax, dword ptr [rbp-0x1EC]
 
G_M000_IG59:
       test     eax, eax
       je       G_M000_IG107
       mov      eax, dword ptr [rbp-0x14C]
       cmp      eax, r12d
       jae      G_M000_IG118
       lea      rcx, bword ptr [rbp-0xB8]
       mov      edx, eax
       lea      rcx, bword ptr [rcx+8*rdx]
       mov      rdx, gword ptr [rbp-0x158]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
 
G_M000_IG60:
       inc      ebx
       jmp      G_M000_IG19
 
G_M000_IG61:
       cmp      dword ptr [rax+0x28], 0
       jge      G_M000_IG108
 
G_M000_IG62:
       mov      rcx, gword ptr [rdi+0x08]
       cmp      dword ptr [rcx+0x2C], 0
       jge      G_M000_IG113
 
G_M000_IG63:
       xor      r8, r8
       mov      gword ptr [rbp-0x148], r8
 
G_M000_IG64:
       mov      gword ptr [rbp-0x158], r8
 
G_M000_IG65:
       mov      rdx, gword ptr [rbp-0xD0]
       mov      r8, qword ptr [rbp-0xC8]
       mov      r9d, dword ptr [rbp-0xC0]
       vxorps   ymm0, ymm0, ymm0
       vmovdqu  ymmword ptr [rbp-0x100], ymm0
       vmovdqu  xmmword ptr [rbp-0xE0], xmm0
       lea      rcx, bword ptr [rbp-0xB8]
       mov      bword ptr [rbp-0x228], rcx
       mov      dword ptr [rbp-0x220], r13d
       mov      gword ptr [rbp-0x240], rdx
       mov      qword ptr [rbp-0x238], r8
       mov      dword ptr [rbp-0x230], r9d
       mov      gword ptr [rsp+0x20], r14
       movzx    rdx, byte  ptr [rbp+0x40]
       mov      dword ptr [rsp+0x28], edx
       mov      r13, bword ptr [rbp+0x50]
       mov      bword ptr [rsp+0x30], r13
       mov      r12, bword ptr [rbp+0x58]
       mov      bword ptr [rsp+0x38], r12
       mov      rbx, bword ptr [rbp+0x60]
       mov      bword ptr [rsp+0x40], rbx
       mov      rbx, bword ptr [rbp+0x68]
       mov      bword ptr [rsp+0x48], rbx
       lea      rdx, [rbp-0x228]
       lea      r8, [rbp-0x240]
       lea      r9, [rbp-0x100]
       mov      rcx, rsi
       call     [Lokad.Lython.Runtime.PyExecutableFunction:StartInline(System.Span`1[System.Object],Lokad.Lython.Runtime.ArgumentPresence,System.Nullable`1[Lokad.Lython.Runtime.BoundCallArguments],Lokad.Lython.LythonSourceSpan,bool,System.Span`1[System.Object],byref,byref,byref):this]
       nop      
 
G_M000_IG66:
       vzeroupper 
       add      rsp, 904
       pop      rbx
       pop      rsi
       pop      rdi
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG67:
       call     [System.ThrowHelper:ThrowArgumentOutOfRangeException()]
       int3     
 
G_M000_IG68:
       add      edx, -64
       mov      rcx, 0xD1FFAB1E
       call     CORINFO_HELP_NEWARR_1_VC
       mov      rcx, rax
       jmp      G_M000_IG03
 
G_M000_IG69:
       mov      r11, bword ptr [rbp-0x330]
       mov      r8d, dword ptr [rbp-0x20C]
       cmp      r8d, r13d
       ja       SHORT G_M000_IG70
       shl      r8, 3
       lea      rcx, bword ptr [rbp-0xB8]
       mov      rdx, r11
       call     [System.Buffer:BulkMoveWithWriteBarrier(byref,byref,nuint)]
       xor      ebx, ebx
       jmp      SHORT G_M000_IG72
 
G_M000_IG70:
       call     [System.ThrowHelper:ThrowArgumentException_DestinationTooShort()]
       int3     
 
G_M000_IG71:
       lea      rcx, [rbp-0xD0]
       mov      edx, ebx
       mov      r8d, 1
       call     [Lokad.Lython.Runtime.ArgumentPresence:set_Item(int,bool):this]
       inc      ebx
 
G_M000_IG72:
       cmp      ebx, dword ptr [rbp-0xC0]
       jl       SHORT G_M000_IG71
       jmp      G_M000_IG65
 
G_M000_IG73:
       xor      eax, eax
       jmp      G_M000_IG06
 
G_M000_IG74:
       cmp      r9d, 1
       jne      G_M000_IG89
       lea      rcx, [rbp-0x198]
       call     [Lokad.Lython.Frontend.CallArgumentForm:get_KeywordName():System.String:this]
       mov      r11, rax
       mov      r9d, 1
       jmp      G_M000_IG10
 
G_M000_IG75:
       cmp      r10d, 0
       jae      G_M000_IG118
       mov      qword ptr [rbp-0x250], r10
       lea      r9, [r10+2*r10]
       mov      r8, bword ptr [rbp-0x338]
       lea      r9, bword ptr [r8+8*r9]
       mov      bword ptr [rbp-0x360], r9
       mov      r9, gword ptr [r9]
       mov      r8, bword ptr [rbp-0x360]
       mov      r8, gword ptr [r8+0x08]
       mov      r11, bword ptr [rbp-0x360]
       mov      r11d, dword ptr [r11+0x10]
       mov      rax, r9
       mov      r9d, r11d
       mov      r11, rax
       jmp      G_M000_IG11
 
G_M000_IG76:
       mov      qword ptr [rbp-0x250], r10
       lea      rcx, [rbp-0x120]
       mov      rdx, rdi
       call     [Lokad.Lython.Runtime.CallArgumentValue:Positional(System.Object):Lokad.Lython.Runtime.CallArgumentValue]
       mov      r9, gword ptr [rbp-0x120]
       mov      r8, gword ptr [rbp-0x118]
       mov      r11d, dword ptr [rbp-0x110]
       mov      rax, r9
       mov      r9d, r11d
       mov      r11, rax
       jmp      G_M000_IG11
 
G_M000_IG77:
       mov      rcx, gword ptr [rbp-0x270]
       mov      r8, gword ptr [rcx+0x08]
       cmp      dword ptr [r8+0x28], 0
       jl       G_M000_IG94
       mov      r8, gword ptr [rbp-0x258]
       test     r8, r8
       mov      dword ptr [rbp-0x104], edx
       jne      SHORT G_M000_IG79
 
G_M000_IG78:
       mov      r8, 0xD1FFAB1E
       mov      r8, gword ptr [r8]
       mov      gword ptr [rbp-0x280], r8
       mov      r9, gword ptr [r15+0xA0]
       mov      gword ptr [rbp-0x2D0], r9
       mov      rcx, 0xD1FFAB1E
       call     CORINFO_HELP_NEWSFAST
       mov      gword ptr [rbp-0x288], rax
       mov      rcx, gword ptr [rbp-0x2D0]
       mov      r8, gword ptr [rcx+0x88]
       mov      rcx, gword ptr [rbp-0x288]
       mov      rdx, gword ptr [rbp-0x280]
       mov      r9, r14
       call     [Lokad.Lython.Runtime.PyList:.ctor(System.Collections.Generic.IEnumerable`1[System.Object],Lokad.Lython.Runtime.MemoryGovernor,Lokad.Lython.LythonSourceSpan):this]
       mov      r8, gword ptr [rbp-0x288]
       mov      rax, r8
       mov      r8, rax
 
G_M000_IG79:
       mov      gword ptr [rbp-0x258], r8
       mov      rcx, r8
       mov      rdx, gword ptr [rbp-0x130]
       call     [Lokad.Lython.Runtime.PyList:Add(System.Object):this]
       jmp      G_M000_IG14
 
G_M000_IG80:
       mov      r8, 0xD1FFAB1E
       call     [System.ArgumentOutOfRangeException:ThrowGreaterEqual[uint](uint,uint,System.String)]
       int3     
 
G_M000_IG81:
       lea      eax, [rcx-0x40]
       mov      rdx, gword ptr [rbp-0xD0]
       cmp      eax, dword ptr [rdx+0x08]
       jae      G_M000_IG118
       mov      rax, gword ptr [rbp-0xD0]
       lea      edx, [rcx-0x40]
       mov      byte  ptr [rax+rdx+0x10], 1
       jmp      G_M000_IG13
 
G_M000_IG82:
       lea      rcx, [rbp-0x138]
       call     [Lokad.Lython.Runtime.CallArgumentValue:get_KeywordName():System.String:this]
       mov      gword ptr [rbp-0x268], rax
       mov      r10, gword ptr [rbp-0x270]
       mov      rcx, gword ptr [r10+0x08]
       mov      rcx, gword ptr [rcx+0x10]
       lea      r8, [rbp-0x140]
       mov      rdx, rax
       mov      r11, 0xD1FFAB1E
       call     [r11]System.Collections.Generic.IReadOnlyDictionary`2[System.__Canon,int]:TryGetValue(System.__Canon,byref):bool:this
       test     eax, eax
       je       SHORT G_M000_IG83
       mov      ecx, dword ptr [rbp-0x140]
       mov      rax, gword ptr [rbp-0x270]
       mov      rdx, gword ptr [rax+0x08]
       cmp      ecx, dword ptr [rdx+0x20]
       jge      SHORT G_M000_IG84
       mov      ecx, dword ptr [rbp-0x140]
       mov      rdx, gword ptr [rax+0x08]
       cmp      ecx, dword ptr [rdx+0x24]
       jge      G_M000_IG87
 
G_M000_IG83:
       mov      rax, gword ptr [rbp-0x270]
       mov      rcx, gword ptr [rax+0x08]
       cmp      dword ptr [rcx+0x2C], 0
       jge      SHORT G_M000_IG85
       jmp      G_M000_IG95
 
G_M000_IG84:
       jmp      SHORT G_M000_IG83
 
G_M000_IG85:
       mov      rdx, gword ptr [rbp-0x260]
       test     rdx, rdx
       jne      SHORT G_M000_IG86
       mov      rcx, 0xD1FFAB1E
       call     CORINFO_HELP_NEWSFAST
       mov      rdx, rax
       mov      gword ptr [rbp-0x278], rdx
       mov      r8, 0xD1FFAB1E
       mov      r8, gword ptr [r8]
       mov      rcx, rdx
       xor      edx, edx
       call     [System.Collections.Generic.Dictionary`2[System.__Canon,System.__Canon]:.ctor(int,System.Collections.Generic.IEqualityComparer`1[System.__Canon]):this]
       mov      rdx, gword ptr [rbp-0x278]
       mov      rax, rdx
       mov      rdx, rax
 
G_M000_IG86:
       mov      r8, gword ptr [rbp-0x130]
       mov      gword ptr [rbp-0x260], rdx
       mov      rcx, rdx
       mov      rdx, gword ptr [rbp-0x268]
       xor      r9d, r9d
       call     [System.Collections.Generic.Dictionary`2[System.__Canon,System.__Canon]:TryInsert(System.__Canon,System.__Canon,byte):bool:this]
       test     eax, eax
       jne      G_M000_IG14
       jmp      G_M000_IG96
 
G_M000_IG87:
       lea      rcx, [rbp-0xD0]
       mov      edx, dword ptr [rbp-0x140]
       call     [Lokad.Lython.Runtime.ArgumentPresence:get_Item(int):bool:this]
       test     eax, eax
       jne      G_M000_IG96
       cmp      dword ptr [rbp-0x140], r12d
       jae      G_M000_IG118
       lea      rcx, bword ptr [rbp-0xB8]
       mov      edx, dword ptr [rbp-0x140]
       lea      rcx, bword ptr [rcx+8*rdx]
       mov      rdx, gword ptr [rbp-0x130]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       lea      rcx, [rbp-0xD0]
       mov      edx, dword ptr [rbp-0x140]
       mov      r8d, 1
       call     [Lokad.Lython.Runtime.ArgumentPresence:set_Item(int,bool):this]
       jmp      G_M000_IG14
 
G_M000_IG88:
       mov      rcx, 0xD1FFAB1E
       call     CORINFO_HELP_NEWSFAST
       mov      r12, rax
       mov      rcx, r12
       mov      rdx, 0xD1FFAB1E
       call     [System.InvalidOperationException:.ctor(System.String):this]
       mov      rcx, r12
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG89:
       lea      rcx, [rbp-0x1C0]
       mov      edx, 57
       mov      r8d, 1
       call     [System.Runtime.CompilerServices.DefaultInterpolatedStringHandler:.ctor(int,int):this]
       mov      ecx, dword ptr [rbp-0x1B0]
       cmp      ecx, dword ptr [rbp-0x1A0]
       ja       G_M000_IG67
       mov      rdx, bword ptr [rbp-0x1A8]
       mov      eax, ecx
       lea      rdx, bword ptr [rdx+2*rax]
       mov      eax, dword ptr [rbp-0x1A0]
       sub      eax, ecx
       cmp      eax, 56
       jb       SHORT G_M000_IG90
       vmovups  ymm0, ymmword ptr [reloc @RWD00]
       vmovups  ymmword ptr [rdx], ymm0
       vmovups  ymm0, ymmword ptr [reloc @RWD32]
       vmovups  ymmword ptr [rdx+0x20], ymm0
       vmovups  ymm0, ymmword ptr [reloc @RWD64]
       vmovups  ymmword ptr [rdx+0x40], ymm0
       vmovups  xmm0, xmmword ptr [reloc @RWD96]
       vmovups  xmmword ptr [rdx+0x60], xmm0
       mov      ecx, dword ptr [rbp-0x1B0]
       add      ecx, 56
       mov      dword ptr [rbp-0x1B0], ecx
       jmp      SHORT G_M000_IG91
 
G_M000_IG90:
       lea      rcx, [rbp-0x1C0]
       mov      rdx, 0xD1FFAB1E
       call     [System.Runtime.CompilerServices.DefaultInterpolatedStringHandler:GrowThenCopyString(System.String):this]
 
G_M000_IG91:
       lea      rcx, [rbp-0x1C0]
       mov      edx, dword ptr [rbp-0x190]
       call     [System.Runtime.CompilerServices.DefaultInterpolatedStringHandler:AppendFormatted[int](int):this]
       mov      ecx, dword ptr [rbp-0x1B0]
       cmp      ecx, dword ptr [rbp-0x1A0]
       ja       G_M000_IG67
       mov      rdx, bword ptr [rbp-0x1A8]
       mov      eax, ecx
       lea      rdx, bword ptr [rdx+2*rax]
       mov      eax, dword ptr [rbp-0x1A0]
       sub      eax, ecx
       je       SHORT G_M000_IG92
       mov      word  ptr [rdx], 46
       mov      ecx, dword ptr [rbp-0x1B0]
       inc      ecx
       mov      dword ptr [rbp-0x1B0], ecx
       jmp      SHORT G_M000_IG93
 
G_M000_IG92:
       lea      rcx, [rbp-0x1C0]
       mov      rdx, 0xD1FFAB1E
       call     [System.Runtime.CompilerServices.DefaultInterpolatedStringHandler:GrowThenCopyString(System.String):this]
 
G_M000_IG93:
       mov      rcx, 0xD1FFAB1E
       call     CORINFO_HELP_NEWSFAST
       mov      r14, rax
       lea      rcx, [rbp-0x1C0]
       call     [System.Runtime.CompilerServices.DefaultInterpolatedStringHandler:ToStringAndClear():System.String:this]
       mov      rdx, rax
       mov      rcx, r14
       call     [System.InvalidOperationException:.ctor(System.String):this]
       mov      rcx, r14
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG94:
       mov      rcx, gword ptr [rbp-0x270]
       mov      ecx, dword ptr [rcx+0x30]
       mov      rbx, gword ptr [rbp-0x270]
       mov      rdx, gword ptr [rbx+0x10]
       mov      r8, r14
       call     [Lokad.Lython.Runtime.CallErrors:TooManyPositional(int,System.String,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.LythonRuntimeException]
       mov      rcx, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG95:
       mov      rax, gword ptr [rbp-0x270]
       mov      ecx, dword ptr [rax+0x30]
       mov      rdx, gword ptr [rax+0x10]
       mov      r8, gword ptr [rbp-0x268]
       mov      r9, r14
       call     [Lokad.Lython.Runtime.CallErrors:UnexpectedKeyword(int,System.String,System.String,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.LythonRuntimeException]
       mov      rcx, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG96:
       mov      rbx, gword ptr [rbp-0x270]
       mov      ecx, dword ptr [rbx+0x30]
       mov      rdx, gword ptr [rbx+0x10]
       mov      r8, gword ptr [rbp-0x268]
       mov      r9, r14
       call     [Lokad.Lython.Runtime.CallErrors:MultipleValues(int,System.String,System.String,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.LythonRuntimeException]
       mov      rcx, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG97:
       mov      ecx, ebx
       mov      r8, 0xD1FFAB1E
       call     [System.ArgumentOutOfRangeException:ThrowGreaterEqual[uint](uint,uint,System.String)]
       int3     
 
G_M000_IG98:
       lea      r8d, [rbx-0x40]
       mov      rcx, gword ptr [rbp-0xD0]
       cmp      r8d, dword ptr [rcx+0x08]
       jae      G_M000_IG118
       mov      r8, gword ptr [rbp-0xD0]
       lea      ecx, [rbx-0x40]
       movzx    r8, byte  ptr [r8+rcx+0x10]
       test     r8d, r8d
       jne      G_M000_IG17
 
G_M000_IG99:
       mov      r8, gword ptr [rdi+0x08]
       mov      r8, gword ptr [r8+0x08]
       cmp      ebx, dword ptr [r8+0x08]
       jae      G_M000_IG118
       mov      rax, gword ptr [r8+8*rbx+0x10]
       mov      gword ptr [rbp-0x290], rax
       lea      r8, [rbp-0x148]
       mov      rcx, rdi
       mov      edx, ebx
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:TryGetPositionalDefault(int,byref):bool:this]
       test     eax, eax
       je       SHORT G_M000_IG100
       cmp      ebx, r12d
       jae      G_M000_IG118
       lea      rcx, bword ptr [rbp-0xB8]
       lea      rcx, bword ptr [rcx+8*rbx]
       mov      rdx, gword ptr [rbp-0x148]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       jmp      G_M000_IG17
 
G_M000_IG100:
       mov      ecx, dword ptr [rdi+0x30]
       mov      rdx, gword ptr [rdi+0x10]
       mov      r8, gword ptr [rbp-0x290]
       mov      r9, r14
       call     [Lokad.Lython.Runtime.CallErrors:MissingArgument(int,System.String,System.String,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.LythonRuntimeException]
       mov      rcx, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG101:
       mov      ecx, edx
       mov      edx, r8d
       mov      r8, 0xD1FFAB1E
       call     [System.ArgumentOutOfRangeException:ThrowGreaterEqual[uint](uint,uint,System.String)]
       int3     
 
G_M000_IG102:
       lea      r8d, [rdx-0x40]
       mov      r10, gword ptr [rbp-0xD0]
       cmp      r8d, dword ptr [r10+0x08]
       jae      G_M000_IG118
       mov      r8, gword ptr [rbp-0xD0]
       lea      r10d, [rdx-0x40]
       movzx    r8, byte  ptr [r8+r10+0x10]
       test     r8d, r8d
       jne      G_M000_IG60
       jmp      G_M000_IG21
 
G_M000_IG103:
       lea      rcx, [rbp-0x158]
       mov      qword ptr [rsp+0x20], rcx
       mov      rcx, rax
       mov      rdx, r10
       mov      r8, r15
       mov      r9, r14
       call     [Lokad.Lython.Runtime.PyDict:TryGetBridgeValue(System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,byref):bool:this]
       jmp      G_M000_IG59
 
G_M000_IG104:
       lea      rcx, [rbp-0x1D8]
       mov      rdx, r15
       mov      r8, r14
       call     [Lokad.Lython.Runtime.PyStructuralGuard:PushAmbient(Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.PyStructuralGuard+AmbientScope]
       mov      r9, gword ptr [rbp-0x1D8]
       mov      r11, gword ptr [rbp-0x1D0]
       movzx    r8, byte  ptr [rbp-0x1C8]
       mov      rax, gword ptr [rbp-0x2A0]
       mov      r10, gword ptr [rbp-0x2D8]
       jmp      G_M000_IG22
 
G_M000_IG105:
       jmp      SHORT G_M000_IG104
 
G_M000_IG106:
       mov      ecx, 12
       call     [CORINFO_HELP_GETDYNAMIC_GCTHREADSTATIC_BASE_NOCTOR_OPTIMIZED]
       lea      rcx, bword ptr [rax+0x18]
       mov      rdx, gword ptr [rbp-0x350]
       call     CORINFO_HELP_ASSIGN_REF
       mov      ecx, 12
       call     [CORINFO_HELP_GETDYNAMIC_GCTHREADSTATIC_BASE_NOCTOR_OPTIMIZED]
       lea      rcx, bword ptr [rax+0x20]
       mov      rdx, gword ptr [rbp-0x358]
       call     CORINFO_HELP_ASSIGN_REF
       jmp      G_M000_IG58
 
G_M000_IG107:
       mov      ecx, dword ptr [rdi+0x30]
       mov      rdx, gword ptr [rdi+0x10]
       mov      r8, gword ptr [rbp-0x298]
       mov      r9, r14
       call     [Lokad.Lython.Runtime.CallErrors:MissingArgument(int,System.String,System.String,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.LythonRuntimeException]
       mov      rcx, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG108:
       mov      rcx, 0xD1FFAB1E
       call     CORINFO_HELP_NEWSFAST
       mov      rbx, rax
       mov      rcx, gword ptr [rbp-0x370]
       mov      eax, dword ptr [rcx+0x28]
       mov      dword ptr [rbp-0x184], eax
       lea      rcx, bword ptr [rbx+0x08]
       mov      rdx, gword ptr [rbp-0x258]
       call     CORINFO_HELP_ASSIGN_REF
       cmp      gword ptr [rbx+0x08], 0
       je       SHORT G_M000_IG109
       mov      rcx, gword ptr [rbx+0x08]
       cmp      dword ptr [rcx+0x28], 0
       jne      G_M000_IG111
 
G_M000_IG109:
       mov      ebx, dword ptr [rbp-0x184]
       cmp      ebx, r12d
       jae      G_M000_IG118
       lea      rcx, bword ptr [rbp-0xB8]
       mov      eax, ebx
       lea      rax, bword ptr [rcx+8*rax]
       mov      bword ptr [rbp-0x2B0], rax
       mov      rcx, 0xD1FFAB1E
       mov      rdx, gword ptr [rcx]
       test     rdx, rdx
       jne      SHORT G_M000_IG110
       mov      rcx, 0xD1FFAB1E
       call     CORINFO_HELP_NEWSFAST
       mov      gword ptr [rbp-0x2B8], rax
       mov      rcx, 0xD1FFAB1E
       mov      rdx, gword ptr [rcx]
       mov      rcx, gword ptr [rbp-0x2B8]
       mov      r8, 0xD1FFAB1E
       call     [System.Delegate:CtorClosed(System.Object,nint):this]
       mov      rcx, 0xD1FFAB1E
       mov      rdx, gword ptr [rbp-0x2B8]
       call     CORINFO_HELP_ASSIGN_REF
       mov      rdx, gword ptr [rbp-0x2B8]
 
G_M000_IG110:
       mov      r9, r14
       mov      r8, r15
       xor      ecx, ecx
       call     [Lokad.Lython.Runtime.LythonRuntime:CreateTuple(int,System.Func`2[int,System.Object],Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.PyTuple]
       mov      rdx, rax
       mov      rcx, bword ptr [rbp-0x2B0]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       jmp      G_M000_IG112
 
G_M000_IG111:
       mov      rax, gword ptr [rbx+0x08]
       mov      gword ptr [rbp-0x328], rax
       mov      rcx, 0xD1FFAB1E
       call     CORINFO_HELP_NEWSFAST
       mov      gword ptr [rbp-0x2C0], rax
       mov      rcx, gword ptr [rbp-0x328]
       mov      r10d, dword ptr [rcx+0x28]
       mov      dword ptr [rbp-0x188], r10d
       mov      rcx, rax
       mov      rdx, rbx
       mov      r8, 0xD1FFAB1E
       call     [System.Delegate:CtorClosed(System.Object,nint):this]
       mov      ecx, dword ptr [rbp-0x188]
       mov      rdx, gword ptr [rbp-0x2C0]
       mov      r8, r15
       mov      r9, r14
       call     [Lokad.Lython.Runtime.LythonRuntime:CreateTuple(int,System.Func`2[int,System.Object],Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.PyTuple]
       mov      ebx, dword ptr [rbp-0x184]
       cmp      ebx, r12d
       jae      G_M000_IG118
       lea      rcx, bword ptr [rbp-0xB8]
       mov      edx, ebx
       lea      rcx, bword ptr [rcx+8*rdx]
       mov      rdx, rax
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
 
G_M000_IG112:
       lea      rcx, [rbp-0xD0]
       mov      edx, ebx
       mov      r8d, 1
       call     [Lokad.Lython.Runtime.ArgumentPresence:set_Item(int,bool):this]
       jmp      G_M000_IG62
 
G_M000_IG113:
       mov      rbx, gword ptr [r15+0xA0]
       mov      rcx, 0xD1FFAB1E
       call     CORINFO_HELP_NEWSFAST
       mov      gword ptr [rbp-0x2A8], rax
       xor      r8d, r8d
       mov      dword ptr [rsp+0x20], r8d
       mov      r8, gword ptr [rbx+0x88]
       mov      rcx, rax
       mov      r9, r14
       xor      edx, edx
       call     [Lokad.Lython.Runtime.PyDict:.ctor(int,Lokad.Lython.Runtime.MemoryGovernor,Lokad.Lython.LythonSourceSpan,bool):this]
       mov      rbx, gword ptr [rbp-0x2A8]
       mov      rcx, gword ptr [rbp-0x260]
       test     rcx, rcx
       je       SHORT G_M000_IG116
       lea      rdx, [rbp-0x180]
       call     [System.Collections.Generic.Dictionary`2[System.__Canon,System.__Canon]:GetEnumerator():System.Collections.Generic.Dictionary`2+Enumerator[System.__Canon,System.__Canon]:this]
       jmp      SHORT G_M000_IG115
 
G_M000_IG114:
       mov      rcx, gword ptr [rbp-0x168]
       mov      rax, gword ptr [rbp-0x160]
       mov      gword ptr [rbp-0x348], rax
       mov      rdx, gword ptr [r15+0xA0]
       mov      rdx, gword ptr [rdx+0x88]
       mov      r8, r14
       call     [Lokad.Lython.Runtime.Text.PyString:FromString(System.String,Lokad.Lython.Runtime.MemoryGovernor,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.Text.PyString]
       mov      rdx, rax
       mov      rcx, rbx
       mov      r8, gword ptr [rbp-0x348]
       call     [Lokad.Lython.Runtime.PyDict:SetItem(System.Object,System.Object):this]
 
G_M000_IG115:
       lea      rcx, [rbp-0x180]
       mov      rdx, 0xD1FFAB1E
       call     [System.Collections.Generic.Dictionary`2+Enumerator[System.__Canon,System.__Canon]:MoveNext():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG114
 
G_M000_IG116:
       mov      rcx, gword ptr [rdi+0x08]
       mov      edi, dword ptr [rcx+0x2C]
       cmp      edi, r12d
       jae      SHORT G_M000_IG118
       lea      rcx, bword ptr [rbp-0xB8]
       mov      edx, edi
       lea      rcx, bword ptr [rcx+8*rdx]
       mov      rdx, rbx
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       lea      rcx, [rbp-0xD0]
       mov      edx, edi
       mov      r8d, 1
       call     [Lokad.Lython.Runtime.ArgumentPresence:set_Item(int,bool):this]
       jmp      G_M000_IG63
 
G_M000_IG117:
       call     CORINFO_HELP_OVERFLOW
       int3     
 
G_M000_IG118:
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG119:
       sub      rsp, 88
 
G_M000_IG120:
       cmp      byte  ptr [rbp-0x214], 0
       je       SHORT G_M000_IG122
 
G_M000_IG121:
       mov      ecx, 12
       call     [CORINFO_HELP_GETDYNAMIC_GCTHREADSTATIC_BASE_NOCTOR_OPTIMIZED]
       lea      rcx, bword ptr [rax+0x18]
       mov      rdx, gword ptr [rbp-0x350]
       call     CORINFO_HELP_ASSIGN_REF
       mov      ecx, 12
       call     [CORINFO_HELP_GETDYNAMIC_GCTHREADSTATIC_BASE_NOCTOR_OPTIMIZED]
       lea      rcx, bword ptr [rax+0x20]
       mov      rdx, gword ptr [rbp-0x358]
       call     CORINFO_HELP_ASSIGN_REF
 
G_M000_IG122:
       nop      
 
G_M000_IG123:
       vzeroupper 
       add      rsp, 88
       ret      
 
RWD00  	dq	0063006500780045h, 0062006100740075h, 006300200065006Ch, 0020006C006C0061h
RWD32  	dq	0065007400690073h, 006E006F00630020h, 006E006900610074h, 006E007500200073h
RWD64  	dq	0070007000750073h, 006500740072006Fh, 0072006100200064h, 0065006D00750067h
RWD96  	dq	006B00200074006Eh, 00200064006E0069h

; Total bytes of code 5111

; Assembly listing for method Lokad.Lython.Runtime.LythonRuntime:BindFunctionArgumentsInto(System.Span`1[System.Object],byref,System.ReadOnlySpan`1[Lokad.Lython.Runtime.CallArgumentValue],Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.FunctionBindingPlan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,bool,System.Object,Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[System.Object]) (Tier1)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; Tier1 code
; optimized code
; optimized using Synthesized PGO
; rbp based frame
; fully interruptible
; with Synthesized PGO: fgCalledCount is 33216
; 27 inlinees with PGO data; 87 single block inlinees; 3 inlinees without PGO data

G_M000_IG01:
       push     rbp
       push     r15
       push     r14
       push     r13
       push     r12
       push     rdi
       push     rsi
       push     rbx
       sub      rsp, 600
       lea      rbp, [rsp+0x290]
       xor      eax, eax
       mov      qword ptr [rbp-0x148], rax
       vxorps   xmm4, xmm4, xmm4
       vmovdqa  xmmword ptr [rbp-0x140], xmm4
       mov      rax, -240
 
G_M000_IG111:
       vmovdqa  xmmword ptr [rbp+rax-0x40], xmm4
       vmovdqa  xmmword ptr [rbp+rax-0x30], xmm4
       vmovdqa  xmmword ptr [rbp+rax-0x20], xmm4
       add      rax, 48
       jne      SHORT G_M000_IG111
       mov      rbx, rdx
       mov      rdi, r9
       mov      rsi, gword ptr [rbp+0x30]
       mov      r13, gword ptr [rbp+0x38]
       mov      r15, gword ptr [rbp+0x50]
       mov      r14, bword ptr [rbp+0x58]
 
G_M000_IG02:
       mov      rax, bword ptr [r8]
       mov      bword ptr [rbp-0x228], rax
       mov      edx, dword ptr [r8+0x08]
       mov      dword ptr [rbp-0x150], edx
       mov      r8, bword ptr [rcx]
       mov      bword ptr [rbp-0x220], r8
       mov      r10d, dword ptr [rcx+0x08]
       mov      dword ptr [rbp-0x14C], r10d
       xor      r9, r9
       mov      gword ptr [rbp-0x168], r9
       xor      r11, r11
       mov      gword ptr [rbp-0x170], r11
       xor      ecx, ecx
       mov      dword ptr [rbp-0x3C], ecx
       test     r15, r15
       je       G_M000_IG61
 
G_M000_IG03:
       mov      eax, dword ptr [r15+0x28]
 
G_M000_IG04:
       mov      dword ptr [rbp-0x40], eax
       xor      r11d, r11d
       mov      edx, -1
       cmp      gword ptr [rbp+0x48], 0
       cmovne   r11d, edx
       mov      edx, r11d
       cmp      edx, eax
       jge      G_M000_IG12
       jmp      SHORT G_M000_IG06
 
G_M000_IG05:
       mov      rdx, rcx
 
G_M000_IG06:
       test     edx, edx
       jl       G_M000_IG64
       test     r15, r15
       je       G_M000_IG63
       mov      r11, gword ptr [r15+0x08]
       cmp      edx, dword ptr [r11+0x08]
       jae      G_M000_IG105
       mov      r9, rdx
       shl      r9, 4
       lea      r9, bword ptr [r11+r9+0x10]
       mov      r11, gword ptr [r9]
       mov      r9d, dword ptr [r9+0x08]
       cmp      edx, dword ptr [r14+0x08]
       jae      G_M000_IG105
       mov      r12, bword ptr [r14]
       mov      qword ptr [rbp-0x160], rdx
       mov      r12, gword ptr [r12+8*rdx]
       test     r12, r12
       je       G_M000_IG74
       mov      gword ptr [rbp-0xD8], r11
       mov      dword ptr [rbp-0xD0], r9d
       vxorps   ymm0, ymm0, ymm0
       vmovdqu  ymmword ptr [rbp-0x100], ymm0
       vmovdqu  xmmword ptr [rbp-0xE8], xmm0
       mov      r9d, dword ptr [rbp-0xD0]
       test     r9d, r9d
       jne      G_M000_IG62
 
G_M000_IG07:
       mov      r11, 0xD1FFAB1E
       xor      r9d, r9d
 
G_M000_IG08:
       mov      gword ptr [rbp-0x58], r11
       mov      gword ptr [rbp-0x50], r12
       mov      dword ptr [rbp-0x48], r9d
       cmp      dword ptr [rbp-0x48], 0
       jne      G_M000_IG70
       mov      r9, gword ptr [rsi+0x08]
       mov      ecx, dword ptr [rbp-0x3C]
       cmp      ecx, dword ptr [r9+0x18]
       jge      G_M000_IG65
 
G_M000_IG09:
       cmp      ecx, dword ptr [rbp-0x14C]
       jae      G_M000_IG105
       mov      dword ptr [rbp-0x3C], ecx
       mov      r9d, ecx
       mov      r8, bword ptr [rbp-0x220]
       lea      rcx, bword ptr [r8+8*r9]
       mov      rdx, gword ptr [rbp-0x50]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      edx, dword ptr [rbx+0x10]
       mov      r12d, dword ptr [rbp-0x3C]
       cmp      r12d, edx
       jae      G_M000_IG68
       cmp      r12d, 64
       jge      G_M000_IG69
       mov      rcx, qword ptr [rbx+0x08]
       bts      rcx, r12
       mov      qword ptr [rbx+0x08], rcx
 
G_M000_IG10:
       inc      r12d
       mov      dword ptr [rbp-0x3C], r12d
 
G_M000_IG11:
       mov      rcx, qword ptr [rbp-0x160]
       inc      ecx
       mov      edx, dword ptr [rbp-0x40]
       cmp      ecx, edx
       jl       G_M000_IG05
 
G_M000_IG12:
       xor      r14d, r14d
       mov      r8, gword ptr [rsi+0x08]
       cmp      dword ptr [r8+0x18], 0
       jle      SHORT G_M000_IG15
 
G_M000_IG13:
       mov      edx, dword ptr [rbx+0x10]
       cmp      r14d, edx
       jae      G_M000_IG85
       cmp      r14d, 64
       jge      G_M000_IG86
       mov      r8, qword ptr [rbx+0x08]
       bt       r8, r14
       jae      G_M000_IG87
 
G_M000_IG14:
       inc      r14d
       mov      rcx, gword ptr [rsi+0x08]
       cmp      r14d, dword ptr [rcx+0x18]
       jl       SHORT G_M000_IG13
 
G_M000_IG15:
       xor      r14d, r14d
 
G_M000_IG16:
       cmp      byte  ptr [rbp+0x40], 0
       jne      G_M000_IG58
 
G_M000_IG17:
       mov      rcx, gword ptr [rsi+0x08]
       cmp      r14d, dword ptr [rcx+0x1C]
       jge      G_M000_IG58
 
G_M000_IG18:
       mov      rcx, gword ptr [rsi+0x08]
       mov      edx, r14d
       add      edx, dword ptr [rcx+0x18]
       mov      r8d, edx
       mov      dword ptr [rbp-0x6C], r8d
       mov      r10d, dword ptr [rbx+0x10]
       cmp      r8d, r10d
       jae      G_M000_IG89
       cmp      r8d, 64
       jge      G_M000_IG90
       mov      rcx, qword ptr [rbx+0x08]
       bt       rcx, r8
       jb       G_M000_IG57
 
G_M000_IG19:
       mov      rcx, gword ptr [rsi+0x08]
       mov      rcx, gword ptr [rcx+0x08]
       cmp      edx, dword ptr [rcx+0x08]
       jae      G_M000_IG105
       mov      edx, edx
       mov      rdx, gword ptr [rcx+8*rdx+0x10]
       mov      gword ptr [rbp-0x180], rdx
       mov      rcx, rsi
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_KeywordDefaultStorage():Lokad.Lython.Runtime.PyDict:this]
       mov      gword ptr [rbp-0x188], rax
       test     rax, rax
       je       G_M000_IG95
       mov      rcx, gword ptr [rsi+0x28]
       cmp      r14d, dword ptr [rcx+0x08]
       jae      G_M000_IG105
       mov      r10, gword ptr [rcx+8*r14+0x10]
       mov      gword ptr [rbp-0x1C8], r10
       cmp      gword ptr [rax+0x28], 0
       je       G_M000_IG91
       test     r10, r10
       je       G_M000_IG93
       mov      r10, gword ptr [rbp-0x1C8]
       cmp      dword ptr [rax+0x50], 0
       setne    cl
       movzx    rcx, cl
       test     ecx, ecx
       jne      G_M000_IG92
       mov      rax, gword ptr [rbp-0x188]
       xor      r9, r9
       xor      r11, r11
       xor      r8d, r8d
 
G_M000_IG20:
       mov      gword ptr [rbp-0x238], r9
       mov      gword ptr [rbp-0x240], r11
       mov      byte  ptr [rbp-0x154], r8b
 
G_M000_IG21:
       mov      rcx, rax
       mov      rdx, r10
       mov      r8, r13
       mov      r9, rdi
       call     [Lokad.Lython.Runtime.PyDict:PrepareQueryKey(System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):System.ValueTuple`2[uint,bool]:this]
       mov      qword ptr [rbp-0x120], rax
       mov      eax, dword ptr [rbp-0x120]
       mov      dword ptr [rbp-0x124], eax
       movzx    rdx, byte  ptr [rbp-0x11C]
       mov      dword ptr [rbp-0x128], edx
       mov      r8, gword ptr [rbp-0x188]
       cmp      gword ptr [r8+0x28], 0
       je       G_M000_IG33
       cmp      dword ptr [r8+0x50], 0
       jne      G_M000_IG46
 
G_M000_IG22:
       cmp      dword ptr [rbp-0x128], 0
       jne      G_M000_IG46
       mov      r10, gword ptr [r8+0x28]
       mov      gword ptr [rbp-0x1D0], r10
       cmp      dword ptr [r8+0x4C], 0
       je       G_M000_IG45
 
G_M000_IG23:
       mov      r9d, dword ptr [r10+0x08]
       mov      dword ptr [rbp-0x158], r9d
       mov      ecx, r9d
       blsr     edx, ecx
       jne      G_M000_IG34
       dec      ecx
       and      ecx, dword ptr [rbp-0x120]
 
G_M000_IG24:
       cmp      ecx, r9d
       jae      G_M000_IG51
       mov      ecx, ecx
       lea      rcx, [rcx+4*rcx]
       mov      edx, dword ptr [r10+8*rcx+0x30]
       dec      edx
       js       G_M000_IG45
 
G_M000_IG25:
       cmp      edx, r9d
       jae      G_M000_IG51
       mov      ecx, edx
       lea      rcx, [rcx+4*rcx]
       lea      r11, bword ptr [r10+8*rcx+0x10]
       mov      bword ptr [rbp-0x1D8], r11
       cmp      gword ptr [r8+0x20], 0
       jne      G_M000_IG35
 
G_M000_IG26:
       mov      eax, dword ptr [rbp-0x124]
       cmp      dword ptr [r11+0x18], eax
       jne      G_M000_IG36
       mov      rcx, 0xD1FFAB1E
       mov      rcx, gword ptr [rcx]
       mov      gword ptr [rbp-0x1E0], rcx
       mov      rcx, gword ptr [r11]
       mov      gword ptr [rbp-0x1E8], rcx
       mov      rax, r13
       test     rax, rax
       je       G_M000_IG37
 
G_M000_IG27:
       mov      rcx, rdi
       test     rcx, rcx
       je       G_M000_IG38
 
G_M000_IG28:
       mov      r15, gword ptr [rbp-0x1C8]
       cmp      gword ptr [rbp-0x1E8], r15
       jne      G_M000_IG39
       test     r15, r15
       mov      r11, bword ptr [rbp-0x1D8]
       je       G_M000_IG36
 
G_M000_IG29:
       mov      eax, edx
 
G_M000_IG30:
       test     eax, eax
       jl       G_M000_IG53
       mov      r10, gword ptr [r8+0x30]
       test     r10, r10
       je       G_M000_IG52
       cmp      gword ptr [r8+0x20], 0
       jne      G_M000_IG50
       mov      gword ptr [rbp-0x200], r10
       cmp      eax, dword ptr [r10+0x08]
       jae      G_M000_IG51
       mov      edx, eax
       mov      r9, gword ptr [r10+8*rdx+0x10]
       test     r9, r9
       je       G_M000_IG49
 
G_M000_IG31:
       mov      rcx, r9
 
G_M000_IG32:
       mov      gword ptr [rbp-0x78], rcx
       not      eax
       shr      eax, 31
       mov      dword ptr [rbp-0x12C], eax
       jmp      G_M000_IG54
 
G_M000_IG33:
       mov      rcx, gword ptr [r8+0x08]
       mov      r11, 0xD1FFAB1E
       call     [r11]Lokad.Lython.Runtime.IPyDictStorage:get_HasProtocolKeys():bool:this
       test     eax, eax
       mov      r8, gword ptr [rbp-0x188]
       jne      G_M000_IG46
       jmp      G_M000_IG22
 
G_M000_IG34:
       mov      eax, dword ptr [rbp-0x120]
       xor      edx, edx
       div      edx:eax, ecx
       mov      ecx, edx
       jmp      G_M000_IG24
 
G_M000_IG35:
       mov      rcx, gword ptr [r8+0x30]
       cmp      dword ptr [rcx+0x08], edx
       jbe      SHORT G_M000_IG36
       mov      rcx, gword ptr [r8+0x30]
       mov      gword ptr [rbp-0x250], rcx
       cmp      edx, dword ptr [rcx+0x08]
       jae      G_M000_IG51
       mov      dword ptr [rbp-0x134], edx
       mov      ecx, edx
       mov      rax, gword ptr [rbp-0x250]
       cmp      gword ptr [rax+8*rcx+0x10], 0
       setne    cl
       movzx    rcx, cl
       test     ecx, ecx
       mov      edx, dword ptr [rbp-0x134]
       mov      r8, gword ptr [rbp-0x188]
       jne      G_M000_IG26
 
G_M000_IG36:
       mov      rdx, rdi
       test     rdx, rdx
       je       G_M000_IG43
       jmp      G_M000_IG44
 
G_M000_IG37:
       mov      dword ptr [rbp-0x134], edx
       mov      ecx, 12
       call     [CORINFO_HELP_GETDYNAMIC_GCTHREADSTATIC_BASE_NOCTOR_OPTIMIZED]
       mov      rax, gword ptr [rax+0x18]
       mov      edx, dword ptr [rbp-0x134]
       mov      r8, gword ptr [rbp-0x188]
       jmp      G_M000_IG27
 
G_M000_IG38:
       mov      rcx, gword ptr [r8+0x18]
       mov      gword ptr [rbp-0x1F8], rcx
       mov      rcx, gword ptr [rbp-0x1F8]
       mov      r8, gword ptr [rbp-0x188]
       jmp      G_M000_IG28
 
G_M000_IG39:
       mov      gword ptr [rbp-0x1F0], rax
       test     rax, rax
       mov      dword ptr [rbp-0x134], edx
       mov      gword ptr [rbp-0x1F8], rcx
       je       SHORT G_M000_IG40
       mov      rdx, gword ptr [rbp-0x1E8]
       mov      rcx, 0xD1FFAB1E
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG40
       mov      rdx, r15
       test     rdx, rdx
       jne      SHORT G_M000_IG41
 
G_M000_IG40:
       mov      rcx, gword ptr [rbp-0x1E0]
       mov      rdx, gword ptr [rbp-0x1E8]
       mov      r8, r15
       call     [Lokad.Lython.Runtime.PyValueComparer:Equals(System.Object,System.Object):bool:this]
       jmp      SHORT G_M000_IG42
 
G_M000_IG41:
       mov      rcx, rax
       mov      r8, gword ptr [rbp-0x1F0]
       mov      r9, gword ptr [rbp-0x1F8]
       call     [Lokad.Lython.Runtime.Text.PyString:Equals(Lokad.Lython.Runtime.Text.PyString,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):bool:this]
 
G_M000_IG42:
       test     eax, eax
       mov      edx, dword ptr [rbp-0x134]
       mov      r8, gword ptr [rbp-0x188]
       mov      r11, bword ptr [rbp-0x1D8]
       je       G_M000_IG36
       jmp      G_M000_IG29
 
G_M000_IG43:
       mov      rdx, gword ptr [r8+0x18]
 
G_M000_IG44:
       mov      rcx, r13
       call     [Lokad.Lython.Runtime.PyStructuralGuard:NoteWork(Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan)]
       mov      rcx, bword ptr [rbp-0x1D8]
       mov      edx, dword ptr [rcx+0x1C]
       dec      edx
       mov      eax, edx
       test     eax, eax
       mov      edx, eax
       mov      r8, gword ptr [rbp-0x188]
       mov      r9d, dword ptr [rbp-0x158]
       mov      r10, gword ptr [rbp-0x1D0]
       jge      G_M000_IG25
 
G_M000_IG45:
       mov      eax, -1
       jmp      G_M000_IG30
 
G_M000_IG46:
       test     r13, r13
       jne      SHORT G_M000_IG48
       mov      rcx, r8
       mov      rdx, gword ptr [rbp-0x1C8]
       call     [Lokad.Lython.Runtime.PyDict:FindNativeIdentity(System.Object):int:this]
       test     eax, eax
       jge      SHORT G_M000_IG47
       xor      rcx, rcx
       mov      gword ptr [rsp+0x20], rcx
       mov      rcx, gword ptr [rbp-0x188]
       mov      rdx, gword ptr [rbp-0x1C8]
       mov      r8d, dword ptr [rbp-0x120]
       xor      r9, r9
       call     [Lokad.Lython.Runtime.PyDict:FindNativeIndex(System.Object,uint,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):int:this]
       mov      r8, gword ptr [rbp-0x188]
       jmp      G_M000_IG30
 
G_M000_IG47:
       mov      r8, gword ptr [rbp-0x188]
       jmp      G_M000_IG30
 
G_M000_IG48:
       mov      gword ptr [rsp+0x20], r13
       mov      gword ptr [rsp+0x28], rdi
       xor      ecx, ecx
       mov      dword ptr [rsp+0x30], ecx
       mov      rcx, r8
       mov      rdx, gword ptr [rbp-0x1C8]
       mov      r8d, dword ptr [rbp-0x120]
       mov      r9d, dword ptr [rbp-0x128]
       call     [Lokad.Lython.Runtime.PyDict:ResolveContextualKey(System.Object,uint,bool,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,bool):int:this]
       mov      r8, gword ptr [rbp-0x188]
       jmp      G_M000_IG30
 
G_M000_IG49:
       vxorps   xmm0, xmm0, xmm0
       vmovdqu  xmmword ptr [rbp-0x148], xmm0
       mov      rdx, gword ptr [r8+0x28]
       cmp      eax, dword ptr [rdx+0x08]
       jae      G_M000_IG51
       mov      dword ptr [rbp-0x130], eax
       mov      ecx, eax
       lea      rcx, [rcx+4*rcx]
       mov      rdx, qword ptr [rdx+8*rcx+0x20]
       lea      rcx, [rbp-0x148]
       call     [System.Numerics.BigInteger:.ctor(long):this]
       mov      rcx, 0xD1FFAB1E
       call     CORINFO_HELP_NEWSFAST
       mov      gword ptr [rbp-0x208], rax
       lea      rcx, bword ptr [rax+0x08]
       mov      rdx, gword ptr [rbp-0x148]
       call     CORINFO_HELP_ASSIGN_REF
       mov      edx, dword ptr [rbp-0x140]
       mov      rax, gword ptr [rbp-0x208]
       mov      dword ptr [rax+0x10], edx
       mov      gword ptr [rbp-0x210], rax
       mov      edx, dword ptr [rbp-0x130]
       mov      rcx, gword ptr [rbp-0x200]
       mov      r8, rax
       call     CORINFO_HELP_ARRADDR_ST
       mov      rcx, gword ptr [rbp-0x210]
       mov      eax, dword ptr [rbp-0x130]
       jmp      G_M000_IG32
 
G_M000_IG50:
       mov      rcx, r10
       cmp      eax, dword ptr [rcx+0x08]
       jae      SHORT G_M000_IG51
       mov      edx, eax
       mov      rcx, gword ptr [rcx+8*rdx+0x10]
       jmp      G_M000_IG32
 
G_M000_IG51:
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG52:
       mov      rcx, 0xD1FFAB1E
       mov      r9, gword ptr [rcx]
       jmp      G_M000_IG31
 
G_M000_IG53:
       mov      rcx, 0xD1FFAB1E
       mov      rcx, gword ptr [rcx]
       jmp      G_M000_IG32
 
G_M000_IG54:
       cmp      byte  ptr [rbp-0x154], 0
       jne      G_M000_IG94
 
G_M000_IG55:
       mov      eax, dword ptr [rbp-0x12C]
 
G_M000_IG56:
       test     eax, eax
       je       G_M000_IG95
       mov      eax, dword ptr [rbp-0x6C]
       mov      r12d, dword ptr [rbp-0x14C]
       cmp      eax, r12d
       jae      G_M000_IG105
       mov      ecx, eax
       mov      r15, bword ptr [rbp-0x220]
       lea      rcx, bword ptr [r15+8*rcx]
       mov      rdx, gword ptr [rbp-0x78]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
 
G_M000_IG57:
       inc      r14d
       jmp      G_M000_IG16
 
G_M000_IG58:
       mov      rcx, gword ptr [rsi+0x08]
       cmp      dword ptr [rcx+0x28], 0
       jge      G_M000_IG96
 
G_M000_IG59:
       mov      rcx, gword ptr [rsi+0x08]
       cmp      dword ptr [rcx+0x2C], 0
       jge      G_M000_IG101
 
G_M000_IG60:
       vzeroupper 
       add      rsp, 600
       pop      rbx
       pop      rsi
       pop      rdi
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG61:
       mov      eax, edx
       jmp      G_M000_IG04
 
G_M000_IG62:
       cmp      r9d, 1
       jne      G_M000_IG75
       lea      rcx, [rbp-0xD8]
       call     [Lokad.Lython.Frontend.CallArgumentForm:get_KeywordName():System.String:this]
       mov      r11, rax
       mov      r9d, 1
       jmp      G_M000_IG08
 
G_M000_IG63:
       cmp      edx, dword ptr [rbp-0x150]
       jae      G_M000_IG105
       mov      qword ptr [rbp-0x160], rdx
       lea      r9, [rdx+2*rdx]
       mov      r11, bword ptr [rbp-0x228]
       lea      r9, bword ptr [r11+8*r9]
       mov      bword ptr [rbp-0x248], r9
       mov      r9, gword ptr [r9]
       mov      r11, bword ptr [rbp-0x248]
       mov      r11, gword ptr [r11+0x08]
       mov      r12, bword ptr [rbp-0x248]
       mov      r12d, dword ptr [r12+0x10]
       mov      rax, r9
       mov      r9d, r12d
       mov      r12, r11
       mov      r11, rax
       jmp      G_M000_IG08
 
G_M000_IG64:
       mov      qword ptr [rbp-0x160], rdx
       lea      rcx, [rbp-0xC0]
       mov      rdx, gword ptr [rbp+0x48]
       call     [Lokad.Lython.Runtime.CallArgumentValue:Positional(System.Object):Lokad.Lython.Runtime.CallArgumentValue]
       mov      r9, gword ptr [rbp-0xC0]
       mov      r11, gword ptr [rbp-0xB8]
       mov      ecx, dword ptr [rbp-0xB0]
       mov      r12, r11
       mov      r11, r9
       mov      r9d, ecx
       jmp      G_M000_IG08
 
G_M000_IG65:
       mov      r9, gword ptr [rsi+0x08]
       cmp      dword ptr [r9+0x28], 0
       jl       G_M000_IG82
       mov      r12, gword ptr [rbp-0x168]
       test     r12, r12
       mov      dword ptr [rbp-0x3C], ecx
       jne      SHORT G_M000_IG67
 
G_M000_IG66:
       mov      r9, 0xD1FFAB1E
       mov      r12, gword ptr [r9]
       mov      r9, gword ptr [r13+0xA0]
       mov      gword ptr [rbp-0x1C0], r9
       mov      rcx, 0xD1FFAB1E
       call     CORINFO_HELP_NEWSFAST
       mov      gword ptr [rbp-0x198], rax
       mov      r8, gword ptr [rbp-0x1C0]
       mov      r8, gword ptr [r8+0x88]
       mov      rcx, rax
       mov      rdx, r12
       mov      r9, rdi
       call     [Lokad.Lython.Runtime.PyList:.ctor(System.Collections.Generic.IEnumerable`1[System.Object],Lokad.Lython.Runtime.MemoryGovernor,Lokad.Lython.LythonSourceSpan):this]
       mov      r12, gword ptr [rbp-0x198]
 
G_M000_IG67:
       mov      rcx, r12
       mov      rdx, gword ptr [rbp-0x50]
       call     [Lokad.Lython.Runtime.PyList:Add(System.Object):this]
       mov      gword ptr [rbp-0x168], r12
       jmp      G_M000_IG11
 
G_M000_IG68:
       mov      ecx, r12d
       mov      r8, 0xD1FFAB1E
       call     [System.ArgumentOutOfRangeException:ThrowGreaterEqual[uint](uint,uint,System.String)]
       int3     
 
G_M000_IG69:
       mov      rcx, gword ptr [rbx]
       lea      eax, [r12-0x40]
       cmp      eax, dword ptr [rcx+0x08]
       jae      G_M000_IG105
       lea      eax, [r12-0x40]
       mov      byte  ptr [rcx+rax+0x10], 1
       jmp      G_M000_IG10
 
G_M000_IG70:
       lea      rcx, [rbp-0x58]
       call     [Lokad.Lython.Runtime.CallArgumentValue:get_KeywordName():System.String:this]
       mov      gword ptr [rbp-0x178], rax
       mov      rcx, gword ptr [rsi+0x08]
       mov      rcx, gword ptr [rcx+0x10]
       lea      r8, [rbp-0x60]
       mov      rdx, rax
       mov      r11, 0xD1FFAB1E
       call     [r11]System.Collections.Generic.IReadOnlyDictionary`2[System.__Canon,int]:TryGetValue(System.__Canon,byref):bool:this
       test     eax, eax
       je       SHORT G_M000_IG71
       mov      ecx, dword ptr [rbp-0x60]
       mov      rdx, gword ptr [rsi+0x08]
       cmp      ecx, dword ptr [rdx+0x20]
       jge      SHORT G_M000_IG71
       mov      ecx, dword ptr [rbp-0x60]
       mov      rdx, gword ptr [rsi+0x08]
       cmp      ecx, dword ptr [rdx+0x24]
       jge      SHORT G_M000_IG73
 
G_M000_IG71:
       mov      rcx, gword ptr [rsi+0x08]
       cmp      dword ptr [rcx+0x2C], 0
       jl       G_M000_IG83
       mov      rax, gword ptr [rbp-0x170]
       test     rax, rax
       jne      SHORT G_M000_IG72
       mov      rcx, 0xD1FFAB1E
       call     CORINFO_HELP_NEWSFAST
       mov      gword ptr [rbp-0x190], rax
       mov      r8, 0xD1FFAB1E
       mov      r8, gword ptr [r8]
       mov      rcx, rax
       xor      edx, edx
       call     [System.Collections.Generic.Dictionary`2[System.__Canon,System.__Canon]:.ctor(int,System.Collections.Generic.IEqualityComparer`1[System.__Canon]):this]
       mov      rax, gword ptr [rbp-0x190]
 
G_M000_IG72:
       mov      r8, gword ptr [rbp-0x50]
       mov      gword ptr [rbp-0x170], rax
       mov      rcx, rax
       mov      rdx, gword ptr [rbp-0x178]
       xor      r9d, r9d
       call     [System.Collections.Generic.Dictionary`2[System.__Canon,System.__Canon]:TryInsert(System.__Canon,System.__Canon,byte):bool:this]
       test     eax, eax
       jne      G_M000_IG11
       jmp      G_M000_IG84
 
G_M000_IG73:
       mov      rcx, rbx
       mov      edx, dword ptr [rbp-0x60]
       call     [Lokad.Lython.Runtime.ArgumentPresence:get_Item(int):bool:this]
       test     eax, eax
       jne      G_M000_IG84
       mov      eax, dword ptr [rbp-0x14C]
       cmp      dword ptr [rbp-0x60], eax
       jae      G_M000_IG105
       mov      ecx, dword ptr [rbp-0x60]
       mov      r8, bword ptr [rbp-0x220]
       lea      rcx, bword ptr [r8+8*rcx]
       mov      rdx, gword ptr [rbp-0x50]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rcx, rbx
       mov      edx, dword ptr [rbp-0x60]
       mov      r8d, 1
       call     [Lokad.Lython.Runtime.ArgumentPresence:set_Item(int,bool):this]
       jmp      G_M000_IG11
 
G_M000_IG74:
       mov      rcx, 0xD1FFAB1E
       call     CORINFO_HELP_NEWSFAST
       mov      rsi, rax
       mov      rcx, rsi
       mov      rdx, 0xD1FFAB1E
       call     [System.InvalidOperationException:.ctor(System.String):this]
       mov      rcx, rsi
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG75:
       lea      rcx, [rbp-0x100]
       mov      edx, 57
       mov      r8d, 1
       call     [System.Runtime.CompilerServices.DefaultInterpolatedStringHandler:.ctor(int,int):this]
       mov      ecx, dword ptr [rbp-0xF0]
       cmp      ecx, dword ptr [rbp-0xE0]
       jbe      SHORT G_M000_IG77
 
G_M000_IG76:
       call     [System.ThrowHelper:ThrowArgumentOutOfRangeException()]
       int3     
 
G_M000_IG77:
       mov      rdx, bword ptr [rbp-0xE8]
       mov      eax, ecx
       lea      rdx, bword ptr [rdx+2*rax]
       mov      eax, dword ptr [rbp-0xE0]
       sub      eax, ecx
       cmp      eax, 56
       jb       SHORT G_M000_IG78
       vmovups  ymm0, ymmword ptr [reloc @RWD00]
       vmovups  ymmword ptr [rdx], ymm0
       vmovups  ymm0, ymmword ptr [reloc @RWD32]
       vmovups  ymmword ptr [rdx+0x20], ymm0
       vmovups  ymm0, ymmword ptr [reloc @RWD64]
       vmovups  ymmword ptr [rdx+0x40], ymm0
       vmovups  xmm0, xmmword ptr [reloc @RWD96]
       vmovups  xmmword ptr [rdx+0x60], xmm0
       mov      ecx, dword ptr [rbp-0xF0]
       add      ecx, 56
       mov      dword ptr [rbp-0xF0], ecx
       jmp      SHORT G_M000_IG79
 
G_M000_IG78:
       lea      rcx, [rbp-0x100]
       mov      rdx, 0xD1FFAB1E
       call     [System.Runtime.CompilerServices.DefaultInterpolatedStringHandler:GrowThenCopyString(System.String):this]
 
G_M000_IG79:
       lea      rcx, [rbp-0x100]
       mov      edx, dword ptr [rbp-0xD0]
       call     [System.Runtime.CompilerServices.DefaultInterpolatedStringHandler:AppendFormatted[int](int):this]
       mov      ecx, dword ptr [rbp-0xF0]
       cmp      ecx, dword ptr [rbp-0xE0]
       ja       G_M000_IG76
       mov      rdx, bword ptr [rbp-0xE8]
       mov      eax, ecx
       lea      rdx, bword ptr [rdx+2*rax]
       mov      eax, dword ptr [rbp-0xE0]
       sub      eax, ecx
       je       SHORT G_M000_IG80
       mov      word  ptr [rdx], 46
       mov      ecx, dword ptr [rbp-0xF0]
       inc      ecx
       mov      dword ptr [rbp-0xF0], ecx
       jmp      SHORT G_M000_IG81
 
G_M000_IG80:
       lea      rcx, [rbp-0x100]
       mov      rdx, 0xD1FFAB1E
       call     [System.Runtime.CompilerServices.DefaultInterpolatedStringHandler:GrowThenCopyString(System.String):this]
 
G_M000_IG81:
       mov      rcx, 0xD1FFAB1E
       call     CORINFO_HELP_NEWSFAST
       mov      r12, rax
       lea      rcx, [rbp-0x100]
       call     [System.Runtime.CompilerServices.DefaultInterpolatedStringHandler:ToStringAndClear():System.String:this]
       mov      rdx, rax
       mov      rcx, r12
       call     [System.InvalidOperationException:.ctor(System.String):this]
       mov      rcx, r12
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG82:
       mov      ecx, dword ptr [rsi+0x30]
       mov      rdx, gword ptr [rsi+0x10]
       mov      r8, rdi
       call     [Lokad.Lython.Runtime.CallErrors:TooManyPositional(int,System.String,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.LythonRuntimeException]
       mov      rcx, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG83:
       mov      ecx, dword ptr [rsi+0x30]
       mov      rdx, gword ptr [rsi+0x10]
       mov      r8, gword ptr [rbp-0x178]
       mov      r9, rdi
       call     [Lokad.Lython.Runtime.CallErrors:UnexpectedKeyword(int,System.String,System.String,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.LythonRuntimeException]
       mov      rcx, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG84:
       mov      ecx, dword ptr [rsi+0x30]
       mov      rdx, gword ptr [rsi+0x10]
       mov      r8, gword ptr [rbp-0x178]
       mov      r9, rdi
       call     [Lokad.Lython.Runtime.CallErrors:MultipleValues(int,System.String,System.String,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.LythonRuntimeException]
       mov      rcx, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG85:
       mov      ecx, r14d
       mov      r8, 0xD1FFAB1E
       call     [System.ArgumentOutOfRangeException:ThrowGreaterEqual[uint](uint,uint,System.String)]
       int3     
 
G_M000_IG86:
       mov      r8, gword ptr [rbx]
       lea      ecx, [r14-0x40]
       cmp      ecx, dword ptr [r8+0x08]
       jae      G_M000_IG105
       lea      ecx, [r14-0x40]
       movzx    r8, byte  ptr [r8+rcx+0x10]
       test     r8d, r8d
       jne      G_M000_IG14
 
G_M000_IG87:
       mov      r8, gword ptr [rsi+0x08]
       mov      r8, gword ptr [r8+0x08]
       cmp      r14d, dword ptr [r8+0x08]
       jae      G_M000_IG105
       mov      r15, gword ptr [r8+8*r14+0x10]
       lea      r8, [rbp-0x68]
       mov      rcx, rsi
       mov      edx, r14d
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:TryGetPositionalDefault(int,byref):bool:this]
       test     eax, eax
       je       SHORT G_M000_IG88
       mov      r12d, dword ptr [rbp-0x14C]
       cmp      r14d, r12d
       jae      G_M000_IG105
       mov      r15, bword ptr [rbp-0x220]
       lea      rcx, bword ptr [r15+8*r14]
       mov      rdx, gword ptr [rbp-0x68]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       jmp      G_M000_IG14
 
G_M000_IG88:
       mov      ecx, dword ptr [rsi+0x30]
       mov      rdx, gword ptr [rsi+0x10]
       mov      r8, r15
       mov      r9, rdi
       call     [Lokad.Lython.Runtime.CallErrors:MissingArgument(int,System.String,System.String,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.LythonRuntimeException]
       mov      rcx, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG89:
       mov      ecx, r8d
       mov      edx, r10d
       mov      r8, 0xD1FFAB1E
       call     [System.ArgumentOutOfRangeException:ThrowGreaterEqual[uint](uint,uint,System.String)]
       int3     
 
G_M000_IG90:
       mov      rcx, gword ptr [rbx]
       lea      r10d, [r8-0x40]
       cmp      r10d, dword ptr [rcx+0x08]
       jae      G_M000_IG105
       lea      r10d, [r8-0x40]
       movzx    rcx, byte  ptr [rcx+r10+0x10]
       test     ecx, ecx
       jne      G_M000_IG57
       jmp      G_M000_IG19
 
G_M000_IG91:
       lea      rcx, [rbp-0x78]
       mov      qword ptr [rsp+0x20], rcx
       mov      rcx, rax
       mov      rdx, r10
       mov      r8, r13
       mov      r9, rdi
       call     [Lokad.Lython.Runtime.PyDict:TryGetBridgeValue(System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,byref):bool:this]
       jmp      G_M000_IG56
 
G_M000_IG92:
       lea      rcx, [rbp-0x118]
       mov      rdx, r13
       mov      r8, rdi
       call     [Lokad.Lython.Runtime.PyStructuralGuard:PushAmbient(Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.PyStructuralGuard+AmbientScope]
       mov      r9, gword ptr [rbp-0x118]
       mov      r11, gword ptr [rbp-0x110]
       movzx    r8, byte  ptr [rbp-0x108]
       mov      rax, gword ptr [rbp-0x188]
       mov      r10, gword ptr [rbp-0x1C8]
       jmp      G_M000_IG20
 
G_M000_IG93:
       jmp      SHORT G_M000_IG92
 
G_M000_IG94:
       mov      ecx, 12
       call     [CORINFO_HELP_GETDYNAMIC_GCTHREADSTATIC_BASE_NOCTOR_OPTIMIZED]
       lea      rcx, bword ptr [rax+0x18]
       mov      rdx, gword ptr [rbp-0x238]
       call     CORINFO_HELP_ASSIGN_REF
       mov      ecx, 12
       call     [CORINFO_HELP_GETDYNAMIC_GCTHREADSTATIC_BASE_NOCTOR_OPTIMIZED]
       lea      rcx, bword ptr [rax+0x20]
       mov      rdx, gword ptr [rbp-0x240]
       call     CORINFO_HELP_ASSIGN_REF
       jmp      G_M000_IG55
 
G_M000_IG95:
       mov      ecx, dword ptr [rsi+0x30]
       mov      rdx, gword ptr [rsi+0x10]
       mov      r8, gword ptr [rbp-0x180]
       mov      r9, rdi
       call     [Lokad.Lython.Runtime.CallErrors:MissingArgument(int,System.String,System.String,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.LythonRuntimeException]
       mov      rcx, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG96:
       mov      rcx, 0xD1FFAB1E
       call     CORINFO_HELP_NEWSFAST
       mov      r14, rax
       mov      rcx, gword ptr [rsi+0x08]
       mov      eax, dword ptr [rcx+0x28]
       mov      dword ptr [rbp-0x7C], eax
       lea      rcx, bword ptr [r14+0x08]
       mov      rdx, gword ptr [rbp-0x168]
       call     CORINFO_HELP_ASSIGN_REF
       cmp      gword ptr [r14+0x08], 0
       je       SHORT G_M000_IG97
       mov      rcx, gword ptr [r14+0x08]
       cmp      dword ptr [rcx+0x28], 0
       jne      G_M000_IG99
 
G_M000_IG97:
       mov      r14d, dword ptr [rbp-0x7C]
       mov      r12d, dword ptr [rbp-0x14C]
       cmp      r14d, r12d
       jae      G_M000_IG105
       mov      ecx, r14d
       mov      r15, bword ptr [rbp-0x220]
       lea      rax, bword ptr [r15+8*rcx]
       mov      bword ptr [rbp-0x1A8], rax
       mov      rcx, 0xD1FFAB1E
       mov      rdx, gword ptr [rcx]
       test     rdx, rdx
       jne      SHORT G_M000_IG98
       mov      rcx, 0xD1FFAB1E
       call     CORINFO_HELP_NEWSFAST
       mov      gword ptr [rbp-0x1B0], rax
       mov      rcx, 0xD1FFAB1E
       mov      rdx, gword ptr [rcx]
       mov      rcx, gword ptr [rbp-0x1B0]
       mov      r8, 0xD1FFAB1E
       call     [System.Delegate:CtorClosed(System.Object,nint):this]
       mov      rcx, 0xD1FFAB1E
       mov      rdx, gword ptr [rbp-0x1B0]
       call     CORINFO_HELP_ASSIGN_REF
       mov      rdx, gword ptr [rbp-0x1B0]
 
G_M000_IG98:
       mov      r9, rdi
       mov      r8, r13
       xor      ecx, ecx
       call     [Lokad.Lython.Runtime.LythonRuntime:CreateTuple(int,System.Func`2[int,System.Object],Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.PyTuple]
       mov      rdx, rax
       mov      rcx, bword ptr [rbp-0x1A8]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       jmp      G_M000_IG100
 
G_M000_IG99:
       mov      rax, gword ptr [r14+0x08]
       mov      gword ptr [rbp-0x218], rax
       mov      rcx, 0xD1FFAB1E
       call     CORINFO_HELP_NEWSFAST
       mov      gword ptr [rbp-0x1B8], rax
       mov      rcx, gword ptr [rbp-0x218]
       mov      r10d, dword ptr [rcx+0x28]
       mov      dword ptr [rbp-0xC4], r10d
       mov      rcx, rax
       mov      rdx, r14
       mov      r8, 0xD1FFAB1E
       call     [System.Delegate:CtorClosed(System.Object,nint):this]
       mov      ecx, dword ptr [rbp-0xC4]
       mov      rdx, gword ptr [rbp-0x1B8]
       mov      r8, r13
       mov      r9, rdi
       call     [Lokad.Lython.Runtime.LythonRuntime:CreateTuple(int,System.Func`2[int,System.Object],Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.PyTuple]
       mov      r14d, dword ptr [rbp-0x7C]
       mov      r12d, dword ptr [rbp-0x14C]
       cmp      r14d, r12d
       jae      G_M000_IG105
       mov      ecx, r14d
       mov      r15, bword ptr [rbp-0x220]
       lea      rcx, bword ptr [r15+8*rcx]
       mov      rdx, rax
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
 
G_M000_IG100:
       mov      rcx, rbx
       mov      edx, r14d
       mov      r8d, 1
       call     [Lokad.Lython.Runtime.ArgumentPresence:set_Item(int,bool):this]
       jmp      G_M000_IG59
 
G_M000_IG101:
       mov      r14, gword ptr [r13+0xA0]
       mov      rcx, 0xD1FFAB1E
       call     CORINFO_HELP_NEWSFAST
       mov      gword ptr [rbp-0x1A0], rax
       xor      r8d, r8d
       mov      dword ptr [rsp+0x20], r8d
       mov      r8, gword ptr [r14+0x88]
       mov      rcx, rax
       mov      r9, rdi
       xor      edx, edx
       call     [Lokad.Lython.Runtime.PyDict:.ctor(int,Lokad.Lython.Runtime.MemoryGovernor,Lokad.Lython.LythonSourceSpan,bool):this]
       mov      r14, gword ptr [rbp-0x1A0]
       mov      rcx, gword ptr [rbp-0x170]
       test     rcx, rcx
       je       SHORT G_M000_IG104
       lea      rdx, [rbp-0xA8]
       call     [System.Collections.Generic.Dictionary`2[System.__Canon,System.__Canon]:GetEnumerator():System.Collections.Generic.Dictionary`2+Enumerator[System.__Canon,System.__Canon]:this]
       jmp      SHORT G_M000_IG103
 
G_M000_IG102:
       mov      rcx, gword ptr [rbp-0x90]
       mov      rax, gword ptr [rbp-0x88]
       mov      gword ptr [rbp-0x230], rax
       mov      rdx, gword ptr [r13+0xA0]
       mov      rdx, gword ptr [rdx+0x88]
       mov      r8, rdi
       call     [Lokad.Lython.Runtime.Text.PyString:FromString(System.String,Lokad.Lython.Runtime.MemoryGovernor,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.Text.PyString]
       mov      rdx, rax
       mov      rcx, r14
       mov      r8, gword ptr [rbp-0x230]
       call     [Lokad.Lython.Runtime.PyDict:SetItem(System.Object,System.Object):this]
 
G_M000_IG103:
       lea      rcx, [rbp-0xA8]
       mov      rdx, 0xD1FFAB1E
       call     [System.Collections.Generic.Dictionary`2+Enumerator[System.__Canon,System.__Canon]:MoveNext():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG102
 
G_M000_IG104:
       mov      rcx, gword ptr [rsi+0x08]
       mov      esi, dword ptr [rcx+0x2C]
       cmp      esi, dword ptr [rbp-0x14C]
       jae      SHORT G_M000_IG105
       mov      ecx, esi
       mov      r15, bword ptr [rbp-0x220]
       lea      rcx, bword ptr [r15+8*rcx]
       mov      rdx, r14
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rcx, rbx
       mov      edx, esi
       mov      r8d, 1
       call     [Lokad.Lython.Runtime.ArgumentPresence:set_Item(int,bool):this]
       jmp      G_M000_IG60
 
G_M000_IG105:
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG106:
       sub      rsp, 56
 
G_M000_IG107:
       cmp      byte  ptr [rbp-0x154], 0
       je       SHORT G_M000_IG109
 
G_M000_IG108:
       mov      ecx, 12
       call     [CORINFO_HELP_GETDYNAMIC_GCTHREADSTATIC_BASE_NOCTOR_OPTIMIZED]
       lea      rcx, bword ptr [rax+0x18]
       mov      rdx, gword ptr [rbp-0x238]
       call     CORINFO_HELP_ASSIGN_REF
       mov      ecx, 12
       call     [CORINFO_HELP_GETDYNAMIC_GCTHREADSTATIC_BASE_NOCTOR_OPTIMIZED]
       lea      rcx, bword ptr [rax+0x20]
       mov      rdx, gword ptr [rbp-0x240]
       call     CORINFO_HELP_ASSIGN_REF
 
G_M000_IG109:
       nop      
 
G_M000_IG110:
       vzeroupper 
       add      rsp, 56
       ret      
 
RWD00  	dq	0063006500780045h, 0062006100740075h, 006300200065006Ch, 0020006C006C0061h
RWD32  	dq	0065007400690073h, 006E006F00630020h, 006E006900610074h, 006E007500200073h
RWD64  	dq	0070007000750073h, 006500740072006Fh, 0072006100200064h, 0065006D00750067h
RWD96  	dq	006B00200074006Eh, 00200064006E0069h

; Total bytes of code 4391

