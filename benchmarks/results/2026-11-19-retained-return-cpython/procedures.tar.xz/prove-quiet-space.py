from pathlib import Path
import gzip
import hashlib
import json
import subprocess

lab=Path(__file__).resolve().parent
read=lambda p: json.loads(p.read_text(encoding='utf-8-sig'))
import sys

which=sys.argv[1]
assert which in ('framed','defaults')
paths = {
    'framed': ('2026-11-19-direct-default-payload/refinement',
               ['direct-default-results-b1112-20261119/candidate/Lokad.Lython.dll',
                'framed-unpacked-return-b1113-20261119/reference/Lokad.Lython.dll',
                'framed-unpacked-return-b1113-control-20261119/reference/Lokad.Lython.dll']),
    'defaults': ('2026-11-19-framed-unpacked-return',
                ['framed-unpacked-return-b1113-20261119/candidate/Lokad.Lython.dll',
                 'framed-unpacked-return-b1113-control-20261119/candidate/Lokad.Lython.dll'])
}
evidence, aliases = paths[which]
local = 'benchmarks/results/'+evidence
image = 'measured-core.dll.gz'
commit = subprocess.check_output(['git','log','-1','--format=%H','--',local+'/'+image]).decode().strip()
def recorded(name):
    return subprocess.check_output(['git','show',f'{commit}:{local}/{name}'])
core = gzip.decompress(recorded(image))
digest = hashlib.sha256(core).hexdigest()
assert digest == json.loads(recorded('summary.json'))['cores']['candidate']
assert hashlib.sha256(recorded('observations.tgz')).hexdigest() == json.loads(recorded('archive-receipt.json'))['archiveSHA256']
proof = dict(bytes=len(core), links=len(aliases), paths=aliases,
             sha256=digest, committedBlobVerified=True, canonicalCommit=commit,
             canonicalPath=local+'/'+image)
remote = """from pathlib import Path
import fcntl,hashlib,json,os,shutil,stat
root=Path('/home/lokad/lython-bench-checks')
proof=CONTENTS
paths=[root/name for name in proof['paths']]
present=[]
with (root/'comparison-vm.lock').open('a') as lease:
    fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
    if all(p.exists() for p in paths):
        infos=[p.lstat() for p in paths]
        if all(stat.S_ISREG(i.st_mode) and i.st_uid==os.getuid() and i.st_nlink==proof['links']
               and i.st_size==proof['bytes'] for i in infos) and len({(i.st_dev,i.st_ino) for i in infos})==1:
            assert all(p.resolve()==p and p.is_relative_to(root) for p in paths)
            assert hashlib.sha256(paths[0].read_bytes()).hexdigest()==proof['sha256']
            present.append(proof)
    print(json.dumps(dict(freeBytes=shutil.disk_usage(root).free,replicas=present),indent=2))
""".replace('CONTENTS',repr(proof))
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i',str(Path.home()/'.ssh/id_lython-bench.pem'),'-o','BatchMode=yes',
     '-o','ConnectTimeout=15','lokad@20.166.121.73','python3 -']
result=subprocess.run(ssh,input=remote.encode('utf-8'),capture_output=True,timeout=30,check=True)
data=json.loads(result.stdout)
(lab/'quiet-space.json').write_text(json.dumps(data,indent=2)+'\n',encoding='utf-8',newline='\n')
print(data['freeBytes'], [item['paths'][0] for item in data['replicas']])
