from pathlib import Path
import ast,datetime,hashlib,json,shlex,subprocess,tarfile
r=Path(__file__).parent;old=r.parent/'regex-producer-050-r409/quiet';q=r/'quiet-ready';q.mkdir();remote='/home/lokad/lython-bench-checks/helper-boundaries-b801-20261115';unit='lython-b801-helper-boundaries-20261115'
original=json.loads((r.parent/'cased-preparation-r408/checkpoint/identity.json').read_text(encoding='utf-8'));files=dict(original['auxiliaryFiles'],**{'Lokad.Lython.dll':original['coreSHA256']['candidate']})
identity=dict(sourceRevision='Unchanged qualified1b82/frozen0ed; matched complete helper/counter decomposition',purpose='A1 finite cost discrimination, not a source-pair optimization or CPU gain claim. Four scripts share input/output, same core/backend and command boundary.',coreSHA256={k:original['coreSHA256']['candidate']for k in ['candidate','candidate-control']},imageFiles=dict(candidate=files),publicationHeld=True)
(q/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8',newline='\n');(q/'representative.json').write_bytes((r/'catalog.json').read_bytes())
for n in ['collect.py','archive-owned.py','run.sh','retrieve.py']:
 s=(old/n).read_text(encoding='utf-8').replace('regex-ranges-b798-20261115','helper-boundaries-b800-20261115').replace('lython-b798-regex-ranges-20261115',unit).replace('B798','B800')
 if n=='collect.py':
  a=s.index('jobs=');b=s.index('\nenv =',a);s=s[:a]+'jobs='+repr([[c['id'],'warm']for c in json.loads((r/'catalog.json').read_text(encoding='utf-8'))['cases']])+'\n'+s[b:]
  s=s.replace("{'reference','reference-control','candidate','candidate-control'}","{'candidate','candidate-control'}").replace("labels=['candidate','reference','candidate-control','reference-control']","labels=['candidate','candidate-control']")
  a=s.index('count=1; end=');b=s.index('; rows=[]',a);s=s[:a]+'count=1; end=time.monotonic()+12'+s[b:]
  s=s.replace(' < 110,',' < 150,')
 s=s.replace("len(raw['jobs'])==2","len(raw['jobs'])==4").replace("['jobs']==2","['jobs']==4").replace('jobs=2,','jobs=4,').replace("elapsedSeconds']<150","elapsedSeconds']<180")
 (q/n).write_text(s,encoding='utf-8',newline='\n')
with tarfile.open(q/'payload.tgz','w:gz')as t:
 for n in ['collect.py','archive-owned.py','run.sh','identity.json','representative.json']:t.add(q/n,arcname=n)
config=dict(root=remote,unit=unit,source='/home/lokad/lython-bench-checks/cased-cpython-b797-20261115',sourceFiles=files,identity=identity,payloadBytes=(q/'payload.tgz').stat().st_size,payloadSHA256=hashlib.sha256((q/'payload.tgz').read_bytes()).hexdigest())
tree=ast.parse((r.parent/'regex-producer-050-r409/launch-vm.py').read_text(encoding='utf-8'));node=next(n for n in tree.body if isinstance(n,ast.Assign)and any(isinstance(t,ast.Name)and t.id=='code'for t in n.targets));code=node.value.func.value.value
a=code.index(" proof=c['retire'];");b=code.index(' root.mkdir()',a);code=code[:a]+" assert shutil.disk_usage(b).free>254*1024*1024+c['payloadBytes']+65536\n"+code[b:]
code='\n'.join(line for line in code.splitlines()if 'retirement-receipt.json'not in line)
code=code.replace("os.link(root/'backend'/n if n in ['Lokad.Utf8Regex.dll','Lokad.Utf8Regex.PythonRe.dll']else source/'candidate'/n,p)","os.link(source/'candidate'/n,p)").replace("['reference','candidate']","['candidate']").replace('lython-b798-fixtures','lython-b800-fixtures').replace('RuntimeMaxSec=150','RuntimeMaxSec=180').replace('CONFIG',repr(config))
code=code.replace(" for role in ['candidate']:\n", " for role in ['candidate']:\n  (root/role).mkdir(exist_ok=True)\n")
(q/'remote-launch.py').write_text(code,encoding='utf-8',newline='\n');(q/'config.json').write_text(json.dumps(config,indent=2)+'\n',encoding='utf-8',newline='\n')
ast.parse(code);ast.parse((q/'collect.py').read_text(encoding='utf-8'))
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
p=subprocess.run(ssh+['python3 -c '+shlex.quote(code)],input=(q/'payload.tgz').read_bytes(),capture_output=True,timeout=45);(q/'launch.log').write_bytes(p.stdout+p.stderr);assert p.returncode==0,(p.stdout+p.stderr).decode('utf-8','replace')
now=datetime.datetime.now(datetime.timezone.utc);(q/'observe-not-before.json').write_text(json.dumps(dict(launchedUTC=now.isoformat(),doNotObserveBeforeUTC=(now+datetime.timedelta(seconds=155)).isoformat()),indent=2)+'\n',encoding='utf-8',newline='\n');print(p.stdout.decode('utf-8'),flush=True)
