from pathlib import Path
import json,shutil,subprocess,tarfile
repo=Path.cwd();r=Path(__file__).parent;q=r/'quiet-corrected';out=repo/'benchmarks/results/2026-11-15-helper-boundary-decomposition';out.mkdir()
for n in ['summary.json','compiler-facts.json','call-capacity-facts.json']:shutil.copyfile(r/n,out/n)
for n in ['identity.json','observations.tgz','archive-receipt.json','terminal-status.json']:shutil.copyfile(q/n,out/n)
ssh=['C:/Windows/System32/OpenSSH/scp.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15']
for n in ['original-failed-stage.tgz','stage-correction.json']:
 p=subprocess.run(ssh+['lokad@20.166.121.73:/home/lokad/lython-bench-checks/helper-boundaries-b801-20261115/'+n,str(q/n)],capture_output=True,text=True,encoding='utf-8',timeout=30);assert p.returncode==0,p.stderr;shutil.copyfile(q/n,out/n)
with tarfile.open(out/'procedure-and-catalog.tar.xz','w:xz')as t:
 for p in r.iterdir():
  if p.is_file():t.add(p,arcname=p.name)
 for folder in ['quiet','quiet-ready','quiet-corrected']:
  for p in (r/folder).iterdir():
   if p.is_file()and p.suffix in ['.json','.py','.log','.sh']:t.add(p,arcname=folder+'/'+p.name)
(out/'README.md').write_text('''# Matched helper and counter decomposition

R410,2026-11-15, unchanged fully qualified1b82cd46/frozen0edc0c1c, normal0.4adapter.
Four complete text scripts share3,072lines/35,840B, mediated input/report/output,
independent goldens and command-v2 warm boundary. This is workload decomposition,
not a source-pair optimization or additive/causal cost attribution.

| Shape | Median elapsed range | Wider process CPU range | Same-bits elapsed spread |
| --- | --- | --- | --- |
| Inline casing/split |0.849–0.893ms|0.922–0.954ms|5.29%|
| Inline plus local per-line counter/assert |0.983–1.040ms|1.052–1.109ms|5.85%|
| Helper, no counter |1.137–1.144ms|1.188–1.220ms|0.58%|
| Helper plus nonlocal counter/assert |1.183–1.239ms|1.253–1.316ms|4.76%|

The helper still costs roughly0.25–0.30ms without counter work. Moving inline
controls preclude an exact penalty or removable share. The counter does not explain
most of the inline/helper difference. No CPython or cross-collection gain claimed.

Actual compiler metadata, from the exact measured core, establishes all four main
scopes unmirrored and all four dictionary loops fused. Both helper variants are
native eligible; captured counter adds one cell/closure, not a blanket fallback.
Main capacity21, helper call input start13 plus target/argument2, leaves6dead tail
slots; helper needs5. Existing ordinary array capacity can therefore fund this
synchronous child workspace without a new arena, owner, allowance or growth.
Metadata inspection compiles/disposes all scripts with budget returning to zero;
it inspects known code properties, not guest-heap reachability.

Select the next bounded prototype: borrow an unused caller tail for the entire
synchronous native helper workspace. Preserve evaluated operands and unpacked-return
windows. Before suspension, use the existing funded continuation transfer; detach
and clear the borrow after success/fault/transfer. Retain fixed managed stack storage
only when existing caller capacity is insufficient. No widened code arrays or extra
pool/controller. This removes repeated buffer construction where capacity exists;
it does not eliminate helper body dispatch or predict a speedup. Compare complete
captured/helper text and invoice/JSON controls before retention; preserve stack,
aliases, reentry, cancellation, terminal refusal and joined cleanup.

B802 finishes130.803s on quiet F4as_v7/Ubuntu24.04.4/four EPYC9V45/.NET11RC3,
16GiB/no swap, ordinary workstation GC/tiering. Two independent processes/shape,
12s full-request warmup each, five rotated0.5s batches. Full goldens/budget/quiet/
Closed/join/archive/cleanup pass; terminal cached, no workers or RAM fixtures remain.
Elapsed includes Run/mediated RAM I/O/goldens/prior-result disposal; excludes compile,
startup/reset/protocol/final cache teardown. Wider CPU includes reset/protocol.
No pending-I/O, RSS or embedding-tail claim.

Original B800 staging omits the image directory; no worker starts. B801 staging
then preserves an old absolute collector path; its owner fails before workers.
Both conditions remain, with original source/journal archived before empty RAM
fixture unmount. B802 corrects directory/path/warmup metadata only, unchanged
scripts/binaries/settings/boundary. No discarded timing exists. Existing floors
and all current images/evidence remain intact; no new retirement was needed.

[All medians](summary.json),[compiled facts](compiler-facts.json),
[actual call capacity](call-capacity-facts.json),[raw](observations.tgz),
[procedure/source/failed stages](procedure-and-catalog.tar.xz).
''',encoding='utf-8',newline='\n')
with(repo/'benchmarks/EXPERIMENTS.md').open('a',encoding='utf-8',newline='\n')as f:f.write('''

[R410 matched helper/counter decomposition](results/2026-11-15-helper-boundary-decomposition/README.md)
at unchanged1b82/0ed closes the enclosing-mirroring hypothesis: all main scopes
unmirrored/fused, helpers native eligible. Helper without counter1.137–1.144ms
versus inline0.849–0.893ms; controls up to5.85%, no removable-share claim.
Existing caller tail6slots can fund5-slot helper work. Select whole-workspace
borrowing prototype, no new arena/owner/capacity/controller. B802all gates pass,
130.803s/users cleaned; original staging/directory/path failures preserved.
''')
p=repo/'PLAN.md';s=p.read_text(encoding='utf-8');a=s.index('**R410 active:');b=s.index('\n\n**Next gate:',a);s=s[:a]+'''**R410 complete:** [matched decomposition](benchmarks/results/2026-11-15-helper-boundary-decomposition/README.md), B802terminal success130.803s/all users cleaned. All main scopes unmirrored/fused, helpers native eligible. Without counter, helper1.137–1.144ms versus inline0.849–0.893ms; controls up to5.85%, no exact removable-share claim. Staging failures preserved. No unchanged replay.

**R411 selected prototype: entire native helper workspace borrows existing caller
dead-tail capacity.** Actual main has6available slots, helper requires5. Remove
repeated fixed-buffer construction/zeroing where already funded capacity suffices;
keep original fixed managed storage when it does not. No growth, new arena, owner,
pool or controller. Preserve evaluated operands/unpacked-result windows, aliases,
reentry, original stack checks and live defaults. Transfer via existing funded
continuation before suspension; clear/detach borrowed storage on all exits. Focused
native-call/workspace/actual suspension/cancellation/refusal tests on both frameworks,
then one short complete captured/helper text source pair with invoice/JSON controls.
Do not predict a speedup or claim whole call cost disappears. Decide retention/debt
from evidence; retire the prototype completely if its cost/complexity is unjustified.
''' +s[b:];s=s.replace('Four new public flag controls are ready with passing focused checks.','Four public flag controls committed in717f0747 with passing focused checks.');p.write_text(s,encoding='utf-8',newline='\n');print('Saved finite A1 decomposition; selected bounded existing-capacity workspace replacement before implementation.')
