from pathlib import Path
import hashlib,json
repo=Path.cwd();r=Path(__file__).parent;checkpoint=repo/'.git/agent-notes/review-20261031/cased-preparation-r408/checkpoint/retrieved'
full=json.loads((checkpoint/'representative.json').read_text(encoding='utf-8'));direct=json.loads((checkpoint/'additional.json').read_text(encoding='utf-8'))['cases'][0]
captured=next(c for c in full['cases']if c['id']=='scripts.text-summary-helpers.nonlocal-counter.large')
assert 'processed += 1'in captured['source']and 'assert processed == 3072'in captured['source']
inline_counter=direct['source'].replace('    counts = {}','    processed = 0\n    counts = {}',1).replace('        for line in source:\n','        for line in source:\n            processed += 1\n',1).replace('    print(total)','    assert processed == 3072\n    print(total)',1)
helper_no_counter=captured['source'].replace('    processed = 0\n','',1).replace('        nonlocal processed\n','',1).replace('        processed += 1\n','',1).replace('    assert processed == 3072\n','',1)
cases=[]
for name,base,source in [('inline',direct,direct['source']),('inline-counter',direct,inline_counter),('helper',captured,helper_no_counter),('helper-counter',captured,captured['source'])]:
 c=dict(base);c.update(id='scripts.helper-boundary.'+name,source=source,sourceSha256=hashlib.sha256(source.encode()).hexdigest(),sourceUtf8Bytes=len(source.encode()))
 assert c['expectedOutput']==direct['expectedOutput']and c['fixtureSha256']==direct['fixtureSha256']
 cases.append(c)
full['cases']=cases;full['fixtureEncoding']='R410 matched complete text scripts: inline/helper crossed with absent/local-or-nonlocal counter; unchanged data/output/boundary'
(r/'catalog.json').write_text(json.dumps(full,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
print('Four complete scripts; same data/goldens, explicit counter/helper decomposition, no timing claim.')
