from pathlib import Path
import datetime,hashlib,json,shlex,subprocess,tarfile
r=Path(__file__).parent;q=r/'quiet-corrected';q.mkdir();old=r/'quiet-ready';root='/home/lokad/lython-bench-checks/helper-boundaries-b801-20261115';unit='lython-b802-helper-boundaries-20261115'
for n in ['collect.py','archive-owned.py','run.sh','retrieve.py','identity.json']:
 s=(old/n).read_text(encoding='utf-8').replace('helper-boundaries-b800-20261115','helper-boundaries-b801-20261115').replace('lython-b801-helper-boundaries-20261115',unit).replace('warmupSeconds=5,','warmupSeconds=12,')
 (q/n).write_text(s,encoding='utf-8',newline='\n')
assert "labels=['candidate','candidate-control']"in(q/'collect.py').read_text(encoding='utf-8')
with tarfile.open(q/'repair.tgz','w:gz')as t:
 for n in ['collect.py','archive-owned.py','run.sh']:t.add(q/n,arcname=n)
config=dict(root=root,unit=unit,images=json.loads((old/'identity.json').read_text(encoding='utf-8'))['imageFiles'],payloadBytes=(q/'repair.tgz').stat().st_size,payloadSHA256=hashlib.sha256((q/'repair.tgz').read_bytes()).hexdigest())
code='''from pathlib import Path
import ast,fcntl,hashlib,io,json,os,shutil,subprocess,sys,tarfile
c=CONFIG
r=Path(c['root']);b=r.parent
with(b/'comparison-vm.lock').open('a')as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 workers=subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record|[p]ython3.*cpython-worker.py'],capture_output=True,text=True).stdout;own={str(os.getpid()),str(os.getppid())};assert all(line.split(maxsplit=1)[0]in own for line in workers.splitlines()),workers
 old=subprocess.check_output(['systemctl','show','lython-b801-helper-boundaries-20261115.service','--property=MainPID,Result,ActiveState'],text=True);assert 'MainPID=0'in old and 'Result=exit-code'in old and 'ActiveState=failed'in old
 assert not(r/'confirmation').exists()
 fixture=r/'guest-fixtures';assert os.path.ismount(fixture)and not list(fixture.iterdir())
 journal=subprocess.check_output(['journalctl','-u','lython-b801-helper-boundaries-20261115.service','--no-pager','-o','cat'],text=True);(r/'original-failed-journal.txt').write_text(journal)
 with tarfile.open(r/'original-failed-stage.tgz','w:gz')as t:
  for n in ['collect.py','archive-owned.py','run.sh','identity.json','representative.json','original-failed-journal.txt','guest-fixtures']:t.add(r/n,arcname=n)
 with tarfile.open(r/'original-failed-stage.tgz')as t:assert t.extractfile('collect.py').read()
 assert shutil.disk_usage(r).free>252*1024*1024
 subprocess.run(['sudo','-n','umount',str(fixture)],check=True);fixture.rmdir()
 for role,files in c['images'].items():
  for n,h in files.items():assert hashlib.sha256((r/role/n).read_bytes()).hexdigest()==h,n
 payload=sys.stdin.buffer.read(c['payloadBytes']+1);assert len(payload)==c['payloadBytes']and hashlib.sha256(payload).hexdigest()==c['payloadSHA256']
 with tarfile.open(fileobj=io.BytesIO(payload),mode='r:gz')as t:t.extractall(r,filter='data')
 for n in ['collect.py','archive-owned.py']:ast.parse((r/n).read_text());assert '/helper-boundaries-b800-'not in(r/n).read_text()
 subprocess.run(['/bin/sh','-n',str(r/'run.sh')],check=True)
 (r/'stage-correction.json').write_text(json.dumps(dict(originalOwnerFailedBeforeAnyWorker=True,originalStageArchived=True,noTimingObservations=True,correction='Only absolute collector paths, image-directory creation and accurate warmup metadata; same source/core/backend/fixtures/timing boundary',allImagesVerified=True,emptyOwnedRamArchivedBeforeUnmount=True))+'\\n')
 assert shutil.disk_usage(r).free>254*1024*1024;fixture.mkdir();subprocess.run(['sudo','-n','mount','-t','tmpfs','-o','size=32m,mode=0700,uid=lokad,gid=lokad','lython-b802-fixtures',str(fixture)],check=True)
try:subprocess.run(['sudo','-n','systemd-run','--unit='+c['unit'],'--property=User=lokad','--property=WorkingDirectory='+str(r),'--property=RuntimeMaxSec=180','--property=TimeoutStopSec=30','--property=KillMode=control-group','/bin/sh',str(r/'run.sh')],check=True)
except BaseException:
 subprocess.run(['sudo','-n','umount',str(fixture)],check=True);fixture.rmdir();raise
print(json.dumps(dict(launched=True,unit=c['unit'],originalStagePreserved=True,freeBytes=shutil.disk_usage(r).free)))
'''.replace('CONFIG',repr(config));(q/'remote-launch.py').write_text(code,encoding='utf-8',newline='\n')
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
p=subprocess.run(ssh+['python3 -c '+shlex.quote(code)],input=(q/'repair.tgz').read_bytes(),capture_output=True,timeout=45);(q/'launch.log').write_bytes(p.stdout+p.stderr);assert p.returncode==0,(p.stdout+p.stderr).decode('utf-8','replace')
now=datetime.datetime.now(datetime.timezone.utc);(q/'observe-not-before.json').write_text(json.dumps(dict(launchedUTC=now.isoformat(),doNotObserveBeforeUTC=(now+datetime.timedelta(seconds=155)).isoformat()),indent=2)+'\n',encoding='utf-8',newline='\n');print(p.stdout.decode('utf-8'),flush=True)
