from pathlib import Path
import json,statistics
r=Path(__file__).parent;q=r/'quiet-corrected';raw=json.loads((q/'retrieved/confirmation/confirmation.json').read_text(encoding='utf-8'));assert raw['complete']and len(raw['jobs'])==4
rows=[]
for j in raw['jobs']:
 med={};cpu={}
 for label in j['identities']:
  samples=[s for s in j['samples']if s['engine']==label]
  med[label]=statistics.median(s['response']['elapsedTicks']/s['response']['clockFrequency']/s['response']['completedInvocations']*1000 for s in samples)
  cpu[label]=statistics.median(s['externalProcessCpuTicks']/s['externalCpuFrequency']/s['response']['completedInvocations']*1000 for s in samples)
 rows.append(dict(case=j['case'],elapsedMilliseconds=med,cpuMilliseconds=cpu,spreadPercent=100*(max(med.values())/min(med.values())-1)))
(r/'summary.json').write_text(json.dumps(dict(complete=True,sourceUnchanged=True,allWorkersJoinedAndFixturesRemoved=True,actualWarmupSecondsPerProcess=12,rows=rows,interpretation='Matched workload decomposition, not a source-pair speedup or additive/causal cost attribution.'),indent=2)+'\n',encoding='utf-8',newline='\n')
for row in rows:print(row['case'],row['elapsedMilliseconds'],row['cpuMilliseconds'],'spread',row['spreadPercent'])
