# Desktop managed attribution for the retained numeric-call runtime

Four local Windows .NET 11 RC3 traces use the 32-file B1335 image from
`b6dd01aee`, production-equivalent to `e961df912`. Each trace starts
after at least five seconds of complete checked worker requests. The
tracing tool samples managed thread time across a five-second window.
The scripts use the ordinary worker, with actual Windows file operations
for the 4,096-row CSV report. The mixed factory performs no guest file
I/O. The data describes attribution under tracing, with no cross-image
timing comparison.

The explicit-float report has 1,744.6 ms marked as managed work on
runtime stacks. The overlapping groups include 374.1 ms with CSV row
work, 108.4 ms with decimal conversion and 53.4 ms with admission.
Host/file and fixture work also appears on worker or runtime stacks.
Most mixed-factory managed samples resolve to a GC poll leaf in both
warm and compile-to-result lanes, limiting method attribution. Compile
only resolves the executable builder, static analysis and lexical
preparation in overlapping groups. Use a quiet Linux process profile
before selecting another factory redesign from the desktop traces.

Both CPython goldens matched in the exact image. Each trace verifies
before and after collection and records a clean worker exit. The first
direct worker request named a temporary directory the file supervisor
does not accept. The corrected harness uses its existing path convention.
The first summary grouped unmanaged intervals and matched method
parameter text. The final analysis keeps unmanaged intervals separate
and selects named methods in stacks marked `CPU_TIME`. Both original
observations remain in the archive.
