from collections import Counter
from pathlib import Path
import json

lab = Path(__file__).resolve().parent
folders = ("explicit-float-warm", "mixed-factory-warm", "mixed-factory-compile-run", "mixed-factory-compile")
patterns = {
    "decimal conversion": ("ParseFloatText(", "TryParseAsciiFloat", "Number.TryParseFloat", "TrimNumericWhitespace"),
    "CSV row work": ("+CsvRecordSource.", "+CsvRecordParser."),
    "definition construction": ("ApplyDefinition", "CreateInlineDefinition", "CreateFunctionValue", "CreateLexicalFunctionValue"),
    "closure capture": ("CaptureExecutableCells", "ReadCapturedCell"),
    "binding": ("BindFunctionArgumentsInto", "BindCallOperands"),
    "governed admission": ("MemoryGovernor.Reserve", "MemoryGovernor.Commit", "MemoryScope.TryResize"),
    "host file and fixture": ("ComparisonFileHost", "ValidateFixtureDirectory", "File.ReadAllBytes"),
    "cleanup": ("LythonExecutionResult.Dispose", "LythonCompiledScript.Dispose", "DisposeExecution"),
    "GC poll leaf": ("<PollGC>g__PollGCWorker",),
    "compiler executable layout": ("ExecutableStackLayout", "ExecutableScript+Builder.CompileCodeObject"),
    "compiler lexical preparation": ("LexicalScopePreparation",),
    "compiler static analysis": ("StaticAnalyzer", "StaticAbstractInterpreter", "StaticNameBindingDiagnostics"),
}
results = []
for label in folders:
    folder = lab / label
    evented = json.loads((folder / "work.speedscope.json").read_text(encoding="utf-8-sig"))
    record = json.loads((folder / "record.json").read_text(encoding="utf-8"))
    assert record["workerExit"] == 0 and record["closed"]["status"] == "Closed"
    assert record["before"]["actualOutputSha256"] == record["after"]["actualOutputSha256"]
    names = [frame["name"] for frame in evented["shared"]["frames"]]
    phases, leaves, focused, unmanaged = Counter(), Counter(), Counter(), Counter()
    for thread in evented["profiles"]:
        assert thread["type"] == "evented" and thread["unit"] == "milliseconds"
        stack = []
        last = thread["startValue"]
        for event in thread["events"]:
            when = event["at"]
            duration = when - last
            assert duration >= 0
            if stack and duration and stack[-1] in ("CPU_TIME", "UNMANAGED_CODE_TIME"):
                methods = [frame.partition("(")[0] for frame in stack[:-1]]
                caller = methods[-1]
                if stack[-1] == "UNMANAGED_CODE_TIME":
                    unmanaged[caller] += duration
                else:
                    compiler = any("LythonFrontend.Compile" in name or "LythonEngine.CompileCore" in name or "ExecutableScript+Builder.CompileCodeObject" in name for name in methods)
                    runtime = any("Lokad.Lython!Lokad.Lython.Runtime.LythonRuntime" in name for name in methods)
                    worker = any("LythonComparisonWorker" in name for name in methods)
                    phase = "compiler ancestry" if compiler else "runtime ancestry" if runtime else "worker ancestry" if worker else "other"
                    phases[phase] += duration
                    if phase != "other":
                        leaves[caller] += duration
                        for name, choices in patterns.items():
                            if any(part in frame for part in choices for frame in (methods[-1:] if name == "GC poll leaf" else methods)):
                                focused[name] += duration
            index = event["frame"]
            if event["type"] == "O": stack.append(names[index])
            else:
                assert event["type"] == "C" and stack.pop() == names[index]
            last = when
        assert not stack
    result = dict(label=label, phaseManagedSampledThreadMilliseconds=dict(phases),
                  overlappingGroupManagedSampledThreadMilliseconds=dict(focused),
                  nearestLeafManagedSampledThreadMilliseconds=dict(leaves.most_common(35)),
                  unmanagedCallerSampledThreadMilliseconds=dict(unmanaged.most_common(20)),
                  verifiedInvocations=sum(batch["completedInvocations"] for batch in record["profileBatches"]),
                  traceSHA256=record["traceSHA256"], isHardwareCpuMeasurement=False)
    results.append(result)
    print(label, {name: round(value, 1) for name, value in phases.items()})
    print({name: round(value, 1) for name, value in focused.most_common()})
(lab / "attribution.json").write_text(json.dumps(results, indent=2) + "\n", encoding="utf-8", newline="\n")
