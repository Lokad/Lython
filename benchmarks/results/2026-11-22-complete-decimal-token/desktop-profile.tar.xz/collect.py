from pathlib import Path
import hashlib
import json
import os
import queue
import struct
import subprocess
import tempfile
import threading
import time

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
base = lab.parent / "numeric-extrema-standalone-20261122"
image = base / "frozen" / "candidate"
worker_dll = image / "Lokad.Lython.Benchmarks.dll"
dotnet = Path.home() / ".dotnet11" / "dotnet.exe"
tracer = Path.home() / ".dotnet" / "tools" / "dotnet-trace.exe"
python = Path("C:/Python313/python.exe")
env = dict(os.environ, DOTNET_ROOT=str(dotnet.parent), DOTNET_ROOT_X64=str(dotnet.parent),
           PATH=str(dotnet.parent) + os.pathsep + os.environ["PATH"])

def read_json(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))

def write_json(path, value):
    path.write_text(json.dumps(value, indent=2) + "\n", encoding="utf-8", newline="\n")

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

identity = read_json(base / "cpython" / "identity.json")
assert identity["productionEquivalent"].startswith("e961df912")
subprocess.run(["git", "diff", "--exit-code", identity["productionEquivalent"], "HEAD", "--", "src", "tests"], cwd=repo, check=True)
hashes = identity["imageFiles"]["candidate"]
assert len(hashes) == 32 and {name: sha(image / name) for name in hashes} == hashes
catalog = read_json(base / "representative.json")
factory_catalog = read_json(lab.parent / "definition-admission-20261122" / "quiet" / "representative.json")
case_ids = ("scripts.csv-meter-report.explicit-float", "scripts.annotated-rule-closures.literal-positional-dynamic-keyword")
catalog["cases"] = [next(case for case in catalog["cases"] + factory_catalog["cases"] if case["id"] == case_id) for case_id in case_ids]
manifest = lab / "representative.json"
write_json(manifest, catalog)
protocol = repo / "benchmarks" / "cpython-worker.py"
assert sha(protocol) == identity["cpythonWorkerSHA256"]
proof = lab / "verify.json"
if not proof.exists():
    subprocess.run([dotnet, worker_dll, "--compare", "verify", "--catalog", manifest, "--dotnet", dotnet,
                    "--python", python, "--python-worker", protocol, "--out", proof], env=env, check=True, timeout=90)
assert read_json(proof)["caseCount"] == 2 and read_json(proof)["catalogSha256"] == sha(manifest)

def collect(label, case, lane, count):
    folder = lab / label
    folder.mkdir()
    trace = folder / "work.nettrace"
    frames = queue.Queue()
    record = dict(name=case["id"], lane=lane, imageRevision=identity["sourceRevision"],
                  productionRevision=identity["productionEquivalent"], wholeRequestThreadSamples=True,
                  performanceQualified=False)
    with tempfile.TemporaryDirectory(prefix="lython-comparison-files-") as fixtures, \
         (folder / "stderr.log").open("wb") as worker_log, (folder / "collector.log").open("wb") as trace_log:
        worker = subprocess.Popen([dotnet, worker_dll, "--compare", "worker", "--catalog", manifest],
                                  stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=worker_log,
                                  cwd=fixtures, env=env)

        def read_exact(size):
            parts = bytearray()
            while len(parts) < size:
                data = worker.stdout.read(size - len(parts))
                if not data:
                    raise EOFError("worker closed the response pipe")
                parts.extend(data)
            return parts

        def receive():
            try:
                while True:
                    size = struct.unpack(">I", read_exact(4))[0]
                    assert 0 < size <= 4 * 1024 * 1024
                    frame = json.loads(read_exact(size))
                    frames.put(frame)
                    if frame["status"] == "Closed": return
            except Exception as error:
                frames.put(error)

        reader = threading.Thread(target=receive, name="benchmark worker response reader")
        reader.start()
        request_id = 0

        def frame():
            reply = frames.get(timeout=20)
            if isinstance(reply, Exception): raise reply
            return reply

        def request(kind, iterations=2):
            nonlocal request_id
            request_id += 1
            message = dict(protocolVersion=2, requestId=request_id, operation=kind, caseId=case["id"],
                           lane=lane, iterations=iterations,
                           **{name: case[name] for name in ("sourceSha256", "fixtureSha256", "expectedOutputSha256")})
            payload = json.dumps(message).encode("utf-8")
            worker.stdin.write(struct.pack(">I", len(payload)) + payload)
            worker.stdin.flush()
            response = frame()
            assert response["status"] == {"quit": "Closed", "verify": "Equivalent", "batch": "Completed"}[kind], response
            if kind == "verify" or kind == "batch" and lane != "compile":
                assert response["actualOutputSha256"] == case["expectedOutputSha256"]
                assert response.get("actualFilesSha256") == case.get("expectedFilesSha256")
            return response

        profiler = None
        try:
            info = frame()
            assert info["status"] == "Ready" and info["catalogSha256"] == sha(manifest)
            core = next(lib for lib in info["libraries"] if Path(lib["path"]).name == "Lokad.Lython.dll")
            assert core["sha256"].lower() == hashes["Lokad.Lython.dll"] and not info["serverGc"]
            record["identity"] = info
            record["before"] = request("verify")
            elapsed = 0.0
            for _ in range(170):
                sample = request("batch", count)
                elapsed += sample["elapsedTicks"] / sample["clockFrequency"]
                if elapsed >= 5: break
            assert elapsed >= 5.0
            record["workerWarmupSeconds"] = elapsed
            profiler = subprocess.Popen([tracer, "collect", "--process-id", str(worker.pid),
                                         "--profile", "dotnet-sampled-thread-time,dotnet-common",
                                         "--duration", "00:00:00:05", "--output", trace],
                                        stdin=subprocess.DEVNULL, stdout=trace_log, stderr=subprocess.STDOUT, env=env)
            start = time.monotonic()
            batches = []
            while profiler.poll() is None and time.monotonic() - start < 22:
                batches.append(request("batch", count))
            assert batches and profiler.wait(timeout=5) == 0 and trace.stat().st_size > 4096
            record["profileBatches"] = batches
            record["after"] = request("verify")
            record["closed"] = request("quit")
            assert worker.wait(timeout=10) == 0
        finally:
            if profiler is not None and profiler.poll() is None:
                profiler.kill()
                profiler.wait(timeout=5)
            if worker.poll() is None:
                worker.kill()
                worker.wait(timeout=5)
            reader.join(timeout=5)
            assert not reader.is_alive()
            if trace.exists(): record["traceSHA256"] = sha(trace)
            record["workerExit"] = worker.returncode
            write_json(folder / "record.json", record)
    for boundary in ("exclusive", "inclusive"):
        with (folder / (boundary + ".txt")).open("wb") as report:
            args = [tracer, "report", trace, "topN", "-n", "80"]
            if boundary == "inclusive": args.append("--inclusive")
            subprocess.run(args, stdout=report, stderr=subprocess.STDOUT, env=env, check=True, timeout=20)
    print(label, sum(batch["completedInvocations"] for batch in record["profileBatches"]), sha(trace), flush=True)

csv, factory = catalog["cases"]
for label, case, lane, count in (
    ("explicit-float-warm", csv, "warm", 96),
    ("mixed-factory-warm", factory, "warm", 256),
    ("mixed-factory-compile-run", factory, "compile-run", 256),
    ("mixed-factory-compile", factory, "compile", 1024),
):
    collect(label, case, lane, count)
