from pathlib import Path
import hashlib
import json
import random
import shutil
import subprocess

lab = Path(__file__).resolve().parent
base = lab.parent
donor = base / "numeric-extrema-standalone-20261122"
shutil.copyfile(donor / "representative.json", lab / "representative.json")
template = base / "regex-prepared-group-current-20261122" / "measure.py"
source = template.read_text(encoding="utf-8").replace("regex-prepared-group-current-20261122", lab.name)
(lab / "measure.py").write_text(source, encoding="utf-8", newline="\n")

source = (base / "csv-numeric-slot-ingress-20261122" / "test-ubuntu.sh").read_text(encoding="utf-8")
source = source.replace("csv-numeric-slot-ingress-20261122", lab.name)
(lab / "test-ubuntu.sh").write_text(source, encoding="utf-8", newline="\n")
assert b"\r" not in (lab / "test-ubuntu.sh").read_bytes()

rng = random.Random(811771)
forms = ["", "+", "-", ".", "0_0", " -0\t", "1e-999999999999999", "1e+999999999999999",
         "-0.000000000", "1e+", ".0e+0", "03.", "٠_١e٢", "-𝟘", "１\x00", "1\x00", "1_2\x00",
         "Infinity\x00", "NaN\x00", "+nAn", "-iNf", "\u2003-1.2\xa0", "3_0.25_00", "1._0",
         "−2.5", "0x1p1", "1,000", "2.2250738585072014e-308", "4.9406564584124654e-324",
         "2.4703282292062327e-324", "1.7976931348623157e+308", "1.7976931348623159e+308"]
for _ in range(144):
    digits = "".join(rng.choices("0123456789", k=rng.randint(1, 100)))
    at = rng.randrange(len(digits) + 1)
    sign = rng.choice(["", "+", "-"])
    exponent = rng.choice(["", "e" + str(rng.randint(-380, 385))])
    token = sign + digits[:at] + "." + digits[at:] + exponent
    forms.extend([token, token + rng.choice(["\x00", "e+", "x", "_", "\t"])])
expressions = [repr(form) for form in forms]
expressions.extend(repr(form.encode("utf-8")) for form in forms)
for count in (255, 256, 1023, 4094, 4095, 4096, 4097):
    expressions.extend([f"'-0.' + '0' * {count} + '1'", f"'0' * {count} + '2e-324'",
                        f"'9' * {count} + 'e-310'", f"'0' * {count} + '3_4.5'"])
midpoint = '1.00000000000000011102230246251565404236316680908203125'
for count in (700, 768, 1024, 4096):
    expressions.extend([f"{midpoint!r} + '0' * {count}", f"{midpoint!r} + '0' * {count} + '1'"])

body = "import struct\nvalues = (\n" + ",\n".join(expressions) + ",\n)\n" + """\
for value in values:
    try:
        output = float(value)
    except ValueError:
        print('ValueError')
    else:
        print(struct.pack('>d', output).hex())
"""
script = lab / "float-token-corpus.py"
script.write_text(body, encoding="utf-8", newline="\n")
golden = subprocess.check_output(["C:/Python313/python.exe", "-I", "-X", "utf8", script], timeout=20).replace(b"\r\n", b"\n")
raw = body.encode("utf-8")
catalog = json.loads((base / "observed-regex-coordinates" / "representative.json").read_text(encoding="utf-8"))
fixture = json.dumps(dict(size=len(expressions), text=None), separators=(",", ":"))
case = dict(catalog["cases"][0], id="diagnostic.float-complete-token-corpus", size=len(expressions), source=body,
            expectedOutput=golden.decode("utf-8"), sourceUtf8Bytes=len(raw), expectedOutputUtf8Bytes=len(golden),
            fixtureJson=fixture, fixtureSha256=hashlib.sha256(fixture.encode("utf-8")).hexdigest(),
            sourceSha256=hashlib.sha256(raw).hexdigest(), expectedOutputSha256=hashlib.sha256(golden).hexdigest())
catalog["cases"] = [case]
(lab / "corpus.json").write_text(json.dumps(catalog, ensure_ascii=False, indent=2) + "\n", encoding="utf-8", newline="\n")
(lab / "corpus-cpython.txt").write_bytes(golden)
print(f"{len(expressions)} independent CPython decimal, bytes and failure observations.")
