from pathlib import Path

lab = Path(__file__).resolve().parent
template = lab.parent / "numeric-extrema-standalone-20261122" / "archive.py"
source = template.read_text(encoding="utf-8")
source = source.replace('2026-11-22-numeric-extrema-operands', '2026-11-22-complete-decimal-token')
source = source.replace('52eeb328e', 'e961df912').replace('b6dd01aee', '0ee58f0b5').replace('B1335', 'B1338')
source = source.replace('(("white", 590), ("public", 776))', '(("white", 279), ("public", 1124))')
source = source.replace('2026-11-22-direct-jump-layout', '2026-11-22-numeric-extrema-operands')
at = source.index('receipt = load(quiet / "archive-receipt.json")')
source = source[:at] + '''corpus = load(lab / "corpus.json")["cases"]
assert len(corpus) == 1 and corpus[0]["size"] == 676
assert sha(lab / "corpus-cpython.txt") == corpus[0]["expectedOutputSha256"]
for role in ("reference", "candidate"):
    proof = load(lab / f"{role}-corpus-verify.json")
    assert proof["state"] == "Completed" and proof["caseCount"] == 1
    assert proof["catalogSha256"] == sha(lab / "corpus.json")
''' + source[at:]
assert 'len(raw["jobs"]) == receipt["jobs"] == 5' in source
target = lab / "archive.py"
compile(source, str(target), "exec")
target.write_text(source, encoding="utf-8", newline="\n")
