from pathlib import Path

lab = Path(__file__).resolve().parent
template = lab.parent / "numeric-extrema-standalone-20261122" / "prepare-quiet-owned.py"
source = template.read_text(encoding="utf-8")
source = source.replace('prior = lab.parent / "csv-numeric-slot-ingress-20261122"',
                        'prior = lab.parent / "numeric-extrema-standalone-20261122"')
source = source.replace('prior_identity["imageFiles"]["reference"]', 'prior_identity["imageFiles"]["candidate"]')
source = source.replace('prior / "frozen" / "reference"', 'prior / "frozen" / "candidate"')
source = source.replace('sourceRole="reference"', 'sourceRole="candidate"')
source = source.replace('reference.startswith("52eeb328e") and candidate.startswith("b6dd01aee")',
                        'reference.startswith("e961df912") and candidate.startswith("0ee58f0b5")')
source = source.replace('(("white", 590), ("public", 776))', '(("white", 279), ("public", 1124))')
source = source.replace('numeric-extrema-b1335', 'complete-decimal-token-b1338')
source = source.replace('b1335-numeric-extrema', 'b1338-complete-decimal-token')
source = source.replace('b1335-fixtures', 'b1338-fixtures')
source = source.replace('Positional numeric extrema consume existing executable operands', 'Parse complete UTF-8 decimals before classification')
source = source.replace('Positional numeric extrema comparison', 'Complete UTF-8 decimal token comparison')
assert 'sourceRole="candidate"' in source and 'assert sha(manifest) == prior_config["catalogSHA256"]' in source
target = lab / "prepare-quiet-owned.py"
target.write_text(source, encoding="utf-8", newline="\n")
exec(compile(source, str(target), "exec"))
