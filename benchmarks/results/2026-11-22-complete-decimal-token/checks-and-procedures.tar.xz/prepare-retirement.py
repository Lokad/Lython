from pathlib import Path

lab = Path(__file__).resolve().parent
template = lab.parent / "numeric-extrema-standalone-20261122" / "prove-retirement.py"
source = template.read_text(encoding="utf-8")
start, end = source.index('for artifact, old_name'), source.index('    old = lab.parent / old_name')
source = source[:start] + '''for artifact, old_name, catalog, core in (
    ("2026-11-22-regex-prepared-group-metadata", "regex-prepared-group-current-20261122", False, True),
):
''' + source[end:]
target = lab / "prove-retirement.py"
compile(source, str(target), "exec")
target.write_text(source, encoding="utf-8", newline="\n")
exec(compile(source, str(target), "exec"))
