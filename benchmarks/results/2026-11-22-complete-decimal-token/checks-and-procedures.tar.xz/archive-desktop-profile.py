from pathlib import Path
import hashlib
import json
import tarfile

lab = Path(__file__).resolve().parent
profile = lab.parent / "current-decimal-and-factory-attribution-20261122"
out = lab.parents[3] / "benchmarks/results/2026-11-22-complete-decimal-token" / "desktop-profile.tar.xz"
rows = json.loads((profile / "attribution.json").read_text(encoding="utf-8"))
for row in rows:
    trace = profile / row["label"] / "work.nettrace"
    assert hashlib.sha256(trace.read_bytes()).hexdigest() == row["traceSHA256"]
assert len(rows) == 4
with tarfile.open(out, "w:xz", preset=5) as archive:
    for path in sorted(profile.rglob("*")):
        if path.is_file() and not path.name.endswith(".speedscope.json"):
            archive.add(path, arcname=path.relative_to(profile).as_posix())
with tarfile.open(out) as archive:
    for row in rows:
        data = archive.extractfile(row["label"] + "/work.nettrace").read()
        assert hashlib.sha256(data).hexdigest() == row["traceSHA256"]
print(f"Verified four desktop traces in {out.name} ({out.stat().st_size} bytes).")
