set -eu
root=/home/lokad/lython-bench-checks/direct-string-storage-b94-20261102
dotnet=/home/lokad/lython-bench-toolchains/dotnet/11.0.100-rc.3.26522.148/dotnet
export DOTNET_ROOT=/home/lokad/lython-bench-toolchains/dotnet/11.0.100-rc.3.26522.148
exec 9>/home/lokad/lython-bench-checks/comparison-vm.lock
flock -n 9
notes="$root/allocation"
mkdir "$notes"
date -u +%FT%TZ > "$notes/started.utc"
trap 'result=$?; printf "%s\n" "$result" > "$notes/exit-code.txt"; date -u +%FT%TZ > "$notes/stopped.utc"' EXIT
env DOTNET_TieredCompilation=0 "$dotnet" "$root/candidate/Lokad.Lython.Benchmarks.dll" --compare check-machine --out "$notes/machine-before.json" > "$notes/machine-before.log" 2>&1
python3 -c 'import json,sys;assert json.load(open(sys.argv[1]))["gate"]["quiet"]' "$notes/machine-before.json"
python3 "$root/reference-check.py" "$root" /home/lokad/lython-bench-toolchains/cpython/3.13.16/bin/python3.13
for image in baseline candidate control; do
 worker="$root/$image/Lokad.Lython.Benchmarks.dll"
 if [ "$image" = control ]; then worker="$root/baseline/Lokad.Lython.Benchmarks.dll"; fi
 "$dotnet" "$root/phase-$image/Diagnostics.dll" "$worker" "$root/catalog.json" "$notes/$image.json" > "$notes/$image.stdout" 2> "$notes/$image.stderr"
done
env DOTNET_TieredCompilation=0 "$dotnet" "$root/candidate/Lokad.Lython.Benchmarks.dll" --compare check-machine --out "$notes/machine-after.json" > "$notes/machine-after.log" 2>&1
python3 -c 'import json,sys;assert json.load(open(sys.argv[1]))["gate"]["quiet"]' "$notes/machine-after.json"
