import json,pathlib,subprocess,sys
root=pathlib.Path(sys.argv[1]);goldens=json.loads((root/'padding-goldens.json').read_text(encoding='utf-8'));records=[]
for value,width,fill,expected in goldens['cases']:
 source='value='+repr(value)+'\nwidth='+str(width)+'\nfill='+repr(fill)+'\n'+goldens['source']
 run=subprocess.run([sys.argv[2],'-I','-S','-X','utf8','-c',source],capture_output=True,timeout=5)
 assert run.returncode==0 and not run.stderr,(value,width,fill,run.stderr)
 assert run.stdout==expected.encode('utf-8'),(value,width,fill)
 records.append({'value':value,'width':width,'fill':fill,'fullGoldenPassed':True})
(root/'padding-reference-validation.json').write_text(json.dumps(records,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
