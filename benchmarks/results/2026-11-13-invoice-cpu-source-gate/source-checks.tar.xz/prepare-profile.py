from pathlib import Path
import ast, hashlib, json, tarfile
r = Path(__file__).parent; out = r / 'b656'
old = r.parent / 'config-startup-r297'
oldroot = '/home/lokad/lython-bench-checks/config-cpu-b653-20261113'
root = '/home/lokad/lython-bench-checks/invoice-cpu-b656-20261113'
runtime = r.parent / 'call-lifecycle-r301'
source = json.loads((runtime / 'candidate-identity.json').read_text(encoding='utf-8'))
assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest() == sha for p, sha in source['sources'].items())
catalog = json.loads((r / 'invoice.json').read_text(encoding='utf-8'))
catalog['cases'] = [c for c in catalog['cases'] if c['id'] == 'scripts.csv-invoice.large']
assert len(catalog['cases']) == 1
(out / 'catalog.json').write_text(json.dumps(catalog, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
identity = json.loads((r.parent / 'cased-pipeline-r300/b655/identity.json').read_text(encoding='utf-8'))
identity.update(sourceRevision='Qualified fc2531b8/6b468bf1 runtime; b649cbd8 invoice workload; complete composed-helper CPU source gate', purpose='One12s warmed/8s199Hz whole invoice CPU capture; no elapsed or CPython comparison', catalogSHA256=hashlib.sha256((out / 'catalog.json').read_bytes()).hexdigest(), coreSHA256={'candidate': source['coreSHA256']}, sourceIdentitySHA256=hashlib.sha256((runtime / 'candidate-identity.json').read_bytes()).hexdigest())
(out / 'identity.json').write_text(json.dumps(identity, indent=2) + '\n', encoding='utf-8')
code = (old / 'ops-profile.py').read_text(encoding='utf-8').replace(oldroot, root).replace("[('config', 'scripts.config-edit.small', 'warm')]", "[('invoice', 'scripts.csv-invoice.large', 'warm')]").replace('count = 4096 #', 'count = 32 #')
ast.parse(code); (out / 'ops-profile.py').write_text(code, encoding='utf-8', newline='\n')
code = (old / 'collect.py').read_text(encoding='utf-8').replace(oldroot, root).replace("str(root/'profiles')", "str(root/'guest-fixtures/profiles')").replace(" assert not list((root/'guest-fixtures').iterdir())", " assert [p.name for p in (root/'guest-fixtures').iterdir()]==['profiles']").replace("root/'profiles/config/record.json'", "root/'guest-fixtures/profiles/invoice/record.json'")
start = code.index(" subprocess.run(['sudo','-n','umount'")
end = code.index(' assert shutil.disk_usage(root).free', start)
code = code[:start] + ''' trace=root/'guest-fixtures/profiles'
 raw={p.relative_to(trace).as_posix():hashlib.sha256(p.read_bytes()).hexdigest()for p in trace.rglob('*')if p.is_file()}
 with tarfile.open(root/'observations.tgz','w:gz',dereference=True)as archive:
  for p in sorted(root.iterdir()):
   if p.is_file()and p.name not in {'observations.tgz','current-core.dll'}:archive.add(p,arcname=p.name)
  archive.add(trace,arcname='profiles')
 with tarfile.open(root/'observations.tgz')as archive:
  assert json.loads(archive.extractfile('profiles/invoice/record.json').read())['exitCode']==0
  for name,sha in raw.items():assert hashlib.sha256(archive.extractfile('profiles/'+name).read()).hexdigest()==sha
 # Every RAM byte is now preserved and verified persistently, while lease is held.
 subprocess.run(['sudo','-n','umount',str(root/'guest-fixtures')],check=True);(root/'guest-fixtures').rmdir()
''' + code[end:]
code = code.replace("source='31d65e01/e34cacaf'", "source='fc2531b8/6b468bf1; b649cbd8 invoice'")
code = code.replace('archivedAndVerifiedUnderLease=True,', 'archivedAndVerifiedUnderLease=True,ramTraceArchivedAndVerifiedBeforeUnmount=True,')
ast.parse(code); (out / 'collect.py').write_text(code, encoding='utf-8', newline='\n')
(out / 'run.sh').write_text('set -eu\nroot=' + root + '\ntrap \'result=$?; printf "%s\\n" "$result" > "$root/exit-code.txt"\' EXIT\npython3 "$root/collect.py"\n', encoding='utf-8', newline='\n')
files = {name: out / name for name in ['catalog.json', 'identity.json', 'collect.py', 'ops-profile.py', 'run.sh']}
files.update({'current-core.dll': runtime / 'candidate-core.dll', 'source-identity.json': runtime / 'candidate-identity.json'})
with tarfile.open(out / 'payload.tgz', 'w:gz') as archive:
 for name, p in files.items(): archive.add(p, arcname=name)
groups = json.loads((out / 'retirement-inspection.json').read_text(encoding='utf-8'))['groups']
config = dict(root=root, unit='lython-b656-invoice-cpu-20261113', sourceRoot='/home/lokad/lython-bench-checks/cased-pipeline-b655-20261113', identity=identity, retire=groups, payloadBytes=(out / 'payload.tgz').stat().st_size, payloadSHA256=hashlib.sha256((out / 'payload.tgz').read_bytes()).hexdigest(), unpackedBytes=sum(p.stat().st_size for p in files.values()))
(out / 'config.json').write_text(json.dumps(config, indent=2) + '\n', encoding='utf-8')
code = (old / 'retrieve.py').read_text(encoding='utf-8').replace('config-cpu-b653-20261113', 'invoice-cpu-b656-20261113').replace('lython-b653-config-cpu-20261113', 'lython-b656-invoice-cpu-20261113').replace('B650 report', 'B656 invoice')
ast.parse(code); (out / 'retrieve.py').write_text(code, encoding='utf-8')
code = (old / 'analyze.py').read_text(encoding='utf-8').replace('profiles/config', 'profiles/invoice').replace("source='31d65e01/e34cacaf'", "source='fc2531b8/6b468bf1 invoice b649cbd8'").replace('Config CPU gate:', 'Invoice CPU gate:')
ast.parse(code); (out / 'analyze.py').write_text(code, encoding='utf-8')
print('B656 prepared: one complete invoice capture, source-matched core, existing worker; staged bytes', config['unpackedBytes'], flush=True)
