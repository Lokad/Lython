from pathlib import Path
import fcntl,hashlib,json,os,shutil,stat,subprocess
base=Path('/home/lokad/lython-bench-checks').resolve()
with(base/'comparison-vm.lock').open('a')as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 users=subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record|[p]ython3.*cpython-worker.py'],capture_output=True,text=True)
 assert users.returncode==1,users.stdout
 known=[base/'cased-pipeline-b655-20261113/candidate/Lokad.Lython.dll',base/'cased-pipeline-b655-20261113/reference/Lokad.Lython.dll']
 rows=[]
 for p in known:
  s=p.lstat();assert p.resolve()==p and stat.S_ISREG(s.st_mode)and s.st_uid==os.getuid()
  sha=hashlib.sha256(p.read_bytes()).hexdigest();proof=next(x for x in [{'canonical': 'benchmarks/results/2026-11-13-cased-word-pipeline/local/source-checks.tar.xz', 'member': 'candidate-core.dll', 'bytes': 5673472, 'sha256': '1fff156bd5f402527ff620a82be1cd8e4ae1c45c01336a4fd575ede571cdb69c'}, {'canonical': 'benchmarks/results/2026-11-13-cased-word-pipeline/local/source-checks.tar.xz', 'member': 'reference/Lokad.Lython.dll', 'bytes': 5674496, 'sha256': 'd7b2ddafb1e5ff7c00152cfaa182d12c057a967a0910015d2ab80beecff9089b'}] if x['sha256']==sha)
  aliases=[]
  for folder,dirs,files in os.walk(base,followlinks=False):
   for name in files:
    a=Path(folder)/name;z=a.lstat()
    if(z.st_dev,z.st_ino)==(s.st_dev,s.st_ino):
     assert a.resolve()==a and stat.S_ISREG(z.st_mode)and z.st_uid==os.getuid()
     aliases.append(str(a.relative_to(base)))
  rows.append(dict(path=str(p.relative_to(base)),sha256=sha,bytes=s.st_size,allocatedBytes=s.st_blocks*512,device=s.st_dev,inode=s.st_ino,links=s.st_nlink,allAliasesInBase=len(aliases)==s.st_nlink,aliases=aliases,canonical=proof))
 print(json.dumps(dict(freshIdleLease=True,freeBytes=shutil.disk_usage(base).free,groups=rows)))
