using Lokad.Utf8Regex;
using Lokad.Utf8Regex.PythonRe;
using System.Security.Cryptography;

var subject = new byte[32769];
subject.AsSpan().Fill((byte)'a');
subject[^1] = (byte)'!';
using var regex = new Utf8PythonRegex("(?P<pairs>(aa)+)!"u8);
Console.WriteLine($"Core SHA256 {Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(typeof(Lokad.Utf8Regex.Utf8Regex).Assembly.Location)))}");
Console.WriteLine($"PythonRe SHA256 {Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(typeof(Utf8PythonRegex).Assembly.Location)))}");

var budget = new ObservedAllowance();
using (var create = new CancellationTokenSource())
using (var advance = new CancellationTokenSource())
{
    budget.OnAdmission = create.Cancel;
    try
    {
        using var cursor = regex.CreateMatchCursor(subject, cancellationToken: create.Token, workingMemoryAllowance: budget);
        throw new Exception("Creation did not stop after cancellation inside admission.");
    }
    catch (OperationCanceledException error) when (error.CancellationToken == create.Token)
    {
        Require(budget.Admissions > 0 && budget.Balance == 0, "Creation must release the working allowance.");
        Console.WriteLine($"Create cancelled after admission {budget.Admissions} and refunded the working allowance.");
    }
}

budget = new ObservedAllowance();
using (var create = new CancellationTokenSource())
using (var advance = new CancellationTokenSource())
{
    using var cursor = regex.CreateMatchCursor(subject, cancellationToken: create.Token, workingMemoryAllowance: budget);
    var creationAdmissions = budget.Admissions;
    Require(creationAdmissions > 0, "Expected real cursor construction work.");
    create.Cancel();
    try
    {
        cursor.MoveNext(out _, advance.Token);
        throw new Exception("Old caller token no longer overrides the active advance token.");
    }
    catch (OperationCanceledException error) when (error.CancellationToken == create.Token)
    {
        Require(!advance.IsCancellationRequested && budget.Balance == 0, "Failed advance must refund the working allowance.");
        Console.WriteLine($"An earlier creation token still cancels a later advance. Creation admissions {creationAdmissions}. The active advance token remains live.");
    }
}

budget = new ObservedAllowance();
using (var advance = new CancellationTokenSource())
{
    using var cursor = regex.CreateMatchCursor(subject, workingMemoryAllowance: budget);
    var creationAdmissions = budget.Admissions;
    budget.OnAdmission = advance.Cancel;
    try
    {
        cursor.MoveNext(out _, advance.Token);
        throw new Exception("Advance did not stop after cancellation inside admission.");
    }
    catch (OperationCanceledException error) when (error.CancellationToken == advance.Token)
    {
        Require(budget.Admissions > creationAdmissions && budget.Balance == 0, "Cancelled advance must return its scratch.");
        Console.WriteLine($"Advance-only token cancelled during admission and refunded. Creation {creationAdmissions}, total {budget.Admissions}.");
    }
}

budget = new ObservedAllowance();
using (var create = new CancellationTokenSource())
using (var creationBridge = new CancellationTokenSource())
{
    Utf8PythonMatchCursor cursor;
    using (create.Token.Register(static state => ((CancellationTokenSource)state!).Cancel(), creationBridge))
        cursor = regex.CreateMatchCursor(subject, cancellationToken: creationBridge.Token, workingMemoryAllowance: budget);
    using (cursor)
    {
        create.Cancel();
        Require(!creationBridge.IsCancellationRequested && cursor.MoveNext(out var match)
            && match.LastIndex == 1 && !cursor.MoveNext(out _), "The detached creation bridge must preserve the later match.");
    }
    Require(budget.Balance == 0, "Successful cursor must return all working allowance.");
    Console.WriteLine("Adapter-local creation bridge detaches earlier caller cancellation and the cursor refunds at EOF.");
}

static void Require(bool condition, string message)
{
    if (!condition) throw new InvalidOperationException(message);
}

sealed class ObservedAllowance : IUtf8MemoryAllowance
{
    public ulong Balance { get; private set; }
    public int Admissions { get; private set; }
    public Action? OnAdmission { get; set; }

    public bool TryReserve(ulong bytes)
    {
        Admissions++;
        Balance = checked(Balance + bytes);
        OnAdmission?.Invoke();
        return true;
    }

    public void Release(ulong bytes) => Balance = checked(Balance - bytes);
}
