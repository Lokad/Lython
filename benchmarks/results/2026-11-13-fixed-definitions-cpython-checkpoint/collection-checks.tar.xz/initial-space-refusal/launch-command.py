from pathlib import Path
import ast,fcntl,hashlib,io,json,os,shutil,stat,subprocess,sys,tarfile
config={'root': '/home/lokad/lython-bench-checks/retained-external-b683-20261113', 'unit': 'lython-b683-retained-external-20261113', 'sourceRoot': '/home/lokad/lython-bench-checks/builtin-setup-corrected-b682-20261113', 'identity': {'auxiliaryFiles': {'Azure.Core.dll': '1d6df436afdc73c30d476be938f6513c90ef8fc884a7bae280091a9bed0a5490', 'Azure.Identity.dll': '31574a3d35ffeb0e25a00ebb317937222fe5283b91af608613f2e3bf0f26c50a', 'BenchmarkDotNet.Annotations.dll': '97974c60500f53a3c7d142088b22d815aae7aac729de69f4b497132cc436594f', 'BenchmarkDotNet.dll': '599ded314fe77dbc17318557e787cf660c1fcb0d69be39994ea462ca95745896', 'CommandLine.dll': '8a55501cd1a1590a4bd93a17c6fdd2c01a0ed5bff1aea9036bdc78d98c9a3fad', 'deniszykov.WebSocketListener.dll': 'c86cfb93e32192ae12fb1a132b4ae785a7d2f325e8583c03c99abf8e832d25d6', 'Dia2Lib.dll': '6c4cac68010fe032218efe5e9fcf46eef9f77bfaa5f3bd33f03c5ff77d5a8fac', 'Gee.External.Capstone.dll': '6dfda67784598de9677173b89d0692593935f1a4024d36040c95dea48c1b5965', 'Iced.dll': 'f058c01321b4cdfc9b9151879e88e59571c8d0ba176fbcf95bc936a8f3d073ed', 'Lokad.Lython.Benchmarks.deps.json': 'b47f293f779ce46eefa92c6eb775842efe363be212c35bf7d155d0b89734d450', 'Lokad.Lython.Benchmarks.dll': 'fec79afdb8425f18aa962d5ff9a3e51ae52f519072ea9d9db8ab69a0c52b69a6', 'Lokad.Lython.Benchmarks.runtimeconfig.json': 'c2ecf2430d6785354d9099b35eef9d6ac3d72f2089dc3dc9fd723558265b83d0', 'Lokad.Lython.Utf8Regex.dll': '9f7282ade883f103956efaf7e46182f7705fb7675f1f46963b9c42ae5aae7f94', 'Lokad.Utf8Regex.dll': 'af5fb1e550cf23559bc7e26ef3d895b45e5ef98d57bcf46b414785a6e24cc857', 'Lokad.Utf8Regex.PythonRe.dll': '96e45b20c1db361a9b3b94bd557405b413510801bdb1488ae5b15d6aae7aedfe', 'Microsoft.Bcl.AsyncInterfaces.dll': 'bf58b47923b2f520c766ca905f68a1a65d217c4d828f05db538c41129cacf9d9', 'Microsoft.CodeAnalysis.CSharp.dll': '1af1de8a162d2312eb2f6b781f5edbe8cec7d5cd268c7e4de24396225e54260f', 'Microsoft.CodeAnalysis.dll': '42c9ce7891470f430267e2dc02d03571f9d046a7e7e121107754bee58d344613', 'Microsoft.Diagnostics.FastSerialization.dll': 'e5bdad179ce97180646f37f357cb7b449f5baaf76f185eb09510eeafc5b773e1', 'Microsoft.Diagnostics.NETCore.Client.dll': 'e2cc9e1f6c97b3c4ee45ebabaa92408eb9b2fc81cb08ceeb342fe48bf79db15f', 'Microsoft.Diagnostics.Runtime.dll': '52d5f113180bb0f70b1a9b10608aef93b187364ac689885d2d3c734102d850a2', 'Microsoft.Diagnostics.Tracing.TraceEvent.dll': '92401392ce1887c3483a3c0085e6cc3656ee39da1be539943096ebabbad6ea21', 'Microsoft.Identity.Client.dll': '5795027e9ae95eececb310a4fed3c502bb368039d186ab0884f64b7792b84717', 'Microsoft.Identity.Client.Extensions.Msal.dll': '07109a2f30df782300077a567ade47cbd0a0502c75cd7c8a62192f7d64bb004e', 'Microsoft.IdentityModel.Abstractions.dll': '24e97b54b6b5c234a124a336757e3116617ac6c30b655cdae74517dc2ecb5746', 'Perfolizer.dll': '4a5508174e2b90a651a29e1de0d2ad88236daaaae01070cd6fc8ca3c36beaa36', 'Pragmastat.dll': '7217e206e47de8a0335f58513019d5805a6e52ca2e8f127e2cc3944f1742bb2e', 'System.ClientModel.dll': 'dec5e22b71a1685c5e6e97cd28b629f0aa6703fb87b6950df28e79fc1804290c', 'System.Memory.Data.dll': '2c1035b0106dbb2de7913d151e06071ed617bb58bbb3d6cd46a2dd0f6a03617b', 'System.Security.Cryptography.ProtectedData.dll': '80566f0839ece5946e66bf9f00d723e59e371ba1341a18e00c7c7a7c49298e1d', 'TraceReloggerLib.dll': '6830c0f1d3f3c17719181e73dd5cfa8ccbb3f3c575329d2120576545103467b5'}, 'referenceSourceIdentitySHA256': 'baeda30610f7ac3023280083e7a7ba2e1318cf3574f1fedf4aa8fe1c0b0da4e2', 'sourceRevision': 'Committedcb8736ff/frozen5a184a1d; source-matched full GREEN required at launch; CPython3.13.16 checkpoint', 'purpose': 'Seven material phase comparisons: invoice compilation/warm/compile-run; captured text, JSON, file search and report warm', 'coreSHA256': {'reference': '5a184a1d40a111ef2217f58789a66443fcc42540c850b79b562dcdb800ff740c', 'candidate': '5a184a1d40a111ef2217f58789a66443fcc42540c850b79b562dcdb800ff740c', 'reference-control': '5a184a1d40a111ef2217f58789a66443fcc42540c850b79b562dcdb800ff740c', 'candidate-control': '5a184a1d40a111ef2217f58789a66443fcc42540c850b79b562dcdb800ff740c'}, 'catalogSHA256': '4f92405c77d983ef659812794d0ff3215f08461d4104be2f671684ef3d5ee394', 'sourceIdentitySHA256': 'baeda30610f7ac3023280083e7a7ba2e1318cf3574f1fedf4aa8fe1c0b0da4e2', 'productionSourceArchiveSHA256': 'ff98e1b73d84a80112fcce090809ad5a63727d41ec40c29ba3cb92b4ecf65e16'}, 'payloadBytes': 1924043, 'payloadSHA256': '66a12110bd021cfdc2aa3e8b4414e5612590242d0ed710bc2844fa6dc1eeb008', 'unpackedBytes': 5771441, 'retire': [{'path': 'selected-call-b680-20261113/representative.json', 'canonical': 'benchmarks\\results\\2026-11-13-selected-native-call\\observations.tgz', 'member': 'representative.json', 'sha256': 'e4fa68ee8743e9014caeffe5ad15a1871fb60a1ab81e119758819144de94b6c6', 'bytes': 1682299, 'device': 66305, 'inode': 845785, 'links': 13, 'allocatedBytes': 1687552, 'aliases': ['selected-call-b680-20261113/representative.json', 'tuple-return-refined-b667-20261113/representative.json', 'window-capacity-b676-20261113/representative.json', 'integer-report-b674-20261113/representative.json', 'integer-b661-20261113/representative.json', 'tuple-return-b666-20261113/representative.json', 'native-return-external-b671-20261113/representative.json', 'tuple-return-direct-b668-20261113/representative.json', 'window-capacity-rough-b678-20261113/representative.json', 'file-search-source-b675-20261113/catalog.json', 'window-capacity-rough-allocation-b679-20261113/catalog.json', 'integer-chain-b672-20261113/representative.json', 'tuple-return-final-b669-20261113/representative.json']}, {'path': 'builtin-setup-b681-20261113/candidate/Lokad.Lython.dll', 'canonical': 'benchmarks\\results\\2026-11-13-builtin-core-definitions\\source-checks.tar.xz', 'member': 'candidate-core.dll', 'sha256': '7ee65002ee91b5750c30c42e8f7792de1e9123ed58e55656dcb1d84fc2c69520', 'bytes': 5680640, 'device': 66305, 'inode': 846145, 'links': 3, 'allocatedBytes': 5685248, 'aliases': ['builtin-setup-b681-20261113/current-core.dll', 'builtin-setup-b681-20261113/candidate/Lokad.Lython.dll', 'builtin-setup-corrected-b682-20261113/candidate/Lokad.Lython.dll']}], 'qualificationHead': '90de765df903e7e7816cf34f5719bf50c041e8a4', 'qualificationRun': '43450480558', 'qualificationDirectory': 'D:\\code\\Lython\\.git\\agent-notes\\review-20261031\\checkpoint-cpython-r318\\staging-delivery'}
base=Path('/home/lokad/lython-bench-checks').resolve()
root=Path(config['root']);source=Path(config['sourceRoot'])
assert root.parent==base and source.parent==base and source.resolve()==source and not root.exists()
digest=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
with(base/'comparison-vm.lock').open('a')as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert not(source/'guest-fixtures').exists()
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[d]otnet.*complete-jobs.dll|[p]erf record|[p]ython3.*cpython-worker.py'],capture_output=True).returncode==1
 for name,sha in config['identity']['auxiliaryFiles'].items():assert digest(source/'reference'/name)==sha
 assert digest(source/'reference/Lokad.Lython.dll')=='485e008e1aee088999c5d426bbd48e4290c00df0e85d1f7687848d55d75214c7'
 assert digest(source/'representative.json')==config['identity']['catalogSHA256']
 payload=sys.stdin.buffer.read(config['payloadBytes']+1)
 assert len(payload)==config['payloadBytes'] and hashlib.sha256(payload).hexdigest()==config['payloadSHA256']
 before=shutil.disk_usage(base).free
 for old in config['retire']:
  p=base/old['path'];s=p.lstat()
  assert p.resolve(strict=True)==p and p.is_relative_to(base) and stat.S_ISREG(s.st_mode) and s.st_uid==os.getuid()
  assert(s.st_dev,s.st_ino,s.st_nlink,s.st_size)==(old['device'],old['inode'],old['links'],old['bytes'])
  assert digest(p)==old['sha256']
  aliases=[]
  for folder,dirs,files in os.walk(base,followlinks=False):
   for name in files:
    q=Path(folder)/name;t=q.lstat()
    if(t.st_dev,t.st_ino)==(s.st_dev,s.st_ino):aliases.append(str(q.relative_to(base)))
  assert sorted(aliases)==sorted(old['aliases']) and len(aliases)==s.st_nlink
  assert all('/reference/'not in name and 'retained-external-b683'not in name for name in aliases)
 assert before+sum(old['allocatedBytes']for old in config['retire'])>252*1024*1024+config['unpackedBytes']+2*1024*1024
 # Retire only byte-proved obsolete working copies; canonical Git evidence remains.
 for old in config['retire']:
  for name in old['aliases']:
   q=base/name;t=q.lstat()
   assert q.resolve(strict=True)==q and q.is_relative_to(base) and(t.st_dev,t.st_ino)==(old['device'],old['inode'])
   q.unlink()
 after_retirement=shutil.disk_usage(base).free
 assert after_retirement>252*1024*1024+config['unpackedBytes']+2*1024*1024
 root.mkdir()
 with tarfile.open(fileobj=io.BytesIO(payload),mode='r:gz')as a:
  assert set(a.getnames())=={'identity.json','collect.py','archive-owned.py','run.sh','current-core.dll','source-identity.json'}
  a.extractall(root,filter='data')
 for name in ['representative.json','cpython-worker.py']:os.link(source/name,root/name)
 os.link(root/'source-identity.json',root/'reference-source-identity.json')
 for role in ['candidate','reference']:
  (root/role).mkdir()
  for name in config['identity']['auxiliaryFiles']:os.link(source/'reference'/name,root/role/name)
  os.link(root/'current-core.dll',root/role/'Lokad.Lython.dll')
  assert digest(root/role/'Lokad.Lython.dll')==config['identity']['coreSHA256'][role]
 assert digest(root/'source-identity.json')==config['identity']['sourceIdentitySHA256']
 assert digest(root/'representative.json')==config['identity']['catalogSHA256']
 for name in ['collect.py','archive-owned.py']:ast.parse((root/name).read_text())
 subprocess.run(['/bin/sh','-n',str(root/'run.sh')],check=True)
 (root/'space-preflight.json').write_text(json.dumps(dict(freshIdleLease=True,beforeFreeBytes=before,afterRetirementFreeBytes=after_retirement,afterStagingFreeBytes=shutil.disk_usage(base).free,osFloorMiB=240,evidenceHeadroomMiB=12,additionalArchiveHeadroomMiB=2,retiredByteProvedCanonicalWorkingCopies=config['retire']),indent=2)+'\n')
 assert shutil.disk_usage(base).free>254*1024*1024
 fixture=root/'guest-fixtures';fixture.mkdir()
 subprocess.run(['sudo','-n','mount','-t','tmpfs','-o','size=128m,mode=0700,uid=lokad,gid=lokad','lython-b683-fixtures',str(fixture)],check=True)
try:subprocess.run(['sudo','-n','systemd-run','--unit='+config['unit'],'--property=User=lokad','--property=WorkingDirectory='+str(root),'--property=RuntimeMaxSec=360','--property=TimeoutStopSec=30','--property=KillMode=control-group','/bin/sh',str(root/'run.sh')],check=True)
except BaseException:
 subprocess.run(['sudo','-n','umount',str(fixture)],check=True);fixture.rmdir();raise
live=subprocess.check_output(['systemctl','show',config['unit']+'.service','--property=ActiveState,MainPID,RuntimeMaxUSec'],text=True)
assert'ActiveState=active'in live and'MainPID=0'not in live
print(live)
