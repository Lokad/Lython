from pathlib import Path
import ast,base64,datetime,hashlib,json,subprocess,tarfile
r=Path(__file__).parent
config=json.loads((r/'config.json').read_text(encoding='utf-8'))
qualification=Path(config.get('qualificationDirectory',str(r.parent)))
terminal=json.loads((qualification/'ci-terminal.json').read_text(encoding='utf-8'))
assert terminal['conclusion']=='success' and terminal['headSha']==config['qualificationHead']
assert str(terminal['url']).endswith('/'+config['qualificationRun'])
for old in config['retire']:
 p=Path(old['canonical'])
 assert subprocess.check_output(['git','show','HEAD:'+p.as_posix()])==p.read_bytes()
 with tarfile.open(p) as a:
  data=a.extractfile(old['member']).read()
  assert len(data)==old['bytes'] and hashlib.sha256(data).hexdigest()==old['sha256']
code=(r/'launch-remote.py').read_text(encoding='utf-8').replace('CONFIG_LITERAL',repr(config))
ast.parse(code)
(r/'launch-command.py').write_text(code,encoding='utf-8',newline='\n')
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
command="python3 -c 'import base64;exec(base64.b64decode(\""+base64.b64encode(code.encode()).decode()+"\"))'"
done=subprocess.run(ssh+[command],input=(r/'payload.tgz').read_bytes(),capture_output=True)
(r/'launch.log').write_bytes(done.stdout+done.stderr)
print((done.stdout+done.stderr).decode(),flush=True)
assert done.returncode==0
now=datetime.datetime.now(datetime.timezone.utc)
(r/'observe-not-before.json').write_text(json.dumps(dict(startedUTC=now.isoformat(),doNotObserveBeforeUTC=(now+datetime.timedelta(seconds=300)).isoformat(),ownerSeconds=360,stopSeconds=30,observationSeconds=300),indent=2)+'\n',encoding='utf-8',newline='\n')
