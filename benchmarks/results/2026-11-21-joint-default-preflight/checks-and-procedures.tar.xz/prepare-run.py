from pathlib import Path
root = Path(".git/agent-notes/review-20261031")
previous = root / "inline-keyword-default-20261121"
lab = root / "joint-default-preflight-20261121"
s = (previous / "prepare-quiet.py").read_text(encoding="utf-8")
s = s.replace('prior = lab.parent / "native-only-method-lookup-20261121"\ndonor = prior / "quiet"',
'''prior = lab.parent / "latest-checkpoint-cpython-20261121"
donor = prior / "quiet"
template = lab.parent / "native-only-method-lookup-20261121/quiet"
template_config = json.loads((template / "config.json").read_text(encoding="utf-8"))''')
a,b = s.index("def tracked("),s.index("prior_config =")
s=s[:a]+'''proof = load(lab / "retire-proof.json")
retire = [proof["proof"]]
'''+s[b:]
s=s.replace('prior / "frozen/candidate"', 'prior / "frozen"')
s=s.replace('local = load(lab / "quiet-images.json")','local = load(lab / "identity.json")')
s=s.replace('reference.startswith("d51891009") and candidate == local["candidate"]', 
            'reference.startswith("4337b7765") and candidate.startswith("6e5261808")')
s=s.replace('lab / "quiet-workers"','lab / "frozen"')
s=s.replace('assert all(reference_donor[name] == value for name, value in hashes.items() if name != core)',
'''assert all(reference_donor[name] == value for name, value in hashes.items() if name != core)
    if role == "reference":
        assert hashes == reference_donor''')
s=s.replace('("white", 322), ("public", 2185)','("white", 5), ("public", 82)')
s=s.replace('prior_config["protocolSHA256"]','prior_config["cpythonWorkerSHA256"]')
s=s.replace('Remove the array holding a single keyword-only default','Joint preflight for mixed inline defaults')
s=s.replace('inline-keyword-default-b1305-20261121','joint-default-preflight-b1308-20261121')
s=s.replace('lython-b1305-inline-keyword-default-20261121','lython-b1308-joint-default-preflight-20261121')
s=s.replace('lython-b1305-fixtures','lython-b1308-fixtures')
s=s.replace('jobs = [(case, "warm") for case in cases] + [(cases[1], "compile-run")]',
            'jobs = [(case, "warm") for case in cases]')
s=s.replace('original = (donor / name).read_text(encoding="utf-8").replace(prior_config["root"], root).replace(prior_config["unit"], unit)',
            'original = (template / name).read_text(encoding="utf-8").replace(template_config["root"], root).replace(template_config["unit"], unit)')
s=s.replace("==5", "==4").replace("jobs=5,", "jobs=4,")
s=s.replace('source = (donor / "remote-launch.py")','source = (template / "remote-launch.py")')
s=s.replace('Inline keyword default comparison','Joint default preflight comparison').replace('.replace("300", "345")','')
s=s.replace('Prepared five lanes','Prepared four lanes')
assert "reference.startswith" in s and 'reference.startswith("4337b7765")' in s
compile(s,str(lab/"prepare-quiet.py"),"exec")
(lab/"prepare-quiet.py").write_text(s,encoding="utf-8",newline="\n")
