from pathlib import Path
root = Path(".git/agent-notes/review-20261031")
previous = root / "inline-keyword-default-20261121"
lab = root / "joint-default-preflight-20261121"
source = (previous/"archive.py").read_text(encoding="utf-8")
source = source.replace("2026-11-21-inline-keyword-default","2026-11-21-joint-default-preflight")
source = source.replace('assert a.startswith("d51891009") and b.startswith("55826c73f")',
                        'assert a.startswith("4337b7765") and b.startswith("6e5261808")')
source = source.replace('assert local["reference"].startswith("3a6accc97") and local["candidate"].startswith("da45b3bf2")',
                        'assert a.startswith(local["reference"]) and b.startswith(local["candidate"])')
source = source.replace('image = lab / "quiet-workers" / role','image = lab / "frozen" / role')
source = source.replace('("white", 322), ("public", 2185)','("white", 5), ("public", 82)')
source = source.replace('len(raw["jobs"]) == receipt["jobs"] == 5','len(raw["jobs"]) == receipt["jobs"] == 4')
source = source.replace('["warm"]*4 + ["compile-run"]','["warm"]*4')
source = source.replace('collection="B1305"','collection="B1308"').replace('verifiedTimedBatches=140','verifiedTimedBatches=112')
source = source.replace('retentionDecision="retain the removed backing and measured factory gains"',
                        'retentionDecision=load(lab / "decision.json")["decision"]')
source = source.replace('("README.md", "allocation-summary.json")','("README.md", "allocation-summary.json", "admission-summary.json")')
source = source.replace('2026-11-21-native-only-method-lookup/candidate-core.dll.gz',
                        '2026-11-21-cpython-retained-checkpoint/measured-core.dll.gz')
source = source.replace("All 140 timed batches","All 112 timed batches")
source = source.replace('allocation = load(lab / "allocation-summary.json")',
'''admissions = load(lab / "admission-summary.json")
assert admissions["source"] == b and a.startswith(admissions["reference"])
assert [row["previous"] - row["prototype"] for row in admissions["rows"]] == [2048,2048,2048,0]
allocation = load(lab / "allocation-summary.json")''')
compile(source,str(lab/"archive.py"),"exec")
(lab/"archive.py").write_text(source,encoding="utf-8",newline="\n")
