set -eu
root=/home/lokad/lython-bench-checks/joint-default-preflight-b1308-20261121
trap 'result=$?; printf "%s\n" "$result" > "$root/exit-code.txt"' EXIT
python3 "$root/collect.py"
