from pathlib import Path
from hashlib import sha256
import json, os, shutil, subprocess
lab=Path(__file__).resolve().parent
repo=lab.parents[3]
trace=lab.parent/"current-factory-admission-20261121"
work=repo/".git/agent-worktrees/dead-block-shape-20261121"
revision=subprocess.check_output(["git","rev-parse","HEAD"],cwd=work,text=True).strip()
assert revision.startswith("6e5261808")
assert not subprocess.check_output(["git","status","--porcelain"],cwd=work)
image=lab/"candidate"
image.mkdir()
for path in (trace/"current").iterdir(): shutil.copyfile(path,image/path.name)
built=work/"src/Lokad.Lython/bin/Release/net11.0/Lokad.Lython.dll"
shutil.copyfile(built,image/built.name)
files={p.name:sha256(p.read_bytes()).hexdigest() for p in image.iterdir()}
assert files[built.name]==sha256(built.read_bytes()).hexdigest()
sdk=Path.home()/".dotnet11"
env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk),PATH=str(sdk)+os.pathsep+os.environ["PATH"])
catalog=lab.parent/"inline-keyword-default-20261121/representative.json"
with (lab/"candidate-admissions.json").open("wb") as output:
    subprocess.run([sdk/"dotnet.exe",image/"Probe.dll",catalog],cwd=repo,env=env,check=True,stdout=output,timeout=55)
before,after=[json.loads(p.read_text(encoding="utf-8-sig")) for p in (trace/"current.json",lab/"candidate-admissions.json")]
rows=[]
for left,right in zip(before,after,strict=True):
    assert left["id"]==right["id"]
    delta=left["Growths"]-right["Growths"]
    assert delta==(0 if "fully-supplied" in left["id"] else 2048), (left,right)
    if delta: assert any(entry["bytes"]==520 and entry["count"]==2048 for entry in right["sources"])
    rows.append(dict(case=left["id"],previous=left["Growths"],prototype=right["Growths"]))
(lab/"admission-summary.json").write_text(json.dumps(dict(source=revision,reference="4337b7765",workerFiles=files,rows=rows),indent=2)+"\n",encoding="utf-8",newline="\n")
print(json.dumps(rows),flush=True)
