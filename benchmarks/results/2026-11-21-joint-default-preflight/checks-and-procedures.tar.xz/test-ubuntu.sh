set -euo pipefail
cd /mnt/d/code/Lython/.git/agent-worktrees/dead-block-shape-20261121
export DOTNET_ROOT="$HOME/.dotnet"
export PATH="$DOTNET_ROOT:$PATH"
logs=/mnt/d/code/Lython/.git/agent-notes/review-20261031/joint-default-preflight-20261121
filter='Category!=Stress&(FullyQualifiedName~FunctionDefault|FullyQualifiedName~PreparedFunctionDefaults|FullyQualifiedName~BindingPlanConstruction)'
dotnet test tests/Lokad.Lython.Tests -c Release -f net10.0 --filter "$filter" --verbosity quiet > "$logs/white-ubuntu.log" 2>&1
dotnet test tests/Lokad.Lython.PublicApi.Tests -c Release -f net10.0 --filter "$filter" --verbosity quiet > "$logs/public-ubuntu.log" 2>&1
grep 'Passed!' "$logs/white-ubuntu.log" "$logs/public-ubuntu.log"
