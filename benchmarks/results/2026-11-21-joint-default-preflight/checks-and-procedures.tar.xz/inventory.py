from pathlib import Path
import gzip
import hashlib
import json
import subprocess


lab = Path(__file__).resolve().parent
repo = lab.parents[3]
remote = r'''
from pathlib import Path
import fcntl, hashlib, json, os, shutil, subprocess

root = Path("/home/lokad/lython-bench-checks").resolve()
with (root / "comparison-vm.lock").open("a") as lease:
    fcntl.flock(lease, fcntl.LOCK_EX | fcntl.LOCK_NB)
    assert not any(os.path.ismount(p) for p in root.glob("*/guest-fixtures"))
    listing = {}
    for stage in root.glob("*-20261121"):
        archive = stage / "observations.tgz"
        receipt = stage / "archive-receipt.json"
        if not archive.is_file() or not receipt.is_file():
            continue
        archived = json.loads(receipt.read_text())
        if not (archived.get("complete") and archived.get("archivedAndVerifiedUnderLease")):
            continue
        for role in ("candidate", "reference", "current"):
            core = stage / role / "Lokad.Lython.dll"
            if not core.is_file() or core.is_symlink():
                continue
            stat = core.stat()
            key = (stat.st_dev, stat.st_ino)
            group = listing.setdefault(key, dict(paths=[], archives={}, bytes=stat.st_size, links=stat.st_nlink,
                                                 sha256=hashlib.sha256(core.read_bytes()).hexdigest()))
            group["paths"].append(str(core.relative_to(root)))
            group["archives"][str(archive.relative_to(root))] = archived["archiveSHA256"]
    print(json.dumps(dict(free=shutil.disk_usage(root).free, groups=list(listing.values()))))
'''
ssh = ["C:/Windows/System32/OpenSSH/ssh.exe", "-i", str(Path.home() / ".ssh/id_lython-bench.pem"),
       "-o", "BatchMode=yes", "-o", "ConnectTimeout=15", "lokad@20.166.121.73", "python3 -"]
process = subprocess.run(ssh, input=remote, capture_output=True, text=True, encoding="utf-8", timeout=40)
assert process.returncode == 0, process.stderr
actual = json.loads(process.stdout)
(lab / "inventory.json").write_text(process.stdout, encoding="utf-8", newline="\n")
known = {}
for case in (repo / "benchmarks/results").glob("2026-11-21-*"):
    for archive in case.glob("*core.dll.gz"):
        member = archive.relative_to(repo).as_posix()
        proc = subprocess.run(["git", "show", "HEAD:" + member], cwd=repo, capture_output=True)
        if proc.returncode == 0:
            digest = hashlib.sha256(gzip.decompress(proc.stdout)).hexdigest()
            known.setdefault(digest, member)
matches = []
for group in actual["groups"]:
    if group["links"] != len(group["paths"]) or group["sha256"] not in known:
        continue
    matches.append(dict(**group, verifiedCanonicalGitImage=known[group["sha256"]]))
result = dict(free=actual["free"], groups=matches)
(lab / "reproducible-remote-images.json").write_text(json.dumps(result, indent=2) + "\n",
                                                    encoding="utf-8", newline="\n")
for group in matches:
    print(group["bytes"], group["paths"], group["verifiedCanonicalGitImage"])
print("Free bytes:", actual["free"])
