from pathlib import Path
root=Path(".git/agent-notes/review-20261031")
target=root/"joint-default-preflight-20261121"
text=(root/"inline-keyword-default-20261121/measure.py").read_text(encoding="utf-8")
text=text.replace('baseline = "3a6accc97"','baseline = "4337b7765"').replace('candidate = "da45b3bf2"','candidate = "6e5261808"')
text=text.replace('    assert subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=root, text=True).startswith(revision)',
'''    if root == repo:
        subprocess.run(["git", "diff", "--exit-code", revision, "HEAD", "--", "src", "tests"], cwd=root, check=True)
    else:
        assert subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=root, text=True).startswith(revision)''')
text=text.replace('donor = lab.parent / "native-only-method-lookup-20261121"','donor = lab.parent / "latest-checkpoint-cpython-20261121"')
text=text.replace('identity = load(donor / "quiet/identity.json")["imageFiles"]["candidate"]\nreference = donor / "frozen/candidate"',
                  'identity = load(donor / "quiet/identity.json")["imageFiles"]["candidate"]\nreference = donor / "frozen"')
text=text.replace('origin = root / "src/Lokad.Lython/bin/Release/net11.0" / name if name == core else reference / name',
                  'origin = root / "src/Lokad.Lython/bin/Release/net11.0" / name if role == "candidate" and name == core else reference / name')
compile(text,str(target/"measure.py"),"exec")
(target/"measure.py").write_text(text,encoding="utf-8",newline="\n")
