from pathlib import Path
import hashlib, json, subprocess, gzip

lab = Path(__file__).resolve().parent
repo = lab.parents[3]

def load(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))

index = load(lab/"reproducible-remote-images.json")
reference = lab.parent/"latest-checkpoint-cpython-20261121/quiet"
identity = load(reference/"identity.json")
assert identity["sourceRevision"].startswith("4337b7765")
assert load(lab/"identity.json")["imageFiles"]["reference"] == identity["imageFiles"]["candidate"]
minimum = 176160768
needed = (lab/"frozen/candidate/Lokad.Lython.dll").stat().st_size + 660*1024
deadline_slack = index["free"] + sum(
    group["bytes"] for group in index["groups"]
    if group["sha256"] != identity["coreSHA256"]["candidate"])
assert deadline_slack > minimum + needed
# Compute the known raw hashes from tracked artifacts only. Linux preflight
# verifies every alias and raw archive again under the collection lease.
raw = {}
for item in (repo/"benchmarks/results").glob("2026-11-21-*/**/observations.tgz"):
    relative = item.relative_to(repo).as_posix()
    archived = subprocess.run(["git", "show", "origin/master:" + relative], cwd=repo, capture_output=True)
    if archived.returncode == 0:
        raw.setdefault(hashlib.sha256(archived.stdout).hexdigest(), relative)
choices = []
for entry in index["groups"]:
    if entry["sha256"] == identity["coreSHA256"]["candidate"] or entry["links"] != len(entry["paths"]):
        continue
    if not all(h in raw for h in entry["archives"].values()):
        continue
    if not all(p.split("/")[0] + "/observations.tgz" in entry["archives"] for p in entry["paths"]):
        continue
    if index["free"] + entry["bytes"] <= minimum + needed:
        continue
    binary = subprocess.check_output(["git", "show", "origin/master:" + entry["verifiedCanonicalGitImage"]], cwd=repo)
    core = gzip.decompress(binary)
    assert len(core) == entry["bytes"] and hashlib.sha256(core).hexdigest() == entry["sha256"]
    choices.append(entry)
assert choices, "No independently recoverable image leaves sufficient disk space."
selected = min(choices, key=lambda entry: (entry["links"], entry["paths"]))
proof = {key:selected[key] for key in ("paths","links","bytes","sha256","archives")}
proof["optional"] = False
(lab/"retire-proof.json").write_text(json.dumps(dict(recoverableArtifact=selected["verifiedCanonicalGitImage"],
    archiveCopies={remote:raw[h] for remote,h in selected["archives"].items()},
    proof=proof),indent=2)+"\n",encoding="utf-8",newline="\n")
print("Selected recoverable image", selected["verifiedCanonicalGitImage"], selected["paths"])
