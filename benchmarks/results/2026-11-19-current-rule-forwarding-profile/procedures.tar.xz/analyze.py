from pathlib import Path
import bisect,collections,gzip,json,re
r=Path(__file__).parent;rows=[]
for label in ['rules', 'forwarding', 'captured']:
 f=r/'retrieved/profiles'/label;record=json.loads((f/'record.json').read_text(encoding='utf-8'));ranges=[];malformed=[]
 for line in gzip.open(f/'perf.map.gz','rt',encoding='utf-8').read().splitlines(keepends=True):
  parts=line.rstrip().split(' ',2)
  if len(parts)!=3 or not line.endswith('\n'):malformed.append(line);continue
  start,size,name=parts;ranges.append((int(start,16),int(size,16),name))
 ranges=sorted(set(ranges));starts=[x[0]for x in ranges];prefix=[]
 for start,size,name in ranges:prefix.append(max(start+size,prefix[-1]if prefix else 0))
 def symbol(address,fallback):
  index=bisect.bisect_right(starts,address)-1;matches=set()
  while index>=0 and prefix[index]>address:
   start,size,name=ranges[index]
   if start<=address<start+size:matches.add(name)
   index-=1
  return next(iter(matches))if len(matches)==1 else'[ambiguous] '+repr(sorted(matches))if matches else fallback
 samples=[];current=None;allThreads=collections.Counter()
 for line in gzip.open(f/'all-thread-stacks.txt.gz','rt',encoding='utf-8').read().splitlines():
  header=re.match(r'^.*?\s(\d+)\s+\d+\.\d+:\s+\d+\s+cpu-clock:',line)
  if header:
   allThreads[header[1]]+=1;current=[]
   if current is not None:samples.append(current)
   continue
  frame=re.match(r'^\s+([0-9a-f]+)\s+(.*)$',line)
  if current is not None and frame:current.append(symbol(int(frame[1],16),frame[2]))
 leaves=collections.Counter(s[0]for s in samples if s);nearest=collections.Counter(next((n for n in s if'Lokad.Lython.'in n),'[no Lython frame]')for s in samples if s)
 groups={'frontend':['LythonFrontend','Parser','Lexer','ExecutableScript','ExecutableStackLayout','LoweredScript'],'invocation setup':['CreateBuiltinVariables','ExecutionState','CreateRoot','CreateModuleVariables'],'function entry/binding/retirement':['StartNativeCall','StartInline','TryStartBoundInvocation','EnterFunctionCall','LeaveFunctionCall','BindFunctionArgumentsInto','ReturnBoundArguments'],'closed instruction execution':['NativeExecution','ExecutableKernel','ExecuteInstructionPrefix'],'iteration and cased preparation':['Cased','CaseMapped','Whitespace','PyFileObject','StringWordCursor'],'dictionary accumulation':['DictionaryLoop','TryAccumulate','NativeTextIndex'],'cooperative checks':['CheckExecution','CheckCancellation'],'text/bulk':['PyStringOps','GovernedByteBuilder','StringJoin','AppendField'],'JSON':['Json','Utf8Json'],'iteration':['Generator','TryBufferYield','PyIteration','Cursor.Move']}
 def method_key(method):
  head=method.split('(',1)[0]
  if '::' not in head:return head
  owner,name=head.rsplit('::',1);return owner.split()[-1]+'::'+name
 groups.update({'receiver entry':['InvokeReceiverMethod','TryInvokeClosedReceiver'],'interpreter guard':['EnterInterpreterFrame','LeaveInterpreterFrame','GuardedInvocation'],'function complete entry':['StartNativeCall','TryStartBoundInvocation','BindIntoSlots','EnterFunctionCall','LeaveFunctionCall','InitializeFrame'],'storage admission':['MemoryReservation','MemoryScope','MemoryBudget','MemoryGovernor']})
 inclusive={name:sum(any(any(part in method_key(method)for part in parts)for method in stack)for stack in samples)for name,parts in groups.items()}
 guest=[stack for stack in samples if any('Lokad.Lython.Runtime.' in frame for frame in stack)]
 fixture=[stack for stack in samples if not any('Lokad.Lython.Runtime.' in frame for frame in stack)
          and any('ComparisonFileHost' in frame or 'ValidateFixtureDirectory' in frame for frame in stack)]
 guest_nearest=collections.Counter(next(n for n in stack if'Lokad.Lython.Runtime.' in n) for stack in guest if stack)
 focus={
     'function construction':('ExecuteExecutableFunctionDefinition','CreateLoweredFunction','EvaluateFunctionDefaults','CaptureExecutableClosures','ChargeClosureRetention','ChargeFunctionValue','CreateLambdaFunction'),
     'positional default materialization':('FromReservedOwnedArray','EstimateStorageBytes','PendingFunctionDefaults::Complete'),
     'prepared record':('CreateDefinitionRecord','PrepareDefinition','AddDefinitionValue','RecordKeys::CreateRecord'),
     'lexical frame creation':('EnterInvocationFrame','InitializeExecutableFrame','CreateNativeContinuation','TryGetCell'),
     'frame operand storage':('RentFunctionArgumentStorage','InitializeExecutableFrame','RestoreNativeExtent','ReturnBoundArguments'),
     'governor resize and admission':('MemoryGovernor::Reserve','MemoryGovernor::ResizeOwnership','TryResize'),
     'lowered default path':('EvaluateDefaultsAsync',),
     'lowered expression dispatch':('EvaluateLoweredExpression','DispatchLoweredExpressionAsync','EvaluateLoweredBinary'),
     'prepared definition operation':('ExecutePreparedDefinitionOperation',),
     'borrowed invocation':('InvokeOwnedExecutableTargetAsync','TryStartBoundInvocation','StartNativeCall','StartInline'),
     'function metadata':('CaptureFunctionDocstring','AttachTypeMetadata','CreateTypeScope','CaptureClosureMetadata'),
     'definition storage':('PendingFunctionDefaults','FunctionParameterLayout','FunctionBindingPlan','CaptureExecutableClosures'),
     'definition execution':('CreateExecutableFunction','CreateLambdaFunction','ExecutePreparedDefinitionOperation'),
     'closure retention':('ChargeClosureRetention','CaptureExecutableClosures'),
     'live argument frame':('CreateNativeContinuation','EnterInvocationFrame','ExecuteInitializedFrame','RentFunctionArgumentStorage'),
     'function defaults':('PendingFunctionDefaults','EvaluateDefaultsAsync','TryGetPositionalDefault','TryGetNativeKeywordIndex'),
     'trailing mapping and native call operands':('StartNativeCall','TryStartBoundInvocation','BindPreparedKeywords','BuildFixedFunctionKeywords','BuildTrailingCallDictionary','InvokeTrailing'),
     'formatting':('StringMembers::Format','FormatTemplate','FormatField','FormatValue','PyFormat','FormatSpan','FormatString','AppendField','ReadNextField'),
     'expanded argument construction and binding':('CallExpansion','CallArgumentAccumulator','BindFunctionArguments','CreateVariadicPositionalTuple','TryAddNativeString'),
     'staged text output':('TextFileWriteState','TextFileHandle::Write','WriteUtf8','WriteEncodedText','EncodedTextByteCount'),
     'dictionary field lookup':('NativeTextIndex','ReadSubscriptValue','TryGetNativeKey','TryGetValue','FindNativeIndex'),
     'unpack publication':('PublishUnpackedTarget','UnpackValues','MaterializeUnpackingSequence'),
     'split construction':('BuildSplitResult','SplitCore','TryReadSplitRange','CreateSplitFragment'),
     'native calls':('StartNativeCall','TryInvokeClosedReceiver','InvokeReceiverMethod','CallFunction'),
     'protected reads':('TryReadLine','ReadLineAsync','MoveNextLine','FileIterator'),
     'rstrip':('RStrip','ScanWhitespaceSuffix'),
     'join and drain':('JoinParts','StringMembers::Join','MaterializeLeased','DrainLeased'),
     'generator':('PyGenerator','TryBufferYield'),
     'replacement':('ReplaceByteContent','ReplaceSingleByte'),
     'expandtabs':('ExpandTabs',),
     'host input or output in runtime ancestry':('TextFileHandle','ComparisonFileHost','OpenedByteFile','TextFileWriteState'),
 }
 focus.update({
     'core regex projection':('ProjectScalarBounds','PreparedSubject::Project','CreateMatchObject','RegexScalarPosition','SelectCloserBoundary'),
     'optional adapter':('Utf8RegexProvider','Utf8RegexMatch','PythonRe','MatchCursor'),
     'regex access and substring':('ResolveGroupBounds','GetBoundsCore','MaterializeGroup','GroupBytes'),
     'body call preparation':('BindExecutable','StartExecutable','NativeCallsPrepare','TryStartBoundInvocation','StartNativeCall','StartInline'),
 })
 focused={name:sum(any(any(x in method_key(frame) for x in fragments) for frame in stack) for stack in guest)
          for name,fragments in focus.items()}
 nearest_helpers = collections.Counter()
 reserve_ancestors = collections.Counter()
 reserve_without_caller = 0
 for stack in guest:
  runtime = [method_key(name) for name in stack if 'Lokad.Lython.Runtime.' in name]
  nearest_helpers[runtime[0]] += 1
  if not runtime[0].endswith('MemoryGovernor::Reserve'):
   continue
  caller = next((method for method in runtime[1:] if 'MemoryGovernor' not in method), None)
  if caller is None:
   reserve_without_caller += 1
  else:
   reserve_ancestors[caller] += 1
 print('nearest explicit Reserve source',reserve_ancestors.most_common(20),'unknown caller',reserve_without_caller)
 rows.append(dict(label=label,case=record['workload'],activeCpuTids=record['activeCpuTids'],allThreadSamples=allThreads,threadCpuSeconds=record['threadCpuSeconds'],sampleCount=len(samples),guestRuntimeAncestry=len(guest),fixtureOutsideRuntime=len(fixture),guestRuntimeFocus=focused,nearestGuestRuntime=guest_nearest.most_common(),unmappedLeafSamples=sum(v for k,v in leaves.items()if'[unknown]'in k),ambiguousLeafSamples=sum(v for k,v in leaves.items()if k.startswith('[ambiguous]')),inclusiveOverlappingGroups=inclusive,nearestLythonFrames=nearest.most_common(),allLeaves=leaves.most_common(),malformedMapLines=malformed,invocations=record['response']['completedInvocations'],guestClockSeconds=record['response']['elapsedTicks']/record['response']['clockFrequency']))
 rows[-1].update(nearestRuntimeMethods=nearest_helpers.most_common(), nearestReserveCallers=reserve_ancestors.most_common(),
                 nearestReserveUnknownCaller=reserve_without_caller)
 if label.startswith('regex-'):
  provider = ('Lokad.Utf8Regex.', 'Lokad.Lython.Utf8Regex.', 'PythonRe')
  projection = ('ProjectScalarBounds', 'CreateMatchObject', 'PreparedSubject::Project')
  categories = collections.Counter()
  for stack in samples:
   adapted = any(any(part in frame for part in provider) for frame in stack)
   projected = any(any(part in frame for part in projection) for frame in stack)
   categories['provider'] += int(adapted)
   categories['core projection'] += int(projected)
   categories['overlap'] += int(adapted and projected)
  rows[-1]['allThreadRegexAttribution'] = dict(categories)

(r/'attribution.json').write_text(json.dumps(dict(kind='RAM-backed whole-batch profile. Guest subset requires a resolved runtime ancestor. Remaining incomplete frames may be guest work. Groups overlap and neither counts nor ratios establish removable CPU.',rows=rows),indent=2)+'\n',encoding='utf-8',newline='\n')
for x in rows:
 print(x['sampleCount'],'samples',x['unmappedLeafSamples'],'unknown',x['guestRuntimeAncestry'],'runtime',x['fixtureOutsideRuntime'],'host outside runtime')
 print(x['guestRuntimeFocus'])
 print('nearest runtime',x['nearestGuestRuntime'][:20])
