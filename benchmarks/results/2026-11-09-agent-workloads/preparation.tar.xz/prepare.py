from pathlib import Path
import hashlib,json,shutil,subprocess,tarfile
r=Path(__file__).parent;old=r.parent/'function-cpython-r122';prior=r.parent/'literal-construction-r129';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
source='459813a3';assert subprocess.check_output(['git','rev-parse','--short=8','HEAD'],text=True).strip()==source
assert not subprocess.check_output(['git','diff','--name-only','--','src','tests']).strip()
root='agent-workloads-b490-20261109';unit='lython-b490-agent-workloads-20261109'
names=['collect.py','archive-owned.py','run.sh','launch.py','retrieve.py','summarize.py']
for name in names:
 s=(old/name).read_text(encoding='utf8').replace('function-cpython-b481-20261108',root).replace('lython-b481-function-cpython-20261108',unit).replace('function-cpython-b481-launch.py','agent-workloads-b490-launch.py').replace('lython-b481-fixtures','lython-b490-fixtures')
 s=s.replace('len(jobs)==15','len(jobs)==9').replace("len(r['jobs'])==15","len(r['jobs'])==9").replace("len(raw['jobs'])==15","len(raw['jobs'])==9").replace('len(external)==15','len(external)==9').replace('jobs=15','jobs=9').replace('all15JobsValidated','all9JobsValidated').replace("status['receipt']['jobs']==15","status['receipt']['jobs']==9")
 s=s.replace('RuntimeMaxSec=360','RuntimeMaxSec=270').replace('ownerSeconds=360','ownerSeconds=270').replace('seconds=420','seconds=330').replace('time.monotonic()-started < 330','time.monotonic()-started < 240')
 s=s.replace("reference=base/'function-lookups-b479-20261108/candidate'","reference=base/'literal-construction-b489-20261109/candidate'")
 if name=='collect.py':
  at=s.index('jobs=');end=s.index('\nassert len(jobs)',at)
  jobs=[[case,lane]for case in ['scripts.config-edit.small','scripts.file-search.large','scripts.file-manifest-helpers.large']for lane in ['compile','warm','compile-run']]
  s=s[:at]+'jobs='+repr(jobs)+s[end:]
  at=s.index("purpose='R122");end=s.index("',\n",at)
  s=s[:at]+"purpose='R130 current459/core1be2, targeted stale config/search/manifest agent scripts; separate compile/warm/compile-to-result against CPython3.13.16. Full source qualification independent; original main five-case6f76 measurements remain named history"+s[end:]
 (r/name).write_text(s,encoding='utf8',newline='\n')
catalog=json.loads((r.parent/'checkpoint-cpython-r67/representative.json').read_text(encoding='utf8'))
mapping={'scripts.config-edit.small':'config-edit.py','scripts.file-search.large':'file-search.py','scripts.file-manifest-helpers.large':'file-manifest-helpers.py'}
catalog['cases']=[c for c in catalog['cases']if c['id']in mapping];assert len(catalog['cases'])==3
for c in catalog['cases']:
 assert c['source']==(Path('benchmarks/scripts')/mapping[c['id']]).read_text(encoding='utf8')
 assert hashlib.sha256(c['source'].encode()).hexdigest()==c['sourceSha256']
(r/'representative.json').write_text(json.dumps(catalog,indent=2)+'\n',encoding='utf8')
b=json.loads((prior/'b489/identity.json').read_text(encoding='utf8'))
i=dict(sourceRevision=source,coreSHA256={role:b['coreSHA256']['candidate']for role in ['candidate','candidate-control']},auxiliaryFiles=b['auxiliaryFiles'],catalogSHA256=sha(r/'representative.json'),productionSources={p:sha(Path(p))for p in subprocess.check_output(['git','ls-files','src'],text=True).splitlines()})
(r/'identity.json').write_text(json.dumps(i,indent=2)+'\n',encoding='utf8')
proof=dict(vmArchive='literal-construction-b489-20261109/observations.tgz',archiveSHA256=json.loads((prior/'b489/terminal.json').read_text(encoding='utf8'))['receipt']['archiveSHA256'],member='current-core.dll',coreSHA256=i['coreSHA256']['candidate'])
(r/'core-source.json').write_text(json.dumps(proof,indent=2)+'\n',encoding='utf8')
for name,data in {'focused.json':dict(eachTarget=dict(internal=42,public=529),actualTargets=['net11.0','net10.0'],fullDelivery='42545629905 pending, no retrospective qualification from847'), 'setup-contract.json':dict(jobs=9,roles=3,ownerSeconds=270,stopSeconds=30,marginSeconds=30,osFreeFloorMiB=240,evidenceHeadroomMiB=12),'sizing.json':dict(jobs=9,warmupPerRoleSeconds=5,rounds=7,targetBatchSeconds=.15,expectedSeconds=200,ownerSeconds=270)}.items():(r/name).write_text(json.dumps(data,indent=2)+'\n',encoding='utf8')
shutil.copyfile('PLAN.md',r/'pre-measurement-plan.md');shutil.copyfile('docs/BENCHMARKS.md',r/'prior-BENCHMARKS.md')
(r/'source.patch').write_bytes(subprocess.check_output(['git','diff','8472935f',source,'--','src']))
contract='R130 nine targeted existing-workload jobs, current459/core1be2 versusCPython3.13.16, independent duplicate Lython controls, normalGC/tiering; five-second warmup/role/seven150msrounds. Compile separate; warm/compile-to-result include mediatedRAMfileIO/fullgoldens/prior-resultcleanup, reset/staging/startup/protocol/finalcacheteardown excluded. Existing main five-case comparison remains named6f76. One270sfiniteowner+30stop+30observation. No new framework, backend qualification or publication; core delivery independent. Archive/join/ownedRAMcleanup/quiet/source/budget gates before table update.\n'
for name in ['contract.md','selection.md']:(r/name).write_text(contract,encoding='utf8')
with tarfile.open(r/'payload.tgz','w:gz')as a:
 for name in ['collect.py','archive-owned.py','run.sh','representative.json','identity.json','core-source.json','focused.json','setup-contract.json','sizing.json','pre-measurement-plan.md','prior-BENCHMARKS.md','source.patch','contract.md','selection.md']:a.add(r/name,arcname=name)
for name in ['collect.py','archive-owned.py','launch.py','retrieve.py','summarize.py']:compile((r/name).read_text(encoding='utf8'),name,'exec')
print('Prepared R130/B490 nine targeted jobs, core',i['coreSHA256']['candidate'])
