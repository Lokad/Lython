from pathlib import Path
import hashlib,json,shutil,tarfile
r=Path(__file__).parent;dest=Path('benchmarks/results/2026-11-09-agent-workloads');dest.mkdir(exist_ok=True)
for name in ['identity.json','summary.json','archive-receipt.json','observations.tgz','prior-BENCHMARKS.md','selection.md']:shutil.copyfile(r/name,dest/name)
assert hashlib.sha256((dest/'observations.tgz').read_bytes()).hexdigest()==json.loads((dest/'archive-receipt.json').read_text(encoding='utf8'))['archiveSHA256']
with tarfile.open(dest/'preparation.tar.xz','w:xz')as a:
 for p in r.iterdir():
  if p.is_file()and p.suffix in ['.py','.json','.md','.log','.sh','.patch']:a.add(p,arcname=p.name)
data=json.loads((r/'summary.json').read_text(encoding='utf8'));rows={(d['case'],d['lane']):d for d in data['timing']}
names={'scripts.config-edit.small':('Config edit','181 B / one JSON file'),'scripts.file-search.large':('Protected file search','1,025 lines /42,010 B'),'scripts.file-manifest-helpers.large':('Copy/checksum/manifest','two files /4,107 B')}
def line(case,lane,unit):
 d=rows[case,lane];factor=1000 if unit=='µs'else 1
 times=d['timeRangeMilliseconds'];py=d['medianMilliseconds']['CPython'];ratio=d['ratioRange'];status=f"{d['status']}; {d['controlPercent']:.2f}% /{max(d['iqrPercent'].values()):.2f}%"
 a=f'{times[0]*factor:.1f}–{times[1]*factor:.1f} {unit}'if unit=='µs'else f'{times[0]:.3f}–{times[1]:.3f} ms'
 b=f'{py*factor:.1f} {unit}'if unit=='µs'else f'{py:.3f} ms'
 prefix=f'| {names[case][0]} | '+(names[case][1]+' | 'if lane=='compile-run'else'')
 return prefix+f'{a} | {b} | {ratio[0]:.2f}–{ratio[1]:.2f}× | `4598` | {status} |'
p=Path('docs/BENCHMARKS.md');s=(r/'prior-BENCHMARKS.md').read_text(encoding='utf8')
lines=s.splitlines();table=0;out=[];active=False
for text in lines:
 if text.startswith('| Workload |'):table+=1;active=True;text=text.replace(' | Status;',' | Source | Status;')
 elif active and table in [1,2,3] and text.startswith('| --- |'):text=text.replace('| --- |','| --- |',1)+' --- |' # add source column
 elif active and table in [1,2,3] and text.startswith('| ') and not text.startswith('| ---'):
  cells=text.split('|');cells.insert(-2,' `6f76` ');text='|'.join(cells)
 if not text:active=False
 out.append(text)
 if active and table in [1,2,3] and text.startswith('| JSON-to-Markdown report |'):
  lane={1:'compile-run',2:'warm',3:'compile'}[table]
  for case in names:out.append(line(case,lane,'µs'if table==3 else'ms'))
s='\n'.join(out)+'\n'
old='**2026-11-08, source `6f76f99d`, CPython 3.13.16, .NET 11 RC3.**'
assert old in s;s=s.replace(old,'**Sources: `6f76` = `6f76f99d`, 2026-11-08; `4598` = `459813a3`, 2026-11-09.**\nBoth use CPython 3.13.16 and .NET 11 RC3 on the same reference VM.')
s=s.replace('These measurements describe the named runtime source, rather than subsequent HEAD\nchanges.', 'Each row describes its named runtime source, rather than subsequent HEAD changes.')
needle='outside this named-source checkpoint.';assert needle in s
s=s.replace(needle,needle+' Source `459813a3`/core `1be2a325` has\nfocused both-target semantic/cancellation/ownership checks and controlled performance\nevidence; its full platform/stress/package qualification is independently pending.')
needle='checkpoints do not isolate individual optimization gains.';assert needle in s
s=s.replace(needle,needle+' The [R130 targeted refresh](../benchmarks/results/2026-11-09-agent-workloads/README.md)\nadds the three previously stale config/file workloads: nine jobs /193.226s, all\nsource/quiet/golden/ownership/cleanup/archive gates pass. Config compile-to-result\nremains variable (max IQR3.95% despite close Lython controls).')
start=s.index('Configuration edit, protected file search and copy/checksum/manifest were last')
end=s.index('\n## Improvements within Lython',start)
s=s[:start]+'''The eight rows use two explicit source checkpoints. Config/search/manifest were
previously measured at7265538c; the targeted459813a3 refresh replaces their stale
figures, with prior evidence retained. The manifest fixture has two small files;
these cases do not establish large-tree or large-file throughput. File-search warm
execution remains1.69–1.71× despite compilation0.96–0.97×; the whole-script boundary
includes host I/O and cleanup, so the ratio alone does not identify interpreter cost.
Guarded text and eager/streamed JSON normalization remain historical: warm
1.76–1.78×,1.23–1.25× and0.61–0.62×, with compilation/startup unmeasured for these
variants. [Prior guide and evidence](../benchmarks/results/2026-11-08-json-conditional-checkpoint/README.md)
retain exact sources, adverse controls and boundaries. Inconclusive rows remain
visible; separate checkpoints cannot attribute individual changes or settle all
earlier regression debts.
'''+s[end:]
needle='| Execution-owned function lookup facts / report and CSV helpers |';at=s.index(needle)
s=s[:at]+'| Literal construction / compilation | Allocation −2.94–9.89%; config compile elapsed −3.66–4.79%, complete config −1.08–3.35%, supporting CPU | Warm text +0.36–1.01% possible debt; original adverse desktop compile results preserved. Full candidate qualification pending. [R129](../benchmarks/results/2026-11-09-literal-construction/README.md) |\n'+s[at:]
p.write_text(s,encoding='utf8')
p=Path('benchmarks/EXPERIMENTS.md');s=p.read_text(encoding='utf8');s+='''

## Targeted agent-workload CPython refresh (2026-11-09 Paris)

[R130/B490](results/2026-11-09-agent-workloads/README.md), committed459/core1be2,
CPython3.13.16/.NET11RC3, same quietF4as_v7. Ninejobs193.226s/allsource/quiet/golden/
ownership/Closed/join/RAM/archive/localgates pass. Existing scripts/fixtures/goldens/
worker/protocol, three roles,5swarmup/7rotated150msrounds. No new framework or main
five-case replay. Compile-to-result config1.09–1.10xVariable (IQR3.95%), search
1.40–1.41x, two-small-file manifest1.47–1.48x. Separate warm ratios1.26–1.27x,
1.69–1.71x,1.56–1.59x; compile1.08–1.09x,.96–.97x,1.25–1.27x. Guide labels every
row6f76/4598; old historical baseline retained, no attribution/additive gain claim.
Full459 platform/stress/package qualification pending independently. Search's warm
gap despite competitive compilation justifies bounded current runtime/host-I/O
attribution next; ratio alone is not an interpreter tax. Publication postponed.
''';p.write_text(s,encoding='utf8')
print('R130 evidence archived; guide labels mixed named sources and visible uncertainty')
