set -e
cd /mnt/d/code/Lython/.git/agent-worktrees/direct-default-owner-r630
export PATH="$HOME/.dotnet:$PATH"
out=/mnt/d/code/Lython/artifacts/r630-wsl
filter='(FullyQualifiedName~FunctionDefault|FullyQualifiedName~PreparedFunction|FullyQualifiedName~FunctionDefinition|FullyQualifiedName~AnnotatedHelper|FullyQualifiedName~Closure|FullyQualifiedName~Lambda|FullyQualifiedName~Tuple|FullyQualifiedName~NativeCallbackArguments|FullyQualifiedName~GovernedMemoryContractTests|FullyQualifiedName~CompilerCancellation)&Category!=Stress'
fixtures="$out/bin/Lokad.Lython.PublicApi.Tests/release_net10.0/Fixtures"
mkdir -p "$fixtures/Language/Values"
cp -a tests/Fixtures/Language/Values/FloatAndTuple "$fixtures/Language/Values/"
dotnet test tests/Lokad.Lython.PublicApi.Tests -c Release -f net10.0 --artifacts-path "$out" --filter "$filter"
dotnet test tests/Lokad.Lython.Tests -c Release -f net10.0 --artifacts-path "$out" --filter "$filter"
