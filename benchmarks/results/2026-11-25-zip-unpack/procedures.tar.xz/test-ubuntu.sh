set -eu
lab="$PWD/.git/agent-notes/review-20261031/zip-unpack-20261125"
export DOTNET_ROOT="$HOME/.dotnet"
export PATH="$DOTNET_ROOT:$PATH"
filter='(FullyQualifiedName~BuiltinIteratorSequenceFunction|FullyQualifiedName~DelayedHostComposition|FullyQualifiedName~GovernedCursorAdmission|FullyQualifiedName~BuiltinIterationCancellation|FullyQualifiedName~IteratorValueAccounting|FullyQualifiedName~CustomIterationModuleRouting|FullyQualifiedName~Generator|FullyQualifiedName~Csv|FullyQualifiedName~ExecutableArchitecture)&Category!=Stress'
for target in net11.0 net10.0; do
 for suite in Lokad.Lython.Tests Lokad.Lython.PublicApi.Tests; do
    log="$lab/ubuntu-$target-$suite.log"
    if "$DOTNET_ROOT/dotnet" test "tests/$suite/$suite.csproj" -c Release -f "$target" --artifacts-path "$lab/ubuntu" --filter "$filter" > "$log" 2>&1; then
        tail -3 "$log"
    else
        tail -48 "$log"
        exit 1
    fi
 done
done
