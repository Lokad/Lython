set -eu
export DOTNET_ROOT="$HOME/.dotnet"
export PATH="$DOTNET_ROOT:$PATH"
lab="$PWD/.git/agent-notes/review-20261031/zip-unpack-20261125"
for target in net11.0 net10.0; do
  log="$lab/ubuntu-cancellation-$target.log"
  if dotnet test tests/Lokad.Lython.PublicApi.Tests -c Release -f "$target" --no-restore --artifacts-path "$lab/ubuntu" --filter FullyQualifiedName~CancelledZipUnpackUnwindsAWaitingPartialRow > "$log" 2>&1; then
    tail -2 "$log"
  else
    tail -23 "$log"
    exit 1
  fi
done
