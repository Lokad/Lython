from pathlib import Path
import base64,hashlib,json,os,shutil,subprocess,tarfile,tempfile

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
source=lab.with_name('shared-locals-cpython-20261125')
prior=lab.with_name('shared-function-local-slots-20261125')
quiet=lab/'comparison/quiet'
quiet.mkdir(parents=True,exist_ok=True)
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
digest=lambda b:hashlib.sha256(b).hexdigest()
sha=lambda p:digest(p.read_bytes())
write=lambda p,s:p.write_text(s,encoding='utf-8',newline='\n')
save=lambda p,d:write(p,json.dumps(d,ensure_ascii=False,indent=2)+'\n')
before=read(source/'external/identity.json')
reference=before['imageFiles']['candidate']
assert len(reference)==32 and {p.name:sha(p) for p in (source/'candidate').iterdir()}==reference
patch=lab/'candidate.patch'
assert subprocess.check_output(['git','diff','--binary','--','src'],cwd=repo)==patch.read_bytes()
core=lab/'candidate-build/bin/Lokad.Lython/release_net11.0/Lokad.Lython.dll'
images={'reference':reference,'candidate':reference|{core.name:sha(core)}}
assert reference[core.name]!=images['candidate'][core.name]
for role,files in images.items():
    image=lab/role
    image.mkdir(exist_ok=True)
    for name in files:shutil.copyfile(core if role=='candidate' and name==core.name else source/'candidate'/name,image/name)
    assert {p.name:sha(p) for p in image.iterdir()}==files

catalog=read(source/'external/representative.json')
source_id='diagnostic.shipment-routing-callbacks'
invoice='scripts.csv-invoice.method-policy.quoted-control'
retained_id='diagnostic.shipment-retained-zip'
cases={r['id']:r for r in catalog['cases']}
retained='''import csv

with open('shipments.csv', encoding='utf-8', newline='') as source:
    rows = list(csv.DictReader(source))
services = ['review' if row['hold'] == 'yes' else 'normal' for row in rows]
pairs = list(zip(rows, services, strict=True))
print(len(pairs), sum(service == 'review' for row, service in pairs))
for index in (0, len(pairs) // 2, len(pairs) - 1):
    row, service = pairs[index]
    print(row['id'], service, row is rows[index])
'''
python=Path('C:/Python313/python.exe')
parent=cases[source_id]
with tempfile.TemporaryDirectory(prefix='lython-retained-zip-golden-') as folder:
    for name,encoded in json.loads(parent['fixtureJson'])['inputFiles'].items():
        Path(folder,name).write_bytes(base64.b64decode(encoded))
    output=subprocess.run([python,'-I','-S','-X','utf8','-'],input=retained,cwd=folder,text=True,encoding='utf-8',capture_output=True,check=True,timeout=30)
    assert not output.stderr
cases[retained_id]=parent|dict(id=retained_id,source=retained,sourceUtf8Bytes=len(retained.encode('utf-8')),
    sourceSha256=digest(retained.encode('utf-8')),expectedOutput=output.stdout,
    expectedOutputUtf8Bytes=len(output.stdout.encode('utf-8')),expectedOutputSha256=digest(output.stdout.encode('utf-8')))
catalog['cases']=[cases[k] for k in (source_id,retained_id,invoice)]
save(quiet/'representative.json',catalog)
save(quiet/'jobs.json',dict(warm=[[source_id,'warm'],[retained_id,'warm'],[source_id,'warm-async'],[invoice,'warm'],[source_id,'compile-run']]))
ident=dict(sourceRevision=before['sourceRevision'],comparisonRevision=before['sourceRevision'],sourcePatchSHA256=sha(patch),
    purpose='Publish fixed zip unpacks into admitted frame slots and keep the same ordered producer for escaping tuples',
    imageFiles=images,coreSHA256={r+s:files[core.name] for r,files in images.items() for s in ('','-control')},
    expectedCPythonSHA256=before['expectedCPythonSHA256'],cpythonWorkerSHA256=before['cpythonWorkerSHA256'],
    catalogs={name:dict(sha256=sha(quiet/name)) for name in ('representative.json','jobs.json')})
save(quiet/'identity.json',ident)
protocol=repo/'benchmarks/cpython-worker.py'
assert sha(protocol)==ident['cpythonWorkerSHA256']
sdk=Path.home()/'.dotnet11'
dotnet=sdk/'dotnet.exe'
env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk))
for role,files in images.items():
    verification=lab/'comparison'/f'{role}-verify.json'
    subprocess.run([dotnet,lab/role/'Lokad.Lython.Benchmarks.dll','--compare','verify','--catalog',quiet/'representative.json',
        '--dotnet',dotnet,'--python',python,'--python-worker',protocol,'--out',verification],env=env,cwd=repo,check=True,timeout=65)
    result=read(verification)
    assert result['state']=='Completed' and result['caseCount']==3 and result['launched']['library']['sha256']==files[core.name]
    assert result['catalogSha256']==ident['catalogs']['representative.json']['sha256']
shutil.copyfile(prior/'comparison/quiet/run.sh',quiet/'run.sh')
assert b'\r' not in (quiet/'run.sh').read_bytes()
collector=(prior/'comparison/quiet/collect.py').read_text(encoding='utf-8').replace('b1662-fixtures','b1665-fixtures')
collector=collector.replace('len(jobs) == 6','len(jobs) == 5').replace('targetBatchSeconds=.56','targetBatchSeconds=.63')
compile(collector,'collect.py','exec')
write(quiet/'collect.py',collector)
payload=quiet/'payload.tar.gz'
with tarfile.open(payload,'w:gz',compresslevel=3) as bundle:
    for name in ('identity.json','jobs.json','representative.json','run.sh','collect.py'):
        bundle.add(quiet/name,arcname=name)
    bundle.add(core,arcname='candidate-core.dll')
save(quiet/'upload.json',dict(root='zip-unpack-b1665-20261125',reference='shared-locals-cpython-b1663-20261125',
    payloadSHA256=sha(payload),payloadBytes=payload.stat().st_size))
save(lab/'verified-raw-replicas.json',[])
source_receipt=read(source/'external/terminal-status.json')['receipt']
old_receipt=read(lab.with_name('direct-callback-return-20261125')/'comparison/quiet/terminal-status.json')['receipt']
assert source_receipt['complete'] and sha(source/'external/observations.tar.xz')==source_receipt['archiveSHA256']
launcher=(prior/'quiet.py').read_text(encoding='utf-8').replace(old_receipt['archiveSHA256'],source_receipt['archiveSHA256'])
launcher=launcher.replace('lython-b1662-shared-function-local-slots-20261125','lython-b1665-zip-unpack-20261125').replace('b1662','b1665')
launcher=launcher.replace('seconds=251','seconds=241').replace('RuntimeMaxSec=320','RuntimeMaxSec=305')
assert source_receipt['archiveSHA256'] in launcher
compile(launcher,'quiet.py','exec')
write(lab/'quiet.py',launcher)
report=(prior/'archive.py').read_text(encoding='utf-8').replace('2026-11-25-shared-function-local-slots','2026-11-25-zip-unpack')
report=report.replace('receipt["warmJobs"]==6','receipt["warmJobs"]==5').replace('timedBatches=168,lanes=6','timedBatches=140,lanes=5')
compile(report,'archive.py','exec')
write(lab/'archive.py',report)
print('Verified both full images on the shipment report and two controls.')
