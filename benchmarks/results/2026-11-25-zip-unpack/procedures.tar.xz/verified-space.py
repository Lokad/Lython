from pathlib import Path

lab=Path(__file__).resolve().parent
donor=lab.with_name('shared-function-local-slots-20261125')
script=(donor/'verify-and-free-space.py').read_text(encoding='utf-8')
script=script.replace("source=operand/'candidate'/core", "source=lab.with_name('shared-function-local-slots-20261125')/'candidate'/core")
script=script.replace('verified-b1659-candidate.dll','verified-b1662-candidate.dll')
start=script.index('stages=(')
end=script.index('copies=[]',start)
script=script[:start]+'''shared=lab.with_name('shared-function-local-slots-20261125')
stages=(
    ('shared-function-local-slots-b1662-20261125','b1662-shared-function-local-slots-20261125','candidate',shared/'comparison/quiet'),
    ('shared-function-local-slots-confirm-b1662-20261125','b1662-shared-function-local-slots-confirm-20261125','candidate',shared/'confirmation'),
)
replicas=(stages[-1],)
'''+script[end:]
path=lab/'verify-and-free-space.py'
compile(script,str(path),'exec')
path.write_text(script,encoding='utf-8',newline='\n')
