from pathlib import Path
import ast,hashlib,json,os,re,shutil,subprocess,tarfile
home=Path(__file__).parent;old=home/'delivery-comparison-b400';r=home/'file-workflows-r47';r.mkdir()
remote='/home/lokad/lython-bench-checks/file-workflows-b401-20261107';old_remote='/home/lokad/lython-bench-checks/delivery-comparison-b400-20261107'
identity=json.loads((old/'identity.json').read_text(encoding='utf-8'))
for name,digest in identity['productionSources'].items():assert hashlib.sha256(Path(name).read_bytes()).hexdigest()==digest
delivery=json.loads(Path('benchmarks/results/2026-11-07-integer-parsing/delivery-ci.json').read_text(encoding='utf-8'));assert delivery['conclusion']=='success'
identity.update(purpose='R47 missing current file-workflow baseline: protected early-exit search and two-file copy/checksum/JSON manifest. Not a source-pair or large-file throughput claim.',delivery=delivery)
(r/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8',newline='\n')
env=os.environ.copy();env['DOTNET_ROOT']='C:/Users/JoannesVermorel/.dotnet11';env['PATH']=env['DOTNET_ROOT']+os.pathsep+env['PATH']
worker=home/'json-integer-r46/images/before/Lokad.Lython.Benchmarks.dll'
assert hashlib.sha256((worker.parent/'Lokad.Lython.dll').read_bytes()).hexdigest()==identity['coreSHA256']['candidate']
done=subprocess.run([env['DOTNET_ROOT']+'/dotnet.exe',str(worker),'--compare','list','--profile','representative','--out',str(r/'all-representative.json')],env=env,capture_output=True,text=True,encoding='utf-8');assert done.returncode==0,done.stderr
catalog=json.loads((r/'all-representative.json').read_text(encoding='utf-8'));ids=['scripts.file-search.large','scripts.file-manifest-helpers.large']
catalog['cases']=[next(c for c in catalog['cases']if c['id']==case)for case in ids]
for case,name in zip(catalog['cases'],['file-search','file-manifest-helpers']):
 assert case['source']==Path('benchmarks/scripts/'+name+'.py').read_text(encoding='utf-8').replace('\r\n','\n')
def write(n,s):(r/n).write_text(s,encoding='utf-8',newline='\n')
write('representative.json',json.dumps(catalog,ensure_ascii=False,indent=2)+'\n')
jobs=[(case,lane)for case in ids for lane in ['compile','warm','compile-run']]
for name in ['collect.py','archive-owned.py','run.sh','retrieve.py','summarize.py']:
 s=(old/name).read_text(encoding='utf-8').replace(old_remote,remote).replace('lython-b400-delivery-comparison-20261107','lython-b401-file-workflows-20261107')
 s=s.replace('len(jobs)==21','len(jobs)==6').replace("len(r['jobs'])==21","len(r['jobs'])==6").replace('jobs=21','jobs=6').replace("['jobs']==21","['jobs']==6").replace('started < 480','started < 120')
 if name=='collect.py':s=re.sub(r'^jobs=\[.*\]$','jobs='+repr(jobs),s,flags=re.M)
 if name.endswith('.py'):ast.parse(s)
 write(name,s)
contract='''R47 current file-workflow gap only: maintained file-search.large (42010B/2049lines, breaks after1025) and file-manifest-helpers.large (only2files/4107B, copy/checksum/JSON output, not large-I/O throughput). Exact qualified8c9fd0d7/frozen d3a6c778 production inventory; current documentatione8389919. Existing worker7cf37ca5/host/normal optional0.4/GC/tiering. CPython3.13.16 plus two identical Lython roles;5s warmup/role/job,7rotated150ms rounds.6jobs, compile/warm/compile-run separate. Execution includes mediated RAM I/O, full stdout/file goldens and prior-result cleanup; startup/staging/reset/transport/final cached teardown excluded. No median subtraction to isolate I/O, isolated-CPU, RSS or tail claim. Every identity/golden/funding/quiet/Closed/exit/join/fixture gate and persistent under-lease archive required.180s owner+30s stop+30s margin, observe after240s; no early service query/restart on timeout. Existing native UTF8 path operations, bytes-sum helpers, list/tuple iteration, protected control flow and fused cased split already exist. Stop after this missing fact: if a material stable whole-job gap and concrete removable phase remain, select one bounded phase capture/source assessment; otherwise move architectural boundary. No automatic parser/pool/arena/tag/dispatcher redesign. Retain all adverse/unknown controls. Source simplification, allocation and CPU improvement are separate; no final adapter/package/publication campaign.'''
write('contract.md',contract+'\n');write('setup-contract.json',json.dumps(dict(jobs=6,ownerSeconds=180,stopSeconds=30,marginSeconds=30,observeAfterSeconds=240),indent=2)+'\n')
p=Path('PLAN.md');s=p.read_text(encoding='utf-8');s=s.replace('Next gate: inspect the maintained file-search/file-manifest helper scripts against','R47/B401: six current CPython baseline jobs for maintained file-search/file-manifest\nhelpers, separate compile/warm/compile-run.180s owner+30s stop+30s margin, observe\nafter240s. Exact qualified8c9fd0d7/frozen d3a6c778; no unchanged seven-case retiming.\nThe manifest is only two files/4107B; search42010B exits after1025lines. Do not\ninfer large-file throughput. Assess these scripts against')
start=s.index('VM: lokad@');s=s[:start]+'''VM: lokad@20.166.121.73, key ~/.ssh/id_lython-bench.pem. B385–B400 are terminal,
archived and locally verified; never service-query them again. B397 failed setup
remains preserved, corrected B398 and both B399/B400 pass all gates. CI42371564043
and prior terminal runs are cached green; no active CI. R47/B401 prepared, not
yet started. Before observing, use its recorded180s owner+30s stop+30s margin.
Persist/verify RAM traces under lease before removing them; never restart on an
observation timeout. Earlier retired duplicate images have exact committed
backups/receipts; restore incomplete old images before reuse. Latest producer
source6032b928/dev51 still has the named missing semantics above; no new package
qualification or core-development blocker inferred.
''';p.write_text(s,encoding='utf-8',newline='\n');shutil.copy2(p,r/'pre-measurement-plan.md')
(r/'source.patch').write_bytes(subprocess.check_output(['git','diff','fba865ef','8c9fd0d7','--binary','--','src','tests']))
with tarfile.open(r/'payload.tgz','w:gz')as a:
 for name in ['identity.json','representative.json','contract.md','setup-contract.json','pre-measurement-plan.md','collect.py','archive-owned.py','run.sh','source.patch']:a.add(r/name,arcname=name)
payload=(r/'payload.tgz').read_bytes();s=(old/'launch.py').read_text(encoding='utf-8').replace(old_remote,remote).replace('lython-b400-delivery-comparison-20261107','lython-b401-file-workflows-20261107')
s=re.sub(r"payload=sys.stdin.buffer.read\(\d+\+1\);assert len\(payload\)==\d+ and hashlib.sha256\(payload\).hexdigest\(\)=='[0-9a-f]+'",'payload=sys.stdin.buffer.read('+str(len(payload))+"+1);assert len(payload)=="+str(len(payload))+" and hashlib.sha256(payload).hexdigest()=='"+hashlib.sha256(payload).hexdigest()+"'",s)
s=re.sub(r' assert cases==\{.*\}',' assert cases=='+repr(set(ids)),s).replace('allTwentyOneJobsValidated','allSixJobsValidated').replace('RuntimeMaxSec=540','RuntimeMaxSec=180')
ast.parse(s);write('launch.py',s)
s=(old/'start.py').read_text(encoding='utf-8').replace('delivery-comparison-b400-launch','file-workflows-b401-launch').replace('seconds=600','seconds=240').replace('ownerSeconds=540','ownerSeconds=180')
ast.parse(s);write('start.py',s)
print('Prepared six existing protocol jobs for two missing file workflows; no VM work started.')
