from pathlib import Path
import hashlib,json,shutil,tarfile
r=Path(__file__).parent;summary=json.loads((r/'summary.json').read_text(encoding='utf-8'));receipt=json.loads((r/'archive-receipt.json').read_text(encoding='utf-8'))
assert summary['complete']and len(summary['timing'])==6 and receipt['complete']and receipt['jobs']==6
assert hashlib.sha256((r/'observations.tgz').read_bytes()).hexdigest()==receipt['archiveSHA256']
out=Path('benchmarks/results/2026-11-07-file-workflows');out.mkdir()
for name in ['identity.json','summary.json','archive-receipt.json','terminal-status.json']:(out/name).write_text((r/name).read_text(encoding='utf-8'),encoding='utf-8',newline='\n')
shutil.copy2(r/'observations.tgz',out/'observations.tgz')
with tarfile.open(out/'development.tar.xz','w:xz')as a:
 for p in r.iterdir():
  if p.is_file()and p.suffix in ['.py','.json','.md','.log','.sh']:a.add(p,arcname=p.name)
 a.add(r.parent/'prepare-b401.py',arcname='prepare-b401.py')
def rows(lane,inputs=False):
 result=''
 for row in summary['timing']:
  if row['lane']!=lane:continue
  name='Protected file search'if'file-search'in row['case']else'Two-file copy/checksum/manifest'
  label='2,049 lines; exits after 1,025 / 42,010 B'if'file-search'in row['case']else'2 files / 4,107 B'
  low,high=row['timeRangeMilliseconds'];ref=row['medianMilliseconds']['CPython'];unit='ms'if low>=1 else'µs';scale=1 if unit=='ms'else 1000
  spread=max(row['iqrPercent'][e]for e in ['candidate','control'])
  result+='| '+name+' | '+(label+' | 'if inputs else'')+f'{scale*low:.3f}–{scale*high:.3f} {unit} | {scale*ref:.3f} {unit} | {row["ratioRange"][0]:.2f}–{row["ratioRange"][1]:.2f}× | {row["status"]}; {row["controlPercent"]:.2f}% / {spread:.2f}% |\n'
 return result
header='| Workload | Lython | CPython | Lython / CPython | Status; control / Lython IQR |\n| --- | ---: | ---: | ---: | --- |\n'
readme='''# Maintained file-workflow comparison — R47/B401

2026-11-07, exact qualified8c9fd0d7 production/frozen d3a6c778; precommit
SourceLink3480aa55, current documentatione8389919. All560source hashes match;
worker7cf37ca5, adapter27211dbe/normal0.4 unchanged. Full delivery42371564043
already qualifies both Windows/Ubuntu, actual.NET11/10, original Stress and
installed core consumers. No new prototype, producer or repeated qualification.

Two missing maintained file workflows, not a repeat of B400's seven cases.
Search includes2049lines/42010B and exits after1025, leaving the trailing half
unread; its protected break and exact output are checked. Manifest copies only
two files/4107B, computes byte checksums through an annotated helper, sorts JSON
and writes the complete manifest. This measures small-file overhead, not large
copy throughput or arbitrary directory scaling. No source/data variants.

Same quiet AzureF4as_v7/Ubuntu24.04.4/four EPYC9V45 vCPUs/16GiB/no swap,
.NET11RC3 normal GC/tiering, CPython3.13.16 GCC13.3 PGO/LTO ordinary GIL/GC,
no JIT/debug, -I -S -X utf8. One CPython and two identical Lython roles per job,
5s warmup/role/job, seven rotated150ms rounds. Six jobs complete ELAPSEDs.
180s owner+30s stop+30s margin, observed after240s. All source/image/Ready/
aux/golden/funding/quiet/Closed/exit/join/fixture gates pass, raw archive verified
under lease and independently after retrieval. No active worker/fixtures remain.

Warm and compile-to-result include mediated RAM I/O, guest work, complete stdout/
file validation and prior-result cleanup. Compile-to-result adds compile/program
disposal. Compile-only excludes execution/I/O. Startup/staging/reset/transport/
final cached teardown excluded. CPython retains modules, Lython isolates imports.
No median subtraction to isolate I/O, isolated-CPU, RSS, pending-I/O or tail claim.
Ratios above1 mean slower; ranges span two role medians, not confidence intervals.
Control=absolute role difference/candidate; IQR=larger Lython-role IQR/median.
The reused collector's generic R43/R44/R45 purpose label is historical; its exact
two-case manifest, six job entries, identity and predeclared R47 contract define
this collection. Variable/adverse observations remain visible.

'''.replace('ELAPSED',f'{summary["elapsedSeconds"]:.2f}')
for lane,title in [('compile-run','Compilation plus one execution'),('warm','Warm execution'),('compile','Compilation/program disposal only')]:readme+='## '+title+'\n\n'+header+rows(lane)+'\n'
readme+='''[Raw observations](observations.tgz), [summary](summary.json), [identities](identity.json),
[receipt](archive-receipt.json), [terminal state](terminal-status.json),
[setup/source/contracts/commands](development.tar.xz) and
[full runtime delivery](../2026-11-07-integer-parsing/delivery-ci.json).
The complete-script performance objective remains active; publication postponed.
''';(out/'README.md').write_text(readme,encoding='utf-8',newline='\n')
p=Path('docs/BENCHMARKS.md');s=p.read_text(encoding='utf-8')
for lane,heading,inputs in [('compile-run','# Performance against CPython',True),('warm','## Warm execution, compilation and startup',False),('compile','Compilation/program disposal only; execution and I/O excluded.',False)]:
 start=s.index(heading);table_start=s.index('| Workload |',start);end=s.index('\n\n',table_start)
 s=s[:end]+'\n'+rows(lane,inputs).rstrip()+s[end:]
needle='## Machine, included work and fairness'
s=s.replace(needle,'The two file workflows were collected in a separate six-job block on the same\nqualified source and machine. Search exits after1,025 of2,049 lines; the manifest\ncopies only two files/4,107B. These do not measure large-file throughput.\n[File-workflow inputs and observations](../benchmarks/results/2026-11-07-file-workflows/README.md).\n\n'+needle)
p.write_text(s,encoding='utf-8',newline='\n')
p=Path('benchmarks/EXPERIMENTS.md');s=p.read_text(encoding='utf-8');s+='\n## Maintained file-workflow comparison (2026-11-07)\n\nR47/B401 adds six compile/warm/compile-run jobs for protected search and the small\ntwo-file copy/checksum/manifest on qualified8c9fd0d7. No runtime change, new\nframework or unchanged seven-case retiming. Full gates/archive verification pass.\n[Complete evidence and limits](results/2026-11-07-file-workflows/README.md).\n';p.write_text(s,encoding='utf-8',newline='\n')
print('File workflow gap recorded with original/adverse controls; no runtime or CPU speedup claim.')
