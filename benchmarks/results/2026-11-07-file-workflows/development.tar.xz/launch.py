from pathlib import Path
import fcntl,hashlib,io,json,shutil,subprocess,sys,tarfile
base=Path('/home/lokad/lython-bench-checks');root=Path('/home/lokad/lython-bench-checks/file-workflows-b401-20261107');prior=Path('/home/lokad/lython-bench-checks/integer-parsing-b399-20261107')
with (base/'comparison-vm.lock').open('a') as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert not root.exists() and not list(Path('/dev/shm').glob('lython-comparison-files-*'))
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record'],capture_output=True).returncode==1
 payload=sys.stdin.buffer.read(67533+1);assert len(payload)==67533 and hashlib.sha256(payload).hexdigest()=='cf8953afefe905d09cd804162d97a1f880769d7d924604e5d0a01cce5e9280d7'
 with tarfile.open(fileobj=io.BytesIO(payload),mode='r:gz') as a:
  assert shutil.disk_usage(base).free>sum(((m.size+4095)//4096)*4096 for m in a.getmembers())+128*1024+8*1024*1024
  root.mkdir();a.extractall(root,filter='data')
 for name in ['candidate','cpython-worker.py']:(root/name).symlink_to(prior/name,target_is_directory=(prior/name).is_dir())
 identity=json.loads((root/'identity.json').read_text())
 assert hashlib.sha256((root/'candidate/Lokad.Lython.dll').read_bytes()).hexdigest()==identity['coreSHA256']['candidate']
 for name,digest in identity['auxiliaryFiles'].items():assert hashlib.sha256((root/'candidate'/name).read_bytes()).hexdigest()==digest
 cases={c['id'] for c in json.loads((root/'representative.json').read_text())['cases']}
 assert cases=={'scripts.file-search.large', 'scripts.file-manifest-helpers.large'}
 for name in ['collect.py','archive-owned.py']:compile((root/name).read_text(),str(root/name),'exec')
 subprocess.run(['/bin/sh','-n',str(root/'run.sh')],check=True)
 print(json.dumps(dict(freeBytes=shutil.disk_usage(base).free,allSixJobsValidated=True,coreSHA256=identity['coreSHA256']['candidate'])),flush=True)
subprocess.run(['sudo','-n','systemd-run','--unit=lython-b401-file-workflows-20261107','--property=User=lokad','--property=WorkingDirectory='+str(root),'--property=RuntimeMaxSec=180','--property=TimeoutStopSec=30','--property=KillMode=control-group','/bin/sh',str(root/'run.sh')],check=True)
