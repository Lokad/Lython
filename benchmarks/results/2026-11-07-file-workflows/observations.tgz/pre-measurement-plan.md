# Lokad.Lython 0.11.0

Updated 2026-11-07. Git-ignored; never force-add. Publication/tagging postponed.
Objective: coherent simplification and substantial complete-script performance.
Completing one experiment or qualification checkpoint does not complete this objective.

## Delivery status

- **Fully qualified production8c9fd0d7:** CI42371564043 terminal GREEN on
  Windows/Ubuntu Release actual11/10, original Stress both targets and installed
  core consumers. Includes R44's twelve immediate duplicate checks and R45's
  admitted/cancellable UTF-8 integer parser. Receipt beside integer-parsing
  evidence. Earlier R43/R41 receipts remain cached; never query terminal runs again.
- **Committed/pushed documentationad74fa41:** B400 CPython refresh, exact8c9fd0d7
  production/frozen d3a6c778.21jobs/all gates,434.37s, raw archive601c0fe8 verified
  under lease and locally. Warm CSV1.22–1.23x, text1.73–1.77x, JSON1.03x,
  report1.50x, config1.25–1.29x; explicit affected CSV1.06–1.07x, numeric-string
  JSON1.69–1.70x. Separate compile/compile-to-result and included I/O/cleanup are
  in docs/BENCHMARKS.md; variable controls stay visible. No startup/RSS/tail claim.
- **R46 prototype withdrawn:** JSON sharing the general int kernel materially
  regresses allocation. Exact source restored and Release solution rebuilt
  nonincrementally, zero warnings/errors. No prototype/runtime branch survives.
  Evidence and initial failed test assertions remain outside docs/.
- **Independent regex:** core decoupled, optional nonpackable normal adapter0.4.0.
  Earlier immutable dev48/f6b2175e focused qualification is historical, not final
  current-source safety/performance certification. Publication/tagging postponed.

## Established evidence and unresolved debt

| Work | Established result | Limits / decision |
| --- | --- | --- |
| Shared compiler facts | Corrected shared inferred-value traversal eliminates exponential analysis; fully qualified | Preserve callback correction; no warm CPU claim. |
| Native helper returns | Allocation −19.92/−19.31%; fully qualified | Earlier elapsed gains remain diagnostic. No unchanged requalification. |
| Direct UTF-8 formatting/storage | Allocation −8.67%; controlled B102 elapsed/CPU −5–8% supports retention | Original adverse 15.125 ms remains unexplained and preserved. |
| R20/R25 records | Shared keys, independent values, completed CSV storage transfer; allocation −7.31/−6.55%, native warm −7.72–8.04% | Selectively replaces the old rigidly rejected 6–8% bulk-record attempt; controls mixed. |
| R35/R38 | Dynamic report allocation ~−15.35%, quiet warm −10–13%; compile allocation −4.38–8.94% | CSV possible debt +0.13–2.36%; R38 required full regex analysis preserved after three initial failures. |
| R40/R41 | Unicode cursor scaling −31–79%; shared receiver methods remove ten markers/guards and closures, regex allocation ~−29.47%, warm −8.64–10.80% | Not broad CPU/parity claims; ASCII and original CSV adverse controls remain possible debt. Fully qualified. |
| R42 cost gate | Text: 1,089 CPU samples, 44 unknown; prefix 229 self / 1,056 inclusive; scalar add 41 self | Self includes inlined work; inclusive totals overlap. No universal scalar rewrite or saved-CPU forecast. |
| R43 ordinary operands | Fewer instructions/smaller immutable payload; compile allocation +0.20–0.87%; full delivery green | Text warm −1.37 to +1.11%, fresh −2.23 to −0.15%; CSV variable, JSON −2.37 to +6.81%/6.66% identical-current spread, report −2.19 to −0.73%/3.92% IQR. No substantial CPU claim; debt stays. |

History, original failed conditions, rejected designs and complete qualification
live in benchmarks/EXPERIMENTS.md and immutable benchmarks/results/. R43 development
evidence stays outside docs/. Do not repeat unchanged completed qualification.

## Completed R44/R45 delivery checkpoint

R45 removes decoded copies/UTF-16 general int parsing, uses native accumulation
then admitted radix chunks, and corrects Unicode decimal semantics. B399 shows
affected padded CSV warm−12.49–13.41% and numeric-string JSON−41.43–41.98%.
Initial allocation−14.70/13.35% and−62.99/62.98% sync/async; ordinary controls
mixed. Final refinement removes one check; allocation was not replayed. Tiny
thresholds change; three conservative magnitudes fund promotion/replacement, with
existing small-scalar headroom. Individual BCL magnitude operations are atomic.
Focused, actual in-flight cancellation and full delivery pass. B400 closes the
external comparison gap. History: benchmarks/results/2026-11-07-integer-parsing/
and integer-cpython/. Do not repeat unchanged qualification or timing.

## Priority 1 — continue whole-script redesign selection after the R46 gate

R46 is withdrawn and fully archived: sharing R45's radix-chunk integer kernel
with default JSON removes decoded text but raises complete-job allocation10.515/
10.511% on40-digit records and2753.905/2748.787% on4096-digit records, sync/async.
Desktop clocks also include adverse outcomes and moving unchanged controls. CLR
decimal parsing already eliminates many arithmetic intermediates.208internal/
986public per actual11/10 and every diagnostic golden/ownership gate pass; this
does not rescue the storage regression. Exact production is restored to8c9fd0d7;
nonincremental Release solution build now passes, replacing prototype outputs.
No speculative shared parser, null-source invariant, replacement guard or revised
architecture-only test remains. History: benchmarks/results/2026-11-07-json-integer-source-gate/.

Do not treat R45 as proof that all int conversions should use the same algorithm.
Keep JSON's current decoded/BCL path until materially different bulk evidence
justifies replacing it; supported public BigInteger.Parse has no byte-span overload.
No thresholded second parser or generic bridge is selected merely to hide the
conversion. Reconsideration remains possible with new evidence/capability.

R47/B401: six current CPython baseline jobs for maintained file-search/file-manifest
helpers, separate compile/warm/compile-run.180s owner+30s stop+30s margin, observe
after240s. Exact qualified8c9fd0d7/frozen d3a6c778; no unchanged seven-case retiming.
The manifest is only two files/4107B; search42010B exits after1025lines. Do not
infer large-file throughput. Assess these scripts against
the current architecture and existing evidence. These complete early-exit/copy/
manifest workflows broaden representative file-processing coverage; native UTF-8
paths, byte summation, list/tuple iteration and fused cased splitting already exist.
Use a bounded missing-phase observation only if it can identify real removable
work; preserve host-mediated I/O, original path requests, cleanup, current tokens
and admitted output/storage. Do not open another general profiling campaign or
invent a new framework. Calls, transport, collections and frontend boundaries below
remain independent; completion of this gate does not complete performance work.

## Next redesign boundaries

Select a real dominant phase from current evidence; do not accumulate narrow cases.
For each selected milestone record the hypothesis, eliminated work/storage and
displaced code, affected scripts, semantic gates, bounded comparison and controls.

| Boundary | Evidence / acceptance / stopping criterion |
| --- | --- |
| Complete calls/frames | R39 CSV helper-inclusive totals are useful work, not proof of binding dominance. Existing borrowed operands/final slots/lazy contexts/native helpers stay. Select only a real removable phase; preserve binding, defaults, closures, exceptions, genuine I/O and owners. Slower call-arena/control designs require new evidence, not automatic retry. |
| Operand transport | R43 retained smaller code and fewer instructions, with CPU improvement unproved. No further leaf-specific rewrite without materially new evidence. |
| Completed-instruction guards | R44 completes twelve provably immediate duplicates. Wider opcode hoisting lacks a complete cancellation/refusal/error-order proof and is not selected. R42 prefix self is not guard CPU. Keep meaningful checkpoints; no replacement counters/quotas or weaker containment. |
| Per-record collections | Shared keys/R25 transfer and synchronous JSON already exist. Reassess bulk construction only where an actual extra copy/capacity phase remains; preserve hook/order/reentry/alias/overlap semantics. Original control regressions remain evidence. |
| Scalars and text | R42 scalar add alone is insufficient for universal tagged values. Bulk UTF-8 and prepared helpers already exist. R28 already tested newly owned packed split storage: allocation −6.94%, text variable, report +0.91–4.97% after refinement; withdrawn. Do not rediscover it as a new design or indiscriminately share refundable input windows. Select materially different remaining work; preserve promotion, identity, Unicode, hashes and cancellation. |
| Frontend/setup | Shared lexical/class/parameter facts, R38 demand pruning, shared builtins and executable imports already exist. Remove actual repeated analysis/storage; preserve dead-scope diagnostics, fresh mutable state and regex analysis. Compile separately, and include compile-to-result for config/new scripts. |

A justified redesign may temporarily regress. Its completion milestone must state
whether remaining debt is accepted, corrected or withdrawn. A source simplification,
an allocation reduction and a CPU improvement are distinct results.

## Independent regex track

Continue Lython-owned Python/native UTF-8 semantics: byte ranges, scalar positions,
original-subject windows, captures/replacements/errors/cache ownership and current
tokens through actual work. Development producers and adapter-local bridges may
support contract/semantic work; missing released capabilities defer only affected
final adapter qualification. They do not stop core or independent performance work.

Current precise producer gaps: DetailedData lacks a separate Prepare working owner;
native names lack enumeration; cursors mix creation/current token authority. Exact
dev48 supplies no documented removal of these limits. Keep conservative preflight,
adapter-local conversion and the qualified cancellation bridge where needed.
Qualify immutable released inputs and managed safety separately. No silent dialect
fallback, work/time quotas, sibling edits, abandoned matching or publication gate
on Lython development. Existing R40/R41 work needs no new producer release.

## Experimental and delivery policy

Timeouts, unstable unchanged controls and inconclusive observations establish
uncertainty, not permanent design rejection. Permit bounded justified confirmation,
refinement or measurement correction; never repeat until favorable. Size observations
for the quiet VM, preserve original conditions/adverse results and source/binary
provenance. Percentages inform decisions rather than automatically vetoing useful
simplification. Use focused correctness/cancellation/ownership checks while iterating;
batch full actual11/10 Windows/Ubuntu, original Stress and installed consumers at
meaningful retained delivery checkpoints. Publication remains postponed.

## Constraints / resources

AGENTS.md governs: fully managed/memory-safe, managed stack/nesting, host mediation,
current cancellation, borrowed shared allowance/preflights/overlap/escaping aliases
and awaited cleanup. First refused admission terminates the command. No unsafe,
tracing, weak reclamation, forced GC, fuel/quotas/caps or hidden allowance. Bounded
host-driven batches; XML depth constraint retained. No overlapping local tests,
builds or measurements. PLAN stays ignored; docs describe only current releases.

VM: lokad@20.166.121.73, key ~/.ssh/id_lython-bench.pem. B385–B400 are terminal,
archived and locally verified; never service-query them again. B397 failed setup
remains preserved, corrected B398 and both B399/B400 pass all gates. CI42371564043
and prior terminal runs are cached green; no active CI. R47/B401 prepared, not
yet started. Before observing, use its recorded180s owner+30s stop+30s margin.
Persist/verify RAM traces under lease before removing them; never restart on an
observation timeout. Earlier retired duplicate images have exact committed
backups/receipts; restore incomplete old images before reuse. Latest producer
source6032b928/dev51 still has the named missing semantics above; no new package
qualification or core-development blocker inferred.
