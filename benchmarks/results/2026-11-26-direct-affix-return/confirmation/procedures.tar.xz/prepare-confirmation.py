from pathlib import Path
import hashlib,json,shutil,tarfile
lab=Path('.git/agent-notes/review-20261031/direct-affix-return-20261126')
old=lab/'comparison/quiet'
confirmed=lab/'confirmation';quiet=confirmed/'comparison/quiet';quiet.mkdir(parents=True,exist_ok=True)
read=lambda f:json.loads(f.read_text(encoding='utf-8-sig'))
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
def write(p,s):p.write_text(s,encoding='utf-8',newline='\n')
def save(p,s):write(p,json.dumps(s,indent=2,ensure_ascii=False)+'\n')
for name in ('representative.json','cpython-worker.py','run.sh'):
 shutil.copyfile(old/name,quiet/name)
assert b'\r' not in (quiet/'run.sh').read_bytes()
save(quiet/'jobs.json',{'warm':[['diagnostic.shipment-file-fed-map','warm-async'],
 ['scripts.file-search.large','compile-run'],['diagnostic.text-summary.nonlocal-computed-width.large','warm']]})
identity=read(old/'identity.json')
identity['catalogs']['jobs.json']['sha256']=sha(quiet/'jobs.json')
identity['purpose']='Reordered confirmation of the protected-search gain and first file-fed control cost.'
save(quiet/'identity.json',identity)
s=(old/'collect.py').read_text(encoding='utf-8').replace('len(jobs) == 5','len(jobs) == 3').replace('lython-b1746-fixtures','lython-b1747-fixtures')
write(quiet/'collect.py',s)
s=(lab/'quiet.py').read_text(encoding='utf-8-sig')
s=s.replace('lython-b1746b-direct-affix-return-20261126','lython-b1747-affix-confirmation-20261126')
s=s.replace('13*1024*1024','4*1024*1024').replace('seconds=263','seconds=160').replace('RuntimeMaxSec=320','RuntimeMaxSec=200')
s=s.replace('len(frames)==7 and len(set(f.name for f in frames))==7','len(frames)==6 and len(set(f.name for f in frames))==6')
a=s.index(" donor=base/'native-cursor-stack-b1743-20261126'/'candidate'"); b=s.index(" for role,files in image['imageFiles'].items():",a)
s=s[:a]+''' donor=base/'direct-affix-return-b1746b-20261126'
 donor_receipt=json.loads((donor/'archive-receipt.json').read_text())
 assert donor_receipt['complete'] and donor_receipt['archiveSHA256']==cfg['firstArchiveSHA256']
 assert sha(donor/'observations.tar.xz')==donor_receipt['archiveSHA256']
 for role in ('reference','candidate'):
  (root/role).symlink_to((donor/role).resolve(),target_is_directory=True)
'''+s[b:]
compile(s,'quiet.py','exec');write(confirmed/'quiet.py',s)
payload=quiet/'stage.tar.gz'
with tarfile.open(payload,'w:gz',compresslevel=6) as archive:
 for name in ('collect.py','run.sh','representative.json','jobs.json','identity.json','cpython-worker.py'):
  archive.add(quiet/name,arcname=name,recursive=False)
receipt=read(old/'terminal-status.json')['receipt']
assert receipt['complete'] and receipt['archiveSHA256']==sha(old/'observations.tar.xz')
save(quiet/'upload.json',dict(root='direct-affix-confirmation-b1747-20261126',payloadSHA256=sha(payload),payloadBytes=payload.stat().st_size,
 firstArchiveSHA256=receipt['archiveSHA256']))
