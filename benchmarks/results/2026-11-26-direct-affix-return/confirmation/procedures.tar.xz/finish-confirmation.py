from pathlib import Path
from statistics import median
import hashlib,json,shutil,tarfile

lab=Path('.git/agent-notes/review-20261031/direct-affix-return-20261126')
first=lab/'comparison/quiet'
trial=lab/'confirmation'
quiet=trial/'comparison/quiet'
out=Path('benchmarks/results/2026-11-26-direct-affix-return/confirmation')
out.mkdir(exist_ok=True)
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
identity=read(quiet/'identity.json'); original=read(first/'identity.json')
for key in ('sourceRevision','sourcePatchSHA256','imageFiles','coreSHA256','cpythonWorkerSHA256'):
 assert identity[key]==original[key]
assert identity['catalogs']['representative.json']==original['catalogs']['representative.json']
status=read(quiet/'terminal-status.json'); receipt=status['receipt']
assert not status['live'] and not status['fixtures'] and status['exitCode']=='0'
assert all(receipt[k]for k in ('allWorkersJoined','quietBeforeAndAfter','archivedAndVerifiedUnderLease','guestFixturesRemoved','complete'))
assert receipt['archiveSHA256']==sha(quiet/'observations.tar.xz') and receipt['warmJobs']==3
verification=read(trial/'remote-verify.json')
assert verification['state']=='Completed' and verification['caseCount']==4
assert verification['launched']['library']['sha256'].lower()==identity['coreSHA256']['candidate'].lower()
with tarfile.open(quiet/'observations.tar.xz') as archive:
 raw=json.load(archive.extractfile('confirmation/confirmation.json'))
 assert json.load(archive.extractfile('identity.json'))==identity
 assert archive.extractfile('representative.json').read()==(first/'representative.json').read_bytes()
 assert hashlib.sha256(archive.extractfile('jobs.json').read()).hexdigest()==identity['catalogs']['jobs.json']['sha256']
assert raw['complete'] and len(raw['jobs'])==3
assert read(lab/'reference-csv-tape.json')==read(lab/'candidate-csv-tape.json')
assert not read(lab/'reference-csv-tape.json')['HasDirectOperandReturn']
summary=[]
for job in raw['jobs']:
 assert job['workersJoinedAndFixturesRemoved'] and len(job['samples'])==28
 measures={}
 for role,worker in job['identities'].items():
  core=next(v for v in worker['libraries'] if Path(v['path']).name=='Lokad.Lython.dll')
  assert core['sha256'].lower()==identity['coreSHA256'][role].lower()
  samples=[x for x in job['samples'] if x['engine']==role]; assert len(samples)==7
  times=[];cpu=[]
  for sample in samples:
   response=sample['response']; assert response['status']=='Completed'
   count=response['completedInvocations']
   times.append(1e6*response['elapsedTicks']/response['clockFrequency']/count)
   cpu.append(1e6*sample['externalProcessCpuTicks']/sample['externalCpuFrequency']/count)
  measures[role]=dict(elapsed=median(times),cpu=median(cpu))
 differences={};spreads={}
 for metric in ('elapsed','cpu'):
  l,r=([measures[role][metric],measures[role+'-control'][metric]]for role in ('reference','candidate'))
  pairs=[100*(x/y-1)for x in r for y in l];differences[metric]=[min(pairs),max(pairs)]
  spreads[metric]=[100*(max(row)/min(row)-1)for row in (l,r)]
 summary.append(dict(case=job['case'],lane=job['lane'],processMedianUs=measures,percentChange=differences,sameSourceSpreadPercent=spreads))
 print(job['case'],job['lane'],differences,spreads)
for name in ('identity.json','terminal-status.json','observations.tar.xz'):shutil.copyfile(quiet/name,out/name)
(out/'summary.json').write_text(json.dumps(dict(sourceRevision=identity['sourceRevision'],sourcePatchSHA256=identity['sourcePatchSHA256'],
 timedBatches=84,collectionSeconds=raw['elapsedSeconds'],rows=summary),indent=2)+'\n',encoding='utf-8',newline='\n')
with tarfile.open(out/'procedures.tar.xz','w:xz')as archive:
 for name in ('quiet.py','retrieve.log','stage.log','remote-verify.json'):
  archive.add(trial/name,arcname=name)
 for name in ('prepare-confirmation.py','finish-confirmation.py','reference-csv-tape.json','candidate-csv-tape.json','route-probe/Program.cs','route-probe/Inspect.csproj'):
  archive.add(lab/name,arcname=name)
 for name in ('collect.py','jobs.json','run.sh','upload.json','launch.log'):
  archive.add(quiet/name,arcname='comparison/quiet/'+name)
