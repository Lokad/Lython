from pathlib import Path
from statistics import median
import hashlib,json,os,shutil,subprocess
lab=Path('.git/agent-notes/review-20261031/direct-affix-return-20261126')
probe=lab.parent/'regex-constant-subject-20261125/candidate-measure'
read=lambda f:json.loads(f.read_text(encoding='utf-8-sig'))
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
identity=read(lab/'comparison/quiet/identity.json')
sdk=Path.home()/'.dotnet11'
env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk))
collected={}
for role in ('reference','candidate'):
 image=lab/f'{role}-compile-measure'
 shutil.copytree(lab/role,image,dirs_exist_ok=True)
 assert {p.name:sha(p)for p in image.iterdir()}==identity['imageFiles'][role]
 for p in probe.glob('RouteProbe.*'):shutil.copyfile(p,image/p.name)
 output=lab/f'{role}-compile-allocations.json'
 with output.open('w',encoding='utf-8',newline='\n') as sink:
  subprocess.run([sdk/'dotnet.exe',image/'RouteProbe.dll',lab/'comparison/quiet/representative.json'],env=env,check=True,stdout=sink,timeout=45)
 current=read(output)
 assert current['coreSHA256']==identity['coreSHA256'][role]
 collected[role]=current['rows']
summary=[]
for a,b in zip(collected['reference'],collected['candidate'],strict=True):
 assert a['id']==b['id'] and a['retainedAdmission']==b['retainedAdmission']
 row=dict(case=a['id'],allocationBytes=[median(a['samples']),median(b['samples'])],retainedAdmission=a['retainedAdmission'])
 summary.append(row); print(row)
(lab/'compile-allocation-summary.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8',newline='\n')
