from pathlib import Path
import hashlib,json,os,shutil,subprocess,tarfile

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
bench=lab.with_name('csv-combined-record-admission-20261125')/'comparison/quiet'
manifest=lab.with_name('map-slots-refined-20261125')/'comparison/quiet/representative.json'
donor=lab.with_name('native-cursor-stack-admission-20261125')
quiet=lab/'comparison/quiet'
quiet.mkdir(parents=True,exist_ok=True)
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
git=lambda *args:subprocess.check_output(['git',*args],cwd=repo)
def save(p,v):p.write_text(json.dumps(v,indent=2,ensure_ascii=False)+'\n',encoding='utf-8',newline='\n')
head=git('rev-parse','HEAD').decode().strip()
assert head.startswith('265e48ba2')
assert git('diff','a490e9d5f',head,'--','src')==b''
original=read(donor/'comparison/quiet/identity.json')
assert git('diff','--binary',original['sourceRevision'],head,'--','src')==(donor/'candidate.patch').read_bytes()
base=original['imageFiles']['candidate']
assert len(base)==32 and {p.name:sha(p) for p in (donor/'candidate').iterdir()}==base
core=repo/'src/Lokad.Lython/bin/Release/net11.0/Lokad.Lython.dll'
assert sha(core)==sha(repo/'tests/Lokad.Lython.PublicApi.Tests/bin/Release/net11.0/Lokad.Lython.dll')
patch=git('diff','--binary','HEAD','--','src')
assert patch.count(b'diff --git ')==2
(lab/'candidate.patch').write_bytes(patch)
(lab/'tests.patch').write_bytes(git('diff','--binary','HEAD','--','tests'))
images=dict(reference=base,candidate=base|{core.name:sha(core)})
for role,files in images.items():
    image=lab/role
    image.mkdir(exist_ok=True)
    for name in files:
        shutil.copyfile(core if role=='candidate' and name==core.name else donor/'candidate'/name,image/name)
    assert {p.name:sha(p)for p in image.iterdir()}==files
catalog=read(lab.with_name('file-processing-profile-20261126')/'comparison/quiet/catalog.json')
rows={c['id']:c for c in catalog['cases']}
rows.update({c['id']:c for c in read(donor/'comparison/quiet/representative.json')['cases'] if c['id']=='diagnostic.shipment-file-fed-map'})
search='scripts.file-search.large'
dynamic='diagnostic.file-search-dynamic-receiver.large'
source=rows[search]['source']
source=source.replace("scanned = 0", "class Probe:\n    def startswith(self, prefix): return self.line.startswith(prefix)\n\nprobe = Probe()\nscanned = 0")
source=source.replace('        if wanted(line):', '        probe.line = line\n        if wanted(probe):')
raw=source.encode('utf-8')
rows[dynamic]=rows[search]|dict(id=dynamic,source=source,sourceUtf8Bytes=len(raw),sourceSha256=hashlib.sha256(raw).hexdigest())
jobs=[[search,'compile-run'],['diagnostic.text-summary.nonlocal-computed-width.large','warm'],[dynamic,'warm'],
    ['diagnostic.shipment-file-fed-map','warm-async'],[search,'warm']]
catalog['cases']=[rows[id] for id in dict.fromkeys(v[0] for v in jobs)]
save(quiet/'representative.json',catalog)
save(quiet/'jobs.json',{'warm':jobs})
script=repo/'benchmarks/cpython-worker.py'
shutil.copyfile(script,quiet/'cpython-worker.py')
ref=read(bench/'identity.json')
assert sha(script)==ref['cpythonWorkerSHA256']
identity=dict(sourceRevision=head,sourcePatchSHA256=sha(lab/'candidate.patch'),
    imageFiles=images, coreSHA256={label:images[label.removesuffix('-control')][core.name] for label in
        ('reference','reference-control','candidate','candidate-control')},
    cpythonWorkerSHA256=ref['cpythonWorkerSHA256'],expectedCPythonSHA256=ref['expectedCPythonSHA256'],
    catalogs={name:{'sha256':sha(quiet/name)} for name in ('jobs.json','representative.json')},
    purpose='Compare a closed affix return in the protected file search with dynamic and file-processing controls.')
save(quiet/'identity.json',identity)
shutil.copyfile(bench/'run.sh',quiet/'run.sh')
assert b'\r' not in (quiet/'run.sh').read_bytes()
(quiet/'collect.py').write_text((bench/'collect.py').read_text(encoding='utf-8').replace('lython-b1738-fixtures','lython-b1746-fixtures'),encoding='utf-8',newline='\n')
sdk=Path.home()/'.dotnet11'; dotnet=sdk/'dotnet.exe'
env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk))
for role,files in images.items():
    evidence=lab/f'{role}-verify.json'
    subprocess.run([dotnet,lab/role/'Lokad.Lython.Benchmarks.dll','--compare','verify','--catalog',quiet/'representative.json',
        '--dotnet',dotnet,'--python','C:/Python313/python.exe','--python-worker',script,'--out',evidence],
        cwd=repo,env=env,check=True,timeout=80)
    checked=read(evidence)
    assert checked['state']=='Completed' and checked['caseCount']==len(catalog['cases'])
    assert checked['catalogSha256']==identity['catalogs']['representative.json']['sha256']
    assert checked['launched']['library']['sha256']==files[core.name]
with tarfile.open(quiet/'stage.tar.gz','w:gz',compresslevel=6) as bundle:
    for name in ('collect.py','run.sh','representative.json','jobs.json','identity.json','cpython-worker.py'):
        bundle.add(quiet/name,arcname=name,recursive=False)
    bundle.add(lab/'candidate'/core.name,arcname='new-core.dll',recursive=False)
save(quiet/'upload.json',dict(root='direct-affix-return-b1746-20261126',
    payloadSHA256=sha(quiet/'stage.tar.gz'),payloadBytes=(quiet/'stage.tar.gz').stat().st_size))
print('Both complete images verify under four goldens.')
