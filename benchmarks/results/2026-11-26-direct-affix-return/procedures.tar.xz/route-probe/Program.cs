using System.Security.Cryptography;
using System.Text.Json;
using Lokad.Lython;
using Lokad.Lython.Frontend;
using Lokad.Lython.Runtime;
using Lokad.Lython.Runtime.Text;

var budget = new LythonMemoryBudget(1024 * 1024);
var outcomes = new List<object>();
using (var owner = budget.CreateScope())
{
    var host = new EmptyHost();
    var context = new LythonRuntime.ExecutionContext(host, new LythonRunOptions { MemoryBudget = owner });
    var frontend = LythonFrontend.Compile("def wanted(value): return value.startswith('é')\nreturn wanted");
    var code = ExecutableScript.Compile(frontend.Script!).EntryPoint;
    var function = (PyExecutableFunction)LythonRuntime.ExecuteExecutableCodeObject(code, context, default, null)!;
    var span = new LythonSourceSpan(0, 1, 1, 1);
    foreach (var input in new object[] { PyString.FromString("é😀"), PyString.FromString("zé"), PyNone.Instance })
    {
        LythonRuntime.ExecutableSlot[] arguments = [LythonRuntime.ExecutableSlot.FromObject(input)];
        var admitted = budget.ReservedBytes;
        var direct = function.TryStartSuppliedOperandReturn(arguments, null, span, out var value);
        if (admitted != budget.ReservedBytes || context.State.CurrentInterpreterDepth != 0 || context.State.CurrentRecursionDepth != 0)
            throw new InvalidOperationException("Admission did not unwind.");
        outcomes.Add(new { receiver = input is PyString text ? text.AsString() : null, direct, result = direct ? value.Object : null });
    }
}
if (budget.ReservedBytes != 0) throw new InvalidOperationException("Owner did not return to baseline.");
Console.WriteLine(JsonSerializer.Serialize(new {coreSHA256=Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(typeof(LythonEngine).Assembly.Location))).ToLowerInvariant(), outcomes}));

sealed class EmptyHost : ILythonHost
{
    public string Cwd => "/";
    public DateTimeOffset LocalNow => default;
    public DateTimeOffset UtcNow => default;
    public ValueTask<bool> ExistsAsync(LythonPathRequest path, CancellationToken token) => throw new NotSupportedException();
    public ValueTask<IReadOnlyList<string>> ListDirAsync(LythonPathRequest path, CancellationToken token) => throw new NotSupportedException();
    public ValueTask MkDirAsync(LythonPathRequest path, CancellationToken token) => throw new NotSupportedException();
    public ValueTask RemoveAsync(LythonPathRequest path, CancellationToken token) => throw new NotSupportedException();
    public ValueTask CopyAsync(LythonPathRequest source, LythonPathRequest destination, CancellationToken token) => throw new NotSupportedException();
    public ValueTask MoveAsync(LythonPathRequest source, LythonPathRequest destination, CancellationToken token) => throw new NotSupportedException();
    public ValueTask<LythonPathStat> StatAsync(LythonPathRequest path, CancellationToken token) => throw new NotSupportedException();
}
