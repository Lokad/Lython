from pathlib import Path
import hashlib,json,subprocess,tarfile
root=Path('/home/lokad/lython-bench-checks/returned-record-b422-20261107')
assert json.loads((root/'machine-before.json').read_text())['gate']['quiet']
assert json.loads((root/'machine-after.json').read_text())['gate']['quiet']
assert not list(Path('/dev/shm').glob('lython-comparison-files-*'))
fixtures=root/'guest-fixtures'
assert fixtures.is_mount() and not list(fixtures.iterdir())
(root/'fixture-filesystem.txt').write_text(subprocess.check_output(['findmnt','-T',str(fixtures),'-o','TARGET,SOURCE,FSTYPE,OPTIONS'],text=True))
assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record'],capture_output=True).returncode==1
records=[]
for case in ['record-warm']:
 record=json.loads(((root/'profiles')/case/'record.json').read_text())
 assert record['exitCode']==0 and record['closed']['status']=='Closed'
 assert ((root/'profiles')/case/'worker.stderr').stat().st_size==0
 assert record['verificationBefore']['status']=='Equivalent' and record['verificationAfter']['status']=='Equivalent'
 records.append(record)
assert sum(r['response']['elapsedTicks']/r['response']['clockFrequency'] for r in records)<8
with tarfile.open(root/'observations.tgz','w:gz',dereference=True) as a:
 a.add(root/'profiles',arcname='perf')
 for p in root.rglob('*'):
  if p.is_file() and p.name!='observations.tgz' and 'candidate' not in p.relative_to(root).parts and 'profiles' not in p.relative_to(root).parts and 'guest-fixtures' not in p.relative_to(root).parts:a.add(p,arcname=str(p.relative_to(root)))
with tarfile.open(root/'observations.tgz') as a:
 for case in ['record-warm']:assert json.loads(a.extractfile('perf/'+case+'/record.json').read())['exitCode']==0
receipt=dict(complete=True,allWorkersJoined=True,guestFixturesRemoved=True,quietBeforeAndAfter=True,archivedAndVerifiedUnderLease=True,
 capturedSeconds=sum(r['response']['elapsedTicks']/r['response']['clockFrequency'] for r in records),
 archiveSHA256=hashlib.sha256((root/'observations.tgz').read_bytes()).hexdigest(),performanceQualified=False)
(root/'archive-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt))
