from pathlib import Path
import hashlib
import json

lab = Path(__file__).resolve().parent
prior = lab.with_name("async-map-prefix-20261125")
read = lambda path: json.loads(path.read_text(encoding="utf-8"))
catalog = read(prior / "input-catalog.json")
catalog["cases"] = [case for case in catalog["cases"] if case["id"] != "diagnostic.bound-map-defaulted-readings"]
assert len(catalog["cases"]) == 5
retained = read(lab.with_name("zip-unpack-20261125") / "comparison/quiet/representative.json")
catalog["cases"].append(next(entry for entry in retained["cases"] if entry["id"] == "diagnostic.shipment-retained-zip"))
shipment = next(entry for entry in catalog["cases"] if entry["id"] == "diagnostic.shipment-routing-callbacks")
line = "    results = map(choose, held, repeat(review), primary)"
assert shipment["source"].count(line) == 1
source = shipment["source"].replace(line, "    results = (policy for policy in map(choose, held, repeat(review), primary))")
utf8 = source.encode("utf-8")
catalog["cases"].append(shipment | dict(id="diagnostic.shipment-generator-over-map", source=source,
    sourceUtf8Bytes=len(utf8), sourceSha256=hashlib.sha256(utf8).hexdigest()))
save = lambda name, data: (lab / name).write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n",
                                                  encoding="utf-8", newline="\n")
save("input-catalog.json", catalog)
for case in catalog["cases"]:
    case["runAsync"] = case["id"].startswith("diagnostic.shipment-")
save("allocation-catalog.json", catalog)
