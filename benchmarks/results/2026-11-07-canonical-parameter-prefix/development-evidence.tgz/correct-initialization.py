from pathlib import Path
p=Path('src/Lokad.Lython/Frontend/ExecutableScript.Builder.cs');s=p.read_text(encoding='utf-8').replace('foreach (var name in _parameterLayout.LayoutParameterNames)\n                    if (IsLocalBindingName(name)) InternLocal(name);','foreach (var parameterName in _parameterLayout.LayoutParameterNames)\n                    if (IsLocalBindingName(parameterName)) InternLocal(parameterName);');p.write_text(s,encoding='utf-8',newline='\n')
p=Path('src/Lokad.Lython/Frontend/LoweredStatement.cs');s=p.read_text(encoding='utf-8');s=s.replace('    public FunctionParameterLayout ParameterLayout { get; } = new(Parameters);','''    private readonly (FunctionParameterLayout Layout, ExecutableCodeObject? Generator) _preparedParameters =
        PrepareParameters(Syntax, Parameters, Body, ScopeFacts);
    public FunctionParameterLayout ParameterLayout => _preparedParameters.Layout;''')
a=s.index('    public ExecutableCodeObject? GeneratorCode { get; } = GeneratorSyntaxFacts.IsGenerator(Syntax.Body)');b=s.index('\n}',a)
s=s[:a]+'''    public ExecutableCodeObject? GeneratorCode => _preparedParameters.Generator;

    private static (FunctionParameterLayout, ExecutableCodeObject?) PrepareParameters(
        FunctionDefinitionStatementSyntax syntax, IReadOnlyList<LoweredFunctionParameter> parameters,
        IReadOnlyList<LoweredStatement> body, ScopeDirectiveFacts facts)
    {
        var layout = new FunctionParameterLayout(parameters);
        return (layout, GeneratorSyntaxFacts.IsGenerator(syntax.Body)
            ? ExecutableScript.CompileGenerator(layout, body, facts) : null);
    }'''+s[b:];p.write_text(s,encoding='utf-8',newline='\n')
root=Path('.git/agent-notes/review-20261031/canonical-parameter-prefix-r32');(root/'build-initial.log').rename(root/'build-initial-initialization-failure.log');p=root/'focused.py';s=p.read_text(encoding='utf-8').replace("'build-initial.log'","'build-corrected.log'");p.write_text(s,encoding='utf-8',newline='\n')
