from pathlib import Path
import hashlib,json,os,re,subprocess
root=Path(__file__).parent
env=os.environ.copy();env['DOTNET_ROOT']='C:/Users/JoannesVermorel/.dotnet11';env['DOTNET_HOST_PATH']=env['DOTNET_ROOT']+'/dotnet.exe';env['PATH']=env['DOTNET_ROOT']+os.pathsep+'C:/Python313'+os.pathsep+env['PATH']
def run(args,log):
    with (root/log).open('w',encoding='utf-8') as output:
        result=subprocess.run([env['DOTNET_HOST_PATH'],*args],env=env,stdout=output,stderr=subprocess.STDOUT)
    text=(root/log).read_text(encoding='utf-8')
    if result.returncode:print(text[-4500:],flush=True)
    return result.returncode,text
code,_=run(['build','Lokad.Lython.slnx','-c','Release','--no-restore','--nologo','--tl:off'],'build-corrected.log')
if code:raise SystemExit(code)
families=['PreparedFunctionDefaults','FunctionDefaultConstruction','FunctionClassCell','Lambda','Generator','Class','Scope','Super','Annotation','SharedMemory','GovernedMemory','Cancellation']
selection='Category!=Stress&('+'|'.join('FullyQualifiedName~'+name for name in families)+')';checks={}
for tfm in ['net11.0','net10.0']:
    for suite in ['Lokad.Lython.Tests','Lokad.Lython.PublicApi.Tests']:
        key=suite+'-'+tfm
        code,log=run(['test',f'tests/{suite}/{suite}.csproj','-c','Release','-f',tfm,'--no-build','--no-restore','--nologo','--tl:off','--filter',selection],'focused-initial-'+key+'.log')
        checks[key]=dict(exitCode=code,summaries=re.findall(r'(?:Passed!|Failed!)\s+[^\r\n]+',log))
        (root/'focused-initial.json').write_text(json.dumps(dict(checks=checks,selection=selection),indent=2)+'\n',encoding='utf-8')
        print(key,checks[key],flush=True)
        if code:raise SystemExit(code)
result=dict(checks=checks,selection=selection,coreSHA256={tfm:hashlib.sha256(Path(f'src/Lokad.Lython/bin/Release/{tfm}/Lokad.Lython.dll').read_bytes()).hexdigest() for tfm in ['net11.0','net10.0']})
(root/'focused-initial.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
