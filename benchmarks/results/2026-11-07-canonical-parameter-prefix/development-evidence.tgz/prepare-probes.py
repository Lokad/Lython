from pathlib import Path
import subprocess,os,json
root=Path('.git/agent-notes/review-20261031/canonical-parameter-prefix-r32')
(root/'generator-prefix.py').write_text('print(sum(i * i for i in range(32)))\n',encoding='utf-8',newline='\n')
s=(root.parent/'prepared-call-layout-r31/probes.py').read_text(encoding='utf-8').replace("root/'function-defaults.py'","root/'generator-prefix.py'")
(root/'probes.py').write_text(s,encoding='utf-8',newline='\n')
