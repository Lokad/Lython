# Lokad.Lython 0.11.0

Updated 2026-11-07. Git-ignored: never force-add. Publication/tagging postponed.
Objective: coherent simplification and substantial complete-script improvement.
Finishing an experiment does not finish that objective.

## Delivery status

- **Fully qualified:** R29 `81036f25`, terminal GREEN42333421800/all eight Windows/
  Ubuntu, actual .NET11/10, original Stress and installed-package gates. This
  includes R26's correctness fix. R26 `c4729a9f`, R25 `01aedc3b`, R23 `ec134e8c`
  and R22 `41c25958` were likewise fully qualified. All terminal receipts cached;
  never query or repeat unchanged qualification. Preserve the shared compiler-fact
  correction, direct UTF-8 formatting/storage and native helper returns.
- **Completed:** B380 representative CPython refresh on exact `81036f25`, frozen
 32dcf141. Every source hash verified against preserved R26 plus committed R29,
 excluding the current R30 prototype. All15jobs/goldens/funding/quiet/joins/archive
 pass in312s. Primary docs/BENCHMARKS.md now measures this source. Historical
 R25 measurements remain immutable; completed checkpoints are not rerun for dates.
- **Withdrawn:** R28 shared split-result storage and mask refinement. Allocation
 −6.94% is established; text elapsed inconclusive, report consistently adverse.
 Both runtime variants removed, Unicode regressions retained. All source/raw/
 initial overcharge/assertion failures and adverse observations remain preserved.
- **Retained, focused-qualified; full delivery pending:** R30 prepared class own-cell
  facts75e60e66/89ee0097. Runtime syntax walk removed. Focused382internal/1,921public
  per actual target plus independent Python probes pass. B382/all five jobs/gates:
  class warm−5.83–6.31%, fresh−3.65–5.33%; compile+0.70–1.30%. Warm allocation−7.75%,
  compile+1,048B. Desktop text adverse not reproduced; cause still unresolved.
  Evidence2026-11-07-prepared-class-facts. Batch full delivery with next coherent
  runtime milestone; no repeat of R29's unchanged qualification.

## Established results / unresolved measurements

| Milestone | Established | Remaining qualification or uncertainty |
| --- | --- | --- |
| Shared compiler facts | Eliminates exponential traversal of shared inferred values; mutable aliases/diagnostics/cancellation preserved | Not a warm-execution result; keep corrected callback traversal too. |
| R29 completed calls | Synthetic pending/completion phase removed; qualified; text elapsed improves with allocation flat | Report/CSV debt and primary CPython variation remain explicit; no broad CPU claim. |
| Native helper returns | Allocation−19.92/−19.31%; qualified | Historical elapsed improvements are diagnostic, not established CPU gains or percentages transferable to HEAD. |
| Direct UTF-8 formatting | Allocation−8.67%; controlled B102 elapsed/CPU−5–8% supports retention | Original adverse15.125ms remains unexplained/preserved; reopen only for justified correction/refinement, not unchanged date-refresh retiming. |
| R20 shared record layout | JSON allocation~−15%, report~−9.4%; warm JSON−10.9–12.5%, report−5.4–8.8%; qualified | CSV coarse CPU mixed. Text−1.21 to+5.53% is accepted possible debt, not parity. |
| R21/R22 execution/setup | Shared resume path removes per-instruction pending return/error polling; immutable builtin metadata; factory−2,688B; qualified | Whole-script R22 allocation mostly<0.2%, config~1.17%; clocks/control movement prevent broad CPU attribution. |
| U04/R23 regex ownership/programs | Capture carriers removed; duplicate frontend/runtime compilation removed; qualified | U04 direct allocation−20.34%; R23 extraction warm−8.34–9.64%, fresh−6.47–6.53%. Earlier denial: compiled funding39,397→105,481B until script disposal. |
| R25 CSV values | Final funded row-array transfer removes second values array/per-field publication for exact unchanged native headers; qualified | Allocation−7.31/−6.55%; B372 ordinary warm−4.13–4.78%, native−7.72–8.04%; controls/coarse CPU limit attribution. |
| R26 canonical formatting | Corrects stale native proof/InvalidCastException after admission changes a receiver; removes duplicate formatted-body execution; qualified | Allocation flat; possible~3% async/text elapsed debt remains for the next coherent execution delivery. |

B380 separates compile-only44–72µs from warm execution: text1.71–1.75×, CSV
1.22×, JSON1.05–1.06×, report1.38–1.42× CPython. Fresh text1.62–1.66×; CSV,
text, JSON and report fresh cases remain variable. Warm text has2.50%role spread,
report3.21%/3.12%IQR. Boundary includes mediated RAM I/O, full checks and prior-result
cleanup; excludes startup, staging/reset and final teardown. No subtraction of
medians or compounding source pairs. Startup, truly suspended-I/O latency, heap/
RSS and embedding tails remain open. Refresh again for a meaningful runtime change.

## Priority 1 — R31 canonical prepared function-call layout

**Hypothesis/source:** FunctionBindingPlan still counts/classifies parameters,
allocates positional/keyword arrays, builds layout names/name-to-slot dictionary
for every guest function object. Parameters
are immutable compiled metadata; defaults, closures and identity are not. Remove
that repeated definition-time construction phase by sharing one prepared immutable
layout across executable/lowered/lambda/generator consumers. Keep per-function
mutable defaults and attributes private. Reuse compiler slot metadata where it
actually matches; do not add identity caches, another binder or a parallel route.

**Scope/removed work:** displace the immutable half of FunctionBindingPlan's
constructor, duplicated parameter classification/maps . Keep per-function keyword PyString names private; do not silently
share exposed identity or its storage owner. One canonical layout belongs to compiled/lowered code; dynamic
native-generated methods prepare the same shape under their existing owner.
Do not retain both old/new construction engines. No per-call arena or control
packet; preserve delivered direct operands/deferred contexts/native returns.

**Acceptance/tradeoffs:** positional-only/keyword-only/variadics/default mutation,
receivers, decorators, nested closures, generators, lambdas, class cells, lazy
annotations, callback suspension and diagnostic ordering unchanged. Admission
funds retained metadata at compilation/dynamic construction, mutable defaults and
replacement overlap at creation; escaping function aliases retain compiled owners.
The existing coarse compilation reservation covers prepared tables; no new owner
or allowance. Native generated layouts keep preflight/rollback through plan creation.
Preserve terminal refusal/cancellation and actual-user cleanup. Prove owner lifetime
before implementation; do not share mutable PyString identity/default dictionaries.

**Bounded decision:** source proof first, then focused Release semantic/cancellation/
ownership checks and short precise compile/warm allocation diagnostic. Compare
complete class-factory plus representative helper/config compile-to-result and
unchanged text/CSV controls when a coherent prototype is ready; preserve adverse
results, use bounded confirmation if controls/measurement fail. Decide simplification,
allocation and elapsed separately. Stop this milestone when old construction is
removed and semantics/ownership established; defer unsupported representation
redesigns, not the larger performance objective. Batch full platform/Stress/installed
consumers with retained R30 at this delivery boundary. No forecast percentage.

R30 is recorded above and in immutable history. B381 failed before Ready on a
fixture-size mismatch, with no timings. Corrected metadata passed normal worker
verification; B382 used unchanged frozen images and completed139.51s/all gates.
Original catalog, failed capture and adverse desktop observations remain retained.
Both collections are terminal; no further queries/retiming of them.

R31 prototype33384376/9a043078 passes1,080internal/4,616public per actual target,
including repeated function/default mutation plus complete run/budget reuse.
Precise local diagnostic: class warm allocation−10.65%, fresh−7.35%, compilation
+1,728B; text/CSV changes tiny, config flat. Desktop class warm/fresh elapsed is
adverse and preserved. Do not claim CPU from allocation. B383 now compares six
jobs/four roles on quiet VM; catalog passes supervised Lython/CPython validation.
Observe only after 2026-11-07T04:25:24.031054+00:00; owner230+stop30+margin40.
Core source is frozen for this comparison. Retention/regression decision follows;
no automatic refinement series or unchanged qualification replay.

## Following redesign roadmap

R29's completed-call phase is delivered: existing native helpers no longer
manufacture pending state or reenter the prefix. B378 warm text improves4.25–7.61%
sync/7.63–8.64%async versus R26 with allocation/peaks flat. Report varies, CSV
retains up to3.04%adverse against differing baselines; JSON improves. Accept that
uncertainty as explicit milestone debt, not parity or automatic percentage veto.
R26's possible earlier~3%text/async debt is not algebraically repaid by another run.

Destination source inspection: completed result publication already skips its
following store. Deleting that metadata alone does not remove normal dispatch;
pending disposal still needs its funded continuation/span. Do not add a pending
register/table merely to remove an instruction. Reopen for a coherent design that
eliminates actual work and preserves the GC-lifetime fence and cleanup semantics.

| Area / evidence | Work to eliminate / displaced implementation | Scripts and acceptance / decision |
| --- | --- | --- |
| Complete call/frame construction | R29 completed phase delivered. Target another complete argument/binding/context/continuation phase, preserving existing borrowed/native paths; remove its old driver/transport. | Helper-heavy text/CSV/report, constructors and genuine I/O. Defaults, dynamic keywords, protocol selection, frames, evaluation order, stack admission, cancellation and funded borrows. No arena merely because boxing exists. |
| Boxed values / operand transport | Assess integer object traffic together with reads, publication and retirement. Select a canonical representation only with a proved hot removable phase; delete displaced object/transport paths. | Counters/indexes/aggregation; Python identity/aliases/hash/projection, exact promotion and public storage funding. Small add's~3% CPU is insufficient by itself; do not start a universal migration speculatively. |
| Per-record construction | R20/R25 delivered. Earlier6–8% CSV bulk rejection was reconsidered through completed-array transfer, not automatically promoted. Select another phase only when an actual intermediate can disappear. | CSV/JSON/report; header reentry/admission mutation, short/rest/duplicate/custom keys, independent mutable rows, Clear capacity and overlap. Keep old adverse control results. |
| Remaining text conversions | Casing/split and unchanged UTF-8 file windows already direct. R28−6.94% allocation fails to justify universal window overhead/report debt; seek a different final-storage/conversion boundary. | Unicode expansion/context, indexing/hash/repr, regex scalar/byte offsets, retained aliases and cancellation. No new pool/owner ledger; allocations and CPU are distinct. |
| Repeated frontend analysis | Lexical/shared facts already reused. Consolidate a demonstrated duplicate walk or retained representation; remove it rather than add another cache. | Helper/comprehension compile-to-result controls, separate from warm text. Preserve corrected shared-graph analysis, scoping/class cells/annotations, diagnostics and compile cancellation/admission. |

## Next source-backed consolidation

R32 candidate: feed R31's canonical parameter layout into executable slot-prefix
construction. Builder still loops over parameter kinds twice to establish the
same named/variadic prefix. Remove that second ordering algorithm; keep module
versus function distinction, local directives, captures and synthetic generator
bindings. Existing full layout includes only parameters, while the compiler's
local map also includes body locals; do not conflate the maps. Acceptance: identical
instruction/local/closure shapes for representative helpers, defaults/variadics,
comprehensions/generators/classes; compile allocation/time separate from warm.
No new runtime route, cache, owner or CPU forecast. First finish R31's decision
and coherent qualification boundary before changing its measured source.

Do not target captured-header cloning as ordinary-script overhead: source shows
it serves yielding function-definition headers. Retain real suspension ordering
and annotation behavior. A sync/async public probe with positional-only, regular,
variadic and keyword annotation effects matches CPython; no bug is inferred from
the source alone. Future consolidation requires actual affected workloads.

## Independent regex track

Core Python semantics/native UTF-8, byte ranges, scalar original-subject windows,
captures/replacements/errors, ownership and current cancellation keep advancing.
U04/R23 delivered; core has zero backend dependency/type edges. Normal adapter
pin0.4 is nonpackable. Dev46 immutable source6957b35a passes85 internal/482 public
per actual target using the U04 bridge; evidence2026-11-06-regex-dev46-compatibility.
Do not repeat unchanged qualification or promote private producer bits silently.

Dev48 immutable packages/sourcef6b2175e inspected: documented surface unchanged
from46; scalar candidate optimization does not supply the missing ownership/name/
cursor-token capabilities below. Exact packages privately qualify85internal/488public per actual11/10 on existing
semantic/cancellation/refusal suites. Keep0.4 pin and nonpackable adapter unchanged.
Evidence2026-11-07-regex-dev48-compatibility preserves original restore failures.
This is compatibility qualification, not backend CPU/safety/release certification.

Only affected final adapter qualification waits: DetailedData lacks independent
Prepare working ownership; native names cannot be enumerated; native cursors mix
creation/current tokens. Existing conservative preflight, adapter-local conversion
and qualified CTS bridge support development/current semantics. Normal0.4 reversed
windows fail explicitly. Development producers/bridges are acceptable; qualify the
released immutable package/managed safety separately. No sibling edits, silent
dialect fallback, work/time quotas or abandoned matching. This dependency never
blocks independent core implementation/correctness/performance work.

## Evidence, iteration and project constraints

Timeouts, unstable controls and inconclusive timings establish uncertainty. Allow
bounded confirmation/refinement/measurement correction when justified; preserve
original failed conditions and adverse results. Percentages inform decisions,
not automatic vetoes or permanent closures. Distinguish simplification, allocation,
elapsed and demonstrated CPU. Temporary regression debt needs an explicit
completion milestone/decision. Keep active plan concise; historical narratives/raw
sources/observations belong in benchmarks/results and benchmarks/EXPERIMENTS.md.
R28 all variants, failed conditions and exact images are preserved in committed
2026-11-07-owned-split-storage; original B205 binaries likewise have committed
backup before redundant expanded VM copies are retired after user/link/hash checks.

Follow AGENTS.md: fully managed/memory-safe; no unsafe/Unsafe/pointers/PInvoke/native
probing. Preserve managed stack/recursion, host capabilities/contained paths, cycles,
cooperative cancellation and borrowed shared allowance for capacity/replacement/
escaping aliases. First admission refusal fails the command; never retry. Await
all users/cleanup. No fuel/quotas, hidden caps/default allowance, heap tracing,
weak reclamation or forced GC. Long streaming uses bounded host executions;
XML depth constraint remains. Do not alter supported semantics to simplify proof.

Focused Release iteration; no overlapping local builds/tests. Nonincremental build
after timestamp-preserving restore. Quiet VM lokad@20.166.121.73,
key~/.ssh/id_lython-bench.pem: owned lease, Ready identities, controls/quiet/goldens/
funding/Closed/joins and verified persistent archives. Observe only after recorded
owner+stop+margin bound. Disk nearly full: retire exact redundant expanded files
only after independent committed backup and current user/dependency checks. Keep
all raw evidence. Continue the roadmap; publication/tagging remain postponed.

B383 failed before workers on a stale five-job collector assertion; no timings.
Failure archived, no users/fixtures. Generated B384 collector/archive job counts
are now checked locally and remotely before launch. Same runtime/catalog/profile.
Observe after 2026-11-07T04:32:13.168731+00:00; no queries/restarts before bound.
