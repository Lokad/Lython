from pathlib import Path
import hashlib,json,shutil,subprocess,tarfile
root=Path('.git/agent-notes/review-20261031/canonical-parameter-prefix-r32');out=Path('benchmarks/results/2026-11-07-canonical-parameter-prefix');out.mkdir()
for name in ['focused-initial.json','summary.json','probes.json','baseline.json']:shutil.copyfile(root/name,out/name)
(root/'source.patch').write_bytes(subprocess.check_output(['git','-c','core.safecrlf=false','diff','--','src']))
checks=json.loads((root/'focused-initial.json').read_text(encoding='utf-8'))
with tarfile.open(out/'development-evidence.tgz','w:gz') as a:
    for p in root.iterdir():
        if p.is_file():a.add(p,arcname=p.name)
    for name in ['compile','warm']:
        for p in (root/name).rglob('*'):
            if p.is_file():a.add(p,arcname=p.relative_to(root))
    for name in ['Program.cs','complete-jobs.csproj','Directory.Build.props']:a.add(root/'tool'/name,arcname='tool/'+name)
    for framework in ['net11.0','net10.0']:
        image=Path(f'src/Lokad.Lython/bin/Release/{framework}/Lokad.Lython.dll')
        assert hashlib.sha256(image.read_bytes()).hexdigest()==checks['coreSHA256'][framework]
        a.add(image,arcname=f'checked-images/{framework}/Lokad.Lython.dll')
p=out/'development-evidence.tgz';(out/'sha256.json').write_text(json.dumps({p.name:hashlib.sha256(p.read_bytes()).hexdigest()},indent=2)+'\n',encoding='utf-8',newline='\n')
(out/'README.md').write_text('''# Canonical compiler parameter prefix — R32

2026-11-07. Complete R31's parameter metadata design: executable local slots use
the same prepared named/variadic order as the binder. Remove Builder's raw parameter
list and separate two-pass classification. Keep function/module distinction and
body-local maps, directives, transitive closures and synthetic generator bindings.
Lowered definitions prepare their layout and optional generator together; there is
no second ordering algorithm, cache, dispatch route or ownership mechanism.

Sourcebf279768 plus the preserved seven-file frontend patch; exact checked core
net11 77bb12cc / net10 0f9553f9. Runtime implementation source is unchanged.
Full source patch, initial compiler initialization/name failure and corrected
commands/logs are retained with the exact checked images.

Release build zero warnings/errors; per actual.NET11/.NET10,406internal/1,962public
focused checks pass: prepared functions/defaults, class/super/scopes, annotations,
lambda/comprehension/generator behavior, cancellation and shared admission/lifetimes.
All four actual-target/API generator probes independently match CPython3.13.2.

One short existing complete-job diagnostic compares R31 33384376, current and an
identical-before image: separate compile/warm, four cases,32warmups and five rotated
16-job rounds. All stdout/file goldens, funding, isolation and fixture gates pass.
Compilation allocation falls128B for the four-definition class factory,32B for
text/CSV's helper. A synthetic generator expression adds152B (+0.385%) for its
explicit empty prepared function layout; retain this small compilation tradeoff.
Warm allocation is flat (observed differences below0.02%; generator exactly flat).
No quiet-machine timing was run for this compiler consolidation; desktop clocks
remain diagnostic. Do not transfer R31's measured percentages to this exact image.

Full Windows/Ubuntu, actual-target ordinary/original Stress and installed Release
consumers are batched once for the retained R30–R32 delivery. That qualification is
pending; prior R29 green receipts do not qualify this source. Text/CSV uncertainty
from R31 remains open at the next coherent execution milestone. This completes the
parameter-layout consolidation, not the broader complete-script performance goal.
''',encoding='utf-8',newline='\n')
p=Path('docs/RUNTIME.md');s=p.read_text(encoding='utf-8');old='created functions. Mutable defaults, keyword-name values, attributes and closures';assert old in s;s=s.replace(old,'created functions. Executable local slots use that same prepared parameter order,\nthen append body locals. Mutable defaults, keyword-name values, attributes and closures');p.write_text(s,encoding='utf-8',newline='\n')
p=Path('CHANGELOG.md');s=p.read_text(encoding='utf-8');old='  and keyword-name storage private, with native generated admission/rollback.';assert old in s;s=s.replace(old,old+'\n  Reuse the same parameter order for executable slots, removing the compiler\'s\n  separate classification pass.');p.write_text(s,encoding='utf-8',newline='\n')
with Path('benchmarks/EXPERIMENTS.md').open('a',encoding='utf-8',newline='\n') as f:f.write('''
## Canonical compiler parameter prefix (2026-11-07)

[R32](results/2026-11-07-canonical-parameter-prefix/README.md) deletes the compiler's
separate parameter-order algorithm and consumes R31 metadata directly. Focused
406internal/1,962public per actual target plus independent generator Python probes
pass. Compilation removes32B per ordinary definition; an empty generator layout
adds152B. Warm allocation flat; no quiet timing or CPU claim for this exact image.
Full platform/Stress/installed consumers batch the retained R30–R32 delivery.
''')
p=Path('PLAN.md');s=p.read_text(encoding='utf-8').replace('- **Active:** R32 compiler-prefix consolidation, then one coherent R30–R32 delivery\n  qualification. Draft exists outside production; no measured R32 CPU claim.','''- **Implemented, focused-qualified; committing:** R32 canonical parameter prefix
  removes Builder's duplicate ordering, images77bb12cc/0f9553f9.406internal/1,962public
  per actual target and independent generator probes pass; compile−32B/ordinary
  definition, empty generator+152B; warm flat. No measured R32 CPU claim.
- **Active:** one coherent R30–R32 platform/Stress/installed-package qualification,
  then Priority2 representative execution design. No isolated-experiment closure.''')
s=s.replace('## Priority 1 — complete canonical parameter metadata (R32)','## Priority 1 — qualify canonical parameter metadata (R30–R32)')
s=s.replace('**Acceptance/stop:** focused Release functions/defaults/lambda/generator/class/','**Acceptance/stop:** implementation and focused Release functions/defaults/lambda/generator/class/')
s=s.replace('Keep the body-local map distinct from the parameter-only lookup. No extra cache,','Body-local maps remain distinct from parameter-only lookup. No extra cache,')
p.write_text(s,encoding='utf-8',newline='\n')
print('R32 evidence/limitations retained; prepared-layout milestone ready for batched delivery.',flush=True)
