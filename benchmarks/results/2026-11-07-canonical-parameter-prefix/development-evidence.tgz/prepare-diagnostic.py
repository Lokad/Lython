from pathlib import Path
import copy,hashlib,json,shutil
root=Path('.git/agent-notes/review-20261031/canonical-parameter-prefix-r32');old=root.parent/'prepared-call-layout-r31';(root/'tool').mkdir()
for name in ['Directory.Build.props','complete-jobs.csproj']:shutil.copyfile(old/'tool'/name,root/'tool'/name)
s=(old/'tool/Program.cs').read_text(encoding='utf-8').replace('R31 prepared function-layout diagnostic','R32 canonical compiler parameter-prefix diagnostic').replace('Require class-factory, configuration, text and CSV cases.','Require class-factory, text, CSV and generator cases.')
(root/'tool/Program.cs').write_text(s,encoding='utf-8',newline='\n')
catalog=json.loads((old/'catalog.json').read_text(encoding='utf-8'));catalog['cases']=[c for c in catalog['cases'] if c['id']!='scripts.config-edit.small']
case=copy.deepcopy(next(c for c in catalog['cases'] if c['id']=='scripts.class-factory.small'))
source='print(sum(i * i for i in range(32)))\n';output='10416\n'
case.update(id='scripts.generator-prefix.small',category='compiler-generator-control',source=source,sourceUtf8Bytes=len(source.encode('utf-8')),sourceSha256=hashlib.sha256(source.encode('utf-8')).hexdigest(),expectedOutput=output,expectedOutputUtf8Bytes=len(output.encode('utf-8')),expectedOutputSha256=hashlib.sha256(output.encode('utf-8')).hexdigest())
assert json.loads(case['fixtureJson'])['size']==case['size']==32
catalog['cases'].append(case);assert len(catalog['cases'])==4
(root/'catalog.json').write_text(json.dumps(catalog,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
b=json.loads((root/'baseline.json').read_text(encoding='utf-8'));b['coreSHA256']=json.loads((old/'focused-initial.json').read_text(encoding='utf-8'))['coreSHA256'];(root/'baseline.json').write_text(json.dumps(b,indent=2)+'\n',encoding='utf-8',newline='\n')
s=(old/'measure.py').read_text(encoding='utf-8').replace("root.parent/'compiler-class-facts-r30/images/candidate/Lokad.Lython.dll'","root.parent/'prepared-call-layout-r31/images/candidate/Lokad.Lython.dll'").replace('class-factory, configuration, text and CSV complete jobs','class-factory, text, CSV and generator jobs; compiler-only consolidation').replace("for phase in ['compile','warm','fresh']:","for phase in ['compile','warm']:")
(root/'measure.py').write_text(s,encoding='utf-8',newline='\n')
s=(old/'summarize.py').read_text(encoding='utf-8').replace("['compile','warm','fresh']","['compile','warm']")
(root/'summarize.py').write_text(s,encoding='utf-8',newline='\n')
print('Prepared short R32 compile/warm allocation observations; no quiet CPU comparison.',flush=True)
