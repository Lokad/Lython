from pathlib import Path
import json,os,re,subprocess
root=Path('.git/agent-notes/review-20261031/canonical-parameter-prefix-r32');env=os.environ.copy();env['DOTNET_ROOT']='C:/Users/JoannesVermorel/.dotnet11';env['DOTNET_HOST_PATH']=env['DOTNET_ROOT']+'/dotnet.exe';env['PATH']=env['DOTNET_ROOT']+os.pathsep+'C:/Python313'+os.pathsep+env['PATH']
project='tests/Lokad.Lython.PublicApi.Tests/Lokad.Lython.PublicApi.Tests.csproj'
commands=[('defaults-stress-build',['build',project,'-c','Release','--no-restore','--nologo','--tl:off'])]+[(f'defaults-stress-{f}',['test',project,'-c','Release','-f',f,'--no-build','--no-restore','--filter','FullyQualifiedName~FunctionDefaultsAccountingScenarioTests','--nologo','--tl:off']) for f in ['net11.0','net10.0']]
checks={}
for label,args in commands:
 log=root/(label+'.log');assert not log.exists(),str(log)
 with log.open('w',encoding='utf-8') as output:p=subprocess.run([env['DOTNET_HOST_PATH'],*args],env=env,stdout=output,stderr=subprocess.STDOUT)
 s=log.read_text(encoding='utf-8');print(label,p.returncode,s[-1800:] if p.returncode else s[-500:],flush=True)
 checks[label]=dict(exitCode=p.returncode,summaries=re.findall(r'(?:Passed!|Failed!)\s+[^\r\n]+',s))
 (root/'defaults-stress-focused.json').write_text(json.dumps(checks,indent=2)+'\n',encoding='utf-8',newline='\n')
 if p.returncode:raise SystemExit(p.returncode)
