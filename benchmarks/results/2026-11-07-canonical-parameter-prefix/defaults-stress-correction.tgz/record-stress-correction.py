from pathlib import Path
import json,shutil
root=Path('.git/agent-notes/review-20261031/canonical-parameter-prefix-r32')
p=root/'delivery-ci-in-progress.json';d=json.loads(p.read_text(encoding='utf-8'));assert d['status']=='completed' and d['conclusion']=='failure'
(root/'delivery-ci-failed.json').write_text(json.dumps(d,indent=2)+'\n',encoding='utf-8',newline='\n')
shutil.copyfile('tests/Lokad.Lython.PublicApi.Tests/FunctionDefaultsAccountingScenarioTests.cs',root/'defaults-stress-before.cs.txt')
p=Path('PLAN.md');s=p.read_text(encoding='utf-8').replace('platform/Stress/installed-package qualification; identity/conclusion not fetched,','platform/Stress/installed-package qualification; terminal stress fixture failure,')
a=s.index('Actual head42643b1b verified');b=s.index('\n## Priority 1',a)
s=s[:a]+'''Actual head42643b1b, terminal failure observed05:08:14Z. Both platforms pass
Release build, ordinary11/10 and installed consumers. Original.NET11 Stress:
405public/3internal pass; one public failure expects20MiB denial for5000discarded
definitions, based on per-function layout charges R31 removed. .NET10 Stress was
not reached; do not claim complete qualification. Logs/terminal receipt cached;
no more status queries of42339537256.

Correction before retry: preserve5000-definition stress scale; replace obsolete
20MiB rejection with20MiB success and6MiB default-storage refusal, keeping retained
function/lambda denial. Fund compilation through the same root; strengthen first
admission attribution and result-cleanup/baseline/reuse assertions. Remove redundant
64MiB success policy case (same scale, weaker bound). Do not restore duplicate
metadata charges, relax timeouts or discard retained-data coverage. Run that focused
scenario on both actual targets, then batch corrected delivery with R33 once ready.
'''+s[b:]
s+='\nDelivery42339537256 is terminal failed, cached05:08:14Z; do not poll it again.\nCorrect stress ownership contract and include R33 in the next delivery batch.\n'
p.write_text(s,encoding='utf-8',newline='\n')
