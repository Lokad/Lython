set -eu
root=/home/lokad/lython-bench-checks/lexical-leaf-preparation-b1309-20261121
trap 'result=$?; printf "%s\n" "$result" > "$root/exit-code.txt"' EXIT
python3 "$root/collect.py"
