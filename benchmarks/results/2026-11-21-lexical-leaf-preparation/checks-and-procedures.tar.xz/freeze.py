from pathlib import Path
import hashlib
import json
import os
import shutil
import subprocess

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
reference = lab.parent / "joint-default-preflight-20261121/frozen/reference"
reference_manifest = json.loads((lab.parent / "joint-default-preflight-20261121/identity.json").read_text(encoding="utf-8"))
candidate_core = repo / ".git/agent-worktrees/lexical-leaf-preparation-20261121/src/Lokad.Lython/bin/Release/net11.0/Lokad.Lython.dll"
parent = lab / "frozen"
sdk = Path.home() / ".dotnet11"
dotnet = sdk / "dotnet.exe"
env = dict(os.environ, DOTNET_ROOT=str(sdk), DOTNET_ROOT_X64=str(sdk), PATH=str(sdk) + os.pathsep + os.environ["PATH"])
python = Path(shutil.which("python.exe")).resolve()
manifest = lab / "representative.json"
protocol = repo / "benchmarks/cpython-worker.py"
worker = "Lokad.Lython.Benchmarks.dll"

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def hashes(directory):
    return {path.name: sha(path) for path in sorted(directory.iterdir()) if path.is_file()}

known = reference_manifest["imageFiles"]["reference"]
assert len(known) == 32 and {name: sha(reference / name) for name in known} == known
images = {}
for role in ("reference", "candidate"):
    folder = parent / role
    folder.mkdir(parents=True)
    for name in known:
        shutil.copyfile(candidate_core if role == "candidate" and name == "Lokad.Lython.dll" else reference / name, folder / name)
    files = hashes(folder)
    assert files == known | ({"Lokad.Lython.dll": sha(candidate_core)} if role == "candidate" else {})
    images[role] = files

for role in images:
    folder = parent / role
    subprocess.run([dotnet, folder / worker, "--compare", "verify", "--catalog", manifest,
                    "--dotnet", dotnet, "--python", python, "--python-worker", protocol,
                    "--out", lab / f"{role}-verify.json"], env=env, check=True)
    assert hashes(folder) == images[role]

identity = {
    "reference": subprocess.check_output(["git", "rev-parse", "4337b7765"], cwd=repo, text=True).strip(),
    "referenceImageSource": reference_manifest["reference"],
    "candidate": subprocess.check_output(["git", "rev-parse", "b8359d01a3f49d2e76f09db6d7d3cae88aff15ca"], cwd=repo, text=True).strip(),
    "catalogSHA256": sha(manifest), "imageFiles": images,
}
(lab / "identity.json").write_text(json.dumps(identity, indent=2) + "\n", encoding="utf-8", newline="\n")
