from pathlib import Path
r=Path(__file__).resolve().parent
s=(r.parent/'returned-loan-bound-r496/finish-delivery.py').read_text(encoding='utf-8')
a=s.index("out=repo/")
verify=s[:a].replace('run=44168196734','run=44173843690').replace('0d2a6ab7a9aac2c3f80e0cd0c3dc670069b07bbc','242ca28437183b41ffa642a8937098b875a8b852')
finish='''out=repo/'benchmarks/results/2026-11-17-returned-loan-cleanup/delivery';out.mkdir(exist_ok=False)
for n in ['terminal.json','qualification.json','inputs.json','inputs.tar.xz','run-logs.zip']:shutil.copyfile(d/n,out/n)
for n in ['cancellation-build.log','cancellation-net11.0.log','cancellation-net10.0.log']:shutil.copyfile(r/n,out/n)
with tarfile.open(out/'procedures.tar.xz','w:xz')as a:
 for n in ['start-delivery.py','poll-delivery.py','prepare-finish.py','finish-delivery.py']:a.add(r/n,arcname=n)
(out/'README.md').write_text("""# Returned-loan cleanup: completed delivery

GREEN [44173843690](https://github.com/Lokad/Lython/actions/runs/44173843690),
committed242ca284. Windows/Ubuntu actual11/10 each4,831internal/18,021public
ordinary,14/406originalstress and installed explicit Release consumers pass.
All16summaries/2,383committed inputs/585production/package steps verified.
No frozen/rebuilt-binary equality inferred. Normal adapter0.4.0; publication held.

Returned private-loan bounds/native final full-scan deletion0d2a6ab7 and independent
continuation/alias/refusal/held-cleanup regressions are qualified. The post-return
cached-key cancellation fixture correction242ca284 changes no production files;
it retains concurrent outcomes and requires a joined cancelled probe with no
mutation/provenance/funding changes. Both corrected originalstress paths pass
each platform/target. Earlier failed44168196734 and original inputs/logs remain
in the [first delivery](../README.md), including the timing-inference limitation.

All585production source inputs at242ca284 match0d2a6ab7; this is source equivalence,
not CI binary equality with frozen8d26963c. The [CPython checkpoint](../../2026-11-17-current-cpython-checkpoint/README.md)
retains that measured source/image. Three adverse shared-runner prototypes remain
outside production. No CPU gain claimed; the broader performance objective remains
active and publication postponed. Terminal/logs cached; no unchanged replay.

[Qualification](qualification.json),[inputs](inputs.tar.xz),[logs](run-logs.zip),
[procedures](procedures.tar.xz).
""",encoding='utf-8',newline='\\n')
for n in contents:
 if n.startswith('src/Lokad.Lython/'):
  before=subprocess.check_output(['git','show','0d2a6ab7:'+n],cwd=repo)
  assert before==contents[n],n
guide=repo/'docs/BENCHMARKS.md';text=guide.read_text(encoding='utf-8-sig')
old="""The measured runtime's [first delivery](../benchmarks/results/2026-11-17-returned-loan-cleanup/README.md)
passed Ubuntu and both platforms' ordinary/package checks but failed a Windows10
stress fixture's post-return cancellation inference. A fixture correction is
committed; complete delivery qualification remains separate from benchmark gates."""
new="""The same production source is [fully qualified at242ca284](../benchmarks/results/2026-11-17-returned-loan-cleanup/delivery/README.md)
on Windows/Ubuntu actual11/10, originalstress and installed Release consumers.
The earlier Windows10 fixture failure and correction remain linked there. This
does not imply binary equality with measured8d26963c or turn diagnostic ratios
into universal performance claims."""
assert old in text;guide.write_text(text.replace(old,new),encoding='utf-8',newline='\\n')
with(repo/'benchmarks/EXPERIMENTS.md').open('a',encoding='utf-8',newline='\\n')as h:
 h.write('\\nR496 corrected [full delivery](results/2026-11-17-returned-loan-cleanup/delivery/README.md) GREEN44173843690 at242ca284: Windows/Ubuntu actual11/10each4,831internal/18,021public ordinary,14/406originalstress/installed Release consumers.16summaries/2,383inputs/585production verified; production source equals0d2a6ab7, no rebuilt-binary equality claim. Failed44168196734/raw conditions retained; post-return cancellation inference replaced with actual cancelled-probe/provenance/no-mutation/funding checks, production unchanged by fixture correction. Benchmark guide retains measured0d/8d source and limitations. No unchanged replay/publication; broader objective active.\\n')
print('Corrected full delivery verified/cached; all585production inputs equal measured0d. Performance objective remains active.')
'''
(r/'finish-delivery.py').write_text(verify+finish,encoding='utf-8',newline='\n')
print('Prepared verifier for corrected exacthead/16summaries/inputs/packages; run only after cachedGREEN.')
