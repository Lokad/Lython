from pathlib import Path
import ast,json

notes=Path(__file__).parent
dispatch=json.loads((notes/'delivery/dispatch.json').read_text(encoding='utf-8'))
source=(notes.parent/'scalar-index-r453/finish-delivery.py').read_text(encoding='utf-8').split('out=repo/')[0]
source=source.replace('43936505308',str(dispatch['run']))
source=source.replace("terminal['headSha'].startswith('be176ed0')", "terminal['headSha']=="+repr(dispatch['head']))
source=source.replace('[14,406,4808,17938]','[14,406,4831,18021]').replace('2370','2383').replace('584','585')
source=source.replace("f'repos/Lokad/Lython/actions/runs/{run}/logs']", "f'repos/Lokad/Lython/actions/runs/{run}/logs','--allow-escape-sequences']")
source=source.replace("repo/'benchmarks/results/2026-11-16-scalar-index-transport/candidate-sources.tar.xz'", "d/'inputs.tar.xz'")
source=source.replace('measuredProductionTextMatchesQualifiedInputs=True','committedProductionMatchesQualifiedInputs=True')
source+='''
out=repo/'benchmarks/results/2026-11-17-returned-loan-cleanup';out.mkdir(exist_ok=False)
for name in ['terminal.json','qualification.json','inputs.json','inputs.tar.xz','run-logs.zip']:
    shutil.copyfile(d/name,out/name)
for name in ['before-build.log','before-fix.log','checks.json','final-trim-build.log',
             'final-trim-net11.0.log','final-trim-net10.0.log']:
    shutil.copyfile(r/name,out/name)
with tarfile.open(out/'focused-procedures.tar.xz','w:xz')as archive:
    for path in sorted(r.rglob('*')):
        if not path.is_file():continue
        relative=path.relative_to(r)
        if 'delivery'in relative.parts or relative.name=='focused-procedures.tar.xz':continue
        archive.add(path,arcname=relative.as_posix())
(out/'README.md').write_text(f"""# Forwarded private-loan cleanup delivery

GREEN [CI{run}](https://github.com/Lokad/Lython/actions/runs/{run}) at
{terminal['headSha'][:8]}. Windows/Ubuntu actual.NET11/10 each pass4,831internal/
18,021public ordinary,14internal/406public originalstress and installed explicit
Release consumers. All16summaries/2,383committed inputs/585production verified.
No rebuilt-binary or performance equality inferred. Publication held.

Directly consumed/forwarded helper calls can return private iteration loans even
without a GetIter in the callee. The old compiler-owned-slot bound omitted those
results, so array-backed cancellation cleanup left their storage charged. The
new regression fails before the correction while native cleanup's full scan
passes. Include call result slots in the existing bound; native cleanup now uses
the same trim invariant and deletes its separate final full scan/proxy. Preserve
alias funding, terminal refusal, cancellation and awaited cleanup. No new owner,
resource policy, tracing or unsafe API.

Actual local11/10 each1,007internal/4,217public focused checks pass, followed by
29affected internal checks each after deleting the trivial cleanup proxy. Eight
public continuation cases preserve partial helper effects, aliases, guest errors,
terminal refusal, cancellation and held real I/O cleanup/budget reuse. The owned
and native cancellation/loan assertions are independent of dispatch selection.
An initial verification launcher targeted the private prototype by mistake; it
was stopped/joined and its results discarded, not counted as production checks.
The original invalid test build switch and binary-fixture snapshot setup failure
remain in the procedures archive. Actual committed inputs compare binary bytes
exactly and normalize only differing UTF-8 text line endings.

The three [shared-runner prototypes](../2026-11-17-completed-instruction-runner/README.md)
remain outside production because their complete-script comparisons were adverse.
This safety fix preserves an independently useful correction found by that work;
it claims no CPU improvement and does not complete the performance objective.
Terminal/logs cached; no unchanged qualification replay. Publication postponed.

[Qualification](qualification.json),[inputs](inputs.tar.xz),[logs](run-logs.zip),
[before-fix failure](before-fix.log),[focused checks](checks.json),[procedures](focused-procedures.tar.xz).
""",encoding='utf-8',newline='\\n')
with(repo/'benchmarks/EXPERIMENTS.md').open('a',encoding='utf-8',newline='\\n')as history:
    history.write(f'\\nR496 [forwarded loan cleanup](results/2026-11-17-returned-loan-cleanup/README.md), committed0d2a6ab7: owned-storage cancellation regression fails before correction/native passes; compiler now bounds returned private call loans and native final full scan/proxy removed. Local11/10each1,007internal/4,217public focused plus29affected internal pass; eight public held-I/O/aliases/refusal/cancellation continuations retained. FullGREEN{run} qualifies both platforms/targets4,831internal/18,021public ordinary,14/406stress and installed Release consumers;16summaries/2,383inputs/585production verified. Three adverse shared-runner prototypes not promoted. No CPU/binary-equality claim; publicationheld/objectiveactive.\\n')
print('Full returned-loan safety qualification verified/cached; performance objective remains active.')
'''
ast.parse(source)
(notes/'finish-delivery.py').write_text(source,encoding='utf-8',newline='\n')
print('Existing full-platform/log/source/package verifier prepared; no status or log API request made.')
