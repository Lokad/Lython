from pathlib import Path
import hashlib,io,json,re,shutil,subprocess,tarfile,zipfile
r=Path(__file__).resolve().parent;repo=Path('D:/code/Lython');d=r/'delivery';run=44168196734
terminal=json.loads((d/'terminal.json').read_text(encoding='utf-8'))
assert terminal['status']=='completed' and terminal['conclusion']=='success' and terminal['headSha']=='0d2a6ab7a9aac2c3f80e0cd0c3dc670069b07bbc'
z=d/'run-logs.zip'
if not z.exists():
 with z.open('wb')as output:p=subprocess.run(['gh','api',f'repos/Lokad/Lython/actions/runs/{run}/logs','--allow-escape-sequences'],stdout=output,stderr=subprocess.PIPE)
 assert p.returncode==0,p.stderr
for job in terminal['jobs']:
 assert job['conclusion']=='success'
 for name in ['Build Release solution','Test Release (.NET 11)','Test Release (.NET 10 checkpoint)','Verify Release package consumer','Test original stress scales']:
  assert next(s for s in job['steps']if s['name']==name)['conclusion']=='success'
pattern=re.compile(r'Passed!\s+-\s+Failed:\s*(\d+).*?\bPassed:\s*([\d,]+).*?\bSkipped:\s*([\d,]+).*?\bTotal:\s*([\d,]+).*?\((net\d+\.\d+)\)');rows=[]
with zipfile.ZipFile(z)as archive:
 roots=[n for n in archive.namelist()if'/'not in n and n.endswith('.txt')];assert len(roots)==2
 for name in roots:
  data=[]
  for m in pattern.finditer(archive.read(name).decode('utf-8-sig')):
   failed,passed,skipped,total=[int(v.replace(',',''))for v in m.groups()[:4]];assert failed==skipped==0 and total==passed;data.append(dict(framework=m[5],passed=passed))
  assert len(data)==8
  for tfm in ['net11.0','net10.0']:assert sorted(x['passed']for x in data if x['framework']==tfm)==[14,406,4831,18021],(name,data)
  rows.append(dict(log=name,summaries=data))
inputs=json.loads((d/'inputs.json').read_text(encoding='utf-8'));assert inputs['head']==terminal['headSha'] and inputs['count']==2383 and inputs['production']==585
specs=[inputs['head']+':'+n for n in inputs['inputs']];raw=subprocess.run(['git','cat-file','--batch'],cwd=repo,input=('\n'.join(specs)+'\n').encode(),stdout=subprocess.PIPE,check=True).stdout;offset=0;contents={}
for spec in specs:
 end=raw.index(b'\n',offset);header=raw[offset:end].decode().split();assert header[1]=='blob';size=int(header[2]);data=raw[end+1:end+1+size];offset=end+2+size;n=spec.split(':',1)[1];assert hashlib.sha256(data).hexdigest()==inputs['inputs'][n];contents[n]=data
assert offset==len(raw)
with tarfile.open(d/'inputs.tar.xz')as archive:
 for n,data in contents.items():
  if n.startswith('src/Lokad.Lython/'):
   frozen=archive.extractfile(n).read()
   if frozen!=data:assert frozen.decode('utf-8-sig').replace('\r\n','\n')==data.decode('utf-8-sig').replace('\r\n','\n'),n
v=dict(run=run,head=terminal['headSha'],conclusion='success',jobs=rows,summaries=16,sourceInputsVerified=2383,production=585,normalAdapterPin='0.4.0',allMeaningfulStepsPassed=True,logsSHA256=hashlib.sha256(z.read_bytes()).hexdigest(),committedProductionMatchesQualifiedInputs=True,binaryEqualityInferred=False,publicationHeld=True)
(d/'qualification.json').write_text(json.dumps(v,indent=2)+'\n',encoding='utf-8')

out=repo/'benchmarks/results/2026-11-17-returned-loan-cleanup';out.mkdir(exist_ok=False)
for name in ['terminal.json','qualification.json','inputs.json','inputs.tar.xz','run-logs.zip']:
    shutil.copyfile(d/name,out/name)
for name in ['before-build.log','before-fix.log','checks.json','final-trim-build.log',
             'final-trim-net11.0.log','final-trim-net10.0.log']:
    shutil.copyfile(r/name,out/name)
with tarfile.open(out/'focused-procedures.tar.xz','w:xz')as archive:
    for path in sorted(r.rglob('*')):
        if not path.is_file():continue
        relative=path.relative_to(r)
        if 'delivery'in relative.parts or relative.name=='focused-procedures.tar.xz':continue
        archive.add(path,arcname=relative.as_posix())
(out/'README.md').write_text(f"""# Forwarded private-loan cleanup delivery

GREEN [CI{run}](https://github.com/Lokad/Lython/actions/runs/{run}) at
{terminal['headSha'][:8]}. Windows/Ubuntu actual.NET11/10 each pass4,831internal/
18,021public ordinary,14internal/406public originalstress and installed explicit
Release consumers. All16summaries/2,383committed inputs/585production verified.
No rebuilt-binary or performance equality inferred. Publication held.

Directly consumed/forwarded helper calls can return private iteration loans even
without a GetIter in the callee. The old compiler-owned-slot bound omitted those
results, so array-backed cancellation cleanup left their storage charged. The
new regression fails before the correction while native cleanup's full scan
passes. Include call result slots in the existing bound; native cleanup now uses
the same trim invariant and deletes its separate final full scan/proxy. Preserve
alias funding, terminal refusal, cancellation and awaited cleanup. No new owner,
resource policy, tracing or unsafe API.

Actual local11/10 each1,007internal/4,217public focused checks pass, followed by
29affected internal checks each after deleting the trivial cleanup proxy. Eight
public continuation cases preserve partial helper effects, aliases, guest errors,
terminal refusal, cancellation and held real I/O cleanup/budget reuse. The owned
and native cancellation/loan assertions are independent of dispatch selection.
An initial verification launcher targeted the private prototype by mistake; it
was stopped/joined and its results discarded, not counted as production checks.
The original invalid test build switch and binary-fixture snapshot setup failure
remain in the procedures archive. Actual committed inputs compare binary bytes
exactly and normalize only differing UTF-8 text line endings.

The three [shared-runner prototypes](../2026-11-17-completed-instruction-runner/README.md)
remain outside production because their complete-script comparisons were adverse.
This safety fix preserves an independently useful correction found by that work;
it claims no CPU improvement and does not complete the performance objective.
Terminal/logs cached; no unchanged qualification replay. Publication postponed.

[Qualification](qualification.json),[inputs](inputs.tar.xz),[logs](run-logs.zip),
[before-fix failure](before-fix.log),[focused checks](checks.json),[procedures](focused-procedures.tar.xz).
""",encoding='utf-8',newline='\n')
with(repo/'benchmarks/EXPERIMENTS.md').open('a',encoding='utf-8',newline='\n')as history:
    history.write(f'\nR496 [forwarded loan cleanup](results/2026-11-17-returned-loan-cleanup/README.md), committed0d2a6ab7: owned-storage cancellation regression fails before correction/native passes; compiler now bounds returned private call loans and native final full scan/proxy removed. Local11/10each1,007internal/4,217public focused plus29affected internal pass; eight public held-I/O/aliases/refusal/cancellation continuations retained. FullGREEN{run} qualifies both platforms/targets4,831internal/18,021public ordinary,14/406stress and installed Release consumers;16summaries/2,383inputs/585production verified. Three adverse shared-runner prototypes not promoted. No CPU/binary-equality claim; publicationheld/objectiveactive.\n')
print('Full returned-loan safety qualification verified/cached; performance objective remains active.')
