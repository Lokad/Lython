from pathlib import Path
import json,subprocess,zipfile
r=Path(__file__).resolve().parent/'delivery';t=json.loads((r/'terminal.json').read_text(encoding='utf-8'))
assert t['status']=='completed'and t['conclusion']=='failure'and t['headSha']=='0d2a6ab7a9aac2c3f80e0cd0c3dc670069b07bbc'
z=r/'run-logs.zip'
if not z.exists():
    with z.open('wb')as out:p=subprocess.run(['gh','api','repos/Lokad/Lython/actions/runs/44168196734/logs','--allow-escape-sequences'],stdout=out,stderr=subprocess.PIPE)
    assert p.returncode==0,p.stderr
for j in t['jobs']:
    print(j['name'],j['conclusion'],[(s['name'],s['conclusion'])for s in j['steps']if s['conclusion']=='failure'])
with zipfile.ZipFile(z)as a:
    for n in a.namelist():
        if '/'in n or not n.endswith('.txt')or'windows'not in n:continue
        lines=a.read(n).decode('utf-8-sig').splitlines()
        for i,line in enumerate(lines):
            if any(s in line for s in ['[FAIL]','Failed ','Error Message:','##[error]','Exception:','Test Run Failed']):
                print('\n'.join(lines[max(0,i-2):i+14]))
