from pathlib import Path
import hashlib
import json
import shutil
import tarfile

lab = Path(__file__).resolve().parent
old = lab/'comparison/quiet'
retry = lab.with_name(lab.name+'-retry')
quiet = retry/'comparison/quiet'
quiet.mkdir(parents=True)

def read(path):
    return json.loads(path.read_text(encoding='utf-8'))

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def write(path, value):
    path.write_text(value,encoding='utf-8',newline='\n')

def save(path, value):
    write(path,json.dumps(value,indent=2,ensure_ascii=False)+'\n')

initial = read(old/'terminal-status.json')
assert not initial['live'] and not initial['fixtures'] and initial['exitCode']=='1'
assert 'Leave time for cleanup and archival' in initial['journal']
assert initial['receipt']['archivedAndVerifiedUnderLease'] and sha(old/'observations.tar.xz')==initial['receipt']['archiveSHA256']
with tarfile.open(old/'observations.tar.xz') as raw:
    assert len(json.load(raw.extractfile('confirmation/confirmation.json'))['jobs'])==8
for name in ('jobs.json','representative.json','run.sh','cpython-worker.py','summarize.py','candidate-verify.json'):
    shutil.copyfile(old/name,quiet/name)
identity = read(old/'identity.json')
root = 'callable-checkpoint-cpython-b1774c-20261126'
previous_root = read(old/'upload.json')['root']
identity['frozenImage'] = identity['frozenImage'].replace(previous_root,root)
save(quiet/'identity.json',identity)
collector = (old/'collect.py').read_text(encoding='utf-8')
for before,after in [('time.monotonic()-started<245','time.monotonic()-started<400'),
    ('lython-b1774-fixtures','lython-b1774c-fixtures'),
    ('Compare the retained dictionary-update revision against CPython.',identity['purpose'])]:
    assert collector.count(before)==1,before
    collector=collector.replace(before,after)
compile(collector,'collect.py','exec')
write(quiet/'collect.py',collector)
payload=quiet/'stage.tar.gz'
with tarfile.open(payload,'w:gz',compresslevel=6) as package:
    for name in ('identity.json','jobs.json','representative.json','collect.py','run.sh','cpython-worker.py'):
        if name in identity['catalogs']:
            assert sha(quiet/name)==identity['catalogs'][name]['sha256']
        package.add(quiet/name,arcname=name,recursive=False)
save(quiet/'upload.json',dict(root=root,payloadSHA256=sha(payload),payloadBytes=payload.stat().st_size))
launch=(lab/'quiet.py').read_text(encoding='utf-8')
assert launch.count('lython-b1774-callable-checkpoint-cpython-20261126')==1
launch=launch.replace('lython-b1774-callable-checkpoint-cpython-20261126','lython-b1774c-callable-checkpoint-cpython-20261126')
compile(launch,'quiet.py','exec')
write(retry/'quiet.py',launch)
