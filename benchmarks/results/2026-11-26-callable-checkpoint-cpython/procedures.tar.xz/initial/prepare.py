from pathlib import Path
import ast
import hashlib
import json
import os
import shutil
import subprocess
import tarfile

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
quiet = lab/'comparison/quiet'
quiet.mkdir(parents=True)
prior = lab.with_name('converted-update-cpython-20261126')
template = prior/'comparison/quiet'
delivery = lab.with_name('compiled-default-operands-20261126')
donor = delivery/'comparison/quiet'

def read(path):
    return json.loads(path.read_text(encoding='utf-8'))

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def write(path, value):
    path.write_text(value, encoding='utf-8', newline='\n')

def save(path, value):
    write(path, json.dumps(value, indent=2, ensure_ascii=False)+'\n')

head = subprocess.check_output(['git','rev-parse','HEAD'], cwd=repo, text=True).strip()
assert head.startswith('088cf9d37') and not subprocess.check_output(['git','status','--porcelain','--','src'],cwd=repo)
source = read(donor/'identity.json')
patch = subprocess.check_output(['git','diff','--binary',source['sourceRevision'],head,'--','src'],cwd=repo)
assert hashlib.sha256(patch).hexdigest() == source['sourcePatchSHA256'] == sha(delivery/'candidate.patch')
receipt = read(donor/'terminal-status.json')['receipt']
assert all(receipt[k] for k in ('complete','allWorkersJoined','guestFixturesRemoved','quietBeforeAndAfter','archivedAndVerifiedUnderLease'))
assert receipt['archiveSHA256'] == sha(donor/'observations.tar.xz')
image = delivery/'local/candidate'
files = source['imageFiles']['candidate']
assert len(files) == 32 and {p.name:sha(p) for p in image.iterdir()} == files

ordinary = 'diagnostic.generated-ordinary-definitions'
shipment = 'diagnostic.shipment-routing-callbacks'
quantity = 'diagnostic.json-service-quantity-totals'
text = 'diagnostic.text-summary.nonlocal-computed-width.large'
rules = 'scripts.rule-default-closures'
catalog = read(donor/'representative.json')
cases = {case['id']:case for case in catalog['cases']}
for path in (template/'representative.json',lab.with_name('prepared-machine-constants-20261126')/'representative.json'):
    for case in read(path)['cases']:
        if case['id'] in cases:
            assert case['sourceSha256'] == cases[case['id']]['sourceSha256']
            assert case['fixtureSha256'] == cases[case['id']]['fixtureSha256']
        cases[case['id']] = case
catalog['cases'] = [cases[id] for id in (ordinary,shipment,quantity,text,rules)]
save(quiet/'representative.json',catalog)
jobs = [[shipment,'warm-async'],[ordinary,'compile'],[quantity,'warm'],[ordinary,'warm'],[shipment,'warm'],
        [ordinary,'warm-async'],[text,'warm'],[shipment,'compile-run'],[ordinary,'compile-run'],[rules,'warm']]
save(quiet/'jobs.json',jobs)
worker = repo/'benchmarks/cpython-worker.py'
shutil.copyfile(worker,quiet/'cpython-worker.py')
assert sha(worker) == source['cpythonWorkerSHA256']
remote_root = 'callable-checkpoint-cpython-b1774-20261126'
identity = dict(sourceRevision=head,productionSource=head,candidate=head,
    frozenImage=f'/home/lokad/lython-bench-checks/{remote_root}/candidate',
    auxiliaryFiles={name:digest for name,digest in files.items() if name!='Lokad.Lython.dll'},
    imageFiles={'candidate':files},coreSHA256={role:files['Lokad.Lython.dll'] for role in ('candidate','candidate-control')},
    donorArchiveSHA256=receipt['archiveSHA256'],sourcePatchSHA256=source['sourcePatchSHA256'],
    cpythonWorkerSHA256=source['cpythonWorkerSHA256'],expectedCPythonSHA256=source['expectedCPythonSHA256'],
    catalogs={name:{'sha256':sha(quiet/name)} for name in ('representative.json','jobs.json')},
    purpose='Compare the retained compiled-defaults and integer-constant checkpoint against CPython.')
save(quiet/'identity.json',identity)
for name in ('collect.py','summarize.py','run.sh'):
    script = (template/name).read_text(encoding='utf-8')
    script = script.replace('lython-b1764-fixtures','lython-b1774-fixtures').replace('len(jobs) == 5','len(jobs) == 10')
    script = script.replace('len(raw["jobs"])==5','len(raw["jobs"])==10').replace('receipt["warmJobs"]==5','receipt["warmJobs"]==10')
    if name.endswith('.py'):
        tree = ast.parse(script)
        compile(tree,name,'exec')
        if name == 'collect.py':
            keys = {node.slice.value for node in ast.walk(tree) if isinstance(node,ast.Subscript) and isinstance(node.value,ast.Name)
                    and node.value.id=='identity' and isinstance(node.slice,ast.Constant)}
            assert keys <= identity.keys(), sorted(keys-identity.keys())
    write(quiet/name,script)
assert b'\r' not in (quiet/'run.sh').read_bytes()

sdk = Path.home()/'.dotnet11'
dotnet = sdk/'dotnet.exe'
verify = quiet/'candidate-verify.json'
subprocess.run([dotnet,image/'Lokad.Lython.Benchmarks.dll','--compare','verify','--catalog',quiet/'representative.json',
    '--dotnet',dotnet,'--python','C:/Python313/python.exe','--python-worker',worker,'--out',verify],cwd=repo,
    env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk)),check=True,timeout=85)
proof = read(verify)
assert proof['state']=='Completed' and proof['caseCount']==5 and proof['catalogSha256']==identity['catalogs']['representative.json']['sha256']
assert proof['launched']['library']['sha256']==files['Lokad.Lython.dll']
payload = quiet/'stage.tar.gz'
with tarfile.open(payload,'w:gz',compresslevel=6) as package:
    for name in ('identity.json','jobs.json','representative.json','collect.py','run.sh','cpython-worker.py'):
        package.add(quiet/name,arcname=name,recursive=False)
save(quiet/'upload.json',dict(root=remote_root,payloadSHA256=sha(payload),payloadBytes=payload.stat().st_size))
launch = (prior/'quiet.py').read_text(encoding='utf-8')
for old,new in (
    ('lython-b1764-converted-update-cpython-20261126','lython-b1774-callable-checkpoint-cpython-20261126'),
    ("base/'converted-dictionary-update-b1763-20261126'","base/'compiled-default-operands-b1773-20261126'"),
    ("cfg['payloadBytes']+12*1024*1024","cfg['payloadBytes']+6*1024*1024"),
    ('RuntimeMaxSec=248','RuntimeMaxSec=470'),('seconds=205','seconds=405')):
    assert launch.count(old)==1, old
    launch = launch.replace(old,new)
assert 'assert len(jobs) == 10' in (quiet/'collect.py').read_text(encoding='utf-8')
compile(launch,'quiet.py','exec')
write(lab/'quiet.py',launch)
