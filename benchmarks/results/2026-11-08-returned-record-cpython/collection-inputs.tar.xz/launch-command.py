from pathlib import Path
import ast,fcntl,hashlib,io,json,os,shutil,subprocess,sys,tarfile
base=Path('/home/lokad/lython-bench-checks');root=base/'returned-record-cpython-b429-20261108'
reference=base/'sequence-construction-b428-20261108/candidate'
with (base/'comparison-vm.lock').open('a') as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert not root.exists() and not list(Path('/dev/shm').glob('lython-comparison-files-*'))
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record|[o]ps-profile.py'],capture_output=True).returncode==1
 payload=sys.stdin.buffer.read(45599+1)
 assert len(payload)==45599 and hashlib.sha256(payload).hexdigest()=='b1368f8ce359cc0cdc01b9ff34364c3ed89ce4413ae23eb78a5af6b2368cc9c0'
 with tarfile.open(fileobj=io.BytesIO(payload),mode='r:gz') as a:
  required=sum(((m.size+4095)//4096)*4096 for m in a.getmembers())+256*1024*1024
  reclaims=[]
  candidates=[('linear-keyword-b424-20261107','42020660bf64eeb63e32ee1cccea565444f16a22c7fa99104315ea44dbdf28a4',['candidate/Lokad.Lython.dll','current-core.dll']),('linear-keyword-b425-20261107','2e649929304de94c1b4c191d95f7013afc982c752beb506edb4f6bfc7821256d',['candidate/Lokad.Lython.dll','current-core.dll'])]
  for folder,digest,names in candidates:
   if shutil.disk_usage(base).free>required+1024*1024:break
   prior=base/folder;receipt=json.loads((prior/'archive-receipt.json').read_text())
   assert receipt['complete'] and receipt['archiveSHA256']==digest and hashlib.sha256((prior/'observations.tgz').read_bytes()).hexdigest()==digest
   original=json.loads((prior/'identity.json').read_text())['coreSHA256']['candidate']
   targets=[prior/name for name in names]
   if folder.startswith('linear-keyword-b425'):targets.append(base/'csv-call-debt-b426-20261108/current/Lokad.Lython.dll')
   before=shutil.disk_usage(base).free
   for target in targets:
    assert target.is_file() and not target.is_symlink() and target.resolve().is_relative_to(base.resolve()) and hashlib.sha256(target.read_bytes()).hexdigest()==original
   for target in targets:target.unlink()
   reclaims.append(dict(paths=[str(p)for p in targets],archiveSHA256=digest,coreSHA256=original,beforeFreeBytes=before,afterFreeBytes=shutil.disk_usage(base).free,reason='Redundant retired-prototype core links; verified immutable VM archive and independent local archives retained.'))
  assert shutil.disk_usage(base).free>required
  root.mkdir();a.extractall(root,filter='data')
  (root/'reclaimed-prototype-links.json').write_text(json.dumps(reclaims,indent=2)+'\n')
 for role in ['reference','candidate']:shutil.copytree(reference,root/role,copy_function=os.link)
 os.link(root/'candidate/Lokad.Lython.dll',root/'current-core.dll')
 (root/'cpython-worker.py').symlink_to(base/'prepared-call-layout-b384-20261107/cpython-worker.py')
 owned_ram=root/'guest-fixtures';assert not owned_ram.exists();owned_ram.mkdir()
 subprocess.run(['sudo','-n','mount','-t','tmpfs','-o','size=128m,mode=0700,uid=lokad,gid=lokad','lython-b429-fixtures',str(owned_ram)],check=True)
 identity=json.loads((root/'identity.json').read_text())
 for role in ['candidate','reference']:
  assert hashlib.sha256((root/role/'Lokad.Lython.dll').read_bytes()).hexdigest()==identity['coreSHA256'][role]
  for name,digest in identity['auxiliaryFiles'].items():assert hashlib.sha256((root/role/name).read_bytes()).hexdigest()==digest
 for name in ['collect.py','archive-owned.py']:ast.parse((root/name).read_text())
 assert 'assert len(jobs)==5 ' in (root/'collect.py').read_text()
 assert "len(r['jobs'])==5" in (root/'archive-owned.py').read_text()
 subprocess.run(['/bin/sh','-n',str(root/'run.sh')],check=True)
 setup=dict(freeBytes=shutil.disk_usage(base).free,coreAndEveryAuxiliaryVerifiedInBothRoles=True,
  allFiveJobsValidated=True,ownerSeconds=150,stopSeconds=30,marginSeconds=30)
 assert setup['freeBytes']>256*1024*1024
 (root/'setup.json').write_text(json.dumps(setup,indent=2)+'\n');print(json.dumps(setup),flush=True)
subprocess.run(['sudo','-n','systemd-run','--unit=lython-b429-returned-record-cpython-20261108','--property=User=lokad',
 '--property=WorkingDirectory='+str(root),'--property=RuntimeMaxSec=150','--property=TimeoutStopSec=30',
 '--property=KillMode=control-group','/bin/sh',str(root/'run.sh')],check=True)
