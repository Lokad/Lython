from pathlib import Path
import hashlib,json,re,shutil,tarfile

r=Path(__file__).parent;out=Path('benchmarks/results/2026-11-08-returned-record-cpython');out.mkdir(exist_ok=True)
assert not(out/'README.md').exists()
receipt=json.loads((r/'archive-receipt.json').read_text(encoding='utf-8'));assert receipt['complete']and receipt['jobs']==5
assert hashlib.sha256((r/'observations.tgz').read_bytes()).hexdigest()==receipt['archiveSHA256']
identity=json.loads((r/'identity.json').read_text(encoding='utf-8'))
assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==h for p,h in identity['productionSources'].items())
shutil.copyfile('docs/BENCHMARKS.md',out/'prior-BENCHMARKS.md')
for name in ['observations.tgz','archive-receipt.json','terminal-status.json','identity.json','summary.json','focused.json','contract.md']:
 shutil.copyfile(r/name,out/name)
shutil.copyfile(r/'retrieved/reclaimed-prototype-links.json',out/'reclaimed-prototype-links.json')
with tarfile.open(out/'collection-inputs.tar.xz','w:xz')as archive:
 for p in r.iterdir():
  if p.is_file()and p.suffix in ['.py','.json','.log','.md','.patch']:archive.add(p,arcname=p.name)
data=json.loads((r/'summary.json').read_text(encoding='utf-8'));rows={(x['case'],x['lane']):x for x in data['timing']}
def line(row,name,inputs=None):
 low,high=row['timeRangeMilliseconds'];scale=1000 if high<1 else 1;unit='µs'if scale==1000 else'ms'
 a,b=row['ratioRange']
 return f'| {name} | '+(f'{inputs} | 'if inputs else'')+f"{low*scale:.3f}–{high*scale:.3f} {unit} | {row['medianMilliseconds']['CPython']*scale:.3f} {unit} | {a:.2f}–{b:.2f}× | {row['status']}; {row['controlPercent']:.2f}% / {max(row['iqrPercent'].values()):.2f}% |"
record='scripts.csv-validated-records.large'
table='| Complete job | Lython | CPython | Lython / CPython | Status; control / max IQR |\n| --- | ---: | ---: | ---: | --- |\n'
for row in data['timing']:table+=line(row,row['case'].removeprefix('scripts.')+' / '+row['lane'])+'\n'
(out/'README.md').write_text('''# Returned-record CSV external baseline — R73/B429

2026-11-08. Source **68d5bffe**, core **a0aef9ef** matches the recorded production
inventory; informational SourceLink is precommit a34f56b5. Focused 1,729 internal /
597 public checks per actual .NET 11/10 passed. Combined full Windows/Ubuntu,
original Stress and installed-core delivery CI42428096630 remains pending. This
measurement does not replace that qualification. Publication postponed.

Only five jobs fill a material gap: maintained CSV validation/helper keyword calls/
early exits/tuple results/aggregation/report, separately compiled, warm and compiled
plus executed once. Current ordinary CSV/text warm controls complete the set.
**5,120 records / 68,625 input bytes**, complete independently specified stdout/file
goldens checked on every invocation. This is the same script used for R69–R72,
not a microkernel. Existing broader R67 rows stay valid for their named source;
[prior guide](prior-BENCHMARKS.md) preserves the full source824fc6bb tables.

**Five jobs complete in 107.441 seconds**. CPython3.13.16, normal GIL/GC/no JIT/debug,
GCC13.3 PGO/LTO, isolated `-I -S -X utf8`; .NET11RC3 normal GC/tiering. Same quiet
Azure F4as_v7/Ubuntu24.04.4, four EPYC9V45 vCPUs,16GiB/no swap. Two independent
identical-build Lython processes and one CPython process per job; five-second
warmup per role, seven rotated150ms rounds. No new framework or old full replay.

'''+table+'''
Ratio is elapsed Lython/CPython; greater than one is slower. Ranges span two Lython
process medians, not confidence intervals. Control is their absolute difference /
candidate; IQR is the largest role IQR/median including CPython. Variable labels
the 2.1–2.7% control differences or compilation IQR4.59%; it is uncertainty, not a
design veto or discarded result. New returned-record execution remains about
1.32–1.35× CPython, compile-to-result1.31–1.34×. Ordinary CSV1.16–1.19× is variable;
text1.67–1.68× is diagnostic. Substantial text and call/record costs remain despite
retained allocation/route improvements. These are not additive source-pair gains,
proof that one subsystem causes the gap, or whole-objective completion.

## Included work and limits

Warm reuses the compiled script and includes invocation, mediated RAM-file I/O,
full validation and prior-result cleanup. Compile includes construction/disposal
under shared admission. Compile-to-result includes both plus execution cleanup.
Startup, staging/reset, protocol transport and final cached teardown excluded.
The inherited identity.included field retains its old warm-only campaign caption;
the explicit five job lanes and actual command-v2 Ready boundaries govern this
collection. Raw input is preserved rather than silently edited.

Efficient host overrides and contained capability/path-component checks remain
inside Lython's timed I/O; CPython uses ordinary builtin open and resident imports,
where Lython isolates execution imports. RAM fixtures measure mediated file access,
not physical-storage throughput. All reported execution is synchronous Run.
No startup, RSS/heap, genuinely pending-I/O or embedding-tail claim. Historical
adverse source-pair CPU/text observations are not explained or repaid by these
independent ratios. Original variable/adverse observations remain visible.

All exact source/core/auxiliary/actualReady/reference/runtime/golden/quiet/Closed/
exit/join/empty-fixture gates pass. Every user joins and owned128MiB RAM fixtures
are unmounted before archival verification under lease and independently locally.
Persistent records/workers remain outside RAM. Staging274,800,640B passes256MiB;
the conditional retired-prototype reclaim list is empty (no extra files removed).
150s owner +30s stop +30s margin; no timeout, restart or further terminal query.
B429 is terminal/archived/verified. Only affected final adapter qualification is
deferred; the optional0.4adapter/worker are unchanged and this is no backend claim.

[Summary](summary.json), [exact identities](identity.json), [focused checks](focused.json),
[contract](contract.md), [original raw archive](observations.tgz),
[archive receipt](archive-receipt.json), [collection inputs](collection-inputs.tar.xz).
''',encoding='utf-8')
p=Path('docs/BENCHMARKS.md');s=p.read_text(encoding='utf-8')
# Add a visibly revision-marked row to the lead compile-to-result table.
anchor='| CSV summary/ordinary helper | 4,096 records'
position=s.index(anchor)
s=s[:position]+line(rows[(record,'compile-run')],'CSV validation/returned records†','5,120 records / 68,625 B')+'\n'+s[position:]
old='**2026-11-07; 0.11 development source `824fc6bb`; CPython 3.13.16; .NET 11 RC3.**'
new='''**† rows: 2026-11-08, source `68d5bffe`; other rows: 2026-11-07, source
`824fc6bb`. CPython 3.13.16; .NET 11 RC3.**'''
assert old in s;s=s.replace(old,new)
anchor='Frozen core `15c04e2a`'
s=s.replace(anchor,'''New † rows use frozen core `a0aef9ef`, matching source `68d5bffe` (informational
SourceLink `a34f56b5`). Focused actual .NET 11/10 checks pass; combined full
platform/Stress/installed-package CI42428096630 is pending. The
[five-job targeted collection](../benchmarks/results/2026-11-08-returned-record-cpython/README.md)
fills the returned-record baseline and refreshes two warm controls; it does not
remeasure every older workload or explain previous adverse source pairs.

Frozen core `15c04e2a`''')
before,warm=s.split('## Warm execution, compilation and startup',1)
warm,after=warm.split('Compilation alone includes',1)
for case,name in [('scripts.csv-summary-functions.large','CSV summary/ordinary helper†'),('scripts.text-summary-helpers.large','Text summary/helpers†')]:
 original=next(x for x in warm.splitlines()if x.startswith('| '+name.removesuffix('†')+' |'))
 warm=warm.replace(original,line(rows[(case,'warm')],name))
index=warm.index('| CSV summary/ordinary helper†')
warm=warm[:index]+line(rows[(record,'warm')],'CSV validation/returned records†')+'\n'+warm[index:]
after=after.replace('the shared allowance:\n','the shared allowance:\n',1)
index=after.index('| CSV summary/ordinary helper |')
after=after[:index]+line(rows[(record,'compile')],'CSV validation/returned records†')+'\n'+after[index:]
s=before+'## Warm execution, compilation and startup'+warm+'Compilation alone includes'+after
s=s.replace('The 23-job CPython checkpoint completed in 478.32 seconds.', 'The source824fc6bb 23-job checkpoint completed in478.32seconds; the five-job\nsource68d5bffe update took107.44seconds. Returned-record input includes skip and\nnegative rows; all5,120 are parsed and3,072 accepted.')
s=s.replace('these tables describe source824fc6bb.', 'table revisions are marked above; they do not all describe HEAD.')
p.write_text(s,encoding='utf-8')
receipt['collectionInputsSHA256']=hashlib.sha256((out/'collection-inputs.tar.xz').read_bytes()).hexdigest()
(out/'archive-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8')
# Preserve old-source terminal delivery without attributing it to later fixes.
p=Path('benchmarks/results/2026-11-08-linear-keyword-calls/README.md')
p.write_text(p.read_text(encoding='utf-8')+'''
Delivery update: sourcef88191f7 passes full CI42426106105 (Windows/Ubuntu Release
actual11/10, original Stress both and installed core consumers). The cached
[terminal receipt](delivery-ci.json) is final. Subsequent readonly transport and
construction changes have their own combined source68d5bffe delivery run; this
old-source green does not qualify those changes.
''',encoding='utf-8')
p=Path('benchmarks/EXPERIMENTS.md');p.write_text(p.read_text(encoding='utf-8')+'''
## Returned-record external baseline at retained checkpoint

[R73/B429](results/2026-11-08-returned-record-cpython/README.md), source68d5bffe/
corea0aef9ef, fivejobs/107.441s: returned-record CSV compile1.07–1.10×, warm
1.32–1.35×, compile-to-result1.31–1.34× CPython3.13.16. Variable control/compile
IQR visible; current ordinary CSV warm1.16–1.19× variable, text1.67–1.68× diagnostic.
All source/Ready/runtime/reference/golden/quiet/join/fixture/archive gates pass.
Guide marks these revisions separately, retaining older valid824fc6bb rows and
all adverse source pairs. Pending full source68d5bffe delivery; f88191f7 alone
is now fully green CI42426106105, cached. No producer/backend/publication or general
CPU-gain claim. Whole-script performance objective and independent redesign remain.
''',encoding='utf-8')
for p in [out/'README.md',Path('docs/BENCHMARKS.md')]:
 for target in re.findall(r'\]\(([^)]+)\)',p.read_text(encoding='utf-8')):
  if '://'not in target and not target.startswith('#'):assert(p.parent/target.split('#',1)[0]).exists(),(p,target)
print('Targeted external baseline archived; authoritative tables show exact per-row revision and remaining CPU gaps, no wholesale replay.')
