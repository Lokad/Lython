from base64 import b64decode
from hashlib import sha256
from pathlib import Path
import json
import subprocess
import tempfile

lab = Path(__file__).resolve().parent
notes = lab.parent
earlier = notes / 'nested-json-layouts-20261127'
read = lambda path: json.loads(path.read_text(encoding='utf-8-sig'))
digest = lambda text: sha256(text.encode('utf-8')).hexdigest()
base = read(notes / 'annotation-demand-r38/b389/representative.json')
original = next(row for row in base['cases'] if row['id'] == 'scripts.regex-capture-summary.large')
fixture = json.loads(original['fixtureJson'])
assert set(fixture['inputFiles']) == {'input.txt'} and not fixture['outputFiles']
payload = b64decode(fixture['inputFiles']['input.txt'])
subject = payload.decode('utf-8')
assert len(subject.splitlines()) == original['size'] == 1024
control_catalog = read(earlier / 'representative.json')
control = next(row for row in control_catalog['cases'] if row['id'] == 'diagnostic.shipment-file-fed-map')
source = r"""import re
with open('input.txt', encoding='utf-8') as source:
    text = source.read()
pattern = re.compile(r'(?m)^[^\t\r\n]+\tCOUNT\tready$')
rows = 0
positions = 0
for match in pattern.finditer(text):
    rows += 1
    positions += match.end()
print(rows, positions)
"""
rows = []
with tempfile.TemporaryDirectory(prefix='lython-group-zero-oracle-') as temp:
    path = Path(temp)
    (path / 'input.txt').write_bytes(payload)
    for name, expression in (('diagnostic.regex-extract-whole', '[0-9]+'),
                             ('diagnostic.regex-extract-captured', '(?P<count>[0-9]+)')):
        script = source.replace('COUNT', expression)
        expected = subprocess.run(['C:/Python313/python.exe', '-X', 'utf8', '-I', '-S', '-c', script],
                                  cwd=path, check=True, capture_output=True, encoding='utf-8').stdout
        assert set(p.name for p in path.iterdir()) == {'input.txt'}
        rows.append(original | dict(id=name, source=script, expectedOutput=expected,
                                    sourceUtf8Bytes=len(script.encode('utf-8')),
                                    expectedOutputUtf8Bytes=len(expected.encode('utf-8')),
                                    sourceSha256=digest(script), expectedOutputSha256=digest(expected)))
assert rows[0]['expectedOutput'] == rows[1]['expectedOutput']
def write(name, data):
    (lab / name).write_text(json.dumps(data, ensure_ascii=False, indent=2) + '\n', encoding='utf-8', newline='\n')
write('representative.json', control_catalog | {'cases': [*rows, control]})
write('fixture-census.json', dict(records=original['size'], bytes=len(payload),
                                matches=int(rows[0]['expectedOutput'].split()[0])))
def emit(name, text):
    (lab / name).write_text(text, encoding='utf-8', newline='\n')
prep = (earlier / 'prepare.py').read_text(encoding='utf-8')
for before, after in (
    ("image_base=lab.with_name('converted-entry-20261127')/'local'", "image_base=lab.with_name('nested-json-layouts-20261127')/'local'"),
    ("assert head.startswith('f48ab7583')", "assert head.startswith('3cb9a1240')"),
    ("assert pin['sourceRevision'].startswith('7bc13cd06')", "assert pin['sourceRevision'].startswith('f48ab7583')"),
    ("document='diagnostic.nested-json-document'\nlines='diagnostic.nested-json-lines'\nflat='scripts.json-summary-helpers.large'",
     "whole='diagnostic.regex-extract-whole'\ncaptured='diagnostic.regex-extract-captured'"),
    ("{file_fed,document,lines,flat}", "{file_fed,whole,captured}"),
    ("lython-nested-json-layouts-fixture-", "lython-inline-whole-regex-match-fixture-"),
    ("[[flat,'warm-async'],[document,'warm'],[file_fed,'warm-async'],[lines,'warm-async']]",
     "[[file_fed,'warm-async'],[whole,'warm'],[captured,'warm'],[whole,'warm-async']]"),
    ("['git','rev-parse','f48ab7583']", "['git','rev-parse','3cb9a1240']"),
    ("Keep previous JSON key layouts by container depth. Flat Lines and file-fed map are controls.",
     "Store the sole projected whole-match range in the existing result. Named captures and file-fed map are controls."),
    ("checked['caseCount']==4", "checked['caseCount']==3"),
):
    assert prep.count(before) == 1, before
    prep = prep.replace(before, after)
compile(prep,'prepare.py','exec')
emit('prepare.py', prep)
emit('stage.sh', (earlier / 'stage.sh').read_text(encoding='utf-8').replace('lython-nested-json-layouts-', 'lython-inline-whole-regex-match-'))
emit('summarize.py', (earlier / 'summarize.py').read_text(encoding='utf-8'))
