#!/bin/bash
set -euo pipefail
cd /mnt/d/code/Lython/.git/agent-worktrees/module-native-workspace-20261123
export DOTNET_ROOT="$HOME/.dotnet"
export PATH="$DOTNET_ROOT:$PATH"
export DOTNET_HOST_PATH="$DOTNET_ROOT/dotnet"
lab=/mnt/d/code/Lython/.git/agent-notes/review-20261031/module-native-workspace-20261123
white_filter='Category!=Stress&(FullyQualifiedName~ComposedNative|FullyQualifiedName~Native|FullyQualifiedName~FunctionDefault|FullyQualifiedName~SharedCompilerFact|FullyQualifiedName~Memory)'
public_filter='Category!=Stress&(FullyQualifiedName~CooperativeCancellation|FullyQualifiedName~FunctionDefault|FullyQualifiedName~PreparedFunction|FullyQualifiedName~MemoryBudget|FullyQualifiedName~Frame|FullyQualifiedName~Stack|FullyQualifiedName~AsyncCall)'
dotnet test tests/Lokad.Lython.Tests -c Release -f net10.0 --artifacts-path "$lab/ubuntu" --filter "$white_filter" > "$lab/white-ubuntu.log" 2>&1 || { tail -38 "$lab/white-ubuntu.log"; exit 1; }
dotnet test tests/Lokad.Lython.PublicApi.Tests -c Release -f net10.0 --artifacts-path "$lab/ubuntu" --filter "$public_filter" > "$lab/public-ubuntu.log" 2>&1 || { tail -38 "$lab/public-ubuntu.log"; exit 1; }
awk '/Passed!/{count++;print} END{exit count!=2}' "$lab/white-ubuntu.log" "$lab/public-ubuntu.log"
