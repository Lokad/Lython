#!/bin/bash
set -euo pipefail
cd /mnt/d/code/Lython/.git/agent-worktrees/module-native-workspace-20261123
export DOTNET_ROOT="$HOME/.dotnet"
export PATH="$DOTNET_ROOT:$PATH"
export DOTNET_HOST_PATH="$DOTNET_ROOT/dotnet"
lab=/mnt/d/code/Lython/.git/agent-notes/review-20261031/module-native-workspace-20261123
filter='Category!=Stress&(FullyQualifiedName~NativeWorkStateDispatch|FullyQualifiedName~NativeStorageTransfer|FullyQualifiedName~NativeSliceSuspension|FullyQualifiedName~NativeOperationAdmission|FullyQualifiedName~NativeProtocolDictionaryWrite)'
dotnet test tests/Lokad.Lython.PublicApi.Tests -c Release -f net10.0 --artifacts-path "$lab/ubuntu" --filter "$filter" > "$lab/transfer-ubuntu.log" 2>&1 || { tail -38 "$lab/transfer-ubuntu.log"; exit 1; }
grep 'Passed!' "$lab/transfer-ubuntu.log"
