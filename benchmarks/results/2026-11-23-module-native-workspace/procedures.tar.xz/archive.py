
from pathlib import Path
import gzip
import hashlib
import json
import shutil
import subprocess
import sys
import tarfile

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
comparison=lab/"comparison"
quiet=comparison/"quiet"
out=repo/"benchmarks/results/2026-11-23-module-native-workspace"
decision=sys.argv[1]
retained=sys.argv[2] if len(sys.argv)>2 else None
def read(p):return json.loads(p.read_text(encoding="utf-8-sig"))
sha=lambda b:hashlib.sha256(b).hexdigest()
def save(p,v):p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+"\n",encoding="utf-8",newline="\n")
def git(*args):return subprocess.check_output(["git",*args],cwd=repo)

identity=read(quiet/"identity.json")
assert identity==read(quiet/"retrieved/identity.json")
patch=git("diff","--binary",identity["patchBase"],identity["candidate"],"--","src","tests")
assert sha(patch)==identity["sourcePatchSHA256"] and patch==(comparison/"source.patch").read_bytes()
if retained:
    paths=git("diff","--name-only",identity["patchBase"],identity["candidate"],"--","src","tests").decode().splitlines()
    assert len(paths)==3 and not git("diff","--name-only",identity["candidate"],retained,"--",*paths)
identity.update(outcome=decision,retainedRevision=retained)
receipt=read(quiet/"archive-receipt.json")
assert all(receipt[k] for k in ("complete","allWorkersJoined","guestFixturesRemoved","quietBeforeAndAfter","archivedAndVerifiedUnderLease"))
assert sha((quiet/"observations.tgz").read_bytes())==receipt["archiveSHA256"]
raw=read(quiet/"retrieved/confirmation/confirmation.json")
assert raw["complete"] and receipt["jobs"]==len(raw["jobs"])==8
cases={c["id"]:c for c in read(quiet/"representative.json")["cases"]}
for job in raw["jobs"]:
    assert job["workersJoinedAndFixturesRemoved"] and len(job["samples"])==28
    case=cases[job["case"]]
    for batch in job["samples"]:
        result=batch["response"]
        assert result["status"]=="Completed"
        assert all(result[k]==case[k] for k in ("sourceSha256","fixtureSha256","expectedOutputSha256"))
        for name in ("Output","Files"):
            assert result.get("actual"+name+"Sha256")== (None if job["lane"]=="compile" else case.get("expected"+name+"Sha256"))
summary=read(quiet/"quiet-summary.json")
summary.update(outcome=decision,retentionDecisionPending=False,timedBatches=sum(len(j["samples"])for j in raw["jobs"]))
out.mkdir(exist_ok=True)
save(out/"source.json",identity)
save(out/"summary.json",summary)
save(out/"local-allocation.json",{role:read(comparison/f"{role}-allocation.json") for role in identity["imageFiles"]})
original=lab.parent/"native-storage-fit-20261123"
save(out/"route-shapes.json",{
    "fields": ["caller","callee","availableFromArguments","calleeValueStorage","calleeLiveSlotMaximum",
               "calleePatternStorage","arity","argumentsAtLiveTop","startsInConsumedWindow","afterLastOwnedTemporary",
               "nativeTapeCoversAllInstructions","unpackedReturnCount","hasReceiver","callerOperandDepth","argumentPosition",
               "callerStorageCapacity","useBorrowedModuleSlots_candidateOnly"],
    "reference": read(original/"diagnostic/routes.json"), "candidate": read(lab/"diagnostic/routes.json")})
core="Lokad.Lython.dll"
for role,manifest in identity["imageFiles"].items():
    image=comparison/f"frozen-{role}"
    assert manifest=={name:sha((image/name).read_bytes()) for name in manifest}
    if role=="candidate":(out/f"{role}-core.dll.gz").write_bytes(gzip.compress((image/core).read_bytes(),compresslevel=9,mtime=0))
for name in ("archive-receipt.json","observations.tgz","terminal-status.json"):
    shutil.copyfile(quiet/name,out/name)
with tarfile.open(out/"procedures.tar.xz","w:xz") as bundle:
    names=["measure.py","measure.log","stage.py","quiet-image-inventory.json","count.py","count.log","archive.py",
           "test-ubuntu.sh","test-candidate-probe-ubuntu.sh","test-transfer-ubuntu.sh","probe-ubuntu.log","probe-windows.log",
           "white-ubuntu.log","public-ubuntu.log","public-final-ubuntu.log","transfer-ubuntu.log","white-windows.log",
           "public-windows.log","public-qualified-windows.log","public-final-windows.log","transfer-final-windows.log"]
    names += ["comparison/"+n for n in ("identity.json","source.patch","representative.json","reference-verify.json",
                "candidate-verify.json","reference-allocation.json","candidate-allocation.json","launch.py","summarize.py","jobs.json")]
    names += ["comparison/quiet/"+n for n in ("remote-launch.py","collect.py","archive-owned.py","retrieve.py",
                "run.sh","launch.log","observe-not-before.json","config.json")]
    details=("diagnostic/Program.cs","diagnostic/RouteProbe.csproj","diagnostic/diagnostic.patch",
             "diagnostic/core-build.log","diagnostic/probe-build.log","diagnostic/identity.json","diagnostic/cases.json")
    for name in names+list(details):
        bundle.add(lab/name,arcname=name,recursive=False)
    for name in ("count.py","run.log","initial-wrong-worktree.log",*details):
        bundle.add(original/name,arcname="reference-route/"+name,recursive=False)
