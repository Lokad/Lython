from pathlib import Path
import hashlib,json,os,shutil,subprocess,tarfile

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
tree=repo/".git/agent-worktrees/native-storage-fit-20261123"
out=lab/"diagnostic"
out.mkdir(exist_ok=False)
sdk=Path.home()/".dotnet11"
dotnet=sdk/"dotnet.exe"
env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk),PATH=str(sdk)+os.pathsep+os.environ["PATH"])

def git(*args):
    return subprocess.check_output(["git",*args],cwd=tree)

def run(command,cwd=repo,**kwargs):
    subprocess.run(command,cwd=cwd,env=env,timeout=90,check=True,**kwargs)

def read(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))

def write(path,text):
    path.write_text(text,encoding="utf-8",newline="\n")

def save(path,value):
    write(path,json.dumps(value,ensure_ascii=False,indent=2)+"\n")

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def insert_after(text,anchor,replacement):
    assert text.count(anchor)==1,anchor
    return text.replace(anchor,anchor+replacement,1)

revision=git("rev-parse","HEAD").decode().strip()
target="30d956735ff198d49c0615c98de73df2f10c2e3d"
assert revision.startswith("f892efa70") and not git("status","--porcelain")
assert not git("diff","--name-only",target,"HEAD","--","src","tests")
outer=tree/"src/Lokad.Lython/Runtime/LythonRuntime.Executable.Calls.Invoke.cs"
original={outer:outer.read_bytes()}
try:
    code=outer.read_text(encoding="utf-8")
    code=insert_after(code,"    internal sealed partial class ExecutionContext\n    {\n",
        "        internal static readonly Dictionary<string, int> DiagnosticFrameShapes = new();\n\n")
    code=insert_after(code,"                    var unpackedReturn = PrepareUnpackedCallReturn(ref execution, call, start, out var originalExtent);\n",
        '''
                    if (completePositional && (functionReceiver is not null || !function.CodeObject.HasDirectIntegerReturn))
                    {
                        var caller = execution.Code;
                        var callee = function.CodeObject;
                        var position = start + call.ArgumentOffset - (functionReceiver is null ? 0 : 1);
                        var argsEnd = start + call.ArgumentOffset + call.ArgumentCount;
                        var key = string.Join("|", caller.Name, callee.Name, caller.ValueStorageCapacity - position,
                            callee.ValueStorageCapacity, callee.FirstTemporarySlot + callee.OperandCapacity,
                            callee.PatternStorageCount, call.ArgumentCount, originalExtent == argsEnd,
                            position >= start, caller.LastOwnedTemporarySlot < position,
                            callee.NativePrefixEnd == callee.Instructions.Length,
                            call.UnpackedReturnCount, functionReceiver is not null,
                            caller.OperandCapacity, position, caller.ValueStorageCapacity);
                        DiagnosticFrameShapes[key] = DiagnosticFrameShapes.GetValueOrDefault(key) + 1;
                    }
''')
    write(outer,code)
    (out/"diagnostic.patch").write_bytes(git("diff","--binary","--","src"))
    with (out/"core-build.log").open("w",encoding="utf-8") as log:
        run([dotnet,"build","src/Lokad.Lython/Lokad.Lython.csproj","-c","Release","-f","net11.0",
             "--no-incremental","--artifacts-path",out/"artifacts","--nologo"],cwd=tree,stdout=log,stderr=subprocess.STDOUT)
finally:
    for path,data in original.items():path.write_bytes(data)
assert not git("status","--porcelain")

base=lab.parent/"abstract-state-snapshots-20261123/comparison"
donor=base/"frozen-candidate"
info=read(base/"quiet/identity.json")
manifest=info["imageFiles"]["candidate"]
assert len(manifest)==32 and {name:sha(donor/name) for name in manifest}==manifest
fixtures=lab.parent/"single-owner-function-preflight-20261123/comparison/quiet"
catalog_path=fixtures/"representative.json"
assert sha(catalog_path)==read(fixtures/"identity.json")["catalogs"][catalog_path.name]["sha256"]
catalog=read(catalog_path)
assert len(catalog["cases"])==7
catalog["cases"]=[{**c,"id":c["id"]+(".async" if asynchronous else ""), "runAsync":asynchronous}
                  for c in catalog["cases"] for asynchronous in (False,True)]
case_path=out/"cases.json"
save(case_path,catalog)
image=out/"image"
image.mkdir()
for name in manifest:shutil.copyfile(donor/name,image/name)
shutil.copyfile(out/"artifacts/bin/Lokad.Lython/release_net11.0/Lokad.Lython.dll",image/"Lokad.Lython.dll")
hashes={name:sha(image/name) for name in manifest}
assert [n for n in hashes if hashes[n]!=manifest[n]]==["Lokad.Lython.dll"]

recipe=repo/"benchmarks/results/2026-11-22-native-operand-call-loan/route-procedures.tar.xz"
with tarfile.open(recipe) as recipes:
    cs=recipes.extractfile("Program.cs").read().decode("utf-8-sig")
    project=recipes.extractfile("RouteProbe.csproj").read().decode("utf-8-sig")
start=cs.index("var entries =")
end=cs.index("foreach (var item",start)
cs=cs[:start]+'''var runtime = typeof(LythonEngine).Assembly.GetType("Lokad.Lython.Runtime.LythonRuntime+ExecutionContext", true)!;
var shapes = (Dictionary<string, int>)runtime.GetField("DiagnosticFrameShapes", all)!.GetValue(null)!;
'''+cs[end:]
start=cs.index("        entries.SetValue")
end=cs.index("        script.Dispose();",start)
cs=cs[:start]+'''        shapes.Clear();
        Run();
        rows.Add(new { id = item.GetProperty("id").GetString(), asynchronous,
            shapes = shapes.ToDictionary(pair => pair.Key, pair => pair.Value),
            peakExecutionMemoryBytes, allowanceReturned = true });
'''+cs[end:]
write(out/"Program.cs",cs)
write(out/"RouteProbe.csproj",project)
with (out/"probe-build.log").open("w",encoding="utf-8") as log:
    run([dotnet,"build",out/"RouteProbe.csproj","-c","Release","--no-incremental","--nologo"],stdout=log,stderr=subprocess.STDOUT)
for path in (out/"bin/Release/net11.0").glob("RouteProbe.*"):shutil.copyfile(path,image/path.name)
report=out/"routes.json"
run([dotnet,image/"RouteProbe.dll",image,case_path,report])
assert {n:sha(image/n) for n in hashes}==hashes
save(out/"identity.json",dict(equivalentCoreSource=target,instrumentedBaseRevision=revision,imageHashes=hashes,
                            stagedWorkerHashes=manifest,sourceCatalogSHA256=sha(catalog_path),
                            projectedCatalogSHA256=sha(case_path),instrumentationSHA256=sha(out/"diagnostic.patch")))
for row in read(report)["rows"]:
    print(row["id"],row["shapes"],row["peakExecutionMemoryBytes"],flush=True)
