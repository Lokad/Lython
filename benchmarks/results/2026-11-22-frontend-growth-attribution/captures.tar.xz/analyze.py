from collections import Counter
from pathlib import Path
import json

lab=Path(__file__).resolve().parent
roots=("LythonFrontend.Compile(","LythonEngine.Compile(","ExecutableScript.Compile(","LythonEngine.CompileWith")
def symbol(name):return name.split("(",1)[0].split("!",1)[-1]

def describe(path):
    data=json.loads(path.read_text(encoding="utf-8-sig"))
    names=[row["name"]for row in data["shared"]["frames"]]
    active=0.0
    intervals=0
    function=Counter()
    exclusive=Counter()
    collections=Counter()
    for profile in data["profiles"]:
        assert profile["unit"]=="milliseconds"and profile["type"]=="evented"
        frames=[]
        last=profile["startValue"]
        for event in profile["events"]:
            now=event["at"]
            elapsed=now-last
            if elapsed>0 and frames and any(any(mark in name for mark in roots)for name in frames):
                active+=elapsed
                intervals+=1
                exclusive[symbol(frames[-1])]+=elapsed
                function.update({symbol(name):elapsed for name in set(frames)if "Lokad.Lython.Frontend."in name})
                for i,name in enumerate(frames):
                    if "HashSet" in name and "ConstructFrom" in name:
                        caller=next((symbol(f)for f in reversed(frames[:i])if "Lokad.Lython.Frontend."in f),"unresolved")
                        collections[caller]+=elapsed
            if event["type"]=="O":frames.append(names[event["frame"]])
            else:assert frames.pop()==names[event["frame"]]
            last=now
        assert not frames
    return dict(script=path.parent.name,managedCompileThreadMilliseconds=active,intervals=intervals,
                compilerAncestry=function.most_common(40),exclusive=exclusive.most_common(25),
                hashSetCopyCallers=collections.most_common(12))

rows=[describe(lab/role/"compile.speedscope.json")for role in ("manifest","sparse-validator","postponed-factories")]
(lab/"attribution.json").write_text(json.dumps(dict(rows=rows,comparisonQualified=False),indent=2)+"\n",encoding="utf-8",newline="\n")
for row in rows:
    print(row["script"],round(row["managedCompileThreadMilliseconds"],1),row["intervals"])
    for n,v in row["compilerAncestry"][:17]:print("  ",round(v,1),n)
    print("  copies",row["hashSetCopyCallers"])
