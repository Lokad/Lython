from pathlib import Path

lab=Path(__file__).resolve().parent
prior=lab.parent/'supplied-lexical-call-cpython-20261123'
source=(prior/'prepare.py').read_text(encoding='utf-8')
start=source.index("name='scripts.")
end=source.index('dotnet=Path.home()',start)
source=source[:start]+"""catalog=read(donor/'comparison/representative.json')
postponed,eager,*_=catalog['cases']
assert 'postponed' in postponed['id'] and 'nested-factories' in eager['id']
catalog['cases']=[postponed,eager]
write(quiet/'representative.json',catalog)
write(quiet/'jobs.json',[[postponed['id'],'warm'],[postponed['id'],'compile-run'],
    [postponed['id'],'compile'],[eager['id'],'warm']])
"""+source[end:]
updates=(
    ("donor=lab.parent/'supplied-lexical-call-20261123'","donor=lab.parent/'closed-factory-operand-20261123'"),
    ("tracked='benchmarks/results/2026-11-23-supplied-lexical-call/'","tracked='benchmarks/results/2026-11-23-closed-factory-operand/'"),
    ("run='supplied-lexical-call-cpython-b1527-20261123'","run='closed-factory-cpython-b1530-20261123'"),
    ("base='supplied-operand-window-b1524-20261123'","base='supplied-lexical-call-b1526-20261123'"),
    ("original='supplied-lexical-call-b1526-20261123'","original='closed-factory-operand-b1529-20261123'"),
    ("verification['caseCount']==1","verification['caseCount']==2"),
    ("'len(jobs) == 2'","'len(jobs) == 4'"),("'<127,'","'<220,'"),
    ("""'len(raw["jobs"])==2'""","""'len(raw["jobs"])==4'"""),
    ("""'receipt["warmJobs"]==2'""","""'receipt["warmJobs"]==4'"""),
    ('lython-b1527-fixtures','lython-b1530-fixtures'),
    ('CPython checkpoint for the lexical supplied integer script','CPython checkpoint for retained closed factory operands'),
    ('lython-b1527-supplied-lexical-call-20261123','lython-b1530-closed-factory-20261123'),
    ('.+b1527-','.+b1530-'),('lython-b1527-stage-','lython-b1530-stage-'),
    ('A 40 MiB','A 32 MiB'),('40 * 1024 * 1024','32 * 1024 * 1024'),
    ('RuntimeMaxSec=155','RuntimeMaxSec=260'),('seconds=109','seconds=206'),
)
for a,b in updates:
    assert source.count(a)==1,a
    source=source.replace(a,b)
target=lab/'prepare.py'
compile(source,str(target),'exec')
target.write_text(source,encoding='utf-8',newline='\n')
