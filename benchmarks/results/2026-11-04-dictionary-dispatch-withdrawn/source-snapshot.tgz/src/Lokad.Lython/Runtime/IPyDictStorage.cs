namespace Lokad.Lython.Runtime;

// Raw storage for live namespace/environment bridges. Ordinary dictionaries
// own their table directly and expose typed raw methods to those bridges.
internal interface IPyDictStorage : IEnumerable<KeyValuePair<object, object>>
{
    int Count { get; }

    IEnumerable<object> Keys { get; }

    IEnumerable<object> Values { get; }

    object GetRequired(object key);

    bool TryGetValue(object key, [MaybeNullWhen(false)] out object value);

    bool ContainsKey(object key);

    bool TrySetExisting(object key, object value);

    void AddNew(object key, object value);

    bool Remove(object key);

    void Clear();

    // Raw storage traversal is separate from Python mutation-checked iteration.
    IEnumerable<KeyValuePair<object, object>> Entries { get; }

    long CommittedBytes { get; }

}
