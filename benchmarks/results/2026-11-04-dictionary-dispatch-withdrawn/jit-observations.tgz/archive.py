from pathlib import Path
import subprocess,json,tarfile,hashlib,fcntl
root=Path('/home/lokad/lython-bench-checks/dictionary-dispatch-b222-jit-20261104')
status=subprocess.check_output(['systemctl','show','lython-b222-jit-shape-r1-20261104','--property=MainPID,ActiveState,Result'],text=True)
assert 'MainPID=0' in status and 'Result=success' in status and 'ActiveState=inactive' in status,status
(root/'final-service-status.txt').write_text(status,encoding='utf-8')
for n in ['before','after']:assert json.loads((root/f'machine-{n}.json').read_text(encoding='utf-8'))['gate']['quiet']
for label in ['baseline','candidate']:
 r=json.loads((root/'diagnostic'/label/'record.json').read_text(encoding='utf-8'))
 assert r['exitCode']==0 and r['warmupSeconds']>=6 and r['verificationBefore']['status']=='Equivalent' and r['verificationAfter']['status']=='Equivalent'
for unit,file in [('lython-b222-jit-shape-20261104','initial-journal.txt'),('lython-b222-jit-shape-r1-20261104','final-journal.txt')]:
 (root/file).write_text(subprocess.check_output(['journalctl','-u',unit,'--no-pager'],text=True),encoding='utf-8')
with open(root.parent/'comparison-vm.lock','w') as lock:
 fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert not list(Path('/dev/shm').glob('lython-comparison-files-*'))
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[c]omplete-jobs.dll'],capture_output=True).returncode==1
 with tarfile.open(root/'jit-observations.tgz','w:gz') as t:
  for f in root.iterdir():
   if f.name in ['candidate','baseline','jit-observations.tgz']:continue
   if f.is_file():t.add(f,arcname=f.name)
   elif f.is_dir():t.add(f,arcname=f.name)
print(hashlib.sha256((root/'jit-observations.tgz').read_bytes()).hexdigest())
