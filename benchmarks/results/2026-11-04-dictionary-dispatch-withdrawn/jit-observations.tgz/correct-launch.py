from pathlib import Path
import subprocess,shutil
root=Path('/home/lokad/lython-bench-checks/dictionary-dispatch-b222-jit-20261104')
status=subprocess.check_output(['systemctl','show','lython-b222-jit-shape-20261104','--property=MainPID,ActiveState,Result'],text=True)
assert 'MainPID=0' in status and 'ActiveState=failed' in status and 'Result=exit-code' in status,status
(root/'initial-service-status.txt').write_text(status,encoding='utf-8')
(root/'diagnostic').rename(root/'initial-override-gate')
shutil.copyfile(root/'profile.py',root/'initial-profile.py')
shutil.copyfile(root/'corrected-profile.py',root/'profile.py')
subprocess.run(['sudo','-n','systemd-run','--unit=lython-b222-jit-shape-r1-20261104','--property=User=lokad','--property=WorkingDirectory='+str(root),'--property=RuntimeMaxSec=90','--property=TimeoutStopSec=15','--property=KillMode=control-group','/bin/sh',str(root/'collect.sh')],check=True)
