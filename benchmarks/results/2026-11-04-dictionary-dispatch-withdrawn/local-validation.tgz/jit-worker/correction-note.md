Initial VM diagnostic failed its ordinary no-override gate before warmup because
the intended disassembly flags are reported as <present>. Preserve original script,
ready identity, Tier0 dump, failed unit and joined worker exit. Correct only the
allowlist to exactly those3 intended JIT flags; GC/tiering overrides still refused.
Use a new owned unit after verified terminal failure, same bits/source/cases/limits.
Fix inherited collector label to JIT-only. No benchmark rerun or performance claim.
One attempted inline-shell inspection had a quoting SyntaxError and executed no
measurement; copied the raw record directly instead. All original conditions kept.
