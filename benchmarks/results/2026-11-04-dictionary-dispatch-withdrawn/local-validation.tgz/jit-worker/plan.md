# Bounded JIT shape inspection

Initial Windows one-shot diagnostic produced Tier0 only, so it cannot establish
optimized call overhead or VM CPU causality. Preserve it. One bounded correction:
actual VM baseline9588b3c8/candidatea6adcfe9 workers, unchanged complete text script,
6seconds guest warmup each/2seconds settle,16final checked jobs, normal GC/tiering.
Only JitDisasm/assemblies/stdoutfile diagnostic flags, no forced tiering/PGO changes.
Existing worker/protocol/golden/hash/quiet/cleanup checks;90seconds owned limit.
No performance sampling, ratios, collector, production instrumentation or unsafe code.
Stop with optimized call-shape evidence sufficient to justify one source refinement,
or withdraw the slower dispatch deletion. No blind attribute series or unchanged
retiming. Corrected live-view rollback remains independently required either way.
