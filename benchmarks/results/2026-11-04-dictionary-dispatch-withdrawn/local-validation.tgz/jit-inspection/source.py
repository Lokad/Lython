def words_from_line(line:str)->list:
 return line.lower().split()
counts={}
total=0
for unused in range(20000):
 for word in words_from_line("Alpha beta café alpha beta"):
  counts[word]=counts.get(word,0)+1
  total+=1
print(total)
