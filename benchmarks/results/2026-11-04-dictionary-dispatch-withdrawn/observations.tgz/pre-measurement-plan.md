# Direct dictionary storage dispatch source pair

Before capture,2026-11-04. Baselineeff471b3/frozen9588b3c8; candidate identified by
candidate-identity.json/exact7file snapshot. Full baseline41896187873 ongoing, both
OS actual11/10 ordinary and installed consumers pass/originalStress running; do not
claim new prototype full qualification. Nonincremental Release33.11seconds,
0warnings/errors;768internal/2258public per actual11/10 pass. No public API change.

Ordinary PyDict no longer implements/calls itself through IPyDictStorage. Typed raw
methods and optional real view bridge remain. Namespace extras concrete; obsolete
view SetItem/EnsureCapacity/ReleaseCommittedBytes contracts removed, invalid live
refund rejection centralized. Native table/capacity/funding/protocol semantics
unchanged. No wrapper/union/owner/backend/special opcode or arithmetic policy.

Ten complete scripts: CSV/text/JSON/report/config, warm Run/awaited RunAsync.
Existing B221 driver, corrected free-text metadata before freeze; same source/
fixtures/goldens,3images/2oldroles,6secguestwarmup/image,alternating preparation,
2secsettle/9rotated200ms batches. Owned360s limit based on8cases222s. NormalGC/
tiering/quiet gates/exact core+aux+CoreLib+hash witness/CPython complete goldens,
ownerbaseline/finalzero/fixtures/users joined. Process allocations/admitted peaks
separate. Compilation unchanged/excluded, no external CPython performance refresh.

Actual invocation/mediatedRAMIO/fullchecks/resultcleanup included, staging/reset/
startup/finalcached teardown excluded and joined afterward. Async IO completes;
real suspension/refusal/reentry/lifetimes are separate focused checks. No predicted
speedup or percentage veto. Preserve all adverse/control data; bounded refinement
or confirmation only with concrete evidence. Decide simplification/elapsed/debt,
finish/remove self machinery or restore, qualify retained changes at next boundary.
