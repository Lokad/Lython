from pathlib import Path
import datetime,json,shutil,subprocess,sys
root=Path(__file__).parent;old=root.parent/'delivery-comparison-b380'
bound=json.loads((root/'observe-not-before.json').read_text(encoding='utf-8'))
assert datetime.datetime.now(datetime.timezone.utc)>=datetime.datetime.fromisoformat(bound['doNotObserveBeforeUTC'])
t=(old/'retrieve.py').read_text(encoding='utf-8').replace('b380','b388')
(root/'retrieve.py').write_text(t,encoding='utf-8',newline='\n')
subprocess.run([sys.executable,'-X','utf8',str(root/'retrieve.py')],check=True)
shutil.copyfile(root/'retrieved/representative.json',root/'representative.json')
shutil.copyfile(old/'summarize.py',root/'summarize.py')
subprocess.run([sys.executable,'-X','utf8',str(root/'summarize.py')],check=True)
