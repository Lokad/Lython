from pathlib import Path
import ast,datetime,hashlib,json,re,shlex,shutil,subprocess,tarfile
root=Path(__file__).parent;old=root.parent/'delivery-comparison-b380';recent=root.parent/'canonical-formatted-instructions-r35/b387'
remote='/home/lokad/lython-bench-checks/delivery-comparison-b388-20261107'
old_remote='/home/lokad/lython-bench-checks/delivery-comparison-b380-20261107'
prior='/home/lokad/lython-bench-checks/canonical-format-instructions-b387-20261107'
head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
assert head=='42101cd5883927a6466f989bdc81fef84a3fd2c2'
assert not subprocess.check_output(['git','diff','--name-only','--','src'],text=True).strip()
identity=json.loads((recent/'identity.json').read_text(encoding='utf-8'))
for name,digest in identity['modifiedSourceSHA256'].items():assert hashlib.sha256((Path('src/Lokad.Lython')/name).read_bytes()).hexdigest()==digest
identity.update(sourceRevision=head+'; frozen6ab7367f from identical production source, built before commit with SourceLinkfffbbbab',
 purpose='Representative CPython checkpoint after R30–R35; compile/warm/fresh separated, not causal per-change attribution',
 sourceSHA256={str(p).replace('\\','/'):hashlib.sha256(p.read_bytes()).hexdigest() for p in Path('src/Lokad.Lython').rglob('*.cs') if not {'bin','obj'}.intersection(p.parts)})
identity['coreSHA256']={k:identity['coreSHA256'][k] for k in ['candidate','control']}
identity.pop('referenceSourceRevision',None)
def write(name,value): (root/name).write_text(value,encoding='utf-8',newline='\n')
write('identity.json',json.dumps(identity,indent=2)+'\n')
catalog=json.loads((old/'retrieved/representative.json').read_text(encoding='utf-8'))
assert len(catalog['cases'])==5
overlap={c['id']:c for c in json.loads((recent/'representative.json').read_text(encoding='utf-8'))['cases']}
for case in catalog['cases']:
 if case['id'] in overlap:
  for key in ['sourceSha256','fixtureSha256','expectedOutputSha256','expectedFilesSha256']:
   assert case[key]==overlap[case['id']][key]
for name in ['collect.py','archive-owned.py','run.sh']:
 t=(old/name).read_text(encoding='utf-8').replace(old_remote,remote)
 t=t.replace('Representative CPython checkpoint after R26/R29; compile/warm/fresh separated, not causal per-change attribution',identity['purpose'])
 if name=='collect.py':t=t.replace("time.monotonic()-started < 390, 'Reserve60 seconds for final owned work/cleanup.'", "time.monotonic()-started < 360, 'Reserve60 seconds for final owned work/cleanup.'")
 if name.endswith('.py'):ast.parse(t)
 assert old_remote not in t
 write(name,t)
shutil.copyfile('PLAN.md',root/'pre-measurement-plan.md')
contract='''One existing fifteen-job/five-script CPython3.13.16 comparison, current42101cd5/frozen6ab7367f, identical-current control. .NET11RC3, unchanged frozenb94 worker/host/normal0.4 provider, normal GC/tiering.5s warmup per role/job, seven rotated150ms rounds. Separate compile, warm and compile-to-result boundaries. Warm/fresh include mediated RAM I/O, complete goldens/validation and prior-result cleanup; fresh adds compile/program disposal. Startup/staging/reset/final cached teardown excluded. No subtraction of independent medians, startup/RSS/suspended-I/O/embedding-tail claim or causal compound improvement claim. Source R30–R33 fully qualified; R35 focused203internal/1141public per actual target and independent Python/ownership/suspension checks pass. R35 source pair dynamic report improves10–13%elapsed/~15%allocation, static warm favorable/fresh and text variable, CSV+0.13–2.36%accepted possible debt. This refresh measures the combined retained source; current primary guide stays on B380 until actual results and full delivery qualification. Exact Ready image/reference/hash, all goldens, quiet endpoints, terminal budgets, Closed/joins, fixture cleanup and persistent under-lease archive required.420s owner+30s stop+30s margin: observe after480s, no early service query or restart on observation timeout. Preserve every adverse/missing/failed condition. No new framework, producer qualification or publication.\n'''
write('contract.md',contract)
write('setup-contract.json',json.dumps(dict(image=prior+'/candidate',jobs=15,ownerSeconds=420,
 stopSeconds=30,observeAfterSeconds=480,reason='Meaningful R30–R35 retained delivery checkpoint; refresh primary external baseline on complete existing scripts.'),indent=2)+'\n')
with tarfile.open(root/'payload.tgz','w:gz') as a:
 for name in ['identity.json','pre-measurement-plan.md','setup-contract.json','contract.md','collect.py','archive-owned.py','run.sh']:a.add(root/name,arcname=name)
payload=(root/'payload.tgz').read_bytes()
launch=(old/'launch.py').read_text(encoding='utf-8').replace(old_remote,remote).replace(
 '/home/lokad/lython-bench-checks/completed-helpers-b378-20261107',prior).replace(
 'lython-b380-delivery-comparison-20261107','lython-b388-delivery-comparison-20261107')
launch=re.sub(r'payload=sys.stdin.buffer.read\(\d+\+1\);assert len\(payload\)==\d+ and hashlib.sha256\(payload\).hexdigest\(\)==\x27[0-9a-f]+\x27',
 "payload=sys.stdin.buffer.read("+str(len(payload))+"+1);assert len(payload)=="+str(len(payload))+" and hashlib.sha256(payload).hexdigest()=='"+hashlib.sha256(payload).hexdigest()+"'",launch)
assert str(len(payload))+'+1' in launch
ast.parse(launch);write('launch.py',launch)
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
stage='/home/lokad/lython-bench-checks/b388-launch.py'
code='from pathlib import Path; import sys; p=Path('+repr(stage)+'); assert not p.exists(); p.write_bytes(sys.stdin.buffer.read())'
r=subprocess.run(ssh+['python3 -c '+shlex.quote(code)],input=launch.encode('utf-8'),capture_output=True);assert r.returncode==0,r.stderr
r=subprocess.run(ssh+['python3 '+stage],input=payload,capture_output=True)
(root/'launch.log').write_bytes(r.stdout+r.stderr);print((r.stdout+r.stderr).decode('utf-8'),flush=True)
assert r.returncode==0,(r.stdout+r.stderr).decode('utf-8')
now=datetime.datetime.now(datetime.timezone.utc)
write('observe-not-before.json',json.dumps(dict(acknowledgedUTC=now.isoformat(),doNotObserveBeforeUTC=(now+datetime.timedelta(seconds=480)).isoformat(),
 ownerSeconds=420,stopSeconds=30,marginSeconds=30),indent=2)+'\n')
print('Observe after '+(now+datetime.timedelta(seconds=480)).isoformat(),flush=True)
