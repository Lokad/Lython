# Lokad.Lython 0.11.0

Updated 2026-11-07. Git-ignored; never force-add. Publication/tagging postponed.
Objective: coherent simplification and substantial complete-script performance.
A local experiment/checkpoint does not complete that objective.

## Actual delivery status

- **Fully qualified:** exact2f1f2715, terminal GREEN42342955936/all Windows/Ubuntu
  Release, ordinary actual.NET11/10, original Stress on both and installed-package
  consumers. Includes R30 class facts49d40b00, R31 shared parameter tablesbf279768,
  R32 canonical parameter prefix42643b1b, R33 current-token hashingabebd004 and the
  shared-layout fixture correction2f1f2715. Receipt is committed under
  benchmarks/results/2026-11-07-native-hash-cancellation/delivery-ci.json.
  No further queries/reruns of this terminal run. Earlier R29/R26/R25/R23/R22
  delivery receipts remain historical evidence, not repeated qualification.
- **Committed evidence only:** da53d001 R34 current report cost gate and fffbbbab
  delivery receipt. These do not change production or qualify a later prototype.
- **Committed/focused-qualified; full delivery pending:** R35 `42101cd5` deletes
  formatting's generic prepared detour/four wrappers; native dynamic specs avoid
  contexts. Real protocols promote/await cleanup; transient values stay outside
  the shared prefix.203internal/1,141public per actual target and independent
  Python probes pass. B387/all five gates: dynamic elapsed−10.09–13.19%, warm
  allocation~−15.35%both APIs. Static warm favorable; fresh/text variable; accept
  CSV+0.13–2.36% possible debt. Original B386/source/adverse conditions preserved.
- **Active delivery:**42347124351 requested for exact42101cd5, full platform/
  original Stress/installed-package workflow. Not yet a green receipt; no active
  runtime prototype. Refresh representative CPython at this coherent checkpoint
  while qualification runs, then resume the substantial redesign roadmap.
- **Independent regex compatibility:** exact immutabledev48/sourcef6b2175e passes
  85internal/488public per actual target on the R30 consumer. Normal adapter stays
  nonpackable/pinned0.4; core has no backend dependency. Not current-HEAD, producer
  CPU/safety/release certification. Final affected capabilities remain separate.
- **Historical failures/withdrawals retained:**42339537256 failed one obsolete
  default-layout Stress threshold; corrected delivery is green. Keep5000-definition
  scale,6MiB refusal/20MiB success, same-root compile/result cleanup and reuse.
  R28 owned split windows/mask both withdrawn; independent Unicode tests stay.
  Original controls, adverse observations and setup failures remain archived.

## Established measurements and open debt

| Milestone | Established outcome | Limit / decision |
| --- | --- | --- |
| Shared compiler facts | Correct shared inferred-value traversal removes exponential work; qualified | Preserve callback correction; no warm CPU claim. |
| Native helper returns | Qualified; allocation−19.92/−19.31% | Earlier elapsed gains diagnostic; not transferable to HEAD. |
| Direct UTF8 formatting/storage | Allocation−8.67%; controlled B102 elapsed/CPU−5–8% supports retention | Original adverse15.125ms unexplained/preserved; no unchanged retiming needed. |
| R20/R25 records | Shared keys/independent values and transfer of final CSV rows delivered; R25 allocation−7.31/−6.55%, warm native−7.72–8.04% | Revisits old6–8% bulk rejection through coherent transfer, not automatic promotion. CSV coarse CPU/text controls mixed. |
| R29 completed calls | Synthetic pause/completion removed; qualified. Text warm−4.25–7.61%sync/−7.63–8.64%async vs R26 | Allocation flat; report/CSV uncertainty and earlier possible debt remain, no compound CPU claim. |
| R30 prepared class facts | Synthetic class warm allocation−7.75%; quiet warm−5.83–6.31%, fresh−3.65–5.33% | Compile+1,048B/+0.70–1.30% elapsed. Desktop text adverse not reproduced; cause unresolved. |
| R31 shared parameter layout | Class allocation−10.65%warm/−7.35%fresh; quiet warm−4.33–7.01%, fresh−3.52–4.38% | Compile+1,728B/+0.26–1.40%. Text/CSV current roles4.41/5.02% apart; adverse pairings remain possible debt, not parity. |
| R32 canonical prefix | Compile−32B/ordinary definition, empty generator+152B; warm allocation flat | No R32 CPU claim; preserve actual default/name/closure ownership. |
| R33 native hashing | Current token reaches4096-byte str/bytes scans; cache callers independent; full delivery green | Short primitive allocation flat; desktop clocks establish no CPU gain/parity. |

B380 primary CPython checkpoint measures exact81036f25/frozen32dcf141, before
R30–R33. All15jobs/312s/gates pass. Compile-only44–72µs separate; warm text
1.71–1.75×, CSV1.22×, JSON1.05–1.06×, report1.38–1.42×. Text/report and most fresh
cases remain variable. Includes mediated RAM I/O, complete checks and prior-result
cleanup; excludes startup/staging/reset/final teardown. No subtraction of medians.
docs/BENCHMARKS.md accurately labels measured source, not today's HEAD. Refresh
after a meaningful retained runtime milestone. Startup, truly pending I/O latency,
heap/RSS and embedding tails remain open; do not infer them from warm clocks.

Detailed history/source/image/conditions: benchmarks/EXPERIMENTS.md and immutable
benchmarks/results/. Current guides stay concise in docs/. Preserve slower call-
control/call-arena lessons without their discarded machinery.

## Priority 1 — close R35 delivery / current external baseline

R34/B385 current report:916actual guest samples/4.62sCPU,63unknown leaves. Formatting
routing241inclusive/37self, JSON220inclusive/25self and shared dispatch compete.
Large helper-call totals include useful work, not demonstrated binding dominance.
All identity/golden/quiet/funding/Closed/join/archive gates pass. Initial launcher
self-match refusal/corrected same-payload transport retained. No new timing or
allocation result; no automatic second profile selected.

**Hypothesis/deletion:** route formatted construction/literals/finish/conversion/
fields directly through the existing instruction loop. Remove ApplyOperation's
formatting detour, TryExecuteImmediateFormatting, four obsolete wrapper records
and generic-driver/layout branches. Retain the real immutable field descriptor,
existing renderers, slot publication/retirement and context-on-demand. Native
already-evaluated dynamic specs need no lexical context just to format them.
Actual protocol values promote at the original instruction and await callbacks.
No expression motion, upfront mutable proof, alternate backend or public option.

**Acceptance:** single-field identity; conversion/value/spec/effect/error order;
Unicode scalar width/numeric behavior; real async hooks and awaited cleanup;
original spans/active exception, managed stack/recursion, effective cancellation,
first refusal, retained aliases and funded builder/input borrows. Initial new
white-box cancellation expectation also fails on isolated original07a6530e; it now
accepts only the real token exception or structured cancellation while keeping
no-publication/balance/cleanup assertions. Preserve both original failed logs.

**Decision:** retain the canonical instructions/context savings and existing
lifetime fence. One source-justified refinement was measured; all original B386
images/controls/adverse data remain. B387 does not establish register pressure as
the cause of old text timing. Final static warm−1.57–4.68%, fresh−5.32 to+0.13%
with5.23% current-role spread; text−2.37 to+1.03%; CSV+0.13–2.36% explicitly accepted
possible debt. No broad CPU or compounded debt-repayment claim; no unchanged
third retiming selected. Earlier uncertainty remains, not parity.

**Remaining delivery:**42347124351 on42101cd5 batches Windows/Ubuntu ordinary
actual11/10, original Stress and installed-package consumers. First query only
after the recorded five-minute bound in the private delivery-dispatch receipt;
space later checks by minutes and never query again after terminal observation.
Source42101cd5/frozen6ab7367f/41b68d90 has203internal/1,141public per target,
six independent Python probes on both APIs and complete workload/cancellation/
refusal/retained-alias/awaited-cleanup checks. Keep source/image metadata exact.

Reuse the existing representative CPython worker/catalog at this meaningful
checkpoint, compile/warm/fresh separate with unchanged mediated-I/O/check/cleanup
boundary. One bounded refresh, no new framework; preserve variable/adverse cases
and publish the measured source only after qualification. Keep the previous B380
snapshot immutable. Then continue Priority2, not another isolated-experiment stop.
No publication or tagging.

## Priority 2 — substantial complete-script roadmap

Use complete CSV/text/JSON/report/config/file workloads, including compile-once/
run-once inside a warm host. Select actual removable work/storage from existing
cost/source evidence; no chain of narrow speculative fast paths.

| Boundary | Required design gate / displaced work | Semantic acceptance |
| --- | --- | --- |
| Complete calls/frames | Build on direct operands/native calls/deferred contexts; prove a remaining binding/context/continuation phase is material before replacing it. Delete its old driver/transport; no new caller arena. R34 inclusive call totals alone are insufficient. | Helpers/constructors/actual suspension; defaults/keywords/closures, read and exception order, spans, stack admission, funded borrows. |
| Operand/scalar transport | Boxed counters must be assessed with reads/publication/retirement. Require a hot removable phase; existing single local/operand backing stays. Small-add~3%CPU alone does not justify universal tagged values. | Exact promotion, identity/aliases/hash/projection, checked arithmetic and major storage funding. |
| Per-record construction | R20/R25 already remove row intermediates. Identify another real capacity/copy phase, rather than another key cache. | CSV/JSON/report; header identity/mutation/duplicates/protocols, short/rest rows, independent values, admission reentry, Clear capacity and overlap. |
| Text/storage | Bulk casing/split/file windows and direct output already exist. Find final-representation conversion/transport to remove; do not revive universal windows from allocation shares alone. | Unicode expansion/context, scalar/byte offsets, hash/index/repr, aliases and cancellation. |
| Frontend/setup | R30–R32 share genuine facts. Prove another repeated analysis/retained representation; compile cost separate from warm. | Diagnostics, shared-graph correctness, lexical scoping, cancellation/admission, fresh helper/comprehension/config behavior. |

Source already rules out per-small-add admission, general completed-JSON async
state machines, ordinary per-character casing strings and late mutable global/
subscript native proofs. Captured-header clones serve yielding definitions, not
ordinary helpers. Destination publication already skips its adjacent store and
owns disposal/lifetime fences. Do not recreate delivered work from stale claims.

**Investigation stopping criterion:** use existing evidence first; one bounded
current affected-workload capture only for a specific missing fact. Then select a
source-proved deletion with explicit displaced methods/storage, affected scripts,
semantics and completion milestone, or record the missing proof and move boundary.
No automatic campaign or broad rewrite from aggregate/inclusive samples.

**Experimental policy:** timeout/unstable unchanged control/inconclusive data means
uncertainty, not permanent rejection. Allow bounded confirmation, refinement or
measurement correction when evidence justifies it; do not repeat until favorable.
Size observations for this quiet VM and preserve all adverse/original failed
conditions. Fixed percentages inform decisions, never automatically veto useful
simplification. A temporary setback needs a completion milestone and an explicit
decision on remaining debt. Maintain simplification/allocation/CPU distinctions.

## Independent regex track

Continue the Lython-owned Python/nativeUTF8 contract: byte ranges, scalar positions,
original-subject windows, captures/replacements/errors/cache ownership and current
cooperative cancellation. Build on U04/R23; do not repeat unchanged qualification.
Development producers and adapter-local conversions/bridges support implementation,
contract tests and semantics; producer publication never blocks independent work.

Only affected final adapter qualification waits: DetailedData lacks independent
Prepare working ownership; native names lack enumeration; cursors mix creation/
current token authority. Exactdev48 adds no documented API removing those limits.
Keep conservative preflight/local conversion/qualified CTS bridge where needed.
Qualify released immutable inputs and managed safety separately. No silent
promotion, sibling edits, dialect fallback, private quota or abandoned matching.

## Delivery constraints and working state

AGENTS.md remains authoritative: fully managed/memory-safe, no unsafe/Unsafe/
pointers/PInvoke/native probing. Preserve managed stack/recursion, cancellation,
host-mediated contained paths, cycles, shared coarse admission/preflights/overlap,
retained aliases and actual-user cleanup. First memory refusal is terminal. No
tracing/weak reclamation/forced GC/fuel/quotas/hidden caps/default allowance.
Bounded host-driven streaming; XML depth constraint stays.

Focused Release iteration, no overlapping local builds/tests. Preserve timeouts,
original stress scales and GC-test nonparallel collection. Full platform/Stress/
installed consumers at meaningful boundaries; never re-query terminal CI.

VM lokad@20.166.121.73, key~/.ssh/id_lython-bench.pem. No owned collection running.
B385/B386 are terminal/archived; no more service queries. Keep catalogs/workers/evidence
persistent and RAM traces archived/verified under the lease before removal.
Record owner+stop+margin before observation; never restart after an observation
timeout. Disk nearly full: retire only exact redundant expanded copies after
independent committed backup and current hash/user/link validation; keep evidence.
No active runtime prototype; R35 delivery and the representative refresh are next.
Publication and tagging remain postponed.
