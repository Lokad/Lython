from pathlib import Path
import ast

lab=Path(__file__).resolve().parent
prior=lab.parent/'prepared-binding-diagnostics-r616'
read=lambda p:p.read_text(encoding='utf-8-sig')
write=lambda p,s:p.write_text(s,encoding='utf-8',newline='\n')
s=read(prior/'stage-quiet.py')
s=s.replace('native-format-selectors-r615','prepared-binding-diagnostics-r616')
s=s.replace('R616 one nested binding-header walk and borrowed prepared locals','R619 lexical function qualified names')
s=s.replace('prepared-binding-diagnostics-b1048','lexical-qualified-names-b1049')
s=s.replace('lython-b1048-prepared-binding-diagnostics','lython-b1049-lexical-qualified-names')
s=s.replace('lython-b1048-fixtures','lython-b1049-fixtures')
s=s.replace('Prepared binding diagnostics source pair','Lexical qualified names source pair')
a,b=s.index('        cases ='),s.index('        source=source[:a]')
s=s[:a]+'''        jobs = [
            ('scripts.rule-default-closures','warm'),('scripts.annotated-rule-closures','warm'),
            ('scripts.annotated-rule-closure-report','warm'),('scripts.annotated-rule-closure-report','compile-run'),
            ('scripts.report-forwarding.expanded','compile-run'),('calls.positional.large','warm'),
            ('scripts.config-generated-guards.medium','compile'),('scripts.config-generated-guards.medium','compile-run')]
'''+s[b:]
s=s.replace('"len(jobs)==9","len(jobs)==7"','"len(jobs)==7","len(jobs)==8"').replace('"len(raw[\'jobs\'])==9","len(raw[\'jobs\'])==7"','"len(raw[\'jobs\'])==7","len(raw[\'jobs\'])==8"').replace('"jobs=9,","jobs=7,"','"jobs=7,","jobs=8,"').replace('"[\'jobs\']==9","[\'jobs\']==7"','"[\'jobs\']==7","[\'jobs\']==8"')
s=s.replace('    write(quiet / name, source)', '''    if name == "archive-owned.py":
        source=source.replace("252*1024*1024", str(minimum_headroom))
    write(quiet / name, source)''')
s=s.replace('old = load(previous / "config.json")','''old = load(previous / "config.json")
donor_archive=load(previous/"archive-recovery.json")
assert donor_archive["complete"] and donor_archive["verifiedAfterCollectionUnderIdleLease"]
minimum_headroom = 232 * 1024 * 1024''')
s=s.replace('needed = 242 * 1024 * 1024 + expanded + 524288','needed = minimum_headroom + expanded + 524288')
s=s.replace('retireGroups=selected,','retireGroups=selected, donorArchiveSHA256=donor_archive["archiveSHA256"],')
s=s.replace('launcher = launcher.replace("254*1024*1024", "242*1024*1024")','''launcher = launcher.replace("242*1024*1024", str(minimum_headroom))
start=launcher.index(" original=json.loads")
end=launcher.index("\\n payload=",start)
launcher=launcher[:start]+" assert sha(source/'observations.tgz')==c['donorArchiveSHA256']"+launcher[end:]''')
s=s.replace('"440","355"','"355","412"').replace('"==9","==7"','"==7","==8"')
s=s.replace('four-case, seven-job','six-case, eight-job')
ast.parse(s)
write(lab/'stage-quiet.py',s)
