type Alias[T: (lambda: int)] = lambda: T
def outer():
    class C[T = (lambda: str)]:
        def __f[U: (lambda: int)](self, x: (lambda: str) = (lambda: float)):
            return lambda: x
    return C
C = outer()
f = C._C__f
print(Alias.__value__.__qualname__)
print(Alias.__type_params__[0].__bound__.__qualname__)
print(C.__type_params__[0].__default__.__qualname__)
print(f.__type_params__[0].__bound__.__qualname__)
print(f.__defaults__[0].__qualname__, f.__annotations__['x'].__qualname__)
print(f(C()).__qualname__)
