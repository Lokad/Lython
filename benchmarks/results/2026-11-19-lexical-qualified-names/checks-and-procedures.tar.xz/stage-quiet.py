import ast
import hashlib
import json
from pathlib import Path
import re
import shutil
import tarfile

lab = Path(__file__).resolve().parent
prior = lab.parent / "prepared-binding-diagnostics-r616"
previous = prior / "quiet"
quiet = lab / "quiet"
def read(path):
    return path.read_text(encoding="utf-8-sig")
def load(path):
    return json.loads(read(path))
def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
def write(path, value):
    if path.suffix == ".py":
        ast.parse(value)
    path.write_text(value, encoding="utf-8", newline="\n")
def save(path, value):
    write(path, json.dumps(value, ensure_ascii=False, indent=2) + "\n")

old = load(previous / "config.json")
donor_archive=load(previous/"archive-recovery.json")
assert donor_archive["complete"] and donor_archive["verifiedAfterCollectionUnderIdleLease"]
minimum_headroom = 232 * 1024 * 1024
pair = load(lab / "frozen-identity.json")
catalog = lab / "catalog.json"
images = pair["images"]
source_files = old["identity"]["imageFiles"]["candidate"]
core = "Lokad.Lython.dll"
assert pair["casesSHA256"] == sha(catalog)
for role, files in images.items():
    assert len(files) == 32 and files == source_files | {core: files[core]}
    assert {name: sha(lab / "frozen" / role / name) for name in files} == files
    verified = load(lab / f"{role}-verify.json")
    assert verified["state"] == "Completed" and verified["catalogSha256"] == sha(catalog)

quiet.mkdir(exist_ok=True)
for role in ("candidate",):
    image = quiet / role
    image.mkdir(exist_ok=True)
    shutil.copyfile(lab / "frozen" / role / core, image / core)
shutil.copyfile(catalog, quiet / "representative.json")
identity = dict(sourceRevision=pair["referenceCommit"] + " versus " + pair["candidateCommit"],
    purpose="R619 lexical function qualified names", imageFiles=images,
    catalogSHA256=sha(catalog), normalAdapterPin="0.4.0",
    coreSHA256={label: images[role][core] for role in images for label in (role, role + "-control")})
save(quiet / "identity.json", identity)

root = "/home/lokad/lython-bench-checks/lexical-qualified-names-b1049-20261119"
unit = "lython-b1049-lexical-qualified-names-20261119"
for name in ("collect.py", "archive-owned.py", "run.sh", "retrieve.py"):
    source = read(previous / name).replace(old["root"], root)
    source = source.replace("Native format selectors source pair", "Lexical qualified names source pair")
    if name == "collect.py":
        a,b=source.index("\njobs = "),source.index("\nassert len(jobs)")
        jobs = [
            ('scripts.rule-default-closures','warm'),('scripts.annotated-rule-closures','warm'),
            ('scripts.annotated-rule-closure-report','warm'),('scripts.annotated-rule-closure-report','compile-run'),
            ('scripts.report-forwarding.expanded','compile-run'),('calls.positional.large','warm'),
            ('scripts.config-generated-guards.medium','compile'),('scripts.config-generated-guards.medium','compile-run')]
        source=source[:a]+"\njobs = "+repr(jobs)+source[b:]
    source = source.replace("len(jobs)==7","len(jobs)==8").replace("len(raw['jobs'])==7","len(raw['jobs'])==8").replace("jobs=7,","jobs=8,").replace("['jobs']==7","['jobs']==8")
    if name == "archive-owned.py":
        source=source.replace("252*1024*1024", str(minimum_headroom))
    write(quiet / name, source)
write(lab / "launch-quiet.py", read(prior / "launch-quiet.py").replace(
    "Native format selectors source pair", "Lexical qualified names source pair").replace("355","412"))
write(lab / "summarize-quiet.py", read(prior / "summarize-quiet.py").replace("==7","==8"))
parts = ["collect.py", "archive-owned.py", "run.sh", "identity.json", "representative.json",
         "candidate/" + core]
payload = quiet / "payload.tgz"
with tarfile.open(payload, "w:gz") as archive:
    for part in parts:
        archive.add(quiet / part, arcname=part)
expanded = sum((quiet / part).stat().st_size for part in parts)
needed = minimum_headroom + expanded + 524288
space = load(lab / "quiet-space.json")
available = space["freeBytes"]
selected = []
for proof in sorted(space["replicas"], key=lambda item: -item["bytes"]):
    if available > needed + 49152:
        break
    assert proof["committedBlobVerified"]
    available += proof["bytes"]
    selected.append(proof)
save(lab / "preflight.json", dict(available=available, need=needed, withoutRetirement=space["freeBytes"], selected=selected))
assert available > needed, (available, needed)

config = dict(root=root, unit=unit, source=old["root"], sourceRole="candidate",
              sourceFiles=source_files, sourceCatalogSHA256=old["catalogSHA256"],
              catalogSHA256=sha(catalog), identity=identity, retireGroups=selected, donorArchiveSHA256=donor_archive["archiveSHA256"],
              payloadBytes=payload.stat().st_size, payloadSHA256=sha(payload), unpackedBytes=expanded)
save(quiet / "config.json", config)
launcher = read(previous / "remote-launch.py")
a, b = launcher.index("\nc=") + 1, launcher.index("\nb=Path(")
launcher = launcher[:a] + "c=" + repr(config) + launcher[b:]
launcher = re.sub(r"lython-b[0-9]+-fixtures", "lython-b1049-fixtures", launcher)
launcher = launcher.replace("242*1024*1024", str(minimum_headroom))
start=launcher.index(" original=json.loads")
end=launcher.index("\n payload=",start)
launcher=launcher[:start]+" assert sha(source/'observations.tgz')==c['donorArchiveSHA256']"+launcher[end:]
write(quiet / "remote-launch.py", launcher)
print("Verified both full images and the six-case, eight-job plan. Staging headroom", available - needed, "bytes.")
