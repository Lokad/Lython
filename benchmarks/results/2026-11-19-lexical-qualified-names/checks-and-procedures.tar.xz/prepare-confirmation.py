from pathlib import Path
import ast
p=Path(__file__).resolve().parent
s=(p.parent/'native-format-selectors-r615/stage-confirmation.py').read_text(encoding='utf-8-sig')
s=s.replace('native-format-selectors-confirmation-b1046','lexical-qualified-names-confirmation-b1050').replace('lython-b1046-native-format-selectors-confirmation','lython-b1050-lexical-qualified-names-confirmation')
s=s.replace('lython-b1045-fixtures','lython-b1049-fixtures').replace('lython-b1046-fixtures','lython-b1050-fixtures')
s=s.replace('R615 confirmation of ordinary formatting and f-string controls','R619 confirmation of the rule report and adverse source-pair controls')
s=s.replace("jobs=[('scripts.report-render.large', 'warm'), ('scripts.report-render.format-method.large', 'warm')]",
    "jobs=[('scripts.report-forwarding.expanded','compile-run'),('scripts.annotated-rule-closure-report','warm'),('scripts.annotated-rule-closures','warm')]")
s=s.replace('len(jobs)==7','len(jobs)==8').replace('len(jobs)==2','len(jobs)==3')
s=s.replace("len(raw['jobs'])==7","len(raw['jobs'])==8").replace("len(raw['jobs'])==2","len(raw['jobs'])==3")
s=s.replace('jobs=7,','jobs=8,').replace('jobs=2,','jobs=3,')
s=s.replace('254*1024*1024','232*1024*1024')
s=s.replace('retireGroups=selected,','retireGroups=selected,donorArchiveSHA256=receipt["archiveSHA256"],')
s=s.replace('"355","117"','"412","167"').replace('"==7","==2"','"==8","==3"')
s=s.replace('Two confirmation jobs','Three confirmation jobs')
ast.parse(s)
(p/'stage-confirmation.py').write_text(s,encoding='utf-8',newline='\n')
