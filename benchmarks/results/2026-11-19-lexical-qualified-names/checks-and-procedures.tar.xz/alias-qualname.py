type Top = lambda: 0
def outer():
    type Local = lambda: 0
    return Local.__value__.__qualname__
print(Top.__value__.__qualname__, outer())
