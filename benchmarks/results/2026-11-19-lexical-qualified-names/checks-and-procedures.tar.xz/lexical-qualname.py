def top():
    pass

class Outer:
    class Inner:
        def m(self):
            pass
    alias = top

def make():
    global exported
    def exported():
        pass
    class Local:
        def m(self):
            pass
    return Local

print(Outer.Inner.m.__qualname__)
print(Outer.alias.__qualname__, top.__qualname__)
print(make().m.__qualname__, exported.__qualname__)
