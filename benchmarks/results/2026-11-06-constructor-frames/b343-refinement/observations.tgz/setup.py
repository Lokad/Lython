from pathlib import Path
import hashlib,json,os,shutil
root=Path('/home/lokad/lython-bench-checks/constructor-frames-refinement-b343-20261106')
base=Path('/home/lokad/lython-bench-checks/native-read-checkpoint-b338-20261106/candidate')
for label in ['candidate','reference']:
    folder=root/label;folder.mkdir()
    for f in base.iterdir():
        if f.name=='Lokad.Lython.pdb':continue
        if f.name in ['Lokad.Lython.Benchmarks.dll','Lokad.Lython.Benchmarks.deps.json','Lokad.Lython.Benchmarks.runtimeconfig.json']:
            os.link(f,folder/f.name)
        else:
            source=((root/'core/Lokad.Lython.dll' if label=='candidate' else Path('/home/lokad/lython-bench-checks/constructor-frames-b342-20261106/baseline/Lokad.Lython-net11.0.dll'))) if f.name=='Lokad.Lython.dll' else f
            (folder/f.name).symlink_to(source.resolve(),target_is_directory=source.is_dir())
i=json.loads((root/'identity.json').read_text())
for label in ['candidate','control','reference']:
    folder=root/('candidate' if label=='control' else label)
    assert hashlib.sha256((folder/'Lokad.Lython.dll').read_bytes()).hexdigest()==i['coreSHA256'][label]
    for name,digest in i['auxiliaryFiles'].items():assert hashlib.sha256((folder/name).read_bytes()).hexdigest()==digest
assert shutil.disk_usage(root).free>24*1024*1024
print(json.dumps(dict(freeBytes=shutil.disk_usage(root).free,coreSHA256=i['coreSHA256'])))
