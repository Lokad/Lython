from pathlib import Path
import gzip
import hashlib
import json
import subprocess
import io
import tarfile

lab=Path(__file__).resolve().parent
read=lambda p: json.loads(p.read_text(encoding='utf-8-sig'))
pairs = [('cpython-dataclass-factories', '2026-11-20-cpython-dataclasses-and-factories', 'candidate', 'measured-core.dll.gz'),
         ('frame-default-storage/quiet', '2026-11-20-frame-default-storage', 'candidate', 'measured-core.dll.gz'),
         ('retained-dispatch-profile', '2026-11-20-retained-dispatch-profile', 'candidate', 'measured-core.dll.gz')]
records=[]
base='/home/lokad/lython-bench-checks'
for folder, evidence, role, image in pairs:
    local=f'benchmarks/results/{evidence}'
    where=read(lab.parent/folder/'config.json')['root']
    assert where.startswith(base+'/')
    commit=subprocess.check_output(['git','log','-1','--format=%H','--',local+'/'+image]).decode().strip()
    def recorded(name):
        return subprocess.check_output(['git','show',f'{commit}:{local}/{name}'])
    core=gzip.decompress(recorded(image))
    digest=hashlib.sha256(core).hexdigest()
    if folder=='retained-dispatch-profile':
        with tarfile.open(fileobj=io.BytesIO(recorded('procedures.tar.xz'))) as archive:
            identity=json.loads(archive.extractfile('identity.json').read())
        assert digest==identity['imageFiles'][role]['Lokad.Lython.dll']
    else:
        summary=json.loads(recorded('summary.json'))
        assert digest==(summary.get('coreSHA256') or summary['cores'][role])
    receipt = json.loads(recorded('archive-recovery.json' if folder == 'borrow-lexical-builder-r625' else 'archive-receipt.json'))
    assert receipt['complete'] and receipt['allWorkersJoined'] and receipt['guestFixturesRemoved']
    assert receipt.get('archivedAndVerifiedUnderLease') or receipt.get('verifiedAfterCollectionUnderIdleLease')
    observations = recorded('observations.tgz')
    assert hashlib.sha256(observations).hexdigest() == receipt['archiveSHA256']
    records.append(dict(bytes=len(core),links=1,paths=[where.removeprefix(base+'/')+'/'+role+'/Lokad.Lython.dll'],
        sha256=digest,committedBlobVerified=True,canonicalCommit=commit,canonicalPath=local+'/'+image))
    if folder=='cpython-dataclass-factories':
        entry='confirmation/confirmation.json'
        with tarfile.open(fileobj=io.BytesIO(observations)) as archive:
            member=archive.getmember(entry)
            assert member.isfile()
            contents=archive.extractfile(member).read()
        assert json.loads(contents)['complete']
        records.append(dict(bytes=len(contents),links=1,paths=[where.removeprefix(base+'/')+'/'+entry],
            sha256=hashlib.sha256(contents).hexdigest(),committedBlobVerified=True,canonicalCommit=commit,
            canonicalPath=local+'/observations.tgz#'+entry,sourceArchive=where.removeprefix(base+'/')+'/observations.tgz',
            sourceArchiveSHA256=receipt['archiveSHA256']))
remote = '''
from pathlib import Path
import fcntl,hashlib,json,os,shutil,stat
root=Path('/home/lokad/lython-bench-checks')
records=CONTENTS
present=[]
with (root/'comparison-vm.lock').open('a') as lease:
    fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
    for record in records:
        path=root/record['paths'][0]
        if not path.exists(): continue
        if 'sourceArchive' in record:
            archive=root/record['sourceArchive']
            assert archive.resolve()==archive and archive.is_relative_to(root)
            assert hashlib.sha256(archive.read_bytes()).hexdigest()==record['sourceArchiveSHA256']
        info=path.lstat()
        if not stat.S_ISREG(info.st_mode) or info.st_uid!=os.getuid(): continue
        assert info.st_size==record['bytes']
        assert hashlib.sha256(path.read_bytes()).hexdigest()==record['sha256']
        aliases=[]
        for directory,_,files in os.walk(root):
            for name in files:
                candidate=Path(directory)/name
                candidate_info=candidate.lstat()
                if (candidate_info.st_dev,candidate_info.st_ino)!=(info.st_dev,info.st_ino): continue
                assert candidate.resolve()==candidate and candidate.is_relative_to(root)
                aliases.append(str(candidate.relative_to(root)))
        if len(aliases)!=info.st_nlink: continue
        assert record['paths'][0] in aliases
        present.append(dict(record,links=len(aliases),paths=sorted(aliases)))
    print(json.dumps(dict(freeBytes=shutil.disk_usage(root).free,replicas=present),indent=2))
'''.replace('CONTENTS',repr(records))
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i',str(Path.home()/'.ssh/id_lython-bench.pem'),'-o','BatchMode=yes',
     '-o','ConnectTimeout=15','lokad@20.166.121.73','python3 -']
result=subprocess.run(ssh,input=remote.encode('utf-8'),capture_output=True,timeout=30,check=True)
data=json.loads(result.stdout)
(lab/'quiet-space.json').write_text(json.dumps(data,indent=2)+'\n',encoding='utf-8',newline='\n')
print(data['freeBytes'], [item['paths'][0] for item in data['replicas']])

