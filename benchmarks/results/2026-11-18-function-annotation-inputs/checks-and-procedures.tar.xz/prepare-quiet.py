from pathlib import Path

lab = Path(__file__).resolve().parent
previous = lab.parent / 'exact-keyword-transport-r579'
old = (previous / 'prepare-quiet.py').read_text(encoding='utf-8')
old = old.replace("previous = lab.parent / 'executable-definition-inputs-r578'", "previous = lab.parent / 'exact-keyword-transport-r579'")
old = old.replace("prior = load(previous / 'quiet-space.json')", "prior = load(lab.parent / 'executable-definition-inputs-r578/quiet-space.json')")
old = old.replace("startswith('c0367d98')", "startswith('84b1a159')")
head = old[:old.index('stage = read(')]
exec(compile(head,str(__file__),'exec'))
stage = (previous / 'stage-quiet.py').read_text(encoding='utf-8')
stage = stage.replace('donor=lab.parent/"executable-definition-inputs-r578"','donor=lab.parent/"exact-keyword-transport-r579"')
stage = stage.replace('2783d3d7f versus exact keyword transport candidate', '03bb07cf5 versus function annotation inputs candidate')
stage = stage.replace('R579 exact keyword transport into final kwargs', 'R581 shared function annotation inputs')
stage = stage.replace('exact-keyword-transport-b1005-20261118', 'function-annotation-inputs-b1007-20261118')
stage = stage.replace('lython-b1005-exact-keyword-transport-20261118', 'lython-b1007-function-annotation-inputs-20261118')
stage = stage.replace('target="scripts.report-forwarding.expanded"', 'target="scripts.annotated-rule-closures"')
stage = stage.replace('("scripts.report-forwarding.mutable-bound","warm")', '("scripts.rule-default-closures","warm")')
stage = stage.replace('"Executable definition inputs source pair","Exact keyword transport source pair"',
                      '"Exact keyword transport source pair","Function annotation inputs source pair"')
stage = stage.replace('lython-b1004-fixtures","lython-b1005-fixtures', 'lython-b1005-fixtures","lython-b1007-fixtures')
stage = stage.replace('"seconds=270","seconds=280"', '"seconds=280","seconds=280"')
stage = stage.replace('"before 270 seconds","before 280 seconds"', '"before 280 seconds","before 280 seconds"')
assert 'b1007' in stage and 'annotated-rule-closures' in stage
compile(stage,'stage-quiet.py','exec')
(lab/'stage-quiet.py').write_text(stage,encoding='utf-8',newline='\n')
