from pathlib import Path
import hashlib
import json

lab = Path(__file__).resolve().parent
previous = lab.parent / 'exact-keyword-transport-r579'
catalog = json.loads((previous / 'catalog.json').read_text(encoding='utf-8'))
base = next(case for case in catalog['cases'] if case['id'] == 'scripts.rule-default-closures')
sha = lambda value: hashlib.sha256(value.encode('utf-8')).hexdigest()
source = '''def compile_rule(seed):
    def evaluate(record: int, /, base: int = seed % 11, *, weight: int = seed % 7 + 1) -> int:
        return (record + base) * weight
    return evaluate

total = 0
for index in range(2048):
    latest = compile_rule(index)
    total += latest(index)
print(total, list(latest.__annotations__))
'''
expected = f"{sum((i+i%11)*(i%7+1) for i in range(2048))} ['base', 'record', 'weight', 'return']\n"
case = dict(base, id='scripts.annotated-rule-closures', source=source,
            sourceUtf8Bytes=len(source.encode('utf-8')), sourceSha256=sha(source), expectedOutput=expected,
            expectedOutputUtf8Bytes=len(expected.encode('utf-8')), expectedOutputSha256=sha(expected))
control_ids = {'scripts.rule-default-closures', 'calls.positional.large'}
catalog['cases'] = [c for c in catalog['cases'] if c['id'] in control_ids]+[case]
assert len(catalog['cases']) == 3
(lab/'catalog.json').write_text(json.dumps(catalog,ensure_ascii=False,indent=2)+'\n', encoding='utf-8',newline='\n')
template = (previous/'verify-pair.py').read_text(encoding='utf-8')
template = template.replace("lab.parent / 'executable-definition-inputs-r578'", "lab.parent / 'exact-keyword-transport-r579'")
template = template.replace("agent-worktrees/exact-keyword-transport-r579", "agent-worktrees/function-annotation-inputs-r581")
template = template.replace("startswith('64fd18de')", "startswith('d97f6f98')")
template = template.replace("referenceCommit='2783d3d7f', candidateBase='2783d3d7f'", "referenceCommit='03bb07cf5', candidateBase='03bb07cf5'")
compile(template,'verify-pair.py','exec')
(lab/'verify-pair.py').write_text(template, encoding='utf-8',newline='\n')
