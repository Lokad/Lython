from pathlib import Path
import hashlib
import json
import subprocess

lab = Path(__file__).resolve().parent
config = lab / 'quiet-space.json'
prior = json.loads(config.read_text(encoding='utf-8'))
proofs = list(prior['replicas'])
for folder, remote in [
    ('post-defaults-attribution','post-defaults-attribution-b1003-20261118'),
    ('direct-defaults-cpython-checkpoint','retained-cpython-b1002-20261118'),
    ('executable-definition-inputs','executable-definition-inputs-b1004-20261118'),
]:
    name = f'benchmarks/results/2026-11-18-{folder}/observations.tgz'
    data = subprocess.check_output(['git','show',f'origin/master:{name}'])
    assert data == Path(name).read_bytes()
    digest = hashlib.sha256(data).hexdigest()
    proofs.append(dict(paths=[remote+'/observations.tgz'], canonical=name,
                       canonicalSHA256=digest, sha256=digest, bytes=len(data), links=1,
                       committedBlobVerified=True, kind='exact archived observations'))
code = r'''
from pathlib import Path
import fcntl, hashlib, json, os, shutil, stat, subprocess
root = Path('/home/lokad/lython-bench-checks').resolve()
assert root == Path('/home/lokad/lython-bench-checks')
proofs = PROOFS
with (root/'comparison-vm.lock').open('a') as lease:
    fcntl.flock(lease, fcntl.LOCK_EX | fcntl.LOCK_NB)
    assert not subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record|[p]ython3.13.*cpython-worker.py'], capture_output=True).stdout
    assert not any(os.path.ismount(p) for p in root.glob('*/guest-fixtures'))
    found = []
    for proof in proofs:
        if not all((root/path).exists() for path in proof['paths']): continue
        identities = set()
        for name in proof['paths']:
            path = root / name
            info = path.lstat()
            assert path.resolve() == path and path.is_relative_to(root) and stat.S_ISREG(info.st_mode)
            assert info.st_uid == os.getuid() and info.st_nlink == proof['links'] and info.st_size == proof['bytes']
            assert hashlib.sha256(path.read_bytes()).hexdigest() == proof['sha256']
            identities.add((info.st_dev, info.st_ino))
        assert len(identities) == 1 and len(proof['paths']) == proof['links']
        found.append(proof)
    print(json.dumps(dict(freeBytes=shutil.disk_usage(root).free, replicas=found)))
'''.replace('PROOFS',repr(proofs))
ssh = ['C:/Windows/System32/OpenSSH/ssh.exe','-i',str(Path.home()/'.ssh/id_lython-bench.pem'),
       '-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
result = subprocess.check_output(ssh+['python3 -'],input=code.encode(),timeout=35)
config.write_bytes(result)
print(f"Verified {len(json.loads(result)['replicas'])} available archival replicas.")
