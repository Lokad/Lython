def define():
    def callback(a: (yield 'positional-only'), /, b: (yield 'positional'),
                 *args: (yield 'starred'), flag: (yield 'keyword-only'),
                 **kwargs: (yield 'double-starred')) -> (yield 'return'):
        return a, b, args, flag, kwargs

    yield list(callback.__annotations__.items())

g = define()
for index in range(6):
    print(g.send(None if index == 0 else index))
print(g.send(6))
