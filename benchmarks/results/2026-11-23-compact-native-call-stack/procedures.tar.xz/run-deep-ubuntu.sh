#!/bin/bash
set -euo pipefail
root=/mnt/d/code/Lython
tree="$root/.git/agent-worktrees/compact-native-call-stack-20261123"
lab="$root/.git/agent-notes/review-20261031/native-stack-initialization-20261123"
export DOTNET_ROOT="$HOME/.dotnet"
export PATH="$DOTNET_ROOT:$PATH"
export DOTNET_HOST_PATH="$DOTNET_ROOT/dotnet"
cd "$tree"
dotnet build tests/Lokad.Lython.WorkerFixture/Lokad.Lython.WorkerFixture.csproj -c Release -f net10.0 --artifacts-path "$lab/stack-latest" > "$lab/stack-fixture-build-ubuntu.log" 2>&1 || { tail -35 "$lab/stack-fixture-build-ubuntu.log"; exit 1; }
cd "$root"
dotnet build src/Lokad.Lython/Lokad.Lython.csproj -c Release -f net10.0 --no-incremental --artifacts-path "$lab/reference-ubuntu" > "$lab/stack-reference-build-ubuntu.log" 2>&1 || { tail -35 "$lab/stack-reference-build-ubuntu.log"; exit 1; }
fixture="$lab/stack-latest/bin/Lokad.Lython.WorkerFixture/release_net10.0"
mkdir -p "$lab/deep-continuation-reference" "$lab/deep-continuation-candidate"
for role in reference candidate; do
  path="$lab/deep-continuation-$role"
  cp "$fixture/"* "$path/"
  if [[ "$role" == reference ]]; then
    cp "$lab/reference-ubuntu/bin/Lokad.Lython/release_net10.0/Lokad.Lython.dll" "$path/Lokad.Lython.dll"
  fi
  sha256sum "$path/Lokad.Lython.dll" "$path/Lokad.Lython.WorkerFixture.dll"
done
set +e
for iteration in 1 2 3 4 5 6; do
  for role in reference candidate; do
    path="$lab/deep-continuation-$role"
    DOTNET_PROCESSOR_COUNT=1 timeout 24s dotnet "$path/Lokad.Lython.WorkerFixture.dll" stack-guard "$path/Lokad.Lython.dll" native-call-continuation > "$lab/$role-deep-$iteration.log" 2>&1
    printf '%s %s exit=%s\n' "$role" "$iteration" "$?"
    cat "$lab/$role-deep-$iteration.log"
  done
done
