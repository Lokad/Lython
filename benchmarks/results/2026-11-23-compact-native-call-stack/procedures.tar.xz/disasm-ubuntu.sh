#!/bin/bash
set -euo pipefail
lab=/mnt/d/code/Lython/.git/agent-notes/review-20261031/native-stack-initialization-20261123
export DOTNET_ROOT="$HOME/.dotnet"
export PATH="$DOTNET_ROOT:$PATH"
export DOTNET_HOST_PATH="$DOTNET_ROOT/dotnet"
cd "$lab/comparison"
for role in reference candidate; do
  image="$PWD/frozen-$role"
  DOTNET_JitDisasm='Lokad.Lython.Runtime.PyExecutableFunction:Start*NativeCall*' DOTNET_JitStdOutFile="$PWD/$role-native-calls-linux.asm"     dotnet "$image/ValidatedAllocation.dll" "$image" "$PWD/representative.json" "$PWD/$role-linux-disasm-verified.json"
done
