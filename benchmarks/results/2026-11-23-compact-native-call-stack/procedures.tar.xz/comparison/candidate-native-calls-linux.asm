; Assembly listing for method Lokad.Lython.Runtime.PyExecutableFunction:StartNativeCall(Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,bool,bool,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,byref,byref):this (Tier0)
; Emitting BLENDED_CODE for x64 + VEX on Unix
; Tier0 code
; rbp based frame
; partially interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 144
       lea      rbp, [rsp+0x90]
       vxorps   xmm8, xmm8, xmm8
       vmovdqu  xmmword ptr [rbp-0x48], xmm8
       xor      eax, eax
       mov      dword ptr [rbp-0x38], eax
       mov      gword ptr [rbp-0x08], rdi
       mov      gword ptr [rbp-0x10], rsi
       mov      bword ptr [rbp-0x20], rdx
       mov      qword ptr [rbp-0x18], rcx
       mov      gword ptr [rbp-0x28], r8
       mov      gword ptr [rbp-0x30], r9
 
G_M000_IG02:                ;; offset=0x0037
       cmp      gword ptr [rbp-0x28], 0
       jne      G_M000_IG07
       mov      rdi, gword ptr [rbp-0x08]
       call     [Lokad.Lython.Runtime.PyFunctionBase:get_CodeObject():Lokad.Lython.Frontend.ExecutableCodeObject:this]
       mov      rdi, rax
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_HasDirectIntegerReturn():bool:this]
       test     eax, eax
       je       G_M000_IG07
       movzx    rax, byte  ptr [rbp+0x20]
       test     eax, eax
       jne      SHORT G_M000_IG03
       mov      rax, bword ptr [rbp+0x40]
       mov      bword ptr [rsp], rax
       mov      rdx, bword ptr [rbp-0x20]
       mov      rcx, qword ptr [rbp-0x18]
       mov      rdi, gword ptr [rbp-0x08]
       mov      rsi, gword ptr [rbp-0x10]
       mov      r8, gword ptr [rbp-0x30]
       mov      r9, gword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.PyExecutableFunction:TryStartPreparedIntegerReturn(Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,byref):bool:this]
       mov      dword ptr [rbp-0x38], eax
       jmp      SHORT G_M000_IG05
 
G_M000_IG03:                ;; offset=0x0092
       mov      eax, dword ptr [rbp-0x18]
       mov      dword ptr [rbp-0x34], eax
       mov      rdi, gword ptr [rbp-0x08]
       call     [Lokad.Lython.Runtime.PyFunctionBase:get_CodeObject():Lokad.Lython.Frontend.ExecutableCodeObject:this]
       mov      rdi, rax
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_FirstTemporarySlot():int:this]
       cmp      eax, dword ptr [rbp-0x34]
       jne      SHORT G_M000_IG04
       mov      rsi, bword ptr [rbp-0x20]
       mov      rdx, qword ptr [rbp-0x18]
       lea      rdi, [rbp-0x48]
       call     [Lokad.Lython.Runtime.LythonRuntime+SlotIntegerOperands:.ctor(System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):this]
       mov      rsi, bword ptr [rbp-0x48]
       mov      rdx, qword ptr [rbp-0x40]
       mov      rdi, gword ptr [rbp-0x08]
       mov      rcx, gword ptr [rbp+0x10]
       mov      r8, bword ptr [rbp+0x40]
       call     [Lokad.Lython.Runtime.PyExecutableFunction:TryStartDirectIntegerReturn[Lokad.Lython.Runtime.LythonRuntime+SlotIntegerOperands](Lokad.Lython.Runtime.LythonRuntime+SlotIntegerOperands,Lokad.Lython.LythonSourceSpan,byref):bool:this]
       mov      dword ptr [rbp-0x38], eax
       jmp      SHORT G_M000_IG05
 
G_M000_IG04:                ;; offset=0x00E3
       xor      eax, eax
       mov      dword ptr [rbp-0x38], eax
 
G_M000_IG05:                ;; offset=0x00E8
       cmp      dword ptr [rbp-0x38], 0
       je       SHORT G_M000_IG07
       mov      rax, bword ptr [rbp+0x38]
       mov      byte  ptr [rax], 0
       mov      rax, bword ptr [rbp+0x48]
       xor      rcx, rcx
       mov      gword ptr [rax], rcx
 
G_M000_IG06:                ;; offset=0x00FE
       add      rsp, 144
       pop      rbp
       ret      
 
G_M000_IG07:                ;; offset=0x0107
       mov      rdi, gword ptr [rbp-0x08]
       call     [Lokad.Lython.Runtime.PyFunctionBase:get_CodeObject():Lokad.Lython.Frontend.ExecutableCodeObject:this]
       mov      rdi, rax
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_ValueStorageCapacity():int:this]
       cmp      eax, 8
       jg       SHORT G_M000_IG09
       mov      rax, gword ptr [rbp+0x10]
       mov      gword ptr [rsp], rax
       movzx    rax, byte  ptr [rbp+0x18]
       mov      dword ptr [rsp+0x08], eax
       movzx    rax, byte  ptr [rbp+0x20]
       mov      dword ptr [rsp+0x10], eax
       lea      rdi, [rsp+0x18]
       lea      rsi, [rbp+0x28]
       mov      rcx, bword ptr [rsi]
       mov      bword ptr [rsp+0x18], rcx
       add      rsi, 8
       add      rdi, 8
       movsq    
       mov      rax, bword ptr [rbp+0x38]
       mov      bword ptr [rsp+0x28], rax
       mov      rax, bword ptr [rbp+0x40]
       mov      bword ptr [rsp+0x30], rax
       mov      rax, bword ptr [rbp+0x48]
       mov      bword ptr [rsp+0x38], rax
       mov      rdx, bword ptr [rbp-0x20]
       mov      rcx, qword ptr [rbp-0x18]
       mov      rdi, gword ptr [rbp-0x08]
       mov      rsi, gword ptr [rbp-0x10]
       mov      r8, gword ptr [rbp-0x28]
       mov      r9, gword ptr [rbp-0x30]
       call     [Lokad.Lython.Runtime.PyExecutableFunction:StartCompactNativeCall(Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,bool,bool,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,byref,byref):this]
       nop      
 
G_M000_IG08:                ;; offset=0x018E
       add      rsp, 144
       pop      rbp
       ret      
 
G_M000_IG09:                ;; offset=0x0197
       mov      rax, gword ptr [rbp+0x10]
       mov      gword ptr [rsp], rax
       movzx    rax, byte  ptr [rbp+0x18]
       mov      dword ptr [rsp+0x08], eax
       movzx    rax, byte  ptr [rbp+0x20]
       mov      dword ptr [rsp+0x10], eax
       lea      rdi, [rsp+0x18]
       lea      rsi, [rbp+0x28]
       mov      rcx, bword ptr [rsi]
       mov      bword ptr [rsp+0x18], rcx
       add      rsi, 8
       add      rdi, 8
       movsq    
       mov      rax, bword ptr [rbp+0x38]
       mov      bword ptr [rsp+0x28], rax
       mov      rax, bword ptr [rbp+0x40]
       mov      bword ptr [rsp+0x30], rax
       mov      rax, bword ptr [rbp+0x48]
       mov      bword ptr [rsp+0x38], rax
       mov      rdx, bword ptr [rbp-0x20]
       mov      rcx, qword ptr [rbp-0x18]
       mov      rdi, gword ptr [rbp-0x08]
       mov      rsi, gword ptr [rbp-0x10]
       mov      r8, gword ptr [rbp-0x28]
       mov      r9, gword ptr [rbp-0x30]
       call     [Lokad.Lython.Runtime.PyExecutableFunction:StartWideNativeCall(Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,bool,bool,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,byref,byref):this]
       nop      
 
G_M000_IG10:                ;; offset=0x0204
       add      rsp, 144
       pop      rbp
       ret      
 
; Total bytes of code 525

; Assembly listing for method Lokad.Lython.Runtime.PyExecutableFunction:StartCompactNativeCall(Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,bool,bool,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,byref,byref):this (Tier0)
; Emitting BLENDED_CODE for x64 + VEX on Unix
; Tier0 code
; rbp based frame
; partially interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 272
       lea      rbp, [rsp+0x110]
       vxorps   xmm8, xmm8, xmm8
       vmovdqu  ymmword ptr [rbp-0xC0], ymm8
       vmovdqu  ymmword ptr [rbp-0xA0], ymm8
       vmovdqu  ymmword ptr [rbp-0x80], ymm8
       vmovdqu  ymmword ptr [rbp-0x60], ymm8
       vmovdqa  xmmword ptr [rbp-0x40], xmm8
       mov      gword ptr [rbp-0x08], rdi
       mov      gword ptr [rbp-0x10], rsi
       mov      bword ptr [rbp-0x20], rdx
       mov      qword ptr [rbp-0x18], rcx
       mov      gword ptr [rbp-0x28], r8
       mov      gword ptr [rbp-0x30], r9
 
G_M000_IG02:                ;; offset=0x004C
       vxorps   ymm0, ymm0, ymm0
       vmovdqu  ymmword ptr [rbp-0xB0], ymm0
       vmovdqu  ymmword ptr [rbp-0x90], ymm0
       vmovdqu  ymmword ptr [rbp-0x70], ymm0
       vmovdqu  ymmword ptr [rbp-0x50], ymm0
       lea      rdi, [rbp-0xB0]
       mov      esi, 8
       call     [<PrivateImplementationDetails>:InlineArrayAsSpan[Lokad.Lython.Runtime.PyExecutableFunction+CompactNativeValues,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot](byref,int):System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]]
       mov      bword ptr [rbp-0xC0], rax
       mov      qword ptr [rbp-0xB8], rdx
       mov      rax, gword ptr [rbp-0x28]
       mov      gword ptr [rsp], rax
       mov      rax, gword ptr [rbp-0x30]
       mov      gword ptr [rsp+0x08], rax
       mov      rax, gword ptr [rbp+0x10]
       mov      gword ptr [rsp+0x10], rax
       movzx    rax, byte  ptr [rbp+0x18]
       mov      dword ptr [rsp+0x18], eax
       movzx    rax, byte  ptr [rbp+0x20]
       mov      dword ptr [rsp+0x20], eax
       lea      rdi, [rsp+0x28]
       lea      rsi, [rbp+0x28]
       mov      rcx, bword ptr [rsi]
       mov      bword ptr [rsp+0x28], rcx
       add      rsi, 8
       add      rdi, 8
       movsq    
       mov      rax, bword ptr [rbp+0x38]
       mov      bword ptr [rsp+0x38], rax
       mov      rax, bword ptr [rbp+0x40]
       mov      bword ptr [rsp+0x40], rax
       mov      rax, bword ptr [rbp+0x48]
       mov      bword ptr [rsp+0x48], rax
       mov      rsi, bword ptr [rbp-0xC0]
       mov      rdx, qword ptr [rbp-0xB8]
       mov      r8, bword ptr [rbp-0x20]
       mov      r9, qword ptr [rbp-0x18]
       mov      rdi, gword ptr [rbp-0x08]
       mov      rcx, gword ptr [rbp-0x10]
       call     [Lokad.Lython.Runtime.PyExecutableFunction:StartNativeCallWithStorage(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,bool,bool,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,byref,byref):this]
       nop      
 
G_M000_IG03:                ;; offset=0x010F
       add      rsp, 272
       pop      rbp
       ret      
 
; Total bytes of code 280

; Assembly listing for method Lokad.Lython.Runtime.PyExecutableFunction:StartNativeCallWithStorage(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,bool,bool,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,byref,byref):this (Tier0)
; Emitting BLENDED_CODE for x64 + VEX on Unix
; Tier0 code
; rbp based frame
; partially interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 288
       lea      rbp, [rsp+0x120]
       vxorps   xmm8, xmm8, xmm8
       vmovdqu  ymmword ptr [rbp-0xC0], ymm8
       vmovdqu  ymmword ptr [rbp-0xA0], ymm8
       vmovdqu  ymmword ptr [rbp-0x80], ymm8
       vmovdqu  ymmword ptr [rbp-0x60], ymm8
       vmovdqa  xmmword ptr [rbp-0x40], xmm8
       mov      gword ptr [rbp-0x08], rdi
       mov      bword ptr [rbp-0x18], rsi
       mov      qword ptr [rbp-0x10], rdx
       mov      gword ptr [rbp-0x20], rcx
       mov      bword ptr [rbp-0x30], r8
       mov      qword ptr [rbp-0x28], r9
 
G_M000_IG02:                ;; offset=0x004C
       mov      rdi, gword ptr [rbp-0x08]
       call     [Lokad.Lython.Runtime.PyFunctionBase:get_CodeObject():Lokad.Lython.Frontend.ExecutableCodeObject:this]
       mov      rdi, rax
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_ValueStorageCapacity():int:this]
       mov      dword ptr [rbp-0xC8], eax
       mov      edx, dword ptr [rbp-0xC8]
       lea      rdi, [rbp-0x18]
       xor      esi, esi
       call     [System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:Slice(int,int):System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:this]
       mov      bword ptr [rbp-0x90], rax
       mov      qword ptr [rbp-0x88], rdx
 
G_M000_IG03:                ;; offset=0x0087
       vmovdqu  xmm0, xmmword ptr [rbp-0x90]
       vmovdqu  xmmword ptr [rbp-0x18], xmm0
 
G_M000_IG04:                ;; offset=0x0094
       movzx    rax, byte  ptr [rbp+0x30]
       test     eax, eax
       je       G_M000_IG06
       xor      eax, eax
       mov      dword ptr [rbp-0x34], eax
       cmp      gword ptr [rbp+0x10], 0
       je       SHORT G_M000_IG05
       mov      eax, dword ptr [rbp-0x34]
       mov      dword ptr [rbp-0xC4], eax
       mov      eax, dword ptr [rbp-0x34]
       inc      eax
       mov      dword ptr [rbp-0x34], eax
       mov      eax, dword ptr [rbp-0x10]
       cmp      dword ptr [rbp-0xC4], eax
       jae      G_M000_IG10
       mov      eax, dword ptr [rbp-0xC4]
       shl      rax, 4
       mov      rdi, rax
       add      rdi, bword ptr [rbp-0x18]
       mov      rsi, gword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:set_Object(System.Object):this]
 
G_M000_IG05:                ;; offset=0x00E7
       lea      rdi, [rbp-0x18]
       mov      esi, dword ptr [rbp-0x34]
       call     [System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:Slice(int):System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:this]
       mov      bword ptr [rbp-0xC0], rax
       mov      qword ptr [rbp-0xB8], rdx
       mov      rsi, bword ptr [rbp-0xC0]
       mov      rdx, qword ptr [rbp-0xB8]
       lea      rdi, [rbp-0x30]
       call     [System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:CopyTo(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):this]
       jmp      G_M000_IG07
 
G_M000_IG06:                ;; offset=0x011F
       mov      rdi, gword ptr [rbp-0x08]
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_ParameterCount():int:this]
       mov      dword ptr [rbp-0xCC], eax
       mov      edx, dword ptr [rbp-0xCC]
       lea      rdi, [rbp-0x18]
       xor      esi, esi
       call     [System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:Slice(int,int):System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:this]
       mov      bword ptr [rbp-0xA0], rax
       mov      qword ptr [rbp-0x98], rdx
       vxorps   xmm0, xmm0, xmm0
       vmovdqu  xmmword ptr [rbp-0x48], xmm0
       mov      rax, gword ptr [rbp+0x18]
       mov      gword ptr [rsp], rax
       xor      eax, eax
       mov      dword ptr [rsp+0x08], eax
       mov      rax, gword ptr [rbp+0x10]
       mov      gword ptr [rsp+0x10], rax
       mov      rax, gword ptr [rbp-0x20]
       mov      gword ptr [rsp+0x18], rax
       lea      rdi, [rsp+0x20]
       lea      rsi, [rbp-0x30]
       mov      rcx, bword ptr [rsi]
       mov      bword ptr [rsp+0x20], rcx
       add      rsi, 8
       add      rdi, 8
       movsq    
       mov      rdi, bword ptr [rbp-0xA0]
       mov      rsi, qword ptr [rbp-0x98]
       mov      rdx, bword ptr [rbp-0x48]
       mov      rcx, qword ptr [rbp-0x40]
       mov      r8, gword ptr [rbp+0x20]
       mov      r9, gword ptr [rbp-0x08]
       call     [Lokad.Lython.Runtime.LythonRuntime:BindFunctionArgumentsInto(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.ReadOnlySpan`1[Lokad.Lython.Runtime.CallArgumentValue],Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.FunctionBindingPlan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,bool,System.Object,Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):int]
 
G_M000_IG07:                ;; offset=0x01B7
       vmovdqu  xmm0, xmmword ptr [rbp-0x18]
       vmovdqu  xmmword ptr [rbp-0xB0], xmm0
 
G_M000_IG08:                ;; offset=0x01C4
       vxorps   ymm0, ymm0, ymm0
       vmovdqu  ymmword ptr [rbp-0x80], ymm0
       lea      rdi, [rsp]
       lea      rsi, [rbp-0x80]
       movsq    
       mov      rcx, gword ptr [rsi]
       mov      gword ptr [rsp+0x08], rcx
       add      rsi, 8
       add      rdi, 8
       mov      rcx, gword ptr [rsi]
       mov      gword ptr [rsp+0x10], rcx
       add      rsi, 8
       add      rdi, 8
       movsq    
       lea      rdi, [rsp+0x20]
       lea      rsi, [rbp+0x38]
       mov      rcx, bword ptr [rsi]
       mov      bword ptr [rsp+0x20], rcx
       add      rsi, 8
       add      rdi, 8
       movsq    
       mov      rax, bword ptr [rbp+0x50]
       mov      bword ptr [rsp+0x30], rax
       mov      rax, bword ptr [rbp+0x58]
       mov      bword ptr [rsp+0x38], rax
       lea      rax, [rbp-0x60]
       mov      qword ptr [rsp+0x40], rax
       movzx    r8, byte  ptr [rbp+0x28]
       mov      rsi, bword ptr [rbp-0xB0]
       mov      rdx, qword ptr [rbp-0xA8]
       mov      rdi, gword ptr [rbp-0x08]
       mov      rcx, gword ptr [rbp+0x20]
       mov      r9, bword ptr [rbp+0x48]
       call     [Lokad.Lython.Runtime.PyExecutableFunction:StartInline(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.Nullable`1[Lokad.Lython.Runtime.BoundFunctionArguments],Lokad.Lython.LythonSourceSpan,bool,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,byref,byref,byref):this]
       nop      
 
G_M000_IG09:                ;; offset=0x0255
       add      rsp, 288
       pop      rbp
       ret      
 
G_M000_IG10:                ;; offset=0x025E
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
; Total bytes of code 612

; Assembly listing for method Lokad.Lython.Runtime.PyExecutableFunction:StartNativeCall(Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,bool,bool,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,byref,byref):this (Instrumented Tier0)
; Emitting BLENDED_CODE for x64 + VEX on Unix
; Instrumented Tier0 code
; rbp based frame
; partially interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 144
       lea      rbp, [rsp+0x90]
       vxorps   xmm8, xmm8, xmm8
       vmovdqu  xmmword ptr [rbp-0x48], xmm8
       xor      eax, eax
       mov      dword ptr [rbp-0x38], eax
       mov      gword ptr [rbp-0x08], rdi
       mov      gword ptr [rbp-0x10], rsi
       mov      bword ptr [rbp-0x20], rdx
       mov      qword ptr [rbp-0x18], rcx
       mov      gword ptr [rbp-0x28], r8
       mov      gword ptr [rbp-0x30], r9
 
G_M000_IG02:                ;; offset=0x0037
       cmp      gword ptr [rbp-0x28], 0
       jne      G_M000_IG09
       mov      rdi, gword ptr [rbp-0x08]
       call     [Lokad.Lython.Runtime.PyFunctionBase:get_CodeObject():Lokad.Lython.Frontend.ExecutableCodeObject:this]
       mov      rdi, rax
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_HasDirectIntegerReturn():bool:this]
       test     eax, eax
       je       SHORT G_M000_IG03
       movzx    rax, byte  ptr [rbp+0x20]
       test     eax, eax
       jne      SHORT G_M000_IG04
       mov      rax, bword ptr [rbp+0x40]
       mov      bword ptr [rsp], rax
       mov      rdx, bword ptr [rbp-0x20]
       mov      rcx, qword ptr [rbp-0x18]
       mov      rdi, gword ptr [rbp-0x08]
       mov      rsi, gword ptr [rbp-0x10]
       mov      r8, gword ptr [rbp-0x30]
       mov      r9, gword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.PyExecutableFunction:TryStartPreparedIntegerReturn(Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,byref):bool:this]
       mov      dword ptr [rbp-0x38], eax
       jmp      G_M000_IG06
 
G_M000_IG03:                ;; offset=0x0091
       mov      rdi, 0x7F3A2A29DB80
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG09
 
G_M000_IG04:                ;; offset=0x00A5
       mov      eax, dword ptr [rbp-0x18]
       mov      dword ptr [rbp-0x34], eax
       mov      rdi, gword ptr [rbp-0x08]
       call     [Lokad.Lython.Runtime.PyFunctionBase:get_CodeObject():Lokad.Lython.Frontend.ExecutableCodeObject:this]
       mov      rdi, rax
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_FirstTemporarySlot():int:this]
       cmp      eax, dword ptr [rbp-0x34]
       jne      SHORT G_M000_IG05
       mov      rdi, 0x7F3A2A29DB84
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rsi, bword ptr [rbp-0x20]
       mov      rdx, qword ptr [rbp-0x18]
       lea      rdi, [rbp-0x48]
       call     [Lokad.Lython.Runtime.LythonRuntime+SlotIntegerOperands:.ctor(System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):this]
       mov      rsi, bword ptr [rbp-0x48]
       mov      rdx, qword ptr [rbp-0x40]
       mov      rdi, gword ptr [rbp-0x08]
       mov      rcx, gword ptr [rbp+0x10]
       mov      r8, bword ptr [rbp+0x40]
       call     [Lokad.Lython.Runtime.PyExecutableFunction:TryStartDirectIntegerReturn[Lokad.Lython.Runtime.LythonRuntime+SlotIntegerOperands](Lokad.Lython.Runtime.LythonRuntime+SlotIntegerOperands,Lokad.Lython.LythonSourceSpan,byref):bool:this]
       mov      dword ptr [rbp-0x38], eax
       jmp      SHORT G_M000_IG06
 
G_M000_IG05:                ;; offset=0x0105
       mov      rdi, 0x7F3A2A29DB88
       call     CORINFO_HELP_COUNTPROFILE32
       xor      eax, eax
       mov      dword ptr [rbp-0x38], eax
 
G_M000_IG06:                ;; offset=0x0119
       cmp      dword ptr [rbp-0x38], 0
       je       SHORT G_M000_IG08
       mov      rdi, 0x7F3A2A29DB8C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x38]
       mov      byte  ptr [rax], 0
       mov      rax, bword ptr [rbp+0x48]
       xor      rcx, rcx
       mov      gword ptr [rax], rcx
 
G_M000_IG07:                ;; offset=0x013E
       add      rsp, 144
       pop      rbp
       ret      
 
G_M000_IG08:                ;; offset=0x0147
       mov      rdi, 0x7F3A2A29DB90
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG09:                ;; offset=0x0156
       mov      rdi, gword ptr [rbp-0x08]
       call     [Lokad.Lython.Runtime.PyFunctionBase:get_CodeObject():Lokad.Lython.Frontend.ExecutableCodeObject:this]
       mov      rdi, rax
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_ValueStorageCapacity():int:this]
       cmp      eax, 8
       jg       G_M000_IG11
       mov      rdi, 0x7F3A2A29DB94
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, gword ptr [rbp+0x10]
       mov      gword ptr [rsp], rax
       movzx    rax, byte  ptr [rbp+0x18]
       mov      dword ptr [rsp+0x08], eax
       movzx    rax, byte  ptr [rbp+0x20]
       mov      dword ptr [rsp+0x10], eax
       lea      rdi, [rsp+0x18]
       lea      rsi, [rbp+0x28]
       mov      rcx, bword ptr [rsi]
       mov      bword ptr [rsp+0x18], rcx
       add      rsi, 8
       add      rdi, 8
       movsq    
       mov      rax, bword ptr [rbp+0x38]
       mov      bword ptr [rsp+0x28], rax
       mov      rax, bword ptr [rbp+0x40]
       mov      bword ptr [rsp+0x30], rax
       mov      rax, bword ptr [rbp+0x48]
       mov      bword ptr [rsp+0x38], rax
       mov      rdx, bword ptr [rbp-0x20]
       mov      rcx, qword ptr [rbp-0x18]
       mov      rdi, gword ptr [rbp-0x08]
       mov      rsi, gword ptr [rbp-0x10]
       mov      r8, gword ptr [rbp-0x28]
       mov      r9, gword ptr [rbp-0x30]
       call     [Lokad.Lython.Runtime.PyExecutableFunction:StartCompactNativeCall(Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,bool,bool,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,byref,byref):this]
       nop      
 
G_M000_IG10:                ;; offset=0x01F0
       add      rsp, 144
       pop      rbp
       ret      
 
G_M000_IG11:                ;; offset=0x01F9
       mov      rdi, 0x7F3A2A29DB98
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, gword ptr [rbp+0x10]
       mov      gword ptr [rsp], rax
       movzx    rax, byte  ptr [rbp+0x18]
       mov      dword ptr [rsp+0x08], eax
       movzx    rax, byte  ptr [rbp+0x20]
       mov      dword ptr [rsp+0x10], eax
       lea      rdi, [rsp+0x18]
       lea      rsi, [rbp+0x28]
       mov      rcx, bword ptr [rsi]
       mov      bword ptr [rsp+0x18], rcx
       add      rsi, 8
       add      rdi, 8
       movsq    
       mov      rax, bword ptr [rbp+0x38]
       mov      bword ptr [rsp+0x28], rax
       mov      rax, bword ptr [rbp+0x40]
       mov      bword ptr [rsp+0x30], rax
       mov      rax, bword ptr [rbp+0x48]
       mov      bword ptr [rsp+0x38], rax
       mov      rdx, bword ptr [rbp-0x20]
       mov      rcx, qword ptr [rbp-0x18]
       mov      rdi, gword ptr [rbp-0x08]
       mov      rsi, gword ptr [rbp-0x10]
       mov      r8, gword ptr [rbp-0x28]
       mov      r9, gword ptr [rbp-0x30]
       call     [Lokad.Lython.Runtime.PyExecutableFunction:StartWideNativeCall(Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,bool,bool,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,byref,byref):this]
       nop      
 
G_M000_IG12:                ;; offset=0x0275
       add      rsp, 144
       pop      rbp
       ret      
 
; Total bytes of code 638

; Assembly listing for method Lokad.Lython.Runtime.PyExecutableFunction:StartCompactNativeCall(Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,bool,bool,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,byref,byref):this (Instrumented Tier0)
; Emitting BLENDED_CODE for x64 + VEX on Unix
; Instrumented Tier0 code
; rbp based frame
; partially interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 272
       lea      rbp, [rsp+0x110]
       vxorps   xmm8, xmm8, xmm8
       vmovdqu  ymmword ptr [rbp-0xC0], ymm8
       vmovdqu  ymmword ptr [rbp-0xA0], ymm8
       vmovdqu  ymmword ptr [rbp-0x80], ymm8
       vmovdqu  ymmword ptr [rbp-0x60], ymm8
       vmovdqa  xmmword ptr [rbp-0x40], xmm8
       mov      gword ptr [rbp-0x08], rdi
       mov      gword ptr [rbp-0x10], rsi
       mov      bword ptr [rbp-0x20], rdx
       mov      qword ptr [rbp-0x18], rcx
       mov      gword ptr [rbp-0x28], r8
       mov      gword ptr [rbp-0x30], r9
 
G_M000_IG02:                ;; offset=0x004C
       vxorps   ymm0, ymm0, ymm0
       vmovdqu  ymmword ptr [rbp-0xB0], ymm0
       vmovdqu  ymmword ptr [rbp-0x90], ymm0
       vmovdqu  ymmword ptr [rbp-0x70], ymm0
       vmovdqu  ymmword ptr [rbp-0x50], ymm0
       lea      rdi, [rbp-0xB0]
       mov      esi, 8
       call     [<PrivateImplementationDetails>:InlineArrayAsSpan[Lokad.Lython.Runtime.PyExecutableFunction+CompactNativeValues,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot](byref,int):System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]]
       mov      bword ptr [rbp-0xC0], rax
       mov      qword ptr [rbp-0xB8], rdx
       mov      rax, gword ptr [rbp-0x28]
       mov      gword ptr [rsp], rax
       mov      rax, gword ptr [rbp-0x30]
       mov      gword ptr [rsp+0x08], rax
       mov      rax, gword ptr [rbp+0x10]
       mov      gword ptr [rsp+0x10], rax
       movzx    rax, byte  ptr [rbp+0x18]
       mov      dword ptr [rsp+0x18], eax
       movzx    rax, byte  ptr [rbp+0x20]
       mov      dword ptr [rsp+0x20], eax
       lea      rdi, [rsp+0x28]
       lea      rsi, [rbp+0x28]
       mov      rcx, bword ptr [rsi]
       mov      bword ptr [rsp+0x28], rcx
       add      rsi, 8
       add      rdi, 8
       movsq    
       mov      rax, bword ptr [rbp+0x38]
       mov      bword ptr [rsp+0x38], rax
       mov      rax, bword ptr [rbp+0x40]
       mov      bword ptr [rsp+0x40], rax
       mov      rax, bword ptr [rbp+0x48]
       mov      bword ptr [rsp+0x48], rax
       mov      rsi, bword ptr [rbp-0xC0]
       mov      rdx, qword ptr [rbp-0xB8]
       mov      r8, bword ptr [rbp-0x20]
       mov      r9, qword ptr [rbp-0x18]
       mov      rdi, gword ptr [rbp-0x08]
       mov      rcx, gword ptr [rbp-0x10]
       call     [Lokad.Lython.Runtime.PyExecutableFunction:StartNativeCallWithStorage(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,bool,bool,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,byref,byref):this]
       nop      
 
G_M000_IG03:                ;; offset=0x010F
       add      rsp, 272
       pop      rbp
       ret      
 
; Total bytes of code 280

; Assembly listing for method Lokad.Lython.Runtime.PyExecutableFunction:StartNativeCallWithStorage(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,bool,bool,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,byref,byref):this (Instrumented Tier0)
; Emitting BLENDED_CODE for x64 + VEX on Unix
; Instrumented Tier0 code
; rbp based frame
; partially interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 288
       lea      rbp, [rsp+0x120]
       vxorps   xmm8, xmm8, xmm8
       vmovdqu  ymmword ptr [rbp-0xC0], ymm8
       vmovdqu  ymmword ptr [rbp-0xA0], ymm8
       vmovdqu  ymmword ptr [rbp-0x80], ymm8
       vmovdqu  ymmword ptr [rbp-0x60], ymm8
       vmovdqa  xmmword ptr [rbp-0x40], xmm8
       mov      gword ptr [rbp-0x08], rdi
       mov      bword ptr [rbp-0x18], rsi
       mov      qword ptr [rbp-0x10], rdx
       mov      gword ptr [rbp-0x20], rcx
       mov      bword ptr [rbp-0x30], r8
       mov      qword ptr [rbp-0x28], r9
 
G_M000_IG02:                ;; offset=0x004C
       mov      rdi, gword ptr [rbp-0x08]
       call     [Lokad.Lython.Runtime.PyFunctionBase:get_CodeObject():Lokad.Lython.Frontend.ExecutableCodeObject:this]
       mov      rdi, rax
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_ValueStorageCapacity():int:this]
       mov      dword ptr [rbp-0xC8], eax
       mov      edx, dword ptr [rbp-0xC8]
       lea      rdi, [rbp-0x18]
       xor      esi, esi
       call     [System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:Slice(int,int):System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:this]
       mov      bword ptr [rbp-0x90], rax
       mov      qword ptr [rbp-0x88], rdx
 
G_M000_IG03:                ;; offset=0x0087
       vmovdqu  xmm0, xmmword ptr [rbp-0x90]
       vmovdqu  xmmword ptr [rbp-0x18], xmm0
 
G_M000_IG04:                ;; offset=0x0094
       movzx    rax, byte  ptr [rbp+0x30]
       test     eax, eax
       je       G_M000_IG06
       xor      eax, eax
       mov      dword ptr [rbp-0x34], eax
       cmp      gword ptr [rbp+0x10], 0
       je       SHORT G_M000_IG05
       mov      rdi, 0x7F3A2A630750
       call     CORINFO_HELP_COUNTPROFILE32
       mov      eax, dword ptr [rbp-0x34]
       mov      dword ptr [rbp-0xC4], eax
       mov      eax, dword ptr [rbp-0x34]
       inc      eax
       mov      dword ptr [rbp-0x34], eax
       mov      eax, dword ptr [rbp-0x10]
       cmp      dword ptr [rbp-0xC4], eax
       jae      G_M000_IG11
       mov      eax, dword ptr [rbp-0xC4]
       shl      rax, 4
       mov      rdi, rax
       add      rdi, bword ptr [rbp-0x18]
       mov      rsi, gword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:set_Object(System.Object):this]
 
G_M000_IG05:                ;; offset=0x00F6
       lea      rdi, [rbp-0x18]
       mov      esi, dword ptr [rbp-0x34]
       call     [System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:Slice(int):System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:this]
       mov      bword ptr [rbp-0xC0], rax
       mov      qword ptr [rbp-0xB8], rdx
       mov      rsi, bword ptr [rbp-0xC0]
       mov      rdx, qword ptr [rbp-0xB8]
       lea      rdi, [rbp-0x30]
       call     [System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:CopyTo(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):this]
       jmp      G_M000_IG07
 
G_M000_IG06:                ;; offset=0x012E
       mov      rdi, 0x7F3A2A630754
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, gword ptr [rbp-0x08]
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_ParameterCount():int:this]
       mov      dword ptr [rbp-0xCC], eax
       mov      edx, dword ptr [rbp-0xCC]
       lea      rdi, [rbp-0x18]
       xor      esi, esi
       call     [System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:Slice(int,int):System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:this]
       mov      bword ptr [rbp-0xA0], rax
       mov      qword ptr [rbp-0x98], rdx
       vxorps   xmm0, xmm0, xmm0
       vmovdqu  xmmword ptr [rbp-0x48], xmm0
       mov      rax, gword ptr [rbp+0x18]
       mov      gword ptr [rsp], rax
       xor      eax, eax
       mov      dword ptr [rsp+0x08], eax
       mov      rax, gword ptr [rbp+0x10]
       mov      gword ptr [rsp+0x10], rax
       mov      rax, gword ptr [rbp-0x20]
       mov      gword ptr [rsp+0x18], rax
       lea      rdi, [rsp+0x20]
       lea      rsi, [rbp-0x30]
       mov      rcx, bword ptr [rsi]
       mov      bword ptr [rsp+0x20], rcx
       add      rsi, 8
       add      rdi, 8
       movsq    
       mov      rdi, bword ptr [rbp-0xA0]
       mov      rsi, qword ptr [rbp-0x98]
       mov      rdx, bword ptr [rbp-0x48]
       mov      rcx, qword ptr [rbp-0x40]
       mov      r8, gword ptr [rbp+0x20]
       mov      r9, gword ptr [rbp-0x08]
       call     [Lokad.Lython.Runtime.LythonRuntime:BindFunctionArgumentsInto(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.ReadOnlySpan`1[Lokad.Lython.Runtime.CallArgumentValue],Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.FunctionBindingPlan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,bool,System.Object,Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):int]
 
G_M000_IG07:                ;; offset=0x01D5
       mov      rdi, 0x7F3A2A630758
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG08:                ;; offset=0x01E4
       vmovdqu  xmm0, xmmword ptr [rbp-0x18]
       vmovdqu  xmmword ptr [rbp-0xB0], xmm0
 
G_M000_IG09:                ;; offset=0x01F1
       vxorps   ymm0, ymm0, ymm0
       vmovdqu  ymmword ptr [rbp-0x80], ymm0
       lea      rdi, [rsp]
       lea      rsi, [rbp-0x80]
       movsq    
       mov      rcx, gword ptr [rsi]
       mov      gword ptr [rsp+0x08], rcx
       add      rsi, 8
       add      rdi, 8
       mov      rcx, gword ptr [rsi]
       mov      gword ptr [rsp+0x10], rcx
       add      rsi, 8
       add      rdi, 8
       movsq    
       lea      rdi, [rsp+0x20]
       lea      rsi, [rbp+0x38]
       mov      rcx, bword ptr [rsi]
       mov      bword ptr [rsp+0x20], rcx
       add      rsi, 8
       add      rdi, 8
       movsq    
       mov      rax, bword ptr [rbp+0x50]
       mov      bword ptr [rsp+0x30], rax
       mov      rax, bword ptr [rbp+0x58]
       mov      bword ptr [rsp+0x38], rax
       lea      rax, [rbp-0x60]
       mov      qword ptr [rsp+0x40], rax
       movzx    r8, byte  ptr [rbp+0x28]
       mov      rsi, bword ptr [rbp-0xB0]
       mov      rdx, qword ptr [rbp-0xA8]
       mov      rdi, gword ptr [rbp-0x08]
       mov      rcx, gword ptr [rbp+0x20]
       mov      r9, bword ptr [rbp+0x48]
       call     [Lokad.Lython.Runtime.PyExecutableFunction:StartInline(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.Nullable`1[Lokad.Lython.Runtime.BoundFunctionArguments],Lokad.Lython.LythonSourceSpan,bool,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,byref,byref,byref):this]
       nop      
 
G_M000_IG10:                ;; offset=0x0282
       add      rsp, 288
       pop      rbp
       ret      
 
G_M000_IG11:                ;; offset=0x028B
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
; Total bytes of code 657

; Assembly listing for method Lokad.Lython.Runtime.PyExecutableFunction:StartNativeCall(Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,bool,bool,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,byref,byref):this (Tier1)
; Emitting BLENDED_CODE for x64 + VEX on Unix
; Tier1 code
; optimized code
; optimized using Synthesized PGO
; rbp based frame
; partially interruptible
; with Synthesized PGO: fgCalledCount is 23388
; 2 inlinees with PGO data; 15 single block inlinees; 0 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       push     r15
       push     r14
       push     r13
       push     r12
       push     rbx
       sub      rsp, 104
       lea      rbp, [rsp+0x90]
       vxorps   xmm8, xmm8, xmm8
       vmovdqa  xmmword ptr [rbp-0x40], xmm8
       xor      eax, eax
       mov      qword ptr [rbp-0x30], rax
       mov      bword ptr [rbp-0x50], rdx
       mov      rbx, rdi
       mov      r14, rsi
       mov      r12d, ecx
       mov      r15, r8
       mov      r13, r9
       mov      rcx, bword ptr [rbp+0x40]
 
G_M000_IG02:                ;; offset=0x003D
       test     r15, r15
       jne      G_M000_IG15
 
G_M000_IG03:                ;; offset=0x0046
       mov      rdi, gword ptr [rbx+0x40]
       cmp      byte  ptr [rdi+0xE0], 0
       jne      G_M000_IG08
 
G_M000_IG04:                ;; offset=0x0057
       mov      rax, bword ptr [rbp-0x50]
 
G_M000_IG05:                ;; offset=0x005B
       mov      rdx, gword ptr [rbx+0x40]
       cmp      dword ptr [rdx+0xD4], 8
       jg       G_M000_IG18
       mov      r10, gword ptr [rbp+0x10]
       mov      gword ptr [rsp], r10
       movzx    rdx, byte  ptr [rbp+0x18]
       mov      dword ptr [rsp+0x08], edx
       movzx    rdx, byte  ptr [rbp+0x20]
       mov      dword ptr [rsp+0x10], edx
       mov      r11, bword ptr [rbp+0x28]
       mov      bword ptr [rsp+0x18], r11
       mov      r9d, dword ptr [rbp+0x30]
       mov      dword ptr [rsp+0x20], r9d
       mov      r8, bword ptr [rbp+0x38]
       mov      bword ptr [rsp+0x28], r8
       mov      bword ptr [rsp+0x30], rcx
       mov      rsi, bword ptr [rbp+0x48]
       mov      bword ptr [rsp+0x38], rsi
       mov      rdx, rax
       mov      ecx, r12d
       mov      rdi, rbx
       mov      rsi, r14
       mov      r8, r15
       mov      r9, r13
       call     [Lokad.Lython.Runtime.PyExecutableFunction:StartCompactNativeCall(Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,bool,bool,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,byref,byref):this]
 
G_M000_IG06:                ;; offset=0x00C5
       nop      
 
G_M000_IG07:                ;; offset=0x00C6
       add      rsp, 104
       pop      rbx
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG08:                ;; offset=0x00D5
       cmp      byte  ptr [rbp+0x20], 0
       jne      G_M000_IG17
       xor      edi, edi
       mov      bword ptr [rbp+0x40], rcx
       mov      qword ptr [rcx], rdi
       mov      qword ptr [rcx+0x08], rdi
       cmp      byte  ptr [r14+0x34], 0
       je       G_M000_IG14
       mov      rdi, gword ptr [rbx+0x08]
       mov      rdi, gword ptr [rdi+0x08]
       mov      edi, dword ptr [rdi+0x08]
       mov      rsi, gword ptr [rbx+0x40]
       cmp      edi, dword ptr [rsi+0xC4]
       jne      G_M000_IG13
       mov      rdi, rbx
       mov      esi, r12d
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:HasPreparedOmittedArguments(int):bool:this]
       test     eax, eax
       je       G_M000_IG11
       mov      rax, gword ptr [r13+0x98]
       mov      gword ptr [rbp-0x48], rax
       cmp      byte  ptr [rax], al
       mov      rdi, rax
       call     [Lokad.Lython.Runtime.ExecutionState:get_CanContinue():bool:this]
       test     eax, eax
       je       G_M000_IG16
 
G_M000_IG09:                ;; offset=0x0144
       mov      gword ptr [rbp-0x40], rbx
       mov      rax, bword ptr [rbp-0x50]
       mov      bword ptr [rbp-0x38], rax
       mov      dword ptr [rbp-0x30], r12d
       lea      rdi, [rsp]
       lea      rsi, [rbp-0x40]
       mov      rcx, gword ptr [rsi]
       mov      gword ptr [rsp], rcx
       add      rsi, 8
       add      rdi, 8
       mov      rcx, bword ptr [rsi]
       mov      bword ptr [rsp+0x08], rcx
       add      rsi, 8
       add      rdi, 8
       movsq    
       mov      rdi, rbx
       mov      rsi, gword ptr [rbp+0x10]
       mov      rdx, bword ptr [rbp+0x40]
       call     [Lokad.Lython.Runtime.PyExecutableFunction:TryStartDirectIntegerReturn[Lokad.Lython.Runtime.LythonRuntime+DefaultIntegerOperands](Lokad.Lython.Runtime.LythonRuntime+DefaultIntegerOperands,Lokad.Lython.LythonSourceSpan,byref):bool:this]
 
G_M000_IG10:                ;; offset=0x018E
       test     eax, eax
       mov      rax, bword ptr [rbp-0x50]
       mov      rcx, bword ptr [rbp+0x40]
       je       G_M000_IG05
       mov      r13, bword ptr [rbp+0x38]
       mov      byte  ptr [r13], 0
       xor      rdx, rdx
       mov      r15, bword ptr [rbp+0x48]
       mov      gword ptr [r15], rdx
       jmp      G_M000_IG06
 
G_M000_IG11:                ;; offset=0x01B5
       mov      rax, bword ptr [rbp-0x50]
 
G_M000_IG12:                ;; offset=0x01B9
       xor      esi, esi
       mov      bword ptr [rbp-0x50], rax
       mov      eax, esi
       jmp      SHORT G_M000_IG10
 
G_M000_IG13:                ;; offset=0x01C3
       mov      rax, bword ptr [rbp-0x50]
       jmp      SHORT G_M000_IG12
 
G_M000_IG14:                ;; offset=0x01C9
       mov      rax, bword ptr [rbp-0x50]
       jmp      SHORT G_M000_IG12
 
G_M000_IG15:                ;; offset=0x01CF
       mov      rax, bword ptr [rbp-0x50]
       jmp      G_M000_IG05
 
G_M000_IG16:                ;; offset=0x01D8
       mov      rdi, gword ptr [rbp-0x48]
       mov      rsi, gword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
       jmp      G_M000_IG09
 
G_M000_IG17:                ;; offset=0x01EB
       mov      rax, bword ptr [rbp-0x50]
       mov      rsi, gword ptr [rbx+0x40]
       cmp      r12d, dword ptr [rsi+0xC4]
       jne      G_M000_IG05
       mov      bword ptr [rbp+0x40], rcx
       mov      bword ptr [rbp-0x50], rax
       mov      rsi, rax
       mov      edx, r12d
       mov      rdi, rbx
       mov      rcx, gword ptr [rbp+0x10]
       mov      r8, bword ptr [rbp+0x40]
       call     [Lokad.Lython.Runtime.PyExecutableFunction:TryStartDirectIntegerReturn[Lokad.Lython.Runtime.LythonRuntime+SlotIntegerOperands](Lokad.Lython.Runtime.LythonRuntime+SlotIntegerOperands,Lokad.Lython.LythonSourceSpan,byref):bool:this]
       jmp      G_M000_IG10
 
G_M000_IG18:                ;; offset=0x0224
       mov      rdx, gword ptr [rbp+0x10]
       mov      gword ptr [rsp], rdx
       movzx    rdx, byte  ptr [rbp+0x18]
       mov      dword ptr [rsp+0x08], edx
       movzx    rdx, byte  ptr [rbp+0x20]
       mov      dword ptr [rsp+0x10], edx
       mov      rdx, bword ptr [rbp+0x28]
       mov      bword ptr [rsp+0x18], rdx
       mov      edi, dword ptr [rbp+0x30]
       mov      dword ptr [rsp+0x20], edi
       mov      rdx, bword ptr [rbp+0x38]
       mov      bword ptr [rsp+0x28], rdx
       mov      bword ptr [rsp+0x30], rcx
       mov      rdx, bword ptr [rbp+0x48]
       mov      bword ptr [rsp+0x38], rdx
       mov      rdx, rax
       mov      ecx, r12d
       mov      rdi, rbx
       mov      rsi, r14
       mov      r8, r15
       mov      r9, r13
       call     [Lokad.Lython.Runtime.PyExecutableFunction:StartWideNativeCall(Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,bool,bool,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,byref,byref):this]
       jmp      G_M000_IG06
 
; Total bytes of code 640

; Assembly listing for method Lokad.Lython.Runtime.PyExecutableFunction:StartCompactNativeCall(Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,bool,bool,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,byref,byref):this (Tier1)
; Emitting BLENDED_CODE for x64 + VEX on Unix
; Tier1 code
; optimized code
; optimized using Synthesized PGO
; rbp based frame
; partially interruptible
; with Synthesized PGO: fgCalledCount is 100
; No PGO data
; 6 inlinees with PGO data; 11 single block inlinees; 1 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       push     r15
       push     r14
       push     r13
       push     rbx
       sub      rsp, 256
       lea      rbp, [rsp+0x120]
       xor      eax, eax
       mov      qword ptr [rbp-0xD8], rax
       vxorps   xmm8, xmm8, xmm8
       vmovdqu  ymmword ptr [rbp-0xD0], ymm8
       vmovdqu  ymmword ptr [rbp-0xB0], ymm8
       vmovdqu  ymmword ptr [rbp-0x90], ymm8
       vmovdqu  ymmword ptr [rbp-0x70], ymm8
       vmovdqu  ymmword ptr [rbp-0x50], ymm8
       vmovdqa  xmmword ptr [rbp-0x30], xmm8
       mov      rbx, rdi
       mov      rax, rdx
 
G_M000_IG02:                ;; offset=0x0052
       mov      rdi, gword ptr [rbx+0x40]
       mov      r15d, dword ptr [rdi+0xD4]
       cmp      r15d, 8
       ja       G_M000_IG06
       cmp      byte  ptr [rbp+0x20], 0
       je       G_M000_IG11
       xor      edi, edi
       test     r8, r8
       jne      G_M000_IG07
 
G_M000_IG03:                ;; offset=0x007C
       cmp      edi, r15d
       ja       G_M000_IG06
       lea      rsi, bword ptr [rbp-0xA0]
       mov      edx, edi
       shl      rdx, 4
       add      rdx, rsi
       mov      esi, r15d
       sub      esi, edi
       cmp      ecx, esi
       ja       G_M000_IG10
       mov      edi, ecx
       shl      rdi, 4
       mov      rcx, rdi
       cmp      rcx, 0x4000
       ja       G_M000_IG09
       mov      rdi, rdx
       mov      rsi, rax
       mov      rdx, rcx
       call     System.Buffer:BulkMoveWithWriteBarrierInternal(byref,byref,nuint)
       cmp      dword ptr [(reloc 0x7f3aa7409818)], 0
       jne      G_M000_IG08
 
G_M000_IG04:                ;; offset=0x00D3
       vxorps   ymm0, ymm0, ymm0
       vmovdqu  ymmword ptr [rbp-0xC0], ymm0
       lea      rdi, [rsp]
       lea      rsi, [rbp-0xC0]
       movsq    
       mov      rcx, gword ptr [rsi]
       mov      gword ptr [rsp+0x08], rcx
       add      rsi, 8
       add      rdi, 8
       mov      rcx, gword ptr [rsi]
       mov      gword ptr [rsp+0x10], rcx
       add      rsi, 8
       add      rdi, 8
       movsq    
       mov      r14, bword ptr [rbp+0x28]
       mov      bword ptr [rsp+0x20], r14
       mov      r13d, dword ptr [rbp+0x30]
       mov      dword ptr [rsp+0x28], r13d
       mov      r14, bword ptr [rbp+0x40]
       mov      bword ptr [rsp+0x30], r14
       mov      r14, bword ptr [rbp+0x48]
       mov      bword ptr [rsp+0x38], r14
       lea      rsi, [rbp-0xD8]
       mov      qword ptr [rsp+0x40], rsi
       lea      rsi, bword ptr [rbp-0xA0]
       mov      edx, r15d
       movzx    r8, byte  ptr [rbp+0x18]
       mov      rdi, rbx
       mov      rcx, gword ptr [rbp+0x10]
       mov      r9, bword ptr [rbp+0x38]
       call     [Lokad.Lython.Runtime.PyExecutableFunction:StartInline(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.Nullable`1[Lokad.Lython.Runtime.BoundFunctionArguments],Lokad.Lython.LythonSourceSpan,bool,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,byref,byref,byref):this]
       nop      
 
G_M000_IG05:                ;; offset=0x015F
       add      rsp, 256
       pop      rbx
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG06:                ;; offset=0x016F
       call     [System.ThrowHelper:ThrowArgumentOutOfRangeException()]
       int3     
 
G_M000_IG07:                ;; offset=0x0176
       mov      edi, 1
       test     r15d, r15d
       je       G_M000_IG12
       mov      gword ptr [rbp-0xA0], r8
       xor      esi, esi
       mov      qword ptr [rbp-0x98], rsi
       jmp      G_M000_IG03
 
G_M000_IG08:                ;; offset=0x0199
       call     CORINFO_HELP_POLL_GC
       jmp      G_M000_IG04
 
G_M000_IG09:                ;; offset=0x01A3
       mov      rdi, rdx
       mov      rsi, rax
       mov      rdx, rcx
       call     [System.Buffer:BulkMoveWithWriteBarrierBatch(byref,byref,nuint)]
       jmp      G_M000_IG04
 
G_M000_IG10:                ;; offset=0x01B7
       call     [System.ThrowHelper:ThrowArgumentException_DestinationTooShort()]
       int3     
 
G_M000_IG11:                ;; offset=0x01BE
       mov      rdi, gword ptr [rbx+0x08]
       mov      rdi, gword ptr [rdi+0x08]
       mov      edx, dword ptr [rdi+0x08]
       cmp      edx, r15d
       ja       SHORT G_M000_IG06
       mov      gword ptr [rsp], r9
       xor      edi, edi
       mov      dword ptr [rsp+0x08], edi
       mov      gword ptr [rsp+0x10], r8
       mov      gword ptr [rsp+0x18], rsi
       mov      bword ptr [rsp+0x20], rax
       mov      dword ptr [rsp+0x28], ecx
       lea      rdi, bword ptr [rbp-0xA0]
       mov      esi, edx
       xor      rdx, rdx
       xor      ecx, ecx
       mov      r8, gword ptr [rbp+0x10]
       mov      r9, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime:BindFunctionArgumentsInto(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.ReadOnlySpan`1[Lokad.Lython.Runtime.CallArgumentValue],Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.FunctionBindingPlan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,bool,System.Object,Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):int]
       jmp      G_M000_IG04
 
G_M000_IG12:                ;; offset=0x020A
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
; Total bytes of code 528

; Assembly listing for method Lokad.Lython.Runtime.PyExecutableFunction:StartNativeCallWithStorage(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,bool,bool,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,byref,byref):this (Tier1)
; Emitting BLENDED_CODE for x64 + VEX on Unix
; Tier1 code
; optimized code
; optimized using Synthesized PGO
; rbp based frame
; partially interruptible
; with Synthesized PGO: fgCalledCount is 30080
; 5 inlinees with PGO data; 8 single block inlinees; 1 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       push     r15
       push     r14
       push     r13
       push     r12
       push     rbx
       sub      rsp, 136
       lea      rbp, [rsp+0xB0]
       xor      eax, eax
       mov      qword ptr [rbp-0x68], rax
       vxorps   xmm8, xmm8, xmm8
       vmovdqu  ymmword ptr [rbp-0x60], ymm8
       vmovdqa  xmmword ptr [rbp-0x40], xmm8
       mov      rbx, rdi
       mov      r14, r8
       mov      r15d, r9d
 
G_M000_IG02:                ;; offset=0x0037
       mov      rdi, gword ptr [rbx+0x40]
       mov      r13d, dword ptr [rdi+0xD4]
       cmp      r13d, edx
       ja       G_M000_IG06
       mov      r12, rsi
       cmp      byte  ptr [rbp+0x30], 0
       je       G_M000_IG11
       xor      eax, eax
       mov      rsi, gword ptr [rbp+0x10]
       test     rsi, rsi
       jne      G_M000_IG07
 
G_M000_IG03:                ;; offset=0x0067
       cmp      eax, r13d
       ja       G_M000_IG06
       mov      edi, eax
       shl      rdi, 4
       add      rdi, r12
       mov      esi, r13d
       sub      esi, eax
       cmp      r15d, esi
       ja       G_M000_IG10
       mov      edx, r15d
       shl      rdx, 4
       cmp      rdx, 0x4000
       ja       G_M000_IG09
       mov      rsi, r14
       call     System.Buffer:BulkMoveWithWriteBarrierInternal(byref,byref,nuint)
       cmp      dword ptr [(reloc 0x7f3aa7409818)], 0
       jne      G_M000_IG08
 
G_M000_IG04:                ;; offset=0x00B0
       vxorps   ymm0, ymm0, ymm0
       vmovdqu  ymmword ptr [rbp-0x68], ymm0
       lea      rdi, [rsp]
       lea      rsi, [rbp-0x68]
       movsq    
       mov      rcx, gword ptr [rsi]
       mov      gword ptr [rsp+0x08], rcx
       add      rsi, 8
       add      rdi, 8
       mov      rcx, gword ptr [rsi]
       mov      gword ptr [rsp+0x10], rcx
       add      rsi, 8
       add      rdi, 8
       movsq    
       mov      r15, bword ptr [rbp+0x38]
       mov      bword ptr [rsp+0x20], r15
       mov      r14d, dword ptr [rbp+0x40]
       mov      dword ptr [rsp+0x28], r14d
       mov      r15, bword ptr [rbp+0x50]
       mov      bword ptr [rsp+0x30], r15
       mov      r15, bword ptr [rbp+0x58]
       mov      bword ptr [rsp+0x38], r15
       lea      rsi, [rbp-0x48]
       mov      qword ptr [rsp+0x40], rsi
       mov      rsi, r12
       mov      edx, r13d
       movzx    r8, byte  ptr [rbp+0x28]
       mov      rdi, rbx
       mov      rcx, gword ptr [rbp+0x20]
       mov      r9, bword ptr [rbp+0x48]
       call     [Lokad.Lython.Runtime.PyExecutableFunction:StartInline(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.Nullable`1[Lokad.Lython.Runtime.BoundFunctionArguments],Lokad.Lython.LythonSourceSpan,bool,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,byref,byref,byref):this]
       nop      
 
G_M000_IG05:                ;; offset=0x012F
       add      rsp, 136
       pop      rbx
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG06:                ;; offset=0x0141
       call     [System.ThrowHelper:ThrowArgumentOutOfRangeException()]
       int3     
 
G_M000_IG07:                ;; offset=0x0148
       mov      dword ptr [rbp-0x2C], 1
       test     r13d, r13d
       je       G_M000_IG12
       mov      rdi, r12
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       xor      edi, edi
       mov      qword ptr [r12+0x08], rdi
       mov      eax, dword ptr [rbp-0x2C]
       jmp      G_M000_IG03
 
G_M000_IG08:                ;; offset=0x016F
       call     CORINFO_HELP_POLL_GC
       jmp      G_M000_IG04
 
G_M000_IG09:                ;; offset=0x0179
       mov      rsi, r14
       call     [System.Buffer:BulkMoveWithWriteBarrierBatch(byref,byref,nuint)]
       jmp      G_M000_IG04
 
G_M000_IG10:                ;; offset=0x0187
       call     [System.ThrowHelper:ThrowArgumentException_DestinationTooShort()]
       int3     
 
G_M000_IG11:                ;; offset=0x018E
       mov      rdi, gword ptr [rbx+0x08]
       mov      rdi, gword ptr [rdi+0x08]
       mov      esi, dword ptr [rdi+0x08]
       cmp      esi, r13d
       ja       SHORT G_M000_IG06
       mov      rdi, gword ptr [rbp+0x18]
       mov      gword ptr [rsp], rdi
       xor      edi, edi
       mov      dword ptr [rsp+0x08], edi
       mov      rdi, gword ptr [rbp+0x10]
       mov      gword ptr [rsp+0x10], rdi
       mov      gword ptr [rsp+0x18], rcx
       mov      bword ptr [rsp+0x20], r14
       mov      dword ptr [rsp+0x28], r15d
       mov      rdi, r12
       xor      rdx, rdx
       xor      ecx, ecx
       mov      r8, gword ptr [rbp+0x20]
       mov      r9, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime:BindFunctionArgumentsInto(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.ReadOnlySpan`1[Lokad.Lython.Runtime.CallArgumentValue],Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.FunctionBindingPlan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,bool,System.Object,Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):int]
       jmp      G_M000_IG04
 
G_M000_IG12:                ;; offset=0x01DD
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
; Total bytes of code 483

; Assembly listing for method Lokad.Lython.Runtime.PyExecutableFunction:StartWideNativeCall(Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,bool,bool,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,byref,byref):this (Tier0)
; Emitting BLENDED_CODE for x64 + VEX on Unix
; Tier0 code
; rbp based frame
; partially interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 400
       lea      rbp, [rsp+0x190]
       vxorps   xmm8, xmm8, xmm8
       vmovdqa  xmmword ptr [rbp-0x140], xmm8
       vmovdqa  xmmword ptr [rbp-0x130], xmm8
       mov      rax, -240
 
G_M000_IG04:                ;; offset=0x002F
       vmovdqa  xmmword ptr [rbp+rax-0x30], xmm8
       vmovdqa  xmmword ptr [rbp+rax-0x20], xmm8
       vmovdqa  xmmword ptr [rbp+rax-0x10], xmm8
       add      rax, 48
       jne      SHORT G_M000_IG04
       mov      gword ptr [rbp-0x08], rdi
       mov      gword ptr [rbp-0x10], rsi
       mov      bword ptr [rbp-0x20], rdx
       mov      qword ptr [rbp-0x18], rcx
       mov      gword ptr [rbp-0x28], r8
       mov      gword ptr [rbp-0x30], r9
 
G_M000_IG02:                ;; offset=0x005F
       vxorps   ymm0, ymm0, ymm0
       vmovdqu  ymmword ptr [rbp-0x130], ymm0
       vmovdqu  ymmword ptr [rbp-0x110], ymm0
       vmovdqu  ymmword ptr [rbp-0xF0], ymm0
       vmovdqu  ymmword ptr [rbp-0xD0], ymm0
       vmovdqu  ymmword ptr [rbp-0xB0], ymm0
       vmovdqu  ymmword ptr [rbp-0x90], ymm0
       vmovdqu  ymmword ptr [rbp-0x70], ymm0
       vmovdqu  ymmword ptr [rbp-0x50], ymm0
       lea      rdi, [rbp-0x130]
       mov      esi, 16
       call     [<PrivateImplementationDetails>:InlineArrayAsSpan[Lokad.Lython.Runtime.PyExecutableFunction+NativeValues,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot](byref,int):System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]]
       mov      bword ptr [rbp-0x140], rax
       mov      qword ptr [rbp-0x138], rdx
       mov      rax, gword ptr [rbp-0x28]
       mov      gword ptr [rsp], rax
       mov      rax, gword ptr [rbp-0x30]
       mov      gword ptr [rsp+0x08], rax
       mov      rax, gword ptr [rbp+0x10]
       mov      gword ptr [rsp+0x10], rax
       movzx    rax, byte  ptr [rbp+0x18]
       mov      dword ptr [rsp+0x18], eax
       movzx    rax, byte  ptr [rbp+0x20]
       mov      dword ptr [rsp+0x20], eax
       lea      rdi, [rsp+0x28]
       lea      rsi, [rbp+0x28]
       mov      rcx, bword ptr [rsi]
       mov      bword ptr [rsp+0x28], rcx
       add      rsi, 8
       add      rdi, 8
       movsq    
       mov      rax, bword ptr [rbp+0x38]
       mov      bword ptr [rsp+0x38], rax
       mov      rax, bword ptr [rbp+0x40]
       mov      bword ptr [rsp+0x40], rax
       mov      rax, bword ptr [rbp+0x48]
       mov      bword ptr [rsp+0x48], rax
       mov      rsi, bword ptr [rbp-0x140]
       mov      rdx, qword ptr [rbp-0x138]
       mov      r8, bword ptr [rbp-0x20]
       mov      r9, qword ptr [rbp-0x18]
       mov      rdi, gword ptr [rbp-0x08]
       mov      rcx, gword ptr [rbp-0x10]
       call     [Lokad.Lython.Runtime.PyExecutableFunction:StartNativeCallWithStorage(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,bool,bool,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,byref,byref):this]
       nop      
 
G_M000_IG03:                ;; offset=0x0142
       add      rsp, 400
       pop      rbp
       ret      
 
; Total bytes of code 331

; Assembly listing for method Lokad.Lython.Runtime.PyExecutableFunction:StartWideNativeCall(Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,bool,bool,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,byref,byref):this (Instrumented Tier0)
; Emitting BLENDED_CODE for x64 + VEX on Unix
; Instrumented Tier0 code
; rbp based frame
; partially interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 400
       lea      rbp, [rsp+0x190]
       vxorps   xmm8, xmm8, xmm8
       vmovdqa  xmmword ptr [rbp-0x140], xmm8
       vmovdqa  xmmword ptr [rbp-0x130], xmm8
       mov      rax, -240
 
G_M000_IG04:                ;; offset=0x002F
       vmovdqa  xmmword ptr [rbp+rax-0x30], xmm8
       vmovdqa  xmmword ptr [rbp+rax-0x20], xmm8
       vmovdqa  xmmword ptr [rbp+rax-0x10], xmm8
       add      rax, 48
       jne      SHORT G_M000_IG04
       mov      gword ptr [rbp-0x08], rdi
       mov      gword ptr [rbp-0x10], rsi
       mov      bword ptr [rbp-0x20], rdx
       mov      qword ptr [rbp-0x18], rcx
       mov      gword ptr [rbp-0x28], r8
       mov      gword ptr [rbp-0x30], r9
 
G_M000_IG02:                ;; offset=0x005F
       vxorps   ymm0, ymm0, ymm0
       vmovdqu  ymmword ptr [rbp-0x130], ymm0
       vmovdqu  ymmword ptr [rbp-0x110], ymm0
       vmovdqu  ymmword ptr [rbp-0xF0], ymm0
       vmovdqu  ymmword ptr [rbp-0xD0], ymm0
       vmovdqu  ymmword ptr [rbp-0xB0], ymm0
       vmovdqu  ymmword ptr [rbp-0x90], ymm0
       vmovdqu  ymmword ptr [rbp-0x70], ymm0
       vmovdqu  ymmword ptr [rbp-0x50], ymm0
       lea      rdi, [rbp-0x130]
       mov      esi, 16
       call     [<PrivateImplementationDetails>:InlineArrayAsSpan[Lokad.Lython.Runtime.PyExecutableFunction+NativeValues,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot](byref,int):System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]]
       mov      bword ptr [rbp-0x140], rax
       mov      qword ptr [rbp-0x138], rdx
       mov      rax, gword ptr [rbp-0x28]
       mov      gword ptr [rsp], rax
       mov      rax, gword ptr [rbp-0x30]
       mov      gword ptr [rsp+0x08], rax
       mov      rax, gword ptr [rbp+0x10]
       mov      gword ptr [rsp+0x10], rax
       movzx    rax, byte  ptr [rbp+0x18]
       mov      dword ptr [rsp+0x18], eax
       movzx    rax, byte  ptr [rbp+0x20]
       mov      dword ptr [rsp+0x20], eax
       lea      rdi, [rsp+0x28]
       lea      rsi, [rbp+0x28]
       mov      rcx, bword ptr [rsi]
       mov      bword ptr [rsp+0x28], rcx
       add      rsi, 8
       add      rdi, 8
       movsq    
       mov      rax, bword ptr [rbp+0x38]
       mov      bword ptr [rsp+0x38], rax
       mov      rax, bword ptr [rbp+0x40]
       mov      bword ptr [rsp+0x40], rax
       mov      rax, bword ptr [rbp+0x48]
       mov      bword ptr [rsp+0x48], rax
       mov      rsi, bword ptr [rbp-0x140]
       mov      rdx, qword ptr [rbp-0x138]
       mov      r8, bword ptr [rbp-0x20]
       mov      r9, qword ptr [rbp-0x18]
       mov      rdi, gword ptr [rbp-0x08]
       mov      rcx, gword ptr [rbp-0x10]
       call     [Lokad.Lython.Runtime.PyExecutableFunction:StartNativeCallWithStorage(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,bool,bool,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,byref,byref):this]
       nop      
 
G_M000_IG03:                ;; offset=0x0142
       add      rsp, 400
       pop      rbp
       ret      
 
; Total bytes of code 331

; Assembly listing for method Lokad.Lython.Runtime.PyExecutableFunction:StartWideNativeCall(Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,bool,bool,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,byref,byref):this (Tier1)
; Emitting BLENDED_CODE for x64 + VEX on Unix
; Tier1 code
; optimized code
; optimized using Synthesized PGO
; rbp based frame
; partially interruptible
; with Synthesized PGO: fgCalledCount is 100
; No PGO data
; 6 inlinees with PGO data; 11 single block inlinees; 1 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       push     r15
       push     r14
       push     r13
       push     rbx
       sub      rsp, 384
       lea      rbp, [rsp+0x1A0]
       xor      eax, eax
       mov      qword ptr [rbp-0x158], rax
       vxorps   xmm8, xmm8, xmm8
       vmovdqa  xmmword ptr [rbp-0x150], xmm8
       mov      rax, -288
 
G_M000_IG13:                ;; offset=0x0037
       vmovdqa  xmmword ptr [rbp+rax-0x20], xmm8
       vmovdqa  xmmword ptr [rbp+rax-0x10], xmm8
       vmovdqa  xmmword ptr [rax+rbp], xmm8
       add      rax, 48
       jne      SHORT G_M000_IG13
       mov      rbx, rdi
       mov      rax, rdx
 
G_M000_IG02:                ;; offset=0x0054
       mov      rdi, gword ptr [rbx+0x40]
       mov      r15d, dword ptr [rdi+0xD4]
       cmp      r15d, 16
       ja       G_M000_IG06
       cmp      byte  ptr [rbp+0x20], 0
       je       G_M000_IG11
       xor      edi, edi
       test     r8, r8
       jne      G_M000_IG07
 
G_M000_IG03:                ;; offset=0x007E
       cmp      edi, r15d
       ja       G_M000_IG06
       lea      rsi, bword ptr [rbp-0x120]
       mov      edx, edi
       shl      rdx, 4
       add      rdx, rsi
       mov      esi, r15d
       sub      esi, edi
       cmp      ecx, esi
       ja       G_M000_IG10
       mov      edi, ecx
       shl      rdi, 4
       mov      rcx, rdi
       cmp      rcx, 0x4000
       ja       G_M000_IG09
       mov      rdi, rdx
       mov      rsi, rax
       mov      rdx, rcx
       call     System.Buffer:BulkMoveWithWriteBarrierInternal(byref,byref,nuint)
       cmp      dword ptr [(reloc 0x7f3aa7409818)], 0
       jne      G_M000_IG08
 
G_M000_IG04:                ;; offset=0x00D5
       vxorps   ymm0, ymm0, ymm0
       vmovdqu  ymmword ptr [rbp-0x140], ymm0
       lea      rdi, [rsp]
       lea      rsi, [rbp-0x140]
       movsq    
       mov      rcx, gword ptr [rsi]
       mov      gword ptr [rsp+0x08], rcx
       add      rsi, 8
       add      rdi, 8
       mov      rcx, gword ptr [rsi]
       mov      gword ptr [rsp+0x10], rcx
       add      rsi, 8
       add      rdi, 8
       movsq    
       mov      r14, bword ptr [rbp+0x28]
       mov      bword ptr [rsp+0x20], r14
       mov      r13d, dword ptr [rbp+0x30]
       mov      dword ptr [rsp+0x28], r13d
       mov      r14, bword ptr [rbp+0x40]
       mov      bword ptr [rsp+0x30], r14
       mov      r14, bword ptr [rbp+0x48]
       mov      bword ptr [rsp+0x38], r14
       lea      rsi, [rbp-0x158]
       mov      qword ptr [rsp+0x40], rsi
       lea      rsi, bword ptr [rbp-0x120]
       mov      edx, r15d
       movzx    r8, byte  ptr [rbp+0x18]
       mov      rdi, rbx
       mov      rcx, gword ptr [rbp+0x10]
       mov      r9, bword ptr [rbp+0x38]
       call     [Lokad.Lython.Runtime.PyExecutableFunction:StartInline(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.Nullable`1[Lokad.Lython.Runtime.BoundFunctionArguments],Lokad.Lython.LythonSourceSpan,bool,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,byref,byref,byref):this]
       nop      
 
G_M000_IG05:                ;; offset=0x0161
       add      rsp, 384
       pop      rbx
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG06:                ;; offset=0x0171
       call     [System.ThrowHelper:ThrowArgumentOutOfRangeException()]
       int3     
 
G_M000_IG07:                ;; offset=0x0178
       mov      edi, 1
       test     r15d, r15d
       je       G_M000_IG12
       mov      gword ptr [rbp-0x120], r8
       xor      esi, esi
       mov      qword ptr [rbp-0x118], rsi
       jmp      G_M000_IG03
 
G_M000_IG08:                ;; offset=0x019B
       call     CORINFO_HELP_POLL_GC
       jmp      G_M000_IG04
 
G_M000_IG09:                ;; offset=0x01A5
       mov      rdi, rdx
       mov      rsi, rax
       mov      rdx, rcx
       call     [System.Buffer:BulkMoveWithWriteBarrierBatch(byref,byref,nuint)]
       jmp      G_M000_IG04
 
G_M000_IG10:                ;; offset=0x01B9
       call     [System.ThrowHelper:ThrowArgumentException_DestinationTooShort()]
       int3     
 
G_M000_IG11:                ;; offset=0x01C0
       mov      rdi, gword ptr [rbx+0x08]
       mov      rdi, gword ptr [rdi+0x08]
       mov      edx, dword ptr [rdi+0x08]
       cmp      edx, r15d
       ja       SHORT G_M000_IG06
       mov      gword ptr [rsp], r9
       xor      edi, edi
       mov      dword ptr [rsp+0x08], edi
       mov      gword ptr [rsp+0x10], r8
       mov      gword ptr [rsp+0x18], rsi
       mov      bword ptr [rsp+0x20], rax
       mov      dword ptr [rsp+0x28], ecx
       lea      rdi, bword ptr [rbp-0x120]
       mov      esi, edx
       xor      rdx, rdx
       xor      ecx, ecx
       mov      r8, gword ptr [rbp+0x10]
       mov      r9, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime:BindFunctionArgumentsInto(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.ReadOnlySpan`1[Lokad.Lython.Runtime.CallArgumentValue],Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.FunctionBindingPlan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,bool,System.Object,Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):int]
       jmp      G_M000_IG04
 
G_M000_IG12:                ;; offset=0x020C
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
; Total bytes of code 530

