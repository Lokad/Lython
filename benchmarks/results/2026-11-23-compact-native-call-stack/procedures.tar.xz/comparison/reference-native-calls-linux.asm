; Assembly listing for method Lokad.Lython.Runtime.PyExecutableFunction:StartNativeCall(Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,bool,bool,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,byref,byref):this (Tier0)
; Emitting BLENDED_CODE for x64 + VEX on Unix
; Tier0 code
; rbp based frame
; partially interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 592
       lea      rbp, [rsp+0x250]
       vxorps   xmm8, xmm8, xmm8
       vmovdqa  xmmword ptr [rbp-0x200], xmm8
       vmovdqa  xmmword ptr [rbp-0x1F0], xmm8
       mov      rax, -432
 
G_M000_IG18:                ;; offset=0x002F
       vmovdqa  xmmword ptr [rbp+rax-0x30], xmm8
       vmovdqa  xmmword ptr [rbp+rax-0x20], xmm8
       vmovdqa  xmmword ptr [rbp+rax-0x10], xmm8
       add      rax, 48
       jne      SHORT G_M000_IG18
       mov      gword ptr [rbp-0x08], rdi
       mov      gword ptr [rbp-0x10], rsi
       mov      bword ptr [rbp-0x20], rdx
       mov      qword ptr [rbp-0x18], rcx
       mov      gword ptr [rbp-0x28], r8
       mov      gword ptr [rbp-0x30], r9
 
G_M000_IG02:                ;; offset=0x005F
       cmp      gword ptr [rbp-0x28], 0
       jne      G_M000_IG07
       mov      rdi, gword ptr [rbp-0x08]
       call     [Lokad.Lython.Runtime.PyFunctionBase:get_CodeObject():Lokad.Lython.Frontend.ExecutableCodeObject:this]
       mov      rdi, rax
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_HasDirectIntegerReturn():bool:this]
       test     eax, eax
       je       G_M000_IG07
       movzx    rax, byte  ptr [rbp+0x20]
       test     eax, eax
       jne      SHORT G_M000_IG03
       mov      rax, bword ptr [rbp+0x40]
       mov      bword ptr [rsp], rax
       mov      rdx, bword ptr [rbp-0x20]
       mov      rcx, qword ptr [rbp-0x18]
       mov      rdi, gword ptr [rbp-0x08]
       mov      rsi, gword ptr [rbp-0x10]
       mov      r8, gword ptr [rbp-0x30]
       mov      r9, gword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.PyExecutableFunction:TryStartPreparedIntegerReturn(Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,byref):bool:this]
       mov      dword ptr [rbp-0x1EC], eax
       jmp      SHORT G_M000_IG05
 
G_M000_IG03:                ;; offset=0x00BD
       mov      eax, dword ptr [rbp-0x18]
       mov      dword ptr [rbp-0x1E8], eax
       mov      rdi, gword ptr [rbp-0x08]
       call     [Lokad.Lython.Runtime.PyFunctionBase:get_CodeObject():Lokad.Lython.Frontend.ExecutableCodeObject:this]
       mov      rdi, rax
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_FirstTemporarySlot():int:this]
       cmp      eax, dword ptr [rbp-0x1E8]
       jne      SHORT G_M000_IG04
       mov      rsi, bword ptr [rbp-0x20]
       mov      rdx, qword ptr [rbp-0x18]
       lea      rdi, [rbp-0x200]
       call     [Lokad.Lython.Runtime.LythonRuntime+SlotIntegerOperands:.ctor(System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):this]
       mov      rsi, bword ptr [rbp-0x200]
       mov      rdx, qword ptr [rbp-0x1F8]
       mov      rdi, gword ptr [rbp-0x08]
       mov      rcx, gword ptr [rbp+0x10]
       mov      r8, bword ptr [rbp+0x40]
       call     [Lokad.Lython.Runtime.PyExecutableFunction:TryStartDirectIntegerReturn[Lokad.Lython.Runtime.LythonRuntime+SlotIntegerOperands](Lokad.Lython.Runtime.LythonRuntime+SlotIntegerOperands,Lokad.Lython.LythonSourceSpan,byref):bool:this]
       mov      dword ptr [rbp-0x1EC], eax
       jmp      SHORT G_M000_IG05
 
G_M000_IG04:                ;; offset=0x0120
       xor      eax, eax
       mov      dword ptr [rbp-0x1EC], eax
 
G_M000_IG05:                ;; offset=0x0128
       cmp      dword ptr [rbp-0x1EC], 0
       je       SHORT G_M000_IG07
       mov      rax, bword ptr [rbp+0x38]
       mov      byte  ptr [rax], 0
       mov      rax, bword ptr [rbp+0x48]
       xor      rcx, rcx
       mov      gword ptr [rax], rcx
 
G_M000_IG06:                ;; offset=0x0141
       add      rsp, 592
       pop      rbp
       ret      
 
G_M000_IG07:                ;; offset=0x014A
       vxorps   ymm0, ymm0, ymm0
       vmovdqu  ymmword ptr [rbp-0x130], ymm0
       vmovdqu  ymmword ptr [rbp-0x110], ymm0
       vmovdqu  ymmword ptr [rbp-0xF0], ymm0
       vmovdqu  ymmword ptr [rbp-0xD0], ymm0
       vmovdqu  ymmword ptr [rbp-0xB0], ymm0
       vmovdqu  ymmword ptr [rbp-0x90], ymm0
       vmovdqu  ymmword ptr [rbp-0x70], ymm0
       vmovdqu  ymmword ptr [rbp-0x50], ymm0
       lea      rdi, [rbp-0x130]
       mov      esi, 16
       call     [<PrivateImplementationDetails>:InlineArrayAsSpan[Lokad.Lython.Runtime.PyExecutableFunction+NativeValues,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot](byref,int):System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]]
       mov      bword ptr [rbp-0x1A0], rax
       mov      qword ptr [rbp-0x198], rdx
 
G_M000_IG08:                ;; offset=0x01A8
       vmovdqu  xmm0, xmmword ptr [rbp-0x1A0]
       vmovdqu  xmmword ptr [rbp-0x140], xmm0
 
G_M000_IG09:                ;; offset=0x01B8
       mov      rdi, gword ptr [rbp-0x08]
       call     [Lokad.Lython.Runtime.PyFunctionBase:get_CodeObject():Lokad.Lython.Frontend.ExecutableCodeObject:this]
       mov      rdi, rax
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_ValueStorageCapacity():int:this]
       mov      dword ptr [rbp-0x204], eax
       mov      edx, dword ptr [rbp-0x204]
       lea      rdi, [rbp-0x140]
       xor      esi, esi
       call     [System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:Slice(int,int):System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:this]
       mov      bword ptr [rbp-0x1B0], rax
       mov      qword ptr [rbp-0x1A8], rdx
 
G_M000_IG10:                ;; offset=0x01F6
       vmovdqu  xmm0, xmmword ptr [rbp-0x1B0]
       vmovdqu  xmmword ptr [rbp-0x140], xmm0
 
G_M000_IG11:                ;; offset=0x0206
       movzx    rax, byte  ptr [rbp+0x20]
       test     eax, eax
       je       G_M000_IG13
       xor      eax, eax
       mov      dword ptr [rbp-0x144], eax
       cmp      gword ptr [rbp-0x28], 0
       je       SHORT G_M000_IG12
       mov      eax, dword ptr [rbp-0x144]
       mov      dword ptr [rbp-0x1E4], eax
       mov      eax, dword ptr [rbp-0x144]
       inc      eax
       mov      dword ptr [rbp-0x144], eax
       mov      eax, dword ptr [rbp-0x138]
       cmp      dword ptr [rbp-0x1E4], eax
       jae      G_M000_IG17
       mov      eax, dword ptr [rbp-0x1E4]
       shl      rax, 4
       mov      rdi, rax
       add      rdi, bword ptr [rbp-0x140]
       mov      rsi, gword ptr [rbp-0x28]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:set_Object(System.Object):this]
 
G_M000_IG12:                ;; offset=0x026B
       lea      rdi, [rbp-0x140]
       mov      esi, dword ptr [rbp-0x144]
       call     [System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:Slice(int):System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:this]
       mov      bword ptr [rbp-0x1E0], rax
       mov      qword ptr [rbp-0x1D8], rdx
       mov      rsi, bword ptr [rbp-0x1E0]
       mov      rdx, qword ptr [rbp-0x1D8]
       lea      rdi, [rbp-0x20]
       call     [System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:CopyTo(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):this]
       jmp      G_M000_IG14
 
G_M000_IG13:                ;; offset=0x02A9
       mov      rdi, gword ptr [rbp-0x08]
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_ParameterCount():int:this]
       mov      dword ptr [rbp-0x208], eax
       mov      edx, dword ptr [rbp-0x208]
       lea      rdi, [rbp-0x140]
       xor      esi, esi
       call     [System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:Slice(int,int):System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:this]
       mov      bword ptr [rbp-0x1C0], rax
       mov      qword ptr [rbp-0x1B8], rdx
       vxorps   xmm0, xmm0, xmm0
       vmovdqu  xmmword ptr [rbp-0x158], xmm0
       mov      rax, gword ptr [rbp-0x30]
       mov      gword ptr [rsp], rax
       xor      eax, eax
       mov      dword ptr [rsp+0x08], eax
       mov      rax, gword ptr [rbp-0x28]
       mov      gword ptr [rsp+0x10], rax
       mov      rax, gword ptr [rbp-0x10]
       mov      gword ptr [rsp+0x18], rax
       lea      rdi, [rsp+0x20]
       lea      rsi, [rbp-0x20]
       mov      rcx, bword ptr [rsi]
       mov      bword ptr [rsp+0x20], rcx
       add      rsi, 8
       add      rdi, 8
       movsq    
       mov      rdi, bword ptr [rbp-0x1C0]
       mov      rsi, qword ptr [rbp-0x1B8]
       mov      rdx, bword ptr [rbp-0x158]
       mov      rcx, qword ptr [rbp-0x150]
       mov      r8, gword ptr [rbp+0x10]
       mov      r9, gword ptr [rbp-0x08]
       call     [Lokad.Lython.Runtime.LythonRuntime:BindFunctionArgumentsInto(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.ReadOnlySpan`1[Lokad.Lython.Runtime.CallArgumentValue],Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.FunctionBindingPlan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,bool,System.Object,Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):int]
 
G_M000_IG14:                ;; offset=0x034D
       vmovdqu  xmm0, xmmword ptr [rbp-0x140]
       vmovdqu  xmmword ptr [rbp-0x1D0], xmm0
 
G_M000_IG15:                ;; offset=0x035D
       vxorps   ymm0, ymm0, ymm0
       vmovdqu  ymmword ptr [rbp-0x190], ymm0
       lea      rdi, [rsp]
       lea      rsi, [rbp-0x190]
       movsq    
       mov      rcx, gword ptr [rsi]
       mov      gword ptr [rsp+0x08], rcx
       add      rsi, 8
       add      rdi, 8
       mov      rcx, gword ptr [rsi]
       mov      gword ptr [rsp+0x10], rcx
       add      rsi, 8
       add      rdi, 8
       movsq    
       lea      rdi, [rsp+0x20]
       lea      rsi, [rbp+0x28]
       mov      rcx, bword ptr [rsi]
       mov      bword ptr [rsp+0x20], rcx
       add      rsi, 8
       add      rdi, 8
       movsq    
       mov      rax, bword ptr [rbp+0x40]
       mov      bword ptr [rsp+0x30], rax
       mov      rax, bword ptr [rbp+0x48]
       mov      bword ptr [rsp+0x38], rax
       lea      rax, [rbp-0x170]
       mov      qword ptr [rsp+0x40], rax
       movzx    r8, byte  ptr [rbp+0x18]
       mov      rsi, bword ptr [rbp-0x1D0]
       mov      rdx, qword ptr [rbp-0x1C8]
       mov      rdi, gword ptr [rbp-0x08]
       mov      rcx, gword ptr [rbp+0x10]
       mov      r9, bword ptr [rbp+0x38]
       call     [Lokad.Lython.Runtime.PyExecutableFunction:StartInline(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.Nullable`1[Lokad.Lython.Runtime.BoundFunctionArguments],Lokad.Lython.LythonSourceSpan,bool,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,byref,byref,byref):this]
       nop      
 
G_M000_IG16:                ;; offset=0x03F7
       add      rsp, 592
       pop      rbp
       ret      
 
G_M000_IG17:                ;; offset=0x0400
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
; Total bytes of code 1030

; Assembly listing for method Lokad.Lython.Runtime.PyExecutableFunction:StartNativeCall(Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,bool,bool,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,byref,byref):this (Instrumented Tier0)
; Emitting BLENDED_CODE for x64 + VEX on Unix
; Instrumented Tier0 code
; rbp based frame
; partially interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 592
       lea      rbp, [rsp+0x250]
       vxorps   xmm8, xmm8, xmm8
       vmovdqa  xmmword ptr [rbp-0x200], xmm8
       vmovdqa  xmmword ptr [rbp-0x1F0], xmm8
       mov      rax, -432
 
G_M000_IG21:                ;; offset=0x002F
       vmovdqa  xmmword ptr [rbp+rax-0x30], xmm8
       vmovdqa  xmmword ptr [rbp+rax-0x20], xmm8
       vmovdqa  xmmword ptr [rbp+rax-0x10], xmm8
       add      rax, 48
       jne      SHORT G_M000_IG21
       mov      gword ptr [rbp-0x08], rdi
       mov      gword ptr [rbp-0x10], rsi
       mov      bword ptr [rbp-0x20], rdx
       mov      qword ptr [rbp-0x18], rcx
       mov      gword ptr [rbp-0x28], r8
       mov      gword ptr [rbp-0x30], r9
 
G_M000_IG02:                ;; offset=0x005F
       cmp      gword ptr [rbp-0x28], 0
       jne      G_M000_IG09
       mov      rdi, gword ptr [rbp-0x08]
       call     [Lokad.Lython.Runtime.PyFunctionBase:get_CodeObject():Lokad.Lython.Frontend.ExecutableCodeObject:this]
       mov      rdi, rax
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_HasDirectIntegerReturn():bool:this]
       test     eax, eax
       je       SHORT G_M000_IG03
       movzx    rax, byte  ptr [rbp+0x20]
       test     eax, eax
       jne      SHORT G_M000_IG04
       mov      rax, bword ptr [rbp+0x40]
       mov      bword ptr [rsp], rax
       mov      rdx, bword ptr [rbp-0x20]
       mov      rcx, qword ptr [rbp-0x18]
       mov      rdi, gword ptr [rbp-0x08]
       mov      rsi, gword ptr [rbp-0x10]
       mov      r8, gword ptr [rbp-0x30]
       mov      r9, gword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.PyExecutableFunction:TryStartPreparedIntegerReturn(Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,byref):bool:this]
       mov      dword ptr [rbp-0x1EC], eax
       jmp      G_M000_IG06
 
G_M000_IG03:                ;; offset=0x00BC
       mov      rdi, 0x7FA2F2C50158
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG09
 
G_M000_IG04:                ;; offset=0x00D0
       mov      eax, dword ptr [rbp-0x18]
       mov      dword ptr [rbp-0x1E8], eax
       mov      rdi, gword ptr [rbp-0x08]
       call     [Lokad.Lython.Runtime.PyFunctionBase:get_CodeObject():Lokad.Lython.Frontend.ExecutableCodeObject:this]
       mov      rdi, rax
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_FirstTemporarySlot():int:this]
       cmp      eax, dword ptr [rbp-0x1E8]
       jne      SHORT G_M000_IG05
       mov      rdi, 0x7FA2F2C5015C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rsi, bword ptr [rbp-0x20]
       mov      rdx, qword ptr [rbp-0x18]
       lea      rdi, [rbp-0x200]
       call     [Lokad.Lython.Runtime.LythonRuntime+SlotIntegerOperands:.ctor(System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):this]
       mov      rsi, bword ptr [rbp-0x200]
       mov      rdx, qword ptr [rbp-0x1F8]
       mov      rdi, gword ptr [rbp-0x08]
       mov      rcx, gword ptr [rbp+0x10]
       mov      r8, bword ptr [rbp+0x40]
       call     [Lokad.Lython.Runtime.PyExecutableFunction:TryStartDirectIntegerReturn[Lokad.Lython.Runtime.LythonRuntime+SlotIntegerOperands](Lokad.Lython.Runtime.LythonRuntime+SlotIntegerOperands,Lokad.Lython.LythonSourceSpan,byref):bool:this]
       mov      dword ptr [rbp-0x1EC], eax
       jmp      SHORT G_M000_IG06
 
G_M000_IG05:                ;; offset=0x0142
       mov      rdi, 0x7FA2F2C50160
       call     CORINFO_HELP_COUNTPROFILE32
       xor      eax, eax
       mov      dword ptr [rbp-0x1EC], eax
 
G_M000_IG06:                ;; offset=0x0159
       cmp      dword ptr [rbp-0x1EC], 0
       je       SHORT G_M000_IG08
       mov      rdi, 0x7FA2F2C50164
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x38]
       mov      byte  ptr [rax], 0
       mov      rax, bword ptr [rbp+0x48]
       xor      rcx, rcx
       mov      gword ptr [rax], rcx
 
G_M000_IG07:                ;; offset=0x0181
       add      rsp, 592
       pop      rbp
       ret      
 
G_M000_IG08:                ;; offset=0x018A
       mov      rdi, 0x7FA2F2C50168
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG09:                ;; offset=0x0199
       vxorps   ymm0, ymm0, ymm0
       vmovdqu  ymmword ptr [rbp-0x130], ymm0
       vmovdqu  ymmword ptr [rbp-0x110], ymm0
       vmovdqu  ymmword ptr [rbp-0xF0], ymm0
       vmovdqu  ymmword ptr [rbp-0xD0], ymm0
       vmovdqu  ymmword ptr [rbp-0xB0], ymm0
       vmovdqu  ymmword ptr [rbp-0x90], ymm0
       vmovdqu  ymmword ptr [rbp-0x70], ymm0
       vmovdqu  ymmword ptr [rbp-0x50], ymm0
       lea      rdi, [rbp-0x130]
       mov      esi, 16
       call     [<PrivateImplementationDetails>:InlineArrayAsSpan[Lokad.Lython.Runtime.PyExecutableFunction+NativeValues,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot](byref,int):System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]]
       mov      bword ptr [rbp-0x1A0], rax
       mov      qword ptr [rbp-0x198], rdx
 
G_M000_IG10:                ;; offset=0x01F7
       vmovdqu  xmm0, xmmword ptr [rbp-0x1A0]
       vmovdqu  xmmword ptr [rbp-0x140], xmm0
 
G_M000_IG11:                ;; offset=0x0207
       mov      rdi, gword ptr [rbp-0x08]
       call     [Lokad.Lython.Runtime.PyFunctionBase:get_CodeObject():Lokad.Lython.Frontend.ExecutableCodeObject:this]
       mov      rdi, rax
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_ValueStorageCapacity():int:this]
       mov      dword ptr [rbp-0x204], eax
       mov      edx, dword ptr [rbp-0x204]
       lea      rdi, [rbp-0x140]
       xor      esi, esi
       call     [System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:Slice(int,int):System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:this]
       mov      bword ptr [rbp-0x1B0], rax
       mov      qword ptr [rbp-0x1A8], rdx
 
G_M000_IG12:                ;; offset=0x0245
       vmovdqu  xmm0, xmmword ptr [rbp-0x1B0]
       vmovdqu  xmmword ptr [rbp-0x140], xmm0
 
G_M000_IG13:                ;; offset=0x0255
       movzx    rax, byte  ptr [rbp+0x20]
       test     eax, eax
       je       G_M000_IG15
       xor      eax, eax
       mov      dword ptr [rbp-0x144], eax
       cmp      gword ptr [rbp-0x28], 0
       je       SHORT G_M000_IG14
       mov      rdi, 0x7FA2F2C5016C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      eax, dword ptr [rbp-0x144]
       mov      dword ptr [rbp-0x1E4], eax
       mov      eax, dword ptr [rbp-0x144]
       inc      eax
       mov      dword ptr [rbp-0x144], eax
       mov      eax, dword ptr [rbp-0x138]
       cmp      dword ptr [rbp-0x1E4], eax
       jae      G_M000_IG20
       mov      eax, dword ptr [rbp-0x1E4]
       shl      rax, 4
       mov      rdi, rax
       add      rdi, bword ptr [rbp-0x140]
       mov      rsi, gword ptr [rbp-0x28]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:set_Object(System.Object):this]
 
G_M000_IG14:                ;; offset=0x02C9
       lea      rdi, [rbp-0x140]
       mov      esi, dword ptr [rbp-0x144]
       call     [System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:Slice(int):System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:this]
       mov      bword ptr [rbp-0x1E0], rax
       mov      qword ptr [rbp-0x1D8], rdx
       mov      rsi, bword ptr [rbp-0x1E0]
       mov      rdx, qword ptr [rbp-0x1D8]
       lea      rdi, [rbp-0x20]
       call     [System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:CopyTo(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):this]
       jmp      G_M000_IG16
 
G_M000_IG15:                ;; offset=0x0307
       mov      rdi, 0x7FA2F2C50170
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, gword ptr [rbp-0x08]
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_ParameterCount():int:this]
       mov      dword ptr [rbp-0x208], eax
       mov      edx, dword ptr [rbp-0x208]
       lea      rdi, [rbp-0x140]
       xor      esi, esi
       call     [System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:Slice(int,int):System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:this]
       mov      bword ptr [rbp-0x1C0], rax
       mov      qword ptr [rbp-0x1B8], rdx
       vxorps   xmm0, xmm0, xmm0
       vmovdqu  xmmword ptr [rbp-0x158], xmm0
       mov      rax, gword ptr [rbp-0x30]
       mov      gword ptr [rsp], rax
       xor      eax, eax
       mov      dword ptr [rsp+0x08], eax
       mov      rax, gword ptr [rbp-0x28]
       mov      gword ptr [rsp+0x10], rax
       mov      rax, gword ptr [rbp-0x10]
       mov      gword ptr [rsp+0x18], rax
       lea      rdi, [rsp+0x20]
       lea      rsi, [rbp-0x20]
       mov      rcx, bword ptr [rsi]
       mov      bword ptr [rsp+0x20], rcx
       add      rsi, 8
       add      rdi, 8
       movsq    
       mov      rdi, bword ptr [rbp-0x1C0]
       mov      rsi, qword ptr [rbp-0x1B8]
       mov      rdx, bword ptr [rbp-0x158]
       mov      rcx, qword ptr [rbp-0x150]
       mov      r8, gword ptr [rbp+0x10]
       mov      r9, gword ptr [rbp-0x08]
       call     [Lokad.Lython.Runtime.LythonRuntime:BindFunctionArgumentsInto(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.ReadOnlySpan`1[Lokad.Lython.Runtime.CallArgumentValue],Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.FunctionBindingPlan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,bool,System.Object,Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):int]
 
G_M000_IG16:                ;; offset=0x03BA
       mov      rdi, 0x7FA2F2C50174
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG17:                ;; offset=0x03C9
       vmovdqu  xmm0, xmmword ptr [rbp-0x140]
       vmovdqu  xmmword ptr [rbp-0x1D0], xmm0
 
G_M000_IG18:                ;; offset=0x03D9
       vxorps   ymm0, ymm0, ymm0
       vmovdqu  ymmword ptr [rbp-0x190], ymm0
       lea      rdi, [rsp]
       lea      rsi, [rbp-0x190]
       movsq    
       mov      rcx, gword ptr [rsi]
       mov      gword ptr [rsp+0x08], rcx
       add      rsi, 8
       add      rdi, 8
       mov      rcx, gword ptr [rsi]
       mov      gword ptr [rsp+0x10], rcx
       add      rsi, 8
       add      rdi, 8
       movsq    
       lea      rdi, [rsp+0x20]
       lea      rsi, [rbp+0x28]
       mov      rcx, bword ptr [rsi]
       mov      bword ptr [rsp+0x20], rcx
       add      rsi, 8
       add      rdi, 8
       movsq    
       mov      rax, bword ptr [rbp+0x40]
       mov      bword ptr [rsp+0x30], rax
       mov      rax, bword ptr [rbp+0x48]
       mov      bword ptr [rsp+0x38], rax
       lea      rax, [rbp-0x170]
       mov      qword ptr [rsp+0x40], rax
       movzx    r8, byte  ptr [rbp+0x18]
       mov      rsi, bword ptr [rbp-0x1D0]
       mov      rdx, qword ptr [rbp-0x1C8]
       mov      rdi, gword ptr [rbp-0x08]
       mov      rcx, gword ptr [rbp+0x10]
       mov      r9, bword ptr [rbp+0x38]
       call     [Lokad.Lython.Runtime.PyExecutableFunction:StartInline(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.Nullable`1[Lokad.Lython.Runtime.BoundFunctionArguments],Lokad.Lython.LythonSourceSpan,bool,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,byref,byref,byref):this]
       nop      
 
G_M000_IG19:                ;; offset=0x0473
       add      rsp, 592
       pop      rbp
       ret      
 
G_M000_IG20:                ;; offset=0x047C
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
; Total bytes of code 1154

; Assembly listing for method Lokad.Lython.Runtime.PyExecutableFunction:StartNativeCall(Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,bool,bool,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,byref,byref):this (Tier1)
; Emitting BLENDED_CODE for x64 + VEX on Unix
; Tier1 code
; optimized code
; optimized using Synthesized PGO
; rbp based frame
; partially interruptible
; with Synthesized PGO: fgCalledCount is 19325
; 7 inlinees with PGO data; 24 single block inlinees; 1 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       push     r15
       push     r14
       push     r13
       push     r12
       push     rbx
       sub      rsp, 440
       lea      rbp, [rsp+0x1E0]
       xor      eax, eax
       mov      qword ptr [rbp-0x178], rax
       vxorps   xmm8, xmm8, xmm8
       vmovdqa  xmmword ptr [rbp-0x170], xmm8
       vmovdqa  xmmword ptr [rbp-0x160], xmm8
       mov      rax, -288
 
G_M000_IG27:                ;; offset=0x0041
       vmovdqa  xmmword ptr [rbp+rax-0x30], xmm8
       vmovdqa  xmmword ptr [rbp+rax-0x20], xmm8
       vmovdqa  xmmword ptr [rbp+rax-0x10], xmm8
       add      rax, 48
       jne      SHORT G_M000_IG27
       mov      qword ptr [rbp-0x30], rax
       mov      bword ptr [rbp-0x190], rdx
       mov      rbx, rdi
       mov      r13, rsi
       mov      r14d, ecx
       mov      r15, r8
       mov      r12, r9
       mov      rcx, bword ptr [rbp+0x40]
 
G_M000_IG02:                ;; offset=0x0077
       test     r15, r15
       jne      G_M000_IG17
 
G_M000_IG03:                ;; offset=0x0080
       mov      rdi, gword ptr [rbx+0x40]
       cmp      byte  ptr [rdi+0xE0], 0
       jne      G_M000_IG10
 
G_M000_IG04:                ;; offset=0x0091
       mov      rax, bword ptr [rbp-0x190]
 
G_M000_IG05:                ;; offset=0x0098
       vxorps   ymm0, ymm0, ymm0
       vmovdqu  ymmword ptr [rbp-0x128], ymm0
       vmovdqu  ymmword ptr [rbp-0x108], ymm0
       vmovdqu  ymmword ptr [rbp-0xE8], ymm0
       vmovdqu  ymmword ptr [rbp-0xC8], ymm0
       vmovdqu  ymmword ptr [rbp-0xA8], ymm0
       vmovdqu  ymmword ptr [rbp-0x88], ymm0
       vmovdqu  ymmword ptr [rbp-0x68], ymm0
       vmovdqu  ymmword ptr [rbp-0x48], ymm0
       mov      rdi, gword ptr [rbx+0x40]
       mov      r8d, dword ptr [rdi+0xD4]
       mov      dword ptr [rbp-0x17C], r8d
       cmp      r8d, 16
       ja       G_M000_IG20
       cmp      byte  ptr [rbp+0x20], 0
       je       G_M000_IG25
       xor      edi, edi
       test     r15, r15
       jne      G_M000_IG21
 
G_M000_IG06:                ;; offset=0x0107
       cmp      edi, r8d
       ja       G_M000_IG20
       lea      rsi, bword ptr [rbp-0x128]
       mov      edx, edi
       shl      rdx, 4
       add      rdx, rsi
       mov      esi, r8d
       sub      esi, edi
       cmp      r14d, esi
       ja       G_M000_IG24
       mov      edi, r14d
       shl      rdi, 4
       mov      r9, rdi
       cmp      r9, 0x4000
       ja       G_M000_IG23
       mov      bword ptr [rbp+0x40], rcx
       mov      rdi, rdx
       mov      rsi, rax
       mov      rdx, r9
       call     System.Buffer:BulkMoveWithWriteBarrierInternal(byref,byref,nuint)
       cmp      dword ptr [(reloc 0x7fa36fa4c818)], 0
       jne      G_M000_IG22
 
G_M000_IG07:                ;; offset=0x0164
       vxorps   ymm0, ymm0, ymm0
       vmovdqu  ymmword ptr [rbp-0x160], ymm0
       lea      rdi, [rsp]
       lea      rsi, [rbp-0x160]
       movsq    
       mov      rcx, gword ptr [rsi]
       mov      gword ptr [rsp+0x08], rcx
       add      rsi, 8
       add      rdi, 8
       mov      rcx, gword ptr [rsi]
       mov      gword ptr [rsp+0x10], rcx
       add      rsi, 8
       add      rdi, 8
       movsq    
       mov      r15, bword ptr [rbp+0x28]
       mov      bword ptr [rsp+0x20], r15
       mov      r14d, dword ptr [rbp+0x30]
       mov      dword ptr [rsp+0x28], r14d
       mov      r15, bword ptr [rbp+0x40]
       mov      bword ptr [rsp+0x30], r15
       mov      r13, bword ptr [rbp+0x48]
       mov      bword ptr [rsp+0x38], r13
       lea      rsi, [rbp-0x140]
       mov      qword ptr [rsp+0x40], rsi
       lea      rsi, bword ptr [rbp-0x128]
       mov      edx, dword ptr [rbp-0x17C]
       movzx    r8, byte  ptr [rbp+0x18]
       mov      rdi, rbx
       mov      rcx, gword ptr [rbp+0x10]
       mov      r9, bword ptr [rbp+0x38]
       call     [Lokad.Lython.Runtime.PyExecutableFunction:StartInline(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.Nullable`1[Lokad.Lython.Runtime.BoundFunctionArguments],Lokad.Lython.LythonSourceSpan,bool,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,byref,byref,byref):this]
 
G_M000_IG08:                ;; offset=0x01F2
       nop      
 
G_M000_IG09:                ;; offset=0x01F3
       add      rsp, 440
       pop      rbx
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG10:                ;; offset=0x0205
       cmp      byte  ptr [rbp+0x20], 0
       jne      G_M000_IG19
       xor      edi, edi
       mov      bword ptr [rbp+0x40], rcx
       mov      qword ptr [rcx], rdi
       mov      qword ptr [rcx+0x08], rdi
       cmp      byte  ptr [r13+0x34], 0
       je       G_M000_IG16
       mov      rdi, gword ptr [rbx+0x08]
       mov      rdi, gword ptr [rdi+0x08]
       mov      edi, dword ptr [rdi+0x08]
       mov      rsi, gword ptr [rbx+0x40]
       cmp      edi, dword ptr [rsi+0xC4]
       jne      G_M000_IG15
       mov      rdi, rbx
       mov      esi, r14d
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:HasPreparedOmittedArguments(int):bool:this]
       test     eax, eax
       je       G_M000_IG13
       mov      rax, gword ptr [r12+0x98]
       mov      gword ptr [rbp-0x188], rax
       cmp      byte  ptr [rax], al
       mov      rdi, rax
       call     [Lokad.Lython.Runtime.ExecutionState:get_CanContinue():bool:this]
       test     eax, eax
       je       G_M000_IG18
 
G_M000_IG11:                ;; offset=0x0278
       mov      gword ptr [rbp-0x178], rbx
       mov      rax, bword ptr [rbp-0x190]
       mov      bword ptr [rbp-0x170], rax
       mov      dword ptr [rbp-0x168], r14d
       lea      rdi, [rsp]
       lea      rsi, [rbp-0x178]
       mov      rcx, gword ptr [rsi]
       mov      gword ptr [rsp], rcx
       add      rsi, 8
       add      rdi, 8
       mov      rcx, bword ptr [rsi]
       mov      bword ptr [rsp+0x08], rcx
       add      rsi, 8
       add      rdi, 8
       movsq    
       mov      rdi, rbx
       mov      rsi, gword ptr [rbp+0x10]
       mov      rdx, bword ptr [rbp+0x40]
       call     [Lokad.Lython.Runtime.PyExecutableFunction:TryStartDirectIntegerReturn[Lokad.Lython.Runtime.LythonRuntime+DefaultIntegerOperands](Lokad.Lython.Runtime.LythonRuntime+DefaultIntegerOperands,Lokad.Lython.LythonSourceSpan,byref):bool:this]
 
G_M000_IG12:                ;; offset=0x02D1
       test     eax, eax
       mov      rax, bword ptr [rbp-0x190]
       mov      rcx, bword ptr [rbp+0x40]
       je       G_M000_IG05
       mov      r13, bword ptr [rbp+0x38]
       mov      byte  ptr [r13], 0
       xor      rdx, rdx
       mov      r13, bword ptr [rbp+0x48]
       mov      gword ptr [r13], rdx
       jmp      G_M000_IG08
 
G_M000_IG13:                ;; offset=0x02FC
       mov      rax, bword ptr [rbp-0x190]
 
G_M000_IG14:                ;; offset=0x0303
       xor      esi, esi
       mov      bword ptr [rbp-0x190], rax
       mov      eax, esi
       jmp      SHORT G_M000_IG12
 
G_M000_IG15:                ;; offset=0x0310
       mov      rax, bword ptr [rbp-0x190]
       jmp      SHORT G_M000_IG14
 
G_M000_IG16:                ;; offset=0x0319
       mov      rax, bword ptr [rbp-0x190]
       jmp      SHORT G_M000_IG14
 
G_M000_IG17:                ;; offset=0x0322
       mov      rax, bword ptr [rbp-0x190]
       jmp      G_M000_IG05
 
G_M000_IG18:                ;; offset=0x032E
       mov      rdi, gword ptr [rbp-0x188]
       mov      rsi, gword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
       jmp      G_M000_IG11
 
G_M000_IG19:                ;; offset=0x0344
       mov      rax, bword ptr [rbp-0x190]
       mov      rsi, gword ptr [rbx+0x40]
       cmp      r14d, dword ptr [rsi+0xC4]
       jne      G_M000_IG05
       mov      bword ptr [rbp+0x40], rcx
       mov      bword ptr [rbp-0x190], rax
       mov      rsi, rax
       mov      edx, r14d
       mov      rdi, rbx
       mov      rcx, gword ptr [rbp+0x10]
       mov      r8, bword ptr [rbp+0x40]
       call     [Lokad.Lython.Runtime.PyExecutableFunction:TryStartDirectIntegerReturn[Lokad.Lython.Runtime.LythonRuntime+SlotIntegerOperands](Lokad.Lython.Runtime.LythonRuntime+SlotIntegerOperands,Lokad.Lython.LythonSourceSpan,byref):bool:this]
       jmp      G_M000_IG12
 
G_M000_IG20:                ;; offset=0x0383
       call     [System.ThrowHelper:ThrowArgumentOutOfRangeException()]
       int3     
 
G_M000_IG21:                ;; offset=0x038A
       mov      edi, 1
       test     r8d, r8d
       je       G_M000_IG26
       mov      gword ptr [rbp-0x128], r15
       xor      esi, esi
       mov      qword ptr [rbp-0x120], rsi
       jmp      G_M000_IG06
 
G_M000_IG22:                ;; offset=0x03AD
       call     CORINFO_HELP_POLL_GC
       jmp      G_M000_IG07
 
G_M000_IG23:                ;; offset=0x03B7
       mov      bword ptr [rbp+0x40], rcx
       mov      rdi, rdx
       mov      rsi, rax
       mov      rdx, r9
       call     [System.Buffer:BulkMoveWithWriteBarrierBatch(byref,byref,nuint)]
       jmp      G_M000_IG07
 
G_M000_IG24:                ;; offset=0x03CF
       call     [System.ThrowHelper:ThrowArgumentException_DestinationTooShort()]
       int3     
 
G_M000_IG25:                ;; offset=0x03D6
       mov      rdi, gword ptr [rbx+0x08]
       mov      rdi, gword ptr [rdi+0x08]
       mov      esi, dword ptr [rdi+0x08]
       cmp      esi, r8d
       mov      bword ptr [rbp+0x40], rcx
       ja       SHORT G_M000_IG20
       mov      gword ptr [rsp], r12
       xor      edi, edi
       mov      dword ptr [rsp+0x08], edi
       mov      gword ptr [rsp+0x10], r15
       mov      gword ptr [rsp+0x18], r13
       mov      bword ptr [rsp+0x20], rax
       mov      dword ptr [rsp+0x28], r14d
       lea      rdi, bword ptr [rbp-0x128]
       xor      rdx, rdx
       xor      ecx, ecx
       mov      r8, gword ptr [rbp+0x10]
       mov      r9, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime:BindFunctionArgumentsInto(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.ReadOnlySpan`1[Lokad.Lython.Runtime.CallArgumentValue],Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.FunctionBindingPlan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,bool,System.Object,Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):int]
       jmp      G_M000_IG07
 
G_M000_IG26:                ;; offset=0x0425
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
; Total bytes of code 1067

