; Assembly listing for method Lokad.Lython.Runtime.PyExecutableFunction:StartNativeCall(Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,bool,bool,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,byref,byref):this (Tier0)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; Tier0 code
; rbp based frame
; partially interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 240
       lea      rbp, [rsp+0xF0]
       xor      eax, eax
       mov      qword ptr [rbp-0x88], rax
       vxorps   xmm4, xmm4, xmm4
       vmovdqu  ymmword ptr [rbp-0x80], ymm4
       vmovdqu  ymmword ptr [rbp-0x60], ymm4
       vmovdqu  ymmword ptr [rbp-0x40], ymm4
       vmovdqa  xmmword ptr [rbp-0x20], xmm4
       mov      qword ptr [rbp-0x10], rax
       mov      dword ptr [rbp-0x08], eax
       mov      gword ptr [rbp+0x10], rcx
       mov      gword ptr [rbp+0x18], rdx
       mov      bword ptr [rbp+0x20], r8
       mov      gword ptr [rbp+0x28], r9
 
G_M000_IG02:                ;; offset=0x0048
       cmp      gword ptr [rbp+0x28], 0
       jne      G_M000_IG13
       mov      rcx, gword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.PyFunctionBase:get_CodeObject():Lokad.Lython.Frontend.ExecutableCodeObject:this]
       mov      rcx, rax
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_HasDirectIntegerReturn():bool:this]
       test     eax, eax
       je       G_M000_IG13
       movzx    rax, byte  ptr [rbp+0x48]
       test     eax, eax
       jne      SHORT G_M000_IG05
       mov      rax, bword ptr [rbp+0x20]
 
G_M000_IG03:                ;; offset=0x007C
       vmovdqu  xmm0, xmmword ptr [rax]
       vmovdqu  xmmword ptr [rbp-0x28], xmm0
 
G_M000_IG04:                ;; offset=0x0085
       mov      rax, gword ptr [rbp+0x38]
       mov      gword ptr [rsp+0x20], rax
       mov      rax, bword ptr [rbp+0x60]
       mov      bword ptr [rsp+0x28], rax
       lea      r8, [rbp-0x28]
       mov      rdx, gword ptr [rbp+0x18]
       mov      rcx, gword ptr [rbp+0x10]
       mov      r9, gword ptr [rbp+0x30]
       call     [Lokad.Lython.Runtime.PyExecutableFunction:TryStartPreparedIntegerReturn(Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,byref):bool:this]
       mov      dword ptr [rbp-0x08], eax
       jmp      SHORT G_M000_IG11
 
G_M000_IG05:                ;; offset=0x00B2
       mov      rax, bword ptr [rbp+0x20]
       mov      eax, dword ptr [rax+0x08]
       mov      dword ptr [rbp-0x04], eax
       mov      rcx, gword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.PyFunctionBase:get_CodeObject():Lokad.Lython.Frontend.ExecutableCodeObject:this]
       mov      rcx, rax
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_FirstTemporarySlot():int:this]
       cmp      eax, dword ptr [rbp-0x04]
       jne      SHORT G_M000_IG10
       mov      rax, bword ptr [rbp+0x20]
 
G_M000_IG06:                ;; offset=0x00DA
       vmovdqu  xmm0, xmmword ptr [rax]
       vmovdqu  xmmword ptr [rbp-0x38], xmm0
 
G_M000_IG07:                ;; offset=0x00E3
       lea      rdx, [rbp-0x38]
       lea      rcx, [rbp-0x18]
       call     [Lokad.Lython.Runtime.LythonRuntime+SlotIntegerOperands:.ctor(System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):this]
 
G_M000_IG08:                ;; offset=0x00F1
       vmovdqu  xmm0, xmmword ptr [rbp-0x18]
       vmovdqu  xmmword ptr [rbp-0x48], xmm0
 
G_M000_IG09:                ;; offset=0x00FB
       lea      rdx, [rbp-0x48]
       mov      rcx, gword ptr [rbp+0x10]
       mov      r8, gword ptr [rbp+0x38]
       mov      r9, bword ptr [rbp+0x60]
       call     [Lokad.Lython.Runtime.PyExecutableFunction:TryStartDirectIntegerReturn[Lokad.Lython.Runtime.LythonRuntime+SlotIntegerOperands](Lokad.Lython.Runtime.LythonRuntime+SlotIntegerOperands,Lokad.Lython.LythonSourceSpan,byref):bool:this]
       mov      dword ptr [rbp-0x08], eax
       jmp      SHORT G_M000_IG11
 
G_M000_IG10:                ;; offset=0x0116
       xor      eax, eax
       mov      dword ptr [rbp-0x08], eax
 
G_M000_IG11:                ;; offset=0x011B
       cmp      dword ptr [rbp-0x08], 0
       je       SHORT G_M000_IG13
       mov      rax, bword ptr [rbp+0x58]
       mov      byte  ptr [rax], 0
       mov      rax, bword ptr [rbp+0x68]
       xor      rcx, rcx
       mov      gword ptr [rax], rcx
 
G_M000_IG12:                ;; offset=0x0131
       add      rsp, 240
       pop      rbp
       ret      
 
G_M000_IG13:                ;; offset=0x013A
       mov      rcx, gword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.PyFunctionBase:get_CodeObject():Lokad.Lython.Frontend.ExecutableCodeObject:this]
       mov      rcx, rax
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_ValueStorageCapacity():int:this]
       cmp      eax, 8
       jg       G_M000_IG19
       mov      rax, bword ptr [rbp+0x20]
 
G_M000_IG14:                ;; offset=0x015C
       vmovdqu  xmm0, xmmword ptr [rax]
       vmovdqu  xmmword ptr [rbp-0x58], xmm0
 
G_M000_IG15:                ;; offset=0x0165
       mov      rax, gword ptr [rbp+0x30]
       mov      gword ptr [rsp+0x20], rax
       mov      rax, gword ptr [rbp+0x38]
       mov      gword ptr [rsp+0x28], rax
       movzx    rax, byte  ptr [rbp+0x40]
       mov      dword ptr [rsp+0x30], eax
       movzx    rax, byte  ptr [rbp+0x48]
       mov      dword ptr [rsp+0x38], eax
       mov      rax, bword ptr [rbp+0x50]
 
G_M000_IG16:                ;; offset=0x018B
       vmovdqu  xmm0, xmmword ptr [rax]
       vmovdqu  xmmword ptr [rbp-0x68], xmm0
 
G_M000_IG17:                ;; offset=0x0194
       mov      rax, bword ptr [rbp+0x58]
       mov      bword ptr [rsp+0x48], rax
       mov      rax, bword ptr [rbp+0x60]
       mov      bword ptr [rsp+0x50], rax
       mov      rax, bword ptr [rbp+0x68]
       mov      bword ptr [rsp+0x58], rax
       lea      r8, [rbp-0x58]
       lea      rax, [rbp-0x68]
       mov      qword ptr [rsp+0x40], rax
       mov      rcx, gword ptr [rbp+0x10]
       mov      r9, gword ptr [rbp+0x28]
       mov      rdx, gword ptr [rbp+0x18]
       call     [Lokad.Lython.Runtime.PyExecutableFunction:StartCompactNativeCall(Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,bool,bool,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,byref,byref):this]
       nop      
 
G_M000_IG18:                ;; offset=0x01CF
       add      rsp, 240
       pop      rbp
       ret      
 
G_M000_IG19:                ;; offset=0x01D8
       mov      rax, bword ptr [rbp+0x20]
 
G_M000_IG20:                ;; offset=0x01DC
       vmovdqu  xmm0, xmmword ptr [rax]
       vmovdqu  xmmword ptr [rbp-0x78], xmm0
 
G_M000_IG21:                ;; offset=0x01E5
       mov      rax, gword ptr [rbp+0x30]
       mov      gword ptr [rsp+0x20], rax
       mov      rax, gword ptr [rbp+0x38]
       mov      gword ptr [rsp+0x28], rax
       movzx    rax, byte  ptr [rbp+0x40]
       mov      dword ptr [rsp+0x30], eax
       movzx    rax, byte  ptr [rbp+0x48]
       mov      dword ptr [rsp+0x38], eax
       mov      rax, bword ptr [rbp+0x50]
 
G_M000_IG22:                ;; offset=0x020B
       vmovdqu  xmm0, xmmword ptr [rax]
       vmovdqu  xmmword ptr [rbp-0x88], xmm0
 
G_M000_IG23:                ;; offset=0x0217
       mov      rax, bword ptr [rbp+0x58]
       mov      bword ptr [rsp+0x48], rax
       mov      rax, bword ptr [rbp+0x60]
       mov      bword ptr [rsp+0x50], rax
       mov      rax, bword ptr [rbp+0x68]
       mov      bword ptr [rsp+0x58], rax
       lea      r8, [rbp-0x78]
       lea      rax, [rbp-0x88]
       mov      qword ptr [rsp+0x40], rax
       mov      rcx, gword ptr [rbp+0x10]
       mov      r9, gword ptr [rbp+0x28]
       mov      rdx, gword ptr [rbp+0x18]
       call     [Lokad.Lython.Runtime.PyExecutableFunction:StartWideNativeCall(Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,bool,bool,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,byref,byref):this]
       nop      
 
G_M000_IG24:                ;; offset=0x0255
       add      rsp, 240
       pop      rbp
       ret      
 
; Total bytes of code 606

; Assembly listing for method Lokad.Lython.Runtime.PyExecutableFunction:StartCompactNativeCall(Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,bool,bool,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,byref,byref):this (Tier0)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; Tier0 code
; rbp based frame
; partially interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 304
       lea      rbp, [rsp+0x130]
       vxorps   xmm4, xmm4, xmm4
       mov      rax, -192
 
G_M000_IG10:                ;; offset=0x001E
       vmovdqa  xmmword ptr [rax+rbp], xmm4
       vmovdqa  xmmword ptr [rbp+rax+0x10], xmm4
       vmovdqa  xmmword ptr [rbp+rax+0x20], xmm4
       add      rax, 48
       jne      SHORT G_M000_IG10
       mov      gword ptr [rbp+0x10], rcx
       mov      gword ptr [rbp+0x18], rdx
       mov      bword ptr [rbp+0x20], r8
       mov      gword ptr [rbp+0x28], r9
 
G_M000_IG02:                ;; offset=0x0045
       vxorps   ymm0, ymm0, ymm0
       vmovdqu  ymmword ptr [rbp-0x80], ymm0
       vmovdqu  ymmword ptr [rbp-0x60], ymm0
       vmovdqu  ymmword ptr [rbp-0x40], ymm0
       vmovdqu  ymmword ptr [rbp-0x20], ymm0
       lea      rdx, [rbp-0x80]
       lea      rcx, [rbp-0x90]
       mov      r8d, 8
       call     [<PrivateImplementationDetails>:InlineArrayAsSpan[Lokad.Lython.Runtime.PyExecutableFunction+CompactNativeValues,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot](byref,int):System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]]
 
G_M000_IG03:                ;; offset=0x0074
       vmovdqu  xmm0, xmmword ptr [rbp-0x90]
       vmovdqu  xmmword ptr [rbp-0xA0], xmm0
 
G_M000_IG04:                ;; offset=0x0084
       mov      rax, bword ptr [rbp+0x20]
 
G_M000_IG05:                ;; offset=0x0088
       vmovdqu  xmm0, xmmword ptr [rax]
       vmovdqu  xmmword ptr [rbp-0xB0], xmm0
 
G_M000_IG06:                ;; offset=0x0094
       mov      rax, gword ptr [rbp+0x28]
       mov      gword ptr [rsp+0x20], rax
       mov      rax, gword ptr [rbp+0x30]
       mov      gword ptr [rsp+0x28], rax
       mov      rax, gword ptr [rbp+0x38]
       mov      gword ptr [rsp+0x30], rax
       movzx    rax, byte  ptr [rbp+0x40]
       mov      dword ptr [rsp+0x38], eax
       movzx    rax, byte  ptr [rbp+0x48]
       mov      dword ptr [rsp+0x40], eax
       mov      rax, bword ptr [rbp+0x50]
 
G_M000_IG07:                ;; offset=0x00C3
       vmovdqu  xmm0, xmmword ptr [rax]
       vmovdqu  xmmword ptr [rbp-0xC0], xmm0
 
G_M000_IG08:                ;; offset=0x00CF
       mov      rax, bword ptr [rbp+0x58]
       mov      bword ptr [rsp+0x50], rax
       mov      rax, bword ptr [rbp+0x60]
       mov      bword ptr [rsp+0x58], rax
       mov      rax, bword ptr [rbp+0x68]
       mov      bword ptr [rsp+0x60], rax
       lea      rdx, [rbp-0xA0]
       lea      r9, [rbp-0xB0]
       lea      rax, [rbp-0xC0]
       mov      qword ptr [rsp+0x48], rax
       mov      rcx, gword ptr [rbp+0x10]
       mov      r8, gword ptr [rbp+0x18]
       call     [Lokad.Lython.Runtime.PyExecutableFunction:StartNativeCallWithStorage(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,bool,bool,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,byref,byref):this]
       nop      
 
G_M000_IG09:                ;; offset=0x0113
       add      rsp, 304
       pop      rbp
       ret      
 
; Total bytes of code 284

; Assembly listing for method Lokad.Lython.Runtime.PyExecutableFunction:StartNativeCallWithStorage(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,bool,bool,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,byref,byref):this (Tier0)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; Tier0 code
; rbp based frame
; partially interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 352
       lea      rbp, [rsp+0x160]
       vxorps   xmm4, xmm4, xmm4
       vmovdqa  xmmword ptr [rbp-0x110], xmm4
       vmovdqa  xmmword ptr [rbp-0x100], xmm4
       mov      rax, -240
 
G_M000_IG22:                ;; offset=0x002E
       vmovdqa  xmmword ptr [rax+rbp], xmm4
       vmovdqa  xmmword ptr [rbp+rax+0x10], xmm4
       vmovdqa  xmmword ptr [rbp+rax+0x20], xmm4
       add      rax, 48
       jne      SHORT G_M000_IG22
       mov      gword ptr [rbp+0x10], rcx
       mov      bword ptr [rbp+0x18], rdx
       mov      gword ptr [rbp+0x20], r8
       mov      bword ptr [rbp+0x28], r9
 
G_M000_IG02:                ;; offset=0x0055
       mov      rcx, gword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.PyFunctionBase:get_CodeObject():Lokad.Lython.Frontend.ExecutableCodeObject:this]
       mov      rcx, rax
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_ValueStorageCapacity():int:this]
       mov      dword ptr [rbp-0x88], eax
       mov      r9d, dword ptr [rbp-0x88]
       mov      rdx, bword ptr [rbp+0x18]
       mov      rcx, bword ptr [rbp+0x18]
       xor      r8d, r8d
       call     [System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:Slice(int,int):System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:this]
       movzx    rax, byte  ptr [rbp+0x50]
       test     eax, eax
       je       G_M000_IG06
       xor      eax, eax
       mov      dword ptr [rbp-0x04], eax
       cmp      gword ptr [rbp+0x30], 0
       je       SHORT G_M000_IG03
       mov      eax, dword ptr [rbp-0x04]
       mov      dword ptr [rbp-0x84], eax
       mov      eax, dword ptr [rbp-0x04]
       inc      eax
       mov      dword ptr [rbp-0x04], eax
       mov      rax, bword ptr [rbp+0x18]
       mov      eax, dword ptr [rax+0x08]
       cmp      dword ptr [rbp-0x84], eax
       jae      G_M000_IG21
       mov      rax, bword ptr [rbp+0x18]
       mov      ecx, dword ptr [rbp-0x84]
       shl      rcx, 4
       add      rcx, bword ptr [rax]
       mov      rdx, gword ptr [rbp+0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:set_Object(System.Object):this]
 
G_M000_IG03:                ;; offset=0x00DF
       lea      rdx, [rbp-0x80]
       mov      rcx, bword ptr [rbp+0x18]
       mov      r8d, dword ptr [rbp-0x04]
       call     [System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:Slice(int):System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:this]
 
G_M000_IG04:                ;; offset=0x00F1
       vmovdqu  xmm0, xmmword ptr [rbp-0x80]
       vmovdqu  xmmword ptr [rbp-0x98], xmm0
 
G_M000_IG05:                ;; offset=0x00FE
       lea      rdx, [rbp-0x98]
       mov      rcx, bword ptr [rbp+0x28]
       call     [System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:CopyTo(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):this]
       jmp      G_M000_IG12
 
G_M000_IG06:                ;; offset=0x0114
       mov      rcx, gword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_ParameterCount():int:this]
       mov      dword ptr [rbp-0x9C], eax
       mov      r9d, dword ptr [rbp-0x9C]
       lea      rdx, [rbp-0x60]
       mov      rcx, bword ptr [rbp+0x18]
       xor      r8d, r8d
       call     [System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:Slice(int,int):System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:this]
       vxorps   xmm0, xmm0, xmm0
       vmovdqu  xmmword ptr [rbp-0x18], xmm0
 
G_M000_IG07:                ;; offset=0x0145
       vmovdqu  xmm0, xmmword ptr [rbp-0x60]
       vmovdqu  xmmword ptr [rbp-0xB0], xmm0
 
G_M000_IG08:                ;; offset=0x0152
       vmovdqu  xmm0, xmmword ptr [rbp-0x18]
       vmovdqu  xmmword ptr [rbp-0xC0], xmm0
 
G_M000_IG09:                ;; offset=0x015F
       mov      rax, gword ptr [rbp+0x38]
       mov      gword ptr [rsp+0x20], rax
       xor      eax, eax
       mov      dword ptr [rsp+0x28], eax
       mov      rax, gword ptr [rbp+0x30]
       mov      gword ptr [rsp+0x30], rax
       mov      rax, gword ptr [rbp+0x20]
       mov      gword ptr [rsp+0x38], rax
       mov      rax, bword ptr [rbp+0x28]
 
G_M000_IG10:                ;; offset=0x0184
       vmovdqu  xmm0, xmmword ptr [rax]
       vmovdqu  xmmword ptr [rbp-0xD0], xmm0
 
G_M000_IG11:                ;; offset=0x0190
       lea      rcx, [rbp-0xB0]
       lea      rdx, [rbp-0xC0]
       lea      rax, [rbp-0xD0]
       mov      qword ptr [rsp+0x40], rax
       mov      r9, gword ptr [rbp+0x10]
       mov      r8, gword ptr [rbp+0x40]
       call     [Lokad.Lython.Runtime.LythonRuntime:BindFunctionArgumentsInto(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.ReadOnlySpan`1[Lokad.Lython.Runtime.CallArgumentValue],Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.FunctionBindingPlan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,bool,System.Object,Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):int]
 
G_M000_IG12:                ;; offset=0x01B8
       mov      rax, bword ptr [rbp+0x18]
 
G_M000_IG13:                ;; offset=0x01BC
       vmovdqu  xmm0, xmmword ptr [rax]
       vmovdqu  xmmword ptr [rbp-0x70], xmm0
 
G_M000_IG14:                ;; offset=0x01C5
       vxorps   ymm0, ymm0, ymm0
       vmovdqu  ymmword ptr [rbp-0x50], ymm0
 
G_M000_IG15:                ;; offset=0x01CE
       vmovdqu  xmm0, xmmword ptr [rbp-0x70]
       vmovdqu  xmmword ptr [rbp-0xE0], xmm0
 
G_M000_IG16:                ;; offset=0x01DB
       vmovdqu  ymm0, ymmword ptr [rbp-0x50]
       vmovdqu  ymmword ptr [rbp-0x100], ymm0
 
G_M000_IG17:                ;; offset=0x01E8
       movzx    rax, byte  ptr [rbp+0x48]
       mov      dword ptr [rsp+0x20], eax
       mov      rax, bword ptr [rbp+0x58]
 
G_M000_IG18:                ;; offset=0x01F4
       vmovdqu  xmm0, xmmword ptr [rax]
       vmovdqu  xmmword ptr [rbp-0x110], xmm0
 
G_M000_IG19:                ;; offset=0x0200
       mov      rax, bword ptr [rbp+0x60]
       mov      bword ptr [rsp+0x30], rax
       mov      rax, bword ptr [rbp+0x68]
       mov      bword ptr [rsp+0x38], rax
       mov      rax, bword ptr [rbp+0x70]
       mov      bword ptr [rsp+0x40], rax
       lea      rax, [rbp-0x30]
       mov      qword ptr [rsp+0x48], rax
       lea      rdx, [rbp-0xE0]
       lea      r8, [rbp-0x100]
       lea      rax, [rbp-0x110]
       mov      qword ptr [rsp+0x28], rax
       mov      r9, gword ptr [rbp+0x40]
       mov      rcx, gword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.PyExecutableFunction:StartInline(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.Nullable`1[Lokad.Lython.Runtime.BoundFunctionArguments],Lokad.Lython.LythonSourceSpan,bool,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,byref,byref,byref):this]
       nop      
 
G_M000_IG20:                ;; offset=0x024D
       vzeroupper 
       add      rsp, 352
       pop      rbp
       ret      
 
G_M000_IG21:                ;; offset=0x0259
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
; Total bytes of code 607

; Assembly listing for method Lokad.Lython.Runtime.PyExecutableFunction:StartNativeCall(Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,bool,bool,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,byref,byref):this (Instrumented Tier0)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; Instrumented Tier0 code
; rbp based frame
; partially interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 240
       lea      rbp, [rsp+0xF0]
       xor      eax, eax
       mov      qword ptr [rbp-0x88], rax
       vxorps   xmm4, xmm4, xmm4
       vmovdqu  ymmword ptr [rbp-0x80], ymm4
       vmovdqu  ymmword ptr [rbp-0x60], ymm4
       vmovdqu  ymmword ptr [rbp-0x40], ymm4
       vmovdqa  xmmword ptr [rbp-0x20], xmm4
       mov      qword ptr [rbp-0x10], rax
       mov      dword ptr [rbp-0x08], eax
       mov      gword ptr [rbp+0x10], rcx
       mov      gword ptr [rbp+0x18], rdx
       mov      bword ptr [rbp+0x20], r8
       mov      gword ptr [rbp+0x28], r9
 
G_M000_IG02:                ;; offset=0x0048
       cmp      gword ptr [rbp+0x28], 0
       jne      G_M000_IG15
       mov      rcx, gword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.PyFunctionBase:get_CodeObject():Lokad.Lython.Frontend.ExecutableCodeObject:this]
       mov      rcx, rax
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_HasDirectIntegerReturn():bool:this]
       test     eax, eax
       je       SHORT G_M000_IG05
       movzx    rax, byte  ptr [rbp+0x48]
       test     eax, eax
       jne      SHORT G_M000_IG06
       mov      rax, bword ptr [rbp+0x20]
 
G_M000_IG03:                ;; offset=0x0078
       vmovdqu  xmm0, xmmword ptr [rax]
       vmovdqu  xmmword ptr [rbp-0x28], xmm0
 
G_M000_IG04:                ;; offset=0x0081
       mov      rax, gword ptr [rbp+0x38]
       mov      gword ptr [rsp+0x20], rax
       mov      rax, bword ptr [rbp+0x60]
       mov      bword ptr [rsp+0x28], rax
       lea      r8, [rbp-0x28]
       mov      rdx, gword ptr [rbp+0x18]
       mov      rcx, gword ptr [rbp+0x10]
       mov      r9, gword ptr [rbp+0x30]
       call     [Lokad.Lython.Runtime.PyExecutableFunction:TryStartPreparedIntegerReturn(Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,byref):bool:this]
       mov      dword ptr [rbp-0x08], eax
       jmp      G_M000_IG12
 
G_M000_IG05:                ;; offset=0x00B1
       mov      rcx, 0x7FFA0265AC98
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG15
 
G_M000_IG06:                ;; offset=0x00C5
       mov      rax, bword ptr [rbp+0x20]
       mov      eax, dword ptr [rax+0x08]
       mov      dword ptr [rbp-0x04], eax
       mov      rcx, gword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.PyFunctionBase:get_CodeObject():Lokad.Lython.Frontend.ExecutableCodeObject:this]
       mov      rcx, rax
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_FirstTemporarySlot():int:this]
       cmp      eax, dword ptr [rbp-0x04]
       jne      SHORT G_M000_IG11
       mov      rcx, 0x7FFA0265AC9C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x20]
 
G_M000_IG07:                ;; offset=0x00FC
       vmovdqu  xmm0, xmmword ptr [rax]
       vmovdqu  xmmword ptr [rbp-0x38], xmm0
 
G_M000_IG08:                ;; offset=0x0105
       lea      rdx, [rbp-0x38]
       lea      rcx, [rbp-0x18]
       call     [Lokad.Lython.Runtime.LythonRuntime+SlotIntegerOperands:.ctor(System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):this]
 
G_M000_IG09:                ;; offset=0x0113
       vmovdqu  xmm0, xmmword ptr [rbp-0x18]
       vmovdqu  xmmword ptr [rbp-0x48], xmm0
 
G_M000_IG10:                ;; offset=0x011D
       lea      rdx, [rbp-0x48]
       mov      rcx, gword ptr [rbp+0x10]
       mov      r8, gword ptr [rbp+0x38]
       mov      r9, bword ptr [rbp+0x60]
       call     [Lokad.Lython.Runtime.PyExecutableFunction:TryStartDirectIntegerReturn[Lokad.Lython.Runtime.LythonRuntime+SlotIntegerOperands](Lokad.Lython.Runtime.LythonRuntime+SlotIntegerOperands,Lokad.Lython.LythonSourceSpan,byref):bool:this]
       mov      dword ptr [rbp-0x08], eax
       jmp      SHORT G_M000_IG12
 
G_M000_IG11:                ;; offset=0x0138
       mov      rcx, 0x7FFA0265ACA0
       call     CORINFO_HELP_COUNTPROFILE32
       xor      eax, eax
       mov      dword ptr [rbp-0x08], eax
 
G_M000_IG12:                ;; offset=0x014C
       cmp      dword ptr [rbp-0x08], 0
       je       SHORT G_M000_IG14
       mov      rcx, 0x7FFA0265ACA4
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x58]
       mov      byte  ptr [rax], 0
       mov      rax, bword ptr [rbp+0x68]
       xor      rcx, rcx
       mov      gword ptr [rax], rcx
 
G_M000_IG13:                ;; offset=0x0171
       add      rsp, 240
       pop      rbp
       ret      
 
G_M000_IG14:                ;; offset=0x017A
       mov      rcx, 0x7FFA0265ACA8
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG15:                ;; offset=0x0189
       mov      rcx, gword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.PyFunctionBase:get_CodeObject():Lokad.Lython.Frontend.ExecutableCodeObject:this]
       mov      rcx, rax
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_ValueStorageCapacity():int:this]
       cmp      eax, 8
       jg       G_M000_IG21
       mov      rcx, 0x7FFA0265ACAC
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x20]
 
G_M000_IG16:                ;; offset=0x01BA
       vmovdqu  xmm0, xmmword ptr [rax]
       vmovdqu  xmmword ptr [rbp-0x58], xmm0
 
G_M000_IG17:                ;; offset=0x01C3
       mov      rax, gword ptr [rbp+0x30]
       mov      gword ptr [rsp+0x20], rax
       mov      rax, gword ptr [rbp+0x38]
       mov      gword ptr [rsp+0x28], rax
       movzx    rax, byte  ptr [rbp+0x40]
       mov      dword ptr [rsp+0x30], eax
       movzx    rax, byte  ptr [rbp+0x48]
       mov      dword ptr [rsp+0x38], eax
       mov      rax, bword ptr [rbp+0x50]
 
G_M000_IG18:                ;; offset=0x01E9
       vmovdqu  xmm0, xmmword ptr [rax]
       vmovdqu  xmmword ptr [rbp-0x68], xmm0
 
G_M000_IG19:                ;; offset=0x01F2
       mov      rax, bword ptr [rbp+0x58]
       mov      bword ptr [rsp+0x48], rax
       mov      rax, bword ptr [rbp+0x60]
       mov      bword ptr [rsp+0x50], rax
       mov      rax, bword ptr [rbp+0x68]
       mov      bword ptr [rsp+0x58], rax
       lea      r8, [rbp-0x58]
       lea      rax, [rbp-0x68]
       mov      qword ptr [rsp+0x40], rax
       mov      rcx, gword ptr [rbp+0x10]
       mov      r9, gword ptr [rbp+0x28]
       mov      rdx, gword ptr [rbp+0x18]
       call     [Lokad.Lython.Runtime.PyExecutableFunction:StartCompactNativeCall(Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,bool,bool,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,byref,byref):this]
       nop      
 
G_M000_IG20:                ;; offset=0x022D
       add      rsp, 240
       pop      rbp
       ret      
 
G_M000_IG21:                ;; offset=0x0236
       mov      rcx, 0x7FFA0265ACB0
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x20]
 
G_M000_IG22:                ;; offset=0x0249
       vmovdqu  xmm0, xmmword ptr [rax]
       vmovdqu  xmmword ptr [rbp-0x78], xmm0
 
G_M000_IG23:                ;; offset=0x0252
       mov      rax, gword ptr [rbp+0x30]
       mov      gword ptr [rsp+0x20], rax
       mov      rax, gword ptr [rbp+0x38]
       mov      gword ptr [rsp+0x28], rax
       movzx    rax, byte  ptr [rbp+0x40]
       mov      dword ptr [rsp+0x30], eax
       movzx    rax, byte  ptr [rbp+0x48]
       mov      dword ptr [rsp+0x38], eax
       mov      rax, bword ptr [rbp+0x50]
 
G_M000_IG24:                ;; offset=0x0278
       vmovdqu  xmm0, xmmword ptr [rax]
       vmovdqu  xmmword ptr [rbp-0x88], xmm0
 
G_M000_IG25:                ;; offset=0x0284
       mov      rax, bword ptr [rbp+0x58]
       mov      bword ptr [rsp+0x48], rax
       mov      rax, bword ptr [rbp+0x60]
       mov      bword ptr [rsp+0x50], rax
       mov      rax, bword ptr [rbp+0x68]
       mov      bword ptr [rsp+0x58], rax
       lea      r8, [rbp-0x78]
       lea      rax, [rbp-0x88]
       mov      qword ptr [rsp+0x40], rax
       mov      rcx, gword ptr [rbp+0x10]
       mov      r9, gword ptr [rbp+0x28]
       mov      rdx, gword ptr [rbp+0x18]
       call     [Lokad.Lython.Runtime.PyExecutableFunction:StartWideNativeCall(Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,bool,bool,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,byref,byref):this]
       nop      
 
G_M000_IG26:                ;; offset=0x02C2
       add      rsp, 240
       pop      rbp
       ret      
 
; Total bytes of code 715

; Assembly listing for method Lokad.Lython.Runtime.PyExecutableFunction:StartCompactNativeCall(Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,bool,bool,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,byref,byref):this (Instrumented Tier0)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; Instrumented Tier0 code
; rbp based frame
; partially interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 304
       lea      rbp, [rsp+0x130]
       vxorps   xmm4, xmm4, xmm4
       mov      rax, -192
 
G_M000_IG10:                ;; offset=0x001E
       vmovdqa  xmmword ptr [rax+rbp], xmm4
       vmovdqa  xmmword ptr [rbp+rax+0x10], xmm4
       vmovdqa  xmmword ptr [rbp+rax+0x20], xmm4
       add      rax, 48
       jne      SHORT G_M000_IG10
       mov      gword ptr [rbp+0x10], rcx
       mov      gword ptr [rbp+0x18], rdx
       mov      bword ptr [rbp+0x20], r8
       mov      gword ptr [rbp+0x28], r9
 
G_M000_IG02:                ;; offset=0x0045
       vxorps   ymm0, ymm0, ymm0
       vmovdqu  ymmword ptr [rbp-0x80], ymm0
       vmovdqu  ymmword ptr [rbp-0x60], ymm0
       vmovdqu  ymmword ptr [rbp-0x40], ymm0
       vmovdqu  ymmword ptr [rbp-0x20], ymm0
       lea      rdx, [rbp-0x80]
       lea      rcx, [rbp-0x90]
       mov      r8d, 8
       call     [<PrivateImplementationDetails>:InlineArrayAsSpan[Lokad.Lython.Runtime.PyExecutableFunction+CompactNativeValues,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot](byref,int):System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]]
 
G_M000_IG03:                ;; offset=0x0074
       vmovdqu  xmm0, xmmword ptr [rbp-0x90]
       vmovdqu  xmmword ptr [rbp-0xA0], xmm0
 
G_M000_IG04:                ;; offset=0x0084
       mov      rax, bword ptr [rbp+0x20]
 
G_M000_IG05:                ;; offset=0x0088
       vmovdqu  xmm0, xmmword ptr [rax]
       vmovdqu  xmmword ptr [rbp-0xB0], xmm0
 
G_M000_IG06:                ;; offset=0x0094
       mov      rax, gword ptr [rbp+0x28]
       mov      gword ptr [rsp+0x20], rax
       mov      rax, gword ptr [rbp+0x30]
       mov      gword ptr [rsp+0x28], rax
       mov      rax, gword ptr [rbp+0x38]
       mov      gword ptr [rsp+0x30], rax
       movzx    rax, byte  ptr [rbp+0x40]
       mov      dword ptr [rsp+0x38], eax
       movzx    rax, byte  ptr [rbp+0x48]
       mov      dword ptr [rsp+0x40], eax
       mov      rax, bword ptr [rbp+0x50]
 
G_M000_IG07:                ;; offset=0x00C3
       vmovdqu  xmm0, xmmword ptr [rax]
       vmovdqu  xmmword ptr [rbp-0xC0], xmm0
 
G_M000_IG08:                ;; offset=0x00CF
       mov      rax, bword ptr [rbp+0x58]
       mov      bword ptr [rsp+0x50], rax
       mov      rax, bword ptr [rbp+0x60]
       mov      bword ptr [rsp+0x58], rax
       mov      rax, bword ptr [rbp+0x68]
       mov      bword ptr [rsp+0x60], rax
       lea      rdx, [rbp-0xA0]
       lea      r9, [rbp-0xB0]
       lea      rax, [rbp-0xC0]
       mov      qword ptr [rsp+0x48], rax
       mov      rcx, gword ptr [rbp+0x10]
       mov      r8, gword ptr [rbp+0x18]
       call     [Lokad.Lython.Runtime.PyExecutableFunction:StartNativeCallWithStorage(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,bool,bool,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,byref,byref):this]
       nop      
 
G_M000_IG09:                ;; offset=0x0113
       add      rsp, 304
       pop      rbp
       ret      
 
; Total bytes of code 284

; Assembly listing for method Lokad.Lython.Runtime.PyExecutableFunction:StartNativeCallWithStorage(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,bool,bool,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,byref,byref):this (Instrumented Tier0)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; Instrumented Tier0 code
; rbp based frame
; partially interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 352
       lea      rbp, [rsp+0x160]
       vxorps   xmm4, xmm4, xmm4
       vmovdqa  xmmword ptr [rbp-0x110], xmm4
       vmovdqa  xmmword ptr [rbp-0x100], xmm4
       mov      rax, -240
 
G_M000_IG22:                ;; offset=0x002E
       vmovdqa  xmmword ptr [rax+rbp], xmm4
       vmovdqa  xmmword ptr [rbp+rax+0x10], xmm4
       vmovdqa  xmmword ptr [rbp+rax+0x20], xmm4
       add      rax, 48
       jne      SHORT G_M000_IG22
       mov      gword ptr [rbp+0x10], rcx
       mov      bword ptr [rbp+0x18], rdx
       mov      gword ptr [rbp+0x20], r8
       mov      bword ptr [rbp+0x28], r9
 
G_M000_IG02:                ;; offset=0x0055
       mov      rcx, gword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.PyFunctionBase:get_CodeObject():Lokad.Lython.Frontend.ExecutableCodeObject:this]
       mov      rcx, rax
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_ValueStorageCapacity():int:this]
       mov      dword ptr [rbp-0x88], eax
       mov      r9d, dword ptr [rbp-0x88]
       mov      rdx, bword ptr [rbp+0x18]
       mov      rcx, bword ptr [rbp+0x18]
       xor      r8d, r8d
       call     [System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:Slice(int,int):System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:this]
       movzx    rax, byte  ptr [rbp+0x50]
       test     eax, eax
       je       G_M000_IG06
       xor      eax, eax
       mov      dword ptr [rbp-0x04], eax
       cmp      gword ptr [rbp+0x30], 0
       je       SHORT G_M000_IG03
       mov      rcx, 0x7FFA0265D4E8
       call     CORINFO_HELP_COUNTPROFILE32
       mov      eax, dword ptr [rbp-0x04]
       mov      dword ptr [rbp-0x84], eax
       mov      eax, dword ptr [rbp-0x04]
       inc      eax
       mov      dword ptr [rbp-0x04], eax
       mov      rax, bword ptr [rbp+0x18]
       mov      eax, dword ptr [rax+0x08]
       cmp      dword ptr [rbp-0x84], eax
       jae      G_M000_IG21
       mov      rax, bword ptr [rbp+0x18]
       mov      ecx, dword ptr [rbp-0x84]
       shl      rcx, 4
       add      rcx, bword ptr [rax]
       mov      rdx, gword ptr [rbp+0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:set_Object(System.Object):this]
 
G_M000_IG03:                ;; offset=0x00EE
       lea      rdx, [rbp-0x80]
       mov      rcx, bword ptr [rbp+0x18]
       mov      r8d, dword ptr [rbp-0x04]
       call     [System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:Slice(int):System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:this]
 
G_M000_IG04:                ;; offset=0x0100
       vmovdqu  xmm0, xmmword ptr [rbp-0x80]
       vmovdqu  xmmword ptr [rbp-0x98], xmm0
 
G_M000_IG05:                ;; offset=0x010D
       lea      rdx, [rbp-0x98]
       mov      rcx, bword ptr [rbp+0x28]
       call     [System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:CopyTo(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):this]
       jmp      G_M000_IG12
 
G_M000_IG06:                ;; offset=0x0123
       mov      rcx, 0x7FFA0265D4EC
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, gword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_ParameterCount():int:this]
       mov      dword ptr [rbp-0x9C], eax
       mov      r9d, dword ptr [rbp-0x9C]
       lea      rdx, [rbp-0x60]
       mov      rcx, bword ptr [rbp+0x18]
       xor      r8d, r8d
       call     [System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:Slice(int,int):System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:this]
       vxorps   xmm0, xmm0, xmm0
       vmovdqu  xmmword ptr [rbp-0x18], xmm0
 
G_M000_IG07:                ;; offset=0x0163
       vmovdqu  xmm0, xmmword ptr [rbp-0x60]
       vmovdqu  xmmword ptr [rbp-0xB0], xmm0
 
G_M000_IG08:                ;; offset=0x0170
       vmovdqu  xmm0, xmmword ptr [rbp-0x18]
       vmovdqu  xmmword ptr [rbp-0xC0], xmm0
 
G_M000_IG09:                ;; offset=0x017D
       mov      rax, gword ptr [rbp+0x38]
       mov      gword ptr [rsp+0x20], rax
       xor      eax, eax
       mov      dword ptr [rsp+0x28], eax
       mov      rax, gword ptr [rbp+0x30]
       mov      gword ptr [rsp+0x30], rax
       mov      rax, gword ptr [rbp+0x20]
       mov      gword ptr [rsp+0x38], rax
       mov      rax, bword ptr [rbp+0x28]
 
G_M000_IG10:                ;; offset=0x01A2
       vmovdqu  xmm0, xmmword ptr [rax]
       vmovdqu  xmmword ptr [rbp-0xD0], xmm0
 
G_M000_IG11:                ;; offset=0x01AE
       lea      rcx, [rbp-0xB0]
       lea      rdx, [rbp-0xC0]
       lea      rax, [rbp-0xD0]
       mov      qword ptr [rsp+0x40], rax
       mov      r9, gword ptr [rbp+0x10]
       mov      r8, gword ptr [rbp+0x40]
       call     [Lokad.Lython.Runtime.LythonRuntime:BindFunctionArgumentsInto(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.ReadOnlySpan`1[Lokad.Lython.Runtime.CallArgumentValue],Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.FunctionBindingPlan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,bool,System.Object,Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):int]
 
G_M000_IG12:                ;; offset=0x01D6
       mov      rcx, 0x7FFA0265D4F0
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x18]
 
G_M000_IG13:                ;; offset=0x01E9
       vmovdqu  xmm0, xmmword ptr [rax]
       vmovdqu  xmmword ptr [rbp-0x70], xmm0
 
G_M000_IG14:                ;; offset=0x01F2
       vxorps   ymm0, ymm0, ymm0
       vmovdqu  ymmword ptr [rbp-0x50], ymm0
 
G_M000_IG15:                ;; offset=0x01FB
       vmovdqu  xmm0, xmmword ptr [rbp-0x70]
       vmovdqu  xmmword ptr [rbp-0xE0], xmm0
 
G_M000_IG16:                ;; offset=0x0208
       vmovdqu  ymm0, ymmword ptr [rbp-0x50]
       vmovdqu  ymmword ptr [rbp-0x100], ymm0
 
G_M000_IG17:                ;; offset=0x0215
       movzx    rax, byte  ptr [rbp+0x48]
       mov      dword ptr [rsp+0x20], eax
       mov      rax, bword ptr [rbp+0x58]
 
G_M000_IG18:                ;; offset=0x0221
       vmovdqu  xmm0, xmmword ptr [rax]
       vmovdqu  xmmword ptr [rbp-0x110], xmm0
 
G_M000_IG19:                ;; offset=0x022D
       mov      rax, bword ptr [rbp+0x60]
       mov      bword ptr [rsp+0x30], rax
       mov      rax, bword ptr [rbp+0x68]
       mov      bword ptr [rsp+0x38], rax
       mov      rax, bword ptr [rbp+0x70]
       mov      bword ptr [rsp+0x40], rax
       lea      rax, [rbp-0x30]
       mov      qword ptr [rsp+0x48], rax
       lea      rdx, [rbp-0xE0]
       lea      r8, [rbp-0x100]
       lea      rax, [rbp-0x110]
       mov      qword ptr [rsp+0x28], rax
       mov      r9, gword ptr [rbp+0x40]
       mov      rcx, gword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.PyExecutableFunction:StartInline(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.Nullable`1[Lokad.Lython.Runtime.BoundFunctionArguments],Lokad.Lython.LythonSourceSpan,bool,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,byref,byref,byref):this]
       nop      
 
G_M000_IG20:                ;; offset=0x027A
       vzeroupper 
       add      rsp, 352
       pop      rbp
       ret      
 
G_M000_IG21:                ;; offset=0x0286
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
; Total bytes of code 652

; Assembly listing for method Lokad.Lython.Runtime.PyExecutableFunction:StartNativeCall(Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,bool,bool,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,byref,byref):this (Tier1)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; Tier1 code
; optimized code
; optimized using Synthesized PGO
; rbp based frame
; partially interruptible
; with Synthesized PGO: fgCalledCount is 21702
; 2 inlinees with PGO data; 15 single block inlinees; 0 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       push     r15
       push     r14
       push     r13
       push     r12
       push     rdi
       push     rsi
       push     rbx
       sub      rsp, 168
       lea      rbp, [rsp+0xE0]
       vxorps   xmm4, xmm4, xmm4
       vmovdqu  ymmword ptr [rbp-0x70], ymm4
       vmovdqa  xmmword ptr [rbp-0x50], xmm4
       xor      eax, eax
       mov      qword ptr [rbp-0x40], rax
       mov      rbx, rcx
       mov      rdi, rdx
       mov      rsi, r9
       mov      r14, bword ptr [rbp+0x50]
       mov      r15, bword ptr [rbp+0x60]
 
G_M000_IG02:                ;; offset=0x0040
       mov      r13, bword ptr [r8]
       mov      r12d, dword ptr [r8+0x08]
       test     rsi, rsi
       jne      SHORT G_M000_IG04
 
G_M000_IG03:                ;; offset=0x004C
       mov      rcx, gword ptr [rbx+0x40]
       cmp      byte  ptr [rcx+0xE0], 0
       jne      G_M000_IG07
 
G_M000_IG04:                ;; offset=0x005D
       mov      r8, gword ptr [rbx+0x40]
       cmp      dword ptr [r8+0xD4], 8
       jg       G_M000_IG13
       mov      bword ptr [rbp-0x70], r13
       mov      dword ptr [rbp-0x68], r12d
       mov      r12, gword ptr [rbp+0x30]
       mov      gword ptr [rsp+0x20], r12
       mov      r12, gword ptr [rbp+0x38]
       mov      gword ptr [rsp+0x28], r12
       movzx    r8, byte  ptr [rbp+0x40]
       mov      dword ptr [rsp+0x30], r8d
       movzx    r8, byte  ptr [rbp+0x48]
       mov      dword ptr [rsp+0x38], r8d
       mov      bword ptr [rsp+0x40], r14
       mov      r14, bword ptr [rbp+0x58]
       mov      bword ptr [rsp+0x48], r14
       mov      bword ptr [rsp+0x50], r15
       mov      r15, bword ptr [rbp+0x68]
       mov      bword ptr [rsp+0x58], r15
       lea      r8, [rbp-0x70]
       mov      rdx, rdi
       mov      rcx, rbx
       mov      r9, rsi
       call     [Lokad.Lython.Runtime.PyExecutableFunction:StartCompactNativeCall(Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,bool,bool,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,byref,byref):this]
 
G_M000_IG05:                ;; offset=0x00CC
       nop      
 
G_M000_IG06:                ;; offset=0x00CD
       add      rsp, 168
       pop      rbx
       pop      rsi
       pop      rdi
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG07:                ;; offset=0x00E1
       cmp      byte  ptr [rbp+0x48], 0
       jne      G_M000_IG12
       xor      ecx, ecx
       mov      qword ptr [r15], rcx
       mov      qword ptr [r15+0x08], rcx
       cmp      byte  ptr [rdi+0x34], 0
       je       G_M000_IG10
       mov      rcx, gword ptr [rbx+0x08]
       mov      rcx, gword ptr [rcx+0x08]
       mov      ecx, dword ptr [rcx+0x08]
       mov      rdx, gword ptr [rbx+0x40]
       cmp      ecx, dword ptr [rdx+0xC4]
       jne      SHORT G_M000_IG10
       mov      rcx, rbx
       mov      edx, r12d
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:HasPreparedOmittedArguments(int):bool:this]
       test     eax, eax
       je       SHORT G_M000_IG10
       mov      rax, gword ptr [rbp+0x30]
       mov      rdx, gword ptr [rax+0x98]
       mov      gword ptr [rbp-0x78], rdx
       cmp      byte  ptr [rdx], dl
       mov      rcx, rdx
       call     [Lokad.Lython.Runtime.ExecutionState:get_CanContinue():bool:this]
       test     eax, eax
       je       SHORT G_M000_IG11
 
G_M000_IG08:                ;; offset=0x0143
       mov      gword ptr [rbp-0x50], rbx
       mov      bword ptr [rbp-0x48], r13
       mov      dword ptr [rbp-0x40], r12d
       lea      rdx, [rbp-0x50]
       mov      rcx, rbx
       mov      r8, gword ptr [rbp+0x38]
       mov      r9, r15
       call     [Lokad.Lython.Runtime.PyExecutableFunction:TryStartDirectIntegerReturn[Lokad.Lython.Runtime.LythonRuntime+DefaultIntegerOperands](Lokad.Lython.Runtime.LythonRuntime+DefaultIntegerOperands,Lokad.Lython.LythonSourceSpan,byref):bool:this]
 
G_M000_IG09:                ;; offset=0x0163
       test     eax, eax
       je       G_M000_IG04
       mov      rsi, bword ptr [rbp+0x58]
       mov      byte  ptr [rsi], 0
       xor      r8, r8
       mov      rdi, bword ptr [rbp+0x68]
       mov      gword ptr [rdi], r8
       jmp      G_M000_IG05
 
G_M000_IG10:                ;; offset=0x0181
       xor      edx, edx
       mov      eax, edx
       jmp      SHORT G_M000_IG09
 
G_M000_IG11:                ;; offset=0x0187
       mov      rcx, gword ptr [rbp-0x78]
       mov      rdx, gword ptr [rbp+0x38]
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
       jmp      SHORT G_M000_IG08
 
G_M000_IG12:                ;; offset=0x0197
       mov      rdx, gword ptr [rbx+0x40]
       cmp      r12d, dword ptr [rdx+0xC4]
       jne      G_M000_IG04
       mov      bword ptr [rbp-0x60], r13
       mov      dword ptr [rbp-0x58], r12d
       lea      rdx, [rbp-0x60]
       mov      rcx, rbx
       mov      r8, gword ptr [rbp+0x38]
       mov      r9, r15
       call     [Lokad.Lython.Runtime.PyExecutableFunction:TryStartDirectIntegerReturn[Lokad.Lython.Runtime.LythonRuntime+SlotIntegerOperands](Lokad.Lython.Runtime.LythonRuntime+SlotIntegerOperands,Lokad.Lython.LythonSourceSpan,byref):bool:this]
       jmp      SHORT G_M000_IG09
 
G_M000_IG13:                ;; offset=0x01C6
       mov      bword ptr [rbp-0x70], r13
       mov      dword ptr [rbp-0x68], r12d
       mov      r12, gword ptr [rbp+0x30]
       mov      gword ptr [rsp+0x20], r12
       mov      r12, gword ptr [rbp+0x38]
       mov      gword ptr [rsp+0x28], r12
       movzx    r8, byte  ptr [rbp+0x40]
       mov      dword ptr [rsp+0x30], r8d
       movzx    r8, byte  ptr [rbp+0x48]
       mov      dword ptr [rsp+0x38], r8d
       mov      bword ptr [rsp+0x40], r14
       mov      r14, bword ptr [rbp+0x58]
       mov      bword ptr [rsp+0x48], r14
       mov      bword ptr [rsp+0x50], r15
       mov      r15, bword ptr [rbp+0x68]
       mov      bword ptr [rsp+0x58], r15
       lea      r8, [rbp-0x70]
       mov      rdx, rdi
       mov      rcx, rbx
       mov      r9, rsi
       call     [Lokad.Lython.Runtime.PyExecutableFunction:StartWideNativeCall(Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,bool,bool,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,byref,byref):this]
       jmp      G_M000_IG05
 
; Total bytes of code 552

; Assembly listing for method Lokad.Lython.Runtime.PyExecutableFunction:StartCompactNativeCall(Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,bool,bool,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,byref,byref):this (Tier1)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; Tier1 code
; optimized code
; optimized using Synthesized PGO
; rbp based frame
; partially interruptible
; with Synthesized PGO: fgCalledCount is 100
; No PGO data
; 6 inlinees with PGO data; 11 single block inlinees; 1 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       push     r14
       push     rdi
       push     rsi
       push     rbx
       sub      rsp, 320
       lea      rbp, [rsp+0x160]
       xor      eax, eax
       mov      qword ptr [rbp-0x108], rax
       vxorps   xmm4, xmm4, xmm4
       vmovdqa  xmmword ptr [rbp-0x100], xmm4
       vmovdqa  xmmword ptr [rbp-0xF0], xmm4
       mov      rax, -192
 
G_M000_IG14:                ;; offset=0x003C
       vmovdqa  xmmword ptr [rbp+rax-0x20], xmm4
       vmovdqa  xmmword ptr [rbp+rax-0x10], xmm4
       vmovdqa  xmmword ptr [rax+rbp], xmm4
       add      rax, 48
       jne      SHORT G_M000_IG14
       mov      rbx, rcx
       mov      rsi, bword ptr [rbp+0x50]
 
G_M000_IG02:                ;; offset=0x005A
       mov      rax, bword ptr [r8]
       mov      edi, dword ptr [r8+0x08]
       mov      rcx, gword ptr [rbx+0x40]
       mov      r14d, dword ptr [rcx+0xD4]
       cmp      r14d, 8
       ja       G_M000_IG06
       cmp      byte  ptr [rbp+0x48], 0
       je       G_M000_IG11
       xor      ecx, ecx
       test     r9, r9
       jne      G_M000_IG07
 
G_M000_IG03:                ;; offset=0x008B
       cmp      ecx, r14d
       ja       G_M000_IG06
       lea      rdx, bword ptr [rbp-0xA0]
       mov      r8d, ecx
       shl      r8, 4
       add      r8, rdx
       mov      edx, r14d
       sub      edx, ecx
       cmp      edi, edx
       ja       G_M000_IG10
       mov      ecx, edi
       shl      rcx, 4
       mov      r10, rcx
       cmp      r10, 0x4000
       ja       G_M000_IG09
       mov      rcx, r8
       mov      rdx, rax
       mov      r8, r10
       call     System.Buffer:BulkMoveWithWriteBarrierInternal(byref,byref,nuint)
       cmp      dword ptr [(reloc 0x7ffa61d42aa8)], 0
       jne      G_M000_IG08
 
G_M000_IG04:                ;; offset=0x00E3
       vxorps   ymm0, ymm0, ymm0
       vmovdqu  ymmword ptr [rbp-0xC0], ymm0
       lea      rdx, bword ptr [rbp-0xA0]
       mov      bword ptr [rbp-0xE8], rdx
       mov      dword ptr [rbp-0xE0], r14d
       movzx    rdx, byte  ptr [rbp+0x40]
       mov      dword ptr [rsp+0x20], edx
       mov      bword ptr [rsp+0x28], rsi
       mov      rsi, bword ptr [rbp+0x58]
       mov      bword ptr [rsp+0x30], rsi
       mov      rsi, bword ptr [rbp+0x60]
       mov      bword ptr [rsp+0x38], rsi
       mov      rsi, bword ptr [rbp+0x68]
       mov      bword ptr [rsp+0x40], rsi
       lea      rdx, [rbp-0xD8]
       mov      qword ptr [rsp+0x48], rdx
       lea      rdx, [rbp-0xE8]
       lea      r8, [rbp-0xC0]
       mov      rcx, rbx
       mov      r9, gword ptr [rbp+0x38]
       call     [Lokad.Lython.Runtime.PyExecutableFunction:StartInline(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.Nullable`1[Lokad.Lython.Runtime.BoundFunctionArguments],Lokad.Lython.LythonSourceSpan,bool,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,byref,byref,byref):this]
       nop      
 
G_M000_IG05:                ;; offset=0x0154
       add      rsp, 320
       pop      rbx
       pop      rsi
       pop      rdi
       pop      r14
       pop      rbp
       ret      
 
G_M000_IG06:                ;; offset=0x0162
       call     [System.ThrowHelper:ThrowArgumentOutOfRangeException()]
       int3     
 
G_M000_IG07:                ;; offset=0x0169
       mov      ecx, 1
       test     r14d, r14d
       je       G_M000_IG13
       mov      gword ptr [rbp-0xA0], r9
       xor      edx, edx
       mov      qword ptr [rbp-0x98], rdx
       jmp      G_M000_IG03
 
G_M000_IG08:                ;; offset=0x018C
       call     CORINFO_HELP_POLL_GC
       jmp      G_M000_IG04
 
G_M000_IG09:                ;; offset=0x0196
       mov      rcx, r8
       mov      rdx, rax
       mov      r8, r10
       call     [System.Buffer:BulkMoveWithWriteBarrierBatch(byref,byref,nuint)]
       jmp      G_M000_IG04
 
G_M000_IG10:                ;; offset=0x01AA
       call     [System.ThrowHelper:ThrowArgumentException_DestinationTooShort()]
       int3     
 
G_M000_IG11:                ;; offset=0x01B1
       mov      rcx, gword ptr [rbx+0x08]
       mov      rcx, gword ptr [rcx+0x08]
       mov      ecx, dword ptr [rcx+0x08]
       cmp      ecx, r14d
       ja       SHORT G_M000_IG06
       lea      r8, bword ptr [rbp-0xA0]
       mov      bword ptr [rbp-0xE8], r8
       mov      dword ptr [rbp-0xE0], ecx
       xor      rcx, rcx
       mov      bword ptr [rbp-0xF8], rcx
 
G_M000_IG12:                ;; offset=0x01DE
       mov      dword ptr [rbp-0xF0], ecx
       mov      rcx, gword ptr [rbp+0x30]
       mov      gword ptr [rsp+0x20], rcx
       xor      ecx, ecx
       mov      dword ptr [rsp+0x28], ecx
       mov      gword ptr [rsp+0x30], r9
       mov      gword ptr [rsp+0x38], rdx
       mov      bword ptr [rbp-0x108], rax
       mov      dword ptr [rbp-0x100], edi
       lea      rcx, [rbp-0xE8]
       lea      rdx, [rbp-0xF8]
       lea      r9, [rbp-0x108]
       mov      qword ptr [rsp+0x40], r9
       mov      r9, rbx
       mov      r8, gword ptr [rbp+0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime:BindFunctionArgumentsInto(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.ReadOnlySpan`1[Lokad.Lython.Runtime.CallArgumentValue],Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.FunctionBindingPlan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,bool,System.Object,Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):int]
       jmp      G_M000_IG04
 
G_M000_IG13:                ;; offset=0x0236
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
; Total bytes of code 572

; Assembly listing for method Lokad.Lython.Runtime.PyExecutableFunction:StartNativeCallWithStorage(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,bool,bool,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,byref,byref):this (Tier1)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; Tier1 code
; optimized code
; optimized using Synthesized PGO
; rbp based frame
; partially interruptible
; with Synthesized PGO: fgCalledCount is 23296
; 5 inlinees with PGO data; 8 single block inlinees; 1 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       push     r15
       push     r14
       push     r13
       push     r12
       push     rdi
       push     rsi
       push     rbx
       sub      rsp, 184
       lea      rbp, [rsp+0xF0]
       vxorps   xmm4, xmm4, xmm4
       vmovdqu  ymmword ptr [rbp-0xA0], ymm4
       vmovdqu  ymmword ptr [rbp-0x80], ymm4
       vmovdqu  ymmword ptr [rbp-0x60], ymm4
       xor      eax, eax
       mov      qword ptr [rbp-0x40], rax
       mov      rbx, rcx
       mov      rsi, bword ptr [rbp+0x58]
 
G_M000_IG02:                ;; offset=0x003E
       mov      rdi, bword ptr [r9]
       mov      r14d, dword ptr [r9+0x08]
       mov      r15, bword ptr [rdx]
       mov      ecx, dword ptr [rdx+0x08]
       mov      rdx, gword ptr [rbx+0x40]
       mov      r13d, dword ptr [rdx+0xD4]
       cmp      r13d, ecx
       ja       G_M000_IG06
       cmp      byte  ptr [rbp+0x50], 0
       je       G_M000_IG11
       xor      r12d, r12d
       mov      rdx, gword ptr [rbp+0x30]
       test     rdx, rdx
       jne      G_M000_IG07
 
G_M000_IG03:                ;; offset=0x0079
       cmp      r12d, r13d
       ja       G_M000_IG06
       mov      ecx, r12d
       shl      rcx, 4
       add      rcx, r15
       mov      edx, r13d
       sub      edx, r12d
       cmp      r14d, edx
       ja       G_M000_IG10
       mov      r8d, r14d
       shl      r8, 4
       cmp      r8, 0x4000
       ja       G_M000_IG09
       mov      rdx, rdi
       call     System.Buffer:BulkMoveWithWriteBarrierInternal(byref,byref,nuint)
       cmp      dword ptr [(reloc 0x7ffa61d42aa8)], 0
       jne      G_M000_IG08
 
G_M000_IG04:                ;; offset=0x00C4
       vxorps   ymm0, ymm0, ymm0
       vmovdqu  ymmword ptr [rbp-0x70], ymm0
       mov      bword ptr [rbp-0x80], r15
       mov      dword ptr [rbp-0x78], r13d
       movzx    rdx, byte  ptr [rbp+0x48]
       mov      dword ptr [rsp+0x20], edx
       mov      bword ptr [rsp+0x28], rsi
       mov      rsi, bword ptr [rbp+0x60]
       mov      bword ptr [rsp+0x30], rsi
       mov      rsi, bword ptr [rbp+0x68]
       mov      bword ptr [rsp+0x38], rsi
       mov      rsi, bword ptr [rbp+0x70]
       mov      bword ptr [rsp+0x40], rsi
       lea      rdx, [rbp-0x50]
       mov      qword ptr [rsp+0x48], rdx
       lea      rdx, [rbp-0x80]
       lea      r8, [rbp-0x70]
       mov      rcx, rbx
       mov      r9, gword ptr [rbp+0x40]
       call     [Lokad.Lython.Runtime.PyExecutableFunction:StartInline(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.Nullable`1[Lokad.Lython.Runtime.BoundFunctionArguments],Lokad.Lython.LythonSourceSpan,bool,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,byref,byref,byref):this]
       nop      
 
G_M000_IG05:                ;; offset=0x011C
       add      rsp, 184
       pop      rbx
       pop      rsi
       pop      rdi
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG06:                ;; offset=0x0130
       call     [System.ThrowHelper:ThrowArgumentOutOfRangeException()]
       int3     
 
G_M000_IG07:                ;; offset=0x0137
       mov      r12d, 1
       test     r13d, r13d
       je       G_M000_IG13
       mov      rcx, r15
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       xor      ecx, ecx
       mov      qword ptr [r15+0x08], rcx
       jmp      G_M000_IG03
 
G_M000_IG08:                ;; offset=0x0159
       call     CORINFO_HELP_POLL_GC
       jmp      G_M000_IG04
 
G_M000_IG09:                ;; offset=0x0163
       mov      rdx, rdi
       call     [System.Buffer:BulkMoveWithWriteBarrierBatch(byref,byref,nuint)]
       jmp      G_M000_IG04
 
G_M000_IG10:                ;; offset=0x0171
       call     [System.ThrowHelper:ThrowArgumentException_DestinationTooShort()]
       int3     
 
G_M000_IG11:                ;; offset=0x0178
       mov      rcx, gword ptr [rbx+0x08]
       mov      rcx, gword ptr [rcx+0x08]
       mov      ecx, dword ptr [rcx+0x08]
       cmp      ecx, r13d
       ja       SHORT G_M000_IG06
       mov      bword ptr [rbp-0x80], r15
       mov      dword ptr [rbp-0x78], ecx
       xor      rcx, rcx
       mov      bword ptr [rbp-0x90], rcx
 
G_M000_IG12:                ;; offset=0x0198
       mov      dword ptr [rbp-0x88], ecx
       mov      rcx, gword ptr [rbp+0x38]
       mov      gword ptr [rsp+0x20], rcx
       xor      ecx, ecx
       mov      dword ptr [rsp+0x28], ecx
       mov      rdx, gword ptr [rbp+0x30]
       mov      gword ptr [rsp+0x30], rdx
       mov      gword ptr [rsp+0x38], r8
       mov      bword ptr [rbp-0xA0], rdi
       mov      dword ptr [rbp-0x98], r14d
       lea      rcx, [rbp-0x80]
       lea      rdx, [rbp-0x90]
       lea      r9, [rbp-0xA0]
       mov      qword ptr [rsp+0x40], r9
       mov      r9, rbx
       mov      r8, gword ptr [rbp+0x40]
       call     [Lokad.Lython.Runtime.LythonRuntime:BindFunctionArgumentsInto(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.ReadOnlySpan`1[Lokad.Lython.Runtime.CallArgumentValue],Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.FunctionBindingPlan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,bool,System.Object,Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):int]
       jmp      G_M000_IG04
 
G_M000_IG13:                ;; offset=0x01F2
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
; Total bytes of code 504

; Assembly listing for method Lokad.Lython.Runtime.PyExecutableFunction:StartWideNativeCall(Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,bool,bool,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,byref,byref):this (Tier0)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; Tier0 code
; rbp based frame
; partially interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 432
       lea      rbp, [rsp+0x1B0]
       vxorps   xmm4, xmm4, xmm4
       vmovdqa  xmmword ptr [rbp-0x140], xmm4
       vmovdqa  xmmword ptr [rbp-0x130], xmm4
       mov      rax, -288
 
G_M000_IG10:                ;; offset=0x002E
       vmovdqa  xmmword ptr [rax+rbp], xmm4
       vmovdqa  xmmword ptr [rbp+rax+0x10], xmm4
       vmovdqa  xmmword ptr [rbp+rax+0x20], xmm4
       add      rax, 48
       jne      SHORT G_M000_IG10
       mov      gword ptr [rbp+0x10], rcx
       mov      gword ptr [rbp+0x18], rdx
       mov      bword ptr [rbp+0x20], r8
       mov      gword ptr [rbp+0x28], r9
 
G_M000_IG02:                ;; offset=0x0055
       vxorps   ymm0, ymm0, ymm0
       vmovdqu  ymmword ptr [rbp-0x100], ymm0
       vmovdqu  ymmword ptr [rbp-0xE0], ymm0
       vmovdqu  ymmword ptr [rbp-0xC0], ymm0
       vmovdqu  ymmword ptr [rbp-0xA0], ymm0
       vmovdqu  ymmword ptr [rbp-0x80], ymm0
       vmovdqu  ymmword ptr [rbp-0x60], ymm0
       vmovdqu  ymmword ptr [rbp-0x40], ymm0
       vmovdqu  ymmword ptr [rbp-0x20], ymm0
       lea      rdx, [rbp-0x100]
       lea      rcx, [rbp-0x110]
       mov      r8d, 16
       call     [<PrivateImplementationDetails>:InlineArrayAsSpan[Lokad.Lython.Runtime.PyExecutableFunction+NativeValues,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot](byref,int):System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]]
 
G_M000_IG03:                ;; offset=0x00A7
       vmovdqu  xmm0, xmmword ptr [rbp-0x110]
       vmovdqu  xmmword ptr [rbp-0x120], xmm0
 
G_M000_IG04:                ;; offset=0x00B7
       mov      rax, bword ptr [rbp+0x20]
 
G_M000_IG05:                ;; offset=0x00BB
       vmovdqu  xmm0, xmmword ptr [rax]
       vmovdqu  xmmword ptr [rbp-0x130], xmm0
 
G_M000_IG06:                ;; offset=0x00C7
       mov      rax, gword ptr [rbp+0x28]
       mov      gword ptr [rsp+0x20], rax
       mov      rax, gword ptr [rbp+0x30]
       mov      gword ptr [rsp+0x28], rax
       mov      rax, gword ptr [rbp+0x38]
       mov      gword ptr [rsp+0x30], rax
       movzx    rax, byte  ptr [rbp+0x40]
       mov      dword ptr [rsp+0x38], eax
       movzx    rax, byte  ptr [rbp+0x48]
       mov      dword ptr [rsp+0x40], eax
       mov      rax, bword ptr [rbp+0x50]
 
G_M000_IG07:                ;; offset=0x00F6
       vmovdqu  xmm0, xmmword ptr [rax]
       vmovdqu  xmmword ptr [rbp-0x140], xmm0
 
G_M000_IG08:                ;; offset=0x0102
       mov      rax, bword ptr [rbp+0x58]
       mov      bword ptr [rsp+0x50], rax
       mov      rax, bword ptr [rbp+0x60]
       mov      bword ptr [rsp+0x58], rax
       mov      rax, bword ptr [rbp+0x68]
       mov      bword ptr [rsp+0x60], rax
       lea      rdx, [rbp-0x120]
       lea      r9, [rbp-0x130]
       lea      rax, [rbp-0x140]
       mov      qword ptr [rsp+0x48], rax
       mov      rcx, gword ptr [rbp+0x10]
       mov      r8, gword ptr [rbp+0x18]
       call     [Lokad.Lython.Runtime.PyExecutableFunction:StartNativeCallWithStorage(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,bool,bool,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,byref,byref):this]
       nop      
 
G_M000_IG09:                ;; offset=0x0146
       add      rsp, 432
       pop      rbp
       ret      
 
; Total bytes of code 335

; Assembly listing for method Lokad.Lython.Runtime.PyExecutableFunction:StartWideNativeCall(Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,bool,bool,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,byref,byref):this (Instrumented Tier0)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; Instrumented Tier0 code
; rbp based frame
; partially interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 432
       lea      rbp, [rsp+0x1B0]
       vxorps   xmm4, xmm4, xmm4
       vmovdqa  xmmword ptr [rbp-0x140], xmm4
       vmovdqa  xmmword ptr [rbp-0x130], xmm4
       mov      rax, -288
 
G_M000_IG10:                ;; offset=0x002E
       vmovdqa  xmmword ptr [rax+rbp], xmm4
       vmovdqa  xmmword ptr [rbp+rax+0x10], xmm4
       vmovdqa  xmmword ptr [rbp+rax+0x20], xmm4
       add      rax, 48
       jne      SHORT G_M000_IG10
       mov      gword ptr [rbp+0x10], rcx
       mov      gword ptr [rbp+0x18], rdx
       mov      bword ptr [rbp+0x20], r8
       mov      gword ptr [rbp+0x28], r9
 
G_M000_IG02:                ;; offset=0x0055
       vxorps   ymm0, ymm0, ymm0
       vmovdqu  ymmword ptr [rbp-0x100], ymm0
       vmovdqu  ymmword ptr [rbp-0xE0], ymm0
       vmovdqu  ymmword ptr [rbp-0xC0], ymm0
       vmovdqu  ymmword ptr [rbp-0xA0], ymm0
       vmovdqu  ymmword ptr [rbp-0x80], ymm0
       vmovdqu  ymmword ptr [rbp-0x60], ymm0
       vmovdqu  ymmword ptr [rbp-0x40], ymm0
       vmovdqu  ymmword ptr [rbp-0x20], ymm0
       lea      rdx, [rbp-0x100]
       lea      rcx, [rbp-0x110]
       mov      r8d, 16
       call     [<PrivateImplementationDetails>:InlineArrayAsSpan[Lokad.Lython.Runtime.PyExecutableFunction+NativeValues,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot](byref,int):System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]]
 
G_M000_IG03:                ;; offset=0x00A7
       vmovdqu  xmm0, xmmword ptr [rbp-0x110]
       vmovdqu  xmmword ptr [rbp-0x120], xmm0
 
G_M000_IG04:                ;; offset=0x00B7
       mov      rax, bword ptr [rbp+0x20]
 
G_M000_IG05:                ;; offset=0x00BB
       vmovdqu  xmm0, xmmword ptr [rax]
       vmovdqu  xmmword ptr [rbp-0x130], xmm0
 
G_M000_IG06:                ;; offset=0x00C7
       mov      rax, gword ptr [rbp+0x28]
       mov      gword ptr [rsp+0x20], rax
       mov      rax, gword ptr [rbp+0x30]
       mov      gword ptr [rsp+0x28], rax
       mov      rax, gword ptr [rbp+0x38]
       mov      gword ptr [rsp+0x30], rax
       movzx    rax, byte  ptr [rbp+0x40]
       mov      dword ptr [rsp+0x38], eax
       movzx    rax, byte  ptr [rbp+0x48]
       mov      dword ptr [rsp+0x40], eax
       mov      rax, bword ptr [rbp+0x50]
 
G_M000_IG07:                ;; offset=0x00F6
       vmovdqu  xmm0, xmmword ptr [rax]
       vmovdqu  xmmword ptr [rbp-0x140], xmm0
 
G_M000_IG08:                ;; offset=0x0102
       mov      rax, bword ptr [rbp+0x58]
       mov      bword ptr [rsp+0x50], rax
       mov      rax, bword ptr [rbp+0x60]
       mov      bword ptr [rsp+0x58], rax
       mov      rax, bword ptr [rbp+0x68]
       mov      bword ptr [rsp+0x60], rax
       lea      rdx, [rbp-0x120]
       lea      r9, [rbp-0x130]
       lea      rax, [rbp-0x140]
       mov      qword ptr [rsp+0x48], rax
       mov      rcx, gword ptr [rbp+0x10]
       mov      r8, gword ptr [rbp+0x18]
       call     [Lokad.Lython.Runtime.PyExecutableFunction:StartNativeCallWithStorage(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,bool,bool,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,byref,byref):this]
       nop      
 
G_M000_IG09:                ;; offset=0x0146
       add      rsp, 432
       pop      rbp
       ret      
 
; Total bytes of code 335

; Assembly listing for method Lokad.Lython.Runtime.PyExecutableFunction:StartWideNativeCall(Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,bool,bool,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,byref,byref):this (Tier1)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; Tier1 code
; optimized code
; optimized using Synthesized PGO
; rbp based frame
; partially interruptible
; with Synthesized PGO: fgCalledCount is 100
; No PGO data
; 6 inlinees with PGO data; 11 single block inlinees; 1 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       push     r14
       push     rdi
       push     rsi
       push     rbx
       sub      rsp, 448
       lea      rbp, [rsp+0x1E0]
       xor      eax, eax
       mov      qword ptr [rbp-0x188], rax
       vxorps   xmm4, xmm4, xmm4
       vmovdqa  xmmword ptr [rbp-0x180], xmm4
       mov      rax, -336
 
G_M000_IG14:                ;; offset=0x0034
       vmovdqa  xmmword ptr [rbp+rax-0x20], xmm4
       vmovdqa  xmmword ptr [rbp+rax-0x10], xmm4
       vmovdqa  xmmword ptr [rax+rbp], xmm4
       add      rax, 48
       jne      SHORT G_M000_IG14
       mov      rbx, rcx
       mov      rsi, bword ptr [rbp+0x50]
 
G_M000_IG02:                ;; offset=0x0052
       mov      rax, bword ptr [r8]
       mov      edi, dword ptr [r8+0x08]
       mov      rcx, gword ptr [rbx+0x40]
       mov      r14d, dword ptr [rcx+0xD4]
       cmp      r14d, 16
       ja       G_M000_IG06
       cmp      byte  ptr [rbp+0x48], 0
       je       G_M000_IG11
       xor      ecx, ecx
       test     r9, r9
       jne      G_M000_IG07
 
G_M000_IG03:                ;; offset=0x0083
       cmp      ecx, r14d
       ja       G_M000_IG06
       lea      rdx, bword ptr [rbp-0x120]
       mov      r8d, ecx
       shl      r8, 4
       add      r8, rdx
       mov      edx, r14d
       sub      edx, ecx
       cmp      edi, edx
       ja       G_M000_IG10
       mov      ecx, edi
       shl      rcx, 4
       mov      r10, rcx
       cmp      r10, 0x4000
       ja       G_M000_IG09
       mov      rcx, r8
       mov      rdx, rax
       mov      r8, r10
       call     System.Buffer:BulkMoveWithWriteBarrierInternal(byref,byref,nuint)
       cmp      dword ptr [(reloc 0x7ffa61d42aa8)], 0
       jne      G_M000_IG08
 
G_M000_IG04:                ;; offset=0x00DB
       vxorps   ymm0, ymm0, ymm0
       vmovdqu  ymmword ptr [rbp-0x140], ymm0
       lea      rdx, bword ptr [rbp-0x120]
       mov      bword ptr [rbp-0x168], rdx
       mov      dword ptr [rbp-0x160], r14d
       movzx    rdx, byte  ptr [rbp+0x40]
       mov      dword ptr [rsp+0x20], edx
       mov      bword ptr [rsp+0x28], rsi
       mov      rsi, bword ptr [rbp+0x58]
       mov      bword ptr [rsp+0x30], rsi
       mov      rsi, bword ptr [rbp+0x60]
       mov      bword ptr [rsp+0x38], rsi
       mov      rsi, bword ptr [rbp+0x68]
       mov      bword ptr [rsp+0x40], rsi
       lea      rdx, [rbp-0x158]
       mov      qword ptr [rsp+0x48], rdx
       lea      rdx, [rbp-0x168]
       lea      r8, [rbp-0x140]
       mov      rcx, rbx
       mov      r9, gword ptr [rbp+0x38]
       call     [Lokad.Lython.Runtime.PyExecutableFunction:StartInline(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.Nullable`1[Lokad.Lython.Runtime.BoundFunctionArguments],Lokad.Lython.LythonSourceSpan,bool,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,byref,byref,byref):this]
       nop      
 
G_M000_IG05:                ;; offset=0x014C
       add      rsp, 448
       pop      rbx
       pop      rsi
       pop      rdi
       pop      r14
       pop      rbp
       ret      
 
G_M000_IG06:                ;; offset=0x015A
       call     [System.ThrowHelper:ThrowArgumentOutOfRangeException()]
       int3     
 
G_M000_IG07:                ;; offset=0x0161
       mov      ecx, 1
       test     r14d, r14d
       je       G_M000_IG13
       mov      gword ptr [rbp-0x120], r9
       xor      edx, edx
       mov      qword ptr [rbp-0x118], rdx
       jmp      G_M000_IG03
 
G_M000_IG08:                ;; offset=0x0184
       call     CORINFO_HELP_POLL_GC
       jmp      G_M000_IG04
 
G_M000_IG09:                ;; offset=0x018E
       mov      rcx, r8
       mov      rdx, rax
       mov      r8, r10
       call     [System.Buffer:BulkMoveWithWriteBarrierBatch(byref,byref,nuint)]
       jmp      G_M000_IG04
 
G_M000_IG10:                ;; offset=0x01A2
       call     [System.ThrowHelper:ThrowArgumentException_DestinationTooShort()]
       int3     
 
G_M000_IG11:                ;; offset=0x01A9
       mov      rcx, gword ptr [rbx+0x08]
       mov      rcx, gword ptr [rcx+0x08]
       mov      ecx, dword ptr [rcx+0x08]
       cmp      ecx, r14d
       ja       SHORT G_M000_IG06
       lea      r8, bword ptr [rbp-0x120]
       mov      bword ptr [rbp-0x168], r8
       mov      dword ptr [rbp-0x160], ecx
       xor      rcx, rcx
       mov      bword ptr [rbp-0x178], rcx
 
G_M000_IG12:                ;; offset=0x01D6
       mov      dword ptr [rbp-0x170], ecx
       mov      rcx, gword ptr [rbp+0x30]
       mov      gword ptr [rsp+0x20], rcx
       xor      ecx, ecx
       mov      dword ptr [rsp+0x28], ecx
       mov      gword ptr [rsp+0x30], r9
       mov      gword ptr [rsp+0x38], rdx
       mov      bword ptr [rbp-0x188], rax
       mov      dword ptr [rbp-0x180], edi
       lea      rcx, [rbp-0x168]
       lea      rdx, [rbp-0x178]
       lea      r9, [rbp-0x188]
       mov      qword ptr [rsp+0x40], r9
       mov      r9, rbx
       mov      r8, gword ptr [rbp+0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime:BindFunctionArgumentsInto(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.ReadOnlySpan`1[Lokad.Lython.Runtime.CallArgumentValue],Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.FunctionBindingPlan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,bool,System.Object,Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):int]
       jmp      G_M000_IG04
 
G_M000_IG13:                ;; offset=0x022E
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
; Total bytes of code 564

