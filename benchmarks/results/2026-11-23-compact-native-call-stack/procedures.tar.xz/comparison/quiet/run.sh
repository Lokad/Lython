set -eu
root=/home/lokad/lython-bench-checks/compact-native-call-stack-b1450-20261123
trap 'result=$?; printf "%s\n" "$result" > "$root/exit-code.txt"' EXIT
python3 "$root/collect.py"
