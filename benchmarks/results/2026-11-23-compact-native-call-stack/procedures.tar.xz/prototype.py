from pathlib import Path
p=Path(".git/agent-worktrees/compact-native-call-stack-20261123/src/Lokad.Lython/Runtime/PyExecutableFunction.cs")
data=p.read_bytes()
s=data.decode("utf-8").replace("\r\n","\n")
old="""    [System.Runtime.CompilerServices.InlineArray(LythonRuntime.NativeValueCapacity)]
    private struct NativeValues { private LythonRuntime.ExecutableSlot _first; }"""
new="""    private const int CompactNativeValueCapacity = 8;

    [System.Runtime.CompilerServices.InlineArray(CompactNativeValueCapacity)]
    private struct CompactNativeValues { private LythonRuntime.ExecutableSlot _first; }

    [System.Runtime.CompilerServices.InlineArray(LythonRuntime.NativeValueCapacity)]
    private struct NativeValues { private LythonRuntime.ExecutableSlot _first; }"""
assert s.count(old)==1
s=s.replace(old,new)
a=s.index("        // Both executable callers select eligibility before entry.")
b=s.index("        // This span is private",a)
s=s[:a]+"""        // Keep the stack blocks in separate methods. The direct return
        // above needs no cleared locals, and an eight-slot body never pays
        // for a sixteen-slot CLR frame.
        if (CodeObject.ValueStorageCapacity <= CompactNativeValueCapacity)
            StartCompactNativeCall(call, arguments, receiver, context, span, consumedByIteration,
                completePositional, unpackedReturn, out unpacked, out result, out frame);
        else
            StartWideNativeCall(call, arguments, receiver, context, span, consumedByIteration,
                completePositional, unpackedReturn, out unpacked, out result, out frame);
    }

    [System.Runtime.CompilerServices.MethodImpl(System.Runtime.CompilerServices.MethodImplOptions.NoInlining)]
    private void StartCompactNativeCall(ExecutableCallSite call, ReadOnlySpan<LythonRuntime.ExecutableSlot> arguments,
        object? receiver, LythonRuntime.ExecutionContext context, LythonSourceSpan span, bool consumedByIteration,
        bool completePositional, Span<LythonRuntime.ExecutableSlot> unpackedReturn, out bool unpacked,
        out LythonRuntime.ExecutableSlot result, out LythonRuntime.ExecutionContext? frame)
    {
        CompactNativeValues buffer = default;
        StartNativeCallWithStorage(buffer, call, arguments, receiver, context, span, consumedByIteration,
            completePositional, unpackedReturn, out unpacked, out result, out frame);
    }

    [System.Runtime.CompilerServices.MethodImpl(System.Runtime.CompilerServices.MethodImplOptions.NoInlining)]
    private void StartWideNativeCall(ExecutableCallSite call, ReadOnlySpan<LythonRuntime.ExecutableSlot> arguments,
        object? receiver, LythonRuntime.ExecutionContext context, LythonSourceSpan span, bool consumedByIteration,
        bool completePositional, Span<LythonRuntime.ExecutableSlot> unpackedReturn, out bool unpacked,
        out LythonRuntime.ExecutableSlot result, out LythonRuntime.ExecutionContext? frame)
    {
        NativeValues buffer = default;
        StartNativeCallWithStorage(buffer, call, arguments, receiver, context, span, consumedByIteration,
            completePositional, unpackedReturn, out unpacked, out result, out frame);
    }

    // Selection, binding and transfers are common to both storage widths.
    private void StartNativeCallWithStorage(Span<LythonRuntime.ExecutableSlot> values, ExecutableCallSite call,
        ReadOnlySpan<LythonRuntime.ExecutableSlot> arguments, object? receiver, LythonRuntime.ExecutionContext context,
        LythonSourceSpan span, bool consumedByIteration, bool completePositional,
        Span<LythonRuntime.ExecutableSlot> unpackedReturn, out bool unpacked, out LythonRuntime.ExecutableSlot result,
        out LythonRuntime.ExecutionContext? frame)
    {
        values = values[..CodeObject.ValueStorageCapacity];
""" + s[b:]
p.write_bytes(s.replace("\n","\r\n" if b"\r\n" in data else "\n").encode("utf-8"))
