#!/bin/bash
set -euo pipefail
cd /mnt/d/code/Lython/.git/agent-worktrees/compact-native-call-stack-20261123
export DOTNET_ROOT="$HOME/.dotnet"
export PATH="$DOTNET_ROOT:$PATH"
export DOTNET_HOST_PATH="$DOTNET_ROOT/dotnet"
lab=/mnt/d/code/Lython/.git/agent-notes/review-20261031/native-stack-initialization-20261123
white='Category!=Stress&(FullyQualifiedName~Native|FullyQualifiedName~FunctionDefault|FullyQualifiedName~ExecutableCallFrame|FullyQualifiedName~ManagedStackGuard)'
public='Category!=Stress&(FullyQualifiedName~CooperativeCancellation|FullyQualifiedName~PreparedFunction|FullyQualifiedName~StackGuardScenario|FullyQualifiedName~RecursionDepthScenario|FullyQualifiedName~NativeWorkStateDispatch|FullyQualifiedName~NativeStorageTransfer|FullyQualifiedName~NativeSliceSuspension|FullyQualifiedName~NativeOperationAdmission|FullyQualifiedName~NativeProtocolDictionaryWrite)'
dotnet build tools/LythonProbe/LythonProbe.csproj -c Release -f net10.0 > "$lab/probe-ubuntu.log" 2>&1 || { tail -38 "$lab/probe-ubuntu.log"; exit 1; }
dotnet test tests/Lokad.Lython.Tests -c Release -f net10.0 --artifacts-path "$lab/ubuntu" --filter "$white" > "$lab/white-ubuntu.log" 2>&1 || { tail -38 "$lab/white-ubuntu.log"; exit 1; }
dotnet test tests/Lokad.Lython.PublicApi.Tests -c Release -f net10.0 --artifacts-path "$lab/ubuntu" --filter "$public" > "$lab/public-ubuntu.log" 2>&1 || { tail -38 "$lab/public-ubuntu.log"; exit 1; }
awk '/Passed!/{count++;print} END{exit count!=2}' "$lab/white-ubuntu.log" "$lab/public-ubuntu.log"
