from pathlib import Path
import json,re,hashlib

lab=Path(__file__).resolve().parent
pair=lab/"comparison"
identity=json.loads((pair/"identity.json").read_text(encoding="utf-8"))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
data=[]
for platform,SUFFIX,PROOF in (("Windows","",".json"),("Ubuntu WSL","-linux","-linux-disasm-verified.json")):
    for role,files in identity["imageFiles"].items():
        image=pair/f"frozen-{role}"
        assert {n:sha(image/n) for n in files}==files
        output=pair/f"{role}-native-calls{SUFFIX}.asm"
        text=output.read_text(encoding="utf-8-sig")
        methods=[]
        for block in text.split("; Assembly listing for method ")[1:]:
            signature,body=block.split("\n",1)
            if not re.search(r"\(Tier1\)$",signature): continue
            method=signature.split(":",1)[1].split("(",1)[0]
            start,=re.findall(r"sub\s+rsp,\s*(\d+)",body)
            pushes=re.findall(r"push\s+(r[a-z0-9]+)",body)
            count,=re.findall(r"Total bytes of code (\d+)",body)
            methods.append(dict(method=method,stackSubtraction=int(start),savedRegisters=len(pushes),codeBytes=int(count),
                initializesByteVectors=len(re.findall(r"vmovdq[a-z]?[^\n]+ymm0",body)),
                callsStackWidths=re.findall(r"(?:call|jmp)\s+\[.*PyExecutableFunction:(Start(?:Compact|Wide)NativeCall)\(",body)))
        assert {m["method"] for m in methods} >= {"StartNativeCall"}
        if role=="candidate":
            assert {m["method"] for m in methods}>={"StartCompactNativeCall","StartWideNativeCall"}
        data.append(dict(platform=platform,role=role,coreSHA256=files["Lokad.Lython.dll"],traceSHA256=sha(output),methods=methods))
        for row in methods: print(platform,role,row)
(lab/"native-jit-summary.json").write_text(json.dumps(data,ensure_ascii=False,indent=2)+"\n",encoding="utf-8",newline="\n")
