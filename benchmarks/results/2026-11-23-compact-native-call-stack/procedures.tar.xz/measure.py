from pathlib import Path
import hashlib
import io
import tarfile
import json
import os
import shutil
import statistics
import subprocess

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
tree = repo / ".git/agent-worktrees/compact-native-call-stack-20261123"
previous = lab.parent / "reuse-private-word-admission-20261123" / "comparison"
out = lab / "comparison"
out.mkdir()
def read(p): return json.loads(p.read_text(encoding="utf-8-sig"))
def sha(data): return hashlib.sha256(data).hexdigest()
def digest(p): return sha(p.read_bytes())
def save(p, value): p.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8", newline="\n")
def git(*args, cwd=repo): return subprocess.check_output(["git", *args], cwd=cwd)

core = "Lokad.Lython.dll"
published = read(repo / "benchmarks/results/2026-11-23-reusable-private-word-admission/source.json")
known = published["imageFiles"]["candidate"]
reference = previous / "frozen-candidate"
assert len(known) == 32 and {n: digest(reference / n) for n in known} == known
base = git("rev-parse", "07f2b859d", cwd=tree).decode().strip()
assert not git("diff", "--name-only", published["retainedRevision"], base, "--", "src", "tests")
patch = git("diff", "--binary", base, "HEAD", "--", "src", "tests", cwd=tree)
assert patch.count(b"diff --git ") == 2
(out / "source.patch").write_bytes(patch)
python = Path("C:/Python313/python.exe")

catalog = out / "representative.json"
def archived(name):
    folder=f"benchmarks/results/{name}"
    read_git=lambda f:git("show",f"origin/master:{folder}/{f}")
    receipt=json.loads(read_git("archive-receipt.json"))
    raw=read_git("observations.tgz")
    assert receipt["complete"] and receipt["archivedAndVerifiedUnderLease"] and sha(raw)==receipt["archiveSHA256"]
    with tarfile.open(fileobj=io.BytesIO(raw))as t:
        return json.load(t.extractfile("representative.json"))

catalog_value=archived("2026-11-23-module-native-workspace")
assert len(catalog_value["cases"])==7
template=next(c for c in catalog_value["cases"] if c["id"]=="calls.positional.large")
wide="""def apply(a,b,c,d,e,f,g,h,i,j,k):
    middle = a + f
    return a, k, middle

total = 0
for index in range(4096):
    low, high, middle = apply(index,2,3,4,5,6,7,8,9,10,11)
    total += low + high + middle
print(total)
"""
proof=subprocess.run([python,"-I","-S","-X","utf8","-c",wide],check=True,capture_output=True,timeout=20)
assert not proof.stderr
expected=proof.stdout.decode("utf-8").replace("\r\n","\n")
fixture = json.dumps(dict(size=4096,text=None),separators=(",",":"))
catalog_value["cases"].append(dict(template,id="calls.positional.wide-native-buffer",size=4096,source=wide,
    sourceUtf8Bytes=len(wide.encode("utf-8")),sourceSha256=sha(wide.encode("utf-8")),
    expectedOutput=expected,expectedOutputUtf8Bytes=len(expected.encode("utf-8")),expectedOutputSha256=sha(expected.encode("utf-8")),
    fixtureJson=fixture,fixtureSha256=sha(fixture.encode("utf-8"))))
assert len(catalog_value["cases"])==8
save(catalog,catalog_value)

sdk = Path.home() / ".dotnet11"
dotnet = sdk / "dotnet.exe"
env = dict(os.environ, DOTNET_ROOT=str(sdk), DOTNET_ROOT_X64=str(sdk), PATH=str(sdk)+os.pathsep+os.environ["PATH"])
protocol = repo / "benchmarks/cpython-worker.py"
assert digest(protocol) == published["protocolSHA256"]

images, allocation = {}, {}
candidate = lab / "private/bin/Lokad.Lython/release_net11.0" / core
for role, built in (("reference", reference / core), ("candidate", candidate)):
    image = out / f"frozen-{role}"
    image.mkdir()
    files = {**known, core: digest(built)}
    for name in files:
        shutil.copyfile(built if name == core else reference / name, image / name)
    assert {n: digest(image / n) for n in files} == files
    images[role] = files
    for suffix in (".dll", ".deps.json", ".runtimeconfig.json"):
        name = "ValidatedAllocation" + suffix
        shutil.copyfile(reference / name, image / name)
    proof = out / f"{role}-verify.json"
    subprocess.run([dotnet, image / "Lokad.Lython.Benchmarks.dll", "--compare", "verify", "--catalog", catalog,
        "--dotnet", dotnet, "--python", python, "--python-worker", protocol, "--out", proof],
        env=env, cwd=repo, check=True, timeout=90)
    state = read(proof)
    assert state["state"] == "Completed" and state["catalogSha256"] == digest(catalog) and state["caseCount"] == 8
    report = out / f"{role}-allocation.json"
    subprocess.run([dotnet, image / "ValidatedAllocation.dll", image, catalog, report],
        env=env, cwd=repo, check=True, timeout=85)
    rows = read(report)["rows"]
    assert len(rows) == 8 and all(r["sharedBudgetBaselineRestored"] for r in rows)
    allocation[role] = rows
    assert {n: digest(image / n) for n in files} == files

save(out / "identity.json", dict(reference=base, verifiedReferenceSource=published["candidate"], patchBase=base,
    sourcePatchSHA256=sha(patch), imageFiles=images, protocolSHA256=digest(protocol), catalogSHA256=digest(catalog)))
for before, after in zip(allocation["reference"], allocation["candidate"], strict=True):
    assert before["id"] == after["id"]
    a, b = (statistics.median(x["allocatedBytesPerInvocation"]) for x in (before, after))
    print(before["id"], a, b, b - a, round(100 * (b / a - 1), 3),
        before["peakExecutionMemoryBytes"], after["peakExecutionMemoryBytes"], flush=True)

probe_template=lab.parent/"current-frontend-phases/inspect/bin/Release/net11.0"
for role, hashes in images.items():
    image=out/f"frozen-{role}"
    for n in probe_template.glob("Inspect.*"):
        shutil.copyfile(n,image/n.name)
        assert digest(image/n.name)==digest(n)
    inspection=out/f"{role}-inspection.json"
    subprocess.run([dotnet,image/"Inspect.dll",catalog,inspection],env=env,cwd=repo,check=True,timeout=55)
    report=read(inspection)
    assert report["coreSHA256"]==hashes[core]
    rows=report["rows"]
    assert len(rows)==8
    for row in rows:
        print(role,row["id"],[(c["name"],c["capacity"],c["native"]) for c in row["codes"]],flush=True)
    disassembly=out/f"{role}-native-calls.asm"
    subprocess.run([dotnet,image/"ValidatedAllocation.dll",image,catalog,out/f"{role}-disasm-verified.json"],cwd=repo,
        env=dict(env,DOTNET_JitDisasm="Lokad.Lython.Runtime.PyExecutableFunction:Start*NativeCall*",DOTNET_JitStdOutFile=str(disassembly)),
        check=True,timeout=100)
    assert disassembly.is_file() and disassembly.stat().st_size>0
    assert {n:digest(image/n)for n in hashes}==hashes
