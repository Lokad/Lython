#!/bin/bash
set -euo pipefail
cd /mnt/d/code/Lython/.git/agent-worktrees/compact-native-call-stack-20261123
export DOTNET_ROOT="$HOME/.dotnet"
export PATH="$DOTNET_ROOT:$PATH"
export DOTNET_HOST_PATH="$DOTNET_ROOT/dotnet"
lab=/mnt/d/code/Lython/.git/agent-notes/review-20261031/native-stack-initialization-20261123
public='Category!=Stress&(FullyQualifiedName~CooperativeCancellation|FullyQualifiedName~PreparedFunction|FullyQualifiedName~StackGuardScenario|FullyQualifiedName~RecursionDepthScenario|FullyQualifiedName~NativeWorkStateDispatch|FullyQualifiedName~NativeStorageTransfer|FullyQualifiedName~NativeSliceSuspension|FullyQualifiedName~NativeOperationAdmission|FullyQualifiedName~NativeProtocolDictionaryWrite)'
dotnet test tests/Lokad.Lython.PublicApi.Tests -c Release -f net10.0 --artifacts-path ./tmp/nativecall-ubuntu --filter "$public" > "$lab/public-ubuntu.log" 2>&1 || { tail -45 "$lab/public-ubuntu.log"; exit 1; }
grep 'Passed!' "$lab/public-ubuntu.log"
