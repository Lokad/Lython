
from pathlib import Path
import gzip
import hashlib
import json
import shutil
import subprocess
import sys
import tarfile

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
comparison=lab/"comparison"
quiet=comparison/"quiet"
out=repo/"benchmarks/results/2026-11-23-compact-native-call-stack"
decision=sys.argv[1]
retained=sys.argv[2] if len(sys.argv)>2 else None
def read(p):return json.loads(p.read_text(encoding="utf-8-sig"))
sha=lambda b:hashlib.sha256(b).hexdigest()
def save(p,v):p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+"\n",encoding="utf-8",newline="\n")
def git(*args):return subprocess.check_output(["git",*args],cwd=repo)

identity=read(quiet/"identity.json")
assert identity==read(quiet/"retrieved/identity.json")
patch=git("diff","--binary",identity["patchBase"],identity["candidate"],"--","src","tests")
assert sha(patch)==identity["sourcePatchSHA256"] and patch==(comparison/"source.patch").read_bytes()
if retained:
    paths=git("diff","--name-only",identity["patchBase"],identity["candidate"],"--","src","tests").decode().splitlines()
    assert len(paths)==2 and not git("diff","--name-only",identity["candidate"],retained,"--",*paths)
identity.update(outcome=decision,retainedRevision=retained)
receipt=read(quiet/"archive-receipt.json")
assert all(receipt[k] for k in ("complete","allWorkersJoined","guestFixturesRemoved","quietBeforeAndAfter","archivedAndVerifiedUnderLease"))
assert sha((quiet/"observations.tgz").read_bytes())==receipt["archiveSHA256"]
raw=read(quiet/"retrieved/confirmation/confirmation.json")
assert raw["complete"] and receipt["jobs"]==len(raw["jobs"])==7
cases={c["id"]:c for c in read(quiet/"representative.json")["cases"]}
for job in raw["jobs"]:
    assert job["workersJoinedAndFixturesRemoved"] and len(job["samples"])==28
    case=cases[job["case"]]
    for batch in job["samples"]:
        result=batch["response"]
        assert result["status"]=="Completed"
        assert all(result[k]==case[k] for k in ("sourceSha256","fixtureSha256","expectedOutputSha256"))
        for name in ("Output","Files"):
            assert result.get("actual"+name+"Sha256")== (None if job["lane"]=="compile" else case.get("expected"+name+"Sha256"))
summary=read(quiet/"quiet-summary.json")
summary.update(outcome=decision,retentionDecisionPending=False,timedBatches=sum(len(j["samples"])for j in raw["jobs"]))
out.mkdir(exist_ok=True)
save(out/"source.json",identity)
save(out/"summary.json",summary)
save(out/"local-allocation.json",{role:read(comparison/f"{role}-allocation.json") for role in identity["imageFiles"]})


for role in identity["imageFiles"]:
    metadata=read(comparison/f"{role}-inspection.json")
    assert metadata["coreSHA256"]==identity["imageFiles"][role]["Lokad.Lython.dll"]
a,b=(read(comparison/f"{r}-inspection.json")["rows"] for r in identity["imageFiles"])
assert len(a)==8 and a==b and sum(len(row["codes"])for row in a)==25
jit=read(lab/"native-jit-summary.json")
assert len(jit)==4
for row in jit:
    assert row["coreSHA256"]==identity["imageFiles"][row["role"]]["Lokad.Lython.dll"]
    suffix="-linux" if row["platform"]=="Ubuntu WSL" else ""
    assert row["traceSHA256"]==sha((comparison/f"{row['role']}-native-calls{suffix}.asm").read_bytes())
save(out/"native-jit-summary.json",jit)
shutil.copyfile(lab/"stack-fixture-inspection.json",out/"stack-fixture-code.json")
core="Lokad.Lython.dll" 
for role,manifest in identity["imageFiles"].items():
    image=comparison/f"frozen-{role}"
    assert manifest=={name:sha((image/name).read_bytes()) for name in manifest}
    if role=="candidate":(out/f"{role}-core.dll.gz").write_bytes(gzip.compress((image/core).read_bytes(),compresslevel=9,mtime=0))
for name in ("archive-receipt.json","observations.tgz","terminal-status.json"):
    shutil.copyfile(quiet/name,out/name)
with tarfile.open(out/"procedures.tar.xz","w:xz") as bundle:
    names=["prototype.py","measure.py","measure.log","private-build.log","measure-first.log",
           "quiet-image-inventory.json","stage.py","archive.py","test-ubuntu.sh",
           "test-public-final-ubuntu.sh","run-deep-ubuntu.sh","measure-jit.py","disasm-ubuntu.sh","disasm-ubuntu.log",
           "white-windows.log","public-windows.log","white-ubuntu.log","public-ubuntu.log",
           "probe-windows-initial.log","probe-windows.log","probe-ubuntu.log","public-ubuntu-initial.log",
           "stack-fixture-build-ubuntu.log","stack-reference-build-ubuntu.log","stack-fixture-catalog.json",
           "stack-fixture-inspection.json","deep-continuation-windows.log","deep-continuation-ubuntu.log",
           "start-native.asm","exact-reference-validation.json"]
    names += [f"{role}-deep-{i}.log" for role in ("reference","candidate") for i in range(1,7)]
    names += ["comparison/"+n for n in ("identity.json","source.patch","representative.json",
              "reference-verify.json","candidate-verify.json","reference-allocation.json","candidate-allocation.json",
              "launch.py","summarize.py","jobs.json")]
    names += [f"comparison/{role}-{n}" for role in ("reference","candidate")
        for n in ("inspection.json","native-calls.asm","native-calls-linux.asm","disasm-verified.json","linux-disasm-verified.json")]
    names += ["comparison/quiet/"+n for n in ("remote-launch.py","collect.py","archive-owned.py","retrieve.py",
                "run.sh","launch.log","observe-not-before.json","config.json")]
    for n in names:bundle.add(lab/n,arcname=n,recursive=False)
