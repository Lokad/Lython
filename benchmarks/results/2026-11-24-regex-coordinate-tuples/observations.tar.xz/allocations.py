from pathlib import Path
import hashlib, json, os, statistics, subprocess

lab = Path(__file__).resolve().parent
comparison = lab / "comparison"
identity = json.loads((comparison / "identity.json").read_text(encoding="utf-8"))
dotnet = Path.home() / ".dotnet11/dotnet.exe"
env = dict(os.environ, DOTNET_ROOT=str(dotnet.parent), DOTNET_ROOT_X64=str(dotnet.parent))
catalog = comparison / "representative.json"
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
roles = {}
assert sha(catalog) == identity["catalogs"]["representative.json"]["sha256"]
for role in ("reference", "candidate"):
    image = lab / role
    for name, digest in identity["imageFiles"][role].items():
        assert sha(image / name) == digest
    for name, digest in json.loads((comparison / 'allocation-helper.json').read_text(encoding='utf-8')).items():
        assert sha(image / name) == digest
    result = lab / (role + "-allocation-six.json")
    subprocess.run([dotnet, image / "ValidatedAllocation.dll", image, catalog, result],
        env=env, timeout=45, check=True)
    roles[role] = json.loads(result.read_text(encoding="utf-8"))["rows"]
    assert len(roles[role]) == len(json.loads(catalog.read_text(encoding="utf-8"))["cases"])
    assert all(row["sharedBudgetBaselineRestored"] for row in roles[role])
summary = []
for a, b in zip(roles["reference"], roles["candidate"], strict=True):
    assert a["id"] == b["id"]
    allocated = [statistics.median(row["allocatedBytesPerInvocation"]) for row in (a, b)]
    admitted = [row["peakExecutionMemoryBytes"] for row in (a, b)]
    summary.append(dict(case=a["id"], allocatedBytes=allocated, peakAdmission=admitted))
    print(a["id"], allocated, admitted)
(lab / "allocation-summary-six.json").write_text(json.dumps(summary, indent=2) + "\n", encoding="utf-8", newline="\n")
