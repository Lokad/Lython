from pathlib import Path

lab = Path(__file__).resolve().parent
reference = lab.parent / 'native-inline-transfer-20261123/prepare.py'
previous = lab.parent / 'indexed-regex-projection-20261123'
prepare = reference.read_text(encoding='utf-8')
prepare = prepare.replace("tree=repo/'.git/agent-worktrees/native-inline-transfer-20261123'", 'tree=repo')
start = prepare.index('assert set(')
end = prepare.index('proof=read(', start)
prepare = prepare[:start] + '''assert set(git('diff','--name-only',reference,candidate,'--','src').splitlines()) == {
    'src/Lokad.Lython/Runtime/' + name for name in ('PyTuple.cs', 'LythonRuntime.RegexMatcher.cs',
        'LythonRuntime.RegexModule.cs', 'LythonRuntime.RegexObjects.cs')}
''' + prepare[end:]
start = prepare.index('catalog=read(')
end = prepare.index("write(comparison/'representative.json'", start)
prepare = prepare[:start] + '''catalog=read(notes/'observed-regex-coordinates/shared/quiet/representative.json')
cases=('scripts.regex-unicode-spans', 'scripts.regex-unicode-whole-offsets',
    'scripts.regex-unicode-wide-registers', 'scripts.regex-unicode-groups', 'scripts.regex-ascii-groups')
catalog['cases']=[item for item in catalog['cases'] if item['id'] in cases]
assert len(catalog['cases']) == len(cases)
''' + prepare[end:]
start = prepare.index("    actual[role]=")
prepare = prepare[:start] + '''    for name in ('ValidatedAllocation.dll','ValidatedAllocation.runtimeconfig.json','ValidatedAllocation.deps.json'):
        shutil.copyfile(notes/'indexed-regex-projection-20261123/candidate'/name,image/name)
''' + prepare[start:]
prepare += '''write(comparison/'allocation-helper.json', {
    name:digest(lab/'candidate'/name) for name in ('ValidatedAllocation.dll',
        'ValidatedAllocation.runtimeconfig.json','ValidatedAllocation.deps.json')})
'''
prepare = prepare.replace('B1541 test deferring native call continuation storage until transfer',
    'Direct admitted regex spans and cached register tuples')
(lab / 'prepare.py').write_text(prepare, encoding='utf-8', newline='\n')
allocations = (previous / 'allocations.py').read_text(encoding='utf-8').replace(
    '    result = lab /', '''    for name, digest in json.loads((comparison / 'allocation-helper.json').read_text(encoding='utf-8')).items():
        assert sha(image / name) == digest
    result = lab /''')
(lab / 'allocations.py').write_text(allocations, encoding='utf-8', newline='\n')
