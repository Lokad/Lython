from pathlib import Path
import hashlib
import json
import shutil
import tarfile

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
record = repo / 'benchmarks/results/2026-11-24-regex-coordinate-tuples'
record.mkdir(exist_ok=True)
source = lab / 'comparison'
read = lambda path: json.loads(path.read_text(encoding='utf-8'))
digest = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
identity = read(source / 'identity.json')
rows = read(lab / 'allocation-summary-six.json')
assert len(rows) == 5 and all(row['peakAdmission'][0] == row['peakAdmission'][1] for row in rows)
assert digest(source / 'representative.json') == identity['catalogs']['representative.json']['sha256']
for role, hashes in identity['imageFiles'].items():
    assert len(hashes) == 32 and all(digest(lab / role / name) == sha for name, sha in hashes.items())
    verify = read(source / (role + '-verify.json'))
    assert verify['state'] == 'Completed' and verify['caseCount'] == len(rows)
    assert verify['launched']['library']['sha256'] == hashes['Lokad.Lython.dll']
    assert all(row['sharedBudgetBaselineRestored'] for row in read(lab / (role + '-allocation-six.json'))['rows'])
shutil.copyfile(source / 'identity.json', record / 'identity.json')
shutil.copyfile(lab / 'allocation-summary-six.json', record / 'allocation-summary.json')
files = {name: lab / name for name in ('archive.py', 'prepare.py', 'prepare-cases.py', 'allocations.py',
    'reference-allocation-six.json', 'candidate-allocation-six.json')}
files.update({name: source / name for name in ('allocation-helper.json', 'representative.json',
    'reference-verify.json', 'candidate-verify.json')})
with tarfile.open(record / 'observations.tar.xz', 'w:xz') as bundle:
    for name, path in files.items():
        bundle.add(path, arcname=name)
with tarfile.open(record / 'observations.tar.xz') as bundle:
    assert set(bundle.getnames()) == set(files)
    assert all(hashlib.sha256(bundle.extractfile(name).read()).hexdigest() == digest(path) for name, path in files.items())
