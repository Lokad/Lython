from hashlib import sha256
from pathlib import Path
from shutil import copy2
from subprocess import check_output
import json
import re
import tarfile

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
pair = lab / 'comparison'
quiet = pair / 'quiet'
out = repo / 'benchmarks/results/2026-11-28-fixed-sum-binding'
read = lambda path: json.loads(path.read_bytes())
digest = lambda path: sha256(path.read_bytes()).hexdigest()
identity = read(pair / 'identity.json')
assert check_output(['git','diff','--binary','HEAD'], cwd=lab/'source') == (lab/'candidate.patch').read_bytes()
assert digest(lab/'candidate.patch') == identity['sourcePatchSHA256']
assert read(quiet/'identity.json')['imageFiles'] == identity['imageFiles']
assert read(quiet/'identity.json')['sourcePatchSHA256'] == identity['sourcePatchSHA256']
for role, files in identity['imageFiles'].items():
    assert len(files) == 32 and {p.name: digest(p) for p in (pair/role).iterdir()} == files
    for proof_path in (pair/f'{role}-verify.json', quiet/f'{role}-remote-verify.json'):
        proof = read(proof_path)
        assert proof['state'] == 'Completed' and proof['caseCount'] == 4
        assert proof['launched']['library']['sha256'] == files['Lokad.Lython.dll']
        assert proof['launched']['python']['sha256'] == identity['expectedCPythonSHA256']
assert {name for name, digest in identity['imageFiles']['reference'].items()
    if digest != identity['imageFiles']['candidate'][name]} == {'Lokad.Lython.dll'}
assert read(pair/'summary.json')['verifiedTimedBatches'] == 140
summary = read(quiet/'summary.json')
assert summary['verifiedTimedBatches'] == 84 and summary['quietGates']
for root in (pair, quiet):
    receipt = read(root/'archive-receipt.json')
    assert receipt['archiveSHA256'] == digest(root/'observations.tar.xz')
    assert all(receipt[name] for name in ('complete','allWorkersJoined','guestFixturesRemoved','archivedAndVerifiedUnderLease'))
allocation = read(lab/'allocation/summary.json')
admission = read(lab/'admission/summary.json')
assert len(allocation) == len(admission) == 8
assert all(row['compiled'][0] == row['compiled'][1] and row['admittedPeak'][0] == row['admittedPeak'][1] for row in allocation)
assert all(65568 <= row['clr'][0] - row['clr'][1] <= 65624 for row in allocation if 'generator-reduction' in row['case'])
assert all(row['peak'][0] == row['peak'][1] and row['requests'][0] == row['requests'][1] for row in admission)
logs = sorted(lab.glob('*-net*.log'))
assert len(logs) == 3
for log in logs:
    assert re.search(r'Failed: +0, Passed: +566, Skipped: +0', log.read_text(encoding='utf-8-sig'))
files = {name: lab/name for name in ('candidate.patch','freeze.py','prepare-repeat.py','quiet-vm.py','compact-completed-images.py',
    'compaction.json','measure-allocation.py','check-admission.py','summarize.py','summarize-repeat.py',
    'first-ubuntu-build.log','ubuntu-build.log','publish.py')}
for log in logs: files[log.name] = log
for folder in ('allocation','admission'):
    for path in (lab/folder).glob('*.json'): files[f'{folder}/{path.name}'] = path
for root, names in ((pair, ('reference-verify.json','candidate-verify.json','archive-receipt.json','run.log')),
    (quiet, ('terminal-status.json','reference-remote-verify.json','candidate-remote-verify.json','launch.log',
        'archive-receipt.json','upload.json','stage-custody.json'))):
    for name in names: files[f'{root.name}/{name}'] = root/name

out.mkdir()
articles = {'identity.json':pair/'identity.json', 'local-summary.json':pair/'summary.json', 'quiet-summary.json':quiet/'summary.json',
    'local-observations.tar.xz':pair/'observations.tar.xz','quiet-observations.tar.xz':quiet/'observations.tar.xz',
    'allocation.json':lab/'allocation/summary.json','admission.json':lab/'admission/summary.json'}
for name, path in articles.items():
    copy2(path, out/name)
    assert digest(out/name) == digest(path)
with tarfile.open(out/'procedures.tar.xz','w:xz') as archive:
    for name,path in files.items(): archive.add(path,arcname=name)
with tarfile.open(out/'procedures.tar.xz') as archive:
    assert all(sha256(archive.extractfile(name).read()).hexdigest() == digest(path) for name,path in files.items())
print('Both timing runs, 32-file images, controls, goldens, admission and test logs verified.')
