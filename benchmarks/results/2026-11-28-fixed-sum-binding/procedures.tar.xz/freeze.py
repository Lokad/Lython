from hashlib import sha256
from pathlib import Path
from shutil import copy2, copytree
from subprocess import check_output
import json

lab = Path(__file__).resolve().parent
source = lab / 'source'
old = lab.parent / 'current-cpython-b1958-20261128/comparison/quiet'
catalog = lab.parent / 'borrowed-generator-sum-b1957-20261128/comparison'
pair = lab / 'comparison'
core = 'Lokad.Lython.dll'
build = lab / 'ubuntu-artifacts/bin/Lokad.Lython/release_net11.0' / core
read = lambda path: json.loads(path.read_bytes())
digest = lambda path: sha256(path.read_bytes()).hexdigest()
files = lambda path: {p.name: digest(p) for p in path.iterdir()}

def git(*args):
    return check_output(['git', *args], cwd=source)

base = read(old / 'identity.json')
head = git('rev-parse', 'HEAD').decode().strip()
assert head == base['sourceRevision'] and head.startswith('09cecc9ce')
patch = git('diff', '--binary', 'HEAD')
assert patch.count(b'diff --git ') == 3
assert not git('ls-files', '--others', '--exclude-standard')
changed = git('diff', '--name-only', 'HEAD').decode().splitlines()
assert set(changed) == {'src/Lokad.Lython/Runtime/LythonRuntime.BuiltinIterables.Aggregates.cs',
    'src/Lokad.Lython/Runtime/LythonRuntime.Calls.cs',
    'src/Lokad.Lython/Runtime/LythonRuntime.ExecutionContext.Builtins.cs'}
baseline = base['imageFiles']['candidate']
assert len(baseline) == 32 and files(old / 'local-image') == baseline
pair.mkdir()
for role in ('reference', 'candidate'):
    copytree(old / 'local-image', pair / role)
copy2(build, pair / 'candidate' / core)
assert not (pair / 'candidate' / core).samefile(build)
images = {role: files(pair / role) for role in ('reference', 'candidate')}
assert images['reference'] == baseline
assert {name for name, value in images['candidate'].items() if baseline[name] != value} == {core}
identity = read(catalog / 'identity.json')
for name in ('representative.json', 'cpython-worker.py', 'run.sh', 'jobs.json', 'collect.py'):
    copy2(catalog / name, pair / name)
assert all(digest(pair / name) == entry['sha256'] for name, entry in identity['catalogs'].items())
assert digest(pair / 'cpython-worker.py') == base['cpythonWorkerSHA256']
assert b'\r' not in (pair / 'run.sh').read_bytes()
record = dict(sourceRevision=head, sourcePatchSHA256=sha256(patch).hexdigest(), imageFiles=images,
    coreSHA256={role+suffix: image[core] for role, image in images.items() for suffix in ('','-control')},
    expectedCPythonSHA256=base['expectedCPythonSHA256'], cpythonWorkerSHA256=base['cpythonWorkerSHA256'],
    catalogs=identity['catalogs'], purpose='Use fixed-width stack binding for synchronous and asynchronous sum.')
(pair / 'identity.json').write_text(json.dumps(record, indent=2) + '\n', encoding='utf-8', newline='\n')
(lab / 'candidate.patch').write_bytes(patch)
for name in ('measure-allocation.py', 'check-admission.py', 'summarize.py'):
    copy2(catalog.parent / name, lab / name)
print(head, 'two verified images for the fixed-width sum binding comparison')
