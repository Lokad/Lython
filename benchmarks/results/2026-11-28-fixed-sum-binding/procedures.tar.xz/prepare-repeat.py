from hashlib import sha256
from pathlib import Path
from shutil import copy2
import json
import tarfile

lab = Path(__file__).resolve().parent
pair = lab / 'comparison'
quiet = pair / 'quiet'
old = lab.parent / 'current-cpython-b1958-20261128'
donor = old / 'comparison/quiet'
template = lab.parent / 'direct-loop-position-b1953-20261128'
stage = 'script-fixed-sum-repeat-b1959-20261128'
core = 'Lokad.Lython.dll'
read = lambda path: json.loads(path.read_bytes())
digest = lambda path: sha256(path.read_bytes()).hexdigest()
image = lambda path: {p.name: digest(p) for p in path.iterdir()}

def save(path, text):
    path.write_text(text, encoding='utf-8', newline='\n')
    assert b'\r' not in path.read_bytes()

def write(path, value):
    save(path, json.dumps(value, indent=2) + '\n')

identity = read(pair / 'identity.json')
assert identity['sourceRevision'].startswith('09cecc9ce')
assert digest(lab / 'candidate.patch') == identity['sourcePatchSHA256']
donor_files = read(donor / 'identity.json')['imageFiles']['candidate']
terminal = read(donor / 'terminal-status.json')
receipt = terminal['receipt']
assert not terminal['live'] and not terminal['fixtures'] and terminal['exitCode'] == '0'
assert receipt['complete'] and receipt['allWorkersJoined'] and receipt['quietBeforeAndAfter']
assert digest(donor / 'observations.tar.xz') == receipt['archiveSHA256']
assert len(donor_files) == 32 and image(donor / 'local-image') == donor_files
assert identity['imageFiles']['reference'] == donor_files
for role, files in identity['imageFiles'].items():
    assert image(pair / role) == files
    proof = read(pair / f'{role}-verify.json')
    assert proof['state'] == 'Completed' and proof['caseCount'] == 4
    assert proof['catalogSha256'] == identity['catalogs']['representative.json']['sha256']
    assert proof['launched']['library']['sha256'] == files[core]
    assert proof['launched']['adapter']['sha256'] == files['Lokad.Lython.Benchmarks.dll']
    assert proof['launched']['python']['sha256'] == identity['expectedCPythonSHA256']
quiet.mkdir()
for name in ('representative.json','cpython-worker.py'):
    copy2(pair / name, quiet / name)
assert digest(quiet / 'representative.json') == identity['catalogs']['representative.json']['sha256']
assert digest(quiet / 'cpython-worker.py') == identity['cpythonWorkerSHA256']
copy2(template / 'comparison/quiet/run.sh', quiet / 'run.sh')
jobs = [['diagnostic.shipment-file-fed-map','warm-async'],
    ['diagnostic.shipment-row-generator-reduction','warm-async'],
    ['diagnostic.shipment-row-range-generator-reduction','warm-async']]
write(quiet / 'jobs.json', jobs)
identity['catalogs']['jobs.json'] = {'sha256': digest(quiet / 'jobs.json')}
identity.update(frozenImage=f'/home/lokad/lython-bench-checks/{stage}/candidate',
    donorArchiveSHA256=receipt['archiveSHA256'],
    purpose='Repeat same-image async fixed-width sum binding after unstable local timings.')
write(quiet / 'identity.json', identity)
collector = (template / 'comparison/quiet/collect.py').read_text(encoding='utf-8')
assert collector.count('lython-b1953-loop-position-fixtures') == 1 and 'len(jobs) == 3' in collector
save(quiet / 'collect.py', collector.replace('lython-b1953-loop-position-fixtures','lython-b1959-fixed-sum-fixtures'))
paths = {name: quiet / name for name in ('identity.json','jobs.json','representative.json','collect.py','run.sh','cpython-worker.py')}
paths[f'candidate/{core}'] = pair / 'candidate' / core
payload = quiet / 'stage.tar.gz'
with tarfile.open(payload, 'w:gz') as archive:
    for name, path in paths.items(): archive.add(path, arcname=name)
with tarfile.open(payload) as archive:
    assert all(sha256(archive.extractfile(name).read()).hexdigest() == digest(path) for name, path in paths.items())
manifest = {name: dict(length=path.stat().st_size, sha256=digest(path)) for name, path in paths.items()}
write(quiet / 'upload.json', dict(root=stage, donor=read(donor/'upload.json')['root'], donorFiles=donor_files,
    donorArchive=receipt['archiveSHA256'], payloadSHA256=digest(payload), files=manifest,
    expandedBytes=sum(file['length'] for file in manifest.values()), minimumAfterStageBytes=16*1024*1024))
launcher = (template / 'quiet-vm.py').read_text(encoding='utf-8')
assert launcher.count('lython-b1953-loop-position') == 1 and launcher.count("proof['caseCount']==3") == 1
save(lab / 'quiet-vm.py', launcher.replace('lython-b1953-loop-position','lython-b1959-fixed-sum')
    .replace("proof['caseCount']==3","proof['caseCount']==4"))
summary = (template / 'summarize-repeat.py').read_text(encoding='utf-8')
save(lab / 'summarize-repeat.py', summary.replace("verified['caseCount'] == 3","verified['caseCount'] == 4")
    .replace("{'donor':62,'paired':0}","{'donor':63,'paired':0}"))
compaction = (old / 'compact-completed-images.py').read_text(encoding='utf-8')
start = compaction.index("    ('starmap-slot-cpython-20261127'")
end = compaction.index('):\n    local =', start)
save(lab / 'compact-completed-images.py', compaction[:start] +
    "    ('trim-truth-without-result-20261126', 'trim-truth-without-result-b1802-20261126',\n"
    "        'lython-b1802-trim-truth-without-result-retry-20261126'),\n" + compaction[end:])
print('Three quiet repeat lanes prepared using the original images and goldens.')
