from pathlib import Path

lab = Path(__file__).resolve().parent
template = lab.parent / "retained-csv-cpython-20261122"
source = (template / "archive.py").read_text(encoding="utf-8")
source = source.replace('local / "quiet"', 'local / "cpython"')
source = source.replace('2026-11-22-retained-csv-cpython', '2026-11-22-numeric-extrema-cpython')
source = source.replace('B1327', 'B1336').replace('verifiedBatches=196', 'verifiedBatches=140')
source = source.replace('candidate_lab / "frozen" / name', 'candidate_lab / "frozen" / "candidate" / name')
source = source.replace('candidate_lab/\'frozen/Lokad.Lython.dll\'', 'candidate_lab/\'frozen/candidate/Lokad.Lython.dll\'')
source = source.replace('local / "verify.json"', 'lab / "verify.json"')
source = source.replace('== 7', '== 5')
source = source.replace('current-factories-cpython/quiet', 'retained-csv-cpython-20261122/quiet')
start = source.index('explicit="scripts.csv-meter-report.explicit-float"')
end = source.index('for job in raw[\'jobs\']:', start)
source = source[:start] + '''meter, explicit, unicode, control = [case["id"] for case in cases]
assert [job["case"] for job in raw["jobs"]] == [meter, explicit, unicode, meter, meter]
assert [job["lanes"] for job in raw["jobs"]] == [["warm"], ["warm"], ["warm"], ["compile"], ["compile-run"]]
''' + source[end:]
start = source.index('    input_records = None')
end = source.index('\n    for lane in lanes:', start)
source = source[:start] + '''    assert byte_counts["meters.csv"] == (223267 if case["id"] == unicode else 139299)
    csv_bytes = base64.b64decode(fixture["inputFiles"]["meters.csv"], validate=True)
    input_records = sum(1 for _ in csv.DictReader(StringIO(csv_bytes.decode("utf-8"), newline="")))
    assert input_records == 4096
''' + source[end:]
source = source.replace('selection=dict(measuredCore="measured-core.dll.gz")',
                        'measured_core = "../2026-11-22-numeric-extrema-operands/candidate-core.dll.gz"')
source = source.replace('measuredCore=selection["measuredCore"]', 'measuredCore=measured_core')
source = source.replace('(out / summary["measuredCore"]).write_bytes(gzip.compress(core_bytes,mtime=0))\n', '')
source = source.replace('("prepare.py","archive.py","verify.json","launch.py","report.py","input-identity.json","build-combined-core-win.log")',
                        '("prepare-cpython.py", "archive-cpython.py", "launch-cpython.py", "report-cpython.py", "prepare-cpython-archive.py", "prove-retirement.py", "retire-inventory.json")')
assert 'len(rows) == 5' in source and 'verifiedBatches=140' in source and 'raw["jobs"]) == 5' in source
target = lab / "archive-cpython.py"
compile(source, str(target), "exec")
target.write_text(source, encoding="utf-8", newline="\n")

report = (template / "report.py").read_text(encoding="utf-8")
report = report.replace('2026-11-22-retained-csv-cpython', '2026-11-22-numeric-extrema-cpython')
report = report.replace('"scripts.annotated-rule-closures.literal-positional-dynamic-keyword": "Mixed literal-default factory",',
                        '"scripts.csv-meter-report.typed-unicode": "Typed Unicode CSV meter report",')
report = report.replace('    "scripts.csv-invoice.method-policy.quoted-control": "Quote-heavy CSV policy invoice",\n', '')
report = report.replace('B1327 Retained CSV and literal-default checkpoint', 'B1336 Retained numeric calls in CSV reports')
report = report.replace('Both meter reports read 139,299 bytes. The quote-heavy invoice reads\n174,147 bytes. The mixed factory creates 4,096 functions for 2,048 inputs\nand uses no files.',
                        'The ASCII and explicit-float reports read 139,299 bytes each. The\nUnicode report reads 223,267 bytes.')
report = report.replace('All 196 timed batches', 'All 140 timed batches')
report = report.replace('[Literal defaults source pair](../2026-11-22-compiled-literal-defaults-keywords/README.md) ·\n[CSV source pair](../2026-11-22-csv-compiled-unpack/README.md)',
                        '[Numeric call source pair](../2026-11-22-numeric-extrema-operands/README.md)\n· [Prior meter checkpoint](../2026-11-22-retained-csv-cpython/README.md)')
target = lab / "report-cpython.py"
compile(report, str(target), "exec")
target.write_text(report, encoding="utf-8", newline="\n")
