from pathlib import Path
import hashlib
import json
import os
import shutil
import subprocess
import tarfile

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
donor = lab / "quiet"
template = lab.parent / "retained-csv-cpython-20261122" / "quiet"
out = lab / "cpython"

def load(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def emit(path, source):
    if path.suffix == ".py":
        compile(source, str(path), "exec")
    path.write_text(source, encoding="utf-8", newline="\n")

def save(path, value):
    emit(path, json.dumps(value, indent=2) + "\n")

def git(*arguments):
    return subprocess.check_output(["git", *arguments], cwd=repo, text=True).strip()

production = git("rev-parse", "HEAD")
assert git("rev-parse", "origin/master") == production and not git("status", "--porcelain")
measured = git("rev-parse", "b6dd01aee")
subprocess.run(["git", "diff", "--exit-code", production, measured, "--", "src", "tests",
                "benchmarks/Lokad.Lython.Benchmarks"], cwd=repo, check=True)
config = load(donor / "config.json")
receipt = load(donor / "archive-receipt.json")
assert receipt["complete"] and receipt["archivedAndVerifiedUnderLease"] and sha(donor / "observations.tgz") == receipt["archiveSHA256"]
files = config["identity"]["imageFiles"]["candidate"]
image = lab / "frozen" / "candidate"
assert len(files) == 32 and {name: sha(image / name) for name in files} == files
protocol = repo / "benchmarks/cpython-worker.py"
assert sha(protocol) == config["protocolSHA256"]

out.mkdir()
manifest = out / "representative.json"
shutil.copyfile(donor / "representative.json", manifest)
assert sha(manifest) == config["catalogSHA256"]
cases = [case["id"] for case in load(manifest)["cases"]]
assert len(cases) == 4 and cases[0].endswith("typed-ascii") and cases[2].endswith("typed-unicode")

sdk = Path.home() / ".dotnet11"
dotnet = sdk / "dotnet.exe"
env = dict(os.environ, DOTNET_ROOT=str(sdk), DOTNET_ROOT_X64=str(sdk), PATH=str(sdk) + os.pathsep + os.environ["PATH"])
proof = out / "verify.json"
subprocess.run([dotnet, image / "Lokad.Lython.Benchmarks.dll", "--compare", "verify", "--catalog", manifest,
                "--dotnet", dotnet, "--python", "C:/Python313/python.exe", "--python-worker", protocol,
                "--out", proof], cwd=repo, env=env, check=True, timeout=95)
check = load(proof)
assert check["state"] == "Completed" and check["caseCount"] == 4 and check["catalogSha256"] == sha(manifest)
assert {name: sha(image / name) for name in files} == files

identity = dict(sourceRevision=measured, productionEquivalent=production, imageSource=measured,
                purpose="Retained numeric call CSV checkpoint against stock CPython",
                imageFiles=dict(candidate=files), catalogSHA256=sha(manifest), cpythonWorkerSHA256=sha(protocol),
                auxiliaryFiles={name: digest for name, digest in files.items() if name != "Lokad.Lython.dll"},
                coreSHA256={role: files["Lokad.Lython.dll"] for role in ("candidate", "candidate-control")})
save(out / "identity.json", identity)
root = "/home/lokad/lython-bench-checks/numeric-extrema-cpython-b1336-20261122"
unit = "lython-b1336-numeric-extrema-cpython-20261122"
old = load(template / "config.json")
lanes = [(case, "warm") for case in cases[:3]] + [(cases[0], "compile"), (cases[0], "compile-run")]
for name in ("collect.py", "archive-owned.py", "run.sh", "retrieve.py"):
    source = (template / name).read_text(encoding="utf-8").replace(old["root"], root).replace(old["unit"], unit).replace("B1327", "B1336")
    if name == "collect.py":
        start = source.index("    for case_id,lane in ")
        end = source.index("        assert time.monotonic()", start)
        source = source[:start] + f"    for case_id,lane in {lanes!r}:\n" + source[end:]
    if name == "archive-owned.py":
        source = source.replace("len(raw['jobs'])==7", "len(raw['jobs'])==5").replace("jobs=7,", "jobs=5,")
    if name == "retrieve.py":
        source = source.replace("['jobs']==7", "['jobs']==5")
    emit(out / name, source)
assert b"\r" not in (out / "run.sh").read_bytes()

parts = ("identity.json", "collect.py", "archive-owned.py", "run.sh")
payload = out / "payload.tgz"
with tarfile.open(payload, "w:gz") as archive:
    for name in parts:
        archive.add(out / name, arcname=name)
unpacked = sum((out / name).stat().st_size for name in parts)
inventory = load(lab / "retire-inventory.json")
needed = 176160768 + unpacked + 640 * 1024
free = inventory["free"]
retire = []
for proof in sorted(inventory["proofs"], key=lambda group: group["bytes"], reverse=True):
    if free > needed:
        break
    if not proof.pop("verified", False):
        continue
    assert all(name.endswith("/representative.json") for name in proof["paths"])
    retire.append(proof)
    free += proof["bytes"]
assert free > needed, (free, needed)
stage = dict(root=root, unit=unit, source=config["root"], sourceRole="candidate", sourceFiles=files,
             sourceCatalogSHA256=sha(manifest), donorArchiveSHA256=receipt["archiveSHA256"],
             catalogSHA256=sha(manifest), retireGroups=retire, cpythonWorkerSHA256=sha(protocol),
             identity=identity, payloadBytes=payload.stat().st_size, payloadSHA256=sha(payload), unpackedBytes=unpacked)
save(out / "config.json", stage)
script = (template / "remote-launch.py").read_text(encoding="utf-8")
a, b = script.index("\nc=") + 1, script.index("\nb=Path(")
script = (script[:a] + "c=" + repr(stage) + script[b:]).replace("lython-b1327-fixtures", "lython-b1336-fixtures")
emit(out / "remote-launch.py", script)
launch = (lab.parent / "retained-csv-cpython-20261122" / "launch.py").read_text(encoding="utf-8")
launch = launch.replace("/'quiet'", "/'cpython'").replace("B1327", "B1336").replace("435", "305")
assert "'cpython'" in launch and "seconds=305" in launch
emit(lab / "launch-cpython.py", launch)
print("Prepared five current CPython lanes with identical retained worker image and corpus.")
