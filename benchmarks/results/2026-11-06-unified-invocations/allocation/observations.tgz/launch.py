from pathlib import Path
import hashlib,json,subprocess,tarfile
base=Path('/home/lokad/lython-bench-checks/unified-frame-b312-20261106')
status=subprocess.check_output(['systemctl','show','lython-b312-unified-frame-20261106','--property=ActiveState,MainPID,Result'],text=True)
assert 'ActiveState=inactive' in status and 'MainPID=0' in status and 'Result=success' in status,status
assert json.loads((base/'confirmation/confirmation.json').read_text())['complete']
root=Path('/home/lokad/lython-bench-checks/unified-frame-allocation-b313-20261106');root.mkdir(exist_ok=False)
with tarfile.open('/home/lokad/lython-bench-checks/b313-payload.tgz') as archive:archive.extractall(root,filter='data')
identity=json.loads((root/'identity.json').read_text())
for label in ['candidate','reference']:
 assert hashlib.sha256((base/label/'Lokad.Lython.dll').read_bytes()).hexdigest()==identity['coreSHA256'][label]
subprocess.run(['sudo','-n','systemd-run','--unit=lython-b313-unified-frame-allocation-20261106','--property=User=lokad','--property=WorkingDirectory='+str(root),'--property=RuntimeMaxSec=45','--property=TimeoutStopSec=15','--property=KillMode=control-group','/bin/sh',str(root/'run.sh')],check=True)
