from pathlib import Path
import fcntl,hashlib,json,subprocess,tarfile
root=Path('/home/lokad/lython-bench-checks/unified-frame-allocation-b313-20261106')
status=subprocess.check_output(['systemctl','show','lython-b313-unified-frame-allocation-20261106','--property=LoadState,ActiveState,Result,MainPID'],text=True)
assert 'ActiveState=inactive' in status and 'MainPID=0' in status and 'Result=success' in status,status
assert (root/'exit-code.txt').read_text().strip()=='0'
with (root.parent/'comparison-vm.lock').open('a') as lease:
    fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
    result=json.loads((root/'result.json').read_text())
    assert len(result['observations'])==1
    assert result['imageIsolationVerified'] and result['allGoldensPassed'] and result['allBalancesZero'] and result['ownedFixturesRemoved']
    for name in ('before','after'):assert json.loads((root/f'machine-{name}.json').read_text())['gate']['quiet']
    assert not list(Path('/dev/shm').glob('lython-comparison-files-*'))
    assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[c]omplete-jobs.dll'],capture_output=True).returncode==1
    (root/'final-service-status.txt').write_text(status)
    with tarfile.open(root/'observations.tgz','w:gz') as archive:
        for path in root.rglob('*'):
            if path.is_file() and path.name!='observations.tgz':archive.add(path,arcname=str(path.relative_to(root)))
    receipt=dict(complete=True,jobs=1,quietBeforeAfter=True,allGoldensAndBalances=True,workersJoined=True,fixturesRemoved=True,archiveSHA256=hashlib.sha256((root/'observations.tgz').read_bytes()).hexdigest())
    (root/'archive-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
    print(json.dumps(receipt))
