from pathlib import Path
import tarfile,subprocess
root=Path("/home/lokad/lython-bench-checks/unified-frame-b312-20261106");root.mkdir(exist_ok=False)
with tarfile.open('/home/lokad/lython-bench-checks/b312-payload.tgz') as archive:archive.extractall(root,filter='data')
subprocess.run(['python3',str(root/'setup.py')],check=True)
subprocess.run(['sudo','-n','systemd-run','--unit=lython-b312-unified-frame-20261106','--property=User=lokad','--property=WorkingDirectory='+str(root),'--property=RuntimeMaxSec=190','--property=TimeoutStopSec=30','--property=KillMode=control-group','/bin/sh',str(root/'run.sh')],check=True)
