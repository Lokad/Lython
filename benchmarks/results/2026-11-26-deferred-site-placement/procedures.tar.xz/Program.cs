using System.Collections;
using System.Reflection;
using System.Text.Json;
using Lokad.Lython;

const BindingFlags Flags = BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic;
using var catalog = JsonDocument.Parse(File.ReadAllText(args[0]));
var cases = new List<object>();
foreach (var item in catalog.RootElement.GetProperty("cases").EnumerateArray())
{
    var id = item.GetProperty("id").GetString()!;
    var budget = new LythonMemoryBudget(256L * 1024 * 1024);
    using var script = new LythonEngine().Compile(item.GetProperty("source").GetString()!, budget);
    if (!script.IsValid) throw new InvalidDataException(string.Join("|", script.Diagnostics));
    var executable = script.GetType().GetField("_executable", Flags)!.GetValue(script)!;
    var codes = new List<object>();
    Visit(Get(executable, "EntryPoint")!);
    cases.Add(new { id, compileAdmissionBytes = budget.ReservedBytes, codes });
    script.Dispose();
    if (budget.ReservedBytes != 0) throw new InvalidDataException("Compile ownership did not return.");

    void Visit(object code)
    {
        var instructions = ((IEnumerable)Get(code, "Instructions")!).Cast<object>().ToArray();
        var sites = (int[]?)Get(code, "DeferredDefinitionSites") ?? [];
        var slots = sites.Select(index => (int)Get(instructions[index], "DeferredKeywordSlot")!).ToArray();
        var operations = instructions.Select(x => new
        {
            op = Get(x, "OpCode")!.ToString(),
            input = Get(x, "InputStart"),
            result = Get(x, "ResultSlot"),
            extent = Get(x, "LiveExtent"),
            consumer = Get(x, "HasResultConsumer")
        });
        codes.Add(new
        {
            name = Get(code, "Name"),
            capacity = Get(code, "ValueStorageCapacity"),
            sites,
            slots,
            operations
        });
        foreach (var item in (object?[])Get(code, "Constants")!)
            if (item?.GetType().Name == "ExecutableCreateFunction") Visit(Get(item, "CodeObject")!);
    }
}
File.WriteAllText(args[1], JsonSerializer.Serialize(cases, new JsonSerializerOptions { WriteIndented = true }));

static object? Get(object value, string name)
    => value.GetType().GetProperty(name, Flags)!.GetValue(value);
