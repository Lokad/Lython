set -eu
export DOTNET_ROOT="$HOME/.dotnet"
export PATH="$DOTNET_ROOT:$PATH"
lab="$PWD/.git/agent-notes/review-20261031/deferred-site-placement-20261126"
filter='Category!=Stress&(FullyQualifiedName~Default|FullyQualifiedName~ExecutableDefinition|FullyQualifiedName~SharedCompilerFact|FullyQualifiedName~AsyncExecutableFunction|FullyQualifiedName~Closure|FullyQualifiedName~Annotation|FullyQualifiedName~Lambda|FullyQualifiedName~FunctionCall|FullyQualifiedName~Cancellation|FullyQualifiedName~GovernedMemoryContract)'
for suite in Lokad.Lython.Tests Lokad.Lython.PublicApi.Tests; do
    log="$lab/$suite-ubuntu10.log"
    if dotnet test "tests/$suite/$suite.csproj" -c Release -f net10.0 --artifacts-path "$lab/ubuntu" --filter "$filter" > "$log" 2>&1; then
        tail -6 "$log"
    else
        tail -45 "$log"
        exit 1
    fi
done