from pathlib import Path
import hashlib
import json
import shutil
import subprocess
import tarfile

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
local = lab / 'local'
target = repo / 'benchmarks/results/2026-11-26-deferred-site-placement'
read = lambda path: json.loads(path.read_text(encoding='utf-8-sig'))
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
identity, summary, receipt = (read(local / name) for name in
    ('identity.json', 'summary.json', 'archive-receipt.json'))
assert summary['quietQualified'] is False and summary['timedBatches'] == 112
assert receipt['archiveSHA256'] == sha(local / 'observations.tar.xz') and receipt['warmJobs'] == 4
assert all(receipt[key] for key in ('allWorkersJoined', 'guestFixturesRemoved', 'complete', 'archivedAndVerifiedUnderLease'))
assert (local / 'exit-code.txt').read_text().strip() == '0'
assert identity['sourcePatchSHA256'] == summary['sourcePatchSHA256'] == sha(lab / 'candidate.patch')
current = subprocess.check_output(['git', 'diff', '--binary', identity['sourceRevision'], '--', 'src'], cwd=repo)
assert not current or hashlib.sha256(current).hexdigest() == identity['sourcePatchSHA256']
cases = read(lab / 'tape-summary.json')
assert [row['sites'] for row in cases] == [93, 0, 2, 0]
assert sha(lab / 'reference-tape.json') == sha(lab / 'candidate-tape.json') == cases[0]['completeSnapshotSHA256']
for role in ('reference','candidate'):
    verify = read(lab / (role + '-verify.json'))
    assert verify['state'] == 'Completed' and verify['caseCount'] == 4
    assert verify['catalogSha256'] == identity['catalogs']['representative.json']['sha256']
    assert verify['launched']['library']['sha256'] == identity['coreSHA256'][role]
target.mkdir(exist_ok=True)
for name in ('identity.json', 'summary.json', 'archive-receipt.json', 'observations.tar.xz'):
    shutil.copyfile(local / name, target / name)
for name in ('candidate.patch', 'tape-summary.json'):
    shutil.copyfile(lab / name, target / name)
with tarfile.open(target / 'procedures.tar.xz', 'w:xz') as archive:
    for name in ('prepare.py', 'prepare.log', 'local-run.log', 'archive.py', 'test-ubuntu.sh',
                 'summarize.py', 'TapeProbe.csproj', 'Program.cs', 'tape-probe-build.log',
                 'compare-tape.py', 'reference-tape.json', 'reference-verify.json', 'candidate-verify.json'):
        archive.add(lab / name, arcname=name)
    for name in ('exit-code.txt', 'cpython-worker.py'):
        archive.add(local / name, arcname=name)
    for log in sorted(lab.glob('Lokad.Lython.*.log')):
        archive.add(log, arcname=log.name)
print('Packaged source, matching tape, verification and local observations')
