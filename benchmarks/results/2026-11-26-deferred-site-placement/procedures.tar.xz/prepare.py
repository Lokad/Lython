from pathlib import Path
import hashlib
import json
import os
import shutil
import subprocess

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
prior = lab.with_name('literal-keyword-defaults-20261126')
reference = prior / 'local/candidate'
local = lab / 'local'
core = 'Lokad.Lython.dll'
candidate = lab / 'windows/bin/Lokad.Lython/release_net11.0' / core
read = lambda path: json.loads(path.read_text(encoding='utf-8-sig'))
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
manifest = lambda path: {p.name: sha(p) for p in path.iterdir()}

def save(path, value):
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False) + '\n', encoding='utf-8', newline='\n')

head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repo, text=True).strip()
assert head == 'c9de89e97a6700b659e45121669eb301be8b7a7b'
old = read(prior / 'comparison/quiet/identity.json')
assert old['imageFiles']['candidate'] == manifest(reference) and len(manifest(reference)) == 32
patch = subprocess.check_output(['git', 'diff', '--binary', head, '--', 'src'], cwd=repo)
assert patch.count(b'diff --git ') == 3 and b'PlaceDeferredDefinitions' in patch
(lab / 'candidate.patch').write_bytes(patch)

local.mkdir()
images = {}
for role in ('reference', 'candidate'):
    folder = local / role
    shutil.copytree(reference, folder)
    if role == 'candidate':
        shutil.copyfile(candidate, folder / core)
    images[role] = manifest(folder)
assert [name for name, digest in images['reference'].items() if images['candidate'][name] != digest] == [core]
for name in ('representative.json', 'cpython-worker.py', 'run.sh'):
    shutil.copyfile(prior / 'local' / name, local / name)
assert sha(local / 'representative.json') == old['catalogs']['representative.json']['sha256']
assert sha(local / 'cpython-worker.py') == old['cpythonWorkerSHA256']
assert b'\r' not in (local / 'run.sh').read_bytes()
save(local / 'jobs.json', {'warm': [
    ['diagnostic.generated-ordinary-definitions', 'compile'],
    ['scripts.file-search.large', 'compile'],
    ['diagnostic.generated-ordinary-definitions', 'compile-run'],
    ['scripts.rule-default-closures', 'compile-run'],
]})
identity = dict(sourceRevision=head, sourcePatchSHA256=sha(lab / 'candidate.patch'), imageFiles=images,
    coreSHA256={role + label: files[core] for role, files in images.items() for label in ('', '-control')},
    cpythonWorkerSHA256=old['cpythonWorkerSHA256'],
    catalogs={name: {'sha256': sha(local / name)} for name in ('representative.json', 'jobs.json')},
    purpose='Record qualifying deferred-definition sites during executable tape linearization.')
save(local / 'identity.json', identity)

collector = (prior / 'local/collect.py').read_text(encoding='utf-8')
collector = collector.replace('len(jobs) == 6', 'len(jobs) == 4')
collector = collector.replace('lython-literal-keyword-defaults-fixture-', 'lython-deferred-site-placement-fixture-')
compile(collector, 'collect.py', 'exec')
(local / 'collect.py').write_text(collector, encoding='utf-8', newline='\n')
sdk = Path.home() / '.dotnet11'
dotnet = sdk / 'dotnet.exe'
settings = dict(os.environ, DOTNET_ROOT=str(sdk), DOTNET_ROOT_X64=str(sdk))
for role, files in images.items():
    image = local / role
    verification = lab / (role + '-verify.json')
    subprocess.run([dotnet, image / 'Lokad.Lython.Benchmarks.dll', '--compare', 'verify', '--catalog',
        local / 'representative.json', '--dotnet', dotnet, '--python', 'C:/Python313/python.exe',
        '--python-worker', local / 'cpython-worker.py', '--out', verification],
        cwd=repo, env=settings, check=True, timeout=75)
    proof = read(verification)
    assert proof['state'] == 'Completed' and proof['caseCount'] == 4
    assert proof['catalogSha256'] == identity['catalogs']['representative.json']['sha256']
    assert proof['launched']['library']['sha256'] == files[core]
