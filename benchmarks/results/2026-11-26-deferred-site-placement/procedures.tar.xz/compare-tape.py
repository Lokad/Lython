from pathlib import Path
import hashlib
import json
import os
import shutil
import subprocess
import sys

lab = Path(sys.argv[1]).resolve()
dotnet = Path.home() / '.dotnet11/dotnet.exe'
identity = json.loads((lab / 'local/identity.json').read_text(encoding='utf-8'))
hash_of = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
snapshots = []
for role in ('reference', 'candidate'):
    image = lab / 'local' / role
    assert {p.name: hash_of(p) for p in image.iterdir()} == identity['imageFiles'][role]
    directory = lab / (role + '-tape-probe')
    shutil.copytree(lab / 'bin/Release/net11.0', directory)
    for file in image.glob('*.dll'):
        shutil.copyfile(file, directory / file.name)
    dump = lab / (role + '-tape.json')
    subprocess.run([dotnet, directory / 'TapeProbe.dll', lab / 'local/representative.json', dump],
                   env=dict(os.environ, DOTNET_ROOT=str(dotnet.parent)), check=True, timeout=22)
    snapshots.append(dump.read_bytes())
assert snapshots[0] == snapshots[1], 'Instruction or admission mismatch'
summary = []
for row in json.loads(snapshots[0]):
    sites = sum(len(code['sites']) for code in row['codes'])
    instructions = sum(len(code['operations']) for code in row['codes'])
    summary.append(dict(case=row['id'], sites=sites, instructions=instructions,
                        compileAdmissionBytes=row['compileAdmissionBytes'],
                        completeSnapshotSHA256=hashlib.sha256(snapshots[0]).hexdigest()))
assert summary[0]['sites'] == 93, summary
(lab / 'tape-summary.json').write_text(json.dumps(summary, indent=2) + '\n', encoding='utf-8', newline='\n')
print(json.dumps(summary))
