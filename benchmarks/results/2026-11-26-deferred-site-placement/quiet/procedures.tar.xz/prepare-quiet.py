from pathlib import Path
import hashlib
import json
import shutil
import tarfile

lab=Path(__file__).resolve().parent
previous=lab.with_name('literal-keyword-defaults-20261126')
local=lab/'local'
quiet=lab/'comparison/quiet'
quiet.mkdir(parents=True)
read=lambda p:json.loads(p.read_text(encoding='utf-8'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()

def edit(source, edits):
    for before,after in edits:
        assert source.count(before)==1,before
        source=source.replace(before,after)
    return source

for name in ('identity.json','representative.json','jobs.json','cpython-worker.py','run.sh'):
    shutil.copyfile(local/name,quiet/name)
settled=read(previous/'comparison/quiet/terminal-status.json')['receipt']
assert settled['complete'] and settled['archiveSHA256']==sha(previous/'comparison/quiet/observations.tar.xz')
old=read(previous/'comparison/quiet/identity.json')
identity=read(quiet/'identity.json')
assert identity['imageFiles']['reference']==old['imageFiles']['candidate']
identity['expectedCPythonSHA256']=old['expectedCPythonSHA256']
(quiet/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8',newline='\n')
for role,files in identity['imageFiles'].items():
    assert len(files)==32 and {p.name:sha(p) for p in (local/role).iterdir()}==files
collector=edit((previous/'comparison/quiet/collect.py').read_text(encoding='utf-8'),[
    ('len(jobs) == 6','len(jobs) == 4'),
    ('lython-b1788-fixtures','lython-b1789-fixtures'),
])
compile(collector,'collect.py','exec')
(quiet/'collect.py').write_text(collector,encoding='utf-8',newline='\n')
assert b'\r' not in (quiet/'run.sh').read_bytes()
entries=('identity.json','representative.json','jobs.json','collect.py','run.sh','cpython-worker.py')
payload=quiet/'stage.tar.gz'
with tarfile.open(payload,'w:gz',compresslevel=6) as package:
    for name in entries:package.add(quiet/name,arcname=name,recursive=False)
dll=local/'candidate/Lokad.Lython.dll'
upload=dict(root='deferred-site-placement-b1789-20261126',payloadSHA256=sha(payload),
    payloadBytes=payload.stat().st_size,expandedBytes=sum((quiet/name).stat().st_size for name in entries),
    coreBytes=dll.stat().st_size,coreSHA256=sha(dll),donorSHA256=settled['archiveSHA256'])
(quiet/'upload.json').write_text(json.dumps(upload,indent=2)+'\n',encoding='utf-8',newline='\n')

launcher=edit((previous/'quiet.py').read_text(encoding='utf-8'),[
    ('lython-b1788-literal-keyword-defaults-20261126','lython-b1789-deferred-site-placement-20261126'),
    ('fixed-row-local-bindings-b1783-20261126','literal-keyword-defaults-b1788-20261126'),
    ('RuntimeMaxSec=285','RuntimeMaxSec=213'),
    ('seconds=245','seconds=178'),
])
compile(launcher,'quiet.py','exec')
(lab/'quiet.py').write_text(launcher,encoding='utf-8',newline='\n')
summary=edit((previous/'summarize.py').read_text(encoding='utf-8'),[
    ("receipt['warmJobs'] == 6","receipt['warmJobs'] == 4"),
    ("len(raw['jobs']) == 6","len(raw['jobs']) == 4"),
    ('timedBatches=168','timedBatches=112'),
])
(lab/'summarize-quiet.py').write_text(summary,encoding='utf-8',newline='\n')
print(upload)
