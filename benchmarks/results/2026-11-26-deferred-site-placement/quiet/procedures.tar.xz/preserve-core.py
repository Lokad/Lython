from pathlib import Path
import gzip
import hashlib
import json
import os
import re
import subprocess
import sys

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
quiet = lab / 'comparison/quiet'
read = lambda path: json.loads(path.read_text(encoding='utf-8'))
digest = lambda data: hashlib.sha256(data).hexdigest()
sha = lambda path: digest(path.read_bytes())
assert sys.argv[1:] in (['preview'], ['reclaim'])
mode = sys.argv[1]
original = lab.with_name('json-default-decoder-20261126')
candidate = original / 'local/candidate'
archives = []
image = {file.name: sha(file) for file in candidate.iterdir()}
assert len(image) == 32
for local, published in (
    (original / 'comparison/quiet', 'benchmarks/results/2026-11-26-json-default-decoder/observations.tar.xz'),
    (lab.with_name('json-default-decoder-20261126-confirmation') / 'comparison/quiet',
     'benchmarks/results/2026-11-26-json-default-decoder/confirmation/observations.tar.xz'),
):
    status = read(local / 'terminal-status.json')
    receipt = status['receipt']
    assert not status['live'] and not status['fixtures'] and status['exitCode'] == '0'
    assert receipt['complete'] and receipt['allWorkersJoined'] and receipt['guestFixturesRemoved']
    assert read(local / 'identity.json')['imageFiles']['candidate'] == image
    published_bytes = subprocess.check_output(['git','show', 'origin/master:' + published], cwd=repo)
    assert digest(published_bytes) == receipt['archiveSHA256'] == sha(local / 'observations.tar.xz')
    unit, = set(re.findall(r'lython-b[a-z0-9-]+\.service', status['journal']))
    archives.append(dict(root=read(local / 'upload.json')['root'], unit=unit,
                         archiveSHA256=receipt['archiveSHA256'], committed=published))

core = candidate / 'Lokad.Lython.dll'
backup = lab / 'preserved-json-default-decoder-core.dll.gz'
if mode == 'preview' and not backup.exists():
    backup.write_bytes(gzip.compress(core.read_bytes(), mtime=0))
assert digest(gzip.decompress(backup.read_bytes())) == image[core.name]
upload = read(quiet / 'upload.json')
need = upload['payloadBytes'] + upload['expandedBytes'] + upload['coreBytes'] + 5 * 1024 * 1024 + 32768
proof = dict(archives=archives, image=image, backup=str(backup), bytes=core.stat().st_size, need=need)
if mode == 'reclaim':
    old = read(quiet / 'duplicate-core-preview.json')
    assert old['proof'] == proof and old['result']['mode'] == 'preview'

remote = r"""
from pathlib import Path
import fcntl,hashlib,json,os,shutil,stat,subprocess
base=Path('/home/lokad/lython-bench-checks')
assert base.resolve()==base
sha=lambda path:hashlib.sha256(path.read_bytes()).hexdigest()
with (base/'comparison-vm.lock').open('a') as lease:
    fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
    assert not any(p.is_mount() for p in base.glob('*/guest-fixtures'))
    first=base/cfg['archives'][0]['root']
    selected=first/'candidate'/'Lokad.Lython.dll'
    assert first.parent==base and first.resolve()==first and selected.resolve()==selected
    for claim in cfg['archives']:
        root=base/claim['root']
        assert root.parent==base and root.resolve()==root
        image=root/'candidate'
        assert (image/'Lokad.Lython.dll').resolve()==selected
        assert {file.name:sha(file) for file in image.iterdir()}==cfg['image']
        state=subprocess.check_output(['systemctl','show',claim['unit'],'--property=ActiveState,MainPID'],text=True).splitlines()
        assert 'ActiveState=inactive' in state and 'MainPID=0' in state,state
        receipt=json.loads((root/'archive-receipt.json').read_text())
        assert receipt['complete'] and receipt['allWorkersJoined'] and receipt['guestFixturesRemoved']
        assert receipt['archiveSHA256']==claim['archiveSHA256']==sha(root/'observations.tar.xz')
    references=sorted(str(p.relative_to(base)) for kind in ('candidate','reference')
                      for p in base.glob('*/'+kind+'/Lokad.Lython.dll') if p.resolve()==selected)
    expected=sorted(claim['root']+'/candidate/Lokad.Lython.dll' for claim in cfg['archives'])
    assert references==expected,references
    info=selected.lstat()
    assert stat.S_ISREG(info.st_mode) and info.st_size==cfg['bytes'] and info.st_nlink==1 and info.st_uid==os.getuid()
    free=shutil.disk_usage(base).free
    assert free+info.st_blocks*512>=cfg['need'],(free,info.st_blocks*512,cfg['need'])
    if mode=='reclaim':
        selected.unlink()
        for claim in cfg['archives']:
            archived=base/claim['root']/'observations.tar.xz'
            assert sha(archived)==claim['archiveSHA256']
    print(json.dumps(dict(mode=mode,before=free,after=shutil.disk_usage(base).free,
                         archiveDependencies=references,physicalBytes=info.st_blocks*512,need=cfg['need'])))
"""
key = Path.home() / '.ssh/id_lython-bench.pem'
result = subprocess.run(['ssh','-i',str(key),'-o','BatchMode=yes','-o','ConnectTimeout=12',
                         'lokad@20.166.121.73','python3 -'], check=True, capture_output=True, encoding='utf-8',
                         input='cfg='+repr(proof)+'\nmode='+repr(mode)+'\n'+remote, timeout=55)
report = dict(result=json.loads(result.stdout), proof=proof)
(quiet / ('duplicate-core-' + mode + '.json')).write_text(json.dumps(report, indent=2)+'\n',encoding='utf-8')
print(result.stdout)
