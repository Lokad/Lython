from pathlib import Path
from statistics import median
import hashlib
import json
import tarfile

lab = Path(__file__).resolve().parent
quiet = lab / 'comparison/quiet'
read = lambda p: json.loads(p.read_text(encoding='utf-8-sig'))
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
identity = read(quiet / 'identity.json')
status = read(quiet / 'terminal-status.json')
receipt = status['receipt']
assert not status['live'] and not status['fixtures'] and status['exitCode'] == '0'
assert all(receipt[field] for field in ('allWorkersJoined', 'quietBeforeAndAfter', 'archivedAndVerifiedUnderLease',
                                        'guestFixturesRemoved', 'complete'))
assert receipt['archiveSHA256'] == sha(quiet / 'observations.tar.xz') and receipt['warmJobs'] == 4
with tarfile.open(quiet / 'observations.tar.xz') as archive:
    raw = json.load(archive.extractfile('confirmation/confirmation.json'))
    assert json.load(archive.extractfile('identity.json')) == identity
    for name, expected in identity['catalogs'].items():
        assert hashlib.sha256(archive.extractfile(name).read()).hexdigest() == expected['sha256']
assert raw['complete'] and len(raw['jobs']) == 4
summary = []
for job in raw['jobs']:
    assert job['workersJoinedAndFixturesRemoved'] and len(job['samples']) == 28
    measures = {}
    for role, worker in job['identities'].items():
        core = next(v for v in worker['libraries'] if Path(v['path']).name == 'Lokad.Lython.dll')
        assert core['sha256'].lower() == identity['coreSHA256'][role].lower()
        samples = [x for x in job['samples'] if x['engine'] == role]
        assert len(samples) == 7
        elapsed = []
        cpu = []
        for sample in samples:
            completed = sample['response']
            assert completed['status'] == 'Completed'
            count = completed['completedInvocations']
            elapsed.append(1e6 * completed['elapsedTicks'] / completed['clockFrequency'] / count)
            cpu.append(1e6 * sample['externalProcessCpuTicks'] / sample['externalCpuFrequency'] / count)
        measures[role] = dict(elapsed=median(elapsed), cpu=median(cpu))
    differences, spreads = {}, {}
    for metric in ('elapsed', 'cpu'):
        before, after = ([measures[role][metric], measures[role + '-control'][metric]] for role in ('reference', 'candidate'))
        pairs = [100 * (new / old - 1) for new in after for old in before]
        differences[metric] = [min(pairs), max(pairs)]
        spreads[metric] = [100 * (max(row) / min(row) - 1) for row in (before, after)]
    summary.append(dict(case=job['case'], lane=job['lane'], processMedianUs=measures,
                        percentChange=differences, sameSourceSpreadPercent=spreads))
    print(job['case'], job['lane'], differences, spreads)
(quiet / 'summary.json').write_text(json.dumps(dict(sourceRevision=identity['sourceRevision'],
            sourcePatchSHA256=identity['sourcePatchSHA256'], timedBatches=112,
            collectionSeconds=raw['elapsedSeconds'], rows=summary), indent=2) + '\n', encoding='utf-8', newline='\n')
