from pathlib import Path
import hashlib
import json
import shutil
import tarfile

lab = Path(__file__).resolve().parent
local = lab / 'local'
quiet = lab / 'comparison/quiet'
target = lab.parents[3] / 'benchmarks/results/2026-11-26-deferred-site-placement/quiet'
read = lambda path: json.loads(path.read_text(encoding='utf-8-sig'))
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
first, confirmed = map(lambda folder: read(folder / 'identity.json'), (local, quiet))
assert confirmed.keys() == first.keys() | {'expectedCPythonSHA256'}
assert all(first[key] == confirmed[key] for key in first)
status = read(quiet / 'terminal-status.json')
receipt = status['receipt']
assert status['exitCode'] == '0' and not status['live'] and not status['fixtures']
assert all(receipt[key] for key in ('complete','quietBeforeAndAfter','allWorkersJoined',
                                   'guestFixturesRemoved','archivedAndVerifiedUnderLease'))
assert receipt['archiveSHA256'] == sha(quiet / 'observations.tar.xz')
assert receipt['warmJobs'] == 4 and read(quiet / 'summary.json')['timedBatches'] == 112
verify = read(quiet / 'remote-verify.json')
assert verify['state'] == 'Completed' and verify['caseCount'] == 4
assert verify['catalogSha256'] == confirmed['catalogs']['representative.json']['sha256']
assert verify['launched']['library']['sha256'] == confirmed['coreSHA256']['candidate']
target.mkdir(exist_ok=True)
for name in ('identity.json','summary.json','observations.tar.xz','terminal-status.json'):
    shutil.copyfile(quiet / name,target / name)
with tarfile.open(target / 'procedures.tar.xz','w:xz') as archive:
    for name in ('prepare-quiet.py','quiet.py','preserve-core.py','summarize-quiet.py','archive-quiet.py',
                 'launch-console.log','retrieve-quiet.log'):
        archive.add(lab / name,arcname=name)
    for name in ('duplicate-core-preview.json','duplicate-core-reclaim.json','upload.json',
                 'launch.log','remote-verify.json','observe-not-before'):
        archive.add(quiet / name,arcname=name)
print('Archived verified quiet observations and procedures')
