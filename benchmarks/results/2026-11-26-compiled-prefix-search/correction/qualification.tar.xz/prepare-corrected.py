from pathlib import Path
from hashlib import sha256
import json
import os
import shutil
import subprocess

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
prior = lab / "local"
current = lab / "corrected"
core = "Lokad.Lython.dll"

def read(path):
    return path.read_text(encoding="utf-8-sig")

def write(path, text):
    path.write_text(text, encoding="utf-8", newline="\n")

def digest(path):
    return sha256(path.read_bytes()).hexdigest()

def manifest(path):
    return {file.name: digest(file) for file in path.iterdir()}

identity = json.loads(read(prior / "identity.json"))
base = subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=repo, text=True).strip()
assert base == identity["sourceRevision"]
assert not subprocess.check_output(["git", "diff", "--", "src", "tests"], cwd=repo)
core_path = repo / "tools/LythonProbe/bin/Release/net11.0" / core
core_sha = digest(core_path)
assert core_sha == digest(repo / "tests/Lokad.Lython.PublicApi.Tests/bin/Release/net11.0" / core)
current.mkdir()
for kind, target in (("src", "candidate.patch"), ("tests", "tests.patch")):
    (current / target).write_bytes(subprocess.check_output(["git", "diff", "--cached", "--binary", "HEAD", "--", kind], cwd=repo))
identity["sourcePatchSHA256"] = digest(current / "candidate.patch")
for role, files in identity["imageFiles"].items():
    assert len(files) == 32 and manifest(prior / role) == files
    image = current / role
    shutil.copytree(prior / role, image)
    if role == "candidate":
        shutil.copyfile(core_path, image / core)
        identity["imageFiles"][role][core] = core_sha
    assert manifest(image) == files
assert [name for name, sha in identity["imageFiles"]["reference"].items() if sha != identity["imageFiles"]["candidate"][name]] == [core]
identity["coreSHA256"].update(candidate=core_sha, **{"candidate-control": core_sha})
for name in ("representative.json", "cpython-worker.py", "run.sh"):
    shutil.copyfile(prior / name, current / name)
assert digest(current / "representative.json") == identity["catalogSHA256"]
assert digest(current / "cpython-worker.py") == identity["cpythonWorkerSHA256"]
assert b"\r" not in (current / "run.sh").read_bytes()
jobs = json.loads(read(prior / "jobs.json"))
jobs["warm"] = [job for job in jobs["warm"] if job[-1] == "warm-async"]
assert len(jobs["warm"]) == 3
write(current / "jobs.json", json.dumps(jobs, indent=2) + "\n")
identity["catalogs"]["jobs.json"]["sha256"] = digest(current / "jobs.json")
identity["purpose"] = "Check the bounded literal proof on the corrected source and recheck late and early async with the same Unicode control."
write(current / "identity.json", json.dumps(identity, indent=2) + "\n")
collector = read(prior / "collect.py").replace("assert len(jobs) == 5 and", "assert len(jobs) == 3 and")
compile(collector, "collect.py", "exec")
write(current / "collect.py", collector)
summary = read(lab / "summarize.py")
for old, new in (("lab / 'local'", "lab / 'corrected'"), ("['warmJobs'] == 5", "['warmJobs'] == 3"), ("len(raw['jobs']) == 5", "len(raw['jobs']) == 3"), ("timedBatches=140", "timedBatches=84")):
    assert summary.count(old) == 1
    summary = summary.replace(old, new)
compile(summary, "summarize.py", "exec")
write(lab / "summarize-corrected.py", summary)

sdk = Path.home() / ".dotnet11"
dotnet = sdk / "dotnet.exe"
env = dict(os.environ, DOTNET_ROOT=str(sdk), DOTNET_ROOT_X64=str(sdk))
image = current / "candidate"
verify = current / "candidate-verify.json"
subprocess.run([dotnet, image / "Lokad.Lython.Benchmarks.dll", "--compare", "verify", "--catalog", current / "representative.json", "--dotnet", dotnet, "--python", "C:/Python313/python.exe", "--python-worker", current / "cpython-worker.py", "--out", verify], check=True, cwd=repo, env=env, timeout=100)
proof = json.loads(read(verify))
assert proof["caseCount"] == 3 and proof["state"] == "Completed"
assert proof["catalogSha256"] == identity["catalogSHA256"]
assert proof["launched"]["library"]["sha256"] == core_sha
allocation = current / "candidate-allocated"
shutil.copytree(image, allocation)
for file in (lab / "candidate-allocated").glob("ValidatedAllocation*"):
    shutil.copyfile(file, allocation / file.name)
assert all(digest(allocation / name) == sha for name, sha in identity["imageFiles"]["candidate"].items())
for mode, catalog in (("sync", lab / "representative.json"), ("async", lab / "async-catalog.json")):
    output = current / f"candidate-{mode}-allocation.json"
    subprocess.run([dotnet, allocation / "ValidatedAllocation.dll", allocation, catalog, output], check=True, cwd=repo, env=env, timeout=90)
    old = json.loads(read(lab / f"candidate-{mode}-allocation.json"))["rows"]
    new = json.loads(read(output))["rows"]
    for previous, row in zip(old, new, strict=True):
        assert row["id"] == previous["id"]
        assert row["sharedBudgetBaselineRestored"]
        for field in ("allocatedBytesPerInvocation", "peakExecutionMemoryBytes"):
            assert row[field] == previous[field], (row["id"], field, row[field], previous[field])
        print(mode, row["id"], row["allocatedBytesPerInvocation"], row["peakExecutionMemoryBytes"])
