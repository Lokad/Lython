STEP = 2
def search(lines):
    def wanted(line):
        return line.startswith('needle')
    scanned = 0
    for line in lines:
        scanned += STEP
        if wanted(line):
            break
    return scanned
print(search(['no','needle']))
