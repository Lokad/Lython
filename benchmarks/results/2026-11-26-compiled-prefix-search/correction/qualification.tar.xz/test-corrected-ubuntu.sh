set -eu
export DOTNET_ROOT="$HOME/.dotnet"
export PATH="$DOTNET_ROOT:$PATH"
repo=/mnt/d/code/Lython
lab="$repo/.git/agent-notes/review-20261031/compiled-prefix-search-20261126"
snapshot=$(cat "$lab/ubuntu-source.txt" | tr -d '\r\n')
case "$snapshot" in "$HOME"/lython-compiled-prefix-*) ;; *) exit 1 ;; esac
cd "$snapshot"
while IFS= read -r path; do
    path=$(printf '%s' "$path" | tr -d '\r')
    cp "$repo/$path" "$path"
    cmp "$repo/$path" "$path"
done < "$lab/changed-files.txt"
dotnet build tools/LythonProbe/LythonProbe.csproj -c Release -f net10.0 --no-incremental > "$lab/corrected-probe-ubuntu10-build.log" 2>&1
filter=$(tr -d '\r\n' < "$lab/filter.txt")
for suite in Lokad.Lython.Tests Lokad.Lython.PublicApi.Tests; do
    log="$lab/corrected-$suite-ubuntu10.log"
    if dotnet test "tests/$suite/$suite.csproj" -c Release -f net10.0 --filter "$filter" > "$log" 2>&1; then
        tail -6 "$log"
    else
        tail -30 "$log"
        exit 1
    fi
done
probe=$(find tools/LythonProbe/bin -name LythonProbe.dll | head -1)
public=$(find tests/Lokad.Lython.PublicApi.Tests/bin -name Lokad.Lython.PublicApi.Tests.dll | head -1)
cmp "$(dirname "$probe")/Lokad.Lython.dll" "$(dirname "$public")/Lokad.Lython.dll"
