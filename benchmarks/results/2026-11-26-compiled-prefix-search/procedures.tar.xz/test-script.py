
def wanted(line):
    return line.startswith('needle')
def alternate(line):
    return line.endswith('!\n')
if rebound:
    wanted = alternate
scanned = 0
match = ''
with open('input.txt') as source:
    for line in source:
        scanned += 1
        if wanted(line):
            match = line
            break
print(scanned, line == match)
with open('report.txt', 'w', newline='') as output:
    output.write(line)
