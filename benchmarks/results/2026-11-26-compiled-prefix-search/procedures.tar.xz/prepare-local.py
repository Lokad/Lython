from hashlib import sha256
from pathlib import Path
import json
import shutil

lab = Path(__file__).resolve().parent
prior = lab.with_name("starmap-frame-inputs-20261126")
local = lab / "local"
local.mkdir()

def read(path):
    return path.read_text(encoding="utf-8-sig")

def write(path, text):
    path.write_text(text, encoding="utf-8", newline="\n")

def digest(path):
    return sha256(path.read_bytes()).hexdigest()

identity = json.loads(read(lab / "identity.json"))
for role, files in identity["imageFiles"].items():
    source = lab / role
    assert len(files) == 32 and {path.name: digest(path) for path in source.iterdir()} == files
    target = local / role
    shutil.copytree(source, target)
    assert {path.name: digest(path) for path in target.iterdir()} == files
for name in ("representative.json", "cpython-worker.py"):
    shutil.copyfile(lab / name, local / name)
assert identity["catalogSHA256"] == digest(local / "representative.json")
assert identity["cpythonWorkerSHA256"] == digest(local / "cpython-worker.py")
jobs = {'warm': [['scripts.file-search.large', 'warm-async'], ['diagnostic.text-summary.nonlocal-computed-width.large', 'warm-async'], ['scripts.file-search.large', 'warm'], ['diagnostic.file-search-first-line', 'warm-async'], ['scripts.file-search.large', 'compile-run']]}
write(local / "jobs.json", json.dumps(jobs, indent=2) + "\n")
identity["coreSHA256"] = {role + suffix: files["Lokad.Lython.dll"]
                          for role, files in identity["imageFiles"].items() for suffix in ("", "-control")}
identity["catalogs"] = {name: {"sha256": digest(local / name)} for name in ("representative.json", "jobs.json")}
identity["purpose"] = "Mark counted file searches at the backedge and check the decoded window before inspecting live values."
write(local / "identity.json", json.dumps(identity, indent=2) + "\n")
collector = read(prior / "local/collect.py")
collector = collector.replace("assert len(jobs) == 4 and", "assert len(jobs) == 5 and")
collector = collector.replace("lython-starmap-frame-inputs-fixture-", "lython-compiled-prefix-fixture-")
assert collector != read(prior / "local/collect.py")
compile(collector, "collect.py", "exec")
write(local / "collect.py", collector)
shutil.copyfile(prior / "local/run.sh", local / "run.sh")
assert b"\r" not in (local / "run.sh").read_bytes()
summary = read(prior / "summarize.py")
for before, after in (("receipt['warmJobs'] == 4", "receipt['warmJobs'] == 5"),
                      ("len(raw['jobs']) == 4", "len(raw['jobs']) == 5"), ("timedBatches=112", "timedBatches=140")):
    assert summary.count(before) == 1
    summary = summary.replace(before, after)
compile(summary, "summarize.py", "exec")
write(lab / "summarize.py", summary)
