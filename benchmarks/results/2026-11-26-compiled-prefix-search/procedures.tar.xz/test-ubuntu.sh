set -eu
export DOTNET_ROOT="$HOME/.dotnet"
export PATH="$DOTNET_ROOT:$PATH"
repo=/mnt/d/code/Lython
lab="$repo/.git/agent-notes/review-20261031/compiled-prefix-search-20261126"
snapshot=$(mktemp -d "$HOME/lython-compiled-prefix-XXXXXX")
tar -xf "$lab/test-source.tar" -C "$snapshot"
for file in src/Lokad.Lython/Frontend/ExecutableScript.NativeSegments.cs src/Lokad.Lython/Frontend/ExecutableScript.cs src/Lokad.Lython/Frontend/ExecutableStackLayout.cs src/Lokad.Lython/Public/LythonMemoryBudget.cs src/Lokad.Lython/Runtime/LythonRuntime.Executable.FileSearch.cs src/Lokad.Lython/Runtime/LythonRuntime.Executable.Interpreter.Async.cs src/Lokad.Lython/Runtime/LythonRuntime.Executable.Interpreter.cs src/Lokad.Lython/Runtime/LythonRuntime.TextFileHandle.Read.cs src/Lokad.Lython/Runtime/LythonRuntime.TextFileHandle.cs src/Lokad.Lython/Runtime/MemoryGovernor.cs src/Lokad.Lython/Runtime/PyExecutableFunction.cs tests/Lokad.Lython.PublicApi.Tests/BoundedStartsWithLifetimeTests.cs; do
    cp "$lab/source/$file" "$snapshot/$file"
    cmp "$lab/source/$file" "$snapshot/$file"
done
printf '%s\n' "$snapshot" > "$lab/ubuntu-source.txt"
cd "$snapshot"
filter='Category!=Stress&(FullyQualifiedName~ProtectedLoop|FullyQualifiedName~ProtectedHelper|FullyQualifiedName~BoundedStartsWith|FullyQualifiedName~TextFile|FullyQualifiedName~BufferedLineAdmission|FullyQualifiedName~ExecutableStackAdmission|FullyQualifiedName~AdmissionFailureCommand|FullyQualifiedName~ExecutableCompiler|FullyQualifiedName~Exception)'
for suite in Lokad.Lython.Tests Lokad.Lython.PublicApi.Tests; do
    log="$lab/$suite-ubuntu10.log"
    if dotnet test "tests/$suite/$suite.csproj" -c Release -f net10.0 --filter "$filter" > "$log" 2>&1; then
        tail -8 "$log"
    else
        tail -33 "$log"
        exit 1
    fi
done
