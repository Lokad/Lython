from pathlib import Path
import ast, hashlib, json, tarfile
r=Path(__file__).parent;prior=r.parent/'xml-utf8-input-r328/b697';out=r/'b698';out.mkdir()
source=json.loads((r/'candidate-identity.json').read_text(encoding='utf-8'))
identity=json.loads((prior/'identity.json').read_text(encoding='utf-8'))
identity['sourceRevision']='R329 frozenc16b44f0 vs R328/frozen316142ab; iterative UTF8 XML selection; fixed B685 workers/adapter0.4'
identity['purpose']='Complete XML settings lookup/report with CPython goldens; existing file-search control; allocation measured separately'
identity['coreSHA256']={label:source['coreSHA256']['candidate'if label.startswith('candidate')else'reference']for label in['reference','candidate','reference-control','candidate-control']}
identity['catalogSHA256']=hashlib.sha256((r/'catalog.json').read_bytes()).hexdigest()
identity['referenceCase']=identity['variantCase']='scripts.xml-settings.large'
(out/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8')
oldroot='/home/lokad/lython-bench-checks/xml-utf8-input-b697-20261113';root='/home/lokad/lython-bench-checks/xml-select-b698-20261113';unit='lython-b698-xml-select-20261113'
for name in ['collect.py','archive-owned.py','run.sh','retrieve.py','summarize.py']:
 s=(prior/name).read_text(encoding='utf-8').replace(oldroot,root).replace('lython-b697-xml-utf8-input-20261113',unit).replace('B697','B698').replace('scripts.xml-summary.large','scripts.xml-settings.large')
 if name.endswith('.py'):ast.parse(s)
 (out/name).write_text(s,encoding='utf-8',newline='\n')
with tarfile.open(out/'payload.tgz','w:gz')as t:
 for name in ['identity.json','collect.py','archive-owned.py','run.sh']:t.add(out/name,arcname=name)
 t.add(r/'catalog.json',arcname='representative.json');t.add(r/'candidate-core.dll',arcname='candidate-core.dll');t.add(r/'candidate-identity.json',arcname='source-identity.json')
with tarfile.open(out/'payload.tgz')as t:unpacked=sum(m.size for m in t.getmembers())
retire=json.loads((r/'retirement-inspection.json').read_text(encoding='utf-8'))['retire']
config=dict(root=root,sourceRoot=oldroot,unit=unit,identity=identity,retire=[retire],payloadBytes=(out/'payload.tgz').stat().st_size,payloadSHA256=hashlib.sha256((out/'payload.tgz').read_bytes()).hexdigest(),unpackedBytes=unpacked)
(out/'config.json').write_text(json.dumps(config,indent=2)+'\n',encoding='utf-8')
s=(r.parent/'xml-utf8-input-r328/b696/launch.py').read_text(encoding='utf-8')
s=s.replace("['word-buffer-loan-b690-', 'word-buffer-loan-b691-', 'post-loan-profile-b692-', 'final-slot-binding-b693-', 'final-slot-binding-b694-']","['final-slot-binding-b694-', 'native-entry-ip-b695-', 'xml-utf8-input-b696-', 'xml-utf8-input-b697-']").replace('lython-b696-fixtures','lython-b698-fixtures')
ast.parse(s);(out/'launch.py').write_text(s,encoding='utf-8',newline='\n')
for name in ['verify-workers.py','measure-allocation.py']:(r/name).write_bytes((r.parent/'xml-utf8-input-r328'/name).read_bytes())
print('Prepared same-code XML settings/search comparison,180s owner; byte-proved historical660 working images retired only under fresh lease.',flush=True)
