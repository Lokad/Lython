from pathlib import Path
import hashlib, json, shutil, tarfile
r=Path(__file__).parent;out=Path('benchmarks/results/2026-11-13-xml-selection');out.mkdir(exist_ok=True)
identity=json.loads((r/'candidate-identity.json').read_text(encoding='utf-8'));assert len(identity['sources'])==577
assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==sha for p,sha in identity['sources'].items())
for stem in ['b698','b699']:
    folder=out/stem;folder.mkdir(exist_ok=True)
    for name in ['observations.tgz','archive-receipt.json','terminal-status.json','summary.json']:
        shutil.copy2(r/stem/name,folder/name)
    assert json.loads((r/stem/'summary.json').read_text(encoding='utf-8'))['complete']
names=['candidate-core.dll','candidate-identity.json','candidate-sources.tar.xz','freeze.py','freeze-build.log','check.py','check-ownership.py','check-slice-correction.py','internal-net11.0.log','internal-net10.0.log','public-net11.0.log','public-net10.0.log','ownership-net11.0.log','ownership-net10.0.log','slice-correction-net11.0.log','slice-correction-net10.0.log','prepare-catalog.py','catalog.json','python-controls.py','verify-goldens.py','python-goldens.json','workload-python-golden.json','measure-allocation.py','allocation-summary.json','verify-workers.py','worker-reference-validation.json','worker-candidate-validation.json','worker-reference.stderr','worker-candidate.stderr','worker-reference-fixture.json','worker-candidate-fixture.json','prepare-comparison.py','inspect-retirement.py','retirement-inspection-command.py','retirement-inspection.json','inspect-old-manifest.py','manifest-retirement-command.py','manifest-retirement-inspection.json','prepare-b699.py','make-confirmation-launcher.py','launch-confirmation.py','save.py']
names += [p.name for p in r.glob('*-allocation-*.*')]
with tarfile.open(out/'source-checks.tar.xz','w:xz')as t:
    for name in dict.fromkeys(names):t.add(r/name,arcname=name)
    for stem in ['b698','b699']:
        for name in ['config.json','launch-command.py','launch.log','observe-not-before.json','retrieve.py','summarize.py','retirement-inspection-command.py','retirement-inspection.json','initial-space-preflight-note.json']:
            if(r/stem/name).exists():t.add(r/stem/name,arcname=stem+'/'+name)
shutil.copy2(r/'allocation-summary.json',out/'allocation-summary.json')
print('Saved both source-specific VM observations, goldens, allocation evidence and focused/cleanup checks.',flush=True)
