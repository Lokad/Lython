from pathlib import Path
import base64, copy, hashlib, json, struct, subprocess, tempfile
r = Path(__file__).parent
prior = r.parent / 'xml-utf8-input-r328'
catalog = json.loads((prior / 'catalog.json').read_text(encoding='utf-8'))
case = copy.deepcopy(catalog['cases'][0])
n = 512
text = '<settings>' + ''.join(f'<setting_{i}><value>{i}</value><label>café Ω😀 {i}</label></setting_{i}>' for i in range(n)) + '</settings>'
source = '''import xml.etree.ElementTree as ET
with open('input.xml') as source:
    root=ET.fromstring(source.read())
total=0
for index in range(0,512,8):
    value=root.find('setting_'+str(index)+'/value')
    total+=int(value.text)
label=root.find('setting_0/label').text
with open('report.txt','w',newline='') as report:
    report.write(label+'\u005cn'+str(total)+'\u005cn')
print(len(root),total)
'''
expected = '512 16128\n'
report = 'café Ω😀 0\n16128\n'
fixture = json.loads(case['fixtureJson'])
fixture.update(size=n,text='',inputFiles={'input.xml':base64.b64encode(text.encode()).decode()},outputFiles={'report.txt':base64.b64encode(report.encode()).decode()})
# Preserve the existing file-worker schema; recompute every affected immutable hash.
case.update(id='scripts.xml-settings.large', size=n, source=source, expectedOutput=expected, fixtureJson=json.dumps(fixture,separators=(',',':'),ensure_ascii=False),sourceUtf8Bytes=len(source.encode()),expectedOutputUtf8Bytes=len(expected.encode()),fixtureTextUtf8Bytes=0,fixtureTextCodePoints=0)
case['sourceSha256'] = hashlib.sha256(source.encode()).hexdigest()
case['fixtureSha256'] = hashlib.sha256(case['fixtureJson'].encode()).hexdigest()
case['expectedOutputSha256'] = hashlib.sha256(expected.encode()).hexdigest()
h=hashlib.sha256();h.update(struct.pack('>i',1));name=b'report.txt';data=report.encode()
h.update(struct.pack('>i',len(name)));h.update(name);h.update(struct.pack('>i',len(data)));h.update(data)
case['expectedFilesSha256']=h.hexdigest()
catalog['cases'][0]=case
(r / 'catalog.json').write_text(json.dumps(catalog,ensure_ascii=False,separators=(',',':'))+'\n',encoding='utf-8')
with tempfile.TemporaryDirectory(prefix='lython-xml-settings-',dir=r.resolve()) as folder:
    root = Path(folder).resolve(); assert root.parent==r.resolve() and root.is_relative_to(Path.cwd().resolve()) and root.name.startswith('lython-xml-settings-')
    (root/'input.xml').write_text(text,encoding='utf-8',newline='\n')
    done = subprocess.run(['C:/Python313/python.exe','-I','-S','-X','utf8','-c',source],cwd=folder,capture_output=True,encoding='utf-8',timeout=10)
    assert done.returncode==0 and not done.stderr, done.stderr
    assert done.stdout==expected and(root/'report.txt').read_bytes()==report.encode()and(root/'input.xml').read_bytes()==text.encode()
(r/'workload-python-golden.json').write_text(json.dumps(dict(python='3.13.2',settings=n,lookups=64,inputBytes=len(text.encode()),sourceSHA256=case['sourceSha256'],fixtureSHA256=case['fixtureSha256'],stdout=expected,expectedOutputSHA256=case['expectedOutputSha256'],expectedFilesSHA256=case['expectedFilesSha256'],exactFilesAndUnchangedInput=True,performanceNotMeasured=True),indent=2)+'\n',encoding='utf-8')
print('Independent settings/report/stdout/input goldens pass CPython3.13.2; exact file-hash manifest finalized.',flush=True)
