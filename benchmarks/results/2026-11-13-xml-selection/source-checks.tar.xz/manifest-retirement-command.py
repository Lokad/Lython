from pathlib import Path
import fcntl,hashlib,json,os,shutil,stat,subprocess
base=Path('/home/lokad/lython-bench-checks').resolve();proof={'path': 'xml-utf8-input-b696-20261113/representative.json', 'canonical': 'benchmarks/results/2026-11-13-xml-utf8-input/b696/observations.tgz', 'member': 'representative.json', 'sha256': 'f847f184e81670857dfd43901a1a971b4d310fc1d06ec20330b15c33eb30717c', 'bytes': 353532}
with(base/'comparison-vm.lock').open('a')as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[d]otnet.*complete-jobs.dll|[p]erf record|[p]ython3.*cpython-worker.py'],capture_output=True).returncode==1
 p=base/proof['path'];s=p.lstat();assert p.resolve(strict=True)==p and p.is_relative_to(base)and stat.S_ISREG(s.st_mode)and s.st_uid==os.getuid()and s.st_size==proof['bytes']and hashlib.sha256(p.read_bytes()).hexdigest()==proof['sha256']
 aliases=[]
 for folder,dirs,files in os.walk(base,followlinks=False):
  for n in files:
   q=Path(folder)/n;t=q.lstat()
   if(t.st_dev,t.st_ino)==(s.st_dev,s.st_ino):aliases.append(str(q.relative_to(base)))
 assert len(aliases)==s.st_nlink and all('xml-utf8-input-b696-'in x for x in aliases)
 print(json.dumps(dict(freshIdleLease=True,readOnly=True,freeBytes=shutil.disk_usage(base).free,retire=dict(**proof,device=s.st_dev,inode=s.st_ino,links=s.st_nlink,allocatedBytes=s.st_blocks*512,aliases=aliases))))
