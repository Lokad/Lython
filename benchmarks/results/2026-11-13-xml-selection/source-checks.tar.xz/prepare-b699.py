from pathlib import Path
import ast, hashlib, json, subprocess, tarfile
r=Path(__file__).parent;prior=r/'b698';out=r/'b699';out.mkdir(exist_ok=True)
assert not(out/'launch.log').exists()
(out/'initial-space-preflight-note.json').write_text(json.dumps(dict(noMutation=True,source='Tool-output condition, not a raw stream',condition='Read-only inspection found that the historical B693 working archive was already absent. No launch or measurement occurred; select two committed old manifests instead.'))+'\n',encoding='utf-8')
proofs=[]
for canonical,remote in [('benchmarks/results/2026-11-13-xml-utf8-input/b697/observations.tgz','xml-utf8-input-b697-20261113/representative.json'),('benchmarks/results/2026-11-13-final-slot-binding/b694-observations.tgz','final-slot-binding-b694-20261113/representative.json')]:
 p=Path(canonical);assert subprocess.check_output(['git','show','HEAD:'+canonical])==p.read_bytes()
 with tarfile.open(p)as t:data=t.extractfile('representative.json').read()
 proofs.append(dict(path=remote,canonical=canonical,member='representative.json',sha256=hashlib.sha256(data).hexdigest(),bytes=len(data)))
s='''from pathlib import Path
import fcntl,hashlib,json,os,shutil,stat,subprocess
base=Path('/home/lokad/lython-bench-checks').resolve();proofs=PROOFS
with(base/'comparison-vm.lock').open('a')as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record|[p]ython3.*cpython-worker.py'],capture_output=True).returncode==1
 rows=[]
 for proof in proofs:
  p=base/proof['path'];s=p.lstat();assert p.resolve(strict=True)==p and p.is_relative_to(base)and stat.S_ISREG(s.st_mode)and s.st_uid==os.getuid()and s.st_size==proof['bytes']and hashlib.sha256(p.read_bytes()).hexdigest()==proof['sha256']and s.st_nlink==1
  rows.append(dict(**proof,device=s.st_dev,inode=s.st_ino,links=1,allocatedBytes=s.st_blocks*512,aliases=[proof['path']]))
 print(json.dumps(dict(freshIdleLease=True,readOnly=True,freeBytes=shutil.disk_usage(base).free,retire=rows)))
'''.replace('PROOFS',repr(proofs))
ast.parse(s);(out/'retirement-inspection-command.py').write_text(s,encoding='utf-8')
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
done=subprocess.run(ssh+['python3 -'],input=s,text=True,encoding='utf-8',capture_output=True);assert done.returncode==0,done.stderr
inspection=json.loads(done.stdout);(out/'retirement-inspection.json').write_text(json.dumps(inspection,indent=2)+'\n',encoding='utf-8')
identity=json.loads((prior/'identity.json').read_text(encoding='utf-8'));identity['purpose']+='; same-image confirmation after adverse unchanged search; reverse job and process creation order, retain original B698'
(out/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8')
source_root='/home/lokad/lython-bench-checks/xml-select-b698-20261113';root='/home/lokad/lython-bench-checks/xml-select-b699-20261113';unit='lython-b699-xml-select-20261113'
for name in ['collect.py','archive-owned.py','run.sh','retrieve.py','summarize.py']:
 s=(prior/name).read_text(encoding='utf-8').replace(source_root,root).replace('lython-b698-xml-select-20261113',unit).replace('B698','B699')
 if name=='collect.py':
  s=s.replace("jobs=[['scripts.xml-settings.large','warm'],['scripts.file-search.large','warm']]","jobs=[['scripts.file-search.large','warm'],['scripts.xml-settings.large','warm']]")
  s=s.replace("labels=['reference','candidate','reference-control','candidate-control']","labels=['candidate-control','reference-control','candidate','reference']")
 if name.endswith('.py'):ast.parse(s)
 (out/name).write_text(s,encoding='utf-8',newline='\n')
with tarfile.open(out/'payload.tgz','w:gz')as t:
 for name in ['identity.json','collect.py','archive-owned.py','run.sh']:t.add(out/name,arcname=name)
 t.add(r/'catalog.json',arcname='representative.json')
with tarfile.open(out/'payload.tgz')as t:unpacked=sum(m.size for m in t.getmembers())
config=dict(root=root,sourceRoot=source_root,unit=unit,identity=identity,retire=inspection['retire'],payloadBytes=(out/'payload.tgz').stat().st_size,payloadSHA256=hashlib.sha256((out/'payload.tgz').read_bytes()).hexdigest(),unpackedBytes=unpacked)
(out/'config.json').write_text(json.dumps(config,indent=2)+'\n',encoding='utf-8');print('Prepared same frozen runtimes, reversed job/process creation order; candidate/reference images and canonical raw evidence preserved.',flush=True)
