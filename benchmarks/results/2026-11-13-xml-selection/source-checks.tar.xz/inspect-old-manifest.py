from pathlib import Path
import ast, hashlib, json, subprocess, tarfile
r=Path(__file__).parent
canonical='benchmarks/results/2026-11-13-xml-utf8-input/b696/observations.tgz'
p=Path(canonical);assert subprocess.check_output(['git','show','HEAD:'+canonical])==p.read_bytes()
with tarfile.open(p)as t:data=t.extractfile('representative.json').read()
proof=dict(path='xml-utf8-input-b696-20261113/representative.json',canonical=canonical,member='representative.json',sha256=hashlib.sha256(data).hexdigest(),bytes=len(data))
s=(r.parent/'checkpoint-cpython-r318/inspect-command.py').read_text(encoding='utf-8');a=s.index('proof=');b=s.index('\nwith(',a);s=s[:a]+'proof='+repr(proof)+s[b:]
s=s.replace("all('builtin-setup'not in x for x in aliases)","all('xml-utf8-input-b696-'in x for x in aliases)")
ast.parse(s);(r/'manifest-retirement-command.py').write_text(s,encoding='utf-8')
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
done=subprocess.run(ssh+['python3 -'],input=s,text=True,encoding='utf-8',capture_output=True);assert done.returncode==0,done.stderr
d=json.loads(done.stdout);(r/'manifest-retirement-inspection.json').write_text(json.dumps(d,indent=2)+'\n',encoding='utf-8')
p=r/'b698/config.json';config=json.loads(p.read_text(encoding='utf-8'));assert len(config['retire'])==1;config['retire'].append(d['retire']);p.write_text(json.dumps(config,indent=2)+'\n',encoding='utf-8');print(d,flush=True)
