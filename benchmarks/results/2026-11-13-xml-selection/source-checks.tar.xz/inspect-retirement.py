from pathlib import Path
import ast, hashlib, json, subprocess, tarfile
r=Path(__file__).parent
canonical='benchmarks/results/2026-11-13-final-slot-binding/refined-source-checks.tar.xz'
p=Path(canonical);assert subprocess.check_output(['git','show','HEAD:'+canonical])==p.read_bytes()
with tarfile.open(p)as t:
    matches=[m for m in t.getmembers()if m.isfile()and m.name.endswith('candidate-core.dll')]
    rows=[(m,t.extractfile(m).read())for m in matches]
    matched=[(m,data)for m,data in rows if hashlib.sha256(data).hexdigest()=='660a033872f5fb161485dc26533dd754218d9e38172f12dfaf708846d703ad2e']
assert len(matched)==1,[(m.name,hashlib.sha256(data).hexdigest())for m,data in rows]
member,data=matched[0]
proof=dict(path='final-slot-binding-b694-20261113/candidate/Lokad.Lython.dll',canonical=canonical,member=member.name,sha256=hashlib.sha256(data).hexdigest(),bytes=len(data))
s=(r.parent/'checkpoint-cpython-r318/inspect-command.py').read_text(encoding='utf-8');a=s.index('proof=');b=s.index('\nwith(',a);s=s[:a]+'proof='+repr(proof)+s[b:]
s=s.replace("all('builtin-setup'not in x for x in aliases)","all(any(prefix in x for prefix in ['final-slot-binding-b694-','native-entry-ip-b695-','native-entry-instructions-b695-','xml-utf8-input-b696-','xml-utf8-input-b697-'])for x in aliases)")
ast.parse(s);(r/'retirement-inspection-command.py').write_text(s,encoding='utf-8')
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
done=subprocess.run(ssh+['python3 -'],input=s,text=True,encoding='utf-8',capture_output=True)
(r/'retirement-inspection.log').write_text(done.stdout+done.stderr,encoding='utf-8');assert done.returncode==0,done.stderr
d=json.loads(done.stdout);(r/'retirement-inspection.json').write_text(json.dumps(d,indent=2)+'\n',encoding='utf-8');print(d,flush=True)
