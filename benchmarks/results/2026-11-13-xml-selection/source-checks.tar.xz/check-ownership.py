from pathlib import Path
import os, subprocess
r = Path(__file__).parent
env = dict(os.environ)
env['DOTNET_ROOT'] = 'C:/Users/JoannesVermorel/.dotnet11'
env['PATH'] = env['DOTNET_ROOT'] + ';C:/Python313;' + env['PATH']
for framework in ['net11.0', 'net10.0']:
    log = r / ('ownership-' + framework + '.log')
    with log.open('w', encoding='utf-8', newline='\n') as f:
        done = subprocess.run([env['DOTNET_ROOT'] + '/dotnet.exe', 'test', 'tests/Lokad.Lython.Tests/Lokad.Lython.Tests.csproj', '-c', 'Release', '-f', framework, '--filter', 'FullyQualifiedName~XmlSelectionOwnershipTests', '--nologo'], env=env, stdout=f, stderr=subprocess.STDOUT)
    print(framework, done.returncode, '\n'.join(log.read_text(encoding='utf-8').splitlines()[-20:]), flush=True)
    assert done.returncode == 0
