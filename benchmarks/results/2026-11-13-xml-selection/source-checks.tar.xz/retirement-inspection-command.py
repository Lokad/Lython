from pathlib import Path
import fcntl,hashlib,json,os,shutil,stat,subprocess
base=Path('/home/lokad/lython-bench-checks').resolve();proof={'path': 'final-slot-binding-b694-20261113/candidate/Lokad.Lython.dll', 'canonical': 'benchmarks/results/2026-11-13-final-slot-binding/refined-source-checks.tar.xz', 'member': 'candidate-core.dll', 'sha256': '660a033872f5fb161485dc26533dd754218d9e38172f12dfaf708846d703ad2e', 'bytes': 5705728}
with(base/'comparison-vm.lock').open('a')as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[d]otnet.*complete-jobs.dll|[p]erf record|[p]ython3.*cpython-worker.py'],capture_output=True).returncode==1
 p=base/proof['path'];s=p.lstat();assert p.resolve(strict=True)==p and p.is_relative_to(base)and stat.S_ISREG(s.st_mode)and s.st_uid==os.getuid()and s.st_size==proof['bytes']and hashlib.sha256(p.read_bytes()).hexdigest()==proof['sha256']
 aliases=[]
 for folder,dirs,files in os.walk(base,followlinks=False):
  for n in files:
   q=Path(folder)/n;t=q.lstat()
   if(t.st_dev,t.st_ino)==(s.st_dev,s.st_ino):aliases.append(str(q.relative_to(base)))
 assert len(aliases)==s.st_nlink and all(any(prefix in x for prefix in ['final-slot-binding-b694-','native-entry-ip-b695-','native-entry-instructions-b695-','xml-utf8-input-b696-','xml-utf8-input-b697-'])for x in aliases)
 print(json.dumps(dict(freshIdleLease=True,readOnly=True,freeBytes=shutil.disk_usage(base).free,retire=dict(**proof,device=s.st_dev,inode=s.st_ino,links=s.st_nlink,allocatedBytes=s.st_blocks*512,aliases=aliases))))
