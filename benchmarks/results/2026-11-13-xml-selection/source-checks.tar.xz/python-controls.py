import json, xml.etree.ElementTree as ET
root = ET.fromstring('<r xmlns:p="urn:x"><group><p:x n="1"/><group><p:x n="2"/></group><p:x n="3"/></group><group><p:x n="4"/></group><p:x n="5"/></r>')
paths = ['.', './.', './/p:x', 'group//p:x', './/group/p:x', './/group//p:x', './/*', 'group//', './/.', './//p:x', '//p:x']
rows=[]
for path in paths:
    try:
        values=root.findall(path, {'p':'urn:x'})
        row=dict(path=path,tags=[v.tag for v in values],n=[v.get('n')for v in values],first=root.find(path,{'p':'urn:x'}).get('n') if values else None)
    except Exception as error: row=dict(path=path,error=type(error).__name__)
    rows.append(row)
print(json.dumps(rows, ensure_ascii=False, indent=2))
