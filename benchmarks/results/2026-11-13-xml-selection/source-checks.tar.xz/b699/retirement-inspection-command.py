from pathlib import Path
import fcntl,hashlib,json,os,shutil,stat,subprocess
base=Path('/home/lokad/lython-bench-checks').resolve();proofs=[{'path': 'xml-utf8-input-b697-20261113/representative.json', 'canonical': 'benchmarks/results/2026-11-13-xml-utf8-input/b697/observations.tgz', 'member': 'representative.json', 'sha256': '27293ffed21025ff794efcf8a5d21d620f8e77e2c588ee27ce74c20ca6d1fc0a', 'bytes': 353546}, {'path': 'final-slot-binding-b694-20261113/representative.json', 'canonical': 'benchmarks/results/2026-11-13-final-slot-binding/b694-observations.tgz', 'member': 'representative.json', 'sha256': 'd4b75d1c284ff1defa39859d77c20763d2eda81f5cf67b23e7f88e28563e69b2', 'bytes': 108614}]
with(base/'comparison-vm.lock').open('a')as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record|[p]ython3.*cpython-worker.py'],capture_output=True).returncode==1
 rows=[]
 for proof in proofs:
  p=base/proof['path'];s=p.lstat();assert p.resolve(strict=True)==p and p.is_relative_to(base)and stat.S_ISREG(s.st_mode)and s.st_uid==os.getuid()and s.st_size==proof['bytes']and hashlib.sha256(p.read_bytes()).hexdigest()==proof['sha256']and s.st_nlink==1
  rows.append(dict(**proof,device=s.st_dev,inode=s.st_ino,links=1,allocatedBytes=s.st_blocks*512,aliases=[proof['path']]))
 print(json.dumps(dict(freshIdleLease=True,readOnly=True,freeBytes=shutil.disk_usage(base).free,retire=rows)))
