from pathlib import Path
import hashlib, json, re, subprocess, textwrap
r = Path(__file__).parent
test = Path('tests/Lokad.Lython.PublicApi.Tests/XmlSelectionTests.cs').read_text(encoding='utf-8')
rows = []
for match in re.finditer(r'yield return \["([^"]+)", """\r?\n(.*?)\r?\n\s+""", ("(?:[^"\\]|\\.)*")\];', test, re.S):
    name, body, literal = match.groups()
    source = textwrap.dedent(body)
    expected = json.loads(literal)
    done = subprocess.run(['C:/Python313/python.exe', '-I', '-S', '-X', 'utf8', '-c', source], capture_output=True, encoding='utf-8', timeout=10)
    assert done.returncode == 0 and not done.stderr, (name, done.stderr)
    assert done.stdout == expected, (name, done.stdout, expected)
    rows.append(dict(name=name, source=source, expectedOutput=expected, sourceSHA256=hashlib.sha256(source.encode()).hexdigest(), stdoutSHA256=hashlib.sha256(expected.encode()).hexdigest()))
assert len(rows) == 4
(r / 'python-goldens.json').write_text(json.dumps(dict(pythonVersion=subprocess.check_output(['C:/Python313/python.exe','--version'],text=True).strip(), isolated=True, allMatched=True, rows=rows), ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
print('Four exact public-test goldens independently pass isolated CPython3.13.2.', flush=True)
