from pathlib import Path
import ast
r=Path(__file__).parent
s=(r.parent/'xml-utf8-input-r328/b697-launch-template.py').read_text(encoding='utf-8')
s=s.replace("/ 'b697'","/ 'b699'").replace('lython-b697-fixtures','lython-b699-fixtures')
s=s.replace('shutil, subprocess, sys, tarfile','shutil, stat, subprocess, sys, tarfile')
s=s.replace("'run.sh','manifest-correction.json'","'run.sh'")
needle=" assert before>254*1024*1024+config['unpackedBytes']\n root.mkdir()"
replacement=""" assert before+sum(p['allocatedBytes']for p in config['retire'])>254*1024*1024+config['unpackedBytes']
 for old in config['retire']:
  p=base/old['path'];s=p.lstat()
  assert old['path']in['xml-utf8-input-b697-20261113/representative.json','final-slot-binding-b694-20261113/representative.json']
  assert p.resolve(strict=True)==p and p.is_relative_to(base)and stat.S_ISREG(s.st_mode)and s.st_uid==os.getuid()
  assert(s.st_dev,s.st_ino,s.st_nlink,s.st_size)==(old['device'],old['inode'],1,old['bytes'])and digest(p)==old['sha256']
 for old in config['retire']:(base/old['path']).unlink()
 root.mkdir()"""
assert needle in s;s=s.replace(needle,replacement).replace('retiredWorkingCopies=[]',"retiredWorkingCopies=config['retire']")
ast.parse(s);(r/'launch-confirmation.py').write_text(s,encoding='utf-8',newline='\n')
