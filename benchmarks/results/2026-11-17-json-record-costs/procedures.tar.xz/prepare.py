from pathlib import Path
import ast,hashlib,io,json,os,shutil,subprocess,tarfile
r=Path(__file__).parent;notes=r.parent;repo=Path('D:/code/Lython');old=notes/'private-construction-r480';retained=notes/'utf8-width-r483/refined';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
catalog=json.loads((notes/'generator-sum-r475/catalog.json').read_text(encoding='utf-8'));catalog['cases']=[next(c for c in catalog['cases']if c['id']=='scripts.json-summary-helpers.large')]
(r/'catalog.json').write_text(json.dumps(catalog,indent=2)+'\n',encoding='utf-8')
frozen=json.loads((retained/'frozen/identity.json').read_text(encoding='utf-8'));current=frozen['imageFiles']['candidate'];image=retained/'frozen/candidate';assert all(sha(image/n)==h for n,h in current.items())
dotnet=Path('C:/Users/JoannesVermorel/.dotnet11/dotnet.exe');env=os.environ.copy();env.update(DOTNET_ROOT=str(dotnet.parent),DOTNET_ROOT_X64=str(dotnet.parent));env['PATH']=str(dotnet.parent)+os.pathsep+env['PATH']
with(r/'actual-worker-preflight.log').open('w',encoding='utf-8')as log:p=subprocess.run([str(dotnet),str(image/'Lokad.Lython.Benchmarks.dll'),'--compare','verify','--catalog',str(r/'catalog.json'),'--dotnet',str(dotnet),'--python','C:/Python313/python.exe','--python-worker',str(repo/'benchmarks/cpython-worker.py'),'--out',str(r/'actual-worker-preflight.json')],env=env,stdout=log,stderr=subprocess.STDOUT)
assert p.returncode==0,(r/'actual-worker-preflight.log').read_text(encoding='utf-8')
prior=json.loads((retained/'cpython/quiet/config.json').read_text(encoding='utf-8'));remote='/home/lokad/lython-bench-checks/json-record-cost-b901-20261117'
identity=dict(sourceRevision='Committeddbdf8262/frozena95ff2a4; metadata32e68a69',purpose='R484 one complete JSON-lines helper aggregation attribution; identify a removable per-record/call stage, distinct from earlier numeric-array report. Source correction: spans are shared references; helpers already borrow/defer frames; mutable scalar slots must preserve aliases under mutation. No timing gain or removable-share forecast.',coreSHA256={'candidate':current['Lokad.Lython.dll']},auxiliaryFiles={n:h for n,h in current.items()if n!='Lokad.Lython.dll'},imageFiles={'candidate':current},catalogSHA256=sha(r/'catalog.json'),normalAdapterPin='0.4.0',publicationHeld=True)
(r/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8')
previous='/home/lokad/lython-bench-checks/private-text-costs-b894-20261117'
for name in ['ops-profile.py','collect.py','run.sh']:
 s=(old/name).read_text(encoding='utf-8').replace(previous,remote).replace("['text-original','text-helper']","['json-records']").replace("[('text-original','scripts.text-normalization.large','warm'),('text-helper','scripts.text-normalization.helper-list','warm')]","[('json-records','scripts.json-summary-helpers.large','warm')]").replace('Qualifiedd8611c85/frozen0315de0a; R480 current text private-construction attribution','Committeddbdf8262/frozena95ff2a4; R484 JSON-lines record attribution')
 (r/name).write_text(s,encoding='utf-8',newline='\n')
s=(old/'analyze.py').read_text(encoding='utf-8').replace("['text-original','text-helper']","['json-records']");(r/'analyze.py').write_text(s,encoding='utf-8',newline='\n')
groups=[]
canonical='benchmarks/results/2026-11-17-utf8-widths/refined/cpython/observations.tgz';blob=subprocess.check_output(['git','show','HEAD:'+canonical],cwd=repo);assert blob==(repo/canonical).read_bytes()
with tarfile.open(fileobj=io.BytesIO(blob))as a:data=a.extractfile('confirmation/confirmation.json').read()
for member,data in [('confirmation/confirmation.json',data),('whole-archive',blob)]:
 groups.append(dict(paths=['width-cpython-b900-20261117/'+('observations.tgz'if member=='whole-archive'else member)],bytes=len(data),links=1,sha256=hashlib.sha256(data).hexdigest(),canonical=canonical,canonicalSHA256=hashlib.sha256(blob).hexdigest(),member=member,committedBlobVerified=True))
stage=['ops-profile.py','collect.py','run.sh','identity.json','catalog.json']
with tarfile.open(r/'payload.tgz','w:gz')as a:
 for n in stage:a.add(r/n,arcname=n)
c=dict(root=remote,unit='lython-b901-json-record-cost-20261117',source=prior['root'],sourceRole='candidate',sourceFiles=current,sourceCatalogSHA256=prior['catalogSHA256'],catalogSHA256=identity['catalogSHA256'],identity=identity,retireGroups=groups,payloadBytes=(r/'payload.tgz').stat().st_size,payloadSHA256=sha(r/'payload.tgz'),unpackedBytes=sum((r/n).stat().st_size for n in stage))
(r/'config.json').write_text(json.dumps(c,indent=2)+'\n',encoding='utf-8')
s=(retained/'cpython/quiet/remote-launch.py').read_text(encoding='utf-8');a=s.index('c=');b=s.index('\nb=Path(',a);s=s[:a]+'c='+repr(c)+s[b:]
s=s.replace("os.link(source/'representative.json',root/'representative.json')","# Custom catalog passed verification with actual image before staging.").replace("root/'representative.json'","root/'catalog.json'").replace("for n in ['collect.py','archive-owned.py']:","for n in ['collect.py','ops-profile.py']:").replace('lython-b900-fixtures','lython-b901-fixtures')
(r/'remote-launch.py').write_text(s,encoding='utf-8',newline='\n')
s=(old/'launch.py').read_text(encoding='utf-8').replace('seconds=90','seconds=60').replace('Two-workload','One-workload').replace('before90seconds','before60seconds');(r/'launch.py').write_text(s,encoding='utf-8',newline='\n');shutil.copyfile(old/'retrieve.py',r/'retrieve.py')
for p in r.glob('*.py'):ast.parse(p.read_text(encoding='utf-8'))
print('One actual current-image JSON-lines golden passes; prepare one short attribution. No runtime edits or unchanged qualification; exact committed historical replicas only.')

