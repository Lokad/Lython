from pathlib import Path
import json,shutil,tarfile
r=Path(__file__).parent;repo=Path('D:/code/Lython');out=repo/'benchmarks/results/2026-11-17-json-record-costs';out.mkdir(exist_ok=False)
for name in ['attribution.json','identity.json','catalog.json','archive-receipt.json','terminal-status.json','observations.tgz','actual-worker-preflight.json']:shutil.copyfile(r/name,out/name)
with tarfile.open(out/'procedures.tar.xz','w:xz')as a:
 for p in r.glob('*'):
  if p.is_file()and p.suffix in{'.py','.json','.log','.sh'}:a.add(p,arcname=p.name)
(out/'README.md').write_text('''# JSON-lines helper aggregation attribution

R484/B901,2026-11-17UTC. Committeddbdf8262/frozena95ff2a4,
[fully qualified](../2026-11-17-utf8-widths/refined/delivery/README.md).
One existing complete JSON-lines helper script through the actual verified worker;
no production edit or new timing comparison. Public fresh/warm boundaries remain
those of the comparison harness; this capture measures warm runtime attribution.

986 active execution-thread samples,60unknown leaves. Nearest mapped Lython frames:
ordinary prefix141, JSON string reader52, construction52, ordinary call43,
stack transfer36, native selection34, dictionary accumulation33, iteration30,
managed stack admission29, container push24. JSON inclusive293/986 overlaps useful
parsing; neither these counts nor dispatch/call overlap is a removable percentage.
4.999guest seconds/4.96active-threadCPU; wider threads/raw stacks preserved.

Source corrections: diagnostic spans are shared references; no large value-span
copy exists to remove. JSON record layouts already persist in ExecutionState
across loads calls. Default option binding is already bypassed; scalar conversion
is synchronous before actual hooks suspend. Mutable native list slots require
stable identity across item withdrawal/mutation and displace direct owned-array
adoption; immutable tuple borrowing alone is insufficient. No duplicate layout
cache, span table, ownership ledger or broad container redesign is introduced.

The general callable boundary still packages completed executable operands into
CallArgumentValue entries, even for an ordinary positional module call. A borrowed
argument representation could remove that complete preparation stage and large
positional packet allocations. It must replace the current borrowed binding input,
not add another public dispatch API; preserve dynamic keyword/star/constructor
ownership, canonical arguments, error/effect order, actual suspension without
retained stack borrows, cancellation and terminal refusal. View transport and
materialization costs are hypotheses requiring a controlled source pair. Existing
call-arena/control/caller-window regressions remain relevant; no speedup forecast.

One8second warmup/2second settle/5second capture,199Hz perf cpu-clock/frame pointers
on quiet AzureF4as_v7/Ubuntu24.04.4/.NET11RC3, diagnostic PerfMap only, normalGC/
tiering. All actual-image/golden/quiet/Closed/exit/join checks pass. Every RAM trace
SHAverified persistently under lease before unmount. Root-owned perf data receives
verified ownership correction without changed bytes after joining. Exact committed
B900raw/archive working replicas retire after fresh path/UID/hash/link/all-alias
proof; current images/toolchains/canonicals and254/252MiB floors preserved.
Terminal cached; no repeat capture. Publication held; broader work continues.

[Full attribution](attribution.json),[raw](observations.tgz),[catalog](catalog.json),
[identity](identity.json),[custody](archive-receipt.json),[procedures](procedures.tar.xz).
''',encoding='utf-8',newline='\n')
p=repo/'benchmarks/EXPERIMENTS.md';s=p.read_text(encoding='utf-8');s+='\nR484/B901: [complete JSON-lines helper attribution](results/2026-11-17-json-record-costs/README.md), qualifieddbdf8262/a95ff2a4,986samples/60unknown,4.999guestseconds/4.96CPU. Existing cross-load record keys/default binding bypass confirmed; spans are shared references, mutable slots need alias/mutation semantics. General positional calls still package completed operands. Select a bounded borrowed-binding representation assessment preserving dynamic owned packets, cancellation/refusal/suspension; no gain forecast or new ownership framework. All gates/join/SHAarchive-before-unmount pass, no repeated qualification/publication.\n';p.write_text(s,encoding='utf-8',newline='\n')
p=repo/'docs/BENCHMARKS.md';s=p.read_text(encoding='utf-8').replace('with full runtime qualification pending.','[fully qualified](../benchmarks/results/2026-11-17-utf8-widths/refined/delivery/README.md).');p.write_text(s,encoding='utf-8',newline='\n')
p=repo/'benchmarks/results/2026-11-17-utf8-widths/refined/cpython/README.md';s=p.read_text(encoding='utf-8').replace('Full runtime delivery44080812207 is pending independently.','[Full runtime delivery44080812207 passes](../delivery/README.md) independently.');p.write_text(s,encoding='utf-8',newline='\n')
p=repo/'PLAN.md';s=p.read_text(encoding='utf-8').replace('| Committed, qualification pending | Bulk UTF-8 scalar/UTF16 widths (dbdf8262), current frozena95ff2a4; focused actual11/10 pass, full44080812207 pending.','| Committed and fully qualified | Bulk UTF-8 scalar/UTF16 widths (dbdf8262), current frozena95ff2a4; focused actual11/10 pass, full44080812207 GREEN/cached.').replace('no sooner\nthan12:20:52UTC after the12:16:52UTC observation (both platforms in ordinary\n.NET11tests), then≥240s apart; cache terminal/logs once.','no further: terminal/logs cached permanently; never requery44080812207.');s=s.replace('Read-only sibling 64bdf06a removes backend routes in three PythonRe files; it adds\nnone of the missing facade APIs.','Read-only sibling fe67e13f additionally unifies boundary literal routes and fixes\nsuffix endpoints. Its facade still lacks the specific APIs below; no new adapter\npin or repeated qualification is justified by these unrelated source changes.');s=s.replace('Next R484: resume complete call/frame/operand and per-record design selection','R484 current JSON-lines capture complete986samples/60unknown; JSON293 inclusive,\nordinary prefix141/call43 nearest, all overlapping useful work. Spans are shared\nreferences; JSON key layouts already persist across loads. Do not add duplicate\nspan/layout caches. [Source/evidence](benchmarks/results/2026-11-17-json-record-costs/README.md).\n\nNext R485: prototype one borrowed argument view for the general callable/binder\ninput, directly reading already-funded executable positional operands. Replace\nReadOnlySpan<CallArgumentValue> borrowed inputs and remove positional packet\npreparation/materialization from normal public calls. Retain packets only for\nreal keyword/star/constructor and pending owned users; admit substantial copies\nbefore allocation and keep funding through cleanup. No new public API/policy,\ncall arena, side table, frame controller or optional fast mode. A wider view may\ncost CPU; that is a hypothesis, not a predicted gain. Preserve bound methods,\ndefaults/keywords/partial/type calls, alias identity/effect/error order, actual\nsuspension with no stack borrow retained, cancellation/first refusal and cleanup.\nFocused Release semantics/ownership/cancellation, actual worker goldens; one short\nJSON-lines/helper/text/report pair with native-call controls. Remove displaced\nborrowed input signatures/copy stage in any retained milestone; otherwise remove\nthe prototype and preserve its evidence. Close with a retention/regression-debt\ndecision, not another unchanged campaign. Full delivery only if retained.\n\nContinue complete call/frame/operand and per-record design selection');p.write_text(s,encoding='utf-8',newline='\n')
print('R483 full delivery and R484 one-workload attribution preserved; precise source corrections and R485 hypothesis/acceptance recorded.')

