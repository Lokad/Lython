from pathlib import Path
import base64
import hashlib
import json
import os
import shutil
import subprocess
import tempfile

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
previous = lab.with_name("regex-050-current-allocation-20261125")
source = lab.with_name("regex-050-artifact-20261125")
quiet = lab / "comparison/quiet"
quiet.mkdir(parents=True, exist_ok=True)
sha = lambda payload: hashlib.sha256(payload).hexdigest()
digest = lambda file: sha(file.read_bytes())
read = lambda file: json.loads(file.read_text(encoding="utf-8-sig"))
save = lambda file, value: file.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8", newline="\n")

prior = read(previous / "comparison/quiet/identity.json")
assert prior["producerSource"].startswith("6edc01772") and prior["lythonSource"].startswith("c1984f96b")
adapter = "Lokad.Lython.Utf8Regex.dll"
base = previous / "candidate"
assert {p.name: digest(p) for p in base.iterdir()} == prior["images"]["candidate"]
candidate_folder = lab / "windows/bin/Lokad.Lython.PublicApi.Tests/release_net11.0"
for name in ("Lokad.Utf8Regex.dll", "Lokad.Utf8Regex.PythonRe.dll"):
    assert digest(candidate_folder / name) == prior["images"]["candidate"][name]
images = {
    "reference": prior["images"]["candidate"],
    "candidate": prior["images"]["candidate"] | {adapter: digest(candidate_folder / adapter)},
}
assert images["reference"][adapter] != images["candidate"][adapter]
catalog = read(previous / "comparison/quiet/representative.json")
python = Path("C:/Python313/python.exe")
kept = [row for row in catalog["cases"] if row["id"] in (
    "scripts.regex-log-search.compiled", "scripts.csv-invoice.method-policy.quoted-control")]
for case in catalog["cases"]:
    if case["id"] not in ("scripts.regex-log-search.compiled", "scripts.regex-log-search.module"):
        continue
    text = case["source"].replace("([A-Z]{2}[0-9]+)", "[A-Z]{2}[0-9]+").replace("match.group(1)", "match.group(0)")
    assert text != case["source"] and "group(1)" not in text
    with tempfile.TemporaryDirectory(prefix="lython-regex-golden-") as path:
        data = json.loads(case["fixtureJson"])
        assert list(data["inputFiles"]) == ["events.log"]
        (Path(path) / "events.log").write_bytes(base64.b64decode(data["inputFiles"]["events.log"]))
        output = subprocess.check_output([python, "-I", "-X", "utf8", "-c", text], cwd=path, encoding="utf-8")
    hash_text = lambda s: sha(s.encode("utf-8"))
    kept.append(case | dict(id=case["id"] + ".whole-match", source=text, sourceSha256=hash_text(text),
        sourceUtf8Bytes=len(text.encode("utf-8")), expectedOutput=output, expectedOutputSha256=hash_text(output),
        expectedOutputUtf8Bytes=len(output.encode("utf-8"))))
catalog["cases"] = kept
assert len(kept) == 4
filename = quiet / "representative.json"
save(filename, catalog)
identity = dict(lythonSource=prior["lythonSource"], producerSource=prior["producerSource"],
                images=images, catalogSHA256=digest(filename), producerVersion="0.5.0-dev.lython.6edc01772")
save(quiet / "identity.json", identity)
sdk = Path.home() / ".dotnet11"
dotnet = sdk / "dotnet.exe"
env = dict(os.environ, DOTNET_ROOT=str(sdk), DOTNET_ROOT_X64=str(sdk))
for engine, hashes in images.items():
    path = lab / engine
    path.mkdir(exist_ok=True)
    for name, expected in hashes.items():
        origin = candidate_folder if engine == "candidate" and name == adapter else base
        shutil.copyfile(origin / name, path / name)
        assert digest(path / name) == expected
    evidence = quiet / f"{engine}-verify.json"
    subprocess.run([dotnet, path / "Lokad.Lython.Benchmarks.dll", "--compare", "verify",
                    "--catalog", filename, "--dotnet", dotnet, "--python", python,
                    "--python-worker", repo / "benchmarks/cpython-worker.py", "--out", evidence],
                   cwd=repo, env=env, check=True, timeout=60)
    report = read(evidence)
    assert report["state"] == "Completed" and report["caseCount"] == len(kept)
    assert report["catalogSha256"] == identity["catalogSHA256"]
    assert report["launched"]["library"]["sha256"] == hashes["Lokad.Lython.dll"]
print("Both adapter builds match the four independent goldens.")
