from pathlib import Path
import hashlib,json,os,shutil,subprocess
lab=Path(__file__).parent; repo=lab.parents[3]
base=lab.with_name('retained-defaults-cpython-20261125'); bridge=lab.with_name('regex-050-artifact-20261125')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
read=lambda p:json.loads(p.read_text(encoding='utf-8'))
identity=read(base/'external/identity.json'); before=identity['imageFiles']['candidate'];assert len(before)==32 and {p.name:sha(p)for p in (base/'candidate').iterdir()}==before
proof=read(repo/'benchmarks/results/2026-11-25-regex-050-artifact-replay/verification.json'); producer=proof['development']; assert producer['producerRevision'].startswith('6edc01772')
preview=bridge/'windows-dev/bin/Lokad.Lython.PublicApi.Tests/release_net11.0'
parts=['Lokad.Lython.Utf8Regex.dll','Lokad.Utf8Regex.dll','Lokad.Utf8Regex.PythonRe.dll']
for name in parts[1:]:
    package=next(record for filename,record in producer['packages'].items() if filename.split('.0.5.0')[0]+'.dll'==name)
    assert sha(preview/name)==package['assemblies']['net11.0']
assert sha(bridge/'development.patch')==proof['developmentPatchSHA256']
files={'reference':before,'candidate':before|{name:sha(preview/name)for name in parts}}
source=lab.with_name('regex-wrapper-cache-20261124')/'comparison/representative.json'
catalog=read(source);assert all('id' in row for row in catalog['cases'])
quiet=lab/'comparison/quiet';quiet.mkdir(parents=True,exist_ok=True)
shutil.copyfile(source,quiet/'representative.json')
local=dict(lythonSource=identity['sourceRevision'],developerAdapterSource=producer['coreRevision'],producerSource=producer['producerRevision'],bridgePatchSHA256=proof['developmentPatchSHA256'],images=files,catalogSHA256=sha(source))
(quiet/'identity.json').write_text(json.dumps(local,indent=2)+'\n',encoding='utf-8',newline='\n')
sdk=Path.home()/'.dotnet11';dotnet=sdk/'dotnet.exe';env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk))
protocol=repo/'benchmarks/cpython-worker.py';assert sha(protocol)==identity['cpythonWorkerSHA256']
for role,expected in files.items():
    location=lab/role;location.mkdir(exist_ok=True)
    for name in expected:shutil.copyfile((preview if role=='candidate' and name in parts else base/'candidate')/name,location/name)
    assert {p.name:sha(p)for p in location.iterdir()}==expected
    verify=quiet/f'{role}-verify.json'
    subprocess.run([dotnet,location/'Lokad.Lython.Benchmarks.dll','--compare','verify','--catalog',quiet/'representative.json',
        '--dotnet',dotnet,'--python','C:/Python313/python.exe','--python-worker',protocol,'--out',verify],env=env,check=True,timeout=60)
    status=read(verify);assert status['state']=='Completed' and status['caseCount']==len(catalog['cases']) and status['catalogSha256']==sha(source) and status['launched']['library']['sha256']==expected['Lokad.Lython.dll']
    print(role,'matching verified cases',status['caseCount'])
print([row['id']for row in catalog['cases']])
