from pathlib import Path
import hashlib
import json
import shutil
import tarfile

lab = Path(__file__).resolve().parent
prior = lab.with_name("compiled-entry-20261125")
donor = lab.with_name("closed-iteration-call-20261125") / "comparison/quiet"
quiet = lab / "comparison/quiet"
read = lambda path: json.loads(path.read_text(encoding="utf-8-sig"))
digest = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
save = lambda path, data: path.write_text(json.dumps(data, ensure_ascii=False, indent=2)+"\n", encoding="utf-8", newline="\n")
write = lambda path, source: path.write_text(source, encoding="utf-8", newline="\n")
sources = read(quiet/"identity.json")
base = read(donor/"identity.json")
receipt = read(donor/"terminal-status.json")["receipt"]
assert receipt["complete"] and receipt["quietBeforeAndAfter"] and digest(donor/"observations.tar.xz")==receipt["archiveSHA256"]
assert sources["catalogSHA256"]==digest(quiet/"representative.json")
for role, files in sources["images"].items():
    verify=read(quiet/(role+"-verify.json"))
    assert verify["state"]=="Completed" and verify["caseCount"]==6
    assert verify["catalogSha256"]==sources["catalogSHA256"]
    assert verify["launched"]["library"]["sha256"]==files["Lokad.Lython.dll"]
    assert {p.name:digest(p) for p in (lab/role).iterdir()}==files
    assert files["Lokad.Lython.dll"]==base["imageFiles"]["reference"]["Lokad.Lython.dll"]
jobs = [
    ["scripts.regex-log-search.compiled", "warm"],
    ["scripts.regex-log-search.bound", "warm"],
    ["scripts.csv-invoice.method-policy.quoted-control", "warm"],
    ["scripts.regex-log-search.module", "warm"],
    ["scripts.regex-log-search.compiled.whole-match", "warm"],
    ["scripts.regex-log-search.compiled.two-groups", "warm"],
]
save(quiet/"jobs.json",dict(warm=jobs))
source_files = ["representative.json", "jobs.json"]
identity = dict(
    sourceRevision=sources["lythonSource"], comparisonRevision=sources["lythonSource"],
    purpose="Use direct group-zero and single-group matching on one funded development producer",
    sourcePatchSHA256=digest(lab/"development.patch"), producer=sources["producerSource"],
    producerVersion=sources["producerVersion"], imageFiles=sources["images"],
    coreSHA256={role+suffix:files["Lokad.Lython.dll"] for role, files in sources["images"].items() for suffix in ("","-control")},
    catalogs={n:dict(sha256=digest(quiet/n)) for n in source_files},
    cpythonWorkerSHA256=base["cpythonWorkerSHA256"], expectedCPythonSHA256=base["expectedCPythonSHA256"])
save(quiet/"timing-identity.json",identity)
script_template = prior/"comparison/focused-compile"
shutil.copyfile(script_template/"run.sh",quiet/"run.sh")
assert b"\r" not in (quiet/"run.sh").read_bytes()
collect=(script_template/"collect.py").read_text(encoding="utf-8")
collect=collect.replace("len(jobs) == 8","len(jobs) == 6").replace(" < 394,"," < 315,").replace("b1689-fixtures","b1691-fixtures")
assert "len(jobs) == 6" in collect
compile(collect,"collect.py","exec")
write(quiet/"collect.py",collect)
payload=quiet/"payload.tar.gz"
payload_src={}
deltas={}
for role, files in identity["imageFiles"].items():
    delta={}
    for name, sha in files.items():
        if sha==base["imageFiles"]["reference"][name]: continue
        key=sha[:12]+"-"+name
        delta[name]=key
        payload_src.setdefault(key,lab/role/name)
    deltas[role]=delta
assert len(payload_src)==4
with tarfile.open(payload,"w:gz",compresslevel=3) as archive:
    for name in source_files+["run.sh","collect.py"]:
        archive.add(quiet/name,arcname=name)
    archive.add(quiet/"timing-identity.json",arcname="identity.json")
    for name,path in payload_src.items():
        archive.add(path,arcname=name)
save(quiet/"upload.json",dict(root="regex-single-group-b1691-20261125",reference="closed-iteration-call-b1687-20261125",
    payloadFiles=sorted(payload_src), deltaFiles=deltas, payloadSHA256=digest(payload), payloadBytes=payload.stat().st_size))
save(lab/"verified-raw-replicas.json",[])
launch=(prior/"quiet.py").read_text(encoding="utf-8")
launch=launch.replace('quiet=lab/"comparison/focused-compile"', 'quiet=lab/"comparison/quiet"')
launch=launch.replace("b1689","b1691").replace("lython-b1691-compiled-entry","lython-b1691-regex-single-group")
launch=launch.replace("seconds=352","seconds=274").replace("RuntimeMaxSec=415","RuntimeMaxSec=331")
launch=launch.replace("'collect.py','candidate-core.dll'}","'collect.py'}|set(configuration['payloadFiles'])")
old = """   if name=='Lokad.Lython.dll' and role=='candidate':
    (root/(role+'-core.dll')).rename(image/name)
   else:
    os.link(reference/'candidate'/name,image/name)
   assert digest(image/name)==sha,(role,name)
"""
new = """   staged = configuration['deltaFiles'][role].get(name)
   if staged:
    os.link(root/staged,image/name)
   else:
    os.link(reference/'reference'/name,image/name)
   assert digest(image/name)==sha,(role,name)
 for staging in configuration['payloadFiles']:
  (root/staging).unlink()
"""
assert old in launch
launch=launch.replace(old,new)
compile(launch,"quiet.py","exec")
write(lab/"quiet.py",launch)
report=(prior/"archive.py").read_text(encoding="utf-8")
report=report.replace('quiet=lab/"comparison/focused-compile"','quiet=lab/"comparison/quiet"')
report=report.replace("2026-11-25-compiled-entry","2026-11-25-regex-050-artifact-replay/single-group")
report=report.replace('staged==read(quiet/"identity.json")','staged==read(quiet/"timing-identity.json")')
report=report.replace("==8","==6").replace("timedBatches=224,lanes=8","timedBatches=168,lanes=6")
report=report.replace('out/"quiet-summary.json"','out/"quiet-summary.json"')
compile(report,"archive.py","exec")
write(lab/"archive.py",report)
print(f"Verified two unchanged core images and six lanes. Four delta DLLs total {sum(p.stat().st_size for p in payload_src.values())} B.")
