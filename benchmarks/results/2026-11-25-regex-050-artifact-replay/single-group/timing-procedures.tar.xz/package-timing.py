from pathlib import Path
import hashlib
import json
import shutil
import tarfile

lab=Path(__file__).resolve().parent
out=lab.parents[3]/"benchmarks/results/2026-11-25-regex-050-artifact-replay/single-group"
quiet=lab/"comparison/quiet"
identity=json.loads((quiet/"timing-identity.json").read_text(encoding="utf-8"))
digest=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert digest(lab/"development.patch")==identity["sourcePatchSHA256"]
assert all({p.name:digest(p) for p in (lab/role).iterdir()}==files for role,files in identity["imageFiles"].items())
shutil.copyfile(quiet/"timing-identity.json",out/"timing-identity.json")
files=["prepare-quiet.py","quiet.py","archive.py","package-timing.py","comparison/quiet/reference-verify.json",
       "comparison/quiet/candidate-verify.json","comparison/quiet/upload.json","comparison/quiet/storage-custody.json",
       "comparison/quiet/launch.log"]
with tarfile.open(out/"timing-procedures.tar.xz","w:xz") as archive:
    for name in files:
        archive.add(lab/name,arcname=name,recursive=False)
with tarfile.open(out/"timing-procedures.tar.xz") as archive:
    assert archive.getnames()==files
    assert all(hashlib.sha256(archive.extractfile(name).read()).hexdigest()==digest(lab/name) for name in files)
