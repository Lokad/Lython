set -eu
repo="$PWD"
lab="$repo/.git/agent-notes/review-20261031/regex-single-group-20261125"
cd "$repo/.git/agent-worktrees/regex-single-group-20261125"
export DOTNET_ROOT="$HOME/.dotnet"
export PATH="$DOTNET_ROOT:$PATH"
export NUGET_PACKAGES="$lab/../regex-050-artifact-20261125/nuget-linux"
suite=tests/Lokad.Lython.PublicApi.Tests/Lokad.Lython.PublicApi.Tests.csproj
if ! dotnet restore "$suite" --locked-mode --artifacts-path "$lab/ubuntu" --configfile "$lab/NuGet.Candidate.Ubuntu.Config" > "$lab/ubuntu-dev-restore.log" 2>&1; then
    tail -35 "$lab/ubuntu-dev-restore.log"
    exit 1
fi
log="$lab/ubuntu-dev-net10.log"
if ! dotnet test "$suite" --no-restore -c Release -f net10.0 --artifacts-path "$lab/ubuntu" --filter "FullyQualifiedName~Regex&Category!=Stress" > "$log" 2>&1; then
    tail -65 "$log"
    exit 1
fi
tail -4 "$log"
