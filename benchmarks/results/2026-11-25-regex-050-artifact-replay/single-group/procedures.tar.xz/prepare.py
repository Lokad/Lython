from pathlib import Path
import base64
import hashlib
import json
import os
import shutil
import subprocess
import tempfile

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
prior = lab.with_name("regex-050-value-match-20261125")
original = lab.with_name("regex-050-current-allocation-20261125")
quiet = lab / "comparison/quiet"
quiet.mkdir(parents=True, exist_ok=True)
read = lambda p: json.loads(p.read_text(encoding="utf-8-sig"))
digest = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
hash_text = lambda text: hashlib.sha256(text.encode("utf-8")).hexdigest()
save = lambda p, value: p.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n",
                                     encoding="utf-8", newline="\n")

identity = read(prior / "comparison/quiet/identity.json")
adapter = "Lokad.Lython.Utf8Regex.dll"
base = prior / "candidate"
old = identity["images"]["candidate"]
assert {p.name: digest(p) for p in base.iterdir()} == old
building = lab / "windows/bin/Lokad.Lython.PublicApi.Tests/release_net11.0"
for name in ("Lokad.Utf8Regex.dll", "Lokad.Utf8Regex.PythonRe.dll"):
    assert digest(building / name) == old[name]
images = {"reference": old, "candidate": old | {adapter: digest(building / adapter)}}
assert images["candidate"][adapter] != old[adapter]
catalog = read(original / "comparison/quiet/representative.json")
previous_cases = read(prior / "comparison/quiet/representative.json")["cases"]
cases = list(catalog["cases"])
assert len(cases) == 4, [case["id"] for case in cases]
compiled = next(case for case in cases if case["id"] == "scripts.regex-log-search.compiled")
cases.append(next(case for case in previous_cases if case["id"] == "scripts.regex-log-search.compiled.whole-match"))
expression = "([A-Z]{2}[0-9]+)"
assert expression in compiled["source"]
source = compiled["source"].replace(expression, "(" + expression + ")")
python = Path("C:/Python313/python.exe")
with tempfile.TemporaryDirectory(prefix="lython-regex-golden-") as folder:
    data = json.loads(compiled["fixtureJson"])
    assert list(data["inputFiles"]) == ["events.log"]
    (Path(folder) / "events.log").write_bytes(base64.b64decode(data["inputFiles"]["events.log"]))
    output = subprocess.check_output([python, "-I", "-X", "utf8", "-c", source], cwd=folder, encoding="utf-8")
assert output == compiled["expectedOutput"]
cases.append(compiled | dict(id=compiled["id"] + ".two-groups", source=source, sourceSha256=hash_text(source),
                             sourceUtf8Bytes=len(source.encode("utf-8"))))
catalog["cases"] = cases
catalog_path = quiet / "representative.json"
save(catalog_path, catalog)
identity = identity | dict(images=images, catalogSHA256=digest(catalog_path))
save(quiet / "identity.json", identity)

sdk = Path.home() / ".dotnet11"
dotnet = sdk / "dotnet.exe"
env = dict(os.environ, DOTNET_ROOT=str(sdk), DOTNET_ROOT_X64=str(sdk))
for role, files in images.items():
    folder = lab / role
    folder.mkdir(exist_ok=True)
    for name, expected in files.items():
        shutil.copyfile((building if role == "candidate" and name == adapter else base) / name, folder / name)
        assert digest(folder / name) == expected
    proof = quiet / (role + "-verify.json")
    subprocess.run([dotnet, folder / "Lokad.Lython.Benchmarks.dll", "--compare", "verify", "--catalog", catalog_path,
                    "--dotnet", dotnet, "--python", python, "--python-worker", repo / "benchmarks/cpython-worker.py",
                    "--out", proof], cwd=repo, env=env, check=True, timeout=65)
    checked = read(proof)
    assert checked["state"] == "Completed" and checked["caseCount"] == 6
    assert checked["catalogSha256"] == identity["catalogSHA256"]
    assert checked["launched"]["library"]["sha256"] == files["Lokad.Lython.dll"]
print("Both optional adapter images match six CPython goldens.")
