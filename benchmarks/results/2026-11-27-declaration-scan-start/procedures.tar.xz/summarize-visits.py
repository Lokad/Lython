from pathlib import Path
import json
lab=Path(__file__).resolve().parent
data=json.loads((lab/'parity/reference/facts.json').read_text(encoding='utf-8'))
declarations={'ExecutableCreateFunction', 'ExecutableCreateClass', 'ExecutableCreateGeneratorExpression', 'ExecutableBindTypeAlias'}
rows=[]
for item in data:
    skipped=[]
    for code in item['tape']:
        constants=code['constants']
        prefix=next((i for i,value in enumerate(constants) if value in declarations),len(constants))
        skipped.append((len(constants),prefix))
    rows.append(dict(case=item['id'], entriesBefore=sum(before for before,skip in skipped),
        skippedEntries=sum(skip for before,skip in skipped),
        skippedNonemptyWalks=sum(before==skip and before>0 for before,skip in skipped)))
path=lab/'parity/visit-counts.json'
path.write_text(json.dumps(rows,indent=2)+'\n',encoding='utf-8')
print(path.read_text(encoding='utf-8'))