from hashlib import sha256
from pathlib import Path
import json
import shutil
import subprocess

lab = Path(__file__).resolve().parent
run = lab/'local'
probe = lab/'probe/bin/Release/net11.0'
read = lambda p: json.loads(p.read_text(encoding='utf-8-sig'))
digest = lambda p: sha256(p.read_bytes()).hexdigest()
identity = read(run/'identity.json')
for role in ('reference','candidate'):
    image = run/role
    assert {p.name:digest(p) for p in image.iterdir()} == identity['imageFiles'][role]
    target = lab/'parity'/role
    target.mkdir(parents=True)
    for name in ('CompilerFacts.dll','CompilerFacts.runtimeconfig.json','CompilerFacts.deps.json'):
        shutil.copyfile(probe/name,target/name)
    shutil.copyfile(image/'Lokad.Lython.dll',target/'Lokad.Lython.dll')
    command = [Path.home()/'.dotnet11/dotnet.exe', target/'CompilerFacts.dll', run/'representative.json', target/'facts.json']
    limits = lab/'parity/limits.json'
    if role == 'candidate':
        command.append(limits)
    subprocess.run(command,check=True,timeout=60)
    if role == 'reference':
        facts=read(target/'facts.json')
        limits.write_text(json.dumps({x['id']: x['testLimits'] for x in facts}),encoding='utf-8')
rows=[]
for left,right in zip(read(lab/'parity/reference/facts.json'),read(lab/'parity/candidate/facts.json'),strict=True):
    assert left['id']==right['id'] and left['tape']==right['tape']
    assert left['testLimits']==right['testLimits']
    rows.append(dict(case=left['id'], codeObjects=len(left['tape']), instructions=sum(len(t['steps']) for t in left['tape']),
                     machineTableEntries=sum(sum(value is not None for value in (t['machine'] or [])) for t in left['tape']),
                     peak=[t['peak'] for t in (left,right)], sameAdmissionOrder=left['growth']==right['growth'],
                     pressureTests=len(left['testLimits']), sameFirstRefusal=left['refusals']==right['refusals'],
                     differingRefusals=[dict(reference=l,candidate=r) for l,r in zip(left['refusals'],right['refusals']) if l!=r]))
summary=lab/'parity/summary.json'
summary.write_text(json.dumps(rows,indent=2)+'\n',encoding='utf-8',newline='\n')
print(summary.read_text(encoding='utf-8'))