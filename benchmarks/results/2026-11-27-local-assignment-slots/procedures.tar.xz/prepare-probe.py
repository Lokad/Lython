from pathlib import Path

lab = Path(__file__).resolve().parent
prior = lab.parent / "executable-positional-forms-20261127"
target = lab / "probe"
target.mkdir()
project = (prior / "probe/CompilerFacts.csproj").read_text(encoding="utf-8").replace(
    "../comparison/local/reference/", "../comparison/reference/")
(target / "CompilerFacts.csproj").write_text(project, encoding="utf-8", newline="\n")
source = (prior / "probe/Program.cs").read_text(encoding="utf-8")
check = r"""
var diagnosticSources = new Dictionary<string, string>
{
    ["branch-order"] = "def route(flag):\n if flag:\n  value=1\n else:\n  return value\n return value\n",
    ["deleted-binding"] = "def clean(value):\n del value\n return value\n",
    ["handler-exit"] = "def recover():\n try:\n  print('body')\n except ValueError as caught:\n  print(caught)\n return caught\n",
    ["lambda-nested-default"] = "def outer():\n def f(default=lambda: before + (before := 2)): pass\n return f\n",
    ["postponed-annotation"] = "from __future__ import annotations\ndef f(arg: (lambda: before + (before := 2))): pass\n",
    ["comprehension-exit"] = "def collect(values):\n print([late for late in values])\n return late\n late = 4\n",
    ["nested-nonlocal"] = "def owner():\n def bind():\n  nonlocal value\n  value = 2\n bind()\n return value\n value = 3\n",
    ["class-nonlocal"] = "def owner():\n class Bind:\n  nonlocal seed\n  seed = 42\n return seed\n seed = 0\n",
    ["large-scope"] = "def many():\n" + string.Concat(Enumerable.Range(0, 144).Select(n => $" local_{n} = {n}\n")) +
        " del local_140\n return local_140\n",
};
var diagnosticsEngine = new LythonEngine();
var diagnostics = diagnosticSources.Select(pair =>
{
    var account = new TracingBudget(null);
    return WithBudget(diagnosticsEngine, pair.Value, account, script => new
    {
        id = pair.Key, script.IsValid, account.Peak, account.Refused,
        diagnostics = script.Diagnostics.Select(item => new { item.Code, item.Span, item.Message, item.Severity }).ToArray(),
    });
}).ToArray();
File.WriteAllText(Path.Combine(Path.GetDirectoryName(args[1])!, "diagnostics.json"), JsonSerializer.Serialize(diagnostics));
"""
idx = source.index("static T WithBudget<T>")
source = source[:idx] + check + "\n" + source[idx:]
(target / "Program.cs").write_text(source, encoding="utf-8", newline="\n")
probe = (prior / "compile-parity.py").read_text(encoding="utf-8")
probe = probe.replace("run = lab / 'comparison/local'", "run = lab / 'comparison'")
lo = probe.index("    positionalRemoved")
hi = probe.index("write(run / 'compiler-parity.json'", lo)
probe = probe[:lo] + """    assert left['tape']==right['tape'], left['id']
    summary.append(dict(id=left['id'], scopes=len(left['tape']), budgetLevels=len(left['testLimits']),
                        compileClr=[median(left['allocated']),median(right['allocated'])],compiledPeak=left['peak']))
diagnostics = read(run / 'probe-reference/diagnostics.json')
assert diagnostics == read(run / 'probe-candidate/diagnostics.json') and len(diagnostics) == 9
assert sum(not row['isValid'] for row in diagnostics) >= 6
""" + probe[hi:]
probe = probe.replace("dict(cases=summary, cancellation=reference_cancel)", "dict(cases=summary, cancellation=reference_cancel, diagnostics=diagnostics)")
compile(probe, "check-compiler.py", "exec")
(lab / "check-compiler.py").write_text(probe, encoding="utf-8", newline="\n")
