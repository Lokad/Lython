from pathlib import Path
import re

path = Path("src/Lokad.Lython/Frontend/StaticNameBindingDiagnostics.cs")
source = path.read_text(encoding="utf-8")
assert source.count("private sealed class AssignmentFacts(") == 1
def change(old, new):
    global source
    assert source.count(old) == 1, old
    source = source.replace(old, new)

lo = source.index("        var localNames = scopeFacts.LocalNames;")
hi = source.index("\n    }", lo)
source = source[:lo] + """        var maybeAssigned = new AssignmentFacts(scopeFacts.PreparedLocalSlots.RequireNotNull(),
            scopeFacts.NestedNonlocalNames, functionDefinition.Parameters, context);
        AnalyzeStatements(functionDefinition.Body, context, maybeAssigned);""" + source[hi:]
change("""                var lambdaLocalNames = ScopeDirectiveFactsCollector.CollectLambdaLocalNames(lambda);
                var lambdaAssigned = new AssignmentFacts(lambda.Parameters.Select(static parameter => parameter.Name), context);
                AnalyzeExpression(lambda.Body, context, lambdaLocalNames, lambdaAssigned);""",
       """                AnalyzeExpression(lambda.Body, context, CreateLambdaFacts(lambda, context));""")
change("""            var localNames = ScopeDirectiveFactsCollector.CollectLambdaLocalNames(lambda);
            var maybeAssigned = new AssignmentFacts(lambda.Parameters.Select(static parameter => parameter.Name), context);
            AnalyzeExpression(lambda.Body, context, localNames, maybeAssigned);""",
       """            AnalyzeExpression(lambda.Body, context, CreateLambdaFacts(lambda, context));""")
change("                    if (localNames.Contains(nonlocalName)) maybeAssigned.Add(nonlocalName);",
       "                    maybeAssigned.Add(nonlocalName);")
change("if (localNames.Contains(name) && !maybeAssigned.Contains(name))",
       "if (maybeAssigned.IsUnassignedLocal(name))")
source = source.replace("        IReadOnlyCollection<string> localNames,\n", "")
source = source.replace("IReadOnlyCollection<string> localNames, ", "")
source = source.replace("StaticAnalysisContext context, IReadOnlyCollection<string> localNames,", "StaticAnalysisContext context,")
source = source.replace(", localNames,", ",").replace(", state.localNames,", ",")
assert not re.search(r"\blocalNames\b", source)
anchor = "    private static bool IsMatchCaseGuard"
idx = source.index(anchor)
source = source[:idx] + """    private static AssignmentFacts CreateLambdaFacts(LambdaExpressionSyntax lambda, StaticAnalysisContext context)
    {
        if (lambda.PreparedScopeFacts?.PreparedLocalSlots is { } slots)
            return new AssignmentFacts(slots, null, lambda.Parameters, context);

        // A postponed annotation can still be checked even if lexical
        // preparation skipped its expressions.
        var localSlots = new Dictionary<string, int>(StringComparer.Ordinal);
        foreach (var name in ScopeDirectiveFactsCollector.CollectLambdaLocalNames(lambda))
            localSlots.Add(name, localSlots.Count);
        return new AssignmentFacts(localSlots, null, lambda.Parameters, context);
    }

""" + source[idx:]
lo = source.index("    // Branches change one live set.")
hi = source.index("\n        internal int BeginBranch()", lo)
source = source[:lo] + """    // Assignment changes use the lexical scope's existing slot order.
    // Slots outside this function's bindings cannot contribute a diagnostic.
    private sealed class AssignmentFacts
    {
        private readonly Dictionary<string, int> _slots;
        private readonly HashSet<string>? _nestedNonlocals;
        private readonly StaticAnalysisContext _context;
        private readonly bool[] _assigned;
        private readonly record struct Change(int Slot, bool Added);
        private List<Change>? _changes;
        private List<int>? _saved;
        private int _branchDepth;

        internal AssignmentFacts(Dictionary<string, int> slots, HashSet<string>? nestedNonlocals,
            IReadOnlyList<FunctionParameterSyntax> parameters, StaticAnalysisContext context)
        {
            _slots = slots;
            _nestedNonlocals = nestedNonlocals;
            _context = context;
            _assigned = slots.Count == 0 ? [] : new bool[slots.Count];
            foreach (var parameter in parameters) Add(parameter.Name);
        }

        internal bool Contains(string name) => _slots.TryGetValue(name, out var slot) && _assigned[slot];

        internal bool IsUnassignedLocal(string name) => _slots.TryGetValue(name, out var slot) &&
            !_assigned[slot] && _nestedNonlocals?.Contains(name) != true;

        internal int SavedCount => _saved?.Count ?? 0;

        internal void Add(string name)
        {
            if (_slots.TryGetValue(name, out var slot)) SetAssigned(slot, true);
        }

        internal void Remove(string name)
        {
            if (_slots.TryGetValue(name, out var slot)) SetAssigned(slot, false);
        }

        private void SetAssigned(int slot, bool assigned)
        {
            if (_assigned[slot] == assigned) return;
            _assigned[slot] = assigned;
            if (_branchDepth != 0) (_changes ??= []).Add(new(slot, assigned));
        }
""" + source[hi:]
source = source.replace("context.CheckExecution();", "_context.CheckExecution();")
change("""                if (change.Added) _names.Remove(change.Name);
                else _names.Add(change.Name);""", "                _assigned[change.Slot] = !change.Added;")
change("if (change.Added && _names.Contains(change.Name)) (_saved ??= []).Add(change.Name);",
       "if (change.Added && _assigned[change.Slot]) (_saved ??= []).Add(change.Slot);")
change("                Add(saved[i]);", "                SetAssigned(saved[i], true);")
assert "_names" not in source
path.write_text(source, encoding="utf-8", newline="\n")
