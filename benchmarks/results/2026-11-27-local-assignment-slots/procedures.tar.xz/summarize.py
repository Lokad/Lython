from hashlib import sha256
from pathlib import Path
from statistics import median, quantiles
import json
import sys
import tarfile

root = Path(__file__).resolve().parent
mode = sys.argv[1]
assert mode in ("local", "quiet")
pair = root / ("comparison/quiet" if mode == "quiet" else "comparison")
read = lambda path: json.loads(path.read_bytes())
digest = lambda path: sha256(path.read_bytes()).hexdigest()
identity = read(pair / "identity.json")
cases = {case["id"]: case for case in read(pair / "representative.json")["cases"]}
assert (pair / "exit-code.txt").read_text().strip() == "0"
receipt = read(pair / "archive-receipt.json")
archive = pair / "observations.tar.xz"
assert receipt["archiveSHA256"] == digest(archive)
assert receipt["complete"] and receipt["allWorkersJoined"] and receipt["warmJobs"] == (3 if mode == "quiet" else 5)
if mode == "quiet":
    terminal = read(pair / "terminal-status.json")
    assert not terminal["fixtures"] and not terminal["live"] and terminal["exitCode"] == "0"
    assert all(receipt[key] for key in ("quietBeforeAndAfter", "guestFixturesRemoved", "archivedAndVerifiedUnderLease"))
    stage = read(pair / "stage-custody.json")
    assert stage["reused"] == {"donor": 63, "paired": 0}

for role, files in identity["imageFiles"].items():
    filename = f"{role}-remote-verify.json" if mode == "quiet" else f"{role}-verify.json"
    proof = read(pair / filename)
    assert proof["state"] == "Completed" and proof["caseCount"] == 4
    assert proof["launched"]["library"]["sha256"] == files["Lokad.Lython.dll"]
    assert proof["launched"]["adapter"]["sha256"] == files["Lokad.Lython.Benchmarks.dll"]
    assert proof["launched"]["python"]["sha256"] == identity["expectedCPythonSHA256"]
    assert proof["catalogSha256"] == identity["catalogs"]["representative.json"]["sha256"]

with tarfile.open(archive) as bundle:
    raw = json.load(bundle.extractfile("confirmation/confirmation.json"))
    if mode == "quiet":
        assert all(json.load(bundle.extractfile(f"confirmation/machine-{phase}.json"))["gate"]["quiet"] for phase in ("before", "after"))
    assert raw["complete"]
    assert json.load(bundle.extractfile("identity.json")) == identity
    jobs = json.load(bundle.extractfile("jobs.json"))["warm"]
    for name, expected in identity["catalogs"].items():
        assert sha256(bundle.extractfile(name).read()).hexdigest() == expected["sha256"]

summary = dict(sourceRevision=identity["sourceRevision"], candidatePatchSHA256=identity["sourcePatchSHA256"],
               quietMachine=mode == "quiet", collectionSeconds=raw["elapsedSeconds"], rows=[])
for job, (case_id, lane) in zip(raw["jobs"], jobs, strict=True):
    assert job["case"] == case_id and job["lane"] == lane and job["workersJoinedAndFixturesRemoved"]
    case = cases[case_id]
    elapsed = {}
    cpu = {}
    iqr = []
    for label, worker in job["identities"].items():
        role = label.removesuffix("-control")
        libraries = {Path(entry["path"]).name: entry["sha256"].lower() for entry in worker["libraries"]}
        assert libraries["Lokad.Lython.dll"] == identity["coreSHA256"][label]
        assert libraries["Lokad.Lython.Benchmarks.dll"] == identity["imageFiles"][role]["Lokad.Lython.Benchmarks.dll"]
        samples = [entry for entry in job["samples"] if entry["engine"] == label]
        assert len(samples) == 7 and {entry["round"] for entry in samples} == set(range(7))
        times = []
        active = []
        for entry in samples:
            result = entry["response"]
            count = result["completedInvocations"]
            assert result["status"] == "Completed" and count > 0
            assert all(result[key] == case[key] for key in ("sourceSha256", "fixtureSha256", "expectedOutputSha256"))
            assert result["actualOutputSha256"] == (None if lane == "compile" else case["expectedOutputSha256"])
            assert result.get("actualFilesSha256") == (None if lane == "compile" else case.get("expectedFilesSha256"))
            times.append(1000 * result["elapsedTicks"] / result["clockFrequency"] / count)
            active.append(1000 * entry["externalProcessCpuTicks"] / entry["externalCpuFrequency"] / count)
        elapsed[label] = median(times)
        cpu[label] = median(active)
        q = quantiles(times, n=4, method="inclusive")
        iqr.append((q[2] - q[0]) * 100 / elapsed[label])

    def change(data):
        pairs = [100 * (data[new] / data[old] - 1) for new in ("candidate", "candidate-control")
                 for old in ("reference", "reference-control")]
        return [min(pairs), max(pairs)]

    def spread(data):
        return {role: 100 * (max(data[role], data[role + "-control"]) / min(data[role], data[role + "-control"]) - 1)
                for role in ("reference", "candidate")}

    row = dict(case=case_id, lane=lane, elapsedMilliseconds=elapsed, cpuMilliseconds=cpu,
               elapsedChangePercent=change(elapsed), cpuChangePercent=change(cpu),
               elapsedSpreadsPercent=spread(elapsed), cpuSpreadsPercent=spread(cpu), maximumElapsedIqrPercent=max(iqr))
    summary["rows"].append(row)
    print(case_id, lane, "elapsed", *[f"{v:.2f}" for v in row["elapsedChangePercent"]],
          "CPU", *[f"{v:.2f}" for v in row["cpuChangePercent"]], "CPU spreads", row["cpuSpreadsPercent"])
summary["verifiedTimedBatches"] = sum(len(job["samples"]) for job in raw["jobs"])
assert summary["verifiedTimedBatches"] == (84 if mode == "quiet" else 140)
(pair / "summary.json").write_text(json.dumps(summary, indent=2) + "\n", encoding="utf-8", newline="\n")
