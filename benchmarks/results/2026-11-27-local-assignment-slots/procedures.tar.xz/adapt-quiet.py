from pathlib import Path

lab = Path(__file__).resolve().parent
donor = lab.parent / "generator-definition-cache-20261127"
source = (donor / "prepare-quiet.py").read_text(encoding="utf-8")
source = source.replace('"current-quiet-script-checkpoint-20261127/comparison/quiet"', '"generator-definition-cache-20261127/comparison/quiet"')
source = source.replace('"Quiet comparison of definition-owned lookup storage shared by interleaved generators."',
                        '"Quiet comparison of slot-indexed assignment analysis and a warm JSON control."')
source = source.replace('for name in ("representative.json", "jobs.json", "cpython-worker.py"):',
                        'for name in ("representative.json", "cpython-worker.py"):')
start = "prior_quiet = prior / \"comparison/quiet\""
replacement = """jobs = read(pair / "jobs.json")["warm"]
selected = [jobs[index] for index in (0, 1, 4)]
assert [row[1] for row in selected] == ["compile", "warm", "compile-run"]
write(quiet / "jobs.json", {"warm": selected})
identity["catalogs"]["jobs.json"]["sha256"] = digest(quiet / "jobs.json")
""" + start
assert source.count(start) == 1
source = source.replace(start, replacement)
source = source.replace('"lython-b1897-generator-cache-fixtures"', '"lython-b1900-local-assignment-slots-fixtures"')
source = source.replace('compile(collector, "collect.py", "exec")',
                        '''collector = collector.replace("len(jobs) == 4", "len(jobs) == 3").replace(
    "if job_index % 2 == 0: labels.reverse()", "if job_index % 2 == 1: labels.reverse()")
assert "len(jobs) == 3" in collector
compile(collector, "collect.py", "exec")''')
source = source.replace('root="generator-cache-quiet-b1897-20261127"', 'root="assignment-slots-quiet-b1900-20261127"')
source = source.replace('"lython-b1897-generator-cache-quiet"', '"lython-b1900-assignment-slots-quiet"')
source = source.replace('compile(vm, "quiet-vm.py", "exec")', 'vm = vm.replace("RuntimeMaxSec=250", "RuntimeMaxSec=195")\ncompile(vm, "quiet-vm.py", "exec")')
source = source.replace("four lanes.", "three lanes.")
compile(source, "prepare-quiet.py", "exec")
(lab / "prepare-quiet.py").write_text(source, encoding="utf-8", newline="\n")
