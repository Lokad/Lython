from pathlib import Path
from hashlib import sha256
import json
import subprocess
import tarfile
from shutil import copyfile

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
pair = lab / "comparison"
out = repo / "benchmarks/results/2026-11-27-local-assignment-slots"
read = lambda p: json.loads(p.read_bytes())
digest = lambda p: sha256(p.read_bytes()).hexdigest()
result = read(pair / "summary.json")
identity = read(pair / "identity.json")
assert result["verifiedTimedBatches"] == 140
assert read(pair / "archive-receipt.json")["archiveSHA256"] == digest(pair / "observations.tar.xz")
assert identity["sourcePatchSHA256"] == result["candidatePatchSHA256"] == digest(lab / "candidate.patch")
assert subprocess.check_output(["git", "diff", "--binary", identity["sourceRevision"], "--", "src"], cwd=repo) == (lab / "candidate.patch").read_bytes()
compiler = read(pair / "compiler-parity.json")
assert len(compiler["cases"]) == 17 and sum(row["budgetLevels"] for row in compiler["cases"]) == 131
assert len(compiler["diagnostics"]) == 9 and compiler["cancellation"]["afterDispose"] == 0
for role in ("reference", "candidate"):
    assert {p.name: digest(p) for p in (pair / role).iterdir()} == identity["imageFiles"][role]
    assert digest(pair / f"probe-{role}/Lokad.Lython.dll") == identity["coreSHA256"][role]
    assert read(pair / f"{role}-verify.json")["state"] == "Completed"
for log in ("windows-net11.0.log", "windows-net10.0.log"):
    assert "Passed!" in (lab / log).read_text(encoding="utf-8")


quiet = pair / "quiet"
quiet_result = read(quiet / "summary.json")
quiet_proof = read(quiet / "identity.json")
assert quiet_result["verifiedTimedBatches"] == 84 and quiet_result["quietMachine"]
assert quiet_proof["sourcePatchSHA256"] == identity["sourcePatchSHA256"]
assert quiet_proof["imageFiles"] == identity["imageFiles"]
assert read(quiet / "archive-receipt.json")["archiveSHA256"] == digest(quiet / "observations.tar.xz")

out.mkdir(exist_ok=True)
for name in ("identity.json", "summary.json", "compiler-parity.json", "observations.tar.xz", "archive-receipt.json"):
    copyfile(pair / name, out / name)
for name in ("summary.json", "identity.json", "observations.tar.xz", "archive-receipt.json", "stage-custody.json", "terminal-status.json"):
    copyfile(quiet / name, out / ("quiet-" + name))
entries = [lab / name for name in ("implement.py", "prepare.py", "prepare.log", "prepare-probe.py", "check-compiler.py",
                                  "compiler-checks-first.log", "compiler-checks.log", "summarize.py", "archive.py", "candidate.patch",
                                  "windows-net10.0.log", "windows-net11.0.log", "test-ubuntu.sh", "ubuntu-net10.0.log", "ubuntu-net11.0.log")]
entries.extend(pair / name for name in ("reference-verify.json", "candidate-verify.json", "run.sh", "exit-code.txt", "collection.log"))
entries.extend((lab / "probe" / name) for name in ("CompilerFacts.csproj", "Program.cs"))
entries.extend(pair.glob("probe-*/*.json"))
entries.extend(lab / name for name in ("adapt-quiet.py", "prepare-quiet.py", "quiet-vm.py"))
entries.extend(quiet / name for name in ("reference-remote-verify.json", "candidate-remote-verify.json", "upload.json", "launch.log", "exit-code.txt"))

with tarfile.open(out / "procedures.tar.xz", "w:xz", preset=3) as archive:
    for path in entries:
        archive.add(path, arcname=path.relative_to(lab))
with tarfile.open(out / "procedures.tar.xz") as archive:
    assert all(archive.extractfile(path.relative_to(lab).as_posix()).read() == path.read_bytes() for path in entries)
print("17 script tapes, 131 budget levels, 9 diagnostic specimens and 224 timing batches verified.")
