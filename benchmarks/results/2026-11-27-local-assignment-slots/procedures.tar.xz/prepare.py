from hashlib import sha256
from pathlib import Path
from shutil import copyfile, copytree
import json
import subprocess

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
notes = lab.parent
production = notes / "generator-definition-cache-20261127/comparison"
read = lambda p: json.loads(p.read_bytes())
digest = lambda p: sha256(p.read_bytes()).hexdigest()
git = lambda *args: subprocess.check_output(["git", *args], cwd=repo)
def write(path, value):
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False) + "\n", encoding="utf-8", newline="\n")

original = read(production / "identity.json")
base = git("rev-parse", "HEAD").decode().strip()
assert sha256(git("diff", "--binary", original["sourceRevision"], base, "--", "src")).hexdigest() == original["sourcePatchSHA256"]
patch = git("diff", "--binary", base, "--", "src")
assert b"private readonly bool[] _assigned;" in patch and patch.count(b"diff --git ") == 1
(lab / "candidate.patch").write_bytes(patch)
pair = lab / "comparison"
pair.mkdir()
for role in ("reference", "candidate"):
    copytree(production / "candidate", pair / role)
assert {p.name: digest(p) for p in (pair / "reference").iterdir()} == original["imageFiles"]["candidate"]
core = "Lokad.Lython.dll"
fresh = repo / "src/Lokad.Lython/bin/Release/net11.0" / core
tested = repo / "tests/Lokad.Lython.PublicApi.Tests/bin/Release/net11.0" / core
assert digest(fresh) == digest(tested) != digest(pair / "reference" / core)
copyfile(fresh, pair / "candidate" / core)
images = {role: {p.name: digest(p) for p in (pair / role).iterdir()} for role in ("reference", "candidate")}
assert [name for name, before in images["reference"].items() if images["candidate"][name] != before] == [core]
for name in ("cpython-worker.py", "run.sh"):
    copyfile(production / name, pair / name)
assert digest(pair / "cpython-worker.py") == original["cpythonWorkerSHA256"]
assert b"\r" not in (pair / "run.sh").read_bytes()
frontend = notes / "current-frontend-profile-20261127/local"
catalog_path = frontend / "catalog.json"
assert digest(catalog_path) == read(frontend / "identity.json")["profileCatalogSHA256"]
catalog = read(catalog_path)
ordinary, escaping, guarded = catalog["cases"]
control = notes / "current-quiet-script-checkpoint-20261127/comparison/quiet"
assert digest(control / "representative.json") == read(control / "identity.json")["catalogs"]["representative.json"]["sha256"]
nested = next(case for case in read(control / "representative.json")["cases"] if case["id"] == "diagnostic.nested-json-document")
catalog["cases"].append(nested)
jobs = [[ordinary["id"], "compile"], [nested["id"], "warm"], [guarded["id"], "compile"],
        [escaping["id"], "compile-run"], [guarded["id"], "compile-run"]]
write(pair / "representative.json", catalog)
write(pair / "jobs.json", {"warm": jobs})
identity = dict(sourceRevision=base, sourcePatchSHA256=digest(lab / "candidate.patch"), productionReference=base, imageFiles=images,
                coreSHA256={role + suffix: files[core] for role,files in images.items() for suffix in ("", "-control")},
                cpythonWorkerSHA256=original["cpythonWorkerSHA256"], cpythonPath=original["cpythonPath"],
                expectedCPythonSHA256=original["expectedCPythonSHA256"], purpose="Share lexical slots with the local definite-assignment diagnostics.",
                catalogs={name: {"sha256": digest(pair / name)} for name in ("representative.json", "jobs.json")})
write(pair / "identity.json", identity)
collect = (production / "collect.py").read_text(encoding="utf-8").replace("len(jobs) == 4", "len(jobs) == 5").replace(
    "lython-generator-definition-cache-", "lython-local-assignment-slots-")
compile(collect, "collect.py", "exec")
(pair / "collect.py").write_text(collect, encoding="utf-8", newline="\n")
print(base, identity["sourcePatchSHA256"])
