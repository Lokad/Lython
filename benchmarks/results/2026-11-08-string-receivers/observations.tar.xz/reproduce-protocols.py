from pathlib import Path
import hashlib,json,os,re,shutil,subprocess
r=Path(__file__).resolve().parent;image=r/'baseline-public-check';shutil.copytree('tests/Lokad.Lython.PublicApi.Tests/bin/Release/net11.0',image,copy_function=os.link)
core=image/'Lokad.Lython.dll';core.unlink();shutil.copyfile(r/'images/before/Lokad.Lython.dll',core)
assert hashlib.sha256(core.read_bytes()).hexdigest()=='903eb34663f37ece159669d4b52418b3e24b465c4d5e3ecc6f0ebe75599f1ab7'
env=os.environ.copy();env['DOTNET_ROOT']='C:/Users/JoannesVermorel/.dotnet11';env['PATH']=env['DOTNET_ROOT']+os.pathsep+env['PATH']
args=[env['DOTNET_ROOT']+'/dotnet.exe','vstest',str(image/'Lokad.Lython.PublicApi.Tests.dll'),'/TestCaseFilter:FullyQualifiedName~StringReceiverBindingTests.GuestProtocolsSuspendWithFundedOperandsAndAwaitedCancellation','/Logger:console;Verbosity=minimal']
with(r/'baseline-protocols.log').open('w',encoding='utf-8')as log:done=subprocess.run(args,env=env,stdout=log,stderr=subprocess.STDOUT)
text=(r/'baseline-protocols.log').read_text(encoding='utf-8');(r/'baseline-protocols.json').write_text(json.dumps(dict(exitCode=done.returncode,coreSHA256=hashlib.sha256(core.read_bytes()).hexdigest(),command=args,tail=text[-1800:]),indent=2)+'\n',encoding='utf-8');print(text[-2000:])
