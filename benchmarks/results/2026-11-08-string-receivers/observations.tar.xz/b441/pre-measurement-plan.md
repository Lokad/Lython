# Lokad.Lython 0.11.0

Updated 2026-11-08. Git-ignored; never force-add. Publication/tagging postponed.
Objective: coherent simplification and substantial complete-script performance.
An isolated experiment does not complete that objective. Experimental narratives,
original failed conditions and raw evidence remain in benchmarks/EXPERIMENTS.md
and results; docs describe the current implementation.

## Actual delivery status

| Work | Actual status |
| --- | --- |
| Shared compiler facts, direct UTF-8 formatting/storage, native helper returns | Committed and fully qualified. Native-return allocation −19.92%/−19.31%; original elapsed diagnostic. Formatting allocation −8.67%; controlled B102 elapsed/CPU −5–8%, original adverse 15.125 ms preserved and unexplained. Do not repeat unchanged qualification. |
| R62 / 70267889 | Fully qualified CI42412531882, cached terminal green. |
| R65/R66 / 824fc6bb | Fully qualified CI42418518578: Windows/Ubuntu Release actual .NET 11/10, original Stress and installed core consumers. |
| R67 / 5076359c | Current CPython guide measures 824fc6bb/core15c04e2a, 23 jobs/478.32 s. Compile, warm and compile-to-result separate; I/O/validation/cleanup boundaries explicit. Original failed B406 and historical 55e510ff preserved. Not today's HEAD. |
| R68 / 5076359c | Exact immutable dev55/d6067925: 86 internal/514 public per actual 11/10, unchanged adapter bridge. Normal optional 0.4 pin/core unchanged. Development compatibility only. |
| R69 / fd5ab1c1 | Complete returned-record CSV script, independent goldens/CPython checks and current attribution committed; production unchanged. |
| R70 / 7a81a629 | Fully qualified CI42422556519: Windows/Ubuntu Release actual 11/10, original Stress and installed consumers. Cached terminal receipt; never requery. Immutable tuple unpacking removes iterator/list/copy/reservation work. Allocation −13.57% sync/−14.40% async; controlled affected elapsed −6.45–7.45% sync/−7.01–9.34% async. |
| R71 / f88191f7 + a34f56b5 | f88191f7 fully qualified CI42426106105, cached terminal green. Subsequent readonly transport correction: 1,366 internal/244 public per actual11/10, B427 complete; fully qualified with R72 by CI42428096630. B424/B425 adverse originals retained. |
| R72 / 68d5bffe | Committed/pushed. 1,729 internal/597 public per actual11/10, matching probes, 20 baseline cases. B428 complete/archived/verified: allocation −23.48% sync/−21.69% async; affected controlled elapsed −1.92–4.79% sync/−2.76–6.49% async. FULLY QUALIFIED CI42428096630: Windows/Ubuntu actual11/10, original Stress and installed core consumers; terminal cached, never requery. |
| R73 /21b0bc72 | Targeted current returned-record CPython baseline committed; source68/corea0, five jobs107.44s. Guide revision boundaries explicit; no wholesale replay. |
| R74 /33b6c191 | Fully qualified CI42431587731; controlled complete float report benefit, neutral allocation, original adverse controls retained. |
| R75 /79657355+c384956f | Text storage gate, missing current allocation capture; raw failures consolidated/verified, no storage prototype or timing claim. |
| R76 prerequisite /06651b11 | Unicode cache cancellation correction committed; reproduced failure,67internal/135public per actual11/10 pass. Full qualification batches with next retained milestone. |
| R76 /38f53c33 | Committed/pushed. Managed inline8 copied UTF-8, native span readers and direct reserved final construction remove payload arrays/stack-copy/caller branches; prerequisite06651b11 cache-cancellation fix retained.162internal/415public per actual11/10 pass. Full CI42439532114 running, not yet fully qualified. |

Latest fully qualified runtime33b6c191: cached green CI42431587731, both OSes,
actual11/10, original Stress and installed consumers. Later documentation does
not qualify another runtime. Never replay unchanged qualification or query cached
terminal runs. Continue work while R76's delivery runs.

## Active deliverables

1. Close R76 delivery: cache CI42439532114 once terminal; require established
   Windows/Ubuntu actual11/10, original Stress and installed-consumer steps.
   Preserve real failures and fix defects without relaxing assertions/timeouts.
   B435/B436 are terminal/archived/verified. Allocation text−9.4%, CSV−8–9%,
   report~−1%; controlled async-text elapsed−2.3–3.3%, report modest benefit,
   CSV near baseline. Sync text inconclusive(old spread11.59%). Float-async
   +0.9–2.7% explicitly accepted debt; CPU mixed/quantized. All four prototype
   sources and adverse observations preserved. No universal CPU/latency claim.
2. R77 combined CPython checkpoint: source38f53c33/core903eb346, CPython3.13.16,
   eight complete scripts, compilation/warm/compile-to-result separate plus two
   numeric-string controls. Explicit included mediated RAM I/O, validation and
   prior-result cleanup; excluded startup/staging/reset/final cached teardown.
   Two independent Lython processes, reference variation visible. B437/B439
   failed before workers on staging floor; B438 failed before samples from a
   worker-role typo. Original failure archived/locally verified, all workers
   joined and empty mount released. Corrected B440 is live,570s owner+30s stop;
   observe after03:08:34.689569UTC. Hardlink unchanged metadata; retain240MiB OS
   floor and7MiB evidence reserve. Archive under lease/verify locally; refresh
   docs/BENCHMARKS.md, preserving prior R67/R73 tables behind evidence links.
   Current guide names its older measured source, never today's HEAD.
3. R78 ordinary method construction gate: complete text report differing only
   by split()/rsplit() independently matches CPython outputs. Same-current-core
   local diagnostics allocate~1.497MB/~3.930MB per invocation in both APIs;
   all goldens/balances/isolation/cleanup pass. Elapsed unstable/diagnostic.
   Unlimited rsplit uses the same whitespace kernel: inspect binding, operand
   transport and context promotion before attributing the2.43MB difference.
   Select a complete removable phase, then implement a coherent shared receiver
   declaration/invocation migration with existing ReceiverMethod/borrowed storage.
   Remove displaced factories/provider dispatch/packing; no name-marker series,
   second dispatch framework or loss of existing native optimizations. Preserve
   exposed methods/metadata/defaults/keywords/errors/evaluation order, Unicode,
   true async guest protocols, cancellation, first refusal and retained/pending
   argument/result funding. Focused Release checks plus one short affected-script
   source pair with unaffected controls decide retention/refinement. Stop at a
   concrete phase or insufficient evidence, then select the next boundary.

## Substantial redesign roadmap

| Boundary | Evidence / eliminated work / acceptance |
| --- | --- |
| Complete calls/frames and operand transport | Indexed operands/native returns/final slots/deferred contexts already exist. R63 text attribution includes useful arithmetic/dispatch; inclusive calls are not removable CPU. Select a complete remaining transport/activation phase, remove its displaced path. Preserve callbacks, exception state, exact integer promotion/identity, aliases and public projection. No universal tagged-value or arena rewrite without dominant-cost evidence. |
| Per-record storage | R20/R25 shared CSV keys/array transfer/direct JSON slots and R70 tuple borrow supersede the rigidly rejected bulk-CSV attempt. Its 6–8% benefit and adverse control remain historical. Reassess a real remaining construction/copy/capacity phase; no automatic revival. Preserve row mutation/reentry/hooks/order/retained aliases. |
| Bulk text/JSON | Direct UTF-8 casing/lower-split/formatting/native parsing, completed JSON loop and shared line scanner delivered. R61 measured ordinary JSON has no escaped tokens. Select a demonstrated whole conversion/storage phase, preserve Unicode/context/hooks/async I/O; no succession of narrow special cases. |
| Frontend facts | R55/R58/R62/R65 remove repeated lexical/graph/validity/module work. Remaining class/function demands have distinct scope/annotation rules. Require concrete repeated-walk deletion with exact diagnostics; no speculative visitor/cache/parser migration. |

For each selected milestone record the hypothesis, work/storage eliminated, affected
complete scripts, semantic/cancellation/admission acceptance and old implementation
removed. One bounded source/generated-code assessment; focused attribution only if
existing evidence cannot select. Stop at a concrete phase or insufficient evidence,
then choose another boundary. Prior call-arena/call-control slowdowns remain lessons,
not dormant alternatives. Architectural simplification, allocation reduction, elapsed
and CPU are distinct. Fixed improvement percentages inform judgment, never automatic
vetoes. A timeout or unstable unchanged control establishes uncertainty. Allow bounded
confirmation/refinement/measurement correction when justified, retaining all original
adverse and failed conditions. No blanket one-attempt/no-retiming/permanent closure.

Temporary regressions during justified redesign require an explicit completion
milestone and retain/correct/reject decision on remaining debt. Architectural
simplification, allocation reduction and demonstrated CPU improvement stay distinct.
At coherent combined checkpoints refresh complete-script CPython comparisons with
exact source, compile/warm/compile-to-result and included I/O/cleanup boundaries;
do not infer source-pair gains from independent external-baseline checkpoints.

## Independent regex deliverable

Core owns Python/native UTF-8 semantics, byte ranges/scalar positions/original-subject
windows, flags/captures/replacements/errors, cache ownership/current tokens and one
provider through frontend/runtime/imports. No Utf8Regex core dependency. Optional
adapter stays nonpackable, normal 0.4 pin. Contract tests, semantic compatibility and
actual backend performance are separate. Development producers/adapter-local bridges
support implementation; missing publication defers only affected final qualification.

Precise dev55 gaps: DetailedData has no separate preparation/working-owner input;
native name lookup lacks enumeration; cursor creation retains its token despite
current-move overloads. Existing bridges remain justified. No sibling edits/builds,
producer-CI replay, dialect fallback, quotas, memory subsystem or abandoned matching.
Released-package/managed-safety/backend-performance qualification remains outstanding;
it must not stop independent core development or performance work.

## Lasting validation and ownership constraints

AGENTS.md governs fully managed/memory-safe code and managed stack admission: no
unsafe/Unsafe/PInvoke/raw pointers/native probes. Preserve host capabilities, effective
cancellation, checked representation bounds, XML depth and bounded I/O chunks.
Borrow the shared allowance for coarse preflights, capacity/replacement overlap,
retained aliases and escaping caches/results. Scope creation reserves nothing; no
hidden allowances/caps/fuel/quotas/tracing/weak reclamation/forced GC. Initial long
streams use bounded host-driven executions. First structured refusal is terminal
through guest suppression/finally returns; native refunds/cleanup remain awaited.
Never retry admission or skip optional storage to recover.

Focused Release checks during iteration; build matching probes, exclude Stress
explicitly when a custom filter is supplied. No overlapping local builds/tests/
measurements. Force nonincremental builds after timestamp-preserving source restores.
Batch full Windows/Ubuntu actual 11/10, original Stress and installed core consumers
at coherent retained boundaries. Use explicit UTF-8. Only core Release pack via
tools/pack.ps1 into artifacts/nuget; no adapter packages/publication/tag promotion.

VM lokad@20.166.121.73,key ~/.ssh/id_lython-bench.pem. Persistent evidence,
RAM-backed fixtures, join/unmount/archive under lease and verify locally. Reclaim
only archive-verified redundant extracts/core links. Terminal runs never requeried;
CI observations at least5minutes apart. Publication/tagging remain postponed.
