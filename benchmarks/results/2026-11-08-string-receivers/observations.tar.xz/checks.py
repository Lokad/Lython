from pathlib import Path
r=Path(__file__).resolve().parent
s=(r.parent/'inline-text-r76/checks.py').read_text(encoding='utf-8')
a=s.index('internal=');b=s.index('results={}',a)
internal=['BoundMethodInvocationBoundaryTests','GeneralBoundMethodTransportTests','GeneralBoundMethodDefaultLifetimeTests','StringMethodOwnershipTests','StringWindowOwnershipTests','StringStripStorageTests','TerminalStringStorageTests','DirectString','StringProtocolBoundaryTests','StringAffixBoundsExecutionTests','Utf8CasingTests']
public=['StringReceiverBindingTests','ReceiverMethodSemanticsTests','StringMethodCompatibilityTests','StringSearchWindowTests','StringPaddingParityTests','StringStripCallTests','DirectString','StringOwnershipAdmissionTests','StringMethodAccountingScenarioTests','StringPadAccountingScenarioTests','StringAffixBoundsSuspensionTests','StringValidationScenarioTests','StringProtocolTests','NativeHelper','GeneralBoundMethod']
s=s[:a]+'internal='+repr(internal)+'\npublic='+repr(public)+'\n'+s[b:]
exec(compile(s,str(r/'checks.py'),'exec'),{'__file__':str(r/'checks.py')})
