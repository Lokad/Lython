from pathlib import Path
import hashlib,json,subprocess,tarfile
r=Path(__file__).resolve().parent;prior=r.parent/'json-float-entry-r74';receipt=json.loads((prior/'archive-receipt.json').read_text(encoding='utf-8'))
assert receipt['complete']and hashlib.sha256((prior/'observations.tgz').read_bytes()).hexdigest()==receipt['archiveSHA256']
with tarfile.open(prior/'observations.tgz')as a:expected=hashlib.sha256(a.extractfile('current-core.dll').read()).hexdigest()
remote=r'''from pathlib import Path
import fcntl,hashlib,json,os,shutil,subprocess,tarfile
base=Path('/home/lokad/lython-bench-checks');prior=base/'json-float-entry-b430-20261108';target=prior/'candidate/Lokad.Lython.dll';note=base/'method-binding-b441-retired-json-core.json'
with(base/'comparison-vm.lock').open('a')as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB);assert not note.exists()
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[c]ollector.dll|[p]erf record'],capture_output=True).returncode==1
 receipt=json.loads((prior/'archive-receipt.json').read_text());assert receipt['complete']and receipt['archiveSHA256']=='ARCHIVE'and hashlib.sha256((prior/'observations.tgz').read_bytes()).hexdigest()=='ARCHIVE'
 with tarfile.open(prior/'observations.tgz')as a:assert hashlib.sha256(a.extractfile('current-core.dll').read()).hexdigest()=='CORE'
 assert target.is_file()and not target.is_symlink()and hashlib.sha256(target.read_bytes()).hexdigest()=='CORE'
 inode=target.stat().st_ino;device=target.stat().st_dev;links=target.stat().st_nlink;paths=[]
 for folder,dirs,files in os.walk(base,followlinks=False):
  for name in files:
   p=Path(folder)/name
   if not p.is_symlink()and p.stat().st_ino==inode and p.stat().st_dev==device:paths.append(p)
 assert len(paths)==links and all(p.resolve().is_relative_to(base.resolve())and hashlib.sha256(p.read_bytes()).hexdigest()=='CORE'for p in paths)
 before=shutil.disk_usage(base).free
 for p in paths:p.unlink()
 result=dict(paths=[str(p)for p in paths],coreSHA256='CORE',archiveSHA256='ARCHIVE',beforeFreeBytes=before,afterFreeBytes=shutil.disk_usage(base).free,allOriginalBytesRetainedInImmutableVmAndVerifiedLocalArchives=True,reason='Retire fully archived old JSON-core extraction; current903 runtime and all raw evidence retained. No active users, all hardlinks within owned root verified.')
 note.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
'''.replace('ARCHIVE',receipt['archiveSHA256']).replace('CORE',expected)
compile(remote,'retire','exec')
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
done=subprocess.run(ssh+['python3 -'],input=remote,text=True,encoding='utf-8',capture_output=True);(r/'retirement.log').write_text(done.stdout+'\n'+done.stderr,encoding='utf-8');assert done.returncode==0,done.stderr
(r/'retired-json-core.json').write_text(done.stdout,encoding='utf-8');print(done.stdout)
