from pathlib import Path
import base64,copy,hashlib,json,os,shutil,subprocess,tempfile
r=Path(__file__).resolve().parent;prior=r.parent/'inline-text-r76'
d=json.loads((prior/'catalog.json').read_text());original=next(c for c in d['cases']if c['id']=='scripts.text-summary-helpers.large');variant=copy.deepcopy(original)
assert original['source'].count('.split()')==1
variant['id']='scripts.text-summary-rsplit-helpers.large';variant['source']=original['source'].replace('.split()','.rsplit()')
variant['sourceUtf8Bytes']=len(variant['source'].encode('utf-8'));variant['sourceSha256']=hashlib.sha256(variant['source'].encode('utf-8')).hexdigest()
fixture=json.loads(variant['fixtureJson']);assert set(fixture['inputFiles'])=={'input.txt'} and set(fixture['outputFiles'])=={'report.txt'}
with tempfile.TemporaryDirectory(prefix='lython-method-golden-')as folder:
 for name,data in fixture['inputFiles'].items():(Path(folder)/name).write_bytes(base64.b64decode(data))
 results=[]
 for label,case in [('split',original),('rsplit',variant)]:
  done=subprocess.run(['C:/Python313/python.exe','-I','-S','-X','utf8','-c',case['source']],cwd=folder,capture_output=True)
  assert done.returncode==0 and not done.stderr and done.stdout.replace(b'\r\n',b'\n')==case['expectedOutput'].encode('utf-8'),(done.returncode,done.stdout,done.stderr)
  files={name:(Path(folder)/name).read_bytes()for name in fixture['outputFiles']}
  assert all(files[name]==base64.b64decode(data)for name,data in fixture['outputFiles'].items())
  results.append(dict(label=label,sourceSHA256=case['sourceSha256'],stdoutSHA256=hashlib.sha256(done.stdout).hexdigest(),files={n:hashlib.sha256(v).hexdigest()for n,v in files.items()}))
 assert results[0]['files']==results[1]['files']
assert not Path(folder).exists();(r/'independent-goldens.json').write_text(json.dumps(results,indent=2)+'\n',encoding='utf-8')
d['cases']=[original,variant]+[next(c for c in d['cases']if c['id']==name)for name in ['scripts.csv-summary-functions.large','scripts.report-render.large','scripts.numeric-report.integer.large']]
(r/'catalog.json').write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
for role in ['before','candidate']:shutil.copytree(prior/'images/candidate',r/'images'/role,copy_function=os.link)
s=(prior/'measure.py').read_text();(r/'measure.py').write_text(s,encoding='utf-8',newline='\n')
plan='''R78 bounded remaining-call assessment, source38f53c33/core903eb346. Ordinary text helperlower().rsplit() and lower().split() produce identical complete stdout/files on identical fixtures, independently verified under isolated localCPython3.13. Same frozen runtime in all three ALC roles, common CoreLib/hash seed; existing five-case allocation diagnostic both APIs, no new benchmark framework. Desktop timing remains diagnostic. Source shows factory closures/general binding/context promotion for rsplit versus existing native helper proof for split. No runtime change selected yet. If materially larger work is demonstrated, propose a complete shared-method declaration/invocation migration using existing ReceiverMethod and borrowed operand storage; remove factory/provider/packing paths, preserve native optimizations, exposed method identity, binding/default/error/order semantics, genuine async protocols, cancellation and owned argument/result lifetimes. Do not add a series of per-name markers or a universal new dispatch framework. Stop at concrete removable phase or insufficient evidence, keep R76 qualification independent.'''
(r/'selected-plan.md').write_text(plan+'\n',encoding='utf-8')
print('Complete split/rsplit text outputs independently match CPython; same runtime frozen in all diagnostic roles.')
