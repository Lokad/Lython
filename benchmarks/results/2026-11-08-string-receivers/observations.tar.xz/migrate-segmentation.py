from pathlib import Path
r=Path('src/Lokad.Lython/Runtime');p=r/'LythonRuntime.StringMembers.Segmentation.cs';s=p.read_text(encoding='utf-8');marker='        private sealed class StringSegmentationMemberProvider : IStringMemberProvider'
assert marker in s
new=r'''        private static readonly ReceiverMethod RSplitMethod = new(
            LythonCallableSignature.Create("str.rsplit", ["sep", "maxsplit"], 0),
            static (receiver, arguments, span, context) => RSplit((PyString)receiver, arguments, span, context, false).GetAwaiter().GetResult(),
            static (receiver, arguments, span, context) => RSplit((PyString)receiver, arguments, span, context, true));

        private static readonly ReceiverMethod SplitLinesMethod = new(
            LythonCallableSignature.Create("str.splitlines", ["keepends"], 0, 1, LythonVariadicParameters.None, 0),
            static (receiver, arguments, span, context) => PyStringOps.SplitLines((PyString)receiver,
                arguments.Length == 1 && IsTruthy(arguments.Span[0]!, context, span), context.MemoryGovernor, span),
            static (receiver, arguments, span, context) => arguments.Length == 1 && arguments.Span[0] is PyInstance
                ? SplitLinesWithGuestTruthAsync((PyString)receiver, arguments.Span[0]!, span, context)
                : new(PyStringOps.SplitLines((PyString)receiver, arguments.Length == 1 && IsTruthy(arguments.Span[0]!), context.MemoryGovernor, span)));

        private static readonly ReceiverMethod ExpandTabsMethod = new(
            LythonCallableSignature.Create("str.expandtabs", ["tabsize"], 0),
            static (receiver, arguments, span, context) => PyStringOps.ExpandTabs((PyString)receiver,
                arguments.Length == 1 ? RuntimeArgumentValidation.CoerceIndexInt32Async(arguments.Span[0]!, context, span, false).GetAwaiter().GetResult() : 8, context, span),
            static (receiver, arguments, span, context) => arguments.Length == 1 && arguments.Span[0] is PyInstance
                ? ExpandTabsWithGuestWidthAsync((PyString)receiver, arguments.Span[0]!, span, context)
                : new(PyStringOps.ExpandTabs((PyString)receiver,
                    arguments.Length == 1 ? RuntimeArgumentValidation.CoerceIndexInt32Async(arguments.Span[0]!, context, span, false).GetAwaiter().GetResult() : 8, context, span)));

        private static readonly ReceiverMethod StripMethod = CreateStripMethod("strip", PyStringOps.Strip,
            LythonCallableSignature.Create("str.strip", ["chars"], 0, 1, LythonVariadicParameters.None, 1));
        private static readonly ReceiverMethod LStripMethod = CreateStripMethod("lstrip", PyStringOps.LStrip,
            LythonCallableSignature.Create("str.lstrip", ["chars"], 0));
        private static readonly ReceiverMethod RStripMethod = CreateStripMethod("rstrip", PyStringOps.RStrip,
            LythonCallableSignature.Create("str.rstrip", ["chars"], 0));

        private static ReceiverMethod? GetSegmentationMethod(string name) => name switch
        {
            "split" => ReceiverMethods.StringSplit,
            "rsplit" => RSplitMethod,
            "splitlines" => SplitLinesMethod,
            "expandtabs" => ExpandTabsMethod,
            "strip" => StripMethod,
            "lstrip" => LStripMethod,
            "rstrip" => RStripMethod,
            _ => null,
        };

        private static ValueTask<object> RSplit(PyString text, ReadOnlyMemory<object?> arguments,
            LythonSourceSpan span, ExecutionContext context, bool asynchronous)
        {
            PyString? separator = null;
            if (arguments.Length != 0 && arguments.Span[0] is not PyNone &&
                !PyStringOps.TryAsString(arguments.Span[0]!, out separator))
                throw RuntimeErrors.Type("must be str or None, not " + RuntimeErrors.OperandTypeName(arguments.Span[0]!), span);
            if (arguments.Length == 2 && arguments.Span[1] is PyInstance)
                return RSplitWithGuestCountAsync(text, separator, arguments.Span[1]!, span, context, asynchronous);
            var count = arguments.Length == 2 ? NormalizeSplitCount(arguments.Span[1]!, context, span) : -1;
            return new(RSplitWithCount(text, separator, count, span, context));
        }

        private static async ValueTask<object> RSplitWithGuestCountAsync(PyString text, PyString? separator,
            object count, LythonSourceSpan span, ExecutionContext context, bool asynchronous)
        {
            var indexed = await CoerceTypeIndexAsync(count, context, span, asynchronous).ConfigureAwait(false);
            return RSplitWithCount(text, separator, NormalizeSplitCount(indexed ?? PyNone.Instance, context, span), span, context);
        }

        private static PyList RSplitWithCount(PyString text, PyString? separator, int count,
            LythonSourceSpan span, ExecutionContext context)
        {
            if (separator is null) return PyStringOps.RSplitWhitespace(text, count, context.MemoryGovernor, span, context);
            try { return PyStringOps.RSplit(text, separator, count, context.MemoryGovernor, span); }
            catch (InvalidOperationException error) { throw new LythonRuntimeException("ValueError", error.Message, span); }
        }

        private static async ValueTask<object> SplitLinesWithGuestTruthAsync(PyString text, object keepEnds,
            LythonSourceSpan span, ExecutionContext context)
            => PyStringOps.SplitLines(text, await IsTruthyAsync(keepEnds, context, span).ConfigureAwait(false), context.MemoryGovernor, span);

        private static async ValueTask<object> ExpandTabsWithGuestWidthAsync(PyString text, object width,
            LythonSourceSpan span, ExecutionContext context)
            => PyStringOps.ExpandTabs(text, await RuntimeArgumentValidation.CoerceIndexInt32Async(width, context, span, true).ConfigureAwait(false), context, span);

        // These declarations are created once. Only a Python-visible attribute
        // allocates a receiver wrapper; immediate calls borrow existing operands.
        private static ReceiverMethod CreateStripMethod(string methodName, Func<PyString, PyString> whitespaceOperation,
            LythonCallableSignature signature)
            => new(signature, (receiver, arguments, span, context) =>
            {
                var text = (PyString)receiver;
                using var ambient = PyStructuralGuard.PushAmbient(context, span);
                PyString result;
                if (arguments.Length == 0 || arguments.Span[0] is PyNone)
                    result = whitespaceOperation(text);
                else if (!PyStringOps.TryAsString(arguments.Span[0]!, out var chars))
                    throw RuntimeErrors.Type($"{methodName} arg must be None or str", span);
                else
                {
                    using var working = context.MemoryGovernor.ReserveTemporary(
                        chars.Utf8Span.IsEmpty ? 0 : checked(256L + 64L * chars.ByteLength), span);
                    result = methodName switch
                    {
                        "strip" => PyStringOps.Strip(text, chars),
                        "lstrip" => PyStringOps.LStrip(text, chars),
                        _ => PyStringOps.RStrip(text, chars),
                    };
                    return OwnMethodResult(result, text, context.MemoryGovernor, span);
                }
                return OwnMethodResult(result, text, context.MemoryGovernor, span);
            });
    }
}
'''
p.write_text(s.split(marker)[0]+new,encoding='utf-8',newline='\n')
p=r/'LythonRuntime.StringMembers.cs';s=p.read_text(encoding='utf-8').replace('            StringSegmentationMemberProvider.Instance,\n','')
needle='            foreach (var provider in Providers)';assert needle in s
s=s.replace(needle,'''            if (GetMethod(name) is { } method)
            {
                value = method.Bind(text);
                return true;
            }

'''+needle)
p.write_text(s,encoding='utf-8',newline='\n')
p=r/'LythonRuntime.StringMembers.Basic.cs';s=p.read_text(encoding='utf-8');needle='        internal static PyString Lower('
assert needle in s
s=s.replace(needle,'''        internal static ReceiverMethod? GetMethod(string name)
            => GetSegmentationMethod(name) ?? (name switch
            {
                "join" => ReceiverMethods.StringJoin,
                "replace" => ReceiverMethods.StringReplace,
                "startswith" => ReceiverMethods.StringStartsWith,
                "endswith" => ReceiverMethods.StringEndsWith,
                _ => null,
            });

'''+needle)
p.write_text(s,encoding='utf-8',newline='\n')
p=r/'LythonRuntime.Executable.Interpreter.cs';s=p.read_text(encoding='utf-8')
s=s.replace('PyString => StringMembers.GetNoArgumentsOperation(name),','PyString => (object?)StringMembers.GetNoArgumentsOperation(name) ?? StringMembers.GetMethod(name),')
start=s.index('                    PyString => name switch');end=s.index('                    ReMatchObject =>',start)
s=s[:start]+'                    PyString => StringMembers.GetMethod(name),\n'+s[end:]
p.write_text(s,encoding='utf-8',newline='\n')
print('Segmentation family uses shared receiver declarations; old provider/factories removed. Existing native no-argument operations retained.')
