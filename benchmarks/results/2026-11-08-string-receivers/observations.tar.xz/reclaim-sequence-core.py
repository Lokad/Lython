from pathlib import Path
r=Path(__file__).resolve().parent
s=(r/'reclaim-json-core.py').read_text(encoding='utf-8')
for a,b in [("a.extractfile('current-core.dll')","a.extractfile('baseline-core.dll')"),("target=prior/'candidate/Lokad.Lython.dll'","target=prior/'reference/Lokad.Lython.dll'"),('method-binding-b441-retired-json-core.json','method-binding-b441-retired-sequence-core.json'),('retirement.log','sequence-retirement.log'),('retired-json-core.json','retired-sequence-core.json'),('old JSON-core extraction','old sequence-core extraction')]:
 assert a in s,a
 s=s.replace(a,b)
exec(compile(s,str(r/'reclaim-sequence-core.py'),'exec'),{'__file__':str(r/'reclaim-sequence-core.py')})
