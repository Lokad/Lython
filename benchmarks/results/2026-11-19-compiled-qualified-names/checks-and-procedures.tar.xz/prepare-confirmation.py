from pathlib import Path
import ast
p=Path(__file__).resolve().parent
prior=p.parent/'lexical-definition-context-r619'
s=(prior/'stage-confirmation.py').read_text(encoding='utf-8-sig')
s=s.replace('lexical-qualified-names-confirmation-b1050','shared-lexical-names-confirmation-b1052')
s=s.replace('lython-b1050-lexical-qualified-names-confirmation','lython-b1052-shared-lexical-names-confirmation')
s=s.replace('lython-b1049-fixtures','lython-b1051-fixtures').replace('lython-b1050-fixtures','lython-b1052-fixtures')
s=s.replace('R619 confirmation of the rule report and adverse source-pair controls','R621 confirmation of annotated rules and controls')
s=s.replace("jobs=[('scripts.report-forwarding.expanded','compile-run'),('scripts.annotated-rule-closure-report','warm'),('scripts.annotated-rule-closures','warm')]",
    "jobs=[('scripts.annotated-rule-closures','warm'),('calls.positional.large','warm'),('scripts.report-forwarding.expanded','compile-run')]")
s=s.replace('232*1024*1024','225*1024*1024')
ast.parse(s)
(p/'stage-confirmation.py').write_text(s,encoding='utf-8',newline='\n')
