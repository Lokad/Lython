shift = 1
def factory(seed):
    def named(value=seed):
        return value + shift
    return named if seed % 2 == 0 else (lambda value=seed: value + shift)
funcs = [factory(seed) for seed in range(400)]
shift = 10
print(funcs[0](), funcs[-1](), funcs[0].__qualname__, funcs[-1].__qualname__)
