def make():
    def nested():
        pass
    return nested
left, right = make(), make()
print(left.__qualname__, left.__qualname__ is right.__qualname__)
