from pathlib import Path
import ast
p=Path(__file__).resolve().parent
previous=p.parent/'lexical-definition-context-r619'
s=(previous/'stage-quiet.py').read_text(encoding='utf-8-sig')
s=s.replace('prepared-binding-diagnostics-r616','lexical-definition-context-r619')
s=s.replace('R619 lexical function qualified names','R621 compiled qualified names and R620 module-owned leaf functions')
s=s.replace('lexical-qualified-names-b1049','shared-lexical-names-b1051').replace('lython-b1049-lexical-qualified-names','lython-b1051-shared-lexical-names').replace('lython-b1049-fixtures','lython-b1051-fixtures')
s=s.replace('donor_archive=load(previous/"archive-recovery.json")','donor_archive=load(previous/"archive-receipt.json")').replace('donor_archive["verifiedAfterCollectionUnderIdleLease"]','donor_archive["archivedAndVerifiedUnderLease"]')
s=s.replace('old["identity"]["imageFiles"]["candidate"]','old["identity"]["imageFiles"]["reference"]').replace('sourceRole="candidate"','sourceRole="reference"')
s=s.replace('minimum_headroom = 232 * 1024 * 1024','minimum_headroom = 225 * 1024 * 1024')
s=s.replace('source=source.replace("252*1024*1024", str(minimum_headroom))','source=source.replace(str(232*1024*1024), str(minimum_headroom))')
a,b=s.index('        jobs = ['),s.index('        source=source[:a]')
s=s[:a]+'''        jobs = [
            ('scripts.rule-default-closures','warm'),('scripts.annotated-rule-closures','warm'),
            ('scripts.annotated-rule-closures','compile-run'),('scripts.annotated-rule-closure-report','warm'),
            ('scripts.annotated-rule-closure-report','compile-run'),('scripts.report-forwarding.expanded','compile-run'),
            ('calls.positional.large','warm'),('scripts.config-generated-guards.medium','compile-run')]
'''+s[b:]
s=s.replace('launcher = launcher.replace("242*1024*1024", str(minimum_headroom))','launcher = launcher.replace(str(232*1024*1024), str(minimum_headroom))')
a,b=s.index('start=launcher.index('),s.index('write(quiet / "remote-launch.py"',s.index('start=launcher.index('))
s=s[:a]+s[b:]
s=s.replace('Prepared binding diagnostics source pair','Shared lexical names and module-owned leaf functions').replace('Lexical qualified names source pair','Shared lexical names and module-owned leaf functions')
ast.parse(s)
(p/'stage-quiet.py').write_text(s,encoding='utf-8',newline='\n')
