using System.Collections;
using System.Reflection;
using System.Security.Cryptography;
using System.Text.Json;

const BindingFlags Members = BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic;
var assemblyPath = Path.GetFullPath(args[0]);
var assembly = Assembly.LoadFrom(assemblyPath);
var engineType = assembly.GetType("Lokad.Lython.LythonEngine", throwOnError: true)!;
var engine = Activator.CreateInstance(engineType)!;
var compile = engineType.GetMethod("Compile", [typeof(string)])!;
using var catalog = JsonDocument.Parse(File.ReadAllBytes(args[1]));
var cases = new Dictionary<string, object>();
foreach (var input in catalog.RootElement.GetProperty("cases").EnumerateArray())
{
    using var compiled = (IDisposable)compile.Invoke(engine, [input.GetProperty("source").GetString()])!;
    if (!(bool)Property(compiled, "IsValid")!) throw new InvalidOperationException("Invalid benchmark input");
    var runner = (Delegate)Field(compiled, "_runner")!;
    var target = runner.Target!;
    var executable = target.GetType().GetFields(Members).Single(field =>
        field.FieldType.FullName == "Lokad.Lython.Frontend.ExecutableScript").GetValue(target)!;
    cases.Add(input.GetProperty("id").GetString()!, DescribeCode(Property(executable, "EntryPoint")!));
}

Console.WriteLine(JsonSerializer.Serialize(new
{
    imageSha256 = Convert.ToHexStringLower(SHA256.HashData(File.ReadAllBytes(assemblyPath))), cases
}, new JsonSerializerOptions { WriteIndented = true }));

static object? Field(object value, string name) => value.GetType().GetField(name, Members)!.GetValue(value);
static object? Property(object value, string name) => value.GetType().GetProperty(name, Members)!.GetValue(value);
static IEnumerable<object?> Sequence(object value, string name) => ((IEnumerable)Property(value, name)!).Cast<object?>();
static object DescribeCode(object code) => new
{
    name = Property(code, "Name"),
    usesLexicalSlots = Property(code, "UsesOnlyLexicalSlots"),
    mirrors = Property(code, "RequiresLocalVariableMirroring"),
    runsNative = Property(code, "CanRunNativeInstructions"),
    capacity = Property(code, "ValueStorageCapacity"),
    nativePrefixEnd = Property(code, "NativePrefixEnd"),
    names = Sequence(code, "Names").ToArray(),
    locals = Sequence(code, "LocalNames").ToArray(),
    closures = Sequence(code, "ClosureNames").ToArray(),
    instructions = Sequence(code, "Instructions").Select(value => new
    {
        opcode = Property(value!, "OpCode")!.ToString(),
        span = Property(value!, "Span")!.ToString(),
        operands = new[] { "_primaryOperand", "_secondaryOperand", "_inputStart", "_resultSlot", "_liveExtent" }
            .Select(name => Field(value!, name)).ToArray()
    }).ToArray(),
    regions = Sequence(code, "ExceptionRegions").Select(region => region!.ToString()).ToArray(),
    constants = Sequence(code, "Constants").Select(value => value?.GetType().Name).ToArray(),
    codeChildren = Sequence(code, "Constants").Where(value => value is not null &&
        value.GetType().GetProperty("CodeObject", Members) is not null)
        .Select(value => DescribeCode(Property(value!, "CodeObject")!)).ToArray()
};
