from pathlib import Path
import hashlib
import json
import os
import subprocess
import tarfile

lab = Path(__file__).resolve().parent
previous = lab.parent / 'shared-executable-graph'
donor_dir = previous / 'quiet'
quiet = lab / 'quiet'
read = lambda p: p.read_text(encoding='utf-8-sig')
load = lambda p: json.loads(read(p))
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()

def write(path, body):
    if path.suffix == '.py':
        compile(body, str(path), 'exec')
    path.write_text(body, encoding='utf-8', newline='\n')

pair = load(lab / 'frozen-identity.json')
donor = load(donor_dir / 'config.json')
receipt = load(donor_dir / 'archive-receipt.json')
assert receipt['complete'] and receipt['archivedAndVerifiedUnderLease']
assert sha(donor_dir / 'observations.tgz') == receipt['archiveSHA256']
assert donor['identity']['imageFiles']['candidate'] == pair['images']['reference']
assert sha(lab/'catalog.json') == pair['casesSHA256']
manifest = lab/'catalog.json'
order = tuple(row['id'] for row in load(manifest)['cases'])
assert len(order) == 4
catalog_hash = sha(manifest)
sdk = Path.home()/'.dotnet11'
dotnet = sdk/'dotnet.exe'
env = dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk),PATH=str(sdk)+os.pathsep+os.environ['PATH'])
for role,files in pair['images'].items():
    image = lab/'frozen'/role
    assert len(files) == 32 and {name:sha(image/name) for name in files} == files
    verified = lab / f'{role}-comparison-verify.json'
    subprocess.run([dotnet,image/'Lokad.Lython.Benchmarks.dll','--compare','verify','--catalog',manifest,'--dotnet',dotnet,
                    '--python','C:/Python313/python.exe','--python-worker',Path('benchmarks/cpython-worker.py').resolve(),'--out',verified],
                   env=env,check=True,timeout=90)
    assert load(verified)['state']=='Completed' and load(verified)['catalogSha256']==catalog_hash
    result = lab / f'{role}-comparison-allocation.json'
    subprocess.run([dotnet,image/'ValidatedAllocation.dll',image,manifest,result],env=env,check=True,timeout=90)
    assert all(row['sharedBudgetBaselineRestored'] for row in load(result)['rows'])
    cold = lab / f'{role}-compile-allocation.json'
    with cold.open('wb') as log:
        subprocess.run([dotnet,image/'CompileAllocation.dll',manifest],env=dict(env,DOTNET_TieredCompilation='0'),
                       check=True,timeout=120,stdout=log)
    cold_rows = load(cold)
    assert cold_rows['coreSha256']==files['Lokad.Lython.dll'] and len(cold_rows['rows'])==4
    assert {name:sha(image/name) for name in files} == files

root = '/home/lokad/lython-bench-checks/default-operand-storage-b1216-20261120'
unit = 'lython-b1216-default-operand-storage-20261120'
core = 'Lokad.Lython.dll'
purpose = 'Retire the separate owner of unpublished function defaults'
jobs = [(order[0], 'warm'), (order[1], 'warm'), (order[2], 'warm'), (order[3], 'warm'),
        (order[0], 'compile-run'), (order[0], 'compile')]
identity = dict(sourceRevision=pair['referenceCommit']+' versus '+pair['candidateCommit'],purpose=purpose,
                imageFiles=pair['images'],catalogSHA256=catalog_hash,normalAdapterPin='0.4.0',
                coreSHA256={label:files[core] for role,files in pair['images'].items() for label in (role,role+'-control')})
quiet.mkdir(exist_ok=False)
write(quiet/'identity.json',json.dumps(identity,indent=2)+'\n')
(quiet/'representative.json').write_bytes(manifest.read_bytes())
(quiet/'cpython-worker.py').write_bytes(Path('benchmarks/cpython-worker.py').read_bytes())
assert sha(quiet/'cpython-worker.py') == donor['protocolSHA256']
(quiet/'candidate').mkdir()
(quiet/'candidate'/core).write_bytes((lab/'frozen/candidate'/core).read_bytes())
for name in ('collect.py','archive-owned.py','run.sh','retrieve.py'):
    body = read(donor_dir/name).replace(donor['root'],root).replace(donor['unit'],unit)
    for old,new in [('len(jobs)==4','len(jobs)==6'),("['jobs']==4","['jobs']==6"),
                    ("len(raw['jobs'])==4","len(raw['jobs'])==6"),('jobs=4,','jobs=6,')]:
        body=body.replace(old,new)
    if name=='collect.py':
        start = body.index('\njobs = ')
        end = body.index('\nassert len(jobs)',start)
        body = body[:start]+'\njobs = '+repr(jobs)+body[end:]
    write(quiet/name,body)
assert b'\r' not in (quiet/'run.sh').read_bytes()
parts = ['identity.json','representative.json','cpython-worker.py','collect.py','archive-owned.py','run.sh','candidate/'+core]
payload = quiet/'payload.tgz'
with tarfile.open(payload,mode='w:gz') as archive:
    for name in parts:
        archive.add(quiet/name,arcname=name)
config = dict(root=root,unit=unit,source=donor['root'],sourceRole='candidate',sourceFiles=pair['images']['reference'],
              sourceCatalogSHA256=donor['catalogSHA256'],protocolSHA256=donor['protocolSHA256'],catalogSHA256=catalog_hash,
              identity=identity,retireGroups=[],donorArchiveSHA256=receipt['archiveSHA256'],
              payloadBytes=payload.stat().st_size,payloadSHA256=sha(payload),unpackedBytes=sum((quiet/name).stat().st_size for name in parts))
write(quiet/'config.json',json.dumps(config,indent=2)+'\n')
body=read(donor_dir/'remote-launch.py')
start=body.index('\nc=')+1
end=body.index('\nb=Path(',start)
body=body[:start]+'c='+repr(config)+body[end:]
body=body.replace('lython-b1212-fixtures','lython-b1216-fixtures')
assert '+64*1024*1024' in body
write(quiet/'remote-launch.py',body)
body=read(previous/'launch-quiet.py').replace(donor['identity']['purpose'],purpose)
write(lab/'launch-quiet.py',body)
write(lab/'summarize-quiet.py',read(previous/'summarize-quiet.py'))
print('Four workload goldens and complete images verified, six timing lanes staged.')
