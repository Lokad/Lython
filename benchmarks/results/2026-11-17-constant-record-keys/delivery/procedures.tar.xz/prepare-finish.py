from pathlib import Path
import json
r=Path(__file__).resolve().parent
dispatch=json.loads((r/'delivery/dispatch.json').read_text(encoding='utf-8'))
s=(r.parent/'record-construction-r498/finish-delivery.py').read_text(encoding='utf-8')
s=s.replace('44187816311',str(dispatch['run'])).replace('4b975a44753eeef0a07d10c715bd046501605517',dispatch['head']).replace('18032','18035')
s=s.replace("r/'final/frozen/identity.json'", "r/'frozen/identity.json'").replace("r/'final/candidate-sources.tar.xz'", "r/'candidate-sources.tar.xz'")
s=s.replace('all585ProductionInputsMatchMeasuredFinal5d9633a8','all585ProductionInputsMatchMeasuredCf847936').replace('benchmarks/results/2026-11-17-function-container-construction/delivery','benchmarks/results/2026-11-17-constant-record-keys/delivery')
(r/'finish-delivery.py').write_text(s,encoding='utf-8',newline='\n')
print('Prepared exactea8/18035public/source-matched verifier; run only after cachedGREEN.')
