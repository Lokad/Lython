from pathlib import Path
import hashlib,io,json,re,shutil,subprocess,tarfile,zipfile
r=Path(__file__).resolve().parent;repo=Path('D:/code/Lython');d=r/'delivery';run=44192474928
terminal=json.loads((d/'terminal.json').read_text(encoding='utf-8'))
assert terminal['status']=='completed' and terminal['conclusion']=='success' and terminal['headSha']=='ea8e9f911fe39aa4133b2d362d8a11754469a2b1'
z=d/'run-logs.zip'
if not z.exists():
 with z.open('wb')as output:p=subprocess.run(['gh','api',f'repos/Lokad/Lython/actions/runs/{run}/logs','--allow-escape-sequences'],stdout=output,stderr=subprocess.PIPE)
 assert p.returncode==0,p.stderr
for job in terminal['jobs']:
 assert job['conclusion']=='success'
 for name in ['Build Release solution','Test Release (.NET 11)','Test Release (.NET 10 checkpoint)','Verify Release package consumer','Test original stress scales']:
  assert next(s for s in job['steps']if s['name']==name)['conclusion']=='success'
pattern=re.compile(r'Passed!\s+-\s+Failed:\s*(\d+).*?\bPassed:\s*([\d,]+).*?\bSkipped:\s*([\d,]+).*?\bTotal:\s*([\d,]+).*?\((net\d+\.\d+)\)');rows=[]
with zipfile.ZipFile(z)as archive:
 roots=[n for n in archive.namelist()if'/'not in n and n.endswith('.txt')];assert len(roots)==2
 for name in roots:
  data=[]
  for m in pattern.finditer(archive.read(name).decode('utf-8-sig')):
   failed,passed,skipped,total=[int(v.replace(',',''))for v in m.groups()[:4]];assert failed==skipped==0 and total==passed;data.append(dict(framework=m[5],passed=passed))
  assert len(data)==8
  for tfm in ['net11.0','net10.0']:assert sorted(x['passed']for x in data if x['framework']==tfm)==[14,406,4831,18035],(name,data)
  rows.append(dict(log=name,summaries=data))
inputs=json.loads((d/'inputs.json').read_text(encoding='utf-8'));assert inputs['head']==terminal['headSha'] and inputs['count']==2385 and inputs['production']==585
specs=[inputs['head']+':'+n for n in inputs['inputs']];raw=subprocess.run(['git','cat-file','--batch'],cwd=repo,input=('\n'.join(specs)+'\n').encode(),stdout=subprocess.PIPE,check=True).stdout;offset=0;contents={}
for spec in specs:
 end=raw.index(b'\n',offset);header=raw[offset:end].decode().split();assert header[1]=='blob';size=int(header[2]);data=raw[end+1:end+1+size];offset=end+2+size;n=spec.split(':',1)[1];assert hashlib.sha256(data).hexdigest()==inputs['inputs'][n];contents[n]=data
assert offset==len(raw)
with tarfile.open(d/'inputs.tar.xz')as archive:
 for n,data in contents.items():
  if n.startswith('src/Lokad.Lython/'):
   frozen=archive.extractfile(n).read()
   if frozen!=data:assert frozen.decode('utf-8-sig').replace('\r\n','\n')==data.decode('utf-8-sig').replace('\r\n','\n'),n
v=dict(run=run,head=terminal['headSha'],conclusion='success',jobs=rows,summaries=16,sourceInputsVerified=2385,production=585,normalAdapterPin='0.4.0',allMeaningfulStepsPassed=True,logsSHA256=hashlib.sha256(z.read_bytes()).hexdigest(),committedProductionMatchesQualifiedInputs=True,binaryEqualityInferred=False,publicationHeld=True)
(d/'qualification.json').write_text(json.dumps(v,indent=2)+'\n',encoding='utf-8')

identity=json.loads((r/'frozen/identity.json').read_text(encoding='utf-8'))
with tarfile.open(r/'candidate-sources.tar.xz')as frozen:
 for n,data in contents.items():
  if not n.startswith('src/Lokad.Lython/'):continue
  source=frozen.extractfile(n).read()
  assert hashlib.sha256(source).hexdigest()==identity['sourceInputs'][n],n
  assert source==data or source.decode('utf-8-sig').replace('\r\n','\n')==data.decode('utf-8-sig').replace('\r\n','\n'),n
v['all585ProductionInputsMatchMeasuredCf847936']=True
(d/'qualification.json').write_text(json.dumps(v,indent=2)+'\n',encoding='utf-8')
out=repo/'benchmarks/results/2026-11-17-constant-record-keys/delivery';out.mkdir(exist_ok=False)
for name in ['terminal.json','qualification.json','inputs.json','inputs.tar.xz','run-logs.zip']:shutil.copyfile(d/name,out/name)
with tarfile.open(out/'procedures.tar.xz','w:xz')as a:
 for name in ['start-delivery.py','poll-delivery.py','prepare-finish.py','finish-delivery.py']:a.add(r/name,arcname=name)
print('Full construction qualification cached and verified; compare final frozen production separately before documenting.')
