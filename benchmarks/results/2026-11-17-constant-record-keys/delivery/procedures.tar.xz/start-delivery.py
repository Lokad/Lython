from pathlib import Path
import datetime,hashlib,io,json,re,subprocess,tarfile

notes=Path(__file__).parent;root=Path('D:/code/Lython');delivery=notes/'delivery'
assert not delivery.exists()
assert not subprocess.check_output(['git','status','--porcelain'],cwd=root,text=True).strip()
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
assert head.startswith('ea8e9f91')
assert subprocess.check_output(['git','rev-parse','origin/master'],cwd=root,text=True).strip()==head
old=json.loads((notes.parent/'record-construction-r498/delivery/inputs.json').read_text(encoding='utf-8'))
names=sorted(old['inputs'])
assert len(names)==2385
batch=subprocess.check_output(['git','cat-file','--batch'],cwd=root,input=''.join('HEAD:'+name+'\n'for name in names).encode('utf-8'))
offset=0;inputs={};contents={}
for name in names:
    end=batch.index(b'\n',offset);header=batch[offset:end].decode('ascii').split();assert header[1]=='blob'
    size=int(header[2]);data=batch[end+1:end+1+size];assert len(data)==size and batch[end+1+size:end+2+size]==b'\n'
    offset=end+2+size;inputs[name]=hashlib.sha256(data).hexdigest();contents[name]=data
    working=(root/name).read_bytes()
    # Fixtures include intentionally binary/non-UTF8 sources. Compare those
    # exactly; normalize only differing text line endings in this Windows tree.
    assert working==data or working.decode('utf-8-sig').replace('\r\n','\n')==data.decode('utf-8-sig').replace('\r\n','\n'),name
assert offset==len(batch)
production=[name for name in names if name.startswith('src/Lokad.Lython/')];assert len(production)==585
delivery.mkdir()
with tarfile.open(delivery/'inputs.tar.xz','w:xz')as archive:
    for name,data in contents.items():
        entry=tarfile.TarInfo(name);entry.size=len(data);entry.mode=0o644;archive.addfile(entry,io.BytesIO(data))
(delivery/'inputs.json').write_text(json.dumps(dict(head=head,count=len(inputs),production=len(production),
    boundary='Exact committed Git blob bytes, matching current working text; constant record construction delivery, no frozen performance equality inferred.',
    inputs=inputs),indent=2)+'\n',encoding='utf-8',newline='\n')
result=subprocess.run(['gh','workflow','run','ci.yml','--ref','master','-f','stress=true'],cwd=root,capture_output=True,text=True,encoding='utf-8')
(delivery/'dispatch.log').write_text(result.stdout+result.stderr,encoding='utf-8',newline='\n')
assert result.returncode==0,result.stderr
match=re.search(r'https://github.com/Lokad/Lython/actions/runs/(\d+)',result.stdout)
assert match,'Inspect acknowledgement; never retry a dispatched workflow.'
now=datetime.datetime.now(datetime.timezone.utc)
record=dict(head=head,workflow='ci.yml',stress=True,recordedAtUTC=now.isoformat(),run=int(match[1]),url=match[0],
    expectedEachPlatformTarget=dict(ordinaryInternal=4831,ordinaryPublic=18035,stressInternal=14,stressPublic=406),publicationHeld=True)
(delivery/'dispatch.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8',newline='\n')
(delivery/'next-observation.json').write_text(json.dumps(dict(notBeforeUTC=(now+datetime.timedelta(seconds=300)).isoformat()),indent=2)+'\n',encoding='utf-8',newline='\n')
source=(notes.parent/'json-scalars-r492/poll-delivery.py').read_text(encoding='utf-8')
source=source.replace('44128892209',str(record['run'])).replace('22d5a5f3c3824eb352825a597d932a9ebc02de5b',head)
(notes/'poll-delivery.py').write_text(source,encoding='utf-8',newline='\n')
print(json.dumps(record))
print('Full correctness boundary dispatched once; observe after',now+datetime.timedelta(seconds=300))

