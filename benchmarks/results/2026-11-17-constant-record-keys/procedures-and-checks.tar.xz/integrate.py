from pathlib import Path
import hashlib,json,shutil,subprocess
r=Path(__file__).resolve().parent;repo=Path('D:/code/Lython');w=repo/'.git/agent-worktrees/constant-record-r499'
assert not subprocess.check_output(['git','status','--porcelain'],cwd=repo,text=True).strip()
f=json.loads((r/'frozen/identity.json').read_text(encoding='utf-8'))
for n in f['changedProductionFiles']:
 assert hashlib.sha256((w/n).read_bytes()).hexdigest()==f['sourceInputs'][n],n
 shutil.copyfile(w/n,repo/n)
n='tests/Lokad.Lython.PublicApi.Tests/ContainerDisplayPipelineTests.cs';shutil.copyfile(w/n,repo/n)
decision=dict(retain=True,reference='4b975a44/5d9633a8',measuredCandidate='privateR499/cf847936 on4b975a44',productionSourceUnchangedSinceFrozen=True,additionalTestOnlyCorrections='After frozen snapshot, warmed-cache refusal cases extend9to11class cases; all11passactual11and10.',cpuClaim='record warm12-14percent lower; compile-to-result9-12percent lower with supporting process CPU',allocationReductionPercent=14.665947207875874,unresolvedDebt='Floating same-source candidate spread12.91percent; elapsed-6.82..+6.17percent, no recovery/source-gain inference.',fullQualification='Batch next coherent delivery, R49844187816311 independent; no silent qualification inheritance',publicationHeld=True)
(r/'integration-decision.json').write_text(json.dumps(decision,indent=2)+'\n',encoding='utf-8',newline='\n')
print('Integrated unchanged measured production and additional observable refusal tests; full qualification remains separate.')
