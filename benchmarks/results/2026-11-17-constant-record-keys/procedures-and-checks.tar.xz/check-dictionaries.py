from pathlib import Path
import os,subprocess,json
r=Path(__file__).resolve().parent;w=Path('D:/code/Lython/.git/agent-worktrees/constant-record-r499');d=Path('C:/Users/JoannesVermorel/.dotnet11/dotnet.exe');env=os.environ.copy();env.update(DOTNET_ROOT=str(d.parent),DOTNET_ROOT_X64=str(d.parent));env['PATH']=str(d.parent)+os.pathsep+env['PATH'];rows=[]
for tfm in ['net11.0','net10.0']:
 for project in ['Lokad.Lython.Tests','Lokad.Lython.PublicApi.Tests']:
  path=r/(project+'-'+tfm+'.log');cmd=[str(d),'test',f'tests/{project}/{project}.csproj','-c','Release','-f',tfm,'--no-build','--filter','(FullyQualifiedName~Dictionary|FullyQualifiedName~GovernedMemoryContract|FullyQualifiedName~MemoryDenialAttribution)&Category!=Stress']
  with path.open('w',encoding='utf-8')as log:p=subprocess.run(cmd,cwd=w,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=180)
  text=path.read_text(encoding='utf-8');rows.append(dict(project=project,framework=tfm,exitCode=p.returncode,command=cmd));(r/'dictionary-checks.json').write_text(json.dumps(rows,indent=2)+'\n',encoding='utf-8');assert p.returncode==0,text;print(project,tfm,text.splitlines()[-1],flush=True)
