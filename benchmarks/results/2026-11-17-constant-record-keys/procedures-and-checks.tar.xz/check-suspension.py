from pathlib import Path
import os,subprocess
r=Path(__file__).resolve().parent;work=Path('D:/code/Lython/.git/agent-worktrees/constant-record-r499');d=Path('C:/Users/JoannesVermorel/.dotnet11/dotnet.exe')
env=os.environ.copy();env.update(DOTNET_ROOT=str(d.parent),DOTNET_ROOT_X64=str(d.parent));env['PATH']=str(d.parent)+os.pathsep+env['PATH']
for tfm in ['net11.0','net10.0']:
 path=r/('suspension-'+tfm+'.log')
 cmd=[str(d),'test','tests/Lokad.Lython.PublicApi.Tests/Lokad.Lython.PublicApi.Tests.csproj','-c','Release','-f',tfm,'--no-restore','--filter','FullyQualifiedName~ContainerDisplayPipeline']
 with path.open('w',encoding='utf-8')as log:p=subprocess.run(cmd,cwd=work,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=180)
 text=path.read_text(encoding='utf-8');assert p.returncode==0,text;print(tfm,text.splitlines()[-1],flush=True)
