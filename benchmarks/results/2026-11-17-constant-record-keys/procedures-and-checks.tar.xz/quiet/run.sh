set -eu
root=/home/lokad/lython-bench-checks/constant-record-b924-20261117
trap 'result=$?; printf "%s\n" "$result" > "$root/exit-code.txt"' EXIT
python3 "$root/collect.py"
