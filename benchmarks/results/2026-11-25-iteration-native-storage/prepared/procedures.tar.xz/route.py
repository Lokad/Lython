from pathlib import Path
import difflib,hashlib,json,os,shutil,subprocess,zipfile

lab=Path(__file__).resolve().parent
donor=lab.with_name("native-call-construction-20261125")
read=lambda p:json.loads(p.read_text(encoding="utf-8"))
identity=read(lab/"comparison/quiet/identity.json")
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
sdk=Path.home()/".dotnet11"
dotnet=sdk/"dotnet.exe"
env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk),PATH=str(sdk)+os.pathsep+os.environ["PATH"])
work=lab/"route"
work.mkdir()
counters=["IterationLoanStarts","PositionalWorkspaces","LoanTransfers","LoanSlotsCopied"]
def write(p,s):p.write_text(s,encoding="utf-8",newline="\n")
def run(*args,cwd=work,log=None):
    if log:
        with (work/log).open("wb") as f:
            subprocess.run([dotnet,*args],cwd=cwd,env=env,timeout=150,stdout=f,stderr=subprocess.STDOUT,check=True)
    else:
        subprocess.run([dotnet,*args],cwd=cwd,env=env,timeout=70,check=True)
cs=(donor/"Program.cs").read_text(encoding="utf-8")
i=cs.index("string[] names = ")
cs=cs[:i]+"string[] names = "+json.dumps(counters)+";\n"+cs[cs.index("var runtime =",i):]
write(work/"Program.cs",cs)
shutil.copyfile(donor/"RouteProbe.csproj",work/"RouteProbe.csproj")
catalog=read(lab/"input-catalog.json")
cases=[]
for mode in (False,True):
    for item in catalog["cases"]:
        cases.append(item|{"runAsync":mode})
catalog["cases"]=cases
write(work/"cases.json",json.dumps(catalog,ensure_ascii=False,indent=2)+"\n")
build_ids={}
for role,files in identity["imageFiles"].items():
    assert {p.name:sha(p) for p in (lab/role).iterdir()}==files
    source=work/(role+"-source")
    if role=="reference":
        with zipfile.ZipFile(lab/"base.zip") as bundle:
            bundle.extractall(source)
            assert all((source/n).read_bytes()==bundle.read(n) for n in bundle.namelist() if not n.endswith("/"))
    else:
        shutil.copytree(lab/"frozen-candidate",source,ignore=shutil.ignore_patterns("obj","bin"))
    p=source/"src/Lokad.Lython/Runtime/PyExecutableFunction.cs"
    before=p.read_text(encoding="utf-8")
    start="internal sealed class PyExecutableFunction : PyFunctionBase\n{\n"
    code=before.replace(start,start+"".join("    internal static int Diagnostic"+n+";\n" for n in counters))
    i=code.index("        NativeValues buffer = default;",code.index("    private void StartNativeWorkspace("))
    code=code[:i]+"        Interlocked.Increment(ref DiagnosticPositionalWorkspaces);\n"+code[i:]
    if role=="candidate":
        mark="            StartInline(storage, null, span, false, default, out _, out result, out frame, out owned);"
        assert code.count(mark)==1
        code=code.replace(mark,"            Interlocked.Increment(ref DiagnosticIterationLoanStarts);\n"+mark)
        mark="            state.PrepareTransfer();"
        assert code.count(mark)==1
        code=code.replace(mark,mark+"""
            if (values.Length == LythonRuntime.InlineIterationOperandCount)
            {
                Interlocked.Increment(ref DiagnosticLoanTransfers);
                Interlocked.Add(ref DiagnosticLoanSlotsCopied, state.LiveExtent);
            }""")
    else:
        # The baseline needs those reflection fields but has no three-slot path.
        for name in ("IterationLoanStarts","LoanTransfers","LoanSlotsCopied"):
            code=code.replace("    internal static int Diagnostic"+name+";", "    internal static int Diagnostic"+name+" = 0;")
    write(p,code)
    write(work/(role+".patch"),"".join(difflib.unified_diff(before.splitlines(True),code.splitlines(True),p.name,p.name)))
    output=work/(role+"-build")
    run("build","src/Lokad.Lython/Lokad.Lython.csproj","-c","Release","-f","net11.0","--no-incremental","--artifacts-path",output,
        cwd=source,log=role+"-build.log")
    image=work/(role+"-image")
    image.mkdir()
    for name in files:
        path=output/"bin/Lokad.Lython/release_net11.0/Lokad.Lython.dll" if name=="Lokad.Lython.dll" else lab/role/name
        shutil.copyfile(path,image/name)
    build_ids[role]={p.name:sha(p) for p in image.iterdir()}
    assert {k for k,v in build_ids[role].items() if v!=files[k]}=={"Lokad.Lython.dll"}
# The same compiler and public APIs are used in both instrumented workers.
proj=work/"RouteProbe.csproj"
s=proj.read_text(encoding="utf-8")
s=s.replace("image/","candidate-image/").replace("image\\","candidate-image\\")
write(proj,s)
run("build","RouteProbe.csproj","-c","Release","--no-incremental",log="probe-build.log")
result={}
for role in build_ids:
    image=work/(role+"-image")
    for p in (work/"bin/Release/net11.0").glob("RouteProbe.*"):
        shutil.copyfile(p,image/p.name)
    output=work/(role+"-rows.json")
    run(image/"RouteProbe.dll",image,work/"cases.json",output)
    assert {n:sha(image/n) for n in build_ids[role]}==build_ids[role]
    result[role]=read(output)["rows"]
rows=[]
for old,new in zip(result["reference"],result["candidate"],strict=True):
    assert old["id"]==new["id"] and old["asynchronous"]==new["asynchronous"]
    assert old["peakExecutionMemoryBytes"]==new["peakExecutionMemoryBytes"]
    n=2048 if new["id"]=="diagnostic.shipment-file-fed-map" else 0
    assert new["routes"]["IterationLoanStarts"]==n,(n,new)
    assert old["routes"]["PositionalWorkspaces"]-new["routes"]["PositionalWorkspaces"]==n,(old,new)
    assert new["routes"]["LoanTransfers"]==0
    row=dict(case=new["id"],asynchronous=new["asynchronous"],reference=old["routes"],candidate=new["routes"],
        peakExecutionMemoryBytes=new["peakExecutionMemoryBytes"])
    rows.append(row)
    print(row,flush=True)
write(lab/"route-summary.json",json.dumps(dict(instrumentedImages=build_ids,rows=rows),indent=2)+"\n")
