set -eu
lab="$PWD/.git/agent-notes/review-20261031/iteration-native-storage-20261125"
worktree="$PWD/.git/agent-worktrees/iteration-native-storage-20261125"
export DOTNET_ROOT="$HOME/.dotnet"
export PATH="$DOTNET_ROOT:$PATH"
for suite in Lokad.Lython.Tests Lokad.Lython.PublicApi.Tests; do
 log="$lab/ubuntu-net10-$suite.log"
 filter='(FullyQualifiedName~Iterat|FullyQualifiedName~Native|FullyQualifiedName~SimpleFunction|FullyQualifiedName~Callback|FullyQualifiedName~Map|FullyQualifiedName~Terminal|FullyQualifiedName~Generator|FullyQualifiedName~AsyncBoundary|FullyQualifiedName~Csv)&Category!=Stress'
 if "$DOTNET_ROOT/dotnet" test "$worktree/tests/$suite/$suite.csproj" -c Release -f net10.0 --artifacts-path "$lab/ubuntu" --filter "$filter" > "$log" 2>&1; then
     tail -3 "$log"
 else
     tail -48 "$log"
     exit 1
 fi
done