set -eu
lab="$PWD/.git/agent-notes/review-20261031/iteration-native-storage-20261125"
tree="$PWD/.git/agent-worktrees/iteration-native-storage-20261125"
export DOTNET_ROOT="$HOME/.dotnet"
export PATH="$DOTNET_ROOT:$PATH"
code=0
dotnet test "$tree/tests/Lokad.Lython.Tests/Lokad.Lython.Tests.csproj" -c Release -f net10.0 --artifacts-path "$lab/ubuntu" --filter 'FullyQualifiedName~IterationWorkspaceLifetimeTests' > "$lab/ubuntu-loan.log" 2>&1 || code=$?
tail -22 "$lab/ubuntu-loan.log"
exit "$code"
