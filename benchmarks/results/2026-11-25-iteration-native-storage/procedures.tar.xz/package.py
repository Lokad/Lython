from pathlib import Path
import hashlib,json,shutil,subprocess,tarfile
lab=Path(__file__).resolve().parent
repo=lab.parents[3]
tree=repo/".git/agent-worktrees/iteration-native-storage-20261125"
out=repo/"benchmarks/results/2026-11-25-iteration-native-storage"
quiet=lab/"comparison/quiet"
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
read=lambda p:json.loads(p.read_text(encoding="utf-8"))
identity=read(quiet/"identity.json")
assert subprocess.check_output(["git","-C",tree,"diff","--binary","--","src"])==(lab/"candidate.patch").read_bytes()
assert sha(lab/"candidate.patch")==identity["sourcePatchSHA256"]
for role,entries in identity["imageFiles"].items():
    assert {p.name:sha(p) for p in (lab/role).iterdir()}==entries
subprocess.run(["git","-C",tree,"add","-N","--","tests/Lokad.Lython.Tests/IterationWorkspaceLifetimeTests.cs"],check=True)
(lab/"test.patch").write_bytes(subprocess.check_output(["git","-C",tree,"diff","--binary","--","tests"]))
status=read(quiet/"terminal-status.json")
assert not status["live"] and not status["fixtures"]
assert sha(out/"quiet-observations.tar.xz")==status["receipt"]["archiveSHA256"]
for name in ("allocation-summary.json","compile-allocation-summary.json","route-summary.json"):
    shutil.copyfile(lab/name,out/name)
shutil.copyfile(quiet/"identity.json",out/"identity.json")
names=[
 "package.py","freeze.py","prepare.py","quiet.py","archive.py","find-archived-duplicates.py","test-ubuntu.sh",
 "test-loan-ubuntu.sh","candidate.patch","candidate-build.log","probe.log","test.patch",
 "windows-Lokad.Lython.Tests.log","windows-Lokad.Lython.PublicApi.Tests.log",
 "ubuntu-net10-Lokad.Lython.Tests.log","ubuntu-net10-Lokad.Lython.PublicApi.Tests.log",
 "windows-loan.log","windows-loan-fixture.log","ubuntu-loan.log","ubuntu-loan-fixture.log",
 "archived-duplicates.json","verified-raw-replicas.json","allocations.py","compile-allocation.py",
 "reference-allocation-final.json","candidate-allocation-final.json","reference-compiler-owner.json","candidate-compiler-owner.json",
 "comparison/reference-verify.json","comparison/candidate-verify.json","comparison/quiet/upload.json",
 "comparison/quiet/storage-custody.json","comparison/quiet/launch.log","route.py","route/Program.cs","route/RouteProbe.csproj",
 "route/cases.json","route/reference.patch","route/candidate.patch","route/reference-build.log","route/candidate-build.log",
 "route/probe-build.log","route/reference-rows.json","route/candidate-rows.json",
]
with tarfile.open(out/"procedures.tar.xz","w:xz") as archive:
    for name in names: archive.add(lab/name,arcname=name,recursive=False)
with tarfile.open(out/"procedures.tar.xz") as archive:
    assert archive.getnames()==names
    assert all(hashlib.sha256(archive.extractfile(name).read()).hexdigest()==sha(lab/name) for name in names)
print("Archived source, test and route evidence.")
