from pathlib import Path
import json,subprocess
r=Path('.git/agent-notes/review-20261031/arithmetic-r405/checkpoint')
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
s='''from pathlib import Path
import fcntl,hashlib,json,shutil,subprocess,tarfile
root=Path('/home/lokad/lython-bench-checks/arithmetic-cpython-b792-20261115')
with(root.parent/'comparison-vm.lock').open('a')as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record|[p]ython3.*cpython-worker.py'],capture_output=True).returncode==1
 assert not(root/'guest-fixtures').exists()
 raw=json.loads((root/'confirmation/confirmation.json').read_text());assert raw['complete']and len(raw['jobs'])==8 and all(j['workersJoinedAndFixturesRemoved']for j in raw['jobs'])
 assert all(json.loads((root/'confirmation'/n).read_text())['gate']['quiet']for n in ['machine-before.json','machine-after.json'])
 with tarfile.open(root/'observations.tgz')as a:
  assert a.extractfile('confirmation/confirmation.json').read()==(root/'confirmation/confirmation.json').read_bytes()
  for m in a.getmembers():
   if m.isfile():assert a.extractfile(m).read()==(root/m.name).read_bytes(),m.name
 data=dict(complete=True,jobs=8,elapsedSeconds=raw['elapsedSeconds'],allWorkersJoined=True,guestFixturesRemoved=True,quietBeforeAndAfter=True,archivedAndVerifiedUnderFreshLeaseAfterOriginalFloorRefusal=True,originalOwnerTerminalFailed=True,archiveSHA256=hashlib.sha256((root/'observations.tgz').read_bytes()).hexdigest(),archiveBytes=(root/'observations.tgz').stat().st_size,freeBytesAfterArchive=shutil.disk_usage(root).free,archiveFloorBytes=252*1024*1024,performanceQualified=False)
 (root/'recovered-archive-receipt.json').write_text(json.dumps(data,indent=2)+'\\n');print(json.dumps(data))
'''
p=subprocess.run(ssh+['python3 -'],input=s,capture_output=True,text=True,encoding='utf-8',timeout=30);(r/'archive-recovery-check.json').write_text(p.stdout,encoding='utf-8');assert p.returncode==0,p.stdout+p.stderr;print(p.stdout)
scp=['C:/Windows/System32/OpenSSH/scp.exe','-i',ssh[2],'-o','BatchMode=yes','-o','ConnectTimeout=15']
for n in ['observations.tgz','recovered-archive-receipt.json']:
 p=subprocess.run(scp+['lokad@20.166.121.73:/home/lokad/lython-bench-checks/arithmetic-cpython-b792-20261115/'+n,str(r/n)],capture_output=True,text=True,encoding='utf-8',timeout=45);assert p.returncode==0,p.stderr
