from pathlib import Path
import datetime,hashlib,json,subprocess
r=Path('.git/agent-notes/review-20261031/arithmetic-r405/checkpoint')
old=(r/'run.sh').read_bytes();assert b'\r\n' in old
new=old.replace(b'\r\n',b'\n');(r/'original-failed-run.sh').write_bytes(old);(r/'run.sh').write_bytes(new)
config=dict(oldSHA256=hashlib.sha256(old).hexdigest(),newSHA256=hashlib.sha256(new).hexdigest(),content=new.decode(),newUnit='lython-b792-corrected-arithmetic-cpython-20261115')
s='''from pathlib import Path
import fcntl,hashlib,json,os,subprocess
config=CONFIG
root=Path('/home/lokad/lython-bench-checks/arithmetic-cpython-b792-20261115')
with(root.parent/'comparison-vm.lock').open('a')as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 state=subprocess.check_output(['systemctl','show','lython-b792-arithmetic-cpython-20261115.service','--property=ActiveState,SubState,MainPID,Result,ExecMainStatus'],text=True)
 assert 'MainPID=0'in state and 'ActiveState=failed'in state and 'ExecMainStatus=2'in state
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record|[p]ython3.*cpython-worker.py'],capture_output=True).returncode==1
 assert not(root/'confirmation').exists()
 assert hashlib.sha256((root/'run.sh').read_bytes()).hexdigest()==config['oldSHA256']
 (root/'original-failed-run.sh').write_bytes((root/'run.sh').read_bytes())
 journal=subprocess.check_output(['journalctl','-u','lython-b792-arithmetic-cpython-20261115.service','--no-pager'],text=True)
 (root/'original-failed-launch.txt').write_text(state+journal)
 (root/'run.sh').write_bytes(config['content'].encode())
 assert hashlib.sha256((root/'run.sh').read_bytes()).hexdigest()==config['newSHA256']
 subprocess.run(['/bin/sh','-n',str(root/'run.sh')],check=True)
 assert os.path.ismount(root/'guest-fixtures')and not list((root/'guest-fixtures').iterdir())
 print(json.dumps(dict(originalFailurePreserved=True,noWorkerStarted=True,onlyLineEndingsCorrected=True,newUnit=config['newUnit'])))
subprocess.run(['sudo','-n','systemd-run','--unit='+config['newUnit'],'--property=User=lokad','--property=WorkingDirectory='+str(root),'--property=RuntimeMaxSec=400','--property=TimeoutStopSec=30','--property=KillMode=control-group','/bin/sh',str(root/'run.sh')],check=True)
'''.replace('CONFIG',repr(config))
(r/'repair-line-endings.py').write_text(s,encoding='utf-8',newline='\n')
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
p=subprocess.run(ssh+['python3 -'],input=s,capture_output=True,text=True,encoding='utf-8',timeout=30);(r/'corrected-launch.log').write_text(p.stdout+p.stderr,encoding='utf-8');assert p.returncode==0,p.stdout+p.stderr
# Retrieval targets the corrected service, same owned root; never observe the original terminal unit again.
f=r/'retrieve.py';f.write_text(f.read_text(encoding='utf-8').replace('lython-b792-arithmetic-cpython-20261115.service','lython-b792-corrected-arithmetic-cpython-20261115.service'),encoding='utf-8',newline='\n')
now=datetime.datetime.now(datetime.timezone.utc);(r/'observe-not-before.json').write_text(json.dumps(dict(startedUTC=now.isoformat(),doNotObserveBeforeUTC=(now+datetime.timedelta(seconds=340)).isoformat(),ownerSeconds=400,service=config['newUnit']),indent=2)+'\n',encoding='utf-8',newline='\n')
print(p.stdout+p.stderr);print('Observe corrected owner after',now+datetime.timedelta(seconds=340))
