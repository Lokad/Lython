from pathlib import Path
import fcntl,hashlib,json,os,subprocess
config={'oldSHA256': 'c6cdbdd305f72c870037e3959fe6d584ceca1f67b83fb4c3c7f797afea7a4b3d', 'newSHA256': '34131b9f2f44542f2e0318201f3eb67a44cebf24b32af46cb658b2ac419cb8da', 'content': 'set -eu\nroot=/home/lokad/lython-bench-checks/arithmetic-cpython-b792-20261115\ntrap \'result=$?; printf "%s\\n" "$result" > "$root/exit-code.txt"\' EXIT\npython3 "$root/collect.py"\n', 'newUnit': 'lython-b792-corrected-arithmetic-cpython-20261115'}
root=Path('/home/lokad/lython-bench-checks/arithmetic-cpython-b792-20261115')
with(root.parent/'comparison-vm.lock').open('a')as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 state=subprocess.check_output(['systemctl','show','lython-b792-arithmetic-cpython-20261115.service','--property=ActiveState,SubState,MainPID,Result,ExecMainStatus'],text=True)
 assert 'MainPID=0'in state and 'ActiveState=failed'in state and 'ExecMainStatus=2'in state
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record|[p]ython3.*cpython-worker.py'],capture_output=True).returncode==1
 assert not(root/'confirmation').exists()
 assert hashlib.sha256((root/'run.sh').read_bytes()).hexdigest()==config['oldSHA256']
 (root/'original-failed-run.sh').write_bytes((root/'run.sh').read_bytes())
 journal=subprocess.check_output(['journalctl','-u','lython-b792-arithmetic-cpython-20261115.service','--no-pager'],text=True)
 (root/'original-failed-launch.txt').write_text(state+journal)
 (root/'run.sh').write_bytes(config['content'].encode())
 assert hashlib.sha256((root/'run.sh').read_bytes()).hexdigest()==config['newSHA256']
 subprocess.run(['/bin/sh','-n',str(root/'run.sh')],check=True)
 assert os.path.ismount(root/'guest-fixtures')and not list((root/'guest-fixtures').iterdir())
 print(json.dumps(dict(originalFailurePreserved=True,noWorkerStarted=True,onlyLineEndingsCorrected=True,newUnit=config['newUnit'])))
subprocess.run(['sudo','-n','systemd-run','--unit='+config['newUnit'],'--property=User=lokad','--property=WorkingDirectory='+str(root),'--property=RuntimeMaxSec=400','--property=TimeoutStopSec=30','--property=KillMode=control-group','/bin/sh',str(root/'run.sh')],check=True)
