from pathlib import Path
import ast,datetime,hashlib,io,json,shlex,subprocess,tarfile
base=Path('.git/agent-notes/review-20261031');r=base/'arithmetic-r405/checkpoint';partial=json.loads((r/'partial-config.json').read_text(encoding='utf-8'));identity=partial['identity'];head=partial['head']
catalog=json.loads((base/'arithmetic-r405/quiet/retrieved/representative.json').read_text(encoding='utf-8'))
extra=json.loads((base/'arithmetic-r405/quiet/retrieved/additional.json').read_text(encoding='utf-8'))
for case in extra['cases']:
 if case['id']=='scripts.config-manifest.small' and not any(c['id']==case['id'] for c in catalog['cases']):catalog['cases'].append(case)
assert all(any(c['id']==n for c in catalog['cases'])for n in ['scripts.csv-invoice.large','scripts.csv-fulfillment.large','scripts.text-summary-helpers.nonlocal-counter.large','scripts.json-summary.large','scripts.file-search.large.protected','scripts.config-manifest.small'])
(r/'checkpoint-catalog.json').write_text(json.dumps(catalog,indent=2)+'\n',encoding='utf-8');identity['catalogSHA256']=hashlib.sha256((r/'checkpoint-catalog.json').read_bytes()).hexdigest()
(r/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8')
with tarfile.open(r/'payload.tgz','w:gz') as t:
 for n in ['identity.json','checkpoint-catalog.json','collect.py','archive-owned.py','run.sh']:t.add(r/n,arcname=n)
retire=[]
for remote,canonical,member in [
 ('arithmetic-controls-b791-20261115/observations.tgz','benchmarks/results/2026-11-15-completed-arithmetic/confirmation/observations.tgz',None),
 ('arithmetic-controls-b791-20261115/confirmation/confirmation.json','benchmarks/results/2026-11-15-completed-arithmetic/confirmation/observations.tgz','confirmation/confirmation.json'),
 ('arithmetic-b790-20261115/observations.tgz','benchmarks/results/2026-11-15-completed-arithmetic/observations.tgz',None)]:
 committed=subprocess.check_output(['git','show',head+':'+canonical]);assert committed==Path(canonical).read_bytes()
 if member:
  with tarfile.open(fileobj=io.BytesIO(committed))as t:data=t.extractfile(member).read()
 else:data=committed
 retire.append(dict(path=remote,bytes=len(data),sha256=hashlib.sha256(data).hexdigest(),canonicalCommit=head,canonicalPath=canonical,archiveSHA256=hashlib.sha256(committed).hexdigest(),member=member))
config=dict(root='/home/lokad/lython-bench-checks/arithmetic-cpython-b792-20261115',source='/home/lokad/lython-bench-checks/arithmetic-b790-20261115',unit='lython-b792-arithmetic-cpython-20261115',identity=identity,payloadBytes=(r/'payload.tgz').stat().st_size,payloadSHA256=hashlib.sha256((r/'payload.tgz').read_bytes()).hexdigest(),retire=retire)
(r/'config.json').write_text(json.dumps(config,indent=2)+'\n',encoding='utf-8')
# Reuse the earlier finite checkpoint launcher; only custody-verified duplicate retirement is added.
s=(base/'csv-cpython-r399/launch-command.py').read_text(encoding='utf-8');start=s.index('config=');end=s.index('\nbase=',start);s=s[:start]+'config='+repr(config)+s[end:]
s=s.replace('import fcntl,hashlib,io,json,os,shutil,subprocess,sys,tarfile','import fcntl,hashlib,io,json,os,shutil,stat,subprocess,sys,tarfile')
s=s.replace(" assert sha(source/'representative.json')==config['identity']['catalogSHA256']\n",'')
s=s.replace(" assert shutil.disk_usage(base).free>254*1024*1024+65536\n",'')
needle=" root.mkdir()\n";assert needle in s
s=s.replace(needle,""" paths=[]
 for proof in config['retire']:
  p=base/proof['path'];m=p.lstat()
  assert p.resolve()==p and p.is_relative_to(base) and stat.S_ISREG(m.st_mode) and m.st_uid==os.getuid() and m.st_nlink==1 and m.st_size==proof['bytes'] and sha(p)==proof['sha256']
  paths.append(p)
 assert shutil.disk_usage(base).free+sum(p.stat().st_size for p in paths)>254*1024*1024+262144
 for p in paths:p.unlink()
 root.mkdir()
""",1)
s=s.replace(" os.link(source/'representative.json',root/'representative.json');os.link(source/'cpython-worker.py',root/'cpython-worker.py')"," assert sha(root/'checkpoint-catalog.json')==config['identity']['catalogSHA256']\n (root/'retirement-receipt.json').write_text(json.dumps(dict(retiredOnly=config['retire'],canonicalBytesVerifiedLocally=True,pathsHashesOwnershipLinksVerified=True,quietLease=True,freeBytes=shutil.disk_usage(base).free),indent=2)+'\\n')\n os.link(source/'cpython-worker.py',root/'cpython-worker.py')")
s=s.replace('lython-b784-fixtures','lython-b792-fixtures').replace('RuntimeMaxSec=240','RuntimeMaxSec=400')
ast.parse(s);(r/'launch-command.py').write_text(s,encoding='utf-8')
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
p=subprocess.run(ssh+['python3 -c '+shlex.quote(s)],input=(r/'payload.tgz').read_bytes(),capture_output=True,timeout=45)
(r/'launch.log').write_bytes(p.stdout+p.stderr);assert p.returncode==0,(p.stdout+p.stderr).decode('utf-8','replace')
now=datetime.datetime.now(datetime.timezone.utc)
(r/'observe-not-before.json').write_text(json.dumps(dict(startedUTC=now.isoformat(),doNotObserveBeforeUTC=(now+datetime.timedelta(seconds=340)).isoformat(),ownerSeconds=400),indent=2)+'\n',encoding='utf-8')
print((p.stdout+p.stderr).decode());print('Observe same B792 after',now+datetime.timedelta(seconds=340))
