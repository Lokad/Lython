from pathlib import Path
import ast,datetime,hashlib,json,subprocess,tarfile
base=Path('.git/agent-notes/review-20261031');r=base/'arithmetic-r405/checkpoint';r.mkdir()
prior=base/'csv-cpython-r399';head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
identity=json.loads((base/'arithmetic-r405/quiet/identity.json').read_text(encoding='utf-8'))
identity.update(sourceRevision=head+'/frozen9e890d18; complete source proof in arithmetic-r405/delivery',runtimeCommit=head,purpose='Representative delivery checkpoint: compilation, warm and compile-to-result; complete CSV/text/JSON/file/config scripts through unchanged workers.',coreSHA256={k:v for k,v in identity['coreSHA256'].items() if k.startswith('candidate')},qualification='Committed/pushed43bce13a, focused actual11/10 passed; full platform/stress/installed-consumer run active',roleMeaning=dict(candidate=head[:8],**{'candidate-control':head[:8]}))
identity.pop('referenceDelivery',None)
(r/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8')
oldjobs="jobs=[['scripts.csv-invoice.large','warm'],['scripts.csv-invoice.large','compile'],['scripts.csv-invoice.large','compile-run'],['scripts.csv-fulfillment.large','warm']]"
newjobs="jobs=[['scripts.csv-invoice.large','warm'],['scripts.csv-invoice.large','compile'],['scripts.csv-invoice.large','compile-run'],['scripts.csv-fulfillment.large','warm'],['scripts.text-summary-helpers.nonlocal-counter.large','warm'],['scripts.json-summary.large','warm'],['scripts.file-search.large.protected','warm'],['scripts.config-manifest.small','compile-run']]"
for name in ['collect.py','archive-owned.py','run.sh','retrieve.py','summarize.py']:
 s=(prior/name).read_text(encoding='utf-8').replace('csv-cpython-b784-20261115','arithmetic-cpython-b792-20261115').replace('lython-b784-csv-cpython-20261115','lython-b792-arithmetic-cpython-20261115').replace('lython-b784-fixtures','lython-b792-fixtures').replace('B784','B792')
 s=s.replace(oldjobs,newjobs).replace('len(jobs)==4','len(jobs)==8').replace("len(raw['jobs'])==4","len(raw['jobs'])==8").replace("['jobs']==4","['jobs']==8").replace('jobs=4','jobs=8').replace("elapsedSeconds']<240","elapsedSeconds']<400").replace(' < 180,',' < 330,')
 if name=='collect.py':
  assert newjobs in s
  s=s.replace("catalog = root / 'representative.json'","catalog = root / 'checkpoint-catalog.json'")
  s=s.replace('else 5); rows=[]','else (8 if lane=="compile-run" else 5)); rows=[]')
  s=s.replace('warmupSeconds=5, capturedWarmupSeconds=12, compilationWarmupSeconds=5','warmupSeconds=5, capturedWarmupSeconds=12, freshWarmupSeconds=8, compilationWarmupSeconds=5')
 if name.endswith('.py'):ast.parse(s)
 (r/name).write_text(s,encoding='utf-8')
# One existing additional case joins the unchanged representative catalog; source/goldens stay exact.
catalog=json.loads((base/'arithmetic-r405/frozen/catalog.json').read_text(encoding='utf-8'))
extra=json.loads((base/'arithmetic-r405/quiet/retrieved/additional.json').read_text(encoding='utf-8'))
print('Catalog cases',len(catalog['cases']),'extra',list(extra) if isinstance(extra,dict) else type(extra))
(r/'partial-config.json').write_text(json.dumps(dict(head=head,identity=identity),indent=2)+'\n',encoding='utf-8')
