set -eu
root=/home/lokad/lython-bench-checks/arithmetic-cpython-b792-20261115
trap 'result=$?; printf "%s\n" "$result" > "$root/exit-code.txt"' EXIT
python3 "$root/collect.py"
