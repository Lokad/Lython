#!/bin/bash
set -euo pipefail
cd /mnt/d/code/Lython/.git/agent-worktrees/native-single-capture-construction-20261122
export DOTNET_ROOT="$HOME/.dotnet"
export PATH="$DOTNET_ROOT:$PATH"
dir=/mnt/d/code/Lython/.git/agent-notes/review-20261031/native-single-capture-construction-20261122
white='Category!=Stress&(FullyQualifiedName~AsyncExecutableFunction|FullyQualifiedName~NativeClosureSequence|FullyQualifiedName~NativeFunctionRefund|FullyQualifiedName~ConstructorOwnership|FullyQualifiedName~ManagedStack|FullyQualifiedName~CapturedScalar|FullyQualifiedName~CasedSplitOwnership)'
public='Category!=Stress&(FullyQualifiedName~FunctionDefault|FullyQualifiedName~FramedFunction|FullyQualifiedName~NativeCallback|FullyQualifiedName~RangeSlotTransport|FullyQualifiedName~Captured|FullyQualifiedName~ClassMethod)'
dotnet test tests/Lokad.Lython.Tests -c Release -f net10.0 --filter "$white" --verbosity quiet > "$dir/white-ubuntu.log" 2>&1 || { tail -30 "$dir/white-ubuntu.log"; exit 1; }
dotnet test tests/Lokad.Lython.PublicApi.Tests -c Release -f net10.0 --filter "$public" --verbosity quiet > "$dir/public-ubuntu.log" 2>&1 || { tail -30 "$dir/public-ubuntu.log"; exit 1; }
grep -H 'Passed!' "$dir/white-ubuntu.log" "$dir/public-ubuntu.log"
