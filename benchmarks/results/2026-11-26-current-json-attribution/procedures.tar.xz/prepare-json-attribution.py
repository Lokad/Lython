from pathlib import Path
import re, subprocess, sys

base=Path(__file__).resolve().parent.parent
source=base/'post-update-shipment-profile-20261126'/'prepare.py'
lab=base/'post-update-json-attribution-20261126'
lab.mkdir(exist_ok=True)
script=source.read_text(encoding='utf-8')
for old,new in (
 ('head=subprocess.check_output(["git","rev-parse","HEAD"],cwd=repo).decode().strip()\nassert head==read(checkpoint/"identity.json")["productionSource"]',
  'head=read(checkpoint/"identity.json")["productionSource"]\nsubprocess.run(["git","diff","--exit-code",head,"--","src"],cwd=repo,check=True)'),
 ('shipment="diagnostic.shipment-routing-callbacks"\ntext="diagnostic.text-summary.nonlocal-computed-width.large"\ncatalog["cases"]=[case for case in catalog["cases"] if case["id"] in {shipment,text}]',
  'shipment="diagnostic.json-service-quantity-totals"\ntext="scripts.json-summary-helpers.large"\nlines=read(repo/"benchmarks/results/2026-11-17-json-record-costs/catalog.json")\ncatalog["cases"]=[next(case for case in catalog["cases"] if case["id"]==shipment), next(case for case in lines["cases"] if case["id"]==text)]'),
 ('"shipment-after-update-async"','"json-service-totals"'),
 ('"unicode-text-control-async"','"json-lines-helpers"'),
 ('Locate remaining shipment work after the complete dictionary update.',
  'Attribute JSON document totals and JSON Lines helper costs after the complete dictionary update.'),
 ('"b1752-fixtures","b1765-fixtures"','"b1752-fixtures","b1767-fixtures"'),
 ('lython-b1765-post-update-shipment-profile-20261126','lython-b1767-post-update-json-attribution-20261126'),
 ('post-update-shipment-profile-b1765-20261126','post-update-json-attribution-b1767-20261126'),
 ('12*1024*1024','8*1024*1024')):
    assert old in script,old
    script=script.replace(old,new)
target=lab/'prepare.py'
target.write_text(script,encoding='utf-8',newline='\n')
subprocess.run([sys.executable,'-X','utf8',target],check=True)
out=lab/'comparison/quiet/analyze.py'
analyzer=out.read_text(encoding='utf-8')
key="     'numeric conversion':"
assert analyzer.count(key)==1
analyzer=analyzer.replace(key,'''     'JSON construction': ('PushJsonContainer','AcceptJsonValue','FinishJsonContainer','ContinueJsonConstruction','ReadJsonContainerAsync','AppendJsonContainerValue'),
     'JSON text and keys': ('ReadJsonString','ReadJsonObjectKey','MatchDelimitedName','FindName','ShareRecordKeys','SetRecordItem'),
     'JSON scalar tokens': ('TryReadJsonScalar','ReadDefaultJsonNumber','ReadJsonNumber','TryParseJsonInteger','TryMatchJson'),
     'complete dictionary updates': ('CompleteConvertedDictionary','TryCompleteConverted','TryAccumulate'),
''' +key)
compile(analyzer,'analyze.py','exec')
out.write_text(analyzer,encoding='utf-8',newline='\n')
