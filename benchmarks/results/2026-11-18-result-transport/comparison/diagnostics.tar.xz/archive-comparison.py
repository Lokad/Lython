from pathlib import Path
import gzip
import hashlib
import json
import re
import shutil
import tarfile

lab = Path(__file__).resolve().parent
out = Path('D:/code/Lython/benchmarks/results/2026-11-18-result-transport/comparison')
quiet = lab / 'quiet'
read_json = lambda path: json.loads(path.read_text(encoding='utf-8-sig'))
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
receipt = read_json(quiet / 'archive-receipt.json')
assert receipt['complete'] and receipt['jobs'] == 5
assert sha(quiet / 'observations.tgz') == receipt['archiveSHA256']
assert not (out / 'observations.tgz').exists()
for name in ['summary.json', 'allocation-summary.json', 'frozen-identity.json']:
    shutil.copyfile(lab / name, out / name)
for name in ['observations.tgz', 'archive-receipt.json', 'terminal-status.json']:
    shutil.copyfile(quiet / name, out / name)
candidate = lab / 'frozen/candidate/Lokad.Lython.dll'
assert sha(candidate) == read_json(lab / 'identity.json')['candidateCores']['net11.0']
(out / 'candidate-core.dll.gz').write_bytes(gzip.compress(candidate.read_bytes(), mtime=0))

assembly = {}
for role in ('reference', 'candidate'):
    text = (lab / (role + '-call.asm')).read_text(encoding='utf-8')
    sections = text.split('; Assembly listing for method ')
    complete = [part for part in sections if part.startswith('Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Call(byref):bool:this (Tier1)') and '; Total bytes of code ' in part]
    assert len(complete) == 1, len(complete)
    assembly[role] = int(re.search(r'; Total bytes of code (\d+)', complete[0])[1])
assert assembly == dict(reference=3488, candidate=3428)
diagnostic = read_json(lab / 'diagnostics.json')
for role, row in diagnostic['rows'].items():
    row['completeTier1NativeCallBytes'] = assembly[role]
    del row['bodies']  # Ignore the incomplete listing left by the diagnostic timeout.
assert diagnostic['rows']['reference']['compileAllocatedBytes'] == diagnostic['rows']['candidate']['compileAllocatedBytes']
(out / 'diagnostics.json').write_text(json.dumps(diagnostic, indent=2) + '\n', encoding='utf-8')
with tarfile.open(out / 'diagnostics.tar.xz', 'w:xz') as archive:
    for name in ['prepare.py', 'space.py', 'observation-space.py', 'stage.py', 'launch.py', 'summarize.py', 'diagnose.py', 'archive-comparison.py', 'space.json', 'diagnostic-initial.stderr', 'diagnostic-initial.stdout', 'diagnostic-60s-timeout.asm']:
        archive.add(lab / name, arcname=name)
    for role in ('reference', 'candidate'):
        for suffix in ('goldens.json', 'measurement.json', 'allocation.json', 'compile-allocation.json', 'call.asm', 'call.stdout', 'call.stderr'):
            name = role + '-' + suffix
            archive.add(lab / name, arcname=name)
    for name in ('config.json', 'collect.py', 'archive-owned.py', 'run.sh', 'remote-launch.py', 'retrieve.py', 'launch.log'):
        archive.add(quiet / name, arcname='quiet/' + name)
print('Archived comparison', receipt['archiveSHA256'], 'and verified disassembly', assembly)
