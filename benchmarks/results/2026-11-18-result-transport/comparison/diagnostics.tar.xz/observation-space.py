from pathlib import Path
import hashlib
import io
import json
import subprocess
import tarfile
from space import remote

lab = Path(__file__).resolve().parent
repo = Path('D:/code/Lython')
archived = [
    ('primitive-helper-delivery', 'b475', 'primitive-proof-b475-20261108'),
    ('integer-helper-prototype', 'b473', 'primitive-helpers-b473-20261108'),
    ('local-publication', 'b472', 'local-publication-b472-20261108'),
]
choices = []
for result, folder, vm_folder in archived:
    canonical = f'benchmarks/results/2026-11-08-{result}/observations.tar.xz'
    blob = (repo / canonical).read_bytes()
    assert blob == subprocess.check_output(['git', 'show', 'HEAD:' + canonical], cwd=repo)
    member = folder + '/observations.tgz'
    with tarfile.open(fileobj=io.BytesIO(blob)) as archive:
        data = archive.extractfile(member).read()
    members = [(member, 'observations.tgz', data)]
    if folder == 'b475':
        with tarfile.open(fileobj=io.BytesIO(data)) as archive:
            raw_member = 'confirmation/confirmation.json'
            members.append((member + '::' + raw_member, raw_member, archive.extractfile(raw_member).read()))
    for source, name, content in members:
        choices.append(dict(kind='archived observation replica', canonical=canonical,
                            canonicalSHA256=hashlib.sha256(blob).hexdigest(), sha256=hashlib.sha256(content).hexdigest(),
                            member=source, committedBlobVerified=True, bytes=len(content),
                            paths=[vm_folder + '/' + name], links=1))
script = '''from pathlib import Path
import fcntl, hashlib, json, os, shutil, stat
root = Path('/home/lokad/lython-bench-checks').resolve()
choices = CHOICES
with (root / 'comparison-vm.lock').open('a') as lease:
    fcntl.flock(lease, fcntl.LOCK_EX | fcntl.LOCK_NB)
    eligible = []
    for row in choices:
        path = root / row['paths'][0]
        if not path.exists():
            continue
        info = path.lstat()
        assert path.resolve() == path and stat.S_ISREG(info.st_mode) and info.st_uid == os.getuid()
        assert info.st_size == row['bytes'] and info.st_nlink == row['links']
        assert hashlib.sha256(path.read_bytes()).hexdigest() == row['sha256']
        eligible.append(row)
    print(json.dumps(dict(freeBytes=shutil.disk_usage(root).free, choices=eligible)))
'''.replace('CHOICES', repr(choices))
state = json.loads(remote(script))
(lab / 'space.json').write_text(json.dumps(state, indent=2) + '\n', encoding='utf-8')
print('Free bytes:', state['freeBytes'], 'Exact committed observation replicas:', [(v['paths'][0], v['bytes']) for v in state['choices']])
