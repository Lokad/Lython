; Assembly listing for method Lokad.Lython.Frontend.ExecutableInstruction:Call(int,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Frontend.ExecutableInstruction (Tier0)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; Tier0 code
; rbp based frame
; partially interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 96
       lea      rbp, [rsp+0x60]
       vxorps   xmm4, xmm4, xmm4
       vmovdqu  ymmword ptr [rbp-0x20], ymm4
       mov      qword ptr [rbp+0x10], rcx
       mov      dword ptr [rbp+0x18], edx
       mov      gword ptr [rbp+0x20], r8
 
G_M000_IG02:                ;; offset=0x001E
       mov      dword ptr [rsp+0x20], 0x7FFFFFFF
       mov      dword ptr [rsp+0x28], 0x7FFFFFFF
       mov      dword ptr [rsp+0x30], -1
       xor      eax, eax
       mov      dword ptr [rsp+0x38], eax
       lea      rcx, [rbp-0x20]
       mov      r9d, dword ptr [rbp+0x18]
       mov      r8, gword ptr [rbp+0x20]
       mov      edx, 44
       call     [Lokad.Lython.Frontend.ExecutableInstruction:.ctor(int,Lokad.Lython.LythonSourceSpan,int,int,int,int,int):this]
       mov      rax, qword ptr [rbp+0x10]
 
G_M000_IG03:                ;; offset=0x0057
       vmovdqu  ymm0, ymmword ptr [rbp-0x20]
       vmovdqu  ymmword ptr [rax], ymm0
 
G_M000_IG04:                ;; offset=0x0060
       mov      rax, qword ptr [rbp+0x10]
 
G_M000_IG05:                ;; offset=0x0064
       vzeroupper 
       add      rsp, 96
       pop      rbp
       ret      
 
; Total bytes of code 109

; Assembly listing for method Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Call(byref):bool:this (Tier0)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; Tier0 code
; rbp based frame
; fully interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 640
       lea      rbp, [rsp+0x280]
       xor      eax, eax
       mov      qword ptr [rbp-0x248], rax
       vxorps   xmm4, xmm4, xmm4
       mov      rax, -576
 
G_M000_IG45:                ;; offset=0x0027
       vmovdqa  xmmword ptr [rax+rbp], xmm4
       vmovdqa  xmmword ptr [rbp+rax+0x10], xmm4
       vmovdqa  xmmword ptr [rbp+rax+0x20], xmm4
       add      rax, 48
       jne      SHORT G_M000_IG45
       mov      bword ptr [rbp+0x10], rcx
       mov      bword ptr [rbp+0x18], rdx
 
G_M000_IG02:                ;; offset=0x0046
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax+0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_CallSites():System.Collections.Generic.IReadOnlyList`1[Lokad.Lython.Frontend.ExecutableCallSite]:this]
       mov      gword ptr [rbp-0xB0], rax
       mov      rcx, bword ptr [rbp+0x18]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_CallSiteIndex():int:this]
       mov      dword ptr [rbp-0x1D4], eax
       mov      edx, dword ptr [rbp-0x1D4]
       mov      rcx, gword ptr [rbp-0xB0]
       mov      r11, 0x7FF9C8D020F8
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       mov      gword ptr [rbp-0x08], rax
       mov      rcx, bword ptr [rbp+0x18]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x0C], eax
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       add      rax, 80
       mov      bword ptr [rbp-0xB8], rax
       mov      rcx, gword ptr [rbp-0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_TargetOffset():int:this]
       add      eax, dword ptr [rbp-0x0C]
       mov      dword ptr [rbp-0xBC], eax
       mov      rax, bword ptr [rbp-0xB8]
       mov      eax, dword ptr [rax+0x08]
       cmp      dword ptr [rbp-0xBC], eax
       jae      G_M000_IG34
       mov      rax, bword ptr [rbp-0xB8]
       mov      ecx, dword ptr [rbp-0xBC]
       shl      rcx, 4
       add      rcx, bword ptr [rax]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Object():System.Object:this]
       mov      gword ptr [rbp-0x1E0], rax
       mov      rdx, gword ptr [rbp-0x1E0]
       mov      rcx, 0x7FF9C9788A60
       call     [Lokad.Lython.Internal.NullabilityExtensions:RequireNotNull[System.__Canon](System.__Canon):System.__Canon]
       mov      gword ptr [rbp-0x18], rax
       vxorps   xmm0, xmm0, xmm0
       vmovdqu  xmmword ptr [rbp-0x28], xmm0
 
G_M000_IG03:                ;; offset=0x011D
       mov      rcx, gword ptr [rbp-0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_IsPositionalOnly():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG04
       lea      rax, [rbp-0x28]
       mov      qword ptr [rsp+0x20], rax
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rbp-0x08]
       mov      r8d, dword ptr [rbp-0x0C]
       mov      r9, gword ptr [rbp-0x18]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:CallFunction(Lokad.Lython.Frontend.ExecutableCallSite,int,System.Object,byref):bool:this]
       test     eax, eax
       jne      G_M000_IG30
       xor      eax, eax
       mov      dword ptr [rbp-0x2C], eax
       jmp      G_M000_IG32
 
G_M000_IG04:                ;; offset=0x015E
       mov      rcx, gword ptr [rbp-0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_HasReceiver():bool:this]
       test     eax, eax
       jne      G_M000_IG08
       mov      rcx, gword ptr [rbp-0x18]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:IsRangeBuiltin(System.Object):bool]
       test     eax, eax
       je       G_M000_IG08
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       add      rax, 80
       mov      bword ptr [rbp-0x190], rax
       mov      rcx, gword ptr [rbp-0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_ArgumentOffset():int:this]
       add      eax, dword ptr [rbp-0x0C]
       mov      dword ptr [rbp-0x194], eax
       mov      rcx, gword ptr [rbp-0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_ArgumentCount():int:this]
       mov      dword ptr [rbp-0x1E4], eax
       mov      r9d, dword ptr [rbp-0x1E4]
       lea      rdx, [rbp-0x1A8]
       mov      r8d, dword ptr [rbp-0x194]
       mov      rcx, bword ptr [rbp-0x190]
       call     [System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:Slice(int,int):System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:this]
 
G_M000_IG05:                ;; offset=0x01E2
       vmovdqu  xmm0, xmmword ptr [rbp-0x1A8]
       vmovdqu  xmmword ptr [rbp-0x1F8], xmm0
 
G_M000_IG06:                ;; offset=0x01F2
       mov      rcx, gword ptr [rbp-0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_CallSpan():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x200], rax
       mov      rdx, gword ptr [rbp-0x200]
       lea      rcx, [rbp-0x1F8]
       lea      r9, [rbp-0x38]
       mov      rax, bword ptr [rbp+0x10]
       mov      r8, gword ptr [rax+0x18]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryInvokeNativeRange(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       test     eax, eax
       jne      SHORT G_M000_IG07
       xor      eax, eax
       mov      dword ptr [rbp-0x2C], eax
       jmp      G_M000_IG32
 
G_M000_IG07:                ;; offset=0x0233
       lea      rcx, [rbp-0x28]
       mov      rdx, gword ptr [rbp-0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:set_Object(System.Object):this]
       jmp      G_M000_IG30
 
G_M000_IG08:                ;; offset=0x0246
       mov      rcx, gword ptr [rbp-0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_HasReceiver():bool:this]
       test     eax, eax
       je       G_M000_IG22
       mov      rdx, gword ptr [rbp-0x18]
       mov      rcx, 0x7FF9C972D7A8
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      gword ptr [rbp-0x40], rax
       cmp      gword ptr [rbp-0x40], 0
       je       G_M000_IG22
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       add      rax, 80
       mov      bword ptr [rbp-0xE8], rax
       mov      rax, bword ptr [rbp-0xE8]
       mov      eax, dword ptr [rax+0x08]
       cmp      dword ptr [rbp-0x0C], eax
       jae      G_M000_IG29
       mov      rax, bword ptr [rbp-0xE8]
       mov      ecx, dword ptr [rbp-0x0C]
       shl      rcx, 4
       add      rcx, bword ptr [rax]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Object():System.Object:this]
       mov      gword ptr [rbp-0x48], rax
       mov      rcx, gword ptr [rbp-0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_ArgumentCount():int:this]
       test     eax, eax
       jne      G_M000_IG18
       mov      rdx, gword ptr [rbp-0x48]
       mov      rcx, 0x7FF9C95B3EB0
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      gword ptr [rbp-0x50], rax
       cmp      gword ptr [rbp-0x50], 0
       je       G_M000_IG18
       mov      rcx, gword ptr [rbp-0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_CasedSplit():Lokad.Lython.Frontend.ExecutableCasedSplit:this]
       mov      gword ptr [rbp-0x58], rax
       cmp      gword ptr [rbp-0x58], 0
       je       G_M000_IG18
       mov      rcx, gword ptr [rbp-0x58]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCasedSplit:get_CasingMethod():Lokad.Lython.Runtime.LythonRuntime+ReceiverMethod:this]
       cmp      rax, gword ptr [rbp-0x18]
       jne      G_M000_IG18
       mov      rax, bword ptr [rbp+0x10]
 
G_M000_IG09:                ;; offset=0x032C
       mov      rcx, gword ptr [rax+0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Instructions():Lokad.Lython.Frontend.ExecutableInstruction[]:this]
       mov      rcx, bword ptr [rbp+0x10]
       mov      ecx, dword ptr [rcx+0x40]
       add      ecx, 2
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG29
       mov      edx, ecx
       imul     rdx, rdx, 32
       lea      rax, bword ptr [rax+rdx+0x10]
 
G_M000_IG10:                ;; offset=0x0356
       vmovdqu  ymm0, ymmword ptr [rax]
       vmovdqu  ymmword ptr [rbp-0x80], ymm0
 
G_M000_IG11:                ;; offset=0x035F
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax+0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_CallSites():System.Collections.Generic.IReadOnlyList`1[Lokad.Lython.Frontend.ExecutableCallSite]:this]
       mov      gword ptr [rbp-0x110], rax
       lea      rcx, [rbp-0x80]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_CallSiteIndex():int:this]
       mov      dword ptr [rbp-0x204], eax
       mov      edx, dword ptr [rbp-0x204]
       mov      rcx, gword ptr [rbp-0x110]
       mov      r11, 0x7FF9C8D02100
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       mov      gword ptr [rbp-0x88], rax
       mov      rax, bword ptr [rbp+0x10]
       mov      rax, gword ptr [rax+0x18]
       mov      gword ptr [rbp-0x118], rax
       mov      rcx, gword ptr [rbp-0x58]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCasedSplit:get_CasingCallSpan():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x210], rax
       mov      rdx, gword ptr [rbp-0x210]
       mov      rcx, gword ptr [rbp-0x118]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:EnterInterpreterFrame(Lokad.Lython.LythonSourceSpan):this]
       nop      
 
G_M000_IG12:                ;; offset=0x03E0
       mov      rax, bword ptr [rbp+0x10]
       mov      rax, gword ptr [rax+0x18]
       mov      gword ptr [rbp-0x120], rax
       lea      rax, bword ptr [rbp-0x28]
       mov      bword ptr [rbp-0x128], rax
       mov      rax, gword ptr [rbp-0x58]
       mov      gword ptr [rbp-0x130], rax
       mov      rax, gword ptr [rbp-0x50]
       mov      gword ptr [rbp-0x138], rax
       mov      rax, gword ptr [rbp-0x120]
       mov      gword ptr [rbp-0x140], rax
       mov      rcx, gword ptr [rbp-0x88]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_ConsumedByIteration():bool:this]
       test     eax, eax
       jne      G_M000_IG14
       mov      rax, bword ptr [rbp-0x128]
       mov      bword ptr [rbp-0x170], rax
       mov      rax, gword ptr [rbp-0x130]
       mov      gword ptr [rbp-0x178], rax
       mov      rax, gword ptr [rbp-0x138]
       mov      gword ptr [rbp-0x180], rax
       mov      rax, gword ptr [rbp-0x140]
       mov      gword ptr [rbp-0x188], rax
       mov      rax, bword ptr [rbp+0x10]
       movzx    rax, byte  ptr [rax+0x48]
       test     eax, eax
       je       SHORT G_M000_IG13
       mov      rax, bword ptr [rbp-0x170]
       mov      bword ptr [rbp-0x148], rax
       mov      rax, gword ptr [rbp-0x178]
       mov      gword ptr [rbp-0x150], rax
       mov      rax, gword ptr [rbp-0x180]
       mov      gword ptr [rbp-0x158], rax
       mov      rax, gword ptr [rbp-0x188]
       mov      gword ptr [rbp-0x160], rax
       mov      rcx, gword ptr [rbp-0x88]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_ReturnedDirectly():bool:this]
       mov      dword ptr [rbp-0x164], eax
       jmp      G_M000_IG15
 
G_M000_IG13:                ;; offset=0x04CB
       mov      rax, bword ptr [rbp-0x170]
       mov      bword ptr [rbp-0x148], rax
       mov      rax, gword ptr [rbp-0x178]
       mov      gword ptr [rbp-0x150], rax
       mov      rax, gword ptr [rbp-0x180]
       mov      gword ptr [rbp-0x158], rax
       mov      rax, gword ptr [rbp-0x188]
       mov      gword ptr [rbp-0x160], rax
       xor      eax, eax
       mov      dword ptr [rbp-0x164], eax
       jmp      SHORT G_M000_IG15
 
G_M000_IG14:                ;; offset=0x050D
       mov      rax, bword ptr [rbp-0x128]
       mov      bword ptr [rbp-0x148], rax
       mov      rax, gword ptr [rbp-0x130]
       mov      gword ptr [rbp-0x150], rax
       mov      rax, gword ptr [rbp-0x138]
       mov      gword ptr [rbp-0x158], rax
       mov      rax, gword ptr [rbp-0x140]
       mov      gword ptr [rbp-0x160], rax
       mov      dword ptr [rbp-0x164], 1
 
G_M000_IG15:                ;; offset=0x054F
       mov      rcx, gword ptr [rbp-0x150]
       mov      rdx, gword ptr [rbp-0x158]
       mov      r8, gword ptr [rbp-0x160]
       mov      r9d, dword ptr [rbp-0x164]
       call     [Lokad.Lython.Runtime.LythonRuntime:ExecuteCasedSplit(Lokad.Lython.Frontend.ExecutableCasedSplit,Lokad.Lython.Runtime.Text.PyString,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,bool):System.Object]
       mov      gword ptr [rbp-0x218], rax
       mov      rdx, gword ptr [rbp-0x218]
       mov      rcx, bword ptr [rbp-0x148]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:set_Object(System.Object):this]
       nop      
 
G_M000_IG16:                ;; offset=0x058D
       call     G_M000_IG35
       nop      
 
G_M000_IG17:                ;; offset=0x0593
       mov      rax, bword ptr [rbp+0x10]
       add      dword ptr [rax+0x40], 2
       lea      rdx, [rbp-0x80]
       lea      r8, [rbp-0x28]
       mov      rcx, bword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,byref):this]
       mov      dword ptr [rbp-0x2C], 1
       jmp      G_M000_IG32
 
G_M000_IG18:                ;; offset=0x05B9
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       add      rax, 80
       mov      bword ptr [rbp-0xF0], rax
       mov      rcx, gword ptr [rbp-0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_ArgumentOffset():int:this]
       add      eax, dword ptr [rbp-0x0C]
       mov      dword ptr [rbp-0xF4], eax
       mov      rcx, gword ptr [rbp-0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_ArgumentCount():int:this]
       mov      dword ptr [rbp-0x21C], eax
       mov      r9d, dword ptr [rbp-0x21C]
       lea      rdx, [rbp-0x108]
       mov      r8d, dword ptr [rbp-0xF4]
       mov      rcx, bword ptr [rbp-0xF0]
       call     [System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:Slice(int,int):System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:this]
 
G_M000_IG19:                ;; offset=0x0617
       vmovdqu  xmm0, xmmword ptr [rbp-0x108]
       vmovdqu  xmmword ptr [rbp-0x230], xmm0
 
G_M000_IG20:                ;; offset=0x0627
       mov      rcx, gword ptr [rbp-0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_CallSpan():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x238], rax
       mov      rax, bword ptr [rbp+0x10]
       mov      rax, gword ptr [rax+0x18]
       mov      gword ptr [rsp+0x20], rax
       lea      rax, [rbp-0x60]
       mov      qword ptr [rsp+0x28], rax
       mov      r9, gword ptr [rbp-0x238]
       lea      r8, [rbp-0x230]
       mov      rdx, gword ptr [rbp-0x48]
       mov      rcx, gword ptr [rbp-0x40]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryInvokeClosedReceiver(Lokad.Lython.Runtime.LythonRuntime+ReceiverMethod,System.Object,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       test     eax, eax
       jne      SHORT G_M000_IG21
       xor      eax, eax
       mov      dword ptr [rbp-0x2C], eax
       jmp      G_M000_IG32
 
G_M000_IG21:                ;; offset=0x067A
       lea      rcx, [rbp-0x28]
       mov      rdx, gword ptr [rbp-0x60]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:set_Object(System.Object):this]
       jmp      G_M000_IG30
 
G_M000_IG22:                ;; offset=0x068D
       mov      rcx, gword ptr [rbp-0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_ArgumentCount():int:this]
       cmp      eax, 1
       jne      SHORT G_M000_IG23
       mov      rcx, gword ptr [rbp-0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_HasReceiver():bool:this]
       test     eax, eax
       je       SHORT G_M000_IG24
 
G_M000_IG23:                ;; offset=0x06AE
       xor      rax, rax
       mov      gword ptr [rbp-0xC8], rax
       jmp      SHORT G_M000_IG25
 
G_M000_IG24:                ;; offset=0x06B9
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       add      rax, 80
       mov      bword ptr [rbp-0xD8], rax
       mov      rcx, gword ptr [rbp-0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_ArgumentOffset():int:this]
       add      eax, dword ptr [rbp-0x0C]
       mov      dword ptr [rbp-0xDC], eax
       mov      rax, bword ptr [rbp-0xD8]
       mov      eax, dword ptr [rax+0x08]
       cmp      dword ptr [rbp-0xDC], eax
       jae      G_M000_IG29
       mov      rax, bword ptr [rbp-0xD8]
       mov      ecx, dword ptr [rbp-0xDC]
       shl      rcx, 4
       add      rcx, bword ptr [rax]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Object():System.Object:this]
       mov      gword ptr [rbp-0xC8], rax
 
G_M000_IG25:                ;; offset=0x071A
       mov      rax, gword ptr [rbp-0xC8]
       mov      gword ptr [rbp-0x90], rax
       xor      eax, eax
       mov      dword ptr [rbp-0x98], eax
       cmp      gword ptr [rbp-0x90], 0
       jne      SHORT G_M000_IG26
       xor      rax, rax
       mov      gword ptr [rbp-0xD0], rax
       jmp      SHORT G_M000_IG27
 
G_M000_IG26:                ;; offset=0x0745
       lea      r8, [rbp-0x98]
       mov      rcx, gword ptr [rbp-0x18]
       mov      rdx, gword ptr [rbp-0x90]
       call     [Lokad.Lython.Runtime.LythonRuntime:SelectNativeUnaryOperation(System.Object,System.Object,byref):System.Func`4[System.Object,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]]
       mov      gword ptr [rbp-0xD0], rax
 
G_M000_IG27:                ;; offset=0x0764
       mov      rax, gword ptr [rbp-0xD0]
       mov      gword ptr [rbp-0xA0], rax
       movzx    rax, byte  ptr [rbp-0x98]
       cmp      gword ptr [rbp-0xA0], 0
       setne    cl
       movzx    rcx, cl
       and      eax, ecx
       test     eax, eax
       je       SHORT G_M000_IG28
       mov      rcx, gword ptr [rbp-0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_CallSpan():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x240], rax
       mov      rax, bword ptr [rbp+0x10]
       mov      rax, gword ptr [rax+0x18]
       mov      gword ptr [rsp+0x20], rax
       mov      r9, gword ptr [rbp-0x240]
       lea      rcx, [rbp-0x28]
       mov      rdx, gword ptr [rbp-0x90]
       mov      r8, gword ptr [rbp-0xA0]
       call     [Lokad.Lython.Runtime.LythonRuntime:InvokeSingleInput(System.Object,System.Func`4[System.Object,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]
       jmp      SHORT G_M000_IG30
 
G_M000_IG28:                ;; offset=0x07CE
       lea      rax, [rbp-0x28]
       mov      qword ptr [rsp+0x20], rax
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rbp-0x08]
       mov      r8d, dword ptr [rbp-0x0C]
       mov      r9, gword ptr [rbp-0x18]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:CallFunction(Lokad.Lython.Frontend.ExecutableCallSite,int,System.Object,byref):bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG30
       xor      eax, eax
       mov      dword ptr [rbp-0x2C], eax
       jmp      SHORT G_M000_IG32
 
G_M000_IG29:                ;; offset=0x07F8
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG30:                ;; offset=0x07FE
       lea      r8, [rbp-0x28]
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, bword ptr [rbp+0x18]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,byref):this]
       mov      eax, 1
 
G_M000_IG31:                ;; offset=0x0815
       vzeroupper 
       add      rsp, 640
       pop      rbp
       ret      
 
G_M000_IG32:                ;; offset=0x0821
       mov      eax, dword ptr [rbp-0x2C]
 
G_M000_IG33:                ;; offset=0x0824
       vzeroupper 
       add      rsp, 640
       pop      rbp
       ret      
 
G_M000_IG34:                ;; offset=0x0830
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG35:                ;; offset=0x0836
       sub      rsp, 56
 
G_M000_IG36:                ;; offset=0x083A
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax+0x18]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:LeaveInterpreterFrame():this]
       nop      
 
G_M000_IG37:                ;; offset=0x084B
       vzeroupper 
       add      rsp, 56
       ret      
 
G_M000_IG38:                ;; offset=0x0853
       sub      rsp, 56
 
G_M000_IG39:                ;; offset=0x0857
       mov      gword ptr [rbp-0x1B0], rcx
       mov      rdx, gword ptr [rbp-0x1B0]
       mov      rcx, 0x7FF9C8E02168
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      gword ptr [rbp-0x1B8], rax
       mov      rax, gword ptr [rbp-0x1B8]
       mov      gword ptr [rbp-0x1C0], rax
       cmp      gword ptr [rbp-0x1B8], 0
       jne      SHORT G_M000_IG40
       xor      eax, eax
       mov      dword ptr [rbp-0x1C4], eax
       jmp      SHORT G_M000_IG41
 
G_M000_IG40:                ;; offset=0x089E
       mov      rcx, gword ptr [rbp-0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_CallSpan():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x248], rax
       mov      rdx, gword ptr [rbp-0x248]
       lea      r8, [rbp-0xA8]
       mov      rcx, gword ptr [rbp-0x1C0]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryTranslateCallableException(System.Exception,Lokad.Lython.LythonSourceSpan,byref):bool]
       test     eax, eax
       setne    al
       movzx    rax, al
       mov      dword ptr [rbp-0x1C4], eax
 
G_M000_IG41:                ;; offset=0x08DA
       mov      eax, dword ptr [rbp-0x1C4]
 
G_M000_IG42:                ;; offset=0x08E0
       vzeroupper 
       add      rsp, 56
       ret      
 
G_M000_IG43:                ;; offset=0x08E8
       sub      rsp, 56
 
G_M000_IG44:                ;; offset=0x08EC
       mov      gword ptr [rbp-0x1D0], rcx
       mov      rcx, gword ptr [rbp-0xA8]
       call     CORINFO_HELP_THROW
       int3     
 
; Total bytes of code 2304

; Assembly listing for method Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Call(byref):bool:this (Instrumented Tier0)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; Instrumented Tier0 code
; rbp based frame
; fully interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 688
       lea      rbp, [rsp+0x2B0]
       xor      eax, eax
       mov      qword ptr [rbp-0x278], rax
       vxorps   xmm4, xmm4, xmm4
       mov      rax, -624
 
G_M000_IG53:                ;; offset=0x0027
       vmovdqa  xmmword ptr [rax+rbp], xmm4
       vmovdqa  xmmword ptr [rbp+rax+0x10], xmm4
       vmovdqa  xmmword ptr [rbp+rax+0x20], xmm4
       add      rax, 48
       jne      SHORT G_M000_IG53
       mov      bword ptr [rbp+0x10], rcx
       mov      bword ptr [rbp+0x18], rdx
 
G_M000_IG02:                ;; offset=0x0046
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax+0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_CallSites():System.Collections.Generic.IReadOnlyList`1[Lokad.Lython.Frontend.ExecutableCallSite]:this]
       mov      gword ptr [rbp-0xB0], rax
       mov      rax, gword ptr [rbp-0xB0]
       mov      gword ptr [rbp-0x1D8], rax
       mov      rcx, gword ptr [rbp-0x1D8]
       mov      rdx, 0x7FF9C990E608
       call     CORINFO_HELP_CLASSPROFILE32
       mov      rax, gword ptr [rbp-0x1D8]
       mov      gword ptr [rbp-0x1F0], rax
       mov      rcx, bword ptr [rbp+0x18]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_CallSiteIndex():int:this]
       mov      dword ptr [rbp-0x1F4], eax
       mov      rcx, gword ptr [rbp-0x1F0]
       mov      edx, dword ptr [rbp-0x1F4]
       mov      r11, 0x7FF9C8D02418
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       mov      gword ptr [rbp-0x08], rax
       mov      rcx, bword ptr [rbp+0x18]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x0C], eax
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       add      rax, 80
       mov      bword ptr [rbp-0xB8], rax
       mov      rcx, gword ptr [rbp-0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_TargetOffset():int:this]
       add      eax, dword ptr [rbp-0x0C]
       mov      dword ptr [rbp-0xBC], eax
       mov      rax, bword ptr [rbp-0xB8]
       mov      eax, dword ptr [rax+0x08]
       cmp      dword ptr [rbp-0xBC], eax
       jae      G_M000_IG42
       mov      rax, bword ptr [rbp-0xB8]
       mov      ecx, dword ptr [rbp-0xBC]
       shl      rcx, 4
       add      rcx, bword ptr [rax]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Object():System.Object:this]
       mov      gword ptr [rbp-0x200], rax
       mov      rdx, gword ptr [rbp-0x200]
       mov      rcx, 0x7FF9C9788A60
       call     [Lokad.Lython.Internal.NullabilityExtensions:RequireNotNull[System.__Canon](System.__Canon):System.__Canon]
       mov      gword ptr [rbp-0x18], rax
       vxorps   xmm0, xmm0, xmm0
       vmovdqu  xmmword ptr [rbp-0x28], xmm0
 
G_M000_IG03:                ;; offset=0x014F
       mov      rcx, gword ptr [rbp-0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_IsPositionalOnly():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG04
       lea      rax, [rbp-0x28]
       mov      qword ptr [rsp+0x20], rax
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rbp-0x08]
       mov      r8d, dword ptr [rbp-0x0C]
       mov      r9, gword ptr [rbp-0x18]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:CallFunction(Lokad.Lython.Frontend.ExecutableCallSite,int,System.Object,byref):bool:this]
       test     eax, eax
       jne      G_M000_IG37
       xor      eax, eax
       mov      dword ptr [rbp-0x2C], eax
       jmp      G_M000_IG40
 
G_M000_IG04:                ;; offset=0x0190
       mov      rcx, gword ptr [rbp-0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_HasReceiver():bool:this]
       test     eax, eax
       jne      G_M000_IG09
       mov      rcx, gword ptr [rbp-0x18]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:IsRangeBuiltin(System.Object):bool]
       test     eax, eax
       je       G_M000_IG07
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       add      rax, 80
       mov      bword ptr [rbp-0x190], rax
       mov      rcx, gword ptr [rbp-0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_ArgumentOffset():int:this]
       add      eax, dword ptr [rbp-0x0C]
       mov      dword ptr [rbp-0x194], eax
       mov      rcx, gword ptr [rbp-0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_ArgumentCount():int:this]
       mov      dword ptr [rbp-0x204], eax
       mov      r9d, dword ptr [rbp-0x204]
       lea      rdx, [rbp-0x1A8]
       mov      r8d, dword ptr [rbp-0x194]
       mov      rcx, bword ptr [rbp-0x190]
       call     [System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:Slice(int,int):System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:this]
 
G_M000_IG05:                ;; offset=0x0214
       vmovdqu  xmm0, xmmword ptr [rbp-0x1A8]
       vmovdqu  xmmword ptr [rbp-0x218], xmm0
 
G_M000_IG06:                ;; offset=0x0224
       mov      rcx, gword ptr [rbp-0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_CallSpan():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x220], rax
       mov      rdx, gword ptr [rbp-0x220]
       lea      rcx, [rbp-0x218]
       lea      r9, [rbp-0x38]
       mov      rax, bword ptr [rbp+0x10]
       mov      r8, gword ptr [rax+0x18]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryInvokeNativeRange(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       test     eax, eax
       jne      SHORT G_M000_IG08
       mov      rcx, 0x7FF9C990E710
       call     CORINFO_HELP_COUNTPROFILE32
       xor      eax, eax
       mov      dword ptr [rbp-0x2C], eax
       jmp      G_M000_IG40
 
G_M000_IG07:                ;; offset=0x0274
       mov      rcx, 0x7FF9C990E714
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG09
 
G_M000_IG08:                ;; offset=0x0285
       mov      rcx, 0x7FF9C990E718
       call     CORINFO_HELP_COUNTPROFILE32
       lea      rcx, [rbp-0x28]
       mov      rdx, gword ptr [rbp-0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:set_Object(System.Object):this]
       jmp      G_M000_IG37
 
G_M000_IG09:                ;; offset=0x02A7
       mov      rcx, gword ptr [rbp-0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_HasReceiver():bool:this]
       test     eax, eax
       je       G_M000_IG27
       mov      rdx, gword ptr [rbp-0x18]
       mov      rcx, 0x7FF9C972D7A8
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      gword ptr [rbp-0x40], rax
       cmp      gword ptr [rbp-0x40], 0
       je       G_M000_IG21
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       add      rax, 80
       mov      bword ptr [rbp-0xE8], rax
       mov      rax, bword ptr [rbp-0xE8]
       mov      eax, dword ptr [rax+0x08]
       cmp      dword ptr [rbp-0x0C], eax
       jae      G_M000_IG35
       mov      rax, bword ptr [rbp-0xE8]
       mov      ecx, dword ptr [rbp-0x0C]
       shl      rcx, 4
       add      rcx, bword ptr [rax]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Object():System.Object:this]
       mov      gword ptr [rbp-0x48], rax
       mov      rcx, gword ptr [rbp-0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_ArgumentCount():int:this]
       test     eax, eax
       jne      G_M000_IG23
       mov      rdx, gword ptr [rbp-0x48]
       mov      rcx, 0x7FF9C95B3EB0
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      gword ptr [rbp-0x50], rax
       cmp      gword ptr [rbp-0x50], 0
       je       G_M000_IG20
       mov      rcx, gword ptr [rbp-0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_CasedSplit():Lokad.Lython.Frontend.ExecutableCasedSplit:this]
       mov      gword ptr [rbp-0x58], rax
       cmp      gword ptr [rbp-0x58], 0
       je       G_M000_IG19
       mov      rcx, gword ptr [rbp-0x58]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCasedSplit:get_CasingMethod():Lokad.Lython.Runtime.LythonRuntime+ReceiverMethod:this]
       cmp      rax, gword ptr [rbp-0x18]
       jne      G_M000_IG18
       mov      rax, bword ptr [rbp+0x10]
 
G_M000_IG10:                ;; offset=0x038D
       mov      rcx, gword ptr [rax+0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Instructions():Lokad.Lython.Frontend.ExecutableInstruction[]:this]
       mov      rcx, bword ptr [rbp+0x10]
       mov      ecx, dword ptr [rcx+0x40]
       add      ecx, 2
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG35
       mov      edx, ecx
       imul     rdx, rdx, 32
       lea      rax, bword ptr [rax+rdx+0x10]
 
G_M000_IG11:                ;; offset=0x03B7
       vmovdqu  ymm0, ymmword ptr [rax]
       vmovdqu  ymmword ptr [rbp-0x80], ymm0
 
G_M000_IG12:                ;; offset=0x03C0
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax+0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_CallSites():System.Collections.Generic.IReadOnlyList`1[Lokad.Lython.Frontend.ExecutableCallSite]:this]
       mov      gword ptr [rbp-0x110], rax
       mov      rax, gword ptr [rbp-0x110]
       mov      gword ptr [rbp-0x1E0], rax
       mov      rcx, gword ptr [rbp-0x1E0]
       mov      rdx, 0x7FF9C990E720
       call     CORINFO_HELP_CLASSPROFILE32
       mov      rax, gword ptr [rbp-0x1E0]
       mov      gword ptr [rbp-0x228], rax
       lea      rcx, [rbp-0x80]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_CallSiteIndex():int:this]
       mov      dword ptr [rbp-0x22C], eax
       mov      rcx, gword ptr [rbp-0x228]
       mov      edx, dword ptr [rbp-0x22C]
       mov      r11, 0x7FF9C8D02420
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       mov      gword ptr [rbp-0x88], rax
       mov      rax, bword ptr [rbp+0x10]
       mov      rax, gword ptr [rax+0x18]
       mov      gword ptr [rbp-0x118], rax
       mov      rcx, gword ptr [rbp-0x58]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCasedSplit:get_CasingCallSpan():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x238], rax
       mov      rdx, gword ptr [rbp-0x238]
       mov      rcx, gword ptr [rbp-0x118]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:EnterInterpreterFrame(Lokad.Lython.LythonSourceSpan):this]
       nop      
 
G_M000_IG13:                ;; offset=0x0473
       mov      rax, bword ptr [rbp+0x10]
       mov      rax, gword ptr [rax+0x18]
       mov      gword ptr [rbp-0x120], rax
       lea      rax, bword ptr [rbp-0x28]
       mov      bword ptr [rbp-0x128], rax
       mov      rax, gword ptr [rbp-0x58]
       mov      gword ptr [rbp-0x130], rax
       mov      rax, gword ptr [rbp-0x50]
       mov      gword ptr [rbp-0x138], rax
       mov      rax, gword ptr [rbp-0x120]
       mov      gword ptr [rbp-0x140], rax
       mov      rcx, gword ptr [rbp-0x88]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_ConsumedByIteration():bool:this]
       test     eax, eax
       jne      G_M000_IG15
       mov      rax, bword ptr [rbp-0x128]
       mov      bword ptr [rbp-0x170], rax
       mov      rax, gword ptr [rbp-0x130]
       mov      gword ptr [rbp-0x178], rax
       mov      rax, gword ptr [rbp-0x138]
       mov      gword ptr [rbp-0x180], rax
       mov      rax, gword ptr [rbp-0x140]
       mov      gword ptr [rbp-0x188], rax
       mov      rax, bword ptr [rbp+0x10]
       movzx    rax, byte  ptr [rax+0x48]
       test     eax, eax
       je       SHORT G_M000_IG14
       mov      rax, bword ptr [rbp-0x170]
       mov      bword ptr [rbp-0x148], rax
       mov      rax, gword ptr [rbp-0x178]
       mov      gword ptr [rbp-0x150], rax
       mov      rax, gword ptr [rbp-0x180]
       mov      gword ptr [rbp-0x158], rax
       mov      rax, gword ptr [rbp-0x188]
       mov      gword ptr [rbp-0x160], rax
       mov      rcx, gword ptr [rbp-0x88]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_ReturnedDirectly():bool:this]
       mov      dword ptr [rbp-0x164], eax
       jmp      G_M000_IG16
 
G_M000_IG14:                ;; offset=0x055E
       mov      rcx, 0x7FF9C990E828
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp-0x170]
       mov      bword ptr [rbp-0x148], rax
       mov      rax, gword ptr [rbp-0x178]
       mov      gword ptr [rbp-0x150], rax
       mov      rax, gword ptr [rbp-0x180]
       mov      gword ptr [rbp-0x158], rax
       mov      rax, gword ptr [rbp-0x188]
       mov      gword ptr [rbp-0x160], rax
       xor      eax, eax
       mov      dword ptr [rbp-0x164], eax
       jmp      SHORT G_M000_IG16
 
G_M000_IG15:                ;; offset=0x05AF
       mov      rcx, 0x7FF9C990E82C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp-0x128]
       mov      bword ptr [rbp-0x148], rax
       mov      rax, gword ptr [rbp-0x130]
       mov      gword ptr [rbp-0x150], rax
       mov      rax, gword ptr [rbp-0x138]
       mov      gword ptr [rbp-0x158], rax
       mov      rax, gword ptr [rbp-0x140]
       mov      gword ptr [rbp-0x160], rax
       mov      dword ptr [rbp-0x164], 1
 
G_M000_IG16:                ;; offset=0x0600
       mov      rcx, gword ptr [rbp-0x150]
       mov      rdx, gword ptr [rbp-0x158]
       mov      r8, gword ptr [rbp-0x160]
       mov      r9d, dword ptr [rbp-0x164]
       call     [Lokad.Lython.Runtime.LythonRuntime:ExecuteCasedSplit(Lokad.Lython.Frontend.ExecutableCasedSplit,Lokad.Lython.Runtime.Text.PyString,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,bool):System.Object]
       mov      gword ptr [rbp-0x240], rax
       mov      rdx, gword ptr [rbp-0x240]
       mov      rcx, bword ptr [rbp-0x148]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:set_Object(System.Object):this]
       nop      
 
G_M000_IG17:                ;; offset=0x063E
       call     G_M000_IG43
       jmp      SHORT G_M000_IG22
 
G_M000_IG18:                ;; offset=0x0645
       mov      rcx, 0x7FF9C990E830
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG23
 
G_M000_IG19:                ;; offset=0x0656
       mov      rcx, 0x7FF9C990E834
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG23
 
G_M000_IG20:                ;; offset=0x0667
       mov      rcx, 0x7FF9C990E838
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG23
 
G_M000_IG21:                ;; offset=0x0678
       mov      rcx, 0x7FF9C990E83C
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG27
 
G_M000_IG22:                ;; offset=0x068C
       mov      rcx, 0x7FF9C990E844
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x10]
       add      dword ptr [rax+0x40], 2
       lea      rdx, [rbp-0x80]
       lea      r8, [rbp-0x28]
       mov      rcx, bword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,byref):this]
       mov      dword ptr [rbp-0x2C], 1
       jmp      G_M000_IG40
 
G_M000_IG23:                ;; offset=0x06C1
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       add      rax, 80
       mov      bword ptr [rbp-0xF0], rax
       mov      rcx, gword ptr [rbp-0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_ArgumentOffset():int:this]
       add      eax, dword ptr [rbp-0x0C]
       mov      dword ptr [rbp-0xF4], eax
       mov      rcx, gword ptr [rbp-0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_ArgumentCount():int:this]
       mov      dword ptr [rbp-0x244], eax
       mov      r9d, dword ptr [rbp-0x244]
       lea      rdx, [rbp-0x108]
       mov      r8d, dword ptr [rbp-0xF4]
       mov      rcx, bword ptr [rbp-0xF0]
       call     [System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:Slice(int,int):System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:this]
 
G_M000_IG24:                ;; offset=0x071F
       vmovdqu  xmm0, xmmword ptr [rbp-0x108]
       vmovdqu  xmmword ptr [rbp-0x258], xmm0
 
G_M000_IG25:                ;; offset=0x072F
       mov      rcx, gword ptr [rbp-0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_CallSpan():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x260], rax
       mov      rax, bword ptr [rbp+0x10]
       mov      rax, gword ptr [rax+0x18]
       mov      gword ptr [rsp+0x20], rax
       lea      rax, [rbp-0x60]
       mov      qword ptr [rsp+0x28], rax
       mov      r9, gword ptr [rbp-0x260]
       lea      r8, [rbp-0x258]
       mov      rdx, gword ptr [rbp-0x48]
       mov      rcx, gword ptr [rbp-0x40]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryInvokeClosedReceiver(Lokad.Lython.Runtime.LythonRuntime+ReceiverMethod,System.Object,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       test     eax, eax
       jne      SHORT G_M000_IG26
       mov      rcx, 0x7FF9C990E848
       call     CORINFO_HELP_COUNTPROFILE32
       xor      eax, eax
       mov      dword ptr [rbp-0x2C], eax
       jmp      G_M000_IG40
 
G_M000_IG26:                ;; offset=0x0791
       mov      rcx, 0x7FF9C990E84C
       call     CORINFO_HELP_COUNTPROFILE32
       lea      rcx, [rbp-0x28]
       mov      rdx, gword ptr [rbp-0x60]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:set_Object(System.Object):this]
       jmp      G_M000_IG37
 
G_M000_IG27:                ;; offset=0x07B3
       mov      rcx, gword ptr [rbp-0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_ArgumentCount():int:this]
       cmp      eax, 1
       jne      SHORT G_M000_IG29
       mov      rcx, gword ptr [rbp-0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_HasReceiver():bool:this]
       test     eax, eax
       je       SHORT G_M000_IG30
 
G_M000_IG28:                ;; offset=0x07D4
       mov      rcx, 0x7FF9C990E850
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG29:                ;; offset=0x07E3
       xor      rax, rax
       mov      gword ptr [rbp-0xC8], rax
       jmp      SHORT G_M000_IG31
 
G_M000_IG30:                ;; offset=0x07EE
       mov      rcx, 0x7FF9C990E854
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       add      rax, 80
       mov      bword ptr [rbp-0xD8], rax
       mov      rcx, gword ptr [rbp-0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_ArgumentOffset():int:this]
       add      eax, dword ptr [rbp-0x0C]
       mov      dword ptr [rbp-0xDC], eax
       mov      rax, bword ptr [rbp-0xD8]
       mov      eax, dword ptr [rax+0x08]
       cmp      dword ptr [rbp-0xDC], eax
       jae      G_M000_IG35
       mov      rax, bword ptr [rbp-0xD8]
       mov      ecx, dword ptr [rbp-0xDC]
       shl      rcx, 4
       add      rcx, bword ptr [rax]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Object():System.Object:this]
       mov      gword ptr [rbp-0xC8], rax
 
G_M000_IG31:                ;; offset=0x085E
       mov      rax, gword ptr [rbp-0xC8]
       mov      gword ptr [rbp-0x90], rax
       xor      eax, eax
       mov      dword ptr [rbp-0x98], eax
       cmp      gword ptr [rbp-0x90], 0
       jne      SHORT G_M000_IG32
       xor      rax, rax
       mov      gword ptr [rbp-0xD0], rax
       jmp      SHORT G_M000_IG33
 
G_M000_IG32:                ;; offset=0x0889
       mov      rcx, 0x7FF9C990E858
       call     CORINFO_HELP_COUNTPROFILE32
       lea      r8, [rbp-0x98]
       mov      rcx, gword ptr [rbp-0x18]
       mov      rdx, gword ptr [rbp-0x90]
       call     [Lokad.Lython.Runtime.LythonRuntime:SelectNativeUnaryOperation(System.Object,System.Object,byref):System.Func`4[System.Object,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]]
       mov      gword ptr [rbp-0xD0], rax
 
G_M000_IG33:                ;; offset=0x08B7
       mov      rax, gword ptr [rbp-0xD0]
       mov      gword ptr [rbp-0xA0], rax
       movzx    rax, byte  ptr [rbp-0x98]
       cmp      gword ptr [rbp-0xA0], 0
       setne    cl
       movzx    rcx, cl
       and      eax, ecx
       test     eax, eax
       je       SHORT G_M000_IG34
       mov      rcx, 0x7FF9C990E85C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, gword ptr [rbp-0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_CallSpan():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x268], rax
       mov      rax, bword ptr [rbp+0x10]
       mov      rax, gword ptr [rax+0x18]
       mov      gword ptr [rsp+0x20], rax
       mov      r9, gword ptr [rbp-0x268]
       lea      rcx, [rbp-0x28]
       mov      rdx, gword ptr [rbp-0x90]
       mov      r8, gword ptr [rbp-0xA0]
       call     [Lokad.Lython.Runtime.LythonRuntime:InvokeSingleInput(System.Object,System.Func`4[System.Object,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]
       jmp      SHORT G_M000_IG37
 
G_M000_IG34:                ;; offset=0x0930
       lea      rax, [rbp-0x28]
       mov      qword ptr [rsp+0x20], rax
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rbp-0x08]
       mov      r8d, dword ptr [rbp-0x0C]
       mov      r9, gword ptr [rbp-0x18]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:CallFunction(Lokad.Lython.Frontend.ExecutableCallSite,int,System.Object,byref):bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG36
       mov      rcx, 0x7FF9C990E860
       call     CORINFO_HELP_COUNTPROFILE32
       xor      eax, eax
       mov      dword ptr [rbp-0x2C], eax
       jmp      SHORT G_M000_IG40
 
G_M000_IG35:                ;; offset=0x0969
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG36:                ;; offset=0x096F
       mov      rcx, 0x7FF9C990E864
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG37:                ;; offset=0x097E
       nop      
 
G_M000_IG38:                ;; offset=0x097F
       mov      rcx, 0x7FF9C990E978
       call     CORINFO_HELP_COUNTPROFILE32
       lea      r8, [rbp-0x28]
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, bword ptr [rbp+0x18]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,byref):this]
       mov      eax, 1
 
G_M000_IG39:                ;; offset=0x09A5
       vzeroupper 
       add      rsp, 688
       pop      rbp
       ret      
 
G_M000_IG40:                ;; offset=0x09B1
       mov      rcx, 0x7FF9C990E97C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      eax, dword ptr [rbp-0x2C]
 
G_M000_IG41:                ;; offset=0x09C3
       vzeroupper 
       add      rsp, 688
       pop      rbp
       ret      
 
G_M000_IG42:                ;; offset=0x09CF
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG43:                ;; offset=0x09D5
       sub      rsp, 56
 
G_M000_IG44:                ;; offset=0x09D9
       mov      rcx, 0x7FF9C990E840
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax+0x18]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:LeaveInterpreterFrame():this]
       nop      
 
G_M000_IG45:                ;; offset=0x09F9
       vzeroupper 
       add      rsp, 56
       ret      
 
G_M000_IG46:                ;; offset=0x0A01
       sub      rsp, 56
 
G_M000_IG47:                ;; offset=0x0A05
       mov      gword ptr [rbp-0x1B0], rcx
       mov      rax, gword ptr [rbp-0x1B0]
       mov      gword ptr [rbp-0x1E8], rax
       mov      rcx, gword ptr [rbp-0x1E8]
       mov      rdx, 0x7FF9C990E868
       call     CORINFO_HELP_CLASSPROFILE32
       mov      rax, gword ptr [rbp-0x1E8]
       mov      gword ptr [rbp-0x270], rax
       mov      rdx, gword ptr [rbp-0x270]
       mov      rcx, 0x7FF9C8E02168
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      gword ptr [rbp-0x1B8], rax
       mov      rax, gword ptr [rbp-0x1B8]
       mov      gword ptr [rbp-0x1C0], rax
       cmp      gword ptr [rbp-0x1B8], 0
       jne      SHORT G_M000_IG48
       xor      eax, eax
       mov      dword ptr [rbp-0x1C4], eax
       jmp      SHORT G_M000_IG49
 
G_M000_IG48:                ;; offset=0x0A7E
       mov      rcx, 0x7FF9C990E970
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, gword ptr [rbp-0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_CallSpan():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x278], rax
       mov      rdx, gword ptr [rbp-0x278]
       lea      r8, [rbp-0xA8]
       mov      rcx, gword ptr [rbp-0x1C0]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryTranslateCallableException(System.Exception,Lokad.Lython.LythonSourceSpan,byref):bool]
       test     eax, eax
       setne    al
       movzx    rax, al
       mov      dword ptr [rbp-0x1C4], eax
 
G_M000_IG49:                ;; offset=0x0AC9
       mov      rcx, 0x7FF9C990E974
       call     CORINFO_HELP_COUNTPROFILE32
       mov      eax, dword ptr [rbp-0x1C4]
 
G_M000_IG50:                ;; offset=0x0ADE
       vzeroupper 
       add      rsp, 56
       ret      
 
G_M000_IG51:                ;; offset=0x0AE6
       sub      rsp, 56
 
G_M000_IG52:                ;; offset=0x0AEA
       mov      gword ptr [rbp-0x1D0], rcx
       mov      rcx, gword ptr [rbp-0xA8]
       call     CORINFO_HELP_THROW
       int3     
 
; Total bytes of code 2814

; Assembly listing for method Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Call(byref):bool:this (Tier1)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; Tier1 code
; optimized code
; optimized using Synthesized PGO
; rbp based frame
; fully interruptible
; with Synthesized PGO: fgCalledCount is 133312
; 29 inlinees with PGO data; 91 single block inlinees; 2 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       push     r15
       push     r14
       push     r13
       push     r12
       push     rdi
       push     rsi
       push     rbx
       sub      rsp, 232
       lea      rbp, [rsp+0x120]
       xor      eax, eax
       mov      qword ptr [rbp-0xE8], rax
       vxorps   xmm4, xmm4, xmm4
       vmovdqu  ymmword ptr [rbp-0xE0], ymm4
       vmovdqu  ymmword ptr [rbp-0xC0], ymm4
       vmovdqu  ymmword ptr [rbp-0xA0], ymm4
       vmovdqu  ymmword ptr [rbp-0x80], ymm4
       vmovdqu  ymmword ptr [rbp-0x60], ymm4
       mov      qword ptr [rbp-0x40], rax
       mov      bword ptr [rbp+0x10], rcx
       mov      rbx, rdx
 
G_M000_IG02:                ;; offset=0x0055
       mov      rax, gword ptr [rcx+0x08]
       mov      rax, gword ptr [rax+0x78]
       cmp      dword ptr [rbx+0x1C], 44
       jne      G_M000_IG119
       mov      edx, dword ptr [rbx+0x08]
       mov      r8, 0x7FF9C96CFD18
       cmp      qword ptr [rax], r8
       jne      G_M000_IG121
       mov      r8d, dword ptr [rax+0x08]
       cmp      r8d, edx
       jbe      G_M000_IG120
       mov      rsi, gword ptr [rax+8*rdx+0x10]
 
G_M000_IG03:                ;; offset=0x008F
       mov      gword ptr [rbp-0xC8], rsi
       mov      edi, dword ptr [rbx+0x10]
       mov      rcx, bword ptr [rbp+0x10]
       lea      rax, bword ptr [rcx+0x50]
       cmp      byte  ptr [rsi+0x30], 0
       setne    dl
       movzx    rdx, dl
       add      edx, edi
       cmp      edx, dword ptr [rax+0x08]
       jae      G_M000_IG137
       shl      rdx, 4
       add      rdx, bword ptr [rax]
       mov      r14, gword ptr [rdx]
       mov      rax, 0x26A96003DE0
       mov      r15, gword ptr [rax]
       cmp      r14, r15
       je       G_M000_IG122
 
G_M000_IG04:                ;; offset=0x00D6
       mov      rax, 0x26A96003DE8
       cmp      r14, gword ptr [rax]
       je       G_M000_IG123
       cmp      qword ptr [rdx+0x08], 0
       jne      G_M000_IG124
 
G_M000_IG05:                ;; offset=0x00F4
       test     r14, r14
       je       G_M000_IG125
       vxorps   xmm0, xmm0, xmm0
       vmovdqu  xmmword ptr [rbp-0x48], xmm0
 
G_M000_IG06:                ;; offset=0x0106
       cmp      byte  ptr [rsi+0x34], 0
       je       G_M000_IG73
 
G_M000_IG07:                ;; offset=0x0110
       cmp      byte  ptr [rsi+0x30], 0
       je       G_M000_IG74
 
G_M000_IG08:                ;; offset=0x011A
       cmp      byte  ptr [rsi+0x30], 0
       je       G_M000_IG29
       mov      rax, 0x7FF9C972D7A8
       cmp      qword ptr [r14], rax
       jne      G_M000_IG29
 
G_M000_IG09:                ;; offset=0x0137
       mov      rcx, bword ptr [rbp+0x10]
       lea      rax, bword ptr [rcx+0x50]
       cmp      edi, dword ptr [rax+0x08]
       jae      G_M000_IG92
       mov      edx, edi
       shl      rdx, 4
       add      rdx, bword ptr [rax]
       cmp      gword ptr [rdx], r15
       je       G_M000_IG77
 
G_M000_IG10:                ;; offset=0x015A
       mov      rax, gword ptr [rdx]
       mov      r8, 0x26A96003DE8
       cmp      rax, gword ptr [r8]
       je       G_M000_IG78
       cmp      qword ptr [rdx+0x08], 0
       jne      G_M000_IG79
       mov      r13, gword ptr [rdx]
 
G_M000_IG11:                ;; offset=0x017E
       mov      r12d, dword ptr [rsi+0x28]
       test     r12d, r12d
       jne      SHORT G_M000_IG15
 
G_M000_IG12:                ;; offset=0x0187
       test     r13, r13
       je       SHORT G_M000_IG15
 
G_M000_IG13:                ;; offset=0x018C
       mov      rdx, 0x7FF9C95B3EB0
       cmp      qword ptr [r13], rdx
       jne      SHORT G_M000_IG15
 
G_M000_IG14:                ;; offset=0x019C
       mov      gword ptr [rbp-0xD0], r13
       mov      r10, gword ptr [rsi+0x20]
       mov      gword ptr [rbp-0xD8], r10
       test     r10, r10
       jne      G_M000_IG80
 
G_M000_IG15:                ;; offset=0x01B7
       mov      rcx, bword ptr [rbp+0x10]
       lea      rdx, bword ptr [rcx+0x50]
       cmp      byte  ptr [rsi+0x30], 0
       setne    r8b
       movzx    r8, r8b
       lea      r8d, [rdi+r8+0x01]
       mov      edi, r8d
       mov      r8d, r12d
       add      r8, rdi
       mov      r9d, dword ptr [rdx+0x08]
       cmp      r8, r9
       ja       G_M000_IG75
       shl      rdi, 4
       add      rdi, bword ptr [rdx]
       mov      rdx, gword ptr [rsi+0x18]
       mov      gword ptr [rbp-0xE0], rdx
       mov      r9, gword ptr [rcx+0x18]
       mov      gword ptr [rbp-0xE8], r9
       test     r12d, r12d
       je       G_M000_IG40
 
G_M000_IG16:                ;; offset=0x020C
       cmp      r12d, 1
       jne      SHORT G_M000_IG18
 
G_M000_IG17:                ;; offset=0x0212
       test     r13, r13
       jne      G_M000_IG53
 
G_M000_IG18:                ;; offset=0x021B
       test     r13, r13
       jne      G_M000_IG66
 
G_M000_IG19:                ;; offset=0x0224
       test     r13, r13
       je       G_M000_IG39
 
G_M000_IG20:                ;; offset=0x022D
       mov      rax, 0x7FF9C9757C68
       cmp      qword ptr [r13], rax
       jne      G_M000_IG39
 
G_M000_IG21:                ;; offset=0x0241
       mov      rsi, r13
       cmp      r12d, 1
       je       SHORT G_M000_IG23
 
G_M000_IG22:                ;; offset=0x024A
       cmp      r12d, 2
       jne      G_M000_IG39
 
G_M000_IG23:                ;; offset=0x0254
       mov      rax, 0x26A96003DF8
       cmp      r14, gword ptr [rax]
       jne      G_M000_IG39
 
G_M000_IG24:                ;; offset=0x0267
       test     r12d, r12d
       je       G_M000_IG92
       mov      rcx, rdi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Object():System.Object:this]
       mov      r14, rax
       mov      rcx, rsi
       mov      rdx, r14
       call     [Lokad.Lython.Runtime.PyDict:CanReadKeySynchronously(System.Object):bool:this]
       test     eax, eax
       je       G_M000_IG39
 
G_M000_IG25:                ;; offset=0x0290
       cmp      r12d, 2
       je       SHORT G_M000_IG28
 
G_M000_IG26:                ;; offset=0x0296
       mov      rcx, 0x26A96001850
       mov      r8, gword ptr [rcx]
 
G_M000_IG27:                ;; offset=0x02A3
       mov      r9, gword ptr [rbp-0xE8]
       mov      gword ptr [rsp+0x20], r9
       mov      rcx, rsi
       mov      rdx, r14
       mov      r9, gword ptr [rbp-0xE0]
       call     [Lokad.Lython.Runtime.LythonRuntime:InvokeDictionaryGet(Lokad.Lython.Runtime.PyDict,System.Object,System.Object,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):System.Object]
       jmp      G_M000_IG51
 
G_M000_IG28:                ;; offset=0x02C7
       lea      rcx, bword ptr [rdi+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Object():System.Object:this]
       mov      r8, rax
       jmp      SHORT G_M000_IG27
 
G_M000_IG29:                ;; offset=0x02D6
       cmp      dword ptr [rsi+0x28], 1
       jne      SHORT G_M000_IG31
 
G_M000_IG30:                ;; offset=0x02DC
       cmp      byte  ptr [rsi+0x30], 0
       je       SHORT G_M000_IG36
 
G_M000_IG31:                ;; offset=0x02E2
       xor      r15, r15
 
G_M000_IG32:                ;; offset=0x02E5
       xor      r8d, r8d
       mov      dword ptr [rbp-0x78], r8d
       test     r15, r15
       jne      SHORT G_M000_IG37
 
G_M000_IG33:                ;; offset=0x02F1
       xor      r8, r8
 
G_M000_IG34:                ;; offset=0x02F4
       test     r8, r8
       setne    r9b
       movzx    r9, r9b
       movzx    rdx, byte  ptr [rbp-0x78]
       test     r9d, edx
       je       SHORT G_M000_IG38
 
G_M000_IG35:                ;; offset=0x0308
       mov      rcx, bword ptr [rbp+0x10]
       mov      r9, gword ptr [rcx+0x18]
       mov      gword ptr [rsp+0x20], r9
       mov      r9, gword ptr [rsi+0x18]
       lea      rcx, [rbp-0x48]
       mov      rdx, r15
       call     [Lokad.Lython.Runtime.LythonRuntime:InvokeSingleInput(System.Object,System.Func`4[System.Object,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]
       jmp      G_M000_IG94
 
G_M000_IG36:                ;; offset=0x032B
       mov      rcx, bword ptr [rbp+0x10]
       lea      rax, bword ptr [rcx+0x50]
       cmp      byte  ptr [rsi+0x30], 0
       setne    dl
       movzx    rdx, dl
       lea      edx, [rdi+rdx+0x01]
       cmp      edx, dword ptr [rax+0x08]
       jae      G_M000_IG92
       shl      rdx, 4
       add      rdx, bword ptr [rax]
       mov      rcx, rdx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Object():System.Object:this]
       mov      r15, rax
       jmp      SHORT G_M000_IG32
 
G_M000_IG37:                ;; offset=0x035F
       lea      r8, [rbp-0x78]
       mov      rcx, r14
       mov      rdx, r15
       call     [Lokad.Lython.Runtime.LythonRuntime:SelectNativeUnaryOperation(System.Object,System.Object,byref):System.Func`4[System.Object,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]]
       mov      r8, rax
       jmp      SHORT G_M000_IG34
 
G_M000_IG38:                ;; offset=0x0374
       lea      rdx, [rbp-0x48]
       mov      qword ptr [rsp+0x20], rdx
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, rsi
       mov      r8d, edi
       mov      r9, r14
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:CallFunction(Lokad.Lython.Frontend.ExecutableCallSite,int,System.Object,byref):bool:this]
       test     eax, eax
       jne      G_M000_IG94
 
G_M000_IG39:                ;; offset=0x0398
       xor      eax, eax
       jmp      G_M000_IG118
 
G_M000_IG40:                ;; offset=0x039F
       test     r13, r13
       je       SHORT G_M000_IG42
 
G_M000_IG41:                ;; offset=0x03A4
       mov      rdx, 0x7FF9C95B3EB0
       cmp      qword ptr [r13], rdx
       je       SHORT G_M000_IG45
 
G_M000_IG42:                ;; offset=0x03B4
       mov      rdx, r13
       test     rdx, rdx
       je       SHORT G_M000_IG44
 
G_M000_IG43:                ;; offset=0x03BC
       mov      r8, 0x7FF9C9757C68
       xor      r9, r9
       cmp      qword ptr [rdx], r8
       cmovne   rdx, r9
 
G_M000_IG44:                ;; offset=0x03D0
       test     rdx, rdx
       je       G_M000_IG16
 
G_M000_IG45:                ;; offset=0x03D9
       mov      rdx, gword ptr [r14+0x20]
       mov      rdx, gword ptr [rdx+0x10]
       cmp      dword ptr [rdx+0x08], 0
       jg       G_M000_IG16
       mov      r8, rdx
       movzx    r9, byte  ptr [r8+0x0C]
       mov      r8d, dword ptr [r8+0x10]
       test     r9d, r9d
       je       SHORT G_M000_IG46
       test     r8d, r8d
       jl       G_M000_IG16
 
G_M000_IG46:                ;; offset=0x0405
       test     rdx, rdx
       je       SHORT G_M000_IG50
 
G_M000_IG47:                ;; offset=0x040A
       mov      r9, 0x7FF9C94AC210
       cmp      qword ptr [rdx], r9
       jne      SHORT G_M000_IG50
 
G_M000_IG48:                ;; offset=0x0419
       movzx    r9, byte  ptr [rdx+0x30]
       mov      r8d, dword ptr [rdx+0x34]
       test     r9d, r9d
       je       G_M000_IG88
       mov      edx, r8d
       not      edx
       shr      edx, 31
 
G_M000_IG49:                ;; offset=0x0433
       test     edx, edx
       je       G_M000_IG16
 
G_M000_IG50:                ;; offset=0x043B
       mov      rcx, r14
       mov      rdx, r13
       mov      r8, gword ptr [rbp-0xE0]
       mov      r9, gword ptr [rbp-0xE8]
       call     [Lokad.Lython.Runtime.LythonRuntime:InvokeReceiverMethod(Lokad.Lython.Runtime.LythonRuntime+ReceiverMethod,System.Object,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):System.Object]
 
G_M000_IG51:                ;; offset=0x0455
       mov      gword ptr [rbp-0x48], rax
 
G_M000_IG52:                ;; offset=0x0459
       xor      eax, eax
       mov      qword ptr [rbp-0x40], rax
       jmp      G_M000_IG94
 
G_M000_IG53:                ;; offset=0x0464
       mov      rax, 0x7FF9C975D0E0
       cmp      qword ptr [r13], rax
       jne      G_M000_IG18
 
G_M000_IG54:                ;; offset=0x0478
       mov      rax, 0x26A96003DF0
       cmp      r14, gword ptr [rax]
       jne      G_M000_IG18
       mov      r12, gword ptr [rdi]
       cmp      r12, r15
       je       G_M000_IG89
 
G_M000_IG55:                ;; offset=0x0497
       mov      rax, 0x26A96003DE8
       cmp      r12, gword ptr [rax]
       je       G_M000_IG90
       cmp      qword ptr [rdi+0x08], 0
       jne      G_M000_IG91
 
G_M000_IG56:                ;; offset=0x04B5
       mov      r9, gword ptr [rbp-0xE8]
       mov      rcx, gword ptr [r9+0x98]
       mov      rdx, gword ptr [rbp-0xE0]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.ExecutionState:EnterInterpreterFrame(Lokad.Lython.LythonSourceSpan):this]
       nop      
 
G_M000_IG57:                ;; offset=0x04D3
       mov      r9, gword ptr [rbp-0xE8]
       mov      rcx, gword ptr [r9+0x98]
       mov      rdx, gword ptr [rcx+0x88]
       cmp      gword ptr [rdx+0x20], 0
       jne      SHORT G_M000_IG61
       mov      rdx, gword ptr [rcx+0x178]
       test     rdx, rdx
       jne      SHORT G_M000_IG60
 
G_M000_IG58:                ;; offset=0x04FB
       mov      r14, gword ptr [r14+0x08]
       mov      rcx, 0x7FF9C976AA78
       cmp      qword ptr [r14+0x18], rcx
       jne      SHORT G_M000_IG62
 
G_M000_IG59:                ;; offset=0x050F
       mov      rcx, r13
       mov      rdx, r12
       mov      r8, gword ptr [rbp-0xE0]
       mov      r9, gword ptr [rbp-0xE8]
       call     [Lokad.Lython.Runtime.LythonRuntime+ListMembers:Append(Lokad.Lython.Runtime.PyList,System.Object,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):System.Object]
       jmp      SHORT G_M000_IG63
 
G_M000_IG60:                ;; offset=0x052B
       cmp      dword ptr [rdx+0x20], 0
       setne    dl
       movzx    rdx, dl
       test     edx, edx
       je       SHORT G_M000_IG58
 
G_M000_IG61:                ;; offset=0x0539
       mov      rdx, gword ptr [rbp-0xE0]
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
       jmp      SHORT G_M000_IG58
 
G_M000_IG62:                ;; offset=0x0548
       mov      gword ptr [rbp-0xB0], r12
       mov      r8, 0x1FFFFFFFF
       mov      qword ptr [rbp-0xA8], r8
       mov      r9, gword ptr [rbp-0xE8]
       mov      gword ptr [rsp+0x20], r9
       lea      r8, [rbp-0xB0]
       mov      rdx, r13
       mov      r9, gword ptr [rbp-0xE0]
       mov      rcx, gword ptr [r14+0x10]
       call     [r14+0x18]System.Func`5[System.__Canon,Lokad.Lython.Runtime.LythonRuntime+ReceiverArguments,System.__Canon,System.__Canon,System.__Canon]:Invoke(System.__Canon,Lokad.Lython.Runtime.LythonRuntime+ReceiverArguments,System.__Canon,System.__Canon):System.__Canon:this
       nop      
 
G_M000_IG63:                ;; offset=0x0586
       mov      r9, gword ptr [rbp-0xE8]
       mov      r14, gword ptr [r9+0x98]
       mov      rcx, qword ptr [r14+0x168]
       test     rcx, rcx
       jle      SHORT G_M000_IG65
 
G_M000_IG64:                ;; offset=0x05A0
       dec      rcx
       mov      qword ptr [r14+0x168], rcx
 
G_M000_IG65:                ;; offset=0x05AA
       xor      rcx, rcx
       mov      gword ptr [rbp-0x90], rcx
       jmp      G_M000_IG51
 
G_M000_IG66:                ;; offset=0x05B8
       mov      rdx, 0x7FF9C95B3EB0
       cmp      qword ptr [r13], rdx
       jne      G_M000_IG19
 
G_M000_IG67:                ;; offset=0x05CC
       mov      rsi, r13
       mov      edx, r12d
       sub      edx, 1
       cmp      edx, 2
       ja       G_M000_IG20
       mov      rcx, r14
       mov      edx, r12d
       call     [Lokad.Lython.Runtime.LythonRuntime:SelectNativeStringOperation(System.Object,int):System.Nullable`1[int]]
       mov      qword ptr [rbp-0x88], rax
       cmp      byte  ptr [rbp-0x88], 0
       je       G_M000_IG20
 
G_M000_IG68:                ;; offset=0x05FE
       mov      rcx, rdi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Object():System.Object:this]
       mov      r13, rax
       cmp      r12d, 1
       jle      SHORT G_M000_IG72
 
G_M000_IG69:                ;; offset=0x0610
       lea      rcx, bword ptr [rdi+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Object():System.Object:this]
       mov      r14, rax
 
G_M000_IG70:                ;; offset=0x061D
       cmp      r12d, 2
       jg       G_M000_IG93
       xor      r12, r12
 
G_M000_IG71:                ;; offset=0x062A
       mov      ecx, dword ptr [rbp-0x84]
       mov      rdx, r13
       mov      r8, r14
       mov      r9, r12
       call     [Lokad.Lython.Runtime.LythonRuntime:CanUseNativeStringCall(int,System.Object,System.Object,System.Object):bool]
       test     eax, eax
       je       G_M000_IG39
       mov      gword ptr [rsp+0x20], r12
       mov      rdx, gword ptr [rbp-0xE0]
       mov      gword ptr [rsp+0x28], rdx
       mov      r9, gword ptr [rbp-0xE8]
       mov      gword ptr [rsp+0x30], r9
       mov      ecx, dword ptr [rbp-0x84]
       mov      rdx, rsi
       mov      r8, r13
       mov      r9, r14
       call     [Lokad.Lython.Runtime.LythonRuntime:InvokeNativeStringOperation(int,Lokad.Lython.Runtime.Text.PyString,System.Object,System.Object,System.Object,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):System.Object]
       jmp      G_M000_IG51
 
G_M000_IG72:                ;; offset=0x067E
       xor      r14, r14
       jmp      SHORT G_M000_IG70
 
G_M000_IG73:                ;; offset=0x0683
       lea      rdx, [rbp-0x48]
       mov      qword ptr [rsp+0x20], rdx
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, rsi
       mov      r8d, edi
       mov      r9, r14
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:CallFunction(Lokad.Lython.Frontend.ExecutableCallSite,int,System.Object,byref):bool:this]
       test     eax, eax
       jne      G_M000_IG94
       jmp      G_M000_IG39
 
G_M000_IG74:                ;; offset=0x06AC
       mov      rcx, r14
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:IsRangeBuiltin(System.Object):bool]
       test     eax, eax
       je       G_M000_IG08
       mov      rcx, bword ptr [rbp+0x10]
       lea      rdx, bword ptr [rcx+0x50]
       cmp      byte  ptr [rsi+0x30], 0
       setne    r8b
       movzx    r8, r8b
       lea      r8d, [rdi+r8+0x01]
       mov      r9d, dword ptr [rsi+0x28]
       mov      eax, r8d
       mov      r10d, r9d
       add      rax, r10
       mov      r10d, dword ptr [rdx+0x08]
       cmp      rax, r10
       jbe      SHORT G_M000_IG76
 
G_M000_IG75:                ;; offset=0x06EC
       call     [System.ThrowHelper:ThrowArgumentOutOfRangeException()]
       int3     
 
G_M000_IG76:                ;; offset=0x06F3
       mov      r8d, r8d
       shl      r8, 4
       add      r8, bword ptr [rdx]
       mov      bword ptr [rbp-0xC0], r8
       mov      dword ptr [rbp-0xB8], r9d
       lea      rcx, [rbp-0xC0]
       mov      rdx, gword ptr [rsi+0x18]
       mov      r15, bword ptr [rbp+0x10]
       mov      r8, gword ptr [r15+0x18]
       lea      r9, [rbp-0x50]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryInvokeNativeRange(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       test     eax, eax
       je       G_M000_IG39
       mov      rcx, gword ptr [rbp-0x50]
       mov      gword ptr [rbp-0x48], rcx
       jmp      G_M000_IG52
 
G_M000_IG77:                ;; offset=0x073D
       mov      rcx, rdx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishInteger():System.Object:this]
       mov      r13, rax
       jmp      G_M000_IG11
 
G_M000_IG78:                ;; offset=0x074E
       mov      rcx, rdx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishDouble():System.Object:this]
       mov      r13, rax
       jmp      G_M000_IG11
 
G_M000_IG79:                ;; offset=0x075F
       mov      rcx, rdx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishTupleBorrow():System.Object:this]
       mov      r13, rax
       jmp      G_M000_IG11
 
G_M000_IG80:                ;; offset=0x0770
       cmp      r14, gword ptr [r10+0x08]
       jne      G_M000_IG15
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rcx+0x08]
       mov      rdx, gword ptr [rdx+0x60]
       mov      r8d, dword ptr [rcx+0x40]
       add      r8d, 2
       cmp      r8d, dword ptr [rdx+0x08]
       jae      G_M000_IG92
       shl      r8, 5
 
G_M000_IG81:                ;; offset=0x079C
       vmovdqu  ymm0, ymmword ptr [rdx+r8+0x10]
       vmovdqu  ymmword ptr [rbp-0x70], ymm0
 
G_M000_IG82:                ;; offset=0x07A8
       mov      rdx, gword ptr [rcx+0x08]
       mov      rsi, gword ptr [rdx+0x78]
       lea      rcx, [rbp-0x70]
       mov      edx, 44
       mov      r8, 0x28ABC9C58B0
       call     [Lokad.Lython.Frontend.ExecutableInstruction:ReadPrimaryOperand(int,System.String):int:this]
       mov      edx, eax
       mov      rcx, rsi
       mov      r11, 0x7FF9C8D02470
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       mov      rdi, rax
       mov      r15, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [r15+0x18]
       mov      r12, gword ptr [rbp-0xD8]
       mov      rdx, gword ptr [r12+0x18]
       mov      rcx, gword ptr [rcx+0x98]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.ExecutionState:EnterInterpreterFrame(Lokad.Lython.LythonSourceSpan):this]
       nop      
 
G_M000_IG83:                ;; offset=0x0802
       mov      r8, gword ptr [r15+0x18]
       cmp      byte  ptr [rdi+0x31], 0
       jne      SHORT G_M000_IG85
       cmp      byte  ptr [r15+0x48], 0
       je       SHORT G_M000_IG84
       movzx    r9, byte  ptr [rdi+0x32]
       jmp      SHORT G_M000_IG86
 
G_M000_IG84:                ;; offset=0x081A
       xor      r9d, r9d
       jmp      SHORT G_M000_IG86
 
G_M000_IG85:                ;; offset=0x081F
       mov      r9d, 1
 
G_M000_IG86:                ;; offset=0x0825
       mov      rcx, r12
       mov      rdx, gword ptr [rbp-0xD0]
       call     [Lokad.Lython.Runtime.LythonRuntime:ExecuteCasedSplit(Lokad.Lython.Frontend.ExecutableCasedSplit,Lokad.Lython.Runtime.Text.PyString,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,bool):System.Object]
       mov      gword ptr [rbp-0x48], rax
       xor      ecx, ecx
       mov      qword ptr [rbp-0x40], rcx
 
G_M000_IG87:                ;; offset=0x083F
       mov      rsi, gword ptr [r15+0x18]
       mov      rcx, gword ptr [rsi+0x98]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.ExecutionState:LeaveInterpreterFrame():this]
       add      dword ptr [r15+0x40], 2
       lea      r8, [rbp-0x48]
       lea      rdx, [rbp-0x70]
       mov      rcx, r15
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,byref):this]
       mov      eax, 1
       jmp      G_M000_IG118
 
G_M000_IG88:                ;; offset=0x0872
       mov      edx, 1
       jmp      G_M000_IG49
 
G_M000_IG89:                ;; offset=0x087C
       mov      rcx, rdi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishInteger():System.Object:this]
       mov      r12, rax
       jmp      G_M000_IG56
 
G_M000_IG90:                ;; offset=0x088D
       mov      rcx, rdi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishDouble():System.Object:this]
       mov      r12, rax
       jmp      G_M000_IG56
 
G_M000_IG91:                ;; offset=0x089E
       mov      rcx, rdi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishTupleBorrow():System.Object:this]
       mov      r12, rax
       jmp      G_M000_IG56
 
G_M000_IG92:                ;; offset=0x08AF
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG93:                ;; offset=0x08B5
       lea      rcx, bword ptr [rdi+0x20]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Object():System.Object:this]
       mov      r12, rax
       jmp      G_M000_IG71
 
G_M000_IG94:                ;; offset=0x08C7
       cmp      dword ptr [rbx+0x18], 0
       jge      G_M000_IG109
 
G_M000_IG95:                ;; offset=0x08D1
       mov      edx, dword ptr [rbx+0x18]
       mov      esi, edx
       not      esi
       mov      edx, esi
       mov      r15, bword ptr [rbp+0x10]
       mov      edi, dword ptr [r15+0x44]
       cmp      edx, edi
       jge      SHORT G_M000_IG98
 
G_M000_IG96:                ;; offset=0x08E6
       dec      edi
       mov      rdx, gword ptr [r15+0x08]
       mov      edx, dword ptr [rdx+0xB0]
       cmp      edi, edx
       cmovg    edi, edx
       cmp      edi, esi
       jge      G_M000_IG127
 
G_M000_IG97:                ;; offset=0x08FF
       mov      dword ptr [r15+0x44], esi
 
G_M000_IG98:                ;; offset=0x0903
       mov      rcx, gword ptr [r15+0x18]
       mov      rcx, gword ptr [rcx+0x98]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.ExecutionState:get_CanContinue():bool:this]
       test     eax, eax
       je       G_M000_IG130
       lea      rsi, bword ptr [r15+0x50]
       mov      ecx, dword ptr [rbx+0x1C]
       cmp      ecx, 53
       ja       SHORT G_M000_IG100
 
G_M000_IG99:                ;; offset=0x092A
       mov      rax, 0x1FFFFFFFFFE7FF
       bt       rax, rcx
       jae      G_M000_IG131
 
G_M000_IG100:                ;; offset=0x093E
       mov      eax, dword ptr [rbx+0x14]
 
G_M000_IG101:                ;; offset=0x0941
       cmp      eax, dword ptr [rsi+0x08]
       jae      G_M000_IG137
       mov      rcx, bword ptr [rsi]
       mov      eax, eax
       shl      rax, 4
       xor      edx, edx
       mov      qword ptr [rcx+rax], rdx
       mov      qword ptr [rcx+rax+0x08], rdx
       mov      ecx, dword ptr [rbx+0x1C]
       cmp      ecx, 53
       ja       SHORT G_M000_IG103
 
G_M000_IG102:                ;; offset=0x0966
       mov      rax, 0x1FFFFFFFFFE7FF
       bt       rax, rcx
       jae      G_M000_IG132
 
G_M000_IG103:                ;; offset=0x097A
       mov      eax, dword ptr [rbx+0x14]
 
G_M000_IG104:                ;; offset=0x097D
       mov      dword ptr [r15+0x44], eax
       mov      rcx, gword ptr [r15+0x08]
       mov      rcx, gword ptr [rcx+0x60]
       mov      eax, dword ptr [r15+0x40]
       inc      eax
       cmp      eax, dword ptr [rcx+0x08]
       jae      G_M000_IG137
       shl      rax, 5
       lea      rcx, bword ptr [rcx+rax+0x10]
       mov      eax, dword ptr [rcx+0x1C]
       cmp      eax, 27
       je       G_M000_IG133
 
G_M000_IG105:                ;; offset=0x09AD
       cmp      eax, 32
       jne      G_M000_IG134
       cmp      gword ptr [rbp-0x48], 0
       je       G_M000_IG135
 
G_M000_IG106:                ;; offset=0x09C1
       inc      dword ptr [r15+0x40]
 
G_M000_IG107:                ;; offset=0x09C5
       mov      eax, 1
 
G_M000_IG108:                ;; offset=0x09CA
       vzeroupper 
       add      rsp, 232
       pop      rbx
       pop      rsi
       pop      rdi
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG109:                ;; offset=0x09E1
       mov      ecx, dword ptr [rbx+0x1C]
       cmp      ecx, 53
       ja       SHORT G_M000_IG111
 
G_M000_IG110:                ;; offset=0x09E9
       mov      rax, 0x1FFFFFFFFFE7FF
       bt       rax, rcx
       jae      G_M000_IG126
 
G_M000_IG111:                ;; offset=0x09FD
       mov      esi, dword ptr [rbx+0x14]
 
G_M000_IG112:                ;; offset=0x0A00
       mov      ebx, dword ptr [rbx+0x18]
       test     ebx, ebx
       jge      SHORT G_M000_IG116
 
G_M000_IG113:                ;; offset=0x0A07
       not      ebx
 
G_M000_IG114:                ;; offset=0x0A09
       mov      r15, bword ptr [rbp+0x10]
       cmp      ebx, dword ptr [r15+0x44]
       jl       SHORT G_M000_IG117
 
G_M000_IG115:                ;; offset=0x0A13
       lea      rcx, bword ptr [r15+0x50]
       cmp      esi, dword ptr [rcx+0x08]
       jae      G_M000_IG137
       mov      esi, esi
       shl      rsi, 4
       add      rsi, bword ptr [rcx]
       mov      rdx, gword ptr [rbp-0x48]
       mov      rcx, rsi
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rax, qword ptr [rbp-0x40]
       mov      qword ptr [rsi+0x08], rax
       mov      dword ptr [r15+0x44], ebx
       jmp      SHORT G_M000_IG107
 
G_M000_IG116:                ;; offset=0x0A43
       jmp      SHORT G_M000_IG114
 
G_M000_IG117:                ;; offset=0x0A45
       mov      rcx, r15
       mov      edx, ebx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Trim(int):this]
       jmp      SHORT G_M000_IG115
 
G_M000_IG118:                ;; offset=0x0A52
       vzeroupper 
       add      rsp, 232
       pop      rbx
       pop      rsi
       pop      rdi
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG119:                ;; offset=0x0A69
       mov      rcx, rbx
       mov      rdx, 0x28ABC9C58B0
       call     [Lokad.Lython.Frontend.ExecutableInstruction:InvalidOperand(System.String):System.InvalidOperationException:this]
       mov      rcx, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG120:                ;; offset=0x0A85
       call     [System.ThrowHelper:ThrowArgumentOutOfRange_IndexMustBeLessException()]
       int3     
 
G_M000_IG121:                ;; offset=0x0A8C
       mov      rcx, rax
       mov      r11, 0x7FF9C8D02468
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       mov      rsi, rax
       jmp      G_M000_IG03
 
G_M000_IG122:                ;; offset=0x0AA4
       mov      rcx, rdx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishInteger():System.Object:this]
       mov      r14, rax
       jmp      G_M000_IG05
 
G_M000_IG123:                ;; offset=0x0AB5
       mov      rcx, rdx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishDouble():System.Object:this]
       mov      r14, rax
       jmp      G_M000_IG05
 
G_M000_IG124:                ;; offset=0x0AC6
       mov      rcx, rdx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishTupleBorrow():System.Object:this]
       mov      r14, rax
       jmp      G_M000_IG05
 
G_M000_IG125:                ;; offset=0x0AD7
       mov      rcx, 0x7FF9C8F2A220
       call     CORINFO_HELP_NEWSFAST
       mov      rbx, rax
       mov      rcx, rbx
       mov      rdx, 0x28ABC9C6318
       call     [System.InvalidOperationException:.ctor(System.String):this]
       mov      rcx, rbx
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG126:                ;; offset=0x0B05
       mov      rcx, rbx
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      esi, eax
       jmp      G_M000_IG112
 
G_M000_IG127:                ;; offset=0x0B15
       lea      rdx, bword ptr [r15+0x50]
       cmp      edi, dword ptr [rdx+0x08]
       jae      G_M000_IG137
       mov      rdx, bword ptr [rdx]
       mov      ecx, edi
       shl      rcx, 4
       mov      rdx, gword ptr [rdx+rcx]
       mov      rcx, 0x7FF9C9753318
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG129
       lea      rcx, bword ptr [r15+0x50]
       cmp      edi, dword ptr [rcx+0x08]
       jae      G_M000_IG137
       mov      edx, edi
       shl      rdx, 4
       add      rdx, bword ptr [rcx]
       xor      rcx, rcx
       mov      gword ptr [rdx], rcx
 
G_M000_IG128:                ;; offset=0x0B5E
       mov      qword ptr [rdx+0x08], rcx
       mov      rcx, rax
       mov      rax, qword ptr [rax]
       mov      rax, qword ptr [rax+0x40]
       call     [rax+0x20]Lokad.Lython.Runtime.ExecutableTemporaryValue:Dispose():this
 
G_M000_IG129:                ;; offset=0x0B6F
       dec      edi
       cmp      edi, esi
       jge      SHORT G_M000_IG127
       jmp      G_M000_IG97
 
G_M000_IG130:                ;; offset=0x0B7A
       mov      rcx, rbx
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       mov      esi, eax
       mov      rcx, rbx
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      r8d, eax
       mov      edx, esi
       lea      r9, [rbp-0x48]
       mov      rcx, r15
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Put(int,int,byref):this]
       jmp      G_M000_IG107
 
G_M000_IG131:                ;; offset=0x0BA5
       mov      rcx, rbx
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       jmp      G_M000_IG101
 
G_M000_IG132:                ;; offset=0x0BB3
       mov      rcx, rbx
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       jmp      G_M000_IG104
 
G_M000_IG133:                ;; offset=0x0BC1
       lea      rbx, bword ptr [r15+0x50]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LocalSlot():int:this]
       cmp      eax, dword ptr [rbx+0x08]
       jae      G_M000_IG137
       mov      esi, eax
       shl      rsi, 4
       add      rsi, bword ptr [rbx]
       mov      rdx, gword ptr [rbp-0x48]
       mov      rcx, rsi
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rcx, qword ptr [rbp-0x40]
       mov      qword ptr [rsi+0x08], rcx
       jmp      G_M000_IG106
 
G_M000_IG134:                ;; offset=0x0BF6
       mov      rcx, 0x7FF9C8F2A220
       call     CORINFO_HELP_NEWSFAST
       mov      r15, rax
       mov      rcx, r15
       mov      rdx, 0x28ABC9C8A90
       call     [System.InvalidOperationException:.ctor(System.String):this]
       mov      rcx, r15
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG135:                ;; offset=0x0C24
       vmovdqu  xmm0, xmmword ptr [rbp-0x48]
       vmovdqu  xmmword ptr [rbp-0xA0], xmm0
 
G_M000_IG136:                ;; offset=0x0C31
       lea      rcx, [rbp-0xA0]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Object():System.Object:this]
       mov      rdx, rax
       mov      rcx, 0x7FF9C9788A60
       call     [Lokad.Lython.Internal.NullabilityExtensions:RequireNotNull[System.__Canon](System.__Canon):System.__Canon]
       jmp      G_M000_IG106
 
G_M000_IG137:                ;; offset=0x0C56
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG138:                ;; offset=0x0C5C
       sub      rsp, 56
 
G_M000_IG139:                ;; offset=0x0C60
       mov      r15, bword ptr [rbp+0x10]
       mov      rsi, gword ptr [r15+0x18]
       mov      rcx, gword ptr [rsi+0x98]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.ExecutionState:LeaveInterpreterFrame():this]
       nop      
 
G_M000_IG140:                ;; offset=0x0C78
       vzeroupper 
       add      rsp, 56
       ret      
 
G_M000_IG141:                ;; offset=0x0C80
       sub      rsp, 56
 
G_M000_IG142:                ;; offset=0x0C84
       mov      rdx, rcx
       mov      rcx, 0x7FF9C8E02168
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       jne      SHORT G_M000_IG144
 
G_M000_IG143:                ;; offset=0x0C9B
       xor      eax, eax
       jmp      SHORT G_M000_IG145
 
G_M000_IG144:                ;; offset=0x0C9F
       lea      r8, [rbp-0x90]
       mov      rcx, rax
       mov      rdx, gword ptr [rbp-0xE0]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryTranslateCallableException(System.Exception,Lokad.Lython.LythonSourceSpan,byref):bool]
       test     eax, eax
       setne    al
       movzx    rax, al
 
G_M000_IG145:                ;; offset=0x0CBE
       vzeroupper 
       add      rsp, 56
       ret      
 
G_M000_IG146:                ;; offset=0x0CC6
       sub      rsp, 56
 
G_M000_IG147:                ;; offset=0x0CCA
       mov      rcx, gword ptr [rbp-0x90]
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG148:                ;; offset=0x0CD7
       sub      rsp, 56
 
G_M000_IG149:                ;; offset=0x0CDB
       mov      r9, gword ptr [rbp-0xE8]
       mov      r14, gword ptr [r9+0x98]
       mov      rcx, qword ptr [r14+0x168]
       test     rcx, rcx
       jle      SHORT G_M000_IG151
 
G_M000_IG150:                ;; offset=0x0CF5
       dec      rcx
       mov      qword ptr [r14+0x168], rcx
 
G_M000_IG151:                ;; offset=0x0CFF
       vzeroupper 
       add      rsp, 56
       ret      
 
G_M000_IG152:                ;; offset=0x0D07
       sub      rsp, 56
 
G_M000_IG153:                ;; offset=0x0D0B
       mov      rdx, rcx
       mov      rcx, 0x7FF9C8E02168
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       mov      rbx, rax
       test     rbx, rbx
       jne      SHORT G_M000_IG155
 
G_M000_IG154:                ;; offset=0x0D25
       xor      eax, eax
       jmp      SHORT G_M000_IG156
 
G_M000_IG155:                ;; offset=0x0D29
       mov      rcx, gword ptr [rbp-0xC8]
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_CallSpan():Lokad.Lython.LythonSourceSpan:this]
       mov      rdx, rax
       lea      r8, [rbp-0x80]
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime:TryTranslateCallableException(System.Exception,Lokad.Lython.LythonSourceSpan,byref):bool]
       test     eax, eax
       setne    al
       movzx    rax, al
 
G_M000_IG156:                ;; offset=0x0D4E
       vzeroupper 
       add      rsp, 56
       ret      
 
G_M000_IG157:                ;; offset=0x0D56
       sub      rsp, 56
 
G_M000_IG158:                ;; offset=0x0D5A
       mov      rcx, gword ptr [rbp-0x80]
       call     CORINFO_HELP_THROW
       int3     
 
; Total bytes of code 3428

