from pathlib import Path
import hashlib
import importlib.util
import io
import json
import os
import re
import shutil
import statistics
import subprocess
import tempfile

lab = Path(__file__).resolve().parent
repo = Path('D:/code/Lython')
catalog = lab / 'representative.json'
identity = json.loads((lab / 'frozen-identity.json').read_text(encoding='utf-8'))
spec = importlib.util.spec_from_file_location('protocol', repo / 'benchmarks/cpython-worker.py')
protocol = importlib.util.module_from_spec(spec)
spec.loader.exec_module(protocol)
case = next(case for case in json.loads(catalog.read_text(encoding='utf-8'))['cases'] if case['id'] == 'scripts.text-normalization.helper-list')
dotnet = Path('C:/Users/JoannesVermorel/.dotnet11/dotnet.exe')
env = os.environ.copy()
env.update(DOTNET_ROOT=str(dotnet.parent), DOTNET_ROOT_X64=str(dotnet.parent))
env['PATH'] = str(dotnet.parent) + os.pathsep + env['PATH']
assert not any(key.startswith(('DOTNET_', 'COMPlus_')) and key not in {'DOTNET_ROOT', 'DOTNET_ROOT_X64'} for key in env)
observations = {}
for role in ('reference', 'candidate'):
    folder = lab / 'frozen' / role
    hashes = identity['imageFiles'][role]
    assert all(hashlib.sha256((folder / name).read_bytes()).hexdigest() == digest for name, digest in hashes.items())
    compile_folder = lab / ('compile-' + role)
    source = lab.parent / 'frontend-dispatch-r527/compile-allocation/bin/Release/net11.0'
    if not compile_folder.exists():
        shutil.copytree(source, compile_folder)
        shutil.copyfile(folder / 'Lokad.Lython.dll', compile_folder / 'Lokad.Lython.dll')
    compile_result = lab / (role + '-compile-allocation.json')
    if not compile_result.exists():
        subprocess.run([str(dotnet), str(compile_folder / 'compile-allocation.dll'), str(catalog), str(compile_result)],
                       cwd=repo, env=env, timeout=60, check=True)
    compiled = json.loads(compile_result.read_text(encoding='utf-8-sig'))
    assert compiled['coreSha256'] == hashes['Lokad.Lython.dll'] and len(compiled['rows']) == 3
    assert all(row['allowanceBaselineRestored'] for row in compiled['rows'])
    print(role, 'compile allocation', [(row['id'], statistics.median(row['allocatedBytesPerCompilation'])) for row in compiled['rows']], flush=True)

    assembly = lab / (role + '-call.asm')
    assembly_env = env | {'DOTNET_JitDisasm': 'Call', 'DOTNET_JitStdOutFile': str(assembly)}
    command = [str(dotnet), str(folder / 'Lokad.Lython.Benchmarks.dll'), '--compare', 'worker', '--catalog', str(catalog)]
    fixture = tempfile.TemporaryDirectory(prefix='lython-comparison-files-')
    messages = []
    for request_id in range(1, 10):
        message = dict(protocolVersion=2, requestId=request_id)
        if request_id == 9:
            message['operation'] = 'quit'
        else:
            operation = 'verify' if request_id == 1 else 'batch'
            message.update(operation=operation, caseId=case['id'], lane='warm', iterations=2 if operation == 'verify' else 16,
                           **{key: case[key] for key in ('sourceSha256', 'fixtureSha256', 'expectedOutputSha256')})
        messages.append(message)
    requests = io.BytesIO()
    for message in messages:
        protocol.write_frame(requests, message)
    try:
        result = subprocess.run(command, cwd=fixture.name, env=assembly_env, input=requests.getvalue(), capture_output=True, timeout=60)
    finally:
        fixture.cleanup()
    (lab / (role + '-call.stdout')).write_bytes(result.stdout)
    (lab / (role + '-call.stderr')).write_bytes(result.stderr)
    assert result.returncode == 0 and not result.stderr, result.stderr
    output = io.BytesIO(result.stdout)
    ready = protocol.read_frame(output)
    assert ready['status'] == 'Ready' and ready['catalogSha256'] == identity['catalogSHA256']
    assert next(v for v in ready['libraries'] if Path(v['path']).name == 'Lokad.Lython.dll')['sha256'].lower() == hashes['Lokad.Lython.dll']
    for message in messages:
        response = protocol.read_frame(output)
        assert response['requestId'] == message['requestId']
        expected = {'verify': 'Equivalent', 'batch': 'Completed', 'quit': 'Closed'}[message['operation']]
        assert response['status'] == expected, response
        if expected != 'Closed':
            assert response['completedInvocations'] == message['iterations']
            assert response['actualOutputSha256'] == case['expectedOutputSha256']
            assert response['actualFilesSha256'] == case.get('expectedFilesSha256')
    assert not output.read()
    text = assembly.read_text(encoding='utf-8')
    methods = re.findall(r'; Assembly listing for method ([^\n]*NativeExecution:Call[^\n]*).*?; Total bytes of code (\d+)', text, re.S)
    assert any(name.endswith('(Tier1)') for name, _ in methods), methods
    observations[role] = dict(core=hashes['Lokad.Lython.dll'], bodies=methods,
                              compileAllocatedBytes={row['id']: statistics.median(row['allocatedBytesPerCompilation']) for row in compiled['rows']})
    print(role, 'native Call versions', methods, flush=True)
(lab / 'diagnostics.json').write_text(json.dumps(dict(boundary='Actual frozen images on Windows x64, .NET 11 RC3. JIT diagnostics only, no timing inference.', rows=observations), indent=2) + '\n', encoding='utf-8')
