; Assembly listing for method Lokad.Lython.Frontend.ExecutableInstruction:Call(int,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Frontend.ExecutableInstruction (Tier0)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; Tier0 code
; rbp based frame
; partially interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 96
       lea      rbp, [rsp+0x60]
       vxorps   xmm4, xmm4, xmm4
       vmovdqu  ymmword ptr [rbp-0x20], ymm4
       mov      qword ptr [rbp+0x10], rcx
       mov      dword ptr [rbp+0x18], edx
       mov      gword ptr [rbp+0x20], r8
 
G_M000_IG02:                ;; offset=0x001E
       mov      dword ptr [rsp+0x20], 0x7FFFFFFF
       mov      dword ptr [rsp+0x28], 0x7FFFFFFF
       mov      dword ptr [rsp+0x30], -1
       xor      eax, eax
       mov      dword ptr [rsp+0x38], eax
       lea      rcx, [rbp-0x20]
       mov      r9d, dword ptr [rbp+0x18]
       mov      r8, gword ptr [rbp+0x20]
       mov      edx, 44
       call     [Lokad.Lython.Frontend.ExecutableInstruction:.ctor(int,Lokad.Lython.LythonSourceSpan,int,int,int,int,int):this]
       mov      rax, qword ptr [rbp+0x10]
 
G_M000_IG03:                ;; offset=0x0057
       vmovdqu  ymm0, ymmword ptr [rbp-0x20]
       vmovdqu  ymmword ptr [rax], ymm0
 
G_M000_IG04:                ;; offset=0x0060
       mov      rax, qword ptr [rbp+0x10]
 
G_M000_IG05:                ;; offset=0x0064
       vzeroupper 
       add      rsp, 96
       pop      rbp
       ret      
 
; Total bytes of code 109

; Assembly listing for method Lokad.Lython.Frontend.ExecutableInstruction:Call(int,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Frontend.ExecutableInstruction (Tier0)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; Tier0 code
; rbp based frame
; partially interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 96
       lea      rbp, [rsp+0x60]
       vxorps   xmm4, xmm4, xmm4
       vmovdqu  ymmword ptr [rbp-0x20], ymm4
       mov      qword ptr [rbp+0x10], rcx
       mov      dword ptr [rbp+0x18], edx
       mov      gword ptr [rbp+0x20], r8
 
G_M000_IG02:                ;; offset=0x001E
       mov      dword ptr [rsp+0x20], 0x7FFFFFFF
       mov      dword ptr [rsp+0x28], 0x7FFFFFFF
       mov      dword ptr [rsp+0x30], -1
       xor      eax, eax
       mov      dword ptr [rsp+0x38], eax
       lea      rcx, [rbp-0x20]
       mov      r9d, dword ptr [rbp+0x18]
       mov      r8, gword ptr [rbp+0x20]
       mov      edx, 44
       call     [Lokad.Lython.Frontend.ExecutableInstruction:.ctor(int,Lokad.Lython.LythonSourceSpan,int,int,int,int,int):this]
       mov      rax, qword ptr [rbp+0x10]
 
G_M000_IG03:                ;; offset=0x0057
       vmovdqu  ymm0, ymmword ptr [rbp-0x20]
       vmovdqu  ymmword ptr [rax], ymm0
 
G_M000_IG04:                ;; offset=0x0060
       mov      rax, qword ptr [rbp+0x10]
 
G_M000_IG05:                ;; offset=0x0064
       vzeroupper 
       add      rsp, 96
       pop      rbp
       ret      
 
; Total bytes of code 109

; Assembly listing for method Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Call(byref):bool:this (Tier0)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; Tier0 code
; rbp based frame
; fully interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 672
       lea      rbp, [rsp+0x2A0]
       xor      eax, eax
       mov      qword ptr [rbp-0x268], rax
       vxorps   xmm4, xmm4, xmm4
       vmovdqa  xmmword ptr [rbp-0x260], xmm4
       vmovdqa  xmmword ptr [rbp-0x250], xmm4
       mov      rax, -576
 
G_M000_IG48:                ;; offset=0x0037
       vmovdqa  xmmword ptr [rax+rbp], xmm4
       vmovdqa  xmmword ptr [rbp+rax+0x10], xmm4
       vmovdqa  xmmword ptr [rbp+rax+0x20], xmm4
       add      rax, 48
       jne      SHORT G_M000_IG48
       mov      bword ptr [rbp+0x10], rcx
       mov      bword ptr [rbp+0x18], rdx
 
G_M000_IG02:                ;; offset=0x0056
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax+0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_CallSites():System.Collections.Generic.IReadOnlyList`1[Lokad.Lython.Frontend.ExecutableCallSite]:this]
       mov      gword ptr [rbp-0xB0], rax
       mov      rcx, bword ptr [rbp+0x18]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_CallSiteIndex():int:this]
       mov      dword ptr [rbp-0x1D4], eax
       mov      edx, dword ptr [rbp-0x1D4]
       mov      rcx, gword ptr [rbp-0xB0]
       mov      r11, 0x7FF9C8CE20F8
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       mov      gword ptr [rbp-0x08], rax
       mov      rcx, bword ptr [rbp+0x18]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x0C], eax
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       add      rax, 80
       mov      bword ptr [rbp-0xB8], rax
       mov      rcx, gword ptr [rbp-0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_TargetOffset():int:this]
       add      eax, dword ptr [rbp-0x0C]
       mov      dword ptr [rbp-0xBC], eax
       mov      rax, bword ptr [rbp-0xB8]
       mov      eax, dword ptr [rax+0x08]
       cmp      dword ptr [rbp-0xBC], eax
       jae      G_M000_IG37
       mov      rax, bword ptr [rbp-0xB8]
       mov      ecx, dword ptr [rbp-0xBC]
       shl      rcx, 4
       add      rcx, bword ptr [rax]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Object():System.Object:this]
       mov      gword ptr [rbp-0x1E0], rax
       mov      rdx, gword ptr [rbp-0x1E0]
       mov      rcx, 0x7FF9C9768B50
       call     [Lokad.Lython.Internal.NullabilityExtensions:RequireNotNull[System.__Canon](System.__Canon):System.__Canon]
       mov      gword ptr [rbp-0x18], rax
       vxorps   xmm0, xmm0, xmm0
       vmovdqu  xmmword ptr [rbp-0x28], xmm0
 
G_M000_IG03:                ;; offset=0x012D
       mov      rcx, gword ptr [rbp-0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_IsPositionalOnly():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG04
       lea      rax, [rbp-0x28]
       mov      qword ptr [rsp+0x20], rax
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rbp-0x08]
       mov      r8d, dword ptr [rbp-0x0C]
       mov      r9, gword ptr [rbp-0x18]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:CallFunction(Lokad.Lython.Frontend.ExecutableCallSite,int,System.Object,byref):bool:this]
       test     eax, eax
       jne      G_M000_IG32
       xor      eax, eax
       mov      dword ptr [rbp-0x2C], eax
       jmp      G_M000_IG35
 
G_M000_IG04:                ;; offset=0x016E
       mov      rcx, gword ptr [rbp-0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_HasReceiver():bool:this]
       test     eax, eax
       jne      G_M000_IG08
       mov      rcx, gword ptr [rbp-0x18]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:IsRangeBuiltin(System.Object):bool]
       test     eax, eax
       je       G_M000_IG08
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       add      rax, 80
       mov      bword ptr [rbp-0x190], rax
       mov      rcx, gword ptr [rbp-0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_ArgumentOffset():int:this]
       add      eax, dword ptr [rbp-0x0C]
       mov      dword ptr [rbp-0x194], eax
       mov      rcx, gword ptr [rbp-0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_ArgumentCount():int:this]
       mov      dword ptr [rbp-0x1E4], eax
       mov      r9d, dword ptr [rbp-0x1E4]
       lea      rdx, [rbp-0x1A8]
       mov      r8d, dword ptr [rbp-0x194]
       mov      rcx, bword ptr [rbp-0x190]
       call     [System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:Slice(int,int):System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:this]
 
G_M000_IG05:                ;; offset=0x01F2
       vmovdqu  xmm0, xmmword ptr [rbp-0x1A8]
       vmovdqu  xmmword ptr [rbp-0x1F8], xmm0
 
G_M000_IG06:                ;; offset=0x0202
       mov      rcx, gword ptr [rbp-0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_CallSpan():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x200], rax
       mov      rdx, gword ptr [rbp-0x200]
       lea      rcx, [rbp-0x1F8]
       lea      r9, [rbp-0x38]
       mov      rax, bword ptr [rbp+0x10]
       mov      r8, gword ptr [rax+0x18]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryInvokeNativeRange(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       test     eax, eax
       jne      SHORT G_M000_IG07
       xor      eax, eax
       mov      dword ptr [rbp-0x2C], eax
       jmp      G_M000_IG35
 
G_M000_IG07:                ;; offset=0x0243
       lea      rcx, [rbp-0x28]
       mov      rdx, gword ptr [rbp-0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:set_Object(System.Object):this]
       jmp      G_M000_IG32
 
G_M000_IG08:                ;; offset=0x0256
       mov      rcx, gword ptr [rbp-0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_HasReceiver():bool:this]
       test     eax, eax
       je       G_M000_IG24
       mov      rdx, gword ptr [rbp-0x18]
       mov      rcx, 0x7FF9C970D7A8
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      gword ptr [rbp-0x40], rax
       cmp      gword ptr [rbp-0x40], 0
       je       G_M000_IG24
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       add      rax, 80
       mov      bword ptr [rbp-0xE8], rax
       mov      rax, bword ptr [rbp-0xE8]
       mov      eax, dword ptr [rax+0x08]
       cmp      dword ptr [rbp-0x0C], eax
       jae      G_M000_IG31
       mov      rax, bword ptr [rbp-0xE8]
       mov      ecx, dword ptr [rbp-0x0C]
       shl      rcx, 4
       add      rcx, bword ptr [rax]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Object():System.Object:this]
       mov      gword ptr [rbp-0x48], rax
       mov      rcx, gword ptr [rbp-0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_ArgumentCount():int:this]
       test     eax, eax
       jne      G_M000_IG20
       mov      rdx, gword ptr [rbp-0x48]
       mov      rcx, 0x7FF9C9593EB0
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      gword ptr [rbp-0x50], rax
       cmp      gword ptr [rbp-0x50], 0
       je       G_M000_IG20
       mov      rcx, gword ptr [rbp-0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_CasedSplit():Lokad.Lython.Frontend.ExecutableCasedSplit:this]
       mov      gword ptr [rbp-0x58], rax
       cmp      gword ptr [rbp-0x58], 0
       je       G_M000_IG20
       mov      rcx, gword ptr [rbp-0x58]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCasedSplit:get_CasingMethod():Lokad.Lython.Runtime.LythonRuntime+ReceiverMethod:this]
       cmp      rax, gword ptr [rbp-0x18]
       jne      G_M000_IG20
       mov      rax, bword ptr [rbp+0x10]
 
G_M000_IG09:                ;; offset=0x033C
       mov      rcx, gword ptr [rax+0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Instructions():Lokad.Lython.Frontend.ExecutableInstruction[]:this]
       mov      rcx, bword ptr [rbp+0x10]
       mov      ecx, dword ptr [rcx+0x40]
       add      ecx, 2
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG31
       mov      edx, ecx
       imul     rdx, rdx, 32
       lea      rax, bword ptr [rax+rdx+0x10]
 
G_M000_IG10:                ;; offset=0x0366
       vmovdqu  ymm0, ymmword ptr [rax]
       vmovdqu  ymmword ptr [rbp-0x80], ymm0
 
G_M000_IG11:                ;; offset=0x036F
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax+0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_CallSites():System.Collections.Generic.IReadOnlyList`1[Lokad.Lython.Frontend.ExecutableCallSite]:this]
       mov      gword ptr [rbp-0x110], rax
       lea      rcx, [rbp-0x80]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_CallSiteIndex():int:this]
       mov      dword ptr [rbp-0x204], eax
       mov      edx, dword ptr [rbp-0x204]
       mov      rcx, gword ptr [rbp-0x110]
       mov      r11, 0x7FF9C8CE2100
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       mov      gword ptr [rbp-0x88], rax
       mov      rax, bword ptr [rbp+0x10]
       mov      rax, gword ptr [rax+0x18]
       mov      gword ptr [rbp-0x118], rax
       mov      rcx, gword ptr [rbp-0x58]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCasedSplit:get_CasingCallSpan():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x210], rax
       mov      rdx, gword ptr [rbp-0x210]
       mov      rcx, gword ptr [rbp-0x118]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:EnterInterpreterFrame(Lokad.Lython.LythonSourceSpan):this]
       nop      
 
G_M000_IG12:                ;; offset=0x03F0
       mov      rax, bword ptr [rbp+0x10]
       mov      rax, gword ptr [rax+0x18]
       mov      gword ptr [rbp-0x120], rax
       lea      rax, bword ptr [rbp-0x28]
       mov      bword ptr [rbp-0x128], rax
       mov      rax, gword ptr [rbp-0x58]
       mov      gword ptr [rbp-0x130], rax
       mov      rax, gword ptr [rbp-0x50]
       mov      gword ptr [rbp-0x138], rax
       mov      rax, gword ptr [rbp-0x120]
       mov      gword ptr [rbp-0x140], rax
       mov      rcx, gword ptr [rbp-0x88]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_ConsumedByIteration():bool:this]
       test     eax, eax
       jne      G_M000_IG14
       mov      rax, bword ptr [rbp-0x128]
       mov      bword ptr [rbp-0x170], rax
       mov      rax, gword ptr [rbp-0x130]
       mov      gword ptr [rbp-0x178], rax
       mov      rax, gword ptr [rbp-0x138]
       mov      gword ptr [rbp-0x180], rax
       mov      rax, gword ptr [rbp-0x140]
       mov      gword ptr [rbp-0x188], rax
       mov      rax, bword ptr [rbp+0x10]
       movzx    rax, byte  ptr [rax+0x48]
       test     eax, eax
       je       SHORT G_M000_IG13
       mov      rax, bword ptr [rbp-0x170]
       mov      bword ptr [rbp-0x148], rax
       mov      rax, gword ptr [rbp-0x178]
       mov      gword ptr [rbp-0x150], rax
       mov      rax, gword ptr [rbp-0x180]
       mov      gword ptr [rbp-0x158], rax
       mov      rax, gword ptr [rbp-0x188]
       mov      gword ptr [rbp-0x160], rax
       mov      rcx, gword ptr [rbp-0x88]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_ReturnedDirectly():bool:this]
       mov      dword ptr [rbp-0x164], eax
       jmp      G_M000_IG15
 
G_M000_IG13:                ;; offset=0x04DB
       mov      rax, bword ptr [rbp-0x170]
       mov      bword ptr [rbp-0x148], rax
       mov      rax, gword ptr [rbp-0x178]
       mov      gword ptr [rbp-0x150], rax
       mov      rax, gword ptr [rbp-0x180]
       mov      gword ptr [rbp-0x158], rax
       mov      rax, gword ptr [rbp-0x188]
       mov      gword ptr [rbp-0x160], rax
       xor      eax, eax
       mov      dword ptr [rbp-0x164], eax
       jmp      SHORT G_M000_IG15
 
G_M000_IG14:                ;; offset=0x051D
       mov      rax, bword ptr [rbp-0x128]
       mov      bword ptr [rbp-0x148], rax
       mov      rax, gword ptr [rbp-0x130]
       mov      gword ptr [rbp-0x150], rax
       mov      rax, gword ptr [rbp-0x138]
       mov      gword ptr [rbp-0x158], rax
       mov      rax, gword ptr [rbp-0x140]
       mov      gword ptr [rbp-0x160], rax
       mov      dword ptr [rbp-0x164], 1
 
G_M000_IG15:                ;; offset=0x055F
       mov      rcx, gword ptr [rbp-0x150]
       mov      rdx, gword ptr [rbp-0x158]
       mov      r8, gword ptr [rbp-0x160]
       mov      r9d, dword ptr [rbp-0x164]
       call     [Lokad.Lython.Runtime.LythonRuntime:ExecuteCasedSplit(Lokad.Lython.Frontend.ExecutableCasedSplit,Lokad.Lython.Runtime.Text.PyString,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,bool):System.Object]
       mov      gword ptr [rbp-0x218], rax
       mov      rdx, gword ptr [rbp-0x218]
       mov      rcx, bword ptr [rbp-0x148]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:set_Object(System.Object):this]
       nop      
 
G_M000_IG16:                ;; offset=0x059D
       call     G_M000_IG38
       nop      
 
G_M000_IG17:                ;; offset=0x05A3
       mov      rax, bword ptr [rbp+0x10]
       add      dword ptr [rax+0x40], 2
 
G_M000_IG18:                ;; offset=0x05AB
       vmovdqu  xmm0, xmmword ptr [rbp-0x28]
       vmovdqu  xmmword ptr [rbp-0x228], xmm0
 
G_M000_IG19:                ;; offset=0x05B8
       lea      r8, [rbp-0x228]
       lea      rdx, [rbp-0x80]
       mov      rcx, bword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot):this]
       mov      dword ptr [rbp-0x2C], 1
       jmp      G_M000_IG35
 
G_M000_IG20:                ;; offset=0x05D9
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       add      rax, 80
       mov      bword ptr [rbp-0xF0], rax
       mov      rcx, gword ptr [rbp-0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_ArgumentOffset():int:this]
       add      eax, dword ptr [rbp-0x0C]
       mov      dword ptr [rbp-0xF4], eax
       mov      rcx, gword ptr [rbp-0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_ArgumentCount():int:this]
       mov      dword ptr [rbp-0x22C], eax
       mov      r9d, dword ptr [rbp-0x22C]
       lea      rdx, [rbp-0x108]
       mov      r8d, dword ptr [rbp-0xF4]
       mov      rcx, bword ptr [rbp-0xF0]
       call     [System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:Slice(int,int):System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:this]
 
G_M000_IG21:                ;; offset=0x0637
       vmovdqu  xmm0, xmmword ptr [rbp-0x108]
       vmovdqu  xmmword ptr [rbp-0x240], xmm0
 
G_M000_IG22:                ;; offset=0x0647
       mov      rcx, gword ptr [rbp-0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_CallSpan():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x248], rax
       mov      rax, bword ptr [rbp+0x10]
       mov      rax, gword ptr [rax+0x18]
       mov      gword ptr [rsp+0x20], rax
       lea      rax, [rbp-0x60]
       mov      qword ptr [rsp+0x28], rax
       mov      r9, gword ptr [rbp-0x248]
       lea      r8, [rbp-0x240]
       mov      rdx, gword ptr [rbp-0x48]
       mov      rcx, gword ptr [rbp-0x40]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryInvokeClosedReceiver(Lokad.Lython.Runtime.LythonRuntime+ReceiverMethod,System.Object,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       test     eax, eax
       jne      SHORT G_M000_IG23
       xor      eax, eax
       mov      dword ptr [rbp-0x2C], eax
       jmp      G_M000_IG35
 
G_M000_IG23:                ;; offset=0x069A
       lea      rcx, [rbp-0x28]
       mov      rdx, gword ptr [rbp-0x60]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:set_Object(System.Object):this]
       jmp      G_M000_IG32
 
G_M000_IG24:                ;; offset=0x06AD
       mov      rcx, gword ptr [rbp-0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_ArgumentCount():int:this]
       cmp      eax, 1
       jne      SHORT G_M000_IG25
       mov      rcx, gword ptr [rbp-0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_HasReceiver():bool:this]
       test     eax, eax
       je       SHORT G_M000_IG26
 
G_M000_IG25:                ;; offset=0x06CE
       xor      rax, rax
       mov      gword ptr [rbp-0xC8], rax
       jmp      SHORT G_M000_IG27
 
G_M000_IG26:                ;; offset=0x06D9
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       add      rax, 80
       mov      bword ptr [rbp-0xD8], rax
       mov      rcx, gword ptr [rbp-0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_ArgumentOffset():int:this]
       add      eax, dword ptr [rbp-0x0C]
       mov      dword ptr [rbp-0xDC], eax
       mov      rax, bword ptr [rbp-0xD8]
       mov      eax, dword ptr [rax+0x08]
       cmp      dword ptr [rbp-0xDC], eax
       jae      G_M000_IG31
       mov      rax, bword ptr [rbp-0xD8]
       mov      ecx, dword ptr [rbp-0xDC]
       shl      rcx, 4
       add      rcx, bword ptr [rax]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Object():System.Object:this]
       mov      gword ptr [rbp-0xC8], rax
 
G_M000_IG27:                ;; offset=0x073A
       mov      rax, gword ptr [rbp-0xC8]
       mov      gword ptr [rbp-0x90], rax
       xor      eax, eax
       mov      dword ptr [rbp-0x98], eax
       cmp      gword ptr [rbp-0x90], 0
       jne      SHORT G_M000_IG28
       xor      rax, rax
       mov      gword ptr [rbp-0xD0], rax
       jmp      SHORT G_M000_IG29
 
G_M000_IG28:                ;; offset=0x0765
       lea      r8, [rbp-0x98]
       mov      rcx, gword ptr [rbp-0x18]
       mov      rdx, gword ptr [rbp-0x90]
       call     [Lokad.Lython.Runtime.LythonRuntime:SelectNativeUnaryOperation(System.Object,System.Object,byref):System.Func`4[System.Object,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]]
       mov      gword ptr [rbp-0xD0], rax
 
G_M000_IG29:                ;; offset=0x0784
       mov      rax, gword ptr [rbp-0xD0]
       mov      gword ptr [rbp-0xA0], rax
       movzx    rax, byte  ptr [rbp-0x98]
       cmp      gword ptr [rbp-0xA0], 0
       setne    cl
       movzx    rcx, cl
       and      eax, ecx
       test     eax, eax
       je       SHORT G_M000_IG30
       mov      rcx, gword ptr [rbp-0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_CallSpan():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x250], rax
       mov      rax, bword ptr [rbp+0x10]
       mov      rax, gword ptr [rax+0x18]
       mov      gword ptr [rsp+0x20], rax
       mov      r9, gword ptr [rbp-0x250]
       lea      rcx, [rbp-0x28]
       mov      rdx, gword ptr [rbp-0x90]
       mov      r8, gword ptr [rbp-0xA0]
       call     [Lokad.Lython.Runtime.LythonRuntime:InvokeSingleInput(System.Object,System.Func`4[System.Object,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]
       jmp      SHORT G_M000_IG32
 
G_M000_IG30:                ;; offset=0x07EE
       lea      rax, [rbp-0x28]
       mov      qword ptr [rsp+0x20], rax
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rbp-0x08]
       mov      r8d, dword ptr [rbp-0x0C]
       mov      r9, gword ptr [rbp-0x18]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:CallFunction(Lokad.Lython.Frontend.ExecutableCallSite,int,System.Object,byref):bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG32
       xor      eax, eax
       mov      dword ptr [rbp-0x2C], eax
       jmp      SHORT G_M000_IG35
 
G_M000_IG31:                ;; offset=0x0818
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG32:                ;; offset=0x081E
       vmovdqu  xmm0, xmmword ptr [rbp-0x28]
       vmovdqu  xmmword ptr [rbp-0x268], xmm0
 
G_M000_IG33:                ;; offset=0x082B
       lea      r8, [rbp-0x268]
       mov      rdx, bword ptr [rbp+0x18]
       mov      rcx, bword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot):this]
       mov      eax, 1
 
G_M000_IG34:                ;; offset=0x0845
       vzeroupper 
       add      rsp, 672
       pop      rbp
       ret      
 
G_M000_IG35:                ;; offset=0x0851
       mov      eax, dword ptr [rbp-0x2C]
 
G_M000_IG36:                ;; offset=0x0854
       vzeroupper 
       add      rsp, 672
       pop      rbp
       ret      
 
G_M000_IG37:                ;; offset=0x0860
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG38:                ;; offset=0x0866
       sub      rsp, 56
 
G_M000_IG39:                ;; offset=0x086A
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax+0x18]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:LeaveInterpreterFrame():this]
       nop      
 
G_M000_IG40:                ;; offset=0x087B
       vzeroupper 
       add      rsp, 56
       ret      
 
G_M000_IG41:                ;; offset=0x0883
       sub      rsp, 56
 
G_M000_IG42:                ;; offset=0x0887
       mov      gword ptr [rbp-0x1B0], rcx
       mov      rdx, gword ptr [rbp-0x1B0]
       mov      rcx, 0x7FF9C8DE2168
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      gword ptr [rbp-0x1B8], rax
       mov      rax, gword ptr [rbp-0x1B8]
       mov      gword ptr [rbp-0x1C0], rax
       cmp      gword ptr [rbp-0x1B8], 0
       jne      SHORT G_M000_IG43
       xor      eax, eax
       mov      dword ptr [rbp-0x1C4], eax
       jmp      SHORT G_M000_IG44
 
G_M000_IG43:                ;; offset=0x08CE
       mov      rcx, gword ptr [rbp-0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_CallSpan():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x258], rax
       mov      rdx, gword ptr [rbp-0x258]
       lea      r8, [rbp-0xA8]
       mov      rcx, gword ptr [rbp-0x1C0]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryTranslateCallableException(System.Exception,Lokad.Lython.LythonSourceSpan,byref):bool]
       test     eax, eax
       setne    al
       movzx    rax, al
       mov      dword ptr [rbp-0x1C4], eax
 
G_M000_IG44:                ;; offset=0x090A
       mov      eax, dword ptr [rbp-0x1C4]
 
G_M000_IG45:                ;; offset=0x0910
       vzeroupper 
       add      rsp, 56
       ret      
 
G_M000_IG46:                ;; offset=0x0918
       sub      rsp, 56
 
G_M000_IG47:                ;; offset=0x091C
       mov      gword ptr [rbp-0x1D0], rcx
       mov      rcx, gword ptr [rbp-0xA8]
       call     CORINFO_HELP_THROW
       int3     
 
; Total bytes of code 2352

; Assembly listing for method Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Call(byref):bool:this (Instrumented Tier0)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; Instrumented Tier0 code
; rbp based frame
; fully interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 720
       lea      rbp, [rsp+0x2D0]
       xor      eax, eax
       mov      qword ptr [rbp-0x298], rax
       vxorps   xmm4, xmm4, xmm4
       vmovdqa  xmmword ptr [rbp-0x290], xmm4
       vmovdqa  xmmword ptr [rbp-0x280], xmm4
       mov      rax, -624
 
G_M000_IG57:                ;; offset=0x0037
       vmovdqa  xmmword ptr [rax+rbp], xmm4
       vmovdqa  xmmword ptr [rbp+rax+0x10], xmm4
       vmovdqa  xmmword ptr [rbp+rax+0x20], xmm4
       add      rax, 48
       jne      SHORT G_M000_IG57
       mov      bword ptr [rbp+0x10], rcx
       mov      bword ptr [rbp+0x18], rdx
 
G_M000_IG02:                ;; offset=0x0056
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax+0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_CallSites():System.Collections.Generic.IReadOnlyList`1[Lokad.Lython.Frontend.ExecutableCallSite]:this]
       mov      gword ptr [rbp-0xB0], rax
       mov      rax, gword ptr [rbp-0xB0]
       mov      gword ptr [rbp-0x1D8], rax
       mov      rcx, gword ptr [rbp-0x1D8]
       mov      rdx, 0x7FF9C98EB3E0
       call     CORINFO_HELP_CLASSPROFILE32
       mov      rax, gword ptr [rbp-0x1D8]
       mov      gword ptr [rbp-0x1F0], rax
       mov      rcx, bword ptr [rbp+0x18]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_CallSiteIndex():int:this]
       mov      dword ptr [rbp-0x1F4], eax
       mov      rcx, gword ptr [rbp-0x1F0]
       mov      edx, dword ptr [rbp-0x1F4]
       mov      r11, 0x7FF9C8CE2418
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       mov      gword ptr [rbp-0x08], rax
       mov      rcx, bword ptr [rbp+0x18]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x0C], eax
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       add      rax, 80
       mov      bword ptr [rbp-0xB8], rax
       mov      rcx, gword ptr [rbp-0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_TargetOffset():int:this]
       add      eax, dword ptr [rbp-0x0C]
       mov      dword ptr [rbp-0xBC], eax
       mov      rax, bword ptr [rbp-0xB8]
       mov      eax, dword ptr [rax+0x08]
       cmp      dword ptr [rbp-0xBC], eax
       jae      G_M000_IG46
       mov      rax, bword ptr [rbp-0xB8]
       mov      ecx, dword ptr [rbp-0xBC]
       shl      rcx, 4
       add      rcx, bword ptr [rax]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Object():System.Object:this]
       mov      gword ptr [rbp-0x200], rax
       mov      rdx, gword ptr [rbp-0x200]
       mov      rcx, 0x7FF9C9768B50
       call     [Lokad.Lython.Internal.NullabilityExtensions:RequireNotNull[System.__Canon](System.__Canon):System.__Canon]
       mov      gword ptr [rbp-0x18], rax
       vxorps   xmm0, xmm0, xmm0
       vmovdqu  xmmword ptr [rbp-0x28], xmm0
 
G_M000_IG03:                ;; offset=0x015F
       mov      rcx, gword ptr [rbp-0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_IsPositionalOnly():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG04
       lea      rax, [rbp-0x28]
       mov      qword ptr [rsp+0x20], rax
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rbp-0x08]
       mov      r8d, dword ptr [rbp-0x0C]
       mov      r9, gword ptr [rbp-0x18]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:CallFunction(Lokad.Lython.Frontend.ExecutableCallSite,int,System.Object,byref):bool:this]
       test     eax, eax
       jne      G_M000_IG39
       xor      eax, eax
       mov      dword ptr [rbp-0x2C], eax
       jmp      G_M000_IG44
 
G_M000_IG04:                ;; offset=0x01A0
       mov      rcx, gword ptr [rbp-0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_HasReceiver():bool:this]
       test     eax, eax
       jne      G_M000_IG09
       mov      rcx, gword ptr [rbp-0x18]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:IsRangeBuiltin(System.Object):bool]
       test     eax, eax
       je       G_M000_IG07
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       add      rax, 80
       mov      bword ptr [rbp-0x190], rax
       mov      rcx, gword ptr [rbp-0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_ArgumentOffset():int:this]
       add      eax, dword ptr [rbp-0x0C]
       mov      dword ptr [rbp-0x194], eax
       mov      rcx, gword ptr [rbp-0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_ArgumentCount():int:this]
       mov      dword ptr [rbp-0x204], eax
       mov      r9d, dword ptr [rbp-0x204]
       lea      rdx, [rbp-0x1A8]
       mov      r8d, dword ptr [rbp-0x194]
       mov      rcx, bword ptr [rbp-0x190]
       call     [System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:Slice(int,int):System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:this]
 
G_M000_IG05:                ;; offset=0x0224
       vmovdqu  xmm0, xmmword ptr [rbp-0x1A8]
       vmovdqu  xmmword ptr [rbp-0x218], xmm0
 
G_M000_IG06:                ;; offset=0x0234
       mov      rcx, gword ptr [rbp-0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_CallSpan():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x220], rax
       mov      rdx, gword ptr [rbp-0x220]
       lea      rcx, [rbp-0x218]
       lea      r9, [rbp-0x38]
       mov      rax, bword ptr [rbp+0x10]
       mov      r8, gword ptr [rax+0x18]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryInvokeNativeRange(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       test     eax, eax
       jne      SHORT G_M000_IG08
       mov      rcx, 0x7FF9C98EB4E8
       call     CORINFO_HELP_COUNTPROFILE32
       xor      eax, eax
       mov      dword ptr [rbp-0x2C], eax
       jmp      G_M000_IG44
 
G_M000_IG07:                ;; offset=0x0284
       mov      rcx, 0x7FF9C98EB4EC
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG09
 
G_M000_IG08:                ;; offset=0x0295
       mov      rcx, 0x7FF9C98EB4F0
       call     CORINFO_HELP_COUNTPROFILE32
       lea      rcx, [rbp-0x28]
       mov      rdx, gword ptr [rbp-0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:set_Object(System.Object):this]
       jmp      G_M000_IG39
 
G_M000_IG09:                ;; offset=0x02B7
       mov      rcx, gword ptr [rbp-0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_HasReceiver():bool:this]
       test     eax, eax
       je       G_M000_IG29
       mov      rdx, gword ptr [rbp-0x18]
       mov      rcx, 0x7FF9C970D7A8
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      gword ptr [rbp-0x40], rax
       cmp      gword ptr [rbp-0x40], 0
       je       G_M000_IG21
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       add      rax, 80
       mov      bword ptr [rbp-0xE8], rax
       mov      rax, bword ptr [rbp-0xE8]
       mov      eax, dword ptr [rax+0x08]
       cmp      dword ptr [rbp-0x0C], eax
       jae      G_M000_IG37
       mov      rax, bword ptr [rbp-0xE8]
       mov      ecx, dword ptr [rbp-0x0C]
       shl      rcx, 4
       add      rcx, bword ptr [rax]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Object():System.Object:this]
       mov      gword ptr [rbp-0x48], rax
       mov      rcx, gword ptr [rbp-0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_ArgumentCount():int:this]
       test     eax, eax
       jne      G_M000_IG25
       mov      rdx, gword ptr [rbp-0x48]
       mov      rcx, 0x7FF9C9593EB0
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      gword ptr [rbp-0x50], rax
       cmp      gword ptr [rbp-0x50], 0
       je       G_M000_IG20
       mov      rcx, gword ptr [rbp-0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_CasedSplit():Lokad.Lython.Frontend.ExecutableCasedSplit:this]
       mov      gword ptr [rbp-0x58], rax
       cmp      gword ptr [rbp-0x58], 0
       je       G_M000_IG19
       mov      rcx, gword ptr [rbp-0x58]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCasedSplit:get_CasingMethod():Lokad.Lython.Runtime.LythonRuntime+ReceiverMethod:this]
       cmp      rax, gword ptr [rbp-0x18]
       jne      G_M000_IG18
       mov      rax, bword ptr [rbp+0x10]
 
G_M000_IG10:                ;; offset=0x039D
       mov      rcx, gword ptr [rax+0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Instructions():Lokad.Lython.Frontend.ExecutableInstruction[]:this]
       mov      rcx, bword ptr [rbp+0x10]
       mov      ecx, dword ptr [rcx+0x40]
       add      ecx, 2
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG37
       mov      edx, ecx
       imul     rdx, rdx, 32
       lea      rax, bword ptr [rax+rdx+0x10]
 
G_M000_IG11:                ;; offset=0x03C7
       vmovdqu  ymm0, ymmword ptr [rax]
       vmovdqu  ymmword ptr [rbp-0x80], ymm0
 
G_M000_IG12:                ;; offset=0x03D0
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax+0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_CallSites():System.Collections.Generic.IReadOnlyList`1[Lokad.Lython.Frontend.ExecutableCallSite]:this]
       mov      gword ptr [rbp-0x110], rax
       mov      rax, gword ptr [rbp-0x110]
       mov      gword ptr [rbp-0x1E0], rax
       mov      rcx, gword ptr [rbp-0x1E0]
       mov      rdx, 0x7FF9C98EB4F8
       call     CORINFO_HELP_CLASSPROFILE32
       mov      rax, gword ptr [rbp-0x1E0]
       mov      gword ptr [rbp-0x228], rax
       lea      rcx, [rbp-0x80]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_CallSiteIndex():int:this]
       mov      dword ptr [rbp-0x22C], eax
       mov      rcx, gword ptr [rbp-0x228]
       mov      edx, dword ptr [rbp-0x22C]
       mov      r11, 0x7FF9C8CE2420
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       mov      gword ptr [rbp-0x88], rax
       mov      rax, bword ptr [rbp+0x10]
       mov      rax, gword ptr [rax+0x18]
       mov      gword ptr [rbp-0x118], rax
       mov      rcx, gword ptr [rbp-0x58]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCasedSplit:get_CasingCallSpan():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x238], rax
       mov      rdx, gword ptr [rbp-0x238]
       mov      rcx, gword ptr [rbp-0x118]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:EnterInterpreterFrame(Lokad.Lython.LythonSourceSpan):this]
       nop      
 
G_M000_IG13:                ;; offset=0x0483
       mov      rax, bword ptr [rbp+0x10]
       mov      rax, gword ptr [rax+0x18]
       mov      gword ptr [rbp-0x120], rax
       lea      rax, bword ptr [rbp-0x28]
       mov      bword ptr [rbp-0x128], rax
       mov      rax, gword ptr [rbp-0x58]
       mov      gword ptr [rbp-0x130], rax
       mov      rax, gword ptr [rbp-0x50]
       mov      gword ptr [rbp-0x138], rax
       mov      rax, gword ptr [rbp-0x120]
       mov      gword ptr [rbp-0x140], rax
       mov      rcx, gword ptr [rbp-0x88]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_ConsumedByIteration():bool:this]
       test     eax, eax
       jne      G_M000_IG15
       mov      rax, bword ptr [rbp-0x128]
       mov      bword ptr [rbp-0x170], rax
       mov      rax, gword ptr [rbp-0x130]
       mov      gword ptr [rbp-0x178], rax
       mov      rax, gword ptr [rbp-0x138]
       mov      gword ptr [rbp-0x180], rax
       mov      rax, gword ptr [rbp-0x140]
       mov      gword ptr [rbp-0x188], rax
       mov      rax, bword ptr [rbp+0x10]
       movzx    rax, byte  ptr [rax+0x48]
       test     eax, eax
       je       SHORT G_M000_IG14
       mov      rax, bword ptr [rbp-0x170]
       mov      bword ptr [rbp-0x148], rax
       mov      rax, gword ptr [rbp-0x178]
       mov      gword ptr [rbp-0x150], rax
       mov      rax, gword ptr [rbp-0x180]
       mov      gword ptr [rbp-0x158], rax
       mov      rax, gword ptr [rbp-0x188]
       mov      gword ptr [rbp-0x160], rax
       mov      rcx, gword ptr [rbp-0x88]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_ReturnedDirectly():bool:this]
       mov      dword ptr [rbp-0x164], eax
       jmp      G_M000_IG16
 
G_M000_IG14:                ;; offset=0x056E
       mov      rcx, 0x7FF9C98EB600
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp-0x170]
       mov      bword ptr [rbp-0x148], rax
       mov      rax, gword ptr [rbp-0x178]
       mov      gword ptr [rbp-0x150], rax
       mov      rax, gword ptr [rbp-0x180]
       mov      gword ptr [rbp-0x158], rax
       mov      rax, gword ptr [rbp-0x188]
       mov      gword ptr [rbp-0x160], rax
       xor      eax, eax
       mov      dword ptr [rbp-0x164], eax
       jmp      SHORT G_M000_IG16
 
G_M000_IG15:                ;; offset=0x05BF
       mov      rcx, 0x7FF9C98EB604
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp-0x128]
       mov      bword ptr [rbp-0x148], rax
       mov      rax, gword ptr [rbp-0x130]
       mov      gword ptr [rbp-0x150], rax
       mov      rax, gword ptr [rbp-0x138]
       mov      gword ptr [rbp-0x158], rax
       mov      rax, gword ptr [rbp-0x140]
       mov      gword ptr [rbp-0x160], rax
       mov      dword ptr [rbp-0x164], 1
 
G_M000_IG16:                ;; offset=0x0610
       mov      rcx, gword ptr [rbp-0x150]
       mov      rdx, gword ptr [rbp-0x158]
       mov      r8, gword ptr [rbp-0x160]
       mov      r9d, dword ptr [rbp-0x164]
       call     [Lokad.Lython.Runtime.LythonRuntime:ExecuteCasedSplit(Lokad.Lython.Frontend.ExecutableCasedSplit,Lokad.Lython.Runtime.Text.PyString,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,bool):System.Object]
       mov      gword ptr [rbp-0x240], rax
       mov      rdx, gword ptr [rbp-0x240]
       mov      rcx, bword ptr [rbp-0x148]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:set_Object(System.Object):this]
       nop      
 
G_M000_IG17:                ;; offset=0x064E
       call     G_M000_IG47
       jmp      SHORT G_M000_IG22
 
G_M000_IG18:                ;; offset=0x0655
       mov      rcx, 0x7FF9C98EB608
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG25
 
G_M000_IG19:                ;; offset=0x0666
       mov      rcx, 0x7FF9C98EB60C
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG25
 
G_M000_IG20:                ;; offset=0x0677
       mov      rcx, 0x7FF9C98EB610
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG25
 
G_M000_IG21:                ;; offset=0x0688
       mov      rcx, 0x7FF9C98EB614
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG29
 
G_M000_IG22:                ;; offset=0x069C
       mov      rcx, 0x7FF9C98EB61C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x10]
       add      dword ptr [rax+0x40], 2
 
G_M000_IG23:                ;; offset=0x06B3
       vmovdqu  xmm0, xmmword ptr [rbp-0x28]
       vmovdqu  xmmword ptr [rbp-0x250], xmm0
 
G_M000_IG24:                ;; offset=0x06C0
       lea      r8, [rbp-0x250]
       lea      rdx, [rbp-0x80]
       mov      rcx, bword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot):this]
       mov      dword ptr [rbp-0x2C], 1
       jmp      G_M000_IG44
 
G_M000_IG25:                ;; offset=0x06E1
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       add      rax, 80
       mov      bword ptr [rbp-0xF0], rax
       mov      rcx, gword ptr [rbp-0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_ArgumentOffset():int:this]
       add      eax, dword ptr [rbp-0x0C]
       mov      dword ptr [rbp-0xF4], eax
       mov      rcx, gword ptr [rbp-0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_ArgumentCount():int:this]
       mov      dword ptr [rbp-0x254], eax
       mov      r9d, dword ptr [rbp-0x254]
       lea      rdx, [rbp-0x108]
       mov      r8d, dword ptr [rbp-0xF4]
       mov      rcx, bword ptr [rbp-0xF0]
       call     [System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:Slice(int,int):System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:this]
 
G_M000_IG26:                ;; offset=0x073F
       vmovdqu  xmm0, xmmword ptr [rbp-0x108]
       vmovdqu  xmmword ptr [rbp-0x268], xmm0
 
G_M000_IG27:                ;; offset=0x074F
       mov      rcx, gword ptr [rbp-0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_CallSpan():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x270], rax
       mov      rax, bword ptr [rbp+0x10]
       mov      rax, gword ptr [rax+0x18]
       mov      gword ptr [rsp+0x20], rax
       lea      rax, [rbp-0x60]
       mov      qword ptr [rsp+0x28], rax
       mov      r9, gword ptr [rbp-0x270]
       lea      r8, [rbp-0x268]
       mov      rdx, gword ptr [rbp-0x48]
       mov      rcx, gword ptr [rbp-0x40]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryInvokeClosedReceiver(Lokad.Lython.Runtime.LythonRuntime+ReceiverMethod,System.Object,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       test     eax, eax
       jne      SHORT G_M000_IG28
       mov      rcx, 0x7FF9C98EB620
       call     CORINFO_HELP_COUNTPROFILE32
       xor      eax, eax
       mov      dword ptr [rbp-0x2C], eax
       jmp      G_M000_IG44
 
G_M000_IG28:                ;; offset=0x07B1
       mov      rcx, 0x7FF9C98EB624
       call     CORINFO_HELP_COUNTPROFILE32
       lea      rcx, [rbp-0x28]
       mov      rdx, gword ptr [rbp-0x60]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:set_Object(System.Object):this]
       jmp      G_M000_IG39
 
G_M000_IG29:                ;; offset=0x07D3
       mov      rcx, gword ptr [rbp-0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_ArgumentCount():int:this]
       cmp      eax, 1
       jne      SHORT G_M000_IG31
       mov      rcx, gword ptr [rbp-0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_HasReceiver():bool:this]
       test     eax, eax
       je       SHORT G_M000_IG32
 
G_M000_IG30:                ;; offset=0x07F4
       mov      rcx, 0x7FF9C98EB628
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG31:                ;; offset=0x0803
       xor      rax, rax
       mov      gword ptr [rbp-0xC8], rax
       jmp      SHORT G_M000_IG33
 
G_M000_IG32:                ;; offset=0x080E
       mov      rcx, 0x7FF9C98EB62C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       add      rax, 80
       mov      bword ptr [rbp-0xD8], rax
       mov      rcx, gword ptr [rbp-0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_ArgumentOffset():int:this]
       add      eax, dword ptr [rbp-0x0C]
       mov      dword ptr [rbp-0xDC], eax
       mov      rax, bword ptr [rbp-0xD8]
       mov      eax, dword ptr [rax+0x08]
       cmp      dword ptr [rbp-0xDC], eax
       jae      G_M000_IG37
       mov      rax, bword ptr [rbp-0xD8]
       mov      ecx, dword ptr [rbp-0xDC]
       shl      rcx, 4
       add      rcx, bword ptr [rax]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Object():System.Object:this]
       mov      gword ptr [rbp-0xC8], rax
 
G_M000_IG33:                ;; offset=0x087E
       mov      rax, gword ptr [rbp-0xC8]
       mov      gword ptr [rbp-0x90], rax
       xor      eax, eax
       mov      dword ptr [rbp-0x98], eax
       cmp      gword ptr [rbp-0x90], 0
       jne      SHORT G_M000_IG34
       xor      rax, rax
       mov      gword ptr [rbp-0xD0], rax
       jmp      SHORT G_M000_IG35
 
G_M000_IG34:                ;; offset=0x08A9
       mov      rcx, 0x7FF9C98EB630
       call     CORINFO_HELP_COUNTPROFILE32
       lea      r8, [rbp-0x98]
       mov      rcx, gword ptr [rbp-0x18]
       mov      rdx, gword ptr [rbp-0x90]
       call     [Lokad.Lython.Runtime.LythonRuntime:SelectNativeUnaryOperation(System.Object,System.Object,byref):System.Func`4[System.Object,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]]
       mov      gword ptr [rbp-0xD0], rax
 
G_M000_IG35:                ;; offset=0x08D7
       mov      rax, gword ptr [rbp-0xD0]
       mov      gword ptr [rbp-0xA0], rax
       movzx    rax, byte  ptr [rbp-0x98]
       cmp      gword ptr [rbp-0xA0], 0
       setne    cl
       movzx    rcx, cl
       and      eax, ecx
       test     eax, eax
       je       SHORT G_M000_IG36
       mov      rcx, 0x7FF9C98EB634
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, gword ptr [rbp-0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_CallSpan():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x278], rax
       mov      rax, bword ptr [rbp+0x10]
       mov      rax, gword ptr [rax+0x18]
       mov      gword ptr [rsp+0x20], rax
       mov      r9, gword ptr [rbp-0x278]
       lea      rcx, [rbp-0x28]
       mov      rdx, gword ptr [rbp-0x90]
       mov      r8, gword ptr [rbp-0xA0]
       call     [Lokad.Lython.Runtime.LythonRuntime:InvokeSingleInput(System.Object,System.Func`4[System.Object,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]
       jmp      SHORT G_M000_IG39
 
G_M000_IG36:                ;; offset=0x0950
       lea      rax, [rbp-0x28]
       mov      qword ptr [rsp+0x20], rax
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rbp-0x08]
       mov      r8d, dword ptr [rbp-0x0C]
       mov      r9, gword ptr [rbp-0x18]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:CallFunction(Lokad.Lython.Frontend.ExecutableCallSite,int,System.Object,byref):bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG38
       mov      rcx, 0x7FF9C98EB638
       call     CORINFO_HELP_COUNTPROFILE32
       xor      eax, eax
       mov      dword ptr [rbp-0x2C], eax
       jmp      SHORT G_M000_IG44
 
G_M000_IG37:                ;; offset=0x0989
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG38:                ;; offset=0x098F
       mov      rcx, 0x7FF9C98EB63C
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG39:                ;; offset=0x099E
       nop      
 
G_M000_IG40:                ;; offset=0x099F
       mov      rcx, 0x7FF9C98EB750
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG41:                ;; offset=0x09AE
       vmovdqu  xmm0, xmmword ptr [rbp-0x28]
       vmovdqu  xmmword ptr [rbp-0x298], xmm0
 
G_M000_IG42:                ;; offset=0x09BB
       lea      r8, [rbp-0x298]
       mov      rdx, bword ptr [rbp+0x18]
       mov      rcx, bword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot):this]
       mov      eax, 1
 
G_M000_IG43:                ;; offset=0x09D5
       vzeroupper 
       add      rsp, 720
       pop      rbp
       ret      
 
G_M000_IG44:                ;; offset=0x09E1
       mov      rcx, 0x7FF9C98EB754
       call     CORINFO_HELP_COUNTPROFILE32
       mov      eax, dword ptr [rbp-0x2C]
 
G_M000_IG45:                ;; offset=0x09F3
       vzeroupper 
       add      rsp, 720
       pop      rbp
       ret      
 
G_M000_IG46:                ;; offset=0x09FF
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG47:                ;; offset=0x0A05
       sub      rsp, 56
 
G_M000_IG48:                ;; offset=0x0A09
       mov      rcx, 0x7FF9C98EB618
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax+0x18]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:LeaveInterpreterFrame():this]
       nop      
 
G_M000_IG49:                ;; offset=0x0A29
       vzeroupper 
       add      rsp, 56
       ret      
 
G_M000_IG50:                ;; offset=0x0A31
       sub      rsp, 56
 
G_M000_IG51:                ;; offset=0x0A35
       mov      gword ptr [rbp-0x1B0], rcx
       mov      rax, gword ptr [rbp-0x1B0]
       mov      gword ptr [rbp-0x1E8], rax
       mov      rcx, gword ptr [rbp-0x1E8]
       mov      rdx, 0x7FF9C98EB640
       call     CORINFO_HELP_CLASSPROFILE32
       mov      rax, gword ptr [rbp-0x1E8]
       mov      gword ptr [rbp-0x280], rax
       mov      rdx, gword ptr [rbp-0x280]
       mov      rcx, 0x7FF9C8DE2168
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      gword ptr [rbp-0x1B8], rax
       mov      rax, gword ptr [rbp-0x1B8]
       mov      gword ptr [rbp-0x1C0], rax
       cmp      gword ptr [rbp-0x1B8], 0
       jne      SHORT G_M000_IG52
       xor      eax, eax
       mov      dword ptr [rbp-0x1C4], eax
       jmp      SHORT G_M000_IG53
 
G_M000_IG52:                ;; offset=0x0AAE
       mov      rcx, 0x7FF9C98EB748
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, gword ptr [rbp-0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_CallSpan():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x288], rax
       mov      rdx, gword ptr [rbp-0x288]
       lea      r8, [rbp-0xA8]
       mov      rcx, gword ptr [rbp-0x1C0]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryTranslateCallableException(System.Exception,Lokad.Lython.LythonSourceSpan,byref):bool]
       test     eax, eax
       setne    al
       movzx    rax, al
       mov      dword ptr [rbp-0x1C4], eax
 
G_M000_IG53:                ;; offset=0x0AF9
       mov      rcx, 0x7FF9C98EB74C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      eax, dword ptr [rbp-0x1C4]
 
G_M000_IG54:                ;; offset=0x0B0E
       vzeroupper 
       add      rsp, 56
       ret      
 
G_M000_IG55:                ;; offset=0x0B16
       sub      rsp, 56
 
G_M000_IG56:                ;; offset=0x0B1A
       mov      gword ptr [rbp-0x1D0], rcx
       mov      rcx, gword ptr [rbp-0xA8]
       call     CORINFO_HELP_THROW
       int3     
 
; Total bytes of code 2862

; Assembly listing for method Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Call(byref):bool:this (Tier1)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; Tier1 code
; optimized code
; optimized using Synthesized PGO
; rbp based frame
; fully interruptible
; with Synthesized PGO: fgCalledCount is 9610
; 32 inlinees with PGO data; 99 single block inlinees; 2 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       push     r15
       push     r14
       push     r13
       push     r12
       push     rdi
       push     rsi
       push     rbx
       sub      rsp, 248
       lea      rbp, [rsp+0x130]
       xor      eax, eax
       mov      qword ptr [rbp-0xF8], rax
       vxorps   xmm4, xmm4, xmm4
       vmovdqu  ymmword ptr [rbp-0xF0], ymm4
       vmovdqu  ymmword ptr [rbp-0xD0], ymm4
       vmovdqu  ymmword ptr [rbp-0xB0], ymm4
       vmovdqu  ymmword ptr [rbp-0x90], ymm4
       vmovdqu  ymmword ptr [rbp-0x70], ymm4
       vmovdqa  xmmword ptr [rbp-0x50], xmm4
       mov      qword ptr [rbp-0x40], rax
       mov      bword ptr [rbp+0x10], rcx
       mov      rbx, rdx
 
G_M000_IG02:                ;; offset=0x005D
       mov      rax, gword ptr [rcx+0x08]
       mov      rax, gword ptr [rax+0x78]
       cmp      dword ptr [rbx+0x1C], 44
       jne      G_M000_IG132
       mov      edx, dword ptr [rbx+0x08]
       mov      r8, 0x7FF9C96AFD18
       cmp      qword ptr [rax], r8
       jne      G_M000_IG134
       mov      r8d, dword ptr [rax+0x08]
       cmp      r8d, edx
       jbe      G_M000_IG133
       mov      rsi, gword ptr [rax+8*rdx+0x10]
 
G_M000_IG03:                ;; offset=0x0097
       mov      gword ptr [rbp-0xD8], rsi
       mov      edi, dword ptr [rbx+0x10]
       mov      rcx, bword ptr [rbp+0x10]
       lea      rax, bword ptr [rcx+0x50]
       cmp      byte  ptr [rsi+0x30], 0
       setne    dl
       movzx    rdx, dl
       add      edx, edi
       cmp      edx, dword ptr [rax+0x08]
       jae      G_M000_IG151
       shl      rdx, 4
       add      rdx, bword ptr [rax]
       mov      r14, gword ptr [rdx]
       mov      rax, 0x25BA8403DE0
       mov      r15, gword ptr [rax]
       cmp      r14, r15
       je       G_M000_IG135
 
G_M000_IG04:                ;; offset=0x00DE
       mov      rax, 0x25BA8403DE8
       cmp      r14, gword ptr [rax]
       je       G_M000_IG136
       cmp      qword ptr [rdx+0x08], 0
       jne      G_M000_IG137
 
G_M000_IG05:                ;; offset=0x00FC
       test     r14, r14
       je       G_M000_IG138
       vxorps   xmm0, xmm0, xmm0
       vmovdqu  xmmword ptr [rbp-0x48], xmm0
 
G_M000_IG06:                ;; offset=0x010E
       cmp      byte  ptr [rsi+0x34], 0
       je       G_M000_IG85
 
G_M000_IG07:                ;; offset=0x0118
       cmp      byte  ptr [rsi+0x30], 0
       je       G_M000_IG86
 
G_M000_IG08:                ;; offset=0x0122
       cmp      byte  ptr [rsi+0x30], 0
       je       G_M000_IG29
       mov      rax, 0x7FF9C970D7A8
       cmp      qword ptr [r14], rax
       jne      G_M000_IG29
 
G_M000_IG09:                ;; offset=0x013F
       mov      rcx, bword ptr [rbp+0x10]
       lea      rax, bword ptr [rcx+0x50]
       cmp      edi, dword ptr [rax+0x08]
       jae      G_M000_IG106
       mov      edx, edi
       shl      rdx, 4
       add      rdx, bword ptr [rax]
       cmp      gword ptr [rdx], r15
       je       G_M000_IG89
 
G_M000_IG10:                ;; offset=0x0162
       mov      rax, gword ptr [rdx]
       mov      r8, 0x25BA8403DE8
       cmp      rax, gword ptr [r8]
       je       G_M000_IG90
       cmp      qword ptr [rdx+0x08], 0
       jne      G_M000_IG91
       mov      r13, gword ptr [rdx]
 
G_M000_IG11:                ;; offset=0x0186
       mov      r12d, dword ptr [rsi+0x28]
       test     r12d, r12d
       jne      SHORT G_M000_IG15
 
G_M000_IG12:                ;; offset=0x018F
       test     r13, r13
       je       SHORT G_M000_IG15
 
G_M000_IG13:                ;; offset=0x0194
       mov      rdx, 0x7FF9C9593EB0
       cmp      qword ptr [r13], rdx
       jne      SHORT G_M000_IG15
 
G_M000_IG14:                ;; offset=0x01A4
       mov      gword ptr [rbp-0xE0], r13
       mov      r10, gword ptr [rsi+0x20]
       mov      gword ptr [rbp-0xE8], r10
       test     r10, r10
       jne      G_M000_IG92
 
G_M000_IG15:                ;; offset=0x01BF
       mov      rcx, bword ptr [rbp+0x10]
       lea      rdx, bword ptr [rcx+0x50]
       cmp      byte  ptr [rsi+0x30], 0
       setne    r8b
       movzx    r8, r8b
       lea      r8d, [rdi+r8+0x01]
       mov      edi, r8d
       mov      r8d, r12d
       add      r8, rdi
       mov      r9d, dword ptr [rdx+0x08]
       cmp      r8, r9
       ja       G_M000_IG87
       shl      rdi, 4
       add      rdi, bword ptr [rdx]
       mov      rdx, gword ptr [rsi+0x18]
       mov      gword ptr [rbp-0xF0], rdx
       mov      r9, gword ptr [rcx+0x18]
       mov      gword ptr [rbp-0xF8], r9
       test     r12d, r12d
       je       G_M000_IG40
 
G_M000_IG16:                ;; offset=0x0214
       cmp      r12d, 1
       jne      SHORT G_M000_IG18
 
G_M000_IG17:                ;; offset=0x021A
       test     r13, r13
       jne      G_M000_IG53
 
G_M000_IG18:                ;; offset=0x0223
       test     r13, r13
       jne      G_M000_IG78
 
G_M000_IG19:                ;; offset=0x022C
       test     r13, r13
       je       G_M000_IG39
 
G_M000_IG20:                ;; offset=0x0235
       mov      rax, 0x7FF9C9737EE8
       cmp      qword ptr [r13], rax
       jne      G_M000_IG39
 
G_M000_IG21:                ;; offset=0x0249
       mov      rsi, r13
       cmp      r12d, 1
       je       SHORT G_M000_IG23
 
G_M000_IG22:                ;; offset=0x0252
       cmp      r12d, 2
       jne      G_M000_IG39
 
G_M000_IG23:                ;; offset=0x025C
       mov      rax, 0x25BA8403DF8
       cmp      r14, gword ptr [rax]
       jne      G_M000_IG39
 
G_M000_IG24:                ;; offset=0x026F
       test     r12d, r12d
       je       G_M000_IG106
       mov      rcx, rdi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Object():System.Object:this]
       mov      r14, rax
       mov      rcx, rsi
       mov      rdx, r14
       call     [Lokad.Lython.Runtime.PyDict:CanReadKeySynchronously(System.Object):bool:this]
       test     eax, eax
       je       G_M000_IG39
 
G_M000_IG25:                ;; offset=0x0298
       cmp      r12d, 2
       je       SHORT G_M000_IG28
 
G_M000_IG26:                ;; offset=0x029E
       mov      rcx, 0x25BA8401850
       mov      r8, gword ptr [rcx]
 
G_M000_IG27:                ;; offset=0x02AB
       mov      r9, gword ptr [rbp-0xF8]
       mov      gword ptr [rsp+0x20], r9
       mov      rcx, rsi
       mov      rdx, r14
       mov      r9, gword ptr [rbp-0xF0]
       call     [Lokad.Lython.Runtime.LythonRuntime:InvokeDictionaryGet(Lokad.Lython.Runtime.PyDict,System.Object,System.Object,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):System.Object]
       jmp      G_M000_IG51
 
G_M000_IG28:                ;; offset=0x02CF
       lea      rcx, bword ptr [rdi+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Object():System.Object:this]
       mov      r8, rax
       jmp      SHORT G_M000_IG27
 
G_M000_IG29:                ;; offset=0x02DE
       cmp      dword ptr [rsi+0x28], 1
       jne      SHORT G_M000_IG31
 
G_M000_IG30:                ;; offset=0x02E4
       cmp      byte  ptr [rsi+0x30], 0
       je       SHORT G_M000_IG36
 
G_M000_IG31:                ;; offset=0x02EA
       xor      r15, r15
 
G_M000_IG32:                ;; offset=0x02ED
       xor      r8d, r8d
       mov      dword ptr [rbp-0x78], r8d
       test     r15, r15
       jne      SHORT G_M000_IG37
 
G_M000_IG33:                ;; offset=0x02F9
       xor      r8, r8
 
G_M000_IG34:                ;; offset=0x02FC
       test     r8, r8
       setne    r9b
       movzx    r9, r9b
       movzx    rdx, byte  ptr [rbp-0x78]
       test     r9d, edx
       je       SHORT G_M000_IG38
 
G_M000_IG35:                ;; offset=0x0310
       mov      rcx, bword ptr [rbp+0x10]
       mov      r9, gword ptr [rcx+0x18]
       mov      gword ptr [rsp+0x20], r9
       mov      r9, gword ptr [rsi+0x18]
       lea      rcx, [rbp-0x48]
       mov      rdx, r15
       call     [Lokad.Lython.Runtime.LythonRuntime:InvokeSingleInput(System.Object,System.Func`4[System.Object,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]
       jmp      G_M000_IG108
 
G_M000_IG36:                ;; offset=0x0333
       mov      rcx, bword ptr [rbp+0x10]
       lea      rax, bword ptr [rcx+0x50]
       cmp      byte  ptr [rsi+0x30], 0
       setne    dl
       movzx    rdx, dl
       lea      edx, [rdi+rdx+0x01]
       cmp      edx, dword ptr [rax+0x08]
       jae      G_M000_IG106
       shl      rdx, 4
       add      rdx, bword ptr [rax]
       mov      rcx, rdx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Object():System.Object:this]
       mov      r15, rax
       jmp      SHORT G_M000_IG32
 
G_M000_IG37:                ;; offset=0x0367
       lea      r8, [rbp-0x78]
       mov      rcx, r14
       mov      rdx, r15
       call     [Lokad.Lython.Runtime.LythonRuntime:SelectNativeUnaryOperation(System.Object,System.Object,byref):System.Func`4[System.Object,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]]
       mov      r8, rax
       jmp      SHORT G_M000_IG34
 
G_M000_IG38:                ;; offset=0x037C
       lea      rdx, [rbp-0x48]
       mov      qword ptr [rsp+0x20], rdx
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, rsi
       mov      r8d, edi
       mov      r9, r14
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:CallFunction(Lokad.Lython.Frontend.ExecutableCallSite,int,System.Object,byref):bool:this]
       test     eax, eax
       jne      G_M000_IG108
 
G_M000_IG39:                ;; offset=0x03A0
       xor      eax, eax
       jmp      G_M000_IG131
 
G_M000_IG40:                ;; offset=0x03A7
       test     r13, r13
       je       SHORT G_M000_IG42
 
G_M000_IG41:                ;; offset=0x03AC
       mov      rdx, 0x7FF9C9593EB0
       cmp      qword ptr [r13], rdx
       je       SHORT G_M000_IG45
 
G_M000_IG42:                ;; offset=0x03BC
       mov      rdx, r13
       test     rdx, rdx
       je       SHORT G_M000_IG44
 
G_M000_IG43:                ;; offset=0x03C4
       mov      r8, 0x7FF9C9737EE8
       xor      r9, r9
       cmp      qword ptr [rdx], r8
       cmovne   rdx, r9
 
G_M000_IG44:                ;; offset=0x03D8
       test     rdx, rdx
       je       G_M000_IG16
 
G_M000_IG45:                ;; offset=0x03E1
       mov      rdx, gword ptr [r14+0x20]
       mov      rdx, gword ptr [rdx+0x10]
       cmp      dword ptr [rdx+0x08], 0
       jg       G_M000_IG16
       mov      r8, rdx
       movzx    r9, byte  ptr [r8+0x0C]
       mov      r8d, dword ptr [r8+0x10]
       test     r9d, r9d
       je       SHORT G_M000_IG46
       test     r8d, r8d
       jl       G_M000_IG16
 
G_M000_IG46:                ;; offset=0x040D
       test     rdx, rdx
       je       SHORT G_M000_IG50
 
G_M000_IG47:                ;; offset=0x0412
       mov      r9, 0x7FF9C948C210
       cmp      qword ptr [rdx], r9
       jne      SHORT G_M000_IG50
 
G_M000_IG48:                ;; offset=0x0421
       movzx    r9, byte  ptr [rdx+0x30]
       mov      r8d, dword ptr [rdx+0x34]
       test     r9d, r9d
       je       G_M000_IG102
       mov      edx, r8d
       not      edx
       shr      edx, 31
 
G_M000_IG49:                ;; offset=0x043B
       test     edx, edx
       je       G_M000_IG16
 
G_M000_IG50:                ;; offset=0x0443
       mov      rcx, r14
       mov      rdx, r13
       mov      r8, gword ptr [rbp-0xF0]
       mov      r9, gword ptr [rbp-0xF8]
       call     [Lokad.Lython.Runtime.LythonRuntime:InvokeReceiverMethod(Lokad.Lython.Runtime.LythonRuntime+ReceiverMethod,System.Object,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):System.Object]
 
G_M000_IG51:                ;; offset=0x045D
       mov      gword ptr [rbp-0x48], rax
 
G_M000_IG52:                ;; offset=0x0461
       xor      eax, eax
       mov      qword ptr [rbp-0x40], rax
       jmp      G_M000_IG108
 
G_M000_IG53:                ;; offset=0x046C
       mov      rax, 0x7FF9C973D360
       cmp      qword ptr [r13], rax
       jne      G_M000_IG18
 
G_M000_IG54:                ;; offset=0x0480
       mov      rax, 0x25BA8403DF0
       cmp      r14, gword ptr [rax]
       jne      G_M000_IG18
       mov      r12, gword ptr [rdi]
       cmp      r12, r15
       je       G_M000_IG103
 
G_M000_IG55:                ;; offset=0x049F
       mov      rax, 0x25BA8403DE8
       cmp      r12, gword ptr [rax]
       je       G_M000_IG104
       cmp      qword ptr [rdi+0x08], 0
       jne      G_M000_IG105
 
G_M000_IG56:                ;; offset=0x04BD
       mov      r9, gword ptr [rbp-0xF8]
       mov      rcx, gword ptr [r9+0x98]
       mov      rdx, gword ptr [rbp-0xF0]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.ExecutionState:EnterInterpreterFrame(Lokad.Lython.LythonSourceSpan):this]
       nop      
 
G_M000_IG57:                ;; offset=0x04DB
       mov      r9, gword ptr [rbp-0xF8]
       mov      rcx, gword ptr [r9+0x98]
       mov      rdx, gword ptr [rcx+0x88]
       cmp      gword ptr [rdx+0x20], 0
       jne      G_M000_IG66
       mov      rdx, gword ptr [rcx+0x178]
       test     rdx, rdx
       jne      G_M000_IG65
 
G_M000_IG58:                ;; offset=0x050B
       mov      r14, gword ptr [r14+0x08]
       mov      rcx, 0x7FF9C974AB08
       cmp      qword ptr [r14+0x18], rcx
       jne      G_M000_IG74
       mov      r9, gword ptr [rbp-0xF8]
       mov      rcx, gword ptr [r9+0x98]
       mov      r14, gword ptr [rcx+0x88]
       cmp      gword ptr [r13+0x10], 0
       je       G_M000_IG67
 
G_M000_IG59:                ;; offset=0x0543
       cmp      gword ptr [r13+0x18], 0
       je       G_M000_IG68
 
G_M000_IG60:                ;; offset=0x054E
       mov      edx, dword ptr [r13+0x28]
       add      edx, 1
       jo       G_M000_IG71
       mov      rcx, r13
       call     [Lokad.Lython.Runtime.PyList:EnsureCapacity(int):this]
       mov      rcx, gword ptr [r13+0x08]
       mov      edx, dword ptr [r13+0x28]
       lea      r8d, [rdx+0x01]
       mov      dword ptr [r13+0x28], r8d
       movsxd   rdx, edx
       mov      r8d, dword ptr [rcx+0x08]
       cmp      r8, rdx
       jbe      G_M000_IG69
       lea      rax, bword ptr [rcx+8*rdx+0x10]
       mov      rcx, qword ptr [rcx]
       mov      rdx, qword ptr [rcx+0x30]
       test     r12, r12
       je       G_M000_IG70
       cmp      rdx, qword ptr [r12]
       je       SHORT G_M000_IG62
 
G_M000_IG61:                ;; offset=0x059F
       mov      r8, 0x7FF9C8DA28A8
       cmp      rcx, r8
       jne      G_M000_IG72
 
G_M000_IG62:                ;; offset=0x05B2
       mov      rcx, rax
       mov      rdx, r12
       call     CORINFO_HELP_ASSIGN_REF
 
G_M000_IG63:                ;; offset=0x05BD
       mov      r9, gword ptr [rbp-0xF8]
       mov      r12, gword ptr [r9+0x98]
       cmp      byte  ptr [r12], r12b
       mov      rcx, r12
       call     [Lokad.Lython.Runtime.ExecutionState:get_CanContinue():bool:this]
       test     eax, eax
       je       G_M000_IG73
 
G_M000_IG64:                ;; offset=0x05E0
       mov      rax, 0x25BA8401850
       mov      rax, gword ptr [rax]
       jmp      G_M000_IG75
 
G_M000_IG65:                ;; offset=0x05F2
       cmp      dword ptr [rdx+0x20], 0
       setne    dl
       movzx    rdx, dl
       test     edx, edx
       je       G_M000_IG58
 
G_M000_IG66:                ;; offset=0x0604
       mov      rdx, gword ptr [rbp-0xF0]
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
       jmp      G_M000_IG58
 
G_M000_IG67:                ;; offset=0x0616
       mov      rcx, gword ptr [r13+0x08]
       mov      ecx, dword ptr [rcx+0x08]
       imul     rdi, rcx, 80
       jo       SHORT G_M000_IG71
       add      rdi, 64
       jo       SHORT G_M000_IG71
       mov      rcx, r14
       mov      rdx, rdi
       mov      r8, gword ptr [rbp-0xF0]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.MemoryGovernor:Reserve(long,Lokad.Lython.LythonSourceSpan):this]
       mov      rcx, r14
       mov      rdx, rdi
       call     [Lokad.Lython.Runtime.MemoryGovernor:Commit(long):this]
       mov      qword ptr [r13+0x20], rdi
       lea      rcx, bword ptr [r13+0x10]
       mov      rdx, r14
       call     CORINFO_HELP_ASSIGN_REF
       jmp      G_M000_IG59
 
G_M000_IG68:                ;; offset=0x065F
       lea      rcx, bword ptr [r13+0x18]
       mov      rdx, gword ptr [rbp-0xF0]
       call     CORINFO_HELP_ASSIGN_REF
       jmp      G_M000_IG60
 
G_M000_IG69:                ;; offset=0x0674
       call     [System.Runtime.CompilerServices.CastHelpers:ThrowIndexOutOfRangeException()]
       int3     
 
G_M000_IG70:                ;; offset=0x067B
       xor      rcx, rcx
       mov      gword ptr [rax], rcx
       jmp      G_M000_IG63
 
G_M000_IG71:                ;; offset=0x0685
       call     CORINFO_HELP_OVERFLOW
       int3     
 
G_M000_IG72:                ;; offset=0x068B
       mov      rcx, rax
       mov      r8, r12
       call     [System.Runtime.CompilerServices.CastHelpers:StelemRef_Helper(byref,ptr,System.Object)]
       jmp      G_M000_IG63
 
G_M000_IG73:                ;; offset=0x069C
       mov      rcx, r12
       mov      rdx, gword ptr [rbp-0xF0]
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
       jmp      G_M000_IG64
 
G_M000_IG74:                ;; offset=0x06B1
       mov      gword ptr [rbp-0xB0], r12
       mov      r8, 0x1FFFFFFFF
       mov      qword ptr [rbp-0xA8], r8
       mov      r9, gword ptr [rbp-0xF8]
       mov      gword ptr [rsp+0x20], r9
       lea      r8, [rbp-0xB0]
       mov      rdx, r13
       mov      r9, gword ptr [rbp-0xF0]
       mov      rcx, gword ptr [r14+0x10]
       call     [r14+0x18]System.Func`5[System.__Canon,Lokad.Lython.Runtime.LythonRuntime+ReceiverArguments,System.__Canon,System.__Canon,System.__Canon]:Invoke(System.__Canon,Lokad.Lython.Runtime.LythonRuntime+ReceiverArguments,System.__Canon,System.__Canon):System.__Canon:this
       nop      
 
G_M000_IG75:                ;; offset=0x06EF
       mov      r9, gword ptr [rbp-0xF8]
       mov      rdi, gword ptr [r9+0x98]
       mov      rcx, qword ptr [rdi+0x168]
       test     rcx, rcx
       jle      SHORT G_M000_IG77
 
G_M000_IG76:                ;; offset=0x0709
       dec      rcx
       mov      qword ptr [rdi+0x168], rcx
 
G_M000_IG77:                ;; offset=0x0713
       xor      rcx, rcx
       mov      gword ptr [rbp-0x90], rcx
       jmp      G_M000_IG51
 
G_M000_IG78:                ;; offset=0x0721
       mov      rdx, 0x7FF9C9593EB0
       cmp      qword ptr [r13], rdx
       jne      G_M000_IG19
 
G_M000_IG79:                ;; offset=0x0735
       mov      rsi, r13
       mov      edx, r12d
       sub      edx, 1
       cmp      edx, 2
       ja       G_M000_IG20
       mov      rcx, r14
       mov      edx, r12d
       call     [Lokad.Lython.Runtime.LythonRuntime:SelectNativeStringOperation(System.Object,int):System.Nullable`1[int]]
       mov      qword ptr [rbp-0x88], rax
       cmp      byte  ptr [rbp-0x88], 0
       je       G_M000_IG20
 
G_M000_IG80:                ;; offset=0x0767
       mov      rcx, rdi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Object():System.Object:this]
       mov      r13, rax
       cmp      r12d, 1
       jle      SHORT G_M000_IG84
 
G_M000_IG81:                ;; offset=0x0779
       lea      rcx, bword ptr [rdi+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Object():System.Object:this]
       mov      r14, rax
 
G_M000_IG82:                ;; offset=0x0786
       cmp      r12d, 2
       jg       G_M000_IG107
       xor      r12, r12
 
G_M000_IG83:                ;; offset=0x0793
       mov      ecx, dword ptr [rbp-0x84]
       mov      rdx, r13
       mov      r8, r14
       mov      r9, r12
       call     [Lokad.Lython.Runtime.LythonRuntime:CanUseNativeStringCall(int,System.Object,System.Object,System.Object):bool]
       test     eax, eax
       je       G_M000_IG39
       mov      gword ptr [rsp+0x20], r12
       mov      rdx, gword ptr [rbp-0xF0]
       mov      gword ptr [rsp+0x28], rdx
       mov      r9, gword ptr [rbp-0xF8]
       mov      gword ptr [rsp+0x30], r9
       mov      ecx, dword ptr [rbp-0x84]
       mov      rdx, rsi
       mov      r8, r13
       mov      r9, r14
       call     [Lokad.Lython.Runtime.LythonRuntime:InvokeNativeStringOperation(int,Lokad.Lython.Runtime.Text.PyString,System.Object,System.Object,System.Object,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):System.Object]
       jmp      G_M000_IG51
 
G_M000_IG84:                ;; offset=0x07E7
       xor      r14, r14
       jmp      SHORT G_M000_IG82
 
G_M000_IG85:                ;; offset=0x07EC
       lea      rdx, [rbp-0x48]
       mov      qword ptr [rsp+0x20], rdx
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, rsi
       mov      r8d, edi
       mov      r9, r14
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:CallFunction(Lokad.Lython.Frontend.ExecutableCallSite,int,System.Object,byref):bool:this]
       test     eax, eax
       jne      G_M000_IG108
       jmp      G_M000_IG39
 
G_M000_IG86:                ;; offset=0x0815
       mov      rcx, r14
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:IsRangeBuiltin(System.Object):bool]
       test     eax, eax
       je       G_M000_IG08
       mov      rcx, bword ptr [rbp+0x10]
       lea      rdx, bword ptr [rcx+0x50]
       cmp      byte  ptr [rsi+0x30], 0
       setne    r8b
       movzx    r8, r8b
       lea      r8d, [rdi+r8+0x01]
       mov      r9d, dword ptr [rsi+0x28]
       mov      eax, r8d
       mov      r10d, r9d
       add      rax, r10
       mov      r10d, dword ptr [rdx+0x08]
       cmp      rax, r10
       jbe      SHORT G_M000_IG88
 
G_M000_IG87:                ;; offset=0x0855
       call     [System.ThrowHelper:ThrowArgumentOutOfRangeException()]
       int3     
 
G_M000_IG88:                ;; offset=0x085C
       mov      r8d, r8d
       shl      r8, 4
       add      r8, bword ptr [rdx]
       mov      bword ptr [rbp-0xD0], r8
       mov      dword ptr [rbp-0xC8], r9d
       lea      rcx, [rbp-0xD0]
       mov      rdx, gword ptr [rsi+0x18]
       mov      r15, bword ptr [rbp+0x10]
       mov      r8, gword ptr [r15+0x18]
       lea      r9, [rbp-0x50]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryInvokeNativeRange(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       test     eax, eax
       je       G_M000_IG39
       mov      rcx, gword ptr [rbp-0x50]
       mov      gword ptr [rbp-0x48], rcx
       jmp      G_M000_IG52
 
G_M000_IG89:                ;; offset=0x08A6
       mov      rcx, rdx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishInteger():System.Object:this]
       mov      r13, rax
       jmp      G_M000_IG11
 
G_M000_IG90:                ;; offset=0x08B7
       mov      rcx, rdx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishDouble():System.Object:this]
       mov      r13, rax
       jmp      G_M000_IG11
 
G_M000_IG91:                ;; offset=0x08C8
       mov      rcx, rdx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishTupleBorrow():System.Object:this]
       mov      r13, rax
       jmp      G_M000_IG11
 
G_M000_IG92:                ;; offset=0x08D9
       cmp      r14, gword ptr [r10+0x08]
       jne      G_M000_IG15
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rcx+0x08]
       mov      rdx, gword ptr [rdx+0x60]
       mov      r8d, dword ptr [rcx+0x40]
       add      r8d, 2
       cmp      r8d, dword ptr [rdx+0x08]
       jae      G_M000_IG106
       shl      r8, 5
 
G_M000_IG93:                ;; offset=0x0905
       vmovdqu  ymm0, ymmword ptr [rdx+r8+0x10]
       vmovdqu  ymmword ptr [rbp-0x70], ymm0
 
G_M000_IG94:                ;; offset=0x0911
       mov      rdx, gword ptr [rcx+0x08]
       mov      rsi, gword ptr [rdx+0x78]
       lea      rcx, [rbp-0x70]
       mov      edx, 44
       mov      r8, 0x27BCF2E58B0
       call     [Lokad.Lython.Frontend.ExecutableInstruction:ReadPrimaryOperand(int,System.String):int:this]
       mov      edx, eax
       mov      rcx, rsi
       mov      r11, 0x7FF9C8CE2470
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       mov      rdi, rax
       mov      r15, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [r15+0x18]
       mov      r12, gword ptr [rbp-0xE8]
       mov      rdx, gword ptr [r12+0x18]
       mov      rcx, gword ptr [rcx+0x98]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.ExecutionState:EnterInterpreterFrame(Lokad.Lython.LythonSourceSpan):this]
       nop      
 
G_M000_IG95:                ;; offset=0x096B
       mov      r8, gword ptr [r15+0x18]
       cmp      byte  ptr [rdi+0x31], 0
       jne      SHORT G_M000_IG97
       cmp      byte  ptr [r15+0x48], 0
       je       SHORT G_M000_IG96
       movzx    r9, byte  ptr [rdi+0x32]
       jmp      SHORT G_M000_IG98
 
G_M000_IG96:                ;; offset=0x0983
       xor      r9d, r9d
       jmp      SHORT G_M000_IG98
 
G_M000_IG97:                ;; offset=0x0988
       mov      r9d, 1
 
G_M000_IG98:                ;; offset=0x098E
       mov      rcx, r12
       mov      rdx, gword ptr [rbp-0xE0]
       call     [Lokad.Lython.Runtime.LythonRuntime:ExecuteCasedSplit(Lokad.Lython.Frontend.ExecutableCasedSplit,Lokad.Lython.Runtime.Text.PyString,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,bool):System.Object]
       mov      gword ptr [rbp-0x48], rax
       xor      ecx, ecx
       mov      qword ptr [rbp-0x40], rcx
 
G_M000_IG99:                ;; offset=0x09A8
       mov      rsi, gword ptr [r15+0x18]
       mov      rcx, gword ptr [rsi+0x98]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.ExecutionState:LeaveInterpreterFrame():this]
       add      dword ptr [r15+0x40], 2
 
G_M000_IG100:                ;; offset=0x09C0
       vmovdqu  xmm0, xmmword ptr [rbp-0x48]
       vmovdqu  xmmword ptr [rbp-0xC0], xmm0
 
G_M000_IG101:                ;; offset=0x09CD
       lea      r8, [rbp-0xC0]
       lea      rdx, [rbp-0x70]
       mov      rcx, r15
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot):this]
       mov      eax, 1
       jmp      G_M000_IG131
 
G_M000_IG102:                ;; offset=0x09EB
       mov      edx, 1
       jmp      G_M000_IG49
 
G_M000_IG103:                ;; offset=0x09F5
       mov      rcx, rdi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishInteger():System.Object:this]
       mov      r12, rax
       jmp      G_M000_IG56
 
G_M000_IG104:                ;; offset=0x0A06
       mov      rcx, rdi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishDouble():System.Object:this]
       mov      r12, rax
       jmp      G_M000_IG56
 
G_M000_IG105:                ;; offset=0x0A17
       mov      rcx, rdi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishTupleBorrow():System.Object:this]
       mov      r12, rax
       jmp      G_M000_IG56
 
G_M000_IG106:                ;; offset=0x0A28
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG107:                ;; offset=0x0A2E
       lea      rcx, bword ptr [rdi+0x20]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Object():System.Object:this]
       mov      r12, rax
       jmp      G_M000_IG83
 
G_M000_IG108:                ;; offset=0x0A40
       vmovdqu  xmm0, xmmword ptr [rbp-0x48]
       vmovdqu  xmmword ptr [rbp-0xA0], xmm0
 
G_M000_IG109:                ;; offset=0x0A4D
       cmp      dword ptr [rbx+0x18], 0
       jge      G_M000_IG120
 
G_M000_IG110:                ;; offset=0x0A57
       mov      edx, dword ptr [rbx+0x18]
       mov      esi, edx
       not      esi
       mov      edx, esi
       mov      r15, bword ptr [rbp+0x10]
       mov      edi, dword ptr [r15+0x44]
       cmp      edx, edi
       jge      SHORT G_M000_IG112
       dec      edi
       mov      rdx, gword ptr [r15+0x08]
       mov      edx, dword ptr [rdx+0xB0]
       cmp      edi, edx
       cmovg    edi, edx
       cmp      edi, esi
       jge      G_M000_IG140
 
G_M000_IG111:                ;; offset=0x0A85
       mov      dword ptr [r15+0x44], esi
 
G_M000_IG112:                ;; offset=0x0A89
       mov      rcx, gword ptr [r15+0x18]
       mov      rcx, gword ptr [rcx+0x98]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.ExecutionState:get_CanContinue():bool:this]
       test     eax, eax
       je       G_M000_IG143
       lea      rsi, bword ptr [r15+0x50]
       mov      ecx, dword ptr [rbx+0x1C]
       cmp      ecx, 53
       ja       SHORT G_M000_IG114
 
G_M000_IG113:                ;; offset=0x0AB0
       mov      rax, 0x1FFFFFFFFFE7FF
       bt       rax, rcx
       jae      G_M000_IG146
 
G_M000_IG114:                ;; offset=0x0AC4
       mov      eax, dword ptr [rbx+0x14]
 
G_M000_IG115:                ;; offset=0x0AC7
       cmp      eax, dword ptr [rsi+0x08]
       jae      G_M000_IG151
       mov      rcx, bword ptr [rsi]
       mov      eax, eax
       shl      rax, 4
       xor      edx, edx
       mov      qword ptr [rcx+rax], rdx
       mov      qword ptr [rcx+rax+0x08], rdx
       mov      ecx, dword ptr [rbx+0x1C]
       cmp      ecx, 53
       ja       SHORT G_M000_IG117
 
G_M000_IG116:                ;; offset=0x0AEC
       mov      rax, 0x1FFFFFFFFFE7FF
       bt       rax, rcx
       jae      G_M000_IG147
 
G_M000_IG117:                ;; offset=0x0B00
       mov      eax, dword ptr [rbx+0x14]
 
G_M000_IG118:                ;; offset=0x0B03
       mov      dword ptr [r15+0x44], eax
       mov      rcx, gword ptr [r15+0x08]
       mov      rcx, gword ptr [rcx+0x60]
       mov      eax, dword ptr [r15+0x40]
       inc      eax
       cmp      eax, dword ptr [rcx+0x08]
       jae      G_M000_IG151
       shl      rax, 5
       lea      rcx, bword ptr [rcx+rax+0x10]
       mov      eax, dword ptr [rcx+0x1C]
       cmp      eax, 27
       je       G_M000_IG148
       cmp      eax, 32
       jne      G_M000_IG149
       cmp      gword ptr [rbp-0xA0], 0
       je       G_M000_IG150
 
G_M000_IG119:                ;; offset=0x0B4A
       inc      dword ptr [r15+0x40]
       jmp      SHORT G_M000_IG127
 
G_M000_IG120:                ;; offset=0x0B50
       mov      ecx, dword ptr [rbx+0x1C]
       cmp      ecx, 53
       ja       SHORT G_M000_IG122
 
G_M000_IG121:                ;; offset=0x0B58
       mov      rax, 0x1FFFFFFFFFE7FF
       bt       rax, rcx
       jae      G_M000_IG139
 
G_M000_IG122:                ;; offset=0x0B6C
       mov      esi, dword ptr [rbx+0x14]
 
G_M000_IG123:                ;; offset=0x0B6F
       mov      ebx, dword ptr [rbx+0x18]
       test     ebx, ebx
       jge      SHORT G_M000_IG129
 
G_M000_IG124:                ;; offset=0x0B76
       not      ebx
 
G_M000_IG125:                ;; offset=0x0B78
       mov      rdi, gword ptr [rbp-0xA0]
       mov      r14, qword ptr [rbp-0x98]
       mov      r15, bword ptr [rbp+0x10]
       cmp      ebx, dword ptr [r15+0x44]
       jl       SHORT G_M000_IG130
 
G_M000_IG126:                ;; offset=0x0B90
       lea      rcx, bword ptr [r15+0x50]
       cmp      esi, dword ptr [rcx+0x08]
       jae      G_M000_IG151
       mov      esi, esi
       shl      rsi, 4
       add      rsi, bword ptr [rcx]
       mov      rcx, rsi
       mov      rdx, rdi
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      qword ptr [rsi+0x08], r14
       mov      dword ptr [r15+0x44], ebx
 
G_M000_IG127:                ;; offset=0x0BB9
       mov      eax, 1
 
G_M000_IG128:                ;; offset=0x0BBE
       vzeroupper 
       add      rsp, 248
       pop      rbx
       pop      rsi
       pop      rdi
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG129:                ;; offset=0x0BD5
       jmp      SHORT G_M000_IG125
 
G_M000_IG130:                ;; offset=0x0BD7
       mov      rcx, r15
       mov      edx, ebx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Trim(int):this]
       jmp      SHORT G_M000_IG126
 
G_M000_IG131:                ;; offset=0x0BE4
       vzeroupper 
       add      rsp, 248
       pop      rbx
       pop      rsi
       pop      rdi
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG132:                ;; offset=0x0BFB
       mov      rcx, rbx
       mov      rdx, 0x27BCF2E58B0
       call     [Lokad.Lython.Frontend.ExecutableInstruction:InvalidOperand(System.String):System.InvalidOperationException:this]
       mov      rcx, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG133:                ;; offset=0x0C17
       call     [System.ThrowHelper:ThrowArgumentOutOfRange_IndexMustBeLessException()]
       int3     
 
G_M000_IG134:                ;; offset=0x0C1E
       mov      rcx, rax
       mov      r11, 0x7FF9C8CE2468
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       mov      rsi, rax
       jmp      G_M000_IG03
 
G_M000_IG135:                ;; offset=0x0C36
       mov      rcx, rdx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishInteger():System.Object:this]
       mov      r14, rax
       jmp      G_M000_IG05
 
G_M000_IG136:                ;; offset=0x0C47
       mov      rcx, rdx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishDouble():System.Object:this]
       mov      r14, rax
       jmp      G_M000_IG05
 
G_M000_IG137:                ;; offset=0x0C58
       mov      rcx, rdx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishTupleBorrow():System.Object:this]
       mov      r14, rax
       jmp      G_M000_IG05
 
G_M000_IG138:                ;; offset=0x0C69
       mov      rcx, 0x7FF9C8F0A220
       call     CORINFO_HELP_NEWSFAST
       mov      rbx, rax
       mov      rcx, rbx
       mov      rdx, 0x27BCF2E6318
       call     [System.InvalidOperationException:.ctor(System.String):this]
       mov      rcx, rbx
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG139:                ;; offset=0x0C97
       mov      rcx, rbx
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      esi, eax
       jmp      G_M000_IG123
 
G_M000_IG140:                ;; offset=0x0CA7
       lea      rdx, bword ptr [r15+0x50]
       cmp      edi, dword ptr [rdx+0x08]
       jae      G_M000_IG151
       mov      rdx, bword ptr [rdx]
       mov      ecx, edi
       shl      rcx, 4
       mov      rdx, gword ptr [rdx+rcx]
       mov      rcx, 0x7FF9C9733598
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG142
       lea      rcx, bword ptr [r15+0x50]
       cmp      edi, dword ptr [rcx+0x08]
       jae      G_M000_IG151
       mov      edx, edi
       shl      rdx, 4
       add      rdx, bword ptr [rcx]
       xor      rcx, rcx
       mov      gword ptr [rdx], rcx
 
G_M000_IG141:                ;; offset=0x0CF0
       mov      qword ptr [rdx+0x08], rcx
       mov      rcx, rax
       mov      rax, qword ptr [rax]
       mov      rax, qword ptr [rax+0x40]
       call     [rax+0x20]Lokad.Lython.Runtime.ExecutableTemporaryValue:Dispose():this
 
G_M000_IG142:                ;; offset=0x0D01
       dec      edi
       cmp      edi, esi
       jge      SHORT G_M000_IG140
       jmp      G_M000_IG111
 
G_M000_IG143:                ;; offset=0x0D0C
       mov      rcx, rbx
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       mov      esi, eax
       mov      rcx, rbx
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      r8d, eax
 
G_M000_IG144:                ;; offset=0x0D23
       vmovdqu  xmm0, xmmword ptr [rbp-0xA0]
       vmovdqu  xmmword ptr [rbp-0xC0], xmm0
 
G_M000_IG145:                ;; offset=0x0D33
       mov      edx, esi
       lea      r9, [rbp-0xC0]
       mov      rcx, r15
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Put(int,int,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot):this]
       jmp      G_M000_IG127
 
G_M000_IG146:                ;; offset=0x0D4A
       mov      rcx, rbx
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       jmp      G_M000_IG115
 
G_M000_IG147:                ;; offset=0x0D58
       mov      rcx, rbx
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       jmp      G_M000_IG118
 
G_M000_IG148:                ;; offset=0x0D66
       lea      rbx, bword ptr [r15+0x50]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LocalSlot():int:this]
       cmp      eax, dword ptr [rbx+0x08]
       jae      SHORT G_M000_IG151
       mov      esi, eax
       shl      rsi, 4
       add      rsi, bword ptr [rbx]
       mov      rdx, gword ptr [rbp-0xA0]
       mov      rcx, rsi
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rcx, qword ptr [rbp-0x98]
       mov      qword ptr [rsi+0x08], rcx
       jmp      G_M000_IG119
 
G_M000_IG149:                ;; offset=0x0D9D
       mov      rcx, 0x7FF9C8F0A220
       call     CORINFO_HELP_NEWSFAST
       mov      r15, rax
       mov      rcx, r15
       mov      rdx, 0x27BCF2E8BE8
       call     [System.InvalidOperationException:.ctor(System.String):this]
       mov      rcx, r15
       call     CORINFO_HELP_THROW
       int3  