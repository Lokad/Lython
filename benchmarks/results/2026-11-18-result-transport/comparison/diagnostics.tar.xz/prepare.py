from pathlib import Path
import hashlib
import json
import os
import shutil
import subprocess

lab = Path(__file__).resolve().parent
repo = Path('D:/code/Lython')
reference = lab.parent / 'frontend-dispatch-r527'
work = repo / '.git/agent-worktrees/prepared-names-r525'

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def read_json(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))

def write_json(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n', encoding='utf-8', newline='\n')

prototype = read_json(lab / 'identity.json')
core = work / 'src/Lokad.Lython/bin/Release/net11.0/Lokad.Lython.dll'
assert sha(core) == prototype['candidateCores']['net11.0']
assert all(sha(work / name) == digest for name, digest in prototype['changedFiles'].items())
assert subprocess.check_output(['git', 'diff', 'HEAD', '--binary'], cwd=work) == (lab / 'change.patch').read_bytes()
previous = read_json(reference / 'frozen/identity.json')
original = previous['imageFiles']['candidate']
assert len(original) == 32 and original['Lokad.Lython.dll'] == prototype['referenceCore']
images = {}
for role in ('reference', 'candidate'):
    folder = lab / 'frozen' / role
    folder.mkdir(parents=True, exist_ok=False)
    for name, digest in original.items():
        source = reference / 'frozen/candidate' / name
        assert sha(source) == digest, name
        shutil.copyfile(core if role == 'candidate' and name == core.name else source, folder / name)
    images[role] = {name: sha(folder / name) for name in original}
    for tool in (reference / 'frozen/candidate').glob('ValidatedAllocation.*'):
        shutil.copyfile(tool, folder / tool.name)
assert images['reference'] == original
assert images['candidate'] == original | {core.name: prototype['candidateCores']['net11.0']}

catalog = read_json(reference / 'combined-catalog.json')
case_ids = {'scripts.text-normalization.helper-list', 'scripts.numeric-squared-error.floating.large', 'calls.positional.large'}
catalog['cases'] = [case for case in catalog['cases'] if case['id'] in case_ids]
assert {case['id'] for case in catalog['cases']} == case_ids
write_json(lab / 'representative.json', catalog)
old_catalog = reference / 'catalog.json'
dotnet = Path('C:/Users/JoannesVermorel/.dotnet11/dotnet.exe')
env = os.environ.copy()
env.update(DOTNET_ROOT=str(dotnet.parent), DOTNET_ROOT_X64=str(dotnet.parent))
env['PATH'] = str(dotnet.parent) + os.pathsep + env['PATH']

def run(label, *args):
    with (lab / (label + '.log')).open('w', encoding='utf-8') as log:
        subprocess.run([str(dotnet), *map(str, args)], cwd=repo, env=env, stdout=log, stderr=subprocess.STDOUT, timeout=120, check=True)
    print(label, 'passed', flush=True)

for role, hashes in images.items():
    folder = lab / 'frozen' / role
    for label, path in [('goldens', old_catalog), ('measurement', lab / 'representative.json')]:
        run(role + '-' + label, folder / 'Lokad.Lython.Benchmarks.dll', '--compare', 'verify', '--catalog', path,
            '--dotnet', dotnet, '--python', 'C:/Python313/python.exe', '--python-worker', repo / 'benchmarks/cpython-worker.py',
            '--out', lab / (role + '-' + label + '.json'))
    run(role + '-allocation', folder / 'ValidatedAllocation.dll', folder, old_catalog, lab / (role + '-allocation.json'))
    assert all(sha(folder / name) == digest for name, digest in hashes.items())
write_json(lab / 'frozen-identity.json', dict(
    sourceRevision='Fully qualified 925397f65 / 2c6b304b and private result transport 76555c49',
    purpose='Compare helper text compile, warm and fresh results, floating report warm execution and positional call control.',
    imageFiles=images, catalogSHA256=sha(lab / 'representative.json'),
    coreSHA256={name: images[role][core.name] for role in images for name in (role, role + '-control')},
    normalAdapterPin='0.4.0', publicationHeld=True))
