from pathlib import Path
import gzip
import hashlib
import json
import subprocess

lab = Path(__file__).resolve().parent
repo = Path('D:/code/Lython')
protected = ('2ede09fc', 'a71', 'c036', '84', 'a503', '2c6b304b')
ssh = ['C:/Windows/System32/OpenSSH/ssh.exe', '-i', str(Path.home() / '.ssh/id_lython-bench.pem'),
       '-o', 'BatchMode=yes', '-o', 'ConnectTimeout=15', 'lokad@20.166.121.73']

def remote(script):
    return subprocess.run(ssh + ['python3 -'], input=script, text=True, encoding='utf-8',
                          capture_output=True, timeout=60, check=True).stdout

if __name__ == '__main__':
    raw = remote('''from pathlib import Path
import fcntl, hashlib, json, os, shutil, stat
root = Path('/home/lokad/lython-bench-checks').resolve()
groups = {}
with (root / 'comparison-vm.lock').open('a') as lease:
    fcntl.flock(lease, fcntl.LOCK_EX | fcntl.LOCK_NB)
    prefixes = ('native-consumers-b852', 'bulk-replacement-b858',
                'discarded-results-refined-b945', 'discarded-results-b944',
                'call-frame-cost-b855', 'iteration-cost-b851')
    for path in root.glob('*/*/Lokad.Lython.dll'):
        if True:
            info = path.lstat()
            if path.resolve() != path or not stat.S_ISREG(info.st_mode) or info.st_uid != os.getuid():
                continue
            key = (info.st_dev, info.st_ino)
            if key not in groups:
                groups[key] = dict(paths=[], bytes=info.st_size, links=info.st_nlink)
            groups[key]['paths'].append(str(path.relative_to(root)))
    eligible = []
    for group in groups.values():
        if any(name.startswith(prefixes) for name in group['paths']) and len(group['paths']) == group['links']:
            path = root / group['paths'][0]
            eligible.append(group | dict(sha256=hashlib.sha256(path.read_bytes()).hexdigest()))
    print(json.dumps(dict(freeBytes=shutil.disk_usage(root).free, groups=eligible)))
''')
    state = json.loads(raw)
    available = {group['sha256']: group for group in state['groups'] if len(group['paths']) == group['links']}
    choices = []
    for path in sorted((repo / 'benchmarks/results').rglob('*core*.dll.gz'), reverse=True):
        blob = path.read_bytes()
        data = gzip.decompress(blob)
        digest = hashlib.sha256(data).hexdigest()
        if digest.startswith(protected) or digest not in available:
            continue
        name = path.relative_to(repo).as_posix()
        assert blob == subprocess.check_output(['git', 'show', 'HEAD:' + name], cwd=repo)
        item = available.pop(digest)
        choices.append(item | dict(kind='archived historical image replica', canonical=name,
                                   canonicalSHA256=hashlib.sha256(blob).hexdigest(),
                                   member='gzip-payload', committedBlobVerified=True))
        if len(choices) == 2:
            break
    (lab / 'space.json').write_text(json.dumps(dict(freeBytes=state['freeBytes'], choices=choices), indent=2) + '\n', encoding='utf-8')
    print('Free bytes:', state['freeBytes'], 'Eligible groups:', [(v['sha256'][:12], v['bytes'], v['links'], v['canonical']) for v in choices])
