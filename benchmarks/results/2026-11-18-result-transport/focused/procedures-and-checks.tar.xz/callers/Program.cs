using Microsoft.CodeAnalysis.CSharp;
using Microsoft.CodeAnalysis.CSharp.Syntax;
using System.Text.Json;

var work = args[0];
var rows = new List<object>();
var suspicious = new List<string>();
foreach (var path in Directory.EnumerateFiles(Path.Combine(work, "src/Lokad.Lython/Runtime"), "*.cs"))
{
    var root = CSharpSyntaxTree.ParseText(File.ReadAllText(path)).GetRoot();
    foreach (var call in root.DescendantNodes().OfType<InvocationExpressionSyntax>())
    {
        var name = call.Expression switch { IdentifierNameSyntax i => i.Identifier.ValueText,
            MemberAccessExpressionSyntax m => m.Name.Identifier.ValueText, _ => "" };
        if (name != "PublishInstructionResult" && name != "CompleteResultConsumer" &&
            !(path.EndsWith("LythonRuntime.Executable.NativePrefix.cs") && name is "Publish" or "Put")) continue;
        var expression = call.ArgumentList.Arguments.Last().Expression;
        var at = Path.GetRelativePath(work, path).Replace('\\', '/') + ":" + (call.GetLocation().GetLineSpan().StartLinePosition.Line + 1);
        var refLocal = expression is IdentifierNameSyntax identifier &&
            call.Ancestors().OfType<MethodDeclarationSyntax>().FirstOrDefault() is { } method &&
            method.DescendantNodes().OfType<VariableDeclarationSyntax>().Any(v => v.Type is RefTypeSyntax &&
                v.Variables.Any(x => x.Identifier.ValueText == identifier.Identifier.ValueText));
        if (expression is ElementAccessExpressionSyntax || refLocal) suspicious.Add(at + " " + expression);
        rows.Add(new { location = at, name, expression = expression.ToString(), kind = expression.Kind().ToString(), refLocal });
    }
}
var result = new { purpose = "One-off caller-shape audit. Element/ref-local aliases require review; other expressions still require ownership reasoning and behavioral checks. Not a semantic proof or permanent architecture test.", calls = rows.Count, directBackingOrRefLocalArguments = suspicious, rows };
Console.WriteLine(JsonSerializer.Serialize(result, new JsonSerializerOptions { WriteIndented = true }));
return suspicious.Count == 0 ? 0 : 1;
