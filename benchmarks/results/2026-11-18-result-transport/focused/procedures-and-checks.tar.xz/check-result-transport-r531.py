from pathlib import Path
import json,os,subprocess
notes=Path(__file__).parent;r=notes/'result-transport-r531';r.mkdir(exist_ok=True)
work=Path('D:/code/Lython/.git/agent-worktrees/prepared-names-r525')
d=Path('C:/Users/JoannesVermorel/.dotnet11/dotnet.exe');env=os.environ.copy();env.update(DOTNET_ROOT=str(d.parent),DOTNET_ROOT_X64=str(d.parent));env['PATH']=str(d.parent)+os.pathsep+env['PATH']
assert subprocess.check_output(['git','status','--porcelain'],cwd=work,text=True).count('\n')==2
cmd=[str(d),'build','Lokad.Lython.slnx','-c','Release','--no-incremental','--nologo']
with(r/'build.log').open('w',encoding='utf-8')as log:p=subprocess.run(cmd,cwd=work,env=env,stdout=log,stderr=subprocess.STDOUT)
assert p.returncode==0,(r/'build.log').read_text(encoding='utf-8')[-8000:]
print('Settled nonincremental Release build passed; focused regressions start.',flush=True)
filters={
 'internal':['ExecutableValueTransfer','ExecutableOperandStackBoundary','ExecutableCallTransfer','ExecutableFunctionInvocationBoundary','ExecutableIteratorCleanup','ExecutableAsyncIteratorCleanup','ExecutableFrameStorage','DirectOperandOwnership','NativeTupleReturn','NativeScalarDispatchBoundary','NativeUnaryReentry','NativeTextConstructionRollback','NativeFunctionRefund','NativeClosureSequence','ComposedNativeCall'],
 'public':['HelperLocalLifetime','ClosedBuiltinResult','FloatArithmeticPipeline','NativeGeneratorSum','NativeReceiverPipeline','BufferedGeneratorContinuation','GlobalBindingPipeline','ContainerDisplayPipeline','GovernedMemoryContract','MemoryDenialAttribution','BulkGeneratorConsumption','LocalOperand']}
rows=[]
for tfm in ['net11.0','net10.0']:
 for kind,parts in filters.items():
  project='Lokad.Lython.Tests'if kind=='internal'else'Lokad.Lython.PublicApi.Tests'
  cmd=[str(d),'test',f'tests/{project}/{project}.csproj','-c','Release','-f',tfm,'--no-build','--filter','('+'|'.join('FullyQualifiedName~'+n for n in parts)+')&Category!=Stress']
  path=r/(kind+'-'+tfm+'.log')
  with path.open('w',encoding='utf-8')as log:p=subprocess.run(cmd,cwd=work,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=180)
  rows.append(dict(kind=kind,framework=tfm,command=cmd,exitCode=p.returncode));(r/'checks.json').write_text(json.dumps(rows,indent=2)+'\n',encoding='utf-8')
  output=path.read_text(encoding='utf-8');assert p.returncode==0,output
  print(kind,tfm,output.splitlines()[-1],flush=True)
