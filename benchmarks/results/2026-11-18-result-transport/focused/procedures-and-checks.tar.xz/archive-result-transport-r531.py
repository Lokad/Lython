from pathlib import Path
import gzip,hashlib,json,os,shutil,subprocess,tarfile
notes=Path(__file__).parent;r=notes/'result-transport-r531';repo=Path('D:/code/Lython');work=repo/'.git/agent-worktrees/prepared-names-r525'
d=Path('C:/Users/JoannesVermorel/.dotnet11/dotnet.exe');env=os.environ.copy();env.update(DOTNET_ROOT=str(d.parent),DOTNET_ROOT_X64=str(d.parent));env['PATH']=str(d.parent)+os.pathsep+env['PATH']
with(r/'caller-audit.json').open('w',encoding='utf-8')as log:p=subprocess.run([str(d),str(r/'callers/bin/Release/net11.0/callers.dll'),str(work)],env=env,stdout=log,stderr=subprocess.PIPE)
assert p.returncode==0,p.stderr.decode('utf-8')
audit=json.loads((r/'caller-audit.json').read_text(encoding='utf-8'));print('Caller-shape audit',audit['calls'],'sites,',len(audit['directBackingOrRefLocalArguments']),'direct backing/ref local arguments. Manual ownership/behavioral reasoning still required.')
checks=json.loads((r/'checks.json').read_text(encoding='utf-8'));assert len(checks)==4 and all(x['exitCode']==0 for x in checks)
changed=subprocess.check_output(['git','diff','HEAD','--name-only'],cwd=work,text=True).splitlines();assert len(changed)==2 and all(n.startswith('src/Lokad.Lython/')for n in changed)
patch=subprocess.check_output(['git','diff','HEAD','--binary'],cwd=work);(r/'change.patch').write_bytes(patch)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
identity=dict(status='Isolated active prototype, not promoted or full-platform qualified; no performance claim.',baseRevision=subprocess.check_output(['git','rev-parse','HEAD'],cwd=work,text=True).strip(),referenceCore='2c6b304be4c81e2c70d4b0e0e89b71fb26e33521a561405255b939c2716d8226',changedFiles={n:sha(work/n)for n in changed},candidateCores={tfm:sha(work/f'src/Lokad.Lython/bin/Release/{tfm}/Lokad.Lython.dll')for tfm in ['net11.0','net10.0']},sdk=json.loads((work/'global.json').read_text(encoding='utf-8')),checks='151internal/84public per actual11/10 after settled nonincremental Release solution build, zero warnings/errors.',limits='Caller shape audit is not proof. Frozen complete images/goldens/allocation and source-pair CPU/assembly still pending. Borrow stable local results only; snapshots at storage/retirement/reentry/suspension boundaries remain.',normalAdapterPin='0.4.0',publicationHeld=True)
(r/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8')
with tarfile.open(r/'candidate-sources.tar.xz','w:xz')as a:
 for n in changed:a.add(work/n,arcname=n)
out=repo/'benchmarks/results/2026-11-18-result-transport/focused';out.mkdir(parents=True,exist_ok=True);assert not(out/'identity.json').exists()
for n in ['identity.json','checks.json','caller-audit.json','candidate-sources.tar.xz','change.patch']:shutil.copyfile(r/n,out/n)
with tarfile.open(out/'procedures-and-checks.tar.xz','w:xz')as a:
 for n in ['build.log','internal-net11.0.log','public-net11.0.log','internal-net10.0.log','public-net10.0.log','callers/Program.cs','callers/callers.csproj']:a.add(r/n,arcname=n)
 for n in ['check-result-transport-r531.py','archive-result-transport-r531.py']:a.add(notes/n,arcname=n)
print(json.dumps(identity,indent=2))
