from pathlib import Path
from hashlib import sha256
import json
import os
import shutil
import subprocess

lab=Path(__file__).resolve().parent
run=lab/'local'
sdk=Path.home()/'.dotnet11'
dotnet=sdk/'dotnet.exe'
env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk))
subprocess.run([dotnet,'build',lab/'probe/PendingZip.csproj','-c','Release','--nologo'],env=env,check=True)
output=lab/'probe/bin/Release/net11.0'
identity=json.loads((run/'identity.json').read_text(encoding='utf-8'))
results={}
for role in ('reference','candidate'):
    core='Lokad.Lython.dll'
    shutil.copyfile(run/role/core,output/core)
    assert sha256((output/core).read_bytes()).hexdigest()==identity['imageFiles'][role][core]
    result=subprocess.check_output([dotnet,output/'Lokad.Lython.WhiteBox.Tests.dll'],env=env,timeout=20)
    results[role]=json.loads(result)
    assert not results[role]['baseline']
    assert results[role]['rows']==20_000
    print(role, results[role], flush=True)
(run/'pending-allocation.json').write_text(json.dumps(results,indent=2)+'\n',encoding='utf-8',newline='\n')
