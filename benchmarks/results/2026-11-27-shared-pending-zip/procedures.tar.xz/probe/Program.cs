using System.Text.Json;
using Lokad.Lython;
using Lokad.Lython.Runtime;

const int batches = 3;
const int rows = 20_000;
var budget = new LythonMemoryBudget(1_048_576);
var span = new LythonSourceSpan(0, 0, 0, 0);
var fixedUnpack = new long[batches];
var inlineOperands = new long[batches];
using (var owner = budget.CreateScope())
{
    var context = new LythonRuntime.ExecutionContext(new NoIoHost(), new() { MemoryBudget = owner });
    var left = new PyList(0, context.MemoryGovernor, span);
    var right = new PyList(0, context.MemoryGovernor, span);
    var delayed = new GatedSource();
    var zip = new PyZipIterator([new ReadySource(left), delayed], false, span, context);
    var slots = new LythonRuntime.ExecutableSlot[2];
    var operands = new LythonRuntime.IterationOperands();

    void AdvanceUnpack()
    {
        var gate = delayed.Begin();
        var pull = zip.UnpackNextAsync(slots);
        if (pull.IsCompleted || !ReferenceEquals(slots[1].Reference, left))
            throw new InvalidOperationException("Fixed unpack must suspend with the first source staged.");
        gate.SetResult(PyIterationResult.Yield(right));
        if (!pull.IsCompletedSuccessfully || pull.Result != 2 || !ReferenceEquals(slots[0].Reference, right))
            throw new InvalidOperationException("Fixed unpack must complete with the original row in reverse order.");
        Array.Clear(slots);
    }

    void AdvanceInline()
    {
        var gate = delayed.Begin();
        if (zip.TryPullOperands(ref operands, true, out _, out var pull)
            || pull.IsCompleted || !ReferenceEquals(operands[0].Reference, left))
            throw new InvalidOperationException("Inline pull must suspend with the first source staged.");
        gate.SetResult(PyIterationResult.Yield(right));
        if (!pull.IsCompletedSuccessfully)
            throw new InvalidOperationException("Inline pull should resume on the measurement thread.");
        var (hasRow, result) = pull.Result;
        if (!hasRow || !ReferenceEquals(result[0].Reference, left) || !ReferenceEquals(result[1].Reference, right))
            throw new InvalidOperationException("Inline pull must complete with the original row in source order.");
        operands = default;
    }

    for (var i = 0; i < 6000; i++)
    {
        AdvanceUnpack();
        AdvanceInline();
    }

    var live = budget.ReservedBytes;
    for (var batch = 0; batch < batches; batch++)
    {
        var before = GC.GetAllocatedBytesForCurrentThread();
        for (var i = 0; i < rows; i++) AdvanceUnpack();
        fixedUnpack[batch] = GC.GetAllocatedBytesForCurrentThread() - before;
        before = GC.GetAllocatedBytesForCurrentThread();
        for (var i = 0; i < rows; i++) AdvanceInline();
        inlineOperands[batch] = GC.GetAllocatedBytesForCurrentThread() - before;
    }
    if (budget.ReservedBytes != live) throw new InvalidOperationException("Row pulls changed live admission.");
}
if (budget.ReservedBytes != 0) throw new InvalidOperationException("Scope cleanup did not return the allowance.");
Console.WriteLine(JsonSerializer.Serialize(new { rows, fixedUnpack, inlineOperands, baseline = budget.ReservedBytes }));

sealed class ReadySource(object value) : IPyIteratorValue
{
    public PyIterationResult TryMoveNext() => PyIterationResult.Yield(value);
    public IEnumerable<object> Iterate() => throw new NotSupportedException();
}

sealed class GatedSource : IPyAsyncIteratorValue
{
    private TaskCompletionSource<PyIterationResult>? _gate;
    public TaskCompletionSource<PyIterationResult> Begin() => _gate = new();
    public ValueTask<PyIterationResult> TryMoveNextAsync() => new(_gate!.Task);
    public PyIterationResult TryMoveNext() => throw new NotSupportedException();
    public IEnumerable<object> Iterate() => throw new NotSupportedException();
}

sealed class NoIoHost : ILythonHost
{
    public string Cwd => "/";
    public DateTimeOffset LocalNow => UnixEpoch;
    public DateTimeOffset UtcNow => UnixEpoch;
    private static DateTimeOffset UnixEpoch => DateTimeOffset.UnixEpoch;
    public ValueTask<bool> ExistsAsync(LythonPathRequest path, CancellationToken token) => throw new NotSupportedException();
    public ValueTask<IReadOnlyList<string>> ListDirAsync(LythonPathRequest path, CancellationToken token) => throw new NotSupportedException();
    public ValueTask MkDirAsync(LythonPathRequest path, CancellationToken token) => throw new NotSupportedException();
    public ValueTask RemoveAsync(LythonPathRequest path, CancellationToken token) => throw new NotSupportedException();
    public ValueTask CopyAsync(LythonPathRequest source, LythonPathRequest destination, CancellationToken token) => throw new NotSupportedException();
    public ValueTask MoveAsync(LythonPathRequest source, LythonPathRequest destination, CancellationToken token) => throw new NotSupportedException();
    public ValueTask<LythonPathStat> StatAsync(LythonPathRequest path, CancellationToken token) => throw new NotSupportedException();
}
