from pathlib import Path
import gzip
import hashlib
import json
import subprocess

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
prior = lab.with_name('early-cased-split-20261123')


def adapt(name, substitutions):
    source = (prior / name).read_text(encoding='utf-8')
    for old, new in substitutions:
        assert source.count(old) == 1, (name, old)
        source = source.replace(old, new)
    compile(source, str(lab / name), 'exec')
    (lab / name).write_text(source, encoding='utf-8', newline='\n')


adapt('prepare.py', (
    ("assert not git('diff','--name-only',reference,'HEAD','--','src','tests')",
     "assert set(git('diff','--name-only',reference,'HEAD','--','src','tests').splitlines()) == {\n"
     "    'src/Lokad.Lython/Runtime/LythonRuntime.RegexMatcher.cs', 'src/Lokad.Lython/Runtime/PyTuple.cs'}"),
    ('B1537 start a prepared cased split at member lookup',
     'B1538 isolate the prepared split instruction from ordinary member dispatch'),
))
adapt('prepare-jobs.py', ())
adapt('stage.py', (
    ('early-cased-split-b1537-20261123', 'marked-cased-split-b1538-20261123'),
    ('lython-b1537-fixtures', 'lython-b1538-fixtures'),
    ('< 235,', '< 315,'),
    ('tail=tail.replace("targetBatchSeconds=.65","targetBatchSeconds=.40").replace("counts[i]*.65", "counts[i]*.40")',
     '''tail=tail.replace("targetBatchSeconds=.65","targetBatchSeconds=.50").replace("counts[i]*.65", "counts[i]*.50")
assert tail.count("warmupSeconds=8")==1
tail=tail.replace("warmupSeconds=8","warmupSeconds=12").replace("accumulate 8 seconds","accumulate 12 seconds")'''),
))
adapt('quiet.py', (
    ('lython-b1537-early-cased-split-20261123', 'lython-b1538-marked-cased-split-20261123'),
    ('.+b1537-', '.+b1538-'),
    ('lython-b1537-stage-', 'lython-b1538-stage-'),
    ('Four bounded lanes write under 1 MiB of receipts. A 15 MiB',
     'Four bounded lanes write under 1 MiB of receipts. A 14 MiB'),
    ('15 * 1024 * 1024', '14 * 1024 * 1024'),
    ('RuntimeMaxSec=270', 'RuntimeMaxSec=345'),
    ('seconds=196', 'seconds=270'),
))
adapt('summarize.py', ())
adapt('jit-check.py', (
    ('*TryLoadDirectCallReceiver* *TryExecuteNativeCall*', '*TryLoadDirectCallReceiver* *TryExecuteCasedSplitMember* *TryExecuteNativeCall*'),
))

archive = 'benchmarks/results/2026-11-23-early-cased-split/'


def read_archive(name):
    return subprocess.check_output(['git', 'show', 'origin/master:' + archive + name], cwd=repo)


def sha(data):
    return hashlib.sha256(data).hexdigest()


receipt = json.loads(read_archive('terminal-status.json'))['receipt']
assert receipt['complete'] and receipt['archivedAndVerifiedUnderLease']
assert sha(read_archive('observations.tar.xz')) == receipt['archiveSHA256']
filename = 'candidate-core.dll.gz'
core = gzip.decompress(read_archive(filename))
assert sha(core) == json.loads(read_archive('identity.json'))['imageFiles']['candidate']['Lokad.Lython.dll']
replica = dict(path='early-cased-split-b1537-20261123/candidate/Lokad.Lython.dll', sha256=sha(core),
               observationSHA256=receipt['archiveSHA256'], trackedArchive=archive + filename)
(lab / 'verified-replicas.json').write_text(json.dumps([replica], indent=2) + '\n', encoding='utf-8', newline='\n')
