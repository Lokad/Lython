from pathlib import Path
import gzip
import hashlib
import json
import shutil
import subprocess
import tarfile

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
comparison = lab / 'comparison'
quiet = comparison / 'quiet'
dest = repo / 'benchmarks/results/2026-11-23-marked-cased-split'


def read(path):
    return json.loads(path.read_text(encoding='utf-8'))


def sha(data):
    return hashlib.sha256(data).hexdigest()


identity = read(comparison / 'identity.json')
status = read(quiet / 'terminal-status.json')
receipt = status['receipt']
assert status['exitCode'] == '0' and not status['live'] and not status['fixtures']
assert all(receipt[name] for name in ('complete', 'quietBeforeAndAfter', 'allWorkersJoined',
                                      'guestFixturesRemoved', 'archivedAndVerifiedUnderLease'))
assert sha((quiet / 'observations.tar.xz').read_bytes()) == receipt['archiveSHA256']
assert read(quiet / 'summary.json')['timedBatches'] == 112
assert all(row['peakAdmission'][0] == row['peakAdmission'][1] for row in read(lab / 'allocation-summary-six.json'))
assert all(sha((lab / role / name).read_bytes()) == h for role, files in identity['imageFiles'].items() for name, h in files.items())
patch = subprocess.check_output(['git', 'diff', '--binary', identity['sourceRevision'], identity['candidate'], '--', 'src', 'tests'], cwd=repo)
(lab / 'comparison.patch').write_bytes(patch)
identity['comparisonPatchSHA256'] = sha(patch)
identity['verifiedDuplicateRetired'] = json.loads((quiet / 'launch.log').read_text(encoding='utf-8'))['verifiedDuplicateRetired']
dest.mkdir(exist_ok=True)
assert all(path.name == 'README.md' for path in dest.iterdir())
(dest / 'candidate-core.dll.gz').write_bytes(gzip.compress((lab / 'candidate/Lokad.Lython.dll').read_bytes(), mtime=0))
(dest / 'identity.json').write_text(json.dumps(identity, indent=2) + '\n', encoding='utf-8', newline='\n')
shutil.copyfile(lab / 'allocation-summary-six.json', dest / 'allocation-summary.json')
shutil.copyfile(lab / 'jit-summary.json', dest / 'jit-summary.json')
for name in ('observations.tar.xz', 'summary.json', 'terminal-status.json'):
    shutil.copyfile(quiet / name, dest / name)
with tarfile.open(dest / 'procedures.tar.xz', 'w:xz') as bundle:
    for name in ('archive.py', 'configure.py', 'prepare.py', 'prepare-jobs.py', 'stage.py', 'quiet.py', 'summarize.py',
                 'allocations.py', 'comparison.patch', 'reference-tape.json', 'candidate-tape.json', 'jit-check.py',
                 'reference-jit.asm', 'candidate-jit.asm', 'windows-public.log', 'windows-white.log', 'windows-build.log',
                 'initial-build.log', 'initial-staging.txt', 'verified-replicas.json', 'ubuntu.log', 'ubuntu-focused.sh',
                 'reference-allocation-six.json', 'candidate-allocation-six.json', 'comparison/reference-verify.json',
                 'comparison/candidate-verify.json', 'comparison/quiet/launch.log'):
        bundle.add(lab / name, arcname=name)
print(dest)
