; Assembly listing for method Lokad.Lython.LythonCompiledScript:RunCore(Lokad.Lython.ILythonHost,Lokad.Lython.LythonRunOptions):Lokad.Lython.LythonExecutionResult:this (FullOpts)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; FullOpts code
; optimized code
; rbp based frame
; fully interruptible
; No PGO data
; 0 inlinees with PGO data; 7 single block inlinees; 0 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       push     r15
       push     r14
       push     rdi
       push     rsi
       push     rbx
       sub      rsp, 72
       lea      rbp, [rsp+0x70]
       mov      rsi, rcx
       mov      rdi, rdx
       mov      rbx, r8
 
G_M000_IG02:                ;; offset=0x001A
       mov      r14, gword ptr [rsi+0x08]
       test     r14, r14
       je       G_M000_IG13
       test     rbx, rbx
       jne      SHORT G_M000_IG04
 
G_M000_IG03:                ;; offset=0x002C
       mov      rcx, 0x7FF9B50603F8
       call     CORINFO_HELP_NEWSFAST
       mov      rbx, rax
 
G_M000_IG04:                ;; offset=0x003E
       mov      r15, gword ptr [rbx+0x38]
       test     r15, r15
       jne      SHORT G_M000_IG06
 
G_M000_IG05:                ;; offset=0x0047
       mov      r15, gword ptr [rsi+0x20]
       test     r15, r15
       jne      SHORT G_M000_IG06
       mov      rcx, 0x7FF9B5054C10
       call     CORINFO_HELP_NEWSFAST
       mov      r15, rax
       mov      byte  ptr [rbp-0x38], 0
       xor      edx, edx
       mov      qword ptr [rbp-0x30], rdx
       lea      rdx, [rbp-0x38]
       mov      rcx, r15
       call     [Lokad.Lython.LythonMemoryBudget:.ctor(System.Nullable`1[long]):this]
 
G_M000_IG06:                ;; offset=0x0079
       mov      rcx, r15
       mov      r11, 0x7FF9B4B62B38
       call     [r11]Lokad.Lython.ILythonMemoryBudget:CreateScope():Lokad.Lython.ILythonMemoryScope:this
       mov      gword ptr [rbp-0x40], rax
 
G_M000_IG07:                ;; offset=0x008D
       mov      rcx, gword ptr [rbx+0x40]
       test     rcx, rcx
       cmove    rcx, r15
       mov      r11, 0x7FF9B4B62B40
       call     [r11]Lokad.Lython.ILythonMemoryBudget:CreateScope():Lokad.Lython.ILythonMemoryScope:this
       mov      r9, rax
       mov      gword ptr [rbp-0x48], r9
 
G_M000_IG08:                ;; offset=0x00AC
       mov      rdx, gword ptr [rbx+0x60]
       mov      rcx, rbx
       mov      r8, gword ptr [rbp-0x40]
       call     [Lokad.Lython.LythonRunOptions:Copy(System.Threading.CancellationToken,Lokad.Lython.ILythonMemoryBudget,Lokad.Lython.ILythonMemoryBudget):Lokad.Lython.LythonRunOptions:this]
       mov      r8, rax
       mov      rdx, rdi
       mov      rcx, gword ptr [r14+0x10]
       call     [r14+0x18]System.Func`3[System.__Canon,System.__Canon,System.__Canon]:Invoke(System.__Canon,System.__Canon):System.__Canon:this
       mov      rbx, rax
       lea      rcx, bword ptr [rbx+0x28]
       mov      rdx, gword ptr [rbp-0x48]
       call     CORINFO_HELP_ASSIGN_REF
       nop      
 
G_M000_IG09:                ;; offset=0x00DC
       cmp      gword ptr [rbp-0x40], 0
       je       SHORT G_M000_IG11
 
G_M000_IG10:                ;; offset=0x00E3
       mov      rcx, gword ptr [rbp-0x40]
       mov      r11, 0x7FF9B4B62B50
       call     [r11]System.IDisposable:Dispose():this
 
G_M000_IG11:                ;; offset=0x00F4
       mov      rax, rbx
 
G_M000_IG12:                ;; offset=0x00F7
       add      rsp, 72
       pop      rbx
       pop      rsi
       pop      rdi
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG13:                ;; offset=0x0104
       mov      rcx, 0x7FF9B5012C60
       call     CORINFO_HELP_NEWSFAST
       mov      rbx, rax
       mov      rcx, rbx
       mov      rdx, 0x19F4A079F68
       call     [System.ObjectDisposedException:.ctor(System.String):this]
       mov      rcx, rbx
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG14:                ;; offset=0x0132
       sub      rsp, 40
 
G_M000_IG15:                ;; offset=0x0136
       mov      rcx, gword ptr [rbp-0x48]
       mov      r11, 0x7FF9B4B62B48
       call     [r11]System.IDisposable:Dispose():this
       call     CORINFO_HELP_RETHROW
       int3     
 
G_M000_IG16:                ;; offset=0x014D
       sub      rsp, 40
 
G_M000_IG17:                ;; offset=0x0151
       cmp      gword ptr [rbp-0x40], 0
       je       SHORT G_M000_IG18
       mov      rcx, gword ptr [rbp-0x40]
       mov      r11, 0x7FF9B4B62B50
       call     [r11]System.IDisposable:Dispose():this
 
G_M000_IG18:                ;; offset=0x0169
       nop      
 
G_M000_IG19:                ;; offset=0x016A
       add      rsp, 40
       ret      
 
; Total bytes of code 367

; Assembly listing for method Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteInstructionPrefix(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,bool,byref,byref,byref,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):int (FullOpts)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; FullOpts code
; optimized code
; rbp based frame
; fully interruptible
; No PGO data
; 28 inlinees with PGO data; 305 single block inlinees; 76 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       push     r15
       push     r14
       push     r13
       push     r12
       push     rdi
       push     rsi
       push     rbx
       sub      rsp, 984
       lea      rbp, [rsp+0x410]
       vxorps   xmm4, xmm4, xmm4
       vmovdqa  xmmword ptr [rbp-0x330], xmm4
       vmovdqa  xmmword ptr [rbp-0x320], xmm4
       mov      rax, -720
 
G_M000_IG380:                ;; offset=0x0039
       vmovdqa  xmmword ptr [rbp+rax-0x40], xmm4
       vmovdqa  xmmword ptr [rbp+rax-0x30], xmm4
       vmovdqa  xmmword ptr [rbp+rax-0x20], xmm4
       add      rax, 48
       jne      SHORT G_M000_IG380
       mov      bword ptr [rbp+0x10], rcx
       mov      gword ptr [rbp+0x18], rdx
       mov      gword ptr [rbp+0x20], r8
       mov      dword ptr [rbp+0x28], r9d
       mov      rbx, r8
       mov      rsi, bword ptr [rbp+0x30]
       mov      r8, bword ptr [rbp+0x38]
       mov      rax, bword ptr [rbp+0x40]
       mov      r10, bword ptr [rbp+0x48]
 
G_M000_IG02:                ;; offset=0x0074
       mov      r9, bword ptr [r10]
       mov      bword ptr [rbp-0x390], r9
       mov      r10d, dword ptr [r10+0x08]
       mov      dword ptr [rbp-0x2E0], r10d
       xor      r9d, r9d
       mov      qword ptr [rsi], r9
       mov      qword ptr [rsi+0x08], r9
 
G_M000_IG03:                ;; offset=0x0093
       mov      gword ptr [r8], r9
 
G_M000_IG04:                ;; offset=0x0096
       mov      qword ptr [rax], r9
       mov      qword ptr [rax+0x08], r9
       mov      qword ptr [rax+0x10], r9
       mov      r9, gword ptr [rcx]
       mov      r9, gword ptr [r9+0x98]
       mov      gword ptr [rbp-0x338], r9
       mov      edi, dword ptr [r9+0x08]
       cmp      dword ptr [rcx+0x10], edi
       jge      G_M000_IG361
 
G_M000_IG05:                ;; offset=0x00BF
       mov      rdx, gword ptr [rbp+0x18]
       xor      r11d, r11d
       mov      dword ptr [rbp-0x3C], r11d
       mov      r11d, dword ptr [rcx+0x10]
       cmp      r11d, edi
       jae      G_M000_IG369
       shl      r11, 5
       lea      r11, bword ptr [r9+r11+0x10]
       mov      bword ptr [rbp-0x340], r11
       mov      r14, gword ptr [rdx+0xA0]
       mov      r11, bword ptr [rbp-0x340]
       mov      r15, gword ptr [r11]
       cmp      byte  ptr [r14], r14b
       mov      rcx, r14
       call     [Lokad.Lython.Runtime.ExecutionState:get_CanContinue():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG07
 
G_M000_IG06:                ;; offset=0x0108
       mov      rcx, r14
       mov      rdx, r15
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
       nop      
 
G_M000_IG07:                ;; offset=0x0115
       mov      rdx, bword ptr [rbp-0x340]
       mov      r14d, dword ptr [rdx+0x1C]
       cmp      r14d, 75
       ja       G_M000_IG290
 
G_M000_IG08:                ;; offset=0x012A
       mov      edx, r14d
       lea      rcx, [reloc @RWD00]
       mov      ecx, dword ptr [rcx+4*rdx]
       lea      rax, G_M000_IG02
       add      rcx, rax
       jmp      rcx
 
G_M000_IG09:                ;; offset=0x0143
       mov      r13, gword ptr [rbp+0x18]
       mov      r15, bword ptr [rbp+0x10]
       test     rbx, rbx
       je       G_M000_IG97
       cmp      byte  ptr [rbp+0x28], 0
       je       SHORT G_M000_IG12
       mov      r8, bword ptr [rbp-0x340]
 
G_M000_IG10:                ;; offset=0x0161
       vmovdqu  ymm0, ymmword ptr [r8]
       vmovdqu  ymmword ptr [rbp-0x320], ymm0
 
G_M000_IG11:                ;; offset=0x016E
       lea      r8, [rbp-0x320]
       lea      rdx, [rbp-0x248]
       mov      rcx, rbx
       mov      r9d, 1
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteTargetInstruction(Lokad.Lython.Frontend.ExecutableInstruction,bool):System.Threading.Tasks.ValueTask:this]
       lea      rcx, [rbp-0x258]
       lea      rdx, [rbp-0x248]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:WithoutJump(System.Threading.Tasks.ValueTask):System.Threading.Tasks.ValueTask`1[bool]]
       mov      rdi, rsi
       mov      rdx, gword ptr [rbp-0x258]
       mov      rcx, rdi
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rdx, qword ptr [rbp-0x250]
       mov      qword ptr [rdi+0x08], rdx
       mov      rdi, gword ptr [rsi]
       test     rdi, rdi
       je       G_M000_IG62
       jmp      G_M000_IG296
 
G_M000_IG12:                ;; offset=0x01CD
       mov      r8, bword ptr [rbp-0x340]
 
G_M000_IG13:                ;; offset=0x01D4
       vmovdqu  ymm0, ymmword ptr [r8]
       vmovdqu  ymmword ptr [rbp-0x320], ymm0
 
G_M000_IG14:                ;; offset=0x01E1
       lea      r8, [rbp-0x320]
       lea      rdx, [rbp-0xB8]
       mov      rcx, rbx
       xor      r9d, r9d
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteTargetInstruction(Lokad.Lython.Frontend.ExecutableInstruction,bool):System.Threading.Tasks.ValueTask:this]
       mov      rdi, gword ptr [rbp-0xB8]
       movsx    r14, word  ptr [rbp-0xB0]
       test     rdi, rdi
       je       G_M000_IG358
 
G_M000_IG15:                ;; offset=0x0213
       mov      rdx, rdi
       mov      rcx, 0x7FF9B4EB8FA0
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       jne      G_M000_IG294
 
G_M000_IG16:                ;; offset=0x022E
       mov      rcx, rdi
       mov      edx, r14d
       mov      r11, 0x7FF9B4B62D18
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource:GetResult(short):this
       jmp      G_M000_IG358
 
G_M000_IG17:                ;; offset=0x0246
       mov      r13, gword ptr [rbp+0x18]
       mov      r15, bword ptr [rbp+0x10]
       movzx    rcx, byte  ptr [rbp+0x28]
       mov      dword ptr [rsp+0x20], ecx
       lea      rcx, [rbp-0x80]
       mov      qword ptr [rsp+0x28], rcx
       mov      rcx, r15
       mov      rdx, r13
       mov      r8, rbx
       mov      r9, bword ptr [rbp-0x340]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecutePreparedOperation(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,bool,byref):bool]
       test     eax, eax
       je       G_M000_IG97
       cmp      byte  ptr [rbp+0x28], 0
       je       SHORT G_M000_IG20
 
G_M000_IG18:                ;; offset=0x0283
       vmovdqu  xmm0, xmmword ptr [rbp-0x80]
       vmovdqu  xmmword ptr [rbp-0x330], xmm0
 
G_M000_IG19:                ;; offset=0x0290
       lea      rdx, [rbp-0x330]
       lea      rcx, [rbp-0x268]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:WithoutJump(System.Threading.Tasks.ValueTask):System.Threading.Tasks.ValueTask`1[bool]]
       mov      rdi, rsi
       mov      rdx, gword ptr [rbp-0x268]
       mov      rcx, rdi
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rdx, qword ptr [rbp-0x260]
       mov      qword ptr [rdi+0x08], rdx
       mov      rdi, gword ptr [rsi]
       test     rdi, rdi
       je       G_M000_IG62
       jmp      G_M000_IG309
 
G_M000_IG20:                ;; offset=0x02D2
       mov      rdi, gword ptr [rbp-0x80]
       movsx    r14, word  ptr [rbp-0x78]
       test     rdi, rdi
       je       G_M000_IG358
 
G_M000_IG21:                ;; offset=0x02E4
       mov      rdx, rdi
       mov      rcx, 0x7FF9B4EB8FA0
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       jne      G_M000_IG307
 
G_M000_IG22:                ;; offset=0x02FF
       mov      rcx, rdi
       mov      edx, r14d
       mov      r11, 0x7FF9B4B62D38
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource:GetResult(short):this
       jmp      G_M000_IG358
 
G_M000_IG23:                ;; offset=0x0317
       mov      r13, gword ptr [rbp+0x18]
       test     rbx, rbx
       je       G_M000_IG97
       mov      r15, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [r15]
       mov      rdi, gword ptr [rcx+0x38]
       mov      rcx, bword ptr [rbp-0x340]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_NameIndex():int:this]
       cmp      eax, dword ptr [rdi+0x08]
       jae      G_M000_IG357
       mov      ecx, eax
       mov      rcx, gword ptr [rdi+8*rcx+0x10]
       mov      rdx, bword ptr [rbp-0x340]
       mov      rdx, gword ptr [rdx]
       mov      r8, rbx
       mov      r9d, 1
       call     [Lokad.Lython.Runtime.LythonRuntime:ResolveName(System.String,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,bool):System.Object]
       mov      rdi, rax
       mov      r9, bword ptr [rbp-0x340]
       mov      r14d, dword ptr [r9+0x18]
       test     r14d, r14d
       jge      SHORT G_M000_IG24
       mov      gword ptr [rbp-0x300], rdi
       xor      r9d, r9d
       mov      qword ptr [rbp-0x2F8], r9
       lea      r9, [rbp-0x300]
       mov      rdx, rbx
       mov      r8, bword ptr [rbp-0x340]
       mov      rcx, r15
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CompleteResultConsumer(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot)]
       jmp      G_M000_IG358
 
G_M000_IG24:                ;; offset=0x03A8
       lea      rax, bword ptr [r15+0x20]
       mov      bword ptr [rbp-0x378], rax
       mov      rcx, bword ptr [rbp-0x340]
       mov      ecx, dword ptr [rcx+0x1C]
       cmp      ecx, 51
       ja       SHORT G_M000_IG27
 
G_M000_IG25:                ;; offset=0x03C2
       mov      rdx, 0x7FFFFFFFFF9FF
       bt       rdx, rcx
       jb       SHORT G_M000_IG27
 
G_M000_IG26:                ;; offset=0x03D2
       mov      r8d, r14d
       mov      dword ptr [rbp-0x2D4], r8d
       jmp      SHORT G_M000_IG28
 
G_M000_IG27:                ;; offset=0x03DE
       mov      r8, bword ptr [rbp-0x340]
       mov      r8d, dword ptr [r8+0x14]
       mov      dword ptr [rbp-0x2D4], r8d
 
G_M000_IG28:                ;; offset=0x03F0
       cmp      r14d, dword ptr [rax+0x40]
       jge      SHORT G_M000_IG29
       mov      rcx, rax
       mov      edx, r14d
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
       mov      rax, bword ptr [rbp-0x378]
 
G_M000_IG29:                ;; offset=0x0409
       mov      rcx, gword ptr [rax]
       mov      r8d, dword ptr [rbp-0x2D4]
       cmp      r8d, dword ptr [rcx+0x08]
       jae      G_M000_IG357
       mov      edx, r8d
       shl      rdx, 4
       lea      r8, bword ptr [rcx+rdx+0x10]
       mov      rcx, r8
       mov      bword ptr [rbp-0x3A8], rcx
       mov      rdx, rdi
       call     CORINFO_HELP_ASSIGN_REF
       xor      ecx, ecx
       mov      rdi, bword ptr [rbp-0x3A8]
       mov      qword ptr [rdi+0x08], rcx
       mov      rdi, bword ptr [rbp-0x378]
       mov      dword ptr [rdi+0x40], r14d
       jmp      G_M000_IG358
 
G_M000_IG30:                ;; offset=0x0458
       mov      r13, gword ptr [rbp+0x18]
       mov      r15, bword ptr [rbp+0x10]
       mov      rdi, gword ptr [r15]
       mov      rcx, bword ptr [rbp-0x340]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_NameIndex():int:this]
       mov      edx, eax
       mov      rcx, rdi
       mov      r8, bword ptr [rbp-0x340]
       mov      r8, gword ptr [r8]
       mov      r9, r13
       call     [Lokad.Lython.Runtime.LythonRuntime:ResolveExecutableGlobal(Lokad.Lython.Frontend.ExecutableCodeObject,int,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):System.Object]
       mov      rdi, rax
       mov      r9, bword ptr [rbp-0x340]
       mov      r14d, dword ptr [r9+0x18]
       test     r14d, r14d
       jge      SHORT G_M000_IG31
       mov      gword ptr [rbp-0x300], rdi
       xor      r9d, r9d
       mov      qword ptr [rbp-0x2F8], r9
       lea      r9, [rbp-0x300]
       mov      rdx, rbx
       mov      r8, bword ptr [rbp-0x340]
       mov      rcx, r15
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CompleteResultConsumer(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot)]
       jmp      G_M000_IG358
 
G_M000_IG31:                ;; offset=0x04CB
       lea      rax, bword ptr [r15+0x20]
       mov      bword ptr [rbp-0x370], rax
       mov      rcx, bword ptr [rbp-0x340]
       mov      ecx, dword ptr [rcx+0x1C]
       cmp      ecx, 51
       ja       SHORT G_M000_IG34
 
G_M000_IG32:                ;; offset=0x04E5
       mov      rdx, 0x7FFFFFFFFF9FF
       bt       rdx, rcx
       jb       SHORT G_M000_IG34
 
G_M000_IG33:                ;; offset=0x04F5
       mov      r8d, r14d
       mov      dword ptr [rbp-0x2D0], r8d
       jmp      SHORT G_M000_IG35
 
G_M000_IG34:                ;; offset=0x0501
       mov      r8, bword ptr [rbp-0x340]
       mov      r8d, dword ptr [r8+0x14]
       mov      dword ptr [rbp-0x2D0], r8d
 
G_M000_IG35:                ;; offset=0x0513
       cmp      r14d, dword ptr [rax+0x40]
       jge      SHORT G_M000_IG36
       mov      rcx, rax
       mov      edx, r14d
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
       mov      rax, bword ptr [rbp-0x370]
 
G_M000_IG36:                ;; offset=0x052C
       mov      rcx, gword ptr [rax]
       mov      r8d, dword ptr [rbp-0x2D0]
       cmp      r8d, dword ptr [rcx+0x08]
       jae      G_M000_IG357
       mov      edx, r8d
       shl      rdx, 4
       lea      r8, bword ptr [rcx+rdx+0x10]
       mov      rcx, r8
       mov      bword ptr [rbp-0x3B0], rcx
       mov      rdx, rdi
       call     CORINFO_HELP_ASSIGN_REF
       xor      ecx, ecx
       mov      rdi, bword ptr [rbp-0x3B0]
       mov      qword ptr [rdi+0x08], rcx
       mov      rdi, bword ptr [rbp-0x370]
       mov      dword ptr [rdi+0x40], r14d
       jmp      G_M000_IG358
 
G_M000_IG37:                ;; offset=0x057B
       mov      r15, bword ptr [rbp+0x10]
       cmp      gword ptr [r15+0x40], 0
       jne      SHORT G_M000_IG38
       mov      r13, gword ptr [rbp+0x18]
       mov      gword ptr [rsp+0x20], r13
       mov      rcx, gword ptr [r15]
       mov      rdx, gword ptr [r15+0x18]
       mov      r8d, dword ptr [r15+0x10]
       mov      r9d, dword ptr [r15+0x60]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryExecuteClosureArithmetic(Lokad.Lython.Frontend.ExecutableCodeObject,Lokad.Lython.Runtime.LythonRuntime+ExecutableCaptures,int,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):bool]
       test     eax, eax
       jne      G_M000_IG45
 
G_M000_IG38:                ;; offset=0x05AC
       mov      r13, gword ptr [rbp+0x18]
       mov      rcx, bword ptr [rbp-0x340]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ClosureSlot():int:this]
       mov      r8d, eax
       lea      r9, [rbp-0x60]
       mov      qword ptr [rsp+0x20], r9
       mov      r9, bword ptr [rbp-0x340]
       mov      r9, gword ptr [r9]
       mov      rdx, rbx
       mov      rcx, r15
       call     [Lokad.Lython.Runtime.LythonRuntime:TryLoadClosure(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,int,Lokad.Lython.LythonSourceSpan,byref):bool]
       test     eax, eax
       je       G_M000_IG97
       mov      rdi, gword ptr [rbp-0x60]
       mov      r9, bword ptr [rbp-0x340]
       mov      r14d, dword ptr [r9+0x18]
       test     r14d, r14d
       jge      SHORT G_M000_IG39
       mov      gword ptr [rbp-0x300], rdi
       xor      r9d, r9d
       mov      qword ptr [rbp-0x2F8], r9
       lea      r9, [rbp-0x300]
       mov      rdx, rbx
       mov      r8, bword ptr [rbp-0x340]
       mov      rcx, r15
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CompleteResultConsumer(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot)]
       jmp      G_M000_IG358
 
G_M000_IG39:                ;; offset=0x062B
       lea      rax, bword ptr [r15+0x20]
       mov      bword ptr [rbp-0x360], rax
       mov      rcx, bword ptr [rbp-0x340]
       mov      ecx, dword ptr [rcx+0x1C]
       cmp      ecx, 51
       ja       SHORT G_M000_IG42
 
G_M000_IG40:                ;; offset=0x0645
       mov      rdx, 0x7FFFFFFFFF9FF
       bt       rdx, rcx
       jb       SHORT G_M000_IG42
 
G_M000_IG41:                ;; offset=0x0655
       mov      r8d, r14d
       mov      dword ptr [rbp-0x298], r8d
       jmp      SHORT G_M000_IG43
 
G_M000_IG42:                ;; offset=0x0661
       mov      r8, bword ptr [rbp-0x340]
       mov      r8d, dword ptr [r8+0x14]
       mov      dword ptr [rbp-0x298], r8d
 
G_M000_IG43:                ;; offset=0x0673
       cmp      r14d, dword ptr [rax+0x40]
       jge      SHORT G_M000_IG44
       mov      rcx, rax
       mov      edx, r14d
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
       mov      rax, bword ptr [rbp-0x360]
 
G_M000_IG44:                ;; offset=0x068C
       mov      rcx, gword ptr [rax]
       mov      r8d, dword ptr [rbp-0x298]
       cmp      r8d, dword ptr [rcx+0x08]
       jae      G_M000_IG357
       mov      edx, r8d
       shl      rdx, 4
       lea      r8, bword ptr [rcx+rdx+0x10]
       mov      rcx, r8
       mov      bword ptr [rbp-0x3B8], rcx
       mov      rdx, rdi
       call     CORINFO_HELP_ASSIGN_REF
       xor      ecx, ecx
       mov      rdi, bword ptr [rbp-0x3B8]
       mov      qword ptr [rdi+0x08], rcx
       mov      rdi, bword ptr [rbp-0x360]
       mov      dword ptr [rdi+0x40], r14d
       jmp      G_M000_IG358
 
G_M000_IG45:                ;; offset=0x06DB
       add      dword ptr [r15+0x10], 2
       jmp      G_M000_IG358
 
G_M000_IG46:                ;; offset=0x06E5
       mov      r13, gword ptr [rbp+0x18]
       mov      r15, bword ptr [rbp+0x10]
       mov      rdi, gword ptr [r15]
       mov      r14, gword ptr [r15+0x08]
       mov      rcx, bword ptr [rbp-0x340]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LocalSlot():int:this]
       mov      dword ptr [rbp-0x26C], eax
       mov      rcx, bword ptr [rbp-0x340]
       mov      r8, gword ptr [rcx]
       mov      gword ptr [rbp-0x350], r8
       mov      rcx, r14
       mov      edx, eax
       call     [Lokad.Lython.Runtime.LythonRuntime:ReadLocalValue(Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot[],int):System.Object]
       mov      r14, rax
       test     r14, r14
       jne      SHORT G_M000_IG47
       mov      rcx, rdi
       mov      edx, dword ptr [rbp-0x26C]
       mov      r8, gword ptr [rbp-0x350]
       mov      r9, r13
       call     [Lokad.Lython.Runtime.LythonRuntime:LoadMissingLocal(Lokad.Lython.Frontend.ExecutableCodeObject,int,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):System.Object]
       mov      r14, rax
 
G_M000_IG47:                ;; offset=0x0747
       mov      r9, bword ptr [rbp-0x340]
       mov      edi, dword ptr [r9+0x18]
       test     edi, edi
       jge      SHORT G_M000_IG48
       mov      gword ptr [rbp-0x300], r14
       xor      r9d, r9d
       mov      qword ptr [rbp-0x2F8], r9
       lea      r9, [rbp-0x300]
       mov      rdx, rbx
       mov      r8, bword ptr [rbp-0x340]
       mov      rcx, r15
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CompleteResultConsumer(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot)]
       jmp      G_M000_IG358
 
G_M000_IG48:                ;; offset=0x0786
       lea      rax, bword ptr [r15+0x20]
       mov      bword ptr [rbp-0x358], rax
       mov      rcx, bword ptr [rbp-0x340]
       mov      ecx, dword ptr [rcx+0x1C]
       cmp      ecx, 51
       ja       SHORT G_M000_IG51
 
G_M000_IG49:                ;; offset=0x07A0
       mov      rdx, 0x7FFFFFFFFF9FF
       bt       rdx, rcx
       jb       SHORT G_M000_IG51
 
G_M000_IG50:                ;; offset=0x07B0
       mov      r8d, edi
       mov      dword ptr [rbp-0x294], r8d
       jmp      SHORT G_M000_IG52
 
G_M000_IG51:                ;; offset=0x07BC
       mov      r8, bword ptr [rbp-0x340]
       mov      r8d, dword ptr [r8+0x14]
       mov      dword ptr [rbp-0x294], r8d
 
G_M000_IG52:                ;; offset=0x07CE
       cmp      edi, dword ptr [rax+0x40]
       jge      SHORT G_M000_IG53
       mov      rcx, rax
       mov      edx, edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
       mov      rax, bword ptr [rbp-0x358]
 
G_M000_IG53:                ;; offset=0x07E5
       mov      rcx, gword ptr [rax]
       mov      r8d, dword ptr [rbp-0x294]
       cmp      r8d, dword ptr [rcx+0x08]
       jae      G_M000_IG357
       mov      edx, r8d
       shl      rdx, 4
       lea      r8, bword ptr [rcx+rdx+0x10]
       mov      rcx, r8
       mov      bword ptr [rbp-0x3C0], rcx
       mov      rdx, r14
       call     CORINFO_HELP_ASSIGN_REF
       xor      ecx, ecx
       mov      r14, bword ptr [rbp-0x3C0]
       mov      qword ptr [r14+0x08], rcx
       mov      r14, bword ptr [rbp-0x358]
       mov      dword ptr [r14+0x40], edi
       jmp      G_M000_IG358
 
G_M000_IG54:                ;; offset=0x0834
       mov      r15, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [r15]
       mov      rdi, gword ptr [rcx+0x30]
       mov      rcx, bword ptr [rbp-0x340]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ConstantIndex():int:this]
       cmp      eax, dword ptr [rdi+0x08]
       jae      G_M000_IG357
       mov      ecx, eax
       mov      rcx, gword ptr [rdi+8*rcx+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime:RuntimeValue(System.Object):System.Object]
       mov      rdi, rax
       mov      r9, bword ptr [rbp-0x340]
       mov      r14d, dword ptr [r9+0x18]
       test     r14d, r14d
       jge      SHORT G_M000_IG55
       mov      gword ptr [rbp-0x300], rdi
       xor      r9d, r9d
       mov      qword ptr [rbp-0x2F8], r9
       lea      r9, [rbp-0x300]
       mov      rdx, rbx
       mov      r8, bword ptr [rbp-0x340]
       mov      rcx, r15
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CompleteResultConsumer(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot)]
       jmp      G_M000_IG358
 
G_M000_IG55:                ;; offset=0x08A5
       lea      rax, bword ptr [r15+0x20]
       mov      bword ptr [rbp-0x368], rax
       mov      rcx, bword ptr [rbp-0x340]
       mov      ecx, dword ptr [rcx+0x1C]
       cmp      ecx, 51
       ja       SHORT G_M000_IG58
 
G_M000_IG56:                ;; offset=0x08BF
       mov      rdx, 0x7FFFFFFFFF9FF
       bt       rdx, rcx
       jb       SHORT G_M000_IG58
 
G_M000_IG57:                ;; offset=0x08CF
       mov      r8d, r14d
       mov      dword ptr [rbp-0x2CC], r8d
       jmp      SHORT G_M000_IG59
 
G_M000_IG58:                ;; offset=0x08DB
       mov      r8, bword ptr [rbp-0x340]
       mov      r8d, dword ptr [r8+0x14]
       mov      dword ptr [rbp-0x2CC], r8d
 
G_M000_IG59:                ;; offset=0x08ED
       cmp      r14d, dword ptr [rax+0x40]
       jge      SHORT G_M000_IG60
       mov      rcx, rax
       mov      edx, r14d
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
       mov      rax, bword ptr [rbp-0x368]
 
G_M000_IG60:                ;; offset=0x0906
       mov      rcx, gword ptr [rax]
       mov      r8d, dword ptr [rbp-0x2CC]
       cmp      r8d, dword ptr [rcx+0x08]
       jae      G_M000_IG357
       mov      edx, r8d
       shl      rdx, 4
       lea      r8, bword ptr [rcx+rdx+0x10]
       mov      rcx, r8
       mov      bword ptr [rbp-0x3C8], rcx
       mov      rdx, rdi
       call     CORINFO_HELP_ASSIGN_REF
       xor      edx, edx
       mov      rdi, bword ptr [rbp-0x3C8]
       mov      qword ptr [rdi+0x08], rdx
       mov      rdi, bword ptr [rbp-0x368]
       mov      dword ptr [rdi+0x40], r14d
       jmp      G_M000_IG358
 
G_M000_IG61:                ;; offset=0x0955
       test     rbx, rbx
       je       G_M000_IG97
       mov      r15, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [r15]
       mov      rcx, gword ptr [rdx+0xA8]
       mov      rdx, bword ptr [rbp-0x340]
       mov      edx, dword ptr [rdx+0x08]
       mov      r11, 0x7FF9B4B62D10
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       cmp      byte  ptr [rbp+0x28], 0
       je       SHORT G_M000_IG63
       lea      rcx, [rbp-0x280]
       mov      rdx, rax
       mov      r8, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime:ExecuteImportAsync(Lokad.Lython.Frontend.ImportStatementSyntax,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):System.Threading.Tasks.ValueTask]
       lea      rcx, [rbp-0x290]
       lea      rdx, [rbp-0x280]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:WithoutJump(System.Threading.Tasks.ValueTask):System.Threading.Tasks.ValueTask`1[bool]]
       mov      rdi, rsi
       mov      rdx, gword ptr [rbp-0x290]
       mov      rcx, rdi
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rdx, qword ptr [rbp-0x288]
       mov      qword ptr [rdi+0x08], rdx
       mov      rdi, gword ptr [rsi]
       test     rdi, rdi
       jne      G_M000_IG316
 
G_M000_IG62:                ;; offset=0x09D9
       mov      r15, bword ptr [rbp+0x10]
       mov      r13, gword ptr [rbp+0x18]
       mov      rcx, rsi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ConsumeOperation(byref):bool]
       jmp      G_M000_IG358
 
G_M000_IG63:                ;; offset=0x09EF
       mov      rcx, gword ptr [r15]
       mov      r8, gword ptr [r15+0x08]
       mov      rdx, rax
       mov      r9, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime:ExecuteExecutableImport(Lokad.Lython.Frontend.ExecutableCodeObject,Lokad.Lython.Frontend.ImportStatementSyntax,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot[],Lokad.Lython.Runtime.LythonRuntime+ExecutionContext)]
       jmp      G_M000_IG358
 
G_M000_IG64:                ;; offset=0x0A07
       test     rbx, rbx
       je       G_M000_IG97
       mov      r15, bword ptr [rbp+0x10]
       lea      rcx, bword ptr [r15+0x20]
       mov      rdx, bword ptr [rbp-0x340]
       mov      r8d, dword ptr [rdx+0x10]
       mov      edx, r14d
       cmp      edx, 51
       ja       SHORT G_M000_IG69
 
G_M000_IG65:                ;; offset=0x0A2B
       mov      r9, 0x7FFFFFFFFF9FF
       bt       r9, rdx
       jb       SHORT G_M000_IG69
 
G_M000_IG66:                ;; offset=0x0A3B
       mov      rdx, bword ptr [rbp-0x340]
       mov      edx, dword ptr [rdx+0x18]
       test     edx, edx
       jge      SHORT G_M000_IG67
       mov      r9d, edx
       not      r9d
       jmp      SHORT G_M000_IG68
 
G_M000_IG67:                ;; offset=0x0A51
       mov      r9d, edx
 
G_M000_IG68:                ;; offset=0x0A54
       jmp      SHORT G_M000_IG70
 
G_M000_IG69:                ;; offset=0x0A56
       mov      r9, bword ptr [rbp-0x340]
       mov      r9d, dword ptr [r9+0x14]
 
G_M000_IG70:                ;; offset=0x0A61
       lea      rdx, [rbp-0xC8]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:TakeSlotValue(int,int):Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:this]
       mov      r14d, dword ptr [r15+0x10]
       inc      r14d
       mov      r13, gword ptr [rbx+0x70]
       cmp      byte  ptr [rbx+0x10A], 0
       jne      SHORT G_M000_IG71
       cmp      byte  ptr [rbx+0x108], 0
       jne      SHORT G_M000_IG71
       cmp      edi, r14d
       jg       SHORT G_M000_IG72
 
G_M000_IG71:                ;; offset=0x0A90
       xor      r12d, r12d
       jmp      SHORT G_M000_IG73
 
G_M000_IG72:                ;; offset=0x0A95
       cmp      r14d, edi
       jae      G_M000_IG357
       mov      r8d, r14d
       shl      r8, 5
       mov      rax, gword ptr [rbp-0x338]
       cmp      dword ptr [rax+r8+0x2C], 30
       sete     r12b
       movzx    r12, r12b
 
G_M000_IG73:                ;; offset=0x0ABA
       test     r12d, r12d
       je       SHORT G_M000_IG76
       test     r13, r13
       je       SHORT G_M000_IG76
 
G_M000_IG74:                ;; offset=0x0AC4
       vmovdqu  xmm0, xmmword ptr [rbp-0xC8]
       vmovdqu  xmmword ptr [rbp-0x300], xmm0
 
G_M000_IG75:                ;; offset=0x0AD4
       lea      r8, [rbp-0x300]
       mov      rdx, r13
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryAppendBufferedYield(System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot):bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG77
 
G_M000_IG76:                ;; offset=0x0AEB
       lea      rdi, bword ptr [rbx+0x198]
       mov      rdx, gword ptr [rbp-0xC8]
       mov      rcx, rdi
       call     CORINFO_HELP_ASSIGN_REF
       mov      rcx, qword ptr [rbp-0xC0]
       mov      qword ptr [rdi+0x08], rcx
       mov      word  ptr [rbx+0x100], 257
       inc      dword ptr [r15+0x10]
       test     r12d, r12d
       jne      G_M000_IG263
       test     r13, r13
       je       G_M000_IG263
       mov      rcx, rbx
       mov      rdx, r13
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryBufferYield(System.Object):bool:this]
       test     eax, eax
       je       G_M000_IG263
       jmp      G_M000_IG360
 
G_M000_IG77:                ;; offset=0x0B44
       cmp      r14d, edi
       jae      G_M000_IG357
       mov      ecx, r14d
       shl      rcx, 5
       mov      rax, gword ptr [rbp-0x338]
       mov      rdi, gword ptr [rax+rcx+0x10]
       mov      r13, gword ptr [rbp+0x18]
       mov      r12, gword ptr [r13+0xA0]
       cmp      byte  ptr [r12], r12b
       mov      rcx, r12
       call     [Lokad.Lython.Runtime.ExecutionState:get_CanContinue():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG78
       mov      rcx, r12
       mov      rdx, rdi
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
 
G_M000_IG78:                ;; offset=0x0B88
       mov      rcx, gword ptr [r13+0xA0]
       mov      rdx, rcx
       mov      rax, gword ptr [rbx+0x78]
       test     rax, rax
       je       SHORT G_M000_IG79
       cmp      dword ptr [rax+0x10], 0
       setg     al
       movzx    rax, al
       test     eax, eax
       je       SHORT G_M000_IG79
       mov      rax, gword ptr [rcx+0x148]
       jmp      SHORT G_M000_IG80
 
G_M000_IG79:                ;; offset=0x0BB2
       mov      rax, gword ptr [rbx+0x80]
 
G_M000_IG80:                ;; offset=0x0BB9
       lea      rcx, bword ptr [rdx+0x148]
       mov      rdx, rax
       call     CORINFO_HELP_ASSIGN_REF
       lea      rcx, bword ptr [r15+0x20]
       mov      edx, r14d
       shl      rdx, 5
       mov      rax, gword ptr [rbp-0x338]
       lea      rdx, bword ptr [rax+rdx+0x10]
       mov      edx, dword ptr [rdx+0x18]
       test     edx, edx
       jge      SHORT G_M000_IG81
       not      edx
 
G_M000_IG81:                ;; offset=0x0BE8
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
       add      dword ptr [r15+0x10], 2
       jmp      G_M000_IG360
 
G_M000_IG82:                ;; offset=0x0BF8
       mov      r13, gword ptr [rbp+0x18]
       mov      r15, bword ptr [rbp+0x10]
       movzx    rcx, byte  ptr [rbp+0x28]
       mov      dword ptr [rsp+0x20], ecx
       mov      bword ptr [rsp+0x28], rsi
       mov      r8, bword ptr [rbp+0x38]
       mov      bword ptr [rsp+0x30], r8
       mov      rcx, r15
       mov      rdx, r13
       mov      r8, rbx
       mov      r9, bword ptr [rbp-0x340]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteComparisonInstruction(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,bool,byref,byref):int]
       test     eax, eax
       je       G_M000_IG228
       mov      dword ptr [rbp-0xA4], eax
       jmp      G_M000_IG366
 
G_M000_IG83:                ;; offset=0x0C3F
       mov      rdx, bword ptr [rbp-0x340]
       mov      r8d, dword ptr [rdx+0x10]
       mov      r15, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [r15]
       mov      rdx, gword ptr [r15+0x20]
       test     rdx, rdx
       je       SHORT G_M000_IG84
       lea      r9, bword ptr [rdx+0x10]
       mov      edx, dword ptr [rdx+0x08]
       jmp      SHORT G_M000_IG85
 
G_M000_IG84:                ;; offset=0x0C63
       xor      r9, r9
       xor      edx, edx
 
G_M000_IG85:                ;; offset=0x0C68
       mov      bword ptr [rbp-0x2F0], r9
       mov      dword ptr [rbp-0x2E8], edx
       xor      edx, edx
       mov      dword ptr [rsp+0x20], edx
       mov      r13, gword ptr [rbp+0x18]
       mov      gword ptr [rsp+0x28], r13
       lea      rdx, [rbp-0x2F0]
       mov      r9d, dword ptr [r15+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime:ReadExecutableOperand(Lokad.Lython.Frontend.ExecutableCodeObject,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],int,int,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):System.Object]
       mov      rdi, rax
       test     rbx, rbx
       jne      SHORT G_M000_IG86
       mov      rcx, rdi
       call     [Lokad.Lython.Runtime.LythonRuntime:CanUseNativeTruth(System.Object):bool]
       test     eax, eax
       je       G_M000_IG97
 
G_M000_IG86:                ;; offset=0x0CAE
       cmp      byte  ptr [rbp+0x28], 0
       je       SHORT G_M000_IG91
       test     rdi, rdi
       je       SHORT G_M000_IG91
 
G_M000_IG87:                ;; offset=0x0CB9
       mov      r8, 0x7FF9B54EF0A8
       cmp      qword ptr [rdi], r8
       jne      SHORT G_M000_IG91
 
G_M000_IG88:                ;; offset=0x0CC8
       mov      r8, bword ptr [rbp-0x340]
 
G_M000_IG89:                ;; offset=0x0CCF
       vmovdqu  ymm0, ymmword ptr [r8]
       vmovdqu  ymmword ptr [rbp-0x320], ymm0
 
G_M000_IG90:                ;; offset=0x0CDC
       lea      r8, [rbp-0x320]
       lea      rdx, [rbp-0x1A8]
       mov      rcx, rbx
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteConditionalJumpAsync(Lokad.Lython.Frontend.ExecutableInstruction):System.Threading.Tasks.ValueTask`1[bool]:this]
       mov      rdi, rsi
       mov      rdx, gword ptr [rbp-0x1A8]
       mov      rcx, rdi
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rdx, qword ptr [rbp-0x1A0]
       mov      qword ptr [rdi+0x08], rdx
       mov      rdi, gword ptr [rsi]
       test     rdi, rdi
       je       G_M000_IG228
       jmp      G_M000_IG351
 
G_M000_IG91:                ;; offset=0x0D23
       mov      rcx, r15
       mov      rdx, r13
       mov      r8, rbx
       mov      r9, bword ptr [rbp-0x340]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteControlFlow(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       mov      dword ptr [rbp-0x3C], eax
       jmp      G_M000_IG358
 
G_M000_IG92:                ;; offset=0x0D41
       mov      r13, gword ptr [rbp+0x18]
       mov      r15, bword ptr [rbp+0x10]
       test     rbx, rbx
       jne      SHORT G_M000_IG94
       mov      ecx, r14d
       cmp      ecx, 58
       ja       G_M000_IG97
 
G_M000_IG93:                ;; offset=0x0D5A
       mov      rdx, 0x1FDFFFFFFFFFFFF
       bt       rdx, rcx
       jb       G_M000_IG97
 
G_M000_IG94:                ;; offset=0x0D6E
       mov      rcx, r15
       mov      rdx, r13
       mov      r8, rbx
       mov      r9, bword ptr [rbp-0x340]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteControlFlow(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       mov      dword ptr [rbp-0x3C], eax
       cmp      gword ptr [r15+0x68], 0
       je       G_M000_IG358
       cmp      byte  ptr [rbp+0x28], 0
       je       G_M000_IG263
       cmp      gword ptr [r15+0x40], 0
       je       G_M000_IG263
       xor      rcx, rcx
       mov      gword ptr [rsi], rcx
       mov      word  ptr [rsi+0x08], 0
       movzx    rcx, byte  ptr [rbp-0x3C]
       mov      byte  ptr [rsi+0x0A], cl
       mov      byte  ptr [rsi+0x0B], 1
       mov      dword ptr [rbp-0xA4], 5
       jmp      G_M000_IG366
 
G_M000_IG95:                ;; offset=0x0DCC
       mov      r13, gword ptr [rbp+0x18]
       mov      r15, bword ptr [rbp+0x10]
       mov      rcx, r15
       mov      rdx, r13
       mov      r8, rbx
       mov      r9, bword ptr [rbp-0x340]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteBuiltinArithmetic(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       test     eax, eax
       je       G_M000_IG102
       jmp      G_M000_IG358
 
G_M000_IG96:                ;; offset=0x0DF7
       mov      r13, gword ptr [rbp+0x18]
       mov      r15, bword ptr [rbp+0x10]
       test     rbx, rbx
       jne      G_M000_IG224
 
G_M000_IG97:                ;; offset=0x0E08
       mov      r15, bword ptr [rbp+0x10]
       mov      r13, gword ptr [rbp+0x18]
       mov      dword ptr [rbp-0xA4], 6
       jmp      G_M000_IG366
 
G_M000_IG98:                ;; offset=0x0E1F
       mov      r13, gword ptr [rbp+0x18]
       mov      r15, bword ptr [rbp+0x10]
       test     rbx, rbx
       je       SHORT G_M000_IG97
       cmp      byte  ptr [rbp+0x28], 0
       je       G_M000_IG224
       mov      r8, bword ptr [rbp-0x340]
 
G_M000_IG99:                ;; offset=0x0E3D
       vmovdqu  ymm0, ymmword ptr [r8]
       vmovdqu  ymmword ptr [rbp-0x320], ymm0
 
G_M000_IG100:                ;; offset=0x0E4A
       lea      r8, [rbp-0x320]
       lea      rdx, [rbp-0x1B8]
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteSliceValueOperationAsync(Lokad.Lython.Frontend.ExecutableInstruction):System.Threading.Tasks.ValueTask:this]
       lea      rcx, [rbp-0x1C8]
       lea      rdx, [rbp-0x1B8]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:WithoutJump(System.Threading.Tasks.ValueTask):System.Threading.Tasks.ValueTask`1[bool]]
       mov      r14, rsi
       mov      rdx, gword ptr [rbp-0x1C8]
       mov      rcx, r14
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rdx, qword ptr [rbp-0x1C0]
       mov      qword ptr [r14+0x08], rdx
       mov      rdi, gword ptr [rsi]
       test     rdi, rdi
       je       G_M000_IG62
       jmp      G_M000_IG348
 
G_M000_IG101:                ;; offset=0x0EA3
       mov      r13, gword ptr [rbp+0x18]
       mov      r15, bword ptr [rbp+0x10]
       mov      rcx, r15
       mov      rdx, r13
       mov      r8, rbx
       mov      r9, bword ptr [rbp-0x340]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteSequenceIndex(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       test     eax, eax
       jne      G_M000_IG358
 
G_M000_IG102:                ;; offset=0x0EC9
       mov      r15, bword ptr [rbp+0x10]
       mov      r13, gword ptr [rbp+0x18]
       movzx    rcx, byte  ptr [rbp+0x28]
       mov      dword ptr [rsp+0x20], ecx
       mov      bword ptr [rsp+0x28], rsi
       mov      rcx, bword ptr [rbp+0x38]
       mov      bword ptr [rsp+0x30], rcx
       mov      r12, bword ptr [rbp+0x40]
       mov      bword ptr [rsp+0x38], r12
       mov      rcx, r15
       mov      rdx, r13
       mov      r8, rbx
       mov      r9, bword ptr [rbp-0x340]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteInputInstruction(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,bool,byref,byref,byref):int]
       test     eax, eax
       je       G_M000_IG358
       mov      dword ptr [rbp-0xA4], eax
       jmp      G_M000_IG366
 
G_M000_IG103:                ;; offset=0x0F19
       mov      r15, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [r15]
       mov      rcx, gword ptr [rdx+0xB0]
       cmp      r14d, 42
       jne      G_M000_IG331
       mov      rdx, bword ptr [rbp-0x340]
       mov      edx, dword ptr [rdx+0x08]
       mov      r11, 0x7FF9B4B62D08
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       mov      r14, rax
       mov      rcx, bword ptr [rbp-0x340]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       mov      edi, eax
       mov      rdx, bword ptr [rbp-0x340]
       cmp      dword ptr [rdx+0x0C], 0x7FFFFFFF
       je       G_M000_IG127
       cmp      dword ptr [r15+0x60], edi
       jne      G_M000_IG127
       mov      rdx, bword ptr [rbp-0x340]
       mov      r8d, dword ptr [rdx+0x10]
       mov      rcx, gword ptr [r15]
       mov      rdx, gword ptr [r15+0x20]
       test     rdx, rdx
       je       SHORT G_M000_IG104
       lea      r9, bword ptr [rdx+0x10]
       mov      edx, dword ptr [rdx+0x08]
       jmp      SHORT G_M000_IG105
 
G_M000_IG104:                ;; offset=0x0F98
       xor      r9, r9
       xor      edx, edx
 
G_M000_IG105:                ;; offset=0x0F9D
       mov      bword ptr [rbp-0x2F0], r9
       mov      dword ptr [rbp-0x2E8], edx
       xor      edx, edx
       mov      dword ptr [rsp+0x20], edx
       mov      r13, gword ptr [rbp+0x18]
       mov      gword ptr [rsp+0x28], r13
       lea      rdx, [rbp-0x2F0]
       mov      r9d, dword ptr [r15+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime:ReadExecutableOperand(Lokad.Lython.Frontend.ExecutableCodeObject,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],int,int,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):System.Object]
       mov      r12, rax
       mov      r8, bword ptr [rbp-0x340]
       mov      eax, dword ptr [r8+0x0C]
       mov      dword ptr [rbp-0xCC], eax
       mov      r8, bword ptr [rbp-0x340]
       cmp      dword ptr [r8+0x10], 0
       jl       G_M000_IG112
       test     rbx, rbx
       je       G_M000_IG112
       test     r12, r12
       je       G_M000_IG112
 
G_M000_IG106:                ;; offset=0x1002
       mov      r8, 0x7FF9B54EA2D8
       cmp      qword ptr [r12], r8
       jne      G_M000_IG112
 
G_M000_IG107:                ;; offset=0x1016
       mov      r8, gword ptr [r15+0x20]
       cmp      eax, dword ptr [r8+0x08]
       jae      G_M000_IG357
       mov      edx, eax
       shl      rdx, 4
 
G_M000_IG108:                ;; offset=0x102A
       vmovdqu  xmm0, xmmword ptr [r8+rdx+0x10]
       vmovdqu  xmmword ptr [rbp-0x300], xmm0
 
G_M000_IG109:                ;; offset=0x1039
       lea      r8, [rbp-0xE0]
       mov      qword ptr [rsp+0x20], r8
       lea      r8, [rbp-0x300]
       mov      rdx, r14
       mov      rcx, r12
       mov      r9, r13
       call     [Lokad.Lython.Runtime.PyExecutableFunction:TryStartForwardedComputedDefinition(Lokad.Lython.Frontend.ExecutableCallSite,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool:this]
       test     eax, eax
       mov      eax, dword ptr [rbp-0xCC]
       je       SHORT G_M000_IG112
 
G_M000_IG110:                ;; offset=0x1065
       vmovdqu  xmm0, xmmword ptr [rbp-0xE0]
       vmovdqu  xmmword ptr [rbp-0x300], xmm0
 
G_M000_IG111:                ;; offset=0x1075
       lea      r9, [rbp-0x300]
       mov      rdx, rbx
       mov      r8, bword ptr [rbp-0x340]
       mov      rcx, r15
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PublishInstructionResult(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot)]
       jmp      G_M000_IG358
 
G_M000_IG112:                ;; offset=0x1094
       test     eax, eax
       jl       SHORT G_M000_IG117
       mov      r8, gword ptr [r15+0x20]
       cmp      eax, dword ptr [r8+0x08]
       jae      G_M000_IG357
       mov      ecx, eax
       shl      rcx, 4
       lea      r8, bword ptr [r8+rcx+0x10]
       mov      rcx, qword ptr [r8+0x08]
       test     rcx, rcx
       mov      eax, dword ptr [rbp-0xCC]
       jle      SHORT G_M000_IG117
       mov      r8, gword ptr [r8]
       test     r8, r8
       je       SHORT G_M000_IG115
 
G_M000_IG113:                ;; offset=0x10C8
       mov      rdx, 0x7FF9B51DB730
       cmp      qword ptr [r8], rdx
       jne      SHORT G_M000_IG115
 
G_M000_IG114:                ;; offset=0x10D7
       mov      r8d, 1
       jmp      SHORT G_M000_IG116
 
G_M000_IG115:                ;; offset=0x10DF
       xor      r8d, r8d
 
G_M000_IG116:                ;; offset=0x10E2
       test     r8d, r8d
       je       SHORT G_M000_IG117
       lea      r8, [rbp-0xF0]
       mov      qword ptr [rsp+0x20], r8
       mov      r8, gword ptr [r14+0x18]
       mov      rdx, r12
       mov      r9, r13
       call     [Lokad.Lython.Runtime.LythonRuntime:TryInvokeShortUtf8Float(long,System.Object,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       test     eax, eax
       mov      eax, dword ptr [rbp-0xCC]
       jne      G_M000_IG146
 
G_M000_IG117:                ;; offset=0x1111
       mov      rcx, gword ptr [r15]
       mov      rdx, gword ptr [r15+0x20]
       test     rdx, rdx
       je       SHORT G_M000_IG118
       lea      r9, bword ptr [rdx+0x10]
       mov      edx, dword ptr [rdx+0x08]
       jmp      SHORT G_M000_IG119
 
G_M000_IG118:                ;; offset=0x1126
       xor      r9, r9
       xor      edx, edx
 
G_M000_IG119:                ;; offset=0x112B
       mov      bword ptr [rbp-0x2F0], r9
       mov      dword ptr [rbp-0x2E8], edx
       mov      dword ptr [rsp+0x20], 1
       mov      gword ptr [rsp+0x28], r13
       lea      rdx, [rbp-0x2F0]
       mov      r9d, dword ptr [r15+0x10]
       mov      r8d, eax
       call     [Lokad.Lython.Runtime.LythonRuntime:ReadExecutableOperand(Lokad.Lython.Frontend.ExecutableCodeObject,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],int,int,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):System.Object]
       mov      gword ptr [rbp-0x348], rax
       mov      rdx, r12
       mov      rcx, 0x7FF9B54BACD0
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG120
       test     rbx, rbx
       setne    r8b
       movzx    r8, r8b
       mov      dword ptr [rsp+0x20], r8d
       lea      r8, [rbp-0x100]
       mov      qword ptr [rsp+0x28], r8
       mov      r8, gword ptr [r14+0x18]
       mov      rcx, rax
       mov      rdx, gword ptr [rbp-0x348]
       mov      r9, r13
       call     [Lokad.Lython.Runtime.LythonRuntime:TryInvokeUnaryBuiltin(Lokad.Lython.Runtime.LythonRuntime+BuiltinCallable,System.Object,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,bool,byref):bool]
       test     eax, eax
       jne      G_M000_IG142
 
G_M000_IG120:                ;; offset=0x11B2
       lea      rax, bword ptr [r15+0x20]
       mov      bword ptr [rbp-0x388], rax
       lea      r8d, [rdi+0x01]
       mov      dword ptr [rbp-0x2D8], r8d
       cmp      r8d, dword ptr [rax+0x40]
       jl       SHORT G_M000_IG122
 
G_M000_IG121:                ;; offset=0x11CE
       jmp      SHORT G_M000_IG123
 
G_M000_IG122:                ;; offset=0x11D0
       mov      rcx, rax
       mov      edx, r8d
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
       mov      rax, bword ptr [rbp-0x388]
 
G_M000_IG123:                ;; offset=0x11E3
       mov      rcx, gword ptr [rax]
       cmp      edi, dword ptr [rcx+0x08]
       jae      G_M000_IG357
       mov      edx, edi
       shl      rdx, 4
       lea      r10, bword ptr [rcx+rdx+0x10]
       mov      rcx, r10
       mov      bword ptr [rbp-0x398], rcx
       mov      rdx, r12
       call     CORINFO_HELP_ASSIGN_REF
       xor      ecx, ecx
       mov      r12, bword ptr [rbp-0x398]
       mov      qword ptr [r12+0x08], rcx
       mov      r12, bword ptr [rbp-0x388]
       mov      ecx, dword ptr [rbp-0x2D8]
       mov      dword ptr [r12+0x40], ecx
       lea      r12, bword ptr [r15+0x20]
       lea      eax, [rdi+0x02]
       mov      dword ptr [rbp-0x2DC], eax
       cmp      eax, dword ptr [r12+0x40]
       jl       SHORT G_M000_IG125
 
G_M000_IG124:                ;; offset=0x1240
       jmp      SHORT G_M000_IG126
 
G_M000_IG125:                ;; offset=0x1242
       mov      rcx, r12
       mov      edx, eax
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
 
G_M000_IG126:                ;; offset=0x124D
       mov      rcx, gword ptr [r12]
       lea      edx, [rdi+0x01]
       cmp      edx, dword ptr [rcx+0x08]
       jae      G_M000_IG357
       lea      edx, [rdi+0x01]
       shl      rdx, 4
       lea      r8, bword ptr [rcx+rdx+0x10]
       mov      rcx, r8
       mov      bword ptr [rbp-0x3A0], rcx
       mov      rdx, gword ptr [rbp-0x348]
       call     CORINFO_HELP_ASSIGN_REF
       xor      ecx, ecx
       mov      rax, bword ptr [rbp-0x3A0]
       mov      qword ptr [rax+0x08], rcx
       mov      ecx, dword ptr [rbp-0x2DC]
       mov      dword ptr [r12+0x40], ecx
 
G_M000_IG127:                ;; offset=0x1297
       mov      r13, gword ptr [rbp+0x18]
       lea      rcx, bword ptr [r15+0x20]
       cmp      byte  ptr [r14], r14b
       mov      rcx, gword ptr [rcx]
       cmp      byte  ptr [r14+0x30], 0
       setne    al
       movzx    rax, al
       add      eax, edi
       cmp      eax, dword ptr [rcx+0x08]
       jae      G_M000_IG357
       shl      rax, 4
       lea      rcx, bword ptr [rcx+rax+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Object():System.Object:this]
       mov      rdx, rax
       mov      rcx, 0x7FF9B54EBCC8
       call     [Lokad.Lython.Internal.NullabilityExtensions:RequireNotNull[System.__Canon](System.__Canon):System.__Canon]
       mov      r12, rax
       mov      dword ptr [rsp+0x20], edi
       mov      gword ptr [rsp+0x28], r12
       lea      rcx, [rbp-0xA0]
       mov      qword ptr [rsp+0x30], rcx
       mov      rcx, r15
       mov      rdx, r13
       mov      r8, rbx
       mov      r9, r14
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteNativeCall(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Frontend.ExecutableCallSite,int,System.Object,byref):bool]
       test     eax, eax
       jne      G_M000_IG137
       test     rbx, rbx
       je       G_M000_IG136
       movzx    rcx, byte  ptr [rbp+0x28]
       mov      dword ptr [rsp+0x20], ecx
       mov      rax, bword ptr [rbp+0x40]
       mov      bword ptr [rsp+0x28], rax
       mov      rcx, rbx
       mov      rdx, r14
       mov      r8d, edi
       mov      r9, r12
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryBeginExecutableCall(Lokad.Lython.Frontend.ExecutableCallSite,int,System.Object,bool,byref):bool:this]
       test     eax, eax
       jne      G_M000_IG132
       cmp      byte  ptr [rbp+0x28], 0
       je       SHORT G_M000_IG129
       mov      gword ptr [rsp+0x20], r12
       mov      dword ptr [rsp+0x28], 1
       lea      rdx, [rbp-0x1D8]
       mov      rcx, rbx
       mov      r8, r14
       mov      r9d, edi
 
G_M000_IG128:                ;; offset=0x1366
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteOrdinaryCall(Lokad.Lython.Frontend.ExecutableCallSite,int,System.Object,bool):System.Threading.Tasks.ValueTask:this]
       lea      rcx, [rbp-0x1E8]
       lea      rdx, [rbp-0x1D8]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:WithoutJump(System.Threading.Tasks.ValueTask):System.Threading.Tasks.ValueTask`1[bool]]
       mov      r12, rsi
       mov      rdx, gword ptr [rbp-0x1E8]
       mov      rcx, r12
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rdx, qword ptr [rbp-0x1E0]
       mov      qword ptr [r12+0x08], rdx
       mov      r14, gword ptr [rsi]
       test     r14, r14
       je       G_M000_IG62
       jmp      G_M000_IG342
 
G_M000_IG129:                ;; offset=0x13AF
       mov      gword ptr [rsp+0x20], r12
       xor      edx, edx
       mov      dword ptr [rsp+0x28], edx
       lea      rdx, [rbp-0xB8]
       mov      rcx, rbx
       mov      r8, r14
       mov      r9d, edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteOrdinaryCall(Lokad.Lython.Frontend.ExecutableCallSite,int,System.Object,bool):System.Threading.Tasks.ValueTask:this]
       mov      rdx, gword ptr [rbp-0xB8]
       mov      rdi, rdx
       movsx    rdx, word  ptr [rbp-0xB0]
       mov      r14d, edx
       test     rdi, rdi
       je       G_M000_IG358
 
G_M000_IG130:                ;; offset=0x13EE
       mov      rdx, rdi
       mov      rcx, 0x7FF9B4EB8FA0
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       jne      G_M000_IG340
 
G_M000_IG131:                ;; offset=0x1409
       mov      rcx, rdi
       mov      edx, r14d
       mov      r11, 0x7FF9B4B62D90
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource:GetResult(short):this
       jmp      G_M000_IG358
 
G_M000_IG132:                ;; offset=0x1421
       mov      rax, bword ptr [rbp+0x40]
       mov      r12, gword ptr [rax]
       test     r12, r12
       jne      G_M000_IG333
 
G_M000_IG133:                ;; offset=0x1431
       mov      rax, bword ptr [rbp+0x40]
       mov      rdi, gword ptr [rax]
       test     rdi, rdi
       jne      G_M000_IG336
 
G_M000_IG134:                ;; offset=0x1441
       mov      r12, gword ptr [rax+0x08]
 
G_M000_IG135:                ;; offset=0x1445
       cmp      r12, rbx
       jne      G_M000_IG140
       xor      ecx, ecx
       mov      rax, bword ptr [rbp+0x40]
       mov      qword ptr [rax], rcx
       mov      qword ptr [rax+0x08], rcx
       mov      qword ptr [rax+0x10], rcx
       mov      rdi, r13
       mov      r14, r15
       jmp      G_M000_IG215
 
G_M000_IG136:                ;; offset=0x146A
       mov      gword ptr [rsp+0x20], r12
       lea      rcx, [rbp-0x108]
       mov      qword ptr [rsp+0x28], rcx
       mov      rcx, r15
       mov      rdx, r13
       mov      r8, r14
       mov      r9d, edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteDeferredChild(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Frontend.ExecutableCallSite,int,System.Object,byref):bool]
       test     eax, eax
       je       G_M000_IG97
       cmp      gword ptr [rbp-0x108], 0
       je       G_M000_IG358
       mov      rdx, gword ptr [rbp-0x108]
       xor      rcx, rcx
       mov      rax, bword ptr [rbp+0x40]
       mov      gword ptr [rax], rcx
       lea      rcx, bword ptr [rax+0x08]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rax, bword ptr [rbp+0x40]
       mov      word  ptr [rax+0x10], 0
       mov      byte  ptr [rax+0x12], 1
       jmp      SHORT G_M000_IG140
 
G_M000_IG137:                ;; offset=0x14CC
       cmp      gword ptr [rbp-0xA0], 0
       je       G_M000_IG358
       mov      rdx, gword ptr [rbp-0xA0]
       mov      rcx, 0x7FF9B51DC748
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       mov      rdi, rax
       test     rdi, rdi
       jne      SHORT G_M000_IG141
       mov      rdx, gword ptr [rbp-0xA0]
       mov      rax, rdx
       test     rax, rax
       je       SHORT G_M000_IG139
 
G_M000_IG138:                ;; offset=0x1507
       mov      rcx, 0x7FF9B5479770
       cmp      qword ptr [rax], rcx
       jne      G_M000_IG332
 
G_M000_IG139:                ;; offset=0x151A
       xor      rcx, rcx
       mov      r12, bword ptr [rbp+0x40]
       mov      gword ptr [r12], rcx
       lea      rcx, bword ptr [r12+0x08]
       mov      rdx, rax
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      word  ptr [r12+0x10], 0
       mov      byte  ptr [r12+0x12], 1
 
G_M000_IG140:                ;; offset=0x153F
       mov      rdx, gword ptr [r14+0x18]
       mov      rcx, bword ptr [rbp+0x38]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      dword ptr [rbp-0xA4], 3
       jmp      G_M000_IG366
 
G_M000_IG141:                ;; offset=0x155B
       jmp      G_M000_IG365
 
G_M000_IG142:                ;; offset=0x1560
       mov      rdx, gword ptr [rbp-0x100]
       mov      rcx, 0x7FF9B51DC748
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       mov      rdi, rax
       test     rdi, rdi
       jne      SHORT G_M000_IG145
 
G_M000_IG143:                ;; offset=0x157E
       vmovdqu  xmm0, xmmword ptr [rbp-0x100]
       vmovdqu  xmmword ptr [rbp-0x300], xmm0
 
G_M000_IG144:                ;; offset=0x158E
       lea      r9, [rbp-0x300]
       mov      rdx, rbx
       mov      r8, bword ptr [rbp-0x340]
       mov      rcx, r15
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PublishInstructionResult(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot)]
       jmp      G_M000_IG358
 
G_M000_IG145:                ;; offset=0x15AD
       jmp      G_M000_IG365
 
G_M000_IG146:                ;; offset=0x15B2
       vmovdqu  xmm0, xmmword ptr [rbp-0xF0]
       vmovdqu  xmmword ptr [rbp-0x300], xmm0
 
G_M000_IG147:                ;; offset=0x15C2
       lea      r9, [rbp-0x300]
       mov      rdx, rbx
       mov      r8, bword ptr [rbp-0x340]
       mov      rcx, r15
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PublishInstructionResult(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot)]
       jmp      G_M000_IG358
 
G_M000_IG148:                ;; offset=0x15E1
       cmp      dword ptr [rbp-0x2E0], 0
       je       G_M000_IG46
       mov      rcx, bword ptr [rbp+0x10]
       mov      edx, dword ptr [rcx+0x60]
       add      rcx, 32
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:CanRetireWithoutCleanup(int):bool:this]
       test     eax, eax
       je       G_M000_IG46
       mov      rcx, bword ptr [rbp+0x10]
       mov      rax, gword ptr [rcx]
       mov      rdx, gword ptr [rcx+0x20]
       test     rdx, rdx
       je       SHORT G_M000_IG149
       lea      r8, bword ptr [rdx+0x10]
       mov      edx, dword ptr [rdx+0x08]
       jmp      SHORT G_M000_IG150
 
G_M000_IG149:                ;; offset=0x1620
       xor      r8, r8
       xor      edx, edx
 
G_M000_IG150:                ;; offset=0x1625
       mov      bword ptr [rbp-0x2F0], r8
       mov      dword ptr [rbp-0x2E8], edx
       mov      r10d, dword ptr [rbp-0x2E0]
       mov      dword ptr [rsp+0x20], r10d
       mov      rdx, gword ptr [rbp+0x18]
       mov      gword ptr [rsp+0x28], rdx
       lea      r8, [rbp-0x58]
       mov      qword ptr [rsp+0x30], r8
       lea      rdx, [rbp-0x2F0]
       mov      r8d, dword ptr [rcx+0x10]
       mov      r9d, dword ptr [rcx+0x60]
       mov      rcx, rax
       call     [Lokad.Lython.Runtime.LythonRuntime:TryPrepareIntegerTuple(Lokad.Lython.Frontend.ExecutableCodeObject,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],int,int,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       test     eax, eax
       je       G_M000_IG46
       mov      rcx, bword ptr [rbp+0x10]
       mov      r10d, dword ptr [rbp-0x2E0]
       add      dword ptr [rcx+0x60], r10d
       mov      edx, dword ptr [rbp-0x58]
       mov      dword ptr [rcx+0x10], edx
       jmp      G_M000_IG360
 
G_M000_IG151:                ;; offset=0x168A
       test     rbx, rbx
       je       SHORT G_M000_IG154
       cmp      byte  ptr [rbx+0x108], 0
       jne      SHORT G_M000_IG154
       cmp      gword ptr [rbx+0x88], 0
       jne      SHORT G_M000_IG154
       mov      rcx, bword ptr [rbp+0x10]
       cmp      gword ptr [rcx+0x40], 0
       jne      SHORT G_M000_IG154
       mov      rax, gword ptr [rcx]
       mov      rdx, gword ptr [rcx+0x20]
       test     rdx, rdx
       je       SHORT G_M000_IG152
       lea      r9, bword ptr [rdx+0x10]
       mov      edx, dword ptr [rdx+0x08]
       jmp      SHORT G_M000_IG153
 
G_M000_IG152:                ;; offset=0x16C2
       xor      r9, r9
       xor      edx, edx
 
G_M000_IG153:                ;; offset=0x16C7
       mov      bword ptr [rbp-0x2F0], r9
       mov      dword ptr [rbp-0x2E8], edx
       mov      rdx, gword ptr [rbp+0x18]
       mov      gword ptr [rsp+0x20], rdx
       lea      r9, [rbp-0x50]
       mov      qword ptr [rsp+0x28], r9
       lea      rdx, [rbp-0x2F0]
       mov      r9d, dword ptr [rcx+0x60]
       lea      r8, bword ptr [rcx+0x10]
       mov      rcx, rax
       call     [Lokad.Lython.Runtime.LythonRuntime:TryEvaluateIntegerCallUpdate(Lokad.Lython.Frontend.ExecutableCodeObject,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       test     eax, eax
       jne      G_M000_IG163
 
G_M000_IG154:                ;; offset=0x1706
       mov      r9, bword ptr [rbp-0x340]
       mov      r9d, dword ptr [r9+0x18]
       test     r9d, r9d
       jge      SHORT G_M000_IG155
       mov      edx, r9d
       not      edx
       jmp      SHORT G_M000_IG156
 
G_M000_IG155:                ;; offset=0x171D
       mov      edx, r9d
 
G_M000_IG156:                ;; offset=0x1720
       mov      r8, bword ptr [rbp-0x340]
       mov      r8d, dword ptr [r8+0x1C]
       cmp      r8d, 51
       ja       SHORT G_M000_IG160
 
G_M000_IG157:                ;; offset=0x1731
       mov      rax, 0x7FFFFFFFFF9FF
       bt       rax, r8
       jb       SHORT G_M000_IG160
 
G_M000_IG158:                ;; offset=0x1741
       test     r9d, r9d
       jge      SHORT G_M000_IG159
       not      r9d
 
G_M000_IG159:                ;; offset=0x1749
       jmp      SHORT G_M000_IG161
 
G_M000_IG160:                ;; offset=0x174B
       mov      r9, bword ptr [rbp-0x340]
       mov      r9d, dword ptr [r9+0x14]
 
G_M000_IG161:                ;; offset=0x1756
       cmp      edx, r9d
       jne      G_M000_IG46
 
G_M000_IG162:                ;; offset=0x175F
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdi, gword ptr [rcx+0x08]
       mov      rcx, bword ptr [rbp-0x340]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LocalSlot():int:this]
       cmp      eax, dword ptr [rdi+0x08]
       jae      G_M000_IG357
       mov      ecx, eax
       shl      rcx, 4
       cmp      gword ptr [rdi+rcx+0x10], 0
       jne      G_M000_IG358
       jmp      G_M000_IG293
 
G_M000_IG163:                ;; offset=0x1794
       mov      rcx, bword ptr [rbp+0x10]
       mov      r9d, dword ptr [rcx+0x10]
       cmp      r9d, edi
       jae      G_M000_IG357
       shl      r9, 5
       mov      rax, gword ptr [rbp-0x338]
       lea      r8, bword ptr [rax+r9+0x10]
       mov      r14, gword ptr [rbp-0x50]
       mov      rdi, qword ptr [rbp-0x48]
       mov      r15d, dword ptr [r8+0x18]
       test     r15d, r15d
       jge      SHORT G_M000_IG164
       mov      gword ptr [rbp-0x300], r14
       mov      qword ptr [rbp-0x2F8], rdi
       lea      r9, [rbp-0x300]
       mov      rdx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CompleteResultConsumer(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot)]
       jmp      G_M000_IG358
 
G_M000_IG164:                ;; offset=0x17E9
       lea      r13, bword ptr [rcx+0x20]
       mov      edx, dword ptr [r8+0x1C]
       cmp      edx, 51
       ja       SHORT G_M000_IG167
 
G_M000_IG165:                ;; offset=0x17F6
       mov      r9, 0x7FFFFFFFFF9FF
       bt       r9, rdx
       jb       SHORT G_M000_IG167
 
G_M000_IG166:                ;; offset=0x1806
       mov      r12d, r15d
       jmp      SHORT G_M000_IG168
 
G_M000_IG167:                ;; offset=0x180B
       mov      r12d, dword ptr [r8+0x14]
 
G_M000_IG168:                ;; offset=0x180F
       cmp      r15d, dword ptr [r13+0x40]
       jge      SHORT G_M000_IG169
       mov      rcx, r13
       mov      edx, r15d
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
 
G_M000_IG169:                ;; offset=0x1821
       mov      rdx, gword ptr [r13]
       cmp      r12d, dword ptr [rdx+0x08]
       jae      G_M000_IG357
       mov      r8d, r12d
       shl      r8, 4
       lea      r12, bword ptr [rdx+r8+0x10]
       mov      rcx, r12
       mov      rdx, r14
       call     CORINFO_HELP_ASSIGN_REF
       mov      qword ptr [r12+0x08], rdi
       mov      dword ptr [r13+0x40], r15d
       jmp      G_M000_IG358
 
G_M000_IG170:                ;; offset=0x1854
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rcx+0x20]
       mov      r8, bword ptr [rbp-0x340]
       mov      r8d, dword ptr [r8+0x10]
       mov      rax, bword ptr [rbp-0x340]
       mov      eax, dword ptr [rax+0x08]
       test     rdx, rdx
       je       SHORT G_M000_IG171
       mov      r10d, r8d
       mov      r9d, eax
       add      r10, r9
       mov      r9d, dword ptr [rdx+0x08]
       cmp      r10, r9
       ja       G_M000_IG306
       shl      r8, 4
       lea      rdx, bword ptr [rdx+r8+0x10]
       jmp      SHORT G_M000_IG172
 
G_M000_IG171:                ;; offset=0x1897
       or       r8d, eax
       jne      G_M000_IG306
       xor      rdx, rdx
       xor      eax, eax
 
G_M000_IG172:                ;; offset=0x18A4
       mov      bword ptr [rbp-0x2F0], rdx
       mov      dword ptr [rbp-0x2E8], eax
       lea      rcx, [rbp-0x2F0]
       mov      rdx, gword ptr [rbp+0x18]
       mov      rdx, gword ptr [rdx+0xA0]
       mov      r8, bword ptr [rbp-0x340]
       mov      r8, gword ptr [r8]
       call     [Lokad.Lython.Runtime.LythonRuntime:ReverseAssignmentValues(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],Lokad.Lython.Runtime.ExecutionState,Lokad.Lython.LythonSourceSpan)]
       jmp      G_M000_IG358
 
G_M000_IG173:                ;; offset=0x18D8
       mov      rcx, bword ptr [rbp+0x10]
       lea      r8, bword ptr [rcx+0x20]
       cmp      r14d, 51
       ja       SHORT G_M000_IG177
 
G_M000_IG174:                ;; offset=0x18E6
       mov      rdx, 0x7FFFFFFFFF9FF
       bt       rdx, r14
       jb       SHORT G_M000_IG177
 
G_M000_IG175:                ;; offset=0x18F6
       mov      rdx, bword ptr [rbp-0x340]
       mov      edi, dword ptr [rdx+0x18]
       test     edi, edi
       jge      SHORT G_M000_IG176
       not      edi
 
G_M000_IG176:                ;; offset=0x1906
       jmp      SHORT G_M000_IG178
 
G_M000_IG177:                ;; offset=0x1908
       mov      rdx, bword ptr [rbp-0x340]
       mov      edi, dword ptr [rdx+0x14]
 
G_M000_IG178:                ;; offset=0x1912
       mov      rdx, bword ptr [rbp-0x340]
       mov      edx, dword ptr [rdx+0x18]
       test     edx, edx
       jge      SHORT G_M000_IG179
       mov      r9d, edx
       not      r9d
       jmp      SHORT G_M000_IG180
 
G_M000_IG179:                ;; offset=0x1928
       mov      r9d, edx
 
G_M000_IG180:                ;; offset=0x192B
       lea      rdx, [rbp-0x70]
       mov      rcx, r8
       mov      r8d, edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:TakeSlotValue(int,int):Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:this]
       mov      rcx, bword ptr [rbp+0x10]
       mov      r8, gword ptr [rcx+0x20]
       test     r8, r8
       je       SHORT G_M000_IG181
       lea      rdx, bword ptr [r8+0x10]
       mov      r8d, dword ptr [r8+0x08]
       jmp      SHORT G_M000_IG182
 
G_M000_IG181:                ;; offset=0x1952
       xor      rdx, rdx
       xor      r8d, r8d
 
G_M000_IG182:                ;; offset=0x1957
       mov      r9, rbx
       test     r9, r9
       jne      SHORT G_M000_IG183
       mov      rdi, gword ptr [rbp+0x18]
       mov      r9, rdi
 
G_M000_IG183:                ;; offset=0x1966
       mov      rdi, gword ptr [rbp+0x18]
       mov      r9, gword ptr [r9+0xA0]
       mov      rax, bword ptr [rbp-0x340]
       mov      eax, dword ptr [rax+0x10]
       cmp      eax, r8d
       jae      G_M000_IG357
       mov      r8d, eax
       shl      r8, 4
       add      r8, rdx
 
G_M000_IG184:                ;; offset=0x198E
       vmovdqu  xmm0, xmmword ptr [rbp-0x70]
       vmovdqu  xmmword ptr [rbp-0x300], xmm0
 
G_M000_IG185:                ;; offset=0x199B
       mov      rcx, r8
       lea      r8, [rbp-0x300]
       mov      rdx, bword ptr [rbp-0x340]
       call     [Lokad.Lython.Runtime.LythonRuntime:StoreDefaultResult(byref,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot,Lokad.Lython.Runtime.ExecutionState)]
       jmp      G_M000_IG358
 
G_M000_IG186:                ;; offset=0x19B7
       mov      rcx, bword ptr [rbp+0x10]
       mov      rax, gword ptr [rcx]
       mov      r14, gword ptr [rax+0x30]
       mov      rcx, bword ptr [rbp-0x340]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ConstantIndex():int:this]
       cmp      eax, dword ptr [r14+0x08]
       jae      G_M000_IG357
       mov      edx, eax
       mov      rdx, gword ptr [r14+8*rdx+0x10]
       mov      rcx, rdx
       test     rcx, rcx
       je       SHORT G_M000_IG188
 
G_M000_IG187:                ;; offset=0x19E8
       mov      rax, 0x7FF9B52755B0
       cmp      qword ptr [rcx], rax
       jne      G_M000_IG305
 
G_M000_IG188:                ;; offset=0x19FB
       mov      r14, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [r14+0x20]
       mov      r8, bword ptr [rbp-0x340]
       mov      r8d, dword ptr [r8+0x1C]
       mov      r9d, r8d
       cmp      r9d, 51
       ja       SHORT G_M000_IG192
 
G_M000_IG189:                ;; offset=0x1A17
       mov      rax, 0x7FFFFFFFFF9FF
       bt       rax, r9
       jb       SHORT G_M000_IG192
 
G_M000_IG190:                ;; offset=0x1A27
       mov      r9, bword ptr [rbp-0x340]
       mov      r9d, dword ptr [r9+0x18]
       test     r9d, r9d
       jge      SHORT G_M000_IG191
       not      r9d
 
G_M000_IG191:                ;; offset=0x1A3A
       jmp      SHORT G_M000_IG193
 
G_M000_IG192:                ;; offset=0x1A3C
       mov      r9, bword ptr [rbp-0x340]
       mov      r9d, dword ptr [r9+0x14]
 
G_M000_IG193:                ;; offset=0x1A47
       mov      rax, bword ptr [rbp-0x340]
       mov      eax, dword ptr [rax+0x18]
       test     eax, eax
       jge      SHORT G_M000_IG194
       mov      r10d, eax
       not      r10d
       jmp      SHORT G_M000_IG195
 
G_M000_IG194:                ;; offset=0x1A5D
       mov      r10d, eax
 
G_M000_IG195:                ;; offset=0x1A60
       cmp      r8d, 51
       ja       SHORT G_M000_IG200
 
G_M000_IG196:                ;; offset=0x1A66
       mov      r11, 0x7FFFFFFFFF9FF
       bt       r11, r8
       jb       SHORT G_M000_IG200
 
G_M000_IG197:                ;; offset=0x1A76
       test     eax, eax
       jge      SHORT G_M000_IG198
       mov      r8d, eax
       not      r8d
       jmp      SHORT G_M000_IG199
 
G_M000_IG198:                ;; offset=0x1A82
       mov      r8d, eax
 
G_M000_IG199:                ;; offset=0x1A85
       jmp      SHORT G_M000_IG201
 
G_M000_IG200:                ;; offset=0x1A87
       mov      r8, bword ptr [rbp-0x340]
       mov      r8d, dword ptr [r8+0x14]
 
G_M000_IG201:                ;; offset=0x1A92
       sub      r10d, r8d
       test     rdx, rdx
       je       SHORT G_M000_IG202
       mov      r8d, r9d
       mov      eax, r10d
       add      r8, rax
       mov      eax, dword ptr [rdx+0x08]
       cmp      r8, rax
       ja       G_M000_IG306
       mov      r9d, r9d
       shl      r9, 4
       lea      rdx, bword ptr [rdx+r9+0x10]
       jmp      SHORT G_M000_IG203
 
G_M000_IG202:                ;; offset=0x1ABD
       or       r9d, r10d
       jne      G_M000_IG306
       xor      rdx, rdx
       xor      r10d, r10d
 
G_M000_IG203:                ;; offset=0x1ACB
       mov      r8, bword ptr [rbp-0x340]
       cmp      dword ptr [r8+0x0C], 0
       setne    r8b
       movzx    r8, r8b
       mov      r9, rbx
       test     r9, r9
       jne      SHORT G_M000_IG204
       mov      rdi, gword ptr [rbp+0x18]
       mov      r9, rdi
 
G_M000_IG204:                ;; offset=0x1AEE
       mov      rdi, gword ptr [rbp+0x18]
       mov      bword ptr [rbp-0x2F0], rdx
       mov      dword ptr [rbp-0x2E8], r10d
       mov      rdx, bword ptr [rbp-0x340]
       mov      rdx, gword ptr [rdx]
       mov      gword ptr [rsp+0x20], rdx
       lea      rdx, [rbp-0x2F0]
       call     [Lokad.Lython.Runtime.LythonRuntime:StartExecutableDefaults(Lokad.Lython.Frontend.FunctionParameterLayout,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],bool,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan)]
       lea      rdx, bword ptr [r14+0x20]
       mov      rcx, bword ptr [rbp-0x340]
       mov      ecx, dword ptr [rcx+0x18]
       test     ecx, ecx
       jge      SHORT G_M000_IG205
       not      ecx
 
G_M000_IG205:                ;; offset=0x1B30
       mov      dword ptr [rdx+0x40], ecx
       jmp      G_M000_IG358
 
G_M000_IG206:                ;; offset=0x1B38
       mov      rdi, gword ptr [rbp+0x18]
       test     rbx, rbx
       je       G_M000_IG210
       mov      r14, bword ptr [rbp+0x10]
       mov      r15d, dword ptr [r14+0x60]
       mov      rcx, bword ptr [rbp-0x340]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       cmp      r15d, eax
       jne      G_M000_IG210
       mov      rcx, gword ptr [r14+0x20]
       mov      rax, bword ptr [rbp-0x340]
       mov      eax, dword ptr [rax+0x10]
       cmp      eax, dword ptr [rcx+0x08]
       jae      G_M000_IG357
       shl      rax, 4
       mov      r15, gword ptr [rcx+rax+0x10]
       test     r15, r15
       je       G_M000_IG210
 
G_M000_IG207:                ;; offset=0x1B8C
       mov      rcx, 0x7FF9B54EB830
       cmp      qword ptr [r15], rcx
       jne      G_M000_IG210
 
G_M000_IG208:                ;; offset=0x1B9F
       mov      rcx, r15
       call     [Lokad.Lython.Runtime.PyIteration+Cursor:get_NativeCsvSource():Lokad.Lython.Runtime.LythonRuntime+CsvRecordSource:this]
       test     rax, rax
       je       G_M000_IG210
       cmp      gword ptr [rax+0x20], 0
       je       G_M000_IG210
       mov      rdx, bword ptr [rbp-0x340]
       mov      bword ptr [rsp+0x20], rdx
       movzx    rdx, byte  ptr [rbp+0x28]
       mov      dword ptr [rsp+0x28], edx
       lea      rdx, [rbp-0x168]
       mov      rcx, rbx
       mov      r8, rax
       mov      r9, r15
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:AdvanceCsvUnpack(Lokad.Lython.Runtime.LythonRuntime+CsvRecordSource,Lokad.Lython.Runtime.PyIteration+Cursor,byref,bool):System.Threading.Tasks.ValueTask`1[bool]:this]
       mov      r15, rsi
       mov      rdx, gword ptr [rbp-0x168]
       mov      rcx, r15
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rdx, qword ptr [rbp-0x160]
       mov      qword ptr [r15+0x08], rdx
       mov      r15, gword ptr [rsi]
       test     r15, r15
       je       G_M000_IG228
       jmp      G_M000_IG325
 
G_M000_IG209:                ;; offset=0x1C14
       mov      rdi, gword ptr [rbp+0x18]
       mov      r14, bword ptr [rbp+0x10]
       mov      rcx, r14
       mov      rdx, rdi
       mov      r8, rbx
       mov      r9, bword ptr [rbp-0x340]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteDictionaryLoop(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       test     eax, eax
       jne      G_M000_IG215
 
G_M000_IG210:                ;; offset=0x1C3A
       mov      r14, bword ptr [rbp+0x10]
       mov      rdi, gword ptr [rbp+0x18]
       mov      rdx, bword ptr [rbp-0x340]
       mov      edx, dword ptr [rdx+0x10]
       lea      rcx, bword ptr [r14+0x20]
       lea      r8, [rbp-0x88]
       lea      r9, [rbp-0x98]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:TryAdvanceNativeIteration(int,byref,byref):bool:this]
       test     eax, eax
       jne      G_M000_IG214
       test     rbx, rbx
       je       G_M000_IG97
       cmp      byte  ptr [rbp+0x28], 0
       je       SHORT G_M000_IG213
       mov      r8, bword ptr [rbp-0x340]
 
G_M000_IG211:                ;; offset=0x1C82
       vmovdqu  ymm0, ymmword ptr [r8]
       vmovdqu  ymmword ptr [rbp-0x320], ymm0
 
G_M000_IG212:                ;; offset=0x1C8F
       lea      r8, [rbp-0x320]
       lea      rdx, [rbp-0x1F8]
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteForNextAsync(Lokad.Lython.Frontend.ExecutableInstruction):System.Threading.Tasks.ValueTask`1[bool]:this]
       mov      r15, rsi
       mov      rdx, gword ptr [rbp-0x1F8]
       mov      rcx, r15
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rdx, qword ptr [rbp-0x1F0]
       mov      qword ptr [r15+0x08], rdx
       mov      r15, gword ptr [rsi]
       test     r15, r15
       je       G_M000_IG228
       jmp      G_M000_IG328
 
G_M000_IG213:                ;; offset=0x1CD4
       mov      rcx, rbx
       mov      rdx, bword ptr [rbp-0x340]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteForNext(byref):bool:this]
       mov      dword ptr [rbp-0x3C], eax
       jmp      G_M000_IG358
 
G_M000_IG214:                ;; offset=0x1CEC
       cmp      byte  ptr [rbp-0x88], 0
       jne      SHORT G_M000_IG216
       mov      rdx, bword ptr [rbp-0x340]
       mov      edx, dword ptr [rdx+0x10]
       lea      rcx, bword ptr [r14+0x20]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
       mov      rcx, bword ptr [rbp-0x340]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_TargetIndex():int:this]
       mov      dword ptr [r14+0x10], eax
 
G_M000_IG215:                ;; offset=0x1D1A
       mov      dword ptr [rbp-0x3C], 1
       jmp      G_M000_IG358
 
G_M000_IG216:                ;; offset=0x1D26
       vmovdqu  xmm0, xmmword ptr [rbp-0x98]
       vmovdqu  xmmword ptr [rbp-0x300], xmm0
 
G_M000_IG217:                ;; offset=0x1D36
       lea      r9, [rbp-0x300]
       mov      rdx, rbx
       mov      r8, bword ptr [rbp-0x340]
       mov      rcx, r14
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PublishInstructionResult(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot)]
       jmp      G_M000_IG358
 
G_M000_IG218:                ;; offset=0x1D55
       mov      r14, bword ptr [rbp+0x10]
       lea      r15, bword ptr [r14+0x20]
       mov      rdx, bword ptr [rbp-0x340]
       mov      r8d, dword ptr [rdx+0x10]
       mov      rcx, gword ptr [r14]
       mov      rdx, gword ptr [r14+0x20]
       test     rdx, rdx
       je       SHORT G_M000_IG219
       lea      r9, bword ptr [rdx+0x10]
       mov      edx, dword ptr [rdx+0x08]
       jmp      SHORT G_M000_IG220
 
G_M000_IG219:                ;; offset=0x1D7D
       xor      r9, r9
       xor      edx, edx
 
G_M000_IG220:                ;; offset=0x1D82
       mov      bword ptr [rbp-0x2F0], r9
       mov      dword ptr [rbp-0x2E8], edx
       xor      edx, edx
       mov      dword ptr [rsp+0x20], edx
       mov      rdi, gword ptr [rbp+0x18]
       mov      gword ptr [rsp+0x28], rdi
       lea      rdx, [rbp-0x2F0]
       mov      r9d, dword ptr [r14+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime:ReadExecutableOperand(Lokad.Lython.Frontend.ExecutableCodeObject,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],int,int,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):System.Object]
       mov      r13, rax
       mov      rcx, bword ptr [rbp-0x340]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       mov      r8d, eax
       mov      rcx, bword ptr [rbp-0x340]
       mov      r9d, dword ptr [rcx+0x18]
       test     r9d, r9d
       jge      SHORT G_M000_IG221
       not      r9d
 
G_M000_IG221:                ;; offset=0x1DD5
       mov      rcx, bword ptr [rbp-0x340]
       mov      rcx, gword ptr [rcx]
       mov      gword ptr [rsp+0x20], rcx
       mov      rcx, r15
       mov      rdx, r13
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:TryPrepareNativeIteration(System.Object,int,int,Lokad.Lython.LythonSourceSpan):bool:this]
       test     eax, eax
       jne      G_M000_IG358
       test     rbx, rbx
       je       G_M000_IG97
       cmp      byte  ptr [rbp+0x28], 0
       je       SHORT G_M000_IG224
       mov      r8, bword ptr [rbp-0x340]
 
G_M000_IG222:                ;; offset=0x1E0E
       vmovdqu  ymm0, ymmword ptr [r8]
       vmovdqu  ymmword ptr [rbp-0x320], ymm0
 
G_M000_IG223:                ;; offset=0x1E1B
       lea      r8, [rbp-0x320]
       lea      rdx, [rbp-0x208]
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteGetIteratorAsync(Lokad.Lython.Frontend.ExecutableInstruction):System.Threading.Tasks.ValueTask:this]
       lea      rcx, [rbp-0x218]
       lea      rdx, [rbp-0x208]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:WithoutJump(System.Threading.Tasks.ValueTask):System.Threading.Tasks.ValueTask`1[bool]]
       mov      r15, rsi
       mov      rdx, gword ptr [rbp-0x218]
       mov      rcx, r15
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rdx, qword ptr [rbp-0x210]
       mov      qword ptr [r15+0x08], rdx
       mov      r15, gword ptr [rsi]
       test     r15, r15
       je       G_M000_IG62
       jmp      G_M000_IG345
 
G_M000_IG224:                ;; offset=0x1E74
       mov      r14, bword ptr [rbp+0x10]
       mov      rdi, gword ptr [rbp+0x18]
       mov      rcx, rbx
       mov      rdx, bword ptr [rbp-0x340]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteValueOperation(byref):this]
       jmp      G_M000_IG358
 
G_M000_IG225:                ;; offset=0x1E91
       mov      r14, bword ptr [rbp+0x10]
       test     rbx, rbx
       je       G_M000_IG97
       cmp      byte  ptr [rbp+0x28], 0
       je       SHORT G_M000_IG230
       mov      r8, bword ptr [rbp-0x340]
 
G_M000_IG226:                ;; offset=0x1EAB
       vmovdqu  ymm0, ymmword ptr [r8]
       vmovdqu  ymmword ptr [rbp-0x320], ymm0
 
G_M000_IG227:                ;; offset=0x1EB8
       lea      r8, [rbp-0x320]
       lea      rdx, [rbp-0x228]
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteContextManagerAsync(Lokad.Lython.Frontend.ExecutableInstruction):System.Threading.Tasks.ValueTask`1[bool]:this]
       mov      r15, rsi
       mov      rdx, gword ptr [rbp-0x228]
       mov      rcx, r15
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rdx, qword ptr [rbp-0x220]
       mov      qword ptr [r15+0x08], rdx
       mov      r15, gword ptr [rsi]
       test     r15, r15
       jne      G_M000_IG322
 
G_M000_IG228:                ;; offset=0x1EF8
       mov      r14, bword ptr [rbp+0x10]
       mov      rcx, rsi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ConsumeOperation(byref):bool]
       mov      dword ptr [rbp-0x3C], eax
       jmp      G_M000_IG358
 
G_M000_IG229:                ;; offset=0x1F0D
       mov      r14, bword ptr [rbp+0x10]
       test     rbx, rbx
       je       G_M000_IG97
 
G_M000_IG230:                ;; offset=0x1F1A
       mov      rcx, rbx
       mov      rdx, bword ptr [rbp-0x340]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteStructure(byref):bool:this]
       mov      dword ptr [rbp-0x3C], eax
       jmp      G_M000_IG358
 
G_M000_IG231:                ;; offset=0x1F32
       mov      r14, bword ptr [rbp+0x10]
       test     rbx, rbx
       je       SHORT G_M000_IG232
       mov      rcx, rbx
       mov      rdx, bword ptr [rbp-0x340]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryStageUnpackedFrameReturn(byref):bool:this]
       test     eax, eax
       jne      G_M000_IG263
 
G_M000_IG232:                ;; offset=0x1F53
       cmp      dword ptr [rbp-0x2E0], 0
       je       SHORT G_M000_IG233
       mov      rcx, r14
       mov      rdx, bword ptr [rbp-0x340]
       mov      r8d, dword ptr [rbp-0x2E0]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CanForwardFixedReturn(byref,byref,int):bool]
       test     eax, eax
       jne      SHORT G_M000_IG234
 
G_M000_IG233:                ;; offset=0x1F77
       lea      r15, bword ptr [r14+0x20]
       mov      rcx, bword ptr [rbp-0x340]
       mov      r13d, dword ptr [rcx+0x10]
       mov      rcx, bword ptr [rbp-0x340]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ItemCount():int:this]
       mov      r8d, eax
       mov      rdi, gword ptr [rbp+0x18]
       mov      gword ptr [rsp+0x20], rdi
       mov      edx, r13d
       mov      rcx, r15
       mov      r9, bword ptr [rbp-0x340]
       mov      r9, gword ptr [r9]
       call     [Lokad.Lython.Runtime.LythonRuntime:CreateTupleFromStack(byref,int,int,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):Lokad.Lython.Runtime.PyTuple]
       mov      gword ptr [rbp-0x300], rax
       xor      r9d, r9d
       mov      qword ptr [rbp-0x2F8], r9
       lea      r9, [rbp-0x300]
       mov      rdx, rbx
       mov      r8, bword ptr [rbp-0x340]
       mov      rcx, r14
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PublishInstructionResult(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot)]
       jmp      G_M000_IG358
 
G_M000_IG234:                ;; offset=0x1FE5
       mov      rdi, gword ptr [rbp+0x18]
       mov      r9, bword ptr [rbp-0x390]
       mov      bword ptr [rbp-0x2F0], r9
       mov      r8d, dword ptr [rbp-0x2E0]
       mov      dword ptr [rbp-0x2E8], r8d
       lea      r9, [rbp-0x2F0]
       mov      rdx, rdi
       mov      r8, bword ptr [rbp-0x340]
       mov      rcx, r14
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CopyFixedReturn(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot])]
       mov      dword ptr [rbp-0xA4], 2
       jmp      G_M000_IG366
 
G_M000_IG235:                ;; offset=0x202E
       mov      r14, bword ptr [rbp+0x10]
       mov      r9, rbx
       test     r9, r9
       jne      SHORT G_M000_IG236
       mov      rdi, gword ptr [rbp+0x18]
       mov      r9, rdi
 
G_M000_IG236:                ;; offset=0x2041
       mov      rcx, r14
       mov      rdx, rbx
       mov      r8, bword ptr [rbp-0x340]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteFormattedInstruction(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):bool]
       test     eax, eax
       jne      G_M000_IG358
       test     rbx, rbx
       je       G_M000_IG97
       cmp      byte  ptr [rbp+0x28], 0
       je       SHORT G_M000_IG239
       mov      r8, bword ptr [rbp-0x340]
 
G_M000_IG237:                ;; offset=0x2072
       vmovdqu  ymm0, ymmword ptr [r8]
       vmovdqu  ymmword ptr [rbp-0x320], ymm0
 
G_M000_IG238:                ;; offset=0x207F
       lea      r8, [rbp-0x320]
       lea      rdx, [rbp-0x178]
       mov      rcx, rbx
       mov      r9d, 1
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteFormattedValueAsync(Lokad.Lython.Frontend.ExecutableInstruction,bool):System.Threading.Tasks.ValueTask:this]
       lea      rcx, [rbp-0x188]
       lea      rdx, [rbp-0x178]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:WithoutJump(System.Threading.Tasks.ValueTask):System.Threading.Tasks.ValueTask`1[bool]]
       mov      r15, rsi
       mov      rdx, gword ptr [rbp-0x188]
       mov      rcx, r15
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rdx, qword ptr [rbp-0x180]
       mov      qword ptr [r15+0x08], rdx
       mov      r15, gword ptr [rsi]
       test     r15, r15
       je       G_M000_IG62
       jmp      G_M000_IG302
 
G_M000_IG239:                ;; offset=0x20DE
       mov      r8, bword ptr [rbp-0x340]
 
G_M000_IG240:                ;; offset=0x20E5
       vmovdqu  ymm0, ymmword ptr [r8]
       vmovdqu  ymmword ptr [rbp-0x320], ymm0
 
G_M000_IG241:                ;; offset=0x20F2
       lea      r8, [rbp-0x320]
       lea      rdx, [rbp-0xB8]
       mov      rcx, rbx
       xor      r9d, r9d
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteFormattedValueAsync(Lokad.Lython.Frontend.ExecutableInstruction,bool):System.Threading.Tasks.ValueTask:this]
       mov      r15, gword ptr [rbp-0xB8]
       movsx    r13, word  ptr [rbp-0xB0]
       test     r15, r15
       je       G_M000_IG358
 
G_M000_IG242:                ;; offset=0x2124
       mov      rdx, r15
       mov      rcx, 0x7FF9B4EB8FA0
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       jne      G_M000_IG300
 
G_M000_IG243:                ;; offset=0x213F
       mov      rcx, r15
       mov      edx, r13d
       mov      r11, 0x7FF9B4B62D28
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource:GetResult(short):this
       jmp      G_M000_IG358
 
G_M000_IG244:                ;; offset=0x2157
       test     rbx, rbx
       je       G_M000_IG97
       cmp      byte  ptr [rbp+0x28], 0
       jne      G_M000_IG258
       cmp      gword ptr [rbx+0x68], 0
       jne      G_M000_IG250
       mov      r15, bword ptr [rbp+0x10]
       lea      rcx, bword ptr [r15+0x20]
       mov      rdx, bword ptr [rbp-0x340]
       mov      edx, dword ptr [rdx+0x10]
       mov      r8d, r14d
       cmp      r8d, 51
       ja       SHORT G_M000_IG248
 
G_M000_IG245:                ;; offset=0x2190
       mov      rax, 0x7FFFFFFFFF9FF
       bt       rax, r8
       jb       SHORT G_M000_IG248
 
G_M000_IG246:                ;; offset=0x21A0
       mov      r8, bword ptr [rbp-0x340]
       mov      r8d, dword ptr [r8+0x18]
       test     r8d, r8d
       jge      SHORT G_M000_IG247
       not      r8d
 
G_M000_IG247:                ;; offset=0x21B3
       jmp      SHORT G_M000_IG249
 
G_M000_IG248:                ;; offset=0x21B5
       mov      r8, bword ptr [rbp-0x340]
       mov      r8d, dword ptr [r8+0x14]
 
G_M000_IG249:                ;; offset=0x21C0
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:TakeValue(int,int):System.Object:this]
       mov      r14, rax
       mov      rcx, 0x7FF9B4C22560
       mov      edx, 1
       call     CORINFO_HELP_NEWARR_1_PTR
       mov      r13, rax
       lea      rcx, bword ptr [r13+0x10]
       mov      rdx, r14
       call     CORINFO_HELP_ASSIGN_REF
       mov      rdx, bword ptr [rbp-0x340]
       mov      rdx, gword ptr [rdx]
       mov      rcx, r13
       mov      r8, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime:Iter(System.Object[],Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):System.Object]
       mov      r14, rax
       mov      rcx, 0x7FF9B54EDCD8
       call     CORINFO_HELP_NEWSFAST
       mov      r13, rax
       mov      rcx, bword ptr [rbp-0x340]
       mov      r12, gword ptr [rcx]
       lea      rcx, bword ptr [r13+0x08]
       mov      rdx, r14
       call     CORINFO_HELP_ASSIGN_REF
       lea      rcx, bword ptr [r13+0x10]
       mov      rdx, rbx
       call     CORINFO_HELP_ASSIGN_REF
       lea      rcx, bword ptr [r13+0x18]
       mov      rdx, r12
       call     CORINFO_HELP_ASSIGN_REF
       mov      rcx, 0x19F7FC01F50
       mov      rdx, gword ptr [rcx]
       lea      rcx, bword ptr [r13+0x20]
       call     CORINFO_HELP_ASSIGN_REF
       lea      rcx, bword ptr [rbx+0x68]
       mov      rdx, r13
       call     CORINFO_HELP_ASSIGN_REF
 
G_M000_IG250:                ;; offset=0x2267
       mov      rcx, gword ptr [rbx+0x68]
       mov      r8, gword ptr [rbx+0x58]
       mov      r9, gword ptr [rbx+0x60]
       cmp      byte  ptr [rcx], cl
       xor      edx, edx
       mov      dword ptr [rsp+0x20], edx
       lea      rdx, [rbp-0x2B8]
       call     [Lokad.Lython.Runtime.LythonRuntime+GeneratorDelegation:AdvanceAsync(System.Object,Lokad.Lython.Runtime.LythonRuntimeException,bool):System.Threading.Tasks.ValueTask`1[Lokad.Lython.Runtime.PyIterationResult]:this]
       mov      r14, gword ptr [rbp-0x2B8]
       movsx    r13, word  ptr [rbp-0x2B0]
       test     r14, r14
       je       SHORT G_M000_IG254
       mov      rdx, r14
       mov      rcx, 0x7FF9B54F3758
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       mov      r12, rax
       test     r12, r12
       jne      SHORT G_M000_IG251
       lea      rdx, [rbp-0x2C8]
       mov      rcx, r14
       mov      r8d, r13d
       mov      r11, 0x7FF9B4B62D50
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[Lokad.Lython.Runtime.PyIterationResult]:GetResult(short):Lokad.Lython.Runtime.PyIterationResult:this
       jmp      SHORT G_M000_IG255
 
G_M000_IG251:                ;; offset=0x22D2
       mov      ecx, dword ptr [r12+0x34]
       and      ecx, 0x11000000
       cmp      ecx, 0x1000000
       jne      G_M000_IG315
 
G_M000_IG252:                ;; offset=0x22E9
       vmovdqu  xmm0, xmmword ptr [r12+0x38]
       vmovdqu  xmmword ptr [rbp-0x2C8], xmm0
 
G_M000_IG253:                ;; offset=0x22F8
       jmp      SHORT G_M000_IG255
 
G_M000_IG254:                ;; offset=0x22FA
       vmovdqu  xmm0, xmmword ptr [rbp-0x2A8]
       vmovdqu  xmmword ptr [rbp-0x2C8], xmm0
 
G_M000_IG255:                ;; offset=0x230A
       mov      r8, bword ptr [rbp-0x340]
 
G_M000_IG256:                ;; offset=0x2311
       vmovdqu  ymm0, ymmword ptr [r8]
       vmovdqu  ymmword ptr [rbp-0x320], ymm0
 
G_M000_IG257:                ;; offset=0x231E
       lea      r8, [rbp-0x320]
       lea      rdx, [rbp-0x2C8]
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CompleteDelegatedStep(Lokad.Lython.Runtime.PyIterationResult,Lokad.Lython.Frontend.ExecutableInstruction):this]
       jmp      SHORT G_M000_IG262
 
G_M000_IG258:                ;; offset=0x2337
       mov      r8, bword ptr [rbp-0x340]
 
G_M000_IG259:                ;; offset=0x233E
       vmovdqu  ymm0, ymmword ptr [r8]
       vmovdqu  ymmword ptr [rbp-0x320], ymm0
 
G_M000_IG260:                ;; offset=0x234B
       lea      r8, [rbp-0x320]
       lea      rdx, [rbp-0x198]
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteDelegationAsync(Lokad.Lython.Frontend.ExecutableInstruction):System.Threading.Tasks.ValueTask`1[bool]:this]
       mov      r14, rsi
       mov      rdx, gword ptr [rbp-0x198]
       mov      rcx, r14
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rdx, qword ptr [rbp-0x190]
       mov      qword ptr [r14+0x08], rdx
       mov      r14, gword ptr [rsi]
       test     r14, r14
       jne      G_M000_IG312
 
G_M000_IG261:                ;; offset=0x238B
       mov      rcx, rsi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ConsumeOperation(byref):bool]
 
G_M000_IG262:                ;; offset=0x2394
       cmp      byte  ptr [rbx+0x101], 0
       je       G_M000_IG358
       mov      rdx, gword ptr [rbx+0x70]
       test     rdx, rdx
       je       SHORT G_M000_IG263
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryBufferYield(System.Object):bool:this]
       test     eax, eax
       jne      G_M000_IG360
 
G_M000_IG263:                ;; offset=0x23BB
       mov      r15, bword ptr [rbp+0x10]
       mov      dword ptr [rbp-0xA4], 1
       jmp      G_M000_IG366
 
G_M000_IG264:                ;; offset=0x23CE
       mov      r15, bword ptr [rbp+0x10]
       lea      r14, bword ptr [r15+0x20]
       mov      rcx, bword ptr [rbp-0x340]
       mov      r13d, dword ptr [rcx+0x10]
       mov      rcx, bword ptr [rbp-0x340]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ItemCount():int:this]
       mov      r8d, eax
       mov      rdi, gword ptr [rbp+0x18]
       mov      gword ptr [rsp+0x20], rdi
       mov      edx, r13d
       mov      rcx, r14
       mov      r9, bword ptr [rbp-0x340]
       mov      r9, gword ptr [r9]
       call     [Lokad.Lython.Runtime.LythonRuntime:CreateListFromStack(byref,int,int,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):Lokad.Lython.Runtime.PyList]
       mov      gword ptr [rbp-0x300], rax
       xor      r9d, r9d
       mov      qword ptr [rbp-0x2F8], r9
       lea      r9, [rbp-0x300]
       mov      rdx, rbx
       mov      r8, bword ptr [rbp-0x340]
       mov      rcx, r15
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PublishInstructionResult(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot)]
       jmp      G_M000_IG358
 
G_M000_IG265:                ;; offset=0x2440
       mov      rdi, gword ptr [rbp+0x18]
       mov      r15, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [r15+0x20]
       mov      rax, bword ptr [rbp-0x340]
       mov      eax, dword ptr [rax+0x10]
       cmp      eax, dword ptr [rcx+0x08]
       jae      G_M000_IG357
       shl      rax, 4
       lea      rcx, bword ptr [rcx+rax+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Object():System.Object:this]
       mov      rdx, rax
       mov      rcx, 0x7FF9B54EBCC8
       call     [Lokad.Lython.Internal.NullabilityExtensions:RequireNotNull[System.__Canon](System.__Canon):System.__Canon]
       lea      rcx, bword ptr [r15+0x20]
       mov      rdx, bword ptr [rbp-0x340]
       mov      edx, dword ptr [rdx+0x18]
       test     edx, edx
       jge      SHORT G_M000_IG266
       not      edx
 
G_M000_IG266:                ;; offset=0x2495
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
       jmp      G_M000_IG358
 
G_M000_IG267:                ;; offset=0x24A0
       mov      rdi, gword ptr [rbp+0x18]
       mov      r15, bword ptr [rbp+0x10]
       lea      r13, bword ptr [r15+0x20]
       mov      ecx, r14d
       cmp      ecx, 51
       ja       SHORT G_M000_IG272
 
G_M000_IG268:                ;; offset=0x24B4
       mov      rax, 0x7FFFFFFFFF9FF
       bt       rax, rcx
       jb       SHORT G_M000_IG272
 
G_M000_IG269:                ;; offset=0x24C4
       mov      rcx, bword ptr [rbp-0x340]
       mov      edx, dword ptr [rcx+0x18]
       test     edx, edx
       jge      SHORT G_M000_IG270
       mov      r14d, edx
       not      r14d
       jmp      SHORT G_M000_IG271
 
G_M000_IG270:                ;; offset=0x24DA
       mov      r14d, edx
 
G_M000_IG271:                ;; offset=0x24DD
       jmp      SHORT G_M000_IG273
 
G_M000_IG272:                ;; offset=0x24DF
       mov      rdx, bword ptr [rbp-0x340]
       mov      r14d, dword ptr [rdx+0x14]
 
G_M000_IG273:                ;; offset=0x24EA
       inc      r14d
       mov      rcx, bword ptr [rbp-0x340]
       mov      edx, dword ptr [rcx+0x18]
       test     edx, edx
       jge      SHORT G_M000_IG274
       mov      r12d, edx
       not      r12d
       jmp      SHORT G_M000_IG275
 
G_M000_IG274:                ;; offset=0x2503
       mov      r12d, edx
 
G_M000_IG275:                ;; offset=0x2506
       mov      rcx, gword ptr [r15+0x20]
       mov      rax, bword ptr [rbp-0x340]
       mov      eax, dword ptr [rax+0x10]
       cmp      eax, dword ptr [rcx+0x08]
       jae      G_M000_IG357
       shl      rax, 4
       lea      rcx, bword ptr [rcx+rax+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Object():System.Object:this]
       mov      rdx, rax
       mov      rcx, 0x7FF9B54EBCC8
       call     [Lokad.Lython.Internal.NullabilityExtensions:RequireNotNull[System.__Canon](System.__Canon):System.__Canon]
       mov      gword ptr [rbp-0x380], rax
       cmp      r12d, dword ptr [r13+0x40]
       jl       SHORT G_M000_IG277
 
G_M000_IG276:                ;; offset=0x254C
       mov      rax, gword ptr [rbp-0x380]
       jmp      SHORT G_M000_IG278
 
G_M000_IG277:                ;; offset=0x2555
       mov      rcx, r13
       mov      edx, r12d
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
       mov      rax, gword ptr [rbp-0x380]
 
G_M000_IG278:                ;; offset=0x2568
       mov      rcx, gword ptr [r13]
       cmp      r14d, dword ptr [rcx+0x08]
       jae      G_M000_IG357
       mov      edx, r14d
       shl      rdx, 4
       lea      r14, bword ptr [rcx+rdx+0x10]
       mov      rcx, r14
       mov      rdx, rax
       call     CORINFO_HELP_ASSIGN_REF
       xor      ecx, ecx
       mov      qword ptr [r14+0x08], rcx
       mov      dword ptr [r13+0x40], r12d
       jmp      G_M000_IG358
 
G_M000_IG279:                ;; offset=0x259C
       mov      rdi, gword ptr [rbp+0x18]
       test     rbx, rbx
       je       G_M000_IG97
       mov      r15, bword ptr [rbp+0x10]
       mov      r14, gword ptr [r15]
       mov      r13, gword ptr [r15+0x08]
       mov      rcx, gword ptr [r15]
       mov      r12, gword ptr [rcx+0x38]
       mov      rcx, bword ptr [rbp-0x340]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_NameIndex():int:this]
       cmp      eax, dword ptr [r12+0x08]
       jae      G_M000_IG357
       mov      ecx, eax
       mov      r12, gword ptr [r12+8*rcx+0x10]
       lea      rcx, bword ptr [r15+0x20]
       mov      rdx, bword ptr [rbp-0x340]
       mov      edx, dword ptr [rdx+0x10]
       mov      r8, bword ptr [rbp-0x340]
       mov      r8d, dword ptr [r8+0x18]
       test     r8d, r8d
       jge      SHORT G_M000_IG280
       not      r8d
 
G_M000_IG280:                ;; offset=0x25FB
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:TakeValue(int,int):System.Object:this]
       mov      r9, rax
       mov      gword ptr [rsp+0x20], rbx
       mov      rdx, bword ptr [rbp-0x340]
       mov      rdx, gword ptr [rdx]
       mov      gword ptr [rsp+0x28], rdx
       mov      rdx, r13
       mov      r8, r12
       mov      rcx, r14
       call     [Lokad.Lython.Runtime.LythonRuntime:AssignExecutableBoundName(Lokad.Lython.Frontend.ExecutableCodeObject,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot[],System.String,System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan)]
       jmp      G_M000_IG358
 
G_M000_IG281:                ;; offset=0x262C
       mov      rdi, gword ptr [rbp+0x18]
       test     rbx, rbx
       je       G_M000_IG97
       mov      r15, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [r15]
       mov      r14, gword ptr [rcx+0x38]
       mov      rcx, bword ptr [rbp-0x340]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_NameIndex():int:this]
       cmp      eax, dword ptr [r14+0x08]
       jae      G_M000_IG357
       mov      ecx, eax
       mov      r14, gword ptr [r14+8*rcx+0x10]
       lea      rcx, bword ptr [r15+0x20]
       mov      rdx, bword ptr [rbp-0x340]
       mov      edx, dword ptr [rdx+0x10]
       mov      r8, bword ptr [rbp-0x340]
       mov      r8d, dword ptr [r8+0x18]
       test     r8d, r8d
       jge      SHORT G_M000_IG282
       not      r8d
 
G_M000_IG282:                ;; offset=0x2683
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:TakeValue(int,int):System.Object:this]
       mov      rdx, rax
       mov      r9, bword ptr [rbp-0x340]
       mov      r9, gword ptr [r9]
       mov      rcx, r14
       mov      r8, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime:StoreName(System.String,System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan)]
       jmp      G_M000_IG358
 
G_M000_IG283:                ;; offset=0x26A7
       mov      rdi, gword ptr [rbp+0x18]
       mov      r15, bword ptr [rbp+0x10]
       mov      rcx, r15
       mov      rdx, rbx
       mov      r8, bword ptr [rbp-0x340]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryStoreClosure(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       test     eax, eax
       jne      G_M000_IG358
       jmp      G_M000_IG97
 
G_M000_IG284:                ;; offset=0x26CF
       mov      rdi, gword ptr [rbp+0x18]
       mov      r15, bword ptr [rbp+0x10]
       mov      rcx, r15
       mov      rdx, rdi
       mov      r8, rbx
       mov      r9, bword ptr [rbp-0x340]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:StoreExecutableLocal(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref)]
       jmp      G_M000_IG358
 
G_M000_IG285:                ;; offset=0x26F2
       mov      rdi, gword ptr [rbp+0x18]
       mov      r15, bword ptr [rbp+0x10]
       test     rbx, rbx
       je       G_M000_IG97
       mov      rdx, bword ptr [rbp-0x340]
       mov      rdx, gword ptr [rdx]
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime:PreloadImplicitSuperArguments(Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan)]
       jmp      G_M000_IG358
 
G_M000_IG286:                ;; offset=0x271B
       mov      rdi, gword ptr [rbp+0x18]
       mov      r15, bword ptr [rbp+0x10]
       mov      rcx, r15
       mov      rdx, rdi
       mov      r8, rbx
       mov      r9, bword ptr [rbp-0x340]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryLoadDirectCallReceiver(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       test     eax, eax
       jne      G_M000_IG358
       test     rbx, rbx
       je       G_M000_IG97
       cmp      byte  ptr [rbp+0x28], 0
       je       SHORT G_M000_IG289
       mov      r8, bword ptr [rbp-0x340]
 
G_M000_IG287:                ;; offset=0x2757
       vmovdqu  ymm0, ymmword ptr [r8]
       vmovdqu  ymmword ptr [rbp-0x320], ymm0
 
G_M000_IG288:                ;; offset=0x2764
       lea      r8, [rbp-0x320]
       lea      rdx, [rbp-0x238]
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteMemberLoadAsync(Lokad.Lython.Frontend.ExecutableInstruction):System.Threading.Tasks.ValueTask`1[bool]:this]
       mov      r14, rsi
       mov      rdx, gword ptr [rbp-0x238]
       mov      rcx, r14
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rdx, qword ptr [rbp-0x230]
       mov      qword ptr [r14+0x08], rdx
       mov      r14, gword ptr [rsi]
       test     r14, r14
       je       G_M000_IG62
       jmp      G_M000_IG319
 
G_M000_IG289:                ;; offset=0x27A9
       mov      rcx, r15
       mov      rdx, rdi
       mov      r8, rbx
       mov      r9, bword ptr [rbp-0x340]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteSynchronousMemberLoad(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref)]
       jmp      G_M000_IG358
 
G_M000_IG290:                ;; offset=0x27C4
       vxorps   ymm0, ymm0, ymm0
       vmovdqu  ymmword ptr [rbp-0x158], ymm0
       vmovdqu  xmmword ptr [rbp-0x140], xmm0
       lea      rcx, [rbp-0x158]
       mov      edx, 27
       mov      r8d, 1
       call     [System.Runtime.CompilerServices.DefaultInterpolatedStringHandler:.ctor(int,int):this]
 
G_M000_IG291:                ;; offset=0x27F0
       vmovdqu  ymm0, ymmword ptr [rbp-0x158]
       vmovdqu  ymmword ptr [rbp-0x130], ymm0
       mov      rcx, qword ptr [rbp-0x138]
       mov      qword ptr [rbp-0x110], rcx
 
G_M000_IG292:                ;; offset=0x280E
       mov      ecx, dword ptr [rbp-0x120]
       cmp      ecx, dword ptr [rbp-0x110]
       jbe      G_M000_IG354
       jmp      G_M000_IG306
 
G_M000_IG293:                ;; offset=0x2825
       mov      rcx, bword ptr [rbp+0x10]
       mov      rax, gword ptr [rcx]
       mov      rdi, gword ptr [rax+0x68]
       mov      rcx, bword ptr [rbp-0x340]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LocalSlot():int:this]
       mov      edx, eax
       mov      rcx, rdi
       mov      r11, 0x7FF9B4B62D00
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       mov      rcx, rax
       mov      rdx, bword ptr [rbp-0x340]
       mov      rdx, gword ptr [rdx]
       call     [Lokad.Lython.Runtime.RuntimeErrors:UnboundLocalVariable(System.String,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.LythonRuntimeException]
       mov      rcx, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG294:                ;; offset=0x286B
       mov      ecx, dword ptr [rax+0x34]
       and      ecx, 0x11000000
       cmp      ecx, 0x1000000
       je       G_M000_IG358
 
G_M000_IG295:                ;; offset=0x2880
       mov      rcx, rax
       xor      edx, edx
       call     [System.Runtime.CompilerServices.TaskAwaiter:HandleNonSuccessAndDebuggerNotification(System.Threading.Tasks.Task,int)]
       jmp      G_M000_IG358
 
G_M000_IG296:                ;; offset=0x2890
       mov      rdx, rdi
       mov      rcx, 0x7FF9B51A60C8
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG297
       test     dword ptr [rax+0x34], 0x1600000
       setne    r14b
       movzx    r14, r14b
       jmp      SHORT G_M000_IG298
 
G_M000_IG297:                ;; offset=0x28B8
       movsx    rdx, word  ptr [rsi+0x08]
       mov      rcx, rdi
       mov      r11, 0x7FF9B4B62D20
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[bool]:GetStatus(short):int:this
       test     eax, eax
       setne    r14b
       movzx    r14, r14b
 
G_M000_IG298:                ;; offset=0x28D7
       test     r14d, r14d
       jne      G_M000_IG62
 
G_M000_IG299:                ;; offset=0x28E0
       mov      r15, bword ptr [rbp+0x10]
       mov      r13, gword ptr [rbp+0x18]
       mov      rcx, bword ptr [rbp-0x340]
       mov      rdx, gword ptr [rcx]
       mov      rcx, bword ptr [rbp+0x38]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      dword ptr [rbp-0xA4], 4
       jmp      G_M000_IG366
 
G_M000_IG300:                ;; offset=0x290A
       mov      ecx, dword ptr [rax+0x34]
       and      ecx, 0x11000000
       cmp      ecx, 0x1000000
       je       G_M000_IG358
 
G_M000_IG301:                ;; offset=0x291F
       mov      rcx, rax
       xor      edx, edx
       call     [System.Runtime.CompilerServices.TaskAwaiter:HandleNonSuccessAndDebuggerNotification(System.Threading.Tasks.Task,int)]
       jmp      G_M000_IG358
 
G_M000_IG302:                ;; offset=0x292F
       mov      rdx, r15
       mov      rcx, 0x7FF9B51A60C8
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG303
       test     dword ptr [rax+0x34], 0x1600000
       setne    r13b
       movzx    r13, r13b
       jmp      SHORT G_M000_IG304
 
G_M000_IG303:                ;; offset=0x2957
       movsx    rdx, word  ptr [rsi+0x08]
       mov      rcx, r15
       mov      r11, 0x7FF9B4B62D30
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[bool]:GetStatus(short):int:this
       test     eax, eax
       setne    r13b
       movzx    r13, r13b
 
G_M000_IG304:                ;; offset=0x2976
       test     r13d, r13d
       jne      G_M000_IG62
       jmp      G_M000_IG299
 
G_M000_IG305:                ;; offset=0x2984
       mov      rdi, gword ptr [rbp+0x18]
       mov      rcx, rax
       call     CORINFO_HELP_CHKCASTCLASS
       int3     
 
G_M000_IG306:                ;; offset=0x2991
       mov      r14, bword ptr [rbp+0x10]
       call     [System.ThrowHelper:ThrowArgumentOutOfRangeException()]
       int3     
 
G_M000_IG307:                ;; offset=0x299C
       mov      ecx, dword ptr [rax+0x34]
       and      ecx, 0x11000000
       cmp      ecx, 0x1000000
       je       G_M000_IG358
 
G_M000_IG308:                ;; offset=0x29B1
       mov      rcx, rax
       xor      edx, edx
       call     [System.Runtime.CompilerServices.TaskAwaiter:HandleNonSuccessAndDebuggerNotification(System.Threading.Tasks.Task,int)]
       jmp      G_M000_IG358
 
G_M000_IG309:                ;; offset=0x29C1
       mov      rdx, rdi
       mov      rcx, 0x7FF9B51A60C8
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG310
       test     dword ptr [rax+0x34], 0x1600000
       setne    r14b
       movzx    r14, r14b
       jmp      SHORT G_M000_IG311
 
G_M000_IG310:                ;; offset=0x29E9
       movsx    rdx, word  ptr [rsi+0x08]
       mov      rcx, rdi
       mov      r11, 0x7FF9B4B62D40
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[bool]:GetStatus(short):int:this
       test     eax, eax
       setne    r14b
       movzx    r14, r14b
 
G_M000_IG311:                ;; offset=0x2A08
       test     r14d, r14d
       jne      G_M000_IG62
       jmp      G_M000_IG299
 
G_M000_IG312:                ;; offset=0x2A16
       mov      rdx, r14
       mov      rcx, 0x7FF9B51A60C8
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG313
       test     dword ptr [rax+0x34], 0x1600000
       setne    r13b
       movzx    r13, r13b
       jmp      SHORT G_M000_IG314
 
G_M000_IG313:                ;; offset=0x2A3E
       movsx    rdx, word  ptr [rsi+0x08]
       mov      rcx, r14
       mov      r11, 0x7FF9B4B62D48
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[bool]:GetStatus(short):int:this
       test     eax, eax
       setne    r13b
       movzx    r13, r13b
 
G_M000_IG314:                ;; offset=0x2A5D
       test     r13d, r13d
       jne      G_M000_IG261
       jmp      G_M000_IG299
 
G_M000_IG315:                ;; offset=0x2A6B
       mov      rcx, r12
       xor      edx, edx
       call     [System.Runtime.CompilerServices.TaskAwaiter:HandleNonSuccessAndDebuggerNotification(System.Threading.Tasks.Task,int)]
       jmp      G_M000_IG252
 
G_M000_IG316:                ;; offset=0x2A7B
       mov      rdx, rdi
       mov      rcx, 0x7FF9B51A60C8
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG317
       test     dword ptr [rax+0x34], 0x1600000
       setne    r14b
       movzx    r14, r14b
       jmp      SHORT G_M000_IG318
 
G_M000_IG317:                ;; offset=0x2AA3
       movsx    rdx, word  ptr [rsi+0x08]
       mov      rcx, rdi
       mov      r11, 0x7FF9B4B62D58
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[bool]:GetStatus(short):int:this
       test     eax, eax
       setne    r14b
       movzx    r14, r14b
 
G_M000_IG318:                ;; offset=0x2AC2
       test     r14d, r14d
       jne      G_M000_IG62
       jmp      G_M000_IG299
 
G_M000_IG319:                ;; offset=0x2AD0
       mov      rdx, r14
       mov      rcx, 0x7FF9B51A60C8
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG320
       test     dword ptr [rax+0x34], 0x1600000
       setne    r13b
       movzx    r13, r13b
       jmp      SHORT G_M000_IG321
 
G_M000_IG320:                ;; offset=0x2AF8
       movsx    rdx, word  ptr [rsi+0x08]
       mov      rcx, r14
       mov      r11, 0x7FF9B4B62D60
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[bool]:GetStatus(short):int:this
       test     eax, eax
       setne    r13b
       movzx    r13, r13b
 
G_M000_IG321:                ;; offset=0x2B17
       test     r13d, r13d
       jne      G_M000_IG62
       jmp      G_M000_IG299
 
G_M000_IG322:                ;; offset=0x2B25
       mov      rdx, r15
       mov      rcx, 0x7FF9B51A60C8
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG323
       test     dword ptr [rax+0x34], 0x1600000
       setne    r13b
       movzx    r13, r13b
       jmp      SHORT G_M000_IG324
 
G_M000_IG323:                ;; offset=0x2B4D
       movsx    rdx, word  ptr [rsi+0x08]
       mov      rcx, r15
       mov      r11, 0x7FF9B4B62D68
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[bool]:GetStatus(short):int:this
       test     eax, eax
       setne    r13b
       movzx    r13, r13b
 
G_M000_IG324:                ;; offset=0x2B6C
       test     r13d, r13d
       jne      G_M000_IG228
       jmp      G_M000_IG299
 
G_M000_IG325:                ;; offset=0x2B7A
       mov      rdx, r15
       mov      rcx, 0x7FF9B51A60C8
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG326
       test     dword ptr [rax+0x34], 0x1600000
       setne    r13b
       movzx    r13, r13b
       jmp      SHORT G_M000_IG327
 
G_M000_IG326:                ;; offset=0x2BA2
       movsx    rdx, word  ptr [rsi+0x08]
       mov      rcx, r15
       mov      r11, 0x7FF9B4B62D70
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[bool]:GetStatus(short):int:this
       test     eax, eax
       setne    r13b
       movzx    r13, r13b
 
G_M000_IG327:                ;; offset=0x2BC1
       test     r13d, r13d
       jne      G_M000_IG228
       jmp      G_M000_IG299
 
G_M000_IG328:                ;; offset=0x2BCF
       mov      rdx, r15
       mov      rcx, 0x7FF9B51A60C8
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG329
       test     dword ptr [rax+0x34], 0x1600000
       setne    r13b
       movzx    r13, r13b
       jmp      SHORT G_M000_IG330
 
G_M000_IG329:                ;; offset=0x2BF7
       movsx    rdx, word  ptr [rsi+0x08]
       mov      rcx, r15
       mov      r11, 0x7FF9B4B62D78
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[bool]:GetStatus(short):int:this
       test     eax, eax
       setne    r13b
       movzx    r13, r13b
 
G_M000_IG330:                ;; offset=0x2C16
       test     r13d, r13d
       jne      G_M000_IG228
       jmp      G_M000_IG299
 
G_M000_IG331:                ;; offset=0x2C24
       mov      rcx, bword ptr [rbp-0x340]
       mov      rdx, 0x19F4A0791D0
       call     [Lokad.Lython.Frontend.ExecutableInstruction:InvalidOperand(System.String):System.InvalidOperationException:this]
       mov      rcx, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG332:                ;; offset=0x2C44
       call     CORINFO_HELP_CHKCASTCLASS
       int3     
 
G_M000_IG333:                ;; offset=0x2C4A
       mov      rdx, r12
       mov      rcx, 0x7FF9B54ED720
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG334
       mov      edx, dword ptr [rax+0x34]
       and      edx, 0x1600000
       cmp      edx, 0x1000000
       sete     dil
       movzx    rdi, dil
       jmp      SHORT G_M000_IG335
 
G_M000_IG334:                ;; offset=0x2C7A
       mov      rax, bword ptr [rbp+0x40]
       movsx    rdx, word  ptr [rax+0x10]
       mov      rcx, r12
       mov      r11, 0x7FF9B4B62D80
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[System.__Canon]:GetStatus(short):int:this
       cmp      eax, 1
       sete     dil
       movzx    rdi, dil
 
G_M000_IG335:                ;; offset=0x2C9E
       test     edi, edi
       je       G_M000_IG140
       jmp      G_M000_IG133
 
G_M000_IG336:                ;; offset=0x2CAB
       mov      rdx, rdi
       mov      rcx, 0x7FF9B54ED720
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       mov      r12, rax
       test     r12, r12
       je       SHORT G_M000_IG339
       mov      ecx, dword ptr [r12+0x34]
       and      ecx, 0x11000000
       cmp      ecx, 0x1000000
       je       SHORT G_M000_IG338
 
G_M000_IG337:                ;; offset=0x2CD8
       mov      rcx, r12
       xor      edx, edx
       call     [System.Runtime.CompilerServices.TaskAwaiter:HandleNonSuccessAndDebuggerNotification(System.Threading.Tasks.Task,int)]
 
G_M000_IG338:                ;; offset=0x2CE3
       mov      r12, gword ptr [r12+0x38]
       jmp      G_M000_IG135
 
G_M000_IG339:                ;; offset=0x2CED
       mov      rax, bword ptr [rbp+0x40]
       movsx    rdx, word  ptr [rax+0x10]
       mov      rcx, rdi
       mov      r11, 0x7FF9B4B62D88
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[System.__Canon]:GetResult(short):System.__Canon:this
       mov      r12, rax
       jmp      G_M000_IG135
 
G_M000_IG340:                ;; offset=0x2D0E
       mov      ecx, dword ptr [rax+0x34]
       and      ecx, 0x11000000
       cmp      ecx, 0x1000000
       je       G_M000_IG358
 
G_M000_IG341:                ;; offset=0x2D23
       mov      rcx, rax
       xor      edx, edx
       call     [System.Runtime.CompilerServices.TaskAwaiter:HandleNonSuccessAndDebuggerNotification(System.Threading.Tasks.Task,int)]
       jmp      G_M000_IG358
 
G_M000_IG342:                ;; offset=0x2D33
       mov      rdx, r14
       mov      rcx, 0x7FF9B51A60C8
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG343
       test     dword ptr [rax+0x34], 0x1600000
       setne    dil
       movzx    rdi, dil
       jmp      SHORT G_M000_IG344
 
G_M000_IG343:                ;; offset=0x2D5B
       movsx    rdx, word  ptr [rsi+0x08]
       mov      rcx, r14
       mov      r11, 0x7FF9B4B62D98
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[bool]:GetStatus(short):int:this
       test     eax, eax
       setne    dil
       movzx    rdi, dil
 
G_M000_IG344:                ;; offset=0x2D7A
       test     edi, edi
       jne      G_M000_IG62
       jmp      G_M000_IG299
 
G_M000_IG345:                ;; offset=0x2D87
       mov      rdx, r15
       mov      rcx, 0x7FF9B51A60C8
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG346
       test     dword ptr [rax+0x34], 0x1600000
       setne    r13b
       movzx    r13, r13b
       jmp      SHORT G_M000_IG347
 
G_M000_IG346:                ;; offset=0x2DAF
       movsx    rdx, word  ptr [rsi+0x08]
       mov      rcx, r15
       mov      r11, 0x7FF9B4B62DA0
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[bool]:GetStatus(short):int:this
       test     eax, eax
       setne    r13b
       movzx    r13, r13b
 
G_M000_IG347:                ;; offset=0x2DCE
       test     r13d, r13d
       jne      G_M000_IG62
       jmp      G_M000_IG299
 
G_M000_IG348:                ;; offset=0x2DDC
       mov      rdx, rdi
       mov      rcx, 0x7FF9B51A60C8
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG349
       test     dword ptr [rax+0x34], 0x1600000
       setne    r14b
       movzx    r14, r14b
       jmp      SHORT G_M000_IG350
 
G_M000_IG349:                ;; offset=0x2E04
       movsx    rdx, word  ptr [rsi+0x08]
       mov      rcx, rdi
       mov      r11, 0x7FF9B4B62DA8
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[bool]:GetStatus(short):int:this
       test     eax, eax
       setne    r14b
       movzx    r14, r14b
 
G_M000_IG350:                ;; offset=0x2E23
       test     r14d, r14d
       jne      G_M000_IG62
       jmp      G_M000_IG299
 
G_M000_IG351:                ;; offset=0x2E31
       mov      rdx, rdi
       mov      rcx, 0x7FF9B51A60C8
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG352
       test     dword ptr [rax+0x34], 0x1600000
       setne    r14b
       movzx    r14, r14b
       jmp      SHORT G_M000_IG353
 
G_M000_IG352:                ;; offset=0x2E59
       movsx    rdx, word  ptr [rsi+0x08]
       mov      rcx, rdi
       mov      r11, 0x7FF9B4B62DB0
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[bool]:GetStatus(short):int:this
       test     eax, eax
       setne    r14b
       movzx    r14, r14b
 
G_M000_IG353:                ;; offset=0x2E78
       test     r14d, r14d
       jne      G_M000_IG228
       jmp      G_M000_IG299
 
G_M000_IG354:                ;; offset=0x2E86
       mov      rdx, bword ptr [rbp-0x118]
       mov      eax, ecx
       lea      rdx, bword ptr [rdx+2*rax]
       mov      eax, dword ptr [rbp-0x110]
       sub      eax, ecx
       cmp      eax, 27
       jb       SHORT G_M000_IG355
       vmovups  ymm0, ymmword ptr [reloc @RWD304]
       vmovups  ymmword ptr [rdx], ymm0
       vmovups  xmm0, xmmword ptr [reloc @RWD336]
       vmovups  xmmword ptr [rdx+0x20], xmm0
       mov      dword ptr [rdx+0x30], 0x3A0065
       mov      word  ptr [rdx+0x34], 32
       mov      ecx, dword ptr [rbp-0x120]
       add      ecx, 27
       mov      dword ptr [rbp-0x120], ecx
       jmp      SHORT G_M000_IG356
 
G_M000_IG355:                ;; offset=0x2ED7
       lea      rcx, [rbp-0x130]
       mov      rdx, 0x19F4A07B800
       call     [System.Runtime.CompilerServices.DefaultInterpolatedStringHandler:GrowThenCopyString(System.String):this]
 
G_M000_IG356:                ;; offset=0x2EEE
       mov      rdx, bword ptr [rbp-0x340]
       mov      edx, dword ptr [rdx+0x1C]
       lea      rcx, [rbp-0x130]
       call     [System.Runtime.CompilerServices.DefaultInterpolatedStringHandler:AppendFormatted[int](int):this]
       mov      rcx, 0x7FF9B4D894A8
       call     CORINFO_HELP_NEWSFAST
       mov      rdi, rax
       lea      rcx, [rbp-0x130]
       call     [System.Runtime.CompilerServices.DefaultInterpolatedStringHandler:ToStringAndClear():System.String:this]
       mov      rdx, rax
       mov      rcx, rdi
       call     [System.InvalidOperationException:.ctor(System.String):this]
       mov      rcx, rdi
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG357:                ;; offset=0x2F39
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG358:                ;; offset=0x2F3F
       cmp      byte  ptr [rbp+0x28], 0
       je       SHORT G_M000_IG359
       mov      r14, bword ptr [rbp+0x10]
       cmp      gword ptr [r14+0x40], 0
       jne      SHORT G_M000_IG363
 
G_M000_IG359:                ;; offset=0x2F50
       cmp      dword ptr [rbp-0x3C], 0
       jne      SHORT G_M000_IG360
       mov      r14, bword ptr [rbp+0x10]
       inc      dword ptr [r14+0x10]
 
G_M000_IG360:                ;; offset=0x2F5E
       mov      rbx, gword ptr [rbp+0x20]
       mov      rsi, bword ptr [rbp+0x30]
       mov      rcx, bword ptr [rbp+0x10]
       mov      eax, dword ptr [rcx+0x10]
       mov      rdx, gword ptr [rbp-0x338]
       mov      edi, dword ptr [rdx+0x08]
       cmp      eax, edi
       mov      r9, rdx
       jl       G_M000_IG05
 
G_M000_IG361:                ;; offset=0x2F82
       mov      eax, 1
 
G_M000_IG362:                ;; offset=0x2F87
       vzeroupper 
       add      rsp, 984
       pop      rbx
       pop      rsi
       pop      rdi
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG363:                ;; offset=0x2F9E
       xor      rax, rax
       mov      rsi, bword ptr [rbp+0x30]
       mov      gword ptr [rsi], rax
       mov      word  ptr [rsi+0x08], 0
       movzx    rax, byte  ptr [rbp-0x3C]
       mov      byte  ptr [rsi+0x0A], al
       mov      byte  ptr [rsi+0x0B], 1
       mov      eax, 5
 
G_M000_IG364:                ;; offset=0x2FBD
       vzeroupper 
       add      rsp, 984
       pop      rbx
       pop      rsi
       pop      rdi
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG365:                ;; offset=0x2FD4
       mov      r9, bword ptr [rbp-0x340]
       mov      r9, gword ptr [r9]
       mov      rcx, rdi
       mov      rdx, r13
       mov      r8, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:RouteInstructionFailure(Lokad.Lython.Runtime.LythonRuntimeException,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):bool]
       test     eax, eax
       je       SHORT G_M000_IG368
       mov      dword ptr [rbp-0x3C], 1
       jmp      G_M000_IG358
 
G_M000_IG366:                ;; offset=0x2FFD
       mov      eax, dword ptr [rbp-0xA4]
 
G_M000_IG367:                ;; offset=0x3003
       vzeroupper 
       add      rsp, 984
       pop      rbx
       pop      rsi
       pop      rdi
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG368:                ;; offset=0x301A
       mov      rcx, rdi
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG369:                ;; offset=0x3023
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG370:                ;; offset=0x3029
       sub      rsp, 72
 
G_M000_IG371:                ;; offset=0x302D
       mov      rbx, rcx
       cmp      gword ptr [rbp+0x20], 0
       jne      SHORT G_M000_IG372
       call     CORINFO_HELP_RETHROW
       int3     
 
G_M000_IG372:                ;; offset=0x303D
       mov      rcx, bword ptr [rbp-0x340]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      r8, rax
       mov      rdx, rbx
       mov      rcx, gword ptr [rbp+0x20]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryRouteReturn(Lokad.Lython.Runtime.LythonRuntime+ReturnSignal,Lokad.Lython.LythonSourceSpan):bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG374
       mov      dword ptr [rbp-0xA4], 1
       lea      rax, G_M000_IG366
 
G_M000_IG373:                ;; offset=0x306F
       vzeroupper 
       add      rsp, 72
       ret      
 
G_M000_IG374:                ;; offset=0x3077
       mov      dword ptr [rbp-0x3C], 1
       lea      rax, G_M000_IG358
 
G_M000_IG375:                ;; offset=0x3085
       vzeroupper 
       add      rsp, 72
       ret      
 
G_M000_IG376:                ;; offset=0x308D
       sub      rsp, 72
 
G_M000_IG377:                ;; offset=0x3091
       mov      rbx, rcx
       mov      rcx, bword ptr [rbp-0x340]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      r9, rax
       mov      rdx, gword ptr [rbp+0x18]
       mov      r8, gword ptr [rbp+0x20]
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:RouteInstructionFailure(Lokad.Lython.Runtime.LythonRuntimeException,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):bool]
       test     eax, eax
       jne      SHORT G_M000_IG378
       call     CORINFO_HELP_RETHROW
       int3     
 
G_M000_IG378:                ;; offset=0x30BF
       mov      dword ptr [rbp-0x3C], 1
       lea      rax, G_M000_IG358
 
G_M000_IG379:                ;; offset=0x30CD
       vzeroupper 
       add      rsp, 72
       ret      
 
RWD00  	dd	000008E1h ; case G_M000_IG61
       	dd	000007C0h ; case G_M000_IG54
       	dd	00000671h ; case G_M000_IG46
       	dd	00000507h ; case G_M000_IG37
       	dd	000003E4h ; case G_M000_IG30
       	dd	000002A3h ; case G_M000_IG23
       	dd	000001D2h ; case G_M000_IG17
       	dd	000000CFh ; case G_M000_IG09
       	dd	000000CFh ; case G_M000_IG09
       	dd	00000E55h ; case G_M000_IG102
       	dd	00000E55h ; case G_M000_IG102
       	dd	000000CFh ; case G_M000_IG09
       	dd	000000CFh ; case G_M000_IG09
       	dd	000000CFh ; case G_M000_IG09
       	dd	000000CFh ; case G_M000_IG09
       	dd	000000CFh ; case G_M000_IG09
       	dd	000000CFh ; case G_M000_IG09
       	dd	000000CFh ; case G_M000_IG09
       	dd	000000CFh ; case G_M000_IG09
       	dd	000000CFh ; case G_M000_IG09
       	dd	000000CFh ; case G_M000_IG09
       	dd	000000CFh ; case G_M000_IG09
       	dd	000026A7h ; case G_M000_IG286
       	dd	000026A7h ; case G_M000_IG286
       	dd	0000267Eh ; case G_M000_IG285
       	dd	0000265Bh ; case G_M000_IG284
       	dd	00002633h ; case G_M000_IG283
       	dd	000025B8h ; case G_M000_IG281
       	dd	00002528h ; case G_M000_IG279
       	dd	0000242Ch ; case G_M000_IG267
       	dd	000023CCh ; case G_M000_IG265
       	dd	0000235Ah ; case G_M000_IG264
       	dd	00001EBEh ; case G_M000_IG231
       	dd	00001E99h ; case G_M000_IG229
       	dd	00001E99h ; case G_M000_IG229
       	dd	00001E99h ; case G_M000_IG229
       	dd	00001E1Dh ; case G_M000_IG225
       	dd	00001E1Dh ; case G_M000_IG225
       	dd	00001E1Dh ; case G_M000_IG225
       	dd	00001E99h ; case G_M000_IG229
       	dd	00001CE1h ; case G_M000_IG218
       	dd	00001BC6h ; case G_M000_IG210
       	dd	00000EA5h ; case G_M000_IG103
       	dd	00000E2Fh ; case G_M000_IG101
       	dd	00000DABh ; case G_M000_IG98
       	dd	00000D83h ; case G_M000_IG96
       	dd	00000D58h ; case G_M000_IG95
       	dd	00000D58h ; case G_M000_IG95
       	dd	00000D58h ; case G_M000_IG95
       	dd	00000CCDh ; case G_M000_IG92
       	dd	00000BCBh ; case G_M000_IG83
       	dd	00000B84h ; case G_M000_IG82
       	dd	00000CCDh ; case G_M000_IG92
       	dd	00000CCDh ; case G_M000_IG92
       	dd	00000CCDh ; case G_M000_IG92
       	dd	00000CCDh ; case G_M000_IG92
       	dd	00000CCDh ; case G_M000_IG92
       	dd	00000CCDh ; case G_M000_IG92
       	dd	00000CCDh ; case G_M000_IG92
       	dd	00002347h ; case G_M000_IG263
       	dd	00000993h ; case G_M000_IG64
       	dd	000020E3h ; case G_M000_IG244
       	dd	00000CCDh ; case G_M000_IG92
       	dd	00001FBAh ; case G_M000_IG235
       	dd	00001FBAh ; case G_M000_IG235
       	dd	00001FBAh ; case G_M000_IG235
       	dd	00001FBAh ; case G_M000_IG235
       	dd	00001FBAh ; case G_M000_IG235
       	dd	00001BA0h ; case G_M000_IG209
       	dd	00001AC4h ; case G_M000_IG206
       	dd	00001943h ; case G_M000_IG186
       	dd	00001864h ; case G_M000_IG173
       	dd	000016EBh ; case G_M000_IG162
       	dd	000017E0h ; case G_M000_IG170
       	dd	00001616h ; case G_M000_IG151
       	dd	0000156Dh ; case G_M000_IG148
RWD304 	dq	006E006B006E0055h, 0020006E0077006Fh, 0063006500780065h, 0062006100740075h
RWD336 	dq	006F00200065006Ch, 0064006F00630070h

; Total bytes of code 12501

; Assembly listing for method Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteNativeCall(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Frontend.ExecutableCallSite,int,System.Object,byref):bool (FullOpts)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; FullOpts code
; optimized code
; rbp based frame
; fully interruptible
; No PGO data
; 0 inlinees with PGO data; 99 single block inlinees; 29 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       push     r15
       push     r14
       push     r13
       push     r12
       push     rdi
       push     rsi
       push     rbx
       sub      rsp, 344
       lea      rbp, [rsp+0x190]
       vxorps   xmm4, xmm4, xmm4
       vmovdqa  xmmword ptr [rbp-0x120], xmm4
       vmovdqa  xmmword ptr [rbp-0x110], xmm4
       mov      rax, -192
 
G_M000_IG136:                ;; offset=0x0039
       vmovdqa  xmmword ptr [rbp+rax-0x40], xmm4
       vmovdqa  xmmword ptr [rbp+rax-0x30], xmm4
       vmovdqa  xmmword ptr [rbp+rax-0x20], xmm4
       add      rax, 48
       jne      SHORT G_M000_IG136
       mov      qword ptr [rbp-0x40], rax
       mov      bword ptr [rbp+0x10], rcx
       mov      gword ptr [rbp+0x18], rdx
       mov      gword ptr [rbp+0x28], r9
       mov      rsi, r8
       mov      rbx, r9
       mov      eax, dword ptr [rbp+0x30]
       mov      rdi, gword ptr [rbp+0x38]
       mov      r14, bword ptr [rbp+0x40]
 
G_M000_IG02:                ;; offset=0x0072
       xor      r8, r8
       mov      gword ptr [r14], r8
       test     rdi, rdi
       je       SHORT G_M000_IG05
 
G_M000_IG03:                ;; offset=0x007D
       mov      r8, 0x7FF9B54EA2D8
       cmp      qword ptr [rdi], r8
       jne      SHORT G_M000_IG05
 
G_M000_IG04:                ;; offset=0x008C
       mov      gword ptr [rbp-0x128], rdi
       jmp      SHORT G_M000_IG06
 
G_M000_IG05:                ;; offset=0x0095
       xor      r8, r8
       mov      gword ptr [rbp-0x128], r8
 
G_M000_IG06:                ;; offset=0x009F
       cmp      byte  ptr [rbx+0x30], 0
       je       SHORT G_M000_IG09
 
G_M000_IG07:                ;; offset=0x00A5
       mov      r8, gword ptr [rcx+0x20]
       cmp      eax, dword ptr [r8+0x08]
       jae      G_M000_IG122
       mov      r10d, eax
       shl      r10, 4
       lea      rcx, bword ptr [r8+r10+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Object():System.Object:this]
       mov      rdx, rax
       mov      rcx, 0x7FF9B54EBCC8
       call     [Lokad.Lython.Internal.NullabilityExtensions:RequireNotNull[System.__Canon](System.__Canon):System.__Canon]
       test     rax, rax
       je       SHORT G_M000_IG10
 
G_M000_IG08:                ;; offset=0x00DD
       mov      rcx, 0x7FF9B545F1F8
       cmp      qword ptr [rax], rcx
       jne      SHORT G_M000_IG10
 
G_M000_IG09:                ;; offset=0x00EC
       mov      rcx, bword ptr [rbp+0x10]
       mov      eax, dword ptr [rbp+0x30]
       xor      r15, r15
       jmp      SHORT G_M000_IG11
 
G_M000_IG10:                ;; offset=0x00F8
       mov      rcx, bword ptr [rbp+0x10]
       mov      r8, gword ptr [rcx+0x20]
       mov      eax, dword ptr [rbp+0x30]
       cmp      eax, dword ptr [r8+0x08]
       jae      G_M000_IG122
       mov      r10d, eax
       shl      r10, 4
       lea      rcx, bword ptr [r8+r10+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Object():System.Object:this]
       mov      rdx, rax
       mov      rcx, 0x7FF9B54EBCC8
       call     [Lokad.Lython.Internal.NullabilityExtensions:RequireNotNull[System.__Canon](System.__Canon):System.__Canon]
       mov      r15, rax
 
G_M000_IG11:                ;; offset=0x0135
       test     rdi, rdi
       je       SHORT G_M000_IG16
 
G_M000_IG12:                ;; offset=0x013A
       mov      r8, 0x7FF9B5543E78
       cmp      qword ptr [rdi], r8
       jne      SHORT G_M000_IG16
 
G_M000_IG13:                ;; offset=0x0149
       mov      r8, gword ptr [rdi+0x10]
       test     r8, r8
       je       SHORT G_M000_IG16
 
G_M000_IG14:                ;; offset=0x0152
       mov      rdx, 0x7FF9B54EA2D8
       cmp      qword ptr [r8], rdx
       jne      SHORT G_M000_IG16
 
G_M000_IG15:                ;; offset=0x0161
       mov      gword ptr [rbp-0x128], r8
       mov      r15, gword ptr [rdi+0x08]
 
G_M000_IG16:                ;; offset=0x016C
       cmp      gword ptr [rbp-0x128], 0
       je       SHORT G_M000_IG18
 
G_M000_IG17:                ;; offset=0x0176
       test     rsi, rsi
       jne      G_M000_IG86
 
G_M000_IG18:                ;; offset=0x017F
       cmp      byte  ptr [rbx+0x30], 0
       je       SHORT G_M000_IG19
       cmp      byte  ptr [rbx+0x34], 0
       jne      G_M000_IG32
 
G_M000_IG19:                ;; offset=0x018F
       mov      rcx, bword ptr [rbp+0x10]
       mov      r8, gword ptr [rcx+0x20]
       test     r8, r8
       je       SHORT G_M000_IG20
       lea      rdx, bword ptr [r8+0x10]
       mov      r8d, dword ptr [r8+0x08]
       jmp      SHORT G_M000_IG21
 
G_M000_IG20:                ;; offset=0x01A6
       xor      rdx, rdx
       xor      r8d, r8d
 
G_M000_IG21:                ;; offset=0x01AB
       mov      bword ptr [rbp-0x100], rdx
       mov      dword ptr [rbp-0xF8], r8d
       mov      rdx, gword ptr [rbp+0x18]
       mov      gword ptr [rsp+0x20], rdx
       test     rsi, rsi
       setne    r8b
       movzx    r8, r8b
       mov      dword ptr [rsp+0x28], r8d
       lea      r8, [rbp-0xC0]
       mov      qword ptr [rsp+0x30], r8
       lea      r8, [rbp-0x100]
       mov      rdx, rdi
       mov      rcx, rbx
       mov      r9d, dword ptr [rbp+0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryInvokeBuiltinFromSlots(Lokad.Lython.Frontend.ExecutableCallSite,System.Object,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,bool,byref):bool]
       test     eax, eax
       je       G_M000_IG30
       mov      rdx, gword ptr [rbp-0xC0]
       mov      rcx, 0x7FF9B51DC748
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       mov      rbx, rax
       test     rbx, rbx
       jne      G_M000_IG28
       mov      rcx, bword ptr [rbp+0x10]
       mov      r9, gword ptr [rcx]
       mov      r9, gword ptr [r9+0x98]
       mov      edx, dword ptr [rcx+0x10]
       cmp      edx, dword ptr [r9+0x08]
       jae      G_M000_IG31
       shl      rdx, 5
       lea      r8, bword ptr [r9+rdx+0x10]
       mov      rbx, gword ptr [rbp-0xC0]
       mov      r14, qword ptr [rbp-0xB8]
       mov      edi, dword ptr [r8+0x18]
       test     edi, edi
       jge      SHORT G_M000_IG22
       mov      gword ptr [rbp-0x110], rbx
       mov      qword ptr [rbp-0x108], r14
       lea      r9, [rbp-0x110]
       mov      rdx, rsi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CompleteResultConsumer(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot)]
       jmp      SHORT G_M000_IG29
 
G_M000_IG22:                ;; offset=0x0279
       lea      rsi, bword ptr [rcx+0x20]
       mov      edx, dword ptr [r8+0x1C]
       cmp      edx, 51
       ja       SHORT G_M000_IG25
 
G_M000_IG23:                ;; offset=0x0286
       mov      rax, 0x7FFFFFFFFF9FF
       bt       rax, rdx
       jb       SHORT G_M000_IG25
 
G_M000_IG24:                ;; offset=0x0296
       mov      r15d, edi
       jmp      SHORT G_M000_IG26
 
G_M000_IG25:                ;; offset=0x029B
       mov      r15d, dword ptr [r8+0x14]
 
G_M000_IG26:                ;; offset=0x029F
       cmp      edi, dword ptr [rsi+0x40]
       jge      SHORT G_M000_IG27
       mov      rcx, rsi
       mov      edx, edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
 
G_M000_IG27:                ;; offset=0x02AF
       mov      rdx, gword ptr [rsi]
       cmp      r15d, dword ptr [rdx+0x08]
       jae      SHORT G_M000_IG31
       mov      eax, r15d
       shl      rax, 4
       lea      r15, bword ptr [rdx+rax+0x10]
       mov      rcx, r15
       mov      rdx, rbx
       call     CORINFO_HELP_ASSIGN_REF
       mov      qword ptr [r15+0x08], r14
       mov      dword ptr [rsi+0x40], edi
       jmp      SHORT G_M000_IG29
 
G_M000_IG28:                ;; offset=0x02D8
       mov      rcx, bword ptr [rbp+0x10]
       add      rcx, 32
       mov      edx, dword ptr [rbp+0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
       mov      rcx, r14
       mov      rdx, rbx
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
 
G_M000_IG29:                ;; offset=0x02F4
       mov      eax, 1
       jmp      G_M000_IG119
 
G_M000_IG30:                ;; offset=0x02FE
       xor      eax, eax
       jmp      G_M000_IG119
 
G_M000_IG31:                ;; offset=0x0305
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG32:                ;; offset=0x030B
       cmp      dword ptr [rbx+0x28], 0
       jne      SHORT G_M000_IG36
       mov      r9, gword ptr [rbx+0x20]
       test     r9, r9
       je       SHORT G_M000_IG36
 
G_M000_IG33:                ;; offset=0x031A
       mov      rcx, 0x7FF9B55445F8
       cmp      qword ptr [r9], rcx
       jne      SHORT G_M000_IG36
 
G_M000_IG34:                ;; offset=0x0329
       mov      rdx, rsi
       test     rdx, rdx
       cmove    rdx, gword ptr [rbp+0x18]
       mov      eax, dword ptr [rbp+0x30]
       mov      dword ptr [rsp+0x20], eax
       mov      gword ptr [rsp+0x28], rdi
       mov      rcx, bword ptr [rbp+0x10]
       mov      r8, rsi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteCasedSplit(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Frontend.ExecutableCasedSplit,int,System.Object):bool]
       test     eax, eax
       je       SHORT G_M000_IG36
       mov      eax, 1
 
G_M000_IG35:                ;; offset=0x0356
       add      rsp, 344
       pop      rbx
       pop      rsi
       pop      rdi
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG36:                ;; offset=0x036A
       test     rdi, rdi
       je       G_M000_IG120
 
G_M000_IG37:                ;; offset=0x0373
       mov      rcx, 0x7FF9B5544A20
       cmp      qword ptr [rdi], rcx
       jne      G_M000_IG120
 
G_M000_IG38:                ;; offset=0x0386
       mov      r9, gword ptr [rbx+0x20]
       test     r9, r9
       je       SHORT G_M000_IG41
 
G_M000_IG39:                ;; offset=0x038F
       mov      rcx, 0x7FF9B5544D28
       cmp      qword ptr [r9], rcx
       jne      SHORT G_M000_IG41
 
G_M000_IG40:                ;; offset=0x039E
       mov      gword ptr [rsp+0x20], rbx
       mov      eax, dword ptr [rbp+0x30]
       mov      dword ptr [rsp+0x28], eax
       mov      gword ptr [rsp+0x30], rdi
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rbp+0x18]
       mov      r8, rsi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteTrimmedSplit(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Frontend.ExecutableTrimmedSplit,Lokad.Lython.Frontend.ExecutableCallSite,int,System.Object):bool]
       test     eax, eax
       jne      G_M000_IG80
 
G_M000_IG41:                ;; offset=0x03C8
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rcx]
       mov      r8, gword ptr [rcx+0x20]
       test     r8, r8
       je       SHORT G_M000_IG42
       lea      r9, bword ptr [r8+0x10]
       mov      r8d, dword ptr [r8+0x08]
       jmp      SHORT G_M000_IG43
 
G_M000_IG42:                ;; offset=0x03E2
       xor      r9, r9
       xor      r8d, r8d
 
G_M000_IG43:                ;; offset=0x03E8
       lea      rax, bword ptr [rcx+0x10]
       mov      r10, rsi
       test     r10, r10
       cmove    r10, gword ptr [rbp+0x18]
       mov      bword ptr [rbp-0x120], r9
       mov      dword ptr [rbp-0x118], r8d
       mov      gword ptr [rsp+0x20], rbx
       mov      r11d, dword ptr [rbp+0x30]
       mov      dword ptr [rsp+0x28], r11d
       mov      gword ptr [rsp+0x30], r10
       lea      r8, [rbp-0xA8]
       mov      qword ptr [rsp+0x38], r8
       lea      r8, [rbp-0x120]
       mov      rcx, rdi
       mov      r9, rax
       call     [Lokad.Lython.Runtime.LythonRuntime:TryConsumePrivateStringResult(Lokad.Lython.Runtime.LythonRuntime+ReceiverMethod,Lokad.Lython.Frontend.ExecutableCodeObject,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,Lokad.Lython.Frontend.ExecutableCallSite,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       test     eax, eax
       jne      G_M000_IG73
       mov      rcx, bword ptr [rbp+0x10]
       mov      rax, gword ptr [rcx+0x20]
       mov      r11d, dword ptr [rbp+0x30]
       cmp      r11d, dword ptr [rax+0x08]
       jae      G_M000_IG85
       mov      edx, r11d
       shl      rdx, 4
       lea      rcx, bword ptr [rax+rdx+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Object():System.Object:this]
       mov      rdx, rax
       mov      rcx, 0x7FF9B54EBCC8
       call     [Lokad.Lython.Internal.NullabilityExtensions:RequireNotNull[System.__Canon](System.__Canon):System.__Canon]
       mov      r14, rax
       mov      rcx, bword ptr [rbp+0x10]
       lea      rdx, bword ptr [rcx+0x20]
       cmp      byte  ptr [rbx+0x30], 0
       setne    al
       movzx    rax, al
       mov      r11d, dword ptr [rbp+0x30]
       lea      r15d, [r11+rax+0x01]
       mov      r13d, dword ptr [rbx+0x28]
       mov      rdx, gword ptr [rdx]
       test     rdx, rdx
       je       G_M000_IG81
       mov      eax, r15d
       mov      r8d, r13d
       add      rax, r8
       mov      r8d, dword ptr [rdx+0x08]
       cmp      rax, r8
       ja       G_M000_IG81
       mov      rax, rdx
       xor      r12, r12
       xor      r8d, r8d
       test     rax, rax
 
G_M000_IG44:                ;; offset=0x04CA
       je       SHORT G_M000_IG47
       mov      rdx, qword ptr [rax]
       test     dword ptr [rdx], 0xFFFFFFFF80000000
       jne      SHORT G_M000_IG45
       lea      rdx, [rbp-0xF0]
       mov      rcx, rax
       mov      rax, qword ptr [rax]
       mov      rax, qword ptr [rax+0x40]
       call     [rax+0x28]System.Buffers.MemoryManager`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:GetSpan():System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:this
       mov      r8d, dword ptr [rbp-0xE8]
       mov      r12, bword ptr [rbp-0xF0]
       mov      eax, r8d
       jmp      SHORT G_M000_IG46
 
G_M000_IG45:                ;; offset=0x04FE
       lea      r12, bword ptr [rax+0x10]
       mov      eax, dword ptr [rax+0x08]
 
G_M000_IG46:                ;; offset=0x0505
       and      r15d, 0x7FFFFFFF
       mov      edx, r15d
       mov      r8d, r13d
       add      r8, rdx
       mov      eax, eax
       cmp      r8, rax
       ja       G_M000_IG81
       shl      rdx, 4
       add      r12, rdx
       mov      dword ptr [rbp-0xDC], r13d
       mov      r8d, dword ptr [rbp-0xDC]
 
G_M000_IG47:                ;; offset=0x0535
       cmp      dword ptr [rbx+0x2C], 0
       je       G_M000_IG51
       test     byte  ptr [(reloc 0x7ff9b5545088)], 1
       je       G_M000_IG82
 
G_M000_IG48:                ;; offset=0x054C
       mov      rdx, 0x19F7FC02B60
       cmp      rdi, gword ptr [rdx]
       jne      SHORT G_M000_IG51
       test     r14, r14
       je       SHORT G_M000_IG51
 
G_M000_IG49:                ;; offset=0x0560
       mov      rdx, 0x7FF9B5277B10
       cmp      qword ptr [r14], rdx
       jne      SHORT G_M000_IG51
 
G_M000_IG50:                ;; offset=0x056F
       cmp      r8d, 2
       jg       SHORT G_M000_IG51
       mov      r11d, dword ptr [rbp+0x30]
       mov      dword ptr [rsp+0x20], r11d
       mov      gword ptr [rsp+0x28], r14
       mov      bword ptr [rbp-0x120], r12
       mov      dword ptr [rbp-0xDC], r8d
       mov      dword ptr [rbp-0x118], r8d
       lea      rdx, [rbp-0x120]
       mov      qword ptr [rsp+0x30], rdx
       mov      rdx, rsi
       mov      r8, gword ptr [rbp+0x18]
       mov      r9, rbx
       mov      rcx, bword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteSplitUnpack(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Frontend.ExecutableCallSite,int,Lokad.Lython.Runtime.Text.PyString,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):bool]
       test     eax, eax
       mov      r8d, dword ptr [rbp-0xDC]
       jne      G_M000_IG80
 
G_M000_IG51:                ;; offset=0x05C7
       cmp      byte  ptr [rbx+0x33], 0
       jne      SHORT G_M000_IG53
 
G_M000_IG52:                ;; offset=0x05CD
       mov      dword ptr [rbp-0xDC], r8d
       jmp      G_M000_IG65
 
G_M000_IG53:                ;; offset=0x05D9
       cmp      r8d, 1
       je       SHORT G_M000_IG55
       mov      dword ptr [rbp-0xDC], r8d
       cmp      r8d, 2
       jne      G_M000_IG65
 
G_M000_IG54:                ;; offset=0x05F0
       mov      r8d, dword ptr [rbp-0xDC]
 
G_M000_IG55:                ;; offset=0x05F7
       test     byte  ptr [(reloc 0x7ff9b5545088)], 1
       je       G_M000_IG83
 
G_M000_IG56:                ;; offset=0x0604
       mov      rax, 0x19F7FC02B30
       cmp      rdi, gword ptr [rax]
       je       SHORT G_M000_IG58
 
G_M000_IG57:                ;; offset=0x0613
       mov      dword ptr [rbp-0xDC], r8d
       jmp      G_M000_IG65
 
G_M000_IG58:                ;; offset=0x061F
       test     r14, r14
       je       G_M000_IG64
 
G_M000_IG59:                ;; offset=0x0628
       mov      rax, 0x7FF9B52CBCB0
       cmp      qword ptr [r14], rax
       jne      SHORT G_M000_IG63
 
G_M000_IG60:                ;; offset=0x0637
       mov      dword ptr [rbp-0xDC], r8d
       test     r8d, r8d
       je       G_M000_IG85
       mov      r15, r12
       mov      rcx, r15
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Object():System.Object:this]
       mov      rdx, rax
       mov      rcx, r14
       call     [Lokad.Lython.Runtime.PyDict:CanReadKeySynchronously(System.Object):bool:this]
       test     eax, eax
       je       SHORT G_M000_IG65
       mov      rcx, r15
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Object():System.Object:this]
       mov      rdx, rax
       test     rdx, rdx
       je       SHORT G_M000_IG62
 
G_M000_IG61:                ;; offset=0x0674
       mov      rcx, 0x7FF9B5277B10
       cmp      qword ptr [rdx], rcx
       jne      G_M000_IG84
 
G_M000_IG62:                ;; offset=0x0687
       mov      gword ptr [rsp+0x28], rdx
       mov      rdx, gword ptr [rbp+0x18]
       mov      r8, rbx
       mov      r9d, dword ptr [rbp+0x30]
       mov      gword ptr [rsp+0x20], r14
       mov      rcx, bword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteDictionaryAccumulation(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Frontend.ExecutableCallSite,int,Lokad.Lython.Runtime.PyDict,Lokad.Lython.Runtime.Text.PyString):bool]
       test     eax, eax
       je       SHORT G_M000_IG65
       jmp      G_M000_IG80
 
G_M000_IG63:                ;; offset=0x06AF
       mov      dword ptr [rbp-0xDC], r8d
       jmp      SHORT G_M000_IG65
 
G_M000_IG64:                ;; offset=0x06B8
       mov      dword ptr [rbp-0xDC], r8d
 
G_M000_IG65:                ;; offset=0x06BF
       mov      r9, gword ptr [rbx+0x18]
       mov      rdx, rsi
       test     rdx, rdx
       cmove    rdx, gword ptr [rbp+0x18]
       mov      bword ptr [rbp-0x100], r12
       mov      r8d, dword ptr [rbp-0xDC]
       mov      dword ptr [rbp-0xF8], r8d
       mov      gword ptr [rsp+0x20], rdx
       lea      r8, [rbp-0xB0]
       mov      qword ptr [rsp+0x28], r8
       lea      r8, [rbp-0x100]
       mov      rdx, r14
       mov      rcx, rdi
       call     [Lokad.Lython.Runtime.LythonRuntime:TryInvokeClosedReceiver(Lokad.Lython.Runtime.LythonRuntime+ReceiverMethod,System.Object,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       test     eax, eax
       je       G_M000_IG72
       mov      rcx, bword ptr [rbp+0x10]
       mov      r9, gword ptr [rcx]
       mov      r9, gword ptr [r9+0x98]
       mov      edx, dword ptr [rcx+0x10]
       cmp      edx, dword ptr [r9+0x08]
       jae      G_M000_IG85
       shl      rdx, 5
       lea      r8, bword ptr [r9+rdx+0x10]
       mov      rbx, gword ptr [rbp-0xB0]
       mov      edi, dword ptr [r8+0x18]
       test     edi, edi
       jge      SHORT G_M000_IG66
       mov      gword ptr [rbp-0x110], rbx
       xor      r9d, r9d
       mov      qword ptr [rbp-0x108], r9
       lea      r9, [rbp-0x110]
       mov      rdx, rsi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CompleteResultConsumer(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot)]
       jmp      G_M000_IG80
 
G_M000_IG66:                ;; offset=0x0768
       lea      rsi, bword ptr [rcx+0x20]
       mov      edx, dword ptr [r8+0x1C]
       cmp      edx, 51
       ja       SHORT G_M000_IG69
 
G_M000_IG67:                ;; offset=0x0775
       mov      rax, 0x7FFFFFFFFF9FF
       bt       rax, rdx
       jb       SHORT G_M000_IG69
 
G_M000_IG68:                ;; offset=0x0785
       mov      r14d, edi
       jmp      SHORT G_M000_IG70
 
G_M000_IG69:                ;; offset=0x078A
       mov      r14d, dword ptr [r8+0x14]
 
G_M000_IG70:                ;; offset=0x078E
       cmp      edi, dword ptr [rsi+0x40]
       jge      SHORT G_M000_IG71
       mov      rcx, rsi
       mov      edx, edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
 
G_M000_IG71:                ;; offset=0x079E
       mov      rdx, gword ptr [rsi]
       cmp      r14d, dword ptr [rdx+0x08]
       jae      G_M000_IG85
       mov      eax, r14d
       shl      rax, 4
       lea      r14, bword ptr [rdx+rax+0x10]
       mov      rcx, r14
       mov      rdx, rbx
       call     CORINFO_HELP_ASSIGN_REF
       xor      eax, eax
       mov      qword ptr [r14+0x08], rax
       mov      dword ptr [rsi+0x40], edi
       jmp      G_M000_IG80
 
G_M000_IG72:                ;; offset=0x07D0
       xor      eax, eax
       jmp      G_M000_IG119
 
G_M000_IG73:                ;; offset=0x07D7
       mov      rcx, bword ptr [rbp+0x10]
       mov      r9, gword ptr [rcx]
       mov      r9, gword ptr [r9+0x98]
       mov      edx, dword ptr [rcx+0x10]
       cmp      edx, dword ptr [r9+0x08]
       jae      G_M000_IG85
       shl      rdx, 5
       lea      r8, bword ptr [r9+rdx+0x10]
       mov      rbx, gword ptr [rbp-0xA8]
       mov      rdi, qword ptr [rbp-0xA0]
       mov      r14d, dword ptr [r8+0x18]
       test     r14d, r14d
       jge      SHORT G_M000_IG74
       mov      gword ptr [rbp-0x110], rbx
       mov      qword ptr [rbp-0x108], rdi
       lea      r9, [rbp-0x110]
       mov      rdx, rsi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CompleteResultConsumer(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot)]
       jmp      SHORT G_M000_IG80
 
G_M000_IG74:                ;; offset=0x0832
       lea      rsi, bword ptr [rcx+0x20]
       mov      edx, dword ptr [r8+0x1C]
       cmp      edx, 51
       ja       SHORT G_M000_IG77
 
G_M000_IG75:                ;; offset=0x083F
       mov      rax, 0x7FFFFFFFFF9FF
       bt       rax, rdx
       jb       SHORT G_M000_IG77
 
G_M000_IG76:                ;; offset=0x084F
       mov      r15d, r14d
       jmp      SHORT G_M000_IG78
 
G_M000_IG77:                ;; offset=0x0854
       mov      r15d, dword ptr [r8+0x14]
 
G_M000_IG78:                ;; offset=0x0858
       cmp      r14d, dword ptr [rsi+0x40]
       jge      SHORT G_M000_IG79
       mov      rcx, rsi
       mov      edx, r14d
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
 
G_M000_IG79:                ;; offset=0x086A
       mov      rdx, gword ptr [rsi]
       cmp      r15d, dword ptr [rdx+0x08]
       jae      G_M000_IG85
       mov      eax, r15d
       shl      rax, 4
       lea      r15, bword ptr [rdx+rax+0x10]
       mov      rcx, r15
       mov      rdx, rbx
       call     CORINFO_HELP_ASSIGN_REF
       mov      qword ptr [r15+0x08], rdi
       mov      dword ptr [rsi+0x40], r14d
 
G_M000_IG80:                ;; offset=0x0896
       mov      eax, 1
       jmp      G_M000_IG119
 
G_M000_IG81:                ;; offset=0x08A0
       call     [System.ThrowHelper:ThrowArgumentOutOfRangeException()]
       int3     
 
G_M000_IG82:                ;; offset=0x08A7
       mov      dword ptr [rbp-0xDC], r8d
       mov      rcx, 0x7FF9B5545020
       call     CORINFO_HELP_GET_GCSTATIC_BASE
       mov      r8d, dword ptr [rbp-0xDC]
       jmp      G_M000_IG48
 
G_M000_IG83:                ;; offset=0x08C9
       mov      dword ptr [rbp-0xDC], r8d
       mov      rcx, 0x7FF9B5545020
       call     CORINFO_HELP_GET_GCSTATIC_BASE
       mov      r8d, dword ptr [rbp-0xDC]
       jmp      G_M000_IG56
 
G_M000_IG84:                ;; offset=0x08EB
       mov      rdx, rax
       call     CORINFO_HELP_CHKCASTCLASS
       int3     
 
G_M000_IG85:                ;; offset=0x08F4
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG86:                ;; offset=0x08FA
       lea      r9, [rbp-0x40]
       mov      rcx, gword ptr [rbp-0x128]
       mov      rdx, rbx
       mov      r8, r15
       call     [Lokad.Lython.Runtime.PyExecutableFunction:TrySelectNativeCall(Lokad.Lython.Frontend.ExecutableCallSite,System.Object,byref):bool:this]
       test     eax, eax
       je       G_M000_IG120
       xor      ecx, ecx
       mov      dword ptr [rbp-0x44], ecx
 
G_M000_IG87:                ;; offset=0x091E
       mov      rdx, gword ptr [rbx+0x18]
       mov      rax, gword ptr [rbp+0x18]
       mov      rcx, gword ptr [rax+0xA0]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.ExecutionState:EnterInterpreterFrame(Lokad.Lython.LythonSourceSpan):this]
       mov      dword ptr [rbp-0x44], 1
       mov      rdi, gword ptr [rbx+0x18]
       mov      rax, gword ptr [rbp+0x18]
       mov      r13, gword ptr [rax+0xA0]
       cmp      byte  ptr [r13], r13b
       mov      rcx, r13
       call     [Lokad.Lython.Runtime.ExecutionState:get_CanContinue():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG88
       mov      rcx, r13
       mov      rdx, rdi
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
 
G_M000_IG88:                ;; offset=0x0968
       mov      rcx, bword ptr [rbp+0x10]
       lea      rdx, bword ptr [rcx+0x20]
       cmp      byte  ptr [rbx+0x30], 0
       setne    al
       movzx    rax, al
       mov      r11d, dword ptr [rbp+0x30]
       lea      edi, [r11+rax+0x01]
       mov      r13d, dword ptr [rbx+0x28]
       mov      rdx, gword ptr [rdx]
       test     rdx, rdx
       je       SHORT G_M000_IG89
       mov      eax, edi
       mov      r8d, r13d
       add      rax, r8
       mov      r8d, dword ptr [rdx+0x08]
       cmp      rax, r8
       ja       G_M000_IG117
       mov      rax, rdx
       jmp      SHORT G_M000_IG90
 
G_M000_IG89:                ;; offset=0x09A9
       mov      eax, edi
       or       eax, r13d
       jne      G_M000_IG117
       xor      rax, rax
       xor      edi, edi
       xor      r13d, r13d
 
G_M000_IG90:                ;; offset=0x09BB
       xor      r12, r12
       xor      r8d, r8d
       test     rax, rax
       je       SHORT G_M000_IG93
       mov      rdx, qword ptr [rax]
       test     dword ptr [rdx], 0xFFFFFFFF80000000
       jne      SHORT G_M000_IG91
       lea      rdx, [rbp-0xD8]
       mov      rcx, rax
       mov      rax, qword ptr [rax]
       mov      rax, qword ptr [rax+0x40]
       call     [rax+0x28]System.Buffers.MemoryManager`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:GetSpan():System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:this
       mov      r8d, dword ptr [rbp-0xD0]
       mov      r12, bword ptr [rbp-0xD8]
       mov      eax, r8d
       jmp      SHORT G_M000_IG92
 
G_M000_IG91:                ;; offset=0x09F8
       lea      r12, bword ptr [rax+0x10]
       mov      eax, dword ptr [rax+0x08]
 
G_M000_IG92:                ;; offset=0x09FF
       and      edi, 0x7FFFFFFF
       mov      edx, edi
       mov      r9d, r13d
       add      r9, rdx
       mov      eax, eax
       cmp      r9, rax
       ja       G_M000_IG117
       shl      rdx, 4
       add      r12, rdx
       mov      eax, r13d
       mov      r8d, eax
 
G_M000_IG93:                ;; offset=0x0A25
       cmp      byte  ptr [rbp-0x40], 0
       jne      SHORT G_M000_IG95
 
G_M000_IG94:                ;; offset=0x0A2B
       mov      dword ptr [rbp-0xC4], r8d
       jmp      SHORT G_M000_IG96
 
G_M000_IG95:                ;; offset=0x0A34
       mov      bword ptr [rbp-0x120], r12
       mov      dword ptr [rbp-0xC4], r8d
       mov      dword ptr [rbp-0x118], r8d
       lea      rdx, [rbp-0x58]
       mov      qword ptr [rsp+0x20], rdx
       lea      rdx, [rbp-0x120]
       mov      r9, gword ptr [rbx+0x18]
       mov      rcx, gword ptr [rbp-0x128]
       mov      r8, r15
       call     [Lokad.Lython.Runtime.PyExecutableFunction:TryStartSuppliedIntegerReturn(System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.Object,Lokad.Lython.LythonSourceSpan,byref):bool:this]
       test     eax, eax
       jne      G_M000_IG113
 
G_M000_IG96:                ;; offset=0x0A75
       lea      rcx, [rbp-0x70]
       mov      qword ptr [rsp+0x20], rcx
       lea      rcx, [rbp-0x68]
       mov      rdx, bword ptr [rbp+0x10]
       mov      r8, rbx
       mov      r9d, dword ptr [rbp+0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PrepareUnpackedCallReturn(byref,Lokad.Lython.Frontend.ExecutableCallSite,int,byref):System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]]
       mov      r8, gword ptr [rbx+0x18]
       cmp      byte  ptr [rbx+0x31], 0
       je       SHORT G_M000_IG97
       mov      r9d, 1
       jmp      SHORT G_M000_IG99
 
G_M000_IG97:                ;; offset=0x0AA5
       mov      rdx, bword ptr [rbp+0x10]
       cmp      byte  ptr [rdx+0x14], 0
       jne      SHORT G_M000_IG98
       xor      r9d, r9d
       jmp      SHORT G_M000_IG99
 
G_M000_IG98:                ;; offset=0x0AB4
       movzx    r9, byte  ptr [rbx+0x32]
 
G_M000_IG99:                ;; offset=0x0AB9
       mov      bword ptr [rbp-0x120], r12
       mov      r13d, dword ptr [rbp-0xC4]
       mov      dword ptr [rbp-0x118], r13d
       mov      rax, gword ptr [rbp+0x18]
       mov      gword ptr [rsp+0x20], rax
       mov      gword ptr [rsp+0x28], r8
       mov      dword ptr [rsp+0x30], r9d
       movzx    r9, byte  ptr [rbp-0x40]
 
G_M000_IG100:                ;; offset=0x0AE6
       vmovdqu  xmm0, xmmword ptr [rbp-0x68]
       vmovdqu  xmmword ptr [rbp-0x100], xmm0
 
G_M000_IG101:                ;; offset=0x0AF3
       lea      r8, [rbp-0x78]
       mov      qword ptr [rsp+0x48], r8
       lea      r8, [rbp-0x88]
       mov      qword ptr [rsp+0x50], r8
       lea      r8, [rbp-0x90]
       mov      qword ptr [rsp+0x58], r8
       lea      r8, [rbp-0x120]
       mov      dword ptr [rsp+0x38], r9d
       lea      r9, [rbp-0x100]
       mov      qword ptr [rsp+0x40], r9
       mov      r9, r15
       mov      rdx, rbx
       mov      rcx, gword ptr [rbp-0x128]
       call     [Lokad.Lython.Runtime.PyExecutableFunction:StartNativeCall(Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,bool,bool,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,byref,byref):this]
       cmp      byte  ptr [rbp-0x78], 0
       jne      SHORT G_M000_IG102
       mov      rdx, bword ptr [rbp+0x10]
       lea      rcx, bword ptr [rdx+0x20]
       mov      eax, dword ptr [rbp-0x70]
       mov      dword ptr [rcx+0x40], eax
 
G_M000_IG102:                ;; offset=0x0B53
       cmp      gword ptr [rbp-0x90], 0
       jne      G_M000_IG110
       mov      rax, gword ptr [rbp+0x18]
       mov      rcx, gword ptr [rax+0xA0]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.ExecutionState:LeaveInterpreterFrame():this]
       xor      r9d, r9d
       mov      dword ptr [rbp-0x44], r9d
       cmp      byte  ptr [rbp-0x78], 0
       jne      G_M000_IG109
       mov      rdx, bword ptr [rbp+0x10]
       mov      r9, gword ptr [rdx]
       mov      r9, gword ptr [r9+0x98]
       mov      r8d, dword ptr [rdx+0x10]
       cmp      r8d, dword ptr [r9+0x08]
       jae      G_M000_IG118
       shl      r8, 5
       lea      r8, bword ptr [r9+r8+0x10]
       mov      r14, gword ptr [rbp-0x88]
       mov      rdi, qword ptr [rbp-0x80]
       mov      r15d, dword ptr [r8+0x18]
       test     r15d, r15d
       jge      SHORT G_M000_IG103
       mov      gword ptr [rbp-0x110], r14
       mov      qword ptr [rbp-0x108], rdi
       lea      r9, [rbp-0x110]
       mov      rdx, rsi
       mov      rcx, bword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CompleteResultConsumer(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot)]
       jmp      G_M000_IG116
 
G_M000_IG103:                ;; offset=0x0BE5
       mov      rdx, bword ptr [rbp+0x10]
       lea      rsi, bword ptr [rdx+0x20]
       mov      ecx, dword ptr [r8+0x1C]
       cmp      ecx, 51
       ja       SHORT G_M000_IG106
 
G_M000_IG104:                ;; offset=0x0BF6
       mov      rax, 0x7FFFFFFFFF9FF
       bt       rax, rcx
       jb       SHORT G_M000_IG106
 
G_M000_IG105:                ;; offset=0x0C06
       mov      r13d, r15d
       jmp      SHORT G_M000_IG107
 
G_M000_IG106:                ;; offset=0x0C0B
       mov      r13d, dword ptr [r8+0x14]
 
G_M000_IG107:                ;; offset=0x0C0F
       cmp      r15d, dword ptr [rsi+0x40]
       jge      SHORT G_M000_IG108
       mov      rcx, rsi
       mov      edx, r15d
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
 
G_M000_IG108:                ;; offset=0x0C21
       mov      rcx, gword ptr [rsi]
       cmp      r13d, dword ptr [rcx+0x08]
       jae      G_M000_IG118
       mov      eax, r13d
       shl      rax, 4
       lea      r13, bword ptr [rcx+rax+0x10]
       mov      rcx, r13
       mov      rdx, r14
       call     CORINFO_HELP_ASSIGN_REF
       mov      qword ptr [r13+0x08], rdi
       mov      dword ptr [rsi+0x40], r15d
       jmp      G_M000_IG116
 
G_M000_IG109:                ;; offset=0x0C52
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rbp+0x18]
       mov      r8d, dword ptr [rbp+0x30]
       mov      r9d, dword ptr [rbp-0x60]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CompleteUnpackedCallReturn(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,int,int)]
       jmp      G_M000_IG116
 
G_M000_IG110:                ;; offset=0x0C6D
       mov      rcx, gword ptr [rbp-0x90]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:EnterExecutableSlots():this]
       mov      rdi, gword ptr [rbp-0x90]
       mov      rcx, gword ptr [rbp-0x128]
       mov      rcx, gword ptr [rcx+0x28]
       mov      rcx, gword ptr [rcx+0xA0]
       mov      r15, gword ptr [rcx+0x88]
       lea      rcx, bword ptr [rsi+0x30]
       mov      rdx, rbx
       call     CORINFO_HELP_ASSIGN_REF
       xor      rcx, rcx
       mov      gword ptr [rsi+0x40], rcx
       mov      r9d, dword ptr [rbp+0x30]
       mov      dword ptr [rsi+0xF0], r9d
 
G_M000_IG111:                ;; offset=0x0CB9
       mov      dword ptr [rsi+0xF4], ecx
       lea      rcx, bword ptr [rdi+0x20]
       mov      rdx, rsi
       call     CORINFO_HELP_ASSIGN_REF
       lea      rcx, bword ptr [rdi+0x28]
       mov      rdx, r15
       call     CORINFO_HELP_ASSIGN_REF
       nop      
 
G_M000_IG112:                ;; offset=0x0CD8
       mov      rdx, gword ptr [rbp-0x90]
       mov      rcx, r14
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       xor      ecx, ecx
       mov      dword ptr [rbp-0x44], ecx
       jmp      SHORT G_M000_IG116
 
G_M000_IG113:                ;; offset=0x0CEE
       mov      rdx, gword ptr [rbp+0x18]
       mov      rcx, gword ptr [rdx+0xA0]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.ExecutionState:LeaveInterpreterFrame():this]
       xor      r9d, r9d
       mov      dword ptr [rbp-0x44], r9d
 
G_M000_IG114:                ;; offset=0x0D08
       vmovdqu  xmm0, xmmword ptr [rbp-0x58]
       vmovdqu  xmmword ptr [rbp-0x110], xmm0
 
G_M000_IG115:                ;; offset=0x0D15
       lea      r9, [rbp-0x110]
       mov      rdx, gword ptr [rbp+0x18]
       mov      r8, rsi
       mov      rcx, bword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PublishDirectIntegerCall(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot)]
 
G_M000_IG116:                ;; offset=0x0D2D
       mov      eax, 1
       jmp      SHORT G_M000_IG119
 
G_M000_IG117:                ;; offset=0x0D34
       call     [System.ThrowHelper:ThrowArgumentOutOfRangeException()]
       int3     
 
G_M000_IG118:                ;; offset=0x0D3B
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG119:                ;; offset=0x0D41
       add      rsp, 344
       pop      rbx
       pop      rsi
       pop      rdi
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG120:                ;; offset=0x0D55
       xor      eax, eax
 
G_M000_IG121:                ;; offset=0x0D57
       add      rsp, 344
       pop      rbx
       pop      rsi
       pop      rdi
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG122:                ;; offset=0x0D6B
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG123:                ;; offset=0x0D71
       sub      rsp, 104
 
G_M000_IG124:                ;; offset=0x0D75
       mov      r14, gword ptr [rbp-0x90]
       mov      rcx, gword ptr [rbp-0x128]
       call     [Lokad.Lython.Runtime.PyExecutableFunction:get_DefinitionContext():Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:this]
       mov      rcx, rax
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:get_MemoryGovernor():Lokad.Lython.Runtime.MemoryGovernor:this]
       mov      rdx, rax
       mov      rcx, r14
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:AbortPreparedCall(Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.MemoryGovernor)]
       call     CORINFO_HELP_RETHROW
       int3     
 
G_M000_IG125:                ;; offset=0x0DA6
       sub      rsp, 104
 
G_M000_IG126:                ;; offset=0x0DAA
       mov      rbx, rcx
       mov      rcx, bword ptr [rbp+0x10]
       cmp      byte  ptr [rcx], cl
       add      rcx, 32
       mov      edx, dword ptr [rbp+0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
       mov      rcx, gword ptr [rbp+0x28]
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_CallSpan():Lokad.Lython.LythonSourceSpan:this]
       mov      rdx, rax
       lea      r8, [rbp-0x98]
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime:TryTranslateCallableException(System.Exception,Lokad.Lython.LythonSourceSpan,byref):bool]
       test     eax, eax
       je       SHORT G_M000_IG127
       mov      rcx, gword ptr [rbp-0x98]
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG127:                ;; offset=0x0DEE
       call     CORINFO_HELP_RETHROW
       int3     
 
G_M000_IG128:                ;; offset=0x0DF4
       sub      rsp, 104
 
G_M000_IG129:                ;; offset=0x0DF8
       cmp      dword ptr [rbp-0x44], 0
       je       SHORT G_M000_IG130
       mov      rdx, gword ptr [rbp+0x18]
       mov      rcx, gword ptr [rdx+0xA0]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.ExecutionState:LeaveInterpreterFrame():this]
 
G_M000_IG130:                ;; offset=0x0E11
       nop      
 
G_M000_IG131:                ;; offset=0x0E12
       add      rsp, 104
       ret      
 
G_M000_IG132:                ;; offset=0x0E17
       sub      rsp, 104
 
G_M000_IG133:                ;; offset=0x0E1B
       mov      rcx, bword ptr [rbp+0x10]
       cmp      byte  ptr [rcx], cl
       add      rcx, 32
       mov      edx, dword ptr [rbp+0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
       call     CORINFO_HELP_RETHROW
       int3     
 
G_M000_IG134:                ;; offset=0x0E34
       sub      rsp, 104
 
G_M000_IG135:                ;; offset=0x0E38
       mov      rcx, bword ptr [rbp+0x10]
       cmp      byte  ptr [rcx], cl
       add      rcx, 32
       mov      edx, dword ptr [rbp+0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
       call     CORINFO_HELP_RETHROW
       int3     
 
; Total bytes of code 3665

; Assembly listing for method Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryLoadDirectCallReceiver(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool (FullOpts)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; FullOpts code
; optimized code
; rsp based frame
; partially interruptible
; No PGO data
; 0 inlinees with PGO data; 42 single block inlinees; 23 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     r15
       push     r14
       push     r13
       push     rdi
       push     rsi
       push     rbp
       push     rbx
       sub      rsp, 80
       vxorps   xmm4, xmm4, xmm4
       vmovdqu  xmmword ptr [rsp+0x38], xmm4
       xor      eax, eax
       mov      qword ptr [rsp+0x48], rax
       mov      rsi, rcx
       mov      rdi, rdx
       mov      rbp, r8
       mov      rbx, r9
 
G_M000_IG02:                ;; offset=0x002B
       cmp      dword ptr [rbx+0x1C], 23
       jne      G_M000_IG65
 
G_M000_IG03:                ;; offset=0x0035
       mov      rcx, gword ptr [rsi]
       mov      r14, gword ptr [rcx+0x38]
       mov      rcx, rbx
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_NameIndex():int:this]
       cmp      eax, dword ptr [r14+0x08]
       jae      G_M000_IG67
       mov      edx, eax
       mov      r14, gword ptr [r14+8*rdx+0x10]
       mov      r8d, dword ptr [rbx+0x10]
       mov      rcx, gword ptr [rsi]
       mov      rdx, gword ptr [rsi+0x20]
       test     rdx, rdx
       je       SHORT G_M000_IG04
       lea      r9, bword ptr [rdx+0x10]
       mov      edx, dword ptr [rdx+0x08]
       jmp      SHORT G_M000_IG05
 
G_M000_IG04:                ;; offset=0x006F
       xor      r9, r9
       xor      edx, edx
 
G_M000_IG05:                ;; offset=0x0074
       mov      bword ptr [rsp+0x38], r9
       mov      dword ptr [rsp+0x40], edx
       xor      edx, edx
       mov      dword ptr [rsp+0x20], edx
       mov      gword ptr [rsp+0x28], rdi
       lea      rdx, [rsp+0x38]
       mov      r9d, dword ptr [rsi+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime:ReadExecutableOperand(Lokad.Lython.Frontend.ExecutableCodeObject,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],int,int,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):System.Object]
       mov      rdi, rax
       test     rbp, rbp
       je       G_M000_IG35
       test     rdi, rdi
       je       G_M000_IG35
 
G_M000_IG06:                ;; offset=0x00AC
       mov      r8, 0x7FF9B54EF0A8
       cmp      qword ptr [rdi], r8
       jne      G_M000_IG35
 
G_M000_IG07:                ;; offset=0x00BF
       lea      r8, [rsp+0x48]
       mov      rcx, rdi
       mov      rdx, r14
       call     [Lokad.Lython.Runtime.PyAttributeLookup:TryResolveInstanceFunctionForCall(Lokad.Lython.Runtime.PyInstance,System.String,byref):bool]
       test     eax, eax
       je       G_M000_IG35
       mov      ecx, dword ptr [rbx+0x10]
       mov      edx, dword ptr [rbx+0x1C]
       mov      eax, edx
       cmp      eax, 51
       ja       SHORT G_M000_IG11
 
G_M000_IG08:                ;; offset=0x00E5
       mov      r8, 0x7FFFFFFFFF9FF
       bt       r8, rax
       jb       SHORT G_M000_IG11
 
G_M000_IG09:                ;; offset=0x00F5
       mov      eax, dword ptr [rbx+0x18]
       test     eax, eax
       jge      SHORT G_M000_IG10
       not      eax
 
G_M000_IG10:                ;; offset=0x00FE
       jmp      SHORT G_M000_IG12
 
G_M000_IG11:                ;; offset=0x0100
       mov      eax, dword ptr [rbx+0x14]
 
G_M000_IG12:                ;; offset=0x0103
       cmp      ecx, eax
       je       G_M000_IG26
       lea      r14, bword ptr [rsi+0x20]
       mov      ecx, edx
       cmp      ecx, 51
       ja       SHORT G_M000_IG17
 
G_M000_IG13:                ;; offset=0x0116
       mov      rax, 0x7FFFFFFFFF9FF
       bt       rax, rcx
       jb       SHORT G_M000_IG17
 
G_M000_IG14:                ;; offset=0x0126
       mov      eax, dword ptr [rbx+0x18]
       test     eax, eax
       jge      SHORT G_M000_IG15
       mov      ebp, eax
       not      ebp
       jmp      SHORT G_M000_IG16
 
G_M000_IG15:                ;; offset=0x0133
       mov      ebp, eax
 
G_M000_IG16:                ;; offset=0x0135
       jmp      SHORT G_M000_IG18
 
G_M000_IG17:                ;; offset=0x0137
       mov      ebp, dword ptr [rbx+0x14]
 
G_M000_IG18:                ;; offset=0x013A
       cmp      edx, 51
       ja       SHORT G_M000_IG23
 
G_M000_IG19:                ;; offset=0x013F
       mov      rax, 0x7FFFFFFFFF9FF
       bt       rax, rdx
       jb       SHORT G_M000_IG23
 
G_M000_IG20:                ;; offset=0x014F
       mov      eax, dword ptr [rbx+0x18]
       test     eax, eax
       jge      SHORT G_M000_IG21
       mov      r15d, eax
       not      r15d
       jmp      SHORT G_M000_IG22
 
G_M000_IG21:                ;; offset=0x015E
       mov      r15d, eax
 
G_M000_IG22:                ;; offset=0x0161
       jmp      SHORT G_M000_IG24
 
G_M000_IG23:                ;; offset=0x0163
       mov      r15d, dword ptr [rbx+0x14]
 
G_M000_IG24:                ;; offset=0x0167
       inc      r15d
       cmp      r15d, dword ptr [r14+0x40]
       jge      SHORT G_M000_IG25
       mov      rcx, r14
       mov      edx, r15d
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
 
G_M000_IG25:                ;; offset=0x017C
       mov      rcx, gword ptr [r14]
       cmp      ebp, dword ptr [rcx+0x08]
       jae      G_M000_IG67
       mov      edx, ebp
       shl      rdx, 4
       lea      rbp, bword ptr [rcx+rdx+0x10]
       mov      rcx, rbp
       mov      rdx, rdi
       call     CORINFO_HELP_ASSIGN_REF
       xor      ecx, ecx
       mov      qword ptr [rbp+0x08], rcx
       mov      dword ptr [r14+0x40], r15d
 
G_M000_IG26:                ;; offset=0x01A8
       add      rsi, 32
       mov      ecx, dword ptr [rbx+0x1C]
       cmp      ecx, 51
       ja       SHORT G_M000_IG30
 
G_M000_IG27:                ;; offset=0x01B4
       mov      rdx, 0x7FFFFFFFFF9FF
       bt       rdx, rcx
       jb       SHORT G_M000_IG30
 
G_M000_IG28:                ;; offset=0x01C4
       mov      edi, dword ptr [rbx+0x18]
       test     edi, edi
       jge      SHORT G_M000_IG29
       not      edi
 
G_M000_IG29:                ;; offset=0x01CD
       jmp      SHORT G_M000_IG31
 
G_M000_IG30:                ;; offset=0x01CF
       mov      edi, dword ptr [rbx+0x14]
 
G_M000_IG31:                ;; offset=0x01D2
       inc      edi
       mov      ecx, dword ptr [rbx+0x18]
       test     ecx, ecx
       jge      SHORT G_M000_IG32
       mov      ebx, ecx
       not      ebx
       jmp      SHORT G_M000_IG33
 
G_M000_IG32:                ;; offset=0x01E1
       mov      ebx, ecx
 
G_M000_IG33:                ;; offset=0x01E3
       mov      rbp, gword ptr [rsp+0x48]
       cmp      ebx, dword ptr [rsi+0x40]
       jge      SHORT G_M000_IG34
       mov      rcx, rsi
       mov      edx, ebx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
 
G_M000_IG34:                ;; offset=0x01F8
       mov      rcx, gword ptr [rsi]
       cmp      edi, dword ptr [rcx+0x08]
       jae      G_M000_IG67
       mov      edx, edi
       shl      rdx, 4
       lea      rdi, bword ptr [rcx+rdx+0x10]
       mov      rcx, rdi
       mov      rdx, rbp
       call     CORINFO_HELP_ASSIGN_REF
       xor      ecx, ecx
       mov      qword ptr [rdi+0x08], rcx
       mov      dword ptr [rsi+0x40], ebx
       jmp      G_M000_IG63
 
G_M000_IG35:                ;; offset=0x0228
       mov      rcx, rdi
       mov      rdx, r14
       call     [Lokad.Lython.Runtime.LythonRuntime:ResolveBuiltinReceiverMethod(System.Object,System.String):Lokad.Lython.Runtime.LythonRuntime+ReceiverMethod]
       mov      rbp, rax
       test     rbp, rbp
       je       G_M000_IG65
       mov      ecx, dword ptr [rbx+0x10]
       mov      edx, dword ptr [rbx+0x1C]
       mov      eax, edx
       cmp      eax, 51
       ja       SHORT G_M000_IG39
 
G_M000_IG36:                ;; offset=0x024D
       mov      r8, 0x7FFFFFFFFF9FF
       bt       r8, rax
       jb       SHORT G_M000_IG39
 
G_M000_IG37:                ;; offset=0x025D
       mov      eax, dword ptr [rbx+0x18]
       test     eax, eax
       jge      SHORT G_M000_IG38
       not      eax
 
G_M000_IG38:                ;; offset=0x0266
       jmp      SHORT G_M000_IG40
 
G_M000_IG39:                ;; offset=0x0268
       mov      eax, dword ptr [rbx+0x14]
 
G_M000_IG40:                ;; offset=0x026B
       cmp      ecx, eax
       je       G_M000_IG54
       lea      r14, bword ptr [rsi+0x20]
       mov      ecx, edx
       cmp      ecx, 51
       ja       SHORT G_M000_IG45
 
G_M000_IG41:                ;; offset=0x027E
       mov      rax, 0x7FFFFFFFFF9FF
       bt       rax, rcx
       jb       SHORT G_M000_IG45
 
G_M000_IG42:                ;; offset=0x028E
       mov      eax, dword ptr [rbx+0x18]
       test     eax, eax
       jge      SHORT G_M000_IG43
       mov      r15d, eax
       not      r15d
       jmp      SHORT G_M000_IG44
 
G_M000_IG43:                ;; offset=0x029D
       mov      r15d, eax
 
G_M000_IG44:                ;; offset=0x02A0
       jmp      SHORT G_M000_IG46
 
G_M000_IG45:                ;; offset=0x02A2
       mov      r15d, dword ptr [rbx+0x14]
 
G_M000_IG46:                ;; offset=0x02A6
       cmp      edx, 51
       ja       SHORT G_M000_IG51
 
G_M000_IG47:                ;; offset=0x02AB
       mov      rax, 0x7FFFFFFFFF9FF
       bt       rax, rdx
       jb       SHORT G_M000_IG51
 
G_M000_IG48:                ;; offset=0x02BB
       mov      eax, dword ptr [rbx+0x18]
       test     eax, eax
       jge      SHORT G_M000_IG49
       mov      r13d, eax
       not      r13d
       jmp      SHORT G_M000_IG50
 
G_M000_IG49:                ;; offset=0x02CA
       mov      r13d, eax
 
G_M000_IG50:                ;; offset=0x02CD
       jmp      SHORT G_M000_IG52
 
G_M000_IG51:                ;; offset=0x02CF
       mov      r13d, dword ptr [rbx+0x14]
 
G_M000_IG52:                ;; offset=0x02D3
       inc      r13d
       cmp      r13d, dword ptr [r14+0x40]
       jge      SHORT G_M000_IG53
       mov      rcx, r14
       mov      edx, r13d
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
 
G_M000_IG53:                ;; offset=0x02E8
       mov      rcx, gword ptr [r14]
       cmp      r15d, dword ptr [rcx+0x08]
       jae      G_M000_IG67
       mov      edx, r15d
       shl      rdx, 4
       lea      r15, bword ptr [rcx+rdx+0x10]
       mov      rcx, r15
       mov      rdx, rdi
       call     CORINFO_HELP_ASSIGN_REF
       xor      ecx, ecx
       mov      qword ptr [r15+0x08], rcx
       mov      dword ptr [r14+0x40], r13d
 
G_M000_IG54:                ;; offset=0x0316
       add      rsi, 32
       mov      ecx, dword ptr [rbx+0x1C]
       cmp      ecx, 51
       ja       SHORT G_M000_IG58
 
G_M000_IG55:                ;; offset=0x0322
       mov      rdx, 0x7FFFFFFFFF9FF
       bt       rdx, rcx
       jb       SHORT G_M000_IG58
 
G_M000_IG56:                ;; offset=0x0332
       mov      edi, dword ptr [rbx+0x18]
       test     edi, edi
       jge      SHORT G_M000_IG57
       not      edi
 
G_M000_IG57:                ;; offset=0x033B
       jmp      SHORT G_M000_IG59
 
G_M000_IG58:                ;; offset=0x033D
       mov      edi, dword ptr [rbx+0x14]
 
G_M000_IG59:                ;; offset=0x0340
       inc      edi
       mov      ecx, dword ptr [rbx+0x18]
       test     ecx, ecx
       jge      SHORT G_M000_IG60
       mov      ebx, ecx
       not      ebx
       jmp      SHORT G_M000_IG61
 
G_M000_IG60:                ;; offset=0x034F
       mov      ebx, ecx
 
G_M000_IG61:                ;; offset=0x0351
       cmp      ebx, dword ptr [rsi+0x40]
       jge      SHORT G_M000_IG62
       mov      rcx, rsi
       mov      edx, ebx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
 
G_M000_IG62:                ;; offset=0x0361
       mov      rcx, gword ptr [rsi]
       cmp      edi, dword ptr [rcx+0x08]
       jae      SHORT G_M000_IG67
       mov      edx, edi
       shl      rdx, 4
       lea      rdi, bword ptr [rcx+rdx+0x10]
       mov      rcx, rdi
       mov      rdx, rbp
       call     CORINFO_HELP_ASSIGN_REF
       xor      eax, eax
       mov      qword ptr [rdi+0x08], rax
       mov      dword ptr [rsi+0x40], ebx
 
G_M000_IG63:                ;; offset=0x0388
       mov      eax, 1
 
G_M000_IG64:                ;; offset=0x038D
       add      rsp, 80
       pop      rbx
       pop      rbp
       pop      rsi
       pop      rdi
       pop      r13
       pop      r14
       pop      r15
       ret      
 
G_M000_IG65:                ;; offset=0x039C
       xor      eax, eax
 
G_M000_IG66:                ;; offset=0x039E
       add      rsp, 80
       pop      rbx
       pop      rbp
       pop      rsi
       pop      rdi
       pop      r13
       pop      r14
       pop      r15
       ret      
 
G_M000_IG67:                ;; offset=0x03AD
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
; Total bytes of code 947

; Assembly listing for method Lokad.Lython.Runtime.LythonRuntime+NativeExecution:RunCore(byref):bool:this (FullOpts)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; FullOpts code
; optimized code
; rsp based frame
; partially interruptible
; No PGO data
; 0 inlinees with PGO data; 167 single block inlinees; 46 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     r15
       push     r14
       push     r13
       push     rdi
       push     rsi
       push     rbp
       push     rbx
       sub      rsp, 224
       xor      eax, eax
       mov      qword ptr [rsp+0x38], rax
       vxorps   xmm4, xmm4, xmm4
       vmovdqu  ymmword ptr [rsp+0x40], ymm4
       vmovdqu  ymmword ptr [rsp+0x60], ymm4
       vmovdqu  ymmword ptr [rsp+0x80], ymm4
       vmovdqu  ymmword ptr [rsp+0xA0], ymm4
       vmovdqu  ymmword ptr [rsp+0xC0], ymm4
       mov      rbx, rcx
       mov      rsi, rdx
 
G_M000_IG02:                ;; offset=0x0049
       mov      rcx, 0x19F7FC01F50
       mov      rdx, gword ptr [rcx]
       mov      rcx, rsi
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       xor      ecx, ecx
       mov      qword ptr [rsi+0x08], rcx
       mov      ecx, dword ptr [rbx+0x38]
       mov      rax, gword ptr [rbx+0x08]
       cmp      ecx, dword ptr [rax+0xEC]
       jge      G_M000_IG149
 
G_M000_IG03:                ;; offset=0x0077
       mov      rcx, gword ptr [rbx+0x08]
       mov      rcx, gword ptr [rcx+0x98]
       mov      eax, dword ptr [rbx+0x38]
       cmp      eax, dword ptr [rcx+0x08]
       jae      G_M000_IG221
       shl      rax, 5
       lea      rdi, bword ptr [rcx+rax+0x10]
       mov      rcx, gword ptr [rbx+0x10]
       mov      rbp, gword ptr [rcx+0xA0]
       mov      r14, gword ptr [rdi]
       cmp      byte  ptr [rbp], bpl
       mov      rcx, rbp
       call     [Lokad.Lython.Runtime.ExecutionState:get_CanContinue():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG05
 
G_M000_IG04:                ;; offset=0x00B6
       mov      rcx, rbp
       mov      rdx, r14
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
 
G_M000_IG05:                ;; offset=0x00C2
       mov      ebp, dword ptr [rdi+0x1C]
       lea      ecx, [rbp-0x01]
       cmp      ecx, 74
       ja       SHORT G_M000_IG07
 
G_M000_IG06:                ;; offset=0x00CD
       mov      ecx, ecx
       lea      rdx, [reloc @RWD00]
       mov      edx, dword ptr [rdx+4*rcx]
       lea      r8, G_M000_IG02
       add      rdx, r8
       jmp      rdx
 
G_M000_IG07:                ;; offset=0x00E5
       xor      eax, eax
 
G_M000_IG08:                ;; offset=0x00E7
       add      rsp, 224
       pop      rbx
       pop      rbp
       pop      rsi
       pop      rdi
       pop      r13
       pop      r14
       pop      r15
       ret      
 
G_M000_IG09:                ;; offset=0x00F9
       mov      rdx, gword ptr [rbx+0x08]
       mov      ecx, dword ptr [rdx+0xEC]
       mov      rax, gword ptr [rdx+0x98]
       cmp      ecx, dword ptr [rax+0x08]
       jne      SHORT G_M000_IG07
       mov      rcx, rdi
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_DiscardIterator():bool:this]
       test     eax, eax
       je       G_M000_IG64
       mov      edx, dword ptr [rbx+0x3C]
       dec      edx
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Trim(int):this]
       jmp      G_M000_IG64
 
G_M000_IG10:                ;; offset=0x0133
       lea      r8, [rsp+0x70]
       mov      rcx, rbx
       mov      rdx, rdi
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:TryIntegerComparison(byref,byref):bool:this]
       test     eax, eax
       jne      G_M000_IG17
       mov      rcx, gword ptr [rbx+0x08]
 
G_M000_IG11:                ;; offset=0x0150
       vmovdqu  xmm0, xmmword ptr [rbx+0x48]
       vmovdqu  xmmword ptr [rsp+0x48], xmm0
 
G_M000_IG12:                ;; offset=0x015B
       xor      edx, edx
       mov      dword ptr [rsp+0x20], edx
       mov      rdx, gword ptr [rbx+0x10]
       mov      gword ptr [rsp+0x28], rdx
       lea      rdx, [rsp+0x48]
       mov      r8d, dword ptr [rdi+0x10]
       mov      r9d, dword ptr [rbx+0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime:ReadExecutableOperand(Lokad.Lython.Frontend.ExecutableCodeObject,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],int,int,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):System.Object]
       mov      rbp, rax
       mov      rcx, gword ptr [rbx+0x08]
 
G_M000_IG13:                ;; offset=0x0184
       vmovdqu  xmm0, xmmword ptr [rbx+0x48]
       vmovdqu  xmmword ptr [rsp+0x48], xmm0
 
G_M000_IG14:                ;; offset=0x018F
       mov      dword ptr [rsp+0x20], 1
       mov      rdx, gword ptr [rbx+0x10]
       mov      gword ptr [rsp+0x28], rdx
       lea      rdx, [rsp+0x48]
       mov      r8d, dword ptr [rdi+0x0C]
       mov      r9d, dword ptr [rbx+0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime:ReadExecutableOperand(Lokad.Lython.Frontend.ExecutableCodeObject,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],int,int,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):System.Object]
       mov      r8, rax
       cmp      dword ptr [rdi+0x1C], 51
       jne      SHORT G_M000_IG15
       mov      ecx, dword ptr [rdi+0x14]
       jmp      SHORT G_M000_IG16
 
G_M000_IG15:                ;; offset=0x01C1
       mov      ecx, dword ptr [rdi+0x08]
       and      ecx, 0x7FFFFFFF
 
G_M000_IG16:                ;; offset=0x01CA
       mov      r9, gword ptr [rdi]
       mov      gword ptr [rsp+0x20], r9
       lea      r9, [rsp+0x70]
       mov      qword ptr [rsp+0x28], r9
       mov      r9, gword ptr [rbx+0x10]
       mov      rdx, rbp
       call     [Lokad.Lython.Runtime.LythonRuntime:TryEvaluateScalarComparison(int,System.Object,System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,byref):bool]
       test     eax, eax
       je       G_M000_IG07
 
G_M000_IG17:                ;; offset=0x01F1
       mov      edx, dword ptr [rdi+0x18]
       test     edx, edx
       jge      SHORT G_M000_IG18
       not      edx
 
G_M000_IG18:                ;; offset=0x01FA
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Trim(int):this]
       mov      rcx, gword ptr [rbx+0x10]
       mov      rbp, gword ptr [rdi]
       mov      r14, gword ptr [rcx+0xA0]
       cmp      byte  ptr [r14], r14b
       mov      rcx, r14
       call     [Lokad.Lython.Runtime.ExecutionState:get_CanContinue():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG19
       mov      rcx, r14
       mov      rdx, rbp
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
 
G_M000_IG19:                ;; offset=0x022D
       cmp      byte  ptr [rsp+0x70], 0
       jne      G_M000_IG147
       jmp      G_M000_IG64
 
G_M000_IG20:                ;; offset=0x023D
       mov      rdx, gword ptr [rbx+0x08]
       mov      rcx, rdx
 
G_M000_IG21:                ;; offset=0x0244
       vmovdqu  xmm0, xmmword ptr [rbx+0x48]
       vmovdqu  xmmword ptr [rsp+0x48], xmm0
 
G_M000_IG22:                ;; offset=0x024F
       xor      edx, edx
       mov      dword ptr [rsp+0x20], edx
       mov      rdx, gword ptr [rbx+0x10]
       mov      gword ptr [rsp+0x28], rdx
       lea      rdx, [rsp+0x48]
       mov      r8d, dword ptr [rdi+0x10]
       mov      r9d, dword ptr [rbx+0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime:ReadExecutableOperand(Lokad.Lython.Frontend.ExecutableCodeObject,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],int,int,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):System.Object]
       mov      rbp, rax
       mov      rcx, rbp
       call     [Lokad.Lython.Runtime.LythonRuntime:CanUseNativeTruth(System.Object):bool]
       test     eax, eax
       je       G_M000_IG07
       mov      rcx, rbx
       mov      rdx, rdi
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Take(byref):System.Object:this]
       mov      r8, gword ptr [rdi]
       mov      rdx, gword ptr [rbx+0x10]
       mov      rcx, rbp
       call     [Lokad.Lython.Runtime.LythonRuntime:IsTruthy(System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):bool]
       test     eax, eax
       jne      G_M000_IG147
       jmp      G_M000_IG64
 
G_M000_IG23:                ;; offset=0x02AE
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:TryIntegerOperation():bool:this]
       test     eax, eax
       jne      G_M000_IG147
 
G_M000_IG24:                ;; offset=0x02BF
       mov      rcx, gword ptr [rbx+0x08]
 
G_M000_IG25:                ;; offset=0x02C3
       vmovdqu  xmm0, xmmword ptr [rbx+0x48]
       vmovdqu  xmmword ptr [rsp+0x48], xmm0
 
G_M000_IG26:                ;; offset=0x02CE
       lea      rdx, [rsp+0xA0]
       mov      qword ptr [rsp+0x20], rdx
       lea      rdx, [rsp+0x48]
       mov      r8d, dword ptr [rbx+0x38]
       mov      r9, gword ptr [rbx+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryEvaluateBuiltinArithmetic(Lokad.Lython.Frontend.ExecutableCodeObject,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       test     eax, eax
       je       G_M000_IG07
 
G_M000_IG27:                ;; offset=0x02F6
       vmovdqu  xmm0, xmmword ptr [rsp+0xA0]
       vmovdqu  xmmword ptr [rsp+0x38], xmm0
 
G_M000_IG28:                ;; offset=0x0305
       lea      r8, [rsp+0x38]
       mov      rdx, rdi
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot):this]
       jmp      G_M000_IG147
 
G_M000_IG29:                ;; offset=0x031B
       mov      rdx, gword ptr [rbx+0x08]
       mov      rcx, rdx
 
G_M000_IG30:                ;; offset=0x0322
       vmovdqu  xmm0, xmmword ptr [rbx+0x48]
       vmovdqu  xmmword ptr [rsp+0x48], xmm0
 
G_M000_IG31:                ;; offset=0x032D
       xor      edx, edx
       mov      dword ptr [rsp+0x20], edx
       mov      rdx, gword ptr [rbx+0x10]
       mov      gword ptr [rsp+0x28], rdx
       lea      rdx, [rsp+0x48]
       mov      r8d, dword ptr [rdi+0x10]
       mov      r9d, dword ptr [rbx+0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime:ReadExecutableOperand(Lokad.Lython.Frontend.ExecutableCodeObject,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],int,int,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):System.Object]
       mov      rbp, rax
       mov      rcx, gword ptr [rbx+0x08]
       mov      r14, bword ptr [rbx+0x48]
       mov      r15d, dword ptr [rbx+0x50]
       mov      r13d, dword ptr [rdi+0x0C]
       mov      r8, gword ptr [rbx+0x10]
       xor      rdx, rdx
       mov      gword ptr [rsp+0x58], rdx
       test     r13d, r13d
       jge      SHORT G_M000_IG33
       mov      edx, r13d
       not      edx
       mov      r15, gword ptr [rcx+0x30]
       cmp      dword ptr [r15+0x08], edx
       jg       SHORT G_M000_IG32
       sub      edx, dword ptr [r15+0x08]
       lea      r9, [rsp+0x58]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryResolveExecutableGlobal(Lokad.Lython.Frontend.ExecutableCodeObject,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       lea      rdx, [rsp+0x90]
       mov      rcx, gword ptr [rsp+0x58]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryMachineInteger(System.Object,byref):bool]
       jmp      SHORT G_M000_IG34
 
G_M000_IG32:                ;; offset=0x03A5
       cmp      edx, dword ptr [r15+0x08]
       jae      G_M000_IG221
       mov      ecx, edx
       mov      rcx, gword ptr [r15+8*rcx+0x10]
       lea      rdx, [rsp+0x90]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryMachineInteger(System.Object,byref):bool]
       jmp      SHORT G_M000_IG34
 
G_M000_IG33:                ;; offset=0x03C6
       cmp      r13d, r15d
       jae      G_M000_IG221
       mov      ecx, r13d
       shl      rcx, 4
       add      rcx, r14
       lea      rdx, [rsp+0x90]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:TryGetInteger(byref):bool:this]
 
G_M000_IG34:                ;; offset=0x03E7
       xor      r9, r9
       mov      gword ptr [rsp+0x58], r9
       test     eax, eax
       je       SHORT G_M000_IG35
       mov      rdx, qword ptr [rsp+0x90]
       lea      r9, [rsp+0x80]
       mov      qword ptr [rsp+0x20], r9
       mov      r9, gword ptr [rbx+0x10]
       mov      r8, gword ptr [rdi]
       mov      rcx, rbp
       call     [Lokad.Lython.Runtime.PyIndexing:TryReadSequenceIndex(System.Object,long,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       test     eax, eax
       jne      G_M000_IG48
 
G_M000_IG35:                ;; offset=0x0420
       mov      rcx, gword ptr [rbx+0x08]
 
G_M000_IG36:                ;; offset=0x0424
       vmovdqu  xmm0, xmmword ptr [rbx+0x48]
       vmovdqu  xmmword ptr [rsp+0x48], xmm0
 
G_M000_IG37:                ;; offset=0x042F
       mov      dword ptr [rsp+0x20], 1
       mov      rdx, gword ptr [rbx+0x10]
       mov      gword ptr [rsp+0x28], rdx
       lea      rdx, [rsp+0x48]
       mov      r8d, dword ptr [rdi+0x0C]
       mov      r9d, dword ptr [rbx+0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime:ReadExecutableOperand(Lokad.Lython.Frontend.ExecutableCodeObject,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],int,int,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):System.Object]
       mov      r14, rax
       test     rbp, rbp
       je       G_M000_IG07
 
G_M000_IG38:                ;; offset=0x045F
       mov      rcx, 0x7FF9B52CBCB0
       cmp      qword ptr [rbp], rcx
       jne      G_M000_IG07
 
G_M000_IG39:                ;; offset=0x0473
       cmp      gword ptr [rbp+0x28], 0
       jne      SHORT G_M000_IG40
       mov      rcx, gword ptr [rbp+0x08]
       mov      r11, 0x7FF9B4B636B8
       call     [r11]Lokad.Lython.Runtime.IPyDictStorage:get_HasProtocolKeys():bool:this
       test     eax, eax
       jne      G_M000_IG07
       jmp      SHORT G_M000_IG41
 
G_M000_IG40:                ;; offset=0x0495
       cmp      dword ptr [rbp+0x50], 0
       jne      G_M000_IG07
 
G_M000_IG41:                ;; offset=0x049F
       test     r14, r14
       je       G_M000_IG07
 
G_M000_IG42:                ;; offset=0x04A8
       mov      rcx, 0x7FF9B5277B10
       cmp      qword ptr [r14], rcx
       jne      G_M000_IG07
 
G_M000_IG43:                ;; offset=0x04BB
       mov      rcx, rdi
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LookupCacheIndex():int:this]
       test     eax, eax
       jl       SHORT G_M000_IG44
       cmp      gword ptr [rbp+0x20], 0
       je       SHORT G_M000_IG44
       mov      rcx, gword ptr [rbx]
       mov      rdx, gword ptr [rdi]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.PyExecutableFunction:GetLookupCaches(Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.LythonRuntime+ExecutableLookupCache[]:this]
       mov      r15, rax
       mov      rcx, rdi
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LookupCacheIndex():int:this]
       cmp      eax, dword ptr [r15+0x08]
       jae      G_M000_IG221
       mov      r8d, eax
       lea      r8, [r8+2*r8]
       lea      r8, bword ptr [r15+8*r8+0x10]
       mov      r9, gword ptr [rdi]
       mov      gword ptr [rsp+0x20], r9
       lea      r9, [rsp+0x78]
       mov      qword ptr [rsp+0x28], r9
       mov      r9, gword ptr [rbx+0x10]
       mov      rdx, r14
       mov      rcx, rbp
       call     [Lokad.Lython.Runtime.PyDict:TryReadRecordValue(Lokad.Lython.Runtime.Text.PyString,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,byref):bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG47
 
G_M000_IG44:                ;; offset=0x0525
       cmp      gword ptr [rbp+0x28], 0
       jne      SHORT G_M000_IG45
       mov      rcx, gword ptr [rbp+0x08]
       mov      r11, 0x7FF9B4B636C0
       call     [r11]Lokad.Lython.Runtime.IPyDictStorage:get_HasProtocolKeys():bool:this
       test     eax, eax
       jne      G_M000_IG07
       jmp      SHORT G_M000_IG46
 
G_M000_IG45:                ;; offset=0x0547
       cmp      dword ptr [rbp+0x50], 0
       jne      G_M000_IG07
 
G_M000_IG46:                ;; offset=0x0551
       mov      r8, gword ptr [rdi]
       mov      r9, gword ptr [rbx+0x10]
       mov      rcx, rbp
       mov      rdx, r14
       call     [Lokad.Lython.Runtime.LythonRuntime:ReadSubscriptValue(System.Object,System.Object,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):System.Object]
       mov      gword ptr [rsp+0x38], rax
       xor      r8d, r8d
       mov      qword ptr [rsp+0x40], r8
       lea      r8, [rsp+0x38]
       mov      rdx, rdi
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot):this]
       jmp      G_M000_IG147
 
G_M000_IG47:                ;; offset=0x0587
       mov      r8, gword ptr [rsp+0x78]
       mov      gword ptr [rsp+0x38], r8
       xor      r8d, r8d
       mov      qword ptr [rsp+0x40], r8
       lea      r8, [rsp+0x38]
       mov      rdx, rdi
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot):this]
       jmp      G_M000_IG147
 
G_M000_IG48:                ;; offset=0x05AF
       vmovdqu  xmm0, xmmword ptr [rsp+0x80]
       vmovdqu  xmmword ptr [rsp+0x38], xmm0
 
G_M000_IG49:                ;; offset=0x05BE
       lea      r8, [rsp+0x38]
       mov      rdx, rdi
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot):this]
       jmp      G_M000_IG147
 
G_M000_IG50:                ;; offset=0x05D4
       mov      rcx, rbx
       mov      rdx, rdi
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Call(byref):bool:this]
       test     eax, eax
       jne      G_M000_IG147
       jmp      G_M000_IG07
 
G_M000_IG51:                ;; offset=0x05ED
       lea      rcx, bword ptr [rbx+0x48]
       mov      eax, dword ptr [rdi+0x10]
       cmp      eax, dword ptr [rcx+0x08]
       jae      G_M000_IG221
       shl      rax, 4
       add      rax, bword ptr [rcx]
       mov      rcx, rax
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Object():System.Object:this]
       mov      rdx, rax
       mov      rcx, 0x7FF9B54EBCC8
       call     [Lokad.Lython.Internal.NullabilityExtensions:RequireNotNull[System.__Canon](System.__Canon):System.__Canon]
       mov      rcx, rax
       test     rcx, rcx
       je       SHORT G_M000_IG54
 
G_M000_IG52:                ;; offset=0x0628
       mov      rdx, 0x7FF9B5628588
       cmp      qword ptr [rcx], rdx
       jne      SHORT G_M000_IG54
 
G_M000_IG53:                ;; offset=0x0637
       lea      rdx, [rsp+0x60]
       call     [Lokad.Lython.Runtime.Text.PyStringOps+CasedWhitespaceIteration:MoveNext():Lokad.Lython.Runtime.PyIterationResult:this]
       jmp      SHORT G_M000_IG60
 
G_M000_IG54:                ;; offset=0x0644
       test     rcx, rcx
       je       SHORT G_M000_IG57
 
G_M000_IG55:                ;; offset=0x0649
       mov      rdx, 0x7FF9B56287F0
       cmp      qword ptr [rcx], rdx
       jne      SHORT G_M000_IG57
 
G_M000_IG56:                ;; offset=0x0658
       lea      rdx, [rsp+0x60]
       call     [Lokad.Lython.Runtime.PyRange+Enumerator:TryMoveNext():Lokad.Lython.Runtime.PyIterationResult:this]
       jmp      SHORT G_M000_IG60
 
G_M000_IG57:                ;; offset=0x0665
       mov      rbp, rcx
       test     rbp, rbp
       je       SHORT G_M000_IG59
 
G_M000_IG58:                ;; offset=0x066D
       mov      rax, 0x7FF9B54EB830
       cmp      qword ptr [rbp], rax
       jne      G_M000_IG217
 
G_M000_IG59:                ;; offset=0x0681
       cmp      byte  ptr [rbp], bpl
       mov      rcx, rbp
       call     [Lokad.Lython.Runtime.PyIteration+Cursor:CheckExecution():this]
       lea      rdx, [rsp+0x60]
       mov      rcx, rbp
       call     [Lokad.Lython.Runtime.PyIteration+Cursor:TryMoveNextCore():Lokad.Lython.Runtime.PyIterationResult:this]
 
G_M000_IG60:                ;; offset=0x069C
       cmp      gword ptr [rsp+0x60], 0
       je       SHORT G_M000_IG63
 
G_M000_IG61:                ;; offset=0x06A4
       vmovdqu  xmm0, xmmword ptr [rsp+0x60]
       vmovdqu  xmmword ptr [rsp+0x38], xmm0
 
G_M000_IG62:                ;; offset=0x06B0
       lea      r8, [rsp+0x38]
       mov      rdx, rdi
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot):this]
       jmp      G_M000_IG147
 
G_M000_IG63:                ;; offset=0x06C6
       mov      edx, dword ptr [rdi+0x10]
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Trim(int):this]
 
G_M000_IG64:                ;; offset=0x06D2
       mov      rcx, rdi
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_TargetIndex():int:this]
       mov      dword ptr [rbx+0x38], eax
       jmp      G_M000_IG148
 
G_M000_IG65:                ;; offset=0x06E3
       mov      rdx, gword ptr [rbx+0x08]
       mov      rcx, rdx
 
G_M000_IG66:                ;; offset=0x06EA
       vmovdqu  xmm0, xmmword ptr [rbx+0x48]
       vmovdqu  xmmword ptr [rsp+0x48], xmm0
 
G_M000_IG67:                ;; offset=0x06F5
       xor      edx, edx
       mov      dword ptr [rsp+0x20], edx
       mov      rdx, gword ptr [rbx+0x10]
       mov      gword ptr [rsp+0x28], rdx
       lea      rdx, [rsp+0x48]
       mov      r8d, dword ptr [rdi+0x10]
       mov      r9d, dword ptr [rbx+0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime:ReadExecutableOperand(Lokad.Lython.Frontend.ExecutableCodeObject,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],int,int,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):System.Object]
       mov      rbp, rax
       test     rbp, rbp
       je       G_M000_IG72
 
G_M000_IG68:                ;; offset=0x0723
       mov      r8, 0x7FF9B5628588
       cmp      qword ptr [rbp], r8
       jne      SHORT G_M000_IG70
 
G_M000_IG69:                ;; offset=0x0733
       mov      gword ptr [rsp+0x38], rbp
       xor      r8d, r8d
       mov      qword ptr [rsp+0x40], r8
       lea      r8, [rsp+0x38]
       mov      rdx, rdi
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot):this]
       jmp      G_M000_IG147
 
G_M000_IG70:                ;; offset=0x0756
       mov      rcx, 0x7FF9B5602D40
       cmp      qword ptr [rbp], rcx
       jne      SHORT G_M000_IG72
 
G_M000_IG71:                ;; offset=0x0766
       mov      rcx, 0x7FF9B56287F0
       call     CORINFO_HELP_NEWSFAST
       mov      r14, rax
       mov      rcx, r14
       mov      rdx, rbp
       call     [Lokad.Lython.Runtime.PyRange+Enumerator:.ctor(Lokad.Lython.Runtime.PyRange):this]
       mov      gword ptr [rsp+0x38], r14
       xor      r8d, r8d
       mov      qword ptr [rsp+0x40], r8
       lea      r8, [rsp+0x38]
       mov      rdx, rdi
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot):this]
       jmp      G_M000_IG147
 
G_M000_IG72:                ;; offset=0x07A7
       test     rbp, rbp
       je       SHORT G_M000_IG74
 
G_M000_IG73:                ;; offset=0x07AC
       mov      rdx, 0x7FF9B54EFB18
       cmp      qword ptr [rbp], rdx
       je       SHORT G_M000_IG76
 
G_M000_IG74:                ;; offset=0x07BC
       mov      rdx, rbp
       mov      rcx, 0x7FF9B547B190
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       jne      SHORT G_M000_IG76
       test     rbp, rbp
       je       G_M000_IG07
 
G_M000_IG75:                ;; offset=0x07DC
       mov      r8, 0x7FF9B5460F80
       cmp      qword ptr [rbp], r8
       je       SHORT G_M000_IG76
       mov      r8, 0x7FF9B5277B10
       cmp      qword ptr [rbp], r8
       je       SHORT G_M000_IG76
       mov      r8, 0x7FF9B52CBCB0
       cmp      qword ptr [rbp], r8
       je       SHORT G_M000_IG76
       mov      r8, 0x7FF9B552B1C8
       cmp      qword ptr [rbp], r8
       jne      G_M000_IG07
 
G_M000_IG76:                ;; offset=0x0820
       mov      r8, gword ptr [rbx+0x10]
       mov      rdx, gword ptr [rdi]
       mov      rcx, rbp
       call     [Lokad.Lython.Runtime.PyIteration+Cursor:Create(System.Object,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):Lokad.Lython.Runtime.PyIteration+Cursor]
       mov      gword ptr [rsp+0x38], rax
       xor      r8d, r8d
       mov      qword ptr [rsp+0x40], r8
       lea      r8, [rsp+0x38]
       mov      rdx, rdi
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot):this]
       jmp      G_M000_IG147
 
G_M000_IG77:                ;; offset=0x0853
       mov      rcx, rbx
       mov      rdx, rdi
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:ConstructContainer(byref):bool:this]
       test     eax, eax
       jne      G_M000_IG147
       jmp      G_M000_IG07
 
G_M000_IG78:                ;; offset=0x086C
       mov      rcx, rbx
       mov      rdx, rdi
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:TryReturnUnpackedTuple(byref):bool:this]
       test     eax, eax
       jne      G_M000_IG162
       mov      rcx, rdi
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ItemCount():int:this]
       test     eax, eax
       jne      SHORT G_M000_IG79
       mov      rcx, 0x19F7FC01FB0
       mov      rbp, gword ptr [rcx]
       jmp      SHORT G_M000_IG80
 
G_M000_IG79:                ;; offset=0x089C
       lea      rbp, bword ptr [rbx+0x48]
       mov      r14d, dword ptr [rdi+0x10]
       mov      rcx, rdi
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ItemCount():int:this]
       mov      ecx, r14d
       mov      edx, eax
       add      rcx, rdx
       mov      edx, dword ptr [rbp+0x08]
       cmp      rcx, rdx
       ja       G_M000_IG220
       mov      ecx, r14d
       shl      rcx, 4
       add      rcx, bword ptr [rbp]
       mov      bword ptr [rsp+0x48], rcx
       mov      dword ptr [rsp+0x50], eax
       lea      rcx, [rsp+0x48]
       mov      rdx, gword ptr [rbx+0x10]
       mov      r8, gword ptr [rdi]
       call     [Lokad.Lython.Runtime.PyTuple:FromSlots(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.PyTuple]
       mov      rbp, rax
 
G_M000_IG80:                ;; offset=0x08EA
       mov      edx, dword ptr [rdi+0x10]
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Trim(int):this]
       mov      gword ptr [rsp+0x38], rbp
       xor      r8d, r8d
       mov      qword ptr [rsp+0x40], r8
       lea      r8, [rsp+0x38]
       mov      rdx, rdi
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot):this]
       jmp      G_M000_IG147
 
G_M000_IG81:                ;; offset=0x0919
       lea      rbp, bword ptr [rbx+0x48]
       mov      r14d, dword ptr [rdi+0x10]
       mov      rcx, rdi
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ItemCount():int:this]
       mov      ecx, r14d
       mov      edx, eax
       add      rcx, rdx
       mov      edx, dword ptr [rbp+0x08]
       cmp      rcx, rdx
       ja       G_M000_IG220
       mov      ecx, r14d
       shl      rcx, 4
       add      rcx, bword ptr [rbp]
       mov      bword ptr [rsp+0x48], rcx
       mov      dword ptr [rsp+0x50], eax
       lea      rcx, [rsp+0x48]
       mov      rdx, gword ptr [rbx+0x10]
       mov      r8, gword ptr [rdi]
       call     [Lokad.Lython.Runtime.LythonRuntime:CreateSlotList(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.PyList]
       mov      rbp, rax
       mov      edx, dword ptr [rdi+0x10]
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Trim(int):this]
       mov      gword ptr [rsp+0x38], rbp
       xor      r8d, r8d
       mov      qword ptr [rsp+0x40], r8
       lea      r8, [rsp+0x38]
       mov      rdx, rdi
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot):this]
       jmp      G_M000_IG147
 
G_M000_IG82:                ;; offset=0x0996
       mov      rdx, gword ptr [rbx+0x08]
       mov      rcx, rdx
 
G_M000_IG83:                ;; offset=0x099D
       vmovdqu  xmm0, xmmword ptr [rbx+0x48]
       vmovdqu  xmmword ptr [rsp+0x48], xmm0
 
G_M000_IG84:                ;; offset=0x09A8
       xor      edx, edx
       mov      dword ptr [rsp+0x20], edx
       mov      rdx, gword ptr [rbx+0x10]
       mov      gword ptr [rsp+0x28], rdx
       lea      rdx, [rsp+0x48]
       mov      r8d, dword ptr [rdi+0x10]
       mov      r9d, dword ptr [rbx+0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime:ReadExecutableOperand(Lokad.Lython.Frontend.ExecutableCodeObject,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],int,int,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):System.Object]
       mov      edx, dword ptr [rdi+0x18]
       test     edx, edx
       jge      SHORT G_M000_IG85
       not      edx
 
G_M000_IG85:                ;; offset=0x09D3
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Trim(int):this]
       jmp      G_M000_IG147
 
G_M000_IG86:                ;; offset=0x09E1
       mov      ecx, ebp
       cmp      ecx, 51
       ja       SHORT G_M000_IG91
 
G_M000_IG87:                ;; offset=0x09E8
       mov      rdx, 0x7FFFFFFFFF9FF
       bt       rdx, rcx
       jb       SHORT G_M000_IG91
 
G_M000_IG88:                ;; offset=0x09F8
       mov      ebp, dword ptr [rdi+0x18]
       test     ebp, ebp
       jge      SHORT G_M000_IG89
       mov      r14d, ebp
       not      r14d
       jmp      SHORT G_M000_IG90
 
G_M000_IG89:                ;; offset=0x0A07
       mov      r14d, ebp
 
G_M000_IG90:                ;; offset=0x0A0A
       jmp      SHORT G_M000_IG92
 
G_M000_IG91:                ;; offset=0x0A0C
       mov      r14d, dword ptr [rdi+0x14]
 
G_M000_IG92:                ;; offset=0x0A10
       inc      r14d
       mov      ebp, dword ptr [rdi+0x18]
       test     ebp, ebp
       jge      SHORT G_M000_IG93
       mov      r15d, ebp
       not      r15d
       jmp      SHORT G_M000_IG94
 
G_M000_IG93:                ;; offset=0x0A22
       mov      r15d, ebp
 
G_M000_IG94:                ;; offset=0x0A25
       mov      rdx, gword ptr [rbx+0x08]
       mov      rcx, rdx
 
G_M000_IG95:                ;; offset=0x0A2C
       vmovdqu  xmm0, xmmword ptr [rbx+0x48]
       vmovdqu  xmmword ptr [rsp+0x48], xmm0
 
G_M000_IG96:                ;; offset=0x0A37
       xor      edx, edx
       mov      dword ptr [rsp+0x20], edx
       mov      rdx, gword ptr [rbx+0x10]
       mov      gword ptr [rsp+0x28], rdx
       lea      rdx, [rsp+0x48]
       mov      r8d, dword ptr [rdi+0x10]
       mov      r9d, dword ptr [rbx+0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime:ReadExecutableOperand(Lokad.Lython.Frontend.ExecutableCodeObject,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],int,int,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):System.Object]
       mov      rdi, rax
       cmp      r15d, dword ptr [rbx+0x3C]
       jge      SHORT G_M000_IG97
       mov      rcx, rbx
       mov      edx, r15d
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Trim(int):this]
 
G_M000_IG97:                ;; offset=0x0A6E
       lea      rcx, bword ptr [rbx+0x48]
       cmp      r14d, dword ptr [rcx+0x08]
       jae      G_M000_IG221
       mov      ebp, r14d
       shl      rbp, 4
       add      rbp, bword ptr [rcx]
       mov      rcx, rbp
       mov      rdx, rdi
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       xor      edx, edx
       mov      qword ptr [rbp+0x08], rdx
       mov      dword ptr [rbx+0x3C], r15d
       jmp      G_M000_IG147
 
G_M000_IG98:                ;; offset=0x0AA0
       lea      rcx, bword ptr [rbx+0x58]
       mov      edx, ebp
       cmp      edx, 3
       je       SHORT G_M000_IG99
       cmp      edx, 26
       jne      G_M000_IG219
 
G_M000_IG99:                ;; offset=0x0AB4
       mov      edx, dword ptr [rdi+0x08]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableCaptures:GetCell(int):Lokad.Lython.Runtime.LythonRuntime+ExecutableCell:this]
       mov      rbp, rax
       test     rbp, rbp
       je       G_M000_IG07
       mov      rcx, gword ptr [rbp+0x10]
       test     rcx, rcx
       je       SHORT G_M000_IG100
       cmp      gword ptr [rbp+0x18], 0
       je       G_M000_IG07
       cmp      gword ptr [rcx+0x88], 0
       jne      G_M000_IG07
 
G_M000_IG100:                ;; offset=0x0AEB
       mov      r8d, dword ptr [rdi+0x10]
       test     r8d, r8d
       jl       SHORT G_M000_IG104
       lea      rcx, bword ptr [rbx+0x48]
       cmp      r8d, dword ptr [rcx+0x08]
       jae      G_M000_IG221
       mov      edx, r8d
       shl      rdx, 4
       add      rdx, bword ptr [rcx]
       mov      r14, gword ptr [rdx]
       mov      r15, qword ptr [rdx+0x08]
       test     r14, r14
       jne      SHORT G_M000_IG103
       mov      rcx, gword ptr [rbx+0x08]
 
G_M000_IG101:                ;; offset=0x0B1C
       vmovdqu  xmm0, xmmword ptr [rbx+0x48]
       vmovdqu  xmmword ptr [rsp+0x48], xmm0
 
G_M000_IG102:                ;; offset=0x0B27
       xor      edx, edx
       mov      dword ptr [rsp+0x20], edx
       mov      rdx, gword ptr [rbx+0x10]
       mov      gword ptr [rsp+0x28], rdx
       lea      rdx, [rsp+0x48]
       mov      r9d, dword ptr [rbx+0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime:ReadExecutableOperand(Lokad.Lython.Frontend.ExecutableCodeObject,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],int,int,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):System.Object]
 
G_M000_IG103:                ;; offset=0x0B45
       jmp      SHORT G_M000_IG107
 
G_M000_IG104:                ;; offset=0x0B47
       mov      rcx, gword ptr [rbx+0x08]
 
G_M000_IG105:                ;; offset=0x0B4B
       vmovdqu  xmm0, xmmword ptr [rbx+0x48]
       vmovdqu  xmmword ptr [rsp+0x48], xmm0
 
G_M000_IG106:                ;; offset=0x0B56
       xor      edx, edx
       mov      dword ptr [rsp+0x20], edx
       mov      rdx, gword ptr [rbx+0x10]
       mov      gword ptr [rsp+0x28], rdx
       lea      rdx, [rsp+0x48]
       mov      r9d, dword ptr [rbx+0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime:ReadExecutableOperand(Lokad.Lython.Frontend.ExecutableCodeObject,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],int,int,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):System.Object]
       mov      r14, rax
       xor      r15d, r15d
 
G_M000_IG107:                ;; offset=0x0B7A
       lea      rcx, bword ptr [rbx+0x48]
       mov      edx, dword ptr [rdi+0x10]
       cmp      edx, dword ptr [rcx+0x08]
       jae      G_M000_IG221
       mov      rcx, bword ptr [rcx]
       shl      rdx, 4
       xor      eax, eax
       mov      qword ptr [rcx+rdx], rax
       mov      qword ptr [rcx+rdx+0x08], rax
       mov      edx, dword ptr [rdi+0x18]
       test     edx, edx
       jge      SHORT G_M000_IG108
       not      edx
 
G_M000_IG108:                ;; offset=0x0BA5
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Trim(int):this]
       mov      gword ptr [rsp+0x38], r14
       mov      qword ptr [rsp+0x40], r15
       lea      rdx, [rsp+0x38]
       mov      rcx, rbp
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableCell:StoreSlot(Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot):this]
       jmp      G_M000_IG147
 
G_M000_IG109:                ;; offset=0x0BCB
       mov      rcx, rbx
       mov      rdx, rdi
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:StoreLocal(byref):this]
       jmp      G_M000_IG147
 
G_M000_IG110:                ;; offset=0x0BDC
       mov      rdx, gword ptr [rbx+0x08]
       mov      rcx, rdx
 
G_M000_IG111:                ;; offset=0x0BE3
       vmovdqu  xmm0, xmmword ptr [rbx+0x48]
       vmovdqu  xmmword ptr [rsp+0x48], xmm0
 
G_M000_IG112:                ;; offset=0x0BEE
       xor      edx, edx
       mov      dword ptr [rsp+0x20], edx
       mov      rdx, gword ptr [rbx+0x10]
       mov      gword ptr [rsp+0x28], rdx
       lea      rdx, [rsp+0x48]
       mov      r8d, dword ptr [rdi+0x10]
       mov      r9d, dword ptr [rbx+0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime:ReadExecutableOperand(Lokad.Lython.Frontend.ExecutableCodeObject,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],int,int,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):System.Object]
       mov      rbp, rax
       mov      rcx, gword ptr [rbx+0x08]
       mov      r14, gword ptr [rcx+0x38]
       mov      rcx, rdi
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_NameIndex():int:this]
       cmp      eax, dword ptr [r14+0x08]
       jae      G_M000_IG221
       mov      r8d, eax
       mov      r14, gword ptr [r14+8*r8+0x10]
       test     rbp, rbp
       je       SHORT G_M000_IG115
 
G_M000_IG113:                ;; offset=0x0C3B
       mov      r8, 0x7FF9B54EF0A8
       cmp      qword ptr [rbp], r8
       jne      SHORT G_M000_IG115
 
G_M000_IG114:                ;; offset=0x0C4B
       lea      r8, [rsp+0x98]
       mov      rcx, rbp
       mov      rdx, r14
       call     [Lokad.Lython.Runtime.PyAttributeLookup:TryResolveInstanceFunctionForCall(Lokad.Lython.Runtime.PyInstance,System.String,byref):bool]
       test     eax, eax
       je       SHORT G_M000_IG115
       mov      r15, gword ptr [rsp+0x98]
       jmp      SHORT G_M000_IG116
 
G_M000_IG115:                ;; offset=0x0C6D
       mov      rcx, rbp
       mov      rdx, r14
       call     [Lokad.Lython.Runtime.LythonRuntime:ResolveBuiltinReceiverMethod(System.Object,System.String):Lokad.Lython.Runtime.LythonRuntime+ReceiverMethod]
       mov      r15, rax
 
G_M000_IG116:                ;; offset=0x0C7C
       test     r15, r15
       je       G_M000_IG07
       mov      ecx, dword ptr [rdi+0x1C]
       mov      edx, ecx
       cmp      edx, 51
       ja       SHORT G_M000_IG120
 
G_M000_IG117:                ;; offset=0x0C8F
       mov      rax, 0x7FFFFFFFFF9FF
       bt       rax, rdx
       jb       SHORT G_M000_IG120
 
G_M000_IG118:                ;; offset=0x0C9F
       mov      r14d, dword ptr [rdi+0x18]
       test     r14d, r14d
       jge      SHORT G_M000_IG119
       not      r14d
 
G_M000_IG119:                ;; offset=0x0CAB
       jmp      SHORT G_M000_IG121
 
G_M000_IG120:                ;; offset=0x0CAD
       mov      r14d, dword ptr [rdi+0x14]
 
G_M000_IG121:                ;; offset=0x0CB1
       cmp      ecx, 51
       ja       SHORT G_M000_IG126
 
G_M000_IG122:                ;; offset=0x0CB6
       mov      rdx, 0x7FFFFFFFFF9FF
       bt       rdx, rcx
       jb       SHORT G_M000_IG126
 
G_M000_IG123:                ;; offset=0x0CC6
       mov      ecx, dword ptr [rdi+0x18]
       test     ecx, ecx
       jge      SHORT G_M000_IG124
       mov      r13d, ecx
       not      r13d
       jmp      SHORT G_M000_IG125
 
G_M000_IG124:                ;; offset=0x0CD5
       mov      r13d, ecx
 
G_M000_IG125:                ;; offset=0x0CD8
       jmp      SHORT G_M000_IG127
 
G_M000_IG126:                ;; offset=0x0CDA
       mov      r13d, dword ptr [rdi+0x14]
 
G_M000_IG127:                ;; offset=0x0CDE
       inc      r13d
       cmp      r13d, dword ptr [rbx+0x3C]
       jge      SHORT G_M000_IG128
       mov      rcx, rbx
       mov      edx, r13d
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Trim(int):this]
 
G_M000_IG128:                ;; offset=0x0CF3
       lea      rcx, bword ptr [rbx+0x48]
       cmp      r14d, dword ptr [rcx+0x08]
       jae      G_M000_IG221
       mov      r14d, r14d
       shl      r14, 4
       add      r14, bword ptr [rcx]
       mov      rcx, r14
       mov      rdx, rbp
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       xor      ecx, ecx
       mov      qword ptr [r14+0x08], rcx
       mov      dword ptr [rbx+0x3C], r13d
       mov      ecx, dword ptr [rdi+0x1C]
       cmp      ecx, 51
       ja       SHORT G_M000_IG132
 
G_M000_IG129:                ;; offset=0x0D28
       mov      rdx, 0x7FFFFFFFFF9FF
       bt       rdx, rcx
       jb       SHORT G_M000_IG132
 
G_M000_IG130:                ;; offset=0x0D38
       mov      ebp, dword ptr [rdi+0x18]
       test     ebp, ebp
       jge      SHORT G_M000_IG131
       not      ebp
 
G_M000_IG131:                ;; offset=0x0D41
       jmp      SHORT G_M000_IG133
 
G_M000_IG132:                ;; offset=0x0D43
       mov      ebp, dword ptr [rdi+0x14]
 
G_M000_IG133:                ;; offset=0x0D46
       inc      ebp
       mov      ecx, dword ptr [rdi+0x18]
       test     ecx, ecx
       jge      SHORT G_M000_IG134
       mov      edi, ecx
       not      edi
       jmp      SHORT G_M000_IG135
 
G_M000_IG134:                ;; offset=0x0D55
       mov      edi, ecx
 
G_M000_IG135:                ;; offset=0x0D57
       cmp      edi, dword ptr [rbx+0x3C]
       jge      SHORT G_M000_IG136
       mov      rcx, rbx
       mov      edx, edi
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Trim(int):this]
 
G_M000_IG136:                ;; offset=0x0D67
       lea      rcx, bword ptr [rbx+0x48]
       cmp      ebp, dword ptr [rcx+0x08]
       jae      G_M000_IG221
       mov      ebp, ebp
       shl      rbp, 4
       add      rbp, bword ptr [rcx]
       mov      rcx, rbp
       mov      rdx, r15
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       xor      ecx, ecx
       mov      qword ptr [rbp+0x08], rcx
       mov      dword ptr [rbx+0x3C], edi
       jmp      G_M000_IG147
 
G_M000_IG137:                ;; offset=0x0D96
       mov      rcx, rbx
       mov      rdx, rdi
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:StoreSubscript(byref):bool:this]
       test     eax, eax
       jne      G_M000_IG147
       jmp      G_M000_IG07
 
G_M000_IG138:                ;; offset=0x0DAF
       mov      rcx, rbx
       mov      rdx, rdi
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:ApplyDefinition(byref):bool:this]
       test     eax, eax
       jne      G_M000_IG147
       jmp      G_M000_IG07
 
G_M000_IG139:                ;; offset=0x0DC8
       mov      rdx, gword ptr [rbx+0x08]
       mov      rbp, rdx
       mov      rcx, rdi
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_NameIndex():int:this]
       mov      edx, eax
       mov      rcx, rbp
       mov      r8, gword ptr [rdi]
       mov      r9, gword ptr [rbx+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime:ResolveExecutableGlobal(Lokad.Lython.Frontend.ExecutableCodeObject,int,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):System.Object]
       mov      gword ptr [rsp+0x38], rax
       xor      r8d, r8d
       mov      qword ptr [rsp+0x40], r8
       lea      r8, [rsp+0x38]
       mov      rdx, rdi
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot):this]
       jmp      G_M000_IG147
 
G_M000_IG140:                ;; offset=0x0E0D
       mov      rcx, gword ptr [rbx+0x10]
       mov      gword ptr [rsp+0x20], rcx
       mov      rdx, gword ptr [rbx+0x08]
       mov      rcx, rdx
       mov      rdx, gword ptr [rbx+0x58]
       mov      r8d, dword ptr [rbx+0x38]
       mov      r9d, dword ptr [rbx+0x3C]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryExecuteClosureArithmetic(Lokad.Lython.Frontend.ExecutableCodeObject,Lokad.Lython.Runtime.LythonRuntime+ExecutableCaptures,int,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):bool]
       test     eax, eax
       jne      SHORT G_M000_IG142
       lea      rcx, bword ptr [rbx+0x58]
       mov      edx, dword ptr [rdi+0x1C]
       cmp      edx, 3
       je       SHORT G_M000_IG141
       cmp      edx, 26
       jne      G_M000_IG219
 
G_M000_IG141:                ;; offset=0x0E48
       mov      edx, dword ptr [rdi+0x08]
       lea      r8, [rsp+0xC0]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableCaptures:TryRead(int,byref):bool:this]
       test     eax, eax
       je       G_M000_IG07
       cmp      gword ptr [rsp+0xC0], 0
       je       G_M000_IG07
       mov      r8, gword ptr [rsp+0xC0]
       mov      gword ptr [rsp+0x38], r8
       xor      r8d, r8d
       mov      qword ptr [rsp+0x40], r8
       lea      r8, [rsp+0x38]
       mov      rdx, rdi
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot):this]
       jmp      G_M000_IG147
 
G_M000_IG142:                ;; offset=0x0E9B
       add      dword ptr [rbx+0x38], 2
       jmp      G_M000_IG147
 
G_M000_IG143:                ;; offset=0x0EA4
       mov      rcx, rdi
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LocalSlot():int:this]
       mov      r8d, eax
       mov      rcx, gword ptr [rbx+0x08]
 
G_M000_IG144:                ;; offset=0x0EB4
       vmovdqu  xmm0, xmmword ptr [rbx+0x48]
       vmovdqu  xmmword ptr [rsp+0x48], xmm0
 
G_M000_IG145:                ;; offset=0x0EBF
       xor      edx, edx
       mov      dword ptr [rsp+0x20], edx
       mov      rdx, gword ptr [rbx+0x10]
       mov      gword ptr [rsp+0x28], rdx
       lea      rdx, [rsp+0x48]
       mov      r9d, dword ptr [rbx+0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime:ReadExecutableOperand(Lokad.Lython.Frontend.ExecutableCodeObject,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],int,int,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):System.Object]
       mov      gword ptr [rsp+0x38], rax
       xor      r8d, r8d
       mov      qword ptr [rsp+0x40], r8
       lea      r8, [rsp+0x38]
       mov      rdx, rdi
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot):this]
       jmp      SHORT G_M000_IG147
 
G_M000_IG146:                ;; offset=0x0EFD
       mov      rdx, gword ptr [rbx+0x08]
       mov      rbp, gword ptr [rdx+0x30]
       mov      rcx, rdi
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ConstantIndex():int:this]
       cmp      eax, dword ptr [rbp+0x08]
       jae      G_M000_IG221
       mov      ecx, eax
       mov      rcx, gword ptr [rbp+8*rcx+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime:RuntimeValue(System.Object):System.Object]
       mov      gword ptr [rsp+0x38], rax
       xor      r8d, r8d
       mov      qword ptr [rsp+0x40], r8
       lea      r8, [rsp+0x38]
       mov      rdx, rdi
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot):this]
 
G_M000_IG147:                ;; offset=0x0F42
       inc      dword ptr [rbx+0x38]
 
G_M000_IG148:                ;; offset=0x0F45
       mov      ecx, dword ptr [rbx+0x38]
       mov      rax, gword ptr [rbx+0x08]
       cmp      ecx, dword ptr [rax+0xEC]
       jl       G_M000_IG03
 
G_M000_IG149:                ;; offset=0x0F58
       mov      eax, dword ptr [rbx+0x38]
       mov      rcx, gword ptr [rbx+0x08]
       mov      rcx, gword ptr [rcx+0x98]
       cmp      eax, dword ptr [rcx+0x08]
       setge    al
       movzx    rax, al
 
G_M000_IG150:                ;; offset=0x0F6F
       add      rsp, 224
       pop      rbx
       pop      rbp
       pop      rsi
       pop      rdi
       pop      r13
       pop      r14
       pop      r15
       ret      
 
G_M000_IG151:                ;; offset=0x0F81
       mov      rdx, gword ptr [rbx+0x08]
       mov      ecx, dword ptr [rdx+0xEC]
       mov      rdx, gword ptr [rdx+0x98]
       cmp      ecx, dword ptr [rdx+0x08]
       jne      G_M000_IG07
       jmp      G_M000_IG161
 
G_M000_IG152:                ;; offset=0x0FA0
       mov      rdx, gword ptr [rbx+0x08]
       mov      ecx, dword ptr [rdx+0xEC]
       mov      r9, gword ptr [rdx+0x98]
       cmp      ecx, dword ptr [r9+0x08]
       jne      G_M000_IG07
       mov      r8d, dword ptr [rdi+0x10]
       test     r8d, r8d
       jl       SHORT G_M000_IG156
       lea      rcx, bword ptr [rbx+0x48]
       cmp      r8d, dword ptr [rcx+0x08]
       jae      G_M000_IG221
       mov      r9d, r8d
       shl      r9, 4
       add      r9, bword ptr [rcx]
       mov      rbp, gword ptr [r9]
       mov      r14, qword ptr [r9+0x08]
       test     rbp, rbp
       jne      SHORT G_M000_IG155
       mov      rcx, rdx
 
G_M000_IG153:                ;; offset=0x0FEB
       vmovdqu  xmm0, xmmword ptr [rbx+0x48]
       vmovdqu  xmmword ptr [rsp+0x48], xmm0
 
G_M000_IG154:                ;; offset=0x0FF6
       xor      edx, edx
       mov      dword ptr [rsp+0x20], edx
       mov      rdx, gword ptr [rbx+0x10]
       mov      gword ptr [rsp+0x28], rdx
       lea      rdx, [rsp+0x48]
       mov      r9d, dword ptr [rbx+0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime:ReadExecutableOperand(Lokad.Lython.Frontend.ExecutableCodeObject,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],int,int,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):System.Object]
 
G_M000_IG155:                ;; offset=0x1014
       jmp      SHORT G_M000_IG159
 
G_M000_IG156:                ;; offset=0x1016
       mov      rcx, rdx
 
G_M000_IG157:                ;; offset=0x1019
       vmovdqu  xmm0, xmmword ptr [rbx+0x48]
       vmovdqu  xmmword ptr [rsp+0x48], xmm0
 
G_M000_IG158:                ;; offset=0x1024
       xor      edx, edx
       mov      dword ptr [rsp+0x20], edx
       mov      rdx, gword ptr [rbx+0x10]
       mov      gword ptr [rsp+0x28], rdx
       lea      rdx, [rsp+0x48]
       mov      r9d, dword ptr [rbx+0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime:ReadExecutableOperand(Lokad.Lython.Frontend.ExecutableCodeObject,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],int,int,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):System.Object]
       mov      rbp, rax
       xor      r14d, r14d
 
G_M000_IG159:                ;; offset=0x1048
       mov      rcx, rsi
       mov      rdx, rbp
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      qword ptr [rsi+0x08], r14
       mov      edx, dword ptr [rdi+0x10]
       mov      rcx, gword ptr [rbx+0x08]
       cmp      edx, dword ptr [rcx+0xD8]
       jl       SHORT G_M000_IG161
       lea      rcx, bword ptr [rbx+0x48]
       cmp      edx, dword ptr [rcx+0x08]
       jae      G_M000_IG221
       shl      rdx, 4
       add      rdx, bword ptr [rcx]
       xor      rcx, rcx
       mov      gword ptr [rdx], rcx
 
G_M000_IG160:                ;; offset=0x107F
       mov      qword ptr [rdx+0x08], rcx
 
G_M000_IG161:                ;; offset=0x1083
       mov      rdx, gword ptr [rbx+0x08]
       mov      edx, dword ptr [rdx+0xD8]
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Trim(int):this]
 
G_M000_IG162:                ;; offset=0x1096
       mov      eax, 1
 
G_M000_IG163:                ;; offset=0x109B
       add      rsp, 224
       pop      rbx
       pop      rbp
       pop      rsi
       pop      rdi
       pop      r13
       pop      r14
       pop      r15
       ret      
 
G_M000_IG164:                ;; offset=0x10AD
       mov      rcx, gword ptr [rbx+0x08]
       mov      edx, dword ptr [rcx+0xEC]
       mov      r8, gword ptr [rcx+0x98]
       cmp      edx, dword ptr [r8+0x08]
       jne      G_M000_IG143
 
G_M000_IG165:                ;; offset=0x10C8
       vmovdqu  xmm0, xmmword ptr [rbx+0x48]
       vmovdqu  xmmword ptr [rsp+0x48], xmm0
 
G_M000_IG166:                ;; offset=0x10D3
       mov      edx, dword ptr [rbx+0x30]
       mov      dword ptr [rsp+0x20], edx
       mov      rdx, gword ptr [rbx+0x10]
       mov      gword ptr [rsp+0x28], rdx
       lea      rdx, [rsp+0xC8]
       mov      qword ptr [rsp+0x30], rdx
       lea      rdx, [rsp+0x48]
       mov      r8d, dword ptr [rbx+0x38]
       mov      r9d, dword ptr [rbx+0x3C]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryPrepareIntegerTuple(Lokad.Lython.Frontend.ExecutableCodeObject,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],int,int,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       test     eax, eax
       je       G_M000_IG143
       mov      ecx, dword ptr [rbx+0x30]
       add      dword ptr [rbx+0x3C], ecx
       mov      ecx, dword ptr [rsp+0xC8]
       mov      dword ptr [rbx+0x38], ecx
       jmp      G_M000_IG148
 
G_M000_IG167:                ;; offset=0x1120
       mov      ecx, dword ptr [rdi+0x0C]
       add      ecx, 2
       mov      rdx, gword ptr [rbx+0x08]
       cmp      ecx, dword ptr [rdx+0xEC]
       jge      SHORT G_M000_IG170
       mov      rcx, gword ptr [rbx+0x10]
       mov      rcx, gword ptr [rcx+0xA0]
       cmp      qword ptr [rcx+0x158], 8
       jge      SHORT G_M000_IG170
       mov      rcx, rdx
 
G_M000_IG168:                ;; offset=0x114A
       vmovdqu  xmm0, xmmword ptr [rbx+0x48]
       vmovdqu  xmmword ptr [rsp+0x48], xmm0
 
G_M000_IG169:                ;; offset=0x1155
       mov      rdx, gword ptr [rbx+0x10]
       mov      gword ptr [rsp+0x20], rdx
       lea      rdx, [rsp+0xD0]
       mov      qword ptr [rsp+0x28], rdx
       lea      rdx, [rsp+0x48]
       mov      r9d, dword ptr [rbx+0x3C]
       lea      r8, bword ptr [rbx+0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryEvaluateIntegerCallUpdate(Lokad.Lython.Frontend.ExecutableCodeObject,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       test     eax, eax
       jne      SHORT G_M000_IG179
 
G_M000_IG170:                ;; offset=0x1182
       mov      edx, dword ptr [rdi+0x18]
       test     edx, edx
       jge      SHORT G_M000_IG171
       mov      r8d, edx
       not      r8d
       jmp      SHORT G_M000_IG172
 
G_M000_IG171:                ;; offset=0x1191
       mov      r8d, edx
 
G_M000_IG172:                ;; offset=0x1194
       mov      ecx, dword ptr [rdi+0x1C]
       cmp      ecx, 51
       ja       SHORT G_M000_IG176
 
G_M000_IG173:                ;; offset=0x119C
       mov      rax, 0x7FFFFFFFFF9FF
       bt       rax, rcx
       jb       SHORT G_M000_IG176
 
G_M000_IG174:                ;; offset=0x11AC
       test     edx, edx
       jge      SHORT G_M000_IG175
       not      edx
 
G_M000_IG175:                ;; offset=0x11B2
       jmp      SHORT G_M000_IG177
 
G_M000_IG176:                ;; offset=0x11B4
       mov      edx, dword ptr [rdi+0x14]
 
G_M000_IG177:                ;; offset=0x11B7
       cmp      r8d, edx
       jne      G_M000_IG143
 
G_M000_IG178:                ;; offset=0x11C0
       lea      rbp, bword ptr [rbx+0x48]
       mov      rcx, rdi
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LocalSlot():int:this]
       cmp      eax, dword ptr [rbp+0x08]
       jae      G_M000_IG221
       mov      rcx, bword ptr [rbp]
       mov      eax, eax
       shl      rax, 4
       cmp      gword ptr [rcx+rax], 0
       jne      G_M000_IG147
       jmp      G_M000_IG218
 
G_M000_IG179:                ;; offset=0x11F0
       mov      rdx, gword ptr [rbx+0x08]
       mov      rdx, gword ptr [rdx+0x98]
       mov      r8d, dword ptr [rbx+0x38]
       cmp      r8d, dword ptr [rdx+0x08]
       jae      G_M000_IG221
       shl      r8, 5
       lea      rdx, bword ptr [rdx+r8+0x10]
 
G_M000_IG180:                ;; offset=0x1212
       vmovdqu  xmm0, xmmword ptr [rsp+0xD0]
       vmovdqu  xmmword ptr [rsp+0x38], xmm0
 
G_M000_IG181:                ;; offset=0x1221
       lea      r8, [rsp+0x38]
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot):this]
       jmp      G_M000_IG147
 
G_M000_IG182:                ;; offset=0x1234
       lea      rcx, bword ptr [rbx+0x48]
       mov      edx, dword ptr [rdi+0x10]
       mov      r8d, dword ptr [rdi+0x08]
       mov      eax, edx
       mov      r10d, r8d
       add      rax, r10
       mov      r10d, dword ptr [rcx+0x08]
       cmp      rax, r10
       ja       G_M000_IG220
       shl      rdx, 4
       add      rdx, bword ptr [rcx]
       mov      bword ptr [rsp+0x48], rdx
       mov      dword ptr [rsp+0x50], r8d
       lea      rcx, [rsp+0x48]
       mov      rdx, gword ptr [rbx+0x10]
       mov      rdx, gword ptr [rdx+0xA0]
       mov      r8, gword ptr [rdi]
       call     [Lokad.Lython.Runtime.LythonRuntime:ReverseAssignmentValues(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],Lokad.Lython.Runtime.ExecutionState,Lokad.Lython.LythonSourceSpan)]
       jmp      G_M000_IG147
 
G_M000_IG183:                ;; offset=0x1283
       lea      rcx, bword ptr [rbx+0x48]
       cmp      ebp, 51
       ja       SHORT G_M000_IG187
 
G_M000_IG184:                ;; offset=0x128C
       mov      rax, 0x7FFFFFFFFF9FF
       bt       rax, rbp
       jb       SHORT G_M000_IG187
 
G_M000_IG185:                ;; offset=0x129C
       mov      ebp, dword ptr [rdi+0x18]
       test     ebp, ebp
       jge      SHORT G_M000_IG186
       not      ebp
 
G_M000_IG186:                ;; offset=0x12A5
       jmp      SHORT G_M000_IG188
 
G_M000_IG187:                ;; offset=0x12A7
       mov      ebp, dword ptr [rdi+0x14]
 
G_M000_IG188:                ;; offset=0x12AA
       cmp      ebp, dword ptr [rcx+0x08]
       jae      G_M000_IG221
       mov      rcx, bword ptr [rcx]
       mov      eax, ebp
       shl      rax, 4
 
G_M000_IG189:                ;; offset=0x12BC
       vmovdqu  xmm0, xmmword ptr [rcx+rax]
       vmovdqu  xmmword ptr [rsp+0xB0], xmm0
 
G_M000_IG190:                ;; offset=0x12CA
       cmp      gword ptr [rsp+0xB0], 0
       jne      SHORT G_M000_IG191
       lea      rcx, [rsp+0xB0]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Object():System.Object:this]
       mov      rdx, rax
       mov      rcx, 0x7FF9B54EBCC8
       call     [Lokad.Lython.Internal.NullabilityExtensions:RequireNotNull[System.__Canon](System.__Canon):System.__Canon]
 
G_M000_IG191:                ;; offset=0x12F6
       lea      rcx, bword ptr [rbx+0x48]
       mov      edx, dword ptr [rdi+0x1C]
       cmp      edx, 51
       ja       SHORT G_M000_IG195
 
G_M000_IG192:                ;; offset=0x1302
       mov      rax, 0x7FFFFFFFFF9FF
       bt       rax, rdx
       jb       SHORT G_M000_IG195
 
G_M000_IG193:                ;; offset=0x1312
       mov      edx, dword ptr [rdi+0x18]
       test     edx, edx
       jge      SHORT G_M000_IG194
       not      edx
 
G_M000_IG194:                ;; offset=0x131B
       jmp      SHORT G_M000_IG196
 
G_M000_IG195:                ;; offset=0x131D
       mov      edx, dword ptr [rdi+0x14]
 
G_M000_IG196:                ;; offset=0x1320
       cmp      edx, dword ptr [rcx+0x08]
       jae      G_M000_IG221
       mov      rcx, bword ptr [rcx]
       mov      edx, edx
       shl      rdx, 4
       xor      eax, eax
       mov      qword ptr [rcx+rdx], rax
       mov      qword ptr [rcx+rdx+0x08], rax
       mov      edx, dword ptr [rdi+0x18]
       test     edx, edx
       jge      SHORT G_M000_IG197
       not      edx
 
G_M000_IG197:                ;; offset=0x1346
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Trim(int):this]
       mov      rcx, bword ptr [rbx+0x48]
       mov      r8d, dword ptr [rbx+0x50]
       mov      rdx, gword ptr [rsp+0xB0]
       mov      r9, qword ptr [rsp+0xB8]
       mov      rax, gword ptr [rbx+0x10]
       mov      rax, gword ptr [rax+0xA0]
       mov      r10d, dword ptr [rdi+0x10]
       cmp      r10d, r8d
       jae      G_M000_IG221
       mov      r8d, r10d
       shl      r8, 4
       add      rcx, r8
       mov      gword ptr [rsp+0x38], rdx
       mov      qword ptr [rsp+0x40], r9
       lea      r8, [rsp+0x38]
       mov      rdx, rdi
       mov      r9, rax
       call     [Lokad.Lython.Runtime.LythonRuntime:StoreDefaultResult(byref,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot,Lokad.Lython.Runtime.ExecutionState)]
       jmp      G_M000_IG147
 
G_M000_IG198:                ;; offset=0x13A9
       mov      rdx, gword ptr [rbx+0x08]
       mov      rbp, gword ptr [rdx+0x30]
       mov      rcx, rdi
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ConstantIndex():int:this]
       cmp      eax, dword ptr [rbp+0x08]
       jae      G_M000_IG221
       mov      edx, eax
       mov      rdx, gword ptr [rbp+8*rdx+0x10]
       mov      rcx, rdx
       test     rcx, rcx
       je       SHORT G_M000_IG200
 
G_M000_IG199:                ;; offset=0x13D2
       mov      rax, 0x7FF9B52755B0
       cmp      qword ptr [rcx], rax
       jne      G_M000_IG216
 
G_M000_IG200:                ;; offset=0x13E5
       lea      rdx, bword ptr [rbx+0x48]
       mov      r8d, dword ptr [rdi+0x1C]
       mov      r9d, r8d
       cmp      r9d, 51
       ja       SHORT G_M000_IG204
 
G_M000_IG201:                ;; offset=0x13F6
       mov      rax, 0x7FFFFFFFFF9FF
       bt       rax, r9
       jb       SHORT G_M000_IG204
 
G_M000_IG202:                ;; offset=0x1406
       mov      r9d, dword ptr [rdi+0x18]
       test     r9d, r9d
       jge      SHORT G_M000_IG203
       not      r9d
 
G_M000_IG203:                ;; offset=0x1412
       jmp      SHORT G_M000_IG205
 
G_M000_IG204:                ;; offset=0x1414
       mov      r9d, dword ptr [rdi+0x14]
 
G_M000_IG205:                ;; offset=0x1418
       mov      eax, dword ptr [rdi+0x18]
       test     eax, eax
       jge      SHORT G_M000_IG206
       mov      r10d, eax
       not      r10d
       jmp      SHORT G_M000_IG207
 
G_M000_IG206:                ;; offset=0x1427
       mov      r10d, eax
 
G_M000_IG207:                ;; offset=0x142A
       cmp      r8d, 51
       ja       SHORT G_M000_IG212
 
G_M000_IG208:                ;; offset=0x1430
       mov      r11, 0x7FFFFFFFFF9FF
       bt       r11, r8
       jb       SHORT G_M000_IG212
 
G_M000_IG209:                ;; offset=0x1440
       test     eax, eax
       jge      SHORT G_M000_IG210
       mov      r8d, eax
       not      r8d
       jmp      SHORT G_M000_IG211
 
G_M000_IG210:                ;; offset=0x144C
       mov      r8d, eax
 
G_M000_IG211:                ;; offset=0x144F
       jmp      SHORT G_M000_IG213
 
G_M000_IG212:                ;; offset=0x1451
       mov      r8d, dword ptr [rdi+0x14]
 
G_M000_IG213:                ;; offset=0x1455
       sub      r10d, r8d
       mov      r8d, r9d
       mov      eax, r10d
       add      r8, rax
       mov      eax, dword ptr [rdx+0x08]
       cmp      r8, rax
       ja       G_M000_IG220
       mov      r8d, r9d
       shl      r8, 4
       add      r8, bword ptr [rdx]
       mov      bword ptr [rsp+0x48], r8
       mov      dword ptr [rsp+0x50], r10d
       mov      rdx, gword ptr [rdi]
       mov      gword ptr [rsp+0x20], rdx
       lea      rdx, [rsp+0x48]
       cmp      dword ptr [rdi+0x0C], 0
       setne    r8b
       movzx    r8, r8b
       mov      r9, gword ptr [rbx+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime:StartExecutableDefaults(Lokad.Lython.Frontend.FunctionParameterLayout,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],bool,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan)]
       mov      ecx, dword ptr [rdi+0x18]
       test     ecx, ecx
       jge      SHORT G_M000_IG214
       not      ecx
 
G_M000_IG214:                ;; offset=0x14AD
       mov      dword ptr [rbx+0x3C], ecx
       jmp      G_M000_IG147
 
G_M000_IG215:                ;; offset=0x14B5
       mov      rcx, rbx
       mov      rdx, rdi
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Format(byref):bool:this]
       test     eax, eax
       jne      G_M000_IG147
       jmp      G_M000_IG07
 
G_M000_IG216:                ;; offset=0x14CE
       mov      rcx, rax
       call     CORINFO_HELP_CHKCASTCLASS
       int3     
 
G_M000_IG217:                ;; offset=0x14D7
       mov      rdx, rcx
       mov      rcx, rax
       call     CORINFO_HELP_CHKCASTCLASS
       int3     
 
G_M000_IG218:                ;; offset=0x14E3
       mov      rcx, gword ptr [rbx+0x08]
       mov      rbx, gword ptr [rcx+0x68]
       mov      rcx, rdi
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LocalSlot():int:this]
       mov      edx, eax
       mov      rcx, rbx
       mov      r11, 0x7FF9B4B636B0
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       mov      rcx, rax
       mov      rdx, gword ptr [rdi]
       call     [Lokad.Lython.Runtime.RuntimeErrors:UnboundLocalVariable(System.String,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.LythonRuntimeException]
       mov      rcx, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG219:                ;; offset=0x151B
       mov      rcx, rdi
       mov      rdx, 0x19F4A07E468
       call     [Lokad.Lython.Frontend.ExecutableInstruction:InvalidOperand(System.String):System.InvalidOperationException:this]
       mov      rcx, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG220:                ;; offset=0x1537
       call     [System.ThrowHelper:ThrowArgumentOutOfRangeException()]
       int3     
 
G_M000_IG221:                ;; offset=0x153E
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
RWD00  	dd	00000EB4h ; case G_M000_IG146
       	dd	00000E5Bh ; case G_M000_IG143
       	dd	00000DC4h ; case G_M000_IG140
       	dd	00000D7Fh ; case G_M000_IG139
       	dd	0000009Ch ; case G_M000_IG07
       	dd	00000D66h ; case G_M000_IG138
       	dd	0000009Ch ; case G_M000_IG07
       	dd	0000009Ch ; case G_M000_IG07
       	dd	00000D4Dh ; case G_M000_IG137
       	dd	00000D4Dh ; case G_M000_IG137
       	dd	0000009Ch ; case G_M000_IG07
       	dd	0000009Ch ; case G_M000_IG07
       	dd	0000009Ch ; case G_M000_IG07
       	dd	0000009Ch ; case G_M000_IG07
       	dd	0000009Ch ; case G_M000_IG07
       	dd	0000009Ch ; case G_M000_IG07
       	dd	0000009Ch ; case G_M000_IG07
       	dd	0000009Ch ; case G_M000_IG07
       	dd	0000009Ch ; case G_M000_IG07
       	dd	0000009Ch ; case G_M000_IG07
       	dd	0000009Ch ; case G_M000_IG07
       	dd	0000009Ch ; case G_M000_IG07
       	dd	00000B93h ; case G_M000_IG110
       	dd	0000009Ch ; case G_M000_IG07
       	dd	00000B82h ; case G_M000_IG109
       	dd	00000A57h ; case G_M000_IG98
       	dd	0000009Ch ; case G_M000_IG07
       	dd	0000009Ch ; case G_M000_IG07
       	dd	00000998h ; case G_M000_IG86
       	dd	0000094Dh ; case G_M000_IG82
       	dd	000008D0h ; case G_M000_IG81
       	dd	00000823h ; case G_M000_IG78
       	dd	0000080Ah ; case G_M000_IG77
       	dd	0000080Ah ; case G_M000_IG77
       	dd	0000080Ah ; case G_M000_IG77
       	dd	0000009Ch ; case G_M000_IG07
       	dd	0000009Ch ; case G_M000_IG07
       	dd	0000009Ch ; case G_M000_IG07
       	dd	0000009Ch ; case G_M000_IG07
       	dd	0000069Ah ; case G_M000_IG65
       	dd	000005A4h ; case G_M000_IG51
       	dd	0000058Bh ; case G_M000_IG50
       	dd	000002D2h ; case G_M000_IG29
       	dd	0000009Ch ; case G_M000_IG07
       	dd	0000009Ch ; case G_M000_IG07
       	dd	00000265h ; case G_M000_IG23
       	dd	00000265h ; case G_M000_IG23
       	dd	00000276h ; case G_M000_IG24
       	dd	00000689h ; case G_M000_IG64
       	dd	000001F4h ; case G_M000_IG20
       	dd	000000EAh ; case G_M000_IG10
       	dd	0000009Ch ; case G_M000_IG07
       	dd	0000009Ch ; case G_M000_IG07
       	dd	0000009Ch ; case G_M000_IG07
       	dd	0000009Ch ; case G_M000_IG07
       	dd	0000009Ch ; case G_M000_IG07
       	dd	00000F57h ; case G_M000_IG152
       	dd	00000F38h ; case G_M000_IG151
       	dd	00000F38h ; case G_M000_IG151
       	dd	0000009Ch ; case G_M000_IG07
       	dd	0000009Ch ; case G_M000_IG07
       	dd	000000B0h ; case G_M000_IG09
       	dd	0000146Ch ; case G_M000_IG215
       	dd	0000146Ch ; case G_M000_IG215
       	dd	0000146Ch ; case G_M000_IG215
       	dd	0000146Ch ; case G_M000_IG215
       	dd	0000146Ch ; case G_M000_IG215
       	dd	0000009Ch ; case G_M000_IG07
       	dd	000005A4h ; case G_M000_IG51
       	dd	00001360h ; case G_M000_IG198
       	dd	0000123Ah ; case G_M000_IG183
       	dd	00001177h ; case G_M000_IG178
       	dd	000011EBh ; case G_M000_IG182
       	dd	000010D7h ; case G_M000_IG167
       	dd	00001064h ; case G_M000_IG164

; Total bytes of code 5444

; Assembly listing for method Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Call(byref):bool:this (FullOpts)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; FullOpts code
; optimized code
; rbp based frame
; fully interruptible
; No PGO data
; 0 inlinees with PGO data; 99 single block inlinees; 18 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       push     r15
       push     r14
       push     r13
       push     r12
       push     rdi
       push     rsi
       push     rbx
       sub      rsp, 296
       lea      rbp, [rsp+0x160]
       xor      eax, eax
       mov      qword ptr [rbp-0x108], rax
       vxorps   xmm4, xmm4, xmm4
       mov      rax, -192
 
G_M000_IG102:                ;; offset=0x0032
       vmovdqa  xmmword ptr [rbp+rax-0x40], xmm4
       vmovdqa  xmmword ptr [rbp+rax-0x30], xmm4
       vmovdqa  xmmword ptr [rbp+rax-0x20], xmm4
       add      rax, 48
       jne      SHORT G_M000_IG102
       mov      qword ptr [rbp-0x40], rax
       mov      bword ptr [rbp+0x10], rcx
       mov      rbx, rdx
 
G_M000_IG02:                ;; offset=0x0055
       mov      rdx, gword ptr [rcx+0x08]
       mov      r11, gword ptr [rdx+0xB0]
       cmp      dword ptr [rbx+0x1C], 42
       jne      G_M000_IG89
       mov      edx, dword ptr [rbx+0x08]
       mov      rcx, r11
       mov      r11, 0x7FF9B4B636D0
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       mov      gword ptr [rbp-0x110], rax
       mov      ecx, dword ptr [rbx+0x1C]
       cmp      ecx, 51
       ja       SHORT G_M000_IG06
 
G_M000_IG03:                ;; offset=0x008C
       mov      r8, 0x7FFFFFFFFF9FF
       bt       r8, rcx
       jb       SHORT G_M000_IG06
 
G_M000_IG04:                ;; offset=0x009C
       mov      esi, dword ptr [rbx+0x18]
       test     esi, esi
       jge      SHORT G_M000_IG05
       not      esi
 
G_M000_IG05:                ;; offset=0x00A5
       jmp      SHORT G_M000_IG07
 
G_M000_IG06:                ;; offset=0x00A7
       mov      esi, dword ptr [rbx+0x14]
 
G_M000_IG07:                ;; offset=0x00AA
       cmp      dword ptr [rbx+0x0C], 0x7FFFFFFF
       je       G_M000_IG28
 
G_M000_IG08:                ;; offset=0x00B7
       mov      rcx, bword ptr [rbp+0x10]
       cmp      dword ptr [rcx+0x3C], esi
       jne      G_M000_IG28
       mov      r8, gword ptr [rcx+0x08]
       lea      rdi, bword ptr [rcx+0x48]
 
G_M000_IG09:                ;; offset=0x00CC
       vmovdqu  xmm0, xmmword ptr [rdi]
       vmovdqu  xmmword ptr [rbp-0xE8], xmm0
 
G_M000_IG10:                ;; offset=0x00D8
       xor      r9d, r9d
       mov      dword ptr [rsp+0x20], r9d
       mov      r9, gword ptr [rcx+0x10]
       mov      gword ptr [rsp+0x28], r9
       mov      rcx, r8
       lea      rdx, [rbp-0xE8]
       mov      r8d, dword ptr [rbx+0x10]
       mov      r14, bword ptr [rbp+0x10]
       mov      r9d, dword ptr [r14+0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime:ReadExecutableOperand(Lokad.Lython.Frontend.ExecutableCodeObject,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],int,int,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):System.Object]
       mov      r15, rax
       mov      r13d, dword ptr [rbx+0x0C]
       cmp      dword ptr [rbx+0x10], 0
       jl       G_M000_IG17
       mov      r8, gword ptr [r14+0x10]
       mov      r8, gword ptr [r8+0xA0]
       cmp      qword ptr [r8+0x158], 8
       jge      G_M000_IG17
       test     r15, r15
       je       G_M000_IG17
 
G_M000_IG11:                ;; offset=0x0138
       mov      r8, 0x7FF9B54EA2D8
       cmp      qword ptr [r15], r8
       jne      SHORT G_M000_IG17
 
G_M000_IG12:                ;; offset=0x0147
       mov      r8, rdi
       cmp      r13d, dword ptr [r8+0x08]
       jae      G_M000_IG92
       mov      r8, bword ptr [r8]
       mov      r9d, r13d
       shl      r9, 4
 
G_M000_IG13:                ;; offset=0x015E
       vmovdqu  xmm0, xmmword ptr [r8+r9]
       vmovdqu  xmmword ptr [rbp-0xF8], xmm0
 
G_M000_IG14:                ;; offset=0x016C
       lea      r8, [rbp-0x60]
       mov      qword ptr [rsp+0x20], r8
       lea      r8, [rbp-0xF8]
       mov      r9, gword ptr [r14+0x10]
       mov      rdx, gword ptr [rbp-0x110]
       mov      rcx, r15
       call     [Lokad.Lython.Runtime.PyExecutableFunction:TryStartForwardedComputedDefinition(Lokad.Lython.Frontend.ExecutableCallSite,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool:this]
       test     eax, eax
       je       SHORT G_M000_IG17
 
G_M000_IG15:                ;; offset=0x0194
       vmovdqu  xmm0, xmmword ptr [rbp-0x60]
       vmovdqu  xmmword ptr [rbp-0xF8], xmm0
 
G_M000_IG16:                ;; offset=0x01A1
       lea      r8, [rbp-0xF8]
       mov      rdx, rbx
       mov      rcx, r14
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot):this]
       jmp      G_M000_IG80
 
G_M000_IG17:                ;; offset=0x01B9
       test     r13d, r13d
       jl       SHORT G_M000_IG22
       mov      r9, rdi
       cmp      r13d, dword ptr [r9+0x08]
       jae      G_M000_IG92
       mov      r8d, r13d
       shl      r8, 4
       add      r8, bword ptr [r9]
       mov      rcx, qword ptr [r8+0x08]
       test     rcx, rcx
       jle      SHORT G_M000_IG22
       mov      r9, gword ptr [r8]
       test     r9, r9
       je       SHORT G_M000_IG20
 
G_M000_IG18:                ;; offset=0x01EA
       mov      r8, 0x7FF9B51DB730
       cmp      qword ptr [r9], r8
       jne      SHORT G_M000_IG20
 
G_M000_IG19:                ;; offset=0x01F9
       mov      r9d, 1
       jmp      SHORT G_M000_IG21
       align    [2 bytes for IG79]
 
G_M000_IG20:                ;; offset=0x0203
       xor      r9d, r9d
 
G_M000_IG21:                ;; offset=0x0206
       test     r9d, r9d
       je       SHORT G_M000_IG22
       lea      r9, [rbp-0x70]
       mov      qword ptr [rsp+0x20], r9
       mov      r9, gword ptr [r14+0x10]
       mov      rdx, gword ptr [rbp-0x110]
       mov      r8, gword ptr [rdx+0x18]
       mov      rdx, r15
       call     [Lokad.Lython.Runtime.LythonRuntime:TryInvokeShortUtf8Float(long,System.Object,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       test     eax, eax
       jne      G_M000_IG87
 
G_M000_IG22:                ;; offset=0x0234
       mov      rcx, gword ptr [r14+0x08]
 
G_M000_IG23:                ;; offset=0x0238
       vmovdqu  xmm0, xmmword ptr [rdi]
       vmovdqu  xmmword ptr [rbp-0xE8], xmm0
 
G_M000_IG24:                ;; offset=0x0244
       mov      dword ptr [rsp+0x20], 1
       mov      rdx, gword ptr [r14+0x10]
       mov      gword ptr [rsp+0x28], rdx
       lea      rdx, [rbp-0xE8]
       mov      r9d, dword ptr [r14+0x38]
       mov      r8d, r13d
       call     [Lokad.Lython.Runtime.LythonRuntime:ReadExecutableOperand(Lokad.Lython.Frontend.ExecutableCodeObject,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],int,int,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):System.Object]
       mov      r13, rax
       mov      rdx, r15
       mov      rcx, 0x7FF9B54BACD0
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG25
       mov      rdx, gword ptr [rbp-0x110]
       mov      r12, gword ptr [rdx+0x18]
       mov      r10, gword ptr [r14+0x10]
       mov      gword ptr [rbp-0x118], r10
       vxorps   xmm0, xmm0, xmm0
       vmovdqu  xmmword ptr [rbp-0x80], xmm0
       mov      rcx, rax
       mov      rdx, r13
       xor      r8d, r8d
       call     [Lokad.Lython.Runtime.LythonRuntime:SelectNativeUnaryOperation(Lokad.Lython.Runtime.LythonRuntime+BuiltinCallable,System.Object,bool):System.Func`4[System.Object,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]]
       test     rax, rax
       jne      G_M000_IG84
 
G_M000_IG25:                ;; offset=0x02BA
       lea      r12d, [rsi+0x01]
       cmp      r12d, dword ptr [r14+0x3C]
       jge      SHORT G_M000_IG26
       mov      rcx, r14
       mov      edx, r12d
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Trim(int):this]
 
G_M000_IG26:                ;; offset=0x02D0
       mov      rcx, rdi
       cmp      esi, dword ptr [rcx+0x08]
       jae      G_M000_IG92
       mov      ebx, esi
       shl      rbx, 4
       add      rbx, bword ptr [rcx]
       mov      rcx, rbx
       mov      rdx, r15
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       xor      ecx, ecx
       mov      qword ptr [rbx+0x08], rcx
       mov      dword ptr [r14+0x3C], r12d
       lea      ebx, [rsi+0x01]
       lea      r15d, [rsi+0x02]
       cmp      r15d, dword ptr [r14+0x3C]
       jge      SHORT G_M000_IG27
       mov      rcx, r14
       mov      edx, r15d
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Trim(int):this]
 
G_M000_IG27:                ;; offset=0x0313
       cmp      ebx, dword ptr [rdi+0x08]
       jae      G_M000_IG92
       mov      ebx, ebx
       shl      rbx, 4
       add      rbx, bword ptr [rdi]
       mov      rcx, rbx
       mov      rdx, r13
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       xor      ecx, ecx
       mov      qword ptr [rbx+0x08], rcx
       mov      dword ptr [r14+0x3C], r15d
 
G_M000_IG28:                ;; offset=0x033A
       mov      r14, bword ptr [rbp+0x10]
       lea      rdi, bword ptr [r14+0x48]
       mov      rcx, rdi
       mov      rdx, gword ptr [rbp-0x110]
       cmp      byte  ptr [rdx+0x30], 0
       setne    al
       movzx    rax, al
       add      eax, esi
       cmp      eax, dword ptr [rcx+0x08]
       jae      G_M000_IG92
       shl      rax, 4
       add      rax, bword ptr [rcx]
       mov      rcx, rax
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Object():System.Object:this]
       mov      rdx, rax
       mov      rcx, 0x7FF9B54EBCC8
       call     [Lokad.Lython.Internal.NullabilityExtensions:RequireNotNull[System.__Canon](System.__Canon):System.__Canon]
       mov      r13, rax
       vxorps   xmm0, xmm0, xmm0
       vmovdqu  xmmword ptr [rbp-0x48], xmm0
       xor      ecx, ecx
       mov      dword ptr [rbp-0x50], ecx
 
G_M000_IG29:                ;; offset=0x0395
       mov      rdx, gword ptr [rbp-0x110]
       cmp      byte  ptr [rdx+0x34], 0
       je       G_M000_IG57
       cmp      byte  ptr [rdx+0x30], 0
       jne      SHORT G_M000_IG30
       mov      rcx, r13
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:IsRangeBuiltin(System.Object):bool]
       test     eax, eax
       jne      G_M000_IG55
 
G_M000_IG30:                ;; offset=0x03BD
       mov      rdx, gword ptr [rbp-0x110]
       cmp      byte  ptr [rdx+0x30], 0
       je       G_M000_IG51
       test     r13, r13
       je       G_M000_IG51
 
G_M000_IG31:                ;; offset=0x03D7
       mov      rcx, 0x7FF9B5544A20
       cmp      qword ptr [r13], rcx
       jne      G_M000_IG51
 
G_M000_IG32:                ;; offset=0x03EB
       mov      rcx, rdi
       cmp      esi, dword ptr [rcx+0x08]
       jae      G_M000_IG62
       mov      eax, esi
       shl      rax, 4
       add      rax, bword ptr [rcx]
       mov      rcx, rax
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Object():System.Object:this]
       mov      rbx, rax
       mov      rdx, gword ptr [rbp-0x110]
       cmp      dword ptr [rdx+0x28], 0
       jne      G_M000_IG46
       test     rbx, rbx
       je       G_M000_IG46
 
G_M000_IG33:                ;; offset=0x0426
       mov      rcx, 0x7FF9B5277B10
       cmp      qword ptr [rbx], rcx
       jne      G_M000_IG46
 
G_M000_IG34:                ;; offset=0x0439
       mov      r15, rbx
       mov      r12, gword ptr [rdx+0x20]
       test     r12, r12
       je       G_M000_IG46
 
G_M000_IG35:                ;; offset=0x0449
       mov      rcx, 0x7FF9B55445F8
       cmp      qword ptr [r12], rcx
       jne      G_M000_IG46
 
G_M000_IG36:                ;; offset=0x045D
       cmp      r13, gword ptr [r12+0x08]
       jne      G_M000_IG46
       mov      rcx, gword ptr [r14+0x08]
       mov      rcx, gword ptr [rcx+0x98]
       mov      r11d, dword ptr [r14+0x38]
       add      r11d, 2
       cmp      r11d, dword ptr [rcx+0x08]
       jae      G_M000_IG62
       shl      r11, 5
 
G_M000_IG37:                ;; offset=0x0489
       vmovdqu  ymm0, ymmword ptr [rcx+r11+0x10]
       vmovdqu  ymmword ptr [rbp-0xB8], ymm0
 
G_M000_IG38:                ;; offset=0x0498
       mov      rcx, gword ptr [r14+0x08]
       mov      rcx, gword ptr [rcx+0xB0]
       cmp      dword ptr [rbp-0x9C], 42
       jne      G_M000_IG59
       mov      edx, dword ptr [rbp-0xB0]
       mov      r11, 0x7FF9B4B636E8
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       mov      rsi, rax
       mov      rcx, gword ptr [r14+0x10]
       mov      rdx, gword ptr [r12+0x18]
       mov      rcx, gword ptr [rcx+0xA0]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.ExecutionState:EnterInterpreterFrame(Lokad.Lython.LythonSourceSpan):this]
       nop      
 
G_M000_IG39:                ;; offset=0x04DF
       mov      r8, gword ptr [r14+0x10]
       cmp      byte  ptr [rsi+0x31], 0
       je       SHORT G_M000_IG40
       mov      r9d, 1
       jmp      SHORT G_M000_IG42
 
G_M000_IG40:                ;; offset=0x04F1
       cmp      byte  ptr [r14+0x40], 0
       jne      SHORT G_M000_IG41
       xor      r9d, r9d
       jmp      SHORT G_M000_IG42
 
G_M000_IG41:                ;; offset=0x04FD
       movzx    r9, byte  ptr [rsi+0x32]
 
G_M000_IG42:                ;; offset=0x0502
       mov      rcx, r12
       mov      rdx, r15
       call     [Lokad.Lython.Runtime.LythonRuntime:ExecuteCasedSplit(Lokad.Lython.Frontend.ExecutableCasedSplit,Lokad.Lython.Runtime.Text.PyString,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,bool):System.Object]
       mov      gword ptr [rbp-0x48], rax
       xor      ecx, ecx
       mov      qword ptr [rbp-0x40], rcx
 
G_M000_IG43:                ;; offset=0x0518
       mov      rsi, gword ptr [r14+0x10]
       mov      rcx, gword ptr [rsi+0xA0]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.ExecutionState:LeaveInterpreterFrame():this]
       add      dword ptr [r14+0x38], 2
 
G_M000_IG44:                ;; offset=0x0530
       vmovdqu  xmm0, xmmword ptr [rbp-0x48]
       vmovdqu  xmmword ptr [rbp-0xF8], xmm0
 
G_M000_IG45:                ;; offset=0x053D
       lea      r8, [rbp-0xF8]
       lea      rdx, [rbp-0xB8]
       mov      rcx, r14
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot):this]
       mov      r15d, 1
       jmp      G_M000_IG82
 
G_M000_IG46:                ;; offset=0x055F
       mov      rdx, gword ptr [rbp-0x110]
       mov      r15, gword ptr [rdx+0x20]
       test     r15, r15
       je       G_M000_IG50
 
G_M000_IG47:                ;; offset=0x0573
       mov      r8, 0x7FF9B5544D28
       cmp      qword ptr [r15], r8
       jne      G_M000_IG50
 
G_M000_IG48:                ;; offset=0x0586
       mov      r8, gword ptr [r14+0x08]
       mov      r8, gword ptr [r8+0x98]
       mov      ecx, dword ptr [r14+0x38]
       add      ecx, 3
       cmp      ecx, dword ptr [r8+0x08]
       jae      G_M000_IG62
       shl      rcx, 5
       cmp      dword ptr [r8+rcx+0x20], esi
       jne      G_M000_IG50
       mov      r8, bword ptr [r14+0x48]
       mov      ecx, dword ptr [r14+0x50]
       mov      bword ptr [rbp-0x108], r8
       mov      dword ptr [rbp-0x100], ecx
       lea      r8, [rbp-0x90]
       mov      qword ptr [rsp+0x20], r8
       lea      r8, [rbp-0x98]
       mov      qword ptr [rsp+0x28], r8
       lea      r8, [rbp-0x108]
       mov      rdx, r13
       mov      rcx, gword ptr [rbp-0x110]
       mov      r9d, esi
       call     [Lokad.Lython.Runtime.LythonRuntime:TryReadAsciiTrim(Lokad.Lython.Frontend.ExecutableCallSite,System.Object,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],int,byref,byref):bool]
       test     eax, eax
       je       G_M000_IG50
       mov      rdx, gword ptr [r14+0x08]
       mov      rcx, gword ptr [rdx+0xB0]
       mov      rdx, gword ptr [rdx+0x98]
       mov      r11d, dword ptr [r14+0x38]
       add      r11d, 3
       cmp      r11d, dword ptr [rdx+0x08]
       jae      G_M000_IG62
       shl      r11, 5
       lea      rax, bword ptr [rdx+r11+0x10]
       cmp      dword ptr [rax+0x1C], 42
       jne      G_M000_IG60
       mov      edx, dword ptr [rax+0x08]
       mov      r11, 0x7FF9B4B636E0
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       mov      rdx, gword ptr [rbp-0x90]
       movzx    r8, byte  ptr [rbp-0x98]
       mov      rcx, gword ptr [rbp-0x110]
       mov      r9, gword ptr [rcx+0x18]
       mov      rax, gword ptr [rax+0x18]
       mov      gword ptr [rsp+0x20], rax
       xor      rax, rax
       mov      bword ptr [rbp-0xE8], rax
 
G_M000_IG49:                ;; offset=0x0673
       mov      dword ptr [rbp-0xE0], eax
       mov      rax, gword ptr [r14+0x10]
       mov      gword ptr [rsp+0x30], rax
       lea      rax, [rbp-0xE8]
       mov      qword ptr [rsp+0x28], rax
       mov      rcx, r15
       call     [Lokad.Lython.Runtime.LythonRuntime:ExecuteTrimmedSplit(Lokad.Lython.Frontend.ExecutableTrimmedSplit,Lokad.Lython.Runtime.Text.PyString,byte,Lokad.Lython.LythonSourceSpan,Lokad.Lython.LythonSourceSpan,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):Lokad.Lython.Runtime.PyList]
       mov      gword ptr [rbp-0x48], rax
       xor      ecx, ecx
       mov      qword ptr [rbp-0x40], rcx
       add      dword ptr [r14+0x38], 3
       jmp      G_M000_IG63
 
G_M000_IG50:                ;; offset=0x06AB
       mov      rdx, gword ptr [r14+0x08]
       mov      r8, bword ptr [r14+0x48]
       mov      r9d, dword ptr [r14+0x50]
       mov      bword ptr [rbp-0x108], r8
       mov      dword ptr [rbp-0x100], r9d
       mov      rcx, gword ptr [rbp-0x110]
       mov      gword ptr [rsp+0x20], rcx
       mov      dword ptr [rsp+0x28], esi
       mov      r8, gword ptr [r14+0x10]
       mov      gword ptr [rsp+0x30], r8
       lea      r8, [rbp-0x48]
       mov      qword ptr [rsp+0x38], r8
       lea      r8, [rbp-0x108]
       lea      r9, bword ptr [r14+0x38]
       mov      rcx, r13
       call     [Lokad.Lython.Runtime.LythonRuntime:TryConsumePrivateStringResult(Lokad.Lython.Runtime.LythonRuntime+ReceiverMethod,Lokad.Lython.Frontend.ExecutableCodeObject,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,Lokad.Lython.Frontend.ExecutableCallSite,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       test     eax, eax
       jne      G_M000_IG63
       mov      r8, rdi
       mov      rcx, gword ptr [rbp-0x110]
       cmp      byte  ptr [rcx+0x30], 0
       setne    r9b
       movzx    r9, r9b
       lea      r9d, [rsi+r9+0x01]
       mov      edx, dword ptr [rcx+0x28]
       mov      eax, r9d
       mov      r10d, edx
       add      rax, r10
       mov      r10d, dword ptr [r8+0x08]
       cmp      rax, r10
       ja       G_M000_IG58
       shl      r9, 4
       add      r9, bword ptr [r8]
       mov      bword ptr [rbp-0xE8], r9
       mov      dword ptr [rbp-0xE0], edx
       mov      r8, gword ptr [r14+0x10]
       mov      gword ptr [rsp+0x20], r8
       lea      r8, [rbp-0xC0]
       mov      qword ptr [rsp+0x28], r8
       lea      r8, [rbp-0xE8]
       mov      r9, gword ptr [rcx+0x18]
       mov      rdx, rbx
       mov      rcx, r13
       call     [Lokad.Lython.Runtime.LythonRuntime:TryInvokeClosedReceiver(Lokad.Lython.Runtime.LythonRuntime+ReceiverMethod,System.Object,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       test     eax, eax
       je       G_M000_IG54
       mov      r8, gword ptr [rbp-0xC0]
       mov      gword ptr [rbp-0x48], r8
       jmp      G_M000_IG56
 
G_M000_IG51:                ;; offset=0x078F
       vmovdqu  xmm0, xmmword ptr [rdi]
       vmovdqu  xmmword ptr [rbp-0xE8], xmm0
 
G_M000_IG52:                ;; offset=0x079B
       mov      r8, gword ptr [r14+0x10]
       mov      gword ptr [rsp+0x20], r8
       xor      r8d, r8d
       mov      dword ptr [rsp+0x28], r8d
       lea      r8, [rbp-0x48]
       mov      qword ptr [rsp+0x30], r8
       lea      r8, [rbp-0xE8]
       mov      rdx, r13
       mov      rcx, gword ptr [rbp-0x110]
       mov      r9d, esi
       call     [Lokad.Lython.Runtime.LythonRuntime:TryInvokeBuiltinFromSlots(Lokad.Lython.Frontend.ExecutableCallSite,System.Object,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,bool,byref):bool]
       test     eax, eax
       jne      SHORT G_M000_IG53
       lea      rcx, [rbp-0x48]
       mov      qword ptr [rsp+0x20], rcx
       lea      rcx, [rbp-0x50]
       mov      qword ptr [rsp+0x28], rcx
       mov      rcx, r14
       mov      rdx, gword ptr [rbp-0x110]
       mov      r8d, esi
       mov      r9, r13
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:CallFunction(Lokad.Lython.Frontend.ExecutableCallSite,int,System.Object,byref,byref):bool:this]
       test     eax, eax
       jne      G_M000_IG63
       jmp      SHORT G_M000_IG54
 
G_M000_IG53:                ;; offset=0x0805
       mov      rdx, gword ptr [rbp-0x48]
       mov      rcx, 0x7FF9B51DC748
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       mov      r13, rax
       test     r13, r13
       je       G_M000_IG63
       mov      rcx, gword ptr [r14+0x08]
       mov      rcx, gword ptr [rcx+0xA0]
       mov      r11, 0x7FF9B4B636D8
       call     [r11]System.Collections.Generic.IReadOnlyCollection`1[System.__Canon]:get_Count():int:this
       test     eax, eax
       je       G_M000_IG61
       mov      gword ptr [r14+0x28], r13
 
G_M000_IG54:                ;; offset=0x0848
       xor      r15d, r15d
       jmp      G_M000_IG82
 
G_M000_IG55:                ;; offset=0x0850
       mov      rcx, rdi
       mov      rdx, gword ptr [rbp-0x110]
       cmp      byte  ptr [rdx+0x30], 0
       setne    r8b
       movzx    r8, r8b
       lea      r8d, [rsi+r8+0x01]
       mov      r9d, dword ptr [rdx+0x28]
       mov      eax, r8d
       mov      r10d, r9d
       add      rax, r10
       mov      r10d, dword ptr [rcx+0x08]
       cmp      rax, r10
       ja       SHORT G_M000_IG58
       shl      r8, 4
       add      r8, bword ptr [rcx]
       mov      bword ptr [rbp-0xE8], r8
       mov      dword ptr [rbp-0xE0], r9d
       lea      rcx, [rbp-0xE8]
       mov      rdx, gword ptr [rdx+0x18]
       mov      r8, gword ptr [r14+0x10]
       lea      r9, [rbp-0x88]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryInvokeNativeRange(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       test     eax, eax
       je       SHORT G_M000_IG54
       mov      rax, gword ptr [rbp-0x88]
       mov      gword ptr [rbp-0x48], rax
 
G_M000_IG56:                ;; offset=0x08C1
       xor      eax, eax
       mov      qword ptr [rbp-0x40], rax
       jmp      SHORT G_M000_IG63
 
G_M000_IG57:                ;; offset=0x08C9
       lea      rcx, [rbp-0x48]
       mov      qword ptr [rsp+0x20], rcx
       lea      rcx, [rbp-0x50]
       mov      qword ptr [rsp+0x28], rcx
       mov      rcx, r14
       mov      r8d, esi
       mov      r9, r13
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:CallFunction(Lokad.Lython.Frontend.ExecutableCallSite,int,System.Object,byref,byref):bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG63
       jmp      G_M000_IG54
 
G_M000_IG58:                ;; offset=0x08F3
       call     [System.ThrowHelper:ThrowArgumentOutOfRangeException()]
       int3     
 
G_M000_IG59:                ;; offset=0x08FA
       lea      rcx, [rbp-0xB8]
       mov      rdx, 0x19F4A0791D0
       call     [Lokad.Lython.Frontend.ExecutableInstruction:InvalidOperand(System.String):System.InvalidOperationException:this]
       mov      rcx, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG60:                ;; offset=0x091A
       mov      rcx, rax
       mov      rdx, 0x19F4A0791D0
       call     [Lokad.Lython.Frontend.ExecutableInstruction:InvalidOperand(System.String):System.InvalidOperationException:this]
       mov      rcx, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG61:                ;; offset=0x0936
       mov      rcx, r13
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG62:                ;; offset=0x093F
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG63:                ;; offset=0x0945
       mov      rdx, gword ptr [rbp-0x110]
       cmp      dword ptr [rdx+0x2C], 0
       je       SHORT G_M000_IG64
       mov      rcx, gword ptr [r14+0x08]
       mov      rbx, gword ptr [rcx+0x98]
       mov      rcx, rbx
       mov      r15d, dword ptr [r14+0x38]
       mov      r8d, r15d
       cmp      r8d, dword ptr [rcx+0x08]
       jae      G_M000_IG92
       shl      r8, 5
       cmp      dword ptr [rcx+r8+0x2C], 15
       je       G_M000_IG77
 
G_M000_IG64:                ;; offset=0x0981
       mov      rcx, gword ptr [r14+0x08]
       mov      rbx, gword ptr [rcx+0x98]
       mov      r15d, dword ptr [r14+0x38]
       mov      edx, r15d
       cmp      edx, dword ptr [rbx+0x08]
       jae      G_M000_IG92
       shl      rdx, 5
       lea      rsi, bword ptr [rbx+rdx+0x10]
       inc      r15d
       cmp      byte  ptr [rbp-0x50], 0
       je       G_M000_IG72
       cmp      dword ptr [rsi+0x18], 0
       jl       G_M000_IG72
       cmp      r15d, dword ptr [rcx+0xEC]
       jge      G_M000_IG72
       mov      rdx, bword ptr [r14+0x48]
       mov      r8d, dword ptr [r14+0x50]
       mov      bword ptr [rbp-0x108], rdx
       mov      dword ptr [rbp-0x100], r8d
 
G_M000_IG65:                ;; offset=0x09DF
       vmovdqu  xmm0, xmmword ptr [rbp-0x48]
       vmovdqu  xmmword ptr [rbp-0xF8], xmm0
 
G_M000_IG66:                ;; offset=0x09EC
       mov      rdx, gword ptr [r14+0x10]
       mov      rdx, gword ptr [rdx+0xA0]
       mov      gword ptr [rsp+0x28], rdx
       lea      rdx, [rbp-0xD8]
       mov      qword ptr [rsp+0x30], rdx
       lea      rdx, [rbp-0x108]
       lea      r8, [rbp-0xF8]
       mov      qword ptr [rsp+0x20], r8
       mov      r8, rsi
       mov      r9d, r15d
       call     [Lokad.Lython.Runtime.LythonRuntime:TryCombineCallAugmentation(Lokad.Lython.Frontend.ExecutableCodeObject,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,int,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot,Lokad.Lython.Runtime.ExecutionState,byref):bool]
       test     eax, eax
       je       G_M000_IG72
       mov      r8, gword ptr [r14+0x08]
       mov      rdx, gword ptr [r8+0x98]
       mov      rcx, rdx
       cmp      r15d, dword ptr [rcx+0x08]
       jae      G_M000_IG92
       mov      eax, r15d
       shl      rax, 5
       lea      rax, bword ptr [rcx+rax+0x10]
       mov      ecx, dword ptr [r8+0xDC]
       mov      r10d, dword ptr [rax+0x1C]
       cmp      r10d, 51
       ja       SHORT G_M000_IG70
 
G_M000_IG67:                ;; offset=0x0A64
       mov      r9, 0x7FFFFFFFFF9FF
       bt       r9, r10
       jb       SHORT G_M000_IG70
 
G_M000_IG68:                ;; offset=0x0A74
       mov      r10d, dword ptr [rax+0x18]
       test     r10d, r10d
       jge      SHORT G_M000_IG69
       not      r10d
 
G_M000_IG69:                ;; offset=0x0A80
       jmp      SHORT G_M000_IG71
 
G_M000_IG70:                ;; offset=0x0A82
       mov      r10d, dword ptr [rax+0x14]
 
G_M000_IG71:                ;; offset=0x0A86
       cmp      ecx, r10d
       jge      SHORT G_M000_IG72
       mov      r10d, dword ptr [rax+0x18]
       test     r10d, r10d
       jge      SHORT G_M000_IG74
       lea      ecx, [r15+0x01]
       cmp      ecx, dword ptr [r8+0xEC]
       jge      SHORT G_M000_IG72
       cmp      ecx, dword ptr [rdx+0x08]
       jae      G_M000_IG92
       mov      r8d, ecx
       shl      r8, 5
       lea      r8, bword ptr [rdx+r8+0x10]
       mov      edx, dword ptr [r8+0x0C]
       mov      r8d, dword ptr [r8+0x1C]
       cmp      r8d, 25
       jne      SHORT G_M000_IG72
       cmp      edx, 0x7FFFFFFF
       je       SHORT G_M000_IG74
 
G_M000_IG72:                ;; offset=0x0ACC
       vmovdqu  xmm0, xmmword ptr [rbp-0x48]
       vmovdqu  xmmword ptr [rbp-0xF8], xmm0
 
G_M000_IG73:                ;; offset=0x0AD9
       lea      r8, [rbp-0xF8]
       mov      rdx, rsi
       mov      rcx, r14
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot):this]
       jmp      G_M000_IG80
 
G_M000_IG74:                ;; offset=0x0AF1
       mov      dword ptr [r14+0x38], r15d
 
G_M000_IG75:                ;; offset=0x0AF5
       vmovdqu  xmm0, xmmword ptr [rbp-0xD8]
       vmovdqu  xmmword ptr [rbp-0xF8], xmm0
 
G_M000_IG76:                ;; offset=0x0B05
       lea      r8, [rbp-0xF8]
       mov      rdx, rax
       mov      rcx, r14
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot):this]
       jmp      G_M000_IG80
 
G_M000_IG77:                ;; offset=0x0B1D
       mov      rcx, gword ptr [r14+0x10]
       mov      rax, rbx
       mov      r8d, r15d
       cmp      r8d, dword ptr [rax+0x08]
       jae      G_M000_IG92
       shl      r8, 5
       mov      rbx, gword ptr [rax+r8+0x10]
       mov      r15, gword ptr [rcx+0xA0]
       cmp      byte  ptr [r15], r15b
       mov      rcx, r15
       call     [Lokad.Lython.Runtime.ExecutionState:get_CanContinue():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG78
       mov      rcx, r15
       mov      rdx, rbx
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
 
G_M000_IG78:                ;; offset=0x0B5D
       mov      rdx, gword ptr [rbp-0x110]
       mov      ecx, esi
       add      ecx, dword ptr [rdx+0x2C]
       mov      edx, ecx
       mov      rcx, r14
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Trim(int):this]
       mov      rcx, rdi
       mov      rdx, gword ptr [rbp-0x110]
       mov      edx, dword ptr [rdx+0x2C]
       mov      eax, esi
       mov      r8d, edx
       add      rax, r8
       mov      r8d, dword ptr [rcx+0x08]
       cmp      rax, r8
       ja       G_M000_IG91
       mov      r14d, esi
       shl      r14, 4
       add      r14, bword ptr [rcx]
       cmp      edx, 1
       jle      SHORT G_M000_IG80
       mov      ecx, edx
       shl      rcx, 4
       lea      rbx, bword ptr [r14+rcx-0x10]
 
G_M000_IG79:                ;; offset=0x0BB0
       mov      rsi, gword ptr [r14]
       mov      rdi, qword ptr [r14+0x08]
       mov      r15, rbx
       mov      r13, r14
       mov      rdx, gword ptr [r15]
       mov      rcx, r13
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rcx, qword ptr [r15+0x08]
       mov      qword ptr [r13+0x08], rcx
       mov      rcx, rbx
       mov      rdx, rsi
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      qword ptr [rbx+0x08], rdi
       add      r14, 16
       add      rbx, -16
       cmp      r14, rbx
       jb       SHORT G_M000_IG79
 
G_M000_IG80:                ;; offset=0x0BEC
       mov      eax, 1
 
G_M000_IG81:                ;; offset=0x0BF1
       vzeroupper 
       add      rsp, 296
       pop      rbx
       pop      rsi
       pop      rdi
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG82:                ;; offset=0x0C08
       mov      eax, r15d
 
G_M000_IG83:                ;; offset=0x0C0B
       vzeroupper 
       add      rsp, 296
       pop      rbx
       pop      rsi
       pop      rdi
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG84:                ;; offset=0x0C22
       mov      gword ptr [rsp+0x20], r12
       mov      rsi, gword ptr [rbp-0x118]
       mov      gword ptr [rsp+0x28], rsi
       lea      rcx, [rbp-0x80]
       mov      r8, r13
       mov      r9, rax
       mov      rdx, 0x7FF9B54F6A90
       call     [Lokad.Lython.Runtime.LythonRuntime:InvokeSingleInput[System.__Canon](System.__Canon,System.Func`4[System.__Canon,System.__Canon,System.__Canon,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]
       mov      rdx, gword ptr [rbp-0x80]
       mov      rcx, 0x7FF9B51DC748
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       mov      rsi, rax
       test     rsi, rsi
       jne      SHORT G_M000_IG85
       lea      r8, [rbp-0x80]
       mov      rcx, r14
       mov      rdx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot):this]
       jmp      G_M000_IG80
 
G_M000_IG85:                ;; offset=0x0C7D
       mov      rcx, gword ptr [r14+0x08]
       mov      rcx, gword ptr [rcx+0xA0]
       mov      r11, 0x7FF9B4B636F0
       call     [r11]System.Collections.Generic.IReadOnlyCollection`1[System.__Canon]:get_Count():int:this
       test     eax, eax
       je       SHORT G_M000_IG90
       mov      gword ptr [r14+0x28], rsi
       xor      eax, eax
 
G_M000_IG86:                ;; offset=0x0C9F
       vzeroupper 
       add      rsp, 296
       pop      rbx
       pop      rsi
       pop      rdi
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG87:                ;; offset=0x0CB6
       vmovdqu  xmm0, xmmword ptr [rbp-0x70]
       vmovdqu  xmmword ptr [rbp-0xF8], xmm0
 
G_M000_IG88:                ;; offset=0x0CC3
       lea      r8, [rbp-0xF8]
       mov      rdx, rbx
       mov      rcx, r14
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot):this]
       jmp      G_M000_IG80
 
G_M000_IG89:                ;; offset=0x0CDB
       mov      rcx, rbx
       mov      rdx, 0x19F4A0791D0
       call     [Lokad.Lython.Frontend.ExecutableInstruction:InvalidOperand(System.String):System.InvalidOperationException:this]
       mov      rcx, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG90:                ;; offset=0x0CF7
       mov      rcx, rsi
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG91:                ;; offset=0x0D00
       call     [System.ThrowHelper:ThrowArgumentOutOfRangeException()]
       int3     
 
G_M000_IG92:                ;; offset=0x0D07
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG93:                ;; offset=0x0D0D
       sub      rsp, 72
 
G_M000_IG94:                ;; offset=0x0D11
       mov      r14, bword ptr [rbp+0x10]
       mov      rsi, gword ptr [r14+0x10]
       mov      rcx, gword ptr [rsi+0xA0]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.ExecutionState:LeaveInterpreterFrame():this]
       nop      
 
G_M000_IG95:                ;; offset=0x0D29
       vzeroupper 
       add      rsp, 72
       ret      
 
G_M000_IG96:                ;; offset=0x0D31
       sub      rsp, 72
 
G_M000_IG97:                ;; offset=0x0D35
       mov      rdx, rcx
       mov      rcx, 0x7FF9B4C61770
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       mov      r15, rax
       test     r15, r15
       jne      SHORT G_M000_IG98
       xor      eax, eax
       jmp      SHORT G_M000_IG99
 
G_M000_IG98:                ;; offset=0x0D53
       mov      rcx, gword ptr [rbp-0x110]
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_CallSpan():Lokad.Lython.LythonSourceSpan:this]
       mov      rdx, rax
       lea      r8, [rbp-0xC8]
       mov      rcx, r15
       call     [Lokad.Lython.Runtime.LythonRuntime:TryTranslateCallableException(System.Exception,Lokad.Lython.LythonSourceSpan,byref):bool]
       test     eax, eax
       setne    al
       movzx    rax, al
 
G_M000_IG99:                ;; offset=0x0D7B
       vzeroupper 
       add      rsp, 72
       ret      
 
G_M000_IG100:                ;; offset=0x0D83
       sub      rsp, 72
 
G_M000_IG101:                ;; offset=0x0D87
       mov      rcx, gword ptr [rbp-0xC8]
       call     CORINFO_HELP_THROW
       int3     
 
; Total bytes of code 3476

; Assembly listing for method Lokad.Lython.Runtime.LythonRuntime+NativeExecution:CallFunction(Lokad.Lython.Frontend.ExecutableCallSite,int,System.Object,byref,byref):bool:this (FullOpts)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; FullOpts code
; optimized code
; rbp based frame
; fully interruptible
; No PGO data
; 0 inlinees with PGO data; 39 single block inlinees; 2 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       push     r15
       push     r14
       push     r13
       push     r12
       push     rdi
       push     rsi
       push     rbx
       sub      rsp, 232
       lea      rbp, [rsp+0x120]
       xor      eax, eax
       mov      qword ptr [rbp-0xA8], rax
       vxorps   xmm4, xmm4, xmm4
       vmovdqu  ymmword ptr [rbp-0xA0], ymm4
       vmovdqu  ymmword ptr [rbp-0x80], ymm4
       vmovdqu  ymmword ptr [rbp-0x60], ymm4
       mov      qword ptr [rbp-0x40], rax
       mov      bword ptr [rbp+0x10], rcx
       mov      rbx, rcx
       mov      rsi, rdx
       mov      edi, r8d
       mov      r14, r9
       mov      r15, bword ptr [rbp+0x30]
       mov      r13, bword ptr [rbp+0x38]
 
G_M000_IG02:                ;; offset=0x0056
       mov      rcx, 0x19F7FC01F50
       mov      rdx, gword ptr [rcx]
       mov      rcx, r15
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       xor      ecx, ecx
       mov      qword ptr [r15+0x08], rcx
       mov      byte  ptr [r13], 0
       mov      rcx, gword ptr [rbx+0x10]
       mov      rcx, gword ptr [rcx+0xA0]
       cmp      qword ptr [rcx+0x158], 8
       jge      G_M000_IG37
       test     r14, r14
       je       SHORT G_M000_IG05
 
G_M000_IG03:                ;; offset=0x0094
       mov      rcx, 0x7FF9B54EA2D8
       cmp      qword ptr [r14], rcx
       jne      SHORT G_M000_IG05
 
G_M000_IG04:                ;; offset=0x00A3
       mov      r12, r14
       jmp      SHORT G_M000_IG06
 
G_M000_IG05:                ;; offset=0x00A8
       xor      r12, r12
 
G_M000_IG06:                ;; offset=0x00AB
       cmp      byte  ptr [rsi+0x30], 0
       je       SHORT G_M000_IG08
       lea      rcx, bword ptr [rbx+0x48]
       cmp      edi, dword ptr [rcx+0x08]
       jae      G_M000_IG39
       mov      eax, edi
       shl      rax, 4
       mov      qword ptr [rbp-0xB0], rax
       mov      rdx, rax
       add      rdx, bword ptr [rcx]
       mov      rcx, rdx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Object():System.Object:this]
       test     rax, rax
       je       SHORT G_M000_IG09
 
G_M000_IG07:                ;; offset=0x00DF
       mov      rcx, 0x7FF9B545F1F8
       cmp      qword ptr [rax], rcx
       jne      SHORT G_M000_IG09
 
G_M000_IG08:                ;; offset=0x00EE
       xor      rax, rax
       jmp      SHORT G_M000_IG10
 
G_M000_IG09:                ;; offset=0x00F2
       lea      rcx, bword ptr [rbx+0x48]
       cmp      edi, dword ptr [rcx+0x08]
       jae      G_M000_IG39
       mov      rax, qword ptr [rbp-0xB0]
       add      rax, bword ptr [rcx]
       mov      rcx, rax
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Object():System.Object:this]
 
G_M000_IG10:                ;; offset=0x0112
       test     r14, r14
       je       SHORT G_M000_IG15
 
G_M000_IG11:                ;; offset=0x0117
       mov      r9, 0x7FF9B5543E78
       cmp      qword ptr [r14], r9
       jne      SHORT G_M000_IG15
 
G_M000_IG12:                ;; offset=0x0126
       mov      r9, gword ptr [r14+0x10]
       test     r9, r9
       je       SHORT G_M000_IG15
 
G_M000_IG13:                ;; offset=0x012F
       mov      rcx, 0x7FF9B54EA2D8
       cmp      qword ptr [r9], rcx
       jne      SHORT G_M000_IG15
 
G_M000_IG14:                ;; offset=0x013E
       mov      r12, r9
       mov      rax, gword ptr [r14+0x08]
 
G_M000_IG15:                ;; offset=0x0145
       test     r12, r12
       je       G_M000_IG37
       lea      r9, [rbp-0x40]
       mov      rcx, r12
       mov      rdx, rsi
       mov      gword ptr [rbp-0xB8], rax
       mov      r8, rax
       call     [Lokad.Lython.Runtime.PyExecutableFunction:TrySelectNativeCall(Lokad.Lython.Frontend.ExecutableCallSite,System.Object,byref):bool:this]
       test     eax, eax
       je       G_M000_IG37
       mov      rcx, gword ptr [rbx+0x10]
       mov      rdx, gword ptr [rsi+0x18]
       mov      rcx, gword ptr [rcx+0xA0]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.ExecutionState:EnterInterpreterFrame(Lokad.Lython.LythonSourceSpan):this]
       mov      dword ptr [rbp-0x44], 1
 
G_M000_IG16:                ;; offset=0x018E
       lea      rdx, bword ptr [rbx+0x48]
       cmp      byte  ptr [rsi+0x30], 0
       setne    cl
       movzx    rcx, cl
       lea      ecx, [rdi+rcx+0x01]
       mov      r14d, dword ptr [rsi+0x28]
       mov      r8d, ecx
       mov      r9d, r14d
       add      r8, r9
       mov      r9d, dword ptr [rdx+0x08]
       cmp      r8, r9
       ja       G_M000_IG31
       mov      eax, ecx
       shl      rax, 4
       add      rax, bword ptr [rdx]
       mov      bword ptr [rbp-0xC0], rax
       cmp      byte  ptr [rbp-0x40], 0
       je       G_M000_IG21
       mov      r8, gword ptr [rsi+0x18]
       xor      edx, edx
       mov      qword ptr [r15], rdx
       mov      qword ptr [r15+0x08], rdx
       mov      rdx, gword ptr [r12+0x40]
       cmp      byte  ptr [rdx+0xF6], 0
       je       G_M000_IG21
       mov      r10, gword ptr [rbp-0xB8]
       test     r10, r10
       setne    cl
       movzx    rcx, cl
       add      ecx, r14d
       cmp      ecx, dword ptr [rdx+0xD8]
       je       SHORT G_M000_IG18
 
G_M000_IG17:                ;; offset=0x020E
       mov      gword ptr [rbp-0xB8], r10
       jmp      SHORT G_M000_IG21
 
G_M000_IG18:                ;; offset=0x0217
       mov      gword ptr [rbp-0xB8], r10
       test     r10, r10
       jne      SHORT G_M000_IG19
       mov      bword ptr [rbp-0x88], rax
       mov      dword ptr [rbp-0x80], r14d
       lea      rdx, [rbp-0x88]
       mov      rcx, r12
       mov      r9, r15
       call     [Lokad.Lython.Runtime.PyExecutableFunction:TryStartDirectIntegerReturn[Lokad.Lython.Runtime.LythonRuntime+SlotIntegerOperands](Lokad.Lython.Runtime.LythonRuntime+SlotIntegerOperands,Lokad.Lython.LythonSourceSpan,byref):bool:this]
       jmp      SHORT G_M000_IG20
 
G_M000_IG19:                ;; offset=0x0243
       mov      r10, gword ptr [rbp-0xB8]
       mov      gword ptr [rbp-0x78], r10
       mov      bword ptr [rbp-0x70], rax
       mov      dword ptr [rbp-0x68], r14d
       lea      rdx, [rbp-0x78]
       mov      rcx, r12
       mov      r9, r15
       call     [Lokad.Lython.Runtime.PyExecutableFunction:TryStartDirectIntegerReturn[Lokad.Lython.Runtime.LythonRuntime+BoundIntegerOperands](Lokad.Lython.Runtime.LythonRuntime+BoundIntegerOperands,Lokad.Lython.LythonSourceSpan,byref):bool:this]
 
G_M000_IG20:                ;; offset=0x0266
       test     eax, eax
       mov      rax, bword ptr [rbp-0xC0]
       jne      G_M000_IG30
 
G_M000_IG21:                ;; offset=0x0275
       cmp      byte  ptr [rsi+0x31], 0
       je       SHORT G_M000_IG22
       mov      r13d, 1
       jmp      SHORT G_M000_IG24
 
G_M000_IG22:                ;; offset=0x0283
       cmp      byte  ptr [rbx+0x40], 0
       jne      SHORT G_M000_IG23
       xor      r13d, r13d
       jmp      SHORT G_M000_IG24
 
G_M000_IG23:                ;; offset=0x028E
       movzx    r13, byte  ptr [rsi+0x32]
 
G_M000_IG24:                ;; offset=0x0293
       cmp      dword ptr [rsi+0x2C], 0
       je       SHORT G_M000_IG25
       mov      r8, gword ptr [rbx+0x08]
       cmp      dword ptr [r8+0xDC], edi
       jl       G_M000_IG27
 
G_M000_IG25:                ;; offset=0x02AA
       mov      r8, gword ptr [rbx+0x10]
       mov      rcx, gword ptr [rsi+0x18]
       movzx    r9, byte  ptr [rbp-0x40]
       mov      bword ptr [rbp-0x98], rax
       mov      dword ptr [rbp-0x90], r14d
       mov      gword ptr [rsp+0x20], r8
       mov      gword ptr [rsp+0x28], rcx
       mov      dword ptr [rsp+0x30], r13d
       mov      dword ptr [rsp+0x38], r9d
       xor      r8, r8
       mov      bword ptr [rbp-0xA8], r8
 
G_M000_IG26:                ;; offset=0x02E3
       mov      dword ptr [rbp-0xA0], r8d
       lea      r8, [rbp-0x60]
       mov      qword ptr [rsp+0x48], r8
       mov      bword ptr [rsp+0x50], r15
       lea      r8, [rbp-0x50]
       mov      qword ptr [rsp+0x58], r8
       lea      r8, [rbp-0x98]
       lea      rcx, [rbp-0xA8]
       mov      qword ptr [rsp+0x40], rcx
       mov      rcx, r12
       mov      r9, gword ptr [rbp-0xB8]
       mov      rdx, rsi
       call     [Lokad.Lython.Runtime.PyExecutableFunction:StartNativeCall(Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,bool,bool,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,byref,byref):this]
       jmp      SHORT G_M000_IG28
 
G_M000_IG27:                ;; offset=0x0329
       mov      bword ptr [rbp-0x98], rax
       mov      dword ptr [rbp-0x90], r14d
       mov      r14, gword ptr [rbp-0xB8]
       mov      gword ptr [rsp+0x20], r14
       mov      dword ptr [rsp+0x28], edi
       mov      dword ptr [rsp+0x30], r13d
       movzx    r9, byte  ptr [rbp-0x40]
       mov      dword ptr [rsp+0x38], r9d
       mov      bword ptr [rsp+0x40], r15
       lea      r9, [rbp-0x50]
       mov      qword ptr [rsp+0x48], r9
       lea      r9, [rbp-0x98]
       mov      rdx, r12
       mov      r8, rsi
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:StartNativeFixedReturn(Lokad.Lython.Runtime.PyExecutableFunction,Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.Object,int,bool,bool,byref,byref):this]
 
G_M000_IG28:                ;; offset=0x037A
       cmp      gword ptr [rbp-0x50], 0
       je       SHORT G_M000_IG32
       mov      rax, gword ptr [rbp-0x50]
       mov      gword ptr [rbx+0x18], rax
       mov      rax, gword ptr [r12+0x28]
       mov      rax, gword ptr [rax+0xA0]
       mov      rax, gword ptr [rax+0x88]
       mov      gword ptr [rbx+0x20], rax
       xor      eax, eax
       mov      dword ptr [rbp-0x44], eax
 
G_M000_IG29:                ;; offset=0x03A5
       mov      dword ptr [rbp-0x54], eax
       jmp      SHORT G_M000_IG34
 
G_M000_IG30:                ;; offset=0x03AA
       mov      byte  ptr [r13], 1
       mov      dword ptr [rbp-0x54], 1
       jmp      SHORT G_M000_IG34
 
G_M000_IG31:                ;; offset=0x03B8
       call     [System.ThrowHelper:ThrowArgumentOutOfRangeException()]
       int3     
 
G_M000_IG32:                ;; offset=0x03BF
       mov      rsi, gword ptr [rbx+0x10]
       mov      rcx, gword ptr [rsi+0xA0]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.ExecutionState:LeaveInterpreterFrame():this]
       mov      eax, 1
 
G_M000_IG33:                ;; offset=0x03D7
       add      rsp, 232
       pop      rbx
       pop      rsi
       pop      rdi
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG34:                ;; offset=0x03EB
       call     G_M000_IG40
       nop      
 
G_M000_IG35:                ;; offset=0x03F1
       mov      eax, dword ptr [rbp-0x54]
 
G_M000_IG36:                ;; offset=0x03F4
       add      rsp, 232
       pop      rbx
       pop      rsi
       pop      rdi
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG37:                ;; offset=0x0408
       xor      eax, eax
 
G_M000_IG38:                ;; offset=0x040A
       add      rsp, 232
       pop      rbx
       pop      rsi
       pop      rdi
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG39:                ;; offset=0x041E
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG40:                ;; offset=0x0424
       sub      rsp, 104
 
G_M000_IG41:                ;; offset=0x0428
       cmp      dword ptr [rbp-0x44], 0
       je       SHORT G_M000_IG42
       mov      rbx, bword ptr [rbp+0x10]
       mov      rsi, gword ptr [rbx+0x10]
       mov      rcx, gword ptr [rsi+0xA0]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.ExecutionState:LeaveInterpreterFrame():this]
 
G_M000_IG42:                ;; offset=0x0445
       nop      
 
G_M000_IG43:                ;; offset=0x0446
       add      rsp, 104
       ret      
 
; Total bytes of code 1099

