def run(value):
    def read():
        return value
    def advance():
        nonlocal value
        value += 2
        return 14
    original = read()
    first = value + 1
    during = value + advance()
    after = value + 1
    if value:
        print(first, during, after, original is read(), read() is read())
run(1000)
