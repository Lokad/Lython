from pathlib import Path
import hashlib
import json
import subprocess
import tarfile

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
blocks = "reuse-compiler-block-storage-20261122"
branches = "branch-assignment-snapshots-20261122"
target = repo/"benchmarks/results/2026-11-22-compiler-storage-snapshots"
target.mkdir(exist_ok=True)

def read(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))

identity = {}
with tarfile.open(target/"observations.tar.xz", "w:xz") as archive:
    for experiment, name, revision in (("blockLists",blocks,"eb7536c34"),("branchSets",branches,"bc5383f3b")):
        folder = lab.parent / name
        work = repo/".git/agent-worktrees"/name
        assert subprocess.check_output(["git","-C",work,"rev-parse","--short=9","HEAD"], text=True).strip()==revision
        patch = subprocess.check_output(["git","-C",work,"diff","d45f2ed21","HEAD","--","src"])
        (folder/"source.patch").write_bytes(patch)
        summary = read(folder/"compile-allocation-summary.json")
        image_proof = read(folder/"inspection-identity.json")
        assert summary["roles"]==["reference","candidate","candidate","reference"]
        assert len(summary["rows"])==12
        reference = read(folder/"reference-inspection.json")
        candidate = read(folder/"candidate-inspection.json")
        assert all(report["coreSHA256"] == image_proof["workerImages"][role]["inspect"]["Lokad.Lython.dll"]
            for role,report in (("reference",reference),("candidate",candidate)))
        assert reference["rows"] == candidate["rows"] and len(reference["rows"])==12
        logs = sorted(path.name for path in folder.glob("*.log"))
        selected = ["source.patch","prepare-inspection.py","compile-allocation.py",
            "inspect-catalog.json","inspection-identity.json","reference-inspection.json","candidate-inspection.json",
            "compile-allocation-summary.json", *[f"{role}-compile-alloc-{i}.json" for i,role in enumerate(summary["roles"])], *logs]
        for leaf in selected:
            archive.add(folder/leaf,arcname=f"{experiment}/{leaf}")
        identity[experiment]=dict(revision=revision, sourcePatchSHA256=hashlib.sha256(patch).hexdigest(),
            fixtureSHA256=image_proof["fixtureSHA256"], images=image_proof["workerImages"],
            allocationCounts=[dict(case=row["id"],bytes=row["allocatedBytes"]) for row in summary["rows"]])
    archive.add(lab/"archive-results.py",arcname="archive-results.py")
with tarfile.open(target/"observations.tar.xz") as archive:
    assert "blockLists/public-initial-windows.log" in archive.getnames()
    assert "branchSets/compile-allocation-summary.json" in archive.getnames()
identity["archiveSHA256"]=hashlib.sha256((target/"observations.tar.xz").read_bytes()).hexdigest()
(target/"summary.json").write_text(json.dumps(identity,indent=2)+"\n",encoding="utf-8",newline="\n")
