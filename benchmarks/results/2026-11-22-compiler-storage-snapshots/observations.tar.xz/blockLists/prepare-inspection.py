from pathlib import Path
import hashlib
import json
import os
import shutil
import subprocess

lab = Path(__file__).resolve().parent
repository = lab.parents[3]
donor = lab.parent / "demanded-jump-targets-20261122"
frozen = lab.parent / "record-and-text-profile-20261122/comparison/frozen-candidate"
candidate = lab / "frozen-build/bin/Lokad.Lython/release_net11.0/Lokad.Lython.dll"
sdk = Path.home() / ".dotnet11"
dotnet = sdk / "dotnet.exe"
env = dict(os.environ, DOTNET_ROOT=str(sdk), DOTNET_ROOT_X64=str(sdk), PATH=str(sdk) + os.pathsep + os.environ["PATH"])

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def read(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))

expected = read(repository / "benchmarks/results/2026-11-22-unicode-decimal-normalization/source.json")["imageFiles"]["candidate"]
assert len(expected) == 32 and {name: sha(frozen / name) for name in expected} == expected
donor_identity = read(donor / "inspection-identity.json")
catalog = lab / "inspect-catalog.json"
shutil.copyfile(donor / catalog.name, catalog)
assert sha(catalog) == donor_identity["fixtureSHA256"]

image_hashes = {}
for role, core in (("reference", frozen / "Lokad.Lython.dll"), ("candidate", candidate)):
    image_hashes[role] = {}
    for tool in ("inspect", "compile"):
        original = donor / "reference" / tool
        hashes = {p.name: sha(p) for p in original.iterdir() if p.is_file()}
        assert hashes == donor_identity["workerImages"]["reference"][tool]
        copied = lab / role / tool
        shutil.copytree(original, copied)
        shutil.copyfile(core, copied / core.name)
        hashes[core.name] = sha(core)
        assert hashes == {p.name: sha(p) for p in copied.iterdir() if p.is_file()}
        image_hashes[role][tool] = hashes
    report = lab / f"{role}-inspection.json"
    subprocess.run([dotnet, lab / role / "inspect/Inspect.dll", catalog, report], env=env, check=True, timeout=50)
    assert read(report)["coreSHA256"] == sha(core)

reference = read(lab / "reference-inspection.json")["rows"]
candidate_rows = read(lab / "candidate-inspection.json")["rows"]
assert reference == candidate_rows
print(f"{len(reference)} fixtures have identical instructions, layout and locations", flush=True)
identity = {
    "reference": "d45f2ed21",
    "candidate": "eb7536c34",
    "fixtureSHA256": sha(catalog),
    "workerImages": image_hashes,
    "runnerNote": "Original runner source labels are historical. imageSHA256 and catalogSHA256 identify the exact measured images and inputs."
}
(lab / "inspection-identity.json").write_text(json.dumps(identity, indent=2)+"\n", encoding="utf-8", newline="\n")
shutil.copyfile(donor / "compile-allocation.py", lab / "compile-allocation.py")
subprocess.run([os.sys.executable, lab / "compile-allocation.py"], check=True, timeout=100)
