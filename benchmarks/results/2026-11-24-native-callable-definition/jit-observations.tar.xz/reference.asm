; Assembly listing for method Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecutePreparedOperation(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,bool,byref):bool (FullOpts)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; FullOpts code
; optimized code
; rbp based frame
; fully interruptible
; No PGO data
; 0 inlinees with PGO data; 179 single block inlinees; 58 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       push     r15
       push     r14
       push     r13
       push     r12
       push     rdi
       push     rsi
       push     rbx
       sub      rsp, 520
       lea      rbp, [rsp+0x240]
       vxorps   xmm4, xmm4, xmm4
       vmovdqa  xmmword ptr [rbp-0x180], xmm4
       vmovdqa  xmmword ptr [rbp-0x170], xmm4
       mov      rax, -288
 
G_M000_IG186:                ;; offset=0x0039
       vmovdqa  xmmword ptr [rbp+rax-0x40], xmm4
       vmovdqa  xmmword ptr [rbp+rax-0x30], xmm4
       vmovdqa  xmmword ptr [rbp+rax-0x20], xmm4
       add      rax, 48
       jne      SHORT G_M000_IG186
       mov      bword ptr [rbp+0x10], rcx
       mov      bword ptr [rbp+0x28], r9
       mov      rdi, rdx
       mov      rsi, r8
       mov      rbx, r9
       mov      r15d, dword ptr [rbp+0x30]
       mov      r14, bword ptr [rbp+0x38]
 
G_M000_IG02:                ;; offset=0x006A
       xor      eax, eax
       mov      qword ptr [r14], rax
       mov      qword ptr [r14+0x08], rax
       mov      r13, rsi
       test     r13, r13
       cmove    r13, rdi
       mov      rax, gword ptr [rcx]
       mov      r12, gword ptr [rax+0x30]
       mov      rcx, rbx
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ConstantIndex():int:this]
       cmp      eax, dword ptr [r12+0x08]
       jae      G_M000_IG174
       mov      edx, eax
       mov      rdx, gword ptr [r12+8*rdx+0x10]
       mov      rcx, 0x7FFA02730290
       call     CORINFO_HELP_CHKCASTCLASS
       mov      r12, rax
       mov      rax, gword ptr [rbx]
       mov      gword ptr [rbp-0x188], rax
       test     r12, r12
       je       G_M000_IG51
 
G_M000_IG03:                ;; offset=0x00C4
       mov      rdx, qword ptr [r12]
       mov      rcx, 0x7FFA02773FC0
       cmp      rdx, rcx
       jne      G_M000_IG51
 
G_M000_IG04:                ;; offset=0x00DB
       test     rsi, rsi
       je       G_M000_IG167
       mov      rcx, bword ptr [rbp+0x10]
       lea      r15, bword ptr [rcx+0x20]
       mov      r14, r15
       mov      edi, dword ptr [rbx+0x10]
       mov      ecx, dword ptr [rbx+0x1C]
       cmp      ecx, 51
       ja       SHORT G_M000_IG09
 
G_M000_IG05:                ;; offset=0x00FA
       mov      rdx, 0x7FFFFFFFFF9FF
       bt       rdx, rcx
       jb       SHORT G_M000_IG09
 
G_M000_IG06:                ;; offset=0x010A
       mov      edx, dword ptr [rbx+0x18]
       test     edx, edx
       jge      SHORT G_M000_IG07
       mov      r8d, edx
       not      r8d
       jmp      SHORT G_M000_IG08
 
G_M000_IG07:                ;; offset=0x0119
       mov      r8d, edx
 
G_M000_IG08:                ;; offset=0x011C
       mov      edx, r8d
       mov      dword ptr [rbp-0xCC], edx
       jmp      SHORT G_M000_IG10
 
G_M000_IG09:                ;; offset=0x0127
       mov      edx, dword ptr [rbx+0x14]
       mov      dword ptr [rbp-0xCC], edx
 
G_M000_IG10:                ;; offset=0x0130
       mov      rcx, gword ptr [r14]
       cmp      edi, dword ptr [rcx+0x08]
       jae      G_M000_IG174
       mov      r8d, edi
       shl      r8, 4
       lea      rcx, bword ptr [rcx+r8+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Object():System.Object:this]
       mov      rdx, rax
       mov      rcx, 0x7FFA028377A8
       call     [Lokad.Lython.Internal.NullabilityExtensions:RequireNotNull[System.__Canon](System.__Canon):System.__Canon]
       mov      gword ptr [rbp-0x1B0], rax
       mov      rcx, gword ptr [r14]
       cmp      edi, dword ptr [rcx+0x08]
       jae      G_M000_IG174
       mov      edx, edi
       shl      rdx, 4
       lea      rcx, bword ptr [rcx+rdx+0x10]
       xor      rdx, rdx
       mov      gword ptr [rcx], rdx
 
G_M000_IG11:                ;; offset=0x0184
       mov      qword ptr [rcx+0x08], rdx
       mov      edi, dword ptr [rbp-0xCC]
       mov      dword ptr [r14+0x40], edi
       mov      rdi, gword ptr [r12+0x08]
       mov      rcx, 0x7FFA028367F8
       call     CORINFO_HELP_NEWSFAST
       mov      r14, rax
       mov      rcx, r14
       mov      rdx, rsi
       mov      r8, rdi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext+InlinedComprehensionScope:.ctor(Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Frontend.ScopeDirectiveFacts):this]
       mov      gword ptr [rbp-0x190], r14
       xor      ecx, ecx
       mov      dword ptr [rbp-0x40], ecx
 
G_M000_IG12:                ;; offset=0x01C4
       mov      edi, dword ptr [r12+0x10]
       cmp      edi, 2
       jne      G_M000_IG13
       mov      rdi, gword ptr [r13+0xA0]
       mov      rcx, 0x7FFA0285D2E0
       call     CORINFO_HELP_NEWSFAST
       mov      r12, rax
       mov      r13, gword ptr [rdi+0x88]
       mov      rcx, 0x7FFA02734750
       call     CORINFO_HELP_NEWSFAST
       mov      rsi, rax
       lea      rcx, bword ptr [rsi+0x10]
       mov      rdx, r13
       call     CORINFO_HELP_ASSIGN_REF
       lea      rcx, bword ptr [rsi+0x18]
       mov      rdx, gword ptr [rbp-0x188]
       call     CORINFO_HELP_ASSIGN_REF
       mov      byte  ptr [rsi+0x54], 1
       mov      rcx, rsi
       mov      r9, gword ptr [rbp-0x188]
       mov      r8, r13
       xor      edx, edx
       call     [Lokad.Lython.Runtime.PyDict:InitializeNativeStorage(int,Lokad.Lython.Runtime.MemoryGovernor,Lokad.Lython.LythonSourceSpan):this]
       lea      rcx, bword ptr [rsi+0x08]
       mov      rdx, rsi
       call     CORINFO_HELP_ASSIGN_REF
       lea      rcx, bword ptr [r12+0x08]
       mov      rdx, rsi
       call     CORINFO_HELP_ASSIGN_REF
       jmp      G_M000_IG16
 
G_M000_IG13:                ;; offset=0x0257
       cmp      edi, 3
       jne      SHORT G_M000_IG14
       mov      r12, gword ptr [r13+0xA0]
       mov      rcx, 0x7FFA02734750
       call     CORINFO_HELP_NEWSFAST
       mov      r13, rax
       mov      rdi, gword ptr [r12+0x88]
       lea      rcx, bword ptr [r13+0x10]
       mov      rdx, rdi
       call     CORINFO_HELP_ASSIGN_REF
       lea      rcx, bword ptr [r13+0x18]
       mov      rdx, gword ptr [rbp-0x188]
       call     CORINFO_HELP_ASSIGN_REF
       mov      byte  ptr [r13+0x54], 0
       mov      rcx, r13
       mov      r9, gword ptr [rbp-0x188]
       mov      r8, rdi
       xor      edx, edx
       call     [Lokad.Lython.Runtime.PyDict:InitializeNativeStorage(int,Lokad.Lython.Runtime.MemoryGovernor,Lokad.Lython.LythonSourceSpan):this]
       lea      rcx, bword ptr [r13+0x08]
       mov      rdx, r13
       call     CORINFO_HELP_ASSIGN_REF
       mov      r12, r13
       jmp      SHORT G_M000_IG16
 
G_M000_IG14:                ;; offset=0x02C4
       test     byte  ptr [(reloc 0x7ffa0285e470)], 1
       je       G_M000_IG49
 
G_M000_IG15:                ;; offset=0x02D1
       mov      rcx, 0x23782C01D50
       mov      r12, gword ptr [rcx]
       mov      r13, gword ptr [r13+0xA0]
       mov      rcx, 0x7FFA0283DA68
       call     CORINFO_HELP_NEWSFAST
       mov      rsi, rax
       mov      r8, gword ptr [r13+0x88]
       mov      rcx, rsi
       mov      rdx, r12
       mov      r9, gword ptr [rbp-0x188]
       call     [Lokad.Lython.Runtime.PyList:.ctor(System.Collections.Generic.IEnumerable`1[System.Object],Lokad.Lython.Runtime.MemoryGovernor,Lokad.Lython.LythonSourceSpan):this]
       mov      r12, rsi
 
G_M000_IG16:                ;; offset=0x0314
       mov      rsi, r15
       mov      ecx, dword ptr [rbx+0x1C]
       mov      edx, ecx
       cmp      edx, 51
       ja       SHORT G_M000_IG20
 
G_M000_IG17:                ;; offset=0x0321
       mov      rax, 0x7FFFFFFFFF9FF
       bt       rax, rdx
       jb       SHORT G_M000_IG20
 
G_M000_IG18:                ;; offset=0x0331
       mov      edi, dword ptr [rbx+0x18]
       test     edi, edi
       jge      SHORT G_M000_IG19
       not      edi
 
G_M000_IG19:                ;; offset=0x033A
       jmp      SHORT G_M000_IG21
 
G_M000_IG20:                ;; offset=0x033C
       mov      edi, dword ptr [rbx+0x14]
 
G_M000_IG21:                ;; offset=0x033F
       cmp      ecx, 51
       ja       SHORT G_M000_IG26
 
G_M000_IG22:                ;; offset=0x0344
       mov      rdx, 0x7FFFFFFFFF9FF
       bt       rdx, rcx
       jb       SHORT G_M000_IG26
 
G_M000_IG23:                ;; offset=0x0354
       mov      ecx, dword ptr [rbx+0x18]
       test     ecx, ecx
       jge      SHORT G_M000_IG24
       mov      r13d, ecx
       not      r13d
       jmp      SHORT G_M000_IG25
 
G_M000_IG24:                ;; offset=0x0363
       mov      r13d, ecx
 
G_M000_IG25:                ;; offset=0x0366
       jmp      SHORT G_M000_IG27
 
G_M000_IG26:                ;; offset=0x0368
       mov      r13d, dword ptr [rbx+0x14]
 
G_M000_IG27:                ;; offset=0x036C
       inc      r13d
       cmp      r13d, dword ptr [rsi+0x40]
       jge      SHORT G_M000_IG28
       mov      rcx, rsi
       mov      edx, r13d
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
 
G_M000_IG28:                ;; offset=0x0381
       mov      rcx, gword ptr [rsi]
       cmp      edi, dword ptr [rcx+0x08]
       jae      G_M000_IG50
       mov      edx, edi
       shl      rdx, 4
       lea      rdi, bword ptr [rcx+rdx+0x10]
       mov      rcx, rdi
       mov      rdx, r14
       call     CORINFO_HELP_ASSIGN_REF
       xor      ecx, ecx
       mov      qword ptr [rdi+0x08], rcx
       mov      dword ptr [rsi+0x40], r13d
       mov      dword ptr [rbp-0x40], 1
       mov      rsi, r15
       mov      ecx, dword ptr [rbx+0x1C]
       mov      edx, ecx
       cmp      edx, 51
       ja       SHORT G_M000_IG32
 
G_M000_IG29:                ;; offset=0x03C1
       mov      rax, 0x7FFFFFFFFF9FF
       bt       rax, rdx
       jb       SHORT G_M000_IG32
 
G_M000_IG30:                ;; offset=0x03D1
       mov      edi, dword ptr [rbx+0x18]
       test     edi, edi
       jge      SHORT G_M000_IG31
       not      edi
 
G_M000_IG31:                ;; offset=0x03DA
       jmp      SHORT G_M000_IG33
 
G_M000_IG32:                ;; offset=0x03DC
       mov      edi, dword ptr [rbx+0x14]
 
G_M000_IG33:                ;; offset=0x03DF
       inc      edi
       cmp      ecx, 51
       ja       SHORT G_M000_IG38
 
G_M000_IG34:                ;; offset=0x03E6
       mov      rdx, 0x7FFFFFFFFF9FF
       bt       rdx, rcx
       jb       SHORT G_M000_IG38
 
G_M000_IG35:                ;; offset=0x03F6
       mov      ecx, dword ptr [rbx+0x18]
       test     ecx, ecx
       jge      SHORT G_M000_IG36
       mov      r14d, ecx
       not      r14d
       jmp      SHORT G_M000_IG37
 
G_M000_IG36:                ;; offset=0x0405
       mov      r14d, ecx
 
G_M000_IG37:                ;; offset=0x0408
       jmp      SHORT G_M000_IG39
 
G_M000_IG38:                ;; offset=0x040A
       mov      r14d, dword ptr [rbx+0x14]
 
G_M000_IG39:                ;; offset=0x040E
       add      r14d, 2
       cmp      r14d, dword ptr [rsi+0x40]
       jge      SHORT G_M000_IG40
       mov      rcx, rsi
       mov      edx, r14d
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
 
G_M000_IG40:                ;; offset=0x0424
       mov      rcx, gword ptr [rsi]
       cmp      edi, dword ptr [rcx+0x08]
       jae      G_M000_IG50
       mov      edx, edi
       shl      rdx, 4
       lea      rdi, bword ptr [rcx+rdx+0x10]
       mov      rcx, rdi
       mov      rdx, r12
       call     CORINFO_HELP_ASSIGN_REF
       xor      ecx, ecx
       mov      qword ptr [rdi+0x08], rcx
       mov      dword ptr [rsi+0x40], r14d
       mov      ecx, dword ptr [rbx+0x1C]
       cmp      ecx, 51
       ja       SHORT G_M000_IG44
 
G_M000_IG41:                ;; offset=0x0458
       mov      rdx, 0x7FFFFFFFFF9FF
       bt       rdx, rcx
       jb       SHORT G_M000_IG44
 
G_M000_IG42:                ;; offset=0x0468
       mov      esi, dword ptr [rbx+0x18]
       test     esi, esi
       jge      SHORT G_M000_IG43
       not      esi
 
G_M000_IG43:                ;; offset=0x0471
       jmp      SHORT G_M000_IG45
 
G_M000_IG44:                ;; offset=0x0473
       mov      esi, dword ptr [rbx+0x14]
 
G_M000_IG45:                ;; offset=0x0476
       add      esi, 2
       mov      ecx, dword ptr [rbx+0x18]
       test     ecx, ecx
       jge      SHORT G_M000_IG46
       mov      ebx, ecx
       not      ebx
       jmp      SHORT G_M000_IG47
 
G_M000_IG46:                ;; offset=0x0486
       mov      ebx, ecx
 
G_M000_IG47:                ;; offset=0x0488
       cmp      ebx, dword ptr [r15+0x40]
       jge      SHORT G_M000_IG48
       mov      rcx, r15
       mov      edx, ebx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
 
G_M000_IG48:                ;; offset=0x0499
       mov      rcx, gword ptr [r15]
       cmp      esi, dword ptr [rcx+0x08]
       jae      SHORT G_M000_IG50
       mov      edx, esi
       shl      rdx, 4
       lea      rsi, bword ptr [rcx+rdx+0x10]
       mov      rdx, gword ptr [rbp-0x1B0]
       mov      rcx, rsi
       call     CORINFO_HELP_ASSIGN_REF
       xor      ecx, ecx
       mov      qword ptr [rsi+0x08], rcx
       mov      dword ptr [r15+0x40], ebx
       jmp      G_M000_IG164
 
G_M000_IG49:                ;; offset=0x04CA
       mov      rcx, 0x7FFA0285E3D8
       call     CORINFO_HELP_GET_GCSTATIC_BASE
       jmp      G_M000_IG15
 
G_M000_IG50:                ;; offset=0x04DE
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG51:                ;; offset=0x04E4
       test     r12, r12
       je       G_M000_IG72
 
G_M000_IG52:                ;; offset=0x04ED
       mov      rdx, qword ptr [r12]
       mov      r8, 0x7FFA027A6EA0
       cmp      rdx, r8
       jne      G_M000_IG60
 
G_M000_IG53:                ;; offset=0x0504
       test     rsi, rsi
       je       G_M000_IG167
       mov      r8d, dword ptr [rbx+0x10]
       inc      r8d
       mov      edx, r8d
       mov      rcx, bword ptr [rbp+0x10]
       lea      r15, bword ptr [rcx+0x20]
       mov      rcx, r15
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:TakeValue(int,int):System.Object:this]
       mov      r12, rax
       mov      r8d, dword ptr [rbx+0x10]
       mov      edx, r8d
       mov      rcx, r15
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:TakeValue(int,int):System.Object:this]
       mov      rdx, rax
       mov      rcx, 0x7FFA0282C3E8
       call     CORINFO_HELP_CHKCASTCLASS
       mov      rcx, rax
       mov      rax, qword ptr [rax]
       mov      rax, qword ptr [rax+0x40]
       call     [rax+0x20]Lokad.Lython.Runtime.ExecutableTemporaryValue:Dispose():this
       mov      r13d, dword ptr [rbx+0x18]
       test     r13d, r13d
       jge      SHORT G_M000_IG54
       mov      gword ptr [rbp-0x130], r12
       xor      r9d, r9d
       mov      qword ptr [rbp-0x128], r9
       lea      r9, [rbp-0x130]
       mov      rdx, rsi
       mov      r8, rbx
       mov      rcx, bword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CompleteResultConsumer(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot)]
       jmp      G_M000_IG164
 
G_M000_IG54:                ;; offset=0x0590
       mov      rsi, r15
       mov      ecx, dword ptr [rbx+0x1C]
       cmp      ecx, 51
       ja       SHORT G_M000_IG57
 
G_M000_IG55:                ;; offset=0x059B
       mov      rdx, 0x7FFFFFFFFF9FF
       bt       rdx, rcx
       jb       SHORT G_M000_IG57
 
G_M000_IG56:                ;; offset=0x05AB
       mov      r15d, r13d
       jmp      SHORT G_M000_IG58
 
G_M000_IG57:                ;; offset=0x05B0
       mov      r15d, dword ptr [rbx+0x14]
 
G_M000_IG58:                ;; offset=0x05B4
       cmp      r13d, dword ptr [rsi+0x40]
       jge      SHORT G_M000_IG59
       mov      rcx, rsi
       mov      edx, r13d
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
 
G_M000_IG59:                ;; offset=0x05C6
       mov      rcx, gword ptr [rsi]
       cmp      r15d, dword ptr [rcx+0x08]
       jae      G_M000_IG174
       mov      edx, r15d
       shl      rdx, 4
       lea      rbx, bword ptr [rcx+rdx+0x10]
       mov      rcx, rbx
       mov      rdx, r12
       call     CORINFO_HELP_ASSIGN_REF
       xor      ecx, ecx
       mov      qword ptr [rbx+0x08], rcx
       mov      dword ptr [rsi+0x40], r13d
       jmp      G_M000_IG164
 
G_M000_IG60:                ;; offset=0x05F9
       mov      rcx, 0x7FFA027A6B30
       cmp      rdx, rcx
       jne      G_M000_IG72
 
G_M000_IG61:                ;; offset=0x060C
       mov      rcx, r12
       test     rsi, rsi
       je       G_M000_IG167
       mov      edi, dword ptr [rcx+0x08]
       cmp      edi, 2
       jne      G_M000_IG62
       mov      rdi, gword ptr [r13+0xA0]
       mov      rcx, 0x7FFA0285D2E0
       call     CORINFO_HELP_NEWSFAST
       mov      r12, rax
       mov      r13, gword ptr [rdi+0x88]
       mov      rcx, 0x7FFA02734750
       call     CORINFO_HELP_NEWSFAST
       mov      r15, rax
       lea      rcx, bword ptr [r15+0x10]
       mov      rdx, r13
       call     CORINFO_HELP_ASSIGN_REF
       lea      rcx, bword ptr [r15+0x18]
       mov      rdx, gword ptr [rbp-0x188]
       call     CORINFO_HELP_ASSIGN_REF
       mov      byte  ptr [r15+0x54], 1
       mov      rcx, r15
       mov      r9, gword ptr [rbp-0x188]
       mov      r8, r13
       xor      edx, edx
       call     [Lokad.Lython.Runtime.PyDict:InitializeNativeStorage(int,Lokad.Lython.Runtime.MemoryGovernor,Lokad.Lython.LythonSourceSpan):this]
       lea      rcx, bword ptr [r15+0x08]
       mov      rdx, r15
       call     CORINFO_HELP_ASSIGN_REF
       lea      rcx, bword ptr [r12+0x08]
       mov      rdx, r15
       call     CORINFO_HELP_ASSIGN_REF
       jmp      G_M000_IG65
 
G_M000_IG62:                ;; offset=0x06AA
       cmp      edi, 3
       jne      SHORT G_M000_IG63
       mov      r12, gword ptr [r13+0xA0]
       mov      rcx, 0x7FFA02734750
       call     CORINFO_HELP_NEWSFAST
       mov      r13, rax
       mov      r14, gword ptr [r12+0x88]
       lea      rcx, bword ptr [r13+0x10]
       mov      rdx, r14
       call     CORINFO_HELP_ASSIGN_REF
       lea      rcx, bword ptr [r13+0x18]
       mov      rdx, gword ptr [rbp-0x188]
       call     CORINFO_HELP_ASSIGN_REF
       mov      byte  ptr [r13+0x54], 0
       mov      rcx, r13
       mov      r9, gword ptr [rbp-0x188]
       mov      r8, r14
       xor      edx, edx
       call     [Lokad.Lython.Runtime.PyDict:InitializeNativeStorage(int,Lokad.Lython.Runtime.MemoryGovernor,Lokad.Lython.LythonSourceSpan):this]
       lea      rcx, bword ptr [r13+0x08]
       mov      rdx, r13
       call     CORINFO_HELP_ASSIGN_REF
       mov      r12, r13
       jmp      SHORT G_M000_IG65
 
G_M000_IG63:                ;; offset=0x0717
       test     byte  ptr [(reloc 0x7ffa0285e470)], 1
       je       G_M000_IG171
 
G_M000_IG64:                ;; offset=0x0724
       mov      rcx, 0x23782C01D50
       mov      r12, gword ptr [rcx]
       mov      r13, gword ptr [r13+0xA0]
       mov      rcx, 0x7FFA0283DA68
       call     CORINFO_HELP_NEWSFAST
       mov      rdi, rax
       mov      r8, gword ptr [r13+0x88]
       mov      rcx, rdi
       mov      rdx, r12
       mov      r9, gword ptr [rbp-0x188]
       call     [Lokad.Lython.Runtime.PyList:.ctor(System.Collections.Generic.IEnumerable`1[System.Object],Lokad.Lython.Runtime.MemoryGovernor,Lokad.Lython.LythonSourceSpan):this]
       mov      r12, rdi
 
G_M000_IG65:                ;; offset=0x0767
       mov      edi, dword ptr [rbx+0x18]
       test     edi, edi
       jge      SHORT G_M000_IG66
       mov      gword ptr [rbp-0x130], r12
       xor      r9d, r9d
       mov      qword ptr [rbp-0x128], r9
       lea      r9, [rbp-0x130]
       mov      rdx, rsi
       mov      r8, rbx
       mov      rcx, bword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CompleteResultConsumer(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot)]
       jmp      G_M000_IG164
 
G_M000_IG66:                ;; offset=0x079B
       mov      r15, bword ptr [rbp+0x10]
       add      r15, 32
       mov      rsi, r15
       mov      ecx, dword ptr [rbx+0x1C]
       cmp      ecx, 51
       ja       SHORT G_M000_IG69
 
G_M000_IG67:                ;; offset=0x07AE
       mov      rdx, 0x7FFFFFFFFF9FF
       bt       rdx, rcx
       jb       SHORT G_M000_IG69
 
G_M000_IG68:                ;; offset=0x07BE
       mov      r15d, edi
       jmp      SHORT G_M000_IG70
 
G_M000_IG69:                ;; offset=0x07C3
       mov      r15d, dword ptr [rbx+0x14]
 
G_M000_IG70:                ;; offset=0x07C7
       cmp      edi, dword ptr [rsi+0x40]
       jge      SHORT G_M000_IG71
       mov      rcx, rsi
       mov      edx, edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
 
G_M000_IG71:                ;; offset=0x07D7
       mov      rcx, gword ptr [rsi]
       cmp      r15d, dword ptr [rcx+0x08]
       jae      G_M000_IG174
       mov      edx, r15d
       shl      rdx, 4
       lea      rbx, bword ptr [rcx+rdx+0x10]
       mov      rcx, rbx
       mov      rdx, r12
       call     CORINFO_HELP_ASSIGN_REF
       xor      ecx, ecx
       mov      qword ptr [rbx+0x08], rcx
       mov      dword ptr [rsi+0x40], edi
       jmp      G_M000_IG164
 
G_M000_IG72:                ;; offset=0x0809
       test     r12, r12
       je       G_M000_IG96
 
G_M000_IG73:                ;; offset=0x0812
       mov      rdx, qword ptr [r12]
       mov      rcx, 0x7FFA027A7218
       cmp      rdx, rcx
       jne      G_M000_IG92
 
G_M000_IG74:                ;; offset=0x0829
       test     rsi, rsi
       je       G_M000_IG167
       mov      r15, bword ptr [rbp+0x10]
       lea      rcx, bword ptr [r15+0x20]
       mov      rdi, rcx
       mov      rcx, rdi
       mov      edx, dword ptr [rbx+0x10]
       mov      r8d, dword ptr [rbx+0x1C]
       cmp      r8d, 51
       ja       SHORT G_M000_IG78
 
G_M000_IG75:                ;; offset=0x084D
       mov      r10, 0x7FFFFFFFFF9FF
       bt       r10, r8
       jb       SHORT G_M000_IG78
 
G_M000_IG76:                ;; offset=0x085D
       mov      r8d, dword ptr [rbx+0x18]
       test     r8d, r8d
       jge      SHORT G_M000_IG77
       not      r8d
 
G_M000_IG77:                ;; offset=0x0869
       jmp      SHORT G_M000_IG79
 
G_M000_IG78:                ;; offset=0x086B
       mov      r8d, dword ptr [rbx+0x14]
 
G_M000_IG79:                ;; offset=0x086F
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:TakeValue(int,int):System.Object:this]
       mov      r12, rax
       test     r12, r12
       je       SHORT G_M000_IG81
 
G_M000_IG80:                ;; offset=0x087D
       mov      rcx, 0x7FFA0283DA68
       cmp      qword ptr [r12], rcx
       jne      G_M000_IG172
 
G_M000_IG81:                ;; offset=0x0891
       cmp      dword ptr [r12+0x28], 0
       jne      SHORT G_M000_IG83
       test     byte  ptr [(reloc 0x7ffa02798a10)], 1
       je       G_M000_IG173
 
G_M000_IG82:                ;; offset=0x08A6
       mov      rcx, 0x23782C015F0
       mov      r14, gword ptr [rcx]
       jmp      SHORT G_M000_IG85
 
G_M000_IG83:                ;; offset=0x08B5
       mov      r14, gword ptr [r13+0xA0]
       mov      rcx, 0x7FFA02798898
       call     CORINFO_HELP_NEWSFAST
       mov      r13, rax
       mov      r14, gword ptr [r14+0x88]
       lea      rcx, bword ptr [r13+0x10]
       mov      rdx, r14
       call     CORINFO_HELP_ASSIGN_REF
       lea      rcx, bword ptr [r13+0x18]
       mov      rdx, gword ptr [rbp-0x188]
       call     CORINFO_HELP_ASSIGN_REF
       lea      r9, bword ptr [r13+0x20]
       xor      ecx, ecx
       xor      edx, edx
       mov      byte  ptr [rsp+0x20], cl
       mov      dword ptr [rsp+0x24], edx
 
G_M000_IG84:                ;; offset=0x0901
       mov      gword ptr [rsp+0x28], rcx
       mov      rcx, r12
       mov      rdx, r14
       mov      r8, gword ptr [rbp-0x188]
       call     [Lokad.Lython.Runtime.PyTuple:MaterializeGovernedItems(System.Collections.Generic.IEnumerable`1[System.Object],Lokad.Lython.Runtime.MemoryGovernor,Lokad.Lython.LythonSourceSpan,byref,System.Nullable`1[int],Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):System.Object[]]
       mov      rdx, rax
       lea      rcx, bword ptr [r13+0x08]
       call     CORINFO_HELP_ASSIGN_REF
       mov      r14, r13
 
G_M000_IG85:                ;; offset=0x0928
       mov      r13d, dword ptr [rbx+0x18]
       test     r13d, r13d
       jge      SHORT G_M000_IG86
       mov      gword ptr [rbp-0x130], r14
       xor      r9d, r9d
       mov      qword ptr [rbp-0x128], r9
       lea      r9, [rbp-0x130]
       mov      rdx, rsi
       mov      r8, rbx
       mov      rcx, r15
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CompleteResultConsumer(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot)]
       jmp      G_M000_IG164
 
G_M000_IG86:                ;; offset=0x095D
       mov      rsi, rdi
       mov      ecx, dword ptr [rbx+0x1C]
       cmp      ecx, 51
       ja       SHORT G_M000_IG89
 
G_M000_IG87:                ;; offset=0x0968
       mov      rdx, 0x7FFFFFFFFF9FF
       bt       rdx, rcx
       jb       SHORT G_M000_IG89
 
G_M000_IG88:                ;; offset=0x0978
       mov      r15d, r13d
       jmp      SHORT G_M000_IG90
 
G_M000_IG89:                ;; offset=0x097D
       mov      r15d, dword ptr [rbx+0x14]
 
G_M000_IG90:                ;; offset=0x0981
       cmp      r13d, dword ptr [rsi+0x40]
       jge      SHORT G_M000_IG91
       mov      rcx, rsi
       mov      edx, r13d
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
 
G_M000_IG91:                ;; offset=0x0993
       mov      rcx, gword ptr [rsi]
       cmp      r15d, dword ptr [rcx+0x08]
       jae      G_M000_IG174
       mov      edx, r15d
       shl      rdx, 4
       lea      rbx, bword ptr [rcx+rdx+0x10]
       mov      rcx, rbx
       mov      rdx, r14
       call     CORINFO_HELP_ASSIGN_REF
       xor      edx, edx
       mov      qword ptr [rbx+0x08], rdx
       mov      dword ptr [rsi+0x40], r13d
       jmp      G_M000_IG164
 
G_M000_IG92:                ;; offset=0x09C6
       mov      rcx, 0x7FFA027743F8
       cmp      rdx, rcx
       jne      G_M000_IG96
 
G_M000_IG93:                ;; offset=0x09D9
       test     rsi, rsi
       je       G_M000_IG167
       mov      edx, dword ptr [rbx+0x10]
       mov      dword ptr [rbp-0x3C], edx
 
G_M000_IG94:                ;; offset=0x09E8
       mov      r15, bword ptr [rbp+0x10]
       lea      rdi, bword ptr [r15+0x20]
       mov      esi, dword ptr [r12+0x08]
       mov      rcx, gword ptr [r15+0x20]
       mov      edx, dword ptr [rbp-0x3C]
       cmp      edx, dword ptr [rcx+0x08]
       jae      G_M000_IG95
       mov      eax, edx
       shl      rax, 4
       lea      rcx, bword ptr [rcx+rax+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Object():System.Object:this]
       mov      rdx, rax
       mov      rcx, 0x7FFA028377A8
       call     [Lokad.Lython.Internal.NullabilityExtensions:RequireNotNull[System.__Canon](System.__Canon):System.__Canon]
       mov      rbx, rax
       mov      rcx, 0x7FFA0285D930
       call     CORINFO_HELP_NEWSFAST
       mov      r14, rax
       movzx    rcx, byte  ptr [r12+0x0C]
       mov      dword ptr [rsp+0x20], ecx
       xor      rcx, rcx
       mov      gword ptr [rsp+0x28], rcx
       mov      rcx, r14
       mov      edx, esi
       mov      r8, r13
       mov      r9, rbx
       call     [Lokad.Lython.Runtime.Calls.CallExpansion+CallArgumentAccumulator:.ctor(int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,System.Object,bool,Lokad.Lython.Runtime.MemoryGovernor+TemporaryMemoryReservation):this]
       mov      rcx, gword ptr [rdi]
       mov      edx, dword ptr [rbp-0x3C]
       cmp      edx, dword ptr [rcx+0x08]
       jae      SHORT G_M000_IG95
       mov      eax, edx
       shl      rax, 4
       lea      r13, bword ptr [rcx+rax+0x10]
       mov      rcx, r13
       mov      rdx, r14
       call     CORINFO_HELP_ASSIGN_REF
       xor      ecx, ecx
       mov      qword ptr [r13+0x08], rcx
       jmp      G_M000_IG164
 
G_M000_IG95:                ;; offset=0x0A8C
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG96:                ;; offset=0x0A92
       test     r12, r12
       je       G_M000_IG103
 
G_M000_IG97:                ;; offset=0x0A9B
       mov      rdx, qword ptr [r12]
       mov      r9, 0x7FFA02776198
       cmp      rdx, r9
       je       SHORT G_M000_IG98
       mov      r9, 0x7FFA027765D0
       cmp      rdx, r9
       je       SHORT G_M000_IG98
       mov      r9, 0x7FFA027769D0
       cmp      rdx, r9
       je       SHORT G_M000_IG98
       mov      r9, 0x7FFA027A7620
       cmp      rdx, r9
       je       SHORT G_M000_IG98
       mov      r9, 0x7FFA027A7B10
       cmp      rdx, r9
       je       SHORT G_M000_IG98
       mov      r9, 0x7FFA02756A18
       cmp      rdx, r9
       jne      SHORT G_M000_IG101
 
G_M000_IG98:                ;; offset=0x0AF9
       test     rsi, rsi
       je       G_M000_IG167
 
G_M000_IG99:                ;; offset=0x0B02
       vmovdqu  ymm0, ymmword ptr [rbx]
       vmovdqu  ymmword ptr [rbp-0x150], ymm0
 
G_M000_IG100:                ;; offset=0x0B0E
       movzx    r9, r15b
       mov      dword ptr [rsp+0x20], r9d
       lea      r9, [rbp-0x150]
       lea      rdx, [rbp-0x78]
       mov      r8, r12
       mov      rcx, rsi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecutePreparedSuspendingOperationAsync(Lokad.Lython.Frontend.ExecutableOperation,Lokad.Lython.Frontend.ExecutableInstruction,bool):System.Threading.Tasks.ValueTask:this]
       mov      rdx, gword ptr [rbp-0x78]
       mov      rcx, r14
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rcx, qword ptr [rbp-0x70]
       mov      qword ptr [r14+0x08], rcx
       jmp      G_M000_IG164
 
G_M000_IG101:                ;; offset=0x0B47
       mov      rcx, 0x7FFA027305A0
       cmp      rdx, rcx
       jne      SHORT G_M000_IG103
 
G_M000_IG102:                ;; offset=0x0B56
       mov      rcx, r12
       test     rsi, rsi
       je       G_M000_IG167
       mov      rcx, gword ptr [rcx+0x08]
       mov      rdx, rsi
       call     [Lokad.Lython.Runtime.LythonRuntime:ExecuteTypeAlias(Lokad.Lython.Frontend.LoweredTypeAlias,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext)]
       mov      r15, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [r15]
       mov      rdx, gword ptr [r15+0x08]
       mov      r8, rsi
       call     [Lokad.Lython.Runtime.LythonRuntime:SyncExecutableLocalsFromContext(Lokad.Lython.Frontend.ExecutableCodeObject,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot[],Lokad.Lython.Runtime.LythonRuntime+ExecutionContext)]
       jmp      G_M000_IG164
 
G_M000_IG103:                ;; offset=0x0B88
       test     r12, r12
       je       G_M000_IG107
 
G_M000_IG104:                ;; offset=0x0B91
       mov      rdx, qword ptr [r12]
       mov      rcx, 0x7FFA027A7F10
       cmp      rdx, rcx
       jne      G_M000_IG107
 
G_M000_IG105:                ;; offset=0x0BA8
       test     rsi, rsi
       je       G_M000_IG167
       mov      rdi, bword ptr [rbp+0x10]
       add      rdi, 32
       mov      rcx, rdi
       mov      edx, dword ptr [rbx+0x10]
       mov      r8d, dword ptr [rbx+0x18]
       test     r8d, r8d
       jge      SHORT G_M000_IG106
       not      r8d
 
G_M000_IG106:                ;; offset=0x0BCB
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:TakeValue(int,int):System.Object:this]
       mov      rsi, rax
       mov      rcx, r13
       mov      rdx, gword ptr [rbp-0x188]
       call     [Lokad.Lython.Runtime.LythonRuntime:ResolveVariableAnnotationMapping(Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):System.Object]
       mov      rdx, rax
       mov      gword ptr [rsp+0x20], r13
       mov      r13, gword ptr [rbp-0x188]
       mov      gword ptr [rsp+0x28], r13
       movzx    r8, r15b
       mov      dword ptr [rsp+0x30], r8d
       mov      r8, gword ptr [r12+0x08]
       lea      rcx, [rbp-0x88]
       mov      r9, rsi
       call     [Lokad.Lython.Runtime.LythonRuntime:StoreAnnotationEntryAsync(System.Object,System.String,System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,bool):System.Threading.Tasks.ValueTask]
       mov      rbx, r14
       mov      rdx, gword ptr [rbp-0x88]
       mov      rcx, rbx
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rcx, qword ptr [rbp-0x80]
       mov      qword ptr [rbx+0x08], rcx
       jmp      G_M000_IG164
 
G_M000_IG107:                ;; offset=0x0C35
       test     r12, r12
       je       G_M000_IG112
 
G_M000_IG108:                ;; offset=0x0C3E
       mov      rdx, qword ptr [r12]
       mov      rcx, 0x7FFA02734FD8
       cmp      rdx, rcx
       jne      G_M000_IG112
 
G_M000_IG109:                ;; offset=0x0C55
       test     rsi, rsi
       je       SHORT G_M000_IG110
       mov      bword ptr [rsp+0x20], rbx
       movzx    rcx, r15b
       mov      dword ptr [rsp+0x28], ecx
       lea      rcx, [rbp-0x98]
       mov      rdx, bword ptr [rbp+0x10]
       mov      r8, rsi
       mov      r9, r12
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CreateExecutableFunction(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Frontend.ExecutableCreateFunction,byref,bool):System.Threading.Tasks.ValueTask]
       mov      r12, r14
       mov      rdx, gword ptr [rbp-0x98]
       mov      rcx, r12
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rcx, qword ptr [rbp-0x90]
       mov      qword ptr [r12+0x08], rcx
       jmp      G_M000_IG164
 
G_M000_IG110:                ;; offset=0x0CA1
       mov      rcx, r12
       mov      rdx, rdi
       call     [Lokad.Lython.Runtime.LythonRuntime:NeedsDefinitionContext(Lokad.Lython.Frontend.ExecutableCreateFunction,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):bool]
       test     eax, eax
       jne      G_M000_IG168
       mov      rsi, gword ptr [r12+0x08]
       mov      r15, bword ptr [rbp+0x10]
       mov      r13, gword ptr [r15]
       mov      r14, gword ptr [r15+0x18]
       xor      rcx, rcx
       mov      gword ptr [rbp-0x48], rcx
       mov      rcx, rsi
       call     [Lokad.Lython.Runtime.LythonRuntime:CanDefineLexically(Lokad.Lython.Frontend.ExecutableCodeObject):bool]
       test     eax, eax
       je       G_M000_IG168
       mov      rcx, gword ptr [rsi+0x80]
       mov      r11, 0x7FFA02181F28
       call     [r11]System.Collections.Generic.IReadOnlyCollection`1[System.__Canon]:get_Count():int:this
       test     eax, eax
       je       SHORT G_M000_IG111
       mov      rax, gword ptr [rbp-0x188]
       mov      gword ptr [rsp+0x20], rax
       lea      rcx, [rbp-0x48]
       mov      qword ptr [rsp+0x28], rcx
       mov      rcx, rsi
       mov      rdx, r13
       mov      r8, r14
       mov      r9, rdi
       call     [Lokad.Lython.Runtime.LythonRuntime:TryGetStandaloneCaptures(Lokad.Lython.Frontend.ExecutableCodeObject,Lokad.Lython.Frontend.ExecutableCodeObject,Lokad.Lython.Runtime.LythonRuntime+ExecutableCaptures,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,byref):bool]
       test     eax, eax
       je       G_M000_IG168
 
G_M000_IG111:                ;; offset=0x0D23
       mov      rcx, gword ptr [rbp-0x48]
       mov      gword ptr [rsp+0x20], rcx
       mov      rcx, r15
       mov      rdx, rdi
       mov      r8, r12
       mov      r9, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CreateBorrowedExecutableFunction(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Frontend.ExecutableCreateFunction,byref,int[])]
       jmp      G_M000_IG164
 
G_M000_IG112:                ;; offset=0x0D43
       test     r12, r12
       je       G_M000_IG151
 
G_M000_IG113:                ;; offset=0x0D4C
       mov      rdx, qword ptr [r12]
       mov      rcx, 0x7FFA02756578
       cmp      rdx, rcx
       jne      G_M000_IG151
 
G_M000_IG114:                ;; offset=0x0D63
       vmovdqu  xmm0, xmmword ptr [r12+0x08]
       vmovdqu  xmmword ptr [rbp-0x60], xmm0
       mov      rcx, qword ptr [r12+0x18]
       mov      qword ptr [rbp-0x50], rcx
 
G_M000_IG115:                ;; offset=0x0D78
       xor      rcx, rcx
       mov      gword ptr [rbp-0x68], rcx
       test     rsi, rsi
       jne      G_M000_IG116
       cmp      byte  ptr [rbp-0x4F], 0
       jne      G_M000_IG168
       mov      r15, gword ptr [r12+0x08]
       mov      r14, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [r14]
       mov      gword ptr [rbp-0x1B8], rdx
       mov      r8, gword ptr [r14+0x18]
       mov      gword ptr [rbp-0x1D0], r8
       xor      rcx, rcx
       mov      gword ptr [rbp-0x68], rcx
       mov      rcx, r15
       call     [Lokad.Lython.Runtime.LythonRuntime:CanDefineLexically(Lokad.Lython.Frontend.ExecutableCodeObject):bool]
       test     eax, eax
       je       G_M000_IG168
       mov      rcx, gword ptr [r15+0x80]
       mov      r11, 0x7FFA02181F30
       call     [r11]System.Collections.Generic.IReadOnlyCollection`1[System.__Canon]:get_Count():int:this
       test     eax, eax
       je       SHORT G_M000_IG116
       mov      rax, gword ptr [rbp-0x188]
       mov      gword ptr [rsp+0x20], rax
       lea      rcx, [rbp-0x68]
       mov      qword ptr [rsp+0x28], rcx
       mov      rcx, r15
       mov      rdx, gword ptr [rbp-0x1B8]
       mov      r8, gword ptr [rbp-0x1D0]
       mov      r9, rdi
       call     [Lokad.Lython.Runtime.LythonRuntime:TryGetStandaloneCaptures(Lokad.Lython.Frontend.ExecutableCodeObject,Lokad.Lython.Frontend.ExecutableCodeObject,Lokad.Lython.Runtime.LythonRuntime+ExecutableCaptures,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,byref):bool]
       test     eax, eax
       je       G_M000_IG168
 
G_M000_IG116:                ;; offset=0x0E15
       mov      r14, bword ptr [rbp+0x10]
       mov      edi, dword ptr [rbx+0x10]
 
G_M000_IG117:                ;; offset=0x0E1C
       test     rsi, rsi
       je       G_M000_IG123
       lea      rcx, bword ptr [r14+0x20]
       mov      r15, rcx
       mov      r13, r15
       mov      rcx, r12
       call     [Lokad.Lython.Frontend.ExecutableCreateLambda:get_InputCount():int:this]
       mov      r12d, eax
       mov      rcx, gword ptr [r13]
       test     rcx, rcx
       je       SHORT G_M000_IG118
       mov      edx, edi
       mov      eax, r12d
       add      rdx, rax
       mov      eax, dword ptr [rcx+0x08]
       cmp      rdx, rax
       ja       G_M000_IG138
       jmp      SHORT G_M000_IG119
 
G_M000_IG118:                ;; offset=0x0E5A
       mov      ecx, edi
       or       ecx, r12d
       jne      G_M000_IG138
       xor      rcx, rcx
       xor      edi, edi
       xor      r12d, r12d
 
G_M000_IG119:                ;; offset=0x0E6C
       xor      r13, r13
       xor      eax, eax
       test     rcx, rcx
       je       SHORT G_M000_IG122
       mov      rdx, qword ptr [rcx]
       test     dword ptr [rdx], 0xFFFFFFFF80000000
       jne      SHORT G_M000_IG120
       lea      rdx, [rbp-0x120]
       mov      rax, qword ptr [rcx]
       mov      rax, qword ptr [rax+0x40]
       call     [rax+0x28]System.Buffers.MemoryManager`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:GetSpan():System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:this
       mov      eax, dword ptr [rbp-0x118]
       mov      r13, bword ptr [rbp-0x120]
       jmp      SHORT G_M000_IG121
 
G_M000_IG120:                ;; offset=0x0EA1
       lea      r13, bword ptr [rcx+0x10]
       mov      eax, dword ptr [rcx+0x08]
 
G_M000_IG121:                ;; offset=0x0EA8
       and      edi, 0x7FFFFFFF
       mov      r8d, edi
       mov      ecx, r12d
       add      rcx, r8
       mov      eax, eax
       cmp      rcx, rax
       ja       G_M000_IG138
       shl      r8, 4
       add      r13, r8
       mov      eax, r12d
 
G_M000_IG122:                ;; offset=0x0ECC
       mov      rdx, gword ptr [rbp-0x58]
       mov      bword ptr [rbp-0x160], r13
       mov      dword ptr [rbp-0x10C], eax
       mov      dword ptr [rbp-0x158], eax
       lea      r8, [rbp-0x160]
       lea      rcx, [rbp-0xB0]
       xor      r9d, r9d
       call     [Lokad.Lython.Runtime.LythonRuntime:ReadExecutableDefaults(Lokad.Lython.Frontend.FunctionParameterLayout,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],bool):Lokad.Lython.Runtime.FunctionDefaults]
       lea      rcx, [rbp-0x60]
       lea      rdx, [rbp-0xB0]
       mov      r8, rsi
       mov      r9, gword ptr [rbp-0x188]
       call     [Lokad.Lython.Runtime.LythonRuntime:CreateLambdaFunction(byref,Lokad.Lython.Runtime.FunctionDefaults,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.PyFunctionBase]
       mov      rdi, rax
       mov      edx, dword ptr [rbp-0x10C]
       add      rdx, rdx
       mov      rcx, r13
       call     [System.SpanHelpers:ClearWithReferences(byref,nuint)]
       mov      bword ptr [rbp-0x1D8], r15
       jmp      G_M000_IG139
 
G_M000_IG123:                ;; offset=0x0F36
       mov      rcx, gword ptr [r12+0x08]
       mov      r9, gword ptr [rbp-0x68]
       mov      rdx, gword ptr [r14+0x08]
       test     rdx, rdx
       je       SHORT G_M000_IG124
       lea      r8, bword ptr [rdx+0x10]
       mov      edx, dword ptr [rdx+0x08]
       jmp      SHORT G_M000_IG125
 
G_M000_IG124:                ;; offset=0x0F51
       xor      r8, r8
       xor      edx, edx
 
G_M000_IG125:                ;; offset=0x0F56
       mov      bword ptr [rbp-0x170], r8
       mov      dword ptr [rbp-0x168], edx
       mov      rdx, gword ptr [r14+0x18]
       mov      gword ptr [rsp+0x20], rdx
       mov      gword ptr [rsp+0x28], r9
       lea      r9, [rbp-0xD8]
       mov      qword ptr [rsp+0x30], r9
       xor      r9, r9
       mov      gword ptr [rsp+0x38], r9
 
G_M000_IG126:                ;; offset=0x0F85
       mov      dword ptr [rsp+0x40], r9d
       lea      r9, [rbp-0x170]
       mov      rdx, r13
       mov      r8, gword ptr [rbp-0x188]
       call     [Lokad.Lython.Runtime.LythonRuntime:CaptureExecutableCells(Lokad.Lython.Frontend.ExecutableCodeObject,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],Lokad.Lython.Runtime.LythonRuntime+ExecutableCaptures,int[],byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,bool):Lokad.Lython.Runtime.LythonRuntime+ExecutableCaptures]
       mov      r15, rax
       cmp      dword ptr [rbp-0xD8], 0
       je       SHORT G_M000_IG127
       lea      rcx, bword ptr [r14+0x20]
       mov      rax, rcx
       mov      ecx, dword ptr [rbp-0xD8]
       movsxd   rcx, ecx
       imul     rcx, rcx, 96
       sub      qword ptr [rax+0x30], rcx
 
G_M000_IG127:                ;; offset=0x0FC5
       mov      rax, gword ptr [rbp-0x58]
       mov      gword ptr [rbp-0x198], rax
       mov      rdx, gword ptr [rbp-0x60]
       mov      gword ptr [rbp-0x1A0], rdx
       movzx    r8, byte  ptr [rbp-0x50]
       mov      dword ptr [rbp-0xB4], r8d
       lea      rcx, bword ptr [r14+0x20]
       mov      r10, rcx
       mov      bword ptr [rbp-0x1D8], r10
       mov      bword ptr [rbp-0x1A8], r10
       mov      rcx, r12
       call     [Lokad.Lython.Frontend.ExecutableCreateLambda:get_InputCount():int:this]
       mov      r12d, eax
       mov      rdx, bword ptr [rbp-0x1A8]
       mov      rcx, gword ptr [rdx]
       test     rcx, rcx
       je       SHORT G_M000_IG128
       mov      edx, edi
       mov      eax, r12d
       add      rdx, rax
       mov      eax, dword ptr [rcx+0x08]
       cmp      rdx, rax
       ja       G_M000_IG138
       jmp      SHORT G_M000_IG129
 
G_M000_IG128:                ;; offset=0x102D
       mov      ecx, edi
       or       ecx, r12d
       jne      G_M000_IG138
       xor      rcx, rcx
       xor      edi, edi
       xor      r12d, r12d
 
G_M000_IG129:                ;; offset=0x103F
       xor      rax, rax
       xor      r8d, r8d
       test     rcx, rcx
       mov      bword ptr [rbp-0x1C0], rax
       mov      dword ptr [rbp-0xDC], r8d
       je       SHORT G_M000_IG132
       mov      rdx, qword ptr [rcx]
       test     dword ptr [rdx], 0xFFFFFFFF80000000
       jne      SHORT G_M000_IG130
       lea      rdx, [rbp-0xF0]
       mov      rax, qword ptr [rcx]
       mov      rax, qword ptr [rax+0x40]
       call     [rax+0x28]System.Buffers.MemoryManager`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:GetSpan():System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:this
       mov      r8d, dword ptr [rbp-0xE8]
       mov      rax, bword ptr [rbp-0xF0]
       mov      edx, r8d
       jmp      SHORT G_M000_IG131
 
G_M000_IG130:                ;; offset=0x1086
       lea      rax, bword ptr [rcx+0x10]
       mov      edx, dword ptr [rcx+0x08]
 
G_M000_IG131:                ;; offset=0x108D
       and      edi, 0x7FFFFFFF
       mov      ecx, edi
       mov      r8d, r12d
       add      r8, rcx
       mov      edx, edx
       cmp      r8, rdx
       ja       G_M000_IG138
       shl      rcx, 4
       add      rax, rcx
       mov      bword ptr [rbp-0x1C0], rax
       mov      dword ptr [rbp-0xDC], r12d
 
G_M000_IG132:                ;; offset=0x10BB
       mov      rcx, gword ptr [rbp-0x198]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.FunctionParameterLayout:get_DefaultStorageCount():int:this]
       mov      edi, eax
       mov      r12d, dword ptr [rbp-0xDC]
       cmp      edi, r12d
       ja       G_M000_IG138
       mov      rcx, r13
       call     [Lokad.Lython.Runtime.LythonRuntime:GetGlobalContext(Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):Lokad.Lython.Runtime.LythonRuntime+ExecutionContext]
       mov      gword ptr [rbp-0x1C8], rax
       mov      r10, bword ptr [rbp-0x1C0]
       mov      bword ptr [rbp-0x160], r10
       mov      dword ptr [rbp-0x158], edi
       lea      r8, [rbp-0x160]
       lea      rcx, [rbp-0x108]
       mov      rdx, gword ptr [rbp-0x198]
       xor      r9d, r9d
       call     [Lokad.Lython.Runtime.LythonRuntime:ReadExecutableDefaults(Lokad.Lython.Frontend.FunctionParameterLayout,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],bool):Lokad.Lython.Runtime.FunctionDefaults]
       mov      r9d, edi
       shl      r9, 4
       add      r9, bword ptr [rbp-0x1C0]
       mov      edx, r12d
       sub      edx, edi
       lea      rcx, [rbp-0x108]
       mov      qword ptr [rsp+0x20], rcx
       mov      r12d, dword ptr [rbp-0xB4]
       mov      dword ptr [rsp+0x28], r12d
       mov      gword ptr [rsp+0x30], r13
       mov      r13, gword ptr [rbp-0x188]
       mov      gword ptr [rsp+0x38], r13
       mov      bword ptr [rbp-0x160], r9
       mov      dword ptr [rbp-0x158], edx
       xor      r9, r9
       mov      gword ptr [rsp+0x48], r9
 
G_M000_IG133:                ;; offset=0x116F
       mov      gword ptr [rbp-0x180], r9
 
G_M000_IG134:                ;; offset=0x1176
       mov      dword ptr [rbp-0x178], r9d
       mov      byte  ptr [rbp-0x174], 0
 
G_M000_IG135:                ;; offset=0x1184
       mov      dword ptr [rsp+0x58], r9d
 
G_M000_IG136:                ;; offset=0x1189
       mov      bword ptr [rbp-0x170], r9
 
G_M000_IG137:                ;; offset=0x1190
       mov      dword ptr [rbp-0x168], r9d
       lea      r9, [rbp-0x160]
       mov      qword ptr [rsp+0x40], r9
       lea      r9, [rbp-0x170]
       mov      qword ptr [rsp+0x60], r9
       lea      r9, [rbp-0x180]
       mov      qword ptr [rsp+0x50], r9
       mov      r9, r15
       mov      rcx, gword ptr [rbp-0x198]
       mov      rdx, gword ptr [rbp-0x1A0]
       mov      r8, gword ptr [rbp-0x1C8]
       call     [Lokad.Lython.Runtime.LythonRuntime:CreateFunctionValue(Lokad.Lython.Frontend.FunctionParameterLayout,Lokad.Lython.Frontend.ExecutableCodeObject,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutableCaptures,Lokad.Lython.Runtime.FunctionDefaults,bool,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],Lokad.Lython.Runtime.Text.PyString[],System.ValueTuple`3[System.Object,int,bool],bool,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):Lokad.Lython.Runtime.PyFunctionBase]
       mov      r15, rax
       mov      edx, edi
       add      rdx, rdx
       mov      rcx, bword ptr [rbp-0x1C0]
       call     [System.SpanHelpers:ClearWithReferences(byref,nuint)]
       mov      rdi, r15
       jmp      SHORT G_M000_IG139
 
G_M000_IG138:                ;; offset=0x11F3
       call     [System.ThrowHelper:ThrowArgumentOutOfRangeException()]
       int3     
 
G_M000_IG139:                ;; offset=0x11FA
       mov      r15, bword ptr [rbp-0x1D8]
       mov      rcx, r15
       mov      r13d, dword ptr [rbx+0x1C]
       cmp      r13d, 51
       ja       SHORT G_M000_IG143
 
G_M000_IG140:                ;; offset=0x120E
       mov      rdx, 0x7FFFFFFFFF9FF
       bt       rdx, r13
       jb       SHORT G_M000_IG143
 
G_M000_IG141:                ;; offset=0x121E
       mov      edx, dword ptr [rbx+0x18]
       test     edx, edx
       jge      SHORT G_M000_IG142
       not      edx
 
G_M000_IG142:                ;; offset=0x1227
       jmp      SHORT G_M000_IG144
 
G_M000_IG143:                ;; offset=0x1229
       mov      edx, dword ptr [rbx+0x14]
 
G_M000_IG144:                ;; offset=0x122C
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
       mov      r13d, dword ptr [rbx+0x18]
       test     r13d, r13d
       jge      SHORT G_M000_IG145
       mov      gword ptr [rbp-0x130], rdi
       xor      r9d, r9d
       mov      qword ptr [rbp-0x128], r9
       lea      r9, [rbp-0x130]
       mov      rdx, rsi
       mov      r8, rbx
       mov      rcx, r14
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CompleteResultConsumer(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot)]
       jmp      G_M000_IG164
 
G_M000_IG145:                ;; offset=0x1267
       mov      r14, r15
       mov      ecx, dword ptr [rbx+0x1C]
       cmp      ecx, 51
       ja       SHORT G_M000_IG148
 
G_M000_IG146:                ;; offset=0x1272
       mov      rdx, 0x7FFFFFFFFF9FF
       bt       rdx, rcx
       jb       SHORT G_M000_IG148
 
G_M000_IG147:                ;; offset=0x1282
       mov      r15d, r13d
       jmp      SHORT G_M000_IG149
 
G_M000_IG148:                ;; offset=0x1287
       mov      r15d, dword ptr [rbx+0x14]
 
G_M000_IG149:                ;; offset=0x128B
       cmp      r13d, dword ptr [r14+0x40]
       jge      SHORT G_M000_IG150
       mov      rcx, r14
       mov      edx, r13d
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
 
G_M000_IG150:                ;; offset=0x129D
       mov      rcx, gword ptr [r14]
       cmp      r15d, dword ptr [rcx+0x08]
       jae      G_M000_IG174
       mov      edx, r15d
       shl      rdx, 4
       lea      rbx, bword ptr [rcx+rdx+0x10]
       mov      rcx, rbx
       mov      rdx, rdi
       call     CORINFO_HELP_ASSIGN_REF
       xor      eax, eax
       mov      qword ptr [rbx+0x08], rax
       mov      dword ptr [r14+0x40], r13d
       jmp      G_M000_IG164
 
G_M000_IG151:                ;; offset=0x12D0
       test     r12, r12
       je       G_M000_IG161
 
G_M000_IG152:                ;; offset=0x12D9
       mov      rdx, qword ptr [r12]
       mov      rcx, 0x7FFA027747E0
       cmp      rdx, rcx
       jne      G_M000_IG161
 
G_M000_IG153:                ;; offset=0x12F0
       test     rsi, rsi
       je       G_M000_IG167
       mov      rcx, 0x7FFA0285D930
       call     CORINFO_HELP_NEWSFAST
       mov      r15, rax
       xor      edx, edx
       mov      dword ptr [rsp+0x20], edx
 
G_M000_IG154:                ;; offset=0x1311
       mov      gword ptr [rsp+0x28], rdx
       mov      edx, dword ptr [r12+0x08]
       mov      r9, 0x23782C01418
       mov      r9, gword ptr [r9]
       mov      rcx, r15
       mov      r8, r13
       call     [Lokad.Lython.Runtime.Calls.CallExpansion+CallArgumentAccumulator:.ctor(int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,System.Object,bool,Lokad.Lython.Runtime.MemoryGovernor+TemporaryMemoryReservation):this]
       mov      r14d, dword ptr [rbx+0x18]
       test     r14d, r14d
       jge      SHORT G_M000_IG155
       mov      gword ptr [rbp-0x130], r15
       xor      r9d, r9d
       mov      qword ptr [rbp-0x128], r9
       lea      r9, [rbp-0x130]
       mov      rdx, rsi
       mov      r8, rbx
       mov      rcx, bword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CompleteResultConsumer(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot)]
       jmp      G_M000_IG164
 
G_M000_IG155:                ;; offset=0x136A
       mov      rdi, bword ptr [rbp+0x10]
       lea      rcx, bword ptr [rdi+0x20]
       mov      rsi, rcx
       mov      rdi, rsi
       mov      ecx, dword ptr [rbx+0x1C]
       cmp      ecx, 51
       ja       SHORT G_M000_IG158
 
G_M000_IG156:                ;; offset=0x1380
       mov      rdx, 0x7FFFFFFFFF9FF
       bt       rdx, rcx
       jb       SHORT G_M000_IG158
 
G_M000_IG157:                ;; offset=0x1390
       mov      esi, r14d
       jmp      SHORT G_M000_IG159
 
G_M000_IG158:                ;; offset=0x1395
       mov      esi, dword ptr [rbx+0x14]
 
G_M000_IG159:                ;; offset=0x1398
       cmp      r14d, dword ptr [rdi+0x40]
       jge      SHORT G_M000_IG160
       mov      rcx, rdi
       mov      edx, r14d
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
 
G_M000_IG160:                ;; offset=0x13AA
       mov      rcx, gword ptr [rdi]
       cmp      esi, dword ptr [rcx+0x08]
       jae      G_M000_IG174
       mov      edx, esi
       shl      rdx, 4
       lea      rbx, bword ptr [rcx+rdx+0x10]
       mov      rcx, rbx
       mov      rdx, r15
       call     CORINFO_HELP_ASSIGN_REF
       xor      r9d, r9d
       mov      qword ptr [rbx+0x08], r9
       mov      dword ptr [rdi+0x40], r14d
       jmp      SHORT G_M000_IG164
 
G_M000_IG161:                ;; offset=0x13D9
       test     r12, r12
       je       SHORT G_M000_IG166
 
G_M000_IG162:                ;; offset=0x13DE
       mov      rdx, qword ptr [r12]
       mov      r9, 0x7FFA02755D60
       cmp      rdx, r9
       jne      SHORT G_M000_IG166
 
G_M000_IG163:                ;; offset=0x13F1
       mov      r8, r12
       test     rsi, rsi
       je       SHORT G_M000_IG167
       movzx    r9, r15b
       mov      dword ptr [rsp+0x20], r9d
       mov      r9d, dword ptr [rbx+0x10]
       lea      rdx, [rbp-0xC8]
       mov      rcx, rsi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecutePreparedClassDefinitionAsync(Lokad.Lython.Frontend.ExecutableCreateClass,int,bool):System.Threading.Tasks.ValueTask:this]
       mov      r12, r14
       mov      rdx, gword ptr [rbp-0xC8]
       mov      rcx, r12
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rax, qword ptr [rbp-0xC0]
       mov      qword ptr [r12+0x08], rax
 
G_M000_IG164:                ;; offset=0x1434
       mov      eax, 1
 
G_M000_IG165:                ;; offset=0x1439
       vzeroupper 
       add      rsp, 520
       pop      rbx
       pop      rsi
       pop      rdi
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG166:                ;; offset=0x1450
       test     r12, r12
       je       SHORT G_M000_IG170
 
G_M000_IG167:                ;; offset=0x1455
       test     rsi, rsi
       jne      SHORT G_M000_IG170
 
G_M000_IG168:                ;; offset=0x145A
       xor      eax, eax
 
G_M000_IG169:                ;; offset=0x145C
       vzeroupper 
       add      rsp, 520
       pop      rbx
       pop      rsi
       pop      rdi
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG170:                ;; offset=0x1473
       mov      rcx, 0x7FFA023A94A8
       call     CORINFO_HELP_NEWSFAST
       mov      rbx, rax
       mov      rcx, rbx
       mov      rdx, 0x257A9A71380
       call     [System.InvalidOperationException:.ctor(System.String):this]
       mov      rcx, rbx
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG171:                ;; offset=0x14A1
       mov      rcx, 0x7FFA0285E3D8
       call     CORINFO_HELP_GET_GCSTATIC_BASE
       jmp      G_M000_IG64
 
G_M000_IG172:                ;; offset=0x14B5
       mov      rdx, rax
       call     CORINFO_HELP_CHKCASTCLASS
       int3     
 
G_M000_IG173:                ;; offset=0x14BE
       mov      rcx, 0x7FFA02798898
       call     CORINFO_HELP_GET_GCSTATIC_BASE
       jmp      G_M000_IG82
 
G_M000_IG174:                ;; offset=0x14D2
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG175:                ;; offset=0x14D8
       sub      rsp, 104
 
G_M000_IG176:                ;; offset=0x14DC
       cmp      dword ptr [rbp-0x40], 0
       jne      SHORT G_M000_IG177
       mov      rcx, gword ptr [rbp-0x190]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext+InlinedComprehensionScope:Dispose():this]
 
G_M000_IG177:                ;; offset=0x14EF
       call     CORINFO_HELP_RETHROW
       int3     
 
G_M000_IG178:                ;; offset=0x14F5
       sub      rsp, 104
 
G_M000_IG179:                ;; offset=0x14F9
       mov      r15, bword ptr [rbp+0x10]
       lea      rdi, bword ptr [r15+0x20]
       mov      rcx, rdi
       mov      edx, dword ptr [rbp-0x3C]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
       call     CORINFO_HELP_RETHROW
       int3     
 
G_M000_IG180:                ;; offset=0x1513
       sub      rsp, 104
 
G_M000_IG181:                ;; offset=0x1517
       mov      r14, bword ptr [rbp+0x10]
       cmp      byte  ptr [r14], r14b
       lea      r15, bword ptr [r14+0x20]
       mov      rcx, r15
       mov      rbx, bword ptr [rbp+0x28]
       mov      r13d, dword ptr [rbx+0x1C]
       cmp      r13d, 9
       je       SHORT G_M000_IG182
       cmp      r13d, 10
       je       SHORT G_M000_IG182
       cmp      r13d, 51
       je       SHORT G_M000_IG182
       mov      edx, dword ptr [rbx+0x14]
       jmp      SHORT G_M000_IG184
 
G_M000_IG182:                ;; offset=0x1544
       cmp      dword ptr [rbx+0x18], 0
       jl       SHORT G_M000_IG183
       mov      edx, dword ptr [rbx+0x18]
       jmp      SHORT G_M000_IG184
 
G_M000_IG183:                ;; offset=0x154F
       mov      edx, dword ptr [rbx+0x18]
       not      edx
 
G_M000_IG184:                ;; offset=0x1554
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
       nop      
 
G_M000_IG185:                ;; offset=0x155B
       vzeroupper 
       add      rsp, 104
       ret      
 
; Total bytes of code 5475

; Assembly listing for method Lokad.Lython.Runtime.LythonRuntime+NativeExecution:ApplyDefinition(byref):bool:this (FullOpts)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; FullOpts code
; optimized code
; rbp based frame
; partially interruptible
; No PGO data
; 0 inlinees with PGO data; 24 single block inlinees; 2 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       push     r15
       push     r14
       push     r13
       push     r12
       push     rdi
       push     rsi
       push     rbx
       sub      rsp, 136
       lea      rbp, [rsp+0xC0]
       xor      eax, eax
       mov      qword ptr [rbp-0x58], rax
       vxorps   xmm4, xmm4, xmm4
       vmovdqa  xmmword ptr [rbp-0x50], xmm4
       mov      qword ptr [rbp-0x40], rax
       mov      rbx, rcx
       mov      rsi, rdx
 
G_M000_IG02:                ;; offset=0x0034
       mov      rdi, gword ptr [rsi]
       mov      rcx, gword ptr [rbx+0x08]
       mov      r14, gword ptr [rcx+0x30]
       mov      rcx, rsi
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ConstantIndex():int:this]
       cmp      eax, dword ptr [r14+0x08]
       jae      G_M000_IG16
       mov      edx, eax
       mov      r14, gword ptr [r14+8*rdx+0x10]
       test     r14, r14
       je       G_M000_IG06
 
G_M000_IG03:                ;; offset=0x0062
       mov      rdx, 0x7FFA02734FD8
       cmp      qword ptr [r14], rdx
       jne      G_M000_IG06
 
G_M000_IG04:                ;; offset=0x0075
       mov      rdx, gword ptr [rbx+0x10]
       mov      rcx, r14
       call     [Lokad.Lython.Runtime.LythonRuntime:NeedsDefinitionContext(Lokad.Lython.Frontend.ExecutableCreateFunction,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):bool]
       test     eax, eax
       jne      G_M000_IG14
       mov      r15, gword ptr [r14+0x08]
       mov      r13, gword ptr [rbx+0x08]
       mov      r12, gword ptr [rbx+0x58]
       mov      rax, gword ptr [rbx+0x10]
       mov      gword ptr [rbp-0x60], rax
       xor      rcx, rcx
       mov      gword ptr [rbp-0x40], rcx
       mov      rcx, r15
       call     [Lokad.Lython.Runtime.LythonRuntime:CanDefineLexically(Lokad.Lython.Frontend.ExecutableCodeObject):bool]
       test     eax, eax
       je       G_M000_IG14
       mov      rcx, gword ptr [r15+0x80]
       mov      r11, 0x7FFA02182040
       call     [r11]System.Collections.Generic.IReadOnlyCollection`1[System.__Canon]:get_Count():int:this
       test     eax, eax
       je       SHORT G_M000_IG05
       mov      gword ptr [rsp+0x20], rdi
       lea      rcx, [rbp-0x40]
       mov      qword ptr [rsp+0x28], rcx
       mov      rcx, r15
       mov      rdx, r13
       mov      r8, r12
       mov      r9, gword ptr [rbp-0x60]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryGetStandaloneCaptures(Lokad.Lython.Frontend.ExecutableCodeObject,Lokad.Lython.Frontend.ExecutableCodeObject,Lokad.Lython.Runtime.LythonRuntime+ExecutableCaptures,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,byref):bool]
       test     eax, eax
       je       G_M000_IG14
 
G_M000_IG05:                ;; offset=0x00F6
       mov      rdi, gword ptr [r14+0x08]
       mov      r15, gword ptr [r14+0x10]
       movzx    r13, byte  ptr [r14+0x40]
       mov      rcx, r14
       call     [Lokad.Lython.Frontend.ExecutableCreateFunction:get_InputCount():int:this]
       mov      rcx, gword ptr [rbp-0x40]
       mov      dword ptr [rsp+0x20], r13d
       mov      dword ptr [rsp+0x28], eax
       mov      gword ptr [rsp+0x30], rcx
       mov      rcx, gword ptr [r14+0x28]
       mov      gword ptr [rsp+0x38], rcx
       mov      rcx, gword ptr [r14+0x30]
       mov      gword ptr [rsp+0x40], rcx
       movzx    rcx, byte  ptr [r14+0x41]
       mov      dword ptr [rsp+0x48], ecx
       mov      rcx, rbx
       mov      rdx, rsi
       mov      r8, rdi
       mov      r9, r15
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:CreateInlineDefinition(byref,Lokad.Lython.Frontend.ExecutableCodeObject,Lokad.Lython.Frontend.FunctionParameterLayout,bool,int,int[],Lokad.Lython.Runtime.Text.PyString[],Lokad.Lython.Frontend.ExecutableInstruction[],bool):Lokad.Lython.Runtime.PyFunctionBase:this]
       mov      gword ptr [rbp-0x58], rax
       xor      r8d, r8d
       mov      qword ptr [rbp-0x50], r8
       lea      r8, [rbp-0x58]
       mov      rdx, rsi
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot):this]
       jmp      G_M000_IG12
 
G_M000_IG06:                ;; offset=0x016B
       test     r14, r14
       je       G_M000_IG14
 
G_M000_IG07:                ;; offset=0x0174
       mov      rcx, 0x7FFA02756578
       cmp      qword ptr [r14], rcx
       jne      G_M000_IG14
 
G_M000_IG08:                ;; offset=0x0187
       movzx    rcx, byte  ptr [r14+0x19]
       test     ecx, ecx
       jne      G_M000_IG14
       mov      r15, gword ptr [r14+0x08]
       mov      r13, gword ptr [rbx+0x08]
       mov      r12, gword ptr [rbx+0x58]
       mov      rax, gword ptr [rbx+0x10]
       mov      gword ptr [rbp-0x68], rax
       xor      rcx, rcx
       mov      gword ptr [rbp-0x48], rcx
       mov      rcx, r15
       call     [Lokad.Lython.Runtime.LythonRuntime:CanDefineLexically(Lokad.Lython.Frontend.ExecutableCodeObject):bool]
       test     eax, eax
       je       G_M000_IG14
       mov      rcx, gword ptr [r15+0x80]
       mov      r11, 0x7FFA02182048
       call     [r11]System.Collections.Generic.IReadOnlyCollection`1[System.__Canon]:get_Count():int:this
       test     eax, eax
       je       SHORT G_M000_IG09
       mov      gword ptr [rsp+0x20], rdi
       lea      rcx, [rbp-0x48]
       mov      qword ptr [rsp+0x28], rcx
       mov      rcx, r15
       mov      rdx, r13
       mov      r8, r12
       mov      r9, gword ptr [rbp-0x68]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryGetStandaloneCaptures(Lokad.Lython.Frontend.ExecutableCodeObject,Lokad.Lython.Frontend.ExecutableCodeObject,Lokad.Lython.Runtime.LythonRuntime+ExecutableCaptures,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,byref):bool]
       test     eax, eax
       je       G_M000_IG14
 
G_M000_IG09:                ;; offset=0x0200
       mov      rdi, gword ptr [r14+0x08]
       mov      r15, gword ptr [r14+0x10]
       movzx    r13, byte  ptr [r14+0x18]
       mov      rcx, r14
       call     [Lokad.Lython.Frontend.ExecutableCreateLambda:get_InputCount():int:this]
       mov      rdx, gword ptr [rbp-0x48]
       mov      gword ptr [rsp+0x30], rdx
       xor      rdx, rdx
       mov      gword ptr [rsp+0x38], rdx
 
G_M000_IG10:                ;; offset=0x0226
       mov      gword ptr [rsp+0x40], rdx
 
G_M000_IG11:                ;; offset=0x022B
       mov      dword ptr [rsp+0x48], edx
       mov      dword ptr [rsp+0x28], eax
       mov      rdx, rsi
       mov      r8, rdi
       mov      r9, r15
       mov      dword ptr [rsp+0x20], r13d
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:CreateInlineDefinition(byref,Lokad.Lython.Frontend.ExecutableCodeObject,Lokad.Lython.Frontend.FunctionParameterLayout,bool,int,int[],Lokad.Lython.Runtime.Text.PyString[],Lokad.Lython.Frontend.ExecutableInstruction[],bool):Lokad.Lython.Runtime.PyFunctionBase:this]
       mov      gword ptr [rbp-0x58], rax
       xor      r8d, r8d
       mov      qword ptr [rbp-0x50], r8
       lea      r8, [rbp-0x58]
       mov      rdx, rsi
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot):this]
 
G_M000_IG12:                ;; offset=0x0265
       mov      eax, 1
 
G_M000_IG13:                ;; offset=0x026A
       add      rsp, 136
       pop      rbx
       pop      rsi
       pop      rdi
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG14:                ;; offset=0x027E
       xor      eax, eax
 
G_M000_IG15:                ;; offset=0x0280
       add      rsp, 136
       pop      rbx
       pop      rsi
       pop      rdi
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG16:                ;; offset=0x0294
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
; Total bytes of code 666

; Assembly listing for method Lokad.Lython.Runtime.LythonRuntime+NativeExecution:CreateInlineDefinition(byref,Lokad.Lython.Frontend.ExecutableCodeObject,Lokad.Lython.Frontend.FunctionParameterLayout,bool,int,int[],Lokad.Lython.Runtime.Text.PyString[],Lokad.Lython.Frontend.ExecutableInstruction[],bool):Lokad.Lython.Runtime.PyFunctionBase:this (FullOpts)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; FullOpts code
; optimized code
; rbp based frame
; fully interruptible
; No PGO data
; 0 inlinees with PGO data; 19 single block inlinees; 6 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       push     r15
       push     r14
       push     r13
       push     r12
       push     rdi
       push     rsi
       push     rbx
       sub      rsp, 280
       lea      rbp, [rsp+0x150]
       vxorps   xmm4, xmm4, xmm4
       vmovdqu  ymmword ptr [rbp-0xC0], ymm4
       vmovdqu  ymmword ptr [rbp-0xA0], ymm4
       vmovdqu  ymmword ptr [rbp-0x80], ymm4
       vmovdqu  ymmword ptr [rbp-0x60], ymm4
       mov      bword ptr [rbp+0x10], rcx
       mov      rbx, rdx
       mov      rsi, r8
       mov      rdi, r9
       mov      r13d, dword ptr [rbp+0x38]
       mov      r14, gword ptr [rbp+0x40]
       mov      r15, gword ptr [rbp+0x50]
 
G_M000_IG02:                ;; offset=0x0052
       mov      edx, dword ptr [rbx+0x10]
       mov      dword ptr [rbp-0x3C], edx
       xor      r8, r8
       mov      gword ptr [rbp-0xE0], r8
 
G_M000_IG03:                ;; offset=0x0062
       mov      dword ptr [rbp-0x80], r8d
 
G_M000_IG04:                ;; offset=0x0066
       xor      r12d, r12d
 
G_M000_IG05:                ;; offset=0x0069
       test     r15, r15
       je       SHORT G_M000_IG06
       mov      r8, gword ptr [rcx+0x10]
       mov      gword ptr [rsp+0x20], r8
       mov      r8, gword ptr [rbx]
       mov      gword ptr [rsp+0x28], r8
       mov      r8, gword ptr [rcx+0x08]
       lea      rcx, [rbp-0x50]
       mov      rdx, r15
       mov      r9, rsi
       call     [Lokad.Lython.Runtime.LythonRuntime:ReadEagerFunctionAnnotations(Lokad.Lython.Frontend.ExecutableInstruction[],Lokad.Lython.Frontend.ExecutableCodeObject,Lokad.Lython.Frontend.ExecutableCodeObject,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):System.ValueTuple`3[System.Object,int,bool]]
       mov      rdx, gword ptr [rbp-0x50]
       mov      gword ptr [rbp-0xE0], rdx
       mov      edx, dword ptr [rbp-0x48]
       mov      dword ptr [rbp-0x80], edx
       movzx    r12, byte  ptr [rbp-0x44]
       mov      rcx, bword ptr [rbp+0x10]
 
G_M000_IG06:                ;; offset=0x00AD
       xor      rax, rax
       xor      r10d, r10d
       test     r15, r15
       jne      SHORT G_M000_IG09
       test     r14, r14
       je       SHORT G_M000_IG09
       mov      r8d, dword ptr [r14+0x08]
       cmp      r8d, 1
       jne      SHORT G_M000_IG09
       mov      r8d, dword ptr [r14+0x10]
       test     r8d, r8d
       jl       SHORT G_M000_IG09
       mov      r9d, r8d
       lea      r11, bword ptr [rcx+0x48]
       mov      r15d, dword ptr [r11+0x08]
       cmp      r9d, r15d
       jae      G_M000_IG20
       mov      r11, bword ptr [r11]
       shl      r9, 4
       mov      r9, gword ptr [r11+r9]
       test     r9, r9
       je       SHORT G_M000_IG08
 
G_M000_IG07:                ;; offset=0x00F3
       mov      rdx, 0x7FFA028366B0
       cmp      qword ptr [r9], rdx
       je       SHORT G_M000_IG09
 
G_M000_IG08:                ;; offset=0x0102
       mov      eax, r8d
       inc      rax
       mov      r10d, r15d
       cmp      rax, r10
       ja       G_M000_IG19
       mov      eax, r8d
       shl      rax, 4
       add      rax, r11
       mov      bword ptr [rbp-0xD0], rax
       mov      r10d, 1
       mov      rax, bword ptr [rbp-0xD0]
 
G_M000_IG09:                ;; offset=0x0132
       test     r14, r14
       jne      SHORT G_M000_IG11
 
G_M000_IG10:                ;; offset=0x0137
       mov      dword ptr [rbp-0x7C], r10d
       jmp      SHORT G_M000_IG12
 
G_M000_IG11:                ;; offset=0x013D
       mov      dword ptr [rbp-0x7C], r10d
       test     r10d, r10d
       je       SHORT G_M000_IG13
 
G_M000_IG12:                ;; offset=0x0146
       xor      r15, r15
       mov      bword ptr [rbp-0xD0], rax
       jmp      SHORT G_M000_IG16
 
G_M000_IG13:                ;; offset=0x0152
       mov      bword ptr [rbp-0xD0], rax
       mov      r8, gword ptr [rcx+0x10]
       mov      r9, gword ptr [rbx]
 
G_M000_IG14:                ;; offset=0x0160
       vmovdqu  xmm0, xmmword ptr [rcx+0x48]
       vmovdqu  xmmword ptr [rbp-0x90], xmm0
 
G_M000_IG15:                ;; offset=0x016D
       mov      r11, gword ptr [rcx+0x58]
       mov      gword ptr [rsp+0x20], r11
       mov      gword ptr [rsp+0x28], r14
       lea      r11, [rbp-0x58]
       mov      qword ptr [rsp+0x30], r11
       xor      r11, r11
       mov      gword ptr [rsp+0x38], r11
       mov      dword ptr [rsp+0x40], 1
       mov      rdx, r8
       mov      r8, r9
       lea      r9, [rbp-0x90]
       mov      rcx, rsi
       call     [Lokad.Lython.Runtime.LythonRuntime:CaptureExecutableCells(Lokad.Lython.Frontend.ExecutableCodeObject,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],Lokad.Lython.Runtime.LythonRuntime+ExecutableCaptures,int[],byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,bool):Lokad.Lython.Runtime.LythonRuntime+ExecutableCaptures]
       mov      r15, rax
 
G_M000_IG16:                ;; offset=0x01AD
       mov      rcx, bword ptr [rbp+0x10]
       mov      r14, gword ptr [rcx+0x10]
       mov      rbx, gword ptr [rbx]
       lea      rax, bword ptr [rcx+0x48]
       mov      edx, dword ptr [rbp-0x3C]
       mov      r8d, edx
       mov      r10d, r13d
       add      r8, r10
       mov      r10d, dword ptr [rax+0x08]
       cmp      r8, r10
       ja       G_M000_IG19
       mov      r8d, edx
       shl      r8, 4
       add      r8, bword ptr [rax]
       mov      bword ptr [rbp-0xD8], r8
       mov      rcx, rdi
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.FunctionParameterLayout:get_DefaultStorageCount():int:this]
       mov      dword ptr [rbp-0x5C], eax
       cmp      eax, r13d
       ja       G_M000_IG19
       mov      rcx, r14
       call     [Lokad.Lython.Runtime.LythonRuntime:GetGlobalContext(Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):Lokad.Lython.Runtime.LythonRuntime+ExecutionContext]
       mov      gword ptr [rbp-0xC8], rax
       mov      r10, bword ptr [rbp-0xD8]
       mov      bword ptr [rbp-0xA0], r10
       mov      r11d, dword ptr [rbp-0x5C]
       mov      dword ptr [rbp-0x98], r11d
       lea      r8, [rbp-0xA0]
       movzx    rdx, byte  ptr [rbp+0x58]
       mov      dword ptr [rbp-0xB4], edx
       mov      r9d, edx
       lea      rcx, [rbp-0x78]
       mov      rdx, rdi
       call     [Lokad.Lython.Runtime.LythonRuntime:ReadExecutableDefaults(Lokad.Lython.Frontend.FunctionParameterLayout,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],bool):Lokad.Lython.Runtime.FunctionDefaults]
       mov      eax, dword ptr [rbp-0x5C]
       mov      r9d, eax
       shl      r9, 4
       add      r9, bword ptr [rbp-0xD8]
       sub      r13d, eax
       lea      rcx, [rbp-0x78]
       mov      qword ptr [rsp+0x20], rcx
       movzx    rcx, byte  ptr [rbp+0x30]
       mov      dword ptr [rsp+0x28], ecx
       mov      gword ptr [rsp+0x30], r14
       mov      gword ptr [rsp+0x38], rbx
       mov      bword ptr [rbp-0xA0], r9
       mov      dword ptr [rbp-0x98], r13d
       mov      rbx, gword ptr [rbp+0x48]
       mov      gword ptr [rsp+0x48], rbx
       mov      r9, gword ptr [rbp-0xE0]
       mov      gword ptr [rbp-0xB0], r9
       mov      r9d, dword ptr [rbp-0x80]
       mov      dword ptr [rbp-0xA8], r9d
 
G_M000_IG17:                ;; offset=0x02A6
       mov      byte  ptr [rbp-0xA4], r12b
       mov      ebx, dword ptr [rbp-0xB4]
       mov      dword ptr [rsp+0x58], ebx
       mov      rbx, bword ptr [rbp-0xD0]
       mov      bword ptr [rbp-0x90], rbx
       mov      ebx, dword ptr [rbp-0x7C]
       mov      dword ptr [rbp-0x88], ebx
       lea      r9, [rbp-0xA0]
       mov      qword ptr [rsp+0x40], r9
       lea      r9, [rbp-0xB0]
       mov      qword ptr [rsp+0x50], r9
       lea      r9, [rbp-0x90]
       mov      qword ptr [rsp+0x60], r9
       mov      r9, r15
       mov      rcx, rdi
       mov      rdx, rsi
       mov      r8, gword ptr [rbp-0xC8]
       call     [Lokad.Lython.Runtime.LythonRuntime:CreateFunctionValue(Lokad.Lython.Frontend.FunctionParameterLayout,Lokad.Lython.Frontend.ExecutableCodeObject,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutableCaptures,Lokad.Lython.Runtime.FunctionDefaults,bool,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],Lokad.Lython.Runtime.Text.PyString[],System.ValueTuple`3[System.Object,int,bool],bool,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):Lokad.Lython.Runtime.PyFunctionBase]
       mov      rbx, rax
       mov      edx, dword ptr [rbp-0x5C]
       add      rdx, rdx
       mov      rcx, bword ptr [rbp-0xD8]
       call     [System.SpanHelpers:ClearWithReferences(byref,nuint)]
       xor      rax, rax
       mov      gword ptr [rbp-0xE0], rax
 
G_M000_IG18:                ;; offset=0x0327
       mov      dword ptr [rbp-0x80], eax
       mov      gword ptr [rbp-0xC0], rbx
       jmp      SHORT G_M000_IG21
 
G_M000_IG19:                ;; offset=0x0333
       call     [System.ThrowHelper:ThrowArgumentOutOfRangeException()]
       int3     
 
G_M000_IG20:                ;; offset=0x033A
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG21:                ;; offset=0x0340
       call     G_M000_IG27
       nop      
 
G_M000_IG22:                ;; offset=0x0346
       mov      rax, gword ptr [rbp-0xC0]
 
G_M000_IG23:                ;; offset=0x034D
       add      rsp, 280
       pop      rbx
       pop      rsi
       pop      rdi
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG24:                ;; offset=0x0361
       sub      rsp, 104
 
G_M000_IG25:                ;; offset=0x0365
       mov      rcx, bword ptr [rbp+0x10]
       mov      edx, dword ptr [rbp-0x3C]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Trim(int):this]
       nop      
 
G_M000_IG26:                ;; offset=0x0373
       add      rsp, 104
       ret      
 
G_M000_IG27:                ;; offset=0x0378
       sub      rsp, 104
 
G_M000_IG28:                ;; offset=0x037C
       mov      rcx, bword ptr [rbp+0x10]
       mov      rax, gword ptr [rcx+0x10]
       cmp      gword ptr [rbp-0xE0], 0
       je       SHORT G_M000_IG30
       mov      rax, gword ptr [rax+0xA0]
       mov      rbx, gword ptr [rax+0x88]
       mov      ecx, dword ptr [rbp-0x80]
       call     [Lokad.Lython.Runtime.PyDict+RecordKeys:RecordBytes(int):long]
       mov      rdx, rax
       add      rdx, 160
       jo       SHORT G_M000_IG29
       mov      rcx, rbx
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.MemoryGovernor:ReleaseReserved(long):this]
       jmp      SHORT G_M000_IG30
 
G_M000_IG29:                ;; offset=0x03BE
       call     CORINFO_HELP_OVERFLOW
       int3     
 
G_M000_IG30:                ;; offset=0x03C4
       call     G_M000_IG24
       nop      
 
G_M000_IG31:                ;; offset=0x03CA
       add      rsp, 104
       ret      
 
; Total bytes of code 975

