; Assembly listing for method Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecutePreparedOperation(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,bool,byref):bool (FullOpts)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; FullOpts code
; optimized code
; rbp based frame
; fully interruptible
; No PGO data
; 0 inlinees with PGO data; 151 single block inlinees; 49 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       push     r15
       push     r14
       push     r13
       push     r12
       push     rdi
       push     rsi
       push     rbx
       sub      rsp, 296
       lea      rbp, [rsp+0x160]
       vxorps   xmm4, xmm4, xmm4
       vmovdqa  xmmword ptr [rbp-0x110], xmm4
       mov      rax, -192
 
G_M000_IG169:                ;; offset=0x0031
       vmovdqa  xmmword ptr [rbp+rax-0x40], xmm4
       vmovdqa  xmmword ptr [rbp+rax-0x30], xmm4
       vmovdqa  xmmword ptr [rbp+rax-0x20], xmm4
       add      rax, 48
       jne      SHORT G_M000_IG169
       mov      bword ptr [rbp+0x10], rcx
       mov      bword ptr [rbp+0x28], r9
       mov      rsi, rdx
       mov      rbx, r8
       mov      r14d, dword ptr [rbp+0x30]
       mov      rdi, bword ptr [rbp+0x38]
 
G_M000_IG02:                ;; offset=0x005F
       xor      eax, eax
       mov      qword ptr [rdi], rax
       mov      qword ptr [rdi+0x08], rax
       mov      r15, rbx
       test     r15, r15
       cmove    r15, rsi
       mov      rax, gword ptr [rcx]
       mov      r13, gword ptr [rax+0x30]
       mov      rcx, r9
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ConstantIndex():int:this]
       cmp      eax, dword ptr [r13+0x08]
       jae      G_M000_IG157
       mov      edx, eax
       mov      rdx, gword ptr [r13+8*rdx+0x10]
       mov      rcx, 0x7FFA02720290
       call     CORINFO_HELP_CHKCASTCLASS
       mov      r13, rax
       mov      rcx, bword ptr [rbp+0x28]
       mov      r12, gword ptr [rcx]
       test     r13, r13
       je       G_M000_IG51
 
G_M000_IG03:                ;; offset=0x00B5
       mov      rax, qword ptr [r13]
       mov      rdx, 0x7FFA02763778
       cmp      rax, rdx
       jne      G_M000_IG51
 
G_M000_IG04:                ;; offset=0x00CC
       test     rbx, rbx
       je       G_M000_IG149
       mov      r14, bword ptr [rbp+0x10]
       add      r14, 32
       mov      rdi, r14
       mov      esi, dword ptr [rcx+0x10]
       mov      eax, dword ptr [rcx+0x1C]
       cmp      eax, 51
       ja       SHORT G_M000_IG09
 
G_M000_IG05:                ;; offset=0x00EB
       mov      rdx, 0x7FFFFFFFFF9FF
       bt       rdx, rax
       jb       SHORT G_M000_IG09
 
G_M000_IG06:                ;; offset=0x00FB
       mov      eax, dword ptr [rcx+0x18]
       test     eax, eax
       jge      SHORT G_M000_IG07
       mov      edx, eax
       not      edx
       jmp      SHORT G_M000_IG08
 
G_M000_IG07:                ;; offset=0x0108
       mov      edx, eax
 
G_M000_IG08:                ;; offset=0x010A
       mov      eax, edx
       mov      dword ptr [rbp-0xBC], eax
       jmp      SHORT G_M000_IG10
 
G_M000_IG09:                ;; offset=0x0114
       mov      eax, dword ptr [rcx+0x14]
       mov      dword ptr [rbp-0xBC], eax
 
G_M000_IG10:                ;; offset=0x011D
       mov      rdx, gword ptr [rdi]
       cmp      esi, dword ptr [rdx+0x08]
       jae      G_M000_IG157
       mov      r8d, esi
       shl      r8, 4
       lea      rcx, bword ptr [rdx+r8+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Object():System.Object:this]
       mov      rdx, rax
       mov      rcx, 0x7FFA02827D30
       call     [Lokad.Lython.Internal.NullabilityExtensions:RequireNotNull[System.__Canon](System.__Canon):System.__Canon]
       mov      gword ptr [rbp-0x128], rax
       mov      rcx, gword ptr [rdi]
       cmp      esi, dword ptr [rcx+0x08]
       jae      G_M000_IG157
       mov      edx, esi
       shl      rdx, 4
       lea      rcx, bword ptr [rcx+rdx+0x10]
       xor      rdx, rdx
       mov      gword ptr [rcx], rdx
 
G_M000_IG11:                ;; offset=0x0171
       mov      qword ptr [rcx+0x08], rdx
       mov      esi, dword ptr [rbp-0xBC]
       mov      dword ptr [rdi+0x40], esi
       mov      rsi, gword ptr [r13+0x08]
       mov      rcx, 0x7FFA02826D80
       call     CORINFO_HELP_NEWSFAST
       mov      rdi, rax
       mov      rcx, rdi
       mov      rdx, rbx
       mov      r8, rsi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext+InlinedComprehensionScope:.ctor(Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Frontend.ScopeDirectiveFacts):this]
       mov      gword ptr [rbp-0x120], rdi
       xor      ecx, ecx
       mov      dword ptr [rbp-0x40], ecx
 
G_M000_IG12:                ;; offset=0x01AF
       mov      esi, dword ptr [r13+0x10]
       cmp      esi, 2
       jne      G_M000_IG13
       mov      rsi, gword ptr [r15+0xA0]
       mov      rcx, 0x7FFA0284CFC0
       call     CORINFO_HELP_NEWSFAST
       mov      r13, rax
       mov      r15, gword ptr [rsi+0x88]
       mov      rcx, 0x7FFA02724750
       call     CORINFO_HELP_NEWSFAST
       mov      rbx, rax
       lea      rcx, bword ptr [rbx+0x10]
       mov      rdx, r15
       call     CORINFO_HELP_ASSIGN_REF
       lea      rcx, bword ptr [rbx+0x18]
       mov      rdx, r12
       call     CORINFO_HELP_ASSIGN_REF
       mov      byte  ptr [rbx+0x54], 1
       mov      rcx, rbx
       mov      r9, r12
       mov      r8, r15
       xor      edx, edx
       call     [Lokad.Lython.Runtime.PyDict:InitializeNativeStorage(int,Lokad.Lython.Runtime.MemoryGovernor,Lokad.Lython.LythonSourceSpan):this]
       lea      rcx, bword ptr [rbx+0x08]
       mov      rdx, rbx
       call     CORINFO_HELP_ASSIGN_REF
       lea      rcx, bword ptr [r13+0x08]
       mov      rdx, rbx
       call     CORINFO_HELP_ASSIGN_REF
       jmp      G_M000_IG16
 
G_M000_IG13:                ;; offset=0x0238
       cmp      esi, 3
       jne      SHORT G_M000_IG14
       mov      r13, gword ptr [r15+0xA0]
       mov      rcx, 0x7FFA02724750
       call     CORINFO_HELP_NEWSFAST
       mov      r15, rax
       mov      rsi, gword ptr [r13+0x88]
       lea      rcx, bword ptr [r15+0x10]
       mov      rdx, rsi
       call     CORINFO_HELP_ASSIGN_REF
       lea      rcx, bword ptr [r15+0x18]
       mov      rdx, r12
       call     CORINFO_HELP_ASSIGN_REF
       mov      byte  ptr [r15+0x54], 0
       mov      rcx, r15
       mov      r9, r12
       mov      r8, rsi
       xor      edx, edx
       call     [Lokad.Lython.Runtime.PyDict:InitializeNativeStorage(int,Lokad.Lython.Runtime.MemoryGovernor,Lokad.Lython.LythonSourceSpan):this]
       lea      rcx, bword ptr [r15+0x08]
       mov      rdx, r15
       call     CORINFO_HELP_ASSIGN_REF
       mov      r13, r15
       jmp      SHORT G_M000_IG16
 
G_M000_IG14:                ;; offset=0x029C
       test     byte  ptr [(reloc 0x7ffa0284e150)], 1
       je       G_M000_IG49
 
G_M000_IG15:                ;; offset=0x02A9
       mov      rcx, 0x2C6B3801D50
       mov      r13, gword ptr [rcx]
       mov      r15, gword ptr [r15+0xA0]
       mov      rcx, 0x7FFA0282DFF0
       call     CORINFO_HELP_NEWSFAST
       mov      rbx, rax
       mov      r8, gword ptr [r15+0x88]
       mov      rcx, rbx
       mov      rdx, r13
       mov      r9, r12
       call     [Lokad.Lython.Runtime.PyList:.ctor(System.Collections.Generic.IEnumerable`1[System.Object],Lokad.Lython.Runtime.MemoryGovernor,Lokad.Lython.LythonSourceSpan):this]
       mov      r13, rbx
 
G_M000_IG16:                ;; offset=0x02E8
       mov      r12, r14
       mov      rcx, bword ptr [rbp+0x28]
       mov      edx, dword ptr [rcx+0x1C]
       mov      eax, edx
       cmp      eax, 51
       ja       SHORT G_M000_IG20
 
G_M000_IG17:                ;; offset=0x02F9
       mov      r8, 0x7FFFFFFFFF9FF
       bt       r8, rax
       jb       SHORT G_M000_IG20
 
G_M000_IG18:                ;; offset=0x0309
       mov      ebx, dword ptr [rcx+0x18]
       test     ebx, ebx
       jge      SHORT G_M000_IG19
       not      ebx
 
G_M000_IG19:                ;; offset=0x0312
       jmp      SHORT G_M000_IG21
 
G_M000_IG20:                ;; offset=0x0314
       mov      ebx, dword ptr [rcx+0x14]
 
G_M000_IG21:                ;; offset=0x0317
       cmp      edx, 51
       ja       SHORT G_M000_IG26
 
G_M000_IG22:                ;; offset=0x031C
       mov      rax, 0x7FFFFFFFFF9FF
       bt       rax, rdx
       jb       SHORT G_M000_IG26
 
G_M000_IG23:                ;; offset=0x032C
       mov      edx, dword ptr [rcx+0x18]
       test     edx, edx
       jge      SHORT G_M000_IG24
       mov      esi, edx
       not      esi
       jmp      SHORT G_M000_IG25
 
G_M000_IG24:                ;; offset=0x0339
       mov      esi, edx
 
G_M000_IG25:                ;; offset=0x033B
       jmp      SHORT G_M000_IG27
 
G_M000_IG26:                ;; offset=0x033D
       mov      esi, dword ptr [rcx+0x14]
 
G_M000_IG27:                ;; offset=0x0340
       inc      esi
       cmp      esi, dword ptr [r12+0x40]
       jge      SHORT G_M000_IG28
       mov      rcx, r12
       mov      edx, esi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
 
G_M000_IG28:                ;; offset=0x0354
       mov      rdx, gword ptr [r12]
       cmp      ebx, dword ptr [rdx+0x08]
       jae      G_M000_IG50
       mov      eax, ebx
       shl      rax, 4
       lea      rbx, bword ptr [rdx+rax+0x10]
       mov      rcx, rbx
       mov      rdx, rdi
       call     CORINFO_HELP_ASSIGN_REF
       xor      ecx, ecx
       mov      qword ptr [rbx+0x08], rcx
       mov      dword ptr [r12+0x40], esi
       mov      dword ptr [rbp-0x40], 1
       mov      rbx, r14
       mov      rcx, bword ptr [rbp+0x28]
       mov      edx, dword ptr [rcx+0x1C]
       mov      eax, edx
       cmp      eax, 51
       ja       SHORT G_M000_IG32
 
G_M000_IG29:                ;; offset=0x039A
       mov      r8, 0x7FFFFFFFFF9FF
       bt       r8, rax
       jb       SHORT G_M000_IG32
 
G_M000_IG30:                ;; offset=0x03AA
       mov      esi, dword ptr [rcx+0x18]
       test     esi, esi
       jge      SHORT G_M000_IG31
       not      esi
 
G_M000_IG31:                ;; offset=0x03B3
       jmp      SHORT G_M000_IG33
 
G_M000_IG32:                ;; offset=0x03B5
       mov      esi, dword ptr [rcx+0x14]
 
G_M000_IG33:                ;; offset=0x03B8
       inc      esi
       cmp      edx, 51
       ja       SHORT G_M000_IG38
 
G_M000_IG34:                ;; offset=0x03BF
       mov      rax, 0x7FFFFFFFFF9FF
       bt       rax, rdx
       jb       SHORT G_M000_IG38
 
G_M000_IG35:                ;; offset=0x03CF
       mov      edx, dword ptr [rcx+0x18]
       test     edx, edx
       jge      SHORT G_M000_IG36
       mov      edi, edx
       not      edi
       jmp      SHORT G_M000_IG37
 
G_M000_IG36:                ;; offset=0x03DC
       mov      edi, edx
 
G_M000_IG37:                ;; offset=0x03DE
       jmp      SHORT G_M000_IG39
 
G_M000_IG38:                ;; offset=0x03E0
       mov      edi, dword ptr [rcx+0x14]
 
G_M000_IG39:                ;; offset=0x03E3
       add      edi, 2
       cmp      edi, dword ptr [rbx+0x40]
       jge      SHORT G_M000_IG40
       mov      rcx, rbx
       mov      edx, edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
 
G_M000_IG40:                ;; offset=0x03F6
       mov      rdx, gword ptr [rbx]
       cmp      esi, dword ptr [rdx+0x08]
       jae      G_M000_IG50
       mov      eax, esi
       shl      rax, 4
       lea      rsi, bword ptr [rdx+rax+0x10]
       mov      rcx, rsi
       mov      rdx, r13
       call     CORINFO_HELP_ASSIGN_REF
       xor      ecx, ecx
       mov      qword ptr [rsi+0x08], rcx
       mov      dword ptr [rbx+0x40], edi
       mov      rcx, bword ptr [rbp+0x28]
       mov      edx, dword ptr [rcx+0x1C]
       cmp      edx, 51
       ja       SHORT G_M000_IG44
 
G_M000_IG41:                ;; offset=0x042D
       mov      rax, 0x7FFFFFFFFF9FF
       bt       rax, rdx
       jb       SHORT G_M000_IG44
 
G_M000_IG42:                ;; offset=0x043D
       mov      ebx, dword ptr [rcx+0x18]
       test     ebx, ebx
       jge      SHORT G_M000_IG43
       not      ebx
 
G_M000_IG43:                ;; offset=0x0446
       jmp      SHORT G_M000_IG45
 
G_M000_IG44:                ;; offset=0x0448
       mov      ebx, dword ptr [rcx+0x14]
 
G_M000_IG45:                ;; offset=0x044B
       add      ebx, 2
       mov      ecx, dword ptr [rcx+0x18]
       test     ecx, ecx
       jge      SHORT G_M000_IG46
       mov      esi, ecx
       not      esi
       jmp      SHORT G_M000_IG47
 
G_M000_IG46:                ;; offset=0x045B
       mov      esi, ecx
 
G_M000_IG47:                ;; offset=0x045D
       cmp      esi, dword ptr [r14+0x40]
       jge      SHORT G_M000_IG48
       mov      rcx, r14
       mov      edx, esi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
 
G_M000_IG48:                ;; offset=0x046E
       mov      rcx, gword ptr [r14]
       cmp      ebx, dword ptr [rcx+0x08]
       jae      SHORT G_M000_IG50
       mov      edx, ebx
       shl      rdx, 4
       lea      rbx, bword ptr [rcx+rdx+0x10]
       mov      rdx, gword ptr [rbp-0x128]
       mov      rcx, rbx
       call     CORINFO_HELP_ASSIGN_REF
       xor      ecx, ecx
       mov      qword ptr [rbx+0x08], rcx
       mov      dword ptr [r14+0x40], esi
       jmp      G_M000_IG146
 
G_M000_IG49:                ;; offset=0x049F
       mov      rcx, 0x7FFA0284E0B8
       call     CORINFO_HELP_GET_GCSTATIC_BASE
       jmp      G_M000_IG15
 
G_M000_IG50:                ;; offset=0x04B3
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG51:                ;; offset=0x04B9
       test     r13, r13
       je       G_M000_IG72
 
G_M000_IG52:                ;; offset=0x04C2
       mov      rax, qword ptr [r13]
       mov      rdx, 0x7FFA02796FF8
       cmp      rax, rdx
       jne      G_M000_IG60
 
G_M000_IG53:                ;; offset=0x04D9
       test     rbx, rbx
       je       G_M000_IG149
       mov      r8d, dword ptr [rcx+0x10]
       inc      r8d
       mov      edx, r8d
       mov      r14, bword ptr [rbp+0x10]
       lea      rax, bword ptr [r14+0x20]
       mov      rsi, rax
       mov      rcx, rsi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:TakeValue(int,int):System.Object:this]
       mov      r13, rax
       mov      rcx, bword ptr [rbp+0x28]
       mov      r8d, dword ptr [rcx+0x10]
       mov      edx, r8d
       mov      rcx, rsi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:TakeValue(int,int):System.Object:this]
       mov      rdx, rax
       mov      rcx, 0x7FFA0281C9E0
       call     CORINFO_HELP_CHKCASTCLASS
       mov      rcx, rax
       mov      rax, qword ptr [rax]
       mov      rax, qword ptr [rax+0x40]
       call     [rax+0x20]Lokad.Lython.Runtime.ExecutableTemporaryValue:Dispose():this
       mov      rcx, bword ptr [rbp+0x28]
       mov      r15d, dword ptr [rcx+0x18]
       test     r15d, r15d
       jge      SHORT G_M000_IG54
       mov      gword ptr [rbp-0xE0], r13
       xor      r9d, r9d
       mov      qword ptr [rbp-0xD8], r9
       lea      r9, [rbp-0xE0]
       mov      rdx, rbx
       mov      r8, rcx
       mov      rcx, r14
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CompleteResultConsumer(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot)]
       jmp      G_M000_IG146
 
G_M000_IG54:                ;; offset=0x056F
       mov      rbx, rsi
       mov      edx, dword ptr [rcx+0x1C]
       cmp      edx, 51
       ja       SHORT G_M000_IG57
 
G_M000_IG55:                ;; offset=0x057A
       mov      rax, 0x7FFFFFFFFF9FF
       bt       rax, rdx
       jb       SHORT G_M000_IG57
 
G_M000_IG56:                ;; offset=0x058A
       mov      r12d, r15d
       jmp      SHORT G_M000_IG58
 
G_M000_IG57:                ;; offset=0x058F
       mov      r12d, dword ptr [rcx+0x14]
 
G_M000_IG58:                ;; offset=0x0593
       cmp      r15d, dword ptr [rbx+0x40]
       jge      SHORT G_M000_IG59
       mov      rcx, rbx
       mov      edx, r15d
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
 
G_M000_IG59:                ;; offset=0x05A5
       mov      rcx, gword ptr [rbx]
       cmp      r12d, dword ptr [rcx+0x08]
       jae      G_M000_IG157
       mov      edx, r12d
       shl      rdx, 4
       lea      r14, bword ptr [rcx+rdx+0x10]
       mov      rcx, r14
       mov      rdx, r13
       call     CORINFO_HELP_ASSIGN_REF
       xor      ecx, ecx
       mov      qword ptr [r14+0x08], rcx
       mov      dword ptr [rbx+0x40], r15d
       jmp      G_M000_IG146
 
G_M000_IG60:                ;; offset=0x05D8
       mov      rdx, 0x7FFA02796C88
       cmp      rax, rdx
       jne      G_M000_IG72
 
G_M000_IG61:                ;; offset=0x05EB
       mov      rax, r13
       test     rbx, rbx
       je       G_M000_IG149
       mov      esi, dword ptr [rax+0x08]
       cmp      esi, 2
       jne      G_M000_IG62
       mov      rsi, gword ptr [r15+0xA0]
       mov      rcx, 0x7FFA0284CFC0
       call     CORINFO_HELP_NEWSFAST
       mov      r13, rax
       mov      r15, gword ptr [rsi+0x88]
       mov      rcx, 0x7FFA02724750
       call     CORINFO_HELP_NEWSFAST
       mov      r14, rax
       lea      rcx, bword ptr [r14+0x10]
       mov      rdx, r15
       call     CORINFO_HELP_ASSIGN_REF
       lea      rcx, bword ptr [r14+0x18]
       mov      rdx, r12
       call     CORINFO_HELP_ASSIGN_REF
       mov      byte  ptr [r14+0x54], 1
       mov      rcx, r14
       mov      r9, r12
       mov      r8, r15
       xor      edx, edx
       call     [Lokad.Lython.Runtime.PyDict:InitializeNativeStorage(int,Lokad.Lython.Runtime.MemoryGovernor,Lokad.Lython.LythonSourceSpan):this]
       lea      rcx, bword ptr [r14+0x08]
       mov      rdx, r14
       call     CORINFO_HELP_ASSIGN_REF
       lea      rcx, bword ptr [r13+0x08]
       mov      rdx, r14
       call     CORINFO_HELP_ASSIGN_REF
       jmp      G_M000_IG65
 
G_M000_IG62:                ;; offset=0x0680
       cmp      esi, 3
       jne      SHORT G_M000_IG63
       mov      r13, gword ptr [r15+0xA0]
       mov      rcx, 0x7FFA02724750
       call     CORINFO_HELP_NEWSFAST
       mov      r15, rax
       mov      rdi, gword ptr [r13+0x88]
       lea      rcx, bword ptr [r15+0x10]
       mov      rdx, rdi
       call     CORINFO_HELP_ASSIGN_REF
       lea      rcx, bword ptr [r15+0x18]
       mov      rdx, r12
       call     CORINFO_HELP_ASSIGN_REF
       mov      byte  ptr [r15+0x54], 0
       mov      rcx, r15
       mov      r9, r12
       mov      r8, rdi
       xor      edx, edx
       call     [Lokad.Lython.Runtime.PyDict:InitializeNativeStorage(int,Lokad.Lython.Runtime.MemoryGovernor,Lokad.Lython.LythonSourceSpan):this]
       lea      rcx, bword ptr [r15+0x08]
       mov      rdx, r15
       call     CORINFO_HELP_ASSIGN_REF
       mov      r13, r15
       jmp      SHORT G_M000_IG65
 
G_M000_IG63:                ;; offset=0x06E4
       test     byte  ptr [(reloc 0x7ffa0284e150)], 1
       je       G_M000_IG153
 
G_M000_IG64:                ;; offset=0x06F1
       mov      rax, 0x2C6B3801D50
       mov      r13, gword ptr [rax]
       mov      r15, gword ptr [r15+0xA0]
       mov      rcx, 0x7FFA0282DFF0
       call     CORINFO_HELP_NEWSFAST
       mov      rsi, rax
       mov      r8, gword ptr [r15+0x88]
       mov      rcx, rsi
       mov      rdx, r13
       mov      r9, r12
       call     [Lokad.Lython.Runtime.PyList:.ctor(System.Collections.Generic.IEnumerable`1[System.Object],Lokad.Lython.Runtime.MemoryGovernor,Lokad.Lython.LythonSourceSpan):this]
       mov      r13, rsi
 
G_M000_IG65:                ;; offset=0x0730
       mov      rcx, bword ptr [rbp+0x28]
       mov      r12d, dword ptr [rcx+0x18]
       test     r12d, r12d
       jge      SHORT G_M000_IG66
       mov      gword ptr [rbp-0xE0], r13
       xor      r9d, r9d
       mov      qword ptr [rbp-0xD8], r9
       lea      r9, [rbp-0xE0]
       mov      rdx, rbx
       mov      r8, rcx
       mov      rcx, bword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CompleteResultConsumer(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot)]
       jmp      G_M000_IG146
 
G_M000_IG66:                ;; offset=0x076A
       mov      r14, bword ptr [rbp+0x10]
       lea      rsi, bword ptr [r14+0x20]
       mov      rbx, rsi
       mov      edx, dword ptr [rcx+0x1C]
       cmp      edx, 51
       ja       SHORT G_M000_IG69
 
G_M000_IG67:                ;; offset=0x077D
       mov      rax, 0x7FFFFFFFFF9FF
       bt       rax, rdx
       jb       SHORT G_M000_IG69
 
G_M000_IG68:                ;; offset=0x078D
       mov      r14d, r12d
       jmp      SHORT G_M000_IG70
 
G_M000_IG69:                ;; offset=0x0792
       mov      r14d, dword ptr [rcx+0x14]
 
G_M000_IG70:                ;; offset=0x0796
       cmp      r12d, dword ptr [rbx+0x40]
       jge      SHORT G_M000_IG71
       mov      rcx, rbx
       mov      edx, r12d
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
 
G_M000_IG71:                ;; offset=0x07A8
       mov      rcx, gword ptr [rbx]
       cmp      r14d, dword ptr [rcx+0x08]
       jae      G_M000_IG157
       mov      edx, r14d
       shl      rdx, 4
       lea      rsi, bword ptr [rcx+rdx+0x10]
       mov      rcx, rsi
       mov      rdx, r13
       call     CORINFO_HELP_ASSIGN_REF
       xor      ecx, ecx
       mov      qword ptr [rsi+0x08], rcx
       mov      dword ptr [rbx+0x40], r12d
       jmp      G_M000_IG146
 
G_M000_IG72:                ;; offset=0x07DB
       test     r13, r13
       je       G_M000_IG97
 
G_M000_IG73:                ;; offset=0x07E4
       mov      rax, qword ptr [r13]
       mov      rdx, 0x7FFA02797370
       cmp      rax, rdx
       jne      G_M000_IG93
 
G_M000_IG74:                ;; offset=0x07FB
       test     rbx, rbx
       je       G_M000_IG149
       mov      r14, bword ptr [rbp+0x10]
       lea      rsi, bword ptr [r14+0x20]
       mov      rdx, rsi
       mov      r8d, dword ptr [rcx+0x10]
       mov      eax, dword ptr [rcx+0x1C]
       cmp      eax, 51
       ja       SHORT G_M000_IG79
 
G_M000_IG75:                ;; offset=0x081B
       mov      r10, 0x7FFFFFFFFF9FF
       bt       r10, rax
       jb       SHORT G_M000_IG79
 
G_M000_IG76:                ;; offset=0x082B
       mov      eax, dword ptr [rcx+0x18]
       test     eax, eax
       jge      SHORT G_M000_IG77
       mov      r10d, eax
       not      r10d
       jmp      SHORT G_M000_IG78
 
G_M000_IG77:                ;; offset=0x083A
       mov      r10d, eax
 
G_M000_IG78:                ;; offset=0x083D
       jmp      SHORT G_M000_IG80
 
G_M000_IG79:                ;; offset=0x083F
       mov      r10d, dword ptr [rcx+0x14]
 
G_M000_IG80:                ;; offset=0x0843
       mov      rcx, rdx
       mov      edx, r8d
       mov      r8d, r10d
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:TakeValue(int,int):System.Object:this]
       mov      r13, rax
       test     r13, r13
       je       SHORT G_M000_IG82
 
G_M000_IG81:                ;; offset=0x085A
       mov      rcx, 0x7FFA0282DFF0
       cmp      qword ptr [r13], rcx
       jne      G_M000_IG154
 
G_M000_IG82:                ;; offset=0x086E
       cmp      dword ptr [r13+0x28], 0
       jne      SHORT G_M000_IG84
       test     byte  ptr [(reloc 0x7ffa027881c8)], 1
       je       G_M000_IG155
 
G_M000_IG83:                ;; offset=0x0882
       mov      rcx, 0x2C6B38015F0
       mov      rdi, gword ptr [rcx]
       jmp      SHORT G_M000_IG86
 
G_M000_IG84:                ;; offset=0x0891
       mov      rdi, gword ptr [r15+0xA0]
       mov      rcx, 0x7FFA02788050
       call     CORINFO_HELP_NEWSFAST
       mov      r15, rax
       mov      rdi, gword ptr [rdi+0x88]
       lea      rcx, bword ptr [r15+0x10]
       mov      rdx, rdi
       call     CORINFO_HELP_ASSIGN_REF
       lea      rcx, bword ptr [r15+0x18]
       mov      rdx, r12
       call     CORINFO_HELP_ASSIGN_REF
       lea      r9, bword ptr [r15+0x20]
       xor      ecx, ecx
       xor      edx, edx
       mov      byte  ptr [rsp+0x20], cl
       mov      dword ptr [rsp+0x24], edx
 
G_M000_IG85:                ;; offset=0x08D9
       mov      gword ptr [rsp+0x28], rcx
       mov      rcx, r13
       mov      rdx, rdi
       mov      r8, r12
       call     [Lokad.Lython.Runtime.PyTuple:MaterializeGovernedItems(System.Collections.Generic.IEnumerable`1[System.Object],Lokad.Lython.Runtime.MemoryGovernor,Lokad.Lython.LythonSourceSpan,byref,System.Nullable`1[int],Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):System.Object[]]
       mov      rdx, rax
       lea      rcx, bword ptr [r15+0x08]
       call     CORINFO_HELP_ASSIGN_REF
       mov      rdi, r15
 
G_M000_IG86:                ;; offset=0x08FC
       mov      rcx, bword ptr [rbp+0x28]
       mov      r12d, dword ptr [rcx+0x18]
       test     r12d, r12d
       jge      SHORT G_M000_IG87
       mov      gword ptr [rbp-0xE0], rdi
       xor      r9d, r9d
       mov      qword ptr [rbp-0xD8], r9
       lea      r9, [rbp-0xE0]
       mov      rdx, rbx
       mov      r8, rcx
       mov      rcx, r14
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CompleteResultConsumer(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot)]
       jmp      G_M000_IG146
 
G_M000_IG87:                ;; offset=0x0935
       mov      rbx, rsi
       mov      edx, dword ptr [rcx+0x1C]
       cmp      edx, 51
       ja       SHORT G_M000_IG90
 
G_M000_IG88:                ;; offset=0x0940
       mov      rax, 0x7FFFFFFFFF9FF
       bt       rax, rdx
       jb       SHORT G_M000_IG90
 
G_M000_IG89:                ;; offset=0x0950
       mov      r14d, r12d
       jmp      SHORT G_M000_IG91
 
G_M000_IG90:                ;; offset=0x0955
       mov      r14d, dword ptr [rcx+0x14]
 
G_M000_IG91:                ;; offset=0x0959
       cmp      r12d, dword ptr [rbx+0x40]
       jge      SHORT G_M000_IG92
       mov      rcx, rbx
       mov      edx, r12d
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
 
G_M000_IG92:                ;; offset=0x096B
       mov      rcx, gword ptr [rbx]
       cmp      r14d, dword ptr [rcx+0x08]
       jae      G_M000_IG157
       mov      edx, r14d
       shl      rdx, 4
       lea      rsi, bword ptr [rcx+rdx+0x10]
       mov      rcx, rsi
       mov      rdx, rdi
       call     CORINFO_HELP_ASSIGN_REF
       xor      edx, edx
       mov      qword ptr [rsi+0x08], rdx
       mov      dword ptr [rbx+0x40], r12d
       jmp      G_M000_IG146
 
G_M000_IG93:                ;; offset=0x099E
       mov      rdx, 0x7FFA02763BB0
       cmp      rax, rdx
       jne      G_M000_IG97
 
G_M000_IG94:                ;; offset=0x09B1
       test     rbx, rbx
       je       G_M000_IG149
       mov      edx, dword ptr [rcx+0x10]
       mov      dword ptr [rbp-0x3C], edx
 
G_M000_IG95:                ;; offset=0x09C0
       mov      r14, bword ptr [rbp+0x10]
       lea      rsi, bword ptr [r14+0x20]
       mov      ebx, dword ptr [r13+0x08]
       mov      rcx, gword ptr [r14+0x20]
       mov      edx, dword ptr [rbp-0x3C]
       cmp      edx, dword ptr [rcx+0x08]
       jae      G_M000_IG96
       mov      eax, edx
       shl      rax, 4
       lea      rcx, bword ptr [rcx+rax+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Object():System.Object:this]
       mov      rdx, rax
       mov      rcx, 0x7FFA02827D30
       call     [Lokad.Lython.Internal.NullabilityExtensions:RequireNotNull[System.__Canon](System.__Canon):System.__Canon]
       mov      rdi, rax
       mov      rcx, 0x7FFA0284D610
       call     CORINFO_HELP_NEWSFAST
       mov      r12, rax
       movzx    rcx, byte  ptr [r13+0x0C]
       mov      dword ptr [rsp+0x20], ecx
       xor      rcx, rcx
       mov      gword ptr [rsp+0x28], rcx
       mov      rcx, r12
       mov      edx, ebx
       mov      r8, r15
       mov      r9, rdi
       call     [Lokad.Lython.Runtime.Calls.CallExpansion+CallArgumentAccumulator:.ctor(int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,System.Object,bool,Lokad.Lython.Runtime.MemoryGovernor+TemporaryMemoryReservation):this]
       mov      rcx, gword ptr [rsi]
       mov      edx, dword ptr [rbp-0x3C]
       cmp      edx, dword ptr [rcx+0x08]
       jae      SHORT G_M000_IG96
       mov      eax, edx
       shl      rax, 4
       lea      r15, bword ptr [rcx+rax+0x10]
       mov      rcx, r15
       mov      rdx, r12
       call     CORINFO_HELP_ASSIGN_REF
       xor      ecx, ecx
       mov      qword ptr [r15+0x08], rcx
       jmp      G_M000_IG146
 
G_M000_IG96:                ;; offset=0x0A62
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG97:                ;; offset=0x0A68
       test     r13, r13
       je       G_M000_IG104
 
G_M000_IG98:                ;; offset=0x0A71
       mov      rax, qword ptr [r13]
       mov      r9, 0x7FFA02765950
       cmp      rax, r9
       je       SHORT G_M000_IG99
       mov      r9, 0x7FFA02765D88
       cmp      rax, r9
       je       SHORT G_M000_IG99
       mov      r9, 0x7FFA02766188
       cmp      rax, r9
       je       SHORT G_M000_IG99
       mov      r9, 0x7FFA02797778
       cmp      rax, r9
       je       SHORT G_M000_IG99
       mov      r9, 0x7FFA02797C68
       cmp      rax, r9
       je       SHORT G_M000_IG99
       mov      r9, 0x7FFA02746190
       cmp      rax, r9
       jne      SHORT G_M000_IG102
 
G_M000_IG99:                ;; offset=0x0ACF
       test     rbx, rbx
       je       G_M000_IG149
 
G_M000_IG100:                ;; offset=0x0AD8
       vmovdqu  ymm0, ymmword ptr [rcx]
       vmovdqu  ymmword ptr [rbp-0x100], ymm0
 
G_M000_IG101:                ;; offset=0x0AE4
       movzx    r9, r14b
       mov      dword ptr [rsp+0x20], r9d
       lea      r9, [rbp-0x100]
       lea      rdx, [rbp-0x70]
       mov      r8, r13
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecutePreparedSuspendingOperationAsync(Lokad.Lython.Frontend.ExecutableOperation,Lokad.Lython.Frontend.ExecutableInstruction,bool):System.Threading.Tasks.ValueTask:this]
       mov      rdx, gword ptr [rbp-0x70]
       mov      rcx, rdi
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rcx, qword ptr [rbp-0x68]
       mov      qword ptr [rdi+0x08], rcx
       jmp      G_M000_IG146
 
G_M000_IG102:                ;; offset=0x0B1D
       mov      rdx, 0x7FFA027205A0
       cmp      rax, rdx
       jne      SHORT G_M000_IG104
 
G_M000_IG103:                ;; offset=0x0B2C
       mov      rcx, r13
       test     rbx, rbx
       je       G_M000_IG149
       mov      rcx, gword ptr [rcx+0x08]
       mov      rdx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime:ExecuteTypeAlias(Lokad.Lython.Frontend.LoweredTypeAlias,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext)]
       mov      r14, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [r14]
       mov      rdx, gword ptr [r14+0x08]
       mov      r8, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime:SyncExecutableLocalsFromContext(Lokad.Lython.Frontend.ExecutableCodeObject,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot[],Lokad.Lython.Runtime.LythonRuntime+ExecutionContext)]
       jmp      G_M000_IG146
 
G_M000_IG104:                ;; offset=0x0B5E
       test     r13, r13
       je       G_M000_IG109
 
G_M000_IG105:                ;; offset=0x0B67
       mov      rax, qword ptr [r13]
       mov      rdx, 0x7FFA02798068
       cmp      rax, rdx
       jne      G_M000_IG109
 
G_M000_IG106:                ;; offset=0x0B7E
       test     rbx, rbx
       je       G_M000_IG149
       mov      rsi, bword ptr [rbp+0x10]
       add      rsi, 32
       mov      rdx, rsi
       mov      r8d, dword ptr [rcx+0x10]
       mov      eax, dword ptr [rcx+0x18]
       test     eax, eax
       jge      SHORT G_M000_IG107
       mov      r10d, eax
       not      r10d
       jmp      SHORT G_M000_IG108
 
G_M000_IG107:                ;; offset=0x0BA5
       mov      r10d, eax
 
G_M000_IG108:                ;; offset=0x0BA8
       mov      rcx, rdx
       mov      edx, r8d
       mov      r8d, r10d
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:TakeValue(int,int):System.Object:this]
       mov      rbx, rax
       mov      rcx, r15
       mov      rdx, r12
       call     [Lokad.Lython.Runtime.LythonRuntime:ResolveVariableAnnotationMapping(Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):System.Object]
       mov      rdx, rax
       mov      gword ptr [rsp+0x20], r15
       mov      gword ptr [rsp+0x28], r12
       movzx    r8, r14b
       mov      dword ptr [rsp+0x30], r8d
       mov      r8, gword ptr [r13+0x08]
       lea      rcx, [rbp-0x80]
       mov      r9, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime:StoreAnnotationEntryAsync(System.Object,System.String,System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,bool):System.Threading.Tasks.ValueTask]
       mov      rsi, rdi
       mov      rdx, gword ptr [rbp-0x80]
       mov      rcx, rsi
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rdx, qword ptr [rbp-0x78]
       mov      qword ptr [rsi+0x08], rdx
       jmp      G_M000_IG146
 
G_M000_IG109:                ;; offset=0x0C09
       mov      rdx, r13
       mov      rcx, 0x7FFA02724E48
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       mov      gword ptr [rbp-0x118], rax
       test     rax, rax
       je       G_M000_IG133
       mov      rcx, 0x7FFA027253C0
       xor      rdx, rdx
       cmp      qword ptr [rax], rcx
       mov      r13, rdx
       cmove    r13, rax
       test     rbx, rbx
       je       G_M000_IG132
       test     r13, r13
       jne      G_M000_IG131
 
G_M000_IG110:                ;; offset=0x0C53
       mov      rcx, rax
       mov      r8, 0x7FFA02795BF0
       cmp      qword ptr [rcx], r8
       jne      G_M000_IG156
 
G_M000_IG111:                ;; offset=0x0C69
       mov      rcx, rax
       lea      rdx, [rbp-0x60]
       call     [Lokad.Lython.Frontend.ExecutableCreateLambda:get_Binding():Lokad.Lython.Frontend.ExecutableLambdaBinding:this]
       nop      
 
G_M000_IG112:                ;; offset=0x0C77
       mov      rsi, bword ptr [rbp+0x10]
       lea      rdx, bword ptr [rsi+0x20]
       mov      r14, rdx
       mov      rdx, r14
       mov      rcx, bword ptr [rbp+0x28]
       mov      r13d, dword ptr [rcx+0x10]
       mov      r15, gword ptr [rbp-0x118]
       mov      r15d, dword ptr [r15+0x18]
       mov      rdx, gword ptr [rdx]
       test     rdx, rdx
       je       SHORT G_M000_IG113
       mov      eax, r13d
       mov      r8d, r15d
       add      rax, r8
       mov      r8d, dword ptr [rdx+0x08]
       cmp      rax, r8
       ja       G_M000_IG118
       mov      rax, rdx
       jmp      SHORT G_M000_IG114
 
G_M000_IG113:                ;; offset=0x0CBB
       mov      eax, r13d
       or       eax, r15d
       jne      G_M000_IG118
       xor      rax, rax
       xor      r13d, r13d
       xor      r15d, r15d
 
G_M000_IG114:                ;; offset=0x0CCF
       xor      rdi, rdi
       xor      r8d, r8d
       test     rax, rax
       je       SHORT G_M000_IG117
       mov      rdx, qword ptr [rax]
       test     dword ptr [rdx], 0xFFFFFFFF80000000
       jne      SHORT G_M000_IG115
       lea      rdx, [rbp-0xD0]
       mov      rcx, rax
       mov      rax, qword ptr [rax]
       mov      rax, qword ptr [rax+0x40]
       call     [rax+0x28]System.Buffers.MemoryManager`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:GetSpan():System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:this
       mov      r8d, dword ptr [rbp-0xC8]
       mov      rdi, bword ptr [rbp-0xD0]
       mov      eax, r8d
       jmp      SHORT G_M000_IG116
 
G_M000_IG115:                ;; offset=0x0D0B
       lea      rdi, bword ptr [rax+0x10]
       mov      eax, dword ptr [rax+0x08]
 
G_M000_IG116:                ;; offset=0x0D12
       and      r13d, 0x7FFFFFFF
       mov      r8d, r13d
       mov      edx, r15d
       add      rdx, r8
       mov      eax, eax
       cmp      rdx, rax
       ja       SHORT G_M000_IG118
       shl      r8, 4
       add      rdi, r8
       mov      eax, r15d
       mov      r8d, eax
 
G_M000_IG117:                ;; offset=0x0D36
       mov      rdx, gword ptr [rbp-0x58]
       mov      bword ptr [rbp-0x110], rdi
       mov      dword ptr [rbp-0xC0], r8d
       mov      dword ptr [rbp-0x108], r8d
       lea      r8, [rbp-0x110]
       lea      rcx, [rbp-0x98]
       xor      r9d, r9d
       call     [Lokad.Lython.Runtime.LythonRuntime:ReadExecutableDefaults(Lokad.Lython.Frontend.FunctionParameterLayout,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],bool):Lokad.Lython.Runtime.FunctionDefaults]
       lea      rcx, [rbp-0x60]
       lea      rdx, [rbp-0x98]
       mov      r8, rbx
       mov      r9, r12
       call     [Lokad.Lython.Runtime.LythonRuntime:CreateLambdaFunction(byref,Lokad.Lython.Runtime.FunctionDefaults,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.PyFunctionBase]
       mov      r12, rax
       mov      edx, dword ptr [rbp-0xC0]
       add      rdx, rdx
       mov      rcx, rdi
       call     [System.SpanHelpers:ClearWithReferences(byref,nuint)]
       jmp      SHORT G_M000_IG119
 
G_M000_IG118:                ;; offset=0x0D94
       call     [System.ThrowHelper:ThrowArgumentOutOfRangeException()]
       int3     
 
G_M000_IG119:                ;; offset=0x0D9B
       mov      rcx, r14
       mov      rdi, bword ptr [rbp+0x28]
       mov      r15d, dword ptr [rdi+0x1C]
       cmp      r15d, 51
       ja       SHORT G_M000_IG123
 
G_M000_IG120:                ;; offset=0x0DAC
       mov      rdx, 0x7FFFFFFFFF9FF
       bt       rdx, r15
       jb       SHORT G_M000_IG123
 
G_M000_IG121:                ;; offset=0x0DBC
       mov      edx, dword ptr [rdi+0x18]
       test     edx, edx
       jge      SHORT G_M000_IG122
       not      edx
 
G_M000_IG122:                ;; offset=0x0DC5
       jmp      SHORT G_M000_IG124
 
G_M000_IG123:                ;; offset=0x0DC7
       mov      edx, dword ptr [rdi+0x14]
 
G_M000_IG124:                ;; offset=0x0DCA
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
       mov      r15d, dword ptr [rdi+0x18]
       test     r15d, r15d
       jge      SHORT G_M000_IG125
       mov      gword ptr [rbp-0xE0], r12
       xor      r9d, r9d
       mov      qword ptr [rbp-0xD8], r9
       lea      r9, [rbp-0xE0]
       mov      rdx, rbx
       mov      r8, rdi
       mov      rcx, rsi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CompleteResultConsumer(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot)]
       jmp      G_M000_IG146
 
G_M000_IG125:                ;; offset=0x0E05
       mov      rsi, r14
       mov      ecx, dword ptr [rdi+0x1C]
       cmp      ecx, 51
       ja       SHORT G_M000_IG128
 
G_M000_IG126:                ;; offset=0x0E10
       mov      rdx, 0x7FFFFFFFFF9FF
       bt       rdx, rcx
       jb       SHORT G_M000_IG128
 
G_M000_IG127:                ;; offset=0x0E20
       mov      r14d, r15d
       jmp      SHORT G_M000_IG129
 
G_M000_IG128:                ;; offset=0x0E25
       mov      r14d, dword ptr [rdi+0x14]
 
G_M000_IG129:                ;; offset=0x0E29
       cmp      r15d, dword ptr [rsi+0x40]
       jge      SHORT G_M000_IG130
       mov      rcx, rsi
       mov      edx, r15d
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
 
G_M000_IG130:                ;; offset=0x0E3B
       mov      rcx, gword ptr [rsi]
       cmp      r14d, dword ptr [rcx+0x08]
       jae      G_M000_IG157
       mov      edx, r14d
       shl      rdx, 4
       lea      rdi, bword ptr [rcx+rdx+0x10]
       mov      rcx, rdi
       mov      rdx, r12
       call     CORINFO_HELP_ASSIGN_REF
       xor      eax, eax
       mov      qword ptr [rdi+0x08], rax
       mov      dword ptr [rsi+0x40], r15d
       jmp      G_M000_IG146
 
G_M000_IG131:                ;; offset=0x0E6E
       mov      rsi, bword ptr [rbp+0x10]
       mov      r15, bword ptr [rbp+0x28]
       mov      bword ptr [rsp+0x20], r15
       movzx    rcx, r14b
       mov      dword ptr [rsp+0x28], ecx
       lea      rcx, [rbp-0xA8]
       mov      rdx, rsi
       mov      r8, rbx
       mov      r9, r13
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CreateExecutableFunction(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Frontend.ExecutableCreateFunction,byref,bool):System.Threading.Tasks.ValueTask]
       mov      rsi, rdi
       mov      rdx, gword ptr [rbp-0xA8]
       mov      rcx, rsi
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      r9, qword ptr [rbp-0xA0]
       mov      qword ptr [rsi+0x08], r9
       jmp      G_M000_IG146
 
G_M000_IG132:                ;; offset=0x0EBB
       mov      gword ptr [rsp+0x20], rsi
       mov      gword ptr [rsp+0x28], r12
       lea      r9, [rbp-0x48]
       mov      qword ptr [rsp+0x30], r9
       mov      r14, bword ptr [rbp+0x10]
       mov      r9, gword ptr [r14+0x18]
       mov      r8, gword ptr [r14]
       mov      rcx, rax
       mov      rdx, r13
       call     [Lokad.Lython.Runtime.LythonRuntime:CanDefineWithoutInvocation(Lokad.Lython.Frontend.ExecutableCallableDefinition,Lokad.Lython.Frontend.ExecutableCreateFunction,Lokad.Lython.Frontend.ExecutableCodeObject,Lokad.Lython.Runtime.LythonRuntime+ExecutableCaptures,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,byref):bool]
       test     eax, eax
       je       G_M000_IG150
       mov      r15, bword ptr [rbp+0x28]
       mov      bword ptr [rsp+0x20], r15
       mov      rcx, gword ptr [rbp-0x48]
       mov      gword ptr [rsp+0x28], rcx
       mov      rcx, r14
       mov      rdx, rsi
       mov      r8, gword ptr [rbp-0x118]
       mov      r9, r13
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CreateBorrowedCallableDefinition(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Frontend.ExecutableCallableDefinition,Lokad.Lython.Frontend.ExecutableCreateFunction,byref,int[])]
       jmp      G_M000_IG146
 
G_M000_IG133:                ;; offset=0x0F1A
       test     r13, r13
       je       G_M000_IG143
 
G_M000_IG134:                ;; offset=0x0F23
       mov      rax, qword ptr [r13]
       mov      rcx, 0x7FFA02763F98
       cmp      rax, rcx
       jne      G_M000_IG143
 
G_M000_IG135:                ;; offset=0x0F3A
       test     rbx, rbx
       je       G_M000_IG149
       mov      rcx, 0x7FFA0284D610
       call     CORINFO_HELP_NEWSFAST
       mov      r14, rax
       xor      edx, edx
       mov      dword ptr [rsp+0x20], edx
 
G_M000_IG136:                ;; offset=0x0F5B
       mov      gword ptr [rsp+0x28], rdx
       mov      edx, dword ptr [r13+0x08]
       mov      r9, 0x2C6B3801418
       mov      r9, gword ptr [r9]
       mov      rcx, r14
       mov      r8, r15
       call     [Lokad.Lython.Runtime.Calls.CallExpansion+CallArgumentAccumulator:.ctor(int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,System.Object,bool,Lokad.Lython.Runtime.MemoryGovernor+TemporaryMemoryReservation):this]
       mov      r15, bword ptr [rbp+0x28]
       mov      edi, dword ptr [r15+0x18]
       test     edi, edi
       jge      SHORT G_M000_IG137
       mov      gword ptr [rbp-0xE0], r14
       xor      r9d, r9d
       mov      qword ptr [rbp-0xD8], r9
       lea      r9, [rbp-0xE0]
       mov      rdx, rbx
       mov      r8, r15
       mov      rcx, bword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CompleteResultConsumer(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot)]
       jmp      G_M000_IG146
 
G_M000_IG137:                ;; offset=0x0FB6
       mov      rsi, bword ptr [rbp+0x10]
       lea      rcx, bword ptr [rsi+0x20]
       mov      rbx, rcx
       mov      rsi, rbx
       mov      ecx, dword ptr [r15+0x1C]
       cmp      ecx, 51
       ja       SHORT G_M000_IG140
 
G_M000_IG138:                ;; offset=0x0FCD
       mov      rdx, 0x7FFFFFFFFF9FF
       bt       rdx, rcx
       jb       SHORT G_M000_IG140
 
G_M000_IG139:                ;; offset=0x0FDD
       mov      ebx, edi
       jmp      SHORT G_M000_IG141
 
G_M000_IG140:                ;; offset=0x0FE1
       mov      ebx, dword ptr [r15+0x14]
 
G_M000_IG141:                ;; offset=0x0FE5
       cmp      edi, dword ptr [rsi+0x40]
       jge      SHORT G_M000_IG142
       mov      rcx, rsi
       mov      edx, edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
 
G_M000_IG142:                ;; offset=0x0FF5
       mov      rcx, gword ptr [rsi]
       cmp      ebx, dword ptr [rcx+0x08]
       jae      G_M000_IG157
       mov      edx, ebx
       shl      rdx, 4
       lea      r15, bword ptr [rcx+rdx+0x10]
       mov      rcx, r15
       mov      rdx, r14
       call     CORINFO_HELP_ASSIGN_REF
       xor      r9d, r9d
       mov      qword ptr [r15+0x08], r9
       mov      dword ptr [rsi+0x40], edi
       jmp      SHORT G_M000_IG146
 
G_M000_IG143:                ;; offset=0x1023
       test     r13, r13
       je       SHORT G_M000_IG148
 
G_M000_IG144:                ;; offset=0x1028
       mov      rax, qword ptr [r13]
       mov      r9, 0x7FFA02745CF0
       cmp      rax, r9
       jne      SHORT G_M000_IG148
 
G_M000_IG145:                ;; offset=0x103B
       mov      r8, r13
       test     rbx, rbx
       je       SHORT G_M000_IG149
       movzx    r9, r14b
       mov      dword ptr [rsp+0x20], r9d
       mov      r15, bword ptr [rbp+0x28]
       mov      r9d, dword ptr [r15+0x10]
       lea      rdx, [rbp-0xB8]
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecutePreparedClassDefinitionAsync(Lokad.Lython.Frontend.ExecutableCreateClass,int,bool):System.Threading.Tasks.ValueTask:this]
       mov      r13, rdi
       mov      rdx, gword ptr [rbp-0xB8]
       mov      rcx, r13
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rax, qword ptr [rbp-0xB0]
       mov      qword ptr [r13+0x08], rax
 
G_M000_IG146:                ;; offset=0x1081
       mov      eax, 1
 
G_M000_IG147:                ;; offset=0x1086
       vzeroupper 
       add      rsp, 296
       pop      rbx
       pop      rsi
       pop      rdi
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG148:                ;; offset=0x109D
       test     r13, r13
       je       SHORT G_M000_IG152
 
G_M000_IG149:                ;; offset=0x10A2
       test     rbx, rbx
       jne      SHORT G_M000_IG152
 
G_M000_IG150:                ;; offset=0x10A7
       xor      eax, eax
 
G_M000_IG151:                ;; offset=0x10A9
       vzeroupper 
       add      rsp, 296
       pop      rbx
       pop      rsi
       pop      rdi
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG152:                ;; offset=0x10C0
       mov      rcx, 0x7FFA023994A8
       call     CORINFO_HELP_NEWSFAST
       mov      rbx, rax
       mov      rcx, rbx
       mov      rdx, 0x2E6DA2B1380
       call     [System.InvalidOperationException:.ctor(System.String):this]
       mov      rcx, rbx
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG153:                ;; offset=0x10EE
       mov      rcx, 0x7FFA0284E0B8
       call     CORINFO_HELP_GET_GCSTATIC_BASE
       jmp      G_M000_IG64
 
G_M000_IG154:                ;; offset=0x1102
       mov      rdx, rax
       call     CORINFO_HELP_CHKCASTCLASS
       int3     
 
G_M000_IG155:                ;; offset=0x110B
       mov      rcx, 0x7FFA02788050
       call     CORINFO_HELP_GET_GCSTATIC_BASE
       jmp      G_M000_IG83
 
G_M000_IG156:                ;; offset=0x111F
       mov      rdx, rax
       mov      rcx, r8
       call     CORINFO_HELP_CHKCASTCLASS
       int3     
 
G_M000_IG157:                ;; offset=0x112B
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG158:                ;; offset=0x1131
       sub      rsp, 56
 
G_M000_IG159:                ;; offset=0x1135
       cmp      dword ptr [rbp-0x40], 0
       jne      SHORT G_M000_IG160
       mov      rcx, gword ptr [rbp-0x120]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext+InlinedComprehensionScope:Dispose():this]
 
G_M000_IG160:                ;; offset=0x1148
       call     CORINFO_HELP_RETHROW
       int3     
 
G_M000_IG161:                ;; offset=0x114E
       sub      rsp, 56
 
G_M000_IG162:                ;; offset=0x1152
       mov      r14, bword ptr [rbp+0x10]
       lea      rsi, bword ptr [r14+0x20]
       mov      rcx, rsi
       mov      edx, dword ptr [rbp-0x3C]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
       call     CORINFO_HELP_RETHROW
       int3     
 
G_M000_IG163:                ;; offset=0x116C
       sub      rsp, 56
 
G_M000_IG164:                ;; offset=0x1170
       mov      rsi, bword ptr [rbp+0x10]
       cmp      byte  ptr [rsi], sil
       lea      r14, bword ptr [rsi+0x20]
       mov      rcx, r14
       mov      rdi, bword ptr [rbp+0x28]
       mov      r15d, dword ptr [rdi+0x1C]
       cmp      r15d, 9
       je       SHORT G_M000_IG165
       cmp      r15d, 10
       je       SHORT G_M000_IG165
       cmp      r15d, 51
       je       SHORT G_M000_IG165
       mov      edx, dword ptr [rdi+0x14]
       jmp      SHORT G_M000_IG167
 
G_M000_IG165:                ;; offset=0x119D
       cmp      dword ptr [rdi+0x18], 0
       jl       SHORT G_M000_IG166
       mov      edx, dword ptr [rdi+0x18]
       jmp      SHORT G_M000_IG167
 
G_M000_IG166:                ;; offset=0x11A8
       mov      edx, dword ptr [rdi+0x18]
       not      edx
 
G_M000_IG167:                ;; offset=0x11AD
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
       nop      
 
G_M000_IG168:                ;; offset=0x11B4
       vzeroupper 
       add      rsp, 56
       ret      
 
; Total bytes of code 4540

; Assembly listing for method Lokad.Lython.Runtime.LythonRuntime+NativeExecution:ApplyDefinition(byref):bool:this (FullOpts)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; FullOpts code
; optimized code
; rsp based frame
; partially interruptible
; No PGO data
; 0 inlinees with PGO data; 4 single block inlinees; 0 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     rdi
       push     rsi
       push     rbp
       push     rbx
       sub      rsp, 88
       vxorps   xmm4, xmm4, xmm4
       vmovdqa  xmmword ptr [rsp+0x40], xmm4
       xor      eax, eax
       mov      qword ptr [rsp+0x50], rax
       mov      rbx, rcx
       mov      rsi, rdx
 
G_M000_IG02:                ;; offset=0x001F
       mov      rcx, gword ptr [rbx+0x08]
       mov      rdi, gword ptr [rcx+0x30]
       mov      rcx, rsi
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ConstantIndex():int:this]
       cmp      eax, dword ptr [rdi+0x08]
       jae      G_M000_IG07
       mov      edx, eax
       mov      rdx, gword ptr [rdi+8*rdx+0x10]
       mov      rcx, 0x7FFA02724E48
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       mov      rdi, rax
       test     rdi, rdi
       je       G_M000_IG05
 
G_M000_IG03:                ;; offset=0x005B
       mov      r8, 0x7FFA027253C0
       xor      r9, r9
       cmp      qword ptr [rdi], r8
       mov      rbp, r9
       cmove    rbp, rdi
       mov      r8, gword ptr [rbx+0x10]
       mov      gword ptr [rsp+0x20], r8
       mov      r8, gword ptr [rsi]
       mov      gword ptr [rsp+0x28], r8
       lea      r8, [rsp+0x50]
       mov      qword ptr [rsp+0x30], r8
       mov      r8, gword ptr [rbx+0x08]
       mov      r9, gword ptr [rbx+0x58]
       mov      rcx, rdi
       mov      rdx, rbp
       call     [Lokad.Lython.Runtime.LythonRuntime:CanDefineWithoutInvocation(Lokad.Lython.Frontend.ExecutableCallableDefinition,Lokad.Lython.Frontend.ExecutableCreateFunction,Lokad.Lython.Frontend.ExecutableCodeObject,Lokad.Lython.Runtime.LythonRuntime+ExecutableCaptures,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,byref):bool]
       test     eax, eax
       je       SHORT G_M000_IG05
       mov      rcx, gword ptr [rsp+0x50]
       mov      gword ptr [rsp+0x20], rcx
       mov      rcx, rbx
       mov      rdx, rsi
       mov      r8, rdi
       mov      r9, rbp
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:CreateInlineDefinition(byref,Lokad.Lython.Frontend.ExecutableCallableDefinition,Lokad.Lython.Frontend.ExecutableCreateFunction,int[]):Lokad.Lython.Runtime.PyFunctionBase:this]
       mov      gword ptr [rsp+0x40], rax
       xor      r8d, r8d
       mov      qword ptr [rsp+0x48], r8
       lea      r8, [rsp+0x40]
       mov      rdx, rsi
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot):this]
       mov      eax, 1
 
G_M000_IG04:                ;; offset=0x00E4
       add      rsp, 88
       pop      rbx
       pop      rbp
       pop      rsi
       pop      rdi
       ret      
 
G_M000_IG05:                ;; offset=0x00ED
       xor      eax, eax
 
G_M000_IG06:                ;; offset=0x00EF
       add      rsp, 88
       pop      rbx
       pop      rbp
       pop      rsi
       pop      rdi
       ret      
 
G_M000_IG07:                ;; offset=0x00F8
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
; Total bytes of code 254

; Assembly listing for method Lokad.Lython.Runtime.LythonRuntime:CanDefineWithoutInvocation(Lokad.Lython.Frontend.ExecutableCallableDefinition,Lokad.Lython.Frontend.ExecutableCreateFunction,Lokad.Lython.Frontend.ExecutableCodeObject,Lokad.Lython.Runtime.LythonRuntime+ExecutableCaptures,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,byref):bool (FullOpts)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; FullOpts code
; optimized code
; rsp based frame
; fully interruptible
; No PGO data
; 0 inlinees with PGO data; 15 single block inlinees; 2 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     r15
       push     r14
       push     rdi
       push     rsi
       push     rbp
       push     rbx
       sub      rsp, 40
       mov      gword ptr [rsp+0x78], r9
       mov      rbx, rcx
       mov      rsi, r8
       mov      rdi, gword ptr [rsp+0x80]
       mov      rbp, gword ptr [rsp+0x88]
       mov      r14, bword ptr [rsp+0x90]
 
G_M000_IG02:                ;; offset=0x002F
       xor      rcx, rcx
       mov      gword ptr [r14], rcx
       cmp      byte  ptr [rbx+0x1D], 0
       je       G_M000_IG14
 
G_M000_IG03:                ;; offset=0x003E
       test     rdx, rdx
       je       SHORT G_M000_IG04
       mov      rcx, rdi
       call     [Lokad.Lython.Runtime.LythonRuntime:HasTypeParameterScope(Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):bool]
       test     eax, eax
       jne      G_M000_IG14
 
G_M000_IG04:                ;; offset=0x0054
       mov      rbx, gword ptr [rbx+0x08]
       mov      rcx, gword ptr [rbx+0x80]
       mov      r11, 0x7FFA02172030
       call     [r11]System.Collections.Generic.IReadOnlyCollection`1[System.__Canon]:get_Count():int:this
       test     eax, eax
       je       G_M000_IG12
       mov      rbx, gword ptr [rbx+0x50]
       test     rbx, rbx
       je       G_M000_IG14
       mov      rcx, gword ptr [rbx+0x08]
       cmp      rcx, gword ptr [rsi+0x70]
       jne      G_M000_IG14
       mov      rsi, gword ptr [rdi+0xA0]
       cmp      byte  ptr [rsi], sil
       mov      rcx, rsi
       call     [Lokad.Lython.Runtime.ExecutionState:get_CanContinue():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG05
       mov      rcx, rsi
       mov      rdx, rbp
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
 
G_M000_IG05:                ;; offset=0x00B2
       mov      ecx, dword ptr [rbx+0x18]
       mov      esi, ecx
       mov      rcx, gword ptr [rbx+0x10]
       cmp      dword ptr [rcx+0x08], esi
       jle      SHORT G_M000_IG11
 
G_M000_IG06:                ;; offset=0x00C0
       test     esi, esi
       je       SHORT G_M000_IG08
 
G_M000_IG07:                ;; offset=0x00C4
       test     sil, sil
       jne      SHORT G_M000_IG08
       mov      r15, gword ptr [rdi+0xA0]
       cmp      byte  ptr [r15], r15b
       mov      rcx, r15
       call     [Lokad.Lython.Runtime.ExecutionState:get_CanContinue():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG08
       mov      rcx, r15
       mov      rdx, rbp
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
 
G_M000_IG08:                ;; offset=0x00EC
       mov      rdx, gword ptr [rbx+0x10]
       cmp      esi, dword ptr [rdx+0x08]
       jae      SHORT G_M000_IG16
       mov      edx, dword ptr [rdx+4*rsi+0x10]
       test     edx, edx
       jge      SHORT G_M000_IG10
 
G_M000_IG09:                ;; offset=0x00FD
       not      edx
       lea      rcx, [rsp+0x78]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableCaptures:GetCell(int):Lokad.Lython.Runtime.LythonRuntime+ExecutableCell:this]
       test     rax, rax
       je       SHORT G_M000_IG14
       cmp      gword ptr [rax+0x10], 0
       jne      SHORT G_M000_IG14
 
G_M000_IG10:                ;; offset=0x0116
       inc      esi
       mov      rcx, gword ptr [rbx+0x10]
       cmp      dword ptr [rcx+0x08], esi
       jg       SHORT G_M000_IG06
 
G_M000_IG11:                ;; offset=0x0121
       mov      rdx, gword ptr [rbx+0x10]
       mov      rcx, r14
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
 
G_M000_IG12:                ;; offset=0x012D
       mov      eax, 1
 
G_M000_IG13:                ;; offset=0x0132
       add      rsp, 40
       pop      rbx
       pop      rbp
       pop      rsi
       pop      rdi
       pop      r14
       pop      r15
       ret      
 
G_M000_IG14:                ;; offset=0x013F
       xor      eax, eax
 
G_M000_IG15:                ;; offset=0x0141
       add      rsp, 40
       pop      rbx
       pop      rbp
       pop      rsi
       pop      rdi
       pop      r14
       pop      r15
       ret      
 
G_M000_IG16:                ;; offset=0x014E
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
; Total bytes of code 340

; Assembly listing for method Lokad.Lython.Runtime.LythonRuntime+NativeExecution:CreateInlineDefinition(byref,Lokad.Lython.Frontend.ExecutableCallableDefinition,Lokad.Lython.Frontend.ExecutableCreateFunction,int[]):Lokad.Lython.Runtime.PyFunctionBase:this (FullOpts)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; FullOpts code
; optimized code
; rbp based frame
; fully interruptible
; No PGO data
; 0 inlinees with PGO data; 26 single block inlinees; 6 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       push     r15
       push     r14
       push     r13
       push     r12
       push     rdi
       push     rsi
       push     rbx
       sub      rsp, 280
       lea      rbp, [rsp+0x150]
       vxorps   xmm4, xmm4, xmm4
       vmovdqu  ymmword ptr [rbp-0xC0], ymm4
       vmovdqu  ymmword ptr [rbp-0xA0], ymm4
       vmovdqu  ymmword ptr [rbp-0x80], ymm4
       vmovdqu  ymmword ptr [rbp-0x60], ymm4
       mov      bword ptr [rbp+0x10], rcx
       mov      rsi, rdx
       mov      rdi, r8
       mov      rbx, r9
       mov      r14, gword ptr [rbp+0x30]
 
G_M000_IG02:                ;; offset=0x004A
       mov      r15, gword ptr [rdi+0x08]
       test     rbx, rbx
       je       SHORT G_M000_IG03
       mov      r13, gword ptr [rbx+0x38]
       jmp      SHORT G_M000_IG04
 
G_M000_IG03:                ;; offset=0x0059
       xor      r13, r13
 
G_M000_IG04:                ;; offset=0x005C
       mov      edx, dword ptr [rsi+0x10]
       mov      dword ptr [rbp-0x3C], edx
       xor      r8, r8
       mov      gword ptr [rbp-0xE8], r8
 
G_M000_IG05:                ;; offset=0x006C
       mov      dword ptr [rbp-0x88], r8d
 
G_M000_IG06:                ;; offset=0x0073
       xor      r12d, r12d
 
G_M000_IG07:                ;; offset=0x0076
       test     r13, r13
       je       SHORT G_M000_IG08
       mov      r8, gword ptr [rcx+0x10]
       mov      gword ptr [rsp+0x20], r8
       mov      r8, gword ptr [rsi]
       mov      gword ptr [rsp+0x28], r8
       mov      r8, gword ptr [rcx+0x08]
       lea      rcx, [rbp-0x50]
       mov      rdx, r13
       mov      r9, r15
       call     [Lokad.Lython.Runtime.LythonRuntime:ReadEagerFunctionAnnotations(Lokad.Lython.Frontend.ExecutableInstruction[],Lokad.Lython.Frontend.ExecutableCodeObject,Lokad.Lython.Frontend.ExecutableCodeObject,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):System.ValueTuple`3[System.Object,int,bool]]
       mov      rdx, gword ptr [rbp-0x50]
       mov      gword ptr [rbp-0xE8], rdx
       mov      edx, dword ptr [rbp-0x48]
       mov      dword ptr [rbp-0x88], edx
       movzx    r12, byte  ptr [rbp-0x44]
       mov      rcx, bword ptr [rbp+0x10]
 
G_M000_IG08:                ;; offset=0x00BD
       xor      rax, rax
       xor      r10d, r10d
       test     r13, r13
       jne      G_M000_IG11
       test     r14, r14
       je       G_M000_IG11
       cmp      dword ptr [r14+0x08], 1
       jne      SHORT G_M000_IG11
       mov      r8d, dword ptr [r14+0x10]
       test     r8d, r8d
       jl       SHORT G_M000_IG11
       mov      r9d, r8d
       lea      r11, bword ptr [rcx+0x48]
       mov      r13d, dword ptr [r11+0x08]
       cmp      r9d, r13d
       jae      G_M000_IG24
       mov      r11, bword ptr [r11]
       shl      r9, 4
       mov      r9, gword ptr [r11+r9]
       test     r9, r9
       je       SHORT G_M000_IG10
 
G_M000_IG09:                ;; offset=0x0108
       mov      r11, 0x7FFA02826C38
       cmp      qword ptr [r9], r11
       je       SHORT G_M000_IG11
 
G_M000_IG10:                ;; offset=0x0117
       lea      rax, bword ptr [rcx+0x48]
       mov      r10d, r8d
       inc      r10
       mov      r9d, r13d
       cmp      r10, r9
       ja       G_M000_IG23
       mov      r8d, r8d
       shl      r8, 4
       add      r8, bword ptr [rax]
       mov      rax, r8
       mov      bword ptr [rbp-0xD8], rax
       mov      eax, 1
       mov      r10d, eax
       mov      rax, bword ptr [rbp-0xD8]
 
G_M000_IG11:                ;; offset=0x0150
       test     r14, r14
       jne      SHORT G_M000_IG13
 
G_M000_IG12:                ;; offset=0x0155
       mov      dword ptr [rbp-0x84], r10d
       jmp      SHORT G_M000_IG14
 
G_M000_IG13:                ;; offset=0x015E
       mov      dword ptr [rbp-0x84], r10d
       test     r10d, r10d
       je       SHORT G_M000_IG15
 
G_M000_IG14:                ;; offset=0x016A
       xor      r13, r13
       mov      bword ptr [rbp-0xD8], rax
       jmp      SHORT G_M000_IG18
 
G_M000_IG15:                ;; offset=0x0176
       mov      bword ptr [rbp-0xD8], rax
       mov      r8, gword ptr [rcx+0x10]
       mov      r9, gword ptr [rsi]
 
G_M000_IG16:                ;; offset=0x0184
       vmovdqu  xmm0, xmmword ptr [rcx+0x48]
       vmovdqu  xmmword ptr [rbp-0x98], xmm0
 
G_M000_IG17:                ;; offset=0x0191
       mov      r11, gword ptr [rcx+0x58]
       mov      gword ptr [rsp+0x20], r11
       mov      gword ptr [rsp+0x28], r14
       lea      r11, [rbp-0x58]
       mov      qword ptr [rsp+0x30], r11
       xor      r11, r11
       mov      gword ptr [rsp+0x38], r11
       mov      dword ptr [rsp+0x40], 1
       mov      rdx, r8
       mov      r8, r9
       lea      r9, [rbp-0x98]
       mov      rcx, r15
       call     [Lokad.Lython.Runtime.LythonRuntime:CaptureExecutableCells(Lokad.Lython.Frontend.ExecutableCodeObject,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],Lokad.Lython.Runtime.LythonRuntime+ExecutableCaptures,int[],byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,bool):Lokad.Lython.Runtime.LythonRuntime+ExecutableCaptures]
       mov      r13, rax
 
G_M000_IG18:                ;; offset=0x01D1
       mov      r14, gword ptr [rdi+0x10]
       movzx    rax, byte  ptr [rdi+0x1C]
       mov      dword ptr [rbp-0x5C], eax
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rcx+0x10]
       mov      gword ptr [rbp-0xC8], rdx
       mov      rsi, gword ptr [rsi]
       lea      r8, bword ptr [rcx+0x48]
       mov      edi, dword ptr [rdi+0x18]
       mov      r10d, dword ptr [rbp-0x3C]
       mov      r9d, r10d
       mov      r11d, edi
       add      r9, r11
       mov      r11d, dword ptr [r8+0x08]
       cmp      r9, r11
       ja       G_M000_IG23
       mov      r9d, r10d
       shl      r9, 4
       add      r9, bword ptr [r8]
       mov      bword ptr [rbp-0xE0], r9
       test     rbx, rbx
       je       SHORT G_M000_IG19
       mov      r9, gword ptr [rbx+0x30]
       movzx    rbx, byte  ptr [rbx+0x1E]
       mov      eax, ebx
       mov      rbx, r9
       mov      r9d, eax
       jmp      SHORT G_M000_IG20
 
G_M000_IG19:                ;; offset=0x0237
       xor      r9, r9
       xor      rbx, rbx
 
G_M000_IG20:                ;; offset=0x023C
       mov      dword ptr [rbp-0x64], r9d
       mov      rcx, r14
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.FunctionParameterLayout:get_DefaultStorageCount():int:this]
       mov      dword ptr [rbp-0x60], eax
       cmp      eax, edi
       ja       G_M000_IG23
       mov      rcx, gword ptr [rbp-0xC8]
       call     [Lokad.Lython.Runtime.LythonRuntime:GetGlobalContext(Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):Lokad.Lython.Runtime.LythonRuntime+ExecutionContext]
       mov      gword ptr [rbp-0xD0], rax
       mov      r10, bword ptr [rbp-0xE0]
       mov      bword ptr [rbp-0xA8], r10
       mov      r11d, dword ptr [rbp-0x60]
       mov      dword ptr [rbp-0xA0], r11d
       lea      r8, [rbp-0xA8]
       lea      rcx, [rbp-0x80]
       mov      rdx, r14
       mov      r9d, dword ptr [rbp-0x64]
       call     [Lokad.Lython.Runtime.LythonRuntime:ReadExecutableDefaults(Lokad.Lython.Frontend.FunctionParameterLayout,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],bool):Lokad.Lython.Runtime.FunctionDefaults]
       mov      eax, dword ptr [rbp-0x60]
       mov      r9d, eax
       shl      r9, 4
       add      r9, bword ptr [rbp-0xE0]
       sub      edi, eax
       lea      rcx, [rbp-0x80]
       mov      qword ptr [rsp+0x20], rcx
       mov      ecx, dword ptr [rbp-0x5C]
       mov      dword ptr [rsp+0x28], ecx
       mov      rcx, gword ptr [rbp-0xC8]
       mov      gword ptr [rsp+0x30], rcx
       mov      gword ptr [rsp+0x38], rsi
       mov      bword ptr [rbp-0xA8], r9
       mov      dword ptr [rbp-0xA0], edi
       mov      gword ptr [rsp+0x48], rbx
       mov      r9, gword ptr [rbp-0xE8]
       mov      gword ptr [rbp-0xB8], r9
       mov      r9d, dword ptr [rbp-0x88]
       mov      dword ptr [rbp-0xB0], r9d
       mov      byte  ptr [rbp-0xAC], r12b
       mov      ebx, dword ptr [rbp-0x64]
       mov      dword ptr [rsp+0x58], ebx
       mov      rbx, bword ptr [rbp-0xD8]
       mov      bword ptr [rbp-0x98], rbx
       mov      ebx, dword ptr [rbp-0x84]
       mov      dword ptr [rbp-0x90], ebx
       lea      r9, [rbp-0xA8]
       mov      qword ptr [rsp+0x40], r9
       lea      r9, [rbp-0xB8]
       mov      qword ptr [rsp+0x50], r9
       lea      r9, [rbp-0x98]
       mov      qword ptr [rsp+0x60], r9
       mov      r9, r13
       mov      rcx, r14
 
G_M000_IG21:                ;; offset=0x034F
       mov      rdx, r15
       mov      r8, gword ptr [rbp-0xD0]
       call     [Lokad.Lython.Runtime.LythonRuntime:CreateFunctionValue(Lokad.Lython.Frontend.FunctionParameterLayout,Lokad.Lython.Frontend.ExecutableCodeObject,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutableCaptures,Lokad.Lython.Runtime.FunctionDefaults,bool,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],Lokad.Lython.Runtime.Text.PyString[],System.ValueTuple`3[System.Object,int,bool],bool,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):Lokad.Lython.Runtime.PyFunctionBase]
       mov      rbx, rax
       mov      edx, dword ptr [rbp-0x60]
       add      rdx, rdx
       mov      rcx, bword ptr [rbp-0xE0]
       call     [System.SpanHelpers:ClearWithReferences(byref,nuint)]
       xor      rax, rax
       mov      gword ptr [rbp-0xE8], rax
 
G_M000_IG22:                ;; offset=0x037E
       mov      dword ptr [rbp-0x88], eax
       mov      gword ptr [rbp-0xC0], rbx
       jmp      SHORT G_M000_IG25
 
G_M000_IG23:                ;; offset=0x038D
       call     [System.ThrowHelper:ThrowArgumentOutOfRangeException()]
       int3     
 
G_M000_IG24:                ;; offset=0x0394
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG25:                ;; offset=0x039A
       call     G_M000_IG31
       nop      
 
G_M000_IG26:                ;; offset=0x03A0
       mov      rax, gword ptr [rbp-0xC0]
 
G_M000_IG27:                ;; offset=0x03A7
       add      rsp, 280
       pop      rbx
       pop      rsi
       pop      rdi
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG28:                ;; offset=0x03BB
       sub      rsp, 104
 
G_M000_IG29:                ;; offset=0x03BF
       mov      rcx, bword ptr [rbp+0x10]
       mov      edx, dword ptr [rbp-0x3C]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Trim(int):this]
       nop      
 
G_M000_IG30:                ;; offset=0x03CD
       add      rsp, 104
       ret      
 
G_M000_IG31:                ;; offset=0x03D2
       sub      rsp, 104
 
G_M000_IG32:                ;; offset=0x03D6
       mov      rcx, bword ptr [rbp+0x10]
       mov      rax, gword ptr [rcx+0x10]
       cmp      gword ptr [rbp-0xE8], 0
       je       SHORT G_M000_IG34
       mov      rax, gword ptr [rax+0xA0]
       mov      rbx, gword ptr [rax+0x88]
       mov      ecx, dword ptr [rbp-0x88]
       call     [Lokad.Lython.Runtime.PyDict+RecordKeys:RecordBytes(int):long]
       mov      rdx, rax
       add      rdx, 160
       jo       SHORT G_M000_IG33
       mov      rcx, rbx
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.MemoryGovernor:ReleaseReserved(long):this]
       jmp      SHORT G_M000_IG34
 
G_M000_IG33:                ;; offset=0x041B
       call     CORINFO_HELP_OVERFLOW
       int3     
 
G_M000_IG34:                ;; offset=0x0421
       call     G_M000_IG28
       nop      
 
G_M000_IG35:                ;; offset=0x0427
       add      rsp, 104
       ret      
 
; Total bytes of code 1068

