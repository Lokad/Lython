from pathlib import Path
import json
import subprocess
import tarfile

lab=Path(__file__).resolve().parent
manifest=json.loads((lab/'verified-replicas.json').read_text(encoding='utf-8'))
quiet=lab/'comparison/quiet'
configuration=json.loads((quiet/'upload.json').read_text(encoding='utf-8'))
with tarfile.open(quiet/'payload.tar.gz') as data:
    lengths=[member.size for member in data.getmembers()]
source='configuration='+repr(configuration)+'\nlengths='+repr(lengths)+'\nreplicas='+repr(manifest)+'\n'+"""
from pathlib import Path
import fcntl, hashlib, json, os, shutil
base=Path('/home/lokad/lython-bench-checks').resolve()
assert base.is_dir()
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
with (base/'comparison-vm.lock').open('a') as lease:
    fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
    assert not (base/configuration['root']).exists()
    assert configuration['reference']+'/' not in [item['path'].split('/',1)[0]+'/' for item in replicas]
    block=os.statvfs(base).f_frsize
    needed=10*1024*1024+1536*1024+sum((size+block-1)//block*block for size in lengths)
    initial=shutil.disk_usage(base).free
    available=initial
    retired=[]
    if available < needed+512*1024:
        for saved in replicas:
            replica=base/saved['path']
            assert replica.resolve()==replica and replica.is_relative_to(base)
            assert replica.is_file() and replica.stat().st_nlink==1
            archive_root=replica.parent.parent
            proof=json.loads((archive_root/'archive-receipt.json').read_text())
            assert proof['complete'] and proof['archivedAndVerifiedUnderLease']
            assert proof['archiveSHA256']==saved['observationSHA256']
            assert sha(archive_root/'observations.tar.xz')==saved['observationSHA256']
            assert sha(replica)==saved['sha256'] and not (archive_root/'guest-fixtures').exists()
            retired.append((replica,saved))
            available+=replica.stat().st_blocks*512
            if available>=needed+512*1024: break
        assert available>=needed+512*1024,(available,needed)
        for replica,_ in retired:
            replica.unlink()
    free=shutil.disk_usage(base).free
    assert free>=needed and free>=configuration['payloadBytes']
    print(json.dumps(dict(before=initial,after=free,required=needed,
        verifiedDuplicateRetired=[saved for _,saved in retired]),indent=2))
"""
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i',str(Path.home()/'.ssh/id_lython-bench.pem'),
     '-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73','python3 -']
result=subprocess.run(ssh,input=source,encoding='utf-8',capture_output=True,timeout=35)
assert result.returncode==0,(result.stdout,result.stderr)
(lab/'space-retirement.json').write_text(result.stdout,encoding='utf-8',newline='\n')
print(result.stdout)
