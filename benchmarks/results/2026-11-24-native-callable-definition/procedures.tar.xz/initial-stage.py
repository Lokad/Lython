from pathlib import Path
import gzip
import hashlib
import json
import shutil
import subprocess
import tarfile

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
donor=lab.with_name('regex-module-index-20261124')
comparison=lab/'comparison'
quiet=comparison/'quiet'
quiet.mkdir(exist_ok=True)
core='Lokad.Lython.dll'
reference='regex-flag-continuations-b1576-20261124'
root='native-callable-definition-b1578-20261124'


def sha(data):
    return hashlib.sha256(data).hexdigest()


def digest(path):
    return sha(path.read_bytes())


def write(path,value):
    path.write_text(value,encoding='utf-8',newline='\n')


def save(path,value):
    write(path,json.dumps(value,indent=2)+'\n')


replicas=[]
for evidence,remote,role,core_evidence in [
    ('regex-module-index','regex-module-index-b1570-20261124','reference','regex-index-resumption'),
    ('regex-module-index','regex-module-index-b1570-20261124','candidate','regex-module-index'),
    ('closed-scalar-branches','closed-scalar-branches-b1572-20261124','candidate','closed-scalar-branches'),
]:
    archive='benchmarks/results/2026-11-24-'+evidence+'/'
    def tracked(path):
        return subprocess.check_output(['git','show','origin/master:'+path],cwd=repo)
    receipt=json.loads(tracked(archive+'terminal-status.json'))['receipt']
    assert receipt['complete'] and receipt['archivedAndVerifiedUnderLease']
    assert sha(tracked(archive+'observations.tar.xz'))==receipt['archiveSHA256']
    core_archive='benchmarks/results/2026-11-24-'+core_evidence+'/candidate-core.dll.gz'
    binary=sha(gzip.decompress(tracked(core_archive)))
    assert json.loads(tracked(archive+'identity.json'))['imageFiles'][role][core]==binary
    replicas.append(dict(path=remote+'/'+role+'/'+core,sha256=binary,
        observationSHA256=receipt['archiveSHA256'],trackedArchive=archive,coreArchive=core_archive))
save(lab/'verified-replicas.json',replicas)

original=donor/'comparison/quiet'
collector=(original/'collect.py').read_text(encoding='utf-8')
assert collector.count("'reference':root/'reference'")==1
collector=collector.replace('b1570-','b1578-').replace('assert len(jobs) == 4','assert len(jobs) == 7')
collector=collector.replace("'reference':root/'reference'","'reference':root.parent/"+repr(reference)+"/'candidate'")
assert collector.count(reference)==1
collector=collector.replace('time.monotonic()-started < 315','time.monotonic()-started < 410')
assert 'assert len(jobs) == 7' in collector
compile(collector,'collect.py','exec')
write(quiet/'collect.py',collector)
shutil.copyfile(original/'run.sh',quiet/'run.sh')
assert b'\r' not in (quiet/'run.sh').read_bytes()
payload=quiet/'payload.tar.gz'
with tarfile.open(payload,'w:gz') as bundle:
    for name in ('identity.json','representative.json','jobs.json'):
        bundle.add(comparison/name,arcname=name)
    for name in ('collect.py','run.sh'):
        bundle.add(quiet/name,arcname=name)
    bundle.add(lab/'candidate'/core,arcname='candidate-core.dll')
save(quiet/'upload.json',dict(root=root,reference=reference,payloadSHA256=digest(payload),payloadBytes=payload.stat().st_size))
launch=(lab.with_name('regex-index-resumption-20261124')/'quiet.py').read_text(encoding='utf-8')
launch=launch.replace('b1569-regex-index-resumption','b1578-native-callable-definition').replace('b1569-','b1578-')
launch=launch.replace('RuntimeMaxSec=270','RuntimeMaxSec=435').replace('seconds=207','seconds=369')
assert 'RuntimeMaxSec=435' in launch and 'seconds=369' in launch
import ast
remote_stage, = (n.value for n in ast.walk(ast.parse(launch)) if isinstance(n, ast.Constant) and isinstance(n.value, str) and n.value.startswith('digest=lambda path:'))
compile(remote_stage,'remote-stage','exec')
compile(launch,'quiet.py','exec')
write(lab/'quiet.py',launch)
summary=(donor/'summarize.py').read_text(encoding='utf-8')
summary=summary.replace('receipt["warmJobs"] == 4','receipt["warmJobs"] == 7').replace('len(warm["jobs"])==4','len(warm["jobs"])==7')
summary=summary.replace('timedBatches=112','timedBatches=196')
compile(summary,'summarize.py','exec')
write(lab/'summarize.py',summary)
