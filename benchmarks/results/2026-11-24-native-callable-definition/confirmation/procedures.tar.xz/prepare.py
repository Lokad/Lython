from pathlib import Path
import hashlib,json,os,subprocess,shutil
lab=Path(__file__).resolve().parent
repo=lab.parents[3]
donor=lab.with_name('native-callable-definition-20261124')
source=donor/'comparison'
original=source/'quiet'
out=lab/'external'
out.mkdir(exist_ok=True)
def read(path):
    return json.loads(path.read_text(encoding='utf-8'))
def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
def write(path,value):
    path.write_text(value,encoding='utf-8',newline='\n')
def save(path,value):
    write(path,json.dumps(value,ensure_ascii=False,indent=2)+'\n')
def change(text,old,new):
    assert text.count(old)==1,old
    return text.replace(old,new,1)
identity=read(source/'identity.json')
assert identity['candidate'].startswith('ebfe49f02') and identity['sourceRevision'].startswith('bd0f0ca93')
terminal=read(original/'terminal-status.json')
assert terminal['exitCode']=='0' and terminal['receipt']['complete']
assert sha(original/'observations.tar.xz')==terminal['receipt']['archiveSHA256']
catalog=read(source/'representative.json')
defaulted='scripts.rule-default-closures'
annotated='scripts.annotated-rule-closures'
catalog['cases']=[c for c in catalog['cases'] if c['id'] in (defaulted,annotated)]
assert [c['id'] for c in catalog['cases']]==[defaulted,annotated]
save(out/'representative.json',catalog)
save(out/'jobs.json',{'warm':[[defaulted,'warm'],[defaulted,'compile-run'],[annotated,'warm']]})
identity['purpose']='B1579 confirm defaulted definition results on the unchanged B1578 images'
identity['catalogs']={name:dict(sha256=sha(out/name)) for name in ('representative.json','jobs.json')}
save(out/'identity.json',identity)
dotnet=Path.home()/'.dotnet11/dotnet.exe'
env=dict(os.environ,DOTNET_ROOT=str(dotnet.parent),DOTNET_ROOT_X64=str(dotnet.parent))
protocol=repo/'benchmarks/cpython-worker.py'
assert sha(protocol)==identity['cpythonWorkerSHA256']
for role,files in identity['imageFiles'].items():
    image=donor/role
    assert len(files)==32 and all(sha(image/name)==checksum for name,checksum in files.items())
    verify=out/(role+'-verify.json')
    subprocess.run([dotnet,image/'Lokad.Lython.Benchmarks.dll','--compare','verify','--catalog',out/'representative.json',
        '--dotnet',dotnet,'--python','C:/Python313/python.exe','--python-worker',protocol,'--out',verify],
        env=env,check=True,timeout=90)
    proof=read(verify)
    assert proof['state']=='Completed' and proof['caseCount']==2
    assert proof['launched']['library']['sha256']==files['Lokad.Lython.dll']
    assert proof['catalogSha256']==identity['catalogs']['representative.json']['sha256']
    assert all(sha(image/name)==checksum for name,checksum in files.items())
collector=(original/'collect.py').read_text(encoding='utf-8').replace('b1578-','b1579-')
for old,new in [
    ('len(jobs) == 7','len(jobs) == 3'),
    ('time.monotonic()-started < 410','time.monotonic()-started < 265'),
    ('accumulate 8 seconds','accumulate 12 seconds'),
    ('warmupSeconds=8','warmupSeconds=12'),
    ('if job_index % 2 == 0: labels.reverse()','if job_index == 0: labels.reverse()')]:
    collector=change(collector,old,new)
assert collector.count('regex-flag-continuations-b1576-20261124')==1
compile(collector,'collect.py','exec')
write(out/'collect.py',collector)
summary=(donor/'summarize.py').read_text(encoding='utf-8')
for old,new in [
    ('lab=Path(__file__).resolve().parent\n','lab=Path(__file__).resolve().parent.parent\n'),
    ('comparison=lab/"comparison"','comparison=lab/"external"'),
    ('quiet=comparison/"quiet"','quiet=comparison'),
    ('receipt["warmJobs"] == 7','receipt["warmJobs"] == 3'),
    ('len(warm["jobs"])==7','len(warm["jobs"])==3'),
    ('timedBatches=196','timedBatches=84')]:
    summary=change(summary,old,new)
compile(summary,'summarize.py','exec')
write(out/'summarize.py',summary)
launch=(lab.with_name('rule-activation-cpython-20261124')/'external.py').read_text(encoding='utf-8')
launch=change(launch,"location = 'rule-activation-cpython-b1575-20261124'","location = 'native-callable-definition-confirmation-b1579-20261124'")
launch=change(launch,"unit = 'lython-b1575-rule-activation-cpython-20261124'","unit = 'lython-b1579-native-callable-definition-confirmation-20261124'")
launch=change(launch,"original = 'external-arithmetic-operands-b1574-20261124'","original = 'native-callable-definition-b1578-20261124'")
launch=change(launch,"quiet = lab.parent / 'external-arithmetic-operands-20261124/comparison/quiet'","quiet = lab.parent / 'native-callable-definition-20261124/comparison/quiet'")
launch=change(launch," files=identity['imageFiles']['candidate']",""" reference=base/'regex-flag-continuations-b1576-20261124'/'candidate'
 reference_files=identity['imageFiles']['reference']
 assert len(reference_files)==32 and all(digest(reference/name)==sha for name,sha in reference_files.items())
 files=identity['imageFiles']['candidate']""")
launch=change(launch,'RuntimeMaxSec=570','RuntimeMaxSec=285')
launch=change(launch,'seconds=444','seconds=215')
compile(launch,'external.py','exec')
write(lab/'external.py',launch)
