from pathlib import Path
import hashlib,json,shutil,tarfile
lab=Path(__file__).resolve().parent
repo=lab.parents[3]
external=lab/'external'
donor=lab.with_name('native-callable-definition-20261124')
record=repo/'benchmarks/results/2026-11-24-native-callable-definition'/'confirmation'
def read(path):
    return json.loads(path.read_text(encoding='utf-8'))
def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
status=read(external/'terminal-status.json')
receipt=status['receipt']
assert not status['live'] and status['exitCode']=='0' and not status['fixtures']
assert all(receipt[key] for key in ('complete','allWorkersJoined','guestFixturesRemoved',
    'quietBeforeAndAfter','archivedAndVerifiedUnderLease'))
assert receipt['warmJobs']==3 and digest(external/'observations.tar.xz')==receipt['archiveSHA256']
identity=read(external/'identity.json')
original=read(donor/'comparison/identity.json')
assert all(identity[key]==original[key] for key in ('sourceRevision','candidate','imageFiles','coreSHA256',
    'cpythonWorkerSHA256','expectedCPythonSHA256'))
summary=read(external/'summary.json')
assert summary['timedBatches']==84 and summary['source']==identity['sourceRevision'] and summary['candidate']==identity['candidate']
assert [(row['case'],row['lane']) for row in summary['rows']]==[tuple(row) for row in read(external/'jobs.json')['warm']]
for role,files in identity['imageFiles'].items():
    assert len(files)==32 and all(digest(donor/role/name)==sha for name,sha in files.items())
    check=read(external/(role+'-verify.json'))
    assert check['state']=='Completed' and check['caseCount']==2 and check['launched']['library']['sha256']==files['Lokad.Lython.dll']
    assert check['catalogSha256']==identity['catalogs']['representative.json']['sha256']
record.mkdir(exist_ok=True)
for name in ('identity.json','observations.tar.xz','summary.json','terminal-status.json'):
    shutil.copyfile(external/name,record/name)
inputs=('prepare.py','archive.py','external.py','external/summarize.py','external/launch.log',
    'external/reference-verify.json','external/candidate-verify.json','initial-summary.txt')
with tarfile.open(record/'procedures.tar.xz','w:xz') as bundle:
    for name in inputs: bundle.add(lab/name,arcname=name)
with tarfile.open(record/'procedures.tar.xz') as bundle:
    assert set(bundle.getnames())==set(inputs)
    assert all(bundle.extractfile(name).read()==(lab/name).read_bytes() for name in inputs)
