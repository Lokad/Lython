from pathlib import Path
import base64,datetime,json,subprocess
r=Path(__file__).parent/'b648';config=json.loads((r/'config.json').read_text(encoding='utf-8'))
code='''from pathlib import Path
import ast,fcntl,hashlib,io,json,os,shutil,stat,subprocess,sys,tarfile
config=CONFIG
base=Path('/home/lokad/lython-bench-checks').resolve();root=Path(config['root']);source=Path(config['sourceRoot'])
digest=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert root.parent==base and not root.exists()and source.parent==base
with(base/'comparison-vm.lock').open('a')as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert not(source/'guest-fixtures').exists()
 users=subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record|[p]ython3.*cpython-worker.py'],capture_output=True)
 assert users.returncode==1,users.stdout
 protected={source/'candidate/Lokad.Lython.dll':config['identity']['coreSHA256']['reference'],source/'reference/Lokad.Lython.dll':'e4cc65b251ace242546f337b0846908a4e2a4313953da74df6fb666e1ce87529'}
 for p,sha in protected.items():assert digest(p)==sha
 for name,sha in config['identity']['auxiliaryFiles'].items():assert digest(source/'candidate'/name)==sha
 before=shutil.disk_usage(base).free;proofs=[]
 for row in config['retire']:
  p=base/row['path'];s=p.lstat()
  assert p.resolve(strict=True)==p and p.is_relative_to(base)and stat.S_ISREG(s.st_mode)and s.st_uid==os.getuid()and s.st_nlink==1
  assert(s.st_dev,s.st_ino,s.st_size)==(row['device'],row['inode'],row['bytes'])and digest(p)==row['sha256']
  proofs.append(dict(row,allocatedBytes=s.st_blocks*512))
 required=252*1024*1024+config['unpackedBytes']+1024*1024
 assert before+sum(p['allocatedBytes']for p in proofs)>required
 payload=sys.stdin.buffer.read(config['payloadBytes']+1)
 assert len(payload)==config['payloadBytes']and hashlib.sha256(payload).hexdigest()==config['payloadSHA256']
 for row in proofs:
  p=base/row['path'];s=p.lstat();assert(s.st_dev,s.st_ino,s.st_size,s.st_nlink,s.st_uid)==(row['device'],row['inode'],row['bytes'],1,os.getuid());p.unlink()
 assert shutil.disk_usage(base).free>required
 root.mkdir()
 with tarfile.open(fileobj=io.BytesIO(payload),mode='r:gz')as archive:archive.extractall(root,filter='data')
 for role in ['reference','candidate']:shutil.copytree(source/'candidate',root/role,copy_function=os.link)
 (root/'candidate/Lokad.Lython.dll').unlink();os.link(root/'current-core.dll',root/'candidate/Lokad.Lython.dll')
 for role in ['reference','candidate']:assert digest(root/role/'Lokad.Lython.dll')==config['identity']['coreSHA256'][role]
 for p,sha in protected.items():assert digest(p)==sha
 os.link(source/'representative.json',root/'representative.json')
 shutil.copyfile(source/'cpython-worker.py',root/'cpython-worker.py')
 assert digest(root/'representative.json')==config['identity']['catalogSHA256']
 assert digest(root/'source-identity.json')==config['identity']['sourceIdentitySHA256']
 for name in ['collect.py','archive-owned.py']:ast.parse((root/name).read_text())
 subprocess.run(['/bin/sh','-n',str(root/'run.sh')],check=True)
 (root/'space-recovery.json').write_text(json.dumps(dict(freshIdleLease=True,beforeFreeBytes=before,afterStagingFreeBytes=shutil.disk_usage(base).free,osFloorMiB=240,evidenceHeadroomMiB=12,requiredBeforeStagingBytes=required,retired=proofs,protectedImagesUnchanged=True),indent=2)+'\\n')
 fixture=root/'guest-fixtures';fixture.mkdir();subprocess.run(['sudo','-n','mount','-t','tmpfs','-o','size=128m,mode=0700,uid=lokad,gid=lokad','lython-b648-fixtures',str(fixture)],check=True)
 assert shutil.disk_usage(base).free>252*1024*1024
try:
 subprocess.run(['sudo','-n','systemd-run','--unit='+config['unit'],'--property=User=lokad','--property=WorkingDirectory='+str(root),'--property=RuntimeMaxSec=420','--property=TimeoutStopSec=30','--property=KillMode=control-group','/bin/sh',str(root/'run.sh')],check=True)
except BaseException:subprocess.run(['sudo','-n','umount',str(fixture)],check=True);fixture.rmdir();raise
live=subprocess.check_output(['systemctl','show',config['unit']+'.service','--property=ActiveState,MainPID,RuntimeMaxUSec'],text=True)
assert'ActiveState=active'in live and'MainPID=0'not in live
print(live)
'''.replace('CONFIG',repr(config))
compile(code,'launch-command.py','exec');(r/'launch-command.py').write_text(code,encoding='utf-8',newline='\n')
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
encoded=base64.b64encode(code.encode()).decode();command="python3 -c 'import base64;exec(base64.b64decode(\""+encoded+"\"))'"
done=subprocess.run(ssh+[command],input=(r/'payload.tgz').read_bytes(),capture_output=True)
(r/'launch.log').write_bytes(done.stdout+done.stderr);print((done.stdout+done.stderr).decode(),flush=True);assert done.returncode==0
now=datetime.datetime.now(datetime.timezone.utc)
(r/'observe-not-before.json').write_text(json.dumps(dict(startedUTC=now.isoformat(),doNotObserveBeforeUTC=(now+datetime.timedelta(seconds=480)).isoformat(),ownerSeconds=420,stopSeconds=30,marginSeconds=30),indent=2)+'\n',encoding='utf-8',newline='\n')
