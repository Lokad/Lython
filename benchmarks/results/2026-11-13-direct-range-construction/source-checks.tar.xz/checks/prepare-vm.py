from pathlib import Path
import ast,hashlib,json,tarfile
r=Path(__file__).parent;out=r/'b648';out.mkdir();old=r.parent/'ordered-native-r289/final/b646'
root='/home/lokad/lython-bench-checks/direct-ranges-b648-20261113'
oldroot='/home/lokad/lython-bench-checks/compile-result-b646-20261112'
identity=json.loads((r/'candidate-identity.json').read_text(encoding='utf-8'))
assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==h for p,h in identity['sources'].items())
for framework in ['net11.0','net10.0']:
 for phase,suite in [('growth','internal'),('focused','public')]:
  name=f'{phase}-{suite}-{framework}-'+('added-cases'if phase=='growth'else'fixture-update')+'.log'
  assert 'Failed:     0'in(r/name).read_text(encoding='utf-8')
info=json.loads((old/'identity.json').read_text(encoding='utf-8'));info['sourceRevision']=identity['head']+'; R293 direct range construction prototype; matched seven-script fixed worker; no dependency changes'
info['coreSHA256']={k:identity['referenceSHA256'if k.startswith('reference')else'coreSHA256']for k in ['reference','reference-control','candidate','candidate-control']}
info['sourceIdentitySHA256']=hashlib.sha256((r/'candidate-identity.json').read_bytes()).hexdigest()
jobs=[['scripts.text-summary-helpers.nonlocal-counter.large','warm'],['scripts.text-summary-helpers.nonlocal-counter.large','warm-async'],['scripts.csv-validated-records.large','warm'],['scripts.file-search.large','warm'],['scripts.text-summary-helpers.nonlocal-counter.large','compile'],['scripts.text-summary-helpers.nonlocal-counter.large','compile-run']]
collect=(old/'collect.py').read_text(encoding='utf-8').replace(oldroot,root)
start=collect.index('jobs=');end=collect.index('\nenv = ',start)
collect=collect[:start]+'jobs='+repr(jobs)+'\nassert len(jobs)==6 and all(case in cases for case,lane in jobs)\n'+collect[end:]
collect=collect.replace("labels=['reference','candidate','reference-control','candidate-control','CPython','CPython-control']","labels=['reference','candidate','reference-control','candidate-control']")
collect=collect.replace('12 if case_id=="scripts.text-summary-helpers.nonlocal-counter.large"','12 if lane!="compile" and case_id=="scripts.text-summary-helpers.nonlocal-counter.large"')
start=collect.index("purpose='");end=collect.index("',\n",start)
collect=collect[:start]+"purpose='Direct owned range construction; removes scratch reservation and final inventory copy; allocation flat in maintained scripts; captured both APIs/compile/compile-run with CSV and native-search controls"+collect[end:]
ast.parse(collect);(out/'collect.py').write_text(collect,encoding='utf-8',newline='\n')
archive=(old/'archive-owned.py').read_text(encoding='utf-8').replace(oldroot,root).replace("len(raw['jobs'])==1","len(raw['jobs'])==6").replace('complete=True,jobs=1','complete=True,jobs=6')
archive=archive.replace("path.name!='observations.tgz'","path.name not in {'observations.tgz','current-core.dll','candidate-sources.tar.xz'}")
archive=archive.replace('>240*1024*1024','>252*1024*1024')
ast.parse(archive);(out/'archive-owned.py').write_text(archive,encoding='utf-8',newline='\n')
(out/'run.sh').write_text('set -eu\nroot='+root+'\ntrap \'result=$?; printf "%s\\n" "$result" > "$root/exit-code.txt"\' EXIT\npython3 "$root/collect.py"\n',encoding='utf-8',newline='\n')
(out/'identity.json').write_text(json.dumps(info,indent=2)+'\n',encoding='utf-8',newline='\n')
files={name:out/name for name in ['collect.py','archive-owned.py','run.sh','identity.json']}
files.update({'current-core.dll':r/'candidate-core.dll','source-identity.json':r/'candidate-identity.json','candidate-sources.tar.xz':r/'candidate-sources.tar.xz'})
with tarfile.open(out/'payload.tgz','w:gz')as t:
 for name,p in files.items():t.add(p,arcname=name)
specs=json.loads((r/'space-inspection.json').read_text(encoding='utf-8'))['candidates']
assert all(row['exists']and row['links']==1 for row in specs)
config=dict(root=root,unit='lython-b648-direct-ranges-20261113',sourceRoot='/home/lokad/lython-bench-checks/ordered-native-b645-20261112',identity=info,retire=specs,payloadBytes=(out/'payload.tgz').stat().st_size,payloadSHA256=hashlib.sha256((out/'payload.tgz').read_bytes()).hexdigest(),unpackedBytes=sum(p.stat().st_size for p in files.values()))
(out/'config.json').write_text(json.dumps(config,indent=2)+'\n',encoding='utf-8',newline='\n')
print('Six jobs/four independent roles;420s owner/30s stop/30s margin. Staged bytes',config['unpackedBytes'],'payload RAM-only. Exact archived duplicates',sum(s['allocatedBytes']for s in specs),flush=True)
