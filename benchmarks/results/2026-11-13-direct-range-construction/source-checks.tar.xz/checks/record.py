from pathlib import Path
import hashlib,json,shutil,subprocess,tarfile
r=Path(__file__).parent;out=Path('benchmarks/results/2026-11-13-direct-range-construction');out.mkdir()
identity=json.loads((r/'candidate-identity.json').read_text(encoding='utf-8'))
assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==h for p,h in identity['sources'].items())
assert hashlib.sha256(Path('src/Lokad.Lython/bin/Release/net11.0/Lokad.Lython.dll').read_bytes()).hexdigest()==identity['coreSHA256']
for name in ['observations.tgz','summary.json','archive-receipt.json','terminal-status.json','config.json']:
 shutil.copyfile(r/'b648'/name,out/name)
patch=subprocess.check_output(['git','diff','--','src','tests']);(r/'implementation.patch').write_bytes(patch)
with tarfile.open(out/'source-checks.tar.xz','w:xz')as archive:
 for name in ['candidate-core.dll','candidate-identity.json','candidate-sources.tar.xz','implementation.patch','before.cs','preallocation-probe.cs']:
  archive.add(r/name,arcname=name)
 for p in sorted(r.iterdir()):
  if p.is_file()and p.suffix in ['.py','.log','.json']:archive.add(p,arcname='checks/'+p.name)
 for phase in ['warm-sync','warm-async','compile','fresh']:
  for name in ['stdout.json','stderr.log','summary.json']:archive.add(r/phase/name,arcname=phase+'/'+name)
 for p in sorted((r/'b648').iterdir()):
  if p.is_file()and p.suffix in ['.py','.json','.log','.sh']:archive.add(p,arcname='b648/'+p.name)
s=json.loads((out/'summary.json').read_text(encoding='utf-8'))
rows=[]
for row in s['timing']:
 a=row['changePercentRange'];b=row['processCpuChangePercentRange']
 rows.append(f'| {row["case"].removeprefix("scripts.")} /{row["lane"]} | {min(a):+.2f}..{max(a):+.2f}% | {min(b):+.2f}..{max(b):+.2f}% | {row["referenceControlPercent"]:.2f}% /{row["candidateControlPercent"]:.2f}% |')
(out/'README.md').write_text('''# Direct range construction — R293 / B648

2026-11-13. Reference: qualified2d91eb1a, core161cd935. Candidate:8c584c2d plus
R293, core9e53b9fa. Exact570-file source inventory, built binary, patch, test
sources/raw logs and driver observations are in [source/check evidence](source-checks.tar.xz).
Both images use the same immutable fec79 benchmark worker and optional adapter0.4.

## Change and ownership contract

One existing execution-owned word-range cache now serves private cased iteration
and larger ordinary whitespace/separator splits. Collection grows directly in its
loans; replacements are admitted while old backing is still funded, then the old
loan returns. This removes growing scratch reservation/counter plumbing and the
private cursor's final inventory copy:12 net production lines removed, no new
pool, owner, configuration or backend. Small ordinary splits retain stack storage.
Private iteration starts with an eight-range loan, including empty input.

Idle inventory capacity stays charged until execution cleanup; oversized reuse and
minimum capacity can reject tighter allowances earlier. Final words/list backing
remain eagerly admitted before loop effects. Retained strings are independently
funded after cache shutdown. Active cursors keep loans until their actual users
finish, including cancellation and pending cleanup. First refusal remains terminal.

Focused actual.NET11/.NET10 checks:114 internal /431 public per target for affected
semantics, plus714 internal /183 public per target for broader admission/ownership
and cancellation. These are overlapping suites, not unique-test totals. Full seven
scripts pass sync/async, compile and compile-to-result goldens, zero final balances
and owned cleanup. Four new interrupted-growth cases and larger overlapping loans
pass. Two fixture adaptations preserve exact post-cache refund balances and Python
binding observation; refund tests no longer require an internal three-slot size.
The first fixture failures survive. A separate bounded cancellation-allocation
probe passed without an extra guard and is preserved only in experimental evidence.

## Controlled comparison

Quiet Azure F4as_v7 /Ubuntu24.04.4, actual.NET11RC3, normal GC/tiering. Four independent
reference/candidate/control processes, seven rotated500ms batches per job;12-second
captured-text warmup (five seconds for compilation/other controls). Complete text
input3,072 lines /35,840B; CSV5,120 records /68,625B. Compilation is separate. Warm
and compile-to-result include mediated RAM-file I/O, full stdout/file validation
and prior-result cleanup, excluding process startup, fixture reset/protocol and
final cache shutdown. Wider CPU includes outside-clock worker work. Ranges are all
four process-median source pairings, not confidence intervals.

| Complete script /lane | Elapsed change | Wider CPU change | Reference /candidate control spread |
| --- | ---: | ---: | ---: |
'''+ '\n'.join(rows)+'''

Whole-script allocation is effectively flat; source compilation allocation is
unchanged. The controlled compile-to-result row supports a roughly4–9% elapsed
improvement, with CPU support. Warm text crosses zero. CSV/search controls move
substantially; CSV elapsed−0.53..+5.75%/CPU−0.80..+8.01% does not establish equivalence
or isolate a regression. Preserve that uncertainty rather than claiming a universal
CPU win. No new CPython comparison is inferred from this source pair.

Retain the common construction/deletion and source-supported compile-to-result
benefit. Warm/CSV uncertainty remains delivery debt for later coherent checkpoints;
it does not trigger another small timing campaign or finish the performance goal.
Full platform/stress/consumer qualification is pending at this evidence commit.
Publication remains held.

## Custody

Six jobs complete in320.712s under420s owner/30s stop/30s margin. Quiet gates,
outputs/balances, Closed/exit0, all joined users, RAM unmount and independently
verified persistent/local archive SHA pass. Input binary/sources are separately
preserved above; the raw archive does not duplicate those large inputs. Under a
fresh idle lease, exact task-owned archive/profile duplicates already committed in
Git were retired with path/UID/inode/link/size/SHA proofs. Current reference images
were protected; OS240MiB/evidence12MiB floors stayed unchanged. Terminal state is
cached; final owned free space265629696B, no workers or RAM fixtures remain.

[Raw observations](observations.tgz), [summary](summary.json),
[receipt](archive-receipt.json), [terminal status](terminal-status.json),
[exact identities](config.json). No RSS or embedding-tail claim.
''',encoding='utf-8',newline='\n')
p=Path('benchmarks/EXPERIMENTS.md');p.write_text(p.read_text(encoding='utf-8')+'''

## R293 — direct range construction

[Shared existing construction buffers](results/2026-11-13-direct-range-construction/README.md)
remove scratch reservations/counters and the private inventory copy (12 net production
lines). All affected/ownership/cancellation checks and seven-script boundaries pass.
B648 six-job quiet comparison completes320.712s with all custody gates. Allocation
is flat. Captured compile-to-result improves3.61–9.06% elapsed /4.37–7.67% wider CPU;
warm results cross zero and adverse/moving CSV/search controls remain explicit.
Retain the common ownership simplification; do not claim universal CPU improvement.
Minimum/idle capacity can deny earlier. Full delivery remains pending separately.
''',encoding='utf-8',newline='\n')
print('Frozen R293 evidence recorded, runtime sources match timed9e53b9fa; full delivery pending.',flush=True)
