from pathlib import Path
import ast
r=Path(__file__).parent/'b648';old=r.parent.parent/'ordered-native-r289/final/b646'
source=(old/'retrieve.py').read_text(encoding='utf-8')
source=source.replace('compile-result-b646-20261112','direct-ranges-b648-20261113').replace('lython-b646-compile-result-20261112','lython-b648-direct-ranges-20261113').replace("['jobs']==1","['jobs']==6").replace("['elapsedSeconds']<180","['elapsedSeconds']<480").replace('B646 corrected one-job','B648 six-job')
ast.parse(source);(r/'retrieve.py').write_text(source,encoding='utf-8',newline='\n')
(r/'summarize.py').write_text((old.parent.parent/'refined/b644/summarize.py').read_text(encoding='utf-8'),encoding='utf-8',newline='\n')
