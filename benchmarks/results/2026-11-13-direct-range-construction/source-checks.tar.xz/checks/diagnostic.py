from pathlib import Path
import hashlib,json,os,subprocess,sys
r=Path(__file__).parent
phase=sys.argv[1];assert phase in ('warm-sync','warm-async','fresh','compile')
identity=json.loads((r/'candidate-identity.json').read_text(encoding='utf-8'))
assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==h for p,h in identity['sources'].items())
out=r/phase
if out.exists():assert not list(out.iterdir())
else:out.mkdir()
witness=out/'witness.json';witness.write_bytes((r.parent/'bulk-utf16-r276/refined/warm-sync/hash-witness.json').read_bytes())
sdk=Path('C:/Users/JoannesVermorel/.dotnet11');env=os.environ.copy();env['DOTNET_ROOT']=str(sdk);env['PATH']=str(sdk)+';C:/Python313;'+env['PATH']
args=[str(sdk/'dotnet.exe'),str(r/'tool/bin/Release/net11.0/complete-jobs.dll'),str(r/'reference/Lokad.Lython.Benchmarks.dll'),str(r/'candidate/Lokad.Lython.Benchmarks.dll'),str(r/'catalog.json'),str(witness),'forward','warm'if phase.startswith('warm')else phase]
if phase=='warm-async':args.append('async')
with(out/'stdout.json').open('w',encoding='utf-8',newline='\n')as stdout, (out/'stderr.log').open('w',encoding='utf-8',newline='\n')as stderr:
    done=subprocess.run(args,env=env,stdout=stdout,stderr=stderr)
assert done.returncode==0,(out/'stderr.log').read_text(encoding='utf-8')
data=json.loads((out/'stdout.json').read_text(encoding='utf-8'))
assert data['allGoldensPassed']and data['allBalancesZero']and data['ownedFixturesRemoved']
print(phase,': seven full scripts/goldens/ownership/cleanup pass; clocks diagnostic only.',flush=True)
