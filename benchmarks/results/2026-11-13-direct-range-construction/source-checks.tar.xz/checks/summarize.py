from pathlib import Path
import runpy
r=Path(__file__).parent
source=(r.parent/'ordered-native-r289/refined/summarize.py').read_text(encoding='utf-8')
exec(compile(source,str(r/'summarize-implementation.py'),'exec'),{'__file__':str(r/'summarize-implementation.py')})
