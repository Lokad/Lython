from pathlib import Path
r=Path(__file__).parent;p=Path('tests/Lokad.Lython.Tests/CasedSplitOwnershipTests.cs');s=p.read_text(encoding='utf-8')
(r/'preallocation-probe.cs').write_text(s,encoding='utf-8',newline='\n')
start=s.index('    private readonly Xunit.Abstractions.ITestOutputHelper')
end=s.index('    [Theory]',start)
s=s[:start]+s[end:]
p.write_text(s,encoding='utf-8',newline='\n')
print('Bounded probe retained privately with raw logs; no demonstrated missing guard, so no extra runtime mechanism or speculative allocation test retained.')
