from pathlib import Path
import hashlib,json,os,shutil,subprocess,tarfile
r=Path(__file__).parent;old=r.parent/'ordered-native-r289/final'
digest=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
names=subprocess.check_output(['git','ls-files','src/Lokad.Lython'],text=True).splitlines()
sources={p:digest(Path(p))for p in names}
for role in ['reference','candidate']:
 shutil.copytree(old/'candidate',r/role,copy_function=os.link)
(r/'candidate/Lokad.Lython.dll').unlink();shutil.copyfile('src/Lokad.Lython/bin/Release/net11.0/Lokad.Lython.dll',r/'candidate/Lokad.Lython.dll')
assert digest(r/'reference/Lokad.Lython.dll')=='161cd935023fd95a08488cbf7cfa3ee02ea4b88c69c0ba1231299b6ef0d80447'
shutil.copyfile(r/'candidate/Lokad.Lython.dll',r/'candidate-core.dll')
with tarfile.open(r/'candidate-sources.tar.xz','w:xz')as archive:
 for p in sources:archive.add(p,arcname=p)
identity=dict(head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()+' plus R293 direct range construction',sources=sources,coreSHA256=digest(r/'candidate-core.dll'),referenceSHA256=digest(r/'reference/Lokad.Lython.dll'))
(r/'candidate-identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8',newline='\n')
shutil.copyfile(old/'catalog.json',r/'catalog.json');shutil.copytree(old/'tool',r/'tool',copy_function=os.link)
code=(old/'diagnostic.py').read_text(encoding='utf-8').replace("r.parent.parent/'bulk-utf16-r276", "r.parent/'bulk-utf16-r276")
(r/'diagnostic.py').write_text(code,encoding='utf-8',newline='\n')
for phase in ['warm-sync','warm-async','compile','fresh']:
 subprocess.run(['python','-X','utf8',str(r/'diagnostic.py'),phase],check=True)
print('Frozen',identity['coreSHA256'],'all phases/goldens/balances/cleanup pass.',flush=True)
