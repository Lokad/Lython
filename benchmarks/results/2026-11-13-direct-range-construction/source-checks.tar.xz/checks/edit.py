from pathlib import Path
import re
r=Path(__file__).parent;p=Path('src/Lokad.Lython/Runtime/Text/PyStringOps.Whitespace.cs')
s=p.read_text(encoding='utf-8');(r/'before.cs').write_text(s,encoding='utf-8',newline='\n')
start=s.index('        Span<(int Start, int End, int Capacity)> ranges = stackalloc',s.index('internal static CasedWhitespaceIteration Prepare'))
end=s.index('\n    internal sealed class CasedWhitespaceIteration',start)
s=s[:start]+'''        var prepared = context.MemoryGovernor.RentWordRanges(8, span);
        Span<(int Start, int End, int Capacity)> ranges = prepared;
        var count = 0;
        long outputBytes = 0;
        try
        {
            CollectWhitespaceForward(value.Utf8Span, -1, ref ranges, ref count, ref outputBytes,
                ref prepared, context.MemoryGovernor, span, context, mapping);
            var bytes = checked(128 + outputBytes); // cursor and all eventual words
            using var storage = context.MemoryGovernor.ReserveTemporary(bytes, span);
            context.CheckExecution(span);
            var result = new CasedWhitespaceIteration(value, upper, context, span, prepared, count);
            storage.Commit(bytes);
            prepared = null;
            return result;
        }
        finally { if (prepared is not null) context.MemoryGovernor.ReturnWordRanges(prepared, count); }
    }
''' +s[end:]
s=s.replace('long outputBytes = 0, scratchBytes = 0;\n        MemoryGovernor.TemporaryMemoryReservation? scratch = null;',
'''long outputBytes = 0;
        (int Start, int End, int Capacity)[]? prepared = null;''')
s=s.replace('ref scratchBytes, ref scratch, governor, span, context','ref prepared, governor, span, context')
s=s.replace('finally { scratch?.Dispose(); }','finally { if (prepared is not null) governor?.ReturnWordRanges(prepared, count); }')
s=s.replace('ref int count, ref long outputBytes, ref long scratchBytes,\n        ref MemoryGovernor.TemporaryMemoryReservation? scratch, MemoryGovernor? governor,',
'''ref int count, ref long outputBytes,
        ref (int Start, int End, int Capacity)[]? prepared, MemoryGovernor? governor,''')
# Separated scanner has the same signature split across different lines.
s=s.replace('ref int count, ref long outputBytes, ref long scratchBytes,\n        ref MemoryGovernor.TemporaryMemoryReservation? scratch, MemoryGovernor? governor, LythonSourceSpan? span,',
'''ref int count, ref long outputBytes,
        ref (int Start, int End, int Capacity)[]? prepared, MemoryGovernor? governor, LythonSourceSpan? span,''')
s=s.replace('ref long outputBytes, ref long scratchBytes,\n        ref MemoryGovernor.TemporaryMemoryReservation? scratch, MemoryGovernor? governor,',
'''ref long outputBytes,
        ref (int Start, int End, int Capacity)[]? prepared, MemoryGovernor? governor,''')
start=s.index('            var bytes = checked(32L + 16L * capacity);',s.index('private static void AppendSplitRange'))
end=s.index('\n        }\n        var outputCapacity',start)
s=s[:start]+'''            context?.CheckExecution(span);
            // Keep the previous loan funded through admission and copying. The
            // execution cache owns returned capacity; active cursors own loans.
            var replacement = governor is null
                ? new (int Start, int End, int Capacity)[capacity]
                : governor.RentWordRanges(capacity, span);
            var previous = prepared;
            ranges[..count].CopyTo(replacement);
            prepared = replacement;
            ranges = replacement;
            if (previous is not null) governor?.ReturnWordRanges(previous, count);''' +s[end:]
s=s.replace('// Fixed, memory-safe stack scratch; larger results admit their backing\n        // through the existing reservation before allocating a replacement.',
'''// Small splits use fixed stack storage. Larger inventories grow directly
        // in admitted execution-owned buffers shared with private iteration.''')
assert 'scratch'not in s,[(i+1,l)for i,l in enumerate(s.splitlines())if 'scratch'in l]
p.write_text(s,encoding='utf-8',newline='\n')
print('Edited range construction:',len(s.splitlines())-len((r/'before.cs').read_text(encoding='utf-8').splitlines()),'net lines',flush=True)
