from pathlib import Path
import json,subprocess,hashlib,tarfile
r=Path(__file__).parent
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
specs=[]
for canonical,remote in [
 ('benchmarks/results/2026-11-12-ordered-final-slots/final/b645/observations-partial.tgz','ordered-native-b645-20261112/observations-partial.tgz'),
 ('benchmarks/results/2026-11-13-captured-current-cpu/observations.tgz','captured-cpu-b647-20261112/observations.tgz')]:
 p=Path(canonical);blob=subprocess.check_output(['git','show','HEAD:'+p.as_posix()]);assert blob==p.read_bytes()
 specs.append(dict(path=remote,bytes=len(blob),sha256=hashlib.sha256(blob).hexdigest(),canonical=canonical))
 if 'cpu' in canonical:
  with tarfile.open(p)as archive:
   for name in ['profiles/captured-text/perf.map','profiles/captured-text/perf.data','profiles/captured-text/perf-stacks.txt','profiles/captured-text/perf-report.txt']:
    blob=archive.extractfile(name).read()
    specs.append(dict(path='captured-cpu-b647-20261112/'+name,bytes=len(blob),sha256=hashlib.sha256(blob).hexdigest(),canonical=canonical+'!'+name))
(r/'retire-candidates.json').write_text(json.dumps(specs,indent=2)+'\n',encoding='utf-8',newline='\n')
code='''from pathlib import Path
import fcntl,hashlib,json,os,shutil,stat,subprocess
base=Path('/home/lokad/lython-bench-checks')
with(base/'comparison-vm.lock').open('a')as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 users=subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record|[p]ython3.*cpython-worker.py'],capture_output=True,text=True)
 assert users.returncode==1,users.stdout
 rows=[]
 for spec in SPECS:
  p=base/spec['path'];row=dict(spec,exists=p.exists())
  if p.exists():
   s=p.lstat();assert p.resolve()==p and stat.S_ISREG(s.st_mode)
   row.update(uid=s.st_uid,links=s.st_nlink,allocatedBytes=s.st_blocks*512,inode=s.st_ino,device=s.st_dev)
   assert s.st_size==spec['bytes']and hashlib.sha256(p.read_bytes()).hexdigest()==spec['sha256']
  rows.append(row)
 print(json.dumps(dict(freshIdleLease=True,freeBytes=shutil.disk_usage(base).free,candidates=rows)))
'''.replace('SPECS',repr(specs))
done=subprocess.run(ssh+['python3 -'],input=code,capture_output=True,text=True,encoding='utf-8');assert done.returncode==0,done.stderr
(r/'space-inspection.json').write_text(done.stdout,encoding='utf-8');d=json.loads(done.stdout)
print('Read-only idle-lease inspection: free',d['freeBytes'],'known duplicates',[(x['path'],x.get('allocatedBytes'),x.get('links'),x['exists'])for x in d['candidates']],flush=True)
