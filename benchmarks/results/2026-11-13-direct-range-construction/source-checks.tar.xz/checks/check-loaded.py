from pathlib import Path
import hashlib
for name in ['src/Lokad.Lython/bin/Release/net11.0/Lokad.Lython.dll','tests/Lokad.Lython.Tests/bin/Release/net11.0/Lokad.Lython.dll','tests/Lokad.Lython.PublicApi.Tests/bin/Release/net11.0/Lokad.Lython.dll']:
 print(name,hashlib.sha256(Path(name).read_bytes()).hexdigest())
