from hashlib import sha256
from pathlib import Path
from shutil import copy2
import json
import tarfile

lab=Path(__file__).resolve().parent
local=lab.parent/'module-surface-storage-b1947-20261128/comparison'
donor=lab.parent/'current-shipment-checkpoint-b1943-20261128/comparison/quiet'
procedures=lab.parent/'matched-shipment-control-b1944-20261128'
quiet=lab/'comparison/quiet'
read=lambda p:json.loads(p.read_bytes())
digest=lambda p:sha256(p.read_bytes()).hexdigest()
files=lambda folder:{p.name:digest(p) for p in folder.iterdir()}
def write(p,s):
    p.write_text(s,encoding='utf-8',newline='\n')
    assert b'\r' not in p.read_bytes()
def js(p,data): write(p,json.dumps(data,indent=2)+'\n')
identity=read(local/'identity.json')
term=read(donor/'terminal-status.json')
assert term['exitCode']=='0' and not term['live'] and not term['fixtures']
receipt=term['receipt']
assert receipt['complete'] and receipt['allWorkersJoined'] and receipt['quietBeforeAndAfter']
assert digest(donor/'observations.tar.xz')==receipt['archiveSHA256']
donor_images=read(donor/'identity.json')['imageFiles']['candidate']
assert len(donor_images)==32 and files(donor/'local-image')==donor_images
for role,image in identity['imageFiles'].items():
    assert len(image)==32 and files(local/role)==image
    assert {name for name,value in image.items() if value!=donor_images[name]}=={'Lokad.Lython.dll'}
    proof=read(local/f'{role}-verify.json')
    assert proof['state']=='Completed' and proof['caseCount']==4
    assert proof['catalogSha256']==identity['catalogs']['representative.json']['sha256']
    assert proof['launched']['library']['sha256']==image['Lokad.Lython.dll']
    assert proof['launched']['adapter']['sha256']==image['Lokad.Lython.Benchmarks.dll']
    assert proof['launched']['python']['sha256']==identity['expectedCPythonSHA256']
quiet.mkdir(parents=True)
for name in ('representative.json','cpython-worker.py'):
    copy2(local/name,quiet/name)
copy2(donor/'run.sh',quiet/'run.sh')
assert b'\r' not in (quiet/'run.sh').read_bytes()
jobs=[['xml.parse-select.small','compile-run'],['scripts.config-edit.small','compile']]
assert all(job in read(local/'jobs.json')['warm'] for job in jobs)
js(quiet/'jobs.json',jobs)
identity.update(referenceRevision='b2aed5489', purpose='Confirm warm XML and configuration on the existing module-surface images.',
    frozenImage='/home/lokad/lython-bench-checks/script-module-surfaces-b1948-20261128/candidate', donorArchiveSHA256=receipt['archiveSHA256'])
identity['catalogs']={name:{'sha256':digest(quiet/name)} for name in ('representative.json','jobs.json')}
js(quiet/'identity.json',identity)
collector=(procedures/'comparison/quiet/collect.py').read_text(encoding='utf-8')
assert 'len(jobs) == 2' in collector
write(quiet/'collect.py',collector.replace('lython-b1944-matched-fixtures','lython-b1948-module-surfaces-fixtures'))
paths={name:quiet/name for name in ('identity.json','jobs.json','representative.json','collect.py','run.sh','cpython-worker.py')}
paths.update({f'{role}/Lokad.Lython.dll':local/role/'Lokad.Lython.dll' for role in ('reference','candidate')})
payload=quiet/'stage.tar.gz'
with tarfile.open(payload,'w:gz') as bundle:
    for name,path in paths.items(): bundle.add(path,arcname=name)
with tarfile.open(payload) as bundle:
    assert all(sha256(bundle.extractfile(name).read()).hexdigest()==digest(path) for name,path in paths.items())
upload=dict(root='script-module-surfaces-b1948-20261128',donor=read(donor/'upload.json')['root'],donorFiles=donor_images,
    donorArchive=receipt['archiveSHA256'],payloadSHA256=digest(payload),
    files={name:dict(length=p.stat().st_size,sha256=digest(p)) for name,p in paths.items()},
    expandedBytes=sum(p.stat().st_size for p in paths.values()),minimumAfterStageBytes=16*1024*1024,caseCount=4)
js(quiet/'upload.json',upload)
launch=(lab.parent/'quiet-generator-outer-20261127/quiet-vm.py').read_text(encoding='utf-8')
write(lab/'quiet-vm.py',launch.replace('lython-b1895-generator-outer-quiet','lython-b1948-module-surfaces'))
print('Two unchanged warm lanes prepared with the exact original images.')
