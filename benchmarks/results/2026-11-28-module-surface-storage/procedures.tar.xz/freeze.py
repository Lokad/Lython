from hashlib import sha256
from pathlib import Path
from shutil import copy2, copytree
from subprocess import check_output
import json

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
reference=lab.parent/'private-generator-layout-b1945-20261128/comparison'
commands=lab.parent/'frontend-contract-sections-20261123/comparison'
prior_catalog=lab.parent/'module-callable-reexports-b1929-20261128'
pair=lab/'comparison'
build=lab/'ubuntu-artifacts/bin/Lokad.Lython/release_net11.0/Lokad.Lython.dll'
read=lambda p:json.loads(p.read_bytes())
digest=lambda p:sha256(p.read_bytes()).hexdigest()
files=lambda folder:{p.name:digest(p) for p in folder.iterdir()}

def git(*args): return check_output(['git',*args],cwd=repo)
def write(path,data): path.write_text(json.dumps(data,indent=2,ensure_ascii=False)+'\n',encoding='utf-8',newline='\n')

old=read(reference/'identity.json')
head=git('rev-parse','HEAD').decode().strip()
assert sha256(git('diff','--binary',old['sourceRevision'],head,'--','src/Lokad.Lython')).hexdigest()==old['sourcePatchSHA256']
assert not git('diff','--binary',old['sourceRevision'],'--','src/Lokad.Lython.Utf8Regex','Directory.Packages.props','tests')
original=files(reference/'candidate')
assert len(original)==32 and original==old['imageFiles']['candidate']
pair.mkdir()
for role in ('reference','candidate'): copytree(reference/'candidate',pair/role)
copy2(build,pair/'candidate/Lokad.Lython.dll')
images={role:files(pair/role) for role in ('reference','candidate')}
assert images['reference']==original and not (pair/'candidate/Lokad.Lython.dll').samefile(build)
assert {name for name,checksum in original.items() if images['candidate'][name]!=checksum}=={'Lokad.Lython.dll'}
patch=git('diff','--binary',head,'--','src/Lokad.Lython')
assert patch.count(b'diff --git ')==1 and b'Array.BinarySearch' in patch
(lab/'candidate.patch').write_bytes(patch)

catalog=read(commands/'representative.json')
selected=['scripts.config-edit.small','scripts.csv-meter-report.typed-ascii','xml.parse-select.small','compiler.generated-read-only-branches']
cases={case['id']:case for case in catalog['cases']}
catalog['cases']=[cases[name] for name in selected]
write(pair/'representative.json',catalog)
for name,key in [('config.json',selected[0]),('xml.json',selected[2])]:
    write(pair/name,dict(catalog,cases=[cases[key]]))
config, csv, xml, control=selected
jobs=[(config,'compile'),(config,'compile-run'),(csv,'compile'),(xml,'compile-run'),(control,'compile')]
write(pair/'jobs.json',{'warm':jobs})
for name in ('collect.py','run.sh','cpython-worker.py'): copy2(reference/name,pair/name)
collector=pair/'collect.py'
code=collector.read_text(encoding='utf-8')
assert code.count('len(jobs) == 6')==1
collector.write_text(code.replace('len(jobs) == 6','len(jobs) == 5'),encoding='utf-8',newline='\n')
assert b'\r' not in (pair/'run.sh').read_bytes()
assert digest(pair/'cpython-worker.py')==old['cpythonWorkerSHA256']
write(pair/'identity.json',dict(sourceRevision=head,sourcePatchSHA256=sha256(patch).hexdigest(),imageFiles=images,
    coreSHA256={role+suffix:hashes['Lokad.Lython.dll'] for role,hashes in images.items() for suffix in ('','-control')},
    cpythonWorkerSHA256=old['cpythonWorkerSHA256'],expectedCPythonSHA256=old['expectedCPythonSHA256'],
    purpose='Share sorted frontend membership storage and lazily materialize filtered module exports.',
    catalogs={name:{'sha256':digest(pair/name)} for name in ('representative.json','jobs.json','config.json','xml.json')}))
cold=(prior_catalog/'collect-cold.py').read_text(encoding='utf-8')
cold=cold.replace('module-reexports-b1929-20261128','module-surface-storage-b1947-20261128').replace('workbook.json','xml.json')
(lab/'collect-cold.py').write_text(cold,encoding='utf-8',newline='\n')
copy2(lab.parent/'private-generator-sum-b1940-20261128/summarize.py',lab/'summarize-warm.py')
print(head, len(jobs), 'warm lanes and two first-command scripts frozen')
