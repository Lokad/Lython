from hashlib import sha256
from pathlib import Path
from resource import RUSAGE_CHILDREN,getrusage
from shutil import copyfile,copytree
from statistics import median,quantiles
from tempfile import TemporaryDirectory
from time import perf_counter_ns
import json
import os
import subprocess

lab=Path(__file__).resolve().parent
pair=lab/'comparison'
root=Path.home()/'lython-bench-work/module-surface-storage-b1947-20261128'
read=lambda p:json.loads(p.read_bytes())
digest=lambda path:sha256(path.read_bytes()).hexdigest()
def write(path,value):
    path.write_text(json.dumps(value,indent=2)+'\n',encoding='utf-8',newline='\n')

identity=read(pair/'identity.json')
dotnet=Path.home()/'.dotnet/dotnet'
worker='Lokad.Lython.Benchmarks.dll'
def assert_image(folder,role):
    assert {p.name:digest(p) for p in folder.iterdir()}==identity['imageFiles'][role]
root.mkdir(parents=True,exist_ok=True)
assert os.stat(root).st_dev!=os.stat(lab).st_dev and os.stat(root).st_dev!=os.stat('/dev/shm').st_dev
for role in ('reference','candidate'):
    assert_image(pair/role,role)
    if not (root/role).exists(): copytree(pair/role,root/role)
    assert_image(root/role,role)
for name in ('config.json','xml.json'):
    if not (root/name).exists(): copyfile(pair/name,root/name)
    assert digest(root/name)==identity['catalogs'][name]['sha256']

env={key:value for key,value in os.environ.items() if not key.startswith(('DOTNET_','COMPlus_'))}
env.update(DOTNET_ROOT=str(dotnet.parent),TMPDIR='/dev/shm',LC_ALL='C.UTF-8')
cases={file:read(root/file)['cases'][0] for file in ('config.json','xml.json')}
def cpu():
    stats=getrusage(RUSAGE_CHILDREN)
    return (stats.ru_utime+stats.ru_stime)*1000

def run(role,name,round_number):
    with TemporaryDirectory(dir='/dev/shm',prefix='lython-comparison-files-') as fixture:
        before=cpu()
        started=perf_counter_ns()
        child=subprocess.run([dotnet,root/role/worker,'--compare','once','--catalog',root/name],
                             cwd=fixture,env=env,stdin=subprocess.DEVNULL,stdout=subprocess.PIPE,
                             stderr=subprocess.PIPE,timeout=30)
        elapsed=(perf_counter_ns()-started)/1e6
        child_cpu=cpu()-before
        assert child.returncode==0 and not child.stderr,(child.returncode,child.stderr)
        assert len(child.stdout)>4 and int.from_bytes(child.stdout[:4],'big')==len(child.stdout)-4
        frame=json.loads(child.stdout[4:])
        command=frame['response']
        case=cases[name]
        assert all(command[key]==case[key] for key in ('caseId','sourceSha256','fixtureSha256','expectedOutputSha256') if key!='caseId')
        assert command['caseId']==case['id'] and command['status']=='Equivalent' and command['completedInvocations']==1,command
        assert command['actualOutputSha256']==case['expectedOutputSha256']
        assert command.get('actualFilesSha256')==case.get('expectedFilesSha256')
        startup=frame['identity']
        assert startup['catalogSha256']==identity['catalogs'][name]['sha256'] and startup['runtimeVersion']=='11.0.0'
        files={Path(item['path']).name:Path(item['path']) for item in startup['libraries']}
        assert files['Lokad.Lython.dll']==root/role/'Lokad.Lython.dll' and files[worker]==root/role/worker
    assert not Path(fixture).exists()
    return dict(role=role,case=case['id'],round=round_number,elapsed=elapsed,cpu=child_cpu,frame=frame)

rows=[]
warm=[run(role,name,-1) for name in cases for role in ('reference','candidate')]
for batch in range(12):
    files=list(cases) if batch%2==0 else list(reversed(cases))
    for j,name in enumerate(files):
        roles=('reference','candidate') if (batch//2+j)%2==0 else ('candidate','reference')
        for role in roles:rows.append(run(role,name,batch))
    write(lab/'cold-observations.json',dict(priming=warm,rows=rows,completedRounds=batch+1,stage=str(root)))
for role in ('reference','candidate'): assert_image(root/role,role)
summary=[]
for case in cases.values():
    selected=[row for row in rows if row['case']==case['id']]
    observations={}
    for clock in ('elapsed','cpu'):
        groups={role:[row[clock] for row in selected if row['role']==role] for role in ('reference','candidate')}
        medians={role:median(values) for role,values in groups.items()}
        iqr={role:quantiles(series,n=4,method='inclusive')[::2] for role,series in groups.items()}
        changes=[100*(new/old-1) for old,new in zip(groups['reference'],groups['candidate'],strict=True)]
        observations[clock]=dict(median=medians,iqr=iqr,medianChange=100*(medians['candidate']/medians['reference']-1),
            pairedRange=[min(changes),max(changes)])
    summary.append(dict(case=case['id'],**observations))
    print(case['id'],observations,flush=True)
write(lab/'cold-summary.json',dict(candidatePatchSHA256=identity['sourcePatchSHA256'],observations=summary,
    verifiedInvocations=len(rows),nativePersistentStage=str(root),cpuAffinity=sorted(os.sched_getaffinity(0))))
