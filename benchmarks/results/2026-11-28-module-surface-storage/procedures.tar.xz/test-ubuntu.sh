#!/usr/bin/env bash
set -euo pipefail
export DOTNET_ROOT="$HOME/.dotnet"
export PATH="$DOTNET_ROOT:$PATH"
cd /mnt/d/code/Lython
lab="$PWD/.git/agent-notes/review-20261031/module-surface-storage-b1947-20261128"
export NUGET_PACKAGES="$PWD/.git/agent-notes/review-20261031/regex-released-050-20261127/packages-ubuntu"
filter='Category!=Stress&(FullyQualifiedName~Static|FullyQualifiedName~ModuleContractParity|FullyQualifiedName~OpenPyxl|FullyQualifiedName~ModuleValidation|FullyQualifiedName~Import|FullyQualifiedName~CompilerMemory|FullyQualifiedName~AdmissionFailureCommandTests)'
dotnet build src/Lokad.Lython/Lokad.Lython.csproj -c Release -f net11.0 --artifacts-path "$lab/ubuntu-artifacts" --no-incremental --disable-build-servers > "$lab/ubuntu-core-build.log" 2>&1 || { tail -60 "$lab/ubuntu-core-build.log"; exit 1; }
for suite in Lokad.Lython.PublicApi.Tests Lokad.Lython.Tests; do
    dotnet test "tests/$suite/$suite.csproj" -c Release -f net11.0 --artifacts-path "$lab/ubuntu-artifacts" --filter "$filter" 2>&1 | tee "$lab/ubuntu-$suite-net11.0.log"
done
