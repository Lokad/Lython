from hashlib import sha256
from pathlib import Path
from shutil import copy2
from subprocess import check_output
import json
import re
import tarfile

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
pair=lab/'comparison'
out=repo/'benchmarks/results/2026-11-28-module-surface-storage'
read=lambda p:json.loads(p.read_bytes())
digest=lambda p:sha256(p.read_bytes()).hexdigest()
identity=read(pair/'identity.json')
assert digest(lab/'candidate.patch')==identity['sourcePatchSHA256']
assert check_output(['git','diff','--binary',identity['sourceRevision'],'--','src/Lokad.Lython'],cwd=repo)==(lab/'candidate.patch').read_bytes()
assert not check_output(['git','diff','--binary',identity['sourceRevision'],'--','tests'],cwd=repo)
for role,expected in identity['imageFiles'].items():
    assert len(expected)==32 and {p.name:digest(p) for p in (pair/role).iterdir()}==expected
assert {n for n,h in identity['imageFiles']['reference'].items() if identity['imageFiles']['candidate'][n]!=h}=={'Lokad.Lython.dll'}
warm=read(pair/'summary.json')
assert warm['verifiedTimedBatches']==140 and len(warm['rows'])==5
receipt=read(pair/'archive-receipt.json')
assert all(receipt[k] for k in ('complete','allWorkersJoined','guestFixturesRemoved','archivedAndVerifiedUnderLease'))
assert receipt['archiveSHA256']==digest(pair/'observations.tar.xz')
cold=read(lab/'cold-summary.json')
assert cold['candidatePatchSHA256']==identity['sourcePatchSHA256'] and cold['verifiedInvocations']==48
assert cold['cpuAffinity']==[27]
observations=read(lab/'cold-observations.json')
assert observations['completedRounds']==12 and len(observations['rows'])==48 and len(observations['priming'])==4
assert all(row['frame']['response']['status']=='Equivalent' for row in observations['rows']+observations['priming'])
alloc=read(lab/'allocation.json')
assert alloc['verifiedCompilations']==28 and len(alloc['summary'])==2
for row in alloc['summary']:
    assert row['admitted'][0]==row['admitted'][1] and row['after']==[0,0]
match=read(lab/'candidate-modules.json')
assert match==read(lab/'reference-modules.json') and len(match['modules'])==66
assert sum(len(row['names']) for row in match['rows'])==874
assert sum(len(row['exports']) for row in match['rows'])==871
assert sum(len(row['queries']) for row in match['rows'])==2138 and len(match['diagnostics'])==13
logs=sorted(lab.glob('*-Lokad.Lython.*Tests-net*.log'))
assert len(logs)==6
for log in logs:
    count=691 if 'PublicApi' in log.name else 67
    assert re.search(rf'Failed: +0, Passed: +{count}, Skipped: +0',log.read_text(encoding='utf-8-sig')),log
out.mkdir(exist_ok=True)
artifacts={name:pair/name for name in ('identity.json','summary.json','archive-receipt.json','observations.tar.xz')}
artifacts.update({name:lab/name for name in ('cold-summary.json','allocation.json')})
for name,path in artifacts.items():
    copy2(path,out/name)
    assert digest(out/name)==digest(path)
files={log.name:log for log in logs}
files.update({name:pair/name for name in ('config.json','xml.json','candidate-verify.json','reference-verify.json','collection.log','exit-code.txt')})
files.update({name:lab/name for name in ('freeze.py','candidate.patch','test-ubuntu.sh','test-windows.ps1','ubuntu-core-build.log',
    'measure-allocations.py','collect-cold.py','summarize-warm.py','publish.py','cold-collection.log','cold-observations.json',
    'candidate-modules.json','reference-modules.json','initial-cold-verifier.log')})
files.update({f'probe/{name}':lab/'probe'/name for name in ('ModuleProbe.csproj','Program.cs','build.log')})
with tarfile.open(out/'procedures.tar.xz','w:xz') as bundle:
    for name,path in files.items(): bundle.add(path,arcname=name)
with tarfile.open(out/'procedures.tar.xz') as bundle:
    assert all(digest(path)==sha256(bundle.extractfile(name).read()).hexdigest() for name,path in files.items())
print('Consolidated module surface evidence verified and saved.')
