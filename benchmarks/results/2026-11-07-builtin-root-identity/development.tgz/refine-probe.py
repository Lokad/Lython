from pathlib import Path
import subprocess,sys
root=Path(__file__).parent
for name in ['probe.jsonl','sources.json']:
 (root/('initial-'+name)).write_bytes((root/name).read_bytes())
t=(root/'probe.py').read_text(encoding='utf-8').replace("print(type(error).__name__,str(error))","print('blocked',str(error))")
(root/'probe-neutral-handler.py').write_text(t,encoding='utf-8',newline='\n')
subprocess.run([sys.executable,'-X','utf8',str(root/'probe-neutral-handler.py')],check=True)
