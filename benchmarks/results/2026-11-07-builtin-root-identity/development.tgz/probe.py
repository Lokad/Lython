from pathlib import Path
import json,os,subprocess
root=Path(__file__).parent
sources=[
'''class object:pass
try:
 object.marker=3
 print(object.marker)
 del object.marker
 print(hasattr(object,'marker'))
except TypeError as error:print(type(error).__name__,str(error))
''',
'''class type:pass
try:
 type.marker=5
 print(type.marker)
 del type.marker
 print(hasattr(type,'marker'))
except TypeError as error:print(type(error).__name__,str(error))
''',
'''for cls in [object,type,int,str,list,ValueError]:
 try:setattr(cls,'marker',1)
 except TypeError:print('immutable')
 else:print('WRITABLE')
''']
env=os.environ.copy();env['DOTNET_ROOT']='C:/Users/JoannesVermorel/.dotnet11';env['PATH']=env['DOTNET_ROOT']+os.pathsep+env['PATH']
(root/'sources.json').write_text(json.dumps(sources,indent=2)+'\n',encoding='utf-8',newline='\n')
r=subprocess.run([env['DOTNET_ROOT']+'/dotnet.exe','tools/LythonProbe/bin/Release/net11.0/LythonProbe.dll',
 '--batch-json','--compare-python','--python','C:/Python313/python.exe'],input=json.dumps(sources),text=True,encoding='utf-8',env=env,capture_output=True,timeout=60)
(root/'probe.jsonl').write_text(r.stdout,encoding='utf-8',newline='\n');(root/'probe.stderr').write_text(r.stderr,encoding='utf-8',newline='\n')
print('Probe exit',r.returncode)
for line in r.stdout.splitlines():
 x=json.loads(line);print(json.dumps(x,ensure_ascii=False)[:1600])
