from pathlib import Path
import hashlib,json,subprocess
root=Path(__file__).parent
before=dict(head='42101cd5883927a6466f989bdc81fef84a3fd2c2',
 coreSHA256={tfm:hashlib.sha256(Path(f'src/Lokad.Lython/bin/Release/{tfm}/Lokad.Lython.dll').read_bytes()).hexdigest() for tfm in ['net11.0','net10.0']})
if not (root/'before.json').exists():(root/'before.json').write_text(json.dumps(before,indent=2)+'\n',encoding='utf-8',newline='\n')
source=(root.parent/'cold-string-hash-r33/focused.py').read_text(encoding='utf-8-sig')
families=['BuiltinRootIdentity','BuiltinDefinitionIsolation','Class','Type','Metaclass','Attribute','Descriptor',
 'Namespace','Constructor','Object','NativeReturn','NativeHelper','Deferred','InstructionFailure','SharedMemory','Admission','Cancellation']
start=source.index('families=');end=source.index('\nselection=',start)
source=source[:start]+'families='+repr(families)+source[end:]
exec(compile(source,str(root/'focused-expanded.py'),'exec'))
