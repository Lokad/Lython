from pathlib import Path
import hashlib,json,re,subprocess
root=Path(__file__).parent
source=Path('tests/Lokad.Lython.PublicApi.Tests/BuiltinRootIdentityTests.cs').read_text(encoding='utf-8')
literal=r'("(?:\\.|[^"\\])*")'
pattern=r'\{\s*'+literal+r'\s*,\s*'+literal+r'\s*,\s*'+literal+r'\s*\}'
cases=[tuple(json.loads(x) for x in row) for row in re.findall(pattern,source)]
assert len(cases)==8,len(cases)
rows=[]
for name,program,expected in cases:
 result=subprocess.run(['C:/Python313/python.exe','-I','-S','-X','utf8','-c',program],text=True,encoding='utf-8',capture_output=True,timeout=10)
 rows.append(dict(name=name,source=program,expected=expected,stdout=result.stdout,stderr=result.stderr,exitCode=result.returncode))
 assert result.returncode==0 and result.stdout==expected,(name,result.stdout,result.stderr,expected)
(root/'python-goldens.json').write_text(json.dumps(dict(reference=subprocess.check_output(['C:/Python313/python.exe','--version'],text=True).strip(),
 cases=rows),indent=2)+'\n',encoding='utf-8',newline='\n')
print('Eight independent Python goldens pass.')
