from pathlib import Path
import json,os,subprocess
r=Path(__file__).resolve().parent;repo=Path('D:/code/Lython');sdk='C:/Users/JoannesVermorel/.dotnet11';env=dict(os.environ);env['DOTNET_ROOT']=sdk;env['DOTNET_ROOT_X64']=sdk
programs=[
"def make():\n offset=10\n type A=(offset+x for x in range(2))\n offset=20\n return A\na=make()\ng=a.__value__\nprint(g.send(None),next(g))\ng.close()\nprint(list(g))",
"class C:\n scale=7\n type A=(scale+x for x in range(2))\ng=C.A.__value__\ntry:g.send(None)\nexcept NameError:print('NameError')\ng.close()",
"type A[T]=(T.__name__ for x in range(2))\ng=A.__value__\nprint(g.send(None),next(g))\ng.close()",
"type A[T:(x+1 for x in range(2))]=list[T]\ng=A.__type_params__[0].__bound__\nprint(g.send(None),next(g))\ng.close()",
"type A[T=(x+1 for x in range(2))]=list[T]\ng=A.__type_params__[0].__default__\nprint(g.send(None),next(g))\ng.close()",
]
(r/'lazy-boundary-programs.json').write_text(json.dumps(programs,indent=2)+'\n',encoding='utf-8')
for asynchronous in [False,True]:
 command=[sdk+'/dotnet.exe',str(repo/'tools/LythonProbe/bin/Release/net11.0/LythonProbe.dll'),'--batch-json','--compare-python','--python','C:/Python313/python.exe']+(['--async']if asynchronous else[])
 p=subprocess.run(command,input=json.dumps(programs),env=env,text=True,encoding='utf-8',capture_output=True,timeout=60)
 out=r/('lazy-boundary-async.jsonl'if asynchronous else'lazy-boundary-sync.jsonl');out.write_text(p.stdout,encoding='utf-8');(r/('lazy-boundary-async.stderr'if asynchronous else'lazy-boundary-sync.stderr')).write_text(p.stderr,encoding='utf-8')
 data=[json.loads(line)for line in p.stdout.splitlines()];assert len(data)==len(programs)
 print(json.dumps(dict(asynchronous=asynchronous,returnCode=p.returncode,probes=[dict(index=x['Index'],matches=x['Matches'],lython=x['Lython']['Success'],python=x['CPython']['Success'],output=x['Lython']['StandardOutput'],failure=x['Lython']['Failure'])for x in data])))
 assert p.returncode==0 and all(x['Matches']and x['CPython']['Success']for x in data)
