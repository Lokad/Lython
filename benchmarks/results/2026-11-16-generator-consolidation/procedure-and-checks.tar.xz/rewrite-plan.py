from pathlib import Path
r=Path(__file__).resolve().parent;repo=Path('D:/code/Lython');p=repo/'PLAN.md'
(r/'PLAN-before.md').write_text(p.read_text(encoding='utf-8'),encoding='utf-8')
p.write_text('''# Lokad.Lython 0.11.0

Updated 2026-11-16 UTC. Git-ignored; never force-add. Publication and tagging held.
Objective: simplify complete execution stages and improve useful agent-written
scripts, including compile-once/run-once latency. One experiment does not complete
this objective. Current contracts live in `docs/`; history and adverse evidence
live in [EXPERIMENTS](benchmarks/EXPERIMENTS.md) and linked immutable artifacts.

## Delivery status

| State | Milestone and evidence |
| --- | --- |
| Committed, fully qualified | Shared compiler facts/callback inspection `61237f58`; native helper returns `8f07764a`. Returns reduce allocation about 19–20%; elapsed improvements remain diagnostic. No qualification replay pending. |
| Committed, fully qualified | Direct UTF-8 formatting/storage reduces allocation 8.67%. [Controlled report comparison](benchmarks/results/2026-11-02-formatting-confirmation/README.md) supports 5–8% lower elapsed/CPU. Original adverse 15.125 ms remains unexplained and preserved. |
| Committed, fully qualified | Native calls, prepared stores/layouts, bulk records, final sinks, line construction, immutable shared subtext and final-slot range transport. [Cumulative delivery](benchmarks/results/2026-11-16-regex-dev105/delivery/README.md): `c18babe9`, GREEN `43869939863`; Windows/Ubuntu actual .NET 11/10, ordinary and original stress, installed Release consumers; 611 inputs/16 summaries verified. Runtime source is measured `0443b5cf`/qualified `312f5911`; later changes here are tests. |
| Committed measurements | [Four-script CPython checkpoint](benchmarks/results/2026-11-16-representative-cpython-checkpoint/README.md) plus [configuration/report checkpoint](benchmarks/results/2026-11-16-generated-scripts-cpython/README.md). Warm CSV 1.08–1.10×, normalization 2.21–2.30×, JSON 0.84–0.85×, search 1.76–1.80×, config 0.96–0.98×, report 1.18–1.20× versus CPython 3.13.16. Separate compilation and fresh phases, I/O/cleanup boundaries, moving controls and original CPython shift remain explicit. Ratios are diagnostic; no cross-collection source gain inferred. |
| Active private prototype | R445 replaces the secondary class/annotation generator-expression interpreter with the existing executable generator. Independent Python protocols now agree; 191 internal/957 public focused checks plus 39 type-scope checks pass on each target. Local complete class-generator report allocation −21.09%; ordinary controls effectively flat. VM comparison pending; no promotion or full qualification yet. |
| Independent development qualification | [R443/dev105](benchmarks/results/2026-11-16-regex-dev105/README.md): immutable producer assets, matching subprocess library hashes, 363 focused Windows regex checks each target for both development producers. Linux rewrite elapsed −6–9% with supporting CPU; extraction uncertain, allocation flat. Normal optional adapter remains 0.4; core remains decoupled. |

Completed CI terminals are cached forever; do not query or replay unchanged
qualification. Source qualification, allocation reduction, CPU improvement,
backend interruption and embedding-process latency are separate claims.

## 1. Finish and deliver R445: one generator-expression engine

Demonstrated problem: class/annotation creation used `PyGeneratorExpression`, a
second recursive clause evaluator without Python `send`/`throw`/`close`. Ordinary
normalization already uses compiled generators; this is not its gap attribution.

Replacement: extend the existing compile-time callable preparation walk, retain
actual executable-site capture facts, and prepare remaining namespace consumers.
Use `PyGenerator.CreateExpressionAsync` everywhere. Delete the 261-line legacy
interpreter, manual outer attachment/iterator lifetimes and runtime lowering.
No runtime compiler, second code cache, controller, owner or new execution option.

Acceptance: both hosting APIs preserve eager outer acquisition, lazy body work,
late binding, nested/class cells, annotations, protocols and Python errors.
Real host suspension/cancellation and construction refusal must keep pending
cleanup and retained aliases funded; return allowance after awaited cleanup.
The common frame/cursor is admitted at construction, allowing conservative earlier
denial. Existing checks caught and corrected class-cell selection; originals stay.

Finish the bounded quiet-VM comparison: affected complete class-generator report
compile/warm/fresh plus ordinary normalization/call controls. Keep all adversity,
including initial staging failure and correction. Decide retain/refine/remove and
document CPU, allocation and admission tradeoffs separately. At retained delivery,
batch full platform, original stress and installed-package checks. Do not repeat
the unchanged c18 qualification. Then continue the roadmap below.

## 2. Substantial whole-script roadmap

For each selected redesign record its hypothesis, eliminated work/storage,
affected complete scripts, semantic gate and displaced implementation to delete.
A temporary regression needs a named completion milestone and an explicit residual
debt decision. Do not accumulate wrappers or syntax-specific fast paths.

| Candidate | Existing evidence and next decision | Completion gate |
| --- | --- | --- |
| Complete calls/frames/operand transport | Direct final-slot binding already exists. [R442](benchmarks/results/2026-11-16-complete-call-design/README.md) found no justified next replacement. Call arena/control and shared-kernel designs measured slower; preserve their lessons, not permanent bans. Reopen with a real displaced stage or new attribution. | Exact defaults, closures, identities, argument order, fault/child transfer, async host operations and generator lifetimes. Complete-script warm/fresh and call controls; remove displaced route. |
| Per-record construction | Historical 6–8% CSV work was reassessed and integrated as funded private rows/shared keys/final payloads. No second duplicate row pipeline is established. | New capacity evidence; duplicate/short/wide rows, custom protocols, aliases, mutation and replacement overlap. No universal wide slots for reference-only records. |
| Text/aggregate execution | Normalization remains about 2.2× CPython. Final sinks, casing, line construction, prepared formats and shared subtext already exist. R438 materialization and R440 cased streaming removed storage but lost CPU and were withdrawn. Assess remaining complete transport/conversion stages before another prototype. | Unicode/context/expansion, hooks/errors, current tokens, real suspension and retained aliases. Remove one representation or transport stage; affected script and independent controls. |
| Frontend/setup | Shared facts, prepared stores and single instruction store are delivered; measured compilation is near CPython for current scripts. Different analyses are not redundant just because each traverses syntax. | Compile-heavy evidence identifying a displaced pass/storage; preserve spans, binding, class cells, lazy annotations, cancellation and admission. No general compiler rewrite selected. |

Import execution consolidation is already delivered (`840621405`). Keep lowered
evaluation for genuine class/annotation and opcode consumers. R439's three shared
kernel shapes, R433 completed-async entry and R440's two cased-stream shapes were
withdrawn; independent correctness/ownership fixes remain delivered. All sources,
slower conditions and controls are linked from EXPERIMENTS. Stop an investigation
with select/refine/retain/remove or explicit uncertainty, then advance the objective.

## 3. Independent regex architecture and final adapter qualification

Core owns Python semantics, native UTF-8 subjects/names, byte ranges, scalar
positions, original-subject windows, effective flags, ownership and active tokens
across frontend/runtime/imports. Cooperating-provider interruption/joined cleanup
and native fnmatch/glob are delivered. No Utf8Regex core dependency.

Development producers and adapter-local bridges may support implementation.
Precisely pending producer capabilities: native UTF-8 group-name enumeration,
active token through actual preparation, and separate per-match result-stage
allowance. Existing cursor tokens, working allowance, receipts and disposal remain.
These gaps defer only affected final adapter qualification. Keep effective-flag/
Verbose controls and exact parent/child image checks. Do not certify producer
unsafe-policy compliance or promote the normal pin from focused evidence.

When capabilities change, freeze immutable assets and qualify semantics/errors/
windows, genuine in-flight cancellation, refusal/unwind, retained users and budget
reuse, plus one affected performance pair. Keep contract, adapter and backend
claims separate; producer publication cannot stop independent core development.

## Iteration and lasting contracts

Timeouts, moving unchanged controls and inconclusive timings establish uncertainty.
Allow bounded confirmation, refinement or measurement correction when justified;
retain every adverse original and failed condition. Percentages inform decisions,
not automatic vetoes. Size short observations for the existing quiet VM. Focused
Release semantics/cancellation/ownership during iteration; full platform/stress/
package checks at coherent retained deliveries, without relaxing timeouts.

[AGENTS](AGENTS.md) binds managed memory safety/stack admission, host mediation,
active cancellation, terminal first refusal, awaited cleanup and coarse shared
capacity/replacement funding for aliases/results/caches/pending users. No unsafe,
fuel/quotas/watchdogs, hidden allowances, retry, tracing, weak reclamation or forced
GC. Long streams use bounded host-driven commands. Freeze copies/full image hashes;
force builds after restoring timestamps. Verify custom catalogs with actual frozen
workers before VM staging. Persist and verify evidence under lease before RAM
teardown; join users before refund. Retire only exact committed archive replicas
after fresh UID/path/hash/all-alias proof; preserve selected images/toolchains and
254/252 MiB floors. CI observations at least 240 seconds apart; cache terminals.
Only core is packaged; publication and tagging remain postponed.
''',encoding='utf-8',newline='\n')
print('PLAN.md condensed to delivery status, three independent deliverables and acceptance gates; history preserved separately.')
