from pathlib import Path
import contextlib,io,json,re
r=Path(__file__).resolve().parent;w=Path('D:/code/Lython/.git/agent-worktrees/generator-consolidation-r445')
source=(w/'tests/Lokad.Lython.PublicApi.Tests/LoweredGeneratorProtocolTests.cs').read_text(encoding='utf-8')
cases=[]
for a,b in re.findall(r'^\s*\{ "((?:\\.|[^"\\])*)", "((?:\\.|[^"\\])*)" \},$',source,re.MULTILINE):
 program=json.loads('"'+a+'"');expected=json.loads('"'+b+'"');output=io.StringIO()
 with contextlib.redirect_stdout(output):exec(program,{})
 assert output.getvalue()==expected,(program,output.getvalue(),expected)
 cases.append(dict(source=program,expected=expected,independentCPythonMatches=True))
assert len(cases)==7
(r/'protocol-goldens.json').write_text(json.dumps(cases,indent=2)+'\n',encoding='utf-8',newline='\n')
print('Seven independent CPython protocol/scoping goldens match; both hosting APIs use those outputs.')
