from pathlib import Path
import hashlib,json,subprocess,tarfile
r=Path(__file__).resolve().parent;repo=Path('D:/code/Lython')
sha=lambda b:hashlib.sha256(b).hexdigest()
inventory=json.loads((r/'vm-inventory.json').read_text(encoding='utf-8'))
selected=[x for x in inventory['rows'] if x['path'] in ['native-workstate-b443-20261108/observations.tgz','conditional-cpython-b467-20261108/confirmation/confirmation.json','method-binding-b441-20261108/observations.tgz']]
assert len(selected)==3
tracked=subprocess.check_output(['git','ls-files','benchmarks/results'],cwd=repo).decode().splitlines()
archives=[repo/n for n in tracked if n.endswith(('.tar.xz','.tgz')) and any(k in n for k in ['2026-11-08-native-workstate','2026-11-08-json-conditional','2026-11-08-native-method-facts'])]
proofs=[]
for p in archives:
 data=p.read_bytes();blob=subprocess.check_output(['git','show','HEAD:'+p.relative_to(repo).as_posix()],cwd=repo);assert data==blob
 with tarfile.open(fileobj=__import__('io').BytesIO(data))as t:
  for m in t.getmembers():
   if not m.isfile():continue
   for candidate in selected:
    if m.size==candidate['bytes']:
     content=t.extractfile(m).read()
     if sha(content)==candidate['sha256']:proofs.append(dict(**candidate,canonical=p.relative_to(repo).as_posix(),canonicalSHA256=sha(data),member=m.name,committedBlobVerified=True))
print(json.dumps(dict(archives=[str(p.relative_to(repo))for p in archives],proofs=proofs),indent=2))
(r/'retirement-proof.json').write_text(json.dumps(proofs,indent=2)+'\n',encoding='utf-8')
