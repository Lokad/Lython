from pathlib import Path
import ast,datetime,hashlib,io,json,subprocess,tarfile
r=Path(__file__).resolve().parent;q=r/'quiet';prior=r.parent/'generated-scripts-r444/quiet'
sha=lambda b:hashlib.sha256(b).hexdigest()
catalog=json.loads((q/'representative.json').read_text(encoding='utf-8'))
catalog['cases']=[c for c in catalog['cases'] if c['id']!='scripts.report-render.large']
raw=(json.dumps(catalog,ensure_ascii=False,indent=2)+'\n').encode();(q/'representative.json').write_bytes(raw)
identity=json.loads((q/'identity.json').read_text(encoding='utf-8'))
identity['catalogSHA256']=sha(raw);identity['purpose']=identity['purpose'].replace('unchanged report/normalization/call controls','unchanged normalization/call controls');identity['catalogInitialization']='Same fixed three-case catalog in every worker: complete class-generator report and two controls.'
(q/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8')
s=(q/'collect.py').read_text(encoding='utf-8');module=ast.parse(s);assignment=next(n for n in module.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='jobs' for t in n.targets));jobs=[v for v in ast.literal_eval(assignment.value) if v[0]!='scripts.report-render.large'];assert len(jobs)==5
a=s.index('jobs=');b=s.index('\nenv =',a);s=s[:a]+'jobs='+repr(jobs)+'\nassert len(jobs)==5 and all(case in cases for case,lane in jobs)\n'+s[b:];(q/'collect.py').write_text(s,encoding='utf-8',newline='\n')
for n in ['archive-owned.py','retrieve.py']:
 s=(q/n).read_text(encoding='utf-8').replace('len(raw[\'jobs\'])==6','len(raw[\'jobs\'])==5').replace('jobs=6','jobs=5').replace("['jobs']==6","['jobs']==5");ast.parse(s);(q/n).write_text(s,encoding='utf-8',newline='\n')
payload={n:(q/n).read_bytes() for n in ['identity.json','representative.json','collect.py','archive-owned.py','run.sh']}
payload['candidate/Lokad.Lython.dll']=(r/'frozen/candidate/Lokad.Lython.dll').read_bytes()
with tarfile.open(q/'payload.tgz','w:gz')as t:
 for n,data in payload.items():m=tarfile.TarInfo(n);m.size=len(data);t.addfile(m,io.BytesIO(data))
previous=json.loads((prior/'config.json').read_text(encoding='utf-8'))
proofs=json.loads((r/'retirement-proof.json').read_text(encoding='utf-8'));assert len(proofs)==2
c=dict(root='/home/lokad/lython-bench-checks/generator-consolidation-b848-20261116',unit='lython-b848-generator-consolidation-20261116',source=previous['root'],sourceFiles=previous['sourceFiles'],sourceCatalogSHA256=previous['catalogSHA256'],catalogSHA256=sha(raw),identity=identity,retireGroups=[dict(paths=[p['path']],bytes=p['bytes'],links=p['links'],sha256=p['sha256'],canonical=p['canonical'],canonicalSHA256=p['canonicalSHA256'],member=p['member'],committedBlobVerified=True)for p in proofs],payloadBytes=(q/'payload.tgz').stat().st_size,payloadSHA256=sha((q/'payload.tgz').read_bytes()),unpackedBytes=sum(map(len,payload.values())))
(q/'config.json').write_text(json.dumps(c,indent=2)+'\n',encoding='utf-8')
s=(prior/'remote-launch.py').read_text(encoding='utf-8');a=s.index('c=');b=s.index('\nb=Path',a);s=s[:a]+'c='+repr(c)+s[b:];s=s.replace('lython-b847-fixtures','lython-b848-fixtures');ast.parse(s);(q/'remote-launch.py').write_text(s,encoding='utf-8',newline='\n')
s=(r.parent/'generated-scripts-r444/launch.py').read_text(encoding='utf-8').replace('Six-phase config/report checkpoint','Five-phase generator consolidation');ast.parse(s);(r/'launch.py').write_text(s,encoding='utf-8',newline='\n')
print(json.dumps(dict(jobs=jobs,catalogSHA256=sha(raw),unpackedBytes=c['unpackedBytes'],retiredBytes=sum(p['bytes']for p in proofs),requiredFreeBeforeStaging=254*1024*1024+c['unpackedBytes']+65536)))
