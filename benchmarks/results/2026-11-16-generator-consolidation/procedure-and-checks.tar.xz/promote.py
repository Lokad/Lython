from pathlib import Path
import hashlib,json,shutil,subprocess,tarfile
r=Path(__file__).resolve().parent;repo=Path('D:/code/Lython');work=repo/'.git/agent-worktrees/generator-consolidation-r445'
sha=lambda b:hashlib.sha256(b).hexdigest()
assert subprocess.check_output(['git','status','--porcelain'],cwd=repo)==b''
assert subprocess.check_output(['git','rev-parse','--short=8','HEAD'],cwd=repo).decode().strip()=='7fd674ce'
summary=json.loads((r/'summary.json').read_text(encoding='utf-8'));assert summary['complete']
inputs=json.loads((r/'inputs.json').read_text(encoding='utf-8'))
for n,h in inputs['files'].items():assert sha((work/n).read_bytes())==h,n
for n in inputs['deleted']:assert not(work/n).exists()
identity=json.loads((r/'quiet/identity.json').read_text(encoding='utf-8'))
for role,files in identity['imageFiles'].items():
 for n,h in files.items():assert sha((r/'frozen'/role/n).read_bytes())==h
assert sha((r/'quiet/observations.tgz').read_bytes())==json.loads((r/'quiet/archive-receipt.json').read_text(encoding='utf-8'))['archiveSHA256']
out=repo/'benchmarks/results/2026-11-16-generator-consolidation';out.mkdir(exist_ok=False)
for name in ['summary.json','allocation-summary.json','inputs.json','candidate-sources.tar.xz','protocol-goldens.json']:shutil.copy2(r/name,out/name)
for name in ['identity.json','archive-receipt.json','terminal-status.json','observations.tgz']:shutil.copy2(r/'quiet'/name,out/name)
with tarfile.open(out/'procedure-and-checks.tar.xz','w:xz')as t:
 for p in sorted(r.rglob('*')):
  if p.is_file() and p.suffix in ['.py','.cs','.csproj','.trx','.log','.json','.md'] and not {'frozen','retrieved','reference','candidate','bin','obj'}&set(p.relative_to(r).parts):t.add(p,arcname=p.relative_to(r).as_posix())
 for role in ['reference','candidate']:t.add(r/'frozen'/role/'Lokad.Lython.dll',arcname='frozen/'+role+'/Lokad.Lython.dll')
decision=dict(retain=True,coherentDeletion='261-line secondary generator interpreter and per-construction lowering removed; shared precompiled executable generator retained',semanticFix='Class/annotation expressions support send/throw/close',allocationPercent=-21.090633325919374,warmElapsedPercent=[-9.365692870418485,-8.144013203896828],compilationElapsedPercent=[4.001357080718049,9.431275816119488],freshElapsedPercent=[-7.2052762521908065,-4.140234586818781],acceptedDebts=['Extra compile-time work and earlier conservative frame/cursor admission','Calls elapsed +0.77..+0.99%,CPU -2.34..0%; do not claim broad call improvement','Normalization unchanged-control spread 4.78%; inconclusive'],qualificationPending=True,publicationHeld=True)
(out/'decision.json').write_text(json.dumps(decision,indent=2)+'\n',encoding='utf-8')
(out/'README.md').write_text('''# One executable generator-expression engine

R445/B848, 2026-11-16 UTC. Retain the coherent migration against qualified
`312f5911` / core `0443b5cf`. Prototype core `16c37b02`; exact source inventory
and deleted file are recorded. No public API or regex-provider change.

Remove the 261-line `PyGeneratorExpression` recursive interpreter, its separate
clause/enumerator/outer-attachment lifetimes and runtime syntax lowering. Extend
the existing callable-preparation walk and reuse the existing executable generator
for class suites and annotation consumers. Ordinary executable generators already
use that engine. No runtime compiler, cache, owner or alternate backend is added.

Class-created generators previously lacked Python send/throw/close under both
public hosting APIs. Seven independent CPython goldens now pass. Existing checks
found a class-cell selection difference; capture through the class function
closure corrects it, preserving the original assertions. The outer iterable still
evaluates immediately in the ordinary class namespace; body lookup skips it.

| Complete source / phase | Elapsed change | Wider process CPU change | Reference / candidate process spread |
| --- | ---: | ---: | ---: |
| Class-generator report, compilation | +4.00..+9.43% | +4.21..+8.24% | 1.94 / 3.22% |
| Class-generator report, warm | −9.37..−8.14% | −10.16..−4.75% | 0.47 / 0.87% |
| Class-generator report, compile-to-result | −7.21..−4.14% | −7.32..−2.68% | 3.19 / 0.11% |
| Ordinary normalization control, warm | −2.45..+2.28% | −3.33..+1.70% | 4.78 / 0.07% |
| Ordinary calls control, warm | +0.77..+0.99% | −2.34..0.00% | 0.04 / 0.17% |

Five jobs completed in 152.091 seconds. Same three-case catalog, scripts,
fixture/stdout/file hashes, benchmark worker and normal optional 0.4 adapter;
two independent processes per source, four-second request-wall warmup and five
rotated approximately half-second rounds. Four pairings of medians are ranges,
not confidence intervals. Maximum sample IQR 3.02%. All image/Ready/golden/quiet/
Closed/exit/join/archive gates pass. No workers or RAM fixtures remain.

The report renders 1,024 JSON records (189,441 input bytes) to a complete Markdown
file using a class-created generator. Both revisions run the same source. Warm
includes mediated RAM I/O, complete stdout/file validation and prior-result
cleanup; excludes compilation, startup, fixture reset/protocol and final cache
teardown. Fresh adds compilation and its owner disposal; compilation includes
code construction/disposal. Wider CPU includes reset/protocol. Independent phase
medians are not additive. No new CPython, RSS, pending-I/O or embedding-tail claim.

Local natural-GC whole-process allocation: report 3,381,008 → 2,667,932 bytes/run
(−21.09%); controls effectively flat. Accounted execution peak 3,493,993 →
3,494,889 bytes, because the common frame/cursor is admitted at construction.
Conservative earlier denial and extra compilation work are accepted contract/cost
tradeoffs. Ordinary call elapsed adversity remains; CPU does not corroborate it.
Moving normalization control makes that result uncertain, not a demonstrated loss.
This does not explain the existing ordinary normalization/CPython gap.

Focused Release checks pass each actual .NET 11/10: 191 internal / 957 public
generator, comprehension, lambda, scope, annotation and compilation checks, plus
39 type-scope checks. Overlapping targeted checks are not summed. Independent
pending host cancellation and construction refusal retain outer storage until
awaited disposal and return the shared allowance to baseline. Full platform,
original stress and installed-package delivery qualification is pending.

Original failed fixture and class-cell checks remain in the checks archive. An
initial staging failure listed unused local Allocation harness files as remote
worker dependencies. No guest workers or RAM fixtures had started. Exact partial
image/hash/ownership verification corrected the inventory to the existing 32-file
worker image before measurement; no timing observations were discarded. Two old
working replicas only were retired after committed archive/member equality and
fresh UID/path/hash/inode/all-alias proof. Canonical evidence, current images,
toolchains and 254/252 MiB floors remain. Terminal is cached; never query it again.

[All observations and controls](summary.json), [allocation](allocation-summary.json),
[raw archive](observations.tgz), [exact sources](candidate-sources.tar.xz),
[procedures, checks, initial conditions and core images](procedure-and-checks.tar.xz),
[retention decision](decision.json). Publication/tagging remain held. The larger
whole-script objective stays open after this correctness and consolidation milestone.
''',encoding='utf-8',newline='\n')
changed=subprocess.check_output(['git','diff','--name-only'],cwd=work).decode().splitlines()+['tests/Lokad.Lython.PublicApi.Tests/LoweredGeneratorProtocolTests.cs']
for n in changed:
 if (work/n).is_file():(repo/n).write_text((work/n).read_text(encoding='utf-8'),encoding='utf-8',newline='\n')
 else:
  assert n in inputs['deleted']
  (repo/n).unlink()
index=repo/'benchmarks/EXPERIMENTS.md';s=index.read_text(encoding='utf-8');s+='\nR445: [one executable generator-expression engine](results/2026-11-16-generator-consolidation/README.md). Retained coherent deletion/protocol fix; report warm −8–9%, allocation −21.09%; compilation cost and unchanged-control adversity remain explicit. Full delivery qualification pending.\n';index.write_text(s,encoding='utf-8',newline='\n')
p=repo/'PLAN.md';s=p.read_text(encoding='utf-8').replace('Active private prototype | R445','Retained; delivery qualification pending | R445').replace('VM comparison pending; no promotion or full qualification yet.','B848 warm −8–9%, fresh −4–7%; compilation +4–9%. Moving normalization control/call elapsed adversity preserved. Promoted; full delivery pending.');s=s.replace('Finish the bounded quiet-VM comparison:','Completed the bounded quiet-VM comparison:').replace('Decide retain/refine/remove and\ndocument CPU, allocation and admission tradeoffs separately. At retained delivery,','Retain: report warm/fresh and allocation improve; extra compilation and earlier\nadmission are accepted. Call elapsed +0.77..+0.99% without CPU support remains debt;\nnormalization is inconclusive. [All evidence](benchmarks/results/2026-11-16-generator-consolidation/README.md). At retained delivery,');p.write_text(s,encoding='utf-8',newline='\n')
print(json.dumps(dict(promotedFiles=len(changed),artifact=str(out),fullQualificationPending=True)))
