# Lokad.Lython 0.11.0

Updated2026-11-16UTC(cumulative-delivery-GREEN/R445selected). Git-ignored; never force-add. Publication/tagging postponed.
Objective: coherent simplification and substantial complete-script improvement,
including compile-once/run-once agent scripts. Finishing one experiment does not
complete that objective. Current contracts belong in `docs/`; immutable measurements,
adverse results, failed conditions and rejected designs remain in
[EXPERIMENTS](benchmarks/EXPERIMENTS.md) and its linked artifacts.

## Actual delivery status

| State | Delivery/evidence |
| --- | --- |
| Fully qualified | Shared compiler facts/callback inspection61237f58; native helper returns8f07764a. Returns establish19–20%less allocation; elapsed gains remain diagnostic. No repeated qualification pending. |
| Fully qualified | Direct UTF8 formatting/storage:8.67%less allocation. [Controlled confirmation](benchmarks/results/2026-11-02-formatting-confirmation/README.md) supports5–8%lower report elapsed/CPU; original adverse15.125ms remains unexplained. No unchanged retest pending. |
| Committed/fully qualified | R395–398tuple transport,R405arithmetic,R408casing,R413prepared stores,R416final sinks,R418layouts,R419shared executor,R422known scalar endpoints,R423native finally,R424single compiler instruction store. [History](benchmarks/EXPERIMENTS.md) records exact sources, controls, qualification and accepted regression debts. Separate source pairs cannot be added. |
| Committed/fully qualified | R426consuming text completions810dafdd; R429bulk constructionefd82707 qualified cumulatively with R430line constructionecd9e956. [R426](benchmarks/results/2026-11-16-consuming-text-completion/delivery/README.md),[R429/R430](benchmarks/results/2026-11-16-line-construction/delivery/README.md). Original adversity and explicit retention debt remain. |
| Committed/fully qualified | R435shared immutable subtext6581454d/measured1c8e1be5. [GREEN43819495111](benchmarks/results/2026-11-16-shared-subtext/delivery/README.md): Windows/Ubuntu actual11/10 ordinary,original stress,installed Release consumers;606inputs/16summaries verified. Receipt d5e75994. Allocation normalization−19.8%/JSON-lines−11.3%, supporting warm/fresh CPU; conservative full-backing retention documented. Original failed fixtures preserved; runtime unchanged through corrections. |
| Committed/fully qualified | R436final-slot range transport, measured0443b5cf versus1c8e1be5. [B834](benchmarks/results/2026-11-16-iteration-slot-transport/refined/README.md): module−24–26%elapsed/−97.8%allocation, async−27%elapsed,generator−6–8%elapsed/−13.7%allocation. Native helper roughly flat; CSV inconclusive with3.58%moving controls. Release446internal/1992public plus original14internal stress pass eachactual11/10;607inputs frozen. GREEN43828954661;607inputs/16summaries verified, terminal cached. No broad file-script gain. |
| Withdrawn prototype | R433completed async entry7c592066 removed; qualifiedecd9 runtime restored. [Evidence](benchmarks/results/2026-11-16-completed-async-entry/README.md). Independent held-I/O small-stack fixture correction81474cb7 is delivered/qualified. R403call-controller/R411tail-loan measured slower and were removed. |
| Current named external checkpoint | [R437/B835–B836](benchmarks/results/2026-11-16-representative-cpython-checkpoint/README.md),312f5911/0443b5cf versus CPython3.13.16. Twelve fixed-catalog phases/all gates: warmCSV1.08–1.10×,text2.21–2.30×,JSON0.84–0.85×,search1.76–1.80×. Compilation0.85–1.07×. Moving controls and original unexplained CPython shift remain; no cross-collection source gain inferred. |
| Withdrawn with independent coverage retained | [R438/B837](benchmarks/results/2026-11-16-direct-materialization-withdrawn/README.md),e0d2bdea versus0443b5cf. Warm normalization adverse2.9–4.6%/CPU1.9–3.9%,allocation flat. Complete transport/proposed admission contract withdrawn; source/raw controls retained. Independent two pending-cleanup cases pass retained runtime actual11/10, committed/pushed9f07335c. |
| Withdrawn complete migration | [R439](benchmarks/results/2026-11-16-shared-executable-kernel/direct/README.md),91ca→4f73→ba4a shapes preserved. One shared loop removed duplicate handlers/eligibility and finally private full WorkState,yet ba4a calls+17.15..17.48%elapsed with0.12/0.16%controls; normalization+4.18..6.04%. Allocation flat. Focused1787internal/1976public pass eachactual11/10; no promotion/full qualification. Independent earlier cleanup coverage retained. Evidencecommits a3d87c5f/b9b66020/8ff5fdfd/2f35905d. |
| Withdrawn text redesign | [R440/B842–B843](benchmarks/results/2026-11-16-cased-word-stream/refined/README.md),1427→ce36 versus0443. First shape allocation−71.54%/accounted peak−27.02%; bulk refinement−46.31%/−15.82%,but long-line elapsed+6.26..8.01% with1.20/0.45%controls. Both withdrawn; all sources/adverse controls preserved. Independent four ownership cases committed/pushedd6a79009;28internal eachactual11/10 pass on qualified production,original range-growth fixture preserved. No repeated full qualification. |
| Completed bounded attribution | [R441/B844](benchmarks/results/2026-11-16-protected-search-attribution/README.md),qualified0443.947active samples:749execution/140unknown,198protocol-reset/179unknown. Entry/binding251inclusive overlaps useful closed execution149; no dominant removable stage established. All gates/joins/archived RAM proof pass. No runtime or speedup/full-qualification change. |
| Qualified development input | [R443/B846](benchmarks/results/2026-11-16-regex-dev105/README.md),old immutable0.5 versusdev105,same native source/0443core. Rewrite elapsed−8.59..−6.25%/CPU−8.09..−6.61%; extraction uncertain,allocation flat.363regex checks eachactual11/10 per producer with matching subprocess hashes. Initial startup-metadata failure/correction retained. No normal pin/core dependency or safety certification. |
| Committed/fully qualified | Exact fixture identityc18babe9 and cumulative independent ownership coverage. [GREEN43869939863](benchmarks/results/2026-11-16-regex-dev105/delivery/README.md): Windows/Ubuntu actual11/10 each4806internal/17921public ordinary,14internal/406public stress,installed Release consumers.16summaries/611inputs verified,terminal cached forever. Normal0.4adapter; private0.5focused Windows qualification remains separate. |
| Independent adapter prototype | [R409](benchmarks/results/2026-11-15-regex-range-prototype/README.md),immutable development0.5 parent semantics originally361eachactual11/10; three child checks did not prove private producer identity. R443corrects that gap with actual matched-child363checks eachtarget for old0.5/dev105. Contract,semantics and performance remain separate. Normal pin unchanged; missing capabilities defer only affected final adapter qualification. |

Completed CI terminals are cached forever; never query or repeat their qualification
unchanged. Initial failures remain evidence. Fully qualified does not imply measured
CPU improvement, backend interruption, heap/RSS or embedding-tail latency.

## Prioritized deliverables

### 1. R445: consolidate lowered generator expressions

**Completed cumulative delivery.** c18babe9/43869939863GREEN: Windows/Ubuntu
actual11/10 ordinary,original stress and installed Release consumers.16summaries/
611inputs verified and archived; complete terminal/logs cached,never query again.
Independent pending-cleanup/cased ownership cases and exact regex child hashes
are covered. Normal0.4adapter; private0.5/dev105focused qualification is Windows
actual11/10 plus separate Linux VM workload checks. No unchanged full replay or
new runtime timing inference. Publication/tagging remain held.

**Completed independent milestone.** R443freezes immutabledev105packages and
qualifies363regex cases eachactual11/10 against both old0.5/dev105with matching
private children. Three deliberate wrong-child hashes fail. Same native source/
qualified0443core; B846rewrite6–9%lower elapsed with supporting CPU,extraction
uncertain,allocation flat. Initial B845metadata failure has no timing observations;
all raw conditions,cleanup and correction retained. Local frozen-worker verification
passes; it precedes future VM staging. No normal0.4pin/core dependency change.

**R444 complete.** [Config/report checkpoint](benchmarks/results/2026-11-16-generated-scripts-cpython/README.md)
adds six phases on qualified0443/CPython3.13.16. Config fresh0.94–0.96×,report
1.20–1.22×; compilation1.04–1.06×. Source/control/IQRand changed six-case catalog
initialization remain explicit. All gates/local actual-worker verification pass,
all users joined/RAM fixtures gone. Current guide adds the rows; prior evidence
preserved,no unchanged four-case retest or causal source gain. Prepared f-string
layouts and direct receiver argument views already exist; do not recreate them.

**R445 demonstrated correctness/deletion opportunity.** Source still constructs
PyGeneratorExpression through synchronous syntax/lowered async evaluators in class/
annotation consumers. It carries a second recursive clause evaluator and sync/async
enumerator lifetimes. CPython probes confirm class-body generators lack send,
throw and close under both public APIs. Ordinary compiled generators already have
these protocols; normalization uses that compiled route,so this is not a claimed
explanation of its2.21–2.30×gap.

**Selected replacement.** Extend existing compile-time callable preparation to
surviving generator expressions,as it already does for lambdas. Bind actual
executable sites with their existing lexical facts; prepare only remaining lowered
consumers with namespace closure semantics. Use PyGenerator.CreateExpressionAsync
for both hosting APIs. Delete PyGeneratorExpression and its clause recursion,
manual sync/async iterator fields,outer attachment and syntax-to-lowered rebuild.
No runtime compilation,second code cache,controller/owner/backend or new option.
Preserve measured native functions and general lowered expression consumers.

**Acceptance/completion.** Existing generator/comprehension/scoping/annotation/class
regressions plus independent send/throw/close/outer-evaluation/late-binding checks
under both APIs; actual I/O/cancellation/first refusal,managed stack,retained aliases
and pending cleanup remain funded. Scope creation/admission precedes new frame/
cursor allocations; document conservative earlier denial. Delete obsolete mechanism
tests while keeping independent behavior assertions. One complete class-generator
text/report source comparison plus ordinary normalization/call controls; separately
measure compilation so removing runtime interpretation does not hide new setup
work. Record actual work/storage eliminated and remaining regression debt,then
retain/refine/remove. Full platform/stress/package qualification at retained delivery;
all new evidence separate from already-qualifiedc18. Performance objective remains
open after this correctness/consolidation milestone.

**Remaining development.** R442complete call/frame design pass closes unresolved:
final-slot binding already exists,consumed-operand reuse adds aliasing/lifetime
obligations beyond slowerR411,and managed block compilation lacks a demonstrated
one-shot/full-replacement case. Preserve qualified native code and all adversity;
do not relabel whole-script gaps solved. Continue only with a genuinely displaced
stage and explicit compile-to-result/semantic/controlled comparison gate,not another
carrier or narrow opcode fusion. The substantial roadmap below remains independent
of producer publication. R443's precise final adapter gaps stay in track3.

### 2. Remaining substantial roadmap and bounded lessons

R436delivery and R437external checkpoint are complete; do not repeat unchanged
qualification. R438materialization,R439shared-kernel and R440cased-stream shapes are
archived and withdrawn. R439's three managed shapes still lose ordinary-call/whole-text CPU with
flat allocation; source deletion alone does not justify discarding measured
function gains. R403call-controller and R411call-arena also measured slower. These
are concrete lessons,not permanent architecture bans. A new call/frame design
needs an actually displaced stage and new evidence,not another carrier/wrapper.

| Candidate | Remaining evidence/work needed | Semantic/completion gate |
| --- | --- | --- |
| Complete calls/frames/operand transport | Direct final slots/binding and current fast helpers are delivered. Generic shared-view migration did not improve them. A future design must eliminate real transport/binding work without per-call carrier/clearing debt. | Keep observed identities/defaults/closures,exact promotion,PC/fault/child transfer,no replay,genuine I/O/generator protocols,managed stack and retained funding. Remove displaced route in the coherent delivery; measure complete scripts and calls with controls. |
| Record construction | Historical6–8%CSV opportunity was reassessed and integrated as private funded rows/shared keys/final payloads. No second duplicate row pipeline is identified. | Require new storage evidence; preserve duplicate/short/wide rows,custom protocols,aliases/mutation and replacement overlap. No universal wide slots for reference-only records. |
| Text/conversions | R440 removes real storage but adds CPU; both shapes withdrawn with independent ownership coverage retained. Casing,final sinks,layouts,line construction and immutable shared subtext already delivered. | Preserve Unicode context/expansion,format hooks/errors,real suspension,current token and aliases. Delete the selected representation,not another narrow syntax special case. |
| Frontend | Shared facts/prepared stores/single instruction store delivered; R437compile phases near CPython. Different analyses are not redundant because they traverse syntax. | Require compile-heavy representative evidence and a complete displaced stage; preserve spans,binding/class cells,lazy annotations,cancellation/admission. No compiler rewrite selected now. |

Import execution consolidation is already delivered(840621405); retain the lowered
evaluator for real class/annotation and opcode consumers. Before every new
redesign record the concrete hypothesis,work/storage to disappear,whole scripts,
semantic gate and bounded controlled comparison. Temporary regression is allowed
only through a named completion milestone and explicit residual-debt decision.
Stop investigations with select/refine/retain/remove or explicit uncertainty,
then continue the performance objective. No open-ended sampling/qualification.

### 3. Independent regex implementation/qualification

Core owns Python-specific native UTF8 subjects/names,byte ranges,scalar positions,
original-subject windows,effective flags,ownership and current tokens across frontend,
runtime and imports. Native fnmatch/glob and cooperating-provider in-flight interruption/
joined cleanup are delivered; core has no Utf8Regex runtime dependency.

Build on R409development producer/adapter-local bridges. Missing native UTF8 group-name
enumeration,preparation with current token and per-match result-stage allowance defer
only affected final adapter qualification. Cursor/advance tokens,working allowance,
receipts and disposal exist. 2026-11-16: normal immutable0.4 remains; changed immutable development
0.5.0-dev.105 qualified underR443(363regex checks eachactual11/10 with real
matching private subprocesses). R409 evidence is historical,not this new package. Keep effective-flag/Verbose controls717f0747.
No hidden host no-reentry/refund restriction,dialect substitution or unsafe promotion.

When actual producer capabilities change,qualify immutable released assets for Python
semantics/errors/windows,real in-flight cancellation,refusal/unwind,retained users,budget
reuse and one affected performance pair. Keep contract,adapter and backend claims distinct.
Publication remains held; producer timing cannot block independent core development.

## Iteration policy and lasting contracts

Timeouts,unstable unchanged controls and inconclusive measurements establish uncertainty,
not permanent rejection. Allow bounded confirmation,refinement or measurement correction
when evidence justifies it; retain all adverse originals and failed conditions. Percentages
inform decisions,not rigid vetoes. Distinguish simplification,allocation and demonstrated CPU.
Use focused Release semantics,cancellation and ownership while iterating; batch full platform,
stress and installed-package checks at retained delivery boundaries.

[AGENTS](AGENTS.md) binds fully managed memory safety and validated stack admission:
no unsafe/Unsafe/PInvoke/native probes. Preserve host capabilities/contained paths,checked
bounds,bounded I/O,current host token,terminal first refusal,awaited cleanup and coarse
shared capacity/replacement funding for aliases,results,caches and pending users. No
fuel/quotas/watchdogs,hidden allowance,retries,tracing,weak reclamation or forced GC.
Long streams use bounded host-driven commands. Freeze copies/full hashes; force builds
after restored timestamps. Read/write UTF8. Persist/verify VM evidence under lease before
RAM teardown; join users before refund. Retire only exact committed archived replicas
after fresh UID/path/hash/all-alias proof; retain current images/toolchains and254/252MiB
floors. CI polls at least240s apart; cache terminals. Only core is packaged.
