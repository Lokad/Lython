from pathlib import Path
import ast,datetime,hashlib,io,json,shlex,subprocess,tarfile
r=Path(__file__).resolve().parent;q=r/'quiet';sha=lambda b:hashlib.sha256(b).hexdigest()
old=json.loads((q/'config.json').read_text(encoding='utf-8'))
assert 'Allocation.deps.json' in old['identity']['imageFiles']['reference']
(q/'initial-stage.log').write_bytes((q/'launch.log').read_bytes())
(q/'initial-config.json').write_text(json.dumps(old,indent=2)+'\n',encoding='utf-8')
identity=old['identity']
for role in ['reference','candidate']:
 identity['imageFiles'][role]={n:h for n,h in identity['imageFiles'][role].items() if n in old['sourceFiles']}
 assert set(identity['imageFiles'][role])==set(old['sourceFiles'])
 for n,h in identity['imageFiles'][role].items():assert sha((r/'frozen'/role/n).read_bytes())==h
(q/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8')
code='''from pathlib import Path
import fcntl,hashlib,json,os,shutil,stat,subprocess
c=CONFIG
original=ORIGINAL
b=Path('/home/lokad/lython-bench-checks');root=Path(c['root']);source=Path(c['source']);sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
with(b/'comparison-vm.lock').open('a')as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert root.resolve()==root and root.parent==b
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record'],capture_output=True).returncode==1
 assert not any(os.path.ismount(p)for p in b.glob('*/guest-fixtures'))
 assert not(root/'confirmation').exists()and not(root/'retirement-receipt.json').exists()
 assert json.loads((root/'identity.json').read_text())==original
 for proof in c['retireGroups']:assert all(not(b/p).exists()for p in proof['paths'])
 for role in ['reference','candidate']:
  (root/role).mkdir(exist_ok=True)
  for n,h in c['identity']['imageFiles'][role].items():
   p=root/role/n
   assert sha(source/'reference'/n)==c['sourceFiles'][n]
   if not p.exists():os.link(source/'reference'/n,p)
   assert sha(p)==h
  assert set(p.name for p in(root/role).iterdir())==set(c['identity']['imageFiles'][role])
 (root/'identity.json').write_text(json.dumps(c['identity'],indent=2)+'\\n')
 os.link(source/'cpython-worker.py',root/'cpython-worker.py')
 assert sha(root/'representative.json')==c['catalogSHA256']
 for n in ['collect.py','archive-owned.py']:__import__('ast').parse((root/n).read_text())
 subprocess.run(['/bin/sh','-n',str(root/'run.sh')],check=True)
 (root/'retirement-receipt.json').write_text(json.dumps(dict(retiredOnly=c['retireGroups'],freshIdleLease=True,allHashesPathsOwnershipLinksAndAliasesVerified=True,canonicalArchiveAndCurrentImagesPreserved=True,freeAfterBytes=shutil.disk_usage(b).free,initialFailure='Unused local Allocation harness files were incorrectly listed as remote benchmark dependencies. No workers or RAM fixtures started; corrected to the exact existing frozen worker image.'),indent=2)+'\\n')
 fixture=root/'guest-fixtures';fixture.mkdir();assert shutil.disk_usage(b).free>254*1024*1024
 subprocess.run(['sudo','-n','mount','-t','tmpfs','-o','size=32m,mode=0700,uid=lokad,gid=lokad','lython-b848-fixtures',str(fixture)],check=True)
try:subprocess.run(['sudo','-n','systemd-run','--unit='+c['unit'],'--property=User=lokad','--property=WorkingDirectory='+str(root),'--property=RuntimeMaxSec=240','--property=TimeoutStopSec=30','--property=KillMode=control-group','/bin/sh',str(root/'run.sh')],check=True)
except BaseException:
 subprocess.run(['sudo','-n','umount',str(fixture)],check=True);fixture.rmdir();raise
print(json.dumps(dict(launched=True,root=str(root),freeBytes=shutil.disk_usage(b).free,correctedImageCount=len(c['sourceFiles']))))
'''
new=dict(old);new['identity']=identity
code=code.replace('CONFIG',repr(new)).replace('ORIGINAL',repr(json.loads((q/'initial-config.json').read_text(encoding='utf-8'))['identity']))
ast.parse(code);(q/'repair-remote.py').write_text(code,encoding='utf-8')
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
p=subprocess.run(ssh+['python3 -'],input=code,text=True,encoding='utf-8',capture_output=True,timeout=60)
(q/'repair.log').write_text(p.stdout+p.stderr,encoding='utf-8');assert p.returncode==0,p.stdout+p.stderr
(q/'config.json').write_text(json.dumps(new,indent=2)+'\n',encoding='utf-8')
now=datetime.datetime.now(datetime.timezone.utc)
(q/'observe-not-before.json').write_text(json.dumps(dict(launchedAtUTC=now.isoformat(),doNotObserveBeforeUTC=(now+datetime.timedelta(seconds=185)).isoformat()),indent=2)+'\n',encoding='utf-8')
print(p.stdout)
