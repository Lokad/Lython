from pathlib import Path
import ast, copy, hashlib, io, json, os, shutil, subprocess, tarfile

r=Path(__file__).resolve().parent
repo=Path('D:/code/Lython')
work=repo/'.git/agent-worktrees/generator-consolidation-r445'
prior=r.parent/'generated-scripts-r444'
old=r.parent/'cased-word-stream-r440/refined/quiet'
sha=lambda b:hashlib.sha256(b).hexdigest()

def replace(path, before, after):
    p=work/path;s=p.read_text(encoding='utf-8');assert before in s,path
    p.write_text(s.replace(before,after),encoding='utf-8',newline='\n')

replace('docs/RUNTIME.md',
 'Lambda code is prepared once during compilation, including lambdas in lazy type\nmetadata; their values and defaults still evaluate at the Python definition point.',
 'Lambda and generator-expression code is prepared once during compilation, including\ncallables in lazy type metadata. Values and defaults still evaluate at the Python\ndefinition point; generator expressions acquire their outer iterator immediately.')
replace('docs/RUNTIME.md',
 'lambda compilation. Lowered class suites and annotations retain their evaluator.',
 'callable compilation. Generator expressions use the same executable generator and\nprotocols in class suites and annotations as at ordinary executable sites. Their\nframe and cursor storage is admitted at construction, which can reject a tight\nallowance earlier than deferred interpretation. Lowered class suites and annotations\nretain their evaluator for their remaining expressions.')
replace('docs/COMPATIBILITY.md',
 'remaining work. Executable creation sites support send/throw/close; required\nlowered/class creation routes retain an iterator-only interface.',
 'remaining work. All creation sites, including class suites and annotations, support\n`send`, `throw` and `close` through the same executable generator.')
replace('tests/README.md',
 'Existing generator fixtures retain pending-protocol cancellation/refusal, send,\nthrow, close and awaited resource cleanup checks.',
 'Existing generator fixtures retain pending-protocol cancellation/refusal, send,\nthrow, close and awaited resource cleanup checks.\n[Lowered generator protocols](Lokad.Lython.PublicApi.Tests/LoweredGeneratorProtocolTests.cs)\ncover class and annotation creation, eager outer acquisition and live captures\nagainst independent Python results under both APIs. Class-created generators also\nexercise genuinely pending host work and cancellation; construction refusal keeps\nthe outer resource funded until its asynchronous disposal completes.')

q=r/'quiet';q.mkdir(exist_ok=False)
catalog=json.loads((prior/'quiet/representative.json').read_text(encoding='utf-8'))
report=next(c for c in catalog['cases'] if c['id']=='scripts.report-render.large')
changed=copy.deepcopy(report)
changed.update(id='scripts.report-render.class-generator',description='Render a complete report through a class-created generator expression')
source=changed['source']
needle="written = 0\n"
if needle not in source:needle='written=0\n'
assert needle in source,source
source=source.replace(needle,'class Report:\n    rows = (render(record) for record in records)\n\n'+needle)
oldloop='    for record in records:\n        target.write(render(record))'
assert oldloop in source,source
source=source.replace(oldloop,'    for row in Report.rows:\n        target.write(row)')
changed['source']=source;changed['sourceSha256']=sha(source.encode())
calls=json.loads((old/'representative.json').read_text(encoding='utf-8'))
calls=next(c for c in calls['cases'] if c['id']=='calls.positional.large')
normal=next(c for c in catalog['cases'] if c['id']=='scripts.text-normalization.large')
catalog['cases']=[changed,report,normal,calls]
raw=(json.dumps(catalog,ensure_ascii=False,indent=2)+'\n').encode()
(q/'representative.json').write_bytes(raw)
for c in catalog['cases']:
    for field,key in [('source','sourceSha256'),('fixtureJson','fixtureSha256'),('expectedOutput','expectedOutputSha256')]:assert sha(c[field].encode())==c[key]
    fixture=json.loads(c['fixtureJson']);assert fixture['size']==c['size'] and 'text' in fixture

reference=r.parent/'cased-word-stream-r440/refined/frozen/reference'
frozen=r/'frozen';frozen.mkdir()
for role in ['reference','candidate']:shutil.copytree(reference,frozen/role)
core=work/'src/Lokad.Lython/bin/Release/net11.0/Lokad.Lython.dll'
shutil.copy2(core,frozen/'candidate/Lokad.Lython.dll')
images={role:{p.name:sha(p.read_bytes()) for p in sorted((frozen/role).iterdir()) if p.is_file()} for role in ['reference','candidate']}
assert images['reference']['Lokad.Lython.dll'].startswith('0443b5cf')
assert [n for n in images['candidate'] if images['candidate'][n]!=images['reference'][n]]==['Lokad.Lython.dll']
for role,files in images.items():
    for n,h in files.items():assert sha((frozen/role/n).read_bytes())==h

paths=subprocess.check_output(['git','ls-files','-z','src','tests','docs','Directory.Build.props','Directory.Build.targets','global.json'],cwd=work).decode().split('\0')
paths=[n for n in paths if n and (work/n).is_file()]
paths+=['tests/Lokad.Lython.PublicApi.Tests/LoweredGeneratorProtocolTests.cs']
inputs={n:sha((work/n).read_bytes()) for n in sorted(set(paths))}
with tarfile.open(r/'candidate-sources.tar.xz','w:xz') as t:
    for n in inputs:t.add(work/n,arcname=n)
(r/'inputs.json').write_text(json.dumps(dict(baseRevision='7fd674ce',files=inputs,deleted=['src/Lokad.Lython/Runtime/PyGeneratorExpression.cs']),indent=2)+'\n',encoding='utf-8')
identity=dict(sourceRevision='R445 uncommitted generator consolidation against qualified0443b5cf; exact input archive recorded',purpose='One executable generator for class/annotation and ordinary sites. Whole class-generator report plus unchanged report/normalization/call controls; compile,warm,fresh separated.',imageFiles=images,coreSHA256={label:images['candidate' if label.startswith('candidate') else 'reference']['Lokad.Lython.dll'] for label in ['candidate','reference','candidate-control','reference-control']},catalogSHA256=sha(raw),catalogInitialization='Same fixed four-case catalog in all workers,including complete class-generator report and three controls.',inputsSHA256=sha((r/'inputs.json').read_bytes()),sourceArchiveSHA256=sha((r/'candidate-sources.tar.xz').read_bytes()),publicationHeld=True)
(q/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8')
jobs=[[changed['id'],lane] for lane in ['compile','warm','compile-run']]+[[c['id'],'warm'] for c in [report,normal,calls]]
s=(old/'collect.py').read_text(encoding='utf-8');a=s.index('jobs=');b=s.index('\nenv =',a)
s=s[:a]+'jobs='+repr(jobs)+'\nassert len(jobs)==6 and all(case in cases for case,lane in jobs)\n'+s[b:]
s=s.replace("(8 if lane=='compile'else 4)",'4')
ast.parse(s);(q/'collect.py').write_text(s,encoding='utf-8',newline='\n')
for n in ['archive-owned.py','run.sh','retrieve.py']:
    s=(prior/'quiet'/n).read_text(encoding='utf-8').replace('B847','B848').replace('generated-scripts-b847-20261116','generator-consolidation-b848-20261116')
    (q/n).write_text(s,encoding='utf-8',newline='\n')
shutil.copy2(repo/'benchmarks/cpython-worker.py',q/'cpython-worker.py')
(r/'preparation.json').write_text(json.dumps(dict(jobs=jobs,images=images,catalogSHA256=sha(raw),sourceArchiveSHA256=identity['sourceArchiveSHA256']),indent=2)+'\n',encoding='utf-8')
print(json.dumps(dict(jobs=jobs,coreSHA256=identity['coreSHA256'],catalogSHA256=sha(raw),sourceBytes=len(source.encode()),imageBytes=core.stat().st_size)))
