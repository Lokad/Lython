from pathlib import Path
r=Path(__file__).resolve().parent;w=Path('D:/code/Lython/.git/agent-worktrees/generator-consolidation-r445')
def edit(name,old,new):
 p=w/name;s=p.read_text(encoding='utf-8');assert old in s,(name,old[:100]);p.write_text(s.replace(old,new,1),encoding='utf-8',newline='\n')
edit('src/Lokad.Lython/Frontend/Syntax.cs','internal IReadOnlyList<LambdaExpressionSyntax> PreparedLambdas { get; set; } = [];','internal IReadOnlyList<ExpressionSyntax> PreparedCallables { get; set; } = [];')
edit('src/Lokad.Lython/Frontend/Syntax.cs','''internal sealed record GeneratorExpressionSyntax(
    ExpressionSyntax ItemExpression,
    IReadOnlyList<ComprehensionClauseSyntax> Clauses,
    LythonSourceSpan Span) : ExpressionSyntax(Span);''','''internal sealed record GeneratorExpressionSyntax(
    ExpressionSyntax ItemExpression,
    IReadOnlyList<ComprehensionClauseSyntax> Clauses,
    LythonSourceSpan Span) : ExpressionSyntax(Span)
{
    internal LoweredGeneratorExpression? PreparedCallable { get; set; }

    // Prepared code points back to this syntax; exclude compilation metadata
    // from structural equality, as for lambda callables.
    public bool Equals(GeneratorExpressionSyntax? other)
        => ReferenceEquals(this, other) || other is not null && base.Equals(other) &&
            EqualityComparer<ExpressionSyntax>.Default.Equals(ItemExpression, other.ItemExpression) &&
            EqualityComparer<IReadOnlyList<ComprehensionClauseSyntax>>.Default.Equals(Clauses, other.Clauses);

    public override int GetHashCode() => HashCode.Combine(base.GetHashCode(), ItemExpression, Clauses);
}''')
p=w/'src/Lokad.Lython/Frontend/LexicalScopePreparation.cs';s=p.read_text(encoding='utf-8');assert s.count('List<LambdaExpressionSyntax>? lambdas')==1
s=s.replace('List<LambdaExpressionSyntax>? lambdas','List<ExpressionSyntax>? callables').replace('(lambdas ??= []).Add(lambda);','(callables ??= []).Add(lambda);').replace('script.PreparedLambdas = lambdas ?? [];','script.PreparedCallables = callables ?? [];')
old='if (generator) facts = scope.BindGeneratorAssignments(node, facts);';assert old in s
s=s.replace(old,'''if (generator)
                {
                    (callables ??= []).Add(node);
                    facts = scope.BindGeneratorAssignments(node, facts);
                }''');p.write_text(s,encoding='utf-8',newline='\n')
p=w/'src/Lokad.Lython/Frontend/LoweredExpression.cs';s=p.read_text(encoding='utf-8');a=s.index('internal sealed record LoweredGeneratorExpression(');b=s.index('\ninternal abstract record LoweredDictionaryDisplayItem',a)
s=s[:a]+'''internal sealed record LoweredGeneratorExpression : LoweredExpression
{
    public LoweredGeneratorExpression(GeneratorExpressionSyntax generator, LoweredExpression itemExpression,
        IReadOnlyList<LoweredComprehensionClause> clauses)
    {
        Generator = generator;
        ItemExpression = itemExpression;
        Clauses = clauses;
        ScopeFacts = generator.PreparedComprehensionScopeFacts ??
            ComprehensionSyntaxFacts.Bindings(clauses.Select(clause => clause.Target), generator: true);
        generator.PreparedCallable = this;
    }

    public GeneratorExpressionSyntax Generator { get; }
    public LoweredExpression ItemExpression { get; }
    public IReadOnlyList<LoweredComprehensionClause> Clauses { get; }
    public override ExpressionSyntax Syntax => Generator;
    public ScopeDirectiveFacts ScopeFacts { get; }
    internal ExecutableCodeObject? PreparedCode { get; private set; }
    public ExecutableCodeObject Code => PreparedCode.RequireNotNull();
    internal void CompleteCompilation(ExecutableCodeObject code) => PreparedCode = code;
}
'''+s[b:];p.write_text(s,encoding='utf-8',newline='\n')
edit('src/Lokad.Lython/Frontend/LoweredScript.cs','GeneratorExpressionSyntax generator => new LoweredGeneratorExpression(','GeneratorExpressionSyntax generator => generator.PreparedCallable ?? new LoweredGeneratorExpression(')
edit('src/Lokad.Lython/Frontend/ExecutableScript.Builder.cs','''        // Remaining lambdas belong to retained lowered consumers and keep their
        // existing namespace closure, with code prepared before execution.
        foreach (var syntax in lowered.Syntax.PreparedLambdas)
        {
            // Lazy annotations/type values can retain raw expressions until
            // runtime. Prepare their callable code without evaluating them.
            var lambda = syntax.PreparedCallable ?? (LoweredLambdaExpression)LoweredScript.LowerStandaloneExpression(syntax);
            if (lambda.PreparedCode is null) CompileNamespaceLambda(lambda);
        }''','''        // Remaining callables belong to retained lowered consumers or lazy
        // annotations. Prepare their namespace code without evaluating them.
        foreach (var syntax in lowered.Syntax.PreparedCallables)
        {
            switch (syntax)
            {
                case LambdaExpressionSyntax lambdaSyntax:
                    var lambda = lambdaSyntax.PreparedCallable ?? (LoweredLambdaExpression)LoweredScript.LowerStandaloneExpression(lambdaSyntax);
                    if (lambda.PreparedCode is null) CompileNamespaceLambda(lambda);
                    break;
                case GeneratorExpressionSyntax generatorSyntax:
                    var generator = generatorSyntax.PreparedCallable ?? (LoweredGeneratorExpression)LoweredScript.LowerStandaloneExpression(generatorSyntax);
                    if (generator.PreparedCode is null)
                        generator.CompleteCompilation(new Builder(FunctionParameterLayout.Create([]), true, GeneratorFacts(generator))
                            .CompileCodeObject("<genexpr>", [], generator));
                    break;
                default: throw new InvalidOperationException("Unexpected prepared callable syntax.");
            }
        }''')
edit('src/Lokad.Lython/Frontend/ExecutableScript.Builder.cs','''    private static void CompileNamespaceLambda''','''    private static ScopeDirectiveFacts GeneratorFacts(LoweredGeneratorExpression expression)
        => expression.ScopeFacts with { LocalNames = new HashSet<string>(expression.ScopeFacts.LocalNames, StringComparer.Ordinal) { ".0" } };

    private static void CompileNamespaceLambda''')
edit('src/Lokad.Lython/Frontend/ExecutableScript.Comprehensions.cs','''            var locals = new HashSet<string>(expression.ScopeFacts.LocalNames, StringComparer.Ordinal) { ".0" };
            var facts = expression.ScopeFacts with { LocalNames = locals };
            var builder = new Builder(FunctionParameterLayout.Create([]), ChildClosureCandidates(), facts,
                completeLexicalParent: _completeLexicalParent) { _generator = true };
            var code = builder.CompileCodeObject("<genexpr>", [], expression);''','''            if (expression.PreparedCode is null)
            {
                var builder = new Builder(FunctionParameterLayout.Create([]), ChildClosureCandidates(), GeneratorFacts(expression),
                    completeLexicalParent: _completeLexicalParent) { _generator = true };
                expression.CompleteCompilation(builder.CompileCodeObject("<genexpr>", [], expression));
            }
            var code = expression.Code;''')
p=w/'src/Lokad.Lython/Runtime/LythonRuntime.Resolution.cs';s=p.read_text(encoding='utf-8');a=s.index('        var clauses = generator.Clauses.Select',s.index('private static object EvaluateGeneratorExpression'));b=s.index('\n    private static void EvaluateComprehensionClauses',a)
s=s[:a]+'''        var prepared = generator.PreparedCallable.RequireNotNull();
        var outer = prepared.Clauses[0].Iterable;
        return PyGenerator.CreateExpressionAsync(prepared.Code, context,
            EvaluateLoweredExpression(outer, context), outer.Span, generator.Span, false)
            .GetAwaiter().GetResult();
    }
'''+s[b:];p.write_text(s,encoding='utf-8',newline='\n')
edit('src/Lokad.Lython/Runtime/LythonRuntime.Lowered.Shared.cs','''                // Acquire the outermost iterable eagerly, exactly as the synchronous
                // construction site does; user __iter__ still resolves synchronously
                // here (async-capable resolution belongs to a separate change).
                var outer = await execution.EvaluateExpressionAsync(generator.Clauses[0].Iterable, context).ConfigureAwait(false);
                var producedAsync = new PyGeneratorExpression(
                    generator.Clauses,
                    generator.ItemExpression,
                    context.FunctionClosureContext,
                    generator.Span,
                    await PyIteration.AcquireGeneratorOuterAsync(outer, generator.Clauses[0].Iterable.Span, context).ConfigureAwait(false), generator.ScopeFacts);
                producedAsync.AttachAsyncOuter(outer);
                return producedAsync;''','''                var outer = await execution.EvaluateExpressionAsync(generator.Clauses[0].Iterable, context).ConfigureAwait(false);
                return await PyGenerator.CreateExpressionAsync(generator.Code, context, outer,
                    generator.Clauses[0].Iterable.Span, generator.Span, true).ConfigureAwait(false);''')
print('Existing compiler callable preparation now covers surviving generator expressions; both evaluators use the compiled generator factory. Legacy class deletion/test migration next.')
