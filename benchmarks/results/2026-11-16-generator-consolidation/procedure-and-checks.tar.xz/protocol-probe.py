class Holder:
    values = (value + 1 for value in range(3))

for name in ('send', 'throw', 'close'):
    try:
        method = getattr(Holder.values, name)
        print(name, callable(method))
    except AttributeError:
        print(name, 'missing')
try:
    print('sent', Holder.values.send(None))
    Holder.values.close()
    print('closed', list(Holder.values))
except AttributeError:
    print('generator protocol missing')
