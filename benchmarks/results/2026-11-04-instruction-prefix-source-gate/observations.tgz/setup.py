from pathlib import Path
import hashlib,json
root=Path('/home/lokad/lython-bench-checks/instruction-prefix-source-gate-b230-20261104')
base=Path('/home/lokad/lython-bench-checks/prepared-declarations-b227-20261104/candidate')
(root/'candidate').symlink_to(base,target_is_directory=True)
i=json.loads((root/'identity.json').read_text(encoding='utf-8'))
assert hashlib.sha256((base/'Lokad.Lython.dll').read_bytes()).hexdigest()==i['files']['Lokad.Lython.dll']
