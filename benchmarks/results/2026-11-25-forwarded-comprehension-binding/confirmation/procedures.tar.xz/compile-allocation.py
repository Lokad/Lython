from pathlib import Path
from statistics import median
import json, os, shutil, subprocess

lab = Path(__file__).resolve().parent
quiet = lab / "comparison/quiet"
donor = lab.with_name("shared-literal-decoding-20261124") / "refinement/compiler-owner"
sdk = Path.home() / ".dotnet11"
env = dict(os.environ, DOTNET_ROOT=str(sdk), DOTNET_ROOT_X64=str(sdk))
read = lambda path: json.loads(path.read_text(encoding="utf-8-sig"))
identity = read(quiet / "identity.json")
rows = {}
for role in ("reference", "candidate"):
    image = lab / (role + "-compiler-owner")
    image.mkdir(exist_ok=True)
    for path in donor.glob("Inspect*"):
        shutil.copyfile(path, image / path.name)
    shutil.copyfile(lab / role / "Lokad.Lython.dll", image / "Lokad.Lython.dll")
    output = lab / (role + "-compiler-owner.json")
    subprocess.run([sdk / "dotnet.exe", image / "Inspect.dll", quiet / "representative.json", output], env=env, check=True, timeout=60)
    data = read(output)
    assert data["coreSHA256"] == identity["coreSHA256"][role]
    rows[role] = data["rows"]
summary = []
for before, after in zip(rows["reference"], rows["candidate"], strict=True):
    assert before["id"] == after["id"]
    row = dict(case=before["id"],
        allocationBytes=[median(r["allocatedBytes"]) for r in (before, after)],
        retainedAdmission=[r["retainedAdmission"] for r in (before, after)])
    print(row)
    summary.append(row)
(lab / "compile-allocation-summary.json").write_text(json.dumps(summary, indent=2)+"\n",encoding="utf-8", newline="\n")
