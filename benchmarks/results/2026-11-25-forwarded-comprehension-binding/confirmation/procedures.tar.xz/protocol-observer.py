class PublishCaller:
    def __iter__(self):
        return self
    __next__ = staticmethod(locals)

def stop(self):
    raise StopIteration

class Gate:
    def __eq__(self, other):
        PublishCaller.__next__ = stop
        return other == 'yes'

def work():
    row = 'outside'
    gate = Gate()
    result = [row['gate'] == 'yes' for row in PublishCaller()]
    return result, row

print(work())
