def stop(self):
    raise StopIteration
class Marker:
    def __getitem__(self, name):
        return 1
    def __eq__(self, other):
        ObservePrevious.__next__ = stop
        return other == 1
class ObservePrevious:
    def __iter__(self):
        return self
    def __next__(self):
        ObservePrevious.__next__ = staticmethod(locals)
        return Marker()
def work():
    row = 'outside'
    return [row['row'] == 1 for row in ObservePrevious()], row
print(work())
