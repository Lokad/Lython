class ObserveCaller:
    def __iter__(self): return self
    __next__ = staticmethod(locals)

def stop(self): raise StopIteration

class Marker:
    def __getitem__(self, name): return 1
    def __eq__(self, other):
        ObservePrevious.__next__ = stop
        return other == 1

class ObservePrevious:
    def __iter__(self): return self
    def __next__(self):
        ObservePrevious.__next__ = staticmethod(locals)
        return Marker()

def work():
    row = 'outside'
    try:
        [row['row'] for row in ObserveCaller()]
    except KeyError:
        print(row)
    payload = []
    projected = [row for row in [payload, payload]]
    print(projected[0] is projected[1] is payload, row)
    print([row['row'] == 1 for row in ObservePrevious()], row)

work()

