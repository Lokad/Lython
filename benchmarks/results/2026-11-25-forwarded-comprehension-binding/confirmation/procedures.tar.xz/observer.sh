set -eu
export DOTNET_ROOT="$HOME/.dotnet"
export PATH="$DOTNET_ROOT:$PATH"
lab="$PWD/.git/agent-notes/review-20261031/lexical-comprehension-confirmation-20261125"
dotnet test tests/Lokad.Lython.PublicApi.Tests/Lokad.Lython.PublicApi.Tests.csproj -c Release -f net10.0 --artifacts-path "$lab/ubuntu" --filter FullyQualifiedName~IteratorCanObserveTheShadowedBindingBeforeAndAfterTheFirstItem --no-restore --nologo > "$lab/observer-ubuntu10.log" 2>&1
tail -6 "$lab/observer-ubuntu10.log"
