from pathlib import Path
import hashlib,json,shutil,subprocess,os,tarfile

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
reference=lab.with_name('deferred-callable-locals-refined-20261125')
reference_quiet=reference/'comparison/quiet'
template=lab.with_name('prepared-map-callback-20261125')
earlier=lab.with_name('lexical-comprehension-assessment-20261125')
earlier_quiet=earlier/'comparison/quiet'
quiet=lab/'comparison/quiet'
quiet.mkdir(parents=True,exist_ok=True)
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
digest=lambda b:hashlib.sha256(b).hexdigest()
git=lambda *args:subprocess.check_output(['git',*args],cwd=repo)
def write(p,s): p.write_text(s,encoding='utf-8',newline='\n')
def save(p,v): write(p,json.dumps(v,indent=2,ensure_ascii=False)+'\n')
head=git('rev-parse','HEAD').decode().strip()
assert head.startswith('4e8e60923')
anchor=read(reference_quiet/'identity.json')
assert git('diff','--binary',anchor['sourceRevision'],head,'--','src')==(reference/'candidate.patch').read_bytes()
base=anchor['imageFiles']['candidate']
assert len(base)==32 and {f.name:sha(f)for f in (reference/'candidate').iterdir()}==base
core=repo/'src/Lokad.Lython/bin/Release/net11.0/Lokad.Lython.dll'
assert sha(core)==sha(repo/'tools/LythonProbe/bin/Release/net11.0/Lokad.Lython.dll')
patch=git('diff','--binary','HEAD','--','src')
assert patch.count(b'diff --git ')==6
(lab/'candidate.patch').write_bytes(patch)
(lab/'tests.patch').write_bytes(git('diff','--binary','HEAD','--','tests'))
images=dict(reference=base,candidate=base|{core.name:sha(core)})
for role,files in images.items():
    path=lab/role
    path.mkdir(exist_ok=True)
    for name in files:
        shutil.copyfile(core if role=='candidate' and name==core.name else reference/'candidate'/name,path/name)
    assert {p.name:sha(p)for p in path.iterdir()}==files

catalog=read(template/'comparison/quiet/representative.json')
candidates={c['id']:c for c in catalog['cases']}
# The text and file-fed scripts remain unchanged controls. Keep the existing
# shipment script as the target and give it both hosting lanes.
shipment='diagnostic.shipment-routing-callbacks'
filefed='diagnostic.shipment-file-fed-map'
text='diagnostic.text-summary.nonlocal-computed-width.large'
catalog['cases']=[candidates[name] for name in (shipment,filefed,text)]
observer_source=(lab/'shadow-observer.py').read_text(encoding='utf-8-sig')
observer=candidates[shipment].copy()
stub=read(reference/'representative.json')['cases'][-1]
observer=stub|dict(id='diagnostic.comprehension-protocol-observes-shadow',source=observer_source,
                  sourceUtf8Bytes=len(observer_source.encode()),sourceSha256=digest(observer_source.encode()),
                  expectedOutput='outside\n',expectedOutputUtf8Bytes=8,expectedOutputSha256=digest(b'outside\n'))
catalog['cases'].append(observer)
save(quiet/'representative.json',catalog)
jobs=[(text,'warm'),(shipment,'compile-run'),(shipment,'warm-async'),(filefed,'warm-async'),(shipment,'warm')]
save(quiet/'jobs.json',{'warm':jobs})
identity=dict(sourceRevision=head,comparisonRevision=head,sourcePatchSHA256=sha(lab/'candidate.patch'),
    inputCatalogSHA256=sha(quiet/'representative.json'),imageFiles=images,
    coreSHA256={role+suffix:files[core.name]for role,files in images.items()for suffix in ('','-control')},
    cpythonWorkerSHA256=anchor['cpythonWorkerSHA256'],expectedCPythonSHA256=anchor['expectedCPythonSHA256'],
    catalogs={name:dict(sha256=sha(quiet/name))for name in ('representative.json','jobs.json')},
    purpose='Forward one eager comprehension binding with structured compiler cancellation')
save(quiet/'identity.json',identity)

sdk=Path.home()/'.dotnet11'
dotnet=sdk/'dotnet.exe'
env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk))
python_worker=repo/'benchmarks/cpython-worker.py'
assert sha(python_worker)==identity['cpythonWorkerSHA256']
for role,files in images.items():
    image=lab/role
    evidence=lab/(role+'-verify.json')
    subprocess.run([dotnet,image/'Lokad.Lython.Benchmarks.dll','--compare','verify','--catalog',quiet/'representative.json',
        '--dotnet',dotnet,'--python','C:/Python313/python.exe','--python-worker',python_worker,'--out',evidence],
        cwd=repo, env=env, check=True, timeout=80)
    checked=read(evidence)
    assert checked['state']=='Completed' and checked['caseCount']==4
    assert checked['catalogSha256']==identity['inputCatalogSHA256']
    assert checked['launched']['library']['sha256']==files[core.name]

old_receipt=read(reference_quiet/'terminal-status.json')['receipt']
assert old_receipt['complete'] and sha(reference_quiet/'observations.tar.xz')==old_receipt['archiveSHA256']
for name in ('collect.py','run.sh'):
    write(quiet/name,(reference_quiet/name).read_text(encoding='utf-8').replace('b1735c-fixtures','b1737c-fixtures'))
assert b'\r' not in (quiet/'run.sh').read_bytes()
s=(reference/'quiet.py').read_text(encoding='utf-8')
s=s.replace('lython-b1735c-deferred-callable-locals','lython-b1737c-forwarded-comprehension')
s=s.replace('b1735c','b1737c').replace('b1714','b1737c')
s=s.replace("os.link(reference/'reference'/name,image/name)","os.link(reference/'candidate'/name,image/name)")
start=s.index("assert donor['archiveSHA256']=='")
end=s.index('\n',start)
s=s[:start]+f"assert donor['archiveSHA256']=={old_receipt['archiveSHA256']!r}"+s[end:]
compile(s,'quiet.py','exec')
write(lab/'quiet.py',s)
write(lab/'archive.py',(reference/'archive.py').read_text(encoding='utf-8').replace(
    '2026-11-25-deferred-callable-locals/confirmation','2026-11-25-forwarded-comprehension-binding/confirmation'))
earlier_receipt=read(earlier_quiet/'terminal-status.json')['receipt']
earlier_image=read(earlier_quiet/'identity.json')['imageFiles']['candidate']
assert earlier_receipt['complete'] and sha(earlier_quiet/'observations.tar.xz')==earlier_receipt['archiveSHA256']
candidate=earlier/'candidate'
assert len(earlier_image)==32 and {p.name:sha(p)for p in candidate.iterdir()}==earlier_image
replicas=[]
for archive in (reference_quiet,earlier_quiet):
    receipt=read(archive/'terminal-status.json')['receipt']
    assert sha(archive/'observations.tar.xz')==receipt['archiveSHA256']
    with tarfile.open(archive/'observations.tar.xz') as bundle:
        raw=bundle.extractfile('confirmation/confirmation.json').read()
    replicas.append(dict(location=read(archive/'upload.json')['root'],member='confirmation/confirmation.json',
        bytes=len(raw),rawSHA256=digest(raw),archiveSHA256=receipt['archiveSHA256']))
f=candidate/core.name
replicas.append(dict(location=read(earlier_quiet/'upload.json')['root'],member='candidate/Lokad.Lython.dll',
    bytes=f.stat().st_size,rawSHA256=sha(f),archiveSHA256=earlier_receipt['archiveSHA256'],
    localFrozenImage=str(candidate),localImageFileCount=32))
save(lab/'verified-raw-replicas.json',replicas)
payload=quiet/'payload.tar.gz'
with tarfile.open(payload,'w:gz',compresslevel=3) as tar:
    for name in ('identity.json','jobs.json','representative.json','run.sh','collect.py'):
        tar.add(quiet/name,arcname=name)
    tar.add(lab/'candidate/Lokad.Lython.dll',arcname='candidate-core.dll')
save(quiet/'upload.json',dict(root='forwarded-comprehension-binding-b1737c-20261125',
    reference=read(reference_quiet/'upload.json')['root'],payloadSHA256=sha(payload),payloadBytes=payload.stat().st_size))
print('Verified four independent CPython output and file goldens per complete image.')
