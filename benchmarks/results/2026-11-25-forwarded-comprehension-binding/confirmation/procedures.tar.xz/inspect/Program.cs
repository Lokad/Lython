using System.Collections;
using System.Reflection;
using System.Security.Cryptography;
using System.Text.Json;
using Lokad.Lython;

using var catalog = JsonDocument.Parse(File.ReadAllText(args[0]));
var cases = catalog.RootElement.GetProperty("cases").EnumerateArray();
var rows = new List<object>();
foreach (var item in cases)
{
var workload = item.GetProperty("id").GetString()!;
if (workload != "diagnostic.shipment-routing-callbacks") continue;
var source = item.GetProperty("source").GetString()!;
var budget = new LythonMemoryBudget(32L * 1024 * 1024);
using var script = new LythonEngine().Compile(source, budget);
if (!script.IsValid) throw new InvalidOperationException(string.Join("\n", script.Diagnostics));
const BindingFlags flags = BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic;
object Read(object target, string property) => target.GetType().GetProperty(property, flags)!.GetValue(target)!;
var executable = script.GetType().GetField("_executable", flags)!.GetValue(script)!;
var entry = Read(executable, "EntryPoint");
var work = new Stack<object>();
work.Push(entry);
var seen = new HashSet<object>(ReferenceEqualityComparer.Instance);
var inspected = new List<object>();
while (work.TryPop(out var code))
{
    if (!seen.Add(code)) continue;
    foreach (var value in (IEnumerable)Read(code, "Constants"))
    {
        if (value is null) continue;
        if (value.GetType().Name == "ExecutableCreateFunction") work.Push(Read(value, "CodeObject"));
        else if (value.GetType().Name == "ExecutableCreateClass") work.Push(Read(value, "Body"));
    }
    var name = (string)Read(code, "Name");
    
    var sites = ((IEnumerable)Read(code, "CallSites")).Cast<object>().ToArray();
    var constants = ((IEnumerable)Read(code, "Constants")).Cast<object?>().ToArray();
    var tape = ((IEnumerable)Read(code, "Instructions")).Cast<object>().Select((instruction, i) =>
    {
        var op = Read(instruction, "OpCode").ToString()!;
        object? call = null;
        if (op == "Call")
        {
            var site = sites[(int)Read(instruction, "CallSiteIndex")];
            call = new { argumentCount = Read(site, "ArgumentCount"), hasReceiver = Read(site, "HasReceiver"),
                returnedItems = Read(site, "UnpackedReturnCount"), hasForwardedInputs = Read(instruction, "HasForwardedCallOperands") };
        }
        return new { index = i, opcode = op, input = Read(instruction, "InputStart"), output = Read(instruction, "ResultSlot"),
            extent = Read(instruction, "LiveExtent"), call,
            operation = op == "ApplyOperation" ? constants[(int)Read(instruction, "ConstantIndex")]!.GetType().Name : null };
    });
    inspected.Add(new { name, capacity = Read(code, "ValueStorageCapacity"), locals = Read(code, "LocalNames"),
        tempStart = Read(code, "FirstTemporarySlot"), nativePrefix = Read(code, "NativePrefixEnd"),
        directReturn = Read(code, "HasDirectOperandReturn"), instructionCount = tape.Count(),
        callCount = tape.Count(item => item.call is not null),
        eligibleLoads = tape.Count(item => item.opcode == "LoadGlobalForArithmeticCall"),
        operationCounts = tape.Where(static item => item.operation is not null)
            .GroupBy(static item => item.operation!).ToDictionary(static group => group.Key, static group => group.Count()),
        opcodeCounts = tape.GroupBy(static item => item.opcode).ToDictionary(static group => group.Key, static group => group.Count()) });
}
script.Dispose();
if (budget.ReservedBytes != 0 || inspected.Count < 4) throw new InvalidOperationException("Incomplete inspection or owner cleanup.");
rows.Add(new { name = item.GetProperty("id").GetString(), methods = inspected });
}
var core = typeof(LythonEngine).Assembly.Location;
var evidence = new { coreSHA256 = Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(core))).ToLowerInvariant(),
    rows };
File.WriteAllText(args[1], JsonSerializer.Serialize(evidence, new JsonSerializerOptions { WriteIndented = true }));
