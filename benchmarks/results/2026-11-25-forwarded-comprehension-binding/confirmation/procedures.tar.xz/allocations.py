import json
import os
import shutil
import statistics
import subprocess
from pathlib import Path

lab=Path(__file__).resolve().parent
comparison=lab/"comparison"
sdk=Path.home()/".dotnet11"
env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk))
donor=lab.with_name("json-traversal-20261124")/"reference"
roles={}
for role in ("reference","candidate"):
    image=lab/(role+"-allocation")
    image.mkdir(exist_ok=True)
    for p in (lab/role).iterdir(): shutil.copyfile(p,image/p.name)
    for p in donor.glob("ValidatedAllocation*"): shutil.copyfile(p,image/p.name)
    output=lab/(role+"-allocation-final.json")
    subprocess.run([sdk/"dotnet.exe",image/"ValidatedAllocation.dll",image,comparison/"quiet/representative.json",output],
        env=env,timeout=60,check=True)
    roles[role]=json.loads(output.read_text(encoding="utf-8"))["rows"]
summary=[]
for old,new in zip(roles["reference"],roles["candidate"],strict=True):
    assert old["id"]==new["id"] and old["sharedBudgetBaselineRestored"] and new["sharedBudgetBaselineRestored"]
    row=dict(case=old["id"],allocationBytes=[statistics.median(r["allocatedBytesPerInvocation"])for r in (old,new)],
        peakAdmission=[r["peakExecutionMemoryBytes"]for r in (old,new)])
    print(row)
    summary.append(row)
(lab/"allocation-summary.json").write_text(json.dumps(summary,indent=2)+"\n",encoding="utf-8",newline="\n")
