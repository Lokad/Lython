class ObserveCaller:
    def __iter__(self):
        return self
    __next__ = staticmethod(locals)

def work():
    row = 'outside'
    try:
        [row['row'] for row in ObserveCaller()]
    except KeyError:
        return row
    return 'inner namespace leaked'

print(work())
