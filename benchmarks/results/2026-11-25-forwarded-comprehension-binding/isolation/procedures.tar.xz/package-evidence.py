from pathlib import Path
import hashlib,json,re,shutil,subprocess,tarfile

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
quiet=lab/'comparison/quiet'
out=repo/'benchmarks/results/2026-11-25-forwarded-comprehension-binding/isolation'
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
identity=read(quiet/'identity.json')
patch=lab/'candidate.patch'
tests=lab/'tests.patch'
for folder,f in [('src',patch),('tests',tests)]:
    assert subprocess.check_output(['git','diff','--binary','HEAD','--',folder],cwd=repo)==f.read_bytes()
summary=read(out/'quiet-summary.json')
assert sha(patch)==identity['sourcePatchSHA256']==summary['sourcePatch']
assert summary['timedBatches']==140 and len(summary['rows'])==5
for role,files in identity['imageFiles'].items():
    assert len(files)==32 and {p.name:sha(p)for p in (lab/role).iterdir()}==files
    verified=read(lab/(role+'-verify.json'))
    assert verified['state']=='Completed' and verified['caseCount']==4
    assert verified['launched']['library']['sha256']==files['Lokad.Lython.dll']
    assert read(lab/(role+'-shape.json'))['coreSHA256']==files['Lokad.Lython.dll']
shape=read(lab/'shape-summary.json')
assert [i['instructionCount'] for i in shape]==[73,71]
assert [i['capacity'] for i in shape]==[21,21]
for suite,n in [('Lokad.Lython.PublicApi.Tests',809),('Lokad.Lython.Tests',170)]:
    for platform in ('win11','ubuntu10'):
        assert re.search(rf'Failed:\s+0, Passed:\s+{n},',(lab/f'{suite}-{platform}.log').read_text(encoding='utf-8-sig'))
for name in ('identity.json','storage-custody.json'):
    shutil.copyfile(quiet/name,out/name)
for name in ('shape-summary.json','allocation-summary.json','compile-allocation-summary.json'):
    shutil.copyfile(lab/name,out/name)
with tarfile.open(out/'procedures.tar.xz','w:xz') as bundle:
    for p in ('prepare.py','archive.py','quiet.py','package-evidence.py','candidate.patch','tests.patch',
        'forwarded-probe-build.log','reference-verify.json','candidate-verify.json','test-ubuntu.sh',
        'reference-allocation-final.json','candidate-allocation-final.json','reference-compiler-owner.json',
        'candidate-compiler-owner.json','allocations.py','compile-allocation.py',
        'verified-raw-replicas.json','launch-console.log','retrieve.log','prepare.log',
        'Lokad.Lython.PublicApi.Tests-win11.log','Lokad.Lython.PublicApi.Tests-ubuntu10.log',
        'Lokad.Lython.Tests-win11.log','Lokad.Lython.Tests-ubuntu10.log',
        'inspect/Program.cs','inspect/ArithmeticCallInspection.csproj','reference-shape.json',
        'candidate-shape.json','protocol-observer.py','shadow-observer.py','previous-observer.py','complete-observer.py'):
        bundle.add(lab/p,arcname=p,recursive=False)
print('Verified exact source and tests, 140 batches, four goldens per image, both 979-check logs and shipment tape.')
