
from pathlib import Path
import hashlib
import json
import os
import shutil
import subprocess

lab=Path(__file__).resolve().parent
comparison=lab/'comparison'
identity=json.loads((comparison/'identity.json').read_text(encoding='utf-8'))
inspection=lab.with_name('current-rule-closures-cpython-20261124')/'local-inspection'
digest=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
helpers={}
dotnet=Path.home()/'.dotnet11/dotnet.exe'
env=dict(os.environ,DOTNET_ROOT=str(dotnet.parent),DOTNET_ROOT_X64=str(dotnet.parent))
tapes={}
for role,files in identity['imageFiles'].items():
    image=lab/role
    assert all(digest(image/name)==sha for name,sha in files.items())
    for suffix in ('.dll','.deps.json','.runtimeconfig.json'):
        name='Inspect'+suffix
        shutil.copyfile(inspection/name,image/name)
        helpers[name]=digest(image/name)
    result=lab/(role+'-tapes.json')
    subprocess.run([dotnet,image/'Inspect.dll',comparison/'representative.json',result],
        env=env,check=True,timeout=35)
    tapes[role]=json.loads(result.read_text(encoding='utf-8'))
    assert tapes[role]['coreSHA256']==files['Lokad.Lython.dll']
    assert all(digest(image/name)==sha for name,sha in files.items())
    assert all(digest(image/name)==sha for name,sha in helpers.items())

def read(role,case,name):
    target,=[code for row in tapes[role]['rows'] if row['id']==case
        for code in row['codes'] if code['name']==name]
    return target
case='scripts.captured-rule-closures'
old=read('reference',case,'<lambda>')
new=read('candidate',case,'<lambda>')
assert old['closureNames'] if 'closureNames' in old else old['closures']==['step']
assert not old['directIntegerReturn'] and new['directIntegerReturn']
assert old['opcodeCounts']==dict(LoadLocal=1,LoadClosure=1,Binary=2,Return=1)
assert new['opcodeCounts']==dict(Binary=2,Return=1)
assert old['capacity']==new['capacity']

for role in ('reference','candidate'):
    assert read(role,'scripts.rule-default-closures','<lambda>')['directIntegerReturn']
    assert read(role,'scripts.annotated-rule-closures','evaluate')['directIntegerReturn']
    assert not read(role,case,'apply')['directIntegerReturn']
doc=dict(inspector=helpers,capturedFallback=dict(
    reference=old['opcodeCounts'],candidate=new['opcodeCounts'],activationsDisplacedPerInvocation=2048,
    source='One exact fallback call per iteration for 2,048 iterations in the captured-rule script.'))
(lab/'tape-summary.json').write_text(json.dumps(doc,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps(doc))
