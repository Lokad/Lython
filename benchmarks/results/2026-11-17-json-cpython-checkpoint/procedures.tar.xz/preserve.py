from pathlib import Path
import json,shutil,tarfile
r=Path(__file__).parent;root=Path('D:/code/Lython');dest=root/'benchmarks/results/2026-11-17-json-cpython-checkpoint';dest.mkdir(exist_ok=False)
for name in ['summary.json']:shutil.copyfile(r/name,dest/name)
for name in ['archive-receipt.json','terminal-status.json','observations.tgz','identity.json']:shutil.copyfile(r/'quiet'/name,dest/name)
shutil.copyfile(r.parent/'call-cost-gate-r488/checkpoint-catalog.json',dest/'catalog.json')
with tarfile.open(dest/'procedures.tar.xz','w:xz')as archive:
 for p in sorted(r.rglob('*')):
  if not p.is_file():continue
  n=p.relative_to(r)
  if'retrieved'in n.parts or n.suffix in ['.dll','.pdb']or n.name in ['payload.tgz','observations.tgz']:continue
  archive.add(p,arcname=n.as_posix())
(dest/'README.md').write_text('''# Representative JSON scripts versus CPython

R491/B908,2026-11-17UTC. Committed runtime557381fe/frozend739132f versus stock
CPython3.13.16; normal optional adapter0.4.0. Actual five-case frozen image and
goldens verified versus CPython3.13.2 before staging. Full changed-source
Windows/Ubuntu11/10/stress/installed-package delivery44116196658 is pending.

| Complete script | Compile ratio | Warm ratio | Compile-and-run ratio |
| --- | ---: | ---: | ---: |
| JSON-lines helper aggregation,4096records/110592B | 0.98–1.02× | 0.82–0.85× | 0.86–0.87× |
| Floating numerical JSON report,4096pairs/56495B | 0.90–0.92× | 1.99–2.03× | 1.67–1.76× |

Ratio=Lython elapsed/CPython elapsed; above one means slower. These are process
median combinations, not confidence intervals. JSON warm controlsL/C2.09/0.87%,
IQR≤0.49%; floatingwarm0.96/0.91%,IQR≤1.73%. Floatingfresh controls2.92/2.50% and
compileIQR≤5.15% limit precision. Warm and fresh medians are independently warmed
and not additive. No cross-collection causal source-change gain is claimed.

Quiet AzureF4as_v7/Ubuntu24.04.4,four EPYC9V45vCPUs/16GiB/no swap,.NET11RC3,
normal tiering/workstationGC; CPythonGIL/GC enabled. Six jobs204.45s,5second
rotated warmups/five approximately0.5second samples/two processes per engine.
Warm includes synchronousRun, mediated RAM input/output, full stdout/file goldens
and prior-result cleanup. Fresh adds compilation/compiled-owner disposal; compile
includes compiled-owner disposal. Startup, fixture reset/protocol and final cache
teardown are excluded; wider processCPU includes request work outside guest clocks.
CPython uses native buffered files without equivalent capability/budget checks.

The numerical warm gap remains clear with close controls; compilation does not
explain it. JSON-lines is faster in this named comparison. Neither generalizes to
all scripts, today’s unmeasured HEAD, startup, physical heap/RSS or embedding tails.

All correctness/quiet/Closed/exit/join/archive gates pass. RAM verified persistently
before unmount; terminal cached. Retired only archived3866core aliases and original
backed raw/archive replicas after fresh lease/path/UID/hash/link/all-alias proof;
qualifieddfc/currentd739/toolchains/canonicals and254/252MiB floors preserved.
Publication held; numerical attribution and substantial runtime roadmap continue.

[Exact timing/control data](summary.json),[raw](observations.tgz),[catalog](catalog.json),
[identity](identity.json),[custody](archive-receipt.json),[procedures](procedures.tar.xz),
[actual runtime image](../2026-11-17-shared-allowance-lock/main-frozen-identity.json).
''',encoding='utf-8',newline='\n')
summary=json.loads((r/'summary.json').read_text(encoding='utf-8'));rows={(v['case'],v['lane']):v for v in summary['timing']}
def stats(case,lane):
 v=rows[case,lane];m=v['medianMilliseconds'];rng=lambda names:f'{min(m[n]for n in names):.3f}–{max(m[n]for n in names):.3f}'
 return v,rng(['candidate','candidate-control']),rng(['CPython','CPython-control']),f'{min(v["ratioRange"]):.2f}–{max(v["ratioRange"]):.2f}×'
guide=root/'docs/BENCHMARKS.md';text=guide.read_text(encoding='utf-8');lines=text.splitlines()
mapping={'Floating JSON numeric report':('scripts.numeric-squared-error.floating.large','4,096 records / 56,495 B'),'JSON-lines aggregation':('scripts.json-summary-helpers.large','4,096 records / 110,592 B')}
for i,line in enumerate(lines):
 for old,(case,size)in mapping.items():
  if not line.startswith('| '+old+' |'):continue
  label='JSON-lines aggregation with a helper'if old=='JSON-lines aggregation'else old
  if line.split('|')[2].strip()not in ['Compilation only','Compile and execute once']:
   v,l,c,ratio=stats(case,'warm');lines[i]=f'| {label} | {size} | {l} ms | {c} ms | {ratio} | R491; diagnostic; controls L/C {v["lythonControlPercent"]:.2f}/{v["cpythonControlPercent"]:.2f}%; IQR≤{v["maxIqrPercent"]:.2f}% |'
  else:
   lane='compile'if'Compilation only'in line else'compile-run';v,l,c,ratio=stats(case,lane);phase='Compilation only'if lane=='compile'else'Compile and execute once'
   lines[i]=f'| {label} | {phase} | {l} ms | {c} ms | {ratio} | R491; diagnostic; controls L/C {v["lythonControlPercent"]:.2f}/{v["cpythonControlPercent"]:.2f}%; IQR≤{v["maxIqrPercent"]:.2f}% |'
text='\n'.join(lines)+'\n'
anchor='Measured **2026-11-17 UTC**: original text normalization uses'
assert anchor in text
text=text.replace(anchor,'Measured **2026-11-17 UTC**: JSON-lines helpers and the numerical JSON report use\n**557381fe / frozend739132f**, stock **CPython3.13.16**. Six separated jobs204.45s;\nall measurement gates pass. Changed-source full delivery44116196658 is pending.\n[Current JSON checkpoint and boundaries](../benchmarks/results/2026-11-17-json-cpython-checkpoint/README.md).\nFloating fresh controls2.92/2.50% and compilationIQR≤5.15% limit precision; warm\ncontrols are close. These observations do not establish a causal source gain.\n\nOther named measurements from **2026-11-17 UTC**: original text normalization uses')
text=text.replace('Floating and invoice CSV warm use **abcbd9fd /','Invoice CSV warm uses **abcbd9fd /').replace('CSV compilation/fresh, JSON and search remain earlier','CSV compilation/fresh and search remain earlier')
guide.write_text(text,encoding='utf-8',newline='\n')
print('Six measured JSON phases preserved; authoritative guide refreshed with actual source/versions/boundaries and uncertainty, no causal source gain.')
