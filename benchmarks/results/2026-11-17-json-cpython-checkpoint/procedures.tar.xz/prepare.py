from pathlib import Path
import ast,gzip,hashlib,io,json,shutil,subprocess,tarfile
r=Path(__file__).parent;r.mkdir(exist_ok=True);notes=r.parent;root=Path('D:/code/Lython');retained=notes/'call-cost-gate-r488';old=notes/'utf8-width-r483/refined/cpython'
f=json.loads((retained/'main-frozen-identity.json').read_text(encoding='utf-8'));assert f['runtimeCommit']=='557381fe'
current=f['imageFiles'];assert all(hashlib.sha256((retained/'main-frozen'/n).read_bytes()).hexdigest()==h for n,h in current.items())
catalog=retained/'checkpoint-catalog.json';assert hashlib.sha256(catalog.read_bytes()).hexdigest()==f['catalogSHA256']
canonical='benchmarks/results/2026-11-17-shared-allowance-lock/candidate-core.dll.gz';blob=subprocess.check_output(['git','show','HEAD:'+canonical],cwd=root);assert blob==(root/canonical).read_bytes();data=gzip.decompress(blob);oldsha=hashlib.sha256(data).hexdigest()
assert oldsha not in [current['Lokad.Lython.dll'],'dfc4c83c3e208ee450e8e250af111ea2ad882a04a29e2fbd00fdea6dce0652e7']
s=(notes/'instruction-global-slots-r479/inspect-retirement.py').read_text(encoding='utf-8');a=s.index("code='''");b=s.index('ssh=');scope={'sha':oldsha};exec(s[a:b],scope)
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
p=subprocess.run(ssh+['python3 -'],input=scope['code'],text=True,encoding='utf-8',capture_output=True,timeout=60);assert p.returncode==0,p.stdout+p.stderr
groups=[json.loads(p.stdout)|dict(canonical=canonical,canonicalSHA256=hashlib.sha256(blob).hexdigest(),member='gzip-payload',committedBlobVerified=True,supersededSource='Archived measured3866 superseded by committed557/d739; qualifieddfc and frozen/canonical3866 preserved')]
for canonical,prefix in [('benchmarks/results/2026-11-17-shared-allowance-lock/first/observations.tgz','shared-allowance-lock-b906-20261117'),('benchmarks/results/2026-11-17-shared-allowance-lock/confirmation/observations.tgz','allowance-lock-confirm-b907-20261117')]:
 blob=subprocess.check_output(['git','show','HEAD:'+canonical],cwd=root);assert blob==(root/canonical).read_bytes()
 with tarfile.open(fileobj=io.BytesIO(blob))as archive:raw=archive.extractfile('confirmation/confirmation.json').read()
 for member,content in [('confirmation/confirmation.json',raw),('whole-archive',blob)]:groups.append(dict(paths=[prefix+'/'+('observations.tgz'if member=='whole-archive'else member)],bytes=len(content),links=1,sha256=hashlib.sha256(content).hexdigest(),canonical=canonical,canonicalSHA256=hashlib.sha256(blob).hexdigest(),member=member,committedBlobVerified=True))
q=r/'quiet';q.mkdir(exist_ok=False);remote='/home/lokad/lython-bench-checks/json-cpython-b908-20261117'
identity=dict(sourceRevision='Committed runtime557381fe/frozend739132f; main qualification pending44116196658 at preparation',purpose='Representative JSON checkpoint versus stockCPython3.13.16: helper JSON-lines and floating numeric report, separately compile/warm/compile-run. Existing trusted scripts and protocol; no causal source gain across collections, no startup/tail claim.',coreSHA256={'candidate':current['Lokad.Lython.dll'],'candidate-control':current['Lokad.Lython.dll']},imageFiles={'candidate':current},auxiliaryFiles={n:h for n,h in current.items()if n!='Lokad.Lython.dll'},catalogSHA256=f['catalogSHA256'],normalAdapterPin='0.4.0',publicationHeld=True)
(q/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8',newline='\n')
s=(old/'quiet/collect.py').read_text(encoding='utf-8');a=s.index('jobs=');b=s.index('\nenv =',a)
jobs=[[name,lane]for name in ['scripts.json-summary-helpers.large','scripts.numeric-squared-error.floating.large']for lane in ['compile','warm','compile-run']]
s=s[:a]+'jobs='+repr(jobs)+'\nassert len(jobs)==6 and all(case in cases for case,lane in jobs)\n'+s[b:];(q/'collect.py').write_text(s,encoding='utf-8',newline='\n')
s=(old/'quiet/archive-owned.py').read_text(encoding='utf-8').replace("len(raw['jobs'])==3","len(raw['jobs'])==6").replace('jobs=3','jobs=6');(q/'archive-owned.py').write_text(s,encoding='utf-8',newline='\n')
prior=json.loads((retained/'confirm/quiet/config.json').read_text(encoding='utf-8'))
(q/'run.sh').write_text((old/'quiet/run.sh').read_text(encoding='utf-8').replace(json.loads((old/'quiet/config.json').read_text(encoding='utf-8'))['root'],remote),encoding='utf-8',newline='\n')
(q/'candidate').mkdir();shutil.copyfile(retained/'main-frozen/Lokad.Lython.dll',q/'candidate/Lokad.Lython.dll');shutil.copyfile(catalog,q/'representative.json')
names=['collect.py','archive-owned.py','run.sh','identity.json','representative.json','candidate/Lokad.Lython.dll']
with tarfile.open(q/'payload.tgz','w:gz')as archive:
 for name in names:archive.add(q/name,arcname=name)
reference=json.loads((retained/'frozen/identity.json').read_text(encoding='utf-8'))['imageFiles']['reference']
c=dict(root=remote,unit='lython-b908-json-cpython-20261117',source=prior['root'],sourceRole='reference',sourceFiles=reference,sourceCatalogSHA256=prior['catalogSHA256'],catalogSHA256=f['catalogSHA256'],identity=identity,retireGroups=groups,payloadBytes=(q/'payload.tgz').stat().st_size,payloadSHA256=hashlib.sha256((q/'payload.tgz').read_bytes()).hexdigest(),unpackedBytes=sum((q/name).stat().st_size for name in names))
(q/'config.json').write_text(json.dumps(c,indent=2)+'\n',encoding='utf-8',newline='\n')
s=(old/'quiet/remote-launch.py').read_text(encoding='utf-8');a=s.index('c=');b=s.index('\nb=Path(',a);s=s[:a]+'c='+repr(c)+s[b:]
s=s.replace("source/'candidate'/n","source/c['sourceRole']/n").replace('source/role/n',"source/c['sourceRole']/n")
s=s.replace(" os.link(source/'representative.json',root/'representative.json')"," # New five-case catalog passed actual committed-image golden verification.")
s=s.replace('lython-b900-fixtures','lython-b908-fixtures').replace('RuntimeMaxSec=240','RuntimeMaxSec=300');(q/'remote-launch.py').write_text(s,encoding='utf-8',newline='\n')
s=(retained/'launch.py').read_text(encoding='utf-8').replace('seconds=230','seconds=250').replace('before230seconds','before250seconds').replace('Five-job typed-lock comparison','Six-job JSON CPython checkpoint');(r/'launch.py').write_text(s,encoding='utf-8',newline='\n')
s=(old/'quiet/retrieve.py').read_text(encoding='utf-8').replace("['jobs']==3","['jobs']==6").replace('B900','B908');(q/'retrieve.py').write_text(s,encoding='utf-8',newline='\n')
s=(old/'summarize.py').read_text(encoding='utf-8').replace("len(raw['jobs'])==3","len(raw['jobs'])==6");(r/'summarize.py').write_text(s,encoding='utf-8',newline='\n')
for p in list(q.glob('*.py'))+[r/'launch.py',r/'summarize.py']:ast.parse(p.read_text(encoding='utf-8'))
print('Two existing JSON workloads/three separated phases prepared with actual d739 image; only archived3866/raw replicas eligible for fresh revalidation.')
