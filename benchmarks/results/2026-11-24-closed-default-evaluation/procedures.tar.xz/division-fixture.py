import time
def make(seed):
    def choose(value: int = 7 // seed, *, step: int = seed % 7 + 1) -> int:
        return value + step
    return choose
time.time()
return make(0)