from pathlib import Path
import gzip
import hashlib
import json
import shutil
import subprocess
import tarfile

lab=Path(__file__).resolve().parent
root=lab.parents[3]
out=root/'benchmarks/results/2026-11-24-closed-default-evaluation'
out.mkdir(exist_ok=True)
c=lab/'comparison'
q=c/'quiet'
read=lambda p:json.loads(p.read_text(encoding='utf-8'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
meta=read(c/'identity.json')
status=read(q/'terminal-status.json')
receipt=status['receipt']
summary=read(q/'summary.json')
assert all(receipt[k] for k in ('complete','allWorkersJoined','guestFixturesRemoved','quietBeforeAndAfter','archivedAndVerifiedUnderLease'))
assert not status['live'] and sha(q/'observations.tar.xz')==receipt['archiveSHA256'] and summary['timedBatches']==168
for role in ('reference','candidate'):
    checked=read(c/(role+'-verify.json'))
    assert checked['state']=='Completed' and checked['caseCount']==6
    assert all(sha(lab/role/name)==expected for name,expected in meta['imageFiles'][role].items())
    shape=json.loads((lab/(role+'-shapes.json')).read_text(encoding='utf-8-sig'))
    assert shape['coreSHA256']==meta['imageFiles'][role]['Lokad.Lython.dll']
binary=(lab/'candidate/Lokad.Lython.dll').read_bytes()
(out/'candidate-core.dll.gz').write_bytes(gzip.compress(binary,mtime=0))
assert hashlib.sha256(gzip.decompress((out/'candidate-core.dll.gz').read_bytes())).hexdigest()==meta['imageFiles']['candidate']['Lokad.Lython.dll']
for p,key in {c/'identity.json':'identity.json',q/'terminal-status.json':'terminal-status.json',q/'observations.tar.xz':'observations.tar.xz',
              q/'summary.json':'summary.json',lab/'allocation-summary-six.json':'allocation-summary.json',lab/'definition-proof.json':'definition-proof.json'}.items():
    shutil.copyfile(p,out/key)
source=subprocess.check_output(['git','diff','--binary','3ef18ef8d',meta['candidate'],'--','src','tests'],cwd=root)
(lab/'measured.patch').write_bytes(source)
files=['prepare.py','stage.py','archive.py','quiet.py','summarize.py','allocations.py','verified-replicas.json',
    'reference-allocation-six.json','candidate-allocation-six.json','comparison/reference-verify.json',
    'comparison/candidate-verify.json','comparison/quiet/launch.log','reference-shapes.json','candidate-shapes.json',
    'division-fixture.py','before-division-probe.json','after-division-probe.json','validation.txt','measured.patch',
    'oracle.py','computed-default-oracle-input.json','reference-computed-default-oracle.jsonl','candidate-computed-default-oracle.jsonl']
with tarfile.open(out/'procedures.tar.xz','w:xz') as tar:
    for name in files:tar.add(lab/name,arcname=name)
with tarfile.open(out/'procedures.tar.xz') as tar:
    assert all(tar.extractfile(item).read()==(lab/item).read_bytes() for item in files)
print('Archived B1590, 168 verified batches and full image identity')
