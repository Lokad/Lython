from pathlib import Path
import ast
import gzip
import hashlib
import json
import shutil
import subprocess
import tarfile

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
donor = lab.with_name('eager-json-owner-20261124')
comparison = lab/'comparison'
quiet = comparison/'quiet'
quiet.mkdir(exist_ok=True)
sha = lambda b: hashlib.sha256(b).hexdigest()
read = lambda p: json.loads(p.read_text(encoding='utf-8'))

def write(path, source):
    path.write_text(source, encoding='utf-8', newline='\n')

def canonical(path):
    return subprocess.check_output(['git','show', 'origin/master:'+path],cwd=repo)

old = 'benchmarks/results/2026-11-24-captured-local-reads/'
core = gzip.decompress(canonical(old+'candidate-core.dll.gz'))
receipt = json.loads(canonical(old+'terminal-status.json'))['receipt']
assert receipt['complete'] and receipt['allWorkersJoined'] and receipt['archivedAndVerifiedUnderLease']
assert sha(canonical(old+'observations.tar.xz')) == receipt['archiveSHA256']
assert sha(core) == json.loads(canonical(old+'identity.json'))['imageFiles']['candidate']['Lokad.Lython.dll']
retired = dict(sha256=sha(core),coreArchive=old+'candidate-core.dll.gz',aliases=[dict(
    path='captured-local-reads-b1589-20261124/candidate/Lokad.Lython.dll',observationSHA256=receipt['archiveSHA256'],source=old)])
write(lab/'verified-replicas.json',json.dumps([retired],indent=2)+'\n')

identity = read(comparison/'identity.json')
assert identity['imageFiles']['reference'] == read(donor/'comparison/identity.json')['imageFiles']['candidate']
for role, files in identity['imageFiles'].items():
    assert len(files) == 32 and all(sha((lab/role/name).read_bytes())==digest for name,digest in files.items())
    assert read(comparison/f'{role}-verify.json')['state']=='Completed'
for name, meta in identity['catalogs'].items():
    assert sha((comparison/name).read_bytes()) == meta['sha256']

collector=(donor/'comparison/quiet/collect.py').read_text(encoding='utf-8').replace('b1588-', 'b1590-').replace('len(jobs) == 5','len(jobs) == 6')
compile(collector,'collect.py','exec')
write(quiet/'collect.py',collector)
shutil.copyfile(donor/'comparison/quiet/run.sh',quiet/'run.sh')
assert b'\r' not in (quiet/'run.sh').read_bytes()
payload=quiet/'payload.tar.gz'
with tarfile.open(payload,'w:gz') as out:
    for item in (comparison/'identity.json',comparison/'representative.json',comparison/'jobs.json',quiet/'run.sh',quiet/'collect.py'):
        out.add(item,arcname=item.name)
    out.add(lab/'candidate/Lokad.Lython.dll',arcname='candidate-core.dll')
write(quiet/'upload.json',json.dumps(dict(root='closed-default-evaluation-b1590-20261124',reference='eager-json-owner-b1588-20261124',
    payloadSHA256=sha(payload.read_bytes()),payloadBytes=payload.stat().st_size),indent=2)+'\n')

launch=(donor/'quiet.py').read_text(encoding='utf-8').replace('b1588-eager-json-owner','b1590-closed-default-evaluation').replace('b1588-','b1590-')
launch=launch.replace("assert archive==base/'regex-flag-continuations-b1576-20261124' and replica==archive/'candidate/Lokad.Lython.dll'",
    "assert archive==base/'captured-local-reads-b1589-20261124' and replica==archive/'candidate/Lokad.Lython.dll'")
launch=launch.replace("{'identity.json','run.sh','collect.py','candidate-core.dll'}", "{'identity.json','representative.json','jobs.json','run.sh','collect.py','candidate-core.dll'}")
launch=launch.replace("  os.link(reference/name,root/name)\n", "")
launch=launch.replace("seconds=280", "seconds=336").replace("RuntimeMaxSec=345", "RuntimeMaxSec=411")
remote,=(node.value for node in ast.walk(ast.parse(launch)) if isinstance(node,ast.Constant) and isinstance(node.value,str) and node.value.startswith('digest=lambda path:'))
compile(remote,'remote-stage','exec')
assert 'captured-local-reads-b1589-20261124' in remote and 'os.link(reference/name,root/name)' not in remote
write(lab/'quiet.py',launch)
summary=(donor/'summarize.py').read_text(encoding='utf-8').replace('receipt["warmJobs"] == 5','receipt["warmJobs"] == 6').replace('len(warm["jobs"])==5','len(warm["jobs"])==6').replace('timedBatches=140','timedBatches=168')
compile(summary,'summarize.py','exec')
write(lab/'summarize.py',summary)
