from pathlib import Path
import hashlib
import json
import shutil
import subprocess

lab = Path(__file__).resolve().parent
root = lab.parents[3]
probe = lab/'frozen-probe'
shutil.copytree(root/'tools/LythonProbe/bin/Release/net11.0',probe,dirs_exist_ok=True,copy_function=shutil.copyfile)
identity = json.loads((lab/'comparison/identity.json').read_text(encoding='utf-8'))
rules = (
    ('seed + 1','seed % 11 + 2'),
    ('seed % 11 + 2','seed + 1'),
    ('(seed % 11 + 2) * 3','seed * 4'),
    ('7 // seed','-3 % seed + 5'),
    ('seed // -3','9 % seed'),
    ('seed - 5 * seed','(seed + seed) // 7'),
    ('seed + 9223372036854775807','seed % -3 + 1'),
    ('seed + 1','seed * seed - 3'),
)
cases = [f'''Kind = int
def make(seed):
    def pick(value: Kind = {left}, *, width: Kind = {right}) -> Kind:
        return value, width
    return pick
for seed in (0, 1, -11, 9223372036854775807, -9223372036854775808, 1 << 80):
    try:
        f = make(seed)
        value, width = f()
        print(value, width, value is f.__defaults__[0], f.__annotations__['width'] is Kind)
    except ZeroDivisionError:
        print('division by zero')
''' for left,right in rules]
request = json.dumps(cases,ensure_ascii=False)
(lab/'computed-default-oracle-input.json').write_text(request+'\n',encoding='utf-8',newline='\n')
for role,files in identity['imageFiles'].items():
    core = probe/'Lokad.Lython.dll'
    shutil.copyfile(lab/role/core.name,core)
    assert hashlib.sha256(core.read_bytes()).hexdigest()==files[core.name]
    run = subprocess.run([Path.home()/'.dotnet11/dotnet.exe',probe/'LythonProbe.dll','--batch-json','--compare-python','--python','C:/Python313/python.exe'],
        input=request,capture_output=True,text=True,encoding='utf-8',timeout=100)
    (lab/(role+'-computed-default-oracle.jsonl')).write_text(run.stdout,encoding='utf-8',newline='\n')
    assert run.returncode==0, (run.stdout, run.stderr)
    results = [json.loads(line) for line in run.stdout.splitlines()]
    assert len(results)==len(cases) and all(r['Lython']['Success'] and r['Matches'] and r['Compared'] for r in results)
    print(role,len(results),'programs matched the isolated Python oracle')
