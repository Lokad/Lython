from hashlib import sha256
from pathlib import Path
from shutil import copy2, copytree
from subprocess import check_output
import json

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
base = lab.parent / 'generator-expression-preflight-b1952-20261128'
prior = base / 'comparison'
pair = lab / 'comparison'
build = lab / 'ubuntu-artifacts/bin/Lokad.Lython/release_net11.0/Lokad.Lython.dll'
read = lambda path: json.loads(path.read_bytes())
digest = lambda path: sha256(path.read_bytes()).hexdigest()
files = lambda folder: {path.name: digest(path) for path in folder.iterdir()}

def git(*args):
    return check_output(['git', *args], cwd=repo)

def write(path, data):
    path.write_text(json.dumps(data, indent=2) + '\n', encoding='utf-8', newline='\n')

old = read(prior / 'identity.json')
head = git('rev-parse', 'HEAD').decode().strip()
assert head.startswith('60ebd6274')
assert sha256(git('diff', '--binary', old['sourceRevision'], head, '--', 'src/Lokad.Lython', 'tests')).hexdigest() == old['sourcePatchSHA256']
assert not git('diff', '--binary', head, '--', 'Directory.Packages.props', 'src/Lokad.Lython.Utf8Regex', 'benchmarks/scripts')
frozen = old['imageFiles']['candidate']
assert len(frozen) == 32 and files(prior / 'candidate') == frozen
assert {name:digest(lab/'catalog-worker'/name) for name in frozen} == frozen
pair.mkdir()
for role in ('reference', 'candidate'):
    copytree(prior / 'candidate', pair / role)
copy2(build, pair / 'candidate/Lokad.Lython.dll')
assert not (pair / 'candidate/Lokad.Lython.dll').samefile(build)
images = {role: files(pair / role) for role in ('reference', 'candidate')}
assert {name for name, checksum in frozen.items() if images['candidate'][name] != checksum} == {'Lokad.Lython.dll'}
assert images['reference'] == frozen
patch = git('diff', '--binary', head, '--', 'src/Lokad.Lython', 'tests')
(lab / 'candidate.patch').write_bytes(patch)
for name in ('cpython-worker.py', 'run.sh'):
    copy2(prior / name, pair / name)
assert digest(prior / 'representative.json') == old['catalogs']['representative.json']['sha256']
assert digest(pair / 'cpython-worker.py') == old['cpythonWorkerSHA256']
previous = {row['id']: row for row in read(prior / 'representative.json')['cases']}
catalog = read(lab / 'full-representative.json')
report = next(row for row in catalog['cases'] if row['id'] == 'scripts.report-render.large')
assert report['size'] == 1024 and report['source'].replace('\r\n','\n').strip() == (repo / 'benchmarks/scripts/report-render.py').read_text(encoding='utf-8').strip()
control = previous['diagnostic.shipment-file-fed-map']
repeated = dict(previous['diagnostic.shipment-row-generator-reduction'], id='diagnostic.shipment-row-explicit-reduction')
generator = "    handling = sum(row[key] == 'yes' for key in ('late', 'hold'))"
loop = "    handling = 0\n    for key in ('late', 'hold'):\n        handling += row[key] == 'yes'"
assert repeated['source'].count(generator) == 1
repeated['source'] = repeated['source'].replace(generator, loop)
raw = repeated['source'].encode('utf-8')
repeated.update(sourceUtf8Bytes=len(raw), sourceSha256=sha256(raw).hexdigest())
catalog['cases'] = [repeated, report, control]
write(pair / 'representative.json', catalog)
jobs = [(row['id'], lane) for row, lanes in ((repeated, ('warm','warm-async')),
    (report, ('warm','warm-async')), (control, ('warm-async',))) for lane in lanes]
write(pair / 'jobs.json', dict(warm=jobs))
write(pair / 'identity.json', dict(sourceRevision=head, sourcePatchSHA256=sha256(patch).hexdigest(),
    imageFiles=images, coreSHA256={r+s: v['Lokad.Lython.dll'] for r, v in images.items() for s in ('', '-control')},
    expectedCPythonSHA256=old['expectedCPythonSHA256'], cpythonWorkerSHA256=old['cpythonWorkerSHA256'],
    catalogs={name: {'sha256': digest(pair / name)} for name in ('representative.json', 'jobs.json')},
    purpose='Store list and tuple loop positions in the admitted operand and remove the side array.'))
copy2(prior / 'collect.py', pair / 'collect.py')
summary = (base / 'summarize.py').read_text(encoding='utf-8')
assert summary.count('== 4') == 1
(lab / 'summarize.py').write_text(summary.replace('== 4', '== 3'), encoding='utf-8', newline='\n')
allocation = (base / 'measure-allocation.py').read_text(encoding='utf-8')
assert allocation.count("len(catalog['cases'])==4") == 1
(lab / 'measure-allocation.py').write_text(allocation.replace("len(catalog['cases'])==4", "len(catalog['cases'])==3"), encoding='utf-8', newline='\n')
copy2(base / 'check-admission.py', lab / 'check-admission.py')
assert b'\r' not in (pair / 'run.sh').read_bytes()
print('Frozen 32 files per image. Five scoped lanes with three exact goldens.')
