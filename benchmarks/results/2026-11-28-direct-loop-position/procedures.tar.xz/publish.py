from hashlib import sha256
from pathlib import Path
from shutil import copy2
from subprocess import check_output
import json
import re
import tarfile

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
bench = lab / 'comparison'
out = repo / 'benchmarks/results/2026-11-28-direct-loop-position'
read = lambda path: json.loads(path.read_bytes())
digest = lambda path: sha256(path.read_bytes()).hexdigest()
identity = read(bench / 'identity.json')
assert identity['sourceRevision'].startswith('60ebd6274')
patch = lab / 'candidate.patch'
assert check_output(['git', 'diff', '--binary', identity['sourceRevision'], '--', 'src/Lokad.Lython', 'tests'], cwd=repo) == patch.read_bytes()
assert digest(patch) == identity['sourcePatchSHA256']
for role, expected in identity['imageFiles'].items():
    assert len(expected) == 32 and {p.name:digest(p) for p in (bench/role).iterdir()} == expected
assert {n for n, checksum in identity['imageFiles']['reference'].items() if identity['imageFiles']['candidate'][n] != checksum} == {'Lokad.Lython.dll'}
summary = read(bench / 'summary.json')
assert summary['verifiedTimedBatches'] == 140 and len(summary['rows']) == 5
receipt = read(bench/'archive-receipt.json')
assert receipt['archiveSHA256'] == digest(bench/'observations.tar.xz')
assert all(receipt[k] for k in ('complete','allWorkersJoined','guestFixturesRemoved','archivedAndVerifiedUnderLease'))
alloc = read(lab/'allocation/summary.json')
assert len(alloc) == 6 and all(row['compiled'][0] == row['compiled'][1] for row in alloc)
for row in alloc:
    delta = row['clr'][0] - row['clr'][1]
    if row['case'].endswith('explicit-reduction'):
        assert 180000 <= delta <= 180300
    elif row['case'].startswith('scripts.report-render'):
        assert abs(delta) <= 2200
    else:
        assert abs(delta) <= 8
admissions = read(lab/'admission/summary.json')
assert len(admissions) == 6
for row in admissions:
    report = row['case'].startswith('scripts.report-render')
    assert row['peak'][0] - row['peak'][1] == (52 if report else 0)
    assert row['requests'][0] - row['requests'][1] == int(report)
for role in identity['imageFiles']:
    assert read(lab/f'admission/{role}.json')['coreSHA256'] == identity['imageFiles'][role]['Lokad.Lython.dll']
logs = sorted(lab.glob('*-Lokad.Lython.*Tests-net*.log'))
assert len(logs) == 6
for log in logs:
    count = 1057 if 'PublicApi' in log.name else 278
    assert re.search(rf'Failed: +0, Passed: +{count}, Skipped: +0', log.read_text(encoding='utf-8-sig')), log
out.mkdir(exist_ok=True)
artifacts = {name:bench/name for name in ('identity.json','summary.json','observations.tar.xz','archive-receipt.json')}
artifacts['allocation.json'] = lab/'allocation/summary.json'
artifacts['admission.json'] = lab/'admission/summary.json'
artifacts['array-only-allocation.json'] = lab/'array-only/allocation/summary.json'
for name, source in artifacts.items():
    copy2(source,out/name)
    assert digest(out/name) == digest(source)
procedures = {p.name:p for p in logs}
for name in ('candidate.patch','freeze.py','test-ubuntu.sh','test-windows.ps1','ubuntu-core-build.log','summarize.py','measure-allocation.py','check-admission.py','publish.py'):
    procedures[name] = lab/name
for name in ('collection.log','reference-verify.json','candidate-verify.json','exit-code.txt'):
    procedures[name] = bench/name
for directory in ('allocation','admission','array-only/allocation','array-only/admission'):
    for p in (lab/directory).glob('*.json'):
        procedures[f'{directory}/{p.name}'] = p
for directory in ('initial','array-only','prefix-build'):
    for filename in ('candidate.patch','ubuntu-core-build.log','windows-Lokad.Lython.Tests-net11.0.log','ubuntu-Lokad.Lython.Tests-net11.0.log','comparison/identity.json'):
        if (p:=lab/directory/filename).is_file(): procedures[f'{directory}/{filename}'] = p
witness=lab.parent/'private-definition-admission-20261125/admission-probe'
procedures['admission-witness/Program.cs'] = witness/'Program.cs'
with tarfile.open(out/'procedures.tar.xz','w:xz') as archive:
    for name, path in procedures.items(): archive.add(path, arcname=name)
with tarfile.open(out/'procedures.tar.xz') as archive:
    assert all(digest(path) == sha256(archive.extractfile(name).read()).hexdigest() for name,path in procedures.items())
print('Direct loop position source, measures and custody verified.')
