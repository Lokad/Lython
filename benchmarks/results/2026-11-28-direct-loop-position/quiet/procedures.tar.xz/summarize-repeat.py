from hashlib import sha256
from pathlib import Path
from shutil import copy2
from statistics import median, quantiles
from subprocess import check_output
import re
import json
import tarfile

lab = Path(__file__).resolve().parent
quiet = lab / 'comparison/quiet'
read=lambda p:json.loads(p.read_bytes())
digest=lambda p:sha256(p.read_bytes()).hexdigest()
identity=read(quiet/'identity.json')
terminal = read(quiet / 'terminal-status.json')
receipt = terminal['receipt']
archive = quiet / 'observations.tar.xz'
assert not terminal['live'] and not terminal['fixtures'] and terminal['exitCode'] == '0'
assert all(receipt[k] for k in ('complete','allWorkersJoined','guestFixturesRemoved','quietBeforeAndAfter','archivedAndVerifiedUnderLease'))
assert receipt['warmJobs'] == 3 and digest(archive) == receipt['archiveSHA256']
assert read(quiet/'stage-custody.json')['reused'] == {'donor':62,'paired':0}
for role,image in identity['imageFiles'].items():
    verified = read(quiet / f'{role}-remote-verify.json')
    assert verified['state'] == 'Completed' and verified['caseCount'] == 3
    assert verified['catalogSha256'] == identity['catalogs']['representative.json']['sha256']
    assert verified['launched']['library']['sha256'] == image['Lokad.Lython.dll']
    assert verified['launched']['adapter']['sha256'] == image['Lokad.Lython.Benchmarks.dll']
    assert verified['launched']['python']['sha256'] == identity['expectedCPythonSHA256']
with tarfile.open(archive) as a:
    assert json.load(a.extractfile('identity.json')) == identity
    for name,row in identity['catalogs'].items():
        assert sha256(a.extractfile(name).read()).hexdigest() == row['sha256']
    assert all(json.load(a.extractfile('confirmation/machine-'+phase+'.json'))['gate']['quiet'] for phase in ('before','after'))
    raw = json.load(a.extractfile('confirmation/confirmation.json'))
    jobs = json.load(a.extractfile('jobs.json'))
    assert raw['complete'] and jobs == read(quiet/'jobs.json')
cases = {case['id']:case for case in read(quiet/'representative.json')['cases']}
rows = []
for job,(case_id,lane) in zip(raw['jobs'],jobs,strict=True):
    assert job['case'] == case_id and job['lanes'] == [lane] and job['workersJoinedAndFixturesRemoved']
    case=cases[case_id]; elapsed={}; cpu={}; iqrs={}
    for label,worker in job['identities'].items():
        role=label.removesuffix('-control')
        libraries={Path(v['path']).name:v['sha256'] for v in worker['libraries']}
        assert libraries['Lokad.Lython.dll'] == identity['coreSHA256'][label]
        assert libraries['Lokad.Lython.Benchmarks.dll'] == identity['imageFiles'][role]['Lokad.Lython.Benchmarks.dll']
        assert worker['catalogSha256'] == identity['catalogs']['representative.json']['sha256']
        times=[]; active=[]
        samples = [s for s in job['samples'] if s['engine'] == label]
        assert len(samples) == 7 and {s['round'] for s in samples} == set(range(7))
        for sample in samples:
            r=sample['response']; count=r['completedInvocations']
            assert r['status'] == 'Completed' and count > 0 and sample['lane'] == lane
            assert all(r[k] == case[k] for k in ('sourceSha256','fixtureSha256','expectedOutputSha256'))
            assert r.get('actualOutputSha256') == (None if lane == 'compile' else case['expectedOutputSha256'])
            assert r.get('actualFilesSha256') == (None if lane == 'compile' else case.get('expectedFilesSha256'))
            times.append(1000*r['elapsedTicks']/r['clockFrequency']/count)
            active.append(1000*sample['externalProcessCpuTicks']/sample['externalCpuFrequency']/count)
        elapsed[label]=median(times); cpu[label]=median(active)
        quartiles=quantiles(times,n=4,method='inclusive')
        iqrs[label]=100*(quartiles[2]-quartiles[0])/elapsed[label]
    def span(values,role): return sorted([values[role],values[role+'-control']])
    def change(values): return [100*(a/b-1) for a,b in [(span(values,'candidate')[0],span(values,'reference')[1]),(span(values,'candidate')[1],span(values,'reference')[0])]]
    def spread(values,role):
        low,high=span(values,role)
        return 100*(high/low-1)
    row=dict(case=case_id,lane=lane,elapsedMilliseconds=elapsed,cpuMilliseconds=cpu,elapsedChangePercent=change(elapsed),
        cpuChangePercent=change(cpu),referenceElapsedSpreadPercent=spread(elapsed,'reference'),candidateElapsedSpreadPercent=spread(elapsed,'candidate'),
        referenceCpuSpreadPercent=spread(cpu,'reference'),candidateCpuSpreadPercent=spread(cpu,'candidate'),maxElapsedIqrPercent=max(iqrs.values()))
    rows.append(row)
    print(case_id,'elapsed',[round(n,2) for n in row['elapsedChangePercent']], 'CPU',[round(n,2) for n in row['cpuChangePercent']],
          'CPU spreads',round(row['referenceCpuSpreadPercent'],2),round(row['candidateCpuSpreadPercent'],2))
assert sum(len(job['samples']) for job in raw['jobs']) == 84
summary=dict(reference=identity['sourceRevision'],candidatePatchSHA256=identity['sourcePatchSHA256'],collectionSeconds=raw['elapsedSeconds'],
    verifiedTimedBatches=84,quietGates=True,rows=rows)
(quiet/'summary.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8',newline='\n')
