from hashlib import sha256
from pathlib import Path
from shutil import copy2
import json
import tarfile

lab = Path(__file__).resolve().parent
pair = lab/'comparison'
quiet = pair/'quiet'
template = lab.parent/'sum-source-b1949-20261128'
donor = lab.parent/'current-shipment-checkpoint-b1943-20261128/comparison/quiet'
stage = 'script-loop-position-repeat-b1953-20261128'
core = 'Lokad.Lython.dll'
read = lambda path: json.loads(path.read_bytes())
digest = lambda path: sha256(path.read_bytes()).hexdigest()
files = lambda path: {p.name:digest(p) for p in path.iterdir()}

def save(path, data):
    path.write_text(data, encoding='utf-8', newline='\n')
    assert b'\r' not in path.read_bytes()

def write(path, data):
    save(path, json.dumps(data, indent=2) + '\n')

identity = read(pair/'identity.json')
assert identity['sourceRevision'].startswith('60ebd6274')
assert digest(lab/'candidate.patch')==identity['sourcePatchSHA256']
assert digest(pair/'representative.json')==identity['catalogs']['representative.json']['sha256']
assert digest(pair/'cpython-worker.py')==identity['cpythonWorkerSHA256']
old = read(donor/'identity.json')
donor_files = old['imageFiles']['candidate']
assert len(donor_files)==32 and files(donor/'local-image')==donor_files
terminal=read(donor/'terminal-status.json')
receipt=terminal['receipt']
assert not terminal['live'] and not terminal['fixtures'] and terminal['exitCode']=='0'
assert receipt['complete'] and receipt['allWorkersJoined'] and receipt['quietBeforeAndAfter']
assert digest(donor/'observations.tar.xz')==receipt['archiveSHA256']
assert identity['expectedCPythonSHA256']==old['expectedCPythonSHA256']
for role, image in identity['imageFiles'].items():
    assert len(image)==32 and files(pair/role)==image
    assert {name for name, checksum in donor_files.items() if image[name]!=checksum}=={core}
    proof=read(pair/f'{role}-verify.json')
    assert proof['state']=='Completed' and proof['caseCount']==3
    assert proof['catalogSha256']==identity['catalogs']['representative.json']['sha256']
    assert proof['launched']['library']['sha256']==image[core]
    assert proof['launched']['adapter']['sha256']==image['Lokad.Lython.Benchmarks.dll']
    assert proof['launched']['python']['sha256']==identity['expectedCPythonSHA256']
quiet.mkdir()
for name in ('representative.json','cpython-worker.py'):
    copy2(pair/name,quiet/name)
copy2(template/'comparison/quiet/run.sh',quiet/'run.sh')
explicit='diagnostic.shipment-row-explicit-reduction'
file_map='diagnostic.shipment-file-fed-map'
jobs=[(file_map,'warm'),(explicit,'warm-async'),(explicit,'warm')]
write(quiet/'jobs.json',jobs)
identity['catalogs']['jobs.json']={'sha256':digest(quiet/'jobs.json')}
identity.update(frozenImage=f'/home/lokad/lython-bench-checks/{stage}/candidate',
                donorArchiveSHA256=receipt['archiveSHA256'],
                purpose='Repeat the exact local loop candidate, check adverse sync timing and retain a same-mode file-fed control.')
write(quiet/'identity.json',identity)
collector=(template/'comparison/quiet/collect.py').read_text(encoding='utf-8')
assert collector.count('len(jobs) == 5')==1 and collector.count('lython-b1949-sum-source-fixtures')==1
save(quiet/'collect.py',collector.replace('len(jobs) == 5','len(jobs) == 3')
     .replace('lython-b1949-sum-source-fixtures','lython-b1953-loop-position-fixtures'))
paths={name:quiet/name for name in ('identity.json','jobs.json','representative.json','collect.py','run.sh','cpython-worker.py')}
paths.update({f'{role}/{core}':pair/role/core for role in identity['imageFiles']})
payload=quiet/'stage.tar.gz'
with tarfile.open(payload,'w:gz') as archive:
    for name,path in paths.items(): archive.add(path,arcname=name)
with tarfile.open(payload) as archive:
    assert all(sha256(archive.extractfile(name).read()).hexdigest()==digest(path) for name,path in paths.items())
manifest={name:dict(length=path.stat().st_size,sha256=digest(path)) for name,path in paths.items()}
write(quiet/'upload.json',dict(root=stage,donor=read(donor/'upload.json')['root'],donorFiles=donor_files,
    donorArchive=receipt['archiveSHA256'],payloadSHA256=digest(payload),files=manifest,
    expandedBytes=sum(row['length'] for row in manifest.values()),minimumAfterStageBytes=16*1024*1024))
launch=(template/'quiet-vm.py').read_text(encoding='utf-8')
assert launch.count('lython-b1949-sum-source')==1 and launch.count("proof['caseCount']==4")==1
save(lab/'quiet-vm.py',launch.replace('lython-b1949-sum-source','lython-b1953-loop-position')
     .replace("proof['caseCount']==4","proof['caseCount']==3"))
template_summary=(template/'summarize.py').read_text(encoding='utf-8')
body=template_summary[template_summary.index('terminal = read('):template_summary.index('out.mkdir(')]
body=body.replace("receipt['warmJobs'] == 5","receipt['warmJobs'] == 3").replace("{'donor':63,'paired':0}","{'donor':62,'paired':0}")
body=body.replace("verified['caseCount'] == 4","verified['caseCount'] == 3").replace('== 140','== 84')
body=body.replace("reference=identity['referenceRevision'],candidate=identity['sourceRevision']",
    "reference=identity['sourceRevision'],candidatePatchSHA256=identity['sourcePatchSHA256']").replace('verifiedTimedBatches=140','verifiedTimedBatches=84')
save(lab/'summarize-repeat.py',template_summary[:template_summary.index('repo = ')] +
    "read=lambda p:json.loads(p.read_bytes())\n" +
    "digest=lambda p:sha256(p.read_bytes()).hexdigest()\nidentity=read(quiet/'identity.json')\n" + body +
    "(quiet/'summary.json').write_text(json.dumps(summary,indent=2)+'\\n',encoding='utf-8',newline='\\n')\n")
print('Staged three quiet repeat lanes with the exact reference and candidate.')
