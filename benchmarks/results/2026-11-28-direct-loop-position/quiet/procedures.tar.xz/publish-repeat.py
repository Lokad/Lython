from hashlib import sha256
from pathlib import Path
from shutil import copy2
import json
import tarfile

lab=Path(__file__).resolve().parent
pair=lab/'comparison'
quiet=pair/'quiet'
out=lab.parents[3]/'benchmarks/results/2026-11-28-direct-loop-position/quiet'
read=lambda path:json.loads(path.read_bytes())
digest=lambda path:sha256(path.read_bytes()).hexdigest()
identity=read(quiet/'identity.json')
local=read(pair/'identity.json')
assert identity['imageFiles']==local['imageFiles']
assert identity['sourcePatchSHA256']==local['sourcePatchSHA256']==digest(lab/'candidate.patch')
assert digest(quiet/'representative.json')==digest(pair/'representative.json')
summary=read(quiet/'summary.json')
assert summary['quietGates'] and summary['verifiedTimedBatches']==84 and len(summary['rows'])==3
receipt=read(quiet/'archive-receipt.json')
assert digest(quiet/'observations.tar.xz')==receipt['archiveSHA256']
out.mkdir()
for name in ('summary.json','identity.json','stage-custody.json','terminal-status.json','observations.tar.xz'):
    copy2(quiet/name,out/name)
    assert digest(quiet/name)==digest(out/name)
procedures={name:lab/name for name in ('prepare-repeat.py','quiet-vm.py','summarize-repeat.py','publish-repeat.py')}
procedures.update({name:quiet/name for name in ('archive-receipt.json','candidate-remote-verify.json','reference-remote-verify.json','launch.log','upload.json')})
with tarfile.open(out/'procedures.tar.xz','w:xz') as bundle:
    for name,path in procedures.items(): bundle.add(path,arcname=name)
with tarfile.open(out/'procedures.tar.xz') as bundle:
    assert all(sha256(bundle.extractfile(name).read()).hexdigest()==digest(path) for name,path in procedures.items())
print('Quiet repeat identities, evidence and archive verified.')
