from pathlib import Path
import hashlib,json,os,statistics,subprocess,time

r=Path(__file__).parent
frozen=(r.parent/'native-call-transport-r365/candidate').resolve()
image=hashlib.sha256((frozen/'Lokad.Lython.dll').read_bytes()).hexdigest()
assert image==json.loads((r/'identity.json').read_text(encoding='utf-8'))['coreSHA256']['candidate']
env={k:v for k,v in os.environ.items() if k.upper()!='PATH'}
sdk='C:/Users/JoannesVermorel/.dotnet11';env['DOTNET_ROOT']=sdk
env['PATH']=sdk+';'+next(v for k,v in os.environ.items() if k.upper()=='PATH')
fixture=r/'allocation-fixtures';fixture.mkdir();env['TEMP']=str(fixture.resolve());env['TMP']=str(fixture.resolve())
output=r/'allocation.json';assert not output.exists()
start=time.monotonic()
with (r/'allocation.log').open('w',encoding='utf-8',newline='\n') as log:
    done=subprocess.run([sdk+'/dotnet.exe',str(frozen/'Allocation.dll'),str(frozen),str((r/'catalog.json').resolve()),str(output.resolve())],env=env,stdout=log,stderr=subprocess.STDOUT,timeout=45)
assert done.returncode==0,(r/'allocation.log').read_text(encoding='utf-8')[-1500:]
j=json.loads(output.read_text(encoding='utf-8'));assert len(j['rows'])==4 and all(x['sharedBudgetBaselineRestored'] for x in j['rows'])
assert not list(fixture.iterdir());fixture.rmdir()
rows=[]
for name in ['scripts.csv-invoice.large','scripts.file-search.large']:
    a=statistics.median(next(x for x in j['rows'] if x['id']==name)['allocatedBytesPerInvocation'])
    b=statistics.median(next(x for x in j['rows'] if x['id']==name+'.protected')['allocatedBytesPerInvocation'])
    rows.append(dict(case=name,originalBytes=a,protectedBytes=b,changePercent=100*(b/a-1)))
summary=dict(coreSHA256=image,toolSHA256=hashlib.sha256((frozen/'Allocation.dll').read_bytes()).hexdigest(),elapsedSeconds=time.monotonic()-start,rows=rows,allGoldensAndSharedBudgetChecksPassed=True,allWorkersJoinedAndFixturesRemoved=True,sourceFormsDifferIntentionally=True,notElapsedOrCpuMeasurement=True,boundary=j['boundary'])
(r/'allocation-summary.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps(summary),flush=True)
