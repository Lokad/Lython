from pathlib import Path
import gzip
import hashlib
import json
import subprocess

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
record = 'benchmarks/results/2026-11-23-retained-call-cpython/'
sha = lambda data: hashlib.sha256(data).hexdigest()
tracked = lambda name: subprocess.check_output(['git','show','origin/master:'+record+name],cwd=repo)
receipt = json.loads(tracked('terminal-status.json'))['receipt']
assert receipt['complete'] and receipt['archivedAndVerifiedUnderLease']
assert sha(tracked('observations.tar.xz')) == receipt['archiveSHA256']
binary = sha(gzip.decompress(tracked('candidate-core.dll.gz')))
assert binary == json.loads(tracked('identity.json'))['imageFiles']['candidate']['Lokad.Lython.dll']
saved = lab/'verified-replicas.json'
replicas = json.loads(saved.read_text(encoding='utf-8'))
replicas.append(dict(path='retained-call-cpython-b1510-20261123/candidate/Lokad.Lython.dll',
    sha256=binary,observationSHA256=receipt['archiveSHA256'],trackedArchive=record))
saved.write_text(json.dumps(replicas,indent=2)+'\n',encoding='utf-8',newline='\n')
