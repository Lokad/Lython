using System;
using System.Linq;
using System.Linq.Expressions;
using System.Reflection;

var assembly = Assembly.LoadFrom(args[0]);
var iterator = assembly.GetType("Lokad.Lython.Runtime.LythonRuntime+JsonEncodeIterator", throwOnError: true)!;
var estimatedBytes = (long)iterator.GetField("StorageBytes", BindingFlags.NonPublic | BindingFlags.Static)!.GetRawConstantValue()!;
var constructor = iterator.GetConstructors(BindingFlags.NonPublic | BindingFlags.Instance).Single();
var instantiate = Expression.Lambda<Func<object>>(Expression.Convert(
    Expression.New(constructor, constructor.GetParameters().Select(parameter => Expression.Default(parameter.ParameterType))),
    typeof(object))).Compile();
for (var warm = 0; warm < 1024; warm++)
    GC.KeepAlive(instantiate());
const int count = 16_384;
var minimum = long.MaxValue;
for (var batch = 0; batch < 3; batch++)
{
    var before = GC.GetAllocatedBytesForCurrentThread();
    for (var i = 0; i < count; i++)
        GC.KeepAlive(instantiate());
    var bytes = GC.GetAllocatedBytesForCurrentThread() - before;
    minimum = Math.Min(minimum, bytes);
    Console.WriteLine($"{bytes} CLR bytes in batch {batch + 1}");
}
Console.WriteLine($"{(double)minimum / count:0.000} minimum CLR bytes per constructor; {estimatedBytes} admitted bytes");
return minimum % count == 0 && minimum <= estimatedBytes * count ? 0 : 1;
