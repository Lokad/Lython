set -eu
root=/home/lokad/lython-bench-checks/shared-executable-graph-b1212-20261120
trap 'result=$?; printf "%s\n" "$result" > "$root/exit-code.txt"' EXIT
python3 "$root/collect.py"
