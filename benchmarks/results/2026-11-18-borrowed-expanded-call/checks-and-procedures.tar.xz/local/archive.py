from pathlib import Path
import hashlib
import json
import re
import shutil
import subprocess
import tarfile

lab = Path(__file__).resolve().parent
quiet = lab / "quiet"
out = Path("benchmarks/results/2026-11-18-borrowed-expanded-call")
load = lambda path: json.loads(path.read_text(encoding="utf-8-sig"))
read = lambda path: path.read_text(encoding="utf-8-sig")
sha = lambda data: hashlib.sha256(data).hexdigest()
terminal = load(quiet / "terminal-status.json")
receipt = load(quiet / "archive-receipt.json")
assert terminal["exitCode"] == "0" and terminal["receipt"] == receipt
assert sha((quiet / "observations.tgz").read_bytes()) == receipt["archiveSHA256"]
assert receipt["jobs"] == 2 and all(receipt[name] for name in (
    "complete", "allWorkersJoined", "guestFixturesRemoved", "quietBeforeAndAfter", "archivedAndVerifiedUnderLease"
))
for kind, count in [("white-final",36), ("public",226), ("wsl-final",36)]:
    for target in ["net10.0", "net11.0"]:
        assert re.search(rf"Failed:\s+0, Passed:\s+{count}, Skipped:\s+0", read(lab / f"{kind}-{target}.log"))
assert read(lab / "overlap-reference.log").count("No exception was thrown") == 2

old_manifest = load(lab / "frozen-identity.json")
assert old_manifest["casesSHA256"] == sha((lab / "catalog.json").read_bytes())
for role, files in old_manifest["images"].items():
    assert {name: sha((lab / "frozen" / role / name).read_bytes()) for name in files} == files
    assert load(lab / f"{role}-verify.json")["state"] == "Completed"

screen = []
for path in sorted(lab.glob("micro-*.json")):
    data = load(path)
    assert data["catalogSha256"] == old_manifest["casesSHA256"]
    index = int(path.name.split("-")[1])
    report = dict(file=path.name, lane=data["lane"], state=data["state"])
    if data["state"] == "Completed":
        by_role = {row["engine"]: row for row in data["summaries"]}
        before, updated = ("baseline", "candidate") if index < 4 else ("candidate", "baseline")
        report.update(reference=by_role[before], candidate=by_role[updated], CPython=by_role["CPython"],
                      elapsedDeltaPercent=100*(by_role[updated]["medianMicroseconds"]/by_role[before]["medianMicroseconds"]-1))
    else:
        report.update(error=data.get("error"), log=read(path.with_suffix(".log")).strip())
    screen.append(report)
assert len(screen) == 8 and sum(row["state"] == "Completed" for row in screen) == 7
assert any("OperationCanceledException" in row.get("log", "") for row in screen)
assert sha(lab.joinpath("frozen/candidate/Lokad.Lython.dll").read_bytes()) == old_manifest["images"]["candidate"]["Lokad.Lython.dll"]
source = subprocess.check_output(["git", "-C", ".git/agent-worktrees/borrowed-expanded-call-r566",
                                  "diff", "--binary", "045eb7f44", "--", "src", "tests"])
(lab / "source.patch").write_bytes(source)
out.mkdir(exist_ok=False)
for name in ["observations.tgz", "archive-receipt.json", "terminal-status.json"]:
    shutil.copyfile(quiet / name, out / name)
shutil.copyfile(lab / "quiet-summary.json", out / "summary.json")
shutil.copyfile(lab / "allocation-summary.json", out / "allocation-summary.json")
(out / "windows-screen.json").write_text(json.dumps(dict(rows=screen, sourcePatchSHA256=sha(source)), indent=2)+"\n", encoding="utf-8")
with tarfile.open(out / "checks-and-procedures.tar.xz", "w:xz", preset=6) as tar:
    for name in ["collect.py", "archive-owned.py", "config.json", "identity.json", "run.sh",
                 "remote-launch.py", "observe-not-before.json", "retrieve.py", "representative.json"]:
        tar.add(quiet / name, arcname=name)
    for path in sorted(lab.iterdir()):
        if path.is_file() and path.suffix in {".log", ".json", ".py", ".patch"}:
            tar.add(path, arcname=f"local/{path.name}")
print("Verified source, Windows and WSL checks, both failing reference regressions and full observations.")
