from pathlib import Path
import ast
import hashlib
import json
import shutil
import tarfile

lab = Path(__file__).resolve().parent
donor = lab.parent / "direct-keyword-overflow-r565"
previous = donor / "quiet-corrected"
quiet = lab / "quiet"
quiet.mkdir(exist_ok=False)
read = lambda path: path.read_text(encoding="utf-8")
load = lambda path: json.loads(read(path))
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
def write(path, source):
    if path.suffix == ".py":
        ast.parse(source)
    path.write_text(source, encoding="utf-8", newline="\n")
def save(path, data):
    write(path, json.dumps(data, ensure_ascii=False, indent=2) + "\n")

prior = load(previous / "config.json")
screen = load(lab / "frozen-identity.json")
space = load(lab / "quiet-space.json")
catalog = lab / "catalog.json"
images = screen["images"]
source_files = prior["identity"]["imageFiles"]["candidate"]
core = "Lokad.Lython.dll"
assert images["reference"] == source_files and screen["casesSHA256"] == sha(catalog)
for role, files in images.items():
    assert len(files) == 32 and files == source_files | {core: files[core]}
    assert {name: sha(lab / "frozen" / role / name) for name in files} == files
    verified = load(lab / f"{role}-verify.json")
    assert verified["state"] == "Completed" and verified["catalogSha256"] == sha(catalog)
(quiet / "candidate").mkdir()
shutil.copyfile(lab / "frozen" / "candidate" / core, quiet / "candidate" / core)
jobs = [("scripts.report-forwarding.expanded", "warm"), ("calls.positional.large", "warm")]
identity = dict(sourceRevision="045eb7f44 versus R566 borrowed expanded-call arguments",
                purpose="R566 expanded application paired elapsed and process CPU comparison",
                imageFiles=images, catalogSHA256=sha(catalog), normalAdapterPin="0.4.0",
                coreSHA256={label: images[role][core] for role in images for label in [role, role + "-control"]})
root = "/home/lokad/lython-bench-checks/expanded-call-b992-20261118"
unit = "lython-b992-expanded-call-20261118"
runner = read(previous / "collect.py").replace("Keyword forwarding source pair", "Expanded call source pair")
a = runner.index("\njobs = ")
b = runner.index("\nassert len(jobs)", a)
write(quiet / "collect.py", runner[:a] + "\njobs = " + repr(jobs) + runner[b:])
write(quiet / "archive-owned.py", read(previous / "archive-owned.py"))
write(quiet / "run.sh", read(previous / "run.sh").replace(prior["root"], root))
assert b"\r" not in (quiet / "run.sh").read_bytes()
save(quiet / "identity.json", identity)
shutil.copyfile(catalog, quiet / "representative.json")
names = ["collect.py", "archive-owned.py", "run.sh", "identity.json", "representative.json", f"candidate/{core}"]
payload = quiet / "payload.tgz"
with tarfile.open(payload, "w:gz") as archive:
    for name in names:
        archive.add(quiet / name, arcname=name)
expanded = sum((quiet / name).stat().st_size for name in names)
need = 254 * 1024 * 1024 + expanded + 512 * 1024
available, selected = space["freeBytes"], []
for proof in sorted(space["replicas"], key=lambda item: -item["bytes"]):
    if available >= need:
        break
    selected.append(proof)
    available += proof["bytes"]
assert available >= need, (available, need, space["replicas"])
config = dict(root=root, unit=unit, source=prior["root"], sourceRole="candidate", sourceFiles=source_files,
              sourceCatalogSHA256=prior["catalogSHA256"], catalogSHA256=sha(catalog), identity=identity,
              retireGroups=selected, payloadBytes=payload.stat().st_size, payloadSHA256=sha(payload), unpackedBytes=expanded)
save(quiet / "config.json", config)
launcher = read(previous / "remote-launch.py")
a = launcher.index("\nc=") + 1
b = launcher.index("\nb=Path(")
launcher = launcher[:a] + "c=" + repr(config) + launcher[b:]
write(quiet / "remote-launch.py", launcher.replace("lython-b991-fixtures", "lython-b992-fixtures"))
write(quiet / "retrieve.py", read(previous / "retrieve.py").replace("Keyword forwarding source pair", "Expanded call source pair"))
launch = read(donor / "launch-quiet-corrected.py").replace("parent/'quiet-corrected'", "parent/'quiet'")
write(lab / "launch-quiet.py", launch.replace("Keyword forwarding source pair", "Expanded call source pair"))
summary = read(donor / "summarize-quiet-corrected.py").replace("quiet-corrected/retrieved", "quiet/retrieved")
summary = summary.replace("corrected-quiet-summary.json", "quiet-summary.json").replace("'final-", "'")
write(lab / "summarize-quiet.py", summary)
print("Verified full B992 worker images and selected", len(selected), "archived raw replicas")
