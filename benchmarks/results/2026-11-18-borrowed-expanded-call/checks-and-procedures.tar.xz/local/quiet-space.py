from pathlib import Path
import hashlib
import io
import json
import subprocess
import tarfile

lab = Path(__file__).resolve().parent
sha = lambda value: hashlib.sha256(value).hexdigest()
roots = [
    ("lexical-binding-order", "lexical-binding-order-b989"),
    ("syntax-validity-scratch", "syntax-validity-b985"),
    ("trimmed-split-join", "trimmed-split-join-b981"),
    ("private-line-count", "split-line-count-b983"),
    ("direct-keyword-overflow-screen/confirmation", "keyword-forwarding-b990"),
]
member = "confirmation/confirmation.json"
proofs = []
for archive, root in roots:
    canonical = f"benchmarks/results/2026-11-18-{archive}/observations.tgz"
    content = subprocess.check_output(["git", "show", f"origin/master:{canonical}"])
    assert content == Path(canonical).read_bytes()
    with tarfile.open(fileobj=io.BytesIO(content), mode="r:gz") as tar:
        observations = tar.extractfile(member).read()
    assert json.loads(observations)["complete"]
    proofs.append(dict(paths=[f"{root}-20261118/{member}"], canonical=canonical,
                       canonicalSHA256=sha(content), member=member, sha256=sha(observations),
                       bytes=len(observations), links=1, kind="exact archived raw observation replica",
                       committedBlobVerified=True))
previous = json.loads((lab.parent / "direct-keyword-overflow-r565/quiet-space.json").read_text(encoding="utf-8"))
for proof in previous["replicas"]:
    if not proof["canonical"].endswith("/observations.tgz") or not proof["paths"][0].endswith("/observations.tgz"):
        continue
    if not proof["canonical"].startswith(("benchmarks/results/2026-11-16-", "benchmarks/results/2026-11-17-")):
        continue
    content = subprocess.check_output(["git", "show", f"origin/master:{proof['canonical']}"])
    assert len(proof["paths"]) == proof["links"] == 1
    assert content == Path(proof["canonical"]).read_bytes()
    assert sha(content) == proof["canonicalSHA256"] == proof["sha256"] and len(content) == proof["bytes"]
    proofs.append(proof)
remote = r'''
from pathlib import Path
import fcntl,hashlib,json,os,shutil,stat,subprocess
root=Path('/home/lokad/lython-bench-checks').resolve()
assert root==Path('/home/lokad/lython-bench-checks')
verified=[]
with (root/'comparison-vm.lock').open('a') as lease:
    fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
    assert not subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record|[p]ython3.13.*cpython-worker.py'],capture_output=True).stdout
    assert not any(os.path.ismount(p) for p in root.glob('*/guest-fixtures'))
    for proof in PROOFS:
        path=root/proof['paths'][0]
        if not path.exists():continue
        v=path.lstat()
        assert path.resolve()==path and path.is_relative_to(root) and stat.S_ISREG(v.st_mode)
        assert v.st_uid==os.getuid() and v.st_size==proof['bytes'] and v.st_nlink==proof['links']
        assert hashlib.sha256(path.read_bytes()).hexdigest()==proof['sha256']
        verified.append(proof)
    print(json.dumps(dict(freeBytes=shutil.disk_usage(root).free,replicas=verified)))
'''.replace("PROOFS", repr(proofs))
ssh = ["C:/Windows/System32/OpenSSH/ssh.exe", "-i", str(Path.home() / ".ssh/id_lython-bench.pem"),
       "-o", "BatchMode=yes", "-o", "ConnectTimeout=15", "lokad@20.166.121.73"]
result = subprocess.run(ssh + ["python3 -"], input=remote.encode("utf-8"), capture_output=True, timeout=45, check=True)
space = json.loads(result.stdout)
(lab / "quiet-space.json").write_text(json.dumps(space, indent=2)+"\n", encoding="utf-8")
print(space["freeBytes"], "bytes free and", len(space["replicas"]), "proved archived raw replicas")
