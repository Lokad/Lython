from pathlib import Path

lab = Path(__file__).resolve().parent
template = lab.parent / "direct-variadics-r564/measure.py"
text = template.read_text(encoding="utf-8")
text = text.replace("direct-variadics-r564", "borrowed-expanded-call-r566")
text = text.replace("scripts.report-forwarding.variadic", "scripts.report-forwarding.expanded")
text = text.replace("da1946b1c", "045eb7f44")
start = text.index('    source = r"""')
end = text.index('    output = ', start)
text = text[:start] + r"""    source = r'''def line(label, **fields):
    return '{}\t{}\t{}\t{}\t{}\t{}\t{}\n'.format(
        label, fields['début'], fields['end'], fields['count'],
        fields['priority'], fields['owner'], fields['service'])

start_key = ''.join(['dé', 'but'])
end_key = ''.join(['e', 'nd'])
count_key = ''.join(['cou', 'nt'])
count = 0
with open('input.txt', encoding='utf-8') as source, open('report.txt', 'w', encoding='utf-8', newline='') as target:
    for record in source:
        label, start, end, total, priority, owner, service = record.rstrip('\n').split(',')
        fields = {start_key: start, end_key: end, count_key: total,
                  'priority': priority, 'owner': owner, 'service': service}
        target.write(line(label, **fields))
        count += 1
print(count)
'''
    data = ("café,7,19,12,2,Éva,web\nnotes,3,9,6,1,Jen,queue\n商品,18,38,20,3,灘,sql\nreport,40,71,31,2,Jo,files\n" * 256).encode()
""" + text[end:]
original = 'replacement = src / "src/Lokad.Lython/bin/Release/net11.0" / core_name'
replacement = '''replacement = (donor.parent / "direct-keyword-overflow-r565/final-frozen/candidate" / core_name
                       if role == "reference" else src / "src/Lokad.Lython/bin/Release/net11.0" / core_name)'''
assert original in text
text = text.replace(original, replacement)
compile(text, str(lab / "measure.py"), "exec")
(lab / "measure.py").write_text(text, encoding="utf-8", newline="\n")
