from pathlib import Path
import fcntl,hashlib,json,os,shutil,subprocess
base=Path('/home/lokad/lython-bench-checks').resolve();groups={'ad3eb74a8440b88fc7aa3bb4f5c9c9e9bd9ea9c5a5aebae0b8e63393e6f2d9a6': ['/home/lokad/lython-bench-checks/proc-stat-exit-20261011/original-bin/Lokad.Lython.dll', '/home/lokad/lython-bench-checks/proc-stat-exit-20261011/corrected-bin/Lokad.Lython.dll'], '4c3f8fa9ad3fe49add25842dc62aabd047900f90fb55399a1a852b491aa41e58': ['/home/lokad/lython-bench-checks/csv-owned-record-b110-20261102/baseline/Lokad.Lython.dll', '/home/lokad/lython-bench-checks/owned-output-b109-20261102/candidate/Lokad.Lython.dll'], '1507216f09cd29a9fc842fac30862bc16e4c140989880cef100cbb65e6352084': ['/home/lokad/lython-bench-checks/key-query-b325-20261106/candidate/Lokad.Lython.dll', '/home/lokad/lython-bench-checks/key-query-b325-20261106/core/Lokad.Lython.dll', '/home/lokad/lython-bench-checks/key-query-text-b326-20261106/candidate/Lokad.Lython.dll', '/home/lokad/lython-bench-checks/key-query-text-b326-20261106/core/Lokad.Lython.dll'], '3bed411efcd6e008fc04bca8634d32be64bafc71742509ff0192e8eee86ab8bc': ['/home/lokad/lython-bench-checks/combined-storage-checkpoint-b184-20261103/baseline/Lokad.Lython.dll', '/home/lokad/lython-bench-checks/coupled-cpython-b195-20261104/baseline/Lokad.Lython.dll', '/home/lokad/lython-bench-checks/activation-storage-b170-20261103/candidate/Lokad.Lython.dll', '/home/lokad/lython-bench-checks/coupled-cpython-b189-20261104/baseline/Lokad.Lython.dll', '/home/lokad/lython-bench-checks/record-key-shape-b166-20261103-refined/candidate/Lokad.Lython.dll']}
with(base/'comparison-vm.lock').open('a') as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[c]ollector.dll|[p]erf record'],capture_output=True).returncode==1
 before=shutil.disk_usage(base).free;inventory={};aliases={}
 for digest,names in groups.items():
  rows=[]
  for name in names:
   p=Path(name).resolve();assert base in p.parents and p.name in ('Lokad.Lython.dll','baseline-core.dll','current-core.dll')
   assert hashlib.sha256(p.read_bytes()).hexdigest()==digest
   aliases[name]=dict(path=str(p),sha256=digest)
   if any(row['path']==str(p) for row in rows):continue
   st=p.stat();rows.append(dict(path=str(p),inode=st.st_ino,bytes=st.st_size,links=st.st_nlink))
  inventory[digest]=rows
 selected=[];saved=0
 for digest,rows in inventory.items():
  canonical=rows[0];byinode={row['inode']:[x for x in rows if x['inode']==row['inode']] for row in rows}
  for inode,paths in byinode.items():
   if inode==canonical['inode'] or len(paths)!=paths[0]['links']:continue
   selected.append(dict(sha256=digest,canonical=canonical,paths=paths));saved+=paths[0]['bytes']
   break
  if saved>=4*1024*1024:break
 assert 4*1024*1024<=saved<=8*1024*1024,(saved,inventory)
 proof=base/'r117-core-dedup-proof.json';assert not proof.exists()
 for group in selected:
  for row in [group['canonical'],*group['paths']]:
   p=Path(row['path']);st=p.stat();assert st.st_ino==row['inode'] and st.st_size==row['bytes'] and hashlib.sha256(p.read_bytes()).hexdigest()==group['sha256']
 for group in selected:
  canonical=Path(group['canonical']['path'])
  for row in group['paths']:
   p=Path(row['path']);temporary=p.with_name(p.name+'.r117-identical-link');assert not temporary.exists()
   os.link(canonical,temporary);os.replace(temporary,p)
 for name,row in aliases.items():
  p=Path(name);assert str(p.resolve())==row['path'] and hashlib.sha256(p.read_bytes()).hexdigest()==row['sha256']
 receipt=dict(beforeFreeBytes=before,afterFreeBytes=shutil.disk_usage(base).free,groups=selected,freshInventory=inventory,aliases=aliases,allPathsAndBytesPreserved=True,archivesUntouched=True,allOriginalAliasesVerified=True)
 proof.write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt))
