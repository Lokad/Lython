from pathlib import Path
import shutil
r=Path(__file__).parent;p=r/'summarize.py';shutil.copyfile(p,r/'initial-summarize.py')
s=p.read_text(encoding='utf8').replace("len(raw['jobs'])==28","len(raw['jobs'])==15").replace('len(external)==28','len(external)==15');p.write_text(s,encoding='utf8')
(r/'summarizer-note.md').write_text('''Before first local post-processing: copied summarizer retained two28-job arity assertions from the full historical catalog. Corrected both to15, preserving the original helper. No collector, source, timing, observation gate, runtime or adverse result changed; no rerun.\n''',encoding='utf8')
