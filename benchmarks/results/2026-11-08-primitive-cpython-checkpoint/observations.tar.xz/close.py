from pathlib import Path
import hashlib,json,shutil,tarfile
r=Path(__file__).parent;i=json.loads((r/'identity.json').read_text(encoding='utf8'));a=json.loads((r/'archive-receipt.json').read_text(encoding='utf8'));d=json.loads((r/'summary.json').read_text(encoding='utf8'))
assert a['complete'] and a['jobs']==15 and a['allWorkersJoined'] and a['quietBeforeAndAfter'] and not a['guestFixtureDirectories']
assert hashlib.sha256((r/'observations.tgz').read_bytes()).hexdigest()==a['archiveSHA256']
assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==h for p,h in i['productionSources'].items())
ci=json.loads((r/'delivery-ci.json').read_text(encoding='utf8'));assert ci['conclusion']=='success' and ci['headSha']==i['sourceRevision']
assert 'RuntimeMaxUSec=6min' in (r/'retrieved/live-unit.txt').read_text(encoding='utf8')
out=Path('benchmarks/results/2026-11-08-primitive-cpython-checkpoint');out.mkdir()
with tarfile.open(out/'observations.tar.xz','w:xz') as t:
    for p in sorted(r.iterdir()):
        if p.name not in ['retrieved','payload.tgz']:t.add(p,arcname=p.name)
with tarfile.open(out/'observations.tar.xz') as t:assert hashlib.sha256(t.extractfile('observations.tgz').read()).hexdigest()==a['archiveSHA256']
for src,name in [(r/'summary.json','summary.json'),(r/'identity.json','identity.json'),(r/'archive-receipt.json','archive-receipt.json'),(r/'delivery-ci.json','delivery-ci.json'),(r/'prior-BENCHMARKS.md','prior-BENCHMARKS.md'),(r/'sizing.json','sizing.json'),(r/'dedup-proof.json','dedup-proof.json')]:shutil.copyfile(src,out/name)
data={(v['case'],v['lane']):v for v in d['timing']}
names=[('scripts.csv-validated-records.large','CSV validation/returned records','5,120 records / 68,625 B'),('scripts.csv-summary-functions.large','CSV summary/helpers','4,096 records / 57,361 B'),('scripts.text-summary-helpers.large','Text summary/helpers','3,072 lines / 35,840 B'),('scripts.json-summary-helpers.large','JSON-lines/helpers','4,096 records / 110,592 B'),('scripts.report-render.large','JSON-to-Markdown report','3,072 records / 189,441 B')]
def clock(values):
    lo,hi=min(values),max(values);scale=1000 if hi<1 else 1;unit='µs' if hi<1 else 'ms';digits=1 if hi<1 else 3
    left=f'{lo*scale:.{digits}f}';right=f'{hi*scale:.{digits}f}'
    return (left if left==right else left+'–'+right)+' '+unit
def rows(lane,inputs=False):
    result=[]
    for id,name,size in names:
        x=data[id,lane];fields=[name]+([size] if inputs else [])+[clock(x['timeRangeMilliseconds']),clock([x['medianMilliseconds']['CPython']]),f'{x["ratioRange"][0]:.2f}–{x["ratioRange"][1]:.2f}×',f'{x["status"]}; {x["controlPercent"]:.2f}% / {max(x["iqrPercent"].values()):.2f}%']
        result.append('| '+' | '.join(fields)+' |')
    return '\n'.join(result)
evidence='[R117 checkpoint](../benchmarks/results/2026-11-08-primitive-cpython-checkpoint/README.md)'
guide='''# Performance against CPython

| Workload | Input | Lython | CPython | Lython / CPython | Status; control / max IQR |
| --- | --- | ---: | ---: | ---: | --- |
'''+rows('compile-run',True)+'''

**2026-11-08, source `b1e17b64`, CPython 3.13.16, .NET 11 RC3.**
The table measures **compilation plus one execution in an already-running host**,
including mediated RAM-file I/O, complete output validation and prior-result
cleanup. Worker/engine startup and fixture staging/reset are excluded.
**Ratio = Lython elapsed / CPython elapsed; above one means slower.** Ranges span
two independent Lython process medians, not confidence intervals. Control is their
absolute difference; max IQR includes CPython. Diagnostic/Variable describe short
observations, not design acceptance thresholds. Variable cases remain visible.

Frozen core `93e926fe` matches the measured production inventory. Windows/Ubuntu
Release actual.NET11/.NET10, original stress both and installed core consumers pass
[cached CI42512127664](../benchmarks/results/2026-11-08-primitive-helper-delivery/delivery-ci.json).
Source qualification and performance evidence are separate. The '''+evidence+'''
reuses five unchanged scripts, catalog/goldens and workers:15jobs/311.431s, all
quiet/output/ownership/cleanup/archive gates pass. No remaining VM users/fixtures.

## Warm execution, compilation and startup

Warm execution reuses the compiled script and excludes compilation:

| Workload | Lython | CPython | Lython / CPython | Status; control / max IQR |
| --- | ---: | ---: | ---: | --- |
'''+rows('warm')+'''

Compilation alone includes code construction and disposal under the shared allowance:

| Workload | Lython | CPython | Lython / CPython | Status; control / max IQR |
| --- | ---: | ---: | ---: | --- |
'''+rows('compile')+'''

Startup, RSS/heap peaks, genuinely pending I/O and impact on other embedding work
are unmeasured. Small file-backed scripts do not establish large-file throughput.

## Measurement boundary and fairness

Dedicated Azure F4as_v7, Ubuntu24.04.4, four AMD EPYC9V45vCPUs,16GiB/no swap.
Actual.NET11RC3 and isolated CPython3.13.16 use normal GC/tiering; five-second
warmup per role/job and seven rotated150msrounds. Frozen worker7cf/optional0.4
adapter unchanged. This checkpoint certifies no newer regex producer.

Identical scripts/fixtures run on both engines, with full stdout/file digests
checked every invocation. Lython uses efficient mediated filesystem overrides;
CPython uses builtin open. Lython opens include capability/path-component checks.
RAM fixtures include guest reads/writes; fixture staging/reset and protocol are
outside clocks. Warm includes invocation/prior-result cleanup. Compilation includes
construction/disposal; compile-to-result adds it to execution. Final cached teardown
is excluded. CPython retains imported modules; Lython isolates execution imports.
This is an embedding comparison, not an isolated CPU kernel. Tables use synchronous
Run; completed-I/O async diagnostics do not establish pending-I/O latency.

## Coverage and uncertainty

Configuration edit, protected file search and copy/checksum/manifest were last
measured at source7265538c, not b1e17b64. Their historical warm ratios were1.26–1.27×,
1.68–1.69× and1.54×; compile-to-result1.16×,1.49–1.51× and1.48× respectively.
Guarded text and eager/streamed JSON normalization are also historical: warm
1.76–1.78×,1.23–1.25× and0.61–0.62×, with compilation/startup unmeasured for these
variants. [Prior guide and evidence](../benchmarks/results/2026-11-08-json-conditional-checkpoint/README.md)
retain the exact source, adverse controls and boundaries. These cases were not
rerun merely to fill a table. The five current cases above include inconclusive
roles and do not isolate individual optimizations or explain earlier regressions.

## Improvements within Lython

CPython remains the primary external baseline. Separate source pairs below are
not additive or universal CPU gains:

| Change / affected work | Established result | Limits / evidence |
| --- | --- | --- |
| Primitive helper proof / complete accounting | Integer CSV/JSON elapsed −3.5–5.2%; float CSV −1.8–6.2% across APIs, supporting CPU; incremental warm allocation neutral | Metadata/ordinary forwarding consolidated. Compiler allocation +1.4–1.5%accounting; custom async +1.3–3.4%elapsed/+6.7%CPU debt, text/report uncertain. Sourceb1e17b64 fully qualified. [R113–R115](../benchmarks/results/2026-11-08-primitive-helper-delivery/README.md) |
| Known-layout record value growth / wide JSON report | Allocation −8.6% both APIs; controlled elapsed −4–10%sync/−6–8%async, coarse CPU supports | New24-field fixtures; alternating records neutral allocation, ordinary controls uncertain. Source05790317 fully qualified. [R110](../benchmarks/results/2026-11-08-json-record-capacity/README.md) |
| Native JSON construction / normalization | Eager allocation −27–28%, elapsed −9–12%; streamed allocation −24%, elapsed −6–7%, supporting CPU | Configuration CPU+4–6%possible debt retained. [R105](../benchmarks/results/2026-11-08-native-json-construction/README.md) |
| Native helper-return expressions | Allocation −19.92%sync/−19.31%async | Original elapsed improvements are diagnostic; later guarded helper source pairs are separate. [History](../benchmarks/EXPERIMENTS.md) |
| Direct UTF8 formatting/storage | Allocation −8.67%; controlled elapsed/CPU−5–8% | Original adverse15.125ms measurement remains unexplained, not erased by later controls. [History](../benchmarks/EXPERIMENTS.md) |

Other delivered source pairs, rejected designs, detailed qualification and original
failed conditions remain in [experimental history](../benchmarks/EXPERIMENTS.md),
the [previous guide](../benchmarks/results/2026-11-08-primitive-cpython-checkpoint/prior-BENCHMARKS.md)
and [benchmark tooling](../benchmarks/README.md). Current text CPU attribution
finds useful native processing and required checks; it does not establish dominant
call/frame construction or justify a new interpreter from inclusive samples alone.
'''
# Verify the directly linked R105 evidence path before publishing navigation.
assert Path('benchmarks/results/2026-11-08-native-json-construction/README.md').exists()
Path('docs/BENCHMARKS.md').write_text(guide,encoding='utf8')
(out/'README.md').write_text('''# Current representative CPython checkpoint

2026-11-08. Committed and fully qualifiedb1e17b64/frozen93e926fe against isolated
CPython3.13.16, actual.NET11RC3, dedicated AzureF4as_v7/Ubuntu24.04.4/four EPYC9V45
vCPUs/16GiB/no swap. Production inventory matches; full Windows/Ubuntu actual11/10,
original Stress both and installed core consumers pass [cached delivery](delivery-ci.json).

Fifteen jobs311.431s: five unchanged maintained scripts, separately compilation,
warm execution and compile-to-result. ReturnedCSVvalidation, CSVhelpers, ordinary
texthelpers, JSON-lineshelpers and JSON-to-Markdownreport; same R109catalog/full
stdout/file goldens, worker7cf/optional0.4/protocol. Two independent Lython processes
and isolated CPython, normal GC/tiering,5swarmup/role/job,7rotated150msrounds.
No new framework, tuned scripts, producer qualification or per-edit full campaign.

'''+guide[:guide.index('## Measurement boundary and fairness')]+'''

Variable cases and all roles are retained. Ratios compare complete workloads and
do not attribute isolated optimization gains or repay older source-pair debt.
Config/search/manifest and four additional helper/normalization variants keep
historical726labels; no inference they describeb1e17b64. Startup/RSS/pending-I/O/
embedding-tail gaps remain. Current guide and this snapshot use the same raw data.

All source/core/aux/Ready/golden/quiet-before-and-after/Closed/exit/join/fixture/
unmount/archive/local verification gates pass. Live360sowner captured, all15jobs
complete within311.431s; no remaining users or RAM fixtures. Persistent evidence,
already-preserved B475core/archive reused. Fresh exact-byte/inode/alias hardlinks
recovered5.03MB, all old paths/bytes/archives retained. OS240MiB/evidence12MiB/
actualpayload preflight strengthened to count payload separately; no relaxed guard.
Copied summarizer's28-job assertion corrected to15 before first post-processing,
original helper retained, no remeasurement or changed observations.

[Summary](summary.json), [identity](identity.json), [receipt](archive-receipt.json),
[prior guide](prior-BENCHMARKS.md), [sizing](sizing.json), [alias proof](dedup-proof.json),
[all raw/source/corrections](observations.tar.xz).
''',encoding='utf8')
# The embedded snapshot uses paths relative to this results directory.
p=out/'README.md';s=p.read_text(encoding='utf8').replace('../benchmarks/results/2026-11-08-primitive-helper-delivery/delivery-ci.json','delivery-ci.json').replace('../benchmarks/results/2026-11-08-primitive-cpython-checkpoint/README.md','README.md');p.write_text(s,encoding='utf8')
p=Path('benchmarks/EXPERIMENTS.md');p.write_text(p.read_text(encoding='utf8')+'''
## Qualified primitive-source CPython checkpoint (2026-11-08)

[R117/B477](results/2026-11-08-primitive-cpython-checkpoint/README.md), qualified
b1e17b64/core93e9, CPython3.13.16,15jobs311.431s/allgates/archive/local. Five
unchanged scripts separate compile/warm/compile-to-result. Compile-to-result:
returnedCSV1.23–1.25x, CSV1.06–1.07x, text1.52x, JSON0.92–0.96xvariable,
report1.42–1.46xvariable. Warmtext1.58–1.65xvariable, CSV1.03–1.07xvariable;
all roles/adverse data retained, no isolated gain/old-debt repayment. Historical
config/search/manifest/extra variants remain726, not current-source claims.
No publication, new framework or unchanged source qualification replay.
''',encoding='utf8')
print('Current CPython guide refreshed from15verifiedjobs; five current cases, historical/missing/variable evidence explicit.')
