from pathlib import Path
import ast,hashlib,json,shutil,subprocess,tarfile
r=Path(__file__).parent;old=r.parent/'conditional-checkpoint-r109';runtime=r.parent/'primitive-proof-r115';vm=runtime/'b475'
i=json.loads((runtime/'identity.json').read_text(encoding='utf8'));prior=json.loads((old/'identity.json').read_text(encoding='utf8'))
assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==h for p,h in i['productionSources'].items())
head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();assert head.startswith('b1e17b64')
receipt=json.loads((vm/'archive-receipt.json').read_text(encoding='utf8'));assert hashlib.sha256((vm/'observations.tgz').read_bytes()).hexdigest()==receipt['archiveSHA256']
with tarfile.open(vm/'observations.tgz') as t:assert hashlib.sha256(t.extractfile('current-core.dll').read()).hexdigest()==i['coreSHA256']['candidate']
(r/'core-source.json').write_text(json.dumps(dict(vmArchive='primitive-proof-b475-20261108/observations.tgz',archiveSHA256=receipt['archiveSHA256'],member='current-core.dll',coreSHA256=i['coreSHA256']['candidate'],immutableLocalArtifact='benchmarks/results/2026-11-08-primitive-helper-delivery/observations.tar.xz (nested B475)'),indent=2)+'\n',encoding='utf8')
shutil.copyfile(old/'representative.json',r/'representative.json');catalog=json.loads((r/'representative.json').read_text(encoding='utf8'))
for c in catalog['cases']:
    for field,digest in [('source','sourceSha256'),('fixtureJson','fixtureSha256'),('expectedOutput','expectedOutputSha256')]:assert hashlib.sha256(c[field].encode()).hexdigest()==c[digest]
ids=['scripts.csv-validated-records.large','scripts.csv-summary-functions.large','scripts.text-summary-helpers.large','scripts.json-summary-helpers.large','scripts.report-render.large']
jobs=[[case,lane] for case in ids for lane in ['compile','warm','compile-run']]
identity=dict(sourceRevision=head,coreSHA256={role:i['coreSHA256']['candidate'] for role in ['candidate','candidate-control']},auxiliaryFiles=prior['auxiliaryFiles'],productionSources=i['productionSources'],jobs=jobs,referenceVersion='CPython3.13.16',qualification='1526public/104internal focused peractual11/10 and controlled B475 pass. Exact sourceb1e17b64 full CI42512127664 pending independently. No producer qualification or publication.')
(r/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf8')
for name in ['collect.py','run.sh','retrieve.py','summarize.py','archive-owned.py','launch.py']:
    s=(old/name).read_text(encoding='utf8').replace('conditional-cpython-b467-20261108','current-cpython-b477-20261108').replace('lython-b467-conditional-cpython','lython-b477-current-cpython').replace('conditional-cpython-b467-launch.py','current-cpython-b477-launch.py').replace('lython-b467-fixtures','lython-b477-fixtures')
    s=s.replace('len(jobs)==28','len(jobs)==15').replace("len(r['jobs'])==28","len(r['jobs'])==15").replace("len(d['jobs'])==28","len(d['jobs'])==15").replace("['jobs']==28","['jobs']==15").replace('jobs=28','jobs=15').replace('all28JobsValidated','all15JobsValidated').replace('ownerSeconds=620','ownerSeconds=360').replace('RuntimeMaxSec=620','RuntimeMaxSec=360').replace('seconds=680','seconds=420').replace('time.monotonic()-started < 590','time.monotonic()-started < 330')
    if name=='collect.py':
        a=s.index('jobs=');z=s.index('\nassert len(jobs)',a);s=s[:a]+'jobs='+repr(jobs)+s[z:]
        a=s.index("purpose='");z=s.index("',\n",a);s=s[:a]+"purpose='R117 targeted committedb1e17b64 checkpoint, five unchanged complete CSV/text/JSON/report scripts, separate compilation warm and compile-to-result against CPython"+s[z:]
    if name=='launch.py':
        s=s.replace("reference=base/'refined-conditional-helpers-b465-20261108/candidate'","reference=base/'primitive-proof-b475-20261108/candidate'")
        s=s.replace('required=251658240+12582912','required=251658240+12582912+payloadRequired')
        s=s.replace("setup['freeBytes']>251658240+12582912-payloadRequired","setup['freeBytes']>251658240+12582912")
    if name=='run.sh':
        marker='date -u +%FT%TZ > "$root/started.utc"\n';assert marker in s
        s=s.replace(marker,marker+'systemctl show lython-b477-current-cpython-20261108.service --property=RuntimeMaxUSec,LoadState,ActiveState,MainPID > "$root/live-unit.txt"\n')
    if name=='archive-owned.py':
        s=s.replace("'started.utc', 'run.sh'","'started.utc', 'live-unit.txt', 'run.sh'")
        marker="with tarfile.open(root/'observations.tgz','w:gz') as t:\n";assert marker in s
        s=s.replace(marker,"assert not (root/'guest-fixtures').exists()\nlive=(root/'live-unit.txt').read_text();assert 'LoadState=loaded' in live and 'RuntimeMaxUSec=infinity' not in live\n"+marker)
    (r/name).write_text(s,encoding='utf8',newline='\n')
    if name.endswith('.py'):ast.parse(s)
for src,name in [(runtime/'identity.json','focused.json'),(runtime/'source.patch','source.patch'),(Path('PLAN.md'),'pre-measurement-plan.md'),(Path('docs/BENCHMARKS.md'),'prior-BENCHMARKS.md')]:shutil.copyfile(src,r/name)
(r/'setup-contract.json').write_text(json.dumps(dict(jobs=jobs,ownerSeconds=360,stopSeconds=30,marginSeconds=30,evidenceHeadroomMiB=12,osFloorMiB=240),indent=2)+'\n',encoding='utf8')
dynamic=sum((p.stat().st_size+4095)//4096*4096 for p in (old/'retrieved/confirmation').rglob('*') if p.is_file());estimate=(dynamic*15/28+(old/'observations.tgz').stat().st_size+(r/'representative.json').stat().st_size)*1.5;assert estimate<12*1024*1024
(r/'sizing.json').write_text(json.dumps(dict(priorRoundedDynamicBytes=dynamic,priorArchiveBytes=(old/'observations.tgz').stat().st_size,jobs=15,priorJobs=28,newCatalogBytes=(r/'representative.json').stat().st_size,estimateWith50PercentHeadroom=estimate,evidenceHeadroomBytes=12*1024*1024,osFloorBytes=240*1024*1024,coreArchiveReused=True),indent=2)+'\n',encoding='utf8')
contract='''R117 targeted coherent-delivery CPython checkpoint atcommittedb1e17b64/frozen93e926fe, production inventory matches. Five unchanged maintained scripts: returnedCSVvalidation, CSVhelpers, ordinarytexthelpers, JSON-lineshelpers, JSON-to-Markdownreport; compilation/warm/compile-to-result15jobs. Reuse byte-identical full R109catalog/fixtures/fullgoldens/worker7cf/optional0.4/protocol and verified B475core/archive; no new framework, script tuning or per-edit full campaign. Additional config/search/manifest/guardedtext/normalization cases retain accurately labelled historical726measurements, not current-source claims.
Two independent Lython processes and isolated CPython3.13.16, quietF4as_v7/Ubuntu24.04.4/actual.NET11RC3, normalGC/tiering,5swarmup/role/job,7rotated150msrounds. Warm includes invocation/mediated RAM I/O/fulloutputvalidation/prior-resultcleanup; startup/staging/reset/protocol/finalcachedteardown excluded. Compilation includes construction/disposal, compile-to-result adds it to execution. No isolated-change CPU/RSS/startup/pending-I/O/embedding-tail claim. Preserve earlier guides and adverse/inconclusive controls; source qualification independent pendingCI42512127664, publication postponed.
360sowner+30stop+30margin pre-sized for15jobs (prior28completed581.7s), final-job admission<330; live finite unit recorded atstartup. Persistent evidence/owned128MiBRAMfixtures; all Ready/core/aux/fullgolden/quiet/Closed/exit/join/unmount/archive/local gates. Unchanged240MiBOSfloor+12MiBevidence+actualpayload rounded preflight, prior scaled dynamic+archive+catalog+50%fitsheadroom. No evidence/path/archive deletion, no new binaries or producer qualification. After checkpoint report useful whole-script gaps/uncertainty and choose next coherent phase only with demonstrated removable work.
'''
for name in ['contract.md','selection.md']:(r/name).write_text(contract,encoding='utf8')
p=Path('PLAN.md');s=p.read_text(encoding='utf8');s+='\nR117 selected current CPython checkpoint: five unchanged CSV/text/JSON/report\nscripts x compile/warm/compile-to-result=15jobs, pre-sized360s owner, existing\nworkers/catalog/goldens. Others keep historical726labels; no new framework,\nprototype or source qualification replay. Then bounded existing-prefix-PC source\nanalysis (15min), no universal tags/guard bypass from unresolved samples.\n';p.write_text(s,encoding='utf8')
shutil.copyfile(p,r/'pre-measurement-plan.md')
with tarfile.open(r/'payload.tgz','w:gz') as t:
    for name in ['collect.py','archive-owned.py','run.sh','representative.json','identity.json','focused.json','source.patch','contract.md','selection.md','prior-BENCHMARKS.md','setup-contract.json','pre-measurement-plan.md','core-source.json','sizing.json']:t.add(r/name,arcname=name)
print('R11715 targeted whole-script CPython jobs prepared; unchanged catalog, independent qualifications and historical labels explicit.')
