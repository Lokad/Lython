from pathlib import Path
r=Path(__file__).parent
s=(r.parent/'primitive-helpers-r113/prepare-space-inodes.py').read_text(encoding='utf8').replace('r113-core-dedup-proof.json','r117-core-dedup-proof.json').replace('.r113-identical-link','.r117-identical-link')
(r/'prepare-space-bounded.py').write_text(s,encoding='utf8');exec(compile(s,str(r/'prepare-space-bounded.py'),'exec'))
