from pathlib import Path
import hashlib,json,shutil,subprocess,tarfile
r=Path(__file__).parent;old=r.parent/'search-runtime-r143';freeze=r.parent/'callback-transport-r149'
old_name='search-runtime-b501-20261109';new_name='json-runtime-b505-20261109'
for name in ['ops-profile.py','analyze-cpu-guest.py','archive.py','attribute.py','run.sh','retrieve.py','launch.py']:
    data=(old/name).read_text(encoding='utf-8').replace(old_name,new_name).replace('lython-b501-search-runtime-20261109','lython-b505-json-runtime-20261109').replace('/dev/shm/lython-b501','/dev/shm/lython-b505').replace('lython-b501-fixtures','lython-b505-fixtures').replace('search-runtime-b501-launch.py','json-runtime-b505-launch.py')
    data=data.replace('search-warm','json-warm').replace('scripts.file-search.control.large','scripts.json-summary-helpers.large').replace('One original file-search capture','One original JSON-report capture')
    if name=='launch.py':
        data=data.replace('generator-storage-b500-20261109/candidate','callback-transport-b504-20261109/candidate')
        start=data.index(" fixture=Path(");end=data.index(" setup=dict(",start)
        section=data[start:end];middle=section.index(' identity=')
        # Validate all source/auxiliary/script identities before mounting RAM.
        data=data[:start]+section[middle:]+section[:middle]+data[end:]
        end=data.index("subprocess.run(['sudo','-n','systemd-run'")
        tail=data.index("'''.replace('SIZE'",end)
        launch=data[end:tail]
        data=data[:end]+"try:\n"+''.join(' '+line+'\n' for line in launch.splitlines())+"except BaseException:\n subprocess.run(['sudo','-n','umount',str(fixture)],check=True);fixture.rmdir();raise\n"+data[tail:]
    if name.endswith('.py'):compile(data,name,'exec')
    (r/name).write_text(data,encoding='utf-8',newline='\n')
identity=json.loads((freeze/'identity.json').read_text(encoding='utf-8'))
assert all(hashlib.sha256(Path(name).read_bytes()).hexdigest()==digest for name,digest in identity['productionSources'].items())
shutil.copyfile(freeze/'images/candidate/Lokad.Lython.dll',r/'current-core.dll')
catalog=json.loads((r.parent/'lexical-operands-r139/catalog.json').read_text(encoding='utf-8'))
case=next(c for c in catalog['cases'] if c['id']=='scripts.json-summary-helpers.large')
assert case['source']==Path('benchmarks/scripts/json-summary-helpers.py').read_text(encoding='utf-8')
catalog['cases']=[case]
(r/'catalog.json').write_text(json.dumps(catalog,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
digest=hashlib.sha256((r/'current-core.dll').read_bytes()).hexdigest()
proof=dict(coreSHA256=digest,sourceRevision=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),sourceSHA256=identity['productionSources'],proof='Reuse the fresh nonincremental R149 freeze; every production byte verified unchanged after commit. Same frozen common worker/adapter/dependencies. No source restore/runtime performance override.')
(r/'core-source.json').write_text(json.dumps(proof,indent=2)+'\n',encoding='utf-8')
aux=json.loads((freeze/'b504/identity.json').read_text(encoding='utf-8'))['auxiliaryFiles']
(r/'identity.json').write_text(json.dumps(dict(coreSHA256=digest,auxiliaryFiles=aux),indent=2)+'\n',encoding='utf-8')
(r/'selection.md').write_text('''# R150 maintained JSON report attribution

R146 warm JSON-report gap1.37–1.38x CPython is source-labelled65ed. Existing text/search
profiles do not establish its dominant costs. One six-second existing-tool capture on
committed afb11d97/current core6417B97A, unchanged maintained JSON source/fixtures/full
goldens, shared comparison worker/optional adapter, normal GC/tiering (only perf maps).
Separate named guest/caller/host/reset/validation; retain unknown samples/maps/raw.
No elapsed or source-pair speed claim. Select coherent phase deletion only after
actual leaves, with semantic/cancellation/refusal/ownership acceptance and displaced
code named first. No new arena/dispatch/cache/JIT from inclusive shares. Stop after
one usable capture; uncertainty can justify later bounded refinement, not a replay
or permanent design ban. Finite120s service+30stop+30margin, persistent evidence apart
from RAM fixtures; join/unmount/archive under lease/localSHA. Floors/headroom unchanged.
''',encoding='utf-8')
(r/'sizing.json').write_text(json.dumps(dict(cases=1,captureTargetSeconds=6,captureCeilingSeconds=10,ownerSeconds=120,stopSeconds=30,observationMarginSeconds=30),indent=2)+'\n',encoding='utf-8')
with tarfile.open(r/'payload.tgz','w:gz') as archive:
    for name in ['ops-profile.py','analyze-cpu-guest.py','archive.py','run.sh','catalog.json','core-source.json','identity.json','selection.md','sizing.json','current-core.dll']:archive.add(r/name,arcname=name)
print('One unchanged JSON script; verified core',digest,'six-second capture; payload',(r/'payload.tgz').stat().st_size)
