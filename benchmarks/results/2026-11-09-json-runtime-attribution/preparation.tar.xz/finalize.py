from pathlib import Path
import hashlib,json,shutil,tarfile
r=Path(__file__).parent
out=Path('benchmarks/results/2026-11-09-json-runtime-attribution');out.mkdir(exist_ok=True)
proof=json.loads((r/'core-source.json').read_text(encoding='utf-8'))
assert all(hashlib.sha256(Path(name).read_bytes()).hexdigest()==digest for name,digest in proof['sourceSHA256'].items())
receipt=json.loads((r/'archive-receipt.json').read_text(encoding='utf-8'))
assert hashlib.sha256((r/'observations.tgz').read_bytes()).hexdigest()==receipt['archiveSHA256']
data=json.loads((r/'attribution.json').read_text(encoding='utf-8'))[0]
guest=data['groups']['guest'];samples=guest['samples']
summary=dict(sourceRevision=proof['sourceRevision'],coreSHA256=proof['coreSHA256'],workload=data['case'],capturedExecutionSeconds=receipt['capturedSeconds'],guestCpuSeconds=sum(t['seconds'] for t in data['threadCpuSeconds'] if t['name'].startswith('Lython executio')),guestSamples=samples,unknownGuestLeaves=guest['unknownLeaf'],unknownPercent=100*guest['unknownLeaf']/samples,innermostObservedPhases=[dict(phase=phase,samples=count,percent=100*count/samples) for phase,count in guest['observedPhase']],otherGroups={g:d for g,d in data['groups'].items() if g!='guest'},sourceGate=['Instruction loop already reads compact immutable instructions by readonly reference; no ordinary instruction-copy phase selected.','JSON plain strings already bypass backend token reparsing/decoding scratch; shared record keys and completed-value loop already exist.','Default JSON calls already avoid general binding; class-cell binding-only facts intentionally precede final lexical demand.'],decision='One usable capture closes this attribution gap; no new phase deletion selected from inclusive samples. Keep actual prefix/JSON/dictionary/admission/call work distinct; require a concrete current phase and semantic/ownership acceptance before a redesign. No extra capture or permanent design veto.',limits=data['limits'],productionSourceUnchanged=True,performanceQualified=False)
(r/'summary.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8')
for name in ['observations.tgz','attribution.json','summary.json','core-source.json','terminal-status.json','archive-receipt.json']:shutil.copyfile(r/name,out/name)
with tarfile.open(out/'preparation.tar.xz','w:xz') as archive:
    for p in r.iterdir():
        if p.is_file() and p.name not in ['current-core.dll','payload.tgz','observations.tgz']:archive.add(p,arcname=p.name)
print('JSON attribution/source proof archived; no runtime source changes, all users/fixtures ended.')
