# R150 maintained JSON report attribution

R146 warm JSON-report gap1.37–1.38x CPython is source-labelled65ed. Existing text/search
profiles do not establish its dominant costs. One six-second existing-tool capture on
committed afb11d97/current core6417B97A, unchanged maintained JSON source/fixtures/full
goldens, shared comparison worker/optional adapter, normal GC/tiering (only perf maps).
Separate named guest/caller/host/reset/validation; retain unknown samples/maps/raw.
No elapsed or source-pair speed claim. Select coherent phase deletion only after
actual leaves, with semantic/cancellation/refusal/ownership acceptance and displaced
code named first. No new arena/dispatch/cache/JIT from inclusive shares. Stop after
one usable capture; uncertainty can justify later bounded refinement, not a replay
or permanent design ban. Finite120s service+30stop+30margin, persistent evidence apart
from RAM fixtures; join/unmount/archive under lease/localSHA. Floors/headroom unchanged.
