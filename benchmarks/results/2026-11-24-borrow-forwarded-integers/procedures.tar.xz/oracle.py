from pathlib import Path
import hashlib, json, os, shutil, subprocess, textwrap

lab = Path(__file__).resolve().parent
sdk = Path.home() / ".dotnet11"
test_file = lab.parents[3]/"tests/Lokad.Lython.PublicApi.Tests/FunctionDefaultMetadataTests.cs"
test = test_file.read_text(encoding="utf-8-sig").split("ForwardedIntegerKeepsIdentityOnDirectReturnAndAfterDefaultsAreExposed",1)[1]
test = test.split(chr(34)*3)[1]
sources = {
    "direct and exposed defaults":test,
    "module arithmetic and alias": """
        def compute(value, *, add=True):
            return value + 0 if add else value
        def alias(value):
            return value
        for seed in range(900, 904):
            changed = compute(seed)
            retained = alias(seed)
            print(changed == seed, changed is seed, retained is seed)
    """,
    "closed pair and exact integers": """
        def make(index):
            def apply(value, offset=index%7, *, use=True):
                return (value+offset) if use else value
            alternate = lambda value, offset=(index+1)%7: value-offset
            return apply, alternate
        for seed in range(9223372036854775805, 9223372036854775809):
            left,right=make(seed)
            print(left(seed), right(seed))
            left.__kwdefaults__['use']=False
            print(left(seed) is seed)
    """,
    "noninteger full call": """
        class Number:
            def __add__(self, other):
                print('add',other)
                return 321
        def ops(value, *, enabled=True):
            return value + 5 if enabled else value
        def caller(target, value):
            return target(value)
        value = Number()
        print(caller(ops,value))
        ops.__kwdefaults__['enabled'] = False
        print(caller(ops,value) is value)
    """,
    "operation exception and cleanup": """
        def factory(seed):
            first = lambda x, y=seed%7: x+y
            second = lambda x, y=5//seed: x*y
            return first, second
        def work(target):
            first, second = 'a', 'b'
            for index in range(0,3):
                try:
                    first, second = target(index)
                except ZeroDivisionError:
                    print(first,second)
                else:
                    print(first(10),second(10))
        work(factory)
    """,
}
sources = {name: textwrap.dedent(source).strip() + "\n" for name, source in sources.items()}
input_json = json.dumps(list(sources.values()), ensure_ascii=False)
(lab / "oracle-input.json").write_text(json.dumps(sources, ensure_ascii=False, indent=2)+"\n", encoding="utf-8")
env = dict(os.environ, DOTNET_ROOT=str(sdk), DOTNET_ROOT_X64=str(sdk))
donor = lab.with_name("shared-function-defaults-20261124")
manifest = json.loads((lab / "comparison/quiet/identity.json").read_text(encoding="utf-8"))["imageFiles"]
for role in ("reference", "candidate"):
    probe = lab / ("probe-" + role)
    shutil.copytree(donor / ("probe-" + role), probe, dirs_exist_ok=True)
    shutil.copyfile(lab / role / "Lokad.Lython.dll", probe / "Lokad.Lython.dll")
    assert hashlib.sha256((probe / "Lokad.Lython.dll").read_bytes()).hexdigest() == manifest[role]["Lokad.Lython.dll"]
    for mode in ("sync", "async"):
        args = [sdk / "dotnet.exe", probe / "LythonProbe.dll", "--batch-json", "--compare-python", "--python", "C:/Python313/python.exe"]
        if mode == "async": args.append("--async")
        result = subprocess.run(args, env=env, input=input_json, encoding="utf-8", capture_output=True, timeout=45)
        raw = result.stdout
        (lab / f"oracle-{role}-{mode}.jsonl").write_text(raw, encoding="utf-8")
        print(role, mode, result.returncode, result.stderr.strip())
        for (name, _), row in zip(sources.items(), raw.splitlines(), strict=True):
            report = json.loads(row)
            if report["Matches"]: print(" ", name, "match")
            else: print(" ", name, "mismatch", report["Lython"], report["CPython"])
