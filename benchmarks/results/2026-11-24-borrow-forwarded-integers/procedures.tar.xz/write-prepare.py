from pathlib import Path
import hashlib, json, tarfile

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
previous = lab.with_name("shared-function-defaults-20261124")
source = (previous / "prepare.py").read_text(encoding="utf-8")
source = source.replace('donor = lab.with_name("accounted-total-20261124")', 'donor = lab.with_name("shared-function-defaults-20261124")')
start = source.index('jobs = [')
end = source.index('save(expected, fixture)', start)
source = source[:start] + '''jobs = [
    ["scripts.rule-default-closures", "warm"],
    ["scripts.rule-default-closures", "compile-run"],
    ["scripts.annotated-rule-closures", "warm"],
    ["scripts.captured-rule-closures", "warm"],
    ["diagnostic.text-summary.nonlocal-computed-width.large", "warm"],
    ["scripts.csv-invoice.method-policy.quoted-control", "warm"],
]
expected_ids = {case for case, _ in jobs}
expected = quiet / "representative.json"
fixture = read(lab.with_name("forwarded-positional-framed-20261124") / "comparison/quiet/representative.json")
fixture["cases"] = [row for row in fixture["cases"] if row["id"] in expected_ids]
assert {r["id"] for r in fixture["cases"]} == expected_ids
''' + source[end:]
source = source.replace('assert head.startswith("cdaf31164")','assert head.startswith("0c907c166")').replace('"dd17f1eb5", head','"cdaf31164", head')
source = source.replace('b"StoreFunctionDefault"', 'b"CanBorrowForwardedInteger"')
source = source.replace('Share prepared default storage for executable, lowered and generated callables',
                        'Use the original forwarded integer slot in the existing native call entry')
source = source.replace('replace("b1628-fixtures", "b1629-fixtures")','replace("b1629-fixtures", "b1631-fixtures")')
source = source.replace('collector.replace("len(jobs) == 4", "len(jobs) == 7")','collector.replace("len(jobs) == 7", "len(jobs) == 6")')
source = source.replace('root="shared-function-defaults-b1629-20261124",\n    reference="accounted-total-b1628-20261124"',
                        'root="borrow-forwarded-integers-b1631-20261124",\n    reference="shared-function-defaults-b1629-20261124"')
source = source.replace('replace("lython-b1628-accounted-total-", "lython-b1629-shared-function-defaults-").replace("b1628-", "b1629-")',
                        'replace("lython-b1629-shared-function-defaults-", "lython-b1631-borrow-forwarded-integers-").replace("b1629-", "b1631-")')
source = source.replace('oldbase = lab.with_name("regex-operation-dispatch-20261124")','oldbase = lab.with_name("accounted-total-20261124")')
source = source.replace('replace("RuntimeMaxSec=212", "RuntimeMaxSec=310").replace("seconds=133", "seconds=236")',
                        'replace("RuntimeMaxSec=310", "RuntimeMaxSec=270").replace("seconds=236", "seconds=202")')
source = source.replace('verified four CPython goldens','verified five CPython goldens')
compile(source,"prepare.py","exec")
(lab / "prepare.py").write_text(source,encoding="utf-8",newline="\n")

read = lambda p: json.loads(p.read_text(encoding="utf-8-sig"))
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
inventory = read(lab/"available-replicas.json")
by_hash = {entry["archiveSHA256"]:entry for entry in inventory["candidates"]}
replicas = []
for folder in (repo/"benchmarks/results").glob("2026-11-24-*"):
    for archive in folder.rglob("*observations.tar.xz"):
        digest = sha(archive)
        if digest not in by_hash: continue
        entry = by_hash.pop(digest)
        with tarfile.open(archive) as data:
            names = [member for member in data.getmembers() if member.name.endswith("/confirmation.json")]
            if len(names)!=1: continue
            raw = data.extractfile(names[0]).read()
        if len(raw)==entry["bytes"] and hashlib.sha256(raw).hexdigest()==entry["rawSHA256"]:
            replicas.append(entry)
replicas.sort(key=lambda row:row["bytes"],reverse=True)
(lab/"verified-raw-replicas.json").write_text(json.dumps(replicas,indent=2)+"\n",encoding="utf-8")
print("available", inventory["free"], "verified replica bytes", sum(row["bytes"] for row in replicas), "candidate replicas",len(replicas))
