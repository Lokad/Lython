from pathlib import Path
import hashlib, json, subprocess, tarfile

lab=Path(__file__).resolve().parent
repo=lab.parents[4]
out=repo/"benchmarks/results/2026-11-24-borrow-forwarded-integers/cumulative"
quiet=lab/"comparison/quiet"
def read(p): return json.loads(p.read_text(encoding="utf-8-sig"))
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
identity=read(quiet/"identity.json")
prior=read(lab.parent/"comparison/quiet/identity.json")
older=read(lab.parents[1]/"shared-function-defaults-20261124/comparison/quiet/identity.json")
assert identity["imageFiles"]=={"reference":older["imageFiles"]["reference"], "candidate":prior["imageFiles"]["candidate"]}
assert identity["sourceRevision"].startswith("d6a168491") and identity["comparisonRevision"].startswith("cdaf31164")
assert identity["sourcePatchSHA256"]==sha(lab/"combined.patch")
assert (lab/"combined.patch").read_bytes()==subprocess.check_output(
    ["git","diff","--binary", identity["comparisonRevision"],identity["sourceRevision"],"--","src","tests"],cwd=repo)
for role in identity["imageFiles"]:
    proof=read(lab/"comparison"/(role+"-verify.json"))
    assert proof["caseCount"]==2 and proof["state"]=="Completed"
    assert proof["catalogSha256"]==identity["catalogs"]["representative.json"]["sha256"]
    assert proof["launched"]["library"]["sha256"]==identity["coreSHA256"][role]
assert sha(out/"quiet-observations.tar.xz")==read(quiet/"terminal-status.json")["receipt"]["archiveSHA256"]
with tarfile.open(out/"procedures.tar.xz", "w:xz") as archive:
    for name in ("prepare.py","archive.py","archive-quiet.py","quiet.py","verified-raw-replicas.json","combined.patch",
                 "comparison/candidate-verify.json","comparison/reference-verify.json","comparison/quiet/storage-custody.json"):
        archive.add(lab/name,arcname=name,recursive=False)
