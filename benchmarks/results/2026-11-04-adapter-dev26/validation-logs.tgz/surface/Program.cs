using System.Reflection;
using System.Runtime.Loader;
using System.Text.Json;
var path=Path.GetFullPath(args[0]);
AssemblyLoadContext.Default.Resolving+=(_,name)=>AssemblyLoadContext.Default.LoadFromAssemblyPath(Path.Combine(path,name.Name+".dll"));
var assembly=AssemblyLoadContext.Default.LoadFromAssemblyPath(Path.Combine(path,"Lokad.Utf8Regex.PythonRe.dll"));
var type=assembly.GetType("Lokad.Utf8Regex.PythonRe.Utf8PythonRegex",throwOnError:true)!;
var members=type.GetMembers(BindingFlags.Public|BindingFlags.Instance|BindingFlags.Static|BindingFlags.DeclaredOnly).Select(m=>m.ToString()!).Order(StringComparer.Ordinal).ToArray();
Console.WriteLine(JsonSerializer.Serialize(members));
