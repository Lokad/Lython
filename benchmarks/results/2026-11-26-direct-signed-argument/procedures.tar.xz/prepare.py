from pathlib import Path
from statistics import median
import hashlib
import json
import os
import shutil
import subprocess

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
prior = lab.with_name('compiled-default-operands-20261126')
extra = lab.with_name('arithmetic-call-operands-confirmation-20261125')
collector_source = lab.with_name('ready-json-decoder-entry-20261126')

def read(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))

def write(path, value):
    path.write_text(value, encoding='utf-8', newline='\n')

def save(path, value):
    write(path, json.dumps(value, indent=2, ensure_ascii=False)+'\n')

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def hashes(path):
    return {p.name:digest(p) for p in sorted(path.iterdir())}

head = subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()
assert head.startswith('088cf9d37')
patch = subprocess.check_output(['git','diff','--binary','--','src'],cwd=repo)
assert patch.count(b'\ndiff --git ')==2
(lab/'candidate.patch').write_bytes(patch)
owner = read(prior/'local/identity.json')
reference_patch = subprocess.check_output(['git','diff','--binary',owner['sourceRevision'],head,'--','src'],cwd=repo)
assert hashlib.sha256(reference_patch).hexdigest() == owner['sourcePatchSHA256']
donor = prior/'local/candidate'
assert len(owner['imageFiles']['candidate'])==32 and hashes(donor)==owner['imageFiles']['candidate']
local = lab/'local'
local.mkdir()
core = 'Lokad.Lython.dll'
images = {}
for role in ('reference','candidate'):
    image = local/role
    shutil.copytree(donor,image)
    assert hashes(image)==owner['imageFiles']['candidate']
    if role=='candidate':
        shutil.copyfile(repo/'src/Lokad.Lython/bin/Release/net11.0'/core,image/core)
    images[role] = hashes(image)
assert {name for name in images['reference'] if images['reference'][name]!=images['candidate'][name]}=={core}
catalog=read(prior/'local/representative.json')
cases={case['id']:case for case in catalog['cases']}
ordinary='diagnostic.generated-ordinary-definitions'
effects='diagnostic.generated-ordinary-default-effects'
rules='scripts.rule-default-closures'
control='diagnostic.shipment-routing-callbacks'
cases[effects]=next(case for case in read(extra/'comparison/quiet/representative.json')['cases'] if case['id']==effects)
catalog['cases']=[cases[id] for id in (ordinary,effects,rules,control)]
save(local/'representative.json',catalog)
shutil.copyfile(repo/'benchmarks/cpython-worker.py',local/'cpython-worker.py')
assert digest(local/'cpython-worker.py')==owner['cpythonWorkerSHA256']
jobs=[[control,'warm-async'],[ordinary,'warm-async'],[rules,'warm'],[effects,'warm'],[ordinary,'warm']]
save(local/'jobs.json',{'warm':jobs})
identity=dict(sourceRevision=head,sourcePatchSHA256=digest(lab/'candidate.patch'),imageFiles=images,
    coreSHA256={role+suffix:files[core] for role,files in images.items() for suffix in ('','-control')},
    cpythonWorkerSHA256=digest(local/'cpython-worker.py'),catalogs={name:{'sha256':digest(local/name)} for name in ('representative.json','jobs.json')},
    purpose='Test direct transport of the unpublished computed scalar into the existing closed function return.')
save(local/'identity.json',identity)
sdk=Path.home()/'.dotnet11'
dotnet=sdk/'dotnet.exe'
env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk))
allocation_tool=lab.with_name('json-traversal-20261124')/'reference'
allocations={}
for role,files in images.items():
    image=local/role
    proof=lab/(role+'-verify.json')
    subprocess.run([dotnet,image/'Lokad.Lython.Benchmarks.dll','--compare','verify','--catalog',local/'representative.json',
                    '--dotnet',dotnet,'--python','C:/Python313/python.exe','--python-worker',local/'cpython-worker.py','--out',proof],
                   cwd=repo,env=env,check=True,timeout=85)
    report=read(proof)
    assert report['state']=='Completed' and report['caseCount']==4
    assert report['catalogSha256']==identity['catalogs']['representative.json']['sha256']
    assert report['launched']['library']['sha256'].lower()==files[core]
    allocated=lab/(role+'-allocated')
    shutil.copytree(image,allocated)
    assert hashes(allocated)==files
    for executable in allocation_tool.glob('ValidatedAllocation*'):
        shutil.copyfile(executable,allocated/executable.name)
    output=lab/(role+'-allocation.json')
    subprocess.run([dotnet,allocated/'ValidatedAllocation.dll',allocated,local/'representative.json',output],
                   cwd=repo,env=env,check=True,timeout=64)
    allocations[role]=read(output)['rows']
summary=[]
for before,after in zip(allocations['reference'],allocations['candidate'],strict=True):
    assert before['id']==after['id'] and before['sharedBudgetBaselineRestored'] and after['sharedBudgetBaselineRestored']
    summary.append(dict(case=before['id'],bytes=[median(row['allocatedBytesPerInvocation']) for row in (before,after)],
                        peak=[row['peakExecutionMemoryBytes'] for row in (before,after)]))
save(lab/'allocation-summary.json',summary)
print(json.dumps(summary))
collector=(collector_source/'local/collect.py').read_text(encoding='utf-8')
for old,new in [('len(jobs) == 4','len(jobs) == 5'),('accumulate 4 seconds','accumulate 3 seconds'),
    ('warmupSeconds=4, targetBatchSeconds=.35','warmupSeconds=3, targetBatchSeconds=.36'),
    ('lython-json-ready-fixture-','lython-direct-signed-argument-fixture-')]:
    assert collector.count(old)==1
    collector=collector.replace(old,new)
compile(collector,'collect.py','exec')
write(local/'collect.py',collector)
shutil.copyfile(collector_source/'local/run.sh',local/'run.sh')
runner=(prior/'run-local.sh').read_text(encoding='utf-8').replace(prior.name,lab.name)
write(lab/'run-local.sh',runner)
assert all(b'\r' not in p.read_bytes() for p in (lab/'run-local.sh',local/'run.sh'))
summary=(collector_source/'summarize.py').read_text(encoding='utf-8').replace('== 4','== 5').replace('timedBatches=112','timedBatches=140')
compile(summary,'summarize.py','exec')
write(lab/'summarize.py',summary)
