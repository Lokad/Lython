from pathlib import Path
import hashlib
import json
import shutil
import tarfile

lab=Path(__file__).resolve().parent
local=lab/'local'
prior=lab.with_name('compiled-default-operands-20261126')
template=lab.with_name('prepared-machine-constants-20261126')
quiet=lab/'comparison/quiet'
quiet.mkdir(parents=True)
read=lambda p:json.loads(p.read_text(encoding='utf-8'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
write=lambda p,t:p.write_text(t,encoding='utf-8',newline='\n')
save=lambda p,v:write(p,json.dumps(v,indent=2)+'\n')
identity=read(local/'identity.json')
assert sha(lab/'candidate.patch')==identity['sourcePatchSHA256']
for role,files in identity['imageFiles'].items():
    assert len(files)==32 and {p.name:sha(p) for p in (local/role).iterdir()}==files
    smoke=read(lab/(role+'-verify.json'))
    assert smoke['state']=='Completed' and smoke['caseCount']==4
    assert smoke['catalogSha256']==identity['catalogs']['representative.json']['sha256']
    assert smoke['launched']['library']['sha256'].lower()==files['Lokad.Lython.dll']
donor=prior/'comparison/quiet'
donor_identity=read(donor/'identity.json')
assert identity['imageFiles']['reference']==donor_identity['imageFiles']['candidate']
receipt=read(donor/'terminal-status.json')['receipt']
assert receipt['complete'] and receipt['quietBeforeAndAfter'] and receipt['archiveSHA256']==sha(donor/'observations.tar.xz')
identity['expectedCPythonSHA256']=donor_identity['expectedCPythonSHA256']
identity['purpose']='Quiet confirmation of direct transport of the unpublished computed integer into the existing closed return.'
for name in ('jobs.json','representative.json','cpython-worker.py'):
    shutil.copyfile(local/name,quiet/name)
assert sha(quiet/'cpython-worker.py')==identity['cpythonWorkerSHA256']
assert all(sha(quiet/name)==meta['sha256'] for name,meta in identity['catalogs'].items())
save(quiet/'identity.json',identity)
collector=(donor/'collect.py').read_text(encoding='utf-8')
assert collector.count('lython-b1773-fixtures')==1 and 'len(jobs) == 5' in collector
collector=collector.replace('lython-b1773-fixtures','lython-b1775-fixtures')
compile(collector,'collect.py','exec')
write(quiet/'collect.py',collector)
shutil.copyfile(donor/'run.sh',quiet/'run.sh')
assert b'\r' not in (quiet/'run.sh').read_bytes()
package=quiet/'stage.tar.gz'
entries=[('new-core.dll',local/'candidate/Lokad.Lython.dll')]
entries.extend((name,quiet/name) for name in ('identity.json','representative.json','jobs.json','collect.py','run.sh','cpython-worker.py'))
with tarfile.open(package,'w:gz',compresslevel=6) as archive:
    for name,path in entries: archive.add(path,arcname=name,recursive=False)
save(quiet/'upload.json',dict(root='direct-signed-argument-b1775-20261126',payloadSHA256=sha(package),
    payloadBytes=package.stat().st_size,expandedBytes=sum(p.stat().st_size for _,p in entries),donorSHA256=receipt['archiveSHA256']))
launcher=(template/'quiet.py').read_text(encoding='utf-8')
for before,after in [('lython-b1770-prepared-constants-20261126','lython-b1775-direct-signed-argument-20261126'),
    ('boolean-increments-b1766-20261126','compiled-default-operands-b1773-20261126'),
    ('RuntimeMaxSec=325','RuntimeMaxSec=285'),('seconds=241','seconds=205')]:
    assert launcher.count(before)==1,before
    launcher=launcher.replace(before,after)
compile(launcher,'quiet.py','exec')
write(lab/'quiet.py',launcher)
shutil.copyfile(prior/'summarize-quiet.py',lab/'summarize-quiet.py')
shutil.copyfile(prior/'compact-for-quiet.py',lab/'compact-for-quiet.py')
