set -eu
root=/home/lokad/lython-bench-checks/parser-endpoint-spans-b1268-20261121
trap 'result=$?; printf "%s\n" "$result" > "$root/exit-code.txt"' EXIT
python3 "$root/collect.py"
