set -euo pipefail
cd /mnt/d/code/Lython/.git/agent-worktrees/compiler-construction-20261121
export DOTNET_ROOT="$HOME/.dotnet"
export PATH="$DOTNET_ROOT:$PATH"
logs=/mnt/d/code/Lython/.git/agent-notes/review-20261031/parser-endpoint-spans
dotnet build tools/LythonProbe/LythonProbe.csproj -c Release -f net10.0 | tee "$logs/probe-ubuntu.log"
dotnet test tests/Lokad.Lython.Tests -c Release -f net10.0 --filter '(FullyQualifiedName~Parser|FullyQualifiedName~Syntax|FullyQualifiedName~FormattedString|FullyQualifiedName~ExecutableInstruction|FullyQualifiedName~ExecutableStackAdmission|FullyQualifiedName~CompilationLifetime|FullyQualifiedName~ProtectedLoop|FullyQualifiedName~TokenSourceCoordinates)&Category!=Stress' | tee "$logs/white-ubuntu.log"
dotnet test tests/Lokad.Lython.PublicApi.Tests -c Release -f net10.0 --filter '(FullyQualifiedName~Parser|FullyQualifiedName~Syntax|FullyQualifiedName~Formatted|FullyQualifiedName~Assignment|FullyQualifiedName~Pattern|FullyQualifiedName~ChainedComparison|FullyQualifiedName~ErrorSpan|FullyQualifiedName~Diagnostic|FullyQualifiedName~CompilerCancellation)&Category!=Stress' | tee "$logs/public-ubuntu.log"
