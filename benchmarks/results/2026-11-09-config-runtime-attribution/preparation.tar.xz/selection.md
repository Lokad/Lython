# R160 current configuration attribution

One six-second on-CPU capture of the unchanged maintained 181B config edit.
Reuse R159's fully qualified 7c10322c-equivalent/corecfeb freeze, exact current
production bytes checked before any subsequent changes. Two-phase comparison
R159 already complete; this is attribution, not another speed comparison.
Separate guest, caller/reset/protocol, tiering and unknowns. CPU samples cannot
explain off-CPU scheduling. No new performance runtime override except perf maps.
After usable attribution, bound the source gate to20min and select actual displaced
work before a redesign; otherwise record uncertainty and move to another family.
Preserve mutable types, current tokens, shared-budget owners, refusal and cleanup.
Finite120s owner+30stop+30margin, persistent raw, joined users and archive under
lease, RAM unmounted, local archive SHA verified. No speculative storage cleanup.
