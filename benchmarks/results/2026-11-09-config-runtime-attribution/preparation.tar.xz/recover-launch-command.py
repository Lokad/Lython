from pathlib import Path
import ast,fcntl,hashlib,json,os,shutil,subprocess,sys
base=Path('/home/lokad/lython-bench-checks');root=base/'config-runtime-b510-20261109'
with (base/'comparison-vm.lock').open('a') as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert not Path('/dev/shm/lython-b510').exists()
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record|[o]ps-profile.py'],capture_output=True).returncode==1
 assert hashlib.sha256((root/'identity.json').read_bytes()).hexdigest()=='dc28c9f8f5df6f37502353784cf7de785fe272e6b58d76da0104bb15d9830844'
 data=sys.stdin.buffer.read();assert hashlib.sha256(data).hexdigest()=='03d1163482118231fc93b67fa6da77d8c81323e6b2ae055bb8a146e35d66227e'
 (root/'identity-original.json').write_bytes((root/'identity.json').read_bytes())
 (root/'identity.json').write_bytes(data)
 identity=json.loads((root/'identity.json').read_text())
 for name,digest in {**identity['auxiliaryFiles'],'Lokad.Lython.dll':identity['coreSHA256']}.items():
  assert hashlib.sha256((root/'candidate'/name).read_bytes()).hexdigest()==digest
 for name in ['ops-profile.py','analyze-cpu-guest.py','archive.py']:ast.parse((root/name).read_text())
 subprocess.run(['/bin/sh','-n',str(root/'run.sh')],check=True)
 fixture=Path('/dev/shm/lython-b510');fixture.mkdir()
 subprocess.run(['sudo','-n','mount','-t','tmpfs','-o','size=128m,mode=0700,uid=lokad,gid=lokad','lython-b510-fixtures',str(fixture)],check=True)
 setup=dict(freeBytes=shutil.disk_usage(base).free,coreAndAuxiliaryImagesVerified=True,
  ownerSeconds=120,stopSeconds=30,observationMarginSeconds=30,osFloorMiB=240,traceArchiveHeadroomMiB=12)
 (root/'setup.json').write_text(json.dumps(setup,indent=2)+'\n');print(json.dumps(setup),flush=True)
try:
 subprocess.run(['sudo','-n','systemd-run','--unit=lython-b510-config-runtime-20261109',
  '--property=User=lokad','--property=WorkingDirectory='+str(root),'--property=RuntimeMaxSec=120',
  '--property=TimeoutStopSec=30','--property=KillMode=control-group','/bin/sh',str(root/'run.sh')],check=True)
except BaseException:
 subprocess.run(['sudo','-n','umount',str(fixture)],check=True);fixture.rmdir();raise
