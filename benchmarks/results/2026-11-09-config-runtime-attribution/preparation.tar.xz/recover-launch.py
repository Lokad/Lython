from pathlib import Path
import datetime,hashlib,json,shlex,subprocess
r=Path(__file__).parent
old=(r/'identity.json').read_bytes();i=json.loads(old);assert set(i['coreSHA256'])=={'candidate','candidate-control'}
assert i['coreSHA256']['candidate']==i['coreSHA256']['candidate-control'];i['coreSHA256']=i['coreSHA256']['candidate']
new=(json.dumps(i,indent=2)+'\n').encode('utf-8')
(r/'identity-original.json').write_bytes(old);(r/'identity.json').write_bytes(new)
original=(r/'launch-command.py').read_text(encoding='utf-8')
tail=original[original.index(' identity=json.loads'):]
remote='''from pathlib import Path
import ast,fcntl,hashlib,json,os,shutil,subprocess,sys
base=Path('/home/lokad/lython-bench-checks');root=base/'config-runtime-b510-20261109'
with (base/'comparison-vm.lock').open('a') as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert not Path('/dev/shm/lython-b510').exists()
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record|[o]ps-profile.py'],capture_output=True).returncode==1
 assert hashlib.sha256((root/'identity.json').read_bytes()).hexdigest()=='OLD'
 data=sys.stdin.buffer.read();assert hashlib.sha256(data).hexdigest()=='NEW'
 (root/'identity-original.json').write_bytes((root/'identity.json').read_bytes())
 (root/'identity.json').write_bytes(data)
'''.replace('OLD',hashlib.sha256(old).hexdigest()).replace('NEW',hashlib.sha256(new).hexdigest())+tail
compile(remote,'recovery','exec');(r/'recover-launch-command.py').write_text(remote,encoding='utf-8')
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
stage='/home/lokad/lython-bench-checks/config-runtime-b510-recover.py'
code='from pathlib import Path;import sys;p=Path('+repr(stage)+');assert not p.exists();p.write_bytes(sys.stdin.buffer.read())'
x=subprocess.run(ssh+['python3 -c '+shlex.quote(code)],input=remote.encode(),capture_output=True);assert x.returncode==0,x.stderr
x=subprocess.run(ssh+['python3 '+stage],input=new,capture_output=True)
(r/'recover-launch.log').write_bytes(x.stdout+b'\n'+x.stderr);print((x.stdout+x.stderr).decode(),flush=True);assert x.returncode==0
now=datetime.datetime.now(datetime.timezone.utc)
(r/'observe-not-before.json').write_text(json.dumps(dict(acknowledgedUTC=now.isoformat(),doNotObserveBeforeUTC=(now+datetime.timedelta(seconds=180)).isoformat(),ownerSeconds=120,stopSeconds=30,marginSeconds=30),indent=2)+'\n',encoding='utf-8')
print('Observe after',now+datetime.timedelta(seconds=180))
