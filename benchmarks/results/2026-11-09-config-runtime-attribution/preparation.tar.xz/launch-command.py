from pathlib import Path
import ast,fcntl,hashlib,io,json,os,shutil,subprocess,sys,tarfile
base=Path('/home/lokad/lython-bench-checks');root=base/'config-runtime-b510-20261109'
source=(base/'config-boundary-b509-20261109/candidate').resolve()
with (base/'comparison-vm.lock').open('a') as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert not root.exists() and not Path('/dev/shm/lython-b510').exists()
 assert not list(Path('/dev/shm').glob('lython-comparison-files-*'))
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record|[o]ps-profile.py'],capture_output=True).returncode==1
 payload=sys.stdin.buffer.read(1914231+1)
 assert len(payload)==1914231 and hashlib.sha256(payload).hexdigest()=='80cf8e04366e7b828a48e77cbe173c58182c310646e06f7b0f9b9c0c61eb11bd'
 with tarfile.open(fileobj=io.BytesIO(payload),mode='r:gz') as a:
  assert shutil.disk_usage(base).free>sum(((m.size+4095)//4096)*4096 for m in a.getmembers())+(240+12)*1024*1024
  root.mkdir();a.extractall(root,filter='data')
 proof=json.loads((root/'core-source.json').read_text())
 assert hashlib.sha256((root/'current-core.dll').read_bytes()).hexdigest()==proof['coreSHA256']
 shutil.copytree(source,root/'candidate',copy_function=os.link)
 (root/'candidate/Lokad.Lython.dll').unlink();os.link(root/'current-core.dll',root/'candidate/Lokad.Lython.dll')
 identity=json.loads((root/'identity.json').read_text())
 for name,digest in {**identity['auxiliaryFiles'],'Lokad.Lython.dll':identity['coreSHA256']}.items():
  assert hashlib.sha256((root/'candidate'/name).read_bytes()).hexdigest()==digest
 for name in ['ops-profile.py','analyze-cpu-guest.py','archive.py']:ast.parse((root/name).read_text())
 subprocess.run(['/bin/sh','-n',str(root/'run.sh')],check=True)
 fixture=Path('/dev/shm/lython-b510');fixture.mkdir()
 subprocess.run(['sudo','-n','mount','-t','tmpfs','-o','size=128m,mode=0700,uid=lokad,gid=lokad','lython-b510-fixtures',str(fixture)],check=True)
 setup=dict(freeBytes=shutil.disk_usage(base).free,coreAndAuxiliaryImagesVerified=True,
  ownerSeconds=120,stopSeconds=30,observationMarginSeconds=30,osFloorMiB=240,traceArchiveHeadroomMiB=12)
 (root/'setup.json').write_text(json.dumps(setup,indent=2)+'\n');print(json.dumps(setup),flush=True)
try:
 subprocess.run(['sudo','-n','systemd-run','--unit=lython-b510-config-runtime-20261109',
  '--property=User=lokad','--property=WorkingDirectory='+str(root),'--property=RuntimeMaxSec=120',
  '--property=TimeoutStopSec=30','--property=KillMode=control-group','/bin/sh',str(root/'run.sh')],check=True)
except BaseException:
 subprocess.run(['sudo','-n','umount',str(fixture)],check=True);fixture.rmdir();raise
