set -eu
root=/home/lokad/lython-bench-checks/captured-factory-delivery-cpython-b1208-20261120
trap 'result=$?; printf "%s\n" "$result" > "$root/exit-code.txt"' EXIT
python3 "$root/collect.py"
