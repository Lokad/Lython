#!/bin/bash
set -euo pipefail
cd /mnt/d/code/Lython
lab=.git/agent-notes/review-20261031/closed-scalar-b1976-20261128
dotnet="$HOME/.dotnet/dotnet"
unset DOTNET_BUNDLE_EXTRACT_BASE_DIR
"$dotnet" test tests/Lokad.Lython.PublicApi.Tests -c Release -f net11.0 --artifacts-path "$lab/ubuntu-tests" \
  --filter 'Category!=Stress&(FullyQualifiedName~NativeGeneratorSum|FullyQualifiedName~NativeReturnFunction|FullyQualifiedName~NativeScalarDispatch|FullyQualifiedName~Arithmetic|FullyQualifiedName~Matrix|FullyQualifiedName~IntegerPayload|FullyQualifiedName~IntegerAlias|FullyQualifiedName~AdmissionFailureCommandTests)' > "$lab/ubuntu-net11.0-public.log" 2>&1
"$dotnet" test tests/Lokad.Lython.Tests -c Release -f net11.0 --artifacts-path "$lab/ubuntu-tests" \
  --filter 'Category!=Stress&(FullyQualifiedName~IntegerBinaryAdmission|FullyQualifiedName~IntegerAdditionAdmission|FullyQualifiedName~ExactIntegerUnaryAdmission|FullyQualifiedName~NativeIntegerChain|FullyQualifiedName~ExecutableAugmentedIntegerBoundary|FullyQualifiedName~DirectOperandOwnership|FullyQualifiedName~ExecutableStackAdmission)' > "$lab/ubuntu-net11.0-whitebox.log" 2>&1