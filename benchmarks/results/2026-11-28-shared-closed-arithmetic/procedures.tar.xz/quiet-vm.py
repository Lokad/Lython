from datetime import datetime, timezone
from pathlib import Path
from hashlib import sha256
import json
import shlex
import subprocess
import sys

lab=Path(__file__).resolve().parent
quiet=lab/'comparison/quiet'
configuration=json.loads((quiet/'upload.json').read_text(encoding='utf-8'))
configuration.update(base='/home/lokad/lython-bench-checks',unit='lython-b1976-closed-scalar')
vm='lokad@20.166.121.73'
common=['-i',str(Path.home()/'.ssh/id_lython-bench.pem'),'-o','BatchMode=yes','-o','IdentitiesOnly=yes','-o','ConnectTimeout=12','-o','StrictHostKeyChecking=yes']
prefix='cfg='+repr(configuration)+'''
from pathlib import Path
import fcntl,hashlib,tarfile,json,os,shutil,stat,subprocess,sys
base=Path(cfg['base'])
root=base/cfg['root']
unit=cfg['unit']
assert root.resolve()==root and root.parent==base and base.resolve()==base
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def snapshot(folder):
 return {path.relative_to(folder).as_posix():sha(path) for path in folder.rglob('*') if path.is_file()}
'''
def invoke(code, *, stream=None, timeout=50):
    command=['ssh',*common,vm,'python3 -c '+shlex.quote(prefix+code)]
    compile(prefix+code,'<remote checkpoint>','exec')
    result=subprocess.run(command,stdin=stream,capture_output=True,timeout=timeout)
    if result.returncode:
        sys.stderr.buffer.write(result.stderr)
        sys.stderr.buffer.write(result.stdout)
        raise RuntimeError(f'Remote checkpoint command failed with exit status {result.returncode}.')
    return result.stdout.decode('utf-8')

if sys.argv[1]=='launch':
    payload=quiet/'stage.tar.gz'
    assert sha256(payload.read_bytes()).hexdigest()==configuration['payloadSHA256']
    with payload.open('rb') as stream:
        staged=invoke(r'''
with (base/'comparison-vm.lock').open('r') as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert not root.exists() and not any(p.is_mount() for p in base.glob('*/guest-fixtures'))
 donor=base/cfg['donor']
 origin=(donor/'candidate').resolve(strict=True)
 assert origin==donor/'candidate' and donor.resolve()==donor and donor.parent==base
 receipt=json.loads((donor/'archive-receipt.json').read_text())
 assert receipt['complete'] and receipt['allWorkersJoined']
 assert receipt['archiveSHA256']==cfg['donorArchive']==sha(donor/'observations.tar.xz')
 assert {p.name:sha(p) for p in origin.iterdir()}==cfg['donorFiles']
 python=Path.home()/'lython-bench-toolchains/cpython/3.13.16/bin/python3.13'
 dotnet=Path.home()/'lython-bench-toolchains/dotnet/11.0.100-rc.3.26522.148/dotnet'
 before=shutil.disk_usage(base).free
 floor=cfg['expandedBytes']+cfg['minimumAfterStageBytes']+400000
 assert before>=floor,(before,floor)
 cleared=before
 root.mkdir()
 for role in ('reference','candidate'):
  (root/role).mkdir()
 seen=set()
 with tarfile.open(fileobj=sys.stdin.buffer,mode='r|gz') as package:
  for member in package:
   assert member.isfile() and member.name in cfg['files'] and member.name not in seen
   expected=cfg['files'][member.name]
   assert member.size==expected['length']
   target=root/member.name
   with package.extractfile(member) as source, target.open('xb') as destination:
    shutil.copyfileobj(source,destination)
   assert sha(target)==expected['sha256']
   seen.add(member.name)
 assert seen==set(cfg['files'])
 image=json.loads((root/'identity.json').read_text())
 assert image['donorArchiveSHA256']==cfg['donorArchive']
 reused={'donor':0,'paired':0}
 for role in ('candidate','reference'):
  files=image['imageFiles'][role]
  target=root/role
  assert len(files)==32
  for name,digest in files.items():
   if (target/name).exists():
    assert role+'/'+name in cfg['files'] and sha(target/name)==digest
    continue
   if cfg['donorFiles'][name]==digest:
    os.link(origin/name,target/name)
    reused['donor']+=1
   else:
    alternate=root/'candidate'/name
    assert role=='reference' and sha(alternate)==digest
    os.link(alternate,target/name)
    reused['paired']+=1
  assert {p.name:sha(p) for p in target.iterdir()}==files
 assert sha(python)==image['expectedCPythonSHA256']
 for name,content in image['catalogs'].items(): assert sha(root/name)==content['sha256']
 assert sha(root/'cpython-worker.py')==image['cpythonWorkerSHA256']
 assert b'\r' not in (root/'run.sh').read_bytes()
 for role,files in image['imageFiles'].items():
  verification=root/f'{role}-remote-verify.json'
  subprocess.run([dotnet,root/role/'Lokad.Lython.Benchmarks.dll','--compare','verify',
   '--catalog',root/'representative.json','--dotnet',dotnet,'--python',python,
   '--python-worker',root/'cpython-worker.py','--out',verification],
   env=dict(os.environ,DOTNET_ROOT=str(dotnet.parent)),check=True,timeout=35)
  proof=json.loads(verification.read_text())
  assert proof['state']=='Completed' and proof['caseCount']==cfg['caseCount']
  assert proof['catalogSha256']==image['catalogs']['representative.json']['sha256']
  assert proof['launched']['library']['sha256']==files['Lokad.Lython.dll']
  assert proof['launched']['adapter']['sha256']==files['Lokad.Lython.Benchmarks.dll']
 after=shutil.disk_usage(base).free
 assert after>=cfg['minimumAfterStageBytes']
 custody=dict(before=before,afterReclaim=cleared,afterStaging=after,
   requiredBeforeStage=floor,deduplicated=[],expandedBytes=cfg['expandedBytes'],reused=reused,streamed=True)
 (root/'stage-custody.json').write_text(json.dumps(custody,indent=2)+'\n')
 print(json.dumps(custody),flush=True)
subprocess.run(['sudo','-n','systemd-run','--unit='+unit,'--property=User=lokad','--property=WorkingDirectory='+str(root),
 '--property=RuntimeMaxSec=250','--property=TimeoutStopSec=20','--property=KillMode=control-group',
 '/bin/sh',str(root/'run.sh')],check=True)
''',stream=stream,timeout=95)
    (quiet/'launch.log').write_text(staged,encoding='utf-8')
    print(staged)
else:
    assert sys.argv[1]=='retrieve'
    status=invoke(r'''
state=subprocess.run(['systemctl','show',unit+'.service','--property=ActiveState,SubState,MainPID,Result,ExecMainStatus'],capture_output=True,text=True).stdout
if 'ActiveState=active' in state or 'ActiveState=activating' in state:
 print(json.dumps(dict(live=True,service=state)))
else:
 with (base/'comparison-vm.lock').open('r') as lease:
  fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
  receipt=root/'archive-receipt.json'
  code=root/'exit-code.txt'
  print(json.dumps(dict(live=False,service=state,exitCode=code.read_text().strip() if code.exists() else None,
   receipt=json.loads(receipt.read_text()) if receipt.exists() else None,fixtures=(root/'guest-fixtures').exists(),
   journal=subprocess.run(['journalctl','-u',unit+'.service','-n','38','--no-pager'],capture_output=True,text=True).stdout)))
''')
    state=json.loads(status)
    (quiet/f'status-{datetime.now(timezone.utc):%H%M%S}.json').write_text(status,encoding='utf-8')
    if not state['live']:
        (quiet/'terminal-status.json').write_text(status,encoding='utf-8')
        if state['receipt']:
            names=['observations.tar.xz','reference-remote-verify.json','candidate-remote-verify.json','stage-custody.json']
            source=configuration['base']+'/'+configuration['root']
            subprocess.run(['scp',*common,*[vm+':'+source+'/'+name for name in names],quiet],check=True,timeout=45)
            assert sha256((quiet/names[0]).read_bytes()).hexdigest()==state['receipt']['archiveSHA256']
            (quiet/'archive-receipt.json').write_text(json.dumps(state['receipt'],indent=2)+'\n',encoding='utf-8')
            (quiet/'exit-code.txt').write_text(str(state['exitCode'])+'\n',encoding='utf-8')
    print(json.dumps({k:v for k,v in state.items() if k!='journal'}))