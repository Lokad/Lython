from hashlib import sha256
from pathlib import Path
from shutil import copy2
import json
import tarfile

lab = Path(__file__).resolve().parent
out = lab.parents[3] / 'benchmarks/results/2026-11-28-shared-closed-arithmetic'
pair = lab / 'comparison'
quiet = pair / 'quiet'
read = lambda path: json.loads(path.read_bytes())
digest = lambda path: sha256(path.read_bytes()).hexdigest()

identity = read(quiet / 'identity.json')
assert identity['sourcePatchSHA256'] == digest(lab / 'candidate.patch')
assert identity['imageFiles'] == read(pair / 'identity.json')['imageFiles']
for role, files in identity['imageFiles'].items():
    assert {path.name: digest(path) for path in (pair / role).iterdir()} == files
    assert read(pair / f'{role}-verify.json')['caseCount'] == 8
    layout = read(lab / f'{role}-layout.json')
    assert layout['core'] == files['Lokad.Lython.dll']
    assert layout['catalog'] == identity['catalogs']['representative.json']['sha256']
    capacities = {case['id']: next(entry['capacity'] for entry in case['layouts'] if entry['name'] == '<genexpr>')
                  for case in layout['observations'] if case['id'].endswith('generator-power')}
    assert capacities == {'diagnostic.shipment-row-generator-power': 7, 'diagnostic.shipment-row-wide-generator-power': 31}

summary = read(quiet / 'summary.json')
assert summary['verifiedTimedBatches'] == 112 and summary['quietGates']
receipt = read(quiet / 'archive-receipt.json')
assert receipt['complete'] and receipt['allWorkersJoined'] and receipt['guestFixturesRemoved']
assert receipt['archiveSHA256'] == digest(quiet / 'observations.tar.xz')
allocation = read(lab / 'allocation/summary.json')
admission = read(lab / 'admission/summary.json')
assert len(allocation) == len(admission) == 16
assert all(row['compiled'][0] == row['compiled'][1] and row['admittedPeak'][0] == row['admittedPeak'][1] for row in allocation)
assert all(row['requests'][0] == row['requests'][1] and row['peak'][0] == row['peak'][1] for row in admission)
for row in allocation:
    difference = row['clr'][0] - row['clr'][1]
    if row['case'] == 'diagnostic.shipment-row-generator-power':
        assert 278_000 < difference < 279_000
    elif 'aliases' in row['case']:
        assert difference == 0
    else:
        assert abs(difference) < 256
for target in ('windows-net10.0', 'windows-net11.0', 'ubuntu-net11.0'):
    for suite, count in (('public', 630), ('whitebox', 120)):
        log = lab / f'{target}-{suite}.log'
        assert f'Passed: {count:5d}' in log.read_text(encoding='utf-8')
        assert 'Failed:     0' in log.read_text(encoding='utf-8')
assert 'Failed:     0, Passed:   709' in (lab / 'windows-supplemental.log').read_text(encoding='utf-8')

out.mkdir(exist_ok=True)
public = {name: quiet / name for name in ('identity.json', 'summary.json', 'observations.tar.xz', 'terminal-status.json')}
public.update({f'{category}-summary.json': lab / category / 'summary.json' for category in ('allocation', 'admission')})
for name, path in public.items():
    copy2(path, out / name)
    assert digest(out / name) == digest(path)

procedures = {path.name: path for path in lab.iterdir() if path.is_file()
              and path.suffix in ('.log', '.py', '.patch', '.sh', '.json')}
for category in ('allocation', 'admission'):
    procedures.update({f'{category}/{path.name}': path for path in (lab / category).glob('*.json')})
for folder, location in ((pair, 'local'), (quiet, 'quiet')):
    procedures.update({f'{location}/{path.name}': path for path in folder.iterdir() if path.name.endswith('-verify.json')})
for name in ('archive-receipt.json', 'stage-custody.json', 'launch.log'):
    procedures[f'quiet/{name}'] = quiet / name
with tarfile.open(out / 'procedures.tar.xz', 'w:xz') as archive:
    for name, path in procedures.items():
        archive.add(path, arcname=name)
with tarfile.open(out / 'procedures.tar.xz') as archive:
    assert all(sha256(archive.extractfile(name).read()).hexdigest() == digest(path)
               for name, path in procedures.items())
print('Verified six focused suites, supplemental coverage, exact layouts and 112 quiet batches.')