from pathlib import Path
import subprocess
import sys

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
base = subprocess.check_output(["git", "rev-parse", sys.argv[1]], cwd=repo, text=True).strip()
previous = lab.with_name("executable-lambda-headers-20261125")
pair = lab.with_name("pair-only-rollback-20261125")
initial = lab.with_name("callable-owned-rollback-20261125")
jobs = [
    ("diagnostic.shipment-file-fed-map", "warm-async"),
    ("scripts.csv-invoice.method-policy.quoted-control", "warm"),
    ("diagnostic.shipment-routing-callbacks", "warm-async"),
    ("diagnostic.text-summary.nonlocal-computed-width.large", "warm"),
    ("diagnostic.shipment-file-fed-map", "warm"),
    ("scripts.csv-invoice.method-policy.quoted-control", "warm-async"),
    ("diagnostic.shipment-routing-callbacks", "warm"),
    ("diagnostic.invoice-plain-reader", "warm"),
]

def edit(source, name, substitutions):
    text = source.read_text(encoding="utf-8")
    for before, after in substitutions:
        assert before in text, before
        text = text.replace(before, after)
    compile(text, name, "exec")
    (lab / name).write_text(text, encoding="utf-8", newline="\n")

freeze = previous / "freeze.py"
original = freeze.read_text(encoding="utf-8")
start = original.index("jobs = [")
stop = original.index("catalog = ", start)
edit(freeze, "freeze.py", [
    ("repo = lab.parents[3]", 'repo = lab.parents[3]\nworktree = repo / ".git/agent-worktrees/dictreader-completed-rows-20261125"'),
    ('"borrowed-builtin-bindings-20261125"', '"pair-only-rollback-20261125"'),
    ('"closed-default-store-links-20261125"', '"native-dictionary-prepared-consumers-20261125"'),
    ('git("rev-parse", "0a8952725")', f'git("rev-parse", "{base}")'),
    ('paths = git("diff", "--name-only", "--", "src").decode().splitlines()', '''def candidate_diff(*args):
    return subprocess.check_output(["git", "diff", *args, base, "--", "src"], cwd=worktree)

paths = candidate_diff("--name-only").decode().splitlines()'''),
    ('assert len(paths) == 6 and all(path.startswith("src/Lokad.Lython/Frontend/") for path in paths), paths',
     'assert paths == ["src/Lokad.Lython/Runtime/LythonRuntime.CsvObjects.cs"], paths'),
    ('git("diff", "--binary", "--", "src")', 'candidate_diff("--binary")'),
    ('shutil.copyfile(repo / path, frozen / path)', 'shutil.copyfile(worktree / path, frozen / path)'),
    ('(repo / name).read_bytes() if role == "candidate"', '(worktree / name).read_bytes() if role == "candidate"'),
    (original[start:stop], "jobs = " + repr(jobs) + "\n"),
    ('assert len(catalog["cases"]) == 4', 'assert len(catalog["cases"]) == 5'),
    ('report["caseCount"] == 4', 'report["caseCount"] == 5'),
    ('Skip unused lowered lambda headers and prepare one executable body',
     'Complete buffered DictReader rows without unconditional asynchronous state machines'),
])
edit(previous / "prepare.py", "prepare.py", [
    ('"borrowed-builtin-bindings-20261125"', '"pair-only-rollback-20261125"'),
    ('verified["caseCount"] == 4', 'verified["caseCount"] == 5'),
    ('.replace("len(jobs) == 8", "len(jobs) == 6")', ''),
    ('"b1711-fixtures", "b1716-fixtures"', '"b1711-fixtures", "b1718-fixtures"'),
    ('"started < 315"', '"started < 360"'),
    ('"lython-b1715-borrowed-builtin-bindings", "lython-b1716-executable-lambda-headers"',
     '"lython-b1717c-pair-only-rollback", "lython-b1718-dictreader-completed-rows"'),
    ('launcher.replace("b1715", "b1716").replace("if name==\'Lokad.Lython.dll\' and role==\'candidate\':", "if name==\'Lokad.Lython.dll\':")',
     'launcher.replace("b1717c", "b1718").replace("if name==\'Lokad.Lython.dll\' and role==\'candidate\':", "if name==\'Lokad.Lython.dll\':")'),
    ('"RuntimeMaxSec=382", "RuntimeMaxSec=332"', '"RuntimeMaxSec=270", "RuntimeMaxSec=390"'),
    ('"seconds=300", "seconds=240"', '"seconds=216", "seconds=305"'),
    ('root="executable-lambda-headers-b1716-20261125"', 'root="dictreader-completed-rows-b1718-20261125"'),
    ('reference="borrowed-builtin-bindings-b1715-20261125"', 'reference="pair-only-rollback-b1717c-20261125"'),
])
edit(initial / "package.py", "package.py", [
    ('2026-11-25-callable-owned-rollback', '2026-11-25-dictreader-completed-rows'),
    ('"derive.py", "freeze.py", "prepare.py"', '"prepare-csv.py", "freeze.py", "prepare.py"'),
    ('"candidate.patch", "candidate-build.log",', '"candidate.patch", "reference-build.log", "candidate-build.log",'),
    ('"probe-build.log", "wide-defaults.py", "probe-sync.json", "probe-async.json",',
     '"blank-refund-before-win11.log", "blank-refund-test.patch",'),
])
