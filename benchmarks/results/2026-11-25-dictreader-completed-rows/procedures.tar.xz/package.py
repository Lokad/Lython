from pathlib import Path
import hashlib
import json
import shutil
import tarfile

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
donor = lab.with_name("closed-default-store-links-20261125")
quiet = lab / "comparison/quiet"
out = repo / "benchmarks/results/2026-11-25-dictreader-completed-rows"
archive = (donor / "archive.py").read_text(encoding="utf-8").replace(
    "2026-11-25-closed-default-store-links", "2026-11-25-dictreader-completed-rows"
)
(lab / "archive.py").write_text(archive, encoding="utf-8", newline="\n")
exec(compile(archive, "archive.py", "exec"))

procedures = out / "procedures.tar.xz"
names = (
    "prepare-csv.py", "freeze.py", "prepare.py", "quiet.py", "archive.py", "package.py", "test-ubuntu.sh",
    "candidate.patch", "reference-build.log", "candidate-build.log", "launch-console.log", "retrieve.log",
    "blank-refund-before-win11.log", "blank-refund-test.patch",
    "suspension-cases.patch", "suspended-win11.log", "suspended-ubuntu10.log", "suspended-cpython.log",
    "Lokad.Lython.Tests-win11.log", "Lokad.Lython.PublicApi.Tests-win11.log",
    "Lokad.Lython.Tests-ubuntu10.log", "Lokad.Lython.PublicApi.Tests-ubuntu10.log",
    "reference-allocation-final.json", "candidate-allocation-final.json", "allocations.py",
    "reference-compiler-owner.json", "candidate-compiler-owner.json", "compile-allocation.py",
    "comparison/reference-verify.json", "comparison/candidate-verify.json",
    "comparison/quiet/representative.json", "comparison/quiet/jobs.json",
    "comparison/quiet/storage-custody.json",
)
with tarfile.open(procedures, "w:xz") as data:
    for name in names:
        data.add(lab / name, arcname=name)
with tarfile.open(procedures) as data:
    for name in names:
        member = data.getmember(name)
        assert member.isfile() and data.extractfile(member).read() == (lab / name).read_bytes()
for name in ("allocation-summary.json", "compile-allocation-summary.json"):
    shutil.copyfile(lab / name, out / name)
shutil.copyfile(quiet / "identity.json", out / "identity.json")
