from pathlib import Path
import shutil

lab=Path(__file__).resolve().parent
template=lab.parent/'eager-computed-definition-20261123'

def install(name,replacements):
    text=(template/name).read_text(encoding='utf-8')
    for old,new in replacements:
        assert old in text,(name,old)
        text=text.replace(old,new)
    compile(text,name,'exec')
    (lab/name).write_text(text,encoding='utf-8',newline='\n')

for name in ('representative.json','jobs.json','summarize.py','allocations.py','inspect-shapes.py','verify-defaults.py'):
    shutil.copyfile(template/name,lab/name)
install('freeze.py',[
    ('eager-computed-b1501/windows','eager-isolated-b1502/windows'),
    ('B1501 share the existing eager annotation preflight within the direct factory',
     'B1502 isolate eager annotation admission from the postponed factory'),
])
install('stage.py',[
    ('eager-computed-definition-b1501-20261123','eager-isolated-definition-b1502-20261123'),
    ('b1501','b1502'),
])
install('quiet.py',[
    ('eager-computed-definition-20261123','eager-isolated-definition-20261123'),
    ('b1501','b1502'),
])
install('archive.py',[
    ('eager-computed-b1501','eager-isolated-b1502'),
    ('2026-11-23-eager-computed-definition','2026-11-23-eager-isolated-definition'),
    ("'selected-returns.json','allocation-summary-six.json'","'selected-returns.json','allocation-summary-six.json','jit-frame-summary.json'"),
    ("'first-upload.json','first-stage.log','first-launch.log','retire-failed-upload.py','retire-failed-upload.log','jit-eager-only.json'",
     "'jit-eager-only.json','compare-frames.py','compare-frames.log'"),
    ("'ubuntu-Lokad.Lython.Tests.log','ubuntu-Lokad.Lython.PublicApi.Tests.log','windows-frozen.log',\n                 'eager-default-annotations.patch','win-retained-annotations.log','ubuntu-retained-annotations.log'",
     "'ubuntu-Lokad.Lython.Tests.log','ubuntu-Lokad.Lython.PublicApi.Tests.log','windows-frozen.log'"),
])
