from pathlib import Path
import json
import re

lab=Path(__file__).resolve().parent
rows=[]
for label,folder in [('B1500','direct-computed-definition-20261123'),
                     ('B1501','eager-computed-definition-20261123'),('B1502',lab.name)]:
    path=lab.parent/folder/'computed-definition.asm'
    text=path.read_text(encoding='utf-8-sig')
    assert 'CreateClosedComputedDefinition' in text
    stack=re.search(r'\bsub\s+rsp,\s*(\d+)\b',text)
    size=re.search(r'Total bytes of code (\d+)',text)
    rows.append(dict(candidate=label,stackSubtraction=int(stack[1]),emittedBytes=int(size[1])))
(lab/'jit-frame-summary.json').write_text(json.dumps(rows,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps(rows))
