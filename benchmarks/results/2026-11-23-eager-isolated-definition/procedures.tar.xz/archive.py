from pathlib import Path
import gzip
import hashlib
import json
import shutil
import subprocess
import tarfile

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
checks=lab.parent.parent/'eager-isolated-b1502'
quiet=lab/'comparison/quiet'
dest=repo/'benchmarks/results/2026-11-23-eager-isolated-definition'
sha=lambda data:hashlib.sha256(data).hexdigest()
read=lambda p:json.loads(p.read_text(encoding='utf-8'))
identity=read(lab/'comparison/identity.json')
terminal=read(quiet/'terminal-status.json')
assert not terminal['live'] and terminal['exitCode']=='0' and not terminal['fixtures']
assert all(terminal['receipt'][name] for name in ('complete','archivedAndVerifiedUnderLease','allWorkersJoined','guestFixturesRemoved','quietBeforeAndAfter'))
assert sha((quiet/'observations.tar.xz').read_bytes())==terminal['receipt']['archiveSHA256']
assert read(quiet/'summary.json')['timedBatches']==168
assert all(row['peakAdmission'][0]==row['peakAdmission'][1]
           for row in read(lab/'allocation-summary-six.json'))
assert len(read(lab/'selected-returns.json'))==1
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,encoding='utf-8').strip()
identity['retainedRevision']=head if not subprocess.check_output(['git','diff','--name-only',head,identity['candidate'],'--','src'],cwd=repo) else None
patch=subprocess.check_output(['git','diff','--binary',identity['sourceRevision'],identity['candidate'],'--','src'],cwd=repo)
(lab/'production.patch').write_bytes(patch)
identity['productionPatchSHA256']=sha(patch)
dest.mkdir(exist_ok=True)
for role,files in identity['imageFiles'].items():
    assert len(files)==32 and all(sha((lab/role/name).read_bytes())==h for name,h in files.items())
    blob=(lab/role/'Lokad.Lython.dll').read_bytes()
    archive=dest.parent/'2026-11-23-direct-computed-definition/candidate-core.dll.gz' if role=='reference' else dest/'candidate-core.dll.gz'
    if role=='candidate': archive.write_bytes(gzip.compress(blob,mtime=0))
    assert sha(gzip.decompress(archive.read_bytes()))==files['Lokad.Lython.dll']
(dest/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8',newline='\n')
for name in ('observations.tar.xz','summary.json','terminal-status.json'):
    shutil.copyfile(quiet/name,dest/name)
for name in ('selected-returns.json','allocation-summary-six.json','jit-frame-summary.json'):
    shutil.copyfile(lab/name,dest/name)
with tarfile.open(dest/'procedures.tar.xz','w:xz') as archive:
    for name in ('prepare.py','freeze.py','stage.py','quiet.py','summarize.py','inspect-shapes.py','allocations.py','verify-defaults.py',
                 'archive.py','production.patch','reference-tape.json','candidate-tape.json','computed-definition.asm',
                 'candidate-jit-allocation.json','reference-allocation-six.json','candidate-allocation-six.json',
                 'default-semantics.json','reference-default-semantics.json','candidate-default-semantics.json',
                 'jit-eager-only.json','compare-frames.py','compare-frames.log',
                 'freeze.log','inspect-shapes.log','stage.log','launch.log','retrieval.log','allocations.log','verify-defaults.log',
                 'comparison/reference-verify.json','comparison/candidate-verify.json','comparison/quiet/observe-not-before'):
        archive.add(lab/name,arcname=name,recursive=False)
    for name in ('windows-Lokad.Lython.Tests.log','windows-Lokad.Lython.PublicApi.Tests.log',
                 'ubuntu-Lokad.Lython.Tests.log','ubuntu-Lokad.Lython.PublicApi.Tests.log','windows-frozen.log'):
        archive.add(checks/name,arcname=name,recursive=False)
print(dest,identity['retainedRevision'] or 'private')
