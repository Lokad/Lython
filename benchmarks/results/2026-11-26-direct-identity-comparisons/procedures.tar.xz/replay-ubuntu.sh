set -eu
export DOTNET_ROOT="$HOME/.dotnet"
export PATH="$DOTNET_ROOT:$PATH"
lab="$PWD/.git/agent-notes/review-20261031/identity-comparisons-20261126"
python_dir="$lab/python-bin"
mkdir -p "$python_dir"
if [ ! -e "$python_dir/python" ]; then
 test -x "$HOME/.local/bin/python3.13"
 ln -s "$HOME/.local/bin/python3.13" "$python_dir/python"
fi
export PATH="$python_dir:$PATH"
python --version
dotnet build tools/LythonProbe/LythonProbe.csproj -c Release -f net10.0 --no-incremental > "$lab/probe-ubuntu10.log" 2>&1
filter='(FullyQualifiedName~Comparison|FullyQualifiedName~Identity|FullyQualifiedName~NumericProtocol|FullyQualifiedName~Operator|FullyQualifiedName~IntegerAlias)&Category!=Stress'
log="$lab/Lokad.Lython.PublicApi.Tests-ubuntu10-replay.log"
if dotnet test tests/Lokad.Lython.PublicApi.Tests/Lokad.Lython.PublicApi.Tests.csproj -c Release -f net10.0   --artifacts-path "$lab/ubuntu" --no-build --filter "$filter" > "$log" 2>&1; then
 tail -5 "$log"
else
 tail -40 "$log"
 exit 1
fi
