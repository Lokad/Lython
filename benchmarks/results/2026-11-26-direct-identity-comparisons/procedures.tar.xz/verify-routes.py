from difflib import unified_diff
from pathlib import Path
import hashlib
import json
import os
import shutil
import subprocess
import zipfile

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
template = lab.with_name('shipment-integer-store-20261126')
identity = json.loads((lab/'identity.json').read_text(encoding='utf-8'))
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
git = lambda *args: subprocess.check_output(['git',*args],cwd=repo)
assert git('diff','--binary','--','src') == (lab/'candidate.patch').read_bytes()
work = lab/'instrumented'
work.mkdir()
source = work/'source'
archive = work/'source.zip'
git('archive','--format=zip','--output',str(archive),identity['sourceRevision'],'--','src','Directory.Build.props',
    'Directory.Build.targets','Directory.Build.rsp','Directory.Packages.props','global.json','NuGet.Config')
with zipfile.ZipFile(archive) as z:
    assert all(not Path(name).is_absolute() and '..' not in Path(name).parts for name in z.namelist())
    z.extractall(source)

second='src/Lokad.Lython/Runtime/LythonRuntime.OperatorDispatch.cs'
shutil.copyfile(repo/second, source/second)
name='src/Lokad.Lython/Runtime/LythonRuntime.ScalarComparison.cs'
current=(repo/name).read_text(encoding='utf-8')
entry = '    internal static bool IsScalarComparison(BinaryOperatorSyntax op)'
matched = '            result = AreIdentical(left, right) == (op == BinaryOperatorSyntax.Is);'
assert current.count(entry)==1 and current.count(matched)==1
update=current.replace(entry, '    internal static int DiagnosticIdentityComparisons;\n\n'+entry)
update=update.replace(matched, '            Interlocked.Increment(ref DiagnosticIdentityComparisons);\n'+matched)
(source/name).write_text(update,encoding='utf-8',newline='\n')
with (work/'diagnostic.patch').open('w',encoding='utf-8',newline='\n') as patch:
    patch.writelines(unified_diff(current.splitlines(keepends=True),update.splitlines(keepends=True),'a/'+name,'b/'+name))
program = (template/'Program.cs').read_text(encoding='utf-8').replace(
    '["IntegerStoreCandidates", "IntegerStoreExisting", "IntegerStoreNativePrefix", "IntegerStorePackedKeys"]',
    '["IdentityComparisons"]').replace(
    'Lokad.Lython.Runtime.LythonRuntime+ExecutionContext', 'Lokad.Lython.Runtime.LythonRuntime')
(work/'Program.cs').write_text(program,encoding='utf-8',newline='\n')
shutil.copyfile(template/'RouteProbe.csproj',work/'RouteProbe.csproj')
catalog=json.loads((lab/'representative.json').read_text(encoding='utf-8'))
catalog['cases']=[case | {'runAsync':mode} for case in catalog['cases'] for mode in (False,True)]
(work/'cases.json').write_text(json.dumps(catalog,ensure_ascii=False),encoding='utf-8',newline='\n')
image=work/'image'
image.mkdir()
for name, expected in identity['imageFiles']['candidate'].items():
    assert sha(lab/'candidate'/name)==expected
    shutil.copyfile(lab/'candidate'/name,image/name)
sdk=Path.home()/'.dotnet11'
dotnet=sdk/'dotnet.exe'
env=dict(os.environ,DOTNET_ROOT=str(sdk))
def run(args,name):
    with (work/name).open('wb') as log:
        subprocess.run([dotnet,*args],stdout=log,stderr=subprocess.STDOUT,cwd=repo,env=env,check=True,timeout=150)
run(['build',source/'src/Lokad.Lython/Lokad.Lython.csproj','-c','Release','-f','net11.0','--no-incremental','-o',work/'core'],'core.log')
shutil.copyfile(work/'core/Lokad.Lython.dll', image/'Lokad.Lython.dll')
run(['build',work/'RouteProbe.csproj','-c','Release','-o',work/'probe'],'probe.log')
for artifact in (work/'probe').glob('RouteProbe*'): shutil.copyfile(artifact,image/artifact.name)
run([image/'RouteProbe.dll',image,work/'cases.json',lab/'routes.json'],'verify.log')
for row in json.loads((lab/'routes.json').read_text(encoding='utf-8'))['rows']:
    print(row['id'],row['asynchronous'],row['routes'])