from pathlib import Path
import hashlib
import json
import shutil
import tarfile

original = Path(__file__).resolve().parent
previous = original / 'comparison/quiet'
lab = original.with_name('identity-comparisons-confirmation-20261126')
quiet = lab / 'comparison/quiet'
quiet.mkdir(parents=True)
read = lambda p: json.loads(p.read_text(encoding='utf-8'))
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
def write(p, text):
    p.write_text(text, encoding='utf-8', newline='\n')
def save(p, data):
    write(p, json.dumps(data, indent=2)+'\n')
receipt = read(previous/'terminal-status.json')['receipt']
assert receipt['complete'] and receipt['allWorkersJoined']
assert sha(previous/'observations.tar.xz') == receipt['archiveSHA256']
identity = read(previous/'identity.json')
for role, files in identity['imageFiles'].items():
    assert len(files)==32 and {p.name:sha(p) for p in (original/role).iterdir()}==files
for name in ('representative.json','cpython-worker.py','run.sh'):
    shutil.copyfile(previous/name,quiet/name)
assert b'\r' not in (quiet/'run.sh').read_bytes()
save(quiet/'jobs.json',{'warm':[
    ['diagnostic.shipment-file-fed-map','warm-async'],
    ['diagnostic.shipment-routing-callbacks','warm-async'],
]})
identity['catalogs']['jobs.json']['sha256'] = sha(quiet/'jobs.json')
identity['purpose'] = 'Confirm shared identity evaluation with the file-fed control measured first.'
save(quiet/'identity.json', identity)
body=(previous/'collect.py').read_text(encoding='utf-8')
assert body.count('len(jobs) == 3')==1
body=body.replace('len(jobs) == 3','len(jobs) == 2').replace('lython-b1756-fixtures','lython-b1756-confirmation-fixtures')
compile(body,'collect.py','exec')
write(quiet/'collect.py',body)
body=(original/'quiet.py').read_text(encoding='utf-8')
body=body.replace("unit='lython-b1756-identity-comparisons-20261126'",
                  "unit='lython-b1756-identity-comparisons-confirmation-20261126'")
body=body.replace('seconds=170','seconds=130').replace('RuntimeMaxSec=210','RuntimeMaxSec=170')
compile(body,'quiet.py','exec')
write(lab/'quiet.py',body)
body=(original/'summarize.py').read_text(encoding='utf-8')
body=body.replace("receipt['warmJobs'] == 3","receipt['warmJobs'] == 2").replace("len(raw['jobs']) == 3","len(raw['jobs']) == 2")
write(lab/'summarize.py',body.replace('timedBatches=84','timedBatches=56'))
payload=quiet/'stage.tar.gz'
with tarfile.open(payload,'w:gz',compresslevel=6) as archive:
    for name in ('identity.json','jobs.json','representative.json','collect.py','run.sh','cpython-worker.py'):
        archive.add(quiet/name,arcname=name,recursive=False)
    archive.add(original/'candidate/Lokad.Lython.dll',arcname='new-core.dll',recursive=False)
prior=read(previous/'upload.json')
save(quiet/'upload.json',dict(root='identity-comparisons-confirmation-b1756-20261126',
    payloadSHA256=sha(payload),payloadBytes=payload.stat().st_size,donorSHA256=prior['donorSHA256']))