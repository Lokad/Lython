import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import tarfile

lab = Path(__file__).resolve().parent
quiet = lab / 'comparison' / 'quiet'
root = lab.parents[3]
result = root / 'benchmarks/results/2026-11-26-direct-identity-comparisons'
identity = json.loads((quiet/'identity.json').read_text(encoding='utf-8'))
def git(*args):
    return subprocess.check_output(['git',*args],cwd=root)
patch = git('diff','--binary','--','src')
assert patch == (lab/'candidate.patch').read_bytes()
assert hashlib.sha256(patch).hexdigest() == identity['sourcePatchSHA256']
assert git('rev-parse','HEAD').decode().strip() == identity['sourceRevision']
terminal = json.loads((quiet/'terminal-status.json').read_text(encoding='utf-8'))
assert hashlib.sha256((quiet/'observations.tar.xz').read_bytes()).hexdigest() == terminal['receipt']['archiveSHA256']
result.mkdir()
for name in ('summary.json','allocation-summary.json','routes.json','comparison-attempts.json'):
    shutil.copyfile(lab/name,result/name)
for name in ('identity.json','terminal-status.json','observations.tar.xz'):
    shutil.copyfile(quiet/name,result/name)

local_files = (
    'candidate.patch','prepare.py','prepare-quiet.py','quiet.py','summarize.py','archive.py',
    'prepare-confirmation.py','verify-comparison-attempts.py','comparison-attempts/diagnostic.patch',
    'comparison-attempts/core.log','comparison-attempts/probe.log','comparison-attempts/verify.log',
    'reference-verify.json','candidate-verify.json','reference-allocation.json','candidate-allocation.json',
    'frozen-build.log','verify-routes.py','test-ubuntu.sh','replay-ubuntu.sh','probe-ubuntu10.log',
    'Lokad.Lython.PublicApi.Tests-win11.log','Lokad.Lython.Tests-win11.log','Lokad.Lython.Tests-ubuntu10.log',
    'Lokad.Lython.PublicApi.Tests-ubuntu10.log','Lokad.Lython.PublicApi.Tests-ubuntu10-replay.log',
    'instrumented/Program.cs','instrumented/RouteProbe.csproj','instrumented/diagnostic.patch','instrumented/cases.json',
    'instrumented/core.log','instrumented/probe.log','instrumented/verify.log',
)
quiet_files = ('launch.log','collect.py','run.sh','jobs.json','representative.json','cpython-worker.py')
with tarfile.open(result/'procedures.tar.xz','w:xz') as archive:
    for name in local_files:
        archive.add(lab/name,arcname=name)
    for name in quiet_files:
        archive.add(quiet/name,arcname='quiet/'+name)
    wide=lab.with_name('json-magnitude-utf8-20261126')
    for name in ('prepare.py','quiet.py','comparison/quiet/collect.py','comparison/quiet/run.sh'):
        archive.add(wide/name,arcname='template/'+name)
    archive.add(lab.with_name('ready-shipment-rows-20261126')/'prepare-quiet.py',arcname='template/ready-prepare-quiet.py')
with tarfile.open(result/'procedures.tar.xz') as archive:
    assert archive.extractfile('candidate.patch').read() == patch
    assert len(archive.getmembers())==len(local_files)+len(quiet_files)+5
confirmation = lab.with_name('identity-comparisons-confirmation-20261126')
reordered = confirmation/'comparison/quiet'
checked = json.loads((reordered/'identity.json').read_text(encoding='utf-8'))
assert checked['sourceRevision']==identity['sourceRevision']
assert checked['sourcePatchSHA256']==identity['sourcePatchSHA256']
assert checked['imageFiles']==identity['imageFiles']
receipt = json.loads((reordered/'terminal-status.json').read_text(encoding='utf-8'))['receipt']
assert receipt['complete'] and receipt['allWorkersJoined'] and receipt['warmJobs']==2
assert hashlib.sha256((reordered/'observations.tar.xz').read_bytes()).hexdigest()==receipt['archiveSHA256']
follow = result/'confirmation'
follow.mkdir()
shutil.copyfile(confirmation/'summary.json',follow/'summary.json')
for name in ('identity.json','terminal-status.json','observations.tar.xz'):
    shutil.copyfile(reordered/name,follow/name)
with tarfile.open(follow/'procedures.tar.xz','w:xz') as archive:
    for name in ('launch.log','collect.py','run.sh','jobs.json','representative.json','cpython-worker.py'):
        archive.add(reordered/name,arcname=name)
    for name in ('quiet.py','summarize.py'):
        archive.add(confirmation/name,arcname=name)
