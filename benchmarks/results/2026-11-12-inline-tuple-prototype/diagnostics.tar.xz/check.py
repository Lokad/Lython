from pathlib import Path
import os,subprocess,sys,shutil
r=Path(__file__).parent;sdk=Path('C:/Users/JoannesVermorel/.dotnet11');env=os.environ.copy();env['DOTNET_ROOT']=str(sdk);env['PATH']=str(sdk)+';C:/Python313;'+env['PATH']
for name in ['build.log','internal-net11.0.log']:
    if (r/name).exists() and not (r/('initial-'+name)).exists():shutil.copyfile(r/name,r/('initial-'+name))
commands=[('build',[str(sdk/'dotnet.exe'),'build','Lokad.Lython.slnx','-c','Release'])]
for framework in ['net11.0','net10.0']:
    for suite in ['internal','public']:
        project='tests/Lokad.Lython.Tests/Lokad.Lython.Tests.csproj' if suite=='internal' else 'tests/Lokad.Lython.PublicApi.Tests/Lokad.Lython.PublicApi.Tests.csproj'
        names=['Tuple','Unpack','FunctionDefault','Csv','Json','NativeClosure','ReturnedIteration','CooperativeCancellation','Admission','Ownership','MemoryBudget','Projection','CallInputLifetime']
        filter='Category!=Stress&('+'|'.join('FullyQualifiedName~'+n for n in names)+')'
        commands.append((suite+'-'+framework,[str(sdk/'dotnet.exe'),'test',project,'-c','Release','-f',framework,'--no-build','--filter',filter]))
for label,args in commands:
    with (r/(label+'.log')).open('w',encoding='utf-8',newline='\n') as log:result=subprocess.run(args,env=env,stdout=log,stderr=subprocess.STDOUT)
    print(label,result.returncode,flush=True);print('\n'.join((r/(label+'.log')).read_text(encoding='utf-8').splitlines()[-9:]),flush=True)
    if result.returncode:sys.exit(result.returncode)
