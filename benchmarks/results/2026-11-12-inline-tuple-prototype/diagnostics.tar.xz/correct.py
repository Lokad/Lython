from pathlib import Path
import shutil
r=Path(__file__).parent;out=r/'corrected';out.mkdir(exist_ok=True)
p=Path('src/Lokad.Lython/Runtime/PyTuple.cs');s=p.read_text(encoding='utf-8')
shutil.copyfile(p,r/'refined-before-correction-PyTuple.cs')
s=s.replace('// Small ordinary tuples own their references directly. Larger/adopted\n    // tuples keep array storage; neither representation borrows caller operands.', '// Small span-built tuples own their references directly. Adopted arrays\n    // stay authoritative, including during private cycle construction. A negative\n    // count encodes array length; it never classifies a guest element by type.')
s=s.replace('_count = array.Length;\n        SetStorage(array);', '_count = ~array.Length;\n        _items[0] = array;')
s=s.replace('_count = items.Length;\n        if (items.Length <= 2)', '_count = items.Length <= 2 ? items.Length : ~items.Length;\n        if (items.Length <= 2)')
s=s.replace('_count = items.Length;\n        SetStorage(takeOwnership || items.Length <= 2 ? items : [.. items]);','_count = ~items.Length;\n        _items[0] = takeOwnership ? items : [.. items];')
s=s.replace('_count = items.Length;\n        SetStorage(items);', '_count = ~items.Length;\n        _items[0] = items;')
start=s.index('    // Count selects one authoritative storage form.')
end=s.index('    public MemoryGovernor?',start)
s=s[:start]+s[end:]
s=s.replace('private ReadOnlySpan<object> Items => _count > 2 ?', 'private ReadOnlySpan<object> Items => _count < 0 ?')
s=s.replace('public int Count => _count;', 'public int Count => _count < 0 ? ~_count : _count;')
s=s.replace('public IEnumerator<object> GetEnumerator() => _count > 2', 'public IEnumerator<object> GetEnumerator() => _count < 0')
assert 'SetStorage' not in s and '_count = items.Length;' not in s
p.write_text(s,encoding='utf-8',newline='\n')
for name in ['check.py','freeze.py']:shutil.copyfile(r/'refined'/name,out/name)
p=out/'check.py';s=p.read_text(encoding='utf-8').replace("names=['Tuple'", "names=['Copy','Tuple'");p.write_text(s,encoding='utf-8',newline='\n')
(out/'correction.md').write_text('''The first single-field refinement copied adopted short arrays eagerly. CopyTupleAsync deliberately publishes the memoized tuple shell before populating its backing, and existing public deepcopy coverage catches the missing values. Keep all adopted arrays authoritative, using a negative encoded count for array mode and nonnegative count for completed inline span storage. Remove the SetStorage conversion helper. No caller inventory or new construction API. Expected64B header and broader indexing costs still need measurement; retain original failed check and frozen image, never qualify the incorrect form.\n''',encoding='utf-8',newline='\n')
print('Corrected array-adoption semantics; final form pending checks and measurement.')
