# Lokad.Lython 0.11.0

Updated 2026-11-12. Git-ignored; never force-add. Publication and tagging remain
postponed. Deliver coherent execution/ownership simplification and substantial
complete-script improvements, including compile-to-result. An isolated experiment
does not complete this objective.

## Actual delivery status

| State | Delivered work and limits |
| --- | --- |
| Fully qualified production | **9bca1337**, GREEN [43295336048](https://github.com/Lokad/Lython/actions/runs/43295336048). Windows/Ubuntu, actual .NET 11/10, ordinary 4590 internal/17448 public and original stress 13/406 per target, installed Release consumers. All 568 measured production sources match. [Delivery](benchmarks/results/2026-11-12-captured-slot-ownership/delivery/README.md). R284 was withdrawn; production remains unchanged. |
| Committed evidence | 7bbf3b9d records final qualification and current CPython guide; da61f00f records complete R284 withdrawal and the retained two-case alias regression. Production is unchanged. |
| Active development | R287 ordinary tuple-storage prototype selected from the actual CSV construction path; no allocation/CPU result or full qualification claimed yet. R285 source gate closes without a runtime change. |
| Withdrawn prototype | **R284** explicit cell locations: 14316 focused checks and seven complete scripts pass, but B641 CSV Run +1.28..+3.46% elapsed with supporting adverse CPU; captured benefit uncertain and allocation flat. Entire source/fixture prototype removed; independent 2-case alias regression retained. Restored build +438 focused checks pass. [Evidence](benchmarks/results/2026-11-12-lexical-cell-storage-withdrawn/README.md). |
| Refreshed external measurements | Qualified 9bca1337 vs CPython 3.13.16: captured text warm **1.63–1.74×**, compile **0.83–0.84×**, compile-to-result **1.44–1.54×**; UTF8 report warm **1.30–1.33×**, compile-to-result **1.23–1.29×**. Controls/IQR leave four rows variable. [Guide](docs/BENCHMARKS.md), [all five observations](benchmarks/results/2026-11-12-captured-cpython-checkpoint/README.md). Other rows retain their historical sources; no extrapolation to R284. |

## Completed milestones to preserve

| Work | Established outcome / remaining debt |
| --- | --- |
| Shared compiler facts | Shared-analysis/nonlocal correction, annotation demand and retained-lowered cleanup delivered. Compilation allocation reductions established; CPU attribution remains limited. |
| Direct UTF8 formatting/storage | Allocation **−8.67%**, controlled elapsed/CPU supports roughly **5–8%**. Original adverse 15.125 ms observation remains unexplained and preserved; it does not automatically invalidate the controlled evidence. |
| Native helper returns | Run allocation **−19.92%**, RunAsync **−19.31%**; full qualification and throwing-refund fix complete. Original elapsed improvements remain diagnostic. |
| Calls and frame storage | Direct ordinary calls, reused startup workers/workspaces, executable callable consolidation, live closures, captured helper execution and private totals delivered. R281 removes sparse local-cell arrays, backpointers and synchronization: captured Run elapsed **−4–6%**, supporting CPU; CSVAsync elapsed **+0.4–2.3%** accepted debt. Other async/report results remain uncertain. |
| CSV / record construction | Earlier bulk CSV work was selectively reassessed into current row adoption/shared keys. Preserve mutable headers/order, duplicates, protocols, retained aliases and construction overlap. No automatic promotion of old prototypes. |
| Native text/storage | Immutable reader windows, prepared word ranges, compact native metadata and transferred builders delivered. R271 report elapsed **+0.6–2.8%** remains accepted debt. These changes do not establish additive CPU gains. |
| Bulk UTF16 | Managed bounded transcoding replaces scalar emission; three dormant helpers removed. Affected elapsed improves, async CPU supports it; sync CPU uncertain. UTF8 control elapsed up to **+2.11%** and CPU up to **+1.25%** remain accepted uncertainty/debt. Initial count fusion withdrawn. |
| R279 JSON windows | Existing immutable backing reused for plain same-owner tokens. Report allocation **−4.68% UTF8 / −4.46–4.49% UTF16**; modest controlled UTF8 report benefit. Full backing can stay funded longer; UTF16/JSON/CSV CPU uncertain. Fully qualified. |
| Bounded assessments | R280 check/span deletions withdrawn with all adversity preserved. R283 observes 6229/13398/14425 allowance resizes for text/CSV/report, identical across APIs; no duplicate funding or removable CPU established, so no funding cache/allocator added. |

Detailed failed conditions, refinements, rejected designs and raw measurements stay
in [EXPERIMENTS](benchmarks/EXPERIMENTS.md) and immutable benchmark artifacts, not
in the active checklist or current runtime guide.

## Prioritized deliverables and acceptance

1. **R287: ordinary tuple storage, active coherent prototype.** CSV's complete
   `validated_record` helper returns an observable two-item tuple on each accepted
   row. Its tuple literal copies operand references into a separate small array;
   tuple unpacking already borrows immutable storage. Preserve the tuple itself,
   its aliases and Python identity. Do not add an unboxed return/unpack protocol.
   - Hypothesis: keep up to two references in managed inline tuple storage and
     remove that per-record backing allocation/copy. Array-backed large tuples
     retain adoption. Unknown iterable construction keeps existing protocol work.
     This consolidates ordinary collection construction, not a compiler pattern.
   - Cost/tradeoff: a larger tuple header and an indexed-storage branch affect
     all tuples. Admit conservative metadata/capacity and unchanged scalar funding
     before construction; retain input overlap and exact cancellation/refusal order.
     Earlier rejection is acceptable, retained aliases are never refunded.
   - Acceptance: tuple identity, hashes/keys, iteration/unpacking/slicing, defaults,
     named tuples, projection, retained results, mutation during admission, genuine
     async callbacks/cancellation and terminal refusal. Use existing focused tests;
     add only independent observable gaps. No Unsafe, native layout assumption,
     tagged scalar VM, extra cache, allocator or consumer-specific backend.
   - Measure actual constructor/array allocation and complete CSV against the
     frozen qualified baseline, plus captured text/JSON/report controls. Separate
     allocation benefit from CPU. Use a bounded desktop diagnostic first; retain
     original adversity and seek quiet-VM confirmation if source remains justified.
     Finish by retaining a coherent migration with explicit debt or removing the
     entire prototype, then batch full qualification only for retained source.

2. **R285 source gate closed; broader result ownership remains a later design.**
   Existing range reuse is delivered. A private cased cursor carries a real loan
   across native/framed/protected returns and asynchronous finally work. Moving
   only its fields into the immediate caller misses those paths; a result union,
   side table or pool adds a broader protocol. No local cursor prototype selected.
   [Source/lifetime proof](benchmarks/results/2026-11-12-private-iteration-source-gate/README.md).
   A future coherent transfer must remove the cursor, separate positions and old
   cleanup together; preserve eager admission and binding/refund order. No permanent
   ban follows. R286's three short Windows disk-host traces and one existing-memory-
   host correction preserve all goldens/balances but sampled wall time is not CPU;
   unmanaged waits and sampling bias remain unresolved. Do not promote its apparent
   MapCaseRune dominance to a CPU claim or retime it unchanged. R267/R272 quiet-VM
   samples remain source-labelled evidence, not exact attribution of today's HEAD.

3. **Other roadmap axes remain evidence-driven.** Locals/operands and span binding
   already share storage. Current record adoption, formatting plans, word ranges,
   JSON windows and output batching are delivered. Do not replay slower call arenas,
   linear native proof, ordered prefixes or segment-entry forms unchanged. Config
   compilation is near CPython; no dominant duplicate frontend pass is proven.
   Scoped scalar improvements must preserve identity, exact promotion and public
   projection; boxing alone does not establish dominant cost. A materially different
   redesign stays open, with an explicit completion milestone and debt decision.

4. **Independent regex track.** Core Python/native-UTF8 contract and implementation
   are delivered; normal optional nonpackable adapter remains 0.4. Immutable
   dev73/eae880c8 semantic checks (86 internal/532 public per actual target) complete.
   Development producers/adapter-local bridges may support independent work.
   Only affected final released-adapter qualification awaits: separate one-match
   working/result owners, native UTF8 group-name enumeration, and token-independent
   cursor creation with cancellable preparation. Per-move cancellation alone does
   not prove preparation interruption. No blanket producer stop or unchanged API
   requalification; core remains decoupled and publication remains postponed.

## Measurement and lasting constraints

Architecture, allocation/allowance reduction and demonstrated CPU improvement are
separate outcomes. Percentages inform decisions; they are not automatic vetoes.
Timeouts or moving controls establish uncertainty. Permit bounded confirmation,
refinement and measurement correction when justified, retaining original/adverse
conditions. Size runs for usable observations on the quiet VM; no permanent bans
or one-attempt/no-retiming policy. Preserve all inconclusive external rows.

Use focused Release checks in development. Batch Windows/Ubuntu, actual .NET11/10,
original stress and installed Release consumers at delivery boundaries. After source
restoration, force a nonincremental build before no-build checks or worker freezing.
GC fixtures stay nonparallel. Cache terminal CI/VM states; live CI checks minutes
apart. Persistent raw/catalog/worker storage stays separate from RAM fixtures;
join, archive and verify before cleanup. Preserve OS/evidence floors. RSS, genuinely
pending-I/O latency and embedding-tail impact remain unqualified.

Fully managed and memory-safe: no unsafe code/APIs, pointers, P/Invoke or native
stack probing. Keep managed stack admission, host capabilities/paths, cancellation,
cycles/XML depth and checked representation/bounded I/O chunks. Borrowed shared
allowance funds capacity, overlap, retained results/aliases/caches and pending users
until ownership ends. First refused admission is terminal; guest-raised MemoryError
remains catchable. No fuel/quotas, hidden caps/default allowances, tracing/weak
reclamation, forced GC, retries or abandoned users. Streaming uses bounded host-led
commands. Preserve original path/Cwd requests and refused-copy destinations.
See [AGENTS](AGENTS.md) and the [current runtime contract](docs/RUNTIME.md).
