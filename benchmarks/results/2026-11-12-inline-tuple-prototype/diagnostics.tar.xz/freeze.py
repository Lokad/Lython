from pathlib import Path
import hashlib,json,os,shutil,subprocess,tarfile
r=Path(__file__).parent;old=r.parent/'lexical-cell-storage-r284';digest=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
baseline=json.loads((old/'candidate-identity.json').read_text(encoding='utf-8'));source={p:digest(Path(p))for p in baseline['sources']}
changed=[p for p in source if Path(p).read_bytes().replace(b'\r\n',b'\n')!=subprocess.check_output(['git','show','HEAD:'+p]).replace(b'\r\n',b'\n')]
assert len(source)==568 and changed==['src/Lokad.Lython/Runtime/PyTuple.cs'],changed
for name in ['reference','candidate']:
    assert not(r/name).exists();shutil.copytree(old/'reference',r/name,copy_function=os.link)
assert digest(r/'reference/Lokad.Lython.dll')=='e4cc65b251ace242546f337b0846908a4e2a4313953da74df6fb666e1ce87529'
(r/'candidate/Lokad.Lython.dll').unlink();shutil.copyfile('src/Lokad.Lython/bin/Release/net11.0/Lokad.Lython.dll',r/'candidate/Lokad.Lython.dll')
for name,folder in [('before-core.dll','reference'),('candidate-core.dll','candidate')]:shutil.copyfile(r/folder/'Lokad.Lython.dll',r/name)
with tarfile.open(r/'candidate-sources.tar.xz','w:xz')as t:
    for p in source:t.add(p,arcname=p)
(r/'candidate-identity.json').write_text(json.dumps(dict(head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()+' plus R287 uncommitted',sources=source,coreSHA256=digest(r/'candidate-core.dll'),referenceSHA256=digest(r/'before-core.dll'),changed=changed),indent=2)+'\n',encoding='utf-8',newline='\n')
shutil.copyfile(old/'catalog.json',r/'catalog.json');tool=r/'tool';tool.mkdir()
for name in ['complete-jobs.csproj','packages.lock.json']:shutil.copyfile(old/'tool'/name,tool/name)
code=(old/'tool/Program.cs').read_text(encoding='utf-8').replace('R284 explicit lexical cell locations; permanent owner, shadow value and repeated mode selection removed;','R287 ordinary tuple inline references; small span construction removes backing arrays; larger headers/estimates and general indexing remain tradeoffs;')
code=code.replace('cellConstruction = MeasureCells(Core.GetType("Lokad.Lython.Runtime.LythonRuntime+ExecutableCell", true)!)','cellConstruction = MeasureCells(Core.GetType("Lokad.Lython.Runtime.LythonRuntime+ExecutableCell", true)!), tupleHeader = MeasureTupleHeader(Core.GetType("Lokad.Lython.Runtime.PyTuple", true)!)')
marker='    private static object MeasureCells(Type type)'
assert marker in code
code=code.replace(marker,'''    private static object MeasureTupleHeader(Type type)
    {
        var constructor = type.GetConstructors(BindingFlags.NonPublic | BindingFlags.Instance)
            .Single(c => c.GetParameters().Select(p => p.ParameterType).SequenceEqual(new[] { typeof(object[]), typeof(bool) }));
        object?[] arguments = [Array.Empty<object>(), true];
        for (var i = 0; i < 32; i++) _ = constructor.Invoke(arguments);
        var retained = new object[256];
        var before = GC.GetAllocatedBytesForCurrentThread();
        for (var i = 0; i < retained.Length; i++) retained[i] = constructor.Invoke(arguments);
        var bytes = GC.GetAllocatedBytesForCurrentThread() - before;
        GC.KeepAlive(retained);
        return new { instances = retained.Length, bytes, bytesPerHeaderIncludingReflection = bytes / (double)retained.Length, outsideGuestClocks = true };
    }

'''+marker)
(tool/'Program.cs').write_text(code,encoding='utf-8',newline='\n')
env=os.environ.copy();sdk=Path('C:/Users/JoannesVermorel/.dotnet11');env['DOTNET_ROOT']=str(sdk);env['PATH']=str(sdk)+';C:/Python313;'+env['PATH']
with(r/'build-driver.log').open('w',encoding='utf-8',newline='\n')as log:done=subprocess.run([str(sdk/'dotnet.exe'),'build',str(tool/'complete-jobs.csproj'),'-c','Release','-f','net11.0','--no-incremental'],env=env,stdout=log,stderr=subprocess.STDOUT)
assert done.returncode==0,(r/'build-driver.log').read_text(encoding='utf-8')
assert all(digest(Path(p))==h for p,h in source.items())
for name in ['diagnostic.py','run-diagnostics.py','summarize.py']:shutil.copyfile(old/name,r/name)
(r/'implementation.patch').write_bytes(subprocess.check_output(['git','diff','--','src/Lokad.Lython','tests/Lokad.Lython.Tests']))
print(json.dumps(dict(sources=len(source),changed=changed,core=digest(r/'candidate-core.dll'))),flush=True)
subprocess.run(['python','-X','utf8',str(r/'run-diagnostics.py')],check=True)
