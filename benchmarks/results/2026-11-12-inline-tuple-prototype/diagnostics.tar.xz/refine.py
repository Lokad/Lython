from pathlib import Path
import shutil
r=Path(__file__).parent;out=r/'refined';out.mkdir(exist_ok=True)
p=Path('src/Lokad.Lython/Runtime/PyTuple.cs');s=p.read_text(encoding='utf-8')
shutil.copyfile(p,r/'initial-PyTuple.cs')
s=s.replace('private readonly object[]? _items;\n    private InlineItems _inlineItems;\n    private readonly int _inlineCount;', 'private InlineItems _items;\n    private readonly int _count;')
s=s.replace('_inlineItems','_items').replace('_inlineCount','_count')
s=s.replace('        _items = items.ToArray();','        var array = items.ToArray();\n        _count = array.Length;\n        SetStorage(array);',1)
s=s.replace('        _items = MaterializeGovernedItems(items, governor, allocationSpan, out _committedBytes);','        var array = MaterializeGovernedItems(items, governor, allocationSpan, out _committedBytes);\n        _count = array.Length;\n        SetStorage(array);')
s=s.replace('    public PyTuple(ReadOnlySpan<object> items)\n    {','    public PyTuple(ReadOnlySpan<object> items)\n    {\n        _count = items.Length;')
s=s.replace('                _count = items.Length;\n','').replace('            _count = items.Length;\n','')
s=s.replace('        else _items = items.ToArray();','        else _items[0] = items.ToArray();')
s=s.replace('        if (items.Length <= 2)\n        {\n            context ??=', '        _count = items.Length;\n        if (items.Length <= 2)\n        {\n            context ??=')
s=s.replace('        else _items = CopyGovernedItems(items, governor, allocationSpan, out _committedBytes, context);','        else _items[0] = CopyGovernedItems(items, governor, allocationSpan, out _committedBytes, context);')
s=s.replace('        _items = takeOwnership ? items : [.. items];','        _count = items.Length;\n        SetStorage(takeOwnership || items.Length <= 2 ? items : [.. items]);')
s=s.replace('        _items = items;\n        _memoryGovernor', '        _count = items.Length;\n        SetStorage(items);\n        _memoryGovernor')
s=s.replace('    public MemoryGovernor? OwnerMemoryGovernor', '''    // Count selects one authoritative storage form. Short adopted arrays can be
    // relinquished after copying their two references; existing conservative
    // construction funding is retained, never refunded from a live alias.
    private void SetStorage(object[] items)
    {
        if (_count <= 2) items.AsSpan().CopyTo(_items);
        else _items[0] = items;
    }

    public MemoryGovernor? OwnerMemoryGovernor''')
s=s.replace('private ReadOnlySpan<object> Items => _items is { } array ? array : ((ReadOnlySpan<object>)_items)[.._count];','private ReadOnlySpan<object> Items => _count > 2 ? (object[])_items[0] : ((ReadOnlySpan<object>)_items)[.._count];')
s=s.replace('public int Count => _items?.Length ?? _count;', 'public int Count => _count;')
s=s.replace('public IEnumerator<object> GetEnumerator() => _items is { } array\n        ? ((IEnumerable<object>)array).GetEnumerator() : EnumerateInline();','public IEnumerator<object> GetEnumerator() => _count > 2\n        ? ((IEnumerable<object>)(object[])_items[0]).GetEnumerator() : EnumerateInline();')
assert '_inline' not in s and '_items =' not in s
p.write_text(s,encoding='utf-8',newline='\n')
for name in ['check.py','freeze.py']:shutil.copyfile(r/name,out/name)
p=out/'freeze.py';s=p.read_text(encoding='utf-8').replace("old=r.parent/'lexical-cell-storage-r284'", "old=r.parent.parent/'lexical-cell-storage-r284'")
s=s.replace("(r/'implementation.patch').write_bytes", "p=r/'diagnostic.py';p.write_text(p.read_text(encoding='utf-8').replace(\"r.parent/'bulk-utf16-r276\",\"r.parent.parent/'bulk-utf16-r276\"),encoding='utf-8',newline='\\n')\n(r/'implementation.patch').write_bytes")
p.write_text(s,encoding='utf-8',newline='\n')
(out/'refinement.md').write_text('''Measured initial header48→72B and CSV allocation−1.62%; no reliable elapsed improvement. Consolidate the inline/array fields into one managed storage field selected by immutable count. Count no longer follows array storage. Expected header64B must be measured. Preserve initial source/core/raw/control adversity; do not declare this CPU improvement. All adopted short arrays relinquish their references only after copying into the tuple; conservative funding/overlap remains. No guest tuple identity, alias, protocol or projection change.\n''',encoding='utf-8',newline='\n')
print('Initial source/data frozen; refined single authoritative tuple storage, no new mechanism.')
