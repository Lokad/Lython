from pathlib import Path
import hashlib,json,shutil,subprocess,tarfile
r=Path(__file__).parent
for root in [r,r/'refined',r/'corrected']:
    for phase in ['warm-sync','warm-async','compile','fresh']:
        d=json.loads((root/phase/'stdout.json').read_text(encoding='utf-8'))
        assert d['allGoldensPassed'] and d['allBalancesZero'] and d['ownedFixturesRemoved']
    subprocess.run(['python','-X','utf8',str(root/'summarize.py')],check=True,stdout=subprocess.DEVNULL)
for framework in ['net11.0','net10.0']:
    for suite,count in [('internal',1494),('public',2617)]:
        text=(r/'corrected'/f'{suite}-{framework}.log').read_text(encoding='utf-8')
        assert 'Failed:     0' in text and str(count) in text
out=Path('benchmarks/results/2026-11-12-inline-tuple-prototype');out.mkdir(exist_ok=True)
identity=json.loads((r/'corrected/candidate-identity.json').read_text(encoding='utf-8'))
assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==h for p,h in identity['sources'].items())
for root,label in [(r,'initial'),(r/'refined','failed-refinement'),(r/'corrected','corrected')]:
    for phase in ['warm-sync','warm-async','compile','fresh']:
        target=out/label/phase;target.mkdir(parents=True,exist_ok=True)
        shutil.copyfile(root/phase/'summary.json',target/'summary.json')
    shutil.copyfile(root/'candidate-identity.json',out/label/'source-identity.json')
with tarfile.open(out/'diagnostics.tar.xz','w:xz') as t:
    for p in sorted(r.rglob('*')):
        rel=p.relative_to(r)
        if p.is_file() and not {'bin','obj','reference','candidate'}&set(rel.parts):t.add(p,arcname=rel.as_posix())
lines=[]
for phase in ['warm-sync','warm-async']:
    for row in json.loads((r/'corrected'/phase/'summary.json').read_text(encoding='utf-8'))['rows']:
        alloc=[x['allocatedBytes'] for x in row['candidateChangePercent'].values()]
        elapsed=[x['elapsedMilliseconds'] for x in row['candidateChangePercent'].values()]
        lines.append(f"| {row['case']} / {phase} | {min(alloc):+.2f}..{max(alloc):+.2f}% | {min(elapsed):+.2f}..{max(elapsed):+.2f}% | {row['unchangedControlSpreadPercent']['elapsedMilliseconds']:.2f}% |")
readme='''# Ordinary tuple storage — R287 active prototype

2026-11-12. Baseline qualified9bca1337/e4cc65b2; current committed source7ea62157
has unchanged production. Three uncommitted source forms are frozen separately:
initialc1945390, incorrect refinementf4f57df2, correcteda3160fcb. **Not retained,
not fully qualified, no CPU gain established.** Publication remains postponed.

The unchanged CSV helper returns an observable pair on each accepted row. Ordinary
tuple construction copies evaluated operands into a separate small backing array;
unpacking already borrows it. Keep the Python object/identity/aliases and copy short
completed spans directly into managed InlineArray storage. Large or adopted arrays
remain array-backed. No private return protocol, pool, unsafe API or new execution
route. Source compares one production file/four accounting fixtures; no general
heap or ownership audit.

Initial separate inline/array fields grow measured header48→72B and reduce complete
CSV allocation only1.62% despite eliminating a pair's array. Other allocations stay
nearly flat. Controls vary and several elapsed/compilation observations are adverse;
all survive.7866focused actual11/10 checks pass (1458internal/2475public each),
seven complete scripts both APIs/compilation/fresh pass. No CPU claim follows.

The single-storage refinement measures64B headers but incorrectly copies short
adopted arrays. Existing deepcopy coverage fails: CopyTupleAsync deliberately memoizes
the tuple shell before populating its private backing. Do not qualify or use timings
from that incorrect form to select a runtime. Its frozen code, failing check and
automatically launched seven-script diagnostics survive. The measurement launcher
was started before the failed test result was inspected; this is procedural error,
not supporting qualification. All diagnostic workers still join and close.

Corrected code keeps adopted arrays authoritative using a negative encoded count;
nonnegative count selects completed short inline spans. It deletes the premature
conversion helper and the overlapping array field. Header64B is measured with256
prewarmed constructor calls outside guest clocks, including identical reflection
overhead; no native layout/Unsafe assumptions. Large tuples pay16B more header than
baseline; small literal pairs remove an array. This tradeoff must be assessed on
whole scripts rather than field counts. Conservative metadata estimates rise;
earlier refusal is intentional. Fixture changes derive their capacity, preserve
the intended cache-insertion denial and retain independent refund/ownership checks.

Corrected Release solution build and8222focused checks pass across actual.NET11/10
(1494internal/2617public each), adding the full existing copy coverage. All seven
unchanged scripts pass both APIs, separate compilation and compile-to-result,
stdout/files, balance and joined-fixture cleanup. Normal workstationGC/tiering,
Windows desktop, same fixed local images/host and original trusted fixtures.
Three isolated load contexts share processGC/CoreLib; clocks are **diagnostic**.
Warm includes disk fixture reset/mediated I/O/goldens/result cleanup; execution clock
is separately recorded. Compile and fresh are separate, startup/final cache cleanup
excluded. This differs from quiet-VM warm timing and predicts no CPython ratio.

| Complete command/API | Allocation change | Diagnostic elapsed | Unchanged-control spread |
| --- | ---: | ---: | ---: |
'''+ '\n'.join(lines)+'''

Ranges use candidate versus both baseline process-role medians. Preserve all original
compile/fresh and adverse observations in raw diagnostics. No unchanged retiming or
full platform/package cycle is selected automatically. Next decide source value and
any justified quiet-VM confirmation, or remove the whole prototype. This bounded
storage experiment does not complete the substantial whole-script performance goal.
The next larger source gate concerns complete helper local/return construction;
it must preserve ordered effects and genuine suspension without replaying the
slower call-arena/generic-prefix migration. Regex final-package gaps are independent.

[Exact sources, patches, binaries, tests and all raw conditions](diagnostics.tar.xz),
[corrected warm](corrected/warm-sync/summary.json),
[corrected async](corrected/warm-async/summary.json),
[source identity](corrected/source-identity.json). Current guides remain unchanged;
this is historical/prototype evidence, not shipped performance documentation.
'''
(out/'README.md').write_text(readme,encoding='utf-8',newline='\n')
files={p.relative_to(out).as_posix():dict(bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest()) for p in out.rglob('*') if p.is_file() and p.name not in ['manifest.json','README.md']}
(out/'manifest.json').write_text(json.dumps(files,indent=2)+'\n',encoding='utf-8',newline='\n')
p=Path('PLAN.md');s=p.read_text(encoding='utf-8').replace('complete-script diagnostics are finishing.','all seven scripts/both APIs/compile/fresh pass. Header64B is measured; desktop allocation/elapsed is archived separately.')
s=s.replace('   - Finish corrected seven-script/both-API/compile/fresh diagnostics and actual\n     header/allocation observation against the frozen baseline.', '   - Corrected seven-script/both-API/compile/fresh diagnostics pass; header64B.\n     [All initial/failing/corrected evidence](benchmarks/results/2026-11-12-inline-tuple-prototype/README.md).')
p.write_text(s,encoding='utf-8',newline='\n')
print('Three source forms and all diagnostics archived; corrected prototype remains uncommitted/unqualified.')
