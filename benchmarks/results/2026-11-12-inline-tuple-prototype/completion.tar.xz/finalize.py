from pathlib import Path
import hashlib,json,re,shutil,subprocess,tarfile
r=Path(__file__).parent;vm=r/'corrected/b642';out=Path('benchmarks/results/2026-11-12-inline-tuple-prototype')
summary=json.loads((vm/'summary.json').read_text(encoding='utf-8'));terminal=json.loads((vm/'terminal-status.json').read_text(encoding='utf-8'))
assert summary['complete']and summary['jobs']==4 and terminal['receipt']['allWorkersJoined'] and not terminal['remainingWorkers'] and not terminal['remainingTrace']
counts={}
for framework in ['net11.0','net10.0']:
    for suite in ['internal','public']:
        log=(r/f'restored-{suite}-{framework}.log').read_text(encoding='utf-8')
        assert 'Failed:     0' in log and 'Passed!' in log
        counts[suite+'-'+framework]=int(re.search(r'Passed:\s+(\d+)',log).group(1))
assert 'Build succeeded.' in (r/'restored-build.log').read_text(encoding='utf-8')
proof=json.loads((r/'restoration.json').read_text(encoding='utf-8'));assert proof['sourceCount']==568 and proof['allMatchWithExplicitNewlineNormalization']
for name in ['observations.tgz','summary.json','terminal-status.json','archive-receipt.json','extraction.json']:
    target=out/'vm';target.mkdir(exist_ok=True);shutil.copyfile(vm/name,target/name)
shutil.copyfile(r/'restoration.json',out/'restoration.json')
with tarfile.open(out/'completion.tar.xz','w:xz') as t:
    for p in sorted(r.iterdir()):
        if p.is_file()and (p.name.startswith('restor')or p.name in ['final-prototype.patch','restore.py','finalize.py','refresh-plan.py']):t.add(p,arcname=p.name)
    for p in sorted(vm.iterdir()):
        if p.is_file()and p.suffix in ['.py','.json','.log','.sh','.stdout','.stderr']:t.add(p,arcname='b642/'+p.name)
p=out/'README.md';s=p.read_text(encoding='utf-8')
s=s.replace('# Ordinary tuple storage — R287 active prototype','# Ordinary tuple storage — R287 withdrawn')
s=s.replace('**Not retained,\nnot fully qualified, no CPU gain established.**','**Withdrawn after B642. No production change, no CPU gain established.**')
s+='''
## Controlled decision and restoration

B642 uses the same quietF4as_v7/Ubuntu24.04.4/.NET11RC3, fixedfec79worker,
normalGC/tiering, two processes/image and seven rotated500ms rounds. Four jobs
complete in169.406s under300s owner/30s stop/30s margin. Warm includes mediated
RAM-file I/O, full validation and prior-result cleanup; wider processCPU includes
reset/protocol/runtime work. No compilation/startup/final-cache cost in warm clocks.

| Complete command/API | Elapsed change | Wider processCPU | Reference/candidate spread |
| --- | ---: | ---: | ---: |
| CSV Run | −0.46..+4.07% | 0..+4.83% | 1.56/2.84% |
| CSV RunAsync | −3.11..+1.69% | −1.22..+1.92% | 3.90/0.86% |
| UTF16 report Run | +0.12..+0.51% | −1.85..+0.67% | 0.37/0.01% |
| UTF8 report Run | −1.64..+0.80% | −1.89..+1.28% | 1.15/1.28% |

Ranges retain all four process-median pairings. No reliable targeted CSV CPU
benefit is demonstrated; Run includes possible adversity. The large desktop
UTF16 elapsed regression is not reproduced, but equivalence/cause is not proven.
**Withdraw the complete prototype.** Its2.42% CSV allocation reduction is real,
but a new storage tag/index branch,16B larger general header and larger admission
estimates do not justify retention without targeted CPU benefit. This is a design/
evidence tradeoff, not a fixed percentage veto, failed-design proof or permanent
ban. The substantial performance objective stays open. No further unchanged
confirmation is needed for this bounded decision; materially new evidence remains
eligible for a later refinement. No dormant tuple form or fixture threshold change
is retained, and no new full platform/package cycle of unchanged runtime is claimed.

All identity/golden/balance/quiet/Closed/exit/join/unmount/archive gates pass.
Raw archive SHAa1deaf1ca49f814c49f445592068da5328b1970c49afb053a958816f13657ed0
is independently verified; terminal cached, no live VM users/RAM fixtures. To stage,
only exact already committed withdrawnc8 image aliases, its source snapshot and
duplicate B641 archive are retired under fresh idle lease/path/UID/inode/all-alias/
Git+SHA proof. Qualified e4 images and all canonical evidence remain. Existing
OS240MiB/evidence12MiB/staging floors are unchanged; final VMfree266145792B.

All five prototype source/fixture files restore to committed production.568core
sources match qualified code with explicit newline normalization. Forced
nonincremental Release solution build and '''+str(sum(counts.values()))+''' focused target checks pass:
'''+', '.join(k+'='+str(v) for k,v in counts.items())+'''.
The previously committed generator alias regression remains. The corrected/failing
forms, all desktop/VM adversity and restoration evidence survive. Next is the
ordered complete-helper state design; this storage withdrawal is not completion
of the overall performance objective.

[Controlled observations](vm/summary.json), [raw VM evidence](vm/observations.tgz),
[completion/preparation/restoration](completion.tar.xz), [restoration proof](restoration.json).
'''
# Earlier next-action prose describes the prototype checkpoint; mark it historical.
s=s.replace('Next decide source value and\nany justified quiet-VM confirmation, or remove the whole prototype.','At that checkpoint, retention/quiet-VM confirmation remained pending; the decision\nbelow completes it.')
p.write_text(s,encoding='utf-8',newline='\n')
files={p.relative_to(out).as_posix():dict(bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest()) for p in out.rglob('*') if p.is_file()and p.name not in ['README.md','manifest.json']}
(out/'manifest.json').write_text(json.dumps(files,indent=2)+'\n',encoding='utf-8',newline='\n')
history=Path('benchmarks/EXPERIMENTS.md')
history.write_text(history.read_text(encoding='utf-8')+'''\n## R287/R288 — tuple storage withdrawn; complete-helper design gate\n\n+[Three tuple forms and all original conditions](results/2026-11-12-inline-tuple-prototype/README.md)\n+measure initial48→72B/refined64B headers. The eager adopted-array refinement fails\n+deepcopy; corrected code preserves that backing and passes8222focused actual-target\n+checks plus seven scripts/both APIs/compile/fresh. CSV allocation−2.42%, but\n+B642four jobs169.406s demonstrates no reliable targeted CPU benefit; Run includes\n+possible adversity. Withdraw the storage tag/header/index/admission complexity,\n+preserve all results, restore568sources and force a nonincremental build plus\n+focused checks. No new full qualification or closure of the whole-script objective.\n+[R288 exact code facts](results/2026-11-12-complete-helper-source-gate/README.md)\n+show13ordinary CSV helper instructions/8slots/0statement fallbacks. Repeated local\n+use and concrete returns need one ordered effect/transition contract, rather than\n+duplicated initializers or premature field-type proof. No automatic larger\n+compiler migration or replay of the slower generic-prefix/arena forms.\n+''',encoding='utf-8',newline='\n')
plan=Path('PLAN.md');s=plan.read_text(encoding='utf-8')
s=s.replace('| Active prototype | **R287**, one production/four accounting-fixture files. Initial c1945390 passes7866 focused checks, removes small literal arrays but CSV allocation falls only1.62%; elapsed diagnostic. A single-field refinement f4f57df2 fails existing deepcopy coverage and is not qualified. Corrected a3160fcb preserves adopted backing, passes8222 focused actual-target checks; all seven scripts/both APIs/compile/fresh pass. Header64B is measured; desktop allocation/elapsed is archived separately. No CPU or full qualification claim. |','| Latest bounded experiment | **R287 withdrawn.** Corrected tuple storage passes8222focused checks/all seven scripts and reduces CSV allocation2.42%, but B642 shows no reliable targeted CPU benefit and possible Run adversity. Tag/header/index/admission complexity removed; qualified source restored, nonincremental build/focused checks pass. [All evidence](benchmarks/results/2026-11-12-inline-tuple-prototype/README.md). |')
start=s.index('1. **R287:');end=s.index('3. **Next substantial call/return milestone:',start)
s=s[:start]+s[end:]
s=s.replace('3. **Next substantial call/return milestone:','1. **Next substantial call/return milestone:').replace('4. **Other roadmap axes','2. **Other roadmap axes').replace('5. **Independent regex','3. **Independent regex')
s=s.replace('| Bounded assessments | R280 check/span deletions withdrawn with all adversity preserved. R283 observes 6229/13398/14425 allowance resizes for text/CSV/report, identical across APIs; no duplicate funding or removable CPU established, so no funding cache/allocator added. |','| Bounded assessments | R280/R284/R287 source forms withdrawn with all adversity preserved. R283 frequent admission counts prove no duplicate funding/CPU tax. [R285](benchmarks/results/2026-11-12-private-iteration-source-gate/README.md) confirms real private cursor ownership through suspended returns; no caller-only side table. [R286](benchmarks/results/2026-11-12-local-script-attribution/README.md) sampled wall-time uncertainty is not CPU dominance. No dormant forms or global funding cache retained. |')
plan.write_text(s,encoding='utf-8',newline='\n')
print('Recorded controlled withdrawal/restoration; plan advances to ordered complete-helper design. Counts:',counts)
