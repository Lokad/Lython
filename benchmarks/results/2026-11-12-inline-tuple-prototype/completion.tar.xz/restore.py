from pathlib import Path
import hashlib,json,os,subprocess,sys
r=Path(__file__).parent
paths=['src/Lokad.Lython/Runtime/PyTuple.cs','tests/Lokad.Lython.Tests/FunctoolsCacheOwnershipTests.cs','tests/Lokad.Lython.Tests/NamedTupleAccountingTests.cs','tests/Lokad.Lython.Tests/PathElementOwnershipTests.cs','tests/Lokad.Lython.Tests/TupleConstructionFailureTests.cs']
workspace=Path.cwd().resolve()
(r/'final-prototype.patch').write_bytes(subprocess.check_output(['git','diff','--',*paths]))
for name in paths:
    p=Path(name).resolve();assert p.is_relative_to(workspace)
    p.write_bytes(subprocess.check_output(['git','show','HEAD:'+name]))
identity=json.loads((r/'corrected/candidate-identity.json').read_text(encoding='utf-8'))
proof=[]
for name in identity['sources']:
    current=Path(name).read_bytes();committed=subprocess.check_output(['git','show','HEAD:'+name])
    assert current.replace(b'\r\n',b'\n')==committed.replace(b'\r\n',b'\n'),name
    proof.append(dict(path=name,sha256=hashlib.sha256(current).hexdigest()))
(r/'restoration.json').write_text(json.dumps(dict(head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),qualifiedProduction='9bca1337f02a9acc172c65c141ce626222b847bd',sources=proof,sourceCount=len(proof),allMatchWithExplicitNewlineNormalization=True),indent=2)+'\n',encoding='utf-8',newline='\n')
sdk=Path('C:/Users/JoannesVermorel/.dotnet11');env=os.environ.copy();env['DOTNET_ROOT']=str(sdk);env['PATH']=str(sdk)+';C:/Python313;'+env['PATH']
commands=[('restored-build',[str(sdk/'dotnet.exe'),'build','Lokad.Lython.slnx','-c','Release','--no-incremental'])]
for framework in ['net11.0','net10.0']:
    for suite in ['internal','public']:
        project='tests/Lokad.Lython.Tests/Lokad.Lython.Tests.csproj' if suite=='internal' else 'tests/Lokad.Lython.PublicApi.Tests/Lokad.Lython.PublicApi.Tests.csproj'
        names=['Tuple','Copy','Unpack','FunctionDefault','NativeClosure','ReturnedIteration','CooperativeCancellation','Admission','Ownership','MemoryBudget','Projection','CallInputLifetime']
        filter='Category!=Stress&('+'|'.join('FullyQualifiedName~'+n for n in names)+')'
        commands.append(('restored-'+suite+'-'+framework,[str(sdk/'dotnet.exe'),'test',project,'-c','Release','-f',framework,'--no-build','--filter',filter]))
for label,args in commands:
    with (r/(label+'.log')).open('w',encoding='utf-8',newline='\n') as log:done=subprocess.run(args,env=env,stdout=log,stderr=subprocess.STDOUT)
    print(label,done.returncode,flush=True);print('\n'.join((r/(label+'.log')).read_text(encoding='utf-8').splitlines()[-8:]),flush=True)
    if done.returncode:sys.exit(done.returncode)
print('Restored qualified runtime/fixtures, forced nonincremental build and focused actual-target checks pass.',flush=True)
