from pathlib import Path
p=Path('PLAN.md');s=p.read_text(encoding='utf-8')
s=s.replace('Publication and tagging remain','Publication and tagging remain')
s=s.replace('All 568 measured production sources match.','All 568 sources of that measured baseline match; the active working-tree prototype is separate.')
s=s.replace('| Active development | R287 ordinary tuple-storage prototype selected from the actual CSV construction path; no allocation/CPU result or full qualification claimed yet. R285 source gate closes without a runtime change. |','| Active prototype | **R287**, one production/four accounting-fixture files. Initial c1945390 passes7866 focused checks, removes small literal arrays but CSV allocation falls only1.62%; elapsed diagnostic. A single-field refinement f4f57df2 fails existing deepcopy coverage and is not qualified. Corrected a3160fcb preserves adopted backing, passes8222 focused actual-target checks; complete-script diagnostics are finishing. No CPU or full qualification claim. |')
s=s.replace('da61f00f records complete R284 withdrawal and the retained two-case alias regression. Production is unchanged.','da61f00f records complete R284 withdrawal and the retained two-case alias regression. 7ea62157 records R285/R286 source/profiling evidence. Committed production is unchanged.')
old='''   - Measure actual constructor/array allocation and complete CSV against the
     frozen qualified baseline, plus captured text/JSON/report controls. Separate
     allocation benefit from CPU. Use a bounded desktop diagnostic first; retain
     original adversity and seek quiet-VM confirmation if source remains justified.
     Finish by retaining a coherent migration with explicit debt or removing the
     entire prototype, then batch full qualification only for retained source.
'''
new='''   - Current evidence: initial header48→72B; whole CSV allocation−1.62% despite
     removal of each literal's small array. Other allocations are nearly flat;
     moving/adverse controls prevent a CPU claim. Refinement consolidates storage
     and count, but copying adopted arrays broke deepcopy's private population
     phase. Corrected code keeps every adopted array authoritative, with inline
     storage only for completed short spans. Both failures/original images survive.
     Larger metadata estimates can reject earlier; first refusal/refunds remain.
   - Finish corrected seven-script/both-API/compile/fresh diagnostics and actual
     header/allocation observation against the frozen baseline. Quiet-VM checks
     follow only a justified retained candidate, with explicit resource preparation
     and unchanged OS/evidence floors. Allocation alone does not establish useful
     CPU improvement. Decide source value/debt or remove the complete prototype;
     do not count this stage as the substantial whole-script performance objective.
     Batch full qualification only for retained source.
'''
assert old in s;s=s.replace(old,new)
idx=s.index('3. **Other roadmap axes')
s=s[:idx]+'''3. **Next substantial call/return milestone: source proof before migration.**
   The representative CSV helper's ordinary scalar local and nonempty tuple
   return still use instruction execution. Current native preparation supports a
   local store only when immediately reloaded once; later reads decline it, and
   only empty tuple literals are prepared. Do not confuse this with a whole-module
   lowered fallback or a second argument/local array: both are already removed.
   - Hypothesis/work to eliminate: recurring ordinary workstate/instruction/operand
     transport for complete acyclic helpers with reused local values and concrete
     collection results. Keep actual Python tuples; retire the limited one-load
     forwarding rule if a coherent local/return representation replaces it. Preserve
     the measured native guard/evaluator benefit; do not replay R268's slower
     replacement with generic prefix execution or claim new physical arrays vanish.
   - Semantic acceptance: evaluate each local initializer exactly once; preserve
     branch/error order, late dictionary reads/types after admission reentry, live
     aliases, builtin shadowing, source spans, genuine protocol suspension, terminal
     refusal, cancellation and funded cleanup. No whole-call replay after effects.
     Do not create a second dispatcher, caching policy or tagged-value VM merely
     to make the helper eligible. A state transfer that duplicates ordinary frames
     needs an explicit removal argument before implementation.
   - Bounded source gate: map this exact helper plus captured/search/report controls,
     identify eligibility and post-effect transition requirements, and finish with
     one implementable design or a precise source objection. A literal/local node
     tweak alone does not finish the milestone. For a selected coherent redesign,
     compare compilation and complete warm/fresh scripts with unchanged controls;
     allow measured refinement and decide any residual regression debt at delivery.

'''+s[idx:]
s=s.replace('3. **Other roadmap axes','4. **Other roadmap axes').replace('4. **Independent regex','5. **Independent regex')
p.write_text(s,encoding='utf-8',newline='\n')
print('Plan distinguishes every tuple form and qualification, and names the next complete-helper design gate.')
