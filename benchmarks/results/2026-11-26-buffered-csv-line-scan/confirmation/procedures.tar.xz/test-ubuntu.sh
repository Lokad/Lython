set -eu
export DOTNET_ROOT="$HOME/.dotnet"
export PATH="$DOTNET_ROOT:$PATH"
lab="$PWD/.git/agent-notes/review-20261031/csv-window-source-gate-20261126"
source="$lab/candidate-source"
cd "$source"
for suite in Lokad.Lython.Tests Lokad.Lython.PublicApi.Tests; do
  if [ "$suite" = Lokad.Lython.Tests ]; then
    filter='Category!=Stress&(FullyQualifiedName~Csv|FullyQualifiedName~TextFile)'
  else
    filter='Category!=Stress&(FullyQualifiedName~Csv|FullyQualifiedName~TextFileNewline)'
  fi
  log="$lab/$suite-ubuntu10.log"
  if dotnet test "tests/$suite/$suite.csproj" -c Release -f net10.0 --artifacts-path "$lab/ubuntu" --filter "$filter" > "$log" 2>&1; then
    tail -5 "$log"
  else
    tail -38 "$log"
    exit 1
  fi
done
