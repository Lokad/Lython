from difflib import unified_diff
from pathlib import Path
import ast
import hashlib
import json
import os
import shutil
import subprocess
import tarfile

lab = Path(__file__).resolve().parent
quiet = lab / "comparison/quiet"
quiet.mkdir(parents=True)
local = lab / "local"
donor = lab.with_name("direct-record-helper-20261126")
template = donor / "comparison/quiet"
read = lambda p: json.loads(p.read_text(encoding="utf-8"))
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
write = lambda p, t: p.write_text(t, encoding="utf-8", newline="\n")
save = lambda p, data: write(p, json.dumps(data,indent=2) + "\n")
identity = read(local / "identity.json")
assert sha(lab / "candidate.patch") == identity["sourcePatchSHA256"]
for role, files in identity["imageFiles"].items():
    assert len(files) == 32 and {p.name:sha(p) for p in (local / role).iterdir()} == files
    proof = read(local / (role + "-verify.json"))
    assert proof["state"] == "Completed" and proof["caseCount"] == 5
    assert proof["launched"]["library"]["sha256"] == files["Lokad.Lython.dll"]
    assert proof["catalogSha256"] == identity["catalogs"]["representative.json"]["sha256"]
for name in ("representative.json","jobs.json","cpython-worker.py"):
    shutil.copyfile(local/name,quiet/name)
identity["expectedCPythonSHA256"] = read(template/"identity.json")["expectedCPythonSHA256"]
assert sha(quiet/"cpython-worker.py") == identity["cpythonWorkerSHA256"]
save(quiet/"identity.json",identity)
source = (template/"collect.py").read_text(encoding="utf-8")
source = source.replace("len(jobs) == 3","len(jobs) == 5").replace("lython-b1759-fixtures","lython-b1762-fixtures")
keys = {node.slice.value for node in ast.walk(ast.parse(source)) if isinstance(node,ast.Subscript)
        and isinstance(node.value,ast.Name) and node.value.id == "identity" and isinstance(node.slice,ast.Constant)}
assert keys <= identity.keys(), sorted(keys-identity.keys())
write(quiet/"collect.py", source)
shutil.copyfile(template/"run.sh",quiet/"run.sh")
assert b"\r" not in (quiet/"run.sh").read_bytes()
files = [("new-core.dll",local/"candidate/Lokad.Lython.dll")]
files += [(name,quiet/name) for name in ("identity.json","representative.json","jobs.json","collect.py","run.sh","cpython-worker.py")]
payload = quiet/"stage.tar.gz"
with tarfile.open(payload,"w:gz",compresslevel=6) as package:
    for name,path in files:
        package.add(path,arcname=name,recursive=False)
donor_receipt=read(template/"terminal-status.json")["receipt"]
assert donor_receipt["complete"] and sha(template/"observations.tar.xz") == donor_receipt["archiveSHA256"]
save(quiet/"upload.json",dict(root="buffered-csv-line-scan-b1762-20261126",payloadSHA256=sha(payload),
     payloadBytes=payload.stat().st_size,donorSHA256=donor_receipt["archiveSHA256"]))
body = (donor/"quiet.py").read_text(encoding="utf-8")
updates = {
    "lython-b1759-direct-record-helper-20261126":"lython-b1762-buffered-csv-line-scan-20261126",
    "base/'identity-comparisons-b1756-20261126'/'candidate'":"base/'direct-record-helper-b1759-20261126'/'candidate'",
    "verified['caseCount']==3":"verified['caseCount']==5",
    "RuntimeMaxSec=210":"RuntimeMaxSec=278",
    "seconds=170":"seconds=233",
    " worker=root/'candidate/Lokad.Lython.Benchmarks.dll'":" assert sha(python)==image['expectedCPythonSHA256']\n worker=root/'candidate/Lokad.Lython.Benchmarks.dll'",
}
for old,new in updates.items():
    assert body.count(old)==1,old
    body = body.replace(old,new)
compile(body,"quiet.py","exec")
write(lab/"quiet.py",body)
summary = (donor/"summarize.py").read_text(encoding="utf-8").replace(
    "['warmJobs'] == 3","['warmJobs'] == 5").replace("len(raw['jobs']) == 3","len(raw['jobs']) == 5")
summary = summary.replace("timedBatches=84","timedBatches=140").replace("lab / 'summary.json'", "quiet / 'summary.json'")
compile(summary,"summarize-quiet.py","exec")
write(lab/"summarize-quiet.py",summary)

retire = []
for name, directory, unit in (
    ("ready-shipment-rows-20261126","ready-shipment-rows-b1753-20261126","lython-b1753-ready-shipment-rows-20261126"),
    ("composed-native-inputs-20261125","composed-native-inputs-b1742-20261125","lython-b1742-composed-inputs-20261125"),
):
    previous = lab.with_name(name)
    data = previous/"comparison/quiet"
    expected=read(data/"identity.json")["imageFiles"]["candidate"]
    receipt=read(data/"terminal-status.json")["receipt"]
    assert len(expected)==32 and {p.name:sha(p) for p in (previous/"candidate").iterdir()}==expected
    assert receipt["complete"] and receipt["allWorkersJoined"] and receipt["guestFixturesRemoved"]
    assert sha(data/"observations.tar.xz")==receipt["archiveSHA256"]
    retire.append(dict(root=directory,unit=unit,files=expected,raw=receipt["archiveSHA256"]))
minimum=payload.stat().st_size+sum(path.stat().st_size for _,path in files)+12*1024*1024
custody = "cfg=" + repr(dict(retire=retire,minimum=minimum)) + """
from pathlib import Path
import fcntl,hashlib,json,shutil,subprocess
base=Path('/home/lokad/lython-bench-checks')
assert base.resolve()==base
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
with (base/'comparison-vm.lock').open('a') as lease:
    fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
    before=shutil.disk_usage(base).free
    copies=[]
    target=before
    for source in cfg['retire']:
        if target>=cfg['minimum']:break
        root=base/source['root']
        assert root.resolve()==root and root.parent==base
        props=subprocess.run(['systemctl','show',source['unit']+'.service','--property=ActiveState,MainPID'],
                             capture_output=True,text=True,check=True).stdout.splitlines()
        assert 'ActiveState=inactive' in props and 'MainPID=0' in props,props
        receipt=json.loads((root/'archive-receipt.json').read_text(encoding='utf-8'))
        assert receipt['complete'] and receipt['allWorkersJoined'] and receipt['guestFixturesRemoved']
        assert receipt['archiveSHA256']==source['raw']==sha(root/'observations.tar.xz')
        image=root/'candidate'
        assert image.resolve()==image and {p.name:sha(p) for p in image.iterdir()}==source['files']
        exact=image/'Lokad.Lython.dll'
        assert exact.resolve()==exact and exact.stat().st_nlink==1
        for folder in base.iterdir():
            if not folder.is_dir() or folder.is_symlink(): continue
            for role in ('candidate','reference'):
                other=folder/role/exact.name
                assert other==exact or other.resolve()!=exact,other
        copies.append((exact,source['files'][exact.name]))
        target+=exact.stat().st_size
    assert target>=cfg['minimum'], (before,target,cfg['minimum'])
    for file,checksum in copies:
        assert sha(file)==checksum
        file.unlink()
    print(json.dumps(dict(freeBeforeBytes=before,freeAfterBytes=shutil.disk_usage(base).free,
                          projectedMinimumBeforeUpload=cfg['minimum'],
                          removedRemoteStageCopies=[dict(path=str(file.relative_to(base)),sha256=digest)
                                                    for file,digest in copies])))
"""
write(lab/"verify-staging-custody.py",custody)
remote = ["ssh","-i",os.environ["LYTHON_BENCH_IDENTITY"],"-o","BatchMode=yes","-o","ConnectTimeout=12",
          os.environ["LYTHON_BENCH_HOST"],"python3 -"]
result = subprocess.check_output(remote,input=custody,encoding="utf-8",timeout=46)
save(lab/"quiet-custody.json",json.loads(result))
print(result,end="")
