using System.Text;
using Lokad.Lython.Tests.Harness;

namespace Lokad.Lython.PublicApi.Tests;

public sealed class CsvBufferedPhysicalLinesTests
{
    [Theory]
    [InlineData("", true)]
    [InlineData(null, false)]
    public async Task MixedNewlinesPreserveRowsLineNumbersAndRemainingInput(string? newline, bool preserve)
    {
        var open = newline is null ? "open('mixed.csv')" : "open('mixed.csv', newline='')";
        var source = $$"""
            import csv
            with {{open}} as f:
                rows = csv.reader(f, strict=True)
                print(next(rows), rows.line_num)
                print(next(rows), rows.line_num)
                wide = next(rows)
                print(len(wide[0]), wide[1] == '', rows.line_num)
                print(next(rows), rows.line_num)
                print(next(rows), rows.line_num)
                print(repr(f.readline()))
            """;
        const string prefix = "start,warm\r\né,yes\n";
        // The CR at the 16 KiB read boundary is held until the LF arrives.
        var count = 16 * 1024 - Encoding.UTF8.GetByteCount(prefix) - 2;
        var content = prefix + new string('x', count) + ",\r\n\r\"p\r\nq\",tail\rleft,untouched\r\n";
        var embedded = preserve ? @"\r\n" : @"\n";
        var expected = $"['start', 'warm'] 1\n['é', 'yes'] 2\n{count} True 3\n[] 4\n" +
            $"['p{embedded}q', 'tail'] 6\n'left,untouched{embedded}'\n";

        var budget = new LythonMemoryBudget(2 * 1024 * 1024);
        using (var script = new LythonEngine().Compile(source, budget))
        {
            Assert.True(script.IsValid, string.Join(" | ", script.Diagnostics));
            var baseline = budget.ReservedBytes;
            var sync = new MockLythonHost();
            sync.SeedFile("/mixed.csv", content);
            using (var result = script.Run(sync)) Check(result);
            Assert.Equal(baseline, budget.ReservedBytes);

            var delayed = new DelayedLythonHost();
            delayed.SeedFile("/mixed.csv", content);
            using (var result = await script.RunAsync(delayed)) Check(result);
            Assert.True(delayed.CompletedAsynchronously > 0);
            Assert.Equal(1, delayed.ClosedFileCount);
            Assert.Equal(baseline, budget.ReservedBytes);
        }
        Assert.Equal(0, budget.ReservedBytes);

        void Check(LythonExecutionResult result)
        {
            Assert.True(result.Success, result.Failure?.Message);
            Assert.Equal(expected, result.StandardOutput);
        }
    }
}
