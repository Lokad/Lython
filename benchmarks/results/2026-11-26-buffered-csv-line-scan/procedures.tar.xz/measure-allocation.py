from pathlib import Path
from statistics import median
import hashlib
import json
import os
import shutil
import subprocess

lab = Path(__file__).resolve().parent
local = lab / "local"
tool = lab.with_name("json-traversal-20261124") / "reference"
repo = lab.parents[3]
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
read = lambda p: json.loads(p.read_text(encoding="utf-8"))
assert (local / "exit-code.txt").read_text(encoding="utf-8").strip() == "0"
initial = read(local / "identity.json")
sdk = Path.home() / ".dotnet11"
dotnet = sdk / "dotnet.exe"
env = dict(os.environ, DOTNET_ROOT=str(sdk), DOTNET_ROOT_X64=str(sdk))
rows = {}
for role, files in initial["imageFiles"].items():
    path = lab / f"{role}-allocated"
    path.mkdir()
    assert {p.name: sha(p) for p in (local / role).iterdir()} == files
    for name in files:
        shutil.copyfile(local / role / name, path / name)
    assert {p.name: sha(p) for p in path.iterdir()} == files
    for program in tool.glob("ValidatedAllocation*"):
        shutil.copyfile(program, path / program.name)
    output = lab / (role + "-allocation.json")
    subprocess.run([dotnet, path / "ValidatedAllocation.dll", path, local / "representative.json", output],
                   cwd=repo, env=env, timeout=55, check=True)
    rows[role] = read(output)["rows"]
summary = []
for before, after in zip(rows["reference"], rows["candidate"], strict=True):
    assert before["id"] == after["id"] and before["sharedBudgetBaselineRestored"] and after["sharedBudgetBaselineRestored"]
    summary.append(dict(case=before["id"],
                        allocationBytes=[median(row["allocatedBytesPerInvocation"]) for row in (before, after)],
                        peakAdmission=[row["peakExecutionMemoryBytes"] for row in (before, after)]))
(lab/"allocation-summary.json").write_text(json.dumps(summary, indent=2)+"\n", encoding="utf-8", newline="\n")
print(json.dumps(summary))
