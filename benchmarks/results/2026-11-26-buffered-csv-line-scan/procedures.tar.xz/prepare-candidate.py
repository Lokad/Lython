from difflib import unified_diff
from pathlib import Path
import subprocess
import zipfile

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
source = lab / "candidate-source"
source.mkdir()
destination = lab / "candidate-source.zip"
subprocess.run(["git", "archive", "--format=zip", "--output", destination, "bc93d4d74", "--",
                "src", "tests", "tools/LythonProbe", "Directory.Build.props", "Directory.Build.targets",
                "Directory.Build.rsp", "Directory.Packages.props", "global.json", "NuGet.Config"],
               cwd=repo, check=True)
with zipfile.ZipFile(destination) as archive:
    assert all(not Path(name).is_absolute() and ".." not in Path(name).parts for name in archive.namelist())
    archive.extractall(source)

patch = []
def change(name, changes):
    relative = "src/Lokad.Lython/Runtime/" + name
    path = source / relative
    before = path.read_text(encoding="utf-8")
    after = before
    for old, new in changes:
        assert after.count(old) == 1, old
        after = after.replace(old, new)
    path.write_text(after, encoding="utf-8", newline="\n")
    patch.extend(unified_diff(before.splitlines(keepends=True), after.splitlines(keepends=True),
                             "a/" + relative, "b/" + relative))

change("LythonRuntime.CsvModule.cs", [
    ("""        internal int ConsumeBorrowedNativeLine(ReadOnlySpan<byte> line, Memory<ExecutableSlot>? destination,
            CsvDictReaderObject? dictionary)
        {
            _context.CheckExecution(_span);
            PhysicalLineCount++;
            return _parser.ConsumeBorrowedLine(line, destination, dictionary);
        }""",
     """        internal bool TryDescribeBufferedNativeRecord(ReadOnlySpan<byte> window, out int length)
            => _parser.TryDescribeBufferedRecord(window, out length);

        internal int ConsumeBorrowedNativeLine(ReadOnlySpan<byte> line, Memory<ExecutableSlot>? destination,
            CsvDictReaderObject? dictionary, bool described)
        {
            _context.CheckExecution(_span);
            PhysicalLineCount++;
            return described
                ? _parser.PublishRecord(line, destination, dictionary)
                : _parser.ConsumeBorrowedLine(line, destination, dictionary);
        }"""),
    ("        private int PublishRecord(ReadOnlySpan<byte> source", "        internal int PublishRecord(ReadOnlySpan<byte> source"),
    ("""        private bool TryDescribeLiteralRecord(ReadOnlySpan<byte> line, out int nextField)
        {
            if (_readyRecord is not null) throw new InvalidOperationException("CSV input advanced before consuming its record.");
            nextField = 0;
            if (line.IsEmpty) return true;
            if (line[0] is (byte)'\\r' or (byte)'\\n')
            {
                _context.CheckExecution(_span);
                ValidateRecordEnd(line[1..]);
                return true;
            }""",
     """        // Universal text windows may contain following rows. Select only
        // complete literal lines here. Recovery starts at the original file
        // position with the parser's pre-admitted scratch still in place.
        internal bool TryDescribeBufferedRecord(ReadOnlySpan<byte> window, out int length)
        {
            length = 0;
            if (_options.Quoting == CsvQuotingMode.NonNumeric) return false;
            if (TryDescribeLiteralRecord(window, out length, buffered: true)) return true;
            ResetFields();
            return false;
        }

        private bool TryDescribeLiteralRecord(ReadOnlySpan<byte> line, out int boundary, bool buffered = false)
        {
            if (_readyRecord is not null) throw new InvalidOperationException("CSV input advanced before consuming its record.");
            boundary = 0;
            if (line.IsEmpty) return !buffered;
            if (line[0] is (byte)'\\r' or (byte)'\\n')
            {
                _context.CheckExecution(_span);
                return DescribeLiteralTerminator(line, 0, buffered, out boundary);
            }"""),
    ("""                    var close = FindLiteralQuote(line, start + 1, (byte)quoteStart);""",
     """                    var close = FindLiteralQuote(line, start + 1, (byte)quoteStart, buffered);"""),
    ("""                if (end == line.Length) return true;
                if (line[end] is (byte)'\\r' or (byte)'\\n')
                {
                    ValidateRecordEnd(line[(end + 1)..]);
                    return true;
                }
                start = end + 1;
            }
            nextField = start;
            return false;
        }""",
     """                if (end == line.Length) return !buffered;
                if (line[end] is (byte)'\\r' or (byte)'\\n')
                    return DescribeLiteralTerminator(line, end, buffered, out boundary);
                start = end + 1;
            }
            boundary = start;
            return false;
        }

        private bool DescribeLiteralTerminator(ReadOnlySpan<byte> line, int terminator, bool buffered, out int boundary)
        {
            boundary = terminator + 1;
            if (!buffered)
            {
                ValidateRecordEnd(line[boundary..]);
                return true;
            }

            if (line[terminator] == (byte)'\\n') return true;
            if (boundary == line.Length) return false;
            if (line[boundary] == (byte)'\\n') boundary++;
            return true;
        }"""),
    ("""        private int FindLiteralQuote(ReadOnlySpan<byte> line, int offset, byte marker)
        {
            while (offset < line.Length)
            {
                _context.CheckExecution(_span);
                var count = Math.Min(4096, line.Length - offset);
                var close = line.Slice(offset, count).IndexOf(marker);
                if (close >= 0) return offset + close;""",
     """        private int FindLiteralQuote(ReadOnlySpan<byte> line, int offset, byte marker, bool buffered)
        {
            while (offset < line.Length)
            {
                _context.CheckExecution(_span);
                var count = Math.Min(4096, line.Length - offset);
                var window = line.Slice(offset, count);
                var close = buffered
                    ? window.IndexOfAny(marker, (byte)'\\r', (byte)'\\n') : window.IndexOf(marker);
                if (close >= 0) return window[close] == marker ? offset + close : -1;""")
])
change("LythonRuntime.TextFileHandle.Read.cs", [
    ("""                var end = TextLineScanning.FindLineEndByte(bytes, start, _newline);
                if (end == bytes.Length && !EndsWithTerminator()) return false;

                // The active read defers window cleanup through parsing and
                // admission. Retained fields still receive independent payload.
                Advance(end);
                _services.CheckExecution(null);
                fields = source.ConsumeBorrowedNativeLine(bytes[start..end], destination, dictionary);""",
     """                var length = 0;
                var described = _newline is TextNewlineMode.TranslateUniversal or TextNewlineMode.PreserveUniversal &&
                    source.TryDescribeBufferedNativeRecord(bytes[start..], out length);
                var end = described ? start + length : TextLineScanning.FindLineEndByte(bytes, start, _newline);
                if (!described && end == bytes.Length && !EndsWithTerminator()) return false;

                // The active read defers window cleanup through parsing and
                // admission. Retained fields still receive independent payload.
                Advance(end);
                _services.CheckExecution(null);
                fields = source.ConsumeBorrowedNativeLine(bytes[start..end], destination, dictionary, described);""")
])
(lab / "candidate.patch").write_text("".join(patch), encoding="utf-8", newline="\n")
