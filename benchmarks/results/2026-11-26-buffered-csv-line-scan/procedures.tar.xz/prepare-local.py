from pathlib import Path
import hashlib
import json
import os
import shutil
import subprocess

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
local = lab / "local"
local.mkdir()
parent = lab.with_name("direct-record-helper-20261126")
template = lab.with_name("arithmetic-operand-outlining-20261126")
text_catalog = lab.with_name("direct-affix-return-20261126") / "comparison/quiet/representative.json"
source = lab / "candidate-source/src/Lokad.Lython"
read = lambda p: json.loads(p.read_text(encoding="utf-8"))
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
write = lambda p, s: p.write_text(s, encoding="utf-8", newline="\n")
save = lambda p, v: write(p, json.dumps(v, indent=2, ensure_ascii=False) + "\n")
state = read(lab / "identity.json")
original = state["baseImage"]
assert len(original) == 32 and {p.name: sha(p) for p in (parent / "candidate").iterdir()} == original
for role in ("candidate", "reference"):
    shutil.copytree(parent / "candidate", local / role)
    assert {p.name: sha(p) for p in (local / role).iterdir()} == original
core = source / "bin/Release/net11.0/Lokad.Lython.dll"
shutil.copyfile(core, local / "candidate" / core.name)
candidate = {p.name: sha(p) for p in (local / "candidate").iterdir()}
assert {name for name in original if original[name] != candidate[name]} == {core.name}
catalog = read(lab / "cases.json")
cases = [{k:v for k,v in item.items() if k != "runAsync"} for item in catalog["cases"] if not item["runAsync"]]
text_id = "diagnostic.text-summary.nonlocal-computed-width.large"
text_case = [c for c in read(text_catalog)["cases"] if c["id"] == text_id]
assert len(text_case) == 1
catalog["cases"] = cases + text_case
assert len({row["id"] for row in catalog["cases"]}) == 5
save(local / "representative.json", catalog)
save(local / "jobs.json", {"warm":[
    ["diagnostic.shipment-routing-callbacks", "warm-async"],
    ["diagnostic.shipment-file-fed-map", "warm-async"],
    [text_id, "warm"],
    ["scripts.csv-invoice.method-policy.quoted-control", "warm-async"],
    ["diagnostic.shipment-routing-callbacks", "warm"],
]})
worker = repo / "benchmarks/cpython-worker.py"
shutil.copyfile(worker, local / "cpython-worker.py")
identity = dict(sourceRevision=state["referenceRevision"], sourcePatchSHA256=sha(lab / "candidate.patch"),
                purpose="Compare one physical line search on literal rows against the existing buffered CSV path.",
                cpythonWorkerSHA256=sha(worker), imageFiles={"candidate":candidate, "reference":original},
                coreSHA256={role + suffix: files[core.name]
                            for role, files in (("candidate", candidate), ("reference", original))
                            for suffix in ("", "-control")},
                catalogs={name:{"sha256":sha(local / name)} for name in ("representative.json", "jobs.json")})
save(local / "identity.json", identity)

collect = (template / "local/collect.py").read_text(encoding="utf-8")
for old, new in (("len(jobs) == 3", "len(jobs) == 5"),
                 ("lython-arithmetic-fixture-", "lython-csv-window-fixture-")):
    assert collect.count(old) == 1
    collect = collect.replace(old,new)
write(local / "collect.py", collect)
shutil.copyfile(template / "local/run.sh", local / "run.sh")
launcher = (template / "run-local.sh").read_text(encoding="utf-8").replace(
    "arithmetic-operand-outlining-20261126", lab.name).replace("150s", "210s")
write(lab / "run-local.sh", launcher)
assert all(b"\r" not in file.read_bytes() for file in (lab/"run-local.sh", local/"run.sh"))
summary = (template / "summarize.py").read_text(encoding="utf-8").replace(
    "['warmJobs'] == 3", "['warmJobs'] == 5").replace("len(raw['jobs']) == 3", "len(raw['jobs']) == 5").replace("timedBatches=84","timedBatches=140")
write(lab / "summarize.py", summary)
for path in (local/"collect.py", lab/"summarize.py"):
    compile(path.read_text(encoding="utf-8"), str(path), "exec")

sdk = Path.home()/".dotnet11"
dotnet = sdk/"dotnet.exe"
env = dict(os.environ, DOTNET_ROOT=str(sdk), DOTNET_ROOT_X64=str(sdk))
for role in ("candidate", "reference"):
    report = local / (role + "-verify.json")
    subprocess.run([dotnet, local/role/"Lokad.Lython.Benchmarks.dll", "--compare", "verify",
                    "--catalog", local/"representative.json", "--dotnet", dotnet, "--python",
                    "C:/Python313/python.exe","--python-worker", worker, "--out", report],
                   cwd=repo, env=env, check=True, timeout=85)
    result = read(report)
    assert result["state"] == "Completed" and result["caseCount"] == 5
    assert result["launched"]["library"]["sha256"] == identity["coreSHA256"][role]
    assert result["catalogSha256"] == identity["catalogs"]["representative.json"]["sha256"]
