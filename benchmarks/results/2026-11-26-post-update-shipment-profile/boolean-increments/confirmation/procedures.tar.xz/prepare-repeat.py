from pathlib import Path
import base64, hashlib, json, os, shutil, subprocess
from datetime import datetime, timedelta, timezone

lab=Path(__file__).resolve().parent
first=lab/'comparison/quiet'
repeat=lab/'repeat/comparison/quiet'
repeat.mkdir(parents=True,exist_ok=True)
read=lambda name:json.loads((first/name).read_text(encoding='utf-8'))
digest=lambda content:hashlib.sha256(content).hexdigest()
record=read('terminal-status.json')
assert record['exitCode']=='0' and record['receipt']['allWorkersJoined']
raw=record['receipt']['archiveSHA256']
assert digest((first/'observations.tar.xz').read_bytes())==raw
identity=read('identity.json')
assert all({p.name:digest(p.read_bytes()) for p in (lab/'frozen'/role).iterdir()}==files
           for role,files in identity['imageFiles'].items())

jobs=read('jobs.json')
jobs['warm'].reverse()
jobs['warm']=[jobs['warm'][1],jobs['warm'][0],jobs['warm'][2],jobs['warm'][3]]
files={'jobs.json':(json.dumps(jobs,indent=2)+'\n').encode()}
identity['catalogs']['jobs.json']['sha256']=digest(files['jobs.json'])
identity['purpose']='Confirm exact B1766 CPU on the same images with fresh workers, longer batches and reordered jobs.'
files['identity.json']=(json.dumps(identity,indent=2,ensure_ascii=False)+'\n').encode()
collector=(first/'collect.py').read_text(encoding='utf-8')
for source,target in (('targetBatchSeconds=.44','targetBatchSeconds=.70'),
                      ('if job_index % 2 == 0','if job_index % 2 != 0'),
                      ('accumulate 7 seconds','accumulate 5 seconds'),
                      ('lython-b1766-fixtures','lython-b1766-repeat-fixtures')):
    assert collector.count(source)==1,source
    collector=collector.replace(source,target)
compile(collector,'collect.py','exec')
files['collect.py']=collector.encode()
for name in ('run.sh','representative.json','cpython-worker.py'):
    files[name]=(first/name).read_bytes()
assert b'\r' not in files['run.sh']
for name,content in files.items():
    (repeat/name).write_bytes(content)
dest='boolean-increments-b1766-repeat-20261126'
unit='lython-b1766-repeat-boolean-increments-20261126'
upload=read('upload.json')
upload['root']=dest
(repeat/'upload.json').write_text(json.dumps(upload),encoding='utf-8')
script=(lab/'quiet.py').read_text(encoding='utf-8').replace(
    'lython-b1766-boolean-increments-20261126',unit)
(lab/'repeat/quiet.py').write_text(script,encoding='utf-8')
shutil.copyfile(lab/'summarize-quiet.py',lab/'repeat/summarize-quiet.py')
data=dict(previous=read('upload.json')['root'],destination=dest,unit=unit,archive=raw,
          files={k:base64.b64encode(v).decode() for k,v in files.items()})
remote=r'''
from pathlib import Path
import base64, fcntl, hashlib, json, os, shutil, subprocess
base=Path('/home/lokad/lython-bench-checks')
root=base/cfg['destination']
previous=base/cfg['previous']
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert base.resolve()==base and root.resolve()==root and previous.resolve()==previous
with (base/'comparison-vm.lock').open('a') as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert not root.exists() and shutil.disk_usage(base).free>=6*1024*1024
 old=json.loads((previous/'archive-receipt.json').read_text())
 assert old['complete'] and old['allWorkersJoined'] and old['guestFixturesRemoved']
 assert cfg['archive']==old['archiveSHA256']==sha(previous/'observations.tar.xz')
 files={k:base64.b64decode(v) for k,v in cfg['files'].items()}
 assert set(files)=={'jobs.json','identity.json','collect.py','run.sh','representative.json','cpython-worker.py'}
 identity=json.loads(files['identity.json'])
 for role,expected in identity['imageFiles'].items():
  assert role in ('reference','candidate') and len(expected)==32
  assert {p.name:sha(p) for p in (previous/role).iterdir()}==expected
 root.mkdir()
 for role in identity['imageFiles']: (root/role).symlink_to((previous/role).resolve(),target_is_directory=True)
 for name,content in files.items(): (root/name).write_bytes(content)
 for name,metadata in identity['catalogs'].items(): assert sha(root/name)==metadata['sha256']
 sdk=Path.home()/'lython-bench-toolchains/dotnet/11.0.100-rc.3.26522.148'
 python=Path.home()/'lython-bench-toolchains/cpython/3.13.16/bin/python3.13'
 assert sha(python)==identity['expectedCPythonSHA256']
 receipt=root/'remote-verify.json'
 subprocess.run([sdk/'dotnet',root/'candidate/Lokad.Lython.Benchmarks.dll','--compare','verify',
                 '--catalog',root/'representative.json','--dotnet',sdk/'dotnet','--python',python,
                 '--python-worker',root/'cpython-worker.py','--out',receipt],
                cwd=root,env=dict(os.environ,DOTNET_ROOT=str(sdk)),check=True,timeout=35)
 report=json.loads(receipt.read_text())
 assert report['state']=='Completed' and report['caseCount']==3
 assert report['catalogSha256']==identity['catalogs']['representative.json']['sha256']
 print(json.dumps(dict(free=shutil.disk_usage(base).free,donorArchiveSHA256=cfg['archive'])),flush=True)
subprocess.run(['sudo','-n','systemd-run','--unit='+cfg['unit'],'--property=User=lokad',
                '--property=WorkingDirectory='+str(root),'--property=RuntimeMaxSec=250',
                '--property=TimeoutStopSec=20','--property=KillMode=control-group',
                '/bin/sh',str(root/'run.sh')],check=True)
'''
command=['ssh','-i',str(Path.home()/'.ssh/id_lython-bench.pem'),'-o','BatchMode=yes','-o','ConnectTimeout=12',
         'lokad@20.166.121.73','python3 -']
result=subprocess.run(command,input='cfg='+repr(data)+'\n'+remote,encoding='utf-8',capture_output=True,timeout=58)
(repeat/'launch.log').write_text(result.stdout+result.stderr,encoding='utf-8')
print(result.stdout+result.stderr)
result.check_returncode()
(repeat/'observe-not-before').write_text((datetime.now(timezone.utc)+timedelta(seconds=198)).isoformat(),encoding='utf-8')
