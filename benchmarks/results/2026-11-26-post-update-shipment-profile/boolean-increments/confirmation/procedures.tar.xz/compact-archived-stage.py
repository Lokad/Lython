from pathlib import Path
import hashlib, json, os, shutil, subprocess, sys
lab=Path(__file__).resolve().parent
old=lab.parent/'direct-zip-starmap-20261126'
archive=old/'comparison/quiet'
quiet=lab/'comparison/quiet'
quote=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
files=json.loads((archive/'identity.json').read_text(encoding='utf-8'))['imageFiles']
receipt=json.loads((archive/'terminal-status.json').read_text(encoding='utf-8'))
digest=quote(archive/'observations.tar.xz')
assert receipt['exitCode']=='0' and digest==receipt['receipt']['archiveSHA256']
for role,manifest in files.items():
    assert len(manifest)==32 and {k:quote(old/role/k) for k in manifest}==manifest
upload=json.loads((quiet/'upload.json').read_text(encoding='utf-8'))
config=dict(files=files,raw=digest,minimum=upload['payloadBytes']+13*1024*1024)
remote=r'''
from pathlib import Path
from tempfile import NamedTemporaryFile
import fcntl, gzip, hashlib, json, os, shutil, stat, subprocess
base=Path('/home/lokad/lython-bench-checks')
root=base/'direct-zip-starmap-b1749-20261126'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert base.resolve()==base and root.resolve()==root and root.parent==base
with (base/'comparison-vm.lock').open('a') as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 before=shutil.disk_usage(base).free
 for unit in ('lython-b1749-direct-zip-starmap-20261126','lython-b1749b-direct-zip-starmap-20261126'):
  props=subprocess.run(['systemctl','show',unit+'.service','--property=ActiveState,MainPID'],
                       text=True,capture_output=True).stdout.splitlines()
  assert 'MainPID=0' in props and ('ActiveState=failed' in props or 'ActiveState=inactive' in props),props
 record=json.loads((root/'archive-receipt.json').read_text())
 assert record['complete'] and record['allWorkersJoined'] and record['guestFixturesRemoved']
 assert record['archiveSHA256']==cfg['raw']==sha(root/'observations.tar.xz')
 assert not (root/'guest-fixtures').exists()
 targets=[]
 for role,manifest in cfg['files'].items():
  folder=root/role
  assert folder.resolve()==folder and {p.name:sha(p) for p in folder.iterdir()}==manifest
  source=folder/'Lokad.Lython.dll'
  destination=root/f'{role}-frozen-core.dll.gz'
  info=source.lstat()
  assert source.resolve()==source and stat.S_ISREG(info.st_mode) and info.st_nlink==1
  assert not destination.exists() and not destination.is_symlink()
  targets.append((source,destination,manifest[source.name],info.st_size))
 for other in base.iterdir():
  if not other.is_dir() or other.is_symlink(): continue
  for role in cfg['files']:
   folder=other/role
   assert not folder.is_symlink() or not folder.resolve().is_relative_to(root)
   path=folder/'Lokad.Lython.dll'
   assert not path.is_symlink() or not path.resolve().is_relative_to(root)
 archived=[]
 try:
  for source,destination,digest,size in targets:
   with NamedTemporaryFile(dir=root,delete=False) as scratch:
    temporary=Path(scratch.name)
    archived.append((source,destination,digest,size,temporary))
    with source.open('rb') as read, gzip.GzipFile(fileobj=scratch,mode='wb',mtime=0) as out:
     shutil.copyfileobj(read,out)
   with gzip.open(temporary,'rb') as stream:
    assert hashlib.file_digest(stream,'sha256').hexdigest()==digest
  predicted=shutil.disk_usage(base).free+sum(size for _,_,_,size,_ in archived)-65536
  assert predicted>cfg['minimum'],(before,predicted,cfg['minimum'])
  for source,destination,digest,size,temporary in archived:
   os.replace(temporary,destination)
   assert sha(source)==digest
   source.unlink()
 finally:
  for _,_,_,_,temporary in archived:
   if temporary.is_file(): temporary.unlink()
 print(json.dumps(dict(freeBeforeBytes=before,freeAfterBytes=shutil.disk_usage(base).free,
     observationsSHA256=cfg['raw'],archived=[dict(source=str(s.relative_to(base)),
     compressed=str(d.relative_to(base)),sha256=h,gzipSHA256=sha(d)) for s,d,h,_,_ in archived])))
'''
identity=Path.home()/'.ssh/id_lython-bench.pem'
command=['ssh','-i',str(identity),'-o','BatchMode=yes','-o','ConnectTimeout=12','lokad@20.166.121.73','python3 -']
result=subprocess.run(command,input='cfg='+repr(config)+'\n'+remote,encoding='utf-8',capture_output=True,timeout=45,check=False)
if result.returncode!=0:
    print(result.stderr,file=sys.stderr)
    result.check_returncode()
(quiet/'quiet-custody.json').write_text(result.stdout,encoding='utf-8')
print(result.stdout)
