from pathlib import Path
import ast
import hashlib
import json
import os
import shutil
import subprocess
import tarfile

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
quiet = lab/"comparison/quiet"
quiet.mkdir(parents=True)
parent = lab.with_name("converted-dictionary-update-20261126")
old = parent
template = old/"comparison/quiet"
route = lab.with_name("boolean-increment-candidate-routes-20261126")
read = lambda p:json.loads(p.read_text(encoding="utf-8"))
sha = lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
write = lambda p,t:p.write_text(t,encoding="utf-8",newline="\n")
save = lambda p,data:write(p,json.dumps(data,indent=2,ensure_ascii=False)+"\n")
identity = read(lab/"frozen-identity.json")
assert sha(lab/"candidate.patch")==identity["sourcePatchSHA256"]
assert sum(item["routes"]["AugmentedAddBooleanIntegerRoute"] for item in read(route/"routes.json")["rows"])==8192
catalog = read(template/"representative.json")
text_id = "diagnostic.text-summary.nonlocal-computed-width.large"
shipment = "diagnostic.shipment-routing-callbacks"
meter = "scripts.csv-meter-report.typed-unicode"
catalog["cases"] = [row for row in catalog["cases"] if row["id"] in {text_id,shipment}]
catalog["cases"] += [row for row in read(lab.with_name("arithmetic-operand-outlining-20261126")/"representative.json")["cases"]
                     if row["id"]==meter]
assert len({row["id"] for row in catalog["cases"]})==3
save(quiet/"representative.json",catalog)
save(quiet/"jobs.json",{"warm":[
    [shipment,"warm-async"],
    [meter,"warm"],
    [text_id,"warm"],
    [shipment,"warm"],
]})
worker=repo/"benchmarks/cpython-worker.py"
shutil.copyfile(worker,quiet/"cpython-worker.py")
assert sha(worker)==identity["cpythonWorkerSHA256"]
identity["catalogs"]={name:{"sha256":sha(quiet/name)} for name in ("representative.json","jobs.json")}
identity["purpose"]="Assess exact computed boolean increments in the existing integer path."
identity["expectedCPythonSHA256"]=read(template/"identity.json")["expectedCPythonSHA256"]
save(quiet/"identity.json",identity)
sdk=Path.home()/".dotnet11"
dotnet=sdk/"dotnet.exe"
env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk))
for role,files in identity["imageFiles"].items():
    image=lab/"frozen"/role
    assert len(files)==32 and {p.name:sha(p) for p in image.iterdir()}==files
    proof=quiet/(role+"-verify.json")
    subprocess.run([dotnet,image/"Lokad.Lython.Benchmarks.dll","--compare","verify","--catalog",quiet/"representative.json",
                    "--dotnet",dotnet,"--python","C:/Python313/python.exe","--python-worker",worker,"--out",proof],
                   cwd=repo,env=env,check=True,timeout=88)
    verified=read(proof)
    assert verified["state"]=="Completed" and verified["caseCount"]==3
    assert verified["catalogSha256"]==identity["catalogs"]["representative.json"]["sha256"]
    assert verified["launched"]["library"]["sha256"]==files["Lokad.Lython.dll"]

source=(template/"collect.py").read_text(encoding="utf-8")
for a,b in (("len(jobs) == 6","len(jobs) == 4"),("lython-b1763-fixtures","lython-b1766-fixtures")):
    assert source.count(a)==1,a
    source=source.replace(a,b)
tree=ast.parse(source)
keys={node.slice.value for node in ast.walk(tree) if isinstance(node,ast.Subscript) and isinstance(node.value,ast.Name)
      and node.value.id=="identity" and isinstance(node.slice,ast.Constant)}
assert keys<=identity.keys(),sorted(keys-identity.keys())
compile(tree,"collect.py","exec")
write(quiet/"collect.py",source)
shutil.copyfile(template/"run.sh",quiet/"run.sh")
assert b"\r" not in (quiet/"run.sh").read_bytes()
files=[("new-core.dll",lab/"frozen/candidate/Lokad.Lython.dll")]
files += [(name,quiet/name) for name in ("identity.json","representative.json","jobs.json","collect.py","run.sh","cpython-worker.py")]
payload=quiet/"stage.tar.gz"
with tarfile.open(payload,"w:gz",compresslevel=6) as package:
    for name,path in files:package.add(path,arcname=name,recursive=False)
root="boolean-increments-b1766-20261126"
donor=parent/"comparison/quiet"
donor_receipt=read(donor/"terminal-status.json")["receipt"]
assert donor_receipt["complete"] and sha(donor/"observations.tar.xz")==donor_receipt["archiveSHA256"]
save(quiet/"upload.json",dict(root=root,payloadSHA256=sha(payload),payloadBytes=payload.stat().st_size,
                             donorSHA256=donor_receipt["archiveSHA256"]))
body=(old/"quiet.py").read_text(encoding="utf-8").replace(
    "lython-b1763-converted-dictionary-update-20261126","lython-b1766-boolean-increments-20261126")
body=body.replace("base/'direct-record-helper-b1759-20261126'","base/'converted-dictionary-update-b1763-20261126'")
body=body.replace("verified['caseCount']==5","verified['caseCount']==3")
body=body.replace("RuntimeMaxSec=278","RuntimeMaxSec=214").replace("seconds=233","seconds=172")
compile(body,"quiet.py","exec")
write(lab/"quiet.py",body)
summary=(old/"summarize-quiet.py").read_text(encoding="utf-8").replace(
    "['warmJobs'] == 6","['warmJobs'] == 4").replace("len(raw['jobs']) == 6","len(raw['jobs']) == 4")
summary=summary.replace("timedBatches=168","timedBatches=112")
compile(summary,"summarize-quiet.py","exec")
write(lab/"summarize-quiet.py",summary)


stages=[]
for name,tag in (("zip-unpack","b1665"),("single-comparison","b1668")):
    earlier=lab.with_name(name+"-20261125")
    original=earlier/"comparison/quiet"
    repeat=earlier/"confirmation"
    records=[]
    for place in (original,repeat):
        status=read(place/"terminal-status.json")
        receipt=status["receipt"]
        assert not status["live"] and receipt["complete"] and receipt["allWorkersJoined"] and receipt["guestFixturesRemoved"]
        assert sha(place/"observations.tar.xz")==receipt["archiveSHA256"]
        records.append((read(place/"identity.json")["imageFiles"]["candidate"],receipt["archiveSHA256"]))
    (original_files,original_raw),(repeat_files,repeat_raw)=records
    dll="Lokad.Lython.dll"
    assert len(original_files)==len(repeat_files)==32 and original_files[dll]==repeat_files[dll]
    assert {p.name:sha(p) for p in (earlier/"candidate").iterdir()}==original_files
    stages.append(dict(original=f"{name}-{tag}-20261125",repeat=f"{name}-confirm-{tag}-20261125",
                       unit=f"lython-{tag}-{name}-confirm-20261125",originalRaw=original_raw,repeatRaw=repeat_raw,
                       originalFiles=original_files,repeatFiles=repeat_files))
minimum=payload.stat().st_size+sum(path.stat().st_size for _,path in files)+12*1024*1024
custody = "cfg="+repr(dict(stages=stages,minimum=minimum))+chr(10)+"""
from pathlib import Path
import fcntl, hashlib, json, os, shutil, subprocess
base=Path('/home/lokad/lython-bench-checks')
assert base.resolve()==base
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
with (base/'comparison-vm.lock').open('a') as lease:
    fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
    before=shutil.disk_usage(base).free
    linked=[]
    target=before
    for item in cfg['stages']:
        if target>=cfg['minimum']: break
        original,repeat=(base/item[k] for k in ('original','repeat'))
        assert all(p.resolve()==p and p.parent==base for p in (original,repeat))
        props=subprocess.run(['systemctl','show',item['unit']+'.service','--property=ActiveState,MainPID'],
                             text=True,capture_output=True,check=True).stdout.splitlines()
        assert 'MainPID=0' in props and 'ActiveState=inactive' in props
        expected=item['originalFiles'],item['repeatFiles']
        for root,raw,files in zip((original,repeat),(item['originalRaw'],item['repeatRaw']),expected,strict=True):
            receipt=json.loads((root/'archive-receipt.json').read_text())
            assert receipt['complete'] and receipt['allWorkersJoined'] and receipt['guestFixturesRemoved']
            assert receipt['archiveSHA256']==raw==sha(root/'observations.tar.xz')
            folder=root/'candidate'
            assert folder.resolve()==folder and {p.name:sha(p) for p in folder.iterdir()}==files
        a,b=(root/'candidate/Lokad.Lython.dll' for root in (original,repeat))
        assert a.resolve()==a and b.resolve()==b and b.stat().st_nlink==1 and sha(a)==sha(b)
        temporary=b.with_suffix('.bench-custody-link')
        assert not temporary.exists() and not temporary.is_symlink()
        linked.append((a,b,temporary,item['repeatFiles']))
        target+=b.stat().st_size
    assert target>=cfg['minimum'],(before,target,cfg['minimum'])
    for a,b,temporary,files in linked:
        temporary.symlink_to(a)
        os.replace(temporary,b)
        assert b.resolve()==a and {p.name:sha(p) for p in b.parent.iterdir()}==files
    print(json.dumps(dict(freeBeforeBytes=before,freeAfterBytes=shutil.disk_usage(base).free,
                         projectedMinimum=cfg['minimum'],coalesced=[dict(path=str(b.relative_to(base)),
                         canonical=str(a.relative_to(base)),sha256=sha(a)) for a,b,_,_ in linked])))
"""
write(lab/"verify-staging-custody.py",custody)
remote=["ssh","-i",os.environ["LYTHON_BENCH_IDENTITY"],"-o","BatchMode=yes","-o","ConnectTimeout=12",
        os.environ["LYTHON_BENCH_HOST"],"python3 -"]
result=subprocess.check_output(remote,input=custody,encoding="utf-8",timeout=49)
save(lab/"quiet-custody.json",json.loads(result))
print(result,end="")
