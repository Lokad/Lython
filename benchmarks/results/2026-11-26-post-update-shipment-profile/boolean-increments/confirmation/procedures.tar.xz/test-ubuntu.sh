set -eu
export DOTNET_ROOT="$HOME/.dotnet"
export PATH="$DOTNET_ROOT:$PATH"
lab="$PWD/.git/agent-notes/review-20261031/post-update-arithmetic-routes-20261126"
cd "$lab/candidate-source"
for suite in Lokad.Lython.Tests Lokad.Lython.PublicApi.Tests; do
  if [ "$suite" = Lokad.Lython.Tests ]; then
    filter='Category!=Stress&(FullyQualifiedName~NativeOperand|FullyQualifiedName~Stack|FullyQualifiedName~Integer)'
  else
    filter='Category!=Stress&(FullyQualifiedName~Augmented|FullyQualifiedName~Integer|FullyQualifiedName~ConvertedDictionaryUpdate|FullyQualifiedName~RecordField|FullyQualifiedName~StackAdmission)'
  fi
  log="$lab/$suite-ubuntu10.log"
  if dotnet test "tests/$suite/$suite.csproj" -c Release -f net10.0 --artifacts-path "$lab/ubuntu" --filter "$filter" > "$log" 2>&1; then
    tail -5 "$log"
  else
    tail -40 "$log"
    exit 1
  fi
done
