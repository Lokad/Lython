from difflib import unified_diff
from pathlib import Path
import hashlib,json,os,shutil,subprocess,zipfile

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
parent=lab.with_name("converted-dictionary-update-20261126")
manifest_dir=parent/"comparison/quiet"
template=lab.with_name("shipment-integer-store-20261126")
read=lambda p:json.loads(p.read_text(encoding="utf-8"))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
write=lambda p,t:p.write_text(t,encoding="utf-8",newline="\n")
baseline=subprocess.check_output(["git","rev-parse","7f7c4ed59"],cwd=repo,text=True).strip()
assert not subprocess.check_output(["git","diff",baseline,"--","src"],cwd=repo)
snapshot=lab/"source.zip"
subprocess.run(["git","archive","--format=zip","--output",snapshot,baseline,"--","src",
                "Directory.Build.props","Directory.Build.targets","Directory.Build.rsp",
                "Directory.Packages.props","global.json","NuGet.Config"],cwd=repo,check=True)
source=lab/"source"
with zipfile.ZipFile(snapshot) as archive:
    assert all(not Path(name).is_absolute() and ".." not in Path(name).parts for name in archive.namelist())
    archive.extractall(source)
catalog=read(manifest_dir/"representative.json")
assert len(catalog["cases"])==5
catalog["cases"]=[case|dict(runAsync=mode) for case in catalog["cases"] for mode in (False,True)]
write(lab/"cases.json",json.dumps(catalog,ensure_ascii=False))

names=["ExecutableArithmetic","AugmentedAdd","AugmentedAddBooleanRhs","AugmentedAddBooleanMachineLeft",
       "AugmentedAddBooleanIntegerRoute","AugmentedAddBooleanOtherRoute"]
relative="src/Lokad.Lython/Runtime/LythonRuntime.Executable.Arithmetic.cs"
path=source/relative
old=path.read_text(encoding="utf-8")
fields="".join(f"    internal static int Diagnostic{name};\n" for name in names)
new=old.replace("    internal sealed partial class ExecutionContext\n",fields+"\n    internal sealed partial class ExecutionContext\n")
anchor="""            try
            {
                var end = execution.InstructionIndex;"""
assert new.count(anchor)==1
new=new.replace(anchor,"""            Interlocked.Increment(ref DiagnosticExecutableArithmetic);
            var augmentedAdd = instruction.OpCode == ExecutableOpCode.Augmented &&
                instruction.AugmentedOperator == AugmentedAssignmentOperatorSyntax.Add;
            var boolean = augmentedAdd && instruction.SecondInput >= 0 &&
                execution.Stack.Values[instruction.SecondInput].Reference is bool;
            if (augmentedAdd) Interlocked.Increment(ref DiagnosticAugmentedAdd);
            if (boolean)
            {
                Interlocked.Increment(ref DiagnosticAugmentedAddBooleanRhs);
                if (instruction.InputStart >= 0 && execution.Stack.Values[instruction.InputStart].TryGetInteger(out _))
                    Interlocked.Increment(ref DiagnosticAugmentedAddBooleanMachineLeft);
            }
"""+anchor)
needle="""                if (!completed && !TryEvaluateBuiltinArithmetic"""
assert new.count(needle)==1
new=new.replace(needle,"""                if (boolean)
                {
                    if (completed) Interlocked.Increment(ref DiagnosticAugmentedAddBooleanIntegerRoute);
                    else Interlocked.Increment(ref DiagnosticAugmentedAddBooleanOtherRoute);
                }
"""+needle)
write(path,new)
write(lab/"diagnostic.patch","".join(unified_diff(old.splitlines(keepends=True),new.splitlines(keepends=True),
                                                "a/"+relative,"b/"+relative)))
program=(template/"Program.cs").read_text(encoding="utf-8")
program=program.replace('["IntegerStoreCandidates", "IntegerStoreExisting", "IntegerStoreNativePrefix", "IntegerStorePackedKeys"]',
                        json.dumps(names)).replace("Lokad.Lython.Runtime.LythonRuntime+ExecutionContext",
                                                    "Lokad.Lython.Runtime.LythonRuntime")
write(lab/"Program.cs",program)
shutil.copyfile(template/"RouteProbe.csproj",lab/"RouteProbe.csproj")
original=read(manifest_dir/"identity.json")["imageFiles"]["candidate"]
candidate=parent/"frozen/candidate"
assert len(original)==32 and {p.name:sha(p) for p in candidate.iterdir()}==original
image=lab/"image"
image.mkdir()
for name,digest in original.items():
    shutil.copyfile(candidate/name,image/name)
    assert sha(image/name)==digest
sdk=Path.home()/".dotnet11"
dotnet=sdk/"dotnet.exe"
env=dict(os.environ,DOTNET_ROOT=str(sdk))
def run(args,name):
    with (lab/name).open("wb") as log:
        subprocess.run([dotnet,*args],stdout=log,stderr=subprocess.STDOUT,env=env,cwd=repo,check=True,timeout=165)
run(["build",source/"src/Lokad.Lython/Lokad.Lython.csproj","-c","Release","-f","net11.0","--no-incremental",
     "-o",lab/"core"],"core.log")
shutil.copyfile(lab/"core/Lokad.Lython.dll",image/"Lokad.Lython.dll")
run(["build",lab/"RouteProbe.csproj","-c","Release","-o",lab/"probe"],"probe.log")
for item in (lab/"probe").glob("RouteProbe*"):shutil.copyfile(item,image/item.name)
run([image/"RouteProbe.dll",image,lab/"cases.json",lab/"routes.json"],"verify.log")
write(lab/"identity.json",json.dumps(dict(sourceRevision=baseline,baseImage=original,
      diagnosticCoreSHA256=sha(image/"Lokad.Lython.dll"),catalogSHA256=sha(lab/"cases.json"),
      diagnosticPatchSHA256=sha(lab/"diagnostic.patch")),indent=2)+"\n")
for row in read(lab/"routes.json")["rows"]:
    print(row["id"],row["asynchronous"],row["routes"])
