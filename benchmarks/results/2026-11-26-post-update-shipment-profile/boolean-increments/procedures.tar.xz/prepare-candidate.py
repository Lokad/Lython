from difflib import unified_diff
from pathlib import Path
import subprocess
import zipfile

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
source=lab/"candidate-source"
source.mkdir()
snapshot=lab/"candidate-source.zip"
subprocess.run(["git","archive","--format=zip","--output",snapshot,"7f7c4ed59","--","src","tests",
                "benchmarks/Lokad.Lython.Benchmarks","benchmarks/scripts","tools/LythonProbe",
                "Directory.Build.props","Directory.Build.targets","Directory.Build.rsp","Directory.Packages.props","global.json","NuGet.Config"],cwd=repo,check=True)
with zipfile.ZipFile(snapshot) as archive:
    assert all(not Path(name).is_absolute() and ".." not in Path(name).parts for name in archive.namelist())
    archive.extractall(source)

name="src/Lokad.Lython/Runtime/LythonRuntime.Executable.Integers.cs"
path=source/name
text=path.read_text(encoding="utf-8")
old="""        if (instruction.OpCode is not (ExecutableOpCode.Binary or ExecutableOpCode.Augmented)
            || !TryReadMachineOperand(code, values, instruction.InputStart, context, out var left, captures)
            || !TryReadMachineOperand(code, values, instruction.SecondInput, context, out var right, captures)) return false;
"""
new="""        if (instruction.OpCode is not (ExecutableOpCode.Binary or ExecutableOpCode.Augmented)
            || !TryReadMachineOperand(code, values, instruction.InputStart, context, out var left, captures)) return false;
        if (!TryReadMachineOperand(code, values, instruction.SecondInput, context, out var right, captures))
        {
            // A completed boolean comparison supplies an exact increment.
            // Keep bool identity and boolean-only operations on their existing paths.
            if (instruction.OpCode != ExecutableOpCode.Augmented ||
                instruction.AugmentedOperator != AugmentedAssignmentOperatorSyntax.Add ||
                instruction.SecondInput < 0 || values[instruction.SecondInput].Reference is not bool increment)
                return false;
            right = increment ? 1 : 0;
        }
"""
assert text.count(old)==1
changed=text.replace(old,new)
path.write_text(changed,encoding="utf-8",newline="\n")
diff=unified_diff(text.splitlines(keepends=True),changed.splitlines(keepends=True),"a/"+name,"b/"+name)
(lab/"candidate.patch").write_text("".join(diff),encoding="utf-8",newline="\n")
