from pathlib import Path
import ast
import hashlib
import json
import os
import shutil
import subprocess
import tarfile

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
quiet=lab/"comparison/quiet"
quiet.mkdir(parents=True)
previous=lab.with_name("remaining-shipment-cpu-20261126")
template=previous/"comparison/quiet"
pair=lab.with_name("converted-dictionary-update-20261126")
donor=pair/"comparison/quiet"
checkpoint=lab.with_name("converted-update-cpython-20261126")/"comparison/quiet"
read=lambda p:json.loads(p.read_text(encoding="utf-8"))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
write=lambda p,t:p.write_text(t,encoding="utf-8",newline="\n")
save=lambda p,v:write(p,json.dumps(v,indent=2,ensure_ascii=False)+"\n")
base=read(donor/"identity.json")
receipt=read(donor/"terminal-status.json")["receipt"]
assert receipt["complete"] and receipt["allWorkersJoined"] and sha(donor/"observations.tar.xz")==receipt["archiveSHA256"]
head=subprocess.check_output(["git","rev-parse","HEAD"],cwd=repo).decode().strip()
assert head==read(checkpoint/"identity.json")["productionSource"]
assert not subprocess.check_output(["git","status","--porcelain","--","src"],cwd=repo)
image=pair/"frozen/candidate"
files=base["imageFiles"]["candidate"]
assert len(files)==32 and {p.name:sha(p) for p in image.iterdir()}==files
catalog=read(donor/"representative.json")
shipment="diagnostic.shipment-routing-callbacks"
text="diagnostic.text-summary.nonlocal-computed-width.large"
catalog["cases"]=[case for case in catalog["cases"] if case["id"] in {shipment,text}]
assert len(catalog["cases"])==2
save(quiet/"catalog.json",catalog)
identity=dict(sourceRevision=head,inspectedHead=head,sourceDifference=[],imageFiles={"candidate":files},
              coreSHA256={"candidate":files["Lokad.Lython.dll"]},donorArchiveSHA256=receipt["archiveSHA256"],
              profileCatalogSHA256=sha(quiet/"catalog.json"),
              profiles=[["shipment-after-update-async",shipment,"candidate"],["unicode-text-control-async",text,"candidate"]],
              purpose="Locate remaining shipment work after the complete dictionary update.")
save(quiet/"identity.json",identity)
for name in ("collect.py","ops-profile.py","analyze.py","run.sh"):
    source=(template/name).read_text(encoding="utf-8").replace(
        "short-path-cpython-b1750-20261126","converted-dictionary-update-b1763-20261126")
    source=source.replace("b1752-fixtures","b1765-fixtures").replace("15*1024*1024-256*1024","12*1024*1024-256*1024")
    if name.endswith(".py"):
        tree=ast.parse(source)
        compile(tree,name,"exec")
        if name=="collect.py":
            keys={n.slice.value for n in ast.walk(tree) if isinstance(n,ast.Subscript) and isinstance(n.value,ast.Name)
                   and n.value.id=="identity" and isinstance(n.slice,ast.Constant)}
            assert keys<=identity.keys(),sorted(keys-identity.keys())
    write(quiet/name,source)
assert b"\r" not in (quiet/"run.sh").read_bytes()
source=(previous/"quiet.py").read_text(encoding="utf-8")
for a,b in (("lython-b1752-shipment-cpu-20261126","lython-b1765-post-update-shipment-profile-20261126"),
            ("short-path-cpython-b1750-20261126","converted-dictionary-update-b1763-20261126"),
            ("cfg['payloadBytes']+15*1024*1024","cfg['payloadBytes']+12*1024*1024")):
    assert source.count(a)==1,a
    source=source.replace(a,b)
compile(source,"quiet.py","exec")
write(lab/"quiet.py",source)
worker=repo/"benchmarks/cpython-worker.py"
assert sha(worker)==base["cpythonWorkerSHA256"]
sdk=Path.home()/".dotnet11"
dotnet=sdk/"dotnet.exe"
env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk))
proof=quiet/"verification.json"
subprocess.run([dotnet,image/"Lokad.Lython.Benchmarks.dll","--compare","verify","--catalog",quiet/"catalog.json",
                "--dotnet",dotnet,"--python","C:/Python313/python.exe","--python-worker",worker,"--out",proof],
               cwd=repo,env=env,check=True,timeout=70)
report=read(proof)
assert report["state"]=="Completed" and report["caseCount"]==2 and report["catalogSha256"]==identity["profileCatalogSHA256"]
assert report["launched"]["library"]["sha256"]==files["Lokad.Lython.dll"]
payload=quiet/"stage.tar.gz"
with tarfile.open(payload,"w:gz",compresslevel=6) as package:
    for name in ("identity.json","catalog.json","collect.py","ops-profile.py","run.sh"):
        package.add(quiet/name,arcname=name,recursive=False)
save(quiet/"upload.json",dict(root="post-update-shipment-profile-b1765-20261126",payloadSHA256=sha(payload),
                             payloadBytes=payload.stat().st_size,expectedDonorArchiveSHA256=receipt["archiveSHA256"]))
