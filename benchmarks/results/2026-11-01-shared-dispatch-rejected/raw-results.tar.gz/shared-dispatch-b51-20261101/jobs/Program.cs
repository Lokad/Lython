using System.Diagnostics;
using System.Reflection;
using System.Runtime.Loader;
using System.Security.Cryptography;
using System.Text.Json;

// Existing complete-job diagnostic adapted to process CPU, wall and allocation controls.
var assemblyPath = Path.GetFullPath(args[0]);
var directory = Path.GetDirectoryName(assemblyPath)!;
AssemblyLoadContext.Default.Resolving += (_, name) => {
    var path = Path.Combine(directory, name.Name + ".dll");
    return File.Exists(path) ? AssemblyLoadContext.Default.LoadFromAssemblyPath(path) : null;
};
var benchmark = AssemblyLoadContext.Default.LoadFromAssemblyPath(assemblyPath);
var core = AssemblyLoadContext.Default.LoadFromAssemblyPath(Path.Combine(directory, "Lokad.Lython.dll"));
var engineType = core.GetType("Lokad.Lython.LythonEngine", true)!;
var engine = Activator.CreateInstance(engineType)!;
var budgetType = core.GetType("Lokad.Lython.LythonMemoryBudget", true)!;
var budget = Activator.CreateInstance(budgetType, [null])!;
var balance = budgetType.GetProperty("ReservedBytes")!;
var compile = engineType.GetMethod("Compile", [typeof(string), core.GetType("Lokad.Lython.ILythonMemoryBudget", true)!])!;
var fixtureType = benchmark.GetType("Lokad.Lython.Benchmarks.Comparison.ComparisonFileFixture", true)!;
var hostType = benchmark.GetType("Lokad.Lython.Benchmarks.Comparison.ComparisonFileHost", true)!;
var validateDirectory = benchmark.GetType("Lokad.Lython.Benchmarks.Comparison.OwnedWorkerProcess", true)!
    .GetMethod("ValidateFixtureDirectory", BindingFlags.Static | BindingFlags.Public | BindingFlags.NonPublic)!;
using var catalog = JsonDocument.Parse(File.ReadAllBytes(args[2]));
var cases = catalog.RootElement.GetProperty("cases").EnumerateArray().Where(c => c.GetProperty("id").GetString() == args[3]).ToArray();
if (cases.Length != 1 || args[3] is not ("scripts.text-summary-helpers.large" or "scripts.csv-summary-helpers.large" or "scripts.config-edit.large"))
    throw new InvalidDataException("Only the three frozen complete-job cases are allowed.");
var mode = args[4];
if (mode is not ("compile" or "compile-run" or "warm" or "warm-async")) throw new ArgumentException("Fixed phases only.");
var batch = mode == "compile" ? 4096 : 64;
var warmups = mode == "compile" ? 512 : 4;
using var process = Process.GetCurrentProcess();
var observations = new List<object>();
foreach (var item in cases)
{
    var id = item.GetProperty("id").GetString();
    var fixture = fixtureType.GetMethod("Parse")!.Invoke(null, [item.GetProperty("fixtureJson").GetString()])!;
    var owned = Path.Combine(Path.GetTempPath(), "lython-comparison-files-" + Guid.NewGuid().ToString("N"));
    var host = Activator.CreateInstance(hostType, BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance,
        null, [fixture, owned], null)!;
    var script = compile.Invoke(engine, [item.GetProperty("source").GetString(), budget])!;
    try
    {
        if (!(bool)script.GetType().GetProperty("IsValid")!.GetValue(script)!) throw new InvalidDataException("Invalid script: " + id);
        var run = script.GetType().GetMethods().Single(m => m.Name == (mode == "warm-async" ? "RunAsync" : "Run") && m.GetParameters().Length == 1);
        var taskResult = run.ReturnType.GetProperty("Result");
        object Run(object invocation)
        {
            var result = run.Invoke(invocation, [host])!;
            if (result is not Task pending) return result;
            pending.GetAwaiter().GetResult();
            return taskResult!.GetValue(result)!;
        }
        var compiledBaseline = (long)balance.GetValue(budget)!;
        long expectedBalance = -1;
        void Once()
        {
            var invocation = mode == "compile-run" ? compile.Invoke(engine, [item.GetProperty("source").GetString(), budget]) : null;
            try
            {
            hostType.GetMethod("Reset")!.Invoke(host, null);
            using ((IDisposable)(Run(invocation ?? script) is { } result ? result : throw new Exception("Missing result")))
            {
                if (!(bool)result.GetType().GetProperty("Success")!.GetValue(result)! ||
                    (string)result.GetType().GetProperty("StandardOutput")!.GetValue(result)! != item.GetProperty("expectedOutput").GetString() ||
                    (string)result.GetType().GetProperty("StandardError")!.GetValue(result)! != "")
                    throw new InvalidDataException("Complete stdout golden failed: " + id);
                var files = hostType.GetMethod("ReadOutputs")!.Invoke(host, null)!;
                if ((string)fixtureType.GetMethod("Digest")!.Invoke(null, [files])! != item.GetProperty("expectedFilesSha256").GetString())
                    throw new InvalidDataException("Complete file golden failed: " + id);
            }
            }
            finally { ((IDisposable?)invocation)?.Dispose(); }
            if (expectedBalance >= 0 && (long)balance.GetValue(budget)! != expectedBalance)
                throw new InvalidDataException("Execution ownership did not end.");
        }
        void TimedOnce()
        {
            if (mode != "compile") { Once(); return; }
            using (var fresh = (IDisposable)compile.Invoke(engine, [item.GetProperty("source").GetString(), budget])!)
            {
                if (!(bool)fresh.GetType().GetProperty("IsValid")!.GetValue(fresh)!) throw new InvalidDataException("Compilation failed.");
            }
            if (expectedBalance >= 0 && (long)balance.GetValue(budget)! != expectedBalance) throw new InvalidDataException("Compilation owner did not end.");
        }
        Once();
        for (var i = 0; i < warmups; i++) TimedOnce();
        expectedBalance = (long)balance.GetValue(budget)!;
        var times = new List<double>(); var allocations = new List<double>(); var cpuMilliseconds = new List<double>();
        for (var round = 0; round < 7; round++)
        {
            process.Refresh(); var cpuStart = process.TotalProcessorTime;
            var before = GC.GetTotalAllocatedBytes(true); var timer = Stopwatch.StartNew();
            for (var i = 0; i < batch; i++) TimedOnce();
            timer.Stop(); times.Add(timer.Elapsed.TotalMilliseconds / batch);
            allocations.Add((GC.GetTotalAllocatedBytes(true) - before) / (double)batch);
            process.Refresh(); cpuMilliseconds.Add((process.TotalProcessorTime - cpuStart).TotalMilliseconds);
        }
        Once();
        observations.Add(new { id, mode, compiledBaseline, steadyBaseline = expectedBalance, milliseconds = times, allocatedBytes = allocations,
            cpuMilliseconds, medianCpuMillisecondsPerJob = cpuMilliseconds.Order().ElementAt(3) / batch, cpuGranularityResolved = cpuMilliseconds.All(t => t > 100),
            medianMilliseconds = times.Order().ElementAt(3), medianAllocatedBytes = allocations.Order().ElementAt(3) });
    }
    finally
    {
        ((IDisposable)script).Dispose();
        if ((long)balance.GetValue(budget)! != 0) throw new InvalidDataException("Compiled owner did not end.");
        // The existing supervisor validates this generated, owned temporary
        // target before the one native-shell-free cleanup operation.
        validateDirectory.Invoke(null, [owned]);
        if (Directory.Exists(owned)) Directory.Delete(owned, recursive: true);
    }
}
var identities = Directory.EnumerateFiles(directory, "Lokad.*.dll").ToDictionary(p => Path.GetFileName(p)!,
    p => Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(p))));
Console.WriteLine(JsonSerializer.Serialize(new { revision = args[1],
    catalogSHA256 = Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(args[2]))),
    boundary = mode == "compile" ? "Public compilation/validity/disposal, same source; startup/guest execution excluded; full goldens before/after" : "Complete public execution/fixture reset/mediated I/O/goldens/disposal; compile-run includes fresh compilation and disposal; common reflection overhead", warmups, rounds = 7, batch,
    observations, runtime = Environment.Version.ToString(), os = System.Runtime.InteropServices.RuntimeInformation.OSDescription,
    processId = Environment.ProcessId, processors = Environment.ProcessorCount, identities, performanceQualified = false }));
