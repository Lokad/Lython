from pathlib import Path
import hashlib, json, os, shutil, subprocess, tarfile

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
donor = lab.with_name("prepared-default-pair-boundaries-refined-20261124")
previous = donor / "comparison/quiet"
quiet = lab / "comparison/quiet"
quiet.mkdir(parents=True, exist_ok=True)
read = lambda p: json.loads(p.read_text(encoding="utf-8-sig"))
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
digest = lambda data: hashlib.sha256(data.encode("utf-8")).hexdigest()
save = lambda p, v: p.write_text(json.dumps(v, ensure_ascii=False, indent=2) + "\n", encoding="utf-8", newline="\n")
base = read(previous / "identity.json")
core = "Lokad.Lython.dll"
head = subprocess.check_output(["git","rev-parse","HEAD"],cwd=repo,text=True).strip()
assert head.startswith("654037855")
assert subprocess.check_output(["git","diff","--binary",base["sourceRevision"],head,"--","src","tests"],cwd=repo)==(donor/"candidate.patch").read_bytes()
reference = base["imageFiles"]["candidate"]
assert {p.name:sha(p) for p in (donor/"candidate").iterdir()} == reference
current = lab/"windows/bin/Lokad.Lython/release_net11.0"/core
images = {"reference": reference, "candidate": reference | {core:sha(current)}}
assert images["candidate"][core] != reference[core]
for role, files in images.items():
    image=lab/role
    image.mkdir(exist_ok=True)
    for name in files:
        shutil.copyfile(current if role=="candidate" and name==core else donor/"candidate"/name,image/name)
    assert len(files)==32 and {p.name:sha(p) for p in image.iterdir()}==files

target="diagnostic.generated-ordinary-definitions"
defaulted="scripts.rule-default-closures"
eager="scripts.annotated-rule-closures"
manifest="scripts.config-manifest.small"
jobs=[[target,"compile"],[eager,"warm"],[target,"warm"],[manifest,"compile-run"],[defaulted,"compile-run"],[target,"compile-run"]]
catalog=read(previous/"representative.json")
rows={r["id"]:r for r in catalog["cases"] if r["id"] in (defaulted,eager)}
older=read(lab.with_name("shared-comprehension-facts-20261124")/"comparison/quiet/representative.json")
rows[manifest]=next(r for r in older["cases"] if r["id"]==manifest)
declarations=[]
for index in range(96):
    positional = str(index) if index % 3 == 0 else f"shift(offset + {index})"
    defaults = f"value={positional}, *, factor=shift(offset + {index % 7})"
    if index % 2 == 0:
        declarations.append(f"    def rule_{index}({defaults}): return value + factor")
    else:
        declarations.append(f"    rule_{index} = lambda {defaults}: value + factor")
source="def shift(value): return value + 1\n\ndef build(offset):\n"+"\n".join(declarations)+"""
    return rule_0, rule_48, rule_95

total = 0
for offset in range(16):
    first, middle, last = build(offset)
    total += first() + middle() + last()
print(total, first.__defaults__, middle.__kwdefaults__['factor'], last.__defaults__)
"""
python=Path("C:/Python313/python.exe")
golden=subprocess.run([python,"-I","-S","-X","utf8","-"],input=source,encoding="utf-8",capture_output=True,timeout=15,check=True)
assert not golden.stderr and golden.stdout.endswith("(0,) 22 (111,)\n"), golden.stdout
fixture=json.dumps({"size":96,"text":None},separators=(",",":"))
rows[target]=dict(id=target,family="scripts",category="whole-script",scale="small",size=96,source=source,
    fixtureJson=fixture,expectedOutput=golden.stdout,sourceUtf8Bytes=len(source.encode("utf-8")),
    expectedOutputUtf8Bytes=len(golden.stdout.encode("utf-8")),fixtureTextUtf8Bytes=0,fixtureTextCodePoints=0,
    sourceSha256=digest(source),fixtureSha256=digest(fixture),expectedOutputSha256=digest(golden.stdout))
catalog["cases"]=[rows[key] for key in (target,defaulted,eager,manifest)]
catalog["fixtureEncoding"]="The manifest uses canonical base64 file maps. The definitions have no file fixture."
expected=quiet/"representative.json"
save(expected,catalog)
save(quiet/"jobs.json",{"warm":jobs})
patch=lab/"candidate.patch"
patch.write_bytes(subprocess.check_output(["git","diff","--binary","--","src","tests"],cwd=repo))
assert b"+            definitionIndex = AppendConstant(layout);" in patch.read_bytes()
identity=dict(sourceRevision=head,comparisonRevision=head,sourcePatchSHA256=sha(patch),
    purpose="Keep one function descriptor shared by default admission and creation",
    imageFiles=images,expectedCPythonSHA256=base["expectedCPythonSHA256"],cpythonWorkerSHA256=base["cpythonWorkerSHA256"],
    coreSHA256={role+suffix:files[core] for role,files in images.items() for suffix in ("","-control")},
    catalogs={name:{"sha256":sha(quiet/name)} for name in ("representative.json","jobs.json")})
save(quiet/"identity.json",identity)
collector=(previous/"collect.py").read_text(encoding="utf-8").replace("b1646-fixtures","b1647-fixtures").replace("len(jobs) == 5", "len(jobs) == 6")
compile(collector,"collect.py","exec")
(quiet/"collect.py").write_text(collector,encoding="utf-8",newline="\n")
shutil.copyfile(previous/"run.sh",quiet/"run.sh")
assert b"\r" not in (quiet/"run.sh").read_bytes()
sdk=Path.home()/".dotnet11"
dotnet=sdk/"dotnet.exe"
env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk))
worker=repo/"benchmarks/cpython-worker.py"
assert sha(worker)==identity["cpythonWorkerSHA256"]
for role in images:
    output=lab/"comparison"/(role+"-verify.json")
    subprocess.run([dotnet,lab/role/"Lokad.Lython.Benchmarks.dll","--compare","verify","--catalog",expected,
        "--dotnet",dotnet,"--python",python,"--python-worker",worker,"--out",output],env=env,cwd=repo,check=True,timeout=60)
    checked=read(output)
    assert checked["state"]=="Completed" and checked["caseCount"]==4
    assert checked["catalogSha256"]==sha(expected) and checked["launched"]["library"]["sha256"]==images[role][core]
staged=quiet/"payload.tar.gz"
with tarfile.open(staged,"w:gz",compresslevel=3) as archive:
    for name in ("identity.json","jobs.json","representative.json","collect.py","run.sh"):
        archive.add(quiet/name,arcname=name,recursive=False)
    archive.add(lab/"candidate"/core,arcname="candidate-core.dll",recursive=False)
save(quiet/"upload.json",dict(root="shared-function-definition-descriptor-b1647-20261124",
    reference="prepared-default-pair-boundaries-refined-b1646-20261124",payloadSHA256=sha(staged),payloadBytes=staged.stat().st_size))
save(lab/"verified-raw-replicas.json",[])
launch=(donor/"quiet.py").read_text(encoding="utf-8")
receipt=read(previous/"terminal-status.json")["receipt"]
assert receipt["complete"] and sha(previous/"observations.tar.xz")==receipt["archiveSHA256"]
assert "716dbb791004b91bc3978d25cc5833fe64de4f4d4deb37e2a1eb556f3fae95ca" in launch
launch=launch.replace("716dbb791004b91bc3978d25cc5833fe64de4f4d4deb37e2a1eb556f3fae95ca",receipt["archiveSHA256"])
launch=launch.replace("lython-b1646-prepared-default-pair-boundaries-refined","lython-b1647-shared-function-definition-descriptor").replace("b1646-","b1647-").replace("RuntimeMaxSec=260","RuntimeMaxSec=292").replace("seconds=177","seconds=208")
compile(launch,"quiet.py","exec")
(lab/"quiet.py").write_text(launch,encoding="utf-8",newline="\n")
print("Verified 32 files per image and four complete CPython goldens.")
