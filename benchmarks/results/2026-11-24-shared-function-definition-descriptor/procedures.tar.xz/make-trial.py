from pathlib import Path

lab = Path(__file__).resolve().parent
donor = lab.with_name("prepared-default-pair-boundaries-refined-20261124")
prepare = (donor / "prepare.py").read_text(encoding="utf-8")
prepare = prepare.replace('lab.with_name("shared-comprehension-facts-20261124")', 'lab.with_name("prepared-default-pair-boundaries-refined-20261124")')
prepare = prepare.replace('head.startswith("9d50a1b1f")', 'head.startswith("654037855")')
start = prepare.index('defaulted="scripts.')
end = prepare.index('patch=lab/"candidate.patch"', start)
prepare = prepare[:start] + '''target="diagnostic.generated-ordinary-definitions"
defaulted="scripts.rule-default-closures"
eager="scripts.annotated-rule-closures"
manifest="scripts.config-manifest.small"
jobs=[[target,"compile"],[eager,"warm"],[target,"warm"],[manifest,"compile-run"],[defaulted,"compile-run"],[target,"compile-run"]]
catalog=read(previous/"representative.json")
rows={r["id"]:r for r in catalog["cases"] if r["id"] in (defaulted,eager)}
older=read(lab.with_name("shared-comprehension-facts-20261124")/"comparison/quiet/representative.json")
rows[manifest]=next(r for r in older["cases"] if r["id"]==manifest)
declarations=[]
for index in range(96):
    positional = str(index) if index % 3 == 0 else f"shift(offset + {index})"
    defaults = f"value={positional}, *, factor=shift(offset + {index % 7})"
    if index % 2 == 0:
        declarations.append(f"    def rule_{index}({defaults}): return value + factor")
    else:
        declarations.append(f"    rule_{index} = lambda {defaults}: value + factor")
source="def shift(value): return value + 1\\n\\ndef build(offset):\\n"+"\\n".join(declarations)+"""
    return rule_0, rule_48, rule_95

total = 0
for offset in range(16):
    first, middle, last = build(offset)
    total += first() + middle() + last()
print(total, first.__defaults__, middle.__kwdefaults__['factor'], last.__defaults__)
"""
python=Path("C:/Python313/python.exe")
golden=subprocess.run([python,"-I","-S","-X","utf8","-"],input=source,encoding="utf-8",capture_output=True,timeout=15,check=True)
assert not golden.stderr and golden.stdout.endswith("(0,) 22 (111,)\\n"), golden.stdout
fixture=json.dumps({"size":96,"text":None},separators=(",",":"))
rows[target]=dict(id=target,family="scripts",category="whole-script",scale="small",size=96,source=source,
    fixtureJson=fixture,expectedOutput=golden.stdout,sourceUtf8Bytes=len(source.encode("utf-8")),
    expectedOutputUtf8Bytes=len(golden.stdout.encode("utf-8")),fixtureTextUtf8Bytes=0,fixtureTextCodePoints=0,
    sourceSha256=digest(source),fixtureSha256=digest(fixture),expectedOutputSha256=digest(golden.stdout))
catalog["cases"]=[rows[key] for key in (target,defaulted,eager,manifest)]
catalog["fixtureEncoding"]="The manifest uses canonical base64 file maps. The definitions have no file fixture."
expected=quiet/"representative.json"
save(expected,catalog)
save(quiet/"jobs.json",{"warm":jobs})
'''+prepare[end:]
prepare = prepare.replace('b"+        ref readonly var create = ref instructions[creation];"', 'b"+            definitionIndex = AppendConstant(layout);"')
prepare = prepare.replace('Reuse the pair discriminator for the verified creation index', 'Keep one function descriptor shared by default admission and creation')
prepare = prepare.replace('reference="shared-comprehension-facts-b1642-20261124"', 'reference="prepared-default-pair-boundaries-refined-b1646-20261124"')
prepare = prepare.replace('root="prepared-default-pair-boundaries-refined-b1646-20261124"', 'root="shared-function-definition-descriptor-b1647-20261124"')
prepare = prepare.replace('replace("b1642-fixtures","b1646-fixtures").replace("len(jobs) == 4", "len(jobs) == 5")',
                          'replace("b1646-fixtures","b1647-fixtures").replace("len(jobs) == 5", "len(jobs) == 6")')
prepare = prepare.replace('f448b00857f22a384fdb36fa871de6d38a1001e06d08716e1197b9d69dab6154',
                          (Path(donor/"quiet.py").read_text(encoding="utf-8").split("assert donor['archiveSHA256']=='",1)[1].split("'",1)[0]))
prepare = prepare.replace('replace("lython-b1642-shared-comprehension-facts","lython-b1646-prepared-default-pair-boundaries-refined").replace("b1642-","b1646-").replace("RuntimeMaxSec=207","RuntimeMaxSec=260").replace("seconds=146","seconds=177")',
                          'replace("lython-b1646-prepared-default-pair-boundaries-refined","lython-b1647-shared-function-definition-descriptor").replace("b1646-","b1647-").replace("RuntimeMaxSec=260","RuntimeMaxSec=292").replace("seconds=177","seconds=208")')
prepare = prepare.replace('checked["caseCount"]==6', 'checked["caseCount"]==4').replace('six complete CPython goldens','four complete CPython goldens')
archive = (donor / "archive.py").read_text(encoding="utf-8").replace('2026-11-24-prepared-default-pair-boundaries/refined','2026-11-24-shared-function-definition-descriptor')
archive = archive.replace('receipt["warmJobs"]==5','receipt["warmJobs"]==6').replace('timedBatches=140,lanes=5','timedBatches=168,lanes=6')
recover = (lab.with_name("shared-comprehension-facts-20261124")/"recover-stage-space.py").read_text(encoding="utf-8")
recover = recover.replace('native-call-boundary-b116','call-construction-b113').replace('42428271','31720436').replace('8567460167be712d2eaee251d13c91d6263a306b4a368677686926ee646cd77c','d4464b98c83166dc81f434430da463a78007cb62e0f36b8bfabe6abad33ae904').replace("'b116' not in units.lower() and 'native-call-boundary' not in units.lower()", "'b113' not in units.lower() and 'call-construction' not in units.lower()")
for name, code in (("prepare.py",prepare),("archive.py",archive),("recover-stage-space.py",recover),
                   ("allocations.py",(donor/"allocations.py").read_text(encoding="utf-8")),
                   ("compile-allocation.py",(donor/"compile-allocation.py").read_text(encoding="utf-8"))):
    compile(code, name, "exec")
    (lab / name).write_text(code,encoding="utf-8",newline="\n")
