using System.Collections;
using System.Reflection;
using System.Security.Cryptography;
using System.Text.Json;
using Lokad.Lython;

const BindingFlags flags = BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance;
using var catalog = JsonDocument.Parse(File.ReadAllBytes(args[0]));
var rows = new List<object>();
object? Read(object item, string name) => item.GetType().GetProperty(name, flags)?.GetValue(item);
foreach (var item in catalog.RootElement.GetProperty("cases").EnumerateArray())
{
    var budget = new LythonMemoryBudget();
    var seen = new HashSet<object>(ReferenceEqualityComparer.Instance);
    var retainedConstants = 0;
    var layoutConstants = 0;
    var definitionConstants = 0;
    var starts = 0;
    var sharedStarts = 0;
    var opcodeCount = new Dictionary<string, int>();
    using (var script = new LythonEngine().Compile(item.GetProperty("source").GetString()!, budget))
    {
        if (!script.IsValid) throw new InvalidOperationException(string.Join("\n", script.Diagnostics));
        var target = ((Delegate)typeof(LythonCompiledScript).GetField("_runner", flags)!.GetValue(script)!).Target!;
        var executable = target.GetType().GetFields(flags).Single(field => field.FieldType.Name == "ExecutableScript").GetValue(target)!;
        Visit(Read(executable, "EntryPoint")!);
    }
    if (budget.ReservedBytes != 0) throw new InvalidOperationException("Compilation retained allowance.");
    rows.Add(new { id=item.GetProperty("id").GetString(), codeObjects=seen.Count, retainedConstants,
        layoutConstants, definitionConstants, starts, sharedStarts, opcodeCount });

    void Visit(object code)
    {
        if (!seen.Add(code)) return;
        var constants = (object?[])Read(code,"Constants")!;
        retainedConstants += constants.Length;
        var instructions = ((IEnumerable)Read(code,"Instructions")!).Cast<object>().ToArray();
        var creations = instructions.Where(instruction => Read(instruction,"OpCode")!.ToString() == "ApplyOperation")
            .Select(instruction => (int)Read(instruction,"ConstantIndex")!).ToHashSet();
        foreach (var instruction in instructions)
        {
            var operation = Read(instruction,"OpCode")!.ToString()!;
            opcodeCount[operation] = opcodeCount.GetValueOrDefault(operation) + 1;
            if (operation != "StartFunctionDefaults") continue;
            var index = (int)Read(instruction,"ConstantIndex")!;
            starts++;
            if (creations.Contains(index) && constants[index]?.GetType().Name == "ExecutableCreateFunction") sharedStarts++;
        }
        foreach (var constant in constants)
        {
            var kind = constant?.GetType().Name;
            if (kind == "FunctionParameterLayout") layoutConstants++;
            if (kind == "ExecutableCreateFunction") definitionConstants++;
            var child = kind switch
            {
                "ExecutableCreateClass" => Read(constant!,"Body"),
                "ExecutableCreateFunction" or "ExecutableCreateGeneratorExpression" => Read(constant!,"CodeObject"),
                _ => null,
            };
            if (child is not null) Visit(child);
        }
    }
}
var hash = Convert.ToHexStringLower(SHA256.HashData(File.ReadAllBytes(typeof(LythonEngine).Assembly.Location)));
File.WriteAllText(args[1], JsonSerializer.Serialize(new { coreSHA256=hash, rows }, new JsonSerializerOptions { WriteIndented=true }));
