from pathlib import Path
import hashlib, json, re, shutil, subprocess, tarfile

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
out = repo / "benchmarks/results/2026-11-24-shared-function-definition-descriptor"
quiet = lab / "comparison/quiet"
read = lambda path: json.loads(path.read_text(encoding="utf-8-sig"))
sha = lambda payload: hashlib.sha256(payload).hexdigest()
identity = read(quiet / "identity.json")
patch = (lab / "candidate.patch").read_bytes()
assert patch == subprocess.check_output(["git", "diff", "--binary", "--", "src", "tests"], cwd=repo)
assert identity["sourcePatchSHA256"] == sha(patch)
checks = {}
for name in ("windows-public.log", "ubuntu-white.log", "windows-net10.log", "ubuntu-net10.log"):
    log = (lab / name).read_text(encoding="utf-8-sig")
    totals = re.search(r"Failed:\s*0, Passed:\s*(\d+), Skipped:\s*0, Total:\s*\1\b", log)
    assert totals, (name, log[-800:])
    checks[name] = int(totals[1])
assert checks["windows-public.log"] == 1151 and checks["ubuntu-white.log"] == 921
assert checks["windows-net10.log"] == checks["ubuntu-net10.log"]
rows = {}
for role, files in identity["imageFiles"].items():
    assert {path.name: sha(path.read_bytes()) for path in (lab / role).iterdir()} == files
    verified = read(lab / "comparison" / (role + "-verify.json"))
    assert verified["state"] == "Completed" and verified["caseCount"] == 4
    assert verified["launched"]["library"]["sha256"] == files["Lokad.Lython.dll"]
    census = read(lab / (role + "-census.json"))
    assert census["coreSHA256"] == files["Lokad.Lython.dll"]
    rows[role] = census["rows"]
summary = []
for before, after in zip(rows["reference"], rows["candidate"], strict=True):
    for key in ("id", "codeObjects", "definitionConstants", "starts", "opcodeCount"):
        assert before[key] == after[key]
    assert before["layoutConstants"] == after["sharedStarts"] == before["starts"] and after["layoutConstants"] == 0
    assert before["retainedConstants"] - after["retainedConstants"] == before["starts"]
    summary.append(dict(id=before["id"], codeObjects=before["codeObjects"],
                        retainedConstants=[x["retainedConstants"] for x in (before,after)],
                        starts=before["starts"], opcodeCountsMatch=True))
(out / "constant-summary.json").write_text(json.dumps(dict(checks=checks, rows=summary), indent=2)+"\n",encoding="utf-8",newline="\n")
for path in (quiet / "identity.json", lab / "allocation-summary.json", lab / "compile-allocation-summary.json", quiet / "retired-stage-custody.json"):
    shutil.copyfile(path, out / path.name)
names = ("package-evidence.py", "make-trial.py", "prepare.py", "prepare.log", "quiet.py", "archive.py",
         "compile-allocation.py", "allocations.py", "recover-stage-space.py", "candidate.patch",
         "census/Census.csproj", "census/Program.cs", "reference-census.json", "candidate-census.json",
         "reference-compiler-owner.json", "candidate-compiler-owner.json", "reference-allocation.json", "candidate-allocation.json",
         "comparison/reference-verify.json", "comparison/candidate-verify.json", "comparison/quiet/storage-custody.json", *checks)
with tarfile.open(out / "procedures.tar.xz", "w:xz") as archive:
    for name in names:
        archive.add(lab / name, arcname=name, recursive=False)
with tarfile.open(out / "procedures.tar.xz") as archive:
    assert {item.name: sha(archive.extractfile(item).read()) for item in archive} == {
        name: sha((lab / name).read_bytes()) for name in names}
print("The measured source, six timings, four goldens, compiler census and test logs verify.")
