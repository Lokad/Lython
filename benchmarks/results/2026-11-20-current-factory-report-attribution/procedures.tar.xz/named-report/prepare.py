from pathlib import Path
import hashlib,json,shutil,tarfile

lab=Path(__file__).resolve().parent
previous=lab.parent/'remaining-runtime-attribution'
read=lambda path:path.read_text(encoding='utf-8-sig')
load=lambda path:json.loads(read(path))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def save(path,text):
    if path.suffix=='.py':compile(text,path,'exec')
    path.write_text(text,encoding='utf-8',newline='\n')
config=load(previous/'config.json')
old_root=config['root']; old_unit=config['unit']
new_root=old_root.replace('remaining-runtime-attribution-b1204','named-report-attribution-b1204r')
new_unit=old_unit.replace('b1204-remaining-runtime-attribution','b1204r-named-report-attribution')
old_purpose=config['identity']['purpose']
purpose='B1204 named report CPU attribution recovery'
jobs=[('candidate-annotated','scripts.annotated-rule-closures','warm'),
      ('candidate-forwarding','scripts.report-forwarding.expanded','warm'),
      ('candidate-named-report','scripts.report-render.named-format-selectors.large','warm')]
labels=[job[0] for job in jobs]
assert config['identity']['catalogSHA256']==sha(previous/'catalog.json')
shutil.copyfile(previous/'catalog.json',lab/'catalog.json')
shutil.copyfile(previous/'identity.json',lab/'identity.json')
config.update(root=new_root,unit=new_unit)
# Reuse the verified three-case catalog and image. Only the missing capture runs.
for name in ('ops-profile.py','collect.py','run.sh','launch.py','retrieve.py','analyze.py'):
    text=read(previous/name).replace(old_root,new_root).replace(old_unit,new_unit).replace(old_purpose,purpose)
    text=text.replace(repr(labels),repr(labels[-1:])).replace('len(records)==3','len(records)==1')
    if name=='ops-profile.py':
        assert repr(jobs) in text and 'total_capture_seconds > 14' in text
        text=text.replace(repr(jobs),repr(jobs[-1:]))
    if name=='launch.py':
        text=text.replace('seconds=85','seconds=35').replace('before 85','before 35')
    save(lab/name,text)
assert b'\r' not in (lab/'run.sh').read_bytes()
names=('identity.json','catalog.json','ops-profile.py','collect.py','run.sh')
payload=lab/'payload.tgz'
with tarfile.open(payload,'w:gz')as archive:
    for name in names:archive.add(lab/name,arcname=name)
config.update(payloadBytes=payload.stat().st_size,payloadSHA256=sha(payload),unpackedBytes=sum((lab/name).stat().st_size for name in names))
save(lab/'config.json',json.dumps(config,indent=2)+'\n')
body=read(previous/'remote-launch.py').replace('lython-b1204-fixtures','lython-b1204r-fixtures')
start=body.index('\nc=')+1;end=body.index('\nb=Path(')
save(lab/'remote-launch.py',body[:start]+'c='+repr(config)+body[end:])
completed=read(previous/'analyze.py').replace(repr(labels),repr(labels[:-1]))
save(previous/'analyze-complete.py',completed)
