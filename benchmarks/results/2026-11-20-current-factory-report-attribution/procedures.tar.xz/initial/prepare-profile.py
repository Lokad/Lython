from pathlib import Path

lab=Path(__file__).resolve().parent
previous=lab.parent/'factory-dispatch-after-direct-emission'
read=lambda p:p.read_text(encoding='utf-8-sig')
def write(name,text):
    compile(text,name,'exec')
    (lab/name).write_text(text,encoding='utf-8',newline='\n')
old_jobs=[('candidate-annotated','scripts.annotated-rule-closures','warm'),
          ('candidate-nested','scripts.annotated-rule-closures.nested-factories','warm')]
new_jobs=[('candidate-annotated','scripts.annotated-rule-closures','warm'),
          ('candidate-forwarding','scripts.report-forwarding.expanded','warm'),
          ('candidate-named-report','scripts.report-render.named-format-selectors.large','warm')]
old_labels=[label for label,_,_ in old_jobs]
new_labels=[label for label,_,_ in new_jobs]
prepare=read(previous/'prepare.py')
prepare=prepare.replace("prior = lab.parent / 'factory-ownership-profile'","prior = lab.parent / 'factory-dispatch-after-direct-emission'")
prepare=prepare.replace("donor = lab.parent / 'direct-statement-emission'","donor = lab.parent / 'shared-lexical-definitions'")
prepare=prepare.replace("assert revision.startswith('2dad15d55')","assert revision.startswith('50d63cf31')")
prepare=prepare.replace("assert measured.startswith('2131039a4')","assert measured.startswith('32c5f2ef7')")
prepare=prepare.replace("catalog = load(prior/'catalog.json')","catalog = load(donor/'comparison-catalog.json')")
start=prepare.index('\njobs = ')
end=prepare.index("catalog['cases'] = ",start)
prepare=prepare[:start]+'\njobs = '+repr(new_jobs)+"""
cases = {case['id']:case for case in catalog['cases']}
report = load(lab.parent/'format-continuation-scratch/catalog.json')
cases.update({case['id']:case for case in report['cases']})
"""+prepare[end:]
prepare=prepare.replace('factory-dispatch-after-direct-emission-b1193','remaining-runtime-attribution-b1204').replace('lython-b1193-factory-dispatch-after-direct-emission','lython-b1204-remaining-runtime-attribution')
prepare=prepare.replace('B1193 current factory ownership and dispatch attribution','B1204 current factory and report CPU attribution')
prepare=prepare.replace("old_labels=['candidate-annotated','candidate-nested','candidate-forwarding','candidate-report']",f'old_labels={old_labels!r}')
prepare=prepare.replace(".replace('len(records)==4','len(records)==2')",".replace('len(records)==2','len(records)==3')")
prepare=prepare.replace("    if name=='ops-profile.py': assert repr(jobs) in body",
    f"""    if name=='ops-profile.py':
        assert {repr(old_jobs)!r} in body
        body=body.replace({repr(old_jobs)!r},repr(jobs))
    if name=='launch.py':
        body=body.replace('seconds=65','seconds=85').replace('before 65','before 85')
""")
prepare=prepare.replace("launcher.replace('lython-b1170-fixtures','lython-b1193-fixtures')","launcher.replace('lython-b1193-fixtures','lython-b1204-fixtures').replace('B1193','B1204')")
prepare=prepare.replace('both CPython goldens verified. VM stages the immutable candidate image from B1191.',
                        'three CPython goldens verified. VM stages the immutable candidate image from B1202.')
write('prepare.py',prepare)
archive=read(previous/'archive-profile.py')
archive=archive.replace("Path('benchmarks/results/2026-11-20-factory-dispatch-after-direct-emission')","Path('benchmarks/results/2026-11-20-current-factory-report-attribution')")
archive=archive.replace("'2dad15d55'","'50d63cf31'").replace("'2131039a4'","'32c5f2ef7'")
archive=archive.replace('/2026-11-20-direct-statement-emission/','/2026-11-20-inline-lexical-definitions/')
archive=archive.replace('len(rows)==len(catalog)==2','len(rows)==len(catalog)==3').replace('two captures, the complete image, both goldens','three captures, the complete image, all goldens')
write('archive-profile.py',archive)
