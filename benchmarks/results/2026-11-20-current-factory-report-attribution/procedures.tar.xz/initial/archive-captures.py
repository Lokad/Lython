from pathlib import Path
import gzip
import hashlib
import json
import shutil
import tarfile

lab=Path(__file__).resolve().parent
retry=lab.parent/'named-report-attribution'
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
identity=load(lab/'identity.json')
assert identity==load(retry/'identity.json')
assert identity['sourceRevision'].startswith('50d63cf31') and identity['imageSource'].startswith('32c5f2ef7')
assert identity['catalogSHA256']==sha(lab/'catalog.json')==sha(retry/'catalog.json')
cases={c['id']:c for c in load(lab/'catalog.json')['cases']}
assert len(cases)==3
files=identity['imageFiles']['candidate']
assert len(files)==32 and {name:sha(lab/'candidate'/name) for name in files}==files
core=Path('benchmarks/results/2026-11-20-inline-lexical-definitions/measured-core.dll.gz')
assert hashlib.sha256(gzip.decompress(core.read_bytes())).hexdigest()==files['Lokad.Lython.dll']
verified=load(lab/'verify.json')
assert verified['state']=='Completed' and verified['catalogSha256']==identity['catalogSHA256']
sources={'initial':lab,'named-report':retry}
out=Path('benchmarks/results/2026-11-20-current-factory-report-attribution')
rows=[]
for label,path in sources.items():
    terminal=load(path/'terminal-status.json')
    receipt=load(path/'archive-receipt.json')
    assert terminal['receipt']==receipt and not terminal['live'] and not terminal['remainingWorkers'] and not terminal['remainingTrace']
    assert all(receipt[k] for k in ('quietBeforeAndAfter','allWorkersJoined','guestFixturesRemoved','archivedAndVerifiedUnderLease',
                                    'persistentTraceArchivedAndVerifiedBeforeUnmount'))
    assert receipt['archiveSHA256']==sha(path/'observations.tgz')
    if label=='initial':
        assert terminal['exitCode']=='1' and not receipt['complete'] and 'Combined diagnostic profile capture window' in terminal['journal']
    else:
        assert terminal['exitCode']=='0' and receipt['complete']
    completed=load(path/'attribution.json')['rows']
    assert len(completed)==(2 if label=='initial' else 1)
    for row in completed:
        run=load(path/'retrieved/profiles'/row['label']/'record.json')
        assert run['exitCode']==0 and run['closed']['status']=='Closed' and run['warmupSeconds']>=8 and row['sampleCount']>900
        libs={Path(lib['path']).name:lib['sha256'].lower() for lib in run['identity']['libraries']}
        assert libs['Lokad.Lython.dll']==files['Lokad.Lython.dll']
        assert all(libs[name]==files[name] for name in libs.keys() & files.keys())
        case=cases[row['case']]
        for check in ('verificationBefore','response','verificationAfter'):
            assert run[check]['actualOutputSha256']==case['expectedOutputSha256']
            assert run[check].get('actualFilesSha256')==case.get('expectedFilesSha256')
        rows.append(dict(row,collection=label))
assert {r['case'] for r in rows}==set(cases)
out.mkdir(exist_ok=False)
for label,path in sources.items():
    target=out/label
    target.mkdir()
    for name in ('terminal-status.json','archive-receipt.json','observations.tgz'):
        shutil.copyfile(path/name,target/name)
(out/'attribution.json').write_text(json.dumps(dict(source=identity['sourceRevision'],imageSource=identity['imageSource'],
    diagnosticOnly=True,rows=rows),indent=2)+'\n',encoding='utf-8',newline='\n')
with tarfile.open(out/'procedures.tar.xz','w:xz')as archive:
    for label,path in sources.items():
        for file in sorted(path.iterdir()):
            if file.is_file() and file.suffix in {'.json','.log','.py','.sh'} and file.name not in {'attribution.json','archive-receipt.json','terminal-status.json'}:
                archive.add(file,arcname=f'{label}/{file.name}')
print('Preserved both VM collections, including the original failed condition and all three independently verified captures.')
for row in rows:
    print(row['case'],row['sampleCount'],row['guestRuntimeAncestry'],row['unmappedLeafSamples'],row['nearestRuntimeMethods'][:10])
