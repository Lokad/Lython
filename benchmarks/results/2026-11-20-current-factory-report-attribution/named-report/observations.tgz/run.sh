set -eu
root=/home/lokad/lython-bench-checks/named-report-attribution-b1204r-20261120
trap 'result=$?; printf "%s\n" "$result" > "$root/exit-code.txt"' EXIT
python3 "$root/collect.py"
