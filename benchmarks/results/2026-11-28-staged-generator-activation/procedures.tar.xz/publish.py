from hashlib import sha256
from pathlib import Path
from shutil import copy2
from subprocess import check_output
import json
import re
import tarfile

lab = Path(__file__).resolve().parent
first = lab.parent / 'staged-generator-activation-b1936-20261128'
repo = lab.parents[3]
bench = lab / 'comparison'
output = repo / 'benchmarks/results/2026-11-28-staged-generator-activation'

def read(path):
    return json.loads(path.read_bytes())

def digest(path):
    return sha256(path.read_bytes()).hexdigest()

identity = read(bench / 'identity.json')
for part, name in [('src/Lokad.Lython', 'candidate.patch'), ('tests', 'test.patch')]:
    source = check_output(['git', 'diff', '--binary', identity['sourceRevision'], '--', part], cwd=repo)
    assert source == (lab / name).read_bytes()
assert digest(lab / 'candidate.patch') == identity['sourcePatchSHA256']
for root in (bench, first / 'comparison'):
    manifest = read(root / 'identity.json')
    for role, files in manifest['imageFiles'].items():
        assert len(files) == 32
        assert {path.name: digest(path) for path in (root / role).iterdir()} == files
assert read(first / 'comparison/identity.json')['imageFiles']['reference'] == identity['imageFiles']['reference']
summary = read(bench / 'summary.json')
assert summary['verifiedTimedBatches'] == 140 and len(summary['rows']) == 5
receipt = read(bench / 'archive-receipt.json')
assert all(receipt[key] for key in ('complete', 'allWorkersJoined', 'guestFixturesRemoved', 'archivedAndVerifiedUnderLease'))
assert receipt['archiveSHA256'] == digest(bench / 'observations.tar.xz')
output.mkdir(exist_ok=True)
artifacts = {name: bench / name for name in ('identity.json', 'summary.json', 'observations.tar.xz', 'archive-receipt.json')}
procedures = {}
for root, prefix in ((lab, ''), (first, 'initial/')):
    rows = read(root / 'allocation/summary.json')
    assert len(rows) == 8 and all(row['compiled'][0] == row['compiled'][1] and row['admittedPeak'][0] == row['admittedPeak'][1] for row in rows)
    artifacts[('initial-' if prefix else '') + 'allocation.json'] = root / 'allocation/summary.json'
    logs = list(root.glob('*-Lokad.Lython.*Tests-net*.log'))
    assert len(logs) == 6
    for log in logs:
        count = 598 if 'PublicApi' in log.name else 139
        assert re.search(rf'Failed: +0, Passed: +{count}, Skipped: +0', log.read_text(encoding='utf-8-sig')), log
        procedures[prefix + log.name] = log
    for name in ('candidate.patch', 'test.patch', 'test-ubuntu.sh', 'test-windows.ps1', 'test-windows-net10.ps1',
                 'build-core.sh', 'core-ubuntu-build.log', 'freeze.py', 'measure-allocation.py'):
        procedures[prefix + name] = root / name
    for path in (root / 'allocation').glob('*.json'):
        procedures[f'{prefix}allocation/{path.name}'] = path
    procedures[prefix + 'comparison-identity.json'] = root / 'comparison/identity.json'
for name in ('collection.log', 'reference-verify.json', 'candidate-verify.json', 'exit-code.txt'):
    procedures[name] = bench / name
for name in ('build-core-retry.sh', 'core-ubuntu-build-retry.log', 'summarize.py', 'publish.py'):
    procedures[name] = lab / name
for name, source in artifacts.items():
    copy2(source, output / name)
    assert digest(output / name) == digest(source)
with tarfile.open(output / 'procedures.tar.xz', 'w:xz') as archive:
    for name, source in procedures.items():
        archive.add(source, arcname=name)
with tarfile.open(output / 'procedures.tar.xz') as archive:
    assert all(digest(path) == sha256(archive.extractfile(name).read()).hexdigest() for name, path in procedures.items())
print('Verified staged generator evidence and first variant receipts.')
