#!/bin/bash
set -euo pipefail
cd /mnt/d/code/Lython
lab=.git/agent-notes/review-20261031/staged-generator-activation-refined-b1936-20261128
export NUGET_PACKAGES=$PWD/.git/agent-notes/review-20261031/regex-released-050-20261127/packages-ubuntu
for suite in Lokad.Lython.Tests Lokad.Lython.PublicApi.Tests; do
  if [[ $suite = Lokad.Lython.Tests ]]; then
    filter='Category!=Stress&(FullyQualifiedName~Generator|FullyQualifiedName~IterationWorkspace|FullyQualifiedName~SimpleFunctionExecutionBoundary|FullyQualifiedName~OwnedFunctionLocals)'
  else
    filter='Category!=Stress&(FullyQualifiedName~Generator|FullyQualifiedName~StarmapMaterializationParity|FullyQualifiedName~NativeCallback|FullyQualifiedName~AdmissionFailureCommandTests)'
  fi
  log="$lab/ubuntu-$suite-net11.0.log"
  ~/.dotnet/dotnet test "tests/$suite/$suite.csproj" -c Release -f net11.0 --artifacts-path "$lab/ubuntu-artifacts" --filter "$filter" > "$log" 2>&1 || { tail -70 "$log"; exit 1; }
  tail -5 "$log"
done
