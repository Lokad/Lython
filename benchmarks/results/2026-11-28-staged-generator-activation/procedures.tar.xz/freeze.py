from pathlib import Path
from hashlib import sha256
from shutil import copy2, copytree
import json
import subprocess

root = Path(__file__).resolve().parent
base = root.parent / 'ready-callback-abi-b1935-20261128'
donor = base / 'comparison'
quiet = root.parent / 'current-checkpoint-b1932-20261128/comparison/quiet'
pair = root / 'comparison'
core = root / 'ubuntu-artifacts/bin/Lokad.Lython/release_net11.0/Lokad.Lython.dll'
def read(path):
    return json.loads(path.read_bytes())
def write(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n', encoding='utf-8', newline='\n')
def digest(path):
    return sha256(path.read_bytes()).hexdigest()
def git(*args):
    return subprocess.check_output(['git', *args])
def files(folder):
    return {path.name: digest(path) for path in sorted(folder.iterdir())}
def adapt(source, target, replacements):
    content = source.read_text(encoding='utf-8')
    for before, after in replacements:
        assert before in content, before
        content = content.replace(before, after)
    target.write_text(content, encoding='utf-8', newline='\n')

identity = read(donor / 'identity.json')
other = read(quiet / 'identity.json')
head = git('rev-parse', 'HEAD').decode().strip()
assert not git('diff', '--binary', identity['sourceRevision'], head, '--', 'src/Lokad.Lython')
assert files(donor / 'reference') == identity['imageFiles']['reference']
assert len(identity['imageFiles']['reference']) == 32
pair.mkdir()
for role in ('reference', 'candidate'):
    copytree(donor / 'reference', pair / role)
copy2(core, pair / 'candidate/Lokad.Lython.dll')
images = {role: files(pair / role) for role in ('reference', 'candidate')}
assert images['reference'] == identity['imageFiles']['reference']
assert {name for name, sha in images['reference'].items() if images['candidate'][name] != sha} == {'Lokad.Lython.dll'}
assert images['candidate']['Lokad.Lython.dll'] == digest(core)
source_patch = git('diff', '--binary', 'HEAD', '--', 'src/Lokad.Lython')
(root / 'candidate.patch').write_bytes(source_patch)
(root / 'test.patch').write_bytes(git('diff', '--binary', 'HEAD', '--', 'tests'))

manifest = 'representative.json'
assert digest(donor / manifest) == identity['catalogs'][manifest]['sha256']
assert digest(quiet / manifest) == other['catalogs'][manifest]['sha256']
catalog = read(donor / manifest)
first_line = read(quiet / manifest)
assert first_line['catalogVersion'] == catalog['catalogVersion']
selection = [
    'diagnostic.shipment-starmap-iterable-rows',
    'diagnostic.shipment-row-generator-reduction',
    'diagnostic.shipment-file-fed-map',
    'diagnostic.file-search-first-line',
]
cases = {case['id']:case for case in catalog['cases'] + first_line['cases']}
catalog['cases'] = [cases[case_id] for case_id in selection]
write(pair / manifest, catalog)
write(pair / 'jobs.json', {'warm': [[selection[0], 'warm']] + [[case_id, 'warm-async'] for case_id in selection]})
copy2(donor / 'cpython-worker.py', pair / 'cpython-worker.py')
assert digest(pair / 'cpython-worker.py') == identity['cpythonWorkerSHA256']
write(pair / 'identity.json', dict(
    sourceRevision=head, sourcePatchSHA256=sha256(source_patch).hexdigest(), imageFiles=images,
    coreSHA256={label: images[role]['Lokad.Lython.dll']
                for role in images for label in (role, role + '-control')},
    catalogs={name: {'sha256': digest(pair / name)} for name in (manifest, 'jobs.json')},
    cpythonWorkerSHA256=identity['cpythonWorkerSHA256'],
    expectedCPythonSHA256=identity['expectedCPythonSHA256'],
    purpose='Remove the generator wrapper on the private call-to-yield edge while retaining the same admitted frame and driver.'
))
adapt(donor / 'run.sh', pair / 'run.sh', [('220s', '270s')])
adapt(donor / 'collect.py', pair / 'collect.py', [
    ('-started < 205', '-started < 255'),
    ('assert len(jobs) == 4', 'assert len(jobs) == 5'),
])
assert b'\r' not in (pair / 'run.sh').read_bytes()
adapt(base / 'summarize.py', root / 'summarize.py', [
    ('receipt["warmJobs"] == 4', 'receipt["warmJobs"] == 5'),
    ('== 112', '== 140'),
])
copy2(base / 'measure-allocation.py', root / 'measure-allocation.py')
print(f'Frozen {len(selection)+1} matched lanes at {head}, both images verified')
