$ErrorActionPreference='Stop'
$d='.git/agent-notes/review-20261031/staged-generator-activation-b1936-20261128'
$exe=Join-Path $env:USERPROFILE '.dotnet11/dotnet.exe'
$tests=[ordered]@{
 'Lokad.Lython.Tests'='Category!=Stress&(FullyQualifiedName~Generator|FullyQualifiedName~IterationWorkspace|FullyQualifiedName~SimpleFunctionExecutionBoundary|FullyQualifiedName~OwnedFunctionLocals)'
 'Lokad.Lython.PublicApi.Tests'='Category!=Stress&(FullyQualifiedName~Generator|FullyQualifiedName~StarmapMaterializationParity|FullyQualifiedName~NativeCallback|FullyQualifiedName~AdmissionFailureCommandTests)'
}
foreach ($t in $tests.GetEnumerator()) {
   $p="tests/$($t.Key)/$($t.Key).csproj"
   $out="$d/windows-$($t.Key)-net10.0.log"
   & $exe test $p -c Release -f net10.0 --filter $t.Value *> $out
   $code=$LASTEXITCODE
   Get-Content -Encoding utf8 -Tail 25 $out
   if ($code -ne 0) { exit $code }
}
