#!/bin/bash
set -euo pipefail
cd /mnt/d/code/Lython
lab=.git/agent-notes/review-20261031/staged-generator-activation-b1936-20261128
export NUGET_PACKAGES=$PWD/.git/agent-notes/review-20261031/regex-released-050-20261127/packages-ubuntu
log=$lab/core-ubuntu-build.log
~/.dotnet/dotnet build src/Lokad.Lython/Lokad.Lython.csproj -c Release -f net11.0 --artifacts-path "$lab/ubuntu-artifacts" --no-incremental > "$log" 2>&1 || { tail -45 "$log"; exit 1; }
tail -5 "$log"
