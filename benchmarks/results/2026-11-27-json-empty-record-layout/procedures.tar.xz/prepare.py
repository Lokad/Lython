from pathlib import Path
from hashlib import sha256
from statistics import median
import base64
import copy
import json
import os
import shutil
import subprocess

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
previous=lab.with_name('compiled-prefix-search-20261126')
image_base=lab.with_name('json-escaped-name-reuse-20261127')/'local'
callback=lab.with_name('direct-map-result-handoff-20261126')
repeat=lab.with_name('map-repeat-operands-20261126')
run=lab/'local'
run.mkdir()
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
def sha(path):return sha256(path.read_bytes()).hexdigest()
def write(path,data):path.write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
def manifest(directory):return {p.name:sha(p) for p in directory.iterdir()}
core='Lokad.Lython.dll'
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()
assert head=='9043062b4565d429393e7bbee97c8676b64d1310'
for area, name in (('src','candidate.patch'),('tests','regression.patch')):
    (run/name).write_bytes(subprocess.check_output(['git','diff','--binary','HEAD','--',area],cwd=repo))
pin=read(image_base/'identity.json')
reference_files=pin['imageFiles']['candidate']
assert len(reference_files)==32 and manifest(image_base/'candidate')==reference_files
new=repo/'tests/Lokad.Lython.PublicApi.Tests/bin/Release/net11.0'/core
assert sha(new)==sha(repo/'src/Lokad.Lython/bin/Release/net11.0'/core)
images={}
for role in ('reference','candidate'):
    target=run/role
    shutil.copytree(image_base/'candidate',target)
    if role=='candidate':shutil.copyfile(new,target/core)
    images[role]=manifest(target)
assert images['reference']==reference_files
assert [p for p,x in reference_files.items() if x!=images['candidate'][p]]==[core]
document='diagnostic.json-service-quantity-totals'
lines='scripts.json-summary-helpers.large'
sparse_doc='diagnostic.json-service-sparse-records'
sparse_lines='diagnostic.json-lines-sparse-records'
catalog=read(lab.with_name('json-single-string-pass-20261126')/'local/representative.json')
catalog['cases']=[row for row in catalog['cases'] if row['id'] in {document,lines}]
assert len(catalog['cases'])==2
counts=[]
def sparse_case(original, case_id, document):
    case=copy.deepcopy(original)
    case['id']=case_id
    fixture=json.loads(case['fixtureJson'])
    file,encoded=next(iter(fixture['inputFiles'].items()))
    data=base64.b64decode(encoded).decode('utf-8')
    if document:
        records=json.loads(data)
        groups=[records[i:i+4]+[{}] for i in range(0,len(records),4)]
        payload=json.dumps([row for group in groups for row in group],separators=(',',':'))
        old="        service = row['service']"
        new="        if not row:\r\n            continue\r\n"+old
        empty=len(groups)
        count=len(records)
    else:
        lines=data.splitlines()
        empty=sum(1 for line in lines if not line)
        count=len(lines)-empty
        payload=''.join(line+'\n' if line else '{}\n\n' for line in lines)
        old='            amount = record_amount(record)'
        new='            if not record:\r\n                continue\r\n'+old
    assert case['source'].count(old)==1
    case['source']=case['source'].replace(old,new)
    fixture['inputFiles'][file]=base64.b64encode(payload.encode()).decode('ascii')
    case['fixtureJson']=json.dumps(fixture,separators=(',',':'),ensure_ascii=True)
    case['fixtureSha256']=sha256(case['fixtureJson'].encode()).hexdigest()
    case['sourceSha256']=sha256(case['source'].encode()).hexdigest()
    case['sourceUtf8Bytes']=len(case['source'].encode())
    counts.append(dict(case=case_id, dataRecords=count, emptyObjects=empty,inputBytes=len(payload.encode())))
    return case
by_id={case['id']:case for case in catalog['cases']}
catalog['cases'] += [
    sparse_case(by_id[document],sparse_doc,True),
    sparse_case(by_id[lines],sparse_lines,False),
]
write(run/'field-census.json',counts)
write(run/'representative.json',catalog)
for name in ('collect.py','run.sh'):
    text=(previous/'local'/name).read_text(encoding='utf-8')
    if name=='collect.py':text=text.replace('lython-compiled-prefix-fixture-','lython-json-empty-record-fixture-')
    (run/name).write_text(text,encoding='utf-8',newline='\n')
assert b'\r' not in (run/'run.sh').read_bytes()
shutil.copyfile(image_base/'cpython-worker.py',run/'cpython-worker.py')
assert sha(run/'cpython-worker.py')==pin['cpythonWorkerSHA256']
write(run/'jobs.json',{'warm':[[sparse_doc,'warm'],[lines,'warm-async'],[sparse_lines,'warm-async'],[document,'warm'],[sparse_doc,'warm-async']]})
identity=dict(sourceRevision=head,sourcePatchSHA256=sha(run/'candidate.patch'),imageFiles=images,cpythonWorkerSHA256=pin['cpythonWorkerSHA256'],
              coreSHA256={role+suffix:im[core] for role,im in images.items() for suffix in ('','-control')},
              catalogs={name:{'sha256':sha(run/name)} for name in ('representative.json','jobs.json')},
              purpose='Preserve already-owned JSON key layouts across empty objects.')
write(run/'identity.json',identity)
shutil.copyfile(previous/'summarize.py',lab/'summarize.py')
sdk=Path.home()/'.dotnet11';dotnet=sdk/'dotnet.exe'
env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk))
for role, im in images.items():
    report=run/f'{role}-verify.json'
    subprocess.run([dotnet,run/role/'Lokad.Lython.Benchmarks.dll','--compare','verify','--catalog',run/'representative.json','--dotnet',dotnet,
                    '--python','C:/Python313/python.exe','--python-worker',run/'cpython-worker.py','--out',report],cwd=repo,env=env,check=True,timeout=60)
    checked=read(report)
    assert checked['caseCount']==4 and checked['state']=='Completed'
    assert checked['catalogSha256']==identity['catalogs']['representative.json']['sha256']
    assert checked['launched']['library']['sha256']==im[core]
    diagnostic=run/f'{role}-allocated'
    shutil.copytree(run/role,diagnostic)
    for path in (previous/'candidate-allocated').glob('ValidatedAllocation*'):
        shutil.copyfile(path,diagnostic/path.name)
    assert all(sha(diagnostic/p)==h for p,h in im.items())
rows=[]
for mode in ('sync','async'):
    for case in catalog['cases']:case['runAsync']=mode=='async'
    selected=run/f'{mode}-allocation-catalog.json'
    write(selected,catalog)
    values=[]
    for role in ('reference','candidate'):
        diagnostic=run/f'{role}-allocated'
        report=run/f'{role}-{mode}-allocation.json'
        subprocess.run([dotnet,diagnostic/'ValidatedAllocation.dll',diagnostic,selected,report],env=env,check=True,timeout=75)
        values.append(read(report)['rows'])
    for before,after in zip(*values,strict=True):
        assert before['id']==after['id'] and before['sharedBudgetBaselineRestored'] and after['sharedBudgetBaselineRestored']
        row=dict(case=before['id'],mode=mode,clr=[median(r['allocatedBytesPerInvocation']) for r in (before,after)],peak=[r['peakExecutionMemoryBytes'] for r in (before,after)],compiled=[r['compiledReservedBytes'] for r in (before,after)])
        rows.append(row)
        print(row,flush=True)
write(run/'allocation-summary.json',rows)
