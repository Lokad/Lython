from pathlib import Path
from hashlib import sha256
import json
import shutil

lab=Path(__file__).resolve().parent
original=lab/'local'
repeat=lab/'confirmation'
repeat.mkdir()
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
def sha(p):return sha256(p.read_bytes()).hexdigest()
def save(path,text):path.write_text(text,encoding='utf-8',newline='\n')
def manifest(p):return {f.name:sha(f) for f in p.iterdir()}
identity=read(original/'identity.json')
for role,ident in identity['imageFiles'].items():
    assert len(ident)==32 and manifest(original/role)==ident
    shutil.copytree(original/role,repeat/role)
    assert manifest(repeat/role)==ident
for name in ('representative.json','cpython-worker.py','run.sh'):
    shutil.copyfile(original/name,repeat/name)
assert sha(repeat/'representative.json')==identity['catalogs']['representative.json']['sha256']
assert sha(repeat/'cpython-worker.py')==identity['cpythonWorkerSHA256']
assert b'\r' not in (repeat/'run.sh').read_bytes()
lanes=[['diagnostic.json-service-quantity-totals','warm'],['diagnostic.json-service-sparse-records','warm']]
save(repeat/'jobs.json',json.dumps(dict(warm=lanes),indent=2)+'\n')
identity['catalogs']['jobs.json']['sha256']=sha(repeat/'jobs.json')
identity['purpose']='Confirm sparse and dense document results under one-CPU affinity after the variable dense control.'
save(repeat/'identity.json',json.dumps(identity,indent=2)+'\n')
collector=(original/'collect.py').read_text(encoding='utf-8')
for a,b in (('assert len(jobs) == 5 and','assert len(jobs) == 2 and'),('warmupSeconds=3','warmupSeconds=6'),('accumulate 3 seconds','accumulate 6 seconds')):
    assert collector.count(a)==1
    collector=collector.replace(a,b)
compile(collector,'collect.py','exec')
save(repeat/'collect.py',collector)
summary=(lab/'summarize.py').read_text(encoding='utf-8')
for a,b in (("lab / 'local'","lab / 'confirmation'"),("receipt['warmJobs'] == 5","receipt['warmJobs'] == 2"),("len(raw['jobs']) == 5","len(raw['jobs']) == 2"),('timedBatches=140','timedBatches=56')):
    assert summary.count(a)==1
    summary=summary.replace(a,b)
compile(summary,'summarize-confirmation.py','exec')
save(lab/'summarize-confirmation.py',summary)
save(repeat/'pinned.sh','''set -eu
root=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
cpu=$(python3 -c 'import os; print(max(os.sched_getaffinity(0)))')
printf '%s\\n' "$cpu" > "$root/affinity.txt"
exec taskset --cpu-list "$cpu" /bin/sh "$root/run.sh"
''')
