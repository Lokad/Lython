from pathlib import Path

lab = Path(__file__).resolve().parent
template = lab.with_name('ready-shipment-rows-20261126')/'prepare-quiet.py'
source = template.read_text(encoding='utf-8')
source = source.replace("baseline=lab.parent/'json-magnitude-utf8-20261126'", "baseline=lab.parent/'identity-comparisons-20261126'")
source = source.replace("source=(baseline/'quiet.py').read_text", "source=(lab.with_name('json-magnitude-utf8-20261126')/'quiet.py').read_text")
source = source.replace('1753','1758').replace('ready-shipment-rows','arithmetic-operand-borrows')
source = source.replace("'lython-b1751-fixtures','lython-b1758-fixtures'", "'lython-b1756-fixtures','lython-b1758-fixtures'")
source = source.replace("donor=base/'json-magnitude-utf8-b1751-20261126'", "donor=base/'identity-comparisons-b1756-20261126'")
old = """    ['diagnostic.shipment-bound-starmap','warm-async'],
    ['diagnostic.shipment-retained-zip','warm-async'],
    ['diagnostic.shipment-routing-callbacks','warm-async'],
    ['diagnostic.shipment-bound-starmap','warm'],"""
new = """    ['scripts.csv-meter-report.typed-unicode','warm'],
    ['diagnostic.shipment-routing-callbacks','warm-async'],
    ['diagnostic.shipment-file-fed-map','warm-async'],"""
assert source.count(old)==1
source = source.replace(old,new)
source = source.replace("body=body.replace('len(jobs) == 3','len(jobs) == 4')","")
source = source.replace(".replace('seconds=170','seconds=219')","")
source = source.replace(".replace('RuntimeMaxSec=210','RuntimeMaxSec=270')","")
source = source.replace("source=source\n","")
source = source.replace('Compare fixed zip unpack and starmap ready results against retained tuple and synchronous controls.',
                        'Compare one operand read on typed CSV and shipment with the file-fed map control.')
start = source.index("start=source.index('bytes=shutil.disk_usage(base).free')")
end = source.index("payload=quiet/'stage.tar.gz'",start)
source = source[:start] + "compile(source,'quiet.py','exec');write(lab/'quiet.py',source)\n" + source[end:]
source = source.replace(",replicaSHA256=sha(replica),\n     replicaBytes=replica.stat().st_size)",")")
exec(compile(source,str(template),'exec'),{'__file__':str(lab/'prepare-quiet.py')})