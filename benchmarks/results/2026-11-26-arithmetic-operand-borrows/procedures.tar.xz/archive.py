from pathlib import Path
import hashlib
import json
import shutil
import subprocess
import tarfile

lab = Path(__file__).resolve().parent
quiet = lab/'comparison/quiet'
root = lab.parents[3]
result = root/'benchmarks/results/2026-11-26-arithmetic-operand-borrows'
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
def read(path):
    return json.loads(path.read_text(encoding='utf-8'))
def git(*args):
    return subprocess.check_output(['git',*args],cwd=root)
identity=read(quiet/'identity.json')
assert git('rev-parse','HEAD').decode().strip()==identity['sourceRevision']
patch=git('diff','--binary','--','src')
assert patch==(lab/'candidate.patch').read_bytes()
assert hashlib.sha256(patch).hexdigest()==identity['sourcePatchSHA256']
(lab/'tests.patch').write_bytes(git('diff','--binary','--','tests'))
terminal=read(quiet/'terminal-status.json')
receipt=terminal['receipt']
assert not terminal['live'] and not terminal['fixtures'] and terminal['exitCode']=='0'
assert all(receipt[field] for field in ('complete','allWorkersJoined','quietBeforeAndAfter',
                                       'guestFixturesRemoved','archivedAndVerifiedUnderLease'))
assert receipt['archiveSHA256']==sha(quiet/'observations.tar.xz')
result.mkdir()
for name in ('summary.json','allocation-summary.json'):
    shutil.copyfile(lab/name,result/name)
for name in ('identity.json','terminal-status.json','observations.tar.xz'):
    shutil.copyfile(quiet/name,result/name)

roles=('reference','candidate')
routes = {role:read(lab/'instrumented'/role/'routes.json')['rows'] for role in roles}
summary=[]
for rows in zip(*(routes[role] for role in roles),strict=True):
    old,new=rows
    assert old['id']==new['id'] and old['asynchronous']==new['asynchronous']
    count=[]
    for row in rows:
        assert row['allowanceReturned']
        numbers=row['routes']
        count.append(sum(numbers[field] for field in ('Borrow','IntegerHead','Floating','ObjectRead','Fallback')))
    summary.append(dict(id=old['id'],asynchronous=old['asynchronous'],arithmeticSourceReads=count,
                        globalResolutions=[row['routes']['Global'] for row in rows],
                        admittedPeaks=[row['peakExecutionMemoryBytes'] for row in rows],
                        routes=dict(zip(roles,(row['routes'] for row in rows),strict=True))))
(result/'routes.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8',newline='\n')

local=('archive.py','prepare.py','prepare-quiet.py','verify-routes.py','quiet.py','summarize.py','candidate.patch','tests.patch',
       'reference-verify.json','candidate-verify.json','reference-allocation.json','candidate-allocation.json',
       'build.log','build-win.log','frozen-build.log','test-ubuntu.sh','Lokad.Lython.Tests-win11.log',
       'Lokad.Lython.PublicApi.Tests-win11.log','Lokad.Lython.Tests-ubuntu10.log','Lokad.Lython.PublicApi.Tests-ubuntu10.log',
       'instrumented/cases.json')
with tarfile.open(result/'procedures.tar.xz','w:xz') as archive:
    for name in local: archive.add(lab/name,arcname=name)
    for role in roles:
        for name in ('diagnostic.patch','Program.cs','RouteProbe.csproj','routes.json','core.log','probe.log','verification.log'):
            path=f'instrumented/{role}/{name}'
            archive.add(lab/path,arcname=path)
    for name in ('collect.py','run.sh','jobs.json','representative.json','cpython-worker.py','launch.log'):
        archive.add(quiet/name,arcname='quiet/'+name)
    template=lab.with_name('json-magnitude-utf8-20261126')
    for name in ('prepare.py','quiet.py'):
        archive.add(template/name,arcname='template/'+name)
    template=lab.with_name('ready-shipment-rows-20261126')
    archive.add(template/'prepare-quiet.py',arcname='template/prepare-quiet.py')
with tarfile.open(result/'procedures.tar.xz') as archive:
    assert archive.extractfile('candidate.patch').read()==patch
for row in summary:
    print(row['id'],row['asynchronous'],row['arithmeticSourceReads'],row['globalResolutions'])