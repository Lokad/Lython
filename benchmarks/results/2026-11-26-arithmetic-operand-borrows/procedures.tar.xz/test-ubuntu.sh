set -eu
export DOTNET_ROOT="$HOME/.dotnet"
export PATH="$DOTNET_ROOT:$PATH"
lab="$PWD/.git/agent-notes/review-20261031/arithmetic-operand-borrows-20261126"
filter='(FullyQualifiedName~Arithmetic|FullyQualifiedName~Integer|FullyQualifiedName~Float|FullyQualifiedName~Comparison|FullyQualifiedName~Closure|FullyQualifiedName~Captured|FullyQualifiedName~Operand|FullyQualifiedName~NumericProtocol|FullyQualifiedName~AdmissionFailure)&FullyQualifiedName!~LythonProbeCliTests&Category!=Stress'
for suite in Lokad.Lython.Tests Lokad.Lython.PublicApi.Tests; do
 log="$lab/$suite-ubuntu10.log"
 if dotnet test "tests/$suite/$suite.csproj" -c Release -f net10.0 --artifacts-path "$lab/ubuntu" --filter "$filter" > "$log" 2>&1; then
  tail -5 "$log"
 else
  tail -38 "$log"
  exit 1
 fi
done
