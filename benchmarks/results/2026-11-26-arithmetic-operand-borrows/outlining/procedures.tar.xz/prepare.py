from pathlib import Path

lab = Path(__file__).resolve().parent
template = lab.with_name('json-magnitude-utf8-20261126') / 'prepare.py'
body = template.read_text(encoding='utf-8')
runtime = 'src/Lokad.Lython/Runtime/'
changed = [runtime + name for name in (
    'LythonRuntime.Executable.Arithmetic.cs', 'LythonRuntime.Executable.Inputs.cs',
    'LythonRuntime.Executable.Integers.cs', 'LythonRuntime.Executable.Interpreter.Dispatch.cs',
    'LythonRuntime.Executable.NativePrefix.cs', 'LythonRuntime.Executable.Operands.cs',
    'LythonRuntime.Executable.cs',
)]
substitutions = {
    "baseline = lab.parent/'short-path-cpython-20261126'": "baseline = lab.parent/'identity-comparisons-20261126'",
    "prior = lab.parent/'json-integer-r46'": "prior = lab.parent/'ready-shipment-rows-20261126'",
    "assert revision.startswith('0a0e32c16')": "assert revision.startswith('2d2905bc8')",
    "== ['src/Lokad.Lython/Runtime/LythonRuntime.Json.Deserialize.cs']": "== " + repr(changed),
    "assert before['sourceRevision']==revision and len(reference)==32":
        "assert git('diff','--binary',before['sourceRevision'],revision,'--','src') == (baseline/'candidate.patch').read_bytes()\n"
        "assert len(reference)==32",
    "catalog=read(prior/'catalog.json')\ncatalog['cases']=[case for case in catalog['cases'] if case['id'].startswith('scripts.json-summary-helpers.')]\nassert len(catalog['cases'])==3":
        "catalog=read(prior/'representative.json')\n"
        "typed=read(lab.with_name('typed-csv-text-20261124')/'external/representative.json')\n"
        "ids=['diagnostic.shipment-routing-callbacks','scripts.csv-meter-report.typed-unicode',"
        "'scripts.csv-meter-report.explicit-float','diagnostic.shipment-file-fed-map']\n"
        "choices={case['id']:case for source in (catalog,typed) for case in source['cases']}\n"
        "catalog['cases']=[choices[identifier] for identifier in ids]\n"
        "assert len(catalog['cases'])==4",
    "checked['caseCount']==3": "checked['caseCount']==4",
    "f'{role}-refined-allocation.json'": "f'{role}-allocation.json'",
}
for old, new in substitutions.items():
    assert body.count(old)==1, old
    body = body.replace(old,new)
exec(compile(body,str(template),'exec'),{'__file__':str(lab/'prepare.py')})