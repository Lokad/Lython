from pathlib import Path
import hashlib
import json
import shutil

lab=Path(__file__).resolve().parent
comparison=lab/'local'
comparison.mkdir()
template=lab.with_name('shared-assignment-bindings-20261125')/'local-confirmation'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
identity=json.loads((lab/'identity.json').read_text(encoding='utf-8'))
for role, files in identity['imageFiles'].items():
    assert len(files)==32 and {p.name:sha(p) for p in (lab/role).iterdir()}==files
    shutil.copytree(lab/role,comparison/role)
    assert {p.name:sha(p) for p in (comparison/role).iterdir()}==files
shutil.copyfile(lab/'representative.json',comparison/'representative.json')
shutil.copyfile(template/'cpython-worker.py',comparison/'cpython-worker.py')
assert sha(comparison/'cpython-worker.py')==identity['cpythonWorkerSHA256']
def write(path,text):
    path.write_text(text,encoding='utf-8',newline='\n')
def save(path, data):
    write(path,json.dumps(data,indent=2)+'\n')
save(comparison/'jobs.json', {'warm':[
 ['diagnostic.shipment-file-fed-map','warm-async'],
 ['scripts.csv-meter-report.typed-unicode','warm'],
 ['diagnostic.shipment-routing-callbacks','warm-async'],
]})
identity['coreSHA256'].update({role+'-control':identity['coreSHA256'][role] for role in identity['imageFiles']})
identity['catalogs']={name:{'sha256':sha(comparison/name)} for name in ('representative.json','jobs.json')}
identity['purpose']='Check the outlined operand variant with pinned local workers and same-source controls.'
save(comparison/'identity.json',identity)
body=(template/'collect.py').read_text(encoding='utf-8')
assert body.count('len(jobs) == 4')==1
body=body.replace('len(jobs) == 4','len(jobs) == 3').replace('lython-bindings-fixture-','lython-arithmetic-fixture-')
write(comparison/'collect.py',body)
shutil.copyfile(template/'run.sh',comparison/'run.sh')
assert b'\r' not in (comparison/'run.sh').read_bytes()

prior=(lab.with_name('arithmetic-operand-borrows-20261126')/'summarize.py').read_text(encoding='utf-8')
start=prior.index("quiet = lab / 'comparison/quiet'")
end=prior.index("assert receipt['archiveSHA256']",start)
prior=prior[:start]+'''quiet = lab / 'local'
read = lambda p: json.loads(p.read_text(encoding='utf-8-sig'))
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
identity = read(quiet / 'identity.json')
receipt = read(quiet / 'archive-receipt.json')
assert (quiet/'exit-code.txt').read_text(encoding='utf-8').strip()=='0'
assert all(receipt[field] for field in ('allWorkersJoined','archivedAndVerifiedUnderLease',
                                        'guestFixturesRemoved','complete'))
'''+prior[end:]
write(lab/'summarize.py',prior)