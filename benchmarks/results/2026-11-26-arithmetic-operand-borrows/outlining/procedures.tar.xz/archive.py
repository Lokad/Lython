from pathlib import Path
import hashlib
import json
import shutil
import subprocess
import tarfile

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
initial=lab.with_name('arithmetic-operand-borrows-20261126')
pinned=lab/'local'
out=repo/'benchmarks/results/2026-11-26-arithmetic-operand-borrows/outlining'
sha=lambda path:hashlib.sha256(path.read_bytes()).hexdigest()
def read(path):
    return json.loads(path.read_text(encoding='utf-8'))
def git(*args):
    return subprocess.check_output(['git',*args],cwd=repo)
identity=read(pinned/'identity.json')
before=read(initial/'identity.json')
assert identity['imageFiles']['reference']==before['imageFiles']['reference']
assert not git('diff','--name-only',before['sourceRevision'],identity['sourceRevision'],'--','src')
assert git('rev-parse','HEAD').decode().strip()==identity['sourceRevision']
patch=git('diff','--binary','--','src')
assert patch==(lab/'candidate.patch').read_bytes()
assert hashlib.sha256(patch).hexdigest()==identity['sourcePatchSHA256']
(lab/'tests.patch').write_bytes(git('diff','--binary','--','tests'))
receipt=read(pinned/'archive-receipt.json')
assert receipt['quietBeforeAndAfter'] is None and receipt['warmJobs']==3
assert all(receipt[field] for field in ('complete','allWorkersJoined','guestFixturesRemoved','archivedAndVerifiedUnderLease'))
assert (pinned/'exit-code.txt').read_text(encoding='utf-8').strip()=='0'
assert sha(pinned/'observations.tar.xz')==receipt['archiveSHA256']
out.mkdir()
for name in ('summary.json','allocation-summary.json'):
    shutil.copyfile(lab/name,out/name)
for name in ('identity.json','archive-receipt.json','observations.tar.xz'):
    shutil.copyfile(pinned/name,out/name)
here=('archive.py','prepare.py','prepare-local.py','test-ubuntu.sh','run-local.sh',
      'candidate.patch','tests.patch','reference-verify.json','candidate-verify.json',
      'reference-allocation.json','candidate-allocation.json','frozen-build.log',
      'jit-arithmetic.txt','jit-arithmetic.log','jit-allocation-diagnostic.json','summarize.py','local-console.log',
      'Lokad.Lython.Tests-win11.log','Lokad.Lython.PublicApi.Tests-win11.log',
      'Lokad.Lython.Tests-ubuntu10.log','Lokad.Lython.PublicApi.Tests-ubuntu10.log')
with tarfile.open(out/'procedures.tar.xz','w:xz') as archive:
    for name in here:
        archive.add(lab/name,arcname=name)
    for name in ('collect.py','run.sh','representative.json','jobs.json','cpython-worker.py'):
        archive.add(pinned/name,arcname='pinned/'+name)
    archive.add(lab.with_name('json-magnitude-utf8-20261126')/'prepare.py',arcname='template/prepare.py')
    archive.add(lab.with_name('shared-assignment-bindings-20261125')/'local-confirmation/collect.py',
                arcname='template/collect.py')
with tarfile.open(out/'procedures.tar.xz') as archive:
    assert archive.extractfile('candidate.patch').read()==patch