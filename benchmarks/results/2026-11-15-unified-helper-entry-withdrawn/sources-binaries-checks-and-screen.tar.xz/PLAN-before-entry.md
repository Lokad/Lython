# Lokad.Lython 0.11.0

Updated 2026-11-15 UTC. Git-ignored: never force-add. Publication/tagging postponed.
Objective: coherent simplification and substantial complete-script gains, including
compile-once/run-once. Closing an isolated experiment does not finish this goal.
Current contracts belong in docs; original conditions and every adverse result
remain in [EXPERIMENTS](benchmarks/EXPERIMENTS.md) and immutable results.

## Actual delivery status

| State | Evidence and limits |
| --- | --- |
| Latest fully qualified runtime | Shared slots/compiled returns `cf754dc7` / frozen `95798eb9`, fixture correction `b4e98b91`: [43662618745 GREEN, cached](benchmarks/results/2026-11-15-shared-executable-slots/delivery/README.md). Windows/Ubuntu actual11/10 each4,774 internal/17,849 public ordinary, original13/406 stress, installed Release consumers. All585sourceinputs proved. Original43fixture failures retained; no unchanged requalification. |
| Committed delivery candidate | `ec6c0416` / frozen `6164a933`: R376 private prepaid word segment plus R375 overlapping-binding fix `78ace9c4`. [43669461343](https://github.com/Lokad/Lython/actions/runs/43669461343) ordinary Release11/10 passed on both Windows/Ubuntu; package/stress still running at03:03UTC, no full-green claim. Focused actual11/10 each53internal/197public,144isolatedPython controls/16goldenspass. |
| Retained R376 outcome | [B767/source pair](benchmarks/results/2026-11-15-closed-word-segment/README.md): captured-text warm elapsed−2.89..−5.68%, widerCPU−3.48..−5.26%; allocationflat. Fresh magnitude inconclusive (reference spread8.77%). Accept unresolved JSON+.80..+2.70%elapsed/0..+3.41%CPU for reduced machinery/warm benefit. Restoring ordinary arithmetic ABI did not resolve it. CSV varies; no universal, heap/tail or causality claim. OriginalB766 remains. |
| Retained R373 tradeoffs | [Source pair](benchmarks/results/2026-11-15-shared-executable-slots/README.md): invoice−7.89%allocation, elapsed−1.81..−2.80%/CPU−1.49..−2.94%; short diagnostic−18.83%allocation. Accept observed-helper+2.83..+4.65%elapsed/+4.28..+5.04%CPU and possible fulfillment fresh+.30..+2.76%elapsed (CPUmixed) for0.11. Later controls do not erase them. |
| External baseline | [B764](benchmarks/results/2026-11-15-shared-slots-cpython-checkpoint/README.md), exactCF/957 versusCPython3.13.16: invoice1.21–1.22xwarm; fulfillment1.18–1.21xwarm/fresh,1.12–1.13xcompile; capturedtext1.42–1.44xwarm. [B768](benchmarks/results/2026-11-15-word-segment-cpython-checkpoint/README.md),ec6c/6164: text1.37–1.39xwarm,JSON.829–.833xwarm;2jobs100.252s/allgates/closed. Other guide rows remain explicitly named. |

Completed/preserved: shared compiler facts/nonlocal correction and retention
cleanup; direct UTF-8 formatting/storage; native helper returns; final argument
slots/linear continuations; immutable plain builtins; native/owned loops and tuple
returns; shared arithmetic/range positions; bulk CSV/shared keys; UTF-8 JSON and
incremental XML. R373 removes native side arrays/loans/flags/capacity facts and
generic cache plumbing. R375 preserves Python errors/effects for overlapping
histogram locals. R374 current text attribution is closed with the R376 decision;
its useful lookup/update leaves are not a removable percentage.

Native helper returns established about19–20%less allocation; original elapsed
results remain diagnostic. Formatting established−8.67%allocation; [controlled
confirmation](benchmarks/results/2026-11-02-formatting-confirmation/README.md)
supports report elapsed/CPU−5–8%. Original adverse15.125ms remains unexplained.
These historical revisions are not measurements of today's HEAD.

## Prioritized deliverables and completion criteria

1. **Close this coherent delivery checkpoint.** Cache43669461343terminal/logs once;
   prove585inputs, Windows/Ubuntu actual11/10, original stress/installed consumers.
   Expected each4,774internal/17,851public ordinary (R375adds2publiccases), original
   13/406stress. Investigate failures without relaxing assertions/timeouts.
   B768 text/JSON refresh is complete with all controls/adverse points retained.
   Compilation/fresh remain separate named B764 observations,
   not inferred for6164. State I/O/validation/prior-result-cleanup boundaries.
   No unchanged R376retiming: its retention/debt decision above is made.

2. **Whole call/frame construction and operand transport: redesign gate.**
   [R377 current file gate](benchmarks/results/2026-11-15-file-call-construction-assessment/README.md)
   is complete:746guest leaves,149unknown, entry/dispatch/I/O/admission mixed.
   Decline exception-shell-only deletion and arena replay; no substantial removable
   activation is proved. Preserve this map rather than resampling unchanged code.
   Hypothesis: complete helper boundaries still repeat context, exception or
   operand work after direct binding/shared final slots. Existing profiles do not
   prove a missing arena or boxing dominance. Source-map one representative
   remaining report/long-field shape only if it resolves a specific design question;
   do not repeat current file/text attribution. Name an entire removable
   stage, callers and displaced implementation. Final slots, direct receiver
   calls and deferred contexts already exist. No replacement dispatcher/controller.
   Acceptance: closures/identity/order, protected returns/exception context,
   generators, real I/O suspension, managed body-local stack safety, cancellation,
   terminal refusal, retained funding and joined cleanup. Completion: focused
   checks plus bounded whole-script warm/compile-to-result source pair with
   unchanged short/observed/CSV/JSON controls; retain/debt, justified refinement
   or withdrawal. Slower call-arena/control designs remain lessons, not automatic
   revival targets. A closed source gate is not completion of the wider objective.

3. **Per-record construction and remaining bulk conversions.** Reassess complete
   CSV/JSON/report pipelines. Bulk CSV already adopts final rows/shared keys,
   scans delimiter runs and combines field admission; historical6–8%improvements
   missed rigid thresholds, not semantics; that opportunity is already delivered
   ([reassessment](benchmarks/results/2026-11-10-record-construction-assessment/README.md)).
   R377 confirms inline 8-byte fields make aggregate row-payload sharing a tradeoff,
   not a missing optimization. Remove real remaining storage/transport,
   not repeat R355raw ranges/scratch. Select one stage from current evidence;
   cover malformed-record timing, headers, aliases, wide rows, Unicode/context
   expansion, hooks and replacement-peak funding. Compare complete scripts and
   unchanged controls with allocation/CPU separate. Finish by deleting displaced
   implementation and deciding remaining debt, not accumulating local tweaks.

4. **Frontend/invocation setup follow measured fresh costs.** Shared facts are
   delivered; fulfillment compilation~.130ms versus~8ms execution. Select a shape
   where repeated analysis/retained representations materially affect compile-to-
   result before another compiler/JIT redesign. Preserve diagnostics/scope/nonlocal
   facts and provider consistency. Stop a source gate after one usable map and
   design/decline decision; continue the wider roadmap.

5. **Independent Lython-owned regex development.** Core owns Python semantics,
   nativeUTF8/original-subject windows, byte/scalar positions, captures/errors,
   explicit owners/current tokens. Separate contract controls, backend semantic/
   interruption qualification and performance. Development producers/adapter-local
   bridges allowed outside core. Optional nonpackable adapter0.4 stays pinned;
   dev80qualification cached. [Source assessment d1822732](benchmarks/results/2026-11-14-regex-provider-capabilities/source-update-d1822732.json)
   leaves final-adapter gaps: separate one-match scratch/escaping-result owners;
   nativeUTF8group-name enumeration/copy; token-independent cursor creation with
   cancellable preparation. These defer only affected final released-adapter
   qualification. Source inspection is not pin promotion or package/safety/
   interruption qualification. Publication cannot stop independent Lython work.

Before release: correct, concretely accept or withdraw R359/R361/R365/R368short-
helper debt, R362materialization/text uncertainty and R370invoice regression.
Preserve original conditions; later collections do not erase them. Startup,
contention, pending-I/O latency, RSS/heap peaks and embedding tails remain
unmeasured; allocation/full-GC counts do not establish these outcomes.

## Evidence policy and lasting constraints

Timeouts, unstable controls and inconclusive results establish uncertainty, not
failed designs. Allow bounded confirmation/refinement/measurement correction when
justified; retain originals/every adverse result. No blanket one-attempt/no-retiming/
permanent-closure rules. Percentages inform, not automatically veto. Architectural
simplification, allocation and CPU improvement are separate. Temporary regression
requires a completion milestone and debt decision.

Focused Release checks during iteration; batch full platforms/frameworks/original
stress/installed consumers at coherent checkpoints. Freeze copies/prove sources,
worker and adapter identity; force rebuild after restores. Persist/verify evidence
under VM lease before RAM teardown, preserving254/252MiB floors. Retire only exact
committed archived duplicates after path/UID/link/hash proof. B767/B768closed with no remaining users/fixtures. Space live GitHub polls>=240s; never requery terminal runs.

[AGENTS](AGENTS.md) remains binding: fully managed/memory-safe; no unsafe/Unsafe,
pointers/PInvoke/native probing. Preserve managed stack safety, host mediation,
checked bounds/bounded I/O/cycle protection. Tokens control time, no fuel/quotas.
Borrowed shared allowance funds capacity/overlap/aliases/results/caches/pending
users through awaited cleanup. First refusal terminal; no retry/tracing/weak
reclamation/forcedGC/hidden caps/abandoned work. Long streams use bounded host
commands. Only core packaged; adapter nonpackable. Publication/tagging postponed.
