from pathlib import Path
import json,os,subprocess,time
r=Path(__file__).parent
sdk='C:/Users/JoannesVermorel/.dotnet11'
env={k:v for k,v in os.environ.items()if k.casefold()!='path'}
env['DOTNET_ROOT']=sdk;env['PATH']=sdk+';C:/Python313;'+next(v for k,v in os.environ.items()if k.casefold()=='path')
fil='(Category!=Stress)&('+ '|'.join('FullyQualifiedName~'+name for name in ['ComposedHelperTests','OrdinaryFunctionCallTests','OrdinaryMethodCallTests','NamedFunctionBindingTests','CallArgumentEvaluationTests','PositionalCallSemanticsTests','ProtectedHelperExecutionTests','NativeTupleReturnTests','NativeReturnFunctionTests','LargeHelperExecutionTests','WhileHelperExecutionTests','ForHelperExecutionTests','FunctionBindingLifetimeTests','FunctionDefaultMetadataTests','PreparedFunctionHostLifetimeTests','ExecutableCallLifetimeTests','FrameIntegerLifetimeTests','FunctionWorkspaceCapacityTests','AsyncFunctionHostingTests','OrderedFunctionContinuationTests','HelperContinuationLifetimeTests'])+')'
start=time.monotonic();log=r/'public-net11.0.log';assert not log.exists()
with log.open('w',encoding='utf-8')as f:
 done=subprocess.run([sdk+'/dotnet.exe','test','tests/Lokad.Lython.PublicApi.Tests/Lokad.Lython.PublicApi.Tests.csproj','-c','Release','-f','net11.0','--filter',fil,'--logger','trx;LogFileName=r378-public-net11.trx'],env=env,stdout=f,stderr=subprocess.STDOUT,timeout=180)
(r/'public-checks.json').write_text(json.dumps(dict(framework='net11.0',exitCode=done.returncode,elapsedSeconds=time.monotonic()-start,filter=fil),indent=2)+'\n',encoding='utf-8',newline='\n')
print(log.read_text(encoding='utf-8')[-4500:],flush=True)
raise SystemExit(done.returncode)
