from pathlib import Path
import contextlib,hashlib,importlib.util,json,math,os,shutil,statistics,subprocess,tarfile,tempfile,time
r=Path(__file__).parent;old=r.parent/'closed-word-segment-r376/refinement';sdk='C:/Users/JoannesVermorel/.dotnet11'
prior=json.loads((old/'candidate-identity.json').read_text(encoding='utf-8'))
sources={p:hashlib.sha256(Path(p).read_bytes()).hexdigest()for p in prior['sources']}
env={k:v for k,v in os.environ.items()if k.casefold()!='path'};env['DOTNET_ROOT']=sdk;env['PATH']=sdk+';C:/Python313;'+next(v for k,v in os.environ.items()if k.casefold()=='path')
assert json.loads((r/'public-checks.json').read_text(encoding='utf-8'))['exitCode']==0
with(r/'freeze-build.log').open('w',encoding='utf-8')as f:
 done=subprocess.run([sdk+'/dotnet.exe','build','src/Lokad.Lython/Lokad.Lython.csproj','-c','Release','-f','net11.0','--no-restore','--no-incremental','-m:1','-v','quiet'],env=env,stdout=f,stderr=subprocess.STDOUT,timeout=120)
assert done.returncode==0,(r/'freeze-build.log').read_text(encoding='utf-8')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert all(sha(p)==h for p,h in sources.items())
for role in ['reference','candidate']:shutil.copytree(old/'candidate',r/role)
shutil.copyfile('src/Lokad.Lython/bin/Release/net11.0/Lokad.Lython.dll',r/'candidate/Lokad.Lython.dll')
shutil.copyfile(r/'candidate/Lokad.Lython.dll',r/'candidate-core.dll')
assert sha(r/'reference/Lokad.Lython.dll')==prior['coreSHA256']['candidate']
assert all(sha(r/role/name)==h for role in ['reference','candidate']for name,h in prior['auxiliaryFiles'].items())
identity=dict(headBeforeCommit=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),referenceRuntimeCommit='ec6c041672a5e6edf85676bfe2442cd62abe1b76',referenceFullQualification='43669461343GREENterminalcached',sources=sources,productionFiles=len(sources),changedProductionInputs=[p for p,h in sources.items()if prior['sources'][p]!=h],coreSHA256={role:sha(r/role/'Lokad.Lython.dll')for role in ['reference','candidate']},auxiliaryFiles=prior['auxiliaryFiles'],frozenFiles={role:{p.name:sha(p)for p in(r/role).iterdir()if p.is_file()}for role in ['reference','candidate']},qualified=False,status='R378 active unified funded helper entry prototype; first285public Release/net11 semantic checks pass. White-box migration and full qualification not claimed.')
(r/'candidate-identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8',newline='\n')
with tarfile.open(r/'candidate-sources.tar.xz','w:xz')as archive:
 for p in sources:archive.add(p,arcname=p)
shutil.copyfile(old/'catalog.json',r/'catalog.json')
spec=importlib.util.spec_from_file_location('protocol','benchmarks/cpython-worker.py');protocol=importlib.util.module_from_spec(spec);spec.loader.exec_module(protocol)
catalog=(r/'catalog.json').resolve();cases={c['id']:c for c in json.loads(catalog.read_text(encoding='utf-8'))['cases']}
out=dict(complete=False,identity=identity,location='Local Windows development box; no quiet-machine or portable CPU claim. Short construction-regression screen only.',warmupBoundary='full request wall time',elapsedBoundary='Unchanged command-v2; mediated filesystem I/O, stdout/file goldens and prior-result cleanup; excludes startup/compile/reset/protocol/final cache teardown.',jobs=[])
def save(): (r/'local-screen.json').write_text(json.dumps(out,indent=2)+'\n',encoding='utf-8',newline='\n')
class Worker:
 def __init__(self,label,case,stack):
  self.label,self.case,self.seq,self.process=label,case,0,None
  self.fixture=tempfile.TemporaryDirectory(prefix='lython-comparison-files-');self.errors=tempfile.TemporaryFile();stack.callback(self.close)
  role='candidate'if label.startswith('candidate')else'reference'
  self.process=subprocess.Popen([sdk+'/dotnet.exe',str((r/role/'Lokad.Lython.Benchmarks.dll').resolve()),'--compare','worker','--catalog',str(catalog)],cwd=self.fixture.name,env=env,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=self.errors)
  self.ready=protocol.read_frame(self.process.stdout);assert self.ready and self.ready['status']=='Ready',self.ready
  assert self.ready['catalogSha256']==sha(catalog)
  for name,h in identity['frozenFiles'][role].items():
   library=next((v for v in self.ready['libraries']if Path(v['path']).name==name),None)
   if library:assert library['sha256'].lower()==h
  self.request('verify',2)
 def request(self,op,count):
  self.seq+=1;q={k:self.case[k]for k in ['sourceSha256','fixtureSha256','expectedOutputSha256']};q.update(protocolVersion=2,requestId=self.seq,operation=op,caseId=self.case['id'],lane='warm',iterations=count)
  start=time.monotonic();protocol.write_frame(self.process.stdin,q);res=protocol.read_frame(self.process.stdout);self.lastSeconds=time.monotonic()-start
  assert res and res['status']==('Equivalent'if op=='verify'else'Completed'),res
  assert res['completedInvocations']==count and res['actualOutputSha256']==self.case['expectedOutputSha256']and res['actualFilesSha256']==self.case.get('expectedFilesSha256')
  return res
 def close(self):
  try:
   if self.process:
    if self.process.poll()is None:
     protocol.write_frame(self.process.stdin,dict(protocolVersion=2,requestId=self.seq+1,operation='quit'));assert protocol.read_frame(self.process.stdout)['status']=='Closed'
    assert self.process.wait(timeout=10)==0
    self.errors.seek(0);assert not self.errors.read()
  finally:
   if self.process:
    if self.process.poll()is None:self.process.kill();self.process.wait()
    self.process.stdin.close();self.process.stdout.close()
   self.errors.close();self.fixture.cleanup()
started=time.monotonic();save()
for caseId in ['scripts.file-search.large.protected','scripts.csv-invoice.large','scripts.csv-fulfillment.large','diagnostic.loop-helper.short-zero.large']:
 assert time.monotonic()-started<110
 with contextlib.ExitStack()as stack:
  workers=[Worker(label,cases[caseId],stack)for label in ['reference','candidate','candidate-control','reference-control']]
  counts=[];warmups=[]
  for w in workers:
   count=1;end=time.monotonic()+2.5;rows=[]
   while time.monotonic()<end:
    rows.append(w.request('batch',count));count=max(1,min(100000,math.ceil(count*.15/max(w.lastSeconds,.000001))))
   counts.append(count);warmups.append(rows)
  samples=[]
  for round in range(5):
   for i in [(round+offset)%4 for offset in range(4)]:samples.append(dict(round=round,label=workers[i].label,response=workers[i].request('batch',counts[i])))
  med={w.label:statistics.median(1000*s['response']['elapsedTicks']/s['response']['clockFrequency']/s['response']['completedInvocations']for s in samples if s['label']==w.label)for w in workers}
  result=dict(case=caseId,identities={w.label:w.ready for w in workers},counts=counts,warmups=warmups,samples=samples,medianMilliseconds=med,changePercent=sorted(100*(med[a]/med[b]-1)for a in ['candidate','candidate-control']for b in ['reference','reference-control']))
 result['allWorkersJoinedAndFixturesRemoved']=True;out['jobs'].append(result);save();print(caseId,med,result['changePercent'],flush=True)
out.update(complete=True,elapsedSeconds=time.monotonic()-started,allGoldensAndBudgetsPassed=True,allUsersJoined=True,portablePerformanceClaim=False);save()
