from pathlib import Path
import hashlib,json,subprocess,tarfile
r=Path(__file__).parent
assert not(r/'original-sources.json').exists()
prior=r.parent/'closed-word-segment-r376/refinement'
identity=json.loads((prior/'candidate-identity.json').read_text(encoding='utf-8'))
assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==h for p,h in identity['sources'].items())
paths=['src/Lokad.Lython/Runtime/'+n for n in ['PyExecutableFunction.cs','PyFunctionBase.cs','LythonRuntime.Executable.NativePrefix.cs','LythonRuntime.Executable.Calls.Invoke.cs','LythonRuntime.Executable.Calls.cs','LythonRuntime.Executable.Interpreter.Dispatch.cs']]+['src/Lokad.Lython/Frontend/ExecutableScript.CasedSplits.cs']
(r/'original-sources.json').write_text(json.dumps({p:Path(p).read_text(encoding='utf-8')for p in paths},indent=2)+'\n',encoding='utf-8',newline='\n')
(r/'original-identity.json').write_text(json.dumps(dict(head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),sources=identity['sources'],coreSHA256=identity['coreSHA256']['candidate']),indent=2)+'\n',encoding='utf-8',newline='\n')
(r/'PLAN-before-entry.md').write_text(Path('PLAN.md').read_text(encoding='utf-8'),encoding='utf-8',newline='\n')
p=Path('PLAN.md');s=p.read_text(encoding='utf-8');tag='2. **Whole call/frame construction and operand transport: redesign gate.**'
assert tag in s;s=s.replace(tag,'''2. **R378 active prototype: one existing funded compiled-call entry.**
   Shared slots and the one-idle-workspace cache now permit a changed design:
   ordinary compiled calls bind directly into their final admitted array and use
   the existing linear runner/native body. Remove the separate fixed16-slot
   helper ABI, repeated inline-binding eligibility, recursive native child-call
   handoff/abort path and its depth threshold. No new arena/controller/window
   representation or memory layer. Direct return optimization remains separate.
   R377 shows real call-entry work (61 of746guest leaves in StartNativeCall),
   not a removable percentage. Hypothesis: eliminate whole entry/transfer work
   and stack-buffer initialization while reusing already-funded final capacity.
   Unlike old B69/B61, no new saved records or owner/offset indirection is added.
   Preserve native instruction/typed-return optimizations and body stack guard;
   ordinary callbacks/protocols/generators and real suspension keep their semantics.
   Tradeoffs: formerly stack-only calls first admit final workspace; idle capacity
   remains charged until scope cleanup. Nested helpers can promote their caller
   at its exact call before the flat runner proceeds. Earlier denial is explicit.
   First check complete script goldens, calls/defaults/closure/return/exception
   context, cancellation/refusal and retained aliases. A short local source pair
   screens material construction regressions, not a portable CPU claim. If viable,
   focused actual11/10 plus one bounded quiet whole-script warm/fresh comparison
   (file/report/CSV and short/observed controls), separate allocation/CPU. Final
   completion is deleted obsolete machinery and retain/debt or withdrawal; full
   delivery only at retention. Preserve all adverse/original conditions. No
   fixed percentage veto; a justified changed refinement is allowed.

   **Broader call/frame source evidence:**''')
p.write_text(s,encoding='utf-8',newline='\n')
def change(path, transform):
 p=Path(path);old=p.read_text(encoding='utf-8');new=transform(old);assert old!=new,path;p.write_text(new,encoding='utf-8',newline='\n')
root='src/Lokad.Lython/Runtime/'
def executable(s):
 a=s.index('    internal bool CanStartInline =>');b=s.index('    internal override bool TryStartBoundInvocation',a);s=s[:a]+s[b:]
 s=s.replace('''StartInline(bound.Values.AsSpan(0, _codeObject.ValueStorageCapacity),
            bound.Assigned, bound, span, consumedByIteration, unpackedReturn, out unpacked, out result, out frame);''','''StartBoundPrefix(bound, span, consumedByIteration, unpackedReturn, out unpacked, out result, out frame);''')
 a=s.index('    private void StartInline(');b=s.index('    protected override object ExecuteBody(',a)
 s=s[:a]+'''    private void StartBoundPrefix(in BoundFunctionArguments bound, LythonSourceSpan span,
        bool consumedByIteration, Span<LythonRuntime.ExecutableSlot> unpackedReturn, out bool unpacked,
        out LythonRuntime.ExecutableSlot result, out LythonRuntime.ExecutionContext? frame)
    {
        unpacked = false;
        result = LythonRuntime.ExecutableSlot.FromObject(PyNone.Instance);
        frame = null;
        // Binding owns the final locals/operands through completion or transfer.
        // The existing workspace cache retains its capacity until command cleanup.
        var state = new LythonRuntime.NativeExecution(this,
            bound.Values.AsSpan(0, _codeObject.ValueStorageCapacity), consumedByIteration, unpackedReturn.Length);
        var entered = false;
        var transferred = false;
        try
        {
            Closure.EnterFunctionCall(span);
            entered = true;
            if (state.Run(span, out result, unpackedReturn))
            {
                unpacked = state.ReturnedUnpacked;
                return;
            }
            state.PrepareTransfer();
            frame = LythonRuntime.CreateNativeContinuation(this, bound, span, state.Index, state.LiveExtent,
                consumedByIteration, state.Failure);
            state.TransferOwnership();
            transferred = true;
        }
        catch (LythonRuntimeException error)
        {
            PyFunctionBinding.AnnotateException(error, Closure, Name, span);
            throw;
        }
        finally
        {
            try { state.Dispose(); }
            finally { if (entered && !transferred) Closure.LeaveFunctionCall(); }
        }
    }

'''+s[b:]
 return s
change(root+'PyExecutableFunction.cs',executable)
def base(s):
 a=s.index('    // No defaults, receiver insertion or dynamic binding during the borrow.');b=s.index('    /// <summary>States whether',a);return s[:a]+s[b:]
change(root+'PyFunctionBase.cs',base)
def native(s):
 a=s.index('    internal const int NativeValueCapacity = 16;');b=s.index('    // This view cannot survive a suspension.',a)
 s=s[:a]+'    internal const int MaxDirectTupleReturnItems = 16;\n\n'+s[b:]
 s=s.replace('        private ExecutionContext? _preparedChild;\n        private MemoryGovernor? _preparedChildOwner;\n','')
 s=s.replace('else if (!CallFunction(call, start, target, out result)) return false;', 'else return false; // The existing linear runner owns compiled function calls.')
 a=s.index('        private bool CallFunction(');b=s.index('        private bool TryReturnUnpackedTuple(',a);s=s[:a]+s[b:]
 a=s.index('        internal void TransferOwnership(');b=s.index('        private void DisposeValues()',a)
 s=s[:a]+'''        internal void TransferOwnership() => _transferred = true;

        internal void Dispose()
        {
            if (!_transferred) DisposeValues();
        }

'''+s[b:]
 return s
change(root+'LythonRuntime.Executable.NativePrefix.cs',native)
def invoke(s):
 s=s.replace('ExecutableCallSite call, int start, object target, out ExecutionContext? started)', 'ExecutableCallSite call, int start, object target)')
 a=s.index('            started = null;');b=s.index('            // These existing native receiver operations',a);s=s[:a]+s[b:]
 a=s.index('        internal static void AbortPreparedNativeCall(');b=s.index('        // The opcode has already read its evaluated target',a);s=s[:a]+s[b:]
 return s.replace('NativeValueCapacity','MaxDirectTupleReturnItems')
change(root+'LythonRuntime.Executable.Calls.Invoke.cs',invoke)
def calls(s):
 s=s.replace('current.TakePreparedNativeChild() ?? current.ExecuteUntilCall()', 'current.ExecuteUntilCall()').replace('current.TakePreparedNativeChild() ?? await current.ExecuteUntilCallAsync()', 'await current.ExecuteUntilCallAsync()')
 a=s.index('        internal void AdoptPreparedNativeChild(');b=s.index('        private void CloseInvocation(',a);return s[:a]+s[b:]
change(root+'LythonRuntime.Executable.Calls.cs',calls)
def dispatch(s):
 a=s.index('                            if (TryExecuteNativeCall(');b=s.index('                            if (invocation is null)',a)
 return s[:a]+'''                            if (TryExecuteNativeCall(ref execution, scope, invocation, call, callStart, target)) break;
'''+s[b:]
change(root+'LythonRuntime.Executable.Interpreter.Dispatch.cs',dispatch)
change('src/Lokad.Lython/Frontend/ExecutableScript.CasedSplits.cs',lambda s:s.replace('NativeValueCapacity','MaxDirectTupleReturnItems'))
print('R378 prototype: seven production inputs changed; original bytes/frozen image preserved; no tests changed yet.')
