from pathlib import Path
import hashlib,json,os,shutil,subprocess,tarfile,time
r=Path(__file__).parent;prior=r.parent/'closed-word-segment-r376/refinement'
d=json.loads((r/'local-screen.json').read_text(encoding='utf-8'));assert d['complete']and len(d['jobs'])==4 and d['allUsersJoined']
f=json.loads((r/'candidate-identity.json').read_text(encoding='utf-8'));assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==h for p,h in f['sources'].items())
(r/'completed-prototype.patch').write_bytes(subprocess.check_output(['git','-c','core.safecrlf=false','diff','--','src/Lokad.Lython']))
decision=dict(status='withdraw',reason='Unifying final funded entry removes241netlines but promotes nested synchronous callers and adds real state/allocation work. Initial285publicsemantic checks pass. Local complete-script screen shows invoice+11.7..+20.2%, short+17.7..+19.0%, fulfillment-5.7..-1.1%, file control inconclusive. No quiet-machine/portable CPU inference.',lesson='Workspace reuse avoids admission for idle reuse but cannot remove live nested-caller representation. Eliminating prepared child transfer without replacing that synchronous activation cost is not a complete performance design. Do not disguise required handoff as obsolete scaffolding.',completion='Withdraw this form, restore all585production bytes, force actual11/10 builds and focused semantic/ownership/stack checks. Preserve original source/binary/failed compile/all controls. No new switches, dormant modes, internal compatibility stubs or CI qualification of withdrawn code.',future='A genuinely different full calling convention may be assessed with a changed invariant. No permanent design ban or fixed percentage veto. Continue per-record storage work; broader objective stays open.',publicationHeld=True)
(r/'decision.json').write_text(json.dumps(decision,indent=2)+'\n',encoding='utf-8',newline='\n')
original=json.loads((r/'original-identity.json').read_text(encoding='utf-8'))
paths=list(json.loads((r/'original-sources.json').read_text(encoding='utf-8')))
with tarfile.open(prior/'candidate-sources.tar.xz')as archive:
 for p in paths:
  body=archive.extractfile(p).read();assert hashlib.sha256(body).hexdigest()==original['sources'][p];Path(p).write_bytes(body)
assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==h for p,h in original['sources'].items())
(r/'restoration-source-proof.json').write_text(json.dumps(dict(all585ProductionInputsMatchQualified6164Source=True,files=original['sources'],restoredPaths=paths,testsUnchanged=True,independentBuildBinaryIdentityNotInferred=True),indent=2)+'\n',encoding='utf-8',newline='\n')
sdk='C:/Users/JoannesVermorel/.dotnet11';env={k:v for k,v in os.environ.items()if k.casefold()!='path'};env['DOTNET_ROOT']=sdk;env['PATH']=sdk+';C:/Python313;'+next(v for k,v in os.environ.items()if k.casefold()=='path')
fil=json.loads((r/'public-checks.json').read_text(encoding='utf-8'))['filter'];records=[]
for tfm in ['net11.0','net10.0']:
 for stage,command in [
  ('build',[sdk+'/dotnet.exe','build','tests/Lokad.Lython.PublicApi.Tests/Lokad.Lython.PublicApi.Tests.csproj','-c','Release','-f',tfm,'--no-incremental','-m:1','-v','quiet']),
  ('public',[sdk+'/dotnet.exe','test','tests/Lokad.Lython.PublicApi.Tests/Lokad.Lython.PublicApi.Tests.csproj','-c','Release','-f',tfm,'--no-build','--filter',fil,'--logger','trx;LogFileName=r378-restored-'+tfm+'.trx']),
  ('internal',[sdk+'/dotnet.exe','test','tests/Lokad.Lython.Tests/Lokad.Lython.Tests.csproj','-c','Release','-f',tfm,'--filter','(Category!=Stress)&(FullyQualifiedName~ComposedNativeCallTests|FullyQualifiedName~NativeTupleReturnTests|FullyQualifiedName~FunctionWorkspaceOwnershipTests|FullyQualifiedName~ManagedStackGuardTests)'])]:
  start=time.monotonic();log=r/('restored-'+stage+'-'+tfm+'.log');assert not log.exists()
  with log.open('w',encoding='utf-8')as output:done=subprocess.run(command,env=env,stdout=output,stderr=subprocess.STDOUT,timeout=180)
  records.append(dict(framework=tfm,stage=stage,exitCode=done.returncode,elapsedSeconds=time.monotonic()-start));(r/'restored-checks.json').write_text(json.dumps(records,indent=2)+'\n',encoding='utf-8',newline='\n');print(tfm,stage,done.returncode,log.read_text(encoding='utf-8')[-1400:],flush=True)
  assert done.returncode==0
assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==h for p,h in original['sources'].items())
print('All585sourceinputs restored, actual11/10 forced builds/focused checks pass; qualified6164 runtime unchanged.',flush=True)
