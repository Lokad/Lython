from pathlib import Path
import hashlib,json,shutil,tarfile
r=Path(__file__).parent;out=Path('benchmarks/results/2026-11-15-unified-helper-entry-withdrawn');out.mkdir()
original=json.loads((r/'original-identity.json').read_text(encoding='utf-8'));assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==h for p,h in original['sources'].items())
checks=json.loads((r/'restored-checks.json').read_text(encoding='utf-8'));assert len(checks)==6 and all(v['exitCode']==0 for v in checks)
p=r/'decision.json';decision=json.loads(p.read_text(encoding='utf-8'));decision['reason']=decision['reason'].replace('removes241netlines','removes about240netlines');p.write_text(json.dumps(decision,indent=2)+'\n',encoding='utf-8',newline='\n')
for name in ['decision.json','candidate-identity.json','public-checks.json','local-screen.json','restoration-source-proof.json','restored-checks.json']:shutil.copyfile(r/name,out/name)
with tarfile.open(out/'sources-binaries-checks-and-screen.tar.xz','w:xz')as archive:
 for p in sorted(r.iterdir()):
  if p.is_file()and p.name not in {'local-screen.json','candidate-identity.json','restoration-source-proof.json'}:archive.add(p,arcname=p.name)
f=json.loads((r/'candidate-identity.json').read_text(encoding='utf-8'))
with tarfile.open(out/'sources-binaries-checks-and-screen.tar.xz')as archive:assert hashlib.sha256(archive.extractfile('candidate-core.dll').read()).hexdigest()==f['coreSHA256']['candidate']
(out/'README.md').write_text('''# Unified funded helper entry: withdrawn first form

R378, 2026-11-15. Shared slots allow a different proposal from the old arena and
call-controller designs: bind every compiled call directly into its final funded
workspace, using the existing linear runner/native body. No new arena, saved call
records, owner/offset windows, cache or configuration. About240production lines
disappear: fixed16-slot helper ABI, separate binding/eligibility, recursive native
child handoff/abort and the native-call depth threshold. Body-local managed stack
admission and typed native operations/returns remain. Former stack-only calls first
admit workspace; nested callers promote at their exact call into ordinary state.

The first compile fails on a second reference to the removed CallFunction helper;
the original patch/log survive. Corrected source builds and285focused public
Release/net11 cases pass, including defaults/order, closures, protected faults,
tuple returns, actual suspension, cancellation, refused admission and funding.
No white-box architecture tests were edited or relaxed before this initial screen.

## Local complete-script construction screen

Reference ec6c0416/frozen6164a933 has cached full43669461343 qualification;
candidate's exact source/core/frozen auxiliaries are recorded. Existing workers,
catalog and protocol, four fresh processes/job,2.5sfull-request warmups, five
rotating .15s batches. Local Windows development box, ordinary GC/tiering; no
quiet-machine or portable CPU qualification. Clocks include mediated filesystem
I/O, full output/file checks and prior-result cleanup, excluding compilation,
startup/reset/protocol/final cache teardown. All four median pairings are retained.

| Complete warm script | Candidate elapsed change | Interpretation |
| --- | ---: | --- |
| Protected file search |−6.9..+9.2%|Moving controls/inconclusive|
| Invoice with composed helpers |+11.7..+20.2%|Adverse across both controls|
| Fulfillment helper |−5.7..−1.1%|Favorable local diagnostic|
| Short/zero helpers |+17.7..+19.0%|Adverse across both controls|

These data do not isolate an instruction's cost or establish a VM speedup/lower
bound. Source also exposes real new nested-caller state. Removing the child handoff
without replacing synchronous activation costs is not a complete performance
design. Withdraw this form before a new quiet-VM/full-qualification campaign;
retain every adverse/favorable condition. No permanent arena/calling-convention
ban or fixed-percentage veto follows. A changed whole-stage design can be assessed.

All585production source inputs restore byte-for-byte to qualified6164 source.
Forced actual11/10 Release builds and285public/26internal focused checks each pass,
including restored native composition, stack, ownership and refusal. Tests remain
unchanged; no new stub, switch or dormant route. Independent rebuilt binary identity
is not inferred. Full43669461343 qualification stays cached, not repeated.

All local workers join and fixtures close. No VM work, remote retirement, package
qualification or publication for this prototype. The broader objective continues
with per-record construction; this experiment's withdrawal does not complete it.
''',encoding='utf-8',newline='\n')
p=Path('benchmarks/EXPERIMENTS.md');s=p.read_text(encoding='utf-8');s+='''

R378 [unified funded helper entry](results/2026-11-15-unified-helper-entry-withdrawn/README.md)
withdraws its first form: about240lines removed without a new arena/controller,
but synchronous nested callers promote earlier.285public/net11 semantics pass;
local full-script screen invoice+11.7..+20.2%, short+17.7..+19.0%, fulfillment
−5.7..−1.1%, file control inconclusive. No quiet/portable CPU claim, fixed veto or
permanent ban. Preserve initial compile failure, all source/binary/control data.
All585productionbytesrestore; forced actual11/10 builds plus285public/26internal
each pass; tests unchanged. No VM/new full qualification, policy, dormant stub or
publication. Qualified6164/43669461343cached; broader per-record roadmap continues.
''';p.write_text(s,encoding='utf-8',newline='\n')
p=Path('PLAN.md');s=p.read_text(encoding='utf-8');a=s.index('| Active uncommitted prototype |');b=s.index('\n',a);s=s[:a]+'| R378 withdrawn and restored | [Unified funded entry](benchmarks/results/2026-11-15-unified-helper-entry-withdrawn/README.md) removes about240lines but adds nested caller state; local invoice +11.7–20.2%, short +17.7–19.0%, fulfillment favorable/file inconclusive. No portable CPU claim. All585productionbytes restored; forced actual11/10 builds and285public/26internal each pass. No test changes or VM campaign. |'+s[b:]
a=s.index('2. **R378 active prototype:');b=s.index('   **Broader call/frame source evidence:**',a)
s=s[:a]+'''2. **R378 closes by withdrawal; preserve the changed-design lesson.**
   Final funded slots remove the fixed helper ABI but do not themselves remove
   synchronous nested caller state. The local source pair and exact restoration
   above are complete; do not repeat unchanged timing or full qualification.
   A future replacement must remove the entire activation cost rather than
   merely transfer it to the ordinary runner. No permanent design ban.

'''+s[b:];p.write_text(s,encoding='utf-8',newline='\n')
print('R378 withdrawal/evidence/restoration saved; qualified runtime unchanged, wider goal active.')
