from pathlib import Path
import fcntl,hashlib,json,os,shutil,stat,subprocess
base=Path('/home/lokad/lython-bench-checks').resolve();specs=[{'path': 'tuple-return-b666-20261113/candidate/Lokad.Lython.dll', 'canonical': {'canonical': 'benchmarks/results/2026-11-13-native-tuple-return/initial/source-checks.tar.xz', 'member': 'candidate-core.dll', 'bytes': 5679104, 'sha256': '23eb67dac52b57a8f8fca9af05d598077dad9e9b217dbe19097d15fa6d567612'}, 'sha256': '23eb67dac52b57a8f8fca9af05d598077dad9e9b217dbe19097d15fa6d567612'}]
with(base/'comparison-vm.lock').open('a')as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record|[p]ython3.*cpython-worker.py'],capture_output=True).returncode==1
 rows=[]
 for item in specs:
  path=base/item['path'];info=path.lstat();assert path.resolve(strict=True)==path and path.is_relative_to(base)and stat.S_ISREG(info.st_mode)and info.st_uid==os.getuid()
  assert hashlib.sha256(path.read_bytes()).hexdigest()==item['sha256']
  aliases=[]
  for folder,dirs,files in os.walk(base,followlinks=False):
   for name in files:
    other=Path(folder)/name;s=other.lstat()
    if(s.st_dev,s.st_ino)==(info.st_dev,info.st_ino):aliases.append(str(other.relative_to(base)))
  assert len(aliases)==info.st_nlink==2,(path,aliases,info.st_nlink)
  rows.append(dict(**item,device=info.st_dev,inode=info.st_ino,links=info.st_nlink,bytes=info.st_size,allocatedBytes=info.st_blocks*512,allAliasesInBase=True,aliases=aliases))
 print(json.dumps(dict(freshIdleLease=True,readOnly=True,freeBytes=shutil.disk_usage(base).free,groups=rows)))
