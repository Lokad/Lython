from pathlib import Path
import fcntl,hashlib,json,os,shutil,stat,subprocess
base=Path('/home/lokad/lython-bench-checks').resolve();specs=[{'path': 'csv-shared-b663-20261113/observations.tgz', 'sha256': '3509a7827ee56ecc598b967f1896c4a6a72ca4e7c675da2e629793f730a124e5', 'canonical': {'canonical': 'benchmarks/results/2026-11-13-csv-shared-fields/initial/observations.tgz', 'sha256': '3509a7827ee56ecc598b967f1896c4a6a72ca4e7c675da2e629793f730a124e5', 'bytes': 153279}}, {'path': 'csv-shared-refined-b664-20261113/observations.tgz', 'sha256': '3c9b445116ee6b51cd41d29d4b49e4c96aff8f79a06b674481cb93ead408e80d', 'canonical': {'canonical': 'benchmarks/results/2026-11-13-csv-shared-fields/refined/observations.tgz', 'sha256': '3c9b445116ee6b51cd41d29d4b49e4c96aff8f79a06b674481cb93ead408e80d', 'bytes': 153254}}, {'path': 'tuple-return-b666-20261113/observations.tgz', 'sha256': 'aedfc66825cb8fec4e181da8615ccaa0dd4b1bbdd8df64f6d1fccb12b81120ac', 'canonical': {'canonical': 'benchmarks/results/2026-11-13-native-tuple-return/initial/observations.tgz', 'sha256': 'aedfc66825cb8fec4e181da8615ccaa0dd4b1bbdd8df64f6d1fccb12b81120ac', 'bytes': 123802}}, {'path': 'integer-b661-20261113/observations.tgz', 'sha256': '8645760ad23538eb4b539da4f13fe319dc2b05f5cfa76902be1bcbde957a0654', 'canonical': {'canonical': 'benchmarks/results/2026-11-13-integer-admission/observations.tgz', 'sha256': '8645760ad23538eb4b539da4f13fe319dc2b05f5cfa76902be1bcbde957a0654', 'bytes': 93005}}, {'path': 'invoice-external-b660-20261113/observations.tgz', 'sha256': '784bb7d773d8faacce41cf3303844ae4ee7ef709ce75b7650dafff73fae07eb5', 'canonical': {'canonical': 'benchmarks/results/2026-11-13-invoice-cpython-checkpoint/observations.tgz', 'sha256': '784bb7d773d8faacce41cf3303844ae4ee7ef709ce75b7650dafff73fae07eb5', 'bytes': 103563}}]
with(base/'comparison-vm.lock').open('a')as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record|[p]ython3.*cpython-worker.py'],capture_output=True).returncode==1
 rows=[]
 for item in specs:
  path=base/item['path'];info=path.lstat();assert path.resolve(strict=True)==path and path.is_relative_to(base)and stat.S_ISREG(info.st_mode)and info.st_uid==os.getuid()
  assert hashlib.sha256(path.read_bytes()).hexdigest()==item['sha256']
  aliases=[]
  for folder,dirs,files in os.walk(base,followlinks=False):
   for name in files:
    other=Path(folder)/name;s=other.lstat()
    if(s.st_dev,s.st_ino)==(info.st_dev,info.st_ino):aliases.append(str(other.relative_to(base)))
  assert len(aliases)==info.st_nlink==1,(path,aliases,info.st_nlink)
  rows.append(dict(**item,device=info.st_dev,inode=info.st_ino,links=info.st_nlink,bytes=info.st_size,allocatedBytes=info.st_blocks*512,allAliasesInBase=True,aliases=aliases))
 print(json.dumps(dict(freshIdleLease=True,readOnly=True,freeBytes=shutil.disk_usage(base).free,groups=rows)))
