from pathlib import Path
import datetime,json,os,subprocess,sys
r=Path(__file__).parent;notes=r.parent.parent.parent;out=r/'warm-sync';out.mkdir()
witness=out/'witness.json';witness.write_bytes((notes/'bulk-utf16-r276/refined/warm-sync/hash-witness.json').read_bytes())
sdk=Path('C:/Users/JoannesVermorel/.dotnet11');env=os.environ.copy();env['DOTNET_ROOT']=str(sdk);env['PATH']=str(sdk)+';C:/Python313;'+env['PATH']
args=[str(sdk/'dotnet.exe'),str(notes/'composed-native-r303/tool/bin/Release/net11.0/complete-jobs.dll'),str(r/'reference/Lokad.Lython.Benchmarks.dll'),str(r/'candidate/Lokad.Lython.Benchmarks.dll'),str(r/'catalog.json'),str(witness),'forward','warm']
with(out/'stdout.json').open('w',encoding='utf-8')as stdout,(out/'stderr.log').open('w',encoding='utf-8')as stderr:
    p=subprocess.Popen(args,env=env,stdout=stdout,stderr=stderr)
    (out/'process.json').write_text(json.dumps(dict(pid=p.pid,args=args,startedUTC=datetime.datetime.now(datetime.timezone.utc).isoformat()),indent=2)+'\n',encoding='utf-8')
    print('Existing eight-script desktop allocation diagnostic PID',p.pid,'bounded; clocks diagnostic only.',flush=True)
    try:p.wait(timeout=60)
    except subprocess.TimeoutExpired:
        with(out/'incomplete-managed-stacks.log').open('w',encoding='utf-8')as f:
            try:subprocess.run(['C:/Users/JoannesVermorel/.dotnet/tools/dotnet-stack.exe','report','--process-id',str(p.pid)],env=env,stdout=f,stderr=subprocess.STDOUT,timeout=15)
            except subprocess.TimeoutExpired:f.write('Managed diagnostic itself timed out.\n')
        try:p.wait(timeout=30)
        except subprocess.TimeoutExpired:
            subprocess.run(['taskkill','/PID',str(p.pid),'/T','/F'],check=True,capture_output=True);p.wait(timeout=10)
if p.returncode:
    (out/'incomplete.json').write_text(json.dumps(dict(complete=False,exitCode=p.returncode,ownedUsersJoined=True,originalOutputPreserved=True),indent=2)+'\n',encoding='utf-8')
    raise SystemExit('Incomplete diagnostic preserved; no allocation/timing result inferred.')
d=json.loads((out/'stdout.json').read_text(encoding='utf-8'));assert d['allGoldensPassed']and d['allBalancesZero']and d['ownedFixturesRemoved']
print('Eight scripts full goldens/balances/cleanup pass; allocation available, clocks diagnostic.',flush=True)
