from pathlib import Path
import ast,base64,datetime,json,subprocess
r=Path(__file__).parent;config=json.loads((r/'config.json').read_text(encoding='utf-8'))
code='''from pathlib import Path
import ast,fcntl,hashlib,io,json,os,shutil,subprocess,sys,tarfile
config=CONFIG
base=Path('/home/lokad/lython-bench-checks').resolve();root=Path(config['root']);source=Path(config['sourceRoot'])
assert root.parent==base and source.parent==base and not root.exists()
digest=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
with(base/'comparison-vm.lock').open('a')as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert not(source/'guest-fixtures').exists()
 users=subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record|[p]ython3.*cpython-worker.py'],capture_output=True)
 assert users.returncode==1,users.stdout
 for role in ['reference','candidate']:assert digest(source/role/'Lokad.Lython.dll')==config['identity']['coreSHA256'][role]
 assert digest(source/'source-identity.json')==config['identity']['sourceIdentitySHA256']
 before=shutil.disk_usage(base).free
 assert before>252*1024*1024+config['unpackedBytes']+2*1024*1024
 payload=sys.stdin.buffer.read(config['payloadBytes']+1)
 assert len(payload)==config['payloadBytes']and hashlib.sha256(payload).hexdigest()==config['payloadSHA256']
 root.mkdir()
 with tarfile.open(fileobj=io.BytesIO(payload),mode='r:gz')as archive:archive.extractall(root,filter='data')
 assert digest(root/'catalog.json')==config['identity']['catalogSHA256']
 assert digest(root/'complete-jobs.dll')==config['identity']['driverSHA256']
 for name in ['collect.py']:ast.parse((root/name).read_text())
 subprocess.run(['/bin/sh','-n',str(root/'run.sh')],check=True)
 (root/'space-preflight.json').write_text(json.dumps(dict(freshIdleLease=True,beforeFreeBytes=before,afterStagingFreeBytes=shutil.disk_usage(base).free,osFloorMiB=240,evidenceHeadroomMiB=12,additionalArchiveHeadroomMiB=2,retired=[]),indent=2)+'\\n')
 assert shutil.disk_usage(base).free>252*1024*1024+2*1024*1024
 fixture=root/'guest-fixtures';fixture.mkdir()
 subprocess.run(['sudo','-n','mount','-t','tmpfs','-o','size=128m,mode=0700,uid=lokad,gid=lokad','lython-b670-fixtures',str(fixture)],check=True)
try:subprocess.run(['sudo','-n','systemd-run','--unit='+config['unit'],'--property=User=lokad','--property=WorkingDirectory='+str(root),'--property=RuntimeMaxSec=150','--property=TimeoutStopSec=30','--property=KillMode=control-group','/bin/sh',str(root/'run.sh')],check=True)
except BaseException:subprocess.run(['sudo','-n','umount',str(fixture)],check=True);fixture.rmdir();raise
live=subprocess.check_output(['systemctl','show',config['unit']+'.service','--property=ActiveState,MainPID,RuntimeMaxUSec'],text=True)
assert'ActiveState=active'in live and'MainPID=0'not in live;print(live)
'''.replace('CONFIG',repr(config))
ast.parse(code);(r/'launch-command.py').write_text(code,encoding='utf-8',newline='\n')
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
encoded=base64.b64encode(code.encode()).decode();command="python3 -c 'import base64;exec(base64.b64decode(\""+encoded+"\"))'"
done=subprocess.run(ssh+[command],input=(r/'payload.tgz').read_bytes(),capture_output=True)
(r/'launch.log').write_bytes(done.stdout+done.stderr);print((done.stdout+done.stderr).decode(),flush=True);assert done.returncode==0
now=datetime.datetime.now(datetime.timezone.utc)
(r/'observe-not-before.json').write_text(json.dumps(dict(startedUTC=now.isoformat(),doNotObserveBeforeUTC=(now+datetime.timedelta(seconds=120)).isoformat(),ownerSeconds=150,stopSeconds=30,observationSeconds=120),indent=2)+'\n',encoding='utf-8',newline='\n')
