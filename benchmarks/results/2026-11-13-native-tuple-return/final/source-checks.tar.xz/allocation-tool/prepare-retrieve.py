from pathlib import Path
r=Path(__file__).parent
code=(r.parent.parent.parent/'arithmetic-source-r305/b662/retrieve.py').read_text(encoding='utf-8').replace('captured-cpu-b662-20261113','tuple-allocation-b670-20261113').replace('lython-b662-captured-cpu-20261113','lython-b670-tuple-allocation-20261113').replace('B662','B670')
code=code.replace("[d]otnet.* --compare worker|[p]erf record|[p]ython3.*cpython-worker.py","[d]otnet.*complete-jobs.dll|[d]otnet.* --compare worker|[p]erf record|[p]ython3.*cpython-worker.py")
(r/'retrieve.py').write_text(code,encoding='utf-8')
code=(r.parent/'summarize-diagnostic.py').read_text(encoding='utf-8').replace("out=r/'warm-sync'","out=r/'retrieved'")
(r/'summarize.py').write_text(code,encoding='utf-8')
