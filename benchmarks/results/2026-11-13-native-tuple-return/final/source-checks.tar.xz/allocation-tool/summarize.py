from pathlib import Path
import json,statistics
r=Path(__file__).parent;out=r/'retrieved';d=json.loads((out/'stdout.json').read_text(encoding='utf-8'))
rows=[]
for case in d['observations']:
    values={k:[s for s in case['samples']if s['image']==k]for k in ['before','candidate','before-control']}
    allocation={k:statistics.median(s['allocatedBytes']/s['jobs']for s in samples)for k,samples in values.items()}
    timing={k:statistics.median(s['executionMilliseconds']/s['jobs']for s in samples)for k,samples in values.items()}
    change=lambda v:[100*(v['candidate']/v[k]-1)for k in ['before','before-control']]
    row=dict(case=case['caseId'],allocationBytes=allocation,allocationChangePercent=change(allocation),executionMilliseconds=timing,diagnosticChangePercent=change(timing))
    rows.append(row);print(case['caseId'],'allocation',[round(x,3)for x in row['allocationChangePercent']],'desktop diagnostic elapsed',[round(x,2)for x in row['diagnosticChangePercent']],flush=True)
(out/'summary.json').write_text(json.dumps(dict(complete=True,performanceQualified=False,allGoldensPassed=d['allGoldensPassed'],allBalancesZero=d['allBalancesZero'],ownedFixturesRemoved=d['ownedFixturesRemoved'],rows=rows),indent=2)+'\n',encoding='utf-8')
