from pathlib import Path
import ast,hashlib,json,tarfile
r=Path(__file__).parent;old=r.parent/'final/b669'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
root='/home/lokad/lython-bench-checks/tuple-allocation-b670-20261113'
(r/'run.sh').write_text('set -eu\nroot='+root+'\ntrap \'result=$?; printf "%s\\n" "$result" > "$root/exit-code.txt"\' EXIT\npython3 "$root/collect.py"\n',encoding='utf-8',newline='\n')
files={n:r/n for n in ['collect.py','run.sh','identity.json','catalog.json','witness.json']}
for suffix in ['dll','deps.json','runtimeconfig.json']:files['complete-jobs.'+suffix]=r/'tool/bin/Release/net11.0'/('complete-jobs.'+suffix)
with tarfile.open(r/'payload.tgz','w:gz')as a:
    for name,p in files.items():a.add(p,arcname=name)
config=dict(root=root,unit='lython-b670-tuple-allocation-20261113',sourceRoot='/home/lokad/lython-bench-checks/tuple-return-final-b669-20261113',identity=json.loads((r/'identity.json').read_text(encoding='utf-8')),payloadBytes=(r/'payload.tgz').stat().st_size,payloadSHA256=sha(r/'payload.tgz'),unpackedBytes=sum(p.stat().st_size for p in files.values()))
(r/'config.json').write_text(json.dumps(config,indent=2)+'\n',encoding='utf-8')
code=(r.parent.parent.parent/'arithmetic-source-r305/b662/launch.py').read_text(encoding='utf-8')
a=code.index(" assert digest(source/'candidate/Lokad.Lython.dll')");b=code.index(' before=shutil',a)
code=code[:a]+" for role in ['reference','candidate']:assert digest(source/role/'Lokad.Lython.dll')==config['identity']['coreSHA256'][role]\n assert digest(source/'source-identity.json')==config['identity']['sourceIdentitySHA256']\n"+code[b:]
a=code.index(" shutil.copytree(source/'candidate'");b=code.index(" for name in ['collect.py'",a)
code=code[:a]+" assert digest(root/'catalog.json')==config['identity']['catalogSHA256']\n assert digest(root/'complete-jobs.dll')==config['identity']['driverSHA256']\n"+code[b:]
code=code.replace("['collect.py','ops-profile.py']","['collect.py']").replace('b662','b670').replace('RuntimeMaxSec=120','RuntimeMaxSec=150')
code=code.replace('datetime.timedelta(seconds=60)','datetime.timedelta(seconds=120)').replace('ownerSeconds=120','ownerSeconds=150').replace('observationSeconds=60','observationSeconds=120')
ast.parse(code);(r/'launch.py').write_text(code,encoding='utf-8')
print('B670 targeted allocation only: two original fixtures, fixed ALC driver except count guard; staged',config['unpackedBytes'],'bytes.',flush=True)
