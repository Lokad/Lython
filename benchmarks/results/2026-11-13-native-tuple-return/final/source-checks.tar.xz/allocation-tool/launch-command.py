from pathlib import Path
import ast,fcntl,hashlib,io,json,os,shutil,subprocess,sys,tarfile
config={'root': '/home/lokad/lython-bench-checks/tuple-allocation-b670-20261113', 'unit': 'lython-b670-tuple-allocation-20261113', 'sourceRoot': '/home/lokad/lython-bench-checks/tuple-return-final-b669-20261113', 'identity': {'purpose': 'Targeted final8f allocation qualification on quiet VM after incomplete Windows8-case diagnostic; existing ALC driver changes only fixture-count guard/description, no runtime/host/clock change', 'coreSHA256': {'reference': '93a6d13483515e82313ef9136ab3b96d5b432218d7b3461f95d79dbf12df417e', 'candidate': '8f69261d79a3e32a563bb374d1ad9bc49b980b1b9884fbf697fea02996068aa2'}, 'catalogSHA256': '8540e010f8421b83ec41be0f1a69116340be12e20709e9d14bfb1a3ef6d3e327', 'sourceIdentitySHA256': '9763f7d40f9aac224ee1e8179e6107ce556be675eb6637f366378c4ec146663e', 'driverSourceSHA256': 'a362f1ec590dfc128903d8152eccd4648bf83be7feb07214cc75e487f61e46da', 'driverSHA256': '794b87445e08139a12ff648ffd0463eb0aec361afad659a2a389f49d8f3b3052'}, 'payloadBytes': 70373, 'payloadSHA256': '4bcea6e3e034c8884b4f2442ee9d3c73b09f303e204b09a7f1e3af5dbd70962f', 'unpackedBytes': 1320934}
base=Path('/home/lokad/lython-bench-checks').resolve();root=Path(config['root']);source=Path(config['sourceRoot'])
assert root.parent==base and source.parent==base and not root.exists()
digest=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
with(base/'comparison-vm.lock').open('a')as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert not(source/'guest-fixtures').exists()
 users=subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record|[p]ython3.*cpython-worker.py'],capture_output=True)
 assert users.returncode==1,users.stdout
 for role in ['reference','candidate']:assert digest(source/role/'Lokad.Lython.dll')==config['identity']['coreSHA256'][role]
 assert digest(source/'source-identity.json')==config['identity']['sourceIdentitySHA256']
 before=shutil.disk_usage(base).free
 assert before>252*1024*1024+config['unpackedBytes']+2*1024*1024
 payload=sys.stdin.buffer.read(config['payloadBytes']+1)
 assert len(payload)==config['payloadBytes']and hashlib.sha256(payload).hexdigest()==config['payloadSHA256']
 root.mkdir()
 with tarfile.open(fileobj=io.BytesIO(payload),mode='r:gz')as archive:archive.extractall(root,filter='data')
 assert digest(root/'catalog.json')==config['identity']['catalogSHA256']
 assert digest(root/'complete-jobs.dll')==config['identity']['driverSHA256']
 for name in ['collect.py']:ast.parse((root/name).read_text())
 subprocess.run(['/bin/sh','-n',str(root/'run.sh')],check=True)
 (root/'space-preflight.json').write_text(json.dumps(dict(freshIdleLease=True,beforeFreeBytes=before,afterStagingFreeBytes=shutil.disk_usage(base).free,osFloorMiB=240,evidenceHeadroomMiB=12,additionalArchiveHeadroomMiB=2,retired=[]),indent=2)+'\n')
 assert shutil.disk_usage(base).free>252*1024*1024+2*1024*1024
 fixture=root/'guest-fixtures';fixture.mkdir()
 subprocess.run(['sudo','-n','mount','-t','tmpfs','-o','size=128m,mode=0700,uid=lokad,gid=lokad','lython-b670-fixtures',str(fixture)],check=True)
try:subprocess.run(['sudo','-n','systemd-run','--unit='+config['unit'],'--property=User=lokad','--property=WorkingDirectory='+str(root),'--property=RuntimeMaxSec=150','--property=TimeoutStopSec=30','--property=KillMode=control-group','/bin/sh',str(root/'run.sh')],check=True)
except BaseException:subprocess.run(['sudo','-n','umount',str(fixture)],check=True);fixture.rmdir();raise
live=subprocess.check_output(['systemctl','show',config['unit']+'.service','--property=ActiveState,MainPID,RuntimeMaxUSec'],text=True)
assert'ActiveState=active'in live and'MainPID=0'not in live;print(live)
