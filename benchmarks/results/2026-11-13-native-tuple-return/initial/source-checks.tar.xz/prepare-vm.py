from pathlib import Path
import ast,hashlib,json,tarfile
r=Path(__file__).parent;notes=r.parent.parent;old=notes/'csv-shared-fields-r308/b664';out=r/'b666';out.mkdir()
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
source=json.loads((r/'candidate-identity.json').read_text(encoding='utf-8'));assert all(sha(p)==h for p,h in source['sources'].items())
root='/home/lokad/lython-bench-checks/tuple-return-b666-20261113';oldroot='/home/lokad/lython-bench-checks/csv-shared-refined-b664-20261113'
catalog=notes/'arithmetic-source-r305/b661/retrieved/representative.json'
cases={c['id']for c in json.loads(catalog.read_text(encoding='utf-8'))['cases']}
jobs=[['scripts.csv-invoice.large','warm'],['scripts.csv-invoice.large','compile-run'],['scripts.text-summary-helpers.nonlocal-counter.large','warm'],['scripts.report-render.large','warm']]
assert all(c in cases for c,l in jobs),cases
previous=json.loads((old/'identity.json').read_text(encoding='utf-8'))
identity={k:previous[k]for k in ['auxiliaryFiles','referenceSourceIdentitySHA256']}
identity.update(sourceRevision='Fully qualified14dd45b7/93a6d134 versus uncommitted23eb67da direct native tuple-result transport',purpose='Complete invoice warm/fresh and captured-text/report controls; no external ratio',coreSHA256={k:source['referenceSHA256']if k.startswith('reference')else source['coreSHA256']for k in ['reference','candidate','reference-control','candidate-control']},catalogSHA256=sha(catalog),sourceIdentitySHA256=sha(r/'candidate-identity.json'),productionSourceArchiveSHA256=sha(r/'candidate-sources.tar.xz'))
(out/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8')
for name in ['collect.py','archive-owned.py','run.sh','retrieve.py','summarize.py']:
    code=(old/name).read_text(encoding='utf-8').replace(oldroot,root).replace('lython-b664-csv-shared-refined-20261113','lython-b666-tuple-return-20261113').replace('B664','B666')
    if name=='collect.py':
        a=code.index('jobs=');b=code.index('\nenv =',a);code=code[:a]+'jobs='+repr(jobs)+'\nassert len(jobs)==4 and all(case in cases for case,lane in jobs)\n'+code[b:]
    if name.endswith('.py'):ast.parse(code)
    (out/name).write_text(code,encoding='utf-8',newline='\n')
files={n:out/n for n in ['identity.json','collect.py','archive-owned.py','run.sh']};files.update({'current-core.dll':r/'candidate-core.dll','source-identity.json':r/'candidate-identity.json'})
with tarfile.open(out/'payload.tgz','w:gz')as archive:
    for name,p in files.items():archive.add(p,arcname=name)
config=dict(root=root,unit='lython-b666-tuple-return-20261113',sourceRoot='/home/lokad/lython-bench-checks/csv-shared-b663-20261113',catalogRoot='/home/lokad/lython-bench-checks/integer-b661-20261113',sourceCoreSHA256=source['referenceSHA256'],identity=identity,retire=json.loads((r/'retirement-inspection.json').read_text(encoding='utf-8'))['groups'],payloadBytes=(out/'payload.tgz').stat().st_size,payloadSHA256=sha(out/'payload.tgz'),unpackedBytes=sum(p.stat().st_size for p in files.values()))
(out/'config.json').write_text(json.dumps(config,indent=2)+'\n',encoding='utf-8')
code=(old/'launch.py').read_text(encoding='utf-8').replace('b664','b666')
code=code.replace(" for name in ['representative.json','reference-source-identity.json','cpython-worker.py']:os.link(source/name,root/name)"," for name in ['reference-source-identity.json','cpython-worker.py']:os.link(source/name,root/name)\n catalogSource=Path(config['catalogRoot']);assert catalogSource.parent==base\n os.link(catalogSource/'representative.json',root/'representative.json')")
ast.parse(code);(out/'launch.py').write_text(code,encoding='utf-8')
print('B666 four complete-script jobs; exact reference reused, only archived superseded277 retired; staged',config['unpackedBytes'],'bytes',flush=True)
