from pathlib import Path
import subprocess
r=Path(__file__).parent
code=(r/'check.py').read_text(encoding='utf-8').replace('focused-','refined-readonly-corrected-')
(r/'refined-readonly-corrected-check.py').write_text(code,encoding='utf-8')
subprocess.run(['python','-X','utf8',str(r/'refined-readonly-corrected-check.py')],check=True)
