using Lokad.Lython.Frontend;
using System.Text.Json;
var parsed=LythonFrontend.Compile(File.ReadAllText(args[0]));
var code=ExecutableScript.Compile(LoweredScript.Lower(parsed.Script!)).EntryPoint;
Console.WriteLine(JsonSerializer.Serialize(Inspect(code),new JsonSerializerOptions{WriteIndented=true}));
static object Inspect(ExecutableCodeObject code)=>new{
    code.Name,code.ValueStorageCapacity,code.CanInlineInstructions,code.LastOwnedTemporarySlot,
    calls=code.Instructions.Select((instruction,index)=>(instruction,index)).Where(x=>x.instruction.OpCode==ExecutableOpCode.Call)
        .Select(x=>new{x.index,x.instruction.InputStart,x.instruction.HasLocalResult,site=new{code.CallSites[x.instruction.CallSiteIndex].ArgumentCount,code.CallSites[x.instruction.CallSiteIndex].UnpackedReturnCount},next=code.Instructions[x.index+1].OpCode.ToString()}).ToArray(),
    tuples=code.Instructions.Select((instruction,index)=>(instruction,index)).Where(x=>x.instruction.OpCode==ExecutableOpCode.MakeTuple)
        .Select(x=>new{x.index,x.instruction.InputStart,x.instruction.ResultSlot,x.instruction.HasLocalResult,x.instruction.ItemCount,next=code.Instructions[x.index+1].OpCode.ToString(),nextInput=code.Instructions[x.index+1].InputStart}).ToArray(),
    children=code.Functions.Select(x=>Inspect(x.CodeObject)).ToArray()};
