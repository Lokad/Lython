from pathlib import Path
import json,os,subprocess
r=Path(__file__).parent;sdk=Path('C:/Users/JoannesVermorel/.dotnet11');env=os.environ.copy();env['DOTNET_ROOT']=str(sdk)
with(r/'inspect-corrected-build.log').open('w',encoding='utf-8')as log:subprocess.run([str(sdk/'dotnet.exe'),'build',str(r/'inspect/inspect.csproj'),'-c','Release','--disable-build-servers'],env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
done=subprocess.run([str(sdk/'dotnet.exe'),str(r/'inspect/bin/Release/net11.0/Lokad.Lython.WhiteBox.Tests.dll'),'benchmarks/scripts/csv-invoice.py'],env=env,capture_output=True,text=True,encoding='utf-8');assert done.returncode==0,done.stderr
(r/'compiled-facts.json').write_text(done.stdout,encoding='utf-8')
d=json.loads(done.stdout);print('Module owned limit',d['lastOwnedTemporarySlot']if 'lastOwnedTemporarySlot'in d else d['LastOwnedTemporarySlot'])
for c in d['calls']:
    if c['site']['UnpackedReturnCount']:print('Unpack site',c)
for f in d['children']:
    print('Function',f['Name'],'inline',f['CanInlineInstructions'],'tuples',f['tuples'])
