from pathlib import Path
r=Path(__file__).parent
for p in sorted(r.glob('constructor-corrected-*.log')):
    print(p.name,p.stat().st_size,p.read_text(encoding='utf-8',errors='replace')[-650:])
