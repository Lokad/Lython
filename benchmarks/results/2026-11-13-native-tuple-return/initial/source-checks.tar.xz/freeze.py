from pathlib import Path
import hashlib,json,os,shutil,subprocess,tarfile
r=Path(__file__).parent;notes=r.parent.parent
for kind,count in [('internal',110),('public',180)]:
    text=(r/('constructor-corrected-'+kind+'-test.log')).read_text(encoding='utf-8');assert 'Test Run Successful.'in text and f'Total tests: {count}'in text
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
baseline=json.loads((notes/'immutable-repeat-r307/index-corrected/candidate-identity.json').read_text(encoding='utf-8'))
sources={p:sha(p)for p in baseline['sources']}
changed=[]
for p in sources:
    if Path(p).read_bytes().replace(b'\r\n',b'\n')!=subprocess.check_output(['git','show','14dd45b7:'+p]).replace(b'\r\n',b'\n'):changed.append(p)
assert len(changed)==6,changed
for role in ['reference','candidate']:
    shutil.copytree(notes/'csv-shared-fields-r308/reference',r/role,copy_function=os.link)
    if role=='candidate':
        (r/role/'Lokad.Lython.dll').unlink();shutil.copyfile('src/Lokad.Lython/bin/Release/net11.0/Lokad.Lython.dll',r/role/'Lokad.Lython.dll')
shutil.copyfile(r/'candidate/Lokad.Lython.dll',r/'candidate-core.dll')
identity=dict(head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),description='R310 immediate exact tuple-return unpack borrows bounded caller scratch; conservative eager admission preserved; no escaping span',coreSHA256=sha(r/'candidate-core.dll'),referenceSHA256=baseline['coreSHA256'],sources=sources,changed=changed)
(r/'candidate-identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8')
with tarfile.open(r/'candidate-sources.tar.xz','w:xz')as archive:
    for p in sources:archive.add(p,arcname=p)
shutil.copyfile(notes/'csv-shared-fields-r308/catalog.json',r/'catalog.json')
code=(notes/'csv-shared-fields-r308/inspect-vm.py').read_text(encoding='utf-8')
start=code.index('specs=');end=code.index('\nproofs=',start)
code=code[:start]+"specs=[('csv-shared-refined-b664-20261113/candidate/Lokad.Lython.dll','benchmarks/results/2026-11-13-csv-shared-fields/refined/source-checks.tar.xz',r.parent.parent/'csv-shared-fields-r308/refined/candidate-core.dll')]"+code[end:]
(r/'inspect-vm.py').write_text(code,encoding='utf-8')
print(identity['coreSHA256'],len(sources),'production inputs,',len(changed),'changed;110internal/180public pass.',flush=True)
