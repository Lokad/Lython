from pathlib import Path
import subprocess
r=Path(__file__).parent
code=(r/'check.py').read_text(encoding='utf-8').replace('focused-','constructor-corrected-')
(r/'constructor-corrected-check.py').write_text(code,encoding='utf-8')
subprocess.run(['python','-X','utf8',str(r/'constructor-corrected-check.py')],check=True)
