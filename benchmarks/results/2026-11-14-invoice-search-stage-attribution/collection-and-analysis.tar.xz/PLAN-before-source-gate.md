# Lokad.Lython 0.11.0

Updated 2026-11-14. Git-ignored; never force-add. Publication/tagging postponed.
Objective: coherent simplification and substantial complete-script performance,
including freshly generated scripts. A delivered experiment is a checkpoint, not
completion. History and adverse evidence live in [EXPERIMENTS](benchmarks/EXPERIMENTS.md),
immutable results and saved plans, outside current-version docs.

## Delivery status

| State | Actual status and limits |
| --- | --- |
| Committed and fully qualified runtime | R346 `009d236a`, frozen `8ae1ae5f`, 581 production inputs. GREEN43563853239: Windows/Ubuntu actual .NET11/10, original stress, installed Release consumers; 16 summaries cached. Exact-sequence cursors share indexed advancement and remove CLR enumerators. List allocation−1.53%, elapsed−3.30..−5.20%, wider CPU−2.63..−4.58%. Text+0.69%allocation/small CPU adversity remains accepted debt. [Delivery](benchmarks/results/2026-11-14-indexed-sequence-cursors/delivery/README.md). |
| Committed, focused-qualified only | `fc11817c` preserves R348 evidence and the independent reentrant-retirement fixture; production is byte-identical to qualified009d. The test change passes frozen8ae and restored nonincremental actual11/10; include it in the next full batch. |
| Committed runtime, delivery pending | R349 `e235b18b` captured-cell scalar storage/publication, frozen `71ba421c`: 8 changed inputs, old dictionary-only preparation file retired, inventory still581. 1,826 focused actual11/10 cases pass, including independent Python values/identity, actual I/O, cancellation, first refusal and retained results. Allocation−18.00% on complete captured text, direct-text/CSV controls flat. B720 completes225.65s with all gates; captured warm−5.20..−7.60%/CPU−4.81..−6.89%, but faster variable direct controls make attribution uncertain. Frequent-read allocation+8B. CI43571864663 full delivery pending; observe at least four minutes apart. |
| Current CPython comparison | R347/B717, 2026-11-14, runtime009d/frozen8ae versus stockCPython3.13.16: invoice warm1.26–1.31×, compile1.08–1.10×, compile-to-result1.21–1.24×; captured text1.48–1.59×, search1.66–1.76×, JSON0.83×, report1.19–1.21×, fulfillment1.30–1.31×, for-loopCSV1.28–1.29×. Invoice/search/text process spreads3.47/4.05/6.57% remain uncertainty. All image/golden/balance/quiet/join/archive gates pass; runtime fully qualified. Config retains its separately qualifiedcdd/f4 source. [Boundaries and results](docs/BENCHMARKS.md). |
| Withdrawn / unresolved | Both R348 inventory-removal forms withdrawn: coarse form rejects20KB/two words under1MiB; refined4311 has flat allocation and3–18%time adversity with CPU support. B718 unexplained stop/restart remains uncertainty; fresh same-bitB719 corrected the measurement. All original failures/cores survive. [Evidence](benchmarks/results/2026-11-14-streamed-cased-inventory-withdrawn/README.md). |

Completed foundations need no unchanged requalification:

- Shared compiler-fact/nonlocal correction, annotation demand and lowered-tree
  retention cleanup are delivered. [Evidence](benchmarks/results/2026-11-02-shared-compiler-facts/README.md).
- Direct UTF8 formatting/storage: allocation−8.67%original/−8.59%later pair;
  two controlled report CPU/elapsed confirmations support−5..−8%on their sources.
  Original15.125ms adversity remains unexplained and preserved. [Evidence](benchmarks/results/2026-11-02-formatting-confirmation/README.md).
- Native helper returns: whole-run allocation−19.92%CSVhelpers/−19.31%JSONhelpers,
  separate from diagnostic elapsed; corrected full delivery8f07764a complete.
  [Evidence](benchmarks/results/2026-11-02-native-function-returns/README.md).
- Bulk CSV's6–8%opportunity was selectively revisited: admitted array adoption/shared
  keys shipped. R308/R314 alternatives remain withdrawn, useful regressions retained.
  [Evidence](benchmarks/results/2026-11-02-native-csv-records/README.md).
- Final call slots/linear continuations/native prefixes, integer chains/counters,
  immutable builtins, native UTF8 JSON, incremental XML and builtin for-loops are
  delivered. R345 CSV allocation−25.31%/warm−14.71..−20.25%; confirmed
  compile-to-result−17.84..−19.94%. Original Windows CRLF failure stays failed;
  corrected descendant009d passes combined delivery. [Evidence](benchmarks/results/2026-11-14-native-for-prefixes/README.md).
- Slower call-arena/control designs remain lessons. R325/R327/R342 do not establish
  a dominant removable frame/packet; R338's frame-allocation explanation was
  corrected. R343/R348 cased-buffer/inventory alternatives are withdrawn. Historical
  failures and XML/report/search/helper control debt remain explicit in their
  evidence; do not add source-pair percentages or infer release-wide neutrality.

## Prioritized delivery

1. **Decide and deliver R349 as one coherent representation change.**
   Hypothesis: nonlocal increments box once per line; an authoritative existing cell
   can store an exact machine integer and publish one stable object when read.
   The source gate verified unmirrored owners, instruction extents and namespace
   publication through actual admission observers. Prototype removes per-update
   boxes and three-instruction temporary transport, reusing the machine kernel and
   existing compiler pass/unused metadata field. Three48Bcell preflights consolidate
   into96Bmetadata/current-value funding. Earlier tiny-budget denial is acceptable;
   old aliases never refund. No new policy, identity ledger, arena or tagged VM.
   Semantic acceptance: aliases/id/is, nonlocals, delete/unbound/rebind, namespace/
   lambda/comprehension exposure, exact promotion, protocols/error order, genuine
   suspension, cancellation/refusal, joined cleanup and retained results.
   Complete captured text versus unchanged direct-text/fulfillment controls separates
   allocation, warm elapsed and wider CPU. Preserve adverse medians and observable-
   read uncertainty. B720 and frequent-read exposure checks are complete; retain for18%allocation
   removal, with CPU attribution/frequent-read timing debt explicit. Current runtime
   docs describe the representation and conservative funding. Committed/pushed e235b18b; full CI43571864663 includes Windows/Ubuntu actual11/10,
   original stress and installed Release consumers. Continue independent roadmap
   work while that runs; cache terminal status and space observations four minutes. No unchanged retiming is needed for this
   allocation decision. [Evidence](benchmarks/results/2026-11-14-captured-scalar-storage/README.md).

2. **Advance the substantial redesign roadmap after that decision.**
   Select work from demonstrated owning costs in representative scripts, not another
   isolated local tweak. Existing CPython gaps justify continued work but do not
   attribute them. Stop each source investigation when it selects/rejects a bounded
   coherent change; it need not exhaust every explanation.

   | Area / scripts | Work to eliminate; acceptance and displacement |
   | --- | --- |
   | Complete calls, frames, operand transport / helpers, search, invoices | Establish an actually redundant complete activation or storage stage; final slots and deferred prefixes already exist. Remove its displaced route. Preserve defaults/receivers, closure identity, exact errors, stack handoff, pending transfers and awaited cleanup. Do not revive a slower arena under another name. |
   | Per-record construction / CSV and JSON aggregates, reports | Existing CSV adoption/shared keys and iterative JSON are foundations. Eliminate a real record representation, copy or pass and retire its constructor. Preserve callbacks, mutation, aliases, pre-effect admission and replacement overlap. |
   | Scalar transport / counters, invoices, checksums | Decide R349 first. Select wider storage only with owning evidence; preserve exact promotion/identity/publication. A universal tagged VM is unselected. |
   | Remaining text conversions / file search, text summaries, reports | Remove an entire conversion/build stage. Preserve Unicode expansion/context, eager preflight, errors and real callback suspension; delete the superseded pipeline. R343/R348 scans are measured warnings, not permanent bans. |
   | Repeated frontend analysis / fresh generated scripts | Reuse proven repeated facts/retained IR with scopes, nonlocals, diagnostic order, cancellation and admission intact. Duplicate-name modeling accounted for only0.41–0.95%allocation; many visitors alone do not prove dominance. Remove displaced analysis rather than adding a cache layer. |

   Before each selected prototype record its hypothesis, eliminated work/storage,
   affected complete scripts, semantic/cancellation/ownership criteria, implementation
   to delete, bounded before/after/control comparison and regression-debt decision.
   Temporary setbacks are acceptable with a concrete completion milestone. Refresh
   representative CPython compilation/warm/fresh comparisons at a changed coherent
   checkpoint; state mediated I/O, reset, output, result cleanup and cache boundaries.
   Do not repeat B717 or completed qualification without a material change.

3. **Develop regex independently.**
   The Lython-owned Python/nativeUTF8/original-window/byte-scalar/capture/flags/error/
   current-token contract and existing owners/caches remain authoritative. Core has
   no backend edge; development producers and adapter-local bridges are allowed.
   Completed dev80/15b248dc checks (88internal/534public per actual11/10) are cached;
   normal29inputs/optional nonpackable0.4adapter stay unchanged. Producer06ef69e4
   leaves all three integration files byte-identical toae463cb4; dev84 package
   834162df is a separate immutable identity. Missing producer capabilities are
   separate one-match work/result owners, nativeUTF8group-name enumeration/copy,
   and token-independent cursor creation with cancellable preparation. Only the
   affected final adapter qualification defers. Select concrete contract/code/new-
   capability work; no repeated unchanged producer qualification. Distinguish
   contract correctness, semantic validation and real backend performance/safety.
   [Assessment](benchmarks/results/2026-11-14-regex-provider-capabilities/README.md).

## Evidence and lasting constraints

Separate architectural simplification, allocation reduction and demonstrated CPU
improvement. Percentages inform decisions, not automatic vetoes. A timeout,
unstable unchanged control or inconclusive observation establishes uncertainty.
Allow bounded confirmation, refinement and measurement correction for a stated
reason, preserving every adverse point and original failed condition. No blanket
one-attempt/no-retiming/permanently-closed rule or open-ended qualification campaign.

Focused Release correctness/cancellation/ownership checks during iteration; batch
Windows/Ubuntu actual11/10, original stress and installed Release consumers at
meaningful delivery checkpoints. Fully managed/memory-safe only: no unsafe/Unsafe,
pointers, P/Invoke or native probing. Preserve managed stack protection, host
capabilities/original paths+Cwd, cancellation, cycles/XML depth, checked representation
bounds and bounded I/O chunks. No fuel/quotas, hidden caps/default allowance, regex
work/time policies, tracing, weak reclamation, forced GC or abandoned users.
Borrowed allowance funds capacity/overlap, aliases/results/caches and pending users.
First refusal is terminal through suppression/finally: retain origin, await cleanup,
never retry. Long streams use bounded host commands. Force nonincremental builds
after restoration; copy/verify complete frozen images and sources. Persist evidence,
join users, preserve VM floors/current images. [AGENTS](AGENTS.md) remains binding.
