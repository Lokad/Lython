from pathlib import Path
import ast,subprocess
r=Path(__file__).parent;prior=r.parent/'captured-loop-ip-r342/analyze-loop.py'
for name in ['invoice','search']:
 s=prior.read_text(encoding='utf-8').replace('analyze-captured.py','analyze-'+name+'.py').replace('ExecutionContext::TryExecuteDictionaryLoop(', 'NativeExecution::RunCore(').replace('TryExecuteDictionaryLoop(', 'NativeExecution:RunCore(').replace('retrieved/profiles/captured','retrieved/profiles/'+name).replace('dictionary-loop.asm','native-run-core.asm').replace('Committed2f606519/frozen53becdb6','Committede235b18b/frozen71ba421c').replace('dictionary-loop-instruction-groups.json','native-body-'+name+'-instruction-groups.json').replace('dictionaryLoopLeafSamples','nativeBodyLeafSamples').replace('dictionaryLoopGuestSamplePercent','nativeBodyGuestSamplePercent')
 ast.parse(s);script=r/('analyze-native-'+name+'.py');script.write_text(s,encoding='utf-8',newline='\n')
 with(r/('native-body-'+name+'.log')).open('w',encoding='utf-8',newline='\n')as f:done=subprocess.run(['C:/Python313/python.exe','-X','utf8',str(script)],stdout=f,stderr=subprocess.STDOUT)
 print(name,done.returncode,(r/('native-body-'+name+'.log')).read_text(encoding='utf-8')[:9500],flush=True)
 assert done.returncode==0
