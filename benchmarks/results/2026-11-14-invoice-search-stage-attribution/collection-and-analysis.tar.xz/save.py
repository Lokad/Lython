from pathlib import Path
import hashlib,json,shutil,subprocess,tarfile
r=Path(__file__).parent;out=Path('benchmarks/results/2026-11-14-invoice-search-stage-attribution');out.mkdir(exist_ok=False)
assert json.loads((r/'terminal-status.json').read_text(encoding='utf-8'))['receipt']['complete']
invoice=json.loads((r/'attribution-invoice.json').read_text(encoding='utf-8'));search=json.loads((r/'attribution-search.json').read_text(encoding='utf-8'))
assert (invoice['samples'],search['samples'])==(1053,742)
decision=dict(source='e235b18b/frozen71ba421c',state='Bounded source gate complete; no new runtime prototype selected.',findings=['Native entry/body plus ordinary dispatch are material owning costs, not removable shares. Invoice1053/5.30guestCPU seconds; search742/3.79. Unknown96/142 and zero ambiguous leaves remain explicit.','Exact same-process Tier1 native body maps117invoice and42search leaves, with11568/5405byte maps/disassembly. Invoice samples spread across387groups; hottest13leaves mixes metadata/cancellation. Search19leaves in the prologue are2.56%of guest samples, not evidence for a large new call engine.','Native calls already use final slots and one16slot private buffer. Eligibility reads live mutable defaults/keyword storage; replacing it with a once-cached fact would be a semantic change. No redundant complete packet/frame is established.','Private DictReader rows already use raw funded arrays and shared-key adoption without a guest list. CSV FinishRecord already combines field/row admission; short strings use inline UTF8 and native input is decoded into its admitted record buffer. The proposed list/copy/per-field allowance removal would duplicate delivered work.','Tuple CopyGovernedItems has21invoice leaves; native CSV FinishRecord36/Feed31/adoption17. These include required retained values/decoding/construction and do not identify a whole redundant record stage.','Current exact integer operators already avoid allowance transactions for fixed-size scalars. Do not remove substantial-storage preflights based on a generic memory-admission frame share.'],next='Continue remaining dispatch/operand construction source analysis on this evidence, with an explicit eliminated representation and alias/identity/promotion/cleanup contract before selecting a prototype. Do not repeat this unchanged capture or revive slower arenas/default caches. The whole-script performance objective remains active; this negative source gate is not its completion.',semanticRequirements=['Python values/identity/aliases and exact promotion','live defaults, receivers and closures; supported errors/evaluation order','actual asynchronous protocols and joined pending storage','current cancellation, managed stack admission, terminal memory refusal and result/cache funding'],noNormalTimingComparison=True,publicationHeld=True)
(r/'decision.json').write_text(json.dumps(decision,indent=2)+'\n',encoding='utf-8',newline='\n')
for name in ['identity.json','prospective.json','decision.json','attribution-invoice.json','attribution-search.json','native-body-invoice-instruction-groups.json','native-body-search-instruction-groups.json','terminal-status.json','archive-receipt.json','observations.tgz']:shutil.copyfile(r/name,out/name)
with tarfile.open(out/'collection-and-analysis.tar.xz','w:xz')as t:
 for p in sorted(r.iterdir()):
  if p.is_file()and p.name not in ['observations.tgz','payload.tgz']:t.add(p,arcname=p.name,recursive=False)
(out/'README.md').write_text('''# Complete invoice and search stage attribution

2026-11-14, R350/B721, exact committed `e235b18b` / frozen `71ba421c`.
Existing quiet F4as_v7 Ubuntu24.04.4/.NET11RC3 worker/optional0.4adapter,
two5s199Hz cpu-clock/fp captures after8guest-second warmups. Invoice batches64,
search512 avoid consuming a capture in one oversized invoice request. Perf maps
and JIT disassembly are explicit diagnostic overrides. This is CPU attribution,
not a normal timing, allocation-stack or CPython comparison.

| Complete script | Guest CPU | Leaf samples | Unknown leaves | Ambiguous |
| --- | ---: | ---: | ---: | ---: |
| Invoice,4,096records /127,031B | 5.30s | 1,053 | 96(9.12%) | 0 |
| Search,2,049lines /42,010B, stop after1,025 | 3.79s | 742 | 142(19.14%) | 0 |

Search also uses1.02s on a thread-pool worker; all thread deltas and raw stacks
remain available. Guest-only selection does not describe all embedding CPU.
Ordinary dispatch, native entry/body, admission and useful record/scalar work are
material owning costs; the families include inlined work and are not removable
shares. Unknown kernel/runtime leaves limit attribution.

Every native-body leaf maps to one unique same-process Tier1 range/disassembly:
117invoice leaves,11,568bytes/387groups;42search leaves,5,405bytes/142groups.
Invoice's largest13-leaf group mixes instruction metadata and cancellation; other
groups include real lookup/hash/arithmetic. Search has19leaves in a managed
prologue (2.56%of guest samples). Neither establishes a large redundant activation
or operand packet. Preserve earlier slower arena/control lessons, without making
them permanent design bans.

Source inspection also rules out attractive but stale removals: native calls
already bind final slots; private DictReader rows already bypass guest lists and
adopt funded arrays/shared keys. CSV record construction already combines major
field/row admission; fixed-size scalar arithmetic avoids allowance transactions.
Native eligibility includes live default storage. Tuple copying and CSV decoding
have useful retained-value semantics; their hot methods alone do not establish an
unnecessary complete stage.

Close this bounded source gate without a speculative local patch. Continue
dispatch/operand construction analysis from these owning facts before selecting
one coherent representation removal, preserving identity, mutable defaults,
promotion, genuine suspension, cancellation, terminal refusal and retained owners.
No new engine, memory policy, once-cached mutable-default proof or universal value
rewrite follows automatically. The wider performance objective remains active.

All source/image/auxiliary/golden/balance/quiet/join/archive gates pass. No workers
or RAM fixtures remain; each RAM byte is independently archived/verified before
unmount under120s ownership. Only three duplicate working raw archives were
retired after exact canonical Git/SHA/path/UID/terminal proof, with all current
images/catalogs/toolchains and254/252MiBfloors preserved. Canonical evidence
remains immutable. Raw SHA256:
`4bb297596bb7906fe188561c84ecfcf7fa2d3db745ebc36d7d389aa0a7eed7f4`.
R349 full delivery43571864663 is independent and pending at capture time.
Publication/tagging remain held.

[Decision](decision.json),[invoice](attribution-invoice.json),[search](attribution-search.json),
[raw](observations.tgz),[collection/analysis and source-gate history](collection-and-analysis.tar.xz).
''',encoding='utf-8',newline='\n')
p=Path('benchmarks/EXPERIMENTS.md');s=p.read_text(encoding='utf-8');anchor='[R349 captured scalar storage]';assert anchor in s
s=s.replace(anchor,'''[R350 invoice/search stage attribution](results/2026-11-14-invoice-search-stage-attribution/README.md)
maps exacte235b18b/frozen71ba complete scripts:1,053/742guest leaves with96/142
unknown and zero ambiguous. All native-body leaves map to same-process Tier1
groups; mixed metadata/lookup/arithmetic does not establish a redundant complete
frame/packet. DictReader already bypasses lists/combines record admission. Close
this gate without a speculative patch; further transport work needs a concrete
displaced representation and semantic contract. No normal timing claim.

'''+anchor,1);p.write_text(s,encoding='utf-8',newline='\n')
p=Path('PLAN.md');s=p.read_text(encoding='utf-8');a=s.index('2. **R350:');b=s.index('   Select work from demonstrated',a)
s=s[:a]+'''2. **R350 source gate complete; select a coherent remaining transport removal.**
   Committede235b18b/frozen71ba: B721 maps1,053invoice/742search guest leaves,
   96/142unknown and zero ambiguous. Every117/42native-body leaf maps to exact
   same-process Tier1 groups; useful/mixed work does not identify a large redundant
   activation. Final call slots, listless DictReader and combined CSV admission
   already exist. No new runtime prototype selected; do not duplicate those stages,
   infer removable shares or repeat unchanged captures. Continue dispatch/operand
   construction source analysis with a concrete displaced representation and
   identity/alias/promotion/pending-cleanup contract before implementation.
   [Evidence](benchmarks/results/2026-11-14-invoice-search-stage-attribution/README.md).
'''+s[b:];p.write_text(s,encoding='utf-8',newline='\n')
assert not subprocess.check_output(['git','diff','--cached','--name-only'],text=True).strip()
subprocess.run(['git','add','--',str(out),'benchmarks/EXPERIMENTS.md','CHANGELOG.md'],check=True);subprocess.run(['git','diff','--cached','--check'],check=True)
subprocess.run(['git','commit','-m','Record complete invoice and search stage attribution [skip ci]'],check=True);subprocess.run(['git','push','origin','HEAD'],check=True,timeout=120)
print('R350 bounded gate/evidence committed; production stays exacte235b18b; performance goal remains active.',flush=True)
