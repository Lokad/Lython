from pathlib import Path
import ast,base64,datetime,hashlib,json,subprocess,tarfile
r=Path(__file__).parent;prior=r.parent/'captured-loop-ip-r342';current=r.parent/'closure-scalars-r349'
root='/home/lokad/lython-bench-checks/script-stage-b721-20261114';oldroot='/home/lokad/lython-bench-checks/captured-loop-ip-b712-20261114'
fullcatalog=Path('benchmarks/results/2026-11-14-iteration-cpython-checkpoint/observations.tgz')
with tarfile.open(fullcatalog)as t:catalog=t.extractfile('representative.json').read()
image=json.loads((current/'b720/identity.json').read_text(encoding='utf-8'))
identity=dict(coreSHA256={'candidate':image['coreSHA256']['candidate']},auxiliaryFiles=image['candidateAuxiliaryFiles'],catalogSHA256=hashlib.sha256(catalog).hexdigest(),sourceRevision='Committede235b18b/frozen71ba421c; R350 complete invoice/search stage attribution',diagnosticOnly=True,scriptCaptureWallSeconds=5,warmGuestSeconds=8,compilationExcluded=True,allocationStacksNotMeasured=True,disassemblyCollectedInTheSameProcessAsSamples=True,fullDelivery='43571864663pending; previous009d fully qualified43563853239',noSpeedupForecast=True)
(r/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8',newline='\n')
prospective=dict(recordedUTC=datetime.datetime.now(datetime.timezone.utc).isoformat(),hypothesis='Current invoice and keyword-default file search retain CPython warm gaps1.26–1.31x/1.66–1.76x. Owning work may expose a complete redundant call/frame/operand or record/text construction stage, but prior profiles do not establish one and do not justify another arena or local method tweak.',question='Which whole phase or representation dominates these complete scripts after delivered native/cursor/scalar changes?',bound='Reuse existing perf/protocol/image on committed71ba: two5s199Hz captures after8guest-second warmups,120s owner. Invoice batch64/search512 prevents one invoice request consuming a whole capture. Attribution only, no normal timing/CPU-gain claim.',acceptance='Exact core/all auxiliary files and source/catalog identities, output/files goldens, budget baseline, actual worker ownership, quiet before/after, joined users, RAM trace independently archived/verified before unmount. Keep every unknown/ambiguous sample and failure.',stopping='Select one coherent removal from owning costs and semantics, or record that no redundant complete stage is established. A hot method is not a removable share. No automatic extra capture or marginal patch.',constraints='Managed-only, current cancellation/admission/terminal refusal/retained owners and stack safety; no new quota or policy. Full delivery runs independently. Publication held.')
(r/'prospective.json').write_text(json.dumps(prospective,indent=2)+'\n',encoding='utf-8',newline='\n')
for name in ['ops-profile.py','collect.py','run.sh','retrieve.py']:
 s=(prior/name).read_text(encoding='utf-8').replace(oldroot,root).replace('Committed2f606519/frozen53becdb6; R342 captured dictionary-loop instruction attribution',identity['sourceRevision'])
 if name=='ops-profile.py':
  s=s.replace("[('captured', 'scripts.text-summary-helpers.nonlocal-counter.large', 'warm')]","[('invoice','scripts.csv-invoice.large','warm'),('search','scripts.file-search.large','warm')]")
  s=s.replace("*TryExecuteDictionaryLoop*","*RunCore*").replace('dictionary-loop.asm','native-run-core.asm').replace("(128 if name=='captured' else 512)","(64 if name=='invoice' else 512)").replace('total_capture_seconds > 8','total_capture_seconds > 12')
 if name=='collect.py':
  s=s.replace("['captured']","['invoice','search']").replace("assert json.loads(archive.extractfile('profiles/captured/record.json').read())['exitCode']==0","assert all(json.loads(archive.extractfile('profiles/'+name+'/record.json').read())['exitCode']==0 for name in ['invoice','search'])")
 if name.endswith('.py'):ast.parse(s)
 (r/name).write_text(s,encoding='utf-8',newline='\n')
with tarfile.open(r/'payload.tgz','w:gz')as t:
 for name in ['identity.json','ops-profile.py','collect.py','run.sh']:t.add(r/name,arcname=name)
with tarfile.open(r/'payload.tgz')as t:unpacked=sum(m.size for m in t.getmembers())
proofs=[]
sources=[('e235b18b','benchmarks/results/2026-11-14-captured-scalar-storage/sources-checks-and-observations.tar.xz','b720/observations.tgz','captured-scalar-b720-20261114/observations.tgz'),('fc11817c','benchmarks/results/2026-11-14-streamed-cased-inventory-withdrawn/prototypes-checks-and-observations.tar.xz','b719/observations.tgz','streamed-cased-b719-20261114/observations.tgz'),('c89010e6','benchmarks/results/2026-11-14-iteration-cpython-checkpoint/observations.tgz',None,'iteration-checkpoint-b717-20261114/observations.tgz')]
for commit,path,member,remote in sources:
 p=Path(path);blob=subprocess.check_output(['git','show',commit+':'+path]);assert hashlib.sha256(blob).digest()==hashlib.sha256(p.read_bytes()).digest()
 if member:
  with tarfile.open(p)as t:working=t.extractfile(member).read()
 else:working=blob
 proofs.append(dict(commit=commit,path=path,archiveSHA256=hashlib.sha256(blob).hexdigest(),member=member,remote=remote,workingSHA256=hashlib.sha256(working).hexdigest(),workingBytes=len(working)))
(r/'retirement-proof.json').write_text(json.dumps(proofs,indent=2)+'\n',encoding='utf-8',newline='\n')
config=dict(root=root,sourceRoot='/home/lokad/lython-bench-checks/captured-scalar-b720-20261114',catalogRoot='/home/lokad/lython-bench-checks/iteration-checkpoint-b717-20261114',unit='lython-b721-script-stage-20261114',identity=identity,payloadBytes=(r/'payload.tgz').stat().st_size,payloadSHA256=hashlib.sha256((r/'payload.tgz').read_bytes()).hexdigest(),unpackedBytes=unpacked,retirementProofs=proofs)
(r/'config.json').write_text(json.dumps(config,indent=2)+'\n',encoding='utf-8',newline='\n')
code=r'''from pathlib import Path
import ast,fcntl,hashlib,io,json,os,shutil,stat,subprocess,sys,tarfile
config=CONFIG
base=Path('/home/lokad/lython-bench-checks').resolve();root=Path(config['root']);source=Path(config['sourceRoot']);catalogRoot=Path(config['catalogRoot']);digest=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert root.parent==base and source.resolve()==source and source.parent==base and not root.exists()
with(base/'comparison-vm.lock').open('a')as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record|[p]ython3.*cpython-worker.py'],capture_output=True).returncode==1
 assert digest(source/'candidate/Lokad.Lython.dll')==config['identity']['coreSHA256']['candidate']
 for name,sha in config['identity']['auxiliaryFiles'].items():assert digest(source/'candidate'/name)==sha
 assert {p.name for p in(source/'candidate').iterdir()}==set(config['identity']['auxiliaryFiles'])|{'Lokad.Lython.dll'}
 assert digest(catalogRoot/'representative.json')==config['identity']['catalogSHA256']
 retired=[]
 for proof in config['retirementProofs']:
  p=base/proof['remote'];s=p.lstat()
  assert p.resolve()==p and p.is_relative_to(base)and stat.S_ISREG(s.st_mode)and s.st_uid==os.getuid()and s.st_nlink==1
  assert s.st_size==proof['workingBytes']and digest(p)==proof['workingSHA256']
  assert(p.parent/'exit-code.txt').read_text().strip()=='0'and not(p.parent/'guest-fixtures').exists()
  assert json.loads((p.parent/'archive-receipt.json').read_text())['complete']
  retired.append(dict(path=str(p),bytes=s.st_size,sha256=proof['workingSHA256']))
 beforeRetirement=shutil.disk_usage(base).free
 for entry in retired:Path(entry['path']).unlink()
 (base/'b721-proved-duplicate-archive-retirement-20261114.json').write_text(json.dumps(dict(proofs=config['retirementProofs'],retiredOnly=retired,allVerifiedBeforeMutation=True,freshIdleLease=True,beforeFreeBytes=beforeRetirement,afterFreeBytes=shutil.disk_usage(base).free,canonicalEvidenceAndAllImagesCatalogsToolchainsPreserved=True,floorsUnchanged=True),indent=2)+'\n')
 free=shutil.disk_usage(base).free;assert free>254*1024*1024+config['unpackedBytes'],(free,config['unpackedBytes'])
 payload=sys.stdin.buffer.read(config['payloadBytes']+1);assert len(payload)==config['payloadBytes']and hashlib.sha256(payload).hexdigest()==config['payloadSHA256']
 root.mkdir()
 with tarfile.open(fileobj=io.BytesIO(payload),mode='r:gz')as t:t.extractall(root,filter='data')
 shutil.copytree(source/'candidate',root/'candidate',copy_function=os.link);os.link(catalogRoot/'representative.json',root/'catalog.json')
 for name in ['collect.py','ops-profile.py']:ast.parse((root/name).read_text())
 subprocess.run(['/bin/sh','-n',str(root/'run.sh')],check=True);assert shutil.disk_usage(base).free>254*1024*1024
 (root/'space-preflight.json').write_text(json.dumps(dict(beforeFreeBytes=free,afterFreeBytes=shutil.disk_usage(base).free,noNewImageOrCatalogUpload=True,floorsUnchanged=True))+'\n')
 fixture=root/'guest-fixtures';fixture.mkdir()
 subprocess.run(['sudo','-n','mount','-t','tmpfs','-o','size=128m,mode=0700,uid=lokad,gid=lokad','lython-b721-fixtures',str(fixture)],check=True)
try:subprocess.run(['sudo','-n','systemd-run','--unit='+config['unit'],'--property=User=lokad','--property=WorkingDirectory='+str(root),'--property=RuntimeMaxSec=120','--property=TimeoutStopSec=30','--property=KillMode=control-group','/bin/sh',str(root/'run.sh')],check=True)
except BaseException:
 subprocess.run(['sudo','-n','umount',str(fixture)],check=True);fixture.rmdir();raise
print(subprocess.check_output(['systemctl','show',config['unit']+'.service','--property=ActiveState,MainPID,RuntimeMaxUSec'],text=True))
'''.replace('CONFIG',repr(config));ast.parse(code);(r/'launch-command.py').write_text(code,encoding='utf-8',newline='\n')
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
command="python3 -c 'import base64;exec(base64.b64decode(\""+base64.b64encode(code.encode()).decode()+"\"))'"
done=subprocess.run(ssh+[command],input=(r/'payload.tgz').read_bytes(),capture_output=True,timeout=45)
(r/'launch.log').write_bytes(done.stdout+done.stderr);assert done.returncode==0,(done.stdout+done.stderr).decode()
now=datetime.datetime.now(datetime.timezone.utc);(r/'observe-not-before.json').write_text(json.dumps(dict(startedUTC=now.isoformat(),doNotObserveBeforeUTC=(now+datetime.timedelta(seconds=90)).isoformat(),ownerSeconds=120),indent=2)+'\n',encoding='utf-8',newline='\n')
p=Path('PLAN.md');s=p.read_text(encoding='utf-8');(r/'PLAN-before-source-gate.md').write_text(s,encoding='utf-8',newline='\n');s=s.replace('2. **Advance the substantial redesign roadmap after that decision.**','2. **R350: complete invoice/search stage attribution, then select a redesign.**\n   Committede235b18b/frozen71ba is fixed. B721 reuses existing workers/catalog/perf:\n   two5s199Hz captures after8guest-second warmups,120s owner; no timing claim.\n   Source gate selects an actual whole phase/representation to remove or records\n   why it cannot. Preserve unknown samples and do not equate hot owning methods\n   with removable overhead. No production mutation or new profiling framework.');p.write_text(s,encoding='utf-8',newline='\n')
print((done.stdout+done.stderr).decode(),flush=True);print('Observe after',(now+datetime.timedelta(seconds=90)).isoformat(),flush=True)
