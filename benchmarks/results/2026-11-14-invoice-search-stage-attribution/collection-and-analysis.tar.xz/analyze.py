from pathlib import Path
import ast,json,subprocess
r=Path(__file__).parent
base=(r.parent/'native-entry-ip-r327/analyze-search.py').read_text(encoding='utf-8')
for name in ['invoice','search']:
 s=base.replace("r/'retrieved/profiles/search'","r/'retrieved/profiles/"+name+"'").replace('Committede698656c/frozen660a0338 search complete-script','Committede235b18b/frozen71ba421c '+name+' complete-script').replace("r/'attribution-search.json'","r/'attribution-"+name+".json'").replace("'casing/whitespace'","'text operations'")
 ast.parse(s);script=r/('analyze-'+name+'.py');script.write_text(s,encoding='utf-8',newline='\n')
 subprocess.run(['C:/Python313/python.exe','-X','utf8',str(script)],check=True)
 d=json.loads((r/('attribution-'+name+'.json')).read_text(encoding='utf-8'));print(name,d['nearestFrameFamilies'],flush=True)
 for method,n in d['topLeafCpuSamples'][:18]:print(n,method,flush=True)
