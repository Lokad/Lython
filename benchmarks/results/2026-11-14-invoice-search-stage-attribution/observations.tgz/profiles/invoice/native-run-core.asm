; Assembly listing for method Lokad.Lython.LythonCompiledScript:RunCore(Lokad.Lython.ILythonHost,Lokad.Lython.LythonRunOptions):Lokad.Lython.LythonExecutionResult:this (Tier0)
; Emitting BLENDED_CODE for x64 + VEX + EVEX on Unix
; Tier0 code
; rbp based frame
; fully interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 192
       lea      rbp, [rsp+0xC0]
       xor      eax, eax
       mov      qword ptr [rbp-0xB8], rax
       vxorps   xmm8, xmm8, xmm8
       vmovdqu32 zmmword ptr [rbp-0xB0], zmm8
       vmovdqu32 zmmword ptr [rbp-0x70], zmm8
       vmovdqa  xmmword ptr [rbp-0x30], xmm8
       mov      qword ptr [rbp-0x20], rax
       mov      gword ptr [rbp-0x08], rdi
       mov      gword ptr [rbp-0x10], rsi
       mov      gword ptr [rbp-0x18], rdx
 
G_M000_IG02:                ;; offset=0x0047
       mov      rax, gword ptr [rbp-0x08]
       mov      rax, gword ptr [rax+0x08]
       mov      gword ptr [rbp-0x58], rax
       mov      rax, gword ptr [rbp-0x58]
       mov      gword ptr [rbp-0x60], rax
       cmp      gword ptr [rbp-0x58], 0
       jne      SHORT G_M000_IG04
 
G_M000_IG03:                ;; offset=0x0062
       mov      rdi, 0x78C06D886F18
       call     CORINFO_HELP_NEWSFAST
       mov      gword ptr [rbp-0xA8], rax
       mov      rdi, gword ptr [rbp-0xA8]
       mov      rsi, 0x78C0684583E8
       call     [System.ObjectDisposedException:.ctor(System.String):this]
       mov      rdi, gword ptr [rbp-0xA8]
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG04:                ;; offset=0x009C
       mov      rax, gword ptr [rbp-0x60]
       mov      gword ptr [rbp-0x20], rax
       cmp      gword ptr [rbp-0x18], 0
       jne      SHORT G_M000_IG05
       mov      rdi, 0x78C06D9E6A60
       call     CORINFO_HELP_NEWSFAST
       mov      gword ptr [rbp-0xA0], rax
       mov      rdi, gword ptr [rbp-0xA0]
       call     [Lokad.Lython.LythonRunOptions:.ctor():this]
       mov      rax, gword ptr [rbp-0xA0]
       mov      gword ptr [rbp-0x18], rax
 
G_M000_IG05:                ;; offset=0x00D9
       mov      rdi, gword ptr [rbp-0x18]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.LythonRunOptions:get_MemoryBudget():Lokad.Lython.ILythonMemoryBudget:this]
       mov      gword ptr [rbp-0x68], rax
       mov      rax, gword ptr [rbp-0x68]
       mov      gword ptr [rbp-0x70], rax
       cmp      gword ptr [rbp-0x68], 0
       jne      SHORT G_M000_IG06
       mov      rax, gword ptr [rbp-0x08]
       mov      rax, gword ptr [rax+0x20]
       mov      gword ptr [rbp-0x90], rax
       mov      rax, gword ptr [rbp-0x90]
       mov      gword ptr [rbp-0x70], rax
       cmp      gword ptr [rbp-0x90], 0
       jne      SHORT G_M000_IG06
       vxorps   xmm0, xmm0, xmm0
       vmovups  xmmword ptr [rbp-0x48], xmm0
       mov      rdi, 0x78C06D926738
       call     CORINFO_HELP_NEWSFAST
       mov      gword ptr [rbp-0x98], rax
       mov      rsi, qword ptr [rbp-0x48]
       mov      rdx, qword ptr [rbp-0x40]
       mov      rdi, gword ptr [rbp-0x98]
       call     [Lokad.Lython.LythonMemoryBudget:.ctor(System.Nullable`1[long]):this]
       mov      rax, gword ptr [rbp-0x98]
       mov      gword ptr [rbp-0x70], rax
 
G_M000_IG06:                ;; offset=0x015B
       mov      rax, gword ptr [rbp-0x70]
       mov      gword ptr [rbp-0x28], rax
       mov      rdi, gword ptr [rbp-0x28]
       mov      r11, 0x78C06BA720B0
       call     [r11]Lokad.Lython.ILythonMemoryBudget:CreateScope():Lokad.Lython.ILythonMemoryScope:this
       mov      gword ptr [rbp-0x30], rax
 
G_M000_IG07:                ;; offset=0x0178
       mov      rdi, gword ptr [rbp-0x18]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.LythonRunOptions:get_ResultMemoryBudget():Lokad.Lython.ILythonMemoryBudget:this]
       mov      gword ptr [rbp-0x78], rax
       mov      rax, gword ptr [rbp-0x78]
       mov      gword ptr [rbp-0x80], rax
       cmp      gword ptr [rbp-0x78], 0
       jne      SHORT G_M000_IG08
       mov      rax, gword ptr [rbp-0x28]
       mov      gword ptr [rbp-0x80], rax
 
G_M000_IG08:                ;; offset=0x019F
       mov      rdi, gword ptr [rbp-0x80]
       mov      r11, 0x78C06BA720B8
       call     [r11]Lokad.Lython.ILythonMemoryBudget:CreateScope():Lokad.Lython.ILythonMemoryScope:this
       mov      gword ptr [rbp-0x38], rax
 
G_M000_IG09:                ;; offset=0x01B4
       mov      rdi, gword ptr [rbp-0x18]
       mov      rsi, gword ptr [rbp-0x30]
       mov      rdx, gword ptr [rbp-0x38]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.LythonRunOptions:WithMemoryOwners(Lokad.Lython.ILythonMemoryBudget,Lokad.Lython.ILythonMemoryBudget):Lokad.Lython.LythonRunOptions:this]
       mov      gword ptr [rbp-0xB0], rax
       mov      rdx, gword ptr [rbp-0xB0]
       mov      rsi, gword ptr [rbp-0x10]
       mov      rax, gword ptr [rbp-0x20]
       mov      rdi, gword ptr [rax+0x10]
       mov      rax, gword ptr [rbp-0x20]
       call     [rax+0x18]System.Func`3[System.__Canon,System.__Canon,System.__Canon]:Invoke(System.__Canon,System.__Canon):System.__Canon:this
       mov      gword ptr [rbp-0xB8], rax
       mov      rdi, gword ptr [rbp-0xB8]
       mov      rsi, gword ptr [rbp-0x38]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.LythonExecutionResult:OwnMemoryScope(Lokad.Lython.ILythonMemoryScope):Lokad.Lython.LythonExecutionResult:this]
       mov      gword ptr [rbp-0x50], rax
 
G_M000_IG10:                ;; offset=0x0207
       call     G_M000_IG15
       nop      
 
G_M000_IG11:                ;; offset=0x020D
       mov      rax, gword ptr [rbp-0x50]
 
G_M000_IG12:                ;; offset=0x0211
       add      rsp, 192
       pop      rbp
       ret      
 
G_M000_IG13:                ;; offset=0x021A
       push     rax
 
G_M000_IG14:                ;; offset=0x021B
       mov      gword ptr [rbp-0x88], rdi
       mov      rdi, gword ptr [rbp-0x38]
       mov      r11, 0x78C06BA720C0
       call     [r11]System.IDisposable:Dispose():this
       call     CORINFO_HELP_RETHROW
       int3     
 
G_M000_IG15:                ;; offset=0x0239
       push     rax
 
G_M000_IG16:                ;; offset=0x023A
       cmp      gword ptr [rbp-0x30], 0
       je       SHORT G_M000_IG17
       mov      rdi, gword ptr [rbp-0x30]
       mov      r11, 0x78C06BA720C8
       call     [r11]System.IDisposable:Dispose():this
 
G_M000_IG17:                ;; offset=0x0252
       nop      
 
G_M000_IG18:                ;; offset=0x0253
       add      rsp, 8
       ret      
 
; Total bytes of code 600

; Assembly listing for method Lokad.Lython.Runtime.LythonRuntime+NativeExecution:RunCore(byref):bool:this (Instrumented Tier0)
; Emitting BLENDED_CODE for x64 + VEX + EVEX on Unix
; Instrumented Tier0 code
; rbp based frame
; fully interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 0x5D0
       lea      rbp, [rsp+0x5D0]
       vxorps   xmm8, xmm8, xmm8
       mov      rax, -0x570
 
G_M000_IG125:                ;; offset=0x001F
       vmovdqa  xmmword ptr [rbp+rax-0x40], xmm8
       vmovdqa  xmmword ptr [rbp+rax-0x30], xmm8
       vmovdqa  xmmword ptr [rbp+rax-0x20], xmm8
       add      rax, 48
       jne      SHORT G_M000_IG125
       mov      qword ptr [rbp-0x40], rax
       mov      bword ptr [rbp-0x30], rdi
       mov      bword ptr [rbp-0x38], rsi
 
G_M000_IG02:                ;; offset=0x0043
       mov      dword ptr [rbp-0x3E4], 0x3E8
       mov      rax, 0x78B88D801A58
       mov      rsi, gword ptr [rax]
       mov      rdi, bword ptr [rbp-0x38]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       jmp      G_M000_IG115
 
G_M000_IG03:                ;; offset=0x0068
       mov      rax, bword ptr [rbp-0x30]
       mov      rdi, gword ptr [rax+0x08]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Instructions():Lokad.Lython.Frontend.ExecutableInstruction[]:this]
       mov      rcx, bword ptr [rbp-0x30]
       mov      ecx, dword ptr [rcx+0x38]
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG120
       mov      edx, ecx
       imul     rdx, rdx, 32
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      bword ptr [rbp-0x40], rax
       mov      rax, bword ptr [rbp-0x30]
       mov      rdi, gword ptr [rax+0x18]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:get_State():Lokad.Lython.Runtime.ExecutionState:this]
       mov      gword ptr [rbp-0x1A0], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x3F0], rax
       mov      rsi, gword ptr [rbp-0x3F0]
       mov      rdi, gword ptr [rbp-0x1A0]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.ExecutionState:CheckExecution(Lokad.Lython.LythonSourceSpan):this]
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_OpCode():int:this]
       mov      dword ptr [rbp-0x64], eax
       mov      eax, dword ptr [rbp-0x64]
       add      eax, -3
       mov      dword ptr [rbp-0x5B4], eax
       cmp      dword ptr [rbp-0x5B4], 3
       ja       SHORT G_M000_IG05
 
G_M000_IG04:                ;; offset=0x00F7
       mov      eax, dword ptr [rbp-0x5B4]
       lea      rcx, [reloc @RWD00]
       mov      ecx, dword ptr [rcx+4*rax]
       lea      rdx, G_M000_IG02
       add      rcx, rdx
       jmp      rcx
 
G_M000_IG05:                ;; offset=0x0113
       mov      eax, dword ptr [rbp-0x64]
       add      eax, -25
       mov      dword ptr [rbp-0x5B8], eax
       cmp      dword ptr [rbp-0x5B8], 43
       ja       SHORT G_M000_IG07
 
G_M000_IG06:                ;; offset=0x0128
       mov      eax, dword ptr [rbp-0x5B8]
       lea      rcx, [reloc @RWD16]
       mov      ecx, dword ptr [rcx+4*rax]
       lea      rdx, G_M000_IG02
       add      rcx, rdx
       jmp      rcx
 
G_M000_IG07:                ;; offset=0x0144
       mov      rdi, 0x78C06E5601A0
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG113
 
G_M000_IG08:                ;; offset=0x0158
       mov      rdi, 0x78C06E5601A4
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp-0x30]
       mov      rdi, gword ptr [rax+0x08]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_FirstTemporarySlot():int:this]
       mov      dword ptr [rbp-0x3F4], eax
       mov      esi, dword ptr [rbp-0x3F4]
       mov      rdi, bword ptr [rbp-0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Trim(int):this]
       jmp      G_M000_IG118
 
G_M000_IG09:                ;; offset=0x0192
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x3F8], eax
       mov      esi, dword ptr [rbp-0x3F8]
       mov      rdi, bword ptr [rbp-0x30]
       xor      edx, edx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Read(int,int):System.Object:this]
       mov      rsi, rax
       mov      rdi, bword ptr [rbp-0x38]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x1A4], eax
       mov      rax, bword ptr [rbp-0x30]
       mov      rdi, gword ptr [rax+0x08]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_FirstTemporarySlot():int:this]
       cmp      eax, dword ptr [rbp-0x1A4]
       jg       SHORT G_M000_IG10
       mov      rdi, 0x78C06E5601A8
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp-0x30]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp-0x30]
       add      rax, 72
       mov      bword ptr [rbp-0x1B0], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x1B4], eax
       mov      rax, bword ptr [rbp-0x1B0]
       mov      eax, dword ptr [rax+0x08]
       cmp      dword ptr [rbp-0x1B4], eax
       jae      G_M000_IG120
       mov      rax, bword ptr [rbp-0x1B0]
       mov      rax, bword ptr [rax]
       mov      ecx, dword ptr [rbp-0x1B4]
       xor      rdx, rdx
       mov      gword ptr [rax+8*rcx], rdx
 
G_M000_IG10:                ;; offset=0x0248
       mov      rdi, 0x78C06E5601AC
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp-0x30]
       mov      rdi, gword ptr [rax+0x08]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_FirstTemporarySlot():int:this]
       mov      dword ptr [rbp-0x3FC], eax
       mov      esi, dword ptr [rbp-0x3FC]
       mov      rdi, bword ptr [rbp-0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Trim(int):this]
       jmp      G_M000_IG118
 
G_M000_IG11:                ;; offset=0x0282
       mov      rax, bword ptr [rbp-0x30]
       mov      rdi, gword ptr [rax+0x08]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Constants():System.Collections.Generic.IReadOnlyList`1[System.Object]:this]
       mov      gword ptr [rbp-0x3C0], rax
       mov      rax, gword ptr [rbp-0x3C0]
       mov      gword ptr [rbp-0x3C8], rax
       mov      rdi, gword ptr [rbp-0x3C8]
       mov      rsi, 0x78C06E5601B0
       call     CORINFO_HELP_CLASSPROFILE32
       mov      rax, gword ptr [rbp-0x3C8]
       mov      gword ptr [rbp-0x408], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ConstantIndex():int:this]
       mov      dword ptr [rbp-0x40C], eax
       mov      rdi, gword ptr [rbp-0x408]
       mov      esi, dword ptr [rbp-0x40C]
       mov      r11, 0x78C06BA72640
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       mov      rdi, rax
       call     [Lokad.Lython.Runtime.LythonRuntime:RuntimeValue(System.Object):System.Object]
       mov      gword ptr [rbp-0x418], rax
       mov      rdx, gword ptr [rbp-0x418]
       mov      rsi, bword ptr [rbp-0x40]
       mov      rdi, bword ptr [rbp-0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,System.Object):this]
       jmp      G_M000_IG114
 
G_M000_IG12:                ;; offset=0x031F
       mov      rdi, 0x78C06E5602B8
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LocalSlot():int:this]
       mov      dword ptr [rbp-0x3B4], eax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x420], rax
       mov      rdx, gword ptr [rbp-0x420]
       mov      esi, dword ptr [rbp-0x3B4]
       mov      rdi, bword ptr [rbp-0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:ReadLocal(int,Lokad.Lython.LythonSourceSpan):System.Object:this]
       mov      gword ptr [rbp-0x428], rax
       mov      rdx, gword ptr [rbp-0x428]
       mov      rsi, bword ptr [rbp-0x40]
       mov      rdi, bword ptr [rbp-0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,System.Object):this]
       jmp      G_M000_IG114
 
G_M000_IG13:                ;; offset=0x0387
       mov      rdi, 0x78C06E5602BC
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp-0x30]
       mov      rdi, gword ptr [rax+0x08]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Names():System.Collections.Generic.IReadOnlyList`1[System.String]:this]
       mov      gword ptr [rbp-0x3A8], rax
       mov      rax, gword ptr [rbp-0x3A8]
       mov      gword ptr [rbp-0x3D0], rax
       mov      rdi, gword ptr [rbp-0x3D0]
       mov      rsi, 0x78C06E5602C0
       call     CORINFO_HELP_CLASSPROFILE32
       mov      rax, gword ptr [rbp-0x3D0]
       mov      gword ptr [rbp-0x430], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_NameIndex():int:this]
       mov      dword ptr [rbp-0x434], eax
       mov      rdi, gword ptr [rbp-0x430]
       mov      esi, dword ptr [rbp-0x434]
       mov      r11, 0x78C06BA72638
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       mov      gword ptr [rbp-0x3B0], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x440], rax
       mov      rsi, gword ptr [rbp-0x440]
       mov      rax, bword ptr [rbp-0x30]
       mov      rdx, gword ptr [rax+0x18]
       mov      rdi, gword ptr [rbp-0x3B0]
       call     [Lokad.Lython.Runtime.LythonRuntime:ResolveExecutableGlobal(System.String,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):System.Object]
       mov      gword ptr [rbp-0x448], rax
       mov      rdx, gword ptr [rbp-0x448]
       mov      rsi, bword ptr [rbp-0x40]
       mov      rdi, bword ptr [rbp-0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,System.Object):this]
       jmp      G_M000_IG114
 
G_M000_IG14:                ;; offset=0x045E
       mov      rax, bword ptr [rbp-0x30]
       mov      r8, gword ptr [rax+0x18]
       mov      rax, bword ptr [rbp-0x30]
       mov      rdi, gword ptr [rax+0x08]
       mov      rax, bword ptr [rbp-0x30]
       mov      rsi, gword ptr [rax+0x10]
       mov      rax, bword ptr [rbp-0x30]
       mov      edx, dword ptr [rax+0x38]
       mov      rax, bword ptr [rbp-0x30]
       mov      ecx, dword ptr [rax+0x3C]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryExecuteClosureArithmetic(Lokad.Lython.Frontend.ExecutableCodeObject,System.Collections.Generic.IReadOnlyList`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableCell],int,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):bool]
       test     eax, eax
       je       SHORT G_M000_IG15
       mov      rdi, 0x78C06E5603C8
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp-0x30]
       add      dword ptr [rax+0x38], 2
       jmp      G_M000_IG114
 
G_M000_IG15:                ;; offset=0x04AA
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ClosureSlot():int:this]
       mov      dword ptr [rbp-0x44C], eax
       mov      esi, dword ptr [rbp-0x44C]
       lea      rdx, [rbp-0x48]
       mov      rdi, bword ptr [rbp-0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:TryCell(int,byref):bool:this]
       test     eax, eax
       je       SHORT G_M000_IG17
       mov      rdi, gword ptr [rbp-0x48]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableCell:get_Value():System.Object:this]
       mov      gword ptr [rbp-0x50], rax
       cmp      gword ptr [rbp-0x50], 0
       jne      SHORT G_M000_IG18
 
G_M000_IG16:                ;; offset=0x04E9
       mov      rdi, 0x78C06E5603CC
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG17:                ;; offset=0x04F8
       mov      rdi, 0x78C06E5603D0
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG108
 
G_M000_IG18:                ;; offset=0x050C
       mov      rdi, 0x78C06E5603D4
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, bword ptr [rbp-0x30]
       mov      rsi, bword ptr [rbp-0x40]
       mov      rdx, gword ptr [rbp-0x50]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,System.Object):this]
       jmp      G_M000_IG114
 
G_M000_IG19:                ;; offset=0x0532
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ClosureSlot():int:this]
       mov      dword ptr [rbp-0x450], eax
       mov      esi, dword ptr [rbp-0x450]
       lea      rdx, [rbp-0x58]
       mov      rdi, bword ptr [rbp-0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:TryCell(int,byref):bool:this]
       test     eax, eax
       je       SHORT G_M000_IG21
       mov      rdi, gword ptr [rbp-0x58]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableCell:get_CanStoreThroughOwner():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG22
 
G_M000_IG20:                ;; offset=0x056A
       mov      rdi, 0x78C06E5603D8
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG21:                ;; offset=0x0579
       mov      rdi, 0x78C06E5603DC
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG108
 
G_M000_IG22:                ;; offset=0x058D
       mov      rdi, 0x78C06E5603E0
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, bword ptr [rbp-0x30]
       mov      rsi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Take(byref):System.Object:this]
       mov      gword ptr [rbp-0x60], rax
       mov      rdi, gword ptr [rbp-0x58]
       mov      rsi, gword ptr [rbp-0x60]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableCell:set_Value(System.Object):this]
       jmp      G_M000_IG114
 
G_M000_IG23:                ;; offset=0x05C3
       mov      rdi, 0x78C06E5603E4
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp-0x30]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp-0x30]
       add      rax, 72
       mov      bword ptr [rbp-0x370], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LocalSlot():int:this]
       mov      dword ptr [rbp-0x374], eax
       mov      rax, bword ptr [rbp-0x370]
       mov      eax, dword ptr [rax+0x08]
       cmp      dword ptr [rbp-0x374], eax
       jae      G_M000_IG120
       mov      rax, bword ptr [rbp-0x370]
       mov      rax, bword ptr [rax]
       mov      ecx, dword ptr [rbp-0x374]
       lea      rax, bword ptr [rax+8*rcx]
       mov      bword ptr [rbp-0x380], rax
       mov      rdi, bword ptr [rbp-0x30]
       mov      rsi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Take(byref):System.Object:this]
       mov      rsi, rax
       mov      rdi, bword ptr [rbp-0x380]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       jmp      G_M000_IG114
 
G_M000_IG24:                ;; offset=0x064A
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x454], eax
       mov      esi, dword ptr [rbp-0x454]
       mov      rdi, bword ptr [rbp-0x30]
       xor      edx, edx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Read(int,int):System.Object:this]
       mov      gword ptr [rbp-0x70], rax
       mov      rax, bword ptr [rbp-0x30]
       mov      rdi, gword ptr [rax+0x08]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Names():System.Collections.Generic.IReadOnlyList`1[System.String]:this]
       mov      gword ptr [rbp-0x390], rax
       mov      rax, gword ptr [rbp-0x390]
       mov      gword ptr [rbp-0x3D8], rax
       mov      rdi, gword ptr [rbp-0x3D8]
       mov      rsi, 0x78C06E5603E8
       call     CORINFO_HELP_CLASSPROFILE32
       mov      rax, gword ptr [rbp-0x3D8]
       mov      gword ptr [rbp-0x460], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_NameIndex():int:this]
       mov      dword ptr [rbp-0x464], eax
       mov      rdi, gword ptr [rbp-0x460]
       mov      esi, dword ptr [rbp-0x464]
       mov      r11, 0x78C06BA72630
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       mov      gword ptr [rbp-0x78], rax
       mov      rsi, gword ptr [rbp-0x70]
       mov      rdi, 0x78C06E0B75A0
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       jne      SHORT G_M000_IG26
       mov      rsi, gword ptr [rbp-0x70]
       mov      rdi, 0x78C06E43DDA8
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       jne      SHORT G_M000_IG25
       xor      rax, rax
       mov      gword ptr [rbp-0x398], rax
       jmp      SHORT G_M000_IG27
 
G_M000_IG25:                ;; offset=0x0724
       mov      rdi, 0x78C06E5604F0
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, gword ptr [rbp-0x78]
       call     [Lokad.Lython.Runtime.LythonRuntime+DictMembers:GetMethod(System.String):Lokad.Lython.Runtime.LythonRuntime+ReceiverMethod]
       mov      gword ptr [rbp-0x398], rax
       jmp      SHORT G_M000_IG27
 
G_M000_IG26:                ;; offset=0x0746
       mov      rdi, 0x78C06E5604F4
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, gword ptr [rbp-0x78]
       call     [Lokad.Lython.Runtime.LythonRuntime+StringMembers:GetMethod(System.String):Lokad.Lython.Runtime.LythonRuntime+ReceiverMethod]
       mov      gword ptr [rbp-0x398], rax
 
G_M000_IG27:                ;; offset=0x0766
       mov      rax, gword ptr [rbp-0x398]
       mov      gword ptr [rbp-0x80], rax
       cmp      gword ptr [rbp-0x80], 0
       jne      SHORT G_M000_IG28
       mov      rdi, 0x78C06E5604F8
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG108
 
G_M000_IG28:                ;; offset=0x078C
       mov      rdi, 0x78C06E5604FC
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       mov      dword ptr [rbp-0x39C], eax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       inc      eax
       mov      dword ptr [rbp-0x468], eax
       mov      edx, dword ptr [rbp-0x468]
       mov      esi, dword ptr [rbp-0x39C]
       mov      rdi, bword ptr [rbp-0x30]
       mov      rcx, gword ptr [rbp-0x70]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Put(int,int,System.Object):this]
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       inc      eax
       mov      dword ptr [rbp-0x3A0], eax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      dword ptr [rbp-0x46C], eax
       mov      edx, dword ptr [rbp-0x46C]
       mov      esi, dword ptr [rbp-0x3A0]
       mov      rdi, bword ptr [rbp-0x30]
       mov      rcx, gword ptr [rbp-0x80]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Put(int,int,System.Object):this]
       jmp      G_M000_IG114
 
G_M000_IG29:                ;; offset=0x0818
       mov      rdi, bword ptr [rbp-0x30]
       mov      rsi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Call(byref):bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG30
       mov      rdi, 0x78C06E560500
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG108
 
G_M000_IG30:                ;; offset=0x083E
       mov      rdi, 0x78C06E560504
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG114
 
G_M000_IG31:                ;; offset=0x0852
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x470], eax
       mov      esi, dword ptr [rbp-0x470]
       mov      rdi, bword ptr [rbp-0x30]
       xor      edx, edx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Read(int,int):System.Object:this]
       mov      gword ptr [rbp-0x278], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_SecondInput():int:this]
       mov      dword ptr [rbp-0x474], eax
       mov      esi, dword ptr [rbp-0x474]
       mov      rdi, bword ptr [rbp-0x30]
       mov      edx, 1
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Read(int,int):System.Object:this]
       mov      gword ptr [rbp-0x88], rax
       mov      rsi, gword ptr [rbp-0x278]
       mov      rdi, 0x78C06E43DDA8
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      gword ptr [rbp-0x90], rax
       cmp      gword ptr [rbp-0x90], 0
       je       SHORT G_M000_IG33
       mov      rdi, gword ptr [rbp-0x90]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.PyDict:get_HasProtocolKeys():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG34
       mov      rsi, gword ptr [rbp-0x88]
       mov      rdi, 0x78C06E0B75A0
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      gword ptr [rbp-0x98], rax
       cmp      gword ptr [rbp-0x98], 0
       jne      SHORT G_M000_IG35
 
G_M000_IG32:                ;; offset=0x090A
       mov      rdi, 0x78C06E560508
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG33:                ;; offset=0x0919
       mov      rdi, 0x78C06E56050C
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG108
 
G_M000_IG34:                ;; offset=0x092D
       mov      rdi, 0x78C06E560510
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG33
 
G_M000_IG35:                ;; offset=0x093E
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LookupCacheIndex():int:this]
       test     eax, eax
       jl       G_M000_IG38
       mov      rdi, gword ptr [rbp-0x90]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.PyDict:get_HasSharedRecordKeys():bool:this]
       test     eax, eax
       je       G_M000_IG37
       mov      rax, bword ptr [rbp-0x30]
       mov      rax, gword ptr [rax]
       mov      gword ptr [rbp-0x280], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x480], rax
       mov      rsi, gword ptr [rbp-0x480]
       mov      rdi, gword ptr [rbp-0x280]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.PyExecutableFunction:GetLookupCaches(Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.LythonRuntime+ExecutableLookupCache[]:this]
       mov      gword ptr [rbp-0xA0], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LookupCacheIndex():int:this]
       mov      rcx, gword ptr [rbp-0xA0]
       cmp      eax, dword ptr [rcx+0x08]
       jae      G_M000_IG120
       mov      edx, eax
       imul     rdx, rdx, 24
       lea      rcx, bword ptr [rcx+rdx+0x10]
       mov      bword ptr [rbp-0x288], rcx
       mov      rax, bword ptr [rbp-0x30]
       mov      rax, gword ptr [rax+0x18]
       mov      gword ptr [rbp-0x290], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x488], rax
       mov      r8, gword ptr [rbp-0x488]
       lea      r9, [rbp-0xA8]
       mov      rsi, gword ptr [rbp-0x98]
       mov      rdx, bword ptr [rbp-0x288]
       mov      rcx, gword ptr [rbp-0x290]
       mov      rdi, gword ptr [rbp-0x90]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.PyDict:TryReadRecordValue(Lokad.Lython.Runtime.Text.PyString,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,byref):bool:this]
       test     eax, eax
       je       SHORT G_M000_IG36
       mov      rdi, 0x78C06E560514
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, bword ptr [rbp-0x30]
       mov      rsi, bword ptr [rbp-0x40]
       mov      rdx, gword ptr [rbp-0xA8]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,System.Object):this]
       jmp      G_M000_IG114
 
G_M000_IG36:                ;; offset=0x0A4E
       mov      rdi, 0x78C06E560518
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG38
 
G_M000_IG37:                ;; offset=0x0A5F
       mov      rdi, 0x78C06E56051C
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG38:                ;; offset=0x0A6E
       mov      rdi, gword ptr [rbp-0x90]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.PyDict:get_HasProtocolKeys():bool:this]
       test     eax, eax
       je       SHORT G_M000_IG39
       mov      rdi, 0x78C06E560520
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG108
 
G_M000_IG39:                ;; offset=0x0A95
       mov      rdi, 0x78C06E560524
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x490], rax
       mov      rdx, gword ptr [rbp-0x490]
       mov      rax, bword ptr [rbp-0x30]
       mov      rcx, gword ptr [rax+0x18]
       mov      rsi, gword ptr [rbp-0x98]
       mov      rdi, gword ptr [rbp-0x90]
       call     [Lokad.Lython.Runtime.LythonRuntime:ReadSubscriptValue(System.Object,System.Object,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):System.Object]
       mov      gword ptr [rbp-0x498], rax
       mov      rdx, gword ptr [rbp-0x498]
       mov      rsi, bword ptr [rbp-0x40]
       mov      rdi, bword ptr [rbp-0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,System.Object):this]
       jmp      G_M000_IG114
 
G_M000_IG40:                ;; offset=0x0AF9
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x49C], eax
       mov      esi, dword ptr [rbp-0x49C]
       mov      rdi, bword ptr [rbp-0x30]
       xor      edx, edx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Read(int,int):System.Object:this]
       mov      gword ptr [rbp-0xB0], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_UnaryOperator():int:this]
       test     eax, eax
       je       G_M000_IG43
       mov      rsi, gword ptr [rbp-0xB0]
       mov      rdi, 0x78C06E251F78
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       jne      SHORT G_M000_IG42
       mov      rsi, gword ptr [rbp-0xB0]
       mov      rdi, 0x78C06CCC6558
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       jne      SHORT G_M000_IG41
       mov      rdi, 0x78C06E560528
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rsi, gword ptr [rbp-0xB0]
       mov      rdi, 0x78C06CC935C8
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       sete     al
       movzx    rax, al
       mov      dword ptr [rbp-0x1D4], eax
       jmp      SHORT G_M000_IG44
 
G_M000_IG41:                ;; offset=0x0BA3
       mov      rdi, 0x78C06E56052C
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG42:                ;; offset=0x0BB2
       xor      eax, eax
       mov      dword ptr [rbp-0x1D4], eax
       jmp      SHORT G_M000_IG44
 
G_M000_IG43:                ;; offset=0x0BBC
       mov      rdi, 0x78C06E560530
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, gword ptr [rbp-0xB0]
       call     [Lokad.Lython.Runtime.LythonRuntime:CanUseNativeTruth(System.Object):bool]
       test     eax, eax
       sete     al
       movzx    rax, al
       mov      dword ptr [rbp-0x1D4], eax
 
G_M000_IG44:                ;; offset=0x0BE6
       cmp      dword ptr [rbp-0x1D4], 0
       je       SHORT G_M000_IG45
       mov      rdi, 0x78C06E560534
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG108
 
G_M000_IG45:                ;; offset=0x0C03
       mov      rdi, 0x78C06E560538
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_UnaryOperator():int:this]
       mov      dword ptr [rbp-0x1D8], eax
       mov      rax, bword ptr [rbp-0x30]
       mov      rax, gword ptr [rax+0x18]
       mov      gword ptr [rbp-0x1E0], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x4A8], rax
       mov      rcx, gword ptr [rbp-0x4A8]
       mov      rsi, gword ptr [rbp-0xB0]
       mov      rdx, gword ptr [rbp-0x1E0]
       mov      edi, dword ptr [rbp-0x1D8]
       call     [Lokad.Lython.Runtime.LythonRuntime:EvaluateExecutableUnary(int,System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):System.Object]
       mov      gword ptr [rbp-0x4B0], rax
       mov      rdx, gword ptr [rbp-0x4B0]
       mov      rsi, bword ptr [rbp-0x40]
       mov      rdi, bword ptr [rbp-0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,System.Object):this]
       jmp      G_M000_IG114
 
G_M000_IG46:                ;; offset=0x0C84
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x4B4], eax
       mov      esi, dword ptr [rbp-0x4B4]
       mov      rdi, bword ptr [rbp-0x30]
       xor      edx, edx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Read(int,int):System.Object:this]
       mov      gword ptr [rbp-0xB8], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_SecondInput():int:this]
       mov      dword ptr [rbp-0x4B8], eax
       mov      esi, dword ptr [rbp-0x4B8]
       mov      rdi, bword ptr [rbp-0x30]
       mov      edx, 1
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Read(int,int):System.Object:this]
       mov      gword ptr [rbp-0xC0], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_OpCode():int:this]
       cmp      eax, 48
       sete     al
       movzx    rax, al
       mov      dword ptr [rbp-0xC4], eax
       cmp      dword ptr [rbp-0xC4], 0
       jne      G_M000_IG49
       mov      rax, bword ptr [rbp-0x30]
       mov      rax, gword ptr [rax+0x08]
       mov      gword ptr [rbp-0x258], rax
       mov      rax, bword ptr [rbp-0x30]
       mov      rsi, bword ptr [rax+0x48]
       mov      rax, bword ptr [rbp-0x30]
       mov      rdx, qword ptr [rax+0x50]
       mov      rdi, 0x78C06DC0B4D0
       call     [System.Span`1[System.__Canon]:op_Implicit(System.Span`1[System.__Canon]):System.ReadOnlySpan`1[System.__Canon]]
       mov      bword ptr [rbp-0x250], rax
       mov      qword ptr [rbp-0x248], rdx
       mov      rax, bword ptr [rbp-0x30]
       mov      rax, gword ptr [rax+0x18]
       mov      gword ptr [rsp], rax
       lea      rax, [rbp-0xD0]
       mov      qword ptr [rsp+0x08], rax
       lea      rax, [rbp-0xD8]
       mov      qword ptr [rsp+0x10], rax
       mov      rsi, bword ptr [rbp-0x250]
       mov      rdx, qword ptr [rbp-0x248]
       mov      rax, bword ptr [rbp-0x30]
       mov      ecx, dword ptr [rax+0x38]
       mov      rdi, gword ptr [rbp-0x258]
       mov      r8, gword ptr [rbp-0xB8]
       mov      r9, gword ptr [rbp-0xC0]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryIntegerChain(Lokad.Lython.Frontend.ExecutableCodeObject,System.ReadOnlySpan`1[System.Object],int,System.Object,System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,byref):bool]
       test     eax, eax
       je       G_M000_IG48
       mov      rdi, 0x78C06E56053C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp-0x30]
       mov      ecx, dword ptr [rbp-0xD0]
       mov      dword ptr [rax+0x38], ecx
 
G_M000_IG47:                ;; offset=0x0DB4
       mov      rax, bword ptr [rbp-0x30]
       mov      rdi, gword ptr [rax+0x08]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Instructions():Lokad.Lython.Frontend.ExecutableInstruction[]:this]
       mov      ecx, dword ptr [rbp-0xD0]
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG120
       mov      edx, ecx
       imul     rdx, rdx, 32
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      bword ptr [rbp-0x270], rax
       mov      rdi, qword ptr [rbp-0xD8]
       call     [System.Numerics.BigInteger:op_Implicit(long):System.Numerics.BigInteger]
       mov      gword ptr [rbp-0x268], rax
       mov      qword ptr [rbp-0x260], rdx
       lea      rsi, [rbp-0x268]
       mov      rdi, 0x78C06E251F78
       call     [CORINFO_HELP_BOX]
       mov      gword ptr [rbp-0x4C0], rax
       mov      rdx, gword ptr [rbp-0x4C0]
       mov      rsi, bword ptr [rbp-0x270]
       mov      rdi, bword ptr [rbp-0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,System.Object):this]
       jmp      G_M000_IG114
 
G_M000_IG48:                ;; offset=0x0E3B
       mov      rdi, 0x78C06E560540
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG49:                ;; offset=0x0E4A
       cmp      dword ptr [rbp-0xC4], 0
       jne      G_M000_IG51
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_BinaryOperator():int:this]
       mov      dword ptr [rbp-0x234], eax
       mov      rax, bword ptr [rbp-0x30]
       mov      rax, gword ptr [rax+0x18]
       mov      gword ptr [rbp-0x240], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x4C8], rax
       mov      r8, gword ptr [rbp-0x4C8]
       lea      r9, [rbp-0xE0]
       mov      rsi, gword ptr [rbp-0xB8]
       mov      rdx, gword ptr [rbp-0xC0]
       mov      rcx, gword ptr [rbp-0x240]
       mov      edi, dword ptr [rbp-0x234]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryEvaluateScalarComparison(int,System.Object,System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,byref):bool]
       test     eax, eax
       je       SHORT G_M000_IG50
       mov      rdi, 0x78C06E560544
       call     CORINFO_HELP_COUNTPROFILE32
       movzx    rdi, byte  ptr [rbp-0xE0]
       call     [Lokad.Lython.Runtime.LythonRuntime:RuntimeValue(bool):System.Object]
       mov      gword ptr [rbp-0x4D0], rax
       mov      rdx, gword ptr [rbp-0x4D0]
       mov      rsi, bword ptr [rbp-0x40]
       mov      rdi, bword ptr [rbp-0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,System.Object):this]
       jmp      G_M000_IG114
 
G_M000_IG50:                ;; offset=0x0EF8
       mov      rdi, 0x78C06E560548
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG51:                ;; offset=0x0F07
       cmp      dword ptr [rbp-0xC4], 0
       jne      SHORT G_M000_IG52
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_BinaryOperator():int:this]
       mov      dword ptr [rbp-0x1E4], eax
       jmp      SHORT G_M000_IG53
 
G_M000_IG52:                ;; offset=0x0F22
       mov      rdi, 0x78C06E56054C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_AugmentedOperator():int:this]
       mov      edi, eax
       call     [Lokad.Lython.Runtime.LythonRuntime:AugmentedBinaryOperator(int):int]
       mov      dword ptr [rbp-0x1E4], eax
 
G_M000_IG53:                ;; offset=0x0F49
       mov      edi, dword ptr [rbp-0x1E4]
       mov      rsi, gword ptr [rbp-0xB8]
       mov      rdx, gword ptr [rbp-0xC0]
       call     [Lokad.Lython.Runtime.LythonRuntime:CanUseNativeBinary(int,System.Object,System.Object):bool]
       test     eax, eax
       jne      SHORT G_M000_IG54
       mov      rdi, 0x78C06E560550
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG108
 
G_M000_IG54:                ;; offset=0x0F7B
       cmp      dword ptr [rbp-0xC4], 0
       je       G_M000_IG63
       mov      rsi, gword ptr [rbp-0xB8]
       mov      rdi, 0x78C06E251F78
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       jne      SHORT G_M000_IG56
       mov      rsi, gword ptr [rbp-0xB8]
       mov      rdi, 0x78C06CCC6558
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       jne      G_M000_IG62
       mov      rsi, gword ptr [rbp-0xB8]
       mov      rdi, 0x78C06CC935C8
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       je       G_M000_IG61
 
G_M000_IG55:                ;; offset=0x0FE4
       mov      rdi, 0x78C06E560554
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG56:                ;; offset=0x0FF3
       mov      rsi, gword ptr [rbp-0xC0]
       mov      rdi, 0x78C06E251F78
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       jne      SHORT G_M000_IG60
       mov      rsi, gword ptr [rbp-0xC0]
       mov      rdi, 0x78C06CCC6558
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       jne      SHORT G_M000_IG59
       mov      rsi, gword ptr [rbp-0xC0]
       mov      rdi, 0x78C06CC935C8
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       jne      SHORT G_M000_IG58
 
G_M000_IG57:                ;; offset=0x1047
       mov      rdi, 0x78C06E560558
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG108
 
G_M000_IG58:                ;; offset=0x105B
       mov      rdi, 0x78C06E56055C
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG63
 
G_M000_IG59:                ;; offset=0x106C
       mov      rdi, 0x78C06E560560
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG63
 
G_M000_IG60:                ;; offset=0x107D
       mov      rdi, 0x78C06E560564
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG63
 
G_M000_IG61:                ;; offset=0x108E
       mov      rdi, 0x78C06E560568
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG57
 
G_M000_IG62:                ;; offset=0x109F
       mov      rdi, 0x78C06E56056C
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG56
 
G_M000_IG63:                ;; offset=0x10B3
       mov      rax, bword ptr [rbp-0x30]
       mov      bword ptr [rbp-0x1F0], rax
       mov      rax, bword ptr [rbp-0x40]
       mov      bword ptr [rbp-0x1F8], rax
       cmp      dword ptr [rbp-0xC4], 0
       jne      G_M000_IG64
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_BinaryOperator():int:this]
       mov      dword ptr [rbp-0x224], eax
       mov      rax, bword ptr [rbp-0x30]
       mov      rax, gword ptr [rax+0x18]
       mov      gword ptr [rbp-0x230], rax
       mov      rax, bword ptr [rbp-0x1F0]
       mov      bword ptr [rbp-0x210], rax
       mov      rax, bword ptr [rbp-0x1F8]
       mov      bword ptr [rbp-0x218], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x4D8], rax
       mov      r8, gword ptr [rbp-0x4D8]
       mov      rsi, gword ptr [rbp-0xB8]
       mov      rdx, gword ptr [rbp-0xC0]
       mov      rcx, gword ptr [rbp-0x230]
       mov      edi, dword ptr [rbp-0x224]
       call     [Lokad.Lython.Runtime.LythonRuntime:EvaluateBinaryOperator(int,System.Object,System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):System.Object]
       mov      gword ptr [rbp-0x220], rax
       jmp      G_M000_IG65
 
G_M000_IG64:                ;; offset=0x1156
       mov      rdi, 0x78C06E560570
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_AugmentedOperator():int:this]
       mov      dword ptr [rbp-0x1FC], eax
       mov      rax, bword ptr [rbp-0x30]
       mov      rax, gword ptr [rax+0x18]
       mov      gword ptr [rbp-0x208], rax
       mov      rax, bword ptr [rbp-0x1F0]
       mov      bword ptr [rbp-0x210], rax
       mov      rax, bword ptr [rbp-0x1F8]
       mov      bword ptr [rbp-0x218], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x4E0], rax
       mov      r8, gword ptr [rbp-0x4E0]
       mov      rsi, gword ptr [rbp-0xC0]
       mov      edx, dword ptr [rbp-0x1FC]
       mov      rcx, gword ptr [rbp-0x208]
       mov      rdi, gword ptr [rbp-0xB8]
       call     [Lokad.Lython.Runtime.LythonRuntime:EvaluateAugmentedBuiltin(System.Object,System.Object,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):System.Object]
       mov      gword ptr [rbp-0x220], rax
 
G_M000_IG65:                ;; offset=0x11E0
       mov      rdi, 0x78C06E560574
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, bword ptr [rbp-0x210]
       mov      rsi, bword ptr [rbp-0x218]
       mov      rdx, gword ptr [rbp-0x220]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,System.Object):this]
       jmp      G_M000_IG114
 
G_M000_IG66:                ;; offset=0x120F
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x4E4], eax
       mov      esi, dword ptr [rbp-0x4E4]
       mov      rdi, bword ptr [rbp-0x30]
       xor      edx, edx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Read(int,int):System.Object:this]
       mov      gword ptr [rbp-0xE8], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_SecondInput():int:this]
       mov      dword ptr [rbp-0x4E8], eax
       mov      esi, dword ptr [rbp-0x4E8]
       mov      rdi, bword ptr [rbp-0x30]
       mov      edx, 1
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Read(int,int):System.Object:this]
       mov      gword ptr [rbp-0xF0], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_BinaryOperator():int:this]
       mov      dword ptr [rbp-0x1B8], eax
       mov      rax, bword ptr [rbp-0x30]
       mov      rax, gword ptr [rax+0x18]
       mov      gword ptr [rbp-0x1C0], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x4F0], rax
       mov      r8, gword ptr [rbp-0x4F0]
       lea      r9, [rbp-0xF8]
       mov      rsi, gword ptr [rbp-0xE8]
       mov      rdx, gword ptr [rbp-0xF0]
       mov      rcx, gword ptr [rbp-0x1C0]
       mov      edi, dword ptr [rbp-0x1B8]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryEvaluateScalarComparison(int,System.Object,System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,byref):bool]
       test     eax, eax
       jne      SHORT G_M000_IG67
       mov      rdi, 0x78C06E560578
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG108
 
G_M000_IG67:                ;; offset=0x12DB
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      dword ptr [rbp-0x4F4], eax
       mov      esi, dword ptr [rbp-0x4F4]
       mov      rdi, bword ptr [rbp-0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Trim(int):this]
       mov      rax, bword ptr [rbp-0x30]
       mov      rax, gword ptr [rax+0x18]
       mov      gword ptr [rbp-0x1C8], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x500], rax
       mov      rsi, gword ptr [rbp-0x500]
       mov      rdi, gword ptr [rbp-0x1C8]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CheckExecution(Lokad.Lython.LythonSourceSpan):this]
       movzx    rax, byte  ptr [rbp-0xF8]
       test     eax, eax
       jne      SHORT G_M000_IG68
       mov      rdi, 0x78C06E56057C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_TargetIndex():int:this]
       mov      rcx, bword ptr [rbp-0x30]
       mov      dword ptr [rcx+0x38], eax
       jmp      G_M000_IG115
 
G_M000_IG68:                ;; offset=0x1361
       mov      rdi, 0x78C06E560580
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG114
 
G_M000_IG69:                ;; offset=0x1375
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x504], eax
       mov      esi, dword ptr [rbp-0x504]
       mov      rdi, bword ptr [rbp-0x30]
       xor      edx, edx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Read(int,int):System.Object:this]
       mov      gword ptr [rbp-0x100], rax
       mov      rdi, gword ptr [rbp-0x100]
       call     [Lokad.Lython.Runtime.LythonRuntime:CanUseNativeTruth(System.Object):bool]
       test     eax, eax
       jne      SHORT G_M000_IG70
       mov      rdi, 0x78C06E560584
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG108
 
G_M000_IG70:                ;; offset=0x13C3
       mov      rdi, bword ptr [rbp-0x30]
       mov      rsi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Take(byref):System.Object:this]
       mov      rax, bword ptr [rbp-0x30]
       mov      rax, gword ptr [rax+0x18]
       mov      gword ptr [rbp-0x1D0], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x510], rax
       mov      rdx, gword ptr [rbp-0x510]
       mov      rsi, gword ptr [rbp-0x1D0]
       mov      rdi, gword ptr [rbp-0x100]
       call     [Lokad.Lython.Runtime.LythonRuntime:IsTruthy(System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):bool]
       test     eax, eax
       jne      SHORT G_M000_IG71
       mov      rdi, 0x78C06E560588
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_TargetIndex():int:this]
       mov      rcx, bword ptr [rbp-0x30]
       mov      dword ptr [rcx+0x38], eax
       jmp      G_M000_IG115
 
G_M000_IG71:                ;; offset=0x1435
       mov      rdi, 0x78C06E56058C
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG114
 
G_M000_IG72:                ;; offset=0x1449
       mov      rdi, 0x78C06E560590
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_TargetIndex():int:this]
       mov      rcx, bword ptr [rbp-0x30]
       mov      dword ptr [rcx+0x38], eax
       jmp      G_M000_IG115
 
G_M000_IG73:                ;; offset=0x146E
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_DiscardIterator():bool:this]
       test     eax, eax
       je       SHORT G_M000_IG74
       mov      rdi, 0x78C06E560594
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp-0x30]
       mov      eax, dword ptr [rax+0x3C]
       lea      esi, [rax-0x01]
       mov      rdi, bword ptr [rbp-0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Trim(int):this]
 
G_M000_IG74:                ;; offset=0x149F
       mov      rdi, 0x78C06E560598
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_TargetIndex():int:this]
       mov      rcx, bword ptr [rbp-0x30]
       mov      dword ptr [rcx+0x38], eax
       jmp      G_M000_IG115
 
G_M000_IG75:                ;; offset=0x14C4
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x514], eax
       mov      esi, dword ptr [rbp-0x514]
       mov      rdi, bword ptr [rbp-0x30]
       xor      edx, edx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Read(int,int):System.Object:this]
       mov      gword ptr [rbp-0x108], rax
       mov      rsi, gword ptr [rbp-0x108]
       mov      rdi, 0x78C06E53ACD8
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       je       SHORT G_M000_IG76
       mov      rdi, 0x78C06E56059C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, bword ptr [rbp-0x30]
       mov      rsi, bword ptr [rbp-0x40]
       mov      rdx, gword ptr [rbp-0x108]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,System.Object):this]
       jmp      G_M000_IG114
 
G_M000_IG76:                ;; offset=0x1532
       mov      rsi, gword ptr [rbp-0x108]
       mov      rdi, 0x78C06E442B88
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       jne      G_M000_IG78
       mov      rsi, gword ptr [rbp-0x108]
       mov      rdi, 0x78C06E0B8030
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       jne      G_M000_IG83
       mov      rsi, gword ptr [rbp-0x108]
       mov      rdi, 0x78C06E526510
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       jne      G_M000_IG82
       mov      rsi, gword ptr [rbp-0x108]
       mov      rdi, 0x78C06E0BB8C0
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       jne      G_M000_IG81
       mov      rsi, gword ptr [rbp-0x108]
       mov      rdi, 0x78C06E0B75A0
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       jne      SHORT G_M000_IG80
       mov      rsi, gword ptr [rbp-0x108]
       mov      rdi, 0x78C06E43DDA8
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       jne      SHORT G_M000_IG79
       mov      rsi, gword ptr [rbp-0x108]
       mov      rdi, 0x78C06E4F0FE8
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       je       SHORT G_M000_IG84
 
G_M000_IG77:                ;; offset=0x1606
       mov      rdi, 0x78C06E5605A0
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG78:                ;; offset=0x1615
       mov      dword ptr [rbp-0x10C], 1
       jmp      SHORT G_M000_IG85
 
G_M000_IG79:                ;; offset=0x1621
       mov      rdi, 0x78C06E5605A4
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG78
 
G_M000_IG80:                ;; offset=0x1632
       mov      rdi, 0x78C06E5605A8
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG78
 
G_M000_IG81:                ;; offset=0x1643
       mov      rdi, 0x78C06E5605AC
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG78
 
G_M000_IG82:                ;; offset=0x1654
       mov      rdi, 0x78C06E5605B0
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG78
 
G_M000_IG83:                ;; offset=0x1665
       mov      rdi, 0x78C06E5605B4
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG78
 
G_M000_IG84:                ;; offset=0x1676
       mov      rdi, 0x78C06E5605B8
       call     CORINFO_HELP_COUNTPROFILE32
       xor      eax, eax
       mov      dword ptr [rbp-0x10C], eax
 
G_M000_IG85:                ;; offset=0x168D
       cmp      dword ptr [rbp-0x10C], 0
       je       SHORT G_M000_IG86
       mov      rdi, 0x78C06E5605BC
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x520], rax
       mov      rsi, gword ptr [rbp-0x520]
       mov      rax, bword ptr [rbp-0x30]
       mov      rdx, gword ptr [rax+0x18]
       mov      rdi, gword ptr [rbp-0x108]
       call     [Lokad.Lython.Runtime.PyIteration+Cursor:Create(System.Object,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):Lokad.Lython.Runtime.PyIteration+Cursor]
       mov      gword ptr [rbp-0x528], rax
       mov      rdx, gword ptr [rbp-0x528]
       mov      rsi, bword ptr [rbp-0x40]
       mov      rdi, bword ptr [rbp-0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,System.Object):this]
       jmp      G_M000_IG114
 
G_M000_IG86:                ;; offset=0x16F3
       mov      rdi, 0x78C06E5605C0
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG108
 
G_M000_IG87:                ;; offset=0x1707
       mov      rax, bword ptr [rbp-0x30]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp-0x30]
       add      rax, 72
       mov      bword ptr [rbp-0x298], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x29C], eax
       mov      rax, bword ptr [rbp-0x298]
       mov      eax, dword ptr [rax+0x08]
       cmp      dword ptr [rbp-0x29C], eax
       jae      G_M000_IG120
       mov      rax, bword ptr [rbp-0x298]
       mov      rax, bword ptr [rax]
       mov      ecx, dword ptr [rbp-0x29C]
       mov      rax, gword ptr [rax+8*rcx]
       mov      gword ptr [rbp-0x118], rax
       mov      rsi, gword ptr [rbp-0x118]
       mov      rdi, 0x78C06E53ACD8
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      gword ptr [rbp-0x130], rax
       cmp      gword ptr [rbp-0x130], 0
       jne      G_M000_IG93
       mov      rsi, gword ptr [rbp-0x118]
       mov      rdi, 0x78C06E43FE48
       call     [CORINFO_HELP_CHKCASTCLASS]
       mov      gword ptr [rbp-0x530], rax
       mov      rdi, gword ptr [rbp-0x530]
       lea      rsi, [rbp-0x138]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.PyIteration+Cursor:TryMoveNext(byref):bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG90
       call     [Lokad.Lython.Runtime.PyIterationResult:get_End():Lokad.Lython.Runtime.PyIterationResult]
       mov      gword ptr [rbp-0x2E0], rax
       mov      qword ptr [rbp-0x2D8], rdx
 
G_M000_IG88:                ;; offset=0x17D5
       vmovdqu32 xmm0, xmmword ptr [rbp-0x2E0]
       vmovdqu32 xmmword ptr [rbp-0x2C0], xmm0
 
G_M000_IG89:                ;; offset=0x17E3
       jmp      SHORT G_M000_IG95
 
G_M000_IG90:                ;; offset=0x17E5
       mov      rdi, 0x78C06E5605C4
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, gword ptr [rbp-0x138]
       call     [Lokad.Lython.Runtime.PyIterationResult:Yield(System.Object):Lokad.Lython.Runtime.PyIterationResult]
       mov      gword ptr [rbp-0x2D0], rax
       mov      qword ptr [rbp-0x2C8], rdx
 
G_M000_IG91:                ;; offset=0x180F
       vmovdqu32 xmm0, xmmword ptr [rbp-0x2D0]
       vmovdqu32 xmmword ptr [rbp-0x2C0], xmm0
 
G_M000_IG92:                ;; offset=0x181D
       jmp      SHORT G_M000_IG95
 
G_M000_IG93:                ;; offset=0x181F
       mov      rdi, 0x78C06E5605C8
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, gword ptr [rbp-0x130]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.Text.PyStringOps+CasedWhitespaceIteration:MoveNext():Lokad.Lython.Runtime.PyIterationResult:this]
       mov      gword ptr [rbp-0x2B0], rax
       mov      qword ptr [rbp-0x2A8], rdx
 
G_M000_IG94:                ;; offset=0x184B
       vmovdqu32 xmm0, xmmword ptr [rbp-0x2B0]
       vmovdqu32 xmmword ptr [rbp-0x2C0], xmm0
 
G_M000_IG95:                ;; offset=0x1859
       vmovdqu32 xmm0, xmmword ptr [rbp-0x2C0]
       vmovdqu  xmmword ptr [rbp-0x128], xmm0
 
G_M000_IG96:                ;; offset=0x1868
       lea      rdi, [rbp-0x128]
       call     [Lokad.Lython.Runtime.PyIterationResult:get_HasValue():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG97
       mov      rdi, 0x78C06E5605CC
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x534], eax
       mov      esi, dword ptr [rbp-0x534]
       mov      rdi, bword ptr [rbp-0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Trim(int):this]
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_TargetIndex():int:this]
       mov      rcx, bword ptr [rbp-0x30]
       mov      dword ptr [rcx+0x38], eax
       jmp      G_M000_IG115
 
G_M000_IG97:                ;; offset=0x18BE
       mov      rdi, 0x78C06E5605D0
       call     CORINFO_HELP_COUNTPROFILE32
       lea      rdi, [rbp-0x128]
       call     [Lokad.Lython.Runtime.PyIterationResult:get_Value():System.Object:this]
       mov      gword ptr [rbp-0x540], rax
       mov      rdx, gword ptr [rbp-0x540]
       mov      rsi, bword ptr [rbp-0x40]
       mov      rdi, bword ptr [rbp-0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,System.Object):this]
       jmp      G_M000_IG114
 
G_M000_IG98:                ;; offset=0x18FB
       mov      rdi, bword ptr [rbp-0x30]
       mov      rsi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:TryReturnUnpackedTuple(byref):bool:this]
       test     eax, eax
       je       SHORT G_M000_IG99
       mov      rdi, 0x78C06E5605D4
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG118
 
G_M000_IG99:                ;; offset=0x1921
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ItemCount():int:this]
       test     eax, eax
       je       G_M000_IG100
       mov      rax, bword ptr [rbp-0x30]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp-0x30]
       add      rax, 72
       mov      bword ptr [rbp-0x2F0], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x2F4], eax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ItemCount():int:this]
       mov      dword ptr [rbp-0x544], eax
       mov      ecx, dword ptr [rbp-0x544]
       mov      rdi, bword ptr [rbp-0x2F0]
       mov      edx, dword ptr [rbp-0x2F4]
       mov      rsi, 0x78C06DC0B4D0
       call     [System.Span`1[System.__Canon]:Slice(int,int):System.Span`1[System.__Canon]:this]
       mov      bword ptr [rbp-0x308], rax
       mov      qword ptr [rbp-0x300], rdx
       mov      rsi, bword ptr [rbp-0x308]
       mov      rdx, qword ptr [rbp-0x300]
       mov      rdi, 0x78C06DC0B4D0
       call     [System.Span`1[System.__Canon]:op_Implicit(System.Span`1[System.__Canon]):System.ReadOnlySpan`1[System.__Canon]]
       mov      bword ptr [rbp-0x318], rax
       mov      qword ptr [rbp-0x310], rdx
       mov      rax, bword ptr [rbp-0x30]
       mov      rdi, gword ptr [rax+0x18]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:get_MemoryGovernor():Lokad.Lython.Runtime.MemoryGovernor:this]
       mov      gword ptr [rbp-0x320], rax
       mov      rdi, 0x78C06E0B8030
       call     CORINFO_HELP_NEWSFAST
       mov      gword ptr [rbp-0x328], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x550], rax
       mov      r8, gword ptr [rbp-0x550]
       mov      rax, bword ptr [rbp-0x30]
       mov      r9, gword ptr [rax+0x18]
       mov      rsi, bword ptr [rbp-0x318]
       mov      rdx, qword ptr [rbp-0x310]
       mov      rcx, gword ptr [rbp-0x320]
       mov      rdi, gword ptr [rbp-0x328]
       call     [Lokad.Lython.Runtime.PyTuple:.ctor(System.ReadOnlySpan`1[System.Object],Lokad.Lython.Runtime.MemoryGovernor,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):this]
       mov      rax, gword ptr [rbp-0x328]
       mov      gword ptr [rbp-0x2E8], rax
       jmp      SHORT G_M000_IG101
 
G_M000_IG100:                ;; offset=0x1A44
       mov      rdi, 0x78C06E5605D8
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, 0x78B88D801950
       mov      rax, gword ptr [rax]
       mov      gword ptr [rbp-0x2E8], rax
 
G_M000_IG101:                ;; offset=0x1A67
       mov      rdi, 0x78C06E5605DC
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, gword ptr [rbp-0x2E8]
       mov      gword ptr [rbp-0x140], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x554], eax
       mov      esi, dword ptr [rbp-0x554]
       mov      rdi, bword ptr [rbp-0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Trim(int):this]
       mov      rdi, bword ptr [rbp-0x30]
       mov      rsi, bword ptr [rbp-0x40]
       mov      rdx, gword ptr [rbp-0x140]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,System.Object):this]
       jmp      G_M000_IG114
 
G_M000_IG102:                ;; offset=0x1ABE
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ItemCount():int:this]
       mov      edi, eax
       call     [Lokad.Lython.Runtime.PyList:EstimateCapacityBytes(int):long]
       mov      qword ptr [rbp-0x148], rax
       mov      rax, bword ptr [rbp-0x30]
       mov      rdi, gword ptr [rax+0x18]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:get_MemoryGovernor():Lokad.Lython.Runtime.MemoryGovernor:this]
       mov      gword ptr [rbp-0x330], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x560], rax
       mov      rdx, gword ptr [rbp-0x560]
       mov      rsi, qword ptr [rbp-0x148]
       mov      rdi, gword ptr [rbp-0x330]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.MemoryGovernor:ReserveTemporary(long,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.MemoryGovernor+TemporaryMemoryReservation:this]
       mov      gword ptr [rbp-0x150], rax
 
G_M000_IG103:                ;; offset=0x1B23
       mov      rdi, 0x78C06E5605E0
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp-0x30]
       mov      rax, gword ptr [rax+0x18]
       mov      gword ptr [rbp-0x338], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x568], rax
       mov      rsi, gword ptr [rbp-0x568]
       mov      rdi, gword ptr [rbp-0x338]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CheckExecution(Lokad.Lython.LythonSourceSpan):this]
       mov      rax, bword ptr [rbp-0x30]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp-0x30]
       add      rax, 72
       mov      bword ptr [rbp-0x340], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x344], eax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ItemCount():int:this]
       mov      dword ptr [rbp-0x56C], eax
       mov      ecx, dword ptr [rbp-0x56C]
       mov      rdi, bword ptr [rbp-0x340]
       mov      edx, dword ptr [rbp-0x344]
       mov      rsi, 0x78C06DC0B4D0
       call     [System.Span`1[System.__Canon]:Slice(int,int):System.Span`1[System.__Canon]:this]
       mov      bword ptr [rbp-0x358], rax
       mov      qword ptr [rbp-0x350], rdx
 
G_M000_IG104:                ;; offset=0x1BCE
       vmovdqu  xmm0, xmmword ptr [rbp-0x358]
       vmovdqu  xmmword ptr [rbp-0x168], xmm0
 
G_M000_IG105:                ;; offset=0x1BDE
       lea      rdi, [rbp-0x168]
       mov      rsi, 0x78C06DC0B4D0
       call     [System.Span`1[System.__Canon]:ToArray():System.__Canon[]:this]
       mov      gword ptr [rbp-0x158], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x570], eax
       mov      esi, dword ptr [rbp-0x570]
       mov      rdi, bword ptr [rbp-0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Trim(int):this]
       mov      rdi, gword ptr [rbp-0x150]
       mov      rsi, qword ptr [rbp-0x148]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.MemoryGovernor+TemporaryMemoryReservation:Commit(long):this]
       mov      rax, bword ptr [rbp-0x30]
       mov      rdi, gword ptr [rax+0x18]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:get_MemoryGovernor():Lokad.Lython.Runtime.MemoryGovernor:this]
       mov      gword ptr [rbp-0x360], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x578], rax
       mov      rdx, gword ptr [rbp-0x578]
       mov      rsi, gword ptr [rbp-0x360]
       mov      rdi, gword ptr [rbp-0x158]
       call     [Lokad.Lython.Runtime.PyList:FromTransferredArray(System.Object[],Lokad.Lython.Runtime.MemoryGovernor,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.PyList]
       mov      gword ptr [rbp-0x580], rax
       mov      rdx, gword ptr [rbp-0x580]
       mov      rsi, bword ptr [rbp-0x40]
       mov      rdi, bword ptr [rbp-0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,System.Object):this]
       nop      
 
G_M000_IG106:                ;; offset=0x1C92
       call     G_M000_IG121
       jmp      G_M000_IG114
 
G_M000_IG107:                ;; offset=0x1C9C
       mov      rdi, bword ptr [rbp-0x30]
       mov      rsi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Format(byref):bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG110
       mov      rdi, 0x78C06E5606F4
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG108:                ;; offset=0x1CBD
       xor      eax, eax
 
G_M000_IG109:                ;; offset=0x1CBF
       add      rsp, 0x5D0
       pop      rbp
       ret      
 
G_M000_IG110:                ;; offset=0x1CC8
       mov      rdi, 0x78C06E5606F8
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG114
 
G_M000_IG111:                ;; offset=0x1CDC
       mov      rdi, 0x78C06E5606FC
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       inc      eax
       mov      dword ptr [rbp-0x364], eax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      dword ptr [rbp-0x368], eax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x58C], eax
       mov      esi, dword ptr [rbp-0x58C]
       mov      rdi, bword ptr [rbp-0x30]
       xor      edx, edx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Read(int,int):System.Object:this]
       mov      gword ptr [rbp-0x598], rax
       mov      rcx, gword ptr [rbp-0x598]
       mov      esi, dword ptr [rbp-0x364]
       mov      edx, dword ptr [rbp-0x368]
       mov      rdi, bword ptr [rbp-0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Put(int,int,System.Object):this]
       jmp      G_M000_IG114
 
G_M000_IG112:                ;; offset=0x1D58
       mov      rdi, 0x78C06E560700
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x59C], eax
       mov      esi, dword ptr [rbp-0x59C]
       mov      rdi, bword ptr [rbp-0x30]
       xor      edx, edx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Read(int,int):System.Object:this]
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      dword ptr [rbp-0x5A0], eax
       mov      esi, dword ptr [rbp-0x5A0]
       mov      rdi, bword ptr [rbp-0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Trim(int):this]
       jmp      G_M000_IG114
 
G_M000_IG113:                ;; offset=0x1DAE
       lea      rdi, [rbp-0x190]
       mov      esi, 26
       mov      edx, 1
       call     [System.Runtime.CompilerServices.DefaultInterpolatedStringHandler:.ctor(int,int):this]
       lea      rdi, [rbp-0x190]
       mov      rsi, 0x78C06845BB98
       call     [System.Runtime.CompilerServices.DefaultInterpolatedStringHandler:AppendLiteral(System.String):this]
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_OpCode():int:this]
       mov      dword ptr [rbp-0x5A4], eax
       mov      esi, dword ptr [rbp-0x5A4]
       lea      rdi, [rbp-0x190]
       call     [System.Runtime.CompilerServices.DefaultInterpolatedStringHandler:AppendFormatted[int](int):this]
       mov      rdi, 0x78C06D3A7A68
       call     CORINFO_HELP_NEWSFAST
       mov      gword ptr [rbp-0x388], rax
       lea      rdi, [rbp-0x190]
       call     [System.Runtime.CompilerServices.DefaultInterpolatedStringHandler:ToStringAndClear():System.String:this]
       mov      gword ptr [rbp-0x5B0], rax
       mov      rsi, gword ptr [rbp-0x5B0]
       mov      rdi, gword ptr [rbp-0x388]
       call     [System.InvalidOperationException:.ctor(System.String):this]
       mov      rdi, gword ptr [rbp-0x388]
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG114:                ;; offset=0x1E4A
       mov      rdi, 0x78C06E560704
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp-0x30]
       inc      dword ptr [rax+0x38]
 
G_M000_IG115:                ;; offset=0x1E60
       mov      eax, dword ptr [rbp-0x3E4]
       dec      eax
       mov      dword ptr [rbp-0x3E4], eax
       cmp      dword ptr [rbp-0x3E4], 0
       jg       SHORT G_M000_IG117
 
G_M000_IG116:                ;; offset=0x1E77
       lea      rdi, [rbp-0x3E4]
       mov      esi, 0x96A
       call     CORINFO_HELP_PATCHPOINT
       jmp      rax
 
G_M000_IG117:                ;; offset=0x1E8A
       mov      rax, bword ptr [rbp-0x30]
       mov      eax, dword ptr [rax+0x38]
       mov      dword ptr [rbp-0x194], eax
       mov      rax, bword ptr [rbp-0x30]
       mov      rdi, gword ptr [rax+0x08]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Instructions():Lokad.Lython.Frontend.ExecutableInstruction[]:this]
       mov      eax, dword ptr [rax+0x08]
       cmp      eax, dword ptr [rbp-0x194]
       jg       G_M000_IG03
       mov      rdi, 0x78C06E560708
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG118:                ;; offset=0x1EC5
       mov      eax, 1
 
G_M000_IG119:                ;; offset=0x1ECA
       add      rsp, 0x5D0
       pop      rbp
       ret      
 
G_M000_IG120:                ;; offset=0x1ED3
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG121:                ;; offset=0x1ED9
       sub      rsp, 24
 
G_M000_IG122:                ;; offset=0x1EDD
       cmp      gword ptr [rbp-0x150], 0
       je       SHORT G_M000_IG123
       mov      rdi, 0x78C06E5605E4
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, gword ptr [rbp-0x150]
       mov      gword ptr [rbp-0x3E0], rax
       mov      rdi, gword ptr [rbp-0x3E0]
       mov      rsi, 0x78C06E5605E8
       call     CORINFO_HELP_CLASSPROFILE32
       mov      rax, gword ptr [rbp-0x3E0]
       mov      gword ptr [rbp-0x588], rax
       mov      rdi, gword ptr [rbp-0x588]
       mov      r11, 0x78C06BA72628
       call     [r11]System.IDisposable:Dispose():this
 
G_M000_IG123:                ;; offset=0x1F3C
       mov      rdi, 0x78C06E5606F0
       call     CORINFO_HELP_COUNTPROFILE32
       nop      
 
G_M000_IG124:                ;; offset=0x1F4C
       add      rsp, 24
       ret      
 
RWD00  	dd	0000023Fh ; case G_M000_IG11
       	dd	000002DCh ; case G_M000_IG12
       	dd	0000041Bh ; case G_M000_IG14
       	dd	00000344h ; case G_M000_IG13
RWD16  	dd	00000607h ; case G_M000_IG24
       	dd	00001D6Bh ; case G_M000_IG113
       	dd	00000580h ; case G_M000_IG23
       	dd	000004EFh ; case G_M000_IG19
       	dd	00001D6Bh ; case G_M000_IG113
       	dd	00001D6Bh ; case G_M000_IG113
       	dd	00001C99h ; case G_M000_IG111
       	dd	00001D15h ; case G_M000_IG112
       	dd	00001A7Bh ; case G_M000_IG102
       	dd	000018B8h ; case G_M000_IG98
       	dd	00001D6Bh ; case G_M000_IG113
       	dd	00001D6Bh ; case G_M000_IG113
       	dd	00001D6Bh ; case G_M000_IG113
       	dd	00001D6Bh ; case G_M000_IG113
       	dd	00001D6Bh ; case G_M000_IG113
       	dd	00001D6Bh ; case G_M000_IG113
       	dd	00001481h ; case G_M000_IG75
       	dd	000016C4h ; case G_M000_IG87
       	dd	000007D5h ; case G_M000_IG29
       	dd	0000080Fh ; case G_M000_IG31
       	dd	00001D6Bh ; case G_M000_IG113
       	dd	00001D6Bh ; case G_M000_IG113
       	dd	00000C41h ; case G_M000_IG46
       	dd	00000C41h ; case G_M000_IG46
       	dd	00000AB6h ; case G_M000_IG40
       	dd	00001406h ; case G_M000_IG72
       	dd	00001332h ; case G_M000_IG69
       	dd	000011CCh ; case G_M000_IG66
       	dd	00001D6Bh ; case G_M000_IG113
       	dd	00001D6Bh ; case G_M000_IG113
       	dd	00001D6Bh ; case G_M000_IG113
       	dd	00001D6Bh ; case G_M000_IG113
       	dd	00001D6Bh ; case G_M000_IG113
       	dd	0000014Fh ; case G_M000_IG09
       	dd	00000115h ; case G_M000_IG08
       	dd	00000115h ; case G_M000_IG08
       	dd	00001D6Bh ; case G_M000_IG113
       	dd	00001D6Bh ; case G_M000_IG113
       	dd	0000142Bh ; case G_M000_IG73
       	dd	00001C59h ; case G_M000_IG107
       	dd	00001C59h ; case G_M000_IG107
       	dd	00001C59h ; case G_M000_IG107
       	dd	00001C59h ; case G_M000_IG107
       	dd	00001C59h ; case G_M000_IG107

; Total bytes of code 8017

; Assembly listing for method Lokad.Lython.Runtime.LythonRuntime+NativeExecution:RunCore(byref):bool:this (Instrumented Tier0)
; Emitting BLENDED_CODE for x64 + VEX + EVEX on Unix
; Instrumented Tier0 code
; rbp based frame
; fully interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 0x5D0
       lea      rbp, [rsp+0x5D0]
       vxorps   xmm8, xmm8, xmm8
       mov      rax, -0x570
 
G_M000_IG125:                ;; offset=0x001F
       vmovdqa  xmmword ptr [rbp+rax-0x40], xmm8
       vmovdqa  xmmword ptr [rbp+rax-0x30], xmm8
       vmovdqa  xmmword ptr [rbp+rax-0x20], xmm8
       add      rax, 48
       jne      SHORT G_M000_IG125
       mov      qword ptr [rbp-0x40], rax
       mov      bword ptr [rbp-0x30], rdi
       mov      bword ptr [rbp-0x38], rsi
 
G_M000_IG02:                ;; offset=0x0043
       mov      dword ptr [rbp-0x3E4], 0x3E8
       mov      rax, 0x78B88D801A58
       mov      rsi, gword ptr [rax]
       mov      rdi, bword ptr [rbp-0x38]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       jmp      G_M000_IG115
 
G_M000_IG03:                ;; offset=0x0068
       mov      rax, bword ptr [rbp-0x30]
       mov      rdi, gword ptr [rax+0x08]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Instructions():Lokad.Lython.Frontend.ExecutableInstruction[]:this]
       mov      rcx, bword ptr [rbp-0x30]
       mov      ecx, dword ptr [rcx+0x38]
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG120
       mov      edx, ecx
       imul     rdx, rdx, 32
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      bword ptr [rbp-0x40], rax
       mov      rax, bword ptr [rbp-0x30]
       mov      rdi, gword ptr [rax+0x18]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:get_State():Lokad.Lython.Runtime.ExecutionState:this]
       mov      gword ptr [rbp-0x1A0], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x3F0], rax
       mov      rsi, gword ptr [rbp-0x3F0]
       mov      rdi, gword ptr [rbp-0x1A0]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.ExecutionState:CheckExecution(Lokad.Lython.LythonSourceSpan):this]
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_OpCode():int:this]
       mov      dword ptr [rbp-0x64], eax
       mov      eax, dword ptr [rbp-0x64]
       add      eax, -3
       mov      dword ptr [rbp-0x5B4], eax
       cmp      dword ptr [rbp-0x5B4], 3
       ja       SHORT G_M000_IG05
 
G_M000_IG04:                ;; offset=0x00F7
       mov      eax, dword ptr [rbp-0x5B4]
       lea      rcx, [reloc @RWD00]
       mov      ecx, dword ptr [rcx+4*rax]
       lea      rdx, G_M000_IG02
       add      rcx, rdx
       jmp      rcx
 
G_M000_IG05:                ;; offset=0x0113
       mov      eax, dword ptr [rbp-0x64]
       add      eax, -25
       mov      dword ptr [rbp-0x5B8], eax
       cmp      dword ptr [rbp-0x5B8], 43
       ja       SHORT G_M000_IG07
 
G_M000_IG06:                ;; offset=0x0128
       mov      eax, dword ptr [rbp-0x5B8]
       lea      rcx, [reloc @RWD16]
       mov      ecx, dword ptr [rcx+4*rax]
       lea      rdx, G_M000_IG02
       add      rcx, rdx
       jmp      rcx
 
G_M000_IG07:                ;; offset=0x0144
       mov      rdi, 0x78C06E5601A0
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG113
 
G_M000_IG08:                ;; offset=0x0158
       mov      rdi, 0x78C06E5601A4
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp-0x30]
       mov      rdi, gword ptr [rax+0x08]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_FirstTemporarySlot():int:this]
       mov      dword ptr [rbp-0x3F4], eax
       mov      esi, dword ptr [rbp-0x3F4]
       mov      rdi, bword ptr [rbp-0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Trim(int):this]
       jmp      G_M000_IG118
 
G_M000_IG09:                ;; offset=0x0192
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x3F8], eax
       mov      esi, dword ptr [rbp-0x3F8]
       mov      rdi, bword ptr [rbp-0x30]
       xor      edx, edx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Read(int,int):System.Object:this]
       mov      rsi, rax
       mov      rdi, bword ptr [rbp-0x38]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x1A4], eax
       mov      rax, bword ptr [rbp-0x30]
       mov      rdi, gword ptr [rax+0x08]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_FirstTemporarySlot():int:this]
       cmp      eax, dword ptr [rbp-0x1A4]
       jg       SHORT G_M000_IG10
       mov      rdi, 0x78C06E5601A8
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp-0x30]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp-0x30]
       add      rax, 72
       mov      bword ptr [rbp-0x1B0], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x1B4], eax
       mov      rax, bword ptr [rbp-0x1B0]
       mov      eax, dword ptr [rax+0x08]
       cmp      dword ptr [rbp-0x1B4], eax
       jae      G_M000_IG120
       mov      rax, bword ptr [rbp-0x1B0]
       mov      rax, bword ptr [rax]
       mov      ecx, dword ptr [rbp-0x1B4]
       xor      rdx, rdx
       mov      gword ptr [rax+8*rcx], rdx
 
G_M000_IG10:                ;; offset=0x0248
       mov      rdi, 0x78C06E5601AC
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp-0x30]
       mov      rdi, gword ptr [rax+0x08]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_FirstTemporarySlot():int:this]
       mov      dword ptr [rbp-0x3FC], eax
       mov      esi, dword ptr [rbp-0x3FC]
       mov      rdi, bword ptr [rbp-0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Trim(int):this]
       jmp      G_M000_IG118
 
G_M000_IG11:                ;; offset=0x0282
       mov      rax, bword ptr [rbp-0x30]
       mov      rdi, gword ptr [rax+0x08]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Constants():System.Collections.Generic.IReadOnlyList`1[System.Object]:this]
       mov      gword ptr [rbp-0x3C0], rax
       mov      rax, gword ptr [rbp-0x3C0]
       mov      gword ptr [rbp-0x3C8], rax
       mov      rdi, gword ptr [rbp-0x3C8]
       mov      rsi, 0x78C06E5601B0
       call     CORINFO_HELP_CLASSPROFILE32
       mov      rax, gword ptr [rbp-0x3C8]
       mov      gword ptr [rbp-0x408], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ConstantIndex():int:this]
       mov      dword ptr [rbp-0x40C], eax
       mov      rdi, gword ptr [rbp-0x408]
       mov      esi, dword ptr [rbp-0x40C]
       mov      r11, 0x78C06BA72C38
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       mov      rdi, rax
       call     [Lokad.Lython.Runtime.LythonRuntime:RuntimeValue(System.Object):System.Object]
       mov      gword ptr [rbp-0x418], rax
       mov      rdx, gword ptr [rbp-0x418]
       mov      rsi, bword ptr [rbp-0x40]
       mov      rdi, bword ptr [rbp-0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,System.Object):this]
       jmp      G_M000_IG114
 
G_M000_IG12:                ;; offset=0x031F
       mov      rdi, 0x78C06E5602B8
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LocalSlot():int:this]
       mov      dword ptr [rbp-0x3B4], eax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x420], rax
       mov      rdx, gword ptr [rbp-0x420]
       mov      esi, dword ptr [rbp-0x3B4]
       mov      rdi, bword ptr [rbp-0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:ReadLocal(int,Lokad.Lython.LythonSourceSpan):System.Object:this]
       mov      gword ptr [rbp-0x428], rax
       mov      rdx, gword ptr [rbp-0x428]
       mov      rsi, bword ptr [rbp-0x40]
       mov      rdi, bword ptr [rbp-0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,System.Object):this]
       jmp      G_M000_IG114
 
G_M000_IG13:                ;; offset=0x0387
       mov      rdi, 0x78C06E5602BC
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp-0x30]
       mov      rdi, gword ptr [rax+0x08]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Names():System.Collections.Generic.IReadOnlyList`1[System.String]:this]
       mov      gword ptr [rbp-0x3A8], rax
       mov      rax, gword ptr [rbp-0x3A8]
       mov      gword ptr [rbp-0x3D0], rax
       mov      rdi, gword ptr [rbp-0x3D0]
       mov      rsi, 0x78C06E5602C0
       call     CORINFO_HELP_CLASSPROFILE32
       mov      rax, gword ptr [rbp-0x3D0]
       mov      gword ptr [rbp-0x430], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_NameIndex():int:this]
       mov      dword ptr [rbp-0x434], eax
       mov      rdi, gword ptr [rbp-0x430]
       mov      esi, dword ptr [rbp-0x434]
       mov      r11, 0x78C06BA72C30
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       mov      gword ptr [rbp-0x3B0], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x440], rax
       mov      rsi, gword ptr [rbp-0x440]
       mov      rax, bword ptr [rbp-0x30]
       mov      rdx, gword ptr [rax+0x18]
       mov      rdi, gword ptr [rbp-0x3B0]
       call     [Lokad.Lython.Runtime.LythonRuntime:ResolveExecutableGlobal(System.String,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):System.Object]
       mov      gword ptr [rbp-0x448], rax
       mov      rdx, gword ptr [rbp-0x448]
       mov      rsi, bword ptr [rbp-0x40]
       mov      rdi, bword ptr [rbp-0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,System.Object):this]
       jmp      G_M000_IG114
 
G_M000_IG14:                ;; offset=0x045E
       mov      rax, bword ptr [rbp-0x30]
       mov      r8, gword ptr [rax+0x18]
       mov      rax, bword ptr [rbp-0x30]
       mov      rdi, gword ptr [rax+0x08]
       mov      rax, bword ptr [rbp-0x30]
       mov      rsi, gword ptr [rax+0x10]
       mov      rax, bword ptr [rbp-0x30]
       mov      edx, dword ptr [rax+0x38]
       mov      rax, bword ptr [rbp-0x30]
       mov      ecx, dword ptr [rax+0x3C]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryExecuteClosureArithmetic(Lokad.Lython.Frontend.ExecutableCodeObject,System.Collections.Generic.IReadOnlyList`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableCell],int,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):bool]
       test     eax, eax
       je       SHORT G_M000_IG15
       mov      rdi, 0x78C06E5603C8
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp-0x30]
       add      dword ptr [rax+0x38], 2
       jmp      G_M000_IG114
 
G_M000_IG15:                ;; offset=0x04AA
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ClosureSlot():int:this]
       mov      dword ptr [rbp-0x44C], eax
       mov      esi, dword ptr [rbp-0x44C]
       lea      rdx, [rbp-0x48]
       mov      rdi, bword ptr [rbp-0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:TryCell(int,byref):bool:this]
       test     eax, eax
       je       SHORT G_M000_IG17
       mov      rdi, gword ptr [rbp-0x48]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableCell:get_Value():System.Object:this]
       mov      gword ptr [rbp-0x50], rax
       cmp      gword ptr [rbp-0x50], 0
       jne      SHORT G_M000_IG18
 
G_M000_IG16:                ;; offset=0x04E9
       mov      rdi, 0x78C06E5603CC
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG17:                ;; offset=0x04F8
       mov      rdi, 0x78C06E5603D0
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG108
 
G_M000_IG18:                ;; offset=0x050C
       mov      rdi, 0x78C06E5603D4
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, bword ptr [rbp-0x30]
       mov      rsi, bword ptr [rbp-0x40]
       mov      rdx, gword ptr [rbp-0x50]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,System.Object):this]
       jmp      G_M000_IG114
 
G_M000_IG19:                ;; offset=0x0532
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ClosureSlot():int:this]
       mov      dword ptr [rbp-0x450], eax
       mov      esi, dword ptr [rbp-0x450]
       lea      rdx, [rbp-0x58]
       mov      rdi, bword ptr [rbp-0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:TryCell(int,byref):bool:this]
       test     eax, eax
       je       SHORT G_M000_IG21
       mov      rdi, gword ptr [rbp-0x58]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableCell:get_CanStoreThroughOwner():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG22
 
G_M000_IG20:                ;; offset=0x056A
       mov      rdi, 0x78C06E5603D8
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG21:                ;; offset=0x0579
       mov      rdi, 0x78C06E5603DC
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG108
 
G_M000_IG22:                ;; offset=0x058D
       mov      rdi, 0x78C06E5603E0
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, bword ptr [rbp-0x30]
       mov      rsi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Take(byref):System.Object:this]
       mov      gword ptr [rbp-0x60], rax
       mov      rdi, gword ptr [rbp-0x58]
       mov      rsi, gword ptr [rbp-0x60]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableCell:set_Value(System.Object):this]
       jmp      G_M000_IG114
 
G_M000_IG23:                ;; offset=0x05C3
       mov      rdi, 0x78C06E5603E4
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp-0x30]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp-0x30]
       add      rax, 72
       mov      bword ptr [rbp-0x370], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LocalSlot():int:this]
       mov      dword ptr [rbp-0x374], eax
       mov      rax, bword ptr [rbp-0x370]
       mov      eax, dword ptr [rax+0x08]
       cmp      dword ptr [rbp-0x374], eax
       jae      G_M000_IG120
       mov      rax, bword ptr [rbp-0x370]
       mov      rax, bword ptr [rax]
       mov      ecx, dword ptr [rbp-0x374]
       lea      rax, bword ptr [rax+8*rcx]
       mov      bword ptr [rbp-0x380], rax
       mov      rdi, bword ptr [rbp-0x30]
       mov      rsi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Take(byref):System.Object:this]
       mov      rsi, rax
       mov      rdi, bword ptr [rbp-0x380]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       jmp      G_M000_IG114
 
G_M000_IG24:                ;; offset=0x064A
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x454], eax
       mov      esi, dword ptr [rbp-0x454]
       mov      rdi, bword ptr [rbp-0x30]
       xor      edx, edx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Read(int,int):System.Object:this]
       mov      gword ptr [rbp-0x70], rax
       mov      rax, bword ptr [rbp-0x30]
       mov      rdi, gword ptr [rax+0x08]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Names():System.Collections.Generic.IReadOnlyList`1[System.String]:this]
       mov      gword ptr [rbp-0x390], rax
       mov      rax, gword ptr [rbp-0x390]
       mov      gword ptr [rbp-0x3D8], rax
       mov      rdi, gword ptr [rbp-0x3D8]
       mov      rsi, 0x78C06E5603E8
       call     CORINFO_HELP_CLASSPROFILE32
       mov      rax, gword ptr [rbp-0x3D8]
       mov      gword ptr [rbp-0x460], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_NameIndex():int:this]
       mov      dword ptr [rbp-0x464], eax
       mov      rdi, gword ptr [rbp-0x460]
       mov      esi, dword ptr [rbp-0x464]
       mov      r11, 0x78C06BA72C28
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       mov      gword ptr [rbp-0x78], rax
       mov      rsi, gword ptr [rbp-0x70]
       mov      rdi, 0x78C06E0B75A0
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       jne      SHORT G_M000_IG26
       mov      rsi, gword ptr [rbp-0x70]
       mov      rdi, 0x78C06E43DDA8
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       jne      SHORT G_M000_IG25
       xor      rax, rax
       mov      gword ptr [rbp-0x398], rax
       jmp      SHORT G_M000_IG27
 
G_M000_IG25:                ;; offset=0x0724
       mov      rdi, 0x78C06E5604F0
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, gword ptr [rbp-0x78]
       call     [Lokad.Lython.Runtime.LythonRuntime+DictMembers:GetMethod(System.String):Lokad.Lython.Runtime.LythonRuntime+ReceiverMethod]
       mov      gword ptr [rbp-0x398], rax
       jmp      SHORT G_M000_IG27
 
G_M000_IG26:                ;; offset=0x0746
       mov      rdi, 0x78C06E5604F4
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, gword ptr [rbp-0x78]
       call     [Lokad.Lython.Runtime.LythonRuntime+StringMembers:GetMethod(System.String):Lokad.Lython.Runtime.LythonRuntime+ReceiverMethod]
       mov      gword ptr [rbp-0x398], rax
 
G_M000_IG27:                ;; offset=0x0766
       mov      rax, gword ptr [rbp-0x398]
       mov      gword ptr [rbp-0x80], rax
       cmp      gword ptr [rbp-0x80], 0
       jne      SHORT G_M000_IG28
       mov      rdi, 0x78C06E5604F8
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG108
 
G_M000_IG28:                ;; offset=0x078C
       mov      rdi, 0x78C06E5604FC
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       mov      dword ptr [rbp-0x39C], eax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       inc      eax
       mov      dword ptr [rbp-0x468], eax
       mov      edx, dword ptr [rbp-0x468]
       mov      esi, dword ptr [rbp-0x39C]
       mov      rdi, bword ptr [rbp-0x30]
       mov      rcx, gword ptr [rbp-0x70]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Put(int,int,System.Object):this]
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       inc      eax
       mov      dword ptr [rbp-0x3A0], eax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      dword ptr [rbp-0x46C], eax
       mov      edx, dword ptr [rbp-0x46C]
       mov      esi, dword ptr [rbp-0x3A0]
       mov      rdi, bword ptr [rbp-0x30]
       mov      rcx, gword ptr [rbp-0x80]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Put(int,int,System.Object):this]
       jmp      G_M000_IG114
 
G_M000_IG29:                ;; offset=0x0818
       mov      rdi, bword ptr [rbp-0x30]
       mov      rsi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Call(byref):bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG30
       mov      rdi, 0x78C06E560500
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG108
 
G_M000_IG30:                ;; offset=0x083E
       mov      rdi, 0x78C06E560504
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG114
 
G_M000_IG31:                ;; offset=0x0852
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x470], eax
       mov      esi, dword ptr [rbp-0x470]
       mov      rdi, bword ptr [rbp-0x30]
       xor      edx, edx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Read(int,int):System.Object:this]
       mov      gword ptr [rbp-0x278], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_SecondInput():int:this]
       mov      dword ptr [rbp-0x474], eax
       mov      esi, dword ptr [rbp-0x474]
       mov      rdi, bword ptr [rbp-0x30]
       mov      edx, 1
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Read(int,int):System.Object:this]
       mov      gword ptr [rbp-0x88], rax
       mov      rsi, gword ptr [rbp-0x278]
       mov      rdi, 0x78C06E43DDA8
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      gword ptr [rbp-0x90], rax
       cmp      gword ptr [rbp-0x90], 0
       je       SHORT G_M000_IG33
       mov      rdi, gword ptr [rbp-0x90]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.PyDict:get_HasProtocolKeys():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG34
       mov      rsi, gword ptr [rbp-0x88]
       mov      rdi, 0x78C06E0B75A0
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      gword ptr [rbp-0x98], rax
       cmp      gword ptr [rbp-0x98], 0
       jne      SHORT G_M000_IG35
 
G_M000_IG32:                ;; offset=0x090A
       mov      rdi, 0x78C06E560508
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG33:                ;; offset=0x0919
       mov      rdi, 0x78C06E56050C
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG108
 
G_M000_IG34:                ;; offset=0x092D
       mov      rdi, 0x78C06E560510
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG33
 
G_M000_IG35:                ;; offset=0x093E
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LookupCacheIndex():int:this]
       test     eax, eax
       jl       G_M000_IG38
       mov      rdi, gword ptr [rbp-0x90]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.PyDict:get_HasSharedRecordKeys():bool:this]
       test     eax, eax
       je       G_M000_IG37
       mov      rax, bword ptr [rbp-0x30]
       mov      rax, gword ptr [rax]
       mov      gword ptr [rbp-0x280], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x480], rax
       mov      rsi, gword ptr [rbp-0x480]
       mov      rdi, gword ptr [rbp-0x280]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.PyExecutableFunction:GetLookupCaches(Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.LythonRuntime+ExecutableLookupCache[]:this]
       mov      gword ptr [rbp-0xA0], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LookupCacheIndex():int:this]
       mov      rcx, gword ptr [rbp-0xA0]
       cmp      eax, dword ptr [rcx+0x08]
       jae      G_M000_IG120
       mov      edx, eax
       imul     rdx, rdx, 24
       lea      rcx, bword ptr [rcx+rdx+0x10]
       mov      bword ptr [rbp-0x288], rcx
       mov      rax, bword ptr [rbp-0x30]
       mov      rax, gword ptr [rax+0x18]
       mov      gword ptr [rbp-0x290], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x488], rax
       mov      r8, gword ptr [rbp-0x488]
       lea      r9, [rbp-0xA8]
       mov      rsi, gword ptr [rbp-0x98]
       mov      rdx, bword ptr [rbp-0x288]
       mov      rcx, gword ptr [rbp-0x290]
       mov      rdi, gword ptr [rbp-0x90]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.PyDict:TryReadRecordValue(Lokad.Lython.Runtime.Text.PyString,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,byref):bool:this]
       test     eax, eax
       je       SHORT G_M000_IG36
       mov      rdi, 0x78C06E560514
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, bword ptr [rbp-0x30]
       mov      rsi, bword ptr [rbp-0x40]
       mov      rdx, gword ptr [rbp-0xA8]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,System.Object):this]
       jmp      G_M000_IG114
 
G_M000_IG36:                ;; offset=0x0A4E
       mov      rdi, 0x78C06E560518
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG38
 
G_M000_IG37:                ;; offset=0x0A5F
       mov      rdi, 0x78C06E56051C
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG38:                ;; offset=0x0A6E
       mov      rdi, gword ptr [rbp-0x90]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.PyDict:get_HasProtocolKeys():bool:this]
       test     eax, eax
       je       SHORT G_M000_IG39
       mov      rdi, 0x78C06E560520
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG108
 
G_M000_IG39:                ;; offset=0x0A95
       mov      rdi, 0x78C06E560524
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x490], rax
       mov      rdx, gword ptr [rbp-0x490]
       mov      rax, bword ptr [rbp-0x30]
       mov      rcx, gword ptr [rax+0x18]
       mov      rsi, gword ptr [rbp-0x98]
       mov      rdi, gword ptr [rbp-0x90]
       call     [Lokad.Lython.Runtime.LythonRuntime:ReadSubscriptValue(System.Object,System.Object,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):System.Object]
       mov      gword ptr [rbp-0x498], rax
       mov      rdx, gword ptr [rbp-0x498]
       mov      rsi, bword ptr [rbp-0x40]
       mov      rdi, bword ptr [rbp-0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,System.Object):this]
       jmp      G_M000_IG114
 
G_M000_IG40:                ;; offset=0x0AF9
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x49C], eax
       mov      esi, dword ptr [rbp-0x49C]
       mov      rdi, bword ptr [rbp-0x30]
       xor      edx, edx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Read(int,int):System.Object:this]
       mov      gword ptr [rbp-0xB0], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_UnaryOperator():int:this]
       test     eax, eax
       je       G_M000_IG43
       mov      rsi, gword ptr [rbp-0xB0]
       mov      rdi, 0x78C06E251F78
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       jne      SHORT G_M000_IG42
       mov      rsi, gword ptr [rbp-0xB0]
       mov      rdi, 0x78C06CCC6558
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       jne      SHORT G_M000_IG41
       mov      rdi, 0x78C06E560528
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rsi, gword ptr [rbp-0xB0]
       mov      rdi, 0x78C06CC935C8
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       sete     al
       movzx    rax, al
       mov      dword ptr [rbp-0x1D4], eax
       jmp      SHORT G_M000_IG44
 
G_M000_IG41:                ;; offset=0x0BA3
       mov      rdi, 0x78C06E56052C
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG42:                ;; offset=0x0BB2
       xor      eax, eax
       mov      dword ptr [rbp-0x1D4], eax
       jmp      SHORT G_M000_IG44
 
G_M000_IG43:                ;; offset=0x0BBC
       mov      rdi, 0x78C06E560530
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, gword ptr [rbp-0xB0]
       call     [Lokad.Lython.Runtime.LythonRuntime:CanUseNativeTruth(System.Object):bool]
       test     eax, eax
       sete     al
       movzx    rax, al
       mov      dword ptr [rbp-0x1D4], eax
 
G_M000_IG44:                ;; offset=0x0BE6
       cmp      dword ptr [rbp-0x1D4], 0
       je       SHORT G_M000_IG45
       mov      rdi, 0x78C06E560534
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG108
 
G_M000_IG45:                ;; offset=0x0C03
       mov      rdi, 0x78C06E560538
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_UnaryOperator():int:this]
       mov      dword ptr [rbp-0x1D8], eax
       mov      rax, bword ptr [rbp-0x30]
       mov      rax, gword ptr [rax+0x18]
       mov      gword ptr [rbp-0x1E0], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x4A8], rax
       mov      rcx, gword ptr [rbp-0x4A8]
       mov      rsi, gword ptr [rbp-0xB0]
       mov      rdx, gword ptr [rbp-0x1E0]
       mov      edi, dword ptr [rbp-0x1D8]
       call     [Lokad.Lython.Runtime.LythonRuntime:EvaluateExecutableUnary(int,System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):System.Object]
       mov      gword ptr [rbp-0x4B0], rax
       mov      rdx, gword ptr [rbp-0x4B0]
       mov      rsi, bword ptr [rbp-0x40]
       mov      rdi, bword ptr [rbp-0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,System.Object):this]
       jmp      G_M000_IG114
 
G_M000_IG46:                ;; offset=0x0C84
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x4B4], eax
       mov      esi, dword ptr [rbp-0x4B4]
       mov      rdi, bword ptr [rbp-0x30]
       xor      edx, edx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Read(int,int):System.Object:this]
       mov      gword ptr [rbp-0xB8], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_SecondInput():int:this]
       mov      dword ptr [rbp-0x4B8], eax
       mov      esi, dword ptr [rbp-0x4B8]
       mov      rdi, bword ptr [rbp-0x30]
       mov      edx, 1
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Read(int,int):System.Object:this]
       mov      gword ptr [rbp-0xC0], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_OpCode():int:this]
       cmp      eax, 48
       sete     al
       movzx    rax, al
       mov      dword ptr [rbp-0xC4], eax
       cmp      dword ptr [rbp-0xC4], 0
       jne      G_M000_IG49
       mov      rax, bword ptr [rbp-0x30]
       mov      rax, gword ptr [rax+0x08]
       mov      gword ptr [rbp-0x258], rax
       mov      rax, bword ptr [rbp-0x30]
       mov      rsi, bword ptr [rax+0x48]
       mov      rax, bword ptr [rbp-0x30]
       mov      rdx, qword ptr [rax+0x50]
       mov      rdi, 0x78C06DC0B4D0
       call     [System.Span`1[System.__Canon]:op_Implicit(System.Span`1[System.__Canon]):System.ReadOnlySpan`1[System.__Canon]]
       mov      bword ptr [rbp-0x250], rax
       mov      qword ptr [rbp-0x248], rdx
       mov      rax, bword ptr [rbp-0x30]
       mov      rax, gword ptr [rax+0x18]
       mov      gword ptr [rsp], rax
       lea      rax, [rbp-0xD0]
       mov      qword ptr [rsp+0x08], rax
       lea      rax, [rbp-0xD8]
       mov      qword ptr [rsp+0x10], rax
       mov      rsi, bword ptr [rbp-0x250]
       mov      rdx, qword ptr [rbp-0x248]
       mov      rax, bword ptr [rbp-0x30]
       mov      ecx, dword ptr [rax+0x38]
       mov      rdi, gword ptr [rbp-0x258]
       mov      r8, gword ptr [rbp-0xB8]
       mov      r9, gword ptr [rbp-0xC0]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryIntegerChain(Lokad.Lython.Frontend.ExecutableCodeObject,System.ReadOnlySpan`1[System.Object],int,System.Object,System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,byref):bool]
       test     eax, eax
       je       G_M000_IG48
       mov      rdi, 0x78C06E56053C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp-0x30]
       mov      ecx, dword ptr [rbp-0xD0]
       mov      dword ptr [rax+0x38], ecx
 
G_M000_IG47:                ;; offset=0x0DB4
       mov      rax, bword ptr [rbp-0x30]
       mov      rdi, gword ptr [rax+0x08]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Instructions():Lokad.Lython.Frontend.ExecutableInstruction[]:this]
       mov      ecx, dword ptr [rbp-0xD0]
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG120
       mov      edx, ecx
       imul     rdx, rdx, 32
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      bword ptr [rbp-0x270], rax
       mov      rdi, qword ptr [rbp-0xD8]
       call     [System.Numerics.BigInteger:op_Implicit(long):System.Numerics.BigInteger]
       mov      gword ptr [rbp-0x268], rax
       mov      qword ptr [rbp-0x260], rdx
       lea      rsi, [rbp-0x268]
       mov      rdi, 0x78C06E251F78
       call     [CORINFO_HELP_BOX]
       mov      gword ptr [rbp-0x4C0], rax
       mov      rdx, gword ptr [rbp-0x4C0]
       mov      rsi, bword ptr [rbp-0x270]
       mov      rdi, bword ptr [rbp-0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,System.Object):this]
       jmp      G_M000_IG114
 
G_M000_IG48:                ;; offset=0x0E3B
       mov      rdi, 0x78C06E560540
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG49:                ;; offset=0x0E4A
       cmp      dword ptr [rbp-0xC4], 0
       jne      G_M000_IG51
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_BinaryOperator():int:this]
       mov      dword ptr [rbp-0x234], eax
       mov      rax, bword ptr [rbp-0x30]
       mov      rax, gword ptr [rax+0x18]
       mov      gword ptr [rbp-0x240], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x4C8], rax
       mov      r8, gword ptr [rbp-0x4C8]
       lea      r9, [rbp-0xE0]
       mov      rsi, gword ptr [rbp-0xB8]
       mov      rdx, gword ptr [rbp-0xC0]
       mov      rcx, gword ptr [rbp-0x240]
       mov      edi, dword ptr [rbp-0x234]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryEvaluateScalarComparison(int,System.Object,System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,byref):bool]
       test     eax, eax
       je       SHORT G_M000_IG50
       mov      rdi, 0x78C06E560544
       call     CORINFO_HELP_COUNTPROFILE32
       movzx    rdi, byte  ptr [rbp-0xE0]
       call     [Lokad.Lython.Runtime.LythonRuntime:RuntimeValue(bool):System.Object]
       mov      gword ptr [rbp-0x4D0], rax
       mov      rdx, gword ptr [rbp-0x4D0]
       mov      rsi, bword ptr [rbp-0x40]
       mov      rdi, bword ptr [rbp-0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,System.Object):this]
       jmp      G_M000_IG114
 
G_M000_IG50:                ;; offset=0x0EF8
       mov      rdi, 0x78C06E560548
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG51:                ;; offset=0x0F07
       cmp      dword ptr [rbp-0xC4], 0
       jne      SHORT G_M000_IG52
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_BinaryOperator():int:this]
       mov      dword ptr [rbp-0x1E4], eax
       jmp      SHORT G_M000_IG53
 
G_M000_IG52:                ;; offset=0x0F22
       mov      rdi, 0x78C06E56054C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_AugmentedOperator():int:this]
       mov      edi, eax
       call     [Lokad.Lython.Runtime.LythonRuntime:AugmentedBinaryOperator(int):int]
       mov      dword ptr [rbp-0x1E4], eax
 
G_M000_IG53:                ;; offset=0x0F49
       mov      edi, dword ptr [rbp-0x1E4]
       mov      rsi, gword ptr [rbp-0xB8]
       mov      rdx, gword ptr [rbp-0xC0]
       call     [Lokad.Lython.Runtime.LythonRuntime:CanUseNativeBinary(int,System.Object,System.Object):bool]
       test     eax, eax
       jne      SHORT G_M000_IG54
       mov      rdi, 0x78C06E560550
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG108
 
G_M000_IG54:                ;; offset=0x0F7B
       cmp      dword ptr [rbp-0xC4], 0
       je       G_M000_IG63
       mov      rsi, gword ptr [rbp-0xB8]
       mov      rdi, 0x78C06E251F78
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       jne      SHORT G_M000_IG56
       mov      rsi, gword ptr [rbp-0xB8]
       mov      rdi, 0x78C06CCC6558
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       jne      G_M000_IG62
       mov      rsi, gword ptr [rbp-0xB8]
       mov      rdi, 0x78C06CC935C8
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       je       G_M000_IG61
 
G_M000_IG55:                ;; offset=0x0FE4
       mov      rdi, 0x78C06E560554
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG56:                ;; offset=0x0FF3
       mov      rsi, gword ptr [rbp-0xC0]
       mov      rdi, 0x78C06E251F78
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       jne      SHORT G_M000_IG60
       mov      rsi, gword ptr [rbp-0xC0]
       mov      rdi, 0x78C06CCC6558
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       jne      SHORT G_M000_IG59
       mov      rsi, gword ptr [rbp-0xC0]
       mov      rdi, 0x78C06CC935C8
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       jne      SHORT G_M000_IG58
 
G_M000_IG57:                ;; offset=0x1047
       mov      rdi, 0x78C06E560558
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG108
 
G_M000_IG58:                ;; offset=0x105B
       mov      rdi, 0x78C06E56055C
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG63
 
G_M000_IG59:                ;; offset=0x106C
       mov      rdi, 0x78C06E560560
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG63
 
G_M000_IG60:                ;; offset=0x107D
       mov      rdi, 0x78C06E560564
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG63
 
G_M000_IG61:                ;; offset=0x108E
       mov      rdi, 0x78C06E560568
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG57
 
G_M000_IG62:                ;; offset=0x109F
       mov      rdi, 0x78C06E56056C
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG56
 
G_M000_IG63:                ;; offset=0x10B3
       mov      rax, bword ptr [rbp-0x30]
       mov      bword ptr [rbp-0x1F0], rax
       mov      rax, bword ptr [rbp-0x40]
       mov      bword ptr [rbp-0x1F8], rax
       cmp      dword ptr [rbp-0xC4], 0
       jne      G_M000_IG64
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_BinaryOperator():int:this]
       mov      dword ptr [rbp-0x224], eax
       mov      rax, bword ptr [rbp-0x30]
       mov      rax, gword ptr [rax+0x18]
       mov      gword ptr [rbp-0x230], rax
       mov      rax, bword ptr [rbp-0x1F0]
       mov      bword ptr [rbp-0x210], rax
       mov      rax, bword ptr [rbp-0x1F8]
       mov      bword ptr [rbp-0x218], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x4D8], rax
       mov      r8, gword ptr [rbp-0x4D8]
       mov      rsi, gword ptr [rbp-0xB8]
       mov      rdx, gword ptr [rbp-0xC0]
       mov      rcx, gword ptr [rbp-0x230]
       mov      edi, dword ptr [rbp-0x224]
       call     [Lokad.Lython.Runtime.LythonRuntime:EvaluateBinaryOperator(int,System.Object,System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):System.Object]
       mov      gword ptr [rbp-0x220], rax
       jmp      G_M000_IG65
 
G_M000_IG64:                ;; offset=0x1156
       mov      rdi, 0x78C06E560570
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_AugmentedOperator():int:this]
       mov      dword ptr [rbp-0x1FC], eax
       mov      rax, bword ptr [rbp-0x30]
       mov      rax, gword ptr [rax+0x18]
       mov      gword ptr [rbp-0x208], rax
       mov      rax, bword ptr [rbp-0x1F0]
       mov      bword ptr [rbp-0x210], rax
       mov      rax, bword ptr [rbp-0x1F8]
       mov      bword ptr [rbp-0x218], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x4E0], rax
       mov      r8, gword ptr [rbp-0x4E0]
       mov      rsi, gword ptr [rbp-0xC0]
       mov      edx, dword ptr [rbp-0x1FC]
       mov      rcx, gword ptr [rbp-0x208]
       mov      rdi, gword ptr [rbp-0xB8]
       call     [Lokad.Lython.Runtime.LythonRuntime:EvaluateAugmentedBuiltin(System.Object,System.Object,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):System.Object]
       mov      gword ptr [rbp-0x220], rax
 
G_M000_IG65:                ;; offset=0x11E0
       mov      rdi, 0x78C06E560574
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, bword ptr [rbp-0x210]
       mov      rsi, bword ptr [rbp-0x218]
       mov      rdx, gword ptr [rbp-0x220]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,System.Object):this]
       jmp      G_M000_IG114
 
G_M000_IG66:                ;; offset=0x120F
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x4E4], eax
       mov      esi, dword ptr [rbp-0x4E4]
       mov      rdi, bword ptr [rbp-0x30]
       xor      edx, edx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Read(int,int):System.Object:this]
       mov      gword ptr [rbp-0xE8], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_SecondInput():int:this]
       mov      dword ptr [rbp-0x4E8], eax
       mov      esi, dword ptr [rbp-0x4E8]
       mov      rdi, bword ptr [rbp-0x30]
       mov      edx, 1
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Read(int,int):System.Object:this]
       mov      gword ptr [rbp-0xF0], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_BinaryOperator():int:this]
       mov      dword ptr [rbp-0x1B8], eax
       mov      rax, bword ptr [rbp-0x30]
       mov      rax, gword ptr [rax+0x18]
       mov      gword ptr [rbp-0x1C0], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x4F0], rax
       mov      r8, gword ptr [rbp-0x4F0]
       lea      r9, [rbp-0xF8]
       mov      rsi, gword ptr [rbp-0xE8]
       mov      rdx, gword ptr [rbp-0xF0]
       mov      rcx, gword ptr [rbp-0x1C0]
       mov      edi, dword ptr [rbp-0x1B8]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryEvaluateScalarComparison(int,System.Object,System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,byref):bool]
       test     eax, eax
       jne      SHORT G_M000_IG67
       mov      rdi, 0x78C06E560578
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG108
 
G_M000_IG67:                ;; offset=0x12DB
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      dword ptr [rbp-0x4F4], eax
       mov      esi, dword ptr [rbp-0x4F4]
       mov      rdi, bword ptr [rbp-0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Trim(int):this]
       mov      rax, bword ptr [rbp-0x30]
       mov      rax, gword ptr [rax+0x18]
       mov      gword ptr [rbp-0x1C8], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x500], rax
       mov      rsi, gword ptr [rbp-0x500]
       mov      rdi, gword ptr [rbp-0x1C8]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CheckExecution(Lokad.Lython.LythonSourceSpan):this]
       movzx    rax, byte  ptr [rbp-0xF8]
       test     eax, eax
       jne      SHORT G_M000_IG68
       mov      rdi, 0x78C06E56057C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_TargetIndex():int:this]
       mov      rcx, bword ptr [rbp-0x30]
       mov      dword ptr [rcx+0x38], eax
       jmp      G_M000_IG115
 
G_M000_IG68:                ;; offset=0x1361
       mov      rdi, 0x78C06E560580
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG114
 
G_M000_IG69:                ;; offset=0x1375
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x504], eax
       mov      esi, dword ptr [rbp-0x504]
       mov      rdi, bword ptr [rbp-0x30]
       xor      edx, edx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Read(int,int):System.Object:this]
       mov      gword ptr [rbp-0x100], rax
       mov      rdi, gword ptr [rbp-0x100]
       call     [Lokad.Lython.Runtime.LythonRuntime:CanUseNativeTruth(System.Object):bool]
       test     eax, eax
       jne      SHORT G_M000_IG70
       mov      rdi, 0x78C06E560584
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG108
 
G_M000_IG70:                ;; offset=0x13C3
       mov      rdi, bword ptr [rbp-0x30]
       mov      rsi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Take(byref):System.Object:this]
       mov      rax, bword ptr [rbp-0x30]
       mov      rax, gword ptr [rax+0x18]
       mov      gword ptr [rbp-0x1D0], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x510], rax
       mov      rdx, gword ptr [rbp-0x510]
       mov      rsi, gword ptr [rbp-0x1D0]
       mov      rdi, gword ptr [rbp-0x100]
       call     [Lokad.Lython.Runtime.LythonRuntime:IsTruthy(System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):bool]
       test     eax, eax
       jne      SHORT G_M000_IG71
       mov      rdi, 0x78C06E560588
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_TargetIndex():int:this]
       mov      rcx, bword ptr [rbp-0x30]
       mov      dword ptr [rcx+0x38], eax
       jmp      G_M000_IG115
 
G_M000_IG71:                ;; offset=0x1435
       mov      rdi, 0x78C06E56058C
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG114
 
G_M000_IG72:                ;; offset=0x1449
       mov      rdi, 0x78C06E560590
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_TargetIndex():int:this]
       mov      rcx, bword ptr [rbp-0x30]
       mov      dword ptr [rcx+0x38], eax
       jmp      G_M000_IG115
 
G_M000_IG73:                ;; offset=0x146E
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_DiscardIterator():bool:this]
       test     eax, eax
       je       SHORT G_M000_IG74
       mov      rdi, 0x78C06E560594
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp-0x30]
       mov      eax, dword ptr [rax+0x3C]
       lea      esi, [rax-0x01]
       mov      rdi, bword ptr [rbp-0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Trim(int):this]
 
G_M000_IG74:                ;; offset=0x149F
       mov      rdi, 0x78C06E560598
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_TargetIndex():int:this]
       mov      rcx, bword ptr [rbp-0x30]
       mov      dword ptr [rcx+0x38], eax
       jmp      G_M000_IG115
 
G_M000_IG75:                ;; offset=0x14C4
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x514], eax
       mov      esi, dword ptr [rbp-0x514]
       mov      rdi, bword ptr [rbp-0x30]
       xor      edx, edx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Read(int,int):System.Object:this]
       mov      gword ptr [rbp-0x108], rax
       mov      rsi, gword ptr [rbp-0x108]
       mov      rdi, 0x78C06E53ACD8
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       je       SHORT G_M000_IG76
       mov      rdi, 0x78C06E56059C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, bword ptr [rbp-0x30]
       mov      rsi, bword ptr [rbp-0x40]
       mov      rdx, gword ptr [rbp-0x108]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,System.Object):this]
       jmp      G_M000_IG114
 
G_M000_IG76:                ;; offset=0x1532
       mov      rsi, gword ptr [rbp-0x108]
       mov      rdi, 0x78C06E442B88
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       jne      G_M000_IG78
       mov      rsi, gword ptr [rbp-0x108]
       mov      rdi, 0x78C06E0B8030
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       jne      G_M000_IG83
       mov      rsi, gword ptr [rbp-0x108]
       mov      rdi, 0x78C06E526510
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       jne      G_M000_IG82
       mov      rsi, gword ptr [rbp-0x108]
       mov      rdi, 0x78C06E0BB8C0
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       jne      G_M000_IG81
       mov      rsi, gword ptr [rbp-0x108]
       mov      rdi, 0x78C06E0B75A0
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       jne      SHORT G_M000_IG80
       mov      rsi, gword ptr [rbp-0x108]
       mov      rdi, 0x78C06E43DDA8
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       jne      SHORT G_M000_IG79
       mov      rsi, gword ptr [rbp-0x108]
       mov      rdi, 0x78C06E4F0FE8
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       je       SHORT G_M000_IG84
 
G_M000_IG77:                ;; offset=0x1606
       mov      rdi, 0x78C06E5605A0
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG78:                ;; offset=0x1615
       mov      dword ptr [rbp-0x10C], 1
       jmp      SHORT G_M000_IG85
 
G_M000_IG79:                ;; offset=0x1621
       mov      rdi, 0x78C06E5605A4
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG78
 
G_M000_IG80:                ;; offset=0x1632
       mov      rdi, 0x78C06E5605A8
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG78
 
G_M000_IG81:                ;; offset=0x1643
       mov      rdi, 0x78C06E5605AC
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG78
 
G_M000_IG82:                ;; offset=0x1654
       mov      rdi, 0x78C06E5605B0
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG78
 
G_M000_IG83:                ;; offset=0x1665
       mov      rdi, 0x78C06E5605B4
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG78
 
G_M000_IG84:                ;; offset=0x1676
       mov      rdi, 0x78C06E5605B8
       call     CORINFO_HELP_COUNTPROFILE32
       xor      eax, eax
       mov      dword ptr [rbp-0x10C], eax
 
G_M000_IG85:                ;; offset=0x168D
       cmp      dword ptr [rbp-0x10C], 0
       je       SHORT G_M000_IG86
       mov      rdi, 0x78C06E5605BC
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x520], rax
       mov      rsi, gword ptr [rbp-0x520]
       mov      rax, bword ptr [rbp-0x30]
       mov      rdx, gword ptr [rax+0x18]
       mov      rdi, gword ptr [rbp-0x108]
       call     [Lokad.Lython.Runtime.PyIteration+Cursor:Create(System.Object,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):Lokad.Lython.Runtime.PyIteration+Cursor]
       mov      gword ptr [rbp-0x528], rax
       mov      rdx, gword ptr [rbp-0x528]
       mov      rsi, bword ptr [rbp-0x40]
       mov      rdi, bword ptr [rbp-0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,System.Object):this]
       jmp      G_M000_IG114
 
G_M000_IG86:                ;; offset=0x16F3
       mov      rdi, 0x78C06E5605C0
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG108
 
G_M000_IG87:                ;; offset=0x1707
       mov      rax, bword ptr [rbp-0x30]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp-0x30]
       add      rax, 72
       mov      bword ptr [rbp-0x298], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x29C], eax
       mov      rax, bword ptr [rbp-0x298]
       mov      eax, dword ptr [rax+0x08]
       cmp      dword ptr [rbp-0x29C], eax
       jae      G_M000_IG120
       mov      rax, bword ptr [rbp-0x298]
       mov      rax, bword ptr [rax]
       mov      ecx, dword ptr [rbp-0x29C]
       mov      rax, gword ptr [rax+8*rcx]
       mov      gword ptr [rbp-0x118], rax
       mov      rsi, gword ptr [rbp-0x118]
       mov      rdi, 0x78C06E53ACD8
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      gword ptr [rbp-0x130], rax
       cmp      gword ptr [rbp-0x130], 0
       jne      G_M000_IG93
       mov      rsi, gword ptr [rbp-0x118]
       mov      rdi, 0x78C06E43FE48
       call     [CORINFO_HELP_CHKCASTCLASS]
       mov      gword ptr [rbp-0x530], rax
       mov      rdi, gword ptr [rbp-0x530]
       lea      rsi, [rbp-0x138]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.PyIteration+Cursor:TryMoveNext(byref):bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG90
       call     [Lokad.Lython.Runtime.PyIterationResult:get_End():Lokad.Lython.Runtime.PyIterationResult]
       mov      gword ptr [rbp-0x2E0], rax
       mov      qword ptr [rbp-0x2D8], rdx
 
G_M000_IG88:                ;; offset=0x17D5
       vmovdqu32 xmm0, xmmword ptr [rbp-0x2E0]
       vmovdqu32 xmmword ptr [rbp-0x2C0], xmm0
 
G_M000_IG89:                ;; offset=0x17E3
       jmp      SHORT G_M000_IG95
 
G_M000_IG90:                ;; offset=0x17E5
       mov      rdi, 0x78C06E5605C4
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, gword ptr [rbp-0x138]
       call     [Lokad.Lython.Runtime.PyIterationResult:Yield(System.Object):Lokad.Lython.Runtime.PyIterationResult]
       mov      gword ptr [rbp-0x2D0], rax
       mov      qword ptr [rbp-0x2C8], rdx
 
G_M000_IG91:                ;; offset=0x180F
       vmovdqu32 xmm0, xmmword ptr [rbp-0x2D0]
       vmovdqu32 xmmword ptr [rbp-0x2C0], xmm0
 
G_M000_IG92:                ;; offset=0x181D
       jmp      SHORT G_M000_IG95
 
G_M000_IG93:                ;; offset=0x181F
       mov      rdi, 0x78C06E5605C8
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, gword ptr [rbp-0x130]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.Text.PyStringOps+CasedWhitespaceIteration:MoveNext():Lokad.Lython.Runtime.PyIterationResult:this]
       mov      gword ptr [rbp-0x2B0], rax
       mov      qword ptr [rbp-0x2A8], rdx
 
G_M000_IG94:                ;; offset=0x184B
       vmovdqu32 xmm0, xmmword ptr [rbp-0x2B0]
       vmovdqu32 xmmword ptr [rbp-0x2C0], xmm0
 
G_M000_IG95:                ;; offset=0x1859
       vmovdqu32 xmm0, xmmword ptr [rbp-0x2C0]
       vmovdqu  xmmword ptr [rbp-0x128], xmm0
 
G_M000_IG96:                ;; offset=0x1868
       lea      rdi, [rbp-0x128]
       call     [Lokad.Lython.Runtime.PyIterationResult:get_HasValue():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG97
       mov      rdi, 0x78C06E5605CC
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x534], eax
       mov      esi, dword ptr [rbp-0x534]
       mov      rdi, bword ptr [rbp-0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Trim(int):this]
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_TargetIndex():int:this]
       mov      rcx, bword ptr [rbp-0x30]
       mov      dword ptr [rcx+0x38], eax
       jmp      G_M000_IG115
 
G_M000_IG97:                ;; offset=0x18BE
       mov      rdi, 0x78C06E5605D0
       call     CORINFO_HELP_COUNTPROFILE32
       lea      rdi, [rbp-0x128]
       call     [Lokad.Lython.Runtime.PyIterationResult:get_Value():System.Object:this]
       mov      gword ptr [rbp-0x540], rax
       mov      rdx, gword ptr [rbp-0x540]
       mov      rsi, bword ptr [rbp-0x40]
       mov      rdi, bword ptr [rbp-0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,System.Object):this]
       jmp      G_M000_IG114
 
G_M000_IG98:                ;; offset=0x18FB
       mov      rdi, bword ptr [rbp-0x30]
       mov      rsi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:TryReturnUnpackedTuple(byref):bool:this]
       test     eax, eax
       je       SHORT G_M000_IG99
       mov      rdi, 0x78C06E5605D4
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG118
 
G_M000_IG99:                ;; offset=0x1921
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ItemCount():int:this]
       test     eax, eax
       je       G_M000_IG100
       mov      rax, bword ptr [rbp-0x30]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp-0x30]
       add      rax, 72
       mov      bword ptr [rbp-0x2F0], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x2F4], eax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ItemCount():int:this]
       mov      dword ptr [rbp-0x544], eax
       mov      ecx, dword ptr [rbp-0x544]
       mov      rdi, bword ptr [rbp-0x2F0]
       mov      edx, dword ptr [rbp-0x2F4]
       mov      rsi, 0x78C06DC0B4D0
       call     [System.Span`1[System.__Canon]:Slice(int,int):System.Span`1[System.__Canon]:this]
       mov      bword ptr [rbp-0x308], rax
       mov      qword ptr [rbp-0x300], rdx
       mov      rsi, bword ptr [rbp-0x308]
       mov      rdx, qword ptr [rbp-0x300]
       mov      rdi, 0x78C06DC0B4D0
       call     [System.Span`1[System.__Canon]:op_Implicit(System.Span`1[System.__Canon]):System.ReadOnlySpan`1[System.__Canon]]
       mov      bword ptr [rbp-0x318], rax
       mov      qword ptr [rbp-0x310], rdx
       mov      rax, bword ptr [rbp-0x30]
       mov      rdi, gword ptr [rax+0x18]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:get_MemoryGovernor():Lokad.Lython.Runtime.MemoryGovernor:this]
       mov      gword ptr [rbp-0x320], rax
       mov      rdi, 0x78C06E0B8030
       call     CORINFO_HELP_NEWSFAST
       mov      gword ptr [rbp-0x328], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x550], rax
       mov      r8, gword ptr [rbp-0x550]
       mov      rax, bword ptr [rbp-0x30]
       mov      r9, gword ptr [rax+0x18]
       mov      rsi, bword ptr [rbp-0x318]
       mov      rdx, qword ptr [rbp-0x310]
       mov      rcx, gword ptr [rbp-0x320]
       mov      rdi, gword ptr [rbp-0x328]
       call     [Lokad.Lython.Runtime.PyTuple:.ctor(System.ReadOnlySpan`1[System.Object],Lokad.Lython.Runtime.MemoryGovernor,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):this]
       mov      rax, gword ptr [rbp-0x328]
       mov      gword ptr [rbp-0x2E8], rax
       jmp      SHORT G_M000_IG101
 
G_M000_IG100:                ;; offset=0x1A44
       mov      rdi, 0x78C06E5605D8
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, 0x78B88D801950
       mov      rax, gword ptr [rax]
       mov      gword ptr [rbp-0x2E8], rax
 
G_M000_IG101:                ;; offset=0x1A67
       mov      rdi, 0x78C06E5605DC
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, gword ptr [rbp-0x2E8]
       mov      gword ptr [rbp-0x140], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x554], eax
       mov      esi, dword ptr [rbp-0x554]
       mov      rdi, bword ptr [rbp-0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Trim(int):this]
       mov      rdi, bword ptr [rbp-0x30]
       mov      rsi, bword ptr [rbp-0x40]
       mov      rdx, gword ptr [rbp-0x140]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,System.Object):this]
       jmp      G_M000_IG114
 
G_M000_IG102:                ;; offset=0x1ABE
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ItemCount():int:this]
       mov      edi, eax
       call     [Lokad.Lython.Runtime.PyList:EstimateCapacityBytes(int):long]
       mov      qword ptr [rbp-0x148], rax
       mov      rax, bword ptr [rbp-0x30]
       mov      rdi, gword ptr [rax+0x18]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:get_MemoryGovernor():Lokad.Lython.Runtime.MemoryGovernor:this]
       mov      gword ptr [rbp-0x330], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x560], rax
       mov      rdx, gword ptr [rbp-0x560]
       mov      rsi, qword ptr [rbp-0x148]
       mov      rdi, gword ptr [rbp-0x330]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.MemoryGovernor:ReserveTemporary(long,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.MemoryGovernor+TemporaryMemoryReservation:this]
       mov      gword ptr [rbp-0x150], rax
 
G_M000_IG103:                ;; offset=0x1B23
       mov      rdi, 0x78C06E5605E0
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp-0x30]
       mov      rax, gword ptr [rax+0x18]
       mov      gword ptr [rbp-0x338], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x568], rax
       mov      rsi, gword ptr [rbp-0x568]
       mov      rdi, gword ptr [rbp-0x338]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CheckExecution(Lokad.Lython.LythonSourceSpan):this]
       mov      rax, bword ptr [rbp-0x30]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp-0x30]
       add      rax, 72
       mov      bword ptr [rbp-0x340], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x344], eax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ItemCount():int:this]
       mov      dword ptr [rbp-0x56C], eax
       mov      ecx, dword ptr [rbp-0x56C]
       mov      rdi, bword ptr [rbp-0x340]
       mov      edx, dword ptr [rbp-0x344]
       mov      rsi, 0x78C06DC0B4D0
       call     [System.Span`1[System.__Canon]:Slice(int,int):System.Span`1[System.__Canon]:this]
       mov      bword ptr [rbp-0x358], rax
       mov      qword ptr [rbp-0x350], rdx
 
G_M000_IG104:                ;; offset=0x1BCE
       vmovdqu  xmm0, xmmword ptr [rbp-0x358]
       vmovdqu  xmmword ptr [rbp-0x168], xmm0
 
G_M000_IG105:                ;; offset=0x1BDE
       lea      rdi, [rbp-0x168]
       mov      rsi, 0x78C06DC0B4D0
       call     [System.Span`1[System.__Canon]:ToArray():System.__Canon[]:this]
       mov      gword ptr [rbp-0x158], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x570], eax
       mov      esi, dword ptr [rbp-0x570]
       mov      rdi, bword ptr [rbp-0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Trim(int):this]
       mov      rdi, gword ptr [rbp-0x150]
       mov      rsi, qword ptr [rbp-0x148]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.MemoryGovernor+TemporaryMemoryReservation:Commit(long):this]
       mov      rax, bword ptr [rbp-0x30]
       mov      rdi, gword ptr [rax+0x18]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:get_MemoryGovernor():Lokad.Lython.Runtime.MemoryGovernor:this]
       mov      gword ptr [rbp-0x360], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x578], rax
       mov      rdx, gword ptr [rbp-0x578]
       mov      rsi, gword ptr [rbp-0x360]
       mov      rdi, gword ptr [rbp-0x158]
       call     [Lokad.Lython.Runtime.PyList:FromTransferredArray(System.Object[],Lokad.Lython.Runtime.MemoryGovernor,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.PyList]
       mov      gword ptr [rbp-0x580], rax
       mov      rdx, gword ptr [rbp-0x580]
       mov      rsi, bword ptr [rbp-0x40]
       mov      rdi, bword ptr [rbp-0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,System.Object):this]
       nop      
 
G_M000_IG106:                ;; offset=0x1C92
       call     G_M000_IG121
       jmp      G_M000_IG114
 
G_M000_IG107:                ;; offset=0x1C9C
       mov      rdi, bword ptr [rbp-0x30]
       mov      rsi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Format(byref):bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG110
       mov      rdi, 0x78C06E5606F4
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG108:                ;; offset=0x1CBD
       xor      eax, eax
 
G_M000_IG109:                ;; offset=0x1CBF
       add      rsp, 0x5D0
       pop      rbp
       ret      
 
G_M000_IG110:                ;; offset=0x1CC8
       mov      rdi, 0x78C06E5606F8
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG114
 
G_M000_IG111:                ;; offset=0x1CDC
       mov      rdi, 0x78C06E5606FC
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       inc      eax
       mov      dword ptr [rbp-0x364], eax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      dword ptr [rbp-0x368], eax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x58C], eax
       mov      esi, dword ptr [rbp-0x58C]
       mov      rdi, bword ptr [rbp-0x30]
       xor      edx, edx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Read(int,int):System.Object:this]
       mov      gword ptr [rbp-0x598], rax
       mov      rcx, gword ptr [rbp-0x598]
       mov      esi, dword ptr [rbp-0x364]
       mov      edx, dword ptr [rbp-0x368]
       mov      rdi, bword ptr [rbp-0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Put(int,int,System.Object):this]
       jmp      G_M000_IG114
 
G_M000_IG112:                ;; offset=0x1D58
       mov      rdi, 0x78C06E560700
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x59C], eax
       mov      esi, dword ptr [rbp-0x59C]
       mov      rdi, bword ptr [rbp-0x30]
       xor      edx, edx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Read(int,int):System.Object:this]
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      dword ptr [rbp-0x5A0], eax
       mov      esi, dword ptr [rbp-0x5A0]
       mov      rdi, bword ptr [rbp-0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Trim(int):this]
       jmp      G_M000_IG114
 
G_M000_IG113:                ;; offset=0x1DAE
       lea      rdi, [rbp-0x190]
       mov      esi, 26
       mov      edx, 1
       call     [System.Runtime.CompilerServices.DefaultInterpolatedStringHandler:.ctor(int,int):this]
       lea      rdi, [rbp-0x190]
       mov      rsi, 0x78C06845BB98
       call     [System.Runtime.CompilerServices.DefaultInterpolatedStringHandler:AppendLiteral(System.String):this]
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_OpCode():int:this]
       mov      dword ptr [rbp-0x5A4], eax
       mov      esi, dword ptr [rbp-0x5A4]
       lea      rdi, [rbp-0x190]
       call     [System.Runtime.CompilerServices.DefaultInterpolatedStringHandler:AppendFormatted[int](int):this]
       mov      rdi, 0x78C06D3A7A68
       call     CORINFO_HELP_NEWSFAST
       mov      gword ptr [rbp-0x388], rax
       lea      rdi, [rbp-0x190]
       call     [System.Runtime.CompilerServices.DefaultInterpolatedStringHandler:ToStringAndClear():System.String:this]
       mov      gword ptr [rbp-0x5B0], rax
       mov      rsi, gword ptr [rbp-0x5B0]
       mov      rdi, gword ptr [rbp-0x388]
       call     [System.InvalidOperationException:.ctor(System.String):this]
       mov      rdi, gword ptr [rbp-0x388]
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG114:                ;; offset=0x1E4A
       mov      rdi, 0x78C06E560704
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp-0x30]
       inc      dword ptr [rax+0x38]
 
G_M000_IG115:                ;; offset=0x1E60
       mov      eax, dword ptr [rbp-0x3E4]
       dec      eax
       mov      dword ptr [rbp-0x3E4], eax
       cmp      dword ptr [rbp-0x3E4], 0
       jg       SHORT G_M000_IG117
 
G_M000_IG116:                ;; offset=0x1E77
       lea      rdi, [rbp-0x3E4]
       mov      esi, 0x96A
       call     CORINFO_HELP_PATCHPOINT
       jmp      rax
 
G_M000_IG117:                ;; offset=0x1E8A
       mov      rax, bword ptr [rbp-0x30]
       mov      eax, dword ptr [rax+0x38]
       mov      dword ptr [rbp-0x194], eax
       mov      rax, bword ptr [rbp-0x30]
       mov      rdi, gword ptr [rax+0x08]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Instructions():Lokad.Lython.Frontend.ExecutableInstruction[]:this]
       mov      eax, dword ptr [rax+0x08]
       cmp      eax, dword ptr [rbp-0x194]
       jg       G_M000_IG03
       mov      rdi, 0x78C06E560708
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG118:                ;; offset=0x1EC5
       mov      eax, 1
 
G_M000_IG119:                ;; offset=0x1ECA
       add      rsp, 0x5D0
       pop      rbp
       ret      
 
G_M000_IG120:                ;; offset=0x1ED3
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG121:                ;; offset=0x1ED9
       sub      rsp, 24
 
G_M000_IG122:                ;; offset=0x1EDD
       cmp      gword ptr [rbp-0x150], 0
       je       SHORT G_M000_IG123
       mov      rdi, 0x78C06E5605E4
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, gword ptr [rbp-0x150]
       mov      gword ptr [rbp-0x3E0], rax
       mov      rdi, gword ptr [rbp-0x3E0]
       mov      rsi, 0x78C06E5605E8
       call     CORINFO_HELP_CLASSPROFILE32
       mov      rax, gword ptr [rbp-0x3E0]
       mov      gword ptr [rbp-0x588], rax
       mov      rdi, gword ptr [rbp-0x588]
       mov      r11, 0x78C06BA72C20
       call     [r11]System.IDisposable:Dispose():this
 
G_M000_IG123:                ;; offset=0x1F3C
       mov      rdi, 0x78C06E5606F0
       call     CORINFO_HELP_COUNTPROFILE32
       nop      
 
G_M000_IG124:                ;; offset=0x1F4C
       add      rsp, 24
       ret      
 
RWD00  	dd	0000023Fh ; case G_M000_IG11
       	dd	000002DCh ; case G_M000_IG12
       	dd	0000041Bh ; case G_M000_IG14
       	dd	00000344h ; case G_M000_IG13
RWD16  	dd	00000607h ; case G_M000_IG24
       	dd	00001D6Bh ; case G_M000_IG113
       	dd	00000580h ; case G_M000_IG23
       	dd	000004EFh ; case G_M000_IG19
       	dd	00001D6Bh ; case G_M000_IG113
       	dd	00001D6Bh ; case G_M000_IG113
       	dd	00001C99h ; case G_M000_IG111
       	dd	00001D15h ; case G_M000_IG112
       	dd	00001A7Bh ; case G_M000_IG102
       	dd	000018B8h ; case G_M000_IG98
       	dd	00001D6Bh ; case G_M000_IG113
       	dd	00001D6Bh ; case G_M000_IG113
       	dd	00001D6Bh ; case G_M000_IG113
       	dd	00001D6Bh ; case G_M000_IG113
       	dd	00001D6Bh ; case G_M000_IG113
       	dd	00001D6Bh ; case G_M000_IG113
       	dd	00001481h ; case G_M000_IG75
       	dd	000016C4h ; case G_M000_IG87
       	dd	000007D5h ; case G_M000_IG29
       	dd	0000080Fh ; case G_M000_IG31
       	dd	00001D6Bh ; case G_M000_IG113
       	dd	00001D6Bh ; case G_M000_IG113
       	dd	00000C41h ; case G_M000_IG46
       	dd	00000C41h ; case G_M000_IG46
       	dd	00000AB6h ; case G_M000_IG40
       	dd	00001406h ; case G_M000_IG72
       	dd	00001332h ; case G_M000_IG69
       	dd	000011CCh ; case G_M000_IG66
       	dd	00001D6Bh ; case G_M000_IG113
       	dd	00001D6Bh ; case G_M000_IG113
       	dd	00001D6Bh ; case G_M000_IG113
       	dd	00001D6Bh ; case G_M000_IG113
       	dd	00001D6Bh ; case G_M000_IG113
       	dd	0000014Fh ; case G_M000_IG09
       	dd	00000115h ; case G_M000_IG08
       	dd	00000115h ; case G_M000_IG08
       	dd	00001D6Bh ; case G_M000_IG113
       	dd	00001D6Bh ; case G_M000_IG113
       	dd	0000142Bh ; case G_M000_IG73
       	dd	00001C59h ; case G_M000_IG107
       	dd	00001C59h ; case G_M000_IG107
       	dd	00001C59h ; case G_M000_IG107
       	dd	00001C59h ; case G_M000_IG107
       	dd	00001C59h ; case G_M000_IG107

; Total bytes of code 8017

; Assembly listing for method Lokad.Lython.Runtime.LythonRuntime+NativeExecution:RunCore(byref):bool:this (Tier1)
; Emitting BLENDED_CODE for x64 + VEX + EVEX on Unix
; Tier1 code
; optimized code
; optimized using Synthesized PGO
; rbp based frame
; fully interruptible
; with Synthesized PGO: fgCalledCount is 141760
; 115 inlinees with PGO data; 251 single block inlinees; 19 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       push     r15
       push     r14
       push     r13
       push     r12
       push     rbx
       sub      rsp, 648
       lea      rbp, [rsp+0x2B0]
       xor      eax, eax
       mov      qword ptr [rbp-0x298], rax
       vxorps   xmm8, xmm8, xmm8
       vmovdqa32 xmmword ptr [rbp-0x290], xmm8
       vmovdqa32 xmmword ptr [rbp-0x280], xmm8
       mov      rax, -576
 
G_M000_IG387:                ;; offset=0x003F
       vmovdqa  xmmword ptr [rbp+rax-0x30], xmm8
       vmovdqa  xmmword ptr [rbp+rax-0x20], xmm8
       vmovdqa  xmmword ptr [rbp+rax-0x10], xmm8
       add      rax, 48
       jne      SHORT G_M000_IG387
       mov      qword ptr [rbp-0x30], rax
       mov      rbx, rdi
       mov      r15, rsi
 
G_M000_IG02:                ;; offset=0x0061
       mov      rdi, 0x78B88D801A58
       mov      rsi, gword ptr [rdi]
       mov      rdi, r15
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      edi, dword ptr [rbx+0x38]
       mov      rax, gword ptr [rbx+0x08]
       mov      rax, gword ptr [rax+0x50]
       cmp      edi, dword ptr [rax+0x08]
       jge      G_M000_IG194
       jmp      G_M000_IG65
 
G_M000_IG03:                ;; offset=0x008F
       mov      rdi, gword ptr [rbx+0x08]
       mov      rdi, gword ptr [rdi+0x10]
       mov      r11, 0x78C06CC927A0
       cmp      qword ptr [rdi], r11
       jne      G_M000_IG299
       not      esi
       mov      r12d, dword ptr [rdi+0x08]
       cmp      r12d, esi
       jbe      G_M000_IG361
       cmp      esi, r12d
       jae      G_M000_IG379
       mov      rdi, gword ptr [rdi+8*rsi+0x10]
 
G_M000_IG04:                ;; offset=0x00C7
       call     [Lokad.Lython.Runtime.LythonRuntime:RuntimeValue(System.Object):System.Object]
       mov      r13, rax
       jmp      G_M000_IG70
 
G_M000_IG05:                ;; offset=0x00D5
       mov      rdi, gword ptr [rbx+0x08]
       mov      rdi, gword ptr [rdi+0x10]
       mov      r11, 0x78C06CC927A0
       cmp      qword ptr [rdi], r11
       jne      G_M000_IG302
       not      esi
       mov      r11d, dword ptr [rdi+0x08]
       cmp      r11d, esi
       jbe      G_M000_IG361
       cmp      esi, r11d
       jae      G_M000_IG379
       mov      rdi, gword ptr [rdi+8*rsi+0x10]
 
G_M000_IG06:                ;; offset=0x010D
       call     [Lokad.Lython.Runtime.LythonRuntime:RuntimeValue(System.Object):System.Object]
       mov      r12, rax
       jmp      G_M000_IG72
 
G_M000_IG07:                ;; offset=0x011B
       mov      edi, dword ptr [rbp-0x48]
       mov      dword ptr [rbx+0x38], edi
       mov      rdi, gword ptr [rbx+0x08]
       mov      rdi, gword ptr [rdi+0x50]
       mov      esi, dword ptr [rdi+0x08]
       cmp      dword ptr [rbp-0x48], esi
       jae      G_M000_IG379
       mov      esi, dword ptr [rbp-0x48]
       shl      rsi, 5
       lea      r14, bword ptr [rdi+rsi+0x10]
       mov      rsi, qword ptr [rbp-0x50]
       vxorps   xmm0, xmm0, xmm0
       vmovdqu  xmmword ptr [rbp-0x118], xmm0
       lea      rdi, [rbp-0x118]
       call     [System.Numerics.BigInteger:.ctor(long):this]
       mov      rdi, 0x78C06E251F78
       call     CORINFO_HELP_NEWSFAST
       mov      r13, rax
       lea      rdi, bword ptr [r13+0x08]
       mov      rsi, gword ptr [rbp-0x118]
       call     CORINFO_HELP_ASSIGN_REF
       mov      edi, dword ptr [rbp-0x110]
       mov      dword ptr [r13+0x10], edi
       cmp      dword ptr [r14+0x18], 0
       jl       SHORT G_M000_IG16
 
G_M000_IG08:                ;; offset=0x0191
       mov      edi, dword ptr [r14+0x1C]
       cmp      edi, 52
       ja       SHORT G_M000_IG10
 
G_M000_IG09:                ;; offset=0x019A
       mov      rax, 0xFFFFFFFFFE7FF
       bt       rax, rdi
       jae      G_M000_IG305
 
G_M000_IG10:                ;; offset=0x01AE
       mov      r12d, dword ptr [r14+0x14]
 
G_M000_IG11:                ;; offset=0x01B2
       cmp      dword ptr [r14+0x18], 0
       jl       SHORT G_M000_IG15
 
G_M000_IG12:                ;; offset=0x01B9
       mov      r14d, dword ptr [r14+0x18]
 
G_M000_IG13:                ;; offset=0x01BD
       cmp      r14d, dword ptr [rbx+0x3C]
       jl       G_M000_IG306
 
G_M000_IG14:                ;; offset=0x01C7
       lea      rdi, bword ptr [rbx+0x48]
       cmp      r12d, dword ptr [rdi+0x08]
       jae      G_M000_IG379
       mov      rdi, bword ptr [rdi]
       mov      esi, r12d
       lea      rdi, bword ptr [rdi+8*rsi]
       mov      rsi, r13
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      dword ptr [rbx+0x3C], r14d
       jmp      G_M000_IG63
 
G_M000_IG15:                ;; offset=0x01F0
       mov      edi, dword ptr [r14+0x18]
       mov      r14d, edi
       not      r14d
       jmp      SHORT G_M000_IG13
 
G_M000_IG16:                ;; offset=0x01FC
       mov      edi, dword ptr [r14+0x18]
       not      edi
       cmp      edi, dword ptr [rbx+0x3C]
       jge      SHORT G_M000_IG18
 
G_M000_IG17:                ;; offset=0x0207
       mov      edi, dword ptr [r14+0x18]
       mov      esi, edi
       not      esi
       mov      rdi, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Trim(int):this]
 
G_M000_IG18:                ;; offset=0x0218
       lea      r12, bword ptr [rbx+0x48]
       mov      rdi, r14
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       cmp      eax, dword ptr [r12+0x08]
       jae      G_M000_IG379
       mov      rdi, bword ptr [r12]
       mov      eax, eax
       xor      rcx, rcx
       mov      gword ptr [rdi+8*rax], rcx
       mov      rdi, r14
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       mov      dword ptr [rbx+0x3C], eax
       mov      rdi, gword ptr [rbx+0x08]
       mov      rdi, gword ptr [rdi+0x50]
       mov      eax, dword ptr [rbx+0x38]
       inc      eax
       cmp      eax, dword ptr [rdi+0x08]
       jae      G_M000_IG379
       shl      rax, 5
       lea      r14, bword ptr [rdi+rax+0x10]
       mov      rdi, gword ptr [rbx+0x18]
       mov      rax, gword ptr [r14]
       mov      rdi, gword ptr [rdi+0xA0]
       mov      rcx, gword ptr [rdi+0x88]
       mov      rcx, gword ptr [rcx+0x20]
       test     rcx, rcx
       jne      G_M000_IG307
       mov      rdi, gword ptr [rdi+0x178]
       test     rdi, rdi
       jne      G_M000_IG308
 
G_M000_IG19:                ;; offset=0x0299
       lea      r12, bword ptr [rbx+0x48]
       mov      rdi, r14
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LocalSlot():int:this]
       cmp      eax, dword ptr [r12+0x08]
       jae      G_M000_IG379
       mov      rdi, bword ptr [r12]
       mov      esi, eax
       lea      rdi, bword ptr [rdi+8*rsi]
       mov      rsi, r13
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       jmp      G_M000_IG163
 
G_M000_IG20:                ;; offset=0x02C8
       mov      edi, dword ptr [r14+0x18]
       mov      r14d, edi
       not      r14d
       jmp      G_M000_IG84
 
G_M000_IG21:                ;; offset=0x02D7
       mov      edi, dword ptr [r14+0x18]
       not      edi
       cmp      edi, dword ptr [rbx+0x3C]
       jge      SHORT G_M000_IG23
 
G_M000_IG22:                ;; offset=0x02E2
       mov      edi, dword ptr [r14+0x18]
       mov      esi, edi
       not      esi
       mov      rdi, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Trim(int):this]
 
G_M000_IG23:                ;; offset=0x02F3
       lea      r13, bword ptr [rbx+0x48]
       mov      edi, dword ptr [r14+0x1C]
       cmp      edi, 52
       ja       SHORT G_M000_IG25
 
G_M000_IG24:                ;; offset=0x0300
       mov      rax, 0xFFFFFFFFFE7FF
       bt       rax, rdi
       jae      G_M000_IG321
 
G_M000_IG25:                ;; offset=0x0314
       mov      eax, dword ptr [r14+0x14]
 
G_M000_IG26:                ;; offset=0x0318
       cmp      eax, dword ptr [r13+0x08]
       jae      G_M000_IG379
       mov      rdi, bword ptr [r13]
       mov      eax, eax
       xor      rcx, rcx
       mov      gword ptr [rdi+8*rax], rcx
       mov      edi, dword ptr [r14+0x1C]
       cmp      edi, 52
       ja       SHORT G_M000_IG28
 
G_M000_IG27:                ;; offset=0x0337
       mov      rax, 0xFFFFFFFFFE7FF
       bt       rax, rdi
       jae      G_M000_IG322
 
G_M000_IG28:                ;; offset=0x034B
       mov      eax, dword ptr [r14+0x14]
 
G_M000_IG29:                ;; offset=0x034F
       mov      dword ptr [rbx+0x3C], eax
       mov      rdi, gword ptr [rbx+0x08]
       mov      rdi, gword ptr [rdi+0x50]
       mov      eax, dword ptr [rbx+0x38]
       inc      eax
       cmp      eax, dword ptr [rdi+0x08]
       jae      G_M000_IG379
       shl      rax, 5
       lea      r14, bword ptr [rdi+rax+0x10]
       mov      rdi, gword ptr [rbx+0x18]
       mov      rax, gword ptr [r14]
       mov      rdi, gword ptr [rdi+0xA0]
       mov      rcx, gword ptr [rdi+0x88]
       mov      rcx, gword ptr [rcx+0x20]
       test     rcx, rcx
       jne      G_M000_IG323
       mov      rdi, gword ptr [rdi+0x178]
       test     rdi, rdi
       jne      G_M000_IG324
 
G_M000_IG30:                ;; offset=0x03A3
       lea      r13, bword ptr [rbx+0x48]
       mov      rdi, r14
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LocalSlot():int:this]
       cmp      eax, dword ptr [r13+0x08]
       jae      G_M000_IG379
       mov      rdi, bword ptr [r13]
       mov      esi, eax
       lea      rdi, bword ptr [rdi+8*rsi]
       mov      rsi, r12
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       jmp      G_M000_IG163
 
G_M000_IG31:                ;; offset=0x03D1
       mov      esi, dword ptr [r14+0x10]
       test     esi, esi
       jl       SHORT G_M000_IG38
 
G_M000_IG32:                ;; offset=0x03D9
       lea      rdi, bword ptr [rbx+0x48]
       cmp      esi, dword ptr [rdi+0x08]
       jae      G_M000_IG379
       mov      rdi, bword ptr [rdi]
       mov      r11d, esi
       mov      r13, gword ptr [rdi+8*r11]
       test     r13, r13
       je       G_M000_IG252
 
G_M000_IG33:                ;; offset=0x03F9
       mov      esi, dword ptr [r14+0x0C]
       test     esi, esi
       jl       G_M000_IG40
 
G_M000_IG34:                ;; offset=0x0405
       lea      rdi, bword ptr [rbx+0x48]
       cmp      esi, dword ptr [rdi+0x08]
       jae      G_M000_IG379
       mov      rdi, bword ptr [rdi]
       mov      r11d, esi
       mov      r12, gword ptr [rdi+8*r11]
       test     r12, r12
       je       G_M000_IG254
 
G_M000_IG35:                ;; offset=0x0425
       test     r13, r13
       jne      G_M000_IG42
 
G_M000_IG36:                ;; offset=0x042E
       xor      eax, eax
 
G_M000_IG37:                ;; offset=0x0430
       vzeroupper 
       add      rsp, 648
       pop      rbx
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG38:                ;; offset=0x0445
       mov      rdi, gword ptr [rbx+0x08]
       mov      rdi, gword ptr [rdi+0x10]
       mov      r11, 0x78C06CC927A0
       cmp      qword ptr [rdi], r11
       jne      G_M000_IG251
       not      esi
       mov      r12d, dword ptr [rdi+0x08]
       cmp      r12d, esi
       jbe      G_M000_IG361
       mov      rdi, gword ptr [rdi+8*rsi+0x10]
 
G_M000_IG39:                ;; offset=0x0474
       call     [Lokad.Lython.Runtime.LythonRuntime:RuntimeValue(System.Object):System.Object]
       mov      r13, rax
       jmp      G_M000_IG33
 
G_M000_IG40:                ;; offset=0x0482
       mov      rdi, gword ptr [rbx+0x08]
       mov      rdi, gword ptr [rdi+0x10]
       mov      r11, 0x78C06CC927A0
       cmp      qword ptr [rdi], r11
       jne      G_M000_IG253
       not      esi
       mov      r11d, dword ptr [rdi+0x08]
       cmp      r11d, esi
       jbe      G_M000_IG361
       mov      rdi, gword ptr [rdi+8*rsi+0x10]
 
G_M000_IG41:                ;; offset=0x04B1
       call     [Lokad.Lython.Runtime.LythonRuntime:RuntimeValue(System.Object):System.Object]
       mov      r12, rax
       jmp      G_M000_IG35
 
G_M000_IG42:                ;; offset=0x04BF
       mov      rdi, 0x78C06E43DDA8
       cmp      qword ptr [r13], rdi
       jne      G_M000_IG36
 
G_M000_IG43:                ;; offset=0x04D3
       cmp      gword ptr [r13+0x28], 0
       je       G_M000_IG255
       cmp      dword ptr [r13+0x50], 0
       jne      G_M000_IG36
 
G_M000_IG44:                ;; offset=0x04E9
       test     r12, r12
       je       G_M000_IG36
 
G_M000_IG45:                ;; offset=0x04F2
       mov      rdi, 0x78C06E0B75A0
       cmp      qword ptr [r12], rdi
       jne      G_M000_IG36
 
G_M000_IG46:                ;; offset=0x0506
       cmp      dword ptr [r14+0x1C], 44
       jne      G_M000_IG256
       mov      edi, dword ptr [r14+0x08]
 
G_M000_IG47:                ;; offset=0x0515
       test     edi, edi
       jl       G_M000_IG271
       cmp      gword ptr [r13+0x20], 0
       je       G_M000_IG271
       mov      rax, gword ptr [rbx]
       mov      gword ptr [rbp-0x158], rax
       mov      rcx, gword ptr [r14]
       mov      gword ptr [rbp-0x220], rcx
       mov      rdx, gword ptr [rax+0x78]
       test     rdx, rdx
       je       G_M000_IG258
 
G_M000_IG48:                ;; offset=0x0549
       cmp      dword ptr [r14+0x1C], 44
       jne      G_M000_IG267
       mov      edi, dword ptr [r14+0x08]
 
G_M000_IG49:                ;; offset=0x0558
       cmp      edi, dword ptr [rdx+0x08]
       jae      G_M000_IG379
       mov      edi, edi
       lea      rdi, [rdi+2*rdi]
       lea      rax, bword ptr [rdx+8*rdi+0x10]
       mov      bword ptr [rbp-0x160], rax
       mov      rcx, gword ptr [rbx+0x18]
       mov      gword ptr [rbp-0x168], rcx
       mov      rdx, gword ptr [r14]
       mov      gword ptr [rbp-0x250], rdx
       mov      rdi, gword ptr [rcx+0xA0]
       mov      rsi, gword ptr [rdi+0x88]
       mov      rsi, gword ptr [rsi+0x20]
       test     rsi, rsi
       jne      G_M000_IG269
       mov      rcx, gword ptr [rbp-0x168]
       mov      rdi, gword ptr [rdi+0x178]
       test     rdi, rdi
       jne      G_M000_IG270
 
G_M000_IG50:                ;; offset=0x05BA
       mov      r8, gword ptr [r13+0x20]
       mov      gword ptr [rbp-0x258], r8
       test     r8, r8
       je       G_M000_IG271
       mov      rax, bword ptr [rbp-0x160]
       cmp      gword ptr [rax], r8
       jne      G_M000_IG273
 
G_M000_IG51:                ;; offset=0x05DE
       cmp      gword ptr [rax+0x08], r12
       jne      G_M000_IG272
       mov      r9d, dword ptr [rax+0x10]
 
G_M000_IG52:                ;; offset=0x05EC
       cmp      gword ptr [r13+0x20], 0
       je       SHORT G_M000_IG54
 
G_M000_IG53:                ;; offset=0x05F3
       mov      rdi, gword ptr [r13+0x30]
       cmp      dword ptr [rdi+0x08], r9d
       jbe      G_M000_IG274
       cmp      r9d, dword ptr [rdi+0x08]
       jae      G_M000_IG379
       mov      eax, r9d
       cmp      gword ptr [rdi+8*rax+0x10], 0
       je       G_M000_IG274
 
G_M000_IG54:                ;; offset=0x061A
       mov      rdi, gword ptr [r13+0x30]
       mov      rax, rdi
       cmp      r9d, dword ptr [rax+0x08]
       jae      G_M000_IG379
       mov      edi, r9d
       mov      rax, gword ptr [rax+8*rdi+0x10]
 
G_M000_IG55:                ;; offset=0x0633
       mov      gword ptr [rbp-0x148], rax
       test     rax, rax
       je       G_M000_IG271
       mov      rax, gword ptr [rbp-0x148]
       mov      r13d, dword ptr [r14+0x18]
       test     r13d, r13d
       jl       G_M000_IG278
 
G_M000_IG56:                ;; offset=0x0657
       mov      edi, dword ptr [r14+0x1C]
       cmp      edi, 52
       ja       SHORT G_M000_IG58
 
G_M000_IG57:                ;; offset=0x0660
       mov      rcx, 0xFFFFFFFFFE7FF
       bt       rcx, rdi
       jae      G_M000_IG275
 
G_M000_IG58:                ;; offset=0x0674
       mov      r13d, dword ptr [r14+0x14]
 
G_M000_IG59:                ;; offset=0x0678
       mov      r14d, dword ptr [r14+0x18]
       test     r14d, r14d
       jl       G_M000_IG276
 
G_M000_IG60:                ;; offset=0x0685
       cmp      r14d, dword ptr [rbx+0x3C]
       jl       G_M000_IG277
 
G_M000_IG61:                ;; offset=0x068F
       lea      rdi, bword ptr [rbx+0x48]
       cmp      r13d, dword ptr [rdi+0x08]
       jae      G_M000_IG379
       mov      rdi, bword ptr [rdi]
       mov      esi, r13d
       lea      rdi, bword ptr [rdi+8*rsi]
       mov      rsi, rax
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      dword ptr [rbx+0x3C], r14d
       jmp      SHORT G_M000_IG63
 
G_M000_IG62:                ;; offset=0x06B5
       mov      rdi, rbx
       mov      rsi, r14
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Call(byref):bool:this]
       test     eax, eax
       je       G_M000_IG36
 
G_M000_IG63:                ;; offset=0x06C9
       inc      dword ptr [rbx+0x38]
 
G_M000_IG64:                ;; offset=0x06CC
       mov      esi, dword ptr [rbx+0x38]
       mov      rdi, gword ptr [rbx+0x08]
       mov      rdi, gword ptr [rdi+0x50]
       cmp      esi, dword ptr [rdi+0x08]
       jge      G_M000_IG194
 
G_M000_IG65:                ;; offset=0x06E0
       mov      rdi, gword ptr [rbx+0x08]
       mov      rdi, gword ptr [rdi+0x50]
       mov      eax, dword ptr [rbx+0x38]
       cmp      eax, dword ptr [rdi+0x08]
       jae      G_M000_IG379
       shl      rax, 5
       lea      r14, bword ptr [rdi+rax+0x10]
       mov      rdi, gword ptr [rbx+0x18]
       mov      rdi, gword ptr [rdi+0xA0]
       mov      rax, gword ptr [r14]
       mov      rcx, gword ptr [rdi+0x88]
       mov      rcx, gword ptr [rcx+0x20]
       test     rcx, rcx
       jne      G_M000_IG358
       mov      rdi, gword ptr [rdi+0x178]
       test     rdi, rdi
       jne      G_M000_IG205
 
G_M000_IG66:                ;; offset=0x072F
       mov      edi, dword ptr [r14+0x1C]
       lea      r13d, [rdi-0x03]
       cmp      r13d, 3
       jbe      G_M000_IG87
 
G_M000_IG67:                ;; offset=0x0741
       add      edi, -25
       cmp      edi, 43
       ja       G_M000_IG359
       lea      rsi, [reloc @RWD00]
       mov      esi, dword ptr [rsi+4*rdi]
       lea      rax, G_M000_IG02
       add      rsi, rax
       jmp      rsi
 
G_M000_IG68:                ;; offset=0x0763
       mov      esi, dword ptr [r14+0x10]
       test     esi, esi
       jl       G_M000_IG03
 
G_M000_IG69:                ;; offset=0x076F
       lea      rdi, bword ptr [rbx+0x48]
       cmp      esi, dword ptr [rdi+0x08]
       jae      G_M000_IG379
       mov      rdi, bword ptr [rdi]
       mov      r11d, esi
       mov      r13, gword ptr [rdi+8*r11]
       test     r13, r13
       je       G_M000_IG300
 
G_M000_IG70:                ;; offset=0x078F
       mov      esi, dword ptr [r14+0x0C]
       test     esi, esi
       jl       G_M000_IG05
 
G_M000_IG71:                ;; offset=0x079B
       lea      rdi, bword ptr [rbx+0x48]
       cmp      esi, dword ptr [rdi+0x08]
       jae      G_M000_IG379
       mov      rdi, bword ptr [rdi]
       mov      r11d, esi
       mov      r12, gword ptr [rdi+8*r11]
       test     r12, r12
       je       G_M000_IG303
 
G_M000_IG72:                ;; offset=0x07BB
       cmp      dword ptr [r14+0x1C], 48
       sete     al
       movzx    rax, al
       mov      dword ptr [rbp-0x3C], eax
       test     eax, eax
       jne      G_M000_IG314
 
G_M000_IG73:                ;; offset=0x07D1
       mov      rdi, gword ptr [rbx+0x08]
       mov      rsi, bword ptr [rbx+0x48]
       mov      edx, dword ptr [rbx+0x50]
       mov      rcx, gword ptr [rbx+0x18]
       mov      gword ptr [rsp], rcx
       lea      rcx, [rbp-0x48]
       mov      qword ptr [rsp+0x08], rcx
       lea      rcx, [rbp-0x50]
       mov      qword ptr [rsp+0x10], rcx
       mov      ecx, dword ptr [rbx+0x38]
       mov      r8, r13
       mov      r9, r12
       call     [Lokad.Lython.Runtime.LythonRuntime:TryIntegerChain(Lokad.Lython.Frontend.ExecutableCodeObject,System.ReadOnlySpan`1[System.Object],int,System.Object,System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,byref):bool]
       test     eax, eax
       jne      G_M000_IG07
 
G_M000_IG74:                ;; offset=0x080D
       cmp      dword ptr [r14+0x1C], 52
       je       G_M000_IG309
       mov      edi, dword ptr [r14+0x08]
 
G_M000_IG75:                ;; offset=0x081C
       mov      rcx, gword ptr [rbx+0x18]
       mov      r8, gword ptr [r14]
       lea      r9, [rbp-0x58]
       mov      rsi, r13
       mov      rdx, r12
       call     [Lokad.Lython.Runtime.LythonRuntime:TryEvaluateScalarComparison(int,System.Object,System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,byref):bool]
       test     eax, eax
       jne      G_M000_IG310
       cmp      dword ptr [r14+0x1C], 52
       je       G_M000_IG313
       mov      edi, dword ptr [r14+0x08]
 
G_M000_IG76:                ;; offset=0x084A
       mov      rsi, r13
       mov      rdx, r12
       call     [Lokad.Lython.Runtime.LythonRuntime:CanUseNativeBinary(int,System.Object,System.Object):bool]
       test     eax, eax
       je       G_M000_IG36
       cmp      dword ptr [rbp-0x3C], 0
       jne      G_M000_IG315
       cmp      dword ptr [r14+0x1C], 52
       je       G_M000_IG317
       mov      edi, dword ptr [r14+0x08]
 
G_M000_IG77:                ;; offset=0x0877
       mov      rcx, gword ptr [rbx+0x18]
       mov      r8, gword ptr [r14]
       mov      rsi, r13
       mov      rdx, r12
       call     [Lokad.Lython.Runtime.LythonRuntime:EvaluateBinaryOperator(int,System.Object,System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):System.Object]
       mov      r12, rax
 
G_M000_IG78:                ;; offset=0x088D
       cmp      dword ptr [r14+0x18], 0
       jl       G_M000_IG21
 
G_M000_IG79:                ;; offset=0x0898
       mov      edi, dword ptr [r14+0x1C]
       cmp      edi, 52
       ja       SHORT G_M000_IG81
 
G_M000_IG80:                ;; offset=0x08A1
       mov      rax, 0xFFFFFFFFFE7FF
       bt       rax, rdi
       jae      G_M000_IG319
 
G_M000_IG81:                ;; offset=0x08B5
       mov      r13d, dword ptr [r14+0x14]
 
G_M000_IG82:                ;; offset=0x08B9
       cmp      dword ptr [r14+0x18], 0
       jl       G_M000_IG20
 
G_M000_IG83:                ;; offset=0x08C4
       mov      r14d, dword ptr [r14+0x18]
 
G_M000_IG84:                ;; offset=0x08C8
       cmp      r14d, dword ptr [rbx+0x3C]
       jl       G_M000_IG320
 
G_M000_IG85:                ;; offset=0x08D2
       lea      rdi, bword ptr [rbx+0x48]
       cmp      r13d, dword ptr [rdi+0x08]
       jae      G_M000_IG379
       mov      rdi, bword ptr [rdi]
       mov      esi, r13d
       lea      rdi, bword ptr [rdi+8*rsi]
       mov      rsi, r12
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      dword ptr [rbx+0x3C], r14d
       jmp      G_M000_IG63
 
G_M000_IG86:                ;; offset=0x08FB
       mov      rdi, rbx
       mov      rsi, r14
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:TryReturnUnpackedTuple(byref):bool:this]
       test     eax, eax
       jne      G_M000_IG194
       jmp      G_M000_IG339
 
G_M000_IG87:                ;; offset=0x0914
       mov      edi, r13d
       lea      rax, [reloc @RWD176]
       mov      eax, dword ptr [rax+4*rdi]
       lea      rcx, G_M000_IG02
       add      rax, rcx
       jmp      rax
 
G_M000_IG88:                ;; offset=0x092D
       mov      rdi, gword ptr [rbx+0x08]
       mov      r13, gword ptr [rdi+0x18]
       mov      rdi, r14
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_NameIndex():int:this]
       mov      rdi, 0x78C06CD6BEC0
       cmp      qword ptr [r13], rdi
       jne      G_M000_IG215
       cmp      dword ptr [r13+0x08], eax
       jbe      G_M000_IG361
       mov      edi, eax
       mov      r12, gword ptr [r13+8*rdi+0x10]
 
G_M000_IG89:                ;; offset=0x0963
       mov      r13, gword ptr [r14]
       mov      gword ptr [rbp-0x198], r13
       mov      rax, gword ptr [rbx+0x18]
       mov      gword ptr [rbp-0x188], rax
       mov      rcx, rax
       mov      r13, gword ptr [rbp-0x198]
 
G_M000_IG90:                ;; offset=0x0982
       mov      rsi, gword ptr [rcx+0x10]
       mov      rdi, rsi
       test     rdi, rdi
       je       SHORT G_M000_IG92
 
G_M000_IG91:                ;; offset=0x098E
       mov      rdx, 0x78C06E0B52B0
       cmp      qword ptr [rdi], rdx
       jne      G_M000_IG217
 
G_M000_IG92:                ;; offset=0x09A1
       test     rdi, rdi
       jne      G_M000_IG216
       mov      gword ptr [rbp-0x1A0], rcx
       movzx    rdi, byte  ptr [rcx+0x102]
       test     edi, edi
       je       G_M000_IG115
       mov      rsi, rcx
       test     rsi, rsi
       je       G_M000_IG115
 
G_M000_IG93:                ;; offset=0x09CD
       test     edi, edi
       je       G_M000_IG218
       mov      rdx, rcx
 
G_M000_IG94:                ;; offset=0x09D8
       cmp      byte  ptr [rdx], dl
       xor      edi, edi
       mov      dword ptr [rbp-0xB0], edi
 
G_M000_IG95:                ;; offset=0x09E2
       mov      dword ptr [rbp-0xB8], edi
       mov      gword ptr [rbp-0x1A8], rdx
       mov      rdi, gword ptr [rdx+0x108]
       mov      r8, gword ptr [rdi+0x28]
       mov      rdi, 0x78C06DFAECA8
       cmp      qword ptr [r8], rdi
       jne      G_M000_IG223
       mov      gword ptr [rbp-0x1B0], r8
       test     r12, r12
       je       G_M000_IG371
       cmp      gword ptr [r8+0x08], 0
       je       G_M000_IG113
 
G_M000_IG96:                ;; offset=0x0A28
       mov      r9, gword ptr [r8+0x18]
       mov      gword ptr [rbp-0x1C0], r9
       mov      rdi, 0x78C06CD684D8
       cmp      qword ptr [r9], rdi
       jne      G_M000_IG220
       lea      rdi, bword ptr [r12+0x0C]
       mov      bword ptr [rbp-0xC8], rdi
       mov      edi, 0x15051505
       mov      esi, 0x15051505
       mov      r11, bword ptr [rbp-0xC8]
       mov      r10d, dword ptr [r12+0x08]
       cmp      r10d, 2
       jle      SHORT G_M000_IG98
 
G_M000_IG97:                ;; offset=0x0A6E
       add      r10d, -4
       mov      r13d, edi
       rol      r13d, 5
       add      edi, r13d
       xor      edi, dword ptr [r11]
       mov      r13d, esi
       rol      r13d, 5
       add      esi, r13d
       xor      esi, dword ptr [r11+0x04]
       add      r11, 8
       cmp      r10d, 2
       jg       SHORT G_M000_IG97
 
G_M000_IG98:                ;; offset=0x0A97
       test     r10d, r10d
       jg       G_M000_IG219
 
G_M000_IG99:                ;; offset=0x0AA0
       imul     r13d, esi, 0x5D588B65
       add      r13d, edi
       xor      rdi, rdi
       mov      bword ptr [rbp-0xC8], rdi
 
G_M000_IG100:                ;; offset=0x0AB3
       mov      r8, gword ptr [rbp-0x1B0]
       mov      rsi, gword ptr [r8+0x08]
       mov      edi, r13d
       imul     rdi, qword ptr [r8+0x30]
       shr      rdi, 32
       inc      rdi
       mov      r10d, dword ptr [rsi+0x08]
       imul     rdi, r10
       shr      rdi, 32
       cmp      edi, dword ptr [rsi+0x08]
       jae      G_M000_IG379
       mov      edi, edi
       lea      rsi, bword ptr [rsi+4*rdi+0x10]
       mov      esi, dword ptr [rsi]
       mov      r8, gword ptr [r8+0x10]
       mov      gword ptr [rbp-0x1C8], r8
       xor      r10d, r10d
       mov      dword ptr [rbp-0xBC], r10d
       dec      esi
       cmp      dword ptr [r8+0x08], esi
       jbe      G_M000_IG112
 
G_M000_IG101:                ;; offset=0x0B0C
       mov      esi, esi
       lea      rsi, [rsi+2*rsi]
       lea      r11, bword ptr [r8+8*rsi+0x10]
       mov      bword ptr [rbp-0x1B8], r11
       cmp      dword ptr [r11+0x08], r13d
       je       SHORT G_M000_IG104
 
G_M000_IG102:                ;; offset=0x0B24
       mov      esi, dword ptr [r11+0x0C]
       mov      r10d, dword ptr [rbp-0xBC]
       inc      r10d
       mov      r8, gword ptr [rbp-0x1C8]
       cmp      dword ptr [r8+0x08], r10d
       jb       G_M000_IG372
       cmp      dword ptr [r8+0x08], esi
       mov      dword ptr [rbp-0xBC], r10d
       ja       SHORT G_M000_IG101
 
G_M000_IG103:                ;; offset=0x0B50
       mov      r13, gword ptr [rbp-0x198]
       jmp      G_M000_IG113
 
G_M000_IG104:                ;; offset=0x0B5C
       mov      rsi, gword ptr [r11]
       mov      rdi, 0x78C06CD684D8
       cmp      qword ptr [r9], rdi
       jne      G_M000_IG222
       mov      r9, gword ptr [rbp-0x1C0]
       cmp      rsi, r12
       je       G_M000_IG111
 
G_M000_IG105:                ;; offset=0x0B82
       test     rsi, rsi
       je       G_M000_IG221
       mov      edi, dword ptr [rsi+0x08]
       cmp      edi, dword ptr [r12+0x08]
       jne      G_M000_IG221
 
G_M000_IG106:                ;; offset=0x0B99
       add      rsi, 12
       mov      bword ptr [rbp-0x1D0], rsi
       add      edi, edi
       mov      edx, edi
       lea      rsi, bword ptr [r12+0x0C]
       mov      rdi, bword ptr [rbp-0x1D0]
       call     [System.SpanHelpers:SequenceEqual(byref,byref,nuint):bool]
       mov      r9, gword ptr [rbp-0x1C0]
 
G_M000_IG107:                ;; offset=0x0BC1
       test     eax, eax
       mov      r11, bword ptr [rbp-0x1B8]
       je       G_M000_IG102
       add      r11, 16
       mov      edi, dword ptr [r11]
       mov      dword ptr [rbp-0xB0], edi
       mov      r13, gword ptr [rbp-0x198]
 
G_M000_IG108:                ;; offset=0x0BE4
       mov      rdx, gword ptr [rbp-0x1A8]
       mov      rdi, gword ptr [rdx+0x110]
       mov      esi, dword ptr [rbp-0xB0]
       cmp      esi, dword ptr [rdi+0x08]
       jae      G_M000_IG379
       mov      rdi, gword ptr [rdi+8*rsi+0x10]
       test     rdi, rdi
       jne      G_M000_IG198
 
G_M000_IG109:                ;; offset=0x0C0F
       mov      r8, rdi
 
G_M000_IG110:                ;; offset=0x0C12
       test     r8, r8
       je       SHORT G_M000_IG114
       mov      r13, r8
       mov      rax, r13
       jmp      G_M000_IG136
 
G_M000_IG111:                ;; offset=0x0C22
       mov      edi, 1
       mov      eax, edi
       jmp      SHORT G_M000_IG107
 
G_M000_IG112:                ;; offset=0x0C2B
       mov      r13, gword ptr [rbp-0x198]
 
G_M000_IG113:                ;; offset=0x0C32
       xor      edi, edi
       mov      dword ptr [rbp-0xB0], edi
 
G_M000_IG114:                ;; offset=0x0C3A
       mov      rdx, gword ptr [rbp-0x1A8]
       cmp      gword ptr [rdx+0x118], 0
       jne      G_M000_IG224
       mov      rcx, gword ptr [rbp-0x1A0]
 
G_M000_IG115:                ;; offset=0x0C56
       mov      rdx, gword ptr [rcx+0x08]
       test     rdx, rdx
       je       G_M000_IG226
 
G_M000_IG116:                ;; offset=0x0C63
       mov      rcx, rdx
       mov      gword ptr [rbp-0x1D8], rcx
       cmp      byte  ptr [rcx], cl
       test     r12, r12
       je       G_M000_IG371
       cmp      gword ptr [rcx+0x08], 0
       je       G_M000_IG125
 
G_M000_IG117:                ;; offset=0x0C83
       mov      rdx, gword ptr [rcx+0x18]
       mov      gword ptr [rbp-0x1E8], rdx
       mov      rdi, 0x78C06CD684D8
       cmp      qword ptr [rdx], rdi
       jne      G_M000_IG228
       lea      rdi, bword ptr [r12+0x0C]
       mov      bword ptr [rbp-0xD8], rdi
       mov      edi, 0x15051505
       mov      esi, 0x15051505
       mov      r11, bword ptr [rbp-0xD8]
       mov      r8d, dword ptr [r12+0x08]
       cmp      r8d, 2
       jle      SHORT G_M000_IG119
 
G_M000_IG118:                ;; offset=0x0CC9
       add      r8d, -4
       mov      r9d, edi
       rol      r9d, 5
       add      edi, r9d
       xor      edi, dword ptr [r11]
       mov      r9d, esi
       rol      r9d, 5
       add      esi, r9d
       xor      esi, dword ptr [r11+0x04]
       add      r11, 8
       cmp      r8d, 2
       jg       SHORT G_M000_IG118
 
G_M000_IG119:                ;; offset=0x0CF2
       test     r8d, r8d
       jg       G_M000_IG227
 
G_M000_IG120:                ;; offset=0x0CFB
       imul     r8d, esi, 0x5D588B65
       add      r8d, edi
       xor      rdi, rdi
       mov      bword ptr [rbp-0xD8], rdi
 
G_M000_IG121:                ;; offset=0x0D0E
       mov      dword ptr [rbp-0xCC], r8d
       mov      rcx, gword ptr [rbp-0x1D8]
       mov      rsi, gword ptr [rcx+0x08]
       mov      edi, r8d
       imul     rdi, qword ptr [rcx+0x30]
       shr      rdi, 32
       inc      rdi
       mov      r9d, dword ptr [rsi+0x08]
       mov      r10d, r9d
       imul     rdi, r10
       shr      rdi, 32
       cmp      edi, r9d
       jae      G_M000_IG379
       mov      edi, edi
       lea      rsi, bword ptr [rsi+4*rdi+0x10]
       mov      esi, dword ptr [rsi]
       mov      rcx, gword ptr [rcx+0x10]
       mov      gword ptr [rbp-0x1F0], rcx
       xor      r9d, r9d
       mov      dword ptr [rbp-0xD0], r9d
       dec      esi
       mov      r10d, dword ptr [rcx+0x08]
       mov      dword ptr [rbp-0x13C], r10d
       cmp      r10d, esi
       jbe      SHORT G_M000_IG125
 
G_M000_IG122:                ;; offset=0x0D77
       mov      esi, esi
       lea      rsi, [rsi+2*rsi]
       lea      r11, bword ptr [rcx+8*rsi+0x10]
       mov      bword ptr [rbp-0x1E0], r11
       cmp      dword ptr [r11+0x10], r8d
       je       G_M000_IG200
 
G_M000_IG123:                ;; offset=0x0D93
       mov      esi, dword ptr [r11+0x14]
       mov      r9d, dword ptr [rbp-0xD0]
       inc      r9d
       mov      r10d, dword ptr [rbp-0x13C]
       cmp      r10d, r9d
       jb       G_M000_IG372
 
G_M000_IG124:                ;; offset=0x0DB1
       cmp      r10d, esi
       mov      dword ptr [rbp-0xD0], r9d
       mov      rcx, gword ptr [rbp-0x1F0]
       mov      r8d, dword ptr [rbp-0xCC]
       ja       SHORT G_M000_IG122
 
G_M000_IG125:                ;; offset=0x0DCB
       mov      rax, gword ptr [rbp-0x188]
       mov      rdi, gword ptr [rax+0xA0]
       mov      rax, gword ptr [rdi+0xF0]
       mov      gword ptr [rbp-0x200], rax
       cmp      byte  ptr [rax], al
       cmp      gword ptr [rax+0x08], 0
       je       G_M000_IG134
 
G_M000_IG126:                ;; offset=0x0DF4
       mov      rcx, gword ptr [rax+0x18]
       mov      gword ptr [rbp-0x210], rcx
       mov      rdi, 0x78C06CD684D8
       cmp      qword ptr [rcx], rdi
       jne      G_M000_IG232
       lea      rdi, bword ptr [r12+0x0C]
       mov      bword ptr [rbp-0xE8], rdi
       mov      edi, 0x15051505
       mov      esi, 0x15051505
       mov      r11, bword ptr [rbp-0xE8]
       mov      edx, dword ptr [r12+0x08]
       cmp      edx, 2
       jle      SHORT G_M000_IG128
 
G_M000_IG127:                ;; offset=0x0E39
       add      edx, -4
       mov      r8d, edi
       rol      r8d, 5
       add      edi, r8d
       xor      edi, dword ptr [r11]
       mov      r8d, esi
       rol      r8d, 5
       add      esi, r8d
       xor      esi, dword ptr [r11+0x04]
       add      r11, 8
       cmp      edx, 2
       jg       SHORT G_M000_IG127
 
G_M000_IG128:                ;; offset=0x0E60
       test     edx, edx
       jg       G_M000_IG231
 
G_M000_IG129:                ;; offset=0x0E68
       imul     edx, esi, 0x5D588B65
       add      edx, edi
       xor      rdi, rdi
       mov      bword ptr [rbp-0xE8], rdi
 
G_M000_IG130:                ;; offset=0x0E79
       mov      r8d, edx
       mov      dword ptr [rbp-0xDC], r8d
       mov      rax, gword ptr [rbp-0x200]
       mov      rdx, gword ptr [rax+0x08]
       mov      esi, r8d
       imul     rsi, qword ptr [rax+0x30]
       shr      rsi, 32
       inc      rsi
       mov      edi, dword ptr [rdx+0x08]
       mov      r9d, edi
       imul     rsi, r9
       shr      rsi, 32
       cmp      esi, edi
       jae      G_M000_IG379
       mov      esi, esi
       lea      rdx, bword ptr [rdx+4*rsi+0x10]
       mov      edx, dword ptr [rdx]
       mov      rax, gword ptr [rax+0x10]
       mov      gword ptr [rbp-0x218], rax
       xor      r9d, r9d
       mov      dword ptr [rbp-0xE0], r9d
       dec      edx
       mov      r10d, dword ptr [rax+0x08]
       mov      dword ptr [rbp-0x140], r10d
       cmp      r10d, edx
       jbe      SHORT G_M000_IG134
 
G_M000_IG131:                ;; offset=0x0EE3
       mov      edx, edx
       lea      rdx, [rdx+2*rdx]
       lea      r11, bword ptr [rax+8*rdx+0x10]
       mov      bword ptr [rbp-0x208], r11
       cmp      dword ptr [r11+0x10], r8d
       je       G_M000_IG143
 
G_M000_IG132:                ;; offset=0x0EFF
       mov      edx, dword ptr [r11+0x14]
       mov      r9d, dword ptr [rbp-0xE0]
       inc      r9d
       mov      r10d, dword ptr [rbp-0x140]
       cmp      r10d, r9d
       jb       G_M000_IG372
 
G_M000_IG133:                ;; offset=0x0F1D
       cmp      r10d, edx
       mov      dword ptr [rbp-0xE0], r9d
       mov      rax, gword ptr [rbp-0x218]
       mov      r8d, dword ptr [rbp-0xDC]
       ja       SHORT G_M000_IG131
 
G_M000_IG134:                ;; offset=0x0F37
       xor      rax, rax
       xor      edi, edi
 
G_M000_IG135:                ;; offset=0x0F3B
       test     edi, edi
       je       G_M000_IG373
 
G_M000_IG136:                ;; offset=0x0F43
       mov      gword ptr [rbp-0x190], rax
       mov      r12, rax
       cmp      dword ptr [r14+0x18], 0
       jl       G_M000_IG149
 
G_M000_IG137:                ;; offset=0x0F58
       mov      rax, gword ptr [rbp-0x190]
       mov      edi, dword ptr [r14+0x1C]
       cmp      edi, 52
       ja       SHORT G_M000_IG139
 
G_M000_IG138:                ;; offset=0x0F68
       mov      rcx, 0xFFFFFFFFFE7FF
       bt       rcx, rdi
       jae      G_M000_IG235
 
G_M000_IG139:                ;; offset=0x0F7C
       mov      r12d, dword ptr [r14+0x14]
 
G_M000_IG140:                ;; offset=0x0F80
       mov      r14d, dword ptr [r14+0x18]
       test     r14d, r14d
       jl       G_M000_IG148
 
G_M000_IG141:                ;; offset=0x0F8D
       cmp      r14d, dword ptr [rbx+0x3C]
       jl       G_M000_IG236
 
G_M000_IG142:                ;; offset=0x0F97
       lea      rdi, bword ptr [rbx+0x48]
       cmp      r12d, dword ptr [rdi+0x08]
       jae      G_M000_IG379
       mov      rdi, bword ptr [rdi]
       mov      esi, r12d
       lea      rdi, bword ptr [rdi+8*rsi]
       mov      rsi, rax
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      dword ptr [rbx+0x3C], r14d
       jmp      G_M000_IG63
 
G_M000_IG143:                ;; offset=0x0FC0
       mov      rsi, gword ptr [r11]
       mov      rdx, 0x78C06CD684D8
       cmp      qword ptr [rcx], rdx
       jne      G_M000_IG234
       mov      rcx, gword ptr [rbp-0x210]
       cmp      rsi, r12
       je       SHORT G_M000_IG147
 
G_M000_IG144:                ;; offset=0x0FE2
       test     rsi, rsi
       je       G_M000_IG233
       mov      edx, dword ptr [rsi+0x08]
       cmp      edx, dword ptr [r12+0x08]
       jne      G_M000_IG233
 
G_M000_IG145:                ;; offset=0x0FF9
       lea      rdi, bword ptr [rsi+0x0C]
       add      edx, edx
       lea      rsi, bword ptr [r12+0x0C]
       call     [System.SpanHelpers:SequenceEqual(byref,byref,nuint):bool]
       mov      rcx, gword ptr [rbp-0x210]
 
G_M000_IG146:                ;; offset=0x1011
       test     eax, eax
       mov      r11, bword ptr [rbp-0x208]
       je       G_M000_IG132
       add      r11, 8
       mov      rdi, gword ptr [r11]
       mov      rax, rdi
       mov      edi, 1
       jmp      G_M000_IG135
 
G_M000_IG147:                ;; offset=0x1034
       mov      edi, 1
       mov      eax, edi
       jmp      SHORT G_M000_IG146
 
G_M000_IG148:                ;; offset=0x103D
       not      r14d
       jmp      G_M000_IG141
 
G_M000_IG149:                ;; offset=0x1045
       mov      esi, dword ptr [r14+0x18]
       mov      r13d, esi
       not      r13d
       mov      esi, r13d
       mov      eax, dword ptr [rbx+0x3C]
       cmp      esi, eax
       jge      SHORT G_M000_IG153
 
G_M000_IG150:                ;; offset=0x1059
       dec      eax
       mov      rsi, gword ptr [rbx+0x08]
       mov      ecx, dword ptr [rsi+0xA0]
       cmp      eax, ecx
       jle      G_M000_IG237
 
G_M000_IG151:                ;; offset=0x106D
       mov      eax, ecx
       cmp      eax, r13d
       jge      G_M000_IG238
 
G_M000_IG152:                ;; offset=0x1078
       mov      dword ptr [rbx+0x3C], r13d
 
G_M000_IG153:                ;; offset=0x107C
       lea      r13, bword ptr [rbx+0x48]
       mov      edi, dword ptr [r14+0x1C]
       cmp      edi, 52
       ja       SHORT G_M000_IG155
 
G_M000_IG154:                ;; offset=0x1089
       mov      rax, 0xFFFFFFFFFE7FF
       bt       rax, rdi
       jae      G_M000_IG240
 
G_M000_IG155:                ;; offset=0x109D
       mov      eax, dword ptr [r14+0x14]
 
G_M000_IG156:                ;; offset=0x10A1
       cmp      eax, dword ptr [r13+0x08]
       jae      G_M000_IG379
       mov      rdi, bword ptr [r13]
       mov      eax, eax
       xor      rcx, rcx
       mov      gword ptr [rdi+8*rax], rcx
       mov      edi, dword ptr [r14+0x1C]
       cmp      edi, 52
       ja       SHORT G_M000_IG158
 
G_M000_IG157:                ;; offset=0x10C0
       mov      rax, 0xFFFFFFFFFE7FF
       bt       rax, rdi
       jae      G_M000_IG241
 
G_M000_IG158:                ;; offset=0x10D4
       mov      eax, dword ptr [r14+0x14]
 
G_M000_IG159:                ;; offset=0x10D8
       mov      dword ptr [rbx+0x3C], eax
       mov      rdi, gword ptr [rbx+0x08]
       mov      rdi, gword ptr [rdi+0x50]
       mov      eax, dword ptr [rbx+0x38]
       inc      eax
       cmp      eax, dword ptr [rdi+0x08]
       jae      G_M000_IG379
       shl      rax, 5
       lea      r13, bword ptr [rdi+rax+0x10]
       mov      rdi, gword ptr [rbx+0x18]
       mov      rax, gword ptr [r13]
       mov      rdi, gword ptr [rdi+0xA0]
       mov      rcx, gword ptr [rdi+0x88]
       mov      rcx, gword ptr [rcx+0x20]
       test     rcx, rcx
       jne      G_M000_IG374
       mov      rdi, gword ptr [rdi+0x178]
       test     rdi, rdi
       jne      G_M000_IG242
 
G_M000_IG160:                ;; offset=0x112D
       lea      rdi, bword ptr [rbx+0x48]
       mov      esi, dword ptr [r13+0x1C]
       cmp      esi, 4
       je       SHORT G_M000_IG162
 
G_M000_IG161:                ;; offset=0x113A
       cmp      esi, 27
       jne      G_M000_IG375
 
G_M000_IG162:                ;; offset=0x1143
       mov      esi, dword ptr [r13+0x08]
       cmp      esi, dword ptr [rdi+0x08]
       jae      G_M000_IG379
       mov      rdi, bword ptr [rdi]
       lea      rdi, bword ptr [rdi+8*rsi]
       mov      rsi, r12
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
 
G_M000_IG163:                ;; offset=0x115F
       inc      dword ptr [rbx+0x38]
       jmp      G_M000_IG63
 
G_M000_IG164:                ;; offset=0x1167
       mov      edi, dword ptr [r14+0x1C]
       cmp      edi, 4
       je       SHORT G_M000_IG166
 
G_M000_IG165:                ;; offset=0x1170
       cmp      edi, 27
       jne      G_M000_IG367
 
G_M000_IG166:                ;; offset=0x1179
       mov      esi, dword ptr [r14+0x08]
       mov      r12, gword ptr [r14]
       lea      rdi, bword ptr [rbx+0x48]
       cmp      esi, dword ptr [rdi+0x08]
       jae      G_M000_IG379
       mov      rdi, bword ptr [rdi]
       mov      eax, esi
       mov      r13, gword ptr [rdi+8*rax]
       test     r13, r13
       je       G_M000_IG368
       mov      r12, r13
       cmp      dword ptr [r14+0x18], 0
       jl       SHORT G_M000_IG174
 
G_M000_IG167:                ;; offset=0x11A9
       mov      edi, dword ptr [r14+0x1C]
       cmp      edi, 52
       ja       SHORT G_M000_IG169
 
G_M000_IG168:                ;; offset=0x11B2
       mov      rax, 0xFFFFFFFFFE7FF
       bt       rax, rdi
       jae      G_M000_IG207
 
G_M000_IG169:                ;; offset=0x11C6
       mov      r12d, dword ptr [r14+0x14]
 
G_M000_IG170:                ;; offset=0x11CA
       mov      r14d, dword ptr [r14+0x18]
       test     r14d, r14d
       jl       SHORT G_M000_IG173
 
G_M000_IG171:                ;; offset=0x11D3
       cmp      r14d, dword ptr [rbx+0x3C]
       jl       G_M000_IG208
 
G_M000_IG172:                ;; offset=0x11DD
       lea      rdi, bword ptr [rbx+0x48]
       cmp      r12d, dword ptr [rdi+0x08]
       jae      G_M000_IG379
       mov      rdi, bword ptr [rdi]
       mov      esi, r12d
       lea      rdi, bword ptr [rdi+8*rsi]
       mov      rsi, r13
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      dword ptr [rbx+0x3C], r14d
       jmp      G_M000_IG63
 
G_M000_IG173:                ;; offset=0x1206
       not      r14d
       jmp      SHORT G_M000_IG171
 
G_M000_IG174:                ;; offset=0x120B
       mov      esi, dword ptr [r14+0x18]
       mov      r13d, esi
       not      r13d
       mov      esi, r13d
       mov      ecx, dword ptr [rbx+0x3C]
       cmp      esi, ecx
       jge      SHORT G_M000_IG178
 
G_M000_IG175:                ;; offset=0x121F
       dec      ecx
       mov      rsi, gword ptr [rbx+0x08]
       mov      eax, dword ptr [rsi+0xA0]
       cmp      ecx, eax
       jle      G_M000_IG209
 
G_M000_IG176:                ;; offset=0x1233
       cmp      eax, r13d
       jge      G_M000_IG210
 
G_M000_IG177:                ;; offset=0x123C
       mov      dword ptr [rbx+0x3C], r13d
 
G_M000_IG178:                ;; offset=0x1240
       lea      r13, bword ptr [rbx+0x48]
       mov      edi, dword ptr [r14+0x1C]
       cmp      edi, 52
       ja       SHORT G_M000_IG180
 
G_M000_IG179:                ;; offset=0x124D
       mov      rax, 0xFFFFFFFFFE7FF
       bt       rax, rdi
       jae      G_M000_IG212
 
G_M000_IG180:                ;; offset=0x1261
       mov      eax, dword ptr [r14+0x14]
 
G_M000_IG181:                ;; offset=0x1265
       cmp      eax, dword ptr [r13+0x08]
       jae      G_M000_IG379
       mov      rdi, bword ptr [r13]
       mov      eax, eax
       xor      rcx, rcx
       mov      gword ptr [rdi+8*rax], rcx
       mov      edi, dword ptr [r14+0x1C]
       cmp      edi, 52
       ja       SHORT G_M000_IG183
 
G_M000_IG182:                ;; offset=0x1284
       mov      rax, 0xFFFFFFFFFE7FF
       bt       rax, rdi
       jae      G_M000_IG213
 
G_M000_IG183:                ;; offset=0x1298
       mov      eax, dword ptr [r14+0x14]
 
G_M000_IG184:                ;; offset=0x129C
       mov      dword ptr [rbx+0x3C], eax
       mov      rdi, gword ptr [rbx+0x08]
       mov      rdi, gword ptr [rdi+0x50]
       mov      eax, dword ptr [rbx+0x38]
       inc      eax
       cmp      eax, dword ptr [rdi+0x08]
       jae      G_M000_IG379
       shl      rax, 5
       lea      r13, bword ptr [rdi+rax+0x10]
       mov      rdi, gword ptr [rbx+0x18]
       mov      rax, gword ptr [r13]
       mov      rdi, gword ptr [rdi+0xA0]
       mov      rcx, gword ptr [rdi+0x88]
       mov      rcx, gword ptr [rcx+0x20]
       test     rcx, rcx
       jne      G_M000_IG369
       mov      rdi, gword ptr [rdi+0x178]
       test     rdi, rdi
       jne      G_M000_IG214
 
G_M000_IG185:                ;; offset=0x12F1
       lea      rdi, bword ptr [rbx+0x48]
       mov      esi, dword ptr [r13+0x1C]
       cmp      esi, 4
       je       SHORT G_M000_IG187
 
G_M000_IG186:                ;; offset=0x12FE
       cmp      esi, 27
       jne      G_M000_IG370
 
G_M000_IG187:                ;; offset=0x1307
       mov      esi, dword ptr [r13+0x08]
       cmp      esi, dword ptr [rdi+0x08]
       jae      G_M000_IG379
       mov      rdi, bword ptr [rdi]
       lea      rdi, bword ptr [rdi+8*rsi]
       mov      rsi, r12
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       jmp      G_M000_IG163
 
G_M000_IG188:                ;; offset=0x1328
       mov      esi, dword ptr [r14+0x10]
       test     esi, esi
       jl       G_M000_IG196
 
G_M000_IG189:                ;; offset=0x1334
       lea      rdi, bword ptr [rbx+0x48]
       cmp      esi, dword ptr [rdi+0x08]
       jae      G_M000_IG379
       mov      rdi, bword ptr [rdi]
       mov      eax, esi
       mov      rdi, gword ptr [rdi+8*rax]
       test     rdi, rdi
       je       G_M000_IG363
       mov      gword ptr [rbp-0x180], rdi
 
G_M000_IG190:                ;; offset=0x135A
       mov      rsi, gword ptr [rbp-0x180]
       mov      rdi, r15
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      esi, dword ptr [r14+0x10]
       mov      rdi, gword ptr [rbx+0x08]
       cmp      esi, dword ptr [rdi+0x9C]
       jl       SHORT G_M000_IG192
 
G_M000_IG191:                ;; offset=0x1379
       lea      rsi, bword ptr [rbx+0x48]
       mov      edi, dword ptr [r14+0x10]
       cmp      edi, dword ptr [rsi+0x08]
       jae      G_M000_IG379
       mov      rsi, bword ptr [rsi]
       xor      rax, rax
       mov      gword ptr [rsi+8*rdi], rax
 
G_M000_IG192:                ;; offset=0x1393
       mov      rsi, gword ptr [rbx+0x08]
       mov      r14d, dword ptr [rsi+0x9C]
       mov      r15d, dword ptr [rbx+0x3C]
       dec      r15d
       mov      rsi, gword ptr [rbx+0x08]
       mov      esi, dword ptr [rsi+0xA0]
       cmp      r15d, esi
       cmovg    r15d, esi
       cmp      r15d, r14d
       jge      G_M000_IG365
 
G_M000_IG193:                ;; offset=0x13BF
       mov      dword ptr [rbx+0x3C], r14d
 
G_M000_IG194:                ;; offset=0x13C3
       mov      eax, 1
 
G_M000_IG195:                ;; offset=0x13C8
       vzeroupper 
       add      rsp, 648
       pop      rbx
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG196:                ;; offset=0x13DD
       mov      rdi, gword ptr [rbx+0x08]
       mov      rdi, gword ptr [rdi+0x10]
       mov      r11, 0x78C06CC927A0
       cmp      qword ptr [rdi], r11
       jne      G_M000_IG362
       not      esi
       mov      r12d, dword ptr [rdi+0x08]
       cmp      r12d, esi
       jbe      G_M000_IG361
       cmp      esi, r12d
       jae      G_M000_IG379
       mov      rdi, gword ptr [rdi+8*rsi+0x10]
 
G_M000_IG197:                ;; offset=0x1415
       call     [Lokad.Lython.Runtime.LythonRuntime:RuntimeValue(System.Object):System.Object]
       mov      gword ptr [rbp-0x180], rax
       jmp      G_M000_IG190
 
G_M000_IG198:                ;; offset=0x1427
       mov      rsi, 0x78C06E40F7C8
       cmp      qword ptr [rdi], rsi
       jne      G_M000_IG109
 
G_M000_IG199:                ;; offset=0x143A
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableCell:get_Value():System.Object:this]
       mov      r8, rax
       jmp      G_M000_IG110
 
G_M000_IG200:                ;; offset=0x1448
       mov      rsi, gword ptr [r11]
       mov      rdi, 0x78C06CD684D8
       cmp      qword ptr [rdx], rdi
       jne      G_M000_IG230
       mov      rdx, gword ptr [rbp-0x1E8]
       cmp      rsi, r12
       je       SHORT G_M000_IG204
 
G_M000_IG201:                ;; offset=0x146A
       test     rsi, rsi
       je       G_M000_IG229
       mov      edi, dword ptr [rsi+0x08]
       cmp      edi, dword ptr [r12+0x08]
       jne      G_M000_IG229
 
G_M000_IG202:                ;; offset=0x1481
       add      rsi, 12
       mov      bword ptr [rbp-0x1F8], rsi
       add      edi, edi
       mov      edx, edi
       lea      rsi, bword ptr [r12+0x0C]
       mov      rdi, bword ptr [rbp-0x1F8]
       call     [System.SpanHelpers:SequenceEqual(byref,byref,nuint):bool]
       mov      rdx, gword ptr [rbp-0x1E8]
 
G_M000_IG203:                ;; offset=0x14A9
       test     eax, eax
       mov      r11, bword ptr [rbp-0x1E0]
       je       G_M000_IG123
       add      r11, 8
       mov      r13, gword ptr [r11]
       mov      rax, r13
       jmp      G_M000_IG136
 
G_M000_IG204:                ;; offset=0x14C7
       mov      edi, 1
       mov      eax, edi
       jmp      SHORT G_M000_IG203
 
G_M000_IG205:                ;; offset=0x14D0
       cmp      dword ptr [rdi+0x20], 0
       je       G_M000_IG66
       mov      rdi, rax
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionCanceled(Lokad.Lython.LythonSourceSpan)]
       jmp      G_M000_IG66
 
G_M000_IG206:                ;; offset=0x14E8
       mov      rdi, gword ptr [rbx+0x08]
       mov      r13, gword ptr [rdi+0x10]
       mov      rdi, r14
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ConstantIndex():int:this]
       mov      esi, eax
       mov      rdi, r13
       mov      r11, 0x78C06BA72F40
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       mov      rdi, rax
       call     [Lokad.Lython.Runtime.LythonRuntime:RuntimeValue(System.Object):System.Object]
       mov      rdx, rax
       mov      rsi, r14
       mov      rdi, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,System.Object):this]
       jmp      G_M000_IG63
 
G_M000_IG207:                ;; offset=0x1528
       mov      rdi, r14
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      r12d, eax
       jmp      G_M000_IG170
 
G_M000_IG208:                ;; offset=0x1539
       mov      rdi, rbx
       mov      esi, r14d
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Trim(int):this]
       jmp      G_M000_IG172
 
G_M000_IG209:                ;; offset=0x154A
       mov      eax, ecx
       jmp      G_M000_IG176
 
G_M000_IG210:                ;; offset=0x1551
       lea      rsi, bword ptr [rbx+0x48]
       cmp      eax, dword ptr [rsi+0x08]
       jae      G_M000_IG379
       mov      rsi, bword ptr [rsi]
       mov      dword ptr [rbp-0xA8], eax
       mov      edi, eax
       mov      rsi, gword ptr [rsi+8*rdi]
       mov      rdi, 0x78C06E439488
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG211
       lea      rdi, bword ptr [rbx+0x48]
       mov      ecx, dword ptr [rbp-0xA8]
       cmp      ecx, dword ptr [rdi+0x08]
       jae      G_M000_IG379
       mov      rdi, bword ptr [rdi]
       mov      dword ptr [rbp-0xA8], ecx
       mov      edx, ecx
       xor      rsi, rsi
       mov      gword ptr [rdi+8*rdx], rsi
       mov      rdi, rax
       mov      rax, qword ptr [rax]
       mov      rax, qword ptr [rax+0x40]
       call     [rax+0x20]Lokad.Lython.Runtime.ExecutableTemporaryValue:Dispose():this
 
G_M000_IG211:                ;; offset=0x15B2
       mov      ecx, dword ptr [rbp-0xA8]
       dec      ecx
       cmp      ecx, r13d
       mov      eax, ecx
       jge      SHORT G_M000_IG210
       jmp      G_M000_IG177
 
G_M000_IG212:                ;; offset=0x15C6
       mov      rdi, r14
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       jmp      G_M000_IG181
 
G_M000_IG213:                ;; offset=0x15D4
       mov      rdi, r14
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       jmp      G_M000_IG184
 
G_M000_IG214:                ;; offset=0x15E2
       cmp      dword ptr [rdi+0x20], 0
       je       G_M000_IG185
       mov      rdi, rax
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionCanceled(Lokad.Lython.LythonSourceSpan)]
       jmp      G_M000_IG185
 
G_M000_IG215:                ;; offset=0x15FA
       mov      rdi, r13
       mov      esi, eax
       mov      r11, 0x78C06BA72F38
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       mov      r12, rax
       jmp      G_M000_IG89
 
G_M000_IG216:                ;; offset=0x1614
       mov      rsi, gword ptr [rcx+0x10]
       mov      rdi, 0x78C06E0B52B0
       call     CORINFO_HELP_CHKCASTCLASS
       mov      rcx, rax
       jmp      G_M000_IG90
 
G_M000_IG217:                ;; offset=0x162F
       mov      rdi, rdx
       call     CORINFO_HELP_CHKCASTCLASS
       int3     
 
G_M000_IG218:                ;; offset=0x1638
       xor      rdx, rdx
       jmp      G_M000_IG94
 
G_M000_IG219:                ;; offset=0x163F
       mov      r10d, esi
       rol      r10d, 5
       add      r10d, esi
       mov      esi, r10d
       xor      esi, dword ptr [r11]
       jmp      G_M000_IG99
 
G_M000_IG220:                ;; offset=0x1654
       mov      rdi, r9
       mov      rsi, r12
       mov      r11, 0x78C06BA72F78
       call     [r11]System.Collections.Generic.IEqualityComparer`1[System.__Canon]:GetHashCode(System.__Canon):int:this
       mov      r13d, eax
       mov      r9, gword ptr [rbp-0x1C0]
       jmp      G_M000_IG100
 
G_M000_IG221:                ;; offset=0x1676
       xor      edi, edi
       mov      eax, edi
       jmp      G_M000_IG107
 
G_M000_IG222:                ;; offset=0x167F
       mov      r9, gword ptr [rbp-0x1C0]
       mov      rdi, r9
       mov      rdx, r12
       mov      r11, 0x78C06BA72F80
       call     [r11]System.Collections.Generic.IEqualityComparer`1[System.__Canon]:Equals(System.__Canon,System.__Canon):bool:this
       mov      r9, gword ptr [rbp-0x1C0]
       jmp      G_M000_IG107
 
G_M000_IG223:                ;; offset=0x16A5
       lea      rdx, [rbp-0xB0]
       mov      rdi, r8
       mov      rsi, r12
       mov      r11, 0x78C06BA72F60
       call     [r11]System.Collections.Generic.IReadOnlyDictionary`2[System.__Canon,int]:TryGetValue(System.__Canon,byref):bool:this
       test     eax, eax
       je       G_M000_IG114
       jmp      G_M000_IG108
 
G_M000_IG224:                ;; offset=0x16CC
       mov      gword ptr [rbp-0x1A8], rdx
       mov      rdi, gword ptr [rdx+0x108]
       mov      rdi, gword ptr [rdi+0x40]
       lea      rdx, [rbp-0xB8]
       mov      rsi, r12
       mov      r11, 0x78C06BA72F68
       call     [r11]System.Collections.Generic.IReadOnlyDictionary`2[System.__Canon,int]:TryGetValue(System.__Canon,byref):bool:this
       test     eax, eax
       je       SHORT G_M000_IG225
       mov      rdi, gword ptr [rbp-0x1A8]
       mov      rdi, gword ptr [rdi+0x118]
       mov      esi, dword ptr [rbp-0xB8]
       mov      r11, 0x78C06BA72F70
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       mov      rdi, rax
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableCell:get_Value():System.Object:this]
       test     rax, rax
       mov      rcx, gword ptr [rbp-0x1A0]
       je       G_M000_IG115
       mov      r13, rax
       mov      rax, r13
       jmp      G_M000_IG136
 
G_M000_IG225:                ;; offset=0x1740
       mov      rcx, gword ptr [rbp-0x1A0]
       jmp      G_M000_IG115
 
G_M000_IG226:                ;; offset=0x174C
       mov      rdi, rcx
       call     [Lokad.Lython.Runtime.ExecutionFrame:InitializeVariables():System.Collections.Generic.Dictionary`2[System.String,System.Object]:this]
       mov      rdx, rax
       jmp      G_M000_IG116
 
G_M000_IG227:                ;; offset=0x175D
       mov      r8d, esi
       rol      r8d, 5
       add      r8d, esi
       mov      esi, r8d
       xor      esi, dword ptr [r11]
       jmp      G_M000_IG120
 
G_M000_IG228:                ;; offset=0x1772
       mov      rdi, rdx
       mov      rsi, r12
       mov      r11, 0x78C06BA72F88
       call     [r11]System.Collections.Generic.IEqualityComparer`1[System.__Canon]:GetHashCode(System.__Canon):int:this
       mov      r8d, eax
       mov      rdx, gword ptr [rbp-0x1E8]
       jmp      G_M000_IG121
 
G_M000_IG229:                ;; offset=0x1794
       xor      edi, edi
       mov      eax, edi
       jmp      G_M000_IG203
 
G_M000_IG230:                ;; offset=0x179D
       mov      rdx, gword ptr [rbp-0x1E8]
       mov      rdi, rdx
       mov      rdx, r12
       mov      r11, 0x78C06BA72F90
       call     [r11]System.Collections.Generic.IEqualityComparer`1[System.__Canon]:Equals(System.__Canon,System.__Canon):bool:this
       mov      rdx, gword ptr [rbp-0x1E8]
       jmp      G_M000_IG203
 
G_M000_IG231:                ;; offset=0x17C3
       mov      edx, esi
       rol      edx, 5
       add      edx, esi
       mov      esi, edx
       xor      esi, dword ptr [r11]
       jmp      G_M000_IG129
 
G_M000_IG232:                ;; offset=0x17D4
       mov      rdi, rcx
       mov      rsi, r12
       mov      r11, 0x78C06BA72F98
       call     [r11]System.Collections.Generic.IEqualityComparer`1[System.__Canon]:GetHashCode(System.__Canon):int:this
       mov      edx, eax
       mov      rcx, gword ptr [rbp-0x210]
       jmp      G_M000_IG130
 
G_M000_IG233:                ;; offset=0x17F5
       xor      edi, edi
       mov      eax, edi
       jmp      G_M000_IG146
 
G_M000_IG234:                ;; offset=0x17FE
       mov      rcx, gword ptr [rbp-0x210]
       mov      rdi, rcx
       mov      rdx, r12
       mov      r11, 0x78C06BA72FA0
       call     [r11]System.Collections.Generic.IEqualityComparer`1[System.__Canon]:Equals(System.__Canon,System.__Canon):bool:this
       mov      rcx, gword ptr [rbp-0x210]
       jmp      G_M000_IG146
 
G_M000_IG235:                ;; offset=0x1824
       mov      gword ptr [rbp-0x190], rax
       mov      rdi, r14
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      r12d, eax
       mov      rax, gword ptr [rbp-0x190]
       jmp      G_M000_IG140
 
G_M000_IG236:                ;; offset=0x1843
       mov      gword ptr [rbp-0x190], rax
       mov      rdi, rbx
       mov      esi, r14d
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Trim(int):this]
       mov      rax, gword ptr [rbp-0x190]
       jmp      G_M000_IG142
 
G_M000_IG237:                ;; offset=0x1862
       mov      ecx, eax
       jmp      G_M000_IG151
 
G_M000_IG238:                ;; offset=0x1869
       lea      rsi, bword ptr [rbx+0x48]
       cmp      eax, dword ptr [rsi+0x08]
       jae      G_M000_IG379
       mov      rsi, bword ptr [rsi]
       mov      dword ptr [rbp-0xEC], eax
       mov      edi, eax
       mov      rsi, gword ptr [rsi+8*rdi]
       mov      rdi, 0x78C06E439488
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG239
       lea      rdi, bword ptr [rbx+0x48]
       mov      ecx, dword ptr [rbp-0xEC]
       cmp      ecx, dword ptr [rdi+0x08]
       jae      G_M000_IG379
       mov      rdi, bword ptr [rdi]
       mov      dword ptr [rbp-0xEC], ecx
       mov      edx, ecx
       xor      rsi, rsi
       mov      gword ptr [rdi+8*rdx], rsi
       mov      rdi, rax
       mov      rax, qword ptr [rax]
       mov      rax, qword ptr [rax+0x40]
       call     [rax+0x20]Lokad.Lython.Runtime.ExecutableTemporaryValue:Dispose():this
 
G_M000_IG239:                ;; offset=0x18CA
       mov      ecx, dword ptr [rbp-0xEC]
       dec      ecx
       cmp      ecx, r13d
       mov      eax, ecx
       jge      SHORT G_M000_IG238
       jmp      G_M000_IG152
 
G_M000_IG240:                ;; offset=0x18DE
       mov      rdi, r14
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       jmp      G_M000_IG156
 
G_M000_IG241:                ;; offset=0x18EC
       mov      rdi, r14
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       jmp      G_M000_IG159
 
G_M000_IG242:                ;; offset=0x18FA
       cmp      dword ptr [rdi+0x20], 0
       je       G_M000_IG160
       mov      rdi, rax
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionCanceled(Lokad.Lython.LythonSourceSpan)]
       jmp      G_M000_IG160
 
G_M000_IG243:                ;; offset=0x1912
       mov      rdi, gword ptr [rbx+0x08]
       mov      rsi, gword ptr [rbx+0x10]
       mov      edx, dword ptr [rbx+0x38]
       mov      ecx, dword ptr [rbx+0x3C]
       mov      r8, gword ptr [rbx+0x18]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryExecuteClosureArithmetic(Lokad.Lython.Frontend.ExecutableCodeObject,System.Collections.Generic.IReadOnlyList`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableCell],int,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):bool]
       test     eax, eax
       je       SHORT G_M000_IG244
       add      dword ptr [rbx+0x38], 2
       jmp      G_M000_IG63
 
G_M000_IG244:                ;; offset=0x1937
       mov      rdi, r14
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ClosureSlot():int:this]
       mov      esi, eax
       lea      rdx, [rbp-0x30]
       mov      rdi, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:TryCell(int,byref):bool:this]
       test     eax, eax
       je       G_M000_IG36
       mov      rdi, gword ptr [rbp-0x30]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableCell:get_Value():System.Object:this]
       test     rax, rax
       je       G_M000_IG36
       mov      rdi, rbx
       mov      rsi, r14
       mov      rdx, rax
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,System.Object):this]
       jmp      G_M000_IG63
 
G_M000_IG245:                ;; offset=0x1980
       mov      rdi, r14
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ClosureSlot():int:this]
       mov      esi, eax
       lea      rdx, [rbp-0x38]
       mov      rdi, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:TryCell(int,byref):bool:this]
       test     eax, eax
       je       G_M000_IG36
       mov      rdi, gword ptr [rbp-0x38]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableCell:get_CanStoreThroughOwner():bool:this]
       test     eax, eax
       je       G_M000_IG36
       mov      rdi, rbx
       mov      rsi, r14
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Take(byref):System.Object:this]
       mov      rsi, rax
       mov      rdi, gword ptr [rbp-0x38]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableCell:set_Value(System.Object):this]
       jmp      G_M000_IG63
 
G_M000_IG246:                ;; offset=0x19D4
       lea      r13, bword ptr [rbx+0x48]
       mov      rdi, r14
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LocalSlot():int:this]
       cmp      eax, dword ptr [r13+0x08]
       jae      G_M000_IG379
       mov      rdi, bword ptr [r13]
       mov      esi, eax
       lea      rdi, bword ptr [rdi+8*rsi]
       mov      bword ptr [rbp-0x298], rdi
       mov      rdi, rbx
       mov      rsi, r14
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Take(byref):System.Object:this]
       mov      rsi, rax
       mov      rdi, bword ptr [rbp-0x298]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       jmp      G_M000_IG63
 
G_M000_IG247:                ;; offset=0x1A1C
       mov      esi, dword ptr [r14+0x10]
       mov      rdi, rbx
       xor      edx, edx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Read(int,int):System.Object:this]
       mov      r13, rax
       mov      rdi, gword ptr [rbx+0x08]
       mov      r12, gword ptr [rdi+0x18]
       mov      rdi, r14
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_NameIndex():int:this]
       mov      esi, eax
       mov      rdi, r12
       mov      r11, 0x78C06BA72F30
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       mov      r12, rax
       mov      rsi, r13
       mov      rdi, 0x78C06E0B75A0
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       jne      SHORT G_M000_IG249
       mov      rsi, r13
       mov      rdi, 0x78C06E43DDA8
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       jne      SHORT G_M000_IG248
       xor      r12, r12
       jmp      SHORT G_M000_IG250
 
G_M000_IG248:                ;; offset=0x1A87
       mov      rdi, r12
       call     [Lokad.Lython.Runtime.LythonRuntime+DictMembers:GetMethod(System.String):Lokad.Lython.Runtime.LythonRuntime+ReceiverMethod]
       mov      r12, rax
       jmp      SHORT G_M000_IG250
 
G_M000_IG249:                ;; offset=0x1A95
       mov      rdi, r12
       call     [Lokad.Lython.Runtime.LythonRuntime+StringMembers:GetMethod(System.String):Lokad.Lython.Runtime.LythonRuntime+ReceiverMethod]
       mov      r12, rax
 
G_M000_IG250:                ;; offset=0x1AA1
       test     r12, r12
       je       G_M000_IG36
       mov      rdi, r14
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       mov      dword ptr [rbp-0x138], eax
       mov      rdi, r14
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       lea      edx, [rax+0x01]
       mov      esi, dword ptr [rbp-0x138]
       mov      rdi, rbx
       mov      rcx, r13
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Put(int,int,System.Object):this]
       mov      rdi, r14
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       lea      r13d, [rax+0x01]
       mov      rdi, r14
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      edx, eax
       mov      esi, r13d
       mov      rdi, rbx
       mov      rcx, r12
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Put(int,int,System.Object):this]
       jmp      G_M000_IG63
 
G_M000_IG251:                ;; offset=0x1B03
       not      esi
       mov      r11, 0x78C06BA72FB0
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       mov      rdi, rax
       jmp      G_M000_IG39
 
G_M000_IG252:                ;; offset=0x1B1A
       mov      rdi, gword ptr [rbx+0x08]
       cmp      esi, dword ptr [rdi+0x9C]
       jl       G_M000_IG376
       mov      rdi, 0x78C06D3A7A68
       call     CORINFO_HELP_NEWSFAST
       mov      rbx, rax
       mov      rdi, rbx
       mov      rsi, 0x78C06840EE38
       call     [System.InvalidOperationException:.ctor(System.String):this]
       mov      rdi, rbx
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG253:                ;; offset=0x1B58
       not      esi
       mov      r11, 0x78C06BA72FC0
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       mov      rdi, rax
       jmp      G_M000_IG41
 
G_M000_IG254:                ;; offset=0x1B6F
       mov      rdi, gword ptr [rbx+0x08]
       cmp      esi, dword ptr [rdi+0x9C]
       jl       G_M000_IG377
       mov      rdi, 0x78C06D3A7A68
       call     CORINFO_HELP_NEWSFAST
       mov      rbx, rax
       mov      rdi, rbx
       mov      rsi, 0x78C06840EE38
       call     [System.InvalidOperationException:.ctor(System.String):this]
       mov      rdi, rbx
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG255:                ;; offset=0x1BAD
       mov      rdi, gword ptr [r13+0x08]
       mov      r11, 0x78C06BA72FC8
       call     [r11]Lokad.Lython.Runtime.IPyDictStorage:get_HasProtocolKeys():bool:this
       test     eax, eax
       jne      G_M000_IG36
       jmp      G_M000_IG44
 
G_M000_IG256:                ;; offset=0x1BCB
       mov      edi, dword ptr [r14+0x1C]
       cmp      edi, 24
       je       SHORT G_M000_IG257
       cmp      edi, 25
       jne      G_M000_IG378
 
G_M000_IG257:                ;; offset=0x1BDD
       mov      edi, dword ptr [r14+0x0C]
       jmp      G_M000_IG47
 
G_M000_IG258:                ;; offset=0x1BE6
       mov      rdi, gword ptr [rax+0x68]
       movsxd   rdi, dword ptr [rdi+0x94]
       imul     rdx, rdi, 64
       jo       G_M000_IG380
       add      rdx, 32
       jo       G_M000_IG380
       mov      qword ptr [rbp-0xF8], rdx
       mov      rdi, gword ptr [rax+0x10]
       mov      rdi, gword ptr [rdi+0xA0]
       mov      rsi, gword ptr [rdi+0x88]
       mov      gword ptr [rbp-0x240], rsi
       cmp      byte  ptr [rsi], sil
       mov      rdi, 0x78C06DD68D98
       call     CORINFO_HELP_NEWSFAST
       mov      gword ptr [rbp-0x248], rax
       mov      rdi, rax
       mov      rsi, gword ptr [rbp-0x240]
       mov      rdx, qword ptr [rbp-0xF8]
       mov      rcx, gword ptr [rbp-0x220]
       call     [Lokad.Lython.Runtime.MemoryGovernor+TemporaryMemoryReservation:.ctor(Lokad.Lython.Runtime.MemoryGovernor,long,Lokad.Lython.LythonSourceSpan):this]
       mov      rax, gword ptr [rbp-0x248]
       mov      gword ptr [rbp-0x228], rax
 
G_M000_IG259:                ;; offset=0x1C6A
       mov      rcx, gword ptr [rbp-0x158]
       mov      rdi, gword ptr [rcx+0x10]
       mov      rdi, gword ptr [rdi+0xA0]
       cmp      byte  ptr [rdi], dil
       xor      edx, edx
       mov      gword ptr [rbp-0x100], rdx
       mov      rdx, gword ptr [rdi+0x88]
       mov      rdx, gword ptr [rdx+0x20]
       test     rdx, rdx
       je       SHORT G_M000_IG261
 
G_M000_IG260:                ;; offset=0x1C98
       mov      rdi, rdx
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG261:                ;; offset=0x1CA1
       mov      rdi, gword ptr [rdi+0x178]
       mov      gword ptr [rbp-0x100], rdi
       lea      rdi, [rbp-0x100]
       call     [System.Threading.CancellationToken:get_IsCancellationRequested():bool:this]
       test     eax, eax
       je       SHORT G_M000_IG263
 
G_M000_IG262:                ;; offset=0x1CC0
       mov      rdi, gword ptr [rbp-0x220]
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionCanceled(Lokad.Lython.LythonSourceSpan)]
 
G_M000_IG263:                ;; offset=0x1CCD
       mov      rax, gword ptr [rbp-0x158]
       mov      rcx, gword ptr [rax+0x78]
       test     rcx, rcx
       je       SHORT G_M000_IG265
 
G_M000_IG264:                ;; offset=0x1CDD
       mov      gword ptr [rbp-0x238], rcx
       jmp      SHORT G_M000_IG266
 
G_M000_IG265:                ;; offset=0x1CE6
       mov      rsi, gword ptr [rax+0x68]
       movsxd   rsi, dword ptr [rsi+0x94]
       mov      rdi, 0x78C06E5203B8
       call     CORINFO_HELP_NEWARR_1_VC
       mov      gword ptr [rbp-0x230], rax
       mov      rdi, gword ptr [rbp-0x248]
       mov      rsi, qword ptr [rbp-0xF8]
       call     [Lokad.Lython.Runtime.MemoryGovernor+TemporaryMemoryReservation:Commit(long):this]
       mov      rdi, gword ptr [rbp-0x158]
       lea      rdi, bword ptr [rdi+0x78]
       mov      rsi, gword ptr [rbp-0x230]
       call     CORINFO_HELP_ASSIGN_REF
       mov      rax, gword ptr [rbp-0x230]
       mov      rdx, rax
       mov      gword ptr [rbp-0x238], rdx
 
G_M000_IG266:                ;; offset=0x1D43
       mov      rdi, gword ptr [rbp-0x248]
       call     [Lokad.Lython.Runtime.MemoryGovernor+TemporaryMemoryReservation:Dispose():this]
       mov      rdx, gword ptr [rbp-0x238]
       jmp      G_M000_IG48
 
G_M000_IG267:                ;; offset=0x1D5C
       mov      edi, dword ptr [r14+0x1C]
       cmp      edi, 24
       je       SHORT G_M000_IG268
       cmp      edi, 25
       jne      G_M000_IG378
 
G_M000_IG268:                ;; offset=0x1D6E
       mov      edi, dword ptr [r14+0x0C]
       jmp      G_M000_IG49
 
G_M000_IG269:                ;; offset=0x1D77
       mov      rdi, rsi
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG270:                ;; offset=0x1D80
       cmp      dword ptr [rdi+0x20], 0
       je       G_M000_IG50
       mov      rdi, rdx
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionCanceled(Lokad.Lython.LythonSourceSpan)]
       mov      rcx, gword ptr [rbp-0x168]
       mov      rdx, gword ptr [rbp-0x250]
       jmp      G_M000_IG50
 
G_M000_IG271:                ;; offset=0x1DA6
       mov      rdi, r13
       call     [Lokad.Lython.Runtime.PyDict:get_HasProtocolKeys():bool:this]
       test     eax, eax
       jne      G_M000_IG36
       jmp      G_M000_IG294
 
G_M000_IG272:                ;; offset=0x1DBC
 
G_M000_IG273:                ;; offset=0x1DBC
       mov      rdi, r12
       mov      rsi, rdx
       mov      rdx, rcx
       call     [Lokad.Lython.Runtime.LythonRuntime:ComputeStructuralHashCode(System.Object,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):int]
       mov      edi, eax
       call     [Lokad.Lython.Runtime.PyDict:MixNativeHash(int):uint]
       mov      edx, eax
       mov      rsi, r12
       mov      rdi, r13
       mov      rcx, gword ptr [rbp-0x168]
       mov      r8, gword ptr [rbp-0x250]
       call     [Lokad.Lython.Runtime.PyDict:FindNativeIndex(System.Object,uint,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):int:this]
       mov      dword ptr [rbp-0x104], eax
       test     eax, eax
       jl       SHORT G_M000_IG271
       mov      rdi, bword ptr [rbp-0x160]
       mov      rsi, gword ptr [rbp-0x258]
       call     CORINFO_HELP_ASSIGN_REF
       mov      rax, bword ptr [rbp-0x160]
       lea      rdi, bword ptr [rax+0x08]
       mov      rsi, r12
       call     CORINFO_HELP_ASSIGN_REF
       mov      rdi, bword ptr [rbp-0x160]
       mov      eax, dword ptr [rbp-0x104]
       mov      dword ptr [rdi+0x10], eax
       mov      r9d, eax
       jmp      G_M000_IG52
 
G_M000_IG274:                ;; offset=0x1E37
       xor      rax, rax
       jmp      G_M000_IG55
 
G_M000_IG275:                ;; offset=0x1E3E
       mov      rdi, r14
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      r13d, eax
       mov      rax, gword ptr [rbp-0x148]
       jmp      G_M000_IG59
 
G_M000_IG276:                ;; offset=0x1E56
       not      r14d
       jmp      G_M000_IG60
 
G_M000_IG277:                ;; offset=0x1E5E
       mov      rdi, rbx
       mov      esi, r14d
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Trim(int):this]
       mov      rax, gword ptr [rbp-0x148]
       jmp      G_M000_IG61
 
G_M000_IG278:                ;; offset=0x1E76
       mov      esi, r13d
       not      esi
       mov      edi, esi
       cmp      edi, dword ptr [rbx+0x3C]
       jge      SHORT G_M000_IG280
 
G_M000_IG279:                ;; offset=0x1E82
       mov      rdi, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Trim(int):this]
       mov      rax, gword ptr [rbp-0x148]
 
G_M000_IG280:                ;; offset=0x1E92
       lea      r12, bword ptr [rbx+0x48]
       mov      edi, dword ptr [r14+0x1C]
       cmp      edi, 52
       ja       SHORT G_M000_IG282
 
G_M000_IG281:                ;; offset=0x1E9F
       mov      rcx, 0xFFFFFFFFFE7FF
       bt       rcx, rdi
       jae      SHORT G_M000_IG283
 
G_M000_IG282:                ;; offset=0x1EAF
       mov      edi, dword ptr [r14+0x14]
       jmp      SHORT G_M000_IG284
 
G_M000_IG283:                ;; offset=0x1EB5
       mov      rdi, r14
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      edi, eax
       mov      rax, gword ptr [rbp-0x148]
 
G_M000_IG284:                ;; offset=0x1EC7
       cmp      edi, dword ptr [r12+0x08]
       jae      G_M000_IG379
       mov      rcx, bword ptr [r12]
       mov      edi, edi
       xor      rdx, rdx
       mov      gword ptr [rcx+8*rdi], rdx
       mov      edi, dword ptr [r14+0x1C]
       cmp      edi, 52
       ja       SHORT G_M000_IG286
 
G_M000_IG285:                ;; offset=0x1EE7
       mov      rcx, 0xFFFFFFFFFE7FF
       bt       rcx, rdi
       jae      SHORT G_M000_IG287
 
G_M000_IG286:                ;; offset=0x1EF7
       mov      edi, dword ptr [r14+0x14]
       jmp      SHORT G_M000_IG288
 
G_M000_IG287:                ;; offset=0x1EFD
       mov      rdi, r14
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      edi, eax
       mov      rax, gword ptr [rbp-0x148]
 
G_M000_IG288:                ;; offset=0x1F0F
       mov      dword ptr [rbx+0x3C], edi
       mov      rdi, gword ptr [rbx+0x08]
       mov      rdi, gword ptr [rdi+0x50]
       mov      ecx, dword ptr [rbx+0x38]
       inc      ecx
       cmp      ecx, dword ptr [rdi+0x08]
       jae      G_M000_IG379
       shl      rcx, 5
       lea      r14, bword ptr [rdi+rcx+0x10]
       mov      rdi, gword ptr [rbx+0x18]
       mov      rcx, gword ptr [r14]
       mov      rdi, gword ptr [rdi+0xA0]
       mov      rdx, gword ptr [rdi+0x88]
       mov      rdx, gword ptr [rdx+0x20]
       test     rdx, rdx
       je       SHORT G_M000_IG290
 
G_M000_IG289:                ;; offset=0x1F4F
       mov      rdi, rdx
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG290:                ;; offset=0x1F58
       mov      rdi, gword ptr [rdi+0x178]
       test     rdi, rdi
       je       SHORT G_M000_IG292
 
G_M000_IG291:                ;; offset=0x1F64
       cmp      dword ptr [rdi+0x20], 0
       je       SHORT G_M000_IG292
       jmp      SHORT G_M000_IG293
 
G_M000_IG292:                ;; offset=0x1F6C
       lea      r13, bword ptr [rbx+0x48]
       mov      rdi, r14
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LocalSlot():int:this]
       cmp      eax, dword ptr [r13+0x08]
       jae      G_M000_IG379
       mov      rdi, bword ptr [r13]
       mov      esi, eax
       lea      rdi, bword ptr [rdi+8*rsi]
       mov      rsi, gword ptr [rbp-0x148]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       jmp      G_M000_IG163
 
G_M000_IG293:                ;; offset=0x1F9E
       mov      rdi, rcx
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionCanceled(Lokad.Lython.LythonSourceSpan)]
       jmp      SHORT G_M000_IG292
 
G_M000_IG294:                ;; offset=0x1FA9
       mov      rdx, gword ptr [r14]
       mov      rcx, gword ptr [rbx+0x18]
       mov      rdi, r13
       mov      rsi, r12
       call     [Lokad.Lython.Runtime.LythonRuntime:ReadSubscriptValue(System.Object,System.Object,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):System.Object]
       mov      rdx, rax
       mov      rsi, r14
       mov      rdi, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,System.Object):this]
       jmp      G_M000_IG63
 
G_M000_IG295:                ;; offset=0x1FD0
       mov      esi, dword ptr [r14+0x10]
       mov      rdi, rbx
       xor      edx, edx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Read(int,int):System.Object:this]
       mov      r13, rax
       cmp      dword ptr [r14+0x08], 0
       je       G_M000_IG297
       mov      rsi, r13
       mov      rdi, 0x78C06E251F78
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       jne      SHORT G_M000_IG296
       mov      rsi, r13
       mov      rdi, 0x78C06CCC6558
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       jne      SHORT G_M000_IG296
       mov      rsi, r13
       mov      rdi, 0x78C06CC935C8
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       sete     r12b
       movzx    r12, r12b
       jmp      SHORT G_M000_IG298
 
G_M000_IG296:                ;; offset=0x203A
       mov      edi, dword ptr [r14+0x08]
       mov      r12, gword ptr [rbx+0x18]
       mov      rax, gword ptr [r14]
       mov      gword ptr [rbp-0x260], rax
       call     [Lokad.Lython.Runtime.LythonRuntime:MapExecutableUnary(int):int]
       mov      edi, eax
       mov      rsi, r13
       mov      rdx, r12
       mov      rcx, gword ptr [rbp-0x260]
       call     [Lokad.Lython.Runtime.LythonRuntime:EvaluateUnaryOperator(int,System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):System.Object]
       mov      rdx, rax
       mov      rsi, r14
       mov      rdi, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,System.Object):this]
       jmp      G_M000_IG63
 
G_M000_IG297:                ;; offset=0x207B
       mov      rdi, r13
       call     [Lokad.Lython.Runtime.LythonRuntime:CanUseNativeTruth(System.Object):bool]
       test     eax, eax
       sete     r12b
       movzx    r12, r12b
 
G_M000_IG298:                ;; offset=0x208E
       test     r12d, r12d
       jne      G_M000_IG36
       jmp      SHORT G_M000_IG296
 
G_M000_IG299:                ;; offset=0x2099
       not      esi
       mov      r11, 0x78C06BA72FE0
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       mov      rdi, rax
       jmp      G_M000_IG04
 
G_M000_IG300:                ;; offset=0x20B0
       mov      rdi, gword ptr [rbx+0x08]
       cmp      esi, dword ptr [rdi+0x9C]
       jge      SHORT G_M000_IG301
       mov      rdi, gword ptr [rbx+0x08]
       mov      rdi, gword ptr [rdi+0x20]
       mov      r11, 0x78C06BA72FD8
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       mov      r15, rax
       mov      rdi, gword ptr [rbx+0x08]
       mov      esi, dword ptr [rbx+0x38]
       xor      edx, edx
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:OperandReadSpan(int,int):Lokad.Lython.LythonSourceSpan:this]
       mov      rsi, rax
       mov      rdi, r15
       call     [Lokad.Lython.Runtime.RuntimeErrors:UnboundLocalVariable(System.String,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.LythonRuntimeException]
       mov      rdi, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG301:                ;; offset=0x20FA
       mov      rdi, 0x78C06D3A7A68
       call     CORINFO_HELP_NEWSFAST
       mov      rbx, rax
       mov      rdi, rbx
       mov      rsi, 0x78C06840EE38
       call     [System.InvalidOperationException:.ctor(System.String):this]
       mov      rdi, rbx
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG302:                ;; offset=0x2128
       not      esi
       mov      r11, 0x78C06BA72FF0
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       mov      rdi, rax
       jmp      G_M000_IG06
 
G_M000_IG303:                ;; offset=0x213F
       mov      rdi, gword ptr [rbx+0x08]
       cmp      esi, dword ptr [rdi+0x9C]
       jge      SHORT G_M000_IG304
       mov      rdi, gword ptr [rbx+0x08]
       mov      rdi, gword ptr [rdi+0x20]
       mov      r11, 0x78C06BA72FE8
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       mov      r15, rax
       mov      rdi, gword ptr [rbx+0x08]
       mov      esi, dword ptr [rbx+0x38]
       mov      edx, 1
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:OperandReadSpan(int,int):Lokad.Lython.LythonSourceSpan:this]
       mov      rsi, rax
       mov      rdi, r15
       call     [Lokad.Lython.Runtime.RuntimeErrors:UnboundLocalVariable(System.String,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.LythonRuntimeException]
       mov      rdi, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG304:                ;; offset=0x218C
       mov      rdi, 0x78C06D3A7A68
       call     CORINFO_HELP_NEWSFAST
       mov      rbx, rax
       mov      rdi, rbx
       mov      rsi, 0x78C06840EE38
       call     [System.InvalidOperationException:.ctor(System.String):this]
       mov      rdi, rbx
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG305:                ;; offset=0x21BA
       mov      rdi, r14
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      r12d, eax
       jmp      G_M000_IG11
 
G_M000_IG306:                ;; offset=0x21CB
       mov      rdi, rbx
       mov      esi, r14d
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Trim(int):this]
       jmp      G_M000_IG14
 
G_M000_IG307:                ;; offset=0x21DC
       mov      rdi, rcx
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG308:                ;; offset=0x21E5
       cmp      dword ptr [rdi+0x20], 0
       je       G_M000_IG19
       mov      rdi, rax
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionCanceled(Lokad.Lython.LythonSourceSpan)]
       jmp      G_M000_IG19
 
G_M000_IG309:                ;; offset=0x21FD
       mov      edi, dword ptr [r14+0x14]
       jmp      G_M000_IG75
 
G_M000_IG310:                ;; offset=0x2206
       movzx    rdi, byte  ptr [rbp-0x58]
       test     edi, edi
       jne      SHORT G_M000_IG311
       mov      rdi, 0x78B88D803118
       mov      rdx, gword ptr [rdi]
       jmp      SHORT G_M000_IG312
 
G_M000_IG311:                ;; offset=0x221E
       mov      rdx, 0x78B88D803110
       mov      rdx, gword ptr [rdx]
 
G_M000_IG312:                ;; offset=0x222B
       mov      rdi, rbx
       mov      rsi, r14
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,System.Object):this]
       jmp      G_M000_IG63
 
G_M000_IG313:                ;; offset=0x223C
       mov      edi, dword ptr [r14+0x14]
       jmp      G_M000_IG76
 
G_M000_IG314:                ;; offset=0x2245
       mov      edi, dword ptr [r14+0x08]
       call     [Lokad.Lython.Runtime.LythonRuntime:AugmentedBinaryOperator(int):int]
       mov      edi, eax
       jmp      G_M000_IG76
 
G_M000_IG315:                ;; offset=0x2256
       mov      rsi, r13
       mov      rdi, 0x78C06E251F78
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       jne      SHORT G_M000_IG316
       mov      rsi, r13
       mov      rdi, 0x78C06CCC6558
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       jne      SHORT G_M000_IG316
       mov      rsi, r13
       mov      rdi, 0x78C06CC935C8
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       G_M000_IG36
 
G_M000_IG316:                ;; offset=0x229F
       mov      rsi, r12
       mov      rdi, 0x78C06E251F78
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       jne      SHORT G_M000_IG318
       mov      rsi, r12
       mov      rdi, 0x78C06CCC6558
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       jne      SHORT G_M000_IG318
       mov      rsi, r12
       mov      rdi, 0x78C06CC935C8
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       G_M000_IG36
       jmp      SHORT G_M000_IG318
 
G_M000_IG317:                ;; offset=0x22EA
       mov      edi, dword ptr [r14+0x14]
       jmp      G_M000_IG77
 
G_M000_IG318:                ;; offset=0x22F3
       mov      edx, dword ptr [r14+0x08]
       mov      rcx, gword ptr [rbx+0x18]
       mov      r8, gword ptr [r14]
       mov      rdi, r13
       mov      rsi, r12
       call     [Lokad.Lython.Runtime.LythonRuntime:EvaluateAugmentedBuiltin(System.Object,System.Object,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):System.Object]
       mov      r12, rax
       jmp      G_M000_IG78
 
G_M000_IG319:                ;; offset=0x2312
       mov      rdi, r14
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      r13d, eax
       jmp      G_M000_IG82
 
G_M000_IG320:                ;; offset=0x2323
       mov      rdi, rbx
       mov      esi, r14d
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Trim(int):this]
       jmp      G_M000_IG85
 
G_M000_IG321:                ;; offset=0x2334
       mov      rdi, r14
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       jmp      G_M000_IG26
 
G_M000_IG322:                ;; offset=0x2342
       mov      rdi, r14
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       jmp      G_M000_IG29
 
G_M000_IG323:                ;; offset=0x2350
       mov      rdi, rcx
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG324:                ;; offset=0x2359
       cmp      dword ptr [rdi+0x20], 0
       je       G_M000_IG30
       mov      rdi, rax
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionCanceled(Lokad.Lython.LythonSourceSpan)]
       jmp      G_M000_IG30
 
G_M000_IG325:                ;; offset=0x2371
       mov      esi, dword ptr [r14+0x10]
       mov      rdi, rbx
       xor      edx, edx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Read(int,int):System.Object:this]
       mov      r13, rax
       mov      esi, dword ptr [r14+0x0C]
       mov      rdi, rbx
       mov      edx, 1
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Read(int,int):System.Object:this]
       mov      r12, rax
       mov      rdi, r14
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_BinaryOperator():int:this]
       mov      edi, eax
       mov      r8, gword ptr [r14]
       mov      rcx, gword ptr [rbx+0x18]
       lea      r9, [rbp-0x60]
       mov      rsi, r13
       mov      rdx, r12
       call     [Lokad.Lython.Runtime.LythonRuntime:TryEvaluateScalarComparison(int,System.Object,System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,byref):bool]
       test     eax, eax
       je       G_M000_IG36
       mov      rdi, r14
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      esi, eax
       mov      rdi, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Trim(int):this]
       mov      rdi, gword ptr [rbx+0x18]
       mov      r13, gword ptr [r14]
       mov      rdi, gword ptr [rdi+0xA0]
       cmp      byte  ptr [rdi], dil
       xor      eax, eax
       mov      gword ptr [rbp-0x120], rax
       mov      rax, gword ptr [rdi+0x88]
       mov      rax, gword ptr [rax+0x20]
       test     rax, rax
       je       SHORT G_M000_IG326
       mov      rdi, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG326:                ;; offset=0x2409
       mov      rdi, gword ptr [rdi+0x178]
       mov      gword ptr [rbp-0x120], rdi
       lea      rdi, [rbp-0x120]
       call     [System.Threading.CancellationToken:get_IsCancellationRequested():bool:this]
       test     eax, eax
       je       SHORT G_M000_IG327
       mov      rdi, r13
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionCanceled(Lokad.Lython.LythonSourceSpan)]
 
G_M000_IG327:                ;; offset=0x2431
       cmp      byte  ptr [rbp-0x60], 0
       jne      G_M000_IG63
 
G_M000_IG328:                ;; offset=0x243B
       mov      rdi, r14
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_TargetIndex():int:this]
       mov      dword ptr [rbx+0x38], eax
       jmp      G_M000_IG64
 
G_M000_IG329:                ;; offset=0x244C
       mov      esi, dword ptr [r14+0x10]
       mov      rdi, rbx
       xor      edx, edx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Read(int,int):System.Object:this]
       mov      r13, rax
       mov      rdi, r13
       call     [Lokad.Lython.Runtime.LythonRuntime:CanUseNativeTruth(System.Object):bool]
       test     eax, eax
       je       G_M000_IG36
       mov      rdi, rbx
       mov      rsi, r14
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Take(byref):System.Object:this]
       mov      rdx, gword ptr [r14]
       mov      rsi, gword ptr [rbx+0x18]
       mov      rdi, r13
       call     [Lokad.Lython.Runtime.LythonRuntime:IsTruthy(System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):bool]
       test     eax, eax
       jne      G_M000_IG63
       jmp      SHORT G_M000_IG328
 
G_M000_IG330:                ;; offset=0x2495
       mov      rdi, r14
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_DiscardIterator():bool:this]
       test     eax, eax
       je       SHORT G_M000_IG328
       mov      esi, dword ptr [rbx+0x3C]
       dec      esi
       mov      rdi, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Trim(int):this]
       jmp      SHORT G_M000_IG328
 
G_M000_IG331:                ;; offset=0x24B2
       mov      esi, dword ptr [r14+0x10]
       mov      rdi, rbx
       xor      edx, edx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Read(int,int):System.Object:this]
       mov      r13, rax
       mov      rsi, r13
       mov      rdi, 0x78C06E53ACD8
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG332
       mov      rdi, rbx
       mov      rsi, r14
       mov      rdx, r13
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,System.Object):this]
       jmp      G_M000_IG63
 
G_M000_IG332:                ;; offset=0x24EF
       mov      rsi, r13
       mov      rdi, 0x78C06E442B88
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       jne      G_M000_IG333
       mov      rsi, r13
       mov      rdi, 0x78C06E0B8030
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       jne      SHORT G_M000_IG333
       mov      rsi, r13
       mov      rdi, 0x78C06E526510
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       jne      SHORT G_M000_IG333
       mov      rsi, r13
       mov      rdi, 0x78C06E0BB8C0
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       jne      SHORT G_M000_IG333
       mov      rsi, r13
       mov      rdi, 0x78C06E0B75A0
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       jne      SHORT G_M000_IG333
       mov      rsi, r13
       mov      rdi, 0x78C06E43DDA8
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       jne      SHORT G_M000_IG333
       mov      rsi, r13
       mov      rdi, 0x78C06E4F0FE8
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       G_M000_IG36
 
G_M000_IG333:                ;; offset=0x2598
       mov      rdx, gword ptr [rbx+0x18]
       mov      rsi, gword ptr [r14]
       mov      rdi, r13
       call     [Lokad.Lython.Runtime.PyIteration+Cursor:Create(System.Object,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):Lokad.Lython.Runtime.PyIteration+Cursor]
       mov      rdx, rax
       mov      rsi, r14
       mov      rdi, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,System.Object):this]
       jmp      G_M000_IG63
 
G_M000_IG334:                ;; offset=0x25BC
       lea      rsi, bword ptr [rbx+0x48]
       mov      edi, dword ptr [r14+0x10]
       cmp      edi, dword ptr [rsi+0x08]
       jae      G_M000_IG379
       mov      rsi, bword ptr [rsi]
       mov      r13, gword ptr [rsi+8*rdi]
       mov      rsi, r13
       mov      rdi, 0x78C06E53ACD8
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       jne      SHORT G_M000_IG336
       mov      rsi, r13
       mov      rdi, 0x78C06E43FE48
       call     CORINFO_HELP_CHKCASTCLASS
       mov      r13, rax
       cmp      byte  ptr [r13], r13b
       mov      rdi, r13
       call     [Lokad.Lython.Runtime.PyIteration+Cursor:CheckExecution():this]
       lea      rsi, [rbp-0x78]
       mov      rdi, r13
       call     [Lokad.Lython.Runtime.PyIteration+Cursor:TryMoveNextCore(byref):bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG335
       xor      r13, r13
       xor      r12d, r12d
       jmp      SHORT G_M000_IG337
 
G_M000_IG335:                ;; offset=0x2626
       mov      rdi, gword ptr [rbp-0x78]
       call     [Lokad.Lython.Runtime.PyIterationResult:Yield(System.Object):Lokad.Lython.Runtime.PyIterationResult]
       mov      r13, rax
       mov      r12d, edx
       jmp      SHORT G_M000_IG337
 
G_M000_IG336:                ;; offset=0x2638
       mov      rdi, rax
       call     [Lokad.Lython.Runtime.Text.PyStringOps+CasedWhitespaceIteration:MoveNext():Lokad.Lython.Runtime.PyIterationResult:this]
       mov      r13, rax
       mov      r12d, edx
 
G_M000_IG337:                ;; offset=0x2647
       mov      gword ptr [rbp-0x70], r13
       mov      byte  ptr [rbp-0x68], r12b
       cmp      byte  ptr [rbp-0x68], 0
       jne      SHORT G_M000_IG338
       mov      esi, dword ptr [r14+0x10]
       mov      rdi, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Trim(int):this]
       jmp      G_M000_IG328
 
G_M000_IG338:                ;; offset=0x2667
       lea      rdi, [rbp-0x70]
       call     [Lokad.Lython.Runtime.PyIterationResult:get_Value():System.Object:this]
       mov      rdx, rax
       mov      rsi, r14
       mov      rdi, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,System.Object):this]
       jmp      G_M000_IG63
 
G_M000_IG339:                ;; offset=0x2685
       mov      rdi, r14
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ItemCount():int:this]
       test     eax, eax
       je       G_M000_IG342
       lea      r13, bword ptr [rbx+0x48]
       mov      r12d, dword ptr [r14+0x10]
       mov      rdi, r14
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ItemCount():int:this]
       mov      dword ptr [rbp-0x124], eax
       mov      edi, r12d
       mov      ecx, eax
       add      rdi, rcx
       mov      ecx, dword ptr [r13+0x08]
       cmp      rdi, rcx
       jbe      SHORT G_M000_IG341
 
G_M000_IG340:                ;; offset=0x26BE
       call     [System.ThrowHelper:ThrowArgumentOutOfRangeException()]
       int3     
 
G_M000_IG341:                ;; offset=0x26C5
       mov      rdi, bword ptr [r13]
       mov      ecx, r12d
       lea      r13, bword ptr [rdi+8*rcx]
       mov      rdi, gword ptr [rbx+0x18]
       mov      rdi, gword ptr [rdi+0xA0]
       mov      r12, gword ptr [rdi+0x88]
       mov      rdi, 0x78C06E0B8030
       call     CORINFO_HELP_NEWSFAST
       mov      gword ptr [rbp-0x170], rax
       mov      r8, gword ptr [r14]
       mov      rsi, r13
       mov      edx, dword ptr [rbp-0x124]
       mov      r9, gword ptr [rbx+0x18]
       mov      rdi, rax
       mov      rcx, r12
       call     [Lokad.Lython.Runtime.PyTuple:.ctor(System.ReadOnlySpan`1[System.Object],Lokad.Lython.Runtime.MemoryGovernor,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):this]
       mov      r13, gword ptr [rbp-0x170]
       jmp      SHORT G_M000_IG343
 
G_M000_IG342:                ;; offset=0x271D
       mov      rsi, 0x78B88D801950
       mov      r13, gword ptr [rsi]
 
G_M000_IG343:                ;; offset=0x272A
       mov      esi, dword ptr [r14+0x10]
       mov      rdi, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Trim(int):this]
       mov      rdi, rbx
       mov      rsi, r14
       mov      rdx, r13
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,System.Object):this]
       jmp      G_M000_IG63
 
G_M000_IG344:                ;; offset=0x274B
       mov      rdi, r14
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ItemCount():int:this]
       movsxd   rdi, eax
       imul     r13, rdi, 80
       jo       G_M000_IG380
       add      r13, 64
       jo       G_M000_IG380
       mov      rdi, gword ptr [rbx+0x18]
       mov      rdi, gword ptr [rdi+0xA0]
       mov      r12, gword ptr [rdi+0x88]
       mov      rax, gword ptr [r14]
       mov      gword ptr [rbp-0x268], rax
       cmp      byte  ptr [r12], r12b
       mov      rdi, 0x78C06DD68D98
       call     CORINFO_HELP_NEWSFAST
       mov      gword ptr [rbp-0x270], rax
       mov      rdi, rax
       mov      rsi, r12
       mov      rdx, r13
       mov      rcx, gword ptr [rbp-0x268]
       call     [Lokad.Lython.Runtime.MemoryGovernor+TemporaryMemoryReservation:.ctor(Lokad.Lython.Runtime.MemoryGovernor,long,Lokad.Lython.LythonSourceSpan):this]
       mov      r12, gword ptr [rbp-0x270]
       mov      gword ptr [rbp-0x150], r12
 
G_M000_IG345:                ;; offset=0x27C5
       mov      rdi, gword ptr [rbx+0x18]
       mov      rax, gword ptr [r14]
       mov      gword ptr [rbp-0x278], rax
       mov      rdi, gword ptr [rdi+0xA0]
       cmp      byte  ptr [rdi], dil
       xor      ecx, ecx
       mov      gword ptr [rbp-0x130], rcx
       mov      rcx, gword ptr [rdi+0x88]
       mov      rcx, gword ptr [rcx+0x20]
       test     rcx, rcx
       je       SHORT G_M000_IG346
       mov      rdi, rcx
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG346:                ;; offset=0x27FF
       mov      rdi, gword ptr [rdi+0x178]
       mov      gword ptr [rbp-0x130], rdi
       lea      rdi, [rbp-0x130]
       call     [System.Threading.CancellationToken:get_IsCancellationRequested():bool:this]
       test     eax, eax
       je       SHORT G_M000_IG347
       mov      rdi, gword ptr [rbp-0x278]
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionCanceled(Lokad.Lython.LythonSourceSpan)]
 
G_M000_IG347:                ;; offset=0x282B
       lea      rax, bword ptr [rbx+0x48]
       mov      bword ptr [rbp-0x178], rax
       mov      ecx, dword ptr [r14+0x10]
       mov      dword ptr [rbp-0xA4], ecx
       mov      rdi, r14
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ItemCount():int:this]
       mov      dword ptr [rbp-0x134], eax
       mov      esi, dword ptr [rbp-0xA4]
       mov      edi, esi
       mov      ecx, eax
       add      rdi, rcx
       mov      rcx, bword ptr [rbp-0x178]
       mov      edx, dword ptr [rcx+0x08]
       cmp      rdi, rdx
       jbe      SHORT G_M000_IG348
       call     [System.ThrowHelper:ThrowArgumentOutOfRangeException()]
       int3     
 
G_M000_IG348:                ;; offset=0x2872
       mov      rdi, bword ptr [rcx]
       mov      esi, esi
       lea      rcx, bword ptr [rdi+8*rsi]
       mov      bword ptr [rbp-0x290], rcx
       test     eax, eax
       jne      SHORT G_M000_IG349
       mov      rax, 0x78B88D800F80
       mov      rax, gword ptr [rax]
       mov      gword ptr [rbp-0x280], rax
       jmp      SHORT G_M000_IG350
 
G_M000_IG349:                ;; offset=0x289C
       movsxd   rsi, eax
       mov      rdi, 0x78C06CC927A0
       call     CORINFO_HELP_NEWARR_1_PTR
       mov      gword ptr [rbp-0x288], rax
       lea      rdi, bword ptr [rax+0x10]
       mov      edx, dword ptr [rbp-0x134]
       shl      rdx, 3
       mov      rsi, bword ptr [rbp-0x290]
       call     [System.Buffer:BulkMoveWithWriteBarrier(byref,byref,nuint)]
       mov      rax, gword ptr [rbp-0x288]
       mov      gword ptr [rbp-0x280], rax
 
G_M000_IG350:                ;; offset=0x28DE
       mov      esi, dword ptr [r14+0x10]
       mov      rdi, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Trim(int):this]
       mov      rdi, r12
       mov      rsi, r13
       call     [Lokad.Lython.Runtime.MemoryGovernor+TemporaryMemoryReservation:Commit(long):this]
       mov      rsi, gword ptr [rbx+0x18]
       mov      rsi, gword ptr [rsi+0xA0]
       mov      rsi, gword ptr [rsi+0x88]
       mov      rdx, gword ptr [r14]
       mov      rdi, gword ptr [rbp-0x280]
       call     [Lokad.Lython.Runtime.PyList:FromTransferredArray(System.Object[],Lokad.Lython.Runtime.MemoryGovernor,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.PyList]
       mov      rdx, rax
       mov      rsi, r14
       mov      rdi, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,System.Object):this]
       nop      
 
G_M000_IG351:                ;; offset=0x2929
       mov      rdi, r12
       call     [Lokad.Lython.Runtime.MemoryGovernor+TemporaryMemoryReservation:Dispose():this]
       jmp      G_M000_IG63
 
G_M000_IG352:                ;; offset=0x2937
       mov      rdi, rbx
       mov      rsi, r14
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Format(byref):bool:this]
       test     eax, eax
       jne      G_M000_IG63
       jmp      G_M000_IG36
 
G_M000_IG353:                ;; offset=0x2950
       mov      rdi, r14
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       lea      r13d, [rax+0x01]
       mov      rdi, r14
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      r12d, eax
       mov      esi, dword ptr [r14+0x10]
       mov      rdi, rbx
       xor      edx, edx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Read(int,int):System.Object:this]
       mov      rcx, rax
       mov      esi, r13d
       mov      edx, r12d
       mov      rdi, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Put(int,int,System.Object):this]
       jmp      G_M000_IG63
 
G_M000_IG354:                ;; offset=0x298F
       mov      esi, dword ptr [r14+0x10]
       mov      rdi, rbx
       xor      edx, edx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Read(int,int):System.Object:this]
       mov      rdi, r14
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      esi, eax
       mov      rdi, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Trim(int):this]
       jmp      G_M000_IG63
 
G_M000_IG355:                ;; offset=0x29B7
       mov      rsi, bword ptr [rbp-0x88]
       mov      eax, edi
       lea      rsi, bword ptr [rsi+2*rax]
       mov      eax, dword ptr [rbp-0x80]
       sub      eax, edi
       cmp      eax, 26
       jb       SHORT G_M000_IG356
       vmovups  ymm0, ymmword ptr [reloc @RWD192]
       vmovups  ymmword ptr [rsi], ymm0
       vmovups  xmm0, xmmword ptr [reloc @RWD224]
       vmovups  xmmword ptr [rsi+0x20], xmm0
       mov      dword ptr [rsi+0x30], 0x20003A
       mov      edi, dword ptr [rbp-0x90]
       add      edi, 26
       mov      dword ptr [rbp-0x90], edi
       jmp      SHORT G_M000_IG357
 
G_M000_IG356:                ;; offset=0x29FF
       lea      rdi, [rbp-0xA0]
       mov      rsi, 0x78C06845BB98
       call     [System.Runtime.CompilerServices.DefaultInterpolatedStringHandler:GrowThenCopyString(System.String):this]
 
G_M000_IG357:                ;; offset=0x2A16
       mov      esi, dword ptr [r14+0x1C]
       lea      rdi, [rbp-0xA0]
       call     [System.Runtime.CompilerServices.DefaultInterpolatedStringHandler:AppendFormatted[int](int):this]
       mov      rdi, 0x78C06D3A7A68
       call     CORINFO_HELP_NEWSFAST
       mov      r14, rax
       lea      rdi, [rbp-0xA0]
       call     [System.Runtime.CompilerServices.DefaultInterpolatedStringHandler:ToStringAndClear():System.String:this]
       mov      rsi, rax
       mov      rdi, r14
       call     [System.InvalidOperationException:.ctor(System.String):this]
       mov      rdi, r14
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG358:                ;; offset=0x2A5B
       mov      rdi, rcx
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG359:                ;; offset=0x2A64
       lea      rdi, [rbp-0xA0]
       mov      esi, 26
       mov      edx, 1
       call     [System.Runtime.CompilerServices.DefaultInterpolatedStringHandler:.ctor(int,int):this]
       mov      edi, dword ptr [rbp-0x90]
       cmp      edi, dword ptr [rbp-0x80]
       jbe      G_M000_IG355
       jmp      G_M000_IG340
 
G_M000_IG360:                ;; offset=0x2A8F
       mov      rsi, gword ptr [rbx+0x08]
       mov      esi, dword ptr [rsi+0x9C]
       mov      rdi, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Trim(int):this]
       jmp      G_M000_IG194
 
G_M000_IG361:                ;; offset=0x2AA7
       call     [System.ThrowHelper:ThrowArgumentOutOfRange_IndexMustBeLessException()]
       int3     
 
G_M000_IG362:                ;; offset=0x2AAE
       not      esi
       mov      r11, 0x78C06BA72F50
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       mov      rdi, rax
       jmp      G_M000_IG197
 
G_M000_IG363:                ;; offset=0x2AC5
       mov      rdi, gword ptr [rbx+0x08]
       cmp      esi, dword ptr [rdi+0x9C]
       jge      SHORT G_M000_IG364
       mov      rdi, gword ptr [rbx+0x08]
       mov      rdi, gword ptr [rdi+0x20]
       mov      r11, 0x78C06BA72F48
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       mov      r15, rax
       mov      rdi, gword ptr [rbx+0x08]
       mov      esi, dword ptr [rbx+0x38]
       xor      edx, edx
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:OperandReadSpan(int,int):Lokad.Lython.LythonSourceSpan:this]
       mov      rsi, rax
       mov      rdi, r15
       call     [Lokad.Lython.Runtime.RuntimeErrors:UnboundLocalVariable(System.String,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.LythonRuntimeException]
       mov      rdi, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG364:                ;; offset=0x2B0F
       mov      rdi, 0x78C06D3A7A68
       call     CORINFO_HELP_NEWSFAST
       mov      rbx, rax
       mov      rdi, rbx
       mov      rsi, 0x78C06840EE38
       call     [System.InvalidOperationException:.ctor(System.String):this]
       mov      rdi, rbx
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG365:                ;; offset=0x2B3D
       lea      rsi, bword ptr [rbx+0x48]
       cmp      r15d, dword ptr [rsi+0x08]
       jae      G_M000_IG379
       mov      rsi, bword ptr [rsi]
       mov      edi, r15d
       mov      rsi, gword ptr [rsi+8*rdi]
       mov      rdi, 0x78C06E439488
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG366
       lea      rdi, bword ptr [rbx+0x48]
       cmp      r15d, dword ptr [rdi+0x08]
       jae      G_M000_IG379
       mov      rdi, bword ptr [rdi]
       mov      ecx, r15d
       xor      rdx, rdx
       mov      gword ptr [rdi+8*rcx], rdx
       mov      rdi, rax
       mov      rax, qword ptr [rax]
       mov      rax, qword ptr [rax+0x40]
       call     [rax+0x20]Lokad.Lython.Runtime.ExecutableTemporaryValue:Dispose():this
 
G_M000_IG366:                ;; offset=0x2B90
       dec      r15d
       cmp      r15d, r14d
       jge      SHORT G_M000_IG365
       jmp      G_M000_IG193
 
G_M000_IG367:                ;; offset=0x2B9D
       mov      rdi, r14
       mov      rsi, 0x78C0684577D8
       call     [Lokad.Lython.Frontend.ExecutableInstruction:InvalidOperand(System.String):System.InvalidOperationException:this]
       mov      rdi, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG368:                ;; offset=0x2BB9
       mov      rdi, gword ptr [rbx+0x08]
       mov      rdi, gword ptr [rdi+0x20]
       mov      r11, 0x78C06BA72F58
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       mov      rdi, rax
       mov      rsi, r12
       call     [Lokad.Lython.Runtime.RuntimeErrors:UnboundLocalVariable(System.String,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.LythonRuntimeException]
       mov      rdi, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG369:                ;; offset=0x2BE3
       mov      rdi, rcx
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG370:                ;; offset=0x2BEC
       mov      rdi, r13
       mov      rsi, 0x78C0684577D8
       call     [Lokad.Lython.Frontend.ExecutableInstruction:InvalidOperand(System.String):System.InvalidOperationException:this]
       mov      rdi, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG371:                ;; offset=0x2C08
       mov      edi, 4
       call     [System.ThrowHelper:ThrowArgumentNullException(int)]
       int3     
 
G_M000_IG372:                ;; offset=0x2C14
       call     [System.ThrowHelper:ThrowInvalidOperationException_ConcurrentOperationsNotSupported()]
       int3     
 
G_M000_IG373:                ;; offset=0x2C1B
       mov      rdi, r12
       mov      rsi, r13
       call     [Lokad.Lython.Runtime.RuntimeErrors:NameNotDefined(System.String,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.LythonRuntimeException]
       mov      rdi, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG374:                ;; offset=0x2C30
       mov      rdi, rcx
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG375:                ;; offset=0x2C39
       mov      rdi, r13
       mov      rsi, 0x78C0684577D8
       call     [Lokad.Lython.Frontend.ExecutableInstruction:InvalidOperand(System.String):System.InvalidOperationException:this]
       mov      rdi, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG376:                ;; offset=0x2C55
       mov      rdi, gword ptr [rbx+0x08]
       mov      rdi, gword ptr [rdi+0x20]
       mov      r11, 0x78C06BA72FA8
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       mov      r15, rax
       mov      rdi, gword ptr [rbx+0x08]
       mov      esi, dword ptr [rbx+0x38]
       xor      edx, edx
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:OperandReadSpan(int,int):Lokad.Lython.LythonSourceSpan:this]
       mov      rsi, rax
       mov      rdi, r15
       call     [Lokad.Lython.Runtime.RuntimeErrors:UnboundLocalVariable(System.String,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.LythonRuntimeException]
       mov      rdi, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG377:                ;; offset=0x2C93
       mov      rdi, gword ptr [rbx+0x08]
       mov      rdi, gword ptr [rdi+0x20]
       mov      r11, 0x78C06BA72FB8
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       mov      r15, rax
       mov      rdi, gword ptr [rbx+0x08]
       mov      esi, dword ptr [rbx+0x38]
       mov      edx, 1
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:OperandReadSpan(int,int):Lokad.Lython.LythonSourceSpan:this]
       mov      rsi, rax
       mov      rdi, r15
       call     [Lokad.Lython.Runtime.RuntimeErrors:UnboundLocalVariable(System.String,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.LythonRuntimeException]
       mov      rdi, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG378:                ;; offset=0x2CD4
       mov      rdi, r14
       mov      rsi, 0x78C06845A1A0
       call     [Lokad.Lython.Frontend.ExecutableInstruction:InvalidOperand(System.String):System.InvalidOperationException:this]
       mov      rdi, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG379:                ;; offset=0x2CF0
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG380:                ;; offset=0x2CF6
       call     CORINFO_HELP_OVERFLOW
       int3     
 
G_M000_IG381:                ;; offset=0x2CFC
       sub      rsp, 24
 
G_M000_IG382:                ;; offset=0x2D00
       mov      rdi, gword ptr [rbp-0x150]
       call     [Lokad.Lython.Runtime.MemoryGovernor+TemporaryMemoryReservation:Dispose():this]
       nop      
 
G_M000_IG383:                ;; offset=0x2D0E
       vzeroupper 
       add      rsp, 24
       ret      
 
G_M000_IG384:                ;; offset=0x2D16
       sub      rsp, 24
 
G_M000_IG385:                ;; offset=0x2D1A
       mov      rdi, gword ptr [rbp-0x228]
       call     [Lokad.Lython.Runtime.MemoryGovernor+TemporaryMemoryReservation:Dispose():this]
       nop      
 
G_M000_IG386:                ;; offset=0x2D28
       vzeroupper 
       add      rsp, 24
       ret      
 
RWD00  	dd	000019BBh ; case G_M000_IG247
       	dd	00002A03h ; case G_M000_IG359
       	dd	00001973h ; case G_M000_IG246
       	dd	0000191Fh ; case G_M000_IG245
       	dd	00002A03h ; case G_M000_IG359
       	dd	00002A03h ; case G_M000_IG359
       	dd	000028EFh ; case G_M000_IG353
       	dd	0000292Eh ; case G_M000_IG354
       	dd	000026EAh ; case G_M000_IG344
       	dd	0000089Ah ; case G_M000_IG86
       	dd	00002A03h ; case G_M000_IG359
       	dd	00002A03h ; case G_M000_IG359
       	dd	00002A03h ; case G_M000_IG359
       	dd	00002A03h ; case G_M000_IG359
       	dd	00002A03h ; case G_M000_IG359
       	dd	00002A03h ; case G_M000_IG359
       	dd	00002451h ; case G_M000_IG331
       	dd	0000255Bh ; case G_M000_IG334
       	dd	00000654h ; case G_M000_IG62
       	dd	00000370h ; case G_M000_IG31
       	dd	00002A03h ; case G_M000_IG359
       	dd	00002A03h ; case G_M000_IG359
       	dd	00000702h ; case G_M000_IG68
       	dd	00000702h ; case G_M000_IG68
       	dd	00001F6Fh ; case G_M000_IG295
       	dd	000023DAh ; case G_M000_IG328
       	dd	000023EBh ; case G_M000_IG329
       	dd	00002310h ; case G_M000_IG325
       	dd	00002A03h ; case G_M000_IG359
       	dd	00002A03h ; case G_M000_IG359
       	dd	00002A03h ; case G_M000_IG359
       	dd	00002A03h ; case G_M000_IG359
       	dd	00002A03h ; case G_M000_IG359
       	dd	000012C7h ; case G_M000_IG188
       	dd	00002A2Eh ; case G_M000_IG360
       	dd	00002A2Eh ; case G_M000_IG360
       	dd	00002A03h ; case G_M000_IG359
       	dd	00002A03h ; case G_M000_IG359
       	dd	00002434h ; case G_M000_IG330
       	dd	000028D6h ; case G_M000_IG352
       	dd	000028D6h ; case G_M000_IG352
       	dd	000028D6h ; case G_M000_IG352
       	dd	000028D6h ; case G_M000_IG352
       	dd	000028D6h ; case G_M000_IG352
RWD176 	dd	00001487h ; case G_M000_IG206
       	dd	00001106h ; case G_M000_IG164
       	dd	000018B1h ; case G_M000_IG243
       	dd	000008CCh ; case G_M000_IG88
RWD192 	dq	00780065006E0055h, 0074006300650070h, 0069002000640065h, 006E0069006C006Eh
RWD224 	dq	0070006F00200065h, 00650064006F0063h

; Total bytes of code 11568

; Assembly listing for method Lokad.Lython.LythonCompiledScript:RunCore(Lokad.Lython.ILythonHost,Lokad.Lython.LythonRunOptions):Lokad.Lython.LythonExecutionResult:this (Instrumented Tier0)
; Emitting BLENDED_CODE for x64 + VEX + EVEX on Unix
; Instrumented Tier0 code
; rbp based frame
; fully interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 272
       lea      rbp, [rsp+0x110]
       xor      eax, eax
       mov      qword ptr [rbp-0x108], rax
       vxorps   xmm8, xmm8, xmm8
       vmovdqu32 zmmword ptr [rbp-0x100], zmm8
       vmovdqu32 zmmword ptr [rbp-0xC0], zmm8
       vmovdqu32 zmmword ptr [rbp-0x80], zmm8
       vmovdqu  ymmword ptr [rbp-0x40], ymm8
       mov      qword ptr [rbp-0x20], rax
       mov      gword ptr [rbp-0x08], rdi
       mov      gword ptr [rbp-0x10], rsi
       mov      gword ptr [rbp-0x18], rdx
 
G_M000_IG02:                ;; offset=0x0048
       mov      rax, gword ptr [rbp-0x08]
       mov      rax, gword ptr [rax+0x08]
       mov      gword ptr [rbp-0x58], rax
       mov      rax, gword ptr [rbp-0x58]
       mov      gword ptr [rbp-0x60], rax
       cmp      gword ptr [rbp-0x58], 0
       jne      SHORT G_M000_IG04
 
G_M000_IG03:                ;; offset=0x0063
       mov      rdi, 0x78C06D886F18
       call     CORINFO_HELP_NEWSFAST
       mov      gword ptr [rbp-0xA8], rax
       mov      rdi, gword ptr [rbp-0xA8]
       mov      rsi, 0x78C0684583E8
       call     [System.ObjectDisposedException:.ctor(System.String):this]
       mov      rdi, gword ptr [rbp-0xA8]
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG04:                ;; offset=0x009D
       mov      rax, gword ptr [rbp-0x60]
       mov      gword ptr [rbp-0x20], rax
       cmp      gword ptr [rbp-0x18], 0
       jne      SHORT G_M000_IG05
       mov      rdi, 0x78C06E8D7F28
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, 0x78C06D9E6A60
       call     CORINFO_HELP_NEWSFAST
       mov      gword ptr [rbp-0xA0], rax
       mov      rdi, gword ptr [rbp-0xA0]
       call     [Lokad.Lython.LythonRunOptions:.ctor():this]
       mov      rax, gword ptr [rbp-0xA0]
       mov      gword ptr [rbp-0x18], rax
 
G_M000_IG05:                ;; offset=0x00E9
       mov      rdi, gword ptr [rbp-0x18]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.LythonRunOptions:get_MemoryBudget():Lokad.Lython.ILythonMemoryBudget:this]
       mov      gword ptr [rbp-0x68], rax
       mov      rax, gword ptr [rbp-0x68]
       mov      gword ptr [rbp-0x70], rax
       cmp      gword ptr [rbp-0x68], 0
       jne      SHORT G_M000_IG06
       mov      rax, gword ptr [rbp-0x08]
       mov      rax, gword ptr [rax+0x20]
       mov      gword ptr [rbp-0x90], rax
       mov      rax, gword ptr [rbp-0x90]
       mov      gword ptr [rbp-0x70], rax
       cmp      gword ptr [rbp-0x90], 0
       jne      G_M000_IG10
       mov      rdi, 0x78C06E8D7F2C
       call     CORINFO_HELP_COUNTPROFILE32
       vxorps   xmm0, xmm0, xmm0
       vmovups  xmmword ptr [rbp-0x48], xmm0
       mov      rdi, 0x78C06D926738
       call     CORINFO_HELP_NEWSFAST
       mov      gword ptr [rbp-0x98], rax
       mov      rsi, qword ptr [rbp-0x48]
       mov      rdx, qword ptr [rbp-0x40]
       mov      rdi, gword ptr [rbp-0x98]
       call     [Lokad.Lython.LythonMemoryBudget:.ctor(System.Nullable`1[long]):this]
       mov      rax, gword ptr [rbp-0x98]
       mov      gword ptr [rbp-0x70], rax
 
G_M000_IG06:                ;; offset=0x017E
       mov      rax, gword ptr [rbp-0x70]
       mov      gword ptr [rbp-0x28], rax
       mov      rax, gword ptr [rbp-0x28]
       mov      gword ptr [rbp-0xB0], rax
       mov      rdi, gword ptr [rbp-0xB0]
       mov      rsi, 0x78C06E8D7F30
       call     CORINFO_HELP_CLASSPROFILE32
       mov      rax, gword ptr [rbp-0xB0]
       mov      gword ptr [rbp-0xD8], rax
       mov      rdi, gword ptr [rbp-0xD8]
       mov      r11, 0x78C06BA73A70
       call     [r11]Lokad.Lython.ILythonMemoryBudget:CreateScope():Lokad.Lython.ILythonMemoryScope:this
       mov      gword ptr [rbp-0x30], rax
 
G_M000_IG07:                ;; offset=0x01CD
       mov      rdi, gword ptr [rbp-0x18]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.LythonRunOptions:get_ResultMemoryBudget():Lokad.Lython.ILythonMemoryBudget:this]
       mov      gword ptr [rbp-0x78], rax
       mov      rax, gword ptr [rbp-0x78]
       mov      gword ptr [rbp-0x80], rax
       cmp      gword ptr [rbp-0x78], 0
       jne      SHORT G_M000_IG08
       mov      rdi, 0x78C06E8D8038
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, gword ptr [rbp-0x28]
       mov      gword ptr [rbp-0x80], rax
 
G_M000_IG08:                ;; offset=0x0203
       mov      rax, gword ptr [rbp-0x80]
       mov      gword ptr [rbp-0xB8], rax
       mov      rdi, gword ptr [rbp-0xB8]
       mov      rsi, 0x78C06E8D8040
       call     CORINFO_HELP_CLASSPROFILE32
       mov      rax, gword ptr [rbp-0xB8]
       mov      gword ptr [rbp-0xE0], rax
       mov      rdi, gword ptr [rbp-0xE0]
       mov      r11, 0x78C06BA73A78
       call     [r11]Lokad.Lython.ILythonMemoryBudget:CreateScope():Lokad.Lython.ILythonMemoryScope:this
       mov      gword ptr [rbp-0x38], rax
 
G_M000_IG09:                ;; offset=0x024A
       mov      rax, gword ptr [rbp-0x20]
       mov      gword ptr [rbp-0xC0], rax
       mov      rdi, gword ptr [rbp-0xC0]
       mov      rsi, 0x78C06E8D8148
       call     CORINFO_HELP_DELEGATEPROFILE32
       mov      rax, gword ptr [rbp-0xC0]
       mov      gword ptr [rbp-0xE8], rax
       mov      rdi, gword ptr [rbp-0x18]
       mov      rsi, gword ptr [rbp-0x30]
       mov      rdx, gword ptr [rbp-0x38]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.LythonRunOptions:WithMemoryOwners(Lokad.Lython.ILythonMemoryBudget,Lokad.Lython.ILythonMemoryBudget):Lokad.Lython.LythonRunOptions:this]
       mov      gword ptr [rbp-0xF0], rax
       mov      rax, gword ptr [rbp-0xE8]
       mov      rdx, gword ptr [rbp-0xF0]
       mov      rsi, gword ptr [rbp-0x10]
       mov      rdi, gword ptr [rax+0x10]
       mov      rax, gword ptr [rbp-0xE8]
       call     [rax+0x18]System.Func`3[System.__Canon,System.__Canon,System.__Canon]:Invoke(System.__Canon,System.__Canon):System.__Canon:this
       mov      gword ptr [rbp-0xF8], rax
       mov      rdi, gword ptr [rbp-0xF8]
       mov      rsi, gword ptr [rbp-0x38]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.LythonExecutionResult:OwnMemoryScope(Lokad.Lython.ILythonMemoryScope):Lokad.Lython.LythonExecutionResult:this]
       mov      gword ptr [rbp-0x50], rax
       jmp      SHORT G_M000_IG11
 
G_M000_IG10:                ;; offset=0x02D4
       mov      rdi, 0x78C06E8D8358
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG06
 
G_M000_IG11:                ;; offset=0x02E8
       call     G_M000_IG16
       nop      
 
G_M000_IG12:                ;; offset=0x02EE
       mov      rdi, 0x78C06E8D846C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, gword ptr [rbp-0x50]
 
G_M000_IG13:                ;; offset=0x0301
       add      rsp, 272
       pop      rbp
       ret      
 
G_M000_IG14:                ;; offset=0x030A
       push     rax
 
G_M000_IG15:                ;; offset=0x030B
       mov      gword ptr [rbp-0x88], rdi
       mov      rax, gword ptr [rbp-0x38]
       mov      gword ptr [rbp-0xC8], rax
       mov      rdi, gword ptr [rbp-0xC8]
       mov      rsi, 0x78C06E8D8250
       call     CORINFO_HELP_CLASSPROFILE32
       mov      rax, gword ptr [rbp-0xC8]
       mov      gword ptr [rbp-0x100], rax
       mov      rdi, gword ptr [rbp-0x100]
       mov      r11, 0x78C06BA73A80
       call     [r11]System.IDisposable:Dispose():this
       call     CORINFO_HELP_RETHROW
       int3     
 
G_M000_IG16:                ;; offset=0x035B
       push     rax
 
G_M000_IG17:                ;; offset=0x035C
       cmp      gword ptr [rbp-0x30], 0
       je       SHORT G_M000_IG18
       mov      rdi, 0x78C06E8D835C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, gword ptr [rbp-0x30]
       mov      gword ptr [rbp-0xD0], rax
       mov      rdi, gword ptr [rbp-0xD0]
       mov      rsi, 0x78C06E8D8360
       call     CORINFO_HELP_CLASSPROFILE32
       mov      rax, gword ptr [rbp-0xD0]
       mov      gword ptr [rbp-0x108], rax
       mov      rdi, gword ptr [rbp-0x108]
       mov      r11, 0x78C06BA73A88
       call     [r11]System.IDisposable:Dispose():this
 
G_M000_IG18:                ;; offset=0x03B5
       mov      rdi, 0x78C06E8D8468
       call     CORINFO_HELP_COUNTPROFILE32
       nop      
 
G_M000_IG19:                ;; offset=0x03C5
       add      rsp, 8
       ret      
 
; Total bytes of code 970

; Assembly listing for method Lokad.Lython.LythonCompiledScript:RunCore(Lokad.Lython.ILythonHost,Lokad.Lython.LythonRunOptions):Lokad.Lython.LythonExecutionResult:this (Tier1)
; Emitting BLENDED_CODE for x64 + VEX + EVEX on Unix
; Tier1 code
; optimized code
; optimized using Synthesized PGO
; rbp based frame
; fully interruptible
; with Synthesized PGO: fgCalledCount is 149
; 16 inlinees with PGO data; 70 single block inlinees; 8 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       push     r15
       push     r14
       push     r13
       push     r12
       push     rbx
       sub      rsp, 232
       lea      rbp, [rsp+0x110]
       vxorps   xmm8, xmm8, xmm8
       vmovdqu32 zmmword ptr [rbp-0xB0], zmm8
       vmovdqu32 zmmword ptr [rbp-0x80], zmm8
       xor      eax, eax
       mov      qword ptr [rbp-0x40], rax
       mov      r15, rsi
       mov      rbx, rdx
 
G_M000_IG02:                ;; offset=0x003B
       mov      r14, gword ptr [rdi+0x08]
       test     r14, r14
       je       G_M000_IG66
       test     rbx, rbx
       jne      SHORT G_M000_IG04
 
G_M000_IG03:                ;; offset=0x004D
       mov      rax, 0x78C06D9E6A60
       mov      qword ptr [rbp-0xB0], rax
       lea      rbx, [rbp-0xB0]
 
G_M000_IG04:                ;; offset=0x0065
       mov      r13, gword ptr [rbx+0x38]
       test     r13, r13
       jne      SHORT G_M000_IG06
 
G_M000_IG05:                ;; offset=0x006E
       mov      r13, gword ptr [rdi+0x20]
       test     r13, r13
       je       G_M000_IG67
 
G_M000_IG06:                ;; offset=0x007B
       mov      rdi, 0x78C06D926738
       cmp      qword ptr [r13], rdi
       jne      G_M000_IG68
       mov      r12, gword ptr [r13+0x10]
       mov      rdi, gword ptr [r12+0x08]
       mov      rdi, gword ptr [rdi+0x08]
       mov      gword ptr [rbp-0xC8], rdi
       xor      edi, edi
       mov      dword ptr [rbp-0x2C], edi
 
G_M000_IG07:                ;; offset=0x00A8
       mov      rdi, gword ptr [rbp-0xC8]
       call     [System.Threading.Monitor:Enter(System.Object)]
       mov      dword ptr [rbp-0x2C], 1
       cmp      byte  ptr [r12+0x38], 0
       jne      G_M000_IG10
       mov      rdi, 0x78C06D926B38
       call     CORINFO_HELP_NEWSFAST
       mov      gword ptr [rbp-0xD0], rax
       mov      rsi, gword ptr [r12+0x08]
       lea      rdi, bword ptr [rax+0x08]
       call     CORINFO_HELP_ASSIGN_REF
       mov      rax, gword ptr [rbp-0xD0]
       lea      rdi, bword ptr [rax+0x10]
       mov      rsi, r12
       call     CORINFO_HELP_ASSIGN_REF
       mov      rax, gword ptr [r12+0x18]
       mov      gword ptr [rbp-0x100], rax
       mov      rcx, gword ptr [rbp-0xD0]
       lea      rdi, bword ptr [rcx+0x20]
       mov      rsi, rax
       call     CORINFO_HELP_ASSIGN_REF
       mov      rsi, gword ptr [rbp-0x100]
       test     rsi, rsi
       je       SHORT G_M000_IG09
 
G_M000_IG08:                ;; offset=0x012A
       lea      rdi, bword ptr [rsi+0x28]
       mov      rsi, gword ptr [rbp-0xD0]
       call     CORINFO_HELP_ASSIGN_REF
 
G_M000_IG09:                ;; offset=0x013A
       lea      rdi, bword ptr [r12+0x18]
       mov      rsi, gword ptr [rbp-0xD0]
       call     CORINFO_HELP_ASSIGN_REF
       jmp      SHORT G_M000_IG11
 
G_M000_IG10:                ;; offset=0x014D
       mov      rdi, r12
       call     [System.ThrowHelper:ThrowObjectDisposedException(System.Object)]
       int3     
 
G_M000_IG11:                ;; offset=0x0157
       mov      rdi, gword ptr [rbp-0xC8]
       call     [System.Threading.Monitor:Exit(System.Object)]
       mov      r12, gword ptr [rbp-0xD0]
 
G_M000_IG12:                ;; offset=0x016B
       mov      gword ptr [rbp-0xB8], r12
 
G_M000_IG13:                ;; offset=0x0172
       mov      rdi, gword ptr [rbx+0x40]
       test     rdi, rdi
       cmove    rdi, r13
       mov      rax, 0x78C06D926738
       cmp      qword ptr [rdi], rax
       jne      G_M000_IG62
       mov      r13, gword ptr [rdi+0x10]
       mov      rdi, gword ptr [r13+0x08]
       mov      rdi, gword ptr [rdi+0x08]
       mov      gword ptr [rbp-0xD8], rdi
       xor      edi, edi
       mov      dword ptr [rbp-0x30], edi
 
G_M000_IG14:                ;; offset=0x01A8
       mov      rdi, gword ptr [rbp-0xD8]
       call     [System.Threading.Monitor:Enter(System.Object)]
       mov      dword ptr [rbp-0x30], 1
       cmp      byte  ptr [r13+0x38], 0
       jne      G_M000_IG17
       mov      rdi, 0x78C06D926B38
       call     CORINFO_HELP_NEWSFAST
       mov      gword ptr [rbp-0xE0], rax
       mov      rsi, gword ptr [r13+0x08]
       lea      rdi, bword ptr [rax+0x08]
       call     CORINFO_HELP_ASSIGN_REF
       mov      rax, gword ptr [rbp-0xE0]
       lea      rdi, bword ptr [rax+0x10]
       mov      rsi, r13
       call     CORINFO_HELP_ASSIGN_REF
       mov      rax, gword ptr [r13+0x18]
       mov      gword ptr [rbp-0x108], rax
       mov      rcx, gword ptr [rbp-0xE0]
       lea      rdi, bword ptr [rcx+0x20]
       mov      rsi, rax
       call     CORINFO_HELP_ASSIGN_REF
       mov      rsi, gword ptr [rbp-0x108]
       test     rsi, rsi
       je       SHORT G_M000_IG16
 
G_M000_IG15:                ;; offset=0x0227
       lea      rdi, bword ptr [rsi+0x28]
       mov      rsi, gword ptr [rbp-0xE0]
       call     CORINFO_HELP_ASSIGN_REF
 
G_M000_IG16:                ;; offset=0x0237
       lea      rdi, bword ptr [r13+0x18]
       mov      rsi, gword ptr [rbp-0xE0]
       call     CORINFO_HELP_ASSIGN_REF
       jmp      SHORT G_M000_IG18
 
G_M000_IG17:                ;; offset=0x0249
       mov      rdi, r13
       call     [System.ThrowHelper:ThrowObjectDisposedException(System.Object)]
       int3     
 
G_M000_IG18:                ;; offset=0x0253
       mov      rdi, gword ptr [rbp-0xD8]
       call     [System.Threading.Monitor:Exit(System.Object)]
       mov      r13, gword ptr [rbp-0xE0]
 
G_M000_IG19:                ;; offset=0x0267
       mov      gword ptr [rbp-0xC0], r13
 
G_M000_IG20:                ;; offset=0x026E
       mov      rax, gword ptr [rbx+0x60]
       mov      gword ptr [rbp-0xF8], rax
       mov      rdi, 0x78C06D9E6A60
       call     CORINFO_HELP_NEWSFAST
       mov      gword ptr [rbp-0xE8], rax
       mov      rsi, gword ptr [rbx+0x08]
       lea      rdi, bword ptr [rax+0x08]
       call     CORINFO_HELP_ASSIGN_REF
       mov      rsi, gword ptr [rbx+0x10]
       mov      rax, gword ptr [rbp-0xE8]
       lea      rdi, bword ptr [rax+0x10]
       call     CORINFO_HELP_ASSIGN_REF
       mov      rsi, gword ptr [rbx+0x18]
       mov      rax, gword ptr [rbp-0xE8]
       lea      rdi, bword ptr [rax+0x18]
       call     CORINFO_HELP_ASSIGN_REF
       mov      rsi, gword ptr [rbx+0x20]
       mov      rax, gword ptr [rbp-0xE8]
       lea      rdi, bword ptr [rax+0x20]
       call     CORINFO_HELP_ASSIGN_REF
       mov      rax, gword ptr [rbp-0xE8]
       lea      rdi, bword ptr [rax+0x60]
       mov      rsi, gword ptr [rbp-0xF8]
       call     CORINFO_HELP_ASSIGN_REF
       movzx    rdi, byte  ptr [rbx+0x58]
       mov      rax, gword ptr [rbp-0xE8]
       mov      byte  ptr [rax+0x58], dil
       mov      rsi, gword ptr [rbx+0x28]
       lea      rdi, bword ptr [rax+0x28]
       call     CORINFO_HELP_ASSIGN_REF
       mov      rsi, gword ptr [rbx+0x30]
       mov      rax, gword ptr [rbp-0xE8]
       lea      rdi, bword ptr [rax+0x30]
       call     CORINFO_HELP_ASSIGN_REF
       mov      rdi, qword ptr [rbx+0x68]
       mov      rax, gword ptr [rbp-0xE8]
       mov      qword ptr [rax+0x68], rdi
       mov      rsi, gword ptr [rbx+0x38]
       lea      rdi, bword ptr [rax+0x38]
 
G_M000_IG21:                ;; offset=0x0337
       call     CORINFO_HELP_ASSIGN_REF
       mov      rsi, gword ptr [rbx+0x40]
       mov      rbx, gword ptr [rbp-0xE8]
       lea      rdi, bword ptr [rbx+0x40]
       call     CORINFO_HELP_ASSIGN_REF
       lea      rdi, bword ptr [rbx+0x48]
       mov      rsi, r12
       call     CORINFO_HELP_ASSIGN_REF
       lea      rdi, bword ptr [rbx+0x50]
       mov      rsi, r13
       call     CORINFO_HELP_ASSIGN_REF
       mov      rdi, 0x78C06DC9A1D8
       cmp      qword ptr [r14+0x18], rdi
       jne      G_M000_IG61
       mov      r14, gword ptr [r14+0x10]
       mov      rdi, r14
       call     [Lokad.Lython.LythonEngine+<>c__DisplayClass8_0:<CompileCore>g__CreatePreExecutionFailure|1():Lokad.Lython.LythonExecutionResult:this]
       mov      r13, rax
       test     r13, r13
       jne      G_M000_IG57
       mov      rdi, 0x78C06DFA6208
       call     CORINFO_HELP_NEWSFAST
       mov      r13, rax
       mov      rsi, gword ptr [r14+0x10]
       mov      r12, gword ptr [r14+0x18]
       lea      rdi, bword ptr [r13+0x08]
       call     CORINFO_HELP_ASSIGN_REF
       lea      rdi, bword ptr [r13+0x10]
       mov      rsi, r12
       call     CORINFO_HELP_ASSIGN_REF
       mov      r14, gword ptr [r14+0x20]
       test     r14, r14
       je       G_M000_IG58
       mov      rdi, 0x78C06E40C9A0
       call     CORINFO_HELP_NEWSFAST
       mov      r12, rax
 
G_M000_IG22:                ;; offset=0x03E3
       lea      rdi, bword ptr [r12+0x08]
       mov      rsi, r15
       call     CORINFO_HELP_ASSIGN_REF
       lea      rdi, bword ptr [r12+0x10]
       mov      rsi, rbx
       call     CORINFO_HELP_ASSIGN_REF
       lea      rdi, bword ptr [r12+0x18]
       mov      rsi, r13
       call     CORINFO_HELP_ASSIGN_REF
       lea      rdi, bword ptr [r12+0x20]
       mov      rsi, r14
       call     CORINFO_HELP_ASSIGN_REF
       mov      rdi, 0x78C06E40CA20
       call     CORINFO_HELP_NEWSFAST
       mov      r15, rax
       lea      rdi, bword ptr [r15+0x10]
       mov      rsi, r12
       call     CORINFO_HELP_ASSIGN_REF
       mov      rdi, 0x78C06E410C78
       mov      qword ptr [r15+0x18], rdi
       mov      rdi, 0x78B88D803120
       mov      rbx, gword ptr [rdi]
       mov      rdi, 0x78C0EAF013F0
       mov      rax, 0x78C0EB7C8810
       call     rax
       cmp      dword ptr [rax], 4
       jle      G_M000_IG59
       mov      rdi, gword ptr [rax+0x08]
       mov      rax, bword ptr [rdi+0x20]
       test     rax, rax
       je       G_M000_IG59
 
G_M000_IG23:                ;; offset=0x0480
       mov      rax, gword ptr [rax+0x10]
       test     rax, rax
       jne      SHORT G_M000_IG25
 
G_M000_IG24:                ;; offset=0x0489
       call     [System.Threading.Thread:InitializeCurrentThread():System.Threading.Thread]
 
G_M000_IG25:                ;; offset=0x048F
       mov      r14, gword ptr [rax+0x08]
       test     r14, r14
       jne      G_M000_IG60
       mov      rdi, 0x78B88D801158
       mov      r14, gword ptr [rdi]
 
G_M000_IG26:                ;; offset=0x04A9
       mov      rdi, 0x78C06E40CDB0
       call     CORINFO_HELP_NEWSFAST
       mov      r13, rax
       mov      rdi, 0x78C06BA64828
       call     CORINFO_HELP_NEWSFAST
       mov      rsi, rax
       lea      rdi, bword ptr [r13+0x18]
       call     CORINFO_HELP_ASSIGN_REF
       lea      rdi, bword ptr [r13+0x20]
       mov      rsi, r15
       call     CORINFO_HELP_ASSIGN_REF
       lea      rdi, bword ptr [r13+0x08]
       mov      rsi, r14
       call     CORINFO_HELP_ASSIGN_REF
       mov      rdi, gword ptr [rbx+0x08]
       mov      gword ptr [rbp-0xF0], rdi
       xor      edi, edi
       mov      dword ptr [rbp-0x34], edi
 
G_M000_IG27:                ;; offset=0x04FE
       mov      rdi, gword ptr [rbp-0xF0]
       call     [System.Threading.Monitor:Enter(System.Object)]
       mov      dword ptr [rbp-0x34], 1
       cmp      byte  ptr [rbx+0x20], 0
       jne      G_M000_IG45
       mov      r15, gword ptr [rbx+0x10]
       mov      r14, gword ptr [r15+0x08]
       test     r14, r14
       je       G_M000_IG51
       cmp      byte  ptr [r15], r15b
       cmp      gword ptr [r14+0x08], r15
       jne      G_M000_IG46
       cmp      gword ptr [r14+0x10], r14
       jne      G_M000_IG47
       xor      rdi, rdi
       mov      gword ptr [r15+0x08], rdi
 
G_M000_IG28:                ;; offset=0x054A
       xor      rdi, rdi
       mov      gword ptr [r14+0x08], rdi
 
G_M000_IG29:                ;; offset=0x0550
       mov      gword ptr [r14+0x10], rdi
 
G_M000_IG30:                ;; offset=0x0554
       mov      gword ptr [r14+0x18], rdi
       dec      dword ptr [r15+0x18]
       inc      dword ptr [r15+0x1C]
       mov      rdi, gword ptr [r14+0x20]
       xor      rsi, rsi
       mov      gword ptr [rdi+0x20], rsi
       lea      rdi, bword ptr [rdi+0x18]
       mov      rsi, r13
       call     CORINFO_HELP_ASSIGN_REF
       mov      rbx, gword ptr [rbx+0x08]
       test     rbx, rbx
       je       G_M000_IG48
       mov      rdi, rbx
       call     System.Threading.ObjectHeader:GetLockHandleIfExists(System.Object):nint
       test     rax, rax
       je       G_M000_IG40
 
G_M000_IG31:                ;; offset=0x0594
       mov      r15, gword ptr [rax]
 
G_M000_IG32:                ;; offset=0x0597
       cmp      byte  ptr [r15], r15b
 
G_M000_IG33:                ;; offset=0x059A
       mov      rbx, gword ptr [r15+0x08]
       test     rbx, rbx
       jne      G_M000_IG41
 
G_M000_IG34:                ;; offset=0x05A7
       mov      rdi, 0x78C06DCC9430
       call     CORINFO_HELP_NEWSFAST
       mov      r14, rax
       lea      rdi, bword ptr [r14+0x08]
       mov      rsi, r15
       call     CORINFO_HELP_ASSIGN_REF
       mov      rsi, gword ptr [r15+0x08]
       test     rsi, rsi
       jne      SHORT G_M000_IG43
 
G_M000_IG35:                ;; offset=0x05CE
       mov      rdi, rsi
       test     rdi, rdi
       je       SHORT G_M000_IG37
 
G_M000_IG36:                ;; offset=0x05D6
       mov      rax, 0x78C06DCB6270
       cmp      qword ptr [rdi], rax
       jne      G_M000_IG49
 
G_M000_IG37:                ;; offset=0x05E9
       mov      rsi, rdi
 
G_M000_IG38:                ;; offset=0x05EC
       lea      rdi, bword ptr [r14+0x10]
       call     CORINFO_HELP_ASSIGN_REF
       lea      rdi, bword ptr [r15+0x08]
       test     rdi, rdi
       je       G_M000_IG50
       mov      rsi, r14
       mov      rdx, rbx
       call     System.Threading.Interlocked:CompareExchangeObject(byref,System.Object,System.Object):System.Object
       cmp      rax, rbx
       jne      SHORT G_M000_IG33
       mov      rdi, r14
 
G_M000_IG39:                ;; offset=0x0615
       call     [System.Threading.Condition:SignalAll():this]
       jmp      G_M000_IG55
 
G_M000_IG40:                ;; offset=0x0620
       mov      rdi, rbx
       call     [System.Threading.ObjectHeader:<GetLockObject>g__GetLockObjectFallback|11_0(System.Object):System.Threading.Lock]
       mov      r15, rax
       jmp      G_M000_IG32
 
G_M000_IG41:                ;; offset=0x0631
       mov      rdi, 0x78C06DCC9430
       cmp      qword ptr [rbx], rdi
       jne      G_M000_IG34
 
G_M000_IG42:                ;; offset=0x0644
       mov      rdi, rbx
       jmp      SHORT G_M000_IG39
 
G_M000_IG43:                ;; offset=0x0649
       mov      rdi, 0x78C06DCC9430
       cmp      qword ptr [rsi], rdi
       jne      G_M000_IG35
 
G_M000_IG44:                ;; offset=0x065C
       mov      rsi, gword ptr [rsi+0x10]
       jmp      SHORT G_M000_IG38
 
G_M000_IG45:                ;; offset=0x0662
       mov      rdi, rbx
       call     [System.ThrowHelper:ThrowObjectDisposedException(System.Object)]
       int3     
 
G_M000_IG46:                ;; offset=0x066C
       mov      rdi, 0x78C06D3A7A68
       call     CORINFO_HELP_NEWSFAST
       mov      r13, rax
       call     [System.SR:get_ExternalLinkedListNode():System.String]
       mov      rsi, rax
       mov      rdi, r13
       call     [System.InvalidOperationException:.ctor(System.String):this]
       mov      rdi, r13
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG47:                ;; offset=0x0699
       mov      rdi, gword ptr [r14+0x10]
       lea      rdi, bword ptr [rdi+0x18]
       mov      rsi, gword ptr [r14+0x18]
       call     CORINFO_HELP_ASSIGN_REF
       mov      rdi, gword ptr [r14+0x18]
       lea      rdi, bword ptr [rdi+0x10]
       mov      rsi, gword ptr [r14+0x10]
       call     CORINFO_HELP_ASSIGN_REF
       mov      rsi, gword ptr [r14+0x10]
       lea      rdi, bword ptr [r15+0x08]
       call     CORINFO_HELP_ASSIGN_REF
       jmp      G_M000_IG28
 
G_M000_IG48:                ;; offset=0x06CD
       mov      rdi, 0x78C0684007E8
       call     [System.ArgumentNullException:Throw(System.String)]
       int3     
 
G_M000_IG49:                ;; offset=0x06DE
       mov      rdi, rax
       call     CORINFO_HELP_CHKCASTCLASS
       int3     
 
G_M000_IG50:                ;; offset=0x06E7
       call     [System.ThrowHelper:ThrowNullReferenceException()]
       int3     
 
G_M000_IG51:                ;; offset=0x06EE
       mov      rdi, 0x78C06E257320
       call     CORINFO_HELP_NEWSFAST
       mov      r15, rax
       mov      rdi, r15
       mov      rsi, rbx
       mov      rdx, r13
       call     [Lokad.Lython.Runtime.ExecutionThreads+Worker:.ctor(Lokad.Lython.Runtime.ExecutionThreads,Lokad.Lython.Runtime.ExecutionThreads+WorkItem):this]
       call     [System.Threading.ExecutionContext:IsFlowSuppressed():bool]
       test     eax, eax
       je       SHORT G_M000_IG52
       mov      rdi, gword ptr [r15+0x10]
       cmp      byte  ptr [rdi], dil
       mov      esi, 1
       call     [System.Threading.Thread:Start(bool):this]
       jmp      SHORT G_M000_IG55
 
G_M000_IG52:                ;; offset=0x072D
       call     [System.Threading.ExecutionContext:SuppressFlow():System.Threading.AsyncFlowControl]
       mov      gword ptr [rbp-0x40], rax
 
G_M000_IG53:                ;; offset=0x0737
       mov      rdi, gword ptr [r15+0x10]
       cmp      byte  ptr [rdi], dil
       mov      esi, 1
       call     [System.Threading.Thread:Start(bool):this]
       nop      
 
G_M000_IG54:                ;; offset=0x074A
       lea      rdi, [rbp-0x40]
       call     [System.Threading.AsyncFlowControl:Undo():this]
       nop      
 
G_M000_IG55:                ;; offset=0x0755
       mov      rdi, gword ptr [rbp-0xF0]
       call     [System.Threading.Monitor:Exit(System.Object)]
       mov      rdi, r13
       call     [Lokad.Lython.Runtime.ExecutionThreads+SynchronousWorkItem:Wait():Lokad.Lython.LythonExecutionResult:this]
       mov      r15, rax
 
G_M000_IG56:                ;; offset=0x076E
       lea      rdi, bword ptr [r15+0x28]
       mov      rsi, gword ptr [rbp-0xC0]
       call     CORINFO_HELP_ASSIGN_REF
       jmp      SHORT G_M000_IG63
 
G_M000_IG57:                ;; offset=0x0780
       mov      r15, r13
       jmp      SHORT G_M000_IG56
 
G_M000_IG58:                ;; offset=0x0785
       mov      rdi, 0x78C06D3A7A68
       call     CORINFO_HELP_NEWSFAST
       mov      r15, rax
       mov      rdi, r15
       mov      rsi, 0x78C06840EE38
       call     [System.InvalidOperationException:.ctor(System.String):this]
       mov      rdi, r15
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG59:                ;; offset=0x07B3
       mov      edi, 4
       call     CORINFO_HELP_GETDYNAMIC_GCTHREADSTATIC_BASE_NOCTOR_OPTIMIZED
       jmp      G_M000_IG23
 
G_M000_IG60:                ;; offset=0x07C2
       xor      rdi, rdi
       cmp      byte  ptr [r14+0x18], 0
       cmovne   r14, rdi
       jmp      G_M000_IG26
 
G_M000_IG61:                ;; offset=0x07D2
       mov      rsi, r15
       mov      rdx, rbx
       mov      rdi, gword ptr [r14+0x10]
       call     [r14+0x18]System.Func`3[System.__Canon,System.__Canon,System.__Canon]:Invoke(System.__Canon,System.__Canon):System.__Canon:this
       mov      r15, rax
       jmp      SHORT G_M000_IG56
 
G_M000_IG62:                ;; offset=0x07E5
       mov      r11, 0x78C06BA74E08
       call     [r11]Lokad.Lython.ILythonMemoryBudget:CreateScope():Lokad.Lython.ILythonMemoryScope:this
       mov      r13, rax
       jmp      G_M000_IG19
 
G_M000_IG63:                ;; offset=0x07FA
       cmp      gword ptr [rbp-0xB8], 0
       je       SHORT G_M000_IG64
       mov      rdi, 0x78C06D926B38
       mov      rax, gword ptr [rbp-0xB8]
       cmp      qword ptr [rax], rdi
       jne      G_M000_IG69
       mov      rdi, rax
       call     [Lokad.Lython.LythonMemoryBudget+Scope:Dispose():this]
 
G_M000_IG64:                ;; offset=0x0827
       mov      rax, r15
 
G_M000_IG65:                ;; offset=0x082A
       add      rsp, 232
       pop      rbx
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG66:                ;; offset=0x083C
       mov      rdi, 0x78C06D886F18
       call     CORINFO_HELP_NEWSFAST
       mov      rbx, rax
       mov      rdi, rbx
       mov      rsi, 0x78C0684583E8
       call     [System.ObjectDisposedException:.ctor(System.String):this]
       mov      rdi, rbx
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG67:                ;; offset=0x086A
       mov      rdi, 0x78C06D926738
       call     CORINFO_HELP_NEWSFAST
       mov      r13, rax
       xor      esi, esi
       xor      edx, edx
       mov      rdi, r13
       call     [Lokad.Lython.LythonMemoryBudget:.ctor(System.Nullable`1[long]):this]
       jmp      G_M000_IG06
 
G_M000_IG68:                ;; offset=0x088E
       mov      rdi, r13
       mov      r11, 0x78C06BA74E00
       call     [r11]Lokad.Lython.ILythonMemoryBudget:CreateScope():Lokad.Lython.ILythonMemoryScope:this
       mov      r12, rax
       jmp      G_M000_IG12
 
G_M000_IG69:                ;; offset=0x08A6
       mov      rdi, rax
       mov      r11, 0x78C06BA74E18
       call     [r11]System.IDisposable:Dispose():this
       jmp      G_M000_IG64
 
G_M000_IG70:                ;; offset=0x08BB
       push     rax
 
G_M000_IG71:                ;; offset=0x08BC
       lea      rdi, [rbp-0x40]
       call     [System.Threading.AsyncFlowControl:Undo():this]
       nop      
 
G_M000_IG72:                ;; offset=0x08C7
       add      rsp, 8
       ret      
 
G_M000_IG73:                ;; offset=0x08CC
       push     rax
 
G_M000_IG74:                ;; offset=0x08CD
       cmp      dword ptr [rbp-0x34], 0
       je       SHORT G_M000_IG75
       mov      rdi, gword ptr [rbp-0xF0]
       call     [System.Threading.Monitor:Exit(System.Object)]
 
G_M000_IG75:                ;; offset=0x08E0
       nop      
 
G_M000_IG76:                ;; offset=0x08E1
       add      rsp, 8
       ret      
 
G_M000_IG77:                ;; offset=0x08E6
       push     rax
 
G_M000_IG78:                ;; offset=0x08E7
       mov      rdi, gword ptr [rbp-0xC0]
       mov      r11, 0x78C06BA74E10
       call     [r11]System.IDisposable:Dispose():this
       call     CORINFO_HELP_RETHROW
       int3     
 
G_M000_IG79:                ;; offset=0x0901
       push     rax
 
G_M000_IG80:                ;; offset=0x0902
       cmp      dword ptr [rbp-0x30], 0
       je       SHORT G_M000_IG81
       mov      rdi, gword ptr [rbp-0xD8]
       call     [System.Threading.Monitor:Exit(System.Object)]
 
G_M000_IG81:                ;; offset=0x0915
       nop      
 
G_M000_IG82:                ;; offset=0x0916
       add      rsp, 8
       ret      
 
G_M000_IG83:                ;; offset=0x091B
       push     rax
 
G_M000_IG84:                ;; offset=0x091C
       cmp      gword ptr [rbp-0xB8], 0
       je       SHORT G_M000_IG86
       mov      rdi, 0x78C06D926B38
       mov      rax, gword ptr [rbp-0xB8]
       cmp      qword ptr [rax], rdi
       jne      SHORT G_M000_IG85
       mov      rdi, rax
       call     [Lokad.Lython.LythonMemoryBudget+Scope:Dispose():this]
       jmp      SHORT G_M000_IG86
 
G_M000_IG85:                ;; offset=0x0947
       mov      rdi, rax
       mov      r11, 0x78C06BA74E18
       call     [r11]System.IDisposable:Dispose():this
 
G_M000_IG86:                ;; offset=0x0957
       nop      
 
G_M000_IG87:                ;; offset=0x0958
       add      rsp, 8
       ret      
 
G_M000_IG88:                ;; offset=0x095D
       push     rax
 
G_M000_IG89:                ;; offset=0x095E
       cmp      dword ptr [rbp-0x2C], 0
       je       SHORT G_M000_IG90
       mov      rdi, gword ptr [rbp-0xC8]
       call     [System.Threading.Monitor:Exit(System.Object)]
 
G_M000_IG90:                ;; offset=0x0971
       nop      
 
G_M000_IG91:                ;; offset=0x0972
       add      rsp, 8
       ret      
 
; Total bytes of code 2423

