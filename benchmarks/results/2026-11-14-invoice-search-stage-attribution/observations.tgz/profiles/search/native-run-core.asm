; Assembly listing for method Lokad.Lython.LythonCompiledScript:RunCore(Lokad.Lython.ILythonHost,Lokad.Lython.LythonRunOptions):Lokad.Lython.LythonExecutionResult:this (Tier0)
; Emitting BLENDED_CODE for x64 + VEX + EVEX on Unix
; Tier0 code
; rbp based frame
; fully interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 192
       lea      rbp, [rsp+0xC0]
       xor      eax, eax
       mov      qword ptr [rbp-0xB8], rax
       vxorps   xmm8, xmm8, xmm8
       vmovdqu32 zmmword ptr [rbp-0xB0], zmm8
       vmovdqu32 zmmword ptr [rbp-0x70], zmm8
       vmovdqa  xmmword ptr [rbp-0x30], xmm8
       mov      qword ptr [rbp-0x20], rax
       mov      gword ptr [rbp-0x08], rdi
       mov      gword ptr [rbp-0x10], rsi
       mov      gword ptr [rbp-0x18], rdx
 
G_M000_IG02:                ;; offset=0x0047
       mov      rax, gword ptr [rbp-0x08]
       mov      rax, gword ptr [rax+0x08]
       mov      gword ptr [rbp-0x58], rax
       mov      rax, gword ptr [rbp-0x58]
       mov      gword ptr [rbp-0x60], rax
       cmp      gword ptr [rbp-0x58], 0
       jne      SHORT G_M000_IG04
 
G_M000_IG03:                ;; offset=0x0062
       mov      rdi, 0x7BE47FE66F18
       call     CORINFO_HELP_NEWSFAST
       mov      gword ptr [rbp-0xA8], rax
       mov      rdi, gword ptr [rbp-0xA8]
       mov      rsi, 0x7BE47C253300
       call     [System.ObjectDisposedException:.ctor(System.String):this]
       mov      rdi, gword ptr [rbp-0xA8]
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG04:                ;; offset=0x009C
       mov      rax, gword ptr [rbp-0x60]
       mov      gword ptr [rbp-0x20], rax
       cmp      gword ptr [rbp-0x18], 0
       jne      SHORT G_M000_IG05
       mov      rdi, 0x7BE47FFC6A60
       call     CORINFO_HELP_NEWSFAST
       mov      gword ptr [rbp-0xA0], rax
       mov      rdi, gword ptr [rbp-0xA0]
       call     [Lokad.Lython.LythonRunOptions:.ctor():this]
       mov      rax, gword ptr [rbp-0xA0]
       mov      gword ptr [rbp-0x18], rax
 
G_M000_IG05:                ;; offset=0x00D9
       mov      rdi, gword ptr [rbp-0x18]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.LythonRunOptions:get_MemoryBudget():Lokad.Lython.ILythonMemoryBudget:this]
       mov      gword ptr [rbp-0x68], rax
       mov      rax, gword ptr [rbp-0x68]
       mov      gword ptr [rbp-0x70], rax
       cmp      gword ptr [rbp-0x68], 0
       jne      SHORT G_M000_IG06
       mov      rax, gword ptr [rbp-0x08]
       mov      rax, gword ptr [rax+0x20]
       mov      gword ptr [rbp-0x90], rax
       mov      rax, gword ptr [rbp-0x90]
       mov      gword ptr [rbp-0x70], rax
       cmp      gword ptr [rbp-0x90], 0
       jne      SHORT G_M000_IG06
       vxorps   xmm0, xmm0, xmm0
       vmovups  xmmword ptr [rbp-0x48], xmm0
       mov      rdi, 0x7BE47FF06738
       call     CORINFO_HELP_NEWSFAST
       mov      gword ptr [rbp-0x98], rax
       mov      rsi, qword ptr [rbp-0x48]
       mov      rdx, qword ptr [rbp-0x40]
       mov      rdi, gword ptr [rbp-0x98]
       call     [Lokad.Lython.LythonMemoryBudget:.ctor(System.Nullable`1[long]):this]
       mov      rax, gword ptr [rbp-0x98]
       mov      gword ptr [rbp-0x70], rax
 
G_M000_IG06:                ;; offset=0x015B
       mov      rax, gword ptr [rbp-0x70]
       mov      gword ptr [rbp-0x28], rax
       mov      rdi, gword ptr [rbp-0x28]
       mov      r11, 0x7BE47E051DB8
       call     [r11]Lokad.Lython.ILythonMemoryBudget:CreateScope():Lokad.Lython.ILythonMemoryScope:this
       mov      gword ptr [rbp-0x30], rax
 
G_M000_IG07:                ;; offset=0x0178
       mov      rdi, gword ptr [rbp-0x18]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.LythonRunOptions:get_ResultMemoryBudget():Lokad.Lython.ILythonMemoryBudget:this]
       mov      gword ptr [rbp-0x78], rax
       mov      rax, gword ptr [rbp-0x78]
       mov      gword ptr [rbp-0x80], rax
       cmp      gword ptr [rbp-0x78], 0
       jne      SHORT G_M000_IG08
       mov      rax, gword ptr [rbp-0x28]
       mov      gword ptr [rbp-0x80], rax
 
G_M000_IG08:                ;; offset=0x019F
       mov      rdi, gword ptr [rbp-0x80]
       mov      r11, 0x7BE47E051DC0
       call     [r11]Lokad.Lython.ILythonMemoryBudget:CreateScope():Lokad.Lython.ILythonMemoryScope:this
       mov      gword ptr [rbp-0x38], rax
 
G_M000_IG09:                ;; offset=0x01B4
       mov      rdi, gword ptr [rbp-0x18]
       mov      rsi, gword ptr [rbp-0x30]
       mov      rdx, gword ptr [rbp-0x38]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.LythonRunOptions:WithMemoryOwners(Lokad.Lython.ILythonMemoryBudget,Lokad.Lython.ILythonMemoryBudget):Lokad.Lython.LythonRunOptions:this]
       mov      gword ptr [rbp-0xB0], rax
       mov      rdx, gword ptr [rbp-0xB0]
       mov      rsi, gword ptr [rbp-0x10]
       mov      rax, gword ptr [rbp-0x20]
       mov      rdi, gword ptr [rax+0x10]
       mov      rax, gword ptr [rbp-0x20]
       call     [rax+0x18]System.Func`3[System.__Canon,System.__Canon,System.__Canon]:Invoke(System.__Canon,System.__Canon):System.__Canon:this
       mov      gword ptr [rbp-0xB8], rax
       mov      rdi, gword ptr [rbp-0xB8]
       mov      rsi, gword ptr [rbp-0x38]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.LythonExecutionResult:OwnMemoryScope(Lokad.Lython.ILythonMemoryScope):Lokad.Lython.LythonExecutionResult:this]
       mov      gword ptr [rbp-0x50], rax
 
G_M000_IG10:                ;; offset=0x0207
       call     G_M000_IG15
       nop      
 
G_M000_IG11:                ;; offset=0x020D
       mov      rax, gword ptr [rbp-0x50]
 
G_M000_IG12:                ;; offset=0x0211
       add      rsp, 192
       pop      rbp
       ret      
 
G_M000_IG13:                ;; offset=0x021A
       push     rax
 
G_M000_IG14:                ;; offset=0x021B
       mov      gword ptr [rbp-0x88], rdi
       mov      rdi, gword ptr [rbp-0x38]
       mov      r11, 0x7BE47E051DC8
       call     [r11]System.IDisposable:Dispose():this
       call     CORINFO_HELP_RETHROW
       int3     
 
G_M000_IG15:                ;; offset=0x0239
       push     rax
 
G_M000_IG16:                ;; offset=0x023A
       cmp      gword ptr [rbp-0x30], 0
       je       SHORT G_M000_IG17
       mov      rdi, gword ptr [rbp-0x30]
       mov      r11, 0x7BE47E051DD0
       call     [r11]System.IDisposable:Dispose():this
 
G_M000_IG17:                ;; offset=0x0252
       nop      
 
G_M000_IG18:                ;; offset=0x0253
       add      rsp, 8
       ret      
 
; Total bytes of code 600

; Assembly listing for method Lokad.Lython.Runtime.LythonRuntime+NativeExecution:RunCore(byref):bool:this (Instrumented Tier0)
; Emitting BLENDED_CODE for x64 + VEX + EVEX on Unix
; Instrumented Tier0 code
; rbp based frame
; fully interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 0x5D0
       lea      rbp, [rsp+0x5D0]
       vxorps   xmm8, xmm8, xmm8
       mov      rax, -0x570
 
G_M000_IG125:                ;; offset=0x001F
       vmovdqa  xmmword ptr [rbp+rax-0x40], xmm8
       vmovdqa  xmmword ptr [rbp+rax-0x30], xmm8
       vmovdqa  xmmword ptr [rbp+rax-0x20], xmm8
       add      rax, 48
       jne      SHORT G_M000_IG125
       mov      qword ptr [rbp-0x40], rax
       mov      bword ptr [rbp-0x30], rdi
       mov      bword ptr [rbp-0x38], rsi
 
G_M000_IG02:                ;; offset=0x0043
       mov      dword ptr [rbp-0x3E4], 0x3E8
       mov      rax, 0x7BDCA1801728
       mov      rsi, gword ptr [rax]
       mov      rdi, bword ptr [rbp-0x38]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       jmp      G_M000_IG115
 
G_M000_IG03:                ;; offset=0x0068
       mov      rax, bword ptr [rbp-0x30]
       mov      rdi, gword ptr [rax+0x08]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Instructions():Lokad.Lython.Frontend.ExecutableInstruction[]:this]
       mov      rcx, bword ptr [rbp-0x30]
       mov      ecx, dword ptr [rcx+0x38]
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG120
       mov      edx, ecx
       imul     rdx, rdx, 32
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      bword ptr [rbp-0x40], rax
       mov      rax, bword ptr [rbp-0x30]
       mov      rdi, gword ptr [rax+0x18]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:get_State():Lokad.Lython.Runtime.ExecutionState:this]
       mov      gword ptr [rbp-0x1A0], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x3F0], rax
       mov      rsi, gword ptr [rbp-0x3F0]
       mov      rdi, gword ptr [rbp-0x1A0]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.ExecutionState:CheckExecution(Lokad.Lython.LythonSourceSpan):this]
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_OpCode():int:this]
       mov      dword ptr [rbp-0x64], eax
       mov      eax, dword ptr [rbp-0x64]
       add      eax, -3
       mov      dword ptr [rbp-0x5B4], eax
       cmp      dword ptr [rbp-0x5B4], 3
       ja       SHORT G_M000_IG05
 
G_M000_IG04:                ;; offset=0x00F7
       mov      eax, dword ptr [rbp-0x5B4]
       lea      rcx, [reloc @RWD00]
       mov      ecx, dword ptr [rcx+4*rax]
       lea      rdx, G_M000_IG02
       add      rcx, rdx
       jmp      rcx
 
G_M000_IG05:                ;; offset=0x0113
       mov      eax, dword ptr [rbp-0x64]
       add      eax, -25
       mov      dword ptr [rbp-0x5B8], eax
       cmp      dword ptr [rbp-0x5B8], 43
       ja       SHORT G_M000_IG07
 
G_M000_IG06:                ;; offset=0x0128
       mov      eax, dword ptr [rbp-0x5B8]
       lea      rcx, [reloc @RWD16]
       mov      ecx, dword ptr [rcx+4*rax]
       lea      rdx, G_M000_IG02
       add      rcx, rdx
       jmp      rcx
 
G_M000_IG07:                ;; offset=0x0144
       mov      rdi, 0x7BE480A64150
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG113
 
G_M000_IG08:                ;; offset=0x0158
       mov      rdi, 0x7BE480A64154
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp-0x30]
       mov      rdi, gword ptr [rax+0x08]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_FirstTemporarySlot():int:this]
       mov      dword ptr [rbp-0x3F4], eax
       mov      esi, dword ptr [rbp-0x3F4]
       mov      rdi, bword ptr [rbp-0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Trim(int):this]
       jmp      G_M000_IG118
 
G_M000_IG09:                ;; offset=0x0192
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x3F8], eax
       mov      esi, dword ptr [rbp-0x3F8]
       mov      rdi, bword ptr [rbp-0x30]
       xor      edx, edx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Read(int,int):System.Object:this]
       mov      rsi, rax
       mov      rdi, bword ptr [rbp-0x38]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x1A4], eax
       mov      rax, bword ptr [rbp-0x30]
       mov      rdi, gword ptr [rax+0x08]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_FirstTemporarySlot():int:this]
       cmp      eax, dword ptr [rbp-0x1A4]
       jg       SHORT G_M000_IG10
       mov      rdi, 0x7BE480A64158
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp-0x30]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp-0x30]
       add      rax, 72
       mov      bword ptr [rbp-0x1B0], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x1B4], eax
       mov      rax, bword ptr [rbp-0x1B0]
       mov      eax, dword ptr [rax+0x08]
       cmp      dword ptr [rbp-0x1B4], eax
       jae      G_M000_IG120
       mov      rax, bword ptr [rbp-0x1B0]
       mov      rax, bword ptr [rax]
       mov      ecx, dword ptr [rbp-0x1B4]
       xor      rdx, rdx
       mov      gword ptr [rax+8*rcx], rdx
 
G_M000_IG10:                ;; offset=0x0248
       mov      rdi, 0x7BE480A6415C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp-0x30]
       mov      rdi, gword ptr [rax+0x08]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_FirstTemporarySlot():int:this]
       mov      dword ptr [rbp-0x3FC], eax
       mov      esi, dword ptr [rbp-0x3FC]
       mov      rdi, bword ptr [rbp-0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Trim(int):this]
       jmp      G_M000_IG118
 
G_M000_IG11:                ;; offset=0x0282
       mov      rax, bword ptr [rbp-0x30]
       mov      rdi, gword ptr [rax+0x08]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Constants():System.Collections.Generic.IReadOnlyList`1[System.Object]:this]
       mov      gword ptr [rbp-0x3C0], rax
       mov      rax, gword ptr [rbp-0x3C0]
       mov      gword ptr [rbp-0x3C8], rax
       mov      rdi, gword ptr [rbp-0x3C8]
       mov      rsi, 0x7BE480A64160
       call     CORINFO_HELP_CLASSPROFILE32
       mov      rax, gword ptr [rbp-0x3C8]
       mov      gword ptr [rbp-0x408], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ConstantIndex():int:this]
       mov      dword ptr [rbp-0x40C], eax
       mov      rdi, gword ptr [rbp-0x408]
       mov      esi, dword ptr [rbp-0x40C]
       mov      r11, 0x7BE47E052368
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       mov      rdi, rax
       call     [Lokad.Lython.Runtime.LythonRuntime:RuntimeValue(System.Object):System.Object]
       mov      gword ptr [rbp-0x418], rax
       mov      rdx, gword ptr [rbp-0x418]
       mov      rsi, bword ptr [rbp-0x40]
       mov      rdi, bword ptr [rbp-0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,System.Object):this]
       jmp      G_M000_IG114
 
G_M000_IG12:                ;; offset=0x031F
       mov      rdi, 0x7BE480A64268
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LocalSlot():int:this]
       mov      dword ptr [rbp-0x3B4], eax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x420], rax
       mov      rdx, gword ptr [rbp-0x420]
       mov      esi, dword ptr [rbp-0x3B4]
       mov      rdi, bword ptr [rbp-0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:ReadLocal(int,Lokad.Lython.LythonSourceSpan):System.Object:this]
       mov      gword ptr [rbp-0x428], rax
       mov      rdx, gword ptr [rbp-0x428]
       mov      rsi, bword ptr [rbp-0x40]
       mov      rdi, bword ptr [rbp-0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,System.Object):this]
       jmp      G_M000_IG114
 
G_M000_IG13:                ;; offset=0x0387
       mov      rdi, 0x7BE480A6426C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp-0x30]
       mov      rdi, gword ptr [rax+0x08]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Names():System.Collections.Generic.IReadOnlyList`1[System.String]:this]
       mov      gword ptr [rbp-0x3A8], rax
       mov      rax, gword ptr [rbp-0x3A8]
       mov      gword ptr [rbp-0x3D0], rax
       mov      rdi, gword ptr [rbp-0x3D0]
       mov      rsi, 0x7BE480A64270
       call     CORINFO_HELP_CLASSPROFILE32
       mov      rax, gword ptr [rbp-0x3D0]
       mov      gword ptr [rbp-0x430], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_NameIndex():int:this]
       mov      dword ptr [rbp-0x434], eax
       mov      rdi, gword ptr [rbp-0x430]
       mov      esi, dword ptr [rbp-0x434]
       mov      r11, 0x7BE47E052360
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       mov      gword ptr [rbp-0x3B0], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x440], rax
       mov      rsi, gword ptr [rbp-0x440]
       mov      rax, bword ptr [rbp-0x30]
       mov      rdx, gword ptr [rax+0x18]
       mov      rdi, gword ptr [rbp-0x3B0]
       call     [Lokad.Lython.Runtime.LythonRuntime:ResolveExecutableGlobal(System.String,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):System.Object]
       mov      gword ptr [rbp-0x448], rax
       mov      rdx, gword ptr [rbp-0x448]
       mov      rsi, bword ptr [rbp-0x40]
       mov      rdi, bword ptr [rbp-0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,System.Object):this]
       jmp      G_M000_IG114
 
G_M000_IG14:                ;; offset=0x045E
       mov      rax, bword ptr [rbp-0x30]
       mov      r8, gword ptr [rax+0x18]
       mov      rax, bword ptr [rbp-0x30]
       mov      rdi, gword ptr [rax+0x08]
       mov      rax, bword ptr [rbp-0x30]
       mov      rsi, gword ptr [rax+0x10]
       mov      rax, bword ptr [rbp-0x30]
       mov      edx, dword ptr [rax+0x38]
       mov      rax, bword ptr [rbp-0x30]
       mov      ecx, dword ptr [rax+0x3C]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryExecuteClosureArithmetic(Lokad.Lython.Frontend.ExecutableCodeObject,System.Collections.Generic.IReadOnlyList`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableCell],int,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):bool]
       test     eax, eax
       je       SHORT G_M000_IG15
       mov      rdi, 0x7BE480A64378
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp-0x30]
       add      dword ptr [rax+0x38], 2
       jmp      G_M000_IG114
 
G_M000_IG15:                ;; offset=0x04AA
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ClosureSlot():int:this]
       mov      dword ptr [rbp-0x44C], eax
       mov      esi, dword ptr [rbp-0x44C]
       lea      rdx, [rbp-0x48]
       mov      rdi, bword ptr [rbp-0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:TryCell(int,byref):bool:this]
       test     eax, eax
       je       SHORT G_M000_IG17
       mov      rdi, gword ptr [rbp-0x48]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableCell:get_Value():System.Object:this]
       mov      gword ptr [rbp-0x50], rax
       cmp      gword ptr [rbp-0x50], 0
       jne      SHORT G_M000_IG18
 
G_M000_IG16:                ;; offset=0x04E9
       mov      rdi, 0x7BE480A6437C
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG17:                ;; offset=0x04F8
       mov      rdi, 0x7BE480A64380
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG108
 
G_M000_IG18:                ;; offset=0x050C
       mov      rdi, 0x7BE480A64384
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, bword ptr [rbp-0x30]
       mov      rsi, bword ptr [rbp-0x40]
       mov      rdx, gword ptr [rbp-0x50]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,System.Object):this]
       jmp      G_M000_IG114
 
G_M000_IG19:                ;; offset=0x0532
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ClosureSlot():int:this]
       mov      dword ptr [rbp-0x450], eax
       mov      esi, dword ptr [rbp-0x450]
       lea      rdx, [rbp-0x58]
       mov      rdi, bword ptr [rbp-0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:TryCell(int,byref):bool:this]
       test     eax, eax
       je       SHORT G_M000_IG21
       mov      rdi, gword ptr [rbp-0x58]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableCell:get_CanStoreThroughOwner():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG22
 
G_M000_IG20:                ;; offset=0x056A
       mov      rdi, 0x7BE480A64388
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG21:                ;; offset=0x0579
       mov      rdi, 0x7BE480A6438C
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG108
 
G_M000_IG22:                ;; offset=0x058D
       mov      rdi, 0x7BE480A64390
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, bword ptr [rbp-0x30]
       mov      rsi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Take(byref):System.Object:this]
       mov      gword ptr [rbp-0x60], rax
       mov      rdi, gword ptr [rbp-0x58]
       mov      rsi, gword ptr [rbp-0x60]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableCell:set_Value(System.Object):this]
       jmp      G_M000_IG114
 
G_M000_IG23:                ;; offset=0x05C3
       mov      rdi, 0x7BE480A64394
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp-0x30]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp-0x30]
       add      rax, 72
       mov      bword ptr [rbp-0x370], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LocalSlot():int:this]
       mov      dword ptr [rbp-0x374], eax
       mov      rax, bword ptr [rbp-0x370]
       mov      eax, dword ptr [rax+0x08]
       cmp      dword ptr [rbp-0x374], eax
       jae      G_M000_IG120
       mov      rax, bword ptr [rbp-0x370]
       mov      rax, bword ptr [rax]
       mov      ecx, dword ptr [rbp-0x374]
       lea      rax, bword ptr [rax+8*rcx]
       mov      bword ptr [rbp-0x380], rax
       mov      rdi, bword ptr [rbp-0x30]
       mov      rsi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Take(byref):System.Object:this]
       mov      rsi, rax
       mov      rdi, bword ptr [rbp-0x380]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       jmp      G_M000_IG114
 
G_M000_IG24:                ;; offset=0x064A
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x454], eax
       mov      esi, dword ptr [rbp-0x454]
       mov      rdi, bword ptr [rbp-0x30]
       xor      edx, edx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Read(int,int):System.Object:this]
       mov      gword ptr [rbp-0x70], rax
       mov      rax, bword ptr [rbp-0x30]
       mov      rdi, gword ptr [rax+0x08]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Names():System.Collections.Generic.IReadOnlyList`1[System.String]:this]
       mov      gword ptr [rbp-0x390], rax
       mov      rax, gword ptr [rbp-0x390]
       mov      gword ptr [rbp-0x3D8], rax
       mov      rdi, gword ptr [rbp-0x3D8]
       mov      rsi, 0x7BE480A64398
       call     CORINFO_HELP_CLASSPROFILE32
       mov      rax, gword ptr [rbp-0x3D8]
       mov      gword ptr [rbp-0x460], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_NameIndex():int:this]
       mov      dword ptr [rbp-0x464], eax
       mov      rdi, gword ptr [rbp-0x460]
       mov      esi, dword ptr [rbp-0x464]
       mov      r11, 0x7BE47E052358
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       mov      gword ptr [rbp-0x78], rax
       mov      rsi, gword ptr [rbp-0x70]
       mov      rdi, 0x7BE4806CE6B0
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       jne      SHORT G_M000_IG26
       mov      rsi, gword ptr [rbp-0x70]
       mov      rdi, 0x7BE4809E8968
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       jne      SHORT G_M000_IG25
       xor      rax, rax
       mov      gword ptr [rbp-0x398], rax
       jmp      SHORT G_M000_IG27
 
G_M000_IG25:                ;; offset=0x0724
       mov      rdi, 0x7BE480A644A0
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, gword ptr [rbp-0x78]
       call     [Lokad.Lython.Runtime.LythonRuntime+DictMembers:GetMethod(System.String):Lokad.Lython.Runtime.LythonRuntime+ReceiverMethod]
       mov      gword ptr [rbp-0x398], rax
       jmp      SHORT G_M000_IG27
 
G_M000_IG26:                ;; offset=0x0746
       mov      rdi, 0x7BE480A644A4
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, gword ptr [rbp-0x78]
       call     [Lokad.Lython.Runtime.LythonRuntime+StringMembers:GetMethod(System.String):Lokad.Lython.Runtime.LythonRuntime+ReceiverMethod]
       mov      gword ptr [rbp-0x398], rax
 
G_M000_IG27:                ;; offset=0x0766
       mov      rax, gword ptr [rbp-0x398]
       mov      gword ptr [rbp-0x80], rax
       cmp      gword ptr [rbp-0x80], 0
       jne      SHORT G_M000_IG28
       mov      rdi, 0x7BE480A644A8
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG108
 
G_M000_IG28:                ;; offset=0x078C
       mov      rdi, 0x7BE480A644AC
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       mov      dword ptr [rbp-0x39C], eax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       inc      eax
       mov      dword ptr [rbp-0x468], eax
       mov      edx, dword ptr [rbp-0x468]
       mov      esi, dword ptr [rbp-0x39C]
       mov      rdi, bword ptr [rbp-0x30]
       mov      rcx, gword ptr [rbp-0x70]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Put(int,int,System.Object):this]
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       inc      eax
       mov      dword ptr [rbp-0x3A0], eax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      dword ptr [rbp-0x46C], eax
       mov      edx, dword ptr [rbp-0x46C]
       mov      esi, dword ptr [rbp-0x3A0]
       mov      rdi, bword ptr [rbp-0x30]
       mov      rcx, gword ptr [rbp-0x80]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Put(int,int,System.Object):this]
       jmp      G_M000_IG114
 
G_M000_IG29:                ;; offset=0x0818
       mov      rdi, bword ptr [rbp-0x30]
       mov      rsi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Call(byref):bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG30
       mov      rdi, 0x7BE480A644B0
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG108
 
G_M000_IG30:                ;; offset=0x083E
       mov      rdi, 0x7BE480A644B4
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG114
 
G_M000_IG31:                ;; offset=0x0852
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x470], eax
       mov      esi, dword ptr [rbp-0x470]
       mov      rdi, bword ptr [rbp-0x30]
       xor      edx, edx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Read(int,int):System.Object:this]
       mov      gword ptr [rbp-0x278], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_SecondInput():int:this]
       mov      dword ptr [rbp-0x474], eax
       mov      esi, dword ptr [rbp-0x474]
       mov      rdi, bword ptr [rbp-0x30]
       mov      edx, 1
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Read(int,int):System.Object:this]
       mov      gword ptr [rbp-0x88], rax
       mov      rsi, gword ptr [rbp-0x278]
       mov      rdi, 0x7BE4809E8968
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      gword ptr [rbp-0x90], rax
       cmp      gword ptr [rbp-0x90], 0
       je       SHORT G_M000_IG33
       mov      rdi, gword ptr [rbp-0x90]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.PyDict:get_HasProtocolKeys():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG34
       mov      rsi, gword ptr [rbp-0x88]
       mov      rdi, 0x7BE4806CE6B0
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      gword ptr [rbp-0x98], rax
       cmp      gword ptr [rbp-0x98], 0
       jne      SHORT G_M000_IG35
 
G_M000_IG32:                ;; offset=0x090A
       mov      rdi, 0x7BE480A644B8
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG33:                ;; offset=0x0919
       mov      rdi, 0x7BE480A644BC
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG108
 
G_M000_IG34:                ;; offset=0x092D
       mov      rdi, 0x7BE480A644C0
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG33
 
G_M000_IG35:                ;; offset=0x093E
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LookupCacheIndex():int:this]
       test     eax, eax
       jl       G_M000_IG38
       mov      rdi, gword ptr [rbp-0x90]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.PyDict:get_HasSharedRecordKeys():bool:this]
       test     eax, eax
       je       G_M000_IG37
       mov      rax, bword ptr [rbp-0x30]
       mov      rax, gword ptr [rax]
       mov      gword ptr [rbp-0x280], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x480], rax
       mov      rsi, gword ptr [rbp-0x480]
       mov      rdi, gword ptr [rbp-0x280]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.PyExecutableFunction:GetLookupCaches(Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.LythonRuntime+ExecutableLookupCache[]:this]
       mov      gword ptr [rbp-0xA0], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LookupCacheIndex():int:this]
       mov      rcx, gword ptr [rbp-0xA0]
       cmp      eax, dword ptr [rcx+0x08]
       jae      G_M000_IG120
       mov      edx, eax
       imul     rdx, rdx, 24
       lea      rcx, bword ptr [rcx+rdx+0x10]
       mov      bword ptr [rbp-0x288], rcx
       mov      rax, bword ptr [rbp-0x30]
       mov      rax, gword ptr [rax+0x18]
       mov      gword ptr [rbp-0x290], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x488], rax
       mov      r8, gword ptr [rbp-0x488]
       lea      r9, [rbp-0xA8]
       mov      rsi, gword ptr [rbp-0x98]
       mov      rdx, bword ptr [rbp-0x288]
       mov      rcx, gword ptr [rbp-0x290]
       mov      rdi, gword ptr [rbp-0x90]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.PyDict:TryReadRecordValue(Lokad.Lython.Runtime.Text.PyString,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,byref):bool:this]
       test     eax, eax
       je       SHORT G_M000_IG36
       mov      rdi, 0x7BE480A644C4
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, bword ptr [rbp-0x30]
       mov      rsi, bword ptr [rbp-0x40]
       mov      rdx, gword ptr [rbp-0xA8]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,System.Object):this]
       jmp      G_M000_IG114
 
G_M000_IG36:                ;; offset=0x0A4E
       mov      rdi, 0x7BE480A644C8
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG38
 
G_M000_IG37:                ;; offset=0x0A5F
       mov      rdi, 0x7BE480A644CC
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG38:                ;; offset=0x0A6E
       mov      rdi, gword ptr [rbp-0x90]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.PyDict:get_HasProtocolKeys():bool:this]
       test     eax, eax
       je       SHORT G_M000_IG39
       mov      rdi, 0x7BE480A644D0
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG108
 
G_M000_IG39:                ;; offset=0x0A95
       mov      rdi, 0x7BE480A644D4
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x490], rax
       mov      rdx, gword ptr [rbp-0x490]
       mov      rax, bword ptr [rbp-0x30]
       mov      rcx, gword ptr [rax+0x18]
       mov      rsi, gword ptr [rbp-0x98]
       mov      rdi, gword ptr [rbp-0x90]
       call     [Lokad.Lython.Runtime.LythonRuntime:ReadSubscriptValue(System.Object,System.Object,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):System.Object]
       mov      gword ptr [rbp-0x498], rax
       mov      rdx, gword ptr [rbp-0x498]
       mov      rsi, bword ptr [rbp-0x40]
       mov      rdi, bword ptr [rbp-0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,System.Object):this]
       jmp      G_M000_IG114
 
G_M000_IG40:                ;; offset=0x0AF9
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x49C], eax
       mov      esi, dword ptr [rbp-0x49C]
       mov      rdi, bword ptr [rbp-0x30]
       xor      edx, edx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Read(int,int):System.Object:this]
       mov      gword ptr [rbp-0xB0], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_UnaryOperator():int:this]
       test     eax, eax
       je       G_M000_IG43
       mov      rsi, gword ptr [rbp-0xB0]
       mov      rdi, 0x7BE4806D9A60
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       jne      SHORT G_M000_IG42
       mov      rsi, gword ptr [rbp-0xB0]
       mov      rdi, 0x7BE47F2A6558
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       jne      SHORT G_M000_IG41
       mov      rdi, 0x7BE480A644D8
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rsi, gword ptr [rbp-0xB0]
       mov      rdi, 0x7BE47F2735C8
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       sete     al
       movzx    rax, al
       mov      dword ptr [rbp-0x1D4], eax
       jmp      SHORT G_M000_IG44
 
G_M000_IG41:                ;; offset=0x0BA3
       mov      rdi, 0x7BE480A644DC
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG42:                ;; offset=0x0BB2
       xor      eax, eax
       mov      dword ptr [rbp-0x1D4], eax
       jmp      SHORT G_M000_IG44
 
G_M000_IG43:                ;; offset=0x0BBC
       mov      rdi, 0x7BE480A644E0
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, gword ptr [rbp-0xB0]
       call     [Lokad.Lython.Runtime.LythonRuntime:CanUseNativeTruth(System.Object):bool]
       test     eax, eax
       sete     al
       movzx    rax, al
       mov      dword ptr [rbp-0x1D4], eax
 
G_M000_IG44:                ;; offset=0x0BE6
       cmp      dword ptr [rbp-0x1D4], 0
       je       SHORT G_M000_IG45
       mov      rdi, 0x7BE480A644E4
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG108
 
G_M000_IG45:                ;; offset=0x0C03
       mov      rdi, 0x7BE480A644E8
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_UnaryOperator():int:this]
       mov      dword ptr [rbp-0x1D8], eax
       mov      rax, bword ptr [rbp-0x30]
       mov      rax, gword ptr [rax+0x18]
       mov      gword ptr [rbp-0x1E0], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x4A8], rax
       mov      rcx, gword ptr [rbp-0x4A8]
       mov      rsi, gword ptr [rbp-0xB0]
       mov      rdx, gword ptr [rbp-0x1E0]
       mov      edi, dword ptr [rbp-0x1D8]
       call     [Lokad.Lython.Runtime.LythonRuntime:EvaluateExecutableUnary(int,System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):System.Object]
       mov      gword ptr [rbp-0x4B0], rax
       mov      rdx, gword ptr [rbp-0x4B0]
       mov      rsi, bword ptr [rbp-0x40]
       mov      rdi, bword ptr [rbp-0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,System.Object):this]
       jmp      G_M000_IG114
 
G_M000_IG46:                ;; offset=0x0C84
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x4B4], eax
       mov      esi, dword ptr [rbp-0x4B4]
       mov      rdi, bword ptr [rbp-0x30]
       xor      edx, edx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Read(int,int):System.Object:this]
       mov      gword ptr [rbp-0xB8], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_SecondInput():int:this]
       mov      dword ptr [rbp-0x4B8], eax
       mov      esi, dword ptr [rbp-0x4B8]
       mov      rdi, bword ptr [rbp-0x30]
       mov      edx, 1
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Read(int,int):System.Object:this]
       mov      gword ptr [rbp-0xC0], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_OpCode():int:this]
       cmp      eax, 48
       sete     al
       movzx    rax, al
       mov      dword ptr [rbp-0xC4], eax
       cmp      dword ptr [rbp-0xC4], 0
       jne      G_M000_IG49
       mov      rax, bword ptr [rbp-0x30]
       mov      rax, gword ptr [rax+0x08]
       mov      gword ptr [rbp-0x258], rax
       mov      rax, bword ptr [rbp-0x30]
       mov      rsi, bword ptr [rax+0x48]
       mov      rax, bword ptr [rbp-0x30]
       mov      rdx, qword ptr [rax+0x50]
       mov      rdi, 0x7BE4801EB4D0
       call     [System.Span`1[System.__Canon]:op_Implicit(System.Span`1[System.__Canon]):System.ReadOnlySpan`1[System.__Canon]]
       mov      bword ptr [rbp-0x250], rax
       mov      qword ptr [rbp-0x248], rdx
       mov      rax, bword ptr [rbp-0x30]
       mov      rax, gword ptr [rax+0x18]
       mov      gword ptr [rsp], rax
       lea      rax, [rbp-0xD0]
       mov      qword ptr [rsp+0x08], rax
       lea      rax, [rbp-0xD8]
       mov      qword ptr [rsp+0x10], rax
       mov      rsi, bword ptr [rbp-0x250]
       mov      rdx, qword ptr [rbp-0x248]
       mov      rax, bword ptr [rbp-0x30]
       mov      ecx, dword ptr [rax+0x38]
       mov      rdi, gword ptr [rbp-0x258]
       mov      r8, gword ptr [rbp-0xB8]
       mov      r9, gword ptr [rbp-0xC0]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryIntegerChain(Lokad.Lython.Frontend.ExecutableCodeObject,System.ReadOnlySpan`1[System.Object],int,System.Object,System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,byref):bool]
       test     eax, eax
       je       G_M000_IG48
       mov      rdi, 0x7BE480A644EC
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp-0x30]
       mov      ecx, dword ptr [rbp-0xD0]
       mov      dword ptr [rax+0x38], ecx
 
G_M000_IG47:                ;; offset=0x0DB4
       mov      rax, bword ptr [rbp-0x30]
       mov      rdi, gword ptr [rax+0x08]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Instructions():Lokad.Lython.Frontend.ExecutableInstruction[]:this]
       mov      ecx, dword ptr [rbp-0xD0]
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG120
       mov      edx, ecx
       imul     rdx, rdx, 32
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      bword ptr [rbp-0x270], rax
       mov      rdi, qword ptr [rbp-0xD8]
       call     [System.Numerics.BigInteger:op_Implicit(long):System.Numerics.BigInteger]
       mov      gword ptr [rbp-0x268], rax
       mov      qword ptr [rbp-0x260], rdx
       lea      rsi, [rbp-0x268]
       mov      rdi, 0x7BE4806D9A60
       call     [CORINFO_HELP_BOX]
       mov      gword ptr [rbp-0x4C0], rax
       mov      rdx, gword ptr [rbp-0x4C0]
       mov      rsi, bword ptr [rbp-0x270]
       mov      rdi, bword ptr [rbp-0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,System.Object):this]
       jmp      G_M000_IG114
 
G_M000_IG48:                ;; offset=0x0E3B
       mov      rdi, 0x7BE480A644F0
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG49:                ;; offset=0x0E4A
       cmp      dword ptr [rbp-0xC4], 0
       jne      G_M000_IG51
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_BinaryOperator():int:this]
       mov      dword ptr [rbp-0x234], eax
       mov      rax, bword ptr [rbp-0x30]
       mov      rax, gword ptr [rax+0x18]
       mov      gword ptr [rbp-0x240], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x4C8], rax
       mov      r8, gword ptr [rbp-0x4C8]
       lea      r9, [rbp-0xE0]
       mov      rsi, gword ptr [rbp-0xB8]
       mov      rdx, gword ptr [rbp-0xC0]
       mov      rcx, gword ptr [rbp-0x240]
       mov      edi, dword ptr [rbp-0x234]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryEvaluateScalarComparison(int,System.Object,System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,byref):bool]
       test     eax, eax
       je       SHORT G_M000_IG50
       mov      rdi, 0x7BE480A644F4
       call     CORINFO_HELP_COUNTPROFILE32
       movzx    rdi, byte  ptr [rbp-0xE0]
       call     [Lokad.Lython.Runtime.LythonRuntime:RuntimeValue(bool):System.Object]
       mov      gword ptr [rbp-0x4D0], rax
       mov      rdx, gword ptr [rbp-0x4D0]
       mov      rsi, bword ptr [rbp-0x40]
       mov      rdi, bword ptr [rbp-0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,System.Object):this]
       jmp      G_M000_IG114
 
G_M000_IG50:                ;; offset=0x0EF8
       mov      rdi, 0x7BE480A644F8
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG51:                ;; offset=0x0F07
       cmp      dword ptr [rbp-0xC4], 0
       jne      SHORT G_M000_IG52
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_BinaryOperator():int:this]
       mov      dword ptr [rbp-0x1E4], eax
       jmp      SHORT G_M000_IG53
 
G_M000_IG52:                ;; offset=0x0F22
       mov      rdi, 0x7BE480A644FC
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_AugmentedOperator():int:this]
       mov      edi, eax
       call     [Lokad.Lython.Runtime.LythonRuntime:AugmentedBinaryOperator(int):int]
       mov      dword ptr [rbp-0x1E4], eax
 
G_M000_IG53:                ;; offset=0x0F49
       mov      edi, dword ptr [rbp-0x1E4]
       mov      rsi, gword ptr [rbp-0xB8]
       mov      rdx, gword ptr [rbp-0xC0]
       call     [Lokad.Lython.Runtime.LythonRuntime:CanUseNativeBinary(int,System.Object,System.Object):bool]
       test     eax, eax
       jne      SHORT G_M000_IG54
       mov      rdi, 0x7BE480A64500
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG108
 
G_M000_IG54:                ;; offset=0x0F7B
       cmp      dword ptr [rbp-0xC4], 0
       je       G_M000_IG63
       mov      rsi, gword ptr [rbp-0xB8]
       mov      rdi, 0x7BE4806D9A60
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       jne      SHORT G_M000_IG56
       mov      rsi, gword ptr [rbp-0xB8]
       mov      rdi, 0x7BE47F2A6558
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       jne      G_M000_IG62
       mov      rsi, gword ptr [rbp-0xB8]
       mov      rdi, 0x7BE47F2735C8
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       je       G_M000_IG61
 
G_M000_IG55:                ;; offset=0x0FE4
       mov      rdi, 0x7BE480A64504
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG56:                ;; offset=0x0FF3
       mov      rsi, gword ptr [rbp-0xC0]
       mov      rdi, 0x7BE4806D9A60
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       jne      SHORT G_M000_IG60
       mov      rsi, gword ptr [rbp-0xC0]
       mov      rdi, 0x7BE47F2A6558
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       jne      SHORT G_M000_IG59
       mov      rsi, gword ptr [rbp-0xC0]
       mov      rdi, 0x7BE47F2735C8
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       jne      SHORT G_M000_IG58
 
G_M000_IG57:                ;; offset=0x1047
       mov      rdi, 0x7BE480A64508
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG108
 
G_M000_IG58:                ;; offset=0x105B
       mov      rdi, 0x7BE480A6450C
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG63
 
G_M000_IG59:                ;; offset=0x106C
       mov      rdi, 0x7BE480A64510
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG63
 
G_M000_IG60:                ;; offset=0x107D
       mov      rdi, 0x7BE480A64514
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG63
 
G_M000_IG61:                ;; offset=0x108E
       mov      rdi, 0x7BE480A64518
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG57
 
G_M000_IG62:                ;; offset=0x109F
       mov      rdi, 0x7BE480A6451C
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG56
 
G_M000_IG63:                ;; offset=0x10B3
       mov      rax, bword ptr [rbp-0x30]
       mov      bword ptr [rbp-0x1F0], rax
       mov      rax, bword ptr [rbp-0x40]
       mov      bword ptr [rbp-0x1F8], rax
       cmp      dword ptr [rbp-0xC4], 0
       jne      G_M000_IG64
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_BinaryOperator():int:this]
       mov      dword ptr [rbp-0x224], eax
       mov      rax, bword ptr [rbp-0x30]
       mov      rax, gword ptr [rax+0x18]
       mov      gword ptr [rbp-0x230], rax
       mov      rax, bword ptr [rbp-0x1F0]
       mov      bword ptr [rbp-0x210], rax
       mov      rax, bword ptr [rbp-0x1F8]
       mov      bword ptr [rbp-0x218], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x4D8], rax
       mov      r8, gword ptr [rbp-0x4D8]
       mov      rsi, gword ptr [rbp-0xB8]
       mov      rdx, gword ptr [rbp-0xC0]
       mov      rcx, gword ptr [rbp-0x230]
       mov      edi, dword ptr [rbp-0x224]
       call     [Lokad.Lython.Runtime.LythonRuntime:EvaluateBinaryOperator(int,System.Object,System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):System.Object]
       mov      gword ptr [rbp-0x220], rax
       jmp      G_M000_IG65
 
G_M000_IG64:                ;; offset=0x1156
       mov      rdi, 0x7BE480A64520
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_AugmentedOperator():int:this]
       mov      dword ptr [rbp-0x1FC], eax
       mov      rax, bword ptr [rbp-0x30]
       mov      rax, gword ptr [rax+0x18]
       mov      gword ptr [rbp-0x208], rax
       mov      rax, bword ptr [rbp-0x1F0]
       mov      bword ptr [rbp-0x210], rax
       mov      rax, bword ptr [rbp-0x1F8]
       mov      bword ptr [rbp-0x218], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x4E0], rax
       mov      r8, gword ptr [rbp-0x4E0]
       mov      rsi, gword ptr [rbp-0xC0]
       mov      edx, dword ptr [rbp-0x1FC]
       mov      rcx, gword ptr [rbp-0x208]
       mov      rdi, gword ptr [rbp-0xB8]
       call     [Lokad.Lython.Runtime.LythonRuntime:EvaluateAugmentedBuiltin(System.Object,System.Object,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):System.Object]
       mov      gword ptr [rbp-0x220], rax
 
G_M000_IG65:                ;; offset=0x11E0
       mov      rdi, 0x7BE480A64524
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, bword ptr [rbp-0x210]
       mov      rsi, bword ptr [rbp-0x218]
       mov      rdx, gword ptr [rbp-0x220]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,System.Object):this]
       jmp      G_M000_IG114
 
G_M000_IG66:                ;; offset=0x120F
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x4E4], eax
       mov      esi, dword ptr [rbp-0x4E4]
       mov      rdi, bword ptr [rbp-0x30]
       xor      edx, edx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Read(int,int):System.Object:this]
       mov      gword ptr [rbp-0xE8], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_SecondInput():int:this]
       mov      dword ptr [rbp-0x4E8], eax
       mov      esi, dword ptr [rbp-0x4E8]
       mov      rdi, bword ptr [rbp-0x30]
       mov      edx, 1
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Read(int,int):System.Object:this]
       mov      gword ptr [rbp-0xF0], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_BinaryOperator():int:this]
       mov      dword ptr [rbp-0x1B8], eax
       mov      rax, bword ptr [rbp-0x30]
       mov      rax, gword ptr [rax+0x18]
       mov      gword ptr [rbp-0x1C0], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x4F0], rax
       mov      r8, gword ptr [rbp-0x4F0]
       lea      r9, [rbp-0xF8]
       mov      rsi, gword ptr [rbp-0xE8]
       mov      rdx, gword ptr [rbp-0xF0]
       mov      rcx, gword ptr [rbp-0x1C0]
       mov      edi, dword ptr [rbp-0x1B8]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryEvaluateScalarComparison(int,System.Object,System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,byref):bool]
       test     eax, eax
       jne      SHORT G_M000_IG67
       mov      rdi, 0x7BE480A64528
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG108
 
G_M000_IG67:                ;; offset=0x12DB
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      dword ptr [rbp-0x4F4], eax
       mov      esi, dword ptr [rbp-0x4F4]
       mov      rdi, bword ptr [rbp-0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Trim(int):this]
       mov      rax, bword ptr [rbp-0x30]
       mov      rax, gword ptr [rax+0x18]
       mov      gword ptr [rbp-0x1C8], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x500], rax
       mov      rsi, gword ptr [rbp-0x500]
       mov      rdi, gword ptr [rbp-0x1C8]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CheckExecution(Lokad.Lython.LythonSourceSpan):this]
       movzx    rax, byte  ptr [rbp-0xF8]
       test     eax, eax
       jne      SHORT G_M000_IG68
       mov      rdi, 0x7BE480A6452C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_TargetIndex():int:this]
       mov      rcx, bword ptr [rbp-0x30]
       mov      dword ptr [rcx+0x38], eax
       jmp      G_M000_IG115
 
G_M000_IG68:                ;; offset=0x1361
       mov      rdi, 0x7BE480A64530
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG114
 
G_M000_IG69:                ;; offset=0x1375
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x504], eax
       mov      esi, dword ptr [rbp-0x504]
       mov      rdi, bword ptr [rbp-0x30]
       xor      edx, edx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Read(int,int):System.Object:this]
       mov      gword ptr [rbp-0x100], rax
       mov      rdi, gword ptr [rbp-0x100]
       call     [Lokad.Lython.Runtime.LythonRuntime:CanUseNativeTruth(System.Object):bool]
       test     eax, eax
       jne      SHORT G_M000_IG70
       mov      rdi, 0x7BE480A64534
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG108
 
G_M000_IG70:                ;; offset=0x13C3
       mov      rdi, bword ptr [rbp-0x30]
       mov      rsi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Take(byref):System.Object:this]
       mov      rax, bword ptr [rbp-0x30]
       mov      rax, gword ptr [rax+0x18]
       mov      gword ptr [rbp-0x1D0], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x510], rax
       mov      rdx, gword ptr [rbp-0x510]
       mov      rsi, gword ptr [rbp-0x1D0]
       mov      rdi, gword ptr [rbp-0x100]
       call     [Lokad.Lython.Runtime.LythonRuntime:IsTruthy(System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):bool]
       test     eax, eax
       jne      SHORT G_M000_IG71
       mov      rdi, 0x7BE480A64538
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_TargetIndex():int:this]
       mov      rcx, bword ptr [rbp-0x30]
       mov      dword ptr [rcx+0x38], eax
       jmp      G_M000_IG115
 
G_M000_IG71:                ;; offset=0x1435
       mov      rdi, 0x7BE480A6453C
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG114
 
G_M000_IG72:                ;; offset=0x1449
       mov      rdi, 0x7BE480A64540
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_TargetIndex():int:this]
       mov      rcx, bword ptr [rbp-0x30]
       mov      dword ptr [rcx+0x38], eax
       jmp      G_M000_IG115
 
G_M000_IG73:                ;; offset=0x146E
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_DiscardIterator():bool:this]
       test     eax, eax
       je       SHORT G_M000_IG74
       mov      rdi, 0x7BE480A64544
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp-0x30]
       mov      eax, dword ptr [rax+0x3C]
       lea      esi, [rax-0x01]
       mov      rdi, bword ptr [rbp-0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Trim(int):this]
 
G_M000_IG74:                ;; offset=0x149F
       mov      rdi, 0x7BE480A64548
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_TargetIndex():int:this]
       mov      rcx, bword ptr [rbp-0x30]
       mov      dword ptr [rcx+0x38], eax
       jmp      G_M000_IG115
 
G_M000_IG75:                ;; offset=0x14C4
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x514], eax
       mov      esi, dword ptr [rbp-0x514]
       mov      rdi, bword ptr [rbp-0x30]
       xor      edx, edx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Read(int,int):System.Object:this]
       mov      gword ptr [rbp-0x108], rax
       mov      rsi, gword ptr [rbp-0x108]
       mov      rdi, 0x7BE480A49120
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       je       SHORT G_M000_IG76
       mov      rdi, 0x7BE480A6454C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, bword ptr [rbp-0x30]
       mov      rsi, bword ptr [rbp-0x40]
       mov      rdx, gword ptr [rbp-0x108]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,System.Object):this]
       jmp      G_M000_IG114
 
G_M000_IG76:                ;; offset=0x1532
       mov      rsi, gword ptr [rbp-0x108]
       mov      rdi, 0x7BE4809ED748
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       jne      G_M000_IG78
       mov      rsi, gword ptr [rbp-0x108]
       mov      rdi, 0x7BE4806CF140
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       jne      G_M000_IG83
       mov      rsi, gword ptr [rbp-0x108]
       mov      rdi, 0x7BE480A2D378
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       jne      G_M000_IG82
       mov      rsi, gword ptr [rbp-0x108]
       mov      rdi, 0x7BE4806D3410
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       jne      G_M000_IG81
       mov      rsi, gword ptr [rbp-0x108]
       mov      rdi, 0x7BE4806CE6B0
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       jne      SHORT G_M000_IG80
       mov      rsi, gword ptr [rbp-0x108]
       mov      rdi, 0x7BE4809E8968
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       jne      SHORT G_M000_IG79
       mov      rsi, gword ptr [rbp-0x108]
       mov      rdi, 0x7BE480A2CEC0
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       je       SHORT G_M000_IG84
 
G_M000_IG77:                ;; offset=0x1606
       mov      rdi, 0x7BE480A64550
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG78:                ;; offset=0x1615
       mov      dword ptr [rbp-0x10C], 1
       jmp      SHORT G_M000_IG85
 
G_M000_IG79:                ;; offset=0x1621
       mov      rdi, 0x7BE480A64554
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG78
 
G_M000_IG80:                ;; offset=0x1632
       mov      rdi, 0x7BE480A64558
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG78
 
G_M000_IG81:                ;; offset=0x1643
       mov      rdi, 0x7BE480A6455C
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG78
 
G_M000_IG82:                ;; offset=0x1654
       mov      rdi, 0x7BE480A64560
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG78
 
G_M000_IG83:                ;; offset=0x1665
       mov      rdi, 0x7BE480A64564
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG78
 
G_M000_IG84:                ;; offset=0x1676
       mov      rdi, 0x7BE480A64568
       call     CORINFO_HELP_COUNTPROFILE32
       xor      eax, eax
       mov      dword ptr [rbp-0x10C], eax
 
G_M000_IG85:                ;; offset=0x168D
       cmp      dword ptr [rbp-0x10C], 0
       je       SHORT G_M000_IG86
       mov      rdi, 0x7BE480A6456C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x520], rax
       mov      rsi, gword ptr [rbp-0x520]
       mov      rax, bword ptr [rbp-0x30]
       mov      rdx, gword ptr [rax+0x18]
       mov      rdi, gword ptr [rbp-0x108]
       call     [Lokad.Lython.Runtime.PyIteration+Cursor:Create(System.Object,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):Lokad.Lython.Runtime.PyIteration+Cursor]
       mov      gword ptr [rbp-0x528], rax
       mov      rdx, gword ptr [rbp-0x528]
       mov      rsi, bword ptr [rbp-0x40]
       mov      rdi, bword ptr [rbp-0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,System.Object):this]
       jmp      G_M000_IG114
 
G_M000_IG86:                ;; offset=0x16F3
       mov      rdi, 0x7BE480A64570
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG108
 
G_M000_IG87:                ;; offset=0x1707
       mov      rax, bword ptr [rbp-0x30]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp-0x30]
       add      rax, 72
       mov      bword ptr [rbp-0x298], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x29C], eax
       mov      rax, bword ptr [rbp-0x298]
       mov      eax, dword ptr [rax+0x08]
       cmp      dword ptr [rbp-0x29C], eax
       jae      G_M000_IG120
       mov      rax, bword ptr [rbp-0x298]
       mov      rax, bword ptr [rax]
       mov      ecx, dword ptr [rbp-0x29C]
       mov      rax, gword ptr [rax+8*rcx]
       mov      gword ptr [rbp-0x118], rax
       mov      rsi, gword ptr [rbp-0x118]
       mov      rdi, 0x7BE480A49120
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      gword ptr [rbp-0x130], rax
       cmp      gword ptr [rbp-0x130], 0
       jne      G_M000_IG93
       mov      rsi, gword ptr [rbp-0x118]
       mov      rdi, 0x7BE4809EAA08
       call     [CORINFO_HELP_CHKCASTCLASS]
       mov      gword ptr [rbp-0x530], rax
       mov      rdi, gword ptr [rbp-0x530]
       lea      rsi, [rbp-0x138]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.PyIteration+Cursor:TryMoveNext(byref):bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG90
       call     [Lokad.Lython.Runtime.PyIterationResult:get_End():Lokad.Lython.Runtime.PyIterationResult]
       mov      gword ptr [rbp-0x2E0], rax
       mov      qword ptr [rbp-0x2D8], rdx
 
G_M000_IG88:                ;; offset=0x17D5
       vmovdqu32 xmm0, xmmword ptr [rbp-0x2E0]
       vmovdqu32 xmmword ptr [rbp-0x2C0], xmm0
 
G_M000_IG89:                ;; offset=0x17E3
       jmp      SHORT G_M000_IG95
 
G_M000_IG90:                ;; offset=0x17E5
       mov      rdi, 0x7BE480A64574
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, gword ptr [rbp-0x138]
       call     [Lokad.Lython.Runtime.PyIterationResult:Yield(System.Object):Lokad.Lython.Runtime.PyIterationResult]
       mov      gword ptr [rbp-0x2D0], rax
       mov      qword ptr [rbp-0x2C8], rdx
 
G_M000_IG91:                ;; offset=0x180F
       vmovdqu32 xmm0, xmmword ptr [rbp-0x2D0]
       vmovdqu32 xmmword ptr [rbp-0x2C0], xmm0
 
G_M000_IG92:                ;; offset=0x181D
       jmp      SHORT G_M000_IG95
 
G_M000_IG93:                ;; offset=0x181F
       mov      rdi, 0x7BE480A64578
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, gword ptr [rbp-0x130]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.Text.PyStringOps+CasedWhitespaceIteration:MoveNext():Lokad.Lython.Runtime.PyIterationResult:this]
       mov      gword ptr [rbp-0x2B0], rax
       mov      qword ptr [rbp-0x2A8], rdx
 
G_M000_IG94:                ;; offset=0x184B
       vmovdqu32 xmm0, xmmword ptr [rbp-0x2B0]
       vmovdqu32 xmmword ptr [rbp-0x2C0], xmm0
 
G_M000_IG95:                ;; offset=0x1859
       vmovdqu32 xmm0, xmmword ptr [rbp-0x2C0]
       vmovdqu  xmmword ptr [rbp-0x128], xmm0
 
G_M000_IG96:                ;; offset=0x1868
       lea      rdi, [rbp-0x128]
       call     [Lokad.Lython.Runtime.PyIterationResult:get_HasValue():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG97
       mov      rdi, 0x7BE480A6457C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x534], eax
       mov      esi, dword ptr [rbp-0x534]
       mov      rdi, bword ptr [rbp-0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Trim(int):this]
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_TargetIndex():int:this]
       mov      rcx, bword ptr [rbp-0x30]
       mov      dword ptr [rcx+0x38], eax
       jmp      G_M000_IG115
 
G_M000_IG97:                ;; offset=0x18BE
       mov      rdi, 0x7BE480A64580
       call     CORINFO_HELP_COUNTPROFILE32
       lea      rdi, [rbp-0x128]
       call     [Lokad.Lython.Runtime.PyIterationResult:get_Value():System.Object:this]
       mov      gword ptr [rbp-0x540], rax
       mov      rdx, gword ptr [rbp-0x540]
       mov      rsi, bword ptr [rbp-0x40]
       mov      rdi, bword ptr [rbp-0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,System.Object):this]
       jmp      G_M000_IG114
 
G_M000_IG98:                ;; offset=0x18FB
       mov      rdi, bword ptr [rbp-0x30]
       mov      rsi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:TryReturnUnpackedTuple(byref):bool:this]
       test     eax, eax
       je       SHORT G_M000_IG99
       mov      rdi, 0x7BE480A64584
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG118
 
G_M000_IG99:                ;; offset=0x1921
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ItemCount():int:this]
       test     eax, eax
       je       G_M000_IG100
       mov      rax, bword ptr [rbp-0x30]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp-0x30]
       add      rax, 72
       mov      bword ptr [rbp-0x2F0], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x2F4], eax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ItemCount():int:this]
       mov      dword ptr [rbp-0x544], eax
       mov      ecx, dword ptr [rbp-0x544]
       mov      rdi, bword ptr [rbp-0x2F0]
       mov      edx, dword ptr [rbp-0x2F4]
       mov      rsi, 0x7BE4801EB4D0
       call     [System.Span`1[System.__Canon]:Slice(int,int):System.Span`1[System.__Canon]:this]
       mov      bword ptr [rbp-0x308], rax
       mov      qword ptr [rbp-0x300], rdx
       mov      rsi, bword ptr [rbp-0x308]
       mov      rdx, qword ptr [rbp-0x300]
       mov      rdi, 0x7BE4801EB4D0
       call     [System.Span`1[System.__Canon]:op_Implicit(System.Span`1[System.__Canon]):System.ReadOnlySpan`1[System.__Canon]]
       mov      bword ptr [rbp-0x318], rax
       mov      qword ptr [rbp-0x310], rdx
       mov      rax, bword ptr [rbp-0x30]
       mov      rdi, gword ptr [rax+0x18]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:get_MemoryGovernor():Lokad.Lython.Runtime.MemoryGovernor:this]
       mov      gword ptr [rbp-0x320], rax
       mov      rdi, 0x7BE4806CF140
       call     CORINFO_HELP_NEWSFAST
       mov      gword ptr [rbp-0x328], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x550], rax
       mov      r8, gword ptr [rbp-0x550]
       mov      rax, bword ptr [rbp-0x30]
       mov      r9, gword ptr [rax+0x18]
       mov      rsi, bword ptr [rbp-0x318]
       mov      rdx, qword ptr [rbp-0x310]
       mov      rcx, gword ptr [rbp-0x320]
       mov      rdi, gword ptr [rbp-0x328]
       call     [Lokad.Lython.Runtime.PyTuple:.ctor(System.ReadOnlySpan`1[System.Object],Lokad.Lython.Runtime.MemoryGovernor,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):this]
       mov      rax, gword ptr [rbp-0x328]
       mov      gword ptr [rbp-0x2E8], rax
       jmp      SHORT G_M000_IG101
 
G_M000_IG100:                ;; offset=0x1A44
       mov      rdi, 0x7BE480A64588
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, 0x7BDCA1801680
       mov      rax, gword ptr [rax]
       mov      gword ptr [rbp-0x2E8], rax
 
G_M000_IG101:                ;; offset=0x1A67
       mov      rdi, 0x7BE480A6458C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, gword ptr [rbp-0x2E8]
       mov      gword ptr [rbp-0x140], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x554], eax
       mov      esi, dword ptr [rbp-0x554]
       mov      rdi, bword ptr [rbp-0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Trim(int):this]
       mov      rdi, bword ptr [rbp-0x30]
       mov      rsi, bword ptr [rbp-0x40]
       mov      rdx, gword ptr [rbp-0x140]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,System.Object):this]
       jmp      G_M000_IG114
 
G_M000_IG102:                ;; offset=0x1ABE
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ItemCount():int:this]
       mov      edi, eax
       call     [Lokad.Lython.Runtime.PyList:EstimateCapacityBytes(int):long]
       mov      qword ptr [rbp-0x148], rax
       mov      rax, bword ptr [rbp-0x30]
       mov      rdi, gword ptr [rax+0x18]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:get_MemoryGovernor():Lokad.Lython.Runtime.MemoryGovernor:this]
       mov      gword ptr [rbp-0x330], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x560], rax
       mov      rdx, gword ptr [rbp-0x560]
       mov      rsi, qword ptr [rbp-0x148]
       mov      rdi, gword ptr [rbp-0x330]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.MemoryGovernor:ReserveTemporary(long,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.MemoryGovernor+TemporaryMemoryReservation:this]
       mov      gword ptr [rbp-0x150], rax
 
G_M000_IG103:                ;; offset=0x1B23
       mov      rdi, 0x7BE480A64590
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp-0x30]
       mov      rax, gword ptr [rax+0x18]
       mov      gword ptr [rbp-0x338], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x568], rax
       mov      rsi, gword ptr [rbp-0x568]
       mov      rdi, gword ptr [rbp-0x338]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CheckExecution(Lokad.Lython.LythonSourceSpan):this]
       mov      rax, bword ptr [rbp-0x30]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp-0x30]
       add      rax, 72
       mov      bword ptr [rbp-0x340], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x344], eax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ItemCount():int:this]
       mov      dword ptr [rbp-0x56C], eax
       mov      ecx, dword ptr [rbp-0x56C]
       mov      rdi, bword ptr [rbp-0x340]
       mov      edx, dword ptr [rbp-0x344]
       mov      rsi, 0x7BE4801EB4D0
       call     [System.Span`1[System.__Canon]:Slice(int,int):System.Span`1[System.__Canon]:this]
       mov      bword ptr [rbp-0x358], rax
       mov      qword ptr [rbp-0x350], rdx
 
G_M000_IG104:                ;; offset=0x1BCE
       vmovdqu  xmm0, xmmword ptr [rbp-0x358]
       vmovdqu  xmmword ptr [rbp-0x168], xmm0
 
G_M000_IG105:                ;; offset=0x1BDE
       lea      rdi, [rbp-0x168]
       mov      rsi, 0x7BE4801EB4D0
       call     [System.Span`1[System.__Canon]:ToArray():System.__Canon[]:this]
       mov      gword ptr [rbp-0x158], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x570], eax
       mov      esi, dword ptr [rbp-0x570]
       mov      rdi, bword ptr [rbp-0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Trim(int):this]
       mov      rdi, gword ptr [rbp-0x150]
       mov      rsi, qword ptr [rbp-0x148]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.MemoryGovernor+TemporaryMemoryReservation:Commit(long):this]
       mov      rax, bword ptr [rbp-0x30]
       mov      rdi, gword ptr [rax+0x18]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:get_MemoryGovernor():Lokad.Lython.Runtime.MemoryGovernor:this]
       mov      gword ptr [rbp-0x360], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x578], rax
       mov      rdx, gword ptr [rbp-0x578]
       mov      rsi, gword ptr [rbp-0x360]
       mov      rdi, gword ptr [rbp-0x158]
       call     [Lokad.Lython.Runtime.PyList:FromTransferredArray(System.Object[],Lokad.Lython.Runtime.MemoryGovernor,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.PyList]
       mov      gword ptr [rbp-0x580], rax
       mov      rdx, gword ptr [rbp-0x580]
       mov      rsi, bword ptr [rbp-0x40]
       mov      rdi, bword ptr [rbp-0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,System.Object):this]
       nop      
 
G_M000_IG106:                ;; offset=0x1C92
       call     G_M000_IG121
       jmp      G_M000_IG114
 
G_M000_IG107:                ;; offset=0x1C9C
       mov      rdi, bword ptr [rbp-0x30]
       mov      rsi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Format(byref):bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG110
       mov      rdi, 0x7BE480A646A4
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG108:                ;; offset=0x1CBD
       xor      eax, eax
 
G_M000_IG109:                ;; offset=0x1CBF
       add      rsp, 0x5D0
       pop      rbp
       ret      
 
G_M000_IG110:                ;; offset=0x1CC8
       mov      rdi, 0x7BE480A646A8
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG114
 
G_M000_IG111:                ;; offset=0x1CDC
       mov      rdi, 0x7BE480A646AC
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       inc      eax
       mov      dword ptr [rbp-0x364], eax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      dword ptr [rbp-0x368], eax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x58C], eax
       mov      esi, dword ptr [rbp-0x58C]
       mov      rdi, bword ptr [rbp-0x30]
       xor      edx, edx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Read(int,int):System.Object:this]
       mov      gword ptr [rbp-0x598], rax
       mov      rcx, gword ptr [rbp-0x598]
       mov      esi, dword ptr [rbp-0x364]
       mov      edx, dword ptr [rbp-0x368]
       mov      rdi, bword ptr [rbp-0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Put(int,int,System.Object):this]
       jmp      G_M000_IG114
 
G_M000_IG112:                ;; offset=0x1D58
       mov      rdi, 0x7BE480A646B0
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x59C], eax
       mov      esi, dword ptr [rbp-0x59C]
       mov      rdi, bword ptr [rbp-0x30]
       xor      edx, edx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Read(int,int):System.Object:this]
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      dword ptr [rbp-0x5A0], eax
       mov      esi, dword ptr [rbp-0x5A0]
       mov      rdi, bword ptr [rbp-0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Trim(int):this]
       jmp      G_M000_IG114
 
G_M000_IG113:                ;; offset=0x1DAE
       lea      rdi, [rbp-0x190]
       mov      esi, 26
       mov      edx, 1
       call     [System.Runtime.CompilerServices.DefaultInterpolatedStringHandler:.ctor(int,int):this]
       lea      rdi, [rbp-0x190]
       mov      rsi, 0x7BE47C254E80
       call     [System.Runtime.CompilerServices.DefaultInterpolatedStringHandler:AppendLiteral(System.String):this]
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_OpCode():int:this]
       mov      dword ptr [rbp-0x5A4], eax
       mov      esi, dword ptr [rbp-0x5A4]
       lea      rdi, [rbp-0x190]
       call     [System.Runtime.CompilerServices.DefaultInterpolatedStringHandler:AppendFormatted[int](int):this]
       mov      rdi, 0x7BE47F987A68
       call     CORINFO_HELP_NEWSFAST
       mov      gword ptr [rbp-0x388], rax
       lea      rdi, [rbp-0x190]
       call     [System.Runtime.CompilerServices.DefaultInterpolatedStringHandler:ToStringAndClear():System.String:this]
       mov      gword ptr [rbp-0x5B0], rax
       mov      rsi, gword ptr [rbp-0x5B0]
       mov      rdi, gword ptr [rbp-0x388]
       call     [System.InvalidOperationException:.ctor(System.String):this]
       mov      rdi, gword ptr [rbp-0x388]
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG114:                ;; offset=0x1E4A
       mov      rdi, 0x7BE480A646B4
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp-0x30]
       inc      dword ptr [rax+0x38]
 
G_M000_IG115:                ;; offset=0x1E60
       mov      eax, dword ptr [rbp-0x3E4]
       dec      eax
       mov      dword ptr [rbp-0x3E4], eax
       cmp      dword ptr [rbp-0x3E4], 0
       jg       SHORT G_M000_IG117
 
G_M000_IG116:                ;; offset=0x1E77
       lea      rdi, [rbp-0x3E4]
       mov      esi, 0x96A
       call     CORINFO_HELP_PATCHPOINT
       jmp      rax
 
G_M000_IG117:                ;; offset=0x1E8A
       mov      rax, bword ptr [rbp-0x30]
       mov      eax, dword ptr [rax+0x38]
       mov      dword ptr [rbp-0x194], eax
       mov      rax, bword ptr [rbp-0x30]
       mov      rdi, gword ptr [rax+0x08]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Instructions():Lokad.Lython.Frontend.ExecutableInstruction[]:this]
       mov      eax, dword ptr [rax+0x08]
       cmp      eax, dword ptr [rbp-0x194]
       jg       G_M000_IG03
       mov      rdi, 0x7BE480A646B8
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG118:                ;; offset=0x1EC5
       mov      eax, 1
 
G_M000_IG119:                ;; offset=0x1ECA
       add      rsp, 0x5D0
       pop      rbp
       ret      
 
G_M000_IG120:                ;; offset=0x1ED3
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG121:                ;; offset=0x1ED9
       sub      rsp, 24
 
G_M000_IG122:                ;; offset=0x1EDD
       cmp      gword ptr [rbp-0x150], 0
       je       SHORT G_M000_IG123
       mov      rdi, 0x7BE480A64594
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, gword ptr [rbp-0x150]
       mov      gword ptr [rbp-0x3E0], rax
       mov      rdi, gword ptr [rbp-0x3E0]
       mov      rsi, 0x7BE480A64598
       call     CORINFO_HELP_CLASSPROFILE32
       mov      rax, gword ptr [rbp-0x3E0]
       mov      gword ptr [rbp-0x588], rax
       mov      rdi, gword ptr [rbp-0x588]
       mov      r11, 0x7BE47E052350
       call     [r11]System.IDisposable:Dispose():this
 
G_M000_IG123:                ;; offset=0x1F3C
       mov      rdi, 0x7BE480A646A0
       call     CORINFO_HELP_COUNTPROFILE32
       nop      
 
G_M000_IG124:                ;; offset=0x1F4C
       add      rsp, 24
       ret      
 
RWD00  	dd	0000023Fh ; case G_M000_IG11
       	dd	000002DCh ; case G_M000_IG12
       	dd	0000041Bh ; case G_M000_IG14
       	dd	00000344h ; case G_M000_IG13
RWD16  	dd	00000607h ; case G_M000_IG24
       	dd	00001D6Bh ; case G_M000_IG113
       	dd	00000580h ; case G_M000_IG23
       	dd	000004EFh ; case G_M000_IG19
       	dd	00001D6Bh ; case G_M000_IG113
       	dd	00001D6Bh ; case G_M000_IG113
       	dd	00001C99h ; case G_M000_IG111
       	dd	00001D15h ; case G_M000_IG112
       	dd	00001A7Bh ; case G_M000_IG102
       	dd	000018B8h ; case G_M000_IG98
       	dd	00001D6Bh ; case G_M000_IG113
       	dd	00001D6Bh ; case G_M000_IG113
       	dd	00001D6Bh ; case G_M000_IG113
       	dd	00001D6Bh ; case G_M000_IG113
       	dd	00001D6Bh ; case G_M000_IG113
       	dd	00001D6Bh ; case G_M000_IG113
       	dd	00001481h ; case G_M000_IG75
       	dd	000016C4h ; case G_M000_IG87
       	dd	000007D5h ; case G_M000_IG29
       	dd	0000080Fh ; case G_M000_IG31
       	dd	00001D6Bh ; case G_M000_IG113
       	dd	00001D6Bh ; case G_M000_IG113
       	dd	00000C41h ; case G_M000_IG46
       	dd	00000C41h ; case G_M000_IG46
       	dd	00000AB6h ; case G_M000_IG40
       	dd	00001406h ; case G_M000_IG72
       	dd	00001332h ; case G_M000_IG69
       	dd	000011CCh ; case G_M000_IG66
       	dd	00001D6Bh ; case G_M000_IG113
       	dd	00001D6Bh ; case G_M000_IG113
       	dd	00001D6Bh ; case G_M000_IG113
       	dd	00001D6Bh ; case G_M000_IG113
       	dd	00001D6Bh ; case G_M000_IG113
       	dd	0000014Fh ; case G_M000_IG09
       	dd	00000115h ; case G_M000_IG08
       	dd	00000115h ; case G_M000_IG08
       	dd	00001D6Bh ; case G_M000_IG113
       	dd	00001D6Bh ; case G_M000_IG113
       	dd	0000142Bh ; case G_M000_IG73
       	dd	00001C59h ; case G_M000_IG107
       	dd	00001C59h ; case G_M000_IG107
       	dd	00001C59h ; case G_M000_IG107
       	dd	00001C59h ; case G_M000_IG107
       	dd	00001C59h ; case G_M000_IG107

; Total bytes of code 8017

; Assembly listing for method Lokad.Lython.Runtime.LythonRuntime+NativeExecution:RunCore(byref):bool:this (Instrumented Tier0)
; Emitting BLENDED_CODE for x64 + VEX + EVEX on Unix
; Instrumented Tier0 code
; rbp based frame
; fully interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 0x5D0
       lea      rbp, [rsp+0x5D0]
       vxorps   xmm8, xmm8, xmm8
       mov      rax, -0x570
 
G_M000_IG125:                ;; offset=0x001F
       vmovdqa  xmmword ptr [rbp+rax-0x40], xmm8
       vmovdqa  xmmword ptr [rbp+rax-0x30], xmm8
       vmovdqa  xmmword ptr [rbp+rax-0x20], xmm8
       add      rax, 48
       jne      SHORT G_M000_IG125
       mov      qword ptr [rbp-0x40], rax
       mov      bword ptr [rbp-0x30], rdi
       mov      bword ptr [rbp-0x38], rsi
 
G_M000_IG02:                ;; offset=0x0043
       mov      dword ptr [rbp-0x3E4], 0x3E8
       mov      rax, 0x7BDCA1801728
       mov      rsi, gword ptr [rax]
       mov      rdi, bword ptr [rbp-0x38]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       jmp      G_M000_IG115
 
G_M000_IG03:                ;; offset=0x0068
       mov      rax, bword ptr [rbp-0x30]
       mov      rdi, gword ptr [rax+0x08]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Instructions():Lokad.Lython.Frontend.ExecutableInstruction[]:this]
       mov      rcx, bword ptr [rbp-0x30]
       mov      ecx, dword ptr [rcx+0x38]
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG120
       mov      edx, ecx
       imul     rdx, rdx, 32
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      bword ptr [rbp-0x40], rax
       mov      rax, bword ptr [rbp-0x30]
       mov      rdi, gword ptr [rax+0x18]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:get_State():Lokad.Lython.Runtime.ExecutionState:this]
       mov      gword ptr [rbp-0x1A0], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x3F0], rax
       mov      rsi, gword ptr [rbp-0x3F0]
       mov      rdi, gword ptr [rbp-0x1A0]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.ExecutionState:CheckExecution(Lokad.Lython.LythonSourceSpan):this]
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_OpCode():int:this]
       mov      dword ptr [rbp-0x64], eax
       mov      eax, dword ptr [rbp-0x64]
       add      eax, -3
       mov      dword ptr [rbp-0x5B4], eax
       cmp      dword ptr [rbp-0x5B4], 3
       ja       SHORT G_M000_IG05
 
G_M000_IG04:                ;; offset=0x00F7
       mov      eax, dword ptr [rbp-0x5B4]
       lea      rcx, [reloc @RWD00]
       mov      ecx, dword ptr [rcx+4*rax]
       lea      rdx, G_M000_IG02
       add      rcx, rdx
       jmp      rcx
 
G_M000_IG05:                ;; offset=0x0113
       mov      eax, dword ptr [rbp-0x64]
       add      eax, -25
       mov      dword ptr [rbp-0x5B8], eax
       cmp      dword ptr [rbp-0x5B8], 43
       ja       SHORT G_M000_IG07
 
G_M000_IG06:                ;; offset=0x0128
       mov      eax, dword ptr [rbp-0x5B8]
       lea      rcx, [reloc @RWD16]
       mov      ecx, dword ptr [rcx+4*rax]
       lea      rdx, G_M000_IG02
       add      rcx, rdx
       jmp      rcx
 
G_M000_IG07:                ;; offset=0x0144
       mov      rdi, 0x7BE480A64150
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG113
 
G_M000_IG08:                ;; offset=0x0158
       mov      rdi, 0x7BE480A64154
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp-0x30]
       mov      rdi, gword ptr [rax+0x08]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_FirstTemporarySlot():int:this]
       mov      dword ptr [rbp-0x3F4], eax
       mov      esi, dword ptr [rbp-0x3F4]
       mov      rdi, bword ptr [rbp-0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Trim(int):this]
       jmp      G_M000_IG118
 
G_M000_IG09:                ;; offset=0x0192
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x3F8], eax
       mov      esi, dword ptr [rbp-0x3F8]
       mov      rdi, bword ptr [rbp-0x30]
       xor      edx, edx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Read(int,int):System.Object:this]
       mov      rsi, rax
       mov      rdi, bword ptr [rbp-0x38]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x1A4], eax
       mov      rax, bword ptr [rbp-0x30]
       mov      rdi, gword ptr [rax+0x08]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_FirstTemporarySlot():int:this]
       cmp      eax, dword ptr [rbp-0x1A4]
       jg       SHORT G_M000_IG10
       mov      rdi, 0x7BE480A64158
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp-0x30]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp-0x30]
       add      rax, 72
       mov      bword ptr [rbp-0x1B0], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x1B4], eax
       mov      rax, bword ptr [rbp-0x1B0]
       mov      eax, dword ptr [rax+0x08]
       cmp      dword ptr [rbp-0x1B4], eax
       jae      G_M000_IG120
       mov      rax, bword ptr [rbp-0x1B0]
       mov      rax, bword ptr [rax]
       mov      ecx, dword ptr [rbp-0x1B4]
       xor      rdx, rdx
       mov      gword ptr [rax+8*rcx], rdx
 
G_M000_IG10:                ;; offset=0x0248
       mov      rdi, 0x7BE480A6415C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp-0x30]
       mov      rdi, gword ptr [rax+0x08]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_FirstTemporarySlot():int:this]
       mov      dword ptr [rbp-0x3FC], eax
       mov      esi, dword ptr [rbp-0x3FC]
       mov      rdi, bword ptr [rbp-0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Trim(int):this]
       jmp      G_M000_IG118
 
G_M000_IG11:                ;; offset=0x0282
       mov      rax, bword ptr [rbp-0x30]
       mov      rdi, gword ptr [rax+0x08]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Constants():System.Collections.Generic.IReadOnlyList`1[System.Object]:this]
       mov      gword ptr [rbp-0x3C0], rax
       mov      rax, gword ptr [rbp-0x3C0]
       mov      gword ptr [rbp-0x3C8], rax
       mov      rdi, gword ptr [rbp-0x3C8]
       mov      rsi, 0x7BE480A64160
       call     CORINFO_HELP_CLASSPROFILE32
       mov      rax, gword ptr [rbp-0x3C8]
       mov      gword ptr [rbp-0x408], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ConstantIndex():int:this]
       mov      dword ptr [rbp-0x40C], eax
       mov      rdi, gword ptr [rbp-0x408]
       mov      esi, dword ptr [rbp-0x40C]
       mov      r11, 0x7BE47E052748
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       mov      rdi, rax
       call     [Lokad.Lython.Runtime.LythonRuntime:RuntimeValue(System.Object):System.Object]
       mov      gword ptr [rbp-0x418], rax
       mov      rdx, gword ptr [rbp-0x418]
       mov      rsi, bword ptr [rbp-0x40]
       mov      rdi, bword ptr [rbp-0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,System.Object):this]
       jmp      G_M000_IG114
 
G_M000_IG12:                ;; offset=0x031F
       mov      rdi, 0x7BE480A64268
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LocalSlot():int:this]
       mov      dword ptr [rbp-0x3B4], eax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x420], rax
       mov      rdx, gword ptr [rbp-0x420]
       mov      esi, dword ptr [rbp-0x3B4]
       mov      rdi, bword ptr [rbp-0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:ReadLocal(int,Lokad.Lython.LythonSourceSpan):System.Object:this]
       mov      gword ptr [rbp-0x428], rax
       mov      rdx, gword ptr [rbp-0x428]
       mov      rsi, bword ptr [rbp-0x40]
       mov      rdi, bword ptr [rbp-0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,System.Object):this]
       jmp      G_M000_IG114
 
G_M000_IG13:                ;; offset=0x0387
       mov      rdi, 0x7BE480A6426C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp-0x30]
       mov      rdi, gword ptr [rax+0x08]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Names():System.Collections.Generic.IReadOnlyList`1[System.String]:this]
       mov      gword ptr [rbp-0x3A8], rax
       mov      rax, gword ptr [rbp-0x3A8]
       mov      gword ptr [rbp-0x3D0], rax
       mov      rdi, gword ptr [rbp-0x3D0]
       mov      rsi, 0x7BE480A64270
       call     CORINFO_HELP_CLASSPROFILE32
       mov      rax, gword ptr [rbp-0x3D0]
       mov      gword ptr [rbp-0x430], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_NameIndex():int:this]
       mov      dword ptr [rbp-0x434], eax
       mov      rdi, gword ptr [rbp-0x430]
       mov      esi, dword ptr [rbp-0x434]
       mov      r11, 0x7BE47E052740
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       mov      gword ptr [rbp-0x3B0], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x440], rax
       mov      rsi, gword ptr [rbp-0x440]
       mov      rax, bword ptr [rbp-0x30]
       mov      rdx, gword ptr [rax+0x18]
       mov      rdi, gword ptr [rbp-0x3B0]
       call     [Lokad.Lython.Runtime.LythonRuntime:ResolveExecutableGlobal(System.String,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):System.Object]
       mov      gword ptr [rbp-0x448], rax
       mov      rdx, gword ptr [rbp-0x448]
       mov      rsi, bword ptr [rbp-0x40]
       mov      rdi, bword ptr [rbp-0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,System.Object):this]
       jmp      G_M000_IG114
 
G_M000_IG14:                ;; offset=0x045E
       mov      rax, bword ptr [rbp-0x30]
       mov      r8, gword ptr [rax+0x18]
       mov      rax, bword ptr [rbp-0x30]
       mov      rdi, gword ptr [rax+0x08]
       mov      rax, bword ptr [rbp-0x30]
       mov      rsi, gword ptr [rax+0x10]
       mov      rax, bword ptr [rbp-0x30]
       mov      edx, dword ptr [rax+0x38]
       mov      rax, bword ptr [rbp-0x30]
       mov      ecx, dword ptr [rax+0x3C]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryExecuteClosureArithmetic(Lokad.Lython.Frontend.ExecutableCodeObject,System.Collections.Generic.IReadOnlyList`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableCell],int,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):bool]
       test     eax, eax
       je       SHORT G_M000_IG15
       mov      rdi, 0x7BE480A64378
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp-0x30]
       add      dword ptr [rax+0x38], 2
       jmp      G_M000_IG114
 
G_M000_IG15:                ;; offset=0x04AA
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ClosureSlot():int:this]
       mov      dword ptr [rbp-0x44C], eax
       mov      esi, dword ptr [rbp-0x44C]
       lea      rdx, [rbp-0x48]
       mov      rdi, bword ptr [rbp-0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:TryCell(int,byref):bool:this]
       test     eax, eax
       je       SHORT G_M000_IG17
       mov      rdi, gword ptr [rbp-0x48]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableCell:get_Value():System.Object:this]
       mov      gword ptr [rbp-0x50], rax
       cmp      gword ptr [rbp-0x50], 0
       jne      SHORT G_M000_IG18
 
G_M000_IG16:                ;; offset=0x04E9
       mov      rdi, 0x7BE480A6437C
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG17:                ;; offset=0x04F8
       mov      rdi, 0x7BE480A64380
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG108
 
G_M000_IG18:                ;; offset=0x050C
       mov      rdi, 0x7BE480A64384
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, bword ptr [rbp-0x30]
       mov      rsi, bword ptr [rbp-0x40]
       mov      rdx, gword ptr [rbp-0x50]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,System.Object):this]
       jmp      G_M000_IG114
 
G_M000_IG19:                ;; offset=0x0532
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ClosureSlot():int:this]
       mov      dword ptr [rbp-0x450], eax
       mov      esi, dword ptr [rbp-0x450]
       lea      rdx, [rbp-0x58]
       mov      rdi, bword ptr [rbp-0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:TryCell(int,byref):bool:this]
       test     eax, eax
       je       SHORT G_M000_IG21
       mov      rdi, gword ptr [rbp-0x58]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableCell:get_CanStoreThroughOwner():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG22
 
G_M000_IG20:                ;; offset=0x056A
       mov      rdi, 0x7BE480A64388
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG21:                ;; offset=0x0579
       mov      rdi, 0x7BE480A6438C
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG108
 
G_M000_IG22:                ;; offset=0x058D
       mov      rdi, 0x7BE480A64390
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, bword ptr [rbp-0x30]
       mov      rsi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Take(byref):System.Object:this]
       mov      gword ptr [rbp-0x60], rax
       mov      rdi, gword ptr [rbp-0x58]
       mov      rsi, gword ptr [rbp-0x60]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableCell:set_Value(System.Object):this]
       jmp      G_M000_IG114
 
G_M000_IG23:                ;; offset=0x05C3
       mov      rdi, 0x7BE480A64394
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp-0x30]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp-0x30]
       add      rax, 72
       mov      bword ptr [rbp-0x370], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LocalSlot():int:this]
       mov      dword ptr [rbp-0x374], eax
       mov      rax, bword ptr [rbp-0x370]
       mov      eax, dword ptr [rax+0x08]
       cmp      dword ptr [rbp-0x374], eax
       jae      G_M000_IG120
       mov      rax, bword ptr [rbp-0x370]
       mov      rax, bword ptr [rax]
       mov      ecx, dword ptr [rbp-0x374]
       lea      rax, bword ptr [rax+8*rcx]
       mov      bword ptr [rbp-0x380], rax
       mov      rdi, bword ptr [rbp-0x30]
       mov      rsi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Take(byref):System.Object:this]
       mov      rsi, rax
       mov      rdi, bword ptr [rbp-0x380]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       jmp      G_M000_IG114
 
G_M000_IG24:                ;; offset=0x064A
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x454], eax
       mov      esi, dword ptr [rbp-0x454]
       mov      rdi, bword ptr [rbp-0x30]
       xor      edx, edx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Read(int,int):System.Object:this]
       mov      gword ptr [rbp-0x70], rax
       mov      rax, bword ptr [rbp-0x30]
       mov      rdi, gword ptr [rax+0x08]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Names():System.Collections.Generic.IReadOnlyList`1[System.String]:this]
       mov      gword ptr [rbp-0x390], rax
       mov      rax, gword ptr [rbp-0x390]
       mov      gword ptr [rbp-0x3D8], rax
       mov      rdi, gword ptr [rbp-0x3D8]
       mov      rsi, 0x7BE480A64398
       call     CORINFO_HELP_CLASSPROFILE32
       mov      rax, gword ptr [rbp-0x3D8]
       mov      gword ptr [rbp-0x460], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_NameIndex():int:this]
       mov      dword ptr [rbp-0x464], eax
       mov      rdi, gword ptr [rbp-0x460]
       mov      esi, dword ptr [rbp-0x464]
       mov      r11, 0x7BE47E052738
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       mov      gword ptr [rbp-0x78], rax
       mov      rsi, gword ptr [rbp-0x70]
       mov      rdi, 0x7BE4806CE6B0
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       jne      SHORT G_M000_IG26
       mov      rsi, gword ptr [rbp-0x70]
       mov      rdi, 0x7BE4809E8968
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       jne      SHORT G_M000_IG25
       xor      rax, rax
       mov      gword ptr [rbp-0x398], rax
       jmp      SHORT G_M000_IG27
 
G_M000_IG25:                ;; offset=0x0724
       mov      rdi, 0x7BE480A644A0
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, gword ptr [rbp-0x78]
       call     [Lokad.Lython.Runtime.LythonRuntime+DictMembers:GetMethod(System.String):Lokad.Lython.Runtime.LythonRuntime+ReceiverMethod]
       mov      gword ptr [rbp-0x398], rax
       jmp      SHORT G_M000_IG27
 
G_M000_IG26:                ;; offset=0x0746
       mov      rdi, 0x7BE480A644A4
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, gword ptr [rbp-0x78]
       call     [Lokad.Lython.Runtime.LythonRuntime+StringMembers:GetMethod(System.String):Lokad.Lython.Runtime.LythonRuntime+ReceiverMethod]
       mov      gword ptr [rbp-0x398], rax
 
G_M000_IG27:                ;; offset=0x0766
       mov      rax, gword ptr [rbp-0x398]
       mov      gword ptr [rbp-0x80], rax
       cmp      gword ptr [rbp-0x80], 0
       jne      SHORT G_M000_IG28
       mov      rdi, 0x7BE480A644A8
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG108
 
G_M000_IG28:                ;; offset=0x078C
       mov      rdi, 0x7BE480A644AC
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       mov      dword ptr [rbp-0x39C], eax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       inc      eax
       mov      dword ptr [rbp-0x468], eax
       mov      edx, dword ptr [rbp-0x468]
       mov      esi, dword ptr [rbp-0x39C]
       mov      rdi, bword ptr [rbp-0x30]
       mov      rcx, gword ptr [rbp-0x70]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Put(int,int,System.Object):this]
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       inc      eax
       mov      dword ptr [rbp-0x3A0], eax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      dword ptr [rbp-0x46C], eax
       mov      edx, dword ptr [rbp-0x46C]
       mov      esi, dword ptr [rbp-0x3A0]
       mov      rdi, bword ptr [rbp-0x30]
       mov      rcx, gword ptr [rbp-0x80]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Put(int,int,System.Object):this]
       jmp      G_M000_IG114
 
G_M000_IG29:                ;; offset=0x0818
       mov      rdi, bword ptr [rbp-0x30]
       mov      rsi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Call(byref):bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG30
       mov      rdi, 0x7BE480A644B0
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG108
 
G_M000_IG30:                ;; offset=0x083E
       mov      rdi, 0x7BE480A644B4
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG114
 
G_M000_IG31:                ;; offset=0x0852
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x470], eax
       mov      esi, dword ptr [rbp-0x470]
       mov      rdi, bword ptr [rbp-0x30]
       xor      edx, edx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Read(int,int):System.Object:this]
       mov      gword ptr [rbp-0x278], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_SecondInput():int:this]
       mov      dword ptr [rbp-0x474], eax
       mov      esi, dword ptr [rbp-0x474]
       mov      rdi, bword ptr [rbp-0x30]
       mov      edx, 1
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Read(int,int):System.Object:this]
       mov      gword ptr [rbp-0x88], rax
       mov      rsi, gword ptr [rbp-0x278]
       mov      rdi, 0x7BE4809E8968
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      gword ptr [rbp-0x90], rax
       cmp      gword ptr [rbp-0x90], 0
       je       SHORT G_M000_IG33
       mov      rdi, gword ptr [rbp-0x90]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.PyDict:get_HasProtocolKeys():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG34
       mov      rsi, gword ptr [rbp-0x88]
       mov      rdi, 0x7BE4806CE6B0
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      gword ptr [rbp-0x98], rax
       cmp      gword ptr [rbp-0x98], 0
       jne      SHORT G_M000_IG35
 
G_M000_IG32:                ;; offset=0x090A
       mov      rdi, 0x7BE480A644B8
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG33:                ;; offset=0x0919
       mov      rdi, 0x7BE480A644BC
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG108
 
G_M000_IG34:                ;; offset=0x092D
       mov      rdi, 0x7BE480A644C0
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG33
 
G_M000_IG35:                ;; offset=0x093E
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LookupCacheIndex():int:this]
       test     eax, eax
       jl       G_M000_IG38
       mov      rdi, gword ptr [rbp-0x90]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.PyDict:get_HasSharedRecordKeys():bool:this]
       test     eax, eax
       je       G_M000_IG37
       mov      rax, bword ptr [rbp-0x30]
       mov      rax, gword ptr [rax]
       mov      gword ptr [rbp-0x280], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x480], rax
       mov      rsi, gword ptr [rbp-0x480]
       mov      rdi, gword ptr [rbp-0x280]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.PyExecutableFunction:GetLookupCaches(Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.LythonRuntime+ExecutableLookupCache[]:this]
       mov      gword ptr [rbp-0xA0], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LookupCacheIndex():int:this]
       mov      rcx, gword ptr [rbp-0xA0]
       cmp      eax, dword ptr [rcx+0x08]
       jae      G_M000_IG120
       mov      edx, eax
       imul     rdx, rdx, 24
       lea      rcx, bword ptr [rcx+rdx+0x10]
       mov      bword ptr [rbp-0x288], rcx
       mov      rax, bword ptr [rbp-0x30]
       mov      rax, gword ptr [rax+0x18]
       mov      gword ptr [rbp-0x290], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x488], rax
       mov      r8, gword ptr [rbp-0x488]
       lea      r9, [rbp-0xA8]
       mov      rsi, gword ptr [rbp-0x98]
       mov      rdx, bword ptr [rbp-0x288]
       mov      rcx, gword ptr [rbp-0x290]
       mov      rdi, gword ptr [rbp-0x90]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.PyDict:TryReadRecordValue(Lokad.Lython.Runtime.Text.PyString,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,byref):bool:this]
       test     eax, eax
       je       SHORT G_M000_IG36
       mov      rdi, 0x7BE480A644C4
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, bword ptr [rbp-0x30]
       mov      rsi, bword ptr [rbp-0x40]
       mov      rdx, gword ptr [rbp-0xA8]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,System.Object):this]
       jmp      G_M000_IG114
 
G_M000_IG36:                ;; offset=0x0A4E
       mov      rdi, 0x7BE480A644C8
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG38
 
G_M000_IG37:                ;; offset=0x0A5F
       mov      rdi, 0x7BE480A644CC
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG38:                ;; offset=0x0A6E
       mov      rdi, gword ptr [rbp-0x90]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.PyDict:get_HasProtocolKeys():bool:this]
       test     eax, eax
       je       SHORT G_M000_IG39
       mov      rdi, 0x7BE480A644D0
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG108
 
G_M000_IG39:                ;; offset=0x0A95
       mov      rdi, 0x7BE480A644D4
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x490], rax
       mov      rdx, gword ptr [rbp-0x490]
       mov      rax, bword ptr [rbp-0x30]
       mov      rcx, gword ptr [rax+0x18]
       mov      rsi, gword ptr [rbp-0x98]
       mov      rdi, gword ptr [rbp-0x90]
       call     [Lokad.Lython.Runtime.LythonRuntime:ReadSubscriptValue(System.Object,System.Object,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):System.Object]
       mov      gword ptr [rbp-0x498], rax
       mov      rdx, gword ptr [rbp-0x498]
       mov      rsi, bword ptr [rbp-0x40]
       mov      rdi, bword ptr [rbp-0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,System.Object):this]
       jmp      G_M000_IG114
 
G_M000_IG40:                ;; offset=0x0AF9
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x49C], eax
       mov      esi, dword ptr [rbp-0x49C]
       mov      rdi, bword ptr [rbp-0x30]
       xor      edx, edx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Read(int,int):System.Object:this]
       mov      gword ptr [rbp-0xB0], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_UnaryOperator():int:this]
       test     eax, eax
       je       G_M000_IG43
       mov      rsi, gword ptr [rbp-0xB0]
       mov      rdi, 0x7BE4806D9A60
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       jne      SHORT G_M000_IG42
       mov      rsi, gword ptr [rbp-0xB0]
       mov      rdi, 0x7BE47F2A6558
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       jne      SHORT G_M000_IG41
       mov      rdi, 0x7BE480A644D8
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rsi, gword ptr [rbp-0xB0]
       mov      rdi, 0x7BE47F2735C8
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       sete     al
       movzx    rax, al
       mov      dword ptr [rbp-0x1D4], eax
       jmp      SHORT G_M000_IG44
 
G_M000_IG41:                ;; offset=0x0BA3
       mov      rdi, 0x7BE480A644DC
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG42:                ;; offset=0x0BB2
       xor      eax, eax
       mov      dword ptr [rbp-0x1D4], eax
       jmp      SHORT G_M000_IG44
 
G_M000_IG43:                ;; offset=0x0BBC
       mov      rdi, 0x7BE480A644E0
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, gword ptr [rbp-0xB0]
       call     [Lokad.Lython.Runtime.LythonRuntime:CanUseNativeTruth(System.Object):bool]
       test     eax, eax
       sete     al
       movzx    rax, al
       mov      dword ptr [rbp-0x1D4], eax
 
G_M000_IG44:                ;; offset=0x0BE6
       cmp      dword ptr [rbp-0x1D4], 0
       je       SHORT G_M000_IG45
       mov      rdi, 0x7BE480A644E4
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG108
 
G_M000_IG45:                ;; offset=0x0C03
       mov      rdi, 0x7BE480A644E8
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_UnaryOperator():int:this]
       mov      dword ptr [rbp-0x1D8], eax
       mov      rax, bword ptr [rbp-0x30]
       mov      rax, gword ptr [rax+0x18]
       mov      gword ptr [rbp-0x1E0], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x4A8], rax
       mov      rcx, gword ptr [rbp-0x4A8]
       mov      rsi, gword ptr [rbp-0xB0]
       mov      rdx, gword ptr [rbp-0x1E0]
       mov      edi, dword ptr [rbp-0x1D8]
       call     [Lokad.Lython.Runtime.LythonRuntime:EvaluateExecutableUnary(int,System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):System.Object]
       mov      gword ptr [rbp-0x4B0], rax
       mov      rdx, gword ptr [rbp-0x4B0]
       mov      rsi, bword ptr [rbp-0x40]
       mov      rdi, bword ptr [rbp-0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,System.Object):this]
       jmp      G_M000_IG114
 
G_M000_IG46:                ;; offset=0x0C84
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x4B4], eax
       mov      esi, dword ptr [rbp-0x4B4]
       mov      rdi, bword ptr [rbp-0x30]
       xor      edx, edx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Read(int,int):System.Object:this]
       mov      gword ptr [rbp-0xB8], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_SecondInput():int:this]
       mov      dword ptr [rbp-0x4B8], eax
       mov      esi, dword ptr [rbp-0x4B8]
       mov      rdi, bword ptr [rbp-0x30]
       mov      edx, 1
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Read(int,int):System.Object:this]
       mov      gword ptr [rbp-0xC0], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_OpCode():int:this]
       cmp      eax, 48
       sete     al
       movzx    rax, al
       mov      dword ptr [rbp-0xC4], eax
       cmp      dword ptr [rbp-0xC4], 0
       jne      G_M000_IG49
       mov      rax, bword ptr [rbp-0x30]
       mov      rax, gword ptr [rax+0x08]
       mov      gword ptr [rbp-0x258], rax
       mov      rax, bword ptr [rbp-0x30]
       mov      rsi, bword ptr [rax+0x48]
       mov      rax, bword ptr [rbp-0x30]
       mov      rdx, qword ptr [rax+0x50]
       mov      rdi, 0x7BE4801EB4D0
       call     [System.Span`1[System.__Canon]:op_Implicit(System.Span`1[System.__Canon]):System.ReadOnlySpan`1[System.__Canon]]
       mov      bword ptr [rbp-0x250], rax
       mov      qword ptr [rbp-0x248], rdx
       mov      rax, bword ptr [rbp-0x30]
       mov      rax, gword ptr [rax+0x18]
       mov      gword ptr [rsp], rax
       lea      rax, [rbp-0xD0]
       mov      qword ptr [rsp+0x08], rax
       lea      rax, [rbp-0xD8]
       mov      qword ptr [rsp+0x10], rax
       mov      rsi, bword ptr [rbp-0x250]
       mov      rdx, qword ptr [rbp-0x248]
       mov      rax, bword ptr [rbp-0x30]
       mov      ecx, dword ptr [rax+0x38]
       mov      rdi, gword ptr [rbp-0x258]
       mov      r8, gword ptr [rbp-0xB8]
       mov      r9, gword ptr [rbp-0xC0]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryIntegerChain(Lokad.Lython.Frontend.ExecutableCodeObject,System.ReadOnlySpan`1[System.Object],int,System.Object,System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,byref):bool]
       test     eax, eax
       je       G_M000_IG48
       mov      rdi, 0x7BE480A644EC
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp-0x30]
       mov      ecx, dword ptr [rbp-0xD0]
       mov      dword ptr [rax+0x38], ecx
 
G_M000_IG47:                ;; offset=0x0DB4
       mov      rax, bword ptr [rbp-0x30]
       mov      rdi, gword ptr [rax+0x08]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Instructions():Lokad.Lython.Frontend.ExecutableInstruction[]:this]
       mov      ecx, dword ptr [rbp-0xD0]
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG120
       mov      edx, ecx
       imul     rdx, rdx, 32
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      bword ptr [rbp-0x270], rax
       mov      rdi, qword ptr [rbp-0xD8]
       call     [System.Numerics.BigInteger:op_Implicit(long):System.Numerics.BigInteger]
       mov      gword ptr [rbp-0x268], rax
       mov      qword ptr [rbp-0x260], rdx
       lea      rsi, [rbp-0x268]
       mov      rdi, 0x7BE4806D9A60
       call     [CORINFO_HELP_BOX]
       mov      gword ptr [rbp-0x4C0], rax
       mov      rdx, gword ptr [rbp-0x4C0]
       mov      rsi, bword ptr [rbp-0x270]
       mov      rdi, bword ptr [rbp-0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,System.Object):this]
       jmp      G_M000_IG114
 
G_M000_IG48:                ;; offset=0x0E3B
       mov      rdi, 0x7BE480A644F0
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG49:                ;; offset=0x0E4A
       cmp      dword ptr [rbp-0xC4], 0
       jne      G_M000_IG51
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_BinaryOperator():int:this]
       mov      dword ptr [rbp-0x234], eax
       mov      rax, bword ptr [rbp-0x30]
       mov      rax, gword ptr [rax+0x18]
       mov      gword ptr [rbp-0x240], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x4C8], rax
       mov      r8, gword ptr [rbp-0x4C8]
       lea      r9, [rbp-0xE0]
       mov      rsi, gword ptr [rbp-0xB8]
       mov      rdx, gword ptr [rbp-0xC0]
       mov      rcx, gword ptr [rbp-0x240]
       mov      edi, dword ptr [rbp-0x234]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryEvaluateScalarComparison(int,System.Object,System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,byref):bool]
       test     eax, eax
       je       SHORT G_M000_IG50
       mov      rdi, 0x7BE480A644F4
       call     CORINFO_HELP_COUNTPROFILE32
       movzx    rdi, byte  ptr [rbp-0xE0]
       call     [Lokad.Lython.Runtime.LythonRuntime:RuntimeValue(bool):System.Object]
       mov      gword ptr [rbp-0x4D0], rax
       mov      rdx, gword ptr [rbp-0x4D0]
       mov      rsi, bword ptr [rbp-0x40]
       mov      rdi, bword ptr [rbp-0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,System.Object):this]
       jmp      G_M000_IG114
 
G_M000_IG50:                ;; offset=0x0EF8
       mov      rdi, 0x7BE480A644F8
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG51:                ;; offset=0x0F07
       cmp      dword ptr [rbp-0xC4], 0
       jne      SHORT G_M000_IG52
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_BinaryOperator():int:this]
       mov      dword ptr [rbp-0x1E4], eax
       jmp      SHORT G_M000_IG53
 
G_M000_IG52:                ;; offset=0x0F22
       mov      rdi, 0x7BE480A644FC
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_AugmentedOperator():int:this]
       mov      edi, eax
       call     [Lokad.Lython.Runtime.LythonRuntime:AugmentedBinaryOperator(int):int]
       mov      dword ptr [rbp-0x1E4], eax
 
G_M000_IG53:                ;; offset=0x0F49
       mov      edi, dword ptr [rbp-0x1E4]
       mov      rsi, gword ptr [rbp-0xB8]
       mov      rdx, gword ptr [rbp-0xC0]
       call     [Lokad.Lython.Runtime.LythonRuntime:CanUseNativeBinary(int,System.Object,System.Object):bool]
       test     eax, eax
       jne      SHORT G_M000_IG54
       mov      rdi, 0x7BE480A64500
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG108
 
G_M000_IG54:                ;; offset=0x0F7B
       cmp      dword ptr [rbp-0xC4], 0
       je       G_M000_IG63
       mov      rsi, gword ptr [rbp-0xB8]
       mov      rdi, 0x7BE4806D9A60
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       jne      SHORT G_M000_IG56
       mov      rsi, gword ptr [rbp-0xB8]
       mov      rdi, 0x7BE47F2A6558
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       jne      G_M000_IG62
       mov      rsi, gword ptr [rbp-0xB8]
       mov      rdi, 0x7BE47F2735C8
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       je       G_M000_IG61
 
G_M000_IG55:                ;; offset=0x0FE4
       mov      rdi, 0x7BE480A64504
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG56:                ;; offset=0x0FF3
       mov      rsi, gword ptr [rbp-0xC0]
       mov      rdi, 0x7BE4806D9A60
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       jne      SHORT G_M000_IG60
       mov      rsi, gword ptr [rbp-0xC0]
       mov      rdi, 0x7BE47F2A6558
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       jne      SHORT G_M000_IG59
       mov      rsi, gword ptr [rbp-0xC0]
       mov      rdi, 0x7BE47F2735C8
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       jne      SHORT G_M000_IG58
 
G_M000_IG57:                ;; offset=0x1047
       mov      rdi, 0x7BE480A64508
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG108
 
G_M000_IG58:                ;; offset=0x105B
       mov      rdi, 0x7BE480A6450C
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG63
 
G_M000_IG59:                ;; offset=0x106C
       mov      rdi, 0x7BE480A64510
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG63
 
G_M000_IG60:                ;; offset=0x107D
       mov      rdi, 0x7BE480A64514
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG63
 
G_M000_IG61:                ;; offset=0x108E
       mov      rdi, 0x7BE480A64518
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG57
 
G_M000_IG62:                ;; offset=0x109F
       mov      rdi, 0x7BE480A6451C
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG56
 
G_M000_IG63:                ;; offset=0x10B3
       mov      rax, bword ptr [rbp-0x30]
       mov      bword ptr [rbp-0x1F0], rax
       mov      rax, bword ptr [rbp-0x40]
       mov      bword ptr [rbp-0x1F8], rax
       cmp      dword ptr [rbp-0xC4], 0
       jne      G_M000_IG64
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_BinaryOperator():int:this]
       mov      dword ptr [rbp-0x224], eax
       mov      rax, bword ptr [rbp-0x30]
       mov      rax, gword ptr [rax+0x18]
       mov      gword ptr [rbp-0x230], rax
       mov      rax, bword ptr [rbp-0x1F0]
       mov      bword ptr [rbp-0x210], rax
       mov      rax, bword ptr [rbp-0x1F8]
       mov      bword ptr [rbp-0x218], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x4D8], rax
       mov      r8, gword ptr [rbp-0x4D8]
       mov      rsi, gword ptr [rbp-0xB8]
       mov      rdx, gword ptr [rbp-0xC0]
       mov      rcx, gword ptr [rbp-0x230]
       mov      edi, dword ptr [rbp-0x224]
       call     [Lokad.Lython.Runtime.LythonRuntime:EvaluateBinaryOperator(int,System.Object,System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):System.Object]
       mov      gword ptr [rbp-0x220], rax
       jmp      G_M000_IG65
 
G_M000_IG64:                ;; offset=0x1156
       mov      rdi, 0x7BE480A64520
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_AugmentedOperator():int:this]
       mov      dword ptr [rbp-0x1FC], eax
       mov      rax, bword ptr [rbp-0x30]
       mov      rax, gword ptr [rax+0x18]
       mov      gword ptr [rbp-0x208], rax
       mov      rax, bword ptr [rbp-0x1F0]
       mov      bword ptr [rbp-0x210], rax
       mov      rax, bword ptr [rbp-0x1F8]
       mov      bword ptr [rbp-0x218], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x4E0], rax
       mov      r8, gword ptr [rbp-0x4E0]
       mov      rsi, gword ptr [rbp-0xC0]
       mov      edx, dword ptr [rbp-0x1FC]
       mov      rcx, gword ptr [rbp-0x208]
       mov      rdi, gword ptr [rbp-0xB8]
       call     [Lokad.Lython.Runtime.LythonRuntime:EvaluateAugmentedBuiltin(System.Object,System.Object,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):System.Object]
       mov      gword ptr [rbp-0x220], rax
 
G_M000_IG65:                ;; offset=0x11E0
       mov      rdi, 0x7BE480A64524
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, bword ptr [rbp-0x210]
       mov      rsi, bword ptr [rbp-0x218]
       mov      rdx, gword ptr [rbp-0x220]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,System.Object):this]
       jmp      G_M000_IG114
 
G_M000_IG66:                ;; offset=0x120F
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x4E4], eax
       mov      esi, dword ptr [rbp-0x4E4]
       mov      rdi, bword ptr [rbp-0x30]
       xor      edx, edx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Read(int,int):System.Object:this]
       mov      gword ptr [rbp-0xE8], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_SecondInput():int:this]
       mov      dword ptr [rbp-0x4E8], eax
       mov      esi, dword ptr [rbp-0x4E8]
       mov      rdi, bword ptr [rbp-0x30]
       mov      edx, 1
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Read(int,int):System.Object:this]
       mov      gword ptr [rbp-0xF0], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_BinaryOperator():int:this]
       mov      dword ptr [rbp-0x1B8], eax
       mov      rax, bword ptr [rbp-0x30]
       mov      rax, gword ptr [rax+0x18]
       mov      gword ptr [rbp-0x1C0], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x4F0], rax
       mov      r8, gword ptr [rbp-0x4F0]
       lea      r9, [rbp-0xF8]
       mov      rsi, gword ptr [rbp-0xE8]
       mov      rdx, gword ptr [rbp-0xF0]
       mov      rcx, gword ptr [rbp-0x1C0]
       mov      edi, dword ptr [rbp-0x1B8]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryEvaluateScalarComparison(int,System.Object,System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,byref):bool]
       test     eax, eax
       jne      SHORT G_M000_IG67
       mov      rdi, 0x7BE480A64528
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG108
 
G_M000_IG67:                ;; offset=0x12DB
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      dword ptr [rbp-0x4F4], eax
       mov      esi, dword ptr [rbp-0x4F4]
       mov      rdi, bword ptr [rbp-0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Trim(int):this]
       mov      rax, bword ptr [rbp-0x30]
       mov      rax, gword ptr [rax+0x18]
       mov      gword ptr [rbp-0x1C8], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x500], rax
       mov      rsi, gword ptr [rbp-0x500]
       mov      rdi, gword ptr [rbp-0x1C8]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CheckExecution(Lokad.Lython.LythonSourceSpan):this]
       movzx    rax, byte  ptr [rbp-0xF8]
       test     eax, eax
       jne      SHORT G_M000_IG68
       mov      rdi, 0x7BE480A6452C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_TargetIndex():int:this]
       mov      rcx, bword ptr [rbp-0x30]
       mov      dword ptr [rcx+0x38], eax
       jmp      G_M000_IG115
 
G_M000_IG68:                ;; offset=0x1361
       mov      rdi, 0x7BE480A64530
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG114
 
G_M000_IG69:                ;; offset=0x1375
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x504], eax
       mov      esi, dword ptr [rbp-0x504]
       mov      rdi, bword ptr [rbp-0x30]
       xor      edx, edx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Read(int,int):System.Object:this]
       mov      gword ptr [rbp-0x100], rax
       mov      rdi, gword ptr [rbp-0x100]
       call     [Lokad.Lython.Runtime.LythonRuntime:CanUseNativeTruth(System.Object):bool]
       test     eax, eax
       jne      SHORT G_M000_IG70
       mov      rdi, 0x7BE480A64534
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG108
 
G_M000_IG70:                ;; offset=0x13C3
       mov      rdi, bword ptr [rbp-0x30]
       mov      rsi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Take(byref):System.Object:this]
       mov      rax, bword ptr [rbp-0x30]
       mov      rax, gword ptr [rax+0x18]
       mov      gword ptr [rbp-0x1D0], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x510], rax
       mov      rdx, gword ptr [rbp-0x510]
       mov      rsi, gword ptr [rbp-0x1D0]
       mov      rdi, gword ptr [rbp-0x100]
       call     [Lokad.Lython.Runtime.LythonRuntime:IsTruthy(System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):bool]
       test     eax, eax
       jne      SHORT G_M000_IG71
       mov      rdi, 0x7BE480A64538
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_TargetIndex():int:this]
       mov      rcx, bword ptr [rbp-0x30]
       mov      dword ptr [rcx+0x38], eax
       jmp      G_M000_IG115
 
G_M000_IG71:                ;; offset=0x1435
       mov      rdi, 0x7BE480A6453C
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG114
 
G_M000_IG72:                ;; offset=0x1449
       mov      rdi, 0x7BE480A64540
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_TargetIndex():int:this]
       mov      rcx, bword ptr [rbp-0x30]
       mov      dword ptr [rcx+0x38], eax
       jmp      G_M000_IG115
 
G_M000_IG73:                ;; offset=0x146E
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_DiscardIterator():bool:this]
       test     eax, eax
       je       SHORT G_M000_IG74
       mov      rdi, 0x7BE480A64544
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp-0x30]
       mov      eax, dword ptr [rax+0x3C]
       lea      esi, [rax-0x01]
       mov      rdi, bword ptr [rbp-0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Trim(int):this]
 
G_M000_IG74:                ;; offset=0x149F
       mov      rdi, 0x7BE480A64548
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_TargetIndex():int:this]
       mov      rcx, bword ptr [rbp-0x30]
       mov      dword ptr [rcx+0x38], eax
       jmp      G_M000_IG115
 
G_M000_IG75:                ;; offset=0x14C4
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x514], eax
       mov      esi, dword ptr [rbp-0x514]
       mov      rdi, bword ptr [rbp-0x30]
       xor      edx, edx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Read(int,int):System.Object:this]
       mov      gword ptr [rbp-0x108], rax
       mov      rsi, gword ptr [rbp-0x108]
       mov      rdi, 0x7BE480A49120
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       je       SHORT G_M000_IG76
       mov      rdi, 0x7BE480A6454C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, bword ptr [rbp-0x30]
       mov      rsi, bword ptr [rbp-0x40]
       mov      rdx, gword ptr [rbp-0x108]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,System.Object):this]
       jmp      G_M000_IG114
 
G_M000_IG76:                ;; offset=0x1532
       mov      rsi, gword ptr [rbp-0x108]
       mov      rdi, 0x7BE4809ED748
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       jne      G_M000_IG78
       mov      rsi, gword ptr [rbp-0x108]
       mov      rdi, 0x7BE4806CF140
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       jne      G_M000_IG83
       mov      rsi, gword ptr [rbp-0x108]
       mov      rdi, 0x7BE480A2D378
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       jne      G_M000_IG82
       mov      rsi, gword ptr [rbp-0x108]
       mov      rdi, 0x7BE4806D3410
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       jne      G_M000_IG81
       mov      rsi, gword ptr [rbp-0x108]
       mov      rdi, 0x7BE4806CE6B0
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       jne      SHORT G_M000_IG80
       mov      rsi, gword ptr [rbp-0x108]
       mov      rdi, 0x7BE4809E8968
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       jne      SHORT G_M000_IG79
       mov      rsi, gword ptr [rbp-0x108]
       mov      rdi, 0x7BE480A2CEC0
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       je       SHORT G_M000_IG84
 
G_M000_IG77:                ;; offset=0x1606
       mov      rdi, 0x7BE480A64550
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG78:                ;; offset=0x1615
       mov      dword ptr [rbp-0x10C], 1
       jmp      SHORT G_M000_IG85
 
G_M000_IG79:                ;; offset=0x1621
       mov      rdi, 0x7BE480A64554
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG78
 
G_M000_IG80:                ;; offset=0x1632
       mov      rdi, 0x7BE480A64558
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG78
 
G_M000_IG81:                ;; offset=0x1643
       mov      rdi, 0x7BE480A6455C
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG78
 
G_M000_IG82:                ;; offset=0x1654
       mov      rdi, 0x7BE480A64560
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG78
 
G_M000_IG83:                ;; offset=0x1665
       mov      rdi, 0x7BE480A64564
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG78
 
G_M000_IG84:                ;; offset=0x1676
       mov      rdi, 0x7BE480A64568
       call     CORINFO_HELP_COUNTPROFILE32
       xor      eax, eax
       mov      dword ptr [rbp-0x10C], eax
 
G_M000_IG85:                ;; offset=0x168D
       cmp      dword ptr [rbp-0x10C], 0
       je       SHORT G_M000_IG86
       mov      rdi, 0x7BE480A6456C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x520], rax
       mov      rsi, gword ptr [rbp-0x520]
       mov      rax, bword ptr [rbp-0x30]
       mov      rdx, gword ptr [rax+0x18]
       mov      rdi, gword ptr [rbp-0x108]
       call     [Lokad.Lython.Runtime.PyIteration+Cursor:Create(System.Object,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):Lokad.Lython.Runtime.PyIteration+Cursor]
       mov      gword ptr [rbp-0x528], rax
       mov      rdx, gword ptr [rbp-0x528]
       mov      rsi, bword ptr [rbp-0x40]
       mov      rdi, bword ptr [rbp-0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,System.Object):this]
       jmp      G_M000_IG114
 
G_M000_IG86:                ;; offset=0x16F3
       mov      rdi, 0x7BE480A64570
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG108
 
G_M000_IG87:                ;; offset=0x1707
       mov      rax, bword ptr [rbp-0x30]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp-0x30]
       add      rax, 72
       mov      bword ptr [rbp-0x298], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x29C], eax
       mov      rax, bword ptr [rbp-0x298]
       mov      eax, dword ptr [rax+0x08]
       cmp      dword ptr [rbp-0x29C], eax
       jae      G_M000_IG120
       mov      rax, bword ptr [rbp-0x298]
       mov      rax, bword ptr [rax]
       mov      ecx, dword ptr [rbp-0x29C]
       mov      rax, gword ptr [rax+8*rcx]
       mov      gword ptr [rbp-0x118], rax
       mov      rsi, gword ptr [rbp-0x118]
       mov      rdi, 0x7BE480A49120
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      gword ptr [rbp-0x130], rax
       cmp      gword ptr [rbp-0x130], 0
       jne      G_M000_IG93
       mov      rsi, gword ptr [rbp-0x118]
       mov      rdi, 0x7BE4809EAA08
       call     [CORINFO_HELP_CHKCASTCLASS]
       mov      gword ptr [rbp-0x530], rax
       mov      rdi, gword ptr [rbp-0x530]
       lea      rsi, [rbp-0x138]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.PyIteration+Cursor:TryMoveNext(byref):bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG90
       call     [Lokad.Lython.Runtime.PyIterationResult:get_End():Lokad.Lython.Runtime.PyIterationResult]
       mov      gword ptr [rbp-0x2E0], rax
       mov      qword ptr [rbp-0x2D8], rdx
 
G_M000_IG88:                ;; offset=0x17D5
       vmovdqu32 xmm0, xmmword ptr [rbp-0x2E0]
       vmovdqu32 xmmword ptr [rbp-0x2C0], xmm0
 
G_M000_IG89:                ;; offset=0x17E3
       jmp      SHORT G_M000_IG95
 
G_M000_IG90:                ;; offset=0x17E5
       mov      rdi, 0x7BE480A64574
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, gword ptr [rbp-0x138]
       call     [Lokad.Lython.Runtime.PyIterationResult:Yield(System.Object):Lokad.Lython.Runtime.PyIterationResult]
       mov      gword ptr [rbp-0x2D0], rax
       mov      qword ptr [rbp-0x2C8], rdx
 
G_M000_IG91:                ;; offset=0x180F
       vmovdqu32 xmm0, xmmword ptr [rbp-0x2D0]
       vmovdqu32 xmmword ptr [rbp-0x2C0], xmm0
 
G_M000_IG92:                ;; offset=0x181D
       jmp      SHORT G_M000_IG95
 
G_M000_IG93:                ;; offset=0x181F
       mov      rdi, 0x7BE480A64578
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, gword ptr [rbp-0x130]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.Text.PyStringOps+CasedWhitespaceIteration:MoveNext():Lokad.Lython.Runtime.PyIterationResult:this]
       mov      gword ptr [rbp-0x2B0], rax
       mov      qword ptr [rbp-0x2A8], rdx
 
G_M000_IG94:                ;; offset=0x184B
       vmovdqu32 xmm0, xmmword ptr [rbp-0x2B0]
       vmovdqu32 xmmword ptr [rbp-0x2C0], xmm0
 
G_M000_IG95:                ;; offset=0x1859
       vmovdqu32 xmm0, xmmword ptr [rbp-0x2C0]
       vmovdqu  xmmword ptr [rbp-0x128], xmm0
 
G_M000_IG96:                ;; offset=0x1868
       lea      rdi, [rbp-0x128]
       call     [Lokad.Lython.Runtime.PyIterationResult:get_HasValue():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG97
       mov      rdi, 0x7BE480A6457C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x534], eax
       mov      esi, dword ptr [rbp-0x534]
       mov      rdi, bword ptr [rbp-0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Trim(int):this]
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_TargetIndex():int:this]
       mov      rcx, bword ptr [rbp-0x30]
       mov      dword ptr [rcx+0x38], eax
       jmp      G_M000_IG115
 
G_M000_IG97:                ;; offset=0x18BE
       mov      rdi, 0x7BE480A64580
       call     CORINFO_HELP_COUNTPROFILE32
       lea      rdi, [rbp-0x128]
       call     [Lokad.Lython.Runtime.PyIterationResult:get_Value():System.Object:this]
       mov      gword ptr [rbp-0x540], rax
       mov      rdx, gword ptr [rbp-0x540]
       mov      rsi, bword ptr [rbp-0x40]
       mov      rdi, bword ptr [rbp-0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,System.Object):this]
       jmp      G_M000_IG114
 
G_M000_IG98:                ;; offset=0x18FB
       mov      rdi, bword ptr [rbp-0x30]
       mov      rsi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:TryReturnUnpackedTuple(byref):bool:this]
       test     eax, eax
       je       SHORT G_M000_IG99
       mov      rdi, 0x7BE480A64584
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG118
 
G_M000_IG99:                ;; offset=0x1921
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ItemCount():int:this]
       test     eax, eax
       je       G_M000_IG100
       mov      rax, bword ptr [rbp-0x30]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp-0x30]
       add      rax, 72
       mov      bword ptr [rbp-0x2F0], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x2F4], eax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ItemCount():int:this]
       mov      dword ptr [rbp-0x544], eax
       mov      ecx, dword ptr [rbp-0x544]
       mov      rdi, bword ptr [rbp-0x2F0]
       mov      edx, dword ptr [rbp-0x2F4]
       mov      rsi, 0x7BE4801EB4D0
       call     [System.Span`1[System.__Canon]:Slice(int,int):System.Span`1[System.__Canon]:this]
       mov      bword ptr [rbp-0x308], rax
       mov      qword ptr [rbp-0x300], rdx
       mov      rsi, bword ptr [rbp-0x308]
       mov      rdx, qword ptr [rbp-0x300]
       mov      rdi, 0x7BE4801EB4D0
       call     [System.Span`1[System.__Canon]:op_Implicit(System.Span`1[System.__Canon]):System.ReadOnlySpan`1[System.__Canon]]
       mov      bword ptr [rbp-0x318], rax
       mov      qword ptr [rbp-0x310], rdx
       mov      rax, bword ptr [rbp-0x30]
       mov      rdi, gword ptr [rax+0x18]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:get_MemoryGovernor():Lokad.Lython.Runtime.MemoryGovernor:this]
       mov      gword ptr [rbp-0x320], rax
       mov      rdi, 0x7BE4806CF140
       call     CORINFO_HELP_NEWSFAST
       mov      gword ptr [rbp-0x328], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x550], rax
       mov      r8, gword ptr [rbp-0x550]
       mov      rax, bword ptr [rbp-0x30]
       mov      r9, gword ptr [rax+0x18]
       mov      rsi, bword ptr [rbp-0x318]
       mov      rdx, qword ptr [rbp-0x310]
       mov      rcx, gword ptr [rbp-0x320]
       mov      rdi, gword ptr [rbp-0x328]
       call     [Lokad.Lython.Runtime.PyTuple:.ctor(System.ReadOnlySpan`1[System.Object],Lokad.Lython.Runtime.MemoryGovernor,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):this]
       mov      rax, gword ptr [rbp-0x328]
       mov      gword ptr [rbp-0x2E8], rax
       jmp      SHORT G_M000_IG101
 
G_M000_IG100:                ;; offset=0x1A44
       mov      rdi, 0x7BE480A64588
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, 0x7BDCA1801680
       mov      rax, gword ptr [rax]
       mov      gword ptr [rbp-0x2E8], rax
 
G_M000_IG101:                ;; offset=0x1A67
       mov      rdi, 0x7BE480A6458C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, gword ptr [rbp-0x2E8]
       mov      gword ptr [rbp-0x140], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x554], eax
       mov      esi, dword ptr [rbp-0x554]
       mov      rdi, bword ptr [rbp-0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Trim(int):this]
       mov      rdi, bword ptr [rbp-0x30]
       mov      rsi, bword ptr [rbp-0x40]
       mov      rdx, gword ptr [rbp-0x140]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,System.Object):this]
       jmp      G_M000_IG114
 
G_M000_IG102:                ;; offset=0x1ABE
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ItemCount():int:this]
       mov      edi, eax
       call     [Lokad.Lython.Runtime.PyList:EstimateCapacityBytes(int):long]
       mov      qword ptr [rbp-0x148], rax
       mov      rax, bword ptr [rbp-0x30]
       mov      rdi, gword ptr [rax+0x18]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:get_MemoryGovernor():Lokad.Lython.Runtime.MemoryGovernor:this]
       mov      gword ptr [rbp-0x330], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x560], rax
       mov      rdx, gword ptr [rbp-0x560]
       mov      rsi, qword ptr [rbp-0x148]
       mov      rdi, gword ptr [rbp-0x330]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.MemoryGovernor:ReserveTemporary(long,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.MemoryGovernor+TemporaryMemoryReservation:this]
       mov      gword ptr [rbp-0x150], rax
 
G_M000_IG103:                ;; offset=0x1B23
       mov      rdi, 0x7BE480A64590
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp-0x30]
       mov      rax, gword ptr [rax+0x18]
       mov      gword ptr [rbp-0x338], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x568], rax
       mov      rsi, gword ptr [rbp-0x568]
       mov      rdi, gword ptr [rbp-0x338]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CheckExecution(Lokad.Lython.LythonSourceSpan):this]
       mov      rax, bword ptr [rbp-0x30]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp-0x30]
       add      rax, 72
       mov      bword ptr [rbp-0x340], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x344], eax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ItemCount():int:this]
       mov      dword ptr [rbp-0x56C], eax
       mov      ecx, dword ptr [rbp-0x56C]
       mov      rdi, bword ptr [rbp-0x340]
       mov      edx, dword ptr [rbp-0x344]
       mov      rsi, 0x7BE4801EB4D0
       call     [System.Span`1[System.__Canon]:Slice(int,int):System.Span`1[System.__Canon]:this]
       mov      bword ptr [rbp-0x358], rax
       mov      qword ptr [rbp-0x350], rdx
 
G_M000_IG104:                ;; offset=0x1BCE
       vmovdqu  xmm0, xmmword ptr [rbp-0x358]
       vmovdqu  xmmword ptr [rbp-0x168], xmm0
 
G_M000_IG105:                ;; offset=0x1BDE
       lea      rdi, [rbp-0x168]
       mov      rsi, 0x7BE4801EB4D0
       call     [System.Span`1[System.__Canon]:ToArray():System.__Canon[]:this]
       mov      gword ptr [rbp-0x158], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x570], eax
       mov      esi, dword ptr [rbp-0x570]
       mov      rdi, bword ptr [rbp-0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Trim(int):this]
       mov      rdi, gword ptr [rbp-0x150]
       mov      rsi, qword ptr [rbp-0x148]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.MemoryGovernor+TemporaryMemoryReservation:Commit(long):this]
       mov      rax, bword ptr [rbp-0x30]
       mov      rdi, gword ptr [rax+0x18]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:get_MemoryGovernor():Lokad.Lython.Runtime.MemoryGovernor:this]
       mov      gword ptr [rbp-0x360], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x578], rax
       mov      rdx, gword ptr [rbp-0x578]
       mov      rsi, gword ptr [rbp-0x360]
       mov      rdi, gword ptr [rbp-0x158]
       call     [Lokad.Lython.Runtime.PyList:FromTransferredArray(System.Object[],Lokad.Lython.Runtime.MemoryGovernor,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.PyList]
       mov      gword ptr [rbp-0x580], rax
       mov      rdx, gword ptr [rbp-0x580]
       mov      rsi, bword ptr [rbp-0x40]
       mov      rdi, bword ptr [rbp-0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,System.Object):this]
       nop      
 
G_M000_IG106:                ;; offset=0x1C92
       call     G_M000_IG121
       jmp      G_M000_IG114
 
G_M000_IG107:                ;; offset=0x1C9C
       mov      rdi, bword ptr [rbp-0x30]
       mov      rsi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Format(byref):bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG110
       mov      rdi, 0x7BE480A646A4
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG108:                ;; offset=0x1CBD
       xor      eax, eax
 
G_M000_IG109:                ;; offset=0x1CBF
       add      rsp, 0x5D0
       pop      rbp
       ret      
 
G_M000_IG110:                ;; offset=0x1CC8
       mov      rdi, 0x7BE480A646A8
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG114
 
G_M000_IG111:                ;; offset=0x1CDC
       mov      rdi, 0x7BE480A646AC
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       inc      eax
       mov      dword ptr [rbp-0x364], eax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      dword ptr [rbp-0x368], eax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x58C], eax
       mov      esi, dword ptr [rbp-0x58C]
       mov      rdi, bword ptr [rbp-0x30]
       xor      edx, edx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Read(int,int):System.Object:this]
       mov      gword ptr [rbp-0x598], rax
       mov      rcx, gword ptr [rbp-0x598]
       mov      esi, dword ptr [rbp-0x364]
       mov      edx, dword ptr [rbp-0x368]
       mov      rdi, bword ptr [rbp-0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Put(int,int,System.Object):this]
       jmp      G_M000_IG114
 
G_M000_IG112:                ;; offset=0x1D58
       mov      rdi, 0x7BE480A646B0
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x59C], eax
       mov      esi, dword ptr [rbp-0x59C]
       mov      rdi, bword ptr [rbp-0x30]
       xor      edx, edx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Read(int,int):System.Object:this]
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      dword ptr [rbp-0x5A0], eax
       mov      esi, dword ptr [rbp-0x5A0]
       mov      rdi, bword ptr [rbp-0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Trim(int):this]
       jmp      G_M000_IG114
 
G_M000_IG113:                ;; offset=0x1DAE
       lea      rdi, [rbp-0x190]
       mov      esi, 26
       mov      edx, 1
       call     [System.Runtime.CompilerServices.DefaultInterpolatedStringHandler:.ctor(int,int):this]
       lea      rdi, [rbp-0x190]
       mov      rsi, 0x7BE47C254E80
       call     [System.Runtime.CompilerServices.DefaultInterpolatedStringHandler:AppendLiteral(System.String):this]
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_OpCode():int:this]
       mov      dword ptr [rbp-0x5A4], eax
       mov      esi, dword ptr [rbp-0x5A4]
       lea      rdi, [rbp-0x190]
       call     [System.Runtime.CompilerServices.DefaultInterpolatedStringHandler:AppendFormatted[int](int):this]
       mov      rdi, 0x7BE47F987A68
       call     CORINFO_HELP_NEWSFAST
       mov      gword ptr [rbp-0x388], rax
       lea      rdi, [rbp-0x190]
       call     [System.Runtime.CompilerServices.DefaultInterpolatedStringHandler:ToStringAndClear():System.String:this]
       mov      gword ptr [rbp-0x5B0], rax
       mov      rsi, gword ptr [rbp-0x5B0]
       mov      rdi, gword ptr [rbp-0x388]
       call     [System.InvalidOperationException:.ctor(System.String):this]
       mov      rdi, gword ptr [rbp-0x388]
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG114:                ;; offset=0x1E4A
       mov      rdi, 0x7BE480A646B4
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp-0x30]
       inc      dword ptr [rax+0x38]
 
G_M000_IG115:                ;; offset=0x1E60
       mov      eax, dword ptr [rbp-0x3E4]
       dec      eax
       mov      dword ptr [rbp-0x3E4], eax
       cmp      dword ptr [rbp-0x3E4], 0
       jg       SHORT G_M000_IG117
 
G_M000_IG116:                ;; offset=0x1E77
       lea      rdi, [rbp-0x3E4]
       mov      esi, 0x96A
       call     CORINFO_HELP_PATCHPOINT
       jmp      rax
 
G_M000_IG117:                ;; offset=0x1E8A
       mov      rax, bword ptr [rbp-0x30]
       mov      eax, dword ptr [rax+0x38]
       mov      dword ptr [rbp-0x194], eax
       mov      rax, bword ptr [rbp-0x30]
       mov      rdi, gword ptr [rax+0x08]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Instructions():Lokad.Lython.Frontend.ExecutableInstruction[]:this]
       mov      eax, dword ptr [rax+0x08]
       cmp      eax, dword ptr [rbp-0x194]
       jg       G_M000_IG03
       mov      rdi, 0x7BE480A646B8
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG118:                ;; offset=0x1EC5
       mov      eax, 1
 
G_M000_IG119:                ;; offset=0x1ECA
       add      rsp, 0x5D0
       pop      rbp
       ret      
 
G_M000_IG120:                ;; offset=0x1ED3
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG121:                ;; offset=0x1ED9
       sub      rsp, 24
 
G_M000_IG122:                ;; offset=0x1EDD
       cmp      gword ptr [rbp-0x150], 0
       je       SHORT G_M000_IG123
       mov      rdi, 0x7BE480A64594
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, gword ptr [rbp-0x150]
       mov      gword ptr [rbp-0x3E0], rax
       mov      rdi, gword ptr [rbp-0x3E0]
       mov      rsi, 0x7BE480A64598
       call     CORINFO_HELP_CLASSPROFILE32
       mov      rax, gword ptr [rbp-0x3E0]
       mov      gword ptr [rbp-0x588], rax
       mov      rdi, gword ptr [rbp-0x588]
       mov      r11, 0x7BE47E052730
       call     [r11]System.IDisposable:Dispose():this
 
G_M000_IG123:                ;; offset=0x1F3C
       mov      rdi, 0x7BE480A646A0
       call     CORINFO_HELP_COUNTPROFILE32
       nop      
 
G_M000_IG124:                ;; offset=0x1F4C
       add      rsp, 24
       ret      
 
RWD00  	dd	0000023Fh ; case G_M000_IG11
       	dd	000002DCh ; case G_M000_IG12
       	dd	0000041Bh ; case G_M000_IG14
       	dd	00000344h ; case G_M000_IG13
RWD16  	dd	00000607h ; case G_M000_IG24
       	dd	00001D6Bh ; case G_M000_IG113
       	dd	00000580h ; case G_M000_IG23
       	dd	000004EFh ; case G_M000_IG19
       	dd	00001D6Bh ; case G_M000_IG113
       	dd	00001D6Bh ; case G_M000_IG113
       	dd	00001C99h ; case G_M000_IG111
       	dd	00001D15h ; case G_M000_IG112
       	dd	00001A7Bh ; case G_M000_IG102
       	dd	000018B8h ; case G_M000_IG98
       	dd	00001D6Bh ; case G_M000_IG113
       	dd	00001D6Bh ; case G_M000_IG113
       	dd	00001D6Bh ; case G_M000_IG113
       	dd	00001D6Bh ; case G_M000_IG113
       	dd	00001D6Bh ; case G_M000_IG113
       	dd	00001D6Bh ; case G_M000_IG113
       	dd	00001481h ; case G_M000_IG75
       	dd	000016C4h ; case G_M000_IG87
       	dd	000007D5h ; case G_M000_IG29
       	dd	0000080Fh ; case G_M000_IG31
       	dd	00001D6Bh ; case G_M000_IG113
       	dd	00001D6Bh ; case G_M000_IG113
       	dd	00000C41h ; case G_M000_IG46
       	dd	00000C41h ; case G_M000_IG46
       	dd	00000AB6h ; case G_M000_IG40
       	dd	00001406h ; case G_M000_IG72
       	dd	00001332h ; case G_M000_IG69
       	dd	000011CCh ; case G_M000_IG66
       	dd	00001D6Bh ; case G_M000_IG113
       	dd	00001D6Bh ; case G_M000_IG113
       	dd	00001D6Bh ; case G_M000_IG113
       	dd	00001D6Bh ; case G_M000_IG113
       	dd	00001D6Bh ; case G_M000_IG113
       	dd	0000014Fh ; case G_M000_IG09
       	dd	00000115h ; case G_M000_IG08
       	dd	00000115h ; case G_M000_IG08
       	dd	00001D6Bh ; case G_M000_IG113
       	dd	00001D6Bh ; case G_M000_IG113
       	dd	0000142Bh ; case G_M000_IG73
       	dd	00001C59h ; case G_M000_IG107
       	dd	00001C59h ; case G_M000_IG107
       	dd	00001C59h ; case G_M000_IG107
       	dd	00001C59h ; case G_M000_IG107
       	dd	00001C59h ; case G_M000_IG107

; Total bytes of code 8017

; Assembly listing for method Lokad.Lython.Runtime.LythonRuntime+NativeExecution:RunCore(byref):bool:this (Tier1)
; Emitting BLENDED_CODE for x64 + VEX + EVEX on Unix
; Tier1 code
; optimized code
; optimized using Synthesized PGO
; rbp based frame
; fully interruptible
; with Synthesized PGO: fgCalledCount is 1553408
; 33 inlinees with PGO data; 124 single block inlinees; 9 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       push     r15
       push     r14
       push     r13
       push     r12
       push     rbx
       sub      rsp, 280
       lea      rbp, [rsp+0x140]
       vxorps   xmm8, xmm8, xmm8
       vmovdqu32 zmmword ptr [rbp-0x120], zmm8
       vmovdqu32 zmmword ptr [rbp-0xE0], zmm8
       vmovdqu32 zmmword ptr [rbp-0xA0], zmm8
       vmovdqu32 zmmword ptr [rbp-0x70], zmm8
       xor      eax, eax
       mov      qword ptr [rbp-0x30], rax
       mov      rbx, rdi
       mov      r15, rsi
 
G_M000_IG02:                ;; offset=0x0052
       mov      rdi, 0x7BDCA1801728
       mov      rsi, gword ptr [rdi]
       mov      rdi, r15
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      edi, dword ptr [rbx+0x38]
       mov      rax, gword ptr [rbx+0x08]
       mov      rax, gword ptr [rax+0x50]
       cmp      edi, dword ptr [rax+0x08]
       jge      G_M000_IG36
       jmp      G_M000_IG28
 
G_M000_IG03:                ;; offset=0x0080
       mov      rdi, rbx
       mov      rsi, r14
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Call(byref):bool:this]
       test     eax, eax
       jne      G_M000_IG26
       jmp      G_M000_IG97
 
G_M000_IG04:                ;; offset=0x0099
       mov      rdi, rbx
       mov      esi, r14d
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Trim(int):this]
       jmp      G_M000_IG25
 
G_M000_IG05:                ;; offset=0x00AA
       mov      esi, dword ptr [r14+0x10]
       test     esi, esi
       jl       G_M000_IG63
       lea      rdi, bword ptr [rbx+0x48]
       cmp      esi, dword ptr [rdi+0x08]
       jae      G_M000_IG138
       mov      rdi, bword ptr [rdi]
       mov      r11d, esi
       mov      r13, gword ptr [rdi+8*r11]
       test     r13, r13
       je       G_M000_IG64
 
G_M000_IG06:                ;; offset=0x00D6
       mov      rdi, gword ptr [rbx+0x08]
       mov      r12, gword ptr [rdi+0x18]
       mov      rdi, r14
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_NameIndex():int:this]
       mov      rdi, 0x7BE47F34BEC0
       cmp      qword ptr [r12], rdi
       jne      G_M000_IG65
       cmp      dword ptr [r12+0x08], eax
       jbe      G_M000_IG135
       mov      edi, eax
       mov      rdi, gword ptr [r12+8*rdi+0x10]
 
G_M000_IG07:                ;; offset=0x010D
       test     r13, r13
       je       SHORT G_M000_IG12
 
G_M000_IG08:                ;; offset=0x0112
       mov      rax, 0x7BE4806CE6B0
       cmp      qword ptr [r13], rax
       jne      SHORT G_M000_IG10
 
G_M000_IG09:                ;; offset=0x0122
       call     [Lokad.Lython.Runtime.LythonRuntime+StringMembers:GetMethod(System.String):Lokad.Lython.Runtime.LythonRuntime+ReceiverMethod]
       mov      r12, rax
       jmp      SHORT G_M000_IG13
 
G_M000_IG10:                ;; offset=0x012D
       mov      rax, 0x7BE4809E8968
       cmp      qword ptr [r13], rax
       jne      SHORT G_M000_IG12
 
G_M000_IG11:                ;; offset=0x013D
       call     [Lokad.Lython.Runtime.LythonRuntime+DictMembers:GetMethod(System.String):Lokad.Lython.Runtime.LythonRuntime+ReceiverMethod]
       mov      r12, rax
       jmp      SHORT G_M000_IG13
 
G_M000_IG12:                ;; offset=0x0148
       xor      r12, r12
 
G_M000_IG13:                ;; offset=0x014B
       test     r12, r12
       je       G_M000_IG97
       mov      edi, dword ptr [r14+0x1C]
       cmp      edi, 52
       ja       SHORT G_M000_IG15
 
G_M000_IG14:                ;; offset=0x015D
       mov      rax, 0xFFFFFFFFFE7FF
       bt       rax, rdi
       jae      G_M000_IG66
 
G_M000_IG15:                ;; offset=0x0171
       mov      eax, dword ptr [r14+0x14]
       mov      dword ptr [rbp-0xB0], eax
 
G_M000_IG16:                ;; offset=0x017B
       mov      edi, dword ptr [r14+0x1C]
       cmp      edi, 52
       ja       SHORT G_M000_IG18
 
G_M000_IG17:                ;; offset=0x0184
       mov      rcx, 0xFFFFFFFFFE7FF
       bt       rcx, rdi
       jae      G_M000_IG67
 
G_M000_IG18:                ;; offset=0x0198
       mov      edi, dword ptr [r14+0x14]
 
G_M000_IG19:                ;; offset=0x019C
       lea      ecx, [rdi+0x01]
       mov      dword ptr [rbp-0xB4], ecx
       cmp      ecx, dword ptr [rbx+0x3C]
       jl       G_M000_IG38
 
G_M000_IG20:                ;; offset=0x01AE
       lea      rdi, bword ptr [rbx+0x48]
       mov      eax, dword ptr [rbp-0xB0]
       cmp      eax, dword ptr [rdi+0x08]
       jae      G_M000_IG138
       mov      rdi, bword ptr [rdi]
       mov      esi, eax
       lea      rdi, bword ptr [rdi+8*rsi]
       mov      rsi, r13
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      r13d, dword ptr [rbp-0xB4]
       mov      dword ptr [rbx+0x3C], r13d
       mov      edi, dword ptr [r14+0x1C]
       cmp      edi, 52
       ja       SHORT G_M000_IG22
 
G_M000_IG21:                ;; offset=0x01E6
       mov      rax, 0xFFFFFFFFFE7FF
       bt       rax, rdi
       jae      G_M000_IG68
 
G_M000_IG22:                ;; offset=0x01FA
       mov      eax, dword ptr [r14+0x14]
 
G_M000_IG23:                ;; offset=0x01FE
       lea      r13d, [rax+0x01]
       mov      r14d, dword ptr [r14+0x18]
       test     r14d, r14d
       jl       G_M000_IG39
 
G_M000_IG24:                ;; offset=0x020F
       cmp      r14d, dword ptr [rbx+0x3C]
       jl       G_M000_IG04
 
G_M000_IG25:                ;; offset=0x0219
       lea      rdi, bword ptr [rbx+0x48]
       cmp      r13d, dword ptr [rdi+0x08]
       jae      G_M000_IG138
       mov      rdi, bword ptr [rdi]
       mov      esi, r13d
       lea      rdi, bword ptr [rdi+8*rsi]
       mov      rsi, r12
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      dword ptr [rbx+0x3C], r14d
 
G_M000_IG26:                ;; offset=0x023D
       inc      dword ptr [rbx+0x38]
 
G_M000_IG27:                ;; offset=0x0240
       mov      esi, dword ptr [rbx+0x38]
       mov      rdi, gword ptr [rbx+0x08]
       mov      rdi, gword ptr [rdi+0x50]
       cmp      esi, dword ptr [rdi+0x08]
       jge      G_M000_IG36
 
G_M000_IG28:                ;; offset=0x0254
       mov      rdi, gword ptr [rbx+0x08]
       mov      rdi, gword ptr [rdi+0x50]
       mov      eax, dword ptr [rbx+0x38]
       cmp      eax, dword ptr [rdi+0x08]
       jae      G_M000_IG138
       shl      rax, 5
       lea      r14, bword ptr [rdi+rax+0x10]
       mov      rdi, gword ptr [rbx+0x18]
       mov      rdi, gword ptr [rdi+0xA0]
       mov      rax, gword ptr [r14]
       mov      rcx, gword ptr [rdi+0x88]
       mov      rcx, gword ptr [rcx+0x20]
       test     rcx, rcx
       jne      G_M000_IG123
       mov      rdi, gword ptr [rdi+0x178]
       test     rdi, rdi
       jne      G_M000_IG51
 
G_M000_IG29:                ;; offset=0x02A3
       mov      edi, dword ptr [r14+0x1C]
       lea      r13d, [rdi-0x03]
       cmp      r13d, 3
       jbe      G_M000_IG40
 
G_M000_IG30:                ;; offset=0x02B5
       add      edi, -25
       cmp      edi, 43
       ja       G_M000_IG124
       lea      rsi, [reloc @RWD00]
       mov      esi, dword ptr [rsi+4*rdi]
       lea      rax, G_M000_IG02
       add      rsi, rax
       jmp      rsi
 
G_M000_IG31:                ;; offset=0x02D7
       mov      esi, dword ptr [r14+0x10]
       test     esi, esi
       jl       G_M000_IG126
       lea      rdi, bword ptr [rbx+0x48]
       cmp      esi, dword ptr [rdi+0x08]
       jae      G_M000_IG138
       mov      rdi, bword ptr [rdi]
       mov      eax, esi
       mov      rdi, gword ptr [rdi+8*rax]
       test     rdi, rdi
       je       G_M000_IG127
       mov      gword ptr [rbp-0xE0], rdi
 
G_M000_IG32:                ;; offset=0x0309
       mov      rsi, gword ptr [rbp-0xE0]
       mov      rdi, r15
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      esi, dword ptr [r14+0x10]
       mov      rdi, gword ptr [rbx+0x08]
       cmp      esi, dword ptr [rdi+0x9C]
       jl       SHORT G_M000_IG34
 
G_M000_IG33:                ;; offset=0x0328
       lea      rdi, bword ptr [rbx+0x48]
       cmp      esi, dword ptr [rdi+0x08]
       jae      G_M000_IG138
       mov      rdi, bword ptr [rdi]
       mov      esi, esi
       xor      rax, rax
       mov      gword ptr [rdi+8*rsi], rax
 
G_M000_IG34:                ;; offset=0x0340
       mov      rsi, gword ptr [rbx+0x08]
       mov      r14d, dword ptr [rsi+0x9C]
       mov      r15d, dword ptr [rbx+0x3C]
       dec      r15d
       mov      esi, dword ptr [rsi+0xA0]
       cmp      r15d, esi
       cmovg    r15d, esi
       cmp      r15d, r14d
       jge      G_M000_IG129
 
G_M000_IG35:                ;; offset=0x0368
       mov      dword ptr [rbx+0x3C], r14d
 
G_M000_IG36:                ;; offset=0x036C
       mov      eax, 1
 
G_M000_IG37:                ;; offset=0x0371
       vzeroupper 
       add      rsp, 280
       pop      rbx
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG38:                ;; offset=0x0386
       mov      rdi, rbx
       mov      esi, ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Trim(int):this]
       jmp      G_M000_IG20
 
G_M000_IG39:                ;; offset=0x0396
       not      r14d
       jmp      G_M000_IG24
 
G_M000_IG40:                ;; offset=0x039E
       mov      edi, r13d
       lea      rax, [reloc @RWD176]
       mov      eax, dword ptr [rax+4*rdi]
       lea      rcx, G_M000_IG02
       add      rax, rcx
       jmp      rax
 
G_M000_IG41:                ;; offset=0x03B7
       mov      edi, dword ptr [r14+0x1C]
       cmp      edi, 4
       je       SHORT G_M000_IG43
 
G_M000_IG42:                ;; offset=0x03C0
       cmp      edi, 27
       jne      G_M000_IG131
 
G_M000_IG43:                ;; offset=0x03C9
       mov      esi, dword ptr [r14+0x08]
       mov      r13, gword ptr [r14]
       lea      rdi, bword ptr [rbx+0x48]
       cmp      esi, dword ptr [rdi+0x08]
       jae      G_M000_IG138
       mov      rdi, bword ptr [rdi]
       mov      eax, esi
       mov      r12, gword ptr [rdi+8*rax]
       test     r12, r12
       je       G_M000_IG132
       cmp      dword ptr [r14+0x18], 0
       jl       G_M000_IG54
       mov      edi, dword ptr [r14+0x1C]
       cmp      edi, 52
       ja       SHORT G_M000_IG45
 
G_M000_IG44:                ;; offset=0x0403
       mov      rax, 0xFFFFFFFFFE7FF
       bt       rax, rdi
       jae      G_M000_IG53
 
G_M000_IG45:                ;; offset=0x0417
       mov      r13d, dword ptr [r14+0x14]
 
G_M000_IG46:                ;; offset=0x041B
       mov      r14d, dword ptr [r14+0x18]
       test     r14d, r14d
       jl       SHORT G_M000_IG49
 
G_M000_IG47:                ;; offset=0x0424
       cmp      r14d, dword ptr [rbx+0x3C]
       jl       SHORT G_M000_IG50
 
G_M000_IG48:                ;; offset=0x042A
       lea      rdi, bword ptr [rbx+0x48]
       cmp      r13d, dword ptr [rdi+0x08]
       jae      G_M000_IG138
       mov      rdi, bword ptr [rdi]
       mov      esi, r13d
       lea      rdi, bword ptr [rdi+8*rsi]
       mov      rsi, r12
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      dword ptr [rbx+0x3C], r14d
       jmp      G_M000_IG26
 
G_M000_IG49:                ;; offset=0x0453
       not      r14d
       jmp      SHORT G_M000_IG47
 
G_M000_IG50:                ;; offset=0x0458
       mov      rdi, rbx
       mov      esi, r14d
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Trim(int):this]
       jmp      SHORT G_M000_IG48
 
G_M000_IG51:                ;; offset=0x0466
       cmp      dword ptr [rdi+0x20], 0
       je       G_M000_IG29
       mov      rdi, rax
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionCanceled(Lokad.Lython.LythonSourceSpan)]
       jmp      G_M000_IG29
 
G_M000_IG52:                ;; offset=0x047E
       mov      rdi, gword ptr [rbx+0x08]
       mov      r13, gword ptr [rdi+0x10]
       mov      rdi, r14
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ConstantIndex():int:this]
       mov      esi, eax
       mov      rdi, r13
       mov      r11, 0x7BE47E052C00
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       mov      rdi, rax
       call     [Lokad.Lython.Runtime.LythonRuntime:RuntimeValue(System.Object):System.Object]
       mov      rdx, rax
       mov      rsi, r14
       mov      rdi, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,System.Object):this]
       jmp      G_M000_IG26
 
G_M000_IG53:                ;; offset=0x04BE
       mov      rdi, r14
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      r13d, eax
       jmp      G_M000_IG46
 
G_M000_IG54:                ;; offset=0x04CF
       mov      rdi, r14
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       cmp      eax, dword ptr [rbx+0x3C]
       jge      SHORT G_M000_IG55
       mov      rdi, r14
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      esi, eax
       mov      rdi, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Trim(int):this]
 
G_M000_IG55:                ;; offset=0x04F1
       lea      r13, bword ptr [rbx+0x48]
       mov      rdi, r14
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       cmp      eax, dword ptr [r13+0x08]
       jae      G_M000_IG138
       mov      rdi, bword ptr [r13]
       mov      eax, eax
       xor      rcx, rcx
       mov      gword ptr [rdi+8*rax], rcx
       mov      rdi, r14
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       mov      dword ptr [rbx+0x3C], eax
       mov      rdi, gword ptr [rbx+0x08]
       mov      rdi, gword ptr [rdi+0x50]
       mov      eax, dword ptr [rbx+0x38]
       inc      eax
       cmp      eax, dword ptr [rdi+0x08]
       jae      G_M000_IG138
       shl      rax, 5
       lea      r14, bword ptr [rdi+rax+0x10]
       mov      rdi, gword ptr [rbx+0x18]
       mov      rax, gword ptr [r14]
       mov      rdi, gword ptr [rdi+0xA0]
       mov      rcx, gword ptr [rdi+0x88]
       mov      rcx, gword ptr [rcx+0x20]
       test     rcx, rcx
       jne      G_M000_IG133
       mov      rdi, gword ptr [rdi+0x178]
       test     rdi, rdi
       je       SHORT G_M000_IG56
       cmp      dword ptr [rdi+0x20], 0
       setne    dil
       movzx    rdi, dil
       test     edi, edi
       jne      SHORT G_M000_IG57
 
G_M000_IG56:                ;; offset=0x057D
       lea      r13, bword ptr [rbx+0x48]
       mov      rdi, r14
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LocalSlot():int:this]
       cmp      eax, dword ptr [r13+0x08]
       jae      G_M000_IG138
       mov      rdi, bword ptr [r13]
       mov      esi, eax
       lea      rdi, bword ptr [rdi+8*rsi]
       mov      rsi, r12
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       inc      dword ptr [rbx+0x38]
       jmp      G_M000_IG26
 
G_M000_IG57:                ;; offset=0x05AE
       mov      rdi, rax
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionCanceled(Lokad.Lython.LythonSourceSpan)]
       jmp      SHORT G_M000_IG56
 
G_M000_IG58:                ;; offset=0x05B9
       mov      rdi, gword ptr [rbx+0x08]
       mov      r13, gword ptr [rdi+0x18]
       mov      rdi, r14
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_NameIndex():int:this]
       mov      esi, eax
       mov      rdi, r13
       mov      r11, 0x7BE47E052BF8
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       mov      rdi, rax
       mov      rsi, gword ptr [r14]
       mov      rdx, gword ptr [rbx+0x18]
       call     [Lokad.Lython.Runtime.LythonRuntime:ResolveExecutableGlobal(System.String,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):System.Object]
       mov      rdx, rax
       mov      rsi, r14
       mov      rdi, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,System.Object):this]
       jmp      G_M000_IG26
 
G_M000_IG59:                ;; offset=0x0600
       mov      rdi, gword ptr [rbx+0x08]
       mov      rsi, gword ptr [rbx+0x10]
       mov      edx, dword ptr [rbx+0x38]
       mov      ecx, dword ptr [rbx+0x3C]
       mov      r8, gword ptr [rbx+0x18]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryExecuteClosureArithmetic(Lokad.Lython.Frontend.ExecutableCodeObject,System.Collections.Generic.IReadOnlyList`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableCell],int,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):bool]
       test     eax, eax
       je       SHORT G_M000_IG60
       add      dword ptr [rbx+0x38], 2
       jmp      G_M000_IG26
 
G_M000_IG60:                ;; offset=0x0625
       mov      rdi, r14
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ClosureSlot():int:this]
       mov      esi, eax
       lea      rdx, [rbp-0x30]
       mov      rdi, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:TryCell(int,byref):bool:this]
       test     eax, eax
       je       G_M000_IG97
       mov      rdi, gword ptr [rbp-0x30]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableCell:get_Value():System.Object:this]
       test     rax, rax
       je       G_M000_IG97
       mov      rdi, rbx
       mov      rsi, r14
       mov      rdx, rax
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,System.Object):this]
       jmp      G_M000_IG26
 
G_M000_IG61:                ;; offset=0x066E
       mov      rdi, r14
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ClosureSlot():int:this]
       mov      esi, eax
       lea      rdx, [rbp-0x38]
       mov      rdi, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:TryCell(int,byref):bool:this]
       test     eax, eax
       je       G_M000_IG97
       mov      rdi, gword ptr [rbp-0x38]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableCell:get_CanStoreThroughOwner():bool:this]
       test     eax, eax
       je       G_M000_IG97
       mov      rdi, rbx
       mov      rsi, r14
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Take(byref):System.Object:this]
       mov      rsi, rax
       mov      rdi, gword ptr [rbp-0x38]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableCell:set_Value(System.Object):this]
       jmp      G_M000_IG26
 
G_M000_IG62:                ;; offset=0x06C2
       lea      r13, bword ptr [rbx+0x48]
       mov      rdi, r14
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LocalSlot():int:this]
       cmp      eax, dword ptr [r13+0x08]
       jae      G_M000_IG138
       mov      rdi, bword ptr [r13]
       mov      esi, eax
       lea      rdi, bword ptr [rdi+8*rsi]
       mov      bword ptr [rbp-0x120], rdi
       mov      rdi, rbx
       mov      rsi, r14
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Take(byref):System.Object:this]
       mov      rsi, rax
       mov      rdi, bword ptr [rbp-0x120]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       jmp      G_M000_IG26
 
G_M000_IG63:                ;; offset=0x070A
       mov      rdi, gword ptr [rbx+0x08]
       mov      rdi, gword ptr [rdi+0x10]
       not      esi
       mov      r11, 0x7BE47E052C28
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       mov      rdi, rax
       call     [Lokad.Lython.Runtime.LythonRuntime:RuntimeValue(System.Object):System.Object]
       mov      r13, rax
       jmp      G_M000_IG06
 
G_M000_IG64:                ;; offset=0x0732
       mov      rdi, gword ptr [rbx+0x08]
       cmp      esi, dword ptr [rdi+0x9C]
       jl       G_M000_IG134
       mov      rdi, 0x7BE47F987A68
       call     CORINFO_HELP_NEWSFAST
       mov      rbx, rax
       mov      rdi, rbx
       mov      rsi, 0x7BE47C20E590
       call     [System.InvalidOperationException:.ctor(System.String):this]
       mov      rdi, rbx
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG65:                ;; offset=0x0770
       mov      rdi, r12
       mov      esi, eax
       mov      r11, 0x7BE47E052BF0
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       mov      rdi, rax
       jmp      G_M000_IG07
 
G_M000_IG66:                ;; offset=0x078A
       mov      rdi, r14
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      dword ptr [rbp-0xB0], eax
       jmp      G_M000_IG16
 
G_M000_IG67:                ;; offset=0x079E
       mov      rdi, r14
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      edi, eax
       jmp      G_M000_IG19
 
G_M000_IG68:                ;; offset=0x07AE
       mov      rdi, r14
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       jmp      G_M000_IG23
 
G_M000_IG69:                ;; offset=0x07BC
       mov      esi, dword ptr [r14+0x10]
       mov      rdi, rbx
       xor      edx, edx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Read(int,int):System.Object:this]
       mov      r13, rax
       mov      esi, dword ptr [r14+0x0C]
       mov      rdi, rbx
       mov      edx, 1
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Read(int,int):System.Object:this]
       mov      r12, rax
       mov      rsi, r13
       mov      rdi, 0x7BE4809E8968
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       mov      r13, rax
       test     r13, r13
       je       G_M000_IG97
       mov      rdi, r13
       call     [Lokad.Lython.Runtime.PyDict:get_HasProtocolKeys():bool:this]
       test     eax, eax
       jne      G_M000_IG97
       mov      rsi, r12
       mov      rdi, 0x7BE4806CE6B0
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       mov      r12, rax
       test     r12, r12
       je       G_M000_IG97
       mov      rdi, r14
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LookupCacheIndex():int:this]
       test     eax, eax
       jl       SHORT G_M000_IG71
       cmp      gword ptr [r13+0x20], 0
       je       SHORT G_M000_IG71
       mov      rdi, gword ptr [rbx]
       mov      rsi, gword ptr [r14]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.PyExecutableFunction:GetLookupCaches(Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.LythonRuntime+ExecutableLookupCache[]:this]
       mov      gword ptr [rbp-0x118], rax
       mov      rdi, r14
 
G_M000_IG70:                ;; offset=0x085C
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LookupCacheIndex():int:this]
       mov      rdx, gword ptr [rbp-0x118]
       cmp      eax, dword ptr [rdx+0x08]
       jae      G_M000_IG138
       mov      r8d, eax
       lea      r8, [r8+2*r8]
       lea      rdx, bword ptr [rdx+8*r8+0x10]
       mov      r8, gword ptr [r14]
       mov      rcx, gword ptr [rbx+0x18]
       lea      r9, [rbp-0x40]
       mov      rsi, r12
       mov      rdi, r13
       call     [Lokad.Lython.Runtime.PyDict:TryReadRecordValue(Lokad.Lython.Runtime.Text.PyString,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,byref):bool:this]
       test     eax, eax
       je       SHORT G_M000_IG71
       mov      rdi, rbx
       mov      rsi, r14
       mov      rdx, gword ptr [rbp-0x40]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,System.Object):this]
       jmp      G_M000_IG26
 
G_M000_IG71:                ;; offset=0x08AE
       mov      rdi, r13
       call     [Lokad.Lython.Runtime.PyDict:get_HasProtocolKeys():bool:this]
       test     eax, eax
       jne      G_M000_IG97
       mov      rdx, gword ptr [r14]
       mov      rcx, gword ptr [rbx+0x18]
       mov      rdi, r13
       mov      rsi, r12
       call     [Lokad.Lython.Runtime.LythonRuntime:ReadSubscriptValue(System.Object,System.Object,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):System.Object]
       mov      rdx, rax
       mov      rsi, r14
       mov      rdi, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,System.Object):this]
       jmp      G_M000_IG26
 
G_M000_IG72:                ;; offset=0x08E6
       mov      esi, dword ptr [r14+0x10]
       mov      rdi, rbx
       xor      edx, edx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Read(int,int):System.Object:this]
       mov      r13, rax
       cmp      dword ptr [r14+0x08], 0
       je       G_M000_IG74
       mov      rsi, r13
       mov      rdi, 0x7BE4806D9A60
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       jne      SHORT G_M000_IG73
       mov      rsi, r13
       mov      rdi, 0x7BE47F2A6558
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       jne      SHORT G_M000_IG73
       mov      rsi, r13
       mov      rdi, 0x7BE47F2735C8
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       sete     r12b
       movzx    r12, r12b
       jmp      SHORT G_M000_IG75
 
G_M000_IG73:                ;; offset=0x0950
       mov      edi, dword ptr [r14+0x08]
       mov      r12, gword ptr [rbx+0x18]
       mov      rax, gword ptr [r14]
       mov      gword ptr [rbp-0xE8], rax
       call     [Lokad.Lython.Runtime.LythonRuntime:MapExecutableUnary(int):int]
       mov      edi, eax
       mov      rsi, r13
       mov      rdx, r12
       mov      rcx, gword ptr [rbp-0xE8]
       call     [Lokad.Lython.Runtime.LythonRuntime:EvaluateUnaryOperator(int,System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):System.Object]
       mov      rdx, rax
       mov      rsi, r14
       mov      rdi, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,System.Object):this]
       jmp      G_M000_IG26
 
G_M000_IG74:                ;; offset=0x0991
       mov      rdi, r13
       call     [Lokad.Lython.Runtime.LythonRuntime:CanUseNativeTruth(System.Object):bool]
       test     eax, eax
       sete     r12b
       movzx    r12, r12b
 
G_M000_IG75:                ;; offset=0x09A4
       test     r12d, r12d
       jne      G_M000_IG97
       jmp      SHORT G_M000_IG73
 
G_M000_IG76:                ;; offset=0x09AF
       mov      esi, dword ptr [r14+0x10]
       mov      rdi, rbx
       xor      edx, edx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Read(int,int):System.Object:this]
       mov      r13, rax
       mov      esi, dword ptr [r14+0x0C]
       mov      rdi, rbx
       mov      edx, 1
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Read(int,int):System.Object:this]
       mov      r12, rax
       cmp      dword ptr [r14+0x1C], 48
       sete     al
       movzx    rax, al
       mov      dword ptr [rbp-0x44], eax
       test     eax, eax
       jne      G_M000_IG81
       mov      rdi, gword ptr [rbx+0x08]
       mov      rsi, bword ptr [rbx+0x48]
       mov      edx, dword ptr [rbx+0x50]
       mov      rcx, gword ptr [rbx+0x18]
       mov      gword ptr [rsp], rcx
       lea      rcx, [rbp-0x50]
       mov      qword ptr [rsp+0x08], rcx
       lea      rcx, [rbp-0x58]
       mov      qword ptr [rsp+0x10], rcx
       mov      ecx, dword ptr [rbx+0x38]
       mov      r8, r13
       mov      r9, r12
       call     [Lokad.Lython.Runtime.LythonRuntime:TryIntegerChain(Lokad.Lython.Frontend.ExecutableCodeObject,System.ReadOnlySpan`1[System.Object],int,System.Object,System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,byref):bool]
       test     eax, eax
       je       SHORT G_M000_IG78
       mov      edi, dword ptr [rbp-0x50]
       mov      dword ptr [rbx+0x38], edi
       mov      rdi, gword ptr [rbx+0x08]
       mov      rdi, gword ptr [rdi+0x50]
       mov      eax, dword ptr [rdi+0x08]
       cmp      dword ptr [rbp-0x50], eax
       jae      G_M000_IG138
       mov      eax, dword ptr [rbp-0x50]
       shl      rax, 5
       lea      r14, bword ptr [rdi+rax+0x10]
       mov      rdi, 0x7BE4806D9A60
       call     CORINFO_HELP_NEWSFAST
       mov      r13, rax
       lea      r12, bword ptr [r13+0x08]
       mov      rdi, qword ptr [rbp-0x58]
       call     [System.Numerics.BigInteger:op_Implicit(long):System.Numerics.BigInteger]
 
G_M000_IG77:                ;; offset=0x0A6A
       mov      dword ptr [rbp-0xC0], edx
       mov      rdi, r12
       mov      rsi, rax
       call     CORINFO_HELP_ASSIGN_REF
       mov      edx, dword ptr [rbp-0xC0]
       mov      dword ptr [r12+0x08], edx
       mov      rdx, r13
       mov      rdi, rbx
       mov      rsi, r14
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,System.Object):this]
       jmp      G_M000_IG26
 
G_M000_IG78:                ;; offset=0x0A9A
       mov      rdi, r14
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_BinaryOperator():int:this]
       mov      edi, eax
       mov      r8, gword ptr [r14]
       mov      rcx, gword ptr [rbx+0x18]
       lea      r9, [rbp-0x60]
       mov      rsi, r13
       mov      rdx, r12
       call     [Lokad.Lython.Runtime.LythonRuntime:TryEvaluateScalarComparison(int,System.Object,System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,byref):bool]
       test     eax, eax
       je       SHORT G_M000_IG82
       movzx    rdi, byte  ptr [rbp-0x60]
       test     edi, edi
       jne      SHORT G_M000_IG79
       mov      rdi, 0x7BDCA18034C8
       mov      rdx, gword ptr [rdi]
       jmp      SHORT G_M000_IG80
 
G_M000_IG79:                ;; offset=0x0AD8
       mov      rdx, 0x7BDCA18034C0
       mov      rdx, gword ptr [rdx]
 
G_M000_IG80:                ;; offset=0x0AE5
       mov      rdi, rbx
       mov      rsi, r14
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,System.Object):this]
       jmp      G_M000_IG26
 
G_M000_IG81:                ;; offset=0x0AF6
       mov      edi, dword ptr [r14+0x08]
       call     [Lokad.Lython.Runtime.LythonRuntime:AugmentedBinaryOperator(int):int]
       jmp      SHORT G_M000_IG83
 
G_M000_IG82:                ;; offset=0x0B02
       mov      rdi, r14
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_BinaryOperator():int:this]
 
G_M000_IG83:                ;; offset=0x0B0B
       mov      edi, eax
       mov      rsi, r13
       mov      rdx, r12
       call     [Lokad.Lython.Runtime.LythonRuntime:CanUseNativeBinary(int,System.Object,System.Object):bool]
       test     eax, eax
       je       G_M000_IG97
       cmp      dword ptr [rbp-0x44], 0
       je       G_M000_IG86
       mov      rsi, r13
       mov      rdi, 0x7BE4806D9A60
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       jne      SHORT G_M000_IG84
       mov      rsi, r13
       mov      rdi, 0x7BE47F2A6558
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       jne      SHORT G_M000_IG84
       mov      rsi, r13
       mov      rdi, 0x7BE47F2735C8
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       G_M000_IG97
 
G_M000_IG84:                ;; offset=0x0B74
       mov      rsi, r12
       mov      rdi, 0x7BE4806D9A60
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       jne      SHORT G_M000_IG85
       mov      rsi, r12
       mov      rdi, 0x7BE47F2A6558
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       jne      SHORT G_M000_IG85
       mov      rsi, r12
       mov      rdi, 0x7BE47F2735C8
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       G_M000_IG97
 
G_M000_IG85:                ;; offset=0x0BBD
       mov      edx, dword ptr [r14+0x08]
       mov      rcx, gword ptr [rbx+0x18]
       mov      r8, gword ptr [r14]
       mov      rdi, r13
       mov      rsi, r12
       call     [Lokad.Lython.Runtime.LythonRuntime:EvaluateAugmentedBuiltin(System.Object,System.Object,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):System.Object]
       jmp      SHORT G_M000_IG87
 
G_M000_IG86:                ;; offset=0x0BD6
       mov      rdi, r14
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_BinaryOperator():int:this]
       mov      edi, eax
       mov      rcx, gword ptr [rbx+0x18]
       mov      r8, gword ptr [r14]
       mov      rsi, r13
       mov      rdx, r12
       call     [Lokad.Lython.Runtime.LythonRuntime:EvaluateBinaryOperator(int,System.Object,System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):System.Object]
 
G_M000_IG87:                ;; offset=0x0BF4
       mov      rdi, rbx
       mov      rsi, r14
       mov      rdx, rax
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,System.Object):this]
       jmp      G_M000_IG26
 
G_M000_IG88:                ;; offset=0x0C08
       mov      esi, dword ptr [r14+0x10]
       mov      rdi, rbx
       xor      edx, edx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Read(int,int):System.Object:this]
       mov      r13, rax
       mov      esi, dword ptr [r14+0x0C]
       mov      rdi, rbx
       mov      edx, 1
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Read(int,int):System.Object:this]
       mov      r12, rax
       mov      rdi, r14
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_BinaryOperator():int:this]
       mov      edi, eax
       mov      r8, gword ptr [r14]
       mov      rcx, gword ptr [rbx+0x18]
       lea      r9, [rbp-0x68]
       mov      rsi, r13
       mov      rdx, r12
       call     [Lokad.Lython.Runtime.LythonRuntime:TryEvaluateScalarComparison(int,System.Object,System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,byref):bool]
       test     eax, eax
       je       G_M000_IG97
       mov      rdi, r14
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      esi, eax
       mov      rdi, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Trim(int):this]
       mov      rdi, gword ptr [rbx+0x18]
       mov      rax, gword ptr [r14]
       mov      rdi, gword ptr [rdi+0xA0]
       mov      rcx, gword ptr [rdi+0x88]
       mov      rcx, gword ptr [rcx+0x20]
       test     rcx, rcx
       jne      G_M000_IG136
       mov      rdi, gword ptr [rdi+0x178]
       test     rdi, rdi
       je       SHORT G_M000_IG89
       cmp      dword ptr [rdi+0x20], 0
       setne    dil
       movzx    rdi, dil
       test     edi, edi
       jne      SHORT G_M000_IG90
 
G_M000_IG89:                ;; offset=0x0CAB
       cmp      byte  ptr [rbp-0x68], 0
       jne      G_M000_IG26
       jmp      SHORT G_M000_IG91
 
G_M000_IG90:                ;; offset=0x0CB7
       mov      rdi, rax
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionCanceled(Lokad.Lython.LythonSourceSpan)]
       jmp      SHORT G_M000_IG89
 
G_M000_IG91:                ;; offset=0x0CC2
       mov      rdi, r14
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_TargetIndex():int:this]
       mov      dword ptr [rbx+0x38], eax
       jmp      G_M000_IG27
 
G_M000_IG92:                ;; offset=0x0CD3
       mov      esi, dword ptr [r14+0x10]
       mov      rdi, rbx
       xor      edx, edx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Read(int,int):System.Object:this]
       mov      r13, rax
       mov      rdi, r13
       call     [Lokad.Lython.Runtime.LythonRuntime:CanUseNativeTruth(System.Object):bool]
       test     eax, eax
       je       G_M000_IG97
       mov      rdi, rbx
       mov      rsi, r14
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Take(byref):System.Object:this]
       mov      rdx, gword ptr [r14]
       mov      rsi, gword ptr [rbx+0x18]
       mov      rdi, r13
       call     [Lokad.Lython.Runtime.LythonRuntime:IsTruthy(System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):bool]
       test     eax, eax
       jne      G_M000_IG26
       jmp      SHORT G_M000_IG91
 
G_M000_IG93:                ;; offset=0x0D1C
       mov      rdi, r14
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_DiscardIterator():bool:this]
       test     eax, eax
       je       SHORT G_M000_IG91
       mov      esi, dword ptr [rbx+0x3C]
       dec      esi
       mov      rdi, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Trim(int):this]
       jmp      SHORT G_M000_IG91
 
G_M000_IG94:                ;; offset=0x0D39
       mov      esi, dword ptr [r14+0x10]
       mov      rdi, rbx
       xor      edx, edx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Read(int,int):System.Object:this]
       mov      r13, rax
       mov      rsi, r13
       mov      rdi, 0x7BE480A49120
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG95
       mov      rdi, rbx
       mov      rsi, r14
       mov      rdx, r13
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,System.Object):this]
       jmp      G_M000_IG26
 
G_M000_IG95:                ;; offset=0x0D76
       mov      rsi, r13
       mov      rdi, 0x7BE4809ED748
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       jne      G_M000_IG96
       mov      rsi, r13
       mov      rdi, 0x7BE4806CF140
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       jne      SHORT G_M000_IG96
       mov      rsi, r13
       mov      rdi, 0x7BE480A2D378
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       jne      SHORT G_M000_IG96
       mov      rsi, r13
       mov      rdi, 0x7BE4806D3410
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       jne      SHORT G_M000_IG96
       mov      rsi, r13
       mov      rdi, 0x7BE4806CE6B0
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       jne      SHORT G_M000_IG96
       mov      rsi, r13
       mov      rdi, 0x7BE4809E8968
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       jne      SHORT G_M000_IG96
       mov      rsi, r13
       mov      rdi, 0x7BE480A2CEC0
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG97
 
G_M000_IG96:                ;; offset=0x0E1B
       mov      rdx, gword ptr [rbx+0x18]
       mov      rsi, gword ptr [r14]
       mov      rdi, r13
       call     [Lokad.Lython.Runtime.PyIteration+Cursor:Create(System.Object,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):Lokad.Lython.Runtime.PyIteration+Cursor]
       mov      rdx, rax
       mov      rsi, r14
       mov      rdi, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,System.Object):this]
       jmp      G_M000_IG26
 
G_M000_IG97:                ;; offset=0x0E3F
       xor      eax, eax
 
G_M000_IG98:                ;; offset=0x0E41
       vzeroupper 
       add      rsp, 280
       pop      rbx
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG99:                ;; offset=0x0E56
       lea      rsi, bword ptr [rbx+0x48]
       mov      edi, dword ptr [r14+0x10]
       cmp      edi, dword ptr [rsi+0x08]
       jae      G_M000_IG138
       mov      rsi, bword ptr [rsi]
       mov      r13, gword ptr [rsi+8*rdi]
       mov      rsi, r13
       mov      rdi, 0x7BE480A49120
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       jne      SHORT G_M000_IG101
       mov      rsi, r13
       mov      rdi, 0x7BE4809EAA08
       call     CORINFO_HELP_CHKCASTCLASS
       mov      r13, rax
       cmp      byte  ptr [r13], r13b
       mov      rdi, r13
       call     [Lokad.Lython.Runtime.PyIteration+Cursor:CheckExecution():this]
       lea      rsi, [rbp-0x80]
       mov      rdi, r13
       call     [Lokad.Lython.Runtime.PyIteration+Cursor:TryMoveNextCore(byref):bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG100
       xor      r13, r13
       xor      r12d, r12d
       jmp      SHORT G_M000_IG102
 
G_M000_IG100:                ;; offset=0x0EC0
       mov      rdi, gword ptr [rbp-0x80]
       call     [Lokad.Lython.Runtime.PyIterationResult:Yield(System.Object):Lokad.Lython.Runtime.PyIterationResult]
       mov      r13, rax
       mov      r12d, edx
       jmp      SHORT G_M000_IG102
 
G_M000_IG101:                ;; offset=0x0ED2
       mov      rdi, rax
       call     [Lokad.Lython.Runtime.Text.PyStringOps+CasedWhitespaceIteration:MoveNext():Lokad.Lython.Runtime.PyIterationResult:this]
       mov      r13, rax
       mov      r12d, edx
 
G_M000_IG102:                ;; offset=0x0EE1
       mov      gword ptr [rbp-0x78], r13
       mov      byte  ptr [rbp-0x70], r12b
       cmp      byte  ptr [rbp-0x70], 0
       jne      SHORT G_M000_IG103
       mov      esi, dword ptr [r14+0x10]
       mov      rdi, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Trim(int):this]
       jmp      G_M000_IG91
 
G_M000_IG103:                ;; offset=0x0F01
       lea      rdi, [rbp-0x78]
       call     [Lokad.Lython.Runtime.PyIterationResult:get_Value():System.Object:this]
       mov      rdx, rax
       mov      rsi, r14
       mov      rdi, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,System.Object):this]
       jmp      G_M000_IG26
 
G_M000_IG104:                ;; offset=0x0F1F
       mov      rdi, rbx
       mov      rsi, r14
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:TryReturnUnpackedTuple(byref):bool:this]
       test     eax, eax
       jne      G_M000_IG36
       mov      rdi, r14
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ItemCount():int:this]
       test     eax, eax
       je       G_M000_IG105
       lea      r13, bword ptr [rbx+0x48]
       mov      r12d, dword ptr [r14+0x10]
       mov      rdi, r14
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ItemCount():int:this]
       mov      dword ptr [rbp-0xB8], eax
       mov      edi, r12d
       mov      ecx, eax
       add      rdi, rcx
       mov      ecx, dword ptr [r13+0x08]
       cmp      rdi, rcx
       ja       G_M000_IG137
       mov      rdi, bword ptr [r13]
       mov      ecx, r12d
       lea      r13, bword ptr [rdi+8*rcx]
       mov      rdi, gword ptr [rbx+0x18]
       mov      rdi, gword ptr [rdi+0xA0]
       mov      r12, gword ptr [rdi+0x88]
       mov      rdi, 0x7BE4806CF140
       call     CORINFO_HELP_NEWSFAST
       mov      gword ptr [rbp-0xD0], rax
       mov      r8, gword ptr [r14]
       mov      rsi, r13
       mov      edx, dword ptr [rbp-0xB8]
       mov      r9, gword ptr [rbx+0x18]
       mov      rdi, rax
       mov      rcx, r12
       call     [Lokad.Lython.Runtime.PyTuple:.ctor(System.ReadOnlySpan`1[System.Object],Lokad.Lython.Runtime.MemoryGovernor,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):this]
       mov      r13, gword ptr [rbp-0xD0]
       jmp      SHORT G_M000_IG106
 
G_M000_IG105:                ;; offset=0x0FC8
       mov      rsi, 0x7BDCA1801680
       mov      r13, gword ptr [rsi]
 
G_M000_IG106:                ;; offset=0x0FD5
       mov      esi, dword ptr [r14+0x10]
       mov      rdi, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Trim(int):this]
       mov      rdi, rbx
       mov      rsi, r14
       mov      rdx, r13
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,System.Object):this]
       jmp      G_M000_IG26
 
G_M000_IG107:                ;; offset=0x0FF6
       mov      rdi, r14
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ItemCount():int:this]
       movsxd   rdi, eax
       imul     r13, rdi, 80
       jo       G_M000_IG139
       add      r13, 64
       jo       G_M000_IG139
       mov      rdi, gword ptr [rbx+0x18]
       mov      rdi, gword ptr [rdi+0xA0]
       mov      r12, gword ptr [rdi+0x88]
       mov      rax, gword ptr [r14]
       mov      gword ptr [rbp-0xF0], rax
       cmp      byte  ptr [r12], r12b
       mov      rdi, 0x7BE48034AE70
       call     CORINFO_HELP_NEWSFAST
       mov      gword ptr [rbp-0xF8], rax
       lea      rdi, bword ptr [rax+0x08]
       mov      rsi, r12
       call     CORINFO_HELP_ASSIGN_REF
       mov      rdi, gword ptr [rbp-0xF8]
       mov      rsi, r13
       mov      rdx, gword ptr [rbp-0xF0]
       call     [Lokad.Lython.Runtime.MemoryGovernor+TemporaryMemoryReservation:Grow(long,Lokad.Lython.LythonSourceSpan):this]
       mov      r12, gword ptr [rbp-0xF8]
       mov      gword ptr [rbp-0xC8], r12
 
G_M000_IG108:                ;; offset=0x107D
       mov      rdi, gword ptr [rbx+0x18]
       mov      rax, gword ptr [r14]
       mov      rdi, gword ptr [rdi+0xA0]
       mov      rcx, gword ptr [rdi+0x88]
       mov      rcx, gword ptr [rcx+0x20]
       test     rcx, rcx
       je       SHORT G_M000_IG109
       mov      rdi, rcx
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG109:                ;; offset=0x10A4
       mov      rdi, gword ptr [rdi+0x178]
       test     rdi, rdi
       je       SHORT G_M000_IG110
       cmp      dword ptr [rdi+0x20], 0
       setne    dil
       movzx    rdi, dil
       test     edi, edi
       jne      SHORT G_M000_IG111
 
G_M000_IG110:                ;; offset=0x10C0
       lea      rax, bword ptr [rbx+0x48]
       mov      bword ptr [rbp-0xD8], rax
       mov      ecx, dword ptr [r14+0x10]
       mov      dword ptr [rbp-0xAC], ecx
       mov      rdi, r14
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ItemCount():int:this]
       mov      dword ptr [rbp-0xBC], eax
       mov      esi, dword ptr [rbp-0xAC]
       mov      edi, esi
       mov      ecx, eax
       add      rdi, rcx
       mov      rcx, bword ptr [rbp-0xD8]
       mov      edx, dword ptr [rcx+0x08]
       cmp      rdi, rdx
       jbe      SHORT G_M000_IG113
       jmp      SHORT G_M000_IG112
 
G_M000_IG111:                ;; offset=0x1102
       mov      rdi, rax
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionCanceled(Lokad.Lython.LythonSourceSpan)]
       jmp      SHORT G_M000_IG110
 
G_M000_IG112:                ;; offset=0x110D
       call     [System.ThrowHelper:ThrowArgumentOutOfRangeException()]
       int3     
 
G_M000_IG113:                ;; offset=0x1114
       mov      rdi, bword ptr [rcx]
       mov      esi, esi
       lea      rcx, bword ptr [rdi+8*rsi]
       mov      bword ptr [rbp-0x110], rcx
       test     eax, eax
       jne      SHORT G_M000_IG114
       mov      rax, 0x7BDCA1800F80
       mov      rax, gword ptr [rax]
       mov      gword ptr [rbp-0x100], rax
       jmp      SHORT G_M000_IG115
 
G_M000_IG114:                ;; offset=0x113E
       movsxd   rsi, eax
       mov      rdi, 0x7BE47F2727A0
       call     CORINFO_HELP_NEWARR_1_PTR
       mov      gword ptr [rbp-0x108], rax
       lea      rdi, bword ptr [rax+0x10]
       mov      edx, dword ptr [rbp-0xBC]
       shl      rdx, 3
       mov      rsi, bword ptr [rbp-0x110]
       call     [System.Buffer:BulkMoveWithWriteBarrier(byref,byref,nuint)]
       mov      rax, gword ptr [rbp-0x108]
       mov      gword ptr [rbp-0x100], rax
 
G_M000_IG115:                ;; offset=0x1180
       mov      esi, dword ptr [r14+0x10]
       mov      rdi, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Trim(int):this]
       mov      rdi, r12
       mov      rsi, r13
       call     [Lokad.Lython.Runtime.MemoryGovernor+TemporaryMemoryReservation:Commit(long):this]
       mov      rsi, gword ptr [rbx+0x18]
       mov      rsi, gword ptr [rsi+0xA0]
       mov      rsi, gword ptr [rsi+0x88]
       mov      rdx, gword ptr [r14]
       mov      rdi, gword ptr [rbp-0x100]
       call     [Lokad.Lython.Runtime.PyList:FromTransferredArray(System.Object[],Lokad.Lython.Runtime.MemoryGovernor,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.PyList]
       mov      rdx, rax
       mov      rsi, r14
       mov      rdi, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,System.Object):this]
       nop      
 
G_M000_IG116:                ;; offset=0x11CB
       mov      rdi, r12
       call     [Lokad.Lython.Runtime.MemoryGovernor+TemporaryMemoryReservation:Dispose():this]
       jmp      G_M000_IG26
 
G_M000_IG117:                ;; offset=0x11D9
       mov      rdi, rbx
       mov      rsi, r14
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Format(byref):bool:this]
       test     eax, eax
       jne      G_M000_IG26
       jmp      G_M000_IG97
 
G_M000_IG118:                ;; offset=0x11F2
       mov      rdi, r14
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       lea      r13d, [rax+0x01]
       mov      rdi, r14
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      r12d, eax
       mov      esi, dword ptr [r14+0x10]
       mov      rdi, rbx
       xor      edx, edx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Read(int,int):System.Object:this]
       mov      rcx, rax
       mov      esi, r13d
       mov      edx, r12d
       mov      rdi, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Put(int,int,System.Object):this]
       jmp      G_M000_IG26
 
G_M000_IG119:                ;; offset=0x1231
       mov      esi, dword ptr [r14+0x10]
       mov      rdi, rbx
       xor      edx, edx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Read(int,int):System.Object:this]
       mov      rdi, r14
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      esi, eax
       mov      rdi, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Trim(int):this]
       jmp      G_M000_IG26
 
G_M000_IG120:                ;; offset=0x1259
       mov      rsi, bword ptr [rbp-0x90]
       mov      eax, edi
       lea      rsi, bword ptr [rsi+2*rax]
       mov      eax, dword ptr [rbp-0x88]
       sub      eax, edi
       cmp      eax, 26
       jb       SHORT G_M000_IG121
       vmovups  ymm0, ymmword ptr [reloc @RWD192]
       vmovups  ymmword ptr [rsi], ymm0
       vmovups  xmm0, xmmword ptr [reloc @RWD224]
       vmovups  xmmword ptr [rsi+0x20], xmm0
       mov      dword ptr [rsi+0x30], 0x20003A
       mov      edi, dword ptr [rbp-0x98]
       add      edi, 26
       mov      dword ptr [rbp-0x98], edi
       jmp      SHORT G_M000_IG122
 
G_M000_IG121:                ;; offset=0x12A4
       lea      rdi, [rbp-0xA8]
       mov      rsi, 0x7BE47C254E80
       call     [System.Runtime.CompilerServices.DefaultInterpolatedStringHandler:GrowThenCopyString(System.String):this]
 
G_M000_IG122:                ;; offset=0x12BB
       mov      esi, dword ptr [r14+0x1C]
       lea      rdi, [rbp-0xA8]
       call     [System.Runtime.CompilerServices.DefaultInterpolatedStringHandler:AppendFormatted[int](int):this]
       mov      rdi, 0x7BE47F987A68
       call     CORINFO_HELP_NEWSFAST
       mov      r14, rax
       lea      rdi, [rbp-0xA8]
       call     [System.Runtime.CompilerServices.DefaultInterpolatedStringHandler:ToStringAndClear():System.String:this]
       mov      rsi, rax
       mov      rdi, r14
       call     [System.InvalidOperationException:.ctor(System.String):this]
       mov      rdi, r14
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG123:                ;; offset=0x1300
       mov      rdi, rcx
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG124:                ;; offset=0x1309
       lea      rdi, [rbp-0xA8]
       mov      esi, 26
       mov      edx, 1
       call     [System.Runtime.CompilerServices.DefaultInterpolatedStringHandler:.ctor(int,int):this]
       mov      edi, dword ptr [rbp-0x98]
       cmp      edi, dword ptr [rbp-0x88]
       jbe      G_M000_IG120
       jmp      G_M000_IG137
 
G_M000_IG125:                ;; offset=0x1337
       mov      rsi, gword ptr [rbx+0x08]
       mov      esi, dword ptr [rsi+0x9C]
       mov      rdi, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Trim(int):this]
       jmp      G_M000_IG36
 
G_M000_IG126:                ;; offset=0x134F
       mov      rdi, gword ptr [rbx+0x08]
       mov      rdi, gword ptr [rdi+0x10]
       not      esi
       mov      r11, 0x7BE47E052C10
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       mov      rdi, rax
       call     [Lokad.Lython.Runtime.LythonRuntime:RuntimeValue(System.Object):System.Object]
       mov      gword ptr [rbp-0xE0], rax
       jmp      G_M000_IG32
 
G_M000_IG127:                ;; offset=0x137B
       mov      rdi, gword ptr [rbx+0x08]
       cmp      esi, dword ptr [rdi+0x9C]
       jge      SHORT G_M000_IG128
       mov      rdi, gword ptr [rbx+0x08]
       mov      rdi, gword ptr [rdi+0x20]
       mov      r11, 0x7BE47E052C08
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       mov      r15, rax
       mov      rdi, gword ptr [rbx+0x08]
       mov      esi, dword ptr [rbx+0x38]
       xor      edx, edx
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:OperandReadSpan(int,int):Lokad.Lython.LythonSourceSpan:this]
       mov      rsi, rax
       mov      rdi, r15
       call     [Lokad.Lython.Runtime.RuntimeErrors:UnboundLocalVariable(System.String,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.LythonRuntimeException]
       mov      rdi, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG128:                ;; offset=0x13C5
       mov      rdi, 0x7BE47F987A68
       call     CORINFO_HELP_NEWSFAST
       mov      rbx, rax
       mov      rdi, rbx
       mov      rsi, 0x7BE47C20E590
       call     [System.InvalidOperationException:.ctor(System.String):this]
       mov      rdi, rbx
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG129:                ;; offset=0x13F3
       lea      rsi, bword ptr [rbx+0x48]
       cmp      r15d, dword ptr [rsi+0x08]
       jae      G_M000_IG138
       mov      rsi, bword ptr [rsi]
       mov      edi, r15d
       mov      rsi, gword ptr [rsi+8*rdi]
       mov      rdi, 0x7BE4809E4048
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG130
       lea      rdi, bword ptr [rbx+0x48]
       cmp      r15d, dword ptr [rdi+0x08]
       jae      G_M000_IG138
       mov      rdi, bword ptr [rdi]
       mov      ecx, r15d
       xor      rdx, rdx
       mov      gword ptr [rdi+8*rcx], rdx
       mov      rdi, rax
       mov      rax, qword ptr [rax]
       mov      rax, qword ptr [rax+0x40]
       call     [rax+0x20]Lokad.Lython.Runtime.ExecutableTemporaryValue:Dispose():this
 
G_M000_IG130:                ;; offset=0x1446
       dec      r15d
       cmp      r15d, r14d
       jge      SHORT G_M000_IG129
       jmp      G_M000_IG35
 
G_M000_IG131:                ;; offset=0x1453
       mov      rdi, r14
       mov      rsi, 0x7BE47C2528B8
       call     [Lokad.Lython.Frontend.ExecutableInstruction:InvalidOperand(System.String):System.InvalidOperationException:this]
       mov      rdi, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG132:                ;; offset=0x146F
       mov      rdi, gword ptr [rbx+0x08]
       mov      rdi, gword ptr [rdi+0x20]
       mov      r11, 0x7BE47E052C18
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       mov      rdi, rax
       mov      rsi, r13
       call     [Lokad.Lython.Runtime.RuntimeErrors:UnboundLocalVariable(System.String,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.LythonRuntimeException]
       mov      rdi, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG133:                ;; offset=0x1499
       mov      rdi, rcx
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG134:                ;; offset=0x14A2
       mov      rdi, gword ptr [rbx+0x08]
       mov      rdi, gword ptr [rdi+0x20]
       mov      r11, 0x7BE47E052C20
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       mov      r15, rax
       mov      rdi, gword ptr [rbx+0x08]
       mov      esi, dword ptr [rbx+0x38]
       xor      edx, edx
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:OperandReadSpan(int,int):Lokad.Lython.LythonSourceSpan:this]
       mov      rsi, rax
       mov      rdi, r15
       call     [Lokad.Lython.Runtime.RuntimeErrors:UnboundLocalVariable(System.String,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.LythonRuntimeException]
       mov      rdi, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG135:                ;; offset=0x14E0
       call     [System.ThrowHelper:ThrowArgumentOutOfRange_IndexMustBeLessException()]
       int3     
 
G_M000_IG136:                ;; offset=0x14E7
       mov      rdi, rcx
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG137:                ;; offset=0x14F0
       call     [System.ThrowHelper:ThrowArgumentOutOfRangeException()]
       int3     
 
G_M000_IG138:                ;; offset=0x14F7
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG139:                ;; offset=0x14FD
       call     CORINFO_HELP_OVERFLOW
       int3     
 
G_M000_IG140:                ;; offset=0x1503
       sub      rsp, 24
 
G_M000_IG141:                ;; offset=0x1507
       mov      rdi, gword ptr [rbp-0xC8]
       call     [Lokad.Lython.Runtime.MemoryGovernor+TemporaryMemoryReservation:Dispose():this]
       nop      
 
G_M000_IG142:                ;; offset=0x1515
       vzeroupper 
       add      rsp, 24
       ret      
 
RWD00  	dd	00000058h ; case G_M000_IG05
       	dd	000012B7h ; case G_M000_IG124
       	dd	00000670h ; case G_M000_IG62
       	dd	0000061Ch ; case G_M000_IG61
       	dd	000012B7h ; case G_M000_IG124
       	dd	000012B7h ; case G_M000_IG124
       	dd	000011A0h ; case G_M000_IG118
       	dd	000011DFh ; case G_M000_IG119
       	dd	00000FA4h ; case G_M000_IG107
       	dd	00000ECDh ; case G_M000_IG104
       	dd	000012B7h ; case G_M000_IG124
       	dd	000012B7h ; case G_M000_IG124
       	dd	000012B7h ; case G_M000_IG124
       	dd	000012B7h ; case G_M000_IG124
       	dd	000012B7h ; case G_M000_IG124
       	dd	000012B7h ; case G_M000_IG124
       	dd	00000CE7h ; case G_M000_IG94
       	dd	00000E04h ; case G_M000_IG99
       	dd	0000002Eh ; case G_M000_IG03
       	dd	0000076Ah ; case G_M000_IG69
       	dd	000012B7h ; case G_M000_IG124
       	dd	000012B7h ; case G_M000_IG124
       	dd	0000095Dh ; case G_M000_IG76
       	dd	0000095Dh ; case G_M000_IG76
       	dd	00000894h ; case G_M000_IG72
       	dd	00000C70h ; case G_M000_IG91
       	dd	00000C81h ; case G_M000_IG92
       	dd	00000BB6h ; case G_M000_IG88
       	dd	000012B7h ; case G_M000_IG124
       	dd	000012B7h ; case G_M000_IG124
       	dd	000012B7h ; case G_M000_IG124
       	dd	000012B7h ; case G_M000_IG124
       	dd	000012B7h ; case G_M000_IG124
       	dd	00000285h ; case G_M000_IG31
       	dd	000012E5h ; case G_M000_IG125
       	dd	000012E5h ; case G_M000_IG125
       	dd	000012B7h ; case G_M000_IG124
       	dd	000012B7h ; case G_M000_IG124
       	dd	00000CCAh ; case G_M000_IG93
       	dd	00001187h ; case G_M000_IG117
       	dd	00001187h ; case G_M000_IG117
       	dd	00001187h ; case G_M000_IG117
       	dd	00001187h ; case G_M000_IG117
       	dd	00001187h ; case G_M000_IG117
RWD176 	dd	0000042Ch ; case G_M000_IG52
       	dd	00000365h ; case G_M000_IG41
       	dd	000005AEh ; case G_M000_IG59
       	dd	00000567h ; case G_M000_IG58
RWD192 	dq	00780065006E0055h, 0074006300650070h, 0069002000640065h, 006E0069006C006Eh
RWD224 	dq	0070006F00200065h, 00650064006F0063h

; Total bytes of code 5405

; Assembly listing for method Lokad.Lython.LythonCompiledScript:RunCore(Lokad.Lython.ILythonHost,Lokad.Lython.LythonRunOptions):Lokad.Lython.LythonExecutionResult:this (Instrumented Tier0)
; Emitting BLENDED_CODE for x64 + VEX + EVEX on Unix
; Instrumented Tier0 code
; rbp based frame
; fully interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 272
       lea      rbp, [rsp+0x110]
       xor      eax, eax
       mov      qword ptr [rbp-0x108], rax
       vxorps   xmm8, xmm8, xmm8
       vmovdqu32 zmmword ptr [rbp-0x100], zmm8
       vmovdqu32 zmmword ptr [rbp-0xC0], zmm8
       vmovdqu32 zmmword ptr [rbp-0x80], zmm8
       vmovdqu  ymmword ptr [rbp-0x40], ymm8
       mov      qword ptr [rbp-0x20], rax
       mov      gword ptr [rbp-0x08], rdi
       mov      gword ptr [rbp-0x10], rsi
       mov      gword ptr [rbp-0x18], rdx
 
G_M000_IG02:                ;; offset=0x0048
       mov      rax, gword ptr [rbp-0x08]
       mov      rax, gword ptr [rax+0x08]
       mov      gword ptr [rbp-0x58], rax
       mov      rax, gword ptr [rbp-0x58]
       mov      gword ptr [rbp-0x60], rax
       cmp      gword ptr [rbp-0x58], 0
       jne      SHORT G_M000_IG04
 
G_M000_IG03:                ;; offset=0x0063
       mov      rdi, 0x7BE47FE66F18
       call     CORINFO_HELP_NEWSFAST
       mov      gword ptr [rbp-0xA8], rax
       mov      rdi, gword ptr [rbp-0xA8]
       mov      rsi, 0x7BE47C253300
       call     [System.ObjectDisposedException:.ctor(System.String):this]
       mov      rdi, gword ptr [rbp-0xA8]
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG04:                ;; offset=0x009D
       mov      rax, gword ptr [rbp-0x60]
       mov      gword ptr [rbp-0x20], rax
       cmp      gword ptr [rbp-0x18], 0
       jne      SHORT G_M000_IG05
       mov      rdi, 0x7BE480D60090
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, 0x7BE47FFC6A60
       call     CORINFO_HELP_NEWSFAST
       mov      gword ptr [rbp-0xA0], rax
       mov      rdi, gword ptr [rbp-0xA0]
       call     [Lokad.Lython.LythonRunOptions:.ctor():this]
       mov      rax, gword ptr [rbp-0xA0]
       mov      gword ptr [rbp-0x18], rax
 
G_M000_IG05:                ;; offset=0x00E9
       mov      rdi, gword ptr [rbp-0x18]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.LythonRunOptions:get_MemoryBudget():Lokad.Lython.ILythonMemoryBudget:this]
       mov      gword ptr [rbp-0x68], rax
       mov      rax, gword ptr [rbp-0x68]
       mov      gword ptr [rbp-0x70], rax
       cmp      gword ptr [rbp-0x68], 0
       jne      SHORT G_M000_IG06
       mov      rax, gword ptr [rbp-0x08]
       mov      rax, gword ptr [rax+0x20]
       mov      gword ptr [rbp-0x90], rax
       mov      rax, gword ptr [rbp-0x90]
       mov      gword ptr [rbp-0x70], rax
       cmp      gword ptr [rbp-0x90], 0
       jne      G_M000_IG10
       mov      rdi, 0x7BE480D60094
       call     CORINFO_HELP_COUNTPROFILE32
       vxorps   xmm0, xmm0, xmm0
       vmovups  xmmword ptr [rbp-0x48], xmm0
       mov      rdi, 0x7BE47FF06738
       call     CORINFO_HELP_NEWSFAST
       mov      gword ptr [rbp-0x98], rax
       mov      rsi, qword ptr [rbp-0x48]
       mov      rdx, qword ptr [rbp-0x40]
       mov      rdi, gword ptr [rbp-0x98]
       call     [Lokad.Lython.LythonMemoryBudget:.ctor(System.Nullable`1[long]):this]
       mov      rax, gword ptr [rbp-0x98]
       mov      gword ptr [rbp-0x70], rax
 
G_M000_IG06:                ;; offset=0x017E
       mov      rax, gword ptr [rbp-0x70]
       mov      gword ptr [rbp-0x28], rax
       mov      rax, gword ptr [rbp-0x28]
       mov      gword ptr [rbp-0xB0], rax
       mov      rdi, gword ptr [rbp-0xB0]
       mov      rsi, 0x7BE480D60098
       call     CORINFO_HELP_CLASSPROFILE32
       mov      rax, gword ptr [rbp-0xB0]
       mov      gword ptr [rbp-0xD8], rax
       mov      rdi, gword ptr [rbp-0xD8]
       mov      r11, 0x7BE47E052E68
       call     [r11]Lokad.Lython.ILythonMemoryBudget:CreateScope():Lokad.Lython.ILythonMemoryScope:this
       mov      gword ptr [rbp-0x30], rax
 
G_M000_IG07:                ;; offset=0x01CD
       mov      rdi, gword ptr [rbp-0x18]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.LythonRunOptions:get_ResultMemoryBudget():Lokad.Lython.ILythonMemoryBudget:this]
       mov      gword ptr [rbp-0x78], rax
       mov      rax, gword ptr [rbp-0x78]
       mov      gword ptr [rbp-0x80], rax
       cmp      gword ptr [rbp-0x78], 0
       jne      SHORT G_M000_IG08
       mov      rdi, 0x7BE480D601A0
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, gword ptr [rbp-0x28]
       mov      gword ptr [rbp-0x80], rax
 
G_M000_IG08:                ;; offset=0x0203
       mov      rax, gword ptr [rbp-0x80]
       mov      gword ptr [rbp-0xB8], rax
       mov      rdi, gword ptr [rbp-0xB8]
       mov      rsi, 0x7BE480D601A8
       call     CORINFO_HELP_CLASSPROFILE32
       mov      rax, gword ptr [rbp-0xB8]
       mov      gword ptr [rbp-0xE0], rax
       mov      rdi, gword ptr [rbp-0xE0]
       mov      r11, 0x7BE47E052E70
       call     [r11]Lokad.Lython.ILythonMemoryBudget:CreateScope():Lokad.Lython.ILythonMemoryScope:this
       mov      gword ptr [rbp-0x38], rax
 
G_M000_IG09:                ;; offset=0x024A
       mov      rax, gword ptr [rbp-0x20]
       mov      gword ptr [rbp-0xC0], rax
       mov      rdi, gword ptr [rbp-0xC0]
       mov      rsi, 0x7BE480D602B0
       call     CORINFO_HELP_DELEGATEPROFILE32
       mov      rax, gword ptr [rbp-0xC0]
       mov      gword ptr [rbp-0xE8], rax
       mov      rdi, gword ptr [rbp-0x18]
       mov      rsi, gword ptr [rbp-0x30]
       mov      rdx, gword ptr [rbp-0x38]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.LythonRunOptions:WithMemoryOwners(Lokad.Lython.ILythonMemoryBudget,Lokad.Lython.ILythonMemoryBudget):Lokad.Lython.LythonRunOptions:this]
       mov      gword ptr [rbp-0xF0], rax
       mov      rax, gword ptr [rbp-0xE8]
       mov      rdx, gword ptr [rbp-0xF0]
       mov      rsi, gword ptr [rbp-0x10]
       mov      rdi, gword ptr [rax+0x10]
       mov      rax, gword ptr [rbp-0xE8]
       call     [rax+0x18]System.Func`3[System.__Canon,System.__Canon,System.__Canon]:Invoke(System.__Canon,System.__Canon):System.__Canon:this
       mov      gword ptr [rbp-0xF8], rax
       mov      rdi, gword ptr [rbp-0xF8]
       mov      rsi, gword ptr [rbp-0x38]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.LythonExecutionResult:OwnMemoryScope(Lokad.Lython.ILythonMemoryScope):Lokad.Lython.LythonExecutionResult:this]
       mov      gword ptr [rbp-0x50], rax
       jmp      SHORT G_M000_IG11
 
G_M000_IG10:                ;; offset=0x02D4
       mov      rdi, 0x7BE480D604C0
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG06
 
G_M000_IG11:                ;; offset=0x02E8
       call     G_M000_IG16
       nop      
 
G_M000_IG12:                ;; offset=0x02EE
       mov      rdi, 0x7BE480D605D4
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, gword ptr [rbp-0x50]
 
G_M000_IG13:                ;; offset=0x0301
       add      rsp, 272
       pop      rbp
       ret      
 
G_M000_IG14:                ;; offset=0x030A
       push     rax
 
G_M000_IG15:                ;; offset=0x030B
       mov      gword ptr [rbp-0x88], rdi
       mov      rax, gword ptr [rbp-0x38]
       mov      gword ptr [rbp-0xC8], rax
       mov      rdi, gword ptr [rbp-0xC8]
       mov      rsi, 0x7BE480D603B8
       call     CORINFO_HELP_CLASSPROFILE32
       mov      rax, gword ptr [rbp-0xC8]
       mov      gword ptr [rbp-0x100], rax
       mov      rdi, gword ptr [rbp-0x100]
       mov      r11, 0x7BE47E052E78
       call     [r11]System.IDisposable:Dispose():this
       call     CORINFO_HELP_RETHROW
       int3     
 
G_M000_IG16:                ;; offset=0x035B
       push     rax
 
G_M000_IG17:                ;; offset=0x035C
       cmp      gword ptr [rbp-0x30], 0
       je       SHORT G_M000_IG18
       mov      rdi, 0x7BE480D604C4
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, gword ptr [rbp-0x30]
       mov      gword ptr [rbp-0xD0], rax
       mov      rdi, gword ptr [rbp-0xD0]
       mov      rsi, 0x7BE480D604C8
       call     CORINFO_HELP_CLASSPROFILE32
       mov      rax, gword ptr [rbp-0xD0]
       mov      gword ptr [rbp-0x108], rax
       mov      rdi, gword ptr [rbp-0x108]
       mov      r11, 0x7BE47E052E80
       call     [r11]System.IDisposable:Dispose():this
 
G_M000_IG18:                ;; offset=0x03B5
       mov      rdi, 0x7BE480D605D0
       call     CORINFO_HELP_COUNTPROFILE32
       nop      
 
G_M000_IG19:                ;; offset=0x03C5
       add      rsp, 8
       ret      
 
; Total bytes of code 970

; Assembly listing for method Lokad.Lython.LythonCompiledScript:RunCore(Lokad.Lython.ILythonHost,Lokad.Lython.LythonRunOptions):Lokad.Lython.LythonExecutionResult:this (Tier1)
; Emitting BLENDED_CODE for x64 + VEX + EVEX on Unix
; Tier1 code
; optimized code
; optimized using Synthesized PGO
; rbp based frame
; fully interruptible
; with Synthesized PGO: fgCalledCount is 3181
; 16 inlinees with PGO data; 70 single block inlinees; 8 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       push     r15
       push     r14
       push     r13
       push     r12
       push     rbx
       sub      rsp, 232
       lea      rbp, [rsp+0x110]
       vxorps   xmm8, xmm8, xmm8
       vmovdqu32 zmmword ptr [rbp-0xB0], zmm8
       vmovdqu32 zmmword ptr [rbp-0x80], zmm8
       xor      eax, eax
       mov      qword ptr [rbp-0x40], rax
       mov      r15, rsi
       mov      rbx, rdx
 
G_M000_IG02:                ;; offset=0x003B
       mov      r14, gword ptr [rdi+0x08]
       test     r14, r14
       je       G_M000_IG66
       test     rbx, rbx
       jne      SHORT G_M000_IG04
 
G_M000_IG03:                ;; offset=0x004D
       mov      rax, 0x7BE47FFC6A60
       mov      qword ptr [rbp-0xB0], rax
       lea      rbx, [rbp-0xB0]
 
G_M000_IG04:                ;; offset=0x0065
       mov      r13, gword ptr [rbx+0x38]
       test     r13, r13
       jne      SHORT G_M000_IG06
 
G_M000_IG05:                ;; offset=0x006E
       mov      r13, gword ptr [rdi+0x20]
       test     r13, r13
       je       G_M000_IG67
 
G_M000_IG06:                ;; offset=0x007B
       mov      rdi, 0x7BE47FF06738
       cmp      qword ptr [r13], rdi
       jne      G_M000_IG68
       mov      r12, gword ptr [r13+0x10]
       mov      rdi, gword ptr [r12+0x08]
       mov      rdi, gword ptr [rdi+0x08]
       mov      gword ptr [rbp-0xC8], rdi
       xor      edi, edi
       mov      dword ptr [rbp-0x2C], edi
 
G_M000_IG07:                ;; offset=0x00A8
       mov      rdi, gword ptr [rbp-0xC8]
       call     [System.Threading.Monitor:Enter(System.Object)]
       mov      dword ptr [rbp-0x2C], 1
       cmp      byte  ptr [r12+0x38], 0
       jne      G_M000_IG10
       mov      rdi, 0x7BE47FF06B38
       call     CORINFO_HELP_NEWSFAST
       mov      gword ptr [rbp-0xD0], rax
       mov      rsi, gword ptr [r12+0x08]
       lea      rdi, bword ptr [rax+0x08]
       call     CORINFO_HELP_ASSIGN_REF
       mov      rax, gword ptr [rbp-0xD0]
       lea      rdi, bword ptr [rax+0x10]
       mov      rsi, r12
       call     CORINFO_HELP_ASSIGN_REF
       mov      rax, gword ptr [r12+0x18]
       mov      gword ptr [rbp-0x100], rax
       mov      rcx, gword ptr [rbp-0xD0]
       lea      rdi, bword ptr [rcx+0x20]
       mov      rsi, rax
       call     CORINFO_HELP_ASSIGN_REF
       mov      rsi, gword ptr [rbp-0x100]
       test     rsi, rsi
       je       SHORT G_M000_IG09
 
G_M000_IG08:                ;; offset=0x012A
       lea      rdi, bword ptr [rsi+0x28]
       mov      rsi, gword ptr [rbp-0xD0]
       call     CORINFO_HELP_ASSIGN_REF
 
G_M000_IG09:                ;; offset=0x013A
       lea      rdi, bword ptr [r12+0x18]
       mov      rsi, gword ptr [rbp-0xD0]
       call     CORINFO_HELP_ASSIGN_REF
       jmp      SHORT G_M000_IG11
 
G_M000_IG10:                ;; offset=0x014D
       mov      rdi, r12
       call     [System.ThrowHelper:ThrowObjectDisposedException(System.Object)]
       int3     
 
G_M000_IG11:                ;; offset=0x0157
       mov      rdi, gword ptr [rbp-0xC8]
       call     [System.Threading.Monitor:Exit(System.Object)]
       mov      r12, gword ptr [rbp-0xD0]
 
G_M000_IG12:                ;; offset=0x016B
       mov      gword ptr [rbp-0xB8], r12
 
G_M000_IG13:                ;; offset=0x0172
       mov      rdi, gword ptr [rbx+0x40]
       test     rdi, rdi
       cmove    rdi, r13
       mov      rax, 0x7BE47FF06738
       cmp      qword ptr [rdi], rax
       jne      G_M000_IG62
       mov      r13, gword ptr [rdi+0x10]
       mov      rdi, gword ptr [r13+0x08]
       mov      rdi, gword ptr [rdi+0x08]
       mov      gword ptr [rbp-0xD8], rdi
       xor      edi, edi
       mov      dword ptr [rbp-0x30], edi
 
G_M000_IG14:                ;; offset=0x01A8
       mov      rdi, gword ptr [rbp-0xD8]
       call     [System.Threading.Monitor:Enter(System.Object)]
       mov      dword ptr [rbp-0x30], 1
       cmp      byte  ptr [r13+0x38], 0
       jne      G_M000_IG17
       mov      rdi, 0x7BE47FF06B38
       call     CORINFO_HELP_NEWSFAST
       mov      gword ptr [rbp-0xE0], rax
       mov      rsi, gword ptr [r13+0x08]
       lea      rdi, bword ptr [rax+0x08]
       call     CORINFO_HELP_ASSIGN_REF
       mov      rax, gword ptr [rbp-0xE0]
       lea      rdi, bword ptr [rax+0x10]
       mov      rsi, r13
       call     CORINFO_HELP_ASSIGN_REF
       mov      rax, gword ptr [r13+0x18]
       mov      gword ptr [rbp-0x108], rax
       mov      rcx, gword ptr [rbp-0xE0]
       lea      rdi, bword ptr [rcx+0x20]
       mov      rsi, rax
       call     CORINFO_HELP_ASSIGN_REF
       mov      rsi, gword ptr [rbp-0x108]
       test     rsi, rsi
       je       SHORT G_M000_IG16
 
G_M000_IG15:                ;; offset=0x0227
       lea      rdi, bword ptr [rsi+0x28]
       mov      rsi, gword ptr [rbp-0xE0]
       call     CORINFO_HELP_ASSIGN_REF
 
G_M000_IG16:                ;; offset=0x0237
       lea      rdi, bword ptr [r13+0x18]
       mov      rsi, gword ptr [rbp-0xE0]
       call     CORINFO_HELP_ASSIGN_REF
       jmp      SHORT G_M000_IG18
 
G_M000_IG17:                ;; offset=0x0249
       mov      rdi, r13
       call     [System.ThrowHelper:ThrowObjectDisposedException(System.Object)]
       int3     
 
G_M000_IG18:                ;; offset=0x0253
       mov      rdi, gword ptr [rbp-0xD8]
       call     [System.Threading.Monitor:Exit(System.Object)]
       mov      r13, gword ptr [rbp-0xE0]
 
G_M000_IG19:                ;; offset=0x0267
       mov      gword ptr [rbp-0xC0], r13
 
G_M000_IG20:                ;; offset=0x026E
       mov      rax, gword ptr [rbx+0x60]
       mov      gword ptr [rbp-0xF8], rax
       mov      rdi, 0x7BE47FFC6A60
       call     CORINFO_HELP_NEWSFAST
       mov      gword ptr [rbp-0xE8], rax
       mov      rsi, gword ptr [rbx+0x08]
       lea      rdi, bword ptr [rax+0x08]
       call     CORINFO_HELP_ASSIGN_REF
       mov      rsi, gword ptr [rbx+0x10]
       mov      rax, gword ptr [rbp-0xE8]
       lea      rdi, bword ptr [rax+0x10]
       call     CORINFO_HELP_ASSIGN_REF
       mov      rsi, gword ptr [rbx+0x18]
       mov      rax, gword ptr [rbp-0xE8]
       lea      rdi, bword ptr [rax+0x18]
       call     CORINFO_HELP_ASSIGN_REF
       mov      rsi, gword ptr [rbx+0x20]
       mov      rax, gword ptr [rbp-0xE8]
       lea      rdi, bword ptr [rax+0x20]
       call     CORINFO_HELP_ASSIGN_REF
       mov      rax, gword ptr [rbp-0xE8]
       lea      rdi, bword ptr [rax+0x60]
       mov      rsi, gword ptr [rbp-0xF8]
       call     CORINFO_HELP_ASSIGN_REF
       movzx    rdi, byte  ptr [rbx+0x58]
       mov      rax, gword ptr [rbp-0xE8]
       mov      byte  ptr [rax+0x58], dil
       mov      rsi, gword ptr [rbx+0x28]
       lea      rdi, bword ptr [rax+0x28]
       call     CORINFO_HELP_ASSIGN_REF
       mov      rsi, gword ptr [rbx+0x30]
       mov      rax, gword ptr [rbp-0xE8]
       lea      rdi, bword ptr [rax+0x30]
       call     CORINFO_HELP_ASSIGN_REF
       mov      rdi, qword ptr [rbx+0x68]
       mov      rax, gword ptr [rbp-0xE8]
       mov      qword ptr [rax+0x68], rdi
       mov      rsi, gword ptr [rbx+0x38]
       lea      rdi, bword ptr [rax+0x38]
 
G_M000_IG21:                ;; offset=0x0337
       call     CORINFO_HELP_ASSIGN_REF
       mov      rsi, gword ptr [rbx+0x40]
       mov      rbx, gword ptr [rbp-0xE8]
       lea      rdi, bword ptr [rbx+0x40]
       call     CORINFO_HELP_ASSIGN_REF
       lea      rdi, bword ptr [rbx+0x48]
       mov      rsi, r12
       call     CORINFO_HELP_ASSIGN_REF
       lea      rdi, bword ptr [rbx+0x50]
       mov      rsi, r13
       call     CORINFO_HELP_ASSIGN_REF
       mov      rdi, 0x7BE48027A0B8
       cmp      qword ptr [r14+0x18], rdi
       jne      G_M000_IG61
       mov      r14, gword ptr [r14+0x10]
       mov      rdi, r14
       call     [Lokad.Lython.LythonEngine+<>c__DisplayClass8_0:<CompileCore>g__CreatePreExecutionFailure|1():Lokad.Lython.LythonExecutionResult:this]
       mov      r13, rax
       test     r13, r13
       jne      G_M000_IG57
       mov      rdi, 0x7BE480655A08
       call     CORINFO_HELP_NEWSFAST
       mov      r13, rax
       mov      rsi, gword ptr [r14+0x10]
       mov      r12, gword ptr [r14+0x18]
       lea      rdi, bword ptr [r13+0x08]
       call     CORINFO_HELP_ASSIGN_REF
       lea      rdi, bword ptr [r13+0x10]
       mov      rsi, r12
       call     CORINFO_HELP_ASSIGN_REF
       mov      r14, gword ptr [r14+0x20]
       test     r14, r14
       je       G_M000_IG58
       mov      rdi, 0x7BE4809D72A8
       call     CORINFO_HELP_NEWSFAST
       mov      r12, rax
 
G_M000_IG22:                ;; offset=0x03E3
       lea      rdi, bword ptr [r12+0x08]
       mov      rsi, r15
       call     CORINFO_HELP_ASSIGN_REF
       lea      rdi, bword ptr [r12+0x10]
       mov      rsi, rbx
       call     CORINFO_HELP_ASSIGN_REF
       lea      rdi, bword ptr [r12+0x18]
       mov      rsi, r13
       call     CORINFO_HELP_ASSIGN_REF
       lea      rdi, bword ptr [r12+0x20]
       mov      rsi, r14
       call     CORINFO_HELP_ASSIGN_REF
       mov      rdi, 0x7BE4809D7328
       call     CORINFO_HELP_NEWSFAST
       mov      r15, rax
       lea      rdi, bword ptr [r15+0x10]
       mov      rsi, r12
       call     CORINFO_HELP_ASSIGN_REF
       mov      rdi, 0x7BE48098A430
       mov      qword ptr [r15+0x18], rdi
       mov      rdi, 0x7BDCA18034D0
       mov      rbx, gword ptr [rdi]
       mov      rdi, 0x7BE4FD5013F0
       mov      rax, 0x7BE4FDD42810
       call     rax
       cmp      dword ptr [rax], 4
       jle      G_M000_IG59
       mov      rdi, gword ptr [rax+0x08]
       mov      rax, bword ptr [rdi+0x20]
       test     rax, rax
       je       G_M000_IG59
 
G_M000_IG23:                ;; offset=0x0480
       mov      rax, gword ptr [rax+0x10]
       test     rax, rax
       jne      SHORT G_M000_IG25
 
G_M000_IG24:                ;; offset=0x0489
       call     [System.Threading.Thread:InitializeCurrentThread():System.Threading.Thread]
 
G_M000_IG25:                ;; offset=0x048F
       mov      r14, gword ptr [rax+0x08]
       test     r14, r14
       jne      G_M000_IG60
       mov      rdi, 0x7BDCA1801158
       mov      r14, gword ptr [rdi]
 
G_M000_IG26:                ;; offset=0x04A9
       mov      rdi, 0x7BE4809D76B8
       call     CORINFO_HELP_NEWSFAST
       mov      r13, rax
       mov      rdi, 0x7BE47E044828
       call     CORINFO_HELP_NEWSFAST
       mov      rsi, rax
       lea      rdi, bword ptr [r13+0x18]
       call     CORINFO_HELP_ASSIGN_REF
       lea      rdi, bword ptr [r13+0x20]
       mov      rsi, r15
       call     CORINFO_HELP_ASSIGN_REF
       lea      rdi, bword ptr [r13+0x08]
       mov      rsi, r14
       call     CORINFO_HELP_ASSIGN_REF
       mov      rdi, gword ptr [rbx+0x08]
       mov      gword ptr [rbp-0xF0], rdi
       xor      edi, edi
       mov      dword ptr [rbp-0x34], edi
 
G_M000_IG27:                ;; offset=0x04FE
       mov      rdi, gword ptr [rbp-0xF0]
       call     [System.Threading.Monitor:Enter(System.Object)]
       mov      dword ptr [rbp-0x34], 1
       cmp      byte  ptr [rbx+0x20], 0
       jne      G_M000_IG45
       mov      r15, gword ptr [rbx+0x10]
       mov      r14, gword ptr [r15+0x08]
       test     r14, r14
       je       G_M000_IG51
       cmp      byte  ptr [r15], r15b
       cmp      gword ptr [r14+0x08], r15
       jne      G_M000_IG46
       cmp      gword ptr [r14+0x10], r14
       jne      G_M000_IG47
       xor      rdi, rdi
       mov      gword ptr [r15+0x08], rdi
 
G_M000_IG28:                ;; offset=0x054A
       xor      rdi, rdi
       mov      gword ptr [r14+0x08], rdi
 
G_M000_IG29:                ;; offset=0x0550
       mov      gword ptr [r14+0x10], rdi
 
G_M000_IG30:                ;; offset=0x0554
       mov      gword ptr [r14+0x18], rdi
       dec      dword ptr [r15+0x18]
       inc      dword ptr [r15+0x1C]
       mov      rdi, gword ptr [r14+0x20]
       xor      rsi, rsi
       mov      gword ptr [rdi+0x20], rsi
       lea      rdi, bword ptr [rdi+0x18]
       mov      rsi, r13
       call     CORINFO_HELP_ASSIGN_REF
       mov      rbx, gword ptr [rbx+0x08]
       test     rbx, rbx
       je       G_M000_IG48
       mov      rdi, rbx
       call     System.Threading.ObjectHeader:GetLockHandleIfExists(System.Object):nint
       test     rax, rax
       je       G_M000_IG40
 
G_M000_IG31:                ;; offset=0x0594
       mov      r15, gword ptr [rax]
 
G_M000_IG32:                ;; offset=0x0597
       cmp      byte  ptr [r15], r15b
 
G_M000_IG33:                ;; offset=0x059A
       mov      rbx, gword ptr [r15+0x08]
       test     rbx, rbx
       jne      G_M000_IG41
 
G_M000_IG34:                ;; offset=0x05A7
       mov      rdi, 0x7BE4802A9430
       call     CORINFO_HELP_NEWSFAST
       mov      r14, rax
       lea      rdi, bword ptr [r14+0x08]
       mov      rsi, r15
       call     CORINFO_HELP_ASSIGN_REF
       mov      rsi, gword ptr [r15+0x08]
       test     rsi, rsi
       jne      SHORT G_M000_IG43
 
G_M000_IG35:                ;; offset=0x05CE
       mov      rdi, rsi
       test     rdi, rdi
       je       SHORT G_M000_IG37
 
G_M000_IG36:                ;; offset=0x05D6
       mov      rax, 0x7BE480295470
       cmp      qword ptr [rdi], rax
       jne      G_M000_IG49
 
G_M000_IG37:                ;; offset=0x05E9
       mov      rsi, rdi
 
G_M000_IG38:                ;; offset=0x05EC
       lea      rdi, bword ptr [r14+0x10]
       call     CORINFO_HELP_ASSIGN_REF
       lea      rdi, bword ptr [r15+0x08]
       test     rdi, rdi
       je       G_M000_IG50
       mov      rsi, r14
       mov      rdx, rbx
       call     System.Threading.Interlocked:CompareExchangeObject(byref,System.Object,System.Object):System.Object
       cmp      rax, rbx
       jne      SHORT G_M000_IG33
       mov      rdi, r14
 
G_M000_IG39:                ;; offset=0x0615
       call     [System.Threading.Condition:SignalAll():this]
       jmp      G_M000_IG55
 
G_M000_IG40:                ;; offset=0x0620
       mov      rdi, rbx
       call     [System.Threading.ObjectHeader:<GetLockObject>g__GetLockObjectFallback|11_0(System.Object):System.Threading.Lock]
       mov      r15, rax
       jmp      G_M000_IG32
 
G_M000_IG41:                ;; offset=0x0631
       mov      rdi, 0x7BE4802A9430
       cmp      qword ptr [rbx], rdi
       jne      G_M000_IG34
 
G_M000_IG42:                ;; offset=0x0644
       mov      rdi, rbx
       jmp      SHORT G_M000_IG39
 
G_M000_IG43:                ;; offset=0x0649
       mov      rdi, 0x7BE4802A9430
       cmp      qword ptr [rsi], rdi
       jne      G_M000_IG35
 
G_M000_IG44:                ;; offset=0x065C
       mov      rsi, gword ptr [rsi+0x10]
       jmp      SHORT G_M000_IG38
 
G_M000_IG45:                ;; offset=0x0662
       mov      rdi, rbx
       call     [System.ThrowHelper:ThrowObjectDisposedException(System.Object)]
       int3     
 
G_M000_IG46:                ;; offset=0x066C
       mov      rdi, 0x7BE47F987A68
       call     CORINFO_HELP_NEWSFAST
       mov      r13, rax
       call     [System.SR:get_ExternalLinkedListNode():System.String]
       mov      rsi, rax
       mov      rdi, r13
       call     [System.InvalidOperationException:.ctor(System.String):this]
       mov      rdi, r13
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG47:                ;; offset=0x0699
       mov      rdi, gword ptr [r14+0x10]
       lea      rdi, bword ptr [rdi+0x18]
       mov      rsi, gword ptr [r14+0x18]
       call     CORINFO_HELP_ASSIGN_REF
       mov      rdi, gword ptr [r14+0x18]
       lea      rdi, bword ptr [rdi+0x10]
       mov      rsi, gword ptr [r14+0x10]
       call     CORINFO_HELP_ASSIGN_REF
       mov      rsi, gword ptr [r14+0x10]
       lea      rdi, bword ptr [r15+0x08]
       call     CORINFO_HELP_ASSIGN_REF
       jmp      G_M000_IG28
 
G_M000_IG48:                ;; offset=0x06CD
       mov      rdi, 0x7BE47C2007E8
       call     [System.ArgumentNullException:Throw(System.String)]
       int3     
 
G_M000_IG49:                ;; offset=0x06DE
       mov      rdi, rax
       call     CORINFO_HELP_CHKCASTCLASS
       int3     
 
G_M000_IG50:                ;; offset=0x06E7
       call     [System.ThrowHelper:ThrowNullReferenceException()]
       int3     
 
G_M000_IG51:                ;; offset=0x06EE
       mov      rdi, 0x7BE4806DEE08
       call     CORINFO_HELP_NEWSFAST
       mov      r15, rax
       mov      rdi, r15
       mov      rsi, rbx
       mov      rdx, r13
       call     [Lokad.Lython.Runtime.ExecutionThreads+Worker:.ctor(Lokad.Lython.Runtime.ExecutionThreads,Lokad.Lython.Runtime.ExecutionThreads+WorkItem):this]
       call     [System.Threading.ExecutionContext:IsFlowSuppressed():bool]
       test     eax, eax
       je       SHORT G_M000_IG52
       mov      rdi, gword ptr [r15+0x10]
       cmp      byte  ptr [rdi], dil
       mov      esi, 1
       call     [System.Threading.Thread:Start(bool):this]
       jmp      SHORT G_M000_IG55
 
G_M000_IG52:                ;; offset=0x072D
       call     [System.Threading.ExecutionContext:SuppressFlow():System.Threading.AsyncFlowControl]
       mov      gword ptr [rbp-0x40], rax
 
G_M000_IG53:                ;; offset=0x0737
       mov      rdi, gword ptr [r15+0x10]
       cmp      byte  ptr [rdi], dil
       mov      esi, 1
       call     [System.Threading.Thread:Start(bool):this]
       nop      
 
G_M000_IG54:                ;; offset=0x074A
       lea      rdi, [rbp-0x40]
       call     [System.Threading.AsyncFlowControl:Undo():this]
       nop      
 
G_M000_IG55:                ;; offset=0x0755
       mov      rdi, gword ptr [rbp-0xF0]
       call     [System.Threading.Monitor:Exit(System.Object)]
       mov      rdi, r13
       call     [Lokad.Lython.Runtime.ExecutionThreads+SynchronousWorkItem:Wait():Lokad.Lython.LythonExecutionResult:this]
       mov      r15, rax
 
G_M000_IG56:                ;; offset=0x076E
       lea      rdi, bword ptr [r15+0x28]
       mov      rsi, gword ptr [rbp-0xC0]
       call     CORINFO_HELP_ASSIGN_REF
       jmp      SHORT G_M000_IG63
 
G_M000_IG57:                ;; offset=0x0780
       mov      r15, r13
       jmp      SHORT G_M000_IG56
 
G_M000_IG58:                ;; offset=0x0785
       mov      rdi, 0x7BE47F987A68
       call     CORINFO_HELP_NEWSFAST
       mov      r15, rax
       mov      rdi, r15
       mov      rsi, 0x7BE47C20E590
       call     [System.InvalidOperationException:.ctor(System.String):this]
       mov      rdi, r15
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG59:                ;; offset=0x07B3
       mov      edi, 4
       call     CORINFO_HELP_GETDYNAMIC_GCTHREADSTATIC_BASE_NOCTOR_OPTIMIZED
       jmp      G_M000_IG23
 
G_M000_IG60:                ;; offset=0x07C2
       xor      rdi, rdi
       cmp      byte  ptr [r14+0x18], 0
       cmovne   r14, rdi
       jmp      G_M000_IG26
 
G_M000_IG61:                ;; offset=0x07D2
       mov      rsi, r15
       mov      rdx, rbx
       mov      rdi, gword ptr [r14+0x10]
       call     [r14+0x18]System.Func`3[System.__Canon,System.__Canon,System.__Canon]:Invoke(System.__Canon,System.__Canon):System.__Canon:this
       mov      r15, rax
       jmp      SHORT G_M000_IG56
 
G_M000_IG62:                ;; offset=0x07E5
       mov      r11, 0x7BE47E053BF0
       call     [r11]Lokad.Lython.ILythonMemoryBudget:CreateScope():Lokad.Lython.ILythonMemoryScope:this
       mov      r13, rax
       jmp      G_M000_IG19
 
G_M000_IG63:                ;; offset=0x07FA
       cmp      gword ptr [rbp-0xB8], 0
       je       SHORT G_M000_IG64
       mov      rdi, 0x7BE47FF06B38
       mov      rax, gword ptr [rbp-0xB8]
       cmp      qword ptr [rax], rdi
       jne      G_M000_IG69
       mov      rdi, rax
       call     [Lokad.Lython.LythonMemoryBudget+Scope:Dispose():this]
 
G_M000_IG64:                ;; offset=0x0827
       mov      rax, r15
 
G_M000_IG65:                ;; offset=0x082A
       add      rsp, 232
       pop      rbx
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG66:                ;; offset=0x083C
       mov      rdi, 0x7BE47FE66F18
       call     CORINFO_HELP_NEWSFAST
       mov      rbx, rax
       mov      rdi, rbx
       mov      rsi, 0x7BE47C253300
       call     [System.ObjectDisposedException:.ctor(System.String):this]
       mov      rdi, rbx
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG67:                ;; offset=0x086A
       mov      rdi, 0x7BE47FF06738
       call     CORINFO_HELP_NEWSFAST
       mov      r13, rax
       xor      esi, esi
       xor      edx, edx
       mov      rdi, r13
       call     [Lokad.Lython.LythonMemoryBudget:.ctor(System.Nullable`1[long]):this]
       jmp      G_M000_IG06
 
G_M000_IG68:                ;; offset=0x088E
       mov      rdi, r13
       mov      r11, 0x7BE47E053BE8
       call     [r11]Lokad.Lython.ILythonMemoryBudget:CreateScope():Lokad.Lython.ILythonMemoryScope:this
       mov      r12, rax
       jmp      G_M000_IG12
 
G_M000_IG69:                ;; offset=0x08A6
       mov      rdi, rax
       mov      r11, 0x7BE47E053C00
       call     [r11]System.IDisposable:Dispose():this
       jmp      G_M000_IG64
 
G_M000_IG70:                ;; offset=0x08BB
       push     rax
 
G_M000_IG71:                ;; offset=0x08BC
       lea      rdi, [rbp-0x40]
       call     [System.Threading.AsyncFlowControl:Undo():this]
       nop      
 
G_M000_IG72:                ;; offset=0x08C7
       add      rsp, 8
       ret      
 
G_M000_IG73:                ;; offset=0x08CC
       push     rax
 
G_M000_IG74:                ;; offset=0x08CD
       cmp      dword ptr [rbp-0x34], 0
       je       SHORT G_M000_IG75
       mov      rdi, gword ptr [rbp-0xF0]
       call     [System.Threading.Monitor:Exit(System.Object)]
 
G_M000_IG75:                ;; offset=0x08E0
       nop      
 
G_M000_IG76:                ;; offset=0x08E1
       add      rsp, 8
       ret      
 
G_M000_IG77:                ;; offset=0x08E6
       push     rax
 
G_M000_IG78:                ;; offset=0x08E7
       mov      rdi, gword ptr [rbp-0xC0]
       mov      r11, 0x7BE47E053BF8
       call     [r11]System.IDisposable:Dispose():this
       call     CORINFO_HELP_RETHROW
       int3     
 
G_M000_IG79:                ;; offset=0x0901
       push     rax
 
G_M000_IG80:                ;; offset=0x0902
       cmp      dword ptr [rbp-0x30], 0
       je       SHORT G_M000_IG82
 
G_M000_IG81:                ;; offset=0x0908
       mov      rdi, gword ptr [rbp-0xD8]
       call     [System.Threading.Monitor:Exit(System.Object)]
 
G_M000_IG82:                ;; offset=0x0915
       nop      
 
G_M000_IG83:                ;; offset=0x0916
       add      rsp, 8
       ret      
 
G_M000_IG84:                ;; offset=0x091B
       push     rax
 
G_M000_IG85:                ;; offset=0x091C
       cmp      gword ptr [rbp-0xB8], 0
       je       SHORT G_M000_IG87
       mov      rdi, 0x7BE47FF06B38
       mov      rax, gword ptr [rbp-0xB8]
       cmp      qword ptr [rax], rdi
       jne      SHORT G_M000_IG86
       mov      rdi, rax
       call     [Lokad.Lython.LythonMemoryBudget+Scope:Dispose():this]
       jmp      SHORT G_M000_IG87
 
G_M000_IG86:                ;; offset=0x0947
       mov      rdi, rax
       mov      r11, 0x7BE47E053C00
       call     [r11]System.IDisposable:Dispose():this
 
G_M000_IG87:                ;; offset=0x0957
       nop      
 
G_M000_IG88:                ;; offset=0x0958
       add      rsp, 8
       ret      
 
G_M000_IG89:                ;; offset=0x095D
       push     rax
 
G_M000_IG90:                ;; offset=0x095E
       cmp      dword ptr [rbp-0x2C], 0
       je       SHORT G_M000_IG92
 
G_M000_IG91:                ;; offset=0x0964
       mov      rdi, gword ptr [rbp-0xC8]
       call     [System.Threading.Monitor:Exit(System.Object)]
 
G_M000_IG92:                ;; offset=0x0971
       nop      
 
G_M000_IG93:                ;; offset=0x0972
       add      rsp, 8
       ret      
 
; Total bytes of code 2423

