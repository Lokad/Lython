from pathlib import Path
import json
r=Path(__file__).parent
d=json.loads((r.parent/'local-publication-r112/catalog.json').read_text(encoding='utf8'))
for c in d['cases']:
    if c['id']!='scripts.csv-summary-functions.large':continue
    print(json.dumps({k:v for k,v in c.items() if k not in ['fixtureJson']},ensure_ascii=False,indent=2))
    f=json.loads(c['fixtureJson']);print('fixture keys',f.keys(),'input names',list(f['inputFiles']),'output names',list(f['outputFiles']))
