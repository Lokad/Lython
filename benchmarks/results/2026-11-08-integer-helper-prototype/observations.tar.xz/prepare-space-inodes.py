from pathlib import Path
import json, subprocess
r=Path(__file__).parent;history=r.parent
old=json.loads((history/'shared-cased-split-r92/space-inventory.json').read_text(encoding='utf8'))['groups']
used=set()
for p in history.rglob('*dedup-proof.json'):
    try:d=json.loads(p.read_text(encoding='utf8'))
    except (ValueError,UnicodeError):continue
    gs=d.get('groups',[])
    if isinstance(gs,dict):used.update(gs)
    else:used.update(g['sha256'] for g in gs if 'sha256' in g)
groups={}
for digest,rows in old.items():
    if digest in used or len({row['inode'] for row in rows})<2:continue
    groups[digest]=[row['path'] for row in rows]
    if len(groups)==4:break
assert groups
remote='''from pathlib import Path
import fcntl,hashlib,json,os,shutil,subprocess
base=Path('/home/lokad/lython-bench-checks').resolve();groups=GROUPS
with(base/'comparison-vm.lock').open('a') as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[c]ollector.dll|[p]erf record'],capture_output=True).returncode==1
 before=shutil.disk_usage(base).free;inventory={};aliases={}
 for digest,names in groups.items():
  rows=[]
  for name in names:
   p=Path(name).resolve();assert base in p.parents and p.name in ('Lokad.Lython.dll','baseline-core.dll','current-core.dll')
   assert hashlib.sha256(p.read_bytes()).hexdigest()==digest
   aliases[name]=dict(path=str(p),sha256=digest)
   if any(row['path']==str(p) for row in rows):continue
   st=p.stat();rows.append(dict(path=str(p),inode=st.st_ino,bytes=st.st_size,links=st.st_nlink))
  inventory[digest]=rows
 selected=[];saved=0
 for digest,rows in inventory.items():
  canonical=rows[0];byinode={row['inode']:[x for x in rows if x['inode']==row['inode']] for row in rows}
  for inode,paths in byinode.items():
   if inode==canonical['inode'] or len(paths)!=paths[0]['links']:continue
   selected.append(dict(sha256=digest,canonical=canonical,paths=paths));saved+=paths[0]['bytes']
   break
  if saved>=4*1024*1024:break
 assert 4*1024*1024<=saved<=8*1024*1024,(saved,inventory)
 proof=base/'r113-core-dedup-proof.json';assert not proof.exists()
 for group in selected:
  for row in [group['canonical'],*group['paths']]:
   p=Path(row['path']);st=p.stat();assert st.st_ino==row['inode'] and st.st_size==row['bytes'] and hashlib.sha256(p.read_bytes()).hexdigest()==group['sha256']
 for group in selected:
  canonical=Path(group['canonical']['path'])
  for row in group['paths']:
   p=Path(row['path']);temporary=p.with_name(p.name+'.r113-identical-link');assert not temporary.exists()
   os.link(canonical,temporary);os.replace(temporary,p)
 for name,row in aliases.items():
  p=Path(name);assert str(p.resolve())==row['path'] and hashlib.sha256(p.read_bytes()).hexdigest()==row['sha256']
 receipt=dict(beforeFreeBytes=before,afterFreeBytes=shutil.disk_usage(base).free,groups=selected,freshInventory=inventory,aliases=aliases,allPathsAndBytesPreserved=True,archivesUntouched=True,allOriginalAliasesVerified=True)
 proof.write_text(json.dumps(receipt,indent=2)+'\\n');print(json.dumps(receipt))
'''.replace('GROUPS',repr(groups))
(r/'space-command.py').write_text(remote,encoding='utf8')
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
p=subprocess.run(ssh+['python3 -'],input=remote.encode(),capture_output=True)
(r/'space.stdout').write_bytes(p.stdout);(r/'space.stderr').write_bytes(p.stderr)
assert p.returncode==0,p.stderr.decode()
receipt=json.loads(p.stdout);(r/'dedup-proof.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf8')
print('Fresh idle-lease exact-byte dedup preserved all known aliases; recovered',receipt['afterFreeBytes']-receipt['beforeFreeBytes'],'bytes. No archive/evidence deletion.')
