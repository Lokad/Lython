from pathlib import Path
import fcntl,hashlib,json,os,shutil,subprocess
base=Path('/home/lokad/lython-bench-checks').resolve();groups={'6cb31a1ef8744b0fbdb72283a1f8d6884a109692251e02fef1f8b3444834b370': ['/home/lokad/lython-bench-checks/nonlocal-owners-b315-20261106/baseline/Lokad.Lython.dll', '/home/lokad/lython-bench-checks/nonlocal-owners-b315-20261106/reference/Lokad.Lython.dll', '/home/lokad/lython-bench-checks/nonlocal-owners-b316-20261106/baseline/Lokad.Lython.dll', '/home/lokad/lython-bench-checks/nonlocal-owners-b316-20261106/reference/Lokad.Lython.dll'], '19097990837efa64db8c0b49613f4082ab4f595595d0513e18115d77b1336663': ['/home/lokad/lython-bench-checks/allocation-current-20261101-ae22392d/worker/Lokad.Lython.dll', '/home/lokad/lython-bench-checks/whitespace-bulk-20261101-ae22392d/baseline/Lokad.Lython.dll', '/home/lokad/lython-bench-checks/iteration-cursor-20261101-4cca2041/baseline/Lokad.Lython.dll'], '88758a0389a7d1a9d0f3727daa7170d27e109cd172267047f61c39967cea5ba8': ['/home/lokad/lython-bench-checks/call-arena-b69-20261101/baseline/Lokad.Lython.dll', '/home/lokad/lython-bench-checks/fresh-config-b68-20261101/worker/Lokad.Lython.dll'], '380b78d49359b22ba73fe337ef400f4d1949485f6ef6e9945bfae49d86a9d108': ['/home/lokad/lython-bench-checks/native-key-construction-b139-20261103/legacy/Lokad.Lython.dll', '/home/lokad/lython-bench-checks/json-key-storage-b138-refined-20261103/candidate/Lokad.Lython.dll']}
with(base/'comparison-vm.lock').open('a') as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[c]ollector.dll|[p]erf record'],capture_output=True).returncode==1
 before=shutil.disk_usage(base).free;inventory={};aliases={}
 for digest,names in groups.items():
  rows=[]
  for name in names:
   p=Path(name).resolve();assert base in p.parents and p.name in ('Lokad.Lython.dll','baseline-core.dll','current-core.dll')
   assert hashlib.sha256(p.read_bytes()).hexdigest()==digest
   aliases[name]=dict(path=str(p),sha256=digest)
   if any(row['path']==str(p) for row in rows):continue
   st=p.stat();rows.append(dict(path=str(p),inode=st.st_ino,bytes=st.st_size,links=st.st_nlink))
  inventory[digest]=rows
 selected=[];saved=0
 for digest,rows in inventory.items():
  canonical=rows[0];byinode={row['inode']:[x for x in rows if x['inode']==row['inode']] for row in rows}
  for inode,paths in byinode.items():
   if inode==canonical['inode'] or len(paths)!=paths[0]['links']:continue
   selected.append(dict(sha256=digest,canonical=canonical,paths=paths));saved+=paths[0]['bytes']
   break
  if saved>=4*1024*1024:break
 assert 4*1024*1024<=saved<=8*1024*1024,(saved,inventory)
 proof=base/'r113-core-dedup-proof.json';assert not proof.exists()
 for group in selected:
  for row in [group['canonical'],*group['paths']]:
   p=Path(row['path']);st=p.stat();assert st.st_ino==row['inode'] and st.st_size==row['bytes'] and hashlib.sha256(p.read_bytes()).hexdigest()==group['sha256']
 for group in selected:
  canonical=Path(group['canonical']['path'])
  for row in group['paths']:
   p=Path(row['path']);temporary=p.with_name(p.name+'.r113-identical-link');assert not temporary.exists()
   os.link(canonical,temporary);os.replace(temporary,p)
 for name,row in aliases.items():
  p=Path(name);assert str(p.resolve())==row['path'] and hashlib.sha256(p.read_bytes()).hexdigest()==row['sha256']
 receipt=dict(beforeFreeBytes=before,afterFreeBytes=shutil.disk_usage(base).free,groups=selected,freshInventory=inventory,aliases=aliases,allPathsAndBytesPreserved=True,archivesUntouched=True,allOriginalAliasesVerified=True)
 proof.write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt))
