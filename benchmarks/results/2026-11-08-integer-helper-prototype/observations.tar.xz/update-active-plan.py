from pathlib import Path
import shutil
r=Path(__file__).parent;p=Path('PLAN.md');s=p.read_text(encoding='utf8');shutil.copyfile(p,r/'plan-before-source-interaction.md')
s=s.replace('**R113 selected: generalize the existing native proof for exact-integer binary','**R113 active prototype: generalize the existing native proof for exact-integer binary')
s=s.replace('   division helpers through general frame/workspace/operand publication. Replace','   division helpers through ordinary resumable dispatch. Reusable owned workspaces\n   already avoid repeated allocation: do not claim new allocation savings. Replace')
needle='   no universal scalar/tagged-value design or unsupported speed prediction.\n'
assert needle in s
s=s.replace(needle,needle+'''   Focused1524public/104internal peractual11/10 pass; initial cancellation-context
   assertion corrected to existing terminal host-failure contract, failure retained.
   Local warm allocation neutral, elapsed moving controls; compile allocation
   +0.40–0.41%affected/unchanged controls. One missing compile execution-clock field
   corrected offline to total compile/teardown clock, no retiming. Stable source/
   binary identities verified after Git-derived assembly metadata changed mid-build;
   affected public target rebuilt. B473 six controlled jobs active; no observation
   before18:15:17UTC. Disk preflight refused before workers, unchanged floor/headroom;
   one exact-byte old core duplicate hardlinked under fresh idle lease,5.61MB freed,
   all aliases/paths/archives preserved. Both alias-only inventory failures retained.

   **R114 next coherent completion milestone: independent native proof metadata
   and ordinary operand forwarding.** Source demonstrates NativeBody!=null disables
   ForwardValues to preserve source offsets, including when a dynamic guard fails.
   Replace proof SourceInstruction/ReturnInstruction offsets and member-opcode
   indices with immutable original instruction descriptors/return/member spans
   owned by existing proof nodes; run ordinary forwarding for all functions. Remove
   that mutual-exclusion branch and runtime source-index lookups. No new evaluator,
   backend, owner/cache/arena/flags; canonical operations and ordinary instruction
   representation stay. Additional descriptor bytes per prepared node versus fewer
   ordinary loads are an explicit compiled-storage tradeoff, not a free claim.
   Gate~20min: verify every proof consumer needs only immutable opcode metadata,
   not prepared positions; keep canonical call-site argument indices, all spans,
   control/cleanup/lifetime fences and mutable-lookup guards. Focus primitive and
   failed-proof/custom/suspending paths, locals/closures/defaults/imports, refusal/
   cancellation and retained-owner baselines. Then bounded controlled affected
   helpers and unchanged representative scripts, compile/warm/storage separated.
   Decide retained regression debt and qualify the coherent combined boundary;
   R113 alone is not completion of the performance objective.
''')
p.write_text(s,encoding='utf8')
print('Active prototype evidence and demonstrated native-proof/forwarding design interaction recorded; coherent R114 source gate next.')
