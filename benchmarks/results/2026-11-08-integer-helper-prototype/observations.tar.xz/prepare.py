from pathlib import Path
import copy, hashlib, json, os, shutil
r=Path(__file__).parent
old=r.parent/'local-publication-r112'
b=json.loads((old/'baseline.json').read_text(encoding='utf8'))
assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==h for p,h in b['productionSources'].items())
(r/'baseline.json').write_text(json.dumps(b,indent=2)+'\n',encoding='utf8')
shutil.copyfile('PLAN.md',r/'prior-plan.md')
for role in ['before','candidate']:
    shutil.copytree(old/'images/before',r/'images'/role,copy_function=os.link)
proposal='''R113 selected source gate: ordinary primitive arithmetic helper construction.
Existing native body already removes general function workspace/frame/operand publication for closed addition helpers, but PrepareNativeBody explicitly rejects all other Binary opcodes. GuardNativeReturn permits only equal Integer/String addition. Ordinary call/argument metadata and shared scope facts already exist; do not add them again. The canonical evaluator already provides exact arithmetic, magnitude preflight, cancellation, rollback and Python diagnostics. Generalize Add to Binary and dispatch through the original instruction operator, with a conservative dynamic proof for exact integers and stable result shapes. Keep existing string-add eligibility. No universal scalar representation, new frame/evaluator/cache/owner/arena or argument transport. Unsupported proof shapes retain all supported Python semantics through the ordinary executable path before effects, never after native work.
Affected scripts: complete CSV/JSON record accounting with quantity*price*(100-discount)//100 in a helper, and numeric checksum helpers; add-only/text/JSON/report controls remain unchanged. The existing positional addition catalog does not measure the affected family, so do not claim it does. Use one small complete-file accounting variation with independent CPython golden and the existing comparison tooling, no new framework. Native proof reuse is architectural work removal, not a CPU claim from source alone.
Semantic acceptance: integer promotion/negative floor and modulo/zero division/shifts/exception spans and context, original left-to-right evaluation, defaults/keywords/forwarding, globals after admission, primitive/dynamic mixed calls, suspending arithmetic protocols, cancellation in substantial arithmetic, terminal refusal and retained inputs/results/budget reuse. Keep depth16 managed native admission and existing function/interpreter nesting. Replace the Add-only operation, compiler restriction and evaluator branch, not retain a competing path. Focused Release both target frameworks; one short normal-settings allocation diagnostic and controlled VM source pair with unchanged roles. Finish with retain/refine/reject and explicit regression debt, then batch full platform/Stress/installed-core at a coherent retained checkpoint. Keep production baseline fully qualified; no promise of a particular speedup. Regex/publication unchanged.
'''
(r/'proposal.md').write_text(proposal,encoding='utf8')
p=Path('PLAN.md');s=p.read_text(encoding='utf8');a=s.index('   Next bounded source gate:');z=s.index('\n3. **Remaining substantial',a)
s=s[:a]+'''   **R113 selected: generalize the existing native proof for exact-integer binary
   helper bodies.** The Add-only restriction sends ordinary multiplication/floor
   division helpers through general frame/workspace/operand publication. Replace
   Add-only proof/dispatch with Binary using the original opcode and canonical
   evaluator; conservative primitive guards, no second evaluator/owner/frame/arena.
   Complete CSV/JSON accounting and checksum helpers are affected; maintained
   addition-only cases are controls, not evidence for other operators. First build
   one complete accounting fixture with an independent CPython golden. Preserve
   exact arithmetic, negative floor/modulo, spans/context/evaluation order, aliases,
   globals after admission, dynamic and suspending protocols, cancellation/refusal,
   managed depth and cleanup. Focused both-target Release, bounded allocation and
   controlled whole-script source pair; classify architecture/allocation/CPU
   separately, decide regression debt and remove displaced Add-only machinery.
   A coherent retained checkpoint triggers full platform/Stress/installed-core;
   no universal scalar/tagged-value design or unsupported speed prediction.
''' + s[z:]
p.write_text(s,encoding='utf8')
shutil.copyfile('PLAN.md',r/'pre-implementation-plan.md')
print('R113 source gate, proposed replacement and acceptance recorded; baseline frozen.')
