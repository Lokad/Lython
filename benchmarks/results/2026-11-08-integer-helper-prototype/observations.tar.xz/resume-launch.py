from pathlib import Path
import shutil,subprocess
r=Path(__file__).parent;b=r/'b473'
shutil.copyfile(b/'launch.log',b/'initial-disk-preflight.log')
s=(b/'launch.py').read_text(encoding='utf8')
old="code='from pathlib import Path; import sys; p=Path('+repr(stage)+'); assert not p.exists(); p.write_bytes(sys.stdin.buffer.read())'"
new="code='from pathlib import Path; import sys; p=Path('+repr(stage)+'); value=sys.stdin.buffer.read(); assert not p.exists() or p.read_bytes()==value; p.write_bytes(value) if not p.exists() else None'"
assert old in s;s=s.replace(old,new)
(b/'launch-after-space.py').write_text(s,encoding='utf8')
(r/'disk-preflight-correction.md').write_text('''Initial B473 launch refused before root creation/mount/workers:269631488B free,271155200B required. OS240MiB/evidence12MiB/payload guards unchanged. Fresh idle-lease inventory first selected symlink aliases rather than distinct old inodes; both no-mutation failures preserved. Filtered prior inode identities, freshly revalidated all current paths/SHA/links and replaced one exact-byte duplicate by hardlinks,5611520B recovered. Every known alias/path/content and all archives preserved, proof local/remote. Reuse only the identical staged helper after SHA/content verification; no collection had started, no duplicate dispatch.\n''',encoding='utf8')
subprocess.run(['C:/Python313/python.exe','-X','utf8',str(b/'launch-after-space.py')],check=True)
