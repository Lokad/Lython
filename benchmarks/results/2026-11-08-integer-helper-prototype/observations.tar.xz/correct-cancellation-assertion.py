from pathlib import Path
import hashlib,json,shutil
r=Path(__file__).parent
p=Path('tests/Lokad.Lython.Tests/SimpleFunctionExecutionBoundaryTests.cs')
shutil.copyfile(p,r/'initial-internal-tests.cs')
shutil.copyfile(r/'internalnet11.0.log',r/'initial-internalnet11.0.log')
s=p.read_text(encoding='utf8');a=s.index('    public void IntegerResultAdmissionStopsBeforePublicationAndRefunds');z=s.index('\n    [Theory]',a)
part=s[a:z];needle='                Assert.Same(active, error.PythonContext);'
assert part.count(needle)==1
part=part.replace(needle,'                // Cancellation at the return checkpoint is a terminal host\n                // failure; unlike an operator error it carries no Python context.\n                if (!cancel) Assert.Same(active, error.PythonContext);')
p.write_text(s[:a]+part+s[z:],encoding='utf8')
(r/'initial-test-correction.md').write_text('''Initial new internal cancellation test expected PythonContext on a terminal CheckNativeReturnExit failure. Existing source performs that return checkpoint outside the operator exception wrapper, and ThrowExecutionCanceled creates the terminal host failure without Python exception context. Corrected the overreaching assertion only for cancellation; retain first refusal origin/operator span/PythonContext, unchanged active exception, actual after-admission cancellation reached, no result publication, zero reservation/depth and final shared-budget baseline. Production source unchanged. Initial test source/failure log preserved. No timeout or containment assertion relaxed.\n''',encoding='utf8')
source={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in Path('src/Lokad.Lython').rglob('*') if p.is_file() and 'bin' not in p.parts and 'obj' not in p.parts}
(r/'post-test-correction-sources.json').write_text(json.dumps(source,indent=2)+'\n',encoding='utf8')
p=r/'qualify.py';s=p.read_text(encoding='utf8');s=s.replace("        log=r/(name+framework+'.log')","        if framework=='net11.0' and name=='public':\n            print('Reuse unchanged production public net11.0 passed1524; only a new internal assertion changed.',flush=True)\n            continue\n        log=r/(name+framework+'.log')")
(r/'qualify-resume.py').write_text(s,encoding='utf8')
