from pathlib import Path
r=Path(__file__).parent
s=(r/'compile-diagnostic.py').read_text(encoding='utf8');a=s.index("s=(r/'measure.py')");z=s.index("d=json.loads",a)
s=s[:a]+s[z:];s=s.replace("s['executionMilliseconds']/s['jobs']","s['elapsedMilliseconds']/s['jobs']")
exec(compile(s,str(r/'assess-compile.py'),'exec'))
