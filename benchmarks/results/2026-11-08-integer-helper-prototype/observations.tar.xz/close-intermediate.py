from pathlib import Path
import hashlib,json,shutil,tarfile
r=Path(__file__).parent;i=json.loads((r/'identity.json').read_text(encoding='utf8'))
assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==h for p,h in i['productionSources'].items())
a=json.loads((r/'b473/archive-receipt.json').read_text(encoding='utf8'))
assert a['complete'] and a['allWorkersJoined'] and a['quietBeforeAndAfter'] and not a['guestFixtureDirectories']
assert hashlib.sha256((r/'b473/observations.tgz').read_bytes()).hexdigest()==a['archiveSHA256']
(r/'status.json').write_text(json.dumps(dict(status='Intermediate active prototype, not committed or fully qualified. Continue coherent native-proof/forwarding milestone R114 before delivery decision.',measurement='Warm allocation neutral; compiler allocation+0.40–0.41%affected. CSV elapsed−1.53to−5.78%sync/−4.33to−6.28%async, syncCPU−0.69to+2.99%uncertain. JSON elapsed−3.54to−5.02%sync/−4.57to−6.67%async, CPU supports. Text nearbaseline, report elapsed−1.61to+2.98%/CPU0to+6.25%possible debt. All adverse/control roles retained.',limitation='Source showed all native bodies disable ordinary operand forwarding to preserve physical source offsets. Guard-failing mixed/protocol operands therefore lose that optimization. General ordinary workspaces are already reused: no per-call allocation savings follow from source alone.',fullQualification='Pending combined retained-source boundary; qualified05790317 remains independently valid.'),indent=2)+'\n',encoding='utf8')
out=Path('benchmarks/results/2026-11-08-integer-helper-prototype');out.mkdir()
with tarfile.open(out/'observations.tar.xz','w:xz') as t:
    for p in sorted(r.iterdir()):
        if p.name=='images':
            for role in ['before','candidate']:t.add(p/role/'Lokad.Lython.dll',arcname='images/'+role+'/Lokad.Lython.dll')
        elif p.name=='b473':
            for q in sorted(p.iterdir()):
                if q.name not in ['retrieved','payload.tgz']:t.add(q,arcname='b473/'+q.name)
        else:t.add(p,arcname=p.name)
with tarfile.open(out/'observations.tar.xz') as t:assert hashlib.sha256(t.extractfile('b473/observations.tgz').read()).hexdigest()==a['archiveSHA256']
for p,name in [(r/'identity.json','identity.json'),(r/'status.json','status.json'),(r/'b473/assessment.json','assessment.json'),(r/'assessment-local.json','allocation.json'),(r/'compile-assessment.json','compilation.json'),(r/'b473/archive-receipt.json','archive-receipt.json')]:shutil.copyfile(p,out/name)
(out/'README.md').write_text('''# Exact-integer helper intermediate prototype

2026-11-08. Baseline qualified05790317/core13107e6b; prototype over9b61264b/
core d8d2a6fb. Replaces Add-only native proof with conservative exact-integer Binary
proof, reusing original canonical operators. No API/backend/owner/arena/value
representation added. Focused1524public/104internal Release peractual11/10 pass.
Three independent CPython semantic goldens, actual suspended multiply/reflected
protocol cancellation, preflight refusal/after-admission cancellation/cleanup.
Initial assertion/build-identity/post-processing corrections retained in archive.

Two new complete4096-record CSV/JSON-lines accounting variations compute signed
quantity*cents*(100-discount)//100 in a helper, aggregate dictionaries and write a
complete CSV report. Independent isolated CPython stdout/file goldens. These expose
the prior arithmetic proof restriction; they are not unchanged published CPython
cases or an explanation of the historic general performance gap.

B473 existing quiet F4as_v7 VM/frozen worker7cf/optional0.4/normal GC and tiering,
two isolated roles per core, five-second warmup, seven rotated150msrounds.
Six jobs168.664s; all goldens/baselines/Ready/image/quiet/Closed/join/fixture/archive/
local verification gates pass. No users or owned RAM remain. Warm includes invocation,
mediated RAM I/O, full output validation and prior-result cleanup; compilation,
startup/protocol/staging/final cache teardown excluded.

| Script / API | Elapsed change across all pairings | Process CPU |
| --- | ---: | ---: |
| CSV accounting / sync |−5.78% to−1.53%|−0.69% to+2.99%|
| CSV accounting / async |−6.28% to−4.33%|−7.14% to−3.70%|
| JSON accounting / sync |−5.02% to−3.54%|−3.57%|
| JSON accounting / async |−6.67% to−4.57%|−3.85% to−1.54%|
| Unchanged text / sync |−1.77% to+0.20%|−2.41% to0%|
| Unchanged report / sync |−1.61% to+2.98%|0% to+6.25%|

Negative is faster. All ten local warm allocations are neutral. Compile allocation
rises0.40–0.41%affected, controls unchanged; desktop compile clocks uncertain.
The original assessor read the warm-only execution clock for compile jobs; corrected
offline to total compilation/teardown clock, no remeasurement. CSV sync CPU is
uncertain; report has possible regression debt, candidate-role spread3.46%.

**Intermediate, not yet committed or fully qualified.** Source gate revealed that
native proof source offsets disable ordinary operand forwarding even when guards
fail. Complete that coherent design boundary before a final delivery decision:
own immutable source descriptors in existing proof nodes, preserve all operation/
return/member spans, and allow ordinary forwarding independently. Account for the
compiled metadata tradeoff. Reusable ordinary workspaces already avoid repeated
allocation; do not infer an allocation reduction from bypassing that dispatch.

Disk preflight refused before root/mount/workers. Floor/headroom unchanged. Fresh
idle-lease exact-byte hardlinks recovered5.61MB, preserving all paths/aliases/
archives; alias-only inventory failures and the original refusal remain explicit.

[Status](status.json), [controlled roles](assessment.json), [allocation](allocation.json),
[compilation](compilation.json), [identity](identity.json), [receipt](archive-receipt.json),
[all sources, binaries, corrections and raw archive](observations.tar.xz).
''',encoding='utf8')
p=Path('benchmarks/EXPERIMENTS.md');p.write_text(p.read_text(encoding='utf8')+'''
## Integer helper proof, intermediate (2026-11-08)

[R113/B473](results/2026-11-08-integer-helper-prototype/README.md) broadens existing
Add-only proof to exact integer binary operators, canonical semantics. Focused
1524public/104internal peractual11/10; allocation neutral, compile+0.40–0.41%affected.
New complete CSV/JSON accounting scripts,168.664s/all gates: CSV−1.53to−5.78%sync/
−4.33to−6.28%async; JSON−3.54to−5.02%sync/−4.57to−6.67%async with supportingCPU.
CSVsyncCPU uncertain, reportCPU0to+6.25%possible debt. Intermediate, no full delivery
or CPython refresh. Source revealed native proof indices disable ordinary operand
forwarding even for failed guards; coherent next milestone makes those independent
using immutable source metadata in existing nodes, with compiled-storage tradeoff.
Disk preflight/alias-only failures/corrections preserved, no guard relaxation or
archive deletion; users joined/RAM unmounted/archive locally verified.
''',encoding='utf8')
p=Path('PLAN.md');s=p.read_text(encoding='utf8').replace('B473 six controlled jobs active; no observation\n   before18:15:17UTC.','B473 six controlled jobs168.664s complete/all gates/archive/localverified;\n   allocation neutral, CSVelapsed−1.53to−5.78%sync/−4.33to−6.28%async, JSON−3.54to\n   −5.02%sync/−4.57to−6.67%async with supportingCPU. CSVsyncCPU uncertain, report\n   CPU0to+6.25%possible debt. Intermediate, not committed/fully qualified.')
s=s.replace('B450–B472 terminal/cached;','B450–B473 terminal/cached;')
p.write_text(s,encoding='utf8')
print('R113 intermediate fully archived/local verified; continue R114 source/forwarding coherence, full delivery pending.')
