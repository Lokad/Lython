from pathlib import Path
import shutil,subprocess
r=Path(__file__).parent
for n in ['space-command.py','space.stdout','space.stderr']:shutil.copyfile(r/n,r/('alias-only-'+n))
s=(r/'prepare-space.py').read_text(encoding='utf8').replace("if digest in used or len(rows)<2:continue","if digest in used or len({row['inode'] for row in rows})<2:continue")
(r/'prepare-space-inodes.py').write_text(s,encoding='utf8')
subprocess.run(['C:/Python313/python.exe','-X','utf8',str(r/'prepare-space-inodes.py')],check=True)
