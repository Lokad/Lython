from pathlib import Path
import os, subprocess
r=Path(__file__).parent
env=os.environ.copy();env['DOTNET_ROOT']='C:/Users/JoannesVermorel/.dotnet11';env['DOTNET_HOST_PATH']=env['DOTNET_ROOT']+'/dotnet.exe';env['PATH']=env['DOTNET_ROOT']+';C:/Python313;'+env['PATH']
jobs=[('public','tests/Lokad.Lython.PublicApi.Tests/Lokad.Lython.PublicApi.Tests.csproj','(FullyQualifiedName~NativeReturnFunctionTests|FullyQualifiedName~NativeBranch|FullyQualifiedName~AsyncFunctionHostingTests|FullyQualifiedName~Integer|FullyQualifiedName~Cancellation|FullyQualifiedName~RepresentativeScriptTests)&Category!=Stress'),('internal','tests/Lokad.Lython.Tests/Lokad.Lython.Tests.csproj','(FullyQualifiedName~SimpleFunctionExecutionBoundaryTests|FullyQualifiedName~OrdinaryFunctionTransportTests|FullyQualifiedName~OwnedFunctionLocalsTests|FullyQualifiedName~FunctionBodyTemporaryLifetimeTests|FullyQualifiedName~FunctionWorkspaceOwnershipTests|FullyQualifiedName~LocalAugmentedLifetimeTests|FullyQualifiedName~LiveGlobalNamespaceHostTests)&Category!=Stress')]
for framework in ['net10.0']:
    # A nonincremental build is mandatory after restoring R112's source.
    for name,project,filter in jobs[:1]:
        log=r/(name+framework+'.log')
        with log.open('w',encoding='utf8') as out:
            p=subprocess.run([env['DOTNET_HOST_PATH'],'build',project,'-c','Release','-f',framework,'--no-incremental'],env=env,stdout=out,stderr=subprocess.STDOUT)
            if p.returncode:print(log.read_text(encoding='utf8')[-12000:],flush=True);raise SystemExit(p.returncode)
            p=subprocess.run([env['DOTNET_HOST_PATH'],'test',project,'-c','Release','-f',framework,'--no-build','--filter',filter],env=env,stdout=out,stderr=subprocess.STDOUT)
        if p.returncode:print(log.read_text(encoding='utf8')[-12000:],flush=True);raise SystemExit(p.returncode)
        print(name,framework,log.read_text(encoding='utf8').strip().splitlines()[-1],flush=True)
