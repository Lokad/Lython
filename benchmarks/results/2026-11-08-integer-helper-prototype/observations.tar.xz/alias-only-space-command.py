from pathlib import Path
import fcntl,hashlib,json,os,shutil,subprocess
base=Path('/home/lokad/lython-bench-checks').resolve();groups={'07a6530e13a7a681c2de48d756c7490765ebce7195b59a734f6de1ac84745b92': ['/home/lokad/lython-bench-checks/report-cost-b385-20261107/candidate/Lokad.Lython.dll', '/home/lokad/lython-bench-checks/canonical-format-instructions-b386-20261107/reference/Lokad.Lython.dll', '/home/lokad/lython-bench-checks/canonical-format-instructions-b387-20261107/reference/Lokad.Lython.dll'], '1f5919c0f48b4c35c22fcbcda252898a70c059d0b2c98ffc002bb8ebb466c78f': ['/home/lokad/lython-bench-checks/runtime-cpython-b266-20261105/candidate/Lokad.Lython.dll', '/home/lokad/lython-bench-checks/target-instructions-b267-20261105/reference/Lokad.Lython.dll', '/home/lokad/lython-bench-checks/native-dictionary-final-b265-20261105/candidate/Lokad.Lython.dll'], '402ae9f15552bc74858c13a1bd4984ff8415a0913247723e07846c3d6e1aefdd': ['/home/lokad/lython-bench-checks/runtime-cpython-b266-20261105/reference/Lokad.Lython.dll', '/home/lokad/lython-bench-checks/activation-allocation-b261-20261105/collector/Lokad.Lython.dll', '/home/lokad/lython-bench-checks/final-construction-b262-20261105/baseline/Lokad.Lython.dll', '/home/lokad/lython-bench-checks/runtime-cpython-b260-20261105/candidate/Lokad.Lython.dll', '/home/lokad/lython-bench-checks/private-csv-refined-b258-20261105/candidate/Lokad.Lython.dll', '/home/lokad/lython-bench-checks/private-csv-text-confirm-b259-20261105/candidate/Lokad.Lython.dll'], 'b909322bcc0b65650386fd7614ce706e85bc1f44166b20e3eca494d6b1cad924': ['/home/lokad/lython-bench-checks/constructor-operands-b341-20261106/candidate/Lokad.Lython.dll', '/home/lokad/lython-bench-checks/constructor-operands-b341-20261106/core/Lokad.Lython.dll']}
with(base/'comparison-vm.lock').open('a') as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[c]ollector.dll|[p]erf record'],capture_output=True).returncode==1
 before=shutil.disk_usage(base).free;inventory={};aliases={}
 for digest,names in groups.items():
  rows=[]
  for name in names:
   p=Path(name).resolve();assert base in p.parents and p.name in ('Lokad.Lython.dll','baseline-core.dll','current-core.dll')
   assert hashlib.sha256(p.read_bytes()).hexdigest()==digest
   aliases[name]=dict(path=str(p),sha256=digest)
   if any(row['path']==str(p) for row in rows):continue
   st=p.stat();rows.append(dict(path=str(p),inode=st.st_ino,bytes=st.st_size,links=st.st_nlink))
  inventory[digest]=rows
 selected=[];saved=0
 for digest,rows in inventory.items():
  canonical=rows[0];byinode={row['inode']:[x for x in rows if x['inode']==row['inode']] for row in rows}
  for inode,paths in byinode.items():
   if inode==canonical['inode'] or len(paths)!=paths[0]['links']:continue
   selected.append(dict(sha256=digest,canonical=canonical,paths=paths));saved+=paths[0]['bytes']
   break
  if saved>=4*1024*1024:break
 assert 4*1024*1024<=saved<=8*1024*1024,(saved,inventory)
 proof=base/'r113-core-dedup-proof.json';assert not proof.exists()
 for group in selected:
  for row in [group['canonical'],*group['paths']]:
   p=Path(row['path']);st=p.stat();assert st.st_ino==row['inode'] and st.st_size==row['bytes'] and hashlib.sha256(p.read_bytes()).hexdigest()==group['sha256']
 for group in selected:
  canonical=Path(group['canonical']['path'])
  for row in group['paths']:
   p=Path(row['path']);temporary=p.with_name(p.name+'.r113-identical-link');assert not temporary.exists()
   os.link(canonical,temporary);os.replace(temporary,p)
 for name,row in aliases.items():
  p=Path(name);assert str(p.resolve())==row['path'] and hashlib.sha256(p.read_bytes()).hexdigest()==row['sha256']
 receipt=dict(beforeFreeBytes=before,afterFreeBytes=shutil.disk_usage(base).free,groups=selected,freshInventory=inventory,aliases=aliases,allPathsAndBytesPreserved=True,archivesUntouched=True,allOriginalAliasesVerified=True)
 proof.write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt))
