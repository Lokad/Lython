from pathlib import Path
import hashlib,json,shutil,subprocess
r=Path(__file__).parent
receipt={framework:{name:hashlib.sha256((Path(path)/'bin/Release'/framework/'Lokad.Lython.dll').read_bytes()).hexdigest() for name,path in [('source','src/Lokad.Lython'),('public','tests/Lokad.Lython.PublicApi.Tests'),('internal','tests/Lokad.Lython.Tests')]} for framework in ['net11.0','net10.0']}
assert len(set(receipt['net11.0'].values()))==1
assert receipt['net10.0']['source']==receipt['net10.0']['internal']
(r/'initial-build-identity-mismatch.json').write_text(json.dumps(dict(hashes=receipt,reason='Evidence-only commit9b61264b occurred during sequential target builds. Git-derived assembly metadata changed across net10 public/internal builds; freeze refused. Production source unchanged. Rebuild/recheck only net10 public at stable HEAD, then require all copies identical.'),indent=2)+'\n',encoding='utf8')
shutil.copyfile(r/'publicnet10.0.log',r/'initial-publicnet10.0.log')
s=(r/'qualify.py').read_text(encoding='utf8').replace("for framework in ['net11.0','net10.0']:","for framework in ['net10.0']:").replace('    for name,project,filter in jobs:','    for name,project,filter in jobs[:1]:')
(r/'align-build-run.py').write_text(s,encoding='utf8')
subprocess.run(['C:/Python313/python.exe','-X','utf8',str(r/'align-build-run.py')],check=True)
