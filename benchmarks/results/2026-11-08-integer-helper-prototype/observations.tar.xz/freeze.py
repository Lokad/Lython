from pathlib import Path
import hashlib,json,re,shutil,subprocess
r=Path(__file__).parent;b=json.loads((r/'baseline.json').read_text(encoding='utf8'))
sources={p:hashlib.sha256(Path(p).read_bytes()).hexdigest() for p in b['productionSources']}
expected={'src/Lokad.Lython/Frontend/ExecutableNativeBody.cs','src/Lokad.Lython/Frontend/ExecutableScript.NativeReturns.cs','src/Lokad.Lython/Runtime/LythonRuntime.Executable.NativeReturn.cs'}
assert {p for p,h in sources.items() if h!=b['productionSources'][p]}==expected
counts={}
for name in ['publicnet11.0','internalnet11.0','publicnet10.0','internalnet10.0']:
    s=(r/(name+'.log')).read_text(encoding='utf8');m=re.search(r'Passed!.*Failed:\s+0, Passed:\s+(\d+),',s);assert m,name;counts[name]=int(m[1])
for framework in ['net11.0','net10.0']:
    ps=[Path(p)/'bin/Release'/framework/'Lokad.Lython.dll' for p in ['src/Lokad.Lython','tests/Lokad.Lython.PublicApi.Tests','tests/Lokad.Lython.Tests']]
    assert len({hashlib.sha256(p.read_bytes()).hexdigest() for p in ps})==1
p=r/'images/candidate/Lokad.Lython.dll';p.unlink();shutil.copyfile('src/Lokad.Lython/bin/Release/net11.0/Lokad.Lython.dll',p)
identity=dict(baselineSource='Fully qualified05790317/core13107e6b, cached CI42502610937',candidateSource='9b61264b plus exact-integer binary native-return proof, ordinary canonical operators',coreSHA256={role:hashlib.sha256((r/'images'/role/'Lokad.Lython.dll').read_bytes()).hexdigest() for role in ['before','candidate']},productionSources=sources,focusedChecks=counts,qualification='Focused Release actual11/10 pass; full retained-source platform/Stress/installed-core independent and pending. Initial new cancellation assertion corrected to existing terminal host failure contract; original test/log retained.',controls='Frozen worker7cf/host/optional0.4, normalGC/tiering. Two new complete accounting variations and unchangedCSV/text/report controls, full independent goldens and shared balances. Warm compilation excluded; no CPython timing refresh.')
(r/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf8')
(r/'source.patch').write_bytes(subprocess.check_output(['git','diff','--','src','tests']))
shutil.copyfile('PLAN.md',r/'pre-measurement-plan.md')
for name in ['measure.py','assess-local.py']:
    s=(r.parent/'local-publication-r112'/name).read_text(encoding='utf8')
    if name=='assess-local.py':
        a=s.index("out['limitations']=");z=s.index("\n(r/'assessment-local",a)
        s=s[:a]+"out['limitations']='R113 normal-settings same-process ALC diagnostic, Run-only clocks; allocations include host reset/full stdout/file validation/prior-result cleanup. New complete CSV/JSON4096-record accounting variations expose the prior Add-only proof restriction, three unchanged file-script controls. Both APIs. Desktop elapsed is diagnostic, not controlled CPU or historic CPython ratio. No new framework.'"+s[z:]
    (r/name).write_text(s,encoding='utf8')
print('Frozen R113',identity['coreSHA256'],counts,flush=True)
