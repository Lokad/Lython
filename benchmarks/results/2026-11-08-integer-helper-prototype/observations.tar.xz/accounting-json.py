def charge(quantity,cents,discount):
    return quantity*cents*(100-discount)//100
import csv
import json

totals={}
accepted=0
with open('input.json',newline='') as source:
    for record in source:
        record=json.loads(record)
        quantity=record['quantity']
        cents=record['cents']
        discount=record['discount']
        amount=charge(quantity,cents,discount)
        category=record['kind']
        totals[category]=totals.get(category,0)+amount
        accepted+=1
with open('report.csv','w',newline='') as target:
    writer=csv.writer(target,lineterminator='\n')
    writer.writerow(['kind','total'])
    for category in sorted(totals):
        writer.writerow([category,totals[category]])
print(accepted,sum(totals.values()))
