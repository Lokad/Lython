from pathlib import Path
import base64,copy,hashlib,json,struct,subprocess,tempfile
r=Path(__file__).parent
prior=json.loads((r.parent/'local-publication-r112/catalog.json').read_text(encoding='utf8'))
template=next(c for c in prior['cases'] if c['id']=='scripts.csv-summary-functions.large')
rows=[dict(kind=['blue','red','green'][i%3],quantity=(i%9)-2,cents=199+i%17,discount=(i%4)*5) for i in range(4096)]
new=[]
for kind in ['csv','json']:
    c=copy.deepcopy(template); c['id']='scripts.'+kind+'-integer-accounting.large'
    data=('kind,quantity,cents,discount\n'+''.join(f'{v["kind"]},{v["quantity"]},{v["cents"]},{v["discount"]}\n' for v in rows) if kind=='csv' else ''.join(json.dumps(v,separators=(',',':'))+'\n' for v in rows)).encode()
    source='''def charge(quantity,cents,discount):
    return quantity*cents*(100-discount)//100
import csv
'''+('import json\n' if kind=='json' else '')+'''
totals={}
accepted=0
with open('input.'''+kind+'''',newline='') as source:
    for record in '''+('csv.DictReader(source)' if kind=='csv' else 'source')+''':
'''+('        record=json.loads(record)\n' if kind=='json' else '')+'''        quantity='''+('int(record[\'quantity\'])' if kind=='csv' else "record['quantity']")+'''
        cents='''+('int(record[\'cents\'])' if kind=='csv' else "record['cents']")+'''
        discount='''+('int(record[\'discount\'])' if kind=='csv' else "record['discount']")+'''
        amount=charge(quantity,cents,discount)
        category=record['kind']
        totals[category]=totals.get(category,0)+amount
        accepted+=1
with open('report.csv','w',newline='') as target:
    writer=csv.writer(target,lineterminator='\\n')
    writer.writerow(['kind','total'])
    for category in sorted(totals):
        writer.writerow([category,totals[category]])
print(accepted,sum(totals.values()))
'''
    fixture=dict(size=4096,text='',inputFiles={'input.'+kind:base64.b64encode(data).decode()},outputFiles={'report.csv':''})
    with tempfile.TemporaryDirectory(prefix='lython-r113-cpython-') as folder:
        folder=Path(folder);(folder/('input.'+kind)).write_bytes(data)
        result=subprocess.run(['C:/Python313/python.exe','-I','-S','-X','utf8','-c',source],cwd=folder,capture_output=True,check=True)
        assert not result.stderr
        output=(folder/'report.csv').read_bytes();fixture['outputFiles']['report.csv']=base64.b64encode(output).decode()
    stdout=result.stdout.replace(b'\r\n',b'\n')
    digest=hashlib.sha256();key=b'report.csv'
    for part in [struct.pack('>I',1),struct.pack('>I',len(key)),key,struct.pack('>I',len(output)),output]:digest.update(part)
    c.update(source=source,size=4096,fixtureJson=json.dumps(fixture,separators=(',',':')),expectedOutput=stdout.decode(),sourceUtf8Bytes=len(source.encode()),expectedOutputUtf8Bytes=len(stdout),sourceSha256=hashlib.sha256(source.encode()).hexdigest(),expectedOutputSha256=hashlib.sha256(stdout).hexdigest(),expectedFilesSha256=digest.hexdigest())
    c['fixtureSha256']=hashlib.sha256(c['fixtureJson'].encode()).hexdigest()
    new.append(c)
    (r/('accounting-'+kind+'.py')).write_text(source,encoding='utf8')
    print(c['id'],len(rows),'records',len(data),'input bytes',stdout.decode().strip(),output.decode().strip(),flush=True)
cases=new+[next(c for c in prior['cases'] if c['id']==id) for id in ['scripts.csv-summary-functions.large','scripts.text-summary-helpers.large','scripts.report-render.large']]
(r/'catalog.json').write_text(json.dumps({**prior,'cases':cases},ensure_ascii=False,indent=2)+'\n',encoding='utf8')
(r/'workload-contract.md').write_text('''Two new complete accounting variations, same4096records, signed quantities/prices/discounts, CSV or JSON-lines input, helper multiplication/subtraction/floor division, dictionary aggregation, complete CSV report plus stdout. Independent isolated CPython goldens, original protocol length-prefixed file digest. Native guard accepts only exact integers; ordinary mixed/custom operations unchanged. These are new variations exposing the prior Add-only cliff, not the unchanged published CPython catalog or proof of the historic general gap. Three unchanged complete CSV/text/report controls. Existing driver, frozen worker/host/optional0.4, normal GC/tiering; no new framework. Warm I/O and cleanup boundary remains explicit.\n''',encoding='utf8')
