from pathlib import Path
import hashlib, json, subprocess
r=Path(__file__).parent
cases=[]
ops=['+','-','*','//','%','|','^','&','<<','>>','/','==','!=','<','<=','>','>=']
source=''.join(f'def op{i}(a,b):return a {op} b\n' for i,op in enumerate(ops))
for a,b in [(19,3),(-19,3),(19,-3),(2**90+7,3)]:
    source+=f'print({",".join(f"op{i}({a},{b})" for i,op in enumerate(ops) if op not in ["<<",">>"] or b>=0)})\n'
source+='print(op2(True,3),op2(1.5,3),op0("a","b"),op2("x",3))\n'
cases.append(('integer-binary-family-and-dynamic-mixed',source))
cases.append(('integer-accounting-forwarding-and-order', '''def amount(quantity,cents,discount=10):
 value=quantity*cents
 return value*(100-discount)//100
def mark(name,value):
 print(name)
 return value
print(amount(mark('quantity',3),mark('cents',199),discount=mark('discount',15)))
print(amount(-3,199),amount(2**80,7,0))
def bounded(a,b):
 if a*b<100:return a-b
 return a//b
print(bounded(2,3),bounded(100,3))
'''))
source=''.join(f'def bad{i}(value):return value {op} {rhs}\n' for i,(op,rhs) in enumerate([('//',0),('%',0),('/',0),('<<',-1)]))
source+='try:raise RuntimeError("outer")\nexcept RuntimeError as outer:\n'
for i in range(4):
    source+=f' try:bad{i}(7)\n except (ZeroDivisionError,ValueError) as error:print(type(error).__name__,error.__context__ is outer)\n'
cases.append(('integer-binary-error-context',source))
receipts=[];entries=[]
for name,source in cases:
    p=subprocess.run(['C:/Python313/python.exe','-I','-X','utf8','-c',source],capture_output=True,check=True)
    output=p.stdout.decode().replace('\r\n','\n')
    receipts.append(dict(name=name,source=source,sourceSHA256=hashlib.sha256(source.encode()).hexdigest(),expected=output,reference='isolated local CPython3.13'))
    entries.append('        { '+', '.join(json.dumps(x,ensure_ascii=False) for x in [name,source,output])+' },\n')
p=Path('tests/Lokad.Lython.PublicApi.Tests/NativeReturnFunctionTests.cs')
s=p.read_text(encoding='utf8');needle='    public static TheoryData<string, string, string> Cases => new()\n    {\n'
assert needle in s and 'integer-binary-family-and-dynamic-mixed' not in s
p.write_text(s.replace(needle,needle+''.join(entries)),encoding='utf8')
(r/'semantic-goldens.json').write_text(json.dumps(receipts,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
print('Independent CPython goldens recorded for',len(cases),'public cases.')
