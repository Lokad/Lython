# Lokad.Lython 0.11.0

Updated 2026-11-08. Git-ignored; never force-add. Publication/tagging postponed.
Objective: coherent simplification and substantial complete-script performance.
Current contracts belong in docs. Historical designs, failures and adverse data
remain in [EXPERIMENTS](benchmarks/EXPERIMENTS.md) and linked immutable evidence.

## Actual delivery status

- **Committed/pushed, fully qualified production05790317/core13107e6b.** Cached
  CI42502610937: Windows/Ubuntu actual .NET11/.NET10 full Release, original Stress
  both and installed core consumers. Later commits contain evidence/docs only.
  Shared compiler-fact correction, direct UTF-8 formatting/storage, original native
  returns and retained R62–R110 changes are delivered; do not replay qualification.
- **R106 delivered:** one existing native-return proof handles acyclic guards and
  selected return spans, with unchanged list factory borrowed by cold helper.
  No new engine/carrier/arena/owner/cache/options.205public/42internal focused per
  actual11/10. Guarded whole-script elapsed−13–17% across both APIs; coarse CPU
  supports gain, warm allocation neutral. Initial67e CSV+3% did not recur in1aa's
  bounded refinement; cause unresolved, original source/data retained. Compiler
  allocation+0.08–0.53%; Windows compiler timing uncertain, no universal compile gain.
- **Distinct established claims:** original native-return allocation−19.92/−19.31%,
  elapsed diagnostic. Formatting allocation−8.67%; controlled B102 elapsed/CPU−5–8%,
  original adverse15.125ms unexplained/preserved. R105 native JSON construction
  eager allocation−27–28%/elapsed−9–12%, streamed allocation−24%/elapsed−6–7%.
  Config coarseCPU+4–6% possible debt and older R76/R79/R95/R96/R102 debts remain
  separate. Favorable newer pairs do not silently repay old source-pair debt.
- **Current external baseline R109:** committed726/core1aa, CPython3.13.16,
  28jobs581.729s, all gates/archive/local verification pass; no users/fixtures.
  [BENCHMARKS](docs/BENCHMARKS.md) separates compile/warm/compile-to-result and names
  I/O/validation/cleanup boundaries. Warm CSV1.11x, returned CSV1.22–1.23x,
  JSON-lines0.92–0.93x, guarded text1.76–1.78x, eager normalization1.23–1.25x,
  streamed0.61–0.62x. Text/report controls remain variable. These are diagnostic
  named-source comparisons, no isolated causal gain. Startup/RSS/pending-I/O/
  embedding tails unmeasured. Prior15c and older guides preserved.
- **R108 assessment closed:**1110guest samples/5.58CPU seconds/64unknown5.77%.
  Formatting/JSON/dictionaries material; contexts0.72%leaf and call/frame3.96%
  despite84%inclusive. Groups overlap/inlining limits apply. No packaging dominance.
  Direct record filling, completed parser loops, UTF8 windows and final-buffer
  formatting already exist. R26/c4729 removed a stale-proof native formatted
  evaluator for correctness; preserve it. Original/corrected offline classifiers
  and failed pre-collection catalog ID retained; no profile retiming/prototype.

## Prioritized deliverables

1. **R110 committed/pushed05790317/core13107e6b; fully qualified.** One shared ordered-prefix value
   growth choice uses existing immutable layout.Count, removing intermediate
   replacements; baseline JSON seeding restored exactly. No new mechanism or API.
   Eight-record full-report replacement admissions21→7, initial funding unchanged;
   full goldens/balance0.897public/193internal Release peractual11/10 pass, including
   nine new shape/real-async/shared/pending/retained/cancel/refusal/cleanup cases.
   Wide allocation−8.56–8.58%bothAPIs; controlled elapsed−3.80to−10.29%sync/
   −6.05to−7.53%async, coarseCPU supports. Alternating allocation neutral, elapsed
   −1.59to−4.20%, CPUnearflat. CSVcontrol8.67%baseline spread inconclusive; JSON/
   shortreport nearbaseline. Initialeb14 startup capacity source/data preserved:
   wide allocation−11%, alternating+14.7%/elapsed+4.31to+10.82%. One bounded
   refinement, no unchanged favorable retime or unrelated old-debt repayment.
   Prefixes that outgrow initial backing can still retain spare hinted capacity
   or deny earlier; all storage/overlap funded and refusal terminal. Documented.
   Six jobs170.447s/all gates/archive/local pass, no users/fixtures. First disk
   preflight stopped before service/workers; measured wide evidence+50% now uses
   32MiBheadroom above unchanged240MiBfloor. Exact-byte17path hardlinks preserve
   every old alias/path/content/archive. Exact full delivery passes/cached CI42502610937, both OSes/actual11/10/original
   Stress/installed core. No repeated earlier qualification.

2. **R111/R112 closed; broader helper source gate next.** R111 existing loop
   diagnostic700.968µs versusCPython596.612µs≈1.17x(no quiet-after), profile1170
   samples: publication24.53%leaf includes necessary checks/cleanup. R112 deferred
   pure name lookup,446public/132internal peractual11/10 pass; allocation neutral.
   B472 six jobs167.915s/all gates/archive/localverified. Async loop modest gain;
   sync loop/control spread uncertain; report CPU+1.42–3.84%possible debt. Not
   retained: duplicated namespace branches without convincing whole-script benefit.
   This is a complexity/evidence tradeoff, no fixed threshold/permanent rejection.
   Exact qualified05790317 production restored; local761 prototype bins are stale
   for current source and require a nonincremental build before reuse. Evidence
   lives under2026-11-08-local-publication; no full CI replay of unchanged baseline.
   **R113 selected: generalize the existing native proof for exact-integer binary
   helper bodies.** The Add-only restriction sends ordinary multiplication/floor
   division helpers through general frame/workspace/operand publication. Replace
   Add-only proof/dispatch with Binary using the original opcode and canonical
   evaluator; conservative primitive guards, no second evaluator/owner/frame/arena.
   Complete CSV/JSON accounting and checksum helpers are affected; maintained
   addition-only cases are controls, not evidence for other operators. First build
   one complete accounting fixture with an independent CPython golden. Preserve
   exact arithmetic, negative floor/modulo, spans/context/evaluation order, aliases,
   globals after admission, dynamic and suspending protocols, cancellation/refusal,
   managed depth and cleanup. Focused both-target Release, bounded allocation and
   controlled whole-script source pair; classify architecture/allocation/CPU
   separately, decide regression debt and remove displaced Add-only machinery.
   A coherent retained checkpoint triggers full platform/Stress/installed-core;
   no universal scalar/tagged-value design or unsupported speed prediction.

3. **Remaining substantial redesign roadmap.** Complete call/frame construction,
   operand transport, per-record storage, text conversions and repeated frontend
   analysis remain candidates requiring demonstrated removable work. Current gates
   already establish direct arguments/final slots/native workstate, unboxed64-bit
   sum, cheap small-counter admission, UInt128 parsing, shared lexical facts and
   immutable builtins, executable imports and efficient comparison file handles.
   Do not reimplement absent phases. Old bulk CSV6–8% evidence/control regression
   remains; current keys/array adoption removed its proposed copying. Preserve
   slower R71 arena/control/wide-carrier lessons. Before a new prototype name its
   complete affected scripts, hypothesis, eliminated work/storage and displaced
   implementation, semantic/ownership/cancellation acceptance, bounded controlled
   comparison and completion/debt decision. Source selection~20min; unresolved
   attribution means uncertainty, not permission for speculative tags/caches/JIT/
   duplicate evaluators. No permanent ban on evidence-backed reconsideration.

4. **Independent regex contract/implementation.** Lython owns native UTF8 names,
   byte captures/scalar positions/original windows, Python flags/replacements/errors,
   ownership/current cancellation and one frontend/runtime/import provider. Core
   remains backend-independent; optional adapter nonpackable, ordinary0.4 pin.
   Exact dev55/d6067925 development checks86internal/514public peractual11/10 remain.
   Missing producer capabilities: DetailedData separate preparation/working owner,
   native-name enumeration and cursor creation without retaining an earlier token.
   Existing adapter-local bridges remain justified; development producers are valid.
   Separate contract forwarding/unwind, semantic tests and actual backend performance.
   Qualify affected final adapter against a released package when supplied; this
   never stops independent core work. No sibling edits/builds or unchanged replays.

## Acceptance and operating policy

Bounded confirmation, refinement and measurement correction are allowed. Timeout,
unstable unchanged controls or inconclusive data establish uncertainty, not failed
design. Size runs for usable quiet-VM observations. Preserve adverse results and
original failed conditions. Percentages inform decisions rather than veto useful
simplification. Separate architecture, allocation, demonstrated CPU and latency.
Temporary setbacks require an explicit completion milestone and regression decision.

AGENTS.md governs managed safety/stack admission, host mediation, cancellation and
shared coarse admission/preflights/replacement overlap. No unsafe/Unsafe/native
probing, independent caps/fuel/quotas, tracing/weak reclamation/forced GC, silent
regex fallback or abandoned work. Aliases/results/cache/pending users remain funded
until awaited cleanup; first refusal is terminal, no retries. Bounded host executions
remain the initial long-stream ownership boundary. No hidden default allowance.

Focused Release iteration; no overlapping local builds/tests/measurements. Fresh
build after timestamp-preserving restores. Batch actual11/10 Windows/Ubuntu/original
Stress/installed core at delivery. UTF8 text. Only core explicit Release pack into
artifacts/nuget; no publication/tagging. VM lokad@20.166.121.73, key
~/.ssh/id_lython-bench.pem. Persistent evidence separate from owned RAM: join users,
copy/verify maps, unmount, archive under lease and verify locally. No evidence deletion;
core hardlinks require fresh exact-byte/inode proof preserving paths and aliases.

B450–B472 terminal/cached; B470 completed micro/failed capture cleaned and archived,
B471 corrected capture complete/archived/locally verified. No VM users/fixtures. All recorded
terminal CI runs cached, including42496463028/726,42488128858/a7 and42484943603/15c;
never query again. Observations>=5min, no duplicate dispatch. Prior active plans
preserved privately; immutable measurement/qualification history stays separate.

R110 CI42502610937/05790317 is terminal green/cached; never query again.
