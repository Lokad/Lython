from pathlib import Path
import json,statistics,subprocess
r=Path(__file__).parent
s=(r/'measure.py').read_text(encoding='utf8').replace("[('warm','sync'),('warm','async')]","[('compile','sync')]")
(r/'measure-compile.py').write_text(s,encoding='utf8')
subprocess.run(['C:/Python313/python.exe','-X','utf8',str(r/'measure-compile.py')],check=True)
d=json.loads((r/'compile-sync/measurements.json').read_text(encoding='utf8'));assert all(d[k] for k in ['allGoldensPassed','allBalancesZero','ownedFixturesRemoved','imageIsolationVerified'])
rows=[]
for o in d['observations']:
    roles={role:dict(milliseconds=statistics.median(s['executionMilliseconds']/s['jobs'] for s in o['samples'] if s['image']==role),allocation=statistics.median(s['allocatedBytes']/s['jobs'] for s in o['samples'] if s['image']==role)) for role in ['before','before-control','candidate']}
    row=dict(case=o['caseId'],roles=roles,allocationPercent=[100*(roles['candidate']['allocation']/roles[b]['allocation']-1) for b in ['before','before-control']],elapsedPercent=[100*(roles['candidate']['milliseconds']/roles[b]['milliseconds']-1) for b in ['before','before-control']])
    rows.append(row);print(row['case'],'compile allocation%',*[round(x,3) for x in row['allocationPercent']],'diagnostic elapsed%',*[round(x,3) for x in row['elapsedPercent']],flush=True)
(r/'compile-assessment.json').write_text(json.dumps(dict(rows=rows,limitations='Compilation only through existing diagnostic driver, allocation includes validation/owned code teardown; normal GC/tiering and same-process ALCs, desktop elapsed uncertain. No compile-to-result or CPython inference.'),indent=2)+'\n',encoding='utf8')
