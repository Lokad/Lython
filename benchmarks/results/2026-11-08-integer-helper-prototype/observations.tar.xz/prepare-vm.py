from pathlib import Path
import ast,hashlib,json,shutil,tarfile
r=Path(__file__).parent;old=r.parent/'local-publication-r112/b472';b=r/'b473';b.mkdir()
sour=json.loads((r/'identity.json').read_text(encoding='utf8'));prior=json.loads((old/'identity.json').read_text(encoding='utf8'))
jobs=[[case,lane] for case in ['scripts.csv-integer-accounting.large','scripts.json-integer-accounting.large'] for lane in ['warm','warm-async']]+[['scripts.text-summary-helpers.large','warm'],['scripts.report-render.large','warm']]
identity={**prior,'sourceRevision':sour['candidateSource'],'baselineSource':sour['baselineSource'],'coreSHA256':{role:sour['coreSHA256']['before' if role.startswith('reference') else 'candidate'] for role in ['reference','reference-control','candidate','candidate-control']},'productionSources':sour['productionSources'],'qualification':sour['qualification'],'jobs':jobs}
(b/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf8')
for name in ['collect.py','run.sh','retrieve.py','assess-vm.py','archive-owned.py','launch.py']:
    s=(old/name).read_text(encoding='utf8').replace('local-publication-b472-20261108','primitive-helpers-b473-20261108').replace('lython-b472-local-publication','lython-b473-primitive-helpers').replace('local-publication-b472-launch.py','primitive-helpers-b473-launch.py').replace('lython-b472-fixtures','lython-b473-fixtures')
    if name=='collect.py':
        a=s.index('jobs=');z=s.index('\nassert len(jobs)',a);s=s[:a]+'jobs='+repr(jobs)+s[z:]
        a=s.index("purpose='");z=s.index("',\n",a);s=s[:a]+"purpose='R113 existing native return proof generalized from Add to exact-integer binary operations; complete CSV and JSON accounting bothAPIs with unchanged text/report controls"+s[z:]
    if name=='archive-owned.py':
        duplicate='assert shutil.disk_usage(root).free>240*1024*1024\nassert shutil.disk_usage(root).free>240*1024*1024\n'
        s=s.replace(duplicate,'assert shutil.disk_usage(root).free>240*1024*1024\n')
    (b/name).write_text(s,encoding='utf8',newline='\n')
    if name.endswith('.py'):ast.parse(s)
for src,name in [(r/'images/candidate/Lokad.Lython.dll','current-core.dll'),(r/'catalog.json','representative.json'),(r/'identity.json','focused.json'),(r/'source.patch','source.patch'),(r/'pre-measurement-plan.md','pre-measurement-plan.md')]:shutil.copyfile(src,b/name)
shutil.copyfile(old/'baseline-source.json',b/'baseline-source.json')
dynamic=sum((p.stat().st_size+4095)//4096*4096 for p in (old/'retrieved/confirmation').rglob('*') if p.is_file())
estimate=(dynamic+(old/'observations.tgz').stat().st_size+(r/'catalog.json').stat().st_size)*1.5
assert estimate<12*1024*1024
(b/'sizing.json').write_text(json.dumps(dict(priorRoundedDynamicBytes=dynamic,priorFullArchiveBytes=(old/'observations.tgz').stat().st_size,newCatalogBytes=(r/'catalog.json').stat().st_size,estimateWith50PercentHeadroom=estimate,evidenceHeadroomBytes=12*1024*1024,osFloorBytes=240*1024*1024,baselineArchiveReused=True,noEvidenceDeleted=True),indent=2)+'\n',encoding='utf8')
(b/'setup-contract.json').write_text(json.dumps(dict(jobs=jobs,ownerSeconds=210,stopSeconds=30,marginSeconds=30,evidenceHeadroomMiB=12,osFloorMiB=240),indent=2)+'\n',encoding='utf8')
contract='''R113 one bounded source pair1310/current exact hashes in identity. Replace Add-only native return restriction/operation with conservative exact-integer Binary proof and original canonical evaluator, no new engine/representation/frame/owner/cache/argument transport. Existing checks, integer preflights/rollback, error context and evaluation order, current cancellation and genuine async protocols retained.1524public/104internal focused Release peractual11/10 pass. Initial new cancellation assertion corrected to existing host-failure contract, original test/failure retained. Git metadata mismatch across sequential target builds caught before freeze; affected public target rebuilt at stable HEAD and all copies verified.
Two complete4096-record CSV/JSON accounting variations, signed quantities/cents/discounts, same accounting helper, full report/stdout goldens independently captured with isolated CPython. Both APIs, plus unchanged text/report controls. These variations are not the unchanged published CPython cases; no broad historic ratio or whole-runtime speed claim. Warm includes invocation, mediated RAM I/O, full stdout/file validation, prior-result cleanup; compile/startup/staging/final cache teardown excluded. Architecture, allocation and CPU reported separately.
Same frozenworker7cf/host/normaloptional0.4/normalGC/tiering, two isolated processes per core,5swarmup/role/job,7rotated150msrounds.210sowner+30stop+30margin; sixjobs. All Ready/source/core/aux/golden/quiet/Closed/exit/join/unmount/archive/local gates. Persistent raw, owned128MiB RAM guestfixtures. Unchanged240MiBOSfloor+12MiBevidence+actualpayload preflight; completed prior dynamic+archive+new catalog+50% fits headroom. Already-preserved verified baseline binary reused via receipt; no old paths/bytes/archives deleted. Full retained-source delivery pending separately. Regex/publication unchanged.
'''
(b/'contract.md').write_text(contract,encoding='utf8')
with tarfile.open(b/'payload.tgz','w:gz') as t:
    for name in ['collect.py','run.sh','current-core.dll','representative.json','identity.json','pre-measurement-plan.md','setup-contract.json','contract.md','focused.json','source.patch','archive-owned.py','baseline-source.json','sizing.json']:t.add(b/name,arcname=name)
print('B473 six controlled jobs prepared; current payload and conservative disk preflight, no unchanged CI replay.')
