from pathlib import Path
r=Path(__file__).resolve().parent;prior=r.parent/'generator-facts-r503'
s=(prior/'freeze.py').read_text(encoding='utf-8')
s=s.replace("work=repo/'.git/agent-worktrees/generator-facts-r503';prior=r.parent/'constant-record-r499'", "work=repo/'.git/agent-worktrees/bulk-trim-r506';prior=r.parent/'generator-facts-r503'")
s=s.replace("referenceSource='Committedea8e9f91/frozencf847936; constant-key record construction'", "referenceSource='Qualified62786960 production/frozen5ae019db; generator field facts'")
a=s.index("candidateSource='");b=s.index("',imageFiles=",a)
s=s[:a]+"candidateSource='Private R506 on9bf3a63d: default strip/lstrip/rstrip reuse existing bounded managed ASCII whitespace scanner; preserve Unicode/custom sets and ownership. Six boundary cases, existing cancellation fixture scans a bulk-sized input. Worker/adapter remain reference copies"+s[b:]
(r/'freeze.py').write_text(s,encoding='utf-8',newline='\n')
print('Prepared copied-image freeze and actual-worker checks.')
