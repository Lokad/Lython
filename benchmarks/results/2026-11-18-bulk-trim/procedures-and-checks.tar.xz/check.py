from pathlib import Path
import json,os,subprocess
r=Path(__file__).resolve().parent; work=Path('D:/code/Lython/.git/agent-worktrees/bulk-trim-r506')
d=Path('C:/Users/JoannesVermorel/.dotnet11/dotnet.exe');env=os.environ.copy();env.update(DOTNET_ROOT=str(d.parent),DOTNET_ROOT_X64=str(d.parent));env['PATH']=str(d.parent)+os.pathsep+env['PATH']
if (r/'build.log').exists()and not(r/'first-invalid-solution.log').exists():
 (r/'build.log').rename(r/'first-invalid-solution.log')
cmd=[str(d),'build','Lokad.Lython.slnx','-c','Release','--no-incremental']
with(r/'build.log').open('w',encoding='utf-8')as log:p=subprocess.run(cmd,cwd=work,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=240)
assert p.returncode==0,(r/'build.log').read_text(encoding='utf-8');print('Nonincremental Release build passes.',flush=True)
filters={'internal':['StringStrip','DirectStringStrip','PyStringOpsPrimitive','StringMethodOwnership','CasedSplitOwnership','Executable'], 'public':['BuiltinCancellation','RepresentativeProtocolCancellation','NativeReceiverPipeline','GovernedMemoryContract','MemoryDenialAttribution']};records=[]
for tfm in ['net11.0','net10.0']:
 for kind,parts in filters.items():
  project='Lokad.Lython.Tests'if kind=='internal'else'Lokad.Lython.PublicApi.Tests'
  filt='('+'|'.join('FullyQualifiedName~'+p for p in parts)+')&Category!=Stress'
  cmd=[str(d),'test',f'tests/{project}/{project}.csproj','-c','Release','-f',tfm,'--no-build','--filter',filt]
  path=r/('focused-'+kind+'-'+tfm+'.log')
  with path.open('w',encoding='utf-8')as log:p=subprocess.run(cmd,cwd=work,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=180)
  records.append(dict(kind=kind,framework=tfm,command=cmd,exitCode=p.returncode));(r/'checks.json').write_text(json.dumps(records,indent=2)+'\n',encoding='utf-8')
  text=path.read_text(encoding='utf-8');assert p.returncode==0,text;print(kind,tfm,text.splitlines()[-1],flush=True)
