from pathlib import Path
import gzip,json,shutil,tarfile
r=Path(__file__).resolve().parent;repo=Path('D:/code/Lython');out=repo/'benchmarks/results/2026-11-18-bulk-trim';out.mkdir(exist_ok=False)
decision=dict(retain=True,reference='Qualified62786960/5ae019db',candidate='PrivateR506 on9bf3a63d/65fcf7d0',reason='Reuse an existing managed bounded bulk whitespace kernel for all default trim variants, with no new policy/owner/cache. Stable named text improvement and semantic passes; modest magnitude does not complete the broader performance objective.',allocation='Unchanged text/call allocation and all peaks; tiny other CLR diagnostic variations retained.',debt='Floating elapsed+0.52..+5.25%,CPU0..+5.42%,reference process spread4.04%; cannot establish universal neutrality or recovery. Preserve original condition; no automatic veto or unchanged broad replay.',fullQualification='Focused both targets only; batch full platform/stress/package at next coherent retained boundary.',publicationHeld=True)
(r/'decision.json').write_text(json.dumps(decision,indent=2)+'\n',encoding='utf-8',newline='\n')
(r/'preparation-history.json').write_text(json.dumps(dict(absentReplica='Initial read-only proof named already absent B925 profile replicas. No staging/mutation; failure retained.',timeout='Original proof performed one full filesystem walk per subject and exceeded60s. No mutation. Consolidated into one walk under the same idle lease, preserving UID/path/hash/link/all-alias checks; passed6.7s.',incompletePreparation='Preparation attempted before asynchronous proof completion; missing retirement-candidates.json failed locally. Partial files preserved; corrected dependency order before staging.',guard='254MiB staging/252MiB final unchanged; only exact committed B928/B929 raw/archive/metadata/cache replicas retired, current5ae image and both catalogs preserved.'),indent=2)+'\n',encoding='utf-8',newline='\n')
for n in ['summary.json','allocation-summary.json','candidate-allocation.json','candidate-preflight.json','candidate-sources.tar.xz','prototype.patch.gz','reference-reuse.json','checks.json','decision.json','preparation-history.json']:
 shutil.copyfile(r/n,out/n)
for n in ['archive-receipt.json','terminal-status.json','observations.tgz']:shutil.copyfile(r/'quiet'/n,out/n)
shutil.copyfile(r/'frozen/identity.json',out/'identity.json')
(out/'candidate-core.dll.gz').write_bytes(gzip.compress((r/'frozen/candidate/Lokad.Lython.dll').read_bytes(),mtime=0))
with tarfile.open(out/'procedures-and-checks.tar.xz','w:xz')as a:
 for p in sorted(r.rglob('*')):
  if not p.is_file()or any(n in p.relative_to(r).parts for n in ['frozen','retrieved']):continue
  if p.suffix in ['.dll','.xz','.tgz','.gz']:continue
  a.add(p,arcname=p.relative_to(r).as_posix())
(out/'README.md').write_text('''# Shared bulk whitespace scanner for default trim

R506 private65fcf7d0 on9bf3a63d versus qualified62786960/5ae019db.
Default strip/lstrip/rstrip reuse split's existing managed bulk ASCII scanner.
Remove Rune decoding and structural traversal per ASCII character; Unicode and
explicit-character scalar matching stay. No new opcode/cache/owner/policy.
Chunks≤64B use the existing cooperative structural check; a full check occurs
within4096ASCII bytes, while Unicode/custom scans retain scalar checkpoints.
The old256character cancellation fixture now scans8192characters so it tests
actual long work rather than an exact former checkpoint location. Boundary cases
cover0/1/63/64/65/129padding, C0/Unicode whitespace, multibyte/nonwhitespace edges,
all-whitespace output, explicit characters and unchanged identity.

Actual11/10 each429internal/29public focused checks pass; six exact-worker goldens,
allocation and shared-budget cleanup pass. Storage/admission/alias behavior is
unchanged. Full platform/originalstress/installed Release consumers are batched
for the next coherent retained delivery boundary, not inherited from62786960.

B930,2026-11-18 quiet F4as_v7/Ubuntu24.04.4/.NET11RC3, normalGC/tiering:
two jobs80.34s, six-second full-request warmups/five rotated rounds/two processes
per source. Complete text normalization warm elapsed1.38–2.19%lower, processCPU
1.16–3.81%lower, controls0.27/0.56%, maxIQR0.61%; allocation/peaks unchanged.
Floating control elapsed+0.52..+5.25%/CPU0..+5.42%, reference spread4.04% remains
uncertain/adverse. Do not claim universal neutrality or a substantial total gain.
Retain the shared kernel and named modest benefit; broader redesign remains active.

Warm clocks include Run, mediated RAM I/O, goldens and prior-result cleanup;
startup/reset/protocol/final cache teardown excluded, processCPU wider. All32image
hashes/catalog/quiet/join/persistent archive/localSHA/fixture teardown pass.
Preparation failures and original conditions are retained separately; no failed
collection or retiming. Only proved exact committed replicas retired, both current
catalogs/5ae images/toolchains/unmatched evidence preserved;254/252MiBguards unchanged.

[Decision](decision.json),[summary](summary.json),[allocation](allocation-summary.json),
[raw](observations.tgz),[identity/source hashes](identity.json),
[source](candidate-sources.tar.xz),[procedures/checks](procedures-and-checks.tar.xz),
[original preparation conditions](preparation-history.json).
Publication postponed. This milestone does not close the whole-script objective.
''',encoding='utf-8',newline='\n')
with(repo/'benchmarks/EXPERIMENTS.md').open('a',encoding='utf-8',newline='\n')as h:
 h.write('\nR506/B930 [shared bulk trim scanner](results/2026-11-18-bulk-trim/README.md),65fcf7d0 versus qualified5ae: defaulttrim reuses split ASCII kernel, no new policy/owner/cache. Both targets429internal/29public/sixgoldens/reuse pass. Twojobs80.34s: text warm1.38–2.19%lower elapsed/supportingCPU/stablecontrols, allocation/peaksflat. Floating+0.52..+5.25%elapsed/CPU0..+5.42%with4.04%reference spread remains uncertain/adverse. Retain modest consistent consolidation, not substantial-total/universal gain. Absent-replica/read-only proof timeout and premature preparation failure preserved; single-walk proof retains all checks, floors/current images/catalogs unchanged. Full qualification batched at next coherent boundary; broader objective active/publication held.\n')
print('R506 source condition, adverse control and retention decision archived.')
