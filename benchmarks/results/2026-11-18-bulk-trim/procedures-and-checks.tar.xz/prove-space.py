from pathlib import Path
import hashlib,io,json,subprocess,tarfile
r=Path(__file__).resolve().parent;repo=Path('D:/code/Lython');subjects=[]
for suffix,remote,members in [
 ('2026-11-17-generator-field-facts','generator-facts-b928-20261117',['confirmation/confirmation.json','whole-archive','confirmation/machine-before.json','confirmation/machine-after.json','collect.py','identity.json','__pycache__/cpython-worker.cpython-312.pyc']),
 ('2026-11-18-agent-cpython-checkpoint','agent-checkpoint-b929-20261118',['confirmation/confirmation.json','whole-archive','confirmation/machine-before.json','confirmation/machine-after.json','collect.py','identity.json','__pycache__/cpython-worker.cpython-312.pyc'])]:
 canonical='benchmarks/results/'+suffix+'/observations.tgz';blob=subprocess.check_output(['git','show','HEAD:'+canonical],cwd=repo);assert blob==(repo/canonical).read_bytes()
 with tarfile.open(fileobj=io.BytesIO(blob))as a:
  for member in members:
   data=blob if member=='whole-archive'else a.extractfile(member).read()
   subjects.append(dict(kind='completed-replica',path=remote+'/'+('observations.tgz'if member=='whole-archive'else member),bytes=len(data),sha256=hashlib.sha256(data).hexdigest(),canonical=canonical,canonicalSHA256=hashlib.sha256(blob).hexdigest(),member=member,committedBlobVerified=True))
code='''from pathlib import Path
import fcntl,hashlib,json,os,stat,subprocess
b=Path('/home/lokad/lython-bench-checks');subjects=SUBJECTS
with(b/'comparison-vm.lock').open('a')as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 workers=subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record|[p]ython3.*cpython-worker.py'],capture_output=True,text=True).stdout
 own={str(os.getpid()),str(os.getppid())};assert all(line.split(maxsplit=1)[0]in own for line in workers.splitlines()),workers
 assert not any(os.path.ismount(p)for p in b.glob('*/guest-fixtures'))
 selected={};proofs=[]
 for item in subjects:
  p=b/item['path'];m=p.lstat()
  assert p.resolve()==p and p.is_relative_to(b)and stat.S_ISREG(m.st_mode)and m.st_uid==os.getuid()and m.st_size==item['bytes']and hashlib.sha256(p.read_bytes()).hexdigest()==item['sha256']
  key=(m.st_dev,m.st_ino);assert key not in selected;selected[key]=[]
  proofs.append(item|dict(paths=[],links=m.st_nlink,inode=key))
 for base,dirs,names in os.walk(b):
  for n in names:
   p=Path(base)/n;m=p.lstat();key=(m.st_dev,m.st_ino)
   if key in selected:selected[key].append(str(p.relative_to(b)))
 for p in proofs:
  p['paths']=selected[tuple(p.pop('inode'))];assert len(p['paths'])==p['links']
 source=b/'generator-facts-b928-20261117'
 assert(source/'candidate/Lokad.Lython.dll').is_file()and(source/'representative.json').is_file()and(source/'cpython-worker.py').is_file()
 print(json.dumps(proofs))
'''.replace('SUBJECTS',repr(subjects))
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
(r/'first-absent-replica.log').write_bytes((r/'space-proof.log').read_bytes())if(r/'space-proof.log').exists()and not(r/'first-absent-replica.log').exists()else None
p=subprocess.run(ssh+['python3 -'],input=code,text=True,encoding='utf-8',capture_output=True,timeout=60)
(r/'space-proof.log').write_text(p.stdout+p.stderr,encoding='utf-8');assert p.returncode==0,p.stdout+p.stderr
proofs=json.loads(p.stdout)
(r/'retirement-candidates.json').write_text(json.dumps(dict(proofs=proofs,eligibleBytes=sum(p['bytes']for p in proofs),currentImageAndCatalogPreserved=True),indent=2)+'\n',encoding='utf-8')
print(json.dumps(dict(groups=len(proofs),eligibleBytes=sum(p['bytes']for p in proofs))))
