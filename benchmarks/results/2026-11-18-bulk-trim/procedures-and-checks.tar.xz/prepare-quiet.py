from pathlib import Path
import ast,hashlib,json,re,shutil,tarfile
r=Path(__file__).resolve().parent;prior=r.parent/'generator-facts-r503';old=prior/'quiet';q=r/'quiet'
assert(r/'retirement-candidates.json').is_file()
if q.exists():
 assert not(q/'config.json').exists()and not(q/'launch.log').exists()
 q.rename(r/'first-incomplete-preparation')
q.mkdir(exist_ok=False)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
f=json.loads((r/'frozen/identity.json').read_text(encoding='utf-8'))
assert all(sha(r/'frozen'/role/n)==h for role,files in f['imageFiles'].items()for n,h in files.items())
identity=dict(sourceRevision='Qualified62786960 production/5ae019db versus privateR506/'+f['imageFiles']['candidate']['Lokad.Lython.dll'][:8],purpose='Default trim reuses existing bulk ASCII whitespace kernel; complete text normalization and unchanged floating control. No predicted magnitude.',coreSHA256={role:f['imageFiles']['candidate'if role.startswith('candidate')else'reference']['Lokad.Lython.dll']for role in ['reference','reference-control','candidate','candidate-control']},imageFiles=f['imageFiles'],auxiliaryFiles={n:h for n,h in f['imageFiles']['reference'].items()if n!='Lokad.Lython.dll'},sourceInputsArchiveSHA256=sha(r/'candidate-sources.tar.xz'),productionFiles=585,catalogSHA256=f['catalogSHA256'],normalAdapterPin='0.4.0',publicationHeld=True)
(q/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8',newline='\n')
jobs=[['scripts.text-normalization.large','warm'],['scripts.numeric-squared-error.floating.large','warm']]
s=(old/'collect.py').read_text(encoding='utf-8');a=s.index('jobs=');b=s.index('\nenv =',a);s=s[:a]+'jobs='+repr(jobs)+'\nassert len(jobs)==2 and all(case in cases for case,lane in jobs)\n'+s[b:];s=re.sub(r'time.monotonic\(\)-started < \d+','time.monotonic()-started < 150',s);(q/'collect.py').write_text(s,encoding='utf-8',newline='\n')
s=(old/'archive-owned.py').read_text(encoding='utf-8');s=re.sub(r"len\(raw\['jobs'\]\)==\d+","len(raw['jobs'])==2",s);s=re.sub(r'jobs=\d+','jobs=2',s);(q/'archive-owned.py').write_text(s,encoding='utf-8',newline='\n')
remote='/home/lokad/lython-bench-checks/bulk-trim-b930-20261118';unit='lython-b930-bulk-trim-20261118';previous=json.loads((old/'config.json').read_text(encoding='utf-8'))
(q/'run.sh').write_text((old/'run.sh').read_text(encoding='utf-8').replace(previous['root'],remote),encoding='utf-8',newline='\n')
(q/'candidate').mkdir();shutil.copyfile(r/'frozen/candidate/Lokad.Lython.dll',q/'candidate/Lokad.Lython.dll');names=['collect.py','archive-owned.py','run.sh','identity.json','candidate/Lokad.Lython.dll']
with tarfile.open(q/'payload.tgz','w:gz')as a:
 for n in names:a.add(q/n,arcname=n)
c=dict(root=remote,unit=unit,source=previous['root'],sourceRole='candidate',sourceFiles=f['imageFiles']['reference'],sourceCatalogSHA256=f['catalogSHA256'],catalogSHA256=f['catalogSHA256'],identity=identity,retireGroups=json.loads((r/'retirement-candidates.json').read_text(encoding='utf-8'))['proofs'],payloadBytes=(q/'payload.tgz').stat().st_size,payloadSHA256=sha(q/'payload.tgz'),unpackedBytes=sum((q/n).stat().st_size for n in names))
(q/'config.json').write_text(json.dumps(c,indent=2)+'\n',encoding='utf-8',newline='\n')
s=(old/'remote-launch.py').read_text(encoding='utf-8');a=s.index('c=');b=s.index('\nb=Path(',a);s=s[:a]+'c='+repr(c)+s[b:];s=re.sub(r'RuntimeMaxSec=\d+','RuntimeMaxSec=210',s);s=re.sub('lython-b[0-9]+-fixtures','lython-b930-fixtures',s);(q/'remote-launch.py').write_text(s,encoding='utf-8',newline='\n')
s=(prior/'launch.py').read_text(encoding='utf-8');s=re.sub(r'seconds=\d+','seconds=165',s).replace('before230seconds','before165seconds').replace('Four-job generator-fact source pair','Two-job bulk-trim source pair');(r/'launch.py').write_text(s,encoding='utf-8',newline='\n')
s=(old/'retrieve.py').read_text(encoding='utf-8');s=re.sub(r"\['jobs'\]==\d+","['jobs']==2",s).replace('B928','B930');(q/'retrieve.py').write_text(s,encoding='utf-8',newline='\n')
s=(prior/'summarize.py').read_text(encoding='utf-8');s=re.sub(r"len\(raw\['jobs'\]\)==\d+","len(raw['jobs'])==2",s);(r/'summarize.py').write_text(s,encoding='utf-8',newline='\n')
for p in list(q.glob('*.py'))+[r/'launch.py',r/'summarize.py']:ast.parse(p.read_text(encoding='utf-8'))
actual=next(ast.literal_eval(n.value)for n in ast.parse((q/'collect.py').read_text(encoding='utf-8')).body if isinstance(n,ast.Assign)and any(isinstance(t,ast.Name)and t.id=='jobs'for t in n.targets));assert actual==jobs
assert "['jobs']==2"in(q/'retrieve.py').read_text(encoding='utf-8')and "len(raw['jobs'])==2"in(r/'summarize.py').read_text(encoding='utf-8')and "len(raw['jobs'])==2"in(q/'archive-owned.py').read_text(encoding='utf-8')
print(json.dumps(dict(prepared=True,jobs=2,cap=150,serviceCap=210,unpackedBytes=c['unpackedBytes'],exactCommittedReplicas=sum(p['bytes']for p in c['retireGroups']))))
