from pathlib import Path
import json
r=Path(__file__).resolve().parent;d=json.loads((r/'delivery/dispatch.json').read_text(encoding='utf-8'))
s=(r.parent/'generator-facts-r503/finish-delivery.py').read_text(encoding='utf-8')
s=s.replace('44201668746',str(d['run'])).replace('627869602c4fbd581ba25267630923265c0f74e9',d['head']).replace('4831','4837')
s=s.replace('all585ProductionInputsMatchMeasured5ae019db','all585ProductionInputsMatchMeasured65fcf7d0').replace('benchmarks/results/2026-11-17-generator-field-facts/delivery','benchmarks/results/2026-11-18-bulk-trim/delivery')
(r/'finish-delivery.py').write_text(s,encoding='utf-8',newline='\n')
print('Prepared16summary/2386input/585production verifier against measured65fc; awaits actual GREEN terminal.')
