from pathlib import Path
import json,os,subprocess
r=Path(__file__).resolve().parent;work=Path('D:/code/Lython/.git/agent-worktrees/bulk-trim-r506');d=Path('C:/Users/JoannesVermorel/.dotnet11/dotnet.exe')
env=os.environ.copy();env.update(DOTNET_ROOT=str(d.parent),DOTNET_ROOT_X64=str(d.parent));env['PATH']=str(d.parent)+os.pathsep+env['PATH']
parts=['ExpandedStringArgument','AsyncMidFlightCancellation','AgentCompatibilityBaseline','TextWindowValue','StringOwnershipAdmission','StringSearchWindow']
records=[]
for tfm in ['net11.0','net10.0']:
 cmd=[str(d),'test','tests/Lokad.Lython.PublicApi.Tests/Lokad.Lython.PublicApi.Tests.csproj','-c','Release','-f',tfm,'--no-build','--filter','('+'|'.join('FullyQualifiedName~'+p for p in parts)+')&Category!=Stress']
 path=r/('extra-public-'+tfm+'.log')
 with path.open('w',encoding='utf-8')as log:p=subprocess.run(cmd,cwd=work,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=180)
 records.append(dict(framework=tfm,command=cmd,exitCode=p.returncode));(r/'extra-checks.json').write_text(json.dumps(records,indent=2)+'\n',encoding='utf-8')
 assert p.returncode==0,path.read_text(encoding='utf-8');print(tfm,path.read_text(encoding='utf-8').splitlines()[-1],flush=True)
