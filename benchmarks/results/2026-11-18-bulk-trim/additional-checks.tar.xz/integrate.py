from pathlib import Path
import hashlib,json,shutil,tarfile
r=Path(__file__).resolve().parent;repo=Path('D:/code/Lython');work=repo/'.git/agent-worktrees/bulk-trim-r506';out=repo/'benchmarks/results/2026-11-18-bulk-trim'
f=json.loads((r/'frozen/identity.json').read_text(encoding='utf-8'))
assert all(hashlib.sha256((work/n).read_bytes()).hexdigest()==h for n,h in f['sourceInputs'].items())
extra=json.loads((r/'extra-checks.json').read_text(encoding='utf-8'));assert len(extra)==2 and all(x['exitCode']==0 for x in extra)
for n in ['src/Lokad.Lython/Runtime/Text/PyStringOps.Helpers.cs','tests/Lokad.Lython.Tests/StringStripStorageTests.cs']:
    (repo/n).write_bytes((work/n).read_bytes());assert hashlib.sha256((repo/n).read_bytes()).hexdigest()==f['sourceInputs'][n]
shutil.copyfile(r/'extra-checks.json',out/'extra-checks.json')
with tarfile.open(out/'additional-checks.tar.xz','w:xz')as a:
    for n in ['extra-checks.py','extra-checks.json','extra-public-net11.0.log','extra-public-net10.0.log','integrate.py']:a.add(r/n,arcname=n)
p=out/'README.md';s=p.read_text(encoding='utf-8').replace('Actual11/10 each429internal/29public focused checks pass; six exact-worker goldens,','Actual11/10 each429internal/29public focused checks, plus78public text/ownership/\nasynchronous cancellation regressions per target pass; six exact-worker goldens,');p.write_text(s,encoding='utf-8',newline='\n')
p=repo/'PLAN.md';s=p.read_text(encoding='utf-8');a=s.index('3. R506 bounded');b=s.index('4. Select',a)
s=s[:a]+'''3. R506 retained/integrated, full qualification batched at next coherent boundary:
   default trim reuses split's existing bounded managed ASCII scanner. No new
   opcode/cache/owner/policy. Both targets429internal/29public plus78public text/
   ownership/actual async cancellation; sixgoldens/reuse pass. B93080.34s: textwarm
   1.38–2.19%lower elapsed/supportingCPU/stablecontrols, allocation/peaks unchanged.
   Floating+0.52..+5.25%elapsed/CPU0..+5.42%with4.04%reference spread remains debt.
   Retain modest consistent consolidation, no universal/substantial-total claim.
   [Source/decision](benchmarks/results/2026-11-18-bulk-trim/README.md).
'''+s[b:]
p.write_text(s,encoding='utf-8',newline='\n')
print('Exact measured runtime/test source integrated; focused checks complete, full delivery batched.')
