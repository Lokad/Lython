using System.Collections;
using System.Reflection;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using Lokad.Lython;
using Lokad.Lython.Utf8Regex;

const BindingFlags all = BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic;
object Field(object value, string field) => value.GetType().GetField(field, all)!.GetValue(value)!;
object Prop(object value, string property) => value.GetType().GetProperty(property, all)!.GetValue(value)!;
var rows = new List<object>();
var shared = args[0] == "candidate";
using var catalog = JsonDocument.Parse(File.ReadAllText(args[1], Encoding.UTF8));
var budget = new LythonMemoryBudget(32 * 1024 * 1024);
var engine = new LythonEngine(Utf8RegexProvider.Instance);
foreach (var item in catalog.RootElement.GetProperty("cases").EnumerateArray())
{
    var id = item.GetProperty("id").GetString()!;
    var source = item.GetProperty("source").GetString()!;
    long[] samples = new long[11];
    for (int i = 0; i < 6 + samples.Length; i++)
    {
        var before = GC.GetAllocatedBytesForCurrentThread();
        using (var script = engine.Compile(source, budget))
        {
            if (!script.IsValid) throw new InvalidDataException(string.Join("\n", script.Diagnostics));
        }
        var bytes = GC.GetAllocatedBytesForCurrentThread() - before;
        if (i >= 6) samples[i - 6] = bytes;
        if (budget.ReservedBytes != 0) throw new InvalidOperationException("Compilation owner did not return to baseline.");
    }
    int? lookupBytes = null;
    bool? sameBacking = null;
    long retained;
    using (var script = engine.Compile(source, budget))
    {
        if (!script.IsValid) throw new InvalidDataException(string.Join("\n", script.Diagnostics));
        retained = budget.ReservedBytes;
        if (id.StartsWith("diagnostic.regex-literal-", StringComparison.Ordinal))
        {
            var runtime = Field(script, "_runtime");
            var programs = Field(runtime, "_regexPrograms");
            var programKeys = (IEnumerable)Prop(Field(programs, "_entries"), "Keys");
            var key = programKeys.Cast<object>().Single();
            var lookup = (byte[])Field(Prop(key, "Pattern"), "_utf8");
            var code = Prop(Field(script, "_executable"), "EntryPoint");
            var constant = ((IEnumerable)Prop(code, "Constants")).Cast<object>()
                .Where(value => value?.GetType().Name == "PyString")
                .Single(value => ((byte[]?)Field(value, "_utf8"))?.Length == lookup.Length);
            var encoded = (byte[])Field(constant, "_utf8");
            if (ReferenceEquals(constant, Prop(key, "Pattern")) || !lookup.AsSpan().SequenceEqual(encoded) ||
                ReferenceEquals(lookup, encoded) != shared)
                throw new InvalidDataException("Unexpected literal/key backing or wrapper identity.");
            lookupBytes = lookup.Length;
            sameBacking = Shared(lookup, encoded);
        }
    }
    if (budget.ReservedBytes != 0) throw new InvalidOperationException("Retained owner did not return to baseline.");
    rows.Add(new { id, lookupBytes, sameBacking, retained, samples });
}
Console.WriteLine(JsonSerializer.Serialize(new {
    core = Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(typeof(LythonEngine).Assembly.Location))).ToLowerInvariant(),
    rows
}, new JsonSerializerOptions { WriteIndented = true }));

static bool Shared(byte[] first, byte[] second) => ReferenceEquals(first, second);
