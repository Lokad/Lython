from pathlib import Path
import hashlib,json,shutil,subprocess

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
up=lab.with_name('arithmetic-call-cpython-20261125')
report=lab.with_name('formatted-report-cpython-20261125')
read=lambda f:json.loads(f.read_text(encoding='utf-8-sig'))
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
s=lambda b:hashlib.sha256(b.encode('utf-8')).hexdigest()
def save(f,obj): f.write_text(json.dumps(obj,indent=2,ensure_ascii=False)+'\n',encoding='utf-8',newline='\n')
prior=read(up/'external/identity.json')
reference=prior['sourceRevision']
base=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo).decode().strip()
assert subprocess.check_output(['git','diff','--name-only',reference,base,'--','src','tests','benchmarks/Lokad.Lython.Benchmarks'],cwd=repo)==b''
delta=subprocess.check_output(['git','diff','--binary','HEAD','--','src'],cwd=repo)
assert delta.count(b'diff --git ')==4
(lab/'candidate.patch').write_bytes(delta)
frozen=prior['imageFiles']['candidate']
assert len(frozen)==32 and {f.name:sha(f) for f in (up/'candidate').iterdir()}==frozen
core=lab/'bench/bin/Lokad.Lython/release_net11.0/Lokad.Lython.dll'
assert sha(core)==sha(lab/'bench/bin/Lokad.Lython.Benchmarks/release_net11.0/Lokad.Lython.dll')
images=dict(reference=frozen,candidate=frozen|{core.name:sha(core)})
for role,files in images.items():
    dst=lab/role
    dst.mkdir(exist_ok=True)
    for name in files: shutil.copyfile(core if name==core.name and role=='candidate' else up/'candidate'/name,dst/name)
    assert {f.name:sha(f) for f in dst.iterdir()}==files
catalog=read(up/'external/representative.json')
ordinary=catalog['cases'][0]
assert ordinary['id']=='diagnostic.generated-ordinary-definitions'
manifest,=[c for c in read(report/'external/representative.json')['cases'] if c['id']=='scripts.file-manifest.small']
cases=[]
for n in [128,4096]:
    fixture=json.dumps(dict(size=n,text=None),separators=(',',':'))
    text='ŵ'*n
    source="import re\npattern = re.compile('"+text+"')\nprint(len(pattern.pattern), pattern.groups)\n"
    result=f'{n} 0\n'
    cases.append(dict(id=f'diagnostic.regex-literal-{n}',family='diagnostic.regex-literal',category='regex',scale='small',
        size=n,source=source,fixtureJson=fixture,expectedOutput=result,sourceUtf8Bytes=len(source.encode('utf-8')),
        expectedOutputUtf8Bytes=len(result.encode('utf-8')),fixtureTextUtf8Bytes=0,fixtureTextCodePoints=0,
        sourceSha256=s(source),fixtureSha256=s(fixture),expectedOutputSha256=s(result)))
catalog['cases']=cases+[manifest,ordinary]
save(lab/'representative.json',catalog)
save(lab/'identity.json',dict(reference=reference,sourceRevision=base,sourcePatchSHA256=sha(lab/'candidate.patch'),
    catalogSHA256=sha(lab/'representative.json'),imageFiles=images,coreSHA256={role:files[core.name] for role,files in images.items()},
    cpythonWorkerSHA256=prior['cpythonWorkerSHA256']))
shutil.copyfile(lab.with_name('native-call-construction-20261125')/'RouteProbe.csproj',lab/'RouteProbe.csproj')
