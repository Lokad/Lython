from pathlib import Path
from statistics import median
import hashlib,json,re,shutil,tarfile

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
initial=lab.with_name('regex-shared-literal-20261125')
out=repo/'benchmarks/results/2026-11-25-shared-regex-literals'
out.mkdir(exist_ok=True)
read=lambda f:json.loads(f.read_text(encoding='utf-8-sig'))
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
data={}
for stage,path,wanted,counts in [('initial',initial,4,(740,87)),('refined',lab,5,(1434,196))]:
    identity=read(path/'identity.json')
    assert sha(path/'candidate.patch')==identity['sourcePatchSHA256']
    assert sha(path/'representative.json')==identity['catalogSHA256']
    results={}
    for role,files in identity['imageFiles'].items():
        assert len(files)==32 and {f.name:sha(f)for f in (path/role).iterdir()}==files
        check=read(path/(role+'-verify.json'))
        assert check['state']=='Completed' and check['caseCount']==wanted
        assert check['catalogSha256']==identity['catalogSHA256']
        assert check['launched']['library']['sha256']==identity['coreSHA256'][role]
        r=read(path/(role+'-allocations.json'))
        assert r['core']==identity['coreSHA256'][role] and len(r['rows'])==wanted
        results[role]=r['rows']
    entries=[]
    for a,b in zip(results['reference'],results['candidate'],strict=True):
        assert a['id']==b['id'] and a['retained']==b['retained']
        assert len(a['samples'])==len(b['samples'])==11
        if a['lookupBytes'] is not None:
            assert a['lookupBytes']==b['lookupBytes'] and a['sameBacking'] is False and b['sameBacking'] is True
        entries.append(dict(id=a['id'],sharedBytes=b['lookupBytes'],
            referenceBytes=median(a['samples']),candidateBytes=median(b['samples']),
            retainedAdmission=a['retained']))
    for suite,expected in zip(('Lokad.Lython.PublicApi.Tests','Lokad.Lython.Tests'),counts,strict=True):
        for platform in ('win11','ubuntu10'):
            p=path/f'{suite}-{platform}.log'
            assert re.search(rf'Failed:\s+0, Passed:\s+{expected},',p.read_text(encoding='utf-8-sig'))
    data[stage]=entries
    shutil.copyfile(path/'identity.json',out/(stage+'-identity.json'))
(out/'allocation-summary.json').write_text(json.dumps(data,indent=2)+'\n',encoding='utf-8',newline='\n')
with tarfile.open(out/'observations.tar.xz','w:xz') as bundle:
    files = ['identity.json','candidate.patch','representative.json',
        'reference-verify.json','candidate-verify.json','reference-allocations.json',
        'candidate-allocations.json','prepare.py','Program.cs','RouteProbe.csproj','bench-build.log','probe-build.log',
        'test-ubuntu.sh','Lokad.Lython.PublicApi.Tests-win11.log','Lokad.Lython.Tests-win11.log',
        'Lokad.Lython.PublicApi.Tests-ubuntu10.log','Lokad.Lython.Tests-ubuntu10.log']
    for stage,path in [('initial',initial),('refined',lab)]:
        additions=['initial-verify.log','initial-representative.json'] if stage=='initial' else ['package-evidence.py']
        for f in files+additions:
            bundle.add(path/f,arcname=stage+'/'+f,recursive=False)
print(json.dumps(data,indent=2))
