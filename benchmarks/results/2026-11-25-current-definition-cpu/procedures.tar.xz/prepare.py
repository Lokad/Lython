from pathlib import Path
import hashlib,json,os,subprocess
lab=Path(__file__).resolve().parent; repo=lab.parents[3]
source=lab.with_name('shared-map-operands-refined-20261125'); quiet=source/'comparison/quiet'
external=lab.with_name('ordinary-defaults-cpython-20261125')/'external'
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
save=lambda p,d:p.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
git=lambda args:subprocess.check_output(['git',*args],cwd=repo)
production=git(['rev-parse','a39d00228']).decode().strip(); donor=read(quiet/'identity.json')
patch=git(['diff','--binary',donor['sourceRevision'],production,'--','src'])
assert patch==(source/'candidate.patch').read_bytes() and hashlib.sha256(patch).hexdigest()==donor['sourcePatchSHA256']
assert not git(['diff','--name-only',production,'--','src','benchmarks/Lokad.Lython.Benchmarks','benchmarks/cpython-worker.py','global.json'])
receipt=read(quiet/'terminal-status.json')['receipt']; assert receipt['complete'] and receipt['allWorkersJoined'] and sha(quiet/'observations.tar.xz')==receipt['archiveSHA256']
catalog=read(external/'representative.json'); ordinary='diagnostic.generated-ordinary-definitions'; rules='scripts.rule-default-closures'
catalog['cases']=[r for r in catalog['cases'] if r['id'] in (ordinary,rules)]; assert len(catalog['cases'])==2
save(lab/'catalog.json',catalog)
files=donor['imageFiles']['candidate']; folder=source/'candidate'
identity=dict(sourceRevision=production,measurementReference=production,sourcePatchSHA256=donor['sourcePatchSHA256'],imageFiles={'candidate':files},coreSHA256={'candidate':files['Lokad.Lython.dll']},
    cpythonWorkerSHA256=donor['cpythonWorkerSHA256'],profiles=[['ordinary-warm',ordinary,'candidate'],['defaulted-rules-warm',rules,'candidate']],
    purpose='Compare ordinary and defaulted-rule definition and call CPU on the retained runtime',donorArchiveSHA256=receipt['archiveSHA256'],profileCatalogSHA256=sha(lab/'catalog.json'))
save(lab/'identity.json',identity); save(lab/'verified-raw-replicas.json',[])
sdk=Path.home()/'.dotnet11'; dotnet=sdk/'dotnet.exe'; env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk)); protocol=repo/'benchmarks/cpython-worker.py'
proof=lab/'candidate-verification.json'
assert sha(protocol)==identity['cpythonWorkerSHA256'] and len(files)==32 and {p.name:sha(p) for p in folder.iterdir()}==files
subprocess.run([dotnet,folder/'Lokad.Lython.Benchmarks.dll','--compare','verify','--catalog',lab/'catalog.json',
    '--dotnet',dotnet,'--python','C:/Python313/python.exe','--python-worker',protocol,'--out',proof],env=env,cwd=repo,check=True,timeout=65)
checked=read(proof); assert checked['state']=='Completed' and checked['caseCount']==2 and checked['catalogSha256']==identity['profileCatalogSHA256']
assert checked['launched']['library']['sha256']==files['Lokad.Lython.dll']
