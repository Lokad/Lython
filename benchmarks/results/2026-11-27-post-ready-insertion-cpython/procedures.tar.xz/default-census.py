from pathlib import Path
from hashlib import sha256
import json
import os
import shutil
import subprocess

lab=Path(__file__).resolve().parent
notes=lab.parent
out=lab/'defaults-census'
out.mkdir()
frame_identity=json.loads((lab/'comparison/quiet/identity.json').read_text(encoding='utf8'))
old=notes/'private-compiler-slots-20261127'/'probe/bin/Release/net11.0'
worker=notes/'direct-prepared-inserts-20261127'/'local/candidate'
core='Lokad.Lython.dll'
files=frame_identity['imageFiles']['candidate']
assert {p.name:sha256(p.read_bytes()).hexdigest() for p in worker.iterdir()}==files
for name in ('CompilerFacts.dll','CompilerFacts.deps.json','CompilerFacts.runtimeconfig.json'):
    shutil.copyfile(old/name,out/name)
shutil.copyfile(worker/core,out/core)
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
ordinary='diagnostic.generated-ordinary-definitions'
escaping='scripts.rule-default-closures'
cases={}
for catalog in (lab/'comparison/quiet/representative.json',notes/'final-default-slots-20261127'/'local/representative.json'):
    for case in read(catalog)['cases']:
        key=case['id']
        if key in (ordinary,escaping):
            assert key not in cases or case['sourceSha256']==cases[key]['sourceSha256']
            cases[key]=case
source=out/'catalog.json'
source.write_text(json.dumps({'cases':list(cases.values())},indent=2)+'\n',encoding='utf8',newline='\n')
sdk=Path.home()/'.dotnet11'
dotnet=sdk/'dotnet.exe'
result=out/'compiler-facts.json'
subprocess.run([dotnet,out/'CompilerFacts.dll',source,result],env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk)),check=True,timeout=40)
rows=[]
for case in read(result):
    name={'diagnostic.generated-ordinary-definitions':'build','scripts.rule-default-closures':'make_rules'}.get(case['id'])
    if name is None:continue
    frame=next(r for r in case['tape'] if r['name']==name)
    steps=frame['steps']
    starts={}
    for index, step in enumerate(steps):
        if step['op']=='StartFunctionDefaults':
            assert step['primary'] not in starts
            starts[step['primary']]=index
    active=set()
    for index in frame['deferred'] or ():
        step=steps[index]
        assert step['op']=='ApplyDeferredDefinition' and step['primary'] in starts
        interval=set(range(starts[step['primary']],index+1))
        assert active.isdisjoint(interval)
        active.update(interval)
    peak=max(step['extent'] for step in steps)
    unaffected=max(step['extent'] for i,step in enumerate(steps) if i not in active)
    rows.append(dict(case=case['id'],name=name,capacity=frame['capacity'],localSlots=len(frame['locals']),
        actualPeakExtent=peak,peakOutsideDeferredDefaults=unaffected,
        starts=len(starts),deferred=len(frame['deferred'] or []),
        survivingPeakInstructions=[dict(index=i,operation=step['op'],span=step['span']) for i,step in enumerate(steps) if i not in active and step['extent']==unaffected]))
proof=dict(sourceRevision=frame_identity['sourceRevision'],coreSha256=files[core],obtainedFrom='Read-only instruction and storage snapshot',rows=rows)
(out/'census.json').write_text(json.dumps(proof,indent=2)+'\n',encoding='utf8',newline='\n')
for row in rows:
    print(row['name'],row['capacity'],row['localSlots'],row['actualPeakExtent'],row['peakOutsideDeferredDefaults'],row['starts'],row['deferred'])
