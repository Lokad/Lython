from hashlib import sha256
from pathlib import Path
import json
import os
import shutil
import subprocess
import tarfile

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
notes=lab.parent
previous=notes/'post-csv-json-cpython-20261127'
prior=previous/'comparison/quiet'
donor=notes/'direct-prepared-inserts-20261127'/'comparison/quiet'
image=donor.parent.parent/'local/candidate'
quiet=lab/'comparison/quiet'
quiet.mkdir(parents=True)
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:sha256(p.read_bytes()).hexdigest()
write=lambda p,v:p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf8',newline='\n')
donor_identity=read(donor/'identity.json')
files=donor_identity['imageFiles']['candidate']
assert len(files)==32 and {p.name:sha(p) for p in image.iterdir()}==files
revision=subprocess.check_output(['git','rev-parse','9cee6f423'],cwd=repo,text=True).strip()
assert not subprocess.check_output(['git','diff',revision,'--','src','benchmarks/Lokad.Lython.Benchmarks'],cwd=repo)
patch=subprocess.check_output(['git','diff','--binary','4919f6748',revision,'--','src'],cwd=repo)
assert sha256(patch).hexdigest()==donor_identity['sourcePatchSHA256']
terminal=read(donor/'terminal-status.json')
receipt=terminal['receipt']
assert not terminal['live'] and receipt['complete'] and receipt['quietBeforeAndAfter']
assert sha(donor/'observations.tar.xz')==receipt['archiveSHA256']
base=read(prior/'representative.json')
reports=read(donor/'representative.json')
text=read(notes/'dictreader-json-control-20261127'/'comparison/quiet/representative.json')
wide='diagnostic.shipment-starmap-wide-lists'
bound='diagnostic.shipment-bound-starmap'
map_case='diagnostic.shipment-file-fed-map'
json_case='diagnostic.nested-json-document'
text_case='diagnostic.text-summary.nonlocal-computed-width.large'
factory='diagnostic.generated-ordinary-definitions'
assert next(c for c in reports['cases'] if c['id']==wide)==next(c for c in base['cases'] if c['id']==wide)
assert next(c for c in text['cases'] if c['id']==json_case)==next(c for c in base['cases'] if c['id']==json_case)
cases={row['id']:row for catalog in (base,reports,text) for row in catalog['cases']}
jobs=[[wide,'warm-async'],[factory,'compile'],[bound,'warm-async'],[map_case,'warm-async'],[json_case,'warm'],[wide,'warm'],[text_case,'warm'],[factory,'compile-run']]
base['cases']=[cases[key] for key in dict.fromkeys(key for key,lane in jobs)]
assert len(base['cases'])==6
write(quiet/'representative.json',base)
write(quiet/'jobs.json',jobs)
for name in ('cpython-worker.py','run.sh','summarize.py'):
    shutil.copyfile(prior/name,quiet/name)
assert sha(quiet/'cpython-worker.py')==donor_identity['cpythonWorkerSHA256'] and b'\r' not in (quiet/'run.sh').read_bytes()
root='post-ready-insertion-cpython-b1849-20261127'
identity=dict(sourceRevision=revision,productionSource=revision,comparisonHostRevision=donor_identity['comparisonHostRevision'],
    frozenImage=f'/home/lokad/lython-bench-checks/{root}/candidate', auxiliaryFiles=files,overlay=[],imageFiles={'candidate':files},
    coreSHA256={role:files['Lokad.Lython.dll'] for role in ('candidate','candidate-control')},
    catalogs={name:{'sha256':sha(quiet/name)} for name in ('representative.json','jobs.json')},
    expectedCPythonSHA256=donor_identity['expectedCPythonSHA256'],cpythonWorkerSHA256=donor_identity['cpythonWorkerSHA256'],
    donorArchiveSHA256=receipt['archiveSHA256'],sourcePatchSHA256=donor_identity['sourcePatchSHA256'],
    purpose='Compare delivered CSV and display paths, nested JSON, Unicode text and ordinary compilation against CPython.')
write(quiet/'identity.json',identity)
collector=(prior/'collect.py').read_text(encoding='utf8').replace('lython-b1844-fixtures','lython-b1849-fixtures')
compile(collector,'collect.py','exec')
(quiet/'collect.py').write_text(collector,encoding='utf8',newline='\n')
ssh=(previous/'quiet-vm.py').read_text(encoding='utf8')
ssh=ssh.replace('lython-b1844-current-cpython-20261127','lython-b1849-current-cpython-20261127').replace("proof['caseCount']==7","proof['caseCount']==6")
compile(ssh,'quiet-vm.py','exec')
(lab/'quiet-vm.py').write_text(ssh,encoding='utf8',newline='\n')
sdk=Path.home()/'.dotnet11'; dotnet=sdk/'dotnet.exe'
verification=quiet/'candidate-verify.json'
subprocess.run([dotnet,image/'Lokad.Lython.Benchmarks.dll','--compare','verify','--catalog',quiet/'representative.json',
    '--dotnet',dotnet,'--python','C:/Python313/python.exe','--python-worker',quiet/'cpython-worker.py','--out',verification],
    env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk)),check=True,timeout=65)
proof=read(verification)
assert proof['state']=='Completed' and proof['caseCount']==6 and proof['catalogSha256']==identity['catalogs']['representative.json']['sha256']
assert proof['launched']['adapter']['sha256']==files['Lokad.Lython.Benchmarks.dll']
assert proof['launched']['library']['sha256']==files['Lokad.Lython.dll']
names=['identity.json','representative.json','jobs.json','cpython-worker.py','run.sh','collect.py']
payload=quiet/'stage.tar.gz'
with tarfile.open(payload,'w:gz') as archive:
    for name in names: archive.add(quiet/name,arcname=name)
staged={name:dict(length=(quiet/name).stat().st_size,sha256=sha(quiet/name)) for name in names}
write(quiet/'upload.json',dict(root=root,donor=read(donor/'upload.json')['root'],donorFiles=files,donorArchive=receipt['archiveSHA256'],
    payloadSHA256=sha(payload),files=staged,expandedBytes=sum(x['length'] for x in staged.values()),minimumAfterStageBytes=6*1024*1024))
