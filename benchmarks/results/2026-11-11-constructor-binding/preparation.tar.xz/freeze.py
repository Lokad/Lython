from pathlib import Path
import hashlib,json,shutil,subprocess
r=Path(__file__).resolve().parent;repo=Path.cwd();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
before=json.loads((r/'before.json').read_text(encoding='utf-8'))
changed=subprocess.check_output(['git','diff','--name-only','--','src/Lokad.Lython'],text=True,stderr=subprocess.DEVNULL).splitlines()
assert set(changed)=={'src/Lokad.Lython/Runtime/PyType.cs','src/Lokad.Lython/Runtime/LythonRuntime.Executable.Calls.cs'}
for p,h in before['sourceHashes'].items():
    if p not in changed:assert sha(repo/p)==h,p
shutil.copyfile(repo/'src/Lokad.Lython/bin/Release/net11.0/Lokad.Lython.dll',r/'images/candidate/Lokad.Lython.dll')
shutil.copyfile(repo/'src/Lokad.Lython/bin/Release/net10.0/Lokad.Lython.dll',r/'candidate-net10.dll')
identity=dict(beforeRevision=before['sourceRevision'],purpose=before['purpose'],sourceHashes={p:sha(repo/p)for p in changed},
    images={role:{p.name:sha(p)for p in(r/'images'/role).iterdir()if p.is_file()}for role in ['before','candidate']},
    net10SHA256=sha(r/'candidate-net10.dll'))
for name,h in identity['images']['before'].items():
    if name!='Lokad.Lython.dll':assert identity['images']['candidate'][name]==h,name
assert identity['images']['candidate']['Lokad.Lython.dll']!=identity['images']['before']['Lokad.Lython.dll']
(r/'diagnostic-identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8')
(r/'source.patch').write_bytes(subprocess.check_output(['git','diff'],stderr=subprocess.DEVNULL))
for script in ['focus.py','measure.py','summarize.py']:
    shutil.copyfile(r.parent/'instance-storage-r232'/script,r/script)
print('Two eligibility conditions changed; all other production source and all worker auxiliaries identical.')
