from pathlib import Path
import hashlib,json,shutil,subprocess,tarfile
r=Path(__file__).resolve().parent;out=Path('benchmarks/results/2026-11-11-constructor-binding')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert not out.exists();out.mkdir()
identity=json.loads((r/'diagnostic-identity.json').read_text(encoding='utf-8'))
for p,h in identity['sourceHashes'].items():assert sha(Path(p))==h,p
for role in ['before','candidate']:
 for name,h in identity['images'][role].items():assert sha(r/'images'/role/name)==h,name
for phase in ['warm-sync','warm-async','compile']:
 data=json.loads((r/phase/'measurements.json').read_text(encoding='utf-8'))
 assert data['allGoldensPassed']and data['allBalancesZero']and data['ownedFixturesRemoved']
 shutil.copytree(r/phase,out/phase)
for name in ['before.json','diagnostic-identity.json','catalog.json','focused-checks.json','semantic-cpython-before.json','semantic-cpython-candidate.json']:
 shutil.copyfile(r/name,out/name)
(r/'source.patch').write_bytes(subprocess.check_output(['git','diff','--','src/Lokad.Lython','tests'],stderr=subprocess.DEVNULL))
with tarfile.open(out/'preparation.tar.xz','w:xz')as t:
 for p in sorted(r.iterdir()):
  if p.is_file():t.add(p,arcname=p.name)
 t.add(r/'tests',arcname='tests')
 for role in ['before','candidate']:
  t.add(r/'images'/role/'Lokad.Lython.dll',arcname=role+'-core.dll')
 for name in ['Lokad.Lython.Benchmarks.dll','Lokad.Lython.Benchmarks.deps.json','Lokad.Lython.Benchmarks.runtimeconfig.json','Lokad.Lython.Utf8Regex.dll','Lokad.Utf8Regex.dll','Lokad.Utf8Regex.PythonRe.dll']:
  t.add(r/'images/before'/name,arcname='common-worker/'+name)
with tarfile.open(out/'preparation.tar.xz')as t:
 for role in ['before','candidate']:
  assert hashlib.sha256(t.extractfile(role+'-core.dll').read()).hexdigest()==identity['images'][role]['Lokad.Lython.dll']
files={p.relative_to(out).as_posix():dict(bytes=p.stat().st_size,sha256=sha(p))for p in out.rglob('*')if p.is_file()}
(out/'archive-identity.json').write_text(json.dumps(dict(files=files,sourcePairVerified=True,allGoldensPassed=True,allBalancesZero=True,ownedFixturesRemoved=True,performanceQualified=False),indent=2)+'\n',encoding='utf-8')
print('R233 source pair, original preparation error, all samples, independent semantic checks and focused ownership/cancellation checks preserved.')
