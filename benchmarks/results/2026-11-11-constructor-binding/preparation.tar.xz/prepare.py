from pathlib import Path
import copy, datetime, hashlib, json, shutil, subprocess

r = Path(__file__).resolve().parent
repo = Path.cwd()
assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip() == '752d78ce7ce4ea314f79b15bba15f8c5f0100882'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
old = json.loads((r.parent/'instance-storage-r232/catalog.json').read_text(encoding='utf-8'))
original = old['cases'][0]
keyword = copy.deepcopy(original)
keyword['id'] = 'scripts.csv-validated-records.constructor-keyword.large'
keyword['source'] = keyword['source'].replace('RecordAmount(record).amount','RecordAmount(record=record).amount')
keyword_only = copy.deepcopy(keyword)
keyword_only['id'] = 'scripts.csv-validated-records.constructor-keyword-only.large'
keyword_only['source'] = keyword_only['source'].replace('def __init__(self, record):','def __init__(self, *, record):')
cases = [keyword,keyword_only,original,old['cases'][1],old['cases'][3],old['cases'][5]]
for c in cases:
    raw = c['source'].encode('utf-8')
    c['sourceUtf8Bytes'] = len(raw)
    c['sourceSha256'] = hashlib.sha256(raw).hexdigest()
catalog = dict(old,cases=cases)
assert not (r/'catalog.json').exists()
(r/'catalog.json').write_text(json.dumps(catalog,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
images = {}
core = repo/'src/Lokad.Lython/bin/Release/net11.0/Lokad.Lython.dll'
delivery = json.loads((repo/'benchmarks/results/2026-11-11-default-allocator-admission/delivery-source.json').read_text(encoding='utf-8'))
for role in ['before','candidate']:
    folder = r/'images'/role
    shutil.copytree(r.parent/'instance-storage-r232/images/candidate',folder)
    shutil.copyfile(core,folder/'Lokad.Lython.dll')
    images[role] = {p.name:sha(p) for p in folder.iterdir() if p.is_file()}
for phase in ['warm-sync','warm-async','compile']:
    (r/phase).mkdir()
    shutil.copyfile(r.parent/'instance-storage-r232'/phase/'hash-witness.json',r/phase/'hash-witness.json')
meta = dict(sourceRevision='752d78ce7ce4ea314f79b15bba15f8c5f0100882',createdUTC=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    images=images,sourceHashes={str(p.relative_to(repo)).replace('\\','/'):sha(p) for p in (repo/'src/Lokad.Lython').rglob('*.cs') if not {'bin','obj'}&set(p.parts)},
    catalogSHA256=sha(r/'catalog.json'),deliverySource=delivery,
    purpose='R233 source-level consolidation of constructor entry with existing general function binder. Three complete CSV scripts, unchanged captured/ordinary text and JSON controls. No CPU claim from local diagnostic clocks.')
(r/'before.json').write_text(json.dumps(meta,indent=2)+'\n',encoding='utf-8')
print('Frozen exact752d78ce core plus common fec79 worker, three constructor CSV variants and three unchanged controls.')
