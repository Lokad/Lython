from pathlib import Path
from difflib import unified_diff
import hashlib
import json
import os
import shutil
import subprocess
import zipfile

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
local = lab / 'local'
template = lab.with_name('post-update-arithmetic-routes-20261126')
diag = lab / 'routes'
diag.mkdir()
source = diag / 'source'
snapshot = diag / 'source.zip'
read = lambda p: json.loads(p.read_text(encoding='utf-8'))
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
write = lambda p,s: p.write_text(s,encoding='utf-8',newline='\n')

identity = read(local / 'identity.json')
subprocess.run(['git','archive','--format=zip','--output',snapshot,identity['sourceRevision'],'--','src',
    'Directory.Build.props','Directory.Build.targets','Directory.Build.rsp','Directory.Packages.props','global.json',
    'NuGet.Config'], cwd=repo,check=True)
with zipfile.ZipFile(snapshot) as archive:
    assert all(not Path(name).is_absolute() and '..' not in Path(name).parts for name in archive.namelist())
    archive.extractall(source)
assert sha(lab/'candidate.patch') == identity['sourcePatchSHA256']
subprocess.run(['git','apply','--whitespace=nowarn',lab/'candidate.patch'], cwd=source,check=True)
names = ['LiteralKeywordAllocations','LiteralKeywordValues','LiteralClosedPairMembers']
changes = []
def patch(filename, edits):
    relative = 'src/Lokad.Lython/Runtime/' + filename
    component = source / relative
    original = component.read_text(encoding='utf-8')
    text = original
    for before,after in edits:
        assert text.count(before) == 1, (filename,before)
        text = text.replace(before,after)
    write(component,text)
    changes.extend(unified_diff(original.splitlines(keepends=True),text.splitlines(keepends=True),
                                 'a/'+relative,'b/'+relative))
marker = 'internal sealed partial class LythonRuntime\n{\n'
patch('LythonRuntime.FunctionDefaults.cs', [
    (marker,marker + ''.join(f'    internal static int Diagnostic{name};\n' for name in names)),
    ('            governor.Commit(bytes);\n            return new(positional, keyword);','''            governor.Commit(bytes);
            if (literalKeywords is not null)
            {
                Interlocked.Increment(ref DiagnosticLiteralKeywordAllocations);
                Interlocked.Add(ref DiagnosticLiteralKeywordValues, literalKeywords.Count);
            }
            return new(positional, keyword);'''),
])
patch('LythonRuntime.Executable.PreparedDefinitions.cs', [
    ('        var index = start + 1;\n        var evaluated', '''        if (definition.LiteralKeywordDefaults is not null)
            Interlocked.Increment(ref DiagnosticLiteralClosedPairMembers);
        var index = start + 1;
        var evaluated'''),
])
write(diag/'diagnostic.patch',''.join(changes))
catalog = read(local/'representative.json')
catalog['cases'] = [case | dict(runAsync=mode) for case in catalog['cases'] for mode in (False,True)]
write(diag/'cases.json',json.dumps(catalog,ensure_ascii=False))
program=(template/'Program.cs').read_text(encoding='utf-8')
start=program.index('string[] names = ')
stop=program.index(';',start)+1
write(diag/'Program.cs',program[:start]+'string[] names = '+json.dumps(names)+';'+program[stop:])
shutil.copyfile(template/'RouteProbe.csproj',diag/'RouteProbe.csproj')
frozen=local/'candidate'
assert len(identity['imageFiles']['candidate']) == 32
assert {p.name:sha(p) for p in frozen.iterdir()} == identity['imageFiles']['candidate']
image=diag/'image'
shutil.copytree(frozen,image)
sdk=Path.home()/'.dotnet11'
dotnet=sdk/'dotnet.exe'
settings=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk))
def run(args,log):
    with (diag/log).open('wb') as output:
        subprocess.run([dotnet,*args],stdout=output,stderr=subprocess.STDOUT,env=settings,cwd=repo,check=True,timeout=150)
run(['build',source/'src/Lokad.Lython/Lokad.Lython.csproj','-c','Release','-f','net11.0','--no-incremental','-o',diag/'core'],'build-core.log')
shutil.copyfile(diag/'core/Lokad.Lython.dll',image/'Lokad.Lython.dll')
run(['build',diag/'RouteProbe.csproj','-c','Release','-o',diag/'probe'],'build-probe.log')
for file in (diag/'probe').glob('RouteProbe*'):
    shutil.copyfile(file,image/file.name)
run([image/'RouteProbe.dll',image,diag/'cases.json',diag/'counts.json'],'run.log')
write(diag/'identity.json',json.dumps(dict(sourceRevision=identity['sourceRevision'],sourcePatchSHA256=identity['sourcePatchSHA256'],
    frozenFiles=identity['imageFiles']['candidate'],instrumentedCoreSHA256=sha(image/'Lokad.Lython.dll'),
    patchSHA256=sha(diag/'diagnostic.patch'),caseSHA256=sha(diag/'cases.json')),indent=2)+'\n')
rows=read(diag/'counts.json')['rows']
assert len(rows)==8
for row in rows:
    print(row['id'],row['asynchronous'],row['routes'])
