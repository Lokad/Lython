set -eu
export DOTNET_ROOT="$HOME/.dotnet"
export PATH="$DOTNET_ROOT:$PATH"
lab="$PWD/.git/agent-notes/review-20261031/literal-keyword-defaults-20261126"
log="$lab/Lokad.Lython.PublicApi.Tests-ubuntu10-default-stress.log"
suite=Lokad.Lython.PublicApi.Tests
set +e
dotnet test "tests/$suite/$suite.csproj" -c Release -f net10.0 --no-build --artifacts-path "$lab/ubuntu" --filter 'FullyQualifiedName~FunctionDefaultsAccountingScenarioTests&Category=Stress' > "$log" 2>&1
status=$?
set -e
tail -12 "$log"
exit "$status"