from pathlib import Path
import hashlib
import json
import shutil
import tarfile

lab=Path(__file__).resolve().parent
local=lab/'local'
quiet=lab/'comparison/quiet'
quiet.mkdir(parents=True)
donor=lab.with_name('fixed-row-local-bindings-20261126')
base=donor/'comparison/quiet'
read=lambda p:json.loads(p.read_text(encoding='utf-8'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
write=lambda p,s:p.write_text(s,encoding='utf-8',newline='\n')
save=lambda p,o:write(p,json.dumps(o,indent=2)+'\n')

def replace(source, edits):
    for before,after in edits:
        assert source.count(before)==1,before
        source=source.replace(before,after)
    return source

identity=read(local/'identity.json')
receipt=read(base/'terminal-status.json')['receipt']
assert receipt['complete'] and receipt['archiveSHA256']==sha(base/'observations.tar.xz')
assert identity['imageFiles']['reference']==read(base/'identity.json')['imageFiles']['candidate']
assert len(identity['imageFiles']['candidate'])==32
assert {p.name:sha(p) for p in (local/'candidate').iterdir()}==identity['imageFiles']['candidate']
for name in ('identity.json','representative.json','jobs.json','cpython-worker.py','run.sh'):
    shutil.copyfile(local/name,quiet/name)
collector = replace((base/'collect.py').read_text(encoding='utf-8'), [
    ('lython-b1783-fixtures','lython-b1788-fixtures'),
    ('len(jobs) == 5','len(jobs) == 6'),
])
compile(collector,'collect.py','exec')
write(quiet/'collect.py',collector)
assert b'\r' not in (quiet/'run.sh').read_bytes()
entries=('identity.json','representative.json','jobs.json','collect.py','run.sh','cpython-worker.py')
payload=quiet/'stage.tar.gz'
with tarfile.open(payload,'w:gz',compresslevel=6) as package:
    for name in entries:package.add(quiet/name,arcname=name,recursive=False)
dll=local/'candidate/Lokad.Lython.dll'
save(quiet/'upload.json',dict(root='literal-keyword-defaults-b1788-20261126',payloadSHA256=sha(payload),
    payloadBytes=payload.stat().st_size,expandedBytes=sum((quiet/name).stat().st_size for name in entries),
    coreBytes=dll.stat().st_size,coreSHA256=sha(dll),donorSHA256=receipt['archiveSHA256']))

launcher=replace((donor/'quiet.py').read_text(encoding='utf-8'),[
    ('lython-b1783-fixed-row-local-bindings-20261126','lython-b1788-literal-keyword-defaults-20261126'),
    ('borrowed-loop-iterators-b1782-20261126','fixed-row-local-bindings-b1783-20261126'),
    ("""archive=base/(cfg['root']+'.tar.gz')""","""archive=base/(cfg['root']+'.tar.gz')
core=base/(cfg['root']+'.incoming.dll')"""),
    ('assert not root.exists() and not archive.exists()','assert not root.exists() and not archive.exists() and not core.exists()'),
    ("cfg['payloadBytes']+cfg['expandedBytes']+5*1024*1024","cfg['payloadBytes']+cfg['expandedBytes']+cfg['coreBytes']+5*1024*1024"),
    ("""    subprocess.run(scp+[payload,vm+':'+remote+'/'+configuration['root']+'.tar.gz'],check=True,timeout=90)""",
     """    source_core=lab/'local/candidate/Lokad.Lython.dll'
    assert hashlib.sha256(source_core.read_bytes()).hexdigest()==configuration['coreSHA256']
    subprocess.run(scp+[source_core,vm+':'+remote+'/'+configuration['root']+'.incoming.dll'],check=True,timeout=90)
    subprocess.run(scp+[payload,vm+':'+remote+'/'+configuration['root']+'.tar.gz'],check=True,timeout=90)"""),
    (""" and sha(archive)==cfg['payloadSHA256']""",""" and sha(archive)==cfg['payloadSHA256']
 assert core.resolve()==core and sha(core)==cfg['coreSHA256'] and core.stat().st_size==cfg['coreBytes']"""),
    ('len(frames)==7 and len(set(f.name for f in frames))==7','len(frames)==6 and len(set(f.name for f in frames))==6'),
    ("(root/'new-core.dll').rename(root/'candidate'/'Lokad.Lython.dll')","core.rename(root/'candidate'/'Lokad.Lython.dll')"),
    ('seconds=205','seconds=245'),
])
compile(launcher,'quiet.py','exec')
write(lab/'quiet.py',launcher)
summary = replace((donor/'summarize-quiet.py').read_text(encoding='utf-8'), [
    ("receipt['warmJobs'] == 5","receipt['warmJobs'] == 6"),
    ("len(raw['jobs']) == 5","len(raw['jobs']) == 6"),
    ('timedBatches=140','timedBatches=168'),
])
compile(summary,'summarize.py','exec')
write(lab/'summarize.py',summary)
