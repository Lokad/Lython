from pathlib import Path
import hashlib
import json
import shutil
import subprocess
import tarfile

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
quiet = lab / 'comparison/quiet'
routes = lab / 'routes'
target = repo / 'benchmarks/results/2026-11-26-literal-keyword-defaults'

def read(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

identity = read(quiet / 'identity.json')
summary = read(quiet / 'summary.json')
status = read(quiet / 'terminal-status.json')
receipt = status['receipt']
assert not status['live'] and not status['fixtures'] and status['exitCode'] == '0'
assert all(receipt[key] for key in ('complete', 'quietBeforeAndAfter', 'allWorkersJoined',
                                   'guestFixturesRemoved', 'archivedAndVerifiedUnderLease'))
assert receipt['archiveSHA256'] == digest(quiet / 'observations.tar.xz')
assert receipt['warmJobs'] == 6 and summary['timedBatches'] == 168
assert identity['sourceRevision'] == summary['sourceRevision']
assert digest(lab / 'candidate.patch') == identity['sourcePatchSHA256'] == summary['sourcePatchSHA256']
current_patch = subprocess.check_output(['git', 'diff', '--binary', identity['sourceRevision'],
                                        '--', 'src'], cwd=repo)
assert not current_patch or hashlib.sha256(current_patch).hexdigest() == identity['sourcePatchSHA256']
for role, path in [('reference', lab / 'reference-verify.json'),
                   ('candidate', lab / 'candidate-verify.json'),
                   ('candidate', quiet / 'remote-verify.json')]:
    verification = read(path)
    assert verification['state'] == 'Completed' and verification['caseCount'] == 4
    assert verification['catalogSha256'] == identity['catalogs']['representative.json']['sha256']
    assert verification['launched']['library']['sha256'] == identity['coreSHA256'][role]
route_identity = read(routes / 'identity.json')
assert identity['sourceRevision'] == route_identity['sourceRevision']
assert identity['sourcePatchSHA256'] == route_identity['sourcePatchSHA256']
assert digest(routes / 'diagnostic.patch') == route_identity['patchSHA256']
assert digest(routes / 'cases.json') == route_identity['caseSHA256']
assert len(read(routes / 'counts.json')['rows']) == 8

target.mkdir(exist_ok=True)
for name in ('identity.json', 'summary.json', 'observations.tar.xz', 'terminal-status.json'):
    shutil.copyfile(quiet / name, target / name)
for name in ('candidate.patch', 'allocation-summary.json'):
    shutil.copyfile(lab / name, target / name)
shutil.copyfile(routes / 'counts.json', target / 'routes.json')

with tarfile.open(target / 'procedures.tar.xz', 'w:xz') as archive:
    for name in ('prepare.py', 'prepare.log', 'prepare-quiet.py', 'quiet.py', 'summarize.py',
                 'preserve-duplicate-cores.py', 'archive.py', 'routes.py', 'routes.log',
                 'retrieve.log', 'launch-console.log', 'test-ubuntu.sh', 'stress-ubuntu.sh', 'test.patch',
                 'reference-verify.json', 'candidate-verify.json', 'reference-allocation.json',
                 'candidate-allocation.json', 'cpython-test.log'):
        archive.add(lab / name, arcname=name)
    for path in sorted(lab.glob('Lokad.Lython.*.log')):
        archive.add(path, arcname=path.name)
    for name in ('duplicate-core-preview.json', 'duplicate-core-reclaim.json',
                 'first-custody-preview.json', 'upload.json', 'launch.log',
                 'remote-verify.json', 'observe-not-before'):
        archive.add(quiet / name, arcname='quiet/' + name)
    for name in ('identity.json', 'diagnostic.patch', 'cases.json', 'Program.cs',
                 'RouteProbe.csproj', 'build-core.log', 'build-probe.log', 'run.log'):
        archive.add(routes / name, arcname='routes/' + name)

print(f'Archived {len(list(target.iterdir()))} files in {target}')
