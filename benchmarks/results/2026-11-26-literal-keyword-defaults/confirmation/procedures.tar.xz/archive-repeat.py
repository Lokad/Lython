from pathlib import Path
import hashlib
import json
import shutil
import tarfile

lab = Path(__file__).resolve().parent
first = lab / 'comparison/quiet'
repeat = lab / 'comparison/repeat'
target = lab.parents[3] / 'benchmarks/results/2026-11-26-literal-keyword-defaults/confirmation'
read = lambda p: json.loads(p.read_text(encoding='utf-8'))
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()

status = read(repeat / 'terminal-status.json')
receipt = status['receipt']
assert not status['live'] and not status['fixtures'] and status['exitCode'] == '0'
assert all(receipt[key] for key in ('complete', 'quietBeforeAndAfter', 'allWorkersJoined',
                                   'guestFixturesRemoved', 'archivedAndVerifiedUnderLease'))
assert receipt['archiveSHA256'] == sha(repeat / 'observations.tar.xz')
assert receipt['warmJobs'] == 4 and read(repeat / 'summary.json')['timedBatches'] == 112
original, confirmed = [read(folder / 'identity.json') for folder in (first, repeat)]
assert original.keys() == confirmed.keys()
assert all(original[key] == confirmed[key] for key in original if key != 'catalogs')
assert original['catalogs']['representative.json'] == confirmed['catalogs']['representative.json']

target.mkdir(exist_ok=True)
for name in ('identity.json', 'summary.json', 'observations.tar.xz', 'terminal-status.json'):
    shutil.copyfile(repeat / name, target / name)
with tarfile.open(target / 'procedures.tar.xz', 'w:xz') as archive:
    for name in ('confirm.py', 'summarize-repeat.py', 'archive-repeat.py'):
        archive.add(lab / name, arcname=name)
    for path in sorted(repeat.glob('*.log')):
        archive.add(path, arcname=path.name)
print('Confirmation archived and checked against the original image')
