from pathlib import Path
import hashlib
import json
import os
import subprocess
import sys
import tarfile

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
prior=lab.with_name('json-text-cpython-20261124')
output=lab/'external'
output.mkdir(exist_ok=True)
(profile_donor,remote_donor)=sys.argv[1:]
assert profile_donor in ('fixed-return-ownership-20261124','fixed-result-order-20261124')
assert remote_donor in ('fixed-return-ownership-b1566-20261124','fixed-result-order-b1567-20261124')
donor=lab.with_name(profile_donor)
collection=donor/'comparison/quiet'


def read(path):
    return json.loads(path.read_text(encoding='utf-8'))


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write(path, source):
    path.write_text(source,encoding='utf-8',newline='\n')


def save(path, data):
    write(path,json.dumps(data,indent=2,ensure_ascii=False)+'\n')


metadata=read(donor/'comparison/identity.json')
proof=read(collection/'terminal-status.json')['receipt']
assert proof['complete'] and proof['archivedAndVerifiedUnderLease']
assert digest(collection/'observations.tar.xz')==proof['archiveSHA256']
production=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()
subprocess.run(['git','diff','--exit-code',metadata['candidate'],production,'--','src','tests'],cwd=repo,check=True)
identity=dict(sourceRevision=metadata['candidate'],candidate=metadata['candidate'],productionSource=production,
    imageFiles={'candidate':metadata['imageFiles']['candidate']},
    frozenImage='/home/lokad/lython-bench-checks/runtime-checkpoint-cpython-b1568-20261124/candidate',
    auxiliaryFiles={name:sha for name,sha in metadata['imageFiles']['candidate'].items() if name!='Lokad.Lython.dll'},
    coreSHA256={role:metadata['coreSHA256']['candidate'] for role in ('candidate','candidate-control')},
    expectedCPythonSHA256=metadata['expectedCPythonSHA256'], cpythonWorkerSHA256=metadata['cpythonWorkerSHA256'])
assert len(identity['imageFiles']['candidate'])==32
assert all(digest(donor/'candidate'/name)==expected for name,expected in identity['imageFiles']['candidate'].items())

catalog=read(donor/'comparison/representative.json')
meter=read(lab.with_name('exact-unicode-float-20261124')/'comparison/representative.json')
text_json=read(lab.with_name('json-text-cpython-20261124')/'external/representative.json')
records={case['id']:case for source in (catalog,meter,text_json) for case in source['cases']}
typed='scripts.csv-meter-report.typed-unicode'
explicit='scripts.csv-meter-report.explicit-float'
short='diagnostic.text-summary.nonlocal-computed-width.large'
invoice='scripts.csv-invoice.method-policy.quoted-control'
captured='scripts.captured-rule-closures'
json_export='scripts.json-lines-shipment.expanded-options.large'
case_ids=[typed,explicit,short,invoice,captured,json_export]
catalog['cases']=[records[case] for case in case_ids]
jobs=[[case,'warm'] for case in case_ids]+[[typed,'compile-run'],[short,'compile-run'],[short,'compile']]
save(output/'representative.json',catalog)
save(output/'jobs.json',jobs)
identity['catalogs']={name:{'sha256':digest(output/name)} for name in ('representative.json','jobs.json')}
save(output/'identity.json',identity)

dotnet=Path.home()/'.dotnet11/dotnet.exe'
env=dict(os.environ,DOTNET_ROOT=str(dotnet.parent),DOTNET_ROOT_X64=str(dotnet.parent))
protocol=repo/'benchmarks/cpython-worker.py'
assert digest(protocol)==identity['cpythonWorkerSHA256']
subprocess.run([dotnet,donor/'candidate/Lokad.Lython.Benchmarks.dll','--compare','verify',
    '--catalog',output/'representative.json','--dotnet',dotnet,'--python','C:/Python313/python.exe',
    '--python-worker',protocol,'--out',output/'candidate-verify.json'],env=env,check=True,timeout=90)
verified=read(output/'candidate-verify.json')
assert verified['state']=='Completed' and verified['caseCount']==6
assert verified['catalogSha256']==identity['catalogs']['representative.json']['sha256']
assert verified['launched']['library']['sha256']==identity['coreSHA256']['candidate']

old=lab.with_name('current-rule-closures-cpython-20261124')
collector=(old/'external/collect.py').read_text(encoding='utf-8').replace('b1561-','b1568-')
collector=collector.replace('len(jobs) == 5','len(jobs) == 9').replace('started<300','started<535')
collector=collector.replace('CPython checkpoint for generated rule closures','CPython checkpoint for current CSV, text, JSON and rules')
compile(collector,'collect.py','exec')
write(output/'collect.py',collector)
summary=(old/'external/summarize.py').read_text(encoding='utf-8')
summary=summary.replace('len(raw["jobs"])==5 and receipt["warmJobs"]==5',
    'len(raw["jobs"])==9 and receipt["warmJobs"]==9')
compile(summary,'summarize.py','exec')
write(output/'summarize.py',summary)

launch=(old/'external.py').read_text(encoding='utf-8')
launch=launch.replace('b1561-current-rule-closures-cpython-20261124-corrected','b1568-runtime-checkpoint-cpython-20261124')
launch=launch.replace('current-rule-closures-cpython-b1561-20261124-corrected','runtime-checkpoint-cpython-b1568-20261124')
launch=launch.replace('exact-unicode-float-20261124',profile_donor).replace('exact-unicode-float-b1560-20261124',remote_donor)
launch=launch.replace('seconds=257','seconds=444').replace('RuntimeMaxSec=335','RuntimeMaxSec=570')
compile(launch,'external.py','exec')
write(lab/'external.py',launch)
