from pathlib import Path
import hashlib
import json
import shutil
import tarfile

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
external = lab/'external'
output = repo/'benchmarks/results/2026-11-24-runtime-checkpoint-cpython'
read = lambda path: json.loads(path.read_text(encoding='utf-8'))
digest = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
terminal = read(external/'terminal-status.json')
receipt = terminal['receipt']
assert not terminal['live'] and not terminal['fixtures'] and terminal['exitCode']=='0'
assert all(receipt[k] for k in ('complete','allWorkersJoined','guestFixturesRemoved',
    'quietBeforeAndAfter','archivedAndVerifiedUnderLease'))
assert receipt['warmJobs']==9 and digest(external/'observations.tar.xz')==receipt['archiveSHA256']
identity=read(external/'identity.json')
summary=read(external/'summary.json')
assert identity['candidate']==summary['source'] and summary['source'].startswith('95aa40601') and identity['productionSource'].startswith('8aef89b09')
assert summary['timedBatches']==252 and summary['cpythonExecutableSHA256']==identity['expectedCPythonSHA256']
case_ids=[case['id'] for case in read(external/'representative.json')['cases']]
assert len(case_ids)==6
assert [(row['case'],row['lane']) for row in summary['rows']]==[tuple(job) for job in read(external/'jobs.json')]
assert [item['lane'] for item in summary['rows']]==['warm']*6+['compile-run','compile-run','compile']
local = read(external/'candidate-verify.json')
assert local['state']=='Completed' and local['caseCount']==6
assert local['catalogSha256']==identity['catalogs']['representative.json']['sha256']
assert local['launched']['library']['sha256']==identity['coreSHA256']['candidate']
files = identity['imageFiles']['candidate']
assert len(files)==32 and all(digest(lab.parent/'fixed-result-order-20261124/candidate'/name)==expected for name,expected in files.items())
output.mkdir(exist_ok=True)
for item in ('identity.json','terminal-status.json','observations.tar.xz','summary.json'):
    shutil.copyfile(external/item,output/item)
inputs=('external.py','prepare.py','archive.py','external/summarize.py',
    'external/launch.log','external/candidate-verify.json')
with tarfile.open(output/'procedures.tar.xz','w:xz') as bundle:
    for item in inputs: bundle.add(lab/item,arcname=item)
with tarfile.open(output/'procedures.tar.xz') as bundle:
    assert set(bundle.getnames())==set(inputs)
    assert all(bundle.extractfile(item).read()==(lab/item).read_bytes() for item in inputs)
