from pathlib import Path
from statistics import median
import hashlib
import json
import os
import shutil
import subprocess

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
quiet = lab / 'comparison/quiet'
quiet.mkdir(parents=True, exist_ok=True)

def read(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))

def save(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8', newline='\n')

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def git(*args):
    return subprocess.check_output(['git', *args], cwd=repo)

revision = git('rev-parse', 'HEAD').decode().strip()
assert revision.startswith('cbf8bb3fe')
patch = git('diff', '--binary', revision, '--', 'src')
scope = git('diff', '--name-only', revision, '--', 'src').decode().splitlines()
assert set(scope) == {f'src/Lokad.Lython/Runtime/{name}.cs' for name in
                      ('PyCoreIterators', 'PyIteration', 'PyItertools.Transforms')}, scope
(lab / 'candidate.patch').write_bytes(patch)
(lab / 'tests.patch').write_bytes(git('diff', '--binary', revision, '--', 'tests'))

sdk = Path.home() / '.dotnet11'
dotnet = sdk / 'dotnet.exe'
env = dict(os.environ, DOTNET_ROOT=str(sdk), DOTNET_ROOT_X64=str(sdk))
with (lab / 'frozen-build.log').open('wb') as log:
    subprocess.run([dotnet, 'build', 'src/Lokad.Lython/Lokad.Lython.csproj', '-c', 'Release', '-f', 'net11.0',
                    '--no-incremental', '--artifacts-path', lab / 'image-build'], cwd=repo, env=env,
                   stdout=log, stderr=subprocess.STDOUT, check=True, timeout=180)
assert patch == git('diff', '--binary', revision, '--', 'src')

old = lab.parent / 'direct-json-callback'
affix = lab.parent / 'direct-affix-return-20261126'
donor = affix / 'candidate'
old_hash = read(old / 'diagnostic.json')['images']['after']['Lokad.Lython.dll']
new_core = lab / 'image-build/bin/Lokad.Lython/release_net11.0/Lokad.Lython.dll'
before_core = old / 'after/Lokad.Lython.dll'
assert sha(before_core) == old_hash
donor_identity = read(affix / 'comparison/quiet/identity.json')['imageFiles']['candidate']
assert len(donor_identity) == 32
assert {p.name: sha(p) for p in donor.iterdir()} == donor_identity
images = {}
for role, core in [('reference', before_core), ('candidate', new_core)]:
    image = lab / role
    image.mkdir(exist_ok=True)
    images[role] = donor_identity | {core.name: sha(core)}
    for name in donor_identity:
        shutil.copyfile(core if name == core.name else donor / name, image / name)
    assert {p.name: sha(p) for p in image.iterdir()} == images[role]

catalog = read(lab.parent / 'native-iterator-routing-20261125/comparison/quiet/representative.json')
case_ids = ['diagnostic.shipment-bound-starmap', 'diagnostic.shipment-retained-zip',
            'diagnostic.shipment-routing-callbacks', 'diagnostic.shipment-file-fed-map']
by_id = {row['id']: row for row in catalog['cases']}
catalog['cases'] = [by_id[identifier] for identifier in case_ids]
catalog_path = quiet / 'representative.json'
save(catalog_path, catalog)
worker = repo / 'benchmarks/cpython-worker.py'
copy = quiet / worker.name
shutil.copyfile(worker, copy)
for role, files in images.items():
    proof = lab / f'{role}-verify.json'
    subprocess.run([dotnet, lab / role / 'Lokad.Lython.Benchmarks.dll', '--compare', 'verify', '--catalog', catalog_path,
                    '--dotnet', dotnet, '--python', 'C:/Python313/python.exe', '--python-worker', worker, '--out', proof],
                   cwd=repo, env=env, check=True, timeout=60)
    verification = read(proof)
    assert verification['state'] == 'Completed' and verification['caseCount'] == len(case_ids)
    assert verification['catalogSha256'] == sha(catalog_path)
    assert verification['launched']['library']['sha256'] == files['Lokad.Lython.dll']

identity = dict(sourceRevision=revision, comparisonRevision=revision, sourcePatchSHA256=sha(lab / 'candidate.patch'),
                imageFiles=images, coreSHA256={role: files['Lokad.Lython.dll'] for role, files in images.items()},
                cpythonWorkerSHA256=sha(copy), catalogs={'representative.json': {'sha256': sha(catalog_path)}},
                purpose='Remove short zip tuple publication before starmap callback binding.')
save(quiet / 'identity.json', identity)

alloc_tool = lab.parent / 'json-traversal-20261124/reference'
assert (alloc_tool / 'ValidatedAllocation.dll').is_file()
rows = {}
for role, files in images.items():
    image = lab / f'{role}-allocation'
    image.mkdir(exist_ok=True)
    for name, signature in files.items():
        shutil.copyfile(lab / role / name, image / name)
        assert sha(image / name) == signature
    for source in alloc_tool.glob('ValidatedAllocation*'):
        shutil.copyfile(source, image / source.name)
    output = lab / f'{role}-allocation.json'
    subprocess.run([dotnet, image / 'ValidatedAllocation.dll', image, catalog_path, output], cwd=repo, env=env,
                   check=True, timeout=60)
    rows[role] = read(output)['rows']

summary = []
for before, after in zip(rows['reference'], rows['candidate'], strict=True):
    assert before['id'] == after['id']
    assert before['sharedBudgetBaselineRestored'] and after['sharedBudgetBaselineRestored']
    summary.append(dict(case=before['id'], allocationBytes=[median(r['allocatedBytesPerInvocation']) for r in (before, after)],
                        peakAdmission=[r['peakExecutionMemoryBytes'] for r in (before, after)]))
save(lab / 'allocation-summary.json', summary)
print(json.dumps(summary, indent=2))
