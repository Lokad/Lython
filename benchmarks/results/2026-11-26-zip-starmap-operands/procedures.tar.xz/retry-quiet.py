from datetime import datetime, timedelta, timezone
from pathlib import Path
import hashlib
import json
import os
import shutil
import subprocess

lab = Path(__file__).resolve().parent
quiet = lab / 'comparison/quiet'
failure = lab / 'first-launch'
failure.mkdir()
for name in ('terminal-status.json', 'identity.json', 'launch.log', 'upload.json', 'observe-not-before'):
    shutil.copyfile(quiet / name, failure / name)
shutil.copyfile(lab / 'quiet.py', failure / 'quiet.py')
status = json.loads((failure / 'terminal-status.json').read_text(encoding='utf-8'))
assert not status['live'] and not status['fixtures'] and status['receipt'] is None and status['exitCode'] == '1'
assert "KeyError: 'expectedCPythonSHA256'" in status['journal']

path = quiet / 'identity.json'
before = hashlib.sha256(path.read_bytes()).hexdigest()
identity = json.loads(path.read_text(encoding='utf-8'))
prior = json.loads((lab.parent / 'direct-affix-return-20261126/comparison/quiet/identity.json').read_text(encoding='utf-8'))
identity['expectedCPythonSHA256'] = prior['expectedCPythonSHA256']
data = json.dumps(identity, ensure_ascii=False, indent=2) + '\n'
path.write_text(data, encoding='utf-8', newline='\n')
unit = 'lython-b1749b-direct-zip-starmap-20261126'
configuration = {'before': before, 'identity': data, 'unit': unit}
remote = 'cfg='+repr(configuration)+'''
from pathlib import Path
import fcntl,hashlib,json,subprocess
base=Path.home()/'lython-bench-checks'
root=base/'direct-zip-starmap-b1749-20261126'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert root.resolve()==root and root.is_dir()
with (base/'comparison-vm.lock').open('a') as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 old=subprocess.run(['systemctl','show','lython-b1749-direct-zip-starmap-20261126.service',
  '--property=ActiveState,MainPID,ExecMainStatus'],check=True,capture_output=True,text=True).stdout
 assert 'ActiveState=failed' in old and 'MainPID=0' in old and 'ExecMainStatus=1' in old
 assert not (root/'guest-fixtures').exists() and not (root/'archive-receipt.json').exists()
 assert (root/'exit-code.txt').read_text().strip()=='1'
 identity=json.loads(cfg['identity'])
 bootstrap=root/'identity.json'
 assert sha(bootstrap)==cfg['before']
 python=Path.home()/'lython-bench-toolchains/cpython/3.13.16/bin/python3.13'
 assert sha(python)==identity['expectedCPythonSHA256']
 for role,files in identity['imageFiles'].items():
  assert len(files)==32 and {p.name:sha(p) for p in (root/role).iterdir()}==files
 for name,details in identity['catalogs'].items(): assert sha(root/name)==details['sha256']
 assert sha(root/'cpython-worker.py')==identity['cpythonWorkerSHA256']
 aborted=root/'aborted-before-fixtures'
 assert not aborted.exists()
 aborted.mkdir()
 for name in ('confirmation','exit-code.txt','identity.json'):
  (root/name).rename(aborted/name)
 bootstrap.write_text(cfg['identity'],encoding='utf-8')
subprocess.run(['sudo','-n','systemd-run','--unit='+cfg['unit'],'--property=User=lokad',
 '--property=WorkingDirectory='+str(root),'--property=RuntimeMaxSec=320','--property=TimeoutStopSec=20',
 '--property=KillMode=control-group','/bin/sh',str(root/'run.sh')],check=True)
'''
launch = subprocess.run(['ssh', '-i', os.environ['LYTHON_BENCH_IDENTITY'], '-o', 'BatchMode=yes', '-o', 'ConnectTimeout=12',
                         os.environ['LYTHON_BENCH_HOST'], 'python3 -'], input=remote, encoding='utf-8', check=True, timeout=40)
retrieve = (failure / 'quiet.py').read_text(encoding='utf-8').replace('lython-b1749-direct-zip-starmap-20261126', unit)
(lab / 'quiet.py').write_text(retrieve, encoding='utf-8', newline='\n')
(quiet / 'observe-not-before').write_text((datetime.now(timezone.utc)+timedelta(seconds=263)).isoformat(), encoding='utf-8')
(quiet / 'terminal-status.json').rename(failure / 'initial-terminal-copy.json')
