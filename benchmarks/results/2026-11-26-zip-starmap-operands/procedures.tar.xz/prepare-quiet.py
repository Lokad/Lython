from pathlib import Path
import hashlib
import json
import tarfile

lab = Path(__file__).resolve().parent
quiet = lab / 'comparison/quiet'
prior = lab.parent / 'direct-affix-return-20261126'
template = prior / 'comparison/quiet'
read = lambda p: json.loads(p.read_text(encoding='utf-8-sig'))
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()

def write(path, data):
    path.write_text(data, encoding='utf-8', newline='\n')

def save(path, data):
    write(path, json.dumps(data, ensure_ascii=False, indent=2) + '\n')

jobs = {'warm': [
    ['diagnostic.shipment-bound-starmap', 'warm-async'],
    ['diagnostic.shipment-retained-zip', 'warm-async'],
    ['diagnostic.shipment-bound-starmap', 'warm'],
    ['diagnostic.shipment-routing-callbacks', 'warm'],
    ['diagnostic.shipment-file-fed-map', 'warm-async'],
]}
save(quiet / 'jobs.json', jobs)
identity = read(quiet / 'identity.json')
identity['catalogs']['jobs.json'] = {'sha256': sha(quiet / 'jobs.json')}
identity['coreSHA256'].update({role + '-control': identity['coreSHA256'][role] for role in identity['imageFiles']})
save(quiet / 'identity.json', identity)
for name in ('collect.py', 'run.sh'):
    source = (template / name).read_text(encoding='utf-8-sig').replace('lython-b1746-fixtures', 'lython-b1749-fixtures')
    write(quiet / name, source)
assert b'\r' not in (quiet / 'run.sh').read_bytes()

source = (prior / 'quiet.py').read_text(encoding='utf-8-sig')
source = source.replace('lython-b1746b-direct-affix-return-20261126', 'lython-b1749-direct-zip-starmap-20261126')
source = source.replace('len(frames)==7 and len(set(f.name for f in frames))==7',
                        'len(frames)==8 and len(set(f.name for f in frames))==8')
start = source.index("bytes=shutil.disk_usage(base).free")
end = source.index("assert bytes>cfg['payloadBytes']", start)
source = source[:start] + '''with (base/'comparison-vm.lock').open('a') as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 retired=base/'call-state-b61-20261101'/'payload.tar.gz'
 initial=shutil.disk_usage(base).free
 if retired.is_file():
  assert retired.resolve()==retired and retired.is_relative_to(base) and retired.stat().st_nlink==1
  assert retired.stat().st_size==cfg['replicaBytes'] and sha(retired)==cfg['replicaSHA256']
  assert not (retired.parent/'guest-fixtures').exists()
  retired.unlink()
 bytes=shutil.disk_usage(base).free
 print(json.dumps(dict(freeBeforeUploadBytes=bytes, freeBeforeReclaimBytes=initial,
  verifiedDuplicate=str(retired.relative_to(base)),duplicateSHA256=cfg['replicaSHA256'])))
''' + source[end:]
source = source.replace('print(json.dumps(dict(freeBeforeUploadBytes=bytes)))','')
start = source.index(" donor=base/'native-cursor-stack-b1743-20261126'")
end = source.index(" for role,files in image['imageFiles'].items():", start)
source = source[:start] + ''' donor=base/'direct-affix-return-b1746b-20261126'/'candidate'
 assert donor.resolve()==donor
 donor_receipt=json.loads((donor.parent/'archive-receipt.json').read_text())
 assert donor_receipt['complete'] and donor_receipt['archiveSHA256']==cfg['donorArchiveSHA256']
 assert sha(donor.parent/'observations.tar.xz')==cfg['donorArchiveSHA256']
 assert {p.name:sha(p) for p in donor.iterdir()}==cfg['donorFiles']
 for role in ('reference','candidate'):
  folder=root/role
  folder.mkdir()
  for p in donor.iterdir():
   if p.name=='Lokad.Lython.dll': continue
   if p.name.startswith('Lokad.Lython.Benchmarks.'):
    shutil.copyfile(p,folder/p.name)
   else:
    (folder/p.name).symlink_to(p)
  (root/(role+'-core.dll')).rename(folder/'Lokad.Lython.dll')
''' + source[end:]
compile(source, 'quiet.py', 'exec'); write(lab / 'quiet.py', source)

payload = quiet / 'stage.tar.gz'
with tarfile.open(payload, 'w:gz', compresslevel=6) as archive:
    for name in ('collect.py', 'run.sh', 'representative.json', 'jobs.json', 'identity.json', 'cpython-worker.py'):
        archive.add(quiet / name, arcname=name, recursive=False)
    for role in ('reference', 'candidate'):
        path = lab / role / 'Lokad.Lython.dll'
        assert sha(path) == identity['coreSHA256'][role]
        archive.add(path, arcname=role+'-core.dll', recursive=False)
donor = read(template / 'identity.json')['imageFiles']['candidate']
receipt = read(template / 'terminal-status.json')['receipt']
assert receipt['complete'] and receipt['archiveSHA256'] == sha(template / 'observations.tar.xz')
replica = lab.parent / 'call-state-b61/payload.tar.gz'
assert sha(replica) == '87bb22a1a366d181bae6d771316c0017d6a6eb9b6ed21a58fbc0b7f7c1d3d6ab'
save(quiet / 'upload.json', dict(root='direct-zip-starmap-b1749-20261126', payloadSHA256=sha(payload),
     payloadBytes=payload.stat().st_size, donorArchiveSHA256=receipt['archiveSHA256'], donorFiles=donor,
     replicaSHA256=sha(replica), replicaBytes=replica.stat().st_size))
