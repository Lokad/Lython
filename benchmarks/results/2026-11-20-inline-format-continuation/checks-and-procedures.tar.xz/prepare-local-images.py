from pathlib import Path

lab=Path(__file__).resolve().parent
prior=lab.parent/'eager-expression-qualification'
text=(prior/'freeze-and-verify.py').read_text(encoding='utf-8-sig').replace('agent-worktrees/eager-expression-emission','agent-worktrees/format-continuation-scratch')
a=text.index('prior = '); b=text.index('\ndef read',a)
text=text[:a]+"prior = lab.parent / 'eager-expression-qualification'"+text[b:]
text=text.replace("'53d3b45d5'","'f0263f0ec'")
start=text.index('catalog=read('); end=text.index("manifest = ",start)
text=text[:start]+"""catalog=read(lab.parent/'prepared-format-keywords/catalog.json')
wanted={
    'scripts.report-forwarding.expanded',
    'scripts.report-render.format-selectors.large',
    'scripts.report-render.named-format-selectors.large',
    'scripts.csv-invoice.large',
    'strings.named-format-report.medium',
    'strings.nested-format-report.medium',
}
catalog['cases']=[row for row in catalog['cases'] if row['id'] in wanted]
assert len(catalog['cases'])==len(wanted)
"""+text[end:]
text=text.replace('Five CPython goldens per full 32-file image.','Six CPython goldens per full 32-file image.')
(lab/'freeze-and-verify.py').write_text(text,encoding='utf-8',newline='\n')
text=(prior/'check-semantics.py').read_text(encoding='utf-8-sig')
a=text.index('cases='); b=text.index('load=lambda',a)
newcases={
    'retained-nested-format-specs':"""seen=[]
class Value:
    def __format__(self,spec):
        seen.append(spec)
        return spec
print('{0:{1}}|{0:{2}}'.format(Value(),'width','second'))
print(seen)
""",
    'format-late-grammar-error':"""seen=[]
class Value:
    def __format__(self,spec):
        seen.append(spec)
        return 'first'
try:
    '{0:{1}} {'.format(Value(),'abc')
except ValueError:
    print(seen)
""",
    'format-recursive-spec-error':"""seen=[]
class Value:
    def __format__(self,spec):
        seen.append(spec)
        return 'first'
try:
    '{0:{1:{2}}}'.format(Value(),Value(),Value())
except ValueError:
    print(seen)
""",
}
text=(text[:a]+f'cases={newcases!r}\n'+text[b:]).replace('agent-worktrees/eager-expression-emission','agent-worktrees/format-continuation-scratch')
(lab/'check-semantics.py').write_text(text,encoding='utf-8',newline='\n')
