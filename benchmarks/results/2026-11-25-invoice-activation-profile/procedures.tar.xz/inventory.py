from pathlib import Path
import json
import subprocess
import sys

lab=Path(__file__).resolve().parent
history=lab.with_name("current-workspace-cpu-retry-20261125")
file=lab/"find-archived-duplicates.py"
source=(history/"find-archived-duplicates.py").read_text(encoding="utf-8")
source=source.replace("6*1024*1024","16*1024*1024").replace("nlargest(200","nlargest(350")
file.write_text(source,encoding="utf-8",newline="\n")
subprocess.run([sys.executable,"-X","utf8",file],check=True,timeout=85)
