from pathlib import Path
import hashlib
import json
import os
import shutil
import subprocess
import tarfile

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
prior=lab.with_name("current-workspace-cpu-retry-20261125")
donor=lab.with_name("private-definition-admission-20261125")
external=donor/"comparison/quiet"
read=lambda p:json.loads(p.read_text(encoding="utf-8"))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def git(*args):
    return subprocess.check_output(["git",*args],cwd=repo)
def write(p,body):
    p.write_text(body,encoding="utf-8",newline="\n")
def save(p,data):
    write(p,json.dumps(data,indent=2)+"\n")

old=read(external/"identity.json")
receipt=read(external/"terminal-status.json")["receipt"]
assert receipt["complete"] and sha(external/"observations.tar.xz")==receipt["archiveSHA256"]
source=git("rev-parse","93eead293").decode().strip()
assert git("diff","--binary",old["sourceRevision"],source,"--","src")== (donor/"candidate.patch").read_bytes()
assert git("diff","--name-only",source,"HEAD","--","src","benchmarks/Lokad.Lython.Benchmarks","benchmarks/cpython-worker.py")==b""
image=donor/"candidate"
files=old["imageFiles"]["candidate"]
assert len(files)==32 and {p.name:sha(p) for p in image.iterdir()}==files
catalog=read(lab.with_name("direct-record-cpython-20261125")/"external/representative.json")
invoice="scripts.csv-invoice.method-policy.quoted-control"
catalog["cases"]=[case for case in catalog["cases"] if case["id"]==invoice]
assert len(catalog["cases"])==1
save(lab/"catalog.json",catalog)
save(lab/"identity.json",dict(sourceRevision=source,measurementReference=source,imageFiles={"candidate":files},
    coreSHA256={"candidate":files["Lokad.Lython.dll"]},cpythonWorkerSHA256=old["cpythonWorkerSHA256"],
    profiles=[["invoice-warm",invoice,"candidate"],["invoice-async",invoice,"candidate"]],
    purpose="Attribute remaining quoted-invoice activation, receiver, dictionary, integer conversion and host costs",
    donorArchiveSHA256=receipt["archiveSHA256"],profileCatalogSHA256=sha(lab/"catalog.json")))

sdk=Path.home()/".dotnet11"
dotnet=sdk/"dotnet.exe"
env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk))
protocol=repo/"benchmarks/cpython-worker.py"
assert sha(protocol)==old["cpythonWorkerSHA256"]
output=lab/"candidate-verification.json"
subprocess.run([dotnet,image/"Lokad.Lython.Benchmarks.dll","--compare","verify","--catalog",lab/"catalog.json","--dotnet",
                dotnet,"--python","C:/Python313/python.exe","--python-worker",protocol,"--out",output],
               cwd=repo,env=env,check=True,timeout=65)
checked=read(output)
assert checked["state"]=="Completed" and checked["caseCount"]==1
assert checked["catalogSha256"]==sha(lab/"catalog.json")
assert checked["launched"]["library"]["sha256"]==files["Lokad.Lython.dll"]
assert {p.name:sha(p) for p in image.iterdir()}==files

collector=(prior/"collect.py").read_text(encoding="utf-8").replace(
    "iteration-native-storage-prepared-b1708b-20261125","private-definition-admission-b1721-20261125")
collector=collector.replace("b1709-fixtures","b1723-fixtures")
launcher=(prior/"quiet.py").read_text(encoding="utf-8").replace("current-workspace-cpu-b1709b-20261125","invoice-activation-profile-b1723-20261125")
launcher=launcher.replace("lython-b1709b-current-workspace-cpu","lython-b1723-invoice-activation-profile")
launcher=launcher.replace("iteration-native-storage-prepared-20261125","private-definition-admission-20261125")
launcher=launcher.replace('checked["caseCount"]==3','checked["caseCount"]==1').replace("Staged three profiles","Staged two invoice profiles")
launcher=launcher.replace("RuntimeMaxSec=175","RuntimeMaxSec=125").replace("seconds=120","seconds=74")
for name, text in (("quiet.py",launcher),("collect.py",collector)):
    compile(text,name,"exec")
    write(lab/name,text)
for name in ("run.sh","ops-profile.py","analyze.py"):
    shutil.copyfile(prior/name,lab/name)
assert b"\r" not in (lab/"run.sh").read_bytes()
assert b"\r" not in (lab/"ops-profile.py").read_bytes()
archive=(prior/"archive.py").read_text(encoding="utf-8").replace("2026-11-25-current-workspace-cpu","2026-11-25-invoice-activation-profile")
archive=archive.replace('startswith("7d24cfe9a")','startswith("93eead293")')
archive=archive.replace('"find-archived-duplicates.py", "archived-duplicates.json"', '"find-archived-duplicates.py", "archived-duplicates.json", "inventory.log", "inventory.py"')
write(lab/"archive.py",archive)
