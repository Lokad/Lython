from pathlib import Path
import hashlib
import json
import shutil
import subprocess
import tarfile
import xml.etree.ElementTree as E

repo = Path('D:/code/Lython')
root = Path(__file__).parent
target = repo / 'benchmarks/results/2026-11-11-regex-projection-storage'
target.mkdir(exist_ok=True)
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
checks = {}
for path in (root / 'tests').glob('*.trx'):
    document = E.parse(path)
    checks[path.name] = next(n.attrib for n in document.iter() if n.tag.endswith('Counters'))
for suite in ['Lokad.Lython.Tests', 'Lokad.Lython.PublicApi.Tests']:
    for framework in ['net11.0', 'net10.0']:
        counts = checks[f'final-{suite}-{framework}.trx']
        assert counts['failed'] == '0'
(target / 'focused-checks.json').write_text(json.dumps(checks, indent=2) + '\n', encoding='utf-8')
for name in ['before.json', 'diagnostic-identity.json', 'cpython-goldens.json',
             'golden-capability-correction.json', 'setup-corrections.md', 'catalog.json',
             'measured-source.patch', 'prepare-measure.py', 'summarize.py']:
    shutil.copyfile(root / name, target / name)
for phase in ['warm-sync', 'warm-async', 'compile']:
    data = json.loads((root / phase / 'measurements.json').read_text(encoding='utf-8'))
    assert data['allGoldensPassed'] and data['allBalancesZero'] and data['ownedFixturesRemoved']
    destination = target / phase
    destination.mkdir(exist_ok=True)
    for name in ['summary.json', 'measurements.json']:
        shutil.copyfile(root / phase / name, destination / name)
source = subprocess.check_output(['git', 'ls-files', 'src/Lokad.Lython'], cwd=repo, text=True).splitlines()
identity = dict(baseRevision=json.loads((root / 'before.json').read_text(encoding='utf-8'))['revision'],
    currentSource={p: hashlib.sha256((repo / p).read_bytes().replace(b'\r\n', b'\n')).hexdigest()
                   for p in source if p.endswith('.cs')},
    currentCoreSHA256={f: sha(repo / f'src/Lokad.Lython/bin/Release/{f}/Lokad.Lython.dll')
                      for f in ['net11.0', 'net10.0']},
    sourceQualification='Retained prototype:64internal/397public focused regex checks per actual11/10. Full platform/stress/installed-consumer qualification is deferred to the next coherent batch; CI42931921242 qualifies predecessor e122 only.',
    decision='Retain explicit operation-owned working storage and measured17–18% Unicode-iteration allocation reduction. Desktop elapsed/CPU diagnostic; moving controls and all adversity retained. No current CPython/producer/CPU/publication claim.')
assert identity['currentCoreSHA256']['net11.0'] == json.loads((root / 'diagnostic-identity.json').read_text(encoding='utf-8'))['images']['candidate']['Lokad.Lython.dll']
(target / 'source-identity.json').write_text(json.dumps(identity, indent=2) + '\n', encoding='utf-8')
with tarfile.open(target / 'preparation.tar.xz', 'w:xz') as archive:
    seen = {}
    def add(path, name):
        if path.suffix == '.dll':
            digest = sha(path)
            if digest in seen:
                entry = tarfile.TarInfo(name)
                entry.type = tarfile.LNKTYPE
                entry.linkname = seen[digest]
                archive.addfile(entry)
                return
            seen[digest] = name
        archive.add(path, arcname=name)
    for framework in ['net11.0', 'net10.0']:
        add(root / f'baseline/{framework}/Lokad.Lython.dll', f'baseline/{framework}/Lokad.Lython.dll')
        add(repo / f'src/Lokad.Lython/bin/Release/{framework}/Lokad.Lython.dll', f'candidate/{framework}/Lokad.Lython.dll')
    for name in ['Lokad.Lython.Benchmarks.dll', 'Lokad.Lython.Benchmarks.deps.json',
                 'Lokad.Lython.Benchmarks.runtimeconfig.json', 'Lokad.Lython.Utf8Regex.dll',
                 'Lokad.Utf8Regex.dll', 'Lokad.Utf8Regex.PythonRe.dll']:
        add(root / 'images/candidate' / name, 'common-images/' + name)
    for path in root.iterdir():
        if path.is_file() and path.suffix in {'.cs', '.py', '.json', '.txt', '.md', '.log', '.patch'}:
            add(path, path.name)
    for folder in ['tests', 'source-before', 'tool']:
        for path in (root / folder).rglob('*'):
            if path.is_file() and 'obj' not in path.relative_to(root).parts:
                add(path, path.relative_to(root).as_posix())
with tarfile.open(target / 'preparation.tar.xz') as archive:
    for member in archive.getmembers():
        if member.isfile():
            assert len(archive.extractfile(member).read()) == member.size
(target / 'archive-identity.json').write_text(json.dumps(dict(bytes=(target / 'preparation.tar.xz').stat().st_size,
    sha256=sha(target / 'preparation.tar.xz')), indent=2) + '\n', encoding='utf-8')
print('Recorded both-target checks, original failures, full diagnostic boundaries, frozen cores and ownership/allocation decision.')
