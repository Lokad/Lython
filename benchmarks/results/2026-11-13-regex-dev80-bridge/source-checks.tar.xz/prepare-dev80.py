from pathlib import Path
import hashlib,json,shutil,subprocess,xml.etree.ElementTree as ET,zipfile
repo=Path.cwd();old=Path(__file__).parent.parent/'regex-dev79-r299';r=old.parent/'regex-dev80-r316';r.mkdir()
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
baseline=json.loads((old/'normal-state-before.json').read_text(encoding='utf-8'))
(r/'normal-state-before.json').write_text(json.dumps({p:sha(p)for p in baseline},indent=2)+'\n',encoding='utf-8')
sources={p:sha(p)for p in subprocess.check_output(['git','ls-files','src/Lokad.Lython'],text=True).splitlines()};assert len(sources)==573
(r/'normal-core-sources-before.json').write_text(json.dumps(sources,indent=2)+'\n',encoding='utf-8')
for name in ['Directory.Build.props','Directory.Packages.props','NuGet.Config','CursorAdmissionTests.cs','workflow-fixture-manifest.json','qualify.py','Utf8RegexProvider.cs']:
    s=(old/name).read_text(encoding='utf-8').replace(old.resolve().as_posix(),r.resolve().as_posix()).replace('0.5.0-dev.79','0.5.0-dev.80')
    if name=='Utf8RegexProvider.cs':
        needle=', inputValidation: Utf8InputValidation.AssumeValid'
        assert s.count(needle)==1;s=s.replace(needle,'')
    if name=='qualify.py':s=s.replace('dev79','dev80').replace('571 sources','573 sources').replace('571sources','573sources')
    (r/name).write_text(s,encoding='utf-8',newline='\n')
(r/'feed').mkdir();packages={}
for name in ['Lokad.Utf8Regex','Lokad.Utf8Regex.PythonRe']:
    source=Path(f'D:/code/utf8regex/artifacts/nuget/{name}.0.5.0-dev.80.nupkg');before=sha(source);target=r/'feed'/source.name;shutil.copyfile(source,target);assert sha(target)==before==sha(source)
    with zipfile.ZipFile(target)as a:
        xml=ET.fromstring(a.read(next(n for n in a.namelist()if n.endswith('.nuspec'))));commit=next(e.attrib['commit']for e in xml.iter()if e.tag.endswith('repository'))
        assemblies={tfm:hashlib.sha256(a.read(f'lib/{tfm}/{name}.dll')).hexdigest()for tfm in ['net11.0','net10.0']}
    packages[source.name]=dict(sha256=before,repositoryCommit=commit,assemblies=assemblies)
identity=dict(consumerRevision=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),consumerRuntimePrototype='R315 selected call/body admission;573 exact source inputs retained',producerVersion='0.5.0-dev.80',producerObservedHead=subprocess.check_output(['git','-C','D:/code/utf8regex','rev-parse','HEAD'],text=True).strip(),packages=packages,bridge='Existing dev79 bridge, removed obsolete inputValidation Compile argument. Producer valid-UTF8 subjects; strict pattern compilation. Current-token linked cursor bridge and conservative one-match admission remain adapter-local.',limitations='Isolated changed-producer semantic/ownership/cancellation validation only. No normal pin/core dependency edit, backend CPU claim or final release/safety qualification. Missing one-match owner split, UTF8 name enumeration/copy and token-independent cursor preparation remain precise gaps.')
(r/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8')
print('Immutable dev80 copied/pinned; API bridge deletes removed validation argument; normal files/573 core inputs snapshotted.',flush=True)
