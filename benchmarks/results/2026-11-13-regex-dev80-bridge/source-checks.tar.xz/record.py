from pathlib import Path
import hashlib,json,shutil,tarfile
r=Path(__file__).parent;out=Path('benchmarks/results/2026-11-13-regex-dev80-bridge');out.mkdir(exist_ok=True)
q=json.loads((r/'qualification.json').read_text(encoding='utf-8'));isolation=json.loads((r/'isolation.json').read_text(encoding='utf-8'))
assert isolation['normalFilesUnchanged']==29 and isolation['coreSourcesUnchanged']==573 and isolation['loadedProducerAssembliesMatchPinnedPackages']
for target in ['net11.0','net10.0']:
 assert q['checks']['Lokad.Lython.Tests-'+target]['passed']==88 and q['checks']['Lokad.Lython.PublicApi.Tests-'+target]['passed']==534
for name in ['identity.json','qualification.json','isolation.json']:shutil.copyfile(r/name,out/name)
with tarfile.open(out/'source-checks.tar.xz','w:xz')as a:
 for p in r.iterdir():
  if p.is_file()and p.suffix in ['.py','.cs','.props','.Config','.json','.log']:a.add(p,arcname=p.name)
 a.add(r.parent/'call-construction-r315/prepare-dev80.py',arcname='prepare-dev80.py')
 a.add(r.parent/'call-construction-r315/candidate-sources.tar.xz',arcname='consumer-sources.tar.xz')
 for target in ['net11.0','net10.0']:
  for name in ['Lokad.Lython','Lokad.Lython.Utf8Regex']:
   a.add(r/f'out/Lokad.Lython.PublicApi.Tests/Release/{target}/{name}.dll',arcname=f'consumer/{target}/{name}.dll')
 for p in (r/'feed').iterdir():
  assert hashlib.sha256(p.read_bytes()).hexdigest()==q['identity']['packages'][p.name]['sha256'];a.add(p,arcname='immutable-feed/'+p.name)
print('dev80 exact packages,573consumer inputs/bits, bridge and both-target622-case checks archived; development-only.',flush=True)
