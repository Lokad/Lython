from pathlib import Path
import ast,base64,datetime,hashlib,json,subprocess,tarfile
base=Path(__file__).parent;r=base/'search-attribution-r400';r.mkdir()
old=base/'hosting-attribution-r389'
identity=json.loads((base/'tuple-transport-r397/quiet/identity.json').read_text(encoding='utf-8'))
identity.update(sourceRevision='51e3c2c1/frozen22e5b72c',purpose='One complete protected file-search CPU attribution, separating final call/frame work from line/storage/host costs. No elapsed source-pair or speedup claim.')
(r/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8',newline='\n')
for name in ['ops-profile.py','collect.py','run.sh','retrieve.py']:
    s=(old/name).read_text(encoding='utf-8').replace('hosting-attribution-b776-20261115','search-attribution-b785-20261115').replace('lython-b776-hosting-attribution-20261115','lython-b785-search-attribution-20261115').replace('B776','B785')
    s=s.replace("[('sync','scripts.text-summary-helpers.nonlocal-counter.large','warm'),('async','scripts.text-summary-helpers.nonlocal-counter.large','warm-async')]", "[('search','scripts.file-search.large.protected','warm')]")
    s=s.replace("['sync','async']","['search']").replace("['sync', 'async']","['search']")
    s=s.replace('Committed810379be/frozen8fbfa3f0; R389 captured-text API CPU attribution','Committed51e3c2c1/frozen22e5b72c; R400 complete search CPU attribution')
    if name.endswith('.py'):ast.parse(s)
    (r/name).write_text(s,encoding='utf-8',newline='\n')
s=(base/'analyze-hosting-attribution-r389.py').read_text(encoding='utf-8').replace("/ 'hosting-attribution-r389'","/ 'search-attribution-r400'").replace("['sync', 'async']","['search']").replace('810379be/frozen8fbfa3f0','51e3c2c1/frozen22e5b72c').replace('Two API captures are not a controlled elapsed source-pair comparison.','One complete-search capture is not a controlled elapsed source-pair comparison or exact removable CPU fraction.')
ast.parse(s);(base/'analyze-search-attribution-r400.py').write_text(s,encoding='utf-8',newline='\n')
with tarfile.open(r/'payload.tgz','w:gz')as a:
    for name in ['identity.json','ops-profile.py','collect.py','run.sh']:a.add(r/name,arcname=name)
config=dict(root='/home/lokad/lython-bench-checks/search-attribution-b785-20261115',source='/home/lokad/lython-bench-checks/tuple-transport-b782-20261115',unit='lython-b785-search-attribution-20261115',identity=identity,payloadBytes=(r/'payload.tgz').stat().st_size,payloadSHA256=hashlib.sha256((r/'payload.tgz').read_bytes()).hexdigest())
code='''from pathlib import Path
import fcntl,hashlib,io,json,os,shutil,subprocess,sys,tarfile
config=CONFIG
base=Path('/home/lokad/lython-bench-checks').resolve();root=Path(config['root']);source=Path(config['source']);sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert root.parent==base and not root.exists() and source.parent==base and source.resolve()==source
with(base/'comparison-vm.lock').open('a')as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record|[p]ython3.*cpython-worker.py'],capture_output=True).returncode==1
 assert not any(os.path.ismount(p)for p in base.glob('*/guest-fixtures'))
 state=subprocess.check_output(['systemctl','show',config['unit']+'.service','--property=LoadState,MainPID'],text=True)
 assert 'LoadState=not-found'in state and 'MainPID=0'in state
 assert sha(source/'candidate/Lokad.Lython.dll')==config['identity']['coreSHA256']['candidate']
 for name,h in config['identity']['auxiliaryFiles'].items():assert sha(source/'candidate'/name)==h
 assert sha(source/'representative.json')==config['identity']['catalogSHA256']
 # Historical maps were1.35–1.50MB; reserve2.5MiB diagnostic headroom over
 # the existing archive floor. This is not a guest memory allowance or policy.
 assert shutil.disk_usage(base).free>max(254*1024*1024+65536,252*1024*1024+2621440)
 payload=sys.stdin.buffer.read(config['payloadBytes']+1);assert len(payload)==config['payloadBytes']and hashlib.sha256(payload).hexdigest()==config['payloadSHA256']
 root.mkdir()
 with tarfile.open(fileobj=io.BytesIO(payload),mode='r:gz')as a:a.extractall(root,filter='data')
 (root/'candidate').mkdir()
 for p in (source/'candidate').iterdir():assert p.is_file();os.link(p,root/'candidate'/p.name)
 os.link(source/'representative.json',root/'catalog.json')
 fixture=root/'guest-fixtures';fixture.mkdir()
 subprocess.run(['sudo','-n','mount','-t','tmpfs','-o','size=128m,mode=0700,uid=lokad,gid=lokad','lython-b785-fixtures',str(fixture)],check=True)
try:subprocess.run(['sudo','-n','systemd-run','--unit='+config['unit'],'--property=User=lokad','--property=WorkingDirectory='+str(root),'--property=RuntimeMaxSec=120','--property=TimeoutStopSec=30','--property=KillMode=control-group','/bin/sh',str(root/'run.sh')],check=True)
except BaseException:
 subprocess.run(['sudo','-n','umount',str(fixture)],check=True);fixture.rmdir();raise
print(subprocess.check_output(['systemctl','show',config['unit']+'.service','--property=ActiveState,MainPID,RuntimeMaxUSec'],text=True))
'''.replace('CONFIG',repr(config))
ast.parse(code);(r/'launch-command.py').write_text(code,encoding='utf-8',newline='\n')
plan=Path('PLAN.md');s=plan.read_text(encoding='utf-8');s=s.replace('## Priority 2 — continue substantial whole-script redesigns','''## Priority 2 — continue substantial whole-script redesigns

R400 next gate: one5s199Hz complete protected-search CPU capture on51e3/22e5,
reusing the checked profiler/worker, eight guest seconds warmup, ordinary GC/tiering
plus explicitly diagnostic perf maps. Attribute call/default/frame work versus
line/storage/host work before selecting any redesign; fixed native storage is
already16slots and direct binding already exists. Stop with an actual dominant
stage or precise unknowns, not another arena or repeated capture tuning. Preserve
all thread CPU/unknown samples, goldens, funded cleanup and archive RAM evidence
under the lease before teardown. No runtime change or timing gain follows.
''');plan.write_text(s,encoding='utf-8',newline='\n')
cmd="python3 -c 'import base64;exec(base64.b64decode(\""+base64.b64encode(code.encode()).decode()+"\"))'"
p=subprocess.run(['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73',cmd],input=(r/'payload.tgz').read_bytes(),capture_output=True,timeout=30)
(r/'launch.log').write_bytes(p.stdout+p.stderr);assert p.returncode==0,(p.stdout+p.stderr).decode()
now=datetime.datetime.now(datetime.timezone.utc)
(r/'observe-not-before.json').write_text(json.dumps(dict(startedUTC=now.isoformat(),doNotObserveBeforeUTC=(now+datetime.timedelta(seconds=60)).isoformat(),ownerSeconds=120),indent=2)+'\n',encoding='utf-8',newline='\n')
print((p.stdout+p.stderr).decode(),flush=True);print('Observe same unit after',(now+datetime.timedelta(seconds=60)).isoformat(),flush=True)
