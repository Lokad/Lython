from pathlib import Path
import hashlib,json,shutil,tarfile
r=Path(__file__).parent/'search-attribution-r400';t=json.loads((r/'terminal-status.json').read_text(encoding='utf-8'));x=json.loads((r/'attribution.json').read_text(encoding='utf-8'))
assert t['receipt']['complete'] and not t['remainingWorkers'] and not t['remainingTrace']
assert hashlib.sha256((r/'observations.tgz').read_bytes()).hexdigest()==t['receipt']['archiveSHA256']
assert len(x['captures'])==1
assessment=dict(revision='51e3c2c153bddf9937e01df2a1c3f2c9d3b10748',coreSHA256='22e5b72c3d02a987758a2c84d08c61b4345fb11e7acac0394b5fef9d98e18141',facts=['Native call working storage is a fixed16-slot managed buffer, not64; direct arguments already enter final slots.', 'Synchronous callers use Monitor.Wait; no custom busy-spin or ManualResetEventSlim policy was found.', 'Decoded line windows already borrow admitted stable UTF8 backing; metadata publication uses direct Reserve/Commit/rollback, not a per-line transaction wrapper.', 'Every Reserve currently resizes the borrowed shared lease; batching would change admission timing/retention and needs an explicit ownership contract.', 'Inclusive frame counts overlap useful work; no whole activation or dispatch controller is established as disposable.'],next='One bounded host-call timing attribution on the same complete file-search script using a private forwarding wrapper around the existing trusted comparison host. Keep capabilities, paths/tokens/budgets, stream contracts and goldens identical. Separate host work from the remaining frame/operand question before selecting a redesign. No new runtime policy, benchmark framework, coupon pool or guest tracing.',stopping='Close this capture/source gate with overlapping costs and explicit kernel/runtime unknowns. No unchanged recapture or another call arena from inclusive percentages.',runtimeChanged=False,testsRepeated=False)
(r/'source-assessment.json').write_text(json.dumps(assessment,indent=2)+'\n',encoding='utf-8',newline='\n')
out=Path('benchmarks/results/2026-11-15-search-cost-attribution');out.mkdir()
for name in ['attribution.json','source-assessment.json','identity.json','terminal-status.json','archive-receipt.json','observations.tgz']:shutil.copyfile(r/name,out/name)
with tarfile.open(out/'procedure.tar.xz','w:xz')as a:
    for name in ['ops-profile.py','collect.py','run.sh','retrieve.py','launch-command.py','launch.log','config.json']:a.add(r/name,arcname=name)
    for p in [Path(__file__),Path(__file__).parent/'prepare-search-attribution-r400.py',Path(__file__).parent/'analyze-search-attribution-r400.py']:a.add(p,arcname=p.name)
print('One complete-search capture/source gate preserved; no new runtime design selected from overlapping/unknown cost')
