from pathlib import Path
import bisect
import collections
import gzip
import json
import re

root = Path(__file__).parent / 'search-attribution-r400'
rows = []
for mode in ['search']:
    folder = root / 'retrieved/profiles' / mode
    record = json.loads((folder/'record.json').read_text(encoding='utf-8'))
    ranges = []
    malformed = []
    for line in gzip.open(folder/'perf.map.gz','rt',encoding='utf-8').read().splitlines(keepends=True):
        parts = line.rstrip().split(' ',2)
        if len(parts)!=3 or not line.endswith('\n'): malformed.append(line);continue
        start,size,name=parts;ranges.append((int(start,16),int(size,16),name))
    ranges=sorted(set(ranges));starts=[row[0]for row in ranges];prefix=[]
    for start,size,name in ranges:prefix.append(max(start+size,prefix[-1]if prefix else 0))
    def symbol(address,fallback):
        index=bisect.bisect_right(starts,address)-1;matches=set()
        while index>=0 and prefix[index]>address:
            start,size,name=ranges[index]
            if start<=address<start+size:matches.add(name)
            index-=1
        if len(matches)==1:return next(iter(matches))
        if matches:return '[ambiguous] '+' | '.join(sorted(matches))
        return fallback
    samples=[];current=None
    for line in gzip.open(folder/'all-thread-stacks.txt.gz','rt',encoding='utf-8').read().splitlines():
        header=re.match(r'^.*?\s(\d+)\s+\d+\.\d+:\s+\d+\s+cpu-clock:',line)
        if header:
            current={'tid':header[1],'stack':[]};samples.append(current);continue
        frame=re.match(r'^\s+([0-9a-f]+)\s+(.*)$',line)
        if current is not None and frame:current['stack'].append(symbol(int(frame[1],16),frame[2]))
    guest=[s for s in samples if s['tid']in record['guestTids']]
    other=[s for s in samples if s['tid']not in record['guestTids']]
    leaves=collections.Counter(s['stack'][0]for s in guest if s['stack'])
    nearest=collections.Counter(next((n for n in s['stack']if 'Lokad.Lython.'in n),'[no Lython frame]')for s in guest if s['stack'])
    other_leaves=collections.Counter(s['stack'][0]for s in other if s['stack'])
    inclusive={label:sum(any(any(term in n for term in terms)for n in s['stack'])for s in guest)
               for label,terms in {'file-line':['TextFileHandle','ChunkedTextFileReadState','ReadLineCore'],
                                   'iteration':['PyIteration','ExecuteForNext'],
                                   'text-segment':['CasedWhitespace','PyStringOps','UnicodeCaseMapping'],
                                   'native-helper':['NativeExecution','StartNativeCall','StartInline'],
                                   'admission':['MemoryGovernor','LythonMemoryBudget','OwnedMemory'],
                                   'ordinary-prefix':['ExecuteInstructionPrefix']}.items()}
    calls=record['response']['completedInvocations']
    guest_cpu=sum(r['seconds']for r in record['threadCpuSeconds']if r['tid']in record['guestTids'])
    other_cpu=sum(r['seconds']for r in record['threadCpuSeconds']if r['tid']not in record['guestTids'])
    row=dict(mode=mode,invocations=calls,timedSeconds=record['response']['elapsedTicks']/record['response']['clockFrequency'],
             guestCpuSeconds=guest_cpu,otherCpuSeconds=other_cpu,guestCpuMicrosecondsPerInvocation=1e6*guest_cpu/calls,
             otherCpuMicrosecondsPerInvocation=1e6*other_cpu/calls,guestSamples=len(guest),otherSamples=len(other),
             malformedMapLines=malformed,unknownLeaves=sum(c for n,c in leaves.items()if '[unknown]'in n),
             ambiguousLeaves=sum(c for n,c in leaves.items()if n.startswith('[ambiguous]')),
             topGuestLeaves=leaves.most_common(50),nearestLythonFrame=nearest.most_common(50),
             topOtherThreadLeaves=other_leaves.most_common(35),inclusiveGuestFrameCounts= inclusive,
             interpretation='Diagnostic CPU-clock/fp samples; inclusive frame counts overlap and include useful work. One complete-search capture is not a controlled elapsed source-pair comparison or exact removable CPU fraction.')
    rows.append(row)
    print(mode,'invocations',calls,'guest us/call',round(row['guestCpuMicrosecondsPerInvocation'],2),'other us/call',round(row['otherCpuMicrosecondsPerInvocation'],2),'samples',len(guest),len(other),'unknown',row['unknownLeaves'],'ambiguous',row['ambiguousLeaves'])
    print('inclusive',inclusive)
    for name,count in row['topGuestLeaves'][:14]:print(count,name)
summary=dict(source='51e3c2c1/frozen22e5b72c',captures=rows,performanceComparison=False)
(root/'attribution.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8',newline='\n')
