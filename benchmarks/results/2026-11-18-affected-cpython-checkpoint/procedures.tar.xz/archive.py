from pathlib import Path
import hashlib,json,shutil,tarfile
r=Path(__file__).resolve().parent;repo=Path('D:/code/Lython');out=repo/'benchmarks/results/2026-11-18-affected-cpython-checkpoint';out.mkdir(exist_ok=False)
guide=repo/'docs/BENCHMARKS.md';shutil.copyfile(guide,out/'prior-BENCHMARKS.md')
for n in ['summary.json','catalog.json','preflight.json','preflight-reuse.json']:shutil.copyfile(r/n,out/n)
for n in ['identity.json','archive-receipt.json','terminal-status.json','observations.tgz']:shutil.copyfile(r/'quiet'/n,out/n)
identity=json.loads((out/'identity.json').read_text(encoding='utf-8'))
assert hashlib.sha256((repo/'benchmarks/results/2026-11-18-buffered-yield-transport/candidate-sources.tar.xz').read_bytes()).hexdigest()==identity['sourceInputsArchiveSHA256']
with tarfile.open(out/'procedures.tar.xz','w:xz')as a:
 for p in sorted(r.rglob('*')):
  if p.is_file()and 'retrieved'not in p.relative_to(r).parts and p.suffix in ['.py','.json','.log','.sh']:a.add(p,arcname=p.relative_to(r).as_posix())
summary=json.loads((out/'summary.json').read_text(encoding='utf-8'))
names={'scripts.text-normalization.large':'Text normalization','scripts.numeric-squared-error.floating.large':'Floating JSON numeric report'}
def fields(row):
 t=row['medianMilliseconds'];l=[t[x]for x in ['candidate','candidate-control']];c=[t[x]for x in ['CPython','CPython-control']]
 return [f'{min(l):.3f}–{max(l):.3f} ms',f'{min(c):.3f}–{max(c):.3f} ms',f"{min(row['ratioRange']):.2f}–{max(row['ratioRange']):.2f}×",f"Diagnostic2e5/1bce; controls L/C {row['lythonControlPercent']:.2f}/{row['cpythonControlPercent']:.2f}%; IQR≤{row['maxIqrPercent']:.2f}%"]
table=[]
for row in summary['timing']:
 phase={'compile':'Compilation only','warm':'Warm execution','compile-run':'Compile-to-result'}[row['lane']]
 table.append('| '+names[row['case']]+' | '+phase+' | '+' | '.join(fields(row))+' |')
(out/'README.md').write_text('''# Affected complete-script CPython checkpoint

R511/B936,2026-11-18 UTC, committed retained **2e585229 / frozen1bce52ad** versus
stock **CPython3.13.16**(PGO/LTO,GIL,no JIT). Full retained delivery44225923745
is independently pending; no inherited qualification. Quiet AzureF4as_v7/4vCPU
AMD EPYC9V45/16GiB/Ubuntu24.04.4/.NET11RC3, default GC/tiering. Two affected
complete scripts/three phases, six jobs226.36seconds; six-second warmups/five
rotated rounds/two processes per engine. Existing workers/catalog/protocol only.

| Complete script | Phase | Lython | CPython | Lython / CPython | Status |
| --- | --- | ---: | ---: | ---: | --- |
'''+ '\n'.join(table)+'''

Text normalization processes4,096lines/52,224B; floating JSON4,096pairs/56,495B.
Ratio is Lython elapsed / CPython elapsed; above one means slower. Ranges cover
all four combinations of process medians, not confidence intervals. Warm text
controls are small; floating fresh CPython control4.91%limits precision. Compilation
is slightly faster here but does not explain away the remaining warm execution
gaps. Do not infer a causal gain by subtracting older source/collection conditions.
The previous5.49/8.33%floating Lython controls and all earlier adversity remain in
their original [checkpoint](../2026-11-18-agent-cpython-checkpoint/README.md).

Warm includes Run, mediated RAM-backed I/O, stdout/file goldens and prior-result
cleanup. Fresh adds compilation/compiled-owner disposal; compilation includes
owner disposal. Startup/reset/request framing/final cache teardown excluded;
wider process CPU includes reset/protocol. Separately warmed phases are not
additive. CPython uses native files without equivalent containment/ownership.

All32image hashes were reverified; unchanged actual-image/six-case independent
goldens and allocation/reuse from R510 were reused, not repeated. Every VM worker
also verifies goldens/Closed. Both quiet gates, all joined users and persistent/local
SHA archives pass before RAM teardown. No images retired for this collection;
current/qualified images/catalogs/toolchains and254/252MiBfloors remain intact.
Publication postponed; current cost attribution and the wider redesign continue.

[Summary](summary.json),[raw](observations.tgz),[identity](identity.json),
[catalog](catalog.json),[actual-image verification](preflight.json),
[verification reuse](preflight-reuse.json),[procedures](procedures.tar.xz),
[previous guide](prior-BENCHMARKS.md).
''',encoding='utf-8',newline='\n')
s=guide.read_text(encoding='utf-8');lines=s.splitlines()
for row in summary['timing']:
 title=names[row['case']];warm=row['lane']=='warm'
 if warm:
  prefix='| '+title+' | 4,096';size='4,096 lines / 52,224 B'if title=='Text normalization'else'4,096 pairs / 56,495 B'
 else:
  prefix='| '+title+' | '+('Compilation only'if row['lane']=='compile'else'Compile')
  size='Compilation only'if row['lane']=='compile'else'Compile-to-result'
 indices=[i for i,line in enumerate(lines)if line.startswith(prefix)];assert len(indices)==1,(prefix,indices)
 lines[indices[0]]='| '+title+' | '+size+' | '+' | '.join(fields(row))+' |'
s='\n'.join(lines)+'\n'
s=s.replace('The CSV/text/aggregation rows and floating compilation-only row were measured','The CSV and JSON-lines aggregation rows were measured')
a=s.index('The configuration/report/floating execution rows');b=s.index('\nWarm clocks include',a)
s=s[:a]+'''The configuration and formatted-report rows use qualified **62786960 / 5ae019db**,
measured2026-11-18 on the same machine/toolchains; report CPython IQR5.34%limits
precision. [Sources and controls](../benchmarks/results/2026-11-18-agent-cpython-checkpoint/README.md).

Text/floating rows use committed retained **2e585229 / frozen1bce52ad**, measured
**2026-11-18**, six jobs226.36seconds. Full platform/package qualification is
independently pending. Textwarm controls are small; floating fresh CPython control
4.91%limits precision. Compilation/warm/fresh are separately observed; gaps remain
in execution. [Sources, controls and raw data](../benchmarks/results/2026-11-18-affected-cpython-checkpoint/README.md).
'''+s[b:]
a=s.index('additive. Warm-only');b=s.index('\n## Uncertainty',a)
s=s[:a]+'''additive. Warm-only numbers do not describe single-use scripts; use compile-to-result.
Floating fresh CPython's4.91%control movement limits precision; all medians remain
visible. Process startup was not measured.
'''+s[b:]
s=s.replace('The floating process controls, report IQR, text warm CPython control and other distributions stay','The floating fresh CPython control, report IQR and other distributions stay')
a=s.index('The older0d production source');b=s.index('\n## Improvements',a)
s=s[:a]+'''The older0d and627production inputs passed Windows/Ubuntu actual11/10, original
stress and installed Release consumers; the new2e5full delivery remains pending.
Qualification does not imply rebuilt-binary equality or universal performance.
Original adverse controls and failed conditions remain linked in the evidence.
'''+s[b:]
guide.write_text(s,encoding='utf-8',newline='\n')
with(repo/'benchmarks/EXPERIMENTS.md').open('a',encoding='utf-8',newline='\n')as a:a.write('''

R511/B936 [affected-script CPython checkpoint](results/2026-11-18-affected-cpython-checkpoint/README.md), retained2e585229/1bce52ad versus stock3.13.16: two affected complete scripts/three phases,sixjobs226.36s/all32image/goldens/quiet/reuse/join/SHAarchive pass. Textcompile0.95–0.96×,warm1.60×,fresh1.47–1.48×; floatingcompile0.91–0.93×,warm1.61–1.66×,fresh1.38–1.47×. Floating fresh CPython control4.91%limits precision; older Lython5.49/8.33%controls retained. No causal source gain or universal claim; full44225923745separately pending. Unchanged preflight reused, no image retirement, guards intact/publication held. Wider redesign continues.
''')
print('Archived affected CPython checkpoint and refreshed exactly six named guide rows with original controls retained.')
