from pathlib import Path
import hashlib,json,shutil,tarfile
r=Path(__file__).parent/'tuple-transport-r395'
run=r/'quiet';out=Path('benchmarks/results/2026-11-15-tuple-operand-prototype/vm');out.mkdir()
summary=json.loads((run/'summary.json').read_text(encoding='utf-8'))
status=json.loads((run/'terminal-status.json').read_text(encoding='utf-8'))
assert summary['complete'] and summary['jobs']==4 and status['receipt']['complete']
assert not status['remainingWorkers'] and not status['remainingFixtures'] and not status['remainingTrace']
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(run/'observations.tgz')==status['receipt']['archiveSHA256']
original=summary['identity']
correction=dict(reason='Preparation inherited descriptive source/role/qualification fields from R390. Exact core/auxiliary/catalog hashes and actual worker Ready records are correct. Preserve raw identity; correct only descriptive provenance. No observation changed or repeated.',originalFields={k:original[k] for k in ['fullSourceIdentitySHA256','committedSourceProofSHA256','qualification','roleMeaning']},candidateSourceIdentity=dict(artifact='sources-checks-and-observations.tar.xz!candidate-identity.json',sha256=sha(r/'candidate-identity.json'),coreSHA256=original['coreSHA256']['candidate']),referenceDelivery='b58e2dc44d5b75669ec78e9027ae3d6ffb100d86; 2026-11-15-invocation-lifetime/delivery; cached43700041511GREEN',qualification='R395 focused416public/171internal each actual.NET11/10 plus overlapping lifetime/admission supplements; full qualification pending',roleMeaning={x:'R3951b88' if x.startswith('candidate') else 'qualifiedb58f304' for x in original['coreSHA256']})
corrected={k:v for k,v in original.items() if k not in correction['originalFields']}
corrected.update(candidateSourceIdentity=correction['candidateSourceIdentity'],referenceDelivery=correction['referenceDelivery'],qualification=correction['qualification'],roleMeaning=correction['roleMeaning'])
summary['identity']=corrected;summary['descriptiveMetadataCorrected']=True
(out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8',newline='\n')
(out/'metadata-correction.json').write_text(json.dumps(correction,indent=2)+'\n',encoding='utf-8',newline='\n')
for name in ['observations.tgz','archive-receipt.json','terminal-status.json','selected-retirement-proof.json']:
    shutil.copyfile(run/name,out/name)
with tarfile.open(out/'preparation-and-alias-controls.tar.xz','w:xz')as a:
    for p in [Path(__file__),Path(__file__).parent/'prepare-tuple-vm-r396.py']:
        a.add(p,arcname=p.name)
    for name in ['launch-command.py','launch.log','config.json','identity.json','inventory.json','retirement-proof.json','selected-retirement-proof.json','collect.py','archive-owned.py','run.sh','retrieve.py','summarize.py']:
        a.add(run/name,arcname='preparation/'+name)
    for name in ['extra-alias-controls.tar.xz','check-wide-call-aliases.py','wide-call-controls.json','wide-call-controls-result.json','wide-call-cpython-controls.json']:
        a.add(r/name,arcname='aliases/'+name)
print('B781 original raw identity preserved; descriptive provenance corrected without retiming. Complete source-pair/control results, retirement proof and alias checks archived.')
