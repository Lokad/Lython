from pathlib import Path
import hashlib,importlib.util,json,os,subprocess,tempfile
r=Path(__file__).parent
c=json.loads((r/'catalog.json').read_text(encoding='utf-8'))
template=c['cases'][0]
sources=["def make(seed):\n return (seed+1,seed+2,seed+3,seed+4,seed+5,seed+6,seed+7,seed+8,seed+9,seed+10,seed+11,seed+12,seed+13,seed+14,seed+15,seed+16,seed+17,seed+18,seed+19,seed+20,seed+21,seed+22,seed+23,seed+24,seed+25,seed+26,seed+27,seed+28,seed+29,seed+30,seed+31,seed+32,seed+33,seed+34,seed+35,seed+36,seed+37,seed+38,seed+39,seed+40,seed+41,seed+42,seed+43,seed+44,seed+45,seed+46,seed+47,seed+48,seed+49,seed+50,seed+51,seed+52,seed+53,seed+54,seed+55,seed+56,seed+57,seed+58,seed+59,seed+60,seed+61,seed+62,seed+63,seed+64,seed+65)\nt=make(10000)\nassert len(t)==65 and t[0]+t[-1]==20066\na=t[0]\nassert a is t[0] and list(t)[0] is a\nassert (t+t)[65] is a and t[:][0] is a\nprint('ok')\n", "def make(seed):return (seed+1,seed+2)\ndef identity(value):return value\ndef pair(value):return (value,value)\ndef slow(value):\n try:return value\n finally:pass\nt=make(10000)\nx=identity(t[0])\na,b=pair(t[0])\nassert x is a and a is b and a is t[0]\nassert slow(t[0]) is a\nprint('ok')\n"]
c['cases']=[]
sha=lambda s:hashlib.sha256(s.encode()).hexdigest()
fixture=json.dumps(dict(size=template['size'],text=None,inputFiles={},outputFiles={}),separators=(',',':'))
for i,source in enumerate(sources):
    x=dict(template);x.update(id='diagnostic.tuple-wide-call.'+str(i),source=source,sourceSha256=sha(source),expectedOutput='ok\n',expectedOutputSha256=sha('ok\n'),fixtureJson=fixture,fixtureSha256=sha(fixture),expectedFilesSha256=hashlib.sha256(bytes(4)).hexdigest());c['cases'].append(x)
cat=r/'wide-call-controls.json';cat.write_text(json.dumps(c,indent=2)+'\n',encoding='utf-8',newline='\n')
spec=importlib.util.spec_from_file_location('protocol','benchmarks/cpython-worker.py');p=importlib.util.module_from_spec(spec);spec.loader.exec_module(p)
sdk='C:/Users/JoannesVermorel/.dotnet11';env=dict(os.environ);env['DOTNET_ROOT']=sdk
results=[]
for role in ['reference','candidate']:
    with tempfile.TemporaryDirectory(prefix='lython-comparison-files-') as cwd:
        with subprocess.Popen([sdk+'/dotnet.exe',str((r/role/'Lokad.Lython.Benchmarks.dll').resolve()),'--compare','worker','--catalog',str(cat.resolve())],cwd=cwd,env=env,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE) as w:
            try:
                ready=p.read_frame(w.stdout);assert ready['status']=='Ready';seq=0
                for case in c['cases']:
                    for lane in ['warm','warm-async']:
                        seq+=1;q={k:case[k] for k in ['sourceSha256','fixtureSha256','expectedOutputSha256']};q.update(protocolVersion=2,requestId=seq,operation='verify',caseId=case['id'],lane=lane,iterations=2)
                        p.write_frame(w.stdin,q);answer=p.read_frame(w.stdout);assert answer['status']=='Equivalent',answer;results.append(dict(role=role,case=case['id'],lane=lane,response=answer))
                p.write_frame(w.stdin,dict(protocolVersion=2,requestId=seq+1,operation='quit'));assert p.read_frame(w.stdout)['status']=='Closed';assert w.wait(timeout=10)==0
            finally:
                if w.poll() is None:w.kill();w.wait()
                assert not w.stderr.read()
(r/'wide-call-controls-result.json').write_text(json.dumps(dict(allPassed=True,allUsersJoined=True,results=results),indent=2)+'\n',encoding='utf-8',newline='\n')
print('Eight source/image/API controls pass; wide tuple backing and call aliases preserve identity')
