from pathlib import Path
import hashlib,importlib.util,json,os,subprocess,tempfile
r=Path(__file__).parent
c=json.loads((r/'catalog.json').read_text(encoding='utf-8'))
template=c['cases'][0]
sources=["def make(seed):\n t=(a:=seed+1,b:=seed+2)\n assert t[0] is a and t[1] is b\n return t\nmake(10000)\nprint('ok')\n", "def make(seed):\n a=seed+1\n b=seed+2\n def read():return a\n t=(a,b)\n assert t[0] is a and t[0] is read()\n return t\nmake(10000)\nprint('ok')\n"]
c['cases']=[]
sha=lambda s:hashlib.sha256(s.encode()).hexdigest()
fixture=json.dumps(dict(size=template['size'],text=None,inputFiles={},outputFiles={}),separators=(',',':'))
for i,source in enumerate(sources):
    x=dict(template);x.update(id='diagnostic.tuple-alias.'+str(i),source=source,sourceSha256=sha(source),expectedOutput='ok\n',expectedOutputSha256=sha('ok\n'),fixtureJson=fixture,fixtureSha256=sha(fixture),expectedFilesSha256=hashlib.sha256(bytes(4)).hexdigest());c['cases'].append(x)
cat=r/'alias-controls.json';cat.write_text(json.dumps(c,indent=2)+'\n',encoding='utf-8',newline='\n')
spec=importlib.util.spec_from_file_location('protocol','benchmarks/cpython-worker.py');p=importlib.util.module_from_spec(spec);spec.loader.exec_module(p)
sdk='C:/Users/JoannesVermorel/.dotnet11';env=dict(os.environ);env['DOTNET_ROOT']=sdk
results=[]
for role in ['reference','candidate']:
    with tempfile.TemporaryDirectory(prefix='lython-comparison-files-') as cwd:
        with subprocess.Popen([sdk+'/dotnet.exe',str((r/role/'Lokad.Lython.Benchmarks.dll').resolve()),'--compare','worker','--catalog',str(cat.resolve())],cwd=cwd,env=env,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE) as w:
            try:
                ready=p.read_frame(w.stdout);assert ready['status']=='Ready';seq=0
                for case in c['cases']:
                    for lane in ['warm','warm-async']:
                        seq+=1;q={k:case[k] for k in ['sourceSha256','fixtureSha256','expectedOutputSha256']};q.update(protocolVersion=2,requestId=seq,operation='verify',caseId=case['id'],lane=lane,iterations=2)
                        p.write_frame(w.stdin,q);answer=p.read_frame(w.stdout);assert answer['status']=='Equivalent',answer;results.append(dict(role=role,case=case['id'],lane=lane,response=answer))
                p.write_frame(w.stdin,dict(protocolVersion=2,requestId=seq+1,operation='quit'));assert p.read_frame(w.stdout)['status']=='Closed';assert w.wait(timeout=10)==0
            finally:
                if w.poll() is None:w.kill();w.wait()
                assert not w.stderr.read()
(r/'alias-controls-result.json').write_text(json.dumps(dict(allPassed=True,allUsersJoined=True,results=results),indent=2)+'\n',encoding='utf-8',newline='\n')
print('Eight source/image/API controls pass; walrus and closures preserve canonical identities')
