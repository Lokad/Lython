from pathlib import Path
import ast,base64,datetime,hashlib,io,json,subprocess,tarfile
r=Path(__file__).parent/'tuple-transport-r397'
out=r/'quiet';out.mkdir()
prior=r.parent/'invocation-lifetime-r390/quiet'
source=json.loads((r/'candidate-identity.json').read_text(encoding='utf-8'))
assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==h for p,h in source['sources'].items())
identity=json.loads((prior/'identity.json').read_text(encoding='utf-8'))
identity.update(sourceRevision='R397 uncommitted/frozen22e5b72c versus qualifiedb58e2dc4/frozenf304b3db',
    runtimeCommit='b58e2dc44d5b75669ec78e9027ae3d6ffb100d86',
    purpose='End-to-end computed integer tuple backing/operand transport: complete invoice/fulfillment with unchanged reference-heavy text/JSON. Separate allocation evidence from CPU/elapsed.',
    coreSHA256={label:source['frozenFiles']['candidate' if label.startswith('candidate') else 'reference']['Lokad.Lython.dll'] for label in ['reference','reference-control','candidate','candidate-control']})
for name,h in identity['auxiliaryFiles'].items():
    assert all(source['frozenFiles'][role][name]==h for role in ['reference','candidate'])
for field in ['fullSourceIdentitySHA256','committedSourceProofSHA256','qualification','roleMeaning']:
    identity.pop(field,None)
identity.update(candidateSourceIdentitySHA256=hashlib.sha256((r/'candidate-identity.json').read_bytes()).hexdigest(),
    referenceDelivery='qualifiedb58e2dc4/frozenf304; cached43700041511GREEN',
    qualification='R397focused418public/173internal each actual.NET11/10; full platform/stress/package pending if retained',
    roleMeaning={label:'R39722e5' if label.startswith('candidate') else 'qualifiedb58f304' for label in identity['coreSHA256']})
(out/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8',newline='\n')
oldname='invocation-lifetime-b777-20261115';newname='tuple-transport-b782-20261115'
for name in ['collect.py','archive-owned.py','run.sh','retrieve.py','summarize.py']:
    text=(prior/name).read_text(encoding='utf-8').replace(oldname,newname).replace('lython-b777-invocation-lifetime-20261115','lython-b782-tuple-transport-20261115').replace('B777','B782')
    text=text.replace("jobs=[['scripts.text-summary-helpers.nonlocal-counter.large', 'warm-async'], ['scripts.file-search.large.protected', 'warm-async'], ['scripts.text-summary-helpers.nonlocal-counter.large', 'warm']]", "jobs=[['scripts.csv-invoice.large','warm'],['scripts.csv-fulfillment.large','warm'],['scripts.text-summary-helpers.nonlocal-counter.large','warm'],['scripts.json-summary-helpers.large','warm']]")
    text=text.replace('len(jobs)==3','len(jobs)==4').replace("len(raw['jobs'])==3","len(raw['jobs'])==4").replace("len(raw['jobs']) == 3","len(raw['jobs']) == 4").replace("['jobs']==3","['jobs']==4").replace('jobs=3','jobs=4').replace('==3 and','==4 and').replace(" < 180, 'Reserve60seconds", " < 240, 'Reserve60seconds")
    text=text.replace('elapsedSeconds\']<240','elapsedSeconds\']<300')
    text=text.replace('three-job','four-job').replace('three-job','four-job').replace('Three-job','Four-job')
    if name=='summarize.py':
        text=text.replace('Frozen R390 versus qualified810379be, same API per job. Complete awaited RunAsync text/file plus unchanged synchronous text control.', 'Frozen R39722e5 versus qualifiedb58f304, synchronous Run per job. Complete CSV invoice/fulfillment and unchanged text/JSON controls.')
    if name.endswith('.py'):ast.parse(text)
    (out/name).write_text(text,encoding='utf-8',newline='\n')
# Every run uses the same exact input catalog and normal worker. No framework edit.
archive=Path('benchmarks/results/2026-11-15-tuple-operand-prototype/sources-checks-and-observations.tar.xz')
commit=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
blob=subprocess.check_output(['git','show',commit+':'+archive.as_posix()]);assert blob==archive.read_bytes()
with tarfile.open(archive)as a:old=a.extractfile('candidate-core.dll').read()
oldsha=hashlib.sha256(old).hexdigest();assert oldsha=='1b88e3c7580caa0c8e9227628b61c3a68e12cc391c0c4c339749190b24d75876'
proof=dict(commit=commit,archive=archive.as_posix(),archiveSHA256=hashlib.sha256(blob).hexdigest(),member='candidate-core.dll',coreSHA256=oldsha,bytes=len(old),paths=['tuple-transport-b781-20261115/candidate/Lokad.Lython.dll'])
(out/'selected-retirement-proof.json').write_text(json.dumps(proof,indent=2)+'\n',encoding='utf-8',newline='\n')
with tarfile.open(out/'payload.tgz','w:gz')as a:
    for name in ['identity.json','collect.py','archive-owned.py','run.sh']:a.add(out/name,arcname=name)
    a.add(r/'candidate/Lokad.Lython.dll',arcname='candidate/Lokad.Lython.dll')
with tarfile.open(out/'payload.tgz')as a:unpacked=sum(x.size for x in a.getmembers())
config=dict(root='/home/lokad/lython-bench-checks/'+newname,
    sourceRoot='/home/lokad/lython-bench-checks/invocation-lifetime-b777-20261115',unit='lython-b782-tuple-transport-20261115',identity=identity,
    payloadBytes=(out/'payload.tgz').stat().st_size,payloadSHA256=hashlib.sha256((out/'payload.tgz').read_bytes()).hexdigest(),unpackedBytes=unpacked,retirement=proof)
(out/'config.json').write_text(json.dumps(config,indent=2)+'\n',encoding='utf-8',newline='\n')
code='''from pathlib import Path
import ast,fcntl,hashlib,io,json,os,shutil,stat,subprocess,sys,tarfile
config=CONFIG
base=Path('/home/lokad/lython-bench-checks').resolve();root=Path(config['root']);source=Path(config['sourceRoot']);sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert root.parent==base and not root.exists()and source.parent==base and source.resolve()==source
with(base/'comparison-vm.lock').open('a')as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record|[p]ython3.*cpython-worker.py'],capture_output=True).returncode==1
 assert not any(os.path.ismount(p)for p in base.glob('*/guest-fixtures'))
 state=subprocess.check_output(['systemctl','show',config['unit']+'.service','--property=LoadState,MainPID'],text=True)
 assert 'LoadState=not-found'in state and 'MainPID=0'in state
 assert sha(source/'candidate/Lokad.Lython.dll')==config['identity']['coreSHA256']['reference']
 for name,h in config['identity']['auxiliaryFiles'].items():assert sha(source/'candidate'/name)==h
 assert sha(source/'representative.json')==config['identity']['catalogSHA256']
 payload=sys.stdin.buffer.read(config['payloadBytes']+1)
 assert len(payload)==config['payloadBytes']and hashlib.sha256(payload).hexdigest()==config['payloadSHA256']
 before=shutil.disk_usage(base).free;proof=config['retirement'];paths=[base/p for p in proof['paths']];metadata=[p.lstat()for p in paths]
 assert len({(m.st_dev,m.st_ino)for m in metadata})==1
 assert all(p.resolve()==p and p.is_relative_to(base)and stat.S_ISREG(m.st_mode)and m.st_uid==os.getuid()and m.st_nlink==len(paths)and m.st_size==proof['bytes']and sha(p)==proof['coreSHA256']for p,m in zip(paths,metadata))
 assert proof['coreSHA256']not in config['identity']['coreSHA256'].values()
 assert before+proof['bytes']>254*1024*1024+config['unpackedBytes']+65536
 for p in paths:p.unlink()
 assert shutil.disk_usage(base).free>254*1024*1024+config['unpackedBytes']+65536
 root.mkdir()
 with tarfile.open(fileobj=io.BytesIO(payload),mode='r:gz')as a:a.extractall(root,filter='data')
 for role in ['candidate','reference']:
  (root/role).mkdir(exist_ok=True)
  for name in config['identity']['auxiliaryFiles']:os.link(source/'candidate'/name,root/role/name)
 os.link(source/'candidate/Lokad.Lython.dll',root/'reference/Lokad.Lython.dll')
 assert sha(root/'candidate/Lokad.Lython.dll')==config['identity']['coreSHA256']['candidate']
 os.link(source/'representative.json',root/'representative.json');os.link(source/'cpython-worker.py',root/'cpython-worker.py')
 (root/'retirement-receipt.json').write_text(json.dumps(dict(retiredOnly=proof['paths'],custody=proof,allMetadataAndHashesVerifiedBeforeMutation=True,incomingPayloadVerifiedBeforeRetirement=True,freshIdleLease=True,qualifiedImagesAndEvidencePreserved=True,freeBeforeBytes=before,freeAfterBytes=shutil.disk_usage(base).free),indent=2)+chr(10))
 for name in ['collect.py','archive-owned.py']:ast.parse((root/name).read_text())
 subprocess.run(['/bin/sh','-n',str(root/'run.sh')],check=True)
 fixture=root/'guest-fixtures';fixture.mkdir();assert shutil.disk_usage(base).free>254*1024*1024
 (root/'space-preflight.json').write_text(json.dumps(dict(beforeFreeBytes=before,afterFreeBytes=shutil.disk_usage(base).free,oneFrozenCoreUpload=True,floorsUnchanged=True))+chr(10))
 subprocess.run(['sudo','-n','mount','-t','tmpfs','-o','size=128m,mode=0700,uid=lokad,gid=lokad','lython-b782-fixtures',str(fixture)],check=True)
try:subprocess.run(['sudo','-n','systemd-run','--unit='+config['unit'],'--property=User=lokad','--property=WorkingDirectory='+str(root),'--property=RuntimeMaxSec=300','--property=TimeoutStopSec=30','--property=KillMode=control-group','/bin/sh',str(root/'run.sh')],check=True)
except BaseException:
 subprocess.run(['sudo','-n','umount',str(fixture)],check=True);fixture.rmdir();raise
print(subprocess.check_output(['systemctl','show',config['unit']+'.service','--property=ActiveState,MainPID,RuntimeMaxUSec'],text=True))
'''.replace('CONFIG',repr(config))
ast.parse(code);(out/'launch-command.py').write_text(code,encoding='utf-8',newline='\n')
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
command="python3 -c 'import base64;exec(base64.b64decode(\""+base64.b64encode(code.encode()).decode()+"\"))'"
p=subprocess.run(ssh+[command],input=(out/'payload.tgz').read_bytes(),capture_output=True,timeout=45)
(out/'launch.log').write_bytes(p.stdout+p.stderr);assert p.returncode==0,(p.stdout+p.stderr).decode()
now=datetime.datetime.now(datetime.timezone.utc)
(out/'observe-not-before.json').write_text(json.dumps(dict(startedUTC=now.isoformat(),doNotObserveBeforeUTC=(now+datetime.timedelta(seconds=175)).isoformat(),ownerSeconds=300),indent=2)+'\n',encoding='utf-8',newline='\n')
print((p.stdout+p.stderr).decode(),flush=True);print('Observe same unit after',(now+datetime.timedelta(seconds=175)).isoformat(),flush=True)
plan=Path('PLAN.md');text=plan.read_text(encoding='utf-8');needle='**R397 bounded refinement:**'
assert needle in text
text=text.replace(needle,'**R397/B782 active:** exact 1b88/f304 source pair, four complete workloads;\n300 s owned service with awaited cleanup. Observe the same live unit after '+(now+datetime.timedelta(seconds=175)).strftime('%H:%M:%S')+' UTC.\nOnly the archived original 1b88 prototype image is retired only after exact committed-archive, hash,\nall-alias/UID/path and fresh idle-lease proof. Qualified images and floors stay.\n\n'+needle)
plan.write_text(text,encoding='utf-8',newline='\n')
