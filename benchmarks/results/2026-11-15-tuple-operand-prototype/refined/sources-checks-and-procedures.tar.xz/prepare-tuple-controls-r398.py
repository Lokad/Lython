from pathlib import Path
import ast,base64,datetime,hashlib,json,subprocess,tarfile
r=Path(__file__).parent/'tuple-transport-r397'
prior=r/'quiet';out=r/'confirmation';out.mkdir()
identity=json.loads((prior/'identity.json').read_text(encoding='utf-8'))
identity['purpose']='One bounded same-bits text/JSON confirmation: B782 unchanged text reference spread8.90%; preserve B781 original adverse source and B782 controls. No CSV retiming or new runtime.'
(out/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8',newline='\n')
for name in ['collect.py','archive-owned.py','run.sh','retrieve.py','summarize.py']:
    s=(prior/name).read_text(encoding='utf-8').replace('tuple-transport-b782-20261115','tuple-controls-b783-20261115').replace('lython-b782-tuple-transport-20261115','lython-b783-tuple-controls-20261115').replace('B782','B783')
    s=s.replace("jobs=[['scripts.csv-invoice.large','warm'],['scripts.csv-fulfillment.large','warm'],['scripts.text-summary-helpers.nonlocal-counter.large','warm'],['scripts.json-summary-helpers.large','warm']]", "jobs=[['scripts.text-summary-helpers.nonlocal-counter.large','warm'],['scripts.json-summary-helpers.large','warm']]")
    s=s.replace('len(jobs)==4','len(jobs)==2').replace("len(raw['jobs'])==4","len(raw['jobs'])==2").replace("len(raw['jobs']) == 4","len(raw['jobs']) == 2").replace("['jobs']==4","['jobs']==2").replace('jobs=4','jobs=2').replace("elapsedSeconds']<300","elapsedSeconds']<180").replace(' < 240,',' < 150,')
    s=s.replace('four-job','two-job').replace('Complete CSV invoice/fulfillment and unchanged text/JSON controls.','Same-bits text/JSON control confirmation; no new CSV observation.')
    if name.endswith('.py'):ast.parse(s)
    (out/name).write_text(s,encoding='utf-8',newline='\n')
with tarfile.open(out/'payload.tgz','w:gz')as a:
    for name in ['identity.json','collect.py','archive-owned.py','run.sh']:a.add(out/name,arcname=name)
config=dict(root='/home/lokad/lython-bench-checks/tuple-controls-b783-20261115',source='/home/lokad/lython-bench-checks/tuple-transport-b782-20261115',unit='lython-b783-tuple-controls-20261115',identity=identity,payloadBytes=(out/'payload.tgz').stat().st_size,payloadSHA256=hashlib.sha256((out/'payload.tgz').read_bytes()).hexdigest())
code='''from pathlib import Path
import fcntl,hashlib,io,json,os,shutil,subprocess,sys,tarfile
config=CONFIG
base=Path('/home/lokad/lython-bench-checks').resolve();root=Path(config['root']);source=Path(config['source']);sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert root.parent==base and not root.exists() and source.parent==base and source.resolve()==source
with(base/'comparison-vm.lock').open('a')as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record|[p]ython3.*cpython-worker.py'],capture_output=True).returncode==1
 assert not any(os.path.ismount(p)for p in base.glob('*/guest-fixtures'))
 state=subprocess.check_output(['systemctl','show',config['unit']+'.service','--property=LoadState,MainPID'],text=True)
 assert 'LoadState=not-found'in state and 'MainPID=0'in state
 for role in ['reference','candidate']:
  assert sha(source/role/'Lokad.Lython.dll')==config['identity']['coreSHA256'][role]
  for name,h in config['identity']['auxiliaryFiles'].items():assert sha(source/role/name)==h
 assert sha(source/'representative.json')==config['identity']['catalogSHA256']
 assert shutil.disk_usage(base).free>254*1024*1024+65536
 payload=sys.stdin.buffer.read(config['payloadBytes']+1);assert len(payload)==config['payloadBytes']and hashlib.sha256(payload).hexdigest()==config['payloadSHA256']
 root.mkdir()
 with tarfile.open(fileobj=io.BytesIO(payload),mode='r:gz')as a:a.extractall(root,filter='data')
 for role in ['reference','candidate']:
  (root/role).mkdir()
  for p in (source/role).iterdir():
   assert p.is_file();os.link(p,root/role/p.name)
 os.link(source/'representative.json',root/'representative.json');os.link(source/'cpython-worker.py',root/'cpython-worker.py')
 fixture=root/'guest-fixtures';fixture.mkdir()
 subprocess.run(['sudo','-n','mount','-t','tmpfs','-o','size=128m,mode=0700,uid=lokad,gid=lokad','lython-b783-fixtures',str(fixture)],check=True)
try:subprocess.run(['sudo','-n','systemd-run','--unit='+config['unit'],'--property=User=lokad','--property=WorkingDirectory='+str(root),'--property=RuntimeMaxSec=180','--property=TimeoutStopSec=30','--property=KillMode=control-group','/bin/sh',str(root/'run.sh')],check=True)
except BaseException:
 subprocess.run(['sudo','-n','umount',str(fixture)],check=True);fixture.rmdir();raise
print(subprocess.check_output(['systemctl','show',config['unit']+'.service','--property=ActiveState,MainPID,RuntimeMaxUSec'],text=True))
'''.replace('CONFIG',repr(config))
ast.parse(code);(out/'launch-command.py').write_text(code,encoding='utf-8',newline='\n')
cmd="python3 -c 'import base64;exec(base64.b64decode(\""+base64.b64encode(code.encode()).decode()+"\"))'"
p=subprocess.run(['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73',cmd],input=(out/'payload.tgz').read_bytes(),capture_output=True,timeout=30)
(out/'launch.log').write_bytes(p.stdout+p.stderr);assert p.returncode==0,(p.stdout+p.stderr).decode()
now=datetime.datetime.now(datetime.timezone.utc)
(out/'observe-not-before.json').write_text(json.dumps(dict(startedUTC=now.isoformat(),doNotObserveBeforeUTC=(now+datetime.timedelta(seconds=110)).isoformat(),ownerSeconds=180),indent=2)+'\n',encoding='utf-8',newline='\n')
print((p.stdout+p.stderr).decode(),flush=True);print('Observe same unit after',(now+datetime.timedelta(seconds=110)).isoformat(),flush=True)
