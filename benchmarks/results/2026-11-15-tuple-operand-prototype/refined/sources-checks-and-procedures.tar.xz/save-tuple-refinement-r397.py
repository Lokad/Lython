from pathlib import Path
import hashlib,json,shutil,tarfile
r=Path(__file__).parent/'tuple-transport-r397';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
f=json.loads((r/'candidate-identity.json').read_text(encoding='utf-8'))
assert all(sha(Path(p))==h for p,h in f['sources'].items())
assert all(sha(r/role/n)==h for role,files in f['frozenFiles'].items() for n,h in files.items())
stages={}
for label,folder,jobs in [('initial','quiet',4),('confirmation','confirmation',2)]:
    d=r/folder;s=json.loads((d/'summary.json').read_text(encoding='utf-8'));t=json.loads((d/'terminal-status.json').read_text(encoding='utf-8'))
    assert s['complete'] and s['jobs']==jobs and t['receipt']['complete']
    assert sha(d/'observations.tgz')==t['receipt']['archiveSHA256']
    assert not t['remainingWorkers'] and not t['remainingFixtures'] and not t['remainingTrace']
    stages[label]=s
allocation=json.loads((r/'allocation-summary.json').read_text(encoding='utf-8'));assert allocation['complete']
decision=dict(status='retain',runtimeQualification='Focused Release passed; full delivery pending',coreSHA256=f['coreSHA256'],referenceRevision=f['referenceRevision'],sourcePair=stages['initial']['timing'],controlConfirmation=stages['confirmation']['timing'],allocation=allocation['summary'],benefit='Final managed slot storage/operand transport removes eager integer boxes and object-array transfer for computed integer tuples; canonical observation preserves identities. Targeted complete CSV elapsed and wider CPU improve.',debt=['Original1b88 desktop and VM text regressions remain immutable; do not add gains across sources.', 'Refined text controls move8.90% then5.40%; no portable text gain or causal JIT explanation is established.', 'JSON original refined elapsed+0.47..+1.16%; confirmation crosseszero. Accept remaining small control uncertainty for0.11, not proven neutrality.', 'Wider typed backing and future scalar boxes require conservative admission; source tuple may remain retained by a private scalar borrow.', 'No startup, pending-I/O, host contention, tail latency or retained-heap claim.'],stoppingDecision='Bounded refinement/control confirmation complete. Retain coherent construction/transport change, preserve all adverse conditions and qualify the complete source. No more unchanged tuple timing campaign; materially new defects/evidence remain eligible.',publicationHeld=True)
(r/'decision.json').write_text(json.dumps(decision,indent=2)+'\n',encoding='utf-8',newline='\n')
out=Path('benchmarks/results/2026-11-15-tuple-operand-prototype/refined');out.mkdir()
for n in ['candidate-identity.json','focused-checks.json','allocation-summary.json','slot-il-size.json','decision.json']:shutil.copyfile(r/n,out/n)
for folder in ['quiet','confirmation']:
    (out/folder).mkdir()
    for n in ['summary.json','observations.tgz','archive-receipt.json','terminal-status.json']:shutil.copyfile(r/folder/n,out/folder/n)
with tarfile.open(out/'sources-checks-and-procedures.tar.xz','w:xz')as a:
    for n in ['candidate-sources.tar.xz','implementation.patch','catalog.json','candidate-identity.json','focused-checks.json','allocation-summary.json','reference-allocation-0.json','candidate-allocation-0.json','measure-allocation-ready.py','slot-il-size.json','decision.json','check-extra-aliases.py','alias-controls.json','alias-controls-result.json','check-wide-call-aliases.py','wide-call-controls.json','wide-call-controls-result.json']:
        a.add(r/n,arcname=n)
    a.add(r/'candidate/Lokad.Lython.dll',arcname='candidate-core.dll')
    for n in r.glob('*.log'):a.add(n,arcname='logs/'+n.name)
    for folder in ['quiet','confirmation']:
        for n in ['collect.py','archive-owned.py','retrieve.py','summarize.py','identity.json','launch-command.py','launch.log','run.sh']:
            a.add(r/folder/n,arcname=folder+'/'+n)
    for n in ['selected-retirement-proof.json','config.json']:a.add(r/'quiet'/n,arcname='quiet/'+n)
    for n in [Path(__file__),Path(__file__).parent/'qualify-tuple-transport-r397.py',Path(__file__).parent/'prepare-tuple-vm-r397.py',Path(__file__).parent/'prepare-tuple-controls-r398.py']:a.add(n,arcname=n.name)
    for n in ['tests/Lokad.Lython.Tests/TupleConstructionFailureTests.cs','tests/Lokad.Lython.PublicApi.Tests/TupleIntegerTransportTests.cs']:
        a.add(n,arcname='tests-supplement/'+n)
print('Retain22e5: complete CSV CPU/allocation benefit, all original/control debt preserved; full delivery pending')
