from pathlib import Path
import hashlib,json,re,shutil,subprocess,tarfile
r=Path(__file__).parent/'tuple-transport-r395'
identity=json.loads((r/'candidate-identity.json').read_text(encoding='utf-8'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert all(sha(Path(p))==h for p,h in identity['sources'].items())
assert all(sha(r/role/name)==h for role,files in identity['frozenFiles'].items() for name,h in files.items())
local=json.loads((r/'local-screen.json').read_text(encoding='utf-8'))
allocation=json.loads((r/'allocation-summary.json').read_text(encoding='utf-8'))
assert local['complete'] and local['allUsersJoined'] and allocation['complete']
assert not (r/'allocation-fixtures').exists() and not (r/'allocation-fixtures-ready').exists()
checks=json.loads((r/'focused-checks.json').read_text(encoding='utf-8'))
assert all(x['exit']==0 for x in checks)
extra=[]
for label in ['lifetime','admission']:
    for framework in ['net11','net10']:
        p=r/f'{label}-{framework}.log';text=p.read_text(encoding='utf-8')
        assert 'Failed:     0, Passed:     6' in text,p
        extra.append(dict(log=p.name,passed=6,sha256=sha(p)))
summary=[]
for row in local['jobs']:
    a=next(x for x in allocation['summary'] if x['case']==row['case'])
    med=row['medianMilliseconds']
    summary.append(dict(case=row['case'],allocationBytesPerJob={role:values[0] for role,values in a['processMedians'].items()},allocationChangePercent=a['allocatedByteChangePercent'],diagnosticElapsedChangePercent=row['changePercent'],referenceSpreadPercent=100*(max(med['reference'],med['reference-control'])/min(med['reference'],med['reference-control'])-1),candidateSpreadPercent=100*(max(med['candidate'],med['candidate-control'])/min(med['candidate'],med['candidate-control'])-1)))
decision=dict(status='Active uncommitted prototype; not retained or fully qualified',referenceRevision=identity['referenceRevision'],coreSHA256=identity['coreSHA256'],runtimeSourceFiles=4,summary=summary,focusedChecksPerTarget=dict(public=416,internal=171),supplementalChecks=extra,allocationBoundary='Same unchanged allocation driver, warm complete scripts including fixture reset, mediated local I/O, full output validation and result cleanup; compilation/startup/final compiled owner disposal excluded. One process/image, five64-invocation blocks per shape; process-wide CLR allocation counter, no forced GC.',elapsedBoundary=local['elapsedBoundary'],elapsedObservationSeconds=local['elapsedSeconds'],allocationObservationSeconds=allocation['elapsedSeconds'],limitations=['Desktop elapsed is diagnostic; no portable CPU gain.', 'Invoice candidate process roles differ substantially; fulfillment and JSON cross zero.', 'Text +1.34..+4.55% is retained adverse evidence, not neutrality.', 'New tuple/borrow branches add complexity; generic reference tuples still require their existing backing.', 'Wider typed capacity and all eventual boxes are conservatively admitted; earlier rejection is possible.', 'A scalar borrow can retain its whole tuple until observation/slot retirement.', 'Final platform, original stress and installed-package checks not run for this prototype.'],nextGate='Controlled quiet-VM source-pair CPU/elapsed with unchanged text/JSON controls; retain/refine/withdraw with explicit debt. First safely fund staging by retiring only an exact proved archived superseded image if needed; do not relax disk floors or replace qualified images.',publicationHeld=True)
(r/'checkpoint.json').write_text(json.dumps(decision,indent=2)+'\n',encoding='utf-8',newline='\n')
out=Path('benchmarks/results/2026-11-15-tuple-operand-prototype');out.mkdir()
shutil.copyfile(r/'checkpoint.json',out/'checkpoint.json')
with tarfile.open(out/'sources-checks-and-observations.tar.xz','w:xz') as a:
    for name in ['candidate-identity.json','candidate-sources.tar.xz','implementation.patch','catalog.json','focused-checks.json','local-screen.py','local-screen.json','measure-allocation.py','measure-allocation-ready.py','allocation-summary.json','allocation-size-correction.json','original-allocation-timeout.tar.xz','reference-allocation-0.json','candidate-allocation-0.json','reference-allocation-0.log','candidate-allocation-0.log','vm-staging-inspection.json','checkpoint.json']:
        a.add(r/name,arcname=name)
    a.add(r/'candidate/Lokad.Lython.dll',arcname='candidate-core.dll')
    for p in sorted(r.glob('*.log')):a.add(p,arcname='logs/'+p.name)
    for p in ['tests/Lokad.Lython.PublicApi.Tests/TupleIntegerTransportTests.cs','tests/Lokad.Lython.Tests/TupleConstructionFailureTests.cs']:
        a.add(p,arcname='supplemental-tests/'+p)
    for p in [Path(__file__),Path(__file__).parent/'qualify-tuple-transport-r395.py']:a.add(p,arcname=p.name)
print(json.dumps(dict(prototype=identity['coreSHA256'],focusedChecks='416public/171internal per target plus6lifetime/6admission per target',archiveSHA256=sha(out/'sources-checks-and-observations.tar.xz'),decision='Active; CPU qualification pending; no runtime commit or publication'),indent=2))
