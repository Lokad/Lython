from pathlib import Path
import hashlib,json,os,shutil,subprocess,tarfile,time
r=Path(__file__).parent/'tuple-transport-r395'
sdk='C:/Users/JoannesVermorel/.dotnet11/dotnet.exe'
public='(FullyQualifiedName~Tuple|FullyQualifiedName~IntegerPublicationTests|FullyQualifiedName~IntegerBinarySemanticsTests|FullyQualifiedName~FrameIntegerLifetimeTests|FullyQualifiedName~CopyContractTests|FullyQualifiedName~CopyProtocolExecutionTests|FullyQualifiedName~CopyOwnerLifetimeTests|FullyQualifiedName~CooperativeCancellationTests|FullyQualifiedName~AdmissionFailureCommandTests|FullyQualifiedName~GovernedMemoryContractTests|FullyQualifiedName~AsyncMidFlightCancellationTests)&Category!=Stress'
internal='(FullyQualifiedName~Tuple|FullyQualifiedName~IntegerAliasOwnershipTests|FullyQualifiedName~IntegerBinaryAdmissionTests|FullyQualifiedName~IntegerProtocolAsyncTests|FullyQualifiedName~NativeIntegerChainTests|FullyQualifiedName~DirectOperandOwnershipTests|FullyQualifiedName~StorageOwnershipBalanceTests|FullyQualifiedName~CopyOwnershipTests|FullyQualifiedName~IterationCancellationTests)&Category!=Stress'
checks=[]
for framework in ['net11.0','net10.0']:
    for role,project,selection in [('public','Lokad.Lython.PublicApi.Tests',public),('internal','Lokad.Lython.Tests',internal)]:
        cmd=[sdk,'test',f'tests/{project}/{project}.csproj','-c','Release','-f',framework,'--no-restore','--nologo','-p:UseSharedCompilation=false','--filter',selection]
        start=time.monotonic();log=r/f'{role}-{framework}-expanded.log'
        with log.open('w',encoding='utf-8',newline='\n') as stream:
            done=subprocess.run(cmd,stdout=stream,stderr=subprocess.STDOUT,timeout=240)
        row=dict(role=role,framework=framework,exit=done.returncode,seconds=time.monotonic()-start,command=cmd,log=log.name)
        checks.append(row);(r/'focused-checks.json').write_text(json.dumps(checks,indent=2)+'\n',encoding='utf-8',newline='\n')
        print(role,framework,done.returncode,log.read_text(encoding='utf-8')[-600:],flush=True)
        assert done.returncode==0,'Focused acceptance failed; do not freeze or measure'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
previous=r.parent/'invocation-lifetime-r390'
before=json.loads((previous/'candidate-identity.json').read_text(encoding='utf-8'))
for role in ['reference','candidate']:
    image=r/role;image.mkdir()
    for name,h in before['frozenFiles']['candidate'].items():
        p=previous/'candidate'/name;assert sha(p)==h;shutil.copyfile(p,image/name)
shutil.copyfile('src/Lokad.Lython/bin/Release/net11.0/Lokad.Lython.dll',r/'candidate/Lokad.Lython.dll')
catalog=json.loads((previous/'catalog.json').read_text(encoding='utf-8'))
ids=['scripts.csv-invoice.large','scripts.csv-fulfillment.large','scripts.text-summary-helpers.nonlocal-counter.large','scripts.json-summary-helpers.large']
catalog['cases']=[next(x for x in catalog['cases'] if x['id']==name) for name in ids]
(r/'catalog.json').write_text(json.dumps(catalog,indent=2)+'\n',encoding='utf-8',newline='\n')
files={role:{p.name:sha(p) for p in (r/role).iterdir() if p.is_file()} for role in ['reference','candidate']}
paths=subprocess.check_output(['git','ls-files','src/Lokad.Lython'],text=True,encoding='utf-8').splitlines()
paths += ['Directory.Build.props','Directory.Build.targets','Directory.Packages.props','global.json']
paths=[x for x in paths if Path(x).is_file()]
sources={x:sha(Path(x)) for x in paths}
with tarfile.open(r/'candidate-sources.tar.xz','w:xz') as archive:
    for name in paths:archive.add(name,arcname=name)
    archive.add('tests/Lokad.Lython.PublicApi.Tests/TupleIntegerTransportTests.cs',arcname='tests/Lokad.Lython.PublicApi.Tests/TupleIntegerTransportTests.cs')
(r/'implementation.patch').write_bytes(subprocess.check_output(['git','diff','--binary','--','src/Lokad.Lython']))
(r/'candidate-identity.json').write_text(json.dumps(dict(referenceRevision='b58e2dc44d5b75669ec78e9027ae3d6ffb100d86',coreSHA256=files['candidate']['Lokad.Lython.dll'],frozenFiles=files,sources=sources,catalogSHA256=sha(r/'catalog.json'),focusedChecks=checks,qualification='Prototype only; no full platform/package qualification',publicationHeld=True),indent=2)+'\n',encoding='utf-8',newline='\n')
print('Frozen complete prototype and unchanged auxiliary image after focused acceptance',flush=True)
