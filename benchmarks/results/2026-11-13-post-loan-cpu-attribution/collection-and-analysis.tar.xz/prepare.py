from pathlib import Path
import ast, hashlib, json, tarfile
r = Path(__file__).parent
prior = r.parent / 'next-profile-r321'
oldroot = '/home/lokad/lython-bench-checks/whole-script-profile-b686-20261113'
root = '/home/lokad/lython-bench-checks/post-loan-profile-b692-20261113'
source = '/home/lokad/lython-bench-checks/word-buffer-loan-b690-20261113'
old = json.loads((r.parent / 'word-buffer-loan-r324/b690/identity.json').read_text(encoding='utf-8'))
catalog = (prior / 'catalog.json').read_bytes()
(r / 'catalog.json').write_bytes(catalog)
description = 'Committed557d18d4/frozen9d157bb2 after word-buffer loan consolidation; corrected full delivery independently running'
identity = dict(coreSHA256={'candidate': old['coreSHA256']['candidate']}, auxiliaryFiles=old['candidateAuxiliaryFiles'], catalogSHA256=hashlib.sha256(catalog).hexdigest(), sourceRevision=description, diagnosticOnly=True, scriptCaptureWallSeconds=3, warmGuestSeconds=8, compilationExcluded=True, allocationStacksNotMeasured=True)
(r / 'identity.json').write_text(json.dumps(identity, indent=2) + '\n', encoding='utf-8', newline='\n')
for name in ['ops-profile.py', 'collect.py', 'run.sh', 'retrieve.py', 'analyze.py', 'prior-analyze.py']:
    s = (prior / name).read_text(encoding='utf-8').replace(oldroot, root)
    s = s.replace('Qualifiedcb8736ff/frozen5a184a1d complete captured-text and keyword-default search CPU attribution; no elapsed comparison or later ZIP source included', description)
    s = s.replace('Qualifiedcb8736ff/frozen5a184a1d', 'Committed557d18d4/frozen9d157bb2')
    if name.endswith('.py'): ast.parse(s)
    (r / name).write_text(s, encoding='utf-8', newline='\n')
files = {name: r / name for name in ['catalog.json', 'identity.json', 'ops-profile.py', 'collect.py', 'run.sh']}
with tarfile.open(r / 'payload.tgz', 'w:gz') as t:
    for name, p in files.items(): t.add(p, arcname=name)
config = dict(root=root, sourceRoot=source, unit='lython-b692-post-loan-profile-20261113', identity=identity, payloadBytes=(r / 'payload.tgz').stat().st_size, payloadSHA256=hashlib.sha256((r / 'payload.tgz').read_bytes()).hexdigest(), unpackedBytes=sum(p.stat().st_size for p in files.values()))
(r / 'config.json').write_text(json.dumps(config, indent=2) + '\n', encoding='utf-8', newline='\n')
s = (prior / 'launch.py').read_text(encoding='utf-8').replace("source/'reference'", "source/'candidate'").replace('lython-b686-fixtures', 'lython-b692-fixtures')
s = s.replace("source/'reference/", "source/'candidate/")
s = s.replace('timedelta(seconds=105)', 'timedelta(seconds=45)')
ast.parse(s)
(r / 'launch.py').write_text(s, encoding='utf-8', newline='\n')
p = Path('PLAN.md')
s = p.read_text(encoding='utf-8').replace('   New attribution or observability can justify confirmation/refinement; no blind inventories.', '''   New attribution or observability can justify confirmation/refinement; no blind inventories.
   **R325 source gate active:** one existing120s-owned CPU collection on frozen9d,
   two complete text/search scripts, eight guest seconds warmup and one3s capture
   each. Reuse frozen images and tooling. Earlier attribution predates35.1%text
   allocation removal. Stop after one usable capture; select a concrete activation,
   transport or construction removal from current owning stacks, with semantic
   and controlled before/after acceptance. Unknown samples remain explicit; no
   speedup or removable-CPU share is inferred from owning frames.''')
p.write_text(s, encoding='utf-8', newline='\n')
print('Prepared existing two-script diagnostic on frozen9d; no new image upload,120s owner.', flush=True)
