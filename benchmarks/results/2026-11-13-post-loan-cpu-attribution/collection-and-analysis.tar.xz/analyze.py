from pathlib import Path
import ast,json,subprocess
r=Path(__file__).parent;base=(r/'prior-analyze.py').read_text(encoding='utf-8')
for name in ['captured','search']:
 s=base.replace("folder=r/'retrieved/profiles/search'","folder=r/'retrieved/profiles/"+name+"'")
 s=s.replace('Committed40d92aef/91d0540d file-search source gate; qualification independently running','Committed557d18d4/frozen9d157bb2 '+name+' complete-script CPU attribution; not a timing comparison')
 s=s.replace('cpu-clock/fp199Hz;6s capture','cpu-clock/fp199Hz;3s capture').replace("(r/'attribution.json')","(r/'attribution-"+name+".json')")
 ast.parse(s);p=r/('analyze-'+name+'.py');p.write_text(s,encoding='utf-8',newline='\n')
 subprocess.run(['python','-X','utf8',str(p)],check=True)
 d=json.loads((r/('attribution-'+name+'.json')).read_text(encoding='utf-8'))
 print(name,'families',d['nearestFrameFamilies'],flush=True)
 print('Top leaf methods',d['topLeafCpuSamples'][:15],flush=True)
