import base64
import hashlib
import json
import os
from pathlib import Path
import shutil
import struct
import subprocess
import sys

lab = Path(__file__).resolve().parent
repo = Path.cwd()
donor = lab.parent / "lexical-binding-order-r563"
work = repo / ".git/agent-worktrees/utf8-keyword-packet-r572"
sdk = Path.home() / ".dotnet11"
dotnet = sdk / "dotnet.exe"
python = Path("C:/Python313/python.exe")
python_worker = repo / "benchmarks/cpython-worker.py"
env = dict(os.environ, DOTNET_ROOT=str(sdk), DOTNET_ROOT_X64=str(sdk),
           PATH=str(sdk) + os.pathsep + os.environ["PATH"])

def digest(data):
    return hashlib.sha256(data).hexdigest()

def load(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))

def save(path, data):
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

def run(command, logfile):
    with logfile.open("w", encoding="utf-8") as output:
        subprocess.run(command, check=True, env=env, stdout=output, stderr=subprocess.STDOUT, timeout=45)

catalog = lab / "catalog.json"
target_id = "scripts.report-forwarding.expanded"
control_id = "calls.positional.large"
core_name = "Lokad.Lython.dll"
worker_name = "Lokad.Lython.Benchmarks.dll"

if sys.argv[1] == "prepare":
    parent = lab.parent / "lazy-keyword-index-r570"
    catalog_data = load(parent / "catalog.json")
    full = lab / "full-catalog.json"
    run([dotnet, donor / "frozen/candidate" / worker_name, "--compare", "list", "--profile", "full", "--out", full],
        lab / "catalog-build.log")
    controls = ("calls.keyword.medium", "strings.formatted-report.medium")
    by_id = {case["id"]: case for case in load(full)["cases"]}
    catalog_data["cases"].extend(by_id[item] for item in controls)
    save(catalog, catalog_data)

    manifest = load(donor / "frozen-identity.json")["imageFiles"]["candidate"]
    base = donor / "frozen/candidate"
    assert len(manifest) == 32
    assert all(digest((base / name).read_bytes()) == value for name, value in manifest.items())
    identities = {}
    for role, src in [("reference", repo), ("candidate", work)]:
        replacement = (lab / "reference-artifacts/bin/Lokad.Lython/release_net11.0" / core_name
                       if role == "reference" else src / "src/Lokad.Lython/bin/Release/net11.0" / core_name)
        frozen = lab / "frozen" / role
        frozen.mkdir(parents=True)
        for name in manifest:
            shutil.copyfile(replacement if name == core_name else base / name, frozen / name)
        for path in base.glob("ValidatedAllocation.*"):
            shutil.copyfile(path, frozen / path.name)
        identities[role] = {name: digest((frozen / name).read_bytes()) for name in manifest}
        assert identities[role] == manifest | {core_name: digest(replacement.read_bytes())}
    save(lab / "frozen-identity.json", dict(referenceCommit="0f48fcbbf", candidateBase="0f48fcbbf",
                                             casesSHA256=digest(catalog.read_bytes()), images=identities))

identities = load(lab / "frozen-identity.json")["images"]
for role, files in identities.items():
    assert all(digest((lab / "frozen" / role / name).read_bytes()) == value for name, value in files.items())
reference = lab / "frozen/reference"
candidate = lab / "frozen/candidate"
if sys.argv[1] == "prepare":
    for role, image in [("reference", reference), ("candidate", candidate)]:
        run([dotnet, image / worker_name, "--compare", "verify", "--catalog", catalog, "--dotnet", dotnet,
             "--python", python, "--python-worker", python_worker, "--out", lab / f"{role}-verify.json"],
            lab / f"{role}-verify.log")
        run([dotnet, image / "ValidatedAllocation.dll", image, catalog, lab / f"{role}-allocation.json"],
            lab / f"{role}-allocation.log")
else:
    pairs = [(target_id, "warm"), ("calls.keyword.medium", "warm"),
             ("strings.formatted-report.medium", "warm"), (control_id, "warm"),
             (target_id, "compile"), ("calls.keyword.medium", "compile"),
             (target_id, "compile-run"), ("calls.keyword.medium", "compile-run")]
    for index, (case, lane) in enumerate(pairs):
        old, new = (reference, candidate) if index % 2 == 0 else (candidate, reference)
        tag = f"micro-{index}-{lane}"
        try:
            run([dotnet, new / worker_name, "--compare", "micro", "--catalog", catalog, "--dotnet", dotnet,
                 "--baseline-worker", old / worker_name, "--python", python,
                 "--python-worker", python_worker, "--out", lab / f"{tag}.json", "--case", case, "--lane", lane],
                lab / f"{tag}.log")
        except (subprocess.CalledProcessError, subprocess.TimeoutExpired) as failure:
            print(tag, "failed", repr(failure), flush=True)
        else:
            print(tag, load(lab / f"{tag}.json")["summaries"], flush=True)

for role, files in identities.items():
    assert all(digest((lab / "frozen" / role / name).read_bytes()) == value for name, value in files.items())
