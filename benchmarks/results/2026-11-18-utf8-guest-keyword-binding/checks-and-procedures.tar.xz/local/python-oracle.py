class Receiver:
    def f(self, name, /, *, café='default', **kw):
        print(name, café, list(kw.values()), next(iter(kw)) is unmatched)
unmatched = ''.join(['cafe', '\u0301'])
values = {'café': 'matched', unmatched: 42, 'name': 5}
Receiver().f('bound', **values)
Receiver().f('bound', **{unmatched: 1})
