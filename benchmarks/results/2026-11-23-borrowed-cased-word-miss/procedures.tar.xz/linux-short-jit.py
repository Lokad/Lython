from pathlib import Path
import subprocess

lab = Path(__file__).resolve().parent
ln = "/mnt/d/" + lab.relative_to(lab.anchor).as_posix()
dotnet = "/home/vermorel/.dotnet/dotnet"
for role in ("reference","candidate"):
    image=ln+"/"+role
    with (lab/(role+"-linux-short-jit.log")).open("wb") as output:
        subprocess.run(["wsl.exe", "--exec", "env", "DOTNET_ROOT=/home/vermorel/.dotnet",
            "DOTNET_JitDisasm=TryExecuteDictionaryLoop TryAccumulateBorrowedWord TryAppendBorrowedWord FindNativeTextIndex",
            "DOTNET_JitStdOutFile="+ln+"/"+role+"-linux-short-cased.asm", dotnet,
            image+"/ValidatedAllocation.dll", image, ln+"/comparison/representative.json",ln+"/"+role+"-linux-jit-allocation.json"],
            check=True,stdout=output,stderr=subprocess.STDOUT,timeout=65)
