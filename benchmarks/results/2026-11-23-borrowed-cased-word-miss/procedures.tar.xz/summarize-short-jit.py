from pathlib import Path
import json, re
lab = Path(Path(__file__).resolve().parent)
summary = {}
for target, suffix in (("windows",""),("linux","-linux")):
    summary[target] = {}
    for role in ("reference","candidate"):
        file = lab / f"{role}{suffix}-short-cased.asm"
        rows = {}
        for entry in file.read_text(encoding="utf-8-sig").split("; Assembly listing for method ")[1:]:
            signature, body = entry.split("\n",1)
            if not signature.endswith(" (Tier1)"):
                continue
            name = signature.split(":",1)[1].split("(",1)[0]
            stack = re.search(r"\bsub\s+rsp,\s*(0x[\da-fA-F]+|\d+)",body)
            code = re.search(r"Total bytes of code (\d+)",body)
            assert code, signature
            calls = re.findall(r"(?:call|jmp)\s+\[(?:[^\n]+):([^ (\[\n]+)", body)
            rows[name] = {"stackSubtractionBytes": int(stack[1],0) if stack else 0,
                "codeBytes": int(code[1]), "callees": list(dict.fromkeys(calls))}
        summary[target][role] = rows
        print(target, role, {name:(row["stackSubtractionBytes"],row["codeBytes"]) for name,row in rows.items()})
(lab/"short-jit-summary.json").write_text(json.dumps(summary,indent=2)+"\n",encoding="utf-8",newline="\n")
