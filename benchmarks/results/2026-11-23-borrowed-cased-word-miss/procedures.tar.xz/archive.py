from pathlib import Path
import gzip, hashlib, json, shutil, subprocess, tarfile

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
comparison = lab / "comparison"
quiet = comparison / "quiet"
dest = repo / "benchmarks/results/2026-11-23-borrowed-cased-word-miss"
read = lambda path: json.loads(path.read_text(encoding="utf-8"))
sha = lambda data: hashlib.sha256(data).hexdigest()
identity = read(comparison / "identity.json")
terminal = read(quiet / "terminal-status.json")
assert terminal["exitCode"] == "0" and terminal["receipt"]["archivedAndVerifiedUnderLease"]
assert sha((quiet / "observations.tar.xz").read_bytes()) == terminal["receipt"]["archiveSHA256"]
for role, files in identity["imageFiles"].items():
    assert len(files) == 32
    for name, digest in files.items():
        assert sha((lab / role / name).read_bytes()) == digest
    result, = read(lab / "small-budget" / (role + ".json"))["rows"]
    assert result["sharedBudgetBaselineRestored"] and result["coreSha256"] == files["Lokad.Lython.dll"]
    assert result["success"]
core = (lab / "candidate/Lokad.Lython.dll").read_bytes()
dest.mkdir(exist_ok=True)
revision = subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=repo, encoding="utf-8").strip()
differences = subprocess.check_output(["git", "diff", "--name-only", revision, identity["candidate"], "--", "src", "tests"], cwd=repo)
keep = not differences
(dest / "identity.json").write_text(json.dumps(dict(identity, retainedRevision=revision if keep else None),
    indent=2) + "\n", encoding="utf-8", newline="\n")
for file in ("terminal-status.json", "observations.tar.xz", "summary.json"):
    shutil.copyfile(quiet / file, dest / file)
shutil.copyfile(lab / "allocation-summary-six.json", dest / "allocation-summary.json")
shutil.copyfile(lab / "short-jit-summary.json", dest / "short-jit-summary.json")
(dest / "shared-allowance.json").write_text(json.dumps(
    {role: read(lab / "small-budget" / (role + ".json"))["rows"][0] for role in identity["imageFiles"]},
    indent=2) + "\n", encoding="utf-8", newline="\n")
(dest / "candidate-core.dll.gz").write_bytes(gzip.compress(core, mtime=0))
with tarfile.open(dest / "procedures.tar.xz", "w:xz") as archive:
    def add(file):
        archive.add(lab / file, arcname=file, recursive=False)
    for file in ("archive.py", "freeze.py", "stage.py", "quiet.py", "inspect-short-jit.py", "linux-short-jit.py", "summarize-short-jit.py", "summarize.py", "allocations.py", "test-ubuntu.py",
            "check-small-budget.py", "small-budget/Program.cs", "small-budget/BudgetCheck.csproj",
            "small-budget/build.log", "windows-freeze-build.log", "windows-white.log",
            "windows-public.log", "ubuntu-white.log", "ubuntu-public.log",
            "comparison/reference-verify.json", "comparison/candidate-verify.json", "comparison/source.patch",
            "comparison/quiet/launch.log", "comparison/quiet/observe-not-before"):
        add(file)
    for role in ("reference", "candidate"):
        for suffix in ("-allocation-six.json", "-short-cased.asm", "-linux-short-cased.asm"):
            add(role + suffix)
        add("small-budget/" + role + ".json")
assert sha(gzip.decompress((dest / "candidate-core.dll.gz").read_bytes())) == identity["coreSHA256"]["candidate"]
print(dest, "retained" if keep else "private")
