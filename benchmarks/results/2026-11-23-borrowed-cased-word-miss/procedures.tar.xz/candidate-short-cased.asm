; Assembly listing for method Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteDictionaryLoop(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool (Instrumented Tier0)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; Instrumented Tier0 code
; rbp based frame
; fully interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 704
       lea      rbp, [rsp+0x2C0]
       vxorps   xmm4, xmm4, xmm4
       mov      rax, -576
 
G_M000_IG83:                ;; offset=0x001E
       vmovdqa  xmmword ptr [rbp+rax-0x40], xmm4
       vmovdqa  xmmword ptr [rbp+rax-0x30], xmm4
       vmovdqa  xmmword ptr [rbp+rax-0x20], xmm4
       add      rax, 48
       jne      SHORT G_M000_IG83
       mov      qword ptr [rbp-0x40], rax
       mov      bword ptr [rbp+0x10], rcx
       mov      gword ptr [rbp+0x18], rdx
       mov      gword ptr [rbp+0x20], r8
       mov      bword ptr [rbp+0x28], r9
 
G_M000_IG02:                ;; offset=0x004A
       mov      dword ptr [rbp-0x1AC], 0x3E8
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       lea      rcx, bword ptr [rax+0x20]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:get_LiveExtent():int:this]
       mov      dword ptr [rbp-0x100], eax
       mov      rcx, bword ptr [rbp+0x28]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       cmp      eax, dword ptr [rbp-0x100]
       jne      SHORT G_M000_IG04
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       lea      rcx, bword ptr [rax+0x20]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:get_HasPendingDisposals():bool:this]
       test     eax, eax
       je       SHORT G_M000_IG05
 
G_M000_IG03:                ;; offset=0x0098
       mov      rcx, 0x7FFA02D26120
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG04:                ;; offset=0x00A7
       mov      rcx, 0x7FFA02D26124
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG24
 
G_M000_IG05:                ;; offset=0x00BB
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_RequiresLocalVariableMirroring():bool:this]
       test     eax, eax
       jne      G_M000_IG11
       cmp      gword ptr [rbp+0x20], 0
       jne      SHORT G_M000_IG06
       mov      dword ptr [rbp-0x194], 1
       jmp      SHORT G_M000_IG07
 
G_M000_IG06:                ;; offset=0x00E5
       mov      rcx, 0x7FFA02D26128
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, gword ptr [rbp+0x20]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:get_MirrorLocalStores():bool:this]
       test     eax, eax
       sete     al
       movzx    rax, al
       mov      dword ptr [rbp-0x194], eax
 
G_M000_IG07:                ;; offset=0x010C
       cmp      dword ptr [rbp-0x194], 0
       je       SHORT G_M000_IG08
       cmp      gword ptr [rbp+0x20], 0
       jne      SHORT G_M000_IG09
       xor      rax, rax
       mov      gword ptr [rbp-0x1A0], rax
       jmp      SHORT G_M000_IG10
 
G_M000_IG08:                ;; offset=0x0127
       mov      rcx, 0x7FFA02D2612C
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG11
 
G_M000_IG09:                ;; offset=0x0138
       mov      rcx, 0x7FFA02D26130
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, gword ptr [rbp+0x20]
       mov      rax, gword ptr [rax+0x88]
       mov      gword ptr [rbp-0x1A0], rax
 
G_M000_IG10:                ;; offset=0x0159
       mov      rcx, 0x7FFA02D26134
       call     CORINFO_HELP_COUNTPROFILE32
       cmp      gword ptr [rbp-0x1A0], 0
       sete     al
       movzx    rax, al
       mov      dword ptr [rbp-0x104], eax
       jmp      SHORT G_M000_IG12
 
G_M000_IG11:                ;; offset=0x017E
       xor      eax, eax
       mov      dword ptr [rbp-0x104], eax
 
G_M000_IG12:                ;; offset=0x0186
       movzx    rax, byte  ptr [rbp-0x104]
       mov      dword ptr [rbp-0x3C], eax
       cmp      dword ptr [rbp-0x3C], 0
       je       G_M000_IG14
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       add      rax, 32
       mov      bword ptr [rbp-0x110], rax
       mov      rcx, bword ptr [rbp+0x28]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x1B4], eax
       mov      edx, dword ptr [rbp-0x1B4]
       mov      rcx, bword ptr [rbp-0x110]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:get_Item(int):System.Object:this]
       mov      gword ptr [rbp-0x1C0], rax
       mov      rdx, gword ptr [rbp-0x1C0]
       mov      rcx, 0x7FFA02D12798
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      gword ptr [rbp-0x48], rax
       cmp      gword ptr [rbp-0x48], 0
       je       SHORT G_M000_IG15
       mov      rcx, gword ptr [rbp-0x48]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.Text.PyStringOps+CasedWhitespaceIteration:get_MemoryGovernor():Lokad.Lython.Runtime.MemoryGovernor:this]
       mov      gword ptr [rbp-0x118], rax
       mov      rcx, gword ptr [rbp+0x18]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:get_MemoryGovernor():Lokad.Lython.Runtime.MemoryGovernor:this]
       cmp      rax, gword ptr [rbp-0x118]
       je       SHORT G_M000_IG16
 
G_M000_IG13:                ;; offset=0x0223
       mov      rcx, 0x7FFA02D26138
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG14:                ;; offset=0x0232
       mov      rcx, 0x7FFA02D2613C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      eax, dword ptr [rbp-0x3C]
       mov      dword ptr [rsp+0x20], eax
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rbp+0x18]
       mov      r8, gword ptr [rbp+0x20]
       mov      r9, bword ptr [rbp+0x28]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteOrdinaryDictionaryLoop(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,bool):bool]
       mov      dword ptr [rbp-0x1B0], eax
       jmp      G_M000_IG55
 
G_M000_IG15:                ;; offset=0x0269
       mov      rcx, 0x7FFA02D26140
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG14
 
G_M000_IG16:                ;; offset=0x027A
       mov      rax, bword ptr [rbp+0x10]
       mov      eax, dword ptr [rax+0x18]
       mov      dword ptr [rbp-0x4C], eax
       mov      rcx, bword ptr [rbp+0x28]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_DictionaryLoopCallIndex():int:this]
       mov      dword ptr [rbp-0x50], eax
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_CallSites():System.Collections.Generic.IReadOnlyList`1[Lokad.Lython.Frontend.ExecutableCallSite]:this]
       mov      gword ptr [rbp-0x120], rax
       mov      rax, gword ptr [rbp-0x120]
       mov      gword ptr [rbp-0x1A8], rax
       mov      rcx, gword ptr [rbp-0x1A8]
       mov      rdx, 0x7FFA02D26148
       call     CORINFO_HELP_CLASSPROFILE32
       mov      rax, gword ptr [rbp-0x1A8]
       mov      gword ptr [rbp-0x1C8], rax
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Instructions():Lokad.Lython.Frontend.ExecutableInstruction[]:this]
       mov      ecx, dword ptr [rbp-0x50]
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG57
       mov      edx, ecx
       imul     rdx, rdx, 32
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      rcx, rax
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_CallSiteIndex():int:this]
       mov      dword ptr [rbp-0x1CC], eax
       mov      rcx, gword ptr [rbp-0x1C8]
       mov      edx, dword ptr [rbp-0x1CC]
       mov      r11, 0x7FFA02541C58
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       mov      gword ptr [rbp-0x58], rax
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Instructions():Lokad.Lython.Frontend.ExecutableInstruction[]:this]
       mov      ecx, dword ptr [rbp-0x4C]
       add      ecx, 2
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG57
       mov      edx, ecx
       imul     rdx, rdx, 32
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      bword ptr [rbp-0x60], rax
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Instructions():Lokad.Lython.Frontend.ExecutableInstruction[]:this]
       mov      ecx, dword ptr [rbp-0x50]
       inc      ecx
       cmp      ecx, dword ptr [rax+0x08]
 
G_M000_IG17:                ;; offset=0x0370
       jae      G_M000_IG57
       mov      edx, ecx
       imul     rdx, rdx, 32
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      bword ptr [rbp-0x68], rax
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Instructions():Lokad.Lython.Frontend.ExecutableInstruction[]:this]
       mov      ecx, dword ptr [rbp-0x50]
       add      ecx, 2
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG57
       mov      edx, ecx
       imul     rdx, rdx, 32
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      bword ptr [rbp-0x70], rax
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Constants():System.Object[]:this]
       mov      gword ptr [rbp-0x128], rax
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Instructions():Lokad.Lython.Frontend.ExecutableInstruction[]:this]
       mov      ecx, dword ptr [rbp-0x4C]
       add      ecx, 4
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG57
       mov      edx, ecx
       imul     rdx, rdx, 32
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      rcx, rax
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ConstantIndex():int:this]
       mov      rcx, gword ptr [rbp-0x128]
       cmp      eax, dword ptr [rcx+0x08]
       jae      G_M000_IG57
       mov      edx, eax
       lea      rcx, bword ptr [rcx+8*rdx+0x10]
       mov      rax, gword ptr [rcx]
       mov      gword ptr [rbp-0x78], rax
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Constants():System.Object[]:this]
       mov      gword ptr [rbp-0x130], rax
       mov      rcx, bword ptr [rbp-0x68]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_SecondInput():int:this]
       not      eax
       mov      rcx, gword ptr [rbp-0x130]
       cmp      eax, dword ptr [rcx+0x08]
       jae      G_M000_IG57
       mov      edx, eax
 
G_M000_IG18:                ;; offset=0x044C
       lea      rcx, bword ptr [rcx+8*rdx+0x10]
       mov      rax, gword ptr [rcx]
       mov      gword ptr [rbp-0x1D8], rax
       mov      rdx, gword ptr [rbp-0x1D8]
       mov      rcx, 0x7FFA029EB3F0
       call     [CORINFO_HELP_UNBOX]
 
G_M000_IG19:                ;; offset=0x0472
       vmovdqu  xmm0, xmmword ptr [rax]
       vmovdqu  xmmword ptr [rbp-0x88], xmm0
 
G_M000_IG20:                ;; offset=0x047E
       mov      rax, bword ptr [rbp+0x10]
       mov      rax, gword ptr [rax+0x08]
       mov      gword ptr [rbp-0x138], rax
       mov      rax, gword ptr [rbp-0x138]
       mov      gword ptr [rbp-0x280], rax
       mov      rcx, bword ptr [rbp-0x70]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_SecondInput():int:this]
       mov      rdx, gword ptr [rbp-0x280]
       cmp      eax, dword ptr [rdx+0x08]
       jae      G_M000_IG57
       mov      ecx, eax
       imul     rcx, rcx, 16
       lea      rcx, bword ptr [rdx+rcx+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Object():System.Object:this]
       mov      gword ptr [rbp-0x1E0], rax
       mov      rdx, gword ptr [rbp-0x1E0]
       mov      rcx, 0x7FFA02AEFD78
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      gword ptr [rbp-0x90], rax
       cmp      gword ptr [rbp-0x90], 0
       je       SHORT G_M000_IG22
       mov      rcx, gword ptr [rbp-0x90]
       mov      rdx, gword ptr [rbp+0x18]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.PyDict:CanAccumulateBorrowedWords(Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG23
 
G_M000_IG21:                ;; offset=0x050C
       mov      rcx, 0x7FFA02D26250
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG22:                ;; offset=0x051B
       mov      rcx, 0x7FFA02D26254
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG24
 
G_M000_IG23:                ;; offset=0x052F
       mov      eax, dword ptr [rbp-0x50]
       add      eax, 3
       mov      dword ptr [rbp-0x94], eax
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Instructions():Lokad.Lython.Frontend.ExecutableInstruction[]:this]
       mov      ecx, dword ptr [rbp-0x94]
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG57
       mov      edx, ecx
       imul     rdx, rdx, 32
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      bword ptr [rbp-0xA0], rax
       mov      rcx, bword ptr [rbp-0xA0]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_OpCode():int:this]
       cmp      eax, 47
       sete     al
       movzx    rax, al
       mov      dword ptr [rbp-0xA4], eax
       xor      eax, eax
       mov      qword ptr [rbp-0xB0], rax
       xor      eax, eax
       mov      qword ptr [rbp-0xB8], rax
       cmp      dword ptr [rbp-0xA4], 0
       je       G_M000_IG29
       mov      rax, bword ptr [rbp+0x10]
       mov      rax, gword ptr [rax+0x08]
       mov      gword ptr [rbp-0x188], rax
       mov      rcx, bword ptr [rbp-0xA0]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      rcx, gword ptr [rbp-0x188]
       cmp      eax, dword ptr [rcx+0x08]
       jae      G_M000_IG57
       mov      edx, eax
       imul     rdx, rdx, 16
       lea      rcx, bword ptr [rcx+rdx+0x10]
       mov      bword ptr [rbp-0x1E8], rcx
       mov      rcx, bword ptr [rbp-0x1E8]
       lea      rdx, [rbp-0xB0]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryReadHistogramTotal(byref,byref):bool]
       test     eax, eax
       jne      SHORT G_M000_IG26
       mov      rcx, 0x7FFA02D26258
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG24:                ;; offset=0x060B
       xor      eax, eax
 
G_M000_IG25:                ;; offset=0x060D
       add      rsp, 704
       pop      rbp
       ret      
 
G_M000_IG26:                ;; offset=0x0616
       mov      rcx, 0x7FFA02D2625C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Constants():System.Object[]:this]
       mov      gword ptr [rbp-0x190], rax
       mov      rcx, bword ptr [rbp-0xA0]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_SecondInput():int:this]
       not      eax
       mov      rcx, gword ptr [rbp-0x190]
       cmp      eax, dword ptr [rcx+0x08]
       jae      G_M000_IG57
       mov      edx, eax
       lea      rcx, bword ptr [rcx+8*rdx+0x10]
       mov      rax, gword ptr [rcx]
       mov      gword ptr [rbp-0x1F0], rax
       mov      rdx, gword ptr [rbp-0x1F0]
       mov      rcx, 0x7FFA029EB3F0
       call     [CORINFO_HELP_UNBOX]
 
G_M000_IG27:                ;; offset=0x0682
       vmovdqu  xmm0, xmmword ptr [rax]
       vmovdqu  xmmword ptr [rbp-0x200], xmm0
 
G_M000_IG28:                ;; offset=0x068E
       lea      rcx, [rbp-0x200]
       call     [System.Numerics.BigInteger:op_Explicit(System.Numerics.BigInteger):long]
       mov      qword ptr [rbp-0xB8], rax
 
G_M000_IG29:                ;; offset=0x06A2
       vxorps   xmm0, xmm0, xmm0
       vmovdqu  xmmword ptr [rbp-0xC8], xmm0
       xor      rax, rax
       mov      gword ptr [rbp-0xD0], rax
       xor      eax, eax
       mov      dword ptr [rbp-0xD4], eax
       xor      eax, eax
       mov      dword ptr [rbp-0xD8], eax
       xor      eax, eax
       mov      dword ptr [rbp-0xDC], eax
 
G_M000_IG30:                ;; offset=0x06CF
       mov      eax, dword ptr [rbp-0x1AC]
       dec      eax
       mov      dword ptr [rbp-0x1AC], eax
       cmp      dword ptr [rbp-0x1AC], 0
       jg       SHORT G_M000_IG32
 
G_M000_IG31:                ;; offset=0x06E6
       lea      rcx, [rbp-0x1AC]
       mov      edx, 496
       call     CORINFO_HELP_PATCHPOINT
       jmp      rax
 
G_M000_IG32:                ;; offset=0x06F9
       lea      rdx, [rbp-0xF0]
       lea      r8, [rbp-0xF8]
       mov      rcx, gword ptr [rbp-0x48]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.Text.PyStringOps+CasedWhitespaceIteration:TryReadWord(byref,byref):bool:this]
       test     eax, eax
       je       G_M000_IG50
 
G_M000_IG33:                ;; offset=0x071B
       vmovdqu  xmm0, xmmword ptr [rbp-0xF0]
       vmovdqu  xmmword ptr [rbp-0xC8], xmm0
 
G_M000_IG34:                ;; offset=0x072B
       mov      rax, gword ptr [rbp-0xF8]
       mov      gword ptr [rbp-0xD0], rax
       cmp      dword ptr [rbp-0xD8], 0
       jne      SHORT G_M000_IG35
       mov      rcx, bword ptr [rbp-0x60]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x208], rax
       mov      rdx, gword ptr [rbp-0x208]
       mov      rcx, gword ptr [rbp+0x18]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CheckExecution(Lokad.Lython.LythonSourceSpan):this]
       mov      rax, bword ptr [rbp+0x10]
       mov      ecx, dword ptr [rbp-0x50]
       mov      dword ptr [rax+0x18], ecx
       mov      rcx, gword ptr [rbp-0x58]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_CallSpan():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x210], rax
       mov      rdx, gword ptr [rbp-0x210]
       mov      rcx, gword ptr [rbp+0x18]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:EnterInterpreterFrame(Lokad.Lython.LythonSourceSpan):this]
       mov      dword ptr [rbp-0xD8], 1
       jmp      SHORT G_M000_IG36
 
G_M000_IG35:                ;; offset=0x07A2
       mov      rcx, 0x7FFA02D26260
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x10]
       mov      ecx, dword ptr [rbp-0x50]
       mov      dword ptr [rax+0x18], ecx
 
G_M000_IG36:                ;; offset=0x07BB
       cmp      gword ptr [rbp-0xF8], 0
       je       SHORT G_M000_IG39
       mov      rax, gword ptr [rbp-0xF8]
       mov      gword ptr [rbp-0x158], rax
 
G_M000_IG37:                ;; offset=0x07D3
       vmovdqu  xmm0, xmmword ptr [rbp-0x88]
       vmovdqu  xmmword ptr [rbp-0x220], xmm0
 
G_M000_IG38:                ;; offset=0x07E3
       mov      rcx, gword ptr [rbp-0x58]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_CallSpan():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x228], rax
       mov      rax, gword ptr [rbp-0x228]
       mov      gword ptr [rsp+0x28], rax
       lea      r9, [rbp-0x220]
       mov      r8, gword ptr [rbp-0x78]
       mov      rdx, gword ptr [rbp-0x158]
       mov      rax, gword ptr [rbp+0x18]
       mov      gword ptr [rsp+0x20], rax
       mov      rcx, gword ptr [rbp-0x90]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.PyDict:TryAccumulateWithoutAdmission(Lokad.Lython.Runtime.Text.PyString,System.Object,System.Numerics.BigInteger,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):bool:this]
       mov      dword ptr [rbp-0x14C], eax
       jmp      G_M000_IG44
 
G_M000_IG39:                ;; offset=0x0837
       mov      rcx, 0x7FFA02D26264
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG40:                ;; offset=0x0846
       vmovdqu  xmm0, xmmword ptr [rbp-0xF0]
       vmovdqu  xmmword ptr [rbp-0x148], xmm0
 
G_M000_IG41:                ;; offset=0x0856
       vmovdqu  xmm0, xmmword ptr [rbp-0x148]
       vmovdqu  xmmword ptr [rbp-0x238], xmm0
 
G_M000_IG42:                ;; offset=0x0866
       vmovdqu  xmm0, xmmword ptr [rbp-0x88]
       vmovdqu  xmmword ptr [rbp-0x248], xmm0
 
G_M000_IG43:                ;; offset=0x0876
       mov      rcx, gword ptr [rbp-0x58]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_CallSpan():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x250], rax
       mov      rax, gword ptr [rbp-0x48]
       mov      gword ptr [rsp+0x30], rax
       lea      rax, [rbp-0xD0]
       mov      qword ptr [rsp+0x38], rax
       mov      rax, gword ptr [rbp-0x250]
       mov      gword ptr [rsp+0x28], rax
       lea      rdx, [rbp-0x238]
       lea      r9, [rbp-0x248]
       mov      r8, gword ptr [rbp-0x78]
       mov      rax, gword ptr [rbp+0x18]
       mov      gword ptr [rsp+0x20], rax
       mov      rcx, gword ptr [rbp-0x90]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.PyDict:TryAccumulateBorrowedWord(System.ReadOnlySpan`1[byte],System.Object,System.Numerics.BigInteger,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.Text.PyStringOps+CasedWhitespaceIteration,byref):bool:this]
       mov      dword ptr [rbp-0x14C], eax
 
G_M000_IG44:                ;; offset=0x08DA
       cmp      dword ptr [rbp-0x14C], 0
       jne      SHORT G_M000_IG45
       mov      eax, dword ptr [rbp-0x4C]
       add      eax, 2
       mov      rcx, bword ptr [rbp+0x10]
       mov      dword ptr [rcx+0x18], eax
       mov      dword ptr [rbp-0xFC], 1
       jmp      G_M000_IG52
 
G_M000_IG45:                ;; offset=0x08FF
       cmp      dword ptr [rbp-0xA4], 0
       je       G_M000_IG49
       mov      rax, qword ptr [rbp-0xB0]
       add      rax, qword ptr [rbp-0xB8]
       mov      qword ptr [rbp-0xB0], rax
       mov      dword ptr [rbp-0xD4], 1
       mov      rax, 0xFF80000000000000
       cmp      qword ptr [rbp-0xB0], rax
       jl       SHORT G_M000_IG47
       mov      rax, 0x80000000000000
       cmp      qword ptr [rbp-0xB0], rax
       jl       SHORT G_M000_IG48
 
G_M000_IG46:                ;; offset=0x0951
       mov      rcx, 0x7FFA02D26268
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG47:                ;; offset=0x0960
       mov      rcx, 0x7FFA02D2626C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      eax, dword ptr [rbp-0x94]
       add      eax, 2
       mov      rcx, bword ptr [rbp+0x10]
       mov      dword ptr [rcx+0x18], eax
       mov      dword ptr [rbp-0xFC], 1
       jmp      G_M000_IG53
 
G_M000_IG48:                ;; offset=0x098E
       mov      rcx, 0x7FFA02D26270
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG49:                ;; offset=0x099D
       mov      rcx, 0x7FFA02D26274
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x10]
       mov      ecx, dword ptr [rbp-0x4C]
       mov      dword ptr [rax+0x18], ecx
       mov      rcx, bword ptr [rbp+0x28]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x258], rax
       mov      rdx, gword ptr [rbp-0x258]
       mov      rcx, gword ptr [rbp+0x18]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CheckExecution(Lokad.Lython.LythonSourceSpan):this]
       jmp      G_M000_IG30
 
G_M000_IG50:                ;; offset=0x09DF
       mov      rcx, 0x7FFA02D26278
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0xDC], 1
       mov      rcx, bword ptr [rbp+0x28]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_TargetIndex():int:this]
       mov      rcx, bword ptr [rbp+0x10]
       mov      dword ptr [rcx+0x18], eax
       mov      dword ptr [rbp-0xFC], 1
 
G_M000_IG51:                ;; offset=0x0A13
       call     G_M000_IG77
       jmp      SHORT G_M000_IG54
 
G_M000_IG52:                ;; offset=0x0A1A
       call     G_M000_IG77
       jmp      SHORT G_M000_IG54
 
G_M000_IG53:                ;; offset=0x0A21
       call     G_M000_IG77
       nop      
 
G_M000_IG54:                ;; offset=0x0A27
       mov      rcx, 0x7FFA02D262A0
       call     CORINFO_HELP_COUNTPROFILE32
       mov      eax, dword ptr [rbp-0xFC]
       mov      dword ptr [rbp-0x1B0], eax
 
G_M000_IG55:                ;; offset=0x0A42
       movzx    rax, byte  ptr [rbp-0x1B0]
 
G_M000_IG56:                ;; offset=0x0A49
       add      rsp, 704
       pop      rbp
       ret      
 
G_M000_IG57:                ;; offset=0x0A52
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG58:                ;; offset=0x0A58
       sub      rsp, 72
 
G_M000_IG59:                ;; offset=0x0A5C
       cmp      dword ptr [rbp-0xD4], 0
       je       SHORT G_M000_IG60
       mov      rcx, 0x7FFA02D2628C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x10]
       mov      rax, gword ptr [rax+0x08]
       mov      gword ptr [rbp-0x180], rax
       mov      rcx, bword ptr [rbp-0xA0]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      rcx, gword ptr [rbp-0x180]
       cmp      eax, dword ptr [rcx+0x08]
       jae      G_M000_IG63
       mov      edx, eax
       imul     rdx, rdx, 16
       lea      rcx, bword ptr [rcx+rdx+0x10]
       mov      bword ptr [rbp-0x270], rcx
       mov      rcx, bword ptr [rbp-0x270]
       mov      rdx, qword ptr [rbp-0xB0]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:SetInteger(long):this]
 
G_M000_IG60:                ;; offset=0x0AC6
       cmp      dword ptr [rbp-0xDC], 0
       je       SHORT G_M000_IG61
       mov      rcx, 0x7FFA02D26290
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       add      rax, 32
       mov      bword ptr [rbp-0x178], rax
       mov      rcx, bword ptr [rbp+0x28]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x274], eax
       mov      edx, dword ptr [rbp-0x274]
       mov      rcx, bword ptr [rbp-0x178]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
 
G_M000_IG61:                ;; offset=0x0B16
       mov      rcx, 0x7FFA02D26294
       call     CORINFO_HELP_COUNTPROFILE32
       nop      
 
G_M000_IG62:                ;; offset=0x0B26
       add      rsp, 72
       ret      
 
G_M000_IG63:                ;; offset=0x0B2B
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG64:                ;; offset=0x0B31
       sub      rsp, 72
 
G_M000_IG65:                ;; offset=0x0B35
       cmp      gword ptr [rbp-0xD0], 0
       jne      SHORT G_M000_IG69
       lea      rcx, [rbp-0xC8]
       call     [System.ReadOnlySpan`1[byte]:get_IsEmpty():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG66
       jmp      SHORT G_M000_IG68
 
G_M000_IG66:                ;; offset=0x0B52
       mov      rcx, 0x7FFA02D26280
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG73
 
G_M000_IG67:                ;; offset=0x0B66
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG68:                ;; offset=0x0B6C
       mov      rcx, 0x7FFA02D26284
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG69:                ;; offset=0x0B7B
       mov      rax, bword ptr [rbp+0x10]
       mov      rax, gword ptr [rax+0x08]
       mov      gword ptr [rbp-0x160], rax
       mov      rcx, bword ptr [rbp-0x70]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ThirdInput():int:this]
       mov      rcx, gword ptr [rbp-0x160]
       cmp      eax, dword ptr [rcx+0x08]
       jae      SHORT G_M000_IG67
       mov      edx, eax
       imul     rdx, rdx, 16
       lea      rcx, bword ptr [rcx+rdx+0x10]
       mov      bword ptr [rbp-0x168], rcx
       mov      rax, gword ptr [rbp-0xD0]
       mov      gword ptr [rbp-0x170], rax
       cmp      gword ptr [rbp-0xD0], 0
       jne      SHORT G_M000_IG72
       mov      rcx, 0x7FFA02D26288
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG70:                ;; offset=0x0BD9
       vmovdqu  xmm0, xmmword ptr [rbp-0xC8]
       vmovdqu  xmmword ptr [rbp-0x268], xmm0
 
G_M000_IG71:                ;; offset=0x0BE9
       lea      rdx, [rbp-0x268]
       mov      rcx, gword ptr [rbp-0x48]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.Text.PyStringOps+CasedWhitespaceIteration:Materialize(System.ReadOnlySpan`1[byte]):Lokad.Lython.Runtime.Text.PyString:this]
       mov      gword ptr [rbp-0x170], rax
 
G_M000_IG72:                ;; offset=0x0C03
       mov      rcx, bword ptr [rbp-0x168]
       mov      rdx, gword ptr [rbp-0x170]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:set_Object(System.Object):this]
 
G_M000_IG73:                ;; offset=0x0C17
       nop      
 
G_M000_IG74:                ;; offset=0x0C18
       call     G_M000_IG58
       nop      
 
G_M000_IG75:                ;; offset=0x0C1E
       mov      rcx, 0x7FFA02D26298
       call     CORINFO_HELP_COUNTPROFILE32
       nop      
 
G_M000_IG76:                ;; offset=0x0C2E
       add      rsp, 72
       ret      
 
G_M000_IG77:                ;; offset=0x0C33
       sub      rsp, 72
 
G_M000_IG78:                ;; offset=0x0C37
       cmp      dword ptr [rbp-0xD8], 0
       je       SHORT G_M000_IG79
       mov      rcx, 0x7FFA02D2627C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, gword ptr [rbp+0x18]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:LeaveInterpreterFrame():this]
 
G_M000_IG79:                ;; offset=0x0C5B
       nop      
 
G_M000_IG80:                ;; offset=0x0C5C
       call     G_M000_IG64
       nop      
 
G_M000_IG81:                ;; offset=0x0C62
       mov      rcx, 0x7FFA02D2629C
       call     CORINFO_HELP_COUNTPROFILE32
       nop      
 
G_M000_IG82:                ;; offset=0x0C72
       add      rsp, 72
       ret      
 
; Total bytes of code 3191

; Assembly listing for method Lokad.Lython.Runtime.PyDict:TryAccumulateBorrowedWord(System.ReadOnlySpan`1[byte],System.Object,System.Numerics.BigInteger,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.Text.PyStringOps+CasedWhitespaceIteration,byref):bool:this (Tier0)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; Tier0 code
; rbp based frame
; partially interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 208
       lea      rbp, [rsp+0xD0]
       xor      eax, eax
       mov      qword ptr [rbp-0x78], rax
       vxorps   xmm4, xmm4, xmm4
       vmovdqu  ymmword ptr [rbp-0x70], ymm4
       vmovdqu  ymmword ptr [rbp-0x50], ymm4
       vmovdqu  ymmword ptr [rbp-0x30], ymm4
       vmovdqa  xmmword ptr [rbp-0x10], xmm4
       mov      gword ptr [rbp+0x10], rcx
       mov      bword ptr [rbp+0x18], rdx
       mov      gword ptr [rbp+0x20], r8
       mov      bword ptr [rbp+0x28], r9
 
G_M000_IG02:                ;; offset=0x003E
       mov      rcx, gword ptr [rbp+0x30]
       mov      rdx, gword ptr [rbp+0x38]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CheckExecution(Lokad.Lython.LythonSourceSpan):this]
       mov      rax, gword ptr [rbp+0x10]
       mov      rax, gword ptr [rax+0x28]
       mov      gword ptr [rbp-0x08], rax
       mov      rax, gword ptr [rbp+0x10]
       mov      eax, dword ptr [rax+0x4C]
       mov      dword ptr [rbp-0x34], eax
       mov      rax, bword ptr [rbp+0x18]
 
G_M000_IG03:                ;; offset=0x0068
       vmovdqu  xmm0, xmmword ptr [rax]
       vmovdqu  xmmword ptr [rbp-0x30], xmm0
 
G_M000_IG04:                ;; offset=0x0071
       mov      rax, gword ptr [rbp+0x38]
       mov      gword ptr [rsp+0x20], rax
       lea      rax, [rbp-0x18]
       mov      qword ptr [rsp+0x28], rax
       mov      edx, dword ptr [rbp-0x34]
       lea      r8, [rbp-0x30]
       mov      rcx, gword ptr [rbp-0x08]
       mov      r9, gword ptr [rbp+0x30]
       call     [Lokad.Lython.Runtime.PyDict:FindNativeTextIndex(Lokad.Lython.Runtime.PyDict+NativeKey[],int,System.ReadOnlySpan`1[byte],Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,byref):int]
       mov      dword ptr [rbp-0x0C], eax
       cmp      dword ptr [rbp-0x0C], 0
       jge      SHORT G_M000_IG10
       mov      rax, bword ptr [rbp+0x18]
 
G_M000_IG05:                ;; offset=0x00A5
       vmovdqu  xmm0, xmmword ptr [rax]
       vmovdqu  xmmword ptr [rbp-0x48], xmm0
 
G_M000_IG06:                ;; offset=0x00AE
       mov      eax, dword ptr [rbp-0x18]
       mov      dword ptr [rbp-0x5C], eax
       mov      rax, bword ptr [rbp+0x28]
 
G_M000_IG07:                ;; offset=0x00B8
       vmovdqu  xmm0, xmmword ptr [rax]
       vmovdqu  xmmword ptr [rbp-0x58], xmm0
 
G_M000_IG08:                ;; offset=0x00C1
       mov      rax, gword ptr [rbp+0x30]
       mov      gword ptr [rsp+0x28], rax
       mov      rax, gword ptr [rbp+0x38]
       mov      gword ptr [rsp+0x30], rax
       mov      rax, gword ptr [rbp+0x40]
       mov      gword ptr [rsp+0x38], rax
       mov      rax, bword ptr [rbp+0x48]
       mov      bword ptr [rsp+0x40], rax
       lea      rdx, [rbp-0x48]
       mov      r8d, dword ptr [rbp-0x5C]
       lea      rax, [rbp-0x58]
       mov      qword ptr [rsp+0x20], rax
       mov      r9, gword ptr [rbp+0x20]
       mov      rcx, gword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.PyDict:TryAppendBorrowedWord(System.ReadOnlySpan`1[byte],uint,System.Object,System.Numerics.BigInteger,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.Text.PyStringOps+CasedWhitespaceIteration,byref):bool:this]
       nop      
 
G_M000_IG09:                ;; offset=0x0105
       add      rsp, 208
       pop      rbp
       ret      
 
G_M000_IG10:                ;; offset=0x010E
       mov      rax, gword ptr [rbp-0x08]
       mov      ecx, dword ptr [rbp-0x0C]
       cmp      ecx, dword ptr [rax+0x08]
       jae      SHORT G_M000_IG14
       mov      edx, ecx
       imul     rdx, rdx, 40
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      bword ptr [rbp-0x20], rax
       mov      rax, bword ptr [rbp-0x20]
       mov      rdx, gword ptr [rax]
       mov      rcx, 0x7FFA02A61030
       call     [CORINFO_HELP_CHKCASTCLASS]
       mov      gword ptr [rbp-0x78], rax
       mov      rax, bword ptr [rbp-0x20]
       mov      eax, dword ptr [rax+0x18]
       mov      dword ptr [rbp-0x7C], eax
       mov      rax, gword ptr [rbp+0x20]
       mov      gword ptr [rsp+0x20], rax
       mov      rax, bword ptr [rbp+0x28]
 
G_M000_IG11:                ;; offset=0x015B
       vmovdqu  xmm0, xmmword ptr [rax]
       vmovdqu  xmmword ptr [rbp-0x70], xmm0
 
G_M000_IG12:                ;; offset=0x0164
       mov      r8, gword ptr [rbp-0x78]
       mov      r9d, dword ptr [rbp-0x7C]
       lea      rax, [rbp-0x70]
       mov      qword ptr [rsp+0x28], rax
       mov      edx, dword ptr [rbp-0x0C]
       mov      rcx, gword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.PyDict:TryAccumulateAt(int,Lokad.Lython.Runtime.Text.PyString,uint,System.Object,System.Numerics.BigInteger):bool:this]
       nop      
 
G_M000_IG13:                ;; offset=0x0183
       add      rsp, 208
       pop      rbp
       ret      
 
G_M000_IG14:                ;; offset=0x018C
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
; Total bytes of code 402

; Assembly listing for method Lokad.Lython.Runtime.PyDict:FindNativeTextIndex(Lokad.Lython.Runtime.PyDict+NativeKey[],int,System.ReadOnlySpan`1[byte],Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,byref):int (Instrumented Tier0)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; Instrumented Tier0 code
; rbp based frame
; fully interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 256
       lea      rbp, [rsp+0x100]
       xor      eax, eax
       mov      qword ptr [rbp-0xD8], rax
       vxorps   xmm4, xmm4, xmm4
       vmovdqu  ymmword ptr [rbp-0xD0], ymm4
       vmovdqu  ymmword ptr [rbp-0xB0], ymm4
       vmovdqu  ymmword ptr [rbp-0x90], ymm4
       vmovdqu  ymmword ptr [rbp-0x70], ymm4
       vmovdqa  xmmword ptr [rbp-0x50], xmm4
       mov      qword ptr [rbp-0x40], rax
       mov      gword ptr [rbp+0x10], rcx
       mov      dword ptr [rbp+0x18], edx
       mov      bword ptr [rbp+0x20], r8
       mov      gword ptr [rbp+0x28], r9
 
G_M000_IG02:                ;; offset=0x0052
       mov      dword ptr [rbp-0x94], 0x3E8
       cmp      dword ptr [rbp+0x18], 4
       jg       G_M000_IG15
       mov      rax, bword ptr [rbp+0x20]
       cmp      dword ptr [rax+0x08], 8
       jg       SHORT G_M000_IG03
       mov      rax, bword ptr [rbp+0x38]
       xor      ecx, ecx
       mov      dword ptr [rax], ecx
       xor      eax, eax
       mov      dword ptr [rbp-0x3C], eax
       jmp      G_M000_IG12
 
G_M000_IG03:                ;; offset=0x0082
       mov      rcx, 0x7FFA02D26478
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG15
 
G_M000_IG04:                ;; offset=0x0096
       mov      rax, gword ptr [rbp+0x10]
       mov      ecx, dword ptr [rbp-0x3C]
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG34
       mov      edx, ecx
       imul     rdx, rdx, 40
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      rdx, gword ptr [rax]
       mov      rcx, 0x7FFA02A61030
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      gword ptr [rbp-0x48], rax
       cmp      gword ptr [rbp-0x48], 0
       je       G_M000_IG11
       mov      rax, bword ptr [rbp+0x20]
 
G_M000_IG05:                ;; offset=0x00D7
       vmovdqu  xmm0, xmmword ptr [rax]
       vmovdqu  xmmword ptr [rbp-0x80], xmm0
 
G_M000_IG06:                ;; offset=0x00E0
       lea      rdx, [rbp-0x90]
       mov      rcx, gword ptr [rbp-0x48]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.Text.PyString:get_Utf8Span():System.ReadOnlySpan`1[byte]:this]
 
G_M000_IG07:                ;; offset=0x00F3
       vmovdqu  xmm0, xmmword ptr [rbp-0x80]
       vmovdqu  xmmword ptr [rbp-0xA8], xmm0
 
G_M000_IG08:                ;; offset=0x0100
       vmovdqu  xmm0, xmmword ptr [rbp-0x90]
       vmovdqu  xmmword ptr [rbp-0xB8], xmm0
 
G_M000_IG09:                ;; offset=0x0110
       lea      rcx, [rbp-0xA8]
       lea      rdx, [rbp-0xB8]
       call     [System.MemoryExtensions:SequenceEqual[byte](System.ReadOnlySpan`1[byte],System.ReadOnlySpan`1[byte]):bool]
       test     eax, eax
       je       SHORT G_M000_IG10
       mov      rcx, 0x7FFA02D2647C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      eax, dword ptr [rbp-0x3C]
       mov      dword ptr [rbp-0x98], eax
       jmp      G_M000_IG32
 
G_M000_IG10:                ;; offset=0x0145
       mov      rcx, 0x7FFA02D26480
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG11:                ;; offset=0x0154
       mov      rcx, 0x7FFA02D26484
       call     CORINFO_HELP_COUNTPROFILE32
       mov      eax, dword ptr [rbp-0x3C]
       inc      eax
       mov      dword ptr [rbp-0x3C], eax
 
G_M000_IG12:                ;; offset=0x016B
       mov      eax, dword ptr [rbp-0x94]
       dec      eax
       mov      dword ptr [rbp-0x94], eax
       cmp      dword ptr [rbp-0x94], 0
       jg       SHORT G_M000_IG14
 
G_M000_IG13:                ;; offset=0x0182
       lea      rcx, [rbp-0x94]
       mov      edx, 63
       call     CORINFO_HELP_PATCHPOINT
       jmp      rax
 
G_M000_IG14:                ;; offset=0x0195
       mov      eax, dword ptr [rbp-0x3C]
       cmp      eax, dword ptr [rbp+0x18]
       jl       G_M000_IG04
       mov      rcx, 0x7FFA02D26488
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG30
 
G_M000_IG15:                ;; offset=0x01B5
       mov      rax, bword ptr [rbp+0x20]
 
G_M000_IG16:                ;; offset=0x01B9
       vmovdqu  xmm0, xmmword ptr [rax]
       vmovdqu  xmmword ptr [rbp-0x70], xmm0
 
G_M000_IG17:                ;; offset=0x01C2
       xor      eax, eax
       mov      gword ptr [rbp-0x50], rax
 
G_M000_IG18:                ;; offset=0x01C8
       vmovdqu  xmm0, xmmword ptr [rbp-0x70]
       vmovdqu  xmmword ptr [rbp-0xC8], xmm0
 
G_M000_IG19:                ;; offset=0x01D5
       lea      rcx, [rbp-0xC8]
       mov      rdx, gword ptr [rbp+0x28]
       mov      r8, gword ptr [rbp+0x30]
       mov      r9, gword ptr [rbp-0x50]
       call     [Lokad.Lython.Runtime.Text.PyString:HashUtf8(System.ReadOnlySpan`1[byte],Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,System.Threading.CancellationToken):int]
       mov      ecx, eax
       call     [Lokad.Lython.Runtime.PyValueComparer:NormalizeHash(int):int]
       mov      ecx, eax
       call     [Lokad.Lython.Runtime.PyDict:MixNativeHash(int):uint]
       mov      rcx, bword ptr [rbp+0x38]
       mov      dword ptr [rcx], eax
       cmp      dword ptr [rbp+0x18], 0
       jne      SHORT G_M000_IG20
       mov      rcx, 0x7FFA02D2648C
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG30
 
G_M000_IG20:                ;; offset=0x021E
       mov      rax, gword ptr [rbp+0x10]
       mov      edx, dword ptr [rax+0x08]
       mov      rax, bword ptr [rbp+0x38]
       mov      ecx, dword ptr [rax]
       call     [Lokad.Lython.Runtime.PyDict:NativeBucket(uint,int):int]
       mov      rcx, gword ptr [rbp+0x10]
       cmp      eax, dword ptr [rcx+0x08]
       jae      G_M000_IG34
       mov      edx, eax
       imul     rdx, rdx, 40
       lea      rcx, bword ptr [rcx+rdx+0x10]
       mov      eax, dword ptr [rcx+0x20]
       dec      eax
       mov      dword ptr [rbp-0x54], eax
       jmp      G_M000_IG27
 
G_M000_IG21:                ;; offset=0x0256
       mov      rcx, gword ptr [rbp+0x28]
       mov      rdx, gword ptr [rbp+0x30]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CheckExecution(Lokad.Lython.LythonSourceSpan):this]
       mov      rax, gword ptr [rbp+0x10]
       mov      ecx, dword ptr [rbp-0x54]
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG34
       mov      edx, ecx
       imul     rdx, rdx, 40
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      eax, dword ptr [rax+0x18]
       mov      rcx, bword ptr [rbp+0x38]
       cmp      eax, dword ptr [rcx]
       jne      G_M000_IG26
       mov      rax, gword ptr [rbp+0x10]
       mov      ecx, dword ptr [rbp-0x54]
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG34
       mov      edx, ecx
       imul     rdx, rdx, 40
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      rdx, gword ptr [rax]
       mov      rcx, 0x7FFA02A61030
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      gword ptr [rbp-0x60], rax
       cmp      gword ptr [rbp-0x60], 0
       je       SHORT G_M000_IG25
       mov      rax, bword ptr [rbp+0x20]
 
G_M000_IG22:                ;; offset=0x02CD
       vmovdqu  xmm0, xmmword ptr [rax]
       vmovdqu  xmmword ptr [rbp-0xD8], xmm0
 
G_M000_IG23:                ;; offset=0x02D9
       lea      rdx, [rbp-0xD8]
       mov      rcx, gword ptr [rbp-0x60]
       mov      r8, gword ptr [rbp+0x28]
       mov      r9, gword ptr [rbp+0x30]
       call     [Lokad.Lython.Runtime.PyDict:EqualNativeText(Lokad.Lython.Runtime.Text.PyString,System.ReadOnlySpan`1[byte],Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):bool]
       test     eax, eax
       je       SHORT G_M000_IG24
       mov      rcx, 0x7FFA02D26490
       call     CORINFO_HELP_COUNTPROFILE32
       mov      eax, dword ptr [rbp-0x54]
       mov      dword ptr [rbp-0x98], eax
       jmp      G_M000_IG32
 
G_M000_IG24:                ;; offset=0x0313
       mov      rcx, 0x7FFA02D26494
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG26
 
G_M000_IG25:                ;; offset=0x0324
       mov      rcx, 0x7FFA02D26498
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG26:                ;; offset=0x0333
       mov      rcx, 0x7FFA02D2649C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, gword ptr [rbp+0x10]
       mov      ecx, dword ptr [rbp-0x54]
       cmp      ecx, dword ptr [rax+0x08]
       jae      SHORT G_M000_IG34
       mov      edx, ecx
       imul     rdx, rdx, 40
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      eax, dword ptr [rax+0x1C]
       dec      eax
       mov      dword ptr [rbp-0x54], eax
 
G_M000_IG27:                ;; offset=0x0361
       mov      eax, dword ptr [rbp-0x94]
       dec      eax
       mov      dword ptr [rbp-0x94], eax
       cmp      dword ptr [rbp-0x94], 0
       jg       SHORT G_M000_IG29
 
G_M000_IG28:                ;; offset=0x0378
       lea      rcx, [rbp-0x94]
       mov      edx, 210
       call     CORINFO_HELP_PATCHPOINT
       jmp      rax
 
G_M000_IG29:                ;; offset=0x038B
       cmp      dword ptr [rbp-0x54], 0
       jge      G_M000_IG21
       mov      rcx, 0x7FFA02D264A0
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG30:                ;; offset=0x03A4
       mov      eax, -1
 
G_M000_IG31:                ;; offset=0x03A9
       add      rsp, 256
       pop      rbp
       ret      
 
G_M000_IG32:                ;; offset=0x03B2
       mov      eax, dword ptr [rbp-0x98]
 
G_M000_IG33:                ;; offset=0x03B8
       add      rsp, 256
       pop      rbp
       ret      
 
G_M000_IG34:                ;; offset=0x03C1
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
; Total bytes of code 967

; Assembly listing for method Lokad.Lython.Runtime.PyDict:TryAppendBorrowedWord(System.ReadOnlySpan`1[byte],uint,System.Object,System.Numerics.BigInteger,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.Text.PyStringOps+CasedWhitespaceIteration,byref):bool:this (Tier0)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; Tier0 code
; rbp based frame
; partially interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 96
       lea      rbp, [rsp+0x60]
       xor      eax, eax
       mov      qword ptr [rbp-0x28], rax
       vxorps   xmm4, xmm4, xmm4
       vmovdqu  ymmword ptr [rbp-0x20], ymm4
       mov      gword ptr [rbp+0x10], rcx
       mov      bword ptr [rbp+0x18], rdx
       mov      dword ptr [rbp+0x20], r8d
       mov      gword ptr [rbp+0x28], r9
 
G_M000_IG02:                ;; offset=0x0029
       mov      rax, bword ptr [rbp+0x18]
       cmp      dword ptr [rax+0x08], 8
       jle      SHORT G_M000_IG03
       mov      rax, gword ptr [rbp+0x10]
       mov      eax, dword ptr [rax+0x4C]
       mov      rcx, gword ptr [rbp+0x10]
       mov      rcx, gword ptr [rcx+0x28]
       cmp      eax, dword ptr [rcx+0x08]
       jne      SHORT G_M000_IG05
 
G_M000_IG03:                ;; offset=0x0047
       xor      eax, eax
 
G_M000_IG04:                ;; offset=0x0049
       add      rsp, 96
       pop      rbp
       ret      
 
G_M000_IG05:                ;; offset=0x004F
       mov      rcx, gword ptr [rbp+0x38]
       mov      rdx, gword ptr [rbp+0x40]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CheckExecution(Lokad.Lython.LythonSourceSpan):this]
       mov      rax, bword ptr [rbp+0x18]
 
G_M000_IG06:                ;; offset=0x0063
       vmovdqu  xmm0, xmmword ptr [rax]
       vmovdqu  xmmword ptr [rbp-0x10], xmm0
 
G_M000_IG07:                ;; offset=0x006C
       lea      rdx, [rbp-0x10]
       mov      rcx, gword ptr [rbp+0x48]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.Text.PyStringOps+CasedWhitespaceIteration:Materialize(System.ReadOnlySpan`1[byte]):Lokad.Lython.Runtime.Text.PyString:this]
       mov      rdx, rax
       mov      rcx, bword ptr [rbp+0x50]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rax, bword ptr [rbp+0x50]
       mov      rax, gword ptr [rax]
       mov      gword ptr [rbp-0x28], rax
       mov      rax, gword ptr [rbp+0x28]
       mov      gword ptr [rsp+0x20], rax
       mov      rax, bword ptr [rbp+0x30]
 
G_M000_IG08:                ;; offset=0x00A0
       vmovdqu  xmm0, xmmword ptr [rax]
       vmovdqu  xmmword ptr [rbp-0x20], xmm0
 
G_M000_IG09:                ;; offset=0x00A9
       lea      rax, [rbp-0x20]
       mov      qword ptr [rsp+0x28], rax
       mov      r8, gword ptr [rbp-0x28]
       mov      rcx, gword ptr [rbp+0x10]
       mov      r9d, dword ptr [rbp+0x20]
       mov      edx, -1
       call     [Lokad.Lython.Runtime.PyDict:TryAccumulateAt(int,Lokad.Lython.Runtime.Text.PyString,uint,System.Object,System.Numerics.BigInteger):bool:this]
       nop      
 
G_M000_IG10:                ;; offset=0x00CA
       add      rsp, 96
       pop      rbp
       ret      
 
; Total bytes of code 208

; Assembly listing for method Lokad.Lython.Runtime.PyDict:TryAccumulateBorrowedWord(System.ReadOnlySpan`1[byte],System.Object,System.Numerics.BigInteger,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.Text.PyStringOps+CasedWhitespaceIteration,byref):bool:this (Instrumented Tier0)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; Instrumented Tier0 code
; rbp based frame
; partially interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 208
       lea      rbp, [rsp+0xD0]
       xor      eax, eax
       mov      qword ptr [rbp-0x78], rax
       vxorps   xmm4, xmm4, xmm4
       vmovdqu  ymmword ptr [rbp-0x70], ymm4
       vmovdqu  ymmword ptr [rbp-0x50], ymm4
       vmovdqu  ymmword ptr [rbp-0x30], ymm4
       vmovdqa  xmmword ptr [rbp-0x10], xmm4
       mov      gword ptr [rbp+0x10], rcx
       mov      bword ptr [rbp+0x18], rdx
       mov      gword ptr [rbp+0x20], r8
       mov      bword ptr [rbp+0x28], r9
 
G_M000_IG02:                ;; offset=0x003E
       mov      rcx, gword ptr [rbp+0x30]
       mov      rdx, gword ptr [rbp+0x38]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CheckExecution(Lokad.Lython.LythonSourceSpan):this]
       mov      rax, gword ptr [rbp+0x10]
       mov      rax, gword ptr [rax+0x28]
       mov      gword ptr [rbp-0x08], rax
       mov      rax, gword ptr [rbp+0x10]
       mov      eax, dword ptr [rax+0x4C]
       mov      dword ptr [rbp-0x34], eax
       mov      rax, bword ptr [rbp+0x18]
 
G_M000_IG03:                ;; offset=0x0068
       vmovdqu  xmm0, xmmword ptr [rax]
       vmovdqu  xmmword ptr [rbp-0x30], xmm0
 
G_M000_IG04:                ;; offset=0x0071
       mov      rax, gword ptr [rbp+0x38]
       mov      gword ptr [rsp+0x20], rax
       lea      rax, [rbp-0x18]
       mov      qword ptr [rsp+0x28], rax
       mov      edx, dword ptr [rbp-0x34]
       lea      r8, [rbp-0x30]
       mov      rcx, gword ptr [rbp-0x08]
       mov      r9, gword ptr [rbp+0x30]
       call     [Lokad.Lython.Runtime.PyDict:FindNativeTextIndex(Lokad.Lython.Runtime.PyDict+NativeKey[],int,System.ReadOnlySpan`1[byte],Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,byref):int]
       mov      dword ptr [rbp-0x0C], eax
       cmp      dword ptr [rbp-0x0C], 0
       jge      G_M000_IG10
       mov      rcx, 0x7FFA02EDB1F8
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x18]
 
G_M000_IG05:                ;; offset=0x00B8
       vmovdqu  xmm0, xmmword ptr [rax]
       vmovdqu  xmmword ptr [rbp-0x48], xmm0
 
G_M000_IG06:                ;; offset=0x00C1
       mov      eax, dword ptr [rbp-0x18]
       mov      dword ptr [rbp-0x5C], eax
       mov      rax, bword ptr [rbp+0x28]
 
G_M000_IG07:                ;; offset=0x00CB
       vmovdqu  xmm0, xmmword ptr [rax]
       vmovdqu  xmmword ptr [rbp-0x58], xmm0
 
G_M000_IG08:                ;; offset=0x00D4
       mov      rax, gword ptr [rbp+0x30]
       mov      gword ptr [rsp+0x28], rax
       mov      rax, gword ptr [rbp+0x38]
       mov      gword ptr [rsp+0x30], rax
       mov      rax, gword ptr [rbp+0x40]
       mov      gword ptr [rsp+0x38], rax
       mov      rax, bword ptr [rbp+0x48]
       mov      bword ptr [rsp+0x40], rax
       lea      rdx, [rbp-0x48]
       mov      r8d, dword ptr [rbp-0x5C]
       lea      rax, [rbp-0x58]
       mov      qword ptr [rsp+0x20], rax
       mov      r9, gword ptr [rbp+0x20]
       mov      rcx, gword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.PyDict:TryAppendBorrowedWord(System.ReadOnlySpan`1[byte],uint,System.Object,System.Numerics.BigInteger,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.Text.PyStringOps+CasedWhitespaceIteration,byref):bool:this]
       nop      
 
G_M000_IG09:                ;; offset=0x0118
       add      rsp, 208
       pop      rbp
       ret      
 
G_M000_IG10:                ;; offset=0x0121
       mov      rcx, 0x7FFA02EDB1FC
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, gword ptr [rbp-0x08]
       mov      ecx, dword ptr [rbp-0x0C]
       cmp      ecx, dword ptr [rax+0x08]
       jae      SHORT G_M000_IG14
       mov      edx, ecx
       imul     rdx, rdx, 40
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      bword ptr [rbp-0x20], rax
       mov      rax, bword ptr [rbp-0x20]
       mov      rdx, gword ptr [rax]
       mov      rcx, 0x7FFA02A61030
       call     [CORINFO_HELP_CHKCASTCLASS]
       mov      gword ptr [rbp-0x78], rax
       mov      rax, bword ptr [rbp-0x20]
       mov      eax, dword ptr [rax+0x18]
       mov      dword ptr [rbp-0x7C], eax
       mov      rax, gword ptr [rbp+0x20]
       mov      gword ptr [rsp+0x20], rax
       mov      rax, bword ptr [rbp+0x28]
 
G_M000_IG11:                ;; offset=0x017D
       vmovdqu  xmm0, xmmword ptr [rax]
       vmovdqu  xmmword ptr [rbp-0x70], xmm0
 
G_M000_IG12:                ;; offset=0x0186
       mov      r8, gword ptr [rbp-0x78]
       mov      r9d, dword ptr [rbp-0x7C]
       lea      rax, [rbp-0x70]
       mov      qword ptr [rsp+0x28], rax
       mov      edx, dword ptr [rbp-0x0C]
       mov      rcx, gword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.PyDict:TryAccumulateAt(int,Lokad.Lython.Runtime.Text.PyString,uint,System.Object,System.Numerics.BigInteger):bool:this]
       nop      
 
G_M000_IG13:                ;; offset=0x01A5
       add      rsp, 208
       pop      rbp
       ret      
 
G_M000_IG14:                ;; offset=0x01AE
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
; Total bytes of code 436

; Assembly listing for method Lokad.Lython.Runtime.PyDict:FindNativeTextIndex(Lokad.Lython.Runtime.PyDict+NativeKey[],int,System.ReadOnlySpan`1[byte],Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,byref):int (Instrumented Tier0)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; Instrumented Tier0 code
; rbp based frame
; fully interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 256
       lea      rbp, [rsp+0x100]
       xor      eax, eax
       mov      qword ptr [rbp-0xD8], rax
       vxorps   xmm4, xmm4, xmm4
       vmovdqu  ymmword ptr [rbp-0xD0], ymm4
       vmovdqu  ymmword ptr [rbp-0xB0], ymm4
       vmovdqu  ymmword ptr [rbp-0x90], ymm4
       vmovdqu  ymmword ptr [rbp-0x70], ymm4
       vmovdqa  xmmword ptr [rbp-0x50], xmm4
       mov      qword ptr [rbp-0x40], rax
       mov      gword ptr [rbp+0x10], rcx
       mov      dword ptr [rbp+0x18], edx
       mov      bword ptr [rbp+0x20], r8
       mov      gword ptr [rbp+0x28], r9
 
G_M000_IG02:                ;; offset=0x0052
       mov      dword ptr [rbp-0x94], 0x3E8
       cmp      dword ptr [rbp+0x18], 4
       jg       G_M000_IG15
       mov      rax, bword ptr [rbp+0x20]
       cmp      dword ptr [rax+0x08], 8
       jg       SHORT G_M000_IG03
       mov      rax, bword ptr [rbp+0x38]
       xor      ecx, ecx
       mov      dword ptr [rax], ecx
       xor      eax, eax
       mov      dword ptr [rbp-0x3C], eax
       jmp      G_M000_IG12
 
G_M000_IG03:                ;; offset=0x0082
       mov      rcx, 0x7FFA02D26478
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG15
 
G_M000_IG04:                ;; offset=0x0096
       mov      rax, gword ptr [rbp+0x10]
       mov      ecx, dword ptr [rbp-0x3C]
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG34
       mov      edx, ecx
       imul     rdx, rdx, 40
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      rdx, gword ptr [rax]
       mov      rcx, 0x7FFA02A61030
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      gword ptr [rbp-0x48], rax
       cmp      gword ptr [rbp-0x48], 0
       je       G_M000_IG11
       mov      rax, bword ptr [rbp+0x20]
 
G_M000_IG05:                ;; offset=0x00D7
       vmovdqu  xmm0, xmmword ptr [rax]
       vmovdqu  xmmword ptr [rbp-0x80], xmm0
 
G_M000_IG06:                ;; offset=0x00E0
       lea      rdx, [rbp-0x90]
       mov      rcx, gword ptr [rbp-0x48]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.Text.PyString:get_Utf8Span():System.ReadOnlySpan`1[byte]:this]
 
G_M000_IG07:                ;; offset=0x00F3
       vmovdqu  xmm0, xmmword ptr [rbp-0x80]
       vmovdqu  xmmword ptr [rbp-0xA8], xmm0
 
G_M000_IG08:                ;; offset=0x0100
       vmovdqu  xmm0, xmmword ptr [rbp-0x90]
       vmovdqu  xmmword ptr [rbp-0xB8], xmm0
 
G_M000_IG09:                ;; offset=0x0110
       lea      rcx, [rbp-0xA8]
       lea      rdx, [rbp-0xB8]
       call     [System.MemoryExtensions:SequenceEqual[byte](System.ReadOnlySpan`1[byte],System.ReadOnlySpan`1[byte]):bool]
       test     eax, eax
       je       SHORT G_M000_IG10
       mov      rcx, 0x7FFA02D2647C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      eax, dword ptr [rbp-0x3C]
       mov      dword ptr [rbp-0x98], eax
       jmp      G_M000_IG32
 
G_M000_IG10:                ;; offset=0x0145
       mov      rcx, 0x7FFA02D26480
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG11:                ;; offset=0x0154
       mov      rcx, 0x7FFA02D26484
       call     CORINFO_HELP_COUNTPROFILE32
       mov      eax, dword ptr [rbp-0x3C]
       inc      eax
       mov      dword ptr [rbp-0x3C], eax
 
G_M000_IG12:                ;; offset=0x016B
       mov      eax, dword ptr [rbp-0x94]
       dec      eax
       mov      dword ptr [rbp-0x94], eax
       cmp      dword ptr [rbp-0x94], 0
       jg       SHORT G_M000_IG14
 
G_M000_IG13:                ;; offset=0x0182
       lea      rcx, [rbp-0x94]
       mov      edx, 63
       call     CORINFO_HELP_PATCHPOINT
       jmp      rax
 
G_M000_IG14:                ;; offset=0x0195
       mov      eax, dword ptr [rbp-0x3C]
       cmp      eax, dword ptr [rbp+0x18]
       jl       G_M000_IG04
       mov      rcx, 0x7FFA02D26488
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG30
 
G_M000_IG15:                ;; offset=0x01B5
       mov      rax, bword ptr [rbp+0x20]
 
G_M000_IG16:                ;; offset=0x01B9
       vmovdqu  xmm0, xmmword ptr [rax]
       vmovdqu  xmmword ptr [rbp-0x70], xmm0
 
G_M000_IG17:                ;; offset=0x01C2
       xor      eax, eax
       mov      gword ptr [rbp-0x50], rax
 
G_M000_IG18:                ;; offset=0x01C8
       vmovdqu  xmm0, xmmword ptr [rbp-0x70]
       vmovdqu  xmmword ptr [rbp-0xC8], xmm0
 
G_M000_IG19:                ;; offset=0x01D5
       lea      rcx, [rbp-0xC8]
       mov      rdx, gword ptr [rbp+0x28]
       mov      r8, gword ptr [rbp+0x30]
       mov      r9, gword ptr [rbp-0x50]
       call     [Lokad.Lython.Runtime.Text.PyString:HashUtf8(System.ReadOnlySpan`1[byte],Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,System.Threading.CancellationToken):int]
       mov      ecx, eax
       call     [Lokad.Lython.Runtime.PyValueComparer:NormalizeHash(int):int]
       mov      ecx, eax
       call     [Lokad.Lython.Runtime.PyDict:MixNativeHash(int):uint]
       mov      rcx, bword ptr [rbp+0x38]
       mov      dword ptr [rcx], eax
       cmp      dword ptr [rbp+0x18], 0
       jne      SHORT G_M000_IG20
       mov      rcx, 0x7FFA02D2648C
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG30
 
G_M000_IG20:                ;; offset=0x021E
       mov      rax, gword ptr [rbp+0x10]
       mov      edx, dword ptr [rax+0x08]
       mov      rax, bword ptr [rbp+0x38]
       mov      ecx, dword ptr [rax]
       call     [Lokad.Lython.Runtime.PyDict:NativeBucket(uint,int):int]
       mov      rcx, gword ptr [rbp+0x10]
       cmp      eax, dword ptr [rcx+0x08]
       jae      G_M000_IG34
       mov      edx, eax
       imul     rdx, rdx, 40
       lea      rcx, bword ptr [rcx+rdx+0x10]
       mov      eax, dword ptr [rcx+0x20]
       dec      eax
       mov      dword ptr [rbp-0x54], eax
       jmp      G_M000_IG27
 
G_M000_IG21:                ;; offset=0x0256
       mov      rcx, gword ptr [rbp+0x28]
       mov      rdx, gword ptr [rbp+0x30]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CheckExecution(Lokad.Lython.LythonSourceSpan):this]
       mov      rax, gword ptr [rbp+0x10]
       mov      ecx, dword ptr [rbp-0x54]
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG34
       mov      edx, ecx
       imul     rdx, rdx, 40
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      eax, dword ptr [rax+0x18]
       mov      rcx, bword ptr [rbp+0x38]
       cmp      eax, dword ptr [rcx]
       jne      G_M000_IG26
       mov      rax, gword ptr [rbp+0x10]
       mov      ecx, dword ptr [rbp-0x54]
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG34
       mov      edx, ecx
       imul     rdx, rdx, 40
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      rdx, gword ptr [rax]
       mov      rcx, 0x7FFA02A61030
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      gword ptr [rbp-0x60], rax
       cmp      gword ptr [rbp-0x60], 0
       je       SHORT G_M000_IG25
       mov      rax, bword ptr [rbp+0x20]
 
G_M000_IG22:                ;; offset=0x02CD
       vmovdqu  xmm0, xmmword ptr [rax]
       vmovdqu  xmmword ptr [rbp-0xD8], xmm0
 
G_M000_IG23:                ;; offset=0x02D9
       lea      rdx, [rbp-0xD8]
       mov      rcx, gword ptr [rbp-0x60]
       mov      r8, gword ptr [rbp+0x28]
       mov      r9, gword ptr [rbp+0x30]
       call     [Lokad.Lython.Runtime.PyDict:EqualNativeText(Lokad.Lython.Runtime.Text.PyString,System.ReadOnlySpan`1[byte],Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):bool]
       test     eax, eax
       je       SHORT G_M000_IG24
       mov      rcx, 0x7FFA02D26490
       call     CORINFO_HELP_COUNTPROFILE32
       mov      eax, dword ptr [rbp-0x54]
       mov      dword ptr [rbp-0x98], eax
       jmp      G_M000_IG32
 
G_M000_IG24:                ;; offset=0x0313
       mov      rcx, 0x7FFA02D26494
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG26
 
G_M000_IG25:                ;; offset=0x0324
       mov      rcx, 0x7FFA02D26498
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG26:                ;; offset=0x0333
       mov      rcx, 0x7FFA02D2649C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, gword ptr [rbp+0x10]
       mov      ecx, dword ptr [rbp-0x54]
       cmp      ecx, dword ptr [rax+0x08]
       jae      SHORT G_M000_IG34
       mov      edx, ecx
       imul     rdx, rdx, 40
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      eax, dword ptr [rax+0x1C]
       dec      eax
       mov      dword ptr [rbp-0x54], eax
 
G_M000_IG27:                ;; offset=0x0361
       mov      eax, dword ptr [rbp-0x94]
       dec      eax
       mov      dword ptr [rbp-0x94], eax
       cmp      dword ptr [rbp-0x94], 0
       jg       SHORT G_M000_IG29
 
G_M000_IG28:                ;; offset=0x0378
       lea      rcx, [rbp-0x94]
       mov      edx, 210
       call     CORINFO_HELP_PATCHPOINT
       jmp      rax
 
G_M000_IG29:                ;; offset=0x038B
       cmp      dword ptr [rbp-0x54], 0
       jge      G_M000_IG21
       mov      rcx, 0x7FFA02D264A0
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG30:                ;; offset=0x03A4
       mov      eax, -1
 
G_M000_IG31:                ;; offset=0x03A9
       add      rsp, 256
       pop      rbp
       ret      
 
G_M000_IG32:                ;; offset=0x03B2
       mov      eax, dword ptr [rbp-0x98]
 
G_M000_IG33:                ;; offset=0x03B8
       add      rsp, 256
       pop      rbp
       ret      
 
G_M000_IG34:                ;; offset=0x03C1
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
; Total bytes of code 967

; Assembly listing for method Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteDictionaryLoop(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool (Instrumented Tier0)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; Instrumented Tier0 code
; rbp based frame
; fully interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 704
       lea      rbp, [rsp+0x2C0]
       vxorps   xmm4, xmm4, xmm4
       mov      rax, -576
 
G_M000_IG83:                ;; offset=0x001E
       vmovdqa  xmmword ptr [rbp+rax-0x40], xmm4
       vmovdqa  xmmword ptr [rbp+rax-0x30], xmm4
       vmovdqa  xmmword ptr [rbp+rax-0x20], xmm4
       add      rax, 48
       jne      SHORT G_M000_IG83
       mov      qword ptr [rbp-0x40], rax
       mov      bword ptr [rbp+0x10], rcx
       mov      gword ptr [rbp+0x18], rdx
       mov      gword ptr [rbp+0x20], r8
       mov      bword ptr [rbp+0x28], r9
 
G_M000_IG02:                ;; offset=0x004A
       mov      dword ptr [rbp-0x1AC], 0x3E8
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       lea      rcx, bword ptr [rax+0x20]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:get_LiveExtent():int:this]
       mov      dword ptr [rbp-0x100], eax
       mov      rcx, bword ptr [rbp+0x28]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       cmp      eax, dword ptr [rbp-0x100]
       jne      SHORT G_M000_IG04
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       lea      rcx, bword ptr [rax+0x20]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:get_HasPendingDisposals():bool:this]
       test     eax, eax
       je       SHORT G_M000_IG05
 
G_M000_IG03:                ;; offset=0x0098
       mov      rcx, 0x7FFA02D26120
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG04:                ;; offset=0x00A7
       mov      rcx, 0x7FFA02D26124
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG24
 
G_M000_IG05:                ;; offset=0x00BB
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_RequiresLocalVariableMirroring():bool:this]
       test     eax, eax
       jne      G_M000_IG11
       cmp      gword ptr [rbp+0x20], 0
       jne      SHORT G_M000_IG06
       mov      dword ptr [rbp-0x194], 1
       jmp      SHORT G_M000_IG07
 
G_M000_IG06:                ;; offset=0x00E5
       mov      rcx, 0x7FFA02D26128
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, gword ptr [rbp+0x20]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:get_MirrorLocalStores():bool:this]
       test     eax, eax
       sete     al
       movzx    rax, al
       mov      dword ptr [rbp-0x194], eax
 
G_M000_IG07:                ;; offset=0x010C
       cmp      dword ptr [rbp-0x194], 0
       je       SHORT G_M000_IG08
       cmp      gword ptr [rbp+0x20], 0
       jne      SHORT G_M000_IG09
       xor      rax, rax
       mov      gword ptr [rbp-0x1A0], rax
       jmp      SHORT G_M000_IG10
 
G_M000_IG08:                ;; offset=0x0127
       mov      rcx, 0x7FFA02D2612C
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG11
 
G_M000_IG09:                ;; offset=0x0138
       mov      rcx, 0x7FFA02D26130
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, gword ptr [rbp+0x20]
       mov      rax, gword ptr [rax+0x88]
       mov      gword ptr [rbp-0x1A0], rax
 
G_M000_IG10:                ;; offset=0x0159
       mov      rcx, 0x7FFA02D26134
       call     CORINFO_HELP_COUNTPROFILE32
       cmp      gword ptr [rbp-0x1A0], 0
       sete     al
       movzx    rax, al
       mov      dword ptr [rbp-0x104], eax
       jmp      SHORT G_M000_IG12
 
G_M000_IG11:                ;; offset=0x017E
       xor      eax, eax
       mov      dword ptr [rbp-0x104], eax
 
G_M000_IG12:                ;; offset=0x0186
       movzx    rax, byte  ptr [rbp-0x104]
       mov      dword ptr [rbp-0x3C], eax
       cmp      dword ptr [rbp-0x3C], 0
       je       G_M000_IG14
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       add      rax, 32
       mov      bword ptr [rbp-0x110], rax
       mov      rcx, bword ptr [rbp+0x28]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x1B4], eax
       mov      edx, dword ptr [rbp-0x1B4]
       mov      rcx, bword ptr [rbp-0x110]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:get_Item(int):System.Object:this]
       mov      gword ptr [rbp-0x1C0], rax
       mov      rdx, gword ptr [rbp-0x1C0]
       mov      rcx, 0x7FFA02D12798
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      gword ptr [rbp-0x48], rax
       cmp      gword ptr [rbp-0x48], 0
       je       SHORT G_M000_IG15
       mov      rcx, gword ptr [rbp-0x48]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.Text.PyStringOps+CasedWhitespaceIteration:get_MemoryGovernor():Lokad.Lython.Runtime.MemoryGovernor:this]
       mov      gword ptr [rbp-0x118], rax
       mov      rcx, gword ptr [rbp+0x18]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:get_MemoryGovernor():Lokad.Lython.Runtime.MemoryGovernor:this]
       cmp      rax, gword ptr [rbp-0x118]
       je       SHORT G_M000_IG16
 
G_M000_IG13:                ;; offset=0x0223
       mov      rcx, 0x7FFA02D26138
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG14:                ;; offset=0x0232
       mov      rcx, 0x7FFA02D2613C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      eax, dword ptr [rbp-0x3C]
       mov      dword ptr [rsp+0x20], eax
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rbp+0x18]
       mov      r8, gword ptr [rbp+0x20]
       mov      r9, bword ptr [rbp+0x28]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteOrdinaryDictionaryLoop(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,bool):bool]
       mov      dword ptr [rbp-0x1B0], eax
       jmp      G_M000_IG55
 
G_M000_IG15:                ;; offset=0x0269
       mov      rcx, 0x7FFA02D26140
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG14
 
G_M000_IG16:                ;; offset=0x027A
       mov      rax, bword ptr [rbp+0x10]
       mov      eax, dword ptr [rax+0x18]
       mov      dword ptr [rbp-0x4C], eax
       mov      rcx, bword ptr [rbp+0x28]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_DictionaryLoopCallIndex():int:this]
       mov      dword ptr [rbp-0x50], eax
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_CallSites():System.Collections.Generic.IReadOnlyList`1[Lokad.Lython.Frontend.ExecutableCallSite]:this]
       mov      gword ptr [rbp-0x120], rax
       mov      rax, gword ptr [rbp-0x120]
       mov      gword ptr [rbp-0x1A8], rax
       mov      rcx, gword ptr [rbp-0x1A8]
       mov      rdx, 0x7FFA02D26148
       call     CORINFO_HELP_CLASSPROFILE32
       mov      rax, gword ptr [rbp-0x1A8]
       mov      gword ptr [rbp-0x1C8], rax
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Instructions():Lokad.Lython.Frontend.ExecutableInstruction[]:this]
       mov      ecx, dword ptr [rbp-0x50]
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG57
       mov      edx, ecx
       imul     rdx, rdx, 32
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      rcx, rax
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_CallSiteIndex():int:this]
       mov      dword ptr [rbp-0x1CC], eax
       mov      rcx, gword ptr [rbp-0x1C8]
       mov      edx, dword ptr [rbp-0x1CC]
       mov      r11, 0x7FFA025420C0
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       mov      gword ptr [rbp-0x58], rax
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Instructions():Lokad.Lython.Frontend.ExecutableInstruction[]:this]
       mov      ecx, dword ptr [rbp-0x4C]
       add      ecx, 2
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG57
       mov      edx, ecx
       imul     rdx, rdx, 32
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      bword ptr [rbp-0x60], rax
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Instructions():Lokad.Lython.Frontend.ExecutableInstruction[]:this]
       mov      ecx, dword ptr [rbp-0x50]
       inc      ecx
       cmp      ecx, dword ptr [rax+0x08]
 
G_M000_IG17:                ;; offset=0x0370
       jae      G_M000_IG57
       mov      edx, ecx
       imul     rdx, rdx, 32
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      bword ptr [rbp-0x68], rax
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Instructions():Lokad.Lython.Frontend.ExecutableInstruction[]:this]
       mov      ecx, dword ptr [rbp-0x50]
       add      ecx, 2
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG57
       mov      edx, ecx
       imul     rdx, rdx, 32
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      bword ptr [rbp-0x70], rax
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Constants():System.Object[]:this]
       mov      gword ptr [rbp-0x128], rax
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Instructions():Lokad.Lython.Frontend.ExecutableInstruction[]:this]
       mov      ecx, dword ptr [rbp-0x4C]
       add      ecx, 4
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG57
       mov      edx, ecx
       imul     rdx, rdx, 32
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      rcx, rax
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ConstantIndex():int:this]
       mov      rcx, gword ptr [rbp-0x128]
       cmp      eax, dword ptr [rcx+0x08]
       jae      G_M000_IG57
       mov      edx, eax
       lea      rcx, bword ptr [rcx+8*rdx+0x10]
       mov      rax, gword ptr [rcx]
       mov      gword ptr [rbp-0x78], rax
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Constants():System.Object[]:this]
       mov      gword ptr [rbp-0x130], rax
       mov      rcx, bword ptr [rbp-0x68]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_SecondInput():int:this]
       not      eax
       mov      rcx, gword ptr [rbp-0x130]
       cmp      eax, dword ptr [rcx+0x08]
       jae      G_M000_IG57
       mov      edx, eax
 
G_M000_IG18:                ;; offset=0x044C
       lea      rcx, bword ptr [rcx+8*rdx+0x10]
       mov      rax, gword ptr [rcx]
       mov      gword ptr [rbp-0x1D8], rax
       mov      rdx, gword ptr [rbp-0x1D8]
       mov      rcx, 0x7FFA029EB3F0
       call     [CORINFO_HELP_UNBOX]
 
G_M000_IG19:                ;; offset=0x0472
       vmovdqu  xmm0, xmmword ptr [rax]
       vmovdqu  xmmword ptr [rbp-0x88], xmm0
 
G_M000_IG20:                ;; offset=0x047E
       mov      rax, bword ptr [rbp+0x10]
       mov      rax, gword ptr [rax+0x08]
       mov      gword ptr [rbp-0x138], rax
       mov      rax, gword ptr [rbp-0x138]
       mov      gword ptr [rbp-0x280], rax
       mov      rcx, bword ptr [rbp-0x70]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_SecondInput():int:this]
       mov      rdx, gword ptr [rbp-0x280]
       cmp      eax, dword ptr [rdx+0x08]
       jae      G_M000_IG57
       mov      ecx, eax
       imul     rcx, rcx, 16
       lea      rcx, bword ptr [rdx+rcx+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Object():System.Object:this]
       mov      gword ptr [rbp-0x1E0], rax
       mov      rdx, gword ptr [rbp-0x1E0]
       mov      rcx, 0x7FFA02AEFD78
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      gword ptr [rbp-0x90], rax
       cmp      gword ptr [rbp-0x90], 0
       je       SHORT G_M000_IG22
       mov      rcx, gword ptr [rbp-0x90]
       mov      rdx, gword ptr [rbp+0x18]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.PyDict:CanAccumulateBorrowedWords(Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG23
 
G_M000_IG21:                ;; offset=0x050C
       mov      rcx, 0x7FFA02D26250
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG22:                ;; offset=0x051B
       mov      rcx, 0x7FFA02D26254
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG24
 
G_M000_IG23:                ;; offset=0x052F
       mov      eax, dword ptr [rbp-0x50]
       add      eax, 3
       mov      dword ptr [rbp-0x94], eax
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Instructions():Lokad.Lython.Frontend.ExecutableInstruction[]:this]
       mov      ecx, dword ptr [rbp-0x94]
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG57
       mov      edx, ecx
       imul     rdx, rdx, 32
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      bword ptr [rbp-0xA0], rax
       mov      rcx, bword ptr [rbp-0xA0]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_OpCode():int:this]
       cmp      eax, 47
       sete     al
       movzx    rax, al
       mov      dword ptr [rbp-0xA4], eax
       xor      eax, eax
       mov      qword ptr [rbp-0xB0], rax
       xor      eax, eax
       mov      qword ptr [rbp-0xB8], rax
       cmp      dword ptr [rbp-0xA4], 0
       je       G_M000_IG29
       mov      rax, bword ptr [rbp+0x10]
       mov      rax, gword ptr [rax+0x08]
       mov      gword ptr [rbp-0x188], rax
       mov      rcx, bword ptr [rbp-0xA0]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      rcx, gword ptr [rbp-0x188]
       cmp      eax, dword ptr [rcx+0x08]
       jae      G_M000_IG57
       mov      edx, eax
       imul     rdx, rdx, 16
       lea      rcx, bword ptr [rcx+rdx+0x10]
       mov      bword ptr [rbp-0x1E8], rcx
       mov      rcx, bword ptr [rbp-0x1E8]
       lea      rdx, [rbp-0xB0]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryReadHistogramTotal(byref,byref):bool]
       test     eax, eax
       jne      SHORT G_M000_IG26
       mov      rcx, 0x7FFA02D26258
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG24:                ;; offset=0x060B
       xor      eax, eax
 
G_M000_IG25:                ;; offset=0x060D
       add      rsp, 704
       pop      rbp
       ret      
 
G_M000_IG26:                ;; offset=0x0616
       mov      rcx, 0x7FFA02D2625C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Constants():System.Object[]:this]
       mov      gword ptr [rbp-0x190], rax
       mov      rcx, bword ptr [rbp-0xA0]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_SecondInput():int:this]
       not      eax
       mov      rcx, gword ptr [rbp-0x190]
       cmp      eax, dword ptr [rcx+0x08]
       jae      G_M000_IG57
       mov      edx, eax
       lea      rcx, bword ptr [rcx+8*rdx+0x10]
       mov      rax, gword ptr [rcx]
       mov      gword ptr [rbp-0x1F0], rax
       mov      rdx, gword ptr [rbp-0x1F0]
       mov      rcx, 0x7FFA029EB3F0
       call     [CORINFO_HELP_UNBOX]
 
G_M000_IG27:                ;; offset=0x0682
       vmovdqu  xmm0, xmmword ptr [rax]
       vmovdqu  xmmword ptr [rbp-0x200], xmm0
 
G_M000_IG28:                ;; offset=0x068E
       lea      rcx, [rbp-0x200]
       call     [System.Numerics.BigInteger:op_Explicit(System.Numerics.BigInteger):long]
       mov      qword ptr [rbp-0xB8], rax
 
G_M000_IG29:                ;; offset=0x06A2
       vxorps   xmm0, xmm0, xmm0
       vmovdqu  xmmword ptr [rbp-0xC8], xmm0
       xor      rax, rax
       mov      gword ptr [rbp-0xD0], rax
       xor      eax, eax
       mov      dword ptr [rbp-0xD4], eax
       xor      eax, eax
       mov      dword ptr [rbp-0xD8], eax
       xor      eax, eax
       mov      dword ptr [rbp-0xDC], eax
 
G_M000_IG30:                ;; offset=0x06CF
       mov      eax, dword ptr [rbp-0x1AC]
       dec      eax
       mov      dword ptr [rbp-0x1AC], eax
       cmp      dword ptr [rbp-0x1AC], 0
       jg       SHORT G_M000_IG32
 
G_M000_IG31:                ;; offset=0x06E6
       lea      rcx, [rbp-0x1AC]
       mov      edx, 496
       call     CORINFO_HELP_PATCHPOINT
       jmp      rax
 
G_M000_IG32:                ;; offset=0x06F9
       lea      rdx, [rbp-0xF0]
       lea      r8, [rbp-0xF8]
       mov      rcx, gword ptr [rbp-0x48]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.Text.PyStringOps+CasedWhitespaceIteration:TryReadWord(byref,byref):bool:this]
       test     eax, eax
       je       G_M000_IG50
 
G_M000_IG33:                ;; offset=0x071B
       vmovdqu  xmm0, xmmword ptr [rbp-0xF0]
       vmovdqu  xmmword ptr [rbp-0xC8], xmm0
 
G_M000_IG34:                ;; offset=0x072B
       mov      rax, gword ptr [rbp-0xF8]
       mov      gword ptr [rbp-0xD0], rax
       cmp      dword ptr [rbp-0xD8], 0
       jne      SHORT G_M000_IG35
       mov      rcx, bword ptr [rbp-0x60]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x208], rax
       mov      rdx, gword ptr [rbp-0x208]
       mov      rcx, gword ptr [rbp+0x18]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CheckExecution(Lokad.Lython.LythonSourceSpan):this]
       mov      rax, bword ptr [rbp+0x10]
       mov      ecx, dword ptr [rbp-0x50]
       mov      dword ptr [rax+0x18], ecx
       mov      rcx, gword ptr [rbp-0x58]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_CallSpan():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x210], rax
       mov      rdx, gword ptr [rbp-0x210]
       mov      rcx, gword ptr [rbp+0x18]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:EnterInterpreterFrame(Lokad.Lython.LythonSourceSpan):this]
       mov      dword ptr [rbp-0xD8], 1
       jmp      SHORT G_M000_IG36
 
G_M000_IG35:                ;; offset=0x07A2
       mov      rcx, 0x7FFA02D26260
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x10]
       mov      ecx, dword ptr [rbp-0x50]
       mov      dword ptr [rax+0x18], ecx
 
G_M000_IG36:                ;; offset=0x07BB
       cmp      gword ptr [rbp-0xF8], 0
       je       SHORT G_M000_IG39
       mov      rax, gword ptr [rbp-0xF8]
       mov      gword ptr [rbp-0x158], rax
 
G_M000_IG37:                ;; offset=0x07D3
       vmovdqu  xmm0, xmmword ptr [rbp-0x88]
       vmovdqu  xmmword ptr [rbp-0x220], xmm0
 
G_M000_IG38:                ;; offset=0x07E3
       mov      rcx, gword ptr [rbp-0x58]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_CallSpan():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x228], rax
       mov      rax, gword ptr [rbp-0x228]
       mov      gword ptr [rsp+0x28], rax
       lea      r9, [rbp-0x220]
       mov      r8, gword ptr [rbp-0x78]
       mov      rdx, gword ptr [rbp-0x158]
       mov      rax, gword ptr [rbp+0x18]
       mov      gword ptr [rsp+0x20], rax
       mov      rcx, gword ptr [rbp-0x90]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.PyDict:TryAccumulateWithoutAdmission(Lokad.Lython.Runtime.Text.PyString,System.Object,System.Numerics.BigInteger,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):bool:this]
       mov      dword ptr [rbp-0x14C], eax
       jmp      G_M000_IG44
 
G_M000_IG39:                ;; offset=0x0837
       mov      rcx, 0x7FFA02D26264
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG40:                ;; offset=0x0846
       vmovdqu  xmm0, xmmword ptr [rbp-0xF0]
       vmovdqu  xmmword ptr [rbp-0x148], xmm0
 
G_M000_IG41:                ;; offset=0x0856
       vmovdqu  xmm0, xmmword ptr [rbp-0x148]
       vmovdqu  xmmword ptr [rbp-0x238], xmm0
 
G_M000_IG42:                ;; offset=0x0866
       vmovdqu  xmm0, xmmword ptr [rbp-0x88]
       vmovdqu  xmmword ptr [rbp-0x248], xmm0
 
G_M000_IG43:                ;; offset=0x0876
       mov      rcx, gword ptr [rbp-0x58]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_CallSpan():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x250], rax
       mov      rax, gword ptr [rbp-0x48]
       mov      gword ptr [rsp+0x30], rax
       lea      rax, [rbp-0xD0]
       mov      qword ptr [rsp+0x38], rax
       mov      rax, gword ptr [rbp-0x250]
       mov      gword ptr [rsp+0x28], rax
       lea      rdx, [rbp-0x238]
       lea      r9, [rbp-0x248]
       mov      r8, gword ptr [rbp-0x78]
       mov      rax, gword ptr [rbp+0x18]
       mov      gword ptr [rsp+0x20], rax
       mov      rcx, gword ptr [rbp-0x90]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.PyDict:TryAccumulateBorrowedWord(System.ReadOnlySpan`1[byte],System.Object,System.Numerics.BigInteger,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.Text.PyStringOps+CasedWhitespaceIteration,byref):bool:this]
       mov      dword ptr [rbp-0x14C], eax
 
G_M000_IG44:                ;; offset=0x08DA
       cmp      dword ptr [rbp-0x14C], 0
       jne      SHORT G_M000_IG45
       mov      eax, dword ptr [rbp-0x4C]
       add      eax, 2
       mov      rcx, bword ptr [rbp+0x10]
       mov      dword ptr [rcx+0x18], eax
       mov      dword ptr [rbp-0xFC], 1
       jmp      G_M000_IG52
 
G_M000_IG45:                ;; offset=0x08FF
       cmp      dword ptr [rbp-0xA4], 0
       je       G_M000_IG49
       mov      rax, qword ptr [rbp-0xB0]
       add      rax, qword ptr [rbp-0xB8]
       mov      qword ptr [rbp-0xB0], rax
       mov      dword ptr [rbp-0xD4], 1
       mov      rax, 0xFF80000000000000
       cmp      qword ptr [rbp-0xB0], rax
       jl       SHORT G_M000_IG47
       mov      rax, 0x80000000000000
       cmp      qword ptr [rbp-0xB0], rax
       jl       SHORT G_M000_IG48
 
G_M000_IG46:                ;; offset=0x0951
       mov      rcx, 0x7FFA02D26268
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG47:                ;; offset=0x0960
       mov      rcx, 0x7FFA02D2626C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      eax, dword ptr [rbp-0x94]
       add      eax, 2
       mov      rcx, bword ptr [rbp+0x10]
       mov      dword ptr [rcx+0x18], eax
       mov      dword ptr [rbp-0xFC], 1
       jmp      G_M000_IG53
 
G_M000_IG48:                ;; offset=0x098E
       mov      rcx, 0x7FFA02D26270
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG49:                ;; offset=0x099D
       mov      rcx, 0x7FFA02D26274
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x10]
       mov      ecx, dword ptr [rbp-0x4C]
       mov      dword ptr [rax+0x18], ecx
       mov      rcx, bword ptr [rbp+0x28]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x258], rax
       mov      rdx, gword ptr [rbp-0x258]
       mov      rcx, gword ptr [rbp+0x18]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CheckExecution(Lokad.Lython.LythonSourceSpan):this]
       jmp      G_M000_IG30
 
G_M000_IG50:                ;; offset=0x09DF
       mov      rcx, 0x7FFA02D26278
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0xDC], 1
       mov      rcx, bword ptr [rbp+0x28]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_TargetIndex():int:this]
       mov      rcx, bword ptr [rbp+0x10]
       mov      dword ptr [rcx+0x18], eax
       mov      dword ptr [rbp-0xFC], 1
 
G_M000_IG51:                ;; offset=0x0A13
       call     G_M000_IG77
       jmp      SHORT G_M000_IG54
 
G_M000_IG52:                ;; offset=0x0A1A
       call     G_M000_IG77
       jmp      SHORT G_M000_IG54
 
G_M000_IG53:                ;; offset=0x0A21
       call     G_M000_IG77
       nop      
 
G_M000_IG54:                ;; offset=0x0A27
       mov      rcx, 0x7FFA02D262A0
       call     CORINFO_HELP_COUNTPROFILE32
       mov      eax, dword ptr [rbp-0xFC]
       mov      dword ptr [rbp-0x1B0], eax
 
G_M000_IG55:                ;; offset=0x0A42
       movzx    rax, byte  ptr [rbp-0x1B0]
 
G_M000_IG56:                ;; offset=0x0A49
       add      rsp, 704
       pop      rbp
       ret      
 
G_M000_IG57:                ;; offset=0x0A52
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG58:                ;; offset=0x0A58
       sub      rsp, 72
 
G_M000_IG59:                ;; offset=0x0A5C
       cmp      dword ptr [rbp-0xD4], 0
       je       SHORT G_M000_IG60
       mov      rcx, 0x7FFA02D2628C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x10]
       mov      rax, gword ptr [rax+0x08]
       mov      gword ptr [rbp-0x180], rax
       mov      rcx, bword ptr [rbp-0xA0]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      rcx, gword ptr [rbp-0x180]
       cmp      eax, dword ptr [rcx+0x08]
       jae      G_M000_IG63
       mov      edx, eax
       imul     rdx, rdx, 16
       lea      rcx, bword ptr [rcx+rdx+0x10]
       mov      bword ptr [rbp-0x270], rcx
       mov      rcx, bword ptr [rbp-0x270]
       mov      rdx, qword ptr [rbp-0xB0]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:SetInteger(long):this]
 
G_M000_IG60:                ;; offset=0x0AC6
       cmp      dword ptr [rbp-0xDC], 0
       je       SHORT G_M000_IG61
       mov      rcx, 0x7FFA02D26290
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       add      rax, 32
       mov      bword ptr [rbp-0x178], rax
       mov      rcx, bword ptr [rbp+0x28]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x274], eax
       mov      edx, dword ptr [rbp-0x274]
       mov      rcx, bword ptr [rbp-0x178]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
 
G_M000_IG61:                ;; offset=0x0B16
       mov      rcx, 0x7FFA02D26294
       call     CORINFO_HELP_COUNTPROFILE32
       nop      
 
G_M000_IG62:                ;; offset=0x0B26
       add      rsp, 72
       ret      
 
G_M000_IG63:                ;; offset=0x0B2B
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG64:                ;; offset=0x0B31
       sub      rsp, 72
 
G_M000_IG65:                ;; offset=0x0B35
       cmp      gword ptr [rbp-0xD0], 0
       jne      SHORT G_M000_IG69
       lea      rcx, [rbp-0xC8]
       call     [System.ReadOnlySpan`1[byte]:get_IsEmpty():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG66
       jmp      SHORT G_M000_IG68
 
G_M000_IG66:                ;; offset=0x0B52
       mov      rcx, 0x7FFA02D26280
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG73
 
G_M000_IG67:                ;; offset=0x0B66
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG68:                ;; offset=0x0B6C
       mov      rcx, 0x7FFA02D26284
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG69:                ;; offset=0x0B7B
       mov      rax, bword ptr [rbp+0x10]
       mov      rax, gword ptr [rax+0x08]
       mov      gword ptr [rbp-0x160], rax
       mov      rcx, bword ptr [rbp-0x70]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ThirdInput():int:this]
       mov      rcx, gword ptr [rbp-0x160]
       cmp      eax, dword ptr [rcx+0x08]
       jae      SHORT G_M000_IG67
       mov      edx, eax
       imul     rdx, rdx, 16
       lea      rcx, bword ptr [rcx+rdx+0x10]
       mov      bword ptr [rbp-0x168], rcx
       mov      rax, gword ptr [rbp-0xD0]
       mov      gword ptr [rbp-0x170], rax
       cmp      gword ptr [rbp-0xD0], 0
       jne      SHORT G_M000_IG72
       mov      rcx, 0x7FFA02D26288
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG70:                ;; offset=0x0BD9
       vmovdqu  xmm0, xmmword ptr [rbp-0xC8]
       vmovdqu  xmmword ptr [rbp-0x268], xmm0
 
G_M000_IG71:                ;; offset=0x0BE9
       lea      rdx, [rbp-0x268]
       mov      rcx, gword ptr [rbp-0x48]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.Text.PyStringOps+CasedWhitespaceIteration:Materialize(System.ReadOnlySpan`1[byte]):Lokad.Lython.Runtime.Text.PyString:this]
       mov      gword ptr [rbp-0x170], rax
 
G_M000_IG72:                ;; offset=0x0C03
       mov      rcx, bword ptr [rbp-0x168]
       mov      rdx, gword ptr [rbp-0x170]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:set_Object(System.Object):this]
 
G_M000_IG73:                ;; offset=0x0C17
       nop      
 
G_M000_IG74:                ;; offset=0x0C18
       call     G_M000_IG58
       nop      
 
G_M000_IG75:                ;; offset=0x0C1E
       mov      rcx, 0x7FFA02D26298
       call     CORINFO_HELP_COUNTPROFILE32
       nop      
 
G_M000_IG76:                ;; offset=0x0C2E
       add      rsp, 72
       ret      
 
G_M000_IG77:                ;; offset=0x0C33
       sub      rsp, 72
 
G_M000_IG78:                ;; offset=0x0C37
       cmp      dword ptr [rbp-0xD8], 0
       je       SHORT G_M000_IG79
       mov      rcx, 0x7FFA02D2627C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, gword ptr [rbp+0x18]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:LeaveInterpreterFrame():this]
 
G_M000_IG79:                ;; offset=0x0C5B
       nop      
 
G_M000_IG80:                ;; offset=0x0C5C
       call     G_M000_IG64
       nop      
 
G_M000_IG81:                ;; offset=0x0C62
       mov      rcx, 0x7FFA02D2629C
       call     CORINFO_HELP_COUNTPROFILE32
       nop      
 
G_M000_IG82:                ;; offset=0x0C72
       add      rsp, 72
       ret      
 
; Total bytes of code 3191

; Assembly listing for method Lokad.Lython.Runtime.PyDict:TryAccumulateBorrowedWord(System.ReadOnlySpan`1[byte],System.Object,System.Numerics.BigInteger,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.Text.PyStringOps+CasedWhitespaceIteration,byref):bool:this (Tier1)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; Tier1 code
; optimized code
; optimized using Synthesized PGO
; rbp based frame
; fully interruptible
; with Synthesized PGO: fgCalledCount is 484409
; 48 inlinees with PGO data; 102 single block inlinees; 5 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       push     r15
       push     r14
       push     r13
       push     r12
       push     rdi
       push     rsi
       push     rbx
       sub      rsp, 360
       lea      rbp, [rsp+0x1A0]
       vxorps   xmm4, xmm4, xmm4
       vmovdqu  ymmword ptr [rbp-0xF0], ymm4
       vmovdqu  ymmword ptr [rbp-0xD0], ymm4
       vmovdqu  ymmword ptr [rbp-0xB0], ymm4
       vmovdqu  ymmword ptr [rbp-0x90], ymm4
       vmovdqa  xmmword ptr [rbp-0x70], xmm4
       xor      eax, eax
       mov      qword ptr [rbp-0x60], rax
       mov      gword ptr [rbp+0x20], r8
       mov      rbx, rcx
       mov      rsi, rdx
       mov      rdi, gword ptr [rbp+0x30]
 
G_M000_IG02:                ;; offset=0x0058
       mov      r15, gword ptr [r9]
       mov      gword ptr [rbp-0x120], r15
       mov      r13d, dword ptr [r9+0x08]
       mov      dword ptr [rbp-0xD4], r13d
       mov      rcx, gword ptr [rdi+0x98]
       mov      rdx, gword ptr [rcx+0x88]
       cmp      gword ptr [rdx+0x20], 0
       mov      r14, gword ptr [rbp+0x20]
       jne      G_M000_IG73
       mov      rdx, gword ptr [rcx+0x180]
       test     rdx, rdx
       jne      G_M000_IG72
 
G_M000_IG03:                ;; offset=0x009A
       mov      r12, gword ptr [rbx+0x28]
       mov      eax, dword ptr [rbx+0x4C]
       mov      dword ptr [rbp-0x40], eax
       mov      r8, bword ptr [rsi]
       mov      bword ptr [rbp-0x128], r8
       mov      r10d, dword ptr [rsi+0x08]
       mov      dword ptr [rbp-0xD8], r10d
       cmp      eax, 4
       jle      G_M000_IG11
 
G_M000_IG04:                ;; offset=0x00C2
       vxorps   ymm0, ymm0, ymm0
       vmovdqu  ymmword ptr [rbp-0x78], ymm0
       xor      r9d, r9d
       mov      dword ptr [rbp-0x7C], r9d
       cmp      r9d, r10d
       jge      G_M000_IG29
 
G_M000_IG05:                ;; offset=0x00DB
       mov      rcx, gword ptr [rdi+0x98]
       mov      rdx, gword ptr [rcx+0x88]
       cmp      gword ptr [rdx+0x20], 0
       jne      G_M000_IG96
       mov      rdx, gword ptr [rcx+0x180]
       test     rdx, rdx
       jne      G_M000_IG95
 
G_M000_IG06:                ;; offset=0x0104
       mov      r10d, dword ptr [rbp-0xD8]
       mov      r9d, dword ptr [rbp-0x7C]
       mov      r11d, r10d
       sub      r11d, r9d
       cmp      r11d, 0x1000
       jge      G_M000_IG25
 
G_M000_IG07:                ;; offset=0x0122
       mov      dword ptr [rbp-0x80], r11d
       mov      edx, r9d
       mov      ecx, r11d
       add      rdx, rcx
       mov      ecx, r10d
       cmp      rdx, rcx
       ja       G_M000_IG94
       mov      dword ptr [rbp-0x7C], r9d
       mov      ecx, r9d
       add      rcx, r8
       mov      bword ptr [rbp-0x130], rcx
       mov      rdx, rcx
       mov      r13d, r11d
       cmp      r13d, 16
       jge      G_M000_IG26
 
G_M000_IG08:                ;; offset=0x015C
       cmp      r13d, 4
       jge      G_M000_IG103
       mov      rcx, rdx
       mov      bword ptr [rbp-0x140], rcx
       xor      edx, edx
       cmp      edx, r13d
       jl       G_M000_IG104
 
G_M000_IG09:                ;; offset=0x017B
       mov      r9d, dword ptr [rbp-0x7C]
       add      r9d, dword ptr [rbp-0x80]
       mov      r10d, dword ptr [rbp-0xD8]
       cmp      r9d, r10d
       mov      dword ptr [rbp-0x7C], r9d
       jge      G_M000_IG29
 
G_M000_IG10:                ;; offset=0x0197
       mov      r8, bword ptr [rbp-0x128]
       jmp      G_M000_IG05
 
G_M000_IG11:                ;; offset=0x01A3
       cmp      r10d, 8
       jg       G_M000_IG04
 
G_M000_IG12:                ;; offset=0x01AD
       xor      r9d, r9d
       xor      ecx, ecx
       test     eax, eax
       jle      G_M000_IG132
       jmp      SHORT G_M000_IG14
 
G_M000_IG13:                ;; offset=0x01BC
       inc      ecx
       cmp      ecx, eax
       jge      G_M000_IG132
 
G_M000_IG14:                ;; offset=0x01C6
       mov      r11d, dword ptr [r12+0x08]
       cmp      ecx, r11d
       jae      G_M000_IG150
       lea      rdx, [rcx+4*rcx]
       mov      rdx, gword ptr [r12+8*rdx+0x10]
       test     rdx, rdx
       je       SHORT G_M000_IG13
 
G_M000_IG15:                ;; offset=0x01E2
       mov      r11, 0x7FFA02A61030
       cmp      qword ptr [rdx], r11
       jne      SHORT G_M000_IG13
 
G_M000_IG16:                ;; offset=0x01F1
       movzx    r11, byte  ptr [rdx+0x24]
       test     r11d, r11d
       je       G_M000_IG74
 
G_M000_IG17:                ;; offset=0x01FF
       cmp      r11d, 255
       je       G_M000_IG67
 
G_M000_IG18:                ;; offset=0x020C
       lea      r11, bword ptr [rdx+0x28]
       mov      edx, dword ptr [rdx+0x18]
       cmp      edx, 8
       ja       G_M000_IG94
 
G_M000_IG19:                ;; offset=0x021C
       cmp      r10d, edx
       jne      SHORT G_M000_IG13
 
G_M000_IG20:                ;; offset=0x0221
       mov      bword ptr [rbp-0x118], r8
       mov      r13, r11
       mov      edx, edx
       cmp      rdx, 8
       jae      G_M000_IG69
 
G_M000_IG21:                ;; offset=0x0237
       cmp      rdx, 4
       jb       G_M000_IG79
 
G_M000_IG22:                ;; offset=0x0241
       add      rdx, -4
       mov      r13d, dword ptr [r8]
       sub      r13d, dword ptr [r11]
       mov      r15d, dword ptr [r8+rdx]
       sub      r15d, dword ptr [r11+rdx]
       or       r15d, r13d
       sete     dl
       movzx    rdx, dl
 
G_M000_IG23:                ;; offset=0x025C
       test     edx, edx
       je       G_M000_IG13
 
G_M000_IG24:                ;; offset=0x0264
       mov      r11d, ecx
       mov      eax, r11d
       mov      r13d, r9d
       jmp      G_M000_IG50
 
G_M000_IG25:                ;; offset=0x0272
       mov      r11d, 0x1000
       jmp      G_M000_IG07
 
G_M000_IG26:                ;; offset=0x027D
       cmp      dword ptr [rbp-0x5C], 0
       jne      G_M000_IG97
       mov      rcx, 0x369A8847D4D201F8
       mov      qword ptr [rbp-0x78], rcx
       mov      rcx, 0x1277441FB0AEBDD0
       mov      qword ptr [rbp-0x70], rcx
 
G_M000_IG27:                ;; offset=0x02A3
       cmp      r13d, 16
       jl       G_M000_IG08
 
G_M000_IG28:                ;; offset=0x02AD
       mov      ecx, dword ptr [rbp-0x78]
       mov      dword ptr [rbp-0x84], ecx
       imul     ecx, dword ptr [rdx], 0xFFFFFFFF85EBCA77
       add      ecx, dword ptr [rbp-0x84]
       rol      ecx, 13
       imul     ecx, ecx, 0xFFFFFFFF9E3779B1
       mov      dword ptr [rbp-0x78], ecx
       mov      ecx, dword ptr [rbp-0x74]
       mov      dword ptr [rbp-0x88], ecx
       lea      rcx, bword ptr [rdx+0x04]
       imul     ecx, dword ptr [rcx], 0xFFFFFFFF85EBCA77
       add      ecx, dword ptr [rbp-0x88]
       rol      ecx, 13
       imul     ecx, ecx, 0xFFFFFFFF9E3779B1
       mov      dword ptr [rbp-0x74], ecx
       mov      ecx, dword ptr [rbp-0x70]
       mov      dword ptr [rbp-0x8C], ecx
       lea      rcx, bword ptr [rdx+0x08]
       imul     ecx, dword ptr [rcx], 0xFFFFFFFF85EBCA77
       add      ecx, dword ptr [rbp-0x8C]
       rol      ecx, 13
       imul     ecx, ecx, 0xFFFFFFFF9E3779B1
       mov      dword ptr [rbp-0x70], ecx
       mov      ecx, dword ptr [rbp-0x6C]
       mov      dword ptr [rbp-0x90], ecx
       lea      rcx, bword ptr [rdx+0x0C]
       imul     ecx, dword ptr [rcx], 0xFFFFFFFF85EBCA77
       add      ecx, dword ptr [rbp-0x90]
       rol      ecx, 13
       imul     ecx, ecx, 0xFFFFFFFF9E3779B1
       mov      dword ptr [rbp-0x6C], ecx
       mov      ecx, dword ptr [rbp-0x5C]
       add      ecx, 4
       mov      dword ptr [rbp-0x5C], ecx
       add      rdx, 16
       add      r13d, -16
       mov      rcx, rdx
       mov      rdx, rcx
       jmp      G_M000_IG27
 
G_M000_IG29:                ;; offset=0x0359
       mov      edx, dword ptr [rbp-0x5C]
       mov      ecx, edx
       and      ecx, 3
       cmp      edx, 4
       jb       G_M000_IG64
 
G_M000_IG30:                ;; offset=0x036A
       rorx     r9d, dword ptr [rbp-0x78], 31
       rorx     r11d, dword ptr [rbp-0x74], 25
       add      r9d, r11d
       rorx     r11d, dword ptr [rbp-0x70], 20
       add      r9d, r11d
       rorx     r11d, dword ptr [rbp-0x6C], 14
       add      r9d, r11d
 
G_M000_IG31:                ;; offset=0x038F
       lea      edx, [r9+4*rdx]
       test     ecx, ecx
       je       SHORT G_M000_IG33
 
G_M000_IG32:                ;; offset=0x0397
       imul     r9d, dword ptr [rbp-0x68], 0xFFFFFFFFC2B2AE3D
       add      edx, r9d
       rol      edx, 17
       imul     edx, edx, 0x27D4EB2F
       cmp      ecx, 1
       ja       G_M000_IG65
 
G_M000_IG33:                ;; offset=0x03B4
       mov      ecx, edx
       shr      ecx, 15
       xor      ecx, edx
       imul     edx, ecx, 0xFFFFFFFF85EBCA77
       mov      ecx, edx
       shr      ecx, 13
       xor      ecx, edx
       imul     edx, ecx, 0xFFFFFFFFC2B2AE3D
       mov      ecx, edx
       shr      ecx, 16
       xor      edx, ecx
       mov      ecx, -2
       cmp      edx, -1
       cmovne   ecx, edx
       mov      edx, ecx
       shr      edx, 16
       xor      edx, ecx
       imul     r9d, edx, 0xFFFFFFFF9E3779B9
       mov      edx, r9d
       shr      edx, 16
       xor      r9d, edx
       mov      r13d, r9d
       test     eax, eax
       je       G_M000_IG105
 
G_M000_IG34:                ;; offset=0x0402
       mov      r11d, dword ptr [r12+0x08]
       mov      r9d, r11d
       mov      ecx, r9d
       blsr     eax, ecx
       jne      G_M000_IG106
       dec      ecx
       and      ecx, r13d
 
G_M000_IG35:                ;; offset=0x041D
       mov      dword ptr [rbp-0xFC], r9d
       cmp      ecx, r9d
       jae      G_M000_IG150
       mov      ecx, ecx
       lea      rcx, [rcx+4*rcx]
       mov      eax, dword ptr [r12+8*rcx+0x30]
       dec      eax
       mov      r11d, eax
       mov      dword ptr [rbp-0x44], r11d
       test     r11d, r11d
       jl       G_M000_IG108
       jmp      SHORT G_M000_IG37
 
G_M000_IG36:                ;; offset=0x044C
       mov      rax, bword ptr [rbp-0x148]
       mov      r11d, dword ptr [rax+0x1C]
       dec      r11d
       mov      dword ptr [rbp-0x44], r11d
       js       G_M000_IG131
 
G_M000_IG37:                ;; offset=0x0464
       mov      rcx, gword ptr [rdi+0x98]
       mov      rdx, gword ptr [rcx+0x88]
       cmp      gword ptr [rdx+0x20], 0
       jne      G_M000_IG109
       mov      rdx, gword ptr [rcx+0x180]
       test     rdx, rdx
       jne      G_M000_IG107
 
G_M000_IG38:                ;; offset=0x048D
       mov      r11d, dword ptr [rbp-0x44]
       cmp      r11d, dword ptr [rbp-0xFC]
       jae      G_M000_IG150
       mov      dword ptr [rbp-0x44], r11d
       mov      edx, r11d
       lea      rdx, [rdx+4*rdx]
       lea      rax, bword ptr [r12+8*rdx+0x10]
       mov      bword ptr [rbp-0x148], rax
       cmp      dword ptr [rax+0x18], r13d
       jne      SHORT G_M000_IG36
 
G_M000_IG39:                ;; offset=0x04BB
       mov      rcx, gword ptr [r12+8*rdx+0x10]
       test     rcx, rcx
       je       SHORT G_M000_IG36
 
G_M000_IG40:                ;; offset=0x04C5
       mov      rdx, 0x7FFA02A61030
       cmp      qword ptr [rcx], rdx
       jne      G_M000_IG36
 
G_M000_IG41:                ;; offset=0x04D8
       mov      r10d, dword ptr [rbp-0xD8]
       mov      dword ptr [rbp-0xDC], r10d
       lea      rdx, [rbp-0xA0]
       call     [Lokad.Lython.Runtime.Text.PyString:get_Utf8Span():System.ReadOnlySpan`1[byte]:this]
       mov      eax, dword ptr [rbp-0x98]
       mov      dword ptr [rbp-0xE0], eax
       mov      ecx, dword ptr [rbp-0xDC]
       cmp      eax, ecx
       jne      G_M000_IG36
       xor      r8d, r8d
       mov      dword ptr [rbp-0xA4], r8d
       mov      r10d, dword ptr [rbp-0xD8]
       cmp      r8d, r10d
       jge      G_M000_IG49
 
G_M000_IG42:                ;; offset=0x0527
       mov      rcx, gword ptr [rdi+0x98]
       mov      rdx, gword ptr [rcx+0x88]
       cmp      gword ptr [rdx+0x20], 0
       jne      G_M000_IG111
       mov      rdx, gword ptr [rcx+0x180]
       test     rdx, rdx
       jne      G_M000_IG110
 
G_M000_IG43:                ;; offset=0x0550
       mov      r10d, dword ptr [rbp-0xD8]
       mov      r8d, dword ptr [rbp-0xA4]
       mov      ecx, r10d
       sub      ecx, r8d
       cmp      ecx, 0x1000
       jge      G_M000_IG60
 
G_M000_IG44:                ;; offset=0x0570
       mov      edx, r8d
       mov      r9d, ecx
       add      rdx, r9
       mov      r11d, r10d
       cmp      rdx, r11
       ja       G_M000_IG94
       mov      r11d, r8d
       mov      rax, bword ptr [rbp-0x128]
       add      r11, rax
       mov      r15d, dword ptr [rbp-0xE0]
       cmp      rdx, r15
       mov      gword ptr [rbp+0x20], r14
       ja       G_M000_IG94
       mov      edx, r8d
       add      rdx, bword ptr [rbp-0xA0]
       mov      r15, r11
       mov      r14, rdx
       cmp      r9, 8
       jae      G_M000_IG61
 
G_M000_IG45:                ;; offset=0x05C0
       cmp      r9, 4
       jb       G_M000_IG112
 
G_M000_IG46:                ;; offset=0x05CA
       add      r9, -4
       mov      r14d, dword ptr [r11]
       sub      r14d, dword ptr [rdx]
       mov      r11d, dword ptr [r11+r9]
       sub      r11d, dword ptr [rdx+r9]
       or       r11d, r14d
       sete     r9b
       movzx    r9, r9b
 
G_M000_IG47:                ;; offset=0x05E7
       test     r9d, r9d
       je       G_M000_IG117
 
G_M000_IG48:                ;; offset=0x05F0
       add      r8d, ecx
       cmp      r8d, r10d
       mov      dword ptr [rbp-0xA4], r8d
       mov      r14, gword ptr [rbp+0x20]
       jl       G_M000_IG42
 
G_M000_IG49:                ;; offset=0x0607
       mov      r11d, dword ptr [rbp-0x44]
       mov      eax, r11d
 
G_M000_IG50:                ;; offset=0x060E
       test     eax, eax
       jl       G_M000_IG133
 
G_M000_IG51:                ;; offset=0x0616
       mov      ecx, dword ptr [r12+0x08]
       mov      ecx, eax
       lea      rcx, [rcx+4*rcx]
       lea      rdx, bword ptr [r12+8*rcx+0x10]
       mov      dword ptr [rbp-0x3C], eax
       mov      edi, eax
       mov      r8, gword ptr [rdx]
       mov      rsi, r8
       test     rsi, rsi
       je       SHORT G_M000_IG53
 
G_M000_IG52:                ;; offset=0x0636
       mov      r10, 0x7FFA02A61030
       cmp      qword ptr [rsi], r10
       jne      G_M000_IG135
 
G_M000_IG53:                ;; offset=0x0649
       mov      r13d, dword ptr [rdx+0x18]
       cmp      gword ptr [rbx+0x20], 0
       jne      G_M000_IG136
       mov      rdx, gword ptr [rbx+0x30]
       cmp      edi, dword ptr [rdx+0x08]
       jae      G_M000_IG150
       mov      r8d, edi
       cmp      gword ptr [rdx+8*r8+0x10], 0
       jne      G_M000_IG136
 
G_M000_IG54:                ;; offset=0x0674
       mov      rdx, gword ptr [rbx+0x28]
       cmp      edi, dword ptr [rdx+0x08]
       jae      G_M000_IG150
       mov      rdx, qword ptr [rdx+8*rcx+0x20]
       mov      rcx, 0xFF80000000000000
       cmp      rdx, rcx
       jl       G_M000_IG137
       mov      rcx, 0x80000000000000
       cmp      rdx, rcx
       jge      G_M000_IG137
 
G_M000_IG55:                ;; offset=0x06AC
       mov      r15, gword ptr [rbp-0x120]
       test     r15, r15
       jne      G_M000_IG143
       movsxd   rcx, dword ptr [rbp-0xD4]
 
G_M000_IG56:                ;; offset=0x06C3
       add      rdx, rcx
       mov      r15d, dword ptr [rbx+0x4C]
       cmp      gword ptr [rbx+0x20], 0
       jne      G_M000_IG148
       mov      rcx, gword ptr [rbx+0x28]
       cmp      edi, dword ptr [rcx+0x08]
       jae      G_M000_IG150
       mov      eax, edi
       lea      rax, [rax+4*rax]
       mov      qword ptr [rcx+8*rax+0x20], rdx
       mov      rcx, gword ptr [rbx+0x30]
       cmp      edi, dword ptr [rcx+0x08]
       jae      G_M000_IG150
       mov      edx, edi
       xor      rax, rax
       mov      gword ptr [rcx+8*rdx+0x10], rax
 
G_M000_IG57:                ;; offset=0x0703
       cmp      dword ptr [rbx+0x4C], r15d
       jne      G_M000_IG149
 
G_M000_IG58:                ;; offset=0x070D
       mov      eax, 1
 
G_M000_IG59:                ;; offset=0x0712
       vzeroupper 
       add      rsp, 360
       pop      rbx
       pop      rsi
       pop      rdi
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG60:                ;; offset=0x0729
       mov      ecx, 0x1000
       jmp      G_M000_IG44
 
G_M000_IG61:                ;; offset=0x0733
       cmp      r15, r14
       je       G_M000_IG48
       cmp      r9, 32
       jae      G_M000_IG118
 
G_M000_IG62:                ;; offset=0x0746
       cmp      r9, 16
       jae      G_M000_IG125
 
G_M000_IG63:                ;; offset=0x0750
       add      r9, -8
       mov      r15, qword ptr [r11]
       sub      r15, qword ptr [rdx]
       mov      r11, qword ptr [r11+r9]
       sub      r11, qword ptr [rdx+r9]
       or       r11, r15
       sete     r9b
       movzx    r9, r9b
       jmp      G_M000_IG47
 
G_M000_IG64:                ;; offset=0x0772
       mov      r9d, 0xFFFFFFFFC7052581
       jmp      G_M000_IG31
 
G_M000_IG65:                ;; offset=0x077D
       imul     r9d, dword ptr [rbp-0x64], 0xFFFFFFFFC2B2AE3D
       add      r9d, edx
       rol      r9d, 17
       imul     edx, r9d, 0x27D4EB2F
       cmp      ecx, 2
       jbe      G_M000_IG33
 
G_M000_IG66:                ;; offset=0x079C
       imul     ecx, dword ptr [rbp-0x60], 0xFFFFFFFFC2B2AE3D
       add      ecx, edx
       rol      ecx, 17
       imul     edx, ecx, 0x27D4EB2F
       jmp      G_M000_IG33
 
G_M000_IG67:                ;; offset=0x07B3
       mov      r11, gword ptr [rdx+0x08]
       mov      gword ptr [rbp-0x110], r11
       lea      r11, bword ptr [rdx+0x28]
       mov      r11d, dword ptr [r11]
       mov      edx, dword ptr [rdx+0x18]
       mov      dword ptr [rbp-0x48], edx
       cmp      gword ptr [rbp-0x110], 0
       je       G_M000_IG78
       mov      qword ptr [rbp-0xF8], r11
       mov      r11d, edx
       add      r11, qword ptr [rbp-0xF8]
       mov      qword ptr [rbp-0x154], r11
       mov      r11, gword ptr [rbp-0x110]
       mov      r11d, dword ptr [r11+0x08]
       cmp      qword ptr [rbp-0x154], r11
       ja       G_M000_IG94
       mov      r11, gword ptr [rbp-0x110]
       mov      rdx, qword ptr [rbp-0xF8]
       lea      r11, bword ptr [r11+rdx+0x10]
       mov      edx, dword ptr [rbp-0x48]
 
G_M000_IG68:                ;; offset=0x081F
       jmp      G_M000_IG19
 
G_M000_IG69:                ;; offset=0x0824
       mov      r15, bword ptr [rbp-0x118]
       cmp      r15, r13
       je       G_M000_IG92
       cmp      rdx, 32
       jae      G_M000_IG84
 
G_M000_IG70:                ;; offset=0x083E
       cmp      rdx, 16
       jae      G_M000_IG88
 
G_M000_IG71:                ;; offset=0x0848
       add      rdx, -8
       mov      r13, qword ptr [r8]
       sub      r13, qword ptr [r11]
       mov      r15, qword ptr [r8+rdx]
       sub      r15, qword ptr [r11+rdx]
       or       r15, r13
       sete     dl
       movzx    rdx, dl
       jmp      G_M000_IG23
 
G_M000_IG72:                ;; offset=0x0868
       cmp      dword ptr [rdx+0x20], 0
       setne    dl
       movzx    rdx, dl
       test     edx, edx
       je       G_M000_IG03
 
G_M000_IG73:                ;; offset=0x087A
       mov      rdx, gword ptr [rbp+0x38]
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
       jmp      G_M000_IG03
 
G_M000_IG74:                ;; offset=0x0889
       mov      r11, gword ptr [rdx+0x08]
       mov      edx, dword ptr [rdx+0x18]
       test     r11, r11
       jne      SHORT G_M000_IG76
 
G_M000_IG75:                ;; offset=0x0895
       test     edx, edx
       jne      G_M000_IG94
       xor      r11, r11
       xor      edx, edx
       jmp      SHORT G_M000_IG77
 
G_M000_IG76:                ;; offset=0x08A4
       cmp      dword ptr [r11+0x08], edx
       jb       G_M000_IG94
       add      r11, 16
 
G_M000_IG77:                ;; offset=0x08B2
       jmp      G_M000_IG19
 
G_M000_IG78:                ;; offset=0x08B7
       or       r11d, edx
       jne      G_M000_IG94
       xor      r11, r11
       xor      edx, edx
       jmp      G_M000_IG68
 
G_M000_IG79:                ;; offset=0x08CA
       xor      r13d, r13d
       mov      dword ptr [rbp-0x4C], r13d
       mov      r13, rdx
       and      r13, 2
       mov      qword ptr [rbp-0x58], r13
       test     r13, r13
       je       SHORT G_M000_IG81
 
G_M000_IG80:                ;; offset=0x08E1
       movzx    r13, word  ptr [r8]
       mov      dword ptr [rbp-0x14C], r13d
       movzx    r13, word  ptr [r11]
       movzx    r15, dword ptr [rbp-0x14C]
       sub      r15d, r13d
       mov      r13d, r15d
       mov      dword ptr [rbp-0x4C], r13d
 
G_M000_IG81:                ;; offset=0x0902
       test     dl, 1
       je       SHORT G_M000_IG83
 
G_M000_IG82:                ;; offset=0x0907
       mov      r13, qword ptr [rbp-0x58]
       movzx    rdx, byte  ptr [r8+r13]
       movzx    r11, byte  ptr [r11+r13]
       sub      edx, r11d
       mov      r13d, edx
       or       r13d, dword ptr [rbp-0x4C]
       mov      dword ptr [rbp-0x4C], r13d
 
G_M000_IG83:                ;; offset=0x0923
       cmp      dword ptr [rbp-0x4C], 0
       sete     dl
       movzx    rdx, dl
       jmp      G_M000_IG23
 
G_M000_IG84:                ;; offset=0x0932
       xor      r11d, r11d
       add      rdx, -32
       je       SHORT G_M000_IG87
       vmovups  ymm0, ymmword ptr [r8]
       vpcmpeqb ymm0, ymm0, ymmword ptr [r13]
       vpmovmskb r15d, ymm0
       cmp      r15d, -1
       jne      G_M000_IG93
 
G_M000_IG85:                ;; offset=0x0954
       add      r11, 32
       cmp      rdx, r11
       jbe      SHORT G_M000_IG87
 
G_M000_IG86:                ;; offset=0x095D
       vmovups  ymm0, ymmword ptr [r8+r11]
       vpcmpeqb ymm0, ymm0, ymmword ptr [r11+r13]
       vpmovmskb r15d, ymm0
       cmp      r15d, -1
       jne      G_M000_IG93
       jmp      SHORT G_M000_IG85
 
G_M000_IG87:                ;; offset=0x0979
       vmovups  ymm0, ymmword ptr [r8+rdx]
       vpcmpeqb ymm0, ymm0, ymmword ptr [rdx+r13]
       vpmovmskb edx, ymm0
       cmp      edx, -1
       jne      SHORT G_M000_IG93
       jmp      SHORT G_M000_IG92
 
G_M000_IG88:                ;; offset=0x0990
       xor      r11d, r11d
       add      rdx, -16
       je       SHORT G_M000_IG91
       vmovups  xmm0, xmmword ptr [r8]
       vpcmpeqb xmm0, xmm0, xmmword ptr [r13]
       vpmovmskb r15d, xmm0
       cmp      r15d, 0xFFFF
       jne      SHORT G_M000_IG93
 
G_M000_IG89:                ;; offset=0x09B1
       add      r11, 16
       cmp      rdx, r11
       jbe      SHORT G_M000_IG91
 
G_M000_IG90:                ;; offset=0x09BA
       vmovups  xmm0, xmmword ptr [r8+r11]
       vpcmpeqb xmm0, xmm0, xmmword ptr [r11+r13]
       vpmovmskb r15d, xmm0
       cmp      r15d, 0xFFFF
       jne      SHORT G_M000_IG93
       jmp      SHORT G_M000_IG89
 
G_M000_IG91:                ;; offset=0x09D5
       vmovups  xmm0, xmmword ptr [r8+rdx]
       vpcmpeqb xmm0, xmm0, xmmword ptr [rdx+r13]
       vpmovmskb edx, xmm0
       cmp      edx, 0xFFFF
       jne      SHORT G_M000_IG93
 
G_M000_IG92:                ;; offset=0x09ED
       mov      edx, 1
       jmp      G_M000_IG23
 
G_M000_IG93:                ;; offset=0x09F7
       xor      edx, edx
       jmp      G_M000_IG23
 
G_M000_IG94:                ;; offset=0x09FE
       call     [System.ThrowHelper:ThrowArgumentOutOfRangeException()]
       int3     
 
G_M000_IG95:                ;; offset=0x0A05
       cmp      dword ptr [rdx+0x20], 0
       setne    dl
       movzx    rdx, dl
       test     edx, edx
       je       G_M000_IG06
 
G_M000_IG96:                ;; offset=0x0A17
       mov      rdx, gword ptr [rbp+0x38]
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
       mov      eax, dword ptr [rbp-0x40]
       mov      r8, bword ptr [rbp-0x128]
       jmp      G_M000_IG06
 
G_M000_IG97:                ;; offset=0x0A30
       mov      r15d, dword ptr [rbp-0x5C]
       and      r15d, 3
       dec      r15d
       cmp      r15d, 2
       ja       G_M000_IG27
       mov      gword ptr [rbp+0x20], r14
       mov      qword ptr [rbp-0x154], r15
       lea      r15, [reloc @RWD00]
       mov      r14, qword ptr [rbp-0x154]
       mov      r15d, dword ptr [r15+4*r14]
       lea      rcx, G_M000_IG02
       add      r15, rcx
       jmp      r15
 
G_M000_IG98:                ;; offset=0x0A6F
       mov      r15, rdx
       jmp      SHORT G_M000_IG102
 
G_M000_IG99:                ;; offset=0x0A74
       mov      r15, rdx
       jmp      SHORT G_M000_IG101
 
G_M000_IG100:                ;; offset=0x0A79
       mov      r14, bword ptr [rbp-0x130]
       mov      edx, dword ptr [r14]
       lea      rcx, [rbp-0x78]
       call     [System.HashCode:Add(int):this]
       add      r14, 4
       mov      rdx, r14
       mov      r14d, dword ptr [rbp-0x80]
       lea      r13d, [r14-0x04]
       mov      r15, rdx
 
G_M000_IG101:                ;; offset=0x0A9F
       mov      edx, dword ptr [r15]
       lea      rcx, [rbp-0x78]
       call     [System.HashCode:Add(int):this]
       add      r15, 4
       add      r13d, -4
 
G_M000_IG102:                ;; offset=0x0AB4
       mov      edx, dword ptr [r15]
       lea      rcx, [rbp-0x78]
       call     [System.HashCode:Add(int):this]
       add      r15, 4
       add      r13d, -4
       mov      rdx, r15
       mov      eax, dword ptr [rbp-0x40]
       mov      r14, gword ptr [rbp+0x20]
       jmp      G_M000_IG27
 
G_M000_IG103:                ;; offset=0x0AD8
       mov      bword ptr [rbp-0x138], rdx
       mov      edx, dword ptr [rdx]
       lea      rcx, [rbp-0x78]
       call     [System.HashCode:Add(int):this]
       mov      rdx, bword ptr [rbp-0x138]
       add      rdx, 4
       add      r13d, -4
       mov      eax, dword ptr [rbp-0x40]
       jmp      G_M000_IG08
 
G_M000_IG104:                ;; offset=0x0B02
       mov      qword ptr [rbp-0x108], rdx
       movzx    rdx, byte  ptr [rcx+rdx]
       lea      rcx, [rbp-0x78]
       call     [System.HashCode:Add(int):this]
       mov      rax, qword ptr [rbp-0x108]
       inc      eax
       cmp      eax, r13d
       mov      rdx, rax
       mov      rcx, bword ptr [rbp-0x140]
       jl       SHORT G_M000_IG104
       mov      eax, dword ptr [rbp-0x40]
       jmp      G_M000_IG09
 
G_M000_IG105:                ;; offset=0x0B37
       mov      r9d, r13d
       jmp      G_M000_IG132
 
G_M000_IG106:                ;; offset=0x0B3F
       mov      eax, r13d
       xor      edx, edx
       div      edx:eax, ecx
       mov      ecx, edx
       jmp      G_M000_IG35
 
G_M000_IG107:                ;; offset=0x0B4D
       cmp      dword ptr [rdx+0x20], 0
       setne    dl
       movzx    rdx, dl
       test     edx, edx
       je       G_M000_IG38
       jmp      SHORT G_M000_IG109
 
G_M000_IG108:                ;; offset=0x0B61
       mov      r9d, r13d
       jmp      G_M000_IG132
 
G_M000_IG109:                ;; offset=0x0B69
       mov      rdx, gword ptr [rbp+0x38]
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
       jmp      G_M000_IG38
 
G_M000_IG110:                ;; offset=0x0B78
       cmp      dword ptr [rdx+0x20], 0
       setne    dl
       movzx    rdx, dl
       test     edx, edx
       je       G_M000_IG43
 
G_M000_IG111:                ;; offset=0x0B8A
       mov      rdx, gword ptr [rbp+0x38]
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
       jmp      G_M000_IG43
 
G_M000_IG112:                ;; offset=0x0B99
       xor      r15d, r15d
       mov      r14, r9
       and      r14, 2
       mov      qword ptr [rbp-0xB0], r14
       test     r14, r14
       je       SHORT G_M000_IG114
 
G_M000_IG113:                ;; offset=0x0BAF
       movzx    r15, word  ptr [r11]
       mov      dword ptr [rbp-0x14C], r15d
       movzx    r15, word  ptr [rdx]
       movzx    r14, dword ptr [rbp-0x14C]
       sub      r14d, r15d
       mov      r15d, r14d
 
G_M000_IG114:                ;; offset=0x0BCC
       test     r9b, 1
       je       SHORT G_M000_IG116
 
G_M000_IG115:                ;; offset=0x0BD2
       mov      r14, qword ptr [rbp-0xB0]
       movzx    r9, byte  ptr [r11+r14]
       movzx    r11, byte  ptr [rdx+r14]
       sub      r9d, r11d
       or       r15d, r9d
 
G_M000_IG116:                ;; offset=0x0BE9
       test     r15d, r15d
       sete     r9b
       movzx    r9, r9b
       jmp      G_M000_IG47
 
G_M000_IG117:                ;; offset=0x0BF9
       mov      r14, gword ptr [rbp+0x20]
       jmp      G_M000_IG36
 
G_M000_IG118:                ;; offset=0x0C02
       xor      edx, edx
       add      r9, -32
       je       SHORT G_M000_IG123
       vmovups  ymm0, ymmword ptr [r15]
       vpcmpeqb ymm0, ymm0, ymmword ptr [r14]
       vpmovmskb r11d, ymm0
       cmp      r11d, -1
       je       SHORT G_M000_IG120
 
G_M000_IG119:                ;; offset=0x0C1E
       mov      r14, gword ptr [rbp+0x20]
       jmp      G_M000_IG36
 
G_M000_IG120:                ;; offset=0x0C27
       add      rdx, 32
       cmp      r9, rdx
       jbe      SHORT G_M000_IG123
 
G_M000_IG121:                ;; offset=0x0C30
       vmovups  ymm0, ymmword ptr [r15+rdx]
       vpcmpeqb ymm0, ymm0, ymmword ptr [r14+rdx]
       vpmovmskb r11d, ymm0
       cmp      r11d, -1
       je       SHORT G_M000_IG120
 
G_M000_IG122:                ;; offset=0x0C46
       mov      r14, gword ptr [rbp+0x20]
       jmp      G_M000_IG36
 
G_M000_IG123:                ;; offset=0x0C4F
       vmovups  ymm0, ymmword ptr [r15+r9]
       vpcmpeqb ymm0, ymm0, ymmword ptr [r14+r9]
       vpmovmskb edx, ymm0
       cmp      edx, -1
       je       G_M000_IG48
 
G_M000_IG124:                ;; offset=0x0C68
       mov      r14, gword ptr [rbp+0x20]
       jmp      G_M000_IG36
 
G_M000_IG125:                ;; offset=0x0C71
       xor      edx, edx
       add      r9, -16
       je       SHORT G_M000_IG129
       vmovups  xmm0, xmmword ptr [r15]
       vpcmpeqb xmm0, xmm0, xmmword ptr [r14]
       vpmovmskb r11d, xmm0
       cmp      r11d, 0xFFFF
       je       SHORT G_M000_IG127
 
G_M000_IG126:                ;; offset=0x0C90
       mov      r14, gword ptr [rbp+0x20]
       jmp      G_M000_IG36
 
G_M000_IG127:                ;; offset=0x0C99
       add      rdx, 16
       cmp      r9, rdx
       jbe      SHORT G_M000_IG129
 
G_M000_IG128:                ;; offset=0x0CA2
       vmovups  xmm0, xmmword ptr [r15+rdx]
       vpcmpeqb xmm0, xmm0, xmmword ptr [r14+rdx]
       vpmovmskb r11d, xmm0
       cmp      r11d, 0xFFFF
       je       SHORT G_M000_IG127
       mov      r14, gword ptr [rbp+0x20]
       jmp      G_M000_IG36
 
G_M000_IG129:                ;; offset=0x0CC4
       vmovups  xmm0, xmmword ptr [r15+r9]
       vpcmpeqb xmm0, xmm0, xmmword ptr [r14+r9]
       vpmovmskb edx, xmm0
       cmp      edx, 0xFFFF
       je       G_M000_IG48
 
G_M000_IG130:                ;; offset=0x0CE0
       mov      r14, gword ptr [rbp+0x20]
       jmp      G_M000_IG36
 
G_M000_IG131:                ;; offset=0x0CE9
       mov      r9d, r13d
 
G_M000_IG132:                ;; offset=0x0CEC
       mov      eax, -1
       mov      r13d, r9d
       jmp      G_M000_IG50
 
G_M000_IG133:                ;; offset=0x0CF9
       mov      r15, gword ptr [rbp-0x120]
       mov      gword ptr [rbp-0xF0], r15
       mov      r15d, dword ptr [rbp-0xD4]
       mov      dword ptr [rbp-0xE8], r15d
       mov      gword ptr [rsp+0x28], rdi
       mov      rdi, gword ptr [rbp+0x38]
       mov      gword ptr [rsp+0x30], rdi
       mov      rdi, gword ptr [rbp+0x40]
       mov      gword ptr [rsp+0x38], rdi
       mov      rdi, bword ptr [rbp+0x48]
       mov      bword ptr [rsp+0x40], rdi
       lea      rdx, [rbp-0xF0]
       mov      qword ptr [rsp+0x20], rdx
       mov      rdx, rsi
       mov      r8d, r13d
       mov      r9, r14
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.PyDict:TryAppendBorrowedWord(System.ReadOnlySpan`1[byte],uint,System.Object,System.Numerics.BigInteger,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.Text.PyStringOps+CasedWhitespaceIteration,byref):bool:this]
       nop      
 
G_M000_IG134:                ;; offset=0x0D54
       vzeroupper 
       add      rsp, 360
       pop      rbx
       pop      rsi
       pop      rdi
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG135:                ;; offset=0x0D6B
       mov      rdx, r8
       mov      rcx, r10
       call     CORINFO_HELP_CHKCASTCLASS
       int3     
 
G_M000_IG136:                ;; offset=0x0D77
       mov      rcx, rbx
       mov      edx, edi
       call     [Lokad.Lython.Runtime.PyDict:ReadNativeValue(int):System.Object:this]
       test     rax, rax
       jne      SHORT G_M000_IG138
 
G_M000_IG137:                ;; offset=0x0D87
       xor      eax, eax
       jmp      G_M000_IG59
 
G_M000_IG138:                ;; offset=0x0D8E
       mov      rcx, 0x7FFA029EB3F0
       cmp      qword ptr [rax], rcx
       jne      SHORT G_M000_IG137
 
G_M000_IG139:                ;; offset=0x0D9D
       vmovdqu  xmm0, xmmword ptr [rax+0x08]
       vmovdqu  xmmword ptr [rbp-0xC0], xmm0
 
G_M000_IG140:                ;; offset=0x0DAA
       lea      rcx, [rbp-0xC0]
       xor      edx, edx
       call     [System.Numerics.BigInteger:GetByteCount(bool):int:this]
       cmp      eax, 8
       jge      SHORT G_M000_IG137
 
G_M000_IG141:                ;; offset=0x0DBE
       vmovdqu  xmm0, xmmword ptr [rbp-0xC0]
       vmovdqu  xmmword ptr [rbp-0xF0], xmm0
 
G_M000_IG142:                ;; offset=0x0DCE
       lea      rcx, [rbp-0xF0]
       call     [System.Numerics.BigInteger:op_Explicit(System.Numerics.BigInteger):long]
       mov      rdx, rax
       jmp      G_M000_IG55
 
G_M000_IG143:                ;; offset=0x0DE3
       cmp      dword ptr [r15+0x08], 1
       jle      SHORT G_M000_IG144
       mov      rcx, 0x7FFA02C7EE18
       call     CORINFO_HELP_NEWSFAST
       mov      rbx, rax
       call     [System.SR:get_Overflow_Int64():System.String]
       mov      rdx, rax
       mov      rcx, rbx
       call     [System.OverflowException:.ctor(System.String):this]
       mov      rcx, rbx
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG144:                ;; offset=0x0E17
       cmp      dword ptr [r15+0x08], 0
       jbe      G_M000_IG150
       mov      rcx, qword ptr [r15+0x10]
       mov      r8, rcx
       neg      r8
       mov      r14d, dword ptr [rbp-0xD4]
       test     r14d, r14d
       cmovle   rcx, r8
       test     rcx, rcx
       jle      SHORT G_M000_IG145
       test     r14d, r14d
       jg       SHORT G_M000_IG146
 
G_M000_IG145:                ;; offset=0x0E44
       test     rcx, rcx
       jge      SHORT G_M000_IG147
       test     r14d, r14d
       jge      SHORT G_M000_IG147
 
G_M000_IG146:                ;; offset=0x0E4E
       jmp      G_M000_IG56
 
G_M000_IG147:                ;; offset=0x0E53
       mov      rcx, 0x7FFA02C7EE18
       call     CORINFO_HELP_NEWSFAST
       mov      rbx, rax
       call     [System.SR:get_Overflow_Int64():System.String]
       mov      rdx, rax
       mov      rcx, rbx
       call     [System.OverflowException:.ctor(System.String):this]
       mov      rcx, rbx
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG148:                ;; offset=0x0E80
       lea      rcx, [rbp-0xD0]
       call     [System.Numerics.BigInteger:.ctor(long):this]
       mov      rcx, 0x7FFA029EB3F0
       call     CORINFO_HELP_NEWSFAST
       mov      r14, rax
       lea      rcx, bword ptr [r14+0x08]
       mov      rdx, gword ptr [rbp-0xD0]
       call     CORINFO_HELP_ASSIGN_REF
       mov      r9d, dword ptr [rbp-0xC8]
       mov      dword ptr [r14+0x10], r9d
       mov      dword ptr [rsp+0x20], r13d
       xor      r9d, r9d
       mov      dword ptr [rsp+0x28], r9d
       mov      dword ptr [rsp+0x30], 1
       mov      r9, r14
       mov      rcx, rbx
       mov      edx, dword ptr [rbp-0x3C]
       mov      r8, rsi
       call     [Lokad.Lython.Runtime.PyDict:PublishNativeValue(int,System.Object,System.Object,uint,bool,bool):System.Object:this]
       jmp      G_M000_IG57
 
G_M000_IG149:                ;; offset=0x0EE6
       inc      dword ptr [rbx+0x48]
       jmp      G_M000_IG58
 
G_M000_IG150:                ;; offset=0x0EEE
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
RWD00  	dd	00000A21h ; case G_M000_IG100
       	dd	00000A1Ch ; case G_M000_IG99
       	dd	00000A17h ; case G_M000_IG98

; Total bytes of code 3828

; Assembly listing for method Lokad.Lython.Runtime.PyDict:FindNativeTextIndex(Lokad.Lython.Runtime.PyDict+NativeKey[],int,System.ReadOnlySpan`1[byte],Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,byref):int (Tier1)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; Tier1 code
; optimized code
; optimized using Synthesized PGO
; rsp based frame
; fully interruptible
; with Synthesized PGO: fgCalledCount is 638489
; 42 inlinees with PGO data; 94 single block inlinees; 5 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     r15
       push     r14
       push     r13
       push     r12
       push     rdi
       push     rsi
       push     rbp
       push     rbx
       sub      rsp, 152
       vxorps   xmm4, xmm4, xmm4
       vmovdqu  ymmword ptr [rsp+0x60], ymm4
       vmovdqa  xmmword ptr [rsp+0x80], xmm4
       mov      rbx, rcx
       mov      esi, edx
       mov      rdi, r9
       mov      rbp, bword ptr [rsp+0x108]
 
G_M000_IG02:                ;; offset=0x0036
       mov      r14, bword ptr [r8]
       mov      r15d, dword ptr [r8+0x08]
       cmp      esi, 4
       jle      G_M000_IG36
 
G_M000_IG03:                ;; offset=0x0046
       vxorps   ymm0, ymm0, ymm0
       vmovdqu  ymmword ptr [rsp+0x70], ymm0
       xor      r13d, r13d
       cmp      r13d, r15d
       jge      G_M000_IG10
 
G_M000_IG04:                ;; offset=0x005C
       test     rdi, rdi
       je       SHORT G_M000_IG06
 
G_M000_IG05:                ;; offset=0x0061
       mov      rcx, gword ptr [rdi+0x98]
       mov      rdx, gword ptr [rcx+0x88]
       cmp      gword ptr [rdx+0x20], 0
       jne      G_M000_IG85
       mov      rdx, gword ptr [rcx+0x180]
       test     rdx, rdx
       jne      G_M000_IG84
 
G_M000_IG06:                ;; offset=0x008A
       mov      r12d, r15d
       sub      r12d, r13d
       cmp      r12d, 0x1000
       jge      G_M000_IG51
 
G_M000_IG07:                ;; offset=0x009D
       mov      edx, r13d
       mov      ecx, r12d
       add      rdx, rcx
       mov      ecx, r15d
       cmp      rdx, rcx
       ja       G_M000_IG83
       mov      eax, r13d
       add      rax, r14
       mov      bword ptr [rsp+0x30], rax
       mov      r8, rax
       mov      r10d, r12d
       cmp      r12d, 16
       jge      G_M000_IG52
 
G_M000_IG08:                ;; offset=0x00CD
       mov      dword ptr [rsp+0x4C], r10d
       cmp      r10d, 4
       jge      G_M000_IG92
       mov      rax, r8
       mov      bword ptr [rsp+0x20], rax
       mov      r10d, dword ptr [rsp+0x4C]
       mov      r8d, r10d
       mov      dword ptr [rsp+0x48], r8d
       xor      r10d, r10d
       cmp      r10d, r8d
       jl       G_M000_IG93
 
G_M000_IG09:                ;; offset=0x00FD
       add      r13d, r12d
       cmp      r13d, r15d
       jl       G_M000_IG04
 
G_M000_IG10:                ;; offset=0x0109
       mov      eax, dword ptr [rsp+0x8C]
       mov      edx, eax
       and      edx, 3
       cmp      eax, 4
       jb       G_M000_IG55
 
G_M000_IG11:                ;; offset=0x011E
       rorx     ecx, dword ptr [rsp+0x70], 31
       rorx     r8d, dword ptr [rsp+0x74], 25
       add      ecx, r8d
       rorx     r8d, dword ptr [rsp+0x78], 20
       add      ecx, r8d
       rorx     r8d, dword ptr [rsp+0x7C], 14
       add      ecx, r8d
 
G_M000_IG12:                ;; offset=0x0147
       lea      eax, [rcx+4*rax]
       test     edx, edx
       je       SHORT G_M000_IG14
 
G_M000_IG13:                ;; offset=0x014E
       imul     ecx, dword ptr [rsp+0x80], 0xFFFFFFFFC2B2AE3D
       add      eax, ecx
       rol      eax, 17
       imul     eax, eax, 0x27D4EB2F
       cmp      edx, 1
       ja       G_M000_IG56
 
G_M000_IG14:                ;; offset=0x016D
       mov      edx, eax
       shr      edx, 15
       xor      edx, eax
       imul     eax, edx, 0xFFFFFFFF85EBCA77
       mov      edx, eax
       shr      edx, 13
       xor      edx, eax
       imul     eax, edx, 0xFFFFFFFFC2B2AE3D
       mov      edx, eax
       shr      edx, 16
       xor      eax, edx
       mov      edx, -2
       cmp      eax, -1
       cmovne   edx, eax
       mov      eax, edx
       shr      eax, 16
       xor      eax, edx
       imul     eax, eax, 0xFFFFFFFF9E3779B9
       mov      edx, eax
       shr      edx, 16
       xor      edx, eax
       mov      dword ptr [rbp], edx
       test     esi, esi
       je       G_M000_IG113
 
G_M000_IG15:                ;; offset=0x01B8
       mov      eax, dword ptr [rbp]
       mov      r13d, dword ptr [rbx+0x08]
       mov      ecx, r13d
       blsr     edx, ecx
       jne      G_M000_IG94
       dec      ecx
       and      ecx, eax
 
G_M000_IG16:                ;; offset=0x01D1
       cmp      ecx, r13d
       jae      G_M000_IG115
       mov      ecx, ecx
       lea      rcx, [rcx+4*rcx]
       mov      esi, dword ptr [rbx+8*rcx+0x30]
       dec      esi
       js       G_M000_IG113
       jmp      SHORT G_M000_IG18
 
G_M000_IG17:                ;; offset=0x01EE
       mov      esi, dword ptr [r12+0x1C]
       dec      esi
       js       G_M000_IG113
 
G_M000_IG18:                ;; offset=0x01FB
       mov      rcx, gword ptr [rdi+0x98]
       mov      rdx, gword ptr [rcx+0x88]
       cmp      gword ptr [rdx+0x20], 0
       jne      G_M000_IG97
       mov      rdx, gword ptr [rcx+0x180]
       test     rdx, rdx
       jne      G_M000_IG96
 
G_M000_IG19:                ;; offset=0x0224
       cmp      esi, r13d
       jae      G_M000_IG115
       mov      edx, esi
       lea      rdx, [rdx+4*rdx]
       lea      r12, bword ptr [rbx+8*rdx+0x10]
       mov      ecx, dword ptr [r12+0x18]
       cmp      ecx, dword ptr [rbp]
       jne      SHORT G_M000_IG17
 
G_M000_IG20:                ;; offset=0x0242
       mov      rcx, gword ptr [rbx+8*rdx+0x10]
       test     rcx, rcx
       je       SHORT G_M000_IG17
 
G_M000_IG21:                ;; offset=0x024C
       mov      rdx, 0x7FFA02A61030
       cmp      qword ptr [rcx], rdx
       jne      SHORT G_M000_IG17
 
G_M000_IG22:                ;; offset=0x025B
       mov      dword ptr [rsp+0x44], r15d
       lea      rdx, [rsp+0x60]
       call     [Lokad.Lython.Runtime.Text.PyString:get_Utf8Span():System.ReadOnlySpan`1[byte]:this]
       mov      eax, dword ptr [rsp+0x68]
       mov      dword ptr [rsp+0x40], eax
       mov      ecx, dword ptr [rsp+0x44]
       cmp      eax, ecx
       jne      G_M000_IG17
       xor      r8d, r8d
       mov      dword ptr [rsp+0x5C], r8d
       cmp      r8d, r15d
       jge      G_M000_IG30
 
G_M000_IG23:                ;; offset=0x0290
       mov      rcx, gword ptr [rdi+0x98]
       mov      rdx, gword ptr [rcx+0x88]
       cmp      gword ptr [rdx+0x20], 0
       jne      G_M000_IG99
       mov      rdx, gword ptr [rcx+0x180]
       test     rdx, rdx
       jne      G_M000_IG98
 
G_M000_IG24:                ;; offset=0x02B9
       mov      r8d, dword ptr [rsp+0x5C]
       mov      ecx, r15d
       sub      ecx, r8d
       cmp      ecx, 0x1000
       jge      G_M000_IG32
 
G_M000_IG25:                ;; offset=0x02D0
       mov      edx, r8d
       mov      r10d, ecx
       add      rdx, r10
       mov      r9d, r15d
       cmp      rdx, r9
       ja       G_M000_IG83
       mov      r9d, r8d
       add      r9, r14
       mov      r11d, dword ptr [rsp+0x40]
       cmp      rdx, r11
       ja       G_M000_IG83
       mov      edx, r8d
       add      rdx, bword ptr [rsp+0x60]
       mov      r11, r9
       mov      rax, rdx
       cmp      r10, 8
       jae      SHORT G_M000_IG33
 
G_M000_IG26:                ;; offset=0x030D
       cmp      r10, 4
       jb       G_M000_IG100
 
G_M000_IG27:                ;; offset=0x0317
       add      r10, -4
       mov      eax, dword ptr [r9]
       sub      eax, dword ptr [rdx]
       mov      r9d, dword ptr [r9+r10]
       sub      r9d, dword ptr [rdx+r10]
       or       eax, r9d
       sete     al
       movzx    rax, al
 
G_M000_IG28:                ;; offset=0x0331
       test     eax, eax
       je       G_M000_IG17
 
G_M000_IG29:                ;; offset=0x0339
       add      r8d, ecx
       cmp      r8d, r15d
       mov      dword ptr [rsp+0x5C], r8d
       jl       G_M000_IG23
 
G_M000_IG30:                ;; offset=0x034A
       mov      eax, esi
 
G_M000_IG31:                ;; offset=0x034C
       vzeroupper 
       add      rsp, 152
       pop      rbx
       pop      rbp
       pop      rsi
       pop      rdi
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       ret      
 
G_M000_IG32:                ;; offset=0x0363
       mov      ecx, 0x1000
       jmp      G_M000_IG25
 
G_M000_IG33:                ;; offset=0x036D
       cmp      r11, rax
       je       SHORT G_M000_IG29
       cmp      r10, 32
       jae      G_M000_IG105
 
G_M000_IG34:                ;; offset=0x037C
       cmp      r10, 16
       jae      G_M000_IG109
 
G_M000_IG35:                ;; offset=0x0386
       add      r10, -8
       mov      r11, qword ptr [r9]
       sub      r11, qword ptr [rdx]
       mov      rax, qword ptr [r9+r10]
       sub      rax, qword ptr [rdx+r10]
       or       rax, r11
       sete     al
       movzx    rax, al
       jmp      SHORT G_M000_IG28
 
G_M000_IG36:                ;; offset=0x03A3
       cmp      r15d, 8
       jg       G_M000_IG03
 
G_M000_IG37:                ;; offset=0x03AD
       xor      ecx, ecx
       mov      dword ptr [rbp], ecx
 
G_M000_IG38:                ;; offset=0x03B2
       test     esi, esi
       jle      G_M000_IG113
       jmp      SHORT G_M000_IG40
 
G_M000_IG39:                ;; offset=0x03BC
       inc      ecx
       cmp      ecx, esi
       jge      G_M000_IG113
 
G_M000_IG40:                ;; offset=0x03C6
       mov      r13d, dword ptr [rbx+0x08]
       cmp      ecx, r13d
       jae      G_M000_IG115
       lea      rdx, [rcx+4*rcx]
       mov      rdx, gword ptr [rbx+8*rdx+0x10]
       test     rdx, rdx
       je       SHORT G_M000_IG39
 
G_M000_IG41:                ;; offset=0x03E1
       mov      rax, 0x7FFA02A61030
       cmp      qword ptr [rdx], rax
       jne      SHORT G_M000_IG39
 
G_M000_IG42:                ;; offset=0x03F0
       movzx    rax, byte  ptr [rdx+0x24]
       test     eax, eax
       je       G_M000_IG63
 
G_M000_IG43:                ;; offset=0x03FC
       cmp      eax, 255
       je       G_M000_IG58
 
G_M000_IG44:                ;; offset=0x0407
       lea      rax, bword ptr [rdx+0x28]
       mov      r8d, dword ptr [rdx+0x18]
       cmp      r8d, 8
       ja       G_M000_IG83
 
G_M000_IG45:                ;; offset=0x0419
       cmp      r15d, r8d
       jne      SHORT G_M000_IG39
 
G_M000_IG46:                ;; offset=0x041E
       mov      rdx, r14
       mov      r10, rax
       mov      r8d, r8d
       cmp      r8, 8
       jae      G_M000_IG60
 
G_M000_IG47:                ;; offset=0x0431
       cmp      r8, 4
       jb       G_M000_IG68
 
G_M000_IG48:                ;; offset=0x043B
       add      r8, -4
       mov      edx, dword ptr [r14]
       sub      edx, dword ptr [rax]
       mov      r10d, dword ptr [r14+r8]
       sub      r10d, dword ptr [rax+r8]
       or       edx, r10d
       sete     dl
       movzx    rdx, dl
 
G_M000_IG49:                ;; offset=0x0455
       test     edx, edx
       je       G_M000_IG39
 
G_M000_IG50:                ;; offset=0x045D
       mov      eax, ecx
       jmp      G_M000_IG31
 
G_M000_IG51:                ;; offset=0x0464
       mov      r12d, 0x1000
       jmp      G_M000_IG07
 
G_M000_IG52:                ;; offset=0x046F
       cmp      dword ptr [rsp+0x8C], 0
       jne      G_M000_IG86
       mov      rax, 0x369A8847D4D201F8
       mov      qword ptr [rsp+0x70], rax
       mov      rdx, 0x1277441FB0AEBDD0
       mov      qword ptr [rsp+0x78], rdx
 
G_M000_IG53:                ;; offset=0x049B
       cmp      r10d, 16
       jl       G_M000_IG08
 
G_M000_IG54:                ;; offset=0x04A5
       mov      edx, dword ptr [rsp+0x70]
       imul     ecx, dword ptr [r8], 0xFFFFFFFF85EBCA77
       add      edx, ecx
       rol      edx, 13
       imul     edx, edx, 0xFFFFFFFF9E3779B1
       mov      dword ptr [rsp+0x70], edx
       mov      edx, dword ptr [rsp+0x74]
       lea      rcx, bword ptr [r8+0x04]
       imul     ecx, dword ptr [rcx], 0xFFFFFFFF85EBCA77
       add      edx, ecx
       rol      edx, 13
       imul     edx, edx, 0xFFFFFFFF9E3779B1
       mov      dword ptr [rsp+0x74], edx
       mov      edx, dword ptr [rsp+0x78]
       lea      rcx, bword ptr [r8+0x08]
       imul     ecx, dword ptr [rcx], 0xFFFFFFFF85EBCA77
       add      edx, ecx
       rol      edx, 13
       imul     edx, edx, 0xFFFFFFFF9E3779B1
       mov      dword ptr [rsp+0x78], edx
       mov      edx, dword ptr [rsp+0x7C]
       lea      rcx, bword ptr [r8+0x0C]
       imul     ecx, dword ptr [rcx], 0xFFFFFFFF85EBCA77
       add      edx, ecx
       rol      edx, 13
       imul     edx, edx, 0xFFFFFFFF9E3779B1
       mov      dword ptr [rsp+0x7C], edx
       mov      edx, dword ptr [rsp+0x8C]
       add      edx, 4
       mov      dword ptr [rsp+0x8C], edx
       add      r8, 16
       add      r10d, -16
       mov      rax, r8
       mov      r8d, r10d
       mov      r10d, r8d
       mov      r8, rax
       jmp      G_M000_IG53
 
G_M000_IG55:                ;; offset=0x0540
       mov      ecx, 0xFFFFFFFFC7052581
       jmp      G_M000_IG12
 
G_M000_IG56:                ;; offset=0x054A
       imul     ecx, dword ptr [rsp+0x84], 0xFFFFFFFFC2B2AE3D
       add      ecx, eax
       rol      ecx, 17
       imul     eax, ecx, 0x27D4EB2F
       cmp      edx, 2
       jbe      G_M000_IG14
 
G_M000_IG57:                ;; offset=0x0569
       imul     edx, dword ptr [rsp+0x88], 0xFFFFFFFFC2B2AE3D
       add      edx, eax
       rol      edx, 17
       imul     eax, edx, 0x27D4EB2F
       jmp      G_M000_IG14
 
G_M000_IG58:                ;; offset=0x0584
       mov      rax, gword ptr [rdx+0x08]
       lea      r8, bword ptr [rdx+0x28]
       mov      r8d, dword ptr [r8]
       mov      edx, dword ptr [rdx+0x18]
       test     rax, rax
       je       G_M000_IG67
       mov      r10d, edx
       add      r10, r8
       mov      r9d, dword ptr [rax+0x08]
       cmp      r10, r9
       ja       G_M000_IG83
       lea      rax, bword ptr [rax+r8+0x10]
       mov      r8d, edx
 
G_M000_IG59:                ;; offset=0x05B6
       jmp      G_M000_IG45
 
G_M000_IG60:                ;; offset=0x05BB
       cmp      rdx, r10
       je       G_M000_IG81
       cmp      r8, 32
       jae      G_M000_IG73
 
G_M000_IG61:                ;; offset=0x05CE
       cmp      r8, 16
       jae      G_M000_IG77
 
G_M000_IG62:                ;; offset=0x05D8
       add      r8, -8
       mov      r10, qword ptr [r14]
       sub      r10, qword ptr [rax]
       mov      rdx, qword ptr [r14+r8]
       sub      rdx, qword ptr [rax+r8]
       or       rdx, r10
       sete     dl
       movzx    rdx, dl
       jmp      G_M000_IG49
 
G_M000_IG63:                ;; offset=0x05F8
       mov      rax, gword ptr [rdx+0x08]
       mov      r8d, dword ptr [rdx+0x18]
       test     rax, rax
       jne      SHORT G_M000_IG65
 
G_M000_IG64:                ;; offset=0x0605
       test     r8d, r8d
       jne      G_M000_IG83
       xor      rax, rax
       xor      r8d, r8d
       jmp      SHORT G_M000_IG66
 
G_M000_IG65:                ;; offset=0x0615
       cmp      dword ptr [rax+0x08], r8d
       jb       G_M000_IG83
       add      rax, 16
 
G_M000_IG66:                ;; offset=0x0623
       jmp      G_M000_IG45
 
G_M000_IG67:                ;; offset=0x0628
       or       r8d, edx
       jne      G_M000_IG83
       xor      rax, rax
       xor      r8d, r8d
       jmp      G_M000_IG59
 
G_M000_IG68:                ;; offset=0x063B
       xor      edx, edx
       mov      r10, r8
       and      r10, 2
       je       SHORT G_M000_IG70
 
G_M000_IG69:                ;; offset=0x0646
       movzx    rdx, word  ptr [r14]
       movzx    r9, word  ptr [rax]
       sub      edx, r9d
 
G_M000_IG70:                ;; offset=0x0651
       test     r8b, 1
       je       SHORT G_M000_IG72
 
G_M000_IG71:                ;; offset=0x0657
       movzx    r8, byte  ptr [r14+r10]
       movzx    rax, byte  ptr [rax+r10]
       sub      r8d, eax
       or       edx, r8d
 
G_M000_IG72:                ;; offset=0x0667
       test     edx, edx
       sete     dl
       movzx    rdx, dl
       jmp      G_M000_IG49
 
G_M000_IG73:                ;; offset=0x0674
       xor      edx, edx
       lea      rax, [r8-0x20]
       test     rax, rax
       je       SHORT G_M000_IG76
       vmovups  ymm0, ymmword ptr [r14]
       vpcmpeqb ymm0, ymm0, ymmword ptr [r10]
       vpmovmskb r8d, ymm0
       cmp      r8d, -1
       jne      G_M000_IG82
 
G_M000_IG74:                ;; offset=0x0697
       add      rdx, 32
       cmp      rax, rdx
       jbe      SHORT G_M000_IG76
 
G_M000_IG75:                ;; offset=0x06A0
       vmovups  ymm0, ymmword ptr [r14+rdx]
       vpcmpeqb ymm0, ymm0, ymmword ptr [r10+rdx]
       vpmovmskb r8d, ymm0
       cmp      r8d, -1
       jne      SHORT G_M000_IG82
       jmp      SHORT G_M000_IG74
 
G_M000_IG76:                ;; offset=0x06B8
       vmovups  ymm0, ymmword ptr [r14+rax]
       vpcmpeqb ymm0, ymm0, ymmword ptr [r10+rax]
       vpmovmskb edx, ymm0
       cmp      edx, -1
       jne      SHORT G_M000_IG82
       jmp      SHORT G_M000_IG81
 
G_M000_IG77:                ;; offset=0x06CF
       xor      edx, edx
       add      r8, -16
       je       SHORT G_M000_IG80
       vmovups  xmm0, xmmword ptr [r14]
       vpcmpeqb xmm0, xmm0, xmmword ptr [r10]
       vpmovmskb eax, xmm0
       cmp      eax, 0xFFFF
       jne      SHORT G_M000_IG82
 
G_M000_IG78:                ;; offset=0x06EC
       add      rdx, 16
       cmp      r8, rdx
       jbe      SHORT G_M000_IG80
 
G_M000_IG79:                ;; offset=0x06F5
       vmovups  xmm0, xmmword ptr [r14+rdx]
       vpcmpeqb xmm0, xmm0, xmmword ptr [r10+rdx]
       vpmovmskb eax, xmm0
       cmp      eax, 0xFFFF
       jne      SHORT G_M000_IG82
       jmp      SHORT G_M000_IG78
 
G_M000_IG80:                ;; offset=0x070E
       vmovups  xmm0, xmmword ptr [r14+r8]
       vpcmpeqb xmm0, xmm0, xmmword ptr [r10+r8]
       vpmovmskb r10d, xmm0
       cmp      r10d, 0xFFFF
       jne      SHORT G_M000_IG82
 
G_M000_IG81:                ;; offset=0x0727
       mov      edx, 1
       jmp      G_M000_IG49
 
G_M000_IG82:                ;; offset=0x0731
       xor      edx, edx
       jmp      G_M000_IG49
 
G_M000_IG83:                ;; offset=0x0738
       call     [System.ThrowHelper:ThrowArgumentOutOfRangeException()]
       int3     
 
G_M000_IG84:                ;; offset=0x073F
       cmp      dword ptr [rdx+0x20], 0
       setne    dl
       movzx    rdx, dl
       test     edx, edx
       je       G_M000_IG06
 
G_M000_IG85:                ;; offset=0x0751
       mov      rdx, gword ptr [rsp+0x100]
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
       jmp      G_M000_IG06
 
G_M000_IG86:                ;; offset=0x0764
       mov      edx, dword ptr [rsp+0x8C]
       and      edx, 3
       dec      edx
       cmp      edx, 2
       ja       G_M000_IG53
       lea      rcx, [reloc @RWD00]
       mov      dword ptr [rsp+0x4C], r10d
       mov      ecx, dword ptr [rcx+4*rdx]
       lea      r9, G_M000_IG02
       add      rcx, r9
       jmp      rcx
 
G_M000_IG87:                ;; offset=0x0794
       mov      rax, r8
       jmp      SHORT G_M000_IG91
 
G_M000_IG88:                ;; offset=0x0799
       mov      rax, r8
       jmp      SHORT G_M000_IG90
 
G_M000_IG89:                ;; offset=0x079E
       mov      edx, dword ptr [rax]
       lea      rcx, [rsp+0x70]
       call     [System.HashCode:Add(int):this]
       mov      r8, bword ptr [rsp+0x30]
       add      r8, 4
       lea      r10d, [r12-0x04]
       mov      rax, r8
       mov      dword ptr [rsp+0x4C], r10d
 
G_M000_IG90:                ;; offset=0x07C1
       mov      bword ptr [rsp+0x28], rax
       mov      edx, dword ptr [rax]
       lea      rcx, [rsp+0x70]
       call     [System.HashCode:Add(int):this]
       mov      rax, bword ptr [rsp+0x28]
       add      rax, 4
       mov      r8d, dword ptr [rsp+0x4C]
       add      r8d, -4
       mov      dword ptr [rsp+0x4C], r8d
 
G_M000_IG91:                ;; offset=0x07EA
       mov      bword ptr [rsp+0x28], rax
       mov      edx, dword ptr [rax]
       lea      rcx, [rsp+0x70]
       call     [System.HashCode:Add(int):this]
       mov      rax, bword ptr [rsp+0x28]
       add      rax, 4
       mov      r8d, dword ptr [rsp+0x4C]
       add      r8d, -4
       mov      r10d, r8d
       mov      r8, rax
       jmp      G_M000_IG53
 
G_M000_IG92:                ;; offset=0x0819
       mov      bword ptr [rsp+0x28], r8
       mov      edx, dword ptr [r8]
       lea      rcx, [rsp+0x70]
       call     [System.HashCode:Add(int):this]
       mov      rdx, bword ptr [rsp+0x28]
       add      rdx, 4
       mov      ecx, dword ptr [rsp+0x4C]
       add      ecx, -4
       mov      r8, rdx
       mov      r10d, ecx
       jmp      G_M000_IG08
 
G_M000_IG93:                ;; offset=0x0847
       mov      qword ptr [rsp+0x38], r10
       movzx    rdx, byte  ptr [rax+r10]
       lea      rcx, [rsp+0x70]
       call     [System.HashCode:Add(int):this]
       mov      rax, qword ptr [rsp+0x38]
       inc      eax
       mov      edx, dword ptr [rsp+0x48]
       cmp      eax, edx
       mov      r10, rax
       jl       SHORT G_M000_IG95
       jmp      G_M000_IG09
 
G_M000_IG94:                ;; offset=0x0873
       xor      edx, edx
       div      edx:eax, ecx
       mov      ecx, edx
       jmp      G_M000_IG16
 
G_M000_IG95:                ;; offset=0x087E
       mov      rax, bword ptr [rsp+0x20]
       jmp      SHORT G_M000_IG93
 
G_M000_IG96:                ;; offset=0x0885
       cmp      dword ptr [rdx+0x20], 0
       setne    dl
       movzx    rdx, dl
       test     edx, edx
       je       G_M000_IG19
 
G_M000_IG97:                ;; offset=0x0897
       mov      rdx, gword ptr [rsp+0x100]
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
       jmp      G_M000_IG19
 
G_M000_IG98:                ;; offset=0x08AA
       cmp      dword ptr [rdx+0x20], 0
       setne    dl
       movzx    rdx, dl
       test     edx, edx
       je       G_M000_IG24
 
G_M000_IG99:                ;; offset=0x08BC
       mov      rdx, gword ptr [rsp+0x100]
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
       jmp      G_M000_IG24
 
G_M000_IG100:                ;; offset=0x08CF
       xor      eax, eax
       mov      r11, r10
       and      r11, 2
       mov      qword ptr [rsp+0x50], r11
       test     r11, r11
       je       SHORT G_M000_IG102
 
G_M000_IG101:                ;; offset=0x08E2
       movzx    rax, word  ptr [r9]
       mov      dword ptr [rsp+0x94], eax
       movzx    rax, word  ptr [rdx]
       movzx    r11, dword ptr [rsp+0x94]
       sub      r11d, eax
       mov      eax, r11d
 
G_M000_IG102:                ;; offset=0x08FF
       test     r10b, 1
       je       SHORT G_M000_IG104
 
G_M000_IG103:                ;; offset=0x0905
       mov      r11, qword ptr [rsp+0x50]
       movzx    r10, byte  ptr [r9+r11]
       movzx    r9, byte  ptr [rdx+r11]
       sub      r10d, r9d
       or       eax, r10d
 
G_M000_IG104:                ;; offset=0x091A
       test     eax, eax
       sete     al
       movzx    rax, al
       jmp      G_M000_IG28
 
G_M000_IG105:                ;; offset=0x0927
       xor      edx, edx
       add      r10, -32
       je       SHORT G_M000_IG108
       vmovups  ymm0, ymmword ptr [r11]
       vpcmpeqb ymm0, ymm0, ymmword ptr [rax]
       vpmovmskb r9d, ymm0
       cmp      r9d, -1
       jne      G_M000_IG17
 
G_M000_IG106:                ;; offset=0x0946
       add      rdx, 32
       cmp      r10, rdx
       jbe      SHORT G_M000_IG108
 
G_M000_IG107:                ;; offset=0x094F
       vmovups  ymm0, ymmword ptr [r11+rdx]
       vpcmpeqb ymm0, ymm0, ymmword ptr [rax+rdx]
       vpmovmskb r9d, ymm0
       cmp      r9d, -1
       jne      G_M000_IG17
       jmp      SHORT G_M000_IG106
 
G_M000_IG108:                ;; offset=0x096A
       vmovups  ymm0, ymmword ptr [r11+r10]
       vpcmpeqb ymm0, ymm0, ymmword ptr [rax+r10]
       vpmovmskb eax, ymm0
       cmp      eax, -1
       jne      G_M000_IG17
       jmp      G_M000_IG29
 
G_M000_IG109:                ;; offset=0x0988
       xor      edx, edx
       add      r10, -16
       je       SHORT G_M000_IG112
       vmovups  xmm0, xmmword ptr [r11]
       vpcmpeqb xmm0, xmm0, xmmword ptr [rax]
       vpmovmskb r9d, xmm0
       cmp      r9d, 0xFFFF
       jne      G_M000_IG17
 
G_M000_IG110:                ;; offset=0x09AA
       add      rdx, 16
       cmp      r10, rdx
       jbe      SHORT G_M000_IG112
 
G_M000_IG111:                ;; offset=0x09B3
       vmovups  xmm0, xmmword ptr [r11+rdx]
       vpcmpeqb xmm0, xmm0, xmmword ptr [rax+rdx]
       vpmovmskb r9d, xmm0
       cmp      r9d, 0xFFFF
       jne      G_M000_IG17
       jmp      SHORT G_M000_IG110
 
G_M000_IG112:                ;; offset=0x09D1
       vmovups  xmm0, xmmword ptr [r11+r10]
       vpcmpeqb xmm0, xmm0, xmmword ptr [rax+r10]
       vpmovmskb r11d, xmm0
       cmp      r11d, 0xFFFF
       jne      G_M000_IG17
       jmp      G_M000_IG29
 
G_M000_IG113:                ;; offset=0x09F3
       mov      eax, -1
 
G_M000_IG114:                ;; offset=0x09F8
       vzeroupper 
       add      rsp, 152
       pop      rbx
       pop      rbp
       pop      rsi
       pop      rdi
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       ret      
 
G_M000_IG115:                ;; offset=0x0A0F
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
RWD00  	dd	00000768h ; case G_M000_IG89
       	dd	00000763h ; case G_M000_IG88
       	dd	0000075Eh ; case G_M000_IG87

; Total bytes of code 2581

; Assembly listing for method Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteDictionaryLoop(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool (Tier1)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; Tier1 code
; optimized code
; optimized using Synthesized PGO
; rbp based frame
; fully interruptible
; with Synthesized PGO: fgCalledCount is 220064
; 79 inlinees with PGO data; 194 single block inlinees; 10 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       push     r15
       push     r14
       push     r13
       push     r12
       push     rdi
       push     rsi
       push     rbx
       sub      rsp, 888
       lea      rbp, [rsp+0x3B0]
       xor      eax, eax
       mov      qword ptr [rbp-0x1F8], rax
       vxorps   xmm4, xmm4, xmm4
       vmovdqa  xmmword ptr [rbp-0x1F0], xmm4
       vmovdqa  xmmword ptr [rbp-0x1E0], xmm4
       mov      rax, -384
 
G_M000_IG303:                ;; offset=0x0042
       vmovdqa  xmmword ptr [rbp+rax-0x50], xmm4
       vmovdqa  xmmword ptr [rbp+rax-0x40], xmm4
       vmovdqa  xmmword ptr [rbp+rax-0x30], xmm4
       add      rax, 48
       jne      SHORT G_M000_IG303
       mov      qword ptr [rbp-0x50], rax
       mov      bword ptr [rbp+0x10], rcx
       mov      gword ptr [rbp+0x18], rdx
       mov      bword ptr [rbp+0x28], r9
       mov      rbx, r8
 
G_M000_IG02:                ;; offset=0x006D
       mov      esi, dword ptr [rcx+0x60]
       mov      eax, dword ptr [r9+0x1C]
       cmp      eax, 51
       ja       SHORT G_M000_IG04
 
G_M000_IG03:                ;; offset=0x0079
       mov      rdx, 0x7FFFFFFFFF9FF
       bt       rdx, rax
       jae      G_M000_IG246
 
G_M000_IG04:                ;; offset=0x008D
       mov      eax, dword ptr [r9+0x14]
 
G_M000_IG05:                ;; offset=0x0091
       cmp      esi, eax
       jne      G_M000_IG19
       mov      rcx, bword ptr [rbp+0x10]
       cmp      gword ptr [rcx+0x40], 0
       jne      G_M000_IG19
       mov      rax, gword ptr [rcx]
       cmp      byte  ptr [rax+0xDD], 0
       jne      G_M000_IG21
 
G_M000_IG06:                ;; offset=0x00B8
       test     rbx, rbx
       je       G_M000_IG247
 
G_M000_IG07:                ;; offset=0x00C1
       cmp      byte  ptr [rbx+0xFF], 0
       jne      G_M000_IG21
       mov      rax, gword ptr [rbx+0x88]
 
G_M000_IG08:                ;; offset=0x00D5
       test     rax, rax
       sete     sil
       movzx    rsi, sil
 
G_M000_IG09:                ;; offset=0x00E0
       test     esi, esi
       je       G_M000_IG243
       mov      rax, gword ptr [rcx+0x20]
       mov      edx, dword ptr [r9+0x10]
       cmp      edx, dword ptr [rax+0x08]
       jae      G_M000_IG271
       shl      rdx, 4
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      rdx, gword ptr [rax]
       mov      r8, 0x26849C01D00
       cmp      rdx, gword ptr [r8]
       je       G_M000_IG248
 
G_M000_IG10:                ;; offset=0x0118
       mov      rdx, gword ptr [rax]
       mov      r8, 0x26849C01D08
       cmp      rdx, gword ptr [r8]
       je       G_M000_IG249
       cmp      qword ptr [rax+0x08], 0
       jne      G_M000_IG250
       mov      rdi, gword ptr [rax]
 
G_M000_IG11:                ;; offset=0x013C
       test     rdi, rdi
       je       G_M000_IG251
       mov      rax, 0x7FFA02D12798
       cmp      qword ptr [rdi], rax
       jne      G_M000_IG243
 
G_M000_IG12:                ;; offset=0x0158
       mov      gword ptr [rbp-0x248], rdi
       mov      rax, gword ptr [rbp-0x248]
       mov      rax, gword ptr [rax+0x08]
       mov      rdi, gword ptr [rbp+0x18]
       mov      rdx, gword ptr [rdi+0x98]
       cmp      rax, gword ptr [rdx+0x88]
       jne      G_M000_IG243
       mov      rcx, bword ptr [rbp+0x10]
       mov      esi, dword ptr [rcx+0x18]
       mov      dword ptr [rbp-0x3C], esi
       mov      r9, bword ptr [rbp+0x28]
       cmp      dword ptr [r9+0x1C], 68
       jne      G_M000_IG252
       mov      ebx, dword ptr [r9+0x0C]
       mov      rax, gword ptr [rcx]
       mov      rax, gword ptr [rax+0xA0]
       mov      rdx, gword ptr [rcx]
       mov      rdx, gword ptr [rdx+0x88]
       cmp      ebx, dword ptr [rdx+0x08]
       jae      G_M000_IG271
       mov      r8d, ebx
       shl      r8, 5
       lea      rdx, bword ptr [rdx+r8+0x10]
       cmp      dword ptr [rdx+0x1C], 42
       jne      G_M000_IG253
       mov      edx, dword ptr [rdx+0x08]
       mov      r8, 0x7FFA02AE8620
       cmp      qword ptr [rax], r8
       jne      G_M000_IG255
       cmp      dword ptr [rax+0x08], edx
       jbe      G_M000_IG254
       mov      r14, gword ptr [rax+8*rdx+0x10]
 
G_M000_IG13:                ;; offset=0x01F6
       mov      gword ptr [rbp-0x250], r14
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rcx]
       mov      rdx, gword ptr [rdx+0x88]
       mov      rax, rdx
       lea      r15d, [rsi+0x02]
       mov      dword ptr [rbp-0x204], r15d
       mov      r8d, dword ptr [rax+0x08]
       cmp      r15d, r8d
       jae      G_M000_IG271
       mov      r10d, r15d
       shl      r10, 5
       lea      r13, bword ptr [rax+r10+0x10]
       mov      bword ptr [rbp-0x258], r13
       mov      rax, rdx
       lea      r10d, [rbx+0x01]
       cmp      r10d, r8d
       jae      G_M000_IG271
       lea      r10d, [rbx+0x01]
       shl      r10, 5
       lea      r12, bword ptr [rax+r10+0x10]
       mov      rax, rdx
       lea      r10d, [rbx+0x02]
       cmp      r10d, r8d
       jae      G_M000_IG271
       lea      r10d, [rbx+0x02]
       shl      r10, 5
       lea      rax, bword ptr [rax+r10+0x10]
       mov      bword ptr [rbp-0x260], rax
       mov      rax, gword ptr [rcx]
       mov      rax, gword ptr [rax+0x30]
       mov      r10, rax
       lea      r11d, [rsi+0x04]
       cmp      r11d, r8d
       jae      G_M000_IG271
       mov      r8d, r11d
       shl      r8, 5
       lea      r8, bword ptr [rdx+r8+0x10]
       mov      edx, dword ptr [r8+0x1C]
       cmp      edx, 35
       jg       G_M000_IG257
       cmp      edx, 35
       ja       G_M000_IG256
       mov      r11, 0x7FFFFFFBD
       bt       r11, rdx
       jb       G_M000_IG256
 
G_M000_IG14:                ;; offset=0x02C7
       mov      edx, dword ptr [r8+0x08]
       cmp      edx, dword ptr [r10+0x08]
       jae      G_M000_IG271
       mov      r8, gword ptr [r10+8*rdx+0x10]
       mov      gword ptr [rbp-0x268], r8
       mov      edx, dword ptr [r12+0x0C]
       not      edx
       cmp      edx, dword ptr [rax+0x08]
       jae      G_M000_IG271
       mov      r12, gword ptr [rax+8*rdx+0x10]
       mov      rdx, 0x7FFA029EB3F0
       cmp      qword ptr [r12], rdx
       je       SHORT G_M000_IG16
 
G_M000_IG15:                ;; offset=0x0306
       mov      rdx, r12
       mov      rcx, 0x7FFA029EB3F0
       call     CORINFO_HELP_UNBOX
 
G_M000_IG16:                ;; offset=0x0318
       mov      rax, gword ptr [r12+0x08]
       mov      gword ptr [rbp-0x2E8], rax
       mov      r12d, dword ptr [r12+0x10]
       mov      dword ptr [rbp-0x194], r12d
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rcx+0x08]
       mov      r10, bword ptr [rbp-0x260]
       mov      r11d, dword ptr [r10+0x0C]
       cmp      r11d, dword ptr [rdx+0x08]
       jae      G_M000_IG271
       shl      r11, 4
       lea      rdx, bword ptr [rdx+r11+0x10]
       mov      r11, gword ptr [rdx]
       mov      r8, 0x26849C01D00
       cmp      r11, gword ptr [r8]
       je       G_M000_IG258
 
G_M000_IG17:                ;; offset=0x036C
       mov      r8, gword ptr [rdx]
       mov      r11, 0x26849C01D08
       cmp      r8, gword ptr [r11]
       je       G_M000_IG259
       cmp      qword ptr [rdx+0x08], 0
       jne      G_M000_IG260
       mov      r8, gword ptr [rdx]
 
G_M000_IG18:                ;; offset=0x0390
       test     r8, r8
       jne      SHORT G_M000_IG22
 
G_M000_IG19:                ;; offset=0x0395
       xor      eax, eax
 
G_M000_IG20:                ;; offset=0x0397
       vzeroupper 
       add      rsp, 888
       pop      rbx
       pop      rsi
       pop      rdi
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG21:                ;; offset=0x03AE
       xor      esi, esi
       jmp      G_M000_IG09
 
G_M000_IG22:                ;; offset=0x03B5
       mov      rdx, 0x7FFA02AEFD78
       cmp      qword ptr [r8], rdx
       jne      SHORT G_M000_IG19
 
G_M000_IG23:                ;; offset=0x03C4
       mov      gword ptr [rbp-0x270], r8
       cmp      gword ptr [r8+0x28], 0
       je       SHORT G_M000_IG19
       cmp      gword ptr [r8+0x30], 0
       je       SHORT G_M000_IG19
       cmp      gword ptr [r8+0x20], 0
       jne      SHORT G_M000_IG19
       cmp      dword ptr [r8+0x50], 0
       jne      SHORT G_M000_IG19
       mov      rdx, gword ptr [r8+0x10]
       mov      r11, gword ptr [rdi+0x98]
       cmp      rdx, gword ptr [r11+0x88]
       jne      SHORT G_M000_IG19
       lea      r11d, [rbx+0x03]
       mov      dword ptr [rbp-0x40], r11d
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rcx]
       mov      rdx, gword ptr [rdx+0x88]
       cmp      r11d, dword ptr [rdx+0x08]
       jae      G_M000_IG271
       mov      r10d, r11d
       shl      r10, 5
       lea      r10, bword ptr [rdx+r10+0x10]
       mov      bword ptr [rbp-0x278], r10
       mov      r10, bword ptr [rbp-0x278]
       cmp      dword ptr [r10+0x1C], 47
       sete     dl
       movzx    rdx, dl
       mov      dword ptr [rbp-0x44], edx
       xor      r10d, r10d
       mov      qword ptr [rbp-0x50], r10
 
G_M000_IG24:                ;; offset=0x044A
       test     edx, edx
       je       G_M000_IG31
 
G_M000_IG25:                ;; offset=0x0452
       mov      r10, gword ptr [rcx+0x08]
       mov      r11, bword ptr [rbp-0x278]
       mov      r11d, dword ptr [r11+0x10]
       cmp      r11d, dword ptr [r10+0x08]
       jae      G_M000_IG271
       shl      r11, 4
       lea      r10, bword ptr [r10+r11+0x10]
       mov      bword ptr [rbp-0x290], r10
       mov      r11, gword ptr [r10]
       mov      rax, 0x26849C01D00
       cmp      r11, gword ptr [rax]
       jne      G_M000_IG261
 
G_M000_IG26:                ;; offset=0x0491
       mov      r10, qword ptr [r10+0x08]
       mov      qword ptr [rbp-0x50], r10
 
G_M000_IG27:                ;; offset=0x0499
       mov      rax, 0xFF80000000000000
       cmp      qword ptr [rbp-0x50], rax
       jl       G_M000_IG19
       mov      rax, 0x80000000000000
       cmp      qword ptr [rbp-0x50], rax
       jge      G_M000_IG19
       mov      rcx, bword ptr [rbp+0x10]
       mov      rax, gword ptr [rcx]
       mov      rax, gword ptr [rax+0x30]
       mov      r11, bword ptr [rbp-0x278]
       mov      r10d, dword ptr [r11+0x0C]
       not      r10d
       cmp      r10d, dword ptr [rax+0x08]
       jae      G_M000_IG271
       mov      rax, gword ptr [rax+8*r10+0x10]
       mov      gword ptr [rbp-0x288], rax
       mov      r10, 0x7FFA029EB3F0
       cmp      qword ptr [rax], r10
       je       SHORT G_M000_IG29
 
G_M000_IG28:                ;; offset=0x04FF
       mov      rdx, rax
       mov      rcx, 0x7FFA029EB3F0
       call     CORINFO_HELP_UNBOX
       mov      rax, gword ptr [rbp-0x288]
 
G_M000_IG29:                ;; offset=0x0518
       mov      r10, gword ptr [rax+0x08]
       mov      eax, dword ptr [rax+0x10]
       test     r10, r10
       jne      G_M000_IG266
       movsxd   r10, eax
 
G_M000_IG30:                ;; offset=0x052B
       mov      qword ptr [rbp-0x58], r10
       mov      rcx, bword ptr [rbp+0x10]
       mov      r10, qword ptr [rbp-0x58]
 
G_M000_IG31:                ;; offset=0x0537
       xor      r11, r11
       mov      bword ptr [rbp-0x2F0], r11
 
G_M000_IG32:                ;; offset=0x0541
       mov      dword ptr [rbp-0x198], r11d
 
G_M000_IG33:                ;; offset=0x0548
       mov      gword ptr [rbp-0x60], r11
 
G_M000_IG34:                ;; offset=0x054C
       mov      dword ptr [rbp-0x64], r11d
 
G_M000_IG35:                ;; offset=0x0550
       mov      dword ptr [rbp-0x68], r11d
 
G_M000_IG36:                ;; offset=0x0554
       mov      dword ptr [rbp-0x6C], r11d
       mov      qword ptr [rbp-0x58], r10
 
G_M000_IG37:                ;; offset=0x055C
       xor      r11, r11
       xor      edx, edx
       xor      rax, rax
       mov      gword ptr [rbp-0x280], rax
       mov      r13, gword ptr [rbp-0x248]
       mov      r13d, dword ptr [r13+0x34]
       mov      r10, gword ptr [rbp-0x248]
       cmp      r13d, dword ptr [r10+0x30]
       je       G_M000_IG121
 
G_M000_IG38:                ;; offset=0x0586
       mov      r10, gword ptr [rbp-0x248]
       mov      r10, gword ptr [r10+0x10]
       test     r10, r10
       je       G_M000_IG136
 
G_M000_IG39:                ;; offset=0x059A
       lea      r13, bword ptr [r10+0x10]
       mov      r10d, dword ptr [r10+0x08]
       mov      bword ptr [rbp-0x308], r13
 
G_M000_IG40:                ;; offset=0x05A9
       mov      r13, gword ptr [rbp-0x248]
       add      r13, 52
       mov      r12d, dword ptr [r13]
       add      r12d, 4
       mov      r14d, dword ptr [r13]
       mov      dword ptr [rbp-0x1A0], r10d
       cmp      r14d, r10d
       ja       G_M000_IG235
       mov      r10d, r14d
       add      r10, bword ptr [rbp-0x308]
       mov      eax, dword ptr [rbp-0x1A0]
       sub      eax, r14d
       cmp      eax, 4
       jl       G_M000_IG236
       mov      eax, dword ptr [r10]
       lea      r10d, [r12+rax]
       mov      dword ptr [r13], r10d
       mov      r10d, dword ptr [r13]
       cmp      eax, 0x1000
       jg       G_M000_IG138
       mov      r11, gword ptr [rbp-0x248]
       mov      rdx, gword ptr [r11+0x10]
       test     rdx, rdx
       je       G_M000_IG137
       mov      r10d, r12d
       mov      r11d, eax
       add      r10, r11
       mov      r11d, dword ptr [rdx+0x08]
       cmp      r10, r11
       ja       G_M000_IG235
       mov      r10d, r12d
       lea      r11, bword ptr [rdx+r10+0x10]
       mov      edx, eax
 
G_M000_IG41:                ;; offset=0x063A
       mov      bword ptr [rbp-0x2F8], r11
       mov      dword ptr [rbp-0x19C], edx
 
G_M000_IG42:                ;; offset=0x0647
       mov      r14, bword ptr [rbp-0x2F8]
       mov      bword ptr [rbp-0x2F0], r14
       mov      r13d, dword ptr [rbp-0x19C]
       mov      dword ptr [rbp-0x198], r13d
       mov      r12, gword ptr [rbp-0x280]
       mov      gword ptr [rbp-0x60], r12
       cmp      dword ptr [rbp-0x68], 0
       je       G_M000_IG54
 
G_M000_IG43:                ;; offset=0x0678
       mov      dword ptr [rcx+0x18], ebx
 
G_M000_IG44:                ;; offset=0x067B
       test     r12, r12
       jne      G_M000_IG141
 
G_M000_IG45:                ;; offset=0x0684
       mov      bword ptr [rbp-0x300], r14
       mov      r12, gword ptr [rbp-0x250]
       mov      rax, gword ptr [r12+0x18]
       mov      gword ptr [rbp-0x298], rax
       mov      rdx, gword ptr [rdi+0x98]
       mov      r10, gword ptr [rdx+0x88]
       cmp      gword ptr [r10+0x20], 0
       jne      G_M000_IG143
       mov      r10, gword ptr [rdx+0x180]
       test     r10, r10
       jne      G_M000_IG142
 
G_M000_IG46:                ;; offset=0x06C7
       mov      r8, gword ptr [rbp-0x270]
       mov      r10, gword ptr [r8+0x28]
       mov      gword ptr [rbp-0x2A0], r10
       mov      r11d, dword ptr [r8+0x4C]
       mov      dword ptr [rbp-0x7C], r11d
       mov      bword ptr [rbp-0x310], r14
       mov      dword ptr [rbp-0x1A4], r13d
       cmp      r11d, 4
       jle      G_M000_IG56
 
G_M000_IG47:                ;; offset=0x06F9
       vxorps   ymm0, ymm0, ymm0
       vmovdqu  ymmword ptr [rbp-0xE8], ymm0
       vxorps   ymm0, ymm0, ymm0
       vmovdqu  ymmword ptr [rbp-0xE8], ymm0
       xor      r12d, r12d
 
G_M000_IG48:                ;; offset=0x0714
       cmp      r12d, r13d
       jge      G_M000_IG75
 
G_M000_IG49:                ;; offset=0x071D
       mov      rdx, gword ptr [rdi+0x98]
       mov      r15, gword ptr [rdx+0x88]
       cmp      gword ptr [r15+0x20], 0
       jne      G_M000_IG167
       mov      r15, gword ptr [rdx+0x180]
       test     r15, r15
       jne      G_M000_IG166
 
G_M000_IG50:                ;; offset=0x0746
       mov      r15d, r13d
       sub      r15d, r12d
       cmp      r15d, 0x1000
       jge      G_M000_IG71
 
G_M000_IG51:                ;; offset=0x0759
       mov      dword ptr [rbp-0xEC], r15d
       mov      edx, r12d
       mov      qword ptr [rbp-0x218], rdx
       mov      eax, r15d
       add      rax, rdx
       mov      edx, r13d
       cmp      rax, rdx
       ja       G_M000_IG235
       mov      rdx, qword ptr [rbp-0x218]
       lea      rax, bword ptr [r14+rdx]
       mov      bword ptr [rbp-0x320], rax
       mov      bword ptr [rbp-0x328], rax
       mov      eax, r15d
       cmp      eax, 16
       jge      G_M000_IG72
 
G_M000_IG52:                ;; offset=0x07A1
       mov      dword ptr [rbp-0x1AC], eax
       cmp      eax, 4
       jge      G_M000_IG174
       mov      rdx, bword ptr [rbp-0x328]
       mov      bword ptr [rbp-0x330], rdx
       mov      eax, dword ptr [rbp-0x1AC]
       mov      dword ptr [rbp-0x1B0], eax
       xor      edx, edx
       cmp      edx, eax
       jl       G_M000_IG175
 
G_M000_IG53:                ;; offset=0x07D4
       add      r12d, dword ptr [rbp-0xEC]
       mov      r14, bword ptr [rbp-0x300]
       jmp      G_M000_IG48
 
G_M000_IG54:                ;; offset=0x07E7
       mov      rax, bword ptr [rbp-0x258]
       mov      rdx, gword ptr [rax]
       mov      r10, gword ptr [rdi+0x98]
       mov      r11, gword ptr [r10+0x88]
       cmp      gword ptr [r11+0x20], 0
       jne      G_M000_IG140
       mov      r11, gword ptr [r10+0x180]
       test     r11, r11
       jne      G_M000_IG139
 
G_M000_IG55:                ;; offset=0x081A
       mov      dword ptr [rcx+0x18], ebx
       mov      r10, gword ptr [rbp-0x250]
       mov      rdx, gword ptr [r10+0x18]
       mov      rcx, gword ptr [rdi+0x98]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.ExecutionState:EnterInterpreterFrame(Lokad.Lython.LythonSourceSpan):this]
       mov      dword ptr [rbp-0x68], 1
       jmp      G_M000_IG44
 
G_M000_IG56:                ;; offset=0x0843
       cmp      r13d, 8
       jg       G_M000_IG47
 
G_M000_IG57:                ;; offset=0x084D
       xor      eax, eax
       xor      edx, edx
       test     r11d, r11d
       jle      G_M000_IG144
       jmp      SHORT G_M000_IG60
 
G_M000_IG58:                ;; offset=0x085C
       inc      edx
       cmp      edx, r11d
       jge      G_M000_IG212
 
G_M000_IG59:                ;; offset=0x0867
       mov      r10, gword ptr [rbp-0x2A0]
 
G_M000_IG60:                ;; offset=0x086E
       mov      r12d, dword ptr [r10+0x08]
       cmp      edx, r12d
       jae      G_M000_IG240
       lea      r12, [rdx+4*rdx]
       mov      r12, gword ptr [r10+8*r12+0x10]
       test     r12, r12
       je       SHORT G_M000_IG58
 
G_M000_IG61:                ;; offset=0x0889
       mov      r15, 0x7FFA02A61030
       cmp      qword ptr [r12], r15
       jne      SHORT G_M000_IG58
 
G_M000_IG62:                ;; offset=0x0899
       movzx    r15, byte  ptr [r12+0x24]
       test     r15d, r15d
       je       G_M000_IG145
 
G_M000_IG63:                ;; offset=0x08A8
       cmp      r15d, 255
       je       G_M000_IG131
 
G_M000_IG64:                ;; offset=0x08B5
       lea      r15, bword ptr [r12+0x28]
       mov      r12d, dword ptr [r12+0x18]
       cmp      r12d, 8
       ja       G_M000_IG235
 
G_M000_IG65:                ;; offset=0x08C9
       mov      dword ptr [rbp-0x1A8], r12d
       cmp      r13d, r12d
       jne      SHORT G_M000_IG58
 
G_M000_IG66:                ;; offset=0x08D5
       mov      bword ptr [rbp-0x2B0], r15
       mov      r12d, dword ptr [rbp-0x1A8]
       cmp      r12, 8
       jae      G_M000_IG133
 
G_M000_IG67:                ;; offset=0x08ED
       cmp      r12, 4
       jb       G_M000_IG150
 
G_M000_IG68:                ;; offset=0x08F7
       add      r12, -4
       mov      qword ptr [rbp-0xB8], r12
       mov      r12d, dword ptr [r14]
       sub      r12d, dword ptr [r15]
       mov      dword ptr [rbp-0x354], r12d
       mov      r12, qword ptr [rbp-0xB8]
       mov      r12d, dword ptr [r14+r12]
       mov      r14, qword ptr [rbp-0xB8]
       sub      r12d, dword ptr [r15+r14]
       or       r12d, dword ptr [rbp-0x354]
       sete     r14b
       movzx    r14, r14b
 
G_M000_IG69:                ;; offset=0x0934
       test     r14d, r14d
       mov      r14, bword ptr [rbp-0x300]
       je       G_M000_IG58
 
G_M000_IG70:                ;; offset=0x0944
       mov      r12d, edx
       mov      r15d, r12d
       mov      r12d, eax
       jmp      G_M000_IG109
 
G_M000_IG71:                ;; offset=0x0952
       mov      r15d, 0x1000
       jmp      G_M000_IG51
 
G_M000_IG72:                ;; offset=0x095D
       cmp      dword ptr [rbp-0xCC], 0
       jne      G_M000_IG168
       mov      rdx, 0x369A8847D4D201F8
       mov      qword ptr [rbp-0xE8], rdx
       mov      rdx, 0x1277441FB0AEBDD0
       mov      qword ptr [rbp-0xE0], rdx
 
G_M000_IG73:                ;; offset=0x098C
       cmp      eax, 16
       jl       G_M000_IG52
 
G_M000_IG74:                ;; offset=0x0995
       mov      edx, dword ptr [rbp-0xE8]
       mov      dword ptr [rbp-0xF0], edx
       mov      rdx, bword ptr [rbp-0x328]
       imul     edx, dword ptr [rdx], 0xFFFFFFFF85EBCA77
       add      edx, dword ptr [rbp-0xF0]
       rol      edx, 13
       imul     edx, edx, 0xFFFFFFFF9E3779B1
       mov      dword ptr [rbp-0xE8], edx
       mov      edx, dword ptr [rbp-0xE4]
       mov      dword ptr [rbp-0xF4], edx
       mov      rdx, bword ptr [rbp-0x328]
       add      rdx, 4
       imul     edx, dword ptr [rdx], 0xFFFFFFFF85EBCA77
       add      edx, dword ptr [rbp-0xF4]
       rol      edx, 13
       imul     edx, edx, 0xFFFFFFFF9E3779B1
       mov      dword ptr [rbp-0xE4], edx
       mov      edx, dword ptr [rbp-0xE0]
       mov      dword ptr [rbp-0xF8], edx
       mov      rdx, bword ptr [rbp-0x328]
       add      rdx, 8
       imul     edx, dword ptr [rdx], 0xFFFFFFFF85EBCA77
       add      edx, dword ptr [rbp-0xF8]
       rol      edx, 13
       imul     edx, edx, 0xFFFFFFFF9E3779B1
       mov      dword ptr [rbp-0xE0], edx
       mov      edx, dword ptr [rbp-0xDC]
       mov      dword ptr [rbp-0xFC], edx
       mov      rdx, bword ptr [rbp-0x328]
       add      rdx, 12
       imul     edx, dword ptr [rdx], 0xFFFFFFFF85EBCA77
       add      edx, dword ptr [rbp-0xFC]
       rol      edx, 13
       imul     edx, edx, 0xFFFFFFFF9E3779B1
       mov      dword ptr [rbp-0xDC], edx
       mov      edx, dword ptr [rbp-0xCC]
       add      edx, 4
       mov      dword ptr [rbp-0xCC], edx
       mov      rdx, bword ptr [rbp-0x328]
       add      rdx, 16
       add      eax, -16
       mov      bword ptr [rbp-0x328], rdx
       jmp      G_M000_IG73
 
G_M000_IG75:                ;; offset=0x0A82
       mov      r12d, dword ptr [rbp-0xCC]
       mov      edx, r12d
       and      edx, 3
       cmp      r12d, 4
       jb       G_M000_IG128
 
G_M000_IG76:                ;; offset=0x0A99
       rorx     eax, dword ptr [rbp-0xE8], 31
       mov      dword ptr [rbp-0x354], eax
       rorx     eax, dword ptr [rbp-0xE4], 25
       add      eax, dword ptr [rbp-0x354]
       mov      dword ptr [rbp-0x354], eax
       rorx     eax, dword ptr [rbp-0xE0], 20
       add      eax, dword ptr [rbp-0x354]
       mov      dword ptr [rbp-0x354], eax
       rorx     eax, dword ptr [rbp-0xDC], 14
       add      eax, dword ptr [rbp-0x354]
 
G_M000_IG77:                ;; offset=0x0AE5
       lea      eax, [rax+4*r12]
       test     edx, edx
       je       SHORT G_M000_IG79
 
G_M000_IG78:                ;; offset=0x0AED
       imul     r12d, dword ptr [rbp-0xD8], 0xFFFFFFFFC2B2AE3D
       add      eax, r12d
       rol      eax, 17
       imul     eax, eax, 0x27D4EB2F
       cmp      edx, 1
       ja       G_M000_IG129
 
G_M000_IG79:                ;; offset=0x0B0D
       mov      edx, eax
       shr      edx, 15
       xor      edx, eax
       imul     eax, edx, 0xFFFFFFFF85EBCA77
       mov      edx, eax
       shr      edx, 13
       xor      edx, eax
       imul     eax, edx, 0xFFFFFFFFC2B2AE3D
       mov      edx, eax
       shr      edx, 16
       xor      eax, edx
       cmp      eax, -1
       je       G_M000_IG176
 
G_M000_IG80:                ;; offset=0x0B37
       mov      edx, eax
       shr      edx, 16
       xor      edx, eax
       imul     eax, edx, 0xFFFFFFFF9E3779B9
       mov      edx, eax
       shr      edx, 16
       xor      eax, edx
       mov      r12d, eax
       test     r11d, r11d
       je       G_M000_IG177
 
G_M000_IG81:                ;; offset=0x0B57
       mov      eax, dword ptr [r10+0x08]
       mov      r11d, eax
       mov      edx, r11d
       lea      eax, [rdx-0x01]
       test     edx, eax
       jne      G_M000_IG178
       and      eax, r12d
 
G_M000_IG82:                ;; offset=0x0B6F
       mov      dword ptr [rbp-0x22C], r11d
       cmp      eax, r11d
       jae      G_M000_IG240
       mov      edx, eax
       lea      rdx, [rdx+4*rdx]
       mov      eax, dword ptr [r10+8*rdx+0x30]
       dec      eax
       mov      dword ptr [rbp-0x80], eax
       test     eax, eax
       jl       G_M000_IG181
       jmp      SHORT G_M000_IG85
 
G_M000_IG83:                ;; offset=0x0B99
       mov      r10, gword ptr [rbp-0x2A0]
 
G_M000_IG84:                ;; offset=0x0BA0
       mov      eax, dword ptr [r15+0x1C]
       dec      eax
       mov      r15d, eax
       test     r15d, r15d
       mov      dword ptr [rbp-0x80], r15d
       jl       G_M000_IG211
 
G_M000_IG85:                ;; offset=0x0BB6
       mov      rdx, gword ptr [rdi+0x98]
       mov      r15, gword ptr [rdx+0x88]
       cmp      gword ptr [r15+0x20], 0
       jne      G_M000_IG182
       mov      r15, gword ptr [rdx+0x180]
       test     r15, r15
       jne      G_M000_IG180
 
G_M000_IG86:                ;; offset=0x0BDF
       mov      eax, dword ptr [rbp-0x80]
       cmp      eax, dword ptr [rbp-0x22C]
       jae      G_M000_IG240
       mov      dword ptr [rbp-0x80], eax
       mov      edx, eax
       lea      rdx, [rdx+4*rdx]
       mov      r10, gword ptr [rbp-0x2A0]
       lea      r15, bword ptr [r10+8*rdx+0x10]
       cmp      dword ptr [r15+0x18], r12d
       jne      SHORT G_M000_IG84
 
G_M000_IG87:                ;; offset=0x0C09
       mov      rdx, gword ptr [r10+8*rdx+0x10]
       test     rdx, rdx
       je       SHORT G_M000_IG83
 
G_M000_IG88:                ;; offset=0x0C13
       mov      r14, 0x7FFA02A61030
       cmp      qword ptr [rdx], r14
       jne      G_M000_IG107
 
G_M000_IG89:                ;; offset=0x0C26
       mov      dword ptr [rbp-0x1B8], r13d
       movzx    r14, byte  ptr [rdx+0x24]
       test     r14d, r14d
       je       G_M000_IG183
 
G_M000_IG90:                ;; offset=0x0C3B
       cmp      r14d, 255
       je       G_M000_IG101
 
G_M000_IG91:                ;; offset=0x0C48
       lea      r14, bword ptr [rdx+0x28]
       mov      edx, dword ptr [rdx+0x18]
       cmp      edx, 8
       ja       G_M000_IG235
 
G_M000_IG92:                ;; offset=0x0C58
       mov      bword ptr [rbp-0x338], r14
       mov      dword ptr [rbp-0x1B4], edx
       mov      r14d, dword ptr [rbp-0x1B8]
       cmp      edx, r14d
       jne      G_M000_IG188
       xor      r14d, r14d
 
G_M000_IG93:                ;; offset=0x0C78
       cmp      r14d, dword ptr [rbp-0x1A4]
       jge      G_M000_IG108
 
G_M000_IG94:                ;; offset=0x0C85
       mov      rdx, gword ptr [rdi+0x98]
       mov      gword ptr [rbp-0x2C0], rdx
       mov      rdx, gword ptr [rdx+0x88]
       cmp      gword ptr [rdx+0x20], 0
       jne      G_M000_IG190
       mov      rdx, gword ptr [rbp-0x2C0]
       mov      rdx, gword ptr [rdx+0x180]
       test     rdx, rdx
       jne      G_M000_IG189
 
G_M000_IG95:                ;; offset=0x0CBC
       mov      edx, dword ptr [rbp-0x1A4]
       sub      edx, r14d
       cmp      edx, 0x1000
       jge      G_M000_IG103
 
G_M000_IG96:                ;; offset=0x0CD1
       mov      dword ptr [rbp-0x104], edx
       mov      dword ptr [rbp-0x100], r14d
       mov      edx, r14d
       mov      qword ptr [rbp-0x210], rdx
       mov      edx, dword ptr [rbp-0x104]
       mov      qword ptr [rbp-0x238], rdx
       add      rdx, qword ptr [rbp-0x210]
       mov      qword ptr [rbp-0x200], rdx
       mov      edx, dword ptr [rbp-0x1A4]
       cmp      qword ptr [rbp-0x200], rdx
       ja       G_M000_IG235
       mov      r14, qword ptr [rbp-0x210]
       mov      rdx, r14
       add      rdx, bword ptr [rbp-0x310]
       mov      bword ptr [rbp-0x340], rdx
       mov      r14d, dword ptr [rbp-0x1B4]
       cmp      qword ptr [rbp-0x200], r14
       ja       G_M000_IG235
       mov      rdx, qword ptr [rbp-0x210]
       add      rdx, bword ptr [rbp-0x338]
       mov      bword ptr [rbp-0x348], rdx
       mov      r14, bword ptr [rbp-0x340]
       mov      bword ptr [rbp-0x2C8], r14
       mov      bword ptr [rbp-0x2D0], rdx
       mov      r14, qword ptr [rbp-0x238]
       cmp      r14, 8
       jae      G_M000_IG104
 
G_M000_IG97:                ;; offset=0x0D7D
       cmp      r14, 4
       jb       G_M000_IG191
 
G_M000_IG98:                ;; offset=0x0D87
       add      r14, -4
       mov      qword ptr [rbp-0x138], r14
       mov      r14, bword ptr [rbp-0x340]
       mov      r14d, dword ptr [r14]
       sub      r14d, dword ptr [rdx]
       mov      dword ptr [rbp-0x354], r14d
       mov      r14, bword ptr [rbp-0x340]
       mov      rdx, qword ptr [rbp-0x138]
       mov      r14d, dword ptr [r14+rdx]
       mov      rsi, bword ptr [rbp-0x348]
       sub      r14d, dword ptr [rsi+rdx]
       or       r14d, dword ptr [rbp-0x354]
       sete     dl
       movzx    rdx, dl
 
G_M000_IG99:                ;; offset=0x0DD0
       test     edx, edx
       je       G_M000_IG196
 
G_M000_IG100:                ;; offset=0x0DD8
       mov      r14d, dword ptr [rbp-0x100]
       add      r14d, dword ptr [rbp-0x104]
       jmp      G_M000_IG93
 
G_M000_IG101:                ;; offset=0x0DEB
       mov      r14, gword ptr [rdx+0x08]
       mov      gword ptr [rbp-0x2B8], r14
       lea      r14, bword ptr [rdx+0x28]
       mov      r14d, dword ptr [r14]
       mov      edx, dword ptr [rdx+0x18]
       mov      dword ptr [rbp-0x108], edx
       cmp      gword ptr [rbp-0x2B8], 0
       je       G_M000_IG187
       mov      qword ptr [rbp-0x228], r14
       mov      r14d, edx
       add      r14, qword ptr [rbp-0x228]
       mov      qword ptr [rbp-0x35C], r14
       mov      r14, gword ptr [rbp-0x2B8]
       mov      r14d, dword ptr [r14+0x08]
       cmp      qword ptr [rbp-0x35C], r14
       ja       G_M000_IG235
       mov      r14, gword ptr [rbp-0x2B8]
       mov      rdx, qword ptr [rbp-0x228]
       lea      r14, bword ptr [r14+rdx+0x10]
       mov      edx, dword ptr [rbp-0x108]
 
G_M000_IG102:                ;; offset=0x0E5D
       jmp      G_M000_IG92
 
G_M000_IG103:                ;; offset=0x0E62
       mov      edx, 0x1000
       jmp      G_M000_IG96
 
G_M000_IG104:                ;; offset=0x0E6C
       mov      rdx, bword ptr [rbp-0x2C8]
       cmp      rdx, bword ptr [rbp-0x2D0]
       je       G_M000_IG100
       cmp      r14, 32
       jae      G_M000_IG197
 
G_M000_IG105:                ;; offset=0x0E8A
       cmp      r14, 16
       jae      G_M000_IG205
 
G_M000_IG106:                ;; offset=0x0E94
       lea      rdx, [r14-0x08]
       mov      qword ptr [rbp-0x110], rdx
       mov      r14, bword ptr [rbp-0x340]
       mov      rdx, qword ptr [r14]
       mov      r14, bword ptr [rbp-0x348]
       sub      rdx, qword ptr [r14]
       mov      qword ptr [rbp-0x35C], rdx
       mov      rdx, bword ptr [rbp-0x340]
       mov      r14, qword ptr [rbp-0x110]
       mov      rdx, qword ptr [rdx+r14]
       mov      rsi, bword ptr [rbp-0x348]
       sub      rdx, qword ptr [rsi+r14]
       or       rdx, qword ptr [rbp-0x35C]
       sete     dl
       movzx    rdx, dl
       jmp      G_M000_IG99
 
G_M000_IG107:                ;; offset=0x0EE9
       mov      r10, gword ptr [rbp-0x2A0]
       mov      r14, bword ptr [rbp-0x300]
       jmp      G_M000_IG84
 
G_M000_IG108:                ;; offset=0x0EFC
       mov      eax, dword ptr [rbp-0x80]
       mov      r15d, eax
 
G_M000_IG109:                ;; offset=0x0F02
       test     r15d, r15d
       jl       G_M000_IG213
 
G_M000_IG110:                ;; offset=0x0F0B
       mov      r10, gword ptr [rbp-0x2A0]
       mov      edx, dword ptr [r10+0x08]
       mov      edx, r15d
       lea      rdx, [rdx+4*rdx]
       lea      rax, bword ptr [r10+8*rdx+0x10]
       mov      r14d, r15d
       mov      r10, gword ptr [rax]
       mov      r13, r10
       test     r13, r13
       je       SHORT G_M000_IG112
 
G_M000_IG111:                ;; offset=0x0F30
       mov      r11, 0x7FFA02A61030
       cmp      qword ptr [r13], r11
       jne      G_M000_IG214
 
G_M000_IG112:                ;; offset=0x0F44
       mov      r12d, dword ptr [rax+0x18]
       vxorps   xmm0, xmm0, xmm0
       vmovdqu  xmmword ptr [rbp-0x158], xmm0
       mov      r8, gword ptr [rbp-0x270]
       cmp      gword ptr [r8+0x20], 0
       jne      G_M000_IG215
       mov      rax, gword ptr [r8+0x30]
       cmp      r14d, dword ptr [rax+0x08]
       jae      G_M000_IG240
       mov      r10d, r14d
       cmp      gword ptr [rax+8*r10+0x10], 0
       jne      G_M000_IG215
 
G_M000_IG113:                ;; offset=0x0F83
       mov      rax, gword ptr [r8+0x28]
       cmp      r14d, dword ptr [rax+0x08]
       jae      G_M000_IG240
       mov      rax, qword ptr [rax+8*rdx+0x20]
       mov      rdx, rax
       mov      rax, 0xFF80000000000000
       cmp      rdx, rax
       jl       G_M000_IG217
       mov      rax, 0x80000000000000
       cmp      rdx, rax
       mov      qword ptr [rbp-0x160], rdx
       jge      G_M000_IG217
 
G_M000_IG114:                ;; offset=0x0FC6
       mov      rax, gword ptr [rbp-0x2E8]
       mov      gword ptr [rbp-0x1E8], rax
       mov      r10d, dword ptr [rbp-0x194]
       mov      dword ptr [rbp-0x1E0], r10d
       lea      rcx, [rbp-0x1E8]
       call     [System.Numerics.BigInteger:op_Explicit(System.Numerics.BigInteger):long]
       mov      rdx, rax
       add      rdx, qword ptr [rbp-0x160]
       mov      rax, gword ptr [rbp-0x270]
       mov      r8d, dword ptr [rax+0x4C]
       mov      dword ptr [rbp-0x164], r8d
       cmp      gword ptr [rax+0x20], 0
       jne      G_M000_IG230
       mov      rcx, gword ptr [rax+0x28]
       cmp      r14d, dword ptr [rcx+0x08]
       jae      G_M000_IG240
       mov      r10d, r14d
       lea      r10, [r10+4*r10]
       mov      qword ptr [rcx+8*r10+0x20], rdx
       mov      rcx, gword ptr [rax+0x30]
       cmp      r14d, dword ptr [rcx+0x08]
       jae      G_M000_IG240
       mov      edx, r14d
       xor      r10, r10
       mov      gword ptr [rcx+8*rdx+0x10], r10
 
G_M000_IG115:                ;; offset=0x1049
       mov      rax, gword ptr [rbp-0x270]
       mov      r8d, dword ptr [rbp-0x164]
       cmp      dword ptr [rax+0x4C], r8d
       jne      G_M000_IG231
 
G_M000_IG116:                ;; offset=0x1061
       mov      r14d, 1
 
G_M000_IG117:                ;; offset=0x1067
       test     r14d, r14d
       je       G_M000_IG237
 
G_M000_IG118:                ;; offset=0x1070
       mov      r14d, dword ptr [rbp-0x44]
       test     r14d, r14d
       je       SHORT G_M000_IG120
 
G_M000_IG119:                ;; offset=0x1079
       mov      r13, qword ptr [rbp-0x58]
       mov      rdx, r13
       add      rdx, qword ptr [rbp-0x50]
       mov      qword ptr [rbp-0x50], rdx
       mov      dword ptr [rbp-0x64], 1
       mov      rdx, 0xFF80000000000000
       cmp      qword ptr [rbp-0x50], rdx
       jl       G_M000_IG238
       mov      rdx, 0x80000000000000
       cmp      qword ptr [rbp-0x50], rdx
       jge      G_M000_IG238
 
G_M000_IG120:                ;; offset=0x10B7
       mov      rcx, bword ptr [rbp+0x10]
       mov      esi, dword ptr [rbp-0x3C]
       mov      dword ptr [rcx+0x18], esi
       mov      r9, bword ptr [rbp+0x28]
       mov      rdx, gword ptr [r9]
       mov      r8, gword ptr [rdi+0x98]
       mov      r10, gword ptr [r8+0x88]
       cmp      gword ptr [r10+0x20], 0
       jne      G_M000_IG234
       mov      r10, gword ptr [r8+0x180]
       test     r10, r10
       mov      gword ptr [rbp-0x350], r10
       mov      gword ptr [rbp-0x2E0], rdx
       mov      rcx, bword ptr [rbp+0x10]
       je       G_M000_IG37
       jmp      G_M000_IG232
 
G_M000_IG121:                ;; offset=0x1108
       mov      dword ptr [rbp-0x6C], 1
       mov      r9, bword ptr [rbp+0x28]
       mov      edx, dword ptr [r9+0x1C]
       cmp      edx, 51
       jg       SHORT G_M000_IG124
 
G_M000_IG122:                ;; offset=0x111C
       cmp      edx, 41
       je       SHORT G_M000_IG126
 
G_M000_IG123:                ;; offset=0x1121
       add      edx, -49
       cmp      edx, 2
       jbe      SHORT G_M000_IG126
       jmp      G_M000_IG239
 
G_M000_IG124:                ;; offset=0x112E
       cmp      edx, 56
       je       SHORT G_M000_IG126
 
G_M000_IG125:                ;; offset=0x1133
       cmp      edx, 62
       je       SHORT G_M000_IG126
       add      edx, -68
       cmp      edx, 1
       ja       G_M000_IG239
 
G_M000_IG126:                ;; offset=0x1144
       mov      edx, dword ptr [r9+0x08]
       mov      dword ptr [rcx+0x18], edx
 
G_M000_IG127:                ;; offset=0x114B
       mov      dword ptr [rbp-0x70], 1
       jmp      G_M000_IG241
 
G_M000_IG128:                ;; offset=0x1157
       mov      eax, 0xFFFFFFFFC7052581
       jmp      G_M000_IG77
 
G_M000_IG129:                ;; offset=0x1161
       imul     r12d, dword ptr [rbp-0xD4], 0xFFFFFFFFC2B2AE3D
       add      r12d, eax
       rol      r12d, 17
       imul     eax, r12d, 0x27D4EB2F
       cmp      edx, 2
       jbe      G_M000_IG79
 
G_M000_IG130:                ;; offset=0x1183
       imul     edx, dword ptr [rbp-0xD0], 0xFFFFFFFFC2B2AE3D
       add      edx, eax
       rol      edx, 17
       imul     eax, edx, 0x27D4EB2F
       jmp      G_M000_IG79
 
G_M000_IG131:                ;; offset=0x119D
       mov      r15, gword ptr [r12+0x08]
       mov      gword ptr [rbp-0x2A8], r15
       lea      r15, bword ptr [r12+0x28]
       mov      r15d, dword ptr [r15]
       mov      r12d, dword ptr [r12+0x18]
       mov      dword ptr [rbp-0x84], r12d
       cmp      gword ptr [rbp-0x2A8], 0
       je       G_M000_IG149
       mov      qword ptr [rbp-0x220], r15
       mov      r15d, r12d
       add      r15, qword ptr [rbp-0x220]
       mov      qword ptr [rbp-0x35C], r15
       mov      r15, gword ptr [rbp-0x2A8]
       mov      r15d, dword ptr [r15+0x08]
       cmp      qword ptr [rbp-0x35C], r15
       ja       G_M000_IG235
       mov      r15, gword ptr [rbp-0x2A8]
       mov      r12, qword ptr [rbp-0x220]
       lea      r15, bword ptr [r15+r12+0x10]
       mov      r12d, dword ptr [rbp-0x84]
 
G_M000_IG132:                ;; offset=0x1215
       jmp      G_M000_IG65
 
G_M000_IG133:                ;; offset=0x121A
       mov      bword ptr [rbp-0x318], r15
       mov      r15, bword ptr [rbp-0x2B0]
       cmp      r14, r15
       je       G_M000_IG164
       cmp      r12, 32
       jae      G_M000_IG155
 
G_M000_IG134:                ;; offset=0x123B
       cmp      r12, 16
       jae      G_M000_IG160
 
G_M000_IG135:                ;; offset=0x1245
       add      r12, -8
       mov      qword ptr [rbp-0x90], r12
       mov      r15, qword ptr [r14]
       mov      r12, bword ptr [rbp-0x318]
       sub      r15, qword ptr [r12]
       mov      qword ptr [rbp-0x35C], r15
       mov      r15, qword ptr [rbp-0x90]
       mov      r15, qword ptr [r14+r15]
       mov      r14, qword ptr [rbp-0x90]
       sub      r15, qword ptr [r12+r14]
       or       r15, qword ptr [rbp-0x35C]
       sete     r14b
       movzx    r14, r14b
       jmp      G_M000_IG69
 
G_M000_IG136:                ;; offset=0x128F
       xor      r13, r13
       mov      bword ptr [rbp-0x308], r13
       xor      r10d, r10d
       jmp      G_M000_IG40
 
G_M000_IG137:                ;; offset=0x12A1
       or       r12d, eax
       jne      G_M000_IG235
       xor      r11, r11
       xor      edx, edx
       jmp      G_M000_IG41
 
G_M000_IG138:                ;; offset=0x12B4
       mov      bword ptr [rbp-0x2F8], r11
       mov      dword ptr [rbp-0x19C], edx
       mov      dword ptr [rbp-0x1C8], r12d
       mov      dword ptr [rbp-0x1C4], r10d
       mov      dword ptr [rbp-0x1C0], eax
       lea      rdx, [rbp-0x1C8]
       mov      rcx, gword ptr [rbp-0x248]
       call     [Lokad.Lython.Runtime.Text.PyStringOps+CasedWhitespaceIteration:Materialize(System.ValueTuple`3[int,int,int]):Lokad.Lython.Runtime.Text.PyString:this]
       mov      r14, rax
       mov      gword ptr [rbp-0x280], r14
       mov      rcx, bword ptr [rbp+0x10]
       jmp      G_M000_IG42
 
G_M000_IG139:                ;; offset=0x12FC
       cmp      dword ptr [r11+0x20], 0
       setne    r11b
       movzx    r11, r11b
       test     r11d, r11d
       je       G_M000_IG55
 
G_M000_IG140:                ;; offset=0x1312
       mov      rcx, r10
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
       mov      rcx, bword ptr [rbp+0x10]
       jmp      G_M000_IG55
 
G_M000_IG141:                ;; offset=0x1324
       mov      r14, gword ptr [rbp-0x2E8]
       mov      gword ptr [rbp-0x1E8], r14
       mov      r13d, dword ptr [rbp-0x194]
       mov      dword ptr [rbp-0x1E0], r13d
       mov      gword ptr [rsp+0x20], rdi
       mov      rax, gword ptr [rbp-0x250]
       mov      rdx, gword ptr [rax+0x18]
       mov      gword ptr [rsp+0x28], rdx
       lea      r9, [rbp-0x1E8]
       mov      rdx, r12
       mov      r8, gword ptr [rbp-0x268]
       mov      rcx, gword ptr [rbp-0x270]
       call     [Lokad.Lython.Runtime.PyDict:TryAccumulateWithoutAdmission(Lokad.Lython.Runtime.Text.PyString,System.Object,System.Numerics.BigInteger,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):bool:this]
       mov      r14d, eax
       mov      rax, gword ptr [rbp-0x270]
       jmp      G_M000_IG117
 
G_M000_IG142:                ;; offset=0x1382
       cmp      dword ptr [r10+0x20], 0
       setne    r10b
       movzx    r10, r10b
       test     r10d, r10d
       jne      SHORT G_M000_IG143
       jmp      G_M000_IG46
 
G_M000_IG143:                ;; offset=0x1399
       mov      rcx, rdx
       mov      rdx, rax
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
       jmp      G_M000_IG46
 
G_M000_IG144:                ;; offset=0x13AA
       jmp      G_M000_IG212
 
G_M000_IG145:                ;; offset=0x13AF
       mov      r15, gword ptr [r12+0x08]
       mov      r12d, dword ptr [r12+0x18]
       test     r15, r15
       jne      SHORT G_M000_IG147
 
G_M000_IG146:                ;; offset=0x13BE
       test     r12d, r12d
       jne      G_M000_IG235
       xor      r15, r15
       xor      r12d, r12d
       jmp      SHORT G_M000_IG148
 
G_M000_IG147:                ;; offset=0x13CF
       cmp      dword ptr [r15+0x08], r12d
       jb       G_M000_IG235
       add      r15, 16
 
G_M000_IG148:                ;; offset=0x13DD
       jmp      G_M000_IG65
 
G_M000_IG149:                ;; offset=0x13E2
       or       r15d, r12d
       jne      G_M000_IG235
       xor      r15, r15
       xor      r12d, r12d
       jmp      G_M000_IG132
 
G_M000_IG150:                ;; offset=0x13F6
       xor      r14d, r14d
       mov      dword ptr [rbp-0xBC], r14d
       mov      r14, r12
       and      r14, 2
       mov      qword ptr [rbp-0xC8], r14
       test     r14, r14
       je       SHORT G_M000_IG152
 
G_M000_IG151:                ;; offset=0x1413
       mov      r14, bword ptr [rbp-0x300]
       movzx    r14, word  ptr [r14]
       mov      dword ptr [rbp-0x354], r14d
       mov      bword ptr [rbp-0x318], r15
       movzx    r14, word  ptr [r15]
       movzx    r15, dword ptr [rbp-0x354]
       sub      r15d, r14d
       mov      r14d, r15d
       mov      dword ptr [rbp-0xBC], r14d
       mov      r15, bword ptr [rbp-0x318]
 
G_M000_IG152:                ;; offset=0x144C
       test     r12b, 1
       je       SHORT G_M000_IG154
 
G_M000_IG153:                ;; offset=0x1452
       mov      r12, bword ptr [rbp-0x300]
       mov      r14, qword ptr [rbp-0xC8]
       movzx    r14, byte  ptr [r12+r14]
       mov      dword ptr [rbp-0x354], r14d
       mov      r14, qword ptr [rbp-0xC8]
       movzx    r15, byte  ptr [r15+r14]
       movzx    r14, dword ptr [rbp-0x354]
       sub      r14d, r15d
       or       r14d, dword ptr [rbp-0xBC]
       mov      dword ptr [rbp-0xBC], r14d
 
G_M000_IG154:                ;; offset=0x1491
       cmp      dword ptr [rbp-0xBC], 0
       sete     r14b
       movzx    r14, r14b
       jmp      G_M000_IG69
 
G_M000_IG155:                ;; offset=0x14A5
       xor      r15d, r15d
       mov      qword ptr [rbp-0xA8], r15
       add      r12, -32
       mov      qword ptr [rbp-0xB0], r12
       test     r12, r12
       je       SHORT G_M000_IG156
       vmovups  ymm0, ymmword ptr [r14]
       mov      r12, bword ptr [rbp-0x2B0]
       vpcmpeqb ymm0, ymm0, ymmword ptr [r12]
       vpmovmskb r15d, ymm0
       cmp      r15d, -1
       je       SHORT G_M000_IG157
       jmp      G_M000_IG165
 
G_M000_IG156:                ;; offset=0x14E0
       mov      r12, bword ptr [rbp-0x2B0]
       jmp      SHORT G_M000_IG159
 
G_M000_IG157:                ;; offset=0x14E9
       mov      r15, qword ptr [rbp-0xA8]
       add      r15, 32
       cmp      qword ptr [rbp-0xB0], r15
       jbe      SHORT G_M000_IG159
 
G_M000_IG158:                ;; offset=0x14FD
       vmovups  ymm0, ymmword ptr [r14+r15]
       mov      qword ptr [rbp-0xA8], r15
       vpcmpeqb ymm0, ymm0, ymmword ptr [r12+r15]
       vpmovmskb r15d, ymm0
       cmp      r15d, -1
       jne      G_M000_IG165
       jmp      SHORT G_M000_IG157
 
G_M000_IG159:                ;; offset=0x1520
       mov      r15, qword ptr [rbp-0xB0]
       vmovups  ymm0, ymmword ptr [r14+r15]
       vpcmpeqb ymm0, ymm0, ymmword ptr [r12+r15]
       vpmovmskb r15d, ymm0
       cmp      r15d, -1
       jne      G_M000_IG165
       jmp      G_M000_IG164
 
G_M000_IG160:                ;; offset=0x1546
       xor      r15d, r15d
       mov      qword ptr [rbp-0x98], r15
       add      r12, -16
       mov      qword ptr [rbp-0xA0], r12
       test     r12, r12
       je       SHORT G_M000_IG163
       vmovups  xmm0, xmmword ptr [r14]
       mov      r15, bword ptr [rbp-0x2B0]
       vpcmpeqb xmm0, xmm0, xmmword ptr [r15]
       vpmovmskb r12d, xmm0
       cmp      r12d, 0xFFFF
       jne      SHORT G_M000_IG165
 
G_M000_IG161:                ;; offset=0x157E
       mov      r12, qword ptr [rbp-0x98]
       add      r12, 16
       cmp      qword ptr [rbp-0xA0], r12
       ja       SHORT G_M000_IG162
       jmp      SHORT G_M000_IG163
 
G_M000_IG162:                ;; offset=0x1594
       vmovups  xmm0, xmmword ptr [r14+r12]
       mov      qword ptr [rbp-0x98], r12
       vpcmpeqb xmm0, xmm0, xmmword ptr [r15+r12]
       vpmovmskb r12d, xmm0
       cmp      r12d, 0xFFFF
       jne      SHORT G_M000_IG165
       jmp      SHORT G_M000_IG161
 
G_M000_IG163:                ;; offset=0x15B6
       mov      r12, qword ptr [rbp-0xA0]
       vmovups  xmm0, xmmword ptr [r14+r12]
       mov      r15, bword ptr [rbp-0x2B0]
       vpcmpeqb xmm0, xmm0, xmmword ptr [r15+r12]
       vpmovmskb r15d, xmm0
       cmp      r15d, 0xFFFF
       jne      SHORT G_M000_IG165
 
G_M000_IG164:                ;; offset=0x15DD
       mov      r15d, 1
       mov      r14d, r15d
       jmp      G_M000_IG69
 
G_M000_IG165:                ;; offset=0x15EB
       xor      r15d, r15d
       mov      r14d, r15d
       jmp      G_M000_IG69
 
G_M000_IG166:                ;; offset=0x15F6
       cmp      dword ptr [r15+0x20], 0
       setne    r15b
       movzx    r15, r15b
       test     r15d, r15d
       je       G_M000_IG50
 
G_M000_IG167:                ;; offset=0x160C
       mov      rcx, rdx
       mov      rdx, gword ptr [rbp-0x298]
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
       mov      r10, gword ptr [rbp-0x2A0]
       mov      r11d, dword ptr [rbp-0x7C]
       jmp      G_M000_IG50
 
G_M000_IG168:                ;; offset=0x162C
       mov      edx, dword ptr [rbp-0xCC]
       and      edx, 3
       dec      edx
       cmp      edx, 2
       ja       G_M000_IG73
       mov      qword ptr [rbp-0x35C], rdx
       lea      rdx, [reloc @RWD00]
       mov      dword ptr [rbp-0x1AC], eax
       mov      r15, qword ptr [rbp-0x35C]
       mov      edx, dword ptr [rdx+4*r15]
       lea      r14, G_M000_IG02
       add      rdx, r14
       jmp      rdx
 
G_M000_IG169:                ;; offset=0x166B
       mov      r14, bword ptr [rbp-0x328]
       jmp      SHORT G_M000_IG173
 
G_M000_IG170:                ;; offset=0x1674
       mov      r14, bword ptr [rbp-0x328]
       jmp      SHORT G_M000_IG172
 
G_M000_IG171:                ;; offset=0x167D
       mov      r14, bword ptr [rbp-0x320]
       mov      edx, dword ptr [r14]
       lea      rcx, [rbp-0xE8]
       call     [System.HashCode:Add(int):this]
       add      r14, 4
       mov      rdx, r14
       mov      r15d, dword ptr [rbp-0xEC]
       lea      eax, [r15-0x04]
       mov      r14, rdx
       mov      dword ptr [rbp-0x1AC], eax
 
G_M000_IG172:                ;; offset=0x16AF
       mov      edx, dword ptr [r14]
       lea      rcx, [rbp-0xE8]
       call     [System.HashCode:Add(int):this]
       add      r14, 4
       mov      eax, dword ptr [rbp-0x1AC]
       add      eax, -4
       mov      dword ptr [rbp-0x1AC], eax
 
G_M000_IG173:                ;; offset=0x16D2
       mov      edx, dword ptr [r14]
       lea      rcx, [rbp-0xE8]
       call     [System.HashCode:Add(int):this]
       add      r14, 4
       mov      eax, dword ptr [rbp-0x1AC]
       add      eax, -4
       mov      bword ptr [rbp-0x328], r14
       mov      r10, gword ptr [rbp-0x2A0]
       mov      r11d, dword ptr [rbp-0x7C]
       jmp      G_M000_IG73
 
G_M000_IG174:                ;; offset=0x1706
       mov      rdx, bword ptr [rbp-0x328]
       mov      edx, dword ptr [rdx]
       lea      rcx, [rbp-0xE8]
       call     [System.HashCode:Add(int):this]
       mov      rdx, bword ptr [rbp-0x328]
       add      rdx, 4
       mov      ecx, dword ptr [rbp-0x1AC]
       add      ecx, -4
       mov      bword ptr [rbp-0x328], rdx
       mov      eax, ecx
       mov      r10, gword ptr [rbp-0x2A0]
       mov      r11d, dword ptr [rbp-0x7C]
       jmp      G_M000_IG52
 
G_M000_IG175:                ;; offset=0x1749
       mov      r15, bword ptr [rbp-0x330]
       mov      qword ptr [rbp-0x240], rdx
       movzx    rdx, byte  ptr [r15+rdx]
       lea      rcx, [rbp-0xE8]
       call     [System.HashCode:Add(int):this]
       mov      rax, qword ptr [rbp-0x240]
       inc      eax
       mov      edx, dword ptr [rbp-0x1B0]
       cmp      eax, edx
       jl       SHORT G_M000_IG179
       mov      r10, gword ptr [rbp-0x2A0]
       mov      r11d, dword ptr [rbp-0x7C]
       jmp      G_M000_IG53
 
G_M000_IG176:                ;; offset=0x178C
       mov      eax, -2
       jmp      G_M000_IG80
 
G_M000_IG177:                ;; offset=0x1796
       mov      eax, r12d
       jmp      G_M000_IG212
 
G_M000_IG178:                ;; offset=0x179E
       mov      r15d, edx
       mov      eax, r12d
       xor      edx, edx
       div      edx:eax, r15d
       mov      eax, edx
       jmp      G_M000_IG82
 
G_M000_IG179:                ;; offset=0x17B0
       mov      rdx, rax
       jmp      SHORT G_M000_IG175
 
G_M000_IG180:                ;; offset=0x17B5
       cmp      dword ptr [r15+0x20], 0
       setne    r15b
       movzx    r15, r15b
       test     r15d, r15d
       je       G_M000_IG86
       jmp      SHORT G_M000_IG182
 
G_M000_IG181:                ;; offset=0x17CD
       mov      eax, r12d
       jmp      G_M000_IG212
 
G_M000_IG182:                ;; offset=0x17D5
       mov      rcx, rdx
       mov      rdx, gword ptr [rbp-0x298]
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
       jmp      G_M000_IG86
 
G_M000_IG183:                ;; offset=0x17EA
       mov      r14, gword ptr [rdx+0x08]
       mov      edx, dword ptr [rdx+0x18]
       test     r14, r14
       jne      SHORT G_M000_IG185
 
G_M000_IG184:                ;; offset=0x17F6
       test     edx, edx
       jne      G_M000_IG235
       xor      r14, r14
       xor      edx, edx
       jmp      SHORT G_M000_IG186
 
G_M000_IG185:                ;; offset=0x1805
       cmp      dword ptr [r14+0x08], edx
       jb       G_M000_IG235
       add      r14, 16
 
G_M000_IG186:                ;; offset=0x1813
       jmp      G_M000_IG92
 
G_M000_IG187:                ;; offset=0x1818
       or       r14d, edx
       jne      G_M000_IG235
       xor      r14, r14
       xor      edx, edx
       jmp      G_M000_IG102
 
G_M000_IG188:                ;; offset=0x182B
       mov      r10, gword ptr [rbp-0x2A0]
       mov      r14, bword ptr [rbp-0x300]
       jmp      G_M000_IG84
 
G_M000_IG189:                ;; offset=0x183E
       cmp      dword ptr [rdx+0x20], 0
       setne    dl
       movzx    rdx, dl
       test     edx, edx
       je       G_M000_IG95
 
G_M000_IG190:                ;; offset=0x1850
       mov      rcx, gword ptr [rbp-0x2C0]
       mov      rdx, gword ptr [rbp-0x298]
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
       jmp      G_M000_IG95
 
G_M000_IG191:                ;; offset=0x1869
       xor      edx, edx
       mov      dword ptr [rbp-0x13C], edx
       mov      rdx, r14
       and      rdx, 2
       mov      qword ptr [rbp-0x148], rdx
       test     rdx, rdx
       je       SHORT G_M000_IG193
 
G_M000_IG192:                ;; offset=0x1884
       mov      rdx, bword ptr [rbp-0x340]
       movzx    rdx, word  ptr [rdx]
       mov      dword ptr [rbp-0x354], edx
       mov      rdx, bword ptr [rbp-0x348]
       movzx    rdx, word  ptr [rdx]
       movzx    rsi, dword ptr [rbp-0x354]
       sub      esi, edx
       mov      edx, esi
       mov      dword ptr [rbp-0x13C], edx
 
G_M000_IG193:                ;; offset=0x18AF
       test     r14b, 1
       je       SHORT G_M000_IG195
 
G_M000_IG194:                ;; offset=0x18B5
       mov      r14, bword ptr [rbp-0x340]
       mov      rdx, qword ptr [rbp-0x148]
       movzx    r14, byte  ptr [r14+rdx]
       mov      dword ptr [rbp-0x354], r14d
       mov      r14, bword ptr [rbp-0x348]
       movzx    rdx, byte  ptr [r14+rdx]
       movzx    r14, dword ptr [rbp-0x354]
       sub      r14d, edx
       mov      edx, r14d
       or       edx, dword ptr [rbp-0x13C]
       mov      dword ptr [rbp-0x13C], edx
 
G_M000_IG195:                ;; offset=0x18F5
       cmp      dword ptr [rbp-0x13C], 0
       sete     dl
       movzx    rdx, dl
       jmp      G_M000_IG99
 
G_M000_IG196:                ;; offset=0x1907
       mov      r10, gword ptr [rbp-0x2A0]
       mov      r14, bword ptr [rbp-0x300]
       jmp      G_M000_IG84
 
G_M000_IG197:                ;; offset=0x191A
       xor      edx, edx
       mov      qword ptr [rbp-0x128], rdx
       add      r14, -32
       mov      qword ptr [rbp-0x130], r14
       test     r14, r14
       je       SHORT G_M000_IG199
       mov      r14, bword ptr [rbp-0x2C8]
       vmovups  ymm0, ymmword ptr [r14]
       mov      rdx, bword ptr [rbp-0x2D0]
       vpcmpeqb ymm0, ymm0, ymmword ptr [rdx]
       vpmovmskb edx, ymm0
       cmp      edx, -1
       je       SHORT G_M000_IG200
 
G_M000_IG198:                ;; offset=0x1953
       mov      r10, gword ptr [rbp-0x2A0]
       mov      r14, bword ptr [rbp-0x300]
       jmp      G_M000_IG84
 
G_M000_IG199:                ;; offset=0x1966
       mov      r14, bword ptr [rbp-0x2C8]
       jmp      SHORT G_M000_IG203
 
G_M000_IG200:                ;; offset=0x196F
       mov      rdx, qword ptr [rbp-0x128]
       add      rdx, 32
       cmp      qword ptr [rbp-0x130], rdx
       jbe      SHORT G_M000_IG203
 
G_M000_IG201:                ;; offset=0x1983
       vmovups  ymm0, ymmword ptr [r14+rdx]
       mov      r14, bword ptr [rbp-0x2D0]
       mov      qword ptr [rbp-0x128], rdx
       vpcmpeqb ymm0, ymm0, ymmword ptr [r14+rdx]
       vpmovmskb edx, ymm0
       cmp      edx, -1
       jne      SHORT G_M000_IG202
       mov      r14, bword ptr [rbp-0x2C8]
       jmp      SHORT G_M000_IG200
 
G_M000_IG202:                ;; offset=0x19AF
       mov      r10, gword ptr [rbp-0x2A0]
       mov      r14, bword ptr [rbp-0x300]
       jmp      G_M000_IG84
 
G_M000_IG203:                ;; offset=0x19C2
       mov      rdx, qword ptr [rbp-0x130]
       vmovups  ymm0, ymmword ptr [r14+rdx]
       mov      r14, bword ptr [rbp-0x2D0]
       vpcmpeqb ymm0, ymm0, ymmword ptr [r14+rdx]
       vpmovmskb edx, ymm0
       cmp      edx, -1
       je       G_M000_IG100
 
G_M000_IG204:                ;; offset=0x19E9
       mov      r10, gword ptr [rbp-0x2A0]
       mov      r14, bword ptr [rbp-0x300]
       jmp      G_M000_IG84
 
G_M000_IG205:                ;; offset=0x19FC
       xor      edx, edx
       mov      qword ptr [rbp-0x118], rdx
       add      r14, -16
       mov      qword ptr [rbp-0x120], r14
       test     r14, r14
       je       G_M000_IG209
       mov      rdx, bword ptr [rbp-0x2C8]
       vmovups  xmm0, xmmword ptr [rdx]
       mov      r14, bword ptr [rbp-0x2D0]
       vpcmpeqb xmm0, xmm0, xmmword ptr [r14]
       vpmovmskb r14d, xmm0
       cmp      r14d, 0xFFFF
       je       SHORT G_M000_IG207
 
G_M000_IG206:                ;; offset=0x1A3D
       mov      r10, gword ptr [rbp-0x2A0]
       mov      r14, bword ptr [rbp-0x300]
       jmp      G_M000_IG84
 
G_M000_IG207:                ;; offset=0x1A50
       mov      r14, qword ptr [rbp-0x118]
       add      r14, 16
       cmp      qword ptr [rbp-0x120], r14
       ja       SHORT G_M000_IG208
       jmp      SHORT G_M000_IG209
 
G_M000_IG208:                ;; offset=0x1A66
       vmovups  xmm0, xmmword ptr [rdx+r14]
       mov      rdx, bword ptr [rbp-0x2D0]
       mov      qword ptr [rbp-0x118], r14
       vpcmpeqb xmm0, xmm0, xmmword ptr [rdx+r14]
       vpmovmskb r14d, xmm0
       cmp      r14d, 0xFFFF
       mov      rdx, bword ptr [rbp-0x2C8]
       je       SHORT G_M000_IG207
       mov      r10, gword ptr [rbp-0x2A0]
       mov      r14, bword ptr [rbp-0x300]
       jmp      G_M000_IG84
 
G_M000_IG209:                ;; offset=0x1AA7
       mov      rdx, bword ptr [rbp-0x2C8]
       mov      r14, qword ptr [rbp-0x120]
       vmovups  xmm0, xmmword ptr [rdx+r14]
       mov      rdx, bword ptr [rbp-0x2D0]
       vpcmpeqb xmm0, xmm0, xmmword ptr [rdx+r14]
       vpmovmskb edx, xmm0
       cmp      edx, 0xFFFF
       je       G_M000_IG100
 
G_M000_IG210:                ;; offset=0x1AD8
       mov      r10, gword ptr [rbp-0x2A0]
       mov      r14, bword ptr [rbp-0x300]
       jmp      G_M000_IG84
 
G_M000_IG211:                ;; offset=0x1AEB
       mov      eax, r12d
 
G_M000_IG212:                ;; offset=0x1AEE
       mov      r12d, -1
       mov      r15d, r12d
       mov      r12d, eax
       jmp      G_M000_IG109
 
G_M000_IG213:                ;; offset=0x1AFF
       mov      r14, bword ptr [rbp-0x300]
       mov      bword ptr [rbp-0x1F8], r14
       mov      dword ptr [rbp-0x1F0], r13d
       mov      r14, gword ptr [rbp-0x2E8]
       mov      gword ptr [rbp-0x1E8], r14
       mov      r15d, dword ptr [rbp-0x194]
       mov      dword ptr [rbp-0x1E0], r15d
       mov      gword ptr [rsp+0x28], rdi
       mov      r13, gword ptr [rbp-0x298]
       mov      gword ptr [rsp+0x30], r13
       mov      rdx, gword ptr [rbp-0x248]
       mov      gword ptr [rsp+0x38], rdx
       lea      rdx, [rbp-0x60]
       mov      qword ptr [rsp+0x40], rdx
       lea      rdx, [rbp-0x1F8]
       lea      rax, [rbp-0x1E8]
       mov      qword ptr [rsp+0x20], rax
       mov      r8d, r12d
       mov      r9, gword ptr [rbp-0x268]
       mov      rcx, gword ptr [rbp-0x270]
       call     [Lokad.Lython.Runtime.PyDict:TryAppendBorrowedWord(System.ReadOnlySpan`1[byte],uint,System.Object,System.Numerics.BigInteger,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.Text.PyStringOps+CasedWhitespaceIteration,byref):bool:this]
       mov      r14d, eax
       mov      rax, gword ptr [rbp-0x270]
       jmp      G_M000_IG117
 
G_M000_IG214:                ;; offset=0x1B8F
       mov      rdx, r10
       mov      rcx, r11
       call     CORINFO_HELP_CHKCASTCLASS
       int3     
 
G_M000_IG215:                ;; offset=0x1B9B
       mov      rcx, r8
       mov      edx, r14d
       call     [Lokad.Lython.Runtime.PyDict:ReadNativeValue(int):System.Object:this]
       mov      gword ptr [rbp-0x2D8], rax
       test     rax, rax
       jne      SHORT G_M000_IG218
 
G_M000_IG216:                ;; offset=0x1BB3
       mov      r8, gword ptr [rbp-0x270]
 
G_M000_IG217:                ;; offset=0x1BBA
       xor      r14d, r14d
       mov      rax, r8
       jmp      G_M000_IG117
 
G_M000_IG218:                ;; offset=0x1BC5
       mov      rdx, qword ptr [rax]
       mov      rcx, 0x7FFA029EB3F0
       cmp      rdx, rcx
       je       SHORT G_M000_IG220
 
G_M000_IG219:                ;; offset=0x1BD7
       mov      r8, gword ptr [rbp-0x270]
       jmp      SHORT G_M000_IG217
 
G_M000_IG220:                ;; offset=0x1BE0
       mov      rcx, 0x7FFA029EB3F0
       cmp      rdx, rcx
       je       SHORT G_M000_IG222
 
G_M000_IG221:                ;; offset=0x1BEF
       mov      rdx, rax
       mov      rcx, 0x7FFA029EB3F0
       call     CORINFO_HELP_UNBOX
       mov      rax, gword ptr [rbp-0x2D8]
 
G_M000_IG222:                ;; offset=0x1C08
       vmovdqu  xmm0, xmmword ptr [rax+0x08]
       vmovdqu  xmmword ptr [rbp-0x158], xmm0
 
G_M000_IG223:                ;; offset=0x1C15
       xor      r8d, r8d
       mov      dword ptr [rbp-0x180], r8d
 
G_M000_IG224:                ;; offset=0x1C1F
       mov      bword ptr [rbp-0x1D8], r8
 
G_M000_IG225:                ;; offset=0x1C26
       mov      dword ptr [rbp-0x1D0], r8d
 
G_M000_IG226:                ;; offset=0x1C2D
       mov      dword ptr [rsp+0x20], r8d
       lea      r8, [rbp-0x180]
       mov      qword ptr [rsp+0x28], r8
       lea      r8, [rbp-0x1D8]
       lea      rcx, [rbp-0x158]
       mov      edx, 1
       xor      r9d, r9d
       call     [System.Numerics.BigInteger:TryGetBytes(int,System.Span`1[byte],bool,bool,byref):byte[]:this]
       cmp      dword ptr [rbp-0x180], 8
       jl       SHORT G_M000_IG228
 
G_M000_IG227:                ;; offset=0x1C63
       mov      r8, gword ptr [rbp-0x270]
       jmp      G_M000_IG217
 
G_M000_IG228:                ;; offset=0x1C6F
       vmovdqu  xmm0, xmmword ptr [rbp-0x158]
       vmovdqu  xmmword ptr [rbp-0x1E8], xmm0
 
G_M000_IG229:                ;; offset=0x1C7F
       lea      rcx, [rbp-0x1E8]
       call     [System.Numerics.BigInteger:op_Explicit(System.Numerics.BigInteger):long]
       mov      qword ptr [rbp-0x160], rax
       jmp      G_M000_IG114
 
G_M000_IG230:                ;; offset=0x1C98
       vxorps   xmm0, xmm0, xmm0
       vmovdqu  xmmword ptr [rbp-0x178], xmm0
       lea      rcx, [rbp-0x178]
       call     [System.Numerics.BigInteger:.ctor(long):this]
       mov      rcx, 0x7FFA029EB3F0
       call     CORINFO_HELP_NEWSFAST
       mov      r14, rax
       lea      rcx, bword ptr [r14+0x08]
       mov      rdx, gword ptr [rbp-0x178]
       call     CORINFO_HELP_ASSIGN_REF
       mov      r9d, dword ptr [rbp-0x170]
       mov      dword ptr [r14+0x10], r9d
       mov      dword ptr [rsp+0x20], r12d
       xor      r9d, r9d
       mov      dword ptr [rsp+0x28], r9d
       mov      dword ptr [rsp+0x30], 1
       mov      r9, r14
       mov      rcx, gword ptr [rbp-0x270]
       mov      edx, r15d
       mov      r8, r13
       call     [Lokad.Lython.Runtime.PyDict:PublishNativeValue(int,System.Object,System.Object,uint,bool,bool):System.Object:this]
       jmp      G_M000_IG115
 
G_M000_IG231:                ;; offset=0x1D0E
       inc      dword ptr [rax+0x48]
       mov      rax, gword ptr [rbp-0x270]
       jmp      G_M000_IG116
 
G_M000_IG232:                ;; offset=0x1D1D
       mov      r11, r8
       mov      r10, gword ptr [rbp-0x350]
       cmp      dword ptr [r10+0x20], 0
       setne    r10b
       movzx    r10, r10b
       test     r10d, r10d
       mov      r8, r11
       mov      rdx, gword ptr [rbp-0x2E0]
       je       G_M000_IG37
       mov      esi, dword ptr [rbp-0x3C]
       mov      r14d, dword ptr [rbp-0x44]
 
G_M000_IG233:                ;; offset=0x1D4E
       mov      rcx, r8
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
       mov      rcx, bword ptr [rbp+0x10]
       jmp      G_M000_IG37
 
G_M000_IG234:                ;; offset=0x1D60
       jmp      SHORT G_M000_IG233
 
G_M000_IG235:                ;; offset=0x1D62
       call     [System.ThrowHelper:ThrowArgumentOutOfRangeException()]
       int3     
 
G_M000_IG236:                ;; offset=0x1D69
       mov      ecx, 40
       call     [System.ThrowHelper:ThrowArgumentOutOfRangeException(int)]
       int3     
 
G_M000_IG237:                ;; offset=0x1D75
       mov      rcx, bword ptr [rbp+0x10]
       mov      r15d, dword ptr [rbp-0x204]
       mov      dword ptr [rcx+0x18], r15d
       mov      rcx, bword ptr [rbp+0x10]
       mov      r9, bword ptr [rbp+0x28]
       jmp      G_M000_IG127
 
G_M000_IG238:                ;; offset=0x1D91
       mov      ebx, dword ptr [rbp-0x40]
       add      ebx, 2
       mov      rcx, bword ptr [rbp+0x10]
       mov      dword ptr [rcx+0x18], ebx
       mov      r9, bword ptr [rbp+0x28]
       jmp      G_M000_IG127
 
G_M000_IG239:                ;; offset=0x1DA7
       mov      rcx, r9
       mov      rdx, 0x28870611498
       call     [Lokad.Lython.Frontend.ExecutableInstruction:InvalidOperand(System.String):System.InvalidOperationException:this]
       mov      rcx, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG240:                ;; offset=0x1DC3
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG241:                ;; offset=0x1DC9
       call     G_M000_IG297
       nop      
 
G_M000_IG242:                ;; offset=0x1DCF
       mov      ebx, dword ptr [rbp-0x70]
       jmp      SHORT G_M000_IG244
 
G_M000_IG243:                ;; offset=0x1DD4
       mov      rcx, bword ptr [rbp+0x10]
       mov      r9, bword ptr [rbp+0x28]
       mov      dword ptr [rsp+0x20], esi
       mov      rdx, gword ptr [rbp+0x18]
       mov      r8, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteOrdinaryDictionaryLoop(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,bool):bool]
       mov      ebx, eax
 
G_M000_IG244:                ;; offset=0x1DEF
       movzx    rax, bl
 
G_M000_IG245:                ;; offset=0x1DF2
       vzeroupper 
       add      rsp, 888
       pop      rbx
       pop      rsi
       pop      rdi
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG246:                ;; offset=0x1E09
       mov      rcx, r9
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      r9, bword ptr [rbp+0x28]
       jmp      G_M000_IG05
 
G_M000_IG247:                ;; offset=0x1E1B
       xor      rax, rax
       jmp      G_M000_IG08
 
G_M000_IG248:                ;; offset=0x1E22
       mov      rcx, rax
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishInteger():System.Object:this]
       mov      rdi, rax
       jmp      G_M000_IG11
 
G_M000_IG249:                ;; offset=0x1E33
       mov      rcx, rax
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishDouble():System.Object:this]
       mov      rdi, rax
       jmp      G_M000_IG11
 
G_M000_IG250:                ;; offset=0x1E44
       mov      rcx, rax
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishTupleBorrow():System.Object:this]
       mov      rdi, rax
       jmp      G_M000_IG11
 
G_M000_IG251:                ;; offset=0x1E55
       mov      rcx, 0x7FFA0276A220
       call     CORINFO_HELP_NEWSFAST
       mov      rbx, rax
       mov      rcx, rbx
       mov      rdx, 0x2887060AC98
       call     [System.InvalidOperationException:.ctor(System.String):this]
       mov      rcx, rbx
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG252:                ;; offset=0x1E83
       mov      rcx, r9
       mov      rdx, 0x28870613FC0
       call     [Lokad.Lython.Frontend.ExecutableInstruction:InvalidOperand(System.String):System.InvalidOperationException:this]
       mov      rcx, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG253:                ;; offset=0x1E9F
       mov      rcx, rdx
       mov      rdx, 0x2887060D488
       call     [Lokad.Lython.Frontend.ExecutableInstruction:InvalidOperand(System.String):System.InvalidOperationException:this]
       mov      rcx, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG254:                ;; offset=0x1EBB
       call     [System.ThrowHelper:ThrowArgumentOutOfRange_IndexMustBeLessException()]
       int3     
 
G_M000_IG255:                ;; offset=0x1EC2
       mov      rcx, rax
       mov      r11, 0x7FFA025426F8
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       mov      r14, rax
       jmp      G_M000_IG13
 
G_M000_IG256:                ;; offset=0x1EDA
       mov      rcx, r8
       mov      rdx, 0x2887060D4B8
       call     [Lokad.Lython.Frontend.ExecutableInstruction:InvalidOperand(System.String):System.InvalidOperationException:this]
       mov      rcx, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG257:                ;; offset=0x1EF6
       cmp      edx, 64
       je       G_M000_IG14
       cmp      edx, 67
       je       G_M000_IG14
       cmp      edx, 70
       jne      SHORT G_M000_IG256
       jmp      G_M000_IG14
 
G_M000_IG258:                ;; offset=0x1F12
       mov      rcx, rdx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishInteger():System.Object:this]
       mov      r8, rax
       jmp      G_M000_IG18
 
G_M000_IG259:                ;; offset=0x1F23
       mov      rcx, rdx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishDouble():System.Object:this]
       mov      r8, rax
       jmp      G_M000_IG18
 
G_M000_IG260:                ;; offset=0x1F34
       mov      rcx, rdx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishTupleBorrow():System.Object:this]
       mov      r8, rax
       jmp      G_M000_IG18
 
G_M000_IG261:                ;; offset=0x1F45
       cmp      qword ptr [r10+0x08], 0
       jle      SHORT G_M000_IG264
 
G_M000_IG262:                ;; offset=0x1F4C
       mov      rdx, gword ptr [r10]
       mov      rcx, 0x7FFA02C340B8
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG263
       mov      r10, bword ptr [rbp-0x290]
       mov      edx, dword ptr [r10+0x08]
       dec      edx
       lea      r8, [rbp-0x50]
       mov      rcx, rax
       call     [Lokad.Lython.Runtime.PyTuple:TryReadInteger(int,byref):bool:this]
       jmp      SHORT G_M000_IG265
 
G_M000_IG263:                ;; offset=0x1F7F
       mov      r10, bword ptr [rbp-0x290]
 
G_M000_IG264:                ;; offset=0x1F86
       mov      rcx, gword ptr [r10]
       lea      rdx, [rbp-0x50]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryMachineInteger(System.Object,byref):bool]
 
G_M000_IG265:                ;; offset=0x1F93
       test     eax, eax
       je       G_M000_IG19
       jmp      G_M000_IG27
 
G_M000_IG266:                ;; offset=0x1FA0
       cmp      dword ptr [r10+0x08], 1
       jle      SHORT G_M000_IG267
       mov      rcx, 0x7FFA02C7EE18
       call     CORINFO_HELP_NEWSFAST
       mov      r13, rax
       call     [System.SR:get_Overflow_Int64():System.String]
       mov      rdx, rax
       mov      rcx, r13
       call     [System.OverflowException:.ctor(System.String):this]
       mov      rcx, r13
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG267:                ;; offset=0x1FD4
       cmp      dword ptr [r10+0x08], 0
       jbe      SHORT G_M000_IG271
       mov      r10, qword ptr [r10+0x10]
       mov      qword ptr [rbp-0x78], r10
       neg      r10
       test     eax, eax
       cmovg    r10, qword ptr [rbp-0x78]
       test     r10, r10
       jle      SHORT G_M000_IG268
       test     eax, eax
       jg       SHORT G_M000_IG269
 
G_M000_IG268:                ;; offset=0x1FF6
       test     r10, r10
       jge      SHORT G_M000_IG270
       test     eax, eax
       jge      SHORT G_M000_IG270
 
G_M000_IG269:                ;; offset=0x1FFF
       jmp      G_M000_IG30
 
G_M000_IG270:                ;; offset=0x2004
       mov      rcx, 0x7FFA02C7EE18
       call     CORINFO_HELP_NEWSFAST
       mov      rbx, rax
       call     [System.SR:get_Overflow_Int64():System.String]
       mov      rdx, rax
       mov      rcx, rbx
       call     [System.OverflowException:.ctor(System.String):this]
       mov      rcx, rbx
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG271:                ;; offset=0x2031
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG272:                ;; offset=0x2037
       sub      rsp, 72
 
G_M000_IG273:                ;; offset=0x203B
       cmp      dword ptr [rbp-0x64], 0
       je       SHORT G_M000_IG275
 
G_M000_IG274:                ;; offset=0x2041
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rcx+0x08]
       mov      r11, bword ptr [rbp-0x278]
       mov      eax, dword ptr [r11+0x10]
       cmp      eax, dword ptr [rdx+0x08]
       jae      SHORT G_M000_IG279
       shl      rax, 4
       lea      rbx, bword ptr [rdx+rax+0x10]
       mov      rsi, qword ptr [rbp-0x50]
       mov      rdx, 0x26849C01D00
       mov      rdx, gword ptr [rdx]
       mov      rcx, rbx
       call     CORINFO_HELP_ASSIGN_REF
       mov      qword ptr [rbx+0x08], rsi
 
G_M000_IG275:                ;; offset=0x207F
       cmp      dword ptr [rbp-0x6C], 0
       je       SHORT G_M000_IG277
 
G_M000_IG276:                ;; offset=0x2085
       mov      rcx, bword ptr [rbp+0x10]
       add      rcx, 32
       mov      r9, bword ptr [rbp+0x28]
       mov      edx, dword ptr [r9+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
 
G_M000_IG277:                ;; offset=0x209B
       nop      
 
G_M000_IG278:                ;; offset=0x209C
       vzeroupper 
       add      rsp, 72
       ret      
 
G_M000_IG279:                ;; offset=0x20A4
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG280:                ;; offset=0x20AA
       sub      rsp, 72
 
G_M000_IG281:                ;; offset=0x20AE
       cmp      gword ptr [rbp-0x60], 0
       jne      SHORT G_M000_IG283
 
G_M000_IG282:                ;; offset=0x20B5
       cmp      dword ptr [rbp-0x198], 0
       je       G_M000_IG295
 
G_M000_IG283:                ;; offset=0x20C2
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rcx+0x08]
       mov      rax, bword ptr [rbp-0x260]
       mov      r8d, dword ptr [rax+0x1C]
       cmp      r8d, 9
       je       SHORT G_M000_IG285
 
G_M000_IG284:                ;; offset=0x20DB
       cmp      r8d, 10
       je       SHORT G_M000_IG285
       mov      rcx, rax
       mov      rdx, 0x28870611568
       call     [Lokad.Lython.Frontend.ExecutableInstruction:InvalidOperand(System.String):System.InvalidOperationException:this]
       mov      rcx, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG285:                ;; offset=0x20FD
       mov      eax, dword ptr [rax+0x14]
       cmp      eax, dword ptr [rdx+0x08]
       jae      G_M000_IG293
       shl      rax, 4
       lea      rdi, bword ptr [rdx+rax+0x10]
       mov      rdx, gword ptr [rbp-0x60]
       cmp      gword ptr [rbp-0x60], 0
       jne      G_M000_IG294
 
G_M000_IG286:                ;; offset=0x2121
       mov      rcx, gword ptr [rbp-0x248]
       mov      edx, dword ptr [rbp-0x198]
       call     [Lokad.Lython.Runtime.Text.PyStringOps+CasedWhitespaceIteration:WordCharge(int):long:this]
       mov      rbx, rax
       mov      rcx, gword ptr [rbp-0x248]
       mov      rsi, gword ptr [rcx+0x08]
       mov      rcx, 0x7FFA02A61030
       call     CORINFO_HELP_NEWSFAST
       mov      r14, rax
       mov      dword ptr [r14+0x1C], -1
       cmp      dword ptr [rbp-0x198], 0
       jne      SHORT G_M000_IG288
 
G_M000_IG287:                ;; offset=0x2165
       xor      ecx, ecx
       mov      rdx, 0x28870606810
       call     [System.ArgumentOutOfRangeException:ThrowNegativeOrZero[int](int,System.String)]
       int3     
 
G_M000_IG288:                ;; offset=0x2178
       cmp      dword ptr [rbp-0x198], 8
       jg       SHORT G_M000_IG290
 
G_M000_IG289:                ;; offset=0x2181
       mov      edx, dword ptr [rbp-0x198]
       mov      byte  ptr [r14+0x24], dl
       jmp      SHORT G_M000_IG291
 
G_M000_IG290:                ;; offset=0x218D
       mov      edx, dword ptr [rbp-0x198]
       mov      rcx, 0x7FFA027200F0
       call     CORINFO_HELP_NEWARR_1_VC
       mov      rdx, rax
       lea      rcx, bword ptr [r14+0x08]
       call     CORINFO_HELP_ASSIGN_REF
 
G_M000_IG291:                ;; offset=0x21AE
       mov      ecx, dword ptr [rbp-0x198]
       mov      dword ptr [r14+0x18], ecx
       lea      rcx, bword ptr [r14+0x10]
       mov      rdx, rsi
       call     CORINFO_HELP_ASSIGN_REF
       lea      rdx, [rbp-0x190]
       mov      rcx, r14
       call     [Lokad.Lython.Runtime.Text.PyString:get_UnpublishedUtf8():System.Span`1[byte]:this]
       mov      rcx, bword ptr [rbp-0x190]
       mov      r8d, dword ptr [rbp-0x188]
       cmp      dword ptr [rbp-0x198], r8d
       jg       SHORT G_M000_IG292
       mov      r8d, dword ptr [rbp-0x198]
       mov      rdx, bword ptr [rbp-0x2F0]
       call     [System.SpanHelpers:Memmove(byref,byref,nuint)]
       mov      rcx, r14
       mov      edx, dword ptr [rbp-0x198]
       call     [Lokad.Lython.Runtime.Text.PyString:CompleteUnpublishedUtf8(int):this]
       mov      rax, gword ptr [rbp-0x248]
       sub      qword ptr [rax+0x28], rbx
       mov      rdx, r14
       jmp      SHORT G_M000_IG294
 
G_M000_IG292:                ;; offset=0x221E
       call     [System.ThrowHelper:ThrowArgumentException_DestinationTooShort()]
       int3     
 
G_M000_IG293:                ;; offset=0x2225
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG294:                ;; offset=0x222B
       mov      rcx, rdi
       call     CORINFO_HELP_ASSIGN_REF
       xor      ecx, ecx
       mov      qword ptr [rdi+0x08], rcx
 
G_M000_IG295:                ;; offset=0x2239
       call     G_M000_IG272
       nop      
 
G_M000_IG296:                ;; offset=0x223F
       vzeroupper 
       add      rsp, 72
       ret      
 
G_M000_IG297:                ;; offset=0x2247
       sub      rsp, 72
 
G_M000_IG298:                ;; offset=0x224B
       cmp      dword ptr [rbp-0x68], 0
       je       SHORT G_M000_IG301
 
G_M000_IG299:                ;; offset=0x2251
       mov      rdi, gword ptr [rbp+0x18]
       mov      rcx, gword ptr [rdi+0x98]
       mov      rdx, qword ptr [rcx+0x160]
       test     rdx, rdx
       jle      SHORT G_M000_IG301
 
G_M000_IG300:                ;; offset=0x2268
       dec      rdx
       mov      qword ptr [rcx+0x160], rdx
 
G_M000_IG301:                ;; offset=0x2272
       call     G_M000_IG280
       nop      
 
G_M000_IG302:                ;; offset=0x2278
       vzeroupper 
       add      rsp, 72
       ret      
 
RWD00  	dd	00001610h ; case G_M000_IG171
       	dd	00001607h ; case G_M000_IG170
       	dd	000015FEh ; case G_M000_IG169

; Total bytes of code 8832

; Assembly listing for method Lokad.Lython.Runtime.PyDict:TryAppendBorrowedWord(System.ReadOnlySpan`1[byte],uint,System.Object,System.Numerics.BigInteger,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.Text.PyStringOps+CasedWhitespaceIteration,byref):bool:this (Instrumented Tier0)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; Instrumented Tier0 code
; rbp based frame
; partially interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 96
       lea      rbp, [rsp+0x60]
       xor      eax, eax
       mov      qword ptr [rbp-0x28], rax
       vxorps   xmm4, xmm4, xmm4
       vmovdqu  ymmword ptr [rbp-0x20], ymm4
       mov      gword ptr [rbp+0x10], rcx
       mov      bword ptr [rbp+0x18], rdx
       mov      dword ptr [rbp+0x20], r8d
       mov      gword ptr [rbp+0x28], r9
 
G_M000_IG02:                ;; offset=0x0029
       mov      rax, bword ptr [rbp+0x18]
       cmp      dword ptr [rax+0x08], 8
       jle      SHORT G_M000_IG04
       mov      rax, gword ptr [rbp+0x10]
       mov      eax, dword ptr [rax+0x4C]
       mov      rcx, gword ptr [rbp+0x10]
       mov      rcx, gword ptr [rcx+0x28]
       cmp      eax, dword ptr [rcx+0x08]
       jne      SHORT G_M000_IG06
 
G_M000_IG03:                ;; offset=0x0047
       mov      rcx, 0x7FFA03045768
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG04:                ;; offset=0x0056
       mov      rcx, 0x7FFA0304576C
       call     CORINFO_HELP_COUNTPROFILE32
       xor      eax, eax
 
G_M000_IG05:                ;; offset=0x0067
       add      rsp, 96
       pop      rbp
       ret      
 
G_M000_IG06:                ;; offset=0x006D
       mov      rcx, 0x7FFA03045770
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, gword ptr [rbp+0x38]
       mov      rdx, gword ptr [rbp+0x40]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CheckExecution(Lokad.Lython.LythonSourceSpan):this]
       mov      rax, bword ptr [rbp+0x18]
 
G_M000_IG07:                ;; offset=0x0090
       vmovdqu  xmm0, xmmword ptr [rax]
       vmovdqu  xmmword ptr [rbp-0x10], xmm0
 
G_M000_IG08:                ;; offset=0x0099
       lea      rdx, [rbp-0x10]
       mov      rcx, gword ptr [rbp+0x48]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.Text.PyStringOps+CasedWhitespaceIteration:Materialize(System.ReadOnlySpan`1[byte]):Lokad.Lython.Runtime.Text.PyString:this]
       mov      rdx, rax
       mov      rcx, bword ptr [rbp+0x50]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rax, bword ptr [rbp+0x50]
       mov      rax, gword ptr [rax]
       mov      gword ptr [rbp-0x28], rax
       mov      rax, gword ptr [rbp+0x28]
       mov      gword ptr [rsp+0x20], rax
       mov      rax, bword ptr [rbp+0x30]
 
G_M000_IG09:                ;; offset=0x00CD
       vmovdqu  xmm0, xmmword ptr [rax]
       vmovdqu  xmmword ptr [rbp-0x20], xmm0
 
G_M000_IG10:                ;; offset=0x00D6
       lea      rax, [rbp-0x20]
       mov      qword ptr [rsp+0x28], rax
       mov      r8, gword ptr [rbp-0x28]
       mov      rcx, gword ptr [rbp+0x10]
       mov      r9d, dword ptr [rbp+0x20]
       mov      edx, -1
       call     [Lokad.Lython.Runtime.PyDict:TryAccumulateAt(int,Lokad.Lython.Runtime.Text.PyString,uint,System.Object,System.Numerics.BigInteger):bool:this]
       nop      
 
G_M000_IG11:                ;; offset=0x00F7
       add      rsp, 96
       pop      rbp
       ret      
 
; Total bytes of code 253

