; Assembly listing for method Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteDictionaryLoop(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool (Instrumented Tier0)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; Instrumented Tier0 code
; rbp based frame
; fully interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 752
       lea      rbp, [rsp+0x2F0]
       vxorps   xmm4, xmm4, xmm4
       mov      rax, -624
 
G_M000_IG87:                ;; offset=0x001E
       vmovdqa  xmmword ptr [rbp+rax-0x40], xmm4
       vmovdqa  xmmword ptr [rbp+rax-0x30], xmm4
       vmovdqa  xmmword ptr [rbp+rax-0x20], xmm4
       add      rax, 48
       jne      SHORT G_M000_IG87
       mov      qword ptr [rbp-0x40], rax
       mov      bword ptr [rbp+0x10], rcx
       mov      gword ptr [rbp+0x18], rdx
       mov      gword ptr [rbp+0x20], r8
       mov      bword ptr [rbp+0x28], r9
 
G_M000_IG02:                ;; offset=0x004A
       mov      dword ptr [rbp-0x1B4], 0x3E8
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       lea      rcx, bword ptr [rax+0x20]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:get_LiveExtent():int:this]
       mov      dword ptr [rbp-0x114], eax
       mov      rcx, bword ptr [rbp+0x28]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       cmp      eax, dword ptr [rbp-0x114]
       jne      SHORT G_M000_IG04
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       lea      rcx, bword ptr [rax+0x20]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:get_HasPendingDisposals():bool:this]
       test     eax, eax
       je       SHORT G_M000_IG05
 
G_M000_IG03:                ;; offset=0x0098
       mov      rcx, 0x7FFA02D56120
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG04:                ;; offset=0x00A7
       mov      rcx, 0x7FFA02D56124
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG24
 
G_M000_IG05:                ;; offset=0x00BB
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_RequiresLocalVariableMirroring():bool:this]
       test     eax, eax
       jne      G_M000_IG11
       cmp      gword ptr [rbp+0x20], 0
       jne      SHORT G_M000_IG06
       mov      dword ptr [rbp-0x19C], 1
       jmp      SHORT G_M000_IG07
 
G_M000_IG06:                ;; offset=0x00E5
       mov      rcx, 0x7FFA02D56128
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, gword ptr [rbp+0x20]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:get_MirrorLocalStores():bool:this]
       test     eax, eax
       sete     al
       movzx    rax, al
       mov      dword ptr [rbp-0x19C], eax
 
G_M000_IG07:                ;; offset=0x010C
       cmp      dword ptr [rbp-0x19C], 0
       je       SHORT G_M000_IG08
       cmp      gword ptr [rbp+0x20], 0
       jne      SHORT G_M000_IG09
       xor      rax, rax
       mov      gword ptr [rbp-0x1A8], rax
       jmp      SHORT G_M000_IG10
 
G_M000_IG08:                ;; offset=0x0127
       mov      rcx, 0x7FFA02D5612C
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG11
 
G_M000_IG09:                ;; offset=0x0138
       mov      rcx, 0x7FFA02D56130
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, gword ptr [rbp+0x20]
       mov      rax, gword ptr [rax+0x88]
       mov      gword ptr [rbp-0x1A8], rax
 
G_M000_IG10:                ;; offset=0x0159
       mov      rcx, 0x7FFA02D56134
       call     CORINFO_HELP_COUNTPROFILE32
       cmp      gword ptr [rbp-0x1A8], 0
       sete     al
       movzx    rax, al
       mov      dword ptr [rbp-0x118], eax
       jmp      SHORT G_M000_IG12
 
G_M000_IG11:                ;; offset=0x017E
       xor      eax, eax
       mov      dword ptr [rbp-0x118], eax
 
G_M000_IG12:                ;; offset=0x0186
       movzx    rax, byte  ptr [rbp-0x118]
       mov      dword ptr [rbp-0x3C], eax
       cmp      dword ptr [rbp-0x3C], 0
       je       G_M000_IG14
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       add      rax, 32
       mov      bword ptr [rbp-0x120], rax
       mov      rcx, bword ptr [rbp+0x28]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x1BC], eax
       mov      edx, dword ptr [rbp-0x1BC]
       mov      rcx, bword ptr [rbp-0x120]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:get_Item(int):System.Object:this]
       mov      gword ptr [rbp-0x1C8], rax
       mov      rdx, gword ptr [rbp-0x1C8]
       mov      rcx, 0x7FFA02D42798
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      gword ptr [rbp-0x48], rax
       cmp      gword ptr [rbp-0x48], 0
       je       SHORT G_M000_IG15
       mov      rcx, gword ptr [rbp-0x48]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.Text.PyStringOps+CasedWhitespaceIteration:get_MemoryGovernor():Lokad.Lython.Runtime.MemoryGovernor:this]
       mov      gword ptr [rbp-0x128], rax
       mov      rcx, gword ptr [rbp+0x18]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:get_MemoryGovernor():Lokad.Lython.Runtime.MemoryGovernor:this]
       cmp      rax, gword ptr [rbp-0x128]
       je       SHORT G_M000_IG16
 
G_M000_IG13:                ;; offset=0x0223
       mov      rcx, 0x7FFA02D56138
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG14:                ;; offset=0x0232
       mov      rcx, 0x7FFA02D5613C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      eax, dword ptr [rbp-0x3C]
       mov      dword ptr [rsp+0x20], eax
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rbp+0x18]
       mov      r8, gword ptr [rbp+0x20]
       mov      r9, bword ptr [rbp+0x28]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteOrdinaryDictionaryLoop(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,bool):bool]
       mov      dword ptr [rbp-0x1B8], eax
       jmp      G_M000_IG59
 
G_M000_IG15:                ;; offset=0x0269
       mov      rcx, 0x7FFA02D56140
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG14
 
G_M000_IG16:                ;; offset=0x027A
       mov      rax, bword ptr [rbp+0x10]
       mov      eax, dword ptr [rax+0x18]
       mov      dword ptr [rbp-0x4C], eax
       mov      rcx, bword ptr [rbp+0x28]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_DictionaryLoopCallIndex():int:this]
       mov      dword ptr [rbp-0x50], eax
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_CallSites():System.Collections.Generic.IReadOnlyList`1[Lokad.Lython.Frontend.ExecutableCallSite]:this]
       mov      gword ptr [rbp-0x130], rax
       mov      rax, gword ptr [rbp-0x130]
       mov      gword ptr [rbp-0x1B0], rax
       mov      rcx, gword ptr [rbp-0x1B0]
       mov      rdx, 0x7FFA02D56148
       call     CORINFO_HELP_CLASSPROFILE32
       mov      rax, gword ptr [rbp-0x1B0]
       mov      gword ptr [rbp-0x1D0], rax
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Instructions():Lokad.Lython.Frontend.ExecutableInstruction[]:this]
       mov      ecx, dword ptr [rbp-0x50]
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG61
       mov      edx, ecx
       imul     rdx, rdx, 32
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      rcx, rax
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_CallSiteIndex():int:this]
       mov      dword ptr [rbp-0x1D4], eax
       mov      rcx, gword ptr [rbp-0x1D0]
       mov      edx, dword ptr [rbp-0x1D4]
       mov      r11, 0x7FFA02571C58
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       mov      gword ptr [rbp-0x58], rax
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Instructions():Lokad.Lython.Frontend.ExecutableInstruction[]:this]
       mov      ecx, dword ptr [rbp-0x4C]
       add      ecx, 2
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG61
       mov      edx, ecx
       imul     rdx, rdx, 32
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      bword ptr [rbp-0x60], rax
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Instructions():Lokad.Lython.Frontend.ExecutableInstruction[]:this]
       mov      ecx, dword ptr [rbp-0x50]
       inc      ecx
       cmp      ecx, dword ptr [rax+0x08]
 
G_M000_IG17:                ;; offset=0x0370
       jae      G_M000_IG61
       mov      edx, ecx
       imul     rdx, rdx, 32
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      bword ptr [rbp-0x68], rax
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Instructions():Lokad.Lython.Frontend.ExecutableInstruction[]:this]
       mov      ecx, dword ptr [rbp-0x50]
       add      ecx, 2
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG61
       mov      edx, ecx
       imul     rdx, rdx, 32
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      bword ptr [rbp-0x70], rax
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Constants():System.Object[]:this]
       mov      gword ptr [rbp-0x138], rax
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Instructions():Lokad.Lython.Frontend.ExecutableInstruction[]:this]
       mov      ecx, dword ptr [rbp-0x4C]
       add      ecx, 4
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG61
       mov      edx, ecx
       imul     rdx, rdx, 32
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      rcx, rax
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ConstantIndex():int:this]
       mov      rcx, gword ptr [rbp-0x138]
       cmp      eax, dword ptr [rcx+0x08]
       jae      G_M000_IG61
       mov      edx, eax
       lea      rcx, bword ptr [rcx+8*rdx+0x10]
       mov      rax, gword ptr [rcx]
       mov      gword ptr [rbp-0x78], rax
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Constants():System.Object[]:this]
       mov      gword ptr [rbp-0x140], rax
       mov      rcx, bword ptr [rbp-0x68]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_SecondInput():int:this]
       not      eax
       mov      rcx, gword ptr [rbp-0x140]
       cmp      eax, dword ptr [rcx+0x08]
       jae      G_M000_IG61
       mov      edx, eax
 
G_M000_IG18:                ;; offset=0x044C
       lea      rcx, bword ptr [rcx+8*rdx+0x10]
       mov      rax, gword ptr [rcx]
       mov      gword ptr [rbp-0x1E0], rax
       mov      rdx, gword ptr [rbp-0x1E0]
       mov      rcx, 0x7FFA02A1B3F0
       call     [CORINFO_HELP_UNBOX]
 
G_M000_IG19:                ;; offset=0x0472
       vmovdqu  xmm0, xmmword ptr [rax]
       vmovdqu  xmmword ptr [rbp-0x88], xmm0
 
G_M000_IG20:                ;; offset=0x047E
       mov      rax, bword ptr [rbp+0x10]
       mov      rax, gword ptr [rax+0x08]
       mov      gword ptr [rbp-0x148], rax
       mov      rax, gword ptr [rbp-0x148]
       mov      gword ptr [rbp-0x2B0], rax
       mov      rcx, bword ptr [rbp-0x70]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_SecondInput():int:this]
       mov      rdx, gword ptr [rbp-0x2B0]
       cmp      eax, dword ptr [rdx+0x08]
       jae      G_M000_IG61
       mov      ecx, eax
       imul     rcx, rcx, 16
       lea      rcx, bword ptr [rdx+rcx+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Object():System.Object:this]
       mov      gword ptr [rbp-0x1E8], rax
       mov      rdx, gword ptr [rbp-0x1E8]
       mov      rcx, 0x7FFA02B1FD78
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      gword ptr [rbp-0x90], rax
       cmp      gword ptr [rbp-0x90], 0
       je       SHORT G_M000_IG22
       mov      rcx, gword ptr [rbp-0x90]
       mov      rdx, gword ptr [rbp+0x18]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.PyDict:CanAccumulateBorrowedWords(Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG23
 
G_M000_IG21:                ;; offset=0x050C
       mov      rcx, 0x7FFA02D56250
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG22:                ;; offset=0x051B
       mov      rcx, 0x7FFA02D56254
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG24
 
G_M000_IG23:                ;; offset=0x052F
       mov      eax, dword ptr [rbp-0x50]
       add      eax, 3
       mov      dword ptr [rbp-0x94], eax
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Instructions():Lokad.Lython.Frontend.ExecutableInstruction[]:this]
       mov      ecx, dword ptr [rbp-0x94]
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG61
       mov      edx, ecx
       imul     rdx, rdx, 32
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      bword ptr [rbp-0xA0], rax
       mov      rcx, bword ptr [rbp-0xA0]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_OpCode():int:this]
       cmp      eax, 47
       sete     al
       movzx    rax, al
       mov      dword ptr [rbp-0xA4], eax
       xor      eax, eax
       mov      qword ptr [rbp-0xB0], rax
       xor      eax, eax
       mov      qword ptr [rbp-0xB8], rax
       cmp      dword ptr [rbp-0xA4], 0
       je       G_M000_IG29
       mov      rax, bword ptr [rbp+0x10]
       mov      rax, gword ptr [rax+0x08]
       mov      gword ptr [rbp-0x190], rax
       mov      rcx, bword ptr [rbp-0xA0]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      rcx, gword ptr [rbp-0x190]
       cmp      eax, dword ptr [rcx+0x08]
       jae      G_M000_IG61
       mov      edx, eax
       imul     rdx, rdx, 16
       lea      rcx, bword ptr [rcx+rdx+0x10]
       mov      bword ptr [rbp-0x1F0], rcx
       mov      rcx, bword ptr [rbp-0x1F0]
       lea      rdx, [rbp-0xB0]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryReadHistogramTotal(byref,byref):bool]
       test     eax, eax
       jne      SHORT G_M000_IG26
       mov      rcx, 0x7FFA02D56258
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG24:                ;; offset=0x060B
       xor      eax, eax
 
G_M000_IG25:                ;; offset=0x060D
       add      rsp, 752
       pop      rbp
       ret      
 
G_M000_IG26:                ;; offset=0x0616
       mov      rcx, 0x7FFA02D5625C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Constants():System.Object[]:this]
       mov      gword ptr [rbp-0x198], rax
       mov      rcx, bword ptr [rbp-0xA0]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_SecondInput():int:this]
       not      eax
       mov      rcx, gword ptr [rbp-0x198]
       cmp      eax, dword ptr [rcx+0x08]
       jae      G_M000_IG61
       mov      edx, eax
       lea      rcx, bword ptr [rcx+8*rdx+0x10]
       mov      rax, gword ptr [rcx]
       mov      gword ptr [rbp-0x1F8], rax
       mov      rdx, gword ptr [rbp-0x1F8]
       mov      rcx, 0x7FFA02A1B3F0
       call     [CORINFO_HELP_UNBOX]
 
G_M000_IG27:                ;; offset=0x0682
       vmovdqu  xmm0, xmmword ptr [rax]
       vmovdqu  xmmword ptr [rbp-0x208], xmm0
 
G_M000_IG28:                ;; offset=0x068E
       lea      rcx, [rbp-0x208]
       call     [System.Numerics.BigInteger:op_Explicit(System.Numerics.BigInteger):long]
       mov      qword ptr [rbp-0xB8], rax
 
G_M000_IG29:                ;; offset=0x06A2
       vxorps   xmm0, xmm0, xmm0
       vmovdqu  xmmword ptr [rbp-0xC8], xmm0
       xor      rax, rax
       mov      gword ptr [rbp-0xD0], rax
       xor      eax, eax
       mov      dword ptr [rbp-0xD4], eax
       xor      eax, eax
       mov      dword ptr [rbp-0xD8], eax
       xor      eax, eax
       mov      dword ptr [rbp-0xDC], eax
 
G_M000_IG30:                ;; offset=0x06CF
       mov      eax, dword ptr [rbp-0x1B4]
       dec      eax
       mov      dword ptr [rbp-0x1B4], eax
       cmp      dword ptr [rbp-0x1B4], 0
       jg       SHORT G_M000_IG32
 
G_M000_IG31:                ;; offset=0x06E6
       lea      rcx, [rbp-0x1B4]
       mov      edx, 496
       call     CORINFO_HELP_PATCHPOINT
       jmp      rax
 
G_M000_IG32:                ;; offset=0x06F9
       lea      rdx, [rbp-0xF0]
       lea      r8, [rbp-0xF8]
       mov      rcx, gword ptr [rbp-0x48]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.Text.PyStringOps+CasedWhitespaceIteration:TryReadWord(byref,byref):bool:this]
       test     eax, eax
       je       G_M000_IG54
 
G_M000_IG33:                ;; offset=0x071B
       vmovdqu  xmm0, xmmword ptr [rbp-0xF0]
       vmovdqu  xmmword ptr [rbp-0xC8], xmm0
 
G_M000_IG34:                ;; offset=0x072B
       mov      rax, gword ptr [rbp-0xF8]
       mov      gword ptr [rbp-0xD0], rax
       cmp      dword ptr [rbp-0xD8], 0
       jne      SHORT G_M000_IG35
       mov      rcx, bword ptr [rbp-0x60]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x210], rax
       mov      rdx, gword ptr [rbp-0x210]
       mov      rcx, gword ptr [rbp+0x18]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CheckExecution(Lokad.Lython.LythonSourceSpan):this]
       mov      rax, bword ptr [rbp+0x10]
       mov      ecx, dword ptr [rbp-0x50]
       mov      dword ptr [rax+0x18], ecx
       mov      rcx, gword ptr [rbp-0x58]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_CallSpan():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x218], rax
       mov      rdx, gword ptr [rbp-0x218]
       mov      rcx, gword ptr [rbp+0x18]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:EnterInterpreterFrame(Lokad.Lython.LythonSourceSpan):this]
       mov      dword ptr [rbp-0xD8], 1
       jmp      SHORT G_M000_IG36
 
G_M000_IG35:                ;; offset=0x07A2
       mov      rcx, 0x7FFA02D56260
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x10]
       mov      ecx, dword ptr [rbp-0x50]
       mov      dword ptr [rax+0x18], ecx
 
G_M000_IG36:                ;; offset=0x07BB
       cmp      gword ptr [rbp-0xF8], 0
       jne      G_M000_IG45
 
G_M000_IG37:                ;; offset=0x07C9
       vmovdqu  xmm0, xmmword ptr [rbp-0xF0]
       vmovdqu  xmmword ptr [rbp-0x160], xmm0
 
G_M000_IG38:                ;; offset=0x07D9
       vmovdqu  xmm0, xmmword ptr [rbp-0x160]
       vmovdqu  xmmword ptr [rbp-0x228], xmm0
 
G_M000_IG39:                ;; offset=0x07E9
       vmovdqu  xmm0, xmmword ptr [rbp-0x88]
       vmovdqu  xmmword ptr [rbp-0x238], xmm0
 
G_M000_IG40:                ;; offset=0x07F9
       mov      rcx, gword ptr [rbp-0x58]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_CallSpan():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x240], rax
       lea      rax, [rbp-0x108]
       mov      qword ptr [rsp+0x30], rax
       mov      rax, gword ptr [rbp-0x240]
       mov      gword ptr [rsp+0x28], rax
       lea      rdx, [rbp-0x228]
       lea      r9, [rbp-0x238]
       mov      r8, gword ptr [rbp-0x78]
       mov      rax, gword ptr [rbp+0x18]
       mov      gword ptr [rsp+0x20], rax
       mov      rcx, gword ptr [rbp-0x90]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.PyDict:TryAccumulateBorrowedWord(System.ReadOnlySpan`1[byte],System.Object,System.Numerics.BigInteger,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,byref):bool:this]
       mov      dword ptr [rbp-0xFC], eax
       lea      rcx, [rbp-0x108]
       call     [System.Nullable`1[uint]:get_HasValue():bool:this]
       test     eax, eax
       je       G_M000_IG48
       mov      rcx, 0x7FFA02D56264
       call     CORINFO_HELP_COUNTPROFILE32
       lea      rcx, [rbp-0x108]
       call     [System.Nullable`1[uint]:GetValueOrDefault():uint:this]
       mov      dword ptr [rbp-0x10C], eax
       mov      rcx, gword ptr [rbp-0x58]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_CallSpan():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x248], rax
       mov      rdx, gword ptr [rbp-0x248]
       mov      rcx, gword ptr [rbp+0x18]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CheckExecution(Lokad.Lython.LythonSourceSpan):this]
 
G_M000_IG41:                ;; offset=0x08B1
       vmovdqu  xmm0, xmmword ptr [rbp-0xF0]
       vmovdqu  xmmword ptr [rbp-0x258], xmm0
 
G_M000_IG42:                ;; offset=0x08C1
       lea      rdx, [rbp-0x258]
       mov      rcx, gword ptr [rbp-0x48]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.Text.PyStringOps+CasedWhitespaceIteration:Materialize(System.ReadOnlySpan`1[byte]):Lokad.Lython.Runtime.Text.PyString:this]
       mov      gword ptr [rbp-0xD0], rax
 
G_M000_IG43:                ;; offset=0x08DB
       vmovdqu  xmm0, xmmword ptr [rbp-0x88]
       vmovdqu  xmmword ptr [rbp-0x268], xmm0
 
G_M000_IG44:                ;; offset=0x08EB
       lea      rax, [rbp-0x268]
       mov      qword ptr [rsp+0x20], rax
       mov      rdx, gword ptr [rbp-0xD0]
       mov      r8d, dword ptr [rbp-0x10C]
       mov      r9, gword ptr [rbp-0x78]
       mov      rcx, gword ptr [rbp-0x90]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.PyDict:TryAppendBorrowedWord(Lokad.Lython.Runtime.Text.PyString,uint,System.Object,System.Numerics.BigInteger):bool:this]
       mov      dword ptr [rbp-0xFC], eax
       jmp      SHORT G_M000_IG48
 
G_M000_IG45:                ;; offset=0x0920
       mov      rcx, 0x7FFA02D56268
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, gword ptr [rbp-0xF8]
       mov      gword ptr [rbp-0x150], rax
 
G_M000_IG46:                ;; offset=0x093D
       vmovdqu  xmm0, xmmword ptr [rbp-0x88]
       vmovdqu  xmmword ptr [rbp-0x278], xmm0
 
G_M000_IG47:                ;; offset=0x094D
       mov      rcx, gword ptr [rbp-0x58]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_CallSpan():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x280], rax
       mov      rax, gword ptr [rbp-0x280]
       mov      gword ptr [rsp+0x28], rax
       lea      r9, [rbp-0x278]
       mov      r8, gword ptr [rbp-0x78]
       mov      rdx, gword ptr [rbp-0x150]
       mov      rax, gword ptr [rbp+0x18]
       mov      gword ptr [rsp+0x20], rax
       mov      rcx, gword ptr [rbp-0x90]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.PyDict:TryAccumulateWithoutAdmission(Lokad.Lython.Runtime.Text.PyString,System.Object,System.Numerics.BigInteger,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):bool:this]
       mov      dword ptr [rbp-0xFC], eax
 
G_M000_IG48:                ;; offset=0x099C
       cmp      dword ptr [rbp-0xFC], 0
       jne      SHORT G_M000_IG49
       mov      eax, dword ptr [rbp-0x4C]
       add      eax, 2
       mov      rcx, bword ptr [rbp+0x10]
       mov      dword ptr [rcx+0x18], eax
       mov      dword ptr [rbp-0x110], 1
       jmp      G_M000_IG56
 
G_M000_IG49:                ;; offset=0x09C1
       cmp      dword ptr [rbp-0xA4], 0
       je       G_M000_IG53
       mov      rax, qword ptr [rbp-0xB0]
       add      rax, qword ptr [rbp-0xB8]
       mov      qword ptr [rbp-0xB0], rax
       mov      dword ptr [rbp-0xD4], 1
       mov      rax, 0xFF80000000000000
       cmp      qword ptr [rbp-0xB0], rax
       jl       SHORT G_M000_IG51
       mov      rax, 0x80000000000000
       cmp      qword ptr [rbp-0xB0], rax
       jl       SHORT G_M000_IG52
 
G_M000_IG50:                ;; offset=0x0A13
       mov      rcx, 0x7FFA02D5626C
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG51:                ;; offset=0x0A22
       mov      rcx, 0x7FFA02D56270
       call     CORINFO_HELP_COUNTPROFILE32
       mov      eax, dword ptr [rbp-0x94]
       add      eax, 2
       mov      rcx, bword ptr [rbp+0x10]
       mov      dword ptr [rcx+0x18], eax
       mov      dword ptr [rbp-0x110], 1
       jmp      G_M000_IG57
 
G_M000_IG52:                ;; offset=0x0A50
       mov      rcx, 0x7FFA02D56274
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG53:                ;; offset=0x0A5F
       mov      rcx, 0x7FFA02D56278
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x10]
       mov      ecx, dword ptr [rbp-0x4C]
       mov      dword ptr [rax+0x18], ecx
       mov      rcx, bword ptr [rbp+0x28]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x288], rax
       mov      rdx, gword ptr [rbp-0x288]
       mov      rcx, gword ptr [rbp+0x18]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CheckExecution(Lokad.Lython.LythonSourceSpan):this]
       jmp      G_M000_IG30
 
G_M000_IG54:                ;; offset=0x0AA1
       mov      rcx, 0x7FFA02D5627C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0xDC], 1
       mov      rcx, bword ptr [rbp+0x28]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_TargetIndex():int:this]
       mov      rcx, bword ptr [rbp+0x10]
       mov      dword ptr [rcx+0x18], eax
       mov      dword ptr [rbp-0x110], 1
 
G_M000_IG55:                ;; offset=0x0AD5
       call     G_M000_IG81
       jmp      SHORT G_M000_IG58
 
G_M000_IG56:                ;; offset=0x0ADC
       call     G_M000_IG81
       jmp      SHORT G_M000_IG58
 
G_M000_IG57:                ;; offset=0x0AE3
       call     G_M000_IG81
       nop      
 
G_M000_IG58:                ;; offset=0x0AE9
       mov      rcx, 0x7FFA02D562A4
       call     CORINFO_HELP_COUNTPROFILE32
       mov      eax, dword ptr [rbp-0x110]
       mov      dword ptr [rbp-0x1B8], eax
 
G_M000_IG59:                ;; offset=0x0B04
       movzx    rax, byte  ptr [rbp-0x1B8]
 
G_M000_IG60:                ;; offset=0x0B0B
       add      rsp, 752
       pop      rbp
       ret      
 
G_M000_IG61:                ;; offset=0x0B14
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG62:                ;; offset=0x0B1A
       sub      rsp, 56
 
G_M000_IG63:                ;; offset=0x0B1E
       cmp      dword ptr [rbp-0xD4], 0
       je       SHORT G_M000_IG64
       mov      rcx, 0x7FFA02D56290
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x10]
       mov      rax, gword ptr [rax+0x08]
       mov      gword ptr [rbp-0x188], rax
       mov      rcx, bword ptr [rbp-0xA0]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      rcx, gword ptr [rbp-0x188]
       cmp      eax, dword ptr [rcx+0x08]
       jae      G_M000_IG67
       mov      edx, eax
       imul     rdx, rdx, 16
       lea      rcx, bword ptr [rcx+rdx+0x10]
       mov      bword ptr [rbp-0x2A0], rcx
       mov      rcx, bword ptr [rbp-0x2A0]
       mov      rdx, qword ptr [rbp-0xB0]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:SetInteger(long):this]
 
G_M000_IG64:                ;; offset=0x0B88
       cmp      dword ptr [rbp-0xDC], 0
       je       SHORT G_M000_IG65
       mov      rcx, 0x7FFA02D56294
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       add      rax, 32
       mov      bword ptr [rbp-0x180], rax
       mov      rcx, bword ptr [rbp+0x28]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x2A4], eax
       mov      edx, dword ptr [rbp-0x2A4]
       mov      rcx, bword ptr [rbp-0x180]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
 
G_M000_IG65:                ;; offset=0x0BD8
       mov      rcx, 0x7FFA02D56298
       call     CORINFO_HELP_COUNTPROFILE32
       nop      
 
G_M000_IG66:                ;; offset=0x0BE8
       add      rsp, 56
       ret      
 
G_M000_IG67:                ;; offset=0x0BED
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG68:                ;; offset=0x0BF3
       sub      rsp, 56
 
G_M000_IG69:                ;; offset=0x0BF7
       cmp      gword ptr [rbp-0xD0], 0
       jne      SHORT G_M000_IG73
       lea      rcx, [rbp-0xC8]
       call     [System.ReadOnlySpan`1[byte]:get_IsEmpty():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG70
       jmp      SHORT G_M000_IG72
 
G_M000_IG70:                ;; offset=0x0C14
       mov      rcx, 0x7FFA02D56284
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG77
 
G_M000_IG71:                ;; offset=0x0C28
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG72:                ;; offset=0x0C2E
       mov      rcx, 0x7FFA02D56288
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG73:                ;; offset=0x0C3D
       mov      rax, bword ptr [rbp+0x10]
       mov      rax, gword ptr [rax+0x08]
       mov      gword ptr [rbp-0x168], rax
       mov      rcx, bword ptr [rbp-0x70]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ThirdInput():int:this]
       mov      rcx, gword ptr [rbp-0x168]
       cmp      eax, dword ptr [rcx+0x08]
       jae      SHORT G_M000_IG71
       mov      edx, eax
       imul     rdx, rdx, 16
       lea      rcx, bword ptr [rcx+rdx+0x10]
       mov      bword ptr [rbp-0x170], rcx
       mov      rax, gword ptr [rbp-0xD0]
       mov      gword ptr [rbp-0x178], rax
       cmp      gword ptr [rbp-0xD0], 0
       jne      SHORT G_M000_IG76
       mov      rcx, 0x7FFA02D5628C
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG74:                ;; offset=0x0C9B
       vmovdqu  xmm0, xmmword ptr [rbp-0xC8]
       vmovdqu  xmmword ptr [rbp-0x298], xmm0
 
G_M000_IG75:                ;; offset=0x0CAB
       lea      rdx, [rbp-0x298]
       mov      rcx, gword ptr [rbp-0x48]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.Text.PyStringOps+CasedWhitespaceIteration:Materialize(System.ReadOnlySpan`1[byte]):Lokad.Lython.Runtime.Text.PyString:this]
       mov      gword ptr [rbp-0x178], rax
 
G_M000_IG76:                ;; offset=0x0CC5
       mov      rcx, bword ptr [rbp-0x170]
       mov      rdx, gword ptr [rbp-0x178]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:set_Object(System.Object):this]
 
G_M000_IG77:                ;; offset=0x0CD9
       nop      
 
G_M000_IG78:                ;; offset=0x0CDA
       call     G_M000_IG62
       nop      
 
G_M000_IG79:                ;; offset=0x0CE0
       mov      rcx, 0x7FFA02D5629C
       call     CORINFO_HELP_COUNTPROFILE32
       nop      
 
G_M000_IG80:                ;; offset=0x0CF0
       add      rsp, 56
       ret      
 
G_M000_IG81:                ;; offset=0x0CF5
       sub      rsp, 56
 
G_M000_IG82:                ;; offset=0x0CF9
       cmp      dword ptr [rbp-0xD8], 0
       je       SHORT G_M000_IG83
       mov      rcx, 0x7FFA02D56280
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, gword ptr [rbp+0x18]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:LeaveInterpreterFrame():this]
 
G_M000_IG83:                ;; offset=0x0D1D
       nop      
 
G_M000_IG84:                ;; offset=0x0D1E
       call     G_M000_IG68
       nop      
 
G_M000_IG85:                ;; offset=0x0D24
       mov      rcx, 0x7FFA02D562A0
       call     CORINFO_HELP_COUNTPROFILE32
       nop      
 
G_M000_IG86:                ;; offset=0x0D34
       add      rsp, 56
       ret      
 
; Total bytes of code 3385

; Assembly listing for method Lokad.Lython.Runtime.PyDict:TryAccumulateBorrowedWord(System.ReadOnlySpan`1[byte],System.Object,System.Numerics.BigInteger,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,byref):bool:this (Tier0)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; Tier0 code
; rbp based frame
; partially interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 144
       lea      rbp, [rsp+0x90]
       xor      eax, eax
       mov      qword ptr [rbp-0x58], rax
       vxorps   xmm4, xmm4, xmm4
       vmovdqu  ymmword ptr [rbp-0x50], ymm4
       vmovdqu  ymmword ptr [rbp-0x30], ymm4
       vmovdqa  xmmword ptr [rbp-0x10], xmm4
       mov      gword ptr [rbp+0x10], rcx
       mov      bword ptr [rbp+0x18], rdx
       mov      gword ptr [rbp+0x20], r8
       mov      bword ptr [rbp+0x28], r9
 
G_M000_IG02:                ;; offset=0x0039
       mov      rcx, gword ptr [rbp+0x30]
       mov      rdx, gword ptr [rbp+0x38]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CheckExecution(Lokad.Lython.LythonSourceSpan):this]
       mov      rax, gword ptr [rbp+0x10]
       mov      rax, gword ptr [rax+0x28]
       mov      gword ptr [rbp-0x08], rax
       mov      rax, gword ptr [rbp+0x10]
       mov      eax, dword ptr [rax+0x4C]
       mov      dword ptr [rbp-0x3C], eax
       mov      rax, bword ptr [rbp+0x18]
 
G_M000_IG03:                ;; offset=0x0063
       vmovdqu  xmm0, xmmword ptr [rax]
       vmovdqu  xmmword ptr [rbp-0x38], xmm0
 
G_M000_IG04:                ;; offset=0x006C
       mov      rax, gword ptr [rbp+0x38]
       mov      gword ptr [rsp+0x20], rax
       lea      rax, [rbp-0x18]
       mov      qword ptr [rsp+0x28], rax
       mov      edx, dword ptr [rbp-0x3C]
       lea      r8, [rbp-0x38]
       mov      rcx, gword ptr [rbp-0x08]
       mov      r9, gword ptr [rbp+0x30]
       call     [Lokad.Lython.Runtime.PyDict:FindNativeTextIndex(Lokad.Lython.Runtime.PyDict+NativeKey[],int,System.ReadOnlySpan`1[byte],Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,byref):int]
       mov      dword ptr [rbp-0x0C], eax
       mov      rax, bword ptr [rbp+0x40]
       xor      ecx, ecx
       mov      qword ptr [rax], rcx
       cmp      dword ptr [rbp-0x0C], 0
       jge      SHORT G_M000_IG07
       mov      rax, bword ptr [rbp+0x18]
       cmp      dword ptr [rax+0x08], 8
       jle      SHORT G_M000_IG05
       mov      rax, gword ptr [rbp+0x10]
       mov      eax, dword ptr [rax+0x4C]
       mov      rcx, gword ptr [rbp-0x08]
       cmp      eax, dword ptr [rcx+0x08]
       jge      SHORT G_M000_IG05
       xor      eax, eax
       mov      qword ptr [rbp-0x28], rax
       lea      rcx, [rbp-0x28]
       mov      edx, dword ptr [rbp-0x18]
       call     [System.Nullable`1[uint]:.ctor(uint):this]
       mov      rax, bword ptr [rbp+0x40]
       mov      rcx, qword ptr [rbp-0x28]
       mov      qword ptr [rax], rcx
 
G_M000_IG05:                ;; offset=0x00DD
       xor      eax, eax
 
G_M000_IG06:                ;; offset=0x00DF
       add      rsp, 144
       pop      rbp
       ret      
 
G_M000_IG07:                ;; offset=0x00E8
       mov      rax, gword ptr [rbp-0x08]
       mov      ecx, dword ptr [rbp-0x0C]
       cmp      ecx, dword ptr [rax+0x08]
       jae      SHORT G_M000_IG11
       mov      edx, ecx
       imul     rdx, rdx, 40
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      bword ptr [rbp-0x20], rax
       mov      rax, bword ptr [rbp-0x20]
       mov      rdx, gword ptr [rax]
       mov      rcx, 0x7FFA02A91030
       call     [CORINFO_HELP_CHKCASTCLASS]
       mov      gword ptr [rbp-0x58], rax
       mov      rax, bword ptr [rbp-0x20]
       mov      eax, dword ptr [rax+0x18]
       mov      dword ptr [rbp-0x5C], eax
       mov      rax, gword ptr [rbp+0x20]
       mov      gword ptr [rsp+0x20], rax
       mov      rax, bword ptr [rbp+0x28]
 
G_M000_IG08:                ;; offset=0x0135
       vmovdqu  xmm0, xmmword ptr [rax]
       vmovdqu  xmmword ptr [rbp-0x50], xmm0
 
G_M000_IG09:                ;; offset=0x013E
       mov      r8, gword ptr [rbp-0x58]
       mov      r9d, dword ptr [rbp-0x5C]
       lea      rax, [rbp-0x50]
       mov      qword ptr [rsp+0x28], rax
       mov      edx, dword ptr [rbp-0x0C]
       mov      rcx, gword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.PyDict:TryAccumulateAt(int,Lokad.Lython.Runtime.Text.PyString,uint,System.Object,System.Numerics.BigInteger):bool:this]
       nop      
 
G_M000_IG10:                ;; offset=0x015D
       add      rsp, 144
       pop      rbp
       ret      
 
G_M000_IG11:                ;; offset=0x0166
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
; Total bytes of code 364

; Assembly listing for method Lokad.Lython.Runtime.PyDict:FindNativeTextIndex(Lokad.Lython.Runtime.PyDict+NativeKey[],int,System.ReadOnlySpan`1[byte],Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,byref):int (Instrumented Tier0)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; Instrumented Tier0 code
; rbp based frame
; fully interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 256
       lea      rbp, [rsp+0x100]
       xor      eax, eax
       mov      qword ptr [rbp-0xD8], rax
       vxorps   xmm4, xmm4, xmm4
       vmovdqu  ymmword ptr [rbp-0xD0], ymm4
       vmovdqu  ymmword ptr [rbp-0xB0], ymm4
       vmovdqu  ymmword ptr [rbp-0x90], ymm4
       vmovdqu  ymmword ptr [rbp-0x70], ymm4
       vmovdqa  xmmword ptr [rbp-0x50], xmm4
       mov      qword ptr [rbp-0x40], rax
       mov      gword ptr [rbp+0x10], rcx
       mov      dword ptr [rbp+0x18], edx
       mov      bword ptr [rbp+0x20], r8
       mov      gword ptr [rbp+0x28], r9
 
G_M000_IG02:                ;; offset=0x0052
       mov      dword ptr [rbp-0x94], 0x3E8
       cmp      dword ptr [rbp+0x18], 4
       jg       G_M000_IG15
       mov      rax, bword ptr [rbp+0x20]
       cmp      dword ptr [rax+0x08], 8
       jg       SHORT G_M000_IG03
       mov      rax, bword ptr [rbp+0x38]
       xor      ecx, ecx
       mov      dword ptr [rax], ecx
       xor      eax, eax
       mov      dword ptr [rbp-0x3C], eax
       jmp      G_M000_IG12
 
G_M000_IG03:                ;; offset=0x0082
       mov      rcx, 0x7FFA02D564C0
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG15
 
G_M000_IG04:                ;; offset=0x0096
       mov      rax, gword ptr [rbp+0x10]
       mov      ecx, dword ptr [rbp-0x3C]
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG34
       mov      edx, ecx
       imul     rdx, rdx, 40
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      rdx, gword ptr [rax]
       mov      rcx, 0x7FFA02A91030
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      gword ptr [rbp-0x48], rax
       cmp      gword ptr [rbp-0x48], 0
       je       G_M000_IG11
       mov      rax, bword ptr [rbp+0x20]
 
G_M000_IG05:                ;; offset=0x00D7
       vmovdqu  xmm0, xmmword ptr [rax]
       vmovdqu  xmmword ptr [rbp-0x80], xmm0
 
G_M000_IG06:                ;; offset=0x00E0
       lea      rdx, [rbp-0x90]
       mov      rcx, gword ptr [rbp-0x48]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.Text.PyString:get_Utf8Span():System.ReadOnlySpan`1[byte]:this]
 
G_M000_IG07:                ;; offset=0x00F3
       vmovdqu  xmm0, xmmword ptr [rbp-0x80]
       vmovdqu  xmmword ptr [rbp-0xA8], xmm0
 
G_M000_IG08:                ;; offset=0x0100
       vmovdqu  xmm0, xmmword ptr [rbp-0x90]
       vmovdqu  xmmword ptr [rbp-0xB8], xmm0
 
G_M000_IG09:                ;; offset=0x0110
       lea      rcx, [rbp-0xA8]
       lea      rdx, [rbp-0xB8]
       call     [System.MemoryExtensions:SequenceEqual[byte](System.ReadOnlySpan`1[byte],System.ReadOnlySpan`1[byte]):bool]
       test     eax, eax
       je       SHORT G_M000_IG10
       mov      rcx, 0x7FFA02D564C4
       call     CORINFO_HELP_COUNTPROFILE32
       mov      eax, dword ptr [rbp-0x3C]
       mov      dword ptr [rbp-0x98], eax
       jmp      G_M000_IG32
 
G_M000_IG10:                ;; offset=0x0145
       mov      rcx, 0x7FFA02D564C8
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG11:                ;; offset=0x0154
       mov      rcx, 0x7FFA02D564CC
       call     CORINFO_HELP_COUNTPROFILE32
       mov      eax, dword ptr [rbp-0x3C]
       inc      eax
       mov      dword ptr [rbp-0x3C], eax
 
G_M000_IG12:                ;; offset=0x016B
       mov      eax, dword ptr [rbp-0x94]
       dec      eax
       mov      dword ptr [rbp-0x94], eax
       cmp      dword ptr [rbp-0x94], 0
       jg       SHORT G_M000_IG14
 
G_M000_IG13:                ;; offset=0x0182
       lea      rcx, [rbp-0x94]
       mov      edx, 63
       call     CORINFO_HELP_PATCHPOINT
       jmp      rax
 
G_M000_IG14:                ;; offset=0x0195
       mov      eax, dword ptr [rbp-0x3C]
       cmp      eax, dword ptr [rbp+0x18]
       jl       G_M000_IG04
       mov      rcx, 0x7FFA02D564D0
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG30
 
G_M000_IG15:                ;; offset=0x01B5
       mov      rax, bword ptr [rbp+0x20]
 
G_M000_IG16:                ;; offset=0x01B9
       vmovdqu  xmm0, xmmword ptr [rax]
       vmovdqu  xmmword ptr [rbp-0x70], xmm0
 
G_M000_IG17:                ;; offset=0x01C2
       xor      eax, eax
       mov      gword ptr [rbp-0x50], rax
 
G_M000_IG18:                ;; offset=0x01C8
       vmovdqu  xmm0, xmmword ptr [rbp-0x70]
       vmovdqu  xmmword ptr [rbp-0xC8], xmm0
 
G_M000_IG19:                ;; offset=0x01D5
       lea      rcx, [rbp-0xC8]
       mov      rdx, gword ptr [rbp+0x28]
       mov      r8, gword ptr [rbp+0x30]
       mov      r9, gword ptr [rbp-0x50]
       call     [Lokad.Lython.Runtime.Text.PyString:HashUtf8(System.ReadOnlySpan`1[byte],Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,System.Threading.CancellationToken):int]
       mov      ecx, eax
       call     [Lokad.Lython.Runtime.PyValueComparer:NormalizeHash(int):int]
       mov      ecx, eax
       call     [Lokad.Lython.Runtime.PyDict:MixNativeHash(int):uint]
       mov      rcx, bword ptr [rbp+0x38]
       mov      dword ptr [rcx], eax
       cmp      dword ptr [rbp+0x18], 0
       jne      SHORT G_M000_IG20
       mov      rcx, 0x7FFA02D564D4
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG30
 
G_M000_IG20:                ;; offset=0x021E
       mov      rax, gword ptr [rbp+0x10]
       mov      edx, dword ptr [rax+0x08]
       mov      rax, bword ptr [rbp+0x38]
       mov      ecx, dword ptr [rax]
       call     [Lokad.Lython.Runtime.PyDict:NativeBucket(uint,int):int]
       mov      rcx, gword ptr [rbp+0x10]
       cmp      eax, dword ptr [rcx+0x08]
       jae      G_M000_IG34
       mov      edx, eax
       imul     rdx, rdx, 40
       lea      rcx, bword ptr [rcx+rdx+0x10]
       mov      eax, dword ptr [rcx+0x20]
       dec      eax
       mov      dword ptr [rbp-0x54], eax
       jmp      G_M000_IG27
 
G_M000_IG21:                ;; offset=0x0256
       mov      rcx, gword ptr [rbp+0x28]
       mov      rdx, gword ptr [rbp+0x30]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CheckExecution(Lokad.Lython.LythonSourceSpan):this]
       mov      rax, gword ptr [rbp+0x10]
       mov      ecx, dword ptr [rbp-0x54]
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG34
       mov      edx, ecx
       imul     rdx, rdx, 40
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      eax, dword ptr [rax+0x18]
       mov      rcx, bword ptr [rbp+0x38]
       cmp      eax, dword ptr [rcx]
       jne      G_M000_IG26
       mov      rax, gword ptr [rbp+0x10]
       mov      ecx, dword ptr [rbp-0x54]
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG34
       mov      edx, ecx
       imul     rdx, rdx, 40
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      rdx, gword ptr [rax]
       mov      rcx, 0x7FFA02A91030
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      gword ptr [rbp-0x60], rax
       cmp      gword ptr [rbp-0x60], 0
       je       SHORT G_M000_IG25
       mov      rax, bword ptr [rbp+0x20]
 
G_M000_IG22:                ;; offset=0x02CD
       vmovdqu  xmm0, xmmword ptr [rax]
       vmovdqu  xmmword ptr [rbp-0xD8], xmm0
 
G_M000_IG23:                ;; offset=0x02D9
       lea      rdx, [rbp-0xD8]
       mov      rcx, gword ptr [rbp-0x60]
       mov      r8, gword ptr [rbp+0x28]
       mov      r9, gword ptr [rbp+0x30]
       call     [Lokad.Lython.Runtime.PyDict:EqualNativeText(Lokad.Lython.Runtime.Text.PyString,System.ReadOnlySpan`1[byte],Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):bool]
       test     eax, eax
       je       SHORT G_M000_IG24
       mov      rcx, 0x7FFA02D564D8
       call     CORINFO_HELP_COUNTPROFILE32
       mov      eax, dword ptr [rbp-0x54]
       mov      dword ptr [rbp-0x98], eax
       jmp      G_M000_IG32
 
G_M000_IG24:                ;; offset=0x0313
       mov      rcx, 0x7FFA02D564DC
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG26
 
G_M000_IG25:                ;; offset=0x0324
       mov      rcx, 0x7FFA02D564E0
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG26:                ;; offset=0x0333
       mov      rcx, 0x7FFA02D564E4
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, gword ptr [rbp+0x10]
       mov      ecx, dword ptr [rbp-0x54]
       cmp      ecx, dword ptr [rax+0x08]
       jae      SHORT G_M000_IG34
       mov      edx, ecx
       imul     rdx, rdx, 40
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      eax, dword ptr [rax+0x1C]
       dec      eax
       mov      dword ptr [rbp-0x54], eax
 
G_M000_IG27:                ;; offset=0x0361
       mov      eax, dword ptr [rbp-0x94]
       dec      eax
       mov      dword ptr [rbp-0x94], eax
       cmp      dword ptr [rbp-0x94], 0
       jg       SHORT G_M000_IG29
 
G_M000_IG28:                ;; offset=0x0378
       lea      rcx, [rbp-0x94]
       mov      edx, 210
       call     CORINFO_HELP_PATCHPOINT
       jmp      rax
 
G_M000_IG29:                ;; offset=0x038B
       cmp      dword ptr [rbp-0x54], 0
       jge      G_M000_IG21
       mov      rcx, 0x7FFA02D564E8
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG30:                ;; offset=0x03A4
       mov      eax, -1
 
G_M000_IG31:                ;; offset=0x03A9
       add      rsp, 256
       pop      rbp
       ret      
 
G_M000_IG32:                ;; offset=0x03B2
       mov      eax, dword ptr [rbp-0x98]
 
G_M000_IG33:                ;; offset=0x03B8
       add      rsp, 256
       pop      rbp
       ret      
 
G_M000_IG34:                ;; offset=0x03C1
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
; Total bytes of code 967

; Assembly listing for method Lokad.Lython.Runtime.PyDict:TryAccumulateBorrowedWord(System.ReadOnlySpan`1[byte],System.Object,System.Numerics.BigInteger,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,byref):bool:this (Instrumented Tier0)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; Instrumented Tier0 code
; rbp based frame
; partially interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 144
       lea      rbp, [rsp+0x90]
       xor      eax, eax
       mov      qword ptr [rbp-0x58], rax
       vxorps   xmm4, xmm4, xmm4
       vmovdqu  ymmword ptr [rbp-0x50], ymm4
       vmovdqu  ymmword ptr [rbp-0x30], ymm4
       vmovdqa  xmmword ptr [rbp-0x10], xmm4
       mov      gword ptr [rbp+0x10], rcx
       mov      bword ptr [rbp+0x18], rdx
       mov      gword ptr [rbp+0x20], r8
       mov      bword ptr [rbp+0x28], r9
 
G_M000_IG02:                ;; offset=0x0039
       mov      rcx, gword ptr [rbp+0x30]
       mov      rdx, gword ptr [rbp+0x38]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CheckExecution(Lokad.Lython.LythonSourceSpan):this]
       mov      rax, gword ptr [rbp+0x10]
       mov      rax, gword ptr [rax+0x28]
       mov      gword ptr [rbp-0x08], rax
       mov      rax, gword ptr [rbp+0x10]
       mov      eax, dword ptr [rax+0x4C]
       mov      dword ptr [rbp-0x3C], eax
       mov      rax, bword ptr [rbp+0x18]
 
G_M000_IG03:                ;; offset=0x0063
       vmovdqu  xmm0, xmmword ptr [rax]
       vmovdqu  xmmword ptr [rbp-0x38], xmm0
 
G_M000_IG04:                ;; offset=0x006C
       mov      rax, gword ptr [rbp+0x38]
       mov      gword ptr [rsp+0x20], rax
       lea      rax, [rbp-0x18]
       mov      qword ptr [rsp+0x28], rax
       mov      edx, dword ptr [rbp-0x3C]
       lea      r8, [rbp-0x38]
       mov      rcx, gword ptr [rbp-0x08]
       mov      r9, gword ptr [rbp+0x30]
       call     [Lokad.Lython.Runtime.PyDict:FindNativeTextIndex(Lokad.Lython.Runtime.PyDict+NativeKey[],int,System.ReadOnlySpan`1[byte],Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,byref):int]
       mov      dword ptr [rbp-0x0C], eax
       mov      rax, bword ptr [rbp+0x40]
       xor      ecx, ecx
       mov      qword ptr [rax], rcx
       cmp      dword ptr [rbp-0x0C], 0
       jge      SHORT G_M000_IG08
       mov      rax, bword ptr [rbp+0x18]
       cmp      dword ptr [rax+0x08], 8
       jle      SHORT G_M000_IG05
       mov      rax, gword ptr [rbp+0x10]
       mov      eax, dword ptr [rax+0x4C]
       mov      rcx, gword ptr [rbp-0x08]
       cmp      eax, dword ptr [rcx+0x08]
       jge      SHORT G_M000_IG07
       mov      rcx, 0x7FFA02F0B200
       call     CORINFO_HELP_COUNTPROFILE32
       xor      eax, eax
       mov      qword ptr [rbp-0x28], rax
       lea      rcx, [rbp-0x28]
       mov      edx, dword ptr [rbp-0x18]
       call     [System.Nullable`1[uint]:.ctor(uint):this]
       mov      rax, bword ptr [rbp+0x40]
       mov      rcx, qword ptr [rbp-0x28]
       mov      qword ptr [rax], rcx
 
G_M000_IG05:                ;; offset=0x00EC
       mov      rcx, 0x7FFA02F0B204
       call     CORINFO_HELP_COUNTPROFILE32
       xor      eax, eax
 
G_M000_IG06:                ;; offset=0x00FD
       add      rsp, 144
       pop      rbp
       ret      
 
G_M000_IG07:                ;; offset=0x0106
       mov      rcx, 0x7FFA02F0B208
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG05
 
G_M000_IG08:                ;; offset=0x0117
       mov      rcx, 0x7FFA02F0B20C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, gword ptr [rbp-0x08]
       mov      ecx, dword ptr [rbp-0x0C]
       cmp      ecx, dword ptr [rax+0x08]
       jae      SHORT G_M000_IG12
       mov      edx, ecx
       imul     rdx, rdx, 40
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      bword ptr [rbp-0x20], rax
       mov      rax, bword ptr [rbp-0x20]
       mov      rdx, gword ptr [rax]
       mov      rcx, 0x7FFA02A91030
       call     [CORINFO_HELP_CHKCASTCLASS]
       mov      gword ptr [rbp-0x58], rax
       mov      rax, bword ptr [rbp-0x20]
       mov      eax, dword ptr [rax+0x18]
       mov      dword ptr [rbp-0x5C], eax
       mov      rax, gword ptr [rbp+0x20]
       mov      gword ptr [rsp+0x20], rax
       mov      rax, bword ptr [rbp+0x28]
 
G_M000_IG09:                ;; offset=0x0173
       vmovdqu  xmm0, xmmword ptr [rax]
       vmovdqu  xmmword ptr [rbp-0x50], xmm0
 
G_M000_IG10:                ;; offset=0x017C
       mov      r8, gword ptr [rbp-0x58]
       mov      r9d, dword ptr [rbp-0x5C]
       lea      rax, [rbp-0x50]
       mov      qword ptr [rsp+0x28], rax
       mov      edx, dword ptr [rbp-0x0C]
       mov      rcx, gword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.PyDict:TryAccumulateAt(int,Lokad.Lython.Runtime.Text.PyString,uint,System.Object,System.Numerics.BigInteger):bool:this]
       nop      
 
G_M000_IG11:                ;; offset=0x019B
       add      rsp, 144
       pop      rbp
       ret      
 
G_M000_IG12:                ;; offset=0x01A4
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
; Total bytes of code 426

; Assembly listing for method Lokad.Lython.Runtime.PyDict:FindNativeTextIndex(Lokad.Lython.Runtime.PyDict+NativeKey[],int,System.ReadOnlySpan`1[byte],Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,byref):int (Instrumented Tier0)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; Instrumented Tier0 code
; rbp based frame
; fully interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 256
       lea      rbp, [rsp+0x100]
       xor      eax, eax
       mov      qword ptr [rbp-0xD8], rax
       vxorps   xmm4, xmm4, xmm4
       vmovdqu  ymmword ptr [rbp-0xD0], ymm4
       vmovdqu  ymmword ptr [rbp-0xB0], ymm4
       vmovdqu  ymmword ptr [rbp-0x90], ymm4
       vmovdqu  ymmword ptr [rbp-0x70], ymm4
       vmovdqa  xmmword ptr [rbp-0x50], xmm4
       mov      qword ptr [rbp-0x40], rax
       mov      gword ptr [rbp+0x10], rcx
       mov      dword ptr [rbp+0x18], edx
       mov      bword ptr [rbp+0x20], r8
       mov      gword ptr [rbp+0x28], r9
 
G_M000_IG02:                ;; offset=0x0052
       mov      dword ptr [rbp-0x94], 0x3E8
       cmp      dword ptr [rbp+0x18], 4
       jg       G_M000_IG15
       mov      rax, bword ptr [rbp+0x20]
       cmp      dword ptr [rax+0x08], 8
       jg       SHORT G_M000_IG03
       mov      rax, bword ptr [rbp+0x38]
       xor      ecx, ecx
       mov      dword ptr [rax], ecx
       xor      eax, eax
       mov      dword ptr [rbp-0x3C], eax
       jmp      G_M000_IG12
 
G_M000_IG03:                ;; offset=0x0082
       mov      rcx, 0x7FFA02D564C0
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG15
 
G_M000_IG04:                ;; offset=0x0096
       mov      rax, gword ptr [rbp+0x10]
       mov      ecx, dword ptr [rbp-0x3C]
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG34
       mov      edx, ecx
       imul     rdx, rdx, 40
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      rdx, gword ptr [rax]
       mov      rcx, 0x7FFA02A91030
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      gword ptr [rbp-0x48], rax
       cmp      gword ptr [rbp-0x48], 0
       je       G_M000_IG11
       mov      rax, bword ptr [rbp+0x20]
 
G_M000_IG05:                ;; offset=0x00D7
       vmovdqu  xmm0, xmmword ptr [rax]
       vmovdqu  xmmword ptr [rbp-0x80], xmm0
 
G_M000_IG06:                ;; offset=0x00E0
       lea      rdx, [rbp-0x90]
       mov      rcx, gword ptr [rbp-0x48]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.Text.PyString:get_Utf8Span():System.ReadOnlySpan`1[byte]:this]
 
G_M000_IG07:                ;; offset=0x00F3
       vmovdqu  xmm0, xmmword ptr [rbp-0x80]
       vmovdqu  xmmword ptr [rbp-0xA8], xmm0
 
G_M000_IG08:                ;; offset=0x0100
       vmovdqu  xmm0, xmmword ptr [rbp-0x90]
       vmovdqu  xmmword ptr [rbp-0xB8], xmm0
 
G_M000_IG09:                ;; offset=0x0110
       lea      rcx, [rbp-0xA8]
       lea      rdx, [rbp-0xB8]
       call     [System.MemoryExtensions:SequenceEqual[byte](System.ReadOnlySpan`1[byte],System.ReadOnlySpan`1[byte]):bool]
       test     eax, eax
       je       SHORT G_M000_IG10
       mov      rcx, 0x7FFA02D564C4
       call     CORINFO_HELP_COUNTPROFILE32
       mov      eax, dword ptr [rbp-0x3C]
       mov      dword ptr [rbp-0x98], eax
       jmp      G_M000_IG32
 
G_M000_IG10:                ;; offset=0x0145
       mov      rcx, 0x7FFA02D564C8
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG11:                ;; offset=0x0154
       mov      rcx, 0x7FFA02D564CC
       call     CORINFO_HELP_COUNTPROFILE32
       mov      eax, dword ptr [rbp-0x3C]
       inc      eax
       mov      dword ptr [rbp-0x3C], eax
 
G_M000_IG12:                ;; offset=0x016B
       mov      eax, dword ptr [rbp-0x94]
       dec      eax
       mov      dword ptr [rbp-0x94], eax
       cmp      dword ptr [rbp-0x94], 0
       jg       SHORT G_M000_IG14
 
G_M000_IG13:                ;; offset=0x0182
       lea      rcx, [rbp-0x94]
       mov      edx, 63
       call     CORINFO_HELP_PATCHPOINT
       jmp      rax
 
G_M000_IG14:                ;; offset=0x0195
       mov      eax, dword ptr [rbp-0x3C]
       cmp      eax, dword ptr [rbp+0x18]
       jl       G_M000_IG04
       mov      rcx, 0x7FFA02D564D0
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG30
 
G_M000_IG15:                ;; offset=0x01B5
       mov      rax, bword ptr [rbp+0x20]
 
G_M000_IG16:                ;; offset=0x01B9
       vmovdqu  xmm0, xmmword ptr [rax]
       vmovdqu  xmmword ptr [rbp-0x70], xmm0
 
G_M000_IG17:                ;; offset=0x01C2
       xor      eax, eax
       mov      gword ptr [rbp-0x50], rax
 
G_M000_IG18:                ;; offset=0x01C8
       vmovdqu  xmm0, xmmword ptr [rbp-0x70]
       vmovdqu  xmmword ptr [rbp-0xC8], xmm0
 
G_M000_IG19:                ;; offset=0x01D5
       lea      rcx, [rbp-0xC8]
       mov      rdx, gword ptr [rbp+0x28]
       mov      r8, gword ptr [rbp+0x30]
       mov      r9, gword ptr [rbp-0x50]
       call     [Lokad.Lython.Runtime.Text.PyString:HashUtf8(System.ReadOnlySpan`1[byte],Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,System.Threading.CancellationToken):int]
       mov      ecx, eax
       call     [Lokad.Lython.Runtime.PyValueComparer:NormalizeHash(int):int]
       mov      ecx, eax
       call     [Lokad.Lython.Runtime.PyDict:MixNativeHash(int):uint]
       mov      rcx, bword ptr [rbp+0x38]
       mov      dword ptr [rcx], eax
       cmp      dword ptr [rbp+0x18], 0
       jne      SHORT G_M000_IG20
       mov      rcx, 0x7FFA02D564D4
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG30
 
G_M000_IG20:                ;; offset=0x021E
       mov      rax, gword ptr [rbp+0x10]
       mov      edx, dword ptr [rax+0x08]
       mov      rax, bword ptr [rbp+0x38]
       mov      ecx, dword ptr [rax]
       call     [Lokad.Lython.Runtime.PyDict:NativeBucket(uint,int):int]
       mov      rcx, gword ptr [rbp+0x10]
       cmp      eax, dword ptr [rcx+0x08]
       jae      G_M000_IG34
       mov      edx, eax
       imul     rdx, rdx, 40
       lea      rcx, bword ptr [rcx+rdx+0x10]
       mov      eax, dword ptr [rcx+0x20]
       dec      eax
       mov      dword ptr [rbp-0x54], eax
       jmp      G_M000_IG27
 
G_M000_IG21:                ;; offset=0x0256
       mov      rcx, gword ptr [rbp+0x28]
       mov      rdx, gword ptr [rbp+0x30]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CheckExecution(Lokad.Lython.LythonSourceSpan):this]
       mov      rax, gword ptr [rbp+0x10]
       mov      ecx, dword ptr [rbp-0x54]
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG34
       mov      edx, ecx
       imul     rdx, rdx, 40
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      eax, dword ptr [rax+0x18]
       mov      rcx, bword ptr [rbp+0x38]
       cmp      eax, dword ptr [rcx]
       jne      G_M000_IG26
       mov      rax, gword ptr [rbp+0x10]
       mov      ecx, dword ptr [rbp-0x54]
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG34
       mov      edx, ecx
       imul     rdx, rdx, 40
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      rdx, gword ptr [rax]
       mov      rcx, 0x7FFA02A91030
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      gword ptr [rbp-0x60], rax
       cmp      gword ptr [rbp-0x60], 0
       je       SHORT G_M000_IG25
       mov      rax, bword ptr [rbp+0x20]
 
G_M000_IG22:                ;; offset=0x02CD
       vmovdqu  xmm0, xmmword ptr [rax]
       vmovdqu  xmmword ptr [rbp-0xD8], xmm0
 
G_M000_IG23:                ;; offset=0x02D9
       lea      rdx, [rbp-0xD8]
       mov      rcx, gword ptr [rbp-0x60]
       mov      r8, gword ptr [rbp+0x28]
       mov      r9, gword ptr [rbp+0x30]
       call     [Lokad.Lython.Runtime.PyDict:EqualNativeText(Lokad.Lython.Runtime.Text.PyString,System.ReadOnlySpan`1[byte],Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):bool]
       test     eax, eax
       je       SHORT G_M000_IG24
       mov      rcx, 0x7FFA02D564D8
       call     CORINFO_HELP_COUNTPROFILE32
       mov      eax, dword ptr [rbp-0x54]
       mov      dword ptr [rbp-0x98], eax
       jmp      G_M000_IG32
 
G_M000_IG24:                ;; offset=0x0313
       mov      rcx, 0x7FFA02D564DC
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG26
 
G_M000_IG25:                ;; offset=0x0324
       mov      rcx, 0x7FFA02D564E0
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG26:                ;; offset=0x0333
       mov      rcx, 0x7FFA02D564E4
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, gword ptr [rbp+0x10]
       mov      ecx, dword ptr [rbp-0x54]
       cmp      ecx, dword ptr [rax+0x08]
       jae      SHORT G_M000_IG34
       mov      edx, ecx
       imul     rdx, rdx, 40
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      eax, dword ptr [rax+0x1C]
       dec      eax
       mov      dword ptr [rbp-0x54], eax
 
G_M000_IG27:                ;; offset=0x0361
       mov      eax, dword ptr [rbp-0x94]
       dec      eax
       mov      dword ptr [rbp-0x94], eax
       cmp      dword ptr [rbp-0x94], 0
       jg       SHORT G_M000_IG29
 
G_M000_IG28:                ;; offset=0x0378
       lea      rcx, [rbp-0x94]
       mov      edx, 210
       call     CORINFO_HELP_PATCHPOINT
       jmp      rax
 
G_M000_IG29:                ;; offset=0x038B
       cmp      dword ptr [rbp-0x54], 0
       jge      G_M000_IG21
       mov      rcx, 0x7FFA02D564E8
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG30:                ;; offset=0x03A4
       mov      eax, -1
 
G_M000_IG31:                ;; offset=0x03A9
       add      rsp, 256
       pop      rbp
       ret      
 
G_M000_IG32:                ;; offset=0x03B2
       mov      eax, dword ptr [rbp-0x98]
 
G_M000_IG33:                ;; offset=0x03B8
       add      rsp, 256
       pop      rbp
       ret      
 
G_M000_IG34:                ;; offset=0x03C1
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
; Total bytes of code 967

; Assembly listing for method Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteDictionaryLoop(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool (Instrumented Tier0)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; Instrumented Tier0 code
; rbp based frame
; fully interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 752
       lea      rbp, [rsp+0x2F0]
       vxorps   xmm4, xmm4, xmm4
       mov      rax, -624
 
G_M000_IG87:                ;; offset=0x001E
       vmovdqa  xmmword ptr [rbp+rax-0x40], xmm4
       vmovdqa  xmmword ptr [rbp+rax-0x30], xmm4
       vmovdqa  xmmword ptr [rbp+rax-0x20], xmm4
       add      rax, 48
       jne      SHORT G_M000_IG87
       mov      qword ptr [rbp-0x40], rax
       mov      bword ptr [rbp+0x10], rcx
       mov      gword ptr [rbp+0x18], rdx
       mov      gword ptr [rbp+0x20], r8
       mov      bword ptr [rbp+0x28], r9
 
G_M000_IG02:                ;; offset=0x004A
       mov      dword ptr [rbp-0x1B4], 0x3E8
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       lea      rcx, bword ptr [rax+0x20]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:get_LiveExtent():int:this]
       mov      dword ptr [rbp-0x114], eax
       mov      rcx, bword ptr [rbp+0x28]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       cmp      eax, dword ptr [rbp-0x114]
       jne      SHORT G_M000_IG04
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       lea      rcx, bword ptr [rax+0x20]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:get_HasPendingDisposals():bool:this]
       test     eax, eax
       je       SHORT G_M000_IG05
 
G_M000_IG03:                ;; offset=0x0098
       mov      rcx, 0x7FFA02D56120
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG04:                ;; offset=0x00A7
       mov      rcx, 0x7FFA02D56124
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG24
 
G_M000_IG05:                ;; offset=0x00BB
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_RequiresLocalVariableMirroring():bool:this]
       test     eax, eax
       jne      G_M000_IG11
       cmp      gword ptr [rbp+0x20], 0
       jne      SHORT G_M000_IG06
       mov      dword ptr [rbp-0x19C], 1
       jmp      SHORT G_M000_IG07
 
G_M000_IG06:                ;; offset=0x00E5
       mov      rcx, 0x7FFA02D56128
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, gword ptr [rbp+0x20]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:get_MirrorLocalStores():bool:this]
       test     eax, eax
       sete     al
       movzx    rax, al
       mov      dword ptr [rbp-0x19C], eax
 
G_M000_IG07:                ;; offset=0x010C
       cmp      dword ptr [rbp-0x19C], 0
       je       SHORT G_M000_IG08
       cmp      gword ptr [rbp+0x20], 0
       jne      SHORT G_M000_IG09
       xor      rax, rax
       mov      gword ptr [rbp-0x1A8], rax
       jmp      SHORT G_M000_IG10
 
G_M000_IG08:                ;; offset=0x0127
       mov      rcx, 0x7FFA02D5612C
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG11
 
G_M000_IG09:                ;; offset=0x0138
       mov      rcx, 0x7FFA02D56130
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, gword ptr [rbp+0x20]
       mov      rax, gword ptr [rax+0x88]
       mov      gword ptr [rbp-0x1A8], rax
 
G_M000_IG10:                ;; offset=0x0159
       mov      rcx, 0x7FFA02D56134
       call     CORINFO_HELP_COUNTPROFILE32
       cmp      gword ptr [rbp-0x1A8], 0
       sete     al
       movzx    rax, al
       mov      dword ptr [rbp-0x118], eax
       jmp      SHORT G_M000_IG12
 
G_M000_IG11:                ;; offset=0x017E
       xor      eax, eax
       mov      dword ptr [rbp-0x118], eax
 
G_M000_IG12:                ;; offset=0x0186
       movzx    rax, byte  ptr [rbp-0x118]
       mov      dword ptr [rbp-0x3C], eax
       cmp      dword ptr [rbp-0x3C], 0
       je       G_M000_IG14
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       add      rax, 32
       mov      bword ptr [rbp-0x120], rax
       mov      rcx, bword ptr [rbp+0x28]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x1BC], eax
       mov      edx, dword ptr [rbp-0x1BC]
       mov      rcx, bword ptr [rbp-0x120]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:get_Item(int):System.Object:this]
       mov      gword ptr [rbp-0x1C8], rax
       mov      rdx, gword ptr [rbp-0x1C8]
       mov      rcx, 0x7FFA02D42798
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      gword ptr [rbp-0x48], rax
       cmp      gword ptr [rbp-0x48], 0
       je       SHORT G_M000_IG15
       mov      rcx, gword ptr [rbp-0x48]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.Text.PyStringOps+CasedWhitespaceIteration:get_MemoryGovernor():Lokad.Lython.Runtime.MemoryGovernor:this]
       mov      gword ptr [rbp-0x128], rax
       mov      rcx, gword ptr [rbp+0x18]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:get_MemoryGovernor():Lokad.Lython.Runtime.MemoryGovernor:this]
       cmp      rax, gword ptr [rbp-0x128]
       je       SHORT G_M000_IG16
 
G_M000_IG13:                ;; offset=0x0223
       mov      rcx, 0x7FFA02D56138
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG14:                ;; offset=0x0232
       mov      rcx, 0x7FFA02D5613C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      eax, dword ptr [rbp-0x3C]
       mov      dword ptr [rsp+0x20], eax
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rbp+0x18]
       mov      r8, gword ptr [rbp+0x20]
       mov      r9, bword ptr [rbp+0x28]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteOrdinaryDictionaryLoop(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,bool):bool]
       mov      dword ptr [rbp-0x1B8], eax
       jmp      G_M000_IG59
 
G_M000_IG15:                ;; offset=0x0269
       mov      rcx, 0x7FFA02D56140
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG14
 
G_M000_IG16:                ;; offset=0x027A
       mov      rax, bword ptr [rbp+0x10]
       mov      eax, dword ptr [rax+0x18]
       mov      dword ptr [rbp-0x4C], eax
       mov      rcx, bword ptr [rbp+0x28]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_DictionaryLoopCallIndex():int:this]
       mov      dword ptr [rbp-0x50], eax
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_CallSites():System.Collections.Generic.IReadOnlyList`1[Lokad.Lython.Frontend.ExecutableCallSite]:this]
       mov      gword ptr [rbp-0x130], rax
       mov      rax, gword ptr [rbp-0x130]
       mov      gword ptr [rbp-0x1B0], rax
       mov      rcx, gword ptr [rbp-0x1B0]
       mov      rdx, 0x7FFA02D56148
       call     CORINFO_HELP_CLASSPROFILE32
       mov      rax, gword ptr [rbp-0x1B0]
       mov      gword ptr [rbp-0x1D0], rax
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Instructions():Lokad.Lython.Frontend.ExecutableInstruction[]:this]
       mov      ecx, dword ptr [rbp-0x50]
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG61
       mov      edx, ecx
       imul     rdx, rdx, 32
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      rcx, rax
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_CallSiteIndex():int:this]
       mov      dword ptr [rbp-0x1D4], eax
       mov      rcx, gword ptr [rbp-0x1D0]
       mov      edx, dword ptr [rbp-0x1D4]
       mov      r11, 0x7FFA025720B0
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       mov      gword ptr [rbp-0x58], rax
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Instructions():Lokad.Lython.Frontend.ExecutableInstruction[]:this]
       mov      ecx, dword ptr [rbp-0x4C]
       add      ecx, 2
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG61
       mov      edx, ecx
       imul     rdx, rdx, 32
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      bword ptr [rbp-0x60], rax
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Instructions():Lokad.Lython.Frontend.ExecutableInstruction[]:this]
       mov      ecx, dword ptr [rbp-0x50]
       inc      ecx
       cmp      ecx, dword ptr [rax+0x08]
 
G_M000_IG17:                ;; offset=0x0370
       jae      G_M000_IG61
       mov      edx, ecx
       imul     rdx, rdx, 32
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      bword ptr [rbp-0x68], rax
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Instructions():Lokad.Lython.Frontend.ExecutableInstruction[]:this]
       mov      ecx, dword ptr [rbp-0x50]
       add      ecx, 2
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG61
       mov      edx, ecx
       imul     rdx, rdx, 32
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      bword ptr [rbp-0x70], rax
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Constants():System.Object[]:this]
       mov      gword ptr [rbp-0x138], rax
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Instructions():Lokad.Lython.Frontend.ExecutableInstruction[]:this]
       mov      ecx, dword ptr [rbp-0x4C]
       add      ecx, 4
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG61
       mov      edx, ecx
       imul     rdx, rdx, 32
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      rcx, rax
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ConstantIndex():int:this]
       mov      rcx, gword ptr [rbp-0x138]
       cmp      eax, dword ptr [rcx+0x08]
       jae      G_M000_IG61
       mov      edx, eax
       lea      rcx, bword ptr [rcx+8*rdx+0x10]
       mov      rax, gword ptr [rcx]
       mov      gword ptr [rbp-0x78], rax
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Constants():System.Object[]:this]
       mov      gword ptr [rbp-0x140], rax
       mov      rcx, bword ptr [rbp-0x68]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_SecondInput():int:this]
       not      eax
       mov      rcx, gword ptr [rbp-0x140]
       cmp      eax, dword ptr [rcx+0x08]
       jae      G_M000_IG61
       mov      edx, eax
 
G_M000_IG18:                ;; offset=0x044C
       lea      rcx, bword ptr [rcx+8*rdx+0x10]
       mov      rax, gword ptr [rcx]
       mov      gword ptr [rbp-0x1E0], rax
       mov      rdx, gword ptr [rbp-0x1E0]
       mov      rcx, 0x7FFA02A1B3F0
       call     [CORINFO_HELP_UNBOX]
 
G_M000_IG19:                ;; offset=0x0472
       vmovdqu  xmm0, xmmword ptr [rax]
       vmovdqu  xmmword ptr [rbp-0x88], xmm0
 
G_M000_IG20:                ;; offset=0x047E
       mov      rax, bword ptr [rbp+0x10]
       mov      rax, gword ptr [rax+0x08]
       mov      gword ptr [rbp-0x148], rax
       mov      rax, gword ptr [rbp-0x148]
       mov      gword ptr [rbp-0x2B0], rax
       mov      rcx, bword ptr [rbp-0x70]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_SecondInput():int:this]
       mov      rdx, gword ptr [rbp-0x2B0]
       cmp      eax, dword ptr [rdx+0x08]
       jae      G_M000_IG61
       mov      ecx, eax
       imul     rcx, rcx, 16
       lea      rcx, bword ptr [rdx+rcx+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Object():System.Object:this]
       mov      gword ptr [rbp-0x1E8], rax
       mov      rdx, gword ptr [rbp-0x1E8]
       mov      rcx, 0x7FFA02B1FD78
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      gword ptr [rbp-0x90], rax
       cmp      gword ptr [rbp-0x90], 0
       je       SHORT G_M000_IG22
       mov      rcx, gword ptr [rbp-0x90]
       mov      rdx, gword ptr [rbp+0x18]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.PyDict:CanAccumulateBorrowedWords(Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG23
 
G_M000_IG21:                ;; offset=0x050C
       mov      rcx, 0x7FFA02D56250
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG22:                ;; offset=0x051B
       mov      rcx, 0x7FFA02D56254
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG24
 
G_M000_IG23:                ;; offset=0x052F
       mov      eax, dword ptr [rbp-0x50]
       add      eax, 3
       mov      dword ptr [rbp-0x94], eax
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Instructions():Lokad.Lython.Frontend.ExecutableInstruction[]:this]
       mov      ecx, dword ptr [rbp-0x94]
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG61
       mov      edx, ecx
       imul     rdx, rdx, 32
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      bword ptr [rbp-0xA0], rax
       mov      rcx, bword ptr [rbp-0xA0]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_OpCode():int:this]
       cmp      eax, 47
       sete     al
       movzx    rax, al
       mov      dword ptr [rbp-0xA4], eax
       xor      eax, eax
       mov      qword ptr [rbp-0xB0], rax
       xor      eax, eax
       mov      qword ptr [rbp-0xB8], rax
       cmp      dword ptr [rbp-0xA4], 0
       je       G_M000_IG29
       mov      rax, bword ptr [rbp+0x10]
       mov      rax, gword ptr [rax+0x08]
       mov      gword ptr [rbp-0x190], rax
       mov      rcx, bword ptr [rbp-0xA0]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      rcx, gword ptr [rbp-0x190]
       cmp      eax, dword ptr [rcx+0x08]
       jae      G_M000_IG61
       mov      edx, eax
       imul     rdx, rdx, 16
       lea      rcx, bword ptr [rcx+rdx+0x10]
       mov      bword ptr [rbp-0x1F0], rcx
       mov      rcx, bword ptr [rbp-0x1F0]
       lea      rdx, [rbp-0xB0]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryReadHistogramTotal(byref,byref):bool]
       test     eax, eax
       jne      SHORT G_M000_IG26
       mov      rcx, 0x7FFA02D56258
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG24:                ;; offset=0x060B
       xor      eax, eax
 
G_M000_IG25:                ;; offset=0x060D
       add      rsp, 752
       pop      rbp
       ret      
 
G_M000_IG26:                ;; offset=0x0616
       mov      rcx, 0x7FFA02D5625C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Constants():System.Object[]:this]
       mov      gword ptr [rbp-0x198], rax
       mov      rcx, bword ptr [rbp-0xA0]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_SecondInput():int:this]
       not      eax
       mov      rcx, gword ptr [rbp-0x198]
       cmp      eax, dword ptr [rcx+0x08]
       jae      G_M000_IG61
       mov      edx, eax
       lea      rcx, bword ptr [rcx+8*rdx+0x10]
       mov      rax, gword ptr [rcx]
       mov      gword ptr [rbp-0x1F8], rax
       mov      rdx, gword ptr [rbp-0x1F8]
       mov      rcx, 0x7FFA02A1B3F0
       call     [CORINFO_HELP_UNBOX]
 
G_M000_IG27:                ;; offset=0x0682
       vmovdqu  xmm0, xmmword ptr [rax]
       vmovdqu  xmmword ptr [rbp-0x208], xmm0
 
G_M000_IG28:                ;; offset=0x068E
       lea      rcx, [rbp-0x208]
       call     [System.Numerics.BigInteger:op_Explicit(System.Numerics.BigInteger):long]
       mov      qword ptr [rbp-0xB8], rax
 
G_M000_IG29:                ;; offset=0x06A2
       vxorps   xmm0, xmm0, xmm0
       vmovdqu  xmmword ptr [rbp-0xC8], xmm0
       xor      rax, rax
       mov      gword ptr [rbp-0xD0], rax
       xor      eax, eax
       mov      dword ptr [rbp-0xD4], eax
       xor      eax, eax
       mov      dword ptr [rbp-0xD8], eax
       xor      eax, eax
       mov      dword ptr [rbp-0xDC], eax
 
G_M000_IG30:                ;; offset=0x06CF
       mov      eax, dword ptr [rbp-0x1B4]
       dec      eax
       mov      dword ptr [rbp-0x1B4], eax
       cmp      dword ptr [rbp-0x1B4], 0
       jg       SHORT G_M000_IG32
 
G_M000_IG31:                ;; offset=0x06E6
       lea      rcx, [rbp-0x1B4]
       mov      edx, 496
       call     CORINFO_HELP_PATCHPOINT
       jmp      rax
 
G_M000_IG32:                ;; offset=0x06F9
       lea      rdx, [rbp-0xF0]
       lea      r8, [rbp-0xF8]
       mov      rcx, gword ptr [rbp-0x48]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.Text.PyStringOps+CasedWhitespaceIteration:TryReadWord(byref,byref):bool:this]
       test     eax, eax
       je       G_M000_IG54
 
G_M000_IG33:                ;; offset=0x071B
       vmovdqu  xmm0, xmmword ptr [rbp-0xF0]
       vmovdqu  xmmword ptr [rbp-0xC8], xmm0
 
G_M000_IG34:                ;; offset=0x072B
       mov      rax, gword ptr [rbp-0xF8]
       mov      gword ptr [rbp-0xD0], rax
       cmp      dword ptr [rbp-0xD8], 0
       jne      SHORT G_M000_IG35
       mov      rcx, bword ptr [rbp-0x60]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x210], rax
       mov      rdx, gword ptr [rbp-0x210]
       mov      rcx, gword ptr [rbp+0x18]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CheckExecution(Lokad.Lython.LythonSourceSpan):this]
       mov      rax, bword ptr [rbp+0x10]
       mov      ecx, dword ptr [rbp-0x50]
       mov      dword ptr [rax+0x18], ecx
       mov      rcx, gword ptr [rbp-0x58]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_CallSpan():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x218], rax
       mov      rdx, gword ptr [rbp-0x218]
       mov      rcx, gword ptr [rbp+0x18]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:EnterInterpreterFrame(Lokad.Lython.LythonSourceSpan):this]
       mov      dword ptr [rbp-0xD8], 1
       jmp      SHORT G_M000_IG36
 
G_M000_IG35:                ;; offset=0x07A2
       mov      rcx, 0x7FFA02D56260
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x10]
       mov      ecx, dword ptr [rbp-0x50]
       mov      dword ptr [rax+0x18], ecx
 
G_M000_IG36:                ;; offset=0x07BB
       cmp      gword ptr [rbp-0xF8], 0
       jne      G_M000_IG45
 
G_M000_IG37:                ;; offset=0x07C9
       vmovdqu  xmm0, xmmword ptr [rbp-0xF0]
       vmovdqu  xmmword ptr [rbp-0x160], xmm0
 
G_M000_IG38:                ;; offset=0x07D9
       vmovdqu  xmm0, xmmword ptr [rbp-0x160]
       vmovdqu  xmmword ptr [rbp-0x228], xmm0
 
G_M000_IG39:                ;; offset=0x07E9
       vmovdqu  xmm0, xmmword ptr [rbp-0x88]
       vmovdqu  xmmword ptr [rbp-0x238], xmm0
 
G_M000_IG40:                ;; offset=0x07F9
       mov      rcx, gword ptr [rbp-0x58]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_CallSpan():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x240], rax
       lea      rax, [rbp-0x108]
       mov      qword ptr [rsp+0x30], rax
       mov      rax, gword ptr [rbp-0x240]
       mov      gword ptr [rsp+0x28], rax
       lea      rdx, [rbp-0x228]
       lea      r9, [rbp-0x238]
       mov      r8, gword ptr [rbp-0x78]
       mov      rax, gword ptr [rbp+0x18]
       mov      gword ptr [rsp+0x20], rax
       mov      rcx, gword ptr [rbp-0x90]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.PyDict:TryAccumulateBorrowedWord(System.ReadOnlySpan`1[byte],System.Object,System.Numerics.BigInteger,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,byref):bool:this]
       mov      dword ptr [rbp-0xFC], eax
       lea      rcx, [rbp-0x108]
       call     [System.Nullable`1[uint]:get_HasValue():bool:this]
       test     eax, eax
       je       G_M000_IG48
       mov      rcx, 0x7FFA02D56264
       call     CORINFO_HELP_COUNTPROFILE32
       lea      rcx, [rbp-0x108]
       call     [System.Nullable`1[uint]:GetValueOrDefault():uint:this]
       mov      dword ptr [rbp-0x10C], eax
       mov      rcx, gword ptr [rbp-0x58]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_CallSpan():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x248], rax
       mov      rdx, gword ptr [rbp-0x248]
       mov      rcx, gword ptr [rbp+0x18]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CheckExecution(Lokad.Lython.LythonSourceSpan):this]
 
G_M000_IG41:                ;; offset=0x08B1
       vmovdqu  xmm0, xmmword ptr [rbp-0xF0]
       vmovdqu  xmmword ptr [rbp-0x258], xmm0
 
G_M000_IG42:                ;; offset=0x08C1
       lea      rdx, [rbp-0x258]
       mov      rcx, gword ptr [rbp-0x48]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.Text.PyStringOps+CasedWhitespaceIteration:Materialize(System.ReadOnlySpan`1[byte]):Lokad.Lython.Runtime.Text.PyString:this]
       mov      gword ptr [rbp-0xD0], rax
 
G_M000_IG43:                ;; offset=0x08DB
       vmovdqu  xmm0, xmmword ptr [rbp-0x88]
       vmovdqu  xmmword ptr [rbp-0x268], xmm0
 
G_M000_IG44:                ;; offset=0x08EB
       lea      rax, [rbp-0x268]
       mov      qword ptr [rsp+0x20], rax
       mov      rdx, gword ptr [rbp-0xD0]
       mov      r8d, dword ptr [rbp-0x10C]
       mov      r9, gword ptr [rbp-0x78]
       mov      rcx, gword ptr [rbp-0x90]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.PyDict:TryAppendBorrowedWord(Lokad.Lython.Runtime.Text.PyString,uint,System.Object,System.Numerics.BigInteger):bool:this]
       mov      dword ptr [rbp-0xFC], eax
       jmp      SHORT G_M000_IG48
 
G_M000_IG45:                ;; offset=0x0920
       mov      rcx, 0x7FFA02D56268
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, gword ptr [rbp-0xF8]
       mov      gword ptr [rbp-0x150], rax
 
G_M000_IG46:                ;; offset=0x093D
       vmovdqu  xmm0, xmmword ptr [rbp-0x88]
       vmovdqu  xmmword ptr [rbp-0x278], xmm0
 
G_M000_IG47:                ;; offset=0x094D
       mov      rcx, gword ptr [rbp-0x58]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_CallSpan():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x280], rax
       mov      rax, gword ptr [rbp-0x280]
       mov      gword ptr [rsp+0x28], rax
       lea      r9, [rbp-0x278]
       mov      r8, gword ptr [rbp-0x78]
       mov      rdx, gword ptr [rbp-0x150]
       mov      rax, gword ptr [rbp+0x18]
       mov      gword ptr [rsp+0x20], rax
       mov      rcx, gword ptr [rbp-0x90]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.PyDict:TryAccumulateWithoutAdmission(Lokad.Lython.Runtime.Text.PyString,System.Object,System.Numerics.BigInteger,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):bool:this]
       mov      dword ptr [rbp-0xFC], eax
 
G_M000_IG48:                ;; offset=0x099C
       cmp      dword ptr [rbp-0xFC], 0
       jne      SHORT G_M000_IG49
       mov      eax, dword ptr [rbp-0x4C]
       add      eax, 2
       mov      rcx, bword ptr [rbp+0x10]
       mov      dword ptr [rcx+0x18], eax
       mov      dword ptr [rbp-0x110], 1
       jmp      G_M000_IG56
 
G_M000_IG49:                ;; offset=0x09C1
       cmp      dword ptr [rbp-0xA4], 0
       je       G_M000_IG53
       mov      rax, qword ptr [rbp-0xB0]
       add      rax, qword ptr [rbp-0xB8]
       mov      qword ptr [rbp-0xB0], rax
       mov      dword ptr [rbp-0xD4], 1
       mov      rax, 0xFF80000000000000
       cmp      qword ptr [rbp-0xB0], rax
       jl       SHORT G_M000_IG51
       mov      rax, 0x80000000000000
       cmp      qword ptr [rbp-0xB0], rax
       jl       SHORT G_M000_IG52
 
G_M000_IG50:                ;; offset=0x0A13
       mov      rcx, 0x7FFA02D5626C
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG51:                ;; offset=0x0A22
       mov      rcx, 0x7FFA02D56270
       call     CORINFO_HELP_COUNTPROFILE32
       mov      eax, dword ptr [rbp-0x94]
       add      eax, 2
       mov      rcx, bword ptr [rbp+0x10]
       mov      dword ptr [rcx+0x18], eax
       mov      dword ptr [rbp-0x110], 1
       jmp      G_M000_IG57
 
G_M000_IG52:                ;; offset=0x0A50
       mov      rcx, 0x7FFA02D56274
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG53:                ;; offset=0x0A5F
       mov      rcx, 0x7FFA02D56278
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x10]
       mov      ecx, dword ptr [rbp-0x4C]
       mov      dword ptr [rax+0x18], ecx
       mov      rcx, bword ptr [rbp+0x28]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x288], rax
       mov      rdx, gword ptr [rbp-0x288]
       mov      rcx, gword ptr [rbp+0x18]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CheckExecution(Lokad.Lython.LythonSourceSpan):this]
       jmp      G_M000_IG30
 
G_M000_IG54:                ;; offset=0x0AA1
       mov      rcx, 0x7FFA02D5627C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0xDC], 1
       mov      rcx, bword ptr [rbp+0x28]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_TargetIndex():int:this]
       mov      rcx, bword ptr [rbp+0x10]
       mov      dword ptr [rcx+0x18], eax
       mov      dword ptr [rbp-0x110], 1
 
G_M000_IG55:                ;; offset=0x0AD5
       call     G_M000_IG81
       jmp      SHORT G_M000_IG58
 
G_M000_IG56:                ;; offset=0x0ADC
       call     G_M000_IG81
       jmp      SHORT G_M000_IG58
 
G_M000_IG57:                ;; offset=0x0AE3
       call     G_M000_IG81
       nop      
 
G_M000_IG58:                ;; offset=0x0AE9
       mov      rcx, 0x7FFA02D562A4
       call     CORINFO_HELP_COUNTPROFILE32
       mov      eax, dword ptr [rbp-0x110]
       mov      dword ptr [rbp-0x1B8], eax
 
G_M000_IG59:                ;; offset=0x0B04
       movzx    rax, byte  ptr [rbp-0x1B8]
 
G_M000_IG60:                ;; offset=0x0B0B
       add      rsp, 752
       pop      rbp
       ret      
 
G_M000_IG61:                ;; offset=0x0B14
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG62:                ;; offset=0x0B1A
       sub      rsp, 56
 
G_M000_IG63:                ;; offset=0x0B1E
       cmp      dword ptr [rbp-0xD4], 0
       je       SHORT G_M000_IG64
       mov      rcx, 0x7FFA02D56290
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x10]
       mov      rax, gword ptr [rax+0x08]
       mov      gword ptr [rbp-0x188], rax
       mov      rcx, bword ptr [rbp-0xA0]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      rcx, gword ptr [rbp-0x188]
       cmp      eax, dword ptr [rcx+0x08]
       jae      G_M000_IG67
       mov      edx, eax
       imul     rdx, rdx, 16
       lea      rcx, bword ptr [rcx+rdx+0x10]
       mov      bword ptr [rbp-0x2A0], rcx
       mov      rcx, bword ptr [rbp-0x2A0]
       mov      rdx, qword ptr [rbp-0xB0]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:SetInteger(long):this]
 
G_M000_IG64:                ;; offset=0x0B88
       cmp      dword ptr [rbp-0xDC], 0
       je       SHORT G_M000_IG65
       mov      rcx, 0x7FFA02D56294
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       add      rax, 32
       mov      bword ptr [rbp-0x180], rax
       mov      rcx, bword ptr [rbp+0x28]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x2A4], eax
       mov      edx, dword ptr [rbp-0x2A4]
       mov      rcx, bword ptr [rbp-0x180]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
 
G_M000_IG65:                ;; offset=0x0BD8
       mov      rcx, 0x7FFA02D56298
       call     CORINFO_HELP_COUNTPROFILE32
       nop      
 
G_M000_IG66:                ;; offset=0x0BE8
       add      rsp, 56
       ret      
 
G_M000_IG67:                ;; offset=0x0BED
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG68:                ;; offset=0x0BF3
       sub      rsp, 56
 
G_M000_IG69:                ;; offset=0x0BF7
       cmp      gword ptr [rbp-0xD0], 0
       jne      SHORT G_M000_IG73
       lea      rcx, [rbp-0xC8]
       call     [System.ReadOnlySpan`1[byte]:get_IsEmpty():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG70
       jmp      SHORT G_M000_IG72
 
G_M000_IG70:                ;; offset=0x0C14
       mov      rcx, 0x7FFA02D56284
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG77
 
G_M000_IG71:                ;; offset=0x0C28
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG72:                ;; offset=0x0C2E
       mov      rcx, 0x7FFA02D56288
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG73:                ;; offset=0x0C3D
       mov      rax, bword ptr [rbp+0x10]
       mov      rax, gword ptr [rax+0x08]
       mov      gword ptr [rbp-0x168], rax
       mov      rcx, bword ptr [rbp-0x70]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ThirdInput():int:this]
       mov      rcx, gword ptr [rbp-0x168]
       cmp      eax, dword ptr [rcx+0x08]
       jae      SHORT G_M000_IG71
       mov      edx, eax
       imul     rdx, rdx, 16
       lea      rcx, bword ptr [rcx+rdx+0x10]
       mov      bword ptr [rbp-0x170], rcx
       mov      rax, gword ptr [rbp-0xD0]
       mov      gword ptr [rbp-0x178], rax
       cmp      gword ptr [rbp-0xD0], 0
       jne      SHORT G_M000_IG76
       mov      rcx, 0x7FFA02D5628C
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG74:                ;; offset=0x0C9B
       vmovdqu  xmm0, xmmword ptr [rbp-0xC8]
       vmovdqu  xmmword ptr [rbp-0x298], xmm0
 
G_M000_IG75:                ;; offset=0x0CAB
       lea      rdx, [rbp-0x298]
       mov      rcx, gword ptr [rbp-0x48]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.Text.PyStringOps+CasedWhitespaceIteration:Materialize(System.ReadOnlySpan`1[byte]):Lokad.Lython.Runtime.Text.PyString:this]
       mov      gword ptr [rbp-0x178], rax
 
G_M000_IG76:                ;; offset=0x0CC5
       mov      rcx, bword ptr [rbp-0x170]
       mov      rdx, gword ptr [rbp-0x178]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:set_Object(System.Object):this]
 
G_M000_IG77:                ;; offset=0x0CD9
       nop      
 
G_M000_IG78:                ;; offset=0x0CDA
       call     G_M000_IG62
       nop      
 
G_M000_IG79:                ;; offset=0x0CE0
       mov      rcx, 0x7FFA02D5629C
       call     CORINFO_HELP_COUNTPROFILE32
       nop      
 
G_M000_IG80:                ;; offset=0x0CF0
       add      rsp, 56
       ret      
 
G_M000_IG81:                ;; offset=0x0CF5
       sub      rsp, 56
 
G_M000_IG82:                ;; offset=0x0CF9
       cmp      dword ptr [rbp-0xD8], 0
       je       SHORT G_M000_IG83
       mov      rcx, 0x7FFA02D56280
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, gword ptr [rbp+0x18]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:LeaveInterpreterFrame():this]
 
G_M000_IG83:                ;; offset=0x0D1D
       nop      
 
G_M000_IG84:                ;; offset=0x0D1E
       call     G_M000_IG68
       nop      
 
G_M000_IG85:                ;; offset=0x0D24
       mov      rcx, 0x7FFA02D562A0
       call     CORINFO_HELP_COUNTPROFILE32
       nop      
 
G_M000_IG86:                ;; offset=0x0D34
       add      rsp, 56
       ret      
 
; Total bytes of code 3385

; Assembly listing for method Lokad.Lython.Runtime.PyDict:TryAppendBorrowedWord(Lokad.Lython.Runtime.Text.PyString,uint,System.Object,System.Numerics.BigInteger):bool:this (Tier0)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; Tier0 code
; rbp based frame
; partially interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 64
       lea      rbp, [rsp+0x40]
       xor      eax, eax
       mov      qword ptr [rbp-0x10], rax
       mov      gword ptr [rbp+0x10], rcx
       mov      gword ptr [rbp+0x18], rdx
       mov      dword ptr [rbp+0x20], r8d
       mov      gword ptr [rbp+0x28], r9
 
G_M000_IG02:                ;; offset=0x0020
       mov      rax, gword ptr [rbp+0x28]
       mov      gword ptr [rsp+0x20], rax
       mov      rax, bword ptr [rbp+0x30]
 
G_M000_IG03:                ;; offset=0x002D
       vmovdqu  xmm0, xmmword ptr [rax]
       vmovdqu  xmmword ptr [rbp-0x10], xmm0
 
G_M000_IG04:                ;; offset=0x0036
       lea      rax, [rbp-0x10]
       mov      qword ptr [rsp+0x28], rax
       mov      rcx, gword ptr [rbp+0x10]
       mov      r8, gword ptr [rbp+0x18]
       mov      r9d, dword ptr [rbp+0x20]
       mov      edx, -1
       call     [Lokad.Lython.Runtime.PyDict:TryAccumulateAt(int,Lokad.Lython.Runtime.Text.PyString,uint,System.Object,System.Numerics.BigInteger):bool:this]
       nop      
 
G_M000_IG05:                ;; offset=0x0057
       add      rsp, 64
       pop      rbp
       ret      
 
; Total bytes of code 93

; Assembly listing for method Lokad.Lython.Runtime.PyDict:TryAccumulateBorrowedWord(System.ReadOnlySpan`1[byte],System.Object,System.Numerics.BigInteger,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,byref):bool:this (Tier1)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; Tier1 code
; optimized code
; optimized using Synthesized PGO
; rsp based frame
; fully interruptible
; with Synthesized PGO: fgCalledCount is 256151
; 25 inlinees with PGO data; 57 single block inlinees; 1 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     r15
       push     r14
       push     r13
       push     r12
       push     rdi
       push     rsi
       push     rbp
       push     rbx
       sub      rsp, 200
       vxorps   xmm4, xmm4, xmm4
       vmovdqu  ymmword ptr [rsp+0x50], ymm4
       vmovdqu  ymmword ptr [rsp+0x70], ymm4
       vmovdqu  ymmword ptr [rsp+0x90], ymm4
       xor      eax, eax
       mov      qword ptr [rsp+0xB0], rax
       mov      rbx, rcx
       mov      rsi, rdx
       mov      rdi, gword ptr [rsp+0x130]
 
G_M000_IG02:                ;; offset=0x0044
       mov      r14, gword ptr [r9]
       mov      r15d, dword ptr [r9+0x08]
       mov      rcx, gword ptr [rdi+0x98]
       mov      rdx, gword ptr [rcx+0x88]
       cmp      gword ptr [rdx+0x20], 0
       jne      G_M000_IG50
       mov      rdx, gword ptr [rcx+0x180]
       test     rdx, rdx
       jne      G_M000_IG49
 
G_M000_IG03:                ;; offset=0x0074
       mov      r13, gword ptr [rbx+0x28]
       mov      r12d, dword ptr [rbx+0x4C]
       mov      rax, bword ptr [rsi]
       mov      bword ptr [rsp+0x48], rax
       mov      r10d, dword ptr [rsi+0x08]
       mov      dword ptr [rsp+0x7C], r10d
       cmp      r12d, 4
       jg       G_M000_IG28
 
G_M000_IG04:                ;; offset=0x0097
       cmp      r10d, 8
       jg       G_M000_IG28
 
G_M000_IG05:                ;; offset=0x00A1
       xor      edi, edi
       xor      ecx, ecx
       test     r12d, r12d
       jle      G_M000_IG80
       jmp      SHORT G_M000_IG07
 
G_M000_IG06:                ;; offset=0x00B0
       inc      ecx
       cmp      ecx, r12d
       jge      G_M000_IG80
 
G_M000_IG07:                ;; offset=0x00BB
       cmp      ecx, dword ptr [r13+0x08]
       jae      G_M000_IG101
       lea      rdx, [rcx+4*rcx]
       mov      rdx, gword ptr [r13+8*rdx+0x10]
       test     rdx, rdx
       je       SHORT G_M000_IG06
 
G_M000_IG08:                ;; offset=0x00D3
       mov      r8, 0x7FFA02A91030
       cmp      qword ptr [rdx], r8
       jne      SHORT G_M000_IG06
 
G_M000_IG09:                ;; offset=0x00E2
       movzx    r8, byte  ptr [rdx+0x24]
       test     r8d, r8d
       je       G_M000_IG51
 
G_M000_IG10:                ;; offset=0x00F0
       cmp      r8d, 255
       je       G_M000_IG43
 
G_M000_IG11:                ;; offset=0x00FD
       lea      r8, bword ptr [rdx+0x28]
       mov      r9d, dword ptr [rdx+0x18]
       cmp      r9d, 8
       ja       G_M000_IG70
 
G_M000_IG12:                ;; offset=0x010F
       cmp      r10d, r9d
       jne      SHORT G_M000_IG06
 
G_M000_IG13:                ;; offset=0x0114
       mov      rdx, rax
       mov      r11, r8
       mov      r9d, r9d
       cmp      r9, 8
       jae      G_M000_IG45
 
G_M000_IG14:                ;; offset=0x0127
       cmp      r9, 4
       jb       G_M000_IG56
 
G_M000_IG15:                ;; offset=0x0131
       add      r9, -4
       mov      edx, dword ptr [rax]
       sub      edx, dword ptr [r8]
       mov      r11d, dword ptr [rax+r9]
       sub      r11d, dword ptr [r8+r9]
       or       edx, r11d
       sete     dl
       movzx    rdx, dl
 
G_M000_IG16:                ;; offset=0x014B
       test     edx, edx
       je       G_M000_IG06
 
G_M000_IG17:                ;; offset=0x0153
       mov      r12d, ecx
 
G_M000_IG18:                ;; offset=0x0156
       xor      ecx, ecx
       mov      rbp, bword ptr [rsp+0x140]
       mov      qword ptr [rbp], rcx
       test     r12d, r12d
       jl       G_M000_IG81
 
G_M000_IG19:                ;; offset=0x016D
       mov      ecx, r12d
       lea      rcx, [rcx+4*rcx]
       lea      rdx, bword ptr [r13+8*rcx+0x10]
       mov      esi, r12d
       mov      rax, gword ptr [rdx]
       mov      r13, rax
       test     r13, r13
       je       SHORT G_M000_IG21
 
G_M000_IG20:                ;; offset=0x0187
       mov      r8, 0x7FFA02A91030
       cmp      qword ptr [r13], r8
       jne      G_M000_IG86
 
G_M000_IG21:                ;; offset=0x019B
       mov      ebp, dword ptr [rdx+0x18]
       cmp      gword ptr [rbx+0x20], 0
       jne      G_M000_IG87
       mov      rdx, gword ptr [rbx+0x30]
       cmp      esi, dword ptr [rdx+0x08]
       jae      G_M000_IG101
       mov      eax, esi
       cmp      gword ptr [rdx+8*rax+0x10], 0
       jne      G_M000_IG87
 
G_M000_IG22:                ;; offset=0x01C4
       mov      rdx, gword ptr [rbx+0x28]
       cmp      esi, dword ptr [rdx+0x08]
       jae      G_M000_IG101
       mov      rdx, qword ptr [rdx+8*rcx+0x20]
       mov      rcx, 0xFF80000000000000
       cmp      rdx, rcx
       jl       G_M000_IG88
       mov      rcx, 0x80000000000000
       cmp      rdx, rcx
       jge      G_M000_IG88
 
G_M000_IG23:                ;; offset=0x01FC
       test     r14, r14
       jne      G_M000_IG94
       movsxd   rcx, r15d
 
G_M000_IG24:                ;; offset=0x0208
       add      rdx, rcx
       mov      edi, dword ptr [rbx+0x4C]
       cmp      gword ptr [rbx+0x20], 0
       jne      G_M000_IG99
       mov      rcx, gword ptr [rbx+0x28]
       cmp      esi, dword ptr [rcx+0x08]
       jae      G_M000_IG101
       mov      eax, esi
       lea      rax, [rax+4*rax]
       mov      qword ptr [rcx+8*rax+0x20], rdx
       mov      rcx, gword ptr [rbx+0x30]
       cmp      esi, dword ptr [rcx+0x08]
       jae      G_M000_IG101
       mov      edx, esi
       xor      rax, rax
       mov      gword ptr [rcx+8*rdx+0x10], rax
 
G_M000_IG25:                ;; offset=0x0247
       cmp      dword ptr [rbx+0x4C], edi
       jne      G_M000_IG100
 
G_M000_IG26:                ;; offset=0x0250
       mov      eax, 1
 
G_M000_IG27:                ;; offset=0x0255
       vzeroupper 
       add      rsp, 200
       pop      rbx
       pop      rbp
       pop      rsi
       pop      rdi
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       ret      
 
G_M000_IG28:                ;; offset=0x026C
       mov      bword ptr [rsp+0x60], rax
       mov      dword ptr [rsp+0x68], r10d
       lea      rcx, [rsp+0x60]
       mov      rdx, rdi
       mov      r8, gword ptr [rsp+0x138]
       xor      r9, r9
       call     [Lokad.Lython.Runtime.Text.PyString:HashUtf8(System.ReadOnlySpan`1[byte],Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,System.Threading.CancellationToken):int]
       mov      edx, -2
       cmp      eax, -1
       cmovne   edx, eax
       mov      eax, edx
       shr      eax, 16
       xor      eax, edx
       imul     eax, eax, 0xFFFFFFFF9E3779B9
       mov      edx, eax
       shr      edx, 16
       xor      edx, eax
       mov      r8d, edx
       test     r12d, r12d
       je       G_M000_IG71
 
G_M000_IG29:                ;; offset=0x02BA
       mov      ecx, dword ptr [r13+0x08]
       lea      r10d, [rcx-0x01]
       test     ecx, r10d
       jne      G_M000_IG72
       and      r10d, r8d
 
G_M000_IG30:                ;; offset=0x02CE
       cmp      r10d, dword ptr [r13+0x08]
       jae      G_M000_IG101
       mov      ecx, r10d
       lea      rcx, [rcx+4*rcx]
       mov      r12d, dword ptr [r13+8*rcx+0x30]
       dec      r12d
       js       G_M000_IG75
       jmp      SHORT G_M000_IG34
 
G_M000_IG31:                ;; offset=0x02EF
       mov      r9d, 0x1000
       jmp      G_M000_IG41
 
G_M000_IG32:                ;; offset=0x02FA
       mov      rax, bword ptr [rsp+0x38]
       mov      r12d, dword ptr [rax+0x1C]
       dec      r12d
       js       G_M000_IG77
 
G_M000_IG33:                ;; offset=0x030C
       mov      r8d, dword ptr [rsp+0xC0]
 
G_M000_IG34:                ;; offset=0x0314
       mov      rcx, gword ptr [rdi+0x98]
       mov      rdx, gword ptr [rcx+0x88]
       cmp      gword ptr [rdx+0x20], 0
       jne      G_M000_IG74
       mov      rdx, gword ptr [rcx+0x180]
       test     rdx, rdx
       jne      G_M000_IG73
 
G_M000_IG35:                ;; offset=0x033D
       cmp      r12d, dword ptr [r13+0x08]
       jae      G_M000_IG101
       mov      edx, r12d
       lea      rdx, [rdx+4*rdx]
       lea      rax, bword ptr [r13+8*rdx+0x10]
       mov      bword ptr [rsp+0x38], rax
       mov      dword ptr [rsp+0xC0], r8d
       cmp      dword ptr [rax+0x18], r8d
       jne      SHORT G_M000_IG32
 
G_M000_IG36:                ;; offset=0x0366
       mov      rcx, gword ptr [r13+8*rdx+0x10]
       test     rcx, rcx
       je       SHORT G_M000_IG32
 
G_M000_IG37:                ;; offset=0x0370
       mov      rdx, 0x7FFA02A91030
       cmp      qword ptr [rcx], rdx
       jne      G_M000_IG32
 
G_M000_IG38:                ;; offset=0x0383
       mov      r10d, dword ptr [rsp+0x7C]
       mov      dword ptr [rsp+0x78], r10d
       lea      rdx, [rsp+0xA8]
       call     [Lokad.Lython.Runtime.Text.PyString:get_Utf8Span():System.ReadOnlySpan`1[byte]:this]
       mov      eax, dword ptr [rsp+0xB0]
       mov      dword ptr [rsp+0x74], eax
       mov      ecx, dword ptr [rsp+0x78]
       cmp      eax, ecx
       jne      G_M000_IG32
       xor      r8d, r8d
       mov      dword ptr [rsp+0xA4], r8d
       mov      r10d, dword ptr [rsp+0x7C]
       cmp      r8d, r10d
       jge      G_M000_IG42
 
G_M000_IG39:                ;; offset=0x03CB
       mov      rcx, gword ptr [rdi+0x98]
       mov      rdx, gword ptr [rcx+0x88]
       cmp      gword ptr [rdx+0x20], 0
       jne      G_M000_IG79
       mov      rdx, gword ptr [rcx+0x180]
       test     rdx, rdx
       jne      G_M000_IG78
 
G_M000_IG40:                ;; offset=0x03F4
       mov      r10d, dword ptr [rsp+0x7C]
       mov      r8d, dword ptr [rsp+0xA4]
       mov      r9d, r10d
       sub      r9d, r8d
       cmp      r9d, 0x1000
       jge      G_M000_IG31
 
G_M000_IG41:                ;; offset=0x0414
       mov      ecx, r8d
       mov      edx, r9d
       add      rcx, rdx
       mov      edx, r10d
       cmp      rcx, rdx
       ja       G_M000_IG70
       mov      edx, r8d
       add      rdx, bword ptr [rsp+0x48]
       mov      ebp, dword ptr [rsp+0x74]
       cmp      rcx, rbp
       ja       G_M000_IG70
       mov      dword ptr [rsp+0xA4], r8d
       mov      ecx, r8d
       add      rcx, bword ptr [rsp+0xA8]
       mov      bword ptr [rsp+0x40], rcx
       mov      dword ptr [rsp+0xA0], r9d
       mov      r8d, r9d
       mov      rcx, rdx
       mov      rdx, bword ptr [rsp+0x40]
       call     [System.SpanHelpers:SequenceEqual(byref,byref,nuint):bool]
       test     eax, eax
       je       G_M000_IG32
       mov      ebp, dword ptr [rsp+0xA0]
       mov      r8d, ebp
       add      r8d, dword ptr [rsp+0xA4]
       mov      ebp, r8d
       mov      r10d, dword ptr [rsp+0x7C]
       cmp      ebp, r10d
       mov      dword ptr [rsp+0xA4], ebp
       jl       G_M000_IG39
 
G_M000_IG42:                ;; offset=0x04A1
       mov      edi, dword ptr [rsp+0xC0]
       jmp      G_M000_IG18
 
G_M000_IG43:                ;; offset=0x04AD
       mov      r8, gword ptr [rdx+0x08]
       lea      r9, bword ptr [rdx+0x28]
       mov      r9d, dword ptr [r9]
       mov      edx, dword ptr [rdx+0x18]
       test     r8, r8
       je       G_M000_IG55
       mov      r11d, edx
       add      r11, r9
       mov      ebp, dword ptr [r8+0x08]
       cmp      r11, rbp
       ja       G_M000_IG70
       lea      r8, bword ptr [r8+r9+0x10]
       mov      r9d, edx
 
G_M000_IG44:                ;; offset=0x04DF
       jmp      G_M000_IG12
 
G_M000_IG45:                ;; offset=0x04E4
       cmp      rdx, r11
       je       G_M000_IG68
       cmp      r9, 32
       jae      G_M000_IG61
 
G_M000_IG46:                ;; offset=0x04F7
       cmp      r9, 16
       jae      G_M000_IG64
 
G_M000_IG47:                ;; offset=0x0501
       add      r9, -8
       mov      r11, qword ptr [rax]
       sub      r11, qword ptr [r8]
       mov      rdx, qword ptr [rax+r9]
       sub      rdx, qword ptr [r8+r9]
       or       rdx, r11
       sete     dl
       movzx    rdx, dl
       jmp      G_M000_IG16
 
G_M000_IG48:                ;; offset=0x0521
       add      rdx, 32
       cmp      r8, rdx
       ja       G_M000_IG62
       jmp      G_M000_IG63
 
G_M000_IG49:                ;; offset=0x0533
       cmp      dword ptr [rdx+0x20], 0
       setne    dl
       movzx    rdx, dl
       test     edx, edx
       je       G_M000_IG03
 
G_M000_IG50:                ;; offset=0x0545
       mov      rdx, gword ptr [rsp+0x138]
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
       jmp      G_M000_IG03
 
G_M000_IG51:                ;; offset=0x0558
       mov      r8, gword ptr [rdx+0x08]
       mov      r9d, dword ptr [rdx+0x18]
       test     r8, r8
       jne      SHORT G_M000_IG53
 
G_M000_IG52:                ;; offset=0x0565
       test     r9d, r9d
       jne      G_M000_IG70
       xor      r8, r8
       xor      r9d, r9d
       jmp      SHORT G_M000_IG54
 
G_M000_IG53:                ;; offset=0x0576
       cmp      dword ptr [r8+0x08], r9d
       jb       G_M000_IG70
       add      r8, 16
 
G_M000_IG54:                ;; offset=0x0584
       jmp      G_M000_IG12
 
G_M000_IG55:                ;; offset=0x0589
       or       r9d, edx
       jne      G_M000_IG70
       xor      r8, r8
       xor      r9d, r9d
       jmp      G_M000_IG44
 
G_M000_IG56:                ;; offset=0x059D
       xor      edx, edx
       mov      r11, r9
       and      r11, 2
       mov      qword ptr [rsp+0xB8], r11
       test     r11, r11
       je       SHORT G_M000_IG58
 
G_M000_IG57:                ;; offset=0x05B3
       movzx    rdx, word  ptr [rax]
       mov      dword ptr [rsp+0xC4], edx
       movzx    rdx, word  ptr [r8]
       movzx    r11, dword ptr [rsp+0xC4]
       sub      r11d, edx
       mov      edx, r11d
 
G_M000_IG58:                ;; offset=0x05D0
       test     r9b, 1
       je       SHORT G_M000_IG60
 
G_M000_IG59:                ;; offset=0x05D6
       mov      r11, qword ptr [rsp+0xB8]
       movzx    r9, byte  ptr [rax+r11]
       movzx    r8, byte  ptr [r8+r11]
       sub      r9d, r8d
       or       edx, r9d
 
G_M000_IG60:                ;; offset=0x05EE
       test     edx, edx
       sete     dl
       movzx    rdx, dl
       jmp      G_M000_IG16
 
G_M000_IG61:                ;; offset=0x05FB
       xor      edx, edx
       lea      r8, [r9-0x20]
       test     r8, r8
       je       SHORT G_M000_IG63
       vmovups  ymm0, ymmword ptr [rax]
       vpcmpeqb ymm0, ymm0, ymmword ptr [r11]
       vpmovmskb r9d, ymm0
       cmp      r9d, -1
       je       G_M000_IG48
       jmp      G_M000_IG69
 
G_M000_IG62:                ;; offset=0x0622
       vmovups  ymm0, ymmword ptr [rax+rdx]
       vpcmpeqb ymm0, ymm0, ymmword ptr [r11+rdx]
       vpmovmskb r9d, ymm0
       cmp      r9d, -1
       jne      G_M000_IG69
       jmp      G_M000_IG48
 
G_M000_IG63:                ;; offset=0x0640
       vmovups  ymm0, ymmword ptr [rax+r8]
       vpcmpeqb ymm0, ymm0, ymmword ptr [r11+r8]
       vpmovmskb edx, ymm0
       cmp      edx, -1
       jne      SHORT G_M000_IG69
       jmp      SHORT G_M000_IG68
 
G_M000_IG64:                ;; offset=0x0657
       xor      edx, edx
       add      r9, -16
       je       SHORT G_M000_IG67
       vmovups  xmm0, xmmword ptr [rax]
       vpcmpeqb xmm0, xmm0, xmmword ptr [r11]
       vpmovmskb r8d, xmm0
       cmp      r8d, 0xFFFF
       jne      SHORT G_M000_IG69
 
G_M000_IG65:                ;; offset=0x0675
       add      rdx, 16
       cmp      r9, rdx
       jbe      SHORT G_M000_IG67
 
G_M000_IG66:                ;; offset=0x067E
       vmovups  xmm0, xmmword ptr [rax+rdx]
       vpcmpeqb xmm0, xmm0, xmmword ptr [r11+rdx]
       vpmovmskb r8d, xmm0
       cmp      r8d, 0xFFFF
       jne      SHORT G_M000_IG69
       jmp      SHORT G_M000_IG65
 
G_M000_IG67:                ;; offset=0x0698
       vmovups  xmm0, xmmword ptr [rax+r9]
       vpcmpeqb xmm0, xmm0, xmmword ptr [r11+r9]
       vpmovmskb r11d, xmm0
       cmp      r11d, 0xFFFF
       jne      SHORT G_M000_IG69
 
G_M000_IG68:                ;; offset=0x06B1
       mov      edx, 1
       jmp      G_M000_IG16
 
G_M000_IG69:                ;; offset=0x06BB
       xor      edx, edx
       jmp      G_M000_IG16
 
G_M000_IG70:                ;; offset=0x06C2
       call     [System.ThrowHelper:ThrowArgumentOutOfRangeException()]
       int3     
 
G_M000_IG71:                ;; offset=0x06C9
       mov      edi, r8d
       jmp      G_M000_IG80
 
G_M000_IG72:                ;; offset=0x06D1
       mov      dword ptr [rsp+0xC0], r8d
       mov      eax, r8d
       xor      edx, edx
       div      edx:eax, ecx
       mov      r10d, edx
       mov      r8d, dword ptr [rsp+0xC0]
       jmp      G_M000_IG30
 
G_M000_IG73:                ;; offset=0x06F0
       cmp      dword ptr [rdx+0x20], 0
       setne    dl
       movzx    rdx, dl
       test     edx, edx
       je       G_M000_IG35
       mov      dword ptr [rsp+0xC0], r8d
       jmp      SHORT G_M000_IG76
 
G_M000_IG74:                ;; offset=0x070C
       mov      dword ptr [rsp+0xC0], r8d
       jmp      SHORT G_M000_IG76
 
G_M000_IG75:                ;; offset=0x0716
       mov      edi, r8d
       jmp      SHORT G_M000_IG80
 
G_M000_IG76:                ;; offset=0x071B
       mov      rdx, gword ptr [rsp+0x138]
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
       mov      r8d, dword ptr [rsp+0xC0]
       jmp      G_M000_IG35
 
G_M000_IG77:                ;; offset=0x0736
       mov      edi, dword ptr [rsp+0xC0]
       jmp      SHORT G_M000_IG80
 
G_M000_IG78:                ;; offset=0x073F
       cmp      dword ptr [rdx+0x20], 0
       setne    dl
       movzx    rdx, dl
       test     edx, edx
       je       G_M000_IG40
 
G_M000_IG79:                ;; offset=0x0751
       mov      rdx, gword ptr [rsp+0x138]
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
       jmp      G_M000_IG40
 
G_M000_IG80:                ;; offset=0x0764
       mov      r12d, -1
       jmp      G_M000_IG18
 
G_M000_IG81:                ;; offset=0x076F
       cmp      dword ptr [rsi+0x08], 8
       jle      SHORT G_M000_IG84
 
G_M000_IG82:                ;; offset=0x0775
       mov      eax, dword ptr [rbx+0x4C]
       cmp      eax, dword ptr [r13+0x08]
       jge      SHORT G_M000_IG84
 
G_M000_IG83:                ;; offset=0x077E
       mov      byte  ptr [rbp], 1
       mov      dword ptr [rbp+0x04], edi
 
G_M000_IG84:                ;; offset=0x0785
       xor      eax, eax
 
G_M000_IG85:                ;; offset=0x0787
       vzeroupper 
       add      rsp, 200
       pop      rbx
       pop      rbp
       pop      rsi
       pop      rdi
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       ret      
 
G_M000_IG86:                ;; offset=0x079E
       mov      rdx, rax
       mov      rcx, r8
       call     CORINFO_HELP_CHKCASTCLASS
       int3     
 
G_M000_IG87:                ;; offset=0x07AA
       mov      rcx, rbx
       mov      edx, esi
       call     [Lokad.Lython.Runtime.PyDict:ReadNativeValue(int):System.Object:this]
       test     rax, rax
       jne      SHORT G_M000_IG89
 
G_M000_IG88:                ;; offset=0x07BA
       xor      eax, eax
       jmp      G_M000_IG27
 
G_M000_IG89:                ;; offset=0x07C1
       mov      rcx, 0x7FFA02A1B3F0
       cmp      qword ptr [rax], rcx
       jne      SHORT G_M000_IG88
 
G_M000_IG90:                ;; offset=0x07D0
       vmovdqu  xmm0, xmmword ptr [rax+0x08]
       vmovdqu  xmmword ptr [rsp+0x90], xmm0
 
G_M000_IG91:                ;; offset=0x07DE
       lea      rcx, [rsp+0x90]
       xor      edx, edx
       call     [System.Numerics.BigInteger:GetByteCount(bool):int:this]
       cmp      eax, 8
       jge      SHORT G_M000_IG88
 
G_M000_IG92:                ;; offset=0x07F3
       vmovdqu  xmm0, xmmword ptr [rsp+0x90]
       vmovdqu  xmmword ptr [rsp+0x50], xmm0
 
G_M000_IG93:                ;; offset=0x0802
       lea      rcx, [rsp+0x50]
       call     [System.Numerics.BigInteger:op_Explicit(System.Numerics.BigInteger):long]
       mov      rdx, rax
       jmp      G_M000_IG23
 
G_M000_IG94:                ;; offset=0x0815
       cmp      dword ptr [r14+0x08], 1
       jle      SHORT G_M000_IG95
       mov      rcx, 0x7FFA02CAEE18
       call     CORINFO_HELP_NEWSFAST
       mov      rbx, rax
       call     [System.SR:get_Overflow_Int64():System.String]
       mov      rdx, rax
       mov      rcx, rbx
       call     [System.OverflowException:.ctor(System.String):this]
       mov      rcx, rbx
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG95:                ;; offset=0x0849
       cmp      dword ptr [r14+0x08], 0
       jbe      G_M000_IG101
       mov      rcx, qword ptr [r14+0x10]
       mov      rax, rcx
       neg      rax
       test     r15d, r15d
       cmovle   rcx, rax
       test     rcx, rcx
       jle      SHORT G_M000_IG96
       test     r15d, r15d
       jg       SHORT G_M000_IG97
 
G_M000_IG96:                ;; offset=0x086F
       test     rcx, rcx
       jge      SHORT G_M000_IG98
       test     r15d, r15d
       jge      SHORT G_M000_IG98
 
G_M000_IG97:                ;; offset=0x0879
       jmp      G_M000_IG24
 
G_M000_IG98:                ;; offset=0x087E
       mov      rcx, 0x7FFA02CAEE18
       call     CORINFO_HELP_NEWSFAST
       mov      rbx, rax
       call     [System.SR:get_Overflow_Int64():System.String]
       mov      rdx, rax
       mov      rcx, rbx
       call     [System.OverflowException:.ctor(System.String):this]
       mov      rcx, rbx
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG99:                ;; offset=0x08AB
       lea      rcx, [rsp+0x80]
       call     [System.Numerics.BigInteger:.ctor(long):this]
       mov      rcx, 0x7FFA02A1B3F0
       call     CORINFO_HELP_NEWSFAST
       mov      rsi, rax
       lea      rcx, bword ptr [rsi+0x08]
       mov      rdx, gword ptr [rsp+0x80]
       call     CORINFO_HELP_ASSIGN_REF
       mov      r9d, dword ptr [rsp+0x88]
       mov      dword ptr [rsi+0x10], r9d
       mov      dword ptr [rsp+0x20], ebp
       xor      r9d, r9d
       mov      dword ptr [rsp+0x28], r9d
       mov      dword ptr [rsp+0x30], 1
       mov      r9, rsi
       mov      rcx, rbx
       mov      edx, r12d
       mov      r8, r13
       call     [Lokad.Lython.Runtime.PyDict:PublishNativeValue(int,System.Object,System.Object,uint,bool,bool):System.Object:this]
       jmp      G_M000_IG25
 
G_M000_IG100:                ;; offset=0x0913
       inc      dword ptr [rbx+0x48]
       jmp      G_M000_IG26
 
G_M000_IG101:                ;; offset=0x091B
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
; Total bytes of code 2337

; Assembly listing for method Lokad.Lython.Runtime.PyDict:FindNativeTextIndex(Lokad.Lython.Runtime.PyDict+NativeKey[],int,System.ReadOnlySpan`1[byte],Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,byref):int (Tier1)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; Tier1 code
; optimized code
; optimized using Synthesized PGO
; rsp based frame
; fully interruptible
; with Synthesized PGO: fgCalledCount is 404631
; 19 inlinees with PGO data; 48 single block inlinees; 1 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     r15
       push     r14
       push     r13
       push     r12
       push     rdi
       push     rsi
       push     rbp
       push     rbx
       sub      rsp, 72
       vxorps   xmm4, xmm4, xmm4
       vmovdqu  ymmword ptr [rsp+0x20], ymm4
       xor      eax, eax
       mov      qword ptr [rsp+0x40], rax
       mov      rbx, rcx
       mov      esi, edx
       mov      rdi, r9
       mov      rbp, bword ptr [rsp+0xB8]
 
G_M000_IG02:                ;; offset=0x0031
       mov      r14, bword ptr [r8]
       mov      r15d, dword ptr [r8+0x08]
       cmp      esi, 4
       jg       G_M000_IG19
 
G_M000_IG03:                ;; offset=0x0041
       cmp      r15d, 8
       jg       G_M000_IG19
 
G_M000_IG04:                ;; offset=0x004B
       xor      ecx, ecx
       mov      dword ptr [rbp], ecx
 
G_M000_IG05:                ;; offset=0x0050
       test     esi, esi
       jle      G_M000_IG64
       jmp      SHORT G_M000_IG07
 
G_M000_IG06:                ;; offset=0x005A
       inc      ecx
       cmp      ecx, esi
       jge      G_M000_IG64
 
G_M000_IG07:                ;; offset=0x0064
       cmp      ecx, dword ptr [rbx+0x08]
       jae      G_M000_IG66
       lea      rdx, [rcx+4*rcx]
       mov      rdx, gword ptr [rbx+8*rdx+0x10]
       test     rdx, rdx
       je       SHORT G_M000_IG06
 
G_M000_IG08:                ;; offset=0x007B
       mov      r8, 0x7FFA02A91030
       cmp      qword ptr [rdx], r8
       jne      SHORT G_M000_IG06
 
G_M000_IG09:                ;; offset=0x008A
       movzx    r8, byte  ptr [rdx+0x24]
       test     r8d, r8d
       je       G_M000_IG39
 
G_M000_IG10:                ;; offset=0x0098
       cmp      r8d, 255
       je       G_M000_IG33
 
G_M000_IG11:                ;; offset=0x00A5
       lea      r8, bword ptr [rdx+0x28]
       mov      r9d, dword ptr [rdx+0x18]
       cmp      r9d, 8
       ja       G_M000_IG58
 
G_M000_IG12:                ;; offset=0x00B7
       cmp      r15d, r9d
       jne      SHORT G_M000_IG06
 
G_M000_IG13:                ;; offset=0x00BC
       mov      rdx, r14
       mov      rax, r8
       mov      r9d, r9d
       cmp      r9, 8
       jae      G_M000_IG35
 
G_M000_IG14:                ;; offset=0x00CF
       cmp      r9, 4
       jb       G_M000_IG44
 
G_M000_IG15:                ;; offset=0x00D9
       add      r9, -4
       mov      eax, dword ptr [r14]
       sub      eax, dword ptr [r8]
       mov      edx, dword ptr [r14+r9]
       sub      edx, dword ptr [r8+r9]
       or       edx, eax
       sete     dl
       movzx    rdx, dl
 
G_M000_IG16:                ;; offset=0x00F3
       test     edx, edx
       je       G_M000_IG06
 
G_M000_IG17:                ;; offset=0x00FB
       mov      eax, ecx
 
G_M000_IG18:                ;; offset=0x00FD
       vzeroupper 
       add      rsp, 72
       pop      rbx
       pop      rbp
       pop      rsi
       pop      rdi
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       ret      
 
G_M000_IG19:                ;; offset=0x0111
       mov      bword ptr [rsp+0x20], r14
       mov      dword ptr [rsp+0x28], r15d
       lea      rcx, [rsp+0x20]
       mov      rdx, rdi
       mov      r8, gword ptr [rsp+0xB0]
       xor      r9, r9
       call     [Lokad.Lython.Runtime.Text.PyString:HashUtf8(System.ReadOnlySpan`1[byte],Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,System.Threading.CancellationToken):int]
       mov      edx, -2
       cmp      eax, -1
       cmovne   edx, eax
       mov      eax, edx
       shr      eax, 16
       xor      eax, edx
       imul     eax, eax, 0xFFFFFFFF9E3779B9
       mov      edx, eax
       shr      edx, 16
       xor      edx, eax
       mov      dword ptr [rbp], edx
       test     esi, esi
       je       G_M000_IG64
 
G_M000_IG20:                ;; offset=0x015E
       mov      eax, dword ptr [rbp]
       mov      ecx, dword ptr [rbx+0x08]
       lea      r8d, [rcx-0x01]
       test     ecx, r8d
       jne      G_M000_IG59
       and      r8d, eax
 
G_M000_IG21:                ;; offset=0x0174
       cmp      r8d, dword ptr [rbx+0x08]
       jae      G_M000_IG66
       mov      ecx, r8d
       lea      rcx, [rcx+4*rcx]
       mov      esi, dword ptr [rbx+8*rcx+0x30]
       dec      esi
       js       G_M000_IG64
       jmp      SHORT G_M000_IG24
 
G_M000_IG22:                ;; offset=0x0193
       mov      r10d, 0x1000
       jmp      G_M000_IG31
 
G_M000_IG23:                ;; offset=0x019E
       mov      esi, dword ptr [r13+0x1C]
       dec      esi
       js       G_M000_IG64
 
G_M000_IG24:                ;; offset=0x01AA
       mov      rcx, gword ptr [rdi+0x98]
       mov      rdx, gword ptr [rcx+0x88]
       cmp      gword ptr [rdx+0x20], 0
       jne      G_M000_IG61
       mov      rdx, gword ptr [rcx+0x180]
       test     rdx, rdx
       jne      G_M000_IG60
 
G_M000_IG25:                ;; offset=0x01D3
       cmp      esi, dword ptr [rbx+0x08]
       jae      G_M000_IG66
       mov      edx, esi
       lea      rdx, [rdx+4*rdx]
       lea      r13, bword ptr [rbx+8*rdx+0x10]
       mov      ecx, dword ptr [r13+0x18]
       cmp      ecx, dword ptr [rbp]
       jne      SHORT G_M000_IG23
 
G_M000_IG26:                ;; offset=0x01F0
       mov      rcx, gword ptr [rbx+8*rdx+0x10]
       test     rcx, rcx
       je       SHORT G_M000_IG23
 
G_M000_IG27:                ;; offset=0x01FA
       mov      rdx, 0x7FFA02A91030
       cmp      qword ptr [rcx], rdx
       jne      SHORT G_M000_IG23
 
G_M000_IG28:                ;; offset=0x0209
       mov      r12d, r15d
       lea      rdx, [rsp+0x38]
       call     [Lokad.Lython.Runtime.Text.PyString:get_Utf8Span():System.ReadOnlySpan`1[byte]:this]
       mov      eax, dword ptr [rsp+0x40]
       mov      dword ptr [rsp+0x30], eax
       cmp      eax, r12d
       jne      G_M000_IG23
       xor      r12d, r12d
       cmp      r12d, r15d
       jge      G_M000_IG32
 
G_M000_IG29:                ;; offset=0x0234
       mov      rcx, gword ptr [rdi+0x98]
       mov      rdx, gword ptr [rcx+0x88]
       cmp      gword ptr [rdx+0x20], 0
       jne      G_M000_IG63
       mov      rdx, gword ptr [rcx+0x180]
       test     rdx, rdx
       jne      G_M000_IG62
 
G_M000_IG30:                ;; offset=0x025D
       mov      r10d, r15d
       sub      r10d, r12d
       cmp      r10d, 0x1000
       jge      G_M000_IG22
 
G_M000_IG31:                ;; offset=0x0270
       mov      r8d, r12d
       mov      ecx, r10d
       add      r8, rcx
       mov      ecx, r15d
       cmp      r8, rcx
       ja       G_M000_IG58
       mov      ecx, r12d
       add      rcx, r14
       mov      edx, dword ptr [rsp+0x30]
       cmp      r8, rdx
       ja       G_M000_IG58
       mov      edx, r12d
       add      rdx, bword ptr [rsp+0x38]
       mov      dword ptr [rsp+0x34], r10d
       mov      r8d, r10d
       call     [System.SpanHelpers:SequenceEqual(byref,byref,nuint):bool]
       test     eax, eax
       je       G_M000_IG23
       mov      eax, dword ptr [rsp+0x34]
       add      r12d, eax
       cmp      r12d, r15d
       jl       G_M000_IG29
 
G_M000_IG32:                ;; offset=0x02C6
       mov      eax, esi
       jmp      G_M000_IG18
 
G_M000_IG33:                ;; offset=0x02CD
       mov      r8, gword ptr [rdx+0x08]
       lea      r9, bword ptr [rdx+0x28]
       mov      r9d, dword ptr [r9]
       mov      edx, dword ptr [rdx+0x18]
       test     r8, r8
       je       G_M000_IG43
       mov      eax, edx
       add      rax, r9
       mov      r10d, dword ptr [r8+0x08]
       cmp      rax, r10
       ja       G_M000_IG58
       lea      r8, bword ptr [r8+r9+0x10]
       mov      r9d, edx
 
G_M000_IG34:                ;; offset=0x02FE
       jmp      G_M000_IG12
 
G_M000_IG35:                ;; offset=0x0303
       cmp      rdx, rax
       je       G_M000_IG56
       cmp      r9, 32
       jae      G_M000_IG49
 
G_M000_IG36:                ;; offset=0x0316
       cmp      r9, 16
       jae      G_M000_IG52
 
G_M000_IG37:                ;; offset=0x0320
       add      r9, -8
       mov      rax, qword ptr [r14]
       sub      rax, qword ptr [r8]
       mov      rdx, qword ptr [r14+r9]
       sub      rdx, qword ptr [r8+r9]
       or       rdx, rax
       sete     dl
       movzx    rdx, dl
       jmp      G_M000_IG16
 
G_M000_IG38:                ;; offset=0x0340
       add      rdx, 32
       cmp      r8, rdx
       ja       G_M000_IG50
       jmp      G_M000_IG51
 
G_M000_IG39:                ;; offset=0x0352
       mov      r8, gword ptr [rdx+0x08]
       mov      r9d, dword ptr [rdx+0x18]
       test     r8, r8
       jne      SHORT G_M000_IG41
 
G_M000_IG40:                ;; offset=0x035F
       test     r9d, r9d
       jne      G_M000_IG58
       xor      r8, r8
       xor      r9d, r9d
       jmp      SHORT G_M000_IG42
 
G_M000_IG41:                ;; offset=0x0370
       cmp      dword ptr [r8+0x08], r9d
       jb       G_M000_IG58
       add      r8, 16
 
G_M000_IG42:                ;; offset=0x037E
       jmp      G_M000_IG12
 
G_M000_IG43:                ;; offset=0x0383
       or       r9d, edx
       jne      G_M000_IG58
       xor      r8, r8
       xor      r9d, r9d
       jmp      G_M000_IG34
 
G_M000_IG44:                ;; offset=0x0397
       xor      edx, edx
       mov      rax, r9
       and      rax, 2
       je       SHORT G_M000_IG46
 
G_M000_IG45:                ;; offset=0x03A2
       movzx    rdx, word  ptr [r14]
       movzx    r10, word  ptr [r8]
       sub      edx, r10d
 
G_M000_IG46:                ;; offset=0x03AD
       test     r9b, 1
       je       SHORT G_M000_IG48
 
G_M000_IG47:                ;; offset=0x03B3
       movzx    r9, byte  ptr [r14+rax]
       movzx    r8, byte  ptr [r8+rax]
       sub      r9d, r8d
       or       edx, r9d
 
G_M000_IG48:                ;; offset=0x03C3
       test     edx, edx
       sete     dl
       movzx    rdx, dl
       jmp      G_M000_IG16
 
G_M000_IG49:                ;; offset=0x03D0
       xor      edx, edx
       lea      r8, [r9-0x20]
       test     r8, r8
       je       SHORT G_M000_IG51
       vmovups  ymm0, ymmword ptr [r14]
       vpcmpeqb ymm0, ymm0, ymmword ptr [rax]
       vpmovmskb r9d, ymm0
       cmp      r9d, -1
       je       G_M000_IG38
       jmp      G_M000_IG57
 
G_M000_IG50:                ;; offset=0x03F7
       vmovups  ymm0, ymmword ptr [r14+rdx]
       vpcmpeqb ymm0, ymm0, ymmword ptr [rax+rdx]
       vpmovmskb r9d, ymm0
       cmp      r9d, -1
       jne      G_M000_IG57
       jmp      G_M000_IG38
 
G_M000_IG51:                ;; offset=0x0415
       vmovups  ymm0, ymmword ptr [r14+r8]
       vpcmpeqb ymm0, ymm0, ymmword ptr [rax+r8]
       vpmovmskb edx, ymm0
       cmp      edx, -1
       jne      SHORT G_M000_IG57
       jmp      SHORT G_M000_IG56
 
G_M000_IG52:                ;; offset=0x042C
       xor      edx, edx
       add      r9, -16
       je       SHORT G_M000_IG55
       vmovups  xmm0, xmmword ptr [r14]
       vpcmpeqb xmm0, xmm0, xmmword ptr [rax]
       vpmovmskb r8d, xmm0
       cmp      r8d, 0xFFFF
       jne      SHORT G_M000_IG57
 
G_M000_IG53:                ;; offset=0x044A
       add      rdx, 16
       cmp      r9, rdx
       jbe      SHORT G_M000_IG55
 
G_M000_IG54:                ;; offset=0x0453
       vmovups  xmm0, xmmword ptr [r14+rdx]
       vpcmpeqb xmm0, xmm0, xmmword ptr [rax+rdx]
       vpmovmskb r8d, xmm0
       cmp      r8d, 0xFFFF
       jne      SHORT G_M000_IG57
       jmp      SHORT G_M000_IG53
 
G_M000_IG55:                ;; offset=0x046D
       vmovups  xmm0, xmmword ptr [r14+r9]
       vpcmpeqb xmm0, xmm0, xmmword ptr [rax+r9]
       vpmovmskb eax, xmm0
       cmp      eax, 0xFFFF
       jne      SHORT G_M000_IG57
 
G_M000_IG56:                ;; offset=0x0484
       mov      edx, 1
       jmp      G_M000_IG16
 
G_M000_IG57:                ;; offset=0x048E
       xor      edx, edx
       jmp      G_M000_IG16
 
G_M000_IG58:                ;; offset=0x0495
       call     [System.ThrowHelper:ThrowArgumentOutOfRangeException()]
       int3     
 
G_M000_IG59:                ;; offset=0x049C
       xor      edx, edx
       div      edx:eax, ecx
       mov      r8d, edx
       jmp      G_M000_IG21
 
G_M000_IG60:                ;; offset=0x04A8
       cmp      dword ptr [rdx+0x20], 0
       setne    dl
       movzx    rdx, dl
       test     edx, edx
       je       G_M000_IG25
 
G_M000_IG61:                ;; offset=0x04BA
       mov      rdx, gword ptr [rsp+0xB0]
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
       jmp      G_M000_IG25
 
G_M000_IG62:                ;; offset=0x04CD
       cmp      dword ptr [rdx+0x20], 0
       setne    dl
       movzx    rdx, dl
       test     edx, edx
       je       G_M000_IG30
 
G_M000_IG63:                ;; offset=0x04DF
       mov      rdx, gword ptr [rsp+0xB0]
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
       jmp      G_M000_IG30
 
G_M000_IG64:                ;; offset=0x04F2
       mov      eax, -1
 
G_M000_IG65:                ;; offset=0x04F7
       vzeroupper 
       add      rsp, 72
       pop      rbx
       pop      rbp
       pop      rsi
       pop      rdi
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       ret      
 
G_M000_IG66:                ;; offset=0x050B
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
; Total bytes of code 1297

; Assembly listing for method Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteDictionaryLoop(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool (Tier1)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; Tier1 code
; optimized code
; optimized using Synthesized PGO
; rbp based frame
; fully interruptible
; with Synthesized PGO: fgCalledCount is 167872
; 82 inlinees with PGO data; 198 single block inlinees; 6 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       push     r15
       push     r14
       push     r13
       push     r12
       push     rdi
       push     rsi
       push     rbx
       sub      rsp, 696
       lea      rbp, [rsp+0x2F0]
       vxorps   xmm4, xmm4, xmm4
       vmovdqa  xmmword ptr [rbp-0x1A0], xmm4
       mov      rax, -336
 
G_M000_IG306:                ;; offset=0x0031
       vmovdqa  xmmword ptr [rbp+rax-0x40], xmm4
       vmovdqa  xmmword ptr [rbp+rax-0x30], xmm4
       vmovdqa  xmmword ptr [rbp+rax-0x20], xmm4
       add      rax, 48
       jne      SHORT G_M000_IG306
       mov      bword ptr [rbp+0x10], rcx
       mov      gword ptr [rbp+0x18], rdx
       mov      bword ptr [rbp+0x28], r9
       mov      rbx, r8
 
G_M000_IG02:                ;; offset=0x0058
       mov      esi, dword ptr [rcx+0x60]
       mov      eax, dword ptr [r9+0x1C]
       cmp      eax, 51
       ja       SHORT G_M000_IG04
 
G_M000_IG03:                ;; offset=0x0064
       mov      rdx, 0x7FFFFFFFFF9FF
       bt       rdx, rax
       jae      G_M000_IG246
 
G_M000_IG04:                ;; offset=0x0078
       mov      eax, dword ptr [r9+0x14]
 
G_M000_IG05:                ;; offset=0x007C
       cmp      esi, eax
       jne      G_M000_IG244
       mov      rcx, bword ptr [rbp+0x10]
       cmp      gword ptr [rcx+0x40], 0
       jne      G_M000_IG244
       mov      rax, gword ptr [rcx]
       cmp      byte  ptr [rax+0xDD], 0
       jne      G_M000_IG248
 
G_M000_IG06:                ;; offset=0x00A3
       test     rbx, rbx
       je       G_M000_IG247
 
G_M000_IG07:                ;; offset=0x00AC
       cmp      byte  ptr [rbx+0xFF], 0
       jne      G_M000_IG248
       mov      rax, gword ptr [rbx+0x88]
 
G_M000_IG08:                ;; offset=0x00C0
       test     rax, rax
       sete     sil
       movzx    rsi, sil
 
G_M000_IG09:                ;; offset=0x00CB
       test     esi, esi
       je       G_M000_IG241
       mov      rax, gword ptr [rcx+0x20]
       mov      edx, dword ptr [r9+0x10]
       cmp      edx, dword ptr [rax+0x08]
       jae      G_M000_IG272
       shl      rdx, 4
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      rdx, gword ptr [rax]
       mov      r8, 0x2AAC5001D00
       cmp      rdx, gword ptr [r8]
       je       G_M000_IG249
 
G_M000_IG10:                ;; offset=0x0103
       mov      r8, 0x2AAC5001D08
       cmp      rdx, gword ptr [r8]
       je       G_M000_IG250
       cmp      qword ptr [rax+0x08], 0
       jne      G_M000_IG251
 
G_M000_IG11:                ;; offset=0x0121
       test     rdx, rdx
       je       G_M000_IG252
       mov      rax, 0x7FFA02D42798
       cmp      qword ptr [rdx], rax
       jne      G_M000_IG241
 
G_M000_IG12:                ;; offset=0x013D
       mov      gword ptr [rbp-0x1C8], rdx
       mov      rax, gword ptr [rbp-0x1C8]
       mov      rax, gword ptr [rax+0x08]
       mov      rdi, gword ptr [rbp+0x18]
       mov      rdx, gword ptr [rdi+0x98]
       cmp      rax, gword ptr [rdx+0x88]
       jne      G_M000_IG241
       mov      rcx, bword ptr [rbp+0x10]
       mov      esi, dword ptr [rcx+0x18]
       mov      r9, bword ptr [rbp+0x28]
       cmp      dword ptr [r9+0x1C], 68
       jne      G_M000_IG253
       mov      ebx, dword ptr [r9+0x0C]
       mov      rax, gword ptr [rcx]
       mov      rax, gword ptr [rax+0xA0]
       mov      rdx, gword ptr [rcx]
       mov      rdx, gword ptr [rdx+0x88]
       cmp      ebx, dword ptr [rdx+0x08]
       jae      G_M000_IG272
       mov      r8d, ebx
       shl      r8, 5
       lea      rdx, bword ptr [rdx+r8+0x10]
       cmp      dword ptr [rdx+0x1C], 42
       jne      G_M000_IG254
       mov      edx, dword ptr [rdx+0x08]
       mov      r8, 0x7FFA02B18620
       cmp      qword ptr [rax], r8
       jne      G_M000_IG256
       cmp      dword ptr [rax+0x08], edx
       jbe      G_M000_IG255
       mov      r14, gword ptr [rax+8*rdx+0x10]
 
G_M000_IG13:                ;; offset=0x01D8
       mov      gword ptr [rbp-0x1D0], r14
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rcx]
       mov      rdx, gword ptr [rdx+0x88]
       mov      rax, rdx
       lea      r15d, [rsi+0x02]
       mov      dword ptr [rbp-0x1AC], r15d
       mov      r8d, dword ptr [rax+0x08]
       cmp      r15d, r8d
       jae      G_M000_IG272
       mov      r10d, r15d
       shl      r10, 5
       lea      r13, bword ptr [rax+r10+0x10]
       mov      bword ptr [rbp-0x1D8], r13
       mov      rax, rdx
       lea      r10d, [rbx+0x01]
       cmp      r10d, r8d
       jae      G_M000_IG272
       lea      r10d, [rbx+0x01]
       shl      r10, 5
       lea      r12, bword ptr [rax+r10+0x10]
       mov      rax, rdx
       lea      r10d, [rbx+0x02]
       cmp      r10d, r8d
       jae      G_M000_IG272
       lea      r10d, [rbx+0x02]
       shl      r10, 5
       lea      rax, bword ptr [rax+r10+0x10]
       mov      bword ptr [rbp-0x1E0], rax
       mov      rax, gword ptr [rcx]
       mov      rax, gword ptr [rax+0x30]
       mov      r10, rax
       lea      r11d, [rsi+0x04]
       cmp      r11d, r8d
       jae      G_M000_IG272
       mov      r8d, r11d
       shl      r8, 5
       lea      r8, bword ptr [rdx+r8+0x10]
       mov      edx, dword ptr [r8+0x1C]
       cmp      edx, 35
       jg       G_M000_IG258
       cmp      edx, 35
       ja       G_M000_IG257
       mov      r11, 0x7FFFFFFBD
       bt       r11, rdx
       jb       G_M000_IG257
 
G_M000_IG14:                ;; offset=0x02A9
       mov      edx, dword ptr [r8+0x08]
       cmp      edx, dword ptr [r10+0x08]
       jae      G_M000_IG272
       mov      r8, gword ptr [r10+8*rdx+0x10]
       mov      gword ptr [rbp-0x1E8], r8
       mov      edx, dword ptr [r12+0x0C]
       not      edx
       cmp      edx, dword ptr [rax+0x08]
       jae      G_M000_IG272
       mov      r12, gword ptr [rax+8*rdx+0x10]
       mov      rdx, 0x7FFA02A1B3F0
       cmp      qword ptr [r12], rdx
       je       SHORT G_M000_IG16
 
G_M000_IG15:                ;; offset=0x02E8
       mov      rdx, r12
       mov      rcx, 0x7FFA02A1B3F0
       call     CORINFO_HELP_UNBOX
 
G_M000_IG16:                ;; offset=0x02FA
       mov      rax, gword ptr [r12+0x08]
       mov      gword ptr [rbp-0x258], rax
       mov      r12d, dword ptr [r12+0x10]
       mov      dword ptr [rbp-0x14C], r12d
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rcx+0x08]
       mov      r10, bword ptr [rbp-0x1E0]
       mov      r11d, dword ptr [r10+0x0C]
       cmp      r11d, dword ptr [rdx+0x08]
       jae      G_M000_IG272
       shl      r11, 4
       lea      rdx, bword ptr [rdx+r11+0x10]
       mov      r11, gword ptr [rdx]
       mov      r8, 0x2AAC5001D00
       cmp      r11, gword ptr [r8]
       je       G_M000_IG259
 
G_M000_IG17:                ;; offset=0x034E
       mov      r8, gword ptr [rdx]
       mov      r11, 0x2AAC5001D08
       cmp      r8, gword ptr [r11]
       je       G_M000_IG260
       cmp      qword ptr [rdx+0x08], 0
       jne      G_M000_IG261
       mov      r8, gword ptr [rdx]
 
G_M000_IG18:                ;; offset=0x0372
       test     r8, r8
       je       G_M000_IG244
 
G_M000_IG19:                ;; offset=0x037B
       mov      rdx, 0x7FFA02B1FD78
       cmp      qword ptr [r8], rdx
       jne      G_M000_IG244
 
G_M000_IG20:                ;; offset=0x038E
       mov      gword ptr [rbp-0x1F0], r8
       cmp      gword ptr [r8+0x28], 0
       je       G_M000_IG244
       cmp      gword ptr [r8+0x30], 0
       je       G_M000_IG244
       cmp      gword ptr [r8+0x20], 0
       jne      G_M000_IG244
       cmp      dword ptr [r8+0x50], 0
       jne      G_M000_IG244
       mov      rdx, gword ptr [r8+0x10]
       mov      r11, gword ptr [rdi+0x98]
       cmp      rdx, gword ptr [r11+0x88]
       jne      G_M000_IG244
       lea      r11d, [rbx+0x03]
       mov      dword ptr [rbp-0x3C], r11d
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rcx]
       mov      rdx, gword ptr [rdx+0x88]
       cmp      r11d, dword ptr [rdx+0x08]
       jae      G_M000_IG272
       mov      r10d, r11d
       shl      r10, 5
       lea      r10, bword ptr [rdx+r10+0x10]
       mov      bword ptr [rbp-0x1F8], r10
       mov      r10, bword ptr [rbp-0x1F8]
       cmp      dword ptr [r10+0x1C], 47
       sete     dl
       movzx    rdx, dl
       mov      dword ptr [rbp-0x40], edx
       xor      r10d, r10d
       mov      qword ptr [rbp-0x48], r10
 
G_M000_IG21:                ;; offset=0x0428
       test     edx, edx
       je       G_M000_IG28
 
G_M000_IG22:                ;; offset=0x0430
       mov      r10, gword ptr [rcx+0x08]
       mov      r11, bword ptr [rbp-0x1F8]
       mov      r11d, dword ptr [r11+0x10]
       cmp      r11d, dword ptr [r10+0x08]
       jae      G_M000_IG272
       shl      r11, 4
       lea      r10, bword ptr [r10+r11+0x10]
       mov      bword ptr [rbp-0x218], r10
       mov      r11, gword ptr [r10]
       mov      rax, 0x2AAC5001D00
       cmp      r11, gword ptr [rax]
       jne      G_M000_IG262
 
G_M000_IG23:                ;; offset=0x046F
       mov      r10, qword ptr [r10+0x08]
       mov      qword ptr [rbp-0x48], r10
 
G_M000_IG24:                ;; offset=0x0477
       mov      rax, 0xFF80000000000000
       cmp      qword ptr [rbp-0x48], rax
       jl       G_M000_IG244
       mov      rax, 0x80000000000000
       cmp      qword ptr [rbp-0x48], rax
       jge      G_M000_IG244
       mov      rcx, bword ptr [rbp+0x10]
       mov      rax, gword ptr [rcx]
       mov      rax, gword ptr [rax+0x30]
       mov      r11, bword ptr [rbp-0x1F8]
       mov      r10d, dword ptr [r11+0x0C]
       not      r10d
       cmp      r10d, dword ptr [rax+0x08]
       jae      G_M000_IG272
       mov      rax, gword ptr [rax+8*r10+0x10]
       mov      gword ptr [rbp-0x210], rax
       mov      r10, 0x7FFA02A1B3F0
       cmp      qword ptr [rax], r10
       je       SHORT G_M000_IG26
 
G_M000_IG25:                ;; offset=0x04DD
       mov      rdx, rax
       mov      rcx, 0x7FFA02A1B3F0
       call     CORINFO_HELP_UNBOX
       mov      rax, gword ptr [rbp-0x210]
 
G_M000_IG26:                ;; offset=0x04F6
       mov      r10, gword ptr [rax+0x08]
       mov      eax, dword ptr [rax+0x10]
       test     r10, r10
       jne      G_M000_IG267
       movsxd   r10, eax
 
G_M000_IG27:                ;; offset=0x0509
       mov      qword ptr [rbp-0x50], r10
       mov      rcx, bword ptr [rbp+0x10]
       mov      r10, qword ptr [rbp-0x50]
 
G_M000_IG28:                ;; offset=0x0515
       xor      r11, r11
       mov      bword ptr [rbp-0x260], r11
 
G_M000_IG29:                ;; offset=0x051F
       mov      dword ptr [rbp-0x150], r11d
 
G_M000_IG30:                ;; offset=0x0526
       mov      gword ptr [rbp-0x200], r11
 
G_M000_IG31:                ;; offset=0x052D
       mov      dword ptr [rbp-0x54], r11d
 
G_M000_IG32:                ;; offset=0x0531
       mov      dword ptr [rbp-0x58], r11d
 
G_M000_IG33:                ;; offset=0x0535
       mov      dword ptr [rbp-0x5C], r11d
       mov      qword ptr [rbp-0x50], r10
 
G_M000_IG34:                ;; offset=0x053D
       xor      r11, r11
       xor      edx, edx
       xor      rax, rax
       mov      r13, gword ptr [rbp-0x1C8]
       mov      r13d, dword ptr [r13+0x34]
       mov      r10, gword ptr [rbp-0x1C8]
       cmp      r13d, dword ptr [r10+0x30]
       je       G_M000_IG106
 
G_M000_IG35:                ;; offset=0x0560
       mov      r10, gword ptr [rbp-0x1C8]
       mov      r10, gword ptr [r10+0x10]
       test     r10, r10
       je       G_M000_IG143
 
G_M000_IG36:                ;; offset=0x0574
       lea      r13, bword ptr [r10+0x10]
       mov      r10d, dword ptr [r10+0x08]
       mov      bword ptr [rbp-0x270], r13
 
G_M000_IG37:                ;; offset=0x0583
       mov      r13, gword ptr [rbp-0x1C8]
       add      r13, 52
       mov      r12d, dword ptr [r13]
       add      r12d, 4
       mov      dword ptr [rbp-0x6C], r12d
       mov      r14d, dword ptr [r13]
       cmp      r14d, r10d
       ja       G_M000_IG233
       mov      r12d, r14d
       add      r12, bword ptr [rbp-0x270]
       sub      r10d, r14d
       cmp      r10d, 4
       jl       G_M000_IG234
       mov      r10d, dword ptr [r12]
       mov      r12d, dword ptr [rbp-0x6C]
       lea      r14d, [r12+r10]
       mov      dword ptr [r13], r14d
       mov      r14d, dword ptr [r13]
       cmp      r10d, 0x1000
       jg       G_M000_IG145
       mov      r11, gword ptr [rbp-0x1C8]
       mov      rdx, gword ptr [r11+0x10]
       test     rdx, rdx
       je       G_M000_IG144
       mov      r11d, r12d
       mov      r12d, r10d
       add      r12, r11
       mov      r14d, dword ptr [rdx+0x08]
       cmp      r12, r14
       ja       G_M000_IG233
       lea      r11, bword ptr [rdx+r11+0x10]
       mov      edx, r10d
 
G_M000_IG38:                ;; offset=0x0611
       mov      bword ptr [rbp-0x268], r11
       mov      dword ptr [rbp-0x154], edx
 
G_M000_IG39:                ;; offset=0x061E
       mov      r14, bword ptr [rbp-0x268]
       mov      bword ptr [rbp-0x260], r14
       mov      r13d, dword ptr [rbp-0x154]
       mov      dword ptr [rbp-0x150], r13d
       mov      gword ptr [rbp-0x208], rax
       mov      gword ptr [rbp-0x200], rax
       cmp      dword ptr [rbp-0x58], 0
       je       G_M000_IG113
 
G_M000_IG40:                ;; offset=0x0652
       mov      dword ptr [rcx+0x18], ebx
 
G_M000_IG41:                ;; offset=0x0655
       mov      rax, gword ptr [rbp-0x208]
       test     rax, rax
       jne      G_M000_IG229
       mov      dword ptr [rbp-0x160], r13d
       mov      r10, gword ptr [rbp-0x1D0]
       mov      r11, gword ptr [r10+0x18]
       mov      gword ptr [rbp-0x220], r11
       mov      rdx, gword ptr [rdi+0x98]
       mov      r12, gword ptr [rdx+0x88]
       cmp      gword ptr [r12+0x20], 0
       jne      G_M000_IG149
       mov      r12, gword ptr [rdx+0x180]
       test     r12, r12
       jne      G_M000_IG148
 
G_M000_IG42:                ;; offset=0x06A8
       mov      r8, gword ptr [rbp-0x1F0]
       mov      r12, gword ptr [r8+0x28]
       mov      edx, dword ptr [r8+0x4C]
       mov      dword ptr [rbp-0x78], edx
       mov      bword ptr [rbp-0x278], r14
       cmp      edx, 4
       jg       G_M000_IG75
 
G_M000_IG43:                ;; offset=0x06CA
       cmp      dword ptr [rbp-0x160], 8
       jg       G_M000_IG75
 
G_M000_IG44:                ;; offset=0x06D7
       xor      eax, eax
       mov      dword ptr [rbp-0x70], eax
       xor      r11d, r11d
       test     edx, edx
       jle      G_M000_IG206
       jmp      SHORT G_M000_IG46
 
G_M000_IG45:                ;; offset=0x06E9
       inc      r11d
       cmp      r11d, edx
       jge      G_M000_IG206
 
G_M000_IG46:                ;; offset=0x06F5
       cmp      r11d, dword ptr [r12+0x08]
       jae      G_M000_IG238
       lea      r10, [r11+4*r11]
       mov      r10, gword ptr [r12+8*r10+0x10]
       test     r10, r10
       je       SHORT G_M000_IG45
 
G_M000_IG47:                ;; offset=0x070E
       mov      rax, 0x7FFA02A91030
       cmp      qword ptr [r10], rax
       jne      SHORT G_M000_IG45
 
G_M000_IG48:                ;; offset=0x071D
       movzx    rax, byte  ptr [r10+0x24]
       test     eax, eax
       je       G_M000_IG150
 
G_M000_IG49:                ;; offset=0x072A
       cmp      eax, 255
       je       G_M000_IG70
 
G_M000_IG50:                ;; offset=0x0735
       lea      rax, bword ptr [r10+0x28]
       mov      r10d, dword ptr [r10+0x18]
       cmp      r10d, 8
       ja       G_M000_IG233
 
G_M000_IG51:                ;; offset=0x0747
       cmp      r13d, r10d
       jne      SHORT G_M000_IG45
 
G_M000_IG52:                ;; offset=0x074C
       mov      r15, rax
       mov      r10d, r10d
       cmp      r10, 8
       jae      G_M000_IG72
 
G_M000_IG53:                ;; offset=0x075C
       cmp      r10, 4
       jb       G_M000_IG155
 
G_M000_IG54:                ;; offset=0x0766
       add      r10, -4
       mov      qword ptr [rbp-0xA0], r10
       mov      r15d, dword ptr [r14]
       sub      r15d, dword ptr [rax]
       mov      bword ptr [rbp-0x268], r14
       mov      r10d, dword ptr [r14+r10]
       mov      r14, qword ptr [rbp-0xA0]
       sub      r10d, dword ptr [rax+r14]
       or       r10d, r15d
       sete     r10b
       movzx    r10, r10b
 
G_M000_IG55:                ;; offset=0x0798
       test     r10d, r10d
       mov      r14, bword ptr [rbp-0x268]
       je       G_M000_IG45
 
G_M000_IG56:                ;; offset=0x07A8
       mov      r10d, r11d
 
G_M000_IG57:                ;; offset=0x07AB
       mov      byte  ptr [rbp-0x158], 0
       xor      edx, edx
       mov      dword ptr [rbp-0x15C], edx
       test     r10d, r10d
       jl       G_M000_IG207
 
G_M000_IG58:                ;; offset=0x07C3
       mov      eax, r10d
       lea      rax, [rax+4*rax]
       mov      qword ptr [rbp-0x1A8], rax
       lea      r12, bword ptr [r12+8*rax+0x10]
       mov      dword ptr [rbp-0x74], r10d
       mov      edx, r10d
       mov      dword ptr [rbp-0x104], edx
       mov      r11, gword ptr [r12]
       mov      r15, r11
       test     r15, r15
       je       SHORT G_M000_IG60
 
G_M000_IG59:                ;; offset=0x07EF
       mov      rax, 0x7FFA02A91030
       cmp      qword ptr [r15], rax
       jne      G_M000_IG211
 
G_M000_IG60:                ;; offset=0x0802
       mov      r12d, dword ptr [r12+0x18]
       vxorps   xmm0, xmm0, xmm0
       vmovdqu  xmmword ptr [rbp-0x118], xmm0
       mov      r8, gword ptr [rbp-0x1F0]
       cmp      gword ptr [r8+0x20], 0
       jne      G_M000_IG212
       mov      r11, gword ptr [r8+0x30]
       cmp      edx, dword ptr [r11+0x08]
       jae      G_M000_IG238
       mov      eax, edx
       cmp      gword ptr [r11+8*rax+0x10], 0
       jne      G_M000_IG212
 
G_M000_IG61:                ;; offset=0x0841
       mov      rax, gword ptr [r8+0x28]
       cmp      edx, dword ptr [rax+0x08]
       jae      G_M000_IG238
       mov      r11, qword ptr [rbp-0x1A8]
       mov      rax, qword ptr [rax+8*r11+0x20]
       mov      r11, 0xFF80000000000000
       cmp      rax, r11
       jl       G_M000_IG214
       mov      r11, 0x80000000000000
       cmp      rax, r11
       mov      qword ptr [rbp-0x120], rax
       jge      G_M000_IG214
 
G_M000_IG62:                ;; offset=0x0887
       mov      r11, gword ptr [rbp-0x258]
       mov      gword ptr [rbp-0x190], r11
       mov      r10d, dword ptr [rbp-0x14C]
       mov      dword ptr [rbp-0x188], r10d
       lea      rcx, [rbp-0x190]
       call     [System.Numerics.BigInteger:op_Explicit(System.Numerics.BigInteger):long]
       mov      rdx, rax
       add      rdx, qword ptr [rbp-0x120]
       mov      rax, gword ptr [rbp-0x1F0]
       mov      r8d, dword ptr [rax+0x4C]
       mov      dword ptr [rbp-0x124], r8d
       cmp      gword ptr [rax+0x20], 0
       jne      G_M000_IG224
       mov      rcx, gword ptr [rax+0x28]
       mov      r12d, dword ptr [rbp-0x104]
       cmp      r12d, dword ptr [rcx+0x08]
       jae      G_M000_IG238
       mov      r10d, r12d
       lea      r10, [r10+4*r10]
       mov      qword ptr [rcx+8*r10+0x20], rdx
       mov      rcx, gword ptr [rax+0x30]
       cmp      r12d, dword ptr [rcx+0x08]
       jae      G_M000_IG238
       mov      edx, r12d
       xor      r10, r10
       mov      gword ptr [rcx+8*rdx+0x10], r10
 
G_M000_IG63:                ;; offset=0x0911
       mov      rax, gword ptr [rbp-0x1F0]
       mov      r8d, dword ptr [rbp-0x124]
       cmp      dword ptr [rax+0x4C], r8d
       jne      G_M000_IG225
 
G_M000_IG64:                ;; offset=0x0929
       mov      edx, 1
 
G_M000_IG65:                ;; offset=0x092E
       movzx    r11, byte  ptr [rbp-0x158]
       test     r11d, r11d
       jne      G_M000_IG226
 
G_M000_IG66:                ;; offset=0x093F
       test     edx, edx
       je       G_M000_IG235
 
G_M000_IG67:                ;; offset=0x0947
       cmp      dword ptr [rbp-0x40], 0
       je       SHORT G_M000_IG69
 
G_M000_IG68:                ;; offset=0x094D
       mov      r10, qword ptr [rbp-0x50]
       mov      rdx, r10
       add      rdx, qword ptr [rbp-0x48]
       mov      qword ptr [rbp-0x48], rdx
       mov      dword ptr [rbp-0x54], 1
       mov      rdx, 0xFF80000000000000
       cmp      qword ptr [rbp-0x48], rdx
       jl       G_M000_IG236
       mov      rdx, 0x80000000000000
       cmp      qword ptr [rbp-0x48], rdx
       jge      G_M000_IG236
 
G_M000_IG69:                ;; offset=0x098B
       mov      rcx, bword ptr [rbp+0x10]
       mov      dword ptr [rcx+0x18], esi
       mov      r9, bword ptr [rbp+0x28]
       mov      rdx, gword ptr [r9]
       mov      r11, gword ptr [rdi+0x98]
       mov      r10, gword ptr [r11+0x88]
       cmp      gword ptr [r10+0x20], 0
       jne      G_M000_IG232
       mov      r10, gword ptr [r11+0x180]
       test     r10, r10
       mov      gword ptr [rbp-0x298], r10
       mov      gword ptr [rbp-0x250], rdx
       mov      rcx, bword ptr [rbp+0x10]
       je       G_M000_IG34
       jmp      G_M000_IG230
 
G_M000_IG70:                ;; offset=0x09D9
       mov      rax, gword ptr [r10+0x08]
       mov      gword ptr [rbp-0x228], rax
       lea      rax, bword ptr [r10+0x28]
       mov      eax, dword ptr [rax]
       mov      r10d, dword ptr [r10+0x18]
       mov      dword ptr [rbp-0x80], r10d
       cmp      gword ptr [rbp-0x228], 0
       je       G_M000_IG154
       mov      qword ptr [rbp-0x1C0], rax
       mov      eax, r10d
       add      rax, qword ptr [rbp-0x1C0]
       mov      qword ptr [rbp-0x2AC], rax
       mov      rax, gword ptr [rbp-0x228]
       mov      eax, dword ptr [rax+0x08]
       cmp      qword ptr [rbp-0x2AC], rax
       ja       G_M000_IG233
       mov      rax, gword ptr [rbp-0x228]
       mov      r10, qword ptr [rbp-0x1C0]
       lea      rax, bword ptr [rax+r10+0x10]
       mov      r10d, dword ptr [rbp-0x80]
 
G_M000_IG71:                ;; offset=0x0A46
       jmp      G_M000_IG51
 
G_M000_IG72:                ;; offset=0x0A4B
       cmp      r14, r15
       je       G_M000_IG168
       cmp      r10, 32
       jae      G_M000_IG160
 
G_M000_IG73:                ;; offset=0x0A5E
       cmp      r10, 16
       jae      G_M000_IG164
 
G_M000_IG74:                ;; offset=0x0A68
       add      r10, -8
       mov      qword ptr [rbp-0x88], r10
       mov      r15, qword ptr [r14]
       sub      r15, qword ptr [rax]
       mov      qword ptr [rbp-0x2AC], r15
       mov      r10, qword ptr [r14+r10]
       mov      r15, qword ptr [rbp-0x88]
       sub      r10, qword ptr [rax+r15]
       or       r10, qword ptr [rbp-0x2AC]
       sete     r10b
       movzx    r10, r10b
       mov      bword ptr [rbp-0x268], r14
       jmp      G_M000_IG55
 
G_M000_IG75:                ;; offset=0x0AAA
       vxorps   ymm0, ymm0, ymm0
       vmovdqu  ymmword ptr [rbp-0xD0], ymm0
       vxorps   ymm0, ymm0, ymm0
       vmovdqu  ymmword ptr [rbp-0xD0], ymm0
       xor      r10d, r10d
 
G_M000_IG76:                ;; offset=0x0AC5
       mov      dword ptr [rbp-0xD4], r10d
       cmp      r10d, r13d
       jl       G_M000_IG115
 
G_M000_IG77:                ;; offset=0x0AD5
       mov      r10d, dword ptr [rbp-0xB4]
       mov      r11d, r10d
       and      r11d, 3
       mov      dword ptr [rbp-0xE0], r11d
       cmp      r10d, 4
       jae      G_M000_IG142
 
G_M000_IG78:                ;; offset=0x0AF4
       mov      r11d, 0x55F978C
 
G_M000_IG79:                ;; offset=0x0AFA
       lea      r10d, [r11+4*r10]
       cmp      dword ptr [rbp-0xE0], 0
       je       SHORT G_M000_IG83
 
G_M000_IG80:                ;; offset=0x0B07
       imul     r11d, dword ptr [rbp-0xC0], 0xFFFFFFFFC2B2AE3D
       add      r10d, r11d
       rol      r10d, 17
       imul     r10d, r10d, 0x27D4EB2F
       cmp      dword ptr [rbp-0xE0], 1
       jbe      SHORT G_M000_IG83
 
G_M000_IG81:                ;; offset=0x0B29
       imul     r11d, dword ptr [rbp-0xBC], 0xFFFFFFFFC2B2AE3D
       add      r11d, r10d
       rol      r11d, 17
       imul     r10d, r11d, 0x27D4EB2F
       cmp      dword ptr [rbp-0xE0], 2
       jbe      SHORT G_M000_IG83
 
G_M000_IG82:                ;; offset=0x0B4B
       imul     r11d, dword ptr [rbp-0xB8], 0xFFFFFFFFC2B2AE3D
       add      r11d, r10d
       rol      r11d, 17
       imul     r10d, r11d, 0x27D4EB2F
 
G_M000_IG83:                ;; offset=0x0B64
       mov      r11d, r10d
       shr      r11d, 15
       xor      r11d, r10d
       imul     r10d, r11d, 0xFFFFFFFF85EBCA77
       mov      r11d, r10d
       shr      r11d, 13
       xor      r11d, r10d
       imul     r10d, r11d, 0xFFFFFFFFC2B2AE3D
       mov      r11d, r10d
       shr      r11d, 16
       xor      r10d, r11d
       cmp      r10d, -1
       je       G_M000_IG180
 
G_M000_IG84:                ;; offset=0x0B9A
       mov      r11d, r10d
       shr      r11d, 16
       xor      r11d, r10d
       imul     r10d, r11d, 0xFFFFFFFF9E3779B9
       mov      r11d, r10d
       shr      r11d, 16
       xor      r11d, r10d
       mov      r10d, r11d
       test     edx, edx
       je       G_M000_IG181
 
G_M000_IG85:                ;; offset=0x0BC0
       mov      r11d, dword ptr [r12+0x08]
       lea      edx, [r11-0x01]
       test     r11d, edx
       jne      G_M000_IG182
       and      edx, r10d
 
G_M000_IG86:                ;; offset=0x0BD5
       cmp      edx, dword ptr [r12+0x08]
       jae      G_M000_IG238
       mov      edx, edx
       lea      rdx, [rdx+4*rdx]
       mov      r11d, dword ptr [r12+8*rdx+0x30]
       dec      r11d
       mov      dword ptr [rbp-0x7C], r11d
       test     r11d, r11d
       mov      dword ptr [rbp-0x70], r10d
       jl       G_M000_IG206
       jmp      SHORT G_M000_IG88
 
G_M000_IG87:                ;; offset=0x0C01
       mov      r10, bword ptr [rbp-0x2A0]
       mov      r11d, dword ptr [r10+0x1C]
       dec      r11d
       mov      r10d, r11d
       test     r10d, r10d
       mov      dword ptr [rbp-0x7C], r10d
       jl       G_M000_IG206
 
G_M000_IG88:                ;; offset=0x0C1F
       mov      rdx, gword ptr [rdi+0x98]
       mov      r10, gword ptr [rdx+0x88]
       cmp      gword ptr [r10+0x20], 0
       jne      G_M000_IG184
       mov      r10, gword ptr [rdx+0x180]
       test     r10, r10
       jne      G_M000_IG183
 
G_M000_IG89:                ;; offset=0x0C48
       mov      r11d, dword ptr [rbp-0x7C]
       cmp      r11d, dword ptr [r12+0x08]
       jae      G_M000_IG238
       mov      dword ptr [rbp-0x7C], r11d
       mov      edx, r11d
       lea      rdx, [rdx+4*rdx]
       lea      r10, bword ptr [r12+8*rdx+0x10]
       mov      bword ptr [rbp-0x2A0], r10
       mov      eax, dword ptr [rbp-0x70]
       cmp      dword ptr [r10+0x18], eax
       jne      SHORT G_M000_IG87
 
G_M000_IG90:                ;; offset=0x0C77
       mov      rdx, gword ptr [r12+8*rdx+0x10]
       test     rdx, rdx
       je       SHORT G_M000_IG87
 
G_M000_IG91:                ;; offset=0x0C81
       mov      rax, 0x7FFA02A91030
       cmp      qword ptr [rdx], rax
       jne      G_M000_IG87
 
G_M000_IG92:                ;; offset=0x0C94
       mov      rax, rdx
       lea      rdx, [rbp-0xF0]
       mov      rcx, rax
       call     [Lokad.Lython.Runtime.Text.PyString:get_Utf8Span():System.ReadOnlySpan`1[byte]:this]
       mov      eax, dword ptr [rbp-0xE8]
       mov      dword ptr [rbp-0x16C], eax
       cmp      eax, r13d
       jne      G_M000_IG87
       xor      r8d, r8d
 
G_M000_IG93:                ;; offset=0x0CBF
       mov      dword ptr [rbp-0xF4], r8d
       cmp      r8d, dword ptr [rbp-0x160]
       jl       SHORT G_M000_IG95
 
G_M000_IG94:                ;; offset=0x0CCF
       mov      r10d, dword ptr [rbp-0x7C]
       jmp      G_M000_IG57
 
G_M000_IG95:                ;; offset=0x0CD8
       mov      rcx, gword ptr [rdi+0x98]
       mov      rdx, gword ptr [rcx+0x88]
       cmp      gword ptr [rdx+0x20], 0
       jne      G_M000_IG186
       mov      rdx, gword ptr [rcx+0x180]
       test     rdx, rdx
       jne      G_M000_IG185
 
G_M000_IG96:                ;; offset=0x0D01
       mov      r10d, dword ptr [rbp-0x160]
       mov      r8d, dword ptr [rbp-0xF4]
       mov      ecx, r10d
       sub      ecx, r8d
       cmp      ecx, 0x1000
       jge      G_M000_IG102
 
G_M000_IG97:                ;; offset=0x0D21
       mov      dword ptr [rbp-0xF4], r8d
       mov      edx, r8d
       mov      r9d, ecx
       lea      r11, [rdx+r9]
       mov      r8d, r10d
       cmp      r11, r8
       ja       G_M000_IG233
       mov      rax, rdx
       add      rax, bword ptr [rbp-0x278]
       mov      r8d, dword ptr [rbp-0x16C]
       cmp      r11, r8
       ja       G_M000_IG233
       add      rdx, bword ptr [rbp-0xF0]
       mov      r8, rax
       mov      r11, rdx
       cmp      r9, 8
       jae      SHORT G_M000_IG103
 
G_M000_IG98:                ;; offset=0x0D6B
       cmp      r9, 4
       jb       G_M000_IG187
 
G_M000_IG99:                ;; offset=0x0D75
       add      r9, -4
       mov      r8d, dword ptr [rax]
       sub      r8d, dword ptr [rdx]
       mov      eax, dword ptr [rax+r9]
       sub      eax, dword ptr [rdx+r9]
       or       eax, r8d
       sete     al
       movzx    rax, al
 
G_M000_IG100:                ;; offset=0x0D90
       test     eax, eax
       je       G_M000_IG192
 
G_M000_IG101:                ;; offset=0x0D98
       mov      r8d, dword ptr [rbp-0xF4]
       add      r8d, ecx
       jmp      G_M000_IG93
 
G_M000_IG102:                ;; offset=0x0DA7
       mov      ecx, 0x1000
       jmp      G_M000_IG97
 
G_M000_IG103:                ;; offset=0x0DB1
       cmp      r8, r11
       je       SHORT G_M000_IG101
       cmp      r9, 32
       jae      G_M000_IG193
 
G_M000_IG104:                ;; offset=0x0DC0
       cmp      r9, 16
       jae      G_M000_IG200
 
G_M000_IG105:                ;; offset=0x0DCA
       add      r9, -8
       mov      r8, qword ptr [rax]
       sub      r8, qword ptr [rdx]
       mov      r11, qword ptr [rax+r9]
       sub      r11, qword ptr [rdx+r9]
       or       r8, r11
       sete     al
       movzx    rax, al
       jmp      SHORT G_M000_IG100
 
G_M000_IG106:                ;; offset=0x0DE7
       mov      dword ptr [rbp-0x5C], 1
       mov      r9, bword ptr [rbp+0x28]
       mov      edx, dword ptr [r9+0x1C]
       cmp      edx, 51
       jg       SHORT G_M000_IG109
 
G_M000_IG107:                ;; offset=0x0DFB
       cmp      edx, 41
       je       SHORT G_M000_IG111
 
G_M000_IG108:                ;; offset=0x0E00
       add      edx, -49
       cmp      edx, 2
       jbe      SHORT G_M000_IG111
       jmp      G_M000_IG237
 
G_M000_IG109:                ;; offset=0x0E0D
       cmp      edx, 56
       je       SHORT G_M000_IG111
 
G_M000_IG110:                ;; offset=0x0E12
       cmp      edx, 62
       je       SHORT G_M000_IG111
       add      edx, -68
       cmp      edx, 1
       ja       G_M000_IG237
 
G_M000_IG111:                ;; offset=0x0E23
       mov      eax, dword ptr [r9+0x08]
       mov      dword ptr [rcx+0x18], eax
 
G_M000_IG112:                ;; offset=0x0E2A
       mov      dword ptr [rbp-0x60], 1
       jmp      G_M000_IG239
 
G_M000_IG113:                ;; offset=0x0E36
       mov      r12, bword ptr [rbp-0x1D8]
       mov      rdx, gword ptr [r12]
       mov      r10, gword ptr [rdi+0x98]
       mov      r11, gword ptr [r10+0x88]
       cmp      gword ptr [r11+0x20], 0
       jne      G_M000_IG147
       mov      r11, gword ptr [r10+0x180]
       test     r11, r11
       jne      G_M000_IG146
 
G_M000_IG114:                ;; offset=0x0E6A
       mov      dword ptr [rcx+0x18], ebx
       mov      r10, gword ptr [rbp-0x1D0]
       mov      rdx, gword ptr [r10+0x18]
       mov      rcx, gword ptr [rdi+0x98]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.ExecutionState:EnterInterpreterFrame(Lokad.Lython.LythonSourceSpan):this]
       mov      dword ptr [rbp-0x58], 1
       jmp      G_M000_IG41
 
G_M000_IG115:                ;; offset=0x0E93
       mov      r11, gword ptr [rdi+0x98]
       mov      rax, gword ptr [r11+0x88]
       cmp      gword ptr [rax+0x20], 0
       jne      G_M000_IG171
       mov      rax, gword ptr [r11+0x180]
       test     rax, rax
       jne      G_M000_IG170
 
G_M000_IG116:                ;; offset=0x0EBC
       mov      r10d, dword ptr [rbp-0xD4]
       mov      eax, r13d
       sub      eax, r10d
       cmp      eax, 0x1000
       jge      G_M000_IG127
 
G_M000_IG117:                ;; offset=0x0ED4
       mov      dword ptr [rbp-0xD8], eax
       mov      dword ptr [rbp-0xD4], r10d
       mov      r11d, r10d
       mov      qword ptr [rbp-0x1B8], r11
       mov      r10d, eax
       add      r10, r11
       mov      r11d, r13d
       cmp      r10, r11
       ja       G_M000_IG233
       mov      r11, qword ptr [rbp-0x1B8]
       lea      r10, bword ptr [r14+r11]
       mov      bword ptr [rbp-0x280], r10
       mov      bword ptr [rbp-0x288], r10
       mov      r10d, eax
       cmp      r10d, 16
       jl       G_M000_IG123
       jmp      G_M000_IG172
 
G_M000_IG118:                ;; offset=0x0F28
       cmp      r10d, 3
       jne      SHORT G_M000_IG120
 
G_M000_IG119:                ;; offset=0x0F2E
       mov      rax, 0x74F4FA52132C7403
       mov      qword ptr [rbp-0xD0], rax
       mov      rax, 0x50D1B62AEF092FDB
       mov      qword ptr [rbp-0xC8], rax
 
G_M000_IG120:                ;; offset=0x0F50
       imul     eax, dword ptr [rbp-0xC0], 0xFFFFFFFF85EBCA77
       add      eax, dword ptr [rbp-0xD0]
       rol      eax, 13
       imul     eax, eax, 0xFFFFFFFF9E3779B1
       mov      dword ptr [rbp-0xD0], eax
       imul     eax, dword ptr [rbp-0xBC], 0xFFFFFFFF85EBCA77
       add      eax, dword ptr [rbp-0xCC]
       rol      eax, 13
       imul     eax, eax, 0xFFFFFFFF9E3779B1
       mov      dword ptr [rbp-0xCC], eax
       imul     eax, dword ptr [rbp-0xB8], 0xFFFFFFFF85EBCA77
       add      eax, dword ptr [rbp-0xC8]
       rol      eax, 13
       imul     eax, eax, 0xFFFFFFFF9E3779B1
       mov      dword ptr [rbp-0xC8], eax
       imul     r11d, r11d, 0xFFFFFFFF85EBCA77
       add      r11d, dword ptr [rbp-0xC4]
       rol      r11d, 13
       imul     eax, r11d, 0xFFFFFFFF9E3779B1
       mov      dword ptr [rbp-0xC4], eax
       jmp      SHORT G_M000_IG122
 
G_M000_IG121:                ;; offset=0x0FCE
       mov      dword ptr [rbp-0xC0], r11d
 
G_M000_IG122:                ;; offset=0x0FD5
       mov      rax, bword ptr [rbp-0x288]
       add      rax, 4
       mov      r10d, dword ptr [rbp-0x164]
       add      r10d, -4
       mov      bword ptr [rbp-0x288], rax
 
G_M000_IG123:                ;; offset=0x0FF2
       mov      dword ptr [rbp-0x164], r10d
       cmp      r10d, 4
       jl       SHORT G_M000_IG130
 
G_M000_IG124:                ;; offset=0x0FFF
       mov      r11, bword ptr [rbp-0x288]
       mov      r11d, dword ptr [r11]
       mov      r10d, dword ptr [rbp-0xB4]
       lea      eax, [r10+0x01]
       mov      dword ptr [rbp-0xB4], eax
       mov      eax, r10d
       and      eax, 3
       je       SHORT G_M000_IG121
 
G_M000_IG125:                ;; offset=0x1022
       cmp      eax, 1
       jne      SHORT G_M000_IG128
 
G_M000_IG126:                ;; offset=0x1027
       mov      dword ptr [rbp-0xBC], r11d
       jmp      SHORT G_M000_IG122
 
G_M000_IG127:                ;; offset=0x1030
       mov      eax, 0x1000
       jmp      G_M000_IG117
 
G_M000_IG128:                ;; offset=0x103A
       cmp      eax, 2
       jne      G_M000_IG118
 
G_M000_IG129:                ;; offset=0x1043
       mov      dword ptr [rbp-0xB8], r11d
       jmp      SHORT G_M000_IG122
 
G_M000_IG130:                ;; offset=0x104C
       mov      r11, bword ptr [rbp-0x288]
       mov      bword ptr [rbp-0x290], r11
       mov      r10d, dword ptr [rbp-0x164]
       mov      dword ptr [rbp-0x168], r10d
       xor      eax, eax
       test     r10d, r10d
       je       G_M000_IG141
 
G_M000_IG131:                ;; offset=0x1073
       movzx    r11, byte  ptr [r11+rax]
       mov      dword ptr [rbp-0xDC], r11d
       mov      r11d, dword ptr [rbp-0xB4]
       lea      r10d, [r11+0x01]
       mov      dword ptr [rbp-0xB4], r10d
       mov      r10d, r11d
       and      r10d, 3
       je       G_M000_IG139
 
G_M000_IG132:                ;; offset=0x109E
       cmp      r10d, 1
       jne      SHORT G_M000_IG134
 
G_M000_IG133:                ;; offset=0x10A4
       mov      r11d, dword ptr [rbp-0xDC]
       mov      dword ptr [rbp-0xBC], r11d
       jmp      G_M000_IG140
 
G_M000_IG134:                ;; offset=0x10B7
       cmp      r10d, 2
       jne      SHORT G_M000_IG136
 
G_M000_IG135:                ;; offset=0x10BD
       mov      r11d, dword ptr [rbp-0xDC]
       mov      dword ptr [rbp-0xB8], r11d
       jmp      G_M000_IG140
 
G_M000_IG136:                ;; offset=0x10D0
       cmp      r11d, 3
       jne      SHORT G_M000_IG138
 
G_M000_IG137:                ;; offset=0x10D6
       mov      r10, 0x74F4FA52132C7403
       mov      qword ptr [rbp-0xD0], r10
       mov      r10, 0x50D1B62AEF092FDB
       mov      qword ptr [rbp-0xC8], r10
 
G_M000_IG138:                ;; offset=0x10F8
       imul     r10d, dword ptr [rbp-0xC0], 0xFFFFFFFF85EBCA77
       add      r10d, dword ptr [rbp-0xD0]
       rol      r10d, 13
       imul     r10d, r10d, 0xFFFFFFFF9E3779B1
       mov      dword ptr [rbp-0xD0], r10d
       imul     r10d, dword ptr [rbp-0xBC], 0xFFFFFFFF85EBCA77
       add      r10d, dword ptr [rbp-0xCC]
       rol      r10d, 13
       imul     r10d, r10d, 0xFFFFFFFF9E3779B1
       mov      dword ptr [rbp-0xCC], r10d
       imul     r10d, dword ptr [rbp-0xB8], 0xFFFFFFFF85EBCA77
       add      r10d, dword ptr [rbp-0xC8]
       rol      r10d, 13
       imul     r10d, r10d, 0xFFFFFFFF9E3779B1
       mov      dword ptr [rbp-0xC8], r10d
       imul     r10d, dword ptr [rbp-0xDC], 0xFFFFFFFF85EBCA77
       add      r10d, dword ptr [rbp-0xC4]
       rol      r10d, 13
       imul     r10d, r10d, 0xFFFFFFFF9E3779B1
       mov      dword ptr [rbp-0xC4], r10d
       jmp      SHORT G_M000_IG140
 
G_M000_IG139:                ;; offset=0x118A
       mov      r11d, dword ptr [rbp-0xDC]
       mov      dword ptr [rbp-0xC0], r11d
 
G_M000_IG140:                ;; offset=0x1198
       inc      eax
       mov      r10d, dword ptr [rbp-0x168]
       cmp      eax, r10d
       mov      r11, bword ptr [rbp-0x290]
       jl       G_M000_IG131
 
G_M000_IG141:                ;; offset=0x11B1
       mov      r10d, dword ptr [rbp-0xD4]
       add      r10d, dword ptr [rbp-0xD8]
       jmp      G_M000_IG76
 
G_M000_IG142:                ;; offset=0x11C4
       rorx     r11d, dword ptr [rbp-0xD0], 31
       mov      dword ptr [rbp-0x2A4], r11d
       rorx     r11d, dword ptr [rbp-0xCC], 25
       add      r11d, dword ptr [rbp-0x2A4]
       mov      dword ptr [rbp-0x2A4], r11d
       rorx     r11d, dword ptr [rbp-0xC8], 20
       add      r11d, dword ptr [rbp-0x2A4]
       mov      dword ptr [rbp-0x2A4], r11d
       rorx     r11d, dword ptr [rbp-0xC4], 14
       add      r11d, dword ptr [rbp-0x2A4]
       jmp      G_M000_IG79
 
G_M000_IG143:                ;; offset=0x121B
       xor      r13, r13
       mov      bword ptr [rbp-0x270], r13
       xor      r10d, r10d
       jmp      G_M000_IG37
 
G_M000_IG144:                ;; offset=0x122D
       or       r12d, r10d
       jne      G_M000_IG233
       xor      r11, r11
       xor      edx, edx
       jmp      G_M000_IG38
 
G_M000_IG145:                ;; offset=0x1240
       mov      bword ptr [rbp-0x268], r11
       mov      dword ptr [rbp-0x154], edx
       mov      dword ptr [rbp-0x180], r12d
       mov      dword ptr [rbp-0x17C], r14d
       mov      dword ptr [rbp-0x178], r10d
       lea      rdx, [rbp-0x180]
       mov      rcx, gword ptr [rbp-0x1C8]
       call     [Lokad.Lython.Runtime.Text.PyStringOps+CasedWhitespaceIteration:Materialize(System.ValueTuple`3[int,int,int]):Lokad.Lython.Runtime.Text.PyString:this]
       mov      r14, rax
       mov      rax, r14
       mov      rcx, bword ptr [rbp+0x10]
       jmp      G_M000_IG39
 
G_M000_IG146:                ;; offset=0x1285
       cmp      dword ptr [r11+0x20], 0
       setne    r11b
       movzx    r11, r11b
       test     r11d, r11d
       je       G_M000_IG114
 
G_M000_IG147:                ;; offset=0x129B
       mov      rcx, r10
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
       mov      rcx, bword ptr [rbp+0x10]
       jmp      G_M000_IG114
 
G_M000_IG148:                ;; offset=0x12AD
       cmp      dword ptr [r12+0x20], 0
       setne    r12b
       movzx    r12, r12b
       test     r12d, r12d
       jne      SHORT G_M000_IG149
       jmp      G_M000_IG42
 
G_M000_IG149:                ;; offset=0x12C5
       mov      rcx, rdx
       mov      rdx, r11
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
       jmp      G_M000_IG42
 
G_M000_IG150:                ;; offset=0x12D6
       mov      rax, gword ptr [r10+0x08]
       mov      r10d, dword ptr [r10+0x18]
       test     rax, rax
       jne      SHORT G_M000_IG152
 
G_M000_IG151:                ;; offset=0x12E3
       test     r10d, r10d
       jne      G_M000_IG233
       xor      rax, rax
       xor      r10d, r10d
       jmp      SHORT G_M000_IG153
 
G_M000_IG152:                ;; offset=0x12F3
       cmp      dword ptr [rax+0x08], r10d
       jb       G_M000_IG233
       add      rax, 16
 
G_M000_IG153:                ;; offset=0x1301
       jmp      G_M000_IG51
 
G_M000_IG154:                ;; offset=0x1306
       or       eax, r10d
       jne      G_M000_IG233
       xor      rax, rax
       xor      r10d, r10d
       jmp      G_M000_IG71
 
G_M000_IG155:                ;; offset=0x1319
       xor      r15d, r15d
       mov      dword ptr [rbp-0xA4], r15d
       mov      r15, r10
       and      r15, 2
       mov      qword ptr [rbp-0xB0], r15
       test     r15, r15
       je       SHORT G_M000_IG157
 
G_M000_IG156:                ;; offset=0x1336
       mov      bword ptr [rbp-0x268], r14
       movzx    r15, word  ptr [r14]
       mov      dword ptr [rbp-0x2A4], r15d
       movzx    r15, word  ptr [rax]
       movzx    r14, dword ptr [rbp-0x2A4]
       sub      r14d, r15d
       mov      r15d, r14d
       mov      dword ptr [rbp-0xA4], r15d
       mov      r14, bword ptr [rbp-0x268]
 
G_M000_IG157:                ;; offset=0x1368
       test     r10b, 1
       je       SHORT G_M000_IG159
 
G_M000_IG158:                ;; offset=0x136E
       mov      r15, qword ptr [rbp-0xB0]
       movzx    r10, byte  ptr [r14+r15]
       movzx    rax, byte  ptr [rax+r15]
       sub      r10d, eax
       mov      r15d, r10d
       or       r15d, dword ptr [rbp-0xA4]
       mov      dword ptr [rbp-0xA4], r15d
 
G_M000_IG159:                ;; offset=0x1393
       cmp      dword ptr [rbp-0xA4], 0
       sete     r10b
       movzx    r10, r10b
       mov      bword ptr [rbp-0x268], r14
       jmp      G_M000_IG55
 
G_M000_IG160:                ;; offset=0x13AE
       xor      eax, eax
       add      r10, -32
       mov      qword ptr [rbp-0x98], r10
       test     r10, r10
       je       SHORT G_M000_IG163
       vmovups  ymm0, ymmword ptr [r14]
       vpcmpeqb ymm0, ymm0, ymmword ptr [r15]
       vpmovmskb r10d, ymm0
       cmp      r10d, -1
       jne      G_M000_IG169
 
G_M000_IG161:                ;; offset=0x13D8
       add      rax, 32
       cmp      qword ptr [rbp-0x98], rax
       jbe      SHORT G_M000_IG163
 
G_M000_IG162:                ;; offset=0x13E5
       vmovups  ymm0, ymmword ptr [r14+rax]
       vpcmpeqb ymm0, ymm0, ymmword ptr [r15+rax]
       vpmovmskb r10d, ymm0
       cmp      r10d, -1
       jne      G_M000_IG169
       jmp      SHORT G_M000_IG161
 
G_M000_IG163:                ;; offset=0x1401
       mov      r10, qword ptr [rbp-0x98]
       vmovups  ymm0, ymmword ptr [r14+r10]
       vpcmpeqb ymm0, ymm0, ymmword ptr [r15+r10]
       vpmovmskb eax, ymm0
       cmp      eax, -1
       jne      G_M000_IG169
       jmp      SHORT G_M000_IG168
 
G_M000_IG164:                ;; offset=0x1423
       xor      eax, eax
       mov      qword ptr [rbp-0x90], rax
       add      r10, -16
       je       SHORT G_M000_IG167
       vmovups  xmm0, xmmword ptr [r14]
       vpcmpeqb xmm0, xmm0, xmmword ptr [r15]
       vpmovmskb eax, xmm0
       cmp      eax, 0xFFFF
       jne      SHORT G_M000_IG169
 
G_M000_IG165:                ;; offset=0x1447
       mov      rax, qword ptr [rbp-0x90]
       add      rax, 16
       cmp      r10, rax
       jbe      SHORT G_M000_IG167
 
G_M000_IG166:                ;; offset=0x1457
       vmovups  xmm0, xmmword ptr [r14+rax]
       mov      qword ptr [rbp-0x90], rax
       vpcmpeqb xmm0, xmm0, xmmword ptr [r15+rax]
       vpmovmskb eax, xmm0
       cmp      eax, 0xFFFF
       jne      SHORT G_M000_IG169
       jmp      SHORT G_M000_IG165
 
G_M000_IG167:                ;; offset=0x1477
       vmovups  xmm0, xmmword ptr [r14+r10]
       vpcmpeqb xmm0, xmm0, xmmword ptr [r15+r10]
       vpmovmskb eax, xmm0
       cmp      eax, 0xFFFF
       jne      SHORT G_M000_IG169
 
G_M000_IG168:                ;; offset=0x148E
       mov      r10d, 1
       mov      bword ptr [rbp-0x268], r14
       jmp      G_M000_IG55
 
G_M000_IG169:                ;; offset=0x14A0
       xor      r10d, r10d
       mov      bword ptr [rbp-0x268], r14
       jmp      G_M000_IG55
 
G_M000_IG170:                ;; offset=0x14AF
       cmp      dword ptr [rax+0x20], 0
       setne    al
       movzx    rax, al
       test     eax, eax
       je       G_M000_IG116
 
G_M000_IG171:                ;; offset=0x14C1
       mov      rcx, r11
       mov      rdx, gword ptr [rbp-0x220]
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
       mov      edx, dword ptr [rbp-0x78]
       jmp      G_M000_IG116
 
G_M000_IG172:                ;; offset=0x14D9
       cmp      dword ptr [rbp-0xB4], 0
       jne      SHORT G_M000_IG173
       mov      rax, 0x74F4FA52132C7403
       mov      qword ptr [rbp-0xD0], rax
       mov      rax, 0x50D1B62AEF092FDB
       mov      qword ptr [rbp-0xC8], rax
       jmp      SHORT G_M000_IG176
 
G_M000_IG173:                ;; offset=0x1506
       mov      eax, dword ptr [rbp-0xB4]
       and      eax, 3
       dec      eax
       cmp      eax, 2
       ja       SHORT G_M000_IG176
       mov      qword ptr [rbp-0x2AC], rax
       lea      rax, [reloc @RWD00]
       mov      dword ptr [rbp-0x164], r10d
       mov      r11, qword ptr [rbp-0x2AC]
       mov      eax, dword ptr [rax+4*r11]
       lea      r15, G_M000_IG02
       add      rax, r15
       jmp      rax
 
G_M000_IG174:                ;; offset=0x1542
       mov      rax, bword ptr [rbp-0x288]
       jmp      G_M000_IG179
 
G_M000_IG175:                ;; offset=0x154E
       mov      rax, bword ptr [rbp-0x288]
       jmp      G_M000_IG178
 
G_M000_IG176:                ;; offset=0x155A
       cmp      r10d, 16
       jl       G_M000_IG123
       mov      eax, dword ptr [rbp-0xD0]
       mov      r11, bword ptr [rbp-0x288]
       imul     r11d, dword ptr [r11], 0xFFFFFFFF85EBCA77
       add      eax, r11d
       rol      eax, 13
       imul     eax, eax, 0xFFFFFFFF9E3779B1
       mov      dword ptr [rbp-0xD0], eax
       mov      eax, dword ptr [rbp-0xCC]
       mov      r11, bword ptr [rbp-0x288]
       add      r11, 4
       imul     r11d, dword ptr [r11], 0xFFFFFFFF85EBCA77
       add      eax, r11d
       rol      eax, 13
       imul     eax, eax, 0xFFFFFFFF9E3779B1
       mov      dword ptr [rbp-0xCC], eax
       mov      eax, dword ptr [rbp-0xC8]
       mov      r11, bword ptr [rbp-0x288]
       add      r11, 8
       imul     r11d, dword ptr [r11], 0xFFFFFFFF85EBCA77
       add      eax, r11d
       rol      eax, 13
       imul     eax, eax, 0xFFFFFFFF9E3779B1
       mov      dword ptr [rbp-0xC8], eax
       mov      eax, dword ptr [rbp-0xC4]
       mov      r11, bword ptr [rbp-0x288]
       add      r11, 12
       imul     r11d, dword ptr [r11], 0xFFFFFFFF85EBCA77
       add      eax, r11d
       rol      eax, 13
       imul     eax, eax, 0xFFFFFFFF9E3779B1
       mov      dword ptr [rbp-0xC4], eax
       mov      eax, dword ptr [rbp-0xB4]
       add      eax, 4
       mov      dword ptr [rbp-0xB4], eax
       mov      rax, bword ptr [rbp-0x288]
       add      rax, 16
       add      r10d, -16
       mov      bword ptr [rbp-0x288], rax
       jmp      G_M000_IG176
 
G_M000_IG177:                ;; offset=0x1632
       mov      r15, bword ptr [rbp-0x280]
       mov      edx, dword ptr [r15]
       lea      rcx, [rbp-0xD0]
       call     [System.HashCode:Add(int):this]
       add      r15, 4
       mov      r11, r15
       mov      r15d, dword ptr [rbp-0xD8]
       lea      r10d, [r15-0x04]
       mov      rax, r11
       mov      dword ptr [rbp-0x164], r10d
 
G_M000_IG178:                ;; offset=0x1665
       mov      bword ptr [rbp-0x288], rax
       mov      edx, dword ptr [rax]
       lea      rcx, [rbp-0xD0]
       call     [System.HashCode:Add(int):this]
       mov      rax, bword ptr [rbp-0x288]
       add      rax, 4
       mov      r8d, dword ptr [rbp-0x164]
       add      r8d, -4
       mov      dword ptr [rbp-0x164], r8d
 
G_M000_IG179:                ;; offset=0x1698
       mov      bword ptr [rbp-0x288], rax
       mov      edx, dword ptr [rax]
       lea      rcx, [rbp-0xD0]
       call     [System.HashCode:Add(int):this]
       mov      rax, bword ptr [rbp-0x288]
       add      rax, 4
       mov      edx, dword ptr [rbp-0x164]
       add      edx, -4
       mov      bword ptr [rbp-0x288], rax
       mov      r10d, edx
       mov      edx, dword ptr [rbp-0x78]
       jmp      G_M000_IG176
 
G_M000_IG180:                ;; offset=0x16D4
       mov      r10d, -2
       jmp      G_M000_IG84
 
G_M000_IG181:                ;; offset=0x16DF
       mov      dword ptr [rbp-0x70], r10d
       jmp      G_M000_IG206
 
G_M000_IG182:                ;; offset=0x16E8
       mov      dword ptr [rbp-0x70], r10d
       mov      eax, r10d
       xor      edx, edx
       div      edx:eax, r11d
       mov      r10d, dword ptr [rbp-0x70]
       jmp      G_M000_IG86
 
G_M000_IG183:                ;; offset=0x16FD
       cmp      dword ptr [r10+0x20], 0
       setne    r10b
       movzx    r10, r10b
       test     r10d, r10d
       je       G_M000_IG89
 
G_M000_IG184:                ;; offset=0x1713
       mov      rcx, rdx
       mov      rdx, gword ptr [rbp-0x220]
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
       jmp      G_M000_IG89
 
G_M000_IG185:                ;; offset=0x1728
       cmp      dword ptr [rdx+0x20], 0
       setne    dl
       movzx    rdx, dl
       test     edx, edx
       je       G_M000_IG96
 
G_M000_IG186:                ;; offset=0x173A
       mov      rdx, gword ptr [rbp-0x220]
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
       jmp      G_M000_IG96
 
G_M000_IG187:                ;; offset=0x174C
       xor      r11d, r11d
       mov      r8, r9
       and      r8, 2
       mov      qword ptr [rbp-0x100], r8
       test     r8, r8
       je       SHORT G_M000_IG189
 
G_M000_IG188:                ;; offset=0x1762
       movzx    r11, word  ptr [rax]
       mov      dword ptr [rbp-0x2A4], r11d
       movzx    r11, word  ptr [rdx]
       movzx    r8, dword ptr [rbp-0x2A4]
       sub      r8d, r11d
       mov      r11d, r8d
 
G_M000_IG189:                ;; offset=0x177F
       test     r9b, 1
       je       SHORT G_M000_IG191
 
G_M000_IG190:                ;; offset=0x1785
       mov      r8, qword ptr [rbp-0x100]
       movzx    r9, byte  ptr [rax+r8]
       movzx    rax, byte  ptr [rdx+r8]
       sub      r9d, eax
       or       r11d, r9d
 
G_M000_IG191:                ;; offset=0x179C
       test     r11d, r11d
       sete     al
       movzx    rax, al
       jmp      G_M000_IG100
 
G_M000_IG192:                ;; offset=0x17AA
       jmp      G_M000_IG87
 
G_M000_IG193:                ;; offset=0x17AF
       xor      edx, edx
       lea      rax, [r9-0x20]
       test     rax, rax
       je       SHORT G_M000_IG198
       vmovups  ymm0, ymmword ptr [r8]
       vpcmpeqb ymm0, ymm0, ymmword ptr [r11]
       vpmovmskb r9d, ymm0
       cmp      r9d, -1
       je       SHORT G_M000_IG195
 
G_M000_IG194:                ;; offset=0x17CE
       jmp      G_M000_IG87
 
G_M000_IG195:                ;; offset=0x17D3
       add      rdx, 32
       cmp      rax, rdx
       jbe      SHORT G_M000_IG198
 
G_M000_IG196:                ;; offset=0x17DC
       vmovups  ymm0, ymmword ptr [r8+rdx]
       vpcmpeqb ymm0, ymm0, ymmword ptr [r11+rdx]
       vpmovmskb r9d, ymm0
       cmp      r9d, -1
       je       SHORT G_M000_IG195
 
G_M000_IG197:                ;; offset=0x17F2
       jmp      G_M000_IG87
 
G_M000_IG198:                ;; offset=0x17F7
       vmovups  ymm0, ymmword ptr [r8+rax]
       vpcmpeqb ymm0, ymm0, ymmword ptr [r11+rax]
       vpmovmskb edx, ymm0
       cmp      edx, -1
       je       G_M000_IG101
 
G_M000_IG199:                ;; offset=0x1810
       jmp      G_M000_IG87
 
G_M000_IG200:                ;; offset=0x1815
       xor      edx, edx
       add      r9, -16
       je       SHORT G_M000_IG204
       vmovups  xmm0, xmmword ptr [r8]
       vpcmpeqb xmm0, xmm0, xmmword ptr [r11]
       vpmovmskb eax, xmm0
       cmp      eax, 0xFFFF
       je       SHORT G_M000_IG202
 
G_M000_IG201:                ;; offset=0x1832
       jmp      G_M000_IG87
 
G_M000_IG202:                ;; offset=0x1837
       add      rdx, 16
       cmp      r9, rdx
       jbe      SHORT G_M000_IG204
 
G_M000_IG203:                ;; offset=0x1840
       vmovups  xmm0, xmmword ptr [r8+rdx]
       vpcmpeqb xmm0, xmm0, xmmword ptr [r11+rdx]
       vpmovmskb eax, xmm0
       cmp      eax, 0xFFFF
       je       SHORT G_M000_IG202
       jmp      G_M000_IG87
 
G_M000_IG204:                ;; offset=0x185C
       vmovups  xmm0, xmmword ptr [r8+r9]
       vpcmpeqb xmm0, xmm0, xmmword ptr [r11+r9]
       vpmovmskb r8d, xmm0
       cmp      r8d, 0xFFFF
       je       G_M000_IG101
 
G_M000_IG205:                ;; offset=0x1879
       jmp      G_M000_IG87
 
G_M000_IG206:                ;; offset=0x187E
       mov      r10d, -1
       jmp      G_M000_IG57
 
G_M000_IG207:                ;; offset=0x1889
       cmp      r13d, 8
       jle      SHORT G_M000_IG210
 
G_M000_IG208:                ;; offset=0x188F
       mov      r8, gword ptr [rbp-0x1F0]
       mov      r10d, dword ptr [r8+0x4C]
       cmp      r10d, dword ptr [r12+0x08]
       jge      SHORT G_M000_IG210
 
G_M000_IG209:                ;; offset=0x18A1
       mov      r11d, 1
       mov      eax, dword ptr [rbp-0x70]
       mov      edx, eax
       mov      dword ptr [rbp-0x158], r11d
       mov      dword ptr [rbp-0x15C], edx
 
G_M000_IG210:                ;; offset=0x18B9
       xor      eax, eax
       mov      edx, eax
       mov      rax, gword ptr [rbp-0x1F0]
       jmp      G_M000_IG65
 
G_M000_IG211:                ;; offset=0x18C9
       mov      rdx, r11
       mov      rcx, rax
       call     CORINFO_HELP_CHKCASTCLASS
       int3     
 
G_M000_IG212:                ;; offset=0x18D5
       mov      rcx, r8
       call     [Lokad.Lython.Runtime.PyDict:ReadNativeValue(int):System.Object:this]
       mov      gword ptr [rbp-0x230], rax
       test     rax, rax
       jne      SHORT G_M000_IG215
 
G_M000_IG213:                ;; offset=0x18EA
       mov      r8, gword ptr [rbp-0x1F0]
 
G_M000_IG214:                ;; offset=0x18F1
       xor      edx, edx
       mov      rax, r8
       jmp      G_M000_IG65
 
G_M000_IG215:                ;; offset=0x18FB
       mov      rdx, qword ptr [rax]
       mov      rcx, 0x7FFA02A1B3F0
       cmp      rdx, rcx
       je       SHORT G_M000_IG217
 
G_M000_IG216:                ;; offset=0x190D
       mov      r8, gword ptr [rbp-0x1F0]
       jmp      SHORT G_M000_IG214
 
G_M000_IG217:                ;; offset=0x1916
       mov      rcx, 0x7FFA02A1B3F0
       cmp      rdx, rcx
       je       SHORT G_M000_IG219
 
G_M000_IG218:                ;; offset=0x1925
       mov      rdx, rax
       mov      rcx, 0x7FFA02A1B3F0
       call     CORINFO_HELP_UNBOX
       mov      rax, gword ptr [rbp-0x230]
 
G_M000_IG219:                ;; offset=0x193E
       vmovdqu  xmm0, xmmword ptr [rax+0x08]
       vmovdqu  xmmword ptr [rbp-0x118], xmm0
 
G_M000_IG220:                ;; offset=0x194B
       lea      rcx, [rbp-0x118]
       xor      edx, edx
       call     [System.Numerics.BigInteger:GetByteCount(bool):int:this]
       cmp      eax, 8
       jl       SHORT G_M000_IG222
 
G_M000_IG221:                ;; offset=0x195F
       mov      r8, gword ptr [rbp-0x1F0]
       jmp      SHORT G_M000_IG214
 
G_M000_IG222:                ;; offset=0x1968
       vmovdqu  xmm0, xmmword ptr [rbp-0x118]
       vmovdqu  xmmword ptr [rbp-0x190], xmm0
 
G_M000_IG223:                ;; offset=0x1978
       lea      rcx, [rbp-0x190]
       call     [System.Numerics.BigInteger:op_Explicit(System.Numerics.BigInteger):long]
       mov      qword ptr [rbp-0x120], rax
       jmp      G_M000_IG62
 
G_M000_IG224:                ;; offset=0x1991
       vxorps   xmm0, xmm0, xmm0
       vmovdqu  xmmword ptr [rbp-0x138], xmm0
       lea      rcx, [rbp-0x138]
       call     [System.Numerics.BigInteger:.ctor(long):this]
       mov      rcx, 0x7FFA02A1B3F0
       call     CORINFO_HELP_NEWSFAST
       mov      gword ptr [rbp-0x238], rax
       lea      rcx, bword ptr [rax+0x08]
       mov      rdx, gword ptr [rbp-0x138]
       call     CORINFO_HELP_ASSIGN_REF
       mov      r9d, dword ptr [rbp-0x130]
       mov      rcx, gword ptr [rbp-0x238]
       mov      dword ptr [rcx+0x10], r9d
       mov      dword ptr [rsp+0x20], r12d
       xor      r9d, r9d
       mov      dword ptr [rsp+0x28], r9d
       mov      dword ptr [rsp+0x30], 1
       mov      r9, rcx
       mov      rcx, gword ptr [rbp-0x1F0]
       mov      edx, dword ptr [rbp-0x74]
       mov      r8, r15
       call     [Lokad.Lython.Runtime.PyDict:PublishNativeValue(int,System.Object,System.Object,uint,bool,bool):System.Object:this]
       jmp      G_M000_IG63
 
G_M000_IG225:                ;; offset=0x1A12
       inc      dword ptr [rax+0x48]
       jmp      G_M000_IG64
 
G_M000_IG226:                ;; offset=0x1A1A
       mov      r12, gword ptr [rbp-0x1D0]
       mov      rdx, gword ptr [r12+0x18]
       mov      gword ptr [rbp-0x240], rdx
       mov      r8, gword ptr [rdi+0x98]
       mov      gword ptr [rbp-0x248], r8
       cmp      byte  ptr [r8], r8b
       mov      rcx, r8
       call     [Lokad.Lython.Runtime.ExecutionState:get_CanContinue():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG228
 
G_M000_IG227:                ;; offset=0x1A4B
       mov      rcx, gword ptr [rbp-0x248]
       mov      rdx, gword ptr [rbp-0x240]
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
 
G_M000_IG228:                ;; offset=0x1A5F
       mov      bword ptr [rbp-0x1A0], r14
       mov      dword ptr [rbp-0x198], r13d
       lea      rdx, [rbp-0x1A0]
       mov      rcx, gword ptr [rbp-0x1C8]
       call     [Lokad.Lython.Runtime.Text.PyStringOps+CasedWhitespaceIteration:Materialize(System.ReadOnlySpan`1[byte]):Lokad.Lython.Runtime.Text.PyString:this]
       mov      gword ptr [rbp-0x200], rax
       mov      r14, gword ptr [rbp-0x1E8]
       mov      gword ptr [rsp+0x20], r14
       mov      r13, gword ptr [rbp-0x258]
       mov      gword ptr [rbp-0x190], r13
       mov      eax, dword ptr [rbp-0x14C]
       mov      dword ptr [rbp-0x188], eax
       lea      rcx, [rbp-0x190]
       mov      qword ptr [rsp+0x28], rcx
       mov      rcx, gword ptr [rbp-0x1F0]
       mov      r8, gword ptr [rbp-0x200]
       mov      r9d, dword ptr [rbp-0x15C]
       mov      edx, -1
       call     [Lokad.Lython.Runtime.PyDict:TryAccumulateAt(int,Lokad.Lython.Runtime.Text.PyString,uint,System.Object,System.Numerics.BigInteger):bool:this]
       mov      edx, eax
       mov      rax, gword ptr [rbp-0x1F0]
       jmp      G_M000_IG66
 
G_M000_IG229:                ;; offset=0x1AE8
       mov      r14, gword ptr [rbp-0x1E8]
       mov      r13, gword ptr [rbp-0x258]
       mov      gword ptr [rbp-0x190], r13
       mov      r10d, dword ptr [rbp-0x14C]
       mov      dword ptr [rbp-0x188], r10d
       mov      gword ptr [rsp+0x20], rdi
       mov      r11, gword ptr [rbp-0x1D0]
       mov      rdx, gword ptr [r11+0x18]
       mov      gword ptr [rsp+0x28], rdx
       lea      r9, [rbp-0x190]
       mov      rdx, rax
       mov      r8, r14
       mov      rcx, gword ptr [rbp-0x1F0]
       call     [Lokad.Lython.Runtime.PyDict:TryAccumulateWithoutAdmission(Lokad.Lython.Runtime.Text.PyString,System.Object,System.Numerics.BigInteger,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):bool:this]
       mov      edx, eax
       mov      rax, gword ptr [rbp-0x1F0]
       jmp      G_M000_IG66
 
G_M000_IG230:                ;; offset=0x1B48
       mov      r10, gword ptr [rbp-0x298]
       cmp      dword ptr [r10+0x20], 0
       setne    r10b
       movzx    r10, r10b
       test     r10d, r10d
       mov      rdx, gword ptr [rbp-0x250]
       je       G_M000_IG34
 
G_M000_IG231:                ;; offset=0x1B6C
       mov      rcx, r11
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
       mov      rcx, bword ptr [rbp+0x10]
       jmp      G_M000_IG34
 
G_M000_IG232:                ;; offset=0x1B7E
       jmp      SHORT G_M000_IG231
 
G_M000_IG233:                ;; offset=0x1B80
       call     [System.ThrowHelper:ThrowArgumentOutOfRangeException()]
       int3     
 
G_M000_IG234:                ;; offset=0x1B87
       mov      ecx, 40
       call     [System.ThrowHelper:ThrowArgumentOutOfRangeException(int)]
       int3     
 
G_M000_IG235:                ;; offset=0x1B93
       mov      rcx, bword ptr [rbp+0x10]
       mov      r15d, dword ptr [rbp-0x1AC]
       mov      dword ptr [rcx+0x18], r15d
       mov      rcx, bword ptr [rbp+0x10]
       mov      r9, bword ptr [rbp+0x28]
       jmp      G_M000_IG112
 
G_M000_IG236:                ;; offset=0x1BAF
       mov      r15d, dword ptr [rbp-0x3C]
       add      r15d, 2
       mov      rcx, bword ptr [rbp+0x10]
       mov      dword ptr [rcx+0x18], r15d
       mov      r9, bword ptr [rbp+0x28]
       jmp      G_M000_IG112
 
G_M000_IG237:                ;; offset=0x1BC8
       mov      rcx, r9
       mov      rdx, 0x2CAEBCD1498
       call     [Lokad.Lython.Frontend.ExecutableInstruction:InvalidOperand(System.String):System.InvalidOperationException:this]
       mov      rcx, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG238:                ;; offset=0x1BE4
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG239:                ;; offset=0x1BEA
       call     G_M000_IG300
       nop      
 
G_M000_IG240:                ;; offset=0x1BF0
       mov      ebx, dword ptr [rbp-0x60]
       jmp      SHORT G_M000_IG242
 
G_M000_IG241:                ;; offset=0x1BF5
       mov      rcx, bword ptr [rbp+0x10]
       mov      r9, bword ptr [rbp+0x28]
       mov      dword ptr [rsp+0x20], esi
       mov      rdx, gword ptr [rbp+0x18]
       mov      r8, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteOrdinaryDictionaryLoop(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,bool):bool]
       mov      ebx, eax
 
G_M000_IG242:                ;; offset=0x1C10
       movzx    rax, bl
 
G_M000_IG243:                ;; offset=0x1C13
       vzeroupper 
       add      rsp, 696
       pop      rbx
       pop      rsi
       pop      rdi
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG244:                ;; offset=0x1C2A
       xor      eax, eax
 
G_M000_IG245:                ;; offset=0x1C2C
       vzeroupper 
       add      rsp, 696
       pop      rbx
       pop      rsi
       pop      rdi
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG246:                ;; offset=0x1C43
       mov      rcx, r9
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      r9, bword ptr [rbp+0x28]
       jmp      G_M000_IG05
 
G_M000_IG247:                ;; offset=0x1C55
       xor      rax, rax
       jmp      G_M000_IG08
 
G_M000_IG248:                ;; offset=0x1C5C
       xor      esi, esi
       jmp      G_M000_IG09
 
G_M000_IG249:                ;; offset=0x1C63
       mov      rcx, rax
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishInteger():System.Object:this]
       mov      rdx, rax
       jmp      G_M000_IG11
 
G_M000_IG250:                ;; offset=0x1C74
       mov      rcx, rax
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishDouble():System.Object:this]
       mov      rdx, rax
       jmp      G_M000_IG11
 
G_M000_IG251:                ;; offset=0x1C85
       mov      rcx, rax
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishTupleBorrow():System.Object:this]
       mov      rdx, rax
       jmp      G_M000_IG11
 
G_M000_IG252:                ;; offset=0x1C96
       mov      rcx, 0x7FFA0279A220
       call     CORINFO_HELP_NEWSFAST
       mov      rbx, rax
       mov      rcx, rbx
       mov      rdx, 0x2CAEBCCAC98
       call     [System.InvalidOperationException:.ctor(System.String):this]
       mov      rcx, rbx
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG253:                ;; offset=0x1CC4
       mov      rcx, r9
       mov      rdx, 0x2CAEBCD3FC0
       call     [Lokad.Lython.Frontend.ExecutableInstruction:InvalidOperand(System.String):System.InvalidOperationException:this]
       mov      rcx, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG254:                ;; offset=0x1CE0
       mov      rcx, rdx
       mov      rdx, 0x2CAEBCCD488
       call     [Lokad.Lython.Frontend.ExecutableInstruction:InvalidOperand(System.String):System.InvalidOperationException:this]
       mov      rcx, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG255:                ;; offset=0x1CFC
       call     [System.ThrowHelper:ThrowArgumentOutOfRange_IndexMustBeLessException()]
       int3     
 
G_M000_IG256:                ;; offset=0x1D03
       mov      rcx, rax
       mov      r11, 0x7FFA02572728
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       mov      r14, rax
       jmp      G_M000_IG13
 
G_M000_IG257:                ;; offset=0x1D1B
       mov      rcx, r8
       mov      rdx, 0x2CAEBCCD4B8
       call     [Lokad.Lython.Frontend.ExecutableInstruction:InvalidOperand(System.String):System.InvalidOperationException:this]
       mov      rcx, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG258:                ;; offset=0x1D37
       cmp      edx, 64
       je       G_M000_IG14
       cmp      edx, 67
       je       G_M000_IG14
       cmp      edx, 70
       jne      SHORT G_M000_IG257
       jmp      G_M000_IG14
 
G_M000_IG259:                ;; offset=0x1D53
       mov      rcx, rdx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishInteger():System.Object:this]
       mov      r8, rax
       jmp      G_M000_IG18
 
G_M000_IG260:                ;; offset=0x1D64
       mov      rcx, rdx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishDouble():System.Object:this]
       mov      r8, rax
       jmp      G_M000_IG18
 
G_M000_IG261:                ;; offset=0x1D75
       mov      rcx, rdx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishTupleBorrow():System.Object:this]
       mov      r8, rax
       jmp      G_M000_IG18
 
G_M000_IG262:                ;; offset=0x1D86
       cmp      qword ptr [r10+0x08], 0
       jle      SHORT G_M000_IG265
 
G_M000_IG263:                ;; offset=0x1D8D
       mov      rdx, gword ptr [r10]
       mov      rcx, 0x7FFA02C640B8
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG264
       mov      r10, bword ptr [rbp-0x218]
       mov      edx, dword ptr [r10+0x08]
       dec      edx
       lea      r8, [rbp-0x48]
       mov      rcx, rax
       call     [Lokad.Lython.Runtime.PyTuple:TryReadInteger(int,byref):bool:this]
       jmp      SHORT G_M000_IG266
 
G_M000_IG264:                ;; offset=0x1DC0
       mov      r10, bword ptr [rbp-0x218]
 
G_M000_IG265:                ;; offset=0x1DC7
       mov      rcx, gword ptr [r10]
       lea      rdx, [rbp-0x48]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryMachineInteger(System.Object,byref):bool]
 
G_M000_IG266:                ;; offset=0x1DD4
       test     eax, eax
       je       G_M000_IG244
       jmp      G_M000_IG24
 
G_M000_IG267:                ;; offset=0x1DE1
       cmp      dword ptr [r10+0x08], 1
       jle      SHORT G_M000_IG268
       mov      rcx, 0x7FFA02CAEE18
       call     CORINFO_HELP_NEWSFAST
       mov      r13, rax
       call     [System.SR:get_Overflow_Int64():System.String]
       mov      rdx, rax
       mov      rcx, r13
       call     [System.OverflowException:.ctor(System.String):this]
       mov      rcx, r13
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG268:                ;; offset=0x1E15
       cmp      dword ptr [r10+0x08], 0
       jbe      SHORT G_M000_IG272
       mov      r10, qword ptr [r10+0x10]
       mov      qword ptr [rbp-0x68], r10
       neg      r10
       test     eax, eax
       cmovg    r10, qword ptr [rbp-0x68]
       test     r10, r10
       jle      SHORT G_M000_IG269
       test     eax, eax
       jg       SHORT G_M000_IG270
 
G_M000_IG269:                ;; offset=0x1E37
       test     r10, r10
       jge      SHORT G_M000_IG271
       test     eax, eax
       jge      SHORT G_M000_IG271
 
G_M000_IG270:                ;; offset=0x1E40
       jmp      G_M000_IG27
 
G_M000_IG271:                ;; offset=0x1E45
       mov      rcx, 0x7FFA02CAEE18
       call     CORINFO_HELP_NEWSFAST
       mov      rbx, rax
       call     [System.SR:get_Overflow_Int64():System.String]
       mov      rdx, rax
       mov      rcx, rbx
       call     [System.OverflowException:.ctor(System.String):this]
       mov      rcx, rbx
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG272:                ;; offset=0x1E72
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG273:                ;; offset=0x1E78
       sub      rsp, 56
 
G_M000_IG274:                ;; offset=0x1E7C
       cmp      dword ptr [rbp-0x54], 0
       je       SHORT G_M000_IG276
 
G_M000_IG275:                ;; offset=0x1E82
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rcx+0x08]
       mov      r11, bword ptr [rbp-0x1F8]
       mov      eax, dword ptr [r11+0x10]
       cmp      eax, dword ptr [rdx+0x08]
       jae      SHORT G_M000_IG280
       shl      rax, 4
       lea      rbx, bword ptr [rdx+rax+0x10]
       mov      rsi, qword ptr [rbp-0x48]
       mov      rdx, 0x2AAC5001D00
       mov      rdx, gword ptr [rdx]
       mov      rcx, rbx
       call     CORINFO_HELP_ASSIGN_REF
       mov      qword ptr [rbx+0x08], rsi
 
G_M000_IG276:                ;; offset=0x1EC0
       cmp      dword ptr [rbp-0x5C], 0
       je       SHORT G_M000_IG278
 
G_M000_IG277:                ;; offset=0x1EC6
       mov      rcx, bword ptr [rbp+0x10]
       add      rcx, 32
       mov      r9, bword ptr [rbp+0x28]
       mov      edx, dword ptr [r9+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
 
G_M000_IG278:                ;; offset=0x1EDC
       nop      
 
G_M000_IG279:                ;; offset=0x1EDD
       vzeroupper 
       add      rsp, 56
       ret      
 
G_M000_IG280:                ;; offset=0x1EE5
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG281:                ;; offset=0x1EEB
       sub      rsp, 56
 
G_M000_IG282:                ;; offset=0x1EEF
       cmp      gword ptr [rbp-0x200], 0
       jne      SHORT G_M000_IG284
 
G_M000_IG283:                ;; offset=0x1EF9
       cmp      dword ptr [rbp-0x150], 0
       je       G_M000_IG298
 
G_M000_IG284:                ;; offset=0x1F06
       mov      rcx, bword ptr [rbp+0x10]
       mov      rax, gword ptr [rcx+0x08]
       mov      rdx, bword ptr [rbp-0x1E0]
       mov      r8d, dword ptr [rdx+0x1C]
       cmp      r8d, 9
       je       SHORT G_M000_IG286
 
G_M000_IG285:                ;; offset=0x1F1F
       cmp      r8d, 10
       je       SHORT G_M000_IG286
       mov      rcx, rdx
       mov      rdx, 0x2CAEBCD1568
       call     [Lokad.Lython.Frontend.ExecutableInstruction:InvalidOperand(System.String):System.InvalidOperationException:this]
       mov      rcx, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG286:                ;; offset=0x1F41
       mov      edx, dword ptr [rdx+0x14]
       cmp      edx, dword ptr [rax+0x08]
       jae      G_M000_IG296
       shl      rdx, 4
       lea      rdi, bword ptr [rax+rdx+0x10]
       mov      rdx, gword ptr [rbp-0x200]
       cmp      gword ptr [rbp-0x200], 0
       jne      G_M000_IG297
 
G_M000_IG287:                ;; offset=0x1F6B
       mov      ebx, dword ptr [rbp-0x150]
       add      rbx, 128
       mov      rax, gword ptr [rbp-0x1C8]
       cmp      rbx, qword ptr [rax+0x28]
       jle      SHORT G_M000_IG289
 
G_M000_IG288:                ;; offset=0x1F85
       mov      rcx, 0x7FFA0279A220
       call     CORINFO_HELP_NEWSFAST
       mov      rdi, rax
       mov      rcx, rdi
       mov      rdx, 0x2CAEBCD4008
       call     [System.InvalidOperationException:.ctor(System.String):this]
       mov      rcx, rdi
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG289:                ;; offset=0x1FB3
       mov      rax, gword ptr [rbp-0x1C8]
       mov      rsi, gword ptr [rax+0x08]
       mov      rcx, 0x7FFA02A91030
       call     CORINFO_HELP_NEWSFAST
       mov      r14, rax
       mov      dword ptr [r14+0x1C], -1
       cmp      dword ptr [rbp-0x150], 0
       jne      SHORT G_M000_IG291
 
G_M000_IG290:                ;; offset=0x1FE1
       xor      ecx, ecx
       mov      rdx, 0x2CAEBCC6810
       call     [System.ArgumentOutOfRangeException:ThrowNegativeOrZero[int](int,System.String)]
       int3     
 
G_M000_IG291:                ;; offset=0x1FF4
       cmp      dword ptr [rbp-0x150], 8
       jg       SHORT G_M000_IG293
 
G_M000_IG292:                ;; offset=0x1FFD
       mov      edx, dword ptr [rbp-0x150]
       mov      byte  ptr [r14+0x24], dl
       jmp      SHORT G_M000_IG294
 
G_M000_IG293:                ;; offset=0x2009
       mov      edx, dword ptr [rbp-0x150]
       mov      rcx, 0x7FFA027500F0
       call     CORINFO_HELP_NEWARR_1_VC
       mov      rdx, rax
       lea      rcx, bword ptr [r14+0x08]
       call     CORINFO_HELP_ASSIGN_REF
 
G_M000_IG294:                ;; offset=0x202A
       mov      ecx, dword ptr [rbp-0x150]
       mov      dword ptr [r14+0x18], ecx
       lea      rcx, bword ptr [r14+0x10]
       mov      rdx, rsi
       call     CORINFO_HELP_ASSIGN_REF
       lea      rdx, [rbp-0x148]
       mov      rcx, r14
       call     [Lokad.Lython.Runtime.Text.PyString:get_UnpublishedUtf8():System.Span`1[byte]:this]
       mov      rcx, bword ptr [rbp-0x148]
       mov      r8d, dword ptr [rbp-0x140]
       cmp      dword ptr [rbp-0x150], r8d
       jg       SHORT G_M000_IG295
       mov      r8d, dword ptr [rbp-0x150]
       mov      rdx, bword ptr [rbp-0x260]
       call     [System.SpanHelpers:Memmove(byref,byref,nuint)]
       mov      rcx, r14
       mov      edx, dword ptr [rbp-0x150]
       call     [Lokad.Lython.Runtime.Text.PyString:CompleteUnpublishedUtf8(int):this]
       mov      rax, gword ptr [rbp-0x1C8]
       sub      qword ptr [rax+0x28], rbx
       mov      rdx, r14
       jmp      SHORT G_M000_IG297
 
G_M000_IG295:                ;; offset=0x209A
       call     [System.ThrowHelper:ThrowArgumentException_DestinationTooShort()]
       int3     
 
G_M000_IG296:                ;; offset=0x20A1
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG297:                ;; offset=0x20A7
       mov      rcx, rdi
       call     CORINFO_HELP_ASSIGN_REF
       xor      ecx, ecx
       mov      qword ptr [rdi+0x08], rcx
 
G_M000_IG298:                ;; offset=0x20B5
       call     G_M000_IG273
       nop      
 
G_M000_IG299:                ;; offset=0x20BB
       vzeroupper 
       add      rsp, 56
       ret      
 
G_M000_IG300:                ;; offset=0x20C3
       sub      rsp, 56
 
G_M000_IG301:                ;; offset=0x20C7
       cmp      dword ptr [rbp-0x58], 0
       je       SHORT G_M000_IG304
 
G_M000_IG302:                ;; offset=0x20CD
       mov      rdi, gword ptr [rbp+0x18]
       mov      rcx, gword ptr [rdi+0x98]
       mov      rax, qword ptr [rcx+0x160]
       test     rax, rax
       jle      SHORT G_M000_IG304
 
G_M000_IG303:                ;; offset=0x20E4
       dec      rax
       mov      qword ptr [rcx+0x160], rax
 
G_M000_IG304:                ;; offset=0x20EE
       call     G_M000_IG281
       nop      
 
G_M000_IG305:                ;; offset=0x20F4
       vzeroupper 
       add      rsp, 56
       ret      
 
RWD00  	dd	000015DAh ; case G_M000_IG177
       	dd	000014F6h ; case G_M000_IG175
       	dd	000014EAh ; case G_M000_IG174

; Total bytes of code 8444

