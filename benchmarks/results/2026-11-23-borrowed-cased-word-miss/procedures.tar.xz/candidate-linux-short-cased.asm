; Assembly listing for method Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteDictionaryLoop(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool (Instrumented Tier0)
; Emitting BLENDED_CODE for x64 + VEX on Unix
; Instrumented Tier0 code
; rbp based frame
; fully interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 624
       lea      rbp, [rsp+0x270]
       vxorps   xmm8, xmm8, xmm8
       vmovdqa  xmmword ptr [rbp-0x250], xmm8
       vmovdqa  xmmword ptr [rbp-0x240], xmm8
       mov      rax, -480
 
G_M000_IG77:                ;; offset=0x002F
       vmovdqa  xmmword ptr [rbp+rax-0x50], xmm8
       vmovdqa  xmmword ptr [rbp+rax-0x40], xmm8
       vmovdqa  xmmword ptr [rbp+rax-0x30], xmm8
       add      rax, 48
       jne      SHORT G_M000_IG77
       mov      qword ptr [rbp-0x50], rax
       mov      bword ptr [rbp-0x30], rdi
       mov      gword ptr [rbp-0x38], rsi
       mov      gword ptr [rbp-0x40], rdx
       mov      bword ptr [rbp-0x48], rcx
 
G_M000_IG02:                ;; offset=0x005B
       mov      dword ptr [rbp-0x1BC], 0x3E8
       mov      rax, bword ptr [rbp-0x30]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp-0x30]
       lea      rdi, bword ptr [rax+0x20]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:get_LiveExtent():int:this]
       mov      dword ptr [rbp-0x110], eax
       mov      rdi, bword ptr [rbp-0x48]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       cmp      eax, dword ptr [rbp-0x110]
       jne      SHORT G_M000_IG04
       mov      rax, bword ptr [rbp-0x30]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp-0x30]
       lea      rdi, bword ptr [rax+0x20]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:get_HasPendingDisposals():bool:this]
       test     eax, eax
       je       SHORT G_M000_IG05
 
G_M000_IG03:                ;; offset=0x00A9
       mov      rdi, 0x7F020E8AEA70
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG04:                ;; offset=0x00B8
       mov      rdi, 0x7F020E8AEA74
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG24
 
G_M000_IG05:                ;; offset=0x00CC
       mov      rax, bword ptr [rbp-0x30]
       mov      rdi, gword ptr [rax]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_RequiresLocalVariableMirroring():bool:this]
       test     eax, eax
       jne      G_M000_IG11
       cmp      gword ptr [rbp-0x40], 0
       jne      SHORT G_M000_IG06
       mov      dword ptr [rbp-0x1A4], 1
       jmp      SHORT G_M000_IG07
 
G_M000_IG06:                ;; offset=0x00F6
       mov      rdi, 0x7F020E8AEA78
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, gword ptr [rbp-0x40]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:get_MirrorLocalStores():bool:this]
       test     eax, eax
       sete     al
       movzx    rax, al
       mov      dword ptr [rbp-0x1A4], eax
 
G_M000_IG07:                ;; offset=0x011D
       cmp      dword ptr [rbp-0x1A4], 0
       je       SHORT G_M000_IG08
       cmp      gword ptr [rbp-0x40], 0
       jne      SHORT G_M000_IG09
       xor      rax, rax
       mov      gword ptr [rbp-0x1B0], rax
       jmp      SHORT G_M000_IG10
 
G_M000_IG08:                ;; offset=0x0138
       mov      rdi, 0x7F020E8AEA7C
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG11
 
G_M000_IG09:                ;; offset=0x0149
       mov      rdi, 0x7F020E8AEA80
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, gword ptr [rbp-0x40]
       mov      rax, gword ptr [rax+0x88]
       mov      gword ptr [rbp-0x1B0], rax
 
G_M000_IG10:                ;; offset=0x016A
       mov      rdi, 0x7F020E8AEA84
       call     CORINFO_HELP_COUNTPROFILE32
       cmp      gword ptr [rbp-0x1B0], 0
       sete     al
       movzx    rax, al
       mov      dword ptr [rbp-0x114], eax
       jmp      SHORT G_M000_IG12
 
G_M000_IG11:                ;; offset=0x018F
       xor      eax, eax
       mov      dword ptr [rbp-0x114], eax
 
G_M000_IG12:                ;; offset=0x0197
       movzx    rax, byte  ptr [rbp-0x114]
       mov      dword ptr [rbp-0x4C], eax
       cmp      dword ptr [rbp-0x4C], 0
       je       G_M000_IG14
       mov      rax, bword ptr [rbp-0x30]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp-0x30]
       add      rax, 32
       mov      bword ptr [rbp-0x120], rax
       mov      rdi, bword ptr [rbp-0x48]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x1C4], eax
       mov      esi, dword ptr [rbp-0x1C4]
       mov      rdi, bword ptr [rbp-0x120]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:get_Item(int):System.Object:this]
       mov      gword ptr [rbp-0x1D0], rax
       mov      rsi, gword ptr [rbp-0x1D0]
       mov      rdi, 0x7F020E88DB58
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      gword ptr [rbp-0x58], rax
       cmp      gword ptr [rbp-0x58], 0
       je       SHORT G_M000_IG15
       mov      rdi, gword ptr [rbp-0x58]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.Text.PyStringOps+CasedWhitespaceIteration:get_MemoryGovernor():Lokad.Lython.Runtime.MemoryGovernor:this]
       mov      gword ptr [rbp-0x128], rax
       mov      rdi, gword ptr [rbp-0x38]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:get_MemoryGovernor():Lokad.Lython.Runtime.MemoryGovernor:this]
       cmp      rax, gword ptr [rbp-0x128]
       je       SHORT G_M000_IG16
 
G_M000_IG13:                ;; offset=0x0234
       mov      rdi, 0x7F020E8AEA88
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG14:                ;; offset=0x0243
       mov      rdi, 0x7F020E8AEA8C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, bword ptr [rbp-0x30]
       mov      rsi, gword ptr [rbp-0x38]
       mov      rdx, gword ptr [rbp-0x40]
       mov      rcx, bword ptr [rbp-0x48]
       mov      r8d, dword ptr [rbp-0x4C]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteOrdinaryDictionaryLoop(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,bool):bool]
       mov      dword ptr [rbp-0x1C0], eax
       jmp      G_M000_IG51
 
G_M000_IG15:                ;; offset=0x0277
       mov      rdi, 0x7F020E8AEA90
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG14
 
G_M000_IG16:                ;; offset=0x0288
       mov      rax, bword ptr [rbp-0x30]
       mov      eax, dword ptr [rax+0x18]
       mov      dword ptr [rbp-0x5C], eax
       mov      rdi, bword ptr [rbp-0x48]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_DictionaryLoopCallIndex():int:this]
       mov      dword ptr [rbp-0x60], eax
       mov      rax, bword ptr [rbp-0x30]
       mov      rdi, gword ptr [rax]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_CallSites():System.Collections.Generic.IReadOnlyList`1[Lokad.Lython.Frontend.ExecutableCallSite]:this]
       mov      gword ptr [rbp-0x130], rax
       mov      rax, gword ptr [rbp-0x130]
       mov      gword ptr [rbp-0x1B8], rax
       mov      rdi, gword ptr [rbp-0x1B8]
       mov      rsi, 0x7F020E8AEA98
       call     CORINFO_HELP_CLASSPROFILE32
       mov      rax, gword ptr [rbp-0x1B8]
       mov      gword ptr [rbp-0x1D8], rax
       mov      rax, bword ptr [rbp-0x30]
       mov      rdi, gword ptr [rax]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Instructions():Lokad.Lython.Frontend.ExecutableInstruction[]:this]
       mov      ecx, dword ptr [rbp-0x60]
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG53
       mov      edx, ecx
       imul     rdx, rdx, 32
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      rdi, rax
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_CallSiteIndex():int:this]
       mov      dword ptr [rbp-0x1DC], eax
       mov      rdi, gword ptr [rbp-0x1D8]
       mov      esi, dword ptr [rbp-0x1DC]
       mov      r11, 0x7F020C651C10
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       mov      gword ptr [rbp-0x68], rax
       mov      rax, bword ptr [rbp-0x30]
       mov      rdi, gword ptr [rax]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Instructions():Lokad.Lython.Frontend.ExecutableInstruction[]:this]
       mov      ecx, dword ptr [rbp-0x5C]
       add      ecx, 2
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG53
       mov      edx, ecx
       imul     rdx, rdx, 32
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      bword ptr [rbp-0x70], rax
       mov      rax, bword ptr [rbp-0x30]
       mov      rdi, gword ptr [rax]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Instructions():Lokad.Lython.Frontend.ExecutableInstruction[]:this]
       mov      ecx, dword ptr [rbp-0x60]
       inc      ecx
       cmp      ecx, dword ptr [rax+0x08]
 
G_M000_IG17:                ;; offset=0x037E
       jae      G_M000_IG53
       mov      edx, ecx
       imul     rdx, rdx, 32
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      bword ptr [rbp-0x78], rax
       mov      rax, bword ptr [rbp-0x30]
       mov      rdi, gword ptr [rax]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Instructions():Lokad.Lython.Frontend.ExecutableInstruction[]:this]
       mov      ecx, dword ptr [rbp-0x60]
       add      ecx, 2
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG53
       mov      edx, ecx
       imul     rdx, rdx, 32
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      bword ptr [rbp-0x80], rax
       mov      rax, bword ptr [rbp-0x30]
       mov      rdi, gword ptr [rax]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Constants():System.Object[]:this]
       mov      gword ptr [rbp-0x138], rax
       mov      rax, bword ptr [rbp-0x30]
       mov      rdi, gword ptr [rax]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Instructions():Lokad.Lython.Frontend.ExecutableInstruction[]:this]
       mov      ecx, dword ptr [rbp-0x5C]
       add      ecx, 4
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG53
       mov      edx, ecx
       imul     rdx, rdx, 32
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      rdi, rax
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ConstantIndex():int:this]
       mov      rcx, gword ptr [rbp-0x138]
       cmp      eax, dword ptr [rcx+0x08]
       jae      G_M000_IG53
       mov      edx, eax
       lea      rcx, bword ptr [rcx+8*rdx+0x10]
       mov      rax, gword ptr [rcx]
       mov      gword ptr [rbp-0x88], rax
       mov      rax, bword ptr [rbp-0x30]
       mov      rdi, gword ptr [rax]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Constants():System.Object[]:this]
       mov      gword ptr [rbp-0x140], rax
       mov      rdi, bword ptr [rbp-0x78]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_SecondInput():int:this]
       not      eax
       mov      rcx, gword ptr [rbp-0x140]
       cmp      eax, dword ptr [rcx+0x08]
       jae      G_M000_IG53
       mov      edx, eax
 
G_M000_IG18:                ;; offset=0x045D
       lea      rcx, bword ptr [rcx+8*rdx+0x10]
       mov      rax, gword ptr [rcx]
       mov      gword ptr [rbp-0x1E8], rax
       mov      rsi, gword ptr [rbp-0x1E8]
       mov      rdi, 0x7F020E280018
       call     [CORINFO_HELP_UNBOX]
 
G_M000_IG19:                ;; offset=0x0483
       vmovdqu  xmm0, xmmword ptr [rax]
       vmovdqu  xmmword ptr [rbp-0x98], xmm0
 
G_M000_IG20:                ;; offset=0x048F
       mov      rax, bword ptr [rbp-0x30]
       mov      rax, gword ptr [rax+0x08]
       mov      gword ptr [rbp-0x148], rax
       mov      rax, gword ptr [rbp-0x148]
       mov      gword ptr [rbp-0x250], rax
       mov      rdi, bword ptr [rbp-0x80]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_SecondInput():int:this]
       mov      rdx, gword ptr [rbp-0x250]
       cmp      eax, dword ptr [rdx+0x08]
       jae      G_M000_IG53
       mov      ecx, eax
       imul     rcx, rcx, 16
       lea      rcx, bword ptr [rdx+rcx+0x10]
       mov      rdi, rcx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Object():System.Object:this]
       mov      gword ptr [rbp-0x1F0], rax
       mov      rsi, gword ptr [rbp-0x1F0]
       mov      rdi, 0x7F020E560018
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      gword ptr [rbp-0xA0], rax
       cmp      gword ptr [rbp-0xA0], 0
       je       SHORT G_M000_IG22
       mov      rdi, gword ptr [rbp-0xA0]
       mov      rsi, gword ptr [rbp-0x38]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.PyDict:CanAccumulateBorrowedWords(Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG23
 
G_M000_IG21:                ;; offset=0x0520
       mov      rdi, 0x7F020E8AEBA0
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG22:                ;; offset=0x052F
       mov      rdi, 0x7F020E8AEBA4
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG24
 
G_M000_IG23:                ;; offset=0x0543
       mov      eax, dword ptr [rbp-0x60]
       add      eax, 3
       mov      dword ptr [rbp-0xA4], eax
       mov      rax, bword ptr [rbp-0x30]
       mov      rdi, gword ptr [rax]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Instructions():Lokad.Lython.Frontend.ExecutableInstruction[]:this]
       mov      ecx, dword ptr [rbp-0xA4]
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG53
       mov      edx, ecx
       imul     rdx, rdx, 32
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      bword ptr [rbp-0xB0], rax
       mov      rdi, bword ptr [rbp-0xB0]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_OpCode():int:this]
       cmp      eax, 47
       sete     al
       movzx    rax, al
       mov      dword ptr [rbp-0xB4], eax
       xor      eax, eax
       mov      qword ptr [rbp-0xC0], rax
       xor      eax, eax
       mov      qword ptr [rbp-0xC8], rax
       cmp      dword ptr [rbp-0xB4], 0
       je       G_M000_IG29
       mov      rax, bword ptr [rbp-0x30]
       mov      rax, gword ptr [rax+0x08]
       mov      gword ptr [rbp-0x198], rax
       mov      rdi, bword ptr [rbp-0xB0]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      rcx, gword ptr [rbp-0x198]
       cmp      eax, dword ptr [rcx+0x08]
       jae      G_M000_IG53
       mov      edx, eax
       imul     rdx, rdx, 16
       lea      rcx, bword ptr [rcx+rdx+0x10]
       mov      bword ptr [rbp-0x1F8], rcx
       mov      rdi, bword ptr [rbp-0x1F8]
       lea      rsi, [rbp-0xC0]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryReadHistogramTotal(byref,byref):bool]
       test     eax, eax
       jne      SHORT G_M000_IG26
       mov      rdi, 0x7F020E8AEBA8
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG24:                ;; offset=0x061F
       xor      eax, eax
 
G_M000_IG25:                ;; offset=0x0621
       add      rsp, 624
       pop      rbp
       ret      
 
G_M000_IG26:                ;; offset=0x062A
       mov      rdi, 0x7F020E8AEBAC
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp-0x30]
       mov      rdi, gword ptr [rax]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Constants():System.Object[]:this]
       mov      gword ptr [rbp-0x1A0], rax
       mov      rdi, bword ptr [rbp-0xB0]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_SecondInput():int:this]
       not      eax
       mov      rcx, gword ptr [rbp-0x1A0]
       cmp      eax, dword ptr [rcx+0x08]
       jae      G_M000_IG53
       mov      edx, eax
       lea      rcx, bword ptr [rcx+8*rdx+0x10]
       mov      rax, gword ptr [rcx]
       mov      gword ptr [rbp-0x200], rax
       mov      rsi, gword ptr [rbp-0x200]
       mov      rdi, 0x7F020E280018
       call     [CORINFO_HELP_UNBOX]
 
G_M000_IG27:                ;; offset=0x0696
       vmovdqu  xmm0, xmmword ptr [rax]
       vmovdqu  xmmword ptr [rbp-0x210], xmm0
 
G_M000_IG28:                ;; offset=0x06A2
       mov      rdi, gword ptr [rbp-0x210]
       mov      rsi, qword ptr [rbp-0x208]
       call     [System.Numerics.BigInteger:op_Explicit(System.Numerics.BigInteger):long]
       mov      qword ptr [rbp-0xC8], rax
 
G_M000_IG29:                ;; offset=0x06BD
       vxorps   xmm0, xmm0, xmm0
       vmovdqu  xmmword ptr [rbp-0xD8], xmm0
       xor      rax, rax
       mov      gword ptr [rbp-0xE0], rax
       xor      eax, eax
       mov      dword ptr [rbp-0xE4], eax
       xor      eax, eax
       mov      dword ptr [rbp-0xE8], eax
       xor      eax, eax
       mov      dword ptr [rbp-0xEC], eax
 
G_M000_IG30:                ;; offset=0x06EA
       mov      eax, dword ptr [rbp-0x1BC]
       dec      eax
       mov      dword ptr [rbp-0x1BC], eax
       cmp      dword ptr [rbp-0x1BC], 0
       jg       SHORT G_M000_IG32
 
G_M000_IG31:                ;; offset=0x0701
       lea      rdi, [rbp-0x1BC]
       mov      esi, 496
       call     CORINFO_HELP_PATCHPOINT
       jmp      rax
 
G_M000_IG32:                ;; offset=0x0714
       lea      rsi, [rbp-0x100]
       lea      rdx, [rbp-0x108]
       mov      rdi, gword ptr [rbp-0x58]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.Text.PyStringOps+CasedWhitespaceIteration:TryReadWord(byref,byref):bool:this]
       test     eax, eax
       je       G_M000_IG46
 
G_M000_IG33:                ;; offset=0x0736
       vmovdqu  xmm0, xmmword ptr [rbp-0x100]
       vmovdqu  xmmword ptr [rbp-0xD8], xmm0
 
G_M000_IG34:                ;; offset=0x0746
       mov      rax, gword ptr [rbp-0x108]
       mov      gword ptr [rbp-0xE0], rax
       cmp      dword ptr [rbp-0xE8], 0
       jne      SHORT G_M000_IG35
       mov      rdi, bword ptr [rbp-0x70]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x218], rax
       mov      rsi, gword ptr [rbp-0x218]
       mov      rdi, gword ptr [rbp-0x38]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CheckExecution(Lokad.Lython.LythonSourceSpan):this]
       mov      rax, bword ptr [rbp-0x30]
       mov      ecx, dword ptr [rbp-0x60]
       mov      dword ptr [rax+0x18], ecx
       mov      rdi, gword ptr [rbp-0x68]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_CallSpan():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x220], rax
       mov      rsi, gword ptr [rbp-0x220]
       mov      rdi, gword ptr [rbp-0x38]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:EnterInterpreterFrame(Lokad.Lython.LythonSourceSpan):this]
       mov      dword ptr [rbp-0xE8], 1
       jmp      SHORT G_M000_IG36
 
G_M000_IG35:                ;; offset=0x07BD
       mov      rdi, 0x7F020E8AEBB0
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp-0x30]
       mov      ecx, dword ptr [rbp-0x60]
       mov      dword ptr [rax+0x18], ecx
 
G_M000_IG36:                ;; offset=0x07D6
       cmp      gword ptr [rbp-0x108], 0
       je       SHORT G_M000_IG37
       mov      rax, gword ptr [rbp-0x108]
       mov      gword ptr [rbp-0x168], rax
       mov      rdi, gword ptr [rbp-0x68]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_CallSpan():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x228], rax
       mov      rax, gword ptr [rbp-0x228]
       mov      gword ptr [rsp], rax
       mov      rcx, gword ptr [rbp-0x98]
       mov      r8, qword ptr [rbp-0x90]
       mov      rsi, gword ptr [rbp-0x168]
       mov      rdx, gword ptr [rbp-0x88]
       mov      r9, gword ptr [rbp-0x38]
       mov      rdi, gword ptr [rbp-0xA0]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.PyDict:TryAccumulateWithoutAdmission(Lokad.Lython.Runtime.Text.PyString,System.Object,System.Numerics.BigInteger,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):bool:this]
       mov      dword ptr [rbp-0x15C], eax
       jmp      G_M000_IG40
 
G_M000_IG37:                ;; offset=0x0846
       mov      rdi, 0x7F020E8AEBB4
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG38:                ;; offset=0x0855
       vmovdqu  xmm0, xmmword ptr [rbp-0x100]
       vmovdqu  xmmword ptr [rbp-0x158], xmm0
 
G_M000_IG39:                ;; offset=0x0865
       mov      rdi, gword ptr [rbp-0x68]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_CallSpan():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x230], rax
       mov      rax, gword ptr [rbp-0x58]
       mov      gword ptr [rsp+0x10], rax
       lea      rax, [rbp-0xE0]
       mov      qword ptr [rsp+0x18], rax
       mov      rax, gword ptr [rbp-0x230]
       mov      gword ptr [rsp+0x08], rax
       mov      r8, gword ptr [rbp-0x98]
       mov      r9, qword ptr [rbp-0x90]
       mov      rsi, bword ptr [rbp-0x158]
       mov      rdx, qword ptr [rbp-0x150]
       mov      rcx, gword ptr [rbp-0x88]
       mov      rax, gword ptr [rbp-0x38]
       mov      gword ptr [rsp], rax
       mov      rdi, gword ptr [rbp-0xA0]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.PyDict:TryAccumulateBorrowedWord(System.ReadOnlySpan`1[byte],System.Object,System.Numerics.BigInteger,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.Text.PyStringOps+CasedWhitespaceIteration,byref):bool:this]
       mov      dword ptr [rbp-0x15C], eax
 
G_M000_IG40:                ;; offset=0x08D9
       cmp      dword ptr [rbp-0x15C], 0
       jne      SHORT G_M000_IG41
       mov      eax, dword ptr [rbp-0x5C]
       add      eax, 2
       mov      rcx, bword ptr [rbp-0x30]
       mov      dword ptr [rcx+0x18], eax
       mov      dword ptr [rbp-0x10C], 1
       jmp      G_M000_IG48
 
G_M000_IG41:                ;; offset=0x08FE
       cmp      dword ptr [rbp-0xB4], 0
       je       G_M000_IG45
       mov      rax, qword ptr [rbp-0xC0]
       add      rax, qword ptr [rbp-0xC8]
       mov      qword ptr [rbp-0xC0], rax
       mov      dword ptr [rbp-0xE4], 1
       mov      rax, 0xFF80000000000000
       cmp      qword ptr [rbp-0xC0], rax
       jl       SHORT G_M000_IG43
       mov      rax, 0x80000000000000
       cmp      qword ptr [rbp-0xC0], rax
       jl       SHORT G_M000_IG44
 
G_M000_IG42:                ;; offset=0x0950
       mov      rdi, 0x7F020E8AEBB8
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG43:                ;; offset=0x095F
       mov      rdi, 0x7F020E8AEBBC
       call     CORINFO_HELP_COUNTPROFILE32
       mov      eax, dword ptr [rbp-0xA4]
       add      eax, 2
       mov      rcx, bword ptr [rbp-0x30]
       mov      dword ptr [rcx+0x18], eax
       mov      dword ptr [rbp-0x10C], 1
       jmp      G_M000_IG49
 
G_M000_IG44:                ;; offset=0x098D
       mov      rdi, 0x7F020E8AEBC0
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG45:                ;; offset=0x099C
       mov      rdi, 0x7F020E8AEBC4
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp-0x30]
       mov      ecx, dword ptr [rbp-0x5C]
       mov      dword ptr [rax+0x18], ecx
       mov      rdi, bword ptr [rbp-0x48]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x238], rax
       mov      rsi, gword ptr [rbp-0x238]
       mov      rdi, gword ptr [rbp-0x38]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CheckExecution(Lokad.Lython.LythonSourceSpan):this]
       jmp      G_M000_IG30
 
G_M000_IG46:                ;; offset=0x09DE
       mov      rdi, 0x7F020E8AEBC8
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0xEC], 1
       mov      rdi, bword ptr [rbp-0x48]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_TargetIndex():int:this]
       mov      rcx, bword ptr [rbp-0x30]
       mov      dword ptr [rcx+0x18], eax
       mov      dword ptr [rbp-0x10C], 1
 
G_M000_IG47:                ;; offset=0x0A12
       call     G_M000_IG71
       jmp      SHORT G_M000_IG50
 
G_M000_IG48:                ;; offset=0x0A19
       call     G_M000_IG71
       jmp      SHORT G_M000_IG50
 
G_M000_IG49:                ;; offset=0x0A20
       call     G_M000_IG71
       nop      
 
G_M000_IG50:                ;; offset=0x0A26
       mov      rdi, 0x7F020E8AEBF0
       call     CORINFO_HELP_COUNTPROFILE32
       mov      eax, dword ptr [rbp-0x10C]
       mov      dword ptr [rbp-0x1C0], eax
 
G_M000_IG51:                ;; offset=0x0A41
       movzx    rax, byte  ptr [rbp-0x1C0]
 
G_M000_IG52:                ;; offset=0x0A48
       add      rsp, 624
       pop      rbp
       ret      
 
G_M000_IG53:                ;; offset=0x0A51
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG54:                ;; offset=0x0A57
       sub      rsp, 40
 
G_M000_IG55:                ;; offset=0x0A5B
       cmp      dword ptr [rbp-0xE4], 0
       je       SHORT G_M000_IG56
       mov      rdi, 0x7F020E8AEBDC
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp-0x30]
       mov      rax, gword ptr [rax+0x08]
       mov      gword ptr [rbp-0x190], rax
       mov      rdi, bword ptr [rbp-0xB0]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      rcx, gword ptr [rbp-0x190]
       cmp      eax, dword ptr [rcx+0x08]
       jae      G_M000_IG59
       mov      edx, eax
       imul     rdx, rdx, 16
       lea      rcx, bword ptr [rcx+rdx+0x10]
       mov      bword ptr [rbp-0x240], rcx
       mov      rdi, bword ptr [rbp-0x240]
       mov      rsi, qword ptr [rbp-0xC0]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:SetInteger(long):this]
 
G_M000_IG56:                ;; offset=0x0AC5
       cmp      dword ptr [rbp-0xEC], 0
       je       SHORT G_M000_IG57
       mov      rdi, 0x7F020E8AEBE0
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp-0x30]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp-0x30]
       add      rax, 32
       mov      bword ptr [rbp-0x188], rax
       mov      rdi, bword ptr [rbp-0x48]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x244], eax
       mov      esi, dword ptr [rbp-0x244]
       mov      rdi, bword ptr [rbp-0x188]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
 
G_M000_IG57:                ;; offset=0x0B15
       mov      rdi, 0x7F020E8AEBE4
       call     CORINFO_HELP_COUNTPROFILE32
       nop      
 
G_M000_IG58:                ;; offset=0x0B25
       add      rsp, 40
       ret      
 
G_M000_IG59:                ;; offset=0x0B2A
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG60:                ;; offset=0x0B30
       sub      rsp, 40
 
G_M000_IG61:                ;; offset=0x0B34
       cmp      gword ptr [rbp-0xE0], 0
       jne      SHORT G_M000_IG65
       lea      rdi, [rbp-0xD8]
       call     [System.ReadOnlySpan`1[byte]:get_IsEmpty():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG62
       jmp      SHORT G_M000_IG64
 
G_M000_IG62:                ;; offset=0x0B51
       mov      rdi, 0x7F020E8AEBD0
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG67
 
G_M000_IG63:                ;; offset=0x0B65
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG64:                ;; offset=0x0B6B
       mov      rdi, 0x7F020E8AEBD4
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG65:                ;; offset=0x0B7A
       mov      rax, bword ptr [rbp-0x30]
       mov      rax, gword ptr [rax+0x08]
       mov      gword ptr [rbp-0x170], rax
       mov      rdi, bword ptr [rbp-0x80]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ThirdInput():int:this]
       mov      rcx, gword ptr [rbp-0x170]
       cmp      eax, dword ptr [rcx+0x08]
       jae      SHORT G_M000_IG63
       mov      edx, eax
       imul     rdx, rdx, 16
       lea      rcx, bword ptr [rcx+rdx+0x10]
       mov      bword ptr [rbp-0x178], rcx
       mov      rax, gword ptr [rbp-0xE0]
       mov      gword ptr [rbp-0x180], rax
       cmp      gword ptr [rbp-0xE0], 0
       jne      SHORT G_M000_IG66
       mov      rdi, 0x7F020E8AEBD8
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rsi, bword ptr [rbp-0xD8]
       mov      rdx, qword ptr [rbp-0xD0]
       mov      rdi, gword ptr [rbp-0x58]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.Text.PyStringOps+CasedWhitespaceIteration:Materialize(System.ReadOnlySpan`1[byte]):Lokad.Lython.Runtime.Text.PyString:this]
       mov      gword ptr [rbp-0x180], rax
 
G_M000_IG66:                ;; offset=0x0BF9
       mov      rdi, bword ptr [rbp-0x178]
       mov      rsi, gword ptr [rbp-0x180]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:set_Object(System.Object):this]
 
G_M000_IG67:                ;; offset=0x0C0D
       nop      
 
G_M000_IG68:                ;; offset=0x0C0E
       call     G_M000_IG54
       nop      
 
G_M000_IG69:                ;; offset=0x0C14
       mov      rdi, 0x7F020E8AEBE8
       call     CORINFO_HELP_COUNTPROFILE32
       nop      
 
G_M000_IG70:                ;; offset=0x0C24
       add      rsp, 40
       ret      
 
G_M000_IG71:                ;; offset=0x0C29
       sub      rsp, 40
 
G_M000_IG72:                ;; offset=0x0C2D
       cmp      dword ptr [rbp-0xE8], 0
       je       SHORT G_M000_IG73
       mov      rdi, 0x7F020E8AEBCC
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, gword ptr [rbp-0x38]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:LeaveInterpreterFrame():this]
 
G_M000_IG73:                ;; offset=0x0C51
       nop      
 
G_M000_IG74:                ;; offset=0x0C52
       call     G_M000_IG60
       nop      
 
G_M000_IG75:                ;; offset=0x0C58
       mov      rdi, 0x7F020E8AEBEC
       call     CORINFO_HELP_COUNTPROFILE32
       nop      
 
G_M000_IG76:                ;; offset=0x0C68
       add      rsp, 40
       ret      
 
; Total bytes of code 3181

; Assembly listing for method Lokad.Lython.Runtime.PyDict:TryAccumulateBorrowedWord(System.ReadOnlySpan`1[byte],System.Object,System.Numerics.BigInteger,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.Text.PyStringOps+CasedWhitespaceIteration,byref):bool:this (Tier0)
; Emitting BLENDED_CODE for x64 + VEX on Unix
; Tier0 code
; rbp based frame
; partially interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 128
       lea      rbp, [rsp+0x80]
       xor      eax, eax
       mov      qword ptr [rbp-0x58], rax
       vxorps   xmm8, xmm8, xmm8
       vmovdqu  ymmword ptr [rbp-0x50], ymm8
       mov      gword ptr [rbp-0x08], rdi
       mov      bword ptr [rbp-0x18], rsi
       mov      qword ptr [rbp-0x10], rdx
       mov      gword ptr [rbp-0x20], rcx
       mov      gword ptr [rbp-0x30], r8
       mov      qword ptr [rbp-0x28], r9
 
G_M000_IG02:                ;; offset=0x0038
       mov      rdi, gword ptr [rbp+0x10]
       mov      rsi, gword ptr [rbp+0x18]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CheckExecution(Lokad.Lython.LythonSourceSpan):this]
       mov      rax, gword ptr [rbp-0x08]
       mov      rax, gword ptr [rax+0x28]
       mov      gword ptr [rbp-0x38], rax
       lea      rax, [rbp-0x48]
       mov      qword ptr [rsp], rax
       mov      rdx, bword ptr [rbp-0x18]
       mov      rcx, qword ptr [rbp-0x10]
       mov      rax, gword ptr [rbp-0x08]
       mov      esi, dword ptr [rax+0x4C]
       mov      rdi, gword ptr [rbp-0x38]
       mov      r8, gword ptr [rbp+0x10]
       mov      r9, gword ptr [rbp+0x18]
       call     [Lokad.Lython.Runtime.PyDict:FindNativeTextIndex(Lokad.Lython.Runtime.PyDict+NativeKey[],int,System.ReadOnlySpan`1[byte],Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,byref):int]
       mov      dword ptr [rbp-0x3C], eax
       cmp      dword ptr [rbp-0x3C], 0
       jge      SHORT G_M000_IG04
       lea      rdi, [rsp]
       lea      rsi, [rbp-0x30]
       mov      rcx, gword ptr [rsi]
       mov      gword ptr [rsp], rcx
       add      rsi, 8
       add      rdi, 8
       movsq    
       mov      rax, gword ptr [rbp+0x18]
       mov      gword ptr [rsp+0x10], rax
       mov      rax, gword ptr [rbp+0x20]
       mov      gword ptr [rsp+0x18], rax
       mov      rax, bword ptr [rbp+0x28]
       mov      bword ptr [rsp+0x20], rax
       mov      rsi, bword ptr [rbp-0x18]
       mov      rdx, qword ptr [rbp-0x10]
       mov      rdi, gword ptr [rbp-0x08]
       mov      ecx, dword ptr [rbp-0x48]
       mov      r8, gword ptr [rbp-0x20]
       mov      r9, gword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.PyDict:TryAppendBorrowedWord(System.ReadOnlySpan`1[byte],uint,System.Object,System.Numerics.BigInteger,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.Text.PyStringOps+CasedWhitespaceIteration,byref):bool:this]
       nop      
 
G_M000_IG03:                ;; offset=0x00D8
       add      rsp, 128
       pop      rbp
       ret      
 
G_M000_IG04:                ;; offset=0x00E1
       mov      rax, gword ptr [rbp-0x38]
       mov      ecx, dword ptr [rbp-0x3C]
       cmp      ecx, dword ptr [rax+0x08]
       jae      SHORT G_M000_IG06
       mov      edx, ecx
       imul     rdx, rdx, 40
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      bword ptr [rbp-0x50], rax
       mov      rax, bword ptr [rbp-0x50]
       mov      rsi, gword ptr [rax]
       mov      rdi, 0x7F020E2DFBC0
       call     [CORINFO_HELP_CHKCASTCLASS]
       mov      gword ptr [rbp-0x58], rax
       lea      rdi, [rsp]
       lea      rsi, [rbp-0x30]
       mov      rcx, gword ptr [rsi]
       mov      gword ptr [rsp], rcx
       add      rsi, 8
       add      rdi, 8
       movsq    
       mov      rdx, gword ptr [rbp-0x58]
       mov      rax, bword ptr [rbp-0x50]
       mov      ecx, dword ptr [rax+0x18]
       mov      esi, dword ptr [rbp-0x3C]
       mov      rdi, gword ptr [rbp-0x08]
       mov      r8, gword ptr [rbp-0x20]
       call     [Lokad.Lython.Runtime.PyDict:TryAccumulateAt(int,Lokad.Lython.Runtime.Text.PyString,uint,System.Object,System.Numerics.BigInteger):bool:this]
       nop      
 
G_M000_IG05:                ;; offset=0x014D
       add      rsp, 128
       pop      rbp
       ret      
 
G_M000_IG06:                ;; offset=0x0156
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
; Total bytes of code 348

; Assembly listing for method Lokad.Lython.Runtime.PyDict:FindNativeTextIndex(Lokad.Lython.Runtime.PyDict+NativeKey[],int,System.ReadOnlySpan`1[byte],Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,byref):int (Instrumented Tier0)
; Emitting BLENDED_CODE for x64 + VEX on Unix
; Instrumented Tier0 code
; rbp based frame
; fully interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 192
       lea      rbp, [rsp+0xC0]
       vxorps   xmm8, xmm8, xmm8
       vmovdqu  ymmword ptr [rbp-0xB0], ymm8
       vmovdqu  ymmword ptr [rbp-0x90], ymm8
       vmovdqa  xmmword ptr [rbp-0x70], xmm8
       xor      eax, eax
       mov      qword ptr [rbp-0x60], rax
       mov      gword ptr [rbp-0x30], rdi
       mov      dword ptr [rbp-0x34], esi
       mov      bword ptr [rbp-0x48], rdx
       mov      qword ptr [rbp-0x40], rcx
       mov      gword ptr [rbp-0x50], r8
       mov      gword ptr [rbp-0x58], r9
 
G_M000_IG02:                ;; offset=0x0047
       mov      dword ptr [rbp-0xB4], 0x3E8
       cmp      dword ptr [rbp-0x34], 4
       jg       G_M000_IG12
       cmp      dword ptr [rbp-0x40], 8
       jg       SHORT G_M000_IG03
       mov      rax, bword ptr [rbp+0x10]
       xor      ecx, ecx
       mov      dword ptr [rax], ecx
       xor      eax, eax
       mov      dword ptr [rbp-0x5C], eax
       jmp      G_M000_IG09
 
G_M000_IG03:                ;; offset=0x0073
       mov      rdi, 0x7F020E8AEDC8
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG12
 
G_M000_IG04:                ;; offset=0x0087
       mov      rax, gword ptr [rbp-0x30]
       mov      ecx, dword ptr [rbp-0x5C]
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG26
       mov      edx, ecx
       imul     rdx, rdx, 40
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      rsi, gword ptr [rax]
       mov      rdi, 0x7F020E2DFBC0
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      gword ptr [rbp-0x68], rax
       cmp      gword ptr [rbp-0x68], 0
       je       SHORT G_M000_IG08
 
G_M000_IG05:                ;; offset=0x00C0
       vmovdqu  xmm0, xmmword ptr [rbp-0x48]
       vmovdqu  xmmword ptr [rbp-0xB0], xmm0
 
G_M000_IG06:                ;; offset=0x00CD
       mov      rdi, gword ptr [rbp-0x68]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.Text.PyString:get_Utf8Span():System.ReadOnlySpan`1[byte]:this]
       mov      bword ptr [rbp-0xA0], rax
       mov      qword ptr [rbp-0x98], rdx
       mov      rdx, bword ptr [rbp-0xA0]
       mov      rcx, qword ptr [rbp-0x98]
       mov      rdi, bword ptr [rbp-0xB0]
       mov      rsi, qword ptr [rbp-0xA8]
       call     [System.MemoryExtensions:SequenceEqual[byte](System.ReadOnlySpan`1[byte],System.ReadOnlySpan`1[byte]):bool]
       test     eax, eax
       je       SHORT G_M000_IG07
       mov      rdi, 0x7F020E8AEDCC
       call     CORINFO_HELP_COUNTPROFILE32
       mov      eax, dword ptr [rbp-0x5C]
       mov      dword ptr [rbp-0xB8], eax
       jmp      G_M000_IG24
 
G_M000_IG07:                ;; offset=0x012A
       mov      rdi, 0x7F020E8AEDD0
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG08:                ;; offset=0x0139
       mov      rdi, 0x7F020E8AEDD4
       call     CORINFO_HELP_COUNTPROFILE32
       mov      eax, dword ptr [rbp-0x5C]
       inc      eax
       mov      dword ptr [rbp-0x5C], eax
 
G_M000_IG09:                ;; offset=0x0150
       mov      eax, dword ptr [rbp-0xB4]
       dec      eax
       mov      dword ptr [rbp-0xB4], eax
       cmp      dword ptr [rbp-0xB4], 0
       jg       SHORT G_M000_IG11
 
G_M000_IG10:                ;; offset=0x0167
       lea      rdi, [rbp-0xB4]
       mov      esi, 63
       call     CORINFO_HELP_PATCHPOINT
       jmp      rax
 
G_M000_IG11:                ;; offset=0x017A
       mov      eax, dword ptr [rbp-0x5C]
       cmp      eax, dword ptr [rbp-0x34]
       jl       G_M000_IG04
       mov      rdi, 0x7F020E8AEDD8
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG22
 
G_M000_IG12:                ;; offset=0x019A
       vmovdqu  xmm0, xmmword ptr [rbp-0x48]
       vmovdqu  xmmword ptr [rbp-0x90], xmm0
 
G_M000_IG13:                ;; offset=0x01A7
       xor      eax, eax
       mov      gword ptr [rbp-0x70], rax
       mov      rdi, bword ptr [rbp-0x90]
       mov      rsi, qword ptr [rbp-0x88]
       mov      rdx, gword ptr [rbp-0x50]
       mov      rcx, gword ptr [rbp-0x58]
       mov      r8, gword ptr [rbp-0x70]
       call     [Lokad.Lython.Runtime.Text.PyString:HashUtf8(System.ReadOnlySpan`1[byte],Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,System.Threading.CancellationToken):int]
       mov      edi, eax
       call     [Lokad.Lython.Runtime.PyValueComparer:NormalizeHash(int):int]
       mov      edi, eax
       call     [Lokad.Lython.Runtime.PyDict:MixNativeHash(int):uint]
       mov      rcx, bword ptr [rbp+0x10]
       mov      dword ptr [rcx], eax
       cmp      dword ptr [rbp-0x34], 0
       jne      SHORT G_M000_IG14
       mov      rdi, 0x7F020E8AEDDC
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG22
 
G_M000_IG14:                ;; offset=0x01FD
       mov      rax, gword ptr [rbp-0x30]
       mov      esi, dword ptr [rax+0x08]
       mov      rax, bword ptr [rbp+0x10]
       mov      edi, dword ptr [rax]
       call     [Lokad.Lython.Runtime.PyDict:NativeBucket(uint,int):int]
       mov      rcx, gword ptr [rbp-0x30]
       cmp      eax, dword ptr [rcx+0x08]
       jae      G_M000_IG26
       mov      edx, eax
       imul     rdx, rdx, 40
       lea      rcx, bword ptr [rcx+rdx+0x10]
       mov      eax, dword ptr [rcx+0x20]
       dec      eax
       mov      dword ptr [rbp-0x74], eax
       jmp      G_M000_IG19
 
G_M000_IG15:                ;; offset=0x0235
       mov      rdi, gword ptr [rbp-0x50]
       mov      rsi, gword ptr [rbp-0x58]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CheckExecution(Lokad.Lython.LythonSourceSpan):this]
       mov      rax, gword ptr [rbp-0x30]
       mov      ecx, dword ptr [rbp-0x74]
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG26
       mov      edx, ecx
       imul     rdx, rdx, 40
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      eax, dword ptr [rax+0x18]
       mov      rcx, bword ptr [rbp+0x10]
       cmp      eax, dword ptr [rcx]
       jne      G_M000_IG18
       mov      rax, gword ptr [rbp-0x30]
       mov      ecx, dword ptr [rbp-0x74]
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG26
       mov      edx, ecx
       imul     rdx, rdx, 40
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      rsi, gword ptr [rax]
       mov      rdi, 0x7F020E2DFBC0
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      gword ptr [rbp-0x80], rax
       cmp      gword ptr [rbp-0x80], 0
       je       SHORT G_M000_IG17
       mov      rsi, bword ptr [rbp-0x48]
       mov      rdx, qword ptr [rbp-0x40]
       mov      rdi, gword ptr [rbp-0x80]
       mov      rcx, gword ptr [rbp-0x50]
       mov      r8, gword ptr [rbp-0x58]
       call     [Lokad.Lython.Runtime.PyDict:EqualNativeText(Lokad.Lython.Runtime.Text.PyString,System.ReadOnlySpan`1[byte],Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):bool]
       test     eax, eax
       je       SHORT G_M000_IG16
       mov      rdi, 0x7F020E8AEDE0
       call     CORINFO_HELP_COUNTPROFILE32
       mov      eax, dword ptr [rbp-0x74]
       mov      dword ptr [rbp-0xB8], eax
       jmp      G_M000_IG24
 
G_M000_IG16:                ;; offset=0x02E3
       mov      rdi, 0x7F020E8AEDE4
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG18
 
G_M000_IG17:                ;; offset=0x02F4
       mov      rdi, 0x7F020E8AEDE8
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG18:                ;; offset=0x0303
       mov      rdi, 0x7F020E8AEDEC
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, gword ptr [rbp-0x30]
       mov      ecx, dword ptr [rbp-0x74]
       cmp      ecx, dword ptr [rax+0x08]
       jae      SHORT G_M000_IG26
       mov      edx, ecx
       imul     rdx, rdx, 40
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      eax, dword ptr [rax+0x1C]
       dec      eax
       mov      dword ptr [rbp-0x74], eax
 
G_M000_IG19:                ;; offset=0x0331
       mov      eax, dword ptr [rbp-0xB4]
       dec      eax
       mov      dword ptr [rbp-0xB4], eax
       cmp      dword ptr [rbp-0xB4], 0
       jg       SHORT G_M000_IG21
 
G_M000_IG20:                ;; offset=0x0348
       lea      rdi, [rbp-0xB4]
       mov      esi, 210
       call     CORINFO_HELP_PATCHPOINT
       jmp      rax
 
G_M000_IG21:                ;; offset=0x035B
       cmp      dword ptr [rbp-0x74], 0
       jge      G_M000_IG15
       mov      rdi, 0x7F020E8AEDF0
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG22:                ;; offset=0x0374
       mov      eax, -1
 
G_M000_IG23:                ;; offset=0x0379
       add      rsp, 192
       pop      rbp
       ret      
 
G_M000_IG24:                ;; offset=0x0382
       mov      eax, dword ptr [rbp-0xB8]
 
G_M000_IG25:                ;; offset=0x0388
       add      rsp, 192
       pop      rbp
       ret      
 
G_M000_IG26:                ;; offset=0x0391
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
; Total bytes of code 919

; Assembly listing for method Lokad.Lython.Runtime.PyDict:TryAppendBorrowedWord(System.ReadOnlySpan`1[byte],uint,System.Object,System.Numerics.BigInteger,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.Text.PyStringOps+CasedWhitespaceIteration,byref):bool:this (Tier0)
; Emitting BLENDED_CODE for x64 + VEX on Unix
; Tier0 code
; rbp based frame
; partially interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 64
       lea      rbp, [rsp+0x40]
       mov      gword ptr [rbp-0x08], rdi
       mov      bword ptr [rbp-0x18], rsi
       mov      qword ptr [rbp-0x10], rdx
       mov      dword ptr [rbp-0x1C], ecx
       mov      gword ptr [rbp-0x28], r8
       mov      gword ptr [rbp-0x30], r9
 
G_M000_IG02:                ;; offset=0x0021
       cmp      dword ptr [rbp-0x10], 8
       jle      SHORT G_M000_IG03
       mov      rax, gword ptr [rbp-0x08]
       mov      eax, dword ptr [rax+0x4C]
       mov      rcx, gword ptr [rbp-0x08]
       mov      rcx, gword ptr [rcx+0x28]
       cmp      eax, dword ptr [rcx+0x08]
       jne      SHORT G_M000_IG05
 
G_M000_IG03:                ;; offset=0x003B
       xor      eax, eax
 
G_M000_IG04:                ;; offset=0x003D
       add      rsp, 64
       pop      rbp
       ret      
 
G_M000_IG05:                ;; offset=0x0043
       mov      rdi, gword ptr [rbp-0x30]
       mov      rsi, gword ptr [rbp+0x20]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CheckExecution(Lokad.Lython.LythonSourceSpan):this]
       mov      rsi, bword ptr [rbp-0x18]
       mov      rdx, qword ptr [rbp-0x10]
       mov      rdi, gword ptr [rbp+0x28]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.Text.PyStringOps+CasedWhitespaceIteration:Materialize(System.ReadOnlySpan`1[byte]):Lokad.Lython.Runtime.Text.PyString:this]
       mov      rsi, rax
       mov      rdi, bword ptr [rbp+0x30]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       lea      rdi, [rsp]
       lea      rsi, [rbp+0x10]
       mov      rcx, gword ptr [rsi]
       mov      gword ptr [rsp], rcx
       add      rsi, 8
       add      rdi, 8
       movsq    
       mov      rax, bword ptr [rbp+0x30]
       mov      rdx, gword ptr [rax]
       mov      rdi, gword ptr [rbp-0x08]
       mov      ecx, dword ptr [rbp-0x1C]
       mov      r8, gword ptr [rbp-0x28]
       mov      esi, -1
       call     [Lokad.Lython.Runtime.PyDict:TryAccumulateAt(int,Lokad.Lython.Runtime.Text.PyString,uint,System.Object,System.Numerics.BigInteger):bool:this]
       nop      
 
G_M000_IG06:                ;; offset=0x00AA
       add      rsp, 64
       pop      rbp
       ret      
 
; Total bytes of code 176

; Assembly listing for method Lokad.Lython.Runtime.PyDict:TryAccumulateBorrowedWord(System.ReadOnlySpan`1[byte],System.Object,System.Numerics.BigInteger,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.Text.PyStringOps+CasedWhitespaceIteration,byref):bool:this (Instrumented Tier0)
; Emitting BLENDED_CODE for x64 + VEX on Unix
; Instrumented Tier0 code
; rbp based frame
; partially interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 128
       lea      rbp, [rsp+0x80]
       xor      eax, eax
       mov      qword ptr [rbp-0x58], rax
       vxorps   xmm8, xmm8, xmm8
       vmovdqu  ymmword ptr [rbp-0x50], ymm8
       mov      gword ptr [rbp-0x08], rdi
       mov      bword ptr [rbp-0x18], rsi
       mov      qword ptr [rbp-0x10], rdx
       mov      gword ptr [rbp-0x20], rcx
       mov      gword ptr [rbp-0x30], r8
       mov      qword ptr [rbp-0x28], r9
 
G_M000_IG02:                ;; offset=0x0038
       mov      rdi, gword ptr [rbp+0x10]
       mov      rsi, gword ptr [rbp+0x18]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CheckExecution(Lokad.Lython.LythonSourceSpan):this]
       mov      rax, gword ptr [rbp-0x08]
       mov      rax, gword ptr [rax+0x28]
       mov      gword ptr [rbp-0x38], rax
       lea      rax, [rbp-0x48]
       mov      qword ptr [rsp], rax
       mov      rdx, bword ptr [rbp-0x18]
       mov      rcx, qword ptr [rbp-0x10]
       mov      rax, gword ptr [rbp-0x08]
       mov      esi, dword ptr [rax+0x4C]
       mov      rdi, gword ptr [rbp-0x38]
       mov      r8, gword ptr [rbp+0x10]
       mov      r9, gword ptr [rbp+0x18]
       call     [Lokad.Lython.Runtime.PyDict:FindNativeTextIndex(Lokad.Lython.Runtime.PyDict+NativeKey[],int,System.ReadOnlySpan`1[byte],Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,byref):int]
       mov      dword ptr [rbp-0x3C], eax
       cmp      dword ptr [rbp-0x3C], 0
       jge      SHORT G_M000_IG04
       mov      rdi, 0x7F020EDF0A90
       call     CORINFO_HELP_COUNTPROFILE32
       lea      rdi, [rsp]
       lea      rsi, [rbp-0x30]
       mov      rcx, gword ptr [rsi]
       mov      gword ptr [rsp], rcx
       add      rsi, 8
       add      rdi, 8
       movsq    
       mov      rax, gword ptr [rbp+0x18]
       mov      gword ptr [rsp+0x10], rax
       mov      rax, gword ptr [rbp+0x20]
       mov      gword ptr [rsp+0x18], rax
       mov      rax, bword ptr [rbp+0x28]
       mov      bword ptr [rsp+0x20], rax
       mov      rsi, bword ptr [rbp-0x18]
       mov      rdx, qword ptr [rbp-0x10]
       mov      rdi, gword ptr [rbp-0x08]
       mov      ecx, dword ptr [rbp-0x48]
       mov      r8, gword ptr [rbp-0x20]
       mov      r9, gword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.PyDict:TryAppendBorrowedWord(System.ReadOnlySpan`1[byte],uint,System.Object,System.Numerics.BigInteger,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.Text.PyStringOps+CasedWhitespaceIteration,byref):bool:this]
       nop      
 
G_M000_IG03:                ;; offset=0x00E7
       add      rsp, 128
       pop      rbp
       ret      
 
G_M000_IG04:                ;; offset=0x00F0
       mov      rdi, 0x7F020EDF0A94
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, gword ptr [rbp-0x38]
       mov      ecx, dword ptr [rbp-0x3C]
       cmp      ecx, dword ptr [rax+0x08]
       jae      SHORT G_M000_IG06
       mov      edx, ecx
       imul     rdx, rdx, 40
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      bword ptr [rbp-0x50], rax
       mov      rax, bword ptr [rbp-0x50]
       mov      rsi, gword ptr [rax]
       mov      rdi, 0x7F020E2DFBC0
       call     [CORINFO_HELP_CHKCASTCLASS]
       mov      gword ptr [rbp-0x58], rax
       lea      rdi, [rsp]
       lea      rsi, [rbp-0x30]
       mov      rcx, gword ptr [rsi]
       mov      gword ptr [rsp], rcx
       add      rsi, 8
       add      rdi, 8
       movsq    
       mov      rdx, gword ptr [rbp-0x58]
       mov      rax, bword ptr [rbp-0x50]
       mov      ecx, dword ptr [rax+0x18]
       mov      esi, dword ptr [rbp-0x3C]
       mov      rdi, gword ptr [rbp-0x08]
       mov      r8, gword ptr [rbp-0x20]
       call     [Lokad.Lython.Runtime.PyDict:TryAccumulateAt(int,Lokad.Lython.Runtime.Text.PyString,uint,System.Object,System.Numerics.BigInteger):bool:this]
       nop      
 
G_M000_IG05:                ;; offset=0x016B
       add      rsp, 128
       pop      rbp
       ret      
 
G_M000_IG06:                ;; offset=0x0174
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
; Total bytes of code 378

; Assembly listing for method Lokad.Lython.Runtime.PyDict:FindNativeTextIndex(Lokad.Lython.Runtime.PyDict+NativeKey[],int,System.ReadOnlySpan`1[byte],Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,byref):int (Instrumented Tier0)
; Emitting BLENDED_CODE for x64 + VEX on Unix
; Instrumented Tier0 code
; rbp based frame
; fully interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 192
       lea      rbp, [rsp+0xC0]
       vxorps   xmm8, xmm8, xmm8
       vmovdqu  ymmword ptr [rbp-0xB0], ymm8
       vmovdqu  ymmword ptr [rbp-0x90], ymm8
       vmovdqa  xmmword ptr [rbp-0x70], xmm8
       xor      eax, eax
       mov      qword ptr [rbp-0x60], rax
       mov      gword ptr [rbp-0x30], rdi
       mov      dword ptr [rbp-0x34], esi
       mov      bword ptr [rbp-0x48], rdx
       mov      qword ptr [rbp-0x40], rcx
       mov      gword ptr [rbp-0x50], r8
       mov      gword ptr [rbp-0x58], r9
 
G_M000_IG02:                ;; offset=0x0047
       mov      dword ptr [rbp-0xB4], 0x3E8
       cmp      dword ptr [rbp-0x34], 4
       jg       G_M000_IG12
       cmp      dword ptr [rbp-0x40], 8
       jg       SHORT G_M000_IG03
       mov      rax, bword ptr [rbp+0x10]
       xor      ecx, ecx
       mov      dword ptr [rax], ecx
       xor      eax, eax
       mov      dword ptr [rbp-0x5C], eax
       jmp      G_M000_IG09
 
G_M000_IG03:                ;; offset=0x0073
       mov      rdi, 0x7F020E8AEDC8
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG12
 
G_M000_IG04:                ;; offset=0x0087
       mov      rax, gword ptr [rbp-0x30]
       mov      ecx, dword ptr [rbp-0x5C]
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG26
       mov      edx, ecx
       imul     rdx, rdx, 40
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      rsi, gword ptr [rax]
       mov      rdi, 0x7F020E2DFBC0
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      gword ptr [rbp-0x68], rax
       cmp      gword ptr [rbp-0x68], 0
       je       SHORT G_M000_IG08
 
G_M000_IG05:                ;; offset=0x00C0
       vmovdqu  xmm0, xmmword ptr [rbp-0x48]
       vmovdqu  xmmword ptr [rbp-0xB0], xmm0
 
G_M000_IG06:                ;; offset=0x00CD
       mov      rdi, gword ptr [rbp-0x68]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.Text.PyString:get_Utf8Span():System.ReadOnlySpan`1[byte]:this]
       mov      bword ptr [rbp-0xA0], rax
       mov      qword ptr [rbp-0x98], rdx
       mov      rdx, bword ptr [rbp-0xA0]
       mov      rcx, qword ptr [rbp-0x98]
       mov      rdi, bword ptr [rbp-0xB0]
       mov      rsi, qword ptr [rbp-0xA8]
       call     [System.MemoryExtensions:SequenceEqual[byte](System.ReadOnlySpan`1[byte],System.ReadOnlySpan`1[byte]):bool]
       test     eax, eax
       je       SHORT G_M000_IG07
       mov      rdi, 0x7F020E8AEDCC
       call     CORINFO_HELP_COUNTPROFILE32
       mov      eax, dword ptr [rbp-0x5C]
       mov      dword ptr [rbp-0xB8], eax
       jmp      G_M000_IG24
 
G_M000_IG07:                ;; offset=0x012A
       mov      rdi, 0x7F020E8AEDD0
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG08:                ;; offset=0x0139
       mov      rdi, 0x7F020E8AEDD4
       call     CORINFO_HELP_COUNTPROFILE32
       mov      eax, dword ptr [rbp-0x5C]
       inc      eax
       mov      dword ptr [rbp-0x5C], eax
 
G_M000_IG09:                ;; offset=0x0150
       mov      eax, dword ptr [rbp-0xB4]
       dec      eax
       mov      dword ptr [rbp-0xB4], eax
       cmp      dword ptr [rbp-0xB4], 0
       jg       SHORT G_M000_IG11
 
G_M000_IG10:                ;; offset=0x0167
       lea      rdi, [rbp-0xB4]
       mov      esi, 63
       call     CORINFO_HELP_PATCHPOINT
       jmp      rax
 
G_M000_IG11:                ;; offset=0x017A
       mov      eax, dword ptr [rbp-0x5C]
       cmp      eax, dword ptr [rbp-0x34]
       jl       G_M000_IG04
       mov      rdi, 0x7F020E8AEDD8
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG22
 
G_M000_IG12:                ;; offset=0x019A
       vmovdqu  xmm0, xmmword ptr [rbp-0x48]
       vmovdqu  xmmword ptr [rbp-0x90], xmm0
 
G_M000_IG13:                ;; offset=0x01A7
       xor      eax, eax
       mov      gword ptr [rbp-0x70], rax
       mov      rdi, bword ptr [rbp-0x90]
       mov      rsi, qword ptr [rbp-0x88]
       mov      rdx, gword ptr [rbp-0x50]
       mov      rcx, gword ptr [rbp-0x58]
       mov      r8, gword ptr [rbp-0x70]
       call     [Lokad.Lython.Runtime.Text.PyString:HashUtf8(System.ReadOnlySpan`1[byte],Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,System.Threading.CancellationToken):int]
       mov      edi, eax
       call     [Lokad.Lython.Runtime.PyValueComparer:NormalizeHash(int):int]
       mov      edi, eax
       call     [Lokad.Lython.Runtime.PyDict:MixNativeHash(int):uint]
       mov      rcx, bword ptr [rbp+0x10]
       mov      dword ptr [rcx], eax
       cmp      dword ptr [rbp-0x34], 0
       jne      SHORT G_M000_IG14
       mov      rdi, 0x7F020E8AEDDC
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG22
 
G_M000_IG14:                ;; offset=0x01FD
       mov      rax, gword ptr [rbp-0x30]
       mov      esi, dword ptr [rax+0x08]
       mov      rax, bword ptr [rbp+0x10]
       mov      edi, dword ptr [rax]
       call     [Lokad.Lython.Runtime.PyDict:NativeBucket(uint,int):int]
       mov      rcx, gword ptr [rbp-0x30]
       cmp      eax, dword ptr [rcx+0x08]
       jae      G_M000_IG26
       mov      edx, eax
       imul     rdx, rdx, 40
       lea      rcx, bword ptr [rcx+rdx+0x10]
       mov      eax, dword ptr [rcx+0x20]
       dec      eax
       mov      dword ptr [rbp-0x74], eax
       jmp      G_M000_IG19
 
G_M000_IG15:                ;; offset=0x0235
       mov      rdi, gword ptr [rbp-0x50]
       mov      rsi, gword ptr [rbp-0x58]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CheckExecution(Lokad.Lython.LythonSourceSpan):this]
       mov      rax, gword ptr [rbp-0x30]
       mov      ecx, dword ptr [rbp-0x74]
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG26
       mov      edx, ecx
       imul     rdx, rdx, 40
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      eax, dword ptr [rax+0x18]
       mov      rcx, bword ptr [rbp+0x10]
       cmp      eax, dword ptr [rcx]
       jne      G_M000_IG18
       mov      rax, gword ptr [rbp-0x30]
       mov      ecx, dword ptr [rbp-0x74]
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG26
       mov      edx, ecx
       imul     rdx, rdx, 40
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      rsi, gword ptr [rax]
       mov      rdi, 0x7F020E2DFBC0
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      gword ptr [rbp-0x80], rax
       cmp      gword ptr [rbp-0x80], 0
       je       SHORT G_M000_IG17
       mov      rsi, bword ptr [rbp-0x48]
       mov      rdx, qword ptr [rbp-0x40]
       mov      rdi, gword ptr [rbp-0x80]
       mov      rcx, gword ptr [rbp-0x50]
       mov      r8, gword ptr [rbp-0x58]
       call     [Lokad.Lython.Runtime.PyDict:EqualNativeText(Lokad.Lython.Runtime.Text.PyString,System.ReadOnlySpan`1[byte],Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):bool]
       test     eax, eax
       je       SHORT G_M000_IG16
       mov      rdi, 0x7F020E8AEDE0
       call     CORINFO_HELP_COUNTPROFILE32
       mov      eax, dword ptr [rbp-0x74]
       mov      dword ptr [rbp-0xB8], eax
       jmp      G_M000_IG24
 
G_M000_IG16:                ;; offset=0x02E3
       mov      rdi, 0x7F020E8AEDE4
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG18
 
G_M000_IG17:                ;; offset=0x02F4
       mov      rdi, 0x7F020E8AEDE8
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG18:                ;; offset=0x0303
       mov      rdi, 0x7F020E8AEDEC
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, gword ptr [rbp-0x30]
       mov      ecx, dword ptr [rbp-0x74]
       cmp      ecx, dword ptr [rax+0x08]
       jae      SHORT G_M000_IG26
       mov      edx, ecx
       imul     rdx, rdx, 40
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      eax, dword ptr [rax+0x1C]
       dec      eax
       mov      dword ptr [rbp-0x74], eax
 
G_M000_IG19:                ;; offset=0x0331
       mov      eax, dword ptr [rbp-0xB4]
       dec      eax
       mov      dword ptr [rbp-0xB4], eax
       cmp      dword ptr [rbp-0xB4], 0
       jg       SHORT G_M000_IG21
 
G_M000_IG20:                ;; offset=0x0348
       lea      rdi, [rbp-0xB4]
       mov      esi, 210
       call     CORINFO_HELP_PATCHPOINT
       jmp      rax
 
G_M000_IG21:                ;; offset=0x035B
       cmp      dword ptr [rbp-0x74], 0
       jge      G_M000_IG15
       mov      rdi, 0x7F020E8AEDF0
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG22:                ;; offset=0x0374
       mov      eax, -1
 
G_M000_IG23:                ;; offset=0x0379
       add      rsp, 192
       pop      rbp
       ret      
 
G_M000_IG24:                ;; offset=0x0382
       mov      eax, dword ptr [rbp-0xB8]
 
G_M000_IG25:                ;; offset=0x0388
       add      rsp, 192
       pop      rbp
       ret      
 
G_M000_IG26:                ;; offset=0x0391
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
; Total bytes of code 919

; Assembly listing for method Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteDictionaryLoop(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool (Instrumented Tier0)
; Emitting BLENDED_CODE for x64 + VEX on Unix
; Instrumented Tier0 code
; rbp based frame
; fully interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 624
       lea      rbp, [rsp+0x270]
       vxorps   xmm8, xmm8, xmm8
       vmovdqa  xmmword ptr [rbp-0x250], xmm8
       vmovdqa  xmmword ptr [rbp-0x240], xmm8
       mov      rax, -480
 
G_M000_IG77:                ;; offset=0x002F
       vmovdqa  xmmword ptr [rbp+rax-0x50], xmm8
       vmovdqa  xmmword ptr [rbp+rax-0x40], xmm8
       vmovdqa  xmmword ptr [rbp+rax-0x30], xmm8
       add      rax, 48
       jne      SHORT G_M000_IG77
       mov      qword ptr [rbp-0x50], rax
       mov      bword ptr [rbp-0x30], rdi
       mov      gword ptr [rbp-0x38], rsi
       mov      gword ptr [rbp-0x40], rdx
       mov      bword ptr [rbp-0x48], rcx
 
G_M000_IG02:                ;; offset=0x005B
       mov      dword ptr [rbp-0x1BC], 0x3E8
       mov      rax, bword ptr [rbp-0x30]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp-0x30]
       lea      rdi, bword ptr [rax+0x20]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:get_LiveExtent():int:this]
       mov      dword ptr [rbp-0x110], eax
       mov      rdi, bword ptr [rbp-0x48]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       cmp      eax, dword ptr [rbp-0x110]
       jne      SHORT G_M000_IG04
       mov      rax, bword ptr [rbp-0x30]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp-0x30]
       lea      rdi, bword ptr [rax+0x20]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:get_HasPendingDisposals():bool:this]
       test     eax, eax
       je       SHORT G_M000_IG05
 
G_M000_IG03:                ;; offset=0x00A9
       mov      rdi, 0x7F020E8AEA70
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG04:                ;; offset=0x00B8
       mov      rdi, 0x7F020E8AEA74
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG24
 
G_M000_IG05:                ;; offset=0x00CC
       mov      rax, bword ptr [rbp-0x30]
       mov      rdi, gword ptr [rax]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_RequiresLocalVariableMirroring():bool:this]
       test     eax, eax
       jne      G_M000_IG11
       cmp      gword ptr [rbp-0x40], 0
       jne      SHORT G_M000_IG06
       mov      dword ptr [rbp-0x1A4], 1
       jmp      SHORT G_M000_IG07
 
G_M000_IG06:                ;; offset=0x00F6
       mov      rdi, 0x7F020E8AEA78
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, gword ptr [rbp-0x40]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:get_MirrorLocalStores():bool:this]
       test     eax, eax
       sete     al
       movzx    rax, al
       mov      dword ptr [rbp-0x1A4], eax
 
G_M000_IG07:                ;; offset=0x011D
       cmp      dword ptr [rbp-0x1A4], 0
       je       SHORT G_M000_IG08
       cmp      gword ptr [rbp-0x40], 0
       jne      SHORT G_M000_IG09
       xor      rax, rax
       mov      gword ptr [rbp-0x1B0], rax
       jmp      SHORT G_M000_IG10
 
G_M000_IG08:                ;; offset=0x0138
       mov      rdi, 0x7F020E8AEA7C
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG11
 
G_M000_IG09:                ;; offset=0x0149
       mov      rdi, 0x7F020E8AEA80
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, gword ptr [rbp-0x40]
       mov      rax, gword ptr [rax+0x88]
       mov      gword ptr [rbp-0x1B0], rax
 
G_M000_IG10:                ;; offset=0x016A
       mov      rdi, 0x7F020E8AEA84
       call     CORINFO_HELP_COUNTPROFILE32
       cmp      gword ptr [rbp-0x1B0], 0
       sete     al
       movzx    rax, al
       mov      dword ptr [rbp-0x114], eax
       jmp      SHORT G_M000_IG12
 
G_M000_IG11:                ;; offset=0x018F
       xor      eax, eax
       mov      dword ptr [rbp-0x114], eax
 
G_M000_IG12:                ;; offset=0x0197
       movzx    rax, byte  ptr [rbp-0x114]
       mov      dword ptr [rbp-0x4C], eax
       cmp      dword ptr [rbp-0x4C], 0
       je       G_M000_IG14
       mov      rax, bword ptr [rbp-0x30]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp-0x30]
       add      rax, 32
       mov      bword ptr [rbp-0x120], rax
       mov      rdi, bword ptr [rbp-0x48]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x1C4], eax
       mov      esi, dword ptr [rbp-0x1C4]
       mov      rdi, bword ptr [rbp-0x120]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:get_Item(int):System.Object:this]
       mov      gword ptr [rbp-0x1D0], rax
       mov      rsi, gword ptr [rbp-0x1D0]
       mov      rdi, 0x7F020E88DB58
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      gword ptr [rbp-0x58], rax
       cmp      gword ptr [rbp-0x58], 0
       je       SHORT G_M000_IG15
       mov      rdi, gword ptr [rbp-0x58]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.Text.PyStringOps+CasedWhitespaceIteration:get_MemoryGovernor():Lokad.Lython.Runtime.MemoryGovernor:this]
       mov      gword ptr [rbp-0x128], rax
       mov      rdi, gword ptr [rbp-0x38]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:get_MemoryGovernor():Lokad.Lython.Runtime.MemoryGovernor:this]
       cmp      rax, gword ptr [rbp-0x128]
       je       SHORT G_M000_IG16
 
G_M000_IG13:                ;; offset=0x0234
       mov      rdi, 0x7F020E8AEA88
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG14:                ;; offset=0x0243
       mov      rdi, 0x7F020E8AEA8C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, bword ptr [rbp-0x30]
       mov      rsi, gword ptr [rbp-0x38]
       mov      rdx, gword ptr [rbp-0x40]
       mov      rcx, bword ptr [rbp-0x48]
       mov      r8d, dword ptr [rbp-0x4C]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteOrdinaryDictionaryLoop(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,bool):bool]
       mov      dword ptr [rbp-0x1C0], eax
       jmp      G_M000_IG51
 
G_M000_IG15:                ;; offset=0x0277
       mov      rdi, 0x7F020E8AEA90
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG14
 
G_M000_IG16:                ;; offset=0x0288
       mov      rax, bword ptr [rbp-0x30]
       mov      eax, dword ptr [rax+0x18]
       mov      dword ptr [rbp-0x5C], eax
       mov      rdi, bword ptr [rbp-0x48]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_DictionaryLoopCallIndex():int:this]
       mov      dword ptr [rbp-0x60], eax
       mov      rax, bword ptr [rbp-0x30]
       mov      rdi, gword ptr [rax]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_CallSites():System.Collections.Generic.IReadOnlyList`1[Lokad.Lython.Frontend.ExecutableCallSite]:this]
       mov      gword ptr [rbp-0x130], rax
       mov      rax, gword ptr [rbp-0x130]
       mov      gword ptr [rbp-0x1B8], rax
       mov      rdi, gword ptr [rbp-0x1B8]
       mov      rsi, 0x7F020E8AEA98
       call     CORINFO_HELP_CLASSPROFILE32
       mov      rax, gword ptr [rbp-0x1B8]
       mov      gword ptr [rbp-0x1D8], rax
       mov      rax, bword ptr [rbp-0x30]
       mov      rdi, gword ptr [rax]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Instructions():Lokad.Lython.Frontend.ExecutableInstruction[]:this]
       mov      ecx, dword ptr [rbp-0x60]
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG53
       mov      edx, ecx
       imul     rdx, rdx, 32
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      rdi, rax
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_CallSiteIndex():int:this]
       mov      dword ptr [rbp-0x1DC], eax
       mov      rdi, gword ptr [rbp-0x1D8]
       mov      esi, dword ptr [rbp-0x1DC]
       mov      r11, 0x7F020C652530
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       mov      gword ptr [rbp-0x68], rax
       mov      rax, bword ptr [rbp-0x30]
       mov      rdi, gword ptr [rax]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Instructions():Lokad.Lython.Frontend.ExecutableInstruction[]:this]
       mov      ecx, dword ptr [rbp-0x5C]
       add      ecx, 2
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG53
       mov      edx, ecx
       imul     rdx, rdx, 32
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      bword ptr [rbp-0x70], rax
       mov      rax, bword ptr [rbp-0x30]
       mov      rdi, gword ptr [rax]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Instructions():Lokad.Lython.Frontend.ExecutableInstruction[]:this]
       mov      ecx, dword ptr [rbp-0x60]
       inc      ecx
       cmp      ecx, dword ptr [rax+0x08]
 
G_M000_IG17:                ;; offset=0x037E
       jae      G_M000_IG53
       mov      edx, ecx
       imul     rdx, rdx, 32
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      bword ptr [rbp-0x78], rax
       mov      rax, bword ptr [rbp-0x30]
       mov      rdi, gword ptr [rax]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Instructions():Lokad.Lython.Frontend.ExecutableInstruction[]:this]
       mov      ecx, dword ptr [rbp-0x60]
       add      ecx, 2
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG53
       mov      edx, ecx
       imul     rdx, rdx, 32
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      bword ptr [rbp-0x80], rax
       mov      rax, bword ptr [rbp-0x30]
       mov      rdi, gword ptr [rax]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Constants():System.Object[]:this]
       mov      gword ptr [rbp-0x138], rax
       mov      rax, bword ptr [rbp-0x30]
       mov      rdi, gword ptr [rax]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Instructions():Lokad.Lython.Frontend.ExecutableInstruction[]:this]
       mov      ecx, dword ptr [rbp-0x5C]
       add      ecx, 4
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG53
       mov      edx, ecx
       imul     rdx, rdx, 32
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      rdi, rax
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ConstantIndex():int:this]
       mov      rcx, gword ptr [rbp-0x138]
       cmp      eax, dword ptr [rcx+0x08]
       jae      G_M000_IG53
       mov      edx, eax
       lea      rcx, bword ptr [rcx+8*rdx+0x10]
       mov      rax, gword ptr [rcx]
       mov      gword ptr [rbp-0x88], rax
       mov      rax, bword ptr [rbp-0x30]
       mov      rdi, gword ptr [rax]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Constants():System.Object[]:this]
       mov      gword ptr [rbp-0x140], rax
       mov      rdi, bword ptr [rbp-0x78]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_SecondInput():int:this]
       not      eax
       mov      rcx, gword ptr [rbp-0x140]
       cmp      eax, dword ptr [rcx+0x08]
       jae      G_M000_IG53
       mov      edx, eax
 
G_M000_IG18:                ;; offset=0x045D
       lea      rcx, bword ptr [rcx+8*rdx+0x10]
       mov      rax, gword ptr [rcx]
       mov      gword ptr [rbp-0x1E8], rax
       mov      rsi, gword ptr [rbp-0x1E8]
       mov      rdi, 0x7F020E280018
       call     [CORINFO_HELP_UNBOX]
 
G_M000_IG19:                ;; offset=0x0483
       vmovdqu  xmm0, xmmword ptr [rax]
       vmovdqu  xmmword ptr [rbp-0x98], xmm0
 
G_M000_IG20:                ;; offset=0x048F
       mov      rax, bword ptr [rbp-0x30]
       mov      rax, gword ptr [rax+0x08]
       mov      gword ptr [rbp-0x148], rax
       mov      rax, gword ptr [rbp-0x148]
       mov      gword ptr [rbp-0x250], rax
       mov      rdi, bword ptr [rbp-0x80]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_SecondInput():int:this]
       mov      rdx, gword ptr [rbp-0x250]
       cmp      eax, dword ptr [rdx+0x08]
       jae      G_M000_IG53
       mov      ecx, eax
       imul     rcx, rcx, 16
       lea      rcx, bword ptr [rdx+rcx+0x10]
       mov      rdi, rcx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Object():System.Object:this]
       mov      gword ptr [rbp-0x1F0], rax
       mov      rsi, gword ptr [rbp-0x1F0]
       mov      rdi, 0x7F020E560018
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      gword ptr [rbp-0xA0], rax
       cmp      gword ptr [rbp-0xA0], 0
       je       SHORT G_M000_IG22
       mov      rdi, gword ptr [rbp-0xA0]
       mov      rsi, gword ptr [rbp-0x38]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.PyDict:CanAccumulateBorrowedWords(Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG23
 
G_M000_IG21:                ;; offset=0x0520
       mov      rdi, 0x7F020E8AEBA0
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG22:                ;; offset=0x052F
       mov      rdi, 0x7F020E8AEBA4
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG24
 
G_M000_IG23:                ;; offset=0x0543
       mov      eax, dword ptr [rbp-0x60]
       add      eax, 3
       mov      dword ptr [rbp-0xA4], eax
       mov      rax, bword ptr [rbp-0x30]
       mov      rdi, gword ptr [rax]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Instructions():Lokad.Lython.Frontend.ExecutableInstruction[]:this]
       mov      ecx, dword ptr [rbp-0xA4]
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG53
       mov      edx, ecx
       imul     rdx, rdx, 32
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      bword ptr [rbp-0xB0], rax
       mov      rdi, bword ptr [rbp-0xB0]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_OpCode():int:this]
       cmp      eax, 47
       sete     al
       movzx    rax, al
       mov      dword ptr [rbp-0xB4], eax
       xor      eax, eax
       mov      qword ptr [rbp-0xC0], rax
       xor      eax, eax
       mov      qword ptr [rbp-0xC8], rax
       cmp      dword ptr [rbp-0xB4], 0
       je       G_M000_IG29
       mov      rax, bword ptr [rbp-0x30]
       mov      rax, gword ptr [rax+0x08]
       mov      gword ptr [rbp-0x198], rax
       mov      rdi, bword ptr [rbp-0xB0]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      rcx, gword ptr [rbp-0x198]
       cmp      eax, dword ptr [rcx+0x08]
       jae      G_M000_IG53
       mov      edx, eax
       imul     rdx, rdx, 16
       lea      rcx, bword ptr [rcx+rdx+0x10]
       mov      bword ptr [rbp-0x1F8], rcx
       mov      rdi, bword ptr [rbp-0x1F8]
       lea      rsi, [rbp-0xC0]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryReadHistogramTotal(byref,byref):bool]
       test     eax, eax
       jne      SHORT G_M000_IG26
       mov      rdi, 0x7F020E8AEBA8
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG24:                ;; offset=0x061F
       xor      eax, eax
 
G_M000_IG25:                ;; offset=0x0621
       add      rsp, 624
       pop      rbp
       ret      
 
G_M000_IG26:                ;; offset=0x062A
       mov      rdi, 0x7F020E8AEBAC
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp-0x30]
       mov      rdi, gword ptr [rax]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Constants():System.Object[]:this]
       mov      gword ptr [rbp-0x1A0], rax
       mov      rdi, bword ptr [rbp-0xB0]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_SecondInput():int:this]
       not      eax
       mov      rcx, gword ptr [rbp-0x1A0]
       cmp      eax, dword ptr [rcx+0x08]
       jae      G_M000_IG53
       mov      edx, eax
       lea      rcx, bword ptr [rcx+8*rdx+0x10]
       mov      rax, gword ptr [rcx]
       mov      gword ptr [rbp-0x200], rax
       mov      rsi, gword ptr [rbp-0x200]
       mov      rdi, 0x7F020E280018
       call     [CORINFO_HELP_UNBOX]
 
G_M000_IG27:                ;; offset=0x0696
       vmovdqu  xmm0, xmmword ptr [rax]
       vmovdqu  xmmword ptr [rbp-0x210], xmm0
 
G_M000_IG28:                ;; offset=0x06A2
       mov      rdi, gword ptr [rbp-0x210]
       mov      rsi, qword ptr [rbp-0x208]
       call     [System.Numerics.BigInteger:op_Explicit(System.Numerics.BigInteger):long]
       mov      qword ptr [rbp-0xC8], rax
 
G_M000_IG29:                ;; offset=0x06BD
       vxorps   xmm0, xmm0, xmm0
       vmovdqu  xmmword ptr [rbp-0xD8], xmm0
       xor      rax, rax
       mov      gword ptr [rbp-0xE0], rax
       xor      eax, eax
       mov      dword ptr [rbp-0xE4], eax
       xor      eax, eax
       mov      dword ptr [rbp-0xE8], eax
       xor      eax, eax
       mov      dword ptr [rbp-0xEC], eax
 
G_M000_IG30:                ;; offset=0x06EA
       mov      eax, dword ptr [rbp-0x1BC]
       dec      eax
       mov      dword ptr [rbp-0x1BC], eax
       cmp      dword ptr [rbp-0x1BC], 0
       jg       SHORT G_M000_IG32
 
G_M000_IG31:                ;; offset=0x0701
       lea      rdi, [rbp-0x1BC]
       mov      esi, 496
       call     CORINFO_HELP_PATCHPOINT
       jmp      rax
 
G_M000_IG32:                ;; offset=0x0714
       lea      rsi, [rbp-0x100]
       lea      rdx, [rbp-0x108]
       mov      rdi, gword ptr [rbp-0x58]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.Text.PyStringOps+CasedWhitespaceIteration:TryReadWord(byref,byref):bool:this]
       test     eax, eax
       je       G_M000_IG46
 
G_M000_IG33:                ;; offset=0x0736
       vmovdqu  xmm0, xmmword ptr [rbp-0x100]
       vmovdqu  xmmword ptr [rbp-0xD8], xmm0
 
G_M000_IG34:                ;; offset=0x0746
       mov      rax, gword ptr [rbp-0x108]
       mov      gword ptr [rbp-0xE0], rax
       cmp      dword ptr [rbp-0xE8], 0
       jne      SHORT G_M000_IG35
       mov      rdi, bword ptr [rbp-0x70]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x218], rax
       mov      rsi, gword ptr [rbp-0x218]
       mov      rdi, gword ptr [rbp-0x38]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CheckExecution(Lokad.Lython.LythonSourceSpan):this]
       mov      rax, bword ptr [rbp-0x30]
       mov      ecx, dword ptr [rbp-0x60]
       mov      dword ptr [rax+0x18], ecx
       mov      rdi, gword ptr [rbp-0x68]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_CallSpan():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x220], rax
       mov      rsi, gword ptr [rbp-0x220]
       mov      rdi, gword ptr [rbp-0x38]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:EnterInterpreterFrame(Lokad.Lython.LythonSourceSpan):this]
       mov      dword ptr [rbp-0xE8], 1
       jmp      SHORT G_M000_IG36
 
G_M000_IG35:                ;; offset=0x07BD
       mov      rdi, 0x7F020E8AEBB0
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp-0x30]
       mov      ecx, dword ptr [rbp-0x60]
       mov      dword ptr [rax+0x18], ecx
 
G_M000_IG36:                ;; offset=0x07D6
       cmp      gword ptr [rbp-0x108], 0
       je       SHORT G_M000_IG37
       mov      rax, gword ptr [rbp-0x108]
       mov      gword ptr [rbp-0x168], rax
       mov      rdi, gword ptr [rbp-0x68]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_CallSpan():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x228], rax
       mov      rax, gword ptr [rbp-0x228]
       mov      gword ptr [rsp], rax
       mov      rcx, gword ptr [rbp-0x98]
       mov      r8, qword ptr [rbp-0x90]
       mov      rsi, gword ptr [rbp-0x168]
       mov      rdx, gword ptr [rbp-0x88]
       mov      r9, gword ptr [rbp-0x38]
       mov      rdi, gword ptr [rbp-0xA0]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.PyDict:TryAccumulateWithoutAdmission(Lokad.Lython.Runtime.Text.PyString,System.Object,System.Numerics.BigInteger,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):bool:this]
       mov      dword ptr [rbp-0x15C], eax
       jmp      G_M000_IG40
 
G_M000_IG37:                ;; offset=0x0846
       mov      rdi, 0x7F020E8AEBB4
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG38:                ;; offset=0x0855
       vmovdqu  xmm0, xmmword ptr [rbp-0x100]
       vmovdqu  xmmword ptr [rbp-0x158], xmm0
 
G_M000_IG39:                ;; offset=0x0865
       mov      rdi, gword ptr [rbp-0x68]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_CallSpan():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x230], rax
       mov      rax, gword ptr [rbp-0x58]
       mov      gword ptr [rsp+0x10], rax
       lea      rax, [rbp-0xE0]
       mov      qword ptr [rsp+0x18], rax
       mov      rax, gword ptr [rbp-0x230]
       mov      gword ptr [rsp+0x08], rax
       mov      r8, gword ptr [rbp-0x98]
       mov      r9, qword ptr [rbp-0x90]
       mov      rsi, bword ptr [rbp-0x158]
       mov      rdx, qword ptr [rbp-0x150]
       mov      rcx, gword ptr [rbp-0x88]
       mov      rax, gword ptr [rbp-0x38]
       mov      gword ptr [rsp], rax
       mov      rdi, gword ptr [rbp-0xA0]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.PyDict:TryAccumulateBorrowedWord(System.ReadOnlySpan`1[byte],System.Object,System.Numerics.BigInteger,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.Text.PyStringOps+CasedWhitespaceIteration,byref):bool:this]
       mov      dword ptr [rbp-0x15C], eax
 
G_M000_IG40:                ;; offset=0x08D9
       cmp      dword ptr [rbp-0x15C], 0
       jne      SHORT G_M000_IG41
       mov      eax, dword ptr [rbp-0x5C]
       add      eax, 2
       mov      rcx, bword ptr [rbp-0x30]
       mov      dword ptr [rcx+0x18], eax
       mov      dword ptr [rbp-0x10C], 1
       jmp      G_M000_IG48
 
G_M000_IG41:                ;; offset=0x08FE
       cmp      dword ptr [rbp-0xB4], 0
       je       G_M000_IG45
       mov      rax, qword ptr [rbp-0xC0]
       add      rax, qword ptr [rbp-0xC8]
       mov      qword ptr [rbp-0xC0], rax
       mov      dword ptr [rbp-0xE4], 1
       mov      rax, 0xFF80000000000000
       cmp      qword ptr [rbp-0xC0], rax
       jl       SHORT G_M000_IG43
       mov      rax, 0x80000000000000
       cmp      qword ptr [rbp-0xC0], rax
       jl       SHORT G_M000_IG44
 
G_M000_IG42:                ;; offset=0x0950
       mov      rdi, 0x7F020E8AEBB8
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG43:                ;; offset=0x095F
       mov      rdi, 0x7F020E8AEBBC
       call     CORINFO_HELP_COUNTPROFILE32
       mov      eax, dword ptr [rbp-0xA4]
       add      eax, 2
       mov      rcx, bword ptr [rbp-0x30]
       mov      dword ptr [rcx+0x18], eax
       mov      dword ptr [rbp-0x10C], 1
       jmp      G_M000_IG49
 
G_M000_IG44:                ;; offset=0x098D
       mov      rdi, 0x7F020E8AEBC0
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG45:                ;; offset=0x099C
       mov      rdi, 0x7F020E8AEBC4
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp-0x30]
       mov      ecx, dword ptr [rbp-0x5C]
       mov      dword ptr [rax+0x18], ecx
       mov      rdi, bword ptr [rbp-0x48]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x238], rax
       mov      rsi, gword ptr [rbp-0x238]
       mov      rdi, gword ptr [rbp-0x38]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CheckExecution(Lokad.Lython.LythonSourceSpan):this]
       jmp      G_M000_IG30
 
G_M000_IG46:                ;; offset=0x09DE
       mov      rdi, 0x7F020E8AEBC8
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0xEC], 1
       mov      rdi, bword ptr [rbp-0x48]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_TargetIndex():int:this]
       mov      rcx, bword ptr [rbp-0x30]
       mov      dword ptr [rcx+0x18], eax
       mov      dword ptr [rbp-0x10C], 1
 
G_M000_IG47:                ;; offset=0x0A12
       call     G_M000_IG71
       jmp      SHORT G_M000_IG50
 
G_M000_IG48:                ;; offset=0x0A19
       call     G_M000_IG71
       jmp      SHORT G_M000_IG50
 
G_M000_IG49:                ;; offset=0x0A20
       call     G_M000_IG71
       nop      
 
G_M000_IG50:                ;; offset=0x0A26
       mov      rdi, 0x7F020E8AEBF0
       call     CORINFO_HELP_COUNTPROFILE32
       mov      eax, dword ptr [rbp-0x10C]
       mov      dword ptr [rbp-0x1C0], eax
 
G_M000_IG51:                ;; offset=0x0A41
       movzx    rax, byte  ptr [rbp-0x1C0]
 
G_M000_IG52:                ;; offset=0x0A48
       add      rsp, 624
       pop      rbp
       ret      
 
G_M000_IG53:                ;; offset=0x0A51
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG54:                ;; offset=0x0A57
       sub      rsp, 40
 
G_M000_IG55:                ;; offset=0x0A5B
       cmp      dword ptr [rbp-0xE4], 0
       je       SHORT G_M000_IG56
       mov      rdi, 0x7F020E8AEBDC
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp-0x30]
       mov      rax, gword ptr [rax+0x08]
       mov      gword ptr [rbp-0x190], rax
       mov      rdi, bword ptr [rbp-0xB0]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      rcx, gword ptr [rbp-0x190]
       cmp      eax, dword ptr [rcx+0x08]
       jae      G_M000_IG59
       mov      edx, eax
       imul     rdx, rdx, 16
       lea      rcx, bword ptr [rcx+rdx+0x10]
       mov      bword ptr [rbp-0x240], rcx
       mov      rdi, bword ptr [rbp-0x240]
       mov      rsi, qword ptr [rbp-0xC0]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:SetInteger(long):this]
 
G_M000_IG56:                ;; offset=0x0AC5
       cmp      dword ptr [rbp-0xEC], 0
       je       SHORT G_M000_IG57
       mov      rdi, 0x7F020E8AEBE0
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp-0x30]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp-0x30]
       add      rax, 32
       mov      bword ptr [rbp-0x188], rax
       mov      rdi, bword ptr [rbp-0x48]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x244], eax
       mov      esi, dword ptr [rbp-0x244]
       mov      rdi, bword ptr [rbp-0x188]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
 
G_M000_IG57:                ;; offset=0x0B15
       mov      rdi, 0x7F020E8AEBE4
       call     CORINFO_HELP_COUNTPROFILE32
       nop      
 
G_M000_IG58:                ;; offset=0x0B25
       add      rsp, 40
       ret      
 
G_M000_IG59:                ;; offset=0x0B2A
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG60:                ;; offset=0x0B30
       sub      rsp, 40
 
G_M000_IG61:                ;; offset=0x0B34
       cmp      gword ptr [rbp-0xE0], 0
       jne      SHORT G_M000_IG65
       lea      rdi, [rbp-0xD8]
       call     [System.ReadOnlySpan`1[byte]:get_IsEmpty():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG62
       jmp      SHORT G_M000_IG64
 
G_M000_IG62:                ;; offset=0x0B51
       mov      rdi, 0x7F020E8AEBD0
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG67
 
G_M000_IG63:                ;; offset=0x0B65
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG64:                ;; offset=0x0B6B
       mov      rdi, 0x7F020E8AEBD4
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG65:                ;; offset=0x0B7A
       mov      rax, bword ptr [rbp-0x30]
       mov      rax, gword ptr [rax+0x08]
       mov      gword ptr [rbp-0x170], rax
       mov      rdi, bword ptr [rbp-0x80]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ThirdInput():int:this]
       mov      rcx, gword ptr [rbp-0x170]
       cmp      eax, dword ptr [rcx+0x08]
       jae      SHORT G_M000_IG63
       mov      edx, eax
       imul     rdx, rdx, 16
       lea      rcx, bword ptr [rcx+rdx+0x10]
       mov      bword ptr [rbp-0x178], rcx
       mov      rax, gword ptr [rbp-0xE0]
       mov      gword ptr [rbp-0x180], rax
       cmp      gword ptr [rbp-0xE0], 0
       jne      SHORT G_M000_IG66
       mov      rdi, 0x7F020E8AEBD8
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rsi, bword ptr [rbp-0xD8]
       mov      rdx, qword ptr [rbp-0xD0]
       mov      rdi, gword ptr [rbp-0x58]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.Text.PyStringOps+CasedWhitespaceIteration:Materialize(System.ReadOnlySpan`1[byte]):Lokad.Lython.Runtime.Text.PyString:this]
       mov      gword ptr [rbp-0x180], rax
 
G_M000_IG66:                ;; offset=0x0BF9
       mov      rdi, bword ptr [rbp-0x178]
       mov      rsi, gword ptr [rbp-0x180]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:set_Object(System.Object):this]
 
G_M000_IG67:                ;; offset=0x0C0D
       nop      
 
G_M000_IG68:                ;; offset=0x0C0E
       call     G_M000_IG54
       nop      
 
G_M000_IG69:                ;; offset=0x0C14
       mov      rdi, 0x7F020E8AEBE8
       call     CORINFO_HELP_COUNTPROFILE32
       nop      
 
G_M000_IG70:                ;; offset=0x0C24
       add      rsp, 40
       ret      
 
G_M000_IG71:                ;; offset=0x0C29
       sub      rsp, 40
 
G_M000_IG72:                ;; offset=0x0C2D
       cmp      dword ptr [rbp-0xE8], 0
       je       SHORT G_M000_IG73
       mov      rdi, 0x7F020E8AEBCC
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, gword ptr [rbp-0x38]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:LeaveInterpreterFrame():this]
 
G_M000_IG73:                ;; offset=0x0C51
       nop      
 
G_M000_IG74:                ;; offset=0x0C52
       call     G_M000_IG60
       nop      
 
G_M000_IG75:                ;; offset=0x0C58
       mov      rdi, 0x7F020E8AEBEC
       call     CORINFO_HELP_COUNTPROFILE32
       nop      
 
G_M000_IG76:                ;; offset=0x0C68
       add      rsp, 40
       ret      
 
; Total bytes of code 3181

; Assembly listing for method Lokad.Lython.Runtime.PyDict:TryAppendBorrowedWord(System.ReadOnlySpan`1[byte],uint,System.Object,System.Numerics.BigInteger,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.Text.PyStringOps+CasedWhitespaceIteration,byref):bool:this (Instrumented Tier0)
; Emitting BLENDED_CODE for x64 + VEX on Unix
; Instrumented Tier0 code
; rbp based frame
; partially interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 64
       lea      rbp, [rsp+0x40]
       mov      gword ptr [rbp-0x08], rdi
       mov      bword ptr [rbp-0x18], rsi
       mov      qword ptr [rbp-0x10], rdx
       mov      dword ptr [rbp-0x1C], ecx
       mov      gword ptr [rbp-0x28], r8
       mov      gword ptr [rbp-0x30], r9
 
G_M000_IG02:                ;; offset=0x0021
       cmp      dword ptr [rbp-0x10], 8
       jle      SHORT G_M000_IG04
       mov      rax, gword ptr [rbp-0x08]
       mov      eax, dword ptr [rax+0x4C]
       mov      rcx, gword ptr [rbp-0x08]
       mov      rcx, gword ptr [rcx+0x28]
       cmp      eax, dword ptr [rcx+0x08]
       jne      SHORT G_M000_IG06
 
G_M000_IG03:                ;; offset=0x003B
       mov      rdi, 0x7F020EF28F98
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG04:                ;; offset=0x004A
       mov      rdi, 0x7F020EF28F9C
       call     CORINFO_HELP_COUNTPROFILE32
       xor      eax, eax
 
G_M000_IG05:                ;; offset=0x005B
       add      rsp, 64
       pop      rbp
       ret      
 
G_M000_IG06:                ;; offset=0x0061
       mov      rdi, 0x7F020EF28FA0
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, gword ptr [rbp-0x30]
       mov      rsi, gword ptr [rbp+0x20]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CheckExecution(Lokad.Lython.LythonSourceSpan):this]
       mov      rsi, bword ptr [rbp-0x18]
       mov      rdx, qword ptr [rbp-0x10]
       mov      rdi, gword ptr [rbp+0x28]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.Text.PyStringOps+CasedWhitespaceIteration:Materialize(System.ReadOnlySpan`1[byte]):Lokad.Lython.Runtime.Text.PyString:this]
       mov      rsi, rax
       mov      rdi, bword ptr [rbp+0x30]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       lea      rdi, [rsp]
       lea      rsi, [rbp+0x10]
       mov      rcx, gword ptr [rsi]
       mov      gword ptr [rsp], rcx
       add      rsi, 8
       add      rdi, 8
       movsq    
       mov      rax, bword ptr [rbp+0x30]
       mov      rdx, gword ptr [rax]
       mov      rdi, gword ptr [rbp-0x08]
       mov      ecx, dword ptr [rbp-0x1C]
       mov      r8, gword ptr [rbp-0x28]
       mov      esi, -1
       call     [Lokad.Lython.Runtime.PyDict:TryAccumulateAt(int,Lokad.Lython.Runtime.Text.PyString,uint,System.Object,System.Numerics.BigInteger):bool:this]
       nop      
 
G_M000_IG07:                ;; offset=0x00D7
       add      rsp, 64
       pop      rbp
       ret      
 
; Total bytes of code 221

