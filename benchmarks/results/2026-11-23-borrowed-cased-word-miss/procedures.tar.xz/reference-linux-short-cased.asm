; Assembly listing for method Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteDictionaryLoop(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool (Instrumented Tier0)
; Emitting BLENDED_CODE for x64 + VEX on Unix
; Instrumented Tier0 code
; rbp based frame
; fully interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 640
       lea      rbp, [rsp+0x280]
       vxorps   xmm8, xmm8, xmm8
       mov      rax, -528
 
G_M000_IG77:                ;; offset=0x001F
       vmovdqa  xmmword ptr [rbp+rax-0x50], xmm8
       vmovdqa  xmmword ptr [rbp+rax-0x40], xmm8
       vmovdqa  xmmword ptr [rbp+rax-0x30], xmm8
       add      rax, 48
       jne      SHORT G_M000_IG77
       mov      qword ptr [rbp-0x50], rax
       mov      bword ptr [rbp-0x30], rdi
       mov      gword ptr [rbp-0x38], rsi
       mov      gword ptr [rbp-0x40], rdx
       mov      bword ptr [rbp-0x48], rcx
 
G_M000_IG02:                ;; offset=0x004B
       mov      dword ptr [rbp-0x1C4], 0x3E8
       mov      rax, bword ptr [rbp-0x30]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp-0x30]
       lea      rdi, bword ptr [rax+0x20]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:get_LiveExtent():int:this]
       mov      dword ptr [rbp-0x124], eax
       mov      rdi, bword ptr [rbp-0x48]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       cmp      eax, dword ptr [rbp-0x124]
       jne      SHORT G_M000_IG04
       mov      rax, bword ptr [rbp-0x30]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp-0x30]
       lea      rdi, bword ptr [rax+0x20]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:get_HasPendingDisposals():bool:this]
       test     eax, eax
       je       SHORT G_M000_IG05
 
G_M000_IG03:                ;; offset=0x0099
       mov      rdi, 0x7F236098F5D8
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG04:                ;; offset=0x00A8
       mov      rdi, 0x7F236098F5DC
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG24
 
G_M000_IG05:                ;; offset=0x00BC
       mov      rax, bword ptr [rbp-0x30]
       mov      rdi, gword ptr [rax]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_RequiresLocalVariableMirroring():bool:this]
       test     eax, eax
       jne      G_M000_IG11
       cmp      gword ptr [rbp-0x40], 0
       jne      SHORT G_M000_IG06
       mov      dword ptr [rbp-0x1AC], 1
       jmp      SHORT G_M000_IG07
 
G_M000_IG06:                ;; offset=0x00E6
       mov      rdi, 0x7F236098F5E0
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, gword ptr [rbp-0x40]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:get_MirrorLocalStores():bool:this]
       test     eax, eax
       sete     al
       movzx    rax, al
       mov      dword ptr [rbp-0x1AC], eax
 
G_M000_IG07:                ;; offset=0x010D
       cmp      dword ptr [rbp-0x1AC], 0
       je       SHORT G_M000_IG08
       cmp      gword ptr [rbp-0x40], 0
       jne      SHORT G_M000_IG09
       xor      rax, rax
       mov      gword ptr [rbp-0x1B8], rax
       jmp      SHORT G_M000_IG10
 
G_M000_IG08:                ;; offset=0x0128
       mov      rdi, 0x7F236098F5E4
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG11
 
G_M000_IG09:                ;; offset=0x0139
       mov      rdi, 0x7F236098F5E8
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, gword ptr [rbp-0x40]
       mov      rax, gword ptr [rax+0x88]
       mov      gword ptr [rbp-0x1B8], rax
 
G_M000_IG10:                ;; offset=0x015A
       mov      rdi, 0x7F236098F5EC
       call     CORINFO_HELP_COUNTPROFILE32
       cmp      gword ptr [rbp-0x1B8], 0
       sete     al
       movzx    rax, al
       mov      dword ptr [rbp-0x128], eax
       jmp      SHORT G_M000_IG12
 
G_M000_IG11:                ;; offset=0x017F
       xor      eax, eax
       mov      dword ptr [rbp-0x128], eax
 
G_M000_IG12:                ;; offset=0x0187
       movzx    rax, byte  ptr [rbp-0x128]
       mov      dword ptr [rbp-0x4C], eax
       cmp      dword ptr [rbp-0x4C], 0
       je       G_M000_IG14
       mov      rax, bword ptr [rbp-0x30]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp-0x30]
       add      rax, 32
       mov      bword ptr [rbp-0x130], rax
       mov      rdi, bword ptr [rbp-0x48]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x1CC], eax
       mov      esi, dword ptr [rbp-0x1CC]
       mov      rdi, bword ptr [rbp-0x130]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:get_Item(int):System.Object:this]
       mov      gword ptr [rbp-0x1D8], rax
       mov      rsi, gword ptr [rbp-0x1D8]
       mov      rdi, 0x7F236096E688
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      gword ptr [rbp-0x58], rax
       cmp      gword ptr [rbp-0x58], 0
       je       SHORT G_M000_IG15
       mov      rdi, gword ptr [rbp-0x58]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.Text.PyStringOps+CasedWhitespaceIteration:get_MemoryGovernor():Lokad.Lython.Runtime.MemoryGovernor:this]
       mov      gword ptr [rbp-0x138], rax
       mov      rdi, gword ptr [rbp-0x38]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:get_MemoryGovernor():Lokad.Lython.Runtime.MemoryGovernor:this]
       cmp      rax, gword ptr [rbp-0x138]
       je       SHORT G_M000_IG16
 
G_M000_IG13:                ;; offset=0x0224
       mov      rdi, 0x7F236098F5F0
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG14:                ;; offset=0x0233
       mov      rdi, 0x7F236098F5F4
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, bword ptr [rbp-0x30]
       mov      rsi, gword ptr [rbp-0x38]
       mov      rdx, gword ptr [rbp-0x40]
       mov      rcx, bword ptr [rbp-0x48]
       mov      r8d, dword ptr [rbp-0x4C]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteOrdinaryDictionaryLoop(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,bool):bool]
       mov      dword ptr [rbp-0x1C8], eax
       jmp      G_M000_IG51
 
G_M000_IG15:                ;; offset=0x0267
       mov      rdi, 0x7F236098F5F8
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG14
 
G_M000_IG16:                ;; offset=0x0278
       mov      rax, bword ptr [rbp-0x30]
       mov      eax, dword ptr [rax+0x18]
       mov      dword ptr [rbp-0x5C], eax
       mov      rdi, bword ptr [rbp-0x48]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_DictionaryLoopCallIndex():int:this]
       mov      dword ptr [rbp-0x60], eax
       mov      rax, bword ptr [rbp-0x30]
       mov      rdi, gword ptr [rax]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_CallSites():System.Collections.Generic.IReadOnlyList`1[Lokad.Lython.Frontend.ExecutableCallSite]:this]
       mov      gword ptr [rbp-0x140], rax
       mov      rax, gword ptr [rbp-0x140]
       mov      gword ptr [rbp-0x1C0], rax
       mov      rdi, gword ptr [rbp-0x1C0]
       mov      rsi, 0x7F236098F600
       call     CORINFO_HELP_CLASSPROFILE32
       mov      rax, gword ptr [rbp-0x1C0]
       mov      gword ptr [rbp-0x1E0], rax
       mov      rax, bword ptr [rbp-0x30]
       mov      rdi, gword ptr [rax]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Instructions():Lokad.Lython.Frontend.ExecutableInstruction[]:this]
       mov      ecx, dword ptr [rbp-0x60]
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG53
       mov      edx, ecx
       imul     rdx, rdx, 32
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      rdi, rax
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_CallSiteIndex():int:this]
       mov      dword ptr [rbp-0x1E4], eax
       mov      rdi, gword ptr [rbp-0x1E0]
       mov      esi, dword ptr [rbp-0x1E4]
       mov      r11, 0x7F235E731C10
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       mov      gword ptr [rbp-0x68], rax
       mov      rax, bword ptr [rbp-0x30]
       mov      rdi, gword ptr [rax]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Instructions():Lokad.Lython.Frontend.ExecutableInstruction[]:this]
       mov      ecx, dword ptr [rbp-0x5C]
       add      ecx, 2
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG53
       mov      edx, ecx
       imul     rdx, rdx, 32
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      bword ptr [rbp-0x70], rax
       mov      rax, bword ptr [rbp-0x30]
       mov      rdi, gword ptr [rax]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Instructions():Lokad.Lython.Frontend.ExecutableInstruction[]:this]
       mov      ecx, dword ptr [rbp-0x60]
       inc      ecx
       cmp      ecx, dword ptr [rax+0x08]
 
G_M000_IG17:                ;; offset=0x036E
       jae      G_M000_IG53
       mov      edx, ecx
       imul     rdx, rdx, 32
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      bword ptr [rbp-0x78], rax
       mov      rax, bword ptr [rbp-0x30]
       mov      rdi, gword ptr [rax]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Instructions():Lokad.Lython.Frontend.ExecutableInstruction[]:this]
       mov      ecx, dword ptr [rbp-0x60]
       add      ecx, 2
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG53
       mov      edx, ecx
       imul     rdx, rdx, 32
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      bword ptr [rbp-0x80], rax
       mov      rax, bword ptr [rbp-0x30]
       mov      rdi, gword ptr [rax]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Constants():System.Object[]:this]
       mov      gword ptr [rbp-0x148], rax
       mov      rax, bword ptr [rbp-0x30]
       mov      rdi, gword ptr [rax]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Instructions():Lokad.Lython.Frontend.ExecutableInstruction[]:this]
       mov      ecx, dword ptr [rbp-0x5C]
       add      ecx, 4
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG53
       mov      edx, ecx
       imul     rdx, rdx, 32
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      rdi, rax
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ConstantIndex():int:this]
       mov      rcx, gword ptr [rbp-0x148]
       cmp      eax, dword ptr [rcx+0x08]
       jae      G_M000_IG53
       mov      edx, eax
       lea      rcx, bword ptr [rcx+8*rdx+0x10]
       mov      rax, gword ptr [rcx]
       mov      gword ptr [rbp-0x88], rax
       mov      rax, bword ptr [rbp-0x30]
       mov      rdi, gword ptr [rax]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Constants():System.Object[]:this]
       mov      gword ptr [rbp-0x150], rax
       mov      rdi, bword ptr [rbp-0x78]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_SecondInput():int:this]
       not      eax
       mov      rcx, gword ptr [rbp-0x150]
       cmp      eax, dword ptr [rcx+0x08]
       jae      G_M000_IG53
       mov      edx, eax
 
G_M000_IG18:                ;; offset=0x044D
       lea      rcx, bword ptr [rcx+8*rdx+0x10]
       mov      rax, gword ptr [rcx]
       mov      gword ptr [rbp-0x1F0], rax
       mov      rsi, gword ptr [rbp-0x1F0]
       mov      rdi, 0x7F2360360018
       call     [CORINFO_HELP_UNBOX]
 
G_M000_IG19:                ;; offset=0x0473
       vmovdqu  xmm0, xmmword ptr [rax]
       vmovdqu  xmmword ptr [rbp-0x98], xmm0
 
G_M000_IG20:                ;; offset=0x047F
       mov      rax, bword ptr [rbp-0x30]
       mov      rax, gword ptr [rax+0x08]
       mov      gword ptr [rbp-0x158], rax
       mov      rax, gword ptr [rbp-0x158]
       mov      gword ptr [rbp-0x260], rax
       mov      rdi, bword ptr [rbp-0x80]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_SecondInput():int:this]
       mov      rdx, gword ptr [rbp-0x260]
       cmp      eax, dword ptr [rdx+0x08]
       jae      G_M000_IG53
       mov      ecx, eax
       imul     rcx, rcx, 16
       lea      rcx, bword ptr [rdx+rcx+0x10]
       mov      rdi, rcx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Object():System.Object:this]
       mov      gword ptr [rbp-0x1F8], rax
       mov      rsi, gword ptr [rbp-0x1F8]
       mov      rdi, 0x7F2360640018
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      gword ptr [rbp-0xA0], rax
       cmp      gword ptr [rbp-0xA0], 0
       je       SHORT G_M000_IG22
       mov      rdi, gword ptr [rbp-0xA0]
       mov      rsi, gword ptr [rbp-0x38]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.PyDict:CanAccumulateBorrowedWords(Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG23
 
G_M000_IG21:                ;; offset=0x0510
       mov      rdi, 0x7F236098F708
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG22:                ;; offset=0x051F
       mov      rdi, 0x7F236098F70C
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG24
 
G_M000_IG23:                ;; offset=0x0533
       mov      eax, dword ptr [rbp-0x60]
       add      eax, 3
       mov      dword ptr [rbp-0xA4], eax
       mov      rax, bword ptr [rbp-0x30]
       mov      rdi, gword ptr [rax]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Instructions():Lokad.Lython.Frontend.ExecutableInstruction[]:this]
       mov      ecx, dword ptr [rbp-0xA4]
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG53
       mov      edx, ecx
       imul     rdx, rdx, 32
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      bword ptr [rbp-0xB0], rax
       mov      rdi, bword ptr [rbp-0xB0]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_OpCode():int:this]
       cmp      eax, 47
       sete     al
       movzx    rax, al
       mov      dword ptr [rbp-0xB4], eax
       xor      eax, eax
       mov      qword ptr [rbp-0xC0], rax
       xor      eax, eax
       mov      qword ptr [rbp-0xC8], rax
       cmp      dword ptr [rbp-0xB4], 0
       je       G_M000_IG29
       mov      rax, bword ptr [rbp-0x30]
       mov      rax, gword ptr [rax+0x08]
       mov      gword ptr [rbp-0x1A0], rax
       mov      rdi, bword ptr [rbp-0xB0]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      rcx, gword ptr [rbp-0x1A0]
       cmp      eax, dword ptr [rcx+0x08]
       jae      G_M000_IG53
       mov      edx, eax
       imul     rdx, rdx, 16
       lea      rcx, bword ptr [rcx+rdx+0x10]
       mov      bword ptr [rbp-0x200], rcx
       mov      rdi, bword ptr [rbp-0x200]
       lea      rsi, [rbp-0xC0]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryReadHistogramTotal(byref,byref):bool]
       test     eax, eax
       jne      SHORT G_M000_IG26
       mov      rdi, 0x7F236098F710
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG24:                ;; offset=0x060F
       xor      eax, eax
 
G_M000_IG25:                ;; offset=0x0611
       add      rsp, 640
       pop      rbp
       ret      
 
G_M000_IG26:                ;; offset=0x061A
       mov      rdi, 0x7F236098F714
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp-0x30]
       mov      rdi, gword ptr [rax]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Constants():System.Object[]:this]
       mov      gword ptr [rbp-0x1A8], rax
       mov      rdi, bword ptr [rbp-0xB0]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_SecondInput():int:this]
       not      eax
       mov      rcx, gword ptr [rbp-0x1A8]
       cmp      eax, dword ptr [rcx+0x08]
       jae      G_M000_IG53
       mov      edx, eax
       lea      rcx, bword ptr [rcx+8*rdx+0x10]
       mov      rax, gword ptr [rcx]
       mov      gword ptr [rbp-0x208], rax
       mov      rsi, gword ptr [rbp-0x208]
       mov      rdi, 0x7F2360360018
       call     [CORINFO_HELP_UNBOX]
 
G_M000_IG27:                ;; offset=0x0686
       vmovdqu  xmm0, xmmword ptr [rax]
       vmovdqu  xmmword ptr [rbp-0x218], xmm0
 
G_M000_IG28:                ;; offset=0x0692
       mov      rdi, gword ptr [rbp-0x218]
       mov      rsi, qword ptr [rbp-0x210]
       call     [System.Numerics.BigInteger:op_Explicit(System.Numerics.BigInteger):long]
       mov      qword ptr [rbp-0xC8], rax
 
G_M000_IG29:                ;; offset=0x06AD
       vxorps   xmm0, xmm0, xmm0
       vmovdqu  xmmword ptr [rbp-0xD8], xmm0
       xor      rax, rax
       mov      gword ptr [rbp-0xE0], rax
       xor      eax, eax
       mov      dword ptr [rbp-0xE4], eax
       xor      eax, eax
       mov      dword ptr [rbp-0xE8], eax
       xor      eax, eax
       mov      dword ptr [rbp-0xEC], eax
 
G_M000_IG30:                ;; offset=0x06DA
       mov      eax, dword ptr [rbp-0x1C4]
       dec      eax
       mov      dword ptr [rbp-0x1C4], eax
       cmp      dword ptr [rbp-0x1C4], 0
       jg       SHORT G_M000_IG32
 
G_M000_IG31:                ;; offset=0x06F1
       lea      rdi, [rbp-0x1C4]
       mov      esi, 496
       call     CORINFO_HELP_PATCHPOINT
       jmp      rax
 
G_M000_IG32:                ;; offset=0x0704
       lea      rsi, [rbp-0x100]
       lea      rdx, [rbp-0x108]
       mov      rdi, gword ptr [rbp-0x58]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.Text.PyStringOps+CasedWhitespaceIteration:TryReadWord(byref,byref):bool:this]
       test     eax, eax
       je       G_M000_IG46
 
G_M000_IG33:                ;; offset=0x0726
       vmovdqu  xmm0, xmmword ptr [rbp-0x100]
       vmovdqu  xmmword ptr [rbp-0xD8], xmm0
 
G_M000_IG34:                ;; offset=0x0736
       mov      rax, gword ptr [rbp-0x108]
       mov      gword ptr [rbp-0xE0], rax
       cmp      dword ptr [rbp-0xE8], 0
       jne      SHORT G_M000_IG35
       mov      rdi, bword ptr [rbp-0x70]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x220], rax
       mov      rsi, gword ptr [rbp-0x220]
       mov      rdi, gword ptr [rbp-0x38]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CheckExecution(Lokad.Lython.LythonSourceSpan):this]
       mov      rax, bword ptr [rbp-0x30]
       mov      ecx, dword ptr [rbp-0x60]
       mov      dword ptr [rax+0x18], ecx
       mov      rdi, gword ptr [rbp-0x68]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_CallSpan():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x228], rax
       mov      rsi, gword ptr [rbp-0x228]
       mov      rdi, gword ptr [rbp-0x38]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:EnterInterpreterFrame(Lokad.Lython.LythonSourceSpan):this]
       mov      dword ptr [rbp-0xE8], 1
       jmp      SHORT G_M000_IG36
 
G_M000_IG35:                ;; offset=0x07AD
       mov      rdi, 0x7F236098F718
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp-0x30]
       mov      ecx, dword ptr [rbp-0x60]
       mov      dword ptr [rax+0x18], ecx
 
G_M000_IG36:                ;; offset=0x07C6
       cmp      gword ptr [rbp-0x108], 0
       jne      G_M000_IG39
 
G_M000_IG37:                ;; offset=0x07D4
       vmovdqu  xmm0, xmmword ptr [rbp-0x100]
       vmovdqu  xmmword ptr [rbp-0x170], xmm0
 
G_M000_IG38:                ;; offset=0x07E4
       mov      rdi, gword ptr [rbp-0x68]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_CallSpan():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x230], rax
       lea      rax, [rbp-0x118]
       mov      qword ptr [rsp+0x10], rax
       mov      rax, gword ptr [rbp-0x230]
       mov      gword ptr [rsp+0x08], rax
       mov      r8, gword ptr [rbp-0x98]
       mov      r9, qword ptr [rbp-0x90]
       mov      rsi, bword ptr [rbp-0x170]
       mov      rdx, qword ptr [rbp-0x168]
       mov      rcx, gword ptr [rbp-0x88]
       mov      rax, gword ptr [rbp-0x38]
       mov      gword ptr [rsp], rax
       mov      rdi, gword ptr [rbp-0xA0]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.PyDict:TryAccumulateBorrowedWord(System.ReadOnlySpan`1[byte],System.Object,System.Numerics.BigInteger,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,byref):bool:this]
       mov      dword ptr [rbp-0x10C], eax
       lea      rdi, [rbp-0x118]
       call     [System.Nullable`1[uint]:get_HasValue():bool:this]
       test     eax, eax
       je       G_M000_IG40
       mov      rdi, 0x7F236098F71C
       call     CORINFO_HELP_COUNTPROFILE32
       lea      rdi, [rbp-0x118]
       call     [System.Nullable`1[uint]:GetValueOrDefault():uint:this]
       mov      dword ptr [rbp-0x11C], eax
       mov      rdi, gword ptr [rbp-0x68]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_CallSpan():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x238], rax
       mov      rsi, gword ptr [rbp-0x238]
       mov      rdi, gword ptr [rbp-0x38]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CheckExecution(Lokad.Lython.LythonSourceSpan):this]
       mov      rsi, bword ptr [rbp-0x100]
       mov      rdx, qword ptr [rbp-0xF8]
       mov      rdi, gword ptr [rbp-0x58]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.Text.PyStringOps+CasedWhitespaceIteration:Materialize(System.ReadOnlySpan`1[byte]):Lokad.Lython.Runtime.Text.PyString:this]
       mov      gword ptr [rbp-0xE0], rax
       mov      r8, gword ptr [rbp-0x98]
       mov      r9, qword ptr [rbp-0x90]
       mov      rdi, gword ptr [rbp-0xA0]
       mov      rsi, gword ptr [rbp-0xE0]
       mov      edx, dword ptr [rbp-0x11C]
       mov      rcx, gword ptr [rbp-0x88]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.PyDict:TryAppendBorrowedWord(Lokad.Lython.Runtime.Text.PyString,uint,System.Object,System.Numerics.BigInteger):bool:this]
       mov      dword ptr [rbp-0x10C], eax
       jmp      SHORT G_M000_IG40
 
G_M000_IG39:                ;; offset=0x0906
       mov      rdi, 0x7F236098F720
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, gword ptr [rbp-0x108]
       mov      gword ptr [rbp-0x160], rax
       mov      rdi, gword ptr [rbp-0x68]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_CallSpan():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x240], rax
       mov      rax, gword ptr [rbp-0x240]
       mov      gword ptr [rsp], rax
       mov      rcx, gword ptr [rbp-0x98]
       mov      r8, qword ptr [rbp-0x90]
       mov      rsi, gword ptr [rbp-0x160]
       mov      rdx, gword ptr [rbp-0x88]
       mov      r9, gword ptr [rbp-0x38]
       mov      rdi, gword ptr [rbp-0xA0]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.PyDict:TryAccumulateWithoutAdmission(Lokad.Lython.Runtime.Text.PyString,System.Object,System.Numerics.BigInteger,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):bool:this]
       mov      dword ptr [rbp-0x10C], eax
 
G_M000_IG40:                ;; offset=0x0976
       cmp      dword ptr [rbp-0x10C], 0
       jne      SHORT G_M000_IG41
       mov      eax, dword ptr [rbp-0x5C]
       add      eax, 2
       mov      rcx, bword ptr [rbp-0x30]
       mov      dword ptr [rcx+0x18], eax
       mov      dword ptr [rbp-0x120], 1
       jmp      G_M000_IG48
 
G_M000_IG41:                ;; offset=0x099B
       cmp      dword ptr [rbp-0xB4], 0
       je       G_M000_IG45
       mov      rax, qword ptr [rbp-0xC0]
       add      rax, qword ptr [rbp-0xC8]
       mov      qword ptr [rbp-0xC0], rax
       mov      dword ptr [rbp-0xE4], 1
       mov      rax, 0xFF80000000000000
       cmp      qword ptr [rbp-0xC0], rax
       jl       SHORT G_M000_IG43
       mov      rax, 0x80000000000000
       cmp      qword ptr [rbp-0xC0], rax
       jl       SHORT G_M000_IG44
 
G_M000_IG42:                ;; offset=0x09ED
       mov      rdi, 0x7F236098F724
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG43:                ;; offset=0x09FC
       mov      rdi, 0x7F236098F728
       call     CORINFO_HELP_COUNTPROFILE32
       mov      eax, dword ptr [rbp-0xA4]
       add      eax, 2
       mov      rcx, bword ptr [rbp-0x30]
       mov      dword ptr [rcx+0x18], eax
       mov      dword ptr [rbp-0x120], 1
       jmp      G_M000_IG49
 
G_M000_IG44:                ;; offset=0x0A2A
       mov      rdi, 0x7F236098F72C
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG45:                ;; offset=0x0A39
       mov      rdi, 0x7F236098F730
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp-0x30]
       mov      ecx, dword ptr [rbp-0x5C]
       mov      dword ptr [rax+0x18], ecx
       mov      rdi, bword ptr [rbp-0x48]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x248], rax
       mov      rsi, gword ptr [rbp-0x248]
       mov      rdi, gword ptr [rbp-0x38]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CheckExecution(Lokad.Lython.LythonSourceSpan):this]
       jmp      G_M000_IG30
 
G_M000_IG46:                ;; offset=0x0A7B
       mov      rdi, 0x7F236098F734
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0xEC], 1
       mov      rdi, bword ptr [rbp-0x48]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_TargetIndex():int:this]
       mov      rcx, bword ptr [rbp-0x30]
       mov      dword ptr [rcx+0x18], eax
       mov      dword ptr [rbp-0x120], 1
 
G_M000_IG47:                ;; offset=0x0AAF
       call     G_M000_IG71
       jmp      SHORT G_M000_IG50
 
G_M000_IG48:                ;; offset=0x0AB6
       call     G_M000_IG71
       jmp      SHORT G_M000_IG50
 
G_M000_IG49:                ;; offset=0x0ABD
       call     G_M000_IG71
       nop      
 
G_M000_IG50:                ;; offset=0x0AC3
       mov      rdi, 0x7F236098F75C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      eax, dword ptr [rbp-0x120]
       mov      dword ptr [rbp-0x1C8], eax
 
G_M000_IG51:                ;; offset=0x0ADE
       movzx    rax, byte  ptr [rbp-0x1C8]
 
G_M000_IG52:                ;; offset=0x0AE5
       add      rsp, 640
       pop      rbp
       ret      
 
G_M000_IG53:                ;; offset=0x0AEE
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG54:                ;; offset=0x0AF4
       sub      rsp, 24
 
G_M000_IG55:                ;; offset=0x0AF8
       cmp      dword ptr [rbp-0xE4], 0
       je       SHORT G_M000_IG56
       mov      rdi, 0x7F236098F748
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp-0x30]
       mov      rax, gword ptr [rax+0x08]
       mov      gword ptr [rbp-0x198], rax
       mov      rdi, bword ptr [rbp-0xB0]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      rcx, gword ptr [rbp-0x198]
       cmp      eax, dword ptr [rcx+0x08]
       jae      G_M000_IG59
       mov      edx, eax
       imul     rdx, rdx, 16
       lea      rcx, bword ptr [rcx+rdx+0x10]
       mov      bword ptr [rbp-0x250], rcx
       mov      rdi, bword ptr [rbp-0x250]
       mov      rsi, qword ptr [rbp-0xC0]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:SetInteger(long):this]
 
G_M000_IG56:                ;; offset=0x0B62
       cmp      dword ptr [rbp-0xEC], 0
       je       SHORT G_M000_IG57
       mov      rdi, 0x7F236098F74C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp-0x30]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp-0x30]
       add      rax, 32
       mov      bword ptr [rbp-0x190], rax
       mov      rdi, bword ptr [rbp-0x48]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x254], eax
       mov      esi, dword ptr [rbp-0x254]
       mov      rdi, bword ptr [rbp-0x190]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
 
G_M000_IG57:                ;; offset=0x0BB2
       mov      rdi, 0x7F236098F750
       call     CORINFO_HELP_COUNTPROFILE32
       nop      
 
G_M000_IG58:                ;; offset=0x0BC2
       add      rsp, 24
       ret      
 
G_M000_IG59:                ;; offset=0x0BC7
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG60:                ;; offset=0x0BCD
       sub      rsp, 24
 
G_M000_IG61:                ;; offset=0x0BD1
       cmp      gword ptr [rbp-0xE0], 0
       jne      SHORT G_M000_IG65
       lea      rdi, [rbp-0xD8]
       call     [System.ReadOnlySpan`1[byte]:get_IsEmpty():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG62
       jmp      SHORT G_M000_IG64
 
G_M000_IG62:                ;; offset=0x0BEE
       mov      rdi, 0x7F236098F73C
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG67
 
G_M000_IG63:                ;; offset=0x0C02
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG64:                ;; offset=0x0C08
       mov      rdi, 0x7F236098F740
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG65:                ;; offset=0x0C17
       mov      rax, bword ptr [rbp-0x30]
       mov      rax, gword ptr [rax+0x08]
       mov      gword ptr [rbp-0x178], rax
       mov      rdi, bword ptr [rbp-0x80]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ThirdInput():int:this]
       mov      rcx, gword ptr [rbp-0x178]
       cmp      eax, dword ptr [rcx+0x08]
       jae      SHORT G_M000_IG63
       mov      edx, eax
       imul     rdx, rdx, 16
       lea      rcx, bword ptr [rcx+rdx+0x10]
       mov      bword ptr [rbp-0x180], rcx
       mov      rax, gword ptr [rbp-0xE0]
       mov      gword ptr [rbp-0x188], rax
       cmp      gword ptr [rbp-0xE0], 0
       jne      SHORT G_M000_IG66
       mov      rdi, 0x7F236098F744
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rsi, bword ptr [rbp-0xD8]
       mov      rdx, qword ptr [rbp-0xD0]
       mov      rdi, gword ptr [rbp-0x58]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.Text.PyStringOps+CasedWhitespaceIteration:Materialize(System.ReadOnlySpan`1[byte]):Lokad.Lython.Runtime.Text.PyString:this]
       mov      gword ptr [rbp-0x188], rax
 
G_M000_IG66:                ;; offset=0x0C96
       mov      rdi, bword ptr [rbp-0x180]
       mov      rsi, gword ptr [rbp-0x188]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:set_Object(System.Object):this]
 
G_M000_IG67:                ;; offset=0x0CAA
       nop      
 
G_M000_IG68:                ;; offset=0x0CAB
       call     G_M000_IG54
       nop      
 
G_M000_IG69:                ;; offset=0x0CB1
       mov      rdi, 0x7F236098F754
       call     CORINFO_HELP_COUNTPROFILE32
       nop      
 
G_M000_IG70:                ;; offset=0x0CC1
       add      rsp, 24
       ret      
 
G_M000_IG71:                ;; offset=0x0CC6
       sub      rsp, 24
 
G_M000_IG72:                ;; offset=0x0CCA
       cmp      dword ptr [rbp-0xE8], 0
       je       SHORT G_M000_IG73
       mov      rdi, 0x7F236098F738
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, gword ptr [rbp-0x38]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:LeaveInterpreterFrame():this]
 
G_M000_IG73:                ;; offset=0x0CEE
       nop      
 
G_M000_IG74:                ;; offset=0x0CEF
       call     G_M000_IG60
       nop      
 
G_M000_IG75:                ;; offset=0x0CF5
       mov      rdi, 0x7F236098F758
       call     CORINFO_HELP_COUNTPROFILE32
       nop      
 
G_M000_IG76:                ;; offset=0x0D05
       add      rsp, 24
       ret      
 
; Total bytes of code 3338

; Assembly listing for method Lokad.Lython.Runtime.PyDict:TryAccumulateBorrowedWord(System.ReadOnlySpan`1[byte],System.Object,System.Numerics.BigInteger,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,byref):bool:this (Tier0)
; Emitting BLENDED_CODE for x64 + VEX on Unix
; Tier0 code
; rbp based frame
; partially interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 112
       lea      rbp, [rsp+0x70]
       vxorps   xmm8, xmm8, xmm8
       vmovdqu  ymmword ptr [rbp-0x60], ymm8
       vmovdqa  xmmword ptr [rbp-0x40], xmm8
       mov      gword ptr [rbp-0x08], rdi
       mov      bword ptr [rbp-0x18], rsi
       mov      qword ptr [rbp-0x10], rdx
       mov      gword ptr [rbp-0x20], rcx
       mov      gword ptr [rbp-0x30], r8
       mov      qword ptr [rbp-0x28], r9
 
G_M000_IG02:                ;; offset=0x0031
       mov      rdi, gword ptr [rbp+0x10]
       mov      rsi, gword ptr [rbp+0x18]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CheckExecution(Lokad.Lython.LythonSourceSpan):this]
       mov      rax, gword ptr [rbp-0x08]
       mov      rax, gword ptr [rax+0x28]
       mov      gword ptr [rbp-0x38], rax
       lea      rax, [rbp-0x48]
       mov      qword ptr [rsp], rax
       mov      rdx, bword ptr [rbp-0x18]
       mov      rcx, qword ptr [rbp-0x10]
       mov      rax, gword ptr [rbp-0x08]
       mov      esi, dword ptr [rax+0x4C]
       mov      rdi, gword ptr [rbp-0x38]
       mov      r8, gword ptr [rbp+0x10]
       mov      r9, gword ptr [rbp+0x18]
       call     [Lokad.Lython.Runtime.PyDict:FindNativeTextIndex(Lokad.Lython.Runtime.PyDict+NativeKey[],int,System.ReadOnlySpan`1[byte],Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,byref):int]
       mov      dword ptr [rbp-0x3C], eax
       mov      rax, bword ptr [rbp+0x20]
       xor      ecx, ecx
       mov      qword ptr [rax], rcx
       cmp      dword ptr [rbp-0x3C], 0
       jge      SHORT G_M000_IG05
       cmp      dword ptr [rbp-0x10], 8
       jle      SHORT G_M000_IG03
       mov      rax, gword ptr [rbp-0x08]
       mov      eax, dword ptr [rax+0x4C]
       mov      rcx, gword ptr [rbp-0x38]
       cmp      eax, dword ptr [rcx+0x08]
       jge      SHORT G_M000_IG03
       xor      eax, eax
       mov      qword ptr [rbp-0x58], rax
       lea      rdi, [rbp-0x58]
       mov      esi, dword ptr [rbp-0x48]
       call     [System.Nullable`1[uint]:.ctor(uint):this]
       mov      rax, bword ptr [rbp+0x20]
       mov      rcx, qword ptr [rbp-0x58]
       mov      qword ptr [rax], rcx
 
G_M000_IG03:                ;; offset=0x00BC
       xor      eax, eax
 
G_M000_IG04:                ;; offset=0x00BE
       add      rsp, 112
       pop      rbp
       ret      
 
G_M000_IG05:                ;; offset=0x00C4
       mov      rax, gword ptr [rbp-0x38]
       mov      ecx, dword ptr [rbp-0x3C]
       cmp      ecx, dword ptr [rax+0x08]
       jae      SHORT G_M000_IG07
       mov      edx, ecx
       imul     rdx, rdx, 40
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      bword ptr [rbp-0x50], rax
       mov      rax, bword ptr [rbp-0x50]
       mov      rsi, gword ptr [rax]
       mov      rdi, 0x7F23603BFBC0
       call     [CORINFO_HELP_CHKCASTCLASS]
       mov      gword ptr [rbp-0x60], rax
       lea      rdi, [rsp]
       lea      rsi, [rbp-0x30]
       mov      rcx, gword ptr [rsi]
       mov      gword ptr [rsp], rcx
       add      rsi, 8
       add      rdi, 8
       movsq    
       mov      rdx, gword ptr [rbp-0x60]
       mov      rax, bword ptr [rbp-0x50]
       mov      ecx, dword ptr [rax+0x18]
       mov      esi, dword ptr [rbp-0x3C]
       mov      rdi, gword ptr [rbp-0x08]
       mov      r8, gword ptr [rbp-0x20]
       call     [Lokad.Lython.Runtime.PyDict:TryAccumulateAt(int,Lokad.Lython.Runtime.Text.PyString,uint,System.Object,System.Numerics.BigInteger):bool:this]
       nop      
 
G_M000_IG06:                ;; offset=0x0130
       add      rsp, 112
       pop      rbp
       ret      
 
G_M000_IG07:                ;; offset=0x0136
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
; Total bytes of code 316

; Assembly listing for method Lokad.Lython.Runtime.PyDict:FindNativeTextIndex(Lokad.Lython.Runtime.PyDict+NativeKey[],int,System.ReadOnlySpan`1[byte],Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,byref):int (Instrumented Tier0)
; Emitting BLENDED_CODE for x64 + VEX on Unix
; Instrumented Tier0 code
; rbp based frame
; fully interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 192
       lea      rbp, [rsp+0xC0]
       vxorps   xmm8, xmm8, xmm8
       vmovdqu  ymmword ptr [rbp-0xB0], ymm8
       vmovdqu  ymmword ptr [rbp-0x90], ymm8
       vmovdqa  xmmword ptr [rbp-0x70], xmm8
       xor      eax, eax
       mov      qword ptr [rbp-0x60], rax
       mov      gword ptr [rbp-0x30], rdi
       mov      dword ptr [rbp-0x34], esi
       mov      bword ptr [rbp-0x48], rdx
       mov      qword ptr [rbp-0x40], rcx
       mov      gword ptr [rbp-0x50], r8
       mov      gword ptr [rbp-0x58], r9
 
G_M000_IG02:                ;; offset=0x0047
       mov      dword ptr [rbp-0xB4], 0x3E8
       cmp      dword ptr [rbp-0x34], 4
       jg       G_M000_IG12
       cmp      dword ptr [rbp-0x40], 8
       jg       SHORT G_M000_IG03
       mov      rax, bword ptr [rbp+0x10]
       xor      ecx, ecx
       mov      dword ptr [rax], ecx
       xor      eax, eax
       mov      dword ptr [rbp-0x5C], eax
       jmp      G_M000_IG09
 
G_M000_IG03:                ;; offset=0x0073
       mov      rdi, 0x7F236098F978
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG12
 
G_M000_IG04:                ;; offset=0x0087
       mov      rax, gword ptr [rbp-0x30]
       mov      ecx, dword ptr [rbp-0x5C]
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG26
       mov      edx, ecx
       imul     rdx, rdx, 40
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      rsi, gword ptr [rax]
       mov      rdi, 0x7F23603BFBC0
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      gword ptr [rbp-0x68], rax
       cmp      gword ptr [rbp-0x68], 0
       je       SHORT G_M000_IG08
 
G_M000_IG05:                ;; offset=0x00C0
       vmovdqu  xmm0, xmmword ptr [rbp-0x48]
       vmovdqu  xmmword ptr [rbp-0xB0], xmm0
 
G_M000_IG06:                ;; offset=0x00CD
       mov      rdi, gword ptr [rbp-0x68]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.Text.PyString:get_Utf8Span():System.ReadOnlySpan`1[byte]:this]
       mov      bword ptr [rbp-0xA0], rax
       mov      qword ptr [rbp-0x98], rdx
       mov      rdx, bword ptr [rbp-0xA0]
       mov      rcx, qword ptr [rbp-0x98]
       mov      rdi, bword ptr [rbp-0xB0]
       mov      rsi, qword ptr [rbp-0xA8]
       call     [System.MemoryExtensions:SequenceEqual[byte](System.ReadOnlySpan`1[byte],System.ReadOnlySpan`1[byte]):bool]
       test     eax, eax
       je       SHORT G_M000_IG07
       mov      rdi, 0x7F236098F97C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      eax, dword ptr [rbp-0x5C]
       mov      dword ptr [rbp-0xB8], eax
       jmp      G_M000_IG24
 
G_M000_IG07:                ;; offset=0x012A
       mov      rdi, 0x7F236098F980
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG08:                ;; offset=0x0139
       mov      rdi, 0x7F236098F984
       call     CORINFO_HELP_COUNTPROFILE32
       mov      eax, dword ptr [rbp-0x5C]
       inc      eax
       mov      dword ptr [rbp-0x5C], eax
 
G_M000_IG09:                ;; offset=0x0150
       mov      eax, dword ptr [rbp-0xB4]
       dec      eax
       mov      dword ptr [rbp-0xB4], eax
       cmp      dword ptr [rbp-0xB4], 0
       jg       SHORT G_M000_IG11
 
G_M000_IG10:                ;; offset=0x0167
       lea      rdi, [rbp-0xB4]
       mov      esi, 63
       call     CORINFO_HELP_PATCHPOINT
       jmp      rax
 
G_M000_IG11:                ;; offset=0x017A
       mov      eax, dword ptr [rbp-0x5C]
       cmp      eax, dword ptr [rbp-0x34]
       jl       G_M000_IG04
       mov      rdi, 0x7F236098F988
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG22
 
G_M000_IG12:                ;; offset=0x019A
       vmovdqu  xmm0, xmmword ptr [rbp-0x48]
       vmovdqu  xmmword ptr [rbp-0x90], xmm0
 
G_M000_IG13:                ;; offset=0x01A7
       xor      eax, eax
       mov      gword ptr [rbp-0x70], rax
       mov      rdi, bword ptr [rbp-0x90]
       mov      rsi, qword ptr [rbp-0x88]
       mov      rdx, gword ptr [rbp-0x50]
       mov      rcx, gword ptr [rbp-0x58]
       mov      r8, gword ptr [rbp-0x70]
       call     [Lokad.Lython.Runtime.Text.PyString:HashUtf8(System.ReadOnlySpan`1[byte],Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,System.Threading.CancellationToken):int]
       mov      edi, eax
       call     [Lokad.Lython.Runtime.PyValueComparer:NormalizeHash(int):int]
       mov      edi, eax
       call     [Lokad.Lython.Runtime.PyDict:MixNativeHash(int):uint]
       mov      rcx, bword ptr [rbp+0x10]
       mov      dword ptr [rcx], eax
       cmp      dword ptr [rbp-0x34], 0
       jne      SHORT G_M000_IG14
       mov      rdi, 0x7F236098F98C
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG22
 
G_M000_IG14:                ;; offset=0x01FD
       mov      rax, gword ptr [rbp-0x30]
       mov      esi, dword ptr [rax+0x08]
       mov      rax, bword ptr [rbp+0x10]
       mov      edi, dword ptr [rax]
       call     [Lokad.Lython.Runtime.PyDict:NativeBucket(uint,int):int]
       mov      rcx, gword ptr [rbp-0x30]
       cmp      eax, dword ptr [rcx+0x08]
       jae      G_M000_IG26
       mov      edx, eax
       imul     rdx, rdx, 40
       lea      rcx, bword ptr [rcx+rdx+0x10]
       mov      eax, dword ptr [rcx+0x20]
       dec      eax
       mov      dword ptr [rbp-0x74], eax
       jmp      G_M000_IG19
 
G_M000_IG15:                ;; offset=0x0235
       mov      rdi, gword ptr [rbp-0x50]
       mov      rsi, gword ptr [rbp-0x58]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CheckExecution(Lokad.Lython.LythonSourceSpan):this]
       mov      rax, gword ptr [rbp-0x30]
       mov      ecx, dword ptr [rbp-0x74]
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG26
       mov      edx, ecx
       imul     rdx, rdx, 40
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      eax, dword ptr [rax+0x18]
       mov      rcx, bword ptr [rbp+0x10]
       cmp      eax, dword ptr [rcx]
       jne      G_M000_IG18
       mov      rax, gword ptr [rbp-0x30]
       mov      ecx, dword ptr [rbp-0x74]
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG26
       mov      edx, ecx
       imul     rdx, rdx, 40
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      rsi, gword ptr [rax]
       mov      rdi, 0x7F23603BFBC0
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      gword ptr [rbp-0x80], rax
       cmp      gword ptr [rbp-0x80], 0
       je       SHORT G_M000_IG17
       mov      rsi, bword ptr [rbp-0x48]
       mov      rdx, qword ptr [rbp-0x40]
       mov      rdi, gword ptr [rbp-0x80]
       mov      rcx, gword ptr [rbp-0x50]
       mov      r8, gword ptr [rbp-0x58]
       call     [Lokad.Lython.Runtime.PyDict:EqualNativeText(Lokad.Lython.Runtime.Text.PyString,System.ReadOnlySpan`1[byte],Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):bool]
       test     eax, eax
       je       SHORT G_M000_IG16
       mov      rdi, 0x7F236098F990
       call     CORINFO_HELP_COUNTPROFILE32
       mov      eax, dword ptr [rbp-0x74]
       mov      dword ptr [rbp-0xB8], eax
       jmp      G_M000_IG24
 
G_M000_IG16:                ;; offset=0x02E3
       mov      rdi, 0x7F236098F994
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG18
 
G_M000_IG17:                ;; offset=0x02F4
       mov      rdi, 0x7F236098F998
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG18:                ;; offset=0x0303
       mov      rdi, 0x7F236098F99C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, gword ptr [rbp-0x30]
       mov      ecx, dword ptr [rbp-0x74]
       cmp      ecx, dword ptr [rax+0x08]
       jae      SHORT G_M000_IG26
       mov      edx, ecx
       imul     rdx, rdx, 40
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      eax, dword ptr [rax+0x1C]
       dec      eax
       mov      dword ptr [rbp-0x74], eax
 
G_M000_IG19:                ;; offset=0x0331
       mov      eax, dword ptr [rbp-0xB4]
       dec      eax
       mov      dword ptr [rbp-0xB4], eax
       cmp      dword ptr [rbp-0xB4], 0
       jg       SHORT G_M000_IG21
 
G_M000_IG20:                ;; offset=0x0348
       lea      rdi, [rbp-0xB4]
       mov      esi, 210
       call     CORINFO_HELP_PATCHPOINT
       jmp      rax
 
G_M000_IG21:                ;; offset=0x035B
       cmp      dword ptr [rbp-0x74], 0
       jge      G_M000_IG15
       mov      rdi, 0x7F236098F9A0
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG22:                ;; offset=0x0374
       mov      eax, -1
 
G_M000_IG23:                ;; offset=0x0379
       add      rsp, 192
       pop      rbp
       ret      
 
G_M000_IG24:                ;; offset=0x0382
       mov      eax, dword ptr [rbp-0xB8]
 
G_M000_IG25:                ;; offset=0x0388
       add      rsp, 192
       pop      rbp
       ret      
 
G_M000_IG26:                ;; offset=0x0391
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
; Total bytes of code 919

; Assembly listing for method Lokad.Lython.Runtime.PyDict:TryAccumulateBorrowedWord(System.ReadOnlySpan`1[byte],System.Object,System.Numerics.BigInteger,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,byref):bool:this (Instrumented Tier0)
; Emitting BLENDED_CODE for x64 + VEX on Unix
; Instrumented Tier0 code
; rbp based frame
; partially interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 112
       lea      rbp, [rsp+0x70]
       vxorps   xmm8, xmm8, xmm8
       vmovdqu  ymmword ptr [rbp-0x60], ymm8
       vmovdqa  xmmword ptr [rbp-0x40], xmm8
       mov      gword ptr [rbp-0x08], rdi
       mov      bword ptr [rbp-0x18], rsi
       mov      qword ptr [rbp-0x10], rdx
       mov      gword ptr [rbp-0x20], rcx
       mov      gword ptr [rbp-0x30], r8
       mov      qword ptr [rbp-0x28], r9
 
G_M000_IG02:                ;; offset=0x0031
       mov      rdi, gword ptr [rbp+0x10]
       mov      rsi, gword ptr [rbp+0x18]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CheckExecution(Lokad.Lython.LythonSourceSpan):this]
       mov      rax, gword ptr [rbp-0x08]
       mov      rax, gword ptr [rax+0x28]
       mov      gword ptr [rbp-0x38], rax
       lea      rax, [rbp-0x48]
       mov      qword ptr [rsp], rax
       mov      rdx, bword ptr [rbp-0x18]
       mov      rcx, qword ptr [rbp-0x10]
       mov      rax, gword ptr [rbp-0x08]
       mov      esi, dword ptr [rax+0x4C]
       mov      rdi, gword ptr [rbp-0x38]
       mov      r8, gword ptr [rbp+0x10]
       mov      r9, gword ptr [rbp+0x18]
       call     [Lokad.Lython.Runtime.PyDict:FindNativeTextIndex(Lokad.Lython.Runtime.PyDict+NativeKey[],int,System.ReadOnlySpan`1[byte],Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,byref):int]
       mov      dword ptr [rbp-0x3C], eax
       mov      rax, bword ptr [rbp+0x20]
       xor      ecx, ecx
       mov      qword ptr [rax], rcx
       cmp      dword ptr [rbp-0x3C], 0
       jge      SHORT G_M000_IG06
       cmp      dword ptr [rbp-0x10], 8
       jle      SHORT G_M000_IG03
       mov      rax, gword ptr [rbp-0x08]
       mov      eax, dword ptr [rax+0x4C]
       mov      rcx, gword ptr [rbp-0x38]
       cmp      eax, dword ptr [rcx+0x08]
       jge      SHORT G_M000_IG05
       mov      rdi, 0x7F2360E84AB8
       call     CORINFO_HELP_COUNTPROFILE32
       xor      eax, eax
       mov      qword ptr [rbp-0x58], rax
       lea      rdi, [rbp-0x58]
       mov      esi, dword ptr [rbp-0x48]
       call     [System.Nullable`1[uint]:.ctor(uint):this]
       mov      rax, bword ptr [rbp+0x20]
       mov      rcx, qword ptr [rbp-0x58]
       mov      qword ptr [rax], rcx
 
G_M000_IG03:                ;; offset=0x00CB
       mov      rdi, 0x7F2360E84ABC
       call     CORINFO_HELP_COUNTPROFILE32
       xor      eax, eax
 
G_M000_IG04:                ;; offset=0x00DC
       add      rsp, 112
       pop      rbp
       ret      
 
G_M000_IG05:                ;; offset=0x00E2
       mov      rdi, 0x7F2360E84AC0
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG03
 
G_M000_IG06:                ;; offset=0x00F3
       mov      rdi, 0x7F2360E84AC4
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, gword ptr [rbp-0x38]
       mov      ecx, dword ptr [rbp-0x3C]
       cmp      ecx, dword ptr [rax+0x08]
       jae      SHORT G_M000_IG08
       mov      edx, ecx
       imul     rdx, rdx, 40
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      bword ptr [rbp-0x50], rax
       mov      rax, bword ptr [rbp-0x50]
       mov      rsi, gword ptr [rax]
       mov      rdi, 0x7F23603BFBC0
       call     [CORINFO_HELP_CHKCASTCLASS]
       mov      gword ptr [rbp-0x60], rax
       lea      rdi, [rsp]
       lea      rsi, [rbp-0x30]
       mov      rcx, gword ptr [rsi]
       mov      gword ptr [rsp], rcx
       add      rsi, 8
       add      rdi, 8
       movsq    
       mov      rdx, gword ptr [rbp-0x60]
       mov      rax, bword ptr [rbp-0x50]
       mov      ecx, dword ptr [rax+0x18]
       mov      esi, dword ptr [rbp-0x3C]
       mov      rdi, gword ptr [rbp-0x08]
       mov      r8, gword ptr [rbp-0x20]
       call     [Lokad.Lython.Runtime.PyDict:TryAccumulateAt(int,Lokad.Lython.Runtime.Text.PyString,uint,System.Object,System.Numerics.BigInteger):bool:this]
       nop      
 
G_M000_IG07:                ;; offset=0x016E
       add      rsp, 112
       pop      rbp
       ret      
 
G_M000_IG08:                ;; offset=0x0174
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
; Total bytes of code 378

; Assembly listing for method Lokad.Lython.Runtime.PyDict:FindNativeTextIndex(Lokad.Lython.Runtime.PyDict+NativeKey[],int,System.ReadOnlySpan`1[byte],Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,byref):int (Instrumented Tier0)
; Emitting BLENDED_CODE for x64 + VEX on Unix
; Instrumented Tier0 code
; rbp based frame
; fully interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 192
       lea      rbp, [rsp+0xC0]
       vxorps   xmm8, xmm8, xmm8
       vmovdqu  ymmword ptr [rbp-0xB0], ymm8
       vmovdqu  ymmword ptr [rbp-0x90], ymm8
       vmovdqa  xmmword ptr [rbp-0x70], xmm8
       xor      eax, eax
       mov      qword ptr [rbp-0x60], rax
       mov      gword ptr [rbp-0x30], rdi
       mov      dword ptr [rbp-0x34], esi
       mov      bword ptr [rbp-0x48], rdx
       mov      qword ptr [rbp-0x40], rcx
       mov      gword ptr [rbp-0x50], r8
       mov      gword ptr [rbp-0x58], r9
 
G_M000_IG02:                ;; offset=0x0047
       mov      dword ptr [rbp-0xB4], 0x3E8
       cmp      dword ptr [rbp-0x34], 4
       jg       G_M000_IG12
       cmp      dword ptr [rbp-0x40], 8
       jg       SHORT G_M000_IG03
       mov      rax, bword ptr [rbp+0x10]
       xor      ecx, ecx
       mov      dword ptr [rax], ecx
       xor      eax, eax
       mov      dword ptr [rbp-0x5C], eax
       jmp      G_M000_IG09
 
G_M000_IG03:                ;; offset=0x0073
       mov      rdi, 0x7F236098F978
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG12
 
G_M000_IG04:                ;; offset=0x0087
       mov      rax, gword ptr [rbp-0x30]
       mov      ecx, dword ptr [rbp-0x5C]
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG26
       mov      edx, ecx
       imul     rdx, rdx, 40
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      rsi, gword ptr [rax]
       mov      rdi, 0x7F23603BFBC0
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      gword ptr [rbp-0x68], rax
       cmp      gword ptr [rbp-0x68], 0
       je       SHORT G_M000_IG08
 
G_M000_IG05:                ;; offset=0x00C0
       vmovdqu  xmm0, xmmword ptr [rbp-0x48]
       vmovdqu  xmmword ptr [rbp-0xB0], xmm0
 
G_M000_IG06:                ;; offset=0x00CD
       mov      rdi, gword ptr [rbp-0x68]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.Text.PyString:get_Utf8Span():System.ReadOnlySpan`1[byte]:this]
       mov      bword ptr [rbp-0xA0], rax
       mov      qword ptr [rbp-0x98], rdx
       mov      rdx, bword ptr [rbp-0xA0]
       mov      rcx, qword ptr [rbp-0x98]
       mov      rdi, bword ptr [rbp-0xB0]
       mov      rsi, qword ptr [rbp-0xA8]
       call     [System.MemoryExtensions:SequenceEqual[byte](System.ReadOnlySpan`1[byte],System.ReadOnlySpan`1[byte]):bool]
       test     eax, eax
       je       SHORT G_M000_IG07
       mov      rdi, 0x7F236098F97C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      eax, dword ptr [rbp-0x5C]
       mov      dword ptr [rbp-0xB8], eax
       jmp      G_M000_IG24
 
G_M000_IG07:                ;; offset=0x012A
       mov      rdi, 0x7F236098F980
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG08:                ;; offset=0x0139
       mov      rdi, 0x7F236098F984
       call     CORINFO_HELP_COUNTPROFILE32
       mov      eax, dword ptr [rbp-0x5C]
       inc      eax
       mov      dword ptr [rbp-0x5C], eax
 
G_M000_IG09:                ;; offset=0x0150
       mov      eax, dword ptr [rbp-0xB4]
       dec      eax
       mov      dword ptr [rbp-0xB4], eax
       cmp      dword ptr [rbp-0xB4], 0
       jg       SHORT G_M000_IG11
 
G_M000_IG10:                ;; offset=0x0167
       lea      rdi, [rbp-0xB4]
       mov      esi, 63
       call     CORINFO_HELP_PATCHPOINT
       jmp      rax
 
G_M000_IG11:                ;; offset=0x017A
       mov      eax, dword ptr [rbp-0x5C]
       cmp      eax, dword ptr [rbp-0x34]
       jl       G_M000_IG04
       mov      rdi, 0x7F236098F988
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG22
 
G_M000_IG12:                ;; offset=0x019A
       vmovdqu  xmm0, xmmword ptr [rbp-0x48]
       vmovdqu  xmmword ptr [rbp-0x90], xmm0
 
G_M000_IG13:                ;; offset=0x01A7
       xor      eax, eax
       mov      gword ptr [rbp-0x70], rax
       mov      rdi, bword ptr [rbp-0x90]
       mov      rsi, qword ptr [rbp-0x88]
       mov      rdx, gword ptr [rbp-0x50]
       mov      rcx, gword ptr [rbp-0x58]
       mov      r8, gword ptr [rbp-0x70]
       call     [Lokad.Lython.Runtime.Text.PyString:HashUtf8(System.ReadOnlySpan`1[byte],Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,System.Threading.CancellationToken):int]
       mov      edi, eax
       call     [Lokad.Lython.Runtime.PyValueComparer:NormalizeHash(int):int]
       mov      edi, eax
       call     [Lokad.Lython.Runtime.PyDict:MixNativeHash(int):uint]
       mov      rcx, bword ptr [rbp+0x10]
       mov      dword ptr [rcx], eax
       cmp      dword ptr [rbp-0x34], 0
       jne      SHORT G_M000_IG14
       mov      rdi, 0x7F236098F98C
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG22
 
G_M000_IG14:                ;; offset=0x01FD
       mov      rax, gword ptr [rbp-0x30]
       mov      esi, dword ptr [rax+0x08]
       mov      rax, bword ptr [rbp+0x10]
       mov      edi, dword ptr [rax]
       call     [Lokad.Lython.Runtime.PyDict:NativeBucket(uint,int):int]
       mov      rcx, gword ptr [rbp-0x30]
       cmp      eax, dword ptr [rcx+0x08]
       jae      G_M000_IG26
       mov      edx, eax
       imul     rdx, rdx, 40
       lea      rcx, bword ptr [rcx+rdx+0x10]
       mov      eax, dword ptr [rcx+0x20]
       dec      eax
       mov      dword ptr [rbp-0x74], eax
       jmp      G_M000_IG19
 
G_M000_IG15:                ;; offset=0x0235
       mov      rdi, gword ptr [rbp-0x50]
       mov      rsi, gword ptr [rbp-0x58]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CheckExecution(Lokad.Lython.LythonSourceSpan):this]
       mov      rax, gword ptr [rbp-0x30]
       mov      ecx, dword ptr [rbp-0x74]
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG26
       mov      edx, ecx
       imul     rdx, rdx, 40
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      eax, dword ptr [rax+0x18]
       mov      rcx, bword ptr [rbp+0x10]
       cmp      eax, dword ptr [rcx]
       jne      G_M000_IG18
       mov      rax, gword ptr [rbp-0x30]
       mov      ecx, dword ptr [rbp-0x74]
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG26
       mov      edx, ecx
       imul     rdx, rdx, 40
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      rsi, gword ptr [rax]
       mov      rdi, 0x7F23603BFBC0
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      gword ptr [rbp-0x80], rax
       cmp      gword ptr [rbp-0x80], 0
       je       SHORT G_M000_IG17
       mov      rsi, bword ptr [rbp-0x48]
       mov      rdx, qword ptr [rbp-0x40]
       mov      rdi, gword ptr [rbp-0x80]
       mov      rcx, gword ptr [rbp-0x50]
       mov      r8, gword ptr [rbp-0x58]
       call     [Lokad.Lython.Runtime.PyDict:EqualNativeText(Lokad.Lython.Runtime.Text.PyString,System.ReadOnlySpan`1[byte],Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):bool]
       test     eax, eax
       je       SHORT G_M000_IG16
       mov      rdi, 0x7F236098F990
       call     CORINFO_HELP_COUNTPROFILE32
       mov      eax, dword ptr [rbp-0x74]
       mov      dword ptr [rbp-0xB8], eax
       jmp      G_M000_IG24
 
G_M000_IG16:                ;; offset=0x02E3
       mov      rdi, 0x7F236098F994
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG18
 
G_M000_IG17:                ;; offset=0x02F4
       mov      rdi, 0x7F236098F998
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG18:                ;; offset=0x0303
       mov      rdi, 0x7F236098F99C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, gword ptr [rbp-0x30]
       mov      ecx, dword ptr [rbp-0x74]
       cmp      ecx, dword ptr [rax+0x08]
       jae      SHORT G_M000_IG26
       mov      edx, ecx
       imul     rdx, rdx, 40
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      eax, dword ptr [rax+0x1C]
       dec      eax
       mov      dword ptr [rbp-0x74], eax
 
G_M000_IG19:                ;; offset=0x0331
       mov      eax, dword ptr [rbp-0xB4]
       dec      eax
       mov      dword ptr [rbp-0xB4], eax
       cmp      dword ptr [rbp-0xB4], 0
       jg       SHORT G_M000_IG21
 
G_M000_IG20:                ;; offset=0x0348
       lea      rdi, [rbp-0xB4]
       mov      esi, 210
       call     CORINFO_HELP_PATCHPOINT
       jmp      rax
 
G_M000_IG21:                ;; offset=0x035B
       cmp      dword ptr [rbp-0x74], 0
       jge      G_M000_IG15
       mov      rdi, 0x7F236098F9A0
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG22:                ;; offset=0x0374
       mov      eax, -1
 
G_M000_IG23:                ;; offset=0x0379
       add      rsp, 192
       pop      rbp
       ret      
 
G_M000_IG24:                ;; offset=0x0382
       mov      eax, dword ptr [rbp-0xB8]
 
G_M000_IG25:                ;; offset=0x0388
       add      rsp, 192
       pop      rbp
       ret      
 
G_M000_IG26:                ;; offset=0x0391
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
; Total bytes of code 919

; Assembly listing for method Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteDictionaryLoop(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool (Instrumented Tier0)
; Emitting BLENDED_CODE for x64 + VEX on Unix
; Instrumented Tier0 code
; rbp based frame
; fully interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 640
       lea      rbp, [rsp+0x280]
       vxorps   xmm8, xmm8, xmm8
       mov      rax, -528
 
G_M000_IG77:                ;; offset=0x001F
       vmovdqa  xmmword ptr [rbp+rax-0x50], xmm8
       vmovdqa  xmmword ptr [rbp+rax-0x40], xmm8
       vmovdqa  xmmword ptr [rbp+rax-0x30], xmm8
       add      rax, 48
       jne      SHORT G_M000_IG77
       mov      qword ptr [rbp-0x50], rax
       mov      bword ptr [rbp-0x30], rdi
       mov      gword ptr [rbp-0x38], rsi
       mov      gword ptr [rbp-0x40], rdx
       mov      bword ptr [rbp-0x48], rcx
 
G_M000_IG02:                ;; offset=0x004B
       mov      dword ptr [rbp-0x1C4], 0x3E8
       mov      rax, bword ptr [rbp-0x30]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp-0x30]
       lea      rdi, bword ptr [rax+0x20]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:get_LiveExtent():int:this]
       mov      dword ptr [rbp-0x124], eax
       mov      rdi, bword ptr [rbp-0x48]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       cmp      eax, dword ptr [rbp-0x124]
       jne      SHORT G_M000_IG04
       mov      rax, bword ptr [rbp-0x30]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp-0x30]
       lea      rdi, bword ptr [rax+0x20]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:get_HasPendingDisposals():bool:this]
       test     eax, eax
       je       SHORT G_M000_IG05
 
G_M000_IG03:                ;; offset=0x0099
       mov      rdi, 0x7F236098F5D8
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG04:                ;; offset=0x00A8
       mov      rdi, 0x7F236098F5DC
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG24
 
G_M000_IG05:                ;; offset=0x00BC
       mov      rax, bword ptr [rbp-0x30]
       mov      rdi, gword ptr [rax]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_RequiresLocalVariableMirroring():bool:this]
       test     eax, eax
       jne      G_M000_IG11
       cmp      gword ptr [rbp-0x40], 0
       jne      SHORT G_M000_IG06
       mov      dword ptr [rbp-0x1AC], 1
       jmp      SHORT G_M000_IG07
 
G_M000_IG06:                ;; offset=0x00E6
       mov      rdi, 0x7F236098F5E0
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, gword ptr [rbp-0x40]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:get_MirrorLocalStores():bool:this]
       test     eax, eax
       sete     al
       movzx    rax, al
       mov      dword ptr [rbp-0x1AC], eax
 
G_M000_IG07:                ;; offset=0x010D
       cmp      dword ptr [rbp-0x1AC], 0
       je       SHORT G_M000_IG08
       cmp      gword ptr [rbp-0x40], 0
       jne      SHORT G_M000_IG09
       xor      rax, rax
       mov      gword ptr [rbp-0x1B8], rax
       jmp      SHORT G_M000_IG10
 
G_M000_IG08:                ;; offset=0x0128
       mov      rdi, 0x7F236098F5E4
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG11
 
G_M000_IG09:                ;; offset=0x0139
       mov      rdi, 0x7F236098F5E8
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, gword ptr [rbp-0x40]
       mov      rax, gword ptr [rax+0x88]
       mov      gword ptr [rbp-0x1B8], rax
 
G_M000_IG10:                ;; offset=0x015A
       mov      rdi, 0x7F236098F5EC
       call     CORINFO_HELP_COUNTPROFILE32
       cmp      gword ptr [rbp-0x1B8], 0
       sete     al
       movzx    rax, al
       mov      dword ptr [rbp-0x128], eax
       jmp      SHORT G_M000_IG12
 
G_M000_IG11:                ;; offset=0x017F
       xor      eax, eax
       mov      dword ptr [rbp-0x128], eax
 
G_M000_IG12:                ;; offset=0x0187
       movzx    rax, byte  ptr [rbp-0x128]
       mov      dword ptr [rbp-0x4C], eax
       cmp      dword ptr [rbp-0x4C], 0
       je       G_M000_IG14
       mov      rax, bword ptr [rbp-0x30]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp-0x30]
       add      rax, 32
       mov      bword ptr [rbp-0x130], rax
       mov      rdi, bword ptr [rbp-0x48]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x1CC], eax
       mov      esi, dword ptr [rbp-0x1CC]
       mov      rdi, bword ptr [rbp-0x130]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:get_Item(int):System.Object:this]
       mov      gword ptr [rbp-0x1D8], rax
       mov      rsi, gword ptr [rbp-0x1D8]
       mov      rdi, 0x7F236096E688
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      gword ptr [rbp-0x58], rax
       cmp      gword ptr [rbp-0x58], 0
       je       SHORT G_M000_IG15
       mov      rdi, gword ptr [rbp-0x58]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.Text.PyStringOps+CasedWhitespaceIteration:get_MemoryGovernor():Lokad.Lython.Runtime.MemoryGovernor:this]
       mov      gword ptr [rbp-0x138], rax
       mov      rdi, gword ptr [rbp-0x38]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:get_MemoryGovernor():Lokad.Lython.Runtime.MemoryGovernor:this]
       cmp      rax, gword ptr [rbp-0x138]
       je       SHORT G_M000_IG16
 
G_M000_IG13:                ;; offset=0x0224
       mov      rdi, 0x7F236098F5F0
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG14:                ;; offset=0x0233
       mov      rdi, 0x7F236098F5F4
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, bword ptr [rbp-0x30]
       mov      rsi, gword ptr [rbp-0x38]
       mov      rdx, gword ptr [rbp-0x40]
       mov      rcx, bword ptr [rbp-0x48]
       mov      r8d, dword ptr [rbp-0x4C]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteOrdinaryDictionaryLoop(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,bool):bool]
       mov      dword ptr [rbp-0x1C8], eax
       jmp      G_M000_IG51
 
G_M000_IG15:                ;; offset=0x0267
       mov      rdi, 0x7F236098F5F8
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG14
 
G_M000_IG16:                ;; offset=0x0278
       mov      rax, bword ptr [rbp-0x30]
       mov      eax, dword ptr [rax+0x18]
       mov      dword ptr [rbp-0x5C], eax
       mov      rdi, bword ptr [rbp-0x48]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_DictionaryLoopCallIndex():int:this]
       mov      dword ptr [rbp-0x60], eax
       mov      rax, bword ptr [rbp-0x30]
       mov      rdi, gword ptr [rax]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_CallSites():System.Collections.Generic.IReadOnlyList`1[Lokad.Lython.Frontend.ExecutableCallSite]:this]
       mov      gword ptr [rbp-0x140], rax
       mov      rax, gword ptr [rbp-0x140]
       mov      gword ptr [rbp-0x1C0], rax
       mov      rdi, gword ptr [rbp-0x1C0]
       mov      rsi, 0x7F236098F600
       call     CORINFO_HELP_CLASSPROFILE32
       mov      rax, gword ptr [rbp-0x1C0]
       mov      gword ptr [rbp-0x1E0], rax
       mov      rax, bword ptr [rbp-0x30]
       mov      rdi, gword ptr [rax]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Instructions():Lokad.Lython.Frontend.ExecutableInstruction[]:this]
       mov      ecx, dword ptr [rbp-0x60]
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG53
       mov      edx, ecx
       imul     rdx, rdx, 32
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      rdi, rax
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_CallSiteIndex():int:this]
       mov      dword ptr [rbp-0x1E4], eax
       mov      rdi, gword ptr [rbp-0x1E0]
       mov      esi, dword ptr [rbp-0x1E4]
       mov      r11, 0x7F235E7320C8
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       mov      gword ptr [rbp-0x68], rax
       mov      rax, bword ptr [rbp-0x30]
       mov      rdi, gword ptr [rax]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Instructions():Lokad.Lython.Frontend.ExecutableInstruction[]:this]
       mov      ecx, dword ptr [rbp-0x5C]
       add      ecx, 2
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG53
       mov      edx, ecx
       imul     rdx, rdx, 32
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      bword ptr [rbp-0x70], rax
       mov      rax, bword ptr [rbp-0x30]
       mov      rdi, gword ptr [rax]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Instructions():Lokad.Lython.Frontend.ExecutableInstruction[]:this]
       mov      ecx, dword ptr [rbp-0x60]
       inc      ecx
       cmp      ecx, dword ptr [rax+0x08]
 
G_M000_IG17:                ;; offset=0x036E
       jae      G_M000_IG53
       mov      edx, ecx
       imul     rdx, rdx, 32
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      bword ptr [rbp-0x78], rax
       mov      rax, bword ptr [rbp-0x30]
       mov      rdi, gword ptr [rax]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Instructions():Lokad.Lython.Frontend.ExecutableInstruction[]:this]
       mov      ecx, dword ptr [rbp-0x60]
       add      ecx, 2
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG53
       mov      edx, ecx
       imul     rdx, rdx, 32
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      bword ptr [rbp-0x80], rax
       mov      rax, bword ptr [rbp-0x30]
       mov      rdi, gword ptr [rax]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Constants():System.Object[]:this]
       mov      gword ptr [rbp-0x148], rax
       mov      rax, bword ptr [rbp-0x30]
       mov      rdi, gword ptr [rax]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Instructions():Lokad.Lython.Frontend.ExecutableInstruction[]:this]
       mov      ecx, dword ptr [rbp-0x5C]
       add      ecx, 4
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG53
       mov      edx, ecx
       imul     rdx, rdx, 32
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      rdi, rax
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ConstantIndex():int:this]
       mov      rcx, gword ptr [rbp-0x148]
       cmp      eax, dword ptr [rcx+0x08]
       jae      G_M000_IG53
       mov      edx, eax
       lea      rcx, bword ptr [rcx+8*rdx+0x10]
       mov      rax, gword ptr [rcx]
       mov      gword ptr [rbp-0x88], rax
       mov      rax, bword ptr [rbp-0x30]
       mov      rdi, gword ptr [rax]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Constants():System.Object[]:this]
       mov      gword ptr [rbp-0x150], rax
       mov      rdi, bword ptr [rbp-0x78]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_SecondInput():int:this]
       not      eax
       mov      rcx, gword ptr [rbp-0x150]
       cmp      eax, dword ptr [rcx+0x08]
       jae      G_M000_IG53
       mov      edx, eax
 
G_M000_IG18:                ;; offset=0x044D
       lea      rcx, bword ptr [rcx+8*rdx+0x10]
       mov      rax, gword ptr [rcx]
       mov      gword ptr [rbp-0x1F0], rax
       mov      rsi, gword ptr [rbp-0x1F0]
       mov      rdi, 0x7F2360360018
       call     [CORINFO_HELP_UNBOX]
 
G_M000_IG19:                ;; offset=0x0473
       vmovdqu  xmm0, xmmword ptr [rax]
       vmovdqu  xmmword ptr [rbp-0x98], xmm0
 
G_M000_IG20:                ;; offset=0x047F
       mov      rax, bword ptr [rbp-0x30]
       mov      rax, gword ptr [rax+0x08]
       mov      gword ptr [rbp-0x158], rax
       mov      rax, gword ptr [rbp-0x158]
       mov      gword ptr [rbp-0x260], rax
       mov      rdi, bword ptr [rbp-0x80]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_SecondInput():int:this]
       mov      rdx, gword ptr [rbp-0x260]
       cmp      eax, dword ptr [rdx+0x08]
       jae      G_M000_IG53
       mov      ecx, eax
       imul     rcx, rcx, 16
       lea      rcx, bword ptr [rdx+rcx+0x10]
       mov      rdi, rcx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Object():System.Object:this]
       mov      gword ptr [rbp-0x1F8], rax
       mov      rsi, gword ptr [rbp-0x1F8]
       mov      rdi, 0x7F2360640018
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      gword ptr [rbp-0xA0], rax
       cmp      gword ptr [rbp-0xA0], 0
       je       SHORT G_M000_IG22
       mov      rdi, gword ptr [rbp-0xA0]
       mov      rsi, gword ptr [rbp-0x38]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.PyDict:CanAccumulateBorrowedWords(Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG23
 
G_M000_IG21:                ;; offset=0x0510
       mov      rdi, 0x7F236098F708
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG22:                ;; offset=0x051F
       mov      rdi, 0x7F236098F70C
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG24
 
G_M000_IG23:                ;; offset=0x0533
       mov      eax, dword ptr [rbp-0x60]
       add      eax, 3
       mov      dword ptr [rbp-0xA4], eax
       mov      rax, bword ptr [rbp-0x30]
       mov      rdi, gword ptr [rax]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Instructions():Lokad.Lython.Frontend.ExecutableInstruction[]:this]
       mov      ecx, dword ptr [rbp-0xA4]
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG53
       mov      edx, ecx
       imul     rdx, rdx, 32
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      bword ptr [rbp-0xB0], rax
       mov      rdi, bword ptr [rbp-0xB0]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_OpCode():int:this]
       cmp      eax, 47
       sete     al
       movzx    rax, al
       mov      dword ptr [rbp-0xB4], eax
       xor      eax, eax
       mov      qword ptr [rbp-0xC0], rax
       xor      eax, eax
       mov      qword ptr [rbp-0xC8], rax
       cmp      dword ptr [rbp-0xB4], 0
       je       G_M000_IG29
       mov      rax, bword ptr [rbp-0x30]
       mov      rax, gword ptr [rax+0x08]
       mov      gword ptr [rbp-0x1A0], rax
       mov      rdi, bword ptr [rbp-0xB0]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      rcx, gword ptr [rbp-0x1A0]
       cmp      eax, dword ptr [rcx+0x08]
       jae      G_M000_IG53
       mov      edx, eax
       imul     rdx, rdx, 16
       lea      rcx, bword ptr [rcx+rdx+0x10]
       mov      bword ptr [rbp-0x200], rcx
       mov      rdi, bword ptr [rbp-0x200]
       lea      rsi, [rbp-0xC0]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryReadHistogramTotal(byref,byref):bool]
       test     eax, eax
       jne      SHORT G_M000_IG26
       mov      rdi, 0x7F236098F710
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG24:                ;; offset=0x060F
       xor      eax, eax
 
G_M000_IG25:                ;; offset=0x0611
       add      rsp, 640
       pop      rbp
       ret      
 
G_M000_IG26:                ;; offset=0x061A
       mov      rdi, 0x7F236098F714
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp-0x30]
       mov      rdi, gword ptr [rax]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Constants():System.Object[]:this]
       mov      gword ptr [rbp-0x1A8], rax
       mov      rdi, bword ptr [rbp-0xB0]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_SecondInput():int:this]
       not      eax
       mov      rcx, gword ptr [rbp-0x1A8]
       cmp      eax, dword ptr [rcx+0x08]
       jae      G_M000_IG53
       mov      edx, eax
       lea      rcx, bword ptr [rcx+8*rdx+0x10]
       mov      rax, gword ptr [rcx]
       mov      gword ptr [rbp-0x208], rax
       mov      rsi, gword ptr [rbp-0x208]
       mov      rdi, 0x7F2360360018
       call     [CORINFO_HELP_UNBOX]
 
G_M000_IG27:                ;; offset=0x0686
       vmovdqu  xmm0, xmmword ptr [rax]
       vmovdqu  xmmword ptr [rbp-0x218], xmm0
 
G_M000_IG28:                ;; offset=0x0692
       mov      rdi, gword ptr [rbp-0x218]
       mov      rsi, qword ptr [rbp-0x210]
       call     [System.Numerics.BigInteger:op_Explicit(System.Numerics.BigInteger):long]
       mov      qword ptr [rbp-0xC8], rax
 
G_M000_IG29:                ;; offset=0x06AD
       vxorps   xmm0, xmm0, xmm0
       vmovdqu  xmmword ptr [rbp-0xD8], xmm0
       xor      rax, rax
       mov      gword ptr [rbp-0xE0], rax
       xor      eax, eax
       mov      dword ptr [rbp-0xE4], eax
       xor      eax, eax
       mov      dword ptr [rbp-0xE8], eax
       xor      eax, eax
       mov      dword ptr [rbp-0xEC], eax
 
G_M000_IG30:                ;; offset=0x06DA
       mov      eax, dword ptr [rbp-0x1C4]
       dec      eax
       mov      dword ptr [rbp-0x1C4], eax
       cmp      dword ptr [rbp-0x1C4], 0
       jg       SHORT G_M000_IG32
 
G_M000_IG31:                ;; offset=0x06F1
       lea      rdi, [rbp-0x1C4]
       mov      esi, 496
       call     CORINFO_HELP_PATCHPOINT
       jmp      rax
 
G_M000_IG32:                ;; offset=0x0704
       lea      rsi, [rbp-0x100]
       lea      rdx, [rbp-0x108]
       mov      rdi, gword ptr [rbp-0x58]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.Text.PyStringOps+CasedWhitespaceIteration:TryReadWord(byref,byref):bool:this]
       test     eax, eax
       je       G_M000_IG46
 
G_M000_IG33:                ;; offset=0x0726
       vmovdqu  xmm0, xmmword ptr [rbp-0x100]
       vmovdqu  xmmword ptr [rbp-0xD8], xmm0
 
G_M000_IG34:                ;; offset=0x0736
       mov      rax, gword ptr [rbp-0x108]
       mov      gword ptr [rbp-0xE0], rax
       cmp      dword ptr [rbp-0xE8], 0
       jne      SHORT G_M000_IG35
       mov      rdi, bword ptr [rbp-0x70]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x220], rax
       mov      rsi, gword ptr [rbp-0x220]
       mov      rdi, gword ptr [rbp-0x38]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CheckExecution(Lokad.Lython.LythonSourceSpan):this]
       mov      rax, bword ptr [rbp-0x30]
       mov      ecx, dword ptr [rbp-0x60]
       mov      dword ptr [rax+0x18], ecx
       mov      rdi, gword ptr [rbp-0x68]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_CallSpan():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x228], rax
       mov      rsi, gword ptr [rbp-0x228]
       mov      rdi, gword ptr [rbp-0x38]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:EnterInterpreterFrame(Lokad.Lython.LythonSourceSpan):this]
       mov      dword ptr [rbp-0xE8], 1
       jmp      SHORT G_M000_IG36
 
G_M000_IG35:                ;; offset=0x07AD
       mov      rdi, 0x7F236098F718
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp-0x30]
       mov      ecx, dword ptr [rbp-0x60]
       mov      dword ptr [rax+0x18], ecx
 
G_M000_IG36:                ;; offset=0x07C6
       cmp      gword ptr [rbp-0x108], 0
       jne      G_M000_IG39
 
G_M000_IG37:                ;; offset=0x07D4
       vmovdqu  xmm0, xmmword ptr [rbp-0x100]
       vmovdqu  xmmword ptr [rbp-0x170], xmm0
 
G_M000_IG38:                ;; offset=0x07E4
       mov      rdi, gword ptr [rbp-0x68]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_CallSpan():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x230], rax
       lea      rax, [rbp-0x118]
       mov      qword ptr [rsp+0x10], rax
       mov      rax, gword ptr [rbp-0x230]
       mov      gword ptr [rsp+0x08], rax
       mov      r8, gword ptr [rbp-0x98]
       mov      r9, qword ptr [rbp-0x90]
       mov      rsi, bword ptr [rbp-0x170]
       mov      rdx, qword ptr [rbp-0x168]
       mov      rcx, gword ptr [rbp-0x88]
       mov      rax, gword ptr [rbp-0x38]
       mov      gword ptr [rsp], rax
       mov      rdi, gword ptr [rbp-0xA0]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.PyDict:TryAccumulateBorrowedWord(System.ReadOnlySpan`1[byte],System.Object,System.Numerics.BigInteger,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,byref):bool:this]
       mov      dword ptr [rbp-0x10C], eax
       lea      rdi, [rbp-0x118]
       call     [System.Nullable`1[uint]:get_HasValue():bool:this]
       test     eax, eax
       je       G_M000_IG40
       mov      rdi, 0x7F236098F71C
       call     CORINFO_HELP_COUNTPROFILE32
       lea      rdi, [rbp-0x118]
       call     [System.Nullable`1[uint]:GetValueOrDefault():uint:this]
       mov      dword ptr [rbp-0x11C], eax
       mov      rdi, gword ptr [rbp-0x68]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_CallSpan():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x238], rax
       mov      rsi, gword ptr [rbp-0x238]
       mov      rdi, gword ptr [rbp-0x38]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CheckExecution(Lokad.Lython.LythonSourceSpan):this]
       mov      rsi, bword ptr [rbp-0x100]
       mov      rdx, qword ptr [rbp-0xF8]
       mov      rdi, gword ptr [rbp-0x58]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.Text.PyStringOps+CasedWhitespaceIteration:Materialize(System.ReadOnlySpan`1[byte]):Lokad.Lython.Runtime.Text.PyString:this]
       mov      gword ptr [rbp-0xE0], rax
       mov      r8, gword ptr [rbp-0x98]
       mov      r9, qword ptr [rbp-0x90]
       mov      rdi, gword ptr [rbp-0xA0]
       mov      rsi, gword ptr [rbp-0xE0]
       mov      edx, dword ptr [rbp-0x11C]
       mov      rcx, gword ptr [rbp-0x88]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.PyDict:TryAppendBorrowedWord(Lokad.Lython.Runtime.Text.PyString,uint,System.Object,System.Numerics.BigInteger):bool:this]
       mov      dword ptr [rbp-0x10C], eax
       jmp      SHORT G_M000_IG40
 
G_M000_IG39:                ;; offset=0x0906
       mov      rdi, 0x7F236098F720
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, gword ptr [rbp-0x108]
       mov      gword ptr [rbp-0x160], rax
       mov      rdi, gword ptr [rbp-0x68]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_CallSpan():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x240], rax
       mov      rax, gword ptr [rbp-0x240]
       mov      gword ptr [rsp], rax
       mov      rcx, gword ptr [rbp-0x98]
       mov      r8, qword ptr [rbp-0x90]
       mov      rsi, gword ptr [rbp-0x160]
       mov      rdx, gword ptr [rbp-0x88]
       mov      r9, gword ptr [rbp-0x38]
       mov      rdi, gword ptr [rbp-0xA0]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.PyDict:TryAccumulateWithoutAdmission(Lokad.Lython.Runtime.Text.PyString,System.Object,System.Numerics.BigInteger,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):bool:this]
       mov      dword ptr [rbp-0x10C], eax
 
G_M000_IG40:                ;; offset=0x0976
       cmp      dword ptr [rbp-0x10C], 0
       jne      SHORT G_M000_IG41
       mov      eax, dword ptr [rbp-0x5C]
       add      eax, 2
       mov      rcx, bword ptr [rbp-0x30]
       mov      dword ptr [rcx+0x18], eax
       mov      dword ptr [rbp-0x120], 1
       jmp      G_M000_IG48
 
G_M000_IG41:                ;; offset=0x099B
       cmp      dword ptr [rbp-0xB4], 0
       je       G_M000_IG45
       mov      rax, qword ptr [rbp-0xC0]
       add      rax, qword ptr [rbp-0xC8]
       mov      qword ptr [rbp-0xC0], rax
       mov      dword ptr [rbp-0xE4], 1
       mov      rax, 0xFF80000000000000
       cmp      qword ptr [rbp-0xC0], rax
       jl       SHORT G_M000_IG43
       mov      rax, 0x80000000000000
       cmp      qword ptr [rbp-0xC0], rax
       jl       SHORT G_M000_IG44
 
G_M000_IG42:                ;; offset=0x09ED
       mov      rdi, 0x7F236098F724
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG43:                ;; offset=0x09FC
       mov      rdi, 0x7F236098F728
       call     CORINFO_HELP_COUNTPROFILE32
       mov      eax, dword ptr [rbp-0xA4]
       add      eax, 2
       mov      rcx, bword ptr [rbp-0x30]
       mov      dword ptr [rcx+0x18], eax
       mov      dword ptr [rbp-0x120], 1
       jmp      G_M000_IG49
 
G_M000_IG44:                ;; offset=0x0A2A
       mov      rdi, 0x7F236098F72C
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG45:                ;; offset=0x0A39
       mov      rdi, 0x7F236098F730
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp-0x30]
       mov      ecx, dword ptr [rbp-0x5C]
       mov      dword ptr [rax+0x18], ecx
       mov      rdi, bword ptr [rbp-0x48]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x248], rax
       mov      rsi, gword ptr [rbp-0x248]
       mov      rdi, gword ptr [rbp-0x38]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CheckExecution(Lokad.Lython.LythonSourceSpan):this]
       jmp      G_M000_IG30
 
G_M000_IG46:                ;; offset=0x0A7B
       mov      rdi, 0x7F236098F734
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0xEC], 1
       mov      rdi, bword ptr [rbp-0x48]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_TargetIndex():int:this]
       mov      rcx, bword ptr [rbp-0x30]
       mov      dword ptr [rcx+0x18], eax
       mov      dword ptr [rbp-0x120], 1
 
G_M000_IG47:                ;; offset=0x0AAF
       call     G_M000_IG71
       jmp      SHORT G_M000_IG50
 
G_M000_IG48:                ;; offset=0x0AB6
       call     G_M000_IG71
       jmp      SHORT G_M000_IG50
 
G_M000_IG49:                ;; offset=0x0ABD
       call     G_M000_IG71
       nop      
 
G_M000_IG50:                ;; offset=0x0AC3
       mov      rdi, 0x7F236098F75C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      eax, dword ptr [rbp-0x120]
       mov      dword ptr [rbp-0x1C8], eax
 
G_M000_IG51:                ;; offset=0x0ADE
       movzx    rax, byte  ptr [rbp-0x1C8]
 
G_M000_IG52:                ;; offset=0x0AE5
       add      rsp, 640
       pop      rbp
       ret      
 
G_M000_IG53:                ;; offset=0x0AEE
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG54:                ;; offset=0x0AF4
       sub      rsp, 24
 
G_M000_IG55:                ;; offset=0x0AF8
       cmp      dword ptr [rbp-0xE4], 0
       je       SHORT G_M000_IG56
       mov      rdi, 0x7F236098F748
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp-0x30]
       mov      rax, gword ptr [rax+0x08]
       mov      gword ptr [rbp-0x198], rax
       mov      rdi, bword ptr [rbp-0xB0]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      rcx, gword ptr [rbp-0x198]
       cmp      eax, dword ptr [rcx+0x08]
       jae      G_M000_IG59
       mov      edx, eax
       imul     rdx, rdx, 16
       lea      rcx, bword ptr [rcx+rdx+0x10]
       mov      bword ptr [rbp-0x250], rcx
       mov      rdi, bword ptr [rbp-0x250]
       mov      rsi, qword ptr [rbp-0xC0]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:SetInteger(long):this]
 
G_M000_IG56:                ;; offset=0x0B62
       cmp      dword ptr [rbp-0xEC], 0
       je       SHORT G_M000_IG57
       mov      rdi, 0x7F236098F74C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp-0x30]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp-0x30]
       add      rax, 32
       mov      bword ptr [rbp-0x190], rax
       mov      rdi, bword ptr [rbp-0x48]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x254], eax
       mov      esi, dword ptr [rbp-0x254]
       mov      rdi, bword ptr [rbp-0x190]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
 
G_M000_IG57:                ;; offset=0x0BB2
       mov      rdi, 0x7F236098F750
       call     CORINFO_HELP_COUNTPROFILE32
       nop      
 
G_M000_IG58:                ;; offset=0x0BC2
       add      rsp, 24
       ret      
 
G_M000_IG59:                ;; offset=0x0BC7
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG60:                ;; offset=0x0BCD
       sub      rsp, 24
 
G_M000_IG61:                ;; offset=0x0BD1
       cmp      gword ptr [rbp-0xE0], 0
       jne      SHORT G_M000_IG65
       lea      rdi, [rbp-0xD8]
       call     [System.ReadOnlySpan`1[byte]:get_IsEmpty():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG62
       jmp      SHORT G_M000_IG64
 
G_M000_IG62:                ;; offset=0x0BEE
       mov      rdi, 0x7F236098F73C
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG67
 
G_M000_IG63:                ;; offset=0x0C02
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG64:                ;; offset=0x0C08
       mov      rdi, 0x7F236098F740
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG65:                ;; offset=0x0C17
       mov      rax, bword ptr [rbp-0x30]
       mov      rax, gword ptr [rax+0x08]
       mov      gword ptr [rbp-0x178], rax
       mov      rdi, bword ptr [rbp-0x80]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ThirdInput():int:this]
       mov      rcx, gword ptr [rbp-0x178]
       cmp      eax, dword ptr [rcx+0x08]
       jae      SHORT G_M000_IG63
       mov      edx, eax
       imul     rdx, rdx, 16
       lea      rcx, bword ptr [rcx+rdx+0x10]
       mov      bword ptr [rbp-0x180], rcx
       mov      rax, gword ptr [rbp-0xE0]
       mov      gword ptr [rbp-0x188], rax
       cmp      gword ptr [rbp-0xE0], 0
       jne      SHORT G_M000_IG66
       mov      rdi, 0x7F236098F744
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rsi, bword ptr [rbp-0xD8]
       mov      rdx, qword ptr [rbp-0xD0]
       mov      rdi, gword ptr [rbp-0x58]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.Text.PyStringOps+CasedWhitespaceIteration:Materialize(System.ReadOnlySpan`1[byte]):Lokad.Lython.Runtime.Text.PyString:this]
       mov      gword ptr [rbp-0x188], rax
 
G_M000_IG66:                ;; offset=0x0C96
       mov      rdi, bword ptr [rbp-0x180]
       mov      rsi, gword ptr [rbp-0x188]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:set_Object(System.Object):this]
 
G_M000_IG67:                ;; offset=0x0CAA
       nop      
 
G_M000_IG68:                ;; offset=0x0CAB
       call     G_M000_IG54
       nop      
 
G_M000_IG69:                ;; offset=0x0CB1
       mov      rdi, 0x7F236098F754
       call     CORINFO_HELP_COUNTPROFILE32
       nop      
 
G_M000_IG70:                ;; offset=0x0CC1
       add      rsp, 24
       ret      
 
G_M000_IG71:                ;; offset=0x0CC6
       sub      rsp, 24
 
G_M000_IG72:                ;; offset=0x0CCA
       cmp      dword ptr [rbp-0xE8], 0
       je       SHORT G_M000_IG73
       mov      rdi, 0x7F236098F738
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, gword ptr [rbp-0x38]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:LeaveInterpreterFrame():this]
 
G_M000_IG73:                ;; offset=0x0CEE
       nop      
 
G_M000_IG74:                ;; offset=0x0CEF
       call     G_M000_IG60
       nop      
 
G_M000_IG75:                ;; offset=0x0CF5
       mov      rdi, 0x7F236098F758
       call     CORINFO_HELP_COUNTPROFILE32
       nop      
 
G_M000_IG76:                ;; offset=0x0D05
       add      rsp, 24
       ret      
 
; Total bytes of code 3338

; Assembly listing for method Lokad.Lython.Runtime.PyDict:TryAppendBorrowedWord(Lokad.Lython.Runtime.Text.PyString,uint,System.Object,System.Numerics.BigInteger):bool:this (Tier0)
; Emitting BLENDED_CODE for x64 + VEX on Unix
; Tier0 code
; rbp based frame
; partially interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 64
       lea      rbp, [rsp+0x40]
       mov      gword ptr [rbp-0x08], rdi
       mov      gword ptr [rbp-0x10], rsi
       mov      dword ptr [rbp-0x14], edx
       mov      gword ptr [rbp-0x20], rcx
       mov      gword ptr [rbp-0x30], r8
       mov      qword ptr [rbp-0x28], r9
 
G_M000_IG02:                ;; offset=0x0021
       lea      rdi, [rsp]
       lea      rsi, [rbp-0x30]
       mov      rcx, gword ptr [rsi]
       mov      gword ptr [rsp], rcx
       add      rsi, 8
       add      rdi, 8
       movsq    
       mov      rdi, gword ptr [rbp-0x08]
       mov      rdx, gword ptr [rbp-0x10]
       mov      ecx, dword ptr [rbp-0x14]
       mov      r8, gword ptr [rbp-0x20]
       mov      esi, -1
       call     [Lokad.Lython.Runtime.PyDict:TryAccumulateAt(int,Lokad.Lython.Runtime.Text.PyString,uint,System.Object,System.Numerics.BigInteger):bool:this]
       nop      
 
G_M000_IG03:                ;; offset=0x0055
       add      rsp, 64
       pop      rbp
       ret      
 
; Total bytes of code 91

; Assembly listing for method Lokad.Lython.Runtime.PyDict:TryAccumulateBorrowedWord(System.ReadOnlySpan`1[byte],System.Object,System.Numerics.BigInteger,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,byref):bool:this (Tier1)
; Emitting BLENDED_CODE for x64 + VEX on Unix
; Tier1 code
; optimized code
; optimized using Synthesized PGO
; rbp based frame
; fully interruptible
; with Synthesized PGO: fgCalledCount is 847540
; 53 inlinees with PGO data; 104 single block inlinees; 1 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       push     r15
       push     r14
       push     r13
       push     r12
       push     rbx
       sub      rsp, 216
       lea      rbp, [rsp+0x100]
       xor      eax, eax
       mov      qword ptr [rbp-0xA8], rax
       vxorps   xmm8, xmm8, xmm8
       vmovdqu  ymmword ptr [rbp-0xA0], ymm8
       vmovdqu  ymmword ptr [rbp-0x80], ymm8
       vmovdqu  ymmword ptr [rbp-0x60], ymm8
       mov      dword ptr [rbp-0xAC], r9d
       mov      rbx, rdi
       mov      r13, rsi
       mov      r15d, edx
       mov      r12, r8
       mov      r14, gword ptr [rbp+0x10]
 
G_M000_IG02:                ;; offset=0x0050
       mov      rdi, gword ptr [r14+0x98]
       mov      rsi, gword ptr [rdi+0x88]
       cmp      gword ptr [rsi+0x20], 0
       jne      G_M000_IG102
       mov      rsi, gword ptr [rdi+0x180]
       test     rsi, rsi
       jne      G_M000_IG101
 
G_M000_IG03:                ;; offset=0x0079
       mov      rdx, gword ptr [rbx+0x28]
       mov      gword ptr [rbp-0xC0], rdx
       mov      r8d, dword ptr [rbx+0x4C]
       mov      dword ptr [rbp-0x30], r8d
       mov      edi, r15d
       cmp      r8d, 4
       jle      G_M000_IG50
 
G_M000_IG04:                ;; offset=0x0099
       vxorps   ymm0, ymm0, ymm0
       vmovdqu  ymmword ptr [rbp-0x60], ymm0
       xor      r9d, r9d
       mov      dword ptr [rbp-0x64], r9d
       cmp      r9d, r15d
       jge      G_M000_IG34
 
G_M000_IG05:                ;; offset=0x00B2
       mov      rdi, gword ptr [r14+0x98]
       mov      rsi, gword ptr [rdi+0x88]
       cmp      gword ptr [rsi+0x20], 0
       jne      G_M000_IG123
       mov      rsi, gword ptr [rdi+0x180]
       test     rsi, rsi
       jne      G_M000_IG122
 
G_M000_IG06:                ;; offset=0x00DB
       mov      r9d, dword ptr [rbp-0x64]
       mov      r10d, r15d
       sub      r10d, r9d
       cmp      r10d, 0x1000
       jge      G_M000_IG87
 
G_M000_IG07:                ;; offset=0x00F2
       mov      dword ptr [rbp-0x68], r10d
       mov      esi, r9d
       mov      edi, r10d
       add      rsi, rdi
       mov      edi, r15d
       cmp      rsi, rdi
       ja       G_M000_IG121
       mov      dword ptr [rbp-0x64], r9d
       mov      r11d, r9d
       add      r11, r13
       mov      bword ptr [rbp-0xC8], r11
       mov      rdi, r11
       mov      esi, r10d
       cmp      r10d, 16
       jl       G_M000_IG21
 
G_M000_IG08:                ;; offset=0x012C
       cmp      dword ptr [rbp-0x44], 0
       jne      G_M000_IG124
       mov      r11, 0xA13CEA793F74642A
       mov      qword ptr [rbp-0x60], r11
       mov      r11, 0x7D19A6511B512002
       mov      qword ptr [rbp-0x58], r11
 
G_M000_IG09:                ;; offset=0x0152
       cmp      esi, 16
       jl       G_M000_IG21
 
G_M000_IG10:                ;; offset=0x015B
       mov      r11d, dword ptr [rbp-0x60]
       imul     ecx, dword ptr [rdi], 0xFFFFFFFF85EBCA77
       add      ecx, r11d
       rol      ecx, 13
       imul     ecx, ecx, 0xFFFFFFFF9E3779B1
       mov      dword ptr [rbp-0x60], ecx
       mov      ecx, dword ptr [rbp-0x5C]
       lea      r11, bword ptr [rdi+0x04]
       imul     r11d, dword ptr [r11], 0xFFFFFFFF85EBCA77
       add      ecx, r11d
       rol      ecx, 13
       imul     ecx, ecx, 0xFFFFFFFF9E3779B1
       mov      dword ptr [rbp-0x5C], ecx
       mov      ecx, dword ptr [rbp-0x58]
       lea      r11, bword ptr [rdi+0x08]
       imul     r11d, dword ptr [r11], 0xFFFFFFFF85EBCA77
       add      ecx, r11d
       rol      ecx, 13
       imul     ecx, ecx, 0xFFFFFFFF9E3779B1
       mov      dword ptr [rbp-0x58], ecx
       mov      ecx, dword ptr [rbp-0x54]
       lea      r11, bword ptr [rdi+0x0C]
       imul     r11d, dword ptr [r11], 0xFFFFFFFF85EBCA77
       add      ecx, r11d
       rol      ecx, 13
       imul     ecx, ecx, 0xFFFFFFFF9E3779B1
       mov      dword ptr [rbp-0x54], ecx
       mov      ecx, dword ptr [rbp-0x44]
       add      ecx, 4
       mov      dword ptr [rbp-0x44], ecx
       add      rdi, 16
       add      esi, -16
       jmp      G_M000_IG09
 
G_M000_IG11:                ;; offset=0x01E0
       mov      r11d, dword ptr [rdi]
       mov      ecx, dword ptr [rbp-0x44]
       lea      eax, [rcx+0x01]
       mov      dword ptr [rbp-0x44], eax
       mov      eax, ecx
       and      eax, 3
       je       G_M000_IG19
 
G_M000_IG12:                ;; offset=0x01F7
       cmp      eax, 1
       jne      SHORT G_M000_IG14
 
G_M000_IG13:                ;; offset=0x01FC
       mov      dword ptr [rbp-0x4C], r11d
       jmp      G_M000_IG20
 
G_M000_IG14:                ;; offset=0x0205
       cmp      eax, 2
       jne      SHORT G_M000_IG16
 
G_M000_IG15:                ;; offset=0x020A
       mov      dword ptr [rbp-0x48], r11d
       jmp      G_M000_IG20
 
G_M000_IG16:                ;; offset=0x0213
       cmp      ecx, 3
       jne      SHORT G_M000_IG18
 
G_M000_IG17:                ;; offset=0x0218
       mov      rax, 0xA13CEA793F74642A
       mov      qword ptr [rbp-0x60], rax
       mov      rax, 0x7D19A6511B512002
       mov      qword ptr [rbp-0x58], rax
 
G_M000_IG18:                ;; offset=0x0234
       imul     eax, dword ptr [rbp-0x50], 0xFFFFFFFF85EBCA77
       add      eax, dword ptr [rbp-0x60]
       rol      eax, 13
       imul     eax, eax, 0xFFFFFFFF9E3779B1
       mov      dword ptr [rbp-0x60], eax
       imul     eax, dword ptr [rbp-0x4C], 0xFFFFFFFF85EBCA77
       add      eax, dword ptr [rbp-0x5C]
       rol      eax, 13
       imul     eax, eax, 0xFFFFFFFF9E3779B1
       mov      dword ptr [rbp-0x5C], eax
       imul     eax, dword ptr [rbp-0x48], 0xFFFFFFFF85EBCA77
       add      eax, dword ptr [rbp-0x58]
       rol      eax, 13
       imul     eax, eax, 0xFFFFFFFF9E3779B1
       mov      dword ptr [rbp-0x58], eax
       imul     r11d, r11d, 0xFFFFFFFF85EBCA77
       add      r11d, dword ptr [rbp-0x54]
       rol      r11d, 13
       imul     eax, r11d, 0xFFFFFFFF9E3779B1
       mov      dword ptr [rbp-0x54], eax
       jmp      SHORT G_M000_IG20
 
G_M000_IG19:                ;; offset=0x0291
       mov      dword ptr [rbp-0x50], r11d
 
G_M000_IG20:                ;; offset=0x0295
       add      rdi, 4
       add      esi, -4
       mov      rax, rdi
       mov      edi, esi
       mov      esi, edi
       mov      rdi, rax
 
G_M000_IG21:                ;; offset=0x02A6
       cmp      esi, 4
       jge      G_M000_IG11
 
G_M000_IG22:                ;; offset=0x02AF
       xor      r11d, r11d
       test     esi, esi
       je       G_M000_IG33
 
G_M000_IG23:                ;; offset=0x02BA
       movzx    rcx, byte  ptr [rdi+r11]
       mov      dword ptr [rbp-0x6C], ecx
       mov      eax, dword ptr [rbp-0x44]
       lea      ecx, [rax+0x01]
       mov      dword ptr [rbp-0x44], ecx
       mov      ecx, eax
       and      ecx, 3
       je       G_M000_IG31
 
G_M000_IG24:                ;; offset=0x02D6
       cmp      ecx, 1
       jne      SHORT G_M000_IG26
 
G_M000_IG25:                ;; offset=0x02DB
       mov      ecx, dword ptr [rbp-0x6C]
       mov      dword ptr [rbp-0x4C], ecx
       jmp      G_M000_IG32
 
G_M000_IG26:                ;; offset=0x02E6
       cmp      ecx, 2
       jne      SHORT G_M000_IG28
 
G_M000_IG27:                ;; offset=0x02EB
       mov      ecx, dword ptr [rbp-0x6C]
       mov      dword ptr [rbp-0x48], ecx
       jmp      G_M000_IG32
 
G_M000_IG28:                ;; offset=0x02F6
       cmp      eax, 3
       jne      SHORT G_M000_IG30
 
G_M000_IG29:                ;; offset=0x02FB
       mov      rax, 0xA13CEA793F74642A
       mov      qword ptr [rbp-0x60], rax
       mov      rax, 0x7D19A6511B512002
       mov      qword ptr [rbp-0x58], rax
 
G_M000_IG30:                ;; offset=0x0317
       imul     eax, dword ptr [rbp-0x50], 0xFFFFFFFF85EBCA77
       add      eax, dword ptr [rbp-0x60]
       rol      eax, 13
       imul     eax, eax, 0xFFFFFFFF9E3779B1
       mov      dword ptr [rbp-0x60], eax
       imul     eax, dword ptr [rbp-0x4C], 0xFFFFFFFF85EBCA77
       add      eax, dword ptr [rbp-0x5C]
       rol      eax, 13
       imul     eax, eax, 0xFFFFFFFF9E3779B1
       mov      dword ptr [rbp-0x5C], eax
       imul     eax, dword ptr [rbp-0x48], 0xFFFFFFFF85EBCA77
       add      eax, dword ptr [rbp-0x58]
       rol      eax, 13
       imul     eax, eax, 0xFFFFFFFF9E3779B1
       mov      dword ptr [rbp-0x58], eax
       imul     ecx, dword ptr [rbp-0x6C], 0xFFFFFFFF85EBCA77
       add      ecx, dword ptr [rbp-0x54]
       rol      ecx, 13
       imul     eax, ecx, 0xFFFFFFFF9E3779B1
       mov      dword ptr [rbp-0x54], eax
       jmp      SHORT G_M000_IG32
 
G_M000_IG31:                ;; offset=0x0371
       mov      ecx, dword ptr [rbp-0x6C]
       mov      dword ptr [rbp-0x50], ecx
 
G_M000_IG32:                ;; offset=0x0377
       inc      r11d
       cmp      r11d, esi
       jl       G_M000_IG23
 
G_M000_IG33:                ;; offset=0x0383
       mov      r9d, dword ptr [rbp-0x64]
       add      r9d, dword ptr [rbp-0x68]
       cmp      r9d, r15d
       mov      dword ptr [rbp-0x64], r9d
       jl       G_M000_IG05
 
G_M000_IG34:                ;; offset=0x0398
       mov      edi, dword ptr [rbp-0x44]
       mov      esi, edi
       and      esi, 3
       cmp      edi, 4
       jb       G_M000_IG88
 
G_M000_IG35:                ;; offset=0x03A9
       rorx     r9d, dword ptr [rbp-0x60], 31
       rorx     r10d, dword ptr [rbp-0x5C], 25
       add      r9d, r10d
       rorx     r10d, dword ptr [rbp-0x58], 20
       add      r9d, r10d
       rorx     r10d, dword ptr [rbp-0x54], 14
       add      r9d, r10d
 
G_M000_IG36:                ;; offset=0x03CE
       lea      edi, [r9+4*rdi]
       test     esi, esi
       je       SHORT G_M000_IG40
 
G_M000_IG37:                ;; offset=0x03D6
       imul     r9d, dword ptr [rbp-0x50], 0xFFFFFFFFC2B2AE3D
       add      edi, r9d
       rol      edi, 17
       imul     edi, edi, 0x27D4EB2F
       cmp      esi, 1
       jbe      SHORT G_M000_IG40
 
G_M000_IG38:                ;; offset=0x03EF
       imul     r9d, dword ptr [rbp-0x4C], 0xFFFFFFFFC2B2AE3D
       add      r9d, edi
       rol      r9d, 17
       imul     edi, r9d, 0x27D4EB2F
       cmp      esi, 2
       jbe      SHORT G_M000_IG40
 
G_M000_IG39:                ;; offset=0x040A
       imul     esi, dword ptr [rbp-0x48], 0xFFFFFFFFC2B2AE3D
       add      esi, edi
       rol      esi, 17
       imul     edi, esi, 0x27D4EB2F
 
G_M000_IG40:                ;; offset=0x041C
       mov      esi, edi
       shr      esi, 15
       xor      esi, edi
       imul     edi, esi, 0xFFFFFFFF85EBCA77
       mov      esi, edi
       shr      esi, 13
       xor      esi, edi
       imul     edi, esi, 0xFFFFFFFFC2B2AE3D
       mov      esi, edi
       shr      esi, 16
       xor      edi, esi
       mov      esi, -2
       cmp      edi, -1
       cmovne   esi, edi
       mov      edi, esi
       shr      edi, 16
       xor      edi, esi
       imul     edi, edi, 0xFFFFFFFF9E3779B9
       mov      esi, edi
       shr      esi, 16
       xor      esi, edi
       mov      r9d, esi
       test     r8d, r8d
       je       G_M000_IG130
 
G_M000_IG41:                ;; offset=0x0468
       mov      edi, dword ptr [rdx+0x08]
       mov      r8d, edi
       mov      edi, r8d
       blsr     esi, edi
       jne      G_M000_IG131
       dec      edi
       and      edi, r9d
 
G_M000_IG42:                ;; offset=0x0481
       mov      dword ptr [rbp-0xB8], r8d
       cmp      edi, r8d
       jae      G_M000_IG151
       mov      edi, edi
       lea      rdi, [rdi+4*rdi]
       mov      rdx, gword ptr [rbp-0xC0]
       mov      r10d, dword ptr [rdx+8*rdi+0x30]
       dec      r10d
       mov      dword ptr [rbp-0x34], r10d
       test     r10d, r10d
       jge      G_M000_IG68
 
G_M000_IG43:                ;; offset=0x04B3
       mov      r14d, r9d
       jmp      G_M000_IG100
 
G_M000_IG44:                ;; offset=0x04BB
       inc      dword ptr [rbx+0x48]
       jmp      G_M000_IG85
 
G_M000_IG45:                ;; offset=0x04C3
       cmp      r15d, 8
       jle      SHORT G_M000_IG48
 
G_M000_IG46:                ;; offset=0x04C9
       mov      eax, dword ptr [rbx+0x4C]
       mov      rdx, gword ptr [rbp-0xC0]
       mov      r8d, dword ptr [rdx+0x08]
       mov      ebx, r8d
       cmp      eax, ebx
       jge      SHORT G_M000_IG48
 
G_M000_IG47:                ;; offset=0x04DE
       mov      byte  ptr [rcx], 1
       mov      r14d, dword ptr [rbp-0x2C]
       mov      dword ptr [rcx+0x04], r14d
 
G_M000_IG48:                ;; offset=0x04E9
       xor      eax, eax
 
G_M000_IG49:                ;; offset=0x04EB
       vzeroupper 
       add      rsp, 216
       pop      rbx
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG50:                ;; offset=0x0500
       cmp      edi, 8
       jg       G_M000_IG04
 
G_M000_IG51:                ;; offset=0x0509
       xor      r14d, r14d
       xor      edi, edi
       test     r8d, r8d
       jle      G_M000_IG103
       jmp      SHORT G_M000_IG54
 
G_M000_IG52:                ;; offset=0x0519
       inc      edi
       cmp      edi, r8d
       jge      G_M000_IG100
 
G_M000_IG53:                ;; offset=0x0524
       mov      rdx, gword ptr [rbp-0xC0]
 
G_M000_IG54:                ;; offset=0x052B
       mov      r9d, dword ptr [rdx+0x08]
       cmp      edi, r9d
       jae      G_M000_IG151
       lea      rsi, [rdi+4*rdi]
       mov      rsi, gword ptr [rdx+8*rsi+0x10]
       test     rsi, rsi
       je       SHORT G_M000_IG52
 
G_M000_IG55:                ;; offset=0x0546
       mov      r9, 0x7F23603BFBC0
       cmp      qword ptr [rsi], r9
       jne      SHORT G_M000_IG52
 
G_M000_IG56:                ;; offset=0x0555
       movzx    r9, byte  ptr [rsi+0x24]
       test     r9d, r9d
       je       G_M000_IG104
 
G_M000_IG57:                ;; offset=0x0563
       cmp      r9d, 255
       je       G_M000_IG89
 
G_M000_IG58:                ;; offset=0x0570
       lea      r9, bword ptr [rsi+0x28]
       mov      r10d, dword ptr [rsi+0x18]
       cmp      r10d, 8
       ja       G_M000_IG121
 
G_M000_IG59:                ;; offset=0x0582
       cmp      r15d, r10d
       jne      SHORT G_M000_IG52
 
G_M000_IG60:                ;; offset=0x0587
       mov      rsi, r13
       mov      r11, r9
       mov      r10d, r10d
       cmp      r10, 8
       jae      G_M000_IG94
 
G_M000_IG61:                ;; offset=0x059A
       cmp      r10, 4
       jb       G_M000_IG91
 
G_M000_IG62:                ;; offset=0x05A4
       add      r10, -4
       mov      esi, dword ptr [r13]
       sub      esi, dword ptr [r9]
       mov      r11d, dword ptr [r10+r13]
       sub      r11d, dword ptr [r9+r10]
       or       esi, r11d
       sete     sil
       movzx    rsi, sil
 
G_M000_IG63:                ;; offset=0x05C2
       test     esi, esi
       je       G_M000_IG52
 
G_M000_IG64:                ;; offset=0x05CA
       mov      r13d, edi
       mov      dword ptr [rbp-0x2C], r14d
       jmp      G_M000_IG77
 
G_M000_IG65:                ;; offset=0x05D6
       mov      rdx, gword ptr [rbp-0xC0]
 
G_M000_IG66:                ;; offset=0x05DD
       mov      rsi, bword ptr [rbp-0xE0]
       mov      r10d, dword ptr [rsi+0x1C]
       dec      r10d
       mov      edi, r10d
       test     edi, edi
       mov      dword ptr [rbp-0x34], edi
       jl       G_M000_IG99
 
G_M000_IG67:                ;; offset=0x05F9
       mov      r9d, dword ptr [rbp-0x2C]
 
G_M000_IG68:                ;; offset=0x05FD
       mov      rdi, gword ptr [r14+0x98]
       mov      rsi, gword ptr [rdi+0x88]
       cmp      gword ptr [rsi+0x20], 0
       jne      G_M000_IG133
       mov      rsi, gword ptr [rdi+0x180]
       test     rsi, rsi
       jne      G_M000_IG132
 
G_M000_IG69:                ;; offset=0x0626
       mov      r10d, dword ptr [rbp-0x34]
       cmp      r10d, dword ptr [rbp-0xB8]
       jae      G_M000_IG151
       mov      dword ptr [rbp-0x34], r10d
       mov      edi, r10d
       lea      rdi, [rdi+4*rdi]
       mov      rdx, gword ptr [rbp-0xC0]
       lea      rsi, bword ptr [rdx+8*rdi+0x10]
       mov      bword ptr [rbp-0xE0], rsi
       mov      dword ptr [rbp-0x2C], r9d
       cmp      dword ptr [rsi+0x18], r9d
       jne      G_M000_IG66
 
G_M000_IG70:                ;; offset=0x0663
       mov      rdi, gword ptr [rdx+8*rdi+0x10]
       test     rdi, rdi
       je       G_M000_IG65
 
G_M000_IG71:                ;; offset=0x0671
       mov      r11, 0x7F23603BFBC0
       cmp      qword ptr [rdi], r11
       jne      G_M000_IG98
 
G_M000_IG72:                ;; offset=0x0684
       call     [Lokad.Lython.Runtime.Text.PyString:get_Utf8Span():System.ReadOnlySpan`1[byte]:this]
       mov      bword ptr [rbp-0xD8], rax
       mov      ecx, edx
       mov      dword ptr [rbp-0xB4], edx
       cmp      ecx, r15d
       jne      G_M000_IG135
       xor      edx, edx
       mov      dword ptr [rbp-0x70], edx
       cmp      edx, r15d
       jge      G_M000_IG76
 
G_M000_IG73:                ;; offset=0x06B0
       mov      rdi, gword ptr [r14+0x98]
       mov      rsi, gword ptr [rdi+0x88]
       cmp      gword ptr [rsi+0x20], 0
       jne      G_M000_IG137
       mov      rsi, gword ptr [rdi+0x180]
       test     rsi, rsi
       jne      G_M000_IG136
 
G_M000_IG74:                ;; offset=0x06D9
       mov      edx, dword ptr [rbp-0x70]
       mov      r8d, r15d
       sub      r8d, edx
       cmp      r8d, 0x1000
       jge      G_M000_IG97
 
G_M000_IG75:                ;; offset=0x06EF
       mov      edi, edx
       mov      esi, r8d
       add      rdi, rsi
       mov      esi, r15d
       cmp      rdi, rsi
       ja       G_M000_IG121
       mov      esi, edx
       add      rsi, r13
       mov      r9d, dword ptr [rbp-0xB4]
       cmp      rdi, r9
       ja       G_M000_IG121
       mov      dword ptr [rbp-0x70], edx
       mov      edi, edx
       add      rdi, bword ptr [rbp-0xD8]
       mov      r9, rdi
       mov      dword ptr [rbp-0x74], r8d
       mov      edx, r8d
       mov      rdi, rsi
       mov      rsi, r9
       call     [System.SpanHelpers:SequenceEqual(byref,byref,nuint):bool]
       test     eax, eax
       je       G_M000_IG138
       mov      edx, dword ptr [rbp-0x74]
       add      edx, dword ptr [rbp-0x70]
       cmp      edx, r15d
       mov      dword ptr [rbp-0x70], edx
       jl       G_M000_IG73
 
G_M000_IG76:                ;; offset=0x0754
       mov      r13d, dword ptr [rbp-0x34]
 
G_M000_IG77:                ;; offset=0x0758
       xor      edi, edi
       mov      rcx, bword ptr [rbp+0x20]
       mov      qword ptr [rcx], rdi
       test     r13d, r13d
       jl       G_M000_IG45
 
G_M000_IG78:                ;; offset=0x076A
       mov      rdx, gword ptr [rbp-0xC0]
       mov      edi, dword ptr [rdx+0x08]
       mov      edi, r13d
       lea      rdi, [rdi+4*rdi]
       lea      rsi, bword ptr [rdx+8*rdi+0x10]
       mov      r15d, r13d
       mov      rcx, gword ptr [rsi]
       mov      r14, rcx
       test     r14, r14
       je       SHORT G_M000_IG80
 
G_M000_IG79:                ;; offset=0x078E
       mov      rdx, 0x7F23603BFBC0
       cmp      qword ptr [r14], rdx
       jne      G_M000_IG139
 
G_M000_IG80:                ;; offset=0x07A1
       mov      ecx, dword ptr [rsi+0x18]
       mov      dword ptr [rbp-0x9C], ecx
       cmp      gword ptr [rbx+0x20], 0
       jne      G_M000_IG140
       mov      rsi, gword ptr [rbx+0x30]
       cmp      r15d, dword ptr [rsi+0x08]
       jae      G_M000_IG151
       mov      edx, r15d
       cmp      gword ptr [rsi+8*rdx+0x10], 0
       jne      G_M000_IG140
 
G_M000_IG81:                ;; offset=0x07D2
       mov      rsi, gword ptr [rbx+0x28]
       cmp      r15d, dword ptr [rsi+0x08]
       jae      G_M000_IG151
       mov      rsi, qword ptr [rsi+8*rdi+0x20]
       mov      rdi, 0xFF80000000000000
       cmp      rsi, rdi
       jl       G_M000_IG141
       mov      rdi, 0x80000000000000
       cmp      rsi, rdi
       jge      G_M000_IG141
 
G_M000_IG82:                ;; offset=0x080B
       test     r12, r12
       jne      G_M000_IG145
       movsxd   rdi, dword ptr [rbp-0xAC]
 
G_M000_IG83:                ;; offset=0x081B
       add      rsi, rdi
       mov      r12d, dword ptr [rbx+0x4C]
       cmp      gword ptr [rbx+0x20], 0
       jne      G_M000_IG150
       mov      rdi, gword ptr [rbx+0x28]
       cmp      r15d, dword ptr [rdi+0x08]
       jae      G_M000_IG151
       mov      eax, r15d
       lea      rax, [rax+4*rax]
       mov      qword ptr [rdi+8*rax+0x20], rsi
       mov      rdi, gword ptr [rbx+0x30]
       cmp      r15d, dword ptr [rdi+0x08]
       jae      G_M000_IG151
       mov      esi, r15d
       xor      rax, rax
       mov      gword ptr [rdi+8*rsi+0x10], rax
 
G_M000_IG84:                ;; offset=0x085F
       cmp      dword ptr [rbx+0x4C], r12d
       jne      G_M000_IG44
 
G_M000_IG85:                ;; offset=0x0869
       mov      eax, 1
 
G_M000_IG86:                ;; offset=0x086E
       vzeroupper 
       add      rsp, 216
       pop      rbx
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG87:                ;; offset=0x0883
       mov      r10d, 0x1000
       jmp      G_M000_IG07
 
G_M000_IG88:                ;; offset=0x088E
       mov      r9d, 0x31A787B3
       jmp      G_M000_IG36
 
G_M000_IG89:                ;; offset=0x0899
       mov      r9, gword ptr [rsi+0x08]
       lea      r10, bword ptr [rsi+0x28]
       mov      r10d, dword ptr [r10]
       mov      esi, dword ptr [rsi+0x18]
       test     r9, r9
       je       G_M000_IG108
       mov      r11d, esi
       add      r11, r10
       mov      ecx, dword ptr [r9+0x08]
       cmp      r11, rcx
       ja       G_M000_IG121
       lea      r9, bword ptr [r9+r10+0x10]
       mov      r10d, esi
 
G_M000_IG90:                ;; offset=0x08CB
       jmp      G_M000_IG59
 
G_M000_IG91:                ;; offset=0x08D0
       xor      esi, esi
       mov      r11, r10
       and      r11, 2
       mov      qword ptr [rbp-0x40], r11
       test     r11, r11
       jne      G_M000_IG109
 
G_M000_IG92:                ;; offset=0x08E6
       test     r10b, 1
       jne      G_M000_IG110
 
G_M000_IG93:                ;; offset=0x08F0
       test     esi, esi
       sete     sil
       movzx    rsi, sil
       jmp      G_M000_IG63
 
G_M000_IG94:                ;; offset=0x08FF
       cmp      rsi, r11
       je       G_M000_IG119
       cmp      r10, 32
       jae      G_M000_IG111
 
G_M000_IG95:                ;; offset=0x0912
       cmp      r10, 16
       jae      G_M000_IG115
 
G_M000_IG96:                ;; offset=0x091C
       add      r10, -8
       mov      r11, qword ptr [r13]
       sub      r11, qword ptr [r9]
       mov      rsi, qword ptr [r10+r13]
       sub      rsi, qword ptr [r9+r10]
       or       rsi, r11
       sete     sil
       movzx    rsi, sil
       jmp      G_M000_IG63
 
G_M000_IG97:                ;; offset=0x093F
       mov      r8d, 0x1000
       jmp      G_M000_IG75
 
G_M000_IG98:                ;; offset=0x094A
       mov      rdx, gword ptr [rbp-0xC0]
       jmp      G_M000_IG66
 
G_M000_IG99:                ;; offset=0x0956
       mov      r14d, dword ptr [rbp-0x2C]
 
G_M000_IG100:                ;; offset=0x095A
       mov      r13d, -1
       mov      dword ptr [rbp-0x2C], r14d
       jmp      G_M000_IG77
 
G_M000_IG101:                ;; offset=0x0969
       cmp      dword ptr [rsi+0x20], 0
       setne    sil
       movzx    rsi, sil
       test     esi, esi
       je       G_M000_IG03
 
G_M000_IG102:                ;; offset=0x097D
       mov      rsi, gword ptr [rbp+0x18]
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
       jmp      G_M000_IG03
 
G_M000_IG103:                ;; offset=0x098C
       jmp      SHORT G_M000_IG100
 
G_M000_IG104:                ;; offset=0x098E
       mov      r9, gword ptr [rsi+0x08]
       mov      r10d, dword ptr [rsi+0x18]
       test     r9, r9
       jne      SHORT G_M000_IG106
 
G_M000_IG105:                ;; offset=0x099B
       test     r10d, r10d
       jne      G_M000_IG121
       xor      r9, r9
       xor      r10d, r10d
       jmp      SHORT G_M000_IG107
 
G_M000_IG106:                ;; offset=0x09AC
       cmp      dword ptr [r9+0x08], r10d
       jb       G_M000_IG121
       add      r9, 16
 
G_M000_IG107:                ;; offset=0x09BA
       jmp      G_M000_IG59
 
G_M000_IG108:                ;; offset=0x09BF
       or       r10d, esi
       jne      G_M000_IG121
       xor      r9, r9
       xor      r10d, r10d
       jmp      G_M000_IG90
 
G_M000_IG109:                ;; offset=0x09D3
       movzx    rsi, word  ptr [r13]
       mov      dword ptr [rbp-0xE4], esi
       movzx    rsi, word  ptr [r9]
       movzx    r11, dword ptr [rbp-0xE4]
       sub      r11d, esi
       mov      esi, r11d
       jmp      G_M000_IG92
 
G_M000_IG110:                ;; offset=0x09F5
       mov      r11, qword ptr [rbp-0x40]
       movzx    r10, byte  ptr [r11+r13]
       movzx    r9, byte  ptr [r9+r11]
       sub      r10d, r9d
       or       esi, r10d
       jmp      G_M000_IG93
 
G_M000_IG111:                ;; offset=0x0A0E
       xor      esi, esi
       lea      r9, [r10-0x20]
       test     r9, r9
       je       SHORT G_M000_IG114
       vmovups  ymm0, ymmword ptr [r13]
       vpcmpeqb ymm0, ymm0, ymmword ptr [r11]
       vpmovmskb r10d, ymm0
       cmp      r10d, -1
       jne      G_M000_IG120
 
G_M000_IG112:                ;; offset=0x0A32
       add      rsi, 32
       cmp      r9, rsi
       jbe      SHORT G_M000_IG114
 
G_M000_IG113:                ;; offset=0x0A3B
       vmovups  ymm0, ymmword ptr [rsi+r13]
       vpcmpeqb ymm0, ymm0, ymmword ptr [r11+rsi]
       vpmovmskb r10d, ymm0
       cmp      r10d, -1
       jne      G_M000_IG120
       jmp      SHORT G_M000_IG112
 
G_M000_IG114:                ;; offset=0x0A57
       vmovups  ymm0, ymmword ptr [r9+r13]
       vpcmpeqb ymm0, ymm0, ymmword ptr [r11+r9]
       vpmovmskb esi, ymm0
       cmp      esi, -1
       jne      SHORT G_M000_IG120
       jmp      SHORT G_M000_IG119
 
G_M000_IG115:                ;; offset=0x0A6E
       xor      esi, esi
       add      r10, -16
       je       SHORT G_M000_IG118
       vmovups  xmm0, xmmword ptr [r13]
       vpcmpeqb xmm0, xmm0, xmmword ptr [r11]
       vpmovmskb r9d, xmm0
       cmp      r9d, 0xFFFF
       jne      SHORT G_M000_IG120
 
G_M000_IG116:                ;; offset=0x0A8E
       add      rsi, 16
       cmp      r10, rsi
       jbe      SHORT G_M000_IG118
 
G_M000_IG117:                ;; offset=0x0A97
       vmovups  xmm0, xmmword ptr [rsi+r13]
       vpcmpeqb xmm0, xmm0, xmmword ptr [r11+rsi]
       vpmovmskb r9d, xmm0
       cmp      r9d, 0xFFFF
       jne      SHORT G_M000_IG120
       jmp      SHORT G_M000_IG116
 
G_M000_IG118:                ;; offset=0x0AB2
       vmovups  xmm0, xmmword ptr [r10+r13]
       vpcmpeqb xmm0, xmm0, xmmword ptr [r11+r10]
       vpmovmskb r11d, xmm0
       cmp      r11d, 0xFFFF
       jne      SHORT G_M000_IG120
 
G_M000_IG119:                ;; offset=0x0ACB
       mov      esi, 1
       jmp      G_M000_IG63
 
G_M000_IG120:                ;; offset=0x0AD5
       xor      esi, esi
       jmp      G_M000_IG63
 
G_M000_IG121:                ;; offset=0x0ADC
       call     [System.ThrowHelper:ThrowArgumentOutOfRangeException()]
       int3     
 
G_M000_IG122:                ;; offset=0x0AE3
       cmp      dword ptr [rsi+0x20], 0
       setne    sil
       movzx    rsi, sil
       test     esi, esi
       je       G_M000_IG06
 
G_M000_IG123:                ;; offset=0x0AF7
       mov      rsi, gword ptr [rbp+0x18]
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
       mov      rdx, gword ptr [rbp-0xC0]
       mov      r8d, dword ptr [rbp-0x30]
       jmp      G_M000_IG06
 
G_M000_IG124:                ;; offset=0x0B11
       mov      ecx, dword ptr [rbp-0x44]
       and      ecx, 3
       dec      ecx
       cmp      ecx, 2
       ja       G_M000_IG09
       mov      qword ptr [rbp-0xEC], rcx
       lea      rcx, [reloc @RWD00]
       mov      dword ptr [rbp-0xB0], esi
       mov      r11, qword ptr [rbp-0xEC]
       mov      ecx, dword ptr [rcx+4*r11]
       lea      rax, G_M000_IG02
       add      rcx, rax
       jmp      rcx
 
G_M000_IG125:                ;; offset=0x0B4D
       mov      rax, rdi
       jmp      SHORT G_M000_IG129
 
G_M000_IG126:                ;; offset=0x0B52
       mov      rcx, rdi
       jmp      SHORT G_M000_IG128
 
G_M000_IG127:                ;; offset=0x0B57
       mov      rdi, bword ptr [rbp-0xC8]
       mov      esi, dword ptr [rdi]
       lea      rdi, [rbp-0x60]
       call     [System.HashCode:Add(int):this]
       mov      rdi, bword ptr [rbp-0xC8]
       add      rdi, 4
       mov      eax, dword ptr [rbp-0x68]
       lea      esi, [rax-0x04]
       mov      rcx, rdi
       mov      dword ptr [rbp-0xB0], esi
 
G_M000_IG128:                ;; offset=0x0B84
       mov      bword ptr [rbp-0xD0], rcx
       mov      esi, dword ptr [rcx]
       lea      rdi, [rbp-0x60]
       call     [System.HashCode:Add(int):this]
       mov      rcx, bword ptr [rbp-0xD0]
       add      rcx, 4
       mov      edx, dword ptr [rbp-0xB0]
       add      edx, -4
       mov      rax, rcx
       mov      dword ptr [rbp-0xB0], edx
 
G_M000_IG129:                ;; offset=0x0BB4
       mov      bword ptr [rbp-0xD0], rax
       mov      esi, dword ptr [rax]
       lea      rdi, [rbp-0x60]
       call     [System.HashCode:Add(int):this]
       mov      rax, bword ptr [rbp-0xD0]
       add      rax, 4
       mov      edx, dword ptr [rbp-0xB0]
       add      edx, -4
       mov      esi, edx
       mov      rdi, rax
       mov      rdx, gword ptr [rbp-0xC0]
       mov      r8d, dword ptr [rbp-0x30]
       jmp      G_M000_IG09
 
G_M000_IG130:                ;; offset=0x0BF0
       mov      r14d, r9d
       jmp      G_M000_IG100
 
G_M000_IG131:                ;; offset=0x0BF8
       mov      dword ptr [rbp-0x2C], r9d
       mov      eax, r9d
       xor      edx, edx
       div      edx:eax, edi
       mov      edi, edx
       mov      r9d, dword ptr [rbp-0x2C]
       jmp      G_M000_IG42
 
G_M000_IG132:                ;; offset=0x0C0E
       cmp      dword ptr [rsi+0x20], 0
       setne    sil
       movzx    rsi, sil
       test     esi, esi
       je       G_M000_IG69
       mov      dword ptr [rbp-0x2C], r9d
       jmp      SHORT G_M000_IG134
 
G_M000_IG133:                ;; offset=0x0C28
       mov      dword ptr [rbp-0x2C], r9d
 
G_M000_IG134:                ;; offset=0x0C2C
       mov      rsi, gword ptr [rbp+0x18]
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
       mov      r9d, dword ptr [rbp-0x2C]
       jmp      G_M000_IG69
 
G_M000_IG135:                ;; offset=0x0C3F
       mov      rdx, gword ptr [rbp-0xC0]
       jmp      G_M000_IG66
 
G_M000_IG136:                ;; offset=0x0C4B
       cmp      dword ptr [rsi+0x20], 0
       setne    sil
       movzx    rsi, sil
       test     esi, esi
       je       G_M000_IG74
 
G_M000_IG137:                ;; offset=0x0C5F
       mov      rsi, gword ptr [rbp+0x18]
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
       jmp      G_M000_IG74
 
G_M000_IG138:                ;; offset=0x0C6E
       mov      rdx, gword ptr [rbp-0xC0]
       jmp      G_M000_IG66
 
G_M000_IG139:                ;; offset=0x0C7A
       mov      rsi, rcx
       mov      rdi, rdx
       call     CORINFO_HELP_CHKCASTCLASS
       int3     
 
G_M000_IG140:                ;; offset=0x0C86
       mov      rdi, rbx
       mov      esi, r15d
       call     [Lokad.Lython.Runtime.PyDict:ReadNativeValue(int):System.Object:this]
       test     rax, rax
       jne      SHORT G_M000_IG142
 
G_M000_IG141:                ;; offset=0x0C97
       xor      eax, eax
       jmp      G_M000_IG86
 
G_M000_IG142:                ;; offset=0x0C9E
       mov      rdi, 0x7F2360360018
       cmp      qword ptr [rax], rdi
       jne      SHORT G_M000_IG141
 
G_M000_IG143:                ;; offset=0x0CAD
       vmovdqu  xmm0, xmmword ptr [rax+0x08]
       vmovdqu  xmmword ptr [rbp-0x88], xmm0
 
G_M000_IG144:                ;; offset=0x0CBA
       xor      edi, edi
       mov      dword ptr [rbp-0xA8], edi
       lea      rdi, [rbp-0xA8]
       mov      qword ptr [rsp], rdi
       lea      rdi, [rbp-0x88]
       xor      rdx, rdx
       xor      ecx, ecx
       mov      esi, 1
       xor      r8d, r8d
       xor      r9d, r9d
       call     [System.Numerics.BigInteger:TryGetBytes(int,System.Span`1[byte],bool,bool,byref):byte[]:this]
       cmp      dword ptr [rbp-0xA8], 8
       jge      SHORT G_M000_IG141
       mov      rdi, gword ptr [rbp-0x88]
       mov      rsi, qword ptr [rbp-0x80]
       call     [System.Numerics.BigInteger:op_Explicit(System.Numerics.BigInteger):long]
       mov      rsi, rax
       jmp      G_M000_IG82
 
G_M000_IG145:                ;; offset=0x0D0B
       cmp      dword ptr [r12+0x08], 1
       jle      SHORT G_M000_IG146
       mov      rdi, 0x7F23608E52B8
       call     CORINFO_HELP_NEWSFAST
       mov      rbx, rax
       call     [System.SR:get_Overflow_Int64():System.String]
       mov      rsi, rax
       mov      rdi, rbx
       call     [System.OverflowException:.ctor(System.String):this]
       mov      rdi, rbx
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG146:                ;; offset=0x0D40
       cmp      dword ptr [r12+0x08], 0
       jbe      G_M000_IG151
       mov      rdi, qword ptr [r12+0x10]
       mov      rdx, rdi
       neg      rdx
       mov      eax, dword ptr [rbp-0xAC]
       test     eax, eax
       cmovle   rdi, rdx
       test     rdi, rdi
       jle      SHORT G_M000_IG147
       test     eax, eax
       jg       SHORT G_M000_IG148
 
G_M000_IG147:                ;; offset=0x0D6C
       test     rdi, rdi
       jge      SHORT G_M000_IG149
       test     eax, eax
       jge      SHORT G_M000_IG149
 
G_M000_IG148:                ;; offset=0x0D75
       jmp      G_M000_IG83
 
G_M000_IG149:                ;; offset=0x0D7A
       mov      rdi, 0x7F23608E52B8
       call     CORINFO_HELP_NEWSFAST
       mov      rbx, rax
       call     [System.SR:get_Overflow_Int64():System.String]
       mov      rsi, rax
       mov      rdi, rbx
       call     [System.OverflowException:.ctor(System.String):this]
       mov      rdi, rbx
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG150:                ;; offset=0x0DA7
       lea      rdi, [rbp-0x98]
       call     [System.Numerics.BigInteger:.ctor(long):this]
       mov      rdi, 0x7F2360360018
       call     CORINFO_HELP_NEWSFAST
       mov      r15, rax
       lea      rdi, bword ptr [r15+0x08]
       mov      rsi, gword ptr [rbp-0x98]
       call     CORINFO_HELP_ASSIGN_REF
       mov      ecx, dword ptr [rbp-0x90]
       mov      dword ptr [r15+0x10], ecx
       mov      dword ptr [rsp], 1
       mov      rcx, r15
       mov      rdi, rbx
       mov      esi, r13d
       mov      rdx, r14
       mov      r8d, dword ptr [rbp-0x9C]
       xor      r9d, r9d
       call     [Lokad.Lython.Runtime.PyDict:PublishNativeValue(int,System.Object,System.Object,uint,bool,bool):System.Object:this]
       jmp      G_M000_IG84
 
G_M000_IG151:                ;; offset=0x0E08
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
RWD00  	dd	00000B07h ; case G_M000_IG127
       	dd	00000B02h ; case G_M000_IG126
       	dd	00000AFDh ; case G_M000_IG125

; Total bytes of code 3598

; Assembly listing for method Lokad.Lython.Runtime.PyDict:FindNativeTextIndex(Lokad.Lython.Runtime.PyDict+NativeKey[],int,System.ReadOnlySpan`1[byte],Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,byref):int (Tier1)
; Emitting BLENDED_CODE for x64 + VEX on Unix
; Tier1 code
; optimized code
; optimized using Synthesized PGO
; rbp based frame
; fully interruptible
; with Synthesized PGO: fgCalledCount is 1064632
; 47 inlinees with PGO data; 94 single block inlinees; 1 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       push     r15
       push     r14
       push     r13
       push     r12
       push     rbx
       sub      rsp, 120
       lea      rbp, [rsp+0xA0]
       vxorps   xmm8, xmm8, xmm8
       vmovdqu  ymmword ptr [rbp-0x50], ymm8
       mov      rbx, rdi
       mov      r14d, esi
       mov      r12, rdx
       mov      r15d, ecx
       mov      rcx, r9
       mov      r13, r8
       mov      rax, bword ptr [rbp+0x10]
 
G_M000_IG02:                ;; offset=0x0036
       cmp      r14d, 4
       jle      G_M000_IG45
 
G_M000_IG03:                ;; offset=0x0040
       vxorps   ymm0, ymm0, ymm0
       vmovdqu  ymmword ptr [rbp-0x50], ymm0
       xor      edx, edx
       mov      dword ptr [rbp-0x54], edx
       cmp      edx, r15d
       jge      G_M000_IG34
 
G_M000_IG04:                ;; offset=0x0057
       test     r13, r13
       je       SHORT G_M000_IG06
 
G_M000_IG05:                ;; offset=0x005C
       mov      rdi, gword ptr [r13+0x98]
       mov      rsi, gword ptr [rdi+0x88]
       cmp      gword ptr [rsi+0x20], 0
       jne      G_M000_IG101
       mov      rsi, gword ptr [rdi+0x180]
       test     rsi, rsi
       jne      G_M000_IG100
 
G_M000_IG06:                ;; offset=0x0085
       mov      edx, dword ptr [rbp-0x54]
       mov      r8d, r15d
       sub      r8d, edx
       cmp      r8d, 0x1000
       jge      G_M000_IG60
 
G_M000_IG07:                ;; offset=0x009B
       mov      dword ptr [rbp-0x58], r8d
       mov      esi, edx
       mov      edi, r8d
       add      rsi, rdi
       mov      edi, r15d
       cmp      rsi, rdi
       ja       G_M000_IG99
       mov      dword ptr [rbp-0x54], edx
       mov      r9d, edx
       add      r9, r12
       mov      bword ptr [rbp-0x80], r9
       mov      r10, r9
       mov      r11d, r8d
       cmp      r8d, 16
       jl       G_M000_IG21
 
G_M000_IG08:                ;; offset=0x00D0
       cmp      dword ptr [rbp-0x34], 0
       jne      G_M000_IG103
       mov      r9, 0xA13CEA793F74642A
       mov      qword ptr [rbp-0x50], r9
       mov      rsi, 0x7D19A6511B512002
       mov      qword ptr [rbp-0x48], rsi
 
G_M000_IG09:                ;; offset=0x00F6
       cmp      r11d, 16
       jl       G_M000_IG21
 
G_M000_IG10:                ;; offset=0x0100
       mov      edi, dword ptr [rbp-0x50]
       imul     esi, dword ptr [r10], 0xFFFFFFFF85EBCA77
       add      edi, esi
       rol      edi, 13
       imul     edi, edi, 0xFFFFFFFF9E3779B1
       mov      dword ptr [rbp-0x50], edi
       mov      edi, dword ptr [rbp-0x4C]
       lea      rsi, bword ptr [r10+0x04]
       imul     esi, dword ptr [rsi], 0xFFFFFFFF85EBCA77
       add      edi, esi
       rol      edi, 13
       imul     edi, edi, 0xFFFFFFFF9E3779B1
       mov      dword ptr [rbp-0x4C], edi
       mov      edi, dword ptr [rbp-0x48]
       lea      rsi, bword ptr [r10+0x08]
       imul     esi, dword ptr [rsi], 0xFFFFFFFF85EBCA77
       add      edi, esi
       rol      edi, 13
       imul     edi, edi, 0xFFFFFFFF9E3779B1
       mov      dword ptr [rbp-0x48], edi
       mov      edi, dword ptr [rbp-0x44]
       lea      rsi, bword ptr [r10+0x0C]
       imul     esi, dword ptr [rsi], 0xFFFFFFFF85EBCA77
       add      edi, esi
       rol      edi, 13
       imul     edi, edi, 0xFFFFFFFF9E3779B1
       mov      dword ptr [rbp-0x44], edi
       mov      edi, dword ptr [rbp-0x34]
       add      edi, 4
       mov      dword ptr [rbp-0x34], edi
       add      r10, 16
       add      r11d, -16
       mov      rdi, r10
       mov      esi, r11d
       mov      r10, rdi
       mov      r11d, esi
       jmp      G_M000_IG09
 
G_M000_IG11:                ;; offset=0x018B
       mov      edi, dword ptr [r10]
       mov      esi, dword ptr [rbp-0x34]
       lea      r9d, [rsi+0x01]
       mov      dword ptr [rbp-0x34], r9d
       mov      r9d, esi
       and      r9d, 3
       je       G_M000_IG19
 
G_M000_IG12:                ;; offset=0x01A6
       cmp      r9d, 1
       jne      SHORT G_M000_IG14
 
G_M000_IG13:                ;; offset=0x01AC
       mov      dword ptr [rbp-0x3C], edi
       jmp      G_M000_IG20
 
G_M000_IG14:                ;; offset=0x01B4
       cmp      r9d, 2
       jne      SHORT G_M000_IG16
 
G_M000_IG15:                ;; offset=0x01BA
       mov      dword ptr [rbp-0x38], edi
       jmp      G_M000_IG20
 
G_M000_IG16:                ;; offset=0x01C2
       cmp      esi, 3
       jne      SHORT G_M000_IG18
 
G_M000_IG17:                ;; offset=0x01C7
       mov      rsi, 0xA13CEA793F74642A
       mov      qword ptr [rbp-0x50], rsi
       mov      rsi, 0x7D19A6511B512002
       mov      qword ptr [rbp-0x48], rsi
 
G_M000_IG18:                ;; offset=0x01E3
       imul     esi, dword ptr [rbp-0x40], 0xFFFFFFFF85EBCA77
       add      esi, dword ptr [rbp-0x50]
       rol      esi, 13
       imul     esi, esi, 0xFFFFFFFF9E3779B1
       mov      dword ptr [rbp-0x50], esi
       imul     esi, dword ptr [rbp-0x3C], 0xFFFFFFFF85EBCA77
       add      esi, dword ptr [rbp-0x4C]
       rol      esi, 13
       imul     esi, esi, 0xFFFFFFFF9E3779B1
       mov      dword ptr [rbp-0x4C], esi
       imul     esi, dword ptr [rbp-0x38], 0xFFFFFFFF85EBCA77
       add      esi, dword ptr [rbp-0x48]
       rol      esi, 13
       imul     esi, esi, 0xFFFFFFFF9E3779B1
       mov      dword ptr [rbp-0x48], esi
       imul     edi, edi, 0xFFFFFFFF85EBCA77
       add      edi, dword ptr [rbp-0x44]
       rol      edi, 13
       imul     edi, edi, 0xFFFFFFFF9E3779B1
       mov      dword ptr [rbp-0x44], edi
       jmp      SHORT G_M000_IG20
 
G_M000_IG19:                ;; offset=0x023C
       mov      dword ptr [rbp-0x40], edi
 
G_M000_IG20:                ;; offset=0x023F
       add      r10, 4
       add      r11d, -4
       mov      rdi, r10
       mov      esi, r11d
       mov      r10, rdi
       mov      r11d, esi
 
G_M000_IG21:                ;; offset=0x0253
       cmp      r11d, 4
       jge      G_M000_IG11
 
G_M000_IG22:                ;; offset=0x025D
       mov      rdi, r10
       mov      esi, r11d
       xor      r9d, r9d
       test     esi, esi
       je       G_M000_IG33
 
G_M000_IG23:                ;; offset=0x026E
       movzx    r10, byte  ptr [rdi+r9]
       mov      dword ptr [rbp-0x5C], r10d
       mov      r11d, dword ptr [rbp-0x34]
       lea      r10d, [r11+0x01]
       mov      dword ptr [rbp-0x34], r10d
       mov      r10d, r11d
       and      r10d, 3
       je       G_M000_IG31
 
G_M000_IG24:                ;; offset=0x0290
       cmp      r10d, 1
       jne      SHORT G_M000_IG26
 
G_M000_IG25:                ;; offset=0x0296
       mov      r10d, dword ptr [rbp-0x5C]
       mov      dword ptr [rbp-0x3C], r10d
       jmp      G_M000_IG32
 
G_M000_IG26:                ;; offset=0x02A3
       cmp      r10d, 2
       jne      SHORT G_M000_IG28
 
G_M000_IG27:                ;; offset=0x02A9
       mov      r10d, dword ptr [rbp-0x5C]
       mov      dword ptr [rbp-0x38], r10d
       jmp      G_M000_IG32
 
G_M000_IG28:                ;; offset=0x02B6
       cmp      r11d, 3
       jne      SHORT G_M000_IG30
 
G_M000_IG29:                ;; offset=0x02BC
       mov      r11, 0xA13CEA793F74642A
       mov      qword ptr [rbp-0x50], r11
       mov      r11, 0x7D19A6511B512002
       mov      qword ptr [rbp-0x48], r11
 
G_M000_IG30:                ;; offset=0x02D8
       imul     r11d, dword ptr [rbp-0x40], 0xFFFFFFFF85EBCA77
       add      r11d, dword ptr [rbp-0x50]
       rol      r11d, 13
       imul     r11d, r11d, 0xFFFFFFFF9E3779B1
       mov      dword ptr [rbp-0x50], r11d
       imul     r11d, dword ptr [rbp-0x3C], 0xFFFFFFFF85EBCA77
       add      r11d, dword ptr [rbp-0x4C]
       rol      r11d, 13
       imul     r11d, r11d, 0xFFFFFFFF9E3779B1
       mov      dword ptr [rbp-0x4C], r11d
       imul     r11d, dword ptr [rbp-0x38], 0xFFFFFFFF85EBCA77
       add      r11d, dword ptr [rbp-0x48]
       rol      r11d, 13
       imul     r11d, r11d, 0xFFFFFFFF9E3779B1
       mov      dword ptr [rbp-0x48], r11d
       imul     r10d, dword ptr [rbp-0x5C], 0xFFFFFFFF85EBCA77
       add      r10d, dword ptr [rbp-0x44]
       rol      r10d, 13
       imul     r10d, r10d, 0xFFFFFFFF9E3779B1
       mov      dword ptr [rbp-0x44], r10d
       jmp      SHORT G_M000_IG32
 
G_M000_IG31:                ;; offset=0x0346
       mov      r10d, dword ptr [rbp-0x5C]
       mov      dword ptr [rbp-0x40], r10d
 
G_M000_IG32:                ;; offset=0x034E
       inc      r9d
       cmp      r9d, esi
       jl       G_M000_IG23
 
G_M000_IG33:                ;; offset=0x035A
       mov      edx, dword ptr [rbp-0x54]
       add      edx, dword ptr [rbp-0x58]
       cmp      edx, r15d
       mov      dword ptr [rbp-0x54], edx
       jl       G_M000_IG04
 
G_M000_IG34:                ;; offset=0x036C
       mov      edx, dword ptr [rbp-0x34]
       mov      edi, edx
       and      edi, 3
       cmp      edx, 4
       jb       G_M000_IG61
 
G_M000_IG35:                ;; offset=0x037D
       rorx     esi, dword ptr [rbp-0x50], 31
       rorx     r8d, dword ptr [rbp-0x4C], 25
       add      esi, r8d
       rorx     r8d, dword ptr [rbp-0x48], 20
       add      esi, r8d
       rorx     r8d, dword ptr [rbp-0x44], 14
       add      esi, r8d
 
G_M000_IG36:                ;; offset=0x03A2
       lea      edx, [rsi+4*rdx]
       test     edi, edi
       je       SHORT G_M000_IG40
 
G_M000_IG37:                ;; offset=0x03A9
       imul     esi, dword ptr [rbp-0x40], 0xFFFFFFFFC2B2AE3D
       add      edx, esi
       rol      edx, 17
       imul     edx, edx, 0x27D4EB2F
       cmp      edi, 1
       jbe      SHORT G_M000_IG40
 
G_M000_IG38:                ;; offset=0x03C0
       imul     esi, dword ptr [rbp-0x3C], 0xFFFFFFFFC2B2AE3D
       add      esi, edx
       rol      esi, 17
       imul     edx, esi, 0x27D4EB2F
       cmp      edi, 2
       jbe      SHORT G_M000_IG40
 
G_M000_IG39:                ;; offset=0x03D7
       imul     edi, dword ptr [rbp-0x38], 0xFFFFFFFFC2B2AE3D
       add      edi, edx
       rol      edi, 17
       imul     edx, edi, 0x27D4EB2F
 
G_M000_IG40:                ;; offset=0x03E9
       mov      edi, edx
       shr      edi, 15
       xor      edi, edx
       imul     edx, edi, 0xFFFFFFFF85EBCA77
       mov      edi, edx
       shr      edi, 13
       xor      edi, edx
       imul     edx, edi, 0xFFFFFFFFC2B2AE3D
       mov      edi, edx
       shr      edi, 16
       xor      edx, edi
       mov      edi, -2
       cmp      edx, -1
       cmovne   edi, edx
       mov      edx, edi
       shr      edx, 16
       xor      edx, edi
       imul     edx, edx, 0xFFFFFFFF9E3779B9
       mov      edi, edx
       shr      edi, 16
       xor      edi, edx
       mov      dword ptr [rax], edi
       test     r14d, r14d
       je       SHORT G_M000_IG43
 
G_M000_IG41:                ;; offset=0x0430
       mov      bword ptr [rbp+0x10], rax
       mov      edx, dword ptr [rax]
       mov      edi, dword ptr [rbx+0x08]
       mov      r14d, edi
       mov      edi, r14d
       blsr     esi, edi
       jne      G_M000_IG109
       dec      edi
       and      edi, edx
 
G_M000_IG42:                ;; offset=0x044E
       cmp      edi, r14d
       jae      G_M000_IG116
       mov      edi, edi
       lea      rdi, [rdi+4*rdi]
       mov      edx, dword ptr [rbx+8*rdi+0x30]
       dec      edx
       mov      dword ptr [rbp-0x2C], edx
       test     edx, edx
       jge      G_M000_IG71
 
G_M000_IG43:                ;; offset=0x046E
       mov      eax, -1
 
G_M000_IG44:                ;; offset=0x0473
       vzeroupper 
       add      rsp, 120
       pop      rbx
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG45:                ;; offset=0x0485
       cmp      r15d, 8
       jg       G_M000_IG03
 
G_M000_IG46:                ;; offset=0x048F
       xor      edi, edi
       mov      dword ptr [rax], edi
 
G_M000_IG47:                ;; offset=0x0493
       test     r14d, r14d
       jle      SHORT G_M000_IG43
       jmp      SHORT G_M000_IG49
 
G_M000_IG48:                ;; offset=0x049A
       inc      edi
       cmp      edi, r14d
       jge      SHORT G_M000_IG43
 
G_M000_IG49:                ;; offset=0x04A1
       mov      r13d, dword ptr [rbx+0x08]
       cmp      edi, r13d
       jae      G_M000_IG116
       lea      rcx, [rdi+4*rdi]
       mov      rsi, gword ptr [rbx+8*rcx+0x10]
       test     rsi, rsi
       je       SHORT G_M000_IG48
 
G_M000_IG50:                ;; offset=0x04BC
       mov      rax, 0x7F23603BFBC0
       cmp      qword ptr [rsi], rax
       jne      SHORT G_M000_IG48
 
G_M000_IG51:                ;; offset=0x04CB
       movzx    rax, byte  ptr [rsi+0x24]
       test     eax, eax
       je       G_M000_IG82
 
G_M000_IG52:                ;; offset=0x04D7
       cmp      eax, 255
       je       SHORT G_M000_IG62
 
G_M000_IG53:                ;; offset=0x04DE
       lea      rax, bword ptr [rsi+0x28]
       mov      ecx, dword ptr [rsi+0x18]
       cmp      ecx, 8
       ja       G_M000_IG99
 
G_M000_IG54:                ;; offset=0x04EE
       cmp      r15d, ecx
       jne      SHORT G_M000_IG48
 
G_M000_IG55:                ;; offset=0x04F3
       mov      rsi, r12
       mov      rdx, rax
       mov      ecx, ecx
       cmp      rcx, 8
       jae      G_M000_IG67
 
G_M000_IG56:                ;; offset=0x0505
       cmp      rcx, 4
       jb       SHORT G_M000_IG64
 
G_M000_IG57:                ;; offset=0x050B
       add      rcx, -4
       mov      edx, dword ptr [r12]
       sub      edx, dword ptr [rax]
       mov      esi, dword ptr [r12+rcx]
       sub      esi, dword ptr [rax+rcx]
       or       esi, edx
       sete     sil
       movzx    rsi, sil
 
G_M000_IG58:                ;; offset=0x0526
       test     esi, esi
       je       G_M000_IG48
 
G_M000_IG59:                ;; offset=0x052E
       mov      eax, edi
       jmp      G_M000_IG80
 
G_M000_IG60:                ;; offset=0x0535
       mov      r8d, 0x1000
       jmp      G_M000_IG07
 
G_M000_IG61:                ;; offset=0x0540
       mov      esi, 0x31A787B3
       jmp      G_M000_IG36
 
G_M000_IG62:                ;; offset=0x054A
       mov      rax, gword ptr [rsi+0x08]
       lea      rcx, bword ptr [rsi+0x28]
       mov      ecx, dword ptr [rcx]
       mov      esi, dword ptr [rsi+0x18]
       test     rax, rax
       je       G_M000_IG86
       mov      edx, esi
       add      rdx, rcx
       mov      r8d, dword ptr [rax+0x08]
       cmp      rdx, r8
       ja       G_M000_IG99
       lea      rax, bword ptr [rax+rcx+0x10]
       mov      ecx, esi
 
G_M000_IG63:                ;; offset=0x0579
       jmp      G_M000_IG54
 
G_M000_IG64:                ;; offset=0x057E
       xor      esi, esi
       mov      rdx, rcx
       and      rdx, 2
       jne      G_M000_IG87
 
G_M000_IG65:                ;; offset=0x058D
       test     cl, 1
       jne      G_M000_IG88
 
G_M000_IG66:                ;; offset=0x0596
       test     esi, esi
       sete     sil
       movzx    rsi, sil
       jmp      SHORT G_M000_IG58
 
G_M000_IG67:                ;; offset=0x05A2
       cmp      rsi, rdx
       je       G_M000_IG97
       cmp      rcx, 32
       jae      G_M000_IG89
 
G_M000_IG68:                ;; offset=0x05B5
       cmp      rcx, 16
       jae      G_M000_IG93
 
G_M000_IG69:                ;; offset=0x05BF
       add      rcx, -8
       mov      rdx, qword ptr [r12]
       sub      rdx, qword ptr [rax]
       mov      rsi, qword ptr [r12+rcx]
       sub      rsi, qword ptr [rax+rcx]
       or       rsi, rdx
       sete     sil
       movzx    rsi, sil
       jmp      G_M000_IG58
 
G_M000_IG70:                ;; offset=0x05E2
       mov      rsi, bword ptr [rbp-0x98]
       mov      edx, dword ptr [rsi+0x1C]
       dec      edx
       mov      dword ptr [rbp-0x2C], edx
       js       G_M000_IG43
 
G_M000_IG71:                ;; offset=0x05F7
       mov      rdi, gword ptr [r13+0x98]
       mov      rsi, gword ptr [rdi+0x88]
       cmp      gword ptr [rsi+0x20], 0
       jne      G_M000_IG111
       mov      rsi, gword ptr [rdi+0x180]
       test     rsi, rsi
       jne      G_M000_IG110
 
G_M000_IG72:                ;; offset=0x0620
       mov      edx, dword ptr [rbp-0x2C]
       cmp      edx, r14d
       jae      G_M000_IG116
       mov      dword ptr [rbp-0x2C], edx
       mov      edi, edx
       lea      rdi, [rdi+4*rdi]
       lea      rsi, bword ptr [rbx+8*rdi+0x10]
       mov      bword ptr [rbp-0x98], rsi
       mov      r8d, dword ptr [rsi+0x18]
       mov      rax, bword ptr [rbp+0x10]
       cmp      r8d, dword ptr [rax]
       jne      SHORT G_M000_IG70
 
G_M000_IG73:                ;; offset=0x064E
       mov      rdi, gword ptr [rbx+8*rdi+0x10]
       test     rdi, rdi
       je       SHORT G_M000_IG70
 
G_M000_IG74:                ;; offset=0x0658
       mov      r8, 0x7F23603BFBC0
       cmp      qword ptr [rdi], r8
       jne      G_M000_IG70
 
G_M000_IG75:                ;; offset=0x066B
       mov      gword ptr [rbp-0x78], rcx
       mov      dword ptr [rbp-0x70], r15d
       call     [Lokad.Lython.Runtime.Text.PyString:get_Utf8Span():System.ReadOnlySpan`1[byte]:this]
       mov      bword ptr [rbp-0x90], rax
       mov      ecx, edx
       mov      dword ptr [rbp-0x6C], edx
       mov      edi, dword ptr [rbp-0x70]
       cmp      ecx, edi
       jne      G_M000_IG112
       xor      edx, edx
       mov      dword ptr [rbp-0x60], edx
       cmp      edx, r15d
       jge      G_M000_IG79
 
G_M000_IG76:                ;; offset=0x069E
       mov      rdi, gword ptr [r13+0x98]
       mov      rsi, gword ptr [rdi+0x88]
       cmp      gword ptr [rsi+0x20], 0
       jne      G_M000_IG114
       mov      rsi, gword ptr [rdi+0x180]
       test     rsi, rsi
       jne      G_M000_IG113
 
G_M000_IG77:                ;; offset=0x06C7
       mov      edx, dword ptr [rbp-0x60]
       mov      r8d, r15d
       sub      r8d, edx
       cmp      r8d, 0x1000
       jge      SHORT G_M000_IG81
 
G_M000_IG78:                ;; offset=0x06D9
       mov      edi, edx
       mov      esi, r8d
       add      rdi, rsi
       mov      esi, r15d
       cmp      rdi, rsi
       ja       G_M000_IG99
       mov      esi, edx
       add      rsi, r12
       mov      r9d, dword ptr [rbp-0x6C]
       cmp      rdi, r9
       ja       G_M000_IG99
       mov      dword ptr [rbp-0x60], edx
       mov      edi, edx
       add      rdi, bword ptr [rbp-0x90]
       mov      r9, rdi
       mov      dword ptr [rbp-0x64], r8d
       mov      edx, r8d
       mov      rdi, rsi
       mov      rsi, r9
       call     [System.SpanHelpers:SequenceEqual(byref,byref,nuint):bool]
       test     eax, eax
       je       G_M000_IG115
       mov      edx, dword ptr [rbp-0x64]
       add      edx, dword ptr [rbp-0x60]
       cmp      edx, r15d
       mov      dword ptr [rbp-0x60], edx
       jl       G_M000_IG76
 
G_M000_IG79:                ;; offset=0x073B
       mov      ebx, dword ptr [rbp-0x2C]
       mov      eax, ebx
 
G_M000_IG80:                ;; offset=0x0740
       vzeroupper 
       add      rsp, 120
       pop      rbx
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG81:                ;; offset=0x0752
       mov      r8d, 0x1000
       jmp      G_M000_IG78
 
G_M000_IG82:                ;; offset=0x075D
       mov      rax, gword ptr [rsi+0x08]
       mov      ecx, dword ptr [rsi+0x18]
       test     rax, rax
       jne      SHORT G_M000_IG84
 
G_M000_IG83:                ;; offset=0x0769
       test     ecx, ecx
       jne      G_M000_IG99
       xor      rax, rax
       xor      ecx, ecx
       jmp      SHORT G_M000_IG85
 
G_M000_IG84:                ;; offset=0x0777
       cmp      dword ptr [rax+0x08], ecx
       jb       G_M000_IG99
       add      rax, 16
 
G_M000_IG85:                ;; offset=0x0784
       jmp      G_M000_IG54
 
G_M000_IG86:                ;; offset=0x0789
       or       ecx, esi
       jne      G_M000_IG99
       xor      rax, rax
       xor      ecx, ecx
       jmp      G_M000_IG63
 
G_M000_IG87:                ;; offset=0x079A
       movzx    rsi, word  ptr [r12]
       movzx    r8, word  ptr [rax]
       sub      esi, r8d
       jmp      G_M000_IG65
 
G_M000_IG88:                ;; offset=0x07AB
       movzx    rcx, byte  ptr [r12+rdx]
       movzx    rax, byte  ptr [rax+rdx]
       sub      ecx, eax
       or       esi, ecx
       jmp      G_M000_IG66
 
G_M000_IG89:                ;; offset=0x07BD
       xor      esi, esi
       lea      rax, [rcx-0x20]
       test     rax, rax
       je       SHORT G_M000_IG92
       vmovups  ymm0, ymmword ptr [r12]
       vpcmpeqb ymm0, ymm0, ymmword ptr [rdx]
       vpmovmskb ecx, ymm0
       cmp      ecx, -1
       jne      G_M000_IG98
 
G_M000_IG90:                ;; offset=0x07DF
       add      rsi, 32
       cmp      rax, rsi
       jbe      SHORT G_M000_IG92
 
G_M000_IG91:                ;; offset=0x07E8
       vmovups  ymm0, ymmword ptr [r12+rsi]
       vpcmpeqb ymm0, ymm0, ymmword ptr [rdx+rsi]
       vpmovmskb ecx, ymm0
       cmp      ecx, -1
       jne      SHORT G_M000_IG98
       jmp      SHORT G_M000_IG90
 
G_M000_IG92:                ;; offset=0x07FE
       vmovups  ymm0, ymmword ptr [r12+rax]
       vpcmpeqb ymm0, ymm0, ymmword ptr [rdx+rax]
       vpmovmskb esi, ymm0
       cmp      esi, -1
       jne      SHORT G_M000_IG98
       jmp      SHORT G_M000_IG97
 
G_M000_IG93:                ;; offset=0x0814
       xor      esi, esi
       add      rcx, -16
       je       SHORT G_M000_IG96
       vmovups  xmm0, xmmword ptr [r12]
       vpcmpeqb xmm0, xmm0, xmmword ptr [rdx]
       vpmovmskb eax, xmm0
       cmp      eax, 0xFFFF
       jne      SHORT G_M000_IG98
 
G_M000_IG94:                ;; offset=0x0831
       add      rsi, 16
       cmp      rcx, rsi
       jbe      SHORT G_M000_IG96
 
G_M000_IG95:                ;; offset=0x083A
       vmovups  xmm0, xmmword ptr [r12+rsi]
       vpcmpeqb xmm0, xmm0, xmmword ptr [rdx+rsi]
       vpmovmskb eax, xmm0
       cmp      eax, 0xFFFF
       jne      SHORT G_M000_IG98
       jmp      SHORT G_M000_IG94
 
G_M000_IG96:                ;; offset=0x0852
       vmovups  xmm0, xmmword ptr [r12+rcx]
       vpcmpeqb xmm0, xmm0, xmmword ptr [rdx+rcx]
       vpmovmskb edx, xmm0
       cmp      edx, 0xFFFF
       jne      SHORT G_M000_IG98
 
G_M000_IG97:                ;; offset=0x0869
       mov      esi, 1
       jmp      G_M000_IG58
 
G_M000_IG98:                ;; offset=0x0873
       xor      esi, esi
       jmp      G_M000_IG58
 
G_M000_IG99:                ;; offset=0x087A
       call     [System.ThrowHelper:ThrowArgumentOutOfRangeException()]
       int3     
 
G_M000_IG100:                ;; offset=0x0881
       cmp      dword ptr [rsi+0x20], 0
       setne    sil
       movzx    rsi, sil
       test     esi, esi
       je       G_M000_IG06
       mov      bword ptr [rbp+0x10], rax
       jmp      SHORT G_M000_IG102
 
G_M000_IG101:                ;; offset=0x089B
       mov      bword ptr [rbp+0x10], rax
 
G_M000_IG102:                ;; offset=0x089F
       mov      gword ptr [rbp-0x78], rcx
       mov      rsi, rcx
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rbp-0x78]
       jmp      G_M000_IG06
 
G_M000_IG103:                ;; offset=0x08B9
       mov      esi, dword ptr [rbp-0x34]
       and      esi, 3
       dec      esi
       cmp      esi, 2
       ja       G_M000_IG09
       mov      gword ptr [rbp-0x78], rcx
       lea      rdi, [reloc @RWD00]
       mov      dword ptr [rbp-0x68], r11d
       mov      bword ptr [rbp+0x10], rax
       mov      edi, dword ptr [rdi+4*rsi]
       lea      rcx, G_M000_IG02
       add      rdi, rcx
       jmp      rdi
 
G_M000_IG104:                ;; offset=0x08EC
       mov      rax, r10
       jmp      SHORT G_M000_IG108
 
G_M000_IG105:                ;; offset=0x08F1
       mov      rcx, r10
       jmp      SHORT G_M000_IG107
 
G_M000_IG106:                ;; offset=0x08F6
       mov      esi, dword ptr [r9]
       lea      rdi, [rbp-0x50]
       call     [System.HashCode:Add(int):this]
       mov      r10, bword ptr [rbp-0x80]
       add      r10, 4
       mov      eax, dword ptr [rbp-0x58]
       lea      r11d, [rax-0x04]
       mov      rcx, r10
       mov      dword ptr [rbp-0x68], r11d
 
G_M000_IG107:                ;; offset=0x0919
       mov      bword ptr [rbp-0x88], rcx
       mov      esi, dword ptr [rcx]
       lea      rdi, [rbp-0x50]
       call     [System.HashCode:Add(int):this]
       mov      rcx, bword ptr [rbp-0x88]
       add      rcx, 4
       mov      edx, dword ptr [rbp-0x68]
       add      edx, -4
       mov      rax, rcx
       mov      dword ptr [rbp-0x68], edx
 
G_M000_IG108:                ;; offset=0x0943
       mov      bword ptr [rbp-0x88], rax
       mov      esi, dword ptr [rax]
       lea      rdi, [rbp-0x50]
       call     [System.HashCode:Add(int):this]
       mov      rax, bword ptr [rbp-0x88]
       add      rax, 4
       mov      edx, dword ptr [rbp-0x68]
       add      edx, -4
       mov      r10, rax
       mov      r11d, edx
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rbp-0x78]
       jmp      G_M000_IG09
 
G_M000_IG109:                ;; offset=0x097A
       mov      eax, edx
       xor      edx, edx
       div      edx:eax, edi
       mov      edi, edx
       jmp      G_M000_IG42
 
G_M000_IG110:                ;; offset=0x0987
       cmp      dword ptr [rsi+0x20], 0
       setne    sil
       movzx    rsi, sil
       test     esi, esi
       je       G_M000_IG72
 
G_M000_IG111:                ;; offset=0x099B
       mov      gword ptr [rbp-0x78], rcx
       mov      rsi, rcx
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
       mov      rcx, gword ptr [rbp-0x78]
       jmp      G_M000_IG72
 
G_M000_IG112:                ;; offset=0x09B1
       mov      rcx, gword ptr [rbp-0x78]
       jmp      G_M000_IG70
 
G_M000_IG113:                ;; offset=0x09BA
       cmp      dword ptr [rsi+0x20], 0
       setne    sil
       movzx    rsi, sil
       test     esi, esi
       je       G_M000_IG77
 
G_M000_IG114:                ;; offset=0x09CE
       mov      rsi, gword ptr [rbp-0x78]
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
       jmp      G_M000_IG77
 
G_M000_IG115:                ;; offset=0x09DD
       mov      rcx, gword ptr [rbp-0x78]
       jmp      G_M000_IG70
 
G_M000_IG116:                ;; offset=0x09E6
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
RWD00  	dd	000008C0h ; case G_M000_IG106
       	dd	000008BBh ; case G_M000_IG105
       	dd	000008B6h ; case G_M000_IG104

; Total bytes of code 2540

; Assembly listing for method Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteDictionaryLoop(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool (Tier1)
; Emitting BLENDED_CODE for x64 + VEX on Unix
; Tier1 code
; optimized code
; optimized using Synthesized PGO
; rbp based frame
; fully interruptible
; with Synthesized PGO: fgCalledCount is 353216
; 86 inlinees with PGO data; 212 single block inlinees; 7 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       push     r15
       push     r14
       push     r13
       push     r12
       push     rbx
       sub      rsp, 792
       lea      rbp, [rsp+0x340]
       xor      eax, eax
       mov      qword ptr [rbp-0x178], rax
       vxorps   xmm8, xmm8, xmm8
       vmovdqa  xmmword ptr [rbp-0x170], xmm8
       mov      rax, -288
 
G_M000_IG320:                ;; offset=0x0039
       vmovdqa  xmmword ptr [rbp+rax-0x40], xmm8
       vmovdqa  xmmword ptr [rbp+rax-0x30], xmm8
       vmovdqa  xmmword ptr [rbp+rax-0x20], xmm8
       add      rax, 48
       jne      SHORT G_M000_IG320
       mov      qword ptr [rbp-0x40], rax
       mov      bword ptr [rbp-0x1D8], rdi
       mov      gword ptr [rbp-0x1E0], rsi
       mov      bword ptr [rbp-0x1E8], rcx
       mov      rbx, rdx
 
G_M000_IG02:                ;; offset=0x006D
       mov      r15d, dword ptr [rdi+0x60]
       mov      eax, dword ptr [rcx+0x1C]
       cmp      eax, 51
       ja       SHORT G_M000_IG04
 
G_M000_IG03:                ;; offset=0x0079
       mov      rdx, 0x7FFFFFFFFF9FF
       bt       rdx, rax
       jae      G_M000_IG261
 
G_M000_IG04:                ;; offset=0x008D
       mov      eax, dword ptr [rcx+0x14]
 
G_M000_IG05:                ;; offset=0x0090
       cmp      r15d, eax
       jne      G_M000_IG19
       mov      rdi, bword ptr [rbp-0x1D8]
       cmp      gword ptr [rdi+0x40], 0
       jne      G_M000_IG19
       mov      rax, gword ptr [rdi]
       cmp      byte  ptr [rax+0xDD], 0
       jne      G_M000_IG21
 
G_M000_IG06:                ;; offset=0x00BB
       test     rbx, rbx
       je       G_M000_IG262
 
G_M000_IG07:                ;; offset=0x00C4
       cmp      byte  ptr [rbx+0xFF], 0
       jne      G_M000_IG21
       mov      rax, gword ptr [rbx+0x88]
 
G_M000_IG08:                ;; offset=0x00D8
       test     rax, rax
       sete     r15b
       movzx    r15, r15b
 
G_M000_IG09:                ;; offset=0x00E3
       test     r15d, r15d
       je       G_M000_IG258
       mov      rax, gword ptr [rdi+0x20]
       mov      edx, dword ptr [rcx+0x10]
       cmp      edx, dword ptr [rax+0x08]
       jae      G_M000_IG286
       shl      rdx, 4
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      rdx, gword ptr [rax]
       mov      rsi, 0x7F13B5801408
       cmp      rdx, gword ptr [rsi]
       je       G_M000_IG263
 
G_M000_IG10:                ;; offset=0x011B
       mov      rdx, gword ptr [rax]
       mov      rsi, 0x7F13B5801410
       cmp      rdx, gword ptr [rsi]
       je       G_M000_IG264
       cmp      qword ptr [rax+0x08], 0
       jne      G_M000_IG265
       mov      r14, gword ptr [rax]
 
G_M000_IG11:                ;; offset=0x013F
       test     r14, r14
       je       G_M000_IG266
       mov      rax, 0x7F236096E688
       cmp      qword ptr [r14], rax
       jne      G_M000_IG258
 
G_M000_IG12:                ;; offset=0x015B
       mov      gword ptr [rbp-0x1F0], r14
       mov      rax, gword ptr [rbp-0x1F0]
       mov      rax, gword ptr [rax+0x08]
       mov      rsi, gword ptr [rbp-0x1E0]
       mov      rdx, gword ptr [rsi+0x98]
       cmp      rax, gword ptr [rdx+0x88]
       jne      G_M000_IG258
       mov      rdi, bword ptr [rbp-0x1D8]
       mov      ebx, dword ptr [rdi+0x18]
       mov      dword ptr [rbp-0x2C], ebx
       mov      rcx, bword ptr [rbp-0x1E8]
       cmp      dword ptr [rcx+0x1C], 68
       jne      G_M000_IG267
       mov      r15d, dword ptr [rcx+0x0C]
       mov      rax, gword ptr [rdi]
       mov      rax, gword ptr [rax+0xA0]
       mov      rdx, gword ptr [rdi]
       mov      rdx, gword ptr [rdx+0x88]
       cmp      r15d, dword ptr [rdx+0x08]
       jae      G_M000_IG286
       mov      r8d, r15d
       shl      r8, 5
       lea      rdx, bword ptr [rdx+r8+0x10]
       cmp      dword ptr [rdx+0x1C], 42
       jne      G_M000_IG268
       mov      edx, dword ptr [rdx+0x08]
       mov      r8, 0x7F2360638840
       cmp      qword ptr [rax], r8
       jne      G_M000_IG270
       cmp      dword ptr [rax+0x08], edx
       jbe      G_M000_IG269
       mov      r14, gword ptr [rax+8*rdx+0x10]
 
G_M000_IG13:                ;; offset=0x0202
       mov      gword ptr [rbp-0x1F8], r14
       mov      rdi, bword ptr [rbp-0x1D8]
       mov      rax, gword ptr [rdi]
       mov      rax, gword ptr [rax+0x88]
       mov      rdx, rax
       lea      r13d, [rbx+0x02]
       mov      dword ptr [rbp-0x1AC], r13d
       mov      r8d, dword ptr [rdx+0x08]
       cmp      r13d, r8d
       jae      G_M000_IG286
       mov      r9d, r13d
       shl      r9, 5
       lea      r12, bword ptr [rdx+r9+0x10]
       mov      bword ptr [rbp-0x200], r12
       mov      rdx, rax
       lea      r9d, [r15+0x01]
       cmp      r9d, r8d
       jae      G_M000_IG286
       lea      r9d, [r15+0x01]
       shl      r9, 5
       lea      rdx, bword ptr [rdx+r9+0x10]
       mov      r9, rax
       lea      r10d, [r15+0x02]
       cmp      r10d, r8d
       jae      G_M000_IG286
       lea      r10d, [r15+0x02]
       shl      r10, 5
       lea      r9, bword ptr [r9+r10+0x10]
       mov      bword ptr [rbp-0x208], r9
       mov      r9, gword ptr [rdi]
       mov      r9, gword ptr [r9+0x30]
       mov      r10, r9
       lea      r11d, [rbx+0x04]
       cmp      r11d, r8d
       jae      G_M000_IG286
       mov      r8d, r11d
       shl      r8, 5
       lea      rax, bword ptr [rax+r8+0x10]
       mov      r8d, dword ptr [rax+0x1C]
       cmp      r8d, 35
       jg       G_M000_IG272
       cmp      r8d, 35
       ja       G_M000_IG271
       mov      r11, 0x7FFFFFFBD
       bt       r11, r8
       jb       G_M000_IG271
 
G_M000_IG14:                ;; offset=0x02D8
       mov      eax, dword ptr [rax+0x08]
       cmp      eax, dword ptr [r10+0x08]
       jae      G_M000_IG286
       mov      rax, gword ptr [r10+8*rax+0x10]
       mov      gword ptr [rbp-0x210], rax
       mov      edx, dword ptr [rdx+0x0C]
       not      edx
       cmp      edx, dword ptr [r9+0x08]
       jae      G_M000_IG286
       mov      rdx, gword ptr [r9+8*rdx+0x10]
       mov      gword ptr [rbp-0x238], rdx
       mov      r8, 0x7F2360360018
       cmp      qword ptr [rdx], r8
       je       SHORT G_M000_IG16
 
G_M000_IG15:                ;; offset=0x031B
       mov      rsi, rdx
       mov      rdi, 0x7F2360360018
       call     CORINFO_HELP_UNBOX
       mov      rdx, gword ptr [rbp-0x238]
 
G_M000_IG16:                ;; offset=0x0334
       mov      r8, gword ptr [rdx+0x08]
       mov      gword ptr [rbp-0x2B8], r8
       mov      edx, dword ptr [rdx+0x10]
       mov      dword ptr [rbp-0x17C], edx
       mov      rdi, bword ptr [rbp-0x1D8]
       mov      r9, gword ptr [rdi+0x08]
       mov      r10, bword ptr [rbp-0x208]
       mov      r11d, dword ptr [r10+0x0C]
       cmp      r11d, dword ptr [r9+0x08]
       jae      G_M000_IG286
       shl      r11, 4
       lea      r9, bword ptr [r9+r11+0x10]
       mov      r11, gword ptr [r9]
       mov      rax, 0x7F13B5801408
       cmp      r11, gword ptr [rax]
       je       G_M000_IG273
 
G_M000_IG17:                ;; offset=0x0387
       mov      rax, gword ptr [r9]
       mov      r11, 0x7F13B5801410
       cmp      rax, gword ptr [r11]
       je       G_M000_IG274
       cmp      qword ptr [r9+0x08], 0
       jne      G_M000_IG275
       mov      rax, gword ptr [r9]
 
G_M000_IG18:                ;; offset=0x03AB
       test     rax, rax
       jne      SHORT G_M000_IG22
 
G_M000_IG19:                ;; offset=0x03B0
       xor      eax, eax
 
G_M000_IG20:                ;; offset=0x03B2
       vzeroupper 
       add      rsp, 792
       pop      rbx
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG21:                ;; offset=0x03C7
       xor      r15d, r15d
       jmp      G_M000_IG09
 
G_M000_IG22:                ;; offset=0x03CF
       mov      r9, 0x7F2360640018
       cmp      qword ptr [rax], r9
       jne      SHORT G_M000_IG19
 
G_M000_IG23:                ;; offset=0x03DE
       mov      gword ptr [rbp-0x218], rax
       cmp      gword ptr [rax+0x28], 0
       je       SHORT G_M000_IG19
       cmp      gword ptr [rax+0x30], 0
       je       SHORT G_M000_IG19
       cmp      gword ptr [rax+0x20], 0
       jne      SHORT G_M000_IG19
       cmp      dword ptr [rax+0x50], 0
       jne      SHORT G_M000_IG19
       mov      r9, gword ptr [rax+0x10]
       mov      rsi, gword ptr [rbp-0x1E0]
       mov      r11, gword ptr [rsi+0x98]
       cmp      r9, gword ptr [r11+0x88]
       jne      SHORT G_M000_IG19
       lea      r9d, [r15+0x03]
       mov      dword ptr [rbp-0x30], r9d
       mov      rdi, bword ptr [rbp-0x1D8]
       mov      r11, gword ptr [rdi]
       mov      r11, gword ptr [r11+0x88]
       cmp      r9d, dword ptr [r11+0x08]
       jae      G_M000_IG286
       mov      r10d, r9d
       shl      r10, 5
       lea      r10, bword ptr [r11+r10+0x10]
       mov      bword ptr [rbp-0x220], r10
       mov      r10, bword ptr [rbp-0x220]
       cmp      dword ptr [r10+0x1C], 47
       sete     r11b
       movzx    r11, r11b
       mov      dword ptr [rbp-0x34], r11d
       xor      r10d, r10d
       mov      qword ptr [rbp-0x40], r10
 
G_M000_IG24:                ;; offset=0x0470
       test     r11d, r11d
       je       G_M000_IG31
 
G_M000_IG25:                ;; offset=0x0479
       mov      r10, gword ptr [rdi+0x08]
       mov      r9, bword ptr [rbp-0x220]
       mov      r9d, dword ptr [r9+0x10]
       cmp      r9d, dword ptr [r10+0x08]
       jae      G_M000_IG286
       shl      r9, 4
       lea      r9, bword ptr [r10+r9+0x10]
       mov      bword ptr [rbp-0x248], r9
       mov      r10, gword ptr [r9]
       mov      rdx, 0x7F13B5801408
       cmp      r10, gword ptr [rdx]
       jne      G_M000_IG276
 
G_M000_IG26:                ;; offset=0x04B8
       mov      r9, qword ptr [r9+0x08]
       mov      qword ptr [rbp-0x40], r9
 
G_M000_IG27:                ;; offset=0x04C0
       mov      rdx, 0xFF80000000000000
       cmp      qword ptr [rbp-0x40], rdx
       jl       G_M000_IG19
       mov      rdx, 0x80000000000000
       cmp      qword ptr [rbp-0x40], rdx
       jge      G_M000_IG19
       mov      rdi, bword ptr [rbp-0x1D8]
       mov      rdx, gword ptr [rdi]
       mov      rdx, gword ptr [rdx+0x30]
       mov      r9, bword ptr [rbp-0x220]
       mov      r10d, dword ptr [r9+0x0C]
       not      r10d
       cmp      r10d, dword ptr [rdx+0x08]
       jae      G_M000_IG286
       mov      rdx, gword ptr [rdx+8*r10+0x10]
       mov      gword ptr [rbp-0x240], rdx
       mov      r10, 0x7F2360360018
       cmp      qword ptr [rdx], r10
       je       SHORT G_M000_IG29
 
G_M000_IG28:                ;; offset=0x0529
       mov      rsi, rdx
       mov      rdi, 0x7F2360360018
       call     CORINFO_HELP_UNBOX
       mov      rdx, gword ptr [rbp-0x240]
 
G_M000_IG29:                ;; offset=0x0542
       mov      r10, gword ptr [rdx+0x08]
       mov      edx, dword ptr [rdx+0x10]
       test     r10, r10
       jne      G_M000_IG281
       movsxd   r10, edx
 
G_M000_IG30:                ;; offset=0x0555
       mov      qword ptr [rbp-0x48], r10
       mov      rdi, bword ptr [rbp-0x1D8]
       mov      r10, qword ptr [rbp-0x48]
 
G_M000_IG31:                ;; offset=0x0564
       xor      r9, r9
       mov      bword ptr [rbp-0x2C0], r9
 
G_M000_IG32:                ;; offset=0x056E
       mov      dword ptr [rbp-0x180], r9d
 
G_M000_IG33:                ;; offset=0x0575
       mov      gword ptr [rbp-0x228], r9
 
G_M000_IG34:                ;; offset=0x057C
       mov      dword ptr [rbp-0x4C], r9d
 
G_M000_IG35:                ;; offset=0x0580
       mov      dword ptr [rbp-0x50], r9d
 
G_M000_IG36:                ;; offset=0x0584
       mov      dword ptr [rbp-0x54], r9d
 
G_M000_IG37:                ;; offset=0x0588
       xor      r9, r9
       xor      r11d, r11d
       xor      r8, r8
       mov      gword ptr [rbp-0x230], r8
       mov      rdx, gword ptr [rbp-0x1F0]
       mov      edx, dword ptr [rdx+0x34]
       mov      r12, gword ptr [rbp-0x1F0]
       cmp      edx, dword ptr [r12+0x30]
       je       G_M000_IG158
 
G_M000_IG38:                ;; offset=0x05B4
       mov      rdx, gword ptr [rbp-0x1F0]
       mov      rdx, gword ptr [rdx+0x10]
       test     rdx, rdx
       je       G_M000_IG163
       lea      r12, bword ptr [rdx+0x10]
       mov      edx, dword ptr [rdx+0x08]
       mov      bword ptr [rbp-0x2D0], r12
       mov      qword ptr [rbp-0x48], r10
 
G_M000_IG39:                ;; offset=0x05DA
       mov      r10, gword ptr [rbp-0x1F0]
       add      r10, 52
       mov      r12d, dword ptr [r10]
       add      r12d, 4
       mov      r14d, dword ptr [r10]
       mov      dword ptr [rbp-0x190], edx
       cmp      r14d, edx
       ja       G_M000_IG250
       mov      edx, r14d
       add      rdx, bword ptr [rbp-0x2D0]
       mov      r8d, dword ptr [rbp-0x190]
       sub      r8d, r14d
       cmp      r8d, 4
       jl       G_M000_IG251
       mov      edx, dword ptr [rdx]
       lea      r8d, [r12+rdx]
       mov      dword ptr [r10], r8d
       mov      r8d, dword ptr [r10]
       cmp      edx, 0x1000
       jg       G_M000_IG165
       mov      r9, gword ptr [rbp-0x1F0]
       mov      r11, gword ptr [r9+0x10]
       test     r11, r11
       je       G_M000_IG164
       mov      r8d, r12d
       mov      r9d, edx
       add      r8, r9
       mov      r9d, dword ptr [r11+0x08]
       cmp      r8, r9
       ja       G_M000_IG250
       mov      r8d, r12d
       lea      r9, bword ptr [r11+r8+0x10]
       mov      r11d, edx
 
G_M000_IG40:                ;; offset=0x0669
       mov      bword ptr [rbp-0x2C8], r9
       mov      dword ptr [rbp-0x184], r11d
 
G_M000_IG41:                ;; offset=0x0677
       mov      r14, bword ptr [rbp-0x2C8]
       mov      bword ptr [rbp-0x2C0], r14
       mov      r12d, dword ptr [rbp-0x184]
       mov      dword ptr [rbp-0x180], r12d
       mov      rdx, gword ptr [rbp-0x230]
       mov      gword ptr [rbp-0x228], rdx
       cmp      dword ptr [rbp-0x50], 0
       je       G_M000_IG55
 
G_M000_IG42:                ;; offset=0x06AB
       mov      dword ptr [rdi+0x18], r15d
 
G_M000_IG43:                ;; offset=0x06AF
       mov      rdx, gword ptr [rbp-0x230]
       test     rdx, rdx
       jne      G_M000_IG246
       mov      dword ptr [rbp-0x194], r12d
       mov      r8, gword ptr [rbp-0x1F8]
       mov      r9, gword ptr [r8+0x18]
       mov      gword ptr [rbp-0x250], r9
       mov      rsi, gword ptr [rbp-0x1E0]
       mov      r10, gword ptr [rsi+0x98]
       mov      r11, gword ptr [r10+0x88]
       cmp      gword ptr [r11+0x20], 0
       jne      G_M000_IG169
       mov      r11, gword ptr [r10+0x180]
       test     r11, r11
       jne      G_M000_IG168
 
G_M000_IG44:                ;; offset=0x0708
       mov      rax, gword ptr [rbp-0x218]
       mov      r10, gword ptr [rax+0x28]
       mov      gword ptr [rbp-0x258], r10
       mov      r11d, dword ptr [rax+0x4C]
       mov      dword ptr [rbp-0x6C], r11d
       mov      bword ptr [rbp-0x2D8], r14
       cmp      r11d, 4
       jle      G_M000_IG57
 
G_M000_IG45:                ;; offset=0x0733
       vxorps   ymm0, ymm0, ymm0
       vmovdqu  ymmword ptr [rbp-0xD8], ymm0
       vxorps   ymm0, ymm0, ymm0
       vmovdqu  ymmword ptr [rbp-0xD8], ymm0
       xor      r9d, r9d
 
G_M000_IG46:                ;; offset=0x074E
       mov      dword ptr [rbp-0xDC], r9d
       cmp      r9d, dword ptr [rbp-0x194]
       jl       G_M000_IG72
 
G_M000_IG47:                ;; offset=0x0762
       mov      edx, dword ptr [rbp-0xBC]
       mov      r9d, edx
       and      r9d, 3
       cmp      edx, 4
       jb       G_M000_IG102
 
G_M000_IG48:                ;; offset=0x0778
       rorx     r8d, dword ptr [rbp-0xD8], 31
       rorx     r13d, dword ptr [rbp-0xD4], 25
       add      r8d, r13d
       rorx     r13d, dword ptr [rbp-0xD0], 20
       add      r8d, r13d
       rorx     r13d, dword ptr [rbp-0xCC], 14
       add      r8d, r13d
 
G_M000_IG49:                ;; offset=0x07A9
       lea      edx, [r8+4*rdx]
       test     r9d, r9d
       jne      G_M000_IG103
 
G_M000_IG50:                ;; offset=0x07B6
       mov      r8d, edx
       shr      r8d, 15
       xor      r8d, edx
       imul     edx, r8d, 0xFFFFFFFF85EBCA77
       mov      r8d, edx
       shr      r8d, 13
       xor      r8d, edx
       imul     edx, r8d, 0xFFFFFFFFC2B2AE3D
       mov      r8d, edx
       shr      r8d, 16
       xor      edx, r8d
       cmp      edx, -1
       je       G_M000_IG197
 
G_M000_IG51:                ;; offset=0x07EB
       mov      r8d, edx
       shr      r8d, 16
       xor      r8d, edx
       imul     r8d, r8d, 0xFFFFFFFF9E3779B9
       mov      edx, r8d
       shr      edx, 16
       xor      r8d, edx
       test     r11d, r11d
       je       G_M000_IG198
 
G_M000_IG52:                ;; offset=0x080E
       mov      r9d, dword ptr [r10+0x08]
       lea      r11d, [r9-0x01]
       test     r9d, r11d
       jne      G_M000_IG199
       and      r11d, r8d
 
G_M000_IG53:                ;; offset=0x0822
       cmp      r11d, dword ptr [r10+0x08]
       jae      G_M000_IG255
       mov      edx, r11d
       lea      rdx, [rdx+4*rdx]
       mov      edx, dword ptr [r10+8*rdx+0x30]
       dec      edx
       mov      dword ptr [rbp-0x70], edx
       test     edx, edx
       jge      G_M000_IG115
 
G_M000_IG54:                ;; offset=0x0845
       mov      edx, -1
       mov      dword ptr [rbp-0x64], r8d
       jmp      G_M000_IG131
 
G_M000_IG55:                ;; offset=0x0853
       mov      r8, bword ptr [rbp-0x200]
       mov      r9, gword ptr [r8]
       mov      rsi, gword ptr [rbp-0x1E0]
       mov      r10, gword ptr [rsi+0x98]
       mov      r11, gword ptr [r10+0x88]
       cmp      gword ptr [r11+0x20], 0
       jne      G_M000_IG167
       mov      r11, gword ptr [r10+0x180]
       test     r11, r11
       jne      G_M000_IG166
 
G_M000_IG56:                ;; offset=0x088D
       mov      dword ptr [rdi+0x18], r15d
       mov      r9, gword ptr [rbp-0x1F8]
       mov      r10, gword ptr [r9+0x18]
       mov      rsi, gword ptr [rbp-0x1E0]
       mov      rdi, gword ptr [rsi+0x98]
       mov      rsi, r10
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.ExecutionState:EnterInterpreterFrame(Lokad.Lython.LythonSourceSpan):this]
       mov      dword ptr [rbp-0x50], 1
       jmp      G_M000_IG43
 
G_M000_IG57:                ;; offset=0x08C1
       cmp      dword ptr [rbp-0x194], 8
       jg       G_M000_IG45
 
G_M000_IG58:                ;; offset=0x08CE
       xor      r8d, r8d
       xor      r9d, r9d
       test     r11d, r11d
       jle      G_M000_IG170
       jmp      SHORT G_M000_IG61
 
G_M000_IG59:                ;; offset=0x08DF
       inc      r9d
       cmp      r9d, r11d
       jge      G_M000_IG54
 
G_M000_IG60:                ;; offset=0x08EB
       mov      r10, gword ptr [rbp-0x258]
 
G_M000_IG61:                ;; offset=0x08F2
       cmp      r9d, dword ptr [r10+0x08]
       jae      G_M000_IG255
       lea      rdx, [r9+4*r9]
       mov      rdx, gword ptr [r10+8*rdx+0x10]
       test     rdx, rdx
       je       SHORT G_M000_IG59
 
G_M000_IG62:                ;; offset=0x090A
       mov      r13, 0x7F23603BFBC0
       cmp      qword ptr [rdx], r13
       jne      SHORT G_M000_IG59
 
G_M000_IG63:                ;; offset=0x0919
       movzx    r13, byte  ptr [rdx+0x24]
       test     r13d, r13d
       je       G_M000_IG171
 
G_M000_IG64:                ;; offset=0x0927
       cmp      r13d, 255
       je       G_M000_IG106
 
G_M000_IG65:                ;; offset=0x0934
       lea      r13, bword ptr [rdx+0x28]
       mov      edx, dword ptr [rdx+0x18]
       cmp      edx, 8
       ja       G_M000_IG250
 
G_M000_IG66:                ;; offset=0x0944
       mov      dword ptr [rbp-0x198], edx
       cmp      dword ptr [rbp-0x194], edx
       jne      SHORT G_M000_IG59
 
G_M000_IG67:                ;; offset=0x0952
       mov      bword ptr [rbp-0x268], r14
       mov      bword ptr [rbp-0x270], r13
       mov      edx, dword ptr [rbp-0x198]
       cmp      rdx, 8
       jae      G_M000_IG108
 
G_M000_IG68:                ;; offset=0x0970
       cmp      rdx, 4
       jb       G_M000_IG176
 
G_M000_IG69:                ;; offset=0x097A
       add      rdx, -4
       mov      qword ptr [rbp-0xA8], rdx
       mov      edx, dword ptr [r14]
       sub      edx, dword ptr [r13]
       mov      dword ptr [rbp-0x31C], edx
       mov      rdx, qword ptr [rbp-0xA8]
       mov      edx, dword ptr [r14+rdx]
       mov      rbx, qword ptr [rbp-0xA8]
       sub      edx, dword ptr [rbx+r13]
       or       edx, dword ptr [rbp-0x31C]
       sete     dl
       movzx    rdx, dl
 
G_M000_IG70:                ;; offset=0x09B4
       test     edx, edx
       je       G_M000_IG59
 
G_M000_IG71:                ;; offset=0x09BC
       mov      edx, r9d
       mov      dword ptr [rbp-0x64], r8d
       jmp      G_M000_IG131
 
G_M000_IG72:                ;; offset=0x09C8
       mov      rsi, gword ptr [rbp-0x1E0]
       mov      r8, gword ptr [rsi+0x98]
       mov      r13, gword ptr [r8+0x88]
       cmp      gword ptr [r13+0x20], 0
       jne      G_M000_IG192
       mov      r13, gword ptr [r8+0x180]
       test     r13, r13
       jne      G_M000_IG191
 
G_M000_IG73:                ;; offset=0x09F8
       mov      edx, dword ptr [rbp-0x194]
       mov      r9d, dword ptr [rbp-0xDC]
       mov      r13d, edx
       sub      r13d, r9d
       cmp      r13d, 0x1000
       jge      G_M000_IG78
 
G_M000_IG74:                ;; offset=0x0A18
       mov      dword ptr [rbp-0xE0], r13d
       mov      dword ptr [rbp-0xDC], r9d
       mov      r8d, r9d
       mov      qword ptr [rbp-0x1B8], r8
       mov      r8d, r13d
       add      r8, qword ptr [rbp-0x1B8]
       mov      ebx, edx
       cmp      r8, rbx
       ja       G_M000_IG250
       mov      r8, qword ptr [rbp-0x1B8]
       add      r8, bword ptr [rbp-0x2D8]
       mov      bword ptr [rbp-0x2E8], r8
       mov      rbx, r8
       mov      r8d, r13d
       cmp      r8d, 16
       jl       G_M000_IG89
 
G_M000_IG75:                ;; offset=0x0A6A
       cmp      dword ptr [rbp-0xBC], 0
       jne      G_M000_IG193
       mov      r9, 0xA13CEA793F74642A
       mov      qword ptr [rbp-0xD8], r9
       mov      r9, 0x7D19A6511B512002
       mov      qword ptr [rbp-0xD0], r9
 
G_M000_IG76:                ;; offset=0x0A99
       cmp      r8d, 16
       jl       G_M000_IG89
 
G_M000_IG77:                ;; offset=0x0AA3
       mov      r9d, dword ptr [rbp-0xD8]
       imul     r13d, dword ptr [rbx], 0xFFFFFFFF85EBCA77
       add      r9d, r13d
       rol      r9d, 13
       imul     r9d, r9d, 0xFFFFFFFF9E3779B1
       mov      dword ptr [rbp-0xD8], r9d
       mov      r9d, dword ptr [rbp-0xD4]
       lea      r13, bword ptr [rbx+0x04]
       imul     r13d, dword ptr [r13], 0xFFFFFFFF85EBCA77
       add      r9d, r13d
       rol      r9d, 13
       imul     r9d, r9d, 0xFFFFFFFF9E3779B1
       mov      dword ptr [rbp-0xD4], r9d
       mov      r9d, dword ptr [rbp-0xD0]
       lea      r13, bword ptr [rbx+0x08]
       imul     r13d, dword ptr [r13], 0xFFFFFFFF85EBCA77
       add      r9d, r13d
       rol      r9d, 13
       imul     r9d, r9d, 0xFFFFFFFF9E3779B1
       mov      dword ptr [rbp-0xD0], r9d
       mov      r9d, dword ptr [rbp-0xCC]
       lea      r13, bword ptr [rbx+0x0C]
       imul     r13d, dword ptr [r13], 0xFFFFFFFF85EBCA77
       add      r9d, r13d
       rol      r9d, 13
       imul     r9d, r9d, 0xFFFFFFFF9E3779B1
       mov      dword ptr [rbp-0xCC], r9d
       mov      r9d, dword ptr [rbp-0xBC]
       add      r9d, 4
       mov      dword ptr [rbp-0xBC], r9d
       add      rbx, 16
       add      r8d, -16
       mov      r13d, r8d
       mov      r8d, r13d
       jmp      G_M000_IG76
 
G_M000_IG78:                ;; offset=0x0B63
       mov      r13d, 0x1000
       jmp      G_M000_IG74
 
G_M000_IG79:                ;; offset=0x0B6E
       mov      r9d, dword ptr [rbx]
       mov      dword ptr [rbp-0xE4], r9d
       mov      r9d, dword ptr [rbp-0xBC]
       mov      dword ptr [rbp-0xE8], r9d
       inc      r9d
       mov      dword ptr [rbp-0xBC], r9d
       mov      r9d, dword ptr [rbp-0xE8]
       and      r9d, 3
       je       G_M000_IG87
 
G_M000_IG80:                ;; offset=0x0BA1
       cmp      r9d, 1
       jne      SHORT G_M000_IG82
 
G_M000_IG81:                ;; offset=0x0BA7
       mov      r9d, dword ptr [rbp-0xE4]
       mov      dword ptr [rbp-0xC4], r9d
       jmp      G_M000_IG88
 
G_M000_IG82:                ;; offset=0x0BBA
       cmp      r9d, 2
       jne      SHORT G_M000_IG84
 
G_M000_IG83:                ;; offset=0x0BC0
       mov      r9d, dword ptr [rbp-0xE4]
       mov      dword ptr [rbp-0xC0], r9d
       jmp      G_M000_IG88
 
G_M000_IG84:                ;; offset=0x0BD3
       cmp      dword ptr [rbp-0xE8], 3
       jne      SHORT G_M000_IG86
 
G_M000_IG85:                ;; offset=0x0BDC
       mov      r9, 0xA13CEA793F74642A
       mov      qword ptr [rbp-0xD8], r9
       mov      r9, 0x7D19A6511B512002
       mov      qword ptr [rbp-0xD0], r9
 
G_M000_IG86:                ;; offset=0x0BFE
       imul     r9d, dword ptr [rbp-0xC8], 0xFFFFFFFF85EBCA77
       add      r9d, dword ptr [rbp-0xD8]
       rol      r9d, 13
       imul     r9d, r9d, 0xFFFFFFFF9E3779B1
       mov      dword ptr [rbp-0xD8], r9d
       imul     r9d, dword ptr [rbp-0xC4], 0xFFFFFFFF85EBCA77
       add      r9d, dword ptr [rbp-0xD4]
       rol      r9d, 13
       imul     r9d, r9d, 0xFFFFFFFF9E3779B1
       mov      dword ptr [rbp-0xD4], r9d
       imul     r9d, dword ptr [rbp-0xC0], 0xFFFFFFFF85EBCA77
       add      r9d, dword ptr [rbp-0xD0]
       rol      r9d, 13
       imul     r9d, r9d, 0xFFFFFFFF9E3779B1
       mov      dword ptr [rbp-0xD0], r9d
       imul     r9d, dword ptr [rbp-0xE4], 0xFFFFFFFF85EBCA77
       add      r9d, dword ptr [rbp-0xCC]
       rol      r9d, 13
       imul     r9d, r9d, 0xFFFFFFFF9E3779B1
       mov      dword ptr [rbp-0xCC], r9d
       jmp      SHORT G_M000_IG88
 
G_M000_IG87:                ;; offset=0x0C90
       mov      r9d, dword ptr [rbp-0xE4]
       mov      dword ptr [rbp-0xC8], r9d
 
G_M000_IG88:                ;; offset=0x0C9E
       add      rbx, 4
       add      r8d, -4
 
G_M000_IG89:                ;; offset=0x0CA6
       cmp      r8d, 4
       jge      G_M000_IG79
 
G_M000_IG90:                ;; offset=0x0CB0
       mov      r9, rbx
       mov      bword ptr [rbp-0x2F0], r9
       xor      ebx, ebx
       test     r8d, r8d
       jne      G_M000_IG99
 
G_M000_IG91:                ;; offset=0x0CC5
       mov      ebx, dword ptr [rbp-0xDC]
       add      ebx, dword ptr [rbp-0xE0]
       mov      r9d, ebx
       jmp      G_M000_IG46
 
G_M000_IG92:                ;; offset=0x0CD9
       cmp      r9d, 2
       jne      SHORT G_M000_IG94
 
G_M000_IG93:                ;; offset=0x0CDF
       mov      r9d, dword ptr [rbp-0xEC]
       mov      dword ptr [rbp-0xC0], r9d
       jmp      G_M000_IG98
 
G_M000_IG94:                ;; offset=0x0CF2
       cmp      dword ptr [rbp-0xF0], 3
       jne      SHORT G_M000_IG96
 
G_M000_IG95:                ;; offset=0x0CFB
       mov      r9, 0xA13CEA793F74642A
       mov      qword ptr [rbp-0xD8], r9
       mov      r9, 0x7D19A6511B512002
       mov      qword ptr [rbp-0xD0], r9
 
G_M000_IG96:                ;; offset=0x0D1D
       imul     r9d, dword ptr [rbp-0xC8], 0xFFFFFFFF85EBCA77
       add      r9d, dword ptr [rbp-0xD8]
       rol      r9d, 13
       imul     r9d, r9d, 0xFFFFFFFF9E3779B1
       mov      dword ptr [rbp-0xD8], r9d
       imul     r9d, dword ptr [rbp-0xC4], 0xFFFFFFFF85EBCA77
       add      r9d, dword ptr [rbp-0xD4]
       rol      r9d, 13
       imul     r9d, r9d, 0xFFFFFFFF9E3779B1
       mov      dword ptr [rbp-0xD4], r9d
       imul     r9d, dword ptr [rbp-0xC0], 0xFFFFFFFF85EBCA77
       add      r9d, dword ptr [rbp-0xD0]
       rol      r9d, 13
       imul     r9d, r9d, 0xFFFFFFFF9E3779B1
       mov      dword ptr [rbp-0xD0], r9d
       imul     r9d, dword ptr [rbp-0xEC], 0xFFFFFFFF85EBCA77
       add      r9d, dword ptr [rbp-0xCC]
       rol      r9d, 13
       imul     r9d, r9d, 0xFFFFFFFF9E3779B1
       mov      dword ptr [rbp-0xCC], r9d
       jmp      SHORT G_M000_IG98
 
G_M000_IG97:                ;; offset=0x0DAF
       mov      r9d, dword ptr [rbp-0xEC]
       mov      dword ptr [rbp-0xC8], r9d
 
G_M000_IG98:                ;; offset=0x0DBD
       inc      ebx
       cmp      ebx, r8d
       mov      r9, bword ptr [rbp-0x2F0]
       jge      G_M000_IG91
 
G_M000_IG99:                ;; offset=0x0DCF
       movzx    r9, byte  ptr [r9+rbx]
       mov      dword ptr [rbp-0xEC], r9d
       mov      r9d, dword ptr [rbp-0xBC]
       mov      dword ptr [rbp-0xF0], r9d
       inc      r9d
       mov      dword ptr [rbp-0xBC], r9d
       mov      r9d, dword ptr [rbp-0xF0]
       and      r9d, 3
       je       SHORT G_M000_IG97
 
G_M000_IG100:                ;; offset=0x0E00
       cmp      r9d, 1
       jne      G_M000_IG92
 
G_M000_IG101:                ;; offset=0x0E0A
       mov      r9d, dword ptr [rbp-0xEC]
       mov      dword ptr [rbp-0xC4], r9d
       jmp      SHORT G_M000_IG98
 
G_M000_IG102:                ;; offset=0x0E1A
       mov      r8d, 0x31A787B3
       jmp      G_M000_IG49
 
G_M000_IG103:                ;; offset=0x0E25
       imul     r8d, dword ptr [rbp-0xC8], 0xFFFFFFFFC2B2AE3D
       add      edx, r8d
       rol      edx, 17
       imul     edx, edx, 0x27D4EB2F
       cmp      r9d, 1
       jbe      G_M000_IG50
 
G_M000_IG104:                ;; offset=0x0E46
       imul     r8d, dword ptr [rbp-0xC4], 0xFFFFFFFFC2B2AE3D
       add      r8d, edx
       rol      r8d, 17
       imul     edx, r8d, 0x27D4EB2F
       cmp      r9d, 2
       jbe      G_M000_IG50
 
G_M000_IG105:                ;; offset=0x0E69
       imul     r8d, dword ptr [rbp-0xC0], 0xFFFFFFFFC2B2AE3D
       add      r8d, edx
       rol      r8d, 17
       imul     edx, r8d, 0x27D4EB2F
       jmp      G_M000_IG50
 
G_M000_IG106:                ;; offset=0x0E87
       mov      r13, gword ptr [rdx+0x08]
       mov      gword ptr [rbp-0x260], r13
       lea      r13, bword ptr [rdx+0x28]
       mov      r13d, dword ptr [r13]
       mov      edx, dword ptr [rdx+0x18]
       mov      dword ptr [rbp-0x74], edx
       cmp      gword ptr [rbp-0x260], 0
       je       G_M000_IG175
       mov      qword ptr [rbp-0x1C0], r13
       mov      r13d, edx
       add      r13, qword ptr [rbp-0x1C0]
       mov      qword ptr [rbp-0x324], r13
       mov      r13, gword ptr [rbp-0x260]
       mov      r13d, dword ptr [r13+0x08]
       cmp      qword ptr [rbp-0x324], r13
       ja       G_M000_IG250
       mov      r13, gword ptr [rbp-0x260]
       mov      rdx, qword ptr [rbp-0x1C0]
       lea      r13, bword ptr [r13+rdx+0x10]
       mov      edx, dword ptr [rbp-0x74]
 
G_M000_IG107:                ;; offset=0x0EF4
       jmp      G_M000_IG66
 
G_M000_IG108:                ;; offset=0x0EF9
       mov      bword ptr [rbp-0x2E0], r13
       mov      r13, bword ptr [rbp-0x268]
       cmp      r13, bword ptr [rbp-0x270]
       je       G_M000_IG189
       cmp      rdx, 32
       jae      G_M000_IG181
 
G_M000_IG109:                ;; offset=0x0F1E
       cmp      rdx, 16
       jae      G_M000_IG185
 
G_M000_IG110:                ;; offset=0x0F28
       add      rdx, -8
       mov      qword ptr [rbp-0x80], rdx
       mov      r13, qword ptr [r14]
       mov      rdx, bword ptr [rbp-0x2E0]
       sub      r13, qword ptr [rdx]
       mov      qword ptr [rbp-0x324], r13
       mov      r13, qword ptr [rbp-0x80]
       mov      r13, qword ptr [r14+r13]
       mov      rbx, qword ptr [rbp-0x80]
       sub      r13, qword ptr [rdx+rbx]
       or       r13, qword ptr [rbp-0x324]
       sete     dl
       movzx    rdx, dl
       jmp      G_M000_IG70
 
G_M000_IG111:                ;; offset=0x0F66
       cmp      eax, 56
       je       G_M000_IG161
 
G_M000_IG112:                ;; offset=0x0F6F
       cmp      eax, 62
       je       G_M000_IG161
       add      eax, -68
       cmp      eax, 1
       ja       G_M000_IG254
       jmp      G_M000_IG161
 
G_M000_IG113:                ;; offset=0x0F89
       mov      r10, gword ptr [rbp-0x258]
 
G_M000_IG114:                ;; offset=0x0F90
       mov      r11, bword ptr [rbp-0x318]
       mov      edx, dword ptr [r11+0x1C]
       dec      edx
       mov      dword ptr [rbp-0x70], edx
       mov      r8d, dword ptr [rbp-0x64]
       js       G_M000_IG54
 
G_M000_IG115:                ;; offset=0x0FAA
       mov      rsi, gword ptr [rbp-0x1E0]
       mov      r9, gword ptr [rsi+0x98]
       mov      r11, gword ptr [r9+0x88]
       cmp      gword ptr [r11+0x20], 0
       jne      G_M000_IG201
       mov      r11, gword ptr [r9+0x180]
       test     r11, r11
       jne      G_M000_IG200
 
G_M000_IG116:                ;; offset=0x0FDA
       mov      edx, dword ptr [rbp-0x70]
       mov      r10, gword ptr [rbp-0x258]
       cmp      edx, dword ptr [r10+0x08]
       jae      G_M000_IG255
       mov      dword ptr [rbp-0x70], edx
       mov      r9d, edx
       lea      r9, [r9+4*r9]
       lea      r11, bword ptr [r10+8*r9+0x10]
       mov      bword ptr [rbp-0x318], r11
       mov      dword ptr [rbp-0x64], r8d
       cmp      dword ptr [r11+0x18], r8d
       jne      SHORT G_M000_IG114
 
G_M000_IG117:                ;; offset=0x100E
       mov      r9, gword ptr [r10+8*r9+0x10]
       test     r9, r9
       je       G_M000_IG113
 
G_M000_IG118:                ;; offset=0x101C
       mov      r13, 0x7F23603BFBC0
       cmp      qword ptr [r9], r13
       jne      G_M000_IG150
 
G_M000_IG119:                ;; offset=0x102F
       movzx    r13, byte  ptr [r9+0x24]
       test     r13d, r13d
       je       G_M000_IG203
 
G_M000_IG120:                ;; offset=0x103D
       cmp      r13d, 255
       je       G_M000_IG144
 
G_M000_IG121:                ;; offset=0x104A
       lea      r13, bword ptr [r9+0x28]
       mov      r9d, dword ptr [r9+0x18]
       cmp      r9d, 8
       ja       G_M000_IG250
 
G_M000_IG122:                ;; offset=0x105C
       mov      bword ptr [rbp-0x2F8], r13
       mov      dword ptr [rbp-0x1A0], r9d
       cmp      r9d, r12d
       jne      G_M000_IG208
       xor      r13d, r13d
       cmp      r13d, r12d
       jge      G_M000_IG130
 
G_M000_IG123:                ;; offset=0x107F
       mov      rsi, gword ptr [rbp-0x1E0]
       mov      r9, gword ptr [rsi+0x98]
       mov      rbx, gword ptr [r9+0x88]
       cmp      gword ptr [rbx+0x20], 0
       jne      G_M000_IG210
       mov      rbx, gword ptr [r9+0x180]
       test     rbx, rbx
       jne      G_M000_IG209
 
G_M000_IG124:                ;; offset=0x10AF
       mov      r9d, r12d
       sub      r9d, r13d
       cmp      r9d, 0x1000
       jge      G_M000_IG146
 
G_M000_IG125:                ;; offset=0x10C2
       mov      dword ptr [rbp-0xF4], r9d
       mov      ebx, r13d
       mov      r9d, r9d
       mov      qword ptr [rbp-0x1D0], r9
       add      r9, rbx
       mov      qword ptr [rbp-0x1A8], r9
       mov      r9d, r12d
       cmp      qword ptr [rbp-0x1A8], r9
       ja       G_M000_IG250
       lea      r9, bword ptr [r14+rbx]
       mov      bword ptr [rbp-0x300], r9
       mov      r9d, dword ptr [rbp-0x1A0]
       cmp      qword ptr [rbp-0x1A8], r9
       ja       G_M000_IG250
       add      rbx, bword ptr [rbp-0x2F8]
       mov      bword ptr [rbp-0x308], rbx
       mov      r9, bword ptr [rbp-0x300]
       mov      bword ptr [rbp-0x280], r9
       mov      bword ptr [rbp-0x288], rbx
       mov      r9, qword ptr [rbp-0x1D0]
       cmp      r9, 8
       jae      G_M000_IG147
 
G_M000_IG126:                ;; offset=0x1143
       cmp      r9, 4
       jb       G_M000_IG211
 
G_M000_IG127:                ;; offset=0x114D
       add      r9, -4
       mov      qword ptr [rbp-0x128], r9
       mov      r9, bword ptr [rbp-0x300]
       mov      r9d, dword ptr [r9]
       sub      r9d, dword ptr [rbx]
       mov      dword ptr [rbp-0x31C], r9d
       mov      r9, bword ptr [rbp-0x300]
       mov      rbx, qword ptr [rbp-0x128]
       mov      r9d, dword ptr [r9+rbx]
       mov      r8, bword ptr [rbp-0x308]
       sub      r9d, dword ptr [r8+rbx]
       or       r9d, dword ptr [rbp-0x31C]
       sete     r9b
       movzx    r9, r9b
 
G_M000_IG128:                ;; offset=0x1198
       test     r9d, r9d
       je       G_M000_IG216
 
G_M000_IG129:                ;; offset=0x11A1
       add      r13d, dword ptr [rbp-0xF4]
       cmp      r13d, r12d
       jl       G_M000_IG123
 
G_M000_IG130:                ;; offset=0x11B1
       mov      edx, dword ptr [rbp-0x70]
 
G_M000_IG131:                ;; offset=0x11B4
       mov      byte  ptr [rbp-0x188], 0
       xor      r11d, r11d
       mov      dword ptr [rbp-0x18C], r11d
       test     edx, edx
       jl       G_M000_IG152
 
G_M000_IG132:                ;; offset=0x11CD
       mov      r10, gword ptr [rbp-0x258]
       cmp      edx, dword ptr [r10+0x08]
       jae      G_M000_IG255
       mov      r8d, edx
       lea      r8, [r8+4*r8]
       lea      r10, bword ptr [r10+8*r8+0x10]
       mov      dword ptr [rbp-0x68], edx
       mov      r11d, edx
       mov      dword ptr [rbp-0x13C], r11d
       mov      r13, gword ptr [r10]
       mov      r9, r13
       test     r9, r9
       je       SHORT G_M000_IG134
 
G_M000_IG133:                ;; offset=0x1202
       mov      rbx, 0x7F23603BFBC0
       cmp      qword ptr [r9], rbx
       jne      G_M000_IG232
 
G_M000_IG134:                ;; offset=0x1215
       mov      gword ptr [rbp-0x290], r9
       mov      r9d, dword ptr [r10+0x18]
       mov      dword ptr [rbp-0x16C], r9d
       vxorps   xmm0, xmm0, xmm0
       vmovdqu  xmmword ptr [rbp-0x150], xmm0
       mov      rax, gword ptr [rbp-0x218]
       cmp      gword ptr [rax+0x20], 0
       jne      G_M000_IG233
       mov      r10, gword ptr [rax+0x30]
       cmp      r11d, dword ptr [r10+0x08]
       jae      G_M000_IG255
       mov      r13d, r11d
       cmp      gword ptr [r10+8*r13+0x10], 0
       jne      G_M000_IG233
 
G_M000_IG135:                ;; offset=0x1262
       mov      r10, gword ptr [rax+0x28]
       cmp      r11d, dword ptr [r10+0x08]
       jae      G_M000_IG255
       mov      r13, qword ptr [r10+8*r8+0x20]
       mov      r8, 0xFF80000000000000
       cmp      r13, r8
       jl       G_M000_IG235
       mov      r8, 0x80000000000000
       cmp      r13, r8
       jge      G_M000_IG235
 
G_M000_IG136:                ;; offset=0x129B
       mov      rdi, gword ptr [rbp-0x2B8]
       mov      esi, dword ptr [rbp-0x17C]
       call     [System.Numerics.BigInteger:op_Explicit(System.Numerics.BigInteger):long]
       lea      rsi, [rax+r13]
       mov      r13, gword ptr [rbp-0x218]
       mov      eax, dword ptr [r13+0x4C]
       mov      dword ptr [rbp-0x154], eax
       cmp      gword ptr [r13+0x20], 0
       jne      G_M000_IG244
       mov      rdi, gword ptr [r13+0x28]
       mov      r11d, dword ptr [rbp-0x13C]
       cmp      r11d, dword ptr [rdi+0x08]
       jae      G_M000_IG255
       mov      ecx, r11d
       lea      rcx, [rcx+4*rcx]
       mov      qword ptr [rdi+8*rcx+0x20], rsi
       mov      rdi, gword ptr [r13+0x30]
       cmp      r11d, dword ptr [rdi+0x08]
       jae      G_M000_IG255
       mov      esi, r11d
       xor      rcx, rcx
       mov      gword ptr [rdi+8*rsi+0x10], rcx
 
G_M000_IG137:                ;; offset=0x1307
       mov      eax, dword ptr [rbp-0x154]
       cmp      dword ptr [r13+0x4C], eax
       jne      G_M000_IG151
 
G_M000_IG138:                ;; offset=0x1317
       mov      eax, 1
 
G_M000_IG139:                ;; offset=0x131C
       movzx    r9, byte  ptr [rbp-0x188]
       test     r9d, r9d
       jne      G_M000_IG156
 
G_M000_IG140:                ;; offset=0x132D
       test     eax, eax
       je       G_M000_IG252
 
G_M000_IG141:                ;; offset=0x1335
       cmp      dword ptr [rbp-0x34], 0
       je       SHORT G_M000_IG143
 
G_M000_IG142:                ;; offset=0x133B
       mov      rdx, qword ptr [rbp-0x48]
       mov      r8, rdx
       add      r8, qword ptr [rbp-0x40]
       mov      qword ptr [rbp-0x40], r8
       mov      dword ptr [rbp-0x4C], 1
       mov      r8, 0xFF80000000000000
       cmp      qword ptr [rbp-0x40], r8
       jl       G_M000_IG253
       mov      r8, 0x80000000000000
       cmp      qword ptr [rbp-0x40], r8
       jge      G_M000_IG253
 
G_M000_IG143:                ;; offset=0x1379
       mov      rdi, bword ptr [rbp-0x1D8]
       mov      ebx, dword ptr [rbp-0x2C]
       mov      dword ptr [rdi+0x18], ebx
       mov      rcx, bword ptr [rbp-0x1E8]
       mov      r8, gword ptr [rcx]
       mov      rsi, gword ptr [rbp-0x1E0]
       mov      r9, gword ptr [rsi+0x98]
       mov      r10, gword ptr [r9+0x88]
       cmp      gword ptr [r10+0x20], 0
       jne      G_M000_IG248
       mov      r10, gword ptr [r9+0x180]
       test     r10, r10
       mov      gword ptr [rbp-0x310], r10
       mov      gword ptr [rbp-0x2B0], r8
       mov      rdi, bword ptr [rbp-0x1D8]
       jne      G_M000_IG247
       mov      r10, qword ptr [rbp-0x48]
       jmp      G_M000_IG37
 
G_M000_IG144:                ;; offset=0x13DE
       mov      r13, gword ptr [r9+0x08]
       mov      gword ptr [rbp-0x278], r13
       lea      r13, bword ptr [r9+0x28]
       mov      r13d, dword ptr [r13]
       mov      r9d, dword ptr [r9+0x18]
       mov      dword ptr [rbp-0xF8], r9d
       cmp      gword ptr [rbp-0x278], 0
       je       G_M000_IG207
       mov      qword ptr [rbp-0x1C8], r13
       mov      r13d, r9d
       add      r13, qword ptr [rbp-0x1C8]
       mov      qword ptr [rbp-0x324], r13
       mov      r13, gword ptr [rbp-0x278]
       mov      r13d, dword ptr [r13+0x08]
       cmp      qword ptr [rbp-0x324], r13
       ja       G_M000_IG250
       mov      r13, gword ptr [rbp-0x278]
       mov      r9, qword ptr [rbp-0x1C8]
       lea      r13, bword ptr [r13+r9+0x10]
       mov      r9d, dword ptr [rbp-0xF8]
 
G_M000_IG145:                ;; offset=0x1454
       jmp      G_M000_IG122
 
G_M000_IG146:                ;; offset=0x1459
       mov      r9d, 0x1000
       jmp      G_M000_IG125
 
G_M000_IG147:                ;; offset=0x1464
       mov      rbx, bword ptr [rbp-0x280]
       cmp      rbx, bword ptr [rbp-0x288]
       je       G_M000_IG129
       cmp      r9, 32
       jae      G_M000_IG217
 
G_M000_IG148:                ;; offset=0x1482
       cmp      r9, 16
       jae      G_M000_IG225
 
G_M000_IG149:                ;; offset=0x148C
       add      r9, -8
       mov      qword ptr [rbp-0x100], r9
       mov      rbx, bword ptr [rbp-0x300]
       mov      r9, qword ptr [rbx]
       mov      rbx, bword ptr [rbp-0x308]
       sub      r9, qword ptr [rbx]
       mov      qword ptr [rbp-0x324], r9
       mov      r9, bword ptr [rbp-0x300]
       mov      rbx, qword ptr [rbp-0x100]
       mov      r9, qword ptr [r9+rbx]
       mov      r8, bword ptr [rbp-0x308]
       sub      r9, qword ptr [r8+rbx]
       or       r9, qword ptr [rbp-0x324]
       sete     r9b
       movzx    r9, r9b
       jmp      G_M000_IG128
 
G_M000_IG150:                ;; offset=0x14E3
       mov      r10, gword ptr [rbp-0x258]
       jmp      G_M000_IG114
 
G_M000_IG151:                ;; offset=0x14EF
       inc      dword ptr [r13+0x48]
       jmp      G_M000_IG138
 
G_M000_IG152:                ;; offset=0x14F8
       cmp      r12d, 8
       jle      G_M000_IG231
 
G_M000_IG153:                ;; offset=0x1502
       mov      rax, gword ptr [rbp-0x218]
       mov      edx, dword ptr [rax+0x4C]
       mov      r10, gword ptr [rbp-0x258]
       cmp      edx, dword ptr [r10+0x08]
       jge      SHORT G_M000_IG155
 
G_M000_IG154:                ;; offset=0x1519
       mov      r9d, 1
       mov      r8d, dword ptr [rbp-0x64]
       mov      dword ptr [rbp-0x18C], r8d
       mov      dword ptr [rbp-0x188], r9d
 
G_M000_IG155:                ;; offset=0x1531
       xor      edx, edx
       mov      r13, rax
       mov      eax, edx
       jmp      G_M000_IG139
 
G_M000_IG156:                ;; offset=0x153D
       mov      rdx, gword ptr [rbp-0x1F8]
       mov      rax, gword ptr [rdx+0x18]
       mov      gword ptr [rbp-0x2A0], rax
       mov      rsi, gword ptr [rbp-0x1E0]
       mov      r8, gword ptr [rsi+0x98]
       mov      gword ptr [rbp-0x2A8], r8
       cmp      byte  ptr [r8], r8b
       mov      rdi, r8
       call     [Lokad.Lython.Runtime.ExecutionState:get_CanContinue():bool:this]
       test     eax, eax
       je       G_M000_IG245
 
G_M000_IG157:                ;; offset=0x1578
       mov      rsi, r14
       mov      edx, r12d
       mov      rdi, gword ptr [rbp-0x1F0]
       call     [Lokad.Lython.Runtime.Text.PyStringOps+CasedWhitespaceIteration:Materialize(System.ReadOnlySpan`1[byte]):Lokad.Lython.Runtime.Text.PyString:this]
       mov      gword ptr [rbp-0x228], rax
       mov      r14, gword ptr [rbp-0x2B8]
       mov      gword ptr [rsp], r14
       mov      r12d, dword ptr [rbp-0x17C]
       mov      dword ptr [rsp+0x08], r12d
       mov      rdi, r13
       mov      rdx, gword ptr [rbp-0x228]
       mov      ecx, dword ptr [rbp-0x18C]
       mov      r8, gword ptr [rbp-0x210]
       mov      esi, -1
       call     [Lokad.Lython.Runtime.PyDict:TryAccumulateAt(int,Lokad.Lython.Runtime.Text.PyString,uint,System.Object,System.Numerics.BigInteger):bool:this]
       jmp      G_M000_IG140
 
G_M000_IG158:                ;; offset=0x15D0
       mov      dword ptr [rbp-0x54], 1
       mov      rcx, bword ptr [rbp-0x1E8]
       mov      eax, dword ptr [rcx+0x1C]
       cmp      eax, 51
       jg       G_M000_IG111
 
G_M000_IG159:                ;; offset=0x15EA
       cmp      eax, 41
       je       SHORT G_M000_IG161
 
G_M000_IG160:                ;; offset=0x15EF
       add      eax, -49
       cmp      eax, 2
       ja       G_M000_IG254
 
G_M000_IG161:                ;; offset=0x15FB
       mov      eax, dword ptr [rcx+0x08]
       mov      dword ptr [rdi+0x18], eax
 
G_M000_IG162:                ;; offset=0x1601
       mov      dword ptr [rbp-0x58], 1
       jmp      G_M000_IG256
 
G_M000_IG163:                ;; offset=0x160D
       xor      r12, r12
       mov      bword ptr [rbp-0x2D0], r12
       xor      edx, edx
       mov      qword ptr [rbp-0x48], r10
       jmp      G_M000_IG39
 
G_M000_IG164:                ;; offset=0x1622
       or       r12d, edx
       jne      G_M000_IG250
       xor      r9, r9
       xor      r11d, r11d
       jmp      G_M000_IG40
 
G_M000_IG165:                ;; offset=0x1636
       mov      bword ptr [rbp-0x2C8], r9
       mov      dword ptr [rbp-0x184], r11d
       mov      r8d, r8d
       shl      r8, 32
       mov      r10d, r12d
       mov      rsi, r10
       or       rsi, r8
       mov      rdi, gword ptr [rbp-0x1F0]
       call     [Lokad.Lython.Runtime.Text.PyStringOps+CasedWhitespaceIteration:Materialize(System.ValueTuple`3[int,int,int]):Lokad.Lython.Runtime.Text.PyString:this]
       mov      r14, rax
       mov      gword ptr [rbp-0x230], r14
       mov      rdi, bword ptr [rbp-0x1D8]
       jmp      G_M000_IG41
 
G_M000_IG166:                ;; offset=0x1677
       cmp      dword ptr [r11+0x20], 0
       setne    r11b
       movzx    r11, r11b
       test     r11d, r11d
       je       G_M000_IG56
 
G_M000_IG167:                ;; offset=0x168D
       mov      rdi, r10
       mov      rsi, r9
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
       mov      rdi, bword ptr [rbp-0x1D8]
       jmp      G_M000_IG56
 
G_M000_IG168:                ;; offset=0x16A5
       cmp      dword ptr [r11+0x20], 0
       setne    r11b
       movzx    r11, r11b
       test     r11d, r11d
       jne      SHORT G_M000_IG169
       jmp      G_M000_IG44
 
G_M000_IG169:                ;; offset=0x16BC
       mov      rdi, r10
       mov      rsi, r9
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
       jmp      G_M000_IG44
 
G_M000_IG170:                ;; offset=0x16CD
       jmp      G_M000_IG54
 
G_M000_IG171:                ;; offset=0x16D2
       mov      r13, gword ptr [rdx+0x08]
       mov      edx, dword ptr [rdx+0x18]
       test     r13, r13
       jne      SHORT G_M000_IG173
 
G_M000_IG172:                ;; offset=0x16DE
       test     edx, edx
       jne      G_M000_IG250
       xor      r13, r13
       xor      edx, edx
       jmp      SHORT G_M000_IG174
 
G_M000_IG173:                ;; offset=0x16ED
       cmp      dword ptr [r13+0x08], edx
       jb       G_M000_IG250
       add      r13, 16
 
G_M000_IG174:                ;; offset=0x16FB
       jmp      G_M000_IG66
 
G_M000_IG175:                ;; offset=0x1700
       or       r13d, edx
       jne      G_M000_IG250
       xor      r13, r13
       xor      edx, edx
       jmp      G_M000_IG107
 
G_M000_IG176:                ;; offset=0x1713
       xor      ebx, ebx
       mov      dword ptr [rbp-0xAC], ebx
       mov      rbx, rdx
       and      rbx, 2
       mov      qword ptr [rbp-0xB8], rbx
       test     rbx, rbx
       je       SHORT G_M000_IG178
 
G_M000_IG177:                ;; offset=0x172E
       movzx    rbx, word  ptr [r14]
       mov      dword ptr [rbp-0x31C], ebx
       mov      bword ptr [rbp-0x2E0], r13
       movzx    rbx, word  ptr [r13]
       movzx    r13, dword ptr [rbp-0x31C]
       sub      r13d, ebx
       mov      ebx, r13d
       mov      dword ptr [rbp-0xAC], ebx
       mov      r13, bword ptr [rbp-0x2E0]
 
G_M000_IG178:                ;; offset=0x175F
       test     dl, 1
       je       SHORT G_M000_IG180
 
G_M000_IG179:                ;; offset=0x1764
       mov      rbx, qword ptr [rbp-0xB8]
       movzx    rdx, byte  ptr [r14+rbx]
       movzx    r13, byte  ptr [rbx+r13]
       sub      edx, r13d
       mov      ebx, edx
       or       ebx, dword ptr [rbp-0xAC]
       mov      dword ptr [rbp-0xAC], ebx
 
G_M000_IG180:                ;; offset=0x1786
       cmp      dword ptr [rbp-0xAC], 0
       sete     dl
       movzx    rdx, dl
       jmp      G_M000_IG70
 
G_M000_IG181:                ;; offset=0x1798
       xor      r13d, r13d
       mov      qword ptr [rbp-0x98], r13
       add      rdx, -32
       mov      qword ptr [rbp-0xA0], rdx
       test     rdx, rdx
       je       SHORT G_M000_IG184
       mov      rdx, bword ptr [rbp-0x2D8]
       vmovups  ymm0, ymmword ptr [rdx]
       mov      r13, bword ptr [rbp-0x270]
       vpcmpeqb ymm0, ymm0, ymmword ptr [r13]
       vpmovmskb edx, ymm0
       cmp      edx, -1
       jne      G_M000_IG190
 
G_M000_IG182:                ;; offset=0x17D7
       mov      rdx, qword ptr [rbp-0x98]
       add      rdx, 32
       cmp      qword ptr [rbp-0xA0], rdx
       jbe      SHORT G_M000_IG184
 
G_M000_IG183:                ;; offset=0x17EB
       mov      r13, bword ptr [rbp-0x2D8]
       vmovups  ymm0, ymmword ptr [rdx+r13]
       mov      r13, bword ptr [rbp-0x270]
       mov      qword ptr [rbp-0x98], rdx
       vpcmpeqb ymm0, ymm0, ymmword ptr [rdx+r13]
       vpmovmskb edx, ymm0
       cmp      edx, -1
       jne      G_M000_IG190
       jmp      SHORT G_M000_IG182
 
G_M000_IG184:                ;; offset=0x181B
       mov      rdx, bword ptr [rbp-0x2D8]
       mov      r13, qword ptr [rbp-0xA0]
       vmovups  ymm0, ymmword ptr [rdx+r13]
       mov      rdx, bword ptr [rbp-0x270]
       vpcmpeqb ymm0, ymm0, ymmword ptr [rdx+r13]
       vpmovmskb edx, ymm0
       cmp      edx, -1
       jne      G_M000_IG190
       jmp      G_M000_IG189
 
G_M000_IG185:                ;; offset=0x184E
       xor      r13d, r13d
       mov      qword ptr [rbp-0x88], r13
       add      rdx, -16
       mov      qword ptr [rbp-0x90], rdx
       test     rdx, rdx
       je       SHORT G_M000_IG188
       mov      r13, bword ptr [rbp-0x2D8]
       vmovups  xmm0, xmmword ptr [r13]
       mov      rdx, bword ptr [rbp-0x270]
       vpcmpeqb xmm0, xmm0, xmmword ptr [rdx]
       vpmovmskb r13d, xmm0
       cmp      r13d, 0xFFFF
       jne      SHORT G_M000_IG190
 
G_M000_IG186:                ;; offset=0x188D
       mov      r13, qword ptr [rbp-0x88]
       add      r13, 16
       cmp      qword ptr [rbp-0x90], r13
       jbe      SHORT G_M000_IG188
 
G_M000_IG187:                ;; offset=0x18A1
       mov      rdx, bword ptr [rbp-0x2D8]
       vmovups  xmm0, xmmword ptr [rdx+r13]
       mov      rdx, bword ptr [rbp-0x270]
       mov      qword ptr [rbp-0x88], r13
       vpcmpeqb xmm0, xmm0, xmmword ptr [rdx+r13]
       vpmovmskb r13d, xmm0
       cmp      r13d, 0xFFFF
       jne      SHORT G_M000_IG190
       jmp      SHORT G_M000_IG186
 
G_M000_IG188:                ;; offset=0x18D1
       mov      r13, bword ptr [rbp-0x2D8]
       mov      rdx, qword ptr [rbp-0x90]
       vmovups  xmm0, xmmword ptr [rdx+r13]
       mov      r13, bword ptr [rbp-0x270]
       vpcmpeqb xmm0, xmm0, xmmword ptr [rdx+r13]
       vpmovmskb edx, xmm0
       cmp      edx, 0xFFFF
       jne      SHORT G_M000_IG190
 
G_M000_IG189:                ;; offset=0x18FE
       mov      edx, 1
       jmp      G_M000_IG70
 
G_M000_IG190:                ;; offset=0x1908
       xor      edx, edx
       jmp      G_M000_IG70
 
G_M000_IG191:                ;; offset=0x190F
       cmp      dword ptr [r13+0x20], 0
       setne    r13b
       movzx    r13, r13b
       test     r13d, r13d
       je       G_M000_IG73
 
G_M000_IG192:                ;; offset=0x1925
       mov      rdi, r8
       mov      rsi, gword ptr [rbp-0x250]
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
       mov      r10, gword ptr [rbp-0x258]
       mov      r11d, dword ptr [rbp-0x6C]
       jmp      G_M000_IG73
 
G_M000_IG193:                ;; offset=0x1945
       mov      r9d, dword ptr [rbp-0xBC]
       and      r9d, 3
       dec      r9d
       cmp      r9d, 2
       ja       G_M000_IG76
       mov      qword ptr [rbp-0x324], r9
       lea      r9, [reloc @RWD00]
       mov      dword ptr [rbp-0x19C], r8d
       mov      r13, qword ptr [rbp-0x324]
       mov      r9d, dword ptr [r9+4*r13]
       lea      rdx, G_M000_IG02
       add      r9, rdx
       jmp      r9
 
G_M000_IG194:                ;; offset=0x198A
       mov      rbx, bword ptr [rbp-0x2E8]
       mov      esi, dword ptr [rbx]
       lea      rdi, [rbp-0xD8]
       call     [System.HashCode:Add(int):this]
       add      rbx, 4
       mov      r13d, dword ptr [rbp-0xE0]
       lea      r8d, [r13-0x04]
       mov      dword ptr [rbp-0x19C], r8d
 
G_M000_IG195:                ;; offset=0x19B6
       mov      esi, dword ptr [rbx]
       lea      rdi, [rbp-0xD8]
       call     [System.HashCode:Add(int):this]
       add      rbx, 4
       mov      eax, dword ptr [rbp-0x19C]
       add      eax, -4
       mov      dword ptr [rbp-0x19C], eax
 
G_M000_IG196:                ;; offset=0x19D8
       mov      esi, dword ptr [rbx]
       lea      rdi, [rbp-0xD8]
       call     [System.HashCode:Add(int):this]
       add      rbx, 4
       mov      eax, dword ptr [rbp-0x19C]
       add      eax, -4
       mov      r8d, eax
       mov      r10, gword ptr [rbp-0x258]
       mov      r11d, dword ptr [rbp-0x6C]
       jmp      G_M000_IG76
 
G_M000_IG197:                ;; offset=0x1A07
       mov      edx, -2
       jmp      G_M000_IG51
 
G_M000_IG198:                ;; offset=0x1A11
       jmp      G_M000_IG54
 
G_M000_IG199:                ;; offset=0x1A16
       mov      dword ptr [rbp-0x64], r8d
       mov      eax, r8d
       xor      edx, edx
       div      edx:eax, r9d
       mov      r11d, edx
       mov      r8d, dword ptr [rbp-0x64]
       jmp      G_M000_IG53
 
G_M000_IG200:                ;; offset=0x1A2E
       cmp      dword ptr [r11+0x20], 0
       setne    r11b
       movzx    r11, r11b
       test     r11d, r11d
       je       G_M000_IG116
       mov      dword ptr [rbp-0x64], r8d
       jmp      SHORT G_M000_IG202
 
G_M000_IG201:                ;; offset=0x1A4A
       mov      dword ptr [rbp-0x64], r8d
 
G_M000_IG202:                ;; offset=0x1A4E
       mov      rdi, r9
       mov      rsi, gword ptr [rbp-0x250]
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
       mov      r8d, dword ptr [rbp-0x64]
       jmp      G_M000_IG116
 
G_M000_IG203:                ;; offset=0x1A67
       mov      r13, gword ptr [r9+0x08]
       mov      r9d, dword ptr [r9+0x18]
       test     r13, r13
       jne      SHORT G_M000_IG205
 
G_M000_IG204:                ;; offset=0x1A74
       test     r9d, r9d
       jne      G_M000_IG250
       xor      r13, r13
       xor      r9d, r9d
       jmp      SHORT G_M000_IG206
 
G_M000_IG205:                ;; offset=0x1A85
       cmp      dword ptr [r13+0x08], r9d
       jb       G_M000_IG250
       add      r13, 16
 
G_M000_IG206:                ;; offset=0x1A93
       jmp      G_M000_IG122
 
G_M000_IG207:                ;; offset=0x1A98
       or       r13d, r9d
       jne      G_M000_IG250
       xor      r13, r13
       xor      r9d, r9d
       jmp      G_M000_IG145
 
G_M000_IG208:                ;; offset=0x1AAC
       mov      r10, gword ptr [rbp-0x258]
       jmp      G_M000_IG114
 
G_M000_IG209:                ;; offset=0x1AB8
       cmp      dword ptr [rbx+0x20], 0
       setne    bl
       movzx    rbx, bl
       test     ebx, ebx
       je       G_M000_IG124
 
G_M000_IG210:                ;; offset=0x1ACA
       mov      rdi, r9
       mov      rsi, gword ptr [rbp-0x250]
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
       jmp      G_M000_IG124
 
G_M000_IG211:                ;; offset=0x1ADF
       xor      ebx, ebx
       mov      dword ptr [rbp-0x12C], ebx
       mov      rbx, r9
       and      rbx, 2
       mov      qword ptr [rbp-0x138], rbx
       test     rbx, rbx
       je       SHORT G_M000_IG213
 
G_M000_IG212:                ;; offset=0x1AFA
       mov      rbx, bword ptr [rbp-0x300]
       movzx    rbx, word  ptr [rbx]
       mov      dword ptr [rbp-0x31C], ebx
       mov      rbx, bword ptr [rbp-0x308]
       movzx    rbx, word  ptr [rbx]
       movzx    r8, dword ptr [rbp-0x31C]
       sub      r8d, ebx
       mov      ebx, r8d
       mov      dword ptr [rbp-0x12C], ebx
 
G_M000_IG213:                ;; offset=0x1B28
       test     r9b, 1
       je       SHORT G_M000_IG215
 
G_M000_IG214:                ;; offset=0x1B2E
       mov      r9, bword ptr [rbp-0x300]
       mov      rbx, qword ptr [rbp-0x138]
       movzx    r9, byte  ptr [r9+rbx]
       mov      dword ptr [rbp-0x31C], r9d
       mov      r9, bword ptr [rbp-0x308]
       movzx    r9, byte  ptr [r9+rbx]
       movzx    rbx, dword ptr [rbp-0x31C]
       sub      ebx, r9d
       or       ebx, dword ptr [rbp-0x12C]
       mov      dword ptr [rbp-0x12C], ebx
 
G_M000_IG215:                ;; offset=0x1B6A
       cmp      dword ptr [rbp-0x12C], 0
       sete     r9b
       movzx    r9, r9b
       jmp      G_M000_IG128
 
G_M000_IG216:                ;; offset=0x1B7E
       mov      r10, gword ptr [rbp-0x258]
       jmp      G_M000_IG114
 
G_M000_IG217:                ;; offset=0x1B8A
       xor      ebx, ebx
       mov      qword ptr [rbp-0x118], rbx
       add      r9, -32
       mov      qword ptr [rbp-0x120], r9
       test     r9, r9
       je       SHORT G_M000_IG219
       mov      r9, bword ptr [rbp-0x280]
       vmovups  ymm0, ymmword ptr [r9]
       mov      rbx, bword ptr [rbp-0x288]
       vpcmpeqb ymm0, ymm0, ymmword ptr [rbx]
       vpmovmskb ebx, ymm0
       cmp      ebx, -1
       je       SHORT G_M000_IG220
 
G_M000_IG218:                ;; offset=0x1BC3
       mov      r10, gword ptr [rbp-0x258]
       jmp      G_M000_IG114
 
G_M000_IG219:                ;; offset=0x1BCF
       mov      r9, bword ptr [rbp-0x280]
       jmp      SHORT G_M000_IG223
 
G_M000_IG220:                ;; offset=0x1BD8
       mov      rbx, qword ptr [rbp-0x118]
       add      rbx, 32
       cmp      qword ptr [rbp-0x120], rbx
       jbe      SHORT G_M000_IG223
 
G_M000_IG221:                ;; offset=0x1BEC
       vmovups  ymm0, ymmword ptr [r9+rbx]
       mov      r9, bword ptr [rbp-0x288]
       mov      qword ptr [rbp-0x118], rbx
       vpcmpeqb ymm0, ymm0, ymmword ptr [r9+rbx]
       vpmovmskb ebx, ymm0
       cmp      ebx, -1
       jne      SHORT G_M000_IG222
       mov      r9, bword ptr [rbp-0x280]
       jmp      SHORT G_M000_IG220
 
G_M000_IG222:                ;; offset=0x1C18
       mov      r10, gword ptr [rbp-0x258]
       jmp      G_M000_IG114
 
G_M000_IG223:                ;; offset=0x1C24
       mov      rbx, qword ptr [rbp-0x120]
       vmovups  ymm0, ymmword ptr [r9+rbx]
       mov      r9, bword ptr [rbp-0x288]
       vpcmpeqb ymm0, ymm0, ymmword ptr [r9+rbx]
       vpmovmskb r9d, ymm0
       cmp      r9d, -1
       je       G_M000_IG129
 
G_M000_IG224:                ;; offset=0x1C4C
       mov      r10, gword ptr [rbp-0x258]
       jmp      G_M000_IG114
 
G_M000_IG225:                ;; offset=0x1C58
       xor      ebx, ebx
       mov      qword ptr [rbp-0x108], rbx
       add      r9, -16
       mov      qword ptr [rbp-0x110], r9
       test     r9, r9
       je       G_M000_IG229
       mov      rbx, bword ptr [rbp-0x280]
       vmovups  xmm0, xmmword ptr [rbx]
       mov      r9, bword ptr [rbp-0x288]
       vpcmpeqb xmm0, xmm0, xmmword ptr [r9]
       vpmovmskb r9d, xmm0
       cmp      r9d, 0xFFFF
       je       SHORT G_M000_IG227
 
G_M000_IG226:                ;; offset=0x1C99
       mov      r10, gword ptr [rbp-0x258]
       jmp      G_M000_IG114
 
G_M000_IG227:                ;; offset=0x1CA5
       mov      r9, qword ptr [rbp-0x108]
       add      r9, 16
       cmp      qword ptr [rbp-0x110], r9
       ja       SHORT G_M000_IG228
       jmp      SHORT G_M000_IG229
 
G_M000_IG228:                ;; offset=0x1CBB
       vmovups  xmm0, xmmword ptr [rbx+r9]
       mov      rbx, bword ptr [rbp-0x288]
       mov      qword ptr [rbp-0x108], r9
       vpcmpeqb xmm0, xmm0, xmmword ptr [rbx+r9]
       vpmovmskb r9d, xmm0
       cmp      r9d, 0xFFFF
       mov      rbx, bword ptr [rbp-0x280]
       je       SHORT G_M000_IG227
       mov      r10, gword ptr [rbp-0x258]
       jmp      G_M000_IG114
 
G_M000_IG229:                ;; offset=0x1CF5
       mov      rbx, bword ptr [rbp-0x280]
       mov      r9, qword ptr [rbp-0x110]
       vmovups  xmm0, xmmword ptr [rbx+r9]
       mov      rbx, bword ptr [rbp-0x288]
       vpcmpeqb xmm0, xmm0, xmmword ptr [rbx+r9]
       vpmovmskb r9d, xmm0
       cmp      r9d, 0xFFFF
       je       G_M000_IG129
 
G_M000_IG230:                ;; offset=0x1D27
       mov      r10, gword ptr [rbp-0x258]
       jmp      G_M000_IG114
 
G_M000_IG231:                ;; offset=0x1D33
       mov      rax, gword ptr [rbp-0x218]
       jmp      G_M000_IG155
 
G_M000_IG232:                ;; offset=0x1D3F
       mov      rsi, r13
       mov      rdi, rbx
       call     CORINFO_HELP_CHKCASTCLASS
       int3     
 
G_M000_IG233:                ;; offset=0x1D4B
       mov      rdi, rax
       mov      esi, r11d
       call     [Lokad.Lython.Runtime.PyDict:ReadNativeValue(int):System.Object:this]
       mov      r13, rax
       test     r13, r13
       jne      SHORT G_M000_IG236
 
G_M000_IG234:                ;; offset=0x1D5F
       mov      rax, gword ptr [rbp-0x218]
 
G_M000_IG235:                ;; offset=0x1D66
       xor      edx, edx
       mov      r13, rax
       mov      eax, edx
       jmp      G_M000_IG139
 
G_M000_IG236:                ;; offset=0x1D72
       mov      rsi, qword ptr [r13]
       mov      rdi, 0x7F2360360018
       cmp      rsi, rdi
       je       SHORT G_M000_IG238
 
G_M000_IG237:                ;; offset=0x1D85
       mov      rax, gword ptr [rbp-0x218]
       jmp      SHORT G_M000_IG235
 
G_M000_IG238:                ;; offset=0x1D8E
       mov      rdi, 0x7F2360360018
       cmp      rsi, rdi
       je       SHORT G_M000_IG240
 
G_M000_IG239:                ;; offset=0x1D9D
       mov      rsi, r13
       mov      rdi, 0x7F2360360018
       call     CORINFO_HELP_UNBOX
 
G_M000_IG240:                ;; offset=0x1DAF
       vmovdqu  xmm0, xmmword ptr [r13+0x08]
       vmovdqu  xmmword ptr [rbp-0x150], xmm0
 
G_M000_IG241:                ;; offset=0x1DBD
       xor      edi, edi
       mov      dword ptr [rbp-0x178], edi
       lea      rdi, [rbp-0x178]
       mov      qword ptr [rsp], rdi
       lea      rdi, [rbp-0x150]
       xor      rdx, rdx
       xor      ecx, ecx
       mov      esi, 1
       xor      r8d, r8d
       xor      r9d, r9d
       call     [System.Numerics.BigInteger:TryGetBytes(int,System.Span`1[byte],bool,bool,byref):byte[]:this]
       cmp      dword ptr [rbp-0x178], 8
       jl       SHORT G_M000_IG243
 
G_M000_IG242:                ;; offset=0x1DF5
       mov      rax, gword ptr [rbp-0x218]
       jmp      G_M000_IG235
 
G_M000_IG243:                ;; offset=0x1E01
       mov      rdi, gword ptr [rbp-0x150]
       mov      rsi, qword ptr [rbp-0x148]
       call     [System.Numerics.BigInteger:op_Explicit(System.Numerics.BigInteger):long]
       mov      r13, rax
       jmp      G_M000_IG136
 
G_M000_IG244:                ;; offset=0x1E1D
       vxorps   xmm0, xmm0, xmm0
       vmovdqu  xmmword ptr [rbp-0x168], xmm0
       lea      rdi, [rbp-0x168]
       call     [System.Numerics.BigInteger:.ctor(long):this]
       mov      rdi, 0x7F2360360018
       call     CORINFO_HELP_NEWSFAST
       mov      gword ptr [rbp-0x298], rax
       lea      rdi, bword ptr [rax+0x08]
       mov      rsi, gword ptr [rbp-0x168]
       call     CORINFO_HELP_ASSIGN_REF
       mov      ecx, dword ptr [rbp-0x160]
       mov      rdi, gword ptr [rbp-0x298]
       mov      dword ptr [rdi+0x10], ecx
       mov      dword ptr [rsp], 1
       mov      rcx, rdi
       mov      rdi, r13
       mov      esi, dword ptr [rbp-0x68]
       mov      rdx, gword ptr [rbp-0x290]
       mov      r8d, dword ptr [rbp-0x16C]
       xor      r9d, r9d
       call     [Lokad.Lython.Runtime.PyDict:PublishNativeValue(int,System.Object,System.Object,uint,bool,bool):System.Object:this]
       jmp      G_M000_IG137
 
G_M000_IG245:                ;; offset=0x1E98
       mov      rdi, gword ptr [rbp-0x2A8]
       mov      rsi, gword ptr [rbp-0x2A0]
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
       jmp      G_M000_IG157
 
G_M000_IG246:                ;; offset=0x1EB1
       mov      rax, gword ptr [rbp-0x218]
       mov      r12d, dword ptr [rbp-0x17C]
       mov      r14, gword ptr [rbp-0x2B8]
       mov      r10, gword ptr [rbp-0x1F8]
       mov      r8, gword ptr [r10+0x18]
       mov      gword ptr [rsp], r8
       mov      rcx, r14
       mov      r8d, r12d
       mov      rdi, rax
       mov      rsi, rdx
       mov      rdx, gword ptr [rbp-0x210]
       mov      r9, gword ptr [rbp-0x1E0]
       call     [Lokad.Lython.Runtime.PyDict:TryAccumulateWithoutAdmission(Lokad.Lython.Runtime.Text.PyString,System.Object,System.Numerics.BigInteger,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):bool:this]
       mov      r13, gword ptr [rbp-0x218]
       jmp      G_M000_IG140
 
G_M000_IG247:                ;; offset=0x1F01
       mov      r10, gword ptr [rbp-0x310]
       cmp      dword ptr [r10+0x20], 0
       setne    r10b
       movzx    r10, r10b
       test     r10d, r10d
       mov      r8, gword ptr [rbp-0x2B0]
       je       SHORT G_M000_IG249
       mov      ebx, dword ptr [rbp-0x2C]
       mov      r13, gword ptr [rbp-0x218]
 
G_M000_IG248:                ;; offset=0x1F2B
       mov      rdi, r9
       mov      rsi, r8
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
       mov      rdi, bword ptr [rbp-0x1D8]
       mov      r10, qword ptr [rbp-0x48]
       jmp      G_M000_IG37
 
G_M000_IG249:                ;; offset=0x1F47
       mov      r10, qword ptr [rbp-0x48]
       jmp      G_M000_IG37
 
G_M000_IG250:                ;; offset=0x1F50
       call     [System.ThrowHelper:ThrowArgumentOutOfRangeException()]
       int3     
 
G_M000_IG251:                ;; offset=0x1F57
       mov      edi, 40
       call     [System.ThrowHelper:ThrowArgumentOutOfRangeException(int)]
       int3     
 
G_M000_IG252:                ;; offset=0x1F63
       mov      rdi, bword ptr [rbp-0x1D8]
       mov      r13d, dword ptr [rbp-0x1AC]
       mov      dword ptr [rdi+0x18], r13d
       mov      rcx, bword ptr [rbp-0x1E8]
       mov      rdi, bword ptr [rbp-0x1D8]
       jmp      G_M000_IG162
 
G_M000_IG253:                ;; offset=0x1F88
       mov      ebx, dword ptr [rbp-0x30]
       add      ebx, 2
       mov      rdi, bword ptr [rbp-0x1D8]
       mov      dword ptr [rdi+0x18], ebx
       mov      rcx, bword ptr [rbp-0x1E8]
       jmp      G_M000_IG162
 
G_M000_IG254:                ;; offset=0x1FA4
       mov      rdi, rcx
       mov      rsi, 0x7F23DA0A4068
       call     [Lokad.Lython.Frontend.ExecutableInstruction:InvalidOperand(System.String):System.InvalidOperationException:this]
       mov      rdi, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG255:                ;; offset=0x1FC0
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG256:                ;; offset=0x1FC6
       call     G_M000_IG314
       nop      
 
G_M000_IG257:                ;; offset=0x1FCC
       mov      ebx, dword ptr [rbp-0x58]
       jmp      SHORT G_M000_IG259
 
G_M000_IG258:                ;; offset=0x1FD1
       mov      rdi, bword ptr [rbp-0x1D8]
       mov      rsi, gword ptr [rbp-0x1E0]
       mov      rdx, rbx
       mov      rcx, bword ptr [rbp-0x1E8]
       mov      r8d, r15d
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteOrdinaryDictionaryLoop(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,bool):bool]
       mov      ebx, eax
 
G_M000_IG259:                ;; offset=0x1FF4
       movzx    rax, bl
 
G_M000_IG260:                ;; offset=0x1FF7
       vzeroupper 
       add      rsp, 792
       pop      rbx
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG261:                ;; offset=0x200C
       mov      rdi, rcx
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      rcx, bword ptr [rbp-0x1E8]
       jmp      G_M000_IG05
 
G_M000_IG262:                ;; offset=0x2021
       xor      rax, rax
       jmp      G_M000_IG08
 
G_M000_IG263:                ;; offset=0x2028
       mov      rdi, rax
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishInteger():System.Object:this]
       mov      r14, rax
       jmp      G_M000_IG11
 
G_M000_IG264:                ;; offset=0x2039
       mov      rdi, rax
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishDouble():System.Object:this]
       mov      r14, rax
       jmp      G_M000_IG11
 
G_M000_IG265:                ;; offset=0x204A
       mov      rdi, rax
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishTupleBorrow():System.Object:this]
       mov      r14, rax
       jmp      G_M000_IG11
 
G_M000_IG266:                ;; offset=0x205B
       mov      rdi, 0x7F235FD6C0C0
       call     CORINFO_HELP_NEWSFAST
       mov      rbx, rax
       mov      rdi, rbx
       mov      rsi, 0x7F23DA09D5A8
       call     [System.InvalidOperationException:.ctor(System.String):this]
       mov      rdi, rbx
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG267:                ;; offset=0x2089
       mov      rdi, rcx
       mov      rsi, 0x7F23DA0A6FC0
       call     [Lokad.Lython.Frontend.ExecutableInstruction:InvalidOperand(System.String):System.InvalidOperationException:this]
       mov      rdi, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG268:                ;; offset=0x20A5
       mov      rdi, rdx
       mov      rsi, 0x7F23DA09FE40
       call     [Lokad.Lython.Frontend.ExecutableInstruction:InvalidOperand(System.String):System.InvalidOperationException:this]
       mov      rdi, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG269:                ;; offset=0x20C1
       call     [System.ThrowHelper:ThrowArgumentOutOfRange_IndexMustBeLessException()]
       int3     
 
G_M000_IG270:                ;; offset=0x20C8
       mov      rdi, rax
       mov      esi, edx
       mov      r11, 0x7F235E732B00
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       mov      r14, rax
       jmp      G_M000_IG13
 
G_M000_IG271:                ;; offset=0x20E2
       mov      rdi, rax
       mov      rsi, 0x7F23DA09FE70
       call     [Lokad.Lython.Frontend.ExecutableInstruction:InvalidOperand(System.String):System.InvalidOperationException:this]
       mov      rdi, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG272:                ;; offset=0x20FE
       cmp      r8d, 64
       je       G_M000_IG14
       cmp      r8d, 67
       je       G_M000_IG14
       cmp      r8d, 70
       jne      SHORT G_M000_IG271
       jmp      G_M000_IG14
 
G_M000_IG273:                ;; offset=0x211D
       mov      rdi, r9
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishInteger():System.Object:this]
       jmp      G_M000_IG18
 
G_M000_IG274:                ;; offset=0x212B
       mov      rdi, r9
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishDouble():System.Object:this]
       jmp      G_M000_IG18
 
G_M000_IG275:                ;; offset=0x2139
       mov      rdi, r9
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishTupleBorrow():System.Object:this]
       jmp      G_M000_IG18
 
G_M000_IG276:                ;; offset=0x2147
       cmp      qword ptr [r9+0x08], 0
       jle      SHORT G_M000_IG279
 
G_M000_IG277:                ;; offset=0x214E
       mov      rsi, gword ptr [r9]
       mov      rdi, 0x7F23607D4AF0
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG278
       mov      rcx, bword ptr [rbp-0x248]
       mov      esi, dword ptr [rcx+0x08]
       dec      esi
       lea      rdx, [rbp-0x40]
       mov      rdi, rax
       call     [Lokad.Lython.Runtime.PyTuple:TryReadInteger(int,byref):bool:this]
       jmp      SHORT G_M000_IG280
 
G_M000_IG278:                ;; offset=0x2180
       mov      r9, bword ptr [rbp-0x248]
 
G_M000_IG279:                ;; offset=0x2187
       mov      rdi, gword ptr [r9]
       lea      rsi, [rbp-0x40]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryMachineInteger(System.Object,byref):bool]
 
G_M000_IG280:                ;; offset=0x2194
       test     eax, eax
       je       G_M000_IG19
       jmp      G_M000_IG27
 
G_M000_IG281:                ;; offset=0x21A1
       cmp      dword ptr [r10+0x08], 1
       jle      SHORT G_M000_IG282
       mov      rdi, 0x7F23608E52B8
       call     CORINFO_HELP_NEWSFAST
       mov      r12, rax
       call     [System.SR:get_Overflow_Int64():System.String]
       mov      rsi, rax
       mov      rdi, r12
       call     [System.OverflowException:.ctor(System.String):this]
       mov      rdi, r12
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG282:                ;; offset=0x21D5
       cmp      dword ptr [r10+0x08], 0
       jbe      SHORT G_M000_IG286
       mov      r10, qword ptr [r10+0x10]
       mov      qword ptr [rbp-0x60], r10
       neg      r10
       test     edx, edx
       cmovg    r10, qword ptr [rbp-0x60]
       test     r10, r10
       jle      SHORT G_M000_IG283
       test     edx, edx
       jg       SHORT G_M000_IG284
 
G_M000_IG283:                ;; offset=0x21F7
       test     r10, r10
       jge      SHORT G_M000_IG285
       test     edx, edx
       jge      SHORT G_M000_IG285
 
G_M000_IG284:                ;; offset=0x2200
       jmp      G_M000_IG30
 
G_M000_IG285:                ;; offset=0x2205
       mov      rdi, 0x7F23608E52B8
       call     CORINFO_HELP_NEWSFAST
       mov      r15, rax
       call     [System.SR:get_Overflow_Int64():System.String]
       mov      rsi, rax
       mov      rdi, r15
       call     [System.OverflowException:.ctor(System.String):this]
       mov      rdi, r15
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG286:                ;; offset=0x2232
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG287:                ;; offset=0x2238
       sub      rsp, 24
 
G_M000_IG288:                ;; offset=0x223C
       cmp      dword ptr [rbp-0x4C], 0
       je       SHORT G_M000_IG290
 
G_M000_IG289:                ;; offset=0x2242
       mov      rdi, bword ptr [rbp-0x1D8]
       mov      rsi, gword ptr [rdi+0x08]
       mov      r9, bword ptr [rbp-0x220]
       mov      eax, dword ptr [r9+0x10]
       cmp      eax, dword ptr [rsi+0x08]
       jae      SHORT G_M000_IG294
       shl      rax, 4
       lea      rbx, bword ptr [rsi+rax+0x10]
       mov      r15, qword ptr [rbp-0x40]
       mov      rsi, 0x7F13B5801408
       mov      rsi, gword ptr [rsi]
       mov      rdi, rbx
       call     CORINFO_HELP_ASSIGN_REF
       mov      qword ptr [rbx+0x08], r15
 
G_M000_IG290:                ;; offset=0x2283
       cmp      dword ptr [rbp-0x54], 0
       je       SHORT G_M000_IG292
 
G_M000_IG291:                ;; offset=0x2289
       mov      rdi, bword ptr [rbp-0x1D8]
       add      rdi, 32
       mov      rcx, bword ptr [rbp-0x1E8]
       mov      esi, dword ptr [rcx+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
 
G_M000_IG292:                ;; offset=0x22A4
       nop      
 
G_M000_IG293:                ;; offset=0x22A5
       vzeroupper 
       add      rsp, 24
       ret      
 
G_M000_IG294:                ;; offset=0x22AD
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG295:                ;; offset=0x22B3
       sub      rsp, 24
 
G_M000_IG296:                ;; offset=0x22B7
       cmp      gword ptr [rbp-0x228], 0
       jne      SHORT G_M000_IG298
 
G_M000_IG297:                ;; offset=0x22C1
       cmp      dword ptr [rbp-0x180], 0
       je       G_M000_IG312
 
G_M000_IG298:                ;; offset=0x22CE
       mov      rdi, bword ptr [rbp-0x1D8]
       mov      rax, gword ptr [rdi+0x08]
       mov      r9, bword ptr [rbp-0x208]
       mov      ecx, dword ptr [r9+0x1C]
       cmp      ecx, 9
       je       SHORT G_M000_IG300
 
G_M000_IG299:                ;; offset=0x22E9
       cmp      ecx, 10
       je       SHORT G_M000_IG300
       mov      rdi, r9
       mov      rsi, 0x7F23DA0A4138
       call     [Lokad.Lython.Frontend.ExecutableInstruction:InvalidOperand(System.String):System.InvalidOperationException:this]
       mov      rdi, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG300:                ;; offset=0x230A
       mov      ecx, dword ptr [r9+0x14]
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG310
       shl      rcx, 4
       lea      rbx, bword ptr [rax+rcx+0x10]
       mov      rsi, gword ptr [rbp-0x228]
       cmp      gword ptr [rbp-0x228], 0
       jne      G_M000_IG311
 
G_M000_IG301:                ;; offset=0x2335
       mov      r15d, dword ptr [rbp-0x180]
       add      r15, 128
       mov      rax, gword ptr [rbp-0x1F0]
       cmp      r15, qword ptr [rax+0x28]
       jle      SHORT G_M000_IG303
 
G_M000_IG302:                ;; offset=0x2350
       mov      rdi, 0x7F235FD6C0C0
       call     CORINFO_HELP_NEWSFAST
       mov      rbx, rax
       mov      rdi, rbx
       mov      rsi, 0x7F23DA0A7008
       call     [System.InvalidOperationException:.ctor(System.String):this]
       mov      rdi, rbx
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG303:                ;; offset=0x237E
       mov      rax, gword ptr [rbp-0x1F0]
       mov      r14, gword ptr [rax+0x08]
       mov      rdi, 0x7F23603BFBC0
       call     CORINFO_HELP_NEWSFAST
       mov      r13, rax
       mov      dword ptr [r13+0x1C], -1
       cmp      dword ptr [rbp-0x180], 0
       jne      SHORT G_M000_IG305
 
G_M000_IG304:                ;; offset=0x23AC
       xor      edi, edi
       mov      rsi, 0x7F23DA098B28
       call     [System.ArgumentOutOfRangeException:ThrowNegativeOrZero[int](int,System.String)]
       int3     
 
G_M000_IG305:                ;; offset=0x23BF
       cmp      dword ptr [rbp-0x180], 8
       jg       SHORT G_M000_IG307
 
G_M000_IG306:                ;; offset=0x23C8
       mov      esi, dword ptr [rbp-0x180]
       mov      byte  ptr [r13+0x24], sil
       jmp      SHORT G_M000_IG308
 
G_M000_IG307:                ;; offset=0x23D4
       mov      esi, dword ptr [rbp-0x180]
       mov      rdi, 0x7F235FA6CCD0
       call     CORINFO_HELP_NEWARR_1_VC
       mov      rsi, rax
       lea      rdi, bword ptr [r13+0x08]
       call     CORINFO_HELP_ASSIGN_REF
 
G_M000_IG308:                ;; offset=0x23F5
       mov      edi, dword ptr [rbp-0x180]
       mov      dword ptr [r13+0x18], edi
       lea      rdi, bword ptr [r13+0x10]
       mov      rsi, r14
       call     CORINFO_HELP_ASSIGN_REF
       mov      rdi, r13
       call     [Lokad.Lython.Runtime.Text.PyString:get_UnpublishedUtf8():System.Span`1[byte]:this]
       mov      rdi, rax
       cmp      dword ptr [rbp-0x180], edx
       jg       SHORT G_M000_IG309
       mov      edx, dword ptr [rbp-0x180]
       mov      rsi, bword ptr [rbp-0x2C0]
       call     [System.SpanHelpers:Memmove(byref,byref,nuint)]
       mov      rdi, r13
       mov      esi, dword ptr [rbp-0x180]
       call     [Lokad.Lython.Runtime.Text.PyString:CompleteUnpublishedUtf8(int):this]
       mov      rax, gword ptr [rbp-0x1F0]
       sub      qword ptr [rax+0x28], r15
       mov      rsi, r13
       jmp      SHORT G_M000_IG311
 
G_M000_IG309:                ;; offset=0x2451
       call     [System.ThrowHelper:ThrowArgumentException_DestinationTooShort()]
       int3     
 
G_M000_IG310:                ;; offset=0x2458
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG311:                ;; offset=0x245E
       mov      rdi, rbx
       call     CORINFO_HELP_ASSIGN_REF
       xor      edi, edi
       mov      qword ptr [rbx+0x08], rdi
 
G_M000_IG312:                ;; offset=0x246C
       call     G_M000_IG287
       nop      
 
G_M000_IG313:                ;; offset=0x2472
       vzeroupper 
       add      rsp, 24
       ret      
 
G_M000_IG314:                ;; offset=0x247A
       sub      rsp, 24
 
G_M000_IG315:                ;; offset=0x247E
       cmp      dword ptr [rbp-0x50], 0
       je       SHORT G_M000_IG318
 
G_M000_IG316:                ;; offset=0x2484
       mov      rsi, gword ptr [rbp-0x1E0]
       mov      rdi, gword ptr [rsi+0x98]
       mov      rax, qword ptr [rdi+0x160]
       test     rax, rax
       jle      SHORT G_M000_IG318
 
G_M000_IG317:                ;; offset=0x249E
       dec      rax
       mov      qword ptr [rdi+0x160], rax
 
G_M000_IG318:                ;; offset=0x24A8
       call     G_M000_IG295
       nop      
 
G_M000_IG319:                ;; offset=0x24AE
       vzeroupper 
       add      rsp, 24
       ret      
 
RWD00  	dd	0000191Dh ; case G_M000_IG194
       	dd	00001949h ; case G_M000_IG195
       	dd	0000196Bh ; case G_M000_IG196

; Total bytes of code 9398

