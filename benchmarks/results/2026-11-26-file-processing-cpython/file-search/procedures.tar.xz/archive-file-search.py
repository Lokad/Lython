from pathlib import Path
import hashlib, json, shutil, tarfile

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
run=lab/'file-search-confirmation'
quiet=run/'comparison/quiet'
main=lab/'comparison/quiet'
out=repo/'benchmarks/results/2026-11-26-file-processing-cpython/file-search'
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
identity=read(quiet/'identity.json'); original=read(main/'identity.json'); summary=read(quiet/'summary.json')
for field in ('sourceRevision','imageFiles','coreSHA256','expectedCPythonSHA256','cpythonWorkerSHA256'):
    assert identity[field]==original[field]
assert summary['source']==identity['sourceRevision'] and summary['timedBatches']==56
verified=read(quiet/'candidate-verify.json')
assert verified['state']=='Completed' and verified['caseCount']==1 and verified['catalogSha256']==sha(quiet/'representative.json')
assert verified['launched']['library']['sha256']==identity['coreSHA256']['candidate']
receipt=read(quiet/'terminal-status.json')['receipt']
assert receipt['complete'] and receipt['allWorkersJoined'] and receipt['guestFixturesRemoved']
assert sha(quiet/'observations.tar.xz')==receipt['archiveSHA256']
local=read(lab/'file-search-warm-local.json')
assert local['state']=='Completed' and local['catalogSha256']==sha(quiet/'representative.json')
assert all(abs(sample['iqrFraction'])>.19 for sample in local['summaries'])
out.mkdir(exist_ok=True)
for name in ('identity.json','summary.json','terminal-status.json','observations.tar.xz'):
    shutil.copyfile(quiet/name,out/name)
with tarfile.open(out/'procedures.tar.xz','w:xz') as archive:
    for name in ('prepare-file-search.py','archive-file-search.py','file-search-warm-local.json','file-search-verify.json'):
        archive.add(lab/name,arcname=name)
    for name in ('quiet.py','stage.log','retrieve.log'):
        archive.add(run/name,arcname=name)
    for name in ('collect.py','summarize.py','run.sh','upload.json','launch.log'):
        archive.add(quiet/name,arcname=f'quiet/{name}')
print('Verified one independent golden, both phases, all 56 timed batches and the earlier local diagnostic.')
