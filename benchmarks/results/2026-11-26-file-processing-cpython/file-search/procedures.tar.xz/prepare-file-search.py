from pathlib import Path
import hashlib,json,shutil,tarfile

base=Path('.git/agent-notes/review-20261031/file-processing-cpython-20261126')
main=base/'comparison/quiet'
q=base/'file-search-confirmation/comparison/quiet'
q.mkdir(parents=True,exist_ok=True)
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,text):p.write_text(text,encoding='utf-8',newline='\n')
def save(p,data):write(p,json.dumps(data,indent=2,ensure_ascii=False)+'\n')
shutil.copyfile(base/'file-search.json',q/'representative.json')
shutil.copyfile(base/'file-search-verify.json',q/'candidate-verify.json')
for name in ('run.sh','cpython-worker.py'):shutil.copyfile(main/name,q/name)
assert b'\r' not in (q/'run.sh').read_bytes()
save(q/'jobs.json',[["scripts.file-search.large",lane]for lane in ('warm','compile-run')])
identity=read(main/'identity.json')
for key in ('sourceEquivalentBuild','productionBuild','auxiliaryImageReference'):
    identity.pop(key,None)
identity['sourcePatchBase']=read(base.parent/'native-cursor-stack-admission-20261125/comparison/quiet/identity.json')['sourceRevision']
identity['purpose']='Refresh the protected early-exit file search against stock CPython.'
identity['catalogs']={name:dict(sha256=sha(q/name))for name in ('jobs.json','representative.json')}
save(q/'identity.json',identity)
verified=read(q/'candidate-verify.json')
assert verified['catalogSha256']==identity['catalogs']['representative.json']['sha256'] and verified['caseCount']==1
assert verified['launched']['library']['sha256']==identity['coreSHA256']['candidate']
for name in ('collect.py','summarize.py'):
    s=(main/name).read_text(encoding='utf-8')
    s=s.replace('len(jobs) == 5','len(jobs) == 2').replace('len(raw["jobs"])==5 and receipt["warmJobs"]==5','len(raw["jobs"])==2 and receipt["warmJobs"]==2')
    s=s.replace('lython-b1744-fixtures','lython-b1744-file-search-fixtures').replace('started<245','started<120')
    compile(s,name,'exec')
    write(q/name,s)
s=(base/'quiet.py').read_text(encoding='utf-8').replace('lython-b1744-file-processing-cpython-20261126','lython-b1744-file-search-cpython-20261126')
s=s.replace('timedelta(seconds=225)','timedelta(seconds=93)').replace('RuntimeMaxSec=290','RuntimeMaxSec=150')
write(q.parents[1]/'quiet.py',s)
payload=q/'stage.tar.gz'
with tarfile.open(payload,'w:gz',compresslevel=6) as tar:
    for name in ('identity.json','jobs.json','representative.json','collect.py','run.sh','cpython-worker.py'):
        tar.add(q/name,arcname=name,recursive=False)
save(q/'upload.json',dict(root='file-search-cpython-b1744-20261126',payloadSHA256=sha(payload),payloadBytes=payload.stat().st_size,
    expectedDonorArchiveSHA256=read(main/'upload.json')['expectedDonorArchiveSHA256']))
