from pathlib import Path
import hashlib,json,shutil,subprocess,sys,tarfile

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
quiet=lab/'comparison/quiet'
origin=lab.parent/'native-cursor-stack-admission-20261125'
out=repo/'benchmarks/results/2026-11-26-file-processing-cpython'
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,value):p.write_text(json.dumps(value,indent=2)+'\n',encoding='utf-8',newline='\n')
observed=read(quiet/'identity.json')
comparison=read(origin/'comparison/quiet/identity.json')
source=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()
assert source==observed['sourceRevision']==observed['productionSource']
assert sha(origin/'candidate.patch')==observed['sourcePatchSHA256']==comparison['sourcePatchSHA256']
assert subprocess.check_output(['git','diff','--binary',comparison['sourceRevision'],source,'--','src'],cwd=repo)==(origin/'candidate.patch').read_bytes()
for name,files in observed['imageFiles'].items():
    assert name=='candidate' and len(files)==32 and files==comparison['imageFiles'][name]
    assert {file.name:sha(file) for file in (lab/name).iterdir()}==files
for name,hash in observed['auxiliaryFiles'].items():
    assert observed['imageFiles']['candidate'][name]==hash
for name,meta in observed['catalogs'].items():
    assert sha(quiet/name)==meta['sha256']
verify=read(quiet/'candidate-verify.json')
assert verify['state']=='Completed' and verify['caseCount']==3
assert verify['catalogSha256']==observed['catalogs']['representative.json']['sha256']
assert verify['launched']['library']['sha256']==observed['coreSHA256']['candidate']
# The stock summarizer first verifies the unedited raw collection identity,
# protocol, results, complete process joins and persistent archive.
subprocess.run([sys.executable,quiet/'summarize.py'],cwd=repo,check=True,timeout=50)
summary=read(quiet/'summary.json')
assert summary['source']==source and summary['timedBatches']==140 and len(summary['rows'])==5
identity={k:observed[k]for k in ('sourceRevision','imageFiles','coreSHA256','cpythonWorkerSHA256',
    'expectedCPythonSHA256','catalogs','sourcePatchSHA256','auxiliaryFiles','purpose')}
identity['sourcePatchBase']=comparison['sourceRevision']
identity['frozenImageArchiveSHA256']=read(origin/'comparison/quiet/terminal-status.json')['receipt']['archiveSHA256']
identity['provenance']='The production patch was measured in B1743 and was committed without source changes. This image reuses that frozen core and the verified benchmark dependencies.'
identity['rawMetadataNote']='The collection template carried stale descriptive provenance fields inherited from B1736. The published identity derives its patch base and image custody from verified B1743 files. Raw observations are unchanged.'
out.mkdir(exist_ok=True)
write(out/'identity.json',identity)
for filename in ('summary.json','terminal-status.json','observations.tar.xz'):
    shutil.copyfile(quiet/filename,out/filename)
with tarfile.open(out/'procedures.tar.xz','w:xz') as archive:
    for name in ('prepare.py','quiet.py','write-evidence.py','prepare.log','stage.log','retrieve.log'):
        archive.add(lab/name,arcname=name,recursive=False)
    for name in ('identity.json','collect.py','summarize.py','run.sh','candidate-verify.json','upload.json','launch.log'):
        archive.add(quiet/name,arcname=f'quiet/{name}',recursive=False)
print('Verified committed production source, complete image, three independent goldens, and all 140 observations.')
