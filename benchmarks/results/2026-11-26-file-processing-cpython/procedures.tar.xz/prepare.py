from pathlib import Path
import hashlib,json,os,shutil,subprocess,tarfile

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
quiet=lab/'comparison/quiet'
quiet.mkdir(parents=True,exist_ok=True)
parent=lab.parent
origin=parent/'native-cursor-stack-admission-20261125'
template=parent/'deferred-callable-locals-cpython-20261125'/'external'
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
git=lambda *args:subprocess.check_output(['git',*args],cwd=repo)
def write(p,s):p.write_text(s,encoding='utf-8',newline='\n')
def save(p,doc):write(p,json.dumps(doc,indent=2,ensure_ascii=False)+'\n')
head=git('rev-parse','HEAD').decode().strip()
assert head.startswith('a490e9d5f')
frozen=read(origin/'comparison/quiet/identity.json')
delta=git('diff','--binary',frozen['sourceRevision'],head,'--','src')
assert delta==(origin/'candidate.patch').read_bytes() and hashlib.sha256(delta).hexdigest()==frozen['sourcePatchSHA256']
files=frozen['imageFiles']['candidate']
assert len(files)==32 and {p.name:sha(p) for p in (origin/'candidate').iterdir()}==files
origin_receipt=read(origin/'comparison/quiet/terminal-status.json')['receipt']
assert origin_receipt['complete'] and sha(origin/'comparison/quiet/observations.tar.xz')==origin_receipt['archiveSHA256']
copy=lab/'candidate'
shutil.copytree(origin/'candidate',copy,dirs_exist_ok=True)
assert {p.name:sha(p) for p in copy.iterdir()}==files
catalog=read(origin/'comparison/quiet/representative.json')
cases={c['id']:c for c in catalog['cases']}
manifest='scripts.config-manifest.small'
manifest_source=read(parent/'post-zip-cpython-20261125/external/representative.json')
cases[manifest]=next(c for c in manifest_source['cases'] if c['id']==manifest)
shipment='diagnostic.shipment-routing-callbacks'
file_fed='diagnostic.shipment-file-fed-map'
jobs=[(manifest,'compile'),(shipment,'warm'),(file_fed,'warm-async'),(shipment,'warm-async'),(manifest,'compile-run')]
catalog['cases']=[cases[key] for key in dict.fromkeys(case for case,lane in jobs)]
save(quiet/'representative.json',catalog)
save(quiet/'jobs.json',jobs)
base=read(template/'identity.json')
identity=base|dict(sourceRevision=head,productionSource=head,candidate=head,
    imageFiles={'candidate':files},coreSHA256={role:files['Lokad.Lython.dll'] for role in ('candidate','candidate-control')},
    sourcePatchSHA256=frozen['sourcePatchSHA256'],frozenImage='/home/lokad/lython-bench-checks/native-cursor-stack-b1743-20261126/candidate',
    catalogs={name:dict(sha256=sha(quiet/name)) for name in ('representative.json','jobs.json')},
    purpose='Current shipment, file-fed map and configuration manifest against stock CPython.')
save(quiet/'identity.json',identity)
for name in ('collect.py','summarize.py','run.sh'):
    s=(template/name).read_text(encoding='utf-8').replace('lython-b1736-fixtures','lython-b1744-fixtures')
    s=s.replace('Retained deferred definitions and shipment callback report against CPython','Current file-processing checkpoint against CPython')
    if name.endswith('.py'):compile(s,name,'exec')
    write(quiet/name,s)
assert b'\r' not in (quiet/'run.sh').read_bytes()
worker=repo/'benchmarks/cpython-worker.py'
assert sha(worker)==identity['cpythonWorkerSHA256']
shutil.copyfile(worker,quiet/worker.name)
sdk=Path.home()/'.dotnet11'; dotnet=sdk/'dotnet.exe'
env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk))
evidence=quiet/'candidate-verify.json'
subprocess.run([dotnet,copy/'Lokad.Lython.Benchmarks.dll','--compare','verify','--catalog',quiet/'representative.json',
  '--dotnet',dotnet,'--python','C:/Python313/python.exe','--python-worker',worker,'--out',evidence],cwd=repo, env=env, check=True, timeout=80)
verified=read(evidence)
assert verified['state']=='Completed' and verified['caseCount']==3
assert verified['catalogSha256']==identity['catalogs']['representative.json']['sha256']
assert verified['launched']['library']['sha256']==files['Lokad.Lython.dll']
payload=quiet/'stage.tar.gz'
with tarfile.open(payload,'w:gz',compresslevel=6) as archive:
    for name in ('identity.json','jobs.json','representative.json','collect.py','run.sh',worker.name):
        archive.add(quiet/name,arcname=name,recursive=False)
save(quiet/'upload.json',dict(root='file-processing-cpython-b1744-20261126',payloadSHA256=sha(payload),payloadBytes=payload.stat().st_size,
    expectedDonorArchiveSHA256=origin_receipt['archiveSHA256']))
print('Three independent CPython output and file goldens passed for the exact current image.')
