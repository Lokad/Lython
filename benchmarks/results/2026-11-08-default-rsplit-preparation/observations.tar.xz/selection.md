R99: default no-argument whitespace rsplit is semantically identical to split.
Runtime already shares the forward scanner for unlimited rsplit. Consolidate the two
compiler eligibility checks and use the existing cased-word recipe/kernel. Remove the
unobservable cased UTF-8 line and second segmentation work from affected scripts.
No new operation/backend/owner/cache/configuration. Supplied arguments retain original
lowering. Dynamic custom receivers preserve real host-I/O suspension/effects/cleanup.
120public/35internal peractual11/10 focused Release pass; all29 whitespace scalars,
expansion/final sigma, retained aliases/first refusal/awaited cleanup, visible locals
and supplied separator/maxsplit semantics. No unsafe code/dependency changes.
One short existing-driver allocation diagnostic; one bounded quiet-VM source pair,
two copies of each core, same worker/normalGC/tiering, original complete lower report
and independent Python-confirmed upper variant, unchanged ordinary split/CSV/report
controls. Do not infer speedup from R92 or external ratios; retain adverse/uncertain data.
Full qualification is separate/batched at next coherent delivery; baseline full CI
currently independent. Objective remains open; publication/tagging postponed.
