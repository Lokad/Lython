from pathlib import Path
import ast,json,shutil,tarfile
r=Path(__file__).parent;old=r.parent/'direct-operands-r96/b457';b=r/'b459';b.mkdir()
source=json.loads((r/'identity.json').read_text(encoding='utf-8'));previous=json.loads((old/'identity.json').read_text(encoding='utf-8'))
jobs=[['scripts.text-summary-rsplit-helpers.large','warm'],['scripts.text-summary-rsplit-helpers.large','warm-async'],['scripts.text-summary-upper-rsplit-helpers.large','warm'],['scripts.text-summary-helpers.large','warm'],['scripts.csv-summary-functions.large','warm'],['scripts.report-render.large','warm-async']]
identity={**previous,'sourceRevision':source['candidateSource'],'baselineSource':source['baselineSource'],'coreSHA256':{role:source['coreSHA256']['before'if role.startswith('reference')else'candidate']for role in ['reference','reference-control','candidate','candidate-control']},'productionSources':source['productionSources'],'qualification':source['qualification'],'jobs':jobs}
(b/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8')
for name in ['collect.py','run.sh','retrieve.py','assess-vm.py','archive-owned.py','launch.py']:
 s=(old/name).read_text(encoding='utf-8').replace('direct-operands-b457-20261108','default-rsplit-b459-20261108').replace('lython-b457-direct-operands','lython-b459-default-rsplit').replace('direct-operands-b457-launch.py','default-rsplit-b459-launch.py')
 if name=='collect.py':
  a=s.index('jobs=');z=s.index('\nassert len(jobs)',a);s=s[:a]+'jobs='+repr(jobs)+s[z:]
  s=s.replace('R96 remove operand carrier/runtime arity reader and borrow synchronous metadata; same complete CSV/JSON/text/report scripts, current9d baseline with duplicated source controls','R99 shared default-rsplit cased-word preparation, intermediate cased-line storage removed; original lower and independent upper reports, ordinary split/CSV/report controls, current57e baseline with duplicated source controls')
 if name=='launch.py':
  s=s.replace("reference=base/'dedicated-comparison-b456-20261108/candidate'","reference=base/'direct-operands-b457-20261108/candidate'")
  needle=""" assert hashlib.sha256((reference/'Lokad.Lython.dll').read_bytes()).hexdigest()==identity['coreSHA256']['reference']
 os.link(reference/'Lokad.Lython.dll',root/'baseline-core.dll')"""
  assert needle in s;s=s.replace(needle," assert hashlib.sha256((root/'baseline-core.dll').read_bytes()).hexdigest()==identity['coreSHA256']['reference']")
  s=s.replace('lython-b443-fixtures','lython-b459-fixtures')
 if name=='archive-owned.py':s=s.replace("'shared-worker-common.json']","'shared-worker-common.json','space-maintenance.json']");s=s.replace('receipt=dict(complete=True',"assert shutil.disk_usage(root).free>240*1024*1024\nreceipt=dict(complete=True")
 (b/name).write_text(s,encoding='utf-8',newline='\n')
 if name.endswith('.py'):ast.parse(s)
for src,name in [(r/'images/candidate/Lokad.Lython.dll','current-core.dll'),(r/'images/before/Lokad.Lython.dll','baseline-core.dll'),(r/'catalog.json','representative.json'),(r/'identity.json','focused.json'),(r/'source.patch','source.patch'),(r/'pre-measurement-plan.md','pre-measurement-plan.md'),(old/'shared-worker-common.json','shared-worker-common.json'),(old/'setup-contract.json','setup-contract.json'),(r/'dedup-proof.json','space-maintenance.json')]:shutil.copyfile(src,b/name)
contract='''R99 one bounded source pair, unchanged worker/protocol/GC/tiering.
Baseline committedcbe88fef/core57e1ef6c, candidatecbe plus two compiler eligibility
changes. Same complete default-rsplit lower report and independently confirmed
upper report, ordinary split/CSV/report controls. Six jobs: lower sync/async,
upper sync, ordinary split sync,CSVsync,reportasync. Each core has two processes.
5s warmup/process/job,7x150ms rotated, coarse process CPU. Full stdout/file checks,
mediated RAM I/O/prior cleanup included; compilation/startup/staging/cache teardown
excluded. Upper async controlled timing unmeasured. Baseline final CI independent.
210s owner+30stop+30margin, persistent evidence, owned128MiB RAM only guest files.
240MiB OSfloor+7MiB evidence headroom+exact uncompressed payload required before
launch. Source/core/aux/Ready/goldens/quiet/Closed/exit/join/fixture/archive/local
verification gates required. Exact-byte hardlink maintenance preserved original
paths/aliases/content and every archive; proof accompanies raw data.
120public/35internal peractual11/10 pass; source/token/ownership unchanged at runtime.
Architecture/allocation distinct from CPU. Retain/correct/reject control debt
explicitly; all desktop adverse/unstable results retained. No framework/new backend,
new memory layer/unsafe code or quota. No objective closure/publication.
'''
(b/'contract.md').write_text(contract,encoding='utf-8')
with tarfile.open(b/'payload.tgz','w:gz')as a:
 for n in ['collect.py','run.sh','current-core.dll','baseline-core.dll','representative.json','identity.json','pre-measurement-plan.md','setup-contract.json','contract.md','focused.json','source.patch','shared-worker-common.json','archive-owned.py','space-maintenance.json']:a.add(b/n,arcname=n)
print('R99 B459 six jobs prepared; two uploaded exact cores and verified immutable auxiliary bytes.')
