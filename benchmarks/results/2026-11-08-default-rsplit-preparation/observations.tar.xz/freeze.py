from pathlib import Path
import base64,copy,hashlib,importlib.util,json,os,re,shutil,subprocess,tempfile
r=Path(__file__).parent;baseline=r.parent/'separated-split-r98'
d=json.loads((r.parent/'operand-cpython-r97/representative.json').read_text(encoding='utf-8'));cases={c['id']:c for c in d['cases']}
upper=copy.deepcopy(cases['scripts.text-summary-rsplit-helpers.large']);upper['id']='scripts.text-summary-upper-rsplit-helpers.large';upper['source']=upper['source'].replace('line.lower().rsplit()','line.upper().rsplit()')
assert upper['source']!=cases['scripts.text-summary-rsplit-helpers.large']['source']
spec=importlib.util.spec_from_file_location('protocol',r.parent/'operand-cpython-r97/retrieved/cpython-worker.py');protocol=importlib.util.module_from_spec(spec);spec.loader.exec_module(protocol)
fixture=json.loads(upper['fixtureJson'])
with tempfile.TemporaryDirectory(prefix='trusted-cpython-',dir=r.resolve())as owned:
 root=Path(owned)
 for name,data in fixture['inputFiles'].items():(root/name).write_bytes(base64.b64decode(data))
 done=subprocess.run(['C:/Python313/python.exe','-I','-S','-X','utf8','-c',upper['source']],cwd=root,text=True,encoding='utf-8',capture_output=True);assert done.returncode==0,done.stderr
 actual={name:(root/name).read_bytes()for name in fixture['outputFiles']}
 upper['expectedOutput']=done.stdout;upper['expectedFilesSha256']=protocol.file_digest(actual);fixture['outputFiles']={name:base64.b64encode(value).decode('ascii')for name,value in actual.items()}
upper['fixtureJson']=json.dumps(fixture,ensure_ascii=False,separators=(',',':'));upper['sourceUtf8Bytes']=len(upper['source'].encode());upper['expectedOutputUtf8Bytes']=len(upper['expectedOutput'].encode())
for field,digest in [('source','sourceSha256'),('fixtureJson','fixtureSha256'),('expectedOutput','expectedOutputSha256')]:upper[digest]=hashlib.sha256(upper[field].encode()).hexdigest()
d['cases']=[cases['scripts.text-summary-rsplit-helpers.large'],upper]+[cases[n]for n in ['scripts.text-summary-helpers.large','scripts.csv-summary-functions.large','scripts.report-render.large']]
assert len(d['cases'])==5
(r/'catalog.json').write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
checks={}
for name,expected in [('public-final11',120),('public-final10',120),('internal-final11',35),('internal-final10',35)]:
 s=(r/(name+'.log')).read_text(encoding='utf-8');assert 'Failed:     0'in s and re.search(r'Passed:\s+'+str(expected)+r'\b',s);checks[name]=expected
for role in ['before','candidate']:shutil.copytree(baseline/'images/candidate',r/'images'/role,copy_function=os.link)
core=r/'images/candidate/Lokad.Lython.dll';core.unlink();shutil.copyfile('src/Lokad.Lython/bin/Release/net11.0/Lokad.Lython.dll',core)
inventory={str(p).replace('\\','/'):hashlib.sha256(p.read_bytes()).hexdigest()for p in Path('src/Lokad.Lython').rglob('*')if p.is_file()and not {'bin','obj'}&set(p.parts)}
identity=dict(baselineSource='Committedcbe88fef/core57e1ef6c. Full CI42477957586 independent/in progress.',candidateSource='cbe88fef plus equivalent default-rsplit preparation, two compiler restrictions removed',coreSHA256={role:hashlib.sha256((r/'images'/role/'Lokad.Lython.dll').read_bytes()).hexdigest()for role in ['before','candidate']},productionSources=inventory,focusedChecks=checks,qualification='120public/35internal focused Release peractual11/10; expanded Unicode/custom suspended callbacks/terminal ownership conditions, supplied options and visible locals. Full retained-boundary qualification pending independently.')
assert identity['coreSHA256']['before'].startswith('57e1ef6c')
(r/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8')
(r/'source.patch').write_bytes(subprocess.check_output(['git','diff','--','src/Lokad.Lython']))
shutil.copyfile('PLAN.md',r/'pre-measurement-plan.md')
for name in ['measure.py','assess-local.py']:
 s=(baseline/name).read_text(encoding='utf-8').replace('Preserve original shared-construction prototype, suspended-context failure and all adverse/unstable controls.','Preserve all original conditions and adverse/unstable controls; changed source removes default-rsplit intermediate storage.')
 (r/name).write_text(s,encoding='utf-8')
selection='''R99: default no-argument whitespace rsplit is semantically identical to split.
Runtime already shares the forward scanner for unlimited rsplit. Consolidate the two
compiler eligibility checks and use the existing cased-word recipe/kernel. Remove the
unobservable cased UTF-8 line and second segmentation work from affected scripts.
No new operation/backend/owner/cache/configuration. Supplied arguments retain original
lowering. Dynamic custom receivers preserve real host-I/O suspension/effects/cleanup.
120public/35internal peractual11/10 focused Release pass; all29 whitespace scalars,
expansion/final sigma, retained aliases/first refusal/awaited cleanup, visible locals
and supplied separator/maxsplit semantics. No unsafe code/dependency changes.
One short existing-driver allocation diagnostic; one bounded quiet-VM source pair,
two copies of each core, same worker/normalGC/tiering, original complete lower report
and independent Python-confirmed upper variant, unchanged ordinary split/CSV/report
controls. Do not infer speedup from R92 or external ratios; retain adverse/uncertain data.
Full qualification is separate/batched at next coherent delivery; baseline full CI
currently independent. Objective remains open; publication/tagging postponed.
'''
(r/'selection.md').write_text(selection,encoding='utf-8')
print(json.dumps(identity['coreSHA256']),'Current source and focused checks verified; allocation/catalog prepared.')
