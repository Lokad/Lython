# Lokad.Lython 0.11.0

Updated 2026-11-08. Git-ignored; never force-add. Publication/tagging postponed.
Objective: coherent simplification and substantial complete-script performance.
Another isolated experiment does not finish that objective. Active work below;
historical narratives, rejected designs, original failed conditions and raw data
stay in benchmarks/EXPERIMENTS.md and results. Docs describe current implementation.

## Actual delivery status

| Milestone | Actual status |
| --- | --- |
| Compiler-fact correction, direct UTF-8 formatting/storage, native helper returns | Committed/fully qualified. Native returns allocation−19.92/−19.31%, original elapsed diagnostic. Formatting allocation−8.67%, controlled B102 elapsed/CPU−5–8%; original15.125ms adverse remains unexplained/preserved. No unchanged qualification replay. |
| Retained R62–R76 | Fully qualified; history preserves70267889,824fc6bb,7a81a629,f88191f7+a34f56b5,68d5bffe,33b6c191,79657355+c384956f,38f53c33/06651b11. Compiler facts/native calls/sequence/tuple storage, JSON floats, inline/final UTF-8 storage remain. R71 slower arenas/control/wide carriers, R72 coarseCPU+6.67%, R74 drift and all failed/adverse conditions remain evidence, not current performance claims. |
| R78/R79 | Fully qualified af481194+5b9d569a and913ea550: shared receiver declarations, callback/signature correctness fixes, native workstate before lexical contexts. Existing measured function optimizations preserved. Cached full-delivery receipts; details in EXPERIMENTS/results. |
| R80/R81 attribution; R82 prepared consumers | Attribution/source gates completed71445454; no unsupported namespace/value/accounting redesign selected. R82 production91f15a3e fully qualified CI42451722109; source consistency retained, allocation neutral, modest/mixed elapsed. |
| R77/R83 CPython checkpoints | Completed historical named-source38f53c33/91f15a3e comparisons; prior tables, inconclusive cases and failed conditions preserved. Current guide is R90 below. |
| R84/R85 | Canonical receivers02c76e52/coreaa4acebe, corrected7796a24f/corecc6b1b15 fully qualified CI42459221409. Failed original CI42457767068/logs retained. Corrected allocation45–52%lower; controlled elapsed22–24%lower belongs to earlier aa4, not cc6. Controls/debt remain explicit in results. |
| R86/R87/R88 | Complete CSV/helper/generated-code source gates committed7796a24f+16e14ee0; B449 terminal/archived/verified. No binder dominance or causal CPU claim. Existing record adoption/keys/batched fields remain. Text source-shape diagnostic selected the next coherent preparation cleanup, not a new arena/engine. |
| R89 | Committed/pushedac5aea97/core6a098198, fully qualified CI42463155006.397internal/2165public focused per actual11/10, both OSes/originalStress/installed core green. B451 affected elapsed−11–19%, CPU agrees, allocation neutral. Fused/report inconclusive, possible CSV+0.42–1.03% debt accepted. All initial/refined/adverse source/evidence preserved. |
| R90 | B452 complete:26jobs538.681s at committedac5aea97/core6a098198, CPython3.13.16. All gates/archive/local verification pass; no active users/fixtures. Current primary guide updated: separate compile/warm/result and I/O/cleanup, exact machine/source. Warm rsplit1.80×, guarded2.15×; other ordinary warm about1.00–1.67×. No single-change attribution or objective closure. |
| R91 source gate | Ordinary integer formatting already native UTF-8 on11/stack bridge10; valid escaped JSON already CopyString UTF-8. Large-integer JSON conversion remains outside ordinary fixtures. Builtin slots retain per-run owner/live namespace identity, so simple global sharing is invalid. No new cache/lazy-owner subsystem or prototype selected from this pass. |
| R92 | Committed/pushed05d81b83/core68f63d29, fully qualified CI42467357131 cached green09:50UTC: Windows/Ubuntu actual11/10, originalStress and installed consumers. B453168.220s all gates/archive/local verification pass. Guarded allocation-12.74%, elapsed sync-3.48to-4.84%/async-6.78to-8.01%, CPU agrees. Other text controls inconclusive; CSV-0.26to+1.07% possible debt. Frontend elapsed and original adverse desktop async remain uncertain/preserved. |
| R93/R94 | Completed bounded source/CPU/allocation selection gates, no further runtime prototype. Final workspace/locals/presence/context deferral and native CSV bulk scanning already exist; no duplicate common binding phase selected. Current1092guestCPU samples/51unknown(4.67%) show distributed execution work. Sampled BigInteger21.61/27.13% text/CSV, Boolean7.25%CSV; not exact bytes/CPU causality. Evidence in results/EXPERIMENTS. |
| R95 | Committed/pushedcb2b015e/core9d30623c, fully qualified CI42472284713 cached green11:10UTC: both OSes/actual11/10/originalStress/installed consumers. B455/B456 all evidence preserved. Retained CSVsync-5–9%, async-10–16%(variable), JSON-6–8%, returnedCSV-3–8%; allocationCSV-3.72%sync/-15.25%async. Text+1.28–3.50%elapsed/CPU0–2.90% retained debt, report inconclusive. No objective closure. |
| R96 | Committed/pushed94cb8963/cored6254b2e; carrier/reader/runtime arity projection removed, synchronous metadata borrowed.62public/24internal peractual11/10 pass. B457168.421s all gates/archive/local verification pass. Allocation neutral; CSV/JSON elapsed favorable, text favorable but8.70%old spread limits precision, report+0.88–3.65%possible elapsed debt/mixedCPU. Fully qualified CI42475420182, cached green11:48UTC: Windows/Ubuntu actual11/10, originalStress and installed consumers. R95 text debt remains separate. |
| R97 | Committedfa995d65, B458 completed26jobs539.873s at94cb8963/cored6254b2e, CPython3.13.16; all gates/archive/local verification pass. Separate compile/warm/result and included I/O/cleanup in current guide. WarmCSV1.07×, JSON0.90–0.91×, returnedCSV1.24–1.25×, rsplit1.80×, guarded2.01–2.02×; report/control variability visible. Independent full CI42475420182 green. No causal attribution or debt repayment. |
| R98 | Committed/pushedcbe88fef/core57e1ef6c,150public/35internal peractual11/10 pass. Explicit split/rsplit share existing admitted final construction/search; temporary list/reversal/conversion/copied backing and duplicate forward builders removed. Original67KB-before-refusal red reproduced; complete preflight now precedes fragments. Full delimiter reports allocation−5.47%forward/−8.91–8.92%reverse; desktop elapsed inconclusive/adverse, controls drift4–20%. Real suspended __index__ cancellation gap reproduced/fixed by explicit current context; old2e prototype/source/diagnostics preserved. Full retained-boundary delivery dispatched, pending independently. |
| Regex R68 | Exact immutable0.5.0-dev.55/d6067925:86internal/514public per actual11/10, unchanged bridge. Development compatibility only. Normal optional0.4 pin/core unchanged; affected final released adapter qualification pending, independent implementation continues. |

Completed milestones and original evidence remain in benchmarks/EXPERIMENTS.md
and linked results; the table is delivery status, not a replay queue.
Latest fully qualified runtime94cb8963/cored6254b2e, CI42475420182 green/cached
11:48UTC: Windows/Ubuntu actual11/10, originalStress and installed consumers.
R98 is separately focused-qualified, not covered by this older CI. CI42475420182/
42472284713/42467357131/42463155006/42459221409/42457767068 and B450-B458 are terminal/
cached, never requery. All VM users/fixtures joined/removed; archives locally verified.
Never requery/re-dispatch terminal runs or imply they qualify later changes.
Allocation reduction, elapsed, coarseCPU and embedding latency are distinct.
R76's float debt and R79's CSV debt are separately accepted; unrelated gains do
not repay them. Preserve native-text/report/control uncertainty and adverse originals.

## Active deliverables

0. **R98 retained construction milestone.** Source/focused checks, original red,
   failed build/oracle conditions and complete-script allocation evidence are
   recorded in results/EXPERIMENTS. Batch its Windows/Ubuntu actual11/10, original
   Stress and installed-core delivery at this coherent source freeze. Qualification
   must identify this source; R96's green receipt does not certify it. No timing
   gain asserted from unstable desktop controls, no whitespace-gap closure.

1. **R96/R97 closed.** Full source94cb8963 and representative CPython checkpoint
   are independently qualified/recorded. Preserve variable report/control evidence,
   R95 text debt and R96 possible report debt. No repeated collection or old CI polls.

2. **Continue the substantial roadmap.** Completed R89/R92 and attribution gates
   do not close the performance objective. R93 finds ordinary presence/workspace/
   locals/context simplifications already delivered; CPU shows no binder dominance.
   Do not revive slower arenas/control carriers or old bulk CSV copying. Native CSV
   already scans chunks/compacts input/batches fields. R91 confirms ordinary integer
   formatting and valid escaped JSON use native UTF-8, while per-run builtin owners
   prohibit simple global sharing. Select a complete removable phase below, not
   another measurement/ownership audit. R97/94cb8963 is the current CPython
   checkpoint; refresh at combined milestones, not after every tweak.

3. **R99: remove redundant cased-line materialization for default rsplit.**
   Source pass finds two split-only compiler eligibility checks, in
   ExecutableScript.CasedSplits.cs and NativeReturns.cs. Runtime unlimited
   whitespace rsplit already uses the same forward planner as split; the existing
   cased-word kernel and recipe need no new operation/state. Let default zero-
   argument rsplit reuse that preparation, eliminating its intermediate cased UTF-8
   line and separate casing/splitting work. This is an eligibility consolidation,
   not another backend, type cache or special runtime loop. R97 ordinary rsplit
   remains1.80×CPython; R92 establishes the existing pipeline's usefulness, not a
   prediction of this source pair's CPU benefit.

   Affected: complete ordinary rsplit helper reports, upper/lower/default whitespace
   chains in helpers/branches/protected bodies. Preserve all29 Python whitespace
   scalars, expansions/final sigma, evaluation order/source spans, custom receivers
   and genuine suspended callbacks, aliases and first-refusal/cancellation unwind.
   Explicit separators or supplied maxsplit must retain their proper original
   semantics; do not equate bounded right splitting with forward splitting.
   Extend existing semantic/custom-protocol/ownership cases to both method names.
   One short allocation diagnostic and bounded quiet-VM complete-script comparison
   with duplicated source controls; retain adverse/variable originals. Observe
   storage/lease/archive preflights and reuse immutable workers/cores; never discard
   evidence to make room. Stop/refine if this needs another fused backend, new
   ownership mechanism or changes exposed call behavior. Batch its final platform/
   Stress/installed-consumer qualification with the next coherent delivery.
   Then resume call/frame/value/frontend roadmap selection; this phase does not
   close the remaining performance objective. No CPython replay after each edit.

4. **Independent regex track.** Core Python/native UTF-8 work remains independent.
   Published producer gaps defer only affected final adapter qualification. Supplied
   dev55 remains newest locally; exact qualification/bridges unchanged. No sibling
   edits/builds or repeat unchanged qualification. Publication/tagging postponed.

## Following substantial redesign boundaries

| Boundary | Selection and acceptance |
| --- | --- |
| Remaining calls/operand/scalar dispatch | Indexed operands/native returns/final slots and native workstate dispatch exist. Find a demonstrated complete remaining binding/transport or numeric phase; avoid pools/arenas and duplicated control routes already measured slower. Exact integer promotion, identity/type/projection, callbacks, reentry and alias funding must hold. Machine-integer handling is a hypothesis until current attribution supports its scope; no universal tagged-value replacement. |
| Per-record construction | Current source gate: shared RecordKeys and exclusive funded row-array adoption already remove the old bulk proposal's copying/key phase; it cannot be revived unchanged. Preserve its6–8% improvement/adverse control. Remaining identity checks protect mutable headers and admission reentry; no mutation-version inventory without current measured dominance. Select a genuinely remaining construction phase; preserve hooks/order/escaping aliases. |
| Remaining bulk text/JSON | Direct casing/lower-split/formatting/native parsing, JSON loop/shared scanner and final UTF-8 storage retained. Select a whole remaining conversion/storage phase, preserving Unicode/context/hooks/async I/O. Ordinary R61 JSON has no escaped tokens; do not optimize hypothetical dominance or add a name-marker series. |
| Frontend facts | R55/R58/R62/R65 already remove lexical/graph/validity/module work. Select demonstrated repeated analysis in compile-to-result workloads; preserve class/function/annotation scope and exact diagnostics, then delete displaced analysis. No speculative visitor/cache/parser/JIT project. |

Bounded confirmation/refinement or measurement correction is allowed when evidence
justifies it. Timeout, unstable unchanged control or inconclusive results establish
uncertainty, not a permanently failed design. Keep original failed conditions and
adverse results. Fixed percentages inform judgment, never automatically veto useful
simplification. Temporary regressions require an explicit completion milestone and
retain/correct/reject decision on remaining debt. Batch CPython refreshes at coherent
combined checkpoints with exact source/date/machine and separate compile, warm,
compile-to-result/startup; include I/O/validation/cleanup boundaries and uncertainty.
Current guide accurately names source94cb8963; do not remeasure after every tweak.

## Independent regex deliverable

Core owns Python/native UTF-8 semantics: byte ranges/scalar positions/original
subject windows, flags/captures/replacements/errors, cache ownership/current tokens
and one provider through frontend/runtime/imports. Core has no Utf8Regex dependency;
adapter remains nonpackable. Contract tests, semantic compatibility and actual
backend performance are separate. Immutable development producers/adapter-local
bridges support development; missing publication does not stop independent work.

Exact dev55 gaps: DetailedData lacks separate preparation/working ownership;
native name lookup lacks enumeration; cursor creation retains its token despite
per-move tokens. Both dev55 package SHAs rechecked bit-identical08:04UTC; no
new supplied version or repeat qualification. Existing bridges remain justified. Qualify the final released
package's semantics, managed safety and actual performance when available. Normal
adapter0.4 pin unchanged pending justified promotion. No sibling edits/builds,
producer-CI replay, dialect fallback, quotas, memory subsystem or abandoned matching.

## Lasting constraints / checks

AGENTS.md governs fully managed safety/managed stack admission: no unsafe/Unsafe,
PInvoke/pointers/native probes. Preserve host capabilities, current cancellation,
checked representation bounds, XML depth, bounded I/O chunks and admitted projection.
Borrow shared allowance for coarse capacity/preflight/replacement storage; fund
retained aliases/caches/results and pending users until awaited cleanup. No caps,
hidden allowances/fuel/quotas/tracing/weak reclamation/forced GC. Initial streaming
uses host batches. First refusal is terminal through suppression/finally; never
retry or skip optional storage. Keep native refunds/cleanup available and awaited.

Focused Release iteration; matching probes when needed and explicit Stress exclusion
with custom filters. No overlapping local builds/tests/measurements; force a fresh
build after timestamp-preserving restores. Batch actual11/10 Windows/Ubuntu,
original Stress and installed consumers at retained boundaries. Explicit UTF-8.
Only core explicit Release pack to artifacts/nuget; no adapter packages/publication.
VM lokad@20.166.121.73,key ~/.ssh/id_lython-bench.pem. B443 terminal/archived/
locally verified; no active user/fixture mount, never requery. Persistent evidence
separate from owned RAM; join/unmount/archive under lease and verify locally.
One byte-identical worker DLL was atomically hardlinked, freeing56MB while keeping
all paths/bytes/cores/sources/archives. No future deletion inferred. CI observations
>=5minutes apart; cached terminal runs never requeried or duplicate-dispatched.
