R99 one bounded source pair, unchanged worker/protocol/GC/tiering.
Baseline committedcbe88fef/core57e1ef6c, candidatecbe plus two compiler eligibility
changes. Same complete default-rsplit lower report and independently confirmed
upper report, ordinary split/CSV/report controls. Six jobs: lower sync/async,
upper sync, ordinary split sync,CSVsync,reportasync. Each core has two processes.
5s warmup/process/job,7x150ms rotated, coarse process CPU. Full stdout/file checks,
mediated RAM I/O/prior cleanup included; compilation/startup/staging/cache teardown
excluded. Upper async controlled timing unmeasured. Baseline final CI independent.
210s owner+30stop+30margin, persistent evidence, owned128MiB RAM only guest files.
240MiB OSfloor+7MiB evidence headroom+exact uncompressed payload required before
launch. Source/core/aux/Ready/goldens/quiet/Closed/exit/join/fixture/archive/local
verification gates required. Exact-byte hardlink maintenance preserved original
paths/aliases/content and every archive; proof accompanies raw data.
120public/35internal peractual11/10 pass; source/token/ownership unchanged at runtime.
Architecture/allocation distinct from CPU. Retain/correct/reject control debt
explicitly; all desktop adverse/unstable results retained. No framework/new backend,
new memory layer/unsafe code or quota. No objective closure/publication.
