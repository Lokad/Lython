text=' A  B  C '
print(text.lower().rsplit(None,1))
print(text.upper().rsplit(' ',1))
def visible(value):
 cased=value.lower()
 parts=cased.rsplit()
 return parts,locals()['cased']
print(visible(text))
