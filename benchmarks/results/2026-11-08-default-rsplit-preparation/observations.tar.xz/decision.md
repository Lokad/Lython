Retain R99: the existing prepared cased-word pipeline applies to default zero-
argument whitespace rsplit. Two compiler restrictions removed, no runtime path added.
Lower complete report allocation-16.46%, upper-11.88% across both APIs. Controlled
B459 same exact sourcepair57e/3fb, six complete jobs167.959s. Lower sync elapsed
-14.19to-16.70%, async-12.88to-13.44%, upper sync-7.85to-11.77%; coarseCPU agrees.
Lower baseline spread2.05%, upper2.53%, two current controls below1.77%.
Ordinary split control-1.04to-4.15% with mixedCPU/baseline2.67%spread; not causal gain.
CSV-0.12to-1.31% nearbaseline/mixedCPU; report-3.94to+2.69%, baseline5.77%spread,
mixedCPU/inconclusive. Preserve desktop adverse report/ordinary-split and 49%baseline
async drift, all raw conditions. No fixed-percentage veto, no universal CPU claim.
120public/35internal focused Release peractual11/10; full retained-boundary pending.
Do not repay R95 text/R96report/R98desktop uncertainty from this newer sourcepair.
Current external CPython guide remains named94cb8963; no per-edit external replay.
B459 terminal/archived/localverified, all workers joined/guest RAM unmounted; never
requery/restart. Exact-byte maintenance freed27975680B while preserving all source
paths/aliases/bytes and archives, proof in raw. Publication/tagging deferred.
Regexdev55 rechecked byte-identical, normal0.4 adapter unchanged, no qualification replay.
