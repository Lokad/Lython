from pathlib import Path
import hashlib,json,shutil,tarfile
r=Path(__file__).parent;identity=json.loads((r/'identity.json').read_text(encoding='utf-8'))
assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==h for p,h in identity['productionSources'].items())
b=r/'b459';receipt=json.loads((b/'archive-receipt.json').read_text(encoding='utf-8'));assert receipt['complete']and receipt['jobs']==6
assert hashlib.sha256((b/'observations.tgz').read_bytes()).hexdigest()==receipt['archiveSHA256']
vm=json.loads((b/'assessment.json').read_text(encoding='utf-8'));assert vm['complete']and len(vm['jobs'])==6
local=json.loads((r/'assessment-local.json').read_text(encoding='utf-8'))
for lane in ['warm-sync','warm-async']:
 assert len(local[lane])==5
out=Path('benchmarks/results/2026-11-08-default-rsplit-preparation');out.mkdir()
(r/'tested-tests').mkdir()
for path in ['tests/Lokad.Lython.PublicApi.Tests/CasedWhitespacePipelineTests.cs','tests/Lokad.Lython.Tests/CasedSplitOwnershipTests.cs']:shutil.copyfile(path,r/'tested-tests'/Path(path).name)
decision='''Retain R99: the existing prepared cased-word pipeline applies to default zero-
argument whitespace rsplit. Two compiler restrictions removed, no runtime path added.
Lower complete report allocation-16.46%, upper-11.88% across both APIs. Controlled
B459 same exact sourcepair57e/3fb, six complete jobs167.959s. Lower sync elapsed
-14.19to-16.70%, async-12.88to-13.44%, upper sync-7.85to-11.77%; coarseCPU agrees.
Lower baseline spread2.05%, upper2.53%, two current controls below1.77%.
Ordinary split control-1.04to-4.15% with mixedCPU/baseline2.67%spread; not causal gain.
CSV-0.12to-1.31% nearbaseline/mixedCPU; report-3.94to+2.69%, baseline5.77%spread,
mixedCPU/inconclusive. Preserve desktop adverse report/ordinary-split and 49%baseline
async drift, all raw conditions. No fixed-percentage veto, no universal CPU claim.
120public/35internal focused Release peractual11/10; full retained-boundary pending.
Do not repay R95 text/R96report/R98desktop uncertainty from this newer sourcepair.
Current external CPython guide remains named94cb8963; no per-edit external replay.
B459 terminal/archived/localverified, all workers joined/guest RAM unmounted; never
requery/restart. Exact-byte maintenance freed27975680B while preserving all source
paths/aliases/bytes and archives, proof in raw. Publication/tagging deferred.
Regexdev55 rechecked byte-identical, normal0.4 adapter unchanged, no qualification replay.
'''
(r/'decision.md').write_text(decision,encoding='utf-8')
with tarfile.open(out/'observations.tar.xz','w:xz')as archive:
 for p in sorted(r.iterdir()):
  if p.name=='images':continue
  if p.name=='b459':
   for child in sorted(p.iterdir()):
    if child.name not in ['retrieved','baseline-core.dll','current-core.dll','payload.tgz']:archive.add(child,arcname='b459/'+child.name)
  else:archive.add(p,arcname=p.name)
with tarfile.open(out/'observations.tar.xz')as archive:
 nested=archive.extractfile('b459/observations.tgz').read();assert hashlib.sha256(nested).hexdigest()==receipt['archiveSHA256']
for src,name in [(r/'identity.json','identity.json'),(r/'assessment-local.json','allocation-and-local.json'),(b/'assessment.json','controlled-comparison.json')]:shutil.copyfile(src,out/name)
status=dict(status='Retained source/focused checks and controlled comparison pass. Full retained-boundary qualification pending independently.',coreSHA256=identity['coreSHA256'],focusedChecks=identity['focusedChecks'],archiveSHA256=hashlib.sha256((out/'observations.tar.xz').read_bytes()).hexdigest(),controlledArchiveSHA256=receipt['archiveSHA256'],noRemainingVMUsersOrFixtures=True,referenceGuideSource='94cb8963')
(out/'status.json').write_text(json.dumps(status,indent=2)+'\n',encoding='utf-8')
readme='''# Default-rsplit cased-word preparation — 2026-11-08

Retain the existing cased-word pipeline for default zero-argument whitespace
rsplit. Two compiler eligibility checks no longer restrict it to split. The runtime
already uses the same unlimited-whitespace planner; no new operation/backend,
owner/pool/cache/configuration or execution route. Affected chains avoid the
intermediate cased UTF-8 line and separate casing/splitting work.

Baseline committedcbe88fef/core57e1ef6c; candidatecbe88fef plus archived two-file
compiler patch/core3fb37cc3. Complete hashes/production inventory in identity.json.
Informational source metadata names the precommit baseline. Full retained-source
platform/Stress/installed-core qualification is separate/pending. The primary
CPython guide remains the recorded94cb8963 checkpoint.

| Complete helper report | Allocation sync / async | Controlled elapsed, all four median pairings |
| --- | ---: | ---: |
| Default lower-rsplit, sync |−16.46% / —|−14.19 to −16.70%|
| Default lower-rsplit, async API |— / −16.46%|−12.88 to −13.44%|
| Default upper-rsplit, sync |−11.88% / —|−7.85 to −11.77%|

Upper async allocation is also−11.88%; its controlled elapsed is unmeasured.
Coarse process CPU agrees on all affected jobs. Baseline spreads2.05%lower-sync/
0.01%lower-async/2.53%upper; candidate spreads0.94/0.64/1.77%. These are short
controlled observations, not confidence intervals or universal CPU gains.

Unchanged ordinary-split control elapsed−1.04to−4.15%, mixedCPU/baseline2.67%spread:
no attributable gain. CSV−0.12to−1.31%, CPU mixed/near baseline. Report−3.94to+2.69%,
baseline5.77%spread/mixedCPU, inconclusive. Every adverse desktop observation and
original49%async-baseline drift is retained. R95 text/R96 report/R98 desktop debt
or uncertainty is not repaid by this different newer source pair.

All reports read the complete maintained fixture, aggregate words through an
ordinary helper and write the full output. Lower/ordinary text:3072lines/35840B;
upper is the same input, independently confirmed with isolated local CPython and
full stdout/file goldens. Existing worker7cf37ca5, optional0.4 adapter, actual.NET11RC3,
quietUbuntu24.04.4/F4as_v7,4EPYC9V45vCPUs/16GiB/noswap. NormalGC/tiering,5s warmup
per process/job, two independent copies of each core,7rotated150ms rounds. Six
jobs167.959s. Command-v2 includes complete execution/mediated RAM I/O/full output
checks/prior-result cleanup; compilation/startup/staging/final cached teardown
excluded. I/O completes inline; genuine suspension is tested separately.

120public/35internal focused Release peractual11/10 pass. Existing independent
Unicode inventory and terminal-ownership tests now cover both method names:
all29 Python whitespace scalars, expansions/final sigma, aliases/result owners,
refusal/cancellation/cleanup, helpers/branches/protected bodies. Custom methods
retain real suspended host reads and exact file-close counts. A separate Python
oracle preserves supplied maxsplit/separators and visible cased locals; only
zero-argument defaults qualify.

All source/core/auxiliary/Ready/golden/quiet/Closed/exit/join/fixture/archive/local
verification gates pass. B459 is terminal/cached, no remaining users or fixtures.
Persistent data remain separate from owned RAM. A bounded exact-byte hardlink
operation recovered27975680B while retaining every original path/alias/content and
all archives; fresh pre/post proof is included. Raw collection verified240MiB
OSfloor+7MiB headroom and actual payload before launch. No evidence was discarded.

[Controlled results](controlled-comparison.json), [allocation/desktop evidence](allocation-and-local.json),
[identity](identity.json), [status](status.json), [sources/cores/logs/raw](observations.tar.xz).
'''
(out/'README.md').write_text(readme,encoding='utf-8',newline='\n')
p=Path('benchmarks/EXPERIMENTS.md');s=p.read_text(encoding='utf-8')+'''
[R99/B459](results/2026-11-08-default-rsplit-preparation/README.md) lets default
zero-argument rsplit share the existing cased-word preparation, removing two compiler
restrictions and intermediate cased-line storage; no new runtime machinery.
Complete lower report allocation−16.46%, upper−11.88% across both APIs. Controlled
lower elapsed−14.19to−16.70%sync/−12.88to−13.44%async, upper−7.85to−11.77%sync;
coarseCPU agrees. Ordinary-split control variable/mixedCPU, CSV nearbaseline,
report−3.94to+2.69%/baseline5.77%spread inconclusive. Original desktop adverse and
49%async-baseline drift remain preserved.120public/35internal peractual11/10 pass,
including all29 whitespace scalars, real suspended custom methods/exact closes,
aliases/first refusal/cleanup and supplied-option/visible-local Python oracle.
B459167.959s all gates/archive/local verification pass; no users/fixtures. Full
retained-source delivery pending independently; old source debts remain distinct.
'''
p.write_text(s,encoding='utf-8',newline='\n')
p=Path('docs/BENCHMARKS.md');s=p.read_text(encoding='utf-8');needle='| Shared split construction / delimiter reports |';a=s.index(needle)
s=s[:a]+'| Shared default-rsplit preparation / text reports | Lower allocation −16.46%, upper −11.88%; controlled lower elapsed −14–17% sync/about−13% async, upper −8–12%; coarse CPU agrees | Existing kernel reused; no new runtime mechanism. Report control inconclusive; full retained-source delivery pending. [R99](../benchmarks/results/2026-11-08-default-rsplit-preparation/README.md) |\n'+s[a:];p.write_text(s,encoding='utf-8',newline='\n')
p=Path('PLAN.md');s=p.read_text(encoding='utf-8');needle='| Regex R68 |';a=s.index(needle);s=s[:a]+'''| R99 | Retained uncommitted sourcecbe+two-file patch/core3fb37cc3;120public/35internal peractual11/10 pass. Default rsplit reuses existing cased-word kernel; intermediate cased-line storage removed, no new runtime machinery. B459167.959s all gates/archive/local verification pass; lower allocation−16.46%, upper−11.88%; controlled lower elapsed−14–17%sync/about−13%async, upper−8–12%sync, coarseCPU agrees. Ordinary-split/report controls inconclusive, CSVnearbaseline. All desktop adverse/49%oldasync drift preserved. Full retained-source delivery pending independently. |
'''+s[a:]
s=s.replace('and B450-B458 are terminal/','and B450-B459 are terminal/')
a=s.index('3. **R99:');z=s.index('4. **Independent regex',a);s=s[:a]+'''3. **R99 retained; commit and batch delivery.** Exact source/core, semantic and
   controlled evidence recorded in results/EXPERIMENTS. Preserve supplied options,
   visible locals, real suspended custom methods/exact closes and aliases/terminal
   refusal. No retiming or CPython replay required: affected elapsed/CPU support
   retention, controls/debts remain distinct. Commit this coherent two-restriction
   consolidation; qualify its exact source at the next retained delivery boundary.
   Then continue a substantial call/frame/value/frontend phase below; this
   milestone does not close the broader performance objective.

'''+s[z:]
s=s.replace('Both dev55 package SHAs rechecked bit-identical08:04UTC; no','Both dev55 package SHAs rechecked bit-identical12:10UTC; no')
p.write_text(s,encoding='utf-8',newline='\n')
print('R99 retained with scoped controlled CPU/allocation evidence; archive SHA256',status['archiveSHA256'])
