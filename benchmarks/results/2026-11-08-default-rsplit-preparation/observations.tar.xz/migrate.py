from pathlib import Path
import shutil
r=Path(__file__).parent
paths=['src/Lokad.Lython/Frontend/ExecutableScript.CasedSplits.cs','src/Lokad.Lython/Frontend/ExecutableScript.NativeReturns.cs','tests/Lokad.Lython.PublicApi.Tests/CasedWhitespacePipelineTests.cs','tests/Lokad.Lython.Tests/CasedSplitOwnershipTests.cs']
for name in paths:
 p=Path(name);q=r/'before'/p.name;q.parent.mkdir(parents=True,exist_ok=True);assert not q.exists();shutil.copyfile(p,q)
p=Path(paths[0]);s=p.read_text(encoding='utf-8');old='Names[instructions[consumer - 1].NameIndex] != "split"';assert s.count(old)==1;s=s.replace(old,'Names[instructions[consumer - 1].NameIndex] is not ("split" or "rsplit")');p.write_text(s,encoding='utf-8',newline='\n')
p=Path(paths[1]);s=p.read_text(encoding='utf-8');old='ReferenceEquals(method, LythonRuntime.StringMembers.GetMethod("split"))';assert s.count(old)==1;s=s.replace(old,'member is "split" or "rsplit"');p.write_text(s,encoding='utf-8',newline='\n')
p=Path(paths[2]);s=p.read_text(encoding='utf-8');old='        })\n        using (var script';assert s.count(old)==2;s=s.replace(old,'        }.SelectMany(source => new[] { source, source.Replace(".split()", ".rsplit()") }))\n        using (var script')
s=s.replace('[InlineData(null)]\n    [InlineData("/lower")]\n    [InlineData("/split")]','[InlineData(null, false), InlineData(null, true)]\n    [InlineData("/lower", false), InlineData("/lower", true)]\n    [InlineData("/split", false), InlineData("/split", true)]').replace('CustomMethodsKeepRealSuspensionOrderAndAwaitedCleanup(string? cancelAt)','CustomMethodsKeepRealSuspensionOrderAndAwaitedCleanup(string? cancelAt, bool reverse)')
a=s.index('    public async Task CustomMethodsKeepReal');b=s.index('        const string source =',a);s=s[:b]+s[b:].replace('        const string source =','        var source =',1)
a=s.index('        var budget =',b);s=s[:a]+'''        if (reverse) source = source.Replace("def split(", "def rsplit(").Replace(".split()", ".rsplit()");
'''+s[a:]
p.write_text(s,encoding='utf-8',newline='\n')
p=Path(paths[3]);s=p.read_text(encoding='utf-8');old='        })\n        {';assert s.count(old)==1;s=s.replace(old,'        }.SelectMany(source => new[] { source, source.Replace(".split()", ".rsplit()") }))\n        {');p.write_text(s,encoding='utf-8',newline='\n')
print('Two compiler restrictions consolidated; existing Unicode/aliases/terminal-refusal/suspended callbacks cover both equivalent default spellings. No runtime mechanism added.')
