from pathlib import Path
import json,subprocess
r=Path(__file__).parent
source="""text=' A  B  C '
print(text.lower().rsplit(None,1))
print(text.upper().rsplit(' ',1))
def visible(value):
 cased=value.lower()
 parts=cased.rsplit()
 return parts,locals()['cased']
print(visible(text))
"""
done=subprocess.run(['C:/Python313/python.exe','-I','-S','-X','utf8','-c',source],capture_output=True,text=True,encoding='utf-8');assert done.returncode==0,done.stderr
(r/'supplied-options.py').write_text(source,encoding='utf-8');(r/'supplied-options.expected').write_text(done.stdout,encoding='utf-8')
method='''
    [Fact]
    public async Task SuppliedOptionsAndVisibleCasedLocalsKeepPythonSemantics()
    {
        const string source = SOURCE;
        const string expected = EXPECTED;
        var budget = new LythonMemoryBudget(4 * 1024 * 1024);
        using (var script = new LythonEngine().Compile(source, budget))
        {
            Assert.True(script.IsValid);
            var baseline = budget.ReservedBytes;
            foreach (var asynchronous in new[] { false, true })
            {
                using (var result = asynchronous ? await script.RunAsync(new MockLythonHost()) : script.Run(new MockLythonHost()))
                {
                    Assert.True(result.Success, result.Failure?.Message);
                    Assert.Equal(expected, result.StandardOutput);
                }
                Assert.Equal(baseline, budget.ReservedBytes);
            }
        }
        Assert.Equal(0, budget.ReservedBytes);
    }
'''.replace('SOURCE',json.dumps(source,ensure_ascii=False)).replace('EXPECTED',json.dumps(done.stdout,ensure_ascii=False))
p=Path('tests/Lokad.Lython.PublicApi.Tests/CasedWhitespacePipelineTests.cs');s=p.read_text(encoding='utf-8');a=s.rfind('}');s=s[:a]+method+s[a:];assert s.count('Assert.True(host.ClosedFileCount > 0);')==1;s=s.replace('Assert.True(host.ClosedFileCount > 0);','Assert.Equal(cancelAt == "/lower" ? 1 : 2, host.ClosedFileCount);');p.write_text(s,encoding='utf-8',newline='\n')
print('Independent Python options/locals oracle added; real callback cleanup counts strengthened.')
