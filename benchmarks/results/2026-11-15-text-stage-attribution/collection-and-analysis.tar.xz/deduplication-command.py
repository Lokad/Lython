from pathlib import Path
import fcntl,hashlib,json,os,shutil,stat,subprocess,tarfile
proof=[{'commit': 'b4e98b91062034f89b6a4c8823a1e8c1c6f47bb0', 'canonicalArchive': 'benchmarks/results/2026-11-15-shared-executable-slots/phase-one/observations.tgz', 'remoteRoot': 'shared-slots-b762-20261115', 'archiveSHA256': '1f4f76d84ad575339c931a7bc43ce92a429d51e0ded9ed663a802f8dd211e482', 'member': 'confirmation/confirmation.json', 'bytes': 662478, 'sha256': '92f42b9d5857dd725a7ec8136c401f942c3eb6d4f84fbe159588b4c24bbd0cd3'}, {'commit': 'b4e98b91062034f89b6a4c8823a1e8c1c6f47bb0', 'canonicalArchive': 'benchmarks/results/2026-11-15-shared-executable-slots/completed-layout/observations.tgz', 'remoteRoot': 'shared-slots-b763-20261115', 'archiveSHA256': 'dd06cc672077305c6ddb99fa85b7d570329274dada28a3895feaf3b40737dd04', 'member': 'confirmation/confirmation.json', 'bytes': 663381, 'sha256': 'e0a577d268b5d1b9c572ab9572d9545ffb68af3b86483de55c0cf57a3d78f2b3'}]
required=21896
base=Path('/home/lokad/lython-bench-checks').resolve()
with(base/'comparison-vm.lock').open('a')as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record|[p]ython3.*cpython-worker.py'],capture_output=True).returncode==1
 assert not any(p.is_mount()for p in base.glob('*/guest-fixtures'))
 paths=[];observations=[]
 for item in proof:
  root=base/item['remoteRoot'];p=root/item['member'];archive=root/'observations.tgz'
  assert root.resolve()==root and p.resolve()==p and archive.resolve()==archive and p.is_relative_to(base)
  s=p.lstat();assert stat.S_ISREG(s.st_mode)and s.st_uid==os.getuid()and s.st_nlink==1 and s.st_size==item['bytes']
  assert hashlib.sha256(p.read_bytes()).hexdigest()==item['sha256']
  assert hashlib.sha256(archive.read_bytes()).hexdigest()==item['archiveSHA256']
  with tarfile.open(archive)as a:assert hashlib.sha256(a.extractfile(item['member']).read()).hexdigest()==item['sha256']
  assert(root/'exit-code.txt').read_text().strip()=='0'and json.loads((root/'archive-receipt.json').read_text())['complete']
  paths.append(p);observations.append(dict(path=str(p),uid=s.st_uid,inode=s.st_ino,links=s.st_nlink,bytes=s.st_size,archiveStillPresent=str(archive)))
 before=shutil.disk_usage(base).free
 assert before+sum(item['bytes']for item in proof)>254*1024*1024+required+32768
 for p in paths:p.unlink()
 receipt=dict(committedProof=proof,metadata=observations,allPathsMetadataAndRawArchiveHashesVerifiedBeforeMutation=True,idleLease=True,retiredOnlyDuplicateJson=[str(p)for p in paths],beforeFreeBytes=before,afterFreeBytes=shutil.disk_usage(base).free,compressedRawArchivesAndLocalGitEvidenceRetained=True,currentImagesCatalogsToolchainsAndFloorsUnchanged=True)
 (base/'b765-proved-archived-json-deduplication.json').write_text(json.dumps(receipt,indent=2)+'\n')
 print(json.dumps(receipt),flush=True)
