from pathlib import Path
import hashlib,json,shutil,subprocess,tarfile
r=Path('.git/agent-notes/review-20261031/text-stage-r374');out=Path('benchmarks/results/2026-11-15-text-stage-attribution');out.mkdir();receipt=json.loads((r/'archive-receipt.json').read_text(encoding='utf-8'));assert hashlib.sha256((r/'observations.tgz').read_bytes()).hexdigest()==receipt['archiveSHA256']
for name in ['observations.tgz','identity.json','prospective.json','archive-receipt.json','attribution-text.json','native-body-text-instruction-groups.json','terminal-status.json','deduplication-receipt.json']:shutil.copyfile(r/name,out/name)
with tarfile.open(out/'collection-and-analysis.tar.xz','w:xz')as t:
 for p in sorted(r.iterdir()):
  if p.is_file()and p.name not in ['observations.tgz','payload.tgz'] and not p.name.startswith(('alias-','aliased-','check-alias')):t.add(p,arcname=p.name)
(out/'README.md').write_text('''# Current captured-text CPU attribution

R374/B765, 2026-11-15, exact qualified runtime cf754dc7 / frozen 95798eb9.
One 5s cpu-clock/fp capture at 199Hz after 8 guest-seconds warmup, unchanged
complete text script, worker, optional 0.4 adapter and catalog. Diagnostic JIT/map
overrides are explicit; this is not an elapsed or allocation comparison.

935 selected guest leaves / 4.71 guest CPU seconds, 76 unmapped leaves, zero
ambiguous. Nearest-frame families include 438 ordinary/call (including the
already-fused loop), 196 text, 105 native helper/slot, 68 admission and 21 file/
iteration samples. These include useful/inlined work and are not removable shares.
The hottest leaf is TryExecuteDictionaryLoop (192), then ordinary dispatch (98),
cased-word preparation (87), native RunCore (44) and UTF8 casing (43). Same-process
native-body mapping is unique: 5,937 bytes / 150 instruction groups, all 44 leaves
mapped. It does not explain the internals of the 192-leaf bulk loop.

Source confirms existing raw-word histogram consumption, deferred private word/
total publication, one-probe native dictionary updates, eager preflight and reused
ranges. Direct append/get/write/CSV dispatch, bulk CSV scanning/admission/adoption,
inline strings/windows and final UTF8 output already exist. No missing arena or
removed text-conversion stage may be claimed again.

The source gate selected a bounded callback-free segment prototype (R376) to
remove repeated per-word activation/revalidation/retirement using existing owners
and mechanisms. Its benefit is unmeasured here. The review also found two real
[overlapping-binding bugs](../2026-11-15-histogram-binding-aliases/README.md), fixed
before relying on that invariant. No generic controller, value rewrite or new
profiling framework follows. Preserve slower call-controller/arena and cased-buffer
lessons; a percentage of samples is no speedup forecast.

All identity/golden/file/budget/quiet/join/archive gates pass. RAM traces are
archived and verified persistently under lease before unmount, all users joined.
Two exact duplicate B762/B763 JSON leaves are deduplicated only with committed,
local/remote archive/member hashes and path/UID/link proof; compressed originals,
local Git evidence and images/catalogs/toolchains remain. Floors unchanged.
[Raw](observations.tgz), [leaf map](attribution-text.json),
[native groups](native-body-text-instruction-groups.json).
''',encoding='utf-8',newline='\n')
out=Path('benchmarks/results/2026-11-15-histogram-binding-aliases');out.mkdir()
for name in ['aliased-bindings-sources.json','aliased-bindings-original.jsonl','alias-control-sources.json','alias-control-False.jsonl','alias-control-True.jsonl','alias-fix-checks.json']:shutil.copyfile(r/name,out/name)
with tarfile.open(out/'source-probes-and-checks.tar.xz','w:xz')as t:
 for p in sorted(r.iterdir()):
  if p.is_file()and p.name.startswith(('alias-','aliased-','check-alias')):t.add(p,arcname=p.name)
 t.add('src/Lokad.Lython/Frontend/ExecutableScript.NativeSegments.cs',arcname='corrected-compiler-facts.cs');t.add('tests/Lokad.Lython.PublicApi.Tests/NativeWordBindingTests.cs',arcname='public-regressions.cs')
(out/'README.md').write_text('''# Overlapping histogram bindings

R375, 2026-11-15. Independent isolated CPython probes expose two compiler-fusion
bugs in the qualified cf754/957 runtime. With a pre-existing key, reusing the loop
word as the dictionary wrongly updates the old dictionary twice instead of
raising AttributeError before any update. Reusing the word as the running total
wrongly completes with total2 instead of raising TypeError after one update.
The original and corrected outputs survive. A literal first variant is statically
rejected; the parameterized variant demonstrates the actual runtime divergence.

Exclude overlapping dictionary/word/total local bindings from whole-loop fusion.
Keep the ordinary executable loop: Python errors, binding order and side effects
are preserved, without removing supported syntax or introducing another backend.
No public API, ownership, limit, cancellation or stack-policy change; no speedup
claim. Preserve this correctness fix independently of the subsequent performance
prototype.

165 focused public and 34 admission/ownership checks pass per actual .NET11/10.
Both examples match isolated CPython under both APIs on both frameworks. The
source/scope correction is separate from the exact cf754 shared-slot full
qualification; later delivery qualification is batched at a coherent boundary.
[Original divergence](aliased-bindings-original.jsonl),
[focused checks](alias-fix-checks.json), [sources/probes](source-probes-and-checks.tar.xz).
''',encoding='utf-8',newline='\n')
p=Path('docs/RUNTIME.md');s=p.read_text(encoding='utf-8');needle='Eligible dictionary counting loops run consecutive native iterations without';s=s.replace(needle,'Dictionary, word and optional total bindings must be distinct for whole-loop\nfusion; overlapping names use ordinary executable operations and Python errors.\n'+needle);p.write_text(s,encoding='utf-8',newline='\n')
p=Path('benchmarks/EXPERIMENTS.md');s=p.read_text(encoding='utf-8');s+='''
## R374 / R375 — text attribution and binding correctness

[One current text capture](results/2026-11-15-text-stage-attribution/README.md)
finds 935 guest leaves, 76 unknown/zero ambiguous; 192 are the existing fused
histogram loop, including useful work. Native body is only44 leaves, uniquely
mapped5937bytes/150groups. No missing arena/conversion or removable share inferred.
Source selects a callback-free segment prototype, not a performance claim.
[Two independently reproduced alias bugs](results/2026-11-15-histogram-binding-aliases/README.md)
require distinct dictionary/word/total bindings for fusion. Ordinary executable
errors/effects remain; 165public+34internal per actual11/10 and both-API CPython
controls pass. Preserve this correction independently of R376. All raw/failed
conditions and verified archival custody remain; no VM users remain from B765.
''';p.write_text(s,encoding='utf-8',newline='\n')
print('Current attribution and independent correctness evidence preserved; prototype remains unpromoted.')
