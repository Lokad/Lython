; Assembly listing for method Lokad.Lython.LythonCompiledScript:RunCore(Lokad.Lython.ILythonHost,Lokad.Lython.LythonRunOptions):Lokad.Lython.LythonExecutionResult:this (Tier0)
; Emitting BLENDED_CODE for x64 + VEX + EVEX on Unix
; Tier0 code
; rbp based frame
; fully interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 192
       lea      rbp, [rsp+0xC0]
       xor      eax, eax
       mov      qword ptr [rbp-0xB8], rax
       vxorps   xmm8, xmm8, xmm8
       vmovdqu32 zmmword ptr [rbp-0xB0], zmm8
       vmovdqu32 zmmword ptr [rbp-0x70], zmm8
       vmovdqa  xmmword ptr [rbp-0x30], xmm8
       mov      qword ptr [rbp-0x20], rax
       mov      gword ptr [rbp-0x08], rdi
       mov      gword ptr [rbp-0x10], rsi
       mov      gword ptr [rbp-0x18], rdx
 
G_M000_IG02:                ;; offset=0x0047
       mov      rax, gword ptr [rbp-0x08]
       mov      rax, gword ptr [rax+0x08]
       mov      gword ptr [rbp-0x58], rax
       mov      rax, gword ptr [rbp-0x58]
       mov      gword ptr [rbp-0x60], rax
       cmp      gword ptr [rbp-0x58], 0
       jne      SHORT G_M000_IG04
 
G_M000_IG03:                ;; offset=0x0062
       mov      rdi, 0x7E77FA856F18
       call     CORINFO_HELP_NEWSFAST
       mov      gword ptr [rbp-0xA8], rax
       mov      rdi, gword ptr [rbp-0xA8]
       mov      rsi, 0x7E77F1215638
       call     [System.ObjectDisposedException:.ctor(System.String):this]
       mov      rdi, gword ptr [rbp-0xA8]
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG04:                ;; offset=0x009C
       mov      rax, gword ptr [rbp-0x60]
       mov      gword ptr [rbp-0x20], rax
       cmp      gword ptr [rbp-0x18], 0
       jne      SHORT G_M000_IG05
       mov      rdi, 0x7E77FA9B6E20
       call     CORINFO_HELP_NEWSFAST
       mov      gword ptr [rbp-0xA0], rax
       mov      rdi, gword ptr [rbp-0xA0]
       call     [Lokad.Lython.LythonRunOptions:.ctor():this]
       mov      rax, gword ptr [rbp-0xA0]
       mov      gword ptr [rbp-0x18], rax
 
G_M000_IG05:                ;; offset=0x00D9
       mov      rdi, gword ptr [rbp-0x18]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.LythonRunOptions:get_MemoryBudget():Lokad.Lython.ILythonMemoryBudget:this]
       mov      gword ptr [rbp-0x68], rax
       mov      rax, gword ptr [rbp-0x68]
       mov      gword ptr [rbp-0x70], rax
       cmp      gword ptr [rbp-0x68], 0
       jne      SHORT G_M000_IG06
       mov      rax, gword ptr [rbp-0x08]
       mov      rax, gword ptr [rax+0x20]
       mov      gword ptr [rbp-0x90], rax
       mov      rax, gword ptr [rbp-0x90]
       mov      gword ptr [rbp-0x70], rax
       cmp      gword ptr [rbp-0x90], 0
       jne      SHORT G_M000_IG06
       vxorps   xmm0, xmm0, xmm0
       vmovups  xmmword ptr [rbp-0x48], xmm0
       mov      rdi, 0x7E77FA8F6988
       call     CORINFO_HELP_NEWSFAST
       mov      gword ptr [rbp-0x98], rax
       mov      rsi, qword ptr [rbp-0x48]
       mov      rdx, qword ptr [rbp-0x40]
       mov      rdi, gword ptr [rbp-0x98]
       call     [Lokad.Lython.LythonMemoryBudget:.ctor(System.Nullable`1[long]):this]
       mov      rax, gword ptr [rbp-0x98]
       mov      gword ptr [rbp-0x70], rax
 
G_M000_IG06:                ;; offset=0x015B
       mov      rax, gword ptr [rbp-0x70]
       mov      gword ptr [rbp-0x28], rax
       mov      rdi, gword ptr [rbp-0x28]
       mov      r11, 0x7E77F8A41BD8
       call     [r11]Lokad.Lython.ILythonMemoryBudget:CreateScope():Lokad.Lython.ILythonMemoryScope:this
       mov      gword ptr [rbp-0x30], rax
 
G_M000_IG07:                ;; offset=0x0178
       mov      rdi, gword ptr [rbp-0x18]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.LythonRunOptions:get_ResultMemoryBudget():Lokad.Lython.ILythonMemoryBudget:this]
       mov      gword ptr [rbp-0x78], rax
       mov      rax, gword ptr [rbp-0x78]
       mov      gword ptr [rbp-0x80], rax
       cmp      gword ptr [rbp-0x78], 0
       jne      SHORT G_M000_IG08
       mov      rax, gword ptr [rbp-0x28]
       mov      gword ptr [rbp-0x80], rax
 
G_M000_IG08:                ;; offset=0x019F
       mov      rdi, gword ptr [rbp-0x80]
       mov      r11, 0x7E77F8A41BE0
       call     [r11]Lokad.Lython.ILythonMemoryBudget:CreateScope():Lokad.Lython.ILythonMemoryScope:this
       mov      gword ptr [rbp-0x38], rax
 
G_M000_IG09:                ;; offset=0x01B4
       mov      rdi, gword ptr [rbp-0x18]
       mov      rsi, gword ptr [rbp-0x30]
       mov      rdx, gword ptr [rbp-0x38]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.LythonRunOptions:WithMemoryOwners(Lokad.Lython.ILythonMemoryBudget,Lokad.Lython.ILythonMemoryBudget):Lokad.Lython.LythonRunOptions:this]
       mov      gword ptr [rbp-0xB0], rax
       mov      rdx, gword ptr [rbp-0xB0]
       mov      rsi, gword ptr [rbp-0x10]
       mov      rax, gword ptr [rbp-0x20]
       mov      rdi, gword ptr [rax+0x10]
       mov      rax, gword ptr [rbp-0x20]
       call     [rax+0x18]System.Func`3[System.__Canon,System.__Canon,System.__Canon]:Invoke(System.__Canon,System.__Canon):System.__Canon:this
       mov      gword ptr [rbp-0xB8], rax
       mov      rdi, gword ptr [rbp-0xB8]
       mov      rsi, gword ptr [rbp-0x38]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.LythonExecutionResult:OwnMemoryScope(Lokad.Lython.ILythonMemoryScope):Lokad.Lython.LythonExecutionResult:this]
       mov      gword ptr [rbp-0x50], rax
 
G_M000_IG10:                ;; offset=0x0207
       call     G_M000_IG15
       nop      
 
G_M000_IG11:                ;; offset=0x020D
       mov      rax, gword ptr [rbp-0x50]
 
G_M000_IG12:                ;; offset=0x0211
       add      rsp, 192
       pop      rbp
       ret      
 
G_M000_IG13:                ;; offset=0x021A
       push     rax
 
G_M000_IG14:                ;; offset=0x021B
       mov      gword ptr [rbp-0x88], rdi
       mov      rdi, gword ptr [rbp-0x38]
       mov      r11, 0x7E77F8A41BE8
       call     [r11]System.IDisposable:Dispose():this
       call     CORINFO_HELP_RETHROW
       int3     
 
G_M000_IG15:                ;; offset=0x0239
       push     rax
 
G_M000_IG16:                ;; offset=0x023A
       cmp      gword ptr [rbp-0x30], 0
       je       SHORT G_M000_IG17
       mov      rdi, gword ptr [rbp-0x30]
       mov      r11, 0x7E77F8A41BF0
       call     [r11]System.IDisposable:Dispose():this
 
G_M000_IG17:                ;; offset=0x0252
       nop      
 
G_M000_IG18:                ;; offset=0x0253
       add      rsp, 8
       ret      
 
; Total bytes of code 600

; Assembly listing for method Lokad.Lython.Runtime.LythonRuntime+NativeExecution:RunCore(byref):bool:this (Instrumented Tier0)
; Emitting BLENDED_CODE for x64 + VEX + EVEX on Unix
; Instrumented Tier0 code
; rbp based frame
; partially interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 0x560
       lea      rbp, [rsp+0x560]
       vxorps   xmm8, xmm8, xmm8
       vmovdqa32 xmmword ptr [rbp-0x560], xmm8
       mov      rax, -0x510
 
G_M000_IG122:                ;; offset=0x0026
       vmovdqa  xmmword ptr [rbp+rax-0x40], xmm8
       vmovdqa  xmmword ptr [rbp+rax-0x30], xmm8
       vmovdqa  xmmword ptr [rbp+rax-0x20], xmm8
       add      rax, 48
       jne      SHORT G_M000_IG122
       mov      qword ptr [rbp-0x40], rax
       mov      bword ptr [rbp-0x30], rdi
       mov      bword ptr [rbp-0x38], rsi
 
G_M000_IG02:                ;; offset=0x004A
       mov      dword ptr [rbp-0x394], 0x3E8
       mov      rax, 0x7E70158016F0
       mov      rdi, gword ptr [rax]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:FromObject(System.Object):Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]
       mov      gword ptr [rbp-0x188], rax
       mov      qword ptr [rbp-0x180], rdx
       mov      rax, bword ptr [rbp-0x38]
       mov      bword ptr [rbp-0x550], rax
       mov      rdi, bword ptr [rbp-0x550]
       mov      rsi, gword ptr [rbp-0x188]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rax, bword ptr [rbp-0x550]
       mov      rcx, qword ptr [rbp-0x180]
       mov      qword ptr [rax+0x08], rcx
       jmp      G_M000_IG116
 
G_M000_IG03:                ;; offset=0x00AA
       mov      rax, bword ptr [rbp-0x30]
       mov      rdi, gword ptr [rax+0x08]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Instructions():Lokad.Lython.Frontend.ExecutableInstruction[]:this]
       mov      rcx, bword ptr [rbp-0x30]
       mov      ecx, dword ptr [rcx+0x40]
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG121
       mov      edx, ecx
       imul     rdx, rdx, 32
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      bword ptr [rbp-0x40], rax
       mov      rax, bword ptr [rbp-0x30]
       mov      rdi, gword ptr [rax+0x18]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:get_State():Lokad.Lython.Runtime.ExecutionState:this]
       mov      gword ptr [rbp-0x198], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x3A0], rax
       mov      rsi, gword ptr [rbp-0x3A0]
       mov      rdi, gword ptr [rbp-0x198]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.ExecutionState:CheckExecution(Lokad.Lython.LythonSourceSpan):this]
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_OpCode():int:this]
       mov      dword ptr [rbp-0x64], eax
       mov      eax, dword ptr [rbp-0x64]
       add      eax, -3
       mov      dword ptr [rbp-0x554], eax
       cmp      dword ptr [rbp-0x554], 3
       ja       SHORT G_M000_IG05
 
G_M000_IG04:                ;; offset=0x0139
       mov      eax, dword ptr [rbp-0x554]
       lea      rcx, [reloc @RWD00]
       mov      ecx, dword ptr [rcx+4*rax]
       lea      rdx, G_M000_IG02
       add      rcx, rdx
       jmp      rcx
 
G_M000_IG05:                ;; offset=0x0155
       mov      eax, dword ptr [rbp-0x64]
       add      eax, -25
       mov      dword ptr [rbp-0x558], eax
       cmp      dword ptr [rbp-0x558], 43
       ja       SHORT G_M000_IG07
 
G_M000_IG06:                ;; offset=0x016A
       mov      eax, dword ptr [rbp-0x558]
       lea      rcx, [reloc @RWD16]
       mov      ecx, dword ptr [rcx+4*rax]
       lea      rdx, G_M000_IG02
       add      rcx, rdx
       jmp      rcx
 
G_M000_IG07:                ;; offset=0x0186
       mov      rdi, 0x7E77FB371BC0
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG114
 
G_M000_IG08:                ;; offset=0x019A
       mov      rdi, 0x7E77FB371BC4
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp-0x30]
       mov      rdi, gword ptr [rax+0x08]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_FirstTemporarySlot():int:this]
       mov      dword ptr [rbp-0x3A4], eax
       mov      esi, dword ptr [rbp-0x3A4]
       mov      rdi, bword ptr [rbp-0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Trim(int):this]
       jmp      G_M000_IG119
 
G_M000_IG09:                ;; offset=0x01D4
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x3A8], eax
       mov      esi, dword ptr [rbp-0x3A8]
       mov      rdi, bword ptr [rbp-0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:ReadReturnSlot(int):Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:this]
       mov      gword ptr [rbp-0x1A8], rax
       mov      qword ptr [rbp-0x1A0], rdx
       mov      rax, bword ptr [rbp-0x38]
       mov      bword ptr [rbp-0x560], rax
       mov      rdi, bword ptr [rbp-0x560]
       mov      rsi, gword ptr [rbp-0x1A8]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rax, bword ptr [rbp-0x560]
       mov      rcx, qword ptr [rbp-0x1A0]
       mov      qword ptr [rax+0x08], rcx
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x1AC], eax
       mov      rax, bword ptr [rbp-0x30]
       mov      rdi, gword ptr [rax+0x08]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_FirstTemporarySlot():int:this]
       cmp      eax, dword ptr [rbp-0x1AC]
       jg       SHORT G_M000_IG10
       mov      rdi, 0x7E77FB371BC8
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp-0x30]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp-0x30]
       add      rax, 80
       mov      bword ptr [rbp-0x1B8], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x1BC], eax
       mov      rax, bword ptr [rbp-0x1B8]
       mov      eax, dword ptr [rax+0x08]
       cmp      dword ptr [rbp-0x1BC], eax
       jae      G_M000_IG121
       mov      rax, bword ptr [rbp-0x1B8]
       mov      ecx, dword ptr [rbp-0x1BC]
       shl      rcx, 4
       add      rcx, bword ptr [rax]
       mov      rdi, rcx
       xor      rsi, rsi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:set_Object(System.Object):this]
 
G_M000_IG10:                ;; offset=0x02C3
       mov      rdi, 0x7E77FB371BCC
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp-0x30]
       mov      rdi, gword ptr [rax+0x08]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_FirstTemporarySlot():int:this]
       mov      dword ptr [rbp-0x3AC], eax
       mov      esi, dword ptr [rbp-0x3AC]
       mov      rdi, bword ptr [rbp-0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Trim(int):this]
       jmp      G_M000_IG119
 
G_M000_IG11:                ;; offset=0x02FD
       mov      rax, bword ptr [rbp-0x30]
       mov      rdi, gword ptr [rax+0x08]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Constants():System.Collections.Generic.IReadOnlyList`1[System.Object]:this]
       mov      gword ptr [rbp-0x378], rax
       mov      rax, gword ptr [rbp-0x378]
       mov      gword ptr [rbp-0x380], rax
       mov      rdi, gword ptr [rbp-0x380]
       mov      rsi, 0x7E77FB371BD0
       call     CORINFO_HELP_CLASSPROFILE32
       mov      rax, gword ptr [rbp-0x380]
       mov      gword ptr [rbp-0x3B8], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ConstantIndex():int:this]
       mov      dword ptr [rbp-0x3BC], eax
       mov      rdi, gword ptr [rbp-0x3B8]
       mov      esi, dword ptr [rbp-0x3BC]
       mov      r11, 0x7E77F8A421E0
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       mov      rdi, rax
       call     [Lokad.Lython.Runtime.LythonRuntime:RuntimeValue(System.Object):System.Object]
       mov      gword ptr [rbp-0x3C8], rax
       mov      rdx, gword ptr [rbp-0x3C8]
       mov      rsi, bword ptr [rbp-0x40]
       mov      rdi, bword ptr [rbp-0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,System.Object):this]
       jmp      G_M000_IG115
 
G_M000_IG12:                ;; offset=0x039A
       mov      rdi, 0x7E77FB371CD8
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LocalSlot():int:this]
       mov      dword ptr [rbp-0x36C], eax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x3D0], rax
       mov      rdx, gword ptr [rbp-0x3D0]
       mov      esi, dword ptr [rbp-0x36C]
       mov      rdi, bword ptr [rbp-0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:ReadLocal(int,Lokad.Lython.LythonSourceSpan):System.Object:this]
       mov      gword ptr [rbp-0x3D8], rax
       mov      rdx, gword ptr [rbp-0x3D8]
       mov      rsi, bword ptr [rbp-0x40]
       mov      rdi, bword ptr [rbp-0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,System.Object):this]
       jmp      G_M000_IG115
 
G_M000_IG13:                ;; offset=0x0402
       mov      rdi, 0x7E77FB371CDC
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp-0x30]
       mov      rdi, gword ptr [rax+0x08]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Names():System.Collections.Generic.IReadOnlyList`1[System.String]:this]
       mov      gword ptr [rbp-0x360], rax
       mov      rax, gword ptr [rbp-0x360]
       mov      gword ptr [rbp-0x388], rax
       mov      rdi, gword ptr [rbp-0x388]
       mov      rsi, 0x7E77FB371CE0
       call     CORINFO_HELP_CLASSPROFILE32
       mov      rax, gword ptr [rbp-0x388]
       mov      gword ptr [rbp-0x3E0], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_NameIndex():int:this]
       mov      dword ptr [rbp-0x3E4], eax
       mov      rdi, gword ptr [rbp-0x3E0]
       mov      esi, dword ptr [rbp-0x3E4]
       mov      r11, 0x7E77F8A421D8
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       mov      gword ptr [rbp-0x368], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x3F0], rax
       mov      rsi, gword ptr [rbp-0x3F0]
       mov      rax, bword ptr [rbp-0x30]
       mov      rdx, gword ptr [rax+0x18]
       mov      rdi, gword ptr [rbp-0x368]
       call     [Lokad.Lython.Runtime.LythonRuntime:ResolveExecutableGlobal(System.String,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):System.Object]
       mov      gword ptr [rbp-0x3F8], rax
       mov      rdx, gword ptr [rbp-0x3F8]
       mov      rsi, bword ptr [rbp-0x40]
       mov      rdi, bword ptr [rbp-0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,System.Object):this]
       jmp      G_M000_IG115
 
G_M000_IG14:                ;; offset=0x04D9
       mov      rax, bword ptr [rbp-0x30]
       mov      r8, gword ptr [rax+0x18]
       mov      rax, bword ptr [rbp-0x30]
       mov      rdi, gword ptr [rax+0x08]
       mov      rax, bword ptr [rbp-0x30]
       mov      rsi, gword ptr [rax+0x10]
       mov      rax, bword ptr [rbp-0x30]
       mov      edx, dword ptr [rax+0x40]
       mov      rax, bword ptr [rbp-0x30]
       mov      ecx, dword ptr [rax+0x44]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryExecuteClosureArithmetic(Lokad.Lython.Frontend.ExecutableCodeObject,System.Collections.Generic.IReadOnlyList`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableCell],int,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):bool]
       test     eax, eax
       je       SHORT G_M000_IG15
       mov      rdi, 0x7E77FB371DE8
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp-0x30]
       add      dword ptr [rax+0x40], 2
       jmp      G_M000_IG115
 
G_M000_IG15:                ;; offset=0x0525
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ClosureSlot():int:this]
       mov      dword ptr [rbp-0x3FC], eax
       mov      esi, dword ptr [rbp-0x3FC]
       lea      rdx, [rbp-0x48]
       mov      rdi, bword ptr [rbp-0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:TryCell(int,byref):bool:this]
       test     eax, eax
       je       SHORT G_M000_IG17
       mov      rdi, gword ptr [rbp-0x48]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableCell:get_Value():System.Object:this]
       mov      gword ptr [rbp-0x50], rax
       cmp      gword ptr [rbp-0x50], 0
       jne      SHORT G_M000_IG18
 
G_M000_IG16:                ;; offset=0x0564
       mov      rdi, 0x7E77FB371DEC
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG17:                ;; offset=0x0573
       mov      rdi, 0x7E77FB371DF0
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG109
 
G_M000_IG18:                ;; offset=0x0587
       mov      rdi, 0x7E77FB371DF4
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, bword ptr [rbp-0x30]
       mov      rsi, bword ptr [rbp-0x40]
       mov      rdx, gword ptr [rbp-0x50]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,System.Object):this]
       jmp      G_M000_IG115
 
G_M000_IG19:                ;; offset=0x05AD
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ClosureSlot():int:this]
       mov      dword ptr [rbp-0x400], eax
       mov      esi, dword ptr [rbp-0x400]
       lea      rdx, [rbp-0x58]
       mov      rdi, bword ptr [rbp-0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:TryCell(int,byref):bool:this]
       test     eax, eax
       je       SHORT G_M000_IG21
       mov      rdi, gword ptr [rbp-0x58]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableCell:get_CanStoreThroughOwner():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG22
 
G_M000_IG20:                ;; offset=0x05E5
       mov      rdi, 0x7E77FB371DF8
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG21:                ;; offset=0x05F4
       mov      rdi, 0x7E77FB371DFC
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG109
 
G_M000_IG22:                ;; offset=0x0608
       mov      rdi, 0x7E77FB371E00
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, bword ptr [rbp-0x30]
       mov      rsi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Take(byref):System.Object:this]
       mov      gword ptr [rbp-0x60], rax
       mov      rdi, gword ptr [rbp-0x58]
       mov      rsi, gword ptr [rbp-0x60]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableCell:set_Value(System.Object):this]
       jmp      G_M000_IG115
 
G_M000_IG23:                ;; offset=0x063E
       mov      rdi, 0x7E77FB371E04
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp-0x30]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp-0x30]
       add      rax, 80
       mov      bword ptr [rbp-0x328], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LocalSlot():int:this]
       mov      dword ptr [rbp-0x32C], eax
       mov      rax, bword ptr [rbp-0x328]
       mov      eax, dword ptr [rax+0x08]
       cmp      dword ptr [rbp-0x32C], eax
       jae      G_M000_IG121
       mov      rax, bword ptr [rbp-0x328]
       mov      ecx, dword ptr [rbp-0x32C]
       shl      rcx, 4
       add      rcx, bword ptr [rax]
       mov      bword ptr [rbp-0x338], rcx
       mov      rdi, bword ptr [rbp-0x30]
       mov      rsi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Take(byref):System.Object:this]
       mov      gword ptr [rbp-0x408], rax
       mov      rsi, gword ptr [rbp-0x408]
       mov      rdi, bword ptr [rbp-0x338]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:set_Object(System.Object):this]
       jmp      G_M000_IG115
 
G_M000_IG24:                ;; offset=0x06D1
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x40C], eax
       mov      esi, dword ptr [rbp-0x40C]
       mov      rdi, bword ptr [rbp-0x30]
       xor      edx, edx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Read(int,int):System.Object:this]
       mov      gword ptr [rbp-0x70], rax
       mov      rax, bword ptr [rbp-0x30]
       mov      rdi, gword ptr [rax+0x08]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Names():System.Collections.Generic.IReadOnlyList`1[System.String]:this]
       mov      gword ptr [rbp-0x348], rax
       mov      rax, gword ptr [rbp-0x348]
       mov      gword ptr [rbp-0x390], rax
       mov      rdi, gword ptr [rbp-0x390]
       mov      rsi, 0x7E77FB371E08
       call     CORINFO_HELP_CLASSPROFILE32
       mov      rax, gword ptr [rbp-0x390]
       mov      gword ptr [rbp-0x418], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_NameIndex():int:this]
       mov      dword ptr [rbp-0x41C], eax
       mov      rdi, gword ptr [rbp-0x418]
       mov      esi, dword ptr [rbp-0x41C]
       mov      r11, 0x7E77F8A421D0
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       mov      gword ptr [rbp-0x78], rax
       mov      rsi, gword ptr [rbp-0x70]
       mov      rdi, 0x7E77FB144048
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       jne      SHORT G_M000_IG26
       mov      rsi, gword ptr [rbp-0x70]
       mov      rdi, 0x7E77FB2DD8E0
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       jne      SHORT G_M000_IG25
       xor      rax, rax
       mov      gword ptr [rbp-0x350], rax
       jmp      SHORT G_M000_IG27
 
G_M000_IG25:                ;; offset=0x07AB
       mov      rdi, 0x7E77FB371F10
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, gword ptr [rbp-0x78]
       call     [Lokad.Lython.Runtime.LythonRuntime+DictMembers:GetMethod(System.String):Lokad.Lython.Runtime.LythonRuntime+ReceiverMethod]
       mov      gword ptr [rbp-0x350], rax
       jmp      SHORT G_M000_IG27
 
G_M000_IG26:                ;; offset=0x07CD
       mov      rdi, 0x7E77FB371F14
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, gword ptr [rbp-0x78]
       call     [Lokad.Lython.Runtime.LythonRuntime+StringMembers:GetMethod(System.String):Lokad.Lython.Runtime.LythonRuntime+ReceiverMethod]
       mov      gword ptr [rbp-0x350], rax
 
G_M000_IG27:                ;; offset=0x07ED
       mov      rax, gword ptr [rbp-0x350]
       mov      gword ptr [rbp-0x80], rax
       cmp      gword ptr [rbp-0x80], 0
       jne      SHORT G_M000_IG28
       mov      rdi, 0x7E77FB371F18
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG109
 
G_M000_IG28:                ;; offset=0x0813
       mov      rdi, 0x7E77FB371F1C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       mov      dword ptr [rbp-0x354], eax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       inc      eax
       mov      dword ptr [rbp-0x420], eax
       mov      edx, dword ptr [rbp-0x420]
       mov      esi, dword ptr [rbp-0x354]
       mov      rdi, bword ptr [rbp-0x30]
       mov      rcx, gword ptr [rbp-0x70]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Put(int,int,System.Object):this]
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       inc      eax
       mov      dword ptr [rbp-0x358], eax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      dword ptr [rbp-0x424], eax
       mov      edx, dword ptr [rbp-0x424]
       mov      esi, dword ptr [rbp-0x358]
       mov      rdi, bword ptr [rbp-0x30]
       mov      rcx, gword ptr [rbp-0x80]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Put(int,int,System.Object):this]
       jmp      G_M000_IG115
 
G_M000_IG29:                ;; offset=0x089F
       mov      rdi, bword ptr [rbp-0x30]
       mov      rsi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Call(byref):bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG30
       mov      rdi, 0x7E77FB371F20
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG109
 
G_M000_IG30:                ;; offset=0x08C5
       mov      rdi, 0x7E77FB371F24
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG115
 
G_M000_IG31:                ;; offset=0x08D9
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x428], eax
       mov      esi, dword ptr [rbp-0x428]
       mov      rdi, bword ptr [rbp-0x30]
       xor      edx, edx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Read(int,int):System.Object:this]
       mov      gword ptr [rbp-0x258], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_SecondInput():int:this]
       mov      dword ptr [rbp-0x42C], eax
       mov      esi, dword ptr [rbp-0x42C]
       mov      rdi, bword ptr [rbp-0x30]
       mov      edx, 1
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Read(int,int):System.Object:this]
       mov      gword ptr [rbp-0x88], rax
       mov      rsi, gword ptr [rbp-0x258]
       mov      rdi, 0x7E77FB2DD8E0
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      gword ptr [rbp-0x90], rax
       cmp      gword ptr [rbp-0x90], 0
       je       SHORT G_M000_IG33
       mov      rdi, gword ptr [rbp-0x90]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.PyDict:get_HasProtocolKeys():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG34
       mov      rsi, gword ptr [rbp-0x88]
       mov      rdi, 0x7E77FB144048
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      gword ptr [rbp-0x98], rax
       cmp      gword ptr [rbp-0x98], 0
       jne      SHORT G_M000_IG35
 
G_M000_IG32:                ;; offset=0x0991
       mov      rdi, 0x7E77FB371F28
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG33:                ;; offset=0x09A0
       mov      rdi, 0x7E77FB371F2C
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG109
 
G_M000_IG34:                ;; offset=0x09B4
       mov      rdi, 0x7E77FB371F30
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG33
 
G_M000_IG35:                ;; offset=0x09C5
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LookupCacheIndex():int:this]
       test     eax, eax
       jl       G_M000_IG38
       mov      rdi, gword ptr [rbp-0x90]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.PyDict:get_HasSharedRecordKeys():bool:this]
       test     eax, eax
       je       G_M000_IG37
       mov      rax, bword ptr [rbp-0x30]
       mov      rax, gword ptr [rax]
       mov      gword ptr [rbp-0x260], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x438], rax
       mov      rsi, gword ptr [rbp-0x438]
       mov      rdi, gword ptr [rbp-0x260]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.PyExecutableFunction:GetLookupCaches(Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.LythonRuntime+ExecutableLookupCache[]:this]
       mov      gword ptr [rbp-0xA0], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LookupCacheIndex():int:this]
       mov      rcx, gword ptr [rbp-0xA0]
       cmp      eax, dword ptr [rcx+0x08]
       jae      G_M000_IG121
       mov      edx, eax
       imul     rdx, rdx, 24
       lea      rcx, bword ptr [rcx+rdx+0x10]
       mov      bword ptr [rbp-0x268], rcx
       mov      rax, bword ptr [rbp-0x30]
       mov      rax, gword ptr [rax+0x18]
       mov      gword ptr [rbp-0x270], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x440], rax
       mov      r8, gword ptr [rbp-0x440]
       lea      r9, [rbp-0xA8]
       mov      rsi, gword ptr [rbp-0x98]
       mov      rdx, bword ptr [rbp-0x268]
       mov      rcx, gword ptr [rbp-0x270]
       mov      rdi, gword ptr [rbp-0x90]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.PyDict:TryReadRecordValue(Lokad.Lython.Runtime.Text.PyString,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,byref):bool:this]
       test     eax, eax
       je       SHORT G_M000_IG36
       mov      rdi, 0x7E77FB371F34
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, bword ptr [rbp-0x30]
       mov      rsi, bword ptr [rbp-0x40]
       mov      rdx, gword ptr [rbp-0xA8]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,System.Object):this]
       jmp      G_M000_IG115
 
G_M000_IG36:                ;; offset=0x0AD5
       mov      rdi, 0x7E77FB371F38
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG38
 
G_M000_IG37:                ;; offset=0x0AE6
       mov      rdi, 0x7E77FB371F3C
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG38:                ;; offset=0x0AF5
       mov      rdi, gword ptr [rbp-0x90]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.PyDict:get_HasProtocolKeys():bool:this]
       test     eax, eax
       je       SHORT G_M000_IG39
       mov      rdi, 0x7E77FB371F40
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG109
 
G_M000_IG39:                ;; offset=0x0B1C
       mov      rdi, 0x7E77FB371F44
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x448], rax
       mov      rdx, gword ptr [rbp-0x448]
       mov      rax, bword ptr [rbp-0x30]
       mov      rcx, gword ptr [rax+0x18]
       mov      rsi, gword ptr [rbp-0x98]
       mov      rdi, gword ptr [rbp-0x90]
       call     [Lokad.Lython.Runtime.LythonRuntime:ReadSubscriptValue(System.Object,System.Object,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):System.Object]
       mov      gword ptr [rbp-0x450], rax
       mov      rdx, gword ptr [rbp-0x450]
       mov      rsi, bword ptr [rbp-0x40]
       mov      rdi, bword ptr [rbp-0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,System.Object):this]
       jmp      G_M000_IG115
 
G_M000_IG40:                ;; offset=0x0B80
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x454], eax
       mov      esi, dword ptr [rbp-0x454]
       mov      rdi, bword ptr [rbp-0x30]
       xor      edx, edx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Read(int,int):System.Object:this]
       mov      gword ptr [rbp-0xB0], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_UnaryOperator():int:this]
       test     eax, eax
       je       G_M000_IG43
       mov      rsi, gword ptr [rbp-0xB0]
       mov      rdi, 0x7E77FB02B158
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       jne      SHORT G_M000_IG42
       mov      rsi, gword ptr [rbp-0xB0]
       mov      rdi, 0x7E77F9C96558
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       jne      SHORT G_M000_IG41
       mov      rdi, 0x7E77FB371F48
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rsi, gword ptr [rbp-0xB0]
       mov      rdi, 0x7E77F9C635C8
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       sete     al
       movzx    rax, al
       mov      dword ptr [rbp-0x1E4], eax
       jmp      SHORT G_M000_IG44
 
G_M000_IG41:                ;; offset=0x0C2A
       mov      rdi, 0x7E77FB371F4C
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG42:                ;; offset=0x0C39
       xor      eax, eax
       mov      dword ptr [rbp-0x1E4], eax
       jmp      SHORT G_M000_IG44
 
G_M000_IG43:                ;; offset=0x0C43
       mov      rdi, 0x7E77FB371F50
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, gword ptr [rbp-0xB0]
       call     [Lokad.Lython.Runtime.LythonRuntime:CanUseNativeTruth(System.Object):bool]
       test     eax, eax
       sete     al
       movzx    rax, al
       mov      dword ptr [rbp-0x1E4], eax
 
G_M000_IG44:                ;; offset=0x0C6D
       cmp      dword ptr [rbp-0x1E4], 0
       je       SHORT G_M000_IG45
       mov      rdi, 0x7E77FB371F54
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG109
 
G_M000_IG45:                ;; offset=0x0C8A
       mov      rdi, 0x7E77FB371F58
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_UnaryOperator():int:this]
       mov      dword ptr [rbp-0x1E8], eax
       mov      rax, bword ptr [rbp-0x30]
       mov      rax, gword ptr [rax+0x18]
       mov      gword ptr [rbp-0x1F0], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x460], rax
       mov      rcx, gword ptr [rbp-0x460]
       mov      rsi, gword ptr [rbp-0xB0]
       mov      rdx, gword ptr [rbp-0x1F0]
       mov      edi, dword ptr [rbp-0x1E8]
       call     [Lokad.Lython.Runtime.LythonRuntime:EvaluateExecutableUnary(int,System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):System.Object]
       mov      gword ptr [rbp-0x468], rax
       mov      rdx, gword ptr [rbp-0x468]
       mov      rsi, bword ptr [rbp-0x40]
       mov      rdi, bword ptr [rbp-0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,System.Object):this]
       jmp      G_M000_IG115
 
G_M000_IG46:                ;; offset=0x0D0B
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_OpCode():int:this]
       cmp      eax, 48
       jne      SHORT G_M000_IG48
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_AugmentedOperator():int:this]
       cmp      eax, 3
       jne      SHORT G_M000_IG47
       mov      rdi, 0x7E77FB371F5C
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG109
 
G_M000_IG47:                ;; offset=0x0D3D
       mov      rdi, 0x7E77FB371F60
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG48:                ;; offset=0x0D4C
       mov      rdi, bword ptr [rbp-0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:TryIntegerOperation():bool:this]
       test     eax, eax
       jne      G_M000_IG51
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x46C], eax
       mov      esi, dword ptr [rbp-0x46C]
       mov      rdi, bword ptr [rbp-0x30]
       xor      edx, edx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Read(int,int):System.Object:this]
       mov      gword ptr [rbp-0xB8], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_SecondInput():int:this]
       mov      dword ptr [rbp-0x470], eax
       mov      esi, dword ptr [rbp-0x470]
       mov      rdi, bword ptr [rbp-0x30]
       mov      edx, 1
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Read(int,int):System.Object:this]
       mov      gword ptr [rbp-0xC0], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_OpCode():int:this]
       cmp      eax, 48
       sete     al
       movzx    rax, al
       mov      dword ptr [rbp-0xC4], eax
       cmp      dword ptr [rbp-0xC4], 0
       jne      G_M000_IG52
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_BinaryOperator():int:this]
       mov      dword ptr [rbp-0x244], eax
       mov      rax, bword ptr [rbp-0x30]
       mov      rax, gword ptr [rax+0x18]
       mov      gword ptr [rbp-0x250], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x478], rax
       mov      r8, gword ptr [rbp-0x478]
       lea      r9, [rbp-0xD0]
       mov      rsi, gword ptr [rbp-0xB8]
       mov      rdx, gword ptr [rbp-0xC0]
       mov      rcx, gword ptr [rbp-0x250]
       mov      edi, dword ptr [rbp-0x244]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryEvaluateScalarComparison(int,System.Object,System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,byref):bool]
       test     eax, eax
       je       SHORT G_M000_IG50
       mov      rdi, 0x7E77FB371F64
       call     CORINFO_HELP_COUNTPROFILE32
       movzx    rdi, byte  ptr [rbp-0xD0]
       call     [Lokad.Lython.Runtime.LythonRuntime:RuntimeValue(bool):System.Object]
       mov      gword ptr [rbp-0x480], rax
       mov      rdx, gword ptr [rbp-0x480]
       mov      rsi, bword ptr [rbp-0x40]
       mov      rdi, bword ptr [rbp-0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,System.Object):this]
 
G_M000_IG49:                ;; offset=0x0E75
       jmp      G_M000_IG115
 
G_M000_IG50:                ;; offset=0x0E7A
       mov      rdi, 0x7E77FB371F68
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG52
 
G_M000_IG51:                ;; offset=0x0E8B
       mov      rdi, 0x7E77FB371F6C
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG115
 
G_M000_IG52:                ;; offset=0x0E9F
       cmp      dword ptr [rbp-0xC4], 0
       jne      SHORT G_M000_IG53
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_BinaryOperator():int:this]
       mov      dword ptr [rbp-0x1F4], eax
       jmp      SHORT G_M000_IG54
 
G_M000_IG53:                ;; offset=0x0EBA
       mov      rdi, 0x7E77FB371F70
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_AugmentedOperator():int:this]
       mov      edi, eax
       call     [Lokad.Lython.Runtime.LythonRuntime:AugmentedBinaryOperator(int):int]
       mov      dword ptr [rbp-0x1F4], eax
 
G_M000_IG54:                ;; offset=0x0EE1
       mov      edi, dword ptr [rbp-0x1F4]
       mov      rsi, gword ptr [rbp-0xB8]
       mov      rdx, gword ptr [rbp-0xC0]
       call     [Lokad.Lython.Runtime.LythonRuntime:CanUseNativeBinary(int,System.Object,System.Object):bool]
       test     eax, eax
       jne      SHORT G_M000_IG55
       mov      rdi, 0x7E77FB371F74
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG109
 
G_M000_IG55:                ;; offset=0x0F13
       cmp      dword ptr [rbp-0xC4], 0
       je       G_M000_IG64
       mov      rsi, gword ptr [rbp-0xB8]
       mov      rdi, 0x7E77FB02B158
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       jne      SHORT G_M000_IG57
       mov      rsi, gword ptr [rbp-0xB8]
       mov      rdi, 0x7E77F9C96558
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       jne      G_M000_IG63
       mov      rsi, gword ptr [rbp-0xB8]
       mov      rdi, 0x7E77F9C635C8
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       je       G_M000_IG62
 
G_M000_IG56:                ;; offset=0x0F7C
       mov      rdi, 0x7E77FB371F78
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG57:                ;; offset=0x0F8B
       mov      rsi, gword ptr [rbp-0xC0]
       mov      rdi, 0x7E77FB02B158
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       jne      SHORT G_M000_IG61
       mov      rsi, gword ptr [rbp-0xC0]
       mov      rdi, 0x7E77F9C96558
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       jne      SHORT G_M000_IG60
       mov      rsi, gword ptr [rbp-0xC0]
       mov      rdi, 0x7E77F9C635C8
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       jne      SHORT G_M000_IG59
 
G_M000_IG58:                ;; offset=0x0FDF
       mov      rdi, 0x7E77FB371F7C
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG109
 
G_M000_IG59:                ;; offset=0x0FF3
       mov      rdi, 0x7E77FB371F80
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG64
 
G_M000_IG60:                ;; offset=0x1004
       mov      rdi, 0x7E77FB371F84
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG64
 
G_M000_IG61:                ;; offset=0x1015
       mov      rdi, 0x7E77FB371F88
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG64
 
G_M000_IG62:                ;; offset=0x1026
       mov      rdi, 0x7E77FB371F8C
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG58
 
G_M000_IG63:                ;; offset=0x1037
       mov      rdi, 0x7E77FB371F90
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG57
 
G_M000_IG64:                ;; offset=0x104B
       mov      rax, bword ptr [rbp-0x30]
       mov      bword ptr [rbp-0x200], rax
       mov      rax, bword ptr [rbp-0x40]
       mov      bword ptr [rbp-0x208], rax
       cmp      dword ptr [rbp-0xC4], 0
       jne      G_M000_IG65
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_BinaryOperator():int:this]
       mov      dword ptr [rbp-0x234], eax
       mov      rax, bword ptr [rbp-0x30]
       mov      rax, gword ptr [rax+0x18]
       mov      gword ptr [rbp-0x240], rax
       mov      rax, bword ptr [rbp-0x200]
       mov      bword ptr [rbp-0x220], rax
       mov      rax, bword ptr [rbp-0x208]
       mov      bword ptr [rbp-0x228], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x488], rax
       mov      r8, gword ptr [rbp-0x488]
       mov      rsi, gword ptr [rbp-0xB8]
       mov      rdx, gword ptr [rbp-0xC0]
       mov      rcx, gword ptr [rbp-0x240]
       mov      edi, dword ptr [rbp-0x234]
       call     [Lokad.Lython.Runtime.LythonRuntime:EvaluateBinaryOperator(int,System.Object,System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):System.Object]
       mov      gword ptr [rbp-0x230], rax
       jmp      G_M000_IG66
 
G_M000_IG65:                ;; offset=0x10EE
       mov      rdi, 0x7E77FB371F94
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_AugmentedOperator():int:this]
       mov      dword ptr [rbp-0x20C], eax
       mov      rax, bword ptr [rbp-0x30]
       mov      rax, gword ptr [rax+0x18]
       mov      gword ptr [rbp-0x218], rax
       mov      rax, bword ptr [rbp-0x200]
       mov      bword ptr [rbp-0x220], rax
       mov      rax, bword ptr [rbp-0x208]
       mov      bword ptr [rbp-0x228], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x490], rax
       mov      r8, gword ptr [rbp-0x490]
       mov      rsi, gword ptr [rbp-0xC0]
       mov      edx, dword ptr [rbp-0x20C]
       mov      rcx, gword ptr [rbp-0x218]
       mov      rdi, gword ptr [rbp-0xB8]
       call     [Lokad.Lython.Runtime.LythonRuntime:EvaluateAugmentedBuiltin(System.Object,System.Object,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):System.Object]
       mov      gword ptr [rbp-0x230], rax
 
G_M000_IG66:                ;; offset=0x1178
       mov      rdi, 0x7E77FB371F98
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, bword ptr [rbp-0x220]
       mov      rsi, bword ptr [rbp-0x228]
       mov      rdx, gword ptr [rbp-0x230]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,System.Object):this]
       jmp      G_M000_IG115
 
G_M000_IG67:                ;; offset=0x11A7
       lea      rdx, [rbp-0xD8]
       mov      rdi, bword ptr [rbp-0x30]
       mov      rsi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:TryIntegerComparison(byref,byref):bool:this]
       test     eax, eax
       jne      G_M000_IG69
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x494], eax
       mov      esi, dword ptr [rbp-0x494]
       mov      rdi, bword ptr [rbp-0x30]
       xor      edx, edx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Read(int,int):System.Object:this]
       mov      gword ptr [rbp-0xE0], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_SecondInput():int:this]
       mov      dword ptr [rbp-0x498], eax
       mov      esi, dword ptr [rbp-0x498]
       mov      rdi, bword ptr [rbp-0x30]
       mov      edx, 1
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Read(int,int):System.Object:this]
       mov      gword ptr [rbp-0xE8], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_BinaryOperator():int:this]
       mov      dword ptr [rbp-0x1CC], eax
       mov      rax, bword ptr [rbp-0x30]
       mov      rax, gword ptr [rax+0x18]
       mov      gword ptr [rbp-0x1D8], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x4A0], rax
       mov      r8, gword ptr [rbp-0x4A0]
       lea      r9, [rbp-0xD8]
       mov      rsi, gword ptr [rbp-0xE0]
       mov      rdx, gword ptr [rbp-0xE8]
       mov      rcx, gword ptr [rbp-0x1D8]
       mov      edi, dword ptr [rbp-0x1CC]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryEvaluateScalarComparison(int,System.Object,System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,byref):bool]
       test     eax, eax
       jne      SHORT G_M000_IG68
       mov      rdi, 0x7E77FB371F9C
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG109
 
G_M000_IG68:                ;; offset=0x1290
       mov      rdi, 0x7E77FB371FA0
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG69:                ;; offset=0x129F
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      dword ptr [rbp-0x4A4], eax
       mov      esi, dword ptr [rbp-0x4A4]
       mov      rdi, bword ptr [rbp-0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Trim(int):this]
       mov      rax, bword ptr [rbp-0x30]
       mov      rax, gword ptr [rax+0x18]
       mov      gword ptr [rbp-0x1C8], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x4B0], rax
       mov      rsi, gword ptr [rbp-0x4B0]
       mov      rdi, gword ptr [rbp-0x1C8]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CheckExecution(Lokad.Lython.LythonSourceSpan):this]
       movzx    rax, byte  ptr [rbp-0xD8]
       test     eax, eax
       jne      SHORT G_M000_IG70
       mov      rdi, 0x7E77FB371FA4
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_TargetIndex():int:this]
       mov      rcx, bword ptr [rbp-0x30]
       mov      dword ptr [rcx+0x40], eax
       jmp      G_M000_IG116
 
G_M000_IG70:                ;; offset=0x1325
       mov      rdi, 0x7E77FB371FA8
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG115
 
G_M000_IG71:                ;; offset=0x1339
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x4B4], eax
       mov      esi, dword ptr [rbp-0x4B4]
       mov      rdi, bword ptr [rbp-0x30]
       xor      edx, edx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Read(int,int):System.Object:this]
       mov      gword ptr [rbp-0xF0], rax
       mov      rdi, gword ptr [rbp-0xF0]
       call     [Lokad.Lython.Runtime.LythonRuntime:CanUseNativeTruth(System.Object):bool]
       test     eax, eax
       jne      SHORT G_M000_IG72
       mov      rdi, 0x7E77FB371FAC
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG109
 
G_M000_IG72:                ;; offset=0x1387
       mov      rdi, bword ptr [rbp-0x30]
       mov      rsi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Take(byref):System.Object:this]
       mov      rax, bword ptr [rbp-0x30]
       mov      rax, gword ptr [rax+0x18]
       mov      gword ptr [rbp-0x1E0], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x4C0], rax
       mov      rdx, gword ptr [rbp-0x4C0]
       mov      rsi, gword ptr [rbp-0x1E0]
       mov      rdi, gword ptr [rbp-0xF0]
       call     [Lokad.Lython.Runtime.LythonRuntime:IsTruthy(System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):bool]
       test     eax, eax
       jne      SHORT G_M000_IG73
       mov      rdi, 0x7E77FB371FB0
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_TargetIndex():int:this]
       mov      rcx, bword ptr [rbp-0x30]
       mov      dword ptr [rcx+0x40], eax
       jmp      G_M000_IG116
 
G_M000_IG73:                ;; offset=0x13F9
       mov      rdi, 0x7E77FB371FB4
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG115
 
G_M000_IG74:                ;; offset=0x140D
       mov      rdi, 0x7E77FB371FB8
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_TargetIndex():int:this]
       mov      rcx, bword ptr [rbp-0x30]
       mov      dword ptr [rcx+0x40], eax
       jmp      G_M000_IG116
 
G_M000_IG75:                ;; offset=0x1432
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_DiscardIterator():bool:this]
       test     eax, eax
       je       SHORT G_M000_IG76
       mov      rdi, 0x7E77FB371FBC
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp-0x30]
       mov      eax, dword ptr [rax+0x44]
       lea      esi, [rax-0x01]
       mov      rdi, bword ptr [rbp-0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Trim(int):this]
 
G_M000_IG76:                ;; offset=0x1463
       mov      rdi, 0x7E77FB371FC0
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_TargetIndex():int:this]
       mov      rcx, bword ptr [rbp-0x30]
       mov      dword ptr [rcx+0x40], eax
       jmp      G_M000_IG116
 
G_M000_IG77:                ;; offset=0x1488
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x4C4], eax
       mov      esi, dword ptr [rbp-0x4C4]
       mov      rdi, bword ptr [rbp-0x30]
       xor      edx, edx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Read(int,int):System.Object:this]
       mov      gword ptr [rbp-0xF8], rax
       mov      rsi, gword ptr [rbp-0xF8]
       mov      rdi, 0x7E77FB35AA90
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       je       SHORT G_M000_IG78
       mov      rdi, 0x7E77FB371FC4
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, bword ptr [rbp-0x30]
       mov      rsi, bword ptr [rbp-0x40]
       mov      rdx, gword ptr [rbp-0xF8]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,System.Object):this]
       jmp      G_M000_IG115
 
G_M000_IG78:                ;; offset=0x14F6
       mov      rsi, gword ptr [rbp-0xF8]
       mov      rdi, 0x7E77FB2F27A0
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       jne      G_M000_IG80
       mov      rsi, gword ptr [rbp-0xF8]
       mov      rdi, 0x7E77FB1D6C50
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       jne      G_M000_IG85
       mov      rsi, gword ptr [rbp-0xF8]
       mov      rdi, 0x7E77FB32E668
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       jne      G_M000_IG84
       mov      rsi, gword ptr [rbp-0xF8]
       mov      rdi, 0x7E77FB166110
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       jne      G_M000_IG83
       mov      rsi, gword ptr [rbp-0xF8]
       mov      rdi, 0x7E77FB144048
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       jne      SHORT G_M000_IG82
       mov      rsi, gword ptr [rbp-0xF8]
       mov      rdi, 0x7E77FB2DD8E0
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       jne      SHORT G_M000_IG81
       mov      rsi, gword ptr [rbp-0xF8]
       mov      rdi, 0x7E77FB330640
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       je       SHORT G_M000_IG86
 
G_M000_IG79:                ;; offset=0x15CA
       mov      rdi, 0x7E77FB371FC8
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG80:                ;; offset=0x15D9
       mov      dword ptr [rbp-0xFC], 1
       jmp      SHORT G_M000_IG87
 
G_M000_IG81:                ;; offset=0x15E5
       mov      rdi, 0x7E77FB371FCC
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG80
 
G_M000_IG82:                ;; offset=0x15F6
       mov      rdi, 0x7E77FB371FD0
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG80
 
G_M000_IG83:                ;; offset=0x1607
       mov      rdi, 0x7E77FB371FD4
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG80
 
G_M000_IG84:                ;; offset=0x1618
       mov      rdi, 0x7E77FB371FD8
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG80
 
G_M000_IG85:                ;; offset=0x1629
       mov      rdi, 0x7E77FB371FDC
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG80
 
G_M000_IG86:                ;; offset=0x163A
       mov      rdi, 0x7E77FB371FE0
       call     CORINFO_HELP_COUNTPROFILE32
       xor      eax, eax
       mov      dword ptr [rbp-0xFC], eax
 
G_M000_IG87:                ;; offset=0x1651
       cmp      dword ptr [rbp-0xFC], 0
       je       SHORT G_M000_IG88
       mov      rdi, 0x7E77FB371FE4
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x4D0], rax
       mov      rsi, gword ptr [rbp-0x4D0]
       mov      rax, bword ptr [rbp-0x30]
       mov      rdx, gword ptr [rax+0x18]
       mov      rdi, gword ptr [rbp-0xF8]
       call     [Lokad.Lython.Runtime.PyIteration+Cursor:Create(System.Object,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):Lokad.Lython.Runtime.PyIteration+Cursor]
       mov      gword ptr [rbp-0x4D8], rax
       mov      rdx, gword ptr [rbp-0x4D8]
       mov      rsi, bword ptr [rbp-0x40]
       mov      rdi, bword ptr [rbp-0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,System.Object):this]
       jmp      G_M000_IG115
 
G_M000_IG88:                ;; offset=0x16B7
       mov      rdi, 0x7E77FB371FE8
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG109
 
G_M000_IG89:                ;; offset=0x16CB
       mov      rax, bword ptr [rbp-0x30]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp-0x30]
       add      rax, 80
       mov      bword ptr [rbp-0x278], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x27C], eax
       mov      rax, bword ptr [rbp-0x278]
       mov      eax, dword ptr [rax+0x08]
       cmp      dword ptr [rbp-0x27C], eax
       jae      G_M000_IG121
       mov      rax, bword ptr [rbp-0x278]
       mov      ecx, dword ptr [rbp-0x27C]
       shl      rcx, 4
       add      rcx, bword ptr [rax]
       mov      rdi, rcx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Object():System.Object:this]
       mov      gword ptr [rbp-0x4E0], rax
       mov      rsi, gword ptr [rbp-0x4E0]
       mov      rdi, 0x7E77FB306FA8
       call     [Lokad.Lython.Internal.NullabilityExtensions:RequireNotNull[System.__Canon](System.__Canon):System.__Canon]
       mov      gword ptr [rbp-0x108], rax
       mov      rsi, gword ptr [rbp-0x108]
       mov      rdi, 0x7E77FB2DF9D0
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      gword ptr [rbp-0x110], rax
       cmp      gword ptr [rbp-0x110], 0
       je       G_M000_IG92
       lea      rsi, [rbp-0x118]
       lea      rdx, [rbp-0x120]
       mov      rdi, gword ptr [rbp-0x110]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.PyIteration+Cursor:TryMoveNextInteger(byref,byref):bool:this]
       test     eax, eax
       je       SHORT G_M000_IG90
       movzx    rax, byte  ptr [rbp-0x118]
       test     eax, eax
       jne      SHORT G_M000_IG91
       mov      rdi, 0x7E77FB371FEC
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x4E4], eax
       mov      esi, dword ptr [rbp-0x4E4]
       mov      rdi, bword ptr [rbp-0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Trim(int):this]
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_TargetIndex():int:this]
       mov      rcx, bword ptr [rbp-0x30]
       mov      dword ptr [rcx+0x40], eax
       jmp      G_M000_IG116
 
G_M000_IG90:                ;; offset=0x17E5
       mov      rdi, 0x7E77FB371FF0
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG92
 
G_M000_IG91:                ;; offset=0x17F6
       mov      rdi, 0x7E77FB371FF4
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, bword ptr [rbp-0x30]
       mov      rsi, bword ptr [rbp-0x40]
       mov      rdx, qword ptr [rbp-0x120]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:PublishInteger(byref,long):this]
       jmp      G_M000_IG115
 
G_M000_IG92:                ;; offset=0x181F
       mov      rsi, gword ptr [rbp-0x108]
       mov      rdi, 0x7E77FB35AA90
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      gword ptr [rbp-0x138], rax
       cmp      gword ptr [rbp-0x138], 0
       jne      G_M000_IG98
       mov      rsi, gword ptr [rbp-0x108]
       mov      rdi, 0x7E77FB2DF9D0
       call     [CORINFO_HELP_CHKCASTCLASS]
       mov      gword ptr [rbp-0x4F0], rax
       mov      rdi, gword ptr [rbp-0x4F0]
       lea      rsi, [rbp-0x140]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.PyIteration+Cursor:TryMoveNext(byref):bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG95
       call     [Lokad.Lython.Runtime.PyIterationResult:get_End():Lokad.Lython.Runtime.PyIterationResult]
       mov      gword ptr [rbp-0x2C0], rax
       mov      qword ptr [rbp-0x2B8], rdx
 
G_M000_IG93:                ;; offset=0x1897
       vmovdqu32 xmm0, xmmword ptr [rbp-0x2C0]
       vmovdqu32 xmmword ptr [rbp-0x2A0], xmm0
 
G_M000_IG94:                ;; offset=0x18A5
       jmp      SHORT G_M000_IG100
 
G_M000_IG95:                ;; offset=0x18A7
       mov      rdi, 0x7E77FB371FF8
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, gword ptr [rbp-0x140]
       call     [Lokad.Lython.Runtime.PyIterationResult:Yield(System.Object):Lokad.Lython.Runtime.PyIterationResult]
       mov      gword ptr [rbp-0x2B0], rax
       mov      qword ptr [rbp-0x2A8], rdx
 
G_M000_IG96:                ;; offset=0x18D1
       vmovdqu32 xmm0, xmmword ptr [rbp-0x2B0]
       vmovdqu32 xmmword ptr [rbp-0x2A0], xmm0
 
G_M000_IG97:                ;; offset=0x18DF
       jmp      SHORT G_M000_IG100
 
G_M000_IG98:                ;; offset=0x18E1
       mov      rdi, 0x7E77FB371FFC
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, gword ptr [rbp-0x138]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.Text.PyStringOps+CasedWhitespaceIteration:MoveNext():Lokad.Lython.Runtime.PyIterationResult:this]
       mov      gword ptr [rbp-0x290], rax
       mov      qword ptr [rbp-0x288], rdx
 
G_M000_IG99:                ;; offset=0x190D
       vmovdqu32 xmm0, xmmword ptr [rbp-0x290]
       vmovdqu32 xmmword ptr [rbp-0x2A0], xmm0
 
G_M000_IG100:                ;; offset=0x191B
       vmovdqu32 xmm0, xmmword ptr [rbp-0x2A0]
       vmovdqu32 xmmword ptr [rbp-0x130], xmm0
 
G_M000_IG101:                ;; offset=0x1929
       lea      rdi, [rbp-0x130]
       call     [Lokad.Lython.Runtime.PyIterationResult:get_HasValue():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG102
       mov      rdi, 0x7E77FB372000
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x4F4], eax
       mov      esi, dword ptr [rbp-0x4F4]
       mov      rdi, bword ptr [rbp-0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Trim(int):this]
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_TargetIndex():int:this]
       mov      rcx, bword ptr [rbp-0x30]
       mov      dword ptr [rcx+0x40], eax
       jmp      G_M000_IG116
 
G_M000_IG102:                ;; offset=0x197F
       mov      rdi, 0x7E77FB372004
       call     CORINFO_HELP_COUNTPROFILE32
       lea      rdi, [rbp-0x130]
       call     [Lokad.Lython.Runtime.PyIterationResult:get_Value():System.Object:this]
       mov      gword ptr [rbp-0x500], rax
       mov      rdx, gword ptr [rbp-0x500]
       mov      rsi, bword ptr [rbp-0x40]
       mov      rdi, bword ptr [rbp-0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,System.Object):this]
       jmp      G_M000_IG115
 
G_M000_IG103:                ;; offset=0x19BC
       mov      rdi, bword ptr [rbp-0x30]
       mov      rsi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:TryReturnUnpackedTuple(byref):bool:this]
       test     eax, eax
       je       SHORT G_M000_IG104
       mov      rdi, 0x7E77FB372008
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG119
 
G_M000_IG104:                ;; offset=0x19E2
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ItemCount():int:this]
       test     eax, eax
       je       G_M000_IG105
       mov      rax, bword ptr [rbp-0x30]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp-0x30]
       add      rax, 80
       mov      bword ptr [rbp-0x2D0], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x2D4], eax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ItemCount():int:this]
       mov      dword ptr [rbp-0x504], eax
       mov      edx, dword ptr [rbp-0x504]
       mov      esi, dword ptr [rbp-0x2D4]
       mov      rdi, bword ptr [rbp-0x2D0]
       call     [System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:Slice(int,int):System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:this]
       mov      bword ptr [rbp-0x2E8], rax
       mov      qword ptr [rbp-0x2E0], rdx
       mov      rax, bword ptr [rbp-0x30]
       mov      rax, gword ptr [rax+0x18]
       mov      gword ptr [rbp-0x2F0], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x510], rax
       mov      rcx, gword ptr [rbp-0x510]
       mov      rdi, bword ptr [rbp-0x2E8]
       mov      rsi, qword ptr [rbp-0x2E0]
       mov      rdx, gword ptr [rbp-0x2F0]
       call     [Lokad.Lython.Runtime.LythonRuntime:CreateSlotTuple(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.PyTuple]
       mov      gword ptr [rbp-0x2C8], rax
       jmp      SHORT G_M000_IG106
 
G_M000_IG105:                ;; offset=0x1A9B
       mov      rdi, 0x7E77FB37200C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, 0x7E7015801778
       mov      rax, gword ptr [rax]
       mov      gword ptr [rbp-0x2C8], rax
 
G_M000_IG106:                ;; offset=0x1ABE
       mov      rdi, 0x7E77FB372010
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, gword ptr [rbp-0x2C8]
       mov      gword ptr [rbp-0x148], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x514], eax
       mov      esi, dword ptr [rbp-0x514]
       mov      rdi, bword ptr [rbp-0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Trim(int):this]
       mov      rdi, bword ptr [rbp-0x30]
       mov      rsi, bword ptr [rbp-0x40]
       mov      rdx, gword ptr [rbp-0x148]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,System.Object):this]
       jmp      G_M000_IG115
 
G_M000_IG107:                ;; offset=0x1B15
       mov      rdi, 0x7E77FB372014
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp-0x30]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp-0x30]
       add      rax, 80
       mov      bword ptr [rbp-0x2F8], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x2FC], eax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ItemCount():int:this]
       mov      dword ptr [rbp-0x518], eax
       mov      edx, dword ptr [rbp-0x518]
       mov      esi, dword ptr [rbp-0x2FC]
       mov      rdi, bword ptr [rbp-0x2F8]
       call     [System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:Slice(int,int):System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:this]
       mov      bword ptr [rbp-0x310], rax
       mov      qword ptr [rbp-0x308], rdx
       mov      rax, bword ptr [rbp-0x30]
       mov      rax, gword ptr [rax+0x18]
       mov      gword ptr [rbp-0x318], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x520], rax
       mov      rcx, gword ptr [rbp-0x520]
       mov      rdi, bword ptr [rbp-0x310]
       mov      rsi, qword ptr [rbp-0x308]
       mov      rdx, gword ptr [rbp-0x318]
       call     [Lokad.Lython.Runtime.LythonRuntime:CreateSlotList(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.PyList]
       mov      gword ptr [rbp-0x150], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x524], eax
       mov      esi, dword ptr [rbp-0x524]
       mov      rdi, bword ptr [rbp-0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Trim(int):this]
       mov      rdi, bword ptr [rbp-0x30]
       mov      rsi, bword ptr [rbp-0x40]
       mov      rdx, gword ptr [rbp-0x150]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,System.Object):this]
       jmp      G_M000_IG115
 
G_M000_IG108:                ;; offset=0x1C03
       mov      rdi, bword ptr [rbp-0x30]
       mov      rsi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Format(byref):bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG111
       mov      rdi, 0x7E77FB372018
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG109:                ;; offset=0x1C24
       xor      eax, eax
 
G_M000_IG110:                ;; offset=0x1C26
       add      rsp, 0x560
       pop      rbp
       ret      
 
G_M000_IG111:                ;; offset=0x1C2F
       mov      rdi, 0x7E77FB37201C
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG115
 
G_M000_IG112:                ;; offset=0x1C43
       mov      rdi, 0x7E77FB372020
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       inc      eax
       mov      dword ptr [rbp-0x31C], eax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      dword ptr [rbp-0x320], eax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x528], eax
       mov      esi, dword ptr [rbp-0x528]
       mov      rdi, bword ptr [rbp-0x30]
       xor      edx, edx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Read(int,int):System.Object:this]
       mov      gword ptr [rbp-0x530], rax
       mov      rcx, gword ptr [rbp-0x530]
       mov      esi, dword ptr [rbp-0x31C]
       mov      edx, dword ptr [rbp-0x320]
       mov      rdi, bword ptr [rbp-0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Put(int,int,System.Object):this]
       jmp      G_M000_IG115
 
G_M000_IG113:                ;; offset=0x1CBF
       mov      rdi, 0x7E77FB372024
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x534], eax
       mov      esi, dword ptr [rbp-0x534]
       mov      rdi, bword ptr [rbp-0x30]
       xor      edx, edx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Read(int,int):System.Object:this]
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      dword ptr [rbp-0x538], eax
       mov      esi, dword ptr [rbp-0x538]
       mov      rdi, bword ptr [rbp-0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Trim(int):this]
       jmp      G_M000_IG115
 
G_M000_IG114:                ;; offset=0x1D15
       lea      rdi, [rbp-0x178]
       mov      esi, 26
       mov      edx, 1
       call     [System.Runtime.CompilerServices.DefaultInterpolatedStringHandler:.ctor(int,int):this]
       lea      rdi, [rbp-0x178]
       mov      rsi, 0x7E77F1217F18
       call     [System.Runtime.CompilerServices.DefaultInterpolatedStringHandler:AppendLiteral(System.String):this]
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_OpCode():int:this]
       mov      dword ptr [rbp-0x53C], eax
       mov      esi, dword ptr [rbp-0x53C]
       lea      rdi, [rbp-0x178]
       call     [System.Runtime.CompilerServices.DefaultInterpolatedStringHandler:AppendFormatted[int](int):this]
       mov      rdi, 0x7E77FA377A68
       call     CORINFO_HELP_NEWSFAST
       mov      gword ptr [rbp-0x340], rax
       lea      rdi, [rbp-0x178]
       call     [System.Runtime.CompilerServices.DefaultInterpolatedStringHandler:ToStringAndClear():System.String:this]
       mov      gword ptr [rbp-0x548], rax
       mov      rsi, gword ptr [rbp-0x548]
       mov      rdi, gword ptr [rbp-0x340]
       call     [System.InvalidOperationException:.ctor(System.String):this]
       mov      rdi, gword ptr [rbp-0x340]
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG115:                ;; offset=0x1DB1
       mov      rdi, 0x7E77FB372028
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp-0x30]
       inc      dword ptr [rax+0x40]
 
G_M000_IG116:                ;; offset=0x1DC7
       mov      eax, dword ptr [rbp-0x394]
       dec      eax
       mov      dword ptr [rbp-0x394], eax
       cmp      dword ptr [rbp-0x394], 0
       jg       SHORT G_M000_IG118
 
G_M000_IG117:                ;; offset=0x1DDE
       lea      rdi, [rbp-0x394]
       mov      esi, 0x92C
       call     CORINFO_HELP_PATCHPOINT
       jmp      rax
 
G_M000_IG118:                ;; offset=0x1DF1
       mov      rax, bword ptr [rbp-0x30]
       mov      eax, dword ptr [rax+0x40]
       mov      dword ptr [rbp-0x18C], eax
       mov      rax, bword ptr [rbp-0x30]
       mov      rdi, gword ptr [rax+0x08]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Instructions():Lokad.Lython.Frontend.ExecutableInstruction[]:this]
       mov      eax, dword ptr [rax+0x08]
       cmp      eax, dword ptr [rbp-0x18C]
       jg       G_M000_IG03
       mov      rdi, 0x7E77FB37202C
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG119:                ;; offset=0x1E2C
       mov      eax, 1
 
G_M000_IG120:                ;; offset=0x1E31
       add      rsp, 0x560
       pop      rbp
       ret      
 
G_M000_IG121:                ;; offset=0x1E3A
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
RWD00  	dd	000002B3h ; case G_M000_IG11
       	dd	00000350h ; case G_M000_IG12
       	dd	0000048Fh ; case G_M000_IG14
       	dd	000003B8h ; case G_M000_IG13
RWD16  	dd	00000687h ; case G_M000_IG24
       	dd	00001CCBh ; case G_M000_IG114
       	dd	000005F4h ; case G_M000_IG23
       	dd	00000563h ; case G_M000_IG19
       	dd	00001CCBh ; case G_M000_IG114
       	dd	00001CCBh ; case G_M000_IG114
       	dd	00001BF9h ; case G_M000_IG112
       	dd	00001C75h ; case G_M000_IG113
       	dd	00001ACBh ; case G_M000_IG107
       	dd	00001972h ; case G_M000_IG103
       	dd	00001CCBh ; case G_M000_IG114
       	dd	00001CCBh ; case G_M000_IG114
       	dd	00001CCBh ; case G_M000_IG114
       	dd	00001CCBh ; case G_M000_IG114
       	dd	00001CCBh ; case G_M000_IG114
       	dd	00001CCBh ; case G_M000_IG114
       	dd	0000143Eh ; case G_M000_IG77
       	dd	00001681h ; case G_M000_IG89
       	dd	00000855h ; case G_M000_IG29
       	dd	0000088Fh ; case G_M000_IG31
       	dd	00001CCBh ; case G_M000_IG114
       	dd	00001CCBh ; case G_M000_IG114
       	dd	00000CC1h ; case G_M000_IG46
       	dd	00000CC1h ; case G_M000_IG46
       	dd	00000B36h ; case G_M000_IG40
       	dd	000013C3h ; case G_M000_IG74
       	dd	000012EFh ; case G_M000_IG71
       	dd	0000115Dh ; case G_M000_IG67
       	dd	00001CCBh ; case G_M000_IG114
       	dd	00001CCBh ; case G_M000_IG114
       	dd	00001CCBh ; case G_M000_IG114
       	dd	00001CCBh ; case G_M000_IG114
       	dd	00001CCBh ; case G_M000_IG114
       	dd	0000018Ah ; case G_M000_IG09
       	dd	00000150h ; case G_M000_IG08
       	dd	00000150h ; case G_M000_IG08
       	dd	00001CCBh ; case G_M000_IG114
       	dd	00001CCBh ; case G_M000_IG114
       	dd	000013E8h ; case G_M000_IG75
       	dd	00001BB9h ; case G_M000_IG108
       	dd	00001BB9h ; case G_M000_IG108
       	dd	00001BB9h ; case G_M000_IG108
       	dd	00001BB9h ; case G_M000_IG108
       	dd	00001BB9h ; case G_M000_IG108

; Total bytes of code 7744

; Assembly listing for method Lokad.Lython.Runtime.LythonRuntime+NativeExecution:RunCore(byref):bool:this (Instrumented Tier0)
; Emitting BLENDED_CODE for x64 + VEX + EVEX on Unix
; Instrumented Tier0 code
; rbp based frame
; partially interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 0x560
       lea      rbp, [rsp+0x560]
       vxorps   xmm8, xmm8, xmm8
       vmovdqa32 xmmword ptr [rbp-0x560], xmm8
       mov      rax, -0x510
 
G_M000_IG122:                ;; offset=0x0026
       vmovdqa  xmmword ptr [rbp+rax-0x40], xmm8
       vmovdqa  xmmword ptr [rbp+rax-0x30], xmm8
       vmovdqa  xmmword ptr [rbp+rax-0x20], xmm8
       add      rax, 48
       jne      SHORT G_M000_IG122
       mov      qword ptr [rbp-0x40], rax
       mov      bword ptr [rbp-0x30], rdi
       mov      bword ptr [rbp-0x38], rsi
 
G_M000_IG02:                ;; offset=0x004A
       mov      dword ptr [rbp-0x394], 0x3E8
       mov      rax, 0x7E70158016F0
       mov      rdi, gword ptr [rax]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:FromObject(System.Object):Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]
       mov      gword ptr [rbp-0x188], rax
       mov      qword ptr [rbp-0x180], rdx
       mov      rax, bword ptr [rbp-0x38]
       mov      bword ptr [rbp-0x550], rax
       mov      rdi, bword ptr [rbp-0x550]
       mov      rsi, gword ptr [rbp-0x188]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rax, bword ptr [rbp-0x550]
       mov      rcx, qword ptr [rbp-0x180]
       mov      qword ptr [rax+0x08], rcx
       jmp      G_M000_IG116
 
G_M000_IG03:                ;; offset=0x00AA
       mov      rax, bword ptr [rbp-0x30]
       mov      rdi, gword ptr [rax+0x08]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Instructions():Lokad.Lython.Frontend.ExecutableInstruction[]:this]
       mov      rcx, bword ptr [rbp-0x30]
       mov      ecx, dword ptr [rcx+0x40]
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG121
       mov      edx, ecx
       imul     rdx, rdx, 32
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      bword ptr [rbp-0x40], rax
       mov      rax, bword ptr [rbp-0x30]
       mov      rdi, gword ptr [rax+0x18]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:get_State():Lokad.Lython.Runtime.ExecutionState:this]
       mov      gword ptr [rbp-0x198], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x3A0], rax
       mov      rsi, gword ptr [rbp-0x3A0]
       mov      rdi, gword ptr [rbp-0x198]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.ExecutionState:CheckExecution(Lokad.Lython.LythonSourceSpan):this]
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_OpCode():int:this]
       mov      dword ptr [rbp-0x64], eax
       mov      eax, dword ptr [rbp-0x64]
       add      eax, -3
       mov      dword ptr [rbp-0x554], eax
       cmp      dword ptr [rbp-0x554], 3
       ja       SHORT G_M000_IG05
 
G_M000_IG04:                ;; offset=0x0139
       mov      eax, dword ptr [rbp-0x554]
       lea      rcx, [reloc @RWD00]
       mov      ecx, dword ptr [rcx+4*rax]
       lea      rdx, G_M000_IG02
       add      rcx, rdx
       jmp      rcx
 
G_M000_IG05:                ;; offset=0x0155
       mov      eax, dword ptr [rbp-0x64]
       add      eax, -25
       mov      dword ptr [rbp-0x558], eax
       cmp      dword ptr [rbp-0x558], 43
       ja       SHORT G_M000_IG07
 
G_M000_IG06:                ;; offset=0x016A
       mov      eax, dword ptr [rbp-0x558]
       lea      rcx, [reloc @RWD16]
       mov      ecx, dword ptr [rcx+4*rax]
       lea      rdx, G_M000_IG02
       add      rcx, rdx
       jmp      rcx
 
G_M000_IG07:                ;; offset=0x0186
       mov      rdi, 0x7E77FB371BC0
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG114
 
G_M000_IG08:                ;; offset=0x019A
       mov      rdi, 0x7E77FB371BC4
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp-0x30]
       mov      rdi, gword ptr [rax+0x08]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_FirstTemporarySlot():int:this]
       mov      dword ptr [rbp-0x3A4], eax
       mov      esi, dword ptr [rbp-0x3A4]
       mov      rdi, bword ptr [rbp-0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Trim(int):this]
       jmp      G_M000_IG119
 
G_M000_IG09:                ;; offset=0x01D4
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x3A8], eax
       mov      esi, dword ptr [rbp-0x3A8]
       mov      rdi, bword ptr [rbp-0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:ReadReturnSlot(int):Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:this]
       mov      gword ptr [rbp-0x1A8], rax
       mov      qword ptr [rbp-0x1A0], rdx
       mov      rax, bword ptr [rbp-0x38]
       mov      bword ptr [rbp-0x560], rax
       mov      rdi, bword ptr [rbp-0x560]
       mov      rsi, gword ptr [rbp-0x1A8]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rax, bword ptr [rbp-0x560]
       mov      rcx, qword ptr [rbp-0x1A0]
       mov      qword ptr [rax+0x08], rcx
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x1AC], eax
       mov      rax, bword ptr [rbp-0x30]
       mov      rdi, gword ptr [rax+0x08]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_FirstTemporarySlot():int:this]
       cmp      eax, dword ptr [rbp-0x1AC]
       jg       SHORT G_M000_IG10
       mov      rdi, 0x7E77FB371BC8
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp-0x30]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp-0x30]
       add      rax, 80
       mov      bword ptr [rbp-0x1B8], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x1BC], eax
       mov      rax, bword ptr [rbp-0x1B8]
       mov      eax, dword ptr [rax+0x08]
       cmp      dword ptr [rbp-0x1BC], eax
       jae      G_M000_IG121
       mov      rax, bword ptr [rbp-0x1B8]
       mov      ecx, dword ptr [rbp-0x1BC]
       shl      rcx, 4
       add      rcx, bword ptr [rax]
       mov      rdi, rcx
       xor      rsi, rsi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:set_Object(System.Object):this]
 
G_M000_IG10:                ;; offset=0x02C3
       mov      rdi, 0x7E77FB371BCC
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp-0x30]
       mov      rdi, gword ptr [rax+0x08]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_FirstTemporarySlot():int:this]
       mov      dword ptr [rbp-0x3AC], eax
       mov      esi, dword ptr [rbp-0x3AC]
       mov      rdi, bword ptr [rbp-0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Trim(int):this]
       jmp      G_M000_IG119
 
G_M000_IG11:                ;; offset=0x02FD
       mov      rax, bword ptr [rbp-0x30]
       mov      rdi, gword ptr [rax+0x08]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Constants():System.Collections.Generic.IReadOnlyList`1[System.Object]:this]
       mov      gword ptr [rbp-0x378], rax
       mov      rax, gword ptr [rbp-0x378]
       mov      gword ptr [rbp-0x380], rax
       mov      rdi, gword ptr [rbp-0x380]
       mov      rsi, 0x7E77FB371BD0
       call     CORINFO_HELP_CLASSPROFILE32
       mov      rax, gword ptr [rbp-0x380]
       mov      gword ptr [rbp-0x3B8], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ConstantIndex():int:this]
       mov      dword ptr [rbp-0x3BC], eax
       mov      rdi, gword ptr [rbp-0x3B8]
       mov      esi, dword ptr [rbp-0x3BC]
       mov      r11, 0x7E77F8A426C8
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       mov      rdi, rax
       call     [Lokad.Lython.Runtime.LythonRuntime:RuntimeValue(System.Object):System.Object]
       mov      gword ptr [rbp-0x3C8], rax
       mov      rdx, gword ptr [rbp-0x3C8]
       mov      rsi, bword ptr [rbp-0x40]
       mov      rdi, bword ptr [rbp-0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,System.Object):this]
       jmp      G_M000_IG115
 
G_M000_IG12:                ;; offset=0x039A
       mov      rdi, 0x7E77FB371CD8
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LocalSlot():int:this]
       mov      dword ptr [rbp-0x36C], eax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x3D0], rax
       mov      rdx, gword ptr [rbp-0x3D0]
       mov      esi, dword ptr [rbp-0x36C]
       mov      rdi, bword ptr [rbp-0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:ReadLocal(int,Lokad.Lython.LythonSourceSpan):System.Object:this]
       mov      gword ptr [rbp-0x3D8], rax
       mov      rdx, gword ptr [rbp-0x3D8]
       mov      rsi, bword ptr [rbp-0x40]
       mov      rdi, bword ptr [rbp-0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,System.Object):this]
       jmp      G_M000_IG115
 
G_M000_IG13:                ;; offset=0x0402
       mov      rdi, 0x7E77FB371CDC
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp-0x30]
       mov      rdi, gword ptr [rax+0x08]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Names():System.Collections.Generic.IReadOnlyList`1[System.String]:this]
       mov      gword ptr [rbp-0x360], rax
       mov      rax, gword ptr [rbp-0x360]
       mov      gword ptr [rbp-0x388], rax
       mov      rdi, gword ptr [rbp-0x388]
       mov      rsi, 0x7E77FB371CE0
       call     CORINFO_HELP_CLASSPROFILE32
       mov      rax, gword ptr [rbp-0x388]
       mov      gword ptr [rbp-0x3E0], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_NameIndex():int:this]
       mov      dword ptr [rbp-0x3E4], eax
       mov      rdi, gword ptr [rbp-0x3E0]
       mov      esi, dword ptr [rbp-0x3E4]
       mov      r11, 0x7E77F8A426C0
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       mov      gword ptr [rbp-0x368], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x3F0], rax
       mov      rsi, gword ptr [rbp-0x3F0]
       mov      rax, bword ptr [rbp-0x30]
       mov      rdx, gword ptr [rax+0x18]
       mov      rdi, gword ptr [rbp-0x368]
       call     [Lokad.Lython.Runtime.LythonRuntime:ResolveExecutableGlobal(System.String,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):System.Object]
       mov      gword ptr [rbp-0x3F8], rax
       mov      rdx, gword ptr [rbp-0x3F8]
       mov      rsi, bword ptr [rbp-0x40]
       mov      rdi, bword ptr [rbp-0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,System.Object):this]
       jmp      G_M000_IG115
 
G_M000_IG14:                ;; offset=0x04D9
       mov      rax, bword ptr [rbp-0x30]
       mov      r8, gword ptr [rax+0x18]
       mov      rax, bword ptr [rbp-0x30]
       mov      rdi, gword ptr [rax+0x08]
       mov      rax, bword ptr [rbp-0x30]
       mov      rsi, gword ptr [rax+0x10]
       mov      rax, bword ptr [rbp-0x30]
       mov      edx, dword ptr [rax+0x40]
       mov      rax, bword ptr [rbp-0x30]
       mov      ecx, dword ptr [rax+0x44]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryExecuteClosureArithmetic(Lokad.Lython.Frontend.ExecutableCodeObject,System.Collections.Generic.IReadOnlyList`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableCell],int,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):bool]
       test     eax, eax
       je       SHORT G_M000_IG15
       mov      rdi, 0x7E77FB371DE8
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp-0x30]
       add      dword ptr [rax+0x40], 2
       jmp      G_M000_IG115
 
G_M000_IG15:                ;; offset=0x0525
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ClosureSlot():int:this]
       mov      dword ptr [rbp-0x3FC], eax
       mov      esi, dword ptr [rbp-0x3FC]
       lea      rdx, [rbp-0x48]
       mov      rdi, bword ptr [rbp-0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:TryCell(int,byref):bool:this]
       test     eax, eax
       je       SHORT G_M000_IG17
       mov      rdi, gword ptr [rbp-0x48]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableCell:get_Value():System.Object:this]
       mov      gword ptr [rbp-0x50], rax
       cmp      gword ptr [rbp-0x50], 0
       jne      SHORT G_M000_IG18
 
G_M000_IG16:                ;; offset=0x0564
       mov      rdi, 0x7E77FB371DEC
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG17:                ;; offset=0x0573
       mov      rdi, 0x7E77FB371DF0
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG109
 
G_M000_IG18:                ;; offset=0x0587
       mov      rdi, 0x7E77FB371DF4
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, bword ptr [rbp-0x30]
       mov      rsi, bword ptr [rbp-0x40]
       mov      rdx, gword ptr [rbp-0x50]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,System.Object):this]
       jmp      G_M000_IG115
 
G_M000_IG19:                ;; offset=0x05AD
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ClosureSlot():int:this]
       mov      dword ptr [rbp-0x400], eax
       mov      esi, dword ptr [rbp-0x400]
       lea      rdx, [rbp-0x58]
       mov      rdi, bword ptr [rbp-0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:TryCell(int,byref):bool:this]
       test     eax, eax
       je       SHORT G_M000_IG21
       mov      rdi, gword ptr [rbp-0x58]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableCell:get_CanStoreThroughOwner():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG22
 
G_M000_IG20:                ;; offset=0x05E5
       mov      rdi, 0x7E77FB371DF8
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG21:                ;; offset=0x05F4
       mov      rdi, 0x7E77FB371DFC
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG109
 
G_M000_IG22:                ;; offset=0x0608
       mov      rdi, 0x7E77FB371E00
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, bword ptr [rbp-0x30]
       mov      rsi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Take(byref):System.Object:this]
       mov      gword ptr [rbp-0x60], rax
       mov      rdi, gword ptr [rbp-0x58]
       mov      rsi, gword ptr [rbp-0x60]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableCell:set_Value(System.Object):this]
       jmp      G_M000_IG115
 
G_M000_IG23:                ;; offset=0x063E
       mov      rdi, 0x7E77FB371E04
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp-0x30]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp-0x30]
       add      rax, 80
       mov      bword ptr [rbp-0x328], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LocalSlot():int:this]
       mov      dword ptr [rbp-0x32C], eax
       mov      rax, bword ptr [rbp-0x328]
       mov      eax, dword ptr [rax+0x08]
       cmp      dword ptr [rbp-0x32C], eax
       jae      G_M000_IG121
       mov      rax, bword ptr [rbp-0x328]
       mov      ecx, dword ptr [rbp-0x32C]
       shl      rcx, 4
       add      rcx, bword ptr [rax]
       mov      bword ptr [rbp-0x338], rcx
       mov      rdi, bword ptr [rbp-0x30]
       mov      rsi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Take(byref):System.Object:this]
       mov      gword ptr [rbp-0x408], rax
       mov      rsi, gword ptr [rbp-0x408]
       mov      rdi, bword ptr [rbp-0x338]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:set_Object(System.Object):this]
       jmp      G_M000_IG115
 
G_M000_IG24:                ;; offset=0x06D1
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x40C], eax
       mov      esi, dword ptr [rbp-0x40C]
       mov      rdi, bword ptr [rbp-0x30]
       xor      edx, edx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Read(int,int):System.Object:this]
       mov      gword ptr [rbp-0x70], rax
       mov      rax, bword ptr [rbp-0x30]
       mov      rdi, gword ptr [rax+0x08]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Names():System.Collections.Generic.IReadOnlyList`1[System.String]:this]
       mov      gword ptr [rbp-0x348], rax
       mov      rax, gword ptr [rbp-0x348]
       mov      gword ptr [rbp-0x390], rax
       mov      rdi, gword ptr [rbp-0x390]
       mov      rsi, 0x7E77FB371E08
       call     CORINFO_HELP_CLASSPROFILE32
       mov      rax, gword ptr [rbp-0x390]
       mov      gword ptr [rbp-0x418], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_NameIndex():int:this]
       mov      dword ptr [rbp-0x41C], eax
       mov      rdi, gword ptr [rbp-0x418]
       mov      esi, dword ptr [rbp-0x41C]
       mov      r11, 0x7E77F8A426B8
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       mov      gword ptr [rbp-0x78], rax
       mov      rsi, gword ptr [rbp-0x70]
       mov      rdi, 0x7E77FB144048
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       jne      SHORT G_M000_IG26
       mov      rsi, gword ptr [rbp-0x70]
       mov      rdi, 0x7E77FB2DD8E0
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       jne      SHORT G_M000_IG25
       xor      rax, rax
       mov      gword ptr [rbp-0x350], rax
       jmp      SHORT G_M000_IG27
 
G_M000_IG25:                ;; offset=0x07AB
       mov      rdi, 0x7E77FB371F10
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, gword ptr [rbp-0x78]
       call     [Lokad.Lython.Runtime.LythonRuntime+DictMembers:GetMethod(System.String):Lokad.Lython.Runtime.LythonRuntime+ReceiverMethod]
       mov      gword ptr [rbp-0x350], rax
       jmp      SHORT G_M000_IG27
 
G_M000_IG26:                ;; offset=0x07CD
       mov      rdi, 0x7E77FB371F14
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, gword ptr [rbp-0x78]
       call     [Lokad.Lython.Runtime.LythonRuntime+StringMembers:GetMethod(System.String):Lokad.Lython.Runtime.LythonRuntime+ReceiverMethod]
       mov      gword ptr [rbp-0x350], rax
 
G_M000_IG27:                ;; offset=0x07ED
       mov      rax, gword ptr [rbp-0x350]
       mov      gword ptr [rbp-0x80], rax
       cmp      gword ptr [rbp-0x80], 0
       jne      SHORT G_M000_IG28
       mov      rdi, 0x7E77FB371F18
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG109
 
G_M000_IG28:                ;; offset=0x0813
       mov      rdi, 0x7E77FB371F1C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       mov      dword ptr [rbp-0x354], eax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       inc      eax
       mov      dword ptr [rbp-0x420], eax
       mov      edx, dword ptr [rbp-0x420]
       mov      esi, dword ptr [rbp-0x354]
       mov      rdi, bword ptr [rbp-0x30]
       mov      rcx, gword ptr [rbp-0x70]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Put(int,int,System.Object):this]
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       inc      eax
       mov      dword ptr [rbp-0x358], eax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      dword ptr [rbp-0x424], eax
       mov      edx, dword ptr [rbp-0x424]
       mov      esi, dword ptr [rbp-0x358]
       mov      rdi, bword ptr [rbp-0x30]
       mov      rcx, gword ptr [rbp-0x80]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Put(int,int,System.Object):this]
       jmp      G_M000_IG115
 
G_M000_IG29:                ;; offset=0x089F
       mov      rdi, bword ptr [rbp-0x30]
       mov      rsi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Call(byref):bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG30
       mov      rdi, 0x7E77FB371F20
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG109
 
G_M000_IG30:                ;; offset=0x08C5
       mov      rdi, 0x7E77FB371F24
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG115
 
G_M000_IG31:                ;; offset=0x08D9
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x428], eax
       mov      esi, dword ptr [rbp-0x428]
       mov      rdi, bword ptr [rbp-0x30]
       xor      edx, edx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Read(int,int):System.Object:this]
       mov      gword ptr [rbp-0x258], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_SecondInput():int:this]
       mov      dword ptr [rbp-0x42C], eax
       mov      esi, dword ptr [rbp-0x42C]
       mov      rdi, bword ptr [rbp-0x30]
       mov      edx, 1
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Read(int,int):System.Object:this]
       mov      gword ptr [rbp-0x88], rax
       mov      rsi, gword ptr [rbp-0x258]
       mov      rdi, 0x7E77FB2DD8E0
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      gword ptr [rbp-0x90], rax
       cmp      gword ptr [rbp-0x90], 0
       je       SHORT G_M000_IG33
       mov      rdi, gword ptr [rbp-0x90]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.PyDict:get_HasProtocolKeys():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG34
       mov      rsi, gword ptr [rbp-0x88]
       mov      rdi, 0x7E77FB144048
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      gword ptr [rbp-0x98], rax
       cmp      gword ptr [rbp-0x98], 0
       jne      SHORT G_M000_IG35
 
G_M000_IG32:                ;; offset=0x0991
       mov      rdi, 0x7E77FB371F28
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG33:                ;; offset=0x09A0
       mov      rdi, 0x7E77FB371F2C
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG109
 
G_M000_IG34:                ;; offset=0x09B4
       mov      rdi, 0x7E77FB371F30
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG33
 
G_M000_IG35:                ;; offset=0x09C5
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LookupCacheIndex():int:this]
       test     eax, eax
       jl       G_M000_IG38
       mov      rdi, gword ptr [rbp-0x90]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.PyDict:get_HasSharedRecordKeys():bool:this]
       test     eax, eax
       je       G_M000_IG37
       mov      rax, bword ptr [rbp-0x30]
       mov      rax, gword ptr [rax]
       mov      gword ptr [rbp-0x260], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x438], rax
       mov      rsi, gword ptr [rbp-0x438]
       mov      rdi, gword ptr [rbp-0x260]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.PyExecutableFunction:GetLookupCaches(Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.LythonRuntime+ExecutableLookupCache[]:this]
       mov      gword ptr [rbp-0xA0], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LookupCacheIndex():int:this]
       mov      rcx, gword ptr [rbp-0xA0]
       cmp      eax, dword ptr [rcx+0x08]
       jae      G_M000_IG121
       mov      edx, eax
       imul     rdx, rdx, 24
       lea      rcx, bword ptr [rcx+rdx+0x10]
       mov      bword ptr [rbp-0x268], rcx
       mov      rax, bword ptr [rbp-0x30]
       mov      rax, gword ptr [rax+0x18]
       mov      gword ptr [rbp-0x270], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x440], rax
       mov      r8, gword ptr [rbp-0x440]
       lea      r9, [rbp-0xA8]
       mov      rsi, gword ptr [rbp-0x98]
       mov      rdx, bword ptr [rbp-0x268]
       mov      rcx, gword ptr [rbp-0x270]
       mov      rdi, gword ptr [rbp-0x90]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.PyDict:TryReadRecordValue(Lokad.Lython.Runtime.Text.PyString,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,byref):bool:this]
       test     eax, eax
       je       SHORT G_M000_IG36
       mov      rdi, 0x7E77FB371F34
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, bword ptr [rbp-0x30]
       mov      rsi, bword ptr [rbp-0x40]
       mov      rdx, gword ptr [rbp-0xA8]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,System.Object):this]
       jmp      G_M000_IG115
 
G_M000_IG36:                ;; offset=0x0AD5
       mov      rdi, 0x7E77FB371F38
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG38
 
G_M000_IG37:                ;; offset=0x0AE6
       mov      rdi, 0x7E77FB371F3C
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG38:                ;; offset=0x0AF5
       mov      rdi, gword ptr [rbp-0x90]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.PyDict:get_HasProtocolKeys():bool:this]
       test     eax, eax
       je       SHORT G_M000_IG39
       mov      rdi, 0x7E77FB371F40
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG109
 
G_M000_IG39:                ;; offset=0x0B1C
       mov      rdi, 0x7E77FB371F44
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x448], rax
       mov      rdx, gword ptr [rbp-0x448]
       mov      rax, bword ptr [rbp-0x30]
       mov      rcx, gword ptr [rax+0x18]
       mov      rsi, gword ptr [rbp-0x98]
       mov      rdi, gword ptr [rbp-0x90]
       call     [Lokad.Lython.Runtime.LythonRuntime:ReadSubscriptValue(System.Object,System.Object,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):System.Object]
       mov      gword ptr [rbp-0x450], rax
       mov      rdx, gword ptr [rbp-0x450]
       mov      rsi, bword ptr [rbp-0x40]
       mov      rdi, bword ptr [rbp-0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,System.Object):this]
       jmp      G_M000_IG115
 
G_M000_IG40:                ;; offset=0x0B80
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x454], eax
       mov      esi, dword ptr [rbp-0x454]
       mov      rdi, bword ptr [rbp-0x30]
       xor      edx, edx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Read(int,int):System.Object:this]
       mov      gword ptr [rbp-0xB0], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_UnaryOperator():int:this]
       test     eax, eax
       je       G_M000_IG43
       mov      rsi, gword ptr [rbp-0xB0]
       mov      rdi, 0x7E77FB02B158
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       jne      SHORT G_M000_IG42
       mov      rsi, gword ptr [rbp-0xB0]
       mov      rdi, 0x7E77F9C96558
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       jne      SHORT G_M000_IG41
       mov      rdi, 0x7E77FB371F48
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rsi, gword ptr [rbp-0xB0]
       mov      rdi, 0x7E77F9C635C8
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       sete     al
       movzx    rax, al
       mov      dword ptr [rbp-0x1E4], eax
       jmp      SHORT G_M000_IG44
 
G_M000_IG41:                ;; offset=0x0C2A
       mov      rdi, 0x7E77FB371F4C
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG42:                ;; offset=0x0C39
       xor      eax, eax
       mov      dword ptr [rbp-0x1E4], eax
       jmp      SHORT G_M000_IG44
 
G_M000_IG43:                ;; offset=0x0C43
       mov      rdi, 0x7E77FB371F50
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, gword ptr [rbp-0xB0]
       call     [Lokad.Lython.Runtime.LythonRuntime:CanUseNativeTruth(System.Object):bool]
       test     eax, eax
       sete     al
       movzx    rax, al
       mov      dword ptr [rbp-0x1E4], eax
 
G_M000_IG44:                ;; offset=0x0C6D
       cmp      dword ptr [rbp-0x1E4], 0
       je       SHORT G_M000_IG45
       mov      rdi, 0x7E77FB371F54
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG109
 
G_M000_IG45:                ;; offset=0x0C8A
       mov      rdi, 0x7E77FB371F58
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_UnaryOperator():int:this]
       mov      dword ptr [rbp-0x1E8], eax
       mov      rax, bword ptr [rbp-0x30]
       mov      rax, gword ptr [rax+0x18]
       mov      gword ptr [rbp-0x1F0], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x460], rax
       mov      rcx, gword ptr [rbp-0x460]
       mov      rsi, gword ptr [rbp-0xB0]
       mov      rdx, gword ptr [rbp-0x1F0]
       mov      edi, dword ptr [rbp-0x1E8]
       call     [Lokad.Lython.Runtime.LythonRuntime:EvaluateExecutableUnary(int,System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):System.Object]
       mov      gword ptr [rbp-0x468], rax
       mov      rdx, gword ptr [rbp-0x468]
       mov      rsi, bword ptr [rbp-0x40]
       mov      rdi, bword ptr [rbp-0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,System.Object):this]
       jmp      G_M000_IG115
 
G_M000_IG46:                ;; offset=0x0D0B
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_OpCode():int:this]
       cmp      eax, 48
       jne      SHORT G_M000_IG48
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_AugmentedOperator():int:this]
       cmp      eax, 3
       jne      SHORT G_M000_IG47
       mov      rdi, 0x7E77FB371F5C
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG109
 
G_M000_IG47:                ;; offset=0x0D3D
       mov      rdi, 0x7E77FB371F60
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG48:                ;; offset=0x0D4C
       mov      rdi, bword ptr [rbp-0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:TryIntegerOperation():bool:this]
       test     eax, eax
       jne      G_M000_IG51
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x46C], eax
       mov      esi, dword ptr [rbp-0x46C]
       mov      rdi, bword ptr [rbp-0x30]
       xor      edx, edx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Read(int,int):System.Object:this]
       mov      gword ptr [rbp-0xB8], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_SecondInput():int:this]
       mov      dword ptr [rbp-0x470], eax
       mov      esi, dword ptr [rbp-0x470]
       mov      rdi, bword ptr [rbp-0x30]
       mov      edx, 1
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Read(int,int):System.Object:this]
       mov      gword ptr [rbp-0xC0], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_OpCode():int:this]
       cmp      eax, 48
       sete     al
       movzx    rax, al
       mov      dword ptr [rbp-0xC4], eax
       cmp      dword ptr [rbp-0xC4], 0
       jne      G_M000_IG52
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_BinaryOperator():int:this]
       mov      dword ptr [rbp-0x244], eax
       mov      rax, bword ptr [rbp-0x30]
       mov      rax, gword ptr [rax+0x18]
       mov      gword ptr [rbp-0x250], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x478], rax
       mov      r8, gword ptr [rbp-0x478]
       lea      r9, [rbp-0xD0]
       mov      rsi, gword ptr [rbp-0xB8]
       mov      rdx, gword ptr [rbp-0xC0]
       mov      rcx, gword ptr [rbp-0x250]
       mov      edi, dword ptr [rbp-0x244]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryEvaluateScalarComparison(int,System.Object,System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,byref):bool]
       test     eax, eax
       je       SHORT G_M000_IG50
       mov      rdi, 0x7E77FB371F64
       call     CORINFO_HELP_COUNTPROFILE32
       movzx    rdi, byte  ptr [rbp-0xD0]
       call     [Lokad.Lython.Runtime.LythonRuntime:RuntimeValue(bool):System.Object]
       mov      gword ptr [rbp-0x480], rax
       mov      rdx, gword ptr [rbp-0x480]
       mov      rsi, bword ptr [rbp-0x40]
       mov      rdi, bword ptr [rbp-0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,System.Object):this]
 
G_M000_IG49:                ;; offset=0x0E75
       jmp      G_M000_IG115
 
G_M000_IG50:                ;; offset=0x0E7A
       mov      rdi, 0x7E77FB371F68
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG52
 
G_M000_IG51:                ;; offset=0x0E8B
       mov      rdi, 0x7E77FB371F6C
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG115
 
G_M000_IG52:                ;; offset=0x0E9F
       cmp      dword ptr [rbp-0xC4], 0
       jne      SHORT G_M000_IG53
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_BinaryOperator():int:this]
       mov      dword ptr [rbp-0x1F4], eax
       jmp      SHORT G_M000_IG54
 
G_M000_IG53:                ;; offset=0x0EBA
       mov      rdi, 0x7E77FB371F70
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_AugmentedOperator():int:this]
       mov      edi, eax
       call     [Lokad.Lython.Runtime.LythonRuntime:AugmentedBinaryOperator(int):int]
       mov      dword ptr [rbp-0x1F4], eax
 
G_M000_IG54:                ;; offset=0x0EE1
       mov      edi, dword ptr [rbp-0x1F4]
       mov      rsi, gword ptr [rbp-0xB8]
       mov      rdx, gword ptr [rbp-0xC0]
       call     [Lokad.Lython.Runtime.LythonRuntime:CanUseNativeBinary(int,System.Object,System.Object):bool]
       test     eax, eax
       jne      SHORT G_M000_IG55
       mov      rdi, 0x7E77FB371F74
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG109
 
G_M000_IG55:                ;; offset=0x0F13
       cmp      dword ptr [rbp-0xC4], 0
       je       G_M000_IG64
       mov      rsi, gword ptr [rbp-0xB8]
       mov      rdi, 0x7E77FB02B158
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       jne      SHORT G_M000_IG57
       mov      rsi, gword ptr [rbp-0xB8]
       mov      rdi, 0x7E77F9C96558
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       jne      G_M000_IG63
       mov      rsi, gword ptr [rbp-0xB8]
       mov      rdi, 0x7E77F9C635C8
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       je       G_M000_IG62
 
G_M000_IG56:                ;; offset=0x0F7C
       mov      rdi, 0x7E77FB371F78
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG57:                ;; offset=0x0F8B
       mov      rsi, gword ptr [rbp-0xC0]
       mov      rdi, 0x7E77FB02B158
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       jne      SHORT G_M000_IG61
       mov      rsi, gword ptr [rbp-0xC0]
       mov      rdi, 0x7E77F9C96558
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       jne      SHORT G_M000_IG60
       mov      rsi, gword ptr [rbp-0xC0]
       mov      rdi, 0x7E77F9C635C8
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       jne      SHORT G_M000_IG59
 
G_M000_IG58:                ;; offset=0x0FDF
       mov      rdi, 0x7E77FB371F7C
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG109
 
G_M000_IG59:                ;; offset=0x0FF3
       mov      rdi, 0x7E77FB371F80
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG64
 
G_M000_IG60:                ;; offset=0x1004
       mov      rdi, 0x7E77FB371F84
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG64
 
G_M000_IG61:                ;; offset=0x1015
       mov      rdi, 0x7E77FB371F88
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG64
 
G_M000_IG62:                ;; offset=0x1026
       mov      rdi, 0x7E77FB371F8C
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG58
 
G_M000_IG63:                ;; offset=0x1037
       mov      rdi, 0x7E77FB371F90
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG57
 
G_M000_IG64:                ;; offset=0x104B
       mov      rax, bword ptr [rbp-0x30]
       mov      bword ptr [rbp-0x200], rax
       mov      rax, bword ptr [rbp-0x40]
       mov      bword ptr [rbp-0x208], rax
       cmp      dword ptr [rbp-0xC4], 0
       jne      G_M000_IG65
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_BinaryOperator():int:this]
       mov      dword ptr [rbp-0x234], eax
       mov      rax, bword ptr [rbp-0x30]
       mov      rax, gword ptr [rax+0x18]
       mov      gword ptr [rbp-0x240], rax
       mov      rax, bword ptr [rbp-0x200]
       mov      bword ptr [rbp-0x220], rax
       mov      rax, bword ptr [rbp-0x208]
       mov      bword ptr [rbp-0x228], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x488], rax
       mov      r8, gword ptr [rbp-0x488]
       mov      rsi, gword ptr [rbp-0xB8]
       mov      rdx, gword ptr [rbp-0xC0]
       mov      rcx, gword ptr [rbp-0x240]
       mov      edi, dword ptr [rbp-0x234]
       call     [Lokad.Lython.Runtime.LythonRuntime:EvaluateBinaryOperator(int,System.Object,System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):System.Object]
       mov      gword ptr [rbp-0x230], rax
       jmp      G_M000_IG66
 
G_M000_IG65:                ;; offset=0x10EE
       mov      rdi, 0x7E77FB371F94
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_AugmentedOperator():int:this]
       mov      dword ptr [rbp-0x20C], eax
       mov      rax, bword ptr [rbp-0x30]
       mov      rax, gword ptr [rax+0x18]
       mov      gword ptr [rbp-0x218], rax
       mov      rax, bword ptr [rbp-0x200]
       mov      bword ptr [rbp-0x220], rax
       mov      rax, bword ptr [rbp-0x208]
       mov      bword ptr [rbp-0x228], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x490], rax
       mov      r8, gword ptr [rbp-0x490]
       mov      rsi, gword ptr [rbp-0xC0]
       mov      edx, dword ptr [rbp-0x20C]
       mov      rcx, gword ptr [rbp-0x218]
       mov      rdi, gword ptr [rbp-0xB8]
       call     [Lokad.Lython.Runtime.LythonRuntime:EvaluateAugmentedBuiltin(System.Object,System.Object,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):System.Object]
       mov      gword ptr [rbp-0x230], rax
 
G_M000_IG66:                ;; offset=0x1178
       mov      rdi, 0x7E77FB371F98
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, bword ptr [rbp-0x220]
       mov      rsi, bword ptr [rbp-0x228]
       mov      rdx, gword ptr [rbp-0x230]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,System.Object):this]
       jmp      G_M000_IG115
 
G_M000_IG67:                ;; offset=0x11A7
       lea      rdx, [rbp-0xD8]
       mov      rdi, bword ptr [rbp-0x30]
       mov      rsi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:TryIntegerComparison(byref,byref):bool:this]
       test     eax, eax
       jne      G_M000_IG69
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x494], eax
       mov      esi, dword ptr [rbp-0x494]
       mov      rdi, bword ptr [rbp-0x30]
       xor      edx, edx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Read(int,int):System.Object:this]
       mov      gword ptr [rbp-0xE0], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_SecondInput():int:this]
       mov      dword ptr [rbp-0x498], eax
       mov      esi, dword ptr [rbp-0x498]
       mov      rdi, bword ptr [rbp-0x30]
       mov      edx, 1
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Read(int,int):System.Object:this]
       mov      gword ptr [rbp-0xE8], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_BinaryOperator():int:this]
       mov      dword ptr [rbp-0x1CC], eax
       mov      rax, bword ptr [rbp-0x30]
       mov      rax, gword ptr [rax+0x18]
       mov      gword ptr [rbp-0x1D8], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x4A0], rax
       mov      r8, gword ptr [rbp-0x4A0]
       lea      r9, [rbp-0xD8]
       mov      rsi, gword ptr [rbp-0xE0]
       mov      rdx, gword ptr [rbp-0xE8]
       mov      rcx, gword ptr [rbp-0x1D8]
       mov      edi, dword ptr [rbp-0x1CC]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryEvaluateScalarComparison(int,System.Object,System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,byref):bool]
       test     eax, eax
       jne      SHORT G_M000_IG68
       mov      rdi, 0x7E77FB371F9C
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG109
 
G_M000_IG68:                ;; offset=0x1290
       mov      rdi, 0x7E77FB371FA0
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG69:                ;; offset=0x129F
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      dword ptr [rbp-0x4A4], eax
       mov      esi, dword ptr [rbp-0x4A4]
       mov      rdi, bword ptr [rbp-0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Trim(int):this]
       mov      rax, bword ptr [rbp-0x30]
       mov      rax, gword ptr [rax+0x18]
       mov      gword ptr [rbp-0x1C8], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x4B0], rax
       mov      rsi, gword ptr [rbp-0x4B0]
       mov      rdi, gword ptr [rbp-0x1C8]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CheckExecution(Lokad.Lython.LythonSourceSpan):this]
       movzx    rax, byte  ptr [rbp-0xD8]
       test     eax, eax
       jne      SHORT G_M000_IG70
       mov      rdi, 0x7E77FB371FA4
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_TargetIndex():int:this]
       mov      rcx, bword ptr [rbp-0x30]
       mov      dword ptr [rcx+0x40], eax
       jmp      G_M000_IG116
 
G_M000_IG70:                ;; offset=0x1325
       mov      rdi, 0x7E77FB371FA8
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG115
 
G_M000_IG71:                ;; offset=0x1339
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x4B4], eax
       mov      esi, dword ptr [rbp-0x4B4]
       mov      rdi, bword ptr [rbp-0x30]
       xor      edx, edx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Read(int,int):System.Object:this]
       mov      gword ptr [rbp-0xF0], rax
       mov      rdi, gword ptr [rbp-0xF0]
       call     [Lokad.Lython.Runtime.LythonRuntime:CanUseNativeTruth(System.Object):bool]
       test     eax, eax
       jne      SHORT G_M000_IG72
       mov      rdi, 0x7E77FB371FAC
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG109
 
G_M000_IG72:                ;; offset=0x1387
       mov      rdi, bword ptr [rbp-0x30]
       mov      rsi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Take(byref):System.Object:this]
       mov      rax, bword ptr [rbp-0x30]
       mov      rax, gword ptr [rax+0x18]
       mov      gword ptr [rbp-0x1E0], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x4C0], rax
       mov      rdx, gword ptr [rbp-0x4C0]
       mov      rsi, gword ptr [rbp-0x1E0]
       mov      rdi, gword ptr [rbp-0xF0]
       call     [Lokad.Lython.Runtime.LythonRuntime:IsTruthy(System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):bool]
       test     eax, eax
       jne      SHORT G_M000_IG73
       mov      rdi, 0x7E77FB371FB0
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_TargetIndex():int:this]
       mov      rcx, bword ptr [rbp-0x30]
       mov      dword ptr [rcx+0x40], eax
       jmp      G_M000_IG116
 
G_M000_IG73:                ;; offset=0x13F9
       mov      rdi, 0x7E77FB371FB4
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG115
 
G_M000_IG74:                ;; offset=0x140D
       mov      rdi, 0x7E77FB371FB8
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_TargetIndex():int:this]
       mov      rcx, bword ptr [rbp-0x30]
       mov      dword ptr [rcx+0x40], eax
       jmp      G_M000_IG116
 
G_M000_IG75:                ;; offset=0x1432
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_DiscardIterator():bool:this]
       test     eax, eax
       je       SHORT G_M000_IG76
       mov      rdi, 0x7E77FB371FBC
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp-0x30]
       mov      eax, dword ptr [rax+0x44]
       lea      esi, [rax-0x01]
       mov      rdi, bword ptr [rbp-0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Trim(int):this]
 
G_M000_IG76:                ;; offset=0x1463
       mov      rdi, 0x7E77FB371FC0
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_TargetIndex():int:this]
       mov      rcx, bword ptr [rbp-0x30]
       mov      dword ptr [rcx+0x40], eax
       jmp      G_M000_IG116
 
G_M000_IG77:                ;; offset=0x1488
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x4C4], eax
       mov      esi, dword ptr [rbp-0x4C4]
       mov      rdi, bword ptr [rbp-0x30]
       xor      edx, edx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Read(int,int):System.Object:this]
       mov      gword ptr [rbp-0xF8], rax
       mov      rsi, gword ptr [rbp-0xF8]
       mov      rdi, 0x7E77FB35AA90
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       je       SHORT G_M000_IG78
       mov      rdi, 0x7E77FB371FC4
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, bword ptr [rbp-0x30]
       mov      rsi, bword ptr [rbp-0x40]
       mov      rdx, gword ptr [rbp-0xF8]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,System.Object):this]
       jmp      G_M000_IG115
 
G_M000_IG78:                ;; offset=0x14F6
       mov      rsi, gword ptr [rbp-0xF8]
       mov      rdi, 0x7E77FB2F27A0
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       jne      G_M000_IG80
       mov      rsi, gword ptr [rbp-0xF8]
       mov      rdi, 0x7E77FB1D6C50
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       jne      G_M000_IG85
       mov      rsi, gword ptr [rbp-0xF8]
       mov      rdi, 0x7E77FB32E668
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       jne      G_M000_IG84
       mov      rsi, gword ptr [rbp-0xF8]
       mov      rdi, 0x7E77FB166110
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       jne      G_M000_IG83
       mov      rsi, gword ptr [rbp-0xF8]
       mov      rdi, 0x7E77FB144048
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       jne      SHORT G_M000_IG82
       mov      rsi, gword ptr [rbp-0xF8]
       mov      rdi, 0x7E77FB2DD8E0
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       jne      SHORT G_M000_IG81
       mov      rsi, gword ptr [rbp-0xF8]
       mov      rdi, 0x7E77FB330640
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       je       SHORT G_M000_IG86
 
G_M000_IG79:                ;; offset=0x15CA
       mov      rdi, 0x7E77FB371FC8
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG80:                ;; offset=0x15D9
       mov      dword ptr [rbp-0xFC], 1
       jmp      SHORT G_M000_IG87
 
G_M000_IG81:                ;; offset=0x15E5
       mov      rdi, 0x7E77FB371FCC
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG80
 
G_M000_IG82:                ;; offset=0x15F6
       mov      rdi, 0x7E77FB371FD0
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG80
 
G_M000_IG83:                ;; offset=0x1607
       mov      rdi, 0x7E77FB371FD4
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG80
 
G_M000_IG84:                ;; offset=0x1618
       mov      rdi, 0x7E77FB371FD8
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG80
 
G_M000_IG85:                ;; offset=0x1629
       mov      rdi, 0x7E77FB371FDC
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG80
 
G_M000_IG86:                ;; offset=0x163A
       mov      rdi, 0x7E77FB371FE0
       call     CORINFO_HELP_COUNTPROFILE32
       xor      eax, eax
       mov      dword ptr [rbp-0xFC], eax
 
G_M000_IG87:                ;; offset=0x1651
       cmp      dword ptr [rbp-0xFC], 0
       je       SHORT G_M000_IG88
       mov      rdi, 0x7E77FB371FE4
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x4D0], rax
       mov      rsi, gword ptr [rbp-0x4D0]
       mov      rax, bword ptr [rbp-0x30]
       mov      rdx, gword ptr [rax+0x18]
       mov      rdi, gword ptr [rbp-0xF8]
       call     [Lokad.Lython.Runtime.PyIteration+Cursor:Create(System.Object,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):Lokad.Lython.Runtime.PyIteration+Cursor]
       mov      gword ptr [rbp-0x4D8], rax
       mov      rdx, gword ptr [rbp-0x4D8]
       mov      rsi, bword ptr [rbp-0x40]
       mov      rdi, bword ptr [rbp-0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,System.Object):this]
       jmp      G_M000_IG115
 
G_M000_IG88:                ;; offset=0x16B7
       mov      rdi, 0x7E77FB371FE8
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG109
 
G_M000_IG89:                ;; offset=0x16CB
       mov      rax, bword ptr [rbp-0x30]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp-0x30]
       add      rax, 80
       mov      bword ptr [rbp-0x278], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x27C], eax
       mov      rax, bword ptr [rbp-0x278]
       mov      eax, dword ptr [rax+0x08]
       cmp      dword ptr [rbp-0x27C], eax
       jae      G_M000_IG121
       mov      rax, bword ptr [rbp-0x278]
       mov      ecx, dword ptr [rbp-0x27C]
       shl      rcx, 4
       add      rcx, bword ptr [rax]
       mov      rdi, rcx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Object():System.Object:this]
       mov      gword ptr [rbp-0x4E0], rax
       mov      rsi, gword ptr [rbp-0x4E0]
       mov      rdi, 0x7E77FB306FA8
       call     [Lokad.Lython.Internal.NullabilityExtensions:RequireNotNull[System.__Canon](System.__Canon):System.__Canon]
       mov      gword ptr [rbp-0x108], rax
       mov      rsi, gword ptr [rbp-0x108]
       mov      rdi, 0x7E77FB2DF9D0
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      gword ptr [rbp-0x110], rax
       cmp      gword ptr [rbp-0x110], 0
       je       G_M000_IG92
       lea      rsi, [rbp-0x118]
       lea      rdx, [rbp-0x120]
       mov      rdi, gword ptr [rbp-0x110]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.PyIteration+Cursor:TryMoveNextInteger(byref,byref):bool:this]
       test     eax, eax
       je       SHORT G_M000_IG90
       movzx    rax, byte  ptr [rbp-0x118]
       test     eax, eax
       jne      SHORT G_M000_IG91
       mov      rdi, 0x7E77FB371FEC
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x4E4], eax
       mov      esi, dword ptr [rbp-0x4E4]
       mov      rdi, bword ptr [rbp-0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Trim(int):this]
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_TargetIndex():int:this]
       mov      rcx, bword ptr [rbp-0x30]
       mov      dword ptr [rcx+0x40], eax
       jmp      G_M000_IG116
 
G_M000_IG90:                ;; offset=0x17E5
       mov      rdi, 0x7E77FB371FF0
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG92
 
G_M000_IG91:                ;; offset=0x17F6
       mov      rdi, 0x7E77FB371FF4
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, bword ptr [rbp-0x30]
       mov      rsi, bword ptr [rbp-0x40]
       mov      rdx, qword ptr [rbp-0x120]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:PublishInteger(byref,long):this]
       jmp      G_M000_IG115
 
G_M000_IG92:                ;; offset=0x181F
       mov      rsi, gword ptr [rbp-0x108]
       mov      rdi, 0x7E77FB35AA90
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      gword ptr [rbp-0x138], rax
       cmp      gword ptr [rbp-0x138], 0
       jne      G_M000_IG98
       mov      rsi, gword ptr [rbp-0x108]
       mov      rdi, 0x7E77FB2DF9D0
       call     [CORINFO_HELP_CHKCASTCLASS]
       mov      gword ptr [rbp-0x4F0], rax
       mov      rdi, gword ptr [rbp-0x4F0]
       lea      rsi, [rbp-0x140]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.PyIteration+Cursor:TryMoveNext(byref):bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG95
       call     [Lokad.Lython.Runtime.PyIterationResult:get_End():Lokad.Lython.Runtime.PyIterationResult]
       mov      gword ptr [rbp-0x2C0], rax
       mov      qword ptr [rbp-0x2B8], rdx
 
G_M000_IG93:                ;; offset=0x1897
       vmovdqu32 xmm0, xmmword ptr [rbp-0x2C0]
       vmovdqu32 xmmword ptr [rbp-0x2A0], xmm0
 
G_M000_IG94:                ;; offset=0x18A5
       jmp      SHORT G_M000_IG100
 
G_M000_IG95:                ;; offset=0x18A7
       mov      rdi, 0x7E77FB371FF8
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, gword ptr [rbp-0x140]
       call     [Lokad.Lython.Runtime.PyIterationResult:Yield(System.Object):Lokad.Lython.Runtime.PyIterationResult]
       mov      gword ptr [rbp-0x2B0], rax
       mov      qword ptr [rbp-0x2A8], rdx
 
G_M000_IG96:                ;; offset=0x18D1
       vmovdqu32 xmm0, xmmword ptr [rbp-0x2B0]
       vmovdqu32 xmmword ptr [rbp-0x2A0], xmm0
 
G_M000_IG97:                ;; offset=0x18DF
       jmp      SHORT G_M000_IG100
 
G_M000_IG98:                ;; offset=0x18E1
       mov      rdi, 0x7E77FB371FFC
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, gword ptr [rbp-0x138]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.Text.PyStringOps+CasedWhitespaceIteration:MoveNext():Lokad.Lython.Runtime.PyIterationResult:this]
       mov      gword ptr [rbp-0x290], rax
       mov      qword ptr [rbp-0x288], rdx
 
G_M000_IG99:                ;; offset=0x190D
       vmovdqu32 xmm0, xmmword ptr [rbp-0x290]
       vmovdqu32 xmmword ptr [rbp-0x2A0], xmm0
 
G_M000_IG100:                ;; offset=0x191B
       vmovdqu32 xmm0, xmmword ptr [rbp-0x2A0]
       vmovdqu32 xmmword ptr [rbp-0x130], xmm0
 
G_M000_IG101:                ;; offset=0x1929
       lea      rdi, [rbp-0x130]
       call     [Lokad.Lython.Runtime.PyIterationResult:get_HasValue():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG102
       mov      rdi, 0x7E77FB372000
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x4F4], eax
       mov      esi, dword ptr [rbp-0x4F4]
       mov      rdi, bword ptr [rbp-0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Trim(int):this]
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_TargetIndex():int:this]
       mov      rcx, bword ptr [rbp-0x30]
       mov      dword ptr [rcx+0x40], eax
       jmp      G_M000_IG116
 
G_M000_IG102:                ;; offset=0x197F
       mov      rdi, 0x7E77FB372004
       call     CORINFO_HELP_COUNTPROFILE32
       lea      rdi, [rbp-0x130]
       call     [Lokad.Lython.Runtime.PyIterationResult:get_Value():System.Object:this]
       mov      gword ptr [rbp-0x500], rax
       mov      rdx, gword ptr [rbp-0x500]
       mov      rsi, bword ptr [rbp-0x40]
       mov      rdi, bword ptr [rbp-0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,System.Object):this]
       jmp      G_M000_IG115
 
G_M000_IG103:                ;; offset=0x19BC
       mov      rdi, bword ptr [rbp-0x30]
       mov      rsi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:TryReturnUnpackedTuple(byref):bool:this]
       test     eax, eax
       je       SHORT G_M000_IG104
       mov      rdi, 0x7E77FB372008
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG119
 
G_M000_IG104:                ;; offset=0x19E2
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ItemCount():int:this]
       test     eax, eax
       je       G_M000_IG105
       mov      rax, bword ptr [rbp-0x30]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp-0x30]
       add      rax, 80
       mov      bword ptr [rbp-0x2D0], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x2D4], eax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ItemCount():int:this]
       mov      dword ptr [rbp-0x504], eax
       mov      edx, dword ptr [rbp-0x504]
       mov      esi, dword ptr [rbp-0x2D4]
       mov      rdi, bword ptr [rbp-0x2D0]
       call     [System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:Slice(int,int):System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:this]
       mov      bword ptr [rbp-0x2E8], rax
       mov      qword ptr [rbp-0x2E0], rdx
       mov      rax, bword ptr [rbp-0x30]
       mov      rax, gword ptr [rax+0x18]
       mov      gword ptr [rbp-0x2F0], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x510], rax
       mov      rcx, gword ptr [rbp-0x510]
       mov      rdi, bword ptr [rbp-0x2E8]
       mov      rsi, qword ptr [rbp-0x2E0]
       mov      rdx, gword ptr [rbp-0x2F0]
       call     [Lokad.Lython.Runtime.LythonRuntime:CreateSlotTuple(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.PyTuple]
       mov      gword ptr [rbp-0x2C8], rax
       jmp      SHORT G_M000_IG106
 
G_M000_IG105:                ;; offset=0x1A9B
       mov      rdi, 0x7E77FB37200C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, 0x7E7015801778
       mov      rax, gword ptr [rax]
       mov      gword ptr [rbp-0x2C8], rax
 
G_M000_IG106:                ;; offset=0x1ABE
       mov      rdi, 0x7E77FB372010
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, gword ptr [rbp-0x2C8]
       mov      gword ptr [rbp-0x148], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x514], eax
       mov      esi, dword ptr [rbp-0x514]
       mov      rdi, bword ptr [rbp-0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Trim(int):this]
       mov      rdi, bword ptr [rbp-0x30]
       mov      rsi, bword ptr [rbp-0x40]
       mov      rdx, gword ptr [rbp-0x148]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,System.Object):this]
       jmp      G_M000_IG115
 
G_M000_IG107:                ;; offset=0x1B15
       mov      rdi, 0x7E77FB372014
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp-0x30]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp-0x30]
       add      rax, 80
       mov      bword ptr [rbp-0x2F8], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x2FC], eax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ItemCount():int:this]
       mov      dword ptr [rbp-0x518], eax
       mov      edx, dword ptr [rbp-0x518]
       mov      esi, dword ptr [rbp-0x2FC]
       mov      rdi, bword ptr [rbp-0x2F8]
       call     [System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:Slice(int,int):System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:this]
       mov      bword ptr [rbp-0x310], rax
       mov      qword ptr [rbp-0x308], rdx
       mov      rax, bword ptr [rbp-0x30]
       mov      rax, gword ptr [rax+0x18]
       mov      gword ptr [rbp-0x318], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x520], rax
       mov      rcx, gword ptr [rbp-0x520]
       mov      rdi, bword ptr [rbp-0x310]
       mov      rsi, qword ptr [rbp-0x308]
       mov      rdx, gword ptr [rbp-0x318]
       call     [Lokad.Lython.Runtime.LythonRuntime:CreateSlotList(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.PyList]
       mov      gword ptr [rbp-0x150], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x524], eax
       mov      esi, dword ptr [rbp-0x524]
       mov      rdi, bword ptr [rbp-0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Trim(int):this]
       mov      rdi, bword ptr [rbp-0x30]
       mov      rsi, bword ptr [rbp-0x40]
       mov      rdx, gword ptr [rbp-0x150]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,System.Object):this]
       jmp      G_M000_IG115
 
G_M000_IG108:                ;; offset=0x1C03
       mov      rdi, bword ptr [rbp-0x30]
       mov      rsi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Format(byref):bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG111
       mov      rdi, 0x7E77FB372018
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG109:                ;; offset=0x1C24
       xor      eax, eax
 
G_M000_IG110:                ;; offset=0x1C26
       add      rsp, 0x560
       pop      rbp
       ret      
 
G_M000_IG111:                ;; offset=0x1C2F
       mov      rdi, 0x7E77FB37201C
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG115
 
G_M000_IG112:                ;; offset=0x1C43
       mov      rdi, 0x7E77FB372020
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       inc      eax
       mov      dword ptr [rbp-0x31C], eax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      dword ptr [rbp-0x320], eax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x528], eax
       mov      esi, dword ptr [rbp-0x528]
       mov      rdi, bword ptr [rbp-0x30]
       xor      edx, edx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Read(int,int):System.Object:this]
       mov      gword ptr [rbp-0x530], rax
       mov      rcx, gword ptr [rbp-0x530]
       mov      esi, dword ptr [rbp-0x31C]
       mov      edx, dword ptr [rbp-0x320]
       mov      rdi, bword ptr [rbp-0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Put(int,int,System.Object):this]
       jmp      G_M000_IG115
 
G_M000_IG113:                ;; offset=0x1CBF
       mov      rdi, 0x7E77FB372024
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x534], eax
       mov      esi, dword ptr [rbp-0x534]
       mov      rdi, bword ptr [rbp-0x30]
       xor      edx, edx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Read(int,int):System.Object:this]
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      dword ptr [rbp-0x538], eax
       mov      esi, dword ptr [rbp-0x538]
       mov      rdi, bword ptr [rbp-0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Trim(int):this]
       jmp      G_M000_IG115
 
G_M000_IG114:                ;; offset=0x1D15
       lea      rdi, [rbp-0x178]
       mov      esi, 26
       mov      edx, 1
       call     [System.Runtime.CompilerServices.DefaultInterpolatedStringHandler:.ctor(int,int):this]
       lea      rdi, [rbp-0x178]
       mov      rsi, 0x7E77F1217F18
       call     [System.Runtime.CompilerServices.DefaultInterpolatedStringHandler:AppendLiteral(System.String):this]
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_OpCode():int:this]
       mov      dword ptr [rbp-0x53C], eax
       mov      esi, dword ptr [rbp-0x53C]
       lea      rdi, [rbp-0x178]
       call     [System.Runtime.CompilerServices.DefaultInterpolatedStringHandler:AppendFormatted[int](int):this]
       mov      rdi, 0x7E77FA377A68
       call     CORINFO_HELP_NEWSFAST
       mov      gword ptr [rbp-0x340], rax
       lea      rdi, [rbp-0x178]
       call     [System.Runtime.CompilerServices.DefaultInterpolatedStringHandler:ToStringAndClear():System.String:this]
       mov      gword ptr [rbp-0x548], rax
       mov      rsi, gword ptr [rbp-0x548]
       mov      rdi, gword ptr [rbp-0x340]
       call     [System.InvalidOperationException:.ctor(System.String):this]
       mov      rdi, gword ptr [rbp-0x340]
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG115:                ;; offset=0x1DB1
       mov      rdi, 0x7E77FB372028
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp-0x30]
       inc      dword ptr [rax+0x40]
 
G_M000_IG116:                ;; offset=0x1DC7
       mov      eax, dword ptr [rbp-0x394]
       dec      eax
       mov      dword ptr [rbp-0x394], eax
       cmp      dword ptr [rbp-0x394], 0
       jg       SHORT G_M000_IG118
 
G_M000_IG117:                ;; offset=0x1DDE
       lea      rdi, [rbp-0x394]
       mov      esi, 0x92C
       call     CORINFO_HELP_PATCHPOINT
       jmp      rax
 
G_M000_IG118:                ;; offset=0x1DF1
       mov      rax, bword ptr [rbp-0x30]
       mov      eax, dword ptr [rax+0x40]
       mov      dword ptr [rbp-0x18C], eax
       mov      rax, bword ptr [rbp-0x30]
       mov      rdi, gword ptr [rax+0x08]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Instructions():Lokad.Lython.Frontend.ExecutableInstruction[]:this]
       mov      eax, dword ptr [rax+0x08]
       cmp      eax, dword ptr [rbp-0x18C]
       jg       G_M000_IG03
       mov      rdi, 0x7E77FB37202C
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG119:                ;; offset=0x1E2C
       mov      eax, 1
 
G_M000_IG120:                ;; offset=0x1E31
       add      rsp, 0x560
       pop      rbp
       ret      
 
G_M000_IG121:                ;; offset=0x1E3A
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
RWD00  	dd	000002B3h ; case G_M000_IG11
       	dd	00000350h ; case G_M000_IG12
       	dd	0000048Fh ; case G_M000_IG14
       	dd	000003B8h ; case G_M000_IG13
RWD16  	dd	00000687h ; case G_M000_IG24
       	dd	00001CCBh ; case G_M000_IG114
       	dd	000005F4h ; case G_M000_IG23
       	dd	00000563h ; case G_M000_IG19
       	dd	00001CCBh ; case G_M000_IG114
       	dd	00001CCBh ; case G_M000_IG114
       	dd	00001BF9h ; case G_M000_IG112
       	dd	00001C75h ; case G_M000_IG113
       	dd	00001ACBh ; case G_M000_IG107
       	dd	00001972h ; case G_M000_IG103
       	dd	00001CCBh ; case G_M000_IG114
       	dd	00001CCBh ; case G_M000_IG114
       	dd	00001CCBh ; case G_M000_IG114
       	dd	00001CCBh ; case G_M000_IG114
       	dd	00001CCBh ; case G_M000_IG114
       	dd	00001CCBh ; case G_M000_IG114
       	dd	0000143Eh ; case G_M000_IG77
       	dd	00001681h ; case G_M000_IG89
       	dd	00000855h ; case G_M000_IG29
       	dd	0000088Fh ; case G_M000_IG31
       	dd	00001CCBh ; case G_M000_IG114
       	dd	00001CCBh ; case G_M000_IG114
       	dd	00000CC1h ; case G_M000_IG46
       	dd	00000CC1h ; case G_M000_IG46
       	dd	00000B36h ; case G_M000_IG40
       	dd	000013C3h ; case G_M000_IG74
       	dd	000012EFh ; case G_M000_IG71
       	dd	0000115Dh ; case G_M000_IG67
       	dd	00001CCBh ; case G_M000_IG114
       	dd	00001CCBh ; case G_M000_IG114
       	dd	00001CCBh ; case G_M000_IG114
       	dd	00001CCBh ; case G_M000_IG114
       	dd	00001CCBh ; case G_M000_IG114
       	dd	0000018Ah ; case G_M000_IG09
       	dd	00000150h ; case G_M000_IG08
       	dd	00000150h ; case G_M000_IG08
       	dd	00001CCBh ; case G_M000_IG114
       	dd	00001CCBh ; case G_M000_IG114
       	dd	000013E8h ; case G_M000_IG75
       	dd	00001BB9h ; case G_M000_IG108
       	dd	00001BB9h ; case G_M000_IG108
       	dd	00001BB9h ; case G_M000_IG108
       	dd	00001BB9h ; case G_M000_IG108
       	dd	00001BB9h ; case G_M000_IG108

; Total bytes of code 7744

; Assembly listing for method Lokad.Lython.LythonCompiledScript:RunCore(Lokad.Lython.ILythonHost,Lokad.Lython.LythonRunOptions):Lokad.Lython.LythonExecutionResult:this (Instrumented Tier0)
; Emitting BLENDED_CODE for x64 + VEX + EVEX on Unix
; Instrumented Tier0 code
; rbp based frame
; fully interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 272
       lea      rbp, [rsp+0x110]
       xor      eax, eax
       mov      qword ptr [rbp-0x108], rax
       vxorps   xmm8, xmm8, xmm8
       vmovdqu32 zmmword ptr [rbp-0x100], zmm8
       vmovdqu32 zmmword ptr [rbp-0xC0], zmm8
       vmovdqu32 zmmword ptr [rbp-0x80], zmm8
       vmovdqu  ymmword ptr [rbp-0x40], ymm8
       mov      qword ptr [rbp-0x20], rax
       mov      gword ptr [rbp-0x08], rdi
       mov      gword ptr [rbp-0x10], rsi
       mov      gword ptr [rbp-0x18], rdx
 
G_M000_IG02:                ;; offset=0x0048
       mov      rax, gword ptr [rbp-0x08]
       mov      rax, gword ptr [rax+0x08]
       mov      gword ptr [rbp-0x58], rax
       mov      rax, gword ptr [rbp-0x58]
       mov      gword ptr [rbp-0x60], rax
       cmp      gword ptr [rbp-0x58], 0
       jne      SHORT G_M000_IG04
 
G_M000_IG03:                ;; offset=0x0063
       mov      rdi, 0x7E77FA856F18
       call     CORINFO_HELP_NEWSFAST
       mov      gword ptr [rbp-0xA8], rax
       mov      rdi, gword ptr [rbp-0xA8]
       mov      rsi, 0x7E77F1215638
       call     [System.ObjectDisposedException:.ctor(System.String):this]
       mov      rdi, gword ptr [rbp-0xA8]
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG04:                ;; offset=0x009D
       mov      rax, gword ptr [rbp-0x60]
       mov      gword ptr [rbp-0x20], rax
       cmp      gword ptr [rbp-0x18], 0
       jne      SHORT G_M000_IG05
       mov      rdi, 0x7E77FB6B2420
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, 0x7E77FA9B6E20
       call     CORINFO_HELP_NEWSFAST
       mov      gword ptr [rbp-0xA0], rax
       mov      rdi, gword ptr [rbp-0xA0]
       call     [Lokad.Lython.LythonRunOptions:.ctor():this]
       mov      rax, gword ptr [rbp-0xA0]
       mov      gword ptr [rbp-0x18], rax
 
G_M000_IG05:                ;; offset=0x00E9
       mov      rdi, gword ptr [rbp-0x18]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.LythonRunOptions:get_MemoryBudget():Lokad.Lython.ILythonMemoryBudget:this]
       mov      gword ptr [rbp-0x68], rax
       mov      rax, gword ptr [rbp-0x68]
       mov      gword ptr [rbp-0x70], rax
       cmp      gword ptr [rbp-0x68], 0
       jne      SHORT G_M000_IG06
       mov      rax, gword ptr [rbp-0x08]
       mov      rax, gword ptr [rax+0x20]
       mov      gword ptr [rbp-0x90], rax
       mov      rax, gword ptr [rbp-0x90]
       mov      gword ptr [rbp-0x70], rax
       cmp      gword ptr [rbp-0x90], 0
       jne      G_M000_IG10
       mov      rdi, 0x7E77FB6B2424
       call     CORINFO_HELP_COUNTPROFILE32
       vxorps   xmm0, xmm0, xmm0
       vmovups  xmmword ptr [rbp-0x48], xmm0
       mov      rdi, 0x7E77FA8F6988
       call     CORINFO_HELP_NEWSFAST
       mov      gword ptr [rbp-0x98], rax
       mov      rsi, qword ptr [rbp-0x48]
       mov      rdx, qword ptr [rbp-0x40]
       mov      rdi, gword ptr [rbp-0x98]
       call     [Lokad.Lython.LythonMemoryBudget:.ctor(System.Nullable`1[long]):this]
       mov      rax, gword ptr [rbp-0x98]
       mov      gword ptr [rbp-0x70], rax
 
G_M000_IG06:                ;; offset=0x017E
       mov      rax, gword ptr [rbp-0x70]
       mov      gword ptr [rbp-0x28], rax
       mov      rax, gword ptr [rbp-0x28]
       mov      gword ptr [rbp-0xB0], rax
       mov      rdi, gword ptr [rbp-0xB0]
       mov      rsi, 0x7E77FB6B2428
       call     CORINFO_HELP_CLASSPROFILE32
       mov      rax, gword ptr [rbp-0xB0]
       mov      gword ptr [rbp-0xD8], rax
       mov      rdi, gword ptr [rbp-0xD8]
       mov      r11, 0x7E77F8A43048
       call     [r11]Lokad.Lython.ILythonMemoryBudget:CreateScope():Lokad.Lython.ILythonMemoryScope:this
       mov      gword ptr [rbp-0x30], rax
 
G_M000_IG07:                ;; offset=0x01CD
       mov      rdi, gword ptr [rbp-0x18]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.LythonRunOptions:get_ResultMemoryBudget():Lokad.Lython.ILythonMemoryBudget:this]
       mov      gword ptr [rbp-0x78], rax
       mov      rax, gword ptr [rbp-0x78]
       mov      gword ptr [rbp-0x80], rax
       cmp      gword ptr [rbp-0x78], 0
       jne      SHORT G_M000_IG08
       mov      rdi, 0x7E77FB6B2530
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, gword ptr [rbp-0x28]
       mov      gword ptr [rbp-0x80], rax
 
G_M000_IG08:                ;; offset=0x0203
       mov      rax, gword ptr [rbp-0x80]
       mov      gword ptr [rbp-0xB8], rax
       mov      rdi, gword ptr [rbp-0xB8]
       mov      rsi, 0x7E77FB6B2538
       call     CORINFO_HELP_CLASSPROFILE32
       mov      rax, gword ptr [rbp-0xB8]
       mov      gword ptr [rbp-0xE0], rax
       mov      rdi, gword ptr [rbp-0xE0]
       mov      r11, 0x7E77F8A43050
       call     [r11]Lokad.Lython.ILythonMemoryBudget:CreateScope():Lokad.Lython.ILythonMemoryScope:this
       mov      gword ptr [rbp-0x38], rax
 
G_M000_IG09:                ;; offset=0x024A
       mov      rax, gword ptr [rbp-0x20]
       mov      gword ptr [rbp-0xC0], rax
       mov      rdi, gword ptr [rbp-0xC0]
       mov      rsi, 0x7E77FB6B2640
       call     CORINFO_HELP_DELEGATEPROFILE32
       mov      rax, gword ptr [rbp-0xC0]
       mov      gword ptr [rbp-0xE8], rax
       mov      rdi, gword ptr [rbp-0x18]
       mov      rsi, gword ptr [rbp-0x30]
       mov      rdx, gword ptr [rbp-0x38]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.LythonRunOptions:WithMemoryOwners(Lokad.Lython.ILythonMemoryBudget,Lokad.Lython.ILythonMemoryBudget):Lokad.Lython.LythonRunOptions:this]
       mov      gword ptr [rbp-0xF0], rax
       mov      rax, gword ptr [rbp-0xE8]
       mov      rdx, gword ptr [rbp-0xF0]
       mov      rsi, gword ptr [rbp-0x10]
       mov      rdi, gword ptr [rax+0x10]
       mov      rax, gword ptr [rbp-0xE8]
       call     [rax+0x18]System.Func`3[System.__Canon,System.__Canon,System.__Canon]:Invoke(System.__Canon,System.__Canon):System.__Canon:this
       mov      gword ptr [rbp-0xF8], rax
       mov      rdi, gword ptr [rbp-0xF8]
       mov      rsi, gword ptr [rbp-0x38]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.LythonExecutionResult:OwnMemoryScope(Lokad.Lython.ILythonMemoryScope):Lokad.Lython.LythonExecutionResult:this]
       mov      gword ptr [rbp-0x50], rax
       jmp      SHORT G_M000_IG11
 
G_M000_IG10:                ;; offset=0x02D4
       mov      rdi, 0x7E77FB6B2850
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG06
 
G_M000_IG11:                ;; offset=0x02E8
       call     G_M000_IG16
       nop      
 
G_M000_IG12:                ;; offset=0x02EE
       mov      rdi, 0x7E77FB6B2964
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, gword ptr [rbp-0x50]
 
G_M000_IG13:                ;; offset=0x0301
       add      rsp, 272
       pop      rbp
       ret      
 
G_M000_IG14:                ;; offset=0x030A
       push     rax
 
G_M000_IG15:                ;; offset=0x030B
       mov      gword ptr [rbp-0x88], rdi
       mov      rax, gword ptr [rbp-0x38]
       mov      gword ptr [rbp-0xC8], rax
       mov      rdi, gword ptr [rbp-0xC8]
       mov      rsi, 0x7E77FB6B2748
       call     CORINFO_HELP_CLASSPROFILE32
       mov      rax, gword ptr [rbp-0xC8]
       mov      gword ptr [rbp-0x100], rax
       mov      rdi, gword ptr [rbp-0x100]
       mov      r11, 0x7E77F8A43058
       call     [r11]System.IDisposable:Dispose():this
       call     CORINFO_HELP_RETHROW
       int3     
 
G_M000_IG16:                ;; offset=0x035B
       push     rax
 
G_M000_IG17:                ;; offset=0x035C
       cmp      gword ptr [rbp-0x30], 0
       je       SHORT G_M000_IG18
       mov      rdi, 0x7E77FB6B2854
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, gword ptr [rbp-0x30]
       mov      gword ptr [rbp-0xD0], rax
       mov      rdi, gword ptr [rbp-0xD0]
       mov      rsi, 0x7E77FB6B2858
       call     CORINFO_HELP_CLASSPROFILE32
       mov      rax, gword ptr [rbp-0xD0]
       mov      gword ptr [rbp-0x108], rax
       mov      rdi, gword ptr [rbp-0x108]
       mov      r11, 0x7E77F8A43060
       call     [r11]System.IDisposable:Dispose():this
 
G_M000_IG18:                ;; offset=0x03B5
       mov      rdi, 0x7E77FB6B2960
       call     CORINFO_HELP_COUNTPROFILE32
       nop      
 
G_M000_IG19:                ;; offset=0x03C5
       add      rsp, 8
       ret      
 
; Total bytes of code 970

; Assembly listing for method Lokad.Lython.Runtime.LythonRuntime+NativeExecution:RunCore(byref):bool:this (Tier1)
; Emitting BLENDED_CODE for x64 + VEX + EVEX on Unix
; Tier1 code
; optimized code
; optimized using Synthesized PGO
; rbp based frame
; fully interruptible
; with Synthesized PGO: fgCalledCount is 1339648
; 37 inlinees with PGO data; 140 single block inlinees; 7 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       push     r15
       push     r14
       push     r13
       push     r12
       push     rbx
       sub      rsp, 280
       lea      rbp, [rsp+0x140]
       xor      eax, eax
       mov      qword ptr [rbp-0x138], rax
       vxorps   xmm8, xmm8, xmm8
       vmovdqu32 zmmword ptr [rbp-0x130], zmm8
       vmovdqu32 zmmword ptr [rbp-0xF0], zmm8
       vmovdqu32 zmmword ptr [rbp-0xB0], zmm8
       vmovdqu32 zmmword ptr [rbp-0x70], zmm8
       mov      qword ptr [rbp-0x30], rax
       mov      rbx, rdi
       mov      r15, rsi
 
G_M000_IG02:                ;; offset=0x0059
       mov      rdi, 0x7E70158016F0
       mov      rsi, gword ptr [rdi]
       mov      rdi, r15
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       xor      edi, edi
       mov      qword ptr [r15+0x08], rdi
       mov      edi, dword ptr [rbx+0x40]
       mov      rax, gword ptr [rbx+0x08]
       mov      rax, gword ptr [rax+0x50]
       cmp      edi, dword ptr [rax+0x08]
       jge      G_M000_IG56
       jmp      G_M000_IG47
 
G_M000_IG03:                ;; offset=0x008D
       mov      rdi, rbx
       mov      rsi, r14
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Call(byref):bool:this]
       test     eax, eax
       jne      G_M000_IG45
       jmp      G_M000_IG114
 
G_M000_IG04:                ;; offset=0x00A6
       mov      r13d, dword ptr [r14+0x10]
       test     r13d, r13d
       jl       G_M000_IG79
       lea      rdi, bword ptr [rbx+0x50]
       cmp      r13d, dword ptr [rdi+0x08]
       jae      G_M000_IG150
       mov      r12d, r13d
       shl      r12, 4
       add      r12, bword ptr [rdi]
       mov      rdi, gword ptr [r12]
       mov      rsi, 0x7E7015801840
       cmp      rdi, gword ptr [rsi]
       je       G_M000_IG80
 
G_M000_IG05:                ;; offset=0x00E2
       mov      r12, gword ptr [r12]
       test     r12, r12
       je       G_M000_IG81
 
G_M000_IG06:                ;; offset=0x00EF
       mov      rdi, gword ptr [rbx+0x08]
       mov      r13, gword ptr [rdi+0x18]
       mov      rdi, r14
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_NameIndex():int:this]
       mov      rdi, 0x7E77F9D3BEC0
       cmp      qword ptr [r13], rdi
       jne      G_M000_IG82
       cmp      dword ptr [r13+0x08], eax
       jbe      G_M000_IG138
       mov      edi, eax
       mov      rdi, gword ptr [r13+8*rdi+0x10]
 
G_M000_IG07:                ;; offset=0x0125
       test     r12, r12
       je       SHORT G_M000_IG12
 
G_M000_IG08:                ;; offset=0x012A
       mov      rax, 0x7E77FB144048
       cmp      qword ptr [r12], rax
       jne      SHORT G_M000_IG10
 
G_M000_IG09:                ;; offset=0x013A
       call     [Lokad.Lython.Runtime.LythonRuntime+StringMembers:GetMethod(System.String):Lokad.Lython.Runtime.LythonRuntime+ReceiverMethod]
       mov      r13, rax
       jmp      SHORT G_M000_IG13
 
G_M000_IG10:                ;; offset=0x0145
       mov      rax, 0x7E77FB2DD8E0
       cmp      qword ptr [r12], rax
       jne      SHORT G_M000_IG12
 
G_M000_IG11:                ;; offset=0x0155
       call     [Lokad.Lython.Runtime.LythonRuntime+DictMembers:GetMethod(System.String):Lokad.Lython.Runtime.LythonRuntime+ReceiverMethod]
       mov      r13, rax
       jmp      SHORT G_M000_IG13
 
G_M000_IG12:                ;; offset=0x0160
       xor      r13, r13
 
G_M000_IG13:                ;; offset=0x0163
       test     r13, r13
       je       G_M000_IG114
       mov      edi, dword ptr [r14+0x1C]
       cmp      edi, 52
       ja       SHORT G_M000_IG15
 
G_M000_IG14:                ;; offset=0x0175
       mov      rax, 0xFFFFFFFFFE7FF
       bt       rax, rdi
       jae      G_M000_IG83
 
G_M000_IG15:                ;; offset=0x0189
       mov      eax, dword ptr [r14+0x14]
       mov      dword ptr [rbp-0xAC], eax
 
G_M000_IG16:                ;; offset=0x0193
       mov      edi, dword ptr [r14+0x1C]
       cmp      edi, 52
       ja       SHORT G_M000_IG18
 
G_M000_IG17:                ;; offset=0x019C
       mov      rcx, 0xFFFFFFFFFE7FF
       bt       rcx, rdi
       jae      G_M000_IG84
 
G_M000_IG18:                ;; offset=0x01B0
       mov      edi, dword ptr [r14+0x14]
 
G_M000_IG19:                ;; offset=0x01B4
       lea      ecx, [rdi+0x01]
       mov      dword ptr [rbp-0xE4], ecx
       cmp      ecx, dword ptr [rbx+0x44]
       jl       G_M000_IG26
 
G_M000_IG20:                ;; offset=0x01C6
       lea      rdi, bword ptr [rbx+0x50]
       mov      eax, dword ptr [rbp-0xAC]
       cmp      eax, dword ptr [rdi+0x08]
       jae      G_M000_IG150
       shl      rax, 4
       add      rax, bword ptr [rdi]
       mov      bword ptr [rbp-0x130], rax
       mov      rdi, rax
       mov      rsi, r12
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       xor      edi, edi
       mov      r12, bword ptr [rbp-0x130]
       mov      qword ptr [r12+0x08], rdi
       mov      r12d, dword ptr [rbp-0xE4]
       mov      dword ptr [rbx+0x44], r12d
       mov      edi, dword ptr [r14+0x1C]
       cmp      edi, 52
       ja       SHORT G_M000_IG22
 
G_M000_IG21:                ;; offset=0x0214
       mov      rax, 0xFFFFFFFFFE7FF
       bt       rax, rdi
       jae      G_M000_IG85
 
G_M000_IG22:                ;; offset=0x0228
       mov      eax, dword ptr [r14+0x14]
 
G_M000_IG23:                ;; offset=0x022C
       lea      r12d, [rax+0x01]
       mov      r14d, dword ptr [r14+0x18]
       test     r14d, r14d
       jl       SHORT G_M000_IG27
 
G_M000_IG24:                ;; offset=0x0239
       cmp      r14d, dword ptr [rbx+0x44]
       jl       SHORT G_M000_IG28
 
G_M000_IG25:                ;; offset=0x023F
       lea      rdi, bword ptr [rbx+0x50]
       cmp      r12d, dword ptr [rdi+0x08]
       jae      G_M000_IG150
       mov      r12d, r12d
       shl      r12, 4
       add      r12, bword ptr [rdi]
       mov      rdi, r12
       mov      rsi, r13
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       xor      edi, edi
       mov      qword ptr [r12+0x08], rdi
       mov      dword ptr [rbx+0x44], r14d
       jmp      G_M000_IG45
 
G_M000_IG26:                ;; offset=0x0272
       mov      rdi, rbx
       mov      esi, ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Trim(int):this]
       jmp      G_M000_IG20
 
G_M000_IG27:                ;; offset=0x0282
       not      r14d
       jmp      SHORT G_M000_IG24
 
G_M000_IG28:                ;; offset=0x0287
       mov      rdi, rbx
       mov      esi, r14d
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Trim(int):this]
       jmp      SHORT G_M000_IG25
 
G_M000_IG29:                ;; offset=0x0295
       mov      edi, r13d
       lea      rax, [reloc @RWD00]
       mov      eax, dword ptr [rax+4*rdi]
       lea      rcx, G_M000_IG02
       add      rax, rcx
       jmp      rax
 
G_M000_IG30:                ;; offset=0x02AE
       mov      r13, gword ptr [rbx+0x08]
       mov      r12, gword ptr [rbx+0x10]
       mov      eax, dword ptr [rbx+0x40]
       mov      dword ptr [rbp-0xB0], eax
       mov      edi, dword ptr [rbx+0x44]
       mov      rcx, gword ptr [rbx+0x18]
       mov      gword ptr [rbp-0x100], rcx
       mov      r11, gword ptr [r13+0x50]
       cmp      eax, dword ptr [r11+0x08]
       jae      G_M000_IG150
       mov      edx, eax
       shl      rdx, 5
       lea      rdx, bword ptr [r11+rdx+0x10]
       mov      bword ptr [rbp-0xF0], rdx
       mov      r11d, dword ptr [rdx+0x1C]
       cmp      r11d, 5
       jne      G_M000_IG62
       cmp      dword ptr [rdx+0x0C], 0x7FFFFFFF
       je       G_M000_IG62
       mov      r11d, dword ptr [rdx+0x14]
       cmp      edi, r11d
       jne      G_M000_IG62
       test     r12, r12
       je       G_M000_IG62
       mov      edi, dword ptr [rdx+0x1C]
       cmp      edi, 5
       jne      G_M000_IG63
 
G_M000_IG31:                ;; offset=0x032A
       mov      esi, dword ptr [rdx+0x08]
       mov      dword ptr [rbp-0xB4], esi
       mov      rdi, 0x7E77FB2F7A60
       cmp      qword ptr [r12], rdi
       jne      G_M000_IG64
       mov      r8d, dword ptr [r12+0x08]
 
G_M000_IG32:                ;; offset=0x034C
       mov      esi, dword ptr [rbp-0xB4]
       cmp      esi, r8d
       jae      G_M000_IG62
       mov      rdi, gword ptr [r13+0x50]
       mov      eax, dword ptr [rbp-0xB0]
       lea      esi, [rax+0x01]
       cmp      esi, dword ptr [rdi+0x08]
       jae      G_M000_IG150
       lea      esi, [rax+0x01]
       shl      rsi, 5
       lea      r8, bword ptr [rdi+rsi+0x10]
       mov      bword ptr [rbp-0xF8], r8
       mov      rdx, bword ptr [rbp-0xF0]
       mov      edi, dword ptr [rdx+0x1C]
       cmp      edi, 5
       jne      G_M000_IG65
 
G_M000_IG33:                ;; offset=0x0397
       mov      esi, dword ptr [rdx+0x08]
       mov      rdi, 0x7E77FB2F7A60
       cmp      qword ptr [r12], rdi
       jne      G_M000_IG66
       cmp      dword ptr [r12+0x08], esi
       jbe      G_M000_IG138
       mov      edi, esi
       mov      r12, gword ptr [r12+8*rdi+0x10]
 
G_M000_IG34:                ;; offset=0x03C0
       mov      r8, bword ptr [rbp-0xF8]
       mov      edi, dword ptr [r8+0x08]
       call     [Lokad.Lython.Runtime.LythonRuntime:AugmentedBinaryOperator(int):int]
       mov      dword ptr [rbp-0xB8], eax
       mov      rdi, gword ptr [r13+0x10]
       mov      rcx, bword ptr [rbp-0xF0]
       cmp      dword ptr [rcx+0x1C], 5
       jne      G_M000_IG139
       mov      eax, dword ptr [rbp-0xB8]
       mov      esi, dword ptr [rcx+0x0C]
       mov      r11, 0x7E77F9C627A0
       cmp      qword ptr [rdi], r11
       jne      G_M000_IG67
       cmp      dword ptr [rdi+0x08], esi
       jbe      G_M000_IG138
       mov      rcx, gword ptr [rdi+8*rsi+0x10]
 
G_M000_IG35:                ;; offset=0x0416
       mov      rsi, 0x7E77FB02B158
       cmp      qword ptr [rcx], rsi
       je       SHORT G_M000_IG37
 
G_M000_IG36:                ;; offset=0x0425
       mov      gword ptr [rbp-0x110], rcx
       mov      rsi, rcx
       mov      rdi, 0x7E77FB02B158
       call     CORINFO_HELP_UNBOX
       mov      eax, dword ptr [rbp-0xB8]
       mov      rcx, gword ptr [rbp-0x110]
 
G_M000_IG37:                ;; offset=0x044B
       mov      rdi, gword ptr [rcx+0x08]
       mov      esi, dword ptr [rcx+0x10]
       test     rdi, rdi
       jne      G_M000_IG68
       movsxd   rcx, esi
 
G_M000_IG38:                ;; offset=0x045E
       mov      rdi, bword ptr [rbp-0xF8]
       mov      rdx, gword ptr [rdi]
       mov      gword ptr [rbp-0x108], rdx
       mov      rdi, gword ptr [r13+0x50]
       mov      r13d, dword ptr [rbp-0xB0]
       lea      esi, [r13+0x02]
       cmp      esi, dword ptr [rdi+0x08]
       jae      G_M000_IG150
       add      r13d, 2
       mov      esi, r13d
       shl      rsi, 5
       mov      r13, gword ptr [rdi+rsi+0x10]
       cmp      byte  ptr [r12], r12b
       xor      edi, edi
       mov      qword ptr [rbp-0xC8], rdi
 
G_M000_IG39:                ;; offset=0x04A4
       mov      qword ptr [rbp-0xD0], rdi
       mov      rdi, gword ptr [r12+0x10]
       test     rdi, rdi
       je       G_M000_IG72
       mov      rdx, gword ptr [rbp-0x108]
       cmp      gword ptr [r12+0x18], 0
       je       G_M000_IG72
       cmp      gword ptr [rdi+0x88], 0
       jne      G_M000_IG72
       mov      rsi, rdi
       cmp      byte  ptr [rsi+0xFD], 0
       jne      G_M000_IG72
       movzx    rdi, byte  ptr [rdi+0xFB]
       test     edi, edi
       jne      G_M000_IG72
       cmp      byte  ptr [r12+0x28], 0
       je       G_M000_IG73
 
G_M000_IG40:                ;; offset=0x0506
       mov      rdi, qword ptr [r12+0x20]
       mov      qword ptr [rbp-0xC8], rdi
 
G_M000_IG41:                ;; offset=0x0512
       mov      rsi, gword ptr [rbp-0x100]
       mov      rdi, gword ptr [rsi+0x98]
       mov      r8, gword ptr [rdi+0x88]
       mov      r8, gword ptr [r8+0x20]
       test     r8, r8
       jne      G_M000_IG142
       mov      rdi, gword ptr [rdi+0x178]
       test     rdi, rdi
       jne      G_M000_IG74
       mov      qword ptr [rbp-0xC0], rcx
 
G_M000_IG42:                ;; offset=0x054B
       lea      rcx, [rbp-0xD0]
       mov      edi, eax
       mov      rsi, qword ptr [rbp-0xC8]
       mov      rdx, qword ptr [rbp-0xC0]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryMachineBinary(int,long,long,byref):bool]
       test     eax, eax
       je       G_M000_IG72
       mov      rdi, gword ptr [rbp-0x100]
       mov      rdi, gword ptr [rdi+0x98]
       mov      rax, gword ptr [rdi+0x88]
       mov      rax, gword ptr [rax+0x20]
       test     rax, rax
       jne      G_M000_IG143
       mov      rdi, gword ptr [rdi+0x178]
       test     rdi, rdi
       jne      G_M000_IG75
 
G_M000_IG43:                ;; offset=0x05A2
       mov      rdi, qword ptr [rbp-0xD0]
       mov      qword ptr [r12+0x20], rdi
       mov      byte  ptr [r12+0x28], 1
       xor      rdi, rdi
       mov      gword ptr [r12+0x08], rdi
       mov      edi, 1
 
G_M000_IG44:                ;; offset=0x05C0
       test     edi, edi
       je       G_M000_IG62
       add      dword ptr [rbx+0x40], 2
 
G_M000_IG45:                ;; offset=0x05CC
       inc      dword ptr [rbx+0x40]
 
G_M000_IG46:                ;; offset=0x05CF
       mov      esi, dword ptr [rbx+0x40]
       mov      rdi, gword ptr [rbx+0x08]
       mov      rdi, gword ptr [rdi+0x50]
       cmp      esi, dword ptr [rdi+0x08]
       jge      G_M000_IG56
 
G_M000_IG47:                ;; offset=0x05E3
       mov      rdi, gword ptr [rbx+0x08]
       mov      rdi, gword ptr [rdi+0x50]
       mov      eax, dword ptr [rbx+0x40]
       cmp      eax, dword ptr [rdi+0x08]
       jae      G_M000_IG150
       shl      rax, 5
       lea      r14, bword ptr [rdi+rax+0x10]
       mov      rdi, gword ptr [rbx+0x18]
       mov      rdi, gword ptr [rdi+0x98]
       mov      rax, gword ptr [r14]
       mov      rcx, gword ptr [rdi+0x88]
       mov      rcx, gword ptr [rcx+0x20]
       test     rcx, rcx
       jne      G_M000_IG130
       mov      rdi, gword ptr [rdi+0x178]
       test     rdi, rdi
       jne      G_M000_IG58
 
G_M000_IG48:                ;; offset=0x0632
       mov      edi, dword ptr [r14+0x1C]
       lea      r13d, [rdi-0x03]
       cmp      r13d, 3
       jbe      G_M000_IG29
 
G_M000_IG49:                ;; offset=0x0644
       add      edi, -25
       cmp      edi, 43
       ja       G_M000_IG131
 
G_M000_IG50:                ;; offset=0x0650
       mov      edi, edi
       lea      rsi, [reloc @RWD16]
       mov      esi, dword ptr [rsi+4*rdi]
       lea      rax, G_M000_IG02
       add      rsi, rax
       jmp      rsi
 
G_M000_IG51:                ;; offset=0x0668
       mov      esi, dword ptr [r14+0x10]
       test     esi, esi
       jl       G_M000_IG133
       lea      rdi, bword ptr [rbx+0x50]
       cmp      esi, dword ptr [rdi+0x08]
       jae      G_M000_IG150
       mov      edx, esi
       shl      rdx, 4
       add      rdx, bword ptr [rdi]
       mov      r13, gword ptr [rdx]
       mov      r12, qword ptr [rdx+0x08]
       test     r13, r13
       je       G_M000_IG134
 
G_M000_IG52:                ;; offset=0x069A
       mov      rdi, r15
       mov      rsi, r13
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      qword ptr [r15+0x08], r12
       mov      esi, dword ptr [r14+0x10]
       mov      rdi, gword ptr [rbx+0x08]
       cmp      esi, dword ptr [rdi+0x9C]
       jl       SHORT G_M000_IG54
 
G_M000_IG53:                ;; offset=0x06B9
       lea      rsi, bword ptr [rbx+0x50]
       mov      edi, dword ptr [r14+0x10]
       cmp      edi, dword ptr [rsi+0x08]
       jae      G_M000_IG150
       mov      rsi, bword ptr [rsi]
       shl      rdi, 4
       xor      rax, rax
       mov      gword ptr [rsi+rdi], rax
 
G_M000_IG54:                ;; offset=0x06D7
       mov      rsi, gword ptr [rbx+0x08]
       mov      r14d, dword ptr [rsi+0x9C]
       mov      r15d, dword ptr [rbx+0x44]
       dec      r15d
       mov      esi, dword ptr [rsi+0xA0]
       cmp      r15d, esi
       cmovg    r15d, esi
       cmp      r15d, r14d
       jge      G_M000_IG135
 
G_M000_IG55:                ;; offset=0x06FF
       mov      dword ptr [rbx+0x44], r14d
 
G_M000_IG56:                ;; offset=0x0703
       mov      eax, 1
 
G_M000_IG57:                ;; offset=0x0708
       vzeroupper 
       add      rsp, 280
       pop      rbx
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG58:                ;; offset=0x071D
       cmp      dword ptr [rdi+0x20], 0
       je       G_M000_IG48
       mov      rdi, rax
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionCanceled(Lokad.Lython.LythonSourceSpan)]
       jmp      G_M000_IG48
 
G_M000_IG59:                ;; offset=0x0735
       mov      rdi, gword ptr [rbx+0x08]
       mov      r13, gword ptr [rdi+0x10]
       mov      rdi, r14
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ConstantIndex():int:this]
       mov      esi, eax
       mov      rdi, r13
       mov      r11, 0x7E77F8A432C0
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       mov      rdi, rax
       call     [Lokad.Lython.Runtime.LythonRuntime:RuntimeValue(System.Object):System.Object]
       mov      rdi, rax
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:FromObject(System.Object):Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]
       mov      rcx, rdx
       mov      rdx, rax
       mov      rdi, rbx
       mov      rsi, r14
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot):this]
       jmp      G_M000_IG45
 
G_M000_IG60:                ;; offset=0x0781
       mov      rdi, r14
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LocalSlot():int:this]
       mov      esi, eax
       mov      rdx, gword ptr [r14]
       mov      rdi, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:ReadLocal(int,Lokad.Lython.LythonSourceSpan):System.Object:this]
       mov      rdi, rax
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:FromObject(System.Object):Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]
       mov      rcx, rdx
       mov      rdx, rax
       mov      rdi, rbx
       mov      rsi, r14
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot):this]
       jmp      G_M000_IG45
 
G_M000_IG61:                ;; offset=0x07B8
       mov      rdi, gword ptr [rbx+0x08]
       mov      r13, gword ptr [rdi+0x18]
       mov      rdi, r14
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_NameIndex():int:this]
       mov      esi, eax
       mov      rdi, r13
       mov      r11, 0x7E77F8A432B8
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       mov      rdi, rax
       mov      rsi, gword ptr [r14]
       mov      rdx, gword ptr [rbx+0x18]
       call     [Lokad.Lython.Runtime.LythonRuntime:ResolveExecutableGlobal(System.String,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):System.Object]
       mov      rdi, rax
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:FromObject(System.Object):Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]
       mov      rcx, rdx
       mov      rdx, rax
       mov      rdi, rbx
       mov      rsi, r14
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot):this]
       jmp      G_M000_IG45
 
G_M000_IG62:                ;; offset=0x080B
       mov      rdi, r14
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ClosureSlot():int:this]
       mov      esi, eax
       lea      rdx, [rbp-0x30]
       mov      rdi, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:TryCell(int,byref):bool:this]
       test     eax, eax
       je       G_M000_IG114
       jmp      G_M000_IG76
 
G_M000_IG63:                ;; offset=0x0830
       cmp      edi, 28
       je       G_M000_IG31
       jmp      G_M000_IG137
 
G_M000_IG64:                ;; offset=0x083E
       mov      rdi, r12
       mov      r11, 0x7E77F8A432D0
       call     [r11]System.Collections.Generic.IReadOnlyCollection`1[System.__Canon]:get_Count():int:this
       mov      r8d, eax
       jmp      G_M000_IG32
 
G_M000_IG65:                ;; offset=0x0856
       cmp      edi, 28
       je       G_M000_IG33
       jmp      G_M000_IG137
 
G_M000_IG66:                ;; offset=0x0864
       mov      rdi, r12
       mov      r11, 0x7E77F8A432D8
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       mov      r12, rax
       jmp      G_M000_IG34
 
G_M000_IG67:                ;; offset=0x087C
       mov      r11, 0x7E77F8A432E0
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       mov      rcx, rax
       mov      eax, dword ptr [rbp-0xB8]
       jmp      G_M000_IG35
 
G_M000_IG68:                ;; offset=0x0897
       cmp      dword ptr [rdi+0x08], 1
       jg       G_M000_IG140
       cmp      dword ptr [rdi+0x08], 0
       jbe      G_M000_IG150
       mov      rcx, qword ptr [rdi+0x10]
       test     esi, esi
       jg       SHORT G_M000_IG69
       neg      rcx
 
G_M000_IG69:                ;; offset=0x08B6
       test     rcx, rcx
       jle      SHORT G_M000_IG70
       test     esi, esi
       jg       SHORT G_M000_IG71
 
G_M000_IG70:                ;; offset=0x08BF
       test     rcx, rcx
       jge      G_M000_IG141
       test     esi, esi
       jge      G_M000_IG141
 
G_M000_IG71:                ;; offset=0x08D0
       mov      qword ptr [rbp-0xC0], rcx
       jmp      G_M000_IG38
 
G_M000_IG72:                ;; offset=0x08DC
       xor      edi, edi
       jmp      G_M000_IG44
 
G_M000_IG73:                ;; offset=0x08E3
       mov      qword ptr [rbp-0xC0], rcx
       mov      rdi, gword ptr [r12+0x08]
       lea      rsi, [rbp-0xC8]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryMachineInteger(System.Object,byref):bool]
       test     eax, eax
       mov      eax, dword ptr [rbp-0xB8]
       mov      rcx, qword ptr [rbp-0xC0]
       mov      rdx, gword ptr [rbp-0x108]
       jne      G_M000_IG41
       jmp      SHORT G_M000_IG72
 
G_M000_IG74:                ;; offset=0x091A
       cmp      dword ptr [rdi+0x20], 0
       mov      qword ptr [rbp-0xC0], rcx
       je       G_M000_IG42
       mov      rdi, rdx
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionCanceled(Lokad.Lython.LythonSourceSpan)]
       mov      eax, dword ptr [rbp-0xB8]
       jmp      G_M000_IG42
 
G_M000_IG75:                ;; offset=0x093F
       cmp      dword ptr [rdi+0x20], 0
       je       G_M000_IG43
       mov      rdi, r13
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionCanceled(Lokad.Lython.LythonSourceSpan)]
       jmp      G_M000_IG43
 
G_M000_IG76:                ;; offset=0x0957
       mov      rdi, gword ptr [rbp-0x30]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableCell:get_Value():System.Object:this]
       test     rax, rax
       je       G_M000_IG114
       mov      rdi, rax
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:FromObject(System.Object):Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]
       mov      rcx, rdx
       mov      rdx, rax
       mov      rdi, rbx
       mov      rsi, r14
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot):this]
       jmp      G_M000_IG45
 
G_M000_IG77:                ;; offset=0x098C
       mov      rdi, r14
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ClosureSlot():int:this]
       mov      esi, eax
       lea      rdx, [rbp-0x38]
       mov      rdi, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:TryCell(int,byref):bool:this]
       test     eax, eax
       je       G_M000_IG114
       mov      rdi, gword ptr [rbp-0x38]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableCell:get_CanStoreThroughOwner():bool:this]
       test     eax, eax
       je       G_M000_IG114
       mov      rdi, rbx
       mov      rsi, r14
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Take(byref):System.Object:this]
       mov      rsi, rax
       mov      rdi, gword ptr [rbp-0x38]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableCell:set_Value(System.Object):this]
       jmp      G_M000_IG45
 
G_M000_IG78:                ;; offset=0x09E0
       lea      r13, bword ptr [rbx+0x50]
       mov      rdi, r14
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LocalSlot():int:this]
       cmp      eax, dword ptr [r13+0x08]
       jae      G_M000_IG150
       mov      rdi, bword ptr [r13]
       mov      esi, eax
       shl      rsi, 4
       lea      rdi, bword ptr [rdi+rsi]
       mov      bword ptr [rbp-0x138], rdi
       mov      rdi, rbx
       mov      rsi, r14
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Take(byref):System.Object:this]
       mov      rsi, rax
       mov      rdi, bword ptr [rbp-0x138]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       jmp      G_M000_IG45
 
G_M000_IG79:                ;; offset=0x0A2C
       mov      rdi, gword ptr [rbx+0x08]
       mov      rdi, gword ptr [rdi+0x10]
       mov      esi, r13d
       not      esi
       mov      r11, 0x7E77F8A432F0
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       mov      rdi, rax
       call     [Lokad.Lython.Runtime.LythonRuntime:RuntimeValue(System.Object):System.Object]
       mov      r12, rax
       jmp      G_M000_IG06
 
G_M000_IG80:                ;; offset=0x0A57
       mov      rsi, qword ptr [r12+0x08]
       vxorps   xmm0, xmm0, xmm0
       vmovdqu32 xmmword ptr [rbp-0xE0], xmm0
       lea      rdi, [rbp-0xE0]
       call     [System.Numerics.BigInteger:.ctor(long):this]
       mov      rdi, 0x7E77FB02B158
       call     CORINFO_HELP_NEWSFAST
       mov      gword ptr [rbp-0x118], rax
       lea      rdi, bword ptr [rax+0x08]
       mov      rsi, gword ptr [rbp-0xE0]
       call     CORINFO_HELP_ASSIGN_REF
       mov      edi, dword ptr [rbp-0xD8]
       mov      rax, gword ptr [rbp-0x118]
       mov      dword ptr [rax+0x10], edi
       mov      rdi, r12
       mov      rsi, rax
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       jmp      G_M000_IG05
 
G_M000_IG81:                ;; offset=0x0ABA
       mov      rdi, gword ptr [rbx+0x08]
       cmp      r13d, dword ptr [rdi+0x9C]
       jl       G_M000_IG144
       mov      rdi, 0x7E77FA377A68
       call     CORINFO_HELP_NEWSFAST
       mov      rbx, rax
       mov      rdi, rbx
       mov      rsi, 0x7E77F120D5A0
       call     [System.InvalidOperationException:.ctor(System.String):this]
       mov      rdi, rbx
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG82:                ;; offset=0x0AF9
       mov      rdi, r13
       mov      esi, eax
       mov      r11, 0x7E77F8A432B0
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       mov      rdi, rax
       jmp      G_M000_IG07
 
G_M000_IG83:                ;; offset=0x0B13
       mov      rdi, r14
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      dword ptr [rbp-0xAC], eax
       jmp      G_M000_IG16
 
G_M000_IG84:                ;; offset=0x0B27
       mov      rdi, r14
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      edi, eax
       jmp      G_M000_IG19
 
G_M000_IG85:                ;; offset=0x0B37
       mov      rdi, r14
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       jmp      G_M000_IG23
 
G_M000_IG86:                ;; offset=0x0B45
       mov      esi, dword ptr [r14+0x10]
       mov      rdi, rbx
       xor      edx, edx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Read(int,int):System.Object:this]
       mov      r13, rax
       mov      esi, dword ptr [r14+0x0C]
       mov      rdi, rbx
       mov      edx, 1
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Read(int,int):System.Object:this]
       mov      r12, rax
       mov      rsi, r13
       mov      rdi, 0x7E77FB2DD8E0
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       mov      r13, rax
       test     r13, r13
       je       G_M000_IG114
       mov      rdi, r13
       call     [Lokad.Lython.Runtime.PyDict:get_HasProtocolKeys():bool:this]
       test     eax, eax
       jne      G_M000_IG114
       mov      rsi, r12
       mov      rdi, 0x7E77FB144048
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       mov      r12, rax
       test     r12, r12
       je       G_M000_IG114
       mov      rdi, r14
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LookupCacheIndex():int:this]
       test     eax, eax
       jl       G_M000_IG88
       cmp      gword ptr [r13+0x20], 0
       je       SHORT G_M000_IG88
       mov      rdi, gword ptr [rbx]
       mov      rsi, gword ptr [r14]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.PyExecutableFunction:GetLookupCaches(Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.LythonRuntime+ExecutableLookupCache[]:this]
       mov      gword ptr [rbp-0x128], rax
       mov      rdi, r14
 
G_M000_IG87:                ;; offset=0x0BE9
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LookupCacheIndex():int:this]
       mov      rdx, gword ptr [rbp-0x128]
       cmp      eax, dword ptr [rdx+0x08]
       jae      G_M000_IG150
       mov      r8d, eax
       lea      r8, [r8+2*r8]
       lea      rdx, bword ptr [rdx+8*r8+0x10]
       mov      r8, gword ptr [r14]
       mov      rcx, gword ptr [rbx+0x18]
       lea      r9, [rbp-0x40]
       mov      rsi, r12
       mov      rdi, r13
       call     [Lokad.Lython.Runtime.PyDict:TryReadRecordValue(Lokad.Lython.Runtime.Text.PyString,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,byref):bool:this]
       test     eax, eax
       je       SHORT G_M000_IG88
       mov      rdi, gword ptr [rbp-0x40]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:FromObject(System.Object):Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]
       mov      rcx, rdx
       mov      rdx, rax
       mov      rdi, rbx
       mov      rsi, r14
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot):this]
       jmp      G_M000_IG45
 
G_M000_IG88:                ;; offset=0x0C47
       mov      rdi, r13
       call     [Lokad.Lython.Runtime.PyDict:get_HasProtocolKeys():bool:this]
       test     eax, eax
       jne      G_M000_IG114
       mov      rdx, gword ptr [r14]
       mov      rcx, gword ptr [rbx+0x18]
       mov      rdi, r13
       mov      rsi, r12
       call     [Lokad.Lython.Runtime.LythonRuntime:ReadSubscriptValue(System.Object,System.Object,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):System.Object]
       mov      rdi, rax
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:FromObject(System.Object):Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]
       mov      rcx, rdx
       mov      rdx, rax
       mov      rdi, rbx
       mov      rsi, r14
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot):this]
       jmp      G_M000_IG45
 
G_M000_IG89:                ;; offset=0x0C8B
       mov      esi, dword ptr [r14+0x10]
       mov      rdi, rbx
       xor      edx, edx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Read(int,int):System.Object:this]
       mov      r13, rax
       cmp      dword ptr [r14+0x08], 0
       je       G_M000_IG91
       mov      rsi, r13
       mov      rdi, 0x7E77FB02B158
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       jne      SHORT G_M000_IG90
       mov      rsi, r13
       mov      rdi, 0x7E77F9C96558
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       jne      SHORT G_M000_IG90
       mov      rsi, r13
       mov      rdi, 0x7E77F9C635C8
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       sete     r12b
       movzx    r12, r12b
       jmp      SHORT G_M000_IG92
 
G_M000_IG90:                ;; offset=0x0CF5
       mov      edi, dword ptr [r14+0x08]
       mov      r12, gword ptr [rbx+0x18]
       mov      rax, gword ptr [r14]
       mov      gword ptr [rbp-0x120], rax
       call     [Lokad.Lython.Runtime.LythonRuntime:MapExecutableUnary(int):int]
       mov      edi, eax
       mov      rsi, r13
       mov      rdx, r12
       mov      rcx, gword ptr [rbp-0x120]
       call     [Lokad.Lython.Runtime.LythonRuntime:EvaluateUnaryOperator(int,System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):System.Object]
       mov      rdi, rax
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:FromObject(System.Object):Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]
       mov      rcx, rdx
       mov      rdx, rax
       mov      rdi, rbx
       mov      rsi, r14
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot):this]
       jmp      G_M000_IG45
 
G_M000_IG91:                ;; offset=0x0D42
       mov      rdi, r13
       call     [Lokad.Lython.Runtime.LythonRuntime:CanUseNativeTruth(System.Object):bool]
       test     eax, eax
       sete     r12b
       movzx    r12, r12b
 
G_M000_IG92:                ;; offset=0x0D55
       test     r12d, r12d
       jne      G_M000_IG114
       jmp      SHORT G_M000_IG90
 
G_M000_IG93:                ;; offset=0x0D60
       cmp      dword ptr [r14+0x1C], 48
       jne      SHORT G_M000_IG94
       cmp      dword ptr [r14+0x08], 3
       je       G_M000_IG114
 
G_M000_IG94:                ;; offset=0x0D72
       mov      rdi, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:TryIntegerOperation():bool:this]
       test     eax, eax
       jne      G_M000_IG45
       mov      esi, dword ptr [r14+0x10]
       mov      rdi, rbx
       xor      edx, edx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Read(int,int):System.Object:this]
       mov      r13, rax
       mov      esi, dword ptr [r14+0x0C]
       mov      rdi, rbx
       mov      edx, 1
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Read(int,int):System.Object:this]
       mov      r12, rax
       cmp      dword ptr [r14+0x1C], 48
       sete     al
       movzx    rax, al
       mov      dword ptr [rbp-0x44], eax
       test     eax, eax
       jne      SHORT G_M000_IG97
       mov      rdi, r14
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_BinaryOperator():int:this]
       mov      edi, eax
       mov      r8, gword ptr [r14]
       mov      rcx, gword ptr [rbx+0x18]
       lea      r9, [rbp-0x50]
       mov      rsi, r13
       mov      rdx, r12
       call     [Lokad.Lython.Runtime.LythonRuntime:TryEvaluateScalarComparison(int,System.Object,System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,byref):bool]
       test     eax, eax
       je       SHORT G_M000_IG98
       movzx    rdi, byte  ptr [rbp-0x50]
       test     edi, edi
       jne      SHORT G_M000_IG95
       mov      rdi, 0x7E70158034A0
       mov      rdi, gword ptr [rdi]
       jmp      SHORT G_M000_IG96
 
G_M000_IG95:                ;; offset=0x0DFA
       mov      rdi, 0x7E7015803498
       mov      rdi, gword ptr [rdi]
 
G_M000_IG96:                ;; offset=0x0E07
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:FromObject(System.Object):Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]
       mov      rcx, rdx
       mov      rdx, rax
       mov      rdi, rbx
       mov      rsi, r14
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot):this]
       jmp      G_M000_IG45
 
G_M000_IG97:                ;; offset=0x0E24
       mov      edi, dword ptr [r14+0x08]
       call     [Lokad.Lython.Runtime.LythonRuntime:AugmentedBinaryOperator(int):int]
       jmp      SHORT G_M000_IG99
 
G_M000_IG98:                ;; offset=0x0E30
       mov      rdi, r14
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_BinaryOperator():int:this]
 
G_M000_IG99:                ;; offset=0x0E39
       mov      edi, eax
       mov      rsi, r13
       mov      rdx, r12
       call     [Lokad.Lython.Runtime.LythonRuntime:CanUseNativeBinary(int,System.Object,System.Object):bool]
       test     eax, eax
       je       G_M000_IG114
       cmp      dword ptr [rbp-0x44], 0
       je       G_M000_IG102
       mov      rsi, r13
       mov      rdi, 0x7E77FB02B158
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       jne      SHORT G_M000_IG100
       mov      rsi, r13
       mov      rdi, 0x7E77F9C96558
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       jne      SHORT G_M000_IG100
       mov      rsi, r13
       mov      rdi, 0x7E77F9C635C8
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       G_M000_IG114
 
G_M000_IG100:                ;; offset=0x0EA2
       mov      rsi, r12
       mov      rdi, 0x7E77FB02B158
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       jne      SHORT G_M000_IG101
       mov      rsi, r12
       mov      rdi, 0x7E77F9C96558
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       jne      SHORT G_M000_IG101
       mov      rsi, r12
       mov      rdi, 0x7E77F9C635C8
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       G_M000_IG114
 
G_M000_IG101:                ;; offset=0x0EEB
       mov      edx, dword ptr [r14+0x08]
       mov      rcx, gword ptr [rbx+0x18]
       mov      r8, gword ptr [r14]
       mov      rdi, r13
       mov      rsi, r12
       call     [Lokad.Lython.Runtime.LythonRuntime:EvaluateAugmentedBuiltin(System.Object,System.Object,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):System.Object]
       jmp      SHORT G_M000_IG103
 
G_M000_IG102:                ;; offset=0x0F04
       mov      rdi, r14
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_BinaryOperator():int:this]
       mov      edi, eax
       mov      rcx, gword ptr [rbx+0x18]
       mov      r8, gword ptr [r14]
       mov      rsi, r13
       mov      rdx, r12
       call     [Lokad.Lython.Runtime.LythonRuntime:EvaluateBinaryOperator(int,System.Object,System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):System.Object]
 
G_M000_IG103:                ;; offset=0x0F22
       mov      rdi, rax
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:FromObject(System.Object):Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]
       mov      rcx, rdx
       mov      rdx, rax
       mov      rdi, rbx
       mov      rsi, r14
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot):this]
       jmp      G_M000_IG45
 
G_M000_IG104:                ;; offset=0x0F42
       lea      rdx, [rbp-0x58]
       mov      rdi, rbx
       mov      rsi, r14
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:TryIntegerComparison(byref,byref):bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG105
       mov      esi, dword ptr [r14+0x10]
       mov      rdi, rbx
       xor      edx, edx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Read(int,int):System.Object:this]
       mov      r13, rax
       mov      esi, dword ptr [r14+0x0C]
       mov      rdi, rbx
       mov      edx, 1
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Read(int,int):System.Object:this]
       mov      r12, rax
       mov      rdi, r14
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_BinaryOperator():int:this]
       mov      edi, eax
       mov      r8, gword ptr [r14]
       mov      rcx, gword ptr [rbx+0x18]
       lea      r9, [rbp-0x58]
       mov      rsi, r13
       mov      rdx, r12
       call     [Lokad.Lython.Runtime.LythonRuntime:TryEvaluateScalarComparison(int,System.Object,System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,byref):bool]
       test     eax, eax
       je       G_M000_IG114
 
G_M000_IG105:                ;; offset=0x0FA7
       mov      rdi, r14
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      esi, eax
       mov      rdi, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Trim(int):this]
       mov      rdi, gword ptr [rbx+0x18]
       mov      rax, gword ptr [r14]
       mov      rdi, gword ptr [rdi+0x98]
       mov      rcx, gword ptr [rdi+0x88]
       mov      rcx, gword ptr [rcx+0x20]
       test     rcx, rcx
       jne      G_M000_IG145
       mov      rdi, gword ptr [rdi+0x178]
       test     rdi, rdi
       je       SHORT G_M000_IG106
       cmp      dword ptr [rdi+0x20], 0
       setne    dil
       movzx    rdi, dil
       test     edi, edi
       jne      SHORT G_M000_IG107
 
G_M000_IG106:                ;; offset=0x0FF9
       cmp      byte  ptr [rbp-0x58], 0
       jne      G_M000_IG45
       jmp      SHORT G_M000_IG108
 
G_M000_IG107:                ;; offset=0x1005
       mov      rdi, rax
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionCanceled(Lokad.Lython.LythonSourceSpan)]
       jmp      SHORT G_M000_IG106
 
G_M000_IG108:                ;; offset=0x1010
       mov      rdi, r14
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_TargetIndex():int:this]
       mov      dword ptr [rbx+0x40], eax
       jmp      G_M000_IG46
 
G_M000_IG109:                ;; offset=0x1021
       mov      esi, dword ptr [r14+0x10]
       mov      rdi, rbx
       xor      edx, edx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Read(int,int):System.Object:this]
       mov      r13, rax
       mov      rdi, r13
       call     [Lokad.Lython.Runtime.LythonRuntime:CanUseNativeTruth(System.Object):bool]
       test     eax, eax
       je       G_M000_IG114
       mov      rdi, rbx
       mov      rsi, r14
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Take(byref):System.Object:this]
       mov      rdx, gword ptr [r14]
       mov      rsi, gword ptr [rbx+0x18]
       mov      rdi, r13
       call     [Lokad.Lython.Runtime.LythonRuntime:IsTruthy(System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):bool]
       test     eax, eax
       jne      G_M000_IG45
       jmp      SHORT G_M000_IG108
 
G_M000_IG110:                ;; offset=0x106A
       mov      rdi, r14
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_DiscardIterator():bool:this]
       test     eax, eax
       je       SHORT G_M000_IG108
       mov      esi, dword ptr [rbx+0x44]
       dec      esi
       mov      rdi, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Trim(int):this]
       jmp      SHORT G_M000_IG108
 
G_M000_IG111:                ;; offset=0x1087
       mov      esi, dword ptr [r14+0x10]
       mov      rdi, rbx
       xor      edx, edx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Read(int,int):System.Object:this]
       mov      r13, rax
       mov      rsi, r13
       mov      rdi, 0x7E77FB35AA90
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG112
       mov      rdi, r13
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:FromObject(System.Object):Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]
       mov      rcx, rdx
       mov      rdx, rax
       mov      rdi, rbx
       mov      rsi, r14
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot):this]
       jmp      G_M000_IG45
 
G_M000_IG112:                ;; offset=0x10D0
       mov      rsi, r13
       mov      rdi, 0x7E77FB2F27A0
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       jne      G_M000_IG113
       mov      rsi, r13
       mov      rdi, 0x7E77FB1D6C50
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       jne      SHORT G_M000_IG113
       mov      rsi, r13
       mov      rdi, 0x7E77FB32E668
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       jne      SHORT G_M000_IG113
       mov      rsi, r13
       mov      rdi, 0x7E77FB166110
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       jne      SHORT G_M000_IG113
       mov      rsi, r13
       mov      rdi, 0x7E77FB144048
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       jne      SHORT G_M000_IG113
       mov      rsi, r13
       mov      rdi, 0x7E77FB2DD8E0
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       jne      SHORT G_M000_IG113
       mov      rsi, r13
       mov      rdi, 0x7E77FB330640
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG114
 
G_M000_IG113:                ;; offset=0x1175
       mov      rdx, gword ptr [rbx+0x18]
       mov      rsi, gword ptr [r14]
       mov      rdi, r13
       call     [Lokad.Lython.Runtime.PyIteration+Cursor:Create(System.Object,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):Lokad.Lython.Runtime.PyIteration+Cursor]
       mov      rdx, rax
       xor      ecx, ecx
       mov      rdi, rbx
       mov      rsi, r14
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot):this]
       jmp      G_M000_IG45
 
G_M000_IG114:                ;; offset=0x119B
       xor      eax, eax
 
G_M000_IG115:                ;; offset=0x119D
       vzeroupper 
       add      rsp, 280
       pop      rbx
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG116:                ;; offset=0x11B2
       lea      rdi, bword ptr [rbx+0x50]
       mov      eax, dword ptr [r14+0x10]
       cmp      eax, dword ptr [rdi+0x08]
       jae      G_M000_IG150
       shl      rax, 4
       add      rax, bword ptr [rdi]
       mov      rdi, rax
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Object():System.Object:this]
       mov      rsi, rax
       mov      rdi, 0x7E77FB306FA8
       call     [Lokad.Lython.Internal.NullabilityExtensions:RequireNotNull[System.__Canon](System.__Canon):System.__Canon]
       mov      r13, rax
       mov      rsi, r13
       mov      rdi, 0x7E77FB2DF9D0
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG119
       lea      rdx, [rbp-0x68]
       lea      rsi, [rbp-0x60]
       mov      rdi, rax
       call     [Lokad.Lython.Runtime.PyIteration+Cursor:TryMoveNextInteger(byref,byref):bool:this]
       test     eax, eax
       je       SHORT G_M000_IG119
       cmp      byte  ptr [rbp-0x60], 0
       jne      SHORT G_M000_IG118
 
G_M000_IG117:                ;; offset=0x121B
       mov      esi, dword ptr [r14+0x10]
       mov      rdi, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Trim(int):this]
       jmp      G_M000_IG108
 
G_M000_IG118:                ;; offset=0x122D
       mov      rdi, rbx
       mov      rsi, r14
       mov      rdx, qword ptr [rbp-0x68]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:PublishInteger(byref,long):this]
       jmp      G_M000_IG45
 
G_M000_IG119:                ;; offset=0x1242
       mov      rsi, r13
       mov      rdi, 0x7E77FB35AA90
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       jne      SHORT G_M000_IG121
       mov      rsi, r13
       mov      rdi, 0x7E77FB2DF9D0
       call     CORINFO_HELP_CHKCASTCLASS
       mov      r13, rax
       cmp      byte  ptr [r13], r13b
       mov      rdi, r13
       call     [Lokad.Lython.Runtime.PyIteration+Cursor:CheckExecution():this]
       lea      rsi, [rbp-0x80]
       mov      rdi, r13
       call     [Lokad.Lython.Runtime.PyIteration+Cursor:TryMoveNextCore(byref):bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG120
       xor      r13, r13
       xor      r12d, r12d
       jmp      SHORT G_M000_IG122
 
G_M000_IG120:                ;; offset=0x1294
       mov      rdi, gword ptr [rbp-0x80]
       call     [Lokad.Lython.Runtime.PyIterationResult:Yield(System.Object):Lokad.Lython.Runtime.PyIterationResult]
       mov      r13, rax
       mov      r12d, edx
       jmp      SHORT G_M000_IG122
 
G_M000_IG121:                ;; offset=0x12A6
       mov      rdi, rax
       call     [Lokad.Lython.Runtime.Text.PyStringOps+CasedWhitespaceIteration:MoveNext():Lokad.Lython.Runtime.PyIterationResult:this]
       mov      r13, rax
       mov      r12d, edx
 
G_M000_IG122:                ;; offset=0x12B5
       mov      gword ptr [rbp-0x78], r13
       mov      byte  ptr [rbp-0x70], r12b
       cmp      byte  ptr [rbp-0x70], 0
       je       G_M000_IG117
       lea      rdi, [rbp-0x78]
       call     [Lokad.Lython.Runtime.PyIterationResult:get_Value():System.Object:this]
       mov      rdi, rax
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:FromObject(System.Object):Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]
       mov      rcx, rdx
       mov      rdx, rax
       mov      rdi, rbx
       mov      rsi, r14
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot):this]
       jmp      G_M000_IG45
 
G_M000_IG123:                ;; offset=0x12F1
       mov      rdi, rbx
       mov      rsi, r14
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:TryReturnUnpackedTuple(byref):bool:this]
       test     eax, eax
       jne      G_M000_IG56
       mov      rdi, r14
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ItemCount():int:this]
       test     eax, eax
       je       SHORT G_M000_IG124
       lea      r13, bword ptr [rbx+0x50]
       mov      r12d, dword ptr [r14+0x10]
       mov      rdi, r14
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ItemCount():int:this]
       mov      edi, r12d
       mov      esi, eax
       add      rdi, rsi
       mov      esi, dword ptr [r13+0x08]
       cmp      rdi, rsi
       ja       G_M000_IG146
       mov      edi, r12d
       shl      rdi, 4
       add      rdi, bword ptr [r13]
       mov      esi, eax
       mov      rdx, gword ptr [rbx+0x18]
       mov      rcx, gword ptr [r14]
       call     [Lokad.Lython.Runtime.LythonRuntime:CreateSlotTuple(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.PyTuple]
       mov      r13, rax
       jmp      SHORT G_M000_IG125
 
G_M000_IG124:                ;; offset=0x1357
       mov      rsi, 0x7E7015801778
       mov      r13, gword ptr [rsi]
 
G_M000_IG125:                ;; offset=0x1364
       mov      esi, dword ptr [r14+0x10]
       mov      rdi, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Trim(int):this]
       mov      rdi, r13
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:FromObject(System.Object):Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]
       mov      rcx, rdx
       mov      rdx, rax
       mov      rdi, rbx
       mov      rsi, r14
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot):this]
       jmp      G_M000_IG45
 
G_M000_IG126:                ;; offset=0x1391
       lea      r13, bword ptr [rbx+0x50]
       mov      r12d, dword ptr [r14+0x10]
       mov      rdi, r14
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ItemCount():int:this]
       mov      edi, r12d
       mov      esi, eax
       add      rdi, rsi
       mov      esi, dword ptr [r13+0x08]
       cmp      rdi, rsi
       ja       G_M000_IG146
       mov      edi, r12d
       shl      rdi, 4
       add      rdi, bword ptr [r13]
       mov      esi, eax
       mov      rdx, gword ptr [rbx+0x18]
       mov      rcx, gword ptr [r14]
       call     [Lokad.Lython.Runtime.LythonRuntime:CreateSlotList(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.PyList]
       mov      r13, rax
       mov      esi, dword ptr [r14+0x10]
       mov      rdi, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Trim(int):this]
       mov      rdi, r13
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:FromObject(System.Object):Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]
       mov      rcx, rdx
       mov      rdx, rax
       mov      rdi, rbx
       mov      rsi, r14
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot):this]
       jmp      G_M000_IG45
 
G_M000_IG127:                ;; offset=0x1401
       mov      rdi, rbx
       mov      rsi, r14
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Format(byref):bool:this]
       test     eax, eax
       jne      G_M000_IG45
       jmp      G_M000_IG114
 
G_M000_IG128:                ;; offset=0x141A
       mov      rdi, r14
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       lea      r13d, [rax+0x01]
       mov      rdi, r14
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      r12d, eax
       mov      esi, dword ptr [r14+0x10]
       mov      rdi, rbx
       xor      edx, edx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Read(int,int):System.Object:this]
       mov      rdi, rax
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:FromObject(System.Object):Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]
       mov      rcx, rax
       mov      r8, rdx
       mov      rdi, rbx
       mov      esi, r13d
       mov      edx, r12d
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Put(int,int,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot):this]
       jmp      G_M000_IG45
 
G_M000_IG129:                ;; offset=0x1465
       mov      esi, dword ptr [r14+0x10]
       mov      rdi, rbx
       xor      edx, edx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Read(int,int):System.Object:this]
       mov      rdi, r14
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      esi, eax
       mov      rdi, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Trim(int):this]
       jmp      G_M000_IG45
 
G_M000_IG130:                ;; offset=0x148D
       mov      rdi, rcx
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG131:                ;; offset=0x1496
       lea      rdi, [rbp-0xA8]
       mov      esi, 26
       mov      edx, 1
       call     [System.Runtime.CompilerServices.DefaultInterpolatedStringHandler:.ctor(int,int):this]
       mov      edi, dword ptr [rbp-0x98]
       cmp      edi, dword ptr [rbp-0x88]
       jbe      G_M000_IG147
       jmp      G_M000_IG146
 
G_M000_IG132:                ;; offset=0x14C4
       mov      rsi, gword ptr [rbx+0x08]
       mov      esi, dword ptr [rsi+0x9C]
       mov      rdi, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Trim(int):this]
       jmp      G_M000_IG56
 
G_M000_IG133:                ;; offset=0x14DC
       mov      rdi, gword ptr [rbx+0x08]
       mov      rdi, gword ptr [rdi+0x10]
       not      esi
       mov      r11, 0x7E77F8A432C8
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       mov      rdi, rax
       call     [Lokad.Lython.Runtime.LythonRuntime:RuntimeValue(System.Object):System.Object]
       mov      rdi, rax
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:FromObject(System.Object):Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]
       mov      r13, rax
       mov      r12, rdx
       jmp      G_M000_IG52
 
G_M000_IG134:                ;; offset=0x1510
       mov      rdi, rbx
       xor      edx, edx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Read(int,int):System.Object:this]
       jmp      G_M000_IG52
 
G_M000_IG135:                ;; offset=0x1520
       lea      rsi, bword ptr [rbx+0x50]
       cmp      r15d, dword ptr [rsi+0x08]
       jae      G_M000_IG150
       mov      rsi, bword ptr [rsi]
       mov      edi, r15d
       shl      rdi, 4
       mov      rsi, gword ptr [rsi+rdi]
       mov      rdi, 0x7E77FB2D7040
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG136
       lea      rdi, bword ptr [rbx+0x50]
       cmp      r15d, dword ptr [rdi+0x08]
       jae      G_M000_IG150
       mov      rdi, bword ptr [rdi]
       mov      ecx, r15d
       shl      rcx, 4
       xor      rdx, rdx
       mov      gword ptr [rdi+rcx], rdx
       mov      rdi, rax
       mov      rax, qword ptr [rax]
       mov      rax, qword ptr [rax+0x40]
       call     [rax+0x20]Lokad.Lython.Runtime.ExecutableTemporaryValue:Dispose():this
 
G_M000_IG136:                ;; offset=0x157B
       dec      r15d
       cmp      r15d, r14d
       jge      SHORT G_M000_IG135
       jmp      G_M000_IG55
 
G_M000_IG137:                ;; offset=0x1588
       mov      rdi, rdx
       mov      rsi, 0x7E77F1211C48
       call     [Lokad.Lython.Frontend.ExecutableInstruction:InvalidOperand(System.String):System.InvalidOperationException:this]
       mov      rdi, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG138:                ;; offset=0x15A4
       call     [System.ThrowHelper:ThrowArgumentOutOfRange_IndexMustBeLessException()]
       int3     
 
G_M000_IG139:                ;; offset=0x15AB
       mov      rdi, rcx
       mov      rsi, 0x7E77F1217FD8
       call     [Lokad.Lython.Frontend.ExecutableInstruction:InvalidOperand(System.String):System.InvalidOperationException:this]
       mov      rdi, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG140:                ;; offset=0x15C7
       mov      rdi, 0x7E77FAC7F990
       call     CORINFO_HELP_NEWSFAST
       mov      rbx, rax
       call     [System.SR:get_Overflow_Int64():System.String]
       mov      rsi, rax
       mov      rdi, rbx
       call     [System.OverflowException:.ctor(System.String):this]
       mov      rdi, rbx
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG141:                ;; offset=0x15F4
       mov      rdi, 0x7E77FAC7F990
       call     CORINFO_HELP_NEWSFAST
       mov      rbx, rax
       call     [System.SR:get_Overflow_Int64():System.String]
       mov      rsi, rax
       mov      rdi, rbx
       call     [System.OverflowException:.ctor(System.String):this]
       mov      rdi, rbx
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG142:                ;; offset=0x1621
       mov      rdi, r8
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG143:                ;; offset=0x162A
       mov      rdi, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG144:                ;; offset=0x1633
       mov      rdi, gword ptr [rbx+0x08]
       mov      rdi, gword ptr [rdi+0x20]
       mov      esi, r13d
       mov      r11, 0x7E77F8A432E8
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       mov      r15, rax
       mov      rdi, gword ptr [rbx+0x08]
       mov      esi, dword ptr [rbx+0x40]
       xor      edx, edx
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:OperandReadSpan(int,int):Lokad.Lython.LythonSourceSpan:this]
       mov      rsi, rax
       mov      rdi, r15
       call     [Lokad.Lython.Runtime.RuntimeErrors:UnboundLocalVariable(System.String,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.LythonRuntimeException]
       mov      rdi, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG145:                ;; offset=0x1674
       mov      rdi, rcx
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG146:                ;; offset=0x167D
       call     [System.ThrowHelper:ThrowArgumentOutOfRangeException()]
       int3     
 
G_M000_IG147:                ;; offset=0x1684
       mov      rsi, bword ptr [rbp-0x90]
       mov      eax, edi
       lea      rsi, bword ptr [rsi+2*rax]
       mov      eax, dword ptr [rbp-0x88]
       sub      eax, edi
       cmp      eax, 26
       jb       SHORT G_M000_IG148
       vmovups  ymm0, ymmword ptr [reloc @RWD192]
       vmovups  ymmword ptr [rsi], ymm0
       vmovups  xmm0, xmmword ptr [reloc @RWD224]
       vmovups  xmmword ptr [rsi+0x20], xmm0
       mov      dword ptr [rsi+0x30], 0x20003A
       mov      edi, dword ptr [rbp-0x98]
       add      edi, 26
       mov      dword ptr [rbp-0x98], edi
       jmp      SHORT G_M000_IG149
 
G_M000_IG148:                ;; offset=0x16CF
       lea      rdi, [rbp-0xA8]
       mov      rsi, 0x7E77F1217F18
       call     [System.Runtime.CompilerServices.DefaultInterpolatedStringHandler:GrowThenCopyString(System.String):this]
 
G_M000_IG149:                ;; offset=0x16E6
       mov      esi, dword ptr [r14+0x1C]
       lea      rdi, [rbp-0xA8]
       call     [System.Runtime.CompilerServices.DefaultInterpolatedStringHandler:AppendFormatted[int](int):this]
       mov      rdi, 0x7E77FA377A68
       call     CORINFO_HELP_NEWSFAST
       mov      rbx, rax
       lea      rdi, [rbp-0xA8]
       call     [System.Runtime.CompilerServices.DefaultInterpolatedStringHandler:ToStringAndClear():System.String:this]
       mov      rsi, rax
       mov      rdi, rbx
       call     [System.InvalidOperationException:.ctor(System.String):this]
       mov      rdi, rbx
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG150:                ;; offset=0x172B
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
RWD00  	dd	000006DCh ; case G_M000_IG59
       	dd	00000728h ; case G_M000_IG60
       	dd	00000255h ; case G_M000_IG30
       	dd	0000075Fh ; case G_M000_IG61
RWD16  	dd	0000004Dh ; case G_M000_IG04
       	dd	0000143Dh ; case G_M000_IG131
       	dd	00000987h ; case G_M000_IG78
       	dd	00000933h ; case G_M000_IG77
       	dd	0000143Dh ; case G_M000_IG131
       	dd	0000143Dh ; case G_M000_IG131
       	dd	000013C1h ; case G_M000_IG128
       	dd	0000140Ch ; case G_M000_IG129
       	dd	00001338h ; case G_M000_IG126
       	dd	00001298h ; case G_M000_IG123
       	dd	0000143Dh ; case G_M000_IG131
       	dd	0000143Dh ; case G_M000_IG131
       	dd	0000143Dh ; case G_M000_IG131
       	dd	0000143Dh ; case G_M000_IG131
       	dd	0000143Dh ; case G_M000_IG131
       	dd	0000143Dh ; case G_M000_IG131
       	dd	0000102Eh ; case G_M000_IG111
       	dd	00001159h ; case G_M000_IG116
       	dd	00000034h ; case G_M000_IG03
       	dd	00000AECh ; case G_M000_IG86
       	dd	0000143Dh ; case G_M000_IG131
       	dd	0000143Dh ; case G_M000_IG131
       	dd	00000D07h ; case G_M000_IG93
       	dd	00000D07h ; case G_M000_IG93
       	dd	00000C32h ; case G_M000_IG89
       	dd	00000FB7h ; case G_M000_IG108
       	dd	00000FC8h ; case G_M000_IG109
       	dd	00000EE9h ; case G_M000_IG104
       	dd	0000143Dh ; case G_M000_IG131
       	dd	0000143Dh ; case G_M000_IG131
       	dd	0000143Dh ; case G_M000_IG131
       	dd	0000143Dh ; case G_M000_IG131
       	dd	0000143Dh ; case G_M000_IG131
       	dd	0000060Fh ; case G_M000_IG51
       	dd	0000146Bh ; case G_M000_IG132
       	dd	0000146Bh ; case G_M000_IG132
       	dd	0000143Dh ; case G_M000_IG131
       	dd	0000143Dh ; case G_M000_IG131
       	dd	00001011h ; case G_M000_IG110
       	dd	000013A8h ; case G_M000_IG127
       	dd	000013A8h ; case G_M000_IG127
       	dd	000013A8h ; case G_M000_IG127
       	dd	000013A8h ; case G_M000_IG127
       	dd	000013A8h ; case G_M000_IG127
RWD192 	dq	00780065006E0055h, 0074006300650070h, 0069002000640065h, 006E0069006C006Eh
RWD224 	dq	0070006F00200065h, 00650064006F0063h

; Total bytes of code 5937

; Assembly listing for method Lokad.Lython.LythonCompiledScript:RunCore(Lokad.Lython.ILythonHost,Lokad.Lython.LythonRunOptions):Lokad.Lython.LythonExecutionResult:this (Tier1)
; Emitting BLENDED_CODE for x64 + VEX + EVEX on Unix
; Tier1 code
; optimized code
; optimized using Synthesized PGO
; rbp based frame
; fully interruptible
; with Synthesized PGO: fgCalledCount is 993
; 16 inlinees with PGO data; 70 single block inlinees; 8 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       push     r15
       push     r14
       push     r13
       push     r12
       push     rbx
       sub      rsp, 232
       lea      rbp, [rsp+0x110]
       vxorps   xmm8, xmm8, xmm8
       vmovdqu32 zmmword ptr [rbp-0xB0], zmm8
       vmovdqu32 zmmword ptr [rbp-0x80], zmm8
       xor      eax, eax
       mov      qword ptr [rbp-0x40], rax
       mov      r15, rsi
       mov      rbx, rdx
 
G_M000_IG02:                ;; offset=0x003B
       mov      r14, gword ptr [rdi+0x08]
       test     r14, r14
       je       G_M000_IG66
       test     rbx, rbx
       jne      SHORT G_M000_IG04
 
G_M000_IG03:                ;; offset=0x004D
       mov      rax, 0x7E77FA9B6E20
       mov      qword ptr [rbp-0xB0], rax
       lea      rbx, [rbp-0xB0]
 
G_M000_IG04:                ;; offset=0x0065
       mov      r13, gword ptr [rbx+0x38]
       test     r13, r13
       jne      SHORT G_M000_IG06
 
G_M000_IG05:                ;; offset=0x006E
       mov      r13, gword ptr [rdi+0x20]
       test     r13, r13
       je       G_M000_IG67
 
G_M000_IG06:                ;; offset=0x007B
       mov      rdi, 0x7E77FA8F6988
       cmp      qword ptr [r13], rdi
       jne      G_M000_IG68
       mov      r12, gword ptr [r13+0x10]
       mov      rdi, gword ptr [r12+0x08]
       mov      rdi, gword ptr [rdi+0x08]
       mov      gword ptr [rbp-0xC8], rdi
       xor      edi, edi
       mov      dword ptr [rbp-0x2C], edi
 
G_M000_IG07:                ;; offset=0x00A8
       mov      rdi, gword ptr [rbp-0xC8]
       call     [System.Threading.Monitor:Enter(System.Object)]
       mov      dword ptr [rbp-0x2C], 1
       cmp      byte  ptr [r12+0x38], 0
       jne      G_M000_IG10
       mov      rdi, 0x7E77FA8F6D88
       call     CORINFO_HELP_NEWSFAST
       mov      gword ptr [rbp-0xD0], rax
       mov      rsi, gword ptr [r12+0x08]
       lea      rdi, bword ptr [rax+0x08]
       call     CORINFO_HELP_ASSIGN_REF
       mov      rax, gword ptr [rbp-0xD0]
       lea      rdi, bword ptr [rax+0x10]
       mov      rsi, r12
       call     CORINFO_HELP_ASSIGN_REF
       mov      rax, gword ptr [r12+0x18]
       mov      gword ptr [rbp-0x100], rax
       mov      rcx, gword ptr [rbp-0xD0]
       lea      rdi, bword ptr [rcx+0x20]
       mov      rsi, rax
       call     CORINFO_HELP_ASSIGN_REF
       mov      rsi, gword ptr [rbp-0x100]
       test     rsi, rsi
       je       SHORT G_M000_IG09
 
G_M000_IG08:                ;; offset=0x012A
       lea      rdi, bword ptr [rsi+0x28]
       mov      rsi, gword ptr [rbp-0xD0]
       call     CORINFO_HELP_ASSIGN_REF
 
G_M000_IG09:                ;; offset=0x013A
       lea      rdi, bword ptr [r12+0x18]
       mov      rsi, gword ptr [rbp-0xD0]
       call     CORINFO_HELP_ASSIGN_REF
       jmp      SHORT G_M000_IG11
 
G_M000_IG10:                ;; offset=0x014D
       mov      rdi, r12
       call     [System.ThrowHelper:ThrowObjectDisposedException(System.Object)]
       int3     
 
G_M000_IG11:                ;; offset=0x0157
       mov      rdi, gword ptr [rbp-0xC8]
       call     [System.Threading.Monitor:Exit(System.Object)]
       mov      r12, gword ptr [rbp-0xD0]
 
G_M000_IG12:                ;; offset=0x016B
       mov      gword ptr [rbp-0xB8], r12
 
G_M000_IG13:                ;; offset=0x0172
       mov      rdi, gword ptr [rbx+0x40]
       test     rdi, rdi
       cmove    rdi, r13
       mov      rax, 0x7E77FA8F6988
       cmp      qword ptr [rdi], rax
       jne      G_M000_IG62
       mov      r13, gword ptr [rdi+0x10]
       mov      rdi, gword ptr [r13+0x08]
       mov      rdi, gword ptr [rdi+0x08]
       mov      gword ptr [rbp-0xD8], rdi
       xor      edi, edi
       mov      dword ptr [rbp-0x30], edi
 
G_M000_IG14:                ;; offset=0x01A8
       mov      rdi, gword ptr [rbp-0xD8]
       call     [System.Threading.Monitor:Enter(System.Object)]
       mov      dword ptr [rbp-0x30], 1
       cmp      byte  ptr [r13+0x38], 0
       jne      G_M000_IG17
       mov      rdi, 0x7E77FA8F6D88
       call     CORINFO_HELP_NEWSFAST
       mov      gword ptr [rbp-0xE0], rax
       mov      rsi, gword ptr [r13+0x08]
       lea      rdi, bword ptr [rax+0x08]
       call     CORINFO_HELP_ASSIGN_REF
       mov      rax, gword ptr [rbp-0xE0]
       lea      rdi, bword ptr [rax+0x10]
       mov      rsi, r13
       call     CORINFO_HELP_ASSIGN_REF
       mov      rax, gword ptr [r13+0x18]
       mov      gword ptr [rbp-0x108], rax
       mov      rcx, gword ptr [rbp-0xE0]
       lea      rdi, bword ptr [rcx+0x20]
       mov      rsi, rax
       call     CORINFO_HELP_ASSIGN_REF
       mov      rsi, gword ptr [rbp-0x108]
       test     rsi, rsi
       je       SHORT G_M000_IG16
 
G_M000_IG15:                ;; offset=0x0227
       lea      rdi, bword ptr [rsi+0x28]
       mov      rsi, gword ptr [rbp-0xE0]
       call     CORINFO_HELP_ASSIGN_REF
 
G_M000_IG16:                ;; offset=0x0237
       lea      rdi, bword ptr [r13+0x18]
       mov      rsi, gword ptr [rbp-0xE0]
       call     CORINFO_HELP_ASSIGN_REF
       jmp      SHORT G_M000_IG18
 
G_M000_IG17:                ;; offset=0x0249
       mov      rdi, r13
       call     [System.ThrowHelper:ThrowObjectDisposedException(System.Object)]
       int3     
 
G_M000_IG18:                ;; offset=0x0253
       mov      rdi, gword ptr [rbp-0xD8]
       call     [System.Threading.Monitor:Exit(System.Object)]
       mov      r13, gword ptr [rbp-0xE0]
 
G_M000_IG19:                ;; offset=0x0267
       mov      gword ptr [rbp-0xC0], r13
 
G_M000_IG20:                ;; offset=0x026E
       mov      rax, gword ptr [rbx+0x60]
       mov      gword ptr [rbp-0xF8], rax
       mov      rdi, 0x7E77FA9B6E20
       call     CORINFO_HELP_NEWSFAST
       mov      gword ptr [rbp-0xE8], rax
       mov      rsi, gword ptr [rbx+0x08]
       lea      rdi, bword ptr [rax+0x08]
       call     CORINFO_HELP_ASSIGN_REF
       mov      rsi, gword ptr [rbx+0x10]
       mov      rax, gword ptr [rbp-0xE8]
       lea      rdi, bword ptr [rax+0x10]
       call     CORINFO_HELP_ASSIGN_REF
       mov      rsi, gword ptr [rbx+0x18]
       mov      rax, gword ptr [rbp-0xE8]
       lea      rdi, bword ptr [rax+0x18]
       call     CORINFO_HELP_ASSIGN_REF
       mov      rsi, gword ptr [rbx+0x20]
       mov      rax, gword ptr [rbp-0xE8]
       lea      rdi, bword ptr [rax+0x20]
       call     CORINFO_HELP_ASSIGN_REF
       mov      rax, gword ptr [rbp-0xE8]
       lea      rdi, bword ptr [rax+0x60]
       mov      rsi, gword ptr [rbp-0xF8]
       call     CORINFO_HELP_ASSIGN_REF
       movzx    rdi, byte  ptr [rbx+0x58]
       mov      rax, gword ptr [rbp-0xE8]
       mov      byte  ptr [rax+0x58], dil
       mov      rsi, gword ptr [rbx+0x28]
       lea      rdi, bword ptr [rax+0x28]
       call     CORINFO_HELP_ASSIGN_REF
       mov      rsi, gword ptr [rbx+0x30]
       mov      rax, gword ptr [rbp-0xE8]
       lea      rdi, bword ptr [rax+0x30]
       call     CORINFO_HELP_ASSIGN_REF
       mov      rdi, qword ptr [rbx+0x68]
       mov      rax, gword ptr [rbp-0xE8]
       mov      qword ptr [rax+0x68], rdi
       mov      rsi, gword ptr [rbx+0x38]
       lea      rdi, bword ptr [rax+0x38]
 
G_M000_IG21:                ;; offset=0x0337
       call     CORINFO_HELP_ASSIGN_REF
       mov      rsi, gword ptr [rbx+0x40]
       mov      rbx, gword ptr [rbp-0xE8]
       lea      rdi, bword ptr [rbx+0x40]
       call     CORINFO_HELP_ASSIGN_REF
       lea      rdi, bword ptr [rbx+0x48]
       mov      rsi, r12
       call     CORINFO_HELP_ASSIGN_REF
       lea      rdi, bword ptr [rbx+0x50]
       mov      rsi, r13
       call     CORINFO_HELP_ASSIGN_REF
       mov      rdi, 0x7E77FAC6A190
       cmp      qword ptr [r14+0x18], rdi
       jne      G_M000_IG61
       mov      r14, gword ptr [r14+0x10]
       mov      rdi, r14
       call     [Lokad.Lython.LythonEngine+<>c__DisplayClass8_0:<CompileCore>g__CreatePreExecutionFailure|1():Lokad.Lython.LythonExecutionResult:this]
       mov      r13, rax
       test     r13, r13
       jne      G_M000_IG57
       mov      rdi, 0x7E77FB140B98
       call     CORINFO_HELP_NEWSFAST
       mov      r13, rax
       mov      rsi, gword ptr [r14+0x10]
       mov      r12, gword ptr [r14+0x18]
       lea      rdi, bword ptr [r13+0x08]
       call     CORINFO_HELP_ASSIGN_REF
       lea      rdi, bword ptr [r13+0x10]
       mov      rsi, r12
       call     CORINFO_HELP_ASSIGN_REF
       mov      r14, gword ptr [r14+0x20]
       test     r14, r14
       je       G_M000_IG58
       mov      rdi, 0x7E77FB2B8BC8
       call     CORINFO_HELP_NEWSFAST
       mov      r12, rax
 
G_M000_IG22:                ;; offset=0x03E3
       lea      rdi, bword ptr [r12+0x08]
       mov      rsi, r15
       call     CORINFO_HELP_ASSIGN_REF
       lea      rdi, bword ptr [r12+0x10]
       mov      rsi, rbx
       call     CORINFO_HELP_ASSIGN_REF
       lea      rdi, bword ptr [r12+0x18]
       mov      rsi, r13
       call     CORINFO_HELP_ASSIGN_REF
       lea      rdi, bword ptr [r12+0x20]
       mov      rsi, r14
       call     CORINFO_HELP_ASSIGN_REF
       mov      rdi, 0x7E77FB2B8C48
       call     CORINFO_HELP_NEWSFAST
       mov      r15, rax
       lea      rdi, bword ptr [r15+0x10]
       mov      rsi, r12
       call     CORINFO_HELP_ASSIGN_REF
       mov      rdi, 0x7E77FB1AA868
       mov      qword ptr [r15+0x18], rdi
       mov      rdi, 0x7E70158034A8
       mov      rbx, gword ptr [rdi]
       mov      rdi, 0x7E7877F013F0
       mov      rax, 0x7E787879A810
       call     rax
       cmp      dword ptr [rax], 4
       jle      G_M000_IG59
       mov      rdi, gword ptr [rax+0x08]
       mov      rax, bword ptr [rdi+0x20]
       test     rax, rax
       je       G_M000_IG59
 
G_M000_IG23:                ;; offset=0x0480
       mov      rax, gword ptr [rax+0x10]
       test     rax, rax
       jne      SHORT G_M000_IG25
 
G_M000_IG24:                ;; offset=0x0489
       call     [System.Threading.Thread:InitializeCurrentThread():System.Threading.Thread]
 
G_M000_IG25:                ;; offset=0x048F
       mov      r14, gword ptr [rax+0x08]
       test     r14, r14
       jne      G_M000_IG60
       mov      rdi, 0x7E7015801160
       mov      r14, gword ptr [rdi]
 
G_M000_IG26:                ;; offset=0x04A9
       mov      rdi, 0x7E77FB2B8FD8
       call     CORINFO_HELP_NEWSFAST
       mov      r13, rax
       mov      rdi, 0x7E77F8A34828
       call     CORINFO_HELP_NEWSFAST
       mov      rsi, rax
       lea      rdi, bword ptr [r13+0x18]
       call     CORINFO_HELP_ASSIGN_REF
       lea      rdi, bword ptr [r13+0x20]
       mov      rsi, r15
       call     CORINFO_HELP_ASSIGN_REF
       lea      rdi, bword ptr [r13+0x08]
       mov      rsi, r14
       call     CORINFO_HELP_ASSIGN_REF
       mov      rdi, gword ptr [rbx+0x08]
       mov      gword ptr [rbp-0xF0], rdi
       xor      edi, edi
       mov      dword ptr [rbp-0x34], edi
 
G_M000_IG27:                ;; offset=0x04FE
       mov      rdi, gword ptr [rbp-0xF0]
       call     [System.Threading.Monitor:Enter(System.Object)]
       mov      dword ptr [rbp-0x34], 1
       cmp      byte  ptr [rbx+0x20], 0
       jne      G_M000_IG45
       mov      r15, gword ptr [rbx+0x10]
       mov      r14, gword ptr [r15+0x08]
       test     r14, r14
       je       G_M000_IG51
       cmp      byte  ptr [r15], r15b
       cmp      gword ptr [r14+0x08], r15
       jne      G_M000_IG46
       cmp      gword ptr [r14+0x10], r14
       jne      G_M000_IG47
       xor      rdi, rdi
       mov      gword ptr [r15+0x08], rdi
 
G_M000_IG28:                ;; offset=0x054A
       xor      rdi, rdi
       mov      gword ptr [r14+0x08], rdi
 
G_M000_IG29:                ;; offset=0x0550
       mov      gword ptr [r14+0x10], rdi
 
G_M000_IG30:                ;; offset=0x0554
       mov      gword ptr [r14+0x18], rdi
       dec      dword ptr [r15+0x18]
       inc      dword ptr [r15+0x1C]
       mov      rdi, gword ptr [r14+0x20]
       xor      rsi, rsi
       mov      gword ptr [rdi+0x20], rsi
       lea      rdi, bword ptr [rdi+0x18]
       mov      rsi, r13
       call     CORINFO_HELP_ASSIGN_REF
       mov      rbx, gword ptr [rbx+0x08]
       test     rbx, rbx
       je       G_M000_IG48
       mov      rdi, rbx
       call     System.Threading.ObjectHeader:GetLockHandleIfExists(System.Object):nint
       test     rax, rax
       je       G_M000_IG40
 
G_M000_IG31:                ;; offset=0x0594
       mov      r15, gword ptr [rax]
 
G_M000_IG32:                ;; offset=0x0597
       cmp      byte  ptr [r15], r15b
 
G_M000_IG33:                ;; offset=0x059A
       mov      rbx, gword ptr [r15+0x08]
       test     rbx, rbx
       jne      G_M000_IG41
 
G_M000_IG34:                ;; offset=0x05A7
       mov      rdi, 0x7E77FAC99130
       call     CORINFO_HELP_NEWSFAST
       mov      r14, rax
       lea      rdi, bword ptr [r14+0x08]
       mov      rsi, r15
       call     CORINFO_HELP_ASSIGN_REF
       mov      rsi, gword ptr [r15+0x08]
       test     rsi, rsi
       jne      SHORT G_M000_IG43
 
G_M000_IG35:                ;; offset=0x05CE
       mov      rdi, rsi
       test     rdi, rdi
       je       SHORT G_M000_IG37
 
G_M000_IG36:                ;; offset=0x05D6
       mov      rax, 0x7E77FAC86198
       cmp      qword ptr [rdi], rax
       jne      G_M000_IG49
 
G_M000_IG37:                ;; offset=0x05E9
       mov      rsi, rdi
 
G_M000_IG38:                ;; offset=0x05EC
       lea      rdi, bword ptr [r14+0x10]
       call     CORINFO_HELP_ASSIGN_REF
       lea      rdi, bword ptr [r15+0x08]
       test     rdi, rdi
       je       G_M000_IG50
       mov      rsi, r14
       mov      rdx, rbx
       call     System.Threading.Interlocked:CompareExchangeObject(byref,System.Object,System.Object):System.Object
       cmp      rax, rbx
       jne      SHORT G_M000_IG33
       mov      rdi, r14
 
G_M000_IG39:                ;; offset=0x0615
       call     [System.Threading.Condition:SignalAll():this]
       jmp      G_M000_IG55
 
G_M000_IG40:                ;; offset=0x0620
       mov      rdi, rbx
       call     [System.Threading.ObjectHeader:<GetLockObject>g__GetLockObjectFallback|11_0(System.Object):System.Threading.Lock]
       mov      r15, rax
       jmp      G_M000_IG32
 
G_M000_IG41:                ;; offset=0x0631
       mov      rdi, 0x7E77FAC99130
       cmp      qword ptr [rbx], rdi
       jne      G_M000_IG34
 
G_M000_IG42:                ;; offset=0x0644
       mov      rdi, rbx
       jmp      SHORT G_M000_IG39
 
G_M000_IG43:                ;; offset=0x0649
       mov      rdi, 0x7E77FAC99130
       cmp      qword ptr [rsi], rdi
       jne      G_M000_IG35
 
G_M000_IG44:                ;; offset=0x065C
       mov      rsi, gword ptr [rsi+0x10]
       jmp      SHORT G_M000_IG38
 
G_M000_IG45:                ;; offset=0x0662
       mov      rdi, rbx
       call     [System.ThrowHelper:ThrowObjectDisposedException(System.Object)]
       int3     
 
G_M000_IG46:                ;; offset=0x066C
       mov      rdi, 0x7E77FA377A68
       call     CORINFO_HELP_NEWSFAST
       mov      r13, rax
       call     [System.SR:get_ExternalLinkedListNode():System.String]
       mov      rsi, rax
       mov      rdi, r13
       call     [System.InvalidOperationException:.ctor(System.String):this]
       mov      rdi, r13
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG47:                ;; offset=0x0699
       mov      rdi, gword ptr [r14+0x10]
       lea      rdi, bword ptr [rdi+0x18]
       mov      rsi, gword ptr [r14+0x18]
       call     CORINFO_HELP_ASSIGN_REF
       mov      rdi, gword ptr [r14+0x18]
       lea      rdi, bword ptr [rdi+0x10]
       mov      rsi, gword ptr [r14+0x10]
       call     CORINFO_HELP_ASSIGN_REF
       mov      rsi, gword ptr [r14+0x10]
       lea      rdi, bword ptr [r15+0x08]
       call     CORINFO_HELP_ASSIGN_REF
       jmp      G_M000_IG28
 
G_M000_IG48:                ;; offset=0x06CD
       mov      rdi, 0x7E77F12007E8
       call     [System.ArgumentNullException:Throw(System.String)]
       int3     
 
G_M000_IG49:                ;; offset=0x06DE
       mov      rdi, rax
       call     CORINFO_HELP_CHKCASTCLASS
       int3     
 
G_M000_IG50:                ;; offset=0x06E7
       call     [System.ThrowHelper:ThrowNullReferenceException()]
       int3     
 
G_M000_IG51:                ;; offset=0x06EE
       mov      rdi, 0x7E77FB1DF2F8
       call     CORINFO_HELP_NEWSFAST
       mov      r15, rax
       mov      rdi, r15
       mov      rsi, rbx
       mov      rdx, r13
       call     [Lokad.Lython.Runtime.ExecutionThreads+Worker:.ctor(Lokad.Lython.Runtime.ExecutionThreads,Lokad.Lython.Runtime.ExecutionThreads+WorkItem):this]
       call     [System.Threading.ExecutionContext:IsFlowSuppressed():bool]
       test     eax, eax
       je       SHORT G_M000_IG52
       mov      rdi, gword ptr [r15+0x10]
       cmp      byte  ptr [rdi], dil
       mov      esi, 1
       call     [System.Threading.Thread:Start(bool):this]
       jmp      SHORT G_M000_IG55
 
G_M000_IG52:                ;; offset=0x072D
       call     [System.Threading.ExecutionContext:SuppressFlow():System.Threading.AsyncFlowControl]
       mov      gword ptr [rbp-0x40], rax
 
G_M000_IG53:                ;; offset=0x0737
       mov      rdi, gword ptr [r15+0x10]
       cmp      byte  ptr [rdi], dil
       mov      esi, 1
       call     [System.Threading.Thread:Start(bool):this]
       nop      
 
G_M000_IG54:                ;; offset=0x074A
       lea      rdi, [rbp-0x40]
       call     [System.Threading.AsyncFlowControl:Undo():this]
       nop      
 
G_M000_IG55:                ;; offset=0x0755
       mov      rdi, gword ptr [rbp-0xF0]
       call     [System.Threading.Monitor:Exit(System.Object)]
       mov      rdi, r13
       call     [Lokad.Lython.Runtime.ExecutionThreads+SynchronousWorkItem:Wait():Lokad.Lython.LythonExecutionResult:this]
       mov      r15, rax
 
G_M000_IG56:                ;; offset=0x076E
       lea      rdi, bword ptr [r15+0x28]
       mov      rsi, gword ptr [rbp-0xC0]
       call     CORINFO_HELP_ASSIGN_REF
       jmp      SHORT G_M000_IG63
 
G_M000_IG57:                ;; offset=0x0780
       mov      r15, r13
       jmp      SHORT G_M000_IG56
 
G_M000_IG58:                ;; offset=0x0785
       mov      rdi, 0x7E77FA377A68
       call     CORINFO_HELP_NEWSFAST
       mov      r15, rax
       mov      rdi, r15
       mov      rsi, 0x7E77F120D5A0
       call     [System.InvalidOperationException:.ctor(System.String):this]
       mov      rdi, r15
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG59:                ;; offset=0x07B3
       mov      edi, 4
       call     CORINFO_HELP_GETDYNAMIC_GCTHREADSTATIC_BASE_NOCTOR_OPTIMIZED
       jmp      G_M000_IG23
 
G_M000_IG60:                ;; offset=0x07C2
       xor      rdi, rdi
       cmp      byte  ptr [r14+0x18], 0
       cmovne   r14, rdi
       jmp      G_M000_IG26
 
G_M000_IG61:                ;; offset=0x07D2
       mov      rsi, r15
       mov      rdx, rbx
       mov      rdi, gword ptr [r14+0x10]
       call     [r14+0x18]System.Func`3[System.__Canon,System.__Canon,System.__Canon]:Invoke(System.__Canon,System.__Canon):System.__Canon:this
       mov      r15, rax
       jmp      SHORT G_M000_IG56
 
G_M000_IG62:                ;; offset=0x07E5
       mov      r11, 0x7E77F8A44928
       call     [r11]Lokad.Lython.ILythonMemoryBudget:CreateScope():Lokad.Lython.ILythonMemoryScope:this
       mov      r13, rax
       jmp      G_M000_IG19
 
G_M000_IG63:                ;; offset=0x07FA
       cmp      gword ptr [rbp-0xB8], 0
       je       SHORT G_M000_IG64
       mov      rdi, 0x7E77FA8F6D88
       mov      rax, gword ptr [rbp-0xB8]
       cmp      qword ptr [rax], rdi
       jne      G_M000_IG69
       mov      rdi, rax
       call     [Lokad.Lython.LythonMemoryBudget+Scope:Dispose():this]
 
G_M000_IG64:                ;; offset=0x0827
       mov      rax, r15
 
G_M000_IG65:                ;; offset=0x082A
       add      rsp, 232
       pop      rbx
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG66:                ;; offset=0x083C
       mov      rdi, 0x7E77FA856F18
       call     CORINFO_HELP_NEWSFAST
       mov      rbx, rax
       mov      rdi, rbx
       mov      rsi, 0x7E77F1215638
       call     [System.ObjectDisposedException:.ctor(System.String):this]
       mov      rdi, rbx
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG67:                ;; offset=0x086A
       mov      rdi, 0x7E77FA8F6988
       call     CORINFO_HELP_NEWSFAST
       mov      r13, rax
       xor      esi, esi
       xor      edx, edx
       mov      rdi, r13
       call     [Lokad.Lython.LythonMemoryBudget:.ctor(System.Nullable`1[long]):this]
       jmp      G_M000_IG06
 
G_M000_IG68:                ;; offset=0x088E
       mov      rdi, r13
       mov      r11, 0x7E77F8A44920
       call     [r11]Lokad.Lython.ILythonMemoryBudget:CreateScope():Lokad.Lython.ILythonMemoryScope:this
       mov      r12, rax
       jmp      G_M000_IG12
 
G_M000_IG69:                ;; offset=0x08A6
       mov      rdi, rax
       mov      r11, 0x7E77F8A44938
       call     [r11]System.IDisposable:Dispose():this
       jmp      G_M000_IG64
 
G_M000_IG70:                ;; offset=0x08BB
       push     rax
 
G_M000_IG71:                ;; offset=0x08BC
       lea      rdi, [rbp-0x40]
       call     [System.Threading.AsyncFlowControl:Undo():this]
       nop      
 
G_M000_IG72:                ;; offset=0x08C7
       add      rsp, 8
       ret      
 
G_M000_IG73:                ;; offset=0x08CC
       push     rax
 
G_M000_IG74:                ;; offset=0x08CD
       cmp      dword ptr [rbp-0x34], 0
       je       SHORT G_M000_IG75
       mov      rdi, gword ptr [rbp-0xF0]
       call     [System.Threading.Monitor:Exit(System.Object)]
 
G_M000_IG75:                ;; offset=0x08E0
       nop      
 
G_M000_IG76:                ;; offset=0x08E1
       add      rsp, 8
       ret      
 
G_M000_IG77:                ;; offset=0x08E6
       push     rax
 
G_M000_IG78:                ;; offset=0x08E7
       mov      rdi, gword ptr [rbp-0xC0]
       mov      r11, 0x7E77F8A44930
       call     [r11]System.IDisposable:Dispose():this
       call     CORINFO_HELP_RETHROW
       int3     
 
G_M000_IG79:                ;; offset=0x0901
       push     rax
 
G_M000_IG80:                ;; offset=0x0902
       cmp      dword ptr [rbp-0x30], 0
       je       SHORT G_M000_IG81
       mov      rdi, gword ptr [rbp-0xD8]
       call     [System.Threading.Monitor:Exit(System.Object)]
 
G_M000_IG81:                ;; offset=0x0915
       nop      
 
G_M000_IG82:                ;; offset=0x0916
       add      rsp, 8
       ret      
 
G_M000_IG83:                ;; offset=0x091B
       push     rax
 
G_M000_IG84:                ;; offset=0x091C
       cmp      gword ptr [rbp-0xB8], 0
       je       SHORT G_M000_IG86
       mov      rdi, 0x7E77FA8F6D88
       mov      rax, gword ptr [rbp-0xB8]
       cmp      qword ptr [rax], rdi
       jne      SHORT G_M000_IG85
       mov      rdi, rax
       call     [Lokad.Lython.LythonMemoryBudget+Scope:Dispose():this]
       jmp      SHORT G_M000_IG86
 
G_M000_IG85:                ;; offset=0x0947
       mov      rdi, rax
       mov      r11, 0x7E77F8A44938
       call     [r11]System.IDisposable:Dispose():this
 
G_M000_IG86:                ;; offset=0x0957
       nop      
 
G_M000_IG87:                ;; offset=0x0958
       add      rsp, 8
       ret      
 
G_M000_IG88:                ;; offset=0x095D
       push     rax
 
G_M000_IG89:                ;; offset=0x095E
       cmp      dword ptr [rbp-0x2C], 0
       je       SHORT G_M000_IG90
       mov      rdi, gword ptr [rbp-0xC8]
       call     [System.Threading.Monitor:Exit(System.Object)]
 
G_M000_IG90:                ;; offset=0x0971
       nop      
 
G_M000_IG91:                ;; offset=0x0972
       add      rsp, 8
       ret      
 
; Total bytes of code 2423

