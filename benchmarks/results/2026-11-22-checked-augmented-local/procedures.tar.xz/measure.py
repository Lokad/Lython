from pathlib import Path
import gzip, hashlib, json, os, shutil, statistics, subprocess

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
worktree = repo / ".git/agent-worktrees/checked-augmented-local-20261122"
donor = lab.parent / "machine-arithmetic-cpython-20261122"
donor_quiet = donor / "quiet"
shape_donor = lab.parent / "module-helper-placement-20261122"
core = "Lokad.Lython.dll"

def read(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def save(path, obj):
    path.write_text(json.dumps(obj, ensure_ascii=False, indent=2)+"\n", encoding="utf-8", newline="\n")

base_id = read(donor_quiet / "identity.json")
reference = donor / "frozen"
files = base_id["imageFiles"]["candidate"]
assert len(files) == 32 and {n: sha(reference / n) for n in files} == files
assert gzip.decompress((repo / "benchmarks/results/2026-11-22-machine-arithmetic-cpython/candidate-core.dll.gz").read_bytes()) == (reference / core).read_bytes()
candidate = subprocess.check_output(["git","rev-parse","HEAD"],cwd=worktree,text=True).strip()
assert candidate.startswith("638fc1138")
assert not subprocess.check_output(["git","status","--porcelain"],cwd=worktree)
assert "0 Error(s)" in (lab / "build-committed-win.log").read_text(encoding="utf-8")
assert all("Passed:     9," in (lab / f"public-{p}-final.log").read_text(encoding="utf-8") for p in ("win","ubuntu"))
build = worktree / "benchmarks/Lokad.Lython.Benchmarks/bin/Release/net11.0"
default_catalog = read(donor_quiet / "representative.json")
selected = {}
for folder in (donor_quiet, shape_donor/"quiet", lab.parent/"construction-csv-cpython-20261122/quiet"):
    for case in read(folder/"representative.json")["cases"]:
        selected.setdefault(case["id"],case)
loop = "diagnostic.loop-range.inside.large"
function_call = "diagnostic.helper-placement.function-call"
module_call = "diagnostic.helper-placement.module-call"
mixed = "scripts.annotated-rule-closures.literal-positional-dynamic-keyword"
invoice = "scripts.csv-invoice.large"
meter = "scripts.csv-meter-report.typed-ascii"
catalog = lab / "representative.json"
cases = [selected[n] for n in (function_call,module_call,loop,mixed,invoice,meter)]
save(catalog,dict(default_catalog,cases=cases,performanceQualified=False))
out = lab / "frozen"
inspect = shape_donor / "inspect"
allocation = shape_donor / "allocation-worker"
sdk = Path.home() / ".dotnet11"
dotnet = sdk / "dotnet.exe"
protocol = repo / "benchmarks/cpython-worker.py"
assert sha(protocol) == base_id["cpythonWorkerSHA256"]
env = dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk),PATH=str(sdk)+os.pathsep+os.environ["PATH"])
hashes = {}
for label, source in (("reference",reference),("candidate",build)):
    image = out / label
    image.mkdir(parents=True)
    for name in files:
        shutil.copyfile((source if name == core else reference)/name,image/name)
    hashes[label] = {name:sha(image/name) for name in files}
    for name in ("Inspect.dll","Inspect.deps.json","Inspect.runtimeconfig.json"):
        shutil.copyfile(inspect/name,image/name)
    for name in ("ValidatedAllocation.dll","ValidatedAllocation.deps.json","ValidatedAllocation.runtimeconfig.json"):
        shutil.copyfile(allocation/name,image/name)
    verify = lab / f"{label}-verify.json"
    subprocess.run([dotnet,image/"Lokad.Lython.Benchmarks.dll","--compare","verify","--catalog",catalog,
        "--dotnet",dotnet,"--python","C:/Python313/python.exe","--python-worker",protocol,"--out",verify],
        env=env,timeout=95,check=True)
    proof=read(verify)
    assert proof["state"]=="Completed" and proof["caseCount"]==len(cases) and proof["catalogSha256"]==sha(catalog)
    subprocess.run([dotnet,image/"Inspect.dll",catalog,lab/f"{label}-shape.json"],env=env,timeout=45,check=True)
    subprocess.run([dotnet,image/"ValidatedAllocation.dll",image,catalog,lab/f"{label}-allocation.json"],env=env,timeout=95,check=True)
    assert {name:sha(image/name) for name in files}==hashes[label]
assert hashes["reference"]==files
assert [n for n in files if hashes["reference"][n] != hashes["candidate"][n]]==[core]
identity=dict(reference=base_id["sourceRevision"],candidate=candidate,imageFiles=hashes,catalogSHA256=sha(catalog))
save(lab/"identity.json",identity)

old_shape,new_shape = (read(lab/f"{label}-shape.json") for label in ("reference","candidate"))
assert old_shape["coreSHA256"]==files[core] and new_shape["coreSHA256"]==hashes["candidate"][core]
changes = []
for old,new in zip(old_shape["rows"],new_shape["rows"],strict=True):
    differing = []
    assert old["id"]==new["id"]
    for left,right in zip(old["codes"],new["codes"],strict=True):
        assert left["name"]==right["name"]
        if left!=right:
            differing.append(dict(frame=left["name"],reference=left["opcodeCounts"],
                candidate=right["opcodeCounts"],capacity=[left["capacity"],right["capacity"]],
                arithmetic=[left["arithmetic"],right["arithmetic"]]))
    changes.append(dict(case=new["id"],changedFrames=differing))
assert changes[0]["changedFrames"][0]["frame"]=="run" and changes[0]["changedFrames"][0]["candidate"]["CheckLocal"]==1
assert changes[0]["changedFrames"][0]["reference"]["LoadLocal"]==changes[0]["changedFrames"][0]["candidate"]["LoadLocal"]+1
assert all(not row["changedFrames"] for row in changes[1:])
save(lab/"shape-summary.json",changes)

old_alloc,new_alloc = (read(lab/f"{label}-allocation.json")["rows"] for label in ("reference","candidate"))
changes = []
for left,right in zip(old_alloc,new_alloc,strict=True):
    assert left["id"]==right["id"] and left["sharedBudgetBaselineRestored"] and right["sharedBudgetBaselineRestored"]
    a,b=[statistics.median(x["allocatedBytesPerInvocation"]) for x in (left,right)]
    row=dict(case=left["id"],referenceBytes=a,candidateBytes=b,allocationChangePercent=100*(b/a-1),
        referencePeak=left["peakExecutionMemoryBytes"],candidatePeak=right["peakExecutionMemoryBytes"],allowanceRestored=True)
    changes.append(row)
    print(row)
assert changes[0]["referenceBytes"] - changes[0]["candidateBytes"] >= 65504
save(lab/"allocation-summary.json",changes)
