from pathlib import Path
import json

lab=Path(__file__).resolve().parent
load=lambda path:json.loads(path.read_text(encoding="utf-8-sig"))
allocation=load(lab/"allocation-summary.json")
invoice=load(lab/"invoice-local-summary.json")
decision=load(lab/"decision.json")
first=load(lab/"quiet/quiet-summary.json")
evidence=[("Initial",first)]
if decision["invoiceTimed"]:
    evidence.append(("Follow-up",load(lab/"invoice-quiet/quiet-summary.json")))
names={
    "diagnostic.helper-placement.function-call":"Function-scoped helper",
    "diagnostic.helper-placement.module-call":"Module-scoped helper",
    "diagnostic.loop-range.inside.large":"Integer range loop",
    "scripts.annotated-rule-closures.literal-positional-dynamic-keyword":"Mixed factory",
    "scripts.csv-invoice.large":"Ordinary CSV invoice",
    "scripts.csv-meter-report.typed-ascii":"Typed ASCII CSV meter",
    "scripts.csv-invoice.helper-accumulation":"Helper-driven CSV invoice",
}
lanes={"warm":"warm","compile-run":"compile to result","compile":"compile"}
percent=lambda a:f"{min(a):+.2f} to {max(a):+.2f}%"
rows=["| Collection and complete script | Boundary | Elapsed change | Wider CPU change | Worker spread old/new |",
      "| --- | --- | ---: | ---: | ---: |"]
for label,run in evidence:
    for row in run["rows"]:
        spread=f"{row['referenceSpreadPercent']:.2f} / {row['candidateSpreadPercent']:.2f}%"
        rows.append(f"| {label} · {names[row['case']]} | {lanes[row['lane']]} | "
            f"{percent(row['elapsedChangePercent'])} | {percent(row['cpuChangePercent'])} | {spread} |")
batches=sum(len(run["rows"])*28 for _,run in evidence)
elapsed=sum(run["elapsedSeconds"] for _,run in evidence)
suffix="""
[Follow-up observations](invoice-observations.tgz) ·
""" if len(evidence)>1 else ""
report="""# Keep private augmented operands in their local slots

Compared `eb227dcac` with `638fc1138` on November 22, 2026 UTC.
The same optional adapter and worker run against each core on the quiet
Azure F4as_v7 with Ubuntu 24.04.4 and .NET 11 RC3. Both copies of the
32-file image and their catalog verify before staging. The only binary
difference is the core library.

A same-block call checks that a private lexical local is bound at the
original read. The augmented operation consumes that same slot after the
right-hand side. Captured, mirrored and module bindings and explicit
right-hand-side writes retain their ordinary snapshots. The supplied helper
uses seven slots instead of eight. The emitted tapes of the five initial
controls match. No new memory owner or outstanding borrow is needed.

## Timing

"""+ "\n".join(rows)+f"""

Negative changes favor the candidate. Intervals span process-median pairs.
Each lane has two workers per image, at least eight seconds of warmup
per worker and seven rotated batches. Warm clocks cover guest work,
applicable mediated RAM-backed I/O, output verification and prior-result
disposal. Compilation includes code-owner disposal. Compile to result
adds one run and cleanup. Startup stays separate. Wider process CPU
also covers fixture reset and request handling.

## Allocation and correctness

The original function-scoped script allocates 65,504 fewer bytes per
warm execution on Windows, from 142,728 to 77,224. The 4,096-record
helper-driven CSV invoice falls from 6,229,470 to 6,098,430 bytes.
Admitted peaks match and every shared allowance returns to baseline.
Both platforms pass 666 focused Release checks and a final nine-case
rerun. Both images match all six initial script pairs, eight focused
semantic probes and the complete CSV invoice against CPython 3.13.2.
The tests cover alias identity and reflected operations, rebinding,
early unbound errors, generator send, actual file suspension,
cancellation and terminal refusal.

The Windows diagnostic with tiering disabled grows the ordinary
instruction prefix from 11,696 to 11,896 bytes and the native loop from
4,869 to 4,979 bytes. This records a shared code-generation change.
It does not attribute Linux timing differences to particular instructions.

{batches} timed batches verify in {elapsed:.0f} seconds across the quiet
collections. All workers join, fixtures are removed and raw evidence is
archived and verified under the VM lease. The initial retrieval guard
rejects an early local attempt before contacting the machine.

## Decision

{decision['readerDecision']}

[Timing summary](summary.json) · [Allocation](allocation-summary.json) ·
[Executable shapes](shape-summary.json) · [Semantic coverage](semantics-summary.json) ·
[Initial observations](observations.tgz) ·
"""+suffix.strip()+"\n[Verification and procedures](procedures.tar.xz).\n"
(lab/"README.md").write_text(report,encoding="utf-8",newline="\n")
