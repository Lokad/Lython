from pathlib import Path
import gzip,hashlib,json,shutil,tarfile

lab=Path(__file__).resolve().parent
out=Path("benchmarks/results/2026-11-22-checked-augmented-local")
quiet=lab/"quiet"

def read(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def save(path, value):
    path.write_text(json.dumps(value,indent=2)+"\n",encoding="utf-8",newline="\n")

local=read(lab/"identity.json")
decision=read(lab/"decision.json")
allocation=read(lab/"allocation-summary.json")
assert len(allocation)==6 and all(row["allowanceRestored"] and row["referencePeak"]==row["candidatePeak"] for row in allocation)
assert allocation[0]["referenceBytes"]-allocation[0]["candidateBytes"]==65504
for platform in ("win","ubuntu"):
    for name,count in (("white",129),("public",537),("public-final",9)):
        file=lab/(f"public-{platform}-final.log" if name=="public-final" else f"{name}-{platform}.log")
        report=file.read_text(encoding="utf-8-sig")
        assert "Passed!" in report and f"Passed: {count:5d}, Skipped:" in report
for role,files in local["imageFiles"].items():
    sitting=lab/"frozen"/role
    assert len(files)==32 and {n:sha(sitting/n) for n in files}==files
    for prefix,catalog,expected in (
        ("","representative.json",6),("semantics-","semantics.json",8),("invoice-","invoice.json",1)
    ):
        verify=lab/(f"invoice-{role}-verify.json" if prefix=="invoice-" else f"{role}-{prefix}verify.json")
        proof=read(verify)
        assert proof["state"]=="Completed" and proof["caseCount"]==expected
        assert proof["catalogSha256"]==sha(lab/catalog)
reference=lab/"frozen/reference/Lokad.Lython.dll"
stored=Path("benchmarks/results/2026-11-22-machine-arithmetic-cpython/candidate-core.dll.gz")
assert gzip.decompress(stored.read_bytes())==reference.read_bytes()
summary=dict(sourceRevision=local["reference"]+" versus "+local["candidate"], identity=local, allocation=allocation,
    invoiceAllocation=read(lab/"invoice-local-summary.json"),decision=decision,collections={})

for name,folder,count in [("B1364",quiet,7),("B1365",lab/"invoice-quiet",3)]:
    if not (folder/"terminal-status.json").exists():
        assert name=="B1365" and not decision["invoiceTimed"]
        continue
    receipt=read(folder/"archive-receipt.json")
    status=read(folder/"terminal-status.json")
    assert receipt==status["receipt"] and status["exitCode"]=="0" and receipt["jobs"]==count
    assert not status["remainingWorkers"] and not status["remainingTrace"]
    assert all(receipt[k] for k in ("complete","allWorkersJoined","guestFixturesRemoved","quietBeforeAndAfter","archivedAndVerifiedUnderLease"))
    assert sha(folder/"observations.tgz")==receipt["archiveSHA256"]
    identity=read(folder/"identity.json")
    assert identity["imageFiles"]==local["imageFiles"] and sha(folder/"representative.json")==identity["catalogSHA256"]
    cases={c["id"]:c for c in read(folder/"representative.json")["cases"]}
    if name=="B1365":
        for role in local["imageFiles"]:
            proof=read(lab/f"invoice-and-mixed-{role}-verify.json")
            assert proof["state"]=="Completed" and proof["caseCount"]==2
            assert proof["catalogSha256"]==identity["catalogSHA256"]
    raw=read(folder/"retrieved/confirmation/confirmation.json")
    assert raw["complete"] and raw["warmupSeconds"]==8 and raw["rounds"]==7 and len(raw["jobs"])==count
    for job in raw["jobs"]:
        assert job["workersJoinedAndFixturesRemoved"] and len(job["samples"])==28
        case=cases[job["case"]]
        for sample in job["samples"]:
            response=sample["response"]
            assert response["completedInvocations"]>0 and response["status"]=="Completed"
            assert response["sourceSha256"]==case["sourceSha256"] and response["fixtureSha256"]==case["fixtureSha256"]
            assert response.get("actualOutputSha256")== (None if job["lane"]=="compile" else case["expectedOutputSha256"])
            assert response.get("actualFilesSha256")== (None if job["lane"]=="compile" else case.get("expectedFilesSha256"))
    clocks=read(folder/"quiet-summary.json")
    del clocks["retentionDecisionPending"]
    clocks.update(archiveSHA256=receipt["archiveSHA256"],verifiedTimedBatches=count*28)
    summary["collections"][name]=clocks

out.mkdir(exist_ok=False)
save(out/"summary.json",summary)
for name in ("README.md","allocation-summary.json","shape-summary.json","semantics-summary.json"):
    shutil.copyfile(lab/name,out/name)
for label,folder in [("",quiet),("invoice-",lab/"invoice-quiet")]:
    if not (folder/"terminal-status.json").exists():
        continue
    for name in ("archive-receipt.json","terminal-status.json","observations.tgz"):
        shutil.copyfile(folder/name,out/(label+name))
(out/"candidate-core.dll.gz").write_bytes(gzip.compress((lab/"frozen/candidate/Lokad.Lython.dll").read_bytes(),mtime=0))
with tarfile.open(out/"procedures.tar.xz","w:xz",preset=6) as tar:
    for folder in (lab,quiet,lab/"invoice-quiet"):
        if not folder.exists(): continue
        for f in sorted(folder.iterdir()):
            if f.is_file() and f.suffix not in (".tgz",".dll",".exe"):
                tar.add(f,arcname=f.relative_to(lab).as_posix())
print("Verified exact frozen images, local semantics/refunds and every sampled batch.")
