from pathlib import Path
import hashlib,json,os,shutil,subprocess,tarfile

lab=Path(__file__).resolve().parent
prior=lab/"quiet"
out=lab/"invoice-quiet"

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def read(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))

def write(path, text):
    if path.suffix==".py":
        compile(text,str(path),"exec")
    path.write_text(text,encoding="utf-8",newline="\n")

def save(path,data):
    write(path,json.dumps(data,indent=2)+"\n")

config=read(prior/"config.json")
receipt=read(prior/"archive-receipt.json")
status=read(prior/"terminal-status.json")
assert status["exitCode"]=="0" and not status["remainingWorkers"] and not status["remainingTrace"]
assert receipt==status["receipt"] and receipt["jobs"]==7
assert all(receipt[key] for key in ("complete","quietBeforeAndAfter","allWorkersJoined","archivedAndVerifiedUnderLease"))
assert sha(prior/"observations.tgz")==receipt["archiveSHA256"]
identity=read(prior/"identity.json")
catalog=lab/"invoice.json"
invoice=read(catalog)
cases=[row["id"] for row in invoice["cases"]]
assert cases==["scripts.csv-invoice.helper-accumulation"]
mixed="scripts.annotated-rule-closures.literal-positional-dynamic-keyword"
original=read(prior/"representative.json")
control=next(case for case in original["cases"] if case["id"]==mixed)
preferred=lab/"invoice-and-mixed.json"
save(preferred,dict(invoice,cases=invoice["cases"]+[control]))
sdk=Path.home()/".dotnet11"
dotnet=sdk/"dotnet.exe"
env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk),PATH=str(sdk)+os.pathsep+os.environ["PATH"])
allocation=read(lab/"invoice-local-summary.json")
assert all(row["fullRefund"] for row in allocation.values())
assert allocation["reference"]["bytes"]-allocation["candidate"]["bytes"]==131040
assert allocation["reference"]["admittedPeak"]==allocation["candidate"]["admittedPeak"]
for role,files in identity["imageFiles"].items():
    image=lab/"frozen"/role
    assert len(files)==32 and {n:sha(image/n) for n in files}==files
    verified=read(lab/f"invoice-{role}-verify.json")
    assert verified["state"]=="Completed" and verified["caseCount"]==1 and verified["catalogSha256"]==sha(catalog)
    proof=lab/f"invoice-and-mixed-{role}-verify.json"
    subprocess.run([dotnet,image/"Lokad.Lython.Benchmarks.dll","--compare","verify","--catalog",preferred,
        "--dotnet",dotnet,"--python","C:/Python313/python.exe","--python-worker",lab.parents[3]/"benchmarks/cpython-worker.py",
        "--out",proof],check=True,env=env,timeout=90)
    accepted=read(proof)
    assert accepted["state"]=="Completed" and accepted["caseCount"]==2 and accepted["catalogSha256"]==sha(preferred)
catalog=preferred

out.mkdir()
shutil.copyfile(catalog,out/"representative.json")
identity.update(catalogSHA256=sha(catalog),purpose="Private local staging in a complete helper-driven CSV invoice")
save(out/"identity.json",identity)
root="/home/lokad/lython-bench-checks/checked-local-csv-b1365-20261122"
unit="lython-b1365-checked-local-csv-20261122"
jobs=[(mixed,"compile-run"),(cases[0],"warm"),(mixed,"compile")]
for name in ("collect.py","archive-owned.py","run.sh","retrieve.py"):
    s=(prior/name).read_text(encoding="utf-8").replace(config["root"],root).replace(config["unit"],unit).replace("B1364","B1365")
    if name=="collect.py":
        first,last=s.index("\njobs = "),s.index("\nassert len(jobs)")
        s=s[:first]+"\njobs = "+repr(jobs)+s[last:]
        s=s.replace("len(jobs)==7","len(jobs)==3").replace("started < 400", "started < 174")
    elif name in ("archive-owned.py","retrieve.py"):
        s=s.replace("jobs=7,", "jobs=3,").replace("['jobs']==7","['jobs']==3").replace("len(raw['jobs'])==7","len(raw['jobs'])==3")
    write(out/name,s)
assert b"\r" not in (out/"run.sh").read_bytes()
parts=("identity.json","collect.py","archive-owned.py","run.sh","representative.json")
packed=out/"payload.tgz"
with tarfile.open(packed,"w:gz") as archive:
    for name in parts:
        archive.add(out/name,arcname=name)
unpacked=sum((out/name).stat().st_size for name in parts)
info=dict(root=root,unit=unit,identity=identity,source=config["root"],sourceRole="candidate",
    sourceFiles=identity["imageFiles"]["candidate"],sourceCatalogSHA256=config["catalogSHA256"],
    donorArchiveSHA256=receipt["archiveSHA256"],protocolSource=config["root"]+"/cpython-worker.py",
    protocolSHA256=config["protocolSHA256"],payloadBytes=packed.stat().st_size,payloadSHA256=sha(packed),
    retireGroups=[],catalogSHA256=identity["catalogSHA256"],unpackedBytes=unpacked)
save(out/"config.json",info)
s=(prior/"remote-launch.py").read_text(encoding="utf-8")
first,last=s.index("\nc=")+1,s.index("\nb=Path(")
s=s[:first]+"c="+repr(info)+s[last:]
s=s.replace("source/c['sourceRole']/n,p","source/role/n,p")
s=s.replace("lython-b1364-fixtures","lython-b1365-fixtures").replace("RuntimeMaxSec=460","RuntimeMaxSec=235")
write(out/"remote-launch.py",s)
s=(lab/"launch.py").read_text(encoding="utf-8").replace("quiet'","invoice-quiet'")
write(lab/"launch-invoice.py",s.replace("420","215").replace("Checked augmented local comparison","Checked local CSV comparison"))
s=(lab/"summarize.py").read_text(encoding="utf-8").replace("/'quiet/","/'invoice-quiet/").replace("len(raw['jobs'])==7","len(raw['jobs'])==3")
write(lab/"summarize-invoice.py",s)
print("Both production-pair images and CSV goldens verified for a complete invoice and two mixed-factory phases.")
