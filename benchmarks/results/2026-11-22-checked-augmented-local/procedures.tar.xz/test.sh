#!/bin/bash
set -euo pipefail
cd /mnt/d/code/Lython/.git/agent-worktrees/checked-augmented-local-20261122
export DOTNET_ROOT="$HOME/.dotnet"
export PATH="$DOTNET_ROOT:$PATH"
dir=/mnt/d/code/Lython/.git/agent-notes/review-20261031/checked-augmented-local-20261122
white='Category!=Stress&(FullyQualifiedName~LocalAugmentedLifetime|FullyQualifiedName~ExecutableAugmented|FullyQualifiedName~DirectOperand|FullyQualifiedName~IntegerAliasOwnership|FullyQualifiedName~IntegerBinaryAdmission|FullyQualifiedName~ExecutableAsyncIteratorCleanup|FullyQualifiedName~NativeIntegerChain)'
api='Category!=Stress&(FullyQualifiedName~Augmented|FullyQualifiedName~OperandReadFailure|FullyQualifiedName~NamedExpression|FullyQualifiedName~Walrus|FullyQualifiedName~NonlocalRebinding|FullyQualifiedName~GlobalBindingPipeline|FullyQualifiedName~IntegerLocalSemantics|FullyQualifiedName~NativeReturnFunction|FullyQualifiedName~HelperLocalLifetime|FullyQualifiedName~FloatArithmeticPipeline|FullyQualifiedName~AdmissionFailureCommand|FullyQualifiedName~ProtectedHelperExecution|FullyQualifiedName~GeneratorNamespaceMutation)'
dotnet test tests/Lokad.Lython.Tests -c Release -f net10.0 --filter "$white" --artifacts-path /tmp/lython-checked-augmented-b1364 > "$dir/white-ubuntu.log" 2>&1 || { tail -80 "$dir/white-ubuntu.log"; exit 1; }
dotnet test tests/Lokad.Lython.PublicApi.Tests -c Release -f net10.0 --filter "$api" --artifacts-path /tmp/lython-checked-augmented-b1364 > "$dir/public-ubuntu.log" 2>&1 || { tail -80 "$dir/public-ubuntu.log"; exit 1; }
rg -H 'Passed!' "$dir/white-ubuntu.log" "$dir/public-ubuntu.log"
