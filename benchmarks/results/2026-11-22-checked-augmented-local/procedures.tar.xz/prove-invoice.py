from pathlib import Path
from textwrap import indent
import copy, hashlib, json, os, shutil, statistics, subprocess

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
template=json.loads((lab/"representative.json").read_text(encoding="utf-8"))
seed=next(case for case in template["cases"] if case["id"]=="scripts.csv-invoice.large")
prefix, source=seed["source"].split("\n\ntotals = {}",maxsplit=1)
source="totals = {}"+source
loop_start=source.index("        quantity, net, tax, gross = price_line(row)")
accumulator=source.index("        count += 1",loop_start)
tail=source.index("\nwith open('report.csv'",accumulator)
lines=source[loop_start:accumulator].splitlines(keepends=True)
assert source[accumulator:tail]=="        count += 1\n        grand_total += gross"
body="".join(line[4:] if line.startswith("    ") else line for line in lines)
aggregate="def accumulate(totals, row):\n"+body+"    return gross\n"
source=source[:loop_start]+"        grand_total += accumulate(totals, row)\n        count += 1"+source[tail:]
source=prefix+"\n\n"+aggregate+"\ndef invoice():\n"+indent(source,"    ")+"\ninvoice()\n"
golden=copy.deepcopy(seed)
golden.update(id="scripts.csv-invoice.helper-accumulation",source=source,sourceUtf8Bytes=len(source.encode("utf-8")),
    sourceSha256=hashlib.sha256(source.encode("utf-8")).hexdigest())
manifest=lab/"invoice.json"
manifest.write_text(json.dumps(dict(template,cases=[golden]),indent=2)+"\n",encoding="utf-8",newline="\n")

sdk=Path.home()/".dotnet11"
dotnet=sdk/"dotnet.exe"
env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk),PATH=str(sdk)+os.pathsep+os.environ["PATH"])
identity=json.loads((lab/"identity.json").read_text(encoding="utf-8"))
results={}
for role,hashes in identity["imageFiles"].items():
    image=lab/"frozen"/role
    assert {name:hashlib.sha256((image/name).read_bytes()).hexdigest() for name in hashes}==hashes
    verify=lab/f"invoice-{role}-verify.json"
    subprocess.run([dotnet,image/"Lokad.Lython.Benchmarks.dll","--compare","verify","--catalog",manifest,
        "--dotnet",dotnet,"--python","C:/Python313/python.exe","--python-worker",repo/"benchmarks/cpython-worker.py","--out",verify],
        env=env,timeout=95,check=True)
    proof=json.loads(verify.read_text(encoding="utf-8"))
    assert proof["state"]=="Completed" and proof["caseCount"]==1
    assert proof["catalogSha256"]==hashlib.sha256(manifest.read_bytes()).hexdigest()
    shape=lab/f"invoice-{role}-shape.json"
    subprocess.run([dotnet,image/"Inspect.dll",manifest,shape],env=env,timeout=45,check=True)
    found=next(c for c in json.loads(shape.read_text(encoding="utf-8"))["rows"][0]["codes"] if c["name"]=="invoice")
    assert found["opcodeCounts"].get("CheckLocal",0)==int(role=="candidate")
    allocation=lab/f"invoice-{role}-allocation.json"
    subprocess.run([dotnet,image/"ValidatedAllocation.dll",image,manifest,allocation],env=env,timeout=95,check=True)
    observed=json.loads(allocation.read_text(encoding="utf-8"))["rows"][0]
    assert observed["sharedBudgetBaselineRestored"]
    results[role]=dict(bytes=statistics.median(observed["allocatedBytesPerInvocation"]),
        admittedPeak=observed["peakExecutionMemoryBytes"],instructions=found["opcodeCounts"],fullRefund=True)
(lab/"invoice-local-summary.json").write_text(json.dumps(results,indent=2)+"\n",encoding="utf-8",newline="\n")
print(results)
