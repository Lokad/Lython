from pathlib import Path
import copy, hashlib, json, os, subprocess

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
template=json.loads((lab/"representative.json").read_text(encoding="utf-8"))
seed=template["cases"][0]
scripts=[
    ("generator-send","""def identity(value):return value
def generate():
    value=70000
    value+=identity((yield 1))
    yield value
g=generate()
print(next(g),g.send(23))
g.close()
""","1 70023\n"),
    ("walrus-rebind","""def identity(value):return value
def augment():
    value=70000
    value+=identity(value:=10)
    return value
print(augment())
""","70010\n"),
    ("captured-rebind","""def augment():
    value=70000
    def replace():
        nonlocal value
        value=100
        return 30
    value+=replace()
    return value
print(augment())
""","70030\n"),
    ("global-rebind","""value=70000
def replace():
    globals()['value']=100
    return 30
value+=replace()
print(value)
""","70030\n"),
    ("inplace-alias","""def augment():
    value=[70000]
    alias=value
    value+=list([23])
    return alias is value,value
print(augment())
""","(True, [70000, 23])\n"),
    ("held-identity-reflected","""class Right:
    def __init__(self,original):self.original=original
    def __radd__(self,left):return left is self.original
def augment():
    value=69999+1
    value+=Right(value)
    return value
print(augment())
""","True\n"),
    ("optimized-local-snapshot","""def read(mapping):
    mapping['value']=1
    return 23
def augment():
    value=70000
    value+=read(locals())
    return value
print(augment())
""","70023\n"),
    ("exception-before-store","""def error():
    raise ValueError("rhs")
def augment():
    value=69999+1
    alias=value
    try:
        value+=error()
    except ValueError as e:
        print(str(e),value is alias,value)
    return value
print(augment())
""","rhs True 70000\n70000\n"),
]
catalog=[]
def sha(contents):return hashlib.sha256(contents.encode("utf-8")).hexdigest()
fixture='{"size":1,"text":null}'
for label,source,expected in scripts:
    case=copy.deepcopy(seed)
    case.update(id="diagnostic.checked-local."+label,size=1,source=source,sourceUtf8Bytes=len(source.encode("utf-8")),
        sourceSha256=sha(source),fixtureJson=fixture,fixtureSha256=sha(fixture),expectedOutput=expected,
        expectedOutputUtf8Bytes=len(expected.encode("utf-8")),expectedOutputSha256=sha(expected))
    catalog.append(case)

manifest=lab/"semantics.json"
manifest.write_text(json.dumps(dict(template,cases=catalog),indent=2)+"\n",encoding="utf-8",newline="\n")
sdk=Path.home()/".dotnet11"
dotnet=sdk/"dotnet.exe"
env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk),PATH=str(sdk)+os.pathsep+os.environ["PATH"])
identity=json.loads((lab/"identity.json").read_text(encoding="utf-8"))
code_shapes={}
for role, hashes in identity["imageFiles"].items():
    image=lab/"frozen"/role
    assert len(hashes)==32 and {name:hashlib.sha256((image/name).read_bytes()).hexdigest() for name in hashes}==hashes
    verify=lab/f"{role}-semantics-verify.json"
    subprocess.run([dotnet,image/"Lokad.Lython.Benchmarks.dll","--compare","verify","--catalog",manifest,
        "--dotnet",dotnet,"--python","C:/Python313/python.exe","--python-worker",repo/"benchmarks/cpython-worker.py","--out",verify],
        env=env,timeout=95,check=True)
    proof=json.loads(verify.read_text(encoding="utf-8"))
    assert proof["state"]=="Completed" and proof["caseCount"]==len(scripts) and proof["catalogSha256"]==hashlib.sha256(manifest.read_bytes()).hexdigest()
    output=lab/f"{role}-semantics-shape.json"
    subprocess.run([dotnet,image/"Inspect.dll",manifest,output],env=env,timeout=45,check=True)
    observed=json.loads(output.read_text(encoding="utf-8"))
    assert observed["coreSHA256"]==hashes["Lokad.Lython.dll"]
    code_shapes[role]={r["id"].split(".")[-1]:sum(c["opcodeCounts"].get("CheckLocal",0) for c in r["codes"]) for r in observed["rows"]}
assert not any(code_shapes["reference"].values())
assert code_shapes["candidate"]=={label:int(label not in ("walrus-rebind","captured-rebind","global-rebind")) for label,_,_ in scripts}
(lab/"semantics-summary.json").write_text(json.dumps(code_shapes,indent=2)+"\n",encoding="utf-8",newline="\n")
print("Allocation-matched code exercises five private reads and preserves three required snapshots.")
