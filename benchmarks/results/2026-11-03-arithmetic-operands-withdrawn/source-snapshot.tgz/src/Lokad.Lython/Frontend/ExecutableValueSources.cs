namespace Lokad.Lython.Frontend;

// Absent sources are the preceding expression values already on the stack.
// Present sources keep their original read operation and diagnostic span.
internal sealed record ExecutableValueSources(ExecutableInstruction? First, ExecutableInstruction? Second)
{
    internal int DirectCount => (First.HasValue ? 1 : 0) + (Second.HasValue ? 1 : 0);
}
