from pathlib import Path
import ast, hashlib, json, os, shutil, subprocess, tarfile

lab=Path(__file__).resolve().parent
previous=lab.parent/'retained-lexical-cpython-b1122'
source=lab.parent/'postfix-statement-r699'
read=lambda p:p.read_text(encoding='utf-8-sig')
load=lambda p:json.loads(read(p))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def write(name,text):
    if name.endswith('.py'): ast.parse(text)
    (lab/name).write_text(text,encoding='utf-8',newline='\n')
def save(name,value): write(name,json.dumps(value,indent=2,ensure_ascii=False)+'\n')

pair=load(source/'frozen-identity.json')
git=lambda *args: subprocess.check_output(['git',*args])
revision=git('rev-parse','HEAD').decode().strip()
assert revision.startswith('a472eb2a4') and not git('status','--porcelain')
assert not git('diff','--name-only',pair['candidateCommit'],revision,'--',
               'benchmarks/Lokad.Lython.Benchmarks','benchmarks/cpython-worker.py','src/Lokad.Lython.Utf8Regex')
assert not git('diff','--name-only',pair['candidateCommit'],revision,'--',
               'src/Lokad.Lython/Frontend/Parser.cs','src/Lokad.Lython/Frontend/Parser.Statements.Assignments.cs')
files=pair['images']['candidate'].copy()
assert len(files)==32
core='Lokad.Lython.dll'
frozen=lab/'frozen/candidate'
frozen.mkdir(parents=True,exist_ok=True)
for name,digest in files.copy().items():
    origin=source/'frozen/candidate'/name
    assert sha(origin)==digest
    if name==core:
        origin=lab/'retained/bin/Lokad.Lython/release_net11.0'/name
        files[name]=sha(origin)
    shutil.copyfile(origin,frozen/name)
assert {name:sha(frozen/name) for name in files}==files
save('build-revision.json',dict(sourceRevision=revision,imageSource=revision,coreSHA256=files[core]))

catalog=load(previous/'representative.json')
wanted=('scripts.config-generated-guards.medium','scripts.config-manifest.small')
catalog['cases']=[case for case in catalog['cases'] if case['id'] in wanted]
assert len(catalog['cases'])==2
save('representative.json',catalog)
catalog_hash=sha(lab/'representative.json')
worker=lab/'cpython-worker.py'
shutil.copyfile(previous/'cpython-worker.py',worker)
worker_hash=sha(worker)
assert worker_hash==sha(Path('benchmarks/cpython-worker.py'))==load(previous/'identity.json')['cpythonWorkerSHA256']
identity=dict(sourceRevision=revision,imageSource=revision,purpose='B1130 combined postfix compiler checkpoint versus CPython',
    imageFiles={'candidate':files},auxiliaryFiles={name:digest for name,digest in files.items() if name!=core},
    coreSHA256={label:files[core] for label in ('candidate','candidate-control')},catalogSHA256=catalog_hash,
    cpythonWorkerSHA256=worker_hash,normalAdapterPin='0.4.0')
save('identity.json',identity)
sdk=Path.home()/'.dotnet11'
dotnet=sdk/'dotnet.exe'
env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk),PATH=str(sdk)+os.pathsep+os.environ['PATH'])
with (lab/'verify.log').open('wb') as log:
    subprocess.run([dotnet,frozen/'Lokad.Lython.Benchmarks.dll','--compare','verify','--catalog',lab/'representative.json',
        '--dotnet',dotnet,'--python','C:/Python313/python.exe','--python-worker',worker,'--out',lab/'verify.json'],
        env=env,stdout=log,stderr=subprocess.STDOUT,timeout=120,check=True)
verification=load(lab/'verify.json')
assert verification['state']=='Completed' and verification['catalogSha256']==catalog_hash
assert {name:sha(frozen/name) for name in files}==files

print('Verified exact combined core, full worker image and two unchanged CPython goldens.')
