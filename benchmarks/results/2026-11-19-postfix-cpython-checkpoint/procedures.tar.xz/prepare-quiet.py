from pathlib import Path
import ast, hashlib, json, shutil, tarfile

lab = Path(__file__).resolve().parent
previous = lab.parent/'retained-lexical-cpython-b1122'
donor = lab.parent/'postfix-statement-r699/quiet'
core = 'Lokad.Lython.dll'
load=lambda p: json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
def write(name, text):
    if name.endswith('.py'): ast.parse(text)
    (lab/name).write_text(text,encoding='utf-8',newline='\n')

old = load(donor/'config.json')
receipt = load(donor/'archive-receipt.json')
assert receipt['complete'] and receipt['archivedAndVerifiedUnderLease']
assert sha(donor/'observations.tgz') == receipt['archiveSHA256']
identity = load(lab/'identity.json')
files = identity['imageFiles']['candidate']
verify = load(lab/'verify.json')
assert verify['state']=='Completed' and verify['catalogSha256']==identity['catalogSHA256']==sha(lab/'representative.json')
assert len(files)==32 and {n:sha(lab/'frozen/candidate'/n) for n in files}==files
source_files = old['identity']['imageFiles']['reference']
assert {n:h for n,h in files.items() if n!=core} == {n:h for n,h in source_files.items() if n!=core}
assert sha(lab/'cpython-worker.py') == identity['cpythonWorkerSHA256']

previous_config = load(previous/'config.json')
root='/home/lokad/lython-bench-checks/postfix-cpython-b1130-20261119'
unit='lython-b1130-postfix-cpython-20261119'
cases=load(lab/'representative.json')['cases']
jobs=[(case['id'],False) for case in cases]
assert len(jobs)==2
for name in ('collect.py','archive-owned.py','launch.py','retrieve.py','run.sh'):
    text=(previous/name).read_text(encoding='utf-8').replace(previous_config['root'],root).replace('B1122','B1130')
    if name=='collect.py':
        a=text.index('    for case_id,diagnostic in ')
        b=text.index('\n',a)
        text=text[:a]+f'    for case_id,diagnostic in {jobs!r}:'+text[b:]
        a = text.index('        lanes = ')
        b = text.index('\n',a)
        text=text[:a]+'        lanes = ["warm", "compile-run", "compile"]'+text[b:]
        text=text.replace('started<510','started<195')
    elif name=='archive-owned.py':
        text=text.replace("len(raw['jobs'])==5","len(raw['jobs'])==2").replace('jobs=5,','jobs=2,')
    elif name=='retrieve.py':
        text=text.replace("['jobs']==5","['jobs']==2")
    elif name=='launch.py':
        text=text.replace('325','181')
        assert 'timedelta(seconds=181)' in text
    write(name,text)

(lab/'payload/candidate').mkdir(parents=True,exist_ok=True)
shutil.copyfile(lab/'frozen/candidate'/core,lab/'payload/candidate'/core)
names=('representative.json','identity.json','collect.py','archive-owned.py','run.sh','cpython-worker.py')
payload=lab/'payload.tgz'
with tarfile.open(payload,'w:gz') as archive:
    for name in names: archive.add(lab/name,arcname=name)
    archive.add(lab/'payload/candidate'/core,arcname='candidate/'+core)
expanded=sum((lab/name).stat().st_size for name in names)+(lab/'payload/candidate'/core).stat().st_size
space=load(lab/'quiet-space.json')
needed=174*1024*1024+1835008+expanded
available=space['freeBytes']
retired=[]
for proof in sorted(space['replicas'],key=lambda row:-row['bytes']):
    if available>needed+49152: break
    assert proof['sha256'] not in {source_files[core],files[core]} and proof['committedBlobVerified']
    available+=proof['bytes']
    retired.append(proof)
write('preflight.json',json.dumps(dict(available=available,need=needed,selected=retired),indent=2)+'\n')
assert available>needed,(available,needed)

config=dict(root=root,unit=unit,source=old['root'],sourceRole='reference',sourceFiles=source_files,
      sourceCatalogSHA256=old['catalogSHA256'],catalogSHA256=identity['catalogSHA256'],identity=identity,retireGroups=retired,
      donorArchiveSHA256=receipt['archiveSHA256'],payloadBytes=payload.stat().st_size,payloadSHA256=sha(payload),
      unpackedBytes=expanded,cpythonWorkerSHA256=identity['cpythonWorkerSHA256'])
write('config.json',json.dumps(config,indent=2)+'\n')
launcher=(previous/'remote-launch.py').read_text(encoding='utf-8')
a,b=launcher.index('\nc=')+1,launcher.index('\nb=Path(')
launcher=launcher[:a]+'c='+repr(config)+launcher[b:]
write('remote-launch.py',launcher.replace('lython-b1122-fixtures','lython-b1130-fixtures').replace('RuntimeMaxSec=590','RuntimeMaxSec=255'))
print('Staged two unchanged workloads, six lanes, and the full verified Lython image. Staging margin',available-needed)
