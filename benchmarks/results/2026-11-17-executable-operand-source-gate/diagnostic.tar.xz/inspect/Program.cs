using System.Text.Json;
using Lokad.Lython.Frontend;

using var catalog = JsonDocument.Parse(File.ReadAllText(args[0], System.Text.Encoding.UTF8));
var rows = new List<object>();
foreach (var item in catalog.RootElement.GetProperty("cases").EnumerateArray())
{
    var source = item.GetProperty("source").GetString()!;
    var syntax = LythonFrontend.Compile(source);
    if (syntax.Script is null) throw new InvalidOperationException("Catalog source did not compile: " + item.GetProperty("id"));
    var code = ExecutableScript.Compile(LoweredScript.Lower(syntax.Script)).EntryPoint;
    var visited = new HashSet<ExecutableCodeObject>();
    var functions = new List<object>();
    Visit(code);
    rows.Add(new { Case = item.GetProperty("id").GetString(), Functions = functions });

    void Visit(ExecutableCodeObject current)
    {
        if (!visited.Add(current)) return;
        var edges = new List<object>();
        for (var index = 0; index + 1 < current.Instructions.Length; index++)
        {
            var load = current.Instructions[index];
            if (load.OpCode is not (ExecutableOpCode.LoadGlobal or ExecutableOpCode.LoadName)) continue;
            var consumer = current.Instructions[index + 1];
            var count = consumer.ValueInputCount;
            if (count == 0 || consumer.InputStart != load.ResultSlot &&
                (count < 2 || consumer.SecondInput != load.ResultSlot) &&
                (count < 3 || consumer.ThirdInput != load.ResultSlot)) continue;
            edges.Add(new { Instruction = index, Name = current.Names[load.NameIndex], Load = load.OpCode.ToString(), Consumer = consumer.OpCode.ToString() });
        }
        functions.Add(new { current.Name, InstructionCount = current.Instructions.Length,
            GlobalLoads = current.Instructions.Count(i => i.OpCode == ExecutableOpCode.LoadGlobal),
            NameLoads = current.Instructions.Count(i => i.OpCode == ExecutableOpCode.LoadName),
            AdjacentConsumerCandidates = edges });
        foreach (var function in current.Functions) Visit(function.CodeObject);
        foreach (var constant in current.Constants)
            if (constant is ExecutableCreateGeneratorExpression generator) Visit(generator.CodeObject);
    }
}
File.WriteAllText(args[1], JsonSerializer.Serialize(rows, new JsonSerializerOptions { WriteIndented = true }), System.Text.Encoding.UTF8);
Console.WriteLine("Static actual-code inventory complete; no runtime timing or dynamic removable share.");
