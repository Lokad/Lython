import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys

lab = Path(__file__).resolve().parent
previous = lab.parent / 'postfix-cpython-b1130'
comparator = lab.parent / 'validator-native-roundtrip-r706'
load = lambda path: json.loads(path.read_text(encoding='utf-8-sig'))
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()

def save(path, data):
    path.write_text(json.dumps(data, indent=2, ensure_ascii=False) + '\n', encoding='utf-8', newline='\n')

repository = Path.cwd()
pair = load(comparator / 'frozen-identity.json')
identity = load(previous / 'identity.json')
files = pair['images']['candidate']
source = pair['candidateCommit']
assert source.startswith('e20604ef4')
assert subprocess.run(['git', 'merge-base', '--is-ancestor', source, 'HEAD'], check=True).returncode == 0
assert not subprocess.check_output(['git', 'diff', '--name-only', source, 'HEAD', '--', 'src', 'benchmarks/Lokad.Lython.Benchmarks'])
catalog = load(previous / 'representative.json')
catalog['cases'] = [case for case in catalog['cases'] if case['id'] == 'scripts.config-generated-guards.medium']
assert len(catalog['cases']) == 1
save(lab / 'representative.json', catalog)
shutil.copyfile(previous / 'cpython-worker.py', lab / 'cpython-worker.py')
core = files['Lokad.Lython.dll']
identity.update(sourceRevision=source, imageSource=source, purpose='B1136 retained native integer transport versus CPython',
                imageFiles={'candidate': files}, catalogSHA256=sha(lab / 'representative.json'),
                coreSHA256={'candidate': core, 'candidate-control': core},
                auxiliaryFiles={name: value for name, value in files.items() if name != 'Lokad.Lython.dll'})
save(lab / 'identity.json', identity)
image = lab / 'frozen/candidate'
image.mkdir(parents=True, exist_ok=True)
for name in files:
    shutil.copyfile(comparator / 'frozen/candidate' / name, image / name)
assert len(files) == 32 and {name: sha(image / name) for name in files} == files

sdk = Path.home() / '.dotnet11'
dotnet = sdk / 'dotnet.exe'
python = Path('C:/Python313/python.exe')
env = dict(os.environ, DOTNET_ROOT=str(sdk), DOTNET_ROOT_X64=str(sdk), PATH=str(sdk) + os.pathsep + os.environ['PATH'])
with (lab / 'verify.log').open('wb') as output:
    subprocess.run([dotnet, image / 'Lokad.Lython.Benchmarks.dll', '--compare', 'verify', '--catalog', lab / 'representative.json',
                    '--dotnet', dotnet, '--python', python, '--python-worker', lab / 'cpython-worker.py',
                    '--out', lab / 'verify.json'], env=env, stdout=output, stderr=subprocess.STDOUT, timeout=120, check=True)

proof = (comparator / 'prove-quiet-space.py').read_text(encoding='utf-8')
start = proof.index('pairs = ')
end = proof.index('\n', start)
pairs = [('validator-native-roundtrip-r706/quiet', '2026-11-19-native-integer-transport', 'reference', 'reference-core.dll.gz')]
proof = proof[:start] + 'pairs = ' + repr(pairs) + proof[end:]
stage = (previous / 'prepare-quiet.py').read_text(encoding='utf-8')
stage = stage.replace('postfix-statement-r699/quiet', 'validator-native-roundtrip-r706/quiet')
stage = stage.replace('postfix-cpython-b1130-20261119', 'integer-transport-cpython-b1136-20261119')
stage = stage.replace('lython-b1130-postfix-cpython', 'lython-b1136-integer-transport-cpython')
stage = stage.replace('B1130', 'B1136').replace('lython-b1130-fixtures', 'lython-b1136-fixtures')
stage = stage.replace("old['identity']['imageFiles']['reference']", "old['identity']['imageFiles']['candidate']")
stage = stage.replace("sourceRole='reference'", "sourceRole='candidate'")
stage = stage.replace('assert len(jobs)==2', 'assert len(jobs)==1')
stage = stage.replace('==2\"', '==1\"').replace("'jobs=2,'", "'jobs=1,'")
stage = stage.replace('181', '105').replace('started<195', 'started<130')
stage = stage.replace("(lab/'payload/candidate').mkdir(parents=True,exist_ok=True)\nshutil.copyfile(lab/'frozen/candidate'/core,lab/'payload/candidate'/core)\n", '')
stage = stage.replace("    archive.add(lab/'payload/candidate'/core,arcname='candidate/'+core)\n", '')
stage = stage.replace("+(lab/'payload/candidate'/core).stat().st_size", '')
stage = stage.replace('1835008', '1310720')
stage = stage.replace(".replace('RuntimeMaxSec=590','RuntimeMaxSec=255')", ".replace('RuntimeMaxSec=590','RuntimeMaxSec=170').replace('1835008','1310720')")
stage = stage.replace('Staged two unchanged workloads, six lanes, and the full verified Lython image.',
                      'Staged one unchanged validator, three lanes, and the full verified Lython image.')
assert "sourceRole='candidate'" in stage and "arcname='candidate/'+core" not in stage
for name, contents in [('prove-quiet-space.py', proof), ('prepare-quiet.py', stage)]:
    (lab / name).write_text(contents, encoding='utf-8', newline='\n')
    subprocess.run([sys.executable, '-X', 'utf8', lab / name], check=True)
