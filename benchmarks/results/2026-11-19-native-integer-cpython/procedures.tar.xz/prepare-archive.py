import json
from pathlib import Path

lab = Path(__file__).resolve().parent
previous = lab.parent / 'postfix-cpython-b1130'
identity = json.loads((lab / 'identity.json').read_text(encoding='utf-8'))
receipt = dict(sourceRevision=identity['sourceRevision'], coreSHA256=identity['coreSHA256']['candidate'],
               imageSource='Complete measured image carried forward from B1135')
(lab / 'build-revision.json').write_text(json.dumps(receipt, indent=2) + '\n', encoding='utf-8', newline='\n')
archive = (previous / 'collect-evidence.py').read_text(encoding='utf-8')
archive = archive.replace('2026-11-19-postfix-cpython-checkpoint', '2026-11-19-native-integer-cpython')
archive = archive.replace('receipt["jobs"] == 2', 'receipt["jobs"] == 1')
archive = archive.replace('len(cases) == 2', 'len(cases) == 1')
archive = archive.replace('len(rows) == 6', 'len(rows) == 3')
archive = archive.replace('verifiedBatches=120', 'verifiedBatches=60').replace('B1130', 'B1136')
archive = archive.replace('retained-trim-cpython-r640/retrieved', 'postfix-cpython-b1130/retrieved')
(lab / 'collect-evidence.py').write_text(archive, encoding='utf-8', newline='\n')
