from pathlib import Path
import gzip
import hashlib
import json
import subprocess

lab = Path(__file__).resolve().parent
remote = r'''
from pathlib import Path
import fcntl, hashlib, json, os, shutil, stat, subprocess
root = Path('/home/lokad/lython-bench-checks').resolve()
assert root == Path('/home/lokad/lython-bench-checks')
with (root / 'comparison-vm.lock').open('a') as lease:
    fcntl.flock(lease, fcntl.LOCK_EX | fcntl.LOCK_NB)
    assert not subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record|[p]ython3.13.*cpython-worker.py'], capture_output=True).stdout
    assert not any(os.path.ismount(p) for p in root.glob('*/guest-fixtures'))
    groups = {}
    paths = [*root.glob('*/candidate/Lokad.Lython.dll'), *root.glob('*/reference/Lokad.Lython.dll'),
             *root.glob('*/observations.tgz')]
    for path in paths:
        native = path.lstat()
        if not stat.S_ISREG(native.st_mode) or native.st_size < 524288: continue
        if native.st_uid != os.getuid() or path.resolve() != path: continue
        key = (native.st_dev, native.st_ino)
        if key not in groups:
            if path.name != 'Lokad.Lython.dll' and not path.name.endswith('.tgz'): continue
            groups[key] = dict(paths=[],bytes=native.st_size, links=native.st_nlink,
                               sha256=hashlib.sha256(path.read_bytes()).hexdigest())
        groups[key]['paths'].append(path.relative_to(root).as_posix())
    print(json.dumps(dict(freeBytes=shutil.disk_usage(root).free,
        groups=[group for group in groups.values() if len(group['paths']) == group['links']])))
'''
ssh = ['C:/Windows/System32/OpenSSH/ssh.exe', '-i', str(Path.home() / '.ssh/id_lython-bench.pem'),
       '-o', 'BatchMode=yes', '-o', 'ConnectTimeout=15', 'lokad@20.166.121.73']
inventory = json.loads(subprocess.check_output(ssh + ['python3 -'], input=remote.encode(), timeout=45))
save = lambda name, value: (lab / name).write_text(json.dumps(value, indent=2) + '\n', encoding='utf-8')
save('inventory.json', inventory)
sources = set(subprocess.check_output(['git','ls-tree','-r','--name-only','origin/master','--','benchmarks/results'],text=True).splitlines())
sha = lambda data: hashlib.sha256(data).hexdigest()
wanted = {group['sha256']: group for group in inventory['groups'] if all(
    name.endswith('/observations.tgz') or name.endswith('/Lokad.Lython.dll') for name in group['paths'])}
live = '6c4cb50a64061abb833fe25ffbf77b776322dacaf23530e5076b93442c295c06'
del wanted[live]
proofs = []
for name in sorted(sources):
    candidate = Path(name)
    if not candidate.is_file(): continue
    if name.endswith('-core.dll.gz'):
        packed = candidate.read_bytes()
        data = gzip.decompress(packed)
    elif name.endswith('/observations.tgz') and candidate.stat().st_size >= 524288:
        packed = data = candidate.read_bytes()
    else: continue
    matched = wanted.get(sha(data))
    if not matched: continue
    assert matched['bytes'] == len(data)
    origin = subprocess.check_output(['git','show',f'origin/master:{name}'])
    assert origin == packed
    if any(row['sha256'] == matched['sha256'] for row in proofs): continue
    proofs.append(matched | dict(canonical=name, canonicalSHA256=sha(packed), committedBlobVerified=True,
                                kind='exact archived measured replica'))
space = dict(freeBytes=inventory['freeBytes'], replicas=sorted(proofs,key=lambda proof:-proof['bytes']))
save('quiet-space.json', space)
print(json.dumps(dict(freeBytes=space['freeBytes'], existingGroups=len(inventory['groups']),
                      candidates=space['replicas'][:5])))
