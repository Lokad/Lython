def make():
    events = []
    shared = ['été']

    def stamp(name, value):
        events.append(name)
        return value

    def decorate(fn):
        events.append(('decorated', list(fn.__annotations__)))
        return fn

    @stamp('decorator', decorate)
    def run(a: stamp('pos-only annotation', list) = stamp('pos-only default', shared), /,
            b: stamp('positional annotation', list) = stamp('positional default', shared), *,
            c=(assigned := stamp('keyword-only default', shared))) -> stamp('return', tuple):
        return a is shared, b is shared, c is assigned

    return run(), run.__defaults__[0] is run.__kwdefaults__['c'], events

print(make())

def yielding():
    try:
        def pending(a=(yield 'default')):
            return a
        yield pending()
    finally:
        print('joined')

g = yielding()
print(next(g))
g.close()
