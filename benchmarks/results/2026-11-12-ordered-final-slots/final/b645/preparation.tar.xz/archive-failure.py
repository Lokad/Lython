from pathlib import Path
import hashlib,json,subprocess,tarfile
r=Path(__file__).parent
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
code='''from pathlib import Path
import datetime,fcntl,hashlib,json,os,shutil,subprocess,tarfile
root=Path('/home/lokad/lython-bench-checks/ordered-native-b645-20261112')
with(root.parent/'comparison-vm.lock').open('a')as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 users=subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record|[p]ython3.*cpython-worker.py'],capture_output=True,text=True)
 assert users.returncode==1,users.stdout
 assert not list((root/'guest-fixtures').iterdir())
 raw=json.loads((root/'confirmation/confirmation.json').read_text());assert not raw['complete']and len(raw['jobs'])==4 and all(row['workersJoinedAndFixturesRemoved']for row in raw['jobs'])
 env=os.environ.copy();env['DOTNET_ROOT']='/home/lokad/lython-bench-toolchains/dotnet/11.0.100-rc.3.26522.148'
 subprocess.run([env['DOTNET_ROOT']+'/dotnet',str(root/'candidate/Lokad.Lython.Benchmarks.dll'),'--compare','check-machine','--out',str(root/'confirmation/machine-after-recovery.json')],env=env,check=True,stdout=subprocess.DEVNULL)
 assert json.loads((root/'confirmation/machine-after-recovery.json').read_text())['gate']['quiet']
 errors={p.name:p.read_text()for p in(root/'confirmation').glob('*.stderr')}
 recovery=dict(originalExitCode=(root/'exit-code.txt').read_text().strip(),normalCampaignCompleted=False,completedRows=4,failedLane='fresh',cause='The persistent protocol names compile-to-result compile-run; the private collector sent fresh.',originalConditionsPreserved=True,allWorkersJoined=True,emptyRamFixtureVerified=True,recoveryQuietAfterUTC=datetime.datetime.now(datetime.timezone.utc).isoformat(),normalEndGateMissing=True,stderr=errors)
 (root/'failure-recovery.json').write_text(json.dumps(recovery,indent=2)+'\\n')
 archive=root/'observations-partial.tgz';assert not archive.exists()
 with tarfile.open(archive,'w:gz',dereference=True)as output:
  for p in sorted(root.rglob('*')):
   if p.is_file()and p!=archive and not{'reference','candidate','guest-fixtures'}&set(p.relative_to(root).parts):output.add(p,arcname=p.relative_to(root).as_posix())
 with tarfile.open(archive)as check:assert len(json.loads(check.extractfile('confirmation/confirmation.json').read())['jobs'])==4
 assert shutil.disk_usage(root).free>252*1024*1024
 subprocess.run(['sudo','-n','umount',str(root/'guest-fixtures')],check=True);(root/'guest-fixtures').rmdir()
 receipt=dict(recovery,archiveSHA256=hashlib.sha256(archive.read_bytes()).hexdigest(),archivedAndVerifiedUnderLease=True,guestFixturesRemoved=True,freeBytes=shutil.disk_usage(root).free,performanceQualified=False)
 (root/'archive-failure-receipt.json').write_text(json.dumps(receipt,indent=2)+'\\n');print(json.dumps(receipt))
'''
done=subprocess.run(ssh+['python3 -'],input=code,text=True,encoding='utf-8',capture_output=True);(r/'archive-failure.stdout').write_text(done.stdout,encoding='utf-8');(r/'archive-failure.stderr').write_text(done.stderr,encoding='utf-8');assert done.returncode==0,done.stderr
receipt=json.loads(done.stdout);print(json.dumps(receipt),flush=True)
scp=['C:/Windows/System32/OpenSSH/scp.exe','-i',ssh[2],'-o','BatchMode=yes','-o','ConnectTimeout=15']
for name in ['observations-partial.tgz','archive-failure-receipt.json']:
 done=subprocess.run(scp+['lokad@20.166.121.73:/home/lokad/lython-bench-checks/ordered-native-b645-20261112/'+name,str(r/name)],capture_output=True,text=True,encoding='utf-8');assert done.returncode==0,done.stderr
assert hashlib.sha256((r/'observations-partial.tgz').read_bytes()).hexdigest()==receipt['archiveSHA256']
out=r/'retrieved';out.mkdir()
with tarfile.open(r/'observations-partial.tgz')as archive:archive.extractall(out,filter='data')
(r/'terminal-status.json').write_text(json.dumps(dict(terminalFailure=True,recovery=receipt,noRemainingUsersOrRamFixtures=True),indent=2)+'\n',encoding='utf-8',newline='\n')
