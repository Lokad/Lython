from pathlib import Path
import json,subprocess
r=Path(__file__).parent
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
script='''from pathlib import Path
import fcntl,json,subprocess
root=Path('/home/lokad/lython-bench-checks/ordered-native-b645-20261112')
with(root.parent/'comparison-vm.lock').open('a')as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 journal=subprocess.check_output(['journalctl','-u','lython-b645-ordered-native-20261112.service','--no-pager','-o','cat'],text=True)
 (root/'failure-journal.txt').write_text(journal)
 raw=json.loads((root/'confirmation/confirmation.json').read_text())if(root/'confirmation/confirmation.json').exists()else None
 print(json.dumps(dict(journal=journal,raw=raw,fixturePaths=[str(p.relative_to(root))for p in(root/'guest-fixtures').rglob('*')],freeBytes=__import__('shutil').disk_usage(root).free)))
'''
done=subprocess.run(ssh+['python3 -'],input=script,text=True,encoding='utf-8',capture_output=True);(r/'failure-inspection.stdout').write_text(done.stdout,encoding='utf-8');(r/'failure-inspection.stderr').write_text(done.stderr,encoding='utf-8');assert done.returncode==0,done.stderr
data=json.loads(done.stdout);print(json.dumps(dict(journal=data['journal'],completeJobs=len(data['raw']['jobs'])if data['raw']else None,fixturePaths=data['fixturePaths'],freeBytes=data['freeBytes'])),flush=True)
