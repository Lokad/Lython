from pathlib import Path
import hashlib,json,tarfile
r=Path(__file__).parent;config=json.loads((r/'config.json').read_text(encoding='utf-8'))
files=['collect.py','archive-owned.py','run.sh','identity.json']
with tarfile.open(r/'payload.tgz','w:gz')as archive:
    for name in files:archive.add(r/name,arcname=name)
config.update(payloadBytes=(r/'payload.tgz').stat().st_size,payloadSHA256=hashlib.sha256((r/'payload.tgz').read_bytes()).hexdigest(),unpackedBytes=sum((r/name).stat().st_size for name in files))
(r/'config-before-hardlinks.json').write_bytes((r/'config.json').read_bytes())
(r/'config.json').write_text(json.dumps(config,indent=2)+'\n',encoding='utf-8',newline='\n')
print('Borrow immutable catalog/source identity as hard links too; actual staging estimate shrinks; OS240MiB/evidence12MiB unchanged.',flush=True)
