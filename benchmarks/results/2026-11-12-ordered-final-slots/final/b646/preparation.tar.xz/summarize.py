from pathlib import Path
import json,statistics
r=Path(__file__).parent;raw=json.loads((r/'retrieved/confirmation/confirmation.json').read_text(encoding='utf-8'));assert raw['complete']and len(raw['jobs'])==1
rows=[]
for job in raw['jobs']:
 labels=list(job['identities']);values={k:[1000*s['response']['elapsedTicks']/s['response']['clockFrequency']/s['response']['completedInvocations']for s in job['samples']if s['engine']==k]for k in labels}
 med={k:statistics.median(v)for k,v in values.items()};cpu={k:statistics.median(1000*s['externalProcessCpuTicks']/s['externalCpuFrequency']/s['response']['completedInvocations']for s in job['samples']if s['engine']==k)for k in labels}
 changes=lambda v:sorted(100*(v[a]/v[b]-1)for a in ['candidate','candidate-control']for b in ['reference','reference-control'])
 ratio=[med[a]/med[b]for a in ['candidate','candidate-control']for b in ['CPython','CPython-control']]
 row=dict(case=job['case'],lane=job['lane'],medianMilliseconds=med,processCpuMedianMilliseconds=cpu,changePercentRange=changes(med),processCpuChangePercentRange=changes(cpu),lythonOverCPythonRange=[min(ratio),max(ratio)],referenceControlPercent=100*abs(med['reference-control']/med['reference']-1),candidateControlPercent=100*abs(med['candidate-control']/med['candidate']-1),pythonControlPercent=100*abs(med['CPython-control']/med['CPython']-1),maxIqrPercent=max(100*(statistics.quantiles(v,n=4)[2]-statistics.quantiles(v,n=4)[0])/med[k]for k,v in values.items()))
 rows.append(row);print(json.dumps(row),flush=True)
(r/'summary.json').write_text(json.dumps(dict(complete=True,jobs=1,elapsedSeconds=raw['elapsedSeconds'],originalB645Preserved=True,source=json.loads((r/'identity.json').read_text(encoding='utf-8')),timing=rows),indent=2)+'\n',encoding='utf-8',newline='\n')
