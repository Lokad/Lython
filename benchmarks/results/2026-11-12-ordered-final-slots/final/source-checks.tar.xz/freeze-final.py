from pathlib import Path
import hashlib,json,os,shutil,subprocess,tarfile
r=Path(__file__).parent;out=r/'final';out.mkdir();sdk=Path('C:/Users/JoannesVermorel/.dotnet11');env=os.environ.copy();env['DOTNET_ROOT']=str(sdk);env['PATH']=str(sdk)+';C:/Python313;'+env['PATH']
assert subprocess.check_output(['git','status','--porcelain'],text=True).strip()==''
head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
names=subprocess.check_output(['git','ls-files','src/Lokad.Lython'],text=True).splitlines()
digest=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();sources={p:digest(Path(p))for p in names}
with(out/'build.log').open('w',encoding='utf-8',newline='\n')as log:done=subprocess.run([str(sdk/'dotnet.exe'),'build','Lokad.Lython.slnx','-c','Release','--no-incremental'],env=env,stdout=log,stderr=subprocess.STDOUT)
assert done.returncode==0,(out/'build.log').read_text(encoding='utf-8')
for role in ['reference','candidate']:
    shutil.copytree(r/'refined/reference',out/role,copy_function=os.link)
(out/'candidate/Lokad.Lython.dll').unlink();shutil.copyfile('src/Lokad.Lython/bin/Release/net11.0/Lokad.Lython.dll',out/'candidate/Lokad.Lython.dll')
shutil.copyfile(out/'candidate/Lokad.Lython.dll',out/'candidate-core.dll')
assert digest(out/'reference/Lokad.Lython.dll')=='e4cc65b251ace242546f337b0846908a4e2a4313953da74df6fb666e1ce87529'
with tarfile.open(out/'candidate-sources.tar.xz','w:xz')as archive:
    for name in sources:archive.add(name,arcname=name)
(out/'candidate-identity.json').write_text(json.dumps(dict(head=head,sources=sources,coreSHA256=digest(out/'candidate-core.dll'),referenceSHA256=digest(out/'reference/Lokad.Lython.dll'),purpose='Exact committed R289 delivery source including cancelled-return cleanup correction; final debt/external-baseline comparison separate from B644'),indent=2)+'\n',encoding='utf-8',newline='\n')
assert all(digest(Path(p))==h for p,h in sources.items())
shutil.copyfile(r/'catalog.json',out/'catalog.json');shutil.copytree(r/'refined/tool',out/'tool',copy_function=os.link)
for name in ['diagnostic.py','run-diagnostics.py','summarize.py']:
    code=(r/'refined'/name).read_text(encoding='utf-8')
    if name=='run-diagnostics.py':code=code.replace("['warm-sync','warm-async','compile','fresh']","['warm-sync','warm-async']")
    (out/name).write_text(code,encoding='utf-8',newline='\n')
print(json.dumps(dict(source=head,core=digest(out/'candidate-core.dll'),productionFiles=len(sources),csharpFiles=sum(p.endswith('.cs')for p in sources))),flush=True)
subprocess.run(['python','-X','utf8',str(out/'run-diagnostics.py')],check=True)
