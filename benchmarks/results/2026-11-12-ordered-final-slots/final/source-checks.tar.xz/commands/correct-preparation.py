from pathlib import Path
import hashlib,json,tarfile
r=Path(__file__).parent/'b645'
p=r/'launch.py';p.write_text(p.read_text(encoding='utf-8').replace("['compile','fresh','warm-sync','warm-async']","['warm-sync','warm-async']"),encoding='utf-8',newline='\n')
p=r/'collect.py';text=p.read_text(encoding='utf-8');start=text.index("purpose='");end=text.index("',",start);text=text[:start]+"purpose='Exact committed R289 delivery2d91eb1a including cancelled-return loan cleanup; CSV/native/guarded warm plus separate CSV compilation and compile-to-result; CPython primary external baseline and unchanged Lython controls"+text[end:];p.write_text(text,encoding='utf-8',newline='\n')
config=json.loads((r/'config.json').read_text(encoding='utf-8'));config['identity']['sourceRevision']=config['identity']['sourceRevision'].replace('all seven scripts/both APIs/compile/fresh','final seven scripts/both APIs; CSV compile/fresh in this owned collection')
(r/'identity.json').write_text(json.dumps(config['identity'],indent=2)+'\n',encoding='utf-8',newline='\n')
with tarfile.open(r/'payload.tgz','w:gz')as archive:
    for name in ['collect.py','archive-owned.py','run.sh','current-core.dll','source-identity.json','candidate-sources.tar.xz','representative.json','identity.json']:archive.add(r/name,arcname=name)
config.update(payloadBytes=(r/'payload.tgz').stat().st_size,payloadSHA256=hashlib.sha256((r/'payload.tgz').read_bytes()).hexdigest())
(r/'config.json').write_text(json.dumps(config,indent=2)+'\n',encoding='utf-8',newline='\n')
print('Local preflight corrected before any remote mutation or timing; only final-source warm phases required locally; CSV compile/fresh checked by the scheduled worker.',flush=True)
