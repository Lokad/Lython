from pathlib import Path
import hashlib,json,shutil,tarfile
r=Path(__file__).parent;old=r/'b645';out=r/'b646';out.mkdir()
oldroot='/home/lokad/lython-bench-checks/ordered-native-b645-20261112';root='/home/lokad/lython-bench-checks/compile-result-b646-20261112';oldunit='lython-b645-ordered-native-20261112';unit='lython-b646-compile-result-20261112'
source=(old/'collect.py').read_text(encoding='utf-8').replace(oldroot,root)
start=source.index('jobs=');end=source.index('\nenv = ',start)
source=source[:start]+"jobs=[['scripts.csv-validated-records.large','compile-run']]\nassert len(jobs)==1 and all(case in cases for case,lane in jobs)\n"+source[end:]
start=source.index("purpose='");end=source.index("',",start);source=source[:start]+"purpose='One corrected compile-run protocol lane after the preserved unsupported fresh request; exact delivery2d91eb1a, unchanged workers/images, CPython baseline and independent Lython controls"+source[end:]
(out/'collect.py').write_text(source,encoding='utf-8',newline='\n')
for name in ['archive-owned.py','run.sh','retrieve.py']:
    text=(old/name).read_text(encoding='utf-8').replace(oldroot,root).replace(oldunit,unit).replace('==5','==1').replace('jobs=5','jobs=1').replace('B645 five-job','B646 corrected one-job').replace("elapsedSeconds']<480","elapsedSeconds']<180")
    (out/name).write_text(text,encoding='utf-8',newline='\n')
config=json.loads((old/'config.json').read_text(encoding='utf-8'));config.update(root=root,unit=unit,sourceRoot=oldroot)
config['identity']['sourceRevision']='2d91eb1a46770e16cf6d67e8c065c018c9403582; corrected one-job compile-run after B645 protocol failure; images/workers unchanged; original/adverse conditions preserved'
config['identity']['imageSourceArchiveSHA256']='eab21a1282fa9c09bb43e126e23cbe236662cc5350c8f73760e737e3df54ddf7'
for name in ['representative.json','source-identity.json']:shutil.copyfile(old/name,out/name)
(out/'identity.json').write_text(json.dumps(config['identity'],indent=2)+'\n',encoding='utf-8',newline='\n')
with tarfile.open(out/'payload.tgz','w:gz')as archive:
    for name in ['collect.py','archive-owned.py','run.sh','representative.json','source-identity.json','identity.json']:archive.add(out/name,arcname=name)
config.update(payloadBytes=(out/'payload.tgz').stat().st_size,payloadSHA256=hashlib.sha256((out/'payload.tgz').read_bytes()).hexdigest(),unpackedBytes=sum((out/name).stat().st_size for name in ['collect.py','archive-owned.py','run.sh','representative.json','source-identity.json','identity.json']))
(out/'config.json').write_text(json.dumps(config,indent=2)+'\n',encoding='utf-8',newline='\n')
print('One corrected existing lane; borrowed exact images via hard links, no repeated successful rows;120s owner/30s stop/30s margin; OS240MiB/evidence12MiB unchanged.',flush=True)
