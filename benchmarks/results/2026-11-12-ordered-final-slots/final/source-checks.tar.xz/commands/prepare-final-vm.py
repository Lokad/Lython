from pathlib import Path
r=Path(__file__).parent
code=(r/'refined/prepare-vm.py').read_text(encoding='utf-8').replace('b644','b645').replace('B644','B645')
code=code.replace("('internal',1340),('public',303)","('internal',1341),('public',303)").replace('refined-final.log','final.log').replace('3286focused','3288focused')
code=code.replace("for phase in ['compile','fresh','warm-sync','warm-async']:","for phase in ['warm-sync','warm-async']:")
code=code.replace('R289 refined final-slot execution; shared record cache/one span exit/obsolete shape and argument wrapper removal','R289 exact delivery2d91eb1a; cancelled-return loan cleanup included')
start=code.index('jobs=');end=code.index('\ncollect=',start)
jobs=[['scripts.csv-validated-records.large','warm'],['scripts.file-search.large','warm'],['scripts.file-search.guarded-helper.large','warm'],['scripts.csv-validated-records.large','compile'],['scripts.csv-validated-records.large','fresh']]
code=code[:start]+'jobs='+repr(jobs)+code[end:]
code=code.replace('len(jobs)==6','len(jobs)==5')
line="ast.parse(collect);(out/'collect.py')"
assert line in code
code=code.replace(line,"collect=collect.replace(\"labels=['reference','candidate','reference-control','candidate-control']\",\"labels=['reference','candidate','reference-control','candidate-control','CPython','CPython-control']\")\n"+line)
code=code.replace('==6','==5').replace('jobs=6','jobs=5').replace("'jobs': 6","'jobs': 5").replace('six-job','five-job').replace('Six existing complete-script jobs','Five existing script/phase jobs; six Lython/CPython process roles')
code=code.replace('2026-11-12-ordered-final-slots/first-form/observations.tgz','2026-11-12-ordered-final-slots/refined/observations.tgz')
code=code.replace('8e407674e73c2daeb64843363197196f34b914cf7bfb847ca65d878acaa888b5','e1315a61e508122166b6fc9cf20e227f40e10b191ab1309a9aff3b80dad97dac')
code=code.replace('c8d0a5154ea3dee3b9d4280c4acd2a98178c88b7272e78923470c75034af5bd2','2bc1549734c7f2c2a029dbc62d78aec85f91070d68b00781ea84bba4fd0796be')
code=code.replace('ordered-native-b643-20261112/','ordered-native-b644-20261112/')
start=code.index("extra=Path(");end=code.index("config['retire']=specs",start);code=code[:start]+code[end:]
code=code.replace("if name.endswith('.py'):ast.parse", "if name=='summarize.py':text=text.replace(\"assert set(labels)=={'reference','reference-control','candidate','candidate-control'}\",\"assert set(labels)=={'reference','reference-control','candidate','candidate-control','CPython','CPython-control'}\").replace(\"for a in ['candidate','candidate-control']for b in ['reference','reference-control']\",\"for a in ['candidate','candidate-control']for b in ['reference','reference-control']\")\n    if name.endswith('.py'):ast.parse")
(r/'final/prepare-vm.py').write_text(code,encoding='utf-8',newline='\n')
print('Final committed source: three warm comparisons plus separate CSV compile/fresh; CPython primary external baseline and unchanged controls;420s owner.',flush=True)
