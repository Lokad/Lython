from pathlib import Path
import datetime,json,subprocess
r=Path(__file__).parent/'b646';config=json.loads((r/'config.json').read_text(encoding='utf-8'));assert not(r/'observe-not-before.json').exists()
script='''from pathlib import Path
import ast,fcntl,hashlib,io,json,os,shutil,subprocess,sys,tarfile
config=CONFIG
root=Path(config['root']);source=Path(config['sourceRoot']);base=source.parent
assert root.parent==base and not root.exists()
with(base/'comparison-vm.lock').open('a')as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert not(source/'guest-fixtures').exists()
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record|[p]ython3.*cpython-worker.py'],capture_output=True).returncode==1
 for role in ['reference','candidate']:
  assert hashlib.sha256((source/role/'Lokad.Lython.dll').read_bytes()).hexdigest()==config['identity']['coreSHA256'][role]
  for name,sha in config['identity']['auxiliaryFiles'].items():assert hashlib.sha256((source/role/name).read_bytes()).hexdigest()==sha
 required=252*1024*1024+2*config['unpackedBytes']+1024*1024
 assert shutil.disk_usage(base).free>required
 payload=sys.stdin.buffer.read(config['payloadBytes']+1);assert len(payload)==config['payloadBytes']and hashlib.sha256(payload).hexdigest()==config['payloadSHA256']
 root.mkdir()
 with tarfile.open(fileobj=io.BytesIO(payload),mode='r:gz')as archive:archive.extractall(root,filter='data')
 for name in ['representative.json','source-identity.json']:os.link(source/name,root/name)
 for role in ['reference','candidate']:shutil.copytree(source/role,root/role,copy_function=os.link)
 shutil.copyfile(source/'cpython-worker.py',root/'cpython-worker.py')
 assert hashlib.sha256((root/'representative.json').read_bytes()).hexdigest()==config['identity']['catalogSHA256']
 for name in ['collect.py','archive-owned.py']:ast.parse((root/name).read_text())
 subprocess.run(['/bin/sh','-n',str(root/'run.sh')],check=True)
 fixture=root/'guest-fixtures';fixture.mkdir();subprocess.run(['sudo','-n','mount','-t','tmpfs','-o','size=128m,mode=0700,uid=lokad,gid=lokad','lython-b646-fixtures',str(fixture)],check=True)
 setup=dict(exactImagesHardLinked=True,freeBytes=shutil.disk_usage(root).free,requiredBeforeStagingBytes=required,osFloorMiB=240,evidenceHeadroomMiB=12,jobs=1,ownerSeconds=120,stopSeconds=30,marginSeconds=30,originalB645Preserved=True)
 (root/'setup.json').write_text(json.dumps(setup,indent=2)+'\\n')
try:subprocess.run(['sudo','-n','systemd-run','--unit='+config['unit'],'--property=User=lokad','--property=WorkingDirectory='+str(root),'--property=RuntimeMaxSec=120','--property=TimeoutStopSec=30','--property=KillMode=control-group','/bin/sh',str(root/'run.sh')],check=True)
except BaseException:subprocess.run(['sudo','-n','umount',str(fixture)],check=True);fixture.rmdir();raise
live=subprocess.check_output(['systemctl','show',config['unit']+'.service','--property=ActiveState,MainPID,RuntimeMaxUSec'],text=True);assert'ActiveState=active'in live and'MainPID=0'not in live;print(live)
'''.replace('config=CONFIG','config='+repr(config))
(r/'launch-command.py').write_text(script,encoding='utf-8',newline='\n')
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
import shlex
if (r/'launch.log').exists():(r/'launch-first.log').write_bytes((r/'launch.log').read_bytes())
stage='/home/lokad/lython-bench-checks/compile-result-b646-launch-corrected.py'
write='from pathlib import Path;import sys;p=Path('+repr(stage)+');assert not p.exists();p.write_bytes(sys.stdin.buffer.read())'
done=subprocess.run(ssh+['python3 -c '+shlex.quote(write)],input=script.encode('utf-8'),capture_output=True);assert done.returncode==0,done.stderr.decode('utf-8')
done=subprocess.run(ssh+['python3 '+stage],input=(r/'payload.tgz').read_bytes(),capture_output=True);(r/'launch.log').write_bytes(done.stdout+b'\n'+done.stderr);assert done.returncode==0,done.stderr.decode('utf-8')
now=datetime.datetime.now(datetime.timezone.utc);bound=dict(acknowledgedUTC=now.isoformat(),doNotObserveBeforeUTC=(now+datetime.timedelta(seconds=180)).isoformat(),ownerSeconds=120,stopSeconds=30,marginSeconds=30)
(r/'observe-not-before.json').write_text(json.dumps(bound,indent=2)+'\n',encoding='utf-8',newline='\n');print(done.stdout.decode('utf-8'));print(json.dumps(bound),flush=True)
