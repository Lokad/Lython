# R289 — ordered native execution over final slots

Base4cc057f0; qualified9bca1337 production. This is an active migration, not a
retained result or another generic-prefix replay. R268 replaced the prepared
path with the large ordinary dispatcher and measured slower. Here one small
ordered prefix replaces the separate native tree/proof/evaluator and consumes
the final executable slot/PC layout directly. No duplicated expression graph,
speculative dictionary-field proof, replay, new public switch or call controller.

Small acyclic unmirrored functions with no local captures/exception regions use
a bounded managed value span. Parameters and live cells retain their existing
owners. Calls bind once. CPU operations inspect their actual already-evaluated
operands immediately before work; reused locals are stored exactly once, tuple
results are ordinary PyTuple. Original final instruction indices, spans and live
extents are authoritative. Cased-split fusion and private return iteration remain.

When an operation needs a namespace, dynamic protocol or user call, stop before
that operation. Direct native entry admits an ordinary workspace and copies the
live slots into the existing executable frame, preserving PC and live extent.
Already bound callback entries reuse their owned workspace. The existing caller
trampoline or initialized-frame runner owns actual I/O and cleanup; the prefix
does not start a task or park a worker. Transfer temporary ownership only after
the frame is established; dispose native-only temporaries on failure. Never
rebind defaults or re-execute an earlier operation. Require a real caller context
before a direct entry that may transfer a child, avoiding another suspended
caller packet. General functions keep their existing entry.

Delete ExecutableScript.NativeReturns, ExecutableNativeBody/NativeReturnValue,
GuardNativeBody/GuardNativeReturn and recursive native evaluation. Keep shared
primitive shape/string-operation facts still used by actual operations, under
names describing those operations. Replace false-before-effects native-call
plumbing with completed/prepared-frame outcomes; attach frames through the
existing caller links. Delete metadata-only test assertions while retaining their
independent refusal, cell, alias, cleanup and Python result assertions.

Hypothesis: remove recurring proof traversal, recursive operation evaluation and
ordinary workspace/operand dispatch for complete CSV and simple helper bodies.
Existing fast search/captured helpers may regress; no speedup is predicted. The
completion milestone is one wired replacement with old machinery removed,
correctness/ownership/cancellation verified and bounded complete-script comparison
with compilation/fresh controls. Refine measured costs, or withdraw the entire
migration. A temporary regression is acceptable during implementation, not an
unresolved retained delivery debt. Publication and final adapter qualification
remain independent/postponed.

Focused acceptance: reused locals and ordered late field reads, arbitrary admitted
reentry changing later field types, live closure rebinding, globals/defaults,
evaluation/error order, last bindings, real protocol I/O and cancellation, first
refusal, construction overlap, retained results and joined users/budget reuse.
Preserve managed stack admission; no Unsafe/native probe or new runtime policy.
