from pathlib import Path
import os,subprocess,sys
r=Path(__file__).parent;sdk=Path('C:/Users/JoannesVermorel/.dotnet11');env=os.environ.copy();env['DOTNET_ROOT']=str(sdk);env['PATH']=str(sdk)+';C:/Python313;'+env['PATH']
phase=sys.argv[1];attempt=sys.argv[2]
frameworks=['net11.0'] if phase=='quick' else ['net11.0','net10.0']
names={
 'quick':{
   'internal':['SimpleFunctionExecutionBoundary','NativeFunctionRefund','NativeClosureSequence'],
   'public':['OrderedFunctionContinuation','ReturnedIteration','NativeClosureLifetime']},
 'focused':{
   'internal':['SimpleFunction','NativeFunction','NativeClosure','LambdaExecutable','AsyncExecutableFunction','DictionaryCountingLoopAdmission','ExecutableValueTransfer','MemoryBudget','Admission','Ownership','Stack'],
   'public':['OrderedFunctionContinuation','ReturnedIteration','NativeClosure','FunctionDefault','ReceiverFunctionEntry','CallInputLifetime','ExecutableGenericFunction','CooperativeCancellation','Stack','UnboundLocal','Nonlocal','GeneratorNamespaceMutation']}}
for framework in frameworks:
 for suite in ['internal','public']:
  project='tests/Lokad.Lython.Tests/Lokad.Lython.Tests.csproj' if suite=='internal' else 'tests/Lokad.Lython.PublicApi.Tests/Lokad.Lython.PublicApi.Tests.csproj'
  filter='Category!=Stress&('+'|'.join('FullyQualifiedName~'+name for name in names[phase][suite])+')'
  path=r/f'{phase}-{suite}-{framework}-{attempt}.log';assert not path.exists()
  with path.open('w',encoding='utf-8',newline='\n') as log:done=subprocess.run([str(sdk/'dotnet.exe'),'test',project,'-c','Release','-f',framework,'--no-build','--filter',filter],env=env,stdout=log,stderr=subprocess.STDOUT)
  text=path.read_text(encoding='utf-8');print(path.name,done.returncode,flush=True);print(text[-9000:],flush=True)
  if done.returncode:sys.exit(done.returncode)
