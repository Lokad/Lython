from pathlib import Path
for name in ['NativeFunctionRefundTests.cs','NativeClosureSequenceTests.cs','SimpleFunctionExecutionBoundaryTests.cs']:
    p=Path('tests/Lokad.Lython.Tests')/name;s=p.read_text(encoding='utf-8')
    s=s.replace('Assert.NotNull(code.NativeBody);','Assert.True(code.CanInlineInstructions);')
    s=s.replace('                Assert.False(function.TryExecuteWithoutFrame([], span, out _));\n                Assert.Equal(BigInteger.Zero, function.ClosureCells[0].Value);\n','')
    p.write_text(s,encoding='utf-8',newline='\n')
print('Removed missing-argument internal-proof probe; actual TypeError/before-cell-effect assertion remains.')
