from pathlib import Path
import json,os,re,subprocess
r=Path(__file__).parent;s=Path('tests/Lokad.Lython.PublicApi.Tests/ReceiverFunctionEntryTests.cs').read_text(encoding='utf-8')
m=re.search(r'\{ "live-defaults-and-keywords", ("(?:[^"\\]|\\.)*")',s);assert m
source=json.loads(m[1]);(r/'live-defaults.py').write_text(source,encoding='utf-8',newline='\n')
(r/'one-case.json').write_text(json.dumps(dict(cases=[dict(id='live-defaults',source=source)]))+'\n',encoding='utf-8',newline='\n')
sdk=Path('C:/Users/JoannesVermorel/.dotnet11');env=os.environ.copy();env['DOTNET_ROOT']=str(sdk);env['PATH']=str(sdk)+';C:/Python313;'+env['PATH']
args=[str(sdk/'dotnet.exe'),'tools/LythonProbe/bin/Release/net11.0/LythonProbe.dll',str(r/'live-defaults.py'),'--compare-python']
done=subprocess.run(args,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT);(r/'live-defaults.log').write_bytes(done.stdout);print(done.stdout.decode('utf-8'))
args=[str(sdk/'dotnet.exe'),str(r.parent/'complete-helper-r288/bin/Release/net11.0/inspect.dll'),str(Path('src/Lokad.Lython/bin/Release/net11.0/Lokad.Lython.dll').resolve()),str((r/'one-case.json').resolve())]
done=subprocess.run(args,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE);assert done.returncode==0,done.stderr.decode('utf-8');(r/'live-defaults-facts.json').write_bytes(done.stdout)
d=json.loads(done.stdout)
for case in d['facts']:
 for function in case['functions']:
  if function['path'].endswith('/wanted'):
   print(function['path'],function['localNames']);print(json.dumps(function['instructions'],indent=2))
