from pathlib import Path
def edit(name,fn):
    p=Path(name);p.write_text(fn(p.read_text(encoding='utf-8')),encoding='utf-8',newline='\n')
p=Path('src/Lokad.Lython/Runtime/PyExecutableFunction.cs');s=p.read_text(encoding='utf-8');start=s.index('    internal override bool TryExecuteWithoutFrame');end=s.index('    protected override object ExecuteBody',start)
s=s[:start]+'''    internal bool CanStartInline => _codeObject.CanInlineInstructions
        && !Closure.IsClassBody && !Closure.IsAnnotationScope && !Closure.IsTypeParameterScope
        && Closure.ClassCell is null && Closure.InlinedComprehensionLookup is null;

    internal bool CanBindNativeArguments => CanStartInline
        && BindingPlan.ParameterCount <= LythonRuntime.NativeValueCapacity
        && BindingPlan.VariadicListIndex < 0 && BindingPlan.VariadicDictionaryIndex < 0
        && BindingPlan.PositionalDefaults is null or PyTuple
        && (BindingPlan.KeywordDefaultStorage is null || BindingPlan.KeywordDefaultStorage.SupportsNativeStringReads);

    [System.Runtime.CompilerServices.InlineArray(LythonRuntime.NativeValueCapacity)]
    private struct NativeValues { private object _first; }

    [System.Runtime.CompilerServices.MethodImpl(System.Runtime.CompilerServices.MethodImplOptions.NoInlining)]
    internal bool TryStartNativeCall(ExecutableCallSite call, ReadOnlySpan<object?> arguments, object? receiver,
        LythonRuntime.ExecutionContext context, LythonSourceSpan span, bool consumedByIteration,
        bool borrow, out object result, out LythonRuntime.ExecutionContext? frame)
    {
        result = PyNone.Instance;
        frame = null;
        if (!CanStartInline || !borrow && !CanBindNativeArguments) return false;
        NativeValues buffer = default;
        Span<object> values = buffer;
        values = values[.._codeObject.ValueStorageCapacity];
        try
        {
            var assigned = new ArgumentPresence(BindingPlan.ParameterCount);
            if (borrow)
            {
                arguments.CopyTo(values!);
                for (var i = 0; i < assigned.Length; i++) assigned[i] = true;
            }
            else LythonRuntime.BindFunctionArgumentsInto(values[..BindingPlan.ParameterCount], ref assigned,
                [], span, BindingPlan, context, receiver: receiver, callSite: call, operands: arguments);
            return StartInline(values, assigned, null, span, consumedByIteration, out result, out frame);
        }
        finally { values.Clear(); }
    }

    internal override bool TryStartBoundInvocation(in BoundCallArguments bound, LythonSourceSpan span,
        out object result, out LythonRuntime.ExecutionContext? frame)
        => TryStartBoundInvocation(bound, span, false, out result, out frame);

    internal bool TryStartBoundInvocation(in BoundCallArguments bound, LythonSourceSpan span, bool consumedByIteration,
        out object result, out LythonRuntime.ExecutionContext? frame)
    {
        result = PyNone.Instance;
        frame = null;
        return CanStartInline && StartInline(bound.Values.AsSpan(0, _codeObject.ValueStorageCapacity),
            bound.Assigned, bound, span, consumedByIteration, out result, out frame);
    }

    private bool StartInline(Span<object> values, ArgumentPresence assigned, BoundCallArguments? existing,
        LythonSourceSpan span, bool consumedByIteration, out object result, out LythonRuntime.ExecutionContext? frame)
    {
        result = PyNone.Instance;
        frame = null;
        var state = new LythonRuntime.NativeExecution(_codeObject, values, _closureCells, Closure, consumedByIteration);
        var entered = false;
        var transferred = false;
        BoundCallArguments owned = existing.GetValueOrDefault();
        var rented = false;
        try
        {
            Closure.EnterFunctionCall(span);
            entered = true;
            if (state.Run(span, out result)) return true;
            if (existing is null)
            {
                owned = LythonRuntime.RentFunctionArgumentStorage(BindingPlan, span, Closure.MemoryGovernor,
                    _codeObject.ValueStorageCapacity) with { Assigned = assigned };
                rented = true;
                values.CopyTo(owned.Values);
            }
            frame = LythonRuntime.CreateNativeContinuation(this, owned, span, state.Index, state.LiveExtent, consumedByIteration);
            state.TransferOwnership();
            transferred = true;
            return true;
        }
        catch (LythonRuntimeException error)
        {
            PyFunctionBinding.AnnotateException(error, Closure, Name, span);
            throw;
        }
        finally
        {
            try { state.Dispose(); }
            finally
            {
                try { if (entered && !transferred) Closure.LeaveFunctionCall(); }
                finally { if (rented && !transferred) LythonRuntime.ReturnBoundArguments(owned, _codeObject.ValueStorageCapacity); }
            }
        }
    }

'''+s[end:]
s=s.replace('        if (LythonRuntime.TryExecuteNativeReturn(_codeObject, frame, boundArguments.Values.AsSpan(0, boundArguments.Assigned.Length), span, out var result))\n            return result;\n','')
s=s.replace('        // Only statically proven bodies without callbacks use this shared shortcut.\n','')
p.write_text(s,encoding='utf-8',newline='\n')
p=Path('src/Lokad.Lython/Runtime/PyFunctionBase.cs');s=p.read_text(encoding='utf-8')
for async_mode in [False,True]:
    old='''            if (TryExecuteWithoutFrame(boundArguments.Values.AsSpan(0, boundArguments.Assigned.Length), span, out var result))
            {
                return result;
            }
            frame = EnterInvocationFrame(boundArguments, span);
            try { return '''+('await ExecuteBodyAsync(frame, boundArguments, span).ConfigureAwait(false);' if async_mode else 'ExecuteBody(frame, boundArguments, span);')+' }'
    new='''            var prepared = TryStartBoundInvocation(boundArguments, span, out var result, out frame);
            if (prepared && frame is null) return result;
            frame ??= EnterInvocationFrame(boundArguments, span);
            try { return '''+('prepared ? await LythonRuntime.ExecuteInitializedFrameAsync(frame).ConfigureAwait(false) ?? PyNone.Instance\n                : await ExecuteBodyAsync(frame, boundArguments, span).ConfigureAwait(false);' if async_mode else 'prepared ? LythonRuntime.ExecuteInitializedFrame(frame) ?? PyNone.Instance\n                : ExecuteBody(frame, boundArguments, span);')+' }'
    assert old in s;s=s.replace(old,new,1)
s=s.replace('frame is null ? boundArguments.Assigned.Length : _storageCapacity ?? boundArguments.Assigned.Length','_storageCapacity ?? boundArguments.Assigned.Length')
start=s.index('    internal virtual bool TryExecuteWithoutFrame');end=s.index('    internal LythonRuntime.ExecutionContext EnterInvocationFrame',start)
s=s[:start]+'''    internal abstract bool TryStartBoundInvocation(in BoundCallArguments bound, LythonSourceSpan span,
        out object result, out LythonRuntime.ExecutionContext? frame);

'''+s[end:];p.write_text(s,encoding='utf-8',newline='\n')
edit('src/Lokad.Lython/Runtime/LythonRuntime.Calls.Binding.cs',lambda s:s.replace('    private static BoundCallArguments RentFunctionArgumentStorage(', '    internal static BoundCallArguments RentFunctionArgumentStorage('))
edit('src/Lokad.Lython/Runtime/LythonRuntime.Executable.cs',lambda s:s.replace('        public int LiveExtent { get; private set; }','''        public int LiveExtent { get; private set; }

        internal void RestoreNativeExtent(int liveExtent) => LiveExtent = liveExtent;'''))
p=Path('src/Lokad.Lython/Runtime/LythonRuntime.Executable.Calls.cs');s=p.read_text(encoding='utf-8')
s=s.replace('                var nativeAttempted = ordinaryCall && positional && function.CanBorrowPositionalArguments(argumentCount, receiver);\n','')
s=s.replace(', nativeAttempted: false', '').replace(', nativeAttempted)',')').replace('bool callEntered, bool nativeAttempted)','bool callEntered)')
old='''                if (!nativeAttempted && function.TryExecuteWithoutFrame(arguments, span, consumedByIteration, out var nativeValue))
                {
                    completedValue = nativeValue;
                    goto Completed;
                }'''
new='''                if (function.TryStartBoundInvocation(bound, span, consumedByIteration, out var nativeValue, out frame))
                {
                    if (frame is null) { completedValue = nativeValue; goto Completed; }
                    functionEntered = true;
                    goto PreparedFrame;
                }'''
assert old in s;s=s.replace(old,new)
start=s.index('                    if (TryExecuteNativeReturn(');end=s.index('                    InitializeExecutableFrame',start)
s=s[:start]+s[end:]
s=s.replace('                frame.EnterExecutableSlots();\n','            PreparedFrame:\n                frame.EnterExecutableSlots();\n',1)
old='''                _pendingCallSite = site;
                _protocolCallSpan = site is null ? span : null;
                _pendingCallStart = start;
                _callCompletion = completion;
                frame._caller = this;
                frame._boundStorageOwner = bound.StorageOwner;'''
new='''                AttachPreparedCall(frame, site, start, span, completion, bound.StorageOwner);'''
assert old in s;s=s.replace(old,new)
marker='        private void CloseInvocation(Exception? failure)'
s=s.replace(marker,'''        private void AttachPreparedCall(ExecutionContext frame, ExecutableCallSite? site,
            int start, LythonSourceSpan span, CallCompletion completion, MemoryGovernor? storageOwner)
        {
            _pendingCallSite = site;
            _protocolCallSpan = site is null ? span : null;
            _pendingCallStart = start;
            _callCompletion = completion;
            frame._caller = this;
            frame._boundStorageOwner = storageOwner;
        }

'''+marker)
p.write_text(s,encoding='utf-8',newline='\n')
p=Path('src/Lokad.Lython/Runtime/LythonRuntime.Executable.Calls.Invoke.cs');s=p.read_text(encoding='utf-8')
s=s.replace('ExecutionContext? invocation, ExecutableCallSite call, int start, object target)','ExecutionContext? invocation, ExecutableCallSite call, int start, object target, out ExecutionContext? started)')
s=s.replace('            // Closed helpers complete here','            started = null;\n            // Closed helpers complete here',1)
s=s.replace('if (function is not null && function.CodeObject.NativeBody is not null)','if (function is not null && function.CanStartInline && invocation is not null)')
start=s.index('                try\n',s.index('if (function is not null'))
end=s.index('\n            // These existing native receiver',start)
s=s[:start]+'''                var callEntered = false;
                try
                {
                    scope.EnterInterpreterFrame(call.CallSpan);
                    callEntered = true;
                    scope.CheckExecution(call.CallSpan);
                    var arguments = execution.Stack.Slice(start + call.ArgumentOffset, call.ArgumentCount).Span;
                    if (!function.TryStartNativeCall(call, arguments, functionReceiver, scope, call.CallSpan,
                        CallResultConsumedByIteration(in execution, call), borrow, out var value, out var frame)) return false;
                    if (frame is not null)
                    {
                        frame.EnterExecutableSlots();
                        invocation.AttachPreparedCall(frame, call, start, call.CallSpan, CallCompletion.Call, scope.MemoryGovernor);
                        started = frame;
                        callEntered = false; // The existing child completion owns it.
                        return true;
                    }
                    scope.LeaveInterpreterFrame();
                    callEntered = false;
                    PublishInstructionResult(ref execution, invocation, execution.Code.Instructions[execution.InstructionIndex], value);
                    return true;
                }
                catch (Exception error)
                {
                    execution.Stack.RetireTo(start);
                    if (TryTranslateCallableException(error, call.CallSpan, out var translated)) throw translated;
                    throw;
                }
                finally { if (callEntered) scope.LeaveInterpreterFrame(); }
            }
'''+s[end:]
p.write_text(s,encoding='utf-8',newline='\n')
p=Path('src/Lokad.Lython/Runtime/LythonRuntime.Executable.Interpreter.Dispatch.cs');s=p.read_text(encoding='utf-8')
s=s.replace('                            if (TryExecuteNativeCall(ref execution, scope, invocation, call, callStart, target)) break;','''                            if (TryExecuteNativeCall(ref execution, scope, invocation, call, callStart, target, out var started))
                            {
                                if (started is null) break;
                                nextCall = new(started);
                                pendingSpan = call.CallSpan;
                                return InstructionPause.Call;
                            }''')
p.write_text(s,encoding='utf-8',newline='\n')
print('Wired native/completed/prepared-frame entry and shared caller attachment; initialization runner and tests next.')
