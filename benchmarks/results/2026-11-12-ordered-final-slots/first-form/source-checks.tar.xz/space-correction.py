from pathlib import Path
import hashlib,json,subprocess
r=Path(__file__).parent/'b643'
config=json.loads((r/'config.json').read_text(encoding='utf-8'))
canonical=Path('benchmarks/results/2026-11-12-native-accumulation-boundaries/b637/observations.tgz')
blob=subprocess.check_output(['git','show','HEAD:'+canonical.as_posix()]);assert blob==canonical.read_bytes()
sha=hashlib.sha256(blob).hexdigest()
assert not any('b637' in entry['knownPath']for entry in config['retire'])
config['retire'].append(dict(knownPath='native-boundaries-b637-20261112/observations.tgz',kind='exact',knownAliases=[],bytes=len(blob),sha256=sha,canonicalStorage=canonical.as_posix()))
(r/'inventory-first.stderr').write_bytes((r/'inventory.stderr').read_bytes())
(r/'config.json').write_text(json.dumps(config,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps(dict(additionalArchivedDuplicateBytes=len(blob),sha256=sha,existingFloorsUnchanged=True)),flush=True)
