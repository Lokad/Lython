class Reader:
    def wanted(self,value,/,prefix='A',*,suffix='!'):
        return value.startswith(prefix) and value.endswith(suffix)
value=Reader();saved=value.wanted
print(saved('ABC!'),value.wanted('ABC!',suffix='?'))
Reader.wanted.__defaults__=('B',)
Reader.wanted.__kwdefaults__['suffix']='?'
print(saved('BCD?'),value.wanted('AX!',prefix='A',suffix='!'))
for bad in [lambda:saved(value='x'),lambda:saved('x',prefix='A',self=value),lambda:saved()]:
    try:bad()
    except TypeError:print('TypeError')
