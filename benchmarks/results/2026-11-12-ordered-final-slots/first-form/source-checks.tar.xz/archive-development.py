from pathlib import Path
import hashlib,json,subprocess,tarfile
r=Path(__file__).parent;target=r/'development-source-checks.tar.xz';assert not target.exists()
patch=subprocess.check_output(['git','diff','--','src/Lokad.Lython','tests'])
(r/'final-development.patch').write_bytes(patch)
# Frozen sources/cores identify the measured form. The final patch and new test
# separately include the post-freeze refusal fixture; the core did not change.
files=[p for p in r.iterdir()if p.is_file()and p.suffix in {'.py','.md','.log','.json','.patch'}]
files += [r/'baseline-sources.tar.xz',r/'candidate-sources.tar.xz',r/'candidate-core.dll']
for folder in ['compile','fresh','warm-sync','warm-async','inspection']:
    files += [p for p in (r/folder).iterdir()if p.is_file()and p.suffix in {'.cs','.csproj','.json','.log','.stderr'}]
for name in ['Program.cs','complete-jobs.csproj','packages.lock.json']:files.append(r/'tool'/name)
with tarfile.open(target,'w:xz')as t:
    for p in sorted(set(files)):t.add(p,arcname=p.relative_to(r).as_posix())
    for p in ['tests/Lokad.Lython.PublicApi.Tests/OrderedFunctionContinuationTests.cs','tests/Lokad.Lython.Tests/NativeClosureSequenceTests.cs']:
        t.add(p,arcname='final-tests/'+p)
print(json.dumps(dict(path=str(target),bytes=target.stat().st_size,sha256=hashlib.sha256(target.read_bytes()).hexdigest())),flush=True)
