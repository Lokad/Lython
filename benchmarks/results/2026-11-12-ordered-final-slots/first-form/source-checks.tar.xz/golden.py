from pathlib import Path
import json, subprocess, tempfile, textwrap, sys
r=Path(__file__).parent
text=Path('tests/Lokad.Lython.PublicApi.Tests/OrderedFunctionContinuationTests.cs').read_text(encoding='utf-8')
source=textwrap.dedent(text.split('private const string Source = """\n',1)[1].split('        """;',1)[0])
assert source.count("'/gate'")==1
with tempfile.TemporaryDirectory(prefix='lython-r289-cpython-') as temporary:
    folder=Path(temporary)
    (folder/'gate').write_text('ready',encoding='utf-8')
    adapted="payload='x'*65536\n"+source.replace("'/gate'","'gate'")
    (folder/'golden.py').write_text(adapted,encoding='utf-8',newline='\n')
    done=subprocess.run(['C:/Python313/python.exe','-I','-X','utf8','golden.py'],cwd=folder,capture_output=True,text=True,encoding='utf-8')
    record=dict(version=subprocess.check_output(['C:/Python313/python.exe','--version'],text=True).strip(),source=source,fixture="/gate -> owned temporary directory/gate; payload seeded exactly as the host global",returncode=done.returncode,stdout=done.stdout,stderr=done.stderr)
    (r/'cpython-golden.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8',newline='\n')
    assert done.returncode==0 and done.stdout=='1 k 123 65536\n',record
    print(json.dumps(record),flush=True)
