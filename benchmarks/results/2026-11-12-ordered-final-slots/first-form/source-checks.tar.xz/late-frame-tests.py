from pathlib import Path
import hashlib,json,os,subprocess,sys
r=Path(__file__).parent;identity=json.loads((r/'candidate-identity.json').read_text(encoding='utf-8'))
assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==h for p,h in identity['sources'].items())
assert hashlib.sha256(Path('src/Lokad.Lython/bin/Release/net11.0/Lokad.Lython.dll').read_bytes()).hexdigest()==identity['coreSHA256']
sdk=Path('C:/Users/JoannesVermorel/.dotnet11');env=os.environ.copy();env['DOTNET_ROOT']=str(sdk);env['PATH']=str(sdk)+';C:/Python313;'+env['PATH']
for framework in ['net11.0','net10.0']:
    log=r/f'late-frame-{framework}-{sys.argv[1]}.log';assert not log.exists()
    with log.open('w',encoding='utf-8',newline='\n')as stream:done=subprocess.run([str(sdk/'dotnet.exe'),'test','tests/Lokad.Lython.Tests/Lokad.Lython.Tests.csproj','-c','Release','-f',framework,'--no-build','--filter','FullyQualifiedName~NativeClosureSequenceTests'],env=env,stdout=stream,stderr=subprocess.STDOUT)
    print(log.read_text(encoding='utf-8')[-8000:],flush=True)
    assert done.returncode==0
