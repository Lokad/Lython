from pathlib import Path
import os,subprocess,sys
r=Path(__file__).parent;sdk=Path('C:/Users/JoannesVermorel/.dotnet11');env=os.environ.copy();env['DOTNET_ROOT']=str(sdk);env['PATH']=str(sdk)+';C:/Python313;'+env['PATH']
label=sys.argv[1] if len(sys.argv)>1 else 'build-core'
project='src/Lokad.Lython/Lokad.Lython.csproj' if label=='build-core' else 'Lokad.Lython.slnx'
args=[str(sdk/'dotnet.exe'),'build',project,'-c','Release']+(['-f','net11.0'] if label=='build-core' else [])
with(r/(label+'.log')).open('w',encoding='utf-8',newline='\n') as output:done=subprocess.run(args,env=env,stdout=output,stderr=subprocess.STDOUT)
print((r/(label+'.log')).read_text(encoding='utf-8')[-14000:]);sys.exit(done.returncode)
