from pathlib import Path
import json,subprocess
r=Path(__file__).parent
baseline=json.loads((r/'baseline.json').read_text(encoding='utf-8'))
identity=json.loads((r/'candidate-identity.json').read_text(encoding='utf-8'))
names=subprocess.check_output(['git','ls-files','--cached','--others','--exclude-standard','src/Lokad.Lython'],text=True).splitlines()
removed=[p for p in names if not Path(p).exists()]
changes=[]
for name in names:
    if not name.endswith('.cs'):continue
    before=subprocess.run(['git','show','HEAD:'+name],capture_output=True)
    prior=before.stdout.decode('utf-8')if before.returncode==0 else ''
    after=Path(name).read_text(encoding='utf-8')if Path(name).exists()else ''
    if before.returncode or prior.replace('\r\n','\n')!=after.replace('\r\n','\n'):
        changes.append(dict(path=name,beforeLines=len(prior.splitlines()),afterLines=len(after.splitlines())))
record=dict(productionFiles=len(identity['sources']),csharpFiles=sum(p.endswith('.cs')for p in identity['sources']),removed=removed,changed=changes,netSourceLines=sum(row['afterLines']-row['beforeLines']for row in changes),completionDebt=['unused NativeInput/NativeArgumentSource from discarded graph','speculative shape inputs and stale proof comments','preserve existing record-key cache selection if refinement is justified'],noOldGraphSymbolsInSource=True)
for name in identity['sources']:
    text=Path(name).read_text(encoding='utf-8')
    assert not any(token in text for token in ['GuardNativeBody','NativeReturnValue','TryExecuteWithoutFrame'])
(r/'source-audit.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps(record),flush=True)
