from pathlib import Path
import hashlib,json,subprocess,tarfile
r=Path(__file__).parent
assert not subprocess.check_output(['git','diff','--','src','tests'],text=True).strip()
paths=subprocess.check_output(['git','ls-files','src/Lokad.Lython'],text=True).splitlines()
with tarfile.open(r/'baseline-sources.tar.xz','w:xz') as t:
    for name in paths:t.add(name,arcname=name)
(r/'baseline.json').write_text(json.dumps(dict(head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),sources={n:hashlib.sha256(Path(n).read_bytes()).hexdigest() for n in paths}),indent=2)+'\n',encoding='utf-8',newline='\n')
p=Path('PLAN.md');s=p.read_text(encoding='utf-8')
s=s.replace('1. **Next substantial call/return milestone: ordered state design.**','1. **R289 active coherent migration: ordered native execution over final slots.**')
marker='2. **Other roadmap axes'
idx=s.index(marker)
s=s[:idx]+'''   - Selected implementation replaces native tree preparation/proof/recursive
     evaluation with a bounded managed span over the final physical slot/PC layout.
     Each actual operation checks its current operands. On a dynamic operation,
     transfer live slots and the current PC into the existing executable frame;
     callbacks reuse owned workspace and direct entries admit it before transfer.
     The existing caller trampoline owns actual suspension and joined cleanup.
     Bind/default evaluation happens once; no caller packet/controller or replay.
   - Required deletion: ExecutableScript.NativeReturns, ExecutableNativeBody and
     NativeReturnValue, whole-body guard traversal and recursive evaluation. Keep
     shared primitive facts with real callers. Replace the false-before-effects
     native-call handshake with completed/prepared-frame outcomes; preserve all
     semantic/refusal assertions while removing node-layout-only test assertions.
   - This differs from R268's slower large generic prefix: a small ordered kernel
     uses final operand layout directly and removes the separate graph. Native
     fast-helper regressions remain possible. Do not call it a retained simplification
     until all old machinery is removed, focused tests and complete-script controls
     pass and measured debt is decided. Refine or withdraw the complete migration.
     No CPU prediction, new public option, unsafe code or replacement resource policy.

'''+s[idx:]
s=s.replace('| Latest bounded experiment |','| Active prototype | R289 ordered native/ordinary state handoff; source migration beginning, not compiled, measured or qualified. |\n| Latest bounded experiment |')
p.write_text(s,encoding='utf-8',newline='\n')
native=Path('src/Lokad.Lython/Runtime/LythonRuntime.Executable.NativeReturn.cs').read_text(encoding='utf-8')
start=native.index('    internal enum NativeReturnShape');end=native.index('    private static bool TryReadNativeInput',start)
facts=native[start:end].replace('NativeReturnShape','NativeValueShape')
Path('src/Lokad.Lython/Runtime/LythonRuntime.Executable.NativeFacts.cs').write_text('using System.Numerics;\nusing Lokad.Lython.Frontend;\nusing Lokad.Lython.Runtime.Text;\n\nnamespace Lokad.Lython.Runtime;\n\ninternal sealed partial class LythonRuntime\n{\n    internal enum NativeStringOperation { Split, Replace, StartsWith, EndsWith }\n\n'+facts+'}\n',encoding='utf-8',newline='\n')
for name in ['src/Lokad.Lython/Frontend/ExecutableScript.NativeReturns.cs','src/Lokad.Lython/Frontend/ExecutableNativeBody.cs','src/Lokad.Lython/Runtime/LythonRuntime.Executable.NativeReturn.cs']:
    p=Path(name).resolve();assert p.is_relative_to(Path.cwd().resolve());p.unlink()
for name in ['src/Lokad.Lython/Runtime/LythonRuntime.Executable.NativeCalls.cs','src/Lokad.Lython/Runtime/LythonRuntime.Executable.Calls.Invoke.cs']:
    p=Path(name);s=p.read_text(encoding='utf-8').replace('NativeReturnOperation','NativeStringOperation').replace('NativeReturnShape','NativeValueShape');p.write_text(s,encoding='utf-8',newline='\n')
p=Path('src/Lokad.Lython/Frontend/ExecutableScript.cs');s=p.read_text(encoding='utf-8').replace('        NativeBody = PrepareNativeBody(blocks, entryBlockIndex, exceptionRegions.Count, callSites);\n','')
s=s.replace('        EntryIndex = offsets[entryBlockIndex];','        EntryIndex = offsets[entryBlockIndex];\n        CanInlineInstructions = IsFunctionScope && !RequiresLocalVariableMirroring && capturedLocalSlots.Count == 0\n            && exceptionRegions.Count == 0 && ValueStorageCapacity <= LythonRuntime.NativeValueCapacity\n            && Instructions.All(IsInlineInstruction);')
s=s.replace('    public ExecutableNativeBody? NativeBody { get; }','''    public bool CanInlineInstructions { get; }

    private static bool IsInlineInstruction(ExecutableInstruction instruction) => instruction.OpCode is
        ExecutableOpCode.LoadConst or ExecutableOpCode.LoadLocal or ExecutableOpCode.LoadGlobal
        or ExecutableOpCode.LoadClosure or ExecutableOpCode.StoreLocal or ExecutableOpCode.StoreClosure
        or ExecutableOpCode.LoadCallMember or ExecutableOpCode.Call or ExecutableOpCode.Unary
        or ExecutableOpCode.Binary or ExecutableOpCode.Augmented or ExecutableOpCode.Subscript
        or ExecutableOpCode.CompareJumpIfFalse or ExecutableOpCode.Jump or ExecutableOpCode.JumpIfFalse
        or ExecutableOpCode.MakeList or ExecutableOpCode.MakeTuple or ExecutableOpCode.Return
        or ExecutableOpCode.ReturnNone or ExecutableOpCode.Complete or ExecutableOpCode.Dup or ExecutableOpCode.PopTop;''')
# Loops stay with the existing ordinary engine. Native spans never grow or survive I/O.
s=s.replace('            && Instructions.All(IsInlineInstruction);','            && Instructions.All(IsInlineInstruction)\n            && !Instructions.Where((instruction, index) => instruction.OpCode is ExecutableOpCode.Jump\n                or ExecutableOpCode.JumpIfFalse or ExecutableOpCode.CompareJumpIfFalse\n                && instruction.TargetIndex <= index).Any();')
p.write_text(s,encoding='utf-8',newline='\n')
print('Ignored plan updated; obsolete graph/proof files removed. Ordered prefix and handoff wiring in progress.')
