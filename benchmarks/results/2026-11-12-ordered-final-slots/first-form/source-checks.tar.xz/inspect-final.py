from pathlib import Path
import json,os,shutil,subprocess
r=Path(__file__).parent;out=r/'inspection';out.mkdir()
old=r.parent/'complete-helper-r288'
for name in ['inspect.csproj','packages.lock.json']:shutil.copyfile(old/name,out/name)
source=(old/'Program.cs').read_text(encoding='utf-8').replace('nativeBody = Read(code, "NativeBody") is not null,','nativeBody = Read(code, "NativeBody") is not null, inlineFinalSlots = Read(code, "CanInlineInstructions"),')
(out/'Program.cs').write_text(source,encoding='utf-8',newline='\n')
sdk=Path('C:/Users/JoannesVermorel/.dotnet11');env=os.environ.copy();env['DOTNET_ROOT']=str(sdk);env['PATH']=str(sdk)+';C:/Python313;'+env['PATH']
with(out/'build.log').open('w',encoding='utf-8',newline='\n')as log:done=subprocess.run([str(sdk/'dotnet.exe'),'build',str(out/'inspect.csproj'),'-c','Release','--no-incremental'],env=env,stdout=log,stderr=subprocess.STDOUT)
assert done.returncode==0
for role in ['reference','candidate']:
    with(out/f'{role}.json').open('w',encoding='utf-8',newline='\n')as stream,(out/f'{role}.stderr').open('w',encoding='utf-8',newline='\n')as errors:
        done=subprocess.run([str(sdk/'dotnet.exe'),str(out/'bin/Release/net11.0/inspect.dll'),str(r/role/'Lokad.Lython.dll'),str(r/'catalog.json')],env=env,stdout=stream,stderr=errors)
    assert done.returncode==0,(out/f'{role}.stderr').read_text(encoding='utf-8')
    data=json.loads((out/f'{role}.json').read_text(encoding='utf-8'))
    for case in data['facts']:
        print(role,case['caseId'],[(item['path'],item['nativeBody'],item['inlineFinalSlots'])for item in case['functions']if item['path']!='module'],flush=True)
