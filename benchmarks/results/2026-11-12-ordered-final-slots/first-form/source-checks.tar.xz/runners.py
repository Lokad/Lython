from pathlib import Path
p=Path('src/Lokad.Lython/Runtime/LythonRuntime.Executable.cs');s=p.read_text(encoding='utf-8')
old='''            // Even a zero-local module has live operands during calls. Publish
            // the same existing frame that the async entry publishes; local
            // slot counts do not determine whether an invocation is active.
            context.EnterExecutableSlots();
            context.Execute();
            return context.HasFrameReturn ? context.FrameReturnValue : null;'''
assert old in s;s=s.replace(old,'            return ExecuteInitializedFrame(context);')
s=s.replace('''            context.EnterExecutableSlots();
            await context.ExecuteAsync().ConfigureAwait(false);
            return context.HasFrameReturn ? context.FrameReturnValue : null;''','            return await ExecuteInitializedFrameAsync(context).ConfigureAwait(false);')
# The shared initialized runner owns frame visibility and detachment. The outer
# entries retain only their own admission cleanup, including initialization faults.
s=s.replace('''            context.LeaveExecutableSlots();
            context.DetachExecutableExecution();
            if (ownsAdmission) context.LeaveInterpreterFrame();''','''            if (ownsAdmission) context.LeaveInterpreterFrame();''')
marker='    private static void InitializeExecutableFrame('
assert marker in s
s=s.replace(marker,'''    internal static object? ExecuteInitializedFrame(ExecutionContext context)
    {
        try
        {
            context.EnterExecutableSlots();
            context.Execute();
            return context.HasFrameReturn ? context.FrameReturnValue : null;
        }
        finally { context.LeaveExecutableSlots(); context.DetachExecutableExecution(); }
    }

    internal static async ValueTask<object?> ExecuteInitializedFrameAsync(ExecutionContext context)
    {
        try
        {
            context.EnterExecutableSlots();
            await context.ExecuteAsync().ConfigureAwait(false);
            return context.HasFrameReturn ? context.FrameReturnValue : null;
        }
        finally { context.LeaveExecutableSlots(); context.DetachExecutableExecution(); }
    }

'''+marker)
p.write_text(s,encoding='utf-8',newline='\n')
p=Path('src/Lokad.Lython/Runtime/LythonRuntime.Executable.Calls.Invoke.cs');s=p.read_text(encoding='utf-8').replace('CallCompletion.Call, scope.MemoryGovernor);','CallCompletion.Call, function.DefinitionContext.MemoryGovernor);');p.write_text(s,encoding='utf-8',newline='\n')
# Metadata assertions identify the intended branch; operation-node layout itself
# is no longer an architecture contract. Independent semantic assertions stay.
for name in ['NativeFunctionRefundTests.cs','NativeClosureSequenceTests.cs','SimpleFunctionExecutionBoundaryTests.cs']:
    p=Path('tests/Lokad.Lython.Tests')/name;s=p.read_text(encoding='utf-8')
    s=s.replace('Assert.NotNull(function.CodeObject.NativeBody);','Assert.True(function.CodeObject.CanInlineInstructions);')
    s=s.replace('Assert.NotNull(Function.CodeObject.NativeBody);','Assert.True(Function.CodeObject.CanInlineInstructions);')
    s=s.replace('            Assert.Contains(Function.CodeObject.NativeBody.Values, value => value.Operation == NativeReturnOperation.StoreClosure);\n','')
    p.write_text(s,encoding='utf-8',newline='\n')
print('Shared initialized runner replaces duplicated body drivers; node-layout assertion removed, semantic assertions retained.')
