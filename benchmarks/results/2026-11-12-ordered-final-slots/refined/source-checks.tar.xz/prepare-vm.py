from pathlib import Path
import ast,hashlib,io,json,shutil,subprocess,tarfile
r=Path(__file__).parent;out=r/'b644';old=r.parent.parent/'inline-tuples-r287/corrected/b642'
oldroot='/home/lokad/lython-bench-checks/inline-tuples-b642-20261112';root='/home/lokad/lython-bench-checks/ordered-native-b644-20261112'
oldunit='lython-b642-inline-tuples-20261112';unit='lython-b644-ordered-native-20261112'
identity=json.loads((r/'candidate-identity.json').read_text(encoding='utf-8'))
assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==h for p,h in identity['sources'].items())
for framework in ['net11.0','net10.0']:
    for suite,count in [('internal',1340),('public',303)]:
        text=(r.parent/f'focused-{suite}-{framework}-refined-final.log').read_text(encoding='utf-8');assert 'Failed:     0' in text and str(count) in text
for phase in ['compile','fresh','warm-sync','warm-async']:
    data=json.loads((r/phase/'stdout.json').read_text(encoding='utf-8'));assert data['allGoldensPassed'] and data['allBalancesZero'] and data['ownedFixturesRemoved']
out.mkdir()
config=json.loads((old/'config.json').read_text(encoding='utf-8'));config.update(root=root,unit=unit)
config['identity'].update(sourceRevision=identity['head']+'; R289 refined final-slot execution; shared record cache/one span exit/obsolete shape and argument wrapper removal;3286focused actual-target checks; all seven scripts/both APIs/compile/fresh',coreSHA256={k:identity['referenceSHA256' if k.startswith('reference') else 'coreSHA256']for k in ['reference','reference-control','candidate','candidate-control']})
jobs=[['scripts.csv-validated-records.large','warm'],['scripts.csv-validated-records.large','warm-async'],['scripts.file-search.large','warm'],['scripts.file-search.guarded-helper.large','warm'],['scripts.text-summary-helpers.nonlocal-counter.large','warm'],['scripts.report-render.large','warm']]
collect=(old/'collect.py').read_text(encoding='utf-8').replace(oldroot,root)
start=collect.index('jobs=');end=collect.index('\nenv = ',start)
collect=collect[:start]+'jobs='+repr(jobs)+"\nassert len(jobs)==6 and all(case in cases for case,lane in jobs)\n"+collect[end:]
collect=collect.replace("purpose='R287 corrected ordinary tuple storage; CSV both APIs, adverse UTF16 and UTF8 report controls; preserve all original/failing/refined conditions.'","purpose='R289 replaces native tree/proof/recursive evaluation with final-slot ordered execution and exact-PC ordinary transfer; CSV both APIs, native/guarded/captured helpers and report control; retain all adversity.'")
collect=collect.replace("time.monotonic()-started < 310, 'Reserve50seconds", "time.monotonic()-started < 360, 'Reserve60seconds")
ast.parse(collect);(out/'collect.py').write_text(collect,encoding='utf-8',newline='\n')
for name in ['archive-owned.py','run.sh','remote-launch.py','launch.py','retrieve.py','summarize.py']:
    text=(old/name).read_text(encoding='utf-8').replace(oldroot,root).replace(oldunit,unit)
    for a,b in [("len(raw['jobs'])==4","len(raw['jobs'])==6"),('jobs=4','jobs=6'),("['jobs']==4","['jobs']==6"),("'jobs': 4","'jobs': 6"),('RuntimeMaxSec=300','RuntimeMaxSec=420'),('ownerSeconds=300','ownerSeconds=420'),('seconds=360','seconds=480'),("'ownerSeconds': 300","'ownerSeconds': 420"),("elapsedSeconds']<360","elapsedSeconds']<480"),('lython-b642-fixtures','lython-b644-fixtures'),('inline-tuples-b642-launch.py','ordered-native-b644-launch.py'),('B642 four-job','B644 six-job')]:text=text.replace(a,b)
    if name.endswith('.py'):ast.parse(text.replace('config=CONFIG','config={}').replace('inventoryOnly=INVENTORY_ONLY','inventoryOnly=True'))
    (out/name).write_text(text,encoding='utf-8',newline='\n')
for source,target in [(r/'candidate-core.dll',out/'current-core.dll'),(r/'candidate-identity.json',out/'source-identity.json'),(r/'candidate-sources.tar.xz',out/'candidate-sources.tar.xz'),(r/'catalog.json',out/'representative.json')]:shutil.copyfile(source,target)
canonical=Path('benchmarks/results/2026-11-12-ordered-final-slots/first-form/observations.tgz')
blob=subprocess.check_output(['git','show','HEAD:'+canonical.as_posix()]);assert blob==canonical.read_bytes()
archivehash=hashlib.sha256(blob).hexdigest();assert archivehash=='8e407674e73c2daeb64843363197196f34b914cf7bfb847ca65d878acaa888b5'
specs=[]
with tarfile.open(fileobj=io.BytesIO(blob))as t:
    for name,kind,aliases in [('current-core.dll','withdrawn-image',['current-core.dll','candidate/Lokad.Lython.dll']),('candidate-sources.tar.xz','exact',[])]:
        content=t.extractfile(name).read();digest=hashlib.sha256(content).hexdigest()
        if name=='current-core.dll':assert digest=='c8d0a5154ea3dee3b9d4280c4acd2a98178c88b7272e78923470c75034af5bd2'
        prefix='ordered-native-b643-20261112/'
        specs.append(dict(knownPath=prefix+name,kind=kind,knownAliases=[prefix+a for a in aliases],bytes=len(content),sha256=digest,canonicalStorage=canonical.as_posix()+'!'+name,canonicalArchiveSHA256=archivehash))
specs.append(dict(knownPath='ordered-native-b643-20261112/observations.tgz',kind='exact',knownAliases=[],bytes=len(blob),sha256=archivehash,canonicalStorage=canonical.as_posix()))
extra=Path('benchmarks/results/2026-11-12-native-accumulation-boundaries/b636/observations.tgz')
extraBytes=subprocess.check_output(['git','show','HEAD:'+extra.as_posix()]);assert extraBytes==extra.read_bytes()
specs.append(dict(knownPath='native-boundaries-b636-20261112/observations.tgz',kind='exact',knownAliases=[],bytes=len(extraBytes),sha256=hashlib.sha256(extraBytes).hexdigest(),canonicalStorage=extra.as_posix()))
config['retire']=specs
(out/'identity.json').write_text(json.dumps(config['identity'],indent=2)+'\n',encoding='utf-8',newline='\n')
with tarfile.open(out/'payload.tgz','w:gz')as t:
    for name in ['collect.py','archive-owned.py','run.sh','current-core.dll','source-identity.json','candidate-sources.tar.xz','representative.json','identity.json']:t.add(out/name,arcname=name)
config.update(payloadBytes=(out/'payload.tgz').stat().st_size,payloadSHA256=hashlib.sha256((out/'payload.tgz').read_bytes()).hexdigest())
(out/'config.json').write_text(json.dumps(config,indent=2)+'\n',encoding='utf-8',newline='\n')
print('Six existing complete-script jobs;420s owner/30s stop/30s margin; existing OS240MiB/evidence12MiB floors; exact committed withdrawn-image duplicates only.',flush=True)
