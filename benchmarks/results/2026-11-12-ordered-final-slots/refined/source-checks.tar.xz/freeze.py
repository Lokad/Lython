from pathlib import Path
import hashlib,json,os,shutil,subprocess,tarfile
r=Path(__file__).parent;old=r.parent.parent/'lexical-cell-storage-r284';digest=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
names=subprocess.check_output(['git','ls-files','--cached','--others','--exclude-standard','src/Lokad.Lython'],text=True).splitlines()
source={name:digest(Path(name))for name in names if Path(name).is_file()}
for framework in ['net11.0','net10.0']:
    for suite in ['internal','public']:
        log=(r.parent/f'focused-{suite}-{framework}-refined-final.log').read_text(encoding='utf-8')
        assert 'Failed:     0' in log and 'Passed!' in log
for name in ['reference','candidate']:
    assert not(r/name).exists();shutil.copytree(old/'reference',r/name,copy_function=os.link)
assert digest(r/'reference/Lokad.Lython.dll')=='e4cc65b251ace242546f337b0846908a4e2a4313953da74df6fb666e1ce87529'
(r/'candidate/Lokad.Lython.dll').unlink();shutil.copyfile('src/Lokad.Lython/bin/Release/net11.0/Lokad.Lython.dll',r/'candidate/Lokad.Lython.dll')
for name,folder in [('before-core.dll','reference'),('candidate-core.dll','candidate')]:shutil.copyfile(r/folder/'Lokad.Lython.dll',r/name)
with tarfile.open(r/'candidate-sources.tar.xz','w:xz')as t:
    for p in source:t.add(p,arcname=p)
(r/'candidate-identity.json').write_text(json.dumps(dict(head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()+' plus R289 uncommitted',sources=source,coreSHA256=digest(r/'candidate-core.dll'),referenceSHA256=digest(r/'before-core.dll'),removed=['Frontend/ExecutableNativeBody.cs','Frontend/ExecutableScript.NativeReturns.cs','Runtime/LythonRuntime.Executable.NativeReturn.cs','ExecutableCallArgument wrapper/speculative native shapes']),indent=2)+'\n',encoding='utf-8',newline='\n')
shutil.copyfile(old/'catalog.json',r/'catalog.json');tool=r/'tool';tool.mkdir()
for name in ['complete-jobs.csproj','packages.lock.json']:shutil.copyfile(old/'tool'/name,tool/name)
code=(old/'tool/Program.cs').read_text(encoding='utf-8').replace('R284 explicit lexical cell locations; permanent owner, shadow value and repeated mode selection removed;','R289 refined ordered final slots; native graph/proof/shape and argument-wrapper metadata removed; record caches preserved; private span tail cleared only at transfer;')
code=code.replace('var nodeType = Core.GetType("Lokad.Lython.Frontend.NativeReturnValue", true)!;','var nodeType = Core.GetType("Lokad.Lython.Frontend.NativeReturnValue", false);\n        if (nodeType is null) NativeNodeStorage = new { removed = true, nativeGraph = false, outsideGuestClocks = true };\n        else\n        {')
end='cellConstruction = MeasureCells(Core.GetType("Lokad.Lython.Runtime.LythonRuntime+ExecutableCell", true)!) };'
assert end in code;code=code.replace(end,end+'\n        }')
(tool/'Program.cs').write_text(code,encoding='utf-8',newline='\n')
env=os.environ.copy();sdk=Path('C:/Users/JoannesVermorel/.dotnet11');env['DOTNET_ROOT']=str(sdk);env['PATH']=str(sdk)+';C:/Python313;'+env['PATH']
with(r/'build-driver.log').open('w',encoding='utf-8',newline='\n')as log:done=subprocess.run([str(sdk/'dotnet.exe'),'build',str(tool/'complete-jobs.csproj'),'-c','Release','-f','net11.0','--no-incremental'],env=env,stdout=log,stderr=subprocess.STDOUT)
assert done.returncode==0,(r/'build-driver.log').read_text(encoding='utf-8')
assert all(digest(Path(p))==h for p,h in source.items())
for name in ['diagnostic.py','run-diagnostics.py','summarize.py']:shutil.copyfile(old/name,r/name)
(r/'implementation.patch').write_bytes(subprocess.check_output(['git','diff','--','src/Lokad.Lython','tests']))
print(json.dumps(dict(sources=len(source),core=digest(r/'candidate-core.dll'))),flush=True)
subprocess.run(['python','-X','utf8',str(r/'run-diagnostics.py')],check=True)
