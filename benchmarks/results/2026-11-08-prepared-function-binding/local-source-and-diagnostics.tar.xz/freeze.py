from pathlib import Path
import hashlib,json,shutil,subprocess
r=Path(__file__).parent;previous=r.parent/'function-lookup-lifetime-r121'
assert not(r/'identity.json').exists()
paths=[Path(p)/'bin/Release/net11.0/Lokad.Lython.dll'for p in ['src/Lokad.Lython','tests/Lokad.Lython.Tests','tests/Lokad.Lython.PublicApi.Tests']]
assert len({hashlib.sha256(p.read_bytes()).hexdigest()for p in paths})==1
images=r/'images-verified'
for name in ['before','candidate']:shutil.copytree(previous/'refined/images/candidate',images/name)
assert hashlib.sha256((images/'before/Lokad.Lython.dll').read_bytes()).hexdigest()=='c6172fec19b0fd8d36ba5eba0046ac66578646ba3714f5f7bed99501619ff0bd'
shutil.copyfile(paths[0],images/'candidate/Lokad.Lython.dll')
catalog=json.loads((r.parent/'function-cpython-r122/representative.json').read_text(encoding='utf8'))
ids=['scripts.csv-validated-records.large','scripts.csv-summary-functions.large','scripts.text-summary-helpers.large','scripts.json-summary-helpers.large','scripts.report-render.large']
catalog['cases']=[next(c for c in catalog['cases']if c['id']==key)for key in ids]
(r/'catalog.json').write_text(json.dumps(catalog,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
for name in ['measure.py','assess-local.py','compile-diagnostic.py']:
 s=(previous/name).read_text(encoding='utf8')
 s=s.replace('images/before/','images-verified/before/').replace('images/candidate/','images-verified/candidate/')
 if name=='assess-local.py':
  at=s.index("out['limitations']=");end=s.index("\n(r/'assessment-local",at)
  s=s[:at]+"out['limitations']='R124 compile-owned immutable-layout-guarded argument positions and shared canonical default completion. Qualified d97/runtime6f76/corec617 reference. Current source focused Release actual11:39public/78internal. Five unchanged primary scripts, same frozen7cf/optional0.4, normalGC/tiering, public Run/awaitedRunAsync/fullgoldens/balances/cleanup. WarmRun clocks, allocation includes reset/validation/prior-result cleanup. Shared CoreLib/process GC and desktop controls limit elapsed evidence. Compile separate; no full candidate qualification or CPU improvement claim.'"+s[end:]
 (r/name).write_text(s,encoding='utf8')
files=subprocess.check_output(['git','ls-files','src'],text=True).splitlines()
i=dict(baseline='Fully qualified d97/runtime6f76/corec617, cached CI42527042378; no requery',
 candidate='Working R124 prototype after20cf17f8; compiler-owned slot facts/no runtime cache, shared default completion/deletion',
 productionSources={p:hashlib.sha256(Path(p).read_bytes()).hexdigest()for p in files},
 coreSHA256={name:hashlib.sha256((images/name/'Lokad.Lython.dll').read_bytes()).hexdigest()for name in ['before','candidate']},
 auxiliaryFiles={p.name:hashlib.sha256(p.read_bytes()).hexdigest()for p in (images/'before').glob('*.dll')if p.name!='Lokad.Lython.dll'},
 qualification='39public/78internal Releaseactual11; actual10/full platform/stress/package pending coherent retention boundary, no publication',
 limitations='Initial cases/focused core preserved separately. New compiler metadata/compile cost measured; no per-call owner or cache. Current function defaults remain live, general dynamic binding preserved.')
(r/'identity.json').write_text(json.dumps(i,indent=2)+'\n',encoding='utf8')
(r/'source.patch').write_bytes(subprocess.check_output(['git','diff','--','src','tests']))
shutil.copyfile('tests/Lokad.Lython.PublicApi.Tests/PreparedFunctionBindingTests.cs',r/'PreparedFunctionBindingTests.cs')
shutil.copyfile('PLAN.md',r/'pre-measurement-plan.md')
print('Frozen R124',i['coreSHA256'])
