from pathlib import Path
import json,subprocess
r=Path(__file__).parent;notes=r.parent.parent
assert json.loads((r/'archive-receipt.json').read_text(encoding='utf8'))['allWorkersJoined']
command=(notes/'function-cpython-r122/space-post-audit-command.py').read_text(encoding='utf8')
command=command.replace('.r122-identical-link','.r124-identical-link').replace('r122-dedup-post-audit.json','r124-post-confirmation-audit.json')
command=command.replace("originalFailure='Optional dedup EPERM, launch separately passed complete space preflight; no historical file changes during audit'", "preparation='Fresh idle-lease recovery of two permitted-canonical identical inodes; all paths/hashes preserved'")
command=command.replace('proof=dict(readOnlyAudit=True',"proof=dict(persistedPreMutationPlan=json.loads((base/'r124-identical-core-plan.json').read_text()),readOnlyAudit=True")
(r/'space-post-audit-command.py').write_text(command,encoding='utf8')
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
done=subprocess.run(ssh+['python3 -'],input=command.encode(),capture_output=True)
(r/'space-post-audit.stdout').write_bytes(done.stdout);(r/'space-post-audit.stderr').write_bytes(done.stderr)
assert done.returncode==0,done.stderr.decode();proof=json.loads(done.stdout)
assert proof['allKnownPathsAndBytesPreserved']and not proof['temporaryLinks']
(r/'space-post-audit.json').write_text(json.dumps(proof,indent=2)+'\n',encoding='utf8')
print('Fresh after-collection audit17original paths/hashes preserved, zero temporary links; pre-mutation plan retrieved.')
