from pathlib import Path
import json,subprocess
r=Path(__file__).parent;notes=r.parent.parent
known=json.loads((notes/'function-cpython-r122/space-post-audit.json').read_text(encoding='utf8'))['aliases']
required=json.loads((r/'space-required.json').read_text(encoding='utf8'))['requiredFreeBytesBeforeExtraction']
remote='''from pathlib import Path
import fcntl,hashlib,json,os,shutil,subprocess
base=Path('/home/lokad/lython-bench-checks').resolve();known=KNOWN;required=REQUIRED
with(base/'comparison-vm.lock').open('a')as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[c]ollector.dll|[p]erf record'],capture_output=True).returncode==1
 aliases=[]
 for prior in known:
  p=Path(prior['path']).resolve();assert base in p.parents
  st=p.stat();assert hashlib.sha256(p.read_bytes()).hexdigest()==prior['sha256']
  if not any(x['path']==str(p)for x in aliases):aliases.append(dict(path=str(p),sha256=prior['sha256'],inode=st.st_ino,bytes=st.st_size,allocatedBytes=st.st_blocks*512,links=st.st_nlink,uid=st.st_uid,parentWritable=os.access(p.parent,os.W_OK)))
 before=shutil.disk_usage(base).free;selected=[];saved=0;used=set()
 for canonical in aliases:
  if before+saved>=required+1024*1024:break
  if canonical['uid']!=os.getuid()or not canonical['parentWritable']or canonical['inode']in used:continue
  for row in aliases:
   if before+saved>=required+1024*1024:break
   paths=[x for x in aliases if x['inode']==row['inode']]
   if row['sha256']==canonical['sha256']and row['inode']!=canonical['inode']and row['inode']not in used and len(paths)==row['links']and all(x['parentWritable']and x['uid']==os.getuid()for x in paths):
    selected.append(dict(canonical=canonical,paths=paths));saved+=row['allocatedBytes'];used.add(row['inode'])
 assert len(selected)<=3 and saved<=20*1024*1024 and before+saved>=required+1024*1024,(before,saved,required)
 plan=base/'r124-identical-core-plan.json';assert not plan.exists()
 plan.write_text(json.dumps(dict(beforeFreeBytes=before,requiredFreeBytes=required,freshAliases=aliases,selected=selected),indent=2)+'\\n')
 for group in selected:
  canonical=Path(group['canonical']['path'])
  for row in [group['canonical'],*group['paths']]:
   p=Path(row['path']);assert p.stat().st_ino==row['inode']and hashlib.sha256(p.read_bytes()).hexdigest()==row['sha256']
  for row in group['paths']:
   p=Path(row['path']);temporary=p.with_name(p.name+'.r124-identical-link');assert not temporary.exists()
   os.link(canonical,temporary);os.replace(temporary,p)
 for row in known:
  p=Path(row['path']);assert hashlib.sha256(p.read_bytes()).hexdigest()==row['sha256']and not p.resolve().with_name(p.name+'.r124-identical-link').exists()
 receipt=dict(beforeFreeBytes=before,afterFreeBytes=shutil.disk_usage(base).free,requiredFreeBytes=required,selected=selected,all17PathsAndHashesPreserved=True,archivesUntouched=True,planPersistedBeforeMutation=True,allDisplacedInodeAliasesVerified=True)
 assert receipt['afterFreeBytes']>required
 (base/'r124-identical-core-receipt.json').write_text(json.dumps(receipt,indent=2)+'\\n');print(json.dumps(receipt))
'''.replace('KNOWN',repr(known)).replace('REQUIRED',str(required))
compile(remote,'fresh-space','exec');(r/'space-command.py').write_text(remote,encoding='utf8')
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
done=subprocess.run(ssh+['python3 -'],input=remote.encode(),capture_output=True);(r/'space.stdout').write_bytes(done.stdout);(r/'space.stderr').write_bytes(done.stderr)
assert done.returncode==0,done.stderr.decode();receipt=json.loads(done.stdout)
(r/'dedup-proof.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf8')
print('Fresh exact-byte recovery',receipt['afterFreeBytes']-receipt['beforeFreeBytes'],'bytes;',len(receipt['selected']),'duplicate inodes; all17paths/hashes preserved.')
