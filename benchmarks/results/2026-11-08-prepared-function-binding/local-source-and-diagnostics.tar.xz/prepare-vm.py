from pathlib import Path
import ast,hashlib,json,shutil,tarfile
r=Path(__file__).parent;old=r.parent/'function-lookup-lifetime-r121/b480';out=r/'b483';out.mkdir()
i=json.loads((r/'identity.json').read_text(encoding='utf8'))
assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==h for p,h in i['productionSources'].items())
jobs=[['scripts.csv-validated-records.large','warm'],['scripts.report-render.large','warm'],['scripts.csv-summary-functions.large','warm'],['scripts.text-summary-helpers.large','warm-async']]
identity=dict(sourceRevision='R124 working prototype after20cf17f8, compiler-owned argument positions/shared default completion',
 baselineSource='Qualified d97/runtime6f76/corec617, cached CI42527042378',
 coreSHA256={name:i['coreSHA256']['before'if name.startswith('reference')else'candidate']for name in ['reference','reference-control','candidate','candidate-control']},
 auxiliaryFiles=json.loads((r.parent/'function-cpython-r122/identity.json').read_text(encoding='utf8'))['auxiliaryFiles'],productionSources=i['productionSources'],
 qualification='41public/78internal Releaseactual11 including partial protocol default actual suspension; retained boundary actual10/platform/stress/package pending',
 localDiagnostics='Warm allocations neutral, compile allocation+0.2%; elapsed controls drift and async text+6.4%adverse preserved. No speed claim. Four-role quiet confirmation, no automatic threshold veto.')
(out/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf8')
for source,name in [(r/'catalog.json','representative.json'),(r/'source.patch','source.patch'),(r/'identity.json','focused.json'),(r.parent/'function-cpython-r122/identity.json','baseline-source.json'),(r/'images-verified/candidate/Lokad.Lython.dll','current-core.dll')]:shutil.copyfile(source,out/name)
shutil.copyfile('PLAN.md',out/'pre-measurement-plan.md')
for n in ['collect.py','archive-owned.py','run.sh','launch.py','retrieve.py','assess-vm.py']:
 s=(old/n).read_text(encoding='utf8').replace('helper-confirm-b480-20261108','prepared-binding-b483-20261108').replace('lython-b480-helper-confirm','lython-b483-prepared-binding').replace('helper-confirm-b480-launch.py','prepared-binding-b483-launch.py')
 if n=='collect.py':
  a=s.index('jobs=');b=s.index('\nassert len(jobs)',a);s=s[:a]+'jobs='+repr(jobs)+s[b:]
  a=s.index("purpose='R121 bounded confirmation:");b=s.index("',\n",a);s=s[:a]+"purpose='R124 compiler-owned fixed keyword positions/shared default completion. QualifiedC617 versus workingC4bb, primary validatedCSV and report/nativeCSV/async text controls. Preserve adverse desktop+6.4percent text and drifting controls. No automatic promotion or gain claim"+s[b:]
  s=s.replace('warmupSeconds=10','warmupSeconds=5').replace('time.monotonic()+10','time.monotonic()+5').replace('time.monotonic()-started < 210','time.monotonic()-started < 150')
 if n=='launch.py':
  s=s.replace("identity['coreSHA256']['candidate']\n assert hashlib.sha256((root/'baseline-core.dll')", "identity['coreSHA256']['reference']\n os.link(reference/'Lokad.Lython.dll',root/'baseline-core.dll')\n assert hashlib.sha256((root/'baseline-core.dll')")
  s=s.replace(" os.link(reference/'Lokad.Lython.dll',root/'current-core.dll')", " assert hashlib.sha256((root/'current-core.dll').read_bytes()).hexdigest()==identity['coreSHA256']['candidate']")
  s=s.replace('ownerSeconds=240','ownerSeconds=180').replace('RuntimeMaxSec=240','RuntimeMaxSec=180').replace('seconds=300','seconds=240').replace('allEightJobsValidated=True','allFourJobsValidated=True,roles=4')
 (out/n).write_text(s,encoding='utf8',newline='\n')
 if n.endswith('.py'):ast.parse(s)
contract='''R124/B483 four-job bounded quiet comparison before retention, currentC4bb/qualifiedC617, same frozen7cf/optional0.4/host/catalog/goldens. Primary validatedCSVwarm, ordinary reportwarm, nativeCSVwarm and async textwarm controls. Compiler-owned immutable layout-guarded keyword slots, shared canonical default completion/deletion, no runtime cache/owner/policy/engine.41public/78internal actual11 pass including default protocol genuine suspension/retained result/budget reuse; full new-source qualification only at coherent retention boundary. Warm allocation neutral, compilerallocation+0.2%, desktop elapsed mixed; async text+6.4%adverse/control0.04% remains explicit. Two independent processes per source, normalGC/tiering,5swarmup/role/job/7rotated150msrounds.180sowner+30stop+30margin, last job admission<150s, live finite unit. Existing tooling, no framework/CPython ratio/new backend qualification. Warm includes invocation/mediated RAM I/O/fullgoldens/prior-resultcleanup; compile/startup/staging/reset/protocol/final cache teardown outside clocks. All source/core/aux/Ready/output/balances/quiet/Closed/join/unmount/archive/local gates. Persistent evidence/128MiBownedRAMfixtures separate,240MiBOSfloor/12MiBheadroom/roundedactualpayload preflight. If needed, only fresh idle permitted-canonical exact-byte hardlinks, all inode aliases/SHA/writable parents/persisted pre-mutation plan; no evidence deletion. No fixed improvement veto, retain all adverse/variable controls; decide remaining regression debt before delivery. Performance objective/regex independent, publication postponed.
'''
(out/'contract.md').write_text(contract,encoding='utf8')
(out/'setup-contract.json').write_text(json.dumps(dict(jobs=jobs,roles=4,ownerSeconds=180,stopSeconds=30,marginSeconds=30,evidenceHeadroomMiB=12,osFloorMiB=240),indent=2)+'\n',encoding='utf8')
(out/'sizing.json').write_text(json.dumps(dict(referenceArchiveReused=True,newCandidateBytes=(out/'current-core.dll').stat().st_size,previousFourJobArchiveBytes=(old/'observations.tgz').stat().st_size,evidenceHeadroomBytes=12*1024*1024,osFloorBytes=240*1024*1024,noEvidenceDeleted=True),indent=2)+'\n',encoding='utf8')
with tarfile.open(out/'payload.tgz','w:gz')as a:
 for n in ['current-core.dll','collect.py','archive-owned.py','run.sh','identity.json','representative.json','contract.md','source.patch','focused.json','baseline-source.json','setup-contract.json','sizing.json','pre-measurement-plan.md']:a.add(out/n,arcname=n)
with tarfile.open(out/'payload.tgz')as a:required=sum(((m.size+4095)//4096)*4096 for m in a.getmembers())+(240+12)*1024*1024
(out/'space-required.json').write_text(json.dumps(dict(requiredFreeBytesBeforeExtraction=required,roundedPayloadBytes=required-(240+12)*1024*1024),indent=2)+'\n',encoding='utf8')
with Path('PLAN.md').open('a',encoding='utf8')as f:f.write('\nR124 refined C4bb:41public/78internal actual11pass; five complete scripts bothAPIs\nallgoldens/balances/cleanup, warmalloc neutral, compileralloc+0.2%. Desktopelapsed\ncontrols unstable; async text+6.4%adverse preserved. B483 four-job quiet comparison\nprepared before retention, 180sowner/5swarmup/7rotated150ms, source/core/ownership/\narchive gates. No speed/full-qualification claim or publication.\n')
print('Prepared four-job quiet comparison, required pre-extraction bytes',required)
