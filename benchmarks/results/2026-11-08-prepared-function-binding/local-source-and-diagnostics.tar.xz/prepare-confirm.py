from pathlib import Path
import ast,hashlib,json,shutil,tarfile
r=Path(__file__).parent;old=r/'b483';out=r/'b484';out.mkdir()
receipt=json.loads((old/'archive-receipt.json').read_text(encoding='utf8'))
assert receipt['complete']and hashlib.sha256((old/'observations.tgz').read_bytes()).hexdigest()==receipt['archiveSHA256']
i=json.loads((old/'identity.json').read_text(encoding='utf8'));assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==h for p,h in i['productionSources'].items())
i['qualification']='Releaseactual11/10:41public/78internal; additional262publicactual11 and3newprepared-default suspension/cancel/refusal cases actual11 pass. Full coherent candidate delivery pending.'
i['purpose']='Bounded two-job confirmation of B483 candidate spreads/async-text adverse data; same C617/C4bb sources, no implementation refinement or erased controls.'
(out/'identity.json').write_text(json.dumps(i,indent=2)+'\n',encoding='utf8')
jobs=[['scripts.csv-validated-records.large','warm'],['scripts.text-summary-helpers.large','warm-async']]
for n in ['representative.json','source.patch','focused.json','baseline-source.json']:shutil.copyfile(old/n,out/n)
shutil.copyfile('PLAN.md',out/'pre-measurement-plan.md')
coreProof=dict(vmArchive='prepared-binding-b483-20261108/observations.tgz',archiveSHA256=receipt['archiveSHA256'],members={'current-core.dll':i['coreSHA256']['candidate'],'baseline-core.dll':i['coreSHA256']['reference']},localArtifact='b483/observations.tgz, independently verified; unchanged source/binary')
(out/'core-source.json').write_text(json.dumps(coreProof,indent=2)+'\n',encoding='utf8')
for n in ['collect.py','archive-owned.py','run.sh','launch.py','retrieve.py','assess-vm.py','space.py']:
 s=(old/n).read_text(encoding='utf8').replace('prepared-binding-b483-20261108','binding-confirm-b484-20261108').replace('lython-b483-prepared-binding','lython-b484-binding-confirm').replace('prepared-binding-b483-launch.py','binding-confirm-b484-launch.py')
 if n=='collect.py':
  a=s.index('jobs=');b=s.index('\nassert len(jobs)',a);s=s[:a]+'jobs='+repr(jobs)+s[b:]
  s=s.replace('len(jobs)==4','len(jobs)==2').replace('warmupSeconds=5','warmupSeconds=10').replace('time.monotonic()+5','time.monotonic()+10').replace('targetBatchSeconds=.15','targetBatchSeconds=.3').replace('count*.15/','count*.3/')
  a=s.index("purpose='R124 compiler-owned");b=s.index("',\n",a)
  s=s[:a]+"purpose='R124 bounded confirmation: unchangedC617/C4bb, primaryCSVvalidation and adverseasync text only, longer10swarmup/300msbatches. Preserve all B483 and desktop adverse/variable controls. No automatic acceptance threshold or gain claim"+s[b:]
 if n=='archive-owned.py':
  s=s.replace("len(r['jobs'])==4","len(r['jobs'])==2").replace('jobs=4','jobs=2')
  s=s.replace("'current-core.dll','baseline-core.dll'","'core-source.json','pre-mutation-space-plan.json'")
 if n=='launch.py':
  s=s.replace("reference=base/'function-lookups-b479-20261108/candidate'","reference=base/'prepared-binding-b483-20261108/reference'")
  marker=" assert hashlib.sha256((root/'current-core.dll').read_bytes()).hexdigest()==identity['coreSHA256']['candidate']"
  assert marker in s
  s=s.replace(marker," os.link(base/'prepared-binding-b483-20261108/candidate/Lokad.Lython.dll',root/'current-core.dll')\n"+marker)
  s=s.replace('allFourJobsValidated=True','allTwoJobsValidated=True').replace("assert len(jobs)==4 ","assert len(jobs)==2 ")
  needle=" identity=json.loads((root/'identity.json').read_text());assert set(identity['coreSHA256'])=={'reference','reference-control','candidate','candidate-control'}"
  assert needle in s
  s=s.replace(needle,needle+"\n proof=json.loads((root/'core-source.json').read_text());assert hashlib.sha256((base/proof['vmArchive']).read_bytes()).hexdigest()==proof['archiveSHA256']\n shutil.copyfile(base/'r124-confirmation-identical-core-plan.json',root/'pre-mutation-space-plan.json')")
 if n=='retrieve.py':s=s.replace("status['receipt']['jobs']==4","status['receipt']['jobs']==2")
 if n=='assess-vm.py':s=s.replace("len(d['jobs'])==4","len(d['jobs'])==2")
 if n=='space.py':s=s.replace('r124-identical','r124-confirmation-identical')
 (out/n).write_text(s,encoding='utf8',newline='\n')
 if n.endswith('.py'):ast.parse(s)
contract='''R124/B484 bounded confirmation justified by B483 candidate process spread2.53%validatedCSV/3.86%async text and original desktopasync text+6.4%. Same C617/C4bb source/binaries, no source refinement or erased adverse/control data. Only two existing complete scripts: primary validatedCSVwarm and async textwarm. Four independent roles,10swarmup/role/job/7rotated300msbatches to reduce coarse CPU tick uncertainty and warmup sensitivity. Diagnostic sources, no automatic fixed-percentage veto or general speed claim. No third confirmation without new specific evidence; decide retained design/regression debt after this bounded gate. Existing tooling/catalog/fullgoldens/worker7cf/optional0.4 unchanged.180sfiniteowner+30stop+30margin, lastjobadmission<150, liveunit recorded. Source/core/aux/Ready/goldens/balances/quiet/Closed/exit/join/ownedRAMunmount/archive/local gates. No publication/backend qualification or replay of old terminal CI. Persistent raw/128MiBownedRAM separate,240MiBOSfloor/12MiBheadroom/actual roundedpayload guards. Cores reused from verified immutable B483archive, no redundant binary upload/archive; no evidence deletion. If needed fresh idle exact-byte recovery only permitted canonical/writableparents/allinodealiases/SHA/persistedpremutationplan, all17paths preserved. Full source qualification at coherent retention boundary. Continue performance/regex roadmap after decision.
'''
(out/'contract.md').write_text(contract,encoding='utf8')
(out/'setup-contract.json').write_text(json.dumps(dict(jobs=jobs,roles=4,ownerSeconds=180,stopSeconds=30,marginSeconds=30,evidenceHeadroomMiB=12,osFloorMiB=240,warmupSeconds=10,targetBatchSeconds=.3),indent=2)+'\n',encoding='utf8')
(out/'sizing.json').write_text(json.dumps(dict(bothCoreImagesAndArchiveReused=True,priorArchiveBytes=(old/'observations.tgz').stat().st_size,evidenceHeadroomBytes=12*1024*1024,osFloorBytes=240*1024*1024,noEvidenceDeleted=True),indent=2)+'\n',encoding='utf8')
with tarfile.open(out/'payload.tgz','w:gz')as a:
 for n in ['collect.py','archive-owned.py','run.sh','identity.json','representative.json','contract.md','source.patch','focused.json','baseline-source.json','setup-contract.json','sizing.json','pre-measurement-plan.md','core-source.json']:a.add(out/n,arcname=n)
with tarfile.open(out/'payload.tgz')as a:required=sum(((m.size+4095)//4096)*4096 for m in a.getmembers())+(240+12)*1024*1024
(out/'space-required.json').write_text(json.dumps(dict(requiredFreeBytesBeforeExtraction=required),indent=2)+'\n',encoding='utf8')
with Path('PLAN.md').open('a',encoding='utf8')as f:f.write('\nR124/B483complete114.346s/allgates/archive/local pass. MainvalidatedCSV−3.15..+0.64%\nacross source pairs, candidate spread2.53%; reportelapsed−0.9..−2.7%/CPU0..+4%possible\ndebt; nativeCSVvariable; asynctext−0.31..+3.88%candidate spread3.86%. No gain claim.\nB484 bounded two-job confirmation before decision, samebinary/source,10swarmup/\n300msbatch/180sowner. Preserve original desktop+6.4% and allcontrols. No third\nconfirmation without specific new evidence. No publication or old CI requery.\n')
print('Prepared two-job confirmation, roundedpayload+OSfloor+headroom requires',required)
