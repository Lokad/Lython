from pathlib import Path
import json
root=Path('D:/code/Lython');r=Path(__file__).parent
terminal=json.loads((r.parent/'function-lookup-lifetime-r121/delivery-fixture-fix/ci-terminal.json').read_text(encoding='utf8'))
assert terminal['conclusion']=='success'and terminal['headSha']=='d97ca8f2524c8a8e873534ffcb7f9086d4bc13e0'
for job in terminal['jobs']:
 for name in ['Test Release (.NET 11)','Test Release (.NET 10 checkpoint)','Verify Release package consumer','Test original stress scales']:
  assert next(s for s in job['steps']if s['name']==name)['conclusion']=='success'
terminal.update(measuredRuntimeRevision='6f76f99d876ad7f3678ed4f4ecc416619c648642',
 measuredFrozenCoreSHA256='c6172fec19b0fd8d36ba5eba0046ac66578646ba3714f5f7bed99501619ff0bd',
 boundary='d97 fixture-only correction leaves measured6f76 runtime unchanged. R124 working prototype is subsequent unqualified source, not covered. Frozen measured core is not a claim about CI binary hashes.',
 statusPolicy='Cached terminal, never requery. Publication postponed.')
dest=root/'benchmarks/results/2026-11-08-function-lookup-lifetimes/delivery-ci.json'
assert not dest.exists();dest.write_text(json.dumps(terminal,indent=2)+'\n',encoding='utf8')
p=root/'docs/BENCHMARKS.md';s=p.read_text(encoding='utf8')
old='''`d97ca8f2` corrects a stale internal fixture; combined Windows/Ubuntu actual.NET11/
.NET10, original stress and installed-core qualification is pending. Source
qualification and performance evidence are separate.'''
new='''`d97ca8f2` corrects a stale internal fixture. Combined Windows/Ubuntu actual.NET11/
.NET10 full Release, original stress and installed-core consumers pass
[cached CI42527042378](../benchmarks/results/2026-11-08-function-lookup-lifetimes/delivery-ci.json).
Source qualification and performance evidence are separate; later prototypes are
outside this named-source checkpoint.'''
assert old in s;s=s.replace(old,new);p.write_text(s,encoding='utf8')
p=root/'benchmarks/results/2026-11-08-function-cpython-checkpoint/README.md';s=p.read_text(encoding='utf8')
s=s.replace('''unchanged. Combined platform/stress/installed-core qualification is pending;
earlier qualified revisions retain independent receipts.''','''unchanged. Combined Windows/Ubuntu full Release actual.NET11/.NET10, original
stress and installed-core consumers pass [cached delivery](../2026-11-08-function-lookup-lifetimes/delivery-ci.json).
Later R124 prototypes are separate; earlier revisions keep independent receipts.''')
p.write_text(s,encoding='utf8')
p=root/'benchmarks/results/2026-11-08-function-lookup-lifetimes/README.md';s=p.read_text(encoding='utf8')
s=s.replace('''2026-11-08, R121; retained corec6172fec, source inventory in identity. Full combined
source qualification is pending.''','''2026-11-08, R121; retained corec6172fec, source inventory in identity. Combined
source qualification passes [cached CI42527042378](delivery-ci.json), fixture-only
correction d97ca8f2 over runtime6f76f99d. Later prototypes are not covered.''')
s=s.replace('''Full coherent Windows/Ubuntu/Stress/installed-core qualification pending; no new
backend API qualification or publication.''','''Full coherent Windows/Ubuntu actual11/10 Release, original stress and installed-core
qualification passes at d97. No new backend API qualification or publication.''')
s=s.replace('''package steps were skipped by that failed run, so replacement delivery is required.''','''package steps were skipped by that failed run; replacement delivery now passes
in the separate cached receipt.''')
p.write_text(s,encoding='utf8')
with(root/'benchmarks/EXPERIMENTS.md').open('a',encoding='utf8')as f:f.write('''

Combined R120/R121 runtime6f76/corec617 with typed fixture fixd97 is fully qualified:
cached CI42527042378success observed22:19:56UTC, Windows/Ubuntu actual11/10 full
Release, original stress both and installed-core consumers. [Receipt](results/2026-11-08-function-lookup-lifetimes/delivery-ci.json).
No old terminal query, retiming or producer qualification replay. Current R122 guide
updated from pending to named-source-qualified; later R124 working prototype remains
independent and unqualified. Publication postponed; performance objective active.
''')
p=root/'PLAN.md';s=p.read_text(encoding='utf8')
s=s.replace('''**Committed/pushed, focused-qualified; combined delivery pending:**''','''**Fully qualified R120/R121 via d97ca8f2:**''')
s=s.replace('''**Test-only delivery correction:**''','''**Test-only correction, full delivery GREEN:**''')
s=s.replace('''per platform, later gates skipped. Failure is cached; never requery. One
  replacement full dispatch accepted; observe using its recorded >=5min boundary,
  never redispatch. Measured production source is unchanged.''','''per platform, later gates skipped. Failure is cached; never requery. Replacement
  CI42527042378success cached22:19:56UTC: Windows/Ubuntu actual11/10 full Release,
  original stress both and installed-core consumers pass. Never requery. Measured
  production source is unchanged; subsequent R124 is not covered.''')
s=s.replace('''**No active runtime prototype.**''','''**Active R124 prototype, not delivered.**''')
start=s.index('1. **Close R120/R121 coherent delivery.**');end=s.index('\n2. **Select and complete',start)
s=s[:start]+'''1. **R120/R121 delivery CLOSED.** Named runtime6f76/corec617 plus typed fixture d97
   passes cached CI42527042378. R122 external checkpoint and current guide are
   updated. Do not repeat qualification/timing or query terminal runs. Current R124
   prototype is separate. Continue the substantive roadmap; no publication.
'''+s[end:]
start=s.index('\nCurrent replacement CI42527042378/');end=s.index('\nR124 selected bounded prototype:',start)
s=s[:start]+s[end:]
s+='''
R124 initial focused Release actual11:39public/78internal pass, including new live
defaults/rebinding/decorators/actual suspension/repeated shared-budget reuse and
existing admission/refusal/cancellation/frame/argument tests. Production prototype
uncommitted and unmeasured; no gain or full-delivery claim. Next freeze source/binary,
short existing whole-script allocation/compile/elapsed diagnostics before refinement.
R120/R121 full CI is cached GREEN, never requery. Metadata commits88f28a69/f2ef9300
are pushed; no publication. All VM collections throughB482 ended and locally archived.
'''
p.write_text(s,encoding='utf8')
print('Cached exact-source delivery recorded; old source fully qualified, R124 prototype explicitly separate.')
