from pathlib import Path
import hashlib,json,shutil,subprocess,tarfile
root=Path('D:/code/Lython');r=Path(__file__).parent
i=json.loads((r/'identity.json').read_text(encoding='utf8'))
assert all(hashlib.sha256((root/p).read_bytes()).hexdigest()==h for p,h in i['productionSources'].items())
assert subprocess.run(['git','diff','--quiet','d97ca8f2','HEAD','--','src'],cwd=root).returncode==0
snapshot=r/'prototype-source';snapshot.mkdir()
production=subprocess.check_output(['git','diff','--name-only','--','src'],cwd=root,text=True).splitlines()
assert len(production)==5
for name in [*production,'tests/Lokad.Lython.Tests/GeneralBoundMethodDefaultLifetimeTests.cs','tests/Lokad.Lython.PublicApi.Tests/PreparedFunctionBindingTests.cs']:
 p=snapshot/name;p.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(root/name,p)
(r/'final-prototype-source.patch').write_bytes(subprocess.check_output(['git','diff','--','src','tests'],cwd=root))
shutil.copyfile(root/'PLAN.md',r/'plan-before-decision.md')
for name in ['b483','b484']:
 p=r/name;a=json.loads((p/'archive-receipt.json').read_text(encoding='utf8'))
 assert a['complete']and a['allWorkersJoined']and a['quietBeforeAndAfter']and a['archivedAndVerifiedUnderLease']
 assert hashlib.sha256((p/'observations.tgz').read_bytes()).hexdigest()==a['archiveSHA256']
 assert json.loads((p/'terminal-status.json').read_text(encoding='utf8'))['exitCode']=='0'
decision=dict(status='Hold the narrow prepared-binding prototype; no production promotion or permanent design rejection.',
 baseline='Fully qualified d97/runtime6f76/corec617, CI42527042378 cached success',candidateCoreSHA256=i['coreSHA256']['candidate'],
 structuralResult='Compile-owned parameter-layout-guarded named slots eliminate repeated static keyword resolution and views; shared default completion removes duplicated default/error logic. No runtime cache/owner/engine/options.',
 qualification='81internal/41public peractual11/10 plus262additional publicactual11 pass; genuine default suspension/cancellation/terminal refusal/funded alias checks. New semantic tests kept independently of prototype.',
 measurements='Warm allocation neutral; compile allocation+0.199–0.254%. B483114.346s and B484109.217s both verified. No stable primaryCSV whole-script CPU gain: confirmation candidate processes differ4.33%. Original desktopasync text+6.4% and first quiet adverse preserved; confirmation text improves in both processes. Report CPU0..+4%possible debt not erased.',
 reason='This restricted same-scope keyword form adds compiler registry/mapping/guards while general binding remains necessary. Source simplification alone does not establish a worthwhile complete call/frame redesign. Do not promote the extra machinery on inconclusive elapsed results.',
 notAnAutomaticThreshold='No fixed percentage veto, semantic failure, proven slowdown or permanent rejection. Bounded confirmation was used for a real measurement question. Preserve all initial conditions; revisit within a broader compiler-fact/call construction consolidation that removes more complete machinery.',
 next='Restore qualified production source, force fresh build after restore, keep external semantic/lifetime regressions, continue broader roadmap/independent regex. No third unchanged timing round; new source-specific evidence can justify future measurement.',
 publication='Postponed')
(r/'decision.json').write_text(json.dumps(decision,indent=2)+'\n',encoding='utf8')
out=root/'benchmarks/results/2026-11-08-prepared-function-binding';out.mkdir()
for name in ['identity.json','assessment-local.json','compile-assessment.json','decision.json','design.md']:shutil.copyfile(r/name,out/name)
for old,new in [('b483','initial'),('b484','confirmation')]:
 p=r/old
 for source,target in [('assessment.json',new+'-assessment.json'),('archive-receipt.json',new+'-receipt.json'),('observations.tgz',new+'-observations.tgz')]:shutil.copyfile(p/source,out/target)
with tarfile.open(out/'local-source-and-diagnostics.tar.xz','w:xz')as a:
 for p in sorted(r.iterdir()):
  if p.is_file():a.add(p,arcname=p.name)
  elif p.name in ['prototype-source','warm-sync','warm-async','compile-sync']:a.add(p,arcname=p.name)
 for name in ['b483','b484']:
  for p in sorted((r/name).iterdir()):
   if p.is_file()and p.name not in ['observations.tgz','payload.tgz','current-core.dll']:a.add(p,arcname=name+'/'+p.name)

def table(name):
 d=json.loads((r/name/'assessment.json').read_text(encoding='utf8'))
 rows=['| Complete script / API | Elapsed change | Process CPU change | Control spread, reference / candidate |','| --- | ---: | ---: | ---: |']
 for j in d['jobs']:
  elapsed=[x for v in j['elapsedPercent'].values()for x in v];cpu=[x for v in j['cpuPercent'].values()for x in v]
  rows.append(f'| {j["case"]} / {j["lane"]} | {min(elapsed):+.2f}..{max(elapsed):+.2f}% | {min(cpu):+.2f}..{max(cpu):+.2f}% | {abs(j["baselineSpreadPercent"]):.2f}% / {abs(j["candidateSpreadPercent"]):.2f}% |')
 return '\n'.join(rows)
(out/'README.md').write_text('''# Prepared function binding: preserved, not promoted

2026-11-08, R124. Qualified d97/runtime6f76/corec617 versus working prototypeC4bb.
Compiler-owned parameter-layout-guarded argument positions remove repeated static
keyword resolution and CallArgumentValue views for previously emitted same-scope
functions. Shared canonical default completion replaces duplicate default/error
logic; fully supplied calls need no default processing. Actual defaults remain
live; dynamic/expanded/variadic and rebound/decorated calls keep canonical binding.
No runtime cache, owner, ledger, engine, policy or public option.

**Hold this narrow form; no production promotion.** Correctness and source-level
work elimination are established, not a stable complete-script CPU benefit. It
adds a compiler registry/mapping/guard while general binding remains necessary.
Revisit prepared positions within broader compiler-fact/call construction
consolidation that removes more complete machinery. No fixed-percentage veto,
semantic failure, proven universal slowdown or permanent design rejection.

81internal/41public cases peractual.NET11/.NET10, plus262additional public.NET11
pass. New regressions keep changed defaults, decorators/rebinding, actual suspended
default/body I/O, pending argument funding, cancellation, original terminal refusal
and retained aliases/budget reuse. These observable tests survive source restoration.
The prototype itself has no full platform/stress/package qualification.

Five unchanged complete scripts, both APIs, normal desktop diagnostic: warm
allocation neutral, compiler allocation+0.199–0.254%. Elapsed controls drift up to
15%; original async text+6.4% with stable old control remains preserved. No CPU
inference from this same-process/ALC diagnostic. All full goldens/balances/cleanup
and image-isolation gates pass. Initial/refined source/core/outputs survive.

Quiet F4as_v7/Ubuntu24.04.4/.NET11RC3, frozen7cf/optional0.4, normal GC/tiering,
two independent processes per source. B483 four jobs114.346s,5swarmup/role/job,
7rotated150msrounds. All Ready/source/core/auxiliary/golden/balance/quiet/Closed/
join/ownedRAM-unmount/archive/local gates pass:

'''+table('b483')+'''

B484 bounded confirmation109.217s, unchanged source/binaries, only primary CSV
and adverse async text,10swarmup/role/job/7rotated300msrounds. Longer batches reduce
coarse process-CPU tick uncertainty. Same gates pass:

'''+table('b484')+'''

Primary CSV remains uncertain: candidate process spread4.33%, effects cross zero.
Async text improves in both confirmation processes, so its first adverse result
is not reproduced consistently; original data is not erased. Report's first
CPU0..+4%possible debt remains. Neither source promotion nor design rejection is
justified by a rigid percentage threshold. No third unchanged collection; new
source-specific evidence or a broader redesign may justify future confirmation.

Both180sfinite owners captured live, all users joined and RAM fixtures removed.
Persistent raw evidence separate from fixtures. Exact-byte space recovery used
fresh idle leases, permitted canonical ownership/writable parents/all-displaced-
inode aliases/SHA/persisted plans; all17 original paths/bytes preserved. B483
post-audit and B484 pre-mutation plan/verified post-operation receipt survive.
No evidence deletion, quota relaxation, abandoned work or publication.

[Decision](decision.json), [design before edits](design.md), [source identity](identity.json),
[desktop](assessment-local.json), [compilation](compile-assessment.json),
[first comparison](initial-assessment.json), [confirmation](confirmation-assessment.json),
[first receipt](initial-receipt.json), [confirmation receipt](confirmation-receipt.json),
[first raw/both exact cores](initial-observations.tgz), [confirmation raw/core archive proof](confirmation-observations.tgz),
[all prototype source/initial binary/local measurements/failures](local-source-and-diagnostics.tar.xz).
Performance objective and independent regex development remain active.
''',encoding='utf8')
with(root/'benchmarks/EXPERIMENTS.md').open('a',encoding='utf8')as f:f.write('''

## Compile-owned named binding prototype held (2026-11-08)

[R124](results/2026-11-08-prepared-function-binding/README.md), qualifiedC617/
prototypeC4bb. Compiler-owned immutable-layout slots/shared default completion,
no runtime cache/owner/engine/options.81internal/41public peractual11/10 plus262
additional public11 pass. Warmallocation neutral, compilerallocation+0.199–0.254%.
B483fourjobs114.346s and B484two-job confirmation109.217s/allgates/archive/localpass.
Primary CSV candidate spread4.33%, no stable whole-script CPU gain; async text
confirmation improves but original desktop+6.4%/quiet adverse survives, reportCPU
0..+4%possible debt. Hold narrow form rather than promote extra compiler machinery
without established benefit; not fixed-threshold rejection, semantic failure or
permanent closure. Full source/core/raw/conditions preserved. Restore qualified
production and retain useful observable lifetime/semantic tests, continue broader
call/frame/frontend roadmap and independent regex. No third unchanged timing round
or publication; future source-specific evidence can justify revisiting the design.
''')
subprocess.run(['git','restore','--source=HEAD','--',*production],cwd=root,check=True)
assert subprocess.run(['git','diff','--quiet','--','src'],cwd=root).returncode==0
print('Prototype/source/cores/adverse data archived. Restored all five production files to qualified source; semantic regressions remain.')
