from pathlib import Path
import hashlib,json,shutil,subprocess,tarfile
root=Path('/home/lokad/lython-bench-checks/binding-confirm-b484-20261108')
r=json.loads((root/'confirmation/confirmation.json').read_text());assert r['complete']and len(r['jobs'])==2 and all(j['workersJoinedAndFixturesRemoved']for j in r['jobs'])
assert not (root/'guest-fixtures').exists()and subprocess.run(['pgrep','-af','[d]otnet.* --compare worker'],capture_output=True).returncode==1
assert json.loads((root/'confirmation/machine-after.json').read_text())['gate']['quiet']
live=(root/'live-unit.txt').read_text();assert 'LoadState=loaded' in live and 'RuntimeMaxUSec=infinity' not in live
with tarfile.open(root/'observations.tgz','w:gz')as a:
 for n in ['confirmation','identity.json','representative.json','collect.py','cpython-worker.py','pre-measurement-plan.md','setup-contract.json','contract.md','source.patch','focused.json','started.utc','live-unit.txt','run.sh','archive-owned.py','core-source.json','pre-mutation-space-plan.json','baseline-source.json','sizing.json']:a.add((root/n).resolve(),arcname=n)
with tarfile.open(root/'observations.tgz')as a:assert json.loads(a.extractfile('confirmation/confirmation.json').read())['complete']
assert shutil.disk_usage(root).free>240*1024*1024
receipt=dict(complete=True,jobs=2,elapsedSeconds=r['elapsedSeconds'],allWorkersJoined=True,guestFixtureDirectories=[],quietBeforeAndAfter=True,archivedAndVerifiedUnderLease=True,archiveSHA256=hashlib.sha256((root/'observations.tgz').read_bytes()).hexdigest());(root/'archive-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt))
