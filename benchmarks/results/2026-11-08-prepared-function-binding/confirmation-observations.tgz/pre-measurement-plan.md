# Lokad.Lython 0.11.0

Updated 2026-11-08. Git-ignored: never force-add. Publication/tagging postponed.
Objective: coherent simplification and substantial complete-script performance.
Current contracts live in docs; original conditions, adverse results and designs
remain in [experimental history](benchmarks/EXPERIMENTS.md) and immutable results.

## Delivery status

- **Fully qualified:** b1e17b64/core93e926fe (cached CI42512127664) includes the
  shared compiler-fact correction, direct UTF8 formatting/storage, native helper
  returns, R105/R106/R110 and R113–R115 primitive facts/accounting. R119 d05b3359/
  core19b8b5a5 (cached CI42519822299) replaces lookup entry objects with flat
  storage and reuses immutable CSV/JSON field positions. Windows/Ubuntu actual
  .NET11/.NET10 full Release, original stress both and installed-core consumers
  pass. Do not repeat completed qualification or query terminal runs.
- **Fully qualified R120/R121 via d97ca8f2:** R120 ca83509f
  skips unused lookup-table allocation for receivers already excluded from caching.
  R121 6f76f99d/corec6172fec lets ordinary calls reuse the existing function's
  execution-owned lookup bank. No new owner/engine/options; native guards remain.
  Capacity conservatively survives until execution cleanup. Focused 83 internal /
  2133 public + 15 provider callback cases per actual11/10 pass. Reentrant first
  admission, refusal, cancellation and genuinely suspended formatting are covered.
- **Test-only correction, full delivery GREEN:** d97ca8f2 replaces a stale reflection fixture
  with typed internal access, preserving disposal/order/ownership assertions. 29
  focused cases pass per actual11/10. Initial combined CI42525582689 failed only
  its 17 stale constructor cases on each platform; all 16,845 public tests passed
  per platform, later gates skipped. Failure is cached; never requery. Replacement
  CI42527042378success cached22:19:56UTC: Windows/Ubuntu actual11/10 full Release,
  original stress both and installed-core consumers pass. Never requery. Measured
  production source is unchanged; subsequent R124 is not covered.
- **Active R124 prototype, not delivered.** R122/B481 is complete, 15 jobs / 311.685s,
  source6f76/corec617 versus CPython3.13.16. All source/golden/quiet/ownership/
  cleanup/archive/local gates pass. [Current comparison](docs/BENCHMARKS.md):
  compile-to-result validated CSV1.17x, CSV1.01–1.03x variable, text1.52–1.53x,
  JSON0.91–0.96x variable, report1.32–1.33x. Warm/compile separate; RAM-file I/O,
  validation and prior-result cleanup included. Startup, pending I/O, RSS and
  embedding tails unmeasured. Config/search/manifest remain historical726.

Claims remain distinct: original native-return allocation −19.92/−19.31%, elapsed
only diagnostic. Formatting allocation −8.67%; controlled B102 elapsed/CPU −5–8%,
original adverse15.125ms unexplained/preserved. R110 wide allocation −8.56–8.58%.
R119 controlled complete CSV/JSON ~5–10% elapsed / custom ~3–6%, supporting CPU;
text inconclusive, report CPU +1.53–6.25% possible debt. R120 custom allocation
−1.71%, no CPU claim. R121 confirmation versus ca835: report −6.09–6.66%, validated
CSV −3.30–5.45%, supporting CPU, inline control ±0.60%; async float variable.
Combined earlier source pair's possible async-float +1–2% debt is not erased.
Initial report cache +9.02% and widened-frame custom +0.871% were explained and
corrected; all initial sources/results and adverse desktop controls remain.
Independent source pairs are not additive and do not settle earlier debts.

## Prioritized deliverables

1. **R120/R121 delivery CLOSED.** Named runtime6f76/corec617 plus typed fixture d97
   passes cached CI42527042378. R122 external checkpoint and current guide are
   updated. Do not repeat qualification/timing or query terminal runs. Current R124
   prototype is separate. Continue the substantive roadmap; no publication.

2. **Select and complete the next substantial redesign.** Remaining complete-text
   and report gaps deserve work beyond isolated experiments. Record hypothesis,
   eliminated work/storage, representative scripts, semantic/cancellation/ownership
   acceptance, displaced code to delete and bounded before/after controls BEFORE
   implementing each selected milestone. A temporary setback requires an explicit
   completion milestone and a decision on residual regression debt.

   - **Complete call/frame/operand construction:** direct operands, deferred contexts,
     funded bound-local workspaces, shared prefix and native returns already remove
     old packaging phases. Current ordinary render borrows locals; zero captures/
     patterns means zero frame-storage admission. R116 binding/context0leaf;
     R108 routing3.96%leaf/inclusive84% includes useful work. Existing exact-tuple
     unpacking already borrows immutable storage in sync/async: no scratch copy to
     remove. R123 attribution completed: binding/workspace4.97%leaf, preparation4.14%,
     context0; inclusive frame samples contain useful work. Exact13instruction
     helper runs borrowed prefix. Existing B480~5.1vs3.3ms includes tuple/useful
     work, not pure call overhead. No new arena/carrier/prototype from samples.
     No revival of slower R71 call-arena/control/carrier or duplicate formatter.
   - **Per-record collection construction:** JSON direct values/shared layouts and
     CSV array adoption remove earlier copies. Bulk CSV6–8% was reassessed with its
     adverse control; current copying premise is gone, no automatic promotion or
     permanent ban. Any revised candidate must prove a current intermediate and
     preserve key/order/duplicates/hooks/retained rows. R118 get/add/store fusion
     selected no prototype: new conditional CFG/proofs would duplicate canonical
     code for a narrow shape; complexity/evidence decision, not measured failure.
   - **Text/frontend:** native UTF8/inline strings, casing-split, final-buffer
     formatting and shared compiler facts are delivered. File windows already borrow
     raw bytes; returned copies protect refill immutability. String views require a
     representation/lifetime tradeoff. Native strings cache hashes; scalar dict
     updates/split commits do not resize the root. Select actual conversions or
     repeated analysis from callers/CPU/allocation evidence; measure compilation
     separately. No second evaluator/parser/formatter, universal tagged slots/JIT/
     stack rewrite justified solely by boxing or inclusive samples.

   Source gate about20min. Use existing evidence or one short targeted diagnostic
   when attribution is missing. Stop when a coherent candidate is testable, or
   record specific uncertainty and pursue an independent track; no open-ended audit.
   Focused Release semantics/current-token cancellation/shared-memory checks during
   iteration; batch full qualification for retained coherent delivery.

3. **Independent regex contract/implementation.** Core owns Python/native UTF8
   names, byte captures/scalar positions/original windows, flags/errors/replacements,
   cache ownership/current tokens, one frontend/runtime/import provider. Optional
   nonpackable adapter remains ordinary0.4. Dev55/d6067925 focused qualification
   already passed86internal/514public per actual11/10; no unchanged replay or sibling
   edits/builds. Missing released producer capabilities: DetailedData with separate
   preparation/working owners, native-name enumeration, cursor creation without
   retaining an earlier token. Adapter-local bridges/development producers can
   support implementation. Missing releases defer only affected final adapter
   qualification, never independent core work. Keep contract forwarding/unwind,
   Python semantics and actual backend performance separate.

## Operating policy

Bounded confirmation/refinement/measurement correction is allowed when evidence
justifies it. Timeout, unstable unchanged controls and inconclusive timing establish
uncertainty, not failed designs or permanent closure. Percentages inform decisions,
not automatic vetoes. Preserve original adverse/source/control conditions. Separate
architectural simplification, allocation reduction and demonstrated CPU improvement.

AGENTS.md governs fully managed memory safety, managed stack admission, host
mediation, current-token cancellation, shared coarse admission/preflights/replacement
overlap, funded aliases/results/caches/pending users and awaited cleanup. Refusal
is terminal. No unsafe/Unsafe/native probes, tracing/weak reclaim/forcedGC, independent
caps/fuel/quotas, hidden allowance, silent regex fallback or abandoned work.
No local build/test/measurement overlap; nonincremental build after preserved-time
source restores. Explicit UTF8. Only core Release pack to artifacts/nuget.

VM lokad@20.166.121.73, key~/.ssh/id_lython-bench.pem. Persistent worker/catalog/raw
separate from owned RAM fixtures; join/verify/unmount/archive under lease and verify
locally. B450–B481 terminal/cached/locally verified; no active users/fixtures, never
requery. R122 optional historical hardlink EPERM preserved; independent launch space
gate passed, fresh idle read-only audit17aliases/hashes unchanged/no temporary links.
Future exact-byte dedup requires permitted canonical ownership/writable parents,
fresh inode/SHA/all-alias proof and persisted plan before mutation. Never delete
historical evidence. Cached terminal CI never queried again; active replacement
status observations at least5min apart. Publication remains postponed.

R123/B482 closed: same source, both captures/output/cleanup/map/archive/local gates
pass. Original ownerexit1 aftercleanup/two-map archive assumption preserved; corrected
only metadata underfreshidlelease/no rerun. Initialspace refusal and symlink assumption
preserved; permitted-canonical exact-byte5537792B recovery, post-audit17aliases pass.
No VM users/fixtures. Never requery B482. Source gate/evidence linked in history.

Next R124 candidate: consolidate ordinary fixed-shape argument-to-local binding.
Hypothesis: static keyword positions can be prepared for immutable parameter-layout
identity, removing repeated CallArgumentValue views/name resolution and sharing
positional/keyword local initialization. Keep defaults live and generic expanded/
protocol binder; reuse existing admitted lookup lifetime, no new owner/framework.
Source gate about20min before prototype; reject a form adding a duplicate binder,
carrier or ownership system. Acceptance: rebinding/default mutation/duplicates/
positional-only/receivers/recursion/actual suspension/evaluation order/cancellation/
refusal/funded aliases/budget reuse. Bound normal before/after primary validatedCSV/
report plus nativeCSV/text controls, compiler/allocation costs and two unchanged
process controls. Preserve regressions and decide completion debt explicitly.

R124 selected bounded prototype: compile-owned argument slots from existing
previously emitted same-scope FunctionParameterLayout facts, guarded by actual
immutable layout identity/receiver shape. Avoid the runtime-cache variant and its
reentrant replacement/retention machinery. Remove per-call static keyword resolution
and wrapper views; consolidate existing positional/general default completion and
delete duplicate default/error logic. General dynamic/expanded/variadic/protocol
binder remains; current defaults read after admission, operands copied before await.
First focused semantic/refusal/cancellation/ownership checks and short existing
complete-workload/compile/allocation diagnostics. If retained, bounded quiet pair
with unchanged controls, then coherent delivery. No new owner/options/engine;
explicit regression-debt decision before promotion. Design recorded before edits.

R124 initial focused Release actual11:39public/78internal pass, including new live
defaults/rebinding/decorators/actual suspension/repeated shared-budget reuse and
existing admission/refusal/cancellation/frame/argument tests. Production prototype
uncommitted and unmeasured; no gain or full-delivery claim. Next freeze source/binary,
short existing whole-script allocation/compile/elapsed diagnostics before refinement.
R120/R121 full CI is cached GREEN, never requery. Metadata commits88f28a69/f2ef9300
are pushed; no publication. All VM collections throughB482 ended and locally archived.

R123 compile-only census identity corrected C54->C617; same operations/counts and
current72/120Bframes. Original preserved. Actual VM captures already verifiedC617.
R124 hash gate caught baseline path mismatch before any comparison; corrected
refined/images reference, no wrong-source measurements or CPU rerun.

R124 refined C4bb:41public/78internal actual11pass; five complete scripts bothAPIs
allgoldens/balances/cleanup, warmalloc neutral, compileralloc+0.2%. Desktopelapsed
controls unstable; async text+6.4%adverse preserved. B483 four-job quiet comparison
prepared before retention, 180sowner/5swarmup/7rotated150ms, source/core/ownership/
archive gates. No speed/full-qualification claim or publication.
