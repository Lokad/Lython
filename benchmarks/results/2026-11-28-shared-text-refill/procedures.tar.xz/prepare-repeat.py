from hashlib import sha256
from pathlib import Path
from shutil import copyfile, copytree
import json

lab = Path(__file__).resolve().parent
first = lab / "comparison"
repeat = first / "repeat"
repeat.mkdir()
read = lambda path: json.loads(path.read_bytes())
digest = lambda path: sha256(path.read_bytes()).hexdigest()
def write(path, value):
    path.write_text(json.dumps(value, indent=2) + "\n", encoding="utf-8", newline="\n")

setup = read(first / "identity.json")
assert read(first / "archive-receipt.json")["archiveSHA256"] == digest(first / "observations.tar.xz")
assert read(first / "summary.json")["verifiedTimedBatches"] == 168
for role, contents in setup["imageFiles"].items():
    assert {file.name: digest(file) for file in (first / role).iterdir()} == contents
    copytree(first / role, repeat / role)
for name in ("representative.json", "cpython-worker.py", "run.sh"):
    copyfile(first / name, repeat / name)
assert b"\r" not in (repeat / "run.sh").read_bytes()
jobs = read(first / "jobs.json")["warm"]
write(repeat / "jobs.json", {"warm": [jobs[4], jobs[3], jobs[0], jobs[2]]})
setup["catalogs"]["jobs.json"]["sha256"] = digest(repeat / "jobs.json")
setup["purpose"] = "Same images with reversed worker placement to confirm async text and both dense paths with an unaffected control."
write(repeat / "identity.json", setup)
collector = (first / "collect.py").read_text(encoding="utf-8").replace("len(jobs) == 6", "len(jobs) == 4").replace("job_index % 2 == 0", "job_index % 2 != 0")
compile(collector, "collect.py", "exec")
(repeat / "collect.py").write_text(collector, encoding="utf-8", newline="\n")
summary = (lab / "summarize.py").read_text(encoding="utf-8").replace('pair = root / "comparison"','pair = root / "comparison/repeat"')
summary = summary.replace('receipt["warmJobs"] == 6','receipt["warmJobs"] == 4').replace('== 168','== 112')
compile(summary, "summarize-repeat.py", "exec")
(lab / "summarize-repeat.py").write_text(summary, encoding="utf-8", newline="\n")
