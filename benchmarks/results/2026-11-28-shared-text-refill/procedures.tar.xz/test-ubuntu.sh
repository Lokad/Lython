#!/usr/bin/env bash
set -euo pipefail
export DOTNET_ROOT="$HOME/.dotnet"
export PATH="$DOTNET_ROOT:$PATH"
cd /mnt/d/code/Lython
lab="$PWD/.git/agent-notes/review-20261031/shared-text-refill-b1918-20261128"
export NUGET_PACKAGES="$PWD/.git/agent-notes/review-20261031/regex-released-050-20261127/packages-ubuntu"
public='Category!=Stress&(FullyQualifiedName~Chunked|FullyQualifiedName~CsvDelayed|FullyQualifiedName~CsvTextStream|FullyQualifiedName~TextFileScopeLifetime|FullyQualifiedName~TextFileOwnerLifetime|FullyQualifiedName~TextReaderAbandonment|FullyQualifiedName~GzipFile|FullyQualifiedName~GzipPathScope|FullyQualifiedName~JsonTextStream|FullyQualifiedName~Utf16CodecCompatibility|FullyQualifiedName~RegexAdapter)'
internal='Category!=Stress&(FullyQualifiedName~ChunkedRead|FullyQualifiedName~TextRead|FullyQualifiedName~BufferedLineAdmission|FullyQualifiedName~CsvParserCancellation|FullyQualifiedName~Utf16Codec|FullyQualifiedName~GzipFileAccounting|FullyQualifiedName~GzipPathScopeLifetime)'
for suite in Lokad.Lython.PublicApi.Tests Lokad.Lython.Tests; do
    if [[ "$suite" == Lokad.Lython.PublicApi.Tests ]]; then filter="$public"; else filter="$internal"; fi
    dotnet test "tests/$suite/$suite.csproj" -c Release -f net11.0 --artifacts-path "$lab/ubuntu-artifacts" --filter "$filter" 2>&1 | tee "$lab/ubuntu-$suite-net11.0.log"
done
