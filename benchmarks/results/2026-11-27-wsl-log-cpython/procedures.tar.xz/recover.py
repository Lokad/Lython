from hashlib import sha256
from pathlib import Path
import json
import shutil


root = Path(__file__).resolve().parent
assert (root / 'exit-code.txt').read_bytes().strip() == b'1'
receipt = json.loads((root / 'archive-receipt.json').read_bytes())
assert not receipt['complete'] and receipt['guestFixturesRemoved']
assert sha256((root / 'observations.tar.xz').read_bytes()).hexdigest() == receipt['archiveSHA256']
identity = json.loads((root / 'identity.json').read_bytes())
frozen = identity['imageFiles']['candidate']
assert {p.name: sha256(p.read_bytes()).hexdigest() for p in (root / 'candidate').iterdir()} == frozen
assert identity['auxiliaryFiles']['Lokad.Lython.dll'] != frozen['Lokad.Lython.dll']
failed = root / 'initial-attempt'
failed.mkdir()
for name in ('archive-receipt.json', 'collection.log', 'exit-code.txt', 'verification.json',
             'identity.json', 'observations.tar.xz', 'confirmation'):
    path = (root / name).resolve()
    assert path.parent == root and (failed / name).parent.resolve() == failed
    shutil.move(path, failed / name)
identity['auxiliaryFiles'] = frozen
(root / 'identity.json').write_text(json.dumps(identity, indent=2) + '\n', encoding='utf-8', newline='\n')
