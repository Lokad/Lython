from hashlib import sha256
from pathlib import Path
from shutil import copyfile, copytree
import json
import subprocess


root = Path(__file__).resolve().parent
repo = root.parents[3]
pair = root.parent / 'direct-regex-allowance-20261127/comparison'
previous = root.parent / 'wsl-shipment-cpython-20261127'
read = lambda p: json.loads(p.read_bytes())


def sha(path):
    return sha256(path.read_bytes()).hexdigest()


def write(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n', encoding='utf-8', newline='\n')


trial = read(pair / 'identity.json')
inspected = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repo, text=True).strip()
source = subprocess.check_output(['git', 'diff', '--binary', trial['sourceRevision'], inspected, '--',
                                 'src/Lokad.Lython.Utf8Regex/Utf8RegexProvider.cs'], cwd=repo)
assert sha256(source).hexdigest() == trial['sourcePatchSHA256']
assert not subprocess.check_output(['git', 'diff', trial['sourceRevision'], inspected, '--', 'src/Lokad.Lython'], cwd=repo)
assert not subprocess.check_output(['git', 'status', '--porcelain', '--', 'src'], cwd=repo)
frozen = trial['imageFiles']['candidate']
assert {p.name: sha(p) for p in (pair / 'candidate').iterdir()} == frozen
copytree(pair / 'candidate', root / 'candidate')
assert {p.name: sha(p) for p in (root / 'candidate').iterdir()} == frozen

catalog = read(pair / 'representative.json')
assert sha(pair / 'representative.json') == trial['catalogs']['representative.json']['sha256']
compiled = 'scripts.regex-log-search.compiled'
module = 'scripts.regex-log-search.module'
catalog['cases'] = [case for case in catalog['cases'] if case['id'] in (compiled, module)]
assert len(catalog['cases']) == 2
write(root / 'representative.json', catalog)
write(root / 'jobs.json', [[compiled, 'warm'], [module, 'compile'], [module, 'warm'], [module, 'compile-run']])
pin = read(previous / 'identity.json')
for name in ('cpython-worker.py', 'run.sh'):
    copyfile(previous / name, root / name)
assert sha(root / 'cpython-worker.py') == pin['cpythonWorkerSHA256']
assert b'\r' not in (root / 'run.sh').read_bytes()
producer = root.parent / 'bench-cpython-3.13.16-runtime'
archives = read(producer / 'identity.json')
assert {p.relative_to(producer / 'runtime').as_posix():sha(p)
        for p in (producer / 'runtime').rglob('*') if p.is_file()} == archives['files']
assert archives['source']['sha256'] == trial['expectedCPythonSHA256'] == pin['expectedCPythonSHA256']
pin.update(sourceRevision=inspected, inspectedHead=inspected, imageFiles={'candidate': frozen},
           purpose='Refresh both log workloads against stock CPython with compilation boundaries.',
           frozenImage=trial['cpythonPath'].split('/bench-cpython-')[0] + '/wsl-log-cpython-20261127/candidate',
           signedPackageSHA256=trial['signedPackageSHA256'])
pin['coreSHA256'] = {r: frozen['Lokad.Lython.dll'] for r in ('candidate', 'candidate-control')}
pin['auxiliaryFiles'] = frozen
pin['catalogs'] = {name: {'sha256': sha(root / name)} for name in ('representative.json', 'jobs.json')}
write(root / 'identity.json', pin)
collector = (previous / 'collect.py').read_text(encoding='utf-8')
collector = collector.replace('assert len(jobs) == 3', 'assert len(jobs) == 4')
collector = collector.replace('lython-b1881-shipment-guest-', 'lython-b1885-log-guest-')
compile(collector, 'collect.py', 'exec')
(root / 'collect.py').write_text(collector, encoding='utf-8', newline='\n')
