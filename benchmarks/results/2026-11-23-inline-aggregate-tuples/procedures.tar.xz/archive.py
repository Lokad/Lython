from pathlib import Path
import gzip
import hashlib
import json
import shutil
import subprocess
import tarfile

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
comparison = lab/"comparison"
quiet = comparison/"quiet"
dest = repo/"benchmarks/results/2026-11-23-inline-aggregate-tuples"
read = lambda path: json.loads(path.read_text(encoding="utf-8-sig"))
sha = lambda blob: hashlib.sha256(blob).hexdigest()
identity = read(comparison/"identity.json")
terminal = read(quiet/"terminal-status.json")
assert terminal["exitCode"] == "0" and terminal["receipt"]["archivedAndVerifiedUnderLease"]
assert terminal["receipt"]["allWorkersJoined"] and terminal["receipt"]["guestFixturesRemoved"]
assert sha((quiet/"observations.tar.xz").read_bytes()) == terminal["receipt"]["archiveSHA256"]
assert read(quiet/"summary.json")["timedBatches"] == 168
for role, files in identity["imageFiles"].items():
    assert len(files) == 32
    assert all(sha((lab/role/name).read_bytes()) == digest for name,digest in files.items())
core = (lab/"candidate/Lokad.Lython.dll").read_bytes()
dest.mkdir(exist_ok=True)
head = subprocess.check_output(["git","rev-parse","HEAD"],cwd=repo,encoding="utf-8").strip()
retained = not subprocess.check_output(["git","diff","--name-only",head,identity["candidate"],"--","src","tests"],cwd=repo)
source = subprocess.check_output(["git","diff","--binary",identity["sourceRevision"],identity["candidate"],"--","src","tests"],cwd=repo)
(comparison/"production.patch").write_bytes(source)
(dest/"identity.json").write_text(json.dumps(dict(identity,retainedRevision=head if retained else None,
    productionPatchSHA256=sha(source)),indent=2)+"\n",encoding="utf-8",newline="\n")
for name in ("terminal-status.json","observations.tar.xz","summary.json"):
    shutil.copyfile(quiet/name,dest/name)
for name in ("allocation-summary-six.json",):
    shutil.copyfile(lab/name,dest/name)
(dest/"candidate-core.dll.gz").write_bytes(gzip.compress(core,mtime=0))
with tarfile.open(dest/"procedures.tar.xz","w:xz") as archive:
    for name in ("archive.py","freeze.py","quiet.py","quiet-first.py","stage.py","summarize.py","allocations.py",
                 "test-platform.py","tuple-semantics.py","cpython-tuple-semantics.log",
                 "windows-white.log","windows-public.log","ubuntu-white.log","ubuntu-public.log",
                 "reference-allocation-six.json","candidate-allocation-six.json",
                 "comparison/reference-verify.json","comparison/candidate-verify.json","comparison/production.patch",
                 "comparison/quiet/initial-launch-failure.txt","comparison/quiet/launch.log","comparison/quiet/observe-not-before"):
        archive.add(lab/name,arcname=name,recursive=False)
    initial=lab.parent/"numeric-aggregate-tuples-20261123"
    for file in initial.glob("*-*.log"):
        archive.add(file,arcname="initial-slot-array/"+file.name,recursive=False)
    patch = subprocess.check_output(["git","diff","--binary","123b2c894","a5914742f","--","src","tests"],cwd=repo)
    (lab/"initial-slot-array.patch").write_bytes(patch)
    archive.add(lab/"initial-slot-array.patch",arcname="initial-slot-array/production.patch",recursive=False)
assert sha(gzip.decompress((dest/"candidate-core.dll.gz").read_bytes())) == identity["coreSHA256"]["candidate"]
print(dest,"retained" if retained else "private")
