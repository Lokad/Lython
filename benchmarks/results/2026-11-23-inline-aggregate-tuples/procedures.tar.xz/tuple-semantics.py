import math
def aggregate(a,b):
    previous=(a*b, b-a, a+a)
    retained=(a*b, max(previous[1], a), previous[0]*b)
    assert retained[-2] is previous[1]
    assert retained[0] is retained[0]
    assert retained[0] is not retained[2]
    assert type(retained) is tuple and tuple(retained) is retained
    assert retained.index(2.0)==1 and retained.count(0.0)==2
    assert math.copysign(1.0,retained[0])==-1.0
    assert math.copysign(1.0,retained[2])==-1.0
    repeated=(retained[0], retained[1], retained[2])
    assert repeated==retained and hash(repeated)==hash(retained)
    return retained
assert aggregate(-0.0,2.0)==(-0.0,2.0,-0.0)
def nan_pair(inf):
    result=(inf-inf, inf*2.0)
    assert math.isnan(result[0])
    assert result[0] is result[0]
    assert len({result[0],result[0]})==1
nan_pair(float('inf'))
print('ok')
