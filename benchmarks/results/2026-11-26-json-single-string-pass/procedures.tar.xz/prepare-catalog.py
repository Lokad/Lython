from pathlib import Path
import base64, copy, hashlib, json

lab=Path(__file__).resolve().parent
p=lab.with_name('json-ascii-character-20261126')/'local/representative.json'
manifest=json.loads(p.read_text(encoding='utf-8-sig'))
case=next(row for row in manifest['cases'] if row['id']=='diagnostic.report-render.escaped-unicode.large')
variant=copy.deepcopy(case)
variant['id']='diagnostic.report-render.raw-unicode.large'
fixture=json.loads(case['fixtureJson'])
original=base64.b64decode(fixture['inputFiles']['records.json'])
decoded=json.loads(original)
raw=json.dumps(decoded,ensure_ascii=False,separators=(',',':')).encode()
assert sum(byte>=128 for byte in raw)>0 and len(decoded)==int(case['expectedOutput'])
fixture['inputFiles']['records.json']=base64.b64encode(raw).decode('ascii')
variant['fixtureJson']=json.dumps(fixture,ensure_ascii=False,separators=(',',':'))
variant['fixtureSha256']=hashlib.sha256(variant['fixtureJson'].encode()).hexdigest()
manifest['cases'].append(variant)
(lab/'representative.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
for row in manifest['cases']:
    print(row['id'])
