def keep(value, marker):
    def first():
        return value
    def pair():
        try:
            return [value, marker, locals()['value']]
        finally:
            value.append(marker)
    return first, pair, lambda: value

def assign(source):
    def read():
        return source
    for source in ['next', 'last']:
        pass
    return read

def delete(source):
    def read():
        return source
    del source
    return read

def exception(source):
    def read():
        return source
    try:
        raise ValueError()
    except ValueError as source:
        pass
    return read

def comprehension(source):
    def read():
        return source
    discarded = [(source := n) for n in [1, 2, 3]]
    return read, discarded

def import_binding(source):
    def read():
        return source
    import math as source
    return read

def nested(source):
    def partial():
        def read():
            return source
        return read
    def update():
        nonlocal source
        source = [42]
    result = partial()
    update()
    return result

def yielding(source):
    def generator():
        yield source
        yield source
    return generator

value = []
first, pair, sibling = keep(value, 'kept')
copy = pair()
print(copy[0] is copy[2], first() is value, sibling() is value, copy[1], value)
print(assign('start')())
for read in [delete('value'), exception('value')]:
    try:
        read()
    except NameError:
        print('unbound')
again, events = comprehension(0)
print(again(), events)
print(import_binding(None)().__name__)
print(nested(None)())
sequence = list(yielding(value)())
print(sequence[0] is sequence[1] is value)

def many(v0, v1, v2, v3, v4, v5, v6, v7, v8, v9, v10, v11, v12, v13, v14, v15, v16, v17, v18, v19, v20, v21, v22, v23):
    def keep():
        return (v0, v1, v2, v3, v4, v5, v6, v7, v8, v9, v10, v11, v12, v13, v14, v15, v16, v17, v18, v19, v20, v21, v22, v23)
    return keep
print(many(*range(24))())
