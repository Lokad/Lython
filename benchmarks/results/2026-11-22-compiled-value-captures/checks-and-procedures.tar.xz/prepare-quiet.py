from pathlib import Path
import gzip
import hashlib
import json
import os
import shutil
import subprocess
import tarfile

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
old=lab.parent/'definition-admission-20261122'
donor=lab.parent/'numeric-extrema-standalone-20261122'/'quiet'
out=lab/'quiet'
def load(path): return json.loads(path.read_text(encoding='utf-8-sig'))
def digest(data): return hashlib.sha256(data).hexdigest()
def sha(path): return digest(path.read_bytes())
def save(path,value): path.write_text(json.dumps(value,indent=2)+'\n',encoding='utf-8',newline='\n')
def emit(path,source):
    if path.suffix=='.py': compile(source,str(path),'exec')
    path.write_text(source,encoding='utf-8',newline='\n')

local=load(lab/'identity.json')
reference,candidate=(subprocess.check_output(['git','rev-parse',local[key]],cwd=repo,text=True).strip()
                     for key in ('reference','candidate'))
assert reference.startswith('2d4fb517b') and candidate.startswith('6cb1da6dc')
core='Lokad.Lython.dll'
images=local['imageFiles']
donor_config=load(donor/'config.json')
donor_receipt=load(donor/'archive-receipt.json')
donor_files=load(donor/'identity.json')['imageFiles']['candidate']
assert donor_receipt['complete'] and donor_receipt['archivedAndVerifiedUnderLease']
assert sha(donor/'observations.tgz')==donor_receipt['archiveSHA256']
assert len(donor_files)==32 and {n:sha(donor.parent/'frozen/candidate'/n) for n in donor_files}==donor_files
expected=load(lab.parent/'complete-decimal-ascii-20261122/quiet/identity.json')['imageFiles']['candidate']
assert images['reference']==expected
assert digest(gzip.decompress((repo/'benchmarks/results/2026-11-22-complete-decimal-ascii/candidate-core.dll.gz').read_bytes()))==expected[core]
for role,files in images.items():
    assert len(files)==32 and {n:sha(lab/'frozen'/role/n) for n in files}==files
    assert all(donor_files[n]==h for n,h in files.items() if n!=core)
for platform in ('win','ubuntu'):
    for suite,count in (('white',1631),('public',3673)):
        text=(lab/f'{suite}-{platform}.log').read_text(encoding='utf-8-sig')
        assert 'Passed!' in text and f'Passed: {count:5d}, Skipped:' in text
allocation=load(lab/'allocation-summary.json')
assert len(allocation)==7 and all(row['allowanceRestored'] for row in allocation)

case_ids=['scripts.ordinary-fully-supplied-helper','scripts.annotated-rule-closures.nested-factories',
          'scripts.annotated-rule-closures.literal-positional-dynamic-keyword','scripts.factory-observed-defaults',
          'scripts.annotated-rule-closures.nested-factories.postponed','scripts.csv-invoice.large']
catalog=load(lab/'representative.json')
catalog['cases']=[case for id in case_ids for case in catalog['cases'] if case['id']==id]
assert [case['id'] for case in catalog['cases']]==case_ids
out.mkdir()
manifest=out/'representative.json'
save(manifest,catalog)
sdk=Path.home()/'.dotnet11'
dotnet=sdk/'dotnet.exe'
env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk),PATH=str(sdk)+os.pathsep+os.environ['PATH'])
protocol=repo/'benchmarks/cpython-worker.py'
assert sha(protocol)==donor_config['protocolSHA256']
for role in images:
    image=lab/'frozen'/role
    receipt=lab/f'quiet-{role}-verify.json'
    subprocess.run([dotnet,image/'Lokad.Lython.Benchmarks.dll','--compare','verify','--catalog',manifest,
        '--dotnet',dotnet,'--python','C:/Python313/python.exe','--python-worker',protocol,'--out',receipt],
        check=True,env=env,timeout=95)
    proof=load(receipt)
    assert proof['state']=='Completed' and proof['caseCount']==len(case_ids) and proof['catalogSha256']==sha(manifest)
    core_out=out/role/core
    core_out.parent.mkdir()
    shutil.copyfile(image/core,core_out)
    assert sha(core_out)==images[role][core]
identity=dict(sourceRevision=reference+' versus '+candidate,purpose='Read-only parameter captures from compiled storage',
              imageFiles=images,normalAdapterPin='0.4.0',catalogSHA256=sha(manifest),
              coreSHA256={role+suffix:files[core] for role,files in images.items() for suffix in ('','-control')})
save(out/'identity.json',identity)
root='/home/lokad/lython-bench-checks/compiled-value-captures-b1341-20261122'
unit='lython-b1341-compiled-value-captures-20261122'
template=old/'quiet'
template_config=load(template/'config.json')
jobs=[(case,'warm') for case in case_ids]+[(case_ids[2],'compile'),(case_ids[2],'compile-run')]
for name in ('collect.py','archive-owned.py','run.sh','retrieve.py'):
    source=(template/name).read_text(encoding='utf-8').replace(template_config['root'],root).replace(template_config['unit'],unit)
    if name=='collect.py':
        start,end=source.index('\njobs = '),source.index('\nassert len(jobs)')
        source=source[:start]+'\njobs = '+repr(jobs)+source[end:]
    source=source.replace('len(jobs)==6','len(jobs)==8').replace("len(raw['jobs'])==6","len(raw['jobs'])==8").replace("['jobs']==6","['jobs']==8").replace('jobs=6,','jobs=8,')
    emit(out/name,source)
assert b'\r' not in (out/'run.sh').read_bytes()
parts=('identity.json','collect.py','archive-owned.py','run.sh','representative.json',
       'reference/'+core,'candidate/'+core)
payload=out/'payload.tgz'
with tarfile.open(payload,'w:gz') as archive:
    for name in parts:
        archive.add(out/name,arcname=name)
used=sum((out/name).stat().st_size for name in parts)
inventory=load(lab/'working-images.json')
retire=[]
if inventory['free']<=176160768+used+640*1024:
    old=lab.parent/'exact-list-drain-r562'
    report='benchmarks/results/2026-11-18-exact-list-drain/observations.tgz'
    archived=subprocess.check_output(['git','show','origin/master:'+report],cwd=repo)
    export=old/'frozen/candidate'
    hashes=load(old/'quiet/identity.json')['imageFiles']['candidate']
    assert len(hashes)==32 and {n:sha(export/n) for n in hashes}==hashes
    duplicate=next(v for v in inventory['workingImages'] if v['core'].startswith('exact-list-drain-b988-'))
    assert sha(export/core)==duplicate['sha256'] and (export/core).stat().st_size==duplicate['bytes']
    assert sha(old/'quiet/observations.tgz')==digest(archived)==duplicate['archiveSha256']
    retire.append(dict(paths=[duplicate['core']],bytes=duplicate['bytes'],links=duplicate['links'],
                       sha256=duplicate['sha256'],archives={duplicate['archive']:duplicate['archiveSha256']},optional=False))
    save(lab/'retained-working-copy-proof.json',dict(localFrozenImage=hashes,remoteWorkingCopy=duplicate,
         trackedObservation=report,retainedLocalCore=str(export/core),allFilesVerified=True))
assert inventory['free']+sum(p['bytes'] for p in retire)>176160768+used+640*1024
stage=dict(root=root,unit=unit,identity=identity,source=donor_config['root'],sourceRole='candidate',
    sourceFiles=donor_files,sourceCatalogSHA256=donor_config['catalogSHA256'],donorArchiveSHA256=donor_receipt['archiveSHA256'],
    protocolSource=donor_config['root']+'/cpython-worker.py',protocolSHA256=donor_config['protocolSHA256'],
    payloadBytes=payload.stat().st_size,payloadSHA256=sha(payload),retireGroups=retire,
    catalogSHA256=sha(manifest),unpackedBytes=used)
save(out/'config.json',stage)
source=(template/'remote-launch.py').read_text(encoding='utf-8')
start,end=source.index('\nc=')+1,source.index('\nb=Path(')
source=source[:start]+'c='+repr(stage)+source[end:]
source=source.replace('lython-b1331-fixtures','lython-b1341-fixtures').replace('RuntimeMaxSec=540','RuntimeMaxSec=660')
assert "c['unpackedBytes']+640*1024" in source
emit(out/'remote-launch.py',source)
source=(lab.parent/'complete-decimal-ascii-20261122/launch.py').read_text(encoding='utf-8')
emit(lab/'launch.py',source.replace('Short ASCII decimal token comparison','Compiled read-only capture comparison').replace('400','620'))
print(f'Eight short lanes, frozen input {used:,} bytes.')

