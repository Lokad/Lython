set -eu
root=/home/lokad/lython-bench-checks/compiled-value-captures-b1341-20261122
trap 'result=$?; printf "%s\n" "$result" > "$root/finish-exit-code.txt"' EXIT
python3 "$root/finish-lane.py"
