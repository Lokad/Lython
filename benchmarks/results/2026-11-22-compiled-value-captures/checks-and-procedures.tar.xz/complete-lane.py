from pathlib import Path
import datetime
import hashlib
import io
import json
import shlex
import subprocess
import tarfile

lab=Path(__file__).resolve().parent
q=lab/'quiet'
def read(name): return json.loads((q/name).read_text(encoding='utf-8'))
def emit(name,contents):
    if name.endswith('.py'): compile(contents,name,'exec')
    (q/name).write_text(contents,encoding='utf-8',newline='\n')
cfg=read('config.json')
partial=read('partial-observations-proof.json')
unit=cfg['unit']+'-finish'
raw_digest=partial['confirmationSHA256']
root=cfg['root']
old=(q/'collect.py').read_text(encoding='utf-8')
start,end=old.index('\njobs = '),old.index('\nassert len(jobs)')
source=old[:start]+"\njobs = [('scripts.annotated-rule-closures.literal-positional-dynamic-keyword', 'compile-run')]"+old[end:]
source=source.replace("out = root / 'confirmation'","out = root / 'completion'").replace("len(jobs)==8","len(jobs)==1")
source=source.replace('for job_index,(case_id,lane) in enumerate(jobs):','for job_index,(case_id,lane) in enumerate(jobs, start=7):')
source=source.replace(' < 430,',' < 90,').replace('Reserve60seconds for final owned work/cleanup.', 'Leave time for final owned cleanup.')
source=source.replace('root/"archive-owned.py"','root/"finish-archive.py"')
emit('finish-lane.py',source)
archive=(q/'archive-owned.py').read_text(encoding='utf-8')
start,end=archive.index('raw='),archive.index('assert not(r/')
archive=archive[:start]+f"""initial=r/'confirmation/confirmation.json'
digest=hashlib.sha256(initial.read_bytes()).hexdigest();assert digest=={raw_digest!r}
raw=json.loads(initial.read_text())
last=json.loads((r/'completion/confirmation.json').read_text())
assert not raw['complete']and len(raw['jobs'])==7 and last['complete']and len(last['jobs'])==1
assert all(j['workersJoinedAndFixturesRemoved']for j in raw['jobs']+last['jobs'])
"""+archive[end:]
archive=archive.replace("(r/'confirmation'/name).read_text()","(r/'completion'/name).read_text()")
archive=archive.replace("with tarfile.open(r/'observations.tgz')as a:assert json.loads(a.extractfile('confirmation/confirmation.json').read())['complete']",
"""with tarfile.open(r/'observations.tgz')as a:
 assert hashlib.sha256(a.extractfile('confirmation/confirmation.json').read()).hexdigest()==digest
 assert json.loads(a.extractfile('completion/confirmation.json').read())['complete']""")
archive=archive.replace("elapsedSeconds=raw['elapsedSeconds']","completionElapsedSeconds=last['elapsedSeconds'],initialConfirmationSHA256=digest,initialAfterGatePresent=False")
emit('finish-archive.py',archive)
emit('run-finish.sh',(q/'run.sh').read_text(encoding='utf-8').replace('exit-code.txt','finish-exit-code.txt').replace('collect.py','finish-lane.py'))
assert b'\r' not in (q/'run-finish.sh').read_bytes()
names=('finish-lane.py','finish-archive.py','run-finish.sh')
payload=io.BytesIO()
with tarfile.open(fileobj=payload,mode='w:gz') as stream:
    for name in names:stream.add(q/name,arcname=name)
blob=payload.getvalue()
stage=dict(config=cfg,unit=unit,partialSHA256=raw_digest,expectedPayload=len(blob),
           payloadSHA256=hashlib.sha256(blob).hexdigest())
code=r"""
from pathlib import Path
import fcntl,hashlib,io,json,os,shutil,subprocess,sys,tarfile
s=STAGE
c=s['config']
r=Path(c['root']); assert r.resolve()==r and r.parent==Path('/home/lokad/lython-bench-checks')
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
with (r.parent/'comparison-vm.lock').open('a') as lease:
    fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
    state=subprocess.check_output(['systemctl','show',c['unit']+'.service','--property=ActiveState,MainPID'],text=True)
    assert 'MainPID=0' in state and 'ActiveState=failed' in state
    worker=subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record'],capture_output=True,text=True)
    assert worker.returncode==1 and not worker.stdout
    for role,files in c['identity']['imageFiles'].items():
        assert len(files)==32 and all(sha(r/role/n)==h for n,h in files.items())
    assert sha(r/'representative.json')==c['catalogSHA256'] and sha(r/'confirmation/confirmation.json')==s['partialSHA256']
    assert sha(r/'cpython-worker.py')==c['protocolSHA256']
    assert os.path.ismount(r/'guest-fixtures') and not list((r/'guest-fixtures').iterdir())
    assert shutil.disk_usage(r).free>176160768+512*1024
    body=sys.stdin.buffer.read(s['expectedPayload']+1)
    assert len(body)==s['expectedPayload'] and hashlib.sha256(body).hexdigest()==s['payloadSHA256']
    with tarfile.open(fileobj=io.BytesIO(body),mode='r:gz') as archive:
        assert {p.name for p in archive}=={'finish-lane.py','finish-archive.py','run-finish.sh'}
        assert not any((r/n).exists() for n in ('finish-lane.py','finish-archive.py','run-finish.sh','completion','archive-receipt.json'))
        archive.extractall(r,filter='data')
    subprocess.run(['/bin/sh','-n',str(r/'run-finish.sh')],check=True)
subprocess.run(['sudo','-n','systemd-run','--unit='+s['unit'],'--property=User=lokad',
    '--property=WorkingDirectory='+str(r),'--property=RuntimeMaxSec=160','--property=TimeoutStopSec=30',
    '--property=KillMode=control-group','/bin/sh',str(r/'run-finish.sh')],check=True)
print(json.dumps(dict(launched=True,unit=s['unit'],initialCompletedLanes=7,remainingLanes=1)))
""".replace('STAGE',repr(stage))
emit('stage-finish.py',code)
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i',str(Path.home()/'.ssh/id_lython-bench.pem'),'-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
bootstrap="import sys; n=int(sys.stdin.buffer.readline()); code=sys.stdin.buffer.read(n); exec(compile(code,'owned-finish','exec'))"
encoded=code.encode()
result=subprocess.run(ssh+['python3 -c '+shlex.quote(bootstrap)],
    input=str(len(encoded)).encode()+b'\n'+encoded+blob,capture_output=True,timeout=70)
(q/'finish-launch.log').write_bytes(result.stdout+result.stderr)
assert result.returncode==0,(result.stdout+result.stderr).decode()
now=datetime.datetime.now(datetime.timezone.utc)
for name,value in [('finish-config.json',dict(cfg,unit=unit)),('finish-not-before.json',dict(launchedAtUTC=now.isoformat(),
                          doNotObserveBeforeUTC=(now+datetime.timedelta(seconds=105)).isoformat()))]:
    emit(name,json.dumps(value,indent=2)+'\n')
retrieve=(q/'retrieve.py').read_text(encoding='utf-8').replace("r/'config.json'","r/'finish-config.json'")
retrieve=retrieve.replace("r/'observe-not-before.json'","r/'finish-not-before.json'").replace("root/'exit-code.txt'","root/'finish-exit-code.txt'")
emit('retrieve-finish.py',retrieve)
print((result.stdout+result.stderr).decode())

