from pathlib import Path
import hashlib
import json
import shutil
import tarfile

lab=Path(__file__).resolve().parent
out=lab.parents[3]/"benchmarks/results/2026-11-25-compiled-entry"
quiet=lab/"comparison/focused-compile"
digest=lambda file:hashlib.sha256(file.read_bytes()).hexdigest()
read=lambda path:json.loads(path.read_text(encoding="utf-8-sig"))
identity=read(quiet/"identity.json")
assert digest(lab/"candidate.patch")==identity["sourcePatchSHA256"]
assert all({p.name:digest(p) for p in (lab/role).iterdir()}==files for role,files in identity["imageFiles"].items())
for log in ["windows-net11.log","ubuntu-net10-Lokad.Lython.PublicApi.Tests.log"]:
    assert "Passed:   511" in (lab/log).read_text(encoding="utf-8")
for folder,name in [(quiet,"identity.json"),(lab,"allocation-summary.json"),(lab,"tape-summary.json")]:
    shutil.copyfile(folder/name,out/name)
files=[
 "candidate.patch","freeze.py","allocations.py","check-tape.py","tape-inspector/Program.cs","tape-inspector/Tape.csproj",
 "first-tape-inspection.txt","tape-inspector-build.log","tape-candidate.json","tape-reference.json",
 "candidate-build.log","windows-net11.log","test-ubuntu.sh","ubuntu-net10-Lokad.Lython.PublicApi.Tests.log",
 "ubuntu-net10-Lokad.Lython.Tests.log","comparison/reference-verify.json","comparison/candidate-verify.json",
 "candidate-allocation-final.json","reference-allocation-final.json","prepare-focused-catalog.py",
 "comparison/focused-compile/reference-verify.json","comparison/focused-compile/candidate-verify.json",
 "comparison/focused-compile/upload.json","comparison/focused-compile/launch.log","comparison/focused-compile/storage-custody.json",
 "prepare-quiet.py","quiet.py","archive.py","package.py","retire-resolved-guest-call-20261125.py","retire-shared-call-entry-20261125.py",
]
for donor in ("resolved-guest-call-20261125", "shared-call-entry-20261125"):
    files.extend((f"retired-core/{donor}/local-custody.json", f"retired-core/{donor}/vm-custody.json"))
with tarfile.open(out/"procedures.tar.xz","w:xz") as archive:
    for name in files:
        archive.add(lab/name,arcname=name,recursive=False)
with tarfile.open(out/"procedures.tar.xz") as archive:
    assert archive.getnames()==files
    assert all(hashlib.sha256(archive.extractfile(name).read()).hexdigest()==digest(lab/name) for name in files)
print("Verified both focused logs, all worker files and archived procedures.")
