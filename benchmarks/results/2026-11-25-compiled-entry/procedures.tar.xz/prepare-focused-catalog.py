from pathlib import Path
import hashlib
import json
import os
import subprocess

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
quiet = lab / "comparison/quiet"
focused = lab / "comparison/focused-compile"
focused.mkdir(exist_ok=True)
read = lambda path: json.loads(path.read_text(encoding="utf-8-sig"))
sha = lambda b: hashlib.sha256(b).hexdigest()
digest = lambda path: sha(path.read_bytes())
save = lambda path, value: path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n",
                                          encoding="utf-8", newline="\n")
identity = read(quiet / "identity.json")
catalog = read(quiet / "representative.json")
older = read(lab.with_name("shared-function-local-slots-20261125") / "comparison/quiet/representative.json")
catalog["cases"] = [case for case in catalog["cases"] if case["id"] in (
    "scripts.rule-default-closures", "scripts.csv-invoice.method-policy.quoted-control", "diagnostic.generated-ordinary-definitions")]
manifest = next(case for case in older["cases"] if case["id"] == "scripts.config-manifest.small")
catalog["cases"].append(manifest)
source = "print(sum(range(16)))\n"
python = Path("C:/Python313/python.exe")
stdout = subprocess.check_output([python, "-I", "-X", "utf8", "-c", source], encoding="utf-8")
fixture = json.dumps(dict(size=16, text=None), separators=(",", ":"))
catalog["cases"].append(dict(id="diagnostic.short-numeric-command", family="scripts", category="whole-script", scale="small",
    size=16, source=source, fixtureJson=fixture, expectedOutput=stdout, sourceUtf8Bytes=len(source),
    expectedOutputUtf8Bytes=len(stdout), fixtureTextUtf8Bytes=0, fixtureTextCodePoints=0,
    sourceSha256=sha(source.encode()), fixtureSha256=sha(fixture.encode()), expectedOutputSha256=sha(stdout.encode())))
assert len(catalog["cases"]) == 5
path = focused / "representative.json"
save(path, catalog)

def phases(case, *names):
    return [[case, name] for name in names]

jobs = (phases("diagnostic.short-numeric-command", "compile", "warm", "compile-run") +
        phases("scripts.rule-default-closures", "compile-run") +
        phases("scripts.config-manifest.small", "compile", "compile-run") +
        phases("scripts.csv-invoice.method-policy.quoted-control", "warm") +
        phases("diagnostic.generated-ordinary-definitions", "compile-run"))
save(focused / "jobs.json", dict(warm=jobs))
identity["catalogs"] = {path.name: dict(sha256=digest(path)), "jobs.json": dict(sha256=digest(focused/"jobs.json"))}
save(focused / "identity.json", identity)
sdk = Path.home() / ".dotnet11"
dotnet = sdk / "dotnet.exe"
env = dict(os.environ, DOTNET_ROOT=str(sdk), DOTNET_ROOT_X64=str(sdk))
worker = repo / "benchmarks/cpython-worker.py"
assert digest(worker) == identity["cpythonWorkerSHA256"]
for role, files in identity["imageFiles"].items():
    image = lab / role
    assert {p.name: digest(p) for p in image.iterdir()} == files
    receipt = focused / f"{role}-verify.json"
    subprocess.run([dotnet, image / "Lokad.Lython.Benchmarks.dll", "--compare", "verify", "--catalog",
        path, "--dotnet", dotnet, "--python", python, "--python-worker", worker, "--out", receipt],
        cwd=repo, env=env, check=True, timeout=65)
    result = read(receipt)
    assert result["state"] == "Completed" and result["caseCount"] == 5
    assert result["catalogSha256"] == digest(path)
    assert result["launched"]["library"]["sha256"] == files["Lokad.Lython.dll"]
print("Eight planned lanes use five cases verified against independent CPython results.")
