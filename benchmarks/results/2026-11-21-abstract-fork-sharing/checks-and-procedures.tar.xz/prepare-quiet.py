from pathlib import Path
import gzip
import hashlib
import json
import os
import shutil
import subprocess
import tarfile


lab = Path(__file__).resolve().parent
repo = lab.parents[3]
donor = lab.parent / "json-string-escape-descriptors"
prior = donor / "quiet"
quiet = lab / "quiet"
core = "Lokad.Lython.dll"

def load(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def emit(path, text):
    if path.suffix == ".py":
        compile(text, str(path), "exec")
    path.write_text(text, encoding="utf-8", newline="\n")

def save(path, value):
    emit(path, json.dumps(value, indent=2) + "\n")

rebased = repo / ".git/agent-worktrees/abstract-fork-sharing-20261121"
revision = subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=rebased, text=True).strip()
assert revision.startswith("393ef9913")
assert not subprocess.check_output(["git", "status", "--porcelain"], cwd=rebased)
production = subprocess.check_output(["git", "rev-parse", revision + "^"], cwd=rebased, text=True).strip()
assert production.startswith("256c5e651")
candidate = rebased / "src/Lokad.Lython/bin/Release/net11.0" / core
for suite, count in (("white", 17), ("public", 772)):
    log = (lab / f"rebased-{suite}-win.log").read_text(encoding="utf-8-sig")
    assert "Passed!" in log and f"Passed: {count:5d}, Skipped:" in log

config = load(prior / "config.json")
receipt = load(prior / "archive-receipt.json")
assert receipt["complete"] and receipt["archivedAndVerifiedUnderLease"]
reference = config["identity"]["imageFiles"]["reference"]
assert len(reference) == 32 and {name: sha(donor / "quiet-workers/reference" / name) for name in reference} == reference
library = reference[core]
assert hashlib.sha256(gzip.decompress((repo / "benchmarks/results/2026-11-21-cpython-current-factories/measured-core.dll.gz").read_bytes())).hexdigest() == library
# Only this single recoverable B1288 worker file may be retired under the lease.
archive = "benchmarks/results/2026-11-21-json-escape-descriptors"
known_core = subprocess.check_output(["git", "show", "06d0c28ca:" + archive + "/candidate-core.dll.gz"], cwd=repo)
known_raw = subprocess.check_output(["git", "show", "06d0c28ca:" + archive + "/observations.tgz"], cwd=repo)
removed = gzip.decompress(known_core)
removed_hash = hashlib.sha256(removed).hexdigest()
raw_hash = hashlib.sha256(known_raw).hexdigest()
assert raw_hash == receipt["archiveSHA256"] == sha(prior / "observations.tgz")
assert removed_hash == config["identity"]["imageFiles"]["candidate"][core]
retire = [dict(paths=[Path(config["root"]).name + "/candidate/" + core], links=1, bytes=len(removed),
               sha256=removed_hash, archives={Path(config["root"]).name + "/observations.tgz": raw_hash},
               optional=False)]

quiet.mkdir()
manifest = quiet / "representative.json"
shutil.copyfile(lab / "qualified-catalog.json", manifest)
cases = load(manifest)["cases"]
jobs = [('scripts.annotated-rule-closures.nested-factories.postponed', 'compile'), ('scripts.dataclass-inherited-configuration.generated', 'compile'), ('scripts.config-generated-guards.medium.bad-0', 'compile'), ('compile-many-live-scalar-facts', 'compile'), ('scripts.config-generated-guards.medium.bad-0', 'compile-run')]
assert len(jobs) == 5
images = {"reference": reference, "candidate": reference | {core: sha(candidate)}}
protocol = repo / "benchmarks/cpython-worker.py"
assert sha(protocol) == config["protocolSHA256"]
sdk = Path.home() / ".dotnet11"
dotnet = sdk / "dotnet.exe"
env = dict(os.environ, DOTNET_ROOT=str(sdk), DOTNET_ROOT_X64=str(sdk), PATH=str(sdk) + os.pathsep + os.environ["PATH"])
python = Path(shutil.which("python.exe")).resolve()
for role, expected in images.items():
    destination = lab / "quiet-workers" / role
    destination.mkdir(parents=True)
    for name in reference:
        path = candidate if role == "candidate" and name == core else donor / "quiet-workers/reference" / name
        shutil.copyfile(path, destination / name)
    proof = lab / f"quiet-{role}-verify.json"
    subprocess.run([dotnet, destination / "Lokad.Lython.Benchmarks.dll", "--compare", "verify",
                    "--catalog", manifest, "--dotnet", dotnet, "--python", python, "--python-worker", protocol,
                    "--out", proof], env=env, check=True)
    assert {f.name: sha(f) for f in destination.iterdir()} == expected
    assert load(proof)["state"] == "Completed" and load(proof)["caseCount"] == 4
    assert load(proof)["catalogSha256"] == sha(manifest)

root = "/home/lokad/lython-bench-checks/abstract-fork-sharing-b1289-20261121"
unit = "lython-b1289-abstract-fork-sharing-20261121"
identity = dict(sourceRevision=production + " versus " + revision, purpose="Share abstract-state snapshots across branches",
                imageFiles=images, normalAdapterPin="0.4.0", catalogSHA256=sha(manifest),
                coreSHA256={role + suffix: hashes[core] for role, hashes in images.items() for suffix in ("", "-control")})
save(quiet / "identity.json", identity)
for name in ("collect.py", "archive-owned.py", "run.sh", "retrieve.py"):
    src = (prior / name).read_text(encoding="utf-8").replace(config["root"], root).replace(config["unit"], unit)
    if name == "collect.py":
        begin = src.index("\njobs = ")
        end = src.index("\nassert len(jobs)", begin)
        src = src[:begin] + "\njobs = " + repr(jobs) + src[end:]
    emit(quiet / name, src)
assert b"\r" not in (quiet / "run.sh").read_bytes()

# Verify the compiler catalog against both images before staging it.
# Keep 3 MiB for trial overhead in addition to the existing floor.
payload = quiet / "payload.tgz"
parts = ("identity.json", "representative.json", "collect.py", "archive-owned.py", "run.sh", "candidate/" + core)
(quiet / "candidate").mkdir()
shutil.copyfile(candidate, quiet / "candidate" / core)
assert sha(quiet / "candidate" / core) == images["candidate"][core]
with tarfile.open(payload, "w:gz") as packed:
    for name in parts:
        packed.add(quiet / name, arcname=name)
stage = dict(root=root, unit=unit, identity=identity, source=config["root"], sourceRole="reference", sourceFiles=reference,
             sourceCatalogSHA256=config["catalogSHA256"], donorArchiveSHA256=raw_hash,
             protocolSource=config["root"] + "/cpython-worker.py", protocolSHA256=sha(protocol),
             payloadBytes=payload.stat().st_size, payloadSHA256=sha(payload), retireGroups=retire,
             catalogSHA256=sha(manifest), unpackedBytes=sum((quiet / name).stat().st_size for name in parts))
save(quiet / "config.json", stage)
src = (prior / "remote-launch.py").read_text(encoding="utf-8")
begin, end = src.index("\nc=") + 1, src.index("\nb=Path(")
src = src[:begin] + "c=" + repr(stage) + src[end:]
src = src.replace("lython-b1288-fixtures", "lython-b1289-fixtures")
assert "c['unpackedBytes']+3*1024*1024" in src
emit(quiet / "remote-launch.py", src)
emit(lab / "launch.py", (donor / "launch.py").read_text(encoding="utf-8")
     .replace("JSON escape descriptor comparison", "Abstract branch sharing comparison"))
shutil.copyfile(donor / "summarize.py", lab / "summarize.py")
print(f"Prepared verified images and five lanes with {stage['unpackedBytes']} bytes to stage.")
