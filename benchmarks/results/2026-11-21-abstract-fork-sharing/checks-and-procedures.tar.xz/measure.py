from pathlib import Path
import hashlib, json, os, shutil, statistics, subprocess

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
trial = repo / ".git/agent-worktrees/abstract-fork-sharing-20261121"
source = lab.parent / "json-string-single-validation"
known_cases = lab.parent / "abstract-binding-map"
compile_probe = lab.parent / "borrow-lexical-builder-r625/compile-allocation/bin/Release/net11.0"
core = "Lokad.Lython.dll"

def load(p):
    return json.loads(p.read_text(encoding="utf-8-sig"))

def write(p, obj):
    p.write_text(json.dumps(obj, indent=2, ensure_ascii=True) + "\n", encoding="utf-8", newline="\n")

def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()

reference = load(source / "identity.json")
reference_sha = reference["reference"]
candidate_sha = subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=trial, text=True).strip()
assert not subprocess.check_output(["git", "status", "--porcelain", "--untracked-files=no"], cwd=trial)
assert not subprocess.check_output(["git", "diff", "--name-only", reference_sha, "--", "src"], cwd=repo)
catalog = load(known_cases / "representative.json")
catalog["cases"].extend(load(known_cases / "scalar-state-control.json")["cases"])
manifest = lab / "catalog.json"
write(manifest, catalog)

sdk = Path.home() / ".dotnet11"
dotnet = sdk / "dotnet.exe"
env = dict(os.environ, DOTNET_ROOT=str(sdk), DOTNET_ROOT_X64=str(sdk),
           PATH=str(sdk) + os.pathsep + os.environ["PATH"])
frozen = source / "workers/reference"
expected = reference["imageFiles"]["reference"]
assert len(expected) == 32 and {name: sha(frozen / name) for name in expected} == expected
candidate_core = trial / "src/Lokad.Lython/bin/Release/net11.0" / core
assert sha(candidate_core) != expected[core]
rows = {}
images = {}
for role, binary in (("reference", frozen / core), ("candidate", candidate_core)):
    folder = lab / role
    folder.mkdir(exist_ok=True)
    for name in expected:
        shutil.copyfile(binary if name == core else frozen / name, folder / name)
    images[role] = {name: sha(folder / name) for name in expected}
    for path in compile_probe.glob("CompileAllocation.*"):
        shutil.copyfile(path, folder / path.name)
    out = lab / f"{role}-allocation.json"
    out.write_bytes(subprocess.check_output([dotnet, folder / "CompileAllocation.dll", manifest], env=env, timeout=100))
    obs = load(out)
    assert obs["coreSha256"] == images[role][core]
    rows[role] = obs["rows"]

measurements = []
for left, right in zip(rows["reference"], rows["candidate"], strict=True):
    assert left["id"] == right["id"]
    a, b = (statistics.median(row["bytes"]) for row in (left, right))
    measurements.append(dict(case=left["id"], referenceBytes=a, candidateBytes=b, changePercent=100*(b/a-1)))
    print(left["id"], round(a), round(b), f"{100*(b/a-1):+.2f}%")
write(lab / "summary.json", dict(reference=reference_sha, candidate=candidate_sha,
      catalogSHA256=sha(manifest), imageFiles=images, rows=measurements, elapsedClaim=False))
