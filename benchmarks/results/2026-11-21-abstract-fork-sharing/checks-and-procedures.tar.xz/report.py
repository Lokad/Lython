from pathlib import Path
import json

lab = Path(__file__).resolve().parent
decision = json.loads((lab / "decision.json").read_text(encoding="utf-8"))["decision"]
rows = json.loads((lab / "quiet/quiet-summary.json").read_text(encoding="utf-8"))["rows"]
allocations = json.loads((lab / "summary.json").read_text(encoding="utf-8"))["rows"]

def bounds(values):
    return " to ".join(f"{value:+.2f}%".replace("-", "−") for value in (min(values), max(values)))

names = ["Postponed nested factories", "Inherited dataclass configuration",
         "Generated 96-field validator", "Dense scalar control", "Generated 96-field validator"]
intro = """# B1289 structurally shared abstract-state forks

The prototype replaces two full mutable map copies at each analysis fork
with shared immutable roots and independently mutable builders. Branches
still own their value facts, length bounds and resolution caches.
Invalidation can rewrite the active branch while visiting its snapshot,
which removes the rewrite list. The value map checks backing identity
when setting an entry. Recursive value joins remain explicit.

Reference `256c5e651` and prototype `393ef9913` ran on the quiet Azure
F4as_v7 with Ubuntu 24.04.4 and .NET 11 RC3 on November 21, 2026 UTC.
Each lane uses two independently warmed processes per source and seven
rotated batches per process. The ranges span all four pairs of process
medians. Compile elapsed includes compiled-owner disposal. Time to result
also includes one run, mediated RAM-backed I/O, result observation and
cleanup. Process CPU covers the enclosing request. Startup and final
teardown are outside these clocks.

| Workload | Phase | Elapsed change | Process CPU change | Reference / candidate elapsed spread |
| --- | --- | ---: | ---: | ---: |
"""
table = "\n".join(f"| {name} | {row['lane']} | {bounds(row['elapsedChangePercent'])} | "
                  f"{bounds(row['cpuChangePercent'])} | {row['referenceSpreadPercent']:.2f}% / "
                  f"{row['candidateSpreadPercent']:.2f}% |"
                  for name, row in zip(names, rows, strict=True))
allocation_intro = """
The local allocation diagnostic measures `2f9ad5677` against `40ba42fdc`
on Windows .NET 11. It counts current-thread allocations through complete
public compilation and compiled-owner disposal. Each invocation returns
the borrowed budget to baseline. This source pair differs from the quiet
pair because both local images include the later operand-forwarding
cancellation checkpoint. The diagnostic makes no elapsed claim.

| Script | Reference allocation | Prototype allocation | Change |
| --- | ---: | ---: | ---: |
"""
allocation_table = "\n".join(f"| {name} | {row['referenceBytes']:,.0f} B | "
                             f"{row['candidateBytes']:,.0f} B | {bounds([row['changePercent']]).split(' to ')[0]} |"
                             for name, row in zip(names[:4], allocations, strict=True))
close = """
The synthetic scaling probe holds branch count at 48 while varying the
number of live scalar bindings. Allocation savings grow from 10.55%
at four bindings to 35.21% at 32 and 55.28% at 256. The corresponding
branchless cases allocate 1.58–5.99% less.

""" + decision + """

Windows .NET 11 and Ubuntu .NET 10 each pass 17 white-box, 772 public
and 18 supplemental ownership checks. The first Ubuntu public run hit
a missing worker root marker in a benchmark supervisor test. The
unchanged rerun passed. Both complete frozen images match four CPython
goldens. All 140 timed batches and machine gates pass. Workers join,
RAM-backed fixtures are removed and the persistent archive is verified
under the lease.

[Timing summary](summary.json) · [Local allocations](local-allocations.json) ·
[Scaling controls](fork-scaling.json) · [Raw observations](observations.tgz) ·
[Source, checks and procedures](checks-and-procedures.tar.xz).
"""
(lab / "README.md").write_text(intro + table + "\n" + allocation_intro + allocation_table + "\n" + close,
                              encoding="utf-8", newline="\n")
