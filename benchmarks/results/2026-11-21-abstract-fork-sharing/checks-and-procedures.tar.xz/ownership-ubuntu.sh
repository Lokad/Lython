set -euo pipefail
cd /mnt/d/code/Lython/.git/agent-worktrees/abstract-fork-sharing-20261121
export DOTNET_ROOT="$HOME/.dotnet"
export PATH="$DOTNET_ROOT:$PATH"
log=/mnt/d/code/Lython/.git/agent-notes/review-20261031/abstract-fork-sharing/ownership-ubuntu.log
dotnet test tests/Lokad.Lython.PublicApi.Tests -c Release -f net10.0 --no-build --filter 'Category!=Stress&(FullyQualifiedName~GovernedMemoryContractTests|FullyQualifiedName~RegexCompilationAccountingScenarioTests)' > "$log" 2>&1
tail -n 4 "$log"
