from pathlib import Path
import hashlib, json, os, statistics, subprocess

lab=Path('.git/agent-notes/review-20261031/abstract-fork-sharing').resolve()
identity=json.loads((lab/'summary.json').read_bytes())
cases=[]
for n in (4, 32, 256):
    for branches in (0, 48):
        lines=["def analyze(flag):",*(f"    value_{i} = {i}" for i in range(n))]
        for j in range(branches):
            lines.extend(("    if flag:", f"        value_{j % n} = {n+j}"))
        lines.extend(("    return value_0","print(analyze(False))"))
        cases.append(dict(id=f"{n}-values-{branches}-branches",source="\n".join(lines)+"\n"))
catalog=lab/'fork-scaling-catalog.json'
catalog.write_text(json.dumps(dict(cases=cases),indent=2)+'\n',encoding="utf-8",newline="\n")
sdk=Path.home()/'.dotnet11'
env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk),PATH=str(sdk)+os.pathsep+os.environ['PATH'])
roles=['reference','candidate']
samples=[]
for role in roles:
    image=lab/role
    for name,known in identity["imageFiles"][role].items():
        assert hashlib.sha256((image/name).read_bytes()).hexdigest()==known
    raw=subprocess.check_output([sdk/'dotnet.exe',image/'CompileAllocation.dll',catalog],env=env,timeout=100)
    (lab/f'{role}-fork-scaling.json').write_bytes(raw)
    data=json.loads(raw)
    assert data['coreSha256']==identity['imageFiles'][role]['Lokad.Lython.dll']
    samples.append(data['rows'])
rows=[]
for left,right in zip(*samples,strict=True):
    assert left['id']==right['id']
    a,b=(statistics.median(row['bytes']) for row in (left,right))
    rows.append(dict(case=left['id'],referenceBytes=a,candidateBytes=b,changePercent=100*(b/a-1)))
    print(left['id'],round(a),round(b),f"{100*(b/a-1):+.2f}%")
(lab/'fork-scaling-summary.json').write_text(json.dumps(rows,indent=2)+'\n',encoding='utf-8',newline='\n')
