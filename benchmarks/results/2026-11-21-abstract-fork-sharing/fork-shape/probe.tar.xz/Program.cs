using Lokad.Lython;
using System.Reflection;
using System.Security.Cryptography;
using System.Text.Json;

using var json = JsonDocument.Parse(File.ReadAllBytes(args[0]));
var core = typeof(LythonEngine).Assembly;
var fields = core.GetType("Lokad.Lython.Frontend.BranchJoinProbe", throwOnError: true)!
    .GetFields(BindingFlags.Static | BindingFlags.NonPublic);
var budget = new LythonMemoryBudget();
var engine = new LythonEngine();
var rows = new List<object>();
foreach (var item in json.RootElement.GetProperty("cases").EnumerateArray())
{
    var source = item.GetProperty("source").GetString()!;
    foreach (var field in fields) field.SetValue(null, 0);
    using (var compiled = engine.Compile(source, budget))
        if (!compiled.IsValid || compiled.Diagnostics.Count != 0)
            throw new InvalidOperationException("Expected valid source without diagnostics.");
    if (budget.ReservedBytes != 0) throw new InvalidOperationException("Compilation failed to release its budget.");
    rows.Add(new { id = item.GetProperty("id").GetString(),
        counts = fields.ToDictionary(field => field.Name, field => (int)field.GetValue(null)!) });
}
Console.WriteLine(JsonSerializer.Serialize(new
{
    reference = "c67b28f80",
    coreSHA256 = Convert.ToHexStringLower(SHA256.HashData(File.ReadAllBytes(core.Location))),
    purpose = "Instrumented single public compile. Counts only, no CPU or elapsed claims.",
    budgetReturnedToBaseline = true,
    rows
}, new JsonSerializerOptions { WriteIndented = true }));
