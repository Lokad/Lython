from pathlib import Path
import hashlib,json,os,shutil,subprocess
r=Path(__file__).resolve().parent;repo=Path('D:/code/Lython');work=repo;project=r/'adapter'
d=Path('C:/Users/JoannesVermorel/.dotnet11/dotnet.exe');env=os.environ.copy();env.update(DOTNET_ROOT=str(d.parent),DOTNET_ROOT_X64=str(d.parent));env['PATH']=str(d.parent)+os.pathsep+env['PATH']
with(r/'adapter-build.log').open('w',encoding='utf-8')as log:p=subprocess.run([str(d),'build',str(project/'Adapter.csproj'),'-c','Release','--no-incremental'],cwd=repo,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=120)
assert p.returncode==0,(r/'adapter-build.log').read_text(encoding='utf-8')[-4500:]
images={};sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for tfm in ['net11.0','net10.0']:
 image=r/'consumers'/tfm
 shutil.copytree(work/'tests/Lokad.Lython.PublicApi.Tests/bin/Release'/tfm,image,copy_function=shutil.copyfile)
 for n in ['Lokad.Utf8Regex','Lokad.Utf8Regex.PythonRe']:
  shutil.copyfile(r/'producer/src'/n/'bin/Release'/tfm/(n+'.dll'),image/(n+'.dll'))
 shutil.copyfile(project/'bin/Release'/tfm/'Lokad.Lython.Utf8Regex.dll',image/'Lokad.Lython.Utf8Regex.dll')
 fixture=image/'tests/Lokad.Lython.WorkerFixture/bin/Release'/tfm
 shutil.copytree(work/'tests/Lokad.Lython.WorkerFixture/bin/Release'/tfm,fixture,copy_function=shutil.copyfile)
 for n in ['Lokad.Lython.dll','Lokad.Lython.Utf8Regex.dll','Lokad.Utf8Regex.dll','Lokad.Utf8Regex.PythonRe.dll']:
  shutil.copyfile(image/n,fixture/n);assert (image/n).read_bytes()==(fixture/n).read_bytes()
 (image/'Directory.Build.props').write_text('<Project/>\n',encoding='utf-8',newline='\n')
 shutil.copytree(repo/'tests/Fixtures/Workflows/RegexRewrite',image/'Fixtures/Workflows/RegexRewrite',copy_function=shutil.copyfile,dirs_exist_ok=True)
 images[tfm]={n:sha(image/n)for n in ['Lokad.Lython.dll','Lokad.Lython.Utf8Regex.dll','Lokad.Utf8Regex.dll','Lokad.Utf8Regex.PythonRe.dll','Lokad.Lython.PublicApi.Tests.dll']}
(r/'image-identity.json').write_text(json.dumps(dict(images=images,adapterSHA256=sha(project/'Utf8RegexProvider.cs'),parentAndChildImagesIdentical=True,normalPinUnchanged=True,coreDependenciesUnchanged=True),indent=2)+'\n',encoding='utf-8',newline='\n')
print('Modern bounded-range development adapter and exact parent/child images built for both targets.',flush=True)
