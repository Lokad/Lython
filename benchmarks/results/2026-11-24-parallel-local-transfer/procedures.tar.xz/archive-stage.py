from pathlib import Path

lab = Path(__file__).resolve().parent
prior = lab.with_name('csv-unpack-bindings-20261124')
source = (prior / 'archive.py').read_text(encoding='utf-8')
source = source.replace('benchmarks/results/2026-11-24-csv-unpack-bindings', 'benchmarks/results/2026-11-24-parallel-local-transfer')
source = source.replace("'558bb990f'", "'81444bec1'")
source = source.replace("'identity.json','bindings.json'", "'identity.json','bindings.json','parallel-bindings.json'")
source = source.replace("'prepare.py','stage.py','quiet.py','summarize.py','allocations.py','archive.py','namespace-cpython.txt',",
    "'prepare.py','configure.py','quiet.py','summarize.py','allocations.py','archive.py','archive-stage.py','verified-replicas.json',")
source = source.replace("'comparison/quiet/launch.log','comparison/quiet/verified-replicas.json',",
    "'comparison/quiet/launch.log','jit-check.py','jit-summary.json',")
source = source.replace("assert sum(len(entries) for entries in bindings.values()) == 2",
    """assert sum(len(entries) for entries in bindings.values()) == 2
parallel = read(comparison / 'parallel-bindings.json')
assert parallel['scripts.csv-meter-report.explicit-float'] == [{'scope':'<module>','start':8,'count':3}]
assert sum(len(entries) for entries in parallel.values()) == 1""")
compile(source, 'archive.py', 'exec')
(lab / 'archive.py').write_text(source, encoding='utf-8', newline='\n')
