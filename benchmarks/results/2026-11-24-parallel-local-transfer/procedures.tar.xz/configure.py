from pathlib import Path
import gzip
import hashlib
import json
import subprocess
import tarfile

lab = Path(__file__).resolve().parent
prior = lab.with_name('csv-unpack-bindings-20261124')
repo = lab.parents[3]
comparison = lab / 'comparison'
comparison.mkdir(exist_ok=True)
quiet = comparison / 'quiet'
quiet.mkdir(exist_ok=True)
read = lambda p: json.loads(p.read_text(encoding='utf-8'))
sha = lambda b: hashlib.sha256(b).hexdigest()
digest = lambda p: sha(p.read_bytes())


def write(path, source):
    path.write_text(source, encoding='utf-8', newline='\n')


def save(path, value):
    write(path, json.dumps(value, indent=2) + '\n')


prepare = (prior / 'prepare.py').read_text(encoding='utf-8').replace('99fc6186a','81444bec1')
prepare = prepare.replace("    'src/Lokad.Lython/Runtime/LythonRuntime.Executable.Interpreter.cs',",
    """    'src/Lokad.Lython/Runtime/LythonRuntime.Executable.Interpreter.cs',
    'src/Lokad.Lython/Runtime/LythonRuntime.Executable.Interpreter.Dispatch.cs',
    'src/Lokad.Lython/Runtime/LythonRuntime.Executable.NativePrefix.cs',
    'src/Lokad.Lython/Runtime/LythonRuntime.Executable.Results.cs',""")
prepare = prepare.replace('complete fixed CSV unpack as one private local transfer',
    'complete fixed CSV unpack and parallel assignments with one slot transfer').replace('B1544', 'B1545')
prepare = prepare.replace("for name in names]})", "for name in (names[2], names[1], names[3], names[0])]})")
prepare += '''
assign = [name.strip() for name in opcodes.split(',')].index('ReverseAssignmentValues')
parallel = {row['id']: [dict(scope=code['name'], start=op['_secondaryOperand'], count=op['_primaryOperand'])
    for code in row['codes'] for op in code['tape'] if op['<OpCode>k__BackingField'] == assign]
    for row in tape['rows']}
print(json.dumps(parallel, indent=2), flush=True)
write(comparison / 'parallel-bindings.json', parallel)
assert parallel[names[0]] == [dict(scope='<module>', start=8, count=3)]
assert all(not any(entry['start'] >= 0 for entry in parallel[name]) for name in names[1:])
'''
write(lab / 'prepare.py', prepare)

def stage():
    previous = lab.with_name('native-inline-transfer-20261123')
    archives = 'benchmarks/results/2026-11-24-csv-unpack-bindings/'
    known = lambda name: subprocess.check_output(['git', 'show', 'origin/master:' + archives + name], cwd=repo)
    receipt = json.loads(known('terminal-status.json'))['receipt']
    assert receipt['complete'] and receipt['archivedAndVerifiedUnderLease']
    assert sha(known('observations.tar.xz')) == receipt['archiveSHA256']
    old = sha(gzip.decompress(known('candidate-core.dll.gz')))
    assert old == json.loads(known('identity.json'))['imageFiles']['candidate']['Lokad.Lython.dll']
    donor = 'csv-unpack-bindings-b1544-20261124'
    replicas = [dict(path=donor + '/candidate/Lokad.Lython.dll', sha256=old,
        observationSHA256=receipt['archiveSHA256'], trackedArchive=archives)]
    save(lab / 'verified-replicas.json', replicas)
    worker = (prior / 'comparison/quiet/collect.py').read_text(encoding='utf-8')
    worker = worker.replace("'reference':root/'reference'", f"'reference':root.parent/'{donor}'/'reference'")
    worker = worker.replace('lython-b1544-fixtures', 'lython-b1545-fixtures')
    compile(worker, 'collect.py', 'exec')
    write(quiet / 'collect.py', worker)
    (quiet / 'run.sh').write_bytes((prior / 'comparison/quiet/run.sh').read_bytes())
    assert b'\r' not in (quiet / 'run.sh').read_bytes()
    payload = quiet / 'payload.tar.gz'
    with tarfile.open(payload, 'w:gz') as archive:
        for name in ('identity.json','representative.json','jobs.json'):
            archive.add(comparison / name, arcname=name)
        for name in ('collect.py','run.sh'):
            archive.add(quiet / name, arcname=name)
        archive.add(lab / 'candidate/Lokad.Lython.dll', arcname='candidate-core.dll')
    save(quiet / 'upload.json', dict(root='parallel-local-transfer-b1545-20261124', reference=donor,
        payloadSHA256=digest(payload), payloadBytes=payload.stat().st_size))
    launch = (previous / 'quiet.py').read_text(encoding='utf-8').replace(
        'b1541-native-inline-transfer-20261124','b1545-parallel-local-transfer-20261124').replace('b1541-', 'b1545-')
    launch = launch.replace("reference/'candidate'", "reference/'reference'").replace('seconds=220','seconds=275')
    write(lab / 'quiet.py', launch)
    (lab / 'summarize.py').write_bytes((prior / 'summarize.py').read_bytes())
    (lab / 'allocations.py').write_bytes((prior / 'allocations.py').read_bytes())


if (comparison / 'parallel-bindings.json').is_file():
    stage()
