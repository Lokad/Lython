from pathlib import Path
import hashlib
import json
import os
import re
import shutil
import subprocess

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
notes = lab.parent
tree = repo / '.git/agent-worktrees/csv-unpack-bindings-20261124'
comparison = lab / 'comparison'
comparison.mkdir(exist_ok=True)
read = lambda path: json.loads(path.read_text(encoding='utf-8-sig'))
digest = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()


def write(path, value):
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False) + '\n', encoding='utf-8', newline='\n')


def git(*args, cwd=repo):
    return subprocess.check_output(['git', *args], cwd=cwd).decode().strip()


donor = notes / 'regex-coordinate-tuples-20261124'
proof = read(donor / 'comparison/identity.json')
reference = proof['candidate']
candidate = git('rev-parse', 'HEAD', cwd=tree)
assert reference.startswith('3e5826f7d') and candidate.startswith('81444bec1')
assert not git('status', '--porcelain', cwd=tree)
assert set(git('diff', '--name-only', reference, candidate, '--', 'src').splitlines()) == {
    'src/Lokad.Lython/Frontend/ExecutableScript.cs',
    'src/Lokad.Lython/Frontend/ExecutableStackLayout.cs',
    'src/Lokad.Lython/Runtime/LythonRuntime.Executable.Interpreter.Async.cs',
    'src/Lokad.Lython/Runtime/LythonRuntime.Executable.Interpreter.cs',
    'src/Lokad.Lython/Runtime/LythonRuntime.Executable.Interpreter.Dispatch.cs',
    'src/Lokad.Lython/Runtime/LythonRuntime.Executable.NativePrefix.cs',
    'src/Lokad.Lython/Runtime/LythonRuntime.Executable.Results.cs',
}

current = read(notes / 'current-csv-cpython-20261124/comparison/quiet/representative.json')
related = read(notes / 'marked-cased-split-20261123/comparison/representative.json')
names = ('scripts.csv-meter-report.explicit-float', 'scripts.csv-meter-report.typed-unicode',
    'scripts.csv-invoice.method-policy.quoted-control', 'diagnostic.text-summary.nonlocal-computed-width.large')
lookup = {item['id']: item for item in current['cases'] + related['cases']}
current['cases'] = [lookup[name] for name in names]
write(comparison / 'representative.json', current)
write(comparison / 'jobs.json', {'warm': [[name, 'warm'] for name in (names[2], names[1], names[3], names[0])]})

runtime = Path.home() / '.dotnet11'
dotnet = runtime / 'dotnet.exe'
env = dict(os.environ, DOTNET_ROOT=str(runtime), DOTNET_ROOT_X64=str(runtime))
protocol = repo / 'benchmarks/cpython-worker.py'
assert digest(protocol) == proof['cpythonWorkerSHA256']
core = 'Lokad.Lython.dll'
files = proof['imageFiles']['candidate']
assert len(files) == 32 and all(digest(donor / 'candidate' / name) == expected for name, expected in files.items())
actual, helpers = {}, {}
for role in ('reference', 'candidate'):
    image = lab / role
    image.mkdir(exist_ok=True)
    for name in files:
        source = lab / 'frozen/bin/Lokad.Lython/release_net11.0' / core if role == 'candidate' and name == core else donor / 'candidate' / name
        shutil.copyfile(source, image / name)
    for helper in ('ValidatedAllocation', 'Inspect'):
        for suffix in ('.dll', '.deps.json', '.runtimeconfig.json'):
            name = helper + suffix
            file = notes / 'marked-cased-split-20261123/candidate' / name
            shutil.copyfile(file, image / name)
            helpers[name] = digest(file)
            assert digest(image / name) == helpers[name]
    actual[role] = {name: digest(image / name) for name in files}
    verified = comparison / (role + '-verify.json')
    subprocess.run([dotnet, image / 'Lokad.Lython.Benchmarks.dll', '--compare', 'verify', '--catalog',
        comparison / 'representative.json', '--dotnet', dotnet, '--python', 'C:/Python313/python.exe',
        '--python-worker', protocol, '--out', verified], env=env, check=True, timeout=85)
    result = read(verified)
    assert result['state'] == 'Completed' and result['caseCount'] == len(names)
    assert result['launched']['library']['sha256'] == actual[role][core]
    subprocess.run([dotnet, image / 'Inspect.dll', comparison / 'representative.json', lab / (role + '-tape.json')],
        env=env, check=True, timeout=30)
    assert all(digest(image / name) == expected for name, expected in actual[role].items())
assert files == actual['reference']
assert [name for name in files if actual['reference'][name] != actual['candidate'][name]] == [core]
write(comparison / 'identity.json', dict(sourceRevision=reference, candidate=candidate,
    purpose='B1545 complete fixed CSV unpack and parallel assignments with one slot transfer',
    imageFiles=actual, helperFiles=helpers, cpythonWorkerSHA256=proof['cpythonWorkerSHA256'],
    expectedCPythonSHA256=proof['expectedCPythonSHA256'],
    catalogs={name: {'sha256': digest(comparison / name)} for name in ('representative.json', 'jobs.json')},
    coreSHA256={label: hashes[core] for role, hashes in actual.items() for label in (role, role + '-control')}))

enum = (tree / 'src/Lokad.Lython/Frontend/ExecutableScript.cs').read_text(encoding='utf-8')
opcodes = re.search(r'enum ExecutableOpCode\s*\{(.*?)\}', enum, re.S).group(1)
unpack = [name.strip() for name in opcodes.split(',')].index('ForNextUnpack')
tape = read(lab / 'candidate-tape.json')
assert tape['coreSHA256'] == actual['candidate'][core]
bindings = {row['id']: [dict(scope=code['name'], start=op['_secondaryOperand'],
    name=code['locals'][op['_secondaryOperand']] if op['_secondaryOperand'] >= 0 else None)
    for code in row['codes'] for op in code['tape'] if op['<OpCode>k__BackingField'] == unpack]
    for row in tape['rows']}
print(json.dumps(bindings, indent=2), flush=True)
write(comparison / 'bindings.json', bindings)
assert all(sum(entry['start'] >= 0 for entry in bindings[name]) == 1 for name in names[:2])
assert all(not any(entry['start'] >= 0 for entry in bindings[name]) for name in names[2:])

assign = [name.strip() for name in opcodes.split(',')].index('ReverseAssignmentValues')
parallel = {row['id']: [dict(scope=code['name'], start=op['_secondaryOperand'], count=op['_primaryOperand'])
    for code in row['codes'] for op in code['tape'] if op['<OpCode>k__BackingField'] == assign]
    for row in tape['rows']}
print(json.dumps(parallel, indent=2), flush=True)
write(comparison / 'parallel-bindings.json', parallel)
assert parallel[names[0]] == [dict(scope='<module>', start=8, count=3)]
assert all(not any(entry['start'] >= 0 for entry in parallel[name]) for name in names[1:])
