cd /home/lokad/lython-bench-checks/utf8-byte-ownership-b705-20261113
python3 -u collect.py > collection.log 2>&1
code=$?
printf "%s\n" "$code" > exit-code.txt
exit "$code"
