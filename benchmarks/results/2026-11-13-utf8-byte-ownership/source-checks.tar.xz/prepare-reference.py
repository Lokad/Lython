from pathlib import Path
import hashlib,json,os,shutil,subprocess,tarfile
r=Path(__file__).parent
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
assert head.startswith('7db788d7')
prior=r.parent/'dictionary-boundaries-r331'
old=json.loads((prior/'candidate-identity.json').read_text(encoding='utf-8'))
sources={p:sha(p)for p in old['sources']}
assert [p for p in sources if sources[p]!=old['sources'][p]]==['src/Lokad.Lython/Runtime/LythonRuntime.ElementTreeModule.cs']
p=Path('PLAN.md');s=p.read_text(encoding='utf-8')
s=s.replace('| Retained correctness change; focused qualified | R333','| Committed correctness change; focused qualified | R3337db788d7')
s=s.replace('   bytes.decode/str(bytes,encoding) and XML still copy a whole valid UTF8 payload;\n   JSON already validates then borrows same-command bytes. Consolidate strict',
'''   whole-array bytes.decode/str(bytes,encoding) already share the physical array
   but fund its payload again. BOM/sliced XML still copies. Correct the initial
   copy hypothesis: deduplicate same-owner funding and eliminate sliced payload
   copies; no ordinary whole-array allocation gain is predicted. JSON already
   validates/borrows same-command bytes. Consolidate strict''')
s=s.replace('   the common binary-text/XML payload copy; preserve other codecs/error modes,',
'''   sliced binary-text/XML payload copy. Unrelated-owner byte decoding must retain
   its current funded array adoption rather than gaining a new physical copy.
   Preserve other codecs/error modes,''')
s=s.replace('Freeze R333 reference before editing.','Reference freeze from R333 precedes editing; full qualification is batched.')
p.write_text(s,encoding='utf-8',newline='\n')
env=dict(os.environ);env['DOTNET_ROOT']='C:/Users/JoannesVermorel/.dotnet11';env['PATH']=env['DOTNET_ROOT']+';C:/Python313;'+env['PATH']
with(r/'reference-build.log').open('wb')as log:done=subprocess.run([env['DOTNET_ROOT']+'/dotnet.exe','build','src/Lokad.Lython/Lokad.Lython.csproj','-c','Release','-f','net11.0','--no-restore','--no-incremental','--disable-build-servers','-m:1'],env=env,stdout=log,stderr=subprocess.STDOUT,timeout=180)
assert done.returncode==0,(r/'reference-build.log').read_text(encoding='utf-8')[-3000:]
assert sources=={p:sha(p)for p in sources}
out=r/'reference';out.mkdir()
for p in(prior/'candidate').iterdir():
    if p.is_file():shutil.copyfile(p,out/p.name)
shutil.copyfile('src/Lokad.Lython/bin/Release/net11.0/Lokad.Lython.dll',out/'Lokad.Lython.dll')
shutil.copyfile(out/'Lokad.Lython.dll',r/'reference-core.dll')
identity=dict(head=head,coreSHA256=sha(out/'Lokad.Lython.dll'),sources=sources,productionFiles=len(sources),auxiliaryFiles={p.name:sha(p)for p in out.iterdir()if p.is_file()and p.name!='Lokad.Lython.dll'},qualified=False,qualification='R333 focused semantics/ownership/cancellation; last full delivery R331',sourceHypothesisCorrection='Whole arrays already avoid physical copy but pay again; sliced/BOM windows copy. Keep unrelated-owner adoption unchanged.')
(r/'reference-identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8')
with tarfile.open(r/'reference-sources.tar.xz','w:xz')as t:
    for name in sources:t.add(name,arcname=name)
print('Frozen R333 reference',identity['coreSHA256'],len(sources),'inputs; physical-copy hypothesis narrowed before prototype.',flush=True)
