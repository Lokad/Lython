from pathlib import Path
p=Path('PLAN.md');s=p.read_text(encoding='utf-8')
s=s.replace('R3337db788d7','R333 runtime7db788d7')
s=s.replace('**R334 selected:','**R334 active:')
at=s.index('| Current external comparison,')
s=s[:at]+'''| Active uncommitted prototype | R334 frozen0b2929ca vs R333/a1f31dcd. One strict UTF8 bytes boundary shares existing funding for same-owner inputs; BOM slices avoid physical copies. JSON's duplicate validation loop is removed, unrelated-owner/other-codec paths retained.45internal/218public focused per actual11/10 pass; separate owner/ElementTree checks running. Whole binary XML/report allocation−1.87..−1.88%, text control flat; CPU/fresh evidence pending B705, one300s owner. No retained-design/CPU claim yet. |
'''+s[at:]
s=s.replace('   Reference freeze from R333 precedes editing; full qualification is batched.','''   R333 referencea1f31dcd and candidate0b2929ca are frozen with578inputs and fixed
   worker/adapter hashes.45internal/218public cases per actual11/10 pass; two fresh
   processes/source establish binary XML whole-run allocation−1.87..−1.88%, text
   control flat. B705runs four affected/control warm/fresh jobs under300s with
   existing tooling; CPU uncertainty remains. Full qualification batches R333/R334.''')
# The selection text may still contain its earlier unindented final sentence.
s=s.replace('Reference freeze from R333 precedes editing; full qualification is batched.','''Referencea1f31dcd/candidate0b2929ca are frozen with578inputs and fixed worker/adapter
   hashes.45internal/218public cases per actual11/10 pass; allocation−1.87..−1.88%
   in two complete binary XML/report scripts, text control flat. B705runs four
   affected/control warm/fresh jobs under300s; CPU/fresh uncertainty remains.
   Full qualification batches R333/R334.''')
p.write_text(s,encoding='utf-8',newline='\n')
print('Prototype vs committed delivery states and established allocation/remaining CPU uncertainty recorded.',flush=True)
