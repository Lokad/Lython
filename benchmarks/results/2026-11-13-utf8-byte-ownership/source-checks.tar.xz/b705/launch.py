from pathlib import Path
import ast,base64,datetime,hashlib,json,subprocess
r=Path(__file__).parent
config=json.loads((r/'config.json').read_text(encoding='utf-8'))
frozen=json.loads((r.parent/'candidate-identity.json').read_text(encoding='utf-8'))
assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==sha for p,sha in frozen['sources'].items())
code=r'''from pathlib import Path
import ast,fcntl,hashlib,io,json,os,shutil,subprocess,sys,tarfile
config=CONFIG
base=Path('/home/lokad/lython-bench-checks').resolve();root=Path(config['root']);source=Path(config['sourceRoot'])
assert root.parent==base and source.parent==base and source.resolve()==source and not root.exists()
digest=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
with(base/'comparison-vm.lock').open('a')as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert not(source/'guest-fixtures').exists()
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[d]otnet.*complete-jobs.dll|[p]erf record|[p]ython3.*cpython-worker.py'],capture_output=True).returncode==1
 for name,sha in config['identity']['candidateAuxiliaryFiles'].items():assert digest(source/'candidate'/name)==sha
 assert digest(source/'candidate/Lokad.Lython.dll')=='798edc1d2a6a080a44feafda0b21f699129c5ee6a349dc30a5c0f756b99ebd4d'
 payload=sys.stdin.buffer.read(config['payloadBytes']+1)
 assert len(payload)==config['payloadBytes']and hashlib.sha256(payload).hexdigest()==config['payloadSHA256']
 before=shutil.disk_usage(base).free;assert before>254*1024*1024+config['unpackedBytes']
 root.mkdir()
 with tarfile.open(fileobj=io.BytesIO(payload),mode='r:gz')as t:
  assert set(t.getnames())=={'identity.json','representative.json','collect.py','archive-owned.py','run.sh','candidate-core.dll','reference-core.dll','source-identity.json','reference-source-identity.json'}
  t.extractall(root,filter='data')
 os.link(source/'cpython-worker.py',root/'cpython-worker.py')
 for role in ['reference','candidate']:
  (root/role).mkdir()
  for name,sha in config['identity'][role+'AuxiliaryFiles'].items():
   assert digest(source/'candidate'/name)==sha;os.link(source/'candidate'/name,root/role/name)
  assert digest(root/(role+'-core.dll'))==config['identity']['coreSHA256'][role]
  os.link(root/(role+'-core.dll'),root/role/'Lokad.Lython.dll')
 assert digest(root/'representative.json')==config['identity']['catalogSHA256']
 for name in ['collect.py','archive-owned.py']:ast.parse((root/name).read_text())
 subprocess.run(['/bin/sh','-n',str(root/'run.sh')],check=True)
 after=shutil.disk_usage(base).free;assert after>254*1024*1024
 (root/'space-preflight.json').write_text(json.dumps(dict(freshIdleLease=True,beforeFreeBytes=before,afterStagingFreeBytes=after,osFloorMiB=240,evidenceHeadroomMiB=12,additionalArchiveHeadroomMiB=2,noRetirement=True))+'\n')
 fixture=root/'guest-fixtures';fixture.mkdir()
 subprocess.run(['sudo','-n','mount','-t','tmpfs','-o','size=128m,mode=0700,uid=lokad,gid=lokad','lython-b705-fixtures',str(fixture)],check=True)
try:subprocess.run(['sudo','-n','systemd-run','--unit='+config['unit'],'--property=User=lokad','--property=WorkingDirectory='+str(root),'--property=RuntimeMaxSec=300','--property=TimeoutStopSec=30','--property=KillMode=control-group','/bin/sh',str(root/'run.sh')],check=True)
except BaseException:
 subprocess.run(['sudo','-n','umount',str(fixture)],check=True);fixture.rmdir();raise
print(subprocess.check_output(['systemctl','show',config['unit']+'.service','--property=ActiveState,MainPID,RuntimeMaxUSec'],text=True))
'''.replace('CONFIG',repr(config))
ast.parse(code);(r/'launch-command.py').write_text(code,encoding='utf-8',newline='\n')
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
command="python3 -c 'import base64;exec(base64.b64decode(\""+base64.b64encode(code.encode()).decode()+"\"))'"
done=subprocess.run(ssh+[command],input=(r/'payload.tgz').read_bytes(),capture_output=True)
(r/'launch.log').write_bytes(done.stdout+done.stderr);print((done.stdout+done.stderr).decode(),flush=True);assert done.returncode==0
now=datetime.datetime.now(datetime.timezone.utc)
(r/'observe-not-before.json').write_text(json.dumps(dict(startedUTC=now.isoformat(),doNotObserveBeforeUTC=(now+datetime.timedelta(seconds=240)).isoformat(),ownerSeconds=300,stopSeconds=30),indent=2)+'\n',encoding='utf-8')
