from pathlib import Path
import hashlib,json,os,shutil,subprocess,tarfile
r=Path(__file__).parent
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
reference=json.loads((r/'reference-identity.json').read_text(encoding='utf-8'))
sources={p:sha(p)for p in reference['sources']}
expected=['src/Lokad.Lython/Runtime/LythonRuntime.Builtins.cs','src/Lokad.Lython/Runtime/LythonRuntime.BytesMembers.cs','src/Lokad.Lython/Runtime/LythonRuntime.ElementTreeModule.cs','src/Lokad.Lython/Runtime/LythonRuntime.Json.Input.cs','src/Lokad.Lython/Runtime/LythonRuntime.TextCodec.cs']
assert sorted(p for p in sources if sources[p]!=reference['sources'][p])==sorted(expected)
env=dict(os.environ);env['DOTNET_ROOT']='C:/Users/JoannesVermorel/.dotnet11';env['PATH']=env['DOTNET_ROOT']+';C:/Python313;'+env['PATH']
with(r/'candidate-build.log').open('wb')as log:done=subprocess.run([env['DOTNET_ROOT']+'/dotnet.exe','build','src/Lokad.Lython/Lokad.Lython.csproj','-c','Release','-f','net11.0','--no-restore','--no-incremental','--disable-build-servers','-m:1'],env=env,stdout=log,stderr=subprocess.STDOUT,timeout=180)
assert done.returncode==0,(r/'candidate-build.log').read_text(encoding='utf-8')[-3000:]
assert sources=={p:sha(p)for p in sources}
out=r/'candidate';out.mkdir()
for p in(r/'reference').iterdir():
    if p.is_file():shutil.copyfile(p,out/p.name)
shutil.copyfile('src/Lokad.Lython/bin/Release/net11.0/Lokad.Lython.dll',out/'Lokad.Lython.dll')
shutil.copyfile(out/'Lokad.Lython.dll',r/'candidate-core.dll')
identity=dict(headBeforeCommit=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),coreSHA256={'reference':reference['coreSHA256'],'candidate':sha(out/'Lokad.Lython.dll')},sources=sources,productionFiles=len(sources),auxiliaryFiles={role:{p.name:sha(p)for p in(r/role).iterdir()if p.is_file()and p.name!='Lokad.Lython.dll'}for role in ['reference','candidate']},qualified=False,sourceAndScriptDifferIntentionally=False)
assert identity['auxiliaryFiles']['candidate']==identity['auxiliaryFiles']['reference']
(r/'candidate-identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8')
with tarfile.open(r/'candidate-sources.tar.xz','w:xz')as t:
    for name in sources:t.add(name,arcname=name)
print('Frozen candidate',identity['coreSHA256'],len(sources),'inputs; worker/adapter bytes identical.',flush=True)
