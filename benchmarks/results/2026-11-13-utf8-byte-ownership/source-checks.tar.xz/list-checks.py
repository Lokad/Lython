from pathlib import Path
import json,subprocess
r=Path(__file__).parent
command=['C:/Users/JoannesVermorel/.dotnet11/dotnet.exe','test','tests/Lokad.Lython.Tests/Lokad.Lython.Tests.csproj','-c','Release','-f','net11.0','--no-build','--list-tests','--filter','FullyQualifiedName~Utf8ByteDecodeOwnershipTests|FullyQualifiedName~JsonByteOwnershipTests|FullyQualifiedName~TextCodecAccountingTests|FullyQualifiedName~Xml|FullyQualifiedName~ElementTree']
done=subprocess.run(command,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=30)
(r/'distinct-internal-cases.log').write_bytes(done.stdout)
assert done.returncode==0,done.stdout.decode('utf-8',errors='replace')[-2000:]
rows=[line.strip()for line in done.stdout.decode('utf-8').splitlines()if line.strip().startswith('Lokad.Lython.Tests.')]
assert len(rows)==len(set(rows))
(r/'distinct-internal-cases.json').write_text(json.dumps(dict(count=len(rows),cases=rows),ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print('Distinct matching internal cases:',len(rows),flush=True)
