from pathlib import Path
import ast,hashlib,json,tarfile
r=Path(__file__).parent
out=r/'b705';out.mkdir()
prior=r.parent/'dictionary-boundaries-r331/b702'
source=json.loads((r/'candidate-identity.json').read_text(encoding='utf-8'))
aux=json.loads((prior/'identity.json').read_text(encoding='utf-8'))['candidateAuxiliaryFiles']
assert all(source['auxiliaryFiles']['candidate'][name]==sha for name,sha in aux.items())
identity=dict(sourceRevision='R334 frozen'+source['coreSHA256']['candidate'][:8]+' vs committedR333/7db788d7 frozena1f31dcd; last full delivery is R331',purpose='Complete binary XML/report scripts: automatic and explicit UTF8 BOM decode, explicit compile-to-result and unchanged text XML control; no CPython CPU comparison',coreSHA256={label:source['coreSHA256']['candidate'if label.startswith('candidate')else'reference']for label in ['reference','candidate','reference-control','candidate-control']},candidateAuxiliaryFiles=aux,referenceAuxiliaryFiles=aux,catalogSHA256=hashlib.sha256((r/'catalog.json').read_bytes()).hexdigest(),referenceCase='scripts.xml-settings.bytes.large',variantCase='scripts.xml-settings.bytes.large',controlCase='scripts.xml-settings.large',sourceAndScriptDifferIntentionally=False)
(out/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8')
oldroot='/home/lokad/lython-bench-checks/dictionary-boundaries-b702-20261113';root='/home/lokad/lython-bench-checks/utf8-byte-ownership-b705-20261113';unit='lython-b705-utf8-byte-ownership-20261113'
jobs=[['scripts.xml-settings.bytes.large','warm'],['scripts.xml-settings.decode.large','warm'],['scripts.xml-settings.decode.large','compile-run'],['scripts.xml-settings.large','warm']]
catalog=json.loads((r/'catalog.json').read_text(encoding='utf-8'))
assert all(case in {c['id']for c in catalog['cases']}for case,lane in jobs)
for name in ['collect.py','archive-owned.py','run.sh','retrieve.py','summarize.py']:
    s=(prior/name).read_text(encoding='utf-8').replace(oldroot,root).replace('lython-b702-dictionary-boundaries-20261113',unit).replace('B702','B705')
    for old,new in [("len(raw['jobs'])==2","len(raw['jobs'])==4"),("['jobs']==2","['jobs']==4"),('jobs=2','jobs=4')]:s=s.replace(old,new)
    if name=='collect.py':
        a=s.index('jobs=');b=s.index('\nenv =',a)
        s=s[:a]+'jobs='+repr(jobs)+'\nassert len(jobs)==4 and all(case in cases for case,lane in jobs)\n'+s[b:]
        s=s.replace('warmupSeconds=12, capturedWarmupSeconds=12, compilationWarmupSeconds=5, targetBatchSeconds=1.0','warmupSeconds=8, capturedWarmupSeconds=8, compilationWarmupSeconds=8, targetBatchSeconds=.5')
        s=s.replace('time.monotonic()-started < 120','time.monotonic()-started < 240').replace('time.monotonic()+12','time.monotonic()+8').replace('count*1.0/max(seconds','count*.5/max(seconds')
    if name=='retrieve.py':s=s.replace("['elapsedSeconds']<180","['elapsedSeconds']<300")
    if name.endswith('.py'):ast.parse(s)
    (out/name).write_text(s,encoding='utf-8',newline='\n')
with tarfile.open(out/'payload.tgz','w:gz')as t:
    for name in ['identity.json','collect.py','archive-owned.py','run.sh']:t.add(out/name,arcname=name)
    for name,arc in [('catalog.json','representative.json'),('candidate-core.dll','candidate-core.dll'),('reference-core.dll','reference-core.dll'),('candidate-identity.json','source-identity.json'),('reference-identity.json','reference-source-identity.json')]:t.add(r/name,arcname=arc)
with tarfile.open(out/'payload.tgz')as t:unpacked=sum(m.size for m in t.getmembers())
config=dict(root=root,sourceRoot='/home/lokad/lython-bench-checks/current-external-b704-20261113',unit=unit,identity=identity,payloadBytes=(out/'payload.tgz').stat().st_size,payloadSHA256=hashlib.sha256((out/'payload.tgz').read_bytes()).hexdigest(),unpackedBytes=unpacked)
(out/'config.json').write_text(json.dumps(config,indent=2)+'\n',encoding='utf-8')
print('Prepared four bounded source-pair phase jobs with identical guest sources/fixtures per case; no producer requalification.',flush=True)
