from pathlib import Path
import subprocess
r=Path(__file__).parent
for framework in ['net11.0','net10.0']:
    command=['C:/Users/JoannesVermorel/.dotnet11/dotnet.exe','test','tests/Lokad.Lython.Tests/Lokad.Lython.Tests.csproj','-c','Release','-f',framework,'--no-restore','--filter','FullyQualifiedName~Utf8ByteDecodeOwnershipTests|FullyQualifiedName~ElementTree','--logger','console;verbosity=minimal']
    with(r/('second-owner-'+framework+'.log')).open('wb')as log:done=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,timeout=180)
    print(framework,done.returncode,(r/('second-owner-'+framework+'.log')).read_text(encoding='utf-8')[-1500:],flush=True)
    assert done.returncode==0
