from pathlib import Path
import hashlib,json,re,shutil,tarfile
r=Path(__file__).parent
identity=json.loads((r/'candidate-identity.json').read_text(encoding='utf-8'))
assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==sha for p,sha in identity['sources'].items())
allocation=json.loads((r/'allocation-summary.json').read_text(encoding='utf-8'))
timing=json.loads((r/'b705/summary.json').read_text(encoding='utf-8'))
receipt=json.loads((r/'b705/archive-receipt.json').read_text(encoding='utf-8'))
assert timing['complete'] and timing['jobs']==4 and receipt['allWorkersJoined'] and receipt['guestFixturesRemoved']
assert hashlib.sha256((r/'b705/observations.tgz').read_bytes()).hexdigest()==receipt['archiveSHA256']
counts={}
for name in ['internal-net11.0.log','internal-net10.0.log','public-net11.0.log','public-net10.0.log','second-owner-net11.0.log','second-owner-net10.0.log']:
    data=(r/name).read_text(encoding='utf-8');match=re.search(r'Passed!.*?Failed:\s+0, Passed:\s+(\d+)',data);assert match,name
    counts[name]=int(match[1])
assert list(counts.values())==[45,45,218,218,25,25]
out=Path('benchmarks/results/2026-11-13-utf8-byte-ownership');out.mkdir()
for name in ['allocation-summary.json','candidate-identity.json','reference-identity.json','workload-python-controls.json']:shutil.copyfile(r/name,out/name)
for name in ['summary.json','archive-receipt.json','terminal-status.json','observations.tgz']:shutil.copyfile(r/'b705'/name,out/name)
with tarfile.open(out/'source-checks.tar.xz','w:xz')as t:
    for name in ['prepare-reference.py','reference-build.log','reference-core.dll','reference-sources.tar.xz','freeze-candidate.py','candidate-build.log','candidate-core.dll','candidate-sources.tar.xz','check-internal.py','check-public.py','check-second-owner.py','prepare-catalog.py','catalog.json','workload-python-controls.json','prepare-allocation.py','measure-allocation.py','allocation-summary.json','allocation-reference-catalog.json','allocation-candidate-catalog.json','prepare-comparison.py','update-progress.py','save.py']+list(counts):t.add(r/name,arcname=name)
    for role in ['candidate','reference']:
        for index in [0,1]:
            for suffix in ['json','log']:
                name=role+'-allocation-'+str(index)+'.'+suffix;t.add(r/name,arcname=name)
    for name in ['src/Lokad.Lython/Runtime/LythonRuntime.TextCodec.cs','tests/Lokad.Lython.Tests/Utf8ByteDecodeOwnershipTests.cs','tests/Lokad.Lython.PublicApi.Tests/Utf8ByteDecodeTests.cs']:t.add(name,arcname=name)
    for name in ['identity.json','config.json','collect.py','archive-owned.py','run.sh','retrieve.py','summarize.py','launch.py','launch-command.py','launch.log','observe-not-before.json','extraction.json']:t.add(r/'b705'/name,arcname='b705/'+name)
    for name in ['Program.cs','Allocation.csproj']:t.add(r.parent/'word-buffer-loan-r324/allocation'/name,arcname='allocation-tool/'+name)
    for p in(r/'reference').glob('Allocation.*'):t.add(p,arcname='allocation-tool/'+p.name)
table='| Whole script / phase | Elapsed change | Wider CPU change | Candidate/reference process spread | Max IQR |\n| --- | ---: | ---: | ---: | ---: |\n'
for row in timing['timing']:
    elapsed=row['lythonSourcePairElapsedPercent'];cpu=row['lythonSourcePairWiderCpuPercent']
    label=row['case'].removeprefix('scripts.').removesuffix('.large')+' /'+row['lane']
    table+=f"|{label}|{min(elapsed):+.2f}..{max(elapsed):+.2f}%|{min(cpu):+.2f}..{max(cpu):+.2f}%|{row['candidateProcessSpreadPercent']:.2f}/{row['referenceProcessSpreadPercent']:.2f}%|{max(row['iqrPercent'].values()):.2f}%|\n"
readme=f'''# Shared UTF8 byte decoding ownership

2026-11-13UTC, R334 frozen0b2929ca against committedR333/7db788d7/frozena1f31dcd.
Retain this as an ownership/construction simplification, **not a CPU improvement**.
The last full qualification is R331; combined R333/R334 delivery is pending.

One strict scalar-UTF8 boundary serves owned bytes.decode/str(bytes,encoding),
JSON and XML. It reuses existing immutable PyBytes windows and private-input
retention, admitting the new text shell while keeping source capacity funded.
JSON's duplicate validation loop disappears. No new owner, ledger, pool, cache,
quota, option or unsafe code is introduced. Other codecs/error modes and
unrelated-owner adoption remain on their existing paths.

The initial source hypothesis is corrected before editing: whole-array decoding
already avoided a physical copy but charged the same capacity again. Sliced/BOM
input copied. The final change removes duplicate same-owner funding and sliced
copies. Once shared, payload funding can remain conservative until command-owner
cleanup even if a temporary text value is withdrawn. Tiny-budget thresholds are
not a compatibility promise; no live alias is refunded.

## Focused correctness and allocation

45internal/218public focused Release cases pass per actual.NET11/10, then25
owner/ElementTree cases per target (10 overlap the first group;60distinct internal
cases total). They cover same/unowned/separate owners, cleanup to baseline,
admission refusal/cancellation before publication, scalar chunk edges, retained
results across two executions, actual pending I/O, encoding/error/newline behavior
and the XML key-protocol correction. Two isolated CPython3.13.2 complete-script
controls agree on stdout/files and unchanged input.

Two fresh isolated processes/source, existing allocation harness,4s warmups and
five64-invocation batches: automatic binary XML allocates38,409–38,414B less,
about1.874%; explicit UTF8-BOM decoding38,483–38,484B less, about1.877%.
Unchanged text control is flat (0..+0.00056%). Full-reset/I/O/output validation/
result cleanup are included; compilation/startup/final caches excluded. Process-wide
CLR allocation counters include incidental/JIT traffic; no forced GC or elapsed
gain is inferred. Borrowed-capacity assertions independently prove the funding change.

## One bounded source-pair comparison

{table}
B705completes{timing['elapsedSeconds']:.3f}s/all gates under one300s owner, quiet
AzureF4as_v7/Ubuntu24.04.4/.NET11RC3, ordinary workstation GC/tiering, fixed B685
workeracda3ef3/optional adapter0.4. Two independent processes per source/job,
eight-second full-request wall warmups, five rotating0.5s wall-sized batches.
Each case has identical source/fixture/output bytes across revisions. The two
affected scripts read the same512-setting XML file as binary UTF8+BOM, then select
fields and write a report; text control retains its original source/fixture.

Guest clocks include mediated RAM-file I/O, complete stdout/file validation and
prior-result cleanup. Compile-to-result adds compilation/compiled-owner disposal;
startup, fixture reset/protocol and final cache teardown are excluded. Wider CPU
includes reset/protocol. Ranges pair process medians, not confidence intervals.
There is no new CPython timing, embedding-tail or live-heap comparison.

Automatic bytes has a small consistent warm cost (+1.32..+2.35%, roughly12–21µs),
with supporting wider CPU adversity. Explicit warm is mixed; fresh elapsed has a
small +0.21..+0.35% cost and widerCPU+0.83..+1.86%. Text control remains flat.
Accept this recorded CPU debt for the common ownership boundary and copy/funding
removal. No further unchanged retiming at this checkpoint; materially different
refinement remains possible. This does not complete the performance objective.

All image/source/golden/balance/quiet/join/archive gates pass. Raw observations
stay persistent; users join and RAM fixtures unmount before the archive is
independently SHA-verified. No working evidence/image retired or disk floor
changed; no VM users remain. Publication/tagging remain postponed.

[Allocation](allocation-summary.json), [timing/wider CPU](summary.json),
[raw](observations.tgz), [exact frozen source/bits and checks](source-checks.tar.xz).
'''
(out/'README.md').write_text(readme,encoding='utf-8',newline='\n')
p=Path('benchmarks/EXPERIMENTS.md')
with p.open('a',encoding='utf-8',newline='\n')as f:f.write('''
## R334 — shared strict UTF8 byte ownership

[Retained source pair](results/2026-11-13-utf8-byte-ownership/README.md) removes
duplicate same-owner capacity funding and BOM-slice copies with the existing
window mechanism. JSON's duplicate validation loop disappears. The initial
whole-array physical-copy hypothesis is corrected before editing. Other owners,
codecs and error modes retain their paths; no new ownership infrastructure.
60distinct internal/218public focused cases pass per actual11/10. Complete binary
XML/report allocation falls1.87–1.88%; text control flat. B705four jobs finish
188.411s/all gates: automatic binary XML warm is1.32–2.35%slower with supporting
wider CPU; explicit warm mixed and fresh has small cost. Retain consolidation
with explicit CPU debt, no speedup/tail claim or unchanged retiming. All users
join, fixtures unmount and persistent archive SHA verifies; no evidence retirement
or floor change. Batch full R333/R334 delivery next; broader objective stays open.
''')
p=Path('PLAN.md');s=p.read_text(encoding='utf-8')
a=s.index('| Active uncommitted prototype | R334');b=s.index('\n',a)
s=s[:a]+'''| Retained runtime change; focused qualified | R334 frozen0b2929ca vs R333/a1f31dcd,578inputs.60distinct internal/218public cases each actual Release11/10. Binary XML/report allocation−1.87..−1.88%, native text control flat. B705four jobs/188.411s/all gates: automatic warm+1.32..+2.35% with wider CPU adversity; explicit warm mixed, fresh small cost. Retain one funding/validation boundary with explicit CPU debt, no speedup claim. Combined R333/R334 full delivery next. [Evidence](benchmarks/results/2026-11-13-utf8-byte-ownership/README.md). |'''+s[b:]
s=s.replace('**R334 active:','**R334 retained; full delivery next:**')
s=s.replace('   Full qualification batches R333/R334.','''   B705completes188.411s/all gates. Automatic bytes warm+1.32..+2.35% with wider
   CPU adversity, explicit warm mixed, fresh+0.21..+0.35%. Accept this small recorded
   debt for single-payload funding and copy removal; no CPU improvement claim or
   unchanged retiming.60distinct internal/218public cases per actual11/10 pass.
   Full qualification batches R333/R334.''')
p.write_text(s,encoding='utf-8',newline='\n')
print('R334 retained for ownership/copy deletion; adverse CPU evidence and debt preserved, full delivery next.',flush=True)
