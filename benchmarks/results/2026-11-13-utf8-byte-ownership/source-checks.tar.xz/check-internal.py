from pathlib import Path
import subprocess,time
r=Path(__file__).parent
for framework in ['net11.0','net10.0']:
    command=['C:/Users/JoannesVermorel/.dotnet11/dotnet.exe','test','tests/Lokad.Lython.Tests/Lokad.Lython.Tests.csproj','-c','Release','-f',framework,'--no-restore','--filter','FullyQualifiedName~Utf8ByteDecodeOwnershipTests|FullyQualifiedName~JsonByteOwnershipTests|FullyQualifiedName~TextCodecAccountingTests|FullyQualifiedName~Xml','--logger','console;verbosity=minimal']
    started=time.monotonic()
    with(r/('internal-'+framework+'.log')).open('wb')as log:done=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,timeout=240)
    print(framework,done.returncode,round(time.monotonic()-started,3),(r/('internal-'+framework+'.log')).read_text(encoding='utf-8')[-2300:],flush=True)
    assert done.returncode==0
