from pathlib import Path
import ast
r=Path(__file__).parent
s=(r.parent/'xml-traversal-r330/native/measure-allocation.py').read_text(encoding='utf-8')
s=s.replace('sourceAndScriptDifferIntentionally=True','sourceAndScriptDifferIntentionally=False')
ast.parse(s)
(r/'measure-allocation.py').write_text(s,encoding='utf-8',newline='\n')
assert all((r/role/'Allocation.dll').exists()for role in ['reference','candidate'])
print('Reuse existing whole-script allocation diagnostic; four fresh processes, no forced GC or CPU claim.',flush=True)
