from pathlib import Path
import base64,copy,hashlib,json,subprocess,tempfile
r=Path(__file__).parent
catalog=json.loads((r.parent/'xml-select-r329/catalog.json').read_text(encoding='utf-8'))
control=next(c for c in catalog['cases']if c['id']=='scripts.xml-settings.large')
cases=[];checks=[]
for label,explicit in [('bytes',False),('decode',True)]:
    c=copy.deepcopy(control)
    source=c['source'].replace("with open('input.xml') as source:","with open('input.xml','rb') as source:")
    if explicit:source=source.replace('ET.fromstring(source.read())',"ET.fromstring(source.read().decode('utf-8-sig'))")
    assert source!=c['source']
    fixture=json.loads(c['fixtureJson'])
    data=b'\xef\xbb\xbf'+base64.b64decode(fixture['inputFiles']['input.xml'])
    fixture['inputFiles']['input.xml']=base64.b64encode(data).decode()
    c.update(id='scripts.xml-settings.'+label+'.large',source=source,sourceUtf8Bytes=len(source.encode()),sourceSha256=hashlib.sha256(source.encode()).hexdigest(),fixtureJson=json.dumps(fixture,separators=(',',':'),ensure_ascii=False))
    c['fixtureSha256']=hashlib.sha256(c['fixtureJson'].encode()).hexdigest()
    with tempfile.TemporaryDirectory(prefix='lython-xml-byte-control-',dir=r.resolve())as folder:
        work=Path(folder).resolve();assert work.parent==r.resolve()and work.name.startswith('lython-xml-byte-control-')
        for name,payload in fixture['inputFiles'].items():(work/name).write_bytes(base64.b64decode(payload))
        done=subprocess.run(['C:/Python313/python.exe','-I','-S','-X','utf8','-c',source],cwd=work,capture_output=True,text=True,encoding='utf-8',timeout=15)
        assert done.returncode==0 and not done.stderr and done.stdout==c['expectedOutput'],(label,done.stdout,done.stderr)
        for name,payload in fixture['outputFiles'].items():assert(work/name).read_bytes()==base64.b64decode(payload)
        assert(work/'input.xml').read_bytes()==data
    cases.append(c);checks.append(dict(case=c['id'],sourceSHA256=c['sourceSha256'],fixtureSHA256=c['fixtureSha256'],inputBytes=len(data),output=done.stdout,exactFilesAndUnchangedInput=True))
catalog['cases']=[*cases,control]
(r/'catalog.json').write_text(json.dumps(catalog,separators=(',',':'),ensure_ascii=False)+'\n',encoding='utf-8')
for role in ['candidate','reference']:(r/('allocation-'+role+'-catalog.json')).write_bytes((r/'catalog.json').read_bytes())
(r/'workload-python-controls.json').write_text(json.dumps(dict(reference='CPython3.13.2',checks=checks,unchangedControl=control['id'],timingNotMeasured=True),indent=2)+'\n',encoding='utf-8')
print('Two complete binary XML/report scripts match isolated Python; unchanged text XML control retained.',flush=True)
