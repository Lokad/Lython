from pathlib import Path
import subprocess,time
r=Path(__file__).parent
for framework in ['net11.0','net10.0']:
    command=['C:/Users/JoannesVermorel/.dotnet11/dotnet.exe','test','tests/Lokad.Lython.PublicApi.Tests/Lokad.Lython.PublicApi.Tests.csproj','-c','Release','-f',framework,'--no-restore','--filter','FullyQualifiedName~Utf8ByteDecodeTests|FullyQualifiedName~JsonByteInputTests|FullyQualifiedName~TextCodecAccountingScenarioTests|FullyQualifiedName~AsciiCodecCompatibilityTests|FullyQualifiedName~Utf16CodecCompatibilityTests|FullyQualifiedName~Latin1CodecTests|FullyQualifiedName~Windows1252CodecCompatibilityTests|FullyQualifiedName~Xml|FullyQualifiedName~ElementTree','--logger','console;verbosity=minimal']
    started=time.monotonic()
    with(r/('public-'+framework+'.log')).open('wb')as log:done=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,timeout=240)
    print(framework,done.returncode,round(time.monotonic()-started,3),(r/('public-'+framework+'.log')).read_text(encoding='utf-8')[-2200:],flush=True)
    assert done.returncode==0
