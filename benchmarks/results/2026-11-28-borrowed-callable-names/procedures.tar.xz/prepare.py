from hashlib import sha256
from pathlib import Path
from shutil import copyfile,copytree
import json
import subprocess

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
prior=lab.parent/'module-callable-reexports-b1929-20261128'
old=prior/'comparison'
pair=lab/'comparison'
read=lambda p:json.loads(p.read_bytes())
digest=lambda p:sha256(p.read_bytes()).hexdigest()
git=lambda *args:subprocess.check_output(['git',*args],cwd=repo)
image=lambda folder:{p.name:digest(p) for p in folder.iterdir()}
hash_text=lambda text:sha256(text.encode('utf-8')).hexdigest()
def write(path,data):
    path.write_text(json.dumps(data,indent=2,ensure_ascii=False)+'\n',encoding='utf-8',newline='\n')

base=git('rev-parse','HEAD').decode().strip()
ref=read(old/'identity.json')
assert sha256(git('diff','--binary',ref['sourceRevision'],base,'--','src')).hexdigest()==ref['sourcePatchSHA256']
patch=git('diff','--binary',base,'--','src')
assert patch.count(b'diff --git ')==2 and b'TryGetKnownModuleCallContract' in patch
(lab/'candidate.patch').write_bytes(patch)
pair.mkdir()
core='Lokad.Lython.dll'
assert image(old/'candidate')==ref['imageFiles']['candidate'] and len(ref['imageFiles']['candidate'])==32
for role in ('reference','candidate'):
    copytree(old/'candidate',pair/role)
compiled=repo/'src/Lokad.Lython/bin/Release/net11.0'/core
assert digest(compiled)!=ref['imageFiles']['candidate'][core]
copyfile(compiled,pair/'candidate'/core)
images={role:image(pair/role) for role in ('reference','candidate')}
assert {name for name in images['reference'] if images['reference'][name]!=images['candidate'][name]}=={core}
for name in ('cpython-worker.py','config.json','workbook.json'):
    copyfile(old/name,pair/name)
    if name.endswith('.json'): assert digest(pair/name)==ref['catalogs'][name]['sha256']
assert digest(pair/'cpython-worker.py')==ref['cpythonWorkerSHA256']
for name in ('workbook-reference.json','workbook.py','workbook-golden.txt'):
    copyfile(prior/name,lab/name)

rows={f'limit {i:02}':float(i)+0.25 for i in range(48)}
body=['import json','import math','from urllib import parse','',
      'def validate(fields):','    normalized = {}']
for key in rows:
    key_text=repr(key)
    body.extend([f'    if math.isfinite(fields[{key_text}]):',
                 f'        normalized[parse.quote({key_text})] = math.floor(fields[{key_text}])'])
body.extend(['    return normalized','',
             'data = json.loads('+repr(json.dumps(rows,separators=(',',':')))+')',
             "print(json.dumps(validate(data), sort_keys=True, separators=(',', ':')))"])
source='\n'.join(body)+'\n'
(lab/'generated.py').write_text(source,encoding='utf-8',newline='\n')
python=ref['cpythonPath']
golden=subprocess.check_output(['wsl',python,'-I','-S','-X','utf8','/mnt/d/code/Lython/'+(lab/'generated.py').relative_to(repo).as_posix()],cwd=repo)
assert len(json.loads(golden))==48
(lab/'generated-golden.json').write_bytes(golden)
fixture='{"size":48,"text":null}'
generated=dict(id='diagnostic.generated-module-configuration',family='diagnostic',category='whole-script',scale='medium',size=48,
             source=source,fixtureJson=fixture,expectedOutput=golden.decode('utf-8'),
             sourceUtf8Bytes=len(source.encode('utf-8')),expectedOutputUtf8Bytes=len(golden),
             fixtureTextUtf8Bytes=0,fixtureTextCodePoints=0,sourceSha256=hash_text(source),
             fixtureSha256=hash_text(fixture),expectedOutputSha256=sha256(golden).hexdigest(),expectedFilesSha256=None)
write(pair/'generated.json',{**read(pair/'config.json'),'cases':[generated]})

catalog=read(old/'representative.json')
config,=read(pair/'config.json')['cases']
control=next(c for c in catalog['cases'] if c['id']=='diagnostic.generated-guarded-report')
workbook,=read(pair/'workbook.json')['cases']
catalog['cases']=[config,generated,control]
write(pair/'ordinary-goldens.json',catalog)
catalog['cases'].append(workbook)
write(pair/'representative.json',catalog)
write(pair/'jobs.json',{'warm':[[config['id'],'compile'],[generated['id'],'compile-run'],
                               [workbook['id'],'compile-run'],[control['id'],'compile']]})
identity=dict(sourceRevision=base,sourcePatchSHA256=digest(lab/'candidate.patch'),imageFiles=images,
    coreSHA256={role+suffix:hashes[core] for role,hashes in images.items() for suffix in ('','-control')},
    cpythonWorkerSHA256=ref['cpythonWorkerSHA256'],expectedCPythonSHA256=ref['expectedCPythonSHA256'],cpythonPath=python,
    purpose='Measure borrowing the canonical callable key instead of allocating a qualified lookup string.',
    catalogs={name:{'sha256':digest(pair/name)} for name in ('representative.json','jobs.json','config.json','workbook.json','generated.json','ordinary-goldens.json')})
write(pair/'identity.json',identity)
collector=(old/'collect.py').read_text(encoding='utf-8').replace('lython-module-reexports-','lython-borrowed-callable-names-')
collector=collector.replace('len(jobs) == 3','len(jobs) == 4')
compile(collector,'collect.py','exec')
(pair/'collect.py').write_text(collector,encoding='utf-8',newline='\n')
run=(old/'run.sh').read_text(encoding='utf-8').replace('/representative.json"','/ordinary-goldens.json"')
assert b'\r' not in run.encode('utf-8')
(pair/'run.sh').write_text(run,encoding='utf-8',newline='\n')
print('Frozen',base,identity['sourcePatchSHA256'])
