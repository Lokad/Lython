import json
import math
from urllib import parse

def validate(fields):
    normalized = {}
    if math.isfinite(fields['limit 00']):
        normalized[parse.quote('limit 00')] = math.floor(fields['limit 00'])
    if math.isfinite(fields['limit 01']):
        normalized[parse.quote('limit 01')] = math.floor(fields['limit 01'])
    if math.isfinite(fields['limit 02']):
        normalized[parse.quote('limit 02')] = math.floor(fields['limit 02'])
    if math.isfinite(fields['limit 03']):
        normalized[parse.quote('limit 03')] = math.floor(fields['limit 03'])
    if math.isfinite(fields['limit 04']):
        normalized[parse.quote('limit 04')] = math.floor(fields['limit 04'])
    if math.isfinite(fields['limit 05']):
        normalized[parse.quote('limit 05')] = math.floor(fields['limit 05'])
    if math.isfinite(fields['limit 06']):
        normalized[parse.quote('limit 06')] = math.floor(fields['limit 06'])
    if math.isfinite(fields['limit 07']):
        normalized[parse.quote('limit 07')] = math.floor(fields['limit 07'])
    if math.isfinite(fields['limit 08']):
        normalized[parse.quote('limit 08')] = math.floor(fields['limit 08'])
    if math.isfinite(fields['limit 09']):
        normalized[parse.quote('limit 09')] = math.floor(fields['limit 09'])
    if math.isfinite(fields['limit 10']):
        normalized[parse.quote('limit 10')] = math.floor(fields['limit 10'])
    if math.isfinite(fields['limit 11']):
        normalized[parse.quote('limit 11')] = math.floor(fields['limit 11'])
    if math.isfinite(fields['limit 12']):
        normalized[parse.quote('limit 12')] = math.floor(fields['limit 12'])
    if math.isfinite(fields['limit 13']):
        normalized[parse.quote('limit 13')] = math.floor(fields['limit 13'])
    if math.isfinite(fields['limit 14']):
        normalized[parse.quote('limit 14')] = math.floor(fields['limit 14'])
    if math.isfinite(fields['limit 15']):
        normalized[parse.quote('limit 15')] = math.floor(fields['limit 15'])
    if math.isfinite(fields['limit 16']):
        normalized[parse.quote('limit 16')] = math.floor(fields['limit 16'])
    if math.isfinite(fields['limit 17']):
        normalized[parse.quote('limit 17')] = math.floor(fields['limit 17'])
    if math.isfinite(fields['limit 18']):
        normalized[parse.quote('limit 18')] = math.floor(fields['limit 18'])
    if math.isfinite(fields['limit 19']):
        normalized[parse.quote('limit 19')] = math.floor(fields['limit 19'])
    if math.isfinite(fields['limit 20']):
        normalized[parse.quote('limit 20')] = math.floor(fields['limit 20'])
    if math.isfinite(fields['limit 21']):
        normalized[parse.quote('limit 21')] = math.floor(fields['limit 21'])
    if math.isfinite(fields['limit 22']):
        normalized[parse.quote('limit 22')] = math.floor(fields['limit 22'])
    if math.isfinite(fields['limit 23']):
        normalized[parse.quote('limit 23')] = math.floor(fields['limit 23'])
    if math.isfinite(fields['limit 24']):
        normalized[parse.quote('limit 24')] = math.floor(fields['limit 24'])
    if math.isfinite(fields['limit 25']):
        normalized[parse.quote('limit 25')] = math.floor(fields['limit 25'])
    if math.isfinite(fields['limit 26']):
        normalized[parse.quote('limit 26')] = math.floor(fields['limit 26'])
    if math.isfinite(fields['limit 27']):
        normalized[parse.quote('limit 27')] = math.floor(fields['limit 27'])
    if math.isfinite(fields['limit 28']):
        normalized[parse.quote('limit 28')] = math.floor(fields['limit 28'])
    if math.isfinite(fields['limit 29']):
        normalized[parse.quote('limit 29')] = math.floor(fields['limit 29'])
    if math.isfinite(fields['limit 30']):
        normalized[parse.quote('limit 30')] = math.floor(fields['limit 30'])
    if math.isfinite(fields['limit 31']):
        normalized[parse.quote('limit 31')] = math.floor(fields['limit 31'])
    if math.isfinite(fields['limit 32']):
        normalized[parse.quote('limit 32')] = math.floor(fields['limit 32'])
    if math.isfinite(fields['limit 33']):
        normalized[parse.quote('limit 33')] = math.floor(fields['limit 33'])
    if math.isfinite(fields['limit 34']):
        normalized[parse.quote('limit 34')] = math.floor(fields['limit 34'])
    if math.isfinite(fields['limit 35']):
        normalized[parse.quote('limit 35')] = math.floor(fields['limit 35'])
    if math.isfinite(fields['limit 36']):
        normalized[parse.quote('limit 36')] = math.floor(fields['limit 36'])
    if math.isfinite(fields['limit 37']):
        normalized[parse.quote('limit 37')] = math.floor(fields['limit 37'])
    if math.isfinite(fields['limit 38']):
        normalized[parse.quote('limit 38')] = math.floor(fields['limit 38'])
    if math.isfinite(fields['limit 39']):
        normalized[parse.quote('limit 39')] = math.floor(fields['limit 39'])
    if math.isfinite(fields['limit 40']):
        normalized[parse.quote('limit 40')] = math.floor(fields['limit 40'])
    if math.isfinite(fields['limit 41']):
        normalized[parse.quote('limit 41')] = math.floor(fields['limit 41'])
    if math.isfinite(fields['limit 42']):
        normalized[parse.quote('limit 42')] = math.floor(fields['limit 42'])
    if math.isfinite(fields['limit 43']):
        normalized[parse.quote('limit 43')] = math.floor(fields['limit 43'])
    if math.isfinite(fields['limit 44']):
        normalized[parse.quote('limit 44')] = math.floor(fields['limit 44'])
    if math.isfinite(fields['limit 45']):
        normalized[parse.quote('limit 45')] = math.floor(fields['limit 45'])
    if math.isfinite(fields['limit 46']):
        normalized[parse.quote('limit 46')] = math.floor(fields['limit 46'])
    if math.isfinite(fields['limit 47']):
        normalized[parse.quote('limit 47')] = math.floor(fields['limit 47'])
    return normalized

data = json.loads('{"limit 00":0.25,"limit 01":1.25,"limit 02":2.25,"limit 03":3.25,"limit 04":4.25,"limit 05":5.25,"limit 06":6.25,"limit 07":7.25,"limit 08":8.25,"limit 09":9.25,"limit 10":10.25,"limit 11":11.25,"limit 12":12.25,"limit 13":13.25,"limit 14":14.25,"limit 15":15.25,"limit 16":16.25,"limit 17":17.25,"limit 18":18.25,"limit 19":19.25,"limit 20":20.25,"limit 21":21.25,"limit 22":22.25,"limit 23":23.25,"limit 24":24.25,"limit 25":25.25,"limit 26":26.25,"limit 27":27.25,"limit 28":28.25,"limit 29":29.25,"limit 30":30.25,"limit 31":31.25,"limit 32":32.25,"limit 33":33.25,"limit 34":34.25,"limit 35":35.25,"limit 36":36.25,"limit 37":37.25,"limit 38":38.25,"limit 39":39.25,"limit 40":40.25,"limit 41":41.25,"limit 42":42.25,"limit 43":43.25,"limit 44":44.25,"limit 45":45.25,"limit 46":46.25,"limit 47":47.25}')
print(json.dumps(validate(data), sort_keys=True, separators=(',', ':')))
