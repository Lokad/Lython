from hashlib import sha256
from pathlib import Path
from shutil import copyfile
import json
import subprocess
import tarfile

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
pair=lab/'comparison'
report=repo/'benchmarks/results/2026-11-28-borrowed-callable-names'
read=lambda p:json.loads(p.read_bytes())
digest=lambda p:sha256(p.read_bytes()).hexdigest()
identity=read(pair/'identity.json')
warm=read(pair/'summary.json')
receipt=read(pair/'archive-receipt.json')
expected=identity['sourcePatchSHA256']
patch=subprocess.check_output(['git','diff','--binary',identity['sourceRevision'],'--','src'],cwd=repo)
assert patch==(lab/'candidate.patch').read_bytes() and sha256(patch).hexdigest()==expected
assert warm['candidatePatchSHA256']==expected
assert warm['verifiedTimedBatches']==112 and warm['quietMachine'] is False
assert all(receipt[key] for key in ('complete','allWorkersJoined','guestFixturesRemoved','archivedAndVerifiedUnderLease'))
assert digest(pair/'observations.tar.xz')==receipt['archiveSHA256']
for role,files in identity['imageFiles'].items():
    assert len(files)==32
    assert {p.name:digest(p) for p in (pair/role).iterdir()}==files
    verification=read(pair/(role+'-verify.json'))
    assert verification['state']=='Completed' and verification['caseCount']==3
    assert verification['catalogSha256']==identity['catalogs']['ordinary-goldens.json']['sha256']
proof=read(lab/'reference-modules.json')
assert proof==read(lab/'candidate-modules.json')
assert len(proof['modules'])==66 and sum(len(row['queries']) for row in proof['rows'])==1342
assert len(proof['diagnostics'])==13
allocation=read(lab/'allocation.json')
assert allocation['verifiedCompilations']==42 and all(row['after']==[0,0] for row in allocation['summary'])
prior=lab.parent/'module-callable-reexports-b1929-20261128'
probe=prior/'probe/bin/Release/net11.0/ModuleProbe.dll'
assert digest(probe)==allocation['probeSHA256']
assert not subprocess.check_output(['git','diff','--name-only',identity['sourceRevision'],'--','tests'],cwd=repo)
report.mkdir(exist_ok=True)
for name,source in [('identity.json',pair/'identity.json'),('warm-summary.json',pair/'summary.json'),
                    ('allocation.json',lab/'allocation.json'),
                    ('warm-observations.tar.xz',pair/'observations.tar.xz')]:
    copyfile(source,report/name)
files=[(lab/name,name) for name in ('archive.py','candidate.patch','prepare.py','workbook.py','workbook-golden.txt',
    'workbook-reference.json','generated.py','generated-golden.json','summarize-warm.py','test-ubuntu.sh',
    'reference-modules.json','candidate-modules.json','measure-allocations.py')]
files.extend((p,p.name) for p in lab.glob('*net*.log'))
files.extend((pair/name,'comparison/'+name) for name in ('archive-receipt.json','reference-verify.json','candidate-verify.json','run.sh',
    'collect.py','config.json','workbook.json','generated.json','ordinary-goldens.json','jobs.json','representative.json','collection.log','exit-code.txt'))
files.extend((prior/'probe'/name,'probe/'+name) for name in ('Program.cs','ModuleProbe.csproj'))
with tarfile.open(report/'procedures.tar.xz','w:xz') as archive:
    for path,name in files: archive.add(path,arcname=name)
with tarfile.open(report/'procedures.tar.xz') as archive:
    assert all(archive.extractfile(name).read()==path.read_bytes() for path,name in files)
print(f'{len(files)} evidence files verified')
