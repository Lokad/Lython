from hashlib import sha256
from pathlib import Path
from shutil import copy2, copytree
from subprocess import check_output
import json

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
previous = lab.parent / 'current-cpython-b1958-20261128'
old = previous / 'comparison/quiet'
current = lab / 'comparison/quiet'
core = 'Lokad.Lython.dll'
digest = lambda path: sha256(path.read_bytes()).hexdigest()
hashes = lambda path: {file.name: digest(file) for file in path.iterdir()}
identity = json.loads((old/'identity.json').read_bytes())
head = check_output(['git','rev-parse','HEAD'], cwd=repo).decode().strip()
assert head.startswith('b663af554') and not check_output(['git','status','--porcelain'],cwd=repo)
assert not check_output(['git','diff',identity['sourceRevision'],head,'--','Directory.Packages.props',
    'src/Lokad.Lython.Utf8Regex','benchmarks/Lokad.Lython.Benchmarks'],cwd=repo)
expected = identity['imageFiles']['candidate']
assert len(expected) == 32 and hashes(old/'local-image') == expected
current.mkdir(parents=True)
copytree(old/'local-image',current/'local-image')
build = lab/'ubuntu-artifacts/bin/Lokad.Lython/release_net11.0'/core
copy2(build,current/'local-image'/core)
assert not (current/'local-image'/core).samefile(build)
image = hashes(current/'local-image')
assert {name for name, checksum in image.items() if expected[name] != checksum} == {core}
for name in ('representative.json','cpython-worker.py'):
    copy2(old/name,current/name)
assert digest(current/'representative.json') == identity['catalogs']['representative.json']['sha256']
assert digest(current/'cpython-worker.py') == identity['cpythonWorkerSHA256']
identity.update(sourceRevision=head, productionHead=head, purpose='Profile combined fixed binding and subtotal ownership.',
    imageFiles={'candidate':image}, coreSHA256={'candidate':image[core]},
    referenceRevision=identity['sourceRevision'],
    catalogs={'representative.json':identity['catalogs']['representative.json']})
for name in ('frozenImage','donorArchiveSHA256'):
    del identity[name]
(current/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8',newline='\n')
copy2(previous/'prepare-profile.py',lab/'prepare-profile.py')
launcher = (previous/'verify.sh').read_text(encoding='utf-8').replace(previous.name,lab.name)
(lab/'verify.sh').write_text(launcher,encoding='utf-8',newline='\n')
assert b'\r' not in (lab/'verify.sh').read_bytes()
print(head,'32-file combined image for warmed attribution')
