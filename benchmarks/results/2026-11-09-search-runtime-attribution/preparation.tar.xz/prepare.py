from pathlib import Path
import hashlib, json, shutil, subprocess, tarfile

r = Path(__file__).parent
old = r.parent/'text-runtime-r140'
remote_old = '/home/lokad/lython-bench-checks/text-runtime-b499-20261109'
remote = '/home/lokad/lython-bench-checks/search-runtime-b501-20261109'
for name in ['ops-profile.py', 'analyze-cpu-guest.py', 'archive.py', 'attribute.py', 'run.sh', 'retrieve.py']:
    data = (old/name).read_text(encoding='utf-8').replace(remote_old, remote)
    data = data.replace('lython-b499-text-runtime-20261109', 'lython-b501-search-runtime-20261109')
    data = data.replace('/dev/shm/lython-b499', '/dev/shm/lython-b501')
    data = data.replace('text-warm', 'search-warm').replace('scripts.text-summary-helpers.large', 'scripts.file-search.control.large')
    data = data.replace('total_capture_seconds > 16', 'total_capture_seconds > 10').replace('seconds<16', 'seconds<10').replace("capturedSeconds']<16", "capturedSeconds']<10")
    if name == 'attribute.py': data = data.replace('One original text capture', 'One original file-search capture')
    (r/name).write_text(data, encoding='utf-8', newline='\n')
catalog = json.loads((r.parent/'generator-storage-r142/catalog.json').read_text(encoding='utf-8'))
case = next(c for c in catalog['cases'] if c['id'] == 'scripts.file-search.control.large')
assert case['source'] == Path('benchmarks/scripts/file-search.py').read_text(encoding='utf-8')
catalog['cases'] = [case]
(r/'catalog.json').write_text(json.dumps(catalog, ensure_ascii=False, indent=2), encoding='utf-8')
aux = json.loads((r.parent/'generator-storage-r142/b500/identity.json').read_text(encoding='utf-8'))['auxiliaryFiles']
digest = hashlib.sha256((r/'current-core.dll').read_bytes()).hexdigest()
proof = dict(coreSHA256=digest, sourceRevision=subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip(),
             sourceSHA256={p.as_posix(): hashlib.sha256(p.read_bytes()).hexdigest()
                           for p in Path('src/Lokad.Lython').rglob('*.cs') if 'obj' not in p.parts},
             proof='Fresh nonincremental Release benchmark build from clean committed 081052fa; upload exact core, pin existing identical worker/adapter/dependencies. No source restore or native runtime override.')
(r/'core-source.json').write_text(json.dumps(proof, indent=2), encoding='utf-8')
(r/'identity.json').write_text(json.dumps(dict(coreSHA256=digest, auxiliaryFiles=aux), indent=2), encoding='utf-8')
(r/'selection.md').write_text('''# R143 bounded file-search attribution

The complete maintained protected file-search script still has a historical warm
1.69–1.71x CPython gap. Source disproves two presumed phases: wanted(line) already
uses direct native affix return with borrowed operands, and text iteration already
uses IPyIteratorValue through the native cursor. Buffered ReadLine completes inline
until actual refill suspension; no per-line IEnumerable pipeline to remove.
One six-second existing-tool capture on fresh committed081052fa (normal GC/tiering,
only perf map diagnostics) separates remaining guest work from caller/reset/host.
Keep named-thread attribution, raw unknowns, all samples and maps. Not an elapsed
or CPython/source-pair comparison. Stop after one usable capture; counts alone do
not justify a dispatch framework, frame arena or native special case. Preserve
managed stack/current cancellation, admission/ownership and awaited native cleanup.
Finite120s service plus30stop/30observation; persistent traces/core separate from
owned RAM fixtures; join/unmount/archive under lease/local SHA. Floors unchanged.
''', encoding='utf-8')
(r/'sizing.json').write_text(json.dumps(dict(cases=1, captureTargetSeconds=6, captureCeilingSeconds=10,
                                           ownerSeconds=120, stopSeconds=30, observationMarginSeconds=30), indent=2), encoding='utf-8')

data = (old/'launch.py').read_text(encoding='utf-8')
data = data.replace('text-runtime-b499-20261109', 'search-runtime-b501-20261109')
data = data.replace('lython-b499-text-runtime-20261109', 'lython-b501-search-runtime-20261109')
data = data.replace('/dev/shm/lython-b499', '/dev/shm/lython-b501').replace('lython-b499-fixtures', 'lython-b501-fixtures')
data = data.replace('lexical-operands-b498-20261109/candidate', 'generator-storage-b500-20261109/candidate')
data = data.replace('text-runtime-b499-launch.py', 'search-runtime-b501-launch.py')
a = data.index(" proof=json.loads((root/'core-source.json').read_text());archive=")
b = data.index(" fixture=Path(", a)
data = data[:a] + """ proof=json.loads((root/'core-source.json').read_text())
 assert hashlib.sha256((root/'current-core.dll').read_bytes()).hexdigest()==proof['coreSHA256']
 shutil.copytree(source,root/'candidate',copy_function=os.link)
 (root/'candidate/Lokad.Lython.dll').unlink();os.link(root/'current-core.dll',root/'candidate/Lokad.Lython.dll')
""" + data[b:]
(r/'launch.py').write_text(data, encoding='utf-8', newline='\n')
with tarfile.open(r/'payload.tgz', 'w:gz') as t:
    for name in ['ops-profile.py', 'analyze-cpu-guest.py', 'archive.py', 'run.sh', 'catalog.json',
                 'core-source.json', 'identity.json', 'selection.md', 'sizing.json', 'current-core.dll']:
        t.add(r/name, arcname=name)
print('One original search script, fresh081052fa core', digest, 'six-second capture, payload bytes', (r/'payload.tgz').stat().st_size)
