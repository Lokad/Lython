from pathlib import Path
import json, shutil, tarfile
r = Path(__file__).parent
out = Path('benchmarks/results/2026-11-09-search-runtime-attribution')
out.mkdir()
for name in ['observations.tgz', 'attribution.json', 'core-source.json', 'identity.json', 'selection.md', 'terminal-status.json']:
    shutil.copyfile(r/name, out/name)
names = ['prepare.py', 'launch.py', 'launch-command.py', 'launch.log', 'observe-not-before.json',
         'retrieve.py', 'attribute.py', 'finalize.py', 'build-current.log']
with tarfile.open(out/'preparation.tar.xz', 'w:xz') as t:
    for name in names: t.add(r/name, arcname=name)
with tarfile.open(out/'preparation.tar.xz') as t:
    assert set(names) <= set(t.getnames())
data = json.loads((r/'attribution.json').read_text(encoding='utf-8'))[0]
guest = data['groups']['guest']
print('Guest', guest['samples'], 'unknown%', round(100*guest['unknownLeaf']/guest['samples'], 2))
for name, count in guest['observedPhase']:
    print(name, round(100*count/guest['samples'], 2))
