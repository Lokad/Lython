from pathlib import Path
import json,os,subprocess,textwrap
lab=Path(__file__).resolve().parent
repo=Path.cwd()
work=repo/'.git/agent-worktrees/function-record-keys-r601'
test=(work/'tests/Lokad.Lython.PublicApi.Tests/FunctionDefinitionIsolationTests.cs').read_text(encoding='utf-8')
section=test.split('RepeatedMetadataDictionariesKeepTheirValuesAndMutationOrder()',1)[1].split('"""',2)[1]
repeated=textwrap.dedent(section).replace('return [defaults, fourth.__kwdefaults__]','print(defaults, fourth.__kwdefaults__)')
source=[
    repeated,
    """events=[]
def factory(seed):
    def note(label, value):
        events.append(label)
        return value
    def apply(x: note('annotation', int) = note('default', seed), *, fin: int = seed+1) -> int:
        return x+fin
    return apply
a,b,c = factory(7),factory(11),factory(17)
print(events)
print(a(),b(),c())
print(a.__kwdefaults__ is b.__kwdefaults__, a.__annotations__ is b.__annotations__)
""",
    """events=[]
def decorator(fn):
    events.append(fn)
    if fn.__kwdefaults__['n']==1: raise LookupError('later')
    return fn
def factory(seed):
    @decorator
    def fn(*, n: int=seed): return n
    return fn
try: factory(1)
except LookupError: pass
a=factory(2)
b=factory(3)
events[0].__kwdefaults__['n']=9
print([fn() for fn in events], a.__annotations__ is b.__annotations__)
""",
    """def factory(seed):
    return lambda *, valeur=seed, quantité=1: valeur*quantité
a,b,c=factory(1),factory(2),factory(3)
d=b.__kwdefaults__
del d['quantité']
d['extra']=12
try: b()
except TypeError: print('missing')
d['quantité']=5
print(list(d),list(c.__kwdefaults__),a(),b(),c())
""",
    """def make():
    def rule(*, n=(yield 'default'), value=int):
        return n
    yield rule
a,b=make(),make()
print(next(a),next(b))
x,y=a.send(7),b.send(8)
x.__kwdefaults__['n']=12
print(x(),y(),x.__kwdefaults__ is y.__kwdefaults__)
""",
]
(lab/'probes.json').write_text(json.dumps(source,ensure_ascii=False)+'\n',encoding='utf-8')
py=Path('C:/Python313/python.exe')
goldens=[]
for program in source:
    completed=subprocess.run([py,'-I','-S','-X','utf8','-c',program],capture_output=True,timeout=10,check=True)
    assert not completed.stderr,completed.stderr
    goldens.append(completed.stdout.decode('utf-8').replace('\r\n','\n'))
sdk=Path.home()/'.dotnet11'
env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk),PATH=str(sdk)+os.pathsep+os.environ['PATH'])
probe=work/'tools/LythonProbe/bin/Release/net11.0/LythonProbe.dll'
checks=[]
for mode in ('sync','async'):
    args=[sdk/'dotnet.exe',probe,'--batch-json','--max-memory-bytes','4194304']
    if mode=='async':args+=['--async']
    process=subprocess.run(args,input=(lab/'probes.json').read_bytes(),env=env,capture_output=True,timeout=70,check=True)
    (lab/f'{mode}.jsonl').write_bytes(process.stdout)
    rows=[json.loads(line)['Lython'] for line in process.stdout.decode('utf-8-sig').splitlines()]
    assert len(rows)==len(goldens)
    for actual,expected in zip(rows,goldens,strict=True):
        assert actual['Success'] and actual['StandardOutput']==expected and not actual['StandardError'],(mode,actual,expected)
    checks.append(dict(mode=mode,matching=len(rows)))
(lab/'probe-summary.json').write_text(json.dumps(dict(checks=checks,cpythonGoldens=goldens),ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(checks)
