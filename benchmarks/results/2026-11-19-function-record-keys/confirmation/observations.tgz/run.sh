set -eu
root=/home/lokad/lython-bench-checks/function-record-confirmation-b1029-20261119
trap 'result=$?; printf "%s\n" "$result" > "$root/exit-code.txt"' EXIT
python3 "$root/collect.py"
