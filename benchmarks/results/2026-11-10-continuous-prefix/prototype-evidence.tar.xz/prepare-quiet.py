from pathlib import Path
import hashlib,json,shutil,subprocess,tarfile
h=Path(__file__).parent;p=h/'b542';assert not(p/'payload.tgz').exists()
d=h/'refined-diagnostic';identity=json.loads((d/'identity.json').read_text(encoding='utf-8'))
for name,sha in identity['source'].items():assert hashlib.sha256((h/'tree'/name).read_bytes()).hexdigest()==sha,name
old=json.loads((h.parent/'prefix-attribution-r193/b541/identity.json').read_text(encoding='utf-8'))
tool=h.parent/'bulk-whitespace-r157/tool/out'
for name in ['complete-jobs.dll','complete-jobs.deps.json','complete-jobs.runtimeconfig.json']:shutil.copyfile(tool/name,p/name)
for a,b in [(d/'catalog.json',p/'catalog.json'),(d/'hash-witness.json',p/'hash-witness.json'),(d/'images/candidate/Lokad.Lython.dll',p/'current-core.dll'),(d/'source.patch',p/'source.patch'),(d/'identity.json',p/'source.json')]:shutil.copyfile(a,b)
images=dict(reference=identity['cores']['before'],candidate=identity['cores']['candidate'])
manifest=dict(sourceRevision='R194 refined uncommitted abovef3e11cc1; qualified1a83c64f reference. No source promotion.',coreSHA256=images,auxiliaryFiles=old['auxiliaryFiles'],
 driverFiles={n:hashlib.sha256((p/n).read_bytes()).hexdigest()for n in ['complete-jobs.dll','complete-jobs.deps.json','complete-jobs.runtimeconfig.json']},
 catalogSHA256=hashlib.sha256((p/'catalog.json').read_bytes()).hexdigest(),witnessSHA256=hashlib.sha256((p/'hash-witness.json').read_bytes()).hexdigest())
(p/'identity.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8')
collector=r'''from pathlib import Path
import datetime,json,os,signal,subprocess,time
root=Path('/home/lokad/lython-bench-checks/prefix-confirm-b542-20261110')
dotnet='/home/lokad/lython-bench-toolchains/dotnet/11.0.100-rc.3.26522.148/dotnet'
env=os.environ.copy();env['DOTNET_ROOT']=str(Path(dotnet).parent);env['TMPDIR']=str(root/'guest-fixtures')
assert not any(n.startswith(('DOTNET_','COMPlus_'))and n!='DOTNET_ROOT'for n in env)
def run(args,out,timeout=45):
 with out.open('w')as stdout,out.with_suffix('.stderr').open('w')as stderr:
  with subprocess.Popen(args,env=env,stdout=stdout,stderr=stderr)as child:
   try:
    child.wait(timeout=timeout);assert child.returncode==0,(out.name,child.returncode)
   finally:
    if child.poll()is None:
     child.terminate()
     try:child.wait(timeout=5)
     except subprocess.TimeoutExpired:child.kill();child.wait()
def stop(*_):raise InterruptedError('Owned collection stopped; drain child before cleanup.')
signal.signal(signal.SIGTERM,stop)
rows=[]
try:
 time.sleep(5)
 run([dotnet,str(root/'reference/Lokad.Lython.Benchmarks.dll'),'--compare','check-machine','--out',str(root/'machine-before.json')],root/'machine-before.log')
 assert json.loads((root/'machine-before.json').read_text())['gate']['quiet']
 for name,api in [('sync-a','sync'),('async-a','async'),('async-b','async'),('sync-b','sync')]:
  directory=root/'output'/name;directory.mkdir(parents=True)
  (directory/'hash-witness.json').write_bytes((root/'hash-witness.json').read_bytes())
  started=datetime.datetime.now(datetime.timezone.utc).isoformat()
  run([dotnet,str(root/'complete-jobs.dll'),str(root/'reference/Lokad.Lython.Benchmarks.dll'),str(root/'candidate/Lokad.Lython.Benchmarks.dll'),str(root/'catalog.json'),str(directory/'hash-witness.json'),'reverse','warm',api],directory/'measurements.json')
  raw=json.loads((directory/'measurements.json').read_text())
  assert all(raw[n]for n in ['allGoldensPassed','allBalancesZero','ownedFixturesRemoved','imageIsolationVerified','normalGcAndTiering'])
  assert raw['asynchronous']==(api=='async')and len(raw['observations'])==5
  assert not list((root/'guest-fixtures').iterdir())
  rows.append(dict(name=name,api=api,startedUTC=started,processId=raw['processId'],allChecksPassed=True))
 time.sleep(5)
 run([dotnet,str(root/'reference/Lokad.Lython.Benchmarks.dll'),'--compare','check-machine','--out',str(root/'machine-after.json')],root/'machine-after.log')
 assert json.loads((root/'machine-after.json').read_text())['gate']['quiet']
 (root/'collection.json').write_text(json.dumps(dict(complete=True,jobs=rows,performanceQualified=False,limits='Quiet VM; shared CoreLib/processGC within each driver; whole-envelope and Run-only clocks separate. Async host I/O completes synchronously.'),indent=2)+'\n')
finally:
 fixture=root/'guest-fixtures'
 assert not list(fixture.iterdir()),'Retain adverse fixtures if a failed driver did not clean its owned files.'
 subprocess.run(['sudo','-n','umount',str(fixture)],check=True);fixture.rmdir()
'''
(p/'collect.py').write_text(collector,encoding='utf-8',newline='\n')
archive=r'''from pathlib import Path
import hashlib,json,shutil,subprocess,tarfile
r=Path('/home/lokad/lython-bench-checks/prefix-confirm-b542-20261110')
assert json.loads((r/'collection.json').read_text())['complete']
assert not(r/'guest-fixtures').exists()
assert subprocess.run(['pgrep','-af','[c]omplete-jobs.dll|[d]otnet.* --compare worker'],capture_output=True).returncode==1
with tarfile.open(r/'observations.tgz','w:gz',dereference=True)as a:
 for p in sorted(r.rglob('*')):
  if p.is_file()and p.name!='observations.tgz'and not any(x in p.relative_to(r).parts for x in ['reference','candidate']):a.add(p,arcname=p.relative_to(r).as_posix())
assert shutil.disk_usage(r).free>240*1024*1024
with tarfile.open(r/'observations.tgz')as a:assert json.loads(a.extractfile('collection.json').read())['complete']
receipt=dict(complete=True,jobs=4,allWorkersJoined=True,guestFixturesRemoved=True,quietBeforeAndAfter=True,archivedAndVerifiedUnderLease=True,archiveSHA256=hashlib.sha256((r/'observations.tgz').read_bytes()).hexdigest(),performanceQualified=False)
(r/'archive-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt))
'''
(p/'archive.py').write_text(archive,encoding='utf-8',newline='\n')
(p/'run.sh').write_text('''set -eu
root=/home/lokad/lython-bench-checks/prefix-confirm-b542-20261110
exec 9>/home/lokad/lython-bench-checks/comparison-vm.lock
flock -n 9
trap 'result=$?; printf "%s\\n" "$result" > "$root/exit-code.txt"; date -u +%FT%TZ > "$root/stopped.utc"' EXIT
date -u +%FT%TZ > "$root/started.utc"
python3 "$root/collect.py" > "$root/collector.log" 2>&1
python3 "$root/archive.py" > "$root/archive.log" 2>&1
''',encoding='utf-8',newline='\n')
# Exact canonical terminal copies; inventory is read-only, no missing paths probed.
rows=json.loads((p/'existing-terminal-archive-inventory.json').read_text(encoding='utf-8'))
by_size={}
for f in Path('benchmarks/results').rglob('*'):
 if f.is_file()and f.suffix in ['.tgz','.xz','.gz']:by_size.setdefault(f.stat().st_size,[]).append(f)
copies=[]
for row in rows:
 options=by_size.get(row['bytes'],[])
 if len(options)==1:
  f=options[0];subprocess.run(['git','ls-files','--error-unmatch',str(f)],check=True,capture_output=True)
  copies.append(dict(row,canonical=f.as_posix(),sha256=hashlib.sha256(f.read_bytes()).hexdigest()))
assert len(copies)==4
canonical=Path('benchmarks/results/2026-11-10-prefix-instruction-attribution/observations.tgz')
copies.append(dict(path='prefix-code-b541-20261110/observations.tgz',bytes=canonical.stat().st_size,sha256=hashlib.sha256(canonical.read_bytes()).hexdigest(),canonical=canonical.as_posix()))
with tarfile.open(canonical)as a:
 for m in a.getmembers():
  if m.isfile()and m.name.startswith('profiles/')and m.size>=32768:
   b=a.extractfile(m).read();copies.append(dict(path='prefix-code-b541-20261110/'+m.name,bytes=len(b),sha256=hashlib.sha256(b).hexdigest(),canonical=canonical.as_posix()+':'+m.name))
(p/'exact-copies.json').write_text(json.dumps(copies,indent=2)+'\n',encoding='utf-8')
with tarfile.open('benchmarks/results/2026-11-10-dictionary-accumulation/observations.tgz')as a:
 b=a.extractfile('current-core.dll').read();assert hashlib.sha256(b).hexdigest()=='e364e4d94ad8015fc8492760cad235475b5943aa6687d681edbb14692e4956f0'
names=['contract.md','identity.json','catalog.json','hash-witness.json','current-core.dll','source.patch','source.json','complete-jobs.dll','complete-jobs.deps.json','complete-jobs.runtimeconfig.json','collect.py','archive.py','run.sh']
with tarfile.open(p/'payload.tgz','w:gz')as a:
 for name in names:a.add(p/name,arcname=name)
with tarfile.open(p/'payload.tgz')as a:required=sum(((m.size+4095)//4096)*4096 for m in a.getmembers())+(240+12)*1024*1024+65536
(p/'payload-identity.json').write_text(json.dumps(dict(bytes=(p/'payload.tgz').stat().st_size,sha256=hashlib.sha256((p/'payload.tgz').read_bytes()).hexdigest(),requiredFreeBytes=required),indent=2)+'\n',encoding='utf-8')
print('Prepared four existing-driver jobs; required free bytes',required,'canonical terminal copies',len(copies))
