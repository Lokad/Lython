R194 bounded refinement: original source/binary/diagnostics/JIT evidence retained.
Original runtime allocation flat; desktop sync mixed, async text+2.72..+11.45%,
report+3.41..+3.95%, moving controls. Original Windows OSR code/frame grew despite
removing jumped stack-home. Do not infer a failed design or promote it.

Refine the same continuous run by sharing a no-state failure predicate and a cold
throw-only helper, removing the prototype nullable-exception hot transport and
unconditional checkpoint span read. Observe the same token/first admission failure
before every instruction; throw outside guest routing, preserve memory precedence.
No new policy/counter/mode/state or compatibility option. Clear SourceSpan retained
through real operation routing. One existing focused/JIT/whole-script comparison
then an explicit decision/quiet confirmation if justified; no general speedup claim.
