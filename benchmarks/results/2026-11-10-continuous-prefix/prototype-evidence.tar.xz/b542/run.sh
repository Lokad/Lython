set -eu
root=/home/lokad/lython-bench-checks/prefix-confirm-b542-20261110
exec 9>/home/lokad/lython-bench-checks/comparison-vm.lock
flock -n 9
trap 'result=$?; printf "%s\n" "$result" > "$root/exit-code.txt"; date -u +%FT%TZ > "$root/stopped.utc"' EXIT
date -u +%FT%TZ > "$root/started.utc"
python3 "$root/collect.py" > "$root/collector.log" 2>&1
python3 "$root/archive.py" > "$root/archive.log" 2>&1
