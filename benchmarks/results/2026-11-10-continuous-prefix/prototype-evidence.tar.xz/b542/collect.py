from pathlib import Path
import datetime,json,os,signal,subprocess,time
root=Path('/home/lokad/lython-bench-checks/prefix-confirm-b542-20261110')
dotnet='/home/lokad/lython-bench-toolchains/dotnet/11.0.100-rc.3.26522.148/dotnet'
env=os.environ.copy();env['DOTNET_ROOT']=str(Path(dotnet).parent);env['TMPDIR']=str(root/'guest-fixtures')
assert not any(n.startswith(('DOTNET_','COMPlus_'))and n!='DOTNET_ROOT'for n in env)
def run(args,out,timeout=45):
 with out.open('w')as stdout,out.with_suffix('.stderr').open('w')as stderr:
  with subprocess.Popen(args,env=env,stdout=stdout,stderr=stderr)as child:
   try:
    child.wait(timeout=timeout);assert child.returncode==0,(out.name,child.returncode)
   finally:
    if child.poll()is None:
     child.terminate()
     try:child.wait(timeout=5)
     except subprocess.TimeoutExpired:child.kill();child.wait()
def stop(*_):raise InterruptedError('Owned collection stopped; drain child before cleanup.')
signal.signal(signal.SIGTERM,stop)
rows=[]
try:
 time.sleep(5)
 run([dotnet,str(root/'reference/Lokad.Lython.Benchmarks.dll'),'--compare','check-machine','--out',str(root/'machine-before.json')],root/'machine-before.log')
 assert json.loads((root/'machine-before.json').read_text())['gate']['quiet']
 for name,api in [('sync-a','sync'),('async-a','async'),('async-b','async'),('sync-b','sync')]:
  directory=root/'output'/name;directory.mkdir(parents=True)
  (directory/'hash-witness.json').write_bytes((root/'hash-witness.json').read_bytes())
  started=datetime.datetime.now(datetime.timezone.utc).isoformat()
  run([dotnet,str(root/'complete-jobs.dll'),str(root/'reference/Lokad.Lython.Benchmarks.dll'),str(root/'candidate/Lokad.Lython.Benchmarks.dll'),str(root/'catalog.json'),str(directory/'hash-witness.json'),'reverse','warm',api],directory/'measurements.json')
  raw=json.loads((directory/'measurements.json').read_text())
  assert all(raw[n]for n in ['allGoldensPassed','allBalancesZero','ownedFixturesRemoved','imageIsolationVerified','normalGcAndTiering'])
  assert raw['asynchronous']==(api=='async')and len(raw['observations'])==5
  assert not list((root/'guest-fixtures').iterdir())
  rows.append(dict(name=name,api=api,startedUTC=started,processId=raw['processId'],allChecksPassed=True))
 time.sleep(5)
 run([dotnet,str(root/'reference/Lokad.Lython.Benchmarks.dll'),'--compare','check-machine','--out',str(root/'machine-after.json')],root/'machine-after.log')
 assert json.loads((root/'machine-after.json').read_text())['gate']['quiet']
 (root/'collection.json').write_text(json.dumps(dict(complete=True,jobs=rows,performanceQualified=False,limits='Quiet VM; shared CoreLib/processGC within each driver; whole-envelope and Run-only clocks separate. Async host I/O completes synchronously.'),indent=2)+'\n')
finally:
 fixture=root/'guest-fixtures'
 assert not list(fixture.iterdir()),'Retain adverse fixtures if a failed driver did not clean its owned files.'
 subprocess.run(['sudo','-n','umount',str(fixture)],check=True);fixture.rmdir()
