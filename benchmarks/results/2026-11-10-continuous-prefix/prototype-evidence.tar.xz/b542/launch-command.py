from pathlib import Path
import ast,fcntl,hashlib,io,json,os,shutil,stat,subprocess,sys,tarfile
base=Path('/home/lokad/lython-bench-checks').resolve();root=base/'prefix-confirm-b542-20261110'
copies=[{'path': 'json-float-entry-b430-20261108/observations.tgz', 'bytes': 3847983, 'canonical': 'benchmarks/results/2026-11-08-json-float-entry/observations.tgz', 'sha256': '6c32d633f85cb0e1051ee10d6b958c2fcc769cfd006022ec92c660c3497f145d'}, {'path': 'buffered-lines-b420-20261107/observations.tgz', 'bytes': 3822022, 'canonical': 'benchmarks/results/2026-11-07-buffered-lines/observations.tgz', 'sha256': 'c13b518b909027015304daaf202f02747cab1a7c7d275dd84758df99e0e3f6a8'}, {'path': 'linear-keyword-b424-20261107/observations.tgz', 'bytes': 3813122, 'canonical': 'benchmarks/results/2026-11-08-linear-keyword-calls/initial-observations.tgz', 'sha256': '42020660bf64eeb63e32ee1cccea565444f16a22c7fa99104315ea44dbdf28a4'}, {'path': 'compiler-graph-b415-20261107/observations.tgz', 'bytes': 3813009, 'canonical': 'benchmarks/results/2026-11-07-executable-graph/observations.tgz', 'sha256': '907f8751ffe5f76aa1d2152d3a8bd95f925e2001fa109185fc4ce02dad20624b'}, {'path': 'prefix-code-b541-20261110/observations.tgz', 'bytes': 2520586, 'sha256': 'a82cddb23171072e63347813a43096522c09da924fbd953466234b64dd3e7e40', 'canonical': 'benchmarks/results/2026-11-10-prefix-instruction-attribution/observations.tgz'}, {'path': 'prefix-code-b541-20261110/profiles/csv-warm/perf-leaves.txt', 'bytes': 56191, 'sha256': '449d34de3ce52b97cd18b1be277f02519a450cf0a12a794dba05a1012dc8cbf2', 'canonical': 'benchmarks/results/2026-11-10-prefix-instruction-attribution/observations.tgz:profiles/csv-warm/perf-leaves.txt'}, {'path': 'prefix-code-b541-20261110/profiles/csv-warm/perf-stacks.txt', 'bytes': 672346, 'sha256': '96c5e4fd1ec68b6343c65fc286189f0d197046b869eee707b18f1f3409120470', 'canonical': 'benchmarks/results/2026-11-10-prefix-instruction-attribution/observations.tgz:profiles/csv-warm/perf-stacks.txt'}, {'path': 'prefix-code-b541-20261110/profiles/csv-warm/perf.data', 'bytes': 315768, 'sha256': 'e7dce9c6ab2e56eb242515daa4a658b5de31ddc981dd595151b21540dd018d07', 'canonical': 'benchmarks/results/2026-11-10-prefix-instruction-attribution/observations.tgz:profiles/csv-warm/perf.data'}, {'path': 'prefix-code-b541-20261110/profiles/csv-warm/perf.map', 'bytes': 1529318, 'sha256': '3e602c045231d34df115d19ae7a250bcd87442f2744f755396c11cc2445ddf95', 'canonical': 'benchmarks/results/2026-11-10-prefix-instruction-attribution/observations.tgz:profiles/csv-warm/perf.map'}, {'path': 'prefix-code-b541-20261110/profiles/csv-warm/prefix-jit.txt', 'bytes': 428569, 'sha256': 'a0b4a311d6d54e55d50b333c218bbc780d7075fe0ce99625e30f3c0310e14b83', 'canonical': 'benchmarks/results/2026-11-10-prefix-instruction-attribution/observations.tgz:profiles/csv-warm/prefix-jit.txt'}, {'path': 'prefix-code-b541-20261110/profiles/text-warm/perf-leaves.txt', 'bytes': 54986, 'sha256': '5b191da1ccd97d4cd9895d14a0d11df0577e5f22fcfc6c72581c48aad9fb0c8d', 'canonical': 'benchmarks/results/2026-11-10-prefix-instruction-attribution/observations.tgz:profiles/text-warm/perf-leaves.txt'}, {'path': 'prefix-code-b541-20261110/profiles/text-warm/perf-stacks.txt', 'bytes': 659304, 'sha256': 'fcddaac75fbe1473d7b29c69db6211f345bdef5114e75c917c4e1473fdb723ed', 'canonical': 'benchmarks/results/2026-11-10-prefix-instruction-attribution/observations.tgz:profiles/text-warm/perf-stacks.txt'}, {'path': 'prefix-code-b541-20261110/profiles/text-warm/perf.data', 'bytes': 308692, 'sha256': 'a2aaf51dff4ca962aada9016a16c3615630ca42087a0edc1fdef82b3846a3304', 'canonical': 'benchmarks/results/2026-11-10-prefix-instruction-attribution/observations.tgz:profiles/text-warm/perf.data'}, {'path': 'prefix-code-b541-20261110/profiles/text-warm/perf.map', 'bytes': 1388610, 'sha256': 'a617c1e226153911541b5cd4a881fa2b1396b3e5e2513a7ae998e76c0addfb14', 'canonical': 'benchmarks/results/2026-11-10-prefix-instruction-attribution/observations.tgz:profiles/text-warm/perf.map'}, {'path': 'prefix-code-b541-20261110/profiles/text-warm/prefix-jit.txt', 'bytes': 822215, 'sha256': 'd9abb5733ef55ece7887d3a1d0bf97e90156d0148c3097b2e2fa8427d3e05365', 'canonical': 'benchmarks/results/2026-11-10-prefix-instruction-attribution/observations.tgz:profiles/text-warm/prefix-jit.txt'}, {'path': 'prefix-code-b541-20261110/profiles/text-warm/record.json', 'bytes': 48810, 'sha256': '1b858686db3c5e43444357eeb363c8e37be8d5c6e1ba78820cf51d5fafe8651f', 'canonical': 'benchmarks/results/2026-11-10-prefix-instruction-attribution/observations.tgz:profiles/text-warm/record.json'}]
with(base/'comparison-vm.lock').open('a')as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert not root.exists()and not list(Path('/dev/shm').glob('lython-comparison-files-*'))
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[c]omplete-jobs.dll|[p]erf record'],capture_output=True).returncode==1
 payload=sys.stdin.buffer.read(1942561)
 assert len(payload)==1942560 and hashlib.sha256(payload).hexdigest()=='e87dacda15432a128cc26810d1df54b0ef97d9f9ea5b6fed890fce26619e6fd2'
 protected=base/'prefix-code-b541-20261110/current-core.dll'
 assert hashlib.sha256(protected.read_bytes()).hexdigest()=='ac6edb6fc361dba9195d973830a5ca02caac10b62cc6d041f134ce31ef9a10d3'
 # e364 is historical now: newer1a83/ac6 is fully qualified and remains intact.
 old=base/'dictionary-cpython-b539-20261110/current-core.dll';oldstat=old.stat()
 assert hashlib.sha256(old.read_bytes()).hexdigest()=='e364e4d94ad8015fc8492760cad235475b5943aa6687d681edbb14692e4956f0'
 aliases=[Path(os.fsdecode(v))for v in subprocess.check_output(['find',str(base),'-xdev','-samefile',str(old),'-print0']).split(bytes([0]))if v]
 assert len(aliases)==oldstat.st_nlink
 targets=[];records=[];reclaim=oldstat.st_blocks*512
 for path in aliases:
  assert path.resolve(strict=True).is_relative_to(base)and stat.S_ISREG(path.lstat().st_mode)
  s=path.stat();assert s.st_uid==os.getuid()and(s.st_dev,s.st_ino)==(oldstat.st_dev,oldstat.st_ino)
  assert(s.st_dev,s.st_ino)!=(protected.stat().st_dev,protected.stat().st_ino);targets.append(path)
 records.append(dict(kind='historicale364Core',allAliases=[str(v)for v in aliases],links=oldstat.st_nlink,allocatedBytes=oldstat.st_blocks*512,
  sha256='e364e4d94ad8015fc8492760cad235475b5943aa6687d681edbb14692e4956f0',canonical='benchmarks/results/2026-11-10-dictionary-accumulation/observations.tgz:current-core.dll',reason='Newac6/1a83 is fully qualified GREEN42792541280, retained.'))
 for c in copies:
  path=base/c['path'];assert path.resolve(strict=True).is_relative_to(base)and stat.S_ISREG(path.lstat().st_mode)
  s=path.stat();assert s.st_uid==os.getuid()and s.st_nlink==1 and s.st_size==c['bytes']
  assert hashlib.sha256(path.read_bytes()).hexdigest()==c['sha256'],str(path)
  assert path not in targets;targets.append(path);reclaim+=s.st_blocks*512
  records.append(dict(c,allocatedBytes=s.st_blocks*512,allAliases=[str(path)]))
 required=270872576;before=shutil.disk_usage(base).free
 assert before+reclaim>required,(before,reclaim,required)
 for path in targets:path.unlink()
 after=shutil.disk_usage(base).free;assert after>required
 recovery=dict(beforeFreeBytes=before,afterFreeBytes=after,requiredFreeBytes=required,osFloorMiB=240,evidenceHeadroomMiB=12,
  freshIdleLease=True,files=records,operation='Exact canonical terminal copies/historicale364 aliases only; qualifiedac6 and all active/current images retained. Initial low free space explicit.')
 with tarfile.open(fileobj=io.BytesIO(payload),mode='r:gz')as a:root.mkdir();a.extractall(root,filter='data')
 (root/'space-recovery.json').write_text(json.dumps(recovery,indent=2)+'\n')
 source=base/'prefix-code-b541-20261110/candidate'
 os.link(source/'Lokad.Lython.dll',root/'baseline-core.dll')
 for role in ['reference','candidate']:
  shutil.copytree(source,root/role,copy_function=os.link)
  (root/role/'Lokad.Lython.dll').unlink();os.link(root/('baseline-core.dll'if role=='reference'else'current-core.dll'),root/role/'Lokad.Lython.dll')
 identity=json.loads((root/'identity.json').read_text())
 for role in ['reference','candidate']:
  for name,digest in {**identity['auxiliaryFiles'],'Lokad.Lython.dll':identity['coreSHA256'][role]}.items():
   assert hashlib.sha256((root/role/name).read_bytes()).hexdigest()==digest,(role,name)
 for name,digest in identity['driverFiles'].items():assert hashlib.sha256((root/name).read_bytes()).hexdigest()==digest,name
 assert hashlib.sha256((root/'catalog.json').read_bytes()).hexdigest()==identity['catalogSHA256']
 assert hashlib.sha256((root/'hash-witness.json').read_bytes()).hexdigest()==identity['witnessSHA256']
 for name in ['collect.py','archive.py']:ast.parse((root/name).read_text())
 subprocess.run(['/bin/sh','-n',str(root/'run.sh')],check=True)
 fixture=root/'guest-fixtures';fixture.mkdir()
 subprocess.run(['sudo','-n','mount','-t','tmpfs','-o','size=128m,mode=0700,uid=lokad,gid=lokad','lython-b542-fixtures',str(fixture)],check=True)
 setup=dict(freeBytes=shutil.disk_usage(base).free,coreAndRuntimeAuxiliaryVerified=True,driverUnchanged=True,configuredJobs=4,
  ownerSeconds=120,stopSeconds=30,marginSeconds=30,osFloorMiB=240,evidenceHeadroomMiB=12)
 assert setup['freeBytes']>(240+12)*1024*1024
 (root/'setup.json').write_text(json.dumps(setup,indent=2)+'\n');print(json.dumps(setup),flush=True)
try:
 subprocess.run(['sudo','-n','systemd-run','--unit=lython-b542-prefix-confirm-20261110','--property=User=lokad',
  '--property=WorkingDirectory='+str(root),'--property=RuntimeMaxSec=120','--property=TimeoutStopSec=30',
  '--property=KillMode=control-group','/bin/sh',str(root/'run.sh')],check=True)
except BaseException:
 subprocess.run(['sudo','-n','umount',str(fixture)],check=True);fixture.rmdir();raise
live=subprocess.check_output(['systemctl','show','lython-b542-prefix-confirm-20261110.service','--property=ActiveState,MainPID,RuntimeMaxUSec'],text=True)
assert 'ActiveState=active'in live and 'MainPID=0'not in live
print(live,flush=True)
