from pathlib import Path
import hashlib,json,shutil,subprocess,tarfile
r=Path('/home/lokad/lython-bench-checks/prefix-confirm-b542-20261110')
assert json.loads((r/'collection.json').read_text())['complete']
assert not(r/'guest-fixtures').exists()
assert subprocess.run(['pgrep','-af','[c]omplete-jobs.dll|[d]otnet.* --compare worker'],capture_output=True).returncode==1
with tarfile.open(r/'observations.tgz','w:gz',dereference=True)as a:
 for p in sorted(r.rglob('*')):
  if p.is_file()and p.name!='observations.tgz'and not any(x in p.relative_to(r).parts for x in ['reference','candidate']):a.add(p,arcname=p.relative_to(r).as_posix())
assert shutil.disk_usage(r).free>240*1024*1024
with tarfile.open(r/'observations.tgz')as a:assert json.loads(a.extractfile('collection.json').read())['complete']
receipt=dict(complete=True,jobs=4,allWorkersJoined=True,guestFixturesRemoved=True,quietBeforeAndAfter=True,archivedAndVerifiedUnderLease=True,archiveSHA256=hashlib.sha256((r/'observations.tgz').read_bytes()).hexdigest(),performanceQualified=False)
(r/'archive-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt))
