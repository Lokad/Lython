from pathlib import Path
import base64, copy, hashlib, json, os, shutil, statistics, subprocess, tempfile

h=Path(__file__).parent; t=h/'tree'; d=h/'diagnostic'; d.mkdir()
env=os.environ.copy();env['DOTNET_ROOT']='C:/Users/JoannesVermorel/.dotnet11'
env['PATH']=env['DOTNET_ROOT']+os.pathsep+'C:/Python313'+os.pathsep+env['PATH']
dotnet=env['DOTNET_ROOT']+'/dotnet.exe'
internal='(Category!=Stress)&(FullyQualifiedName~Executable|FullyQualifiedName~Exception|FullyQualifiedName~Generator|FullyQualifiedName~Stack|FullyQualifiedName~FunctionWorkspace|FullyQualifiedName~FunctionBodyTemporaryLifetime|FullyQualifiedName~Temporary|FullyQualifiedName~GeneralBoundMethodDefaultLifetime|FullyQualifiedName~SimpleFunctionExecutionBoundary|FullyQualifiedName~Admission|FullyQualifiedName~Refusal)'
for name,args in [
    ('internal11',['test','tests/Lokad.Lython.Tests/Lokad.Lython.Tests.csproj','-c','Release','-f','net11.0','--filter',internal]),
    ('internal10',['test','tests/Lokad.Lython.Tests/Lokad.Lython.Tests.csproj','-c','Release','-f','net10.0','--filter',internal]),
    ('freeze11',['build','src/Lokad.Lython/Lokad.Lython.csproj','-c','Release','-f','net11.0','--no-incremental'])]:
    with(d/(name+'.log')).open('w',encoding='utf-8')as out:
        r=subprocess.run([dotnet,*args],cwd=t,env=env,stdout=out,stderr=subprocess.STDOUT,timeout=180)
    print(name,(d/(name+'.log')).read_text(encoding='utf-8')[-350:],flush=True)
    assert r.returncode==0

before=h.parent/'receiver-native-entry-r192/diagnostic/images/candidate'
for role in ['before','candidate']:shutil.copytree(before,d/'images'/role)
shutil.copyfile(t/'src/Lokad.Lython/bin/Release/net11.0/Lokad.Lython.dll',d/'images/candidate/Lokad.Lython.dll')
assert all(p.read_bytes()==(d/'images/candidate'/p.relative_to(d/'images/before')).read_bytes()
           for p in(d/'images/before').rglob('*')if p.is_file()and p.name!='Lokad.Lython.dll')
catalog=json.loads((h.parent/'native-dictionary-accumulation-r190/diagnostic/catalog.json').read_text(encoding='utf-8'))
method_catalog=json.loads((h.parent/'callable-consolidation-r145/catalog.json').read_text(encoding='utf-8'))
target=next(c for c in method_catalog['cases']if c['id']=='scripts.text-summary-helpers.class-callable.large')
catalog['cases']=[copy.deepcopy(target)]+[c for c in catalog['cases']if 'config-edit'not in c['id']]
assert len(catalog['cases'])==5
(d/'catalog.json').write_text(json.dumps(catalog,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
shutil.copyfile(h.parent/'native-dictionary-accumulation-r190/diagnostic/hash-witness.json',d/'hash-witness.json')
goldens=[]
for c in catalog['cases']:
    fixture=json.loads(c['fixtureJson'])
    with tempfile.TemporaryDirectory(prefix='lython-r192-golden-')as folder:
        folder=Path(folder)
        for path,encoded in fixture['inputFiles'].items():
            dest=folder/path;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(base64.b64decode(encoded,validate=True))
        r=subprocess.run(['C:/Python313/python.exe','-I','-S','-X','utf8','-c',c['source']],cwd=folder,
                         text=True,encoding='utf-8',capture_output=True,timeout=15)
        assert r.returncode==0 and not r.stderr and r.stdout==c['expectedOutput'],(c['id'],r.stderr)
        assert all((folder/path).read_bytes()==base64.b64decode(encoded,validate=True)for path,encoded in fixture['outputFiles'].items())
        goldens.append(dict(case=c['id'],sourceSHA256=c['sourceSha256'],stdout=r.stdout,allFileGoldensPassed=True))
(d/'script-goldens.json').write_text(json.dumps(goldens,indent=2)+'\n',encoding='utf-8',newline='\n')
(d/'source.patch').write_bytes(subprocess.check_output(['git','diff','--binary','--','src','tests'],cwd=t,stderr=subprocess.DEVNULL))
(d/'identity.json').write_text(json.dumps(dict(baseRevision='f3e11cc1; qualified1a83c64f runtime, frozen ac6 baseline',
    status='Isolated continuous-prefix exception boundary prototype; not promoted/final-qualified.',
    cores={role:hashlib.sha256((d/'images'/role/'Lokad.Lython.dll').read_bytes()).hexdigest()for role in ['before','candidate']},
    source={p.relative_to(t).as_posix():hashlib.sha256(p.read_bytes()).hexdigest()for p in(t/'src/Lokad.Lython').rglob('*.cs')if'obj'not in p.parts},
    catalogSHA256=hashlib.sha256((d/'catalog.json').read_bytes()).hexdigest(),
    workload='Same complete CSV/text/class-bound-text/report/search; existing worker/auxiliary bytes unchanged. Compile/warm separate, desktop elapsed diagnostic.',
    qualification='Focused actual11/10 logs; forced nonincremental freeze; current cancellation/ownership/refusal remain. Desktop elapsed diagnostic.'),indent=2)+'\n',encoding='utf-8')
for phase,api,field in [('warm','sync','executionMilliseconds'),('warm-async','async','executionMilliseconds'),('compile','sync','elapsedMilliseconds')]:
    o=d/phase;o.mkdir()
    with(o/'measurements.json').open('w',encoding='utf-8')as out,(o/'stderr.txt').open('w',encoding='utf-8')as err:
        r=subprocess.run([dotnet,str(h.parent/'bulk-whitespace-r157/tool/out/complete-jobs.dll'),
            str(d/'images/before/Lokad.Lython.Benchmarks.dll'),str(d/'images/candidate/Lokad.Lython.Benchmarks.dll'),
            str(d/'catalog.json'),str(d/'hash-witness.json'),'reverse','compile'if phase=='compile'else'warm',api],
            env=env,stdout=out,stderr=err,timeout=120)
    assert r.returncode==0,(o/'stderr.txt').read_text(encoding='utf-8')[-2500:]
    raw=json.loads((o/'measurements.json').read_text(encoding='utf-8'))
    assert all(raw[k]for k in ['allGoldensPassed','allBalancesZero','ownedFixturesRemoved','imageIsolationVerified'])
    rows=[]
    for c in raw['observations']:
        roles={role:{key:statistics.median(s[f]/s['jobs']for s in c['samples']if s['image']==role)
            for key,f in [('bytes','allocatedBytes'),('elapsedMs',field)]}for role in ['before','before-control','candidate']}
        row=dict(case=c['caseId'],roles=roles,changes={b:{k:100*(roles['candidate'][k]/roles[b][k]-1)for k in roles[b]}
            for b in ['before','before-control']});rows.append(row)
        print(phase,row['case'],row['changes'],flush=True)
    (o/'summary.json').write_text(json.dumps(rows,indent=2)+'\n',encoding='utf-8')
