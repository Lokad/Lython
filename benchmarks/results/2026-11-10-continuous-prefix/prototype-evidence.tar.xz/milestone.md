# R194 continuous executable prefix with cold exception routing

Basef3e11cc1, runtime1a83c64f; R192 focused/quiet gates pass, full42792541280 still
qualifying independently (Ubuntucomplete, WindowsoriginalStress pending). R193
exactcode-size/tier/offset mapping attributes common fetch/check/dispatch-entry
blocks8.22%CSV/10.10%text guest samples. They include required protections. No
predicted speedup; exception-region placement causing spills is a hypothesis.

Selected coherent change: execute a continuous instruction run inside one exception
region, routing only actual operation exceptions outside that hot loop. Keep the
existing single executable engine/opcode switch and pause/async/call protocol.
Remove the per-instruction try/catch boundary and exception handlers' use of the
hot jumped local; cache immutable execution state for the run. Do not introduce
another dispatcher, frame/arena, per-op callable, option or execution policy.

Checkpoint failures must still bypass Python routing as they do today. Share one
internal execution-failure observation (first existing MemoryGovernor admission
failure, otherwise current-token cancellation) with CheckExecution. Only the cold
failure branch exits the instruction run and throws outside its catch region.
Do not catch an attributed checkpoint refusal/cancellation as a guest operation.
Replace the old cancellation throw-only helper with a cold exception factory as
needed; no new failure state, quota/counter/threshold or saved caller token.
Native-operation checks continue throwing normally through the existing router.

Preserve the exact current instruction reference/span through cold routing, even
when native cased-split/dictionary fusion advances the program counter before a
later publication/disposal error. Preserve jumps, except/finally/with cleanup,
returns, generators/delegation, async pauses and pending native disposals. Keep
managed stack bounds/admission and all existing native helper optimizations.
No public behavior/API/ownership contract is intended to change. Per-instruction
failure checks and all long-operation/host/provider checkpoints remain effective;
first admission origin and memory-before-cancellation precedence stay unchanged.

Source/JIT gate first: the expected repeated jumped stack store/cold routing and
loop bookkeeping must actually disappear/reduce; ordinary work cannot be moved
to another dispatcher. Fully managed/memory-safe only. No unsafe/Unsafe/pointers/
PInvoke/native probing, memory tracing or new ownership infrastructure.

Focused actual11/10: exception/handler/control/with and native helper spans,
true async operations/generator sends/disposals, active cancellation, terminal
refusal through suppressions, retained results/cache/alias funding, budget reuse
and managed stack checks. Preserve independent Python goldens; add coverage only
for a real source-span/unwind gap. No exact checkpoint/fuel count tests.

Short existing five-script warm/completed-I/O-async diagnostic (CSV/ordinarytext
and boundtext/report/search controls), compilation separate. If actual work is
removed and semantic/source gates pass, one bounded quiet confirmation/refinement
as justified. Preserve all adverse/unchanged-control results; don't forecast a
percentage. Temporary regression is allowed only within this isolated migration,
with completion requiring a source/debt decision and displaced boundary removal.
Stop/refine if correctness needs extra routing state/frameworks or no actual work
is removed. No automatic promotion on microbench or allocation results. Full
platform/Stress/installed packages only at a retained checkpoint, not each edit.
Publication postponed; regex contract/adapter track remains independent.
