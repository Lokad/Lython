from pathlib import Path
import datetime,hashlib,json,shlex,subprocess
p=Path(__file__).parent/'b542';assert not(p/'observe-not-before.json').exists()
data=(p/'payload.tgz').read_bytes();details=json.loads((p/'payload-identity.json').read_text(encoding='utf-8'))
assert hashlib.sha256(data).hexdigest()==details['sha256']
copies=json.loads((p/'exact-copies.json').read_text(encoding='utf-8'))
script=r'''from pathlib import Path
import ast,fcntl,hashlib,io,json,os,shutil,stat,subprocess,sys,tarfile
base=Path('/home/lokad/lython-bench-checks').resolve();root=base/'prefix-confirm-b542-20261110'
copies=COPIES
with(base/'comparison-vm.lock').open('a')as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert not root.exists()and not list(Path('/dev/shm').glob('lython-comparison-files-*'))
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[c]omplete-jobs.dll|[p]erf record'],capture_output=True).returncode==1
 payload=sys.stdin.buffer.read(PAYLOADPLUS)
 assert len(payload)==PAYLOADSIZE and hashlib.sha256(payload).hexdigest()=='PAYLOADSHA'
 protected=base/'prefix-code-b541-20261110/current-core.dll'
 assert hashlib.sha256(protected.read_bytes()).hexdigest()=='ac6edb6fc361dba9195d973830a5ca02caac10b62cc6d041f134ce31ef9a10d3'
 # e364 is historical now: newer1a83/ac6 is fully qualified and remains intact.
 old=base/'dictionary-cpython-b539-20261110/current-core.dll';oldstat=old.stat()
 assert hashlib.sha256(old.read_bytes()).hexdigest()=='e364e4d94ad8015fc8492760cad235475b5943aa6687d681edbb14692e4956f0'
 aliases=[Path(os.fsdecode(v))for v in subprocess.check_output(['find',str(base),'-xdev','-samefile',str(old),'-print0']).split(bytes([0]))if v]
 assert len(aliases)==oldstat.st_nlink
 targets=[];records=[];reclaim=oldstat.st_blocks*512
 for path in aliases:
  assert path.resolve(strict=True).is_relative_to(base)and stat.S_ISREG(path.lstat().st_mode)
  s=path.stat();assert s.st_uid==os.getuid()and(s.st_dev,s.st_ino)==(oldstat.st_dev,oldstat.st_ino)
  assert(s.st_dev,s.st_ino)!=(protected.stat().st_dev,protected.stat().st_ino);targets.append(path)
 records.append(dict(kind='historicale364Core',allAliases=[str(v)for v in aliases],links=oldstat.st_nlink,allocatedBytes=oldstat.st_blocks*512,
  sha256='e364e4d94ad8015fc8492760cad235475b5943aa6687d681edbb14692e4956f0',canonical='benchmarks/results/2026-11-10-dictionary-accumulation/observations.tgz:current-core.dll',reason='Newac6/1a83 is fully qualified GREEN42792541280, retained.'))
 for c in copies:
  path=base/c['path'];assert path.resolve(strict=True).is_relative_to(base)and stat.S_ISREG(path.lstat().st_mode)
  s=path.stat();assert s.st_uid==os.getuid()and s.st_nlink==1 and s.st_size==c['bytes']
  assert hashlib.sha256(path.read_bytes()).hexdigest()==c['sha256'],str(path)
  assert path not in targets;targets.append(path);reclaim+=s.st_blocks*512
  records.append(dict(c,allocatedBytes=s.st_blocks*512,allAliases=[str(path)]))
 required=REQUIRED;before=shutil.disk_usage(base).free
 assert before+reclaim>required,(before,reclaim,required)
 for path in targets:path.unlink()
 after=shutil.disk_usage(base).free;assert after>required
 recovery=dict(beforeFreeBytes=before,afterFreeBytes=after,requiredFreeBytes=required,osFloorMiB=240,evidenceHeadroomMiB=12,
  freshIdleLease=True,files=records,operation='Exact canonical terminal copies/historicale364 aliases only; qualifiedac6 and all active/current images retained. Initial low free space explicit.')
 with tarfile.open(fileobj=io.BytesIO(payload),mode='r:gz')as a:root.mkdir();a.extractall(root,filter='data')
 (root/'space-recovery.json').write_text(json.dumps(recovery,indent=2)+'\n')
 source=base/'prefix-code-b541-20261110/candidate'
 os.link(source/'Lokad.Lython.dll',root/'baseline-core.dll')
 for role in ['reference','candidate']:
  shutil.copytree(source,root/role,copy_function=os.link)
  (root/role/'Lokad.Lython.dll').unlink();os.link(root/('baseline-core.dll'if role=='reference'else'current-core.dll'),root/role/'Lokad.Lython.dll')
 identity=json.loads((root/'identity.json').read_text())
 for role in ['reference','candidate']:
  for name,digest in {**identity['auxiliaryFiles'],'Lokad.Lython.dll':identity['coreSHA256'][role]}.items():
   assert hashlib.sha256((root/role/name).read_bytes()).hexdigest()==digest,(role,name)
 for name,digest in identity['driverFiles'].items():assert hashlib.sha256((root/name).read_bytes()).hexdigest()==digest,name
 assert hashlib.sha256((root/'catalog.json').read_bytes()).hexdigest()==identity['catalogSHA256']
 assert hashlib.sha256((root/'hash-witness.json').read_bytes()).hexdigest()==identity['witnessSHA256']
 for name in ['collect.py','archive.py']:ast.parse((root/name).read_text())
 subprocess.run(['/bin/sh','-n',str(root/'run.sh')],check=True)
 fixture=root/'guest-fixtures';fixture.mkdir()
 subprocess.run(['sudo','-n','mount','-t','tmpfs','-o','size=128m,mode=0700,uid=lokad,gid=lokad','lython-b542-fixtures',str(fixture)],check=True)
 setup=dict(freeBytes=shutil.disk_usage(base).free,coreAndRuntimeAuxiliaryVerified=True,driverUnchanged=True,configuredJobs=4,
  ownerSeconds=120,stopSeconds=30,marginSeconds=30,osFloorMiB=240,evidenceHeadroomMiB=12)
 assert setup['freeBytes']>(240+12)*1024*1024
 (root/'setup.json').write_text(json.dumps(setup,indent=2)+'\n');print(json.dumps(setup),flush=True)
try:
 subprocess.run(['sudo','-n','systemd-run','--unit=lython-b542-prefix-confirm-20261110','--property=User=lokad',
  '--property=WorkingDirectory='+str(root),'--property=RuntimeMaxSec=120','--property=TimeoutStopSec=30',
  '--property=KillMode=control-group','/bin/sh',str(root/'run.sh')],check=True)
except BaseException:
 subprocess.run(['sudo','-n','umount',str(fixture)],check=True);fixture.rmdir();raise
live=subprocess.check_output(['systemctl','show','lython-b542-prefix-confirm-20261110.service','--property=ActiveState,MainPID,RuntimeMaxUSec'],text=True)
assert 'ActiveState=active'in live and 'MainPID=0'not in live
print(live,flush=True)
'''.replace('COPIES',repr(copies)).replace('PAYLOADPLUS',str(len(data)+1)).replace('PAYLOADSIZE',str(len(data))).replace('PAYLOADSHA',details['sha256']).replace('REQUIRED',str(details['requiredFreeBytes']))
(p/'launch-command.py').write_text(script,encoding='utf-8',newline='\n')
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
stage='/home/lokad/lython-bench-checks/prefix-confirm-b542-launch.py'
code='from pathlib import Path;import sys;p=Path('+repr(stage)+');assert not p.exists();p.write_bytes(sys.stdin.buffer.read())'
r=subprocess.run([*ssh,'python3 -c '+shlex.quote(code)],input=script.encode('utf-8'),capture_output=True);assert r.returncode==0,r.stderr
r=subprocess.run([*ssh,'python3 '+stage],input=data,capture_output=True)
(p/'launch.log').write_bytes(r.stdout+b'\n'+r.stderr);assert r.returncode==0,r.stderr.decode('utf-8')
assert b'ActiveState=active'in r.stdout and b'MainPID=0'not in r.stdout
now=datetime.datetime.now(datetime.timezone.utc)
(p/'observe-not-before.json').write_text(json.dumps(dict(acknowledgedUTC=now.isoformat(),doNotObserveBeforeUTC=(now+datetime.timedelta(seconds=180)).isoformat(),ownerSeconds=120,stopSeconds=30,marginSeconds=30),indent=2)+'\n',encoding='utf-8')
print(r.stdout.decode('utf-8'));print('Observe after',(now+datetime.timedelta(seconds=180)).isoformat(),flush=True)
