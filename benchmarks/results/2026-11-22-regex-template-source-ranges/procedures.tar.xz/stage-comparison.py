from pathlib import Path
import gzip,hashlib,json,shutil,subprocess,tarfile

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
pair=lab/"comparison"
past=lab.parent/"native-operand-call-loan-20261122/rebased"
quiet=pair/"quiet"
quiet.mkdir(exist_ok=True)
base="/home/lokad/lython-bench-checks"
root=base+"/regex-template-ranges-b1393-20261122"
unit="lython-b1393-regex-template-ranges-20261122"
core="Lokad.Lython.dll"
def read(p):return json.loads(p.read_text(encoding="utf-8-sig"))
def sha(b):return hashlib.sha256(b).hexdigest()
def write(p,v):
    if not isinstance(v,str):v=json.dumps(v,indent=2)+"\n"
    if p.suffix==".py":compile(v,str(p),"exec")
    p.write_text(v,encoding="utf-8",newline="\n")
def published(folder,name):
    return subprocess.check_output(["git","show",f"origin/master:benchmarks/results/{folder}/{name}"],cwd=repo)
def check_archive(folder, expected):
    report=json.loads(published(folder,"archive-receipt.json"))
    assert all(report[n] for n in ("complete","allWorkersJoined","archivedAndVerifiedUnderLease"))
    assert report["archiveSHA256"]==expected==sha(published(folder,"observations.tgz"))

refs=read(pair/"images.json")
files=refs["imageFiles"]
previous=read(past/"quiet/config.json")
for role in files:
    expected=files[role]
    assert len(expected)==32 and {n:sha((pair/role/n).read_bytes()) for n in expected}==expected
    assert all(previous["identity"]["imageFiles"]["candidate"][n]==digest for n,digest in expected.items() if n!=core)
    verification=read(pair/(role+"-verify.json"))
    assert verification["state"]=="Completed" and verification["caseCount"]==5 and verification["catalogSha256"]==refs["catalogSHA256"]
    (quiet/role).mkdir(exist_ok=True)
    shutil.copyfile(pair/role/core,quiet/role/core)
reference_archive="2026-11-22-native-operand-call-loan"
word_archive="2026-11-22-inline-cased-word-headers"
receipt=read(past/"quiet/archive-receipt.json")
check_archive(reference_archive,receipt["archiveSHA256"])
assert sha((past/"quiet/observations.tgz").read_bytes())==receipt["archiveSHA256"]
catalog=pair/"catalog.json"
assert sha(catalog.read_bytes())==refs["catalogSHA256"]
shutil.copyfile(catalog,quiet/"representative.json")
identity=dict(sourceRevision=refs["reference"]+" versus "+refs["candidate"],reference=refs["reference"],candidate=refs["candidate"],
              purpose="Replay original regex template literals without decoded scratch",normalAdapterPin="0.4.0",
              imageFiles=files,sourcePatchSHA256=refs["sourcePatchSHA256"],
              coreSHA256={role+suffix:values[core]for role,values in files.items()for suffix in ("","-control")},
              catalogs={"representative.json":{"sha256":refs["catalogSHA256"]}})
write(quiet/"identity.json",identity)
ids=[c["id"] for c in read(catalog)["cases"]]
for name in ("collect.py","run.sh","archive-owned.py","retrieve.py"):
    code=(past/"quiet"/name).read_text(encoding="utf-8").replace(previous["root"],root).replace(previous["unit"],unit)
    code=code.replace("B1392","B1393")
    if name=="collect.py":
        a,b=code.index("\njob_catalog = "),code.index("\nassert len(jobs)")
        code=code[:a]+"\njob_catalog = "+repr({i:"representative.json" for i in ids})+"\njobs = "+repr([(i,"warm") for i in ids])+code[b:]
    write(quiet/name,code)
assert b"\r" not in (quiet/"run.sh").read_bytes()
parts=("identity.json","representative.json","collect.py","run.sh","archive-owned.py","reference/"+core,"candidate/"+core)
payload=quiet/"payload.tgz"
with tarfile.open(payload,"w:gz")as bundle:
    for item in parts:bundle.add(quiet/item,arcname=item)
unpacked=sum((quiet/item).stat().st_size for item in parts)

# Retire only spare immutable cores and archives with their exact published witnesses.
locations={
    "inline-cased-words-b1390-20261122/candidate/"+core:word_archive,
    "native-operand-call-loan-b1392-20261122/candidate/"+core:reference_archive,
}
known={}
for name,history in locations.items():
    data=gzip.decompress(published(history,"candidate-core.dll.gz"))
    digest=sha(data)
    assert digest==json.loads(published(history,"source.json"))["imageFiles"]["candidate"][core]
    assert digest not in {image[core]for image in files.values()}
    known[name]=(len(data),digest)
archive_locations={}
for path in (repo/"benchmarks/results").glob("*/observations.tgz"):
    receipt_path=path.parent/"archive-receipt.json"
    if path.stat().st_size<250000 or not receipt_path.exists():continue
    info=read(receipt_path)
    if all(info.get(k)for k in ("complete","allWorkersJoined","archivedAndVerifiedUnderLease")):
        archive_locations.setdefault(path.stat().st_size,[]).append((info["archiveSHA256"],path.parent.name))
query="""
from pathlib import Path
import fcntl,hashlib,json,os,shutil,stat
b=Path(BASE);core=CORE;known=KNOWN;archived=ARCHIVED
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
with (b/'comparison-vm.lock').open('a') as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert not any(p.is_mount() for p in b.glob('*/guest-fixtures'))
 ids={}
 for name,(size,digest) in known.items():
  file=b/name;m=file.lstat()
  assert m.st_size==size and sha(file)==digest
  ids[m.st_dev,m.st_ino]=dict(links=m.st_nlink,bytes=size,sha256=digest,paths=[])
 for folder,dirs,names in os.walk(b):
  for name in names:
   p=Path(folder)/name;m=p.lstat();k=(m.st_dev,m.st_ino)
   if k not in ids:continue
   assert p.resolve()==p and name==core and stat.S_ISREG(m.st_mode) and m.st_uid==os.getuid()
   ids[k]['paths'].append(str(p.relative_to(b)))
 owners=set()
 for value in ids.values():
  assert len(value['paths'])==value['links']
  roots={p.split('/')[0]for p in value['paths']}
  owners.update(roots)
  value['receipts']={d:json.loads((b/d/'archive-receipt.json').read_text())['archiveSHA256'] for d in roots}
  value['archives']={d+'/observations.tgz':sha(b/d/'observations.tgz') for d in roots if (b/d/'observations.tgz').is_file()}
  assert all(value['receipts'][p.split('/')[0]]==h for p,h in value['archives'].items())
 redundant=[]
 for p in sorted(b.glob('*/observations.tgz'),key=lambda p:-p.stat().st_size):
  m=p.lstat()
  if p.parent.name in owners or m.st_size not in archived or not stat.S_ISREG(m.st_mode) or m.st_nlink!=1 or m.st_uid!=os.getuid() or p.resolve()!=p:continue
  digest=sha(p)
  match=next((folder for h,folder in archived[m.st_size]if h==digest),None)
  if match:redundant.append(dict(paths=[str(p.relative_to(b))],bytes=m.st_size,links=1,sha256=digest,archives={},published=match))
 print(json.dumps(dict(free=shutil.disk_usage(b).free,cores=list(ids.values()),redundant=redundant)))
""".replace("ARCHIVED",repr(archive_locations)).replace("KNOWN",repr(known)).replace("BASE",repr(base)).replace("CORE",repr(core))
ssh=["C:/Windows/System32/OpenSSH/ssh.exe","-i",str(Path.home()/".ssh/id_lython-bench.pem"),"-o","BatchMode=yes","-o","ConnectTimeout=15","lokad@20.166.121.73"]
inventory=json.loads(subprocess.check_output(ssh+["python3 -"],input=query.encode(),timeout=65))
write(pair/"inventory.json",inventory)
history={"inline-cased-words-b1390-20261122":word_archive,
         "inline-cased-words-repeat-b1391-20261122":"2026-11-22-inline-cased-words-confirmed",
         "native-operand-call-loan-b1392-20261122":reference_archive}
retire=[]
free=inventory["free"]
for proof in inventory["cores"]:
    for owner,digest in proof["receipts"].items():check_archive(history[owner],digest)
    retire.append({k:proof[k] for k in ("paths","bytes","links","sha256","archives")})
    free+=proof["bytes"]
threshold=176160768+unpacked+640*1024
for proof in inventory["redundant"]:
    if free>threshold+260*1024:break
    check_archive(proof["published"],proof["sha256"])
    assert len(published(proof["published"],"observations.tgz"))==proof["bytes"]
    retire.append(proof)
    free+=proof["bytes"]
assert free>threshold,(free,threshold)
config=dict(root=root,unit=unit,identity=identity,source=previous["root"],sourceRole="candidate",
            sourceFiles=previous["identity"]["imageFiles"]["candidate"],sourceCatalogSHA256=previous["identity"]["catalogs"]["representative.json"]["sha256"],
            donorArchiveSHA256=receipt["archiveSHA256"],protocolSource=previous["protocolSource"],protocolSHA256=refs["protocolSHA256"],
            retireGroups=retire,payloadBytes=payload.stat().st_size,payloadSHA256=sha(payload.read_bytes()),unpackedBytes=unpacked)
write(quiet/"config.json",config)
code=(past/"quiet/remote-launch.py").read_text(encoding="utf-8").replace("lython-b1392-fixtures","lython-b1393-fixtures")
a,b=code.index("\nc=")+1,code.index("\nb=Path(")
write(quiet/"remote-launch.py",code[:a]+"c="+repr(config)+code[b:])
write(pair/"launch.py",(past/"launch.py").read_text(encoding="utf-8").replace("Native call operand loan","Regex template replay"))
write(pair/"summarize.py",(past/"summarize.py").read_text(encoding="utf-8"))
print("Verified five workloads and both complete images. Prior archive copies verified:",len(retire),flush=True)
