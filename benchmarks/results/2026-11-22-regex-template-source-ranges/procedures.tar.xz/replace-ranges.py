from pathlib import Path
import sys
runtime=Path(sys.argv[1])/"src/Lokad.Lython/Runtime"
p=runtime/"LythonRuntime.RegexReplacement.cs"
s=p.read_text(encoding="utf-8")
def replace(old,new):
 global s
 assert s.count(old)==1,old
 s=s.replace(old,new)

replace("""    internal readonly record struct RegexReplacementPiece(int Group, int Start, int Length);

    internal sealed class RegexReplacementPlan(byte[] literals, RegexReplacementPiece[] parts, int count,
        MemoryGovernor.TemporaryMemoryReservation storage) : IDisposable
    {
        private byte[] _literals = literals;""","""    internal readonly record struct RegexReplacementPiece(int Group, int Start, int Length)
    {
        internal const int LiteralRange = -1;
        internal const int LiteralScalar = -2;
    }

    internal sealed class RegexReplacementPlan(RegexReplacementPiece[] parts, int count,
        MemoryGovernor.TemporaryMemoryReservation storage) : IDisposable
    {""")
replace("internal void AppendTo(GovernedByteBuilder builder, ReMatchObject match, ExecutionContext context, LythonSourceSpan span)",
        "internal void AppendTo(GovernedByteBuilder builder, PyString template, ReMatchObject match, ExecutionContext context, LythonSourceSpan span)")
replace("internal void AppendTo(GovernedByteBuilder builder, RegexSubjectRange range, ReadOnlySpan<LythonRegexCapture?> captures,",
        "internal void AppendTo(GovernedByteBuilder builder, PyString template, RegexSubjectRange range, ReadOnlySpan<LythonRegexCapture?> captures,")
assert s.count("if (part.Group < 0) AppendRegexBytes(builder, _literals.AsSpan(part.Start, part.Length), context, span);")==2
s=s.replace("if (part.Group < 0) AppendRegexBytes(builder, _literals.AsSpan(part.Start, part.Length), context, span);",
            "if (part.Group < 0) AppendLiteral(builder, template, part, context, span);")
replace("""        public void Dispose()
        {
            _literals = [];
            _parts = [];""","""        private static void AppendLiteral(GovernedByteBuilder builder, PyString template, RegexReplacementPiece part,
            ExecutionContext context, LythonSourceSpan span)
        {
            if (part.Group == RegexReplacementPiece.LiteralRange)
                AppendRegexBytes(builder, template.Utf8Span.Slice(part.Start, part.Length), context, span);
            else
            {
                builder.Append(new Rune(part.Start));
                context.CheckExecution(span);
            }
        }

        public void Dispose()
        {
            _parts = [];""")
replace("plan.AppendTo(builder, match, context, span);","plan.AppendTo(builder, template, match, context, span);")
replace("""            // Fund the private program, literal capacity, transient name keys and
            // construction overlap before allocation. No template storage escapes
            // the operation; the result obtains its independent admission.
            MemoryGovernor.TemporaryMemoryReservation? storage = context.MemoryGovernor.ReserveTemporary(
                checked(256L + 4L * source.Length + 32L * capacity), span);
            GovernedByteBuilder? builder = null;""","""            // The private plan borrows ranges only during replay. The caller
            // keeps the immutable template funded through that use.
            MemoryGovernor.TemporaryMemoryReservation? storage = context.MemoryGovernor.ReserveTemporary(
                checked(256L + 32L * capacity), span);""")
replace("""                builder = new GovernedByteBuilder(source.Length); // capacity is prefunded above
                var parts = new RegexReplacementPiece[capacity];
                var count = 0;
                var literalStart = 0;
                void FlushLiteral()
                {
                    if (builder.Length == literalStart) return;
                    parts[count++] = new(-1, literalStart, builder.Length - literalStart);
                    literalStart = builder.Length;
                }
                void AddGroup(int index)
                {
                    FlushLiteral();
                    parts[count++] = new(index, 0, 0);
                }""","""                var parts = new RegexReplacementPiece[capacity];
                var count = 0;
                var literalStart = 0;
                void FlushLiteral(int end)
                {
                    if (end != literalStart)
                        parts[count++] = new(RegexReplacementPiece.LiteralRange, literalStart, end - literalStart);
                }
                void AddPiece(RegexReplacementPiece piece, int escapeStart, int escapeEnd)
                {
                    FlushLiteral(escapeStart);
                    parts[count++] = piece;
                    literalStart = escapeEnd;
                }""")
replace("""                    if (slash < 0)
                    {
                        builder.Append(chunk);
                        offset += chunk.Length;
                        continue;
                    }

                    builder.Append(chunk[..slash]);
                    offset += slash;""","""                    if (slash < 0)
                    {
                        offset += chunk.Length;
                        continue;
                    }

                    offset += slash;""")
replace("AddGroup(ResolveReplacementGroup(pattern, name, template, nameStart, context, span));",
        """var group = ResolveReplacementGroup(pattern, name, template, nameStart, context, span);
                        AddPiece(new(group, 0, 0), escapeStart, offset);""")
assert s.count("builder.Append(new Rune(value));")==2
s=s.replace("builder.Append(new Rune(value));",
            "AddPiece(new(RegexReplacementPiece.LiteralScalar, value, 0), escapeStart, offset);")
replace("AddGroup(index);","AddPiece(new(index, 0, 0), escapeStart, offset);")
replace(r"""                        if (literal >= 0) builder.Append((byte)literal);
                        else if (escaped is >= (byte)'a' and <= (byte)'z' or >= (byte)'A' and <= (byte)'Z')
                            throw ReplacementError($"bad escape \\{(char)escaped}", template, escapeStart, context, span);
                        else
                        {
                            // Unknown punctuation/non-ASCII escapes keep the slash.
                            // Leave a non-ASCII scalar intact for the next chunk.
                            builder.Append((byte)'\\');
                            if (escaped < 128) builder.Append(escaped);
                            else offset--;
                        }""",r"""                        if (literal >= 0)
                            AddPiece(new(RegexReplacementPiece.LiteralScalar, literal, 0), escapeStart, offset);
                        else if (escaped is >= (byte)'a' and <= (byte)'z' or >= (byte)'A' and <= (byte)'Z')
                            throw ReplacementError($"bad escape \\{(char)escaped}", template, escapeStart, context, span);
                        // Unknown punctuation/non-ASCII escapes remain in the literal range.""")
replace("                FlushLiteral();\n                var plan = new RegexReplacementPlan(builder.ToArrayAndRelease(), parts, count, storage);",
        "                FlushLiteral(source.Length);\n                var plan = new RegexReplacementPlan(parts, count, storage);")
replace("            finally { builder?.Release(); storage?.Dispose(); }", "            finally { storage?.Dispose(); }")
replace("""            // The template transaction funds this transient lookup key.
            var key = PyString.CopyFromUtf8(name, null, span, context);""","""            // Fund the temporary lookup and diagnostic rendering from this
            // name's length. The plan itself keeps no decoded name.
            using var scratch = context.MemoryGovernor.ReserveTemporary(checked(192L + 4L * name.Length), span);
            context.CheckExecution(span);
            var key = PyString.CopyFromUtf8(name, null, span, context);""")
p.write_text(s,encoding="utf-8",newline="\n")
p=runtime/"LythonRuntime.RegexMatcher.cs"
s=p.read_text(encoding="utf-8")
assert s.count("plan.AppendTo(builder, range, match.Captures, context, span);")==1
s=s.replace("plan.AppendTo(builder, range, match.Captures, context, span);","plan.AppendTo(builder, template!, range, match.Captures, context, span);")
p.write_text(s,encoding="utf-8",newline="\n")
