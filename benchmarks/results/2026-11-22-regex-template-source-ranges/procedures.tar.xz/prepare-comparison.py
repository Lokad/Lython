from pathlib import Path
import base64,hashlib,json,os,shutil,struct,subprocess,tarfile,tempfile,statistics

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
out=lab/"comparison"
out.mkdir(exist_ok=True)
def read(p):return json.loads(p.read_text(encoding="utf-8-sig"))
def sha(b):return hashlib.sha256(b).hexdigest()
def write(p,value):p.write_text(json.dumps(value,indent=2)+"\n",encoding="utf-8",newline="\n")
donor=lab.parent/"native-operand-call-loan-20261122/rebased"
catalog=read(donor/"catalog.json")
ordinary=next(r for r in catalog["cases"] if r["id"]=="calls.positional.large")
config=r"""import re
rule = re.compile(r'(?P<label>[a-z]+)-(?P<id>[0-9]+)(?:/(?P<tag>[a-z]+))?')
with open('input.txt', encoding='utf-8') as source:
    with open('output.txt', 'w', encoding='utf-8', newline='') as target:
        for line in source:
            target.write(rule.sub(r'<\g<label> #\g<id>> \g<tag>\t', line))
print('rewritten')
"""
expand=r"""import re
match = re.fullmatch(r'(?P<word>[a-z]+)', 'alpha')
template = TEMPLATE
total = 0
for _ in range(48):
    text = match.expand(template)
    total += len(text)
print(total)
"""
cases=[
    ("file",config,{"input.txt":("alpha-101/main beta-45 gamma-99/prod\n" * 96).encode()},["output.txt"],96),
    ("long-literal",expand.replace("TEMPLATE",r"('z' * 12288) + r'\g<word>\é\377'"),{},[],48),
    ("dense-escapes",expand.replace("TEMPLATE",r"r'\t\n\377\\\g<word>' * 32"),{},[],48),
    ("plain-literal",expand.replace("TEMPLATE",r"'No escapes, configuration label'"),{},[],48),
]
python=Path("C:/Python313/python.exe")
rows=[]
for name,source,inputs,outputs,count in cases:
    with tempfile.TemporaryDirectory(prefix="regex-replay-golden-") as dirname:
        folder=Path(dirname)
        for file,payload in inputs.items():(folder/file).write_bytes(payload)
        completed=subprocess.run([python,"-I","-S","-X","utf8","-c",source],cwd=folder,
            text=True,encoding="utf-8",capture_output=True,check=True,timeout=10)
        files={n:(folder/n).read_bytes() for n in outputs}
        assert not completed.stderr,completed.stderr
    fixture=dict(size=count,text=None)
    if inputs or files:
        raw=bytearray(struct.pack(">i",len(files)))
        for key,value in sorted(files.items()):
            key=key.encode()
            raw.extend(struct.pack(">i",len(key))+key+struct.pack(">i",len(value))+value)
        file_digest=sha(raw)
        fixture["inputFiles"]={n:base64.b64encode(v).decode() for n,v in inputs.items()}
        fixture["outputFiles"]={n:base64.b64encode(v).decode() for n,v in files.items()}
    else:file_digest=None
    spec=json.dumps(fixture,separators=(",",":"))
    stdout=completed.stdout
    rows.append(dict(ordinary,id="diagnostic.regex-template."+name,family="scripts",category="whole-script",scale="bounded",size=count,
        source=source,fixtureJson=spec,expectedOutput=stdout,sourceUtf8Bytes=len(source.encode()),
        expectedOutputUtf8Bytes=len(stdout.encode()),sourceSha256=sha(source.encode()),
        fixtureSha256=sha(spec.encode()),expectedOutputSha256=sha(stdout.encode()),expectedFilesSha256=file_digest))
catalog["cases"]=[*rows,ordinary]
catalog_path=out/"catalog.json"
write(catalog_path,catalog)
baseline=donor/"frozen-candidate"
baseline_files=read(donor/"images.json")["imageFiles"]["candidate"]
assert len(baseline_files)==32 and {n:sha((baseline/n).read_bytes()) for n in baseline_files}==baseline_files
repo_patch=subprocess.check_output(["git","diff","c097d73db","8bdf5f43f","--","src","tests"],cwd=repo)
(out/"source.patch").write_bytes(repo_patch)
protocol=repo/"benchmarks/cpython-worker.py"
protocol_hash=sha(protocol.read_bytes())
assert protocol_hash==read(donor/"images.json")["protocolSHA256"]
core="Lokad.Lython.dll"
sdk=Path.home()/".dotnet11"
dotnet=sdk/"dotnet.exe"
env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk),PATH=str(sdk)+os.pathsep+os.environ["PATH"])
images={}
allocation={}
for role in ("reference","candidate"):
    dest=out/role
    dest.mkdir(exist_ok=True)
    built=lab/("frozen-"+role)/"bin/Lokad.Lython/release_net11.0"/core
    hashes=dict(baseline_files,**{core:sha(built.read_bytes())})
    for file in hashes:shutil.copyfile(built if file==core else baseline/file,dest/file)
    for extra in baseline.glob("ValidatedAllocation.*"):shutil.copyfile(extra,dest/extra.name)
    def check_image():assert {n:sha((dest/n).read_bytes()) for n in hashes}==hashes
    check_image()
    receipt=out/(role+"-verify.json")
    subprocess.run([dotnet,dest/"Lokad.Lython.Benchmarks.dll","--compare","verify","--catalog",catalog_path,
        "--dotnet",dotnet,"--python",python,"--python-worker",protocol,"--out",receipt],env=env,check=True,timeout=85)
    proof=read(receipt)
    assert proof["state"]=="Completed" and proof["caseCount"]==5 and proof["catalogSha256"]==sha(catalog_path.read_bytes())
    raw=out/(role+"-allocation.json")
    subprocess.run([dotnet,dest/"ValidatedAllocation.dll",dest,catalog_path,raw],env=env,check=True,timeout=85)
    allocation[role]=read(raw)["rows"]
    assert all(row["sharedBudgetBaselineRestored"] for row in allocation[role])
    check_image()
    images[role]=hashes
result=[]
for a,b in zip(allocation["reference"],allocation["candidate"],strict=True):
    assert a["id"]==b["id"]
    v=[statistics.median(r["allocatedBytesPerInvocation"]) for r in (a,b)]
    result.append(dict(id=a["id"],managedBytes=v,changePercent=100*(v[1]/v[0]-1),
                       admitted=[r["peakExecutionMemoryBytes"] for r in (a,b)],fullRefund=True))
    print(result[-1],flush=True)
write(out/"images.json",dict(reference="c097d73db",candidate="8bdf5f43f",imageFiles=images,
    protocolSHA256=protocol_hash,catalogSHA256=sha(catalog_path.read_bytes()),sourcePatchSHA256=sha(repo_patch)))
write(out/"allocation-summary.json",result)
