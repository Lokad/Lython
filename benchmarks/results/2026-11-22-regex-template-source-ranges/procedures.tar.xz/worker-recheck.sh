#!/bin/bash
set -euo pipefail
cd /mnt/d/code/Lython/.git/agent-worktrees/regex-template-source-ranges-20261122
export DOTNET_ROOT="$HOME/.dotnet"
export PATH="$DOTNET_ROOT:$PATH"
dir=/mnt/d/code/Lython/.git/agent-notes/review-20261031/regex-template-source-ranges-20261122
artifact="$dir/ubuntu"
cp Directory.Build.props "$artifact/Directory.Build.props"
dest="$artifact/tests/Lokad.Lython.WorkerFixture/bin/Release/net10.0"
mkdir -p "$dest"
cp -a "$artifact/bin/Lokad.Lython.WorkerFixture/release_net10.0/." "$dest/"
cmp "$dest/Lokad.Lython.dll" "$artifact/bin/Lokad.Lython.PublicApi.Tests/release_net10.0/Lokad.Lython.dll"
dotnet test tests/Lokad.Lython.PublicApi.Tests -c Release -f net10.0 --filter 'FullyQualifiedName~RegexAdapterLifetimeTests.ActualBackendWorkObservesInFlightCancellationAndUnwinds' --no-build --artifacts-path "$artifact" --nologo > "$dir/public-worker-ubuntu.log" 2>&1 || { tail -62 "$dir/public-worker-ubuntu.log"; exit 1; }
awk '/Passed!/{count++;print} END{exit count!=1}' "$dir/public-worker-ubuntu.log"
