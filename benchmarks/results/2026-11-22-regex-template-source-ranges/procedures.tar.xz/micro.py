from pathlib import Path
import hashlib,json,os,subprocess

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
out=lab/"comparison"
identity=json.loads((out/"images.json").read_text(encoding="utf-8"))
def check():
    for role,expected in identity["imageFiles"].items():
        assert len(expected)==32 and {n:hashlib.sha256((out/role/n).read_bytes()).hexdigest()for n in expected}==expected
check()
sdk=Path.home()/".dotnet11"
dotnet=sdk/"dotnet.exe"
python=Path("C:/Python313/python.exe")
env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk),PATH=str(sdk)+os.pathsep+os.environ["PATH"])
manifest=out/"catalog.json"
protocol=repo/"benchmarks/cpython-worker.py"
result=[]
cases=["diagnostic.regex-template.long-literal","diagnostic.regex-template.dense-escapes","diagnostic.regex-template.plain-literal",
       "diagnostic.regex-template.file","calls.positional.large"]
for repeat, order in enumerate((cases,list(reversed(cases)))):
    for case in order:
        label=f"{repeat}-{case}"
        receipt=out/(label+".json")
        p=subprocess.run([dotnet,out/"candidate/Lokad.Lython.Benchmarks.dll","--compare","micro",
            "--catalog",manifest,"--dotnet",dotnet,"--baseline-worker",out/"reference/Lokad.Lython.Benchmarks.dll",
            "--python",python,"--python-worker",protocol,"--case",case,"--lane","warm","--out",receipt],
            env=env,capture_output=True,timeout=32)
        (out/(label+".log")).write_bytes(p.stdout+p.stderr)
        row=dict(case=case,repeat=repeat,exitCode=p.returncode)
        if p.returncode==0:
            data=json.loads(receipt.read_text(encoding="utf-8"))
            assert data["catalogSha256"]==identity["catalogSHA256"] and data["state"]=="Completed"
            samples={s["engine"]:s for s in data["summaries"]}
            row.update(samples=samples,deltaPercent=100*(samples["candidate"]["medianMicroseconds"]/samples["baseline"]["medianMicroseconds"]-1))
        result.append(row)
        print(row,flush=True)
        (out/"micro-summary.json").write_text(json.dumps(result,indent=2)+"\n",encoding="utf-8",newline="\n")
check()
