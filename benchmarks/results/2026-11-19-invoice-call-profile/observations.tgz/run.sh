set -eu
root=/home/lokad/lython-bench-checks/invoice-call-profile-b1148-20261119
trap 'result=$?; printf "%s\n" "$result" > "$root/exit-code.txt"' EXIT
python3 "$root/collect.py"
