from pathlib import Path
import hashlib
import json
import shutil
import tarfile

lab = Path(__file__).resolve().parent
pair = lab.parent / 'keyword-default-record-r715'
out = Path('benchmarks/results/2026-11-19-invoice-call-profile')
def read(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))
def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

receipt = read(lab / 'archive-receipt.json')
terminal = read(lab / 'terminal-status.json')
assert terminal['exitCode'] == '0' and terminal['receipt'] == receipt
assert not terminal['remainingWorkers'] and not terminal['remainingTrace']
assert all(receipt[name] for name in ('complete', 'allWorkersJoined', 'quietBeforeAndAfter', 'guestFixturesRemoved',
    'archivedAndVerifiedUnderLease', 'persistentTraceArchivedAndVerifiedBeforeUnmount'))
assert receipt['archiveSHA256'] == digest(lab / 'observations.tgz')
identity = read(lab / 'identity.json')
assert identity['sourceRevision'] == 'c76c59159d77aaab95a1039afda88776d65eb697 versus a7b43ff7c92700984e55a0c38f9604ce58828218'
assert identity['catalogSHA256'] == digest(lab / 'catalog.json')
for role, files in identity['imageFiles'].items():
    assert len(files) == 32
    assert {name: digest(pair / 'frozen' / role / name) for name in files} == files
    verified = read(pair / (role + '-verify.json'))
    assert verified['state'] == 'Completed' and verified['catalogSha256'] == identity['catalogSHA256']

cases = {case['id']: case for case in read(lab / 'catalog.json')['cases']}
rows = read(lab / 'attribution.json')['rows']
assert [row['label'] for row in rows] == ['reference-invoice', 'candidate-annotated', 'candidate-invoice', 'reference-annotated']
for row in rows:
    role = row['label'].split('-', 1)[0]
    files = identity['imageFiles'][role]
    record = read(lab / 'retrieved' / 'profiles' / row['label'] / 'record.json')
    case = cases[row['case']]
    assert record['workload'] == row['case'] and record['lane'] == 'warm'
    assert record['warmupSeconds'] >= 8 and record['exitCode'] == 0 and record['closed']['status'] == 'Closed'
    assert record['verificationBefore']['status'] == record['verificationAfter']['status'] == 'Equivalent'
    observed = {Path(lib['path']).name: lib['sha256'].lower() for lib in record['identity']['libraries']}
    assert observed['Lokad.Lython.dll'] == files['Lokad.Lython.dll']
    assert all(observed[name] == files[name] for name in observed.keys() & files.keys())
    for result in (record['verificationBefore'], *record['batches'], record['verificationAfter']):
        assert result['completedInvocations'] > 0
        for key in ('sourceSha256', 'fixtureSha256', 'expectedOutputSha256'):
            assert result[key] == case[key]
        assert result['actualOutputSha256'] == case['expectedOutputSha256']
        assert result.get('actualFilesSha256') == case.get('expectedFilesSha256')

out.mkdir(exist_ok=True)
for name in ('archive-receipt.json', 'terminal-status.json', 'observations.tgz', 'attribution.json'):
    shutil.copyfile(lab / name, out / name)
with tarfile.open(out / 'procedures.tar.xz', 'w:xz', preset=6) as tar:
    for name in ('identity.json', 'catalog.json', 'prepare.py', 'ops-profile.py', 'collect.py', 'run.sh',
                 'remote-launch.py', 'config.json', 'launch.py', 'launch.log', 'observe-not-before.json',
                 'retrieve.py', 'analyze.py', 'archive-profile.py', 'analysis.log', 'retrieval.log'):
        tar.add(lab / name, arcname=name)
    for role in ('reference', 'candidate'):
        name = role + '-verify.json'
        tar.add(pair / name, arcname=name)
print('Verified both complete 32-file images, goldens, four retained profiles and persistent trace digest.')
