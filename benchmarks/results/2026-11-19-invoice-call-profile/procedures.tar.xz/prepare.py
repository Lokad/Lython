from pathlib import Path
import ast
import hashlib
import json
import tarfile

lab = Path(__file__).resolve().parent
template = lab.parent / 'current-csv-profile-b1140'
pair = lab.parent / 'keyword-default-record-r715'
original = pair / 'quiet'
load = lambda path: json.loads(path.read_text(encoding='utf-8-sig'))
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
source = load(original/'config.json')
receipt = load(original/'archive-receipt.json')
assert receipt['complete'] and receipt['archivedAndVerifiedUnderLease'] and receipt['allWorkersJoined']
assert sha(original/'observations.tgz') == receipt['archiveSHA256']
identity = load(original/'identity.json')
identity.update(purpose='B1148 invoice and annotated call attribution', diagnosticOnly=True)
images = identity['imageFiles']
catalog = original/'representative.json'
assert sha(catalog) == identity['catalogSHA256']
for role, files in images.items():
    assert len(files) == 32
    assert {name: sha(pair/'frozen'/role/name) for name in files} == files
    verified = load(pair/(role+'-verify.json'))
    assert verified['state'] == 'Completed' and verified['catalogSha256'] == identity['catalogSHA256']

jobs = [('reference-invoice', 'scripts.csv-invoice.large', 'warm'),
        ('candidate-annotated', 'scripts.annotated-rule-closures', 'warm'),
        ('candidate-invoice', 'scripts.csv-invoice.large', 'warm'),
        ('reference-annotated', 'scripts.annotated-rule-closures', 'warm')]
assert {job[1] for job in jobs} <= {case['id'] for case in load(catalog)['cases']}
labels = [job[0] for job in jobs]
root = '/home/lokad/lython-bench-checks/invoice-call-profile-b1148-20261119'
unit = 'lython-b1148-invoice-call-profile-20261119'
def write(name, value):
    if name.endswith('.py'): ast.parse(value)
    (lab/name).write_text(value, encoding='utf-8', newline='\n')
def save(name, value):
    write(name, json.dumps(value, indent=2, ensure_ascii=False)+'\n')
save('identity.json', identity)
(lab/'catalog.json').write_bytes(catalog.read_bytes())
for filename in ('ops-profile.py', 'collect.py', 'launch.py', 'retrieve.py', 'run.sh', 'analyze.py'):
    code = (template/filename).read_text(encoding='utf-8-sig')
    code = code.replace('current-csv-profile-b1140-20261119', root.rsplit('/',1)[1])
    code = code.replace("['invoice', 'keywords', 'validated']", repr(labels))
    code = code.replace('B1140 CSV row-finalization CPU attribution', identity['purpose'])
    if filename == 'ops-profile.py':
        start,end = code.index('    for name, case_id, lane in '),code.index('        tree, tfm')
        code = code[:start] + '    for name, case_id, lane in ' + repr(jobs) + ':\n        role = name.split("-", 1)[0]\n' + code[end:]
        code = code.replace('tree / "candidate" /','tree / role /').replace('candidate/"candidate"/filename','candidate/role/filename')
        code = code.replace("['imageFiles']['candidate']", "['imageFiles'][role]").replace("['coreSHA256']['candidate']", "['coreSHA256'][role]")
        code = code.replace('count = 512','count = 128 if name.endswith("-invoice") else 512')
        code = code.replace('if total_capture_seconds > 24:', 'if total_capture_seconds > 26:')
        assert repr(jobs) in code and 'elapsed >= 8' in code and "['imageFiles'][role]" in code
    if filename == 'collect.py':
        code = code.replace("root/'guest-fixtures/profiles'", "root/'profiles'")
        code = code.replace("fixture=root/'guest-fixtures';trace=fixture/'profiles'", "fixture=root/'guest-fixtures';trace=root/'profiles'")
        code = code.replace("for p in fixture.rglob('*'):", "for p in trace.rglob('*'):")
        code = code.replace("p.relative_to(fixture)", "p.relative_to(root)").replace("in fixture.rglob('*')if", "in trace.rglob('*')if")
        code = code.replace("root/'ram-manifest.json'", "root/'profile-manifest.json'").replace("archive.add(fixture/name", "archive.add(root/name")
        code = code.replace("len(records)==3", "len(records)==4")
        code = code.replace("ramTraceArchivedAndVerifiedBeforeUnmount=True", "persistentTraceArchivedAndVerifiedBeforeUnmount=True")
    if filename == 'retrieve.py':
        code = code.replace('ramTraceArchivedAndVerifiedBeforeUnmount','persistentTraceArchivedAndVerifiedBeforeUnmount')
        code = code.replace('RAM traces archived before unmount', 'persistent traces archived before unmount')
    if filename == 'launch.py':
        code = code.replace('Current rule CPU attribution after consolidation', identity['purpose'])
        code = code.replace('seconds=100', 'seconds=95').replace('before 100 seconds','before 95 seconds')
    if filename == 'analyze.py':
        code = code.replace(" focus.update({\n     'row lookup", " focus.update({\n     'general binder':('BindFunctionArgumentsInto','BindSuppliedFunctionArguments','BindFunctionArguments'),\n     'keyword default lookup':('TryGetKeywordDefault','TryGetDefinitionValue'),\n     'native prefix and unpack':('RunCore','FinishUnpackedCall','CompleteUnpackedCallReturn','LoadRetained'),\n })\n focus.update({\n     'row lookup")
    write(filename, code)
names = ('identity.json','catalog.json','ops-profile.py','collect.py','run.sh')
payload = lab/'payload.tgz'
with tarfile.open(payload,'w:gz') as archive:
    for name in names: archive.add(lab/name, arcname=name)
config = dict(root=root,unit=unit,source=source['root'],sourceFiles=images,sourceCatalogSHA256=identity['catalogSHA256'],
              catalogSHA256=identity['catalogSHA256'],identity=identity,retireGroups=[],payloadBytes=payload.stat().st_size,
              payloadSHA256=sha(payload),unpackedBytes=sum((lab/name).stat().st_size for name in names),
              donorArchive=receipt['archiveSHA256'])
save('config.json',config)
launcher = (template/'remote-launch.py').read_text(encoding='utf-8')
start,end = launcher.index('\nc=')+1,launcher.index('\nb=Path(')
launcher = launcher[:start]+'c='+repr(config)+launcher[end:]
launcher = launcher.replace(" for n,h in c['sourceFiles'].items():assert sha(source/'candidate'/n)==h,n", 
                            " for role,files in c['sourceFiles'].items():\n  for n,h in files.items():assert sha(source/role/n)==h,n")
launcher = launcher.replace("for role in ['candidate']:", "for role in ['reference','candidate']:")
launcher = launcher.replace("os.link(source/'candidate'/n,p)", "os.link(source/role/n,p)")
launcher = launcher.replace('+2097152,','+5242880,').replace('lython-b1140-fixtures','lython-b1148-fixtures')
assert "source/'candidate'/n" not in launcher and 'source/role/n' in launcher
write('remote-launch.py',launcher)
print('Verified both complete images and the existing catalog. Staging four diagnostic lanes with persistent profile storage.')
