from pathlib import Path

lab = Path(__file__).resolve().parent
prev = lab.parent / 'current-cpython-b1958-20261128'

def replace(text, source, destination):
    assert source in text, source
    return text.replace(source, destination)

def save(name, text):
    compile(text, name, 'exec')
    path = lab/name
    path.write_text(text, encoding='utf-8', newline='\n')
    assert b'\r' not in path.read_bytes()

prepare = (prev/'prepare.py').read_text(encoding='utf-8')
for source, destination in (
    ("'combined-loop-cpython-b1954-20261128'","'current-cpython-b1958-20261128'"),
    ("'script-cpython-quiet-b1958-20261128'","'script-cpython-quiet-b1963-20261128'"),
    ("startswith('09cecc9ce')","startswith('0b50e6fda')"),
    ("assert len(jobs) == 6\njobs.append(['diagnostic.shipment-row-generator-reduction', 'compile-run'])","assert len(jobs) == 7"),
    ("Refresh warm shipment and JSON comparisons and measure compile-to-result after private generator reduction.",
        "Refresh comparable shipment, JSON and compile-to-result lanes after generator ownership consolidation."),
    ("collector.count('len(jobs) == 6') == collector.count('lython-b1954-cpython-fixtures-retry')",
        "collector.count('len(jobs) == 7') == collector.count('lython-b1958-cpython-fixtures')"),
    ("collector.replace('len(jobs) == 6', 'len(jobs) == 7')\n     .replace('lython-b1954-cpython-fixtures-retry', 'lython-b1958-cpython-fixtures')",
        "collector.replace('lython-b1958-cpython-fixtures', 'lython-b1963-cpython-fixtures')"),
    ("launch.replace('lython-b1954-combined-loop-cpython-retry', 'lython-b1958-current-cpython')",
        "launch.replace('lython-b1958-current-cpython', 'lython-b1963-ownership-cpython')"),
    ("summary.replace(identity['sourceRevision'], head)\n     .replace('len(raw[\"jobs\"])==6', 'len(raw[\"jobs\"])==7').replace('[\"warmJobs\"]==6','[\"warmJobs\"]==7')\n     .replace('==168', '==196').replace('{\"donor\":32}', '{\"donor\":31}')",
        "summary.replace(identity['sourceRevision'], head)"),
):
    prepare = replace(prepare, source, destination)
save('prepare.py',prepare)

compaction = (prev/'compact-completed-images.py').read_text(encoding='utf-8')
start = compaction.index('for folder, remote, unit in (')
end = compaction.index('):\n    local =', start)
compaction = compaction[:start] + """for folder, remote, unit, role in (
    ('call-bound-sum-b1959-20261128', 'script-fixed-sum-repeat-b1959-20261128',
        'lython-b1959-fixed-sum', 'candidate'),
    ('trim-truth-without-result-20261126', 'trim-truth-without-result-b1802-20261126',
        'lython-b1802-trim-truth-without-result-retry-20261126', 'reference'),
""" + compaction[end:]
for source, destination in (
    ("root=remote, unit=unit, archiveSHA256", "root=remote, unit=unit, role=role, archiveSHA256"),
    ("['imageFiles']['candidate']['Lokad.Lython.dll']", "['imageFiles'][role]['Lokad.Lython.dll']"),
    ("root / 'candidate/Lokad.Lython.dll'", "root / row['role'] / 'Lokad.Lython.dll'"),
    ("root / 'packed-candidate-core.dll.gz'", "root / ('packed-' + row['role'] + '-core.dll.gz')"),
    ("root / 'candidate-compaction.json'", "root / (row['role'] + '-compaction.json')"),
):
    compaction = replace(compaction, source, destination)
save('compact-completed-images.py',compaction)
print('Prepared existing checkpoint tools for the combined revision.')
