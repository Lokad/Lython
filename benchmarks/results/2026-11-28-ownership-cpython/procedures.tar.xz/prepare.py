from hashlib import sha256
from pathlib import Path
from shutil import copy2, copytree
from subprocess import check_output
import json
import tarfile

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
previous = lab.parent / 'current-cpython-b1958-20261128'
old = previous / 'comparison/quiet'
quiet = lab / 'comparison/quiet'
core = 'Lokad.Lython.dll'
stage = 'script-cpython-quiet-b1963-20261128'
read = lambda path: json.loads(path.read_bytes())
digest = lambda path: sha256(path.read_bytes()).hexdigest()
hash_image = lambda path: {p.name: digest(p) for p in path.iterdir()}

def save(path, content):
    path.write_text(content, encoding='utf-8', newline='\n')
    assert b'\r' not in path.read_bytes()

def write(path, data):
    save(path, json.dumps(data, indent=2) + '\n')

def git(*args):
    return check_output(['git', *args], cwd=repo)

head = git('rev-parse', 'HEAD').decode().strip()
assert head.startswith('0b50e6fda') and not git('status', '--porcelain')
identity = read(old / 'identity.json')
terminal = read(old / 'terminal-status.json')
receipt = terminal['receipt']
assert not terminal['live'] and not terminal['fixtures'] and terminal['exitCode'] == '0'
assert receipt['complete'] and receipt['allWorkersJoined'] and receipt['quietBeforeAndAfter']
assert digest(old / 'observations.tar.xz') == receipt['archiveSHA256']
donor = identity['imageFiles']['candidate']
assert len(donor) == 32 and hash_image(old / 'local-image') == donor
assert not git('diff', identity['sourceRevision'], head, '--', 'Directory.Packages.props',
    'src/Lokad.Lython.Utf8Regex', 'benchmarks/Lokad.Lython.Benchmarks')

quiet.mkdir(parents=True)
frozen = quiet / 'local-image'
copytree(old / 'local-image', frozen)
build = lab / 'ubuntu-artifacts/bin/Lokad.Lython/release_net11.0' / core
copy2(build, frozen / core)
image = hash_image(frozen)
assert image[core] == digest(build)
assert {name for name, sha in image.items() if donor[name] != sha} == {core}
assert not (frozen / core).samefile(build)
assert all(not p.samefile(old / 'local-image' / p.name) for p in frozen.iterdir())
for name in ('representative.json', 'cpython-worker.py', 'run.sh'):
    copy2(old / name, quiet / name)
assert digest(quiet / 'representative.json') == identity['catalogs']['representative.json']['sha256']
assert digest(quiet / 'cpython-worker.py') == identity['cpythonWorkerSHA256']
assert b'\r' not in (quiet / 'run.sh').read_bytes()
jobs = read(old / 'jobs.json')
assert len(jobs) == 7
write(quiet / 'jobs.json', jobs)
write(quiet / 'identity.json', dict(sourceRevision=head, productionHead=head,
    purpose='Refresh comparable shipment, JSON and compile-to-result lanes after generator ownership consolidation.',
    imageFiles={'candidate': image}, coreSHA256={role: image[core] for role in ('candidate', 'candidate-control')},
    auxiliaryFiles={name: checksum for name, checksum in image.items() if name != core},
    frozenImage=f'/home/lokad/lython-bench-checks/{stage}/candidate',
    catalogs={name: {'sha256': digest(quiet / name)} for name in ('representative.json', 'jobs.json')},
    expectedCPythonSHA256=identity['expectedCPythonSHA256'], cpythonWorkerSHA256=identity['cpythonWorkerSHA256'],
    donorArchiveSHA256=receipt['archiveSHA256']))
collector = (old / 'collect.py').read_text(encoding='utf-8')
assert collector.count('len(jobs) == 7') == collector.count('lython-b1958-cpython-fixtures') == 1
save(quiet / 'collect.py', collector.replace('lython-b1958-cpython-fixtures', 'lython-b1963-cpython-fixtures'))
paths = {name: quiet / name for name in ('identity.json', 'representative.json', 'jobs.json',
    'cpython-worker.py', 'run.sh', 'collect.py')}
paths['candidate/' + core] = frozen / core
payload = quiet / 'stage.tar.gz'
with tarfile.open(payload, 'w:gz') as archive:
    for name, path in paths.items():
        archive.add(path, arcname=name)
with tarfile.open(payload) as archive:
    assert all(sha256(archive.extractfile(name).read()).hexdigest() == digest(path) for name, path in paths.items())
manifest = {name: dict(length=path.stat().st_size, sha256=digest(path)) for name, path in paths.items()}
write(quiet / 'upload.json', dict(root=stage, donor=read(old / 'upload.json')['root'], donorFiles=donor,
    donorArchive=receipt['archiveSHA256'], payloadSHA256=digest(payload), files=manifest,
    expandedBytes=sum(row['length'] for row in manifest.values()), minimumAfterStageBytes=16*1024*1024, caseCount=5))
launch = (previous / 'quiet-vm.py').read_text(encoding='utf-8')
save(lab / 'quiet-vm.py', launch.replace('lython-b1958-current-cpython', 'lython-b1963-ownership-cpython'))
verify = (previous / 'verify.sh').read_text(encoding='utf-8')
save(lab / 'verify.sh', verify.replace(previous.name, lab.name))
summary = (previous / 'summarize.py').read_text(encoding='utf-8')
save(lab / 'summarize.py', summary.replace(identity['sourceRevision'], head))
print(head, len(jobs), 'quiet lanes with five expected output and file goldens')
