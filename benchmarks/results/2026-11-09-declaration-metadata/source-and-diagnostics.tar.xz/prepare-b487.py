from pathlib import Path
import hashlib,json,shutil,tarfile
r=Path(__file__).parent;b=r/'b487';b.mkdir();old=r.parent/'dispatch-liveness-r126/b486'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
base=json.loads((r/'identity.json').read_text(encoding='utf8'))
for p,h in base['changedSources'].items():assert sha(Path(p))==h
root='declaration-layout-b487-20261109';unit='lython-b487-declaration-layout-20261109'
for name in ['collect.py','archive-owned.py','run.sh','launch.py']:
 s=(old/name).read_text(encoding='utf8').replace('dispatch-liveness-b486-20261109',root).replace('lython-b486-dispatch-liveness-20261109',unit).replace('dispatch-liveness-b486-launch.py','declaration-layout-b487-launch.py')
 s=s.replace("reference=base/'text-read-lifetime-b485-20261108/candidate'","reference=base/'dispatch-liveness-b486-20261109/candidate'")
 s=s.replace('len(jobs)==3','len(jobs)==6').replace("len(r['jobs'])==3","len(r['jobs'])==6").replace('jobs=3','jobs=6').replace('allThreeJobsValidated','allSixJobsValidated')
 s=s.replace('RuntimeMaxSec=180','RuntimeMaxSec=240').replace('ownerSeconds=180','ownerSeconds=240')
 s=s.replace('seconds=240','seconds=300').replace('second=240','second=300').replace('seconds=180','seconds=240')
 if name=='collect.py':
  at=s.index('jobs=');end=s.index('\nassert len(jobs)',at)
  jobs=[[key,'warm']for key in ['scripts.csv-validated-records.large','scripts.csv-summary-functions.large','scripts.text-summary-helpers.large','scripts.json-summary-helpers.large','scripts.report-render.large']]+[['scripts.text-summary-helpers.large','warm-async']]
  s=s[:at]+'jobs='+repr(jobs)+s[end:]
  s=s.replace('time.monotonic()-started < 150','time.monotonic()-started < 210')
  at=s.index("purpose='R126");end=s.index("',\n",at)
  s=s[:at]+"purpose='R127 canonical declaration layout/shared syntactic facts. Qualified85e versusac6b, six complete warm jobs/independent controls, original adverse desktop CSV and text retained. Compilation separately measured; no assumed CPU gain"+s[end:]
 (b/name).write_text(s,encoding='utf8',newline='\n')
shutil.copyfile(r/'images-verified/candidate/Lokad.Lython.dll',b/'current-core.dll')
shutil.copyfile(r/'catalog.json',b/'representative.json')
i=dict(sourceRevision='R127 working prototype afterf8dab700, frozenac6b',coreSHA256={role:base['coreSHA256']['before'if role.startswith('reference')else'candidate']for role in ['reference','reference-control','candidate','candidate-control']},auxiliaryFiles={p.name:sha(p)for p in (r/'images-verified/before').glob('*.dll')if p.name!='Lokad.Lython.dll'},catalogSHA256=sha(b/'representative.json'))
(b/'identity.json').write_text(json.dumps(i,indent=2)+'\n',encoding='utf8')
for name,path in [('pre-measurement-plan.md',Path('PLAN.md')),('source.patch',r/'source.patch')]:shutil.copyfile(path,b/name)
for name,data in {'baseline-source.json':base,'focused.json':dict(eachTarget=dict(initialInternal=41,initialPublic=360,extraInternal=23,extraPublic=149),actualTargets=['net11.0','net10.0'],fixtureChanges='Four constructor calls, no assertion changes'), 'setup-contract.json':dict(roles=4,jobs=6,ownerSeconds=240,stopSeconds=30,marginSeconds=30,normalGcAndTiering=True,publication=False),'sizing.json':dict(jobs=6,warmupPerRoleSeconds=5,rounds=7,targetBatchSeconds=.15,expectedSeconds=180,ownerSeconds=240)}.items():(b/name).write_text(json.dumps(data,indent=2)+'\n',encoding='utf8')
(b/'contract.md').write_text('R127 flat declaration signature shared across frontend/lowering/runtime; no new registry/cache owner/carrier/guard/option. Mutable defaults and captured abstract flow remain distinct. Qualified85e reference, ac6b candidate; same worker/optional0.4, six complete scripts/APIs jobs, four processes each. Warm public execution/mediatedRAMfiles/fullgoldens/budgetbalances/priorresultcleanup; compile/startup/reset/protocol/finalcacheteardown excluded. Compilation diagnostic separate. Keep adverse desktop CSV/text and unstable controls.240sfiniteowner/join/RAMunmount/archive-under-lease/localverification.\n',encoding='utf8')
space=json.loads((r/'space.json').read_text(encoding='utf8'))
for name,key in [('space-plan.json','plan'),('space-receipt.json','receipt')]:(b/name).write_text(json.dumps(space[key],indent=2)+'\n',encoding='utf8')
names=['collect.py','archive-owned.py','run.sh','current-core.dll','identity.json','pre-measurement-plan.md','baseline-source.json','source.patch','focused.json','setup-contract.json','sizing.json','contract.md','space-plan.json','space-receipt.json']
with tarfile.open(b/'payload.tgz','w:gz')as a:
 for name in names:a.add(b/name,arcname=name)
for name in ['collect.py','archive-owned.py','launch.py']:compile((b/name).read_text(encoding='utf8'),name,'exec')
assert 'RuntimeMaxSec=240'in(b/'launch.py').read_text()and'len(jobs)==6'in(b/'collect.py').read_text()
print('Prepared bounded B487',sha(b/'current-core.dll'),(b/'payload.tgz').stat().st_size)
