from pathlib import Path
import re,shutil
r=Path(__file__).parent;src=Path('src/Lokad.Lython')
layout=src/'Frontend/FunctionParameterLayout.cs'
shutil.copyfile(layout,r/'FunctionParameterLayout.before.cs');shutil.copyfile(r/'FunctionParameterLayout.next.cs',layout)
plan=src/'Runtime/Calls/FunctionBindingPlan.cs';s=plan.read_text(encoding='utf8')
s=s.replace('public IReadOnlyList<LoweredFunctionParameter> PositionalParameters => _layout.PositionalParameters;', 'public int PositionalCount => _layout.PositionalCount;\n\n    public int ParameterCount => _layout.ParameterCount;\n\n    public string NameAt(int index) => _layout.NameAt(index);')
s=s.replace('public IReadOnlyList<LoweredFunctionParameter> KeywordOnlyParameters => _layout.KeywordOnlyParameters;', 'public int KeywordOnlyCount => _layout.KeywordOnlyCount;')
s=s.replace('public LoweredFunctionParameter? VariadicList => _layout.VariadicList;', 'public int VariadicListIndex => _layout.VariadicListIndex;')
s=s.replace('public LoweredFunctionParameter? VariadicDictionary => _layout.VariadicDictionary;', 'public int VariadicDictionaryIndex => _layout.VariadicDictionaryIndex;')
plan.write_text(s,encoding='utf8')
paths=[plan,src/'Runtime/LythonRuntime.Calls.Binding.cs',src/'Runtime/PyFunctionBase.cs',src/'Runtime/PyFunctionBinding.cs']
for p in paths:
 s=p.read_text(encoding='utf8')
 s=s.replace('plan.LayoutParameterIndex[plan.VariadicList.Name]','plan.VariadicListIndex').replace('plan.LayoutParameterIndex[plan.VariadicDictionary.Name]','plan.VariadicDictionaryIndex')
 s=s.replace('PositionalParameters.Count','PositionalCount').replace('KeywordOnlyParameters.Count','KeywordOnlyCount')
 s=re.sub(r'((?:\w+\.)?)PositionalParameters\[([^\]]+)\]\.Name',lambda m:m[1]+'NameAt('+m[2]+')',s)
 s=re.sub(r'((?:\w+\.)?)KeywordOnlyParameters\[([^\]]+)\]\.Name',lambda m:m[1]+'NameAt('+m[1]+'PositionalCount + '+m[2]+')',s)
 s=s.replace('VariadicList is not null','VariadicListIndex >= 0').replace('VariadicList is null','VariadicListIndex < 0')
 s=s.replace('VariadicDictionary is not null','VariadicDictionaryIndex >= 0').replace('VariadicDictionary is null','VariadicDictionaryIndex < 0')
 s=s.replace('new FunctionParameterLayout(parameters)','FunctionParameterLayout.Create(parameters)')
 s=s.replace('var parameterCount = plan.LayoutParameterNames.Count;','var parameterCount = plan.ParameterCount;')
 p.write_text(s,encoding='utf8')
p=src/'Frontend/ExecutableScript.Comprehensions.cs';s=p.read_text(encoding='utf8');assert'new FunctionParameterLayout([])'in s;p.write_text(s.replace('new FunctionParameterLayout([])','FunctionParameterLayout.Create([])'),encoding='utf8')
p=src/'Frontend/LoweredExpression.cs';s=p.read_text(encoding='utf8');assert'ParameterLayout = new(Parameters);'in s;p.write_text(s.replace('ParameterLayout = new(Parameters);','ParameterLayout = FunctionParameterLayout.Create(Parameters);'),encoding='utf8')
print('Flattened runtime signature metadata; frontend sharing next, no timing yet')
