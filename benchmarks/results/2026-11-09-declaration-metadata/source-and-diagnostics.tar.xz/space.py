from pathlib import Path
import json,shlex,subprocess
r=Path(__file__).parent;old=r.parent/'dispatch-liveness-r126'
g=next(g for g in json.loads((old/'aux-space-probe.json').read_text(encoding='utf8'))['groups']if g['name']=='Microsoft.CodeAnalysis.CSharp.dll')
records=[i for i in g['usableInodes']if len(i['paths'])==1]
remote=r'''from pathlib import Path
import fcntl,hashlib,json,os,shutil,stat,subprocess
base=Path('/home/lokad/lython-bench-checks');records=RECORDS;digest=DIGEST
with(base/'comparison-vm.lock').open('a')as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[c]ollector.dll|[p]erf record'],capture_output=True).returncode==1
 source=base/'dispatch-liveness-b486-20261109/candidate/Microsoft.CodeAnalysis.CSharp.dll';sourceStat=source.lstat();key=(sourceStat.st_dev,sourceStat.st_ino)
 assert sourceStat.st_uid==os.geteuid()and os.access(source.parent,os.W_OK)
 selected=[]
 for rec in records:
  p=Path(rec['paths'][0]);s=p.lstat()
  if(s.st_dev,s.st_ino)==(rec['device'],rec['inode'])and(s.st_dev,s.st_ino)!=key and s.st_nlink==1 and s.st_uid==os.geteuid()and s.st_gid==sourceStat.st_gid and stat.S_IMODE(s.st_mode)==stat.S_IMODE(sourceStat.st_mode)and os.access(p.parent,os.W_OK):selected.append(p)
  if len(selected)==8:break
 assert len(selected)==8
 keys={key:[]}|{(p.stat().st_dev,p.stat().st_ino):[]for p in selected}
 for p in base.rglob(source.name):
  s=p.lstat();inode=(s.st_dev,s.st_ino)
  if inode in keys:keys[inode].append(p)
 proofs=[]
 for inode,paths in keys.items():
  s=paths[0].lstat();assert s.st_nlink==len(paths)
  for p in paths:assert p.resolve()==p and base in p.parents and p.lstat().st_uid==os.geteuid()and os.access(p.parent,os.W_OK)and stat.S_ISREG(p.lstat().st_mode)
  assert hashlib.sha256(paths[0].read_bytes()).hexdigest()==digest
  proofs.append(dict(device=inode[0],inode=inode[1],allocated=s.st_blocks*512,nlink=s.st_nlink,paths=[str(p)for p in paths],sha256=digest))
 before=shutil.disk_usage(base).free;plan=base/'r127-b487-exact-aux-space-plan.json';assert not plan.exists()
 plan.write_text(json.dumps(dict(freeBefore=before,canonical=str(source),proofs=proofs,targets=[str(p)for p in selected],noUsers=True,allAliasesVerified=True,sameOwnerGroupMode=True),indent=2)+'\n')
 for target in selected:
  temporary=target.with_name('.r127-b487-exact-aux-link');assert not temporary.exists();os.link(source,temporary)
  assert hashlib.sha256(temporary.read_bytes()).hexdigest()==digest;os.replace(temporary,target)
 for p in [p for paths in keys.values()for p in paths]:assert(p.stat().st_dev,p.stat().st_ino)==key
 assert hashlib.sha256(source.read_bytes()).hexdigest()==digest
 after=shutil.disk_usage(base).free
 receipt=dict(freeBefore=before,freeAfter=after,recoveredBytes=after-before,displacedInodes=8,allOriginalPathsBytesAndModesPreserved=True,allAliasesVerified=True,preMutationPlan=str(plan))
 (base/'r127-b487-exact-aux-space-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
 print(json.dumps(dict(plan=json.loads(plan.read_text()),receipt=receipt)))
'''.replace('RECORDS',repr(records)).replace('DIGEST',repr(g['sha256']))
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
compile(remote,'r127-space','exec')
(r/'space-launch-failed.json').write_text(json.dumps(dict(error='WinError206 before SSH process spawn',condition='Inline command exceeded Windows argv length',correction='Send the same source over stdin; no VM work started'),indent=2)+'\n',encoding='utf8')
done=subprocess.run(ssh+['python3 -'],input=remote.encode('utf8'),capture_output=True);(r/'space.log').write_bytes(done.stdout+b'\n'+done.stderr)
assert done.returncode==0,done.stderr.decode()
d=json.loads(done.stdout);(r/'space.json').write_text(json.dumps(d,indent=2)+'\n',encoding='utf8');print(d['receipt'])
