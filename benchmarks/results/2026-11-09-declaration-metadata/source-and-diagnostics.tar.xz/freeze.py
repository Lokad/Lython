from pathlib import Path
import hashlib,json,shutil,subprocess
r=Path(__file__).parent;prior=r.parent/'dispatch-liveness-r126'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
images=r/'images-verified';assert not images.exists()
cores=[Path(p)/'bin/Release/net11.0/Lokad.Lython.dll'for p in ['src/Lokad.Lython','tests/Lokad.Lython.Tests','tests/Lokad.Lython.PublicApi.Tests']]
assert len({sha(p)for p in cores})==1
for role in ['before','candidate']:shutil.copytree(prior/'images-verified/candidate',images/role)
assert sha(images/'before/Lokad.Lython.dll')=='85e68bf6d06297ecf8cac1a50f1150ef6be59f431bd9e0c18ea3fc4dcc625e71'
shutil.copyfile(cores[0],images/'candidate/Lokad.Lython.dll')
for n in ['measure.py','catalog.json']:shutil.copyfile(prior/n,r/n)
s=(prior/'assess-local.py').read_text(encoding='utf8');at=s.index("out['limitations']=");end=s.index("\n(r/'assessment-local",at)
s=s[:at]+"out['limitations']='R127 canonical declaration signature: flat names/counts/slots, frontend keyword maps and generator rescans removed, lexical synthetic parameter wrappers removed. Qualified9f2e/core85e before, current working candidate. Same worker/optional0.4, five unchanged complete scripts/bothAPIs, publicRun/awaitedRunAsync/fullgoldens/budgets/cleanup. Warm excludescompile; compilation separate. SharedCoreLib/ALCs/processGC and desktop controls: elapsed diagnostic, no CPU-gain claim.'"+s[end:]
(r/'assess-local.py').write_text(s,encoding='utf8')
shutil.copyfile(r.parent/'prepared-binding-r124/compile-diagnostic.py',r/'compile-diagnostic.py')
changed=subprocess.check_output(['git','diff','--name-only','--','src','tests'],text=True).splitlines()
i=dict(baseline='Fully qualified9f2e/core85e, cachedCI42538659198success; never requery',candidate='R127 canonical declaration metadata working prototype afterca6; docs-only delivery commit leaves production source unchanged',coreSHA256={role:sha(images/role/'Lokad.Lython.dll')for role in ['before','candidate']},changedSources={p:sha(Path(p))for p in changed},patchBase='ca6e89e4/9f2e production; all unlisted tracked production paths unchanged',qualification='41internal/360public eachactual11/10 pass; full candidate delivery pending',contract='No public API or allocator policy change; coarse compilation/dynamic signature estimates unchanged. Actual allocation reduction need not reduce admitted allowance.')
(r/'identity.json').write_text(json.dumps(i,indent=2)+'\n',encoding='utf8')
(r/'source.patch').write_bytes(subprocess.check_output(['git','diff','--','src','tests']))
shutil.copyfile('PLAN.md',r/'pre-measurement-plan.md')
print(i['coreSHA256'])
