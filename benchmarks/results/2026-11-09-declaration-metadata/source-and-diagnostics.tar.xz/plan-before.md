# Lokad.Lython 0.11.0

Updated 2026-11-09 (Paris). Git-ignored: never force-add. Publication/tagging postponed.
Objective: coherent simplification and substantial complete-script performance.
Current contracts live in docs; historical conditions, failed/adverse results and
prototypes remain in [experimental history](benchmarks/EXPERIMENTS.md) and linked
immutable results. Completing an experiment does not complete this objective.

## Actual delivery status

- **Fully qualified reference:** R119 d05; R120/R121 runtime 6f76/core C617 with
  typed-fixture correction d97. Cached CI 42527042378 success, observed Nov8
  22:19:56 UTC: Windows/Ubuntu full Release actual .NET11/10, original stress
  both targets and installed-core consumers. Do not repeat unchanged qualification.
- **R125 fully qualified:** 3109c871/core004e. Requested text-reader
  cleanup waits for copy/decoder/append borrows, pending reads and awaited disposal.
  Qualified-reference regressions demonstrated premature342B refund including72B
  raw input.228 internal/140 public focused cases peractual11/10,16 new cases pass.
  B485 three jobs86.526s, all source/golden/quiet/ownership/cleanup/archive gates pass;
  no CPU gain claim. Cached CI42536319061 success observed Nov9 00:08:01UTC verifies
  Windows/Ubuntu full Release actual11/10, original stress both and installed-core
  consumers. Terminal cached, never requery; qualifies3109/core004e only.

- **R126 committed development change, not fully qualified:** 9f2e1f51/core85e.
  Five forced CLR-liveness NoInlining attributes/comments/imports removed:17 lines,
  same algorithms/owners/retirement.189 internal/229 public plus21 internal stack/
  60 public stack cases pass peractual11/10; matching probes rebuilt. Existing
  GC/lifetime tests unchanged. Allocation neutral within0.064%; no CPU gain claim.
  Desktop sync text/report improve diagnostically, JSON+5.69..+8.16% adverse;
  async controls drift17.54%. Retain development simplification with explicit debt;
  B486 three jobs87.001s/allgates/archive/localpass: JSON elapsed adverse does
  not reproduce, text supports possible gains with reference spread5.27%, report
  inconclusive/possible CPU debt. All24797ILbodies/signatures unchanged; five
  implementation bits differ. Full coherent delivery CI42538659198 dispatched on
  ca6e89e4 (runtime9f2e), Nov9 00:09:38UTC; first observation>=00:14:38UTC.
- **R124 held, not promoted:** compiler-owned named slots/shared defaults; extra
  registry/mapping/guard left general binding necessary. Warm allocation neutral,
  compile allocation+0.20–0.25%; B483/B484 no stable whole-script CPU gain, primary
  CSV candidate spread4.33%. Correctness/source/binaries/original adverse evidence
  preserved. Production restored with fresh builds; useful named/default/suspended/
  cancellation/refusal/alias tests retained. No permanent rejection or percentage veto.
- **Earlier completed work preserved:** shared compiler-fact correction, direct
  UTF-8 formatting/storage, native helper returns, native JSON construction, record
  capacity/adoption, primitive result facts, flat lookup storage and execution-owned
  function field facts. Native-return allocation−19.92/−19.31% is established;
  original elapsed improvements diagnostic. Delivered code qualified, no replay.

**Separate measurements/debts:** formatting allocation−8.67% established;
controlled B102 elapsed/CPU−5–8% supports retention, original adverse15.125ms remains
unexplained/preserved. R110 wide allocation−8.56–8.58%. R119 CSV/JSON~5–10% elapsed,
custom~3–6%, supporting CPU; text inconclusive, report CPU+1.53–6.25% possible debt.
R120 custom allocation−1.71%, no CPU claim. R121 confirmation report−6.09–6.66%,
validated CSV−3.30–5.45%, supporting CPU; inline control±0.60%, async float variable.
Earlier combined async-float+1–2% possible debt remains. Source pairs are not
additive and do not silently settle older custom/config/report debts.

**CPython baseline:** [BENCHMARKS](docs/BENCHMARKS.md), R122/B481, measured6f76/C617
versus CPython3.13.16:15 jobs311.685s, all collection/archive gates pass. Compile-to-
result validated CSV1.17x, CSV1.01–1.03x variable, text1.52–1.53x, JSON0.91–0.96x
variable, report1.32–1.33x. Compilation/warm separate; mediated RAM-file I/O,
validation and prior-result cleanup included. Startup/pending I/O/RSS/embedding tails
unmeasured. Config/search/manifest remain historical726. Refresh after a substantial
coherent change; do not relabel historical measurements as current HEAD.

## Next deliverables: runtime/performance track

1. **Qualify retained R126 at the delivery boundary.** R125 full delivery is complete/cached;
   do not query completed runs again. R126 focused/quiet gates pass separately. R126 challenges the prior assumption that
   CLR-liveness fences must remain: explicit admitted slots/continuations/retirement
   own real users independently of physical collection. Thread/managed-stack and
   recursive-empty-storage boundaries remain. No public API or existing test/assertion
   changed. Completed B486 comparison uses complete text/report/adverse JSON, independent
   controls and unchanged worker/fixtures/normal GC/tiering. Text−7.23..−2.16% with
   reference5.27%; report−4.15..+1.32%/possible CPU debt; JSON−2.07..+0.94%, adverse
   elapsed not reproduced. Keep coarse CPU and control uncertainty explicit.
   CI42538659198 qualifies the retained source independently; continue roadmap work
   while it runs, do not query before00:14:38UTC. Prefer targeted refinement supported
   by evidence over a blanket policy. No further
   unchanged desktop replay without a specific measurement correction. Then batch
   platform/stress/installed-core qualification at a coherent retained boundary.

2. **Complete call/frame/operand simplification.** Hypothesis: consolidate canonical
   preparation/shared compiler facts to eliminate a COMPLETE repeated phase.
   R123 helper/inline~5.1/3.3ms includes useful calls/tuple work; binding/workspace
   4.97%leaf, preparation4.14%, tuple0.99%, context0. Inclusive frame work is not a
   removable tax. Existing BeginPendingCall/BeginBoundCall already uses a linear
   caller-return runner and lazy context promotion. Bound locals, tuple unpack and
   final tuple arrays already borrow/transfer; layouts are shared and ordinary
   presence bits inline. Do not recreate a VM stack, missing local array or context.
   Generic variadic staging exists but is absent from the measured primary helper;
   it is not demonstrated dominant work. R124 facts may serve broader consolidation.
   Source gate ~20min: name actual eliminated storage/work, displaced code and
   affected validated CSV/report/JSON/text helpers BEFORE implementation. Preserve
   native returns/direct operands, defaults/closures/recursion/order, real suspension
   and funded aliases. Do not revive slower R71 arenas/control/carriers or add an
   evaluator/owner/dispatcher. A justified temporary setback needs an explicit
   implementation-completion milestone and a remaining regression-debt decision.
   Acceptance: semantics/current cancellation/refusal/ownership; primary scripts and
   native controls, separate compile/warm/allocation/CPU, bounded quiet comparison.

   R127 selected: one immutable function-declaration signature across frontend,
   lowering and runtime. Current layout keeps positional/keyword-only arrays of
   lowered parameters beside an existing flat names/index table; only names/counts
   are consumed. Frontend separately rebuilds a keyword-index dictionary for each
   shape check and rescans generator bodies per inferred call. Replace these with
   the existing flat table/counts/variadic positions, cached once on finalized syntax.
   Summaries borrow declaration metadata; captured abstract states remain distinct.
   Remove synthetic lowered-parameter wrappers used only to collect lexical names.
   Preserve source binding order, dynamic defaults/annotations, positional-only and
   bound-method diagnostics, generator scope rules, actual async default protocols,
   first refusal/cancellation, construction rollback and retained argument funding.
   No registry, runtime cache, prepared-call guard, owner, carrier or public option.
   Completion: compiled definitions share one layout, old role arrays and frontend
   shape maps/body rescans disappear; generated/lambda definitions use the same flat
   layout with existing explicit admission. Measure compilation and complete-script
   warm execution separately against frozen85e with unchanged primary scripts and
   controls. Allocation/structural reduction does not imply CPU gains. Focused11/10
   gates first; one bounded quiet comparison after source/correctness diagnostics.

3. **Independent bulk/text/frontend work.** Each selected redesign must name its
   hypothesis, complete work/storage eliminated, affected scripts, semantic acceptance,
   displaced implementation and bounded controls before coding. Source gate ~20min;
   if no real phase is demonstrated, record uncertainty and pursue independent work.
   - Bulk CSV6–8% was reconsidered with its adverse control. Current CSV adopts row
     arrays and bulk-admits final fields; JSON constructs direct/shared-layout values.
     The old copying premise is gone. Preserve duplicates/order/rest fields/hooks/
     retained rows. R118 get/add/store would duplicate CFG/proofs; no prototype.
   - Text: native/inline UTF-8, casing split, final-buffer formatting and cached hashes
     delivered. Raw windows already borrow input; independent output protects refill.
     R125 fixes actual pending-borrow funding first. R54/R60 views had width/accessor/
     control debt; a new representation needs retained-page/identity/completion proof.
     Existing b1/core93e9 text CPU/PC evidence is named-source evidence, not HEAD:
     18.79%prefix,8.36%casing/split,4.31%monitor,0leafbinding/context. Hash walks,
     repeated proofs and per-fragment budget resizes were not present. R126 reassesses
     only the liveness-policy premise, not all useful work in those samples.
   - Frontend: ScopeDirectiveFacts already memoizes syntax, LexicalScopePreparation
     publishes before lowering. Repeated ForFunction callers are not duplicate walks.
     Identify actual repeated analysis and compile-to-result costs before consolidation.
   No open-ended audit/capture campaign. Boxing/inclusive samples alone do not justify
   universal tagged slots, a JIT or VM-stack replacement. The whole-script objective
   remains active after individual deletions or experiments.

## Independent regex track

Core owns Python/native UTF-8 names, byte captures/scalar positions/original-subject
windows, effective flags/errors/replacements, one frontend/runtime/import provider,
current tokens and existing explicit ownership. Continue core development independently
of publication. Adapter-local bridges/pinned development producers are allowed outside
core. Optional adapter nonpackable, ordinary selected pin0.4. Dev55/d6067925 focused
86 internal/514 public peractual11/10 already passed; no unchanged replay or sibling
edits/builds. Final selected-package qualification needs DetailedData with distinct
preparation/working owners, native-name enumeration and cursor creation without an
earlier token. Only affected final adapter checks defer. Contract forwarding/unwind,
Python semantics and actual backend speed remain separate evidence.

## Iteration and containment

Bounded confirmation/refinement/measurement correction is allowed when justified.
Timeout, unstable controls or inconclusive observations establish uncertainty, not
failed designs or permanent closure. Size runs for usable quiet-VM observations;
percentages inform decisions, not automatic vetoes. Preserve original failed/adverse
conditions. Simplification, allocation reduction and CPU gains are distinct claims.
Focused Release checks during development; batch full delivery at meaningful boundaries.

AGENTS.md governs fully managed safety/stack admission, host mediation, current-token
cancellation, coarse shared admission/preflights/overlap, funded aliases/results/
caches/pending users and awaited cleanup. Refusal is terminal. No unsafe/Unsafe/native
probes, tracing/weak reclaim/forced GC, caps/fuel/quotas, hidden allowance, silent regex
fallback or abandoned work. No local build/test/measurement overlap. Fresh nonincremental
builds after restoration; explicit UTF-8. Only core Release packages to artifacts/nuget.

VM lokad@20.166.121.73, key ~/.ssh/id_lython-bench.pem. Persistent worker/catalog/raw
storage separate from owned RAM fixtures; join/verify/unmount/archive under lease,
verify locally. ThroughB486 terminal/cached/verified, no users/fixtures; never requery.
New active CI observations at least5min apart; cache terminal results. Space recovery
only fresh idle exact-byte links, permitted canonical ownership/writable parents,
all inode aliases/SHA proof and a persisted pre-mutation plan. Preserve every historical
path/byte/archive and original failed collection condition. Publication postponed.
