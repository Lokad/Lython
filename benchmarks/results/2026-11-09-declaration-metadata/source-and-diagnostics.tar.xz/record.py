from pathlib import Path
import hashlib,json,shutil,tarfile
r=Path(__file__).parent;b=r/'b487';dest=Path('benchmarks/results/2026-11-09-declaration-metadata');dest.mkdir(exist_ok=True)
for name in ['identity.json','assessment-local.json','compile-assessment.json']:
 shutil.copyfile(r/name,dest/name)
for name in ['assessment.json','observations.tgz']:shutil.copyfile(b/name,dest/name)
t=json.loads((b/'terminal.json').read_text(encoding='utf8'))
assert hashlib.sha256((dest/'observations.tgz').read_bytes()).hexdigest()==t['receipt']['archiveSHA256']
(dest/'archive-receipt.json').write_text(json.dumps(t,indent=2)+'\n',encoding='utf8')
validation=dict(actualFrameworks=['net11.0','net10.0'],eachTarget=dict(internalInitial=41,publicInitial=360,internalAdditional=23,publicAdditional=149),testChanges='Four internal fixture constructor calls only; no assertions removed or relaxed',fullDelivery='Pending coherent delivery checkpoint; R126 CI qualifies9f2e/core85e only',decision='Retain declaration metadata consolidation; small compilation allocation reduction, no general CPU gain claim; possible CSV elapsed debt remains')
(dest/'focused-validation.json').write_text(json.dumps(validation,indent=2)+'\n',encoding='utf8')
with tarfile.open(dest/'source-and-diagnostics.tar.xz','w:xz')as a:
 for p in sorted(r.iterdir()):
  if p.is_file()and p.suffix in ['.py','.log','.json','.md','.patch','.cs']:a.add(p,arcname=p.name)
 for name in ['warm-sync','warm-async','compile-sync']:a.add(r/name,arcname=name)
 a.add(r/'images-verified/candidate/Lokad.Lython.dll',arcname='candidate-coreac6b.dll')
 for name in ['launch.py','launch.log','launch-command.py','terminal.json','terminal-observation.log','identity.json','observe-not-before.json']:
  a.add(b/name,arcname='b487/'+name)
p=Path('benchmarks/EXPERIMENTS.md');s=p.read_text(encoding='utf8')
s+='''

## Shared function-declaration metadata (2026-11-09 Paris)

[R127/B487](results/2026-11-09-declaration-metadata/README.md), qualified9f2e/core85e
versus prototypeac6b. One declaration-owned flat signature replaces redundant role
arrays/lowered-parameter retention, per-shape keyword maps, repeated inferred-call
generator scans and synthetic lowered parameters used only for lexical names.
Captured flow states, mutable defaults/annotations, general binding and existing
admission/cleanup remain distinct. No registry, guard, owner, carrier or public API.
41internal/360public plus23internal/149public focused cases peractual11/10 pass.
Compilation allocation−0.10..−0.32%, warm allocation neutral within0.066%; no admitted
allowance reduction. Original desktop sync CSV+13..15%/text+21..22% preserved.
B487 six quiet jobs168.433s/allgates/archive/localpass: validated CSV+0.36..+1.06%,
CSVsummary−0.25..+1.61%, text−3.50..−0.91%, JSON−1.79..+1.43%, report−3.02..−0.05%,
async text−3.22..−1.00%. Coarse CPU mixed except supporting async text−2.70%.
Large desktop adverse timings do not reproduce; possible small CSV debt remains.
Retain coherent metadata simplification, no universal speedup/neutrality claim or
unchanged retiming selected. Full candidate delivery pending; broader objective open.
Space plan preceded exact-byte links for eight singleton compiler-library aliases,
56,131,584B recovered with historical paths/bytes/metadata preserved. Original
Windows argument-length launch failure and corrected stdin transport retained.
All users joined/RAM removed/archive verified locally; terminal cached. Publication postponed.
'''
p.write_text(s,encoding='utf8')
p=Path('PLAN.md');s=p.read_text(encoding='utf8')
start=s.index('1. **R125/R126 delivery complete;')
end=s.index('2. **Complete call/frame',start)
s=s[:start]+'''1. **R127 retained; coherent delivery checkpoint.** Commit canonical declaration
   metadata and its source-paired evidence. Focused 41internal/360public plus
   23internal/149public cases pass peractual11/10. Compilation allocation−0.10..−0.32%;
   warm allocation neutral within0.066%. B487 six quiet jobs168.433s/allgates/archive
   localpass: validated CSV+0.36..+1.06%, CSVsummary−0.25..+1.61%, text−3.50..−0.91%,
   JSON−1.79..+1.43%, report−3.02..−0.05%, async text−3.22..−1.00%; coarseCPU mixed.
   Preserve desktop CSV+13..15%/text+21..22% and possible small quiet CSV debt.
   Retain for work/storage removed, no universal gain/neutrality claim. Full candidate
   Windows/Ubuntu actual11/10, original stress both and installed-core checks next;
   keep working while CI runs. R125/R126 already fully qualified: no unchanged replay.

'''+s[end:]
start=s.index('   R127 selected:')
end=s.index('\n3. **Independent',start)
s=s[:start]+'''   R127 removes role arrays/lowered parameter retention beside the flat names/index
   table, per-call frontend shape maps, repeated generator body scans and synthetic
   lowered wrappers for lexical names. Analysis/lowering/runtime share finalized
   declaration facts; captured flow states/defaults/annotations remain separate.
   No new registry/guard/cache/owner/carrier/option. Evidence/history linked above.
   Next source selection: one short compile-only profile on the current frozen image
   for representative helper/config scripts, to distinguish parsing, flow analysis,
   lowering and executable construction. Existing worker compile lane and perf only;
   two ~6s samples, finite owner, no new harness or warm capture. Stop with phase
   attribution and choose at most one complete repeated phase to remove; if no
   material candidate is established, record that and continue the independent track.
   Preserve current cancellation, diagnostics/scopes, first refusal and retained owners.
'''+s[end:]
s=s.replace('ThroughB486 terminal/cached/verified','ThroughB487 terminal/cached/verified')
p.write_text(s,encoding='utf8')
print('R127 evidence archived; retained consolidation with measured uncertainty')
