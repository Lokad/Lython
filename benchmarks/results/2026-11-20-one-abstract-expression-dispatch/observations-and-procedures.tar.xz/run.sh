#!/bin/sh
set -eu
cd "$(dirname "$0")"
LYTHON_DIAGNOSTIC_FIXTURES=$(mktemp -d /dev/shm/lython-dispatch-local.XXXXXXXX)
export LYTHON_DIAGNOSTIC_FIXTURES
trap 'rmdir -- "$LYTHON_DIAGNOSTIC_FIXTURES"' EXIT
exec_with_watchdog() { timeout --kill-after=15s 220s python3 ./collect.py; }
exec_with_watchdog
