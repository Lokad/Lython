from pathlib import Path
import hashlib,json,os,shutil,statistics,subprocess
root=Path('.git/agent-notes/review-20261031')
lab=root/'one-abstract-expression-dispatch'
trial=Path('.git/agent-worktrees/one-abstract-expression-dispatch')
old=root/'site-owned-compiler-operands'
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
git=lambda *a:subprocess.check_output(['git',*a],encoding='utf-8').strip()
reference=git('rev-parse','d948e0682')
candidate=git('-C',str(trial),'rev-parse','HEAD')
assert candidate.startswith('4060f7972') and not git('-C',str(trial),'status','--porcelain')
assert not git('diff','--name-only',reference,'HEAD','--','src','tests','Directory.Build.props','Directory.Packages.props')
assert git('rev-parse',candidate+'^')==reference
immutable=load(old/'frozen-identity.json')['images']['candidate']
assert len(immutable)==32 and {n:sha(old/'frozen/candidate'/n)for n in immutable}==immutable
catalog=load(old/'catalog.json')
validator=load(root/'shared-executable-graph/catalog.json')['cases'][0]
assert validator['id']=='scripts.config-generated-guards.medium'
catalog['cases'].insert(0,validator)
catalog_path=lab/'catalog.json'
catalog_path.write_text(json.dumps(catalog,indent=2)+'\n',encoding='utf-8',newline='\n')
images={}
for role in ('reference','candidate'):
  target=lab/'frozen'/role
  target.mkdir(parents=True,exist_ok=False)
  source=Path.cwd() if role=='reference' else trial
  for n in immutable:
    origin=source/'src/Lokad.Lython/bin/Release/net11.0/Lokad.Lython.dll' if n=='Lokad.Lython.dll' else old/'frozen/candidate'/n
    shutil.copyfile(origin,target/n)
  for n in (old/'frozen/candidate').glob('CompileAllocation.*'):shutil.copyfile(n,target/n.name)
  images[role]={n:sha(target/n) for n in immutable}
assert [n for n in immutable if images['reference'][n]!=images['candidate'][n]]==['Lokad.Lython.dll']
(lab/'frozen-identity.json').write_text(json.dumps(dict(referenceCommit=reference,candidateCommit=candidate,
    referenceBuiltFrom=reference,images=images,casesSHA256=sha(catalog_path)),indent=2)+'\n',encoding='utf-8',newline='\n')
sdk=Path.home()/'.dotnet11'
dotnet=sdk/'dotnet.exe'
env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk),PATH=str(sdk)+os.pathsep+os.environ['PATH'])
values={}
for role,files in images.items():
  image=lab/'frozen'/role
  verified=lab/f'{role}-comparison-verify.json'
  with (lab/f'{role}-verify.log').open('wb') as stream:
    subprocess.run([dotnet,image/'Lokad.Lython.Benchmarks.dll','--compare','verify','--catalog',catalog_path,
        '--dotnet',dotnet,'--python','C:/Python313/python.exe','--python-worker',Path('benchmarks/cpython-worker.py').resolve(),
        '--out',verified],env=env,stdout=stream,stderr=subprocess.STDOUT,check=True,timeout=90)
  assert load(verified)['state']=='Completed' and load(verified)['catalogSha256']==sha(catalog_path)
  out=lab/f'{role}-compile-allocation.json'
  with out.open('wb') as stream:
    subprocess.run([dotnet,image/'CompileAllocation.dll',catalog_path],env=dict(env,DOTNET_TieredCompilation='0'),
      check=True,timeout=100,stdout=stream)
  diag=load(out)
  assert diag['coreSha256']==files['Lokad.Lython.dll'] and len(diag['rows'])==4
  assert {n:sha(image/n) for n in files}==files
  values[role]=diag['rows']
for x,y in zip(values['reference'],values['candidate'],strict=True):
  assert x['id']==y['id']
  a,b=statistics.median(x['bytes']),statistics.median(y['bytes'])
  print(x['id'], a,b,round((b/a-1)*100,3))
