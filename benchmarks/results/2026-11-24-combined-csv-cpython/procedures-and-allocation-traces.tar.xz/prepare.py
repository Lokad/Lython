from pathlib import Path
import gzip
import hashlib
import json
import os
import shutil
import subprocess
import tarfile

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
quiet = lab / 'comparison/quiet'
quiet.mkdir(parents=True, exist_ok=True)
image = lab / 'candidate'
image.mkdir(exist_ok=True)
source = lab.with_name('current-csv-cpython-20261124') / 'comparison/quiet'
previous = lab.with_name('short-dictionary-keys-20261124')
root = 'combined-csv-cpython-b1549-20261124'
reference = 'csv-unpack-bindings-b1544-20261124'
read = lambda p: json.loads(p.read_text(encoding='utf-8'))
sha = lambda b: hashlib.sha256(b).hexdigest()
digest = lambda p: sha(p.read_bytes())


def write(path, content):
    path.write_text(content, encoding='utf-8', newline='\n')


def save(path, data):
    write(path, json.dumps(data, indent=2, ensure_ascii=False) + '\n')


candidate = subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo).decode().strip()
assert candidate.startswith('583d0e80b')
current = read(previous / 'comparison/identity.json')
reference_image = previous / 'reference'
reference_files = current['imageFiles']['reference']
core = 'Lokad.Lython.dll'
assert len(reference_files) == 32 and all(digest(reference_image / name)==expected for name,expected in reference_files.items())
files = {}
for name, expected in reference_files.items():
    path = lab / 'frozen/bin/Lokad.Lython/release_net11.0' / core if name == core else reference_image / name
    shutil.copyfile(path, image / name)
    files[name] = digest(image / name)
assert [name for name in files if files[name] != reference_files[name]] == [core]

manifest = read(source / 'representative.json')
explicit, typed = [case['id'] for case in manifest['cases']]
quote = next(case for case in read(previous/'comparison/representative.json')['cases'] if case['id'].endswith('quoted-control'))
manifest['cases'].append(quote)
save(quiet / 'representative.json', manifest)
save(quiet / 'jobs.json', [[name,lane] for name,lane in (
    (explicit,'warm'), (quote['id'],'warm'), (explicit,'compile-run'),
    (typed,'warm'), (explicit,'compile'))])

identity = read(source / 'identity.json')
protocol = repo / 'benchmarks/cpython-worker.py'
assert digest(protocol) == identity['cpythonWorkerSHA256'] == current['cpythonWorkerSHA256']
identity.update(sourceRevision=candidate, candidate=candidate, imageFiles={'candidate':files},
    frozenImage=f'/home/lokad/lython-bench-checks/{root}/candidate',
    coreSHA256={role:files[core] for role in ('candidate','candidate-control')},
    catalogs={name:dict(sha256=digest(quiet / name)) for name in ('representative.json','jobs.json')})
save(quiet / 'identity.json', identity)
runtime = Path.home() / '.dotnet11'
dotnet = runtime / 'dotnet.exe'
env = dict(os.environ, DOTNET_ROOT=str(runtime), DOTNET_ROOT_X64=str(runtime))
verified = quiet / 'candidate-verify.json'
subprocess.run([dotnet, image / 'Lokad.Lython.Benchmarks.dll', '--compare', 'verify', '--catalog', quiet / 'representative.json',
    '--dotnet', dotnet, '--python', 'C:/Python313/python.exe', '--python-worker', protocol, '--out', verified],
    check=True, env=env, timeout=90)
result = read(verified)
assert result['state']=='Completed' and result['caseCount']==3 and result['launched']['library']['sha256']==files[core]
assert all(digest(image/name)==expected for name,expected in files.items())
worker = (source/'collect.py').read_text(encoding='utf-8').replace('b1543-', 'b1549-').replace('len(jobs) == 4','len(jobs) == 5')
worker = worker.replace('CPython checkpoint for the two retained CSV meter scripts',
    'CPython checkpoint for retained short-key CSV execution and named regex delivery')
worker = worker.replace('    time.sleep(3)\n', '    time.sleep(12)\n').replace('        time.sleep(12)\n','        time.sleep(8)\n')
compile(worker, 'collect.py', 'exec')
write(quiet/'collect.py',worker)
(quiet/'run.sh').write_bytes((source/'run.sh').read_bytes())
assert b'\r' not in (quiet/'run.sh').read_bytes()
summary=(source/'summarize.py').read_text(encoding='utf-8').replace('len(raw["jobs"])==4 and receipt["warmJobs"]==4',
    'len(raw["jobs"])==5 and receipt["warmJobs"]==5')
write(quiet/'summarize.py',summary)

archived = 'benchmarks/results/2026-11-24-short-dictionary-keys/'
tracked = lambda name: subprocess.check_output(['git','show','origin/master:'+archived+name],cwd=repo)
binary = sha(gzip.decompress(tracked('candidate-core.dll.gz')))
assert binary==current['imageFiles']['candidate'][core]
replicas=[]
for label, path in (('initial','short-dictionary-keys-b1547-20261124'),('confirmation','short-dictionary-keys-b1548-20261124')):
    receipt = json.loads(tracked(label+'-terminal.json'))['receipt']
    assert receipt['archivedAndVerifiedUnderLease'] and receipt['guestFixturesRemoved']
    assert sha(tracked(label+'-observations.tar.xz'))==receipt['archiveSHA256']
    replicas.append(dict(path=path+'/candidate/'+core,archive=path+'/observations.tar.xz', archiveSHA256=receipt['archiveSHA256']))
save(quiet / 'prior-replica.json', dict(coreSHA256=binary, replicas=replicas, tracked=archived))

payload=quiet/'payload.tar.gz'
with tarfile.open(payload,'w:gz') as package:
    for name in ('identity.json','representative.json','jobs.json','collect.py','run.sh'):
        package.add(quiet/name,arcname=name)
    package.add(image/core,arcname='candidate-core.dll')
receipt = read(lab.with_name('csv-unpack-bindings-20261124')/'comparison/quiet/terminal-status.json')['receipt']
assert receipt['complete']
save(quiet/'upload.json',dict(root=root,reference=reference,payloadSHA256=digest(payload),payloadBytes=payload.stat().st_size,
    sourceArchiveSHA256=receipt['archiveSHA256']))

launch = (lab.with_name('current-csv-cpython-20261124')/'quiet.py').read_text(encoding='utf-8')
launch = launch.replace('b1543-current-csv-cpython', 'b1549-combined-csv-cpython').replace('b1543-', 'b1549-')
launch = launch.replace('RuntimeMaxSec=260','RuntimeMaxSec=355').replace('seconds=207','seconds=265')
stage = (lab / 'stage.py.txt').read_text(encoding='utf-8')
start = launch.index('with (base/')
finish = launch.index("subprocess.run(['sudo','-n','systemd-run'",start)
launch = launch[:start] + stage + launch[finish:]
compile(launch,'quiet.py','exec')
write(lab/'quiet.py',launch)
