using System.Text.Json;
using Microsoft.Diagnostics.Tracing;
using Microsoft.Diagnostics.Tracing.Etlx;

using var log = new TraceLog(TraceLog.CreateFromEventPipeDataFile(Path.GetFullPath(args[0])));
using var source = log.Events.GetSource();
var total = new Dictionary<(string Type, string Stack), (int Count, long Weight)>();
source.Clr.GCAllocationTick += tick =>
{
    var type = tick.TypeName ?? "<unknown>";
    var frames = new List<string>();
    for (var stack = tick.CallStack(); stack is not null && frames.Count < 6; stack = stack.Caller)
    {
        var address = stack.CodeAddress;
        if (address.ModuleName?.Contains("Lython", StringComparison.OrdinalIgnoreCase) == true)
            frames.Add($"{address.FullMethodName} IL{address.ILOffset:x} M{address.Method?.MethodToken:x}");
    }
    var key = (type, string.Join(" <- ", frames));
    total.TryGetValue(key, out var prior);
    total[key] = (prior.Count + 1, prior.Weight + tick.AllocationAmount64);
};
source.Process();
var rows = total.OrderByDescending(pair => pair.Value.Weight)
    .Select(pair => new { pair.Key.Type, pair.Key.Stack, pair.Value.Count, pair.Value.Weight })
    .ToArray();
File.WriteAllText(args[1], JsonSerializer.Serialize(rows, new JsonSerializerOptions { WriteIndented = true }) + "\n");
Console.WriteLine($"{rows.Sum(row => row.Count)} ticks, {rows.Where(row => row.Stack.Length != 0).Sum(row => row.Count)} with Lython frames");
foreach (var row in rows.Where(row => row.Type == "System.Numerics.BigInteger").Take(8))
    Console.WriteLine($"{row.Count} {row.Weight} {row.Stack}");


