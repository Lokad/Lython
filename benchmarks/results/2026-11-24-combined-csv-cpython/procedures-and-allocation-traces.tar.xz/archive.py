from pathlib import Path
import hashlib
import json
import re
import shutil
import tarfile

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
archive = repo / 'benchmarks/results/2026-11-24-combined-csv-cpython'
archive.mkdir(exist_ok=True)
quiet = lab / 'comparison/quiet'
read = lambda path: json.loads(path.read_text(encoding='utf-8-sig'))
digest = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
identity = read(quiet / 'identity.json')
terminal = read(quiet / 'terminal-status.json')
receipt = terminal['receipt']
assert terminal['exitCode'] == '0' and not terminal['fixtures'] and not terminal['live']
assert all(receipt[key] for key in ('complete','allWorkersJoined','guestFixturesRemoved',
    'quietBeforeAndAfter','archivedAndVerifiedUnderLease'))
assert receipt['warmJobs'] == 5 and digest(quiet / 'observations.tar.xz') == receipt['archiveSHA256']
summary = read(quiet / 'summary.json')
assert summary['source'] == identity['sourceRevision'] and summary['timedBatches'] == 140
assert summary['cpythonExecutableSHA256'] == identity['expectedCPythonSHA256']
assert read(quiet / 'candidate-verify.json')['launched']['library']['sha256'] == identity['coreSHA256']['candidate']
for name in ('identity.json','terminal-status.json','observations.tar.xz','summary.json'):
    shutil.copyfile(quiet / name, archive / name)

profile = read(lab / 'run-summary.json')
assert profile['allProcessesJoined'] and profile['sourceRevision'] == summary['source']
roles = ('explicit-float','typed-unicode','json-expanded')
allocation_summary = dict(revision=profile['sourceRevision'], type='EventPipe allocation tick weights', rows=[])
bundle_files = {name: lab / name for name in ('prepare.py','quiet.py','archive.py','stage.py.txt',
    'profile-allocation.py','run-summary.json','catalog.json','verification.json')}
bundle_files.update({name: quiet / name for name in ('upload.json','prior-replica.json','launch.log',
    'candidate-verify.json','summarize.py')})
stacks_inspector = lab.with_name('retained-meter-allocation-20261123') / 'inspect-stack'
for name in ('Program.cs','InspectStacks.csproj','packages.lock.json'):
    bundle_files['inspector/' + name] = stacks_inspector / name
for role in roles:
    observed = lab / role
    record = read(observed / 'record.json')
    assert record['allProcessesJoined'] and record['nettraceSha'] == digest(observed / 'warm.nettrace')
    assert record['coreSha'] == identity['coreSHA256']['candidate']
    assert record['before']['status'] == record['after']['status'] == 'Equivalent'
    assert record['closed']['status'] == 'Closed'
    weights = read(observed / 'sampled-allocation.json')
    total_weight = weights['TotalSampleWeight']
    stacks = read(observed / 'allocation-stacks.json')
    assert sum(x['Weight'] for x in stacks) == total_weight
    sites = {}
    for item in stacks:
        method = re.split(r'\(| <- ', item['Stack'])[0] or '<unresolved>'
        by_type = sites.setdefault(item['Type'], {})
        by_type[method] = by_type.get(method, 0) + item['Weight']
    allocation_summary['rows'].append(dict(case=record['workload'], ticks=weights['Samples'],
        weight=total_weight, allocations=weights['Rows'], nearestRuntimeByType=sites))
    for name in ('warm.nettrace','capture.log','record.json','sampled-allocation.json','allocation-stacks.json','stacks.log'):
        bundle_files[role + '/' + name] = observed / name
(archive / 'allocation-summary.json').write_text(json.dumps(allocation_summary, indent=2) + '\n', encoding='utf-8', newline='\n')
with tarfile.open(archive / 'procedures-and-allocation-traces.tar.xz', 'w:xz') as bundle:
    for name, path in bundle_files.items():
        bundle.add(path, arcname=name)
with tarfile.open(archive / 'procedures-and-allocation-traces.tar.xz') as bundle:
    assert set(bundle.getnames()) == set(bundle_files)
    assert all(hashlib.sha256(bundle.extractfile(name).read()).hexdigest() == digest(path) for name, path in bundle_files.items())
