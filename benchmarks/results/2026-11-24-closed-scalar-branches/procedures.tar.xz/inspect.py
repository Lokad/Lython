
from pathlib import Path
import hashlib
import json
import os
import shutil
import subprocess

lab=Path(__file__).resolve().parent
comparison=lab/'comparison'
identity=json.loads((comparison/'identity.json').read_text(encoding='utf-8'))
inspection=lab.with_name('current-rule-closures-cpython-20261124')/'local-inspection'
digest=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
helpers={}
dotnet=Path.home()/'.dotnet11/dotnet.exe'
env=dict(os.environ,DOTNET_ROOT=str(dotnet.parent),DOTNET_ROOT_X64=str(dotnet.parent))
tapes={}
for role,files in identity['imageFiles'].items():
    image=lab/role
    assert all(digest(image/name)==sha for name,sha in files.items())
    for suffix in ('.dll','.deps.json','.runtimeconfig.json'):
        name='Inspect'+suffix
        shutil.copyfile(inspection/name,image/name)
        helpers[name]=digest(image/name)
    result=lab/(role+'-tapes.json')
    subprocess.run([dotnet,image/'Inspect.dll',comparison/'representative.json',result],
        env=env,check=True,timeout=35)
    tapes[role]=json.loads(result.read_text(encoding='utf-8'))
    assert tapes[role]['coreSHA256']==files['Lokad.Lython.dll']
    assert all(digest(image/name)==sha for name,sha in files.items())
    assert all(digest(image/name)==sha for name,sha in helpers.items())

def read(role,case,name):
    target,=[code for row in tapes[role]['rows'] if row['id']==case
        for code in row['codes'] if code['name']==name]
    return target
rows=[]
for case in ('scripts.captured-rule-closures','scripts.rule-default-closures'):
    old,new=(read(role,case,'apply') for role in ('reference','candidate'))
    assert old['opcodeCounts']['Jump'] - new['opcodeCounts']['Jump'] == 2
    assert not old['directIntegerReturn'] and new['directIntegerReturn']
    assert new['opcodeCounts']['Return'] == 2
    assert old['instructions'] - new['instructions'] == (6 if case=='scripts.captured-rule-closures' else 2)
    rows.append(dict(case=case,function='apply',old=old['opcodeCounts'],new=new['opcodeCounts'],activationsDisplacedPerInvocation=2048))
case='scripts.captured-rule-closures'
old,new=(read(role,case,'<lambda>') for role in ('reference','candidate'))
assert not old['directIntegerReturn'] and new['directIntegerReturn']
assert old['instructions'] - new['instructions']==2
rows.append(dict(case=case,function='<lambda>',old=old['opcodeCounts'],new=new['opcodeCounts'],activationsDisplacedPerInvocation=2048))
(lab/'tape-summary.json').write_text(json.dumps(dict(inspector=helpers,rows=rows),indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps(rows))
