from io import BytesIO
from pathlib import Path
import gzip
import hashlib
import json
import shutil
import subprocess
import tarfile

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
tree = repo / '.git/agent-worktrees/closure-scalar-operands-20261124'
comparison = lab / 'comparison'
quiet = comparison / 'quiet'
record = repo / 'benchmarks/results/2026-11-24-closed-scalar-branches'
record.mkdir(exist_ok=True)
read = lambda path: json.loads(path.read_text(encoding='utf-8'))
sha = lambda data: hashlib.sha256(data).hexdigest()
digest = lambda path: sha(path.read_bytes())
identity = read(comparison/'identity.json')
receipt = read(quiet/'terminal-status.json')
terminal = receipt['receipt']
assert not receipt['live'] and not receipt['fixtures'] and receipt['exitCode']=='0'
assert all(terminal[k] for k in ('complete','allWorkersJoined','guestFixturesRemoved',
    'quietBeforeAndAfter','archivedAndVerifiedUnderLease'))
assert terminal['warmJobs']==8 and digest(quiet/'observations.tar.xz')==terminal['archiveSHA256']
summary=read(quiet/'summary.json')
assert summary['source']==identity['sourceRevision'] and summary['candidate']==identity['candidate']
assert summary['timedBatches']==224
cases=[row['id'] for row in read(comparison/'representative.json')['cases']]
assert len(cases)==5
assert [[row['case'],row['lane']] for row in summary['rows']]==read(comparison/'jobs.json')['warm']
for role, files in identity['imageFiles'].items():
    image=lab/role
    assert len(files)==32 and all(digest(image/name)==checksum for name,checksum in files.items())
    assert all(digest(image/name)==checksum for name,checksum in identity['helperFiles'].items())
    smoke=read(comparison/(role+'-verify.json'))
    assert smoke['state']=='Completed' and smoke['caseCount']==len(cases)
    assert smoke['launched']['library']['sha256']==files['Lokad.Lython.dll']
    core=image/'Lokad.Lython.dll'
    published=record/'candidate-core.dll.gz' if role=='candidate' else (
        repo/'benchmarks/results/2026-11-24-regex-module-index/candidate-core.dll.gz')
    if role=='candidate': published.write_bytes(gzip.compress(core.read_bytes(),mtime=0))
    assert sha(gzip.decompress(published.read_bytes()))==files[core.name]
    local=read(lab/(role+'-allocation-six.json'))['rows']
    assert len(local)==len(cases) and all(row['sharedBudgetBaselineRestored'] for row in local)
allocation=read(lab/'allocation-summary-six.json')
assert len(allocation)==len(cases)
assert allocation[0]['case']=='scripts.captured-rule-closures'
assert allocation[0]['allocatedBytes'][0]-allocation[0]['allocatedBytes'][1]==152896
assert all(abs(row['allocatedBytes'][0]-row['allocatedBytes'][1])<=50 for row in allocation[1:])
assert all(len(set(row['peakAdmission']))==1 for row in allocation)
shutil.copyfile(lab/'allocation-summary-six.json',record/'allocation-summary.json')
shutil.copyfile(comparison/'identity.json',record/'identity.json')
shutil.copyfile(lab/'tape-summary.json',record/'tape-summary.json')
for name in ('summary.json','terminal-status.json','observations.tar.xz'):
    shutil.copyfile(quiet/name,record/name)
inputs=('prepare.py','quiet.py','summarize.py','allocations.py','archive.py','verified-replicas.json',
    'reference-allocation-six.json','candidate-allocation-six.json','comparison/quiet/launch.log',
    'comparison/reference-verify.json','comparison/candidate-verify.json','stage.py','comparison/representative.json','comparison/jobs.json',
    'inspect.py','reference-tapes.json','candidate-tapes.json','tape-summary.json',
    'comparison/quiet/collect.py','comparison/quiet/run.sh','comparison/quiet/upload.json',
    'incremental-inspection/comparison/identity.json','incremental-inspection/comparison/reference-verify.json',
    'incremental-inspection/comparison/candidate-verify.json','incremental-inspection/inspect.py',
    'incremental-inspection/prepare.py','incremental-inspection/reference-tapes.json',
    'incremental-inspection/candidate-tapes.json','incremental-inspection/tape-summary.json')
patch=subprocess.check_output(['git','diff','--binary',identity['sourceRevision'],identity['candidate'],'--','src','tests'],cwd=tree)
with tarfile.open(record/'procedures.tar.xz','w:xz') as archive:
    for name in inputs:
        archive.add(lab/name,arcname=name)
    entry=tarfile.TarInfo('changes.patch')
    entry.size=len(patch)
    archive.addfile(entry,BytesIO(patch))
with tarfile.open(record/'procedures.tar.xz') as archive:
    assert set(archive.getnames())==set(inputs)|{'changes.patch'}
    assert archive.extractfile('changes.patch').read()==patch
    assert all(sha(archive.extractfile(name).read())==digest(lab/name) for name in inputs)

