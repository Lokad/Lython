import ast
import hashlib
import json
from pathlib import Path
import shutil
import tarfile

lab = Path(__file__).resolve().parent
profile = lab.parent / 'retained-dispatch-profile'
template = lab.parent / 'direct-class-header'
quiet = lab / 'quiet'
quiet.mkdir(exist_ok=True)
read = lambda path: path.read_text(encoding='utf-8-sig')
load = lambda path: json.loads(read(path))
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
def write(path, text):
    if path.suffix == '.py': ast.parse(text)
    path.write_text(text, encoding='utf-8', newline='\n')
def save(path, value): write(path,json.dumps(value,ensure_ascii=False,indent=2)+'\n')

pair = load(lab/'frozen-identity.json')
old = load(profile/'config.json')
old_receipt = load(profile/'archive-receipt.json')
assert old_receipt['complete'] and old_receipt['archivedAndVerifiedUnderLease']
assert old_receipt['archiveSHA256'] == sha(profile/'observations.tgz')
images = pair['images']
core = 'Lokad.Lython.dll'
donor_aux = {n:h for n,h in old['identity']['imageFiles']['candidate'].items() if n != core}
assert all({n:h for n,h in files.items() if n!=core}==donor_aux for files in images.values())
catalog = lab/'catalog.json'
assert sha(catalog) == pair['casesSHA256']
for role,files in images.items():
    assert len(files) == 32 and {name:sha(lab/'frozen'/role/name) for name in files} == files
    verified = load(lab/(role+'-verify.json'))
    assert verified['state'] == 'Completed' and verified['catalogSha256'] == sha(catalog)
for role in images:
    path=quiet/role
    path.mkdir(exist_ok=True)
    shutil.copyfile(lab/'frozen'/role/core,path/core)
shutil.copyfile(catalog, quiet/'representative.json')
worker = Path('benchmarks/cpython-worker.py')
assert sha(worker)==load(lab.parent/'factory-cpython-b1151/config.json')['cpythonWorkerSHA256']
shutil.copyfile(worker, quiet/'cpython-worker.py')
root='/home/lokad/lython-bench-checks/native-keyword-snapshot-b1161-20261120'
unit='lython-b1161-native-keyword-snapshot-20261120'
purpose='Native keyword snapshots source pair'
identity=dict(sourceRevision=pair['referenceCommit']+' versus '+pair['candidateCommit'], purpose=purpose,
              imageFiles=images, catalogSHA256=sha(catalog), normalAdapterPin='0.4.0',
              coreSHA256={label:images[role][core] for role in images for label in (role,role+'-control')})
save(quiet/'identity.json',identity)
jobs=[('scripts.report-forwarding.expanded','warm'),('scripts.json-keyword-transform.large','warm'),
      ('scripts.csv-keyword-invoice.large','warm'),('scripts.csv-invoice.large','warm'),
      ('scripts.json-record-copy.large','warm'),('scripts.report-forwarding.expanded','compile-run')]
for name in ('collect.py','archive-owned.py','run.sh','retrieve.py'):
    source=read(template/'quiet'/name).replace(load(template/'quiet/config.json')['root'],root)
    if name=='collect.py':
        start=source.index('\njobs = ')
        end=source.index('\nassert len(jobs)',start)
        source=source[:start]+'\njobs = '+repr(jobs)+source[end:]
    source=source.replace('Direct class header handoff source pair',purpose)
    source=source.replace(str(174*1024*1024),str(172*1024*1024))
    write(quiet/name,source)
write(lab/'launch-quiet.py',read(template/'launch-quiet.py').replace('Prepared binding diagnostics source pair',purpose))
shutil.copyfile(template/'summarize-quiet.py',lab/'summarize-quiet.py')
names=['identity.json','representative.json','cpython-worker.py','collect.py','archive-owned.py','run.sh','candidate/'+core,'reference/'+core]
payload=quiet/'payload.tgz'
with tarfile.open(payload,'w:gz') as archive:
    for name in names: archive.add(quiet/name,arcname=name)
expanded=sum((quiet/name).stat().st_size for name in names)
floor=172*1024*1024
expected=floor+expanded+1310720
space=load(lab/'quiet-space.json')
available=space['freeBytes']
selected=[]
for proof in space['replicas']:
    if available > expected + 131072: break
    assert proof['committedBlobVerified'] and proof['sha256'] != images['reference'][core]
    selected.append(proof)
    available += proof['bytes']
assert available > expected,(available,expected)
config=dict(root=root,unit=unit,source=old['root'],sourceRole='candidate',sourceFiles=donor_aux,
            sourceCatalogSHA256=old['catalogSHA256'],protocolSHA256=sha(worker),catalogSHA256=sha(catalog),
            identity=identity,retireGroups=selected,donorArchiveSHA256=old_receipt['archiveSHA256'],
            payloadBytes=payload.stat().st_size,payloadSHA256=sha(payload),unpackedBytes=expanded)
save(quiet/'config.json',config)
launcher=read(template/'quiet/remote-launch.py')
start,end=launcher.index('\nc=')+1,launcher.index('\nb=Path(')
launcher=launcher[:start]+'c='+repr(config)+launcher[end:]
launcher=launcher.replace("source/'representative.json')==c['sourceCatalogSHA256']","source/'catalog.json')==c['sourceCatalogSHA256']")
launcher=launcher.replace(" assert sha(source/'cpython-worker.py')==c['protocolSHA256']\n",'')
launcher=launcher.replace(" os.link(source/'cpython-worker.py',root/'cpython-worker.py')", " assert sha(root/'cpython-worker.py')==c['protocolSHA256']")
launcher=launcher.replace('lython-b1158-fixtures','lython-b1161-fixtures')
launcher=launcher.replace(str(174*1024*1024),str(172*1024*1024))
write(quiet/'remote-launch.py',launcher)
print('Verified both images and six phase/workload pairs. Remaining staging headroom',available-expected,'bytes.')
