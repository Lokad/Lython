from pathlib import Path
import ast
import re

lab = Path(__file__).resolve().parent
template = lab.parent / 'format-operands'
read = lambda path: path.read_text(encoding='utf-8-sig')

def write(name, source):
    ast.parse(source)
    (lab / name).write_text(source, encoding='utf-8', newline='\n')

freeze = read(template / 'freeze-and-verify.py')
freeze = freeze.replace('format-operand-transport', 'native-keyword-snapshot')
freeze = freeze.replace("reference = read(profile/'identity.json')['sourceRevision']", "reference = subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()")
freeze = freeze.replace('f1593aaf5', 'b84ce1fe5').replace('95654712a', 'c1d6e3c01')
start, end = freeze.index("catalog = read(profile/'catalog.json')"), freeze.index("manifest = lab/'catalog.json'")
freeze = freeze[:start] + '''catalog=read(lab.parent/'shared-record-keywords-r693/catalog.json')
cases={case['id']:case for case in catalog['cases']}
copy_case=cases['scripts.json-record-transform.large'].copy()
copy_case['id']='scripts.json-record-copy.large'
source=copy_case['source']
start=source.index('def transform')
end=source.index('import json')
assert start==0 and 'record = transform(record)' in source
source=source[end:].replace('record = transform(record)', 'record = record.copy()')
copy_case.update(source=source, sourceUtf8Bytes=len(source.encode('utf8')), sourceSha256=hashlib.sha256(source.encode('utf8')).hexdigest())
ids=('scripts.report-forwarding.expanded','scripts.json-keyword-transform.large','scripts.csv-keyword-invoice.large','scripts.csv-invoice.large')
catalog['cases']=[cases[key] for key in ids]+[copy_case]
''' + freeze[end:]
freeze = freeze.replace("origin = trial/'src/Lokad.Lython/bin/Release/net11.0'/core if name == core and role == 'candidate' else profile/'candidate'/name",
                        "origin = (trial if role == 'candidate' else repo)/'src/Lokad.Lython/bin/Release/net11.0'/core if name==core else profile/'candidate'/name")
freeze = freeze.replace("if name == core and role == 'candidate':", "if name == core:")
freeze = freeze.replace('match all four CPython goldens','match all five CPython goldens')
write('freeze-and-verify.py', freeze)

stage = read(template / 'stage-quiet.py')
stage = stage.replace("assert images['reference'] == old['identity']['imageFiles']['candidate']", "donor_aux = {n:h for n,h in old['identity']['imageFiles']['candidate'].items() if n != core}\nassert all({n:h for n,h in files.items() if n!=core}==donor_aux for files in images.values())")
stage = stage.replace("candidate = quiet/'candidate'\ncandidate.mkdir(exist_ok=True)\nshutil.copyfile(lab/'frozen/candidate'/core, candidate/core)",
                      "for role in images:\n    path=quiet/role\n    path.mkdir(exist_ok=True)\n    shutil.copyfile(lab/'frozen'/role/core,path/core)")
stage = stage.replace('format-operands-b1160-', 'native-keyword-snapshot-b1161-').replace('b1160-format-operands-', 'b1161-native-keyword-snapshot-')
stage = stage.replace('Direct method-format operands source pair', 'Native keyword snapshots source pair').replace('lython-b1160-fixtures','lython-b1161-fixtures')
start, end = stage.index('jobs=['), stage.index('for name in (\'collect.py\'', stage.index('jobs=['))
stage = stage[:start] + '''jobs=[('scripts.report-forwarding.expanded','warm'),('scripts.json-keyword-transform.large','warm'),
      ('scripts.csv-keyword-invoice.large','warm'),('scripts.csv-invoice.large','warm'),
      ('scripts.json-record-copy.large','warm'),('scripts.report-forwarding.expanded','compile-run')]
''' + stage[end:]
stage = stage.replace("'run.sh','candidate/'+core]", "'run.sh','candidate/'+core,'reference/'+core]")
stage = stage.replace("sourceFiles=images['reference']", "sourceFiles=donor_aux")
stage = stage.replace('floor=174*1024*1024', 'floor=172*1024*1024')
stage = stage.replace('    write(quiet/name,source)', "    source=source.replace(str(174*1024*1024),str(172*1024*1024))\n    write(quiet/name,source)")
stage = stage.replace("write(quiet/'remote-launch.py',launcher)", "launcher=launcher.replace(str(174*1024*1024),str(172*1024*1024))\nwrite(quiet/'remote-launch.py',launcher)")
write('stage-quiet.py', stage)

proof = read(lab.parent / 'direct-class-header' / 'prove-quiet-space.py')
pairs = [('format-operands/quiet','2026-11-20-method-format-operands','candidate','measured-core.dll.gz'),
         ('format-operands/quiet','2026-11-20-method-format-operands','reference','@profile'),
         ('shared-bound-entry/quiet','2026-11-20-shared-bound-entry','candidate','measured-core.dll.gz'),
         ('selected-abstract-path-r713/quiet','2026-11-19-selected-abstract-paths','reference','reference-core.dll.gz'),
         ('csv-search-sets-r711/quiet','2026-11-19-prepared-csv-search-sets','reference','reference-core.dll.gz')]
proof = re.sub(r'^pairs = .*$', 'pairs = '+repr(pairs), proof, flags=re.M)
proof = proof.replace("commit=subprocess.check_output(['git','log','-1','--format=%H','--',local+'/'+image]).decode().strip()", "commit=subprocess.check_output(['git','log','-1','--format=%H','--',local+'/observations.tgz']).decode().strip()")
proof = proof.replace('core=gzip.decompress(recorded(image))', '''canonical_path=local+'/'+image
    canonical_commit=commit
    if image=='@profile':
        canonical_path='benchmarks/results/2026-11-20-retained-dispatch-profile/measured-core.dll.gz'
        canonical_commit=subprocess.check_output(['git','log','-1','--format=%H','--',canonical_path]).decode().strip()
    core=gzip.decompress(subprocess.check_output(['git','show',f'{canonical_commit}:{canonical_path}']))''')
proof = proof.replace("canonicalCommit=commit,canonicalPath=local+'/'+image", 'canonicalCommit=canonical_commit,canonicalPath=canonical_path')
write('prove-quiet-space.py', proof)
