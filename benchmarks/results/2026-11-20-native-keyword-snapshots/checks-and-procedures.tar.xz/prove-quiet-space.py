from pathlib import Path
import gzip
import hashlib
import json
import subprocess

lab=Path(__file__).resolve().parent
read=lambda p: json.loads(p.read_text(encoding='utf-8-sig'))
pairs = [('format-operands/quiet', '2026-11-20-method-format-operands', 'candidate', 'measured-core.dll.gz'), ('format-operands/quiet', '2026-11-20-method-format-operands', 'reference', '@profile'), ('shared-bound-entry/quiet', '2026-11-20-shared-bound-entry', 'candidate', 'measured-core.dll.gz'), ('selected-abstract-path-r713/quiet', '2026-11-19-selected-abstract-paths', 'reference', 'reference-core.dll.gz'), ('csv-search-sets-r711/quiet', '2026-11-19-prepared-csv-search-sets', 'reference', 'reference-core.dll.gz')]
records=[]
base='/home/lokad/lython-bench-checks'
for folder, evidence, role, image in pairs:
    local=f'benchmarks/results/{evidence}'
    where=read(lab.parent/folder/'config.json')['root']
    assert where.startswith(base+'/')
    commit=subprocess.check_output(['git','log','-1','--format=%H','--',local+'/observations.tgz']).decode().strip()
    def recorded(name):
        return subprocess.check_output(['git','show',f'{commit}:{local}/{name}'])
    canonical_path=local+'/'+image
    canonical_commit=commit
    if image=='@profile':
        canonical_path='benchmarks/results/2026-11-20-retained-dispatch-profile/measured-core.dll.gz'
        canonical_commit=subprocess.check_output(['git','log','-1','--format=%H','--',canonical_path]).decode().strip()
    core=gzip.decompress(subprocess.check_output(['git','show',f'{canonical_commit}:{canonical_path}']))
    digest=hashlib.sha256(core).hexdigest()
    summary=json.loads(recorded('summary.json'))
    assert digest==(summary.get('coreSHA256') or summary['cores'][role])
    receipt = json.loads(recorded('archive-recovery.json' if folder == 'borrow-lexical-builder-r625' else 'archive-receipt.json'))
    assert receipt['complete'] and receipt['allWorkersJoined'] and receipt['guestFixturesRemoved']
    assert receipt.get('archivedAndVerifiedUnderLease') or receipt.get('verifiedAfterCollectionUnderIdleLease')
    assert hashlib.sha256(recorded('observations.tgz')).hexdigest() == receipt['archiveSHA256']
    records.append(dict(bytes=len(core),links=1,paths=[where.removeprefix(base+'/')+'/'+role+'/Lokad.Lython.dll'],
        sha256=digest,committedBlobVerified=True,canonicalCommit=canonical_commit,canonicalPath=canonical_path))
remote = '''
from pathlib import Path
import fcntl,hashlib,json,os,shutil,stat
root=Path('/home/lokad/lython-bench-checks')
records=CONTENTS
present=[]
with (root/'comparison-vm.lock').open('a') as lease:
    fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
    for record in records:
        path=root/record['paths'][0]
        if not path.exists(): continue
        info=path.lstat()
        if not stat.S_ISREG(info.st_mode) or info.st_uid!=os.getuid(): continue
        assert info.st_size==record['bytes']
        assert hashlib.sha256(path.read_bytes()).hexdigest()==record['sha256']
        aliases=[]
        for directory,_,files in os.walk(root):
            for name in files:
                candidate=Path(directory)/name
                candidate_info=candidate.lstat()
                if (candidate_info.st_dev,candidate_info.st_ino)!=(info.st_dev,info.st_ino): continue
                assert candidate.resolve()==candidate and candidate.is_relative_to(root)
                aliases.append(str(candidate.relative_to(root)))
        if len(aliases)!=info.st_nlink: continue
        assert record['paths'][0] in aliases
        present.append(dict(record,links=len(aliases),paths=sorted(aliases)))
    print(json.dumps(dict(freeBytes=shutil.disk_usage(root).free,replicas=present),indent=2))
'''.replace('CONTENTS',repr(records))
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i',str(Path.home()/'.ssh/id_lython-bench.pem'),'-o','BatchMode=yes',
     '-o','ConnectTimeout=15','lokad@20.166.121.73','python3 -']
result=subprocess.run(ssh,input=remote.encode('utf-8'),capture_output=True,timeout=30,check=True)
data=json.loads(result.stdout)
(lab/'quiet-space.json').write_text(json.dumps(data,indent=2)+'\n',encoding='utf-8',newline='\n')
print(data['freeBytes'], [item['paths'][0] for item in data['replicas']])
