set -euo pipefail
cd /mnt/d/code/Lython/.git/agent-worktrees/native-keyword-snapshot
export DOTNET_ROOT="$HOME/.dotnet"
export PATH="$DOTNET_ROOT:$PATH"
lab=../../agent-notes/review-20261031/native-keyword-snapshot
dotnet build tools/LythonProbe/LythonProbe.csproj -c Release -f net10.0 --no-incremental 2>&1 | tee "$lab/ubuntu-probe.log"
dotnet test tests/Lokad.Lython.PublicApi.Tests -c Release -f net10.0 --filter '(FullyQualifiedName~Call|FullyQualifiedName~Kwargs|FullyQualifiedName~Dictionary|FullyQualifiedName~RecordKey|FullyQualifiedName~FormatMapping)&Category!=Stress' 2>&1 | tee "$lab/ubuntu-public-confirm.log"
