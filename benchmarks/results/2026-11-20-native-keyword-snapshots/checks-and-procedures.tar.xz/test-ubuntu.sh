set -euo pipefail
cd /mnt/d/code/Lython/.git/agent-worktrees/native-keyword-snapshot
export DOTNET_ROOT="$HOME/.dotnet"
export PATH="$DOTNET_ROOT:$PATH"
lab=../../agent-notes/review-20261031/native-keyword-snapshot
dotnet test tests/Lokad.Lython.Tests -c Release -f net10.0 --artifacts-path "$PWD/artifacts/linux" --filter '(FullyQualifiedName~ExpandedCallExecutable|FullyQualifiedName~RecordKeyOwnership|FullyQualifiedName~Dictionary|FullyQualifiedName~WrapperConstruction)&Category!=Stress' 2>&1 | tee "$lab/ubuntu-whitebox.log"
dotnet test tests/Lokad.Lython.PublicApi.Tests -c Release -f net10.0 --artifacts-path "$PWD/artifacts/linux" --filter '(FullyQualifiedName~Call|FullyQualifiedName~Kwargs|FullyQualifiedName~Dictionary|FullyQualifiedName~RecordKey|FullyQualifiedName~FormatMapping)&Category!=Stress' 2>&1 | tee "$lab/ubuntu-public.log"
