set -euo pipefail
cd /mnt/d/code/Lython
export DOTNET_ROOT="$HOME/.dotnet"
export PATH="$DOTNET_ROOT:$PATH"
lab=.git/agent-notes/review-20261031/native-keyword-snapshot
dotnet test tests/Lokad.Lython.Tests -c Release -f net10.0 --artifacts-path "$PWD/.git/agent-notes/artifacts/native-keyword-correction" --filter '(FullyQualifiedName~ExpandedCallExecutable|FullyQualifiedName~RecordKeyOwnership|FullyQualifiedName~Dictionary|FullyQualifiedName~WrapperConstruction)&Category!=Stress' 2>&1 | tee "$lab/correction-ubuntu-whitebox.log"
