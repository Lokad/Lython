import hashlib
import json
import os
from pathlib import Path
import shutil
import statistics
import subprocess

lab = Path(__file__).resolve().parent
repo = Path.cwd()
profile = lab.parent / 'retained-dispatch-profile'
trial = repo / '.git/agent-worktrees/native-keyword-snapshot'
read = lambda path: json.loads(path.read_text(encoding='utf-8-sig'))
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
def write(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8', newline='\n')

reference = subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
candidate = subprocess.check_output(['git','-C',trial,'rev-parse','HEAD'], text=True).strip()
assert reference.startswith('b84ce1fe5') and candidate.startswith('c1d6e3c01')
assert not subprocess.check_output(['git','-C',trial,'status','--porcelain'])
subprocess.run(['git','merge-base','--is-ancestor',reference,candidate], check=True)
subprocess.run(['git','diff','--exit-code',reference,candidate,'--','global.json','Directory.Build.props',
                'Directory.Packages.props','benchmarks/cpython-worker.py','benchmarks/Lokad.Lython.Benchmarks',
                'src/Lokad.Lython.Utf8Regex'], check=True)
(lab/'measured-source.patch').write_bytes(subprocess.check_output(['git','diff','--binary',reference,candidate,'--','src','tests']))
catalog=read(lab.parent/'shared-record-keywords-r693/catalog.json')
cases={case['id']:case for case in catalog['cases']}
copy_case=cases['scripts.json-record-transform.large'].copy()
copy_case['id']='scripts.json-record-copy.large'
source=copy_case['source']
start=source.index('def transform')
end=source.index('import json')
assert start==0 and 'record = transform(record)' in source
source=source[end:].replace('record = transform(record)', 'record = record.copy()')
copy_case.update(source=source, sourceUtf8Bytes=len(source.encode('utf8')), sourceSha256=hashlib.sha256(source.encode('utf8')).hexdigest())
ids=('scripts.report-forwarding.expanded','scripts.json-keyword-transform.large','scripts.csv-keyword-invoice.large','scripts.csv-invoice.large')
catalog['cases']=[cases[key] for key in ids]+[copy_case]
manifest = lab/'catalog.json'
write(manifest, catalog)

sdk = Path.home()/'.dotnet11'
dotnet = sdk/'dotnet.exe'
env = dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk),PATH=str(sdk)+os.pathsep+os.environ['PATH'])
core = 'Lokad.Lython.dll'
files = read(profile/'identity.json')['imageFiles']['candidate']
assert len(files)==32 and {name:sha(profile/'candidate'/name) for name in files}==files
images = {}
for role in ('reference','candidate'):
    image = lab/'frozen'/role
    image.mkdir(parents=True, exist_ok=True)
    expected = files.copy()
    for name in files:
        origin = (trial if role == 'candidate' else repo)/'src/Lokad.Lython/bin/Release/net11.0'/core if name==core else profile/'candidate'/name
        shutil.copyfile(origin,image/name)
        if name == core: expected[core] = sha(origin)
    for helper in (lab.parent/'native-format-selectors-r615/frozen/candidate').glob('ValidatedAllocation.*'):
        shutil.copyfile(helper,image/helper.name)
    assert {name:sha(image/name) for name in expected} == expected
    with (lab/(role+'-verify.log')).open('wb') as log:
        subprocess.run([dotnet,image/'Lokad.Lython.Benchmarks.dll','--compare','verify','--catalog',manifest,
                        '--dotnet',dotnet,'--python','C:/Python313/python.exe','--python-worker',repo/'benchmarks/cpython-worker.py',
                        '--out',lab/(role+'-verify.json')], env=env,stdout=log,stderr=subprocess.STDOUT, check=True,timeout=140)
    verified=read(lab/(role+'-verify.json'))
    assert verified['state']=='Completed' and verified['catalogSha256']==sha(manifest)
    with (lab/(role+'-allocation.log')).open('wb') as log:
        subprocess.run([dotnet,image/'ValidatedAllocation.dll',image,manifest,lab/(role+'-allocation.json')],
                       env=env,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=120)
    assert {name:sha(image/name) for name in expected} == expected
    images[role]=expected
assert images['reference'][core] != images['candidate'][core]
write(lab/'frozen-identity.json',dict(referenceCommit=reference,candidateCommit=candidate,casesSHA256=sha(manifest),images=images))
for a,b in zip(*(read(lab/(role+'-allocation.json'))['rows'] for role in images),strict=True):
    assert a['id']==b['id'] and a['sharedBudgetBaselineRestored'] and b['sharedBudgetBaselineRestored']
    before,after=[statistics.median(row['allocatedBytesPerInvocation']) for row in (a,b)]
    print(a['id'],f'{before:,} to {after:,} {100*(after/before-1):+.2f}%',a['peakExecutionMemoryBytes'],b['peakExecutionMemoryBytes'])
print('Both 32-file images match all five CPython goldens and restored the shared allowance.')
