#!/usr/bin/env bash
set -euo pipefail
export DOTNET_ROOT="$HOME/.dotnet"
cd /mnt/d/code/Lython/.git/agent-worktrees/native-format-selectors-r615
filter='FullyQualifiedName~Format|FullyQualifiedName~StringMembers|FullyQualifiedName~MethodDefinitionHostBoundary'
"$DOTNET_ROOT/dotnet" test tests/Lokad.Lython.PublicApi.Tests/Lokad.Lython.PublicApi.Tests.csproj -c Release -f net10.0 --artifacts-path artifacts/r615-wsl --filter "$filter"
"$DOTNET_ROOT/dotnet" test tests/Lokad.Lython.Tests/Lokad.Lython.Tests.csproj -c Release -f net10.0 --artifacts-path artifacts/r615-wsl --filter "$filter"
