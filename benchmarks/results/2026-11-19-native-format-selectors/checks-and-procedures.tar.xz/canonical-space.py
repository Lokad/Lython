from pathlib import Path, PurePosixPath
import hashlib, json, shlex, subprocess
from collections import defaultdict

lab=Path(__file__).resolve().parent
sha=lambda data:hashlib.sha256(data).hexdigest()
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i',str(Path.home()/'.ssh/id_lython-bench.pem'),
     '-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
base='/home/lokad/lython-bench-checks'
remote_inventory=subprocess.check_output(ssh+[f"find {base} -xdev -type f -links 1 -size +50000c "
    r"\( -name '*.tgz' -o -name '*.xz' -o -name '*.gz' -o -name '*.zip' \) -printf '%s %P\n'"],
    text=True,encoding='utf-8',timeout=35)
by_size=defaultdict(list)
for row in subprocess.check_output(['git','ls-tree','-r','-l','origin/master','benchmarks/results'],text=True).splitlines():
    info,name=row.split('\t',1)
    if info.split()[-1].isdigit():
        by_size[int(info.split()[-1])].append(name)
matches=[]
for row in sorted(remote_inventory.splitlines(),key=lambda s:-int(s.split(' ',1)[0])):
    number,remote=row.split(' ',1)
    n=int(number)
    if n not in by_size or 'b1021-' in remote:continue
    paths=by_size[n]
    matches.append(dict(bytes=n,path=remote,canonical=paths))
verify='''
from pathlib import Path
import fcntl,hashlib,json,os,shutil,stat,subprocess
root=Path('/home/lokad/lython-bench-checks');assert root.resolve()==root
with (root/'comparison-vm.lock').open('a') as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert not subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record|[p]ython3.13.*cpython-worker.py'],capture_output=True).stdout
 assert not any(os.path.ismount(p) for p in root.glob('*/guest-fixtures'))
 data=[]
 for p in MATCHES:
  path=root/p['path'];st=path.lstat()
  if path.resolve()!=path or not path.is_relative_to(root):continue
  if not (stat.S_ISREG(st.st_mode) and st.st_uid==os.getuid() and st.st_size==p['bytes'] and st.st_nlink==1):continue
  data.append(dict(p,sha256=hashlib.sha256(path.read_bytes()).hexdigest()))
 print(json.dumps(dict(freeBytes=shutil.disk_usage(root).free,candidates=data)))
'''.replace('MATCHES',repr(matches))
data=json.loads(subprocess.check_output(ssh+['python3 -'],input=verify.encode(),timeout=55))
groups=[]
for proof in data['candidates']:
    for canonical in proof['canonical']:
        recorded=subprocess.check_output(['git','show',f'origin/master:{canonical}'])
        if sha(recorded)!=proof['sha256']:continue
        assert recorded==Path(canonical).read_bytes()
        groups.append(dict(bytes=len(recorded),sha256=proof['sha256'],canonical=canonical,
            canonicalSHA256=proof['sha256'],committedBlobVerified=True,kind='exact archived measured replica',
            paths=[proof['path']],links=1))
        break
    if sum(p['bytes'] for p in groups)>=16*1024*1024:break
result=dict(freeBytes=data['freeBytes'],replicas=groups)
(lab/'quiet-space.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
print(result['freeBytes'],[(p['bytes'],p['paths'][0]) for p in groups])

