set -eu
root=/home/lokad/lython-bench-checks/native-format-selectors-b1045-20261119
trap 'result=$?; printf "%s\n" "$result" > "$root/exit-code.txt"' EXIT
python3 "$root/collect.py"
