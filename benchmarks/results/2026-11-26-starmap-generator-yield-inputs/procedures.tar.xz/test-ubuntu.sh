set -eu
export DOTNET_ROOT="$HOME/.dotnet"
export PATH="$DOTNET_ROOT:$PATH"
repo=/mnt/d/code/Lython
lab="$repo/.git/agent-notes/review-20261031/starmap-generator-yield-inputs-20261126"
snapshot=$(mktemp -d "$HOME/lython-starmap-gen-XXXXXX")
tar -xf "$lab/source.tar" -C "$snapshot"
for file in src/Lokad.Lython/Runtime/PyExecutableFunction.cs src/Lokad.Lython/Runtime/LythonRuntime.Calls.cs src/Lokad.Lython/Runtime/LythonRuntime.Generators.cs src/Lokad.Lython/Runtime/LythonRuntime.ItertoolsModule.cs src/Lokad.Lython/Runtime/PyIteration.cs src/Lokad.Lython/Runtime/PyItertools.Transforms.cs src/Lokad.Lython/Runtime/LythonRuntime.Executable.Interpreter.Dispatch.cs src/Lokad.Lython/Runtime/LythonRuntime.Executable.Interpreter.cs tests/Lokad.Lython.PublicApi.Tests/StarmapMaterializationParityTests.cs; do
    cp "$lab/source/$file" "$snapshot/$file"
    cmp "$lab/source/$file" "$snapshot/$file"
done
printf '%s\n' "$snapshot" > "$lab/ubuntu-source.txt"
cd "$snapshot"
filter='Category!=Stress&(FullyQualifiedName~CallablePacketOwnership|FullyQualifiedName~Starmap|FullyQualifiedName~IteratorAdapter|FullyQualifiedName~NativeCallback|FullyQualifiedName~ExecutableStackAdmission|FullyQualifiedName~Generator|FullyQualifiedName~AdmissionFailureCommand)'
for suite in Lokad.Lython.Tests Lokad.Lython.PublicApi.Tests; do
    log="$lab/$suite-ubuntu10.log"
    if dotnet test "tests/$suite/$suite.csproj" -c Release -f net10.0 --filter "$filter" > "$log" 2>&1; then
        tail -8 "$log"
    else
        tail -33 "$log"
        exit 1
    fi
done
