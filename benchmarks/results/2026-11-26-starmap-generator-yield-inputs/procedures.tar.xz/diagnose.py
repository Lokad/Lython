from difflib import unified_diff
from hashlib import sha256
from pathlib import Path
from statistics import median
import json
import os
import shutil
import subprocess

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
donor = lab.with_name("starmap-frame-inputs-20261126")
base = (lab / "base-revision.txt").read_text(encoding="utf-8-sig").strip()
assert not subprocess.check_output(["git", "diff", base, "HEAD", "--", "src"], cwd=repo)
assert not subprocess.check_output(["git", "diff", "HEAD", "--", "src"], cwd=repo)

def digest(path):
    return sha256(path.read_bytes()).hexdigest()

def read(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))

def write(path, value):
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False) + "\n", encoding="utf-8", newline="\n")

def manifest(path):
    return {file.name: digest(file) for file in path.iterdir()}

paths = [
    "src/Lokad.Lython/Runtime/LythonRuntime.Calls.cs",
    "src/Lokad.Lython/Runtime/LythonRuntime.Executable.Interpreter.cs",
    "src/Lokad.Lython/Runtime/LythonRuntime.Executable.Interpreter.Dispatch.cs",
    "src/Lokad.Lython/Runtime/LythonRuntime.Generators.cs",
    "src/Lokad.Lython/Runtime/LythonRuntime.ItertoolsModule.cs",
    "src/Lokad.Lython/Runtime/PyExecutableFunction.cs",
    "src/Lokad.Lython/Runtime/PyIteration.cs",
    "src/Lokad.Lython/Runtime/PyItertools.Transforms.cs",
]
patch = lab / "candidate.patch"
diff = []
for name in paths:
    before = subprocess.check_output(["git", "show", f"{base}:{name}"], cwd=repo).decode("utf-8")
    after = (lab / "source" / name).read_text(encoding="utf-8")
    assert before != after
    diff += [f"diff --git a/{name} b/{name}\n", *unified_diff(before.splitlines(keepends=True), after.splitlines(keepends=True),
                                                           fromfile="a/" + name, tofile="b/" + name)]
patch.write_text("".join(diff), encoding="utf-8", newline="\n")
subprocess.run(["git", "apply", "--check", str(patch)], check=True, cwd=repo)

core = "Lokad.Lython.dll"
baseline = donor / "local/candidate" / core
proved = read(donor / "comparison/quiet/terminal-status.json")["receipt"]
assert proved["complete"] and digest(donor / "comparison/quiet/observations.tar.xz") == proved["archiveSHA256"]
subprocess.run(["git", "apply", "--reverse", "--check", str(donor / "candidate.patch")], check=True, cwd=repo)
cand_core = lab / "windows/bin/Lokad.Lython/release_net11.0" / core
frozen = donor / "local/candidate"
donor_identity = read(donor / "local/identity.json")
assert manifest(frozen) == donor_identity["imageFiles"]["candidate"] and len(manifest(frozen)) == 32
catalog = lab / "representative.json"
shutil.copyfile(donor / "local/representative.json", catalog)
python_worker = lab / "cpython-worker.py"
shutil.copyfile(donor / "local/cpython-worker.py", python_worker)
assert digest(python_worker) == donor_identity["cpythonWorkerSHA256"]
images = {}
identities = {}
for role, library in (("reference", baseline), ("candidate", cand_core)):
    image = lab / role
    shutil.copytree(frozen, image)
    shutil.copyfile(library, image / core)
    images[role] = image
    identities[role] = manifest(image)
assert [name for name, sha in identities["reference"].items() if sha != identities["candidate"][name]] == [core]
write(lab / "identity.json", dict(sourceRevision=base, sourcePatchSHA256=digest(patch), imageFiles=identities,
                                 catalogSHA256=digest(catalog), cpythonWorkerSHA256=digest(python_worker)))

sdk = Path.home() / ".dotnet11"
dotnet = sdk / "dotnet.exe"
env = dict(os.environ, DOTNET_ROOT=str(sdk), DOTNET_ROOT_X64=str(sdk))
for role, image in images.items():
    output = lab / f"{role}-verify.json"
    subprocess.run([dotnet, image / "Lokad.Lython.Benchmarks.dll", "--compare", "verify", "--catalog", catalog,
                    "--dotnet", dotnet, "--python", "C:/Python313/python.exe", "--python-worker", python_worker,
                    "--out", output], check=True, cwd=repo, env=env, timeout=100)
    proof = read(output)
    assert proof["state"] == "Completed" and proof["caseCount"] == 4
    assert proof["catalogSha256"] == digest(catalog)
    assert proof["launched"]["library"]["sha256"] == identities[role][core]

async_catalog = lab / "async-catalog.json"
data = read(catalog)
for row in data["cases"]:
    row["runAsync"] = True
write(async_catalog, data)
for role, image in tuple(images.items()):
    allocation_image = lab / f"{role}-allocated"
    shutil.copytree(image, allocation_image)
    for file in (donor / "reference-allocated").glob("ValidatedAllocation*"):
        shutil.copyfile(file, allocation_image / file.name)
    assert all(digest(allocation_image / name) == sha for name, sha in identities[role].items())
    images[role] = allocation_image

all_rows = []
for mode, catalog_path in (("sync", catalog), ("async", async_catalog)):
    results = []
    for role, image in images.items():
        output = lab / f"{role}-{mode}-allocation.json"
        subprocess.run([dotnet, image / "ValidatedAllocation.dll", image, catalog_path, output],
                       check=True, cwd=repo, env=env, timeout=90)
        results.append(read(output)["rows"])
    for before, after in zip(*results, strict=True):
        assert before["id"] == after["id"]
        assert all(row["sharedBudgetBaselineRestored"] for row in (before, after))
        all_rows.append(dict(mode=mode, case=before["id"],
                             bytes=[median(row["allocatedBytesPerInvocation"]) for row in (before, after)],
                             peak=[row["peakExecutionMemoryBytes"] for row in (before, after)]))
write(lab / "allocation-summary.json", all_rows)
for row in all_rows:
    print(row)
