from pathlib import Path

lab = Path(__file__).resolve().parent
prior = lab.with_name("closed-starmap-row-operands-20261126")
source = (prior / "diagnose.py").read_text(encoding="utf-8")
before = """paths = [
    "src/Lokad.Lython/Runtime/LythonRuntime.Executable.IntegerChains.cs",
    "src/Lokad.Lython/Runtime/PyExecutableFunction.cs",
]"""
paths = (
    "LythonRuntime.Calls.cs", "LythonRuntime.Executable.Interpreter.cs",
    "LythonRuntime.Executable.Interpreter.Dispatch.cs", "LythonRuntime.Generators.cs",
    "LythonRuntime.ItertoolsModule.cs", "PyExecutableFunction.cs",
    "PyIteration.cs", "PyItertools.Transforms.cs",
)
after = "paths = [\n" + "".join(f'    "src/Lokad.Lython/Runtime/{name}",\n' for name in paths) + "]"
assert source.count(before) == 1
source = source.replace(before, after)
compile(source, "diagnose.py", "exec")
(lab / "diagnose.py").write_text(source, encoding="utf-8", newline="\n")

source = (prior / "prepare-local.py").read_text(encoding="utf-8")
for before, after in (
    ("Read exact starmap row operands directly for callback returns that need no frame.",
     "Transfer evaluated generator display operands across the yield boundary to the starmap callback."),
    ('"lython-closed-starmap-row-operands-fixture-"', '"lython-starmap-generator-yield-inputs-fixture-"'),
):
    assert source.count(before) == 1, before
    source = source.replace(before, after)
compile(source, "prepare-local.py", "exec")
(lab / "prepare-local.py").write_text(source, encoding="utf-8", newline="\n")
