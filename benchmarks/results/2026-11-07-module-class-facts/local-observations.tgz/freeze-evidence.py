from pathlib import Path
import hashlib,json,shutil,tarfile,xml.etree.ElementTree as ET
r=Path(__file__).parent;out=Path('benchmarks/results/2026-11-07-module-class-facts');out.mkdir()
checks={}
for p in r.glob('initial-*.trx'):
    counters=dict(ET.parse(p).find('.//{*}Counters').attrib)
    assert counters['failed']=='0';checks[p.stem]=counters
assert len(checks)==4
probeCores={f:hashlib.sha256(Path('src/Lokad.Lython/bin/Release',f,'Lokad.Lython.dll').read_bytes()).digest()==hashlib.sha256(Path('tools/LythonProbe/bin/Release',f,'Lokad.Lython.dll').read_bytes()).digest() for f in ['net11.0','net10.0']}
assert all(probeCores.values())
focused=dict(checks=checks,matchingProbeCoreBytes=probeCores,diagnosticDifferentialComparisons=716,publicCPythonProbeComparisons=32)
(r/'focused.json').write_text(json.dumps(focused,indent=2)+'\n',encoding='utf-8')
for n in ['identity.json','local-assessment.json','focused.json','selected-plan.md']:
    shutil.copyfile(r/n,out/n)
with tarfile.open(out/'local-observations.tgz','w:gz') as t:
    for p in r.iterdir():
        if p.is_file() and p.suffix in ['.json','.py','.cs','.log','.txt','.trx','.jsonl','.stderr','.patch','.md','.dll','.tgz']:
            t.add(p,arcname=p.name)
    for n in ['compile-sync','fresh-sync','warm-sync']:t.add(r/n,arcname=n)
with tarfile.open(out/'local-observations.tgz') as t:
    assert json.loads(t.extractfile('probe-summary.json').read())['comparisons']==32
    assert hashlib.sha256(t.extractfile('current-core.dll').read()).hexdigest()==json.loads((r/'identity.json').read_text(encoding='utf-8'))['coreSHA256']['candidate']
assessment=json.loads((r/'local-assessment.json').read_text(encoding='utf-8'))
table=[]
for row in assessment:
    if row['phase']=='compile':
        table.append('|'+row['case'].removeprefix('scripts.')+'|'+f"{row['allocationPercent'][0]:+.2f}%"+'|'+'/'.join(f'{x:+.2f}%' for x in row['elapsedPercent'])+'|'+f"{row['oldSpreadPercent']:+.2f}%"+'|')
(out/'README.md').write_text('''# Remove unused module class-cell analysis — R65

2026-11-07. Baseline `dc266746` / core `74c88248`, the R62 source fully
qualified by CI 42412531882. Current R65 is focused-qualified separately;
full delivery will be batched at a coherent retained checkpoint. Normal 0.4
optional adapter and comparison driver are unchanged. Publication is postponed.

Lexical preparation computed outward module class-cell demand after its complete
binding/scope walk. The executable builder uses hidden captures only for
parameterized function scopes; runtime module contexts use empty scope facts.
Static analysis has no consumer of the module demand. Delete that whole trailing
walk and disable the same unused calculation in standalone `ForModule`.
No replacement helper, cache, option, execution route or public API is introduced.
Function/class/lambda/generator capture queries and `ClassCellSyntaxFacts.Scope`
have genuine callers and remain. All module binding order, super preload decisions
and Python scope rules remain; no contracts change.

The wider proposed combination would need distinct demands for function/lambda/
comprehension shadowing, nested class suites versus methods and postponed
annotations. Caching a partially prepared fact before those decisions would add
another invariant. This deletion removes an actually unused analysis without
introducing that state. Larger consolidation and whole-script runtime work remain
open; this is not completion of the performance objective or a permanent ban.

## Validation

**591 internal / 1,793 public focused Release checks per actual .NET 11 and 10
pass**, including scopes, closures, classes/super, generators, annotations,
cancellation, refusal and cleanup. Both matching probes are built and contain
the corresponding core bytes. No architecture-only test, timeout or containment
assertion was relaxed. Coarse compilation preflights, terminal refusal and existing
stage cancellation are unchanged; later passes can finish before their next check.

The existing isolated diagnostic tool compares 358 sources with and without a
provider: **716 identical validity / ordered diagnostic records**, including spans.
Every compiled script is disposed and its borrowed allowance returns to zero.
Eight public probe sources across both cores and both APIs produce **32 CPython
matches**: module locals/global rebinding, absent `__class__`, `super`, nested class
suite captures, defining-class methods, postponed annotations, lambda/generator
escapes. The initial six-source successful run is also preserved. Existing complete
script diagnostics pass all goldens, image isolation, funding and fixture cleanup.

## Short affected-workload diagnostic

Same existing five whole scripts, isolated baseline/current/identical-baseline
load contexts, shared CoreLib/process GC; 32 warmups per image, five rotated
four-job rounds. Compile, fresh and warm are separate. Construction/disposal are
included for compile; fresh adds compilation to public execution, mediated I/O,
full outputs and result cleanup; warm excludes compilation. Driver startup and
image setup are excluded. The raw tool's legacy purpose text identifies its first
use; the frozen source/cores here identify this comparison.

Positive elapsed percentages mean current slower. Desktop clocks are diagnostic.

|Complete script / compile|Allocation change|Elapsed vs both old roles|Old elapsed spread|
|---|---:|---:|---:|
'''+ '\n'.join(table)+'''

Compilation allocation falls **3.53–4.64%**; fresh allocation falls roughly
0.13–1.46%, warm allocation is essentially unchanged. Elapsed includes an adverse
report result and drifting controls (warm search +15.61%, text +13.49% old-role
spread). Preserve all raw observations; **no CPU or warm-execution gain is
established**. Retain for deletion of a complete unused analysis and lower compile
allocation. No new VM timing campaign or unchanged full qualification was run.

[Exact source/core inventory](identity.json), [pre-code selected plan](selected-plan.md),
[focused checks](focused.json), [all phase observations](local-assessment.json),
[source/cores/tests/probes/raw diagnostic evidence](local-observations.tgz).
''',encoding='utf-8')
p=Path('benchmarks/results/2026-11-07-syntax-validation/README.md');s=p.read_text(encoding='utf-8')
s=s.replace('Full Windows/Ubuntu, actual11/10, original Stress and installed-package delivery\nis pending on the retained source. Publication remains postponed.',
'''Full delivery CI **42412531882** on `70267889` is GREEN: Windows/Ubuntu,
actual .NET 11/10, original Stress and installed-package consumers.
[Cached terminal receipt](delivery-ci.json); never query again. Later R65 source
changes are qualified separately. Publication remains postponed.''')
p.write_text(s,encoding='utf-8')
p=Path('benchmarks/EXPERIMENTS.md');s=p.read_text(encoding='utf-8').replace('Full delivery is pending. This does not complete the whole-script objective.',
'''Full delivery CI 42412531882 on 70267889 is GREEN (Windows/Ubuntu, actual11/10,
original Stress and installed consumers); cached receipt, no further query.
This does not complete the whole-script objective.''')
s+='''
## Unused module class-cell analysis removed (2026-11-07)

[R65](results/2026-11-07-module-class-facts/README.md) deletes the trailing module
class-cell demand walk and its standalone fallback calculation. Module execution
never consumes this demand; real capture queries and scope semantics remain.
591 internal / 1,793 public checks per actual11/10, 716 exact diagnostic comparisons
and 32 public CPython probes pass. Compile allocation −3.53–4.64%, fresh roughly
−0.13–1.46%; warm essentially unchanged. Adverse report elapsed and drifting desktop
controls preserved; no CPU/warm gain claim or new VM campaign. Full delivery batches
at the next coherent checkpoint; R62's complete green delivery excludes this change.
'''
p.write_text(s,encoding='utf-8')
p=Path('PLAN.md');s=p.read_text(encoding='utf-8')
s=s.replace('CI 42412531882: ordinary Release both targets and installed consumers pass on both platforms; original Stress in progress.',
    'FULLY QUALIFIED CI 42412531882: Windows/Ubuntu, actual .NET 11/10, original Stress and installed consumers. Terminal cached; never query again.')
s += '''
R65 module-only analysis deletion RETAINED: 591 internal / 1,793 public per actual
.NET 11/10, 716 exact diagnostic records and 32 CPython probes pass. Compile
allocation −3.53–4.64%; warm essentially unchanged. No CPU claim from adverse/
drifting desktop clocks. [Evidence](benchmarks/results/2026-11-07-module-class-facts/README.md).
No replacement mechanism or public contract; genuine capture queries remain.
Full new-source delivery batches at the next coherent checkpoint; do not relabel
R62's green 70267889 receipt as qualification of this newer source. Commit next,
then resume the material runtime roadmap. No active local/VM worker or prototype.
'''
p.write_text(s,encoding='utf-8')
print('R65 evidence frozen; R62 full green receipt recorded separately. No new full CI dispatch.')
