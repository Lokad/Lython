from pathlib import Path
p=Path('PLAN.md');s=p.read_text(encoding='utf-8')
a=s.index('Next R65 bounded design:');b=s.index('For the selected redesign, before code',a)
s=s[:a]+'''R65 selected deletion: module outward class-cell analysis has no consumer. The
executable builder admits hidden captures only for a parameterized function scope;
runtime module contexts use empty scope facts. Static analysis does not consume
module RequiresClassCell. Existing function/class/lambda/generator queries have
real callers and different postponed-annotation, nested-class and shadowing rules.
A general merge would require additional demand states; do not introduce it here.

Remove the final module ReferencesFromFunction walk in lexical preparation and
disable the same unused demand in the standalone ForModule fallback. Preserve
module bindings/order, all real capture queries, preloads and class-cell Scope.
No new helper/cache, public contract or runtime route. CSV/text/report/config
compilation is affected; no warm improvement predicted. Preserve diagnostics,
module globals/locals and nested captures, annotations, comprehension/default
boundaries, global/nonlocal, cancellation and terminal refusal. Existing scope/
class-cell/annotation/generator/admission regressions plus exact diagnostic/probe
comparison; one short existing-tool compilation/fresh/warm diagnostic. A pure
unused-analysis deletion needs no new VM campaign or unchanged full qualification.
Batch full delivery with the next coherent retained checkpoint; record deletion,
allocation and noisy elapsed separately. Larger binding/class-cell consolidation
and substantial runtime improvements remain open; this is no replacement objective.

'''+s[b:]
a=s.find('\nR65 source caution:')
if a>=0:s=s[:a]+'\n'
p.write_text(s,encoding='utf-8')
r=Path(__file__).parent
(r/'selected-plan.md').write_text(s,encoding='utf-8')
print('R65 concrete deletion/replacement contract recorded before code.')
