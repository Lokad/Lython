from pathlib import Path
import hashlib,json,os,shutil,subprocess
r=Path(__file__).parent
sources=[
'''class C:
 def owner(self):return __class__
print('__class__' in locals(),C().owner() is C)
''',
'''__class__='global'
read=lambda:__class__
class C:
 __class__='member'
 def owner(self,value=__class__):return __class__,value
print(read(),C().owner()[0] is C,C().owner()[1],locals()['__class__'])
''',
'''def outer():
 __class__=42
 class C:
  value=__class__
  def owner(self):return __class__
 return C
C=outer()
print(C.value,C().owner() is C,'__class__' in locals())
''',
'''class Base:
 def value(self):return 7
class C(Base):
 def value(self):return super().value()+1
print(C().value(),'__class__' in locals())
''',
'''from __future__ import annotations
class C:
 def owner(self,value:__class__=None)->__class__:return __class__
print(C().owner() is C,C.owner.__annotations__)
''',
'''class C:
 def values(self):
  def read():return __class__
  return read,lambda:__class__,(__class__ for _ in range(1))
read,lam,gen=C().values()
print(read() is C,lam() is C,next(gen) is C,'__class__' in locals())
''',
'''def read():return __class__
try:read()
except NameError:print('missing')
print('__class__' in locals())
''',
'''def read(value):return super
print(read(1) is super,'__class__' in locals())
''',
]
(r/'probe-sources.json').write_text(json.dumps(sources,indent=2)+'\n',encoding='utf-8')
env=os.environ.copy();env['DOTNET_ROOT']='C:/Users/JoannesVermorel/.dotnet11';env['PATH']=env['DOTNET_ROOT']+os.pathsep+'C:/Python313'+os.pathsep+env['PATH']
dotnet=env['DOTNET_ROOT']+'/dotnet.exe';reports={}
for role,filename in [('before','baseline-core.dll'),('candidate','current-core.dll')]:
    target=r/'probes'/role
    if not target.exists():
        shutil.copytree('tools/LythonProbe/bin/Release/net11.0',target,copy_function=os.link)
        (target/'Lokad.Lython.dll').unlink();shutil.copyfile(r/filename,target/'Lokad.Lython.dll')
    assert hashlib.sha256((target/'Lokad.Lython.dll').read_bytes()).digest()==hashlib.sha256((r/filename).read_bytes()).digest()
    for api in ['sync','async']:
        args=[dotnet,str(target/'LythonProbe.dll'),'--batch-json','--compare-python']+(['--async'] if api=='async' else [])
        done=subprocess.run(args,input=json.dumps(sources),text=True,encoding='utf-8',env=env,capture_output=True)
        stem=role+'-'+api
        (r/(stem+'-probes.jsonl')).write_text(done.stdout,encoding='utf-8');(r/(stem+'-probes.stderr')).write_text(done.stderr,encoding='utf-8')
        assert done.returncode==0,(stem,done.stderr,done.stdout[-3500:])
        data=[json.loads(line) for line in done.stdout.splitlines()]
        assert len(data)==len(sources) and all(row['Matches'] and row['Lython']['Success'] for row in data)
        reports[stem]=[row['Lython']['StandardOutput'] for row in data]
assert all(v==reports['before-sync'] for v in reports.values())
(r/'probe-summary.json').write_text(json.dumps(dict(sources=len(sources),roles=list(reports),comparisons=len(sources)*len(reports),allMatchCPython=True,beforeAndCurrentOutputsIdentical=True),indent=2)+'\n',encoding='utf-8')
print(len(sources)*len(reports),'public probes match CPython and before/current across sync/async; module and nested class captures unchanged.')
