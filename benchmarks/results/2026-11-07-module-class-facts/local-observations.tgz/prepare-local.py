from pathlib import Path
import hashlib,json,os,shutil,subprocess
r=Path(__file__).parent;prior=r.parent/'syntax-validation-r62'
for role,filename in [('before','baseline-core.dll'),('candidate','current-core.dll')]:
    if role=='candidate':shutil.copyfile('src/Lokad.Lython/bin/Release/net11.0/Lokad.Lython.dll',r/filename)
    target=r/'images'/role
    shutil.copytree(prior/'images/candidate',target,copy_function=os.link)
    (target/'Lokad.Lython.dll').unlink();shutil.copyfile(r/filename,target/'Lokad.Lython.dll')
identity=dict(sourceRevision='dc266746 plus R65 unused module class-cell analysis deletion',baseline=json.loads((r/'baseline.json').read_text(encoding='utf-8')),
    coreSHA256={role:hashlib.sha256((r/'images'/role/'Lokad.Lython.dll').read_bytes()).hexdigest() for role in ['before','candidate']},
    productionSources={str(p).replace('\\','/'):hashlib.sha256(p.read_bytes()).hexdigest() for p in Path('src/Lokad.Lython').rglob('*.cs') if not any(x in ['bin','obj'] for x in p.parts)})
(r/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8')
(r/'source.patch').write_bytes(subprocess.check_output(['git','diff','--binary','--','src']))
shutil.copyfile(prior/'catalog.json',r/'catalog.json')
shutil.copyfile(prior/'measure.py',r/'measure.py')
shutil.copyfile(prior/'diagnostic-sources.json',r/'diagnostic-sources.json')
shutil.copyfile(prior/'assess-local.py',r/'assess-local.py')
print('Existing diagnostic/measurement tools reused; exact before/current frozen.')
