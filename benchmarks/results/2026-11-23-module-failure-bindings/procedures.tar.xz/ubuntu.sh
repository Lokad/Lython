set -eu
export DOTNET_ROOT=/home/vermorel/.dotnet
export DOTNET_ROOT_X64=$DOTNET_ROOT
lab=/mnt/d/code/Lython/.git/agent-notes/review-20261031/module-failure-bindings-20261123
common='FullyQualifiedName~NativeTruthiness|FullyQualifiedName~FailureProjection|FullyQualifiedName~GlobalNamespace|FullyQualifiedName~RenderingStack|FullyQualifiedName~GovernedAdmissionPreflight|FullyQualifiedName~Exception|FullyQualifiedName~Class|FullyQualifiedName~FileCleanup|FullyQualifiedName~DefinitionCancellation'
"$DOTNET_ROOT/dotnet" test tests/Lokad.Lython.PublicApi.Tests/Lokad.Lython.PublicApi.Tests.csproj -c Release -f net10.0 --artifacts-path "$lab/ubuntu" --filter "$common"
