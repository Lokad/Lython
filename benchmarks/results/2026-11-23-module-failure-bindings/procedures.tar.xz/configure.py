from pathlib import Path
import gzip
import hashlib
import json
import subprocess

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
prior = lab.with_name('plain-class-fixed-20261123')


def adapt(name, substitutions):
    src = (prior / name).read_text(encoding='utf-8')
    for before, after in substitutions:
        assert src.count(before) == 1, (name, before)
        src = src.replace(before, after)
    compile(src, str(lab / name), 'exec')
    (lab / name).write_text(src, encoding='utf-8', newline='\n')


adapt('prepare.py', (
    ("tree=repo/'.git/agent-worktrees/plain-class-module-slots-20261123'", "tree=repo"),
    ("donor=notes/'terminal-tuple-reads-20261123'", "donor=notes/'plain-class-fixed-20261123'"),
    ("reference,candidate=git('rev-parse','48bf2bc2f'),git('rev-parse','HEAD',cwd=tree)",
     "reference,candidate=git('rev-parse','0112138c1'),git('rev-parse','e4392967b')"),
    ("assert reference.startswith('48bf2bc2f')", "assert reference.startswith('0112138c1')"),
    ("assert not git('diff','--name-only',reference,'HEAD','--','src','tests')",
     "assert not git('diff','--name-only',candidate,'HEAD','--','src','tests')"),
    ("    catalog,\n)", "    catalog,\n    read(notes/'short-text-boundaries-20261123/catalog.json'),\n)"),
    ("    'scripts.csv-invoice.helper-accumulation',\n    'scripts.csv-invoice.large',\n    'scripts.csv-meter-report.explicit-float.observe-tuple',\n    'scripts.csv-meter-report.explicit-float',\n    'scripts.ordinary-fully-supplied-helper.local-function',",
     "    'diagnostic.text-summary.nonlocal-computed-width.large',"),
    ("B1533 keep owned slots for a plain class while preserving reusable namespaces",
     "B1536 benchmark controls for the corrected public module lifetime"),
))
adapt('prepare-jobs.py', (
    ('quote,nested,_,observer,_,supplied,manifest=', 'quote,short,manifest='),
    ("(quote['id'],'compile-run')", "(short['id'],'warm')"),
))
adapt('stage.py', (
    ('plain-class-namespace-b1533-20261123', 'module-failure-bindings-b1536-20261123'),
    ('terminal-tuple-reads-b1531-20261123', 'plain-class-namespace-b1533-20261123'),
    ('lython-b1533-fixtures', 'lython-b1536-fixtures'),
))
adapt('quiet.py', (
    ('lython-b1533-plain-class-namespace-20261123', 'lython-b1536-module-failure-bindings-20261123'),
    ('.+b1533-', '.+b1536-'),
    ('lython-b1533-stage-', 'lython-b1536-stage-'),
))
adapt('summarize.py', ())

archive = 'benchmarks/results/2026-11-23-terminal-tuple-reads/'


def fetch(name):
    return subprocess.check_output(['git', 'show', 'origin/master:' + archive + name], cwd=repo)


def sha(data):
    return hashlib.sha256(data).hexdigest()


receipt = json.loads(fetch('terminal-status.json'))['receipt']
assert receipt['complete'] and receipt['archivedAndVerifiedUnderLease']
assert sha(fetch('observations.tar.xz')) == receipt['archiveSHA256']
filename = 'candidate-core.dll.gz'
core = gzip.decompress(fetch(filename))
assert sha(core) == json.loads(fetch('identity.json'))['imageFiles']['candidate']['Lokad.Lython.dll']
replica = dict(path='terminal-tuple-reads-b1531-20261123/candidate/Lokad.Lython.dll', sha256=sha(core),
               observationSHA256=receipt['archiveSHA256'], trackedArchive=archive + filename)
(lab / 'verified-replicas.json').write_text(json.dumps([replica], indent=2) + '\n', encoding='utf-8', newline='\n')
