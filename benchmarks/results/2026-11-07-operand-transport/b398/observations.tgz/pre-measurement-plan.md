# Lokad.Lython 0.11.0

Updated 2026-11-07. Git-ignored; never force-add. Publication/tagging postponed.
Objective: coherent simplification and substantial complete-script performance.
Completing one experiment or qualification checkpoint does not complete this objective.

## Delivery status

- **Committed/pushed:** metadata/evidence HEAD `58d14512`; production through
  `fba865ef` is fully qualified. Terminal GREEN `42357660230` covers Windows/Ubuntu,
  actual .NET 11/10, original Stress and installed core-package consumers. Includes
  R40 scalar cursor, R41 shared receiver methods and prior compiler/UTF-8/helper
  milestones. Receipt beside R41 evidence; never query terminal runs again.
- **Active uncommitted R43:** ordinary-operation indexed inputs and one physical
  layout pass. Initial and metadata-refined versions each passed 1,167 internal /
  2,665 public focused checks per target. A final simplification removes the
  prototype frame snapshot cache; 128 internal / 676 public affected checks pass
  per target after that deletion. Full
  delivery, quiet timing and retention/debt decisions remain pending.
- **Current external comparison:** B395 exact production `fba865ef`, frozen
  `5d2ca8e1`, CPython 3.13.16/.NET 11 RC3, quiet F4as_v7 Ubuntu VM. Warm ratios:
  CSV 1.19–1.23x, text 1.75–1.79x, JSON 1.04x, report 1.36–1.38x, config 1.25x.
  Compile 42–68 us separately; fresh ratios 1.03–1.74x across those scripts.
  Variable controls remain explicit. See docs/BENCHMARKS.md for boundaries/status.
- **Independent regex:** core remains decoupled; normal optional, nonpackable
  adapter pinned 0.4.0. Earlier immutable dev48/source f6b2175e passed 85 internal /
  488 public checks per target on R30; this is not current-HEAD, final safety or
  backend performance certification.

## Established evidence and unresolved debt

| Work | Established result | Limits / decision |
| --- | --- | --- |
| Shared compiler facts | Corrected shared inferred-value traversal eliminates exponential analysis; fully qualified | Preserve callback correction; no warm CPU claim. |
| Native helper returns | Allocation −19.92/−19.31%; fully qualified | Earlier elapsed gains remain diagnostic. No unchanged requalification. |
| Direct UTF-8 formatting/storage | Allocation −8.67%; controlled B102 elapsed/CPU −5–8% supports retention | Original adverse 15.125 ms remains unexplained and preserved. |
| R20/R25 records | Shared keys, independent values, completed CSV storage transfer; allocation −7.31/−6.55%, native warm −7.72–8.04% | Selectively replaces the old rigidly rejected 6–8% bulk-record attempt; controls mixed. |
| R35/R38 | Dynamic report allocation ~−15.35%, quiet warm −10–13%; compile allocation −4.38–8.94% | CSV possible debt +0.13–2.36%; R38 required full regex analysis preserved after three initial failures. |
| R40/R41 | Unicode cursor scaling −31–79%; shared receiver methods remove ten markers/guards and closures, regex allocation ~−29.47%, warm −8.64–10.80% | Not broad CPU/parity claims; ASCII and original CSV adverse controls remain possible debt. Fully qualified. |
| R42 cost gate | Text: 1,089 CPU samples, 44 unknown; prefix 229 self / 1,056 inclusive; scalar add 41 self | Self includes inlined work; inclusive totals overlap. No universal scalar rewrite or saved-CPU forecast. |

History, original failed conditions, rejected designs and complete qualification
live in benchmarks/EXPERIMENTS.md and immutable benchmarks/results/. R43 development
evidence stays outside docs/. Do not repeat unchanged completed qualification.

## Priority 1 — complete R43 ordinary-operation transport

Hypothesis: remove repeated load dispatch/copies/retirement around ordinary binary,
unary and subscript reads/stores, preserving existing executable/native helpers.
Affects text counting, CSV/JSON updates and report helpers; all four are controls.

- Extend existing integer sources (constant/local/temporary), not a second operand
  framework. Fold only adjacent plain uncaptured/nonmirrored local/constant leaves
  within one block. Checked missing-local reads retain original spans in sparse
  cold metadata. Dynamic/global/cell reads and real snapshots remain.
- Delete initialized-local tracking/invalidation inventories and displaced repeated
  value/store selectors. Fold before the one shape pass; recompute physical
  positions, owned extents, exception depths and protocol scratch. Calls still
  determine workspace capacity on the maintained scripts; do not claim otherwise.
- The initial 40-byte instruction and +2.8–3.5% compile allocation are preserved.
  Reuse a subscript store's redundant result field for its third input, retaining
  32-byte instructions. Measure final cold metadata and compile allocation.
  Final census: text 85→77 instructions, CSV helper 24→17, report helper 19→13;
  instruction/read-span payload smaller, workspace unchanged. Final compile
  allocation +0.20–0.87%, replacing the initial +2.8–3.5% debt; no CPU claim yet.
- Remove the prototype's frame-wide cache/index/cleanup hooks and 64-byte charge.
  Context promotion runs no guest/admission callback. Type getters retain the
  original type/key in existing funded scratch; actual async operations capture
  input values until awaited completion. Keep transient references outside the
  long dispatch loop. No new ledger, pool, allowance or dormant alternative.
- Semantic acceptance: original read/error/effect order and spans; unbound/builtin
  lookup, closures/mirroring, native proofs, custom protocols and type descriptors;
  cancellation/first refusal stop publication and following effects; pending aliases
  stay funded, cleanup/depths/budget reuse recover. New three-input store coverage
  exercises rebinding, real suspension and both failures. Compiler defects fail
  explicitly, with no silent execution fallback.
- Remaining bounded gate: B397 text warm/fresh plus
  CSV/JSON/report controls against frozen fba. Two old/two current processes,
  normal GC/tiering/optional 0.4; 240 s owner +30 s stop +30 s margin before observing.
  Preserve all adverse outcomes. Decide retention and explicit remaining debt for
  the whole phase, then batch full platform/Stress/package delivery if retained.
  No primary CPython refresh until that coherent retained checkpoint.

## Next redesign boundaries

Select a real dominant phase from current evidence; do not accumulate narrow cases.
For each selected milestone record the hypothesis, eliminated work/storage and
displaced code, affected scripts, semantic gates, bounded comparison and controls.

| Boundary | Evidence / acceptance / stopping criterion |
| --- | --- |
| Complete calls/frames | R39 CSV helper-inclusive totals are useful work, not proof of binding dominance. Existing borrowed operands/final slots/lazy contexts/native helpers stay. Select only a real removable phase; preserve binding, defaults, closures, exceptions, genuine I/O and owners. Slower call-arena/control designs require new evidence, not automatic retry. |
| Operand transport | R43 completes the selected ordinary-operation representation. Assess its complete-script result before selecting a further dispatch/frame redesign; no automatic chain of leaf-specific rewrites. |
| Per-record collections | Shared keys/R25 transfer and synchronous JSON already exist. Reassess bulk construction only where an actual extra copy/capacity phase remains; preserve hook/order/reentry/alias/overlap semantics. Original control regressions remain evidence. |
| Scalars and text | R42 scalar add alone is insufficient for universal tagged values. Bulk UTF-8 and prepared helpers already exist. Select remaining conversions/storage or dispatch only with material complete-script cost; preserve exact integer promotion, identity, Unicode, hashes and cancellation. |
| Frontend/setup | Shared lexical/class/parameter facts, R38 demand pruning, shared builtins and executable imports already exist. Remove actual repeated analysis/storage; preserve dead-scope diagnostics, fresh mutable state and regex analysis. Compile separately, and include compile-to-result for config/new scripts. |

A justified redesign may temporarily regress. Its completion milestone must state
whether remaining debt is accepted, corrected or withdrawn. A source simplification,
an allocation reduction and a CPU improvement are distinct results.

## Independent regex track

Continue Lython-owned Python/native UTF-8 semantics: byte ranges, scalar positions,
original-subject windows, captures/replacements/errors/cache ownership and current
tokens through actual work. Development producers and adapter-local bridges may
support contract/semantic work; missing released capabilities defer only affected
final adapter qualification. They do not stop core or independent performance work.

Current precise producer gaps: DetailedData lacks a separate Prepare working owner;
native names lack enumeration; cursors mix creation/current token authority. Exact
dev48 supplies no documented removal of these limits. Keep conservative preflight,
adapter-local conversion and the qualified cancellation bridge where needed.
Qualify immutable released inputs and managed safety separately. No silent dialect
fallback, work/time quotas, sibling edits, abandoned matching or publication gate
on Lython development. Existing R40/R41 work needs no new producer release.

## Experimental and delivery policy

Timeouts, unstable unchanged controls and inconclusive observations establish
uncertainty, not permanent design rejection. Permit bounded justified confirmation,
refinement or measurement correction; never repeat until favorable. Size observations
for the quiet VM, preserve original conditions/adverse results and source/binary
provenance. Percentages inform decisions rather than automatically vetoing useful
simplification. Use focused correctness/cancellation/ownership checks while iterating;
batch full actual11/10 Windows/Ubuntu, original Stress and installed consumers at
meaningful retained delivery checkpoints. Publication remains postponed.

## Constraints / resources

AGENTS.md governs: fully managed/memory-safe, managed stack/nesting, host mediation,
current cancellation, borrowed shared allowance/preflights/overlap/escaping aliases
and awaited cleanup. First refused admission terminates the command. No unsafe,
tracing, weak reclamation, forced GC, fuel/quotas/caps or hidden allowance. Bounded
host-driven batches; XML depth constraint retained. No overlapping local tests,
builds or measurements. PLAN stays ignored; docs describe only current releases.

VM: lokad@20.166.121.73, key ~/.ssh/id_lython-bench.pem. B385–B396 are terminal and
archived: never service-query again. B397 is planned, not launched. Before launch
verify final images/controls and free space (about 89 MB last checked). Persistent
evidence; archive/verify RAM traces under lease before removal. Record owner/stop/
margin before observing, never restart after observation timeout. Earlier duplicate
image/evidence retirements have exact committed backups and receipts; do not use
those incomplete old images without restoration.
