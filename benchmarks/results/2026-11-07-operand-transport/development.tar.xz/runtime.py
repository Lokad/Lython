from pathlib import Path
root=Path('D:/code/Lython')
def replace(s,old,new):
    assert s.count(old)==1,(old[:100],s.count(old));return s.replace(old,new)
def edit(name,fn):
    p=root/'src/Lokad.Lython/Runtime'/name;s=p.read_text(encoding='utf-8');new=fn(s);assert new!=s,name;p.write_text(new,encoding='utf-8',newline='\n')
def state(s):
    s=replace(s,'        internal object? ReturnValue;','''        internal object? ReturnValue;
        // Captured only across genuine admission/raw-protocol pauses. Zero is
        // empty; otherwise this is the originating instruction index plus one.
        internal ExecutableInputs DeferredInputs;
        internal int DeferredInputIndex;''')
    s=replace(s,'            ReturnValue = null;','            ReturnValue = null;\n            DeferredInputs = default;\n            DeferredInputIndex = 0;')
    s=replace(s,'long bytes = checked((long)codeObject.PatternStorageCount * RuntimeMemoryEstimates.ScalarStorageBytes);', '''// Fund the inline captured-input metadata and adoption overlap with the
        // same workspace owner; it is not another allowance or per-value ledger.
        long bytes = checked(64L + (long)codeObject.PatternStorageCount * RuntimeMemoryEstimates.ScalarStorageBytes);''')
    return s
edit('LythonRuntime.Executable.cs',state)
def interpreter(s):
    s=replace(s,'            ClearExecutableBindings();','            ClearInstructionInputs(ref _execution);\n            ClearExecutableBindings();')
    s=replace(s,'StoreExecutableLocal(ref ExecutableWorkState execution, ExecutionContext? invocation, in ExecutableInstruction instruction)', 'StoreExecutableLocal(ref ExecutableWorkState execution, ExecutionContext scope, ExecutionContext? invocation, in ExecutableInstruction instruction)')
    s=s.replace('TakeOperand(ref execution, instruction)', 'TakeOperand(ref execution, instruction, scope)')
    a=s.index('        private object ReadOperand(int source)');b=s.index('        private void ExecuteDefinitionOrFallback(',a)
    s=s[:a]+'''        private static object ReadOperand(ref ExecutableWorkState execution, int source, ExecutionContext scope, int input)
        {
            if (source < 0) return RuntimeValue(execution.Code.Constants[~source]);
            var value = execution.Stack[source];
            if (source < execution.Code.FirstTemporarySlot && ReferenceEquals(value, UninitializedLocal))
                return LoadLocal(execution.Code, execution.Locals, source,
                    execution.Code.OperandReadSpan(execution.InstructionIndex, input), scope);
            return value;
        }

        private static object TakeOperand(ref ExecutableWorkState execution, in ExecutableInstruction instruction, ExecutionContext scope)
        {
            if (instruction.InputStart >= execution.Code.FirstTemporarySlot)
                return execution.Stack.TakeValue(instruction.InputStart, instruction.LiveExtent);
            var value = ReadOperand(ref execution, instruction.InputStart, scope, 0);
            execution.Stack.RetireTo(instruction.LiveExtent);
            return value;
        }

''' +s[b:]
    a=s.index('        private static void ExecuteOperandValueOperation(');b=s.index('        // Ordinary returns deliver',a)
    s=s[:a]+'''        private static void ExecuteSliceValueOperation(ref ExecutableWorkState execution, ExecutionContext scope,
            ExecutionContext? invocation, in ExecutableInstruction instruction)
        {
            try
            {
                var result = ExecuteExecutableSlice(in execution.Stack, instruction.InputStart, instruction.SliceParts, instruction.Span, scope);
                PublishInstructionResult(ref execution, invocation, instruction, result);
            }
            catch { execution.Stack.RetireTo(instruction.ResultSlot); throw; }
        }

''' +s[b:]
    s=s.replace('ExecuteOperandValueOperation(ref _execution, this, this, instruction);','ExecuteSliceValueOperation(ref _execution, this, this, instruction);')
    return s
edit('LythonRuntime.Executable.Interpreter.cs',interpreter)
def dispatch(s):
    s=replace(s,'private enum InstructionPause { Boundary, Operation, Disposal, ContextRequired }','private enum InstructionPause { Continue, Boundary, Operation, Disposal, ContextRequired }')
    s=replace(s,'StoreExecutableLocal(ref execution, invocation, instruction);','StoreExecutableLocal(ref execution, scope, invocation, instruction);')
    a=s.index('                        case ExecutableOpCode.StoreSubscript or ExecutableOpCode.StoreSubscriptLast:');b=s.index('                        case ExecutableOpCode.StoreMember',a)
    s=s[:a]+s[b:]
    a=s.index('                        case ExecutableOpCode.Binary or ExecutableOpCode.Augmented:');b=s.index('                        case ExecutableOpCode.ForNext:',a)
    s=s[:a]+'''                        case ExecutableOpCode.Binary or ExecutableOpCode.Augmented or ExecutableOpCode.Unary or ExecutableOpCode.Subscript
                            or ExecutableOpCode.StoreSubscript or ExecutableOpCode.StoreSubscriptLast:
                            var pause = ExecuteInputInstruction(ref execution, scope, invocation, instruction, asynchronous,
                                out pending, out pendingSpan);
                            if (pause != InstructionPause.Continue) return pause;
                            break;
''' +s[b:]
    s=s.replace('ExecuteOperandValueOperationAsync(instruction)','ExecuteSliceValueOperationAsync(instruction)')
    return s
edit('LythonRuntime.Executable.Interpreter.Dispatch.cs',dispatch)
def asynchronous(s):
    a=s.index('        private async ValueTask ExecuteOperandValueOperationAsync(')
    s=s[:a]+'''        private async ValueTask ExecuteSliceValueOperationAsync(ExecutableInstruction instruction)
        {
            try
            {
                var (start, end, step) = ReadExecutableSliceBounds(in _execution.Stack, instruction.SliceParts, instruction.InputStart + 1);
                var result = await ReadSliceValueAsync(_execution.Stack[instruction.InputStart], start, end, step, instruction.Span, this).ConfigureAwait(false);
                PublishInstructionResult(instruction, result);
            }
            catch { _execution.Stack.RetireTo(instruction.ResultSlot); throw; }
        }

    }
}
'''
    return s
edit('LythonRuntime.Executable.Interpreter.Async.cs',asynchronous)
def targets(s):
    a=s.index('                    case ExecutableOpCode.StoreSubscript or ExecutableOpCode.StoreSubscriptLast:');b=s.index('                    case ExecutableOpCode.ReadRetainedSubscript:',a)
    s=s[:a]+s[b:]
    a=s.index('        private static ValueTask ExecuteSubscriptStore(');b=s.index('        private ValueTask CompleteTargetMutation(',a)
    return s[:a]+s[b:]
edit('LythonRuntime.Executable.Targets.cs',targets)
def calls(s):
    s=replace(s,'TrySuspendForTypeSubscription(ExecutableInstruction instruction)','TrySuspendForTypeSubscription(ExecutableInstruction instruction, ExecutableInputs inputs)')
    s=replace(s,'            var start = instruction.InputStart;\n            if (_preparedCallValue', '            var start = instruction.ResultSlot;\n            if (_preparedCallValue')
    s=replace(s,'            if (_execution.Stack[start] is not PyType type ||','            if (inputs.First is not PyType type ||')
    # Only actual raw type calls need contiguous argument borrows. Materialize
    # their already-captured receiver/key in the compiler-funded scratch region.
    s=replace(s,'                // Match raw ternary invocation:', '''                _execution.Stack.PublishValue(start, start + 1, inputs.First);
                _execution.Stack.PublishValue(start + 1, start + 2, inputs.Second!);
                // Match raw ternary invocation:''')
    s=replace(s,'            if (raw is not (PyClassMethod or PyStaticMethod or PyExecutableFunction)) return false;', '''            if (raw is not (PyClassMethod or PyStaticMethod or PyExecutableFunction)) return false;
            _execution.Stack.PublishValue(start, start + 1, inputs.First);
            _execution.Stack.PublishValue(start + 1, start + 2, inputs.Second!);''')
    # A getter result may become a second raw call without another member bind.
    # Its receiver/key already occupy scratch from the first call.
    s=replace(s,'            if (completion == CallCompletion.TypeSubscription) CheckExecution(span);','''            if (completion == CallCompletion.TypeSubscription) CheckExecution(span);
            if (completion is CallCompletion.TypeGetter or CallCompletion.TypeSubscription)
                ClearInstructionInputs(ref _execution);''')
    return s
edit('LythonRuntime.Executable.Calls.cs',calls)
def routing(s):
    for signature in ['private bool TryRouteReturn(ReturnSignal signal, LythonSourceSpan span)',
                      'private bool TryRouteControl(ControlSignal signal, LythonSourceSpan span)',
                      'private bool TryRouteRuntimeException(LythonRuntimeException ex, LythonSourceSpan span)']:
        s=replace(s,signature+'\n        {',signature+'\n        {\n            ClearInstructionInputs(ref _execution);')
    return s
edit('LythonRuntime.Executable.Interpreter.Routing.cs',routing)
print('Runtime prototype: single captured-input operation path, genuine pause snapshots, detached cleanup; old repeated value selectors removed.')
