from pathlib import Path
import fcntl,hashlib,json,subprocess,tarfile
root=Path('/home/lokad/lython-bench-checks/operand-transport-b397-20261107')
with (root.parent/'comparison-vm.lock').open('a') as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert not list(Path('/dev/shm').glob('lython-comparison-files-*'))
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record'],capture_output=True).returncode==1
 journal=subprocess.run(['journalctl','-u','lython-b397-operand-transport-20261107.service','--no-pager','-n','65','-o','cat'],capture_output=True,text=True)
 (root/'failure-journal.txt').write_text(journal.stdout+journal.stderr)
 with tarfile.open(root/'failed-observations.tgz','w:gz') as t:
  for name in ['confirmation','identity.json','representative.json','collect.py','cpython-worker.py','pre-measurement-plan.md','setup-contract.json','source.patch','contract.md','started.utc','stopped.utc','exit-code.txt','run.sh','archive-owned.py','source-current.zip','focused.json','failure-journal.txt']:
   if (root/name).exists():t.add((root/name).resolve(),arcname=name)
 with tarfile.open(root/'failed-observations.tgz') as t:assert t.getmember('failure-journal.txt').size>0
 receipt=dict(complete=False,originalFailurePreserved=True,noWorkersOrGuestFixtures=True,archivedAndVerifiedUnderLease=True,archiveSHA256=hashlib.sha256((root/'failed-observations.tgz').read_bytes()).hexdigest())
 (root/'failed-archive-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
 print(journal.stdout[-6500:]);print(json.dumps(receipt))
