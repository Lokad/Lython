from pathlib import Path
import json,os,subprocess
r=Path(__file__).parent;old=r.parent/'builtin-methods-r41'
env=os.environ.copy();env['DOTNET_ROOT']='C:/Users/JoannesVermorel/.dotnet11';env['DOTNET_HOST_PATH']=env['DOTNET_ROOT']+'/dotnet.exe';env['PATH']=env['DOTNET_ROOT']+os.pathsep+env['PATH']
with (r/'census-build.log').open('w',encoding='utf-8') as log:
 done=subprocess.run([env['DOTNET_HOST_PATH'],'build',str(r/'census/census.csproj'),'-c','Release','--nologo','-v','quiet'],env=env,stdout=log,stderr=subprocess.STDOUT)
assert done.returncode==0,(r/'census-build.log').read_text(encoding='utf-8')[-2000:]
for label in ['before','candidate']:
 done=subprocess.run([env['DOTNET_HOST_PATH'],str(r/'census/bin/Release/net11.0/census.dll'),str(r/'images'/label/'Lokad.Lython.dll'),str(r/'catalog.json'),str(r/('census-'+label+'.json'))],env=env,capture_output=True,text=True,encoding='utf-8')
 (r/('census-'+label+'.stderr')).write_text(done.stderr,encoding='utf-8')
 assert done.returncode==0,done.stderr[-2500:]
 print('compile-only census',label,'complete',flush=True)
for phase,api in [('warm','sync'),('warm','async'),('compile','sync')]:
 folder=r/(phase+'-'+api);folder.mkdir()
 witness=folder/'hash-witness.json'
 witness.write_text(json.dumps(dict(source="return [hash('Lython-é😀'), hash((1, 2.0, True))]\n"),ensure_ascii=False)+'\n',encoding='utf-8',newline='\n')
 with (folder/'measurements.json').open('w',encoding='utf-8') as output,(folder/'stderr.txt').open('w',encoding='utf-8') as errors:
  done=subprocess.run([env['DOTNET_HOST_PATH'],str(old/'tool/out/complete-jobs.dll'),str(r/'images/before/Lokad.Lython.Benchmarks.dll'),str(r/'images/candidate/Lokad.Lython.Benchmarks.dll'),str(r/'catalog.json'),str(witness),'reverse',phase,api],env=env,stdout=output,stderr=errors)
 assert done.returncode==0,(folder/'stderr.txt').read_text(encoding='utf-8')[-3000:]
 data=json.loads((folder/'measurements.json').read_text(encoding='utf-8'))
 assert all(data[k] for k in ['allGoldensPassed','allBalancesZero','ownedFixturesRemoved','imageIsolationVerified'])
 print(phase,api,'all complete-job goldens, balances, image isolation and fixture cleanup pass',flush=True)
