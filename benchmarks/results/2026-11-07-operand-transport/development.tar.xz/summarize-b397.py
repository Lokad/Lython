from pathlib import Path
r=Path(__file__).parent
source=(r.parent/'builtin-methods-r41/summarize-b394.py').read_text(encoding='utf-8')
source=source.replace("'b394/retrieved/confirmation/confirmation.json'","'b397/retrieved/confirmation/confirmation.json'").replace("'refined-comparison-summary.json'","'comparison-summary.json'")
exec(compile(source,str(r/'summary-command.py'),'exec'),{'__file__':str(r/'summary-command.py')})
