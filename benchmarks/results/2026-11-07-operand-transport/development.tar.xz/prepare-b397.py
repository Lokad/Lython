from pathlib import Path
import ast,hashlib,json,shutil,subprocess,tarfile,zipfile
home=Path(__file__).parent;r=home/'b397';r.mkdir()
old=home.parent/'builtin-methods-r41/b394'
old_remote='/home/lokad/lython-bench-checks/receiver-methods-b394-20261107'
remote='/home/lokad/lython-bench-checks/operand-transport-b397-20261107'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
checks=json.loads((home/'final-focused.json').read_text(encoding='utf-8'))
assert len(checks['checks'])==4 and len(checks['coreSHA256'])==2
candidate=home/'final/net11.0/Lokad.Lython.dll';assert sha(candidate)==checks['coreSHA256']['net11.0']
baseline=json.loads((home/'before.json').read_text(encoding='utf-8'))
identity=json.loads((old/'identity.json').read_text(encoding='utf-8'))
assert identity['coreSHA256']['candidate']==baseline['coreSHA256']['net11.0']
identity.update(sourceRevision='58d14512 plus R43 operand transport and 32-byte metadata refinement; frozen'+sha(candidate),
 purpose='R43 coherent ordinary-operation operand transport, text warm/fresh plus CSV/JSON/report controls',qualification=checks,
 productionSources={str(p):sha(p) for p in Path('src/Lokad.Lython').rglob('*') if p.suffix in ['.cs','.csproj'] and not any(x in p.parts for x in ['obj','bin'])},
 originalComparison='Initial40-byte metadata prototype, adverse desktop timings, compiler allocation and cold-span capacity costs preserved locally; no initial quiet comparison.')
identity['coreSHA256']={'reference':baseline['coreSHA256']['net11.0'],'reference-control':baseline['coreSHA256']['net11.0'],'candidate':sha(candidate),'control':sha(candidate)}
(r/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8',newline='\n')
shutil.copy2(home/'catalog.json',r/'representative.json')
jobs=[('scripts.text-summary-helpers.large','warm'),('scripts.text-summary-helpers.large','fresh'),('scripts.csv-summary-functions.large','warm'),('scripts.json-summary-helpers.large','warm'),('scripts.report-render.large','warm')]
for name in ['collect.py','archive-owned.py','run.sh']:
 s=(old/name).read_text(encoding='utf-8').replace(old_remote,remote)
 if name=='collect.py':
  start=s.index('jobs=[');end=s.index('\nassert len(jobs)',start)
  s=s[:start]+'jobs='+repr(jobs)+s[end:]
  s=s.replace('assert len(jobs)==4','assert len(jobs)==5').replace("time.monotonic()-started < 170, 'Reserve40", "time.monotonic()-started < 200, 'Reserve40")
  s=s.replace('R41 complete regex extraction and JSON/text/CSV controls; two baseline/two current','R43 text warm/fresh and CSV/JSON/report controls; two baseline/two current')
 if name=='archive-owned.py':
  s=s.replace("len(r['jobs'])==4","len(r['jobs'])==5").replace('jobs=4','jobs=5')
  s=s.replace("'receiver-method-source.cs','receiver-method-tests.cs'","'source-current.zip','focused.json'")
 (r/name).write_text(s,encoding='utf-8',newline='\n')
contract='''R43 extends existing indexed inputs instead of a new operand framework. Fold only adjacent pure uncaptured/nonmirrored local/constant leaves; retain checked read spans, evaluation order, alias identity and native-body preparation. One physical-layout pass replaces initialized-local tracking and retained temporary gaps. Consolidate operation input snapshots and value/store handling. The initial40-byte instruction and unstable desktop/compile-allocation results are preserved; refine redundant subscript-store result metadata into the third input so every instruction remains32bytes. Context promotion has no guest/admission hook; raw type getters reuse existing funded scratch. Remove the prototype snapshot cache/cleanup hooks/64-byte frame charge before this comparison. Workspace remains call-dominated. Actual11/10 focused semantic/ownership/cancellation checks must pass before launch; full delivery pending. Existing complete scripts/workers, normal optional0.4 and .NET11RC3/GC/tiering. Text warm/fresh plus CSV/JSON/report warm; two old/two current processes,5s warmup/role/job,7rotated150ms rounds. Timed public commands include mediated RAM file I/O, full aggregation/goldens and prior-result cleanup; fresh adds compile/program disposal. Startup/staging/reset/final cached teardown excluded. Require Ready/core/aux/golden/budget/quiet/Closed/join/archive gates.240s owner+30s stop+30s margin; observe after300s, never restart on observation timeout. Preserve adverse controls; distinguish simplification/metadata/allocation/elapsed/CPU and decide completion/regression debt for the entire phase. No primary CPython refresh yet; publication/tagging postponed.'''
(r/'contract.md').write_text(contract+'\n',encoding='utf-8',newline='\n')
(r/'setup-contract.json').write_text(json.dumps(dict(referenceTemplate=old_remote+'/candidate',roles=['candidate','reference','control','reference-control'],ownerSeconds=240,stopSeconds=30,observeAfterSeconds=300,jobs=jobs),indent=2)+'\n',encoding='utf-8')
shutil.copy2('PLAN.md',r/'pre-measurement-plan.md');shutil.copy2(home/'final-focused.json',r/'focused.json')
(r/'source.patch').write_bytes(subprocess.check_output(['git','-c','core.autocrlf=false','diff','--','src','tests']))
with zipfile.ZipFile(r/'source-current.zip','x',zipfile.ZIP_DEFLATED) as a:
 for p in identity['productionSources']:a.write(p,p)
for name in ['collect.py','archive-owned.py']:ast.parse((r/name).read_text(encoding='utf-8'))
with tarfile.open(r/'payload.tgz','w:gz') as t:
 for name in ['identity.json','representative.json','collect.py','archive-owned.py','run.sh','contract.md','pre-measurement-plan.md','setup-contract.json','source.patch','source-current.zip','focused.json']:t.add(r/name,arcname=name)
 t.add(candidate,arcname='current-core.dll')
s=(old/'launch.py').read_text(encoding='utf-8').replace(old_remote,remote).replace('receiver-methods-b393-20261107/reference','receiver-methods-b394-20261107/candidate')
s=s.replace('receiver-methods-b394-20261107','operand-transport-b397-20261107')
# The reference is the retained R41 image, not this newly created directory.
s=s.replace("reference=base/'operand-transport-b397-20261107/candidate'","reference=base/'receiver-methods-b394-20261107/candidate'")
s=s.replace('lython-b394-receiver-methods-20261107','lython-b397-operand-transport-20261107').replace('receiver-methods-b394-launch.py','operand-transport-b397-launch.py')
s=s.replace('len(jobs)==4','len(jobs)==5').replace("len(r['jobs'])==4","len(r['jobs'])==5")
s=s.replace('allFourJobsValidated','allFiveJobsValidated').replace('ownerSeconds=210','ownerSeconds=240').replace('marginSeconds=40','marginSeconds=30').replace('RuntimeMaxSec=210','RuntimeMaxSec=240').replace('seconds=280','seconds=300')
ast.parse(s);(r/'launch.py').write_text(s,encoding='utf-8',newline='\n')
s=(home.parent/'builtin-methods-r41/retrieve-b394.py').read_text(encoding='utf-8')
s=s.replace("Path(__file__).resolve().parent/'b394'","Path(__file__).resolve().parent/'b397'").replace(old_remote,remote).replace('lython-b394-receiver-methods-20261107','lython-b397-operand-transport-20261107').replace("status['receipt']['jobs']==4","status['receipt']['jobs']==5")
ast.parse(s);(home/'retrieve-b397.py').write_text(s,encoding='utf-8',newline='\n')
print('Prepared B397: five jobs, one240s owner/30s stop/30s margin; no measurement launched.')
