from pathlib import Path
import hashlib,json,shlex,subprocess,tarfile
r=Path(__file__).parent/'b397'
status=json.loads((r/'terminal-status.json').read_text());assert status['exitCode']=='1' and not status['remainingWorkers'] and not status['remainingFixtures']
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
script=r'''from pathlib import Path
import fcntl,hashlib,json,subprocess,tarfile
root=Path('/home/lokad/lython-bench-checks/operand-transport-b397-20261107')
with (root.parent/'comparison-vm.lock').open('a') as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert not list(Path('/dev/shm').glob('lython-comparison-files-*'))
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record'],capture_output=True).returncode==1
 journal=subprocess.run(['journalctl','-u','lython-b397-operand-transport-20261107.service','--no-pager','-n','65','-o','cat'],capture_output=True,text=True)
 (root/'failure-journal.txt').write_text(journal.stdout+journal.stderr)
 with tarfile.open(root/'failed-observations.tgz','w:gz') as t:
  for name in ['confirmation','identity.json','representative.json','collect.py','cpython-worker.py','pre-measurement-plan.md','setup-contract.json','source.patch','contract.md','started.utc','stopped.utc','exit-code.txt','run.sh','archive-owned.py','source-current.zip','focused.json','failure-journal.txt']:
   if (root/name).exists():t.add((root/name).resolve(),arcname=name)
 with tarfile.open(root/'failed-observations.tgz') as t:assert t.getmember('failure-journal.txt').size>0
 receipt=dict(complete=False,originalFailurePreserved=True,noWorkersOrGuestFixtures=True,archivedAndVerifiedUnderLease=True,archiveSHA256=hashlib.sha256((root/'failed-observations.tgz').read_bytes()).hexdigest())
 (root/'failed-archive-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
 print(journal.stdout[-6500:]);print(json.dumps(receipt))
'''
(r/'archive-failure-command-v2.py').write_text(script,encoding='utf-8',newline='\n')
done=subprocess.run([*ssh,'python3 -'],input=script,text=True,encoding='utf-8',capture_output=True)
(r/'archive-failure-v2.log').write_text(done.stdout+done.stderr,encoding='utf-8');print(done.stdout+done.stderr,flush=True);assert done.returncode==0
scp=['C:/Windows/System32/OpenSSH/scp.exe','-i',ssh[2],'-o','BatchMode=yes','-o','ConnectTimeout=15']
for name in ['failed-observations.tgz','failed-archive-receipt.json']:
 done=subprocess.run([*scp,'lokad@20.166.121.73:/home/lokad/lython-bench-checks/operand-transport-b397-20261107/'+name,str(r/name)],capture_output=True,text=True,encoding='utf-8');assert done.returncode==0,done.stderr
receipt=json.loads((r/'failed-archive-receipt.json').read_text());assert hashlib.sha256((r/'failed-observations.tgz').read_bytes()).hexdigest()==receipt['archiveSHA256']
target=r/'retrieved-failure';target.mkdir()
with tarfile.open(r/'failed-observations.tgz') as t:t.extractall(target,filter='data')
print('Original failed conditions archived and verified; terminal status not queried again.')
