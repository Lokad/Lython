from pathlib import Path
import hashlib,json,os,shutil,subprocess
r=Path(__file__).parent;old=r.parent/'builtin-methods-r41'
env=os.environ.copy();env['DOTNET_ROOT']='C:/Users/JoannesVermorel/.dotnet11';env['DOTNET_HOST_PATH']=env['DOTNET_ROOT']+'/dotnet.exe';env['PATH']=env['DOTNET_ROOT']+os.pathsep+env['PATH']
checks=json.loads((r/'final-focused.json').read_text());assert len(checks['checks'])==4
shutil.copytree(r/'images/candidate',r/'images/final');shutil.copy2(r/'final/net11.0/Lokad.Lython.dll',r/'images/final/Lokad.Lython.dll')
assert hashlib.sha256((r/'images/final/Lokad.Lython.dll').read_bytes()).hexdigest()==checks['coreSHA256']['net11.0']
done=subprocess.run([env['DOTNET_HOST_PATH'],str(r/'census/bin/Release/net11.0/census.dll'),str(r/'images/final/Lokad.Lython.dll'),str(r/'catalog.json'),str(r/'census-final.json')],env=env,capture_output=True,text=True,encoding='utf-8')
(r/'census-final.stderr').write_text(done.stderr,encoding='utf-8');assert done.returncode==0,done.stderr[-2000:]
folder=r/'final-compile-sync';folder.mkdir();witness=folder/'hash-witness.json'
shutil.copy2(r/'compile-sync/hash-witness.json',witness)
with (folder/'measurements.json').open('w',encoding='utf-8') as out,(folder/'stderr.txt').open('w',encoding='utf-8') as err:
 done=subprocess.run([env['DOTNET_HOST_PATH'],str(old/'tool/out/complete-jobs.dll'),str(r/'images/before/Lokad.Lython.Benchmarks.dll'),str(r/'images/final/Lokad.Lython.Benchmarks.dll'),str(r/'catalog.json'),str(witness),'reverse','compile','sync'],env=env,stdout=out,stderr=err)
assert done.returncode==0,(folder/'stderr.txt').read_text(encoding='utf-8')[-2500:]
data=json.loads((folder/'measurements.json').read_text());assert all(data[k] for k in ['allGoldensPassed','allBalancesZero','ownedFixturesRemoved','imageIsolationVerified'])
print('Final32-byte source census and separate compilation-allocation diagnostic complete; goldens/funding/cleanup pass.')
