from pathlib import Path
import hashlib,json,shutil
r=Path(__file__).parent
assert not (r/'diagnostic-identity.json').exists(),'Do not overwrite frozen evidence.'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
focused=json.loads((r/'focused.json').read_text(encoding='utf-8'))
assert len(focused['checks'])==4 and len(focused['coreSHA256'])==2
baseline=json.loads((r/'before.json').read_text(encoding='utf-8'))
old=r.parent/'builtin-methods-r41'
assert sha(old/'images/refined/Lokad.Lython.dll')==baseline['coreSHA256']['net11.0']
for label in ['before','candidate']:
 shutil.copytree(old/'images/refined',r/'images'/label)
 if label=='candidate':shutil.copy2(r/'initial/net11.0/Lokad.Lython.dll',r/'images'/label/'Lokad.Lython.dll')
 assert sha(r/'images'/label/'Lokad.Lython.dll')==(baseline if label=='before' else focused)['coreSHA256']['net11.0']
catalog=json.loads((r.parent/'annotation-demand-r38/catalog.json').read_text(encoding='utf-8'))
ids=['scripts.text-summary-helpers.large','scripts.csv-summary-functions.large','scripts.json-summary-helpers.large','scripts.report-render.large']
catalog['cases']=[next(c for c in catalog['cases'] if c['id']==name) for name in ids]
(r/'catalog.json').write_text(json.dumps(catalog,indent=2,ensure_ascii=False)+'\n',encoding='utf-8',newline='\n')
project=r/'census';project.mkdir()
prior=r.parent/'text-cost-r42/census'
shutil.copy2(prior/'census.csproj',project/'census.csproj')
s=(prior/'Program.cs').read_text(encoding='utf-8')
s=s.replace('var cases = new List<object>();','''long Stride(Type type)
{
    _ = Array.CreateInstance(type, 1);
    var start = GC.GetAllocatedBytesForCurrentThread();
    var small = Array.CreateInstance(type, 4096);
    var middle = GC.GetAllocatedBytesForCurrentThread();
    var large = Array.CreateInstance(type, 8192);
    var end = GC.GetAllocatedBytesForCurrentThread();
    GC.KeepAlive(small); GC.KeepAlive(large);
    return ((end-middle)-(middle-start))/4096;
}
var instructionStride = Stride(core.GetType("Lokad.Lython.Frontend.ExecutableInstruction", true)!);
var spanType = core.GetType("Lokad.Lython.Frontend.ExecutableOperandSpan", false);
var spanStride = spanType is null ? 0 : Stride(spanType);
var cases = new List<object>();''')
s=s.replace('var operations = new List<object>();','''var readSpans = code.GetType().GetField("_operandReadSpans", Flags)?.GetValue(code) as Array;
        var operations = new List<object>();''')
s=s.replace('instructionCount = counts.Values.Sum(), operandCapacity', '''instructionBytesPerElement = instructionStride,
            coldReadSpanCount = readSpans?.Length ?? 0, coldReadSpanBytesPerElement = spanStride,
            instructionAndReadSpanPayloadBytes = counts.Values.Sum()*instructionStride+(readSpans?.Length ?? 0)*spanStride,
            instructionCount = counts.Values.Sum(), operandCapacity''')
(project/'Program.cs').write_text(s,encoding='utf-8',newline='\n')
identity=dict(purpose='R43 coherent operand transport prototype; no elapsed qualification yet',baseline=baseline['coreSHA256'],candidate=focused['coreSHA256'],
 productionSources={str(p):sha(p) for p in Path('src/Lokad.Lython').rglob('*') if p.suffix in ['.cs','.csproj'] and not any(x in p.parts for x in ['obj','bin'])},
 worker=sha(old/'tool/out/complete-jobs.dll'),catalog=sha(r/'catalog.json'),fullDeliveryPending=True)
(r/'diagnostic-identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8',newline='\n')
print('Frozen initial R43 images, reused complete-job driver and four maintained sources; census prepared. No measurements yet.')
