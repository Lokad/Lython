from pathlib import Path
r=Path(__file__).parent
s=(r/'qualify.py').read_text(encoding='utf-8').replace("r/'focused.json'","r/'final-focused.json'").replace("r/'initial'","r/'final'").replace("name=project+","name='final-'+project+")
start=s.index('filters={');end=s.index('\nchecks={}',start)
filters={
 'Lokad.Lython.Tests':'Category!=Stress&('+'|'.join('FullyQualifiedName~'+n for n in ['DirectOperandOwnership','InstructionFailureRouting','LocalAugmentedLifetime','NestedFrameLifetime','CompletedHelperCallOwnership','AsyncExecutableFunction','SimpleFunctionExecutionBoundary','ExecutableOperandStackBoundary','LoweringArchitectureSubsystem'])+')',
 'Lokad.Lython.PublicApi.Tests':'Category!=Stress&('+'|'.join('FullyQualifiedName~'+n for n in ['ClassSubscription','OperandReadFailure','NativeCallback','ReceiverMethodSemantics','Cancellation'])+')'}
s=s[:start]+'filters='+repr(filters)+s[end:]
exec(compile(s,str(r/'final-qualification-command.py'),'exec'),{'__file__':str(r/'final-qualification-command.py')})
