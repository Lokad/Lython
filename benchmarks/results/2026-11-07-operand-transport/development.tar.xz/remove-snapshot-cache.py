from pathlib import Path
import hashlib,json,zipfile
r=Path(__file__).parent
paths=list(Path('src/Lokad.Lython').rglob('*.cs'))
with zipfile.ZipFile(r/'source-metadata-refined.zip','x',zipfile.ZIP_DEFLATED) as a:
 for p in paths:
  if not any(x in p.parts for x in ['obj','bin']):a.write(p,p)
p=Path('src/Lokad.Lython/Runtime/LythonRuntime.Executable.Inputs.cs');s=p.read_text(encoding='utf-8')
start=s.index('        private static ExecutableInputs ReadInstructionInputs(')
end=s.index('        // Keep transient guest references',start)
s=s[:start]+'''        private static ExecutableInputs ReadInstructionInputs(ref ExecutableWorkState execution,
            in ExecutableInstruction instruction, ExecutionContext scope, ExecutionContext? invocation)
        {
            // A descriptor getter already retained the original type/key in
            // the existing funded protocol slots. Its callback may rebind locals;
            // the resumed lookup must consume these snapshots, not those locals.
            if (instruction.OpCode == ExecutableOpCode.Subscript && invocation?._preparedCallValue is not null)
                return new(execution.Stack[instruction.ResultSlot], execution.Stack[instruction.ResultSlot + 1]);
            return new(ReadOperand(ref execution, instruction.InputStart, scope, 0),
                instruction.ValueInputCount > 1 ? ReadOperand(ref execution, instruction.SecondInput, scope, 1) : null,
                instruction.ValueInputCount == 3 ? ReadOperand(ref execution, instruction.ThirdInput, scope, 2) : null);
        }

'''+s[end:]
s=s.replace('''        // Only genuine admission/protocol pauses retain inputs in the work state.''','''        // Genuine async work captures its values; raw type protocols use the
        // existing stack scratch. Context promotion runs no guest/admission hook.''')
s=s.replace('ReadInstructionInputs(ref execution, instruction, scope);','ReadInstructionInputs(ref execution, instruction, scope, invocation);')
s=s.replace('                            PreserveInstructionInputs(ref execution, inputs);\n','').replace('                    PreserveInstructionInputs(ref execution, inputs);\n','')
s=s.replace('                        ClearInstructionInputs(ref execution);\n','').replace('                    ClearInstructionInputs(ref execution);\n','').replace('                ClearInstructionInputs(ref execution);\n','')
assert 'PreserveInstructionInputs' not in s and 'ClearInstructionInputs' not in s
p.write_text(s,encoding='utf-8',newline='\n')
for p in Path('src/Lokad.Lython/Runtime').glob('LythonRuntime.Executable*.cs'):
 if p.name=='LythonRuntime.Executable.Inputs.cs':continue
 s=p.read_text(encoding='utf-8')
 s=s.replace('            ClearInstructionInputs(ref _execution);\n','')
 # Removing the sole body also removes this condition.
 s=s.replace('            if (completion is CallCompletion.TypeGetter or CallCompletion.TypeSubscription)\n','')
 s=s.replace('        internal ExecutableInputs DeferredInputs;\n        internal int DeferredInputIndex;\n','')
 s=s.replace('            DeferredInputs = default;\n            DeferredInputIndex = 0;\n','')
 s=s.replace('''        // Fund the inline captured-input metadata and adoption overlap with the
        // same workspace owner; it is not another allowance or per-value ledger.
        long bytes = checked(64L + (long)codeObject.PatternStorageCount * RuntimeMemoryEstimates.ScalarStorageBytes);''','''        long bytes = (long)codeObject.PatternStorageCount * RuntimeMemoryEstimates.ScalarStorageBytes;''')
 original=p.read_text(encoding='utf-8')
 if s!=original:p.write_text(s,encoding='utf-8',newline='\n')
print('Removed prototype frame cache, index, cleanup hooks and64-byte charge. Type getter snapshots reuse existing funded scratch.')
