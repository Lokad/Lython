# R43 ordinary-operation input transport

Selected extension to existing indexed inputs/ForwardValues, not a new calling or
value framework. See ignored PLAN for concrete deletion/replacement/semantic gates.
Baseline fully qualifiedfba865ef, metadata HEAD58d14512, frozen5d2ca8e1/2aefaa39.
One R42 profile:1089samples/44unknown,229prefix self; no saved CPU percentage.
Preserve original spans/read order and snapshots before admission, raw type protocol
and real async callbacks; managed stack/cancellation/first refusal/owners/cleanup.
New metadata footprint and unchanged call-dominated capacity must be explicit.
No primary CPython refresh or full delivery repeat before a retained coherent phase.
