from pathlib import Path
import hashlib,json,shutil,subprocess,zipfile
r=Path(__file__).parent;root=Path('D:/code/Lython');baseline=r/'baseline';baseline.mkdir()
checks=json.loads((r.parent/'builtin-methods-r41/refined-focused.json').read_text(encoding='utf-8'))
for name,digest in checks['productionSources'].items():
    assert hashlib.sha256((root/name).read_bytes()).hexdigest()==digest,name
cores={}
for target in ['net11.0','net10.0']:
    source=root/f'src/Lokad.Lython/bin/Release/{target}/Lokad.Lython.dll'
    digest=hashlib.sha256(source.read_bytes()).hexdigest();assert digest==checks['coreSHA256'][target]
    dest=baseline/target;dest.mkdir();shutil.copy2(source,dest/source.name);cores[target]=digest
with zipfile.ZipFile(r/'source-before.zip','w',compression=zipfile.ZIP_DEFLATED) as z:
    for file in (root/'src/Lokad.Lython').rglob('*'):
        if file.is_file() and not {'bin','obj'}.intersection(file.parts):z.write(file,file.relative_to(root).as_posix())
manifest=dict(productionSource='fba865ef78ea91a5fdcdb39cd138d88125d7b22a',metadataHead=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),
    qualification='Terminal GREEN42357660230, Windows/Ubuntu actual.NET11/10, original Stress and installed consumers; no requery.',
    coreSHA256=cores,productionSources=checks['productionSources'],sourceZipSHA256=hashlib.sha256((r/'source-before.zip').read_bytes()).hexdigest())
(r/'before.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8',newline='\n')
plan=Path('PLAN.md');s=plan.read_text(encoding='utf-8');a=s.index('- Hypothesis/affected work:')
proposal='''- **Selected representation/replacement, before prototype:**extend existing integer
  input sources/ForwardValues rather than a second operand framework. Constants
  stay complemented indices; locals/temporaries keep existing index domains. Add
  a third source for subscript stores and sparse cold source-span records for
  folded checked local reads. Ordinary hot reads allocate nothing; missing bindings
  use their original leaf span. Preserve native-body preparation unchanged.
- Delete the old per-block initialized-local tracking/invalidations where checked
  source reads replace that proof. Fold only adjacent plain uncaptured/nonmirrored
  local/constant reads inside one block; dynamic/closure/retained-target reads stay.
  Recompute stack effects, positions/capacity/owned-temp extent and region depths
  after folding, replacing today's retained physical gaps. Account for type-
  subscription protocol scratch; calls may still dominate capacity.
- Consolidate repeated operand reads/native classification in the existing ordinary
  value-operation path. Snapshot values once before any protocol or frame admission.
  A small inline pending-input value in the existing work state survives genuine
  context promotion/raw type-subscription suspension; no caller arena or synthetic
  completion phase. Clear it on completion, handled errors and detachment before
  owner refund. Keep transient references outside the long dispatch loop, preserving
  the measured lifetime fences. Async work receives captured values, not reread slots.
- Footprint tradeoff:third index can enlarge instructions; sparse spans and pending
  frame metadata also cost storage. Measure actual compile/allocation effects and
  fund conservative major capacity/overlap through existing owners. No new allowance,
  ledger, pool, tracing or policy. Delete displaced routing/tracking at completion,
  while preserving actual general executable reads and native proofs.
'''
s=s[:a]+proposal+s[a:]
s=s.replace('no runtime prototype yet. Publication remains postponed; objective stays active.', 'baseline source/images frozen; selected coherent prototype starts next.\nPublication remains postponed; objective stays active.')
s=s.replace('No active CI, local build/test/measurement or VM collection. Fully qualified source', 'R43 baseline source/images frozen; selected prototype begins. No active CI/test/VM\ncollection or new timing. Fully qualified source')
plan.write_text(s,encoding='utf-8',newline='\n')
(r/'source-contract.md').write_text('''# R43 ordinary-operation input transport

Selected extension to existing indexed inputs/ForwardValues, not a new calling or
value framework. See ignored PLAN for concrete deletion/replacement/semantic gates.
Baseline fully qualifiedfba865ef, metadata HEAD58d14512, frozen5d2ca8e1/2aefaa39.
One R42 profile:1089samples/44unknown,229prefix self; no saved CPU percentage.
Preserve original spans/read order and snapshots before admission, raw type protocol
and real async callbacks; managed stack/cancellation/first refusal/owners/cleanup.
New metadata footprint and unchanged call-dominated capacity must be explicit.
No primary CPython refresh or full delivery repeat before a retained coherent phase.
''',encoding='utf-8',newline='\n')
print('R43 concrete replacement recorded; current source/images frozen; no runtime mutation yet.')
