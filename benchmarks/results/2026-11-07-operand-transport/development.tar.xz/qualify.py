from pathlib import Path
import hashlib,json,os,re,shutil,subprocess
r=Path(__file__).parent
env=os.environ.copy();env['DOTNET_ROOT']='C:/Users/JoannesVermorel/.dotnet11';env['DOTNET_HOST_PATH']=env['DOTNET_ROOT']+'/dotnet.exe';env['PATH']=env['DOTNET_ROOT']+os.pathsep+'C:/Python313'+os.pathsep+env['PATH']
filters={
 'Lokad.Lython.Tests':'Category!=Stress&('+'|'.join('FullyQualifiedName~'+name for name in ['Executable','Instruction','Local','Subscript','Stack','Return','Header','Subscription','Admission','DirectOperandOwnership','Closure','Generator','CallArgumentEvaluation'])+')',
 'Lokad.Lython.PublicApi.Tests':'Category!=Stress&('+'|'.join('FullyQualifiedName~'+name for name in ['OperandReadFailure','ClassSubscription','Closure','Generator','Exception','Assignment','Augmented','Subscript','NativeCallback','ReceiverMethodSemantics','FunctionCall','Comprehension','Cancellation','Admission'])+')'}
checks={};cores={}
for target in ['net11.0','net10.0']:
 for project,selection in filters.items():
  name=project+'-'+target+'.log'
  with (r/name).open('w',encoding='utf-8') as log:
   done=subprocess.run([env['DOTNET_HOST_PATH'],'test',f'tests/{project}/{project}.csproj','-c','Release','-f',target,'--filter',selection,'--nologo','-v','quiet'],env=env,stdout=log,stderr=subprocess.STDOUT)
  result=(r/name).read_text(encoding='utf-8-sig');summaries=re.findall(r'Passed!.*',result)
  checks[name]=dict(exitCode=done.returncode,selection=selection,summaries=summaries)
  print(target,project,done.returncode,summaries[-1:] or result[-2500:],flush=True)
  (r/'focused.json').write_text(json.dumps(dict(checks=checks,fullDeliveryPending=True),indent=2)+'\n',encoding='utf-8')
  if done.returncode or not summaries:raise SystemExit(1)
 p=Path('src/Lokad.Lython/bin/Release',target,'Lokad.Lython.dll')
 cores[target]=hashlib.sha256(p.read_bytes()).hexdigest()
 (r/'initial'/target).mkdir(parents=True,exist_ok=True)
 shutil.copy2(p,r/'initial'/target/p.name)
(r/'focused.json').write_text(json.dumps(dict(checks=checks,coreSHA256=cores,fullDeliveryPending=True),indent=2)+'\n',encoding='utf-8')
