from pathlib import Path
import hashlib,json,shutil,subprocess,tarfile
r=Path(__file__).parent;out=Path('benchmarks/results/2026-11-07-operand-transport');out.mkdir()
for name in ['final-local-summary.json','initial-local-summary.json','final-focused.json','refined-focused.json','focused.json','delivery-focused.json','post-freeze-source-cleanup.json']:
 shutil.copy2(r/name,out/name)
for tag,archive,receipt,status in [('b397','failed-observations.tgz','failed-archive-receipt.json','terminal-status.json'),('b398','observations.tgz','archive-receipt.json','terminal-status.json')]:
 target=out/tag;target.mkdir()
 for name in [archive,receipt,status]:shutil.copy2(r/tag/name,target/name)
 d=json.loads((target/receipt).read_text());assert hashlib.sha256((target/archive).read_bytes()).hexdigest()==d['archiveSHA256']
shutil.copy2(r/'corrected-comparison-summary.json',out/'comparison-summary.json')
(r/'delivery-source.patch').write_bytes(subprocess.check_output(['git','-c','core.autocrlf=false','diff','--','src','tests','docs']))
identity=json.loads((r/'b398/identity.json').read_text())
identity.update(deliveryProductionSources={p:hashlib.sha256(Path(p).read_bytes()).hexdigest() for p in identity['productionSources']},
 deliveryCoreSHA256=json.loads((r/'delivery-focused.json').read_text())['coreSHA256'],
 limitation='Frozen8b5ce5bc/ed80f283 timed; delivery9eb7a6b5/7fe742dc restores original checked workspace arithmetic and removes dangling prototype comments. Source cleanup is explicit, no binary-equivalence claim. Focused delivery70internal/47public per actual target passes; full CI pending.')
(out/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8')
with tarfile.open(out/'development.tgz','w:gz') as a:
 for p in r.iterdir():
  if p.is_file() and p.suffix in ['.py','.json','.md','.cs','.log','.stderr','.zip','.patch']:a.add(p,arcname=p.name)
 for folder in ['baseline','initial','refined','final']:
  for p in (r/folder).rglob('Lokad.Lython.dll'):a.add(p,arcname=p.relative_to(r))
 for folder in ['warm-sync','warm-async','compile-sync','final-compile-sync']:
  for p in (r/folder).iterdir():
   if p.is_file():a.add(p,arcname=p.relative_to(r))
 for name in ['Program.cs','census.csproj']:a.add(r/'census'/name,arcname='census/'+name)
 for tag in ['b397','b398']:
  for p in (r/tag).iterdir():
   if p.is_file() and p.suffix in ['.py','.json','.md','.log','.sh','.txt']:a.add(p,arcname=p.relative_to(r))
 for p in [Path('src/Lokad.Lython/Frontend/ExecutableScript.InputSpans.cs'),Path('src/Lokad.Lython/Runtime/LythonRuntime.Executable.Inputs.cs'),Path('tests/Lokad.Lython.Tests/DirectOperandOwnershipTests.cs')]:a.add(p,arcname='delivery-new-files/'+p.as_posix())
 for target in ['net11.0','net10.0']:a.add(Path('src/Lokad.Lython/bin/Release',target,'Lokad.Lython.dll'),arcname='delivery-images/'+target+'/Lokad.Lython.dll')
with tarfile.open(out/'development.tgz') as a:assert a.getmember('post-freeze-source-cleanup.json').size>0
print('Immutable local/VM evidence archived; development bytes', (out/'development.tgz').stat().st_size,'SHA256',hashlib.sha256((out/'development.tgz').read_bytes()).hexdigest())
