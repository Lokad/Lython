from pathlib import Path
import hashlib,json,os,subprocess
r=Path(__file__).parent
env=os.environ.copy();env['DOTNET_ROOT']='C:/Users/JoannesVermorel/.dotnet11';env['DOTNET_HOST_PATH']=env['DOTNET_ROOT']+'/dotnet.exe';env['PATH']=env['DOTNET_ROOT']+os.pathsep+env['PATH']
checks={};cores={}
for target in ['net11.0','net10.0']:
 with (r/('delivery-build-'+target+'.log')).open('w',encoding='utf-8') as log:
  done=subprocess.run([env['DOTNET_HOST_PATH'],'build','src/Lokad.Lython/Lokad.Lython.csproj','-c','Release','-f',target,'--no-incremental','--nologo','-v','quiet'],env=env,stdout=log,stderr=subprocess.STDOUT)
 assert done.returncode==0,target
 cores[target]=hashlib.sha256(Path('src/Lokad.Lython/bin/Release',target,'Lokad.Lython.dll').read_bytes()).hexdigest()
 for project,selection in [('Lokad.Lython.Tests','Category!=Stress&(FullyQualifiedName~DirectOperandOwnership|FullyQualifiedName~InstructionFailureRouting|FullyQualifiedName~LoweringArchitectureSubsystem|FullyQualifiedName~LocalAugmentedLifetime)'),('Lokad.Lython.PublicApi.Tests','Category!=Stress&(FullyQualifiedName~OperandReadFailure|FullyQualifiedName~ClassSubscription)')]:
  name='delivery-'+project+'-'+target+'.log'
  with (r/name).open('w',encoding='utf-8') as log:
   done=subprocess.run([env['DOTNET_HOST_PATH'],'test',f'tests/{project}/{project}.csproj','-c','Release','-f',target,'--no-dependencies','--filter',selection,'--nologo','-v','quiet'],env=env,stdout=log,stderr=subprocess.STDOUT)
  tail=(r/name).read_text(encoding='utf-8')[-1000:];print(target,project,done.returncode,tail[-500:],flush=True)
  checks[name]=dict(exitCode=done.returncode,selection=selection,summary=tail)
  assert done.returncode==0,tail
(r/'delivery-focused.json').write_text(json.dumps(dict(checks=checks,coreSHA256=cores,postFreezeCleanup=json.loads((r/'post-freeze-source-cleanup.json').read_text()),fullPlatformDeliveryPending=True),indent=2)+'\n',encoding='utf-8')
