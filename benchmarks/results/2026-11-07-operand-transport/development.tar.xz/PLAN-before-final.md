# Lokad.Lython 0.11.0

Updated2026-11-07. Git-ignored; never force-add. Publication/tagging postponed.
Objective: coherent simplification and substantial complete-script performance.
One completed experiment or delivery checkpoint does not complete this objective.

## Actual delivery status

- **Fully qualified through fba865ef:** terminal GREEN42357660230, Windows/Ubuntu
  Release, actual.NET11/10, original Stress both and installed package consumers.
  Includes retained R40 scalar cursor and R41 receiver-method consolidation, plus
  shared compiler-fact correction/direct UTF8/native helpers and prior R20–R38.
  Exact receipt beside R41 evidence; terminal runs never queried again.
- **R41 committed/pushedfba865ef:** immutable receiver implementations and borrowed
  operands replace ten markers, duplicate invocation chain/factories and ten orphaned
  guard helpers. Refinement deletes one-caller resolver/redundant no-argument tests.
  Frozen5d2ca8e1/2aefaa39 actual11/10; earlierbfc2e427/f848abe1/adverse controls stay.
  Native proofs, genuine suspension/current tokens, first refusal, aliases/defaults/
  metadata/evaluation order and budget reuse pass. No API break/publication.
- **R42 cost gate complete, no runtime prototype:** one text capture1089guest
  samples/5.49CPU seconds,44unknown. ExecuteInstructionPrefix229self/1056inclusive;
  self includes inlined checks/slot work. ScalarAdd41self is insufficient for a
  universal value rewrite. Source census:main85instructions,22local/constant loads,
  9operand slots, no mirroring; helper already native. New source/design boundary
  below; no repeated capture selected. All raw/code/failed extraction conditions
  archived separately under text-cost. No saved-CPU claim from inclusive totals.
- **Independent regex:** normal optional adapter remains nonpackable/pinned0.4,
  core decoupled. Immutabledev48/sourcef6b2175e previously passed85internal/488public
  per target on R30; not current-HEAD/final producer safety or CPU certification.
- **History:** benchmarks/EXPERIMENTS.md and immutable results hold full source pairs,
  failed conditions, refinements, adverse controls and rejected designs. No dormant
  routes/options remain for experiments. Slower call-arena/control lessons remain.

## Established measurements / debt

| Milestone | Established outcome | Limitation / decision |
| --- | --- | --- |
| Shared compiler facts | Shared inferred-value traversal fixes exponential work; fully qualified | Preserve callback correction; no warm CPU claim. |
| Native helper returns | Allocation−19.92/−19.31%; fully qualified | Earlier elapsed gains diagnostic, not transferable to HEAD. |
| Direct UTF8 formatting/storage | Allocation−8.67%; controlled B102 elapsed/CPU−5–8% supports retain | Original adverse15.125ms unexplained/preserved. |
| R20/R25 records | Shared keys/independent values; completed CSV arrays transfer. R25 allocation−7.31/−6.55%, native warm−7.72–8.04% | Selectively revisits old6–8% bulk rejection through coherent transfer. Coarse CPU/text controls mixed. |
| R29 calls | Synthetic native-helper completion phase removed; text warm−4.25–7.61%sync/−7.63–8.64%async vsR26 | Allocation flat; report/CSV uncertainty and older debt remain. |
| R30–R32 facts/layouts | Repeated class/parameter analysis/storage removed | Compilation storage grows; old moving text/CSV controls and adverse pairings remain debt. |
| R35 formatting | Dynamic complete report warm allocation~−15.35%, quiet elapsed−10.09–13.19% | Static warm favorable, fresh/text variable; CSV+0.13–2.36% accepted possible debt. Original B386/refinement preserved. |
| R38 annotation demand | Compile allocation−4.38–8.94%; report compile−6.51–8.02%, text−8.25–9.13%, config fresh−0.54–2.42% | Required full regex flow preserved after initial3failures; regex+304B/+0.117%, elapsed up to+1.66% accepted overhead. Warm text variable. Fully qualified. |
| R40 scalar cursor | Same0.4 backend: Unicode1,024warm−31.28–34.50%,4,096−65.54–68.53%,8,192−78.99–79.47%; allocation essentially flat/peaks identical | Growing-input diagnostic, not broad regex/isolated CPU/CPython claim. ASCII−0.16 to+6.31%/4.78%current spread, forward−3.38 to+2.96% variable; possible ASCII debt accepted. Full delivery green. |
| R41 receiver methods | Ten markers/guard helpers and migrated closures removed; allocation~−29.47% both APIs, refined regex warm−8.64–10.80% | JSON/text/CSV variable; original CSV+2.05–3.41% accepted possible debt. Full platform/Stress/package delivery green. |

Primary CPython checkpoint refreshed B395/exactfba865ef/frozen5d2ca8e1,15jobs311.66s/
all gates. Warm CSV1.19–1.23x,text1.75–1.79x,JSON1.04x,report1.36–1.38x,
config1.25xCPython3.13.16; compile42–68us separately. Fresh CSV1.21x,text1.71–1.74x,
JSON1.03–1.09x,report1.29–1.35x,config1.16–1.17x. docs/BENCHMARKS is authoritative.
Retain variable roles/IQR and B388 historicalsource42101. Includes RAM I/O/checks/
prior-result cleanup; fresh adds compile/program disposal. Excludes startup/staging/
reset/final cached teardown. No median subtraction/compound attribution/debt repayment.

## Priority 1 — coherent ordinary-operation operand transport (R43 prototype)

R42 identifies a material instruction/transport boundary, not a specific removable
CPU percentage. R37 still applies:leaf deletion alone may retain physical capacity
and needs error-span/snapshot metadata. Baseline source/images are frozen. The active
uncommitted prototype removes adjacent loads before one physical-layout pass,
replaces initialized-local tracking with checked reads and consolidates ordinary
value/store operand handling. Native helper preparation remains unchanged.
Publication remains postponed; objective stays active.

- **Selected representation/replacement:**extend existing integer
  input sources/ForwardValues rather than a second operand framework. Constants
  stay complemented indices; locals/temporaries keep existing index domains. Add
  a third source for subscript stores and sparse cold source-span records for
  folded checked local reads. Ordinary hot reads allocate nothing; missing bindings
  use their original leaf span. Preserve native-body preparation unchanged.
- Delete the old per-block initialized-local tracking/invalidations where checked
  source reads replace that proof. Fold only adjacent plain uncaptured/nonmirrored
  local/constant reads inside one block; dynamic/closure/retained-target reads stay.
  Recompute stack effects, positions/capacity/owned-temp extent and region depths
  after folding, replacing today's retained physical gaps. Account for type-
  subscription protocol scratch; calls may still dominate capacity.
- Consolidate repeated operand reads/native classification in the existing ordinary
  value-operation path. Snapshot values once before any protocol or frame admission.
  A small inline pending-input value in the existing work state survives genuine
  context promotion/raw type-subscription suspension; no caller arena or synthetic
  completion phase. Clear it on completion, handled errors and detachment before
  owner refund. Keep transient references outside the long dispatch loop, preserving
  the measured lifetime fences. Async work receives captured values, not reread slots.
- Footprint tradeoff:third index can enlarge instructions; sparse spans and pending
  frame metadata also cost storage. Measure actual compile/allocation effects and
  fund conservative major capacity/overlap through existing owners. No new allowance,
  ledger, pool, tracing or policy. Delete displaced routing/tracking at completion,
  while preserving actual general executable reads and native proofs.
- Hypothesis/affected work:replace adjacent pure local/constant push/dispatch with
  explicit ordinary-operation inputs across binary/comparison/subscript read/store
  families. Text count updates, CSV/JSON aggregation and small report/helper loops
  pay routing/slot retirement; all four maintained scripts are controls too.
- Source/deletion milestone:eligible reads occur once in Python order with original
  spans; remove their emitted load instructions, copies and temporary retirement
  route for those shapes. Recompute physical layout/capacity and account for new
  immutable metadata; report if workspace remains dominated by calls. Retain genuine
  snapshots, dynamic/name lookup and noneligible reads; no dormant alternate engine.
  Build on existing fused local stores/physical extents and exception regions.
- Preserve exact boxed/alias identity; do not introduce tagged values or a caller
  arena. Do not move reads across callbacks, allocation/admission, block/handler/
  suspension boundaries. Evaluate/capture all inputs before invoking protocols;
  hold original values/owners until actual users and awaited cleanup finish.
- Preserve managed stack/nesting, current cancellation on loops/long operations,
  terminal first refusal and native helper guards/fusion. Entry/operand/store failure
  spans and exception selection must remain Python-shaped. No unsafe/Unsafe/native
  probing, counters/fuel/policies, public switch or fallback backend.
- Acceptance before timing:unbound/lookup/type errors in order, argument/target
  rebinding, globals/cells/closures, custom add/index/set protocols with real I/O,
  cancellation/refusal during callbacks/admission, retained aliases, generators,
  exception/finally cleanup, budget baseline/reuse, native proofs. Compiler defects
  fail explicitly; unsupported optimization shapes keep ordinary executable code.
- Initial focused qualification found one obsolete load-shape assertion (corrected),
  with all other 1,106 internal cases passing. New three-input store regressions
  preserve aliases through rebinding/real suspension/cancellation/first refusal,
  stop publication and restore depths/balances. Expanded checks and actual11/10
  qualification are in progress; full delivery is pending. No speedup claim.
- Next: measure instruction count/physical capacity/cold metadata and short exact
  allocation and bounded quiet text warm/fresh plus CSV/JSON/report controls against
  frozenfba. Preserve all adverse outcomes; completion/debt decision for the whole
  phase, not a sequence of narrow shortcuts. No new CPython refresh until a coherent
  retained delivery checkpoint. Batch full delivery then continue remaining work.

| Further boundary | Evidence obligation / acceptance |
| --- | --- |
| Complete calls/frames | R39 CSV inclusive helper totals are useful work, not binding dominance. Direct operands/final slots/lazy contexts already exist; remove a real phase before another arena/design. |
| Scalars/text | R42 scalarAdd41self alone insufficient for universal tags. Preserve exact promotion/identity/Unicode/hash/index/owners; select complete phases from actual costs. |
| Per-record | Shared keys/R25CSV transfer and synchronous JSON already delivered. Remove an actual extra capacity/copy phase; retain hooks/order/reentry/aliases/overlap; withdrawn masks/windows need new evidence. |
| Frontend/setup | Shared lexical/class/parameter facts, shared-graph correction, R38 demand pruning/shared builtins/executable imports/prepared helpers exist. Remove actual duplicate work, preserving dead-scope regex diagnostics and fresh mutable state; compile measured separately. |

## Experimental policy

Timeouts, unstable unchanged controls and inconclusive observations mean uncertainty,
not permanent rejection. Allow bounded justified confirmation/refinement/measurement
correction, never repeated until favorable. Size for the quiet VM; preserve original
failed conditions/adverse results and source/image provenance. Fixed percentages
inform decisions, not automatic vetoes of useful simplification. Distinguish source
deletion, allocation, elapsed and CPU. Batch delivery checks at meaningful boundaries.

## Priority 2 — independent Lython regex architecture

Continue Lython-owned Python/nativeUTF8 semantics:byte ranges/scalar positions,
original windows, captures/replacements/errors/cache ownership and actual current-
token work. R40 projection and R41 method plumbing need no new producer release.
Development producers/adapter-local bridges support contract and semantic work;
missing published capabilities defer only affected final adapter qualification.

Missing capabilities:DetailedData has no independent Prepare working owner; native
names lack enumeration; cursors mix creation/current token authority. Exactdev48
adds no documented API removing these limits. Keep conservative preflight/local
conversion/qualified CTS bridge where needed; qualify released immutable inputs
and managed safety separately. No silent promotion, sibling edits, dialect fallback,
regex quotas, abandoned background work or dependence on producer publication.

## Constraints / current resources

AGENTS.md authoritative. Fully managed/memory-safe; no unsafe/Unsafe/pointers/PInvoke/
native probing. Managed stack/recursion, host mediation/contained paths, cycles,
current cancellation, coarse borrowed allowance/preflights/overlap, escaping aliases
and awaited users remain. First refused admission terminates the command. No tracing,
weak reclamation/forcedGC/fuel/quotas/caps/hidden allowance. Host-driven bounded batches;
XML depth constraint retained. No overlapping local builds/tests; preserve Stress.

R43 baseline source/images frozen; active uncommitted prototype, focused tests then
bounded allocation/census diagnostics. No active CI/VM collection. Fully qualified source
fba865ef; terminal CI42357660230 and earlier receipts cached, never query again.
B385–B396 terminal/archived; B395451d0667/B3965a609f1c independently verified,
all users joined/fixtures/RAM traces removed. VM lokad@20.166.121.73,key~/.ssh/id_lython-bench.pem.
After exact committed-backup checks, retired three c21core copies (R40archive197),
inactive initialbfc core (R41archivefba) and duplicate old checkout evidence (Gitda0ff).
Restore locations/hashes in receipts; current code/inputs and every original retained.
About89MB free at last setup; preflight future inputs/results. Persistent evidence;
archive/verify RAM under lease before removal. Record owner/stop/margin before
observing; never restart on observation timeout. Resume R43; no publication/tagging.
