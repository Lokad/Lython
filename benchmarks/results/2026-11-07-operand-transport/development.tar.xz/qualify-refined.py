from pathlib import Path
r=Path(__file__).parent
s=(r/'qualify.py').read_text(encoding='utf-8').replace("r/'focused.json'","r/'refined-focused.json'").replace("r/'initial'","r/'refined'").replace("name=project+","name='refined-'+project+")
exec(compile(s,str(r/'refined-qualification-command.py'),'exec'),{'__file__':str(r/'refined-qualification-command.py')})
