from pathlib import Path
import ast,json,shutil,tarfile
home=Path(__file__).parent;old=home/'b397';r=home/'b398';r.mkdir()
failure=json.loads((old/'terminal-status.json').read_text());assert failure['exitCode']=='1' and not failure['remainingWorkers'] and not failure['remainingFixtures']
receipt=json.loads((old/'failed-archive-receipt.json').read_text());assert receipt['archivedAndVerifiedUnderLease']
old_remote='/home/lokad/lython-bench-checks/operand-transport-b397-20261107';remote='/home/lokad/lython-bench-checks/operand-transport-b398-20261107'
for name in ['identity.json','representative.json','source.patch','source-current.zip','focused.json','pre-measurement-plan.md']:
 shutil.copy2(old/name,r/name)
identity=json.loads((r/'identity.json').read_text());identity['measurementCorrection']='B397 completed warm text then rejected unsupported fresh lane; original source, partial observations, full stderr, terminal cleanup and failure archive837f6923 preserved. Change only request lane to existing compile-run; do not infer design failure. B398 uses the identical frozen images/source, all five jobs/gates,180s owner+30s stop+30s margin.'
(r/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8')
for name in ['collect.py','archive-owned.py','run.sh','contract.md','setup-contract.json']:
 s=(old/name).read_text(encoding='utf-8').replace(old_remote,remote).replace("'fresh'","'compile-run'").replace('240s owner+30s stop+30s margin; observe after300s','180s owner+30s stop+30s margin; observe after240s')
 s=s.replace('time.monotonic()-started < 200', 'time.monotonic()-started < 140')
 if name=='setup-contract.json':
  d=json.loads(s);d.update(ownerSeconds=180,observeAfterSeconds=240);d['jobs']=[[case,'compile-run' if lane=='fresh' else lane]for case,lane in d['jobs']];s=json.dumps(d,indent=2)+'\n'
 (r/name).write_text(s,encoding='utf-8',newline='\n')
with tarfile.open(old/'payload.tgz') as a:
 core=a.extractfile('current-core.dll').read()
with tarfile.open(r/'payload.tgz','w:gz') as a:
 for name in ['identity.json','representative.json','collect.py','archive-owned.py','run.sh','contract.md','pre-measurement-plan.md','setup-contract.json','source.patch','source-current.zip','focused.json']:a.add(r/name,arcname=name)
 import io
 item=tarfile.TarInfo('current-core.dll');item.size=len(core);a.addfile(item,io.BytesIO(core))
s=(old/'launch.py').read_text(encoding='utf-8').replace(old_remote,remote).replace('operand-transport-b397-20261107','operand-transport-b398-20261107').replace('lython-b397-operand-transport-20261107','lython-b398-operand-transport-20261107').replace('operand-transport-b397-launch.py','operand-transport-b398-launch.py')
s=s.replace('ownerSeconds=240','ownerSeconds=180').replace('RuntimeMaxSec=240','RuntimeMaxSec=180').replace('seconds=300','seconds=240')
ast.parse(s);(r/'launch.py').write_text(s,encoding='utf-8',newline='\n')
s=(home/'retrieve-b397.py').read_text(encoding='utf-8').replace("parent/'b397'","parent/'b398'").replace(old_remote,remote).replace('lython-b397-operand-transport-20261107','lython-b398-operand-transport-20261107')
ast.parse(s);(home/'retrieve-b398.py').write_text(s,encoding='utf-8',newline='\n')
s=(home/'summarize-b397.py').read_text(encoding='utf-8').replace("'b397/retrieved/confirmation/confirmation.json'","'b398/retrieved/confirmation/confirmation.json'")
# The adaptation source still contains the old replacement target.
s=s.replace('comparison-summary.json','corrected-comparison-summary.json')
(home/'summarize-b398.py').write_text(s,encoding='utf-8',newline='\n')
print('B398 protocol correction prepared, identical source/images;180+30+30s. Original failed B397 untouched.')
