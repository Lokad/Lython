from pathlib import Path
root=Path('D:/code/Lython')
def replace(s,old,new):
    assert s.count(old)==1,(old[:90],s.count(old))
    return s.replace(old,new)
def edit(name,operation):
    p=root/name;s=p.read_text(encoding='utf-8');new=operation(s);assert s!=new,name;p.write_text(new,encoding='utf-8',newline='\n')
def metadata(s):
    s=replace(s,'    private readonly int _liveExtent;','    private readonly int _liveExtent;\n    private readonly int _thirdInput;')
    s=replace(s,'int primaryOperand = 0, int secondaryOperand = 0,\n        int inputStart = -1, int resultSlot = -1, int liveExtent = 0)', 'int primaryOperand = 0, int secondaryOperand = int.MaxValue,\n        int inputStart = int.MaxValue, int resultSlot = -1, int liveExtent = 0, int thirdInput = int.MaxValue)')
    s=replace(s,'        _liveExtent = liveExtent;','        _liveExtent = liveExtent;\n        _thirdInput = thirdInput;')
    s=replace(s,'    public int SecondInput => _secondaryOperand;', '''    public int SecondInput => _secondaryOperand;
    public int ThirdInput => ValueInputCount == 3 ? _thirdInput : throw InvalidOperand(nameof(ThirdInput));
    internal int ValueInputCount => OpCode switch
    {
        ExecutableOpCode.Binary or ExecutableOpCode.Augmented or ExecutableOpCode.Subscript => 2,
        ExecutableOpCode.StoreSubscript or ExecutableOpCode.StoreSubscriptLast => 3,
        ExecutableOpCode.Unary or ExecutableOpCode.StoreLocal or ExecutableOpCode.Return => 1,
        _ => 0,
    };''')
    a=s.index('    internal ExecutableInstruction WithStorageSlots(');b=s.index('    // The following store retains',a)
    s=s[:a]+'''    internal ExecutableInstruction WithStorageSlots(int inputStart, int resultSlot, int liveExtent)
        => new(OpCode, Span, _primaryOperand,
            ValueInputCount > 1 ? checked(inputStart + 1) : _secondaryOperand,
            inputStart, resultSlot, HasLocalResult ? ~liveExtent : liveExtent,
            ValueInputCount == 3 ? checked(inputStart + 2) : _thirdInput);

    internal ExecutableInstruction WithValueInputs(int first, int second, int third = int.MaxValue)
        => new(OpCode, Span, _primaryOperand,
            ValueInputCount > 1 ? second : _secondaryOperand,
            first, _resultSlot, _liveExtent, ValueInputCount == 3 ? third : _thirdInput);

''' +s[b:]
    s=s.replace('_inputStart, _resultSlot, ~_liveExtent);','_inputStart, _resultSlot, ~_liveExtent, _thirdInput);')
    s=s.replace('_inputStart, _resultSlot, _liveExtent)\n','_inputStart, _resultSlot, _liveExtent, _thirdInput)\n')
    s=replace(s,'        ExecutableStackLayout operandLayout)\n', '        int initialOperandDepth)\n')
    a=s.index('        OperandCapacity = operandLayout.MaximumDepth;');b=s.index('        EntryIndex = offsets[entryBlockIndex];',a)
    s=s[:a]+'''        NativeBody = PrepareNativeBody(blocks, exceptionRegions.Count);
        var reads = NativeBody is null ? ExecutableStackLayout.ForwardValues(this, blocks) : null;
        // Assign physical positions once, after removing forwarded loads. The
        // native proof retains its original instruction sequence and indices.
        var operandLayout = ExecutableStackLayout.Prepare(blocks, constants, callSites,
            exceptionRegions, entryBlockIndex, initialOperandDepth, FirstTemporarySlot);
        OperandCapacity = operandLayout.MaximumDepth;
        LastOwnedTemporarySlot = operandLayout.LastOwnedTemporarySlot;
        Instructions = ExecutableStackLayout.Linearize(blocks, operandLayout, out var offsets);
        _operandReadSpans = reads is null ? [] : reads.Select(read => new ExecutableOperandSpan(
            ((long)(offsets[read.Block] + read.Instruction) << 2) | (uint)read.Input, read.Span)).ToArray();
''' +s[b:]
    s=replace(s,'        ExceptionRegions = exceptionRegions.Select(region => region with', '''        ExceptionRegions = exceptionRegions
            .Where(region => operandLayout.EntryDepths[region.ProtectedStartIndex].HasValue)
            .Select(region => region with''')
    s=replace(s,'            ProtectedStartIndex = offsets[region.ProtectedStartIndex],','            StackDepth = checked(FirstTemporarySlot + operandLayout.EntryDepths[region.ProtectedStartIndex]!.Value),\n            ProtectedStartIndex = offsets[region.ProtectedStartIndex],')
    return s
edit('src/Lokad.Lython/Frontend/ExecutableScript.cs',metadata)
def builder(s):
    a=s.index('            var operandLayout = ExecutableStackLayout.Prepare(');b=s.index('            // This builder is single-use;',a)
    s=s[:a]+s[b:]
    return replace(s,'                operandLayout: operandLayout);','                initialOperandDepth: generatorExpression is null ? 0 : 1);')
edit('src/Lokad.Lython/Frontend/ExecutableScript.Builder.cs',builder)
def layout(s):
    s=replace(s,'Effect(instruction, constants, calls);','Effect(instruction, constants, calls, firstTemporarySlot);')
    s=replace(s,'maximum = Math.Max(maximum, checked(depth + 2));','maximum = Math.Max(maximum, checked(depth - pop + 4));')
    old='''                instructions[instructionIndex] = instruction.WithStorageSlots(
                    checked(firstTemporarySlot + inputStart), checked(firstTemporarySlot + resultSlot),
                    checked(firstTemporarySlot + depth));'''
    new='''                var prepared = instruction.WithStorageSlots(
                    checked(firstTemporarySlot + inputStart), checked(firstTemporarySlot + resultSlot),
                    checked(firstTemporarySlot + depth));
                if (instruction.ValueInputCount != 0)
                {
                    var physical = checked(firstTemporarySlot + inputStart);
                    var first = instruction.InputStart < firstTemporarySlot ? instruction.InputStart : physical++;
                    var second = instruction.ValueInputCount > 1
                        ? instruction.SecondInput < firstTemporarySlot ? instruction.SecondInput : physical++ : int.MaxValue;
                    var third = instruction.ValueInputCount == 3
                        ? instruction.ThirdInput < firstTemporarySlot ? instruction.ThirdInput : physical++ : int.MaxValue;
                    prepared = prepared.WithValueInputs(first, second, third);
                }
                instructions[instructionIndex] = prepared;'''
    s=replace(s,old,new)
    a=s.index('    // Fixed-arity consumers');b=s.index('    private static bool CanForwardResult',a)
    s=s[:a]+'''    // Forward adjacent pure leaf inputs before assigning physical positions.
    // Checked locals keep their original spans in cold metadata; neither branch
    // initialization facts nor their invalidation inventories are needed.
    internal static List<(int Block, int Instruction, int Input, LythonSourceSpan Span)> ForwardValues(
        ExecutableCodeObject code, List<ExecutableBasicBlock> blocks)
    {
        var reads = new List<(int Block, int Instruction, int Input, LythonSourceSpan Span)>();
        for (var block = 0; block < blocks.Count; block++)
        {
            var instructions = blocks[block].InstructionArray;
            var kept = 0;
            for (var index = 0; index < instructions.Length; index++)
            {
                var instruction = instructions[index];
                var count = instruction.ValueInputCount;
                var first = instruction.InputStart;
                var second = instruction.SecondInput;
                var third = count == 3 ? instruction.ThirdInput : int.MaxValue;
                LythonSourceSpan? firstSpan = null, secondSpan = null, thirdSpan = null;
                for (var input = count - 1; input >= 0 && kept != 0; input--)
                {
                    var leaf = instructions[kept - 1];
                    int source;
                    LythonSourceSpan? span = null;
                    if (leaf.OpCode == ExecutableOpCode.LoadConst) source = ~leaf.ConstantIndex;
                    else if (leaf.OpCode == ExecutableOpCode.LoadLocal && !code.RequiresLocalVariableMirroring
                        && !code.CapturedLocalSlots.Contains(leaf.LocalSlot))
                    {
                        source = leaf.LocalSlot;
                        span = leaf.Span;
                    }
                    else break;
                    if (input == 0) { first = source; firstSpan = span; }
                    else if (input == 1) { second = source; secondSpan = span; }
                    else { third = source; thirdSpan = span; }
                    kept--;
                }
                if (count != 0) instruction = instruction.WithValueInputs(first, second, third);
                // Keep the store as the pending-cleanup continuation and for its
                // own guard/span. Direct sources do not consume a producer result.
                if (instruction.OpCode == ExecutableOpCode.StoreLocal && first == int.MaxValue && kept > 0
                    && CanForwardResult(instructions[kept - 1], code.Constants))
                    instructions[kept - 1] = instructions[kept - 1].WithLocalResult();
                if (firstSpan is not null) reads.Add((block, kept, 0, firstSpan));
                if (secondSpan is not null) reads.Add((block, kept, 1, secondSpan));
                if (thirdSpan is not null) reads.Add((block, kept, 2, thirdSpan));
                instructions[kept++] = instruction;
            }
            if (kept != instructions.Length)
                blocks[block] = blocks[block] with { InstructionArray = instructions[..kept] };
        }
        return reads;
    }

''' +s[b:]
    s=replace(s,'IReadOnlyList<object?> constants, IReadOnlyList<ExecutableCallSite> calls)\n    {','IReadOnlyList<object?> constants, IReadOnlyList<ExecutableCallSite> calls, int firstTemporarySlot)\n    {')
    s=replace(s,'        return (pop, push, minimum);', '''        if (instruction.ValueInputCount != 0)
        {
            var forwarded = instruction.InputStart < firstTemporarySlot ? 1 : 0;
            if (instruction.ValueInputCount > 1 && instruction.SecondInput < firstTemporarySlot) forwarded++;
            if (instruction.ValueInputCount == 3 && instruction.ThirdInput < firstTemporarySlot) forwarded++;
            pop -= forwarded;
            minimum -= forwarded;
        }
        return (pop, push, minimum);''')
    return s
edit('src/Lokad.Lython/Frontend/ExecutableStackLayout.cs',layout)
print('Compiler prototype: indexed inputs extended, forwarding before one physical shape pass, initialized-local tracking removed.')
