using System.Collections;
using System.Reflection;
using System.Runtime.Loader;
using System.Security.Cryptography;
using System.Text.Json;

// Compile-only metadata census. No guest execution or runtime instrumentation.
const BindingFlags Flags = BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic;
object? Get(object owner, string property) => owner.GetType().GetProperty(property, Flags)!.GetValue(owner);
object[] Items(object owner, string property) => ((IEnumerable)Get(owner, property)!).Cast<object>().ToArray();
var corePath = Path.GetFullPath(args[0]);
var core = AssemblyLoadContext.Default.LoadFromAssemblyPath(corePath);
var engineType = core.GetType("Lokad.Lython.LythonEngine", true)!;
var engine = Activator.CreateInstance(engineType)!;
var compile = engineType.GetMethod("Compile", [typeof(string), core.GetType("Lokad.Lython.ILythonMemoryBudget", true)!])!;
using var catalog = JsonDocument.Parse(File.ReadAllBytes(args[1]));
long Stride(Type type)
{
    _ = Array.CreateInstance(type, 1);
    var start = GC.GetAllocatedBytesForCurrentThread();
    var small = Array.CreateInstance(type, 4096);
    var middle = GC.GetAllocatedBytesForCurrentThread();
    var large = Array.CreateInstance(type, 8192);
    var end = GC.GetAllocatedBytesForCurrentThread();
    GC.KeepAlive(small); GC.KeepAlive(large);
    return ((end-middle)-(middle-start))/4096;
}
var instructionStride = Stride(core.GetType("Lokad.Lython.Frontend.ExecutableInstruction", true)!);
var spanType = core.GetType("Lokad.Lython.Frontend.ExecutableOperandSpan", false);
var spanStride = spanType is null ? 0 : Stride(spanType);
var cases = new List<object>();
foreach (var item in catalog.RootElement.GetProperty("cases").EnumerateArray())
{
    using var script = (IDisposable)compile.Invoke(engine, [item.GetProperty("source").GetString(), null])!;
    if (!(bool)Get(script, "IsValid")!) throw new InvalidDataException("Census requires valid maintained source.");
    var runner = (Delegate)script.GetType().GetField("_runner", Flags)!.GetValue(script)!;
    var executable = runner.Target!.GetType().GetField("executableScript", Flags)!.GetValue(runner.Target)!;
    var codes = new List<object>();
    var seen = new HashSet<object>(ReferenceEqualityComparer.Instance);
    void Visit(object code)
    {
        if (!seen.Add(code)) return;
        var readSpans = code.GetType().GetField("_operandReadSpans", Flags)?.GetValue(code) as Array;
        var operations = new List<object>();
        var counts = new Dictionary<string, int>(StringComparer.Ordinal);
        foreach (var instruction in Items(code, "Instructions"))
        {
            var op = Get(instruction, "OpCode")!.ToString()!;
            counts[op] = counts.GetValueOrDefault(op) + 1;
            var span = Get(instruction, "Span")!;
            
            var sites = Items(code, "CallSites");
            object? call = op == "Call" ? sites[(int)Get(instruction, "CallSiteIndex")!] : null;
            operations.Add(new { op, line = Get(span, "Line"),
                inputStart=Get(instruction,"InputStart"), resultSlot=Get(instruction,"ResultSlot"),
                secondInput=Get(instruction,"SecondInput"), liveExtent=Get(instruction,"LiveExtent"),
                localSlot=op=="LoadLocal"?Get(instruction,"LocalSlot"):null,
                constantIndex=op=="LoadConst"?Get(instruction,"ConstantIndex"):null,
                call=call is null?null:new {count=Get(call,"ArgumentCount"),
                    receiver=Get(call,"HasReceiver"),positional=Get(call,"IsPositionalOnly")}
            });
        }
        codes.Add(new { name = Get(code, "Name"), locals = Items(code, "LocalNames"),
            requiresMirroring = Get(code, "RequiresLocalVariableMirroring"),
            exceptionRegions = Items(code, "ExceptionRegions").Length,
            native = Get(code, "NativeBody") is not null,  memberCaches = Get(code, "MemberCacheCount"),
            constantTypes = Items(code, "Constants").Select(value => value?.GetType().FullName),
            instructionBytesPerElement = instructionStride,
            coldReadSpanCount = readSpans?.Length ?? 0, coldReadSpanBytesPerElement = spanStride,
            instructionAndReadSpanPayloadBytes = counts.Values.Sum()*instructionStride+(readSpans?.Length ?? 0)*spanStride,
            instructionCount = counts.Values.Sum(), operandCapacity = Get(code, "OperandCapacity"),
            retainsBlockGraph = code.GetType().GetProperty("Blocks", Flags) is not null,
            regionDepths = Items(code, "ExceptionRegions").Select(region => Get(region, "StackDepth")), counts, operations });
        foreach (var function in Items(code, "Functions")) Visit(Get(function, "CodeObject")!);
    }
    Visit(Get(executable, "EntryPoint")!);
    cases.Add(new { id = item.GetProperty("id").GetString(), sourceSha256 = item.GetProperty("sourceSha256").GetString(), codes });
}
File.WriteAllText(args[2], JsonSerializer.Serialize(new {
    purpose = "Compile-only emitted instruction census; static counts are not CPU shares or speedup evidence",
    coreSHA256 = Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(corePath))),
    runtime = System.Runtime.InteropServices.RuntimeInformation.FrameworkDescription,
    noGuestExecution = true, noProductionEdits = true, cases
}, new JsonSerializerOptions { WriteIndented = true }));

