from pathlib import Path
import hashlib,json,zipfile
r=Path(__file__).parent
identity=json.loads((r/'diagnostic-identity.json').read_text())
assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==digest for p,digest in identity['productionSources'].items())
with zipfile.ZipFile(r/'source-initial.zip','x',zipfile.ZIP_DEFLATED) as archive:
 for p in identity['productionSources']:archive.write(p,p)
p=Path('src/Lokad.Lython/Frontend/ExecutableScript.cs');s=p.read_text(encoding='utf-8')
s=s.replace('    private readonly int _thirdInput;\n','')
s=s.replace('int inputStart = int.MaxValue, int resultSlot = -1, int liveExtent = 0, int thirdInput = int.MaxValue)','int inputStart = int.MaxValue, int resultSlot = -1, int liveExtent = 0)')
s=s.replace('        _thirdInput = thirdInput;\n','')
s=s.replace('public int ThirdInput => ValueInputCount == 3 ? _thirdInput', 'public int ThirdInput => ValueInputCount == 3 ? _resultSlot')
s=s.replace('public int ResultSlot => _resultSlot;', '''// A subscript store pushes no result: its output position is its live
    // extent. Reuse that otherwise redundant field for its third input, keeping
    // every instruction at the existing size, including native helper code.
    public int ResultSlot => OpCode is ExecutableOpCode.StoreSubscript or ExecutableOpCode.StoreSubscriptLast
        ? LiveExtent : _resultSlot;''')
s=s.replace('''            inputStart, resultSlot, HasLocalResult ? ~liveExtent : liveExtent,
            ValueInputCount == 3 ? checked(inputStart + 2) : _thirdInput);''','''            inputStart, ValueInputCount == 3 ? checked(inputStart + 2) : resultSlot,
            HasLocalResult ? ~liveExtent : liveExtent);''')
s=s.replace('''            first, _resultSlot, _liveExtent, ValueInputCount == 3 ? third : _thirdInput);''','''            first, ValueInputCount == 3 ? third : _resultSlot, _liveExtent);''')
s=s.replace(', _thirdInput)',')')
s=s.replace('''span, targetSpanIndex);

    public static ExecutableInstruction StoreSlice''','''span, targetSpanIndex, resultSlot: int.MaxValue);

    public static ExecutableInstruction StoreSlice''')
assert '_thirdInput' not in s and 'thirdInput =' not in s
assert s.count('span, targetSpanIndex, resultSlot: int.MaxValue)')==1
p.write_text(s,encoding='utf-8',newline='\n')
print('Initial source preserved; subscript stores reuse redundant result metadata. No runtime path changes.')
