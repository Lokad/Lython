import json,subprocess,os,fcntl,hashlib
from pathlib import Path
from datetime import datetime,timezone
s=Path('/home/lokad/lython-bench-checks/json-default-options-f728636a')
revision='f728636a5283dcbeb21344629802c2468c5c0525'
dotnet='/home/lokad/lython-bench-toolchains/dotnet/10.0.401/dotnet'
env=dict(os.environ,DOTNET_ROOT=str(Path(dotnet).parent),DOTNET_NOLOGO='1',DOTNET_CLI_TELEMETRY_OPTOUT='1',MSBUILDDISABLENODEREUSE='1',DOTNET_CLI_USE_MSBUILD_SERVER='0',GIT_TERMINAL_PROMPT='0')
r={'state':'Starting','baseRevision':revision,'candidateKind':'two frozen runtime files on immutable base; working snapshot','startedUtc':datetime.now(timezone.utc).isoformat()}
def save():(s/'preparation.json').write_text(json.dumps(r,indent=2)+'\n')
def run(args,cwd=None,log=None):
    x=subprocess.run(args,cwd=cwd,env=env,capture_output=True,text=True)
    if log:(s/log).write_text(x.stdout+x.stderr)
    if x.returncode:raise RuntimeError(str(args[:2])+':'+(x.stderr or x.stdout)[-1800:])
    return x.stdout.strip()
save()
try:
    with Path('/home/lokad/lython-bench-checks/comparison-vm.lock').open('a+') as lease:
        fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
        root=s/'candidate';root.mkdir();run(['git','init','-q',str(root)])
        run(['git','-C',str(root),'remote','add','origin','https://github.com/Lokad/Lython.git'])
        run(['git','-C',str(root),'fetch','--depth=1','--filter=blob:none','origin',revision],log='fetch.log')
        run(['git','-C',str(root),'config','core.sparseCheckout','true'])
        (root/'.git/info/sparse-checkout').write_text('/*\n!/*/\n/src/\n/benchmarks/Lokad.Lython.Benchmarks/\n/benchmarks/scripts/\n/benchmarks/cpython-worker.py\n/third_party/\n')
        run(['git','-C',str(root),'checkout','--detach',revision],log='checkout.log')
        assert not run(['git','-C',str(root),'status','--porcelain'])
        frozen=json.loads((s/'frozen-source.json').read_text())
        for name,identity in frozen['files'].items():
            content=(s/Path(name).name).read_bytes();assert hashlib.sha256(content).hexdigest()==identity['canonicalSha256']
            (root/name).write_bytes(content)
        assert set(run(['git','-C',str(root),'diff','--name-only']).splitlines())==set(frozen['files'])
        r.update(state='Building',root=str(root),frozenSource=frozen);save()
        launch=s/'build-launch';launch.mkdir();(launch/'global.json').write_text(json.dumps({'sdk':{'version':'10.0.401','rollForward':'disable'}}))
        run([dotnet,'build',str(root/'benchmarks/Lokad.Lython.Benchmarks/Lokad.Lython.Benchmarks.csproj'),'-c','Release','-v','minimal','-nodeReuse:false'],cwd=launch,log='build.log')
        worker=root/'benchmarks/Lokad.Lython.Benchmarks/bin/Release/net10.0/Lokad.Lython.Benchmarks.dll'
        (s/'candidate.patch').write_text(run(['git','-C',str(root),'diff','--','src'])+'\n')
        r.update(state='Completed',completedUtc=datetime.now(timezone.utc).isoformat(),worker=str(worker),workerSha256=hashlib.sha256(worker.read_bytes()).hexdigest(),librarySha256=hashlib.sha256(worker.with_name('Lokad.Lython.dll').read_bytes()).hexdigest(),sourceStatus=run(['git','-C',str(root),'status','--porcelain']),baselineWorker='/home/lokad/lython-bench-checks/json-helper-f728636a/source-subject/benchmarks/Lokad.Lython.Benchmarks/bin/Release/net10.0/Lokad.Lython.Benchmarks.dll',catalog='/home/lokad/lython-bench-checks/json-helper-f728636a/catalog.json')
        save()
except BaseException as error:r.update(state='Failed',error=repr(error),completedUtc=datetime.now(timezone.utc).isoformat());save();raise
