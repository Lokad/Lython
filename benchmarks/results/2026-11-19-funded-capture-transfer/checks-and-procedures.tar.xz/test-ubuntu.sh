set -eu
cd /mnt/d/code/Lython/.git/agent-worktrees/capture-charge-transfer-r666
notes=/mnt/d/code/Lython/.git/agent-notes/review-20261031/capture-charge-transfer-r666
filter='(FullyQualifiedName~Closure|FullyQualifiedName~Nonlocal|FullyQualifiedName~Comprehension|FullyQualifiedName~ClassScope|FullyQualifiedName~ExecutableFunction|FullyQualifiedName~FunctionDefault|FullyQualifiedName~Generator|FullyQualifiedName~SharedMemory|FullyQualifiedName~RefusedAdmission)&Category!=Stress'
status=0
for suite in "${@:-Tests}"; do
    log="$notes/ubuntu-net10-$suite.log"
    if ! ~/.dotnet/dotnet test "tests/Lokad.Lython.$suite" -c Release -f net10.0 --artifacts-path ~/lython-r666-artifacts --filter "$filter" > "$log" 2>&1; then
        status=1
    fi
    tail -n 7 "$log"
done
exit "$status"
