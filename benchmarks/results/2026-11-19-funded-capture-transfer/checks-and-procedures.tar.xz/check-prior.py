from pathlib import Path
import hashlib
import json
import os
import shutil
import subprocess

lab = Path(__file__).resolve().parent
repo = Path.cwd()
trial = repo / '.git/agent-worktrees/capture-charge-transfer-r666'
work = trial / 'tests/Lokad.Lython.Tests/bin/Release/net11.0'
previous = lab.parent / 'retained-runtime-cpython-r661'
identity = json.loads((previous / 'identity.json').read_text(encoding='utf-8-sig'))
donor = previous / 'frozen/candidate/Lokad.Lython.dll'
assert hashlib.sha256(donor.read_bytes()).hexdigest() == identity['imageFiles']['candidate'][donor.name]
image = lab / 'prior-build-test'
shutil.copytree(work, image)
assert (image / donor.name).read_bytes() != donor.read_bytes()
shutil.copyfile(donor, image / donor.name)
sdk = Path.home() / '.dotnet11'
env = dict(os.environ, DOTNET_ROOT=str(sdk), DOTNET_ROOT_X64=str(sdk), PATH=str(sdk) + os.pathsep + os.environ['PATH'])
done = subprocess.run([sdk / 'dotnet.exe', 'vstest', image / 'Lokad.Lython.WhiteBox.Tests.dll',
    '/TestCaseFilter:FullyQualifiedName~ClosureCaptureTransfersAdmittedCellsOnlyAfterArrayAdmission'],
    env=env, capture_output=True, timeout=90)
log = done.stdout + done.stderr
(lab / 'prior-build-regression.log').write_bytes(log)
assert done.returncode == 1 and b'Assert.InRange() Failure' in log and b'Actual: 240' in log, log.decode()
print('The previous core charges the 48-byte array plus 192 bytes for the same live cells. The refusal case still passes.')
