from pathlib import Path
import ast
import json
import tarfile

lab = Path(__file__).resolve().parent
template = lab.parent / 'integer-chain-prefix-r665'
historical = Path('benchmarks/results/2026-11-19-detached-nonlocal-cells/checks-and-procedures.tar.xz')

def read(path):
    return path.read_text(encoding='utf-8-sig')

def write(path, source):
    if path.suffix == '.py':
        ast.parse(source)
    path.write_text(source, encoding='utf-8', newline='\n')

captured = 'scripts.captured-rule-closures'
siblings = 'scripts.retained-nonlocal-factories'
counter = 'scripts.mutable-rule-counters'
ordinary = 'scripts.rule-default-closures'
annotated = 'scripts.annotated-rule-closures'
forwarding = 'scripts.report-forwarding.expanded'
jobs = [(case, lane) for lane, cases in [('warm', [captured, siblings, counter, ordinary, annotated, forwarding]),
         ('compile-run', [captured, siblings])] for case in cases]
selected = {case for case, _ in jobs}
with tarfile.open(historical) as evidence:
    catalog = json.load(evidence.extractfile('catalog.json'))
catalog['cases'] = [case for case in catalog['cases'] if case['id'] in selected]
assert {case['id'] for case in catalog['cases']} == selected
write(lab / 'catalog.json', json.dumps(catalog, indent=2, ensure_ascii=False) + '\n')

freeze = read(template / 'freeze-and-verify.py').replace('integer-chain-prefix-r665', 'capture-charge-transfer-r666')
freeze = freeze.replace('== 4', '== 6').replace('all four', 'all six')
write(lab / 'freeze-and-verify.py', freeze)

stage = read(template / 'stage-quiet.py')
stage = stage.replace('quiet-confirmation', 'quiet').replace('b1094', 'b1096')
stage = stage.replace('integer-chain-prefix-b1096-confirmation', 'capture-charge-transfer-b1096')
stage = stage.replace('b1096-integer-chain-prefix', 'b1096-capture-charge-transfer')
stage = stage.replace('R665 publish completed machine integer prefix', 'R666 transfer the funded local capture cell')
stage = stage.replace('four-case', 'six-case')
start, end = stage.index('        jobs = ['), stage.index('        source=source[:a]')
stage = stage[:start] + '        jobs = ' + repr(jobs) + '\n' + stage[end:]
stage += '''
collector = read(quiet / 'collect.py')
archive = read(quiet / 'archive-owned.py')
assert 'assert len(jobs)==8' in collector
assert "len(raw['jobs'])==8" in archive and 'jobs=8,' in archive
assert "['jobs']==8" in read(quiet / 'retrieve.py')
assert "len(raw['jobs'])==8" in read(lab / 'summarize-quiet.py')
'''
write(lab / 'stage-quiet.py', stage)
