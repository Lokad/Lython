from pathlib import Path
import json,shutil
r=Path(__file__).parent;f=r/'refined';f.mkdir();o=f/'original';o.mkdir()
for n in ['src/Lokad.Lython/Runtime/LythonRuntime.StringMembers.Advanced.cs']:
 p=o/n;p.parent.mkdir(parents=True);shutil.copyfile(n,p)
(f/'selection.json').write_text(json.dumps(dict(originalEvidence='../quiet/observations.tgz',originalCore='5ebd657a11ecd0ddea14f82879c78c033f525cff502479eb51b7fb6da8a1322b',hypothesis='First warm normalization is5.3–7.5%slower/CPU4.2–6.0%higher with stable controls. Join replaced simple builder copies with generic repetition setup and repeated checks for every tiny fragment. Use direct bounded copies and periodic native item-loop checkpoints; no change to allocation/storage contract, semantic work or aggregate quotas. Causality not established; one controlled confirmation, preserve original source and adverse observation.'),indent=2)+'\n',encoding='utf-8',newline='\n')
