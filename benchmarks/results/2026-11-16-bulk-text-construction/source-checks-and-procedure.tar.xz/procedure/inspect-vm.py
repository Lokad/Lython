from pathlib import Path
import json,shlex,subprocess
r=Path(__file__).parent
code='''from pathlib import Path
import fcntl,hashlib,json,os,shutil,stat,subprocess
b=Path('/home/lokad/lython-bench-checks');p=b/'compiler-store-b820-20261116/candidate/Lokad.Lython.dll'
with(b/'comparison-vm.lock').open('a')as f:
 fcntl.flock(f,fcntl.LOCK_EX|fcntl.LOCK_NB)
 workers=subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record|[p]ython3.*cpython-worker.py'],capture_output=True,text=True).stdout
 own={str(os.getpid()),str(os.getppid())};assert all(line.split(maxsplit=1)[0]in own for line in workers.splitlines()),workers
 m=p.lstat();assert stat.S_ISREG(m.st_mode) and m.st_uid==os.getuid()
 h=hashlib.sha256(p.read_bytes()).hexdigest();assert h=='9d26d408ac591aba042f92106167a7cc1df8148b6fc26554f65fa667af5cb5f0'
 paths=[]
 for base,dirs,files in os.walk(b):
  for n in files:
   q=Path(base)/n;s=q.lstat()
   if s.st_dev==m.st_dev and s.st_ino==m.st_ino:paths.append(str(q.relative_to(b)))
 assert len(paths)==m.st_nlink
 print(json.dumps(dict(freeBytes=shutil.disk_usage(b).free,sha256=h,bytes=m.st_size,links=m.st_nlink,paths=paths)))
'''
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
p=subprocess.run(ssh+['python3 -c '+shlex.quote(code)],capture_output=True,text=True,encoding='utf-8',timeout=45);assert p.returncode==0,p.stderr
(r/'historical-aliases.json').write_text(p.stdout,encoding='utf-8',newline='\n');print(p.stdout)
