from pathlib import Path
import json,sys
rows=[]
for count in [4093,4094,4095,4096]:
 for width in [-4,0,4,8]:
  prefix='a'*count;source=prefix+'😀\tq\r\né\tz\nA\u0301\tZ\r\tend\v\t.'
  suffix={4:'q\r\né   z\nA\u0301  Z\r    end\v    .',8:'q\r\né       z\nA\u0301      Z\r        end\v    .'}.get(width,'q\r\néz\nA\u0301Z\rend\v.')
  expected=prefix+'😀'+' '*(0 if width<=0 else width-(count+1)%width)+suffix
  assert source.expandtabs(width)==expected
  rows.append(dict(prefix=count,width=width,agrees=True))
Path(__file__).with_name('cpython-semantics.json').write_text(json.dumps(dict(reference=sys.version,rows=rows),indent=2)+'\n',encoding='utf-8',newline='\n')
print('16 adversarial Unicode/chunk-boundary goldens agree with CPython.')
