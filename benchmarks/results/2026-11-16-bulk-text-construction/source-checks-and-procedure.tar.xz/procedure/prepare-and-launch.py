from pathlib import Path
import ast,datetime,hashlib,json,shlex,subprocess,tarfile
r=Path(__file__).parent;base=r.parent/'consume-text-r426';q=r/'quiet';q.mkdir();old=base/'quiet';head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
delivery=json.loads((base/'delivery-corrections/delivery-candidate.json').read_text(encoding='utf-8'));proof=json.loads((base/'delivery-corrections/source-proof.json').read_text(encoding='utf-8'));assert delivery['head']==head and proof['inputCount']==597 and proof['allInputsMatchAfterExplicitUTF8NewlineNormalization']
f=json.loads((r/'frozen/identity.json').read_text(encoding='utf-8'));keys=set(json.loads((old/'identity.json').read_text(encoding='utf-8'))['imageFiles']['candidate']);images={role:{n:h for n,h in files.items()if n in keys}for role,files in f['images'].items()}
root='/home/lokad/lython-bench-checks/bulk-text-b825-20261116';unit='lython-b825-bulk-text-20261116'
identity=dict(sourceRevision='R429 uncommitted'+images['candidate']['Lokad.Lython.dll'][:8]+' versus committed0a04e253/frozen810dafdd',purpose='One final admitted UTF8 output for bulk expandtabs/join; remove per-scalar builder writes and join intermediate iterator/growth. Complete normalization warm/fresh, report and unchanged JSON controls. No new policy/cache/framework.',coreSHA256={label:images['candidate'if label.startswith('candidate')else'reference']['Lokad.Lython.dll']for label in ['candidate','candidate-control','reference','reference-control']},imageFiles=images,prototype=True,publicationHeld=True,referenceQualificationRun=delivery['runId'],referenceFullQualificationPendingAtStaging=True,candidateSourceIdentitySHA256=hashlib.sha256((r/'frozen/identity.json').read_bytes()).hexdigest())
(q/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8',newline='\n')
jobs=[['scripts.text-normalization.large','warm'],['scripts.text-normalization.large','compile-run'],['scripts.report-render.format-method.large','warm'],['scripts.json-summary-helpers.large','warm']]
for n in ['collect.py','archive-owned.py','run.sh','retrieve.py']:
 s=(old/n).read_text(encoding='utf-8').replace('consume-text-b822-20261116','bulk-text-b825-20261116').replace('lython-b822-consume-text-20261116',unit).replace('B822','B825')
 if n=='collect.py':
  a=s.index('jobs=');b=s.index('\nenv =',a);s=s[:a]+'jobs='+repr(jobs)+"\nassert len(jobs)==4 and all(case in cases for case,lane in jobs)\n"+s[b:]
 if n.endswith('.py'):ast.parse(s)
 (q/n).write_text(s,encoding='utf-8',newline='\n')
# Reuse the exact existing complete catalog and unchanged fixture/golden bytes;
# linking the immutable catalog avoids staging another redundant working copy.
(q/'representative.json').write_bytes((old/'representative.json').read_bytes())
with tarfile.open(q/'payload.tgz','w:gz')as a:
 for n in ['identity.json','collect.py','archive-owned.py','run.sh']:a.add(q/n,arcname=n)
 a.add(r/'frozen/candidate/Lokad.Lython.dll',arcname='candidate/Lokad.Lython.dll')
with tarfile.open(q/'payload.tgz')as a:size=sum(m.size for m in a if m.isfile())
v=json.loads((r/'historical-aliases.json').read_text(encoding='utf-8'));archive='benchmarks/results/2026-11-16-consuming-text-completion/source-checks-and-procedure.tar.xz';raw=Path(archive).read_bytes();assert subprocess.check_output(['git','show',head+':'+archive])==raw
with tarfile.open(archive)as a:core=a.extractfile('frozen/reference/Lokad.Lython.dll').read()
assert hashlib.sha256(core).hexdigest()==v['sha256']and len(core)==v['bytes'];v['custody']=dict(commit=head,archive=archive,archiveSHA256=hashlib.sha256(raw).hexdigest(),member='frozen/reference/Lokad.Lython.dll')
(r/'historical-aliases.json').write_text(json.dumps(v,indent=2)+'\n',encoding='utf-8',newline='\n')
c=dict(root=root,unit=unit,source='/home/lokad/lython-bench-checks/consume-text-b822-20261116',sourceFiles=images['reference'],sourceCatalogSHA256=hashlib.sha256((old/'representative.json').read_bytes()).hexdigest(),catalogSHA256=hashlib.sha256((q/'representative.json').read_bytes()).hexdigest(),identity=identity,retireGroups=[v],payloadBytes=(q/'payload.tgz').stat().st_size,payloadSHA256=hashlib.sha256((q/'payload.tgz').read_bytes()).hexdigest(),unpackedBytes=size)
(q/'config.json').write_text(json.dumps(c,indent=2)+'\n',encoding='utf-8',newline='\n')
s=(old/'remote-launch.py').read_text(encoding='utf-8');tree=ast.parse(s);node=next(n for n in tree.body if isinstance(n,ast.Assign)and any(isinstance(t,ast.Name)and t.id=='c'for t in n.targets));lines=s.splitlines(keepends=True);s=''.join(lines[:node.lineno-1])+'c='+repr(c)+'\n'+''.join(lines[node.end_lineno:])
needle=" os.link(source/'cpython-worker.py',root/'cpython-worker.py');assert sha(root/'representative.json')==c['catalogSHA256'];os.link(source/'additional.json',root/'additional.json')";assert needle in s;s=s.replace(needle," os.link(source/'representative.json',root/'representative.json')\n"+needle)
s=s.replace('lython-b822-fixtures','lython-b825-fixtures');ast.parse(s);(q/'remote-launch.py').write_text(s,encoding='utf-8',newline='\n')
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
p=subprocess.run(ssh+['python3 -c '+shlex.quote(s)],input=(q/'payload.tgz').read_bytes(),capture_output=True,timeout=45);(q/'launch.log').write_bytes(p.stdout+p.stderr);assert p.returncode==0,(p.stdout+p.stderr).decode('utf-8','replace')
now=datetime.datetime.now(datetime.timezone.utc);(q/'observe-not-before.json').write_text(json.dumps(dict(startedUTC=now.isoformat(),doNotObserveBeforeUTC=(now+datetime.timedelta(seconds=200)).isoformat(),ownerSeconds=240),indent=2)+'\n',encoding='utf-8',newline='\n');print(p.stdout.decode('utf-8'),flush=True)
