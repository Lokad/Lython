from pathlib import Path
import hashlib,json,shutil,subprocess
r=Path(__file__).parent;o=r/'original';o.mkdir()
paths=['src/Lokad.Lython/Runtime/Text/PyStringOps.cs','src/Lokad.Lython/Runtime/LythonRuntime.StringMembers.Advanced.cs','src/Lokad.Lython/Runtime/LythonRuntime.CsvObjects.cs','tests/Lokad.Lython.Tests/DirectStringJoinTests.cs','tests/Lokad.Lython.Tests/StringJoinCleanupTests.cs']
for n in paths:
 p=o/n;p.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(n,p)
(r/'selection.json').write_text(json.dumps(dict(baseCommit=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),baselineCoreSHA256='810dafdd2afb684158374098c5b16e850369b7a6ebe2a56e451f3bd96f741d46',paths={n:hashlib.sha256(Path(n).read_bytes()).hexdigest()for n in paths},hypothesis='Remove per-scalar builder operation and already-drained join growing output/iterator; direct measured UTF8 into existing final owned PyString. No new policy/cache/framework. Preserve input lifetimes, all effects, cancellation and refusal.'),indent=2)+'\n',encoding='utf-8',newline='\n')
