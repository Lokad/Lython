from pathlib import Path
import hashlib,json,shutil,subprocess,tarfile,xml.etree.ElementTree as E
r=Path(__file__).parent;base=r.parent/'consume-text-r426';f=r/'frozen';f.mkdir();images={}
for role in ['reference','candidate']:
 target=f/role;shutil.copytree(base/'frozen/candidate',target)
 if role=='candidate':shutil.copyfile('src/Lokad.Lython/bin/Release/net11.0/Lokad.Lython.dll',target/'Lokad.Lython.dll')
 images[role]={p.name:hashlib.sha256(p.read_bytes()).hexdigest()for p in target.iterdir()if p.is_file()}
assert images['reference']['Lokad.Lython.dll']=='810dafdd2afb684158374098c5b16e850369b7a6ebe2a56e451f3bd96f741d46'
assert all(images['candidate'][n]==h for n,h in images['reference'].items()if n!='Lokad.Lython.dll')
paths=list(json.loads((base/'qualification-corrections/frozen/identity.json').read_text(encoding='utf-8'))['sources'])+['tests/Lokad.Lython.Tests/BulkTextConstructionTests.cs'];assert len(set(paths))==598
with tarfile.open(f/'sources-and-checks.tar.xz','w:xz')as a:
 for n in paths:a.add(n,arcname=n)
 a.add(r/'checks',arcname='checks')
identity=dict(buildSourceCommit=json.loads((r/'selection.json').read_text(encoding='utf-8'))['baseCommit'],prototype=True,images=images,sources={n:hashlib.sha256(Path(n).read_bytes()).hexdigest()for n in paths},contracts='One final admitted UTF8 output for expandtabs/join. Preserve private drain/effect/error order, scalar columns, bounded cancellation, live inputs, metadata and aliases. Removed two builder representations and join helper/iterator; no new memory policy/cache/framework.')
(f/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8',newline='\n')
ns={'t':'http://microsoft.com/schemas/VisualStudio/TeamTest/2010'};checks=[dict(file=p.name,**E.parse(p).find('t:ResultSummary/t:Counters',ns).attrib)for p in (r/'checks').glob('*.trx')]
assert sorted(int(x['passed'])for x in checks)==[145,145,412,412]and all(x['failed']=='0'for x in checks)
(r/'focused-checks.json').write_text(json.dumps(dict(checks=checks,nonincrementalReleaseBuild=True,testOnlyFinalBuildNoDependencies=True,fullQualificationPending=True),indent=2)+'\n',encoding='utf-8',newline='\n')
catalog=json.loads((base/'catalog.json').read_text(encoding='utf-8'));ids=['scripts.text-normalization.large','scripts.report-render.format-method.large','scripts.csv-invoice.large','scripts.json-summary-helpers.large'];catalog['cases']=[next(c for c in catalog['cases']if c['id']==n)for n in ids]
for c in catalog['cases']:
 for field,text in [('sourceSha256','source'),('fixtureSha256','fixtureJson'),('expectedOutputSha256','expectedOutput')]:assert hashlib.sha256(c[text].encode()).hexdigest()==c[field]
(r/'catalog.json').write_text(json.dumps(catalog,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
d=r/'allocation-short';d.mkdir()
for n in ['Program.cs','Allocation.csproj']:shutil.copyfile(base/'allocation-short'/n,d/n)
shutil.copyfile(r/'catalog.json',d/'catalog.json');shutil.copyfile(base/'measure-allocation.py',r/'measure-allocation.py')
s=(base/'inspect-vm-generated.py').read_text(encoding='utf-8').replace('finally-prefix-b819-20261116/candidate','compiler-store-b820-20261116/candidate').replace('eee74a1030fc154f3de9e35843fac8b178834ea339ea2f45b282935da0fb55f4','9d26d408ac591aba042f92106167a7cc1df8148b6fc26554f65fa667af5cb5f0')
(r/'inspect-vm.py').write_text(s,encoding='utf-8',newline='\n')
print('Frozen598 inputs', {n:v['Lokad.Lython.dll']for n,v in images.items()},'complete four-workload allocation ready.')
