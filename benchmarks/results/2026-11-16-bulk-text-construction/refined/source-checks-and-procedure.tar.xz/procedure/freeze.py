from pathlib import Path
import hashlib,json,shutil,tarfile,xml.etree.ElementTree as E
r=Path(__file__).parent;old=r.parent;f=r/'frozen';f.mkdir();v=json.loads((old/'frozen/identity.json').read_text(encoding='utf-8'));images={}
for role in ['reference','candidate']:
 target=f/role;shutil.copytree(old/'frozen/reference',target)
 if role=='candidate':shutil.copyfile('src/Lokad.Lython/bin/Release/net11.0/Lokad.Lython.dll',target/'Lokad.Lython.dll')
 images[role]={p.name:hashlib.sha256(p.read_bytes()).hexdigest()for p in target.iterdir()if p.is_file()}
assert all(images['candidate'][n]==h for n,h in images['reference'].items()if n!='Lokad.Lython.dll')
v.update(images=images,sources={n:hashlib.sha256(Path(n).read_bytes()).hexdigest()for n in v['sources']},refinement='Direct bounded join copies and item-loop checkpoints; storage/semantic contract unchanged. Original5eb warm elapsed/CPU regression retained; hypothesis not proven.')
with tarfile.open(f/'sources-and-checks.tar.xz','w:xz')as a:
 for n in v['sources']:a.add(n,arcname=n)
 a.add(r/'checks',arcname='checks')
(f/'identity.json').write_text(json.dumps(v,indent=2)+'\n',encoding='utf-8',newline='\n')
ns={'t':'http://microsoft.com/schemas/VisualStudio/TeamTest/2010'};checks=[dict(file=p.name,**E.parse(p).find('t:ResultSummary/t:Counters',ns).attrib)for p in(r/'checks').glob('*.trx')];assert sorted(int(x['passed'])for x in checks)==[145,145,412,412]and all(x['failed']=='0'for x in checks)
(r/'focused-checks.json').write_text(json.dumps(dict(checks=checks,nonincrementalReleaseBuild=True,fullQualificationPending=True),indent=2)+'\n',encoding='utf-8',newline='\n')
shutil.copyfile(old/'catalog.json',r/'catalog.json');d=r/'allocation-short';d.mkdir()
for n in ['Program.cs','Allocation.csproj']:shutil.copyfile(old/'allocation-short'/n,d/n)
shutil.copytree(old/'allocation-short/bin',d/'bin')
catalog=json.loads((r/'catalog.json').read_text(encoding='utf-8'));catalog['cases']=[c for c in catalog['cases']if c['id']=='scripts.text-normalization.large'];(d/'catalog.json').write_text(json.dumps(catalog,ensure_ascii=False)+'\n',encoding='utf-8',newline='\n')
shutil.copyfile(old/'measure-allocation.py',r/'measure-allocation.py')
s=(old/'inspect-vm.py').read_text(encoding='utf-8').replace('compiler-store-b820-20261116/candidate','bulk-text-b825-20261116/candidate').replace('9d26d408ac591aba042f92106167a7cc1df8148b6fc26554f65fa667af5cb5f0','5ebd657a11ecd0ddea14f82879c78c033f525cff502479eb51b7fb6da8a1322b');(r/'inspect-vm.py').write_text(s,encoding='utf-8',newline='\n')
print('598inputs frozen; refined core',images['candidate']['Lokad.Lython.dll'])
