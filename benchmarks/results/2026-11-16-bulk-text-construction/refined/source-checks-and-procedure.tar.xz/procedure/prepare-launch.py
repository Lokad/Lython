from pathlib import Path
import ast
r=Path(__file__).parent
s=(r.parent/'prepare-and-launch.py').read_text(encoding='utf-8')
s=s.replace("base=r.parent/'consume-text-r426'","base=r.parent.parent/'consume-text-r426'")
s=s.replace("assert delivery['head']==head and proof['inputCount']==597", "assert not subprocess.check_output(['git','diff',delivery['head'],head,'--','src/Lokad.Lython']) and proof['inputCount']==597")
s=s.replace("root='/home/lokad/lython-bench-checks/bulk-text-b825-20261116';unit='lython-b825-bulk-text-20261116'","root='/home/lokad/lython-bench-checks/bulk-text-b826-20261116';unit='lython-b826-bulk-text-20261116'")
s=s.replace("'bulk-text-b825-20261116').replace", "'bulk-text-b826-20261116').replace").replace(".replace('B822','B825')", ".replace('B822','B826')")
s=s.replace("'lython-b825-fixtures'","'lython-b826-fixtures'")
s=s.replace("archive='benchmarks/results/2026-11-16-consuming-text-completion/source-checks-and-procedure.tar.xz'", "archive='benchmarks/results/2026-11-16-bulk-text-construction/source-checks-and-procedure.tar.xz'")
s=s.replace("'frozen/reference/Lokad.Lython.dll'","'frozen/candidate/Lokad.Lython.dll'")
needle="c=dict(root=root,unit=unit,source="
idx=s.index(needle)
s=s[:idx]+'''rawpath='benchmarks/results/2026-11-16-bulk-text-construction/observations.tgz';raw=Path(rawpath).read_bytes();assert subprocess.check_output(['git','show',head+':'+rawpath])==raw
with tarfile.open(rawpath)as a:body=a.extractfile('confirmation/confirmation.json').read()
jsonproof=dict(sha256=hashlib.sha256(body).hexdigest(),bytes=len(body),links=1,paths=['bulk-text-b825-20261116/confirmation/confirmation.json'],custody=dict(commit=head,archive=rawpath,archiveSHA256=hashlib.sha256(raw).hexdigest(),member='confirmation/confirmation.json'))
'''+s[idx:]
s=s.replace('retireGroups=[v]','retireGroups=[v,jsonproof]')
s=s.replace('R429 uncommitted','R429 refined uncommitted').replace('One final admitted UTF8 output for bulk expandtabs/join;', 'Refined direct bounded join copies/item-loop checkpoints; one final admitted UTF8 output for bulk expandtabs/join;')
ast.parse(s);(r/'launch.py').write_text(s,encoding='utf-8',newline='\n')
