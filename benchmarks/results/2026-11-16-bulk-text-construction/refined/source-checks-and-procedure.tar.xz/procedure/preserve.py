from pathlib import Path
import hashlib,json,shutil,tarfile
r=Path(__file__).parent;q=r/'quiet';out=Path('benchmarks/results/2026-11-16-bulk-text-construction/refined');out.mkdir()
receipt=json.loads((q/'archive-receipt.json').read_text(encoding='utf-8'));assert receipt['complete']and receipt['allWorkersJoined'];assert hashlib.sha256((q/'observations.tgz').read_bytes()).hexdigest()==receipt['archiveSHA256']
for n in ['summary.json','allocation-summary.json','focused-checks.json']:shutil.copyfile(r/n,out/n)
for n in ['identity.json','observations.tgz','archive-receipt.json','terminal-status.json']:shutil.copyfile(q/n,out/n)
p=out/'summary.json';v=json.loads(p.read_text(encoding='utf-8'));v.update(retentionDecisionPending=False,retained=True,fullQualificationPending=True,decision='Retain direct final output/ownership simplification and normalization allocation−11.46%. Fresh elapsed1.29–5.26%lower/CPU3.24–7.09%lower, with3.31%reference spread; warm uncertain, original5–7%regression not proven recovered. Report/JSON adverse elapsed and mixed CPU remain accepted debt. No general CPU/embedding-latency gain or broader-goal completion.');p.write_text(json.dumps(v,indent=2)+'\n',encoding='utf-8',newline='\n')
with tarfile.open(out/'source-checks-and-procedure.tar.xz','w:xz')as a:
 for n in ['sources-and-checks.tar.xz','identity.json','reference/Lokad.Lython.dll','candidate/Lokad.Lython.dll']:a.add(r/'frozen'/n,arcname='frozen/'+n)
 for p in r.iterdir():
  if p.is_file():a.add(p,arcname='procedure/'+p.name)
 for n in ['original','checks']:a.add(r/n,arcname=n)
 for p in q.iterdir():
  if p.is_file()and p.name not in ['observations.tgz','payload.tgz','representative.json']:a.add(p,arcname='quiet/'+p.name)
 a.add(r/'catalog.json',arcname='inputs/catalog.json')
 for p in(r/'allocation-short').iterdir():
  if p.is_file():a.add(p,arcname='allocation/'+p.name)
(out/'README.md').write_text('''# Retained direct bulk-text construction

R429/B826,2026-11-16UTC. **efd82707 versus0a04e253 /810dafdd**;598 source/
build/test inputs frozen. Nonincremental Release and145 internal/412 public each
actual.NET11/10 pass. Baseline [full qualification passes](../../2026-11-16-consuming-text-completion/delivery/README.md).
New runtime full delivery is pending at the next coherent checkpoint; publication held.

Both tab expansion and joined text allocate one measured final UTF8 value using
existing admission/ownership. Remove their growing byte-builder stages, JoinStrings
and EnumerateJoinParts. Private input drains remain funded; native coercion occurs
once. Tab columns count Unicode scalars; CR/LF resets, nonpositive widths and
chunk-boundary scalars preserve Python results. Copies/fills and native item loops
retain bounded cancellation; refusal is terminal and rolls back unpublished storage.
No cache, memory policy, public API or replacement dispatch framework is introduced.
Exact final capacity can admit earlier than geometric capacity/overlap; no identical
tiny-threshold promise. Existing genuine snapshots/builders remain where needed.

The [original prototype](../README.md) regressed warm elapsed5.34–7.50% with CPU
support despite less allocation. This refinement removes generic repetition setup
and redundant per-tiny-fragment checks from join, using direct bounded copies and
item-loop checkpoints. The changed helper is a hypothesis, not an isolated causal
measurement; original source, failed conditions and all adverse evidence remain.

| Complete workload / phase | Elapsed candidate/reference | Wider CPU | Reference/candidate process-median spreads |
| --- | ---: | ---: | ---: |
| Normalization warm | −2.58..+4.28% | −3.89..+3.81% | 4.56/2.37% |
| Normalization compile-to-result | −5.26..−1.29% | −7.09..−3.24% | 3.31/0.85% |
| Method report warm | −0.19..+1.78% | −0.30..+1.14% | 1.11/0.86% |
| JSON warm control | +0.96..+1.72% | −0.56..+2.90% | 0.18/0.58% |

All four pairings, not confidence intervals. Four jobs139.786s, two processes/source,
five-second full-request warmups and five rotated approximately half-second rounds.
Warm remains uncertain; the original warm regression is **not proven recovered**.
Fresh has modest supporting CPU evidence, with3.31% moving reference; report/JSON
adverse elapsed/mixed CPU are accepted debt. No universal speedup or embedding-tail
claim. Retain for coherent final-storage ownership and lower complete allocation;
the substantial performance objective remains open.

Independent local natural-GC allocation: **2,171,832→1,922,934B(−11.46%)**;
accounted execution peak **2,606,412→2,515,276B(−3.50%)**. Complete stdout/files
match independent goldens; shared accounting returns to compiled baseline then0.
No local timing claim. Report/invoice were allocation-flat in the original source
pair; they were not remeasured for this nonallocating copy/check refinement.

Quiet Azure F4as_v7/Ubuntu24.04.4, four EPYC9V45 vCPUs,16GiB/no swap,.NET11RC3
ordinary tiering/natural workstation GC. Warm includes mediated RAM I/O, complete
goldens and prior-result cleanup; excludes compilation/startup, reset/protocol and
final cache teardown. Fresh adds compilation/compiled-owner disposal. Wider CPU
includes reset/protocol; separate medians are not additive. No pending-I/O, heap/RSS,
contention or embedding-tail comparison. Accounting peaks are not physical memory.

All image/golden/quiet/budget/Closed/exit/join/archive gates pass. Original5eb VM
image and redundant B825 JSON retired only after exact committed custody and fresh
path/ownership/hash/all-alias proof;810/new images/toolchains/floors remain. All
RAM bytes archived/verified under lease before unmount; no users/fixtures remain.
Terminal cached. Next milestone consolidates duplicate splitlines construction and
fixes its source-demonstrated no-break cancellation gap before further tuning.

[All timing/controls](summary.json),[allocation/ownership](allocation-summary.json),
[raw observations](observations.tgz),[source/images/checks/procedure](source-checks-and-procedure.tar.xz).
''',encoding='utf-8',newline='\n')
p=out.parent/'README.md';s=p.read_text(encoding='utf-8');s+='\n\n[One refined source pair retained](refined/README.md): direct copies/check simplification, allocation−11.46%, modest fresh CPU support, warm uncertainty and adverse controls explicitly retained. Original5eb result above remains unchanged.\n';p.write_text(s,encoding='utf-8',newline='\n')
p=Path('docs/RUNTIME.md');s=p.read_text(encoding='utf-8');needle='Unicode indexing caches use the active caller\'s cancellation context'
idx=s.index(needle);s=s[:idx]+'''Tab expansion measures native UTF-8 and writes one admitted final value in bounded
literal runs and space fills. Joined text drains arbitrary iterables before item
validation, preserving iteration effects and error precedence, then measures and
writes final UTF-8 directly. Its private drain stays funded through output admission
and completion. These operations retain exact output capacity; there is no growing
byte buffer or final payload copy. Exact capacity can admit earlier than geometric
growth and replacement overlap. Actual retained results still fund their storage.

'''+s[idx:];p.write_text(s,encoding='utf-8',newline='\n')
p=Path('docs/BENCHMARKS.md');s=p.read_text(encoding='utf-8');needle='| --- | --- | ---: | --- |';assert s.count(needle)==1;s=s.replace(needle,needle+'\n| Direct bulk-text construction / complete normalization | Fresh elapsed1.3–5.3%lower, supporting CPU; warm inconclusive | −11.46% | Retainedefd82707/810dafdd; accounted peak−3.50%. Original5–7%warm regression and new report/JSON adversity remain debt. [Source pairs/limits](../benchmarks/results/2026-11-16-bulk-text-construction/refined/README.md); full delivery pending. |',1);p.write_text(s,encoding='utf-8',newline='\n')
p=Path('benchmarks/EXPERIMENTS.md');s=p.read_text(encoding='utf-8');s+='\n\n[R429 refinedB826 direct bulk output retained](results/2026-11-16-bulk-text-construction/refined/README.md):efd82707 vs810dafdd; normalization allocation−11.46%/accounted peak−3.50%. Fresh elapsed1.29–5.26%lower/CPU3.24–7.09%lower with3.31%reference spread; warm uncertain, original5–7%regression not proven recovered. Report/JSON adversity/mixed CPU accepted debt. Four jobs139.786s/all gates;145internal/412public eachactual11/10/598inputs. Full delivery pending, next line-construction/cancellation milestone active.\n';p.write_text(s,encoding='utf-8',newline='\n')
print('R429 refinement retained with explicit warm/control debt; all source/evidence preserved.')
