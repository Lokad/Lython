from pathlib import Path
import hashlib
import json
import os
import shutil
import subprocess

out = Path(__file__).resolve().parent
lab = out.parent
base = lab.parent
root = lab.parents[3]
read = lambda path: json.loads(path.read_text(encoding='utf-8-sig'))
save = lambda path, value: path.write_text(json.dumps(value, indent=2)+'\n', encoding='utf-8', newline='\n')
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
profiled = base / 'decoded-closed-defaults-20261124'
old = base / 'packed-block-layout-20261122'
cores = {'reference': profiled/'candidate/Lokad.Lython.dll',
         'candidate': lab/'paged-uniform-build/bin/Lokad.Lython/release_net11.0/Lokad.Lython.dll'}
assert sha(cores['reference']) == read(profiled/'comparison/identity.json')['coreSHA256']['candidate']
catalog=read(lab/'catalog.json')
existing={case['id'] for case in catalog['cases']}
for case in read(base/'reuse-compiler-block-storage-20261122/inspect-catalog.json')['cases']:
    if case['id'] not in existing:
        catalog['cases'].append(case)
save(out/'inspect-catalog.json',catalog)
identity={'fixtureSHA256':sha(out/'inspect-catalog.json'),'workerImages':{}}
for role, core in cores.items():
    identity['workerImages'][role]={}
    for tool, donor in [('inspect',old/'reference/inspect'),('compile',old/'reference/compile'),('benchmark',profiled/'candidate')]:
        dest=out/role/tool
        if dest.exists():
            assert {p.name for p in dest.iterdir()}=={p.name for p in donor.iterdir()}
        else:
            shutil.copytree(donor,dest)
        shutil.copyfile(core,dest/core.name)
        expected={p.name:sha(p) for p in donor.iterdir() if p.is_file()}
        expected[core.name]=sha(core)
        assert {p.name:sha(p) for p in dest.iterdir() if p.is_file()}==expected
        identity['workerImages'][role][tool]=expected
save(out/'inspection-identity.json',identity)
sdk=Path.home()/'.dotnet11'
dotnet=sdk/'dotnet.exe'
env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk),PATH=str(sdk)+os.pathsep+os.environ['PATH'])
for role in cores:
    report=out/(role+'-inspection.json')
    subprocess.run([dotnet,out/role/'inspect/Inspect.dll',out/'inspect-catalog.json',report],env=env,timeout=40,check=True)
    assert read(report)['coreSHA256']==identity['workerImages'][role]['inspect']['Lokad.Lython.dll']
assert read(out/'candidate-inspection.json')['rows']==read(out/'reference-inspection.json')['rows']
shutil.copyfile(lab/'catalog.json',out/'benchmark-catalog.json')
for role in cores:
    worker=out/role/'benchmark/Lokad.Lython.Benchmarks.dll'
    receipt=out/(role+'-verify.json')
    subprocess.run([dotnet,worker,'--compare','verify','--catalog',out/'benchmark-catalog.json','--dotnet',dotnet,
        '--python','C:/Python313/python.exe','--python-worker',root/'benchmarks/cpython-worker.py','--out',receipt],
        env=env,timeout=75,check=True)
    passed=read(receipt)
    assert passed['state']=='Completed' and passed['caseCount']==3
print(len(catalog['cases']),'exact tape and layout matches, three CPython goldens per core')

