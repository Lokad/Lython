#!/bin/bash
set -euo pipefail
cd /mnt/d/code/Lython/.git/agent-worktrees/compiler-block-growth-20261124
export DOTNET_ROOT="$HOME/.dotnet"
export PATH="$DOTNET_ROOT:$PATH"
lab=/mnt/d/code/Lython/.git/agent-notes/review-20261031/current-compiler-storage-20261124/paged-uniform
white='Category!=Stress&(FullyQualifiedName~Executable|FullyQualifiedName~Compiler|FullyQualifiedName~Frontend|FullyQualifiedName~ManagedStackGuard)'
public='Category!=Stress&(FullyQualifiedName~ControlFlow|FullyQualifiedName~CompilerCancellation|FullyQualifiedName~LexicalBindingConstruction|FullyQualifiedName~LexicalPreparationBoundary|FullyQualifiedName~SharedCompilerFact|FullyQualifiedName~CooperativeCancellation|FullyQualifiedName~SharedExecutionBudget|FullyQualifiedName~ExceptionState|FullyQualifiedName~CompileOnceRunMany|FullyQualifiedName~CompiledModuleAnnotation|FullyQualifiedName~AnnotatedHelper)'
dotnet test tests/Lokad.Lython.Tests -c Release -f net11.0 --filter "$white" --artifacts-path "$lab/ubuntu" --nologo > "$lab/ubuntu-white.log" 2>&1 || { tail -50 "$lab/ubuntu-white.log"; exit 1; }
dotnet test tests/Lokad.Lython.PublicApi.Tests -c Release -f net11.0 --filter "$public" --artifacts-path "$lab/ubuntu" --nologo > "$lab/ubuntu-public.log" 2>&1 || { tail -50 "$lab/ubuntu-public.log"; exit 1; }
awk '/Passed!/{count++;print} END{exit count!=2}' "$lab/ubuntu-white.log" "$lab/ubuntu-public.log"
