from pathlib import Path
import ast
import gzip
import hashlib
import json
import os
import shutil
import subprocess
import tarfile

lab=Path(__file__).resolve().parent
root=lab.parents[4]
base=lab.parent.parent
reference=base/'decoded-closed-defaults-20261124'
template=base/'closed-default-evaluation-20261124'
comparison=lab/'comparison'
quiet=comparison/'quiet'
quiet.mkdir(parents=True,exist_ok=True)
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda content:hashlib.sha256(content).hexdigest()
write=lambda p,t:p.write_text(t,encoding='utf-8',newline='\n')
save=lambda p,data:write(p,json.dumps(data,indent=2)+'\n')
canonical=lambda name:subprocess.check_output(['git','show','origin/master:benchmarks/results/2026-11-24-'+name],cwd=root)

def retire(aliases):
    primary=aliases[0][0]
    payload=gzip.decompress(canonical(primary+'/candidate-core.dll.gz'))
    digest=sha(payload)
    records=[]
    for record,unit,role in aliases:
        identity=json.loads(canonical(record+'/identity.json'))
        assert digest==identity['coreSHA256'][role]
        terminal=json.loads(canonical(record+'/terminal-status.json'))
        receipt=terminal['receipt']
        assert not terminal['live'] and not terminal['fixtures'] and terminal['exitCode']=='0'
        assert all(receipt[k] for k in ('complete','allWorkersJoined','guestFixturesRemoved','archivedAndVerifiedUnderLease'))
        assert sha(canonical(record+'/observations.tar.xz'))==receipt['archiveSHA256']
        records.append(dict(path=unit+'/'+role+'/Lokad.Lython.dll',observationSHA256=receipt['archiveSHA256'],source=record))
    return dict(sha256=digest,coreArchive=primary+'/candidate-core.dll.gz',aliases=records)

replicas=[retire([('decoded-ascii-file-values','decoded-ascii-file-values-b1580-20261124','candidate'),
                  ('regex-wrapper-cache','regex-wrapper-cache-b1581-20261124','reference')]),
          retire([('json-traversal','json-traversal-b1586-20261124','candidate'),
                  ('shared-traversal-cpython','shared-traversal-cpython-b1587-20261124','candidate'),
                  ('eager-json-owner','eager-json-owner-b1588-20261124','reference')])]
save(lab/'verified-replicas.json',replicas)

catalog=read(lab/'benchmark-catalog.json')
old=base/'packed-block-layout-20261122/representative.json'
by_id={case['id']:case for case in read(old)['cases']}
dataclass='scripts.dataclass-inherited-configuration.generated'
dead='diagnostic.dead-heavy-validator'
for case_id in (dataclass,dead):catalog['cases'].append(by_id[case_id])
manifest,sparse,factory=[case['id'] for case in catalog['cases'][:3]]
for case in catalog['cases']:
    assert case['sourceSha256']==sha(case['source'].encode('utf-8'))
save(comparison/'representative.json',catalog)
jobs=[(manifest,'compile'),(sparse,'compile'),(factory,'compile'),(dataclass,'compile'),(dead,'compile'),
      (manifest,'compile-run'),(sparse,'compile-run')]
save(comparison/'jobs.json',{'warm':jobs})

reference_identity=read(reference/'comparison/identity.json')
local_identity=read(lab/'inspection-identity.json')
expected_names=reference_identity['imageFiles']['candidate']
image_files={role:{name:files['benchmark'][name] for name in expected_names}
             for role,files in local_identity['workerImages'].items()}
assert image_files['reference']==reference_identity['imageFiles']['candidate']
assert [name for name in image_files['reference'] if image_files['reference'][name]!=image_files['candidate'][name]]==['Lokad.Lython.dll']
for role, files in image_files.items():
    input_image=lab/role/'benchmark'
    image=lab/role/'measured'
    image.mkdir(exist_ok=True)
    for name in files:
        shutil.copyfile(input_image/name,image/name)
    assert len(files)==32 and {p.name:sha(p.read_bytes()) for p in image.iterdir()}==files
    sdk=Path.home()/'.dotnet11'
    dotnet=sdk/'dotnet.exe'
    env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk),PATH=str(sdk)+os.pathsep+os.environ['PATH'])
    receipt=comparison/(role+'-verify.json')
    subprocess.run([dotnet,image/'Lokad.Lython.Benchmarks.dll','--compare','verify','--catalog',comparison/'representative.json',
        '--dotnet',dotnet,'--python','C:/Python313/python.exe','--python-worker',root/'benchmarks/cpython-worker.py','--out',receipt],
        env=env,timeout=75,check=True)
    verified=read(receipt)
    assert verified['state']=='Completed' and verified['caseCount']==5 and verified['catalogSha256']==sha((comparison/'representative.json').read_bytes())

revision=lambda ref:subprocess.check_output(['git','rev-parse',ref],cwd=root,text=True).strip()
meta=dict(sourceRevision=revision('5313f9e71'),candidate=revision('2e32391b5'),purpose='Shared fixed compiler instruction pages',
    imageFiles=image_files,coreSHA256={role+suffix:files['Lokad.Lython.dll'] for role,files in image_files.items() for suffix in ('','-control')},
    cpythonWorkerSHA256=reference_identity['cpythonWorkerSHA256'],expectedCPythonSHA256=reference_identity['expectedCPythonSHA256'],
    catalogs={name:{'sha256':sha((comparison/name).read_bytes())} for name in ('representative.json','jobs.json')})
assert meta['cpythonWorkerSHA256']==sha((root/'benchmarks/cpython-worker.py').read_bytes())
save(comparison/'identity.json',meta)

collector=(template/'comparison/quiet/collect.py').read_text(encoding='utf-8').replace('b1590-','b1592-')
collector=collector.replace('len(jobs) == 6','len(jobs) == 7').replace('started < 315','started < 382')
compile(collector,'collect.py','exec')
write(quiet/'collect.py',collector)
shutil.copyfile(template/'comparison/quiet/run.sh',quiet/'run.sh')
assert b'\r' not in (quiet/'run.sh').read_bytes()
payload=quiet/'payload.tar.gz'
with tarfile.open(payload,'w:gz') as package:
    for item in (comparison/'identity.json',comparison/'representative.json',comparison/'jobs.json',quiet/'run.sh',quiet/'collect.py'):
        package.add(item,arcname=item.name)
    package.add(lab/'candidate/measured/Lokad.Lython.dll',arcname='candidate-core.dll')
save(quiet/'upload.json',dict(root='paged-compiler-storage-b1592-20261124',reference='decoded-closed-defaults-b1591-20261124',
    payloadSHA256=sha(payload.read_bytes()),payloadBytes=payload.stat().st_size))

launcher=(template/'quiet.py').read_text(encoding='utf-8').replace('b1590-closed-default-evaluation','b1592-paged-compiler-storage').replace('b1590-','b1592-')
assert 'captured-local-reads-b1589-20261124' in launcher
allowed={entry['path'] for group in replicas for entry in group['aliases']}
launcher=launcher.replace("assert archive==base/'captured-local-reads-b1589-20261124' and replica==archive/'candidate/Lokad.Lython.dll'",
    'assert replica.relative_to(base).as_posix() in '+repr(sorted(allowed)))
launcher=launcher.replace('RuntimeMaxSec=411','RuntimeMaxSec=460').replace('seconds=336','seconds=405')
remote,=(node.value for node in ast.walk(ast.parse(launcher)) if isinstance(node,ast.Constant) and isinstance(node.value,str) and node.value.startswith('digest=lambda path:'))
compile(remote,'remote-stage','exec')
assert 'os.link(reference/name,root/name)' not in remote
write(lab/'quiet.py',launcher)
summary=(template/'summarize.py').read_text(encoding='utf-8').replace('receipt["warmJobs"] == 6','receipt["warmJobs"] == 7').replace('len(warm["jobs"])==6','len(warm["jobs"])==7').replace('timedBatches=168','timedBatches=196')
compile(summary,'summarize.py','exec')
write(lab/'summarize.py',summary)
print('Verified',len(catalog['cases']),'complete scripts. Prepared',len(jobs),'lanes and',payload.stat().st_size,'bytes.')
