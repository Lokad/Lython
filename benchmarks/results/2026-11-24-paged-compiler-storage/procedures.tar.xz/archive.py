from pathlib import Path
import gzip
import hashlib
import json
import shutil
import subprocess
import tarfile

lab=Path(__file__).resolve().parent
root=lab.parents[4]
comparison=lab/'comparison'
quiet=comparison/'quiet'
read=lambda path:json.loads(path.read_text(encoding='utf-8-sig'))
sha=lambda payload:hashlib.sha256(payload).hexdigest()
identity=read(comparison/'identity.json')
terminal=read(quiet/'terminal-status.json')
receipt=terminal['receipt']
summary=read(quiet/'summary.json')
assert not terminal['live'] and not terminal['fixtures'] and terminal['exitCode']=='0'
assert all(receipt[k] for k in ('complete','allWorkersJoined','guestFixturesRemoved','quietBeforeAndAfter','archivedAndVerifiedUnderLease'))
assert receipt['archiveSHA256']==sha((quiet/'observations.tar.xz').read_bytes())
assert summary['timedBatches']==196 and len(summary['rows'])==7
for role,hashes in identity['imageFiles'].items():
    image=lab/role/'measured'
    assert len(hashes)==32 and {p.name:sha(p.read_bytes()) for p in image.iterdir()}==hashes
    check=read(comparison/(role+'-verify.json'))
    assert check['state']=='Completed' and check['caseCount']==5
assert read(lab/'reference-inspection.json')['rows']==read(lab/'candidate-inspection.json')['rows']
assert len(read(lab/'candidate-inspection.json')['rows'])==14
for platform in ('windows','ubuntu'):
    for kind,n in [('white',378),('public',196)]:
        assert f'Passed: {n:5d}' in (lab/f'{platform}-{kind}.log').read_text(encoding='utf-8-sig')
parent=root/'benchmarks/results'
out=parent/'2026-11-24-paged-compiler-storage'
ref=parent/'2026-11-24-decoded-closed-defaults'/'candidate-core.dll.gz'
assert sha(gzip.decompress(ref.read_bytes()))==identity['coreSHA256']['reference']
out.mkdir(exist_ok=True)
core=(lab/'candidate/measured/Lokad.Lython.dll').read_bytes()
assert sha(core)==identity['coreSHA256']['candidate']
(out/'candidate-core.dll.gz').write_bytes(gzip.compress(core,mtime=0))
assert sha(gzip.decompress((out/'candidate-core.dll.gz').read_bytes()))==identity['coreSHA256']['candidate']
for source,name in {comparison/'identity.json':'identity.json',quiet/'terminal-status.json':'terminal-status.json',
                    quiet/'observations.tar.xz':'observations.tar.xz',quiet/'summary.json':'summary.json',
                    lab/'compile-allocation-summary.json':'allocation-summary.json',
                    lab.parent/'paged-fixed-view/compile-allocation-summary.json':'initial-allocation-summary.json'}.items():
    shutil.copyfile(source,out/name)
for ref,name in ((identity['candidate'],'measured.patch'),('4cea15cf6','initial-paged.patch')):
    (lab/name).write_bytes(subprocess.check_output(['git','diff','--binary',identity['sourceRevision'],ref,'--','src','tests'],cwd=root))
procedures=['archive.py','stage.py','prepare.py','quiet.py','summarize.py','compile-allocation.py','verified-replicas.json',
 'test-ubuntu.sh','inspection-identity.json','inspect-catalog.json','reference-inspection.json','candidate-inspection.json',
 'reference-compile-alloc-0.json','reference-compile-alloc-3.json','candidate-compile-alloc-1.json','candidate-compile-alloc-2.json',
 'comparison/reference-verify.json','comparison/candidate-verify.json','comparison/quiet/launch.log',
 'windows-white.log','windows-public.log','ubuntu-white.log','ubuntu-public.log','initial-paged.patch','measured.patch']
with tarfile.open(out/'procedures.tar.xz','w:xz',preset=4) as archive:
    for name in procedures:archive.add(lab/name,arcname=name)
    for name in ('paged/initial-inspection.log','paged/inspection-identity.json','reordered/block-growth.json',
                 'reordered-expanded/block-growth.json','paged-fixed-view/inspection-identity.json'):
        archive.add(lab.parent/name,arcname='earlier/'+name)
with tarfile.open(out/'procedures.tar.xz') as archive:
    for item in archive:
        source=lab.parent/item.name.removeprefix('earlier/') if item.name.startswith('earlier/') else lab/item.name
        assert sha(archive.extractfile(item).read())==sha(source.read_bytes())
print('Verified and archived B1592, 196 batches, both complete images and all matching tapes')
