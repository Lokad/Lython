from pathlib import Path
import ast,hashlib,json,shutil,subprocess,tarfile

lab=Path(__file__).resolve().parent
previous=lab/'quiet'
quiet=lab/'confirmation'
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda path:hashlib.sha256(path.read_bytes()).hexdigest()
read=lambda p:p.read_text(encoding='utf-8')
def write(path,source):
    if path.suffix=='.py':ast.parse(source)
    path.write_text(source,encoding='utf-8',newline='\n')
def save(path,data):write(path,json.dumps(data,ensure_ascii=False,indent=2)+'\n')

old=load(previous/'config.json')
identity=old['identity']
images=identity['imageFiles']
receipt=load(previous/'archive-receipt.json')
assert receipt['complete'] and receipt['allWorkersJoined'] and receipt['archiveSHA256']==sha(previous/'observations.tgz')
for role,files in images.items():
    assert len(files)==32 and {name:sha(lab/'frozen'/role/name) for name in files}==files
catalog=lab/'catalog.json'
assert sha(catalog)==old['catalogSHA256']

quiet.mkdir(exist_ok=False)
root='/home/lokad/lython-bench-checks/function-binding-confirmation-b1024-20261119'
unit='lython-b1024-function-binding-confirmation-20261119'
jobs=[('scripts.report-forwarding.expanded','warm'),('scripts.report-forwarding.expanded','compile-run'),
      ('scripts.annotated-rule-closures','compile-run')]
runner=read(previous/'collect.py').replace('Function binding ownership source pair','R597 forwarding control confirmation')
a=runner.index('\njobs = ')
b=runner.index('\nassert len(jobs)',a)
write(quiet/'collect.py',(runner[:a]+'\njobs = '+repr(jobs)+runner[b:]).replace('len(jobs)==6','len(jobs)==3'))
write(quiet/'archive-owned.py',read(previous/'archive-owned.py').replace("len(raw['jobs'])==6","len(raw['jobs'])==3").replace('jobs=6,','jobs=3,'))
write(quiet/'run.sh',read(previous/'run.sh').replace(old['root'],root))
save(quiet/'identity.json',identity|dict(purpose='R597 repeat of the adverse forwarding control and annotated compile-to-result'))
names=['collect.py','archive-owned.py','run.sh','identity.json']
payload=quiet/'payload.tgz'
with tarfile.open(payload,'w:gz') as out:
    for name in names:out.add(quiet/name,arcname=name)
expanded=sum((quiet/name).stat().st_size for name in names)
assert receipt['freeBytesAfterArchive']>254*1024*1024+expanded+524288
config=dict(root=root,unit=unit,source=old['root'],sourceRole='candidate',sourceFiles=images['candidate'],
            sourceCatalogSHA256=old['catalogSHA256'],catalogSHA256=sha(catalog),identity=identity,
            retireGroups=[],payloadBytes=payload.stat().st_size,payloadSHA256=sha(payload),unpackedBytes=expanded)
save(quiet/'config.json',config)
launch=read(previous/'remote-launch.py')
a=launch.index('\nc=')+1
b=launch.index('\nb=Path(')
launch=(launch[:a]+'c='+repr(config)+launch[b:]).replace('lython-b1023-fixtures','lython-b1024-fixtures')
launch=launch.replace(" for n,h in c['sourceFiles'].items():assert sha(source/c['sourceRole']/n)==h,n",
    " for role,files in c['identity']['imageFiles'].items():\n  for n,h in files.items():assert sha(source/role/n)==h,n")
launch=launch.replace("os.link(source/c['sourceRole']/n,p)",'os.link(source/role/n,p)')
write(quiet/'remote-launch.py',launch)
write(lab/'launch-confirmation.py',read(lab/'launch-quiet.py').replace("/'quiet'","/'confirmation'").replace('295','154'))
write(quiet/'retrieve.py',read(previous/'retrieve.py').replace("==6","==3"))
write(lab/'summarize-confirmation.py',read(lab/'summarize-quiet.py').replace("quiet/","confirmation/").replace('==6','==3').replace('quiet-summary','confirmation-summary'))
print('Reused the exact frozen images and catalog. No replica retirement needed.')
