from pathlib import Path
import json, os, subprocess

lab=Path(__file__).resolve().parent
repo=Path.cwd()
source = [
    """history = []
def record(label, value):
    history.append(label)
    return value
def decorator(function):
    history.append('decorate')
    return function
@record('decorator expression', decorator)
def function(x: record('parameter', int)=record('default', 3),
             *, y=record('keyword default', 5)) -> record('return', int):
    return x + y
print(history)
print(function(), function.__defaults__, function.__kwdefaults__, function.__annotations__)
""",
    """from __future__ import annotations
def function(x: unresolved.member = 8) -> another:
    return x
print(function(), function.__annotations__)
""",
    """def maker(value):
    def function(x: int=value, *, y: int=7) -> int:
        return (value, x, y)
    return function
first, second = maker(10), maker(20)
print(first(), second(), first.__annotations__ is second.__annotations__)
old = first.__defaults__
first.__defaults__ = (30,)
first.__kwdefaults__['y'] = 15
print(first(), second(), old, first.__annotations__)
""",
    """def generator():
    def function(x=(yield 'default')) -> int:
        return x
    yield function
g = generator()
print(next(g))
f = g.send(26)
print(f(), f.__annotations__)
g.close()
""",
    """history=[]
def publish(function):
    history.append(function)
    raise ValueError('decorator failure')
try:
    @publish
    def function(x: int=8):
        return x
except ValueError:
    print(history[0](), history[0].__annotations__)
""",
    """class Base:
    kind = 'base'
class Message(Base, metaclass=type):
    def get(self, default: int=7) -> int:
        return default
print(Message().get(), Message.get.__annotations__, Message.kind)
""",
    """events=[]
def frame():
    try:
        def function(n: missing=events.append('default')) -> int:
            return n
    except NameError as error:
        events.append(type(error).__name__)
    finally:
        events.append('finally')
frame()
print(events)
""",
    """class AnnotationMap:
    def __setitem__(self, key, value):
        print(key, value)
__annotations__ = AnnotationMap()
message: int = 4
print(message)
""",
    """def identity[T](value: T) -> T:
    return value
print(identity(4), identity.__type_params__, identity.__annotations__)
""",
    """def fn(x: int=3, y: int=4) -> int:
    return x+y
alias = fn.__annotations__
alias['x'] = object
print(fn(), alias is fn.__annotations__, fn.__annotations__['x'] is object)
""",
]
source.extend([
    """def fn(x=2,*,y=3): return x+y
alias=fn.__defaults__
fn.__name__='different'
print(fn(),fn.__name__,alias is fn.__defaults__)
fn.__defaults__=(4,)
fn.__kwdefaults__={'y':6}
print(fn(),alias)
""",
    """def f(a,/,b=2,*,c=3,**other): return a,b,c,other
print(f(1,**{'a':5,'c':7}), f(1,4))
try: f(1,4,**{'b':5})
except TypeError as e: print(type(e).__name__,str(e))
""",
    """from dataclasses import dataclass, field
@dataclass
class Item:
    name: str
    values: list=field(default_factory=list)
a,b=Item('x'),Item('x')
print(a==b,a.values is b.values)
a.values.append(4)
print(a==b)
""",
    """class Factory:
    def create(self,value=3):
        def read(*,v=value): return v
        return read
left,right=Factory().create(),Factory().create(8)
print(left(),right(),left.__kwdefaults__ is right.__kwdefaults__)
""",
    """def call(x=1): return x
class Mapping:
    def keys(self): return []
    def __getitem__(self,key): raise KeyError(key)
def source():
    call.__defaults__=(9,)
    return Mapping()
print(call(**source()))
""",
    """def gen(value=4):
    yield value
a=gen()
gen.__defaults__=(5,)
print(next(a),next(gen()))
""",
])
(lab/'probes.json').write_text(json.dumps(source,ensure_ascii=False)+'\n',encoding='utf-8')
sdk=Path.home()/'.dotnet11'
env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk),PATH=str(sdk)+os.pathsep+os.environ['PATH'])
probes={
 'reference':repo/'.git/agent-worktrees/final-split-operands-r595/tools/LythonProbe/bin/Release/net11.0/LythonProbe.dll',
 'candidate':repo/'.git/agent-worktrees/function-binding-owner-r597/tools/LythonProbe/bin/Release/net11.0/LythonProbe.dll',
}
compared=[]
fields=('Success','StandardOutput','StandardError','ExitCode','Diagnostics','Failure')
for mode in ['sync','async']:
 rows={}
 for label,probe in probes.items():
  args=[str(sdk/'dotnet.exe'),str(probe),'--batch-json','--max-memory-bytes','4194304']
  if mode=='async':args+=['--async']
  actual=subprocess.run(args,env=env,input=(lab/'probes.json').read_bytes(),capture_output=True,timeout=90)
  (lab/f'{label}-{mode}.jsonl').write_bytes(actual.stdout)
  (lab/f'{label}-{mode}.stderr').write_bytes(actual.stderr)
  records=[json.loads(line) for line in actual.stdout.decode('utf-8-sig').splitlines()]
  assert len(records)==len(source),(label,mode,len(records),actual.stderr)
  rows[label]=[{k:r['Lython'].get(k) for k in fields} for r in records]
 differences=[i for i,(a,b) in enumerate(zip(rows['reference'],rows['candidate'])) if a!=b]
 compared.append(dict(mode=mode,matching=len(source)-len(differences),total=len(source),differences=differences))
(lab/'comparison.json').write_text(json.dumps(compared,indent=2)+'\n',encoding='utf-8')
print(compared)
assert all(not row['differences'] for row in compared)
