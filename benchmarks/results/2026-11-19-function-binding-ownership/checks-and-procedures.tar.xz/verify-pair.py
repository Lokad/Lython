from pathlib import Path
import hashlib,json,os,shutil,subprocess

lab=Path(__file__).resolve().parent
repo=Path.cwd()
previous=lab.parent/'final-split-operands-r595'
comparison=lab.parent/'annotation-and-forwarding-cpython-r590'
work=repo/'.git/agent-worktrees/function-binding-owner-r597'
sdk=Path.home()/'.dotnet11'
dotnet=sdk/'dotnet.exe'
env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk),PATH=str(sdk)+os.pathsep+os.environ['PATH'])
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
old_build=previous/'frozen/candidate'
old_manifest=load(previous/'frozen-identity.json')['images']['candidate']
core='Lokad.Lython.dll'
worker='Lokad.Lython.Benchmarks.dll'
assert len(old_manifest)==32 and old_manifest[core].startswith('589d6b7b')
assert all(sha(old_build/name)==digest for name,digest in old_manifest.items())
catalog=lab/'catalog.json'
raw=load(comparison/'representative.json')
control=next(case for case in load(previous/'catalog.json')['cases'] if case['id']=='calls.positional.large')
raw['cases'].append(control)
catalog.write_text(json.dumps(raw,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
assert len(raw['cases'])==4

def run(args, output):
    with (lab/output).open('wb') as log:
        subprocess.run(args,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=110,check=True)
identities={}
for role in ['reference','candidate']:
    image=lab/'frozen'/role
    image.mkdir(parents=True,exist_ok=False)
    for name in old_manifest:
        source=work/'src/Lokad.Lython/bin/Release/net11.0'/core if name==core and role=='candidate' else old_build/name
        shutil.copyfile(source,image/name)
    for source in old_build.glob('ValidatedAllocation.*'):shutil.copyfile(source,image/source.name)
    identities[role]={name:sha(image/name) for name in old_manifest}
    assert all(value==old_manifest[name] for name,value in identities[role].items() if name!=core)
    assert (identities[role][core]!=old_manifest[core])==(role=='candidate')
    run([dotnet,image/worker,'--compare','verify','--catalog',catalog,'--dotnet',dotnet,
         '--python','C:/Python313/python.exe','--python-worker',repo/'benchmarks/cpython-worker.py',
         '--out',lab/(role+'-verify.json')],role+'-verify.log')
    verified=load(lab/(role+'-verify.json'))
    assert verified['state']=='Completed' and verified['catalogSha256']==sha(catalog)
    run([dotnet,image/'ValidatedAllocation.dll',image,catalog,lab/(role+'-allocation.json')],role+'-allocation.log')
    assert all(sha(image/name)==digest for name,digest in identities[role].items())
candidate=subprocess.check_output(['git','-C',str(work),'rev-parse','HEAD'],text=True).strip()
identity=dict(referenceCommit='6ce82ba48',candidateCommit=candidate,casesSHA256=sha(catalog),images=identities)
(lab/'frozen-identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8')
print('Both complete images and the four-case comparison catalog verified.')