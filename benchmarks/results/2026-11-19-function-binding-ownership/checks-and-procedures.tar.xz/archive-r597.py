from pathlib import Path
import gzip,hashlib,json,shutil,subprocess,tarfile

lab=Path(__file__).resolve().parent
out=Path('benchmarks/results/2026-11-19-function-binding-ownership')
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda data:hashlib.sha256(data).hexdigest()
write=lambda p,d:p.write_text(json.dumps(d,indent=2)+'\n',encoding='utf-8',newline='\n')
out.mkdir(exist_ok=False)
cases={c['id']:c for c in load(lab/'catalog.json')['cases']}
candidate=load(lab/'frozen-identity.json')['candidateCommit']
base='6ce82ba48'
images=load(lab/'frozen-identity.json')['images']
for label,local,summary_name,job_count in [
    ('initial','quiet','quiet-summary.json',6),
    ('confirmation','confirmation','confirmation-summary.json',3)
]:
    run=lab/local
    target=out/label
    target.mkdir()
    terminal=load(run/'terminal-status.json')
    receipt=load(run/'archive-receipt.json')
    raw=load(run/'retrieved/confirmation/confirmation.json')
    identity=load(run/'identity.json')
    assert identity['catalogSHA256']==sha((lab/'catalog.json').read_bytes()) and identity['imageFiles']==images
    assert terminal['receipt']==receipt and terminal['exitCode']=='0'
    assert not terminal['remainingWorkers'] and not terminal['remainingTrace']
    assert all(receipt[field] for field in ('complete','allWorkersJoined','guestFixturesRemoved',
                                           'quietBeforeAndAfter','archivedAndVerifiedUnderLease'))
    assert receipt['jobs']==job_count and receipt['archiveSHA256']==sha((run/'observations.tgz').read_bytes())
    assert raw['complete'] and len(raw['jobs'])==job_count
    for job in raw['jobs']:
        assert job['workersJoinedAndFixturesRemoved'] and len(job['samples'])==20
        case=cases[job['case']]
        assert set(job['identities'])==set(identity['coreSHA256'])
        for role, worker in job['identities'].items():
            core=next(lib for lib in worker['libraries'] if Path(lib['path']).name=='Lokad.Lython.dll')
            assert core['sha256'].lower()==identity['coreSHA256'][role]
        for sample in job['samples']:
            response=sample['response']
            assert response['status']=='Completed' and response['completedInvocations']>0
            for key in ['sourceSha256','fixtureSha256','expectedOutputSha256']:
                assert response[key]==case[key]
            assert response['actualOutputSha256']==case['expectedOutputSha256']
            assert response.get('actualFilesSha256')==case.get('expectedFilesSha256')
    summary=load(lab/summary_name)
    summary.update(referenceRuntime=base,measuredPrototype=candidate,cores=identity['coreSHA256'],
        archiveSHA256=receipt['archiveSHA256'],retentionDecisionPending=False,retained=False,
        reason='Stable adverse forwarding compile-to-result elapsed and CPU in B1024')
    write(target/'summary.json',summary)
    for name in ['observations.tgz','archive-receipt.json','terminal-status.json']:
        shutil.copyfile(run/name,target/name)
core=(lab/'frozen/candidate/Lokad.Lython.dll').read_bytes()
assert sha(core)==images['candidate']['Lokad.Lython.dll']
(out/'prototype-core.dll.gz').write_bytes(gzip.compress(core,mtime=0))
source_patch=subprocess.check_output(['git','diff','--binary',base,candidate,'--','src','tests'])
assert b'+internal abstract class PyFunctionBase : FunctionBindingPlan' in source_patch
(lab/'measured-source.patch').write_bytes(source_patch)
with tarfile.open(out/'checks-and-procedures.tar.xz','w:xz',preset=6) as archive:
    for name in ['measured-source.patch','frozen-identity.json','catalog.json','verify-pair.py',
        'reference-verify.json','candidate-verify.json','reference-allocation.json','candidate-allocation.json',
        'quiet-space.json','canonical-space.py','preflight.json','stage-quiet.py','stage-confirmation.py',
        'launch-quiet.py','launch-confirmation.py','summarize-quiet.py','summarize-confirmation.py',
        'focused-whitebox-win-net11.log','focused-public-win-net11.log','focused-whitebox-wsl-net10.log',
        'focused-public-wsl-net10.log','compare-probes.py','probes.json','comparison.json','reference-sync.jsonl',
        'reference-async.jsonl','candidate-sync.jsonl','candidate-async.jsonl','probe-build-win-net11.log','archive-r597.py']:
        archive.add(lab/name,arcname=name)
    for run in ['quiet','confirmation']:
        for name in ['config.json','identity.json','remote-launch.py','retrieve.py','observe-not-before.json','launch.log']:
            archive.add(lab/run/name,arcname=run+'/'+name)
print('Verified 180 timed golden responses, both terminal and lifetime receipts, patch and exact candidate core.')
