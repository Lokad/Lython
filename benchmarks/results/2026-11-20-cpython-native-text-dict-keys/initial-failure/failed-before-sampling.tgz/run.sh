set -eu
root=/home/lokad/lython-bench-checks/native-text-dict-keys-cpython-b1248-20261120
trap 'result=$?; printf "%s\n" "$result" > "$root/exit-code.txt"' EXIT
python3 "$root/collect.py"
