from pathlib import Path
import hashlib, json, shlex, subprocess

lab=Path(__file__).resolve().parent
quiet=lab/'quiet'
failed=json.loads(next(quiet.glob('observation-*.json')).read_text(encoding='utf-8'))
assert not failed['live'] and failed['exitCode']=='1' and failed['remainingTrace'] and not failed['remainingWorkers']
assert "KeyError: 'auxiliaryFiles'" in failed['journal']
config=json.loads((quiet/'config.json').read_text(encoding='utf-8'))
folder=lab/'initial-failure'
folder.mkdir()
program=r"""
from pathlib import Path
import fcntl,hashlib,json,os,subprocess,tarfile
root=Path(ROOT); unit=UNIT
base=Path('/home/lokad/lython-bench-checks')
assert root.resolve()==root and root.parent==base and root.name=='native-text-dict-keys-cpython-b1248-20261120'
with (base/'comparison-vm.lock').open('a') as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 service=subprocess.check_output(['systemctl','show',unit+'.service','--property=ActiveState,MainPID,Result'],text=True)
 assert 'MainPID=0' in service and 'ActiveState=failed' in service
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record|[p]ython3.13.*cpython-worker.py'],capture_output=True).returncode==1
 raw=root/'confirmation/confirmation.json'
 record=json.loads(raw.read_text())
 assert not record['complete'] and not record['jobs'] and (root/'exit-code.txt').read_text().strip()=='1'
 fixture=root/'guest-fixtures'
 assert fixture.resolve()==fixture and os.path.ismount(fixture) and not list(fixture.iterdir())
 archive=root/'failed-before-sampling.tgz'
 assert not archive.exists()
 members=[p for p in root.iterdir() if p.is_file() and not p.is_symlink()]+[raw,root/'confirmation/machine-before.json']
 with tarfile.open(archive,'w:gz') as package:
  for p in members: package.add(p,arcname=str(p.relative_to(root)))
 with tarfile.open(archive) as package:
  for p in members: assert package.extractfile(str(p.relative_to(root))).read()==p.read_bytes()
 subprocess.run(['sudo','-n','umount',str(fixture)],check=True)
 fixture.rmdir()
 print(json.dumps(dict(archivedAndVerifiedUnderLease=True,failedBeforeSampling=True,allWorkersJoined=True,
                       guestFixturesRemoved=True,sha256=hashlib.sha256(archive.read_bytes()).hexdigest())))
"""
program=program.replace('ROOT',repr(config['root'])).replace('UNIT',repr(config['unit']))
key=str(Path.home()/'.ssh/id_lython-bench.pem')
ssh='C:/Windows/System32/OpenSSH/ssh.exe'
scp='C:/Windows/System32/OpenSSH/scp.exe'
options=['-i',key,'-o','BatchMode=yes','-o','ConnectTimeout=15']
host='lokad@20.166.121.73'
command=subprocess.run([ssh,*options,host,'python3 -'],input=program,text=True,encoding='utf-8',
                       capture_output=True,timeout=30)
assert command.returncode==0,command.stderr
receipt=json.loads(command.stdout)
output=folder/'failed-before-sampling.tgz'
subprocess.run([scp,*options,host+':'+config['root']+'/'+output.name,output],check=True,timeout=25)
assert hashlib.sha256(output.read_bytes()).hexdigest()==receipt['sha256']
for name,data in (('failure-status.json',failed),('custody.json',receipt)):
 (folder/name).write_text(json.dumps(data,indent=2)+'\n',encoding='utf-8')
print('Failed startup archived and SHA-verified. Empty fixture mount released.')
