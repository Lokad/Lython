from hashlib import sha256
from pathlib import Path
from shutil import copy2, copytree
from subprocess import check_output
import json

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
base = lab.parent / 'ownership-cpython-b1963-20261128/comparison/quiet'
catalog_donor = lab.parent / 'current-checkpoint-b1932-20261128/comparison/quiet'
tool_donor = lab.parent / 'private-outer-owner-b1962-20261128'
pair = lab / 'comparison'
core = 'Lokad.Lython.dll'
build = lab / 'ubuntu-artifacts/bin/Lokad.Lython/release_net11.0' / core
read = lambda path: json.loads(path.read_bytes())
digest = lambda data: sha256(data).hexdigest()
hash_file = lambda path: digest(path.read_bytes())
hashes = lambda directory: {path.name: hash_file(path) for path in directory.iterdir()}


def git(*args):
    return check_output(['git', *args], cwd=repo)


def save(path, contents):
    path.write_text(contents, encoding='utf-8', newline='\n')


def save_json(path, value):
    save(path, json.dumps(value, indent=2) + '\n')


old = read(base / 'identity.json')
reference = old['sourceRevision']
head = git('rev-parse', 'HEAD').decode().strip()
assert reference.startswith('0b50e6fda')
assert not git('diff', reference, head, '--', 'src', 'Directory.Packages.props',
    'Directory.Build.props', 'Directory.Build.targets', 'benchmarks/Lokad.Lython.Benchmarks')
patch = git('diff', '--binary', reference, '--', 'src', 'tests')
assert patch.count(b'diff --git ') == 7
assert not git('ls-files', '--others', '--exclude-standard', '--', 'src', 'tests')
frozen = old['imageFiles']['candidate']
assert len(frozen) == 32 and hashes(base / 'local-image') == frozen
pair.mkdir()
for role in ('reference', 'candidate'):
    copytree(base / 'local-image', pair / role)
copy2(build, pair / 'candidate' / core)
assert not (pair / 'candidate' / core).samefile(build)
images = {role: hashes(pair / role) for role in ('reference', 'candidate')}
assert images['reference'] == frozen
assert {name for name, checksum in images['candidate'].items() if frozen[name] != checksum} == {core}

jobs = [['diagnostic.file-search-first-line', 'warm'], ['scripts.config-edit.small', 'compile-run'],
    ['diagnostic.shipment-row-generator-reduction', 'warm-async']]
cases = {}
for donor in (catalog_donor, base):
    identity = read(donor / 'identity.json')
    donor_path = donor / 'representative.json'
    assert hash_file(donor_path) == identity['catalogs']['representative.json']['sha256']
    catalogue = read(donor_path)
    cases.update({case['id']: case for case in catalogue['cases']})
catalogue['cases'] = [cases[case] for case, _ in jobs]
save_json(pair / 'representative.json', catalogue)
save_json(pair / 'jobs.json', {'warm': jobs})
for name in ('cpython-worker.py', 'collect.py', 'run.sh'):
    copy2(tool_donor / 'comparison' / name, pair / name)
assert hash_file(pair / 'cpython-worker.py') == old['cpythonWorkerSHA256']
assert b'\r' not in (pair / 'run.sh').read_bytes()
(lab / 'candidate.patch').write_bytes(patch)
save_json(pair / 'identity.json', dict(sourceRevision=head, referenceRevision=reference,
    sourcePatchSHA256=digest(patch), imageFiles=images,
    coreSHA256={role + suffix: image[core] for role, image in images.items() for suffix in ('', '-control')},
    expectedCPythonSHA256=old['expectedCPythonSHA256'], cpythonWorkerSHA256=old['cpythonWorkerSHA256'],
    catalogs={name: {'sha256': hash_file(pair / name)} for name in ('representative.json', 'jobs.json')},
    purpose='Replace eager execution builtin dictionaries with a shared index and lazy local bindings.'))

for name in ('measure-allocation.py', 'summarize.py'):
    script = (tool_donor / name).read_text(encoding='utf-8')
    save(lab / name, script.replace("['cases'])==5", "['cases'])==3").replace('["caseCount"] == 5', '["caseCount"] == 3'))
print(head, 'two complete images for three workloads')
