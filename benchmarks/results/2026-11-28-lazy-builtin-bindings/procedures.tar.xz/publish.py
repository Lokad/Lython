from hashlib import sha256
from pathlib import Path
from shutil import copy2
import json
import tarfile

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
out = repo / 'benchmarks/results/2026-11-28-lazy-builtin-bindings'
first = lab / 'comparison'
repeat = lab / 'repeat'
allocation = lab / 'allocation'
read = lambda path: json.loads(path.read_bytes())
digest = lambda path: sha256(path.read_bytes()).hexdigest()

reference = read(first / 'identity.json')
for root in (first, repeat):
    identity = read(root / 'identity.json')
    assert identity['imageFiles'] == reference['imageFiles']
    assert identity['sourcePatchSHA256'] == digest(lab / 'candidate.patch')
    for role, manifest in identity['imageFiles'].items():
        assert {p.name: digest(p) for p in (root / role).iterdir()} == manifest
    assert read(root / 'summary.json')['verifiedTimedBatches'] == 84
    receipt = read(root / 'archive-receipt.json')
    assert receipt['complete'] and receipt['allWorkersJoined'] and receipt['guestFixturesRemoved']
    assert receipt['archiveSHA256'] == digest(root / 'observations.tar.xz')

rows = read(allocation / 'summary.json')
assert len(rows) == 6 and all(row['admittedPeak'][0] == row['admittedPeak'][1]
    and row['compiled'][0] == row['compiled'][1] for row in rows)
for target in ('windows-net11', 'windows-net10', 'ubuntu-net11'):
    for suite, count in (('public', 343), ('whitebox', 60)):
        log = lab / f'{target}-{suite}.log'
        assert 'Failed:     0' in log.read_text(encoding='utf-8')
        assert f'Passed: {count:5d}' in log.read_text(encoding='utf-8')

out.mkdir(exist_ok=True)
for prefix, directory, names in (
    ('initial-', first, ('identity.json', 'summary.json', 'observations.tar.xz')),
    ('repeat-', repeat, ('identity.json', 'summary.json', 'observations.tar.xz')),
    ('allocation-', allocation, ('summary.json', 'identity.json')),
):
    for name in names:
        copy2(directory / name, out / (prefix + name))
        assert digest(out / (prefix + name)) == digest(directory / name)

procedures = {path.name: path for path in lab.iterdir() if path.is_file()
    and path.suffix in ('.log', '.py', '.sh', '.patch')}
for label, folder in (('initial', first), ('repeat', repeat)):
    for name in ('reference-verify.json', 'candidate-verify.json', 'exit-code.txt', 'archive-receipt.json'):
        procedures[f'{label}/{name}'] = folder / name
for path in allocation.glob('*.json'):
    procedures[f'allocation/{path.name}'] = path
with tarfile.open(out / 'procedures.tar.xz', 'w:xz') as archive:
    for name, path in procedures.items():
        archive.add(path, arcname=name)
with tarfile.open(out / 'procedures.tar.xz') as archive:
    for name, path in procedures.items():
        assert sha256(archive.extractfile(name).read()).hexdigest() == digest(path)
print('Verified the two full images in both collections, 168 batches, six ownership observations and three focused targets.')
