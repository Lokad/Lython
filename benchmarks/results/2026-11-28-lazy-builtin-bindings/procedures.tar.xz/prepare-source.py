from pathlib import Path
import re

repo = Path(__file__).resolve().parents[4]
runtime = repo / 'src/Lokad.Lython/Runtime'
frontend = repo / 'src/Lokad.Lython/Frontend'
updates = {}

def edit(file, update):
    original = file.read_text(encoding='utf-8')
    changed = update(original)
    assert changed != original
    updates[file] = changed

def replace(text, before, after):
    assert text.count(before) == 1, before
    return text.replace(before, after)

def state(text):
    first = text.index('    public static readonly HashSet<string> BuiltinNames =\n')
    last = text.index('    public ExecutionState(', first)
    names = text[first:last].strip().split('=', 1)[1].strip().removesuffix(';')
    text = text[:first] + '''    private static readonly Dictionary<string, int> BuiltinSlots = CreateBuiltinSlots();
    public static IReadOnlyCollection<string> BuiltinNames => BuiltinSlots.Keys;

    internal static bool IsBuiltinName(string name) => BuiltinSlots.ContainsKey(name);
    internal static int GetBuiltinSlot(string name) => BuiltinSlots[name];
    internal static bool TryGetBuiltinSlot(string name, out int index) => BuiltinSlots.TryGetValue(name, out index);

    private static Dictionary<string, int> CreateBuiltinSlots()
    {
        string[] names =
''' + '    ' + '\n'.join('    ' + line for line in names.splitlines()) + ''';
        var slots = new Dictionary<string, int>(names.Length, StringComparer.Ordinal);
        for (var i = 0; i < names.Length; i++) slots.Add(names[i], i);
        slots["IOError"] = slots["EnvironmentError"] = slots["OSError"];
        return slots;
    }

''' + text[last:]
    text = replace(text, '''    public ExecutionState(ILythonHost host, LythonRunOptions? options)
        : this(host, options, new Dictionary<string, object>(StringComparer.Ordinal))
    {
    }

''','')
    text = replace(text, '        Dictionary<string, object> builtinVariables,\n','')
    text = replace(text, '        BuiltinVariables = builtinVariables;\n','')
    return replace(text, '    public Dictionary<string, object> BuiltinVariables { get; }',
        '    public LythonRuntime.ExecutionContext.BuiltinBindings BuiltinVariables { get; } = new();')

def builtins(text):
    start = text.index('        private static readonly (string Name, object Value)[] SharedFunctions')
    end = text.index('        // Signature interning',start)
    shared = []
    for line in text[start:end].splitlines()[2:-2]:
        match = re.fullmatch(r'\s*\("([^"]+)", (.+)\),?',line)
        assert match, line
        shared.append(match.groups())
    assert len(shared) == 37
    text = text[:start] + text[end:]
    start = text.index('        private static Dictionary<string, object> CreateBuiltinVariables()')
    original = text[start:]
    entries = dict(re.findall(r'^\s*\["([^"]+)"\] = (.+?),?$',original,re.M))
    assert len(entries) == 67
    exceptions = [key for key,value in entries.items() if value == f'new ExceptionTypeValue("{key}")']
    assert len(exceptions) == 39
    aliases = [key for key,value in entries.items() if value == 'osErrorType']
    assert aliases == ['IOError','EnvironmentError','OSError']
    immutable = dict(object='SharedCoreTypes.Object', type='SharedCoreTypes.Type',
        Ellipsis='PyEllipsis.Instance', NotImplemented='PyNotImplemented.Instance')
    private = [(key,value) for key,value in entries.items()
        if key not in exceptions and key not in aliases and key not in immutable]
    shared = list(immutable.items()) + shared
    return text[:start] + '''        internal sealed class BuiltinBindings
        {
            private static readonly object?[] SharedValues = CreateSharedValues();
            private object?[]? _runValues;

            public IEnumerable<string> Keys => ExecutionState.BuiltinNames;

            public object this[string name] => TryGetValue(name, out var value)
                ? value : throw new KeyNotFoundException(name);

            public bool TryGetValue(string name, [MaybeNullWhen(false)] out object value)
            {
                if (!ExecutionState.TryGetBuiltinSlot(name, out var index))
                {
                    value = null;
                    return false;
                }

                value = SharedValues[index] ?? GetRunValue(index, name);
                return true;
            }

            private object GetRunValue(int index, string name)
                => (_runValues ??= new object?[SharedValues.Length])[index] ??= CreateRunValue(name);

            private static object?[] CreateSharedValues()
            {
                var entries = new object?[ExecutionState.BuiltinNames.Count];
''' + ''.join(f'                entries[ExecutionState.GetBuiltinSlot("{key}")] = {value};\n' for key,value in shared) + '''                return entries;
            }

            private static object CreateRunValue(string name) => name switch
            {
''' + ''.join(f'                "{key}" => {value},\n' for key,value in private) + '''                "IOError" or "EnvironmentError" or "OSError" => new ExceptionTypeValue("OSError"),
''' + ''.join(('                ' if i==0 else '                    or ')
              + ' or '.join(f'"{key}"' for key in exceptions[i:i+4])
              + (' => new ExceptionTypeValue(name),\n' if i+4>=len(exceptions) else '\n') for i in range(0,len(exceptions),4)) + '''                _ => throw new InvalidOperationException("Missing builtin value for " + name),
            };
        }
    }
}
'''

def builtins_module(text):
    text = replace(text, '''        private readonly Dictionary<string, object> _builtins;
        private readonly string[] _exportedNames;
        private readonly string[] _memberNames;
''','''        private readonly ExecutionContext.BuiltinBindings _builtins;
        private static readonly string[] PublicNames = ExecutionState.BuiltinNames
            .Append("False")
            .Append("None")
            .Append("True")
            .Where(static name => !name.StartsWith("_", StringComparison.Ordinal))
            .Order(StringComparer.Ordinal)
            .ToArray();
        private static readonly string[] AllNames = PublicNames
            .Append("__debug__")
            .Append("__name__")
            .Order(StringComparer.Ordinal)
            .ToArray();
''')
    start = text.index('        public BuiltinsModule(')
    end = text.index('        public override bool TryGetMember',start)
    return text[:start] + '''        public BuiltinsModule(ExecutionContext context) : base("builtins")
            => _builtins = context.State.BuiltinVariables;

        public override IReadOnlyList<string> ExportedNames => PublicNames;

        public override IReadOnlyList<string> MemberNames => AllNames;

''' + text[end:]

edit(runtime/'ExecutionState.cs', state)
edit(runtime/'LythonRuntime.ExecutionContext.Builtins.cs', builtins)
edit(runtime/'LythonRuntime.ExecutionContext.cs', lambda text: replace(text,
    '''            var builtinVariables = CreateBuiltinVariables();
            State = new ExecutionState(host, options, builtinVariables, regexProvider, regexPrograms);''',
    '''            State = new ExecutionState(host, options, regexProvider, regexPrograms);'''))
edit(runtime/'LythonRuntime.BuiltinsModule.cs', builtins_module)
for path in (frontend/'AbstractState.cs', runtime/'LythonRuntime.BuiltinIterables.cs',runtime/'LythonRuntime.BuiltinObjects.cs'):
    edit(path, lambda text: text.replace('ExecutionState.BuiltinNames.Contains(', 'ExecutionState.IsBuiltinName('))
for path, text in updates.items():
    path.write_text(text, encoding='utf-8', newline='\n')
