#!/bin/bash
set -euo pipefail
cd /mnt/d/code/Lython
lab=.git/agent-notes/review-20261031/builtin-name-slots-b1964-20261128
dotnet="$HOME/.dotnet/dotnet"
unset DOTNET_BUNDLE_EXTRACT_BASE_DIR
"$dotnet" test tests/Lokad.Lython.PublicApi.Tests -c Release -f net11.0 --artifacts-path "$lab/ubuntu-tests" \
  --filter 'Category!=Stress&(FullyQualifiedName~BuiltinDefinitionIsolation|FullyQualifiedName~BuiltinRootIdentity|FullyQualifiedName~Import|FullyQualifiedName~ExceptionMetadata|FullyQualifiedName~TypeNew|FullyQualifiedName~BuiltinModule|FullyQualifiedName~NameResolution|FullyQualifiedName~AdmissionFailureCommandTests)' > "$lab/ubuntu-net11-public.log" 2>&1
"$dotnet" test tests/Lokad.Lython.Tests -c Release -f net11.0 --artifacts-path "$lab/ubuntu-tests" \
  --filter 'Category!=Stress&(FullyQualifiedName~ExecutionStateSubsystem|FullyQualifiedName~DescriptorMethodBinding|FullyQualifiedName~NativeAggregateState|FullyQualifiedName~StaticAnalysis|FullyQualifiedName~Builtin)' > "$lab/ubuntu-net11-whitebox.log" 2>&1
