from pathlib import Path
import ast, gzip, hashlib, io, json, shutil, subprocess, tarfile

repo=Path.cwd()
lab=repo/'.git/agent-notes/review-20261031/lexical-binding-order-r563'
donor=lab.parent/'syntax-validity-r559'
quiet=lab/'quiet'
quiet.mkdir()
read=lambda path:path.read_text(encoding='utf-8')
sha=lambda data:hashlib.sha256(data).hexdigest()

def write(path,text):
    if path.suffix=='.py': ast.parse(text)
    path.write_text(text,encoding='utf-8',newline='\n')

def save(path,value): write(path,json.dumps(value,indent=2)+'\n')

prior=donor/'quiet'
previous=json.loads(read(prior/'config.json'))
space=json.loads(read(lab/'space.json'))
proof=space['core']
original='benchmarks/results/2026-11-18-local-store-slots/candidate-core.dll.gz'
canonical=subprocess.check_output(['git','show','HEAD:'+original])
assert canonical==(repo/original).read_bytes()
image=gzip.decompress(canonical)
assert len(image)==proof['bytes'] and sha(image)==proof['sha256']
proof.update(kind='exact archived superseded consumed-slot replica',canonical=original,
             canonicalSHA256=sha(canonical),member=None,committedBlobVerified=True)
assert len(proof['paths'])==proof['links']==3

identity=json.loads(read(lab/'frozen-identity.json'))
assert len(identity['imageFiles']['reference'])==32
assert identity['imageFiles']['reference']==previous['identity']['imageFiles']['candidate']
assert all(sha((lab/'frozen'/role/name).read_bytes())==h for role,files in identity['imageFiles'].items() for name,h in files.items())
assert identity['catalogSHA256']==sha((lab/'representative.json').read_bytes())
identity['purpose']='Compact lexical binding membership and first-occurrence order together'
root='/home/lokad/lython-bench-checks/lexical-binding-order-b989-20261118'
unit='lython-b989-lexical-binding-order-20261118'
jobs=[('scripts.csv-invoice.large','compile'),('scripts.config-edit.small','compile'),
      ('scripts.config-edit.small','compile-run'),('scripts.text-normalization.helper-list','compile-run'),('calls.positional.large','warm')]
save(lab/'jobs.json',jobs)
collector=read(prior/'collect.py').replace('Syntax validation source pair','Lexical binding order source pair')
a=collector.index('\njobs = '); b=collector.index('\nassert len(jobs)',a)
write(quiet/'collect.py',collector[:a]+'\njobs = '+repr(jobs)+collector[b:])
write(quiet/'archive-owned.py',read(prior/'archive-owned.py'))
write(quiet/'run.sh',read(prior/'run.sh').replace(previous['root'],root))
save(quiet/'identity.json',identity)
shutil.copyfile(lab/'representative.json',quiet/'representative.json')
core='candidate/Lokad.Lython.dll'; (quiet/'candidate').mkdir()
shutil.copyfile(lab/'frozen'/core,quiet/core)
names=['collect.py','archive-owned.py','run.sh','identity.json','representative.json',core]
payload=quiet/'payload.tgz'
with tarfile.open(payload,'w:gz') as archive:
    for name in names: archive.add(quiet/name,arcname=name)
bytes=sum((quiet/name).stat().st_size for name in names)
selected=[proof]
available=space['freeBytes']+proof['bytes']
minimum=254*1024*1024+bytes+131072
choices=[space['observation']] if space['observation'] else []
name='benchmarks/results/2026-11-18-helper-search-attribution/observations.tgz'
archive=subprocess.check_output(['git','show','HEAD:'+name]); assert (repo/name).read_bytes()==archive
choices.append(dict(canonical=name,canonicalSHA256=sha(archive),member=None,links=1,bytes=len(archive),sha256=sha(archive),
    paths=['helper-search-profile-b987-20261118/observations.tgz'],kind='exact committed profiler archive replica',committedBlobVerified=True))
for choice in choices:
    if available > minimum: break
    selected.append(choice); available+=choice['bytes']
assert available>minimum,(available,minimum)

settings=dict(root=root,unit=unit,source=previous['root'],sourceRole='candidate',sourceFiles=identity['imageFiles']['reference'],
              sourceCatalogSHA256=previous['catalogSHA256'],catalogSHA256=identity['catalogSHA256'],identity=identity,
              retireGroups=selected,payloadBytes=payload.stat().st_size,payloadSHA256=sha(payload.read_bytes()),unpackedBytes=bytes)
save(quiet/'config.json',settings)
launcher=read(prior/'remote-launch.py')
a=launcher.index('\nc=')+1; b=launcher.index('\nb=Path(')
write(quiet/'remote-launch.py',(launcher[:a]+'c='+repr(settings)+launcher[b:]).replace('lython-b985-fixtures','lython-b989-fixtures'))
write(lab/'launch.py',read(donor/'launch.py').replace('Syntax validation source pair','Lexical binding order source pair'))
write(quiet/'retrieve.py',read(prior/'retrieve.py').replace('Syntax validation source pair','Lexical binding order source pair'))
write(lab/'summarize.py',read(donor/'summarize.py'))
print('Preflight ready with',bytes,'payload bytes. Verified matching archive blobs and exact selected inodes.')
