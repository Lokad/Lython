from pathlib import Path
import shutil,subprocess,os
root=Path.cwd(); bench=root/'.git/agent-notes/review-20261031'
lab=bench/'lexical-binding-order-r563'; origin=bench/'frontend-phases-r526/decompose'
phase=lab/'phase'; phase.mkdir()
text=(origin/'Program.cs').read_text(encoding='utf-8-sig')
text=text.replace('or "scripts.csv-invoice.large" or "scripts.report-render.large"','or "scripts.csv-invoice.large" or "scripts.config-edit.small"')
text=text.replace('            var diagnostics = SyntaxValidityDiagnostics.Analyze(parsed.Script);', '''#if STAGE_CHANGED
            var diagnostics = SyntaxValidityDiagnostics.Analyze(parsed.Script, out var hasDirectives, default);
#else
            const bool hasDirectives = true;
            var diagnostics = SyntaxValidityDiagnostics.Analyze(parsed.Script);
#endif''')
text=text.replace('            StaticScopeDirectiveDiagnostics.Analyze(analysis);','            if (hasDirectives) StaticScopeDirectiveDiagnostics.Analyze(analysis);')
text=text.replace('Local Windows diagnostic decomposition of unchanged qualified core.','Local Windows diagnostic decomposition of the specified frozen/reference core or exact source candidate.')
core='Lokad.Lython.dll'
shutil.copyfile(bench/'branch-state-r548/representative.json',lab/'representative.json')
sdk=Path.home()/'.dotnet11'; env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk),PATH=str(sdk)+os.pathsep+os.environ['PATH'])
images=[('reference',bench/'syntax-validity-r559/frozen/candidate'/core),
        ('candidate',root/'.git/agent-worktrees/lexical-binding-order-r563/src/Lokad.Lython/bin/Release/net11.0'/core)]
for role,image in images:
    target=phase/role; target.mkdir()
    shutil.copyfile(origin/'decompose.csproj',target/'phase.csproj')
    (target/'Program.cs').write_text(text,encoding='utf-8',newline='\n')
    args=[sdk/'dotnet.exe','build',target/'phase.csproj','-c','Release','--nologo',f'-p:InspectionCorePath={image}']
    args.append('-p:DefineConstants=STAGE_CHANGED')
    with (lab/f'{role}-phase.log').open('w',encoding='utf-8') as output:
        subprocess.run(args,env=env,cwd=root,stdout=output,stderr=subprocess.STDOUT,check=True,timeout=60)
    subprocess.run([sdk/'dotnet.exe',target/'bin/Release/net11.0/Lokad.Lython.WhiteBox.Tests.dll',lab/'representative.json',lab/f'{role}-phase.json'],env=env,cwd=root,check=True,timeout=75)
print('Both exact core images produced current phase diagnostics.')
