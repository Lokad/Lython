from pathlib import Path
import fcntl, hashlib, json, os, shutil, stat, subprocess
root=Path('/home/lokad/lython-bench-checks').resolve()
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
with (root/'comparison-vm.lock').open('a') as lease:
    fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
    assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record|[p]ython3.*cpython-worker.py'],capture_output=True).returncode==1
    assert not any(os.path.ismount(p) for p in root.glob('*/guest-fixtures'))
    anchor=root/'local-store-slot-b979-20261118/candidate/Lokad.Lython.dll'
    m=anchor.lstat(); assert sha(anchor)=='93739eed3a00abecbae026ee0e0bfc748e57485379d29316f4858e3b3a6bc9ef'
    paths=[]
    for parent,_,names in os.walk(root):
        for n in names:
            p=Path(parent)/n; v=p.lstat()
            if (v.st_dev,v.st_ino)!=(m.st_dev,m.st_ino): continue
            assert p.resolve()==p and p.is_relative_to(root) and p.name==anchor.name and stat.S_ISREG(v.st_mode)
            assert v.st_uid==os.getuid() and v.st_size==m.st_size and v.st_nlink==m.st_nlink and sha(p)=='93739eed3a00abecbae026ee0e0bfc748e57485379d29316f4858e3b3a6bc9ef'
            paths.append(p.relative_to(root).as_posix())
    assert len(paths)==m.st_nlink
    obs={'canonical': 'benchmarks/results/2026-11-18-exact-list-drain/observations.tgz', 'canonicalSHA256': 'a48081595bcbee6792b9745cdd418193b3313bfc80054034c6511e1dc58a91e8', 'member': 'confirmation/confirmation.json', 'links': 1, 'bytes': 479256, 'sha256': 'ab147ed705249f4ec725ff280992b59da6bfa3a2654f212804eed4418297a8a5', 'paths': ['exact-list-drain-b988-20261118/confirmation/confirmation.json'], 'kind': 'exact committed raw observation replica', 'committedBlobVerified': True, 'optional': True}; p=root/obs['paths'][0]; recorded=None
    if p.exists():
        v=p.lstat(); assert p.resolve()==p and p.is_relative_to(root) and stat.S_ISREG(v.st_mode)
        assert v.st_uid==os.getuid() and v.st_nlink==1 and v.st_size==obs['bytes'] and sha(p)==obs['sha256']
        recorded=obs
    print(json.dumps(dict(freeBytes=shutil.disk_usage(root).free,core=dict(paths=sorted(paths),sha256='93739eed3a00abecbae026ee0e0bfc748e57485379d29316f4858e3b3a6bc9ef',bytes=m.st_size,links=m.st_nlink),observation=recorded)))
