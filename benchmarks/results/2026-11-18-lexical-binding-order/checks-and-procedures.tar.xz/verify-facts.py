from pathlib import Path
import shutil,subprocess,os,json
r=Path.cwd(); n=r/'.git/agent-notes/review-20261031'; lab=n/'lexical-binding-order-r563'
phase=lab/'facts';phase.mkdir()
input=json.loads((lab/'representative.json').read_text(encoding='utf-8'))
cases=[x['source'] for x in input['cases']]+[
'def f(x):\n z=3\n y=x\n z=4\n if False:\n  w=1\n return locals()\nprint(f(2))',
'a=10\ndef outer(p):\n q=1\n def inner(p):\n  global a\n  nonlocal q\n  z=1\n  q=z\n  y=p\n  return q,a,y\n return inner(p)\nprint(outer(3))',
'fn=lambda a,b=2: ((c:=a+b),(d:=c+1),(c:=d))\nprint(fn(1))',
'class C:\n z=1\n a=2\n z=3\n def selftype(self):\n  return __class__\n def nested(self):\n  return (lambda: __class__)()\nprint(C().selftype(), C().nested())',
'class Base:\n def method(self):return 1\nclass C(Base):\n def method(self):\n  return super().method()\n def remove(self):\n  del (self.a,self.b)\nprint(C().method())',
'def outer():\n t=1\n class C:\n  nonlocal t\n  t=8\n return t\nprint(outer())',
'match [1,2]:\n case [left,right] if (middle:=right):\n  last=left\nprint(last)',
'def f(x: int = 3) -> int:\n y: int\n return x\nprint(f())',
'def g():\n first=0\n yield (future:=first)\n first=2\n yield future',
'def f(x):\n global x',
]
(lab/'fact-inputs.json').write_text(json.dumps(cases,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
sdk=Path.home()/'.dotnet11';env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk),PATH=str(sdk)+os.pathsep+os.environ['PATH'])
for role in ['reference','candidate']:
    p=phase/role;p.mkdir();shutil.copyfile(lab/'BindingFacts.cs.txt',p/'Program.cs');shutil.copyfile(n/'frontend-phases-r526/decompose/decompose.csproj',p/'facts.csproj')
    image=lab/'frozen'/role/'Lokad.Lython.dll'
    with (lab/f'facts-{role}.log').open('w',encoding='utf-8') as log:
        subprocess.run([sdk/'dotnet.exe','build',p/'facts.csproj','-c','Release',f'-p:InspectionCorePath={image}'],cwd=r,env=env,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=90)
    subprocess.run([sdk/'dotnet.exe',p/'bin/Release/net11.0/Lokad.Lython.WhiteBox.Tests.dll',lab/'fact-inputs.json',lab/f'facts-{role}.json'],cwd=r,env=env,check=True,timeout=60)
a,b=[json.loads((lab/f'facts-{role}.json').read_text(encoding='utf-8-sig')) for role in ['reference','candidate']]
assert a==b and len(a)==len(cases)
print(len(cases),'identical syntax diagnostics and lexical scope captures,',sum(len(x['facts'])for x in a),'scope entries')
