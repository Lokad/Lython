from pathlib import Path
import hashlib,json,os,shutil,subprocess

lab=Path(__file__).resolve().parent
repo=Path.cwd()
worktree=repo/'.git/agent-worktrees/deferred-keyword-default-dictionary'
donor=lab.parent/'dynamic-record-layout'
load=lambda f:json.loads(f.read_text(encoding='utf-8-sig'))
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
def write(path,value):
    path.write_text(json.dumps(value,indent=2)+'\n',encoding='utf-8',newline='\n')
def git(*args):
    return subprocess.check_output(['git',*args])

development_base=git('rev-parse','576434749').decode().strip()
candidate=git('-C',worktree,'rev-parse','HEAD').decode().strip()
identity=load(donor/'frozen-identity.json')
reference=identity['candidateCommit']
assert git('merge-base',development_base,candidate).decode().strip()==development_base
assert not git('diff','--name-only',reference,development_base,'--','src','tests','benchmarks/Lokad.Lython.Benchmarks','benchmarks/cpython-worker.py','global.json','Directory.Build.props','Directory.Packages.props')
assert not git('-C',worktree,'status','--porcelain')
(lab/'measured-source.patch').write_bytes(git('diff','--binary',development_base,candidate))

catalog=load(lab.parent/'lazy-positional-defaults/catalog.json')
ids={'scripts.rule-default-closures','scripts.annotated-rule-closures','scripts.annotated-rule-closures.nested-factories',
    'scripts.csv-invoice.large','scripts.dataclass-inherited-configuration.generated'}
catalog['cases']=[case for case in catalog['cases'] if case['id'] in ids]
ordinary=next(case for case in catalog['cases'] if case['id']=='scripts.rule-default-closures')
source=ordinary['source'].replace('    total += apply(index) + fallback(index)',
    "    weights = apply.__kwdefaults__, fallback.__kwdefaults__\n"
    "    total += apply(index) + fallback(index) + weights[0]['weight'] + weights[1]['scale']")
assert source!=ordinary['source'] and '__kwdefaults__' in source
expected=subprocess.check_output(['C:/Python313/python.exe','-I','-X','utf8','-c',source]).decode('utf-8').replace('\r\n','\n')
digest=lambda text:hashlib.sha256(text.encode('utf-8')).hexdigest()
catalog['cases'].append(ordinary | dict(id='scripts.rule-default-closures.keyword-observed',source=source,
    expectedOutput=expected,sourceUtf8Bytes=len(source.encode('utf-8')),sourceSha256=digest(source),
    expectedOutputSha256=digest(expected),expectedOutputUtf8Bytes=len(expected.encode('utf-8'))))
assert len(catalog['cases'])==6
manifest=lab/'catalog.json'
write(manifest,catalog)
sdk=Path.home()/'.dotnet11'
dotnet=sdk/'dotnet.exe'
env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk),PATH=str(sdk)+os.pathsep+os.environ['PATH'])
files=identity['images']['candidate']
origin=donor/'frozen/candidate'
core='Lokad.Lython.dll'
assert len(files)==32 and {name:sha(origin/name) for name in files}==files
images={}
for role in ('reference','candidate'):
    image=lab/'frozen'/role
    image.mkdir(parents=True,exist_ok=True)
    for name in files:
        shutil.copyfile(origin/name,image/name)
    expected=files.copy()
    if role=='candidate':
        built=lab/'build-win/bin/Lokad.Lython/release_net11.0'/core
        shutil.copyfile(built,image/core)
        expected[core]=sha(built)
    verify=lab/(role+'-verify.json')
    with (lab/(role+'-verify.log')).open('wb') as log:
        subprocess.run([dotnet,image/'Lokad.Lython.Benchmarks.dll','--compare','verify','--catalog',manifest,
            '--dotnet',dotnet,'--python','C:/Python313/python.exe','--python-worker',repo/'benchmarks/cpython-worker.py',
            '--out',verify],env=env,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=140)
    verified=load(verify)
    assert verified['state']=='Completed' and verified['catalogSha256']==sha(manifest)
    assert {name:sha(image/name) for name in expected}==expected
    images[role]=expected
assert images['reference'][core]!=images['candidate'][core]
write(lab/'frozen-identity.json',dict(referenceCommit=reference,developmentBase=development_base,
    candidateCommit=candidate,casesSHA256=sha(manifest),images=images))
