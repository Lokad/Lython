set -eu
root=/home/lokad/lython-bench-checks/keyword-default-dictionary-b1182-20261120
trap 'result=$?; printf "%s\n" "$result" > "$root/exit-code.txt"' EXIT
python3 "$root/collect.py"
