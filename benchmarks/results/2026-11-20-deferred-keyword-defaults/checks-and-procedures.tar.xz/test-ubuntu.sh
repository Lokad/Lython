set -eu
export DOTNET_ROOT="$HOME/.dotnet"
export PATH="$DOTNET_ROOT:$PATH"
lab=$1
filter='(FullyQualifiedName~Defaults|FullyQualifiedName~DefaultMetadata|FullyQualifiedName~DefaultConstruction|FullyQualifiedName~FunctionDefinition|FullyQualifiedName~FunctionBinding|FullyQualifiedName~FunctionSlot|FullyQualifiedName~Dataclass|FullyQualifiedName~Annotation|FullyQualifiedName~Lambda|FullyQualifiedName~AdmissionFailureCommand|FullyQualifiedName~AsyncMidFlightCancellation|FullyQualifiedName~GeneralBoundMethod)&Category!=Stress'
for suite in Lokad.Lython.Tests Lokad.Lython.PublicApi.Tests; do
    log="$lab/$suite-continuation-ubuntu.log"
    dotnet test "tests/$suite/$suite.csproj" -c Release -f net10.0 --artifacts-path "$lab/linux" --filter "$filter" >"$log" 2>&1 || { tail -n 45 "$log"; exit 1; }
    tail -n 8 "$log"
done
