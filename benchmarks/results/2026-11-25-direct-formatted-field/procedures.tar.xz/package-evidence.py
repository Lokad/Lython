from pathlib import Path
import subprocess, hashlib, tarfile, shutil, json, re
lab=Path(__file__).resolve().parent
tree=Path('.git/agent-worktrees/direct-formatted-field-20261125')
out=Path('benchmarks/results/2026-11-25-direct-formatted-field')
quiet=lab/'comparison/quiet'
read=lambda p:json.loads(p.read_text(encoding="utf-8-sig"))
identity=read(quiet/'identity.json')
for section,name in (('src','candidate.patch'),('tests','tests.patch')):
 diff=subprocess.check_output(['git','-C',str(tree),'diff','--binary','HEAD','--',section])
 assert diff==(lab/name).read_bytes()
 if section=='src': assert hashlib.sha256(diff).hexdigest()==identity['sourcePatchSHA256']
for suite,count in (('Lokad.Lython.PublicApi.Tests',350),('Lokad.Lython.Tests',25)):
 for target in ('win11','ubuntu10'):
  log=(lab/f'{suite}-{target}.log').read_text(encoding='utf-8-sig')
  assert re.search(rf'Failed:\s+0, Passed:\s+{count},', log)
assert re.search(r'Failed:\s+1, Passed:\s+50,', (lab/'reference-formatted-fields.log').read_text(encoding='utf-8-sig'))
assert read(lab/'tape-summary.json')['identical']
for name in ('identity.json','storage-custody.json'):
 shutil.copyfile(quiet/name,out/name)
for name in ('compile-allocation-summary.json','tape-summary.json','python-continuations.json'):
 shutil.copyfile(lab/name,out/name)
with tarfile.open(out/'procedures.tar.xz','w:xz') as bundle:
 for name in ('candidate.patch','tests.patch','prepare.py','prepare.log','quiet.py','bench-build.log','archive.py','package-evidence.py',
   'compile-allocation.py','compile-allocation.log','reference-compiler-owner.json','candidate-compiler-owner.json',
   'Lokad.Lython.PublicApi.Tests-win11.log','Lokad.Lython.Tests-win11.log','Lokad.Lython.PublicApi.Tests-ubuntu10.log',
   'Lokad.Lython.Tests-ubuntu10.log','reference-formatted-fields.log','test-ubuntu.sh','verified-raw-replicas.json',
   'launch-console.log','retrieve.log','comparison/reference-verify.json','comparison/candidate-verify.json',
   'check-tape.py','tape/Program.cs','tape/Tape.csproj','tape-candidate.json','tape-reference.json','tape.log',
   'recover-working-space.py','initial-image-custody.json'):
  bundle.add(lab/name,arcname=name,recursive=False)
