from pathlib import Path
import hashlib
import json
import shutil
import subprocess
import tarfile

lab=Path(__file__).resolve().parent
root=lab.parents[3]
out=root/'benchmarks/results/2026-11-24-current-compiler-block-growth'
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
summary=read(lab/'run-summary.json')
assert summary['allProcessesJoined'] and summary['totalVerifiedBatches']==1545 and not summary['timingQualification']
assert sha(lab/'catalog.json')==summary['catalogSha']
verification=read(lab/'verification.json')
assert verification['state']=='Completed' and verification['caseCount']==3 and verification['catalogSha256']==summary['catalogSha']
checks=read(lab/'block-growth.json')
assert checks['matchedInstructions'] and len(checks['rows'])==3
roles=['manifest','sparse-validator','postponed-factories']
for role,case in zip(roles, checks['rows'], strict=True):
    record=read(lab/role/'record.json')
    assert record['workload']==case['case'] and record['allProcessesJoined']
    assert sha(lab/role/'compile.nettrace')==record['nettraceSha']
    assert record['coreSha']==checks['images']['reference']['Lokad.Lython.dll']
    assert record['before']['status']==record['after']['status']=='Equivalent'
    assert record['closed']['status']=='Closed'
for index in range(len(roles)):
    assert read(lab/f'growth-reference-{index}.json')['rows']==read(lab/f'growth-diagnostic-{index}.json')['rows']
assert sha(lab/'inspect-diagnostic'/'Lokad.Lython.dll')==checks['images']['diagnostic']['Lokad.Lython.dll']
assert sha(lab/'inspect-reference'/'Lokad.Lython.dll')==checks['images']['reference']['Lokad.Lython.dll']
patch=subprocess.check_output(['git','-C','.git/agent-worktrees/compiler-block-growth-20261124','diff','--','src'],cwd=root)
(lab/'instrumentation.patch').write_bytes(patch)
assert patch.count(b'diff --git')==2
out.mkdir(exist_ok=True)
for name in ['attribution.json','block-growth.json','run-summary.json']:
    shutil.copyfile(lab/name,out/name)
files=['archive.py','analyze.py','compile-trace.py','growth.py','catalog.json','verification.json','instrumentation.patch']
files += ['inspect-reference/'+name for name in ('Inspect.dll','Inspect.deps.json','Inspect.runtimeconfig.json')]
files += [f'{role}/{name}' for role in roles for name in ('record.json','compile.nettrace','compile.speedscope.json','worker.stderr','capture.log')]
for index in range(len(roles)):
    files += [f'growth-input-{index}.json']
    for image in ('reference','diagnostic'):
        files += [f'growth-{image}-{index}.{suffix}' for suffix in ('json','stderr')]
with tarfile.open(out/'observations.tar.xz','w:xz',preset=4) as archive:
    for name in files:archive.add(lab/name,arcname=name)
with tarfile.open(out/'observations.tar.xz') as archive:
    for record in archive:
        assert hashlib.sha256(archive.extractfile(record).read()).hexdigest()==sha(lab/record.name)
print('Archived and verified three compiler traces and tape-identical growth counts')
