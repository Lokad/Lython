from collections import Counter
from pathlib import Path
import hashlib
import json
import os
import shutil
import subprocess
import tempfile

lab=Path(__file__).resolve().parent
root=lab.parents[3]
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda path:hashlib.sha256(path.read_bytes()).hexdigest()
save=lambda path,data:path.write_text(json.dumps(data,indent=2)+'\n',encoding='utf-8',newline='\n')
donor=lab.parent/'csv-target-publication-20261124'
images={}
cores={
    'reference':lab.parent/'decoded-closed-defaults-20261124/candidate/Lokad.Lython.dll',
    'diagnostic':lab/'instrumented/bin/Lokad.Lython/release_net11.0/Lokad.Lython.dll',
}
sdk=Path.home()/'.dotnet11'
env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk),PATH=str(sdk)+os.pathsep+os.environ['PATH'])
base=read(lab/'catalog.json')
rows=[]
for role,core in cores.items():
    image=lab/('inspect-'+role)
    image.mkdir(exist_ok=True)
    for name in ('Inspect.dll','Inspect.deps.json','Inspect.runtimeconfig.json'):
        shutil.copyfile(donor/name,image/name)
    shutil.copyfile(core,image/core.name)
    images[role]={p.name:sha(p) for p in sorted(image.iterdir())}
for index,case in enumerate(base['cases']):
    fixtures=lab/('growth-input-'+str(index)+'.json')
    save(fixtures,dict(base,cases=[case]))
    outputs={}
    for role in images:
        report=lab/('growth-'+role+'-'+str(index)+'.json')
        image=lab/('inspect-'+role)
        command=[sdk/'dotnet.exe',image/'Inspect.dll',fixtures,report]
        with tempfile.TemporaryDirectory(prefix='lython-compiler-growth-') as wd:
            run=subprocess.run(command,env=env,cwd=wd,capture_output=True,timeout=40,check=True,encoding='utf-8')
        (lab/('growth-'+role+'-'+str(index)+'.stderr')).write_text(run.stderr,encoding='utf-8',newline='\n')
        outputs[role]=read(report)
        assert outputs[role]['coreSHA256']==images[role]['Lokad.Lython.dll']
    assert outputs['reference']['rows']==outputs['diagnostic']['rows']
    entries=[json.loads(line.removeprefix('LYTHON_BLOCK_GROWTH ')) for line in run.stderr.splitlines() if line.startswith('LYTHON_BLOCK_GROWTH ')]
    assert entries
    sizes=Counter()
    grows=Counter()
    reopens=Counter()
    for row in entries:
        sizes.update({int(k):v for k,v in row['blockSizes'].items()})
        grows.update({int(k):v for k,v in row['growthByOldCapacity'].items()})
        reopens.update({int(k):v for k,v in row['reopensByPriorLength'].items()})
    record=dict(case=case['id'],codeObjects=len(entries),blockSizes=dict(sorted(sizes.items())),
                growthByOldCapacity=dict(sorted(grows.items())),reopensByPriorLength=dict(sorted(reopens.items())),slotsCopied=sum(k*v for k,v in grows.items()),
                emittedSlots=sum(k*v for k,v in sizes.items()))
    rows.append(record)
    print(record)
assert all({p.name:sha(p) for p in (lab/('inspect-'+role)).iterdir()}==expected for role,expected in images.items())
save(lab/'block-growth.json',dict(images=images,rows=rows,matchedInstructions=True))
