from pathlib import Path
import hashlib,json,shutil,tarfile
r=Path(__file__).parent;i=json.loads((r/'identity.json').read_text(encoding='utf-8'))
assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==h for p,h in i['productionSources'].items())
receipt=json.loads((r/'archive-receipt.json').read_text(encoding='utf-8'));assert receipt['complete']
assert hashlib.sha256((r/'observations.tgz').read_bytes()).hexdigest()==receipt['archiveSHA256']
a=json.loads((r/'attribution.json').read_text(encoding='utf-8'));assert a['guestSamples']==552 and a['samplesWithCoreManagedFrames']==552
out=Path('benchmarks/results/2026-11-08-config-invocation-attribution');out.mkdir()
decision='''R101 source/profile gate closes without builtin initialization redesign.
Complete config warm workload,6.010s wall/4.240s command clocks/2.93guestCPU-s,
552guest samples,31unknown leaves5.62%, all samples contain mapped core frames.
Inclusive factory19(3.44%), wholecontextctor35(6.34%), JSON92(16.67%),
comparisonfilehost274(49.64%);333kernel leaves60.33%. Groups overlap, not additive.
Prefix83.5%inclusive contains nested host/JSON work, not its self-cost.
No lazy factory/shared mutable-root/new scalar representation selected; observed
setup does not justify such machinery. Keep actual host authorization/path checks.
Decoder already uses an ordinary completed-value loop; async method names alone
were not evidence of state-machine overhead. Encoder Advance/AdvanceValue/
PushDictFrame/TryTakePair are actual async methods on normal native values.
Select a bounded source design for completed JSON encoding using existing frames
and only real-suspension continuations. Effect is a hypothesis; this profile does
not isolate encoder cost or predict speedup. Preserve hooks/options/chunks/order,
retained builder/markers/scratch, cancellation/refusal/unwind and host writes.
All original source/CPU/stacks/maps/JIT/unknown evidence preserved. No timing
comparison/new framework/producer/core, no CPython refresh, no objective closure.
B460 terminal/archived/localverified, no workers/fixtures/maps left. Never requery.
'''
(r/'decision.md').write_text(decision,encoding='utf-8')
with tarfile.open(out/'observations.tar.xz','w:xz')as t:
 for p in sorted(r.iterdir()):
  if p.name not in ['retrieved','payload.tgz']:t.add(p,arcname=p.name)
for src,name in [(r/'identity.json','identity.json'),(r/'attribution.json','attribution.json'),(r/'core-source.json','core-source.json')]:shutil.copyfile(src,out/name)
status=dict(status='Source/CPU selection gate completed. No runtime prototype or normal-settings performance claim.',archiveSHA256=hashlib.sha256((out/'observations.tar.xz').read_bytes()).hexdigest(),profileArchiveSHA256=receipt['archiveSHA256'],sourceRevision=i['sourceRevision'],coreSHA256=i['files']['Lokad.Lython.dll'],allGatesPassed=True,noRemainingVMUsersOrFixtures=True)
(out/'status.json').write_text(json.dumps(status,indent=2)+'\n',encoding='utf-8')
readme='''# Configuration invocation attribution — 2026-11-08

R101/B460 at committedc74c5802/core3fb37cc3 closes the bounded setup investigation.
R100 source facts already find unboxed sum accumulation, executable imports and
shared immutable builtin functions/signatures. Exception values have lazy metadata;
naive sharing is not selected from source alone. Public CLR-ingress/BigInteger
projection contracts also prevent casually replacing guest integer representation.

One unchanged complete maintained config-read/edit/write script:16paths/181B,
same source/fixtures/full stdout/file goldens as R97. Six-second wall capture,
4.240s summed command-v2 clocks,2.93guestCPU-s/552samples, CPU-clock/FP199Hz,
6.078command-second warmup/two-second settle. Warmup2048invocation chunks (max64);
capture256invocation batches,52736complete invocations. Compilation/startup excluded.

| Visible boundary | Inclusive guest samples | Guest sample share |
| --- | ---: | ---: |
| Builtin factory |19|3.44%|
| Complete execution-context constructor |35|6.34%|
| JSON work |92|16.67%|
| Comparison file host |274|49.64%|

Inclusive groups overlap and cannot be added as independent costs.333kernel
leaves(60.33%) show filesystem/scheduling work; this is not all attributable to a
single capability check. All552stacks contain mapped core frames;31unresolved
leaves(5.62%) remain. Prefix83.5%inclusive includes nested host/JSON work, not
dispatch self-cost. Guest sampling excludes fixture reset/full-validation work on
host-worker threads, protocol and other process threads. This does not decompose
the guide's elapsed measurements or compare normal-settings performance.
PerfMap/JIT diagnostics affect execution; Ubuntu24.04.4/F4as_v7/.NET11RC3,
optional0.4/worker7cf37ca5 unchanged.

The evidence does not support a dominant builtin-setup bottleneck or justify new
lazy factories/shared mutable roots. Keep host authorization/component checks.
JSON's16.67%inclusive presence warrants a bounded source check, not a speedup
prediction: the decoder already keeps completed values in its ordinary loop.
The encoder still uses actual async Advance/AdvanceValue/PushDictFrame/TryTakePair
methods for native values. The next hypothesis is sharing their completed path
without per-step state machines, retaining existing frames and true suspension.
Any prototype must preserve semantic chunks/options/hooks, admitted owners,
cancellation/first refusal and cleanup and pass a bounded complete-script source pair.

All source/core/auxiliary/Ready/pre-post full goldens/quiet/Closed/exit/join/
fixture/map-copy/archive/local verification gates pass. B460 terminal/cached,
no workers or RAM traces remain. Exact existing B459 core and archive reused/
verified; raw/stacks/maps/JIT listings/unknowns stay persistent. Footprint+25%
and actual payload preflight fit8MiB above240MiB OSfloor. No new core, producer,
runtime framework or CPython replay. Full source qualification remains separate.

[Attribution](attribution.json), [identity](identity.json), [core provenance](core-source.json),
[status](status.json), [raw observations/source/maps](observations.tar.xz).
'''
(out/'README.md').write_text(readme,encoding='utf-8',newline='\n')
p=Path('benchmarks/EXPERIMENTS.md');s=p.read_text(encoding='utf-8')+'''
[R101/B460](results/2026-11-08-config-invocation-attribution/README.md) closes one
bounded config-setup profile atc74c5802/core3fb37cc3:6.010wall/2.93guestCPU-s,
552samples/31unknown(5.62%). Inclusive factory3.44%, fullcontextctor6.34%,
JSON16.67%, comparisonfilehost49.64%; kernel leaves60.33%. Groups overlap; no
causal/normal-settings elapsed claim. No builtin-lazy/global-root/scalar redesign
selected. Decoder already has a completed-value loop; encoder still uses actual
async per-step helpers. Next bounded source design targets completed encoding,
preserving hooks/owners/chunks/current tokens. B460 all gates/archive/local
verification pass; no remaining users/fixtures/maps. Exact B459 core reused.
'''
p.write_text(s,encoding='utf-8',newline='\n')
p=Path('PLAN.md');s=p.read_text(encoding='utf-8');needle='| Regex R68 |';pos=s.index(needle)
s=s[:pos]+'''| R101 | Completed source/profile gate B460/c74c5802/core3fb37cc3.6.010wall/2.93guestCPU-s,552samples/31unknown5.62%, all stacks mapped to core. Inclusive factory3.44%, fullcontextctor6.34%, JSON16.67%, filehost49.64%; kernel leaves60.33%, groups overlap. No setup-lazy/global-root/scalar prototype selected. Decoder already has a completed-value loop; encoder's actual async per-step helpers remain. All gates/archive/localverification pass, no users/fixtures/maps. |
'''+s[pos:]
s=s.replace('and B450-B459 are terminal/cached','and B450-B460 are terminal/cached')
a=s.index('4. **R101:');z=s.index('5. **Independent regex',a)
s=s[:a]+'''4. **R102: completed JSON encoding on the existing traversal.** R101 does
   not show setup dominance; no lazy builtin/global-root/scalar project follows.
   Its JSON16.67%inclusive share is selection evidence, not isolated encoder CPU
   cost or a speedup prediction. Decoder already uses an ordinary completed-value
   loop. JsonEncodeIterator still uses actual async AdvanceAsync, AdvanceValueAsync,
   PushDictFrameAsync and TryTakePairAsync for ordinary native values.

   Proposed simplification: keep its current EmitFrame stack, builder and traversal;
   execute completed operations directly, with small continuations only for actual
   pending option/default callbacks. Remove these four default-path state machines
   and their completed-await transport. Do not add a second synchronous walker,
   generic dispatcher, pending-state framework, options, caches or owners.
   Preserve original scalar/key/container order, exact exposed iterencode chunks,
   Unicode/numbers/pretty/sort/skip/allow_nan/default behavior, circular markers,
   mutation errors and managed nesting. Keep builder/iterators/sorted scratch and
   aliases funded until actual pending users and awaited cleanup finish; first
   admission refusal remains terminal, current cancellation context explicit.
   Completed default replacements may use the existing frame stack/loop while
   preserving recursion limits and callback order.

   Source/implementation bound~30min: stop/refine if this needs new lifetime state,
   broad parser changes or duplicated traversal. Focus existing JSON semantic,
   real-suspension/reentry/cancellation/first-refusal/retained-owner/cleanup tests.
   One short existing-driver allocation diagnostic and one bounded controlled
   complete JSON edit/normalize source pair, with config/CSV/JSON-decode controls;
   independent Python full goldens. Retain adverse/unstable originals and make a
   source/allocation/CPU decision separately. No normal-settings gains inferred
   from the profile. Batch full actual11/10 Windows/Ubuntu/originalStress/installed
   core checks at the retained boundary. Then resume the broader roadmap.

'''+s[z:];p.write_text(s,encoding='utf-8',newline='\n')
print('R101 archived and bounded gate closed; concrete R102 deletion/replacement and semantic/ownership checks written before implementation.')
