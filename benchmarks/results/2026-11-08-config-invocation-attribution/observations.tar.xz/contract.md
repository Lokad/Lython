R101 bounded config invocation-setup CPU attribution at c74c5802/core3fb37cc3.
R100 source gate confirms existing unboxed sum, executable imports and shared
functions/signatures. Remaining mutable builtin/exception roots are not safe to
share naively; profile actual materiality before choosing a redesign.
One complete maintained config-read/edit/write warm script (16paths/181B),
same exact source/fixtures/goldens as R97, no timing comparison/CPython refresh.
Existing R93 perf worker/protocol,6guest-second warmup/2second settle/6second wall
capture at cpu-clock/FP199Hz. 2048-invocation warmup chunks (max64),256-invocation
capture batches keep IPC outside guest attribution; every invocation remains
complete and fully verified. Preserve startup/compilation exclusions and included
guestI/O/prior cleanup. Profiles enable PerfMap/JIT diagnostics: attribution only.
All Ready/core/aux/pre-post full goldens/quiet/Closed/exit/join/fixture/map/archive
gates.120sowner+30stop+30margin; persistent raw/maps/catalog, owned128MiB RAM only
fixtures/temporary CLR maps, copied+hash-verified before cleanup. Prior raw+archive
footprint+25% under8MiB, preflight actual payload above240MiB OSfloor. Reuse B459
core/archive and immutable auxiliary bytes, no new producer/runtime/framework.
One profile then~20min source attribution/selection. If data is unresolved or
setup not material, retain uncertainty and do not invent lazy factories/value
tags. Correct only demonstrated data-quality problems with originals retained.
No weakened cancellation/memory/stack safeguards, no new quotas/configuration.
Full R99 delivery independent; no objective closure/publication.
