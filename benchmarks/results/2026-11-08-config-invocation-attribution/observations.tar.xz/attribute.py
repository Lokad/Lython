from pathlib import Path
import bisect,collections,json,re
r=Path(__file__).parent;folder=r/'retrieved/profiles/config-warm';record=json.loads((folder/'record.json').read_text(encoding='utf-8'))
ranges=[]
for line in(folder/'perf.map').read_text(encoding='utf-8').splitlines():
 a,size,name=line.split(' ',2);ranges.append((int(a,16),int(size,16),name))
ranges.sort();starts=[v[0]for v in ranges]
def resolve(address,name):
 i=bisect.bisect_right(starts,address)-1
 return ranges[i][2]if i>=0 and address<ranges[i][0]+ranges[i][1]else name
guest=set(record['guestTids']);samples=[];current=None
for line in(folder/'perf-stacks.txt').read_text(encoding='utf-8').splitlines()+['']:
 head=re.match(r'^(\d+)/(\d+)\s*$',line)
 if head:
  if current is not None:samples.append(current)
  current=[]if head[2]in guest else None
 elif line.strip()and current is not None:
  m=re.match(r'\s*([0-9a-f]+)\s+(.*)',line)
  if m:current.append((int(m[1],16),resolve(int(m[1],16),m[2])))
 elif not line.strip()and current is not None:
  samples.append(current);current=None
leaf=json.loads((folder/'guest-cpu-leaves.json').read_text(encoding='utf-8'));assert len(samples)==leaf['samples'],(len(samples),leaf['samples'])
patterns=dict(builtinFactory=lambda n:'CreateBuiltinVariables'in n,moduleNamespace=lambda n:'CreateModuleVariables'in n,
 contextConstructor=lambda n:'LythonRuntime+ExecutionContext' in n and '::.ctor('in n,
 stateConstructor=lambda n:'Lokad.Lython.Runtime.ExecutionState' in n and '::.ctor('in n,
 jsonWork=lambda n:'[Lokad.Lython]'in n and ('JsonModule'in n or'JsonEncodeIterator'in n),
 comparisonFileHost=lambda n:'ComparisonFileHost'in n,
 memoryGovernor=lambda n:'[Lokad.Lython]'in n and'MemoryGovernor::'in n,
 instructionPrefix=lambda n:'ExecuteInstructionPrefix'in n)
counts={tag:sum(any(test(n)for _,n in s)for s in samples)for tag,test in patterns.items()}
allcore=sum(any('[Lokad.Lython]'in n for _,n in s)for s in samples)
ctors=collections.Counter(n for s in samples for _,n in set(s)if any(test(n)for tag,test in patterns.items()if tag in ['contextConstructor','stateConstructor','builtinFactory','moduleNamespace']))
out=dict(sourceRevision='c74c5802',guestSamples=len(samples),guestCpuSeconds=leaf['cpuSeconds'],unknownLeaf=leaf['unknown'],samplesWithCoreManagedFrames=allcore,kernelLeafSamples=sum(bool(s)and s[0][0]>=0xffff000000000000 for s in samples),inclusiveSamplePresence=counts,matchingSetupFrames=ctors.most_common(),caveats='Inclusive groups overlap; never add them as independent costs. Inlining/unwind loss and profiler overrides limit causality. Guest sampling excludes host-worker fixture reset/validation/protocol and other threads; no normal-settings elapsed claim.')
(r/'attribution.json').write_text(json.dumps(out,indent=2)+'\n',encoding='utf-8')
print(json.dumps(out,indent=2))
