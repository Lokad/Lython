R101 source/profile gate closes without builtin initialization redesign.
Complete config warm workload,6.010s wall/4.240s command clocks/2.93guestCPU-s,
552guest samples,31unknown leaves5.62%, all samples contain mapped core frames.
Inclusive factory19(3.44%), wholecontextctor35(6.34%), JSON92(16.67%),
comparisonfilehost274(49.64%);333kernel leaves60.33%. Groups overlap, not additive.
Prefix83.5%inclusive contains nested host/JSON work, not its self-cost.
No lazy factory/shared mutable-root/new scalar representation selected; observed
setup does not justify such machinery. Keep actual host authorization/path checks.
Decoder already uses an ordinary completed-value loop; async method names alone
were not evidence of state-machine overhead. Encoder Advance/AdvanceValue/
PushDictFrame/TryTakePair are actual async methods on normal native values.
Select a bounded source design for completed JSON encoding using existing frames
and only real-suspension continuations. Effect is a hypothesis; this profile does
not isolate encoder cost or predict speedup. Preserve hooks/options/chunks/order,
retained builder/markers/scratch, cancellation/refusal/unwind and host writes.
All original source/CPU/stacks/maps/JIT/unknown evidence preserved. No timing
comparison/new framework/producer/core, no CPython refresh, no objective closure.
B460 terminal/archived/localverified, no workers/fixtures/maps left. Never requery.
