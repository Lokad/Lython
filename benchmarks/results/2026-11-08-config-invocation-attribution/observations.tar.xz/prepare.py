from pathlib import Path
import ast,hashlib,json,math,shutil,tarfile
r=Path(__file__).parent;old=r.parent/'remaining-frame-r93';current=r.parent/'default-rsplit-r99'
source=json.loads((current/'identity.json').read_text(encoding='utf-8'))
assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==h for p,h in source['productionSources'].items())
d=json.loads((r.parent/'operand-cpython-r97/representative.json').read_text(encoding='utf-8'));d['cases']=[c for c in d['cases']if c['id']=='scripts.config-edit.small'];assert len(d['cases'])==1
(r/'catalog.json').write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
receipt=json.loads((current/'b459/archive-receipt.json').read_text(encoding='utf-8'));assert receipt['complete']
assert hashlib.sha256((current/'b459/observations.tgz').read_bytes()).hexdigest()==receipt['archiveSHA256']
with tarfile.open(current/'b459/observations.tgz')as a:assert hashlib.sha256(a.extractfile('current-core.dll').read()).hexdigest()==source['coreSHA256']['candidate']
proof=dict(vmArchive='default-rsplit-b459-20261108/observations.tgz',archiveSHA256=receipt['archiveSHA256'],member='current-core.dll',coreSHA256=source['coreSHA256']['candidate'],immutableLocalArtifact='benchmarks/results/2026-11-08-default-rsplit-preparation/observations.tar.xz (nested B459 archive)')
(r/'core-source.json').write_text(json.dumps(proof,indent=2)+'\n',encoding='utf-8')
identity=dict(sourceRevision='c74c5802994826cc9c26414587dd3c73aa97a635',files={'Lokad.Lython.dll':source['coreSHA256']['candidate']},auxiliaryFiles=json.loads((current/'b459/identity.json').read_text(encoding='utf-8'))['auxiliaryFiles'],productionSources=source['productionSources'],qualification='120public/35internal focused actual11/10 plus controlled B459 pass; full CI42479543467 independent/running.',purpose='R101 one complete warm config-script CPU capture; setup dominance unproven, no normal-settings speed claim.')
(r/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8')
for name in ['ops-profile.py','analyze-cpu-guest.py','retrieve.py','run.sh','archive.py','launch.py']:
 s=(old/name).read_text(encoding='utf-8').replace('current-operand-cost-b454','config-setup-cost-b460').replace('lython-b454-current-operand-cost','lython-b460-config-setup-cost').replace('lython-b454','lython-b460').replace('text-warm','config-warm')
 if name=='ops-profile.py':
  s=s.replace('scripts.text-summary-rsplit-helpers.large','scripts.config-edit.small').replace('count = 1  # Deadline bounded; each request remains a complete checked job.','count = 256  # Batch complete invocations to keep IPC outside guest attribution.')
  s=s.replace('request("batch", 512 if lane == "compile" else 1024)','request("batch", 512 if lane == "compile" else 2048)').replace('batches.append(request("batch",1))','batches.append(request("batch",count))')
  s=s.replace('ExecuteInstructionPrefix TryExecuteNativeCall TryLoadDirectCallReceiver TryGetValue SetItem','CreateBuiltinVariables CreateModuleVariables')
 if name=='launch.py':s=s.replace("source=(base/'shared-cased-split-b453-20261108/candidate').resolve()","source=(base/'default-rsplit-b459-20261108/candidate').resolve()")
 if name=='archive.py':s=s.replace('verified immutable B453 archive','verified immutable B459 archive')
 (r/name).write_text(s,encoding='utf-8',newline='\n')
 if name.endswith('.py'):ast.parse(s)
shutil.copyfile(current/'source.patch',r/'source.patch');shutil.copyfile(current/'r100-source-gate.json',r/'source-gate-evidence.json');shutil.copyfile('PLAN.md',r/'pre-measurement-plan.md')
selection='''R101 bounded config invocation-setup CPU attribution at c74c5802/core3fb37cc3.
R100 source gate confirms existing unboxed sum, executable imports and shared
functions/signatures. Remaining mutable builtin/exception roots are not safe to
share naively; profile actual materiality before choosing a redesign.
One complete maintained config-read/edit/write warm script (16paths/181B),
same exact source/fixtures/goldens as R97, no timing comparison/CPython refresh.
Existing R93 perf worker/protocol,6guest-second warmup/2second settle/6second wall
capture at cpu-clock/FP199Hz. 2048-invocation warmup chunks (max64),256-invocation
capture batches keep IPC outside guest attribution; every invocation remains
complete and fully verified. Preserve startup/compilation exclusions and included
guestI/O/prior cleanup. Profiles enable PerfMap/JIT diagnostics: attribution only.
All Ready/core/aux/pre-post full goldens/quiet/Closed/exit/join/fixture/map/archive
gates.120sowner+30stop+30margin; persistent raw/maps/catalog, owned128MiB RAM only
fixtures/temporary CLR maps, copied+hash-verified before cleanup. Prior raw+archive
footprint+25% under8MiB, preflight actual payload above240MiB OSfloor. Reuse B459
core/archive and immutable auxiliary bytes, no new producer/runtime/framework.
One profile then~20min source attribution/selection. If data is unresolved or
setup not material, retain uncertainty and do not invent lazy factories/value
tags. Correct only demonstrated data-quality problems with originals retained.
No weakened cancellation/memory/stack safeguards, no new quotas/configuration.
Full R99 delivery independent; no objective closure/publication.
'''
for n in ['selection.md','contract.md']:(r/n).write_text(selection,encoding='utf-8')
raw=sum((p.stat().st_size+4095)//4096*4096 for p in (old/'retrieved').rglob('*')if p.is_file()and p.name!='current-core.dll')
estimate=math.ceil((raw+(old/'observations.tgz').stat().st_size)*1.25);assert estimate<8*1024*1024,estimate
(r/'sizing.json').write_text(json.dumps(dict(priorRoundedRawBytes=raw,priorArchiveBytes=(old/'observations.tgz').stat().st_size,conservativeTraceArchiveEstimateBytes=estimate,reservedHeadroomBytes=8*1024*1024,osFloorBytes=240*1024*1024,archivedCoreReused=True,noEvidenceDeleted=True),indent=2)+'\n',encoding='utf-8')
with tarfile.open(r/'payload.tgz','w:gz')as a:
 for n in ['ops-profile.py','analyze-cpu-guest.py','archive.py','run.sh','catalog.json','identity.json','source.patch','contract.md','selection.md','sizing.json','core-source.json','pre-measurement-plan.md','source-gate-evidence.json']:a.add(r/n,arcname=n)
print('One6s config CPU profile prepared. Existing core/worker/protocol reused; footprint+25% fits8MiB; no new runtime prototype.')
