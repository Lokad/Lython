from pathlib import Path

lab = Path(__file__).resolve().parent
prior = lab.parent / "csv-numeric-slot-ingress-20261122"
source = (prior / "prove-retirement.py").read_text(encoding="utf-8")
start = source.index('for artifact, catalog, core in (')
end = source.index('    observation = prefix +', start)
source = source[:start] + '''for artifact, old_name, catalog, core in (
    ("2026-11-22-csv-numeric-slot-ingress", "csv-numeric-slot-ingress-20261122", False, True),
    ("2026-11-22-packed-block-layout", "packed-block-layout-20261122", True, False),
    ("2026-11-22-retained-csv-cpython", "retained-csv-cpython-20261122", True, False),
    ("2026-11-20-prepared-format-map-keys", "private-format-map-keys", True, False),
    ("2026-11-22-compiled-literal-defaults-keywords", "compiled-literal-defaults-keywords-20261122", True, False),
):
    old = lab.parent / old_name / "quiet"
    config = json.loads((old / "config.json").read_text(encoding="utf-8"))
    name = Path(config["root"]).name
    prefix = f"benchmarks/results/{artifact}/"
''' + source[end:]
target = lab / "prove-retirement.py"
compile(source, str(target), "exec")
target.write_text(source, encoding="utf-8", newline="\n")
