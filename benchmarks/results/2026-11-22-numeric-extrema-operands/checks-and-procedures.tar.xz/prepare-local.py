from pathlib import Path
import shutil

lab = Path(__file__).resolve().parent
donor = lab.parent / "csv-numeric-slot-ingress-20261122"
shutil.copyfile(donor / "representative.json", lab / "representative.json")
source = (donor / "measure.py").read_text(encoding="utf-8")
source = source.replace('csv-numeric-slot-ingress-20261122', 'numeric-extrema-standalone-20261122')
(lab / "measure.py").write_text(source, encoding="utf-8", newline="\n")

source = (donor / "test-ubuntu.sh").read_text(encoding="utf-8")
source = source.replace('csv-numeric-slot-ingress-20261122', 'numeric-extrema-standalone-20261122')
source = source.replace('FullyQualifiedName~Float|FullyQualifiedName~Numeric)',
                        'FullyQualifiedName~Float|FullyQualifiedName~Numeric|FullyQualifiedName~Cancellation|FullyQualifiedName~Memory)')
source = source.replace('FullyQualifiedName~Csv|FullyQualifiedName~Float|FullyQualifiedName~NumericReport',
                        'FullyQualifiedName~MinMax|FullyQualifiedName~Csv|FullyQualifiedName~NumericReport')
(lab / "test-ubuntu.sh").write_text(source, encoding="utf-8", newline="\n")
assert b'\r' not in (lab / "test-ubuntu.sh").read_bytes()
