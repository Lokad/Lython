from pathlib import Path
import sys

lab = Path(__file__).resolve().parent
prior = lab.parent / "csv-numeric-slot-ingress-20261122"
white, public = (int(count) for count in sys.argv[1:])
source = (prior / "prepare-quiet.py").read_text(encoding="utf-8")
source = source.replace('52d80f93b', 'b6dd01aee')
source = source.replace('(("white", 279), ("public", 1124))', f'(("white", {white}), ("public", {public}))')
source = source.replace('csv-numeric-slot-ingress-b1334', 'numeric-extrema-b1335')
source = source.replace('b1334-csv-numeric-slot-ingress', 'b1335-numeric-extrema')
source = source.replace('b1334-fixtures', 'b1335-fixtures')
source = source.replace('Fixed CSV unpack transports parsed doubles in existing operands', 'Positional numeric extrema consume existing executable operands')
source = source.replace('Fixed CSV numeric slot transport comparison', 'Positional numeric extrema comparison').replace('"465"', '"400"')
source = source.replace('prior = lab.parent / "direct-jump-layout-20261122"', 'prior = lab.parent / "csv-numeric-slot-ingress-20261122"')
source = source.replace('prior_identity["imageFiles"]["candidate"]', 'prior_identity["imageFiles"]["reference"]')
source = source.replace('prior / "frozen" / "candidate"', 'prior / "frozen" / "reference"')
source = source.replace('sourceRole="candidate"', 'sourceRole="reference"')
source = source.replace('[(cases[3], "warm-async"), (cases[0], "compile-run")]', '[(cases[0], "compile-run")]')
source = source.replace('len(jobs)==6', 'len(jobs)==5').replace('jobs=6,', 'jobs=5,').replace("len(raw['jobs'])==6", "len(raw['jobs'])==5").replace("['jobs']==6", "['jobs']==5")
source = source.replace('Prepared six lanes', 'Prepared five lanes')
source = source.replace('"run.sh", "representative.json",\n         "candidate/"', '"run.sh",\n         "candidate/"')
source = source.replace('payload = out / "payload.tgz"', 'assert sha(manifest) == prior_config["catalogSHA256"]\npayload = out / "payload.tgz"')
assert 'sourceRole="reference"' in source and '"warm-async"' not in source
assert '"run.sh", "representative.json"' not in source
target = lab / "prepare-quiet-owned.py"
target.write_text(source, encoding="utf-8", newline="\n")
exec(compile(source, str(target), "exec"))
