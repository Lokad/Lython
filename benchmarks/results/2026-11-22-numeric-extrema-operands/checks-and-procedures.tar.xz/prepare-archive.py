from pathlib import Path
import shutil

lab = Path(__file__).resolve().parent
base = lab.parent
prior = base / "csv-numeric-slot-ingress-20261122"
combined = base / "numeric-extrema-operands-20261122"
for name in ("allocation-summary.json", "identity.json", "initial-build.log", "public-win.log"):
    shutil.copyfile(combined / name, lab / ("combined-" + name))

source = (prior / "archive.py").read_text(encoding="utf-8")
source = source.replace('2026-11-22-csv-numeric-slot-ingress', '2026-11-22-numeric-extrema-operands')
source = source.replace('52d80f93b', 'b6dd01aee').replace('B1334', 'B1335').replace('168', '140')
source = source.replace('(("white", 279), ("public", 1124))', '(("white", 590), ("public", 776))')
source = source.replace('receipt["jobs"] == 6 and len(cases) == 4', 'receipt["jobs"] == 5 and len(cases) == 4')
source = source.replace('[(list(cases)[3],"warm-async"), (list(cases)[0],"compile-run")]', '[(list(cases)[0],"compile-run")]')
assert 'len(raw["jobs"]) == receipt["jobs"] == 5' in source
assert '(("white", 590), ("public", 776))' in source and 'warm-async' not in source
compile(source, str(lab / 'archive.py'), 'exec')
(lab / 'archive.py').write_text(source, encoding='utf-8', newline='\n')
