R103 combined15c06863/core1674 checkpoint, same protocol/normalGC/tiering.
28jobs: existing26 representative compile/warm/compile-to-result cases plus eager
and streamed full4096record JSON normalization warm execution. Their compilation/
compile-to-result unmeasured; do not infer those from warm. Two independent Lython
processes and isolated CPython3.13.16. Same frozen worker7cf/optional0.4.
5swarmup perrole/job,7rotated150msrounds, quiet dedicated F4as_v7, actual.NET11RC3.
620sowner+30stop+30margin; allworkers awaited/ownedfixtures unmounted, persistent
evidence/archive verified locally. Reuse B461 source/core/archive verified.
Full source platform/Stress/package qualification independent/pending.
Guest mediated RAM I/O/full output checks/prior-result cleanup included;
compile/startup/staging/protocol/final cached teardown outside warm timing.
Compilation includes construction/disposal; compile-run includes compilation.
No causal single-change attribution, CPU/RSS/startup/pending-I/O/tail claim, old
debt repayment or broader objective closure. Preserve original named-source guide,
adverse/control observations and all failed conditions. No new framework.
240MiBOSfloor+12MiB for payload/raw/archive (prior26job footprint plus headroom),
fresh preflight before launch. No evidence/core/path deletion/publication.
