from itertools import product
from pathlib import Path
import hashlib,json,os,shutil,subprocess

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
comparison=lab/"comparison"
manifest=json.loads((comparison/"images.json").read_text(encoding="utf-8"))
values=[]
for prefix,indent,first in product(
    ["", "\n", "\r\n", " ", " # header", "\t# header\n\n", "\uFEFF", "\uFEFF\f# header\r\n", "\f\t# header\r", "\n\r\n# header\n", "\u00a0", "\n\u2003\n"],
    ["", " ", "\t", "\t ", " \f", "\f ", "\t\f\t", " \f\t\f"],
    ["", "$", "x=1\n", "print('unterminated\n", "\\\nprint(2)\n", "if True:\n  print(3)\n",
     "from __future__ import annotations\ndef f(x: list[int]): pass\n",
     "f'{1+ 2}'\n", "x=(\n1\n)\n", "\u00a0"]):
    values.append(prefix+indent+first)
matrix=list(dict.fromkeys(values))
source=lab/"indentation-inputs.json"
source.write_text(json.dumps(matrix,ensure_ascii=False),encoding="utf-8")
core="Lokad.Lython.dll"
reference=comparison/"frozen-reference"/core
sdk=Path.home()/".dotnet11"
dotnet=sdk/"dotnet.exe"
env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk),PATH=str(sdk)+os.pathsep+os.environ["PATH"])
with (lab/"diagnostic-build.log").open("wb") as log:
    subprocess.run([dotnet,"build",lab/"DiagnosticProbe.csproj","-c","Release",f"-p:InspectionCorePath={reference}"],env=env,
                   stdout=log,stderr=subprocess.STDOUT,check=True,timeout=90)
records={}
for role in ("reference","candidate"):
    out=lab/"diagnostic-image"/role
    out.mkdir(parents=True,exist_ok=True)
    for name in ("DiagnosticProbe.dll","DiagnosticProbe.deps.json","DiagnosticProbe.runtimeconfig.json"):
        shutil.copyfile(lab/"bin/Release/net11.0"/name,out/name)
    shutil.copyfile(comparison/f"frozen-{role}"/core,out/core)
    assert hashlib.sha256((out/core).read_bytes()).hexdigest()==manifest["imageFiles"][role][core]
    result=lab/(role+"-diagnostics.json")
    subprocess.run([dotnet,out/"DiagnosticProbe.dll",source,result],check=True,env=env,timeout=40)
    records[role]=json.loads(result.read_text(encoding="utf-8"))
diff=[dict(source=text,reference=r,candidate=c)
      for text,r,c in zip(matrix,records["reference"],records["candidate"],strict=True) if r!=c]
(lab/"diagnostic-comparison.json").write_text(json.dumps(dict(cases=len(matrix),differences=diff),indent=2),
                                             encoding="utf-8",newline="\n")
assert not diff,diff[:6]
print(len(matrix),"matching diagnostics, validity, spans and retained balances")
