from pathlib import Path
import hashlib
import json
import shutil
import subprocess

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
base = lab.with_name('current-calls-and-file-cpu-20261124')
donor = lab.with_name('shared-match-bindings-20261124')
quiet = donor/'comparison/quiet'
read = lambda path: json.loads(path.read_text(encoding='utf-8-sig'))
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
ident = read(quiet/'identity.json')
receipt = read(quiet/'terminal-status.json')['receipt']
assert receipt['complete'] and receipt['archiveSHA256'] == sha(quiet/'observations.tar.xz')
commit = subprocess.check_output(['git','rev-parse','4ae7dcc38'], cwd=repo, text=True).strip()
patch = subprocess.check_output(['git','diff','--binary',ident['sourceRevision'],commit,'--','src','tests','docs'], cwd=repo)
assert hashlib.sha256(patch).hexdigest() == ident['sourcePatchSHA256'] == sha(donor/'candidate.patch')
ident.update(sourceRevision=commit, imageFiles={'candidate': ident['imageFiles']['candidate']},
    purpose='Identify current frontend CPU concentrations after sharing pattern bindings',
    donorArchiveSHA256=receipt['archiveSHA256'], profileCatalogSHA256=sha(quiet/'representative.json'),
    profiles=[('classifier-compile','diagnostic.generated-record-classifier','candidate'),
              ('sparse-compile','scripts.config-generated-guards.medium.bad-0.sparse-lexical','candidate'),
              ('manifest-compile','scripts.config-manifest.small','candidate')])
(lab/'identity.json').write_text(json.dumps(ident, indent=2)+'\n', encoding='utf-8', newline='\n')
(lab/'verified-raw-replicas.json').write_text('[]\n', encoding='utf-8', newline='\n')
shutil.copyfile(quiet/'representative.json', lab/'catalog.json')
shutil.copyfile(donor/'comparison/candidate-verify.json', lab/'candidate-verification.json')
shutil.copyfile(base/'run.sh', lab/'run.sh')
assert b'\r' not in (lab/'run.sh').read_bytes()

launcher = (base/'quiet.py').read_text(encoding='utf-8')
launcher = launcher.replace('current-calls-and-file-cpu-b1644','frontend-phase-profile-b1650')
launcher = launcher.replace('b1644-current-calls-and-file-cpu','b1650-frontend-phase-profile')
launcher = launcher.replace('shared-comprehension-facts-20261124','shared-match-bindings-20261124')
launcher = launcher.replace('checked["caseCount"]==5','checked["caseCount"]==3')
collector = (base/'collect.py').read_text(encoding='utf-8')
collector = collector.replace('shared-comprehension-facts-b1642','shared-match-bindings-b1648')
collector = collector.replace('b1644-fixtures','b1650-fixtures')
ops = (base/'ops-profile.py').read_text(encoding='utf-8')
ops = ops.replace('lane = "compile-run" if name.endswith("-through") else "warm"', 'lane = "compile"')
ops = ops.replace('count = 256', 'count = 1024 if name == "manifest-compile" else 256')
analyzer = (base/'analyze.py').read_text(encoding='utf-8')
offset = analyzer.index("\n(r/'attribution.json')")
analyzer = analyzer[:offset] + '''
 phases = {
    'tokenization': ('PythonTokenization','TokenizedSource'),
    'parsing': ('Frontend.Parser','Frontend.PythonParser'),
    'syntax validity': ('SyntaxValidityDiagnostics',),
    'lexical preparation': ('LexicalScopePreparation','ScopeDirectiveFactsCollector'),
    'annotation and name diagnostics': ('AnnotationDiagnostics','StaticNameBindingDiagnostics','StaticScopeDirectiveDiagnostics'),
    'abstract interpretation': ('StaticAbstractInterpreter','AbstractState','StaticBindingEngine','StaticContracts','StaticAbstractValueResolver'),
    'executable construction': ('ExecutableScript','ExecutableStackLayout','ExecutableCodeObject','LoweredScript','LoweredPatternPreparation'),
 }
 attribution=collections.Counter()
 for method,count in collections.Counter(nearest_lython).items():
  group = next((phase for phase, names in phases.items() if any(name in method for name in names)), None)
  if group is None:
   group = 'other frontend' if method.startswith('Lokad.Lython.Frontend.') else 'outside resolved frontend'
  attribution[group] += count
 assert sum(attribution.values()) == len(samples)
 rows[-1]['nearestCompilationPhases'] = dict(attribution)
 rows[-1]['nearestFrontendMethods'] = collections.Counter(m for m in nearest_lython if m.startswith('Lokad.Lython.Frontend.')).most_common()
''' + analyzer[offset:]
for name, source in (('quiet.py', launcher), ('collect.py', collector), ('ops-profile.py', ops), ('analyze.py', analyzer)):
    compile(source, name, 'exec')
    (lab/name).write_text(source, encoding='utf-8', newline='\n')
