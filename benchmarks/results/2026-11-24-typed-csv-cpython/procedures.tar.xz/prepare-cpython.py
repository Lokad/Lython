from pathlib import Path
import hashlib
import json

lab = Path(__file__).resolve().parent
prior = lab.parent / 'short-dictionary-keys-20261124'
source = lab.parent / 'combined-csv-cpython-20261124/comparison/quiet'
origin = lab / 'comparison/quiet'
output = lab / 'external'
output.mkdir(exist_ok=True)
read = lambda path: json.loads(path.read_text(encoding='utf-8'))
sha = lambda data: hashlib.sha256(data).hexdigest()


def write(path, data):
    path.write_text(data,encoding='utf-8',newline='\n')


def save(path, data):
    write(path,json.dumps(data,indent=2,ensure_ascii=False)+'\n')


metadata = read(lab/'comparison/identity.json')
runtime = read(source/'identity.json')
runtime['sourceRevision']=runtime['candidate']=metadata['candidate']
runtime['frozenImage']='/home/lokad/lython-bench-checks/typed-csv-cpython-b1551-20261124/candidate'
runtime['imageFiles']={'candidate':metadata['imageFiles']['candidate']}
runtime['coreSHA256']={role:metadata['coreSHA256']['candidate'] for role in ('candidate','candidate-control')}
complete = read(origin/'terminal-status.json')['receipt']
assert complete['complete'] and complete['archivedAndVerifiedUnderLease']
assert sha((origin/'observations.tar.xz').read_bytes())==complete['archiveSHA256']
for name, digest in runtime['imageFiles']['candidate'].items():
    assert sha((lab/'candidate'/name).read_bytes())==digest
assert runtime['cpythonWorkerSHA256']==metadata['cpythonWorkerSHA256']
(output/'representative.json').write_bytes((lab/'comparison/representative.json').read_bytes())
assert sha((output/'representative.json').read_bytes())==metadata['catalogs']['representative.json']['sha256']
verified=read(lab/'comparison/candidate-verify.json')
assert verified['state']=='Completed' and verified['catalogSha256']==metadata['catalogs']['representative.json']['sha256']
assert verified['launched']['library']['sha256']==runtime['coreSHA256']['candidate']
save(output/'jobs.json', [['scripts.csv-meter-report.typed-unicode',phase] for phase in ('warm','compile-run')])
runtime['catalogs']={name:{'sha256':sha((output/name).read_bytes())} for name in ('representative.json','jobs.json')}
save(output/'identity.json',runtime)
collector=(source/'collect.py').read_text(encoding='utf-8').replace('b1549-','b1551-').replace('len(jobs) == 5','len(jobs) == 2')
collector=collector.replace('CPython checkpoint for retained short-key CSV execution and named regex delivery',
    'CPython checkpoint for retained short text in typed CSV')
compile(collector,'collect.py','exec')
write(output/'collect.py',collector)
summary=(source/'summarize.py').read_text(encoding='utf-8').replace('len(raw["jobs"])==5 and receipt["warmJobs"]==5',
    'len(raw["jobs"])==2 and receipt["warmJobs"]==2')
write(output/'summarize.py',summary)

launch=(prior/'confirm.py').read_text(encoding='utf-8').replace("output = lab / 'confirmation'","output = lab / 'external'")
launch=launch.replace('b1548-confirm-short-dictionary-keys','b1551-typed-csv-cpython').replace(
    'short-dictionary-keys-b1548','typed-csv-cpython-b1551').replace('short-dictionary-keys-b1547','typed-csv-text-b1550')
start=launch.index("    status = json.loads",launch.index("if sys.argv[1] == 'launch':"))
stop=launch.index("    receipt = invoke(script)",start)
launch=launch[:start]+r'''    previous = json.loads((quiet/'terminal-status.json').read_text(encoding='utf-8'))['receipt']
    payload = {name:(output/name).read_text(encoding='utf-8') for name in ('collect.py','identity.json','jobs.json')}
    script = f"payload={payload!r}; checksum={previous['archiveSHA256']!r}\n" + """
with (base/'comparison-vm.lock').open('a') as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert digest(original/'observations.tar.xz')==checksum
 assert not (original/'guest-fixtures').exists()
 assert shutil.disk_usage(base).free>=10*1024*1024
 root.mkdir()
 (root/'candidate').mkdir()
 for name, content in payload.items(): (root/name).write_text(content,encoding='utf-8')
 identity=json.loads((root/'identity.json').read_text(encoding='utf-8'))
 files=identity['imageFiles']['candidate']
 assert len(files)==32
 for name, sha in files.items():
  item=original/'candidate'/name
  assert digest(item)==sha
  os.link(item,root/'candidate'/name)
 for name in ('representative.json','cpython-worker.py','run.sh'):os.link(original/name,root/name)
 assert digest(root/'representative.json')==identity['catalogs']['representative.json']['sha256']
 assert digest(root/'jobs.json')==identity['catalogs']['jobs.json']['sha256']
 assert digest(root/'cpython-worker.py')==identity['cpythonWorkerSHA256']
 assert bytes([13]) not in (root/'run.sh').read_bytes()
subprocess.run(['sudo','-n','systemd-run','--unit='+unit,'--property=User=lokad','--property=WorkingDirectory='+str(root),
 '--property=RuntimeMaxSec=170','--property=TimeoutStopSec=20','--property=KillMode=control-group','/bin/sh',str(root/'run.sh')],check=True)
"""
'''+launch[stop:]
launch=launch.replace('seconds=230','seconds=117')
compile(launch,'external.py','exec')
write(lab/'external.py',launch)
