from pathlib import Path
import hashlib
import json
import shutil
import tarfile

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
external = lab/'external'
output = repo/'benchmarks/results/2026-11-24-typed-csv-cpython'
read = lambda path: json.loads(path.read_text(encoding='utf-8'))
digest = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
terminal = read(external/'terminal-status.json')
receipt = terminal['receipt']
assert not terminal['live'] and not terminal['fixtures'] and terminal['exitCode']=='0'
assert all(receipt[k] for k in ('complete','allWorkersJoined','guestFixturesRemoved',
    'quietBeforeAndAfter','archivedAndVerifiedUnderLease'))
assert receipt['warmJobs']==2 and digest(external/'observations.tar.xz')==receipt['archiveSHA256']
identity=read(external/'identity.json')
summary=read(external/'summary.json')
assert identity['candidate']==summary['source'] and summary['source'].startswith('b3c447420')
assert summary['timedBatches']==56 and summary['cpythonExecutableSHA256']==identity['expectedCPythonSHA256']
assert [item['lane'] for item in summary['rows']]==['warm','compile-run']
assert all(item['case']=='scripts.csv-meter-report.typed-unicode' for item in summary['rows'])
local = read(lab/'comparison/candidate-verify.json')
assert local['state']=='Completed' and local['caseCount']==4
assert local['catalogSha256']==identity['catalogs']['representative.json']['sha256']
assert local['launched']['library']['sha256']==identity['coreSHA256']['candidate']
files = identity['imageFiles']['candidate']
assert len(files)==32 and all(digest(lab/'candidate'/name)==expected for name,expected in files.items())
output.mkdir(exist_ok=True)
for item in ('identity.json','terminal-status.json','observations.tar.xz','summary.json'):
    shutil.copyfile(external/item,output/item)
inputs=('external.py','prepare-cpython.py','archive-external.py','external/summarize.py',
    'external/launch.log','comparison/candidate-verify.json')
with tarfile.open(output/'procedures.tar.xz','w:xz') as bundle:
    for item in inputs: bundle.add(lab/item,arcname=item)
with tarfile.open(output/'procedures.tar.xz') as bundle:
    assert set(bundle.getnames())==set(inputs)
    assert all(bundle.extractfile(item).read()==(lab/item).read_bytes() for item in inputs)
