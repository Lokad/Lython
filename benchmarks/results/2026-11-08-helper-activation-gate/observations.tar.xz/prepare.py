from pathlib import Path
import base64,copy,hashlib,json,os,shutil,subprocess,tempfile
r=Path(__file__).resolve().parent;prior=r.parent/'receiver-contract-r85/binding-correction'
identity=json.loads((prior/'identity.json').read_text(encoding='utf-8'))
assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==h for p,h in identity['productionSources'].items())
catalog=json.loads((prior/'catalog.json').read_text(encoding='utf-8'));cases=[]
for id in ['scripts.csv-summary-functions.large','scripts.text-summary-rsplit-helpers.large']:
 case=next(c for c in catalog['cases']if c['id']==id);src=case['source']
 cut=src.index('import csv')if 'csv-summary' in id else src.index('counts = {}')
 definitions=src[:cut];body=src[cut:]
 inline=body.replace("        if accumulate(row, totals):\n            accepted += 1", "        amount = int(row['amount'])\n        if amount < 0:\n            continue\n        kind = row['kind']\n        totals[kind] = totals.get(kind, 0) + amount\n        accepted += 1")if 'csv-summary' in id else body.replace('for word in words_from_line(line):','for word in line.lower().rsplit():')
 assert inline!=body
 for label,content in [('helper',body),('inline',inline)]:
  c=copy.deepcopy(case);c['id']=id+'.common-main-'+label
  c['source']=definitions+'def main():\n'+''.join('    '+line+'\n'for line in content.splitlines())+'\nmain()\n'
  c['sourceSha256']=hashlib.sha256(c['source'].encode('utf-8')).hexdigest();c['sourceUtf8Bytes']=len(c['source'].encode('utf-8'))
  fixture=json.loads(c['fixtureJson'])
  with tempfile.TemporaryDirectory(prefix='lython-helper-shape-golden-')as folder:
   for name,value in fixture['inputFiles'].items():(Path(folder)/name).write_bytes(base64.b64decode(value))
   done=subprocess.run(['C:/Python313/python.exe','-I','-S','-X','utf8','-c',c['source']],cwd=folder,capture_output=True)
   assert done.returncode==0 and not done.stderr,(c['id'],done.stderr)
   assert done.stdout.decode('utf-8').replace('\r\n','\n')==c['expectedOutput']
   assert all((Path(folder)/name).read_bytes()==base64.b64decode(value)for name,value in fixture['outputFiles'].items())
  cases.append(c)
catalog['cases']=cases;(r/'catalog.json').write_text(json.dumps(catalog,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
for role in ['before','candidate']:shutil.copytree(prior/'images/candidate',r/'images'/role,copy_function=os.link)
(r/'identity.json').write_text(json.dumps(dict(sourceRevision='7796a24f',coreSHA256=identity['coreSHA256']['candidate'],productionSources=identity['productionSources'],purpose='Current helper versus inlined body within identical function scope; both images are byte-identical controls, no runtime redesign or causal binder-only attribution.',limitations='Trusted fixed workload sources are observationally equivalent at full stdout/files boundary. Function call/locals/retention shape differs intentionally; this does not alter product behavior or prove one internal mechanism.'),indent=2)+'\n',encoding='utf-8')
s=(prior/'measure.py').read_text(encoding='utf-8').replace("old=r.parent.parent/'integer-utf8-r45'","old=r.parent/'integer-utf8-r45'")
s=s.replace("[('warm','sync'),('warm','async')]","[('warm','sync')]")
(r/'measure.py').write_text(s,encoding='utf-8')
shutil.copyfile('PLAN.md',r/'pre-measurement-plan.md')
print('Four complete common-main helper/inline cases independently match full CPython stdout/files; identical current images frozen. No runtime source change.')
