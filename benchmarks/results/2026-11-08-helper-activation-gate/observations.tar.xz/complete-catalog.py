from pathlib import Path
import json,shutil
r=Path(__file__).resolve().parent
shutil.copyfile(r/'catalog.json',r/'catalog-initial-four.json');shutil.copyfile(r/'measure.py',r/'measure-initial-four.py')
d=json.loads((r/'catalog.json').read_text(encoding='utf-8'))
prior=json.loads((r.parent/'receiver-contract-r85/binding-correction/catalog.json').read_text(encoding='utf-8'))
d['cases'].append(next(c for c in prior['cases']if c['id']=='scripts.report-render.large'));assert len(d['cases'])==5
(r/'catalog.json').write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
s=(r/'measure.py').read_text(encoding='utf-8').replace("folder=r/(phase+'-'+api)","folder=r/(phase+'-'+api+'-five')")
(r/'measure.py').write_text(s,encoding='utf-8')
shutil.copyfile('PLAN.md',r/'pre-measurement-plan-refined.md')
print('Existing driver requires exactly five rows. Added unchanged report control; original four-row prelaunch refusal retained. No measurement was started or discarded.')
