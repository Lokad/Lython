from pathlib import Path
import json,statistics
r=Path(__file__).resolve().parent
d=json.loads((r/'warm-sync-five/measurements.json').read_text(encoding='utf-8'))
assert all(d[k]for k in ['allGoldensPassed','allBalancesZero','ownedFixturesRemoved','imageIsolationVerified'])
roles=['before','before-control','candidate'];cases={}
for o in d['observations']:
 cases[o['caseId']]={role:dict(milliseconds=statistics.median(s['executionMilliseconds']/s['jobs']for s in o['samples']if s['image']==role),allocatedBytes=statistics.median(s['allocatedBytes']/s['jobs']for s in o['samples']if s['image']==role))for role in roles}
 identities=o['identities'];assert len({identities[role]['Lokad.Lython.dll']for role in roles})==1
comparisons={}
for family in ['scripts.csv-summary-functions.large','scripts.text-summary-rsplit-helpers.large']:
 helper=cases[family+'.common-main-helper'];inline=cases[family+'.common-main-inline']
 comparisons[family]={role:dict(elapsedPercent=100*(inline[role]['milliseconds']/helper[role]['milliseconds']-1),allocationPercent=100*(inline[role]['allocatedBytes']/helper[role]['allocatedBytes']-1),allocationDifferenceBytes=inline[role]['allocatedBytes']-helper[role]['allocatedBytes'])for role in roles}
out=dict(sourceRevision='7796a24f',sameCoreAcrossAllRoles=True,cases=cases,sourceShapeContrasts=comparisons,limitations='Diagnostic source contrast within common main-function scope; cases execute sequentially, same-process ALC/GC/tiering and no controlled temporal pairing. It measures function/local/retention shape together, not causal binder-only cost or an implementation speedup. Original four-case driver prelaunch refusal retained.')
(r/'assessment.json').write_text(json.dumps(out,indent=2)+'\n',encoding='utf-8')
print(json.dumps(comparisons,indent=2))
for id,obs in cases.items():print(id,'same-binary elapsed spread%',round(100*(max(o['milliseconds']for o in obs.values())/min(o['milliseconds']for o in obs.values())-1),3))
