# Lokad.Lython 0.11.0

Updated 2026-11-08. Git-ignored; never force-add. Publication/tagging postponed.
Objective: coherent simplification and substantial complete-script performance.
Another isolated experiment does not finish that objective. Active work below;
historical narratives, rejected designs, original failed conditions and raw data
stay in benchmarks/EXPERIMENTS.md and results. Docs describe current implementation.

## Actual delivery status

| Milestone | Actual status |
| --- | --- |
| Compiler-fact correction, direct UTF-8 formatting/storage, native helper returns | Committed/fully qualified. Native returns allocation−19.92/−19.31%, original elapsed diagnostic. Formatting allocation−8.67%, controlled B102 elapsed/CPU−5–8%; original15.125ms adverse remains unexplained/preserved. No unchanged qualification replay. |
| Retained R62–R76 | Fully qualified; history preserves70267889,824fc6bb,7a81a629,f88191f7+a34f56b5,68d5bffe,33b6c191,79657355+c384956f,38f53c33/06651b11. Compiler facts/native calls/sequence/tuple storage, JSON floats, inline/final UTF-8 storage remain. R71 slower arenas/control/wide carriers, R72 coarseCPU+6.67%, R74 drift and all failed/adverse conditions remain evidence, not current performance claims. |
| R78/R79 | Fully qualified af481194+5b9d569a and913ea550: shared receiver declarations, callback/signature correctness fixes, native workstate before lexical contexts. Existing measured function optimizations preserved. Cached full-delivery receipts; details in EXPERIMENTS/results. |
| R80/R81 attribution; R82 prepared consumers | Attribution/source gates completed71445454; no unsupported namespace/value/accounting redesign selected. R82 production91f15a3e fully qualified CI42451722109; source consistency retained, allocation neutral, modest/mixed elapsed. |
| R77/R83 CPython checkpoints | Guides accurately identify measured38f53c33 and latest91f15a3e, not today's HEAD. Latest B446:26jobs539.117s; compile/warm/compile-to-result and I/O/validation/prior cleanup separated. Ordinary helper warm2.12–2.23×CPython remains a substantial gap. Original failures/uncertainty preserved. |
| R84/R85/R86 | Canonical receivers committed02c76e52/coreaa4acebe; B448 allocation45–52%lower/elapsed22–24%lower, controls/debt explicit. Full CI42457767068 failed; binding correction corecc6b1b15 passes focused actual11/10 and preserves allocation benefit, no new controlled elapsed claim. Corrected-source full delivery pending. R86 CSV attribution completed/archived, not a timing comparison or source qualification. |
| Regex R68 | Exact immutable0.5.0-dev.55/d6067925:86internal/514public per actual11/10, unchanged bridge. Development compatibility only. Normal optional0.4 pin/core unchanged; affected final released adapter qualification pending, independent implementation continues. |

Completed milestones and original evidence remain in benchmarks/EXPERIMENTS.md
and linked results; the table is delivery status, not a replay queue.
Latest fully qualified runtime91f15a3e; all earlier terminal receipts cached.
Never requery/re-dispatch terminal runs or imply that this qualifies later changes.
Allocation reduction, elapsed, coarseCPU and embedding latency are distinct.
R76's float debt and R79's CSV debt are separately accepted; unrelated gains do
not repay them. Preserve native-text/report/control uncertainty and adverse originals.

## Active deliverables

1. R84 source/CPU attribution complete and preserved; B447 terminal/verified, no
   users/fixtures. R85 canonical receiver consolidation RETAINED, final coreaa4acebe,
   committed/pushed02c76e52 (production matches the frozen inventory). Typed no-arg targets, LoadCallReceiver/name
   heuristic, duplicated routing, provider closures and wrappers removed. Common
   declarations serve immediate/exposed/native-return calls; existing fusion/type
   proof unchanged. Fixed-arity zero-arg invocation avoids empty-memory transport.
   No new owner/pool/config/API/native-proof marker or eligibility expansion.
   373internal/2046public Release per actual11/10 pass. Initial17 wrong-arity failures
   corrected with explicit fixed signatures/common diagnostics, tests unchanged.
   Casefold/title helper allocation45–52%lower. B448 six jobs168.102s: affected
   elapsed22–24%lower, coarseCPU agrees; rsplit−0.90to+4.45%inconclusive(current
   spread3.85%), CSV−0.38to+2.70%possible regression retained, reportasync lower.
   All original/refined adverse observations remain. All source/Ready/golden/quiet/
   Closed/join/fixture/archive gates pass; archive underlease/localverify complete.
   Full Windows/Ubuntu actual11/10/originalStress/installed boundary CI42457767068
   dispatched once07:11UTC; terminal FAILURE07:21UTC, cached logs preserved.
   Full tests found live-environment view receiver rebinding and unrelated Decimal
   error-text regressions. Correct by reusing the existing fixed-arity exposed
   callable wrapper and deleting the overbroad binder diagnostic override. Keep
   canonical declarations/immediate-call optimization. Verify original affected
   tests unchanged:2030+103public actual11,2115public actual10,41internal/target
   pass; short five-case/API allocation reduction44.96–52.00% retained, controls
   neutral. Desktop elapsed unstable/adverse; old B448 CPU/timing belongs toaa4,
   not correctedcc6b1b15. Commit correction/evidence, then one new retained-source
   full boundary. Never requery failed CI42457767068.
   Continue independent roadmap work while CI runs; publication remains postponed.
   VM companion-library dedup is complete/proven:52,531,200bytes freed under idle
   lease, every original path/byte/core/source/archive retained; no further cleanup
   inferred. B448 terminal/verified, no live users or fixtures, never requery.
2. R86 complete CSV-helper attribution CLOSED: B449 terminal/archived/locally
   verified, no users/fixtures; never requery. Committed02c/coreaa4,1124samples/
   5.65CPU-s,79unknown. Prefix11.57%self, inputs6.49%, result3.11%, stack3.02%;
   parser6.67%(15.12%inclusive), adoption2.58%(4.72%), binding/work3.56%(4.27%),
   numeric5.43%(6.23%). Overlap/inlining/unknowns preclude causal totals; no binder
   dominance, no normal-settings timing claim. All gates/raw/adverse data retained.
   R87 bounded offline source/generated-code gate: map existing ordinary-helper
   and CSV sample addresses to emitted Tier1 blocks (verify method/tier/code-size
   identity), identify a complete execution/operand or conversion phase to remove.
   Stop within one source-design pass (~30min), select a coherent replacement and
   its semantic/cancellation/ownership/source-pair acceptance, or record specific
   missing attribution and choose the next roadmap boundary. No new VM collection
   merely to amplify weak samples; no arena/control carrier/accounting redesign.
   R87 mapping finds a unique Tier1/method/code-size match for the prefix:36/130
   samples in loop fetch,24dispatch,19inlined refusal/token checks,9prologue;
   input-handler JIT listing is absent, so its6.49% cannot be source-attributed.
   R88 bounded source-shape gate: current identical corecc6, CSV/rsplit helper
   versus inlined bodies inside the same main-function scope, unused definitions
   retained on both sides. Independently verify full CPython stdout/files. One
   short five-row allocation/desktop diagnostic (report unchanged); then choose
   whether a controlled confirmation of complete call activation is justified.
   Scope/locals/retention differ intentionally: no binder-only causal attribution,
   product semantic change or new pool/driver/framework. Initial four-row private
   driver count refusal precedes measurement; retain it, reuse existing five-row
   tooling. Do not start a broad retiming/ownership campaign from this source gate.
   Ordinary text-fusion source gate: sharing the current straight-line-only fusion
   with general control flow requires another dispatch/proof route. No such change
   selected absent stronger attribution; preserve existing measured native helpers.
   This does not permanently reject a future coherent consolidation.
3. R82/R83 delivery/checkpoint CLOSED and cached; never requery/re-dispatch
   CI42451722109 or B445/B446. Full source91f15a3e qualification is green; guide
   names the exact measured source/core4c072fed and separates compile/warm/result,
   I/O/validation/prior cleanup, uncertainty and historical evidence. Possible
   R82CSV elapsed+1.50%, R79CSV and R76float debt remain separate. No broad CPU
   gain or single-change attribution. VM workers/fixtures gone and persistent
   archives locally verified. Another isolated experiment/CI receipt does not
   complete the whole-script performance objective. Publication postponed.
4. Continue independent Lython-owned regex work below. Missing producer publication
   defers only the affected final adapter qualification. No publication/tagging.

## Following substantial redesign boundaries

| Boundary | Selection and acceptance |
| --- | --- |
| Remaining calls/operand/scalar dispatch | Indexed operands/native returns/final slots and native workstate dispatch exist. Find a demonstrated complete remaining binding/transport or numeric phase; avoid pools/arenas and duplicated control routes already measured slower. Exact integer promotion, identity/type/projection, callbacks, reentry and alias funding must hold. Machine-integer handling is a hypothesis until current attribution supports its scope; no universal tagged-value replacement. |
| Per-record construction | Current source gate: shared RecordKeys and exclusive funded row-array adoption already remove the old bulk proposal's copying/key phase; it cannot be revived unchanged. Preserve its6–8% improvement/adverse control. Remaining identity checks protect mutable headers and admission reentry; no mutation-version inventory without current measured dominance. Select a genuinely remaining construction phase; preserve hooks/order/escaping aliases. |
| Remaining bulk text/JSON | Direct casing/lower-split/formatting/native parsing, JSON loop/shared scanner and final UTF-8 storage retained. Select a whole remaining conversion/storage phase, preserving Unicode/context/hooks/async I/O. Ordinary R61 JSON has no escaped tokens; do not optimize hypothetical dominance or add a name-marker series. |
| Frontend facts | R55/R58/R62/R65 already remove lexical/graph/validity/module work. Select demonstrated repeated analysis in compile-to-result workloads; preserve class/function/annotation scope and exact diagnostics, then delete displaced analysis. No speculative visitor/cache/parser/JIT project. |

Bounded confirmation/refinement or measurement correction is allowed when evidence
justifies it. Timeout, unstable unchanged control or inconclusive results establish
uncertainty, not a permanently failed design. Keep original failed conditions and
adverse results. Fixed percentages inform judgment, never automatically veto useful
simplification. Temporary regressions require an explicit completion milestone and
retain/correct/reject decision on remaining debt. Batch CPython refreshes at coherent
combined checkpoints with exact source/date/machine and separate compile, warm,
compile-to-result/startup; include I/O/validation/cleanup boundaries and uncertainty.
Current guide accurately names source91f15a3e; do not remeasure after every tweak.

## Independent regex deliverable

Core owns Python/native UTF-8 semantics: byte ranges/scalar positions/original
subject windows, flags/captures/replacements/errors, cache ownership/current tokens
and one provider through frontend/runtime/imports. Core has no Utf8Regex dependency;
adapter remains nonpackable. Contract tests, semantic compatibility and actual
backend performance are separate. Immutable development producers/adapter-local
bridges support development; missing publication does not stop independent work.

Exact dev55 gaps: DetailedData lacks separate preparation/working ownership;
native name lookup lacks enumeration; cursor creation retains its token despite
per-move tokens. Both dev55 package SHAs rechecked bit-identical04:45UTC; no
new supplied version or repeat qualification. Existing bridges remain justified. Qualify the final released
package's semantics, managed safety and actual performance when available. Normal
adapter0.4 pin unchanged pending justified promotion. No sibling edits/builds,
producer-CI replay, dialect fallback, quotas, memory subsystem or abandoned matching.

## Lasting constraints / checks

AGENTS.md governs fully managed safety/managed stack admission: no unsafe/Unsafe,
PInvoke/pointers/native probes. Preserve host capabilities, current cancellation,
checked representation bounds, XML depth, bounded I/O chunks and admitted projection.
Borrow shared allowance for coarse capacity/preflight/replacement storage; fund
retained aliases/caches/results and pending users until awaited cleanup. No caps,
hidden allowances/fuel/quotas/tracing/weak reclamation/forced GC. Initial streaming
uses host batches. First refusal is terminal through suppression/finally; never
retry or skip optional storage. Keep native refunds/cleanup available and awaited.

Focused Release iteration; matching probes when needed and explicit Stress exclusion
with custom filters. No overlapping local builds/tests/measurements; force a fresh
build after timestamp-preserving restores. Batch actual11/10 Windows/Ubuntu,
original Stress and installed consumers at retained boundaries. Explicit UTF-8.
Only core explicit Release pack to artifacts/nuget; no adapter packages/publication.
VM lokad@20.166.121.73,key ~/.ssh/id_lython-bench.pem. B443 terminal/archived/
locally verified; no active user/fixture mount, never requery. Persistent evidence
separate from owned RAM; join/unmount/archive under lease and verify locally.
One byte-identical worker DLL was atomically hardlinked, freeing56MB while keeping
all paths/bytes/cores/sources/archives. No future deletion inferred. CI observations
>=5minutes apart; cached terminal runs never requeried or duplicate-dispatched.
