from pathlib import Path
import hashlib,json,shutil,tarfile
r=Path(__file__).resolve().parent;profile=r.parent/'csv-cost-r86'
out=Path('benchmarks/results/2026-11-08-helper-activation-gate');out.mkdir(exist_ok=True)
for name in ['generated-code-attribution.json','attribute-jit.py']:shutil.copyfile(profile/name,r/name)
shutil.copyfile('PLAN.md',r/'next-milestone-plan.md')
driver=r.parent/'integer-utf8-r45/tool'
proof=dict(driverSourceSHA256=hashlib.sha256((driver/'Program.cs').read_bytes()).hexdigest(),driverBinarySHA256=hashlib.sha256((driver/'out/complete-jobs.dll').read_bytes()).hexdigest(),coreReference='2026-11-08-receiver-binding-correction/observations.tar.xz:corrected-core.dll',rawProfileReference='2026-11-08-csv-helper-attribution/observations.tar.xz:observations.tgz (profiles/text-warm)',limitations='Offline instruction-group attribution uses unique method/tier/code-size identity; sampled group range includes all its inlined work. Input handler emitted listing absent. Source-shape elapsed remains diagnostic, not a runtime change or binder-only attribution.')
(r/'evidence-provenance.json').write_text(json.dumps(proof,indent=2)+'\n',encoding='utf-8')
shutil.copyfile(r/'assessment.json',out/'assessment.json')
with tarfile.open(out/'observations.tar.xz','w:xz')as a:
 for p in sorted(r.rglob('*')):
  if p.is_file()and 'images'not in p.relative_to(r).parts:a.add(p,arcname=p.relative_to(r).as_posix())
 a.add(driver/'Program.cs',arcname='reused-driver/Program.cs');a.add(driver/'out/complete-jobs.dll',arcname='reused-driver/complete-jobs.dll')
with tarfile.open(out/'observations.tar.xz')as a:
 for m in a.getmembers():
  if m.name.startswith('reused-driver/'):
   p=driver/'Program.cs'if m.name.endswith('Program.cs')else driver/'out/complete-jobs.dll'
  else:p=r/m.name
  assert m.isfile()and hashlib.sha256(a.extractfile(m).read()).digest()==hashlib.sha256(p.read_bytes()).digest()
print('Existing-profile generated-code map, current source-shape gate, initial driver refusal and next coherent pre-code milestone preserved:',(out/'observations.tar.xz').stat().st_size)
