from pathlib import Path
import json,re,subprocess,tempfile,textwrap
r=Path(__file__).parent
text=Path('tests/Lokad.Lython.PublicApi.Tests/NativeCallbackArgumentsTests.cs').read_text(encoding='utf-8')
sources=[textwrap.dedent(source) for source in re.findall(r'"""\n(.*?)\n\s*"""',text,re.S)]
assert len(sources)==2
expected=["['first!', 'second!']\n","['1(3,)!', '2(4,)!']\n['xa', 'xb']\n['xac', 'xbd']\n['1', '2']\n[(1, 2, 3, 4)]\n[10, 11]\nrequired\n[1, 3]\n"]
proof=[]
for source,wanted in zip(sources,expected):
    converted=source.replace("return list(map(target, ['first','second']))","print(list(map(target, ['first','second'])))")
    with tempfile.TemporaryDirectory(prefix='lython-r149-cpython-') as folder:
        Path(folder,'default.txt').write_text('suffix',encoding='utf-8')
        done=subprocess.run(['C:/Python313/python.exe','-I','-S','-X','utf8','-c',converted],cwd=folder,encoding='utf-8',capture_output=True,timeout=10)
        assert done.returncode==0 and done.stdout==wanted and not done.stderr,done
        proof.append(dict(source=source,pythonSource=converted,stdout=done.stdout,python='CPython3.13',differences='Only top-level return becomes print; real default.txt supplies suffix.'))
(r/'python-goldens.json').write_text(json.dumps(proof,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print('Two independent callback/default-lookup Python goldens pass.')
