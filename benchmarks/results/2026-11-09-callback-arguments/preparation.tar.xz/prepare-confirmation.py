from pathlib import Path
import hashlib,json,shutil,tarfile
r=Path(__file__).parent
v=r/'b504';v.mkdir()
old=r.parent/'callable-consolidation-r145/b502'
old_name='callable-consolidation-b502-20261109'
new_name='callback-transport-b504-20261109'
for name in ['collect.py','archive-owned.py','run.sh','launch.py','retrieve.py','assess-vm.py']:
    data=(old/name).read_text(encoding='utf-8').replace(old_name,new_name)
    data=data.replace('lython-b502-callable-consolidation-20261109','lython-b504-callback-transport-20261109').replace('callable-consolidation-b502-launch.py','callback-transport-b504-launch.py').replace('lython-b502-fixtures','lython-b504-fixtures')
    if name=='collect.py':
        start=data.index('jobs=[');end=data.index('\nenv =',start)
        jobs=[[c['id'],'warm'] for c in json.loads((r/'catalog.json').read_text(encoding='utf-8'))['cases']]
        data=data[:start]+'jobs='+repr(jobs)+'\nassert len(jobs)==5 and all(case in cases for case,lane in jobs)\n'+data[end:]
        start=data.index("purpose='R145");end=data.index('\n                  warmupSeconds=',start)
        data=data[:start]+"purpose='R149 direct managed callback argument transport and removal of thread-local argument pools. Complete map-based CSV/text/JSON scripts, unchanged report/search controls; same source/input per pair. Allocation and CPU claims separate; desktop control drift retained.',"+data[end:]
    if name.endswith('.py'):compile(data,name,'exec')
    (v/name).write_text(data,encoding='utf-8',newline='\n')
for target,source in [('representative.json',r/'catalog.json'),('baseline-core.dll',r/'images/before/Lokad.Lython.dll'),('current-core.dll',r/'images/candidate/Lokad.Lython.dll'),('source.patch',r/'source.patch')]:shutil.copyfile(source,v/target)
shutil.copyfile('PLAN.md',v/'contract.md')
(v/'baseline-source.json').write_text(json.dumps(dict(sourceRevision=(r/'baseline-revision.txt').read_text(encoding='utf-8-sig').strip(),freshNonincrementalBuild=True))+'\n',encoding='utf-8')
for target,name in [('common-worker.dll','Lokad.Lython.Benchmarks.dll'),('common-adapter.dll','Lokad.Lython.Utf8Regex.dll'),('common-worker.deps.json','Lokad.Lython.Benchmarks.deps.json'),('common-worker.runtimeconfig.json','Lokad.Lython.Benchmarks.runtimeconfig.json')]:shutil.copyfile(r/'images/before'/name,v/target)
identity=dict(sourceRevision='Committed46e3746e versus working R149; fresh nonincremental builds; common frozen worker/adapter',coreSHA256={role:hashlib.sha256((v/name).read_bytes()).hexdigest() for role,name in [('reference','baseline-core.dll'),('reference-control','baseline-core.dll'),('candidate','current-core.dll'),('candidate-control','current-core.dll')]},auxiliaryFiles={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in (r/'images/before').glob('*.dll') if p.name!='Lokad.Lython.dll'},catalogSHA256=hashlib.sha256((v/'representative.json').read_bytes()).hexdigest())
(v/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8')
(v/'focused.json').write_text(json.dumps(dict(status='actual11 focused 60internal/918public plus71callback-specific pass; actual10 and final expanded checks pending; independent whole-script Python goldens five'),indent=2)+'\n',encoding='utf-8')
(v/'setup-contract.json').write_text(json.dumps(dict(ownerSeconds=210,stopSeconds=30,marginSeconds=30,osFreeFloorMiB=240,evidenceHeadroomMiB=12,jobs=5,unchangedWorkerAndProtocol=True),indent=2)+'\n',encoding='utf-8')
(v/'sizing.json').write_text(json.dumps(dict(jobs=5,warmupPerRoleSeconds=5,rounds=7,targetBatchSeconds=.15,expectedSeconds=155,ownerSeconds=210),indent=2)+'\n',encoding='utf-8')
(v/'pre-measurement-plan.md').write_text('''# R149 bounded confirmation

Five same-source pairs: complete map-based CSV/text/JSON and unchanged report/search
controls. Four independent roles, five-second warmup each, seven rotated 150ms rounds.
Common frozen worker/adapter, fresh core builds, normal GC/tiering. Warm clock includes
mediated RAM-file I/O, full output checking and prior-result cleanup; excludes startup,
compilation/reset/protocol/final teardown. Separate wider process CPU. Desktop allocation
reductions CSV6.8%,text14.1%,JSON4.7%; unchanged control drift up to16.5% means elapsed
inconclusive. Preserve all adverse results, assess any CPU regression debt explicitly.
Do not compare map shapes to old scripts as a speedup; each source is identical per pair.
No full lanes/producer replay. Owner210s/stop30s/margin30s, expected155s. Persist raw outside
RAM, join users, unmount/remove owned fixture and archive under lease; verify localSHA.
''',encoding='utf-8')
with tarfile.open(v/'payload.tgz','w:gz') as archive:
    for p in v.iterdir():
        if p.name!='payload.tgz':archive.add(p,arcname=p.name)
print('Five jobs; expected155s, owner210s; payload bytes',(v/'payload.tgz').stat().st_size)
