from pathlib import Path
import base64, copy, hashlib, json, subprocess, tempfile
r=Path(__file__).parent
catalog=json.loads((r.parent/'lexical-operands-r139/catalog.json').read_text(encoding='utf-8'))
by_name={item['id'].split('.')[1]:copy.deepcopy(item) for item in catalog['cases']}
sources={name:Path('benchmarks/scripts',name+'.py').read_text(encoding='utf-8') for name in by_name}
csv=sources['csv-validated-records'].replace("for row in csv.DictReader(source):\n        item = validated_record(row, minimum=0)","for item in map(validated_record, csv.DictReader(source)):")
text=sources['text-summary-helpers'].replace("for line in source:\n        for word in words_from_line(line):","for words in map(words_from_line, source):\n        for word in words:")
js=sources['json-summary-helpers'].replace("for line in source:\n        if line.strip():\n            record = json.loads(line)","for record in map(json.loads, (line for line in source if line.strip())):")
# The old if body becomes the for body; keep all aggregation/output unchanged.
lines=js.splitlines(True)
start=next(i for i,line in enumerate(lines) if 'for record in map' in line)+1
end=next(i for i in range(start,len(lines)) if lines[i].startswith('with open'))
for i in range(start,end):
    if lines[i].startswith('    '):lines[i]=lines[i][4:]
js=''.join(lines)
catalog['cases']=[]
goldens=[]
for name,body in [('csv-validated-records',csv),('text-summary-helpers',text),('json-summary-helpers',js),('report-render',sources['report-render']),('file-search',sources['file-search'])]:
    item=by_name[name]
    item['source']=body
    item['id']='scripts.'+name+('.map-callback' if name not in ['report-render','file-search'] else '.control')+'.large'
    item['sourceUtf8Bytes']=len(body.encode())
    item['sourceSha256']=hashlib.sha256(body.encode()).hexdigest()
    fixture=json.loads(item['fixtureJson'])
    with tempfile.TemporaryDirectory(prefix='lython-r149-golden-') as folder:
        folder=Path(folder)
        for path,encoded in fixture['inputFiles'].items():
            dest=folder/path
            dest.parent.mkdir(parents=True,exist_ok=True)
            dest.write_bytes(base64.b64decode(encoded,validate=True))
        done=subprocess.run(['C:/Python313/python.exe','-I','-S','-X','utf8','-c',body],cwd=folder,encoding='utf-8',capture_output=True,timeout=15)
        assert done.returncode==0 and done.stdout==item['expectedOutput'] and not done.stderr,(item['id'],done)
        for path,encoded in fixture['outputFiles'].items():assert (folder/path).read_bytes()==base64.b64decode(encoded,validate=True),(item['id'],path)
        goldens.append(dict(case=item['id'],source=body,sourceSHA256=item['sourceSha256'],stdout=done.stdout,allOutputFilesEqual=True))
    catalog['cases'].append(item)
(r/'catalog.json').write_text(json.dumps(catalog,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
(r/'script-goldens.json').write_text(json.dumps(goldens,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print('Five independent CPython whole-script goldens pass.')

