from pathlib import Path
import json, statistics
r = Path(__file__).parent
out = {}
for phase in ['warm-sync','warm-async','compile-sync']:
    data = json.loads((r/phase/'measurements.json').read_text(encoding='utf-8'))
    assert all(data[k] for k in ['allGoldensPassed','allBalancesZero','ownedFixturesRemoved','imageIsolationVerified'])
    rows = []
    for o in data['observations']:
        values = {role:dict(milliseconds=None if phase == 'compile-sync' else statistics.median(s['executionMilliseconds']/s['jobs'] for s in o['samples'] if s['image']==role),
                            bytes=statistics.median(s['allocatedBytes']/s['jobs'] for s in o['samples'] if s['image']==role))
                  for role in ['before','before-control','candidate']}
        row = dict(case=o['caseId'],roles=values,
                   allocationPercent=[100*(values['candidate']['bytes']/values[b]['bytes']-1) for b in ['before','before-control']],
                   elapsedPercent=None if phase == 'compile-sync' else [100*(values['candidate']['milliseconds']/values[b]['milliseconds']-1) for b in ['before','before-control']],
                   referenceSpreadPercent=None if phase == 'compile-sync' else 100*(values['before-control']['milliseconds']/values['before']['milliseconds']-1))
        rows.append(row)
        print(phase,o['caseId'],'allocation%',[round(p,2) for p in row['allocationPercent']],
              'elapsed%',None if row['elapsedPercent'] is None else [round(p,2) for p in row['elapsedPercent']],
              'referenceSpread%',None if row['referenceSpreadPercent'] is None else round(row['referenceSpreadPercent'],2))
    out[phase]=rows
out['limitations']='Same-process isolated ALCs; actual allocation, diagnostic elapsed. Same whole script/fixture pair; not a CPython timing or machine-independent CPU claim. Pending-I/O latency/startup not measured. Includes mediated I/O, output validation and prior-result cleanup; compilation separate, fixture reset/protocol/final cache teardown excluded.'
(r/'assessment-local.json').write_text(json.dumps(out,indent=2)+'\n',encoding='utf-8')
