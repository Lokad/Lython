from pathlib import Path
import hashlib,json,shutil,subprocess,tarfile
r=Path(__file__).parent;v=r/'b504'
out=Path('benchmarks/results/2026-11-09-callback-arguments');out.mkdir(exist_ok=True)
identity=json.loads((r/'identity.json').read_text(encoding='utf-8'))
assert all(hashlib.sha256(Path(name).read_bytes()).hexdigest()==digest for name,digest in identity['productionSources'].items())
assert hashlib.sha256((v/'observations.tgz').read_bytes()).hexdigest()==json.loads((v/'archive-receipt.json').read_text(encoding='utf-8'))['archiveSHA256']
proof=dict(productionSourceMatchesMeasuredFreeze=True,baselineRevision=identity['baselineRevision'],measuredCoreSHA256=identity['candidateCoreSHA256'],actualFrameworks=['net11.0','net10.0'],focusedPerFramework=dict(internal=60,public=1636),newPublicCases=5,independentPythonGoldens=2,independentWholeScriptGoldens=5,removed='Three thread-local callback argument pools, six rent/return/clear helpers, forwarding async state machines, duplicate function Invoke/InvokeAsync binding bodies; ordinary map per-record argument arrays and their temporary reservations.',preserved='Existing owned function/builtin binders; dynamic callable arrays, admitted wide map storage, evaluation/error order, receivers, variadics/defaults, pending default lookup, reentrancy/generators, current cancellation, first terminal refusal and awaited owner cleanup.',delivery='Focused actual11/10 pass; full Windows/Ubuntu actual11/10, original Stress and installed consumers batch next. Publication postponed.',limitations='Same source per pair; map-based scripts are explicit workload shapes, not speedups over prior differently shaped scripts. Desktop control drift retained. Native callback fallback implementations may allocate owned arrays instead of borrowing thread-local storage; no universal speedup claim.')
(r/'delivery-source.json').write_text(json.dumps(proof,indent=2)+'\n',encoding='utf-8')
(r/'final-source.patch').write_bytes(subprocess.check_output(['git','diff','--binary','--','src/Lokad.Lython','tests']))
for target,source in [('observations.tgz',v/'observations.tgz'),('summary.json',v/'assessment.json'),('terminal.json',v/'terminal-status.json'),('identity.json',r/'identity.json'),('local-summary.json',r/'assessment-local.json'),('delivery-source.json',r/'delivery-source.json'),('python-goldens.json',r/'python-goldens.json'),('script-goldens.json',r/'script-goldens.json')]:
    assert not (out/target).exists();shutil.copyfile(source,out/target)
with tarfile.open(out/'preparation.tar.xz','w:xz') as archive:
    for p in r.iterdir():
        if p.is_file():archive.add(p,arcname=p.name)
    for name in ['warm-sync','warm-async','compile-sync']:archive.add(r/name,arcname=name)
    for p in v.iterdir():
        if p.is_file() and p.name not in ['payload.tgz','observations.tgz','baseline-core.dll','current-core.dll','common-worker.dll','common-adapter.dll']:archive.add(p,arcname='b504/'+p.name)
    archive.add('tests/Lokad.Lython.PublicApi.Tests/NativeCallbackArgumentsTests.cs',arcname='NativeCallbackArgumentsTests.cs')
print('Source matches measured freeze; original invalid-catalog condition, controls, all raw and focused actual11/10 logs archived.')
