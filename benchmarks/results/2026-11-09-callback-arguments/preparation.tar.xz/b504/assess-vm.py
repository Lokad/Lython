from pathlib import Path
import json,statistics
r=Path(__file__).parent;d=json.loads((r/'retrieved/confirmation/confirmation.json').read_text(encoding='utf-8'))
assert d['complete'] and len(d['jobs'])==5
out=dict(complete=True,ownedSeconds=d['elapsedSeconds'],jobs=[])
for j in d['jobs']:
    roles={}
    for role in ['reference','reference-control','candidate','candidate-control']:
        ss=[s for s in j['samples'] if s['engine']==role]
        ee=[s['response']['elapsedTicks']/s['response']['clockFrequency']/s['response']['completedInvocations'] for s in ss]
        cc=[s['externalProcessCpuTicks']/s['externalCpuFrequency']/s['response']['completedInvocations'] for s in ss]
        q=statistics.quantiles(ee,n=4,method='inclusive');m=statistics.median(ee)
        roles[role]=dict(seconds=m,cpuSeconds=statistics.median(cc),iqrPercent=100*(q[2]-q[0])/m)
    row=dict(case=j['case'],lane=j['lane'],roles=roles,
        elapsedPercent={c:[100*(roles[c]['seconds']/roles[b]['seconds']-1) for b in ['reference','reference-control']] for c in ['candidate','candidate-control']},
        cpuPercent={c:[100*(roles[c]['cpuSeconds']/roles[b]['cpuSeconds']-1) for b in ['reference','reference-control']] for c in ['candidate','candidate-control']},
        baselineSpreadPercent=100*(roles['reference-control']['seconds']/roles['reference']['seconds']-1),
        candidateSpreadPercent=100*(roles['candidate-control']['seconds']/roles['candidate']['seconds']-1))
    out['jobs'].append(row)
    print(row['lane'],row['case'],'elapsed%',{k:[round(x,3)for x in v]for k,v in row['elapsedPercent'].items()},'CPU%',{k:[round(x,3)for x in v]for k,v in row['cpuPercent'].items()},'oldSpread',round(row['baselineSpreadPercent'],3),'currentSpread',round(row['candidateSpreadPercent'],3))
(r/'assessment.json').write_text(json.dumps(out,indent=2)+'\n',encoding='utf-8')
