# R149 bounded confirmation

Five same-source pairs: complete map-based CSV/text/JSON and unchanged report/search
controls. Four independent roles, five-second warmup each, seven rotated 150ms rounds.
Common frozen worker/adapter, fresh core builds, normal GC/tiering. Warm clock includes
mediated RAM-file I/O, full output checking and prior-result cleanup; excludes startup,
compilation/reset/protocol/final teardown. Separate wider process CPU. Desktop allocation
reductions CSV6.8%,text14.1%,JSON4.7%; unchanged control drift up to16.5% means elapsed
inconclusive. Preserve all adverse results, assess any CPU regression debt explicitly.
Do not compare map shapes to old scripts as a speedup; each source is identical per pair.
No full lanes/producer replay. Owner210s/stop30s/margin30s, expected155s. Persist raw outside
RAM, join users, unmount/remove owned fixture and archive under lease; verify localSHA.
