# Lokad.Lython 0.11.0

Updated 2026-11-09 (Paris). Git-ignored; never force-add. Publication/tagging postponed.
Objective: coherent simplification and substantial whole-script performance. Completing
an isolated experiment does not complete it. Current contracts live in docs; original
failures, prototypes and qualification live in [history](benchmarks/EXPERIMENTS.md).

## Actual delivery status

| Work | Delivery | Qualification / limits |
| --- | --- | --- |
| Shared compiler-fact correction, direct UTF-8 formatting/storage, native helper returns | Committed foundations | Qualified. Keep allocation and elapsed claims separate; no unchanged replay. |
| R119–R135 record/lookup facts, storage lifetimes, declaration/literal/static-call facts, native inputs/Boolean identity | Committed | Qualified Windows/Ubuntu actual .NET 11/10, original Stress and installed consumers at later checkpoints. |
| R138/R139 closed helpers and incoming lexical reads | Committed, class/global proof corrections preserved | Qualified. Source-pair CPU benefits and control uncertainty remain in history. |
| R141 owned hash stress canceller | Committed `7aa637bf` | Full CI42573178034 cached success; original failed conditions/mutation proof retained. Never requery. |
| R142 shared generator compilation/state | Committed `081052fa`, test correction `27353cfb` | Fully qualified CI42579357509; prototype timings remain distinct from delivery binary. Never requery. |
| R140/R143 CPU attribution | Committed | One usable text/search capture each, exact sources/raw retained. Inclusive VM-prefix shares include useful work. |
| R144 helper proof gate | Completed assessment | Guards precede admission/effects; execution rereads live data. No safe phase deletion selected, no second guard VM/cache. Not a permanent design ban. |
| R145 one executable callable engine | Committed `65ed6cf7`, correctness/fixture correction `58d3ec0f` | Fully qualified: corrected CI42588611410 cached terminal success, Windows/Ubuntu actual11/10, original Stress both and installed consumers. Original failure/correction and measured65ed source retained. Never requery. |
| R146 CPython refresh | Committed `115dda5f`; measured `65ed6cf7`/core082a | Twelve jobs250.847s, all quiet/output/ownership/cleanup/archive gates pass. Do not relabel timings as the correction. |
| R147 general operand transport gate | Committed `c301812f` | Existing input/result forwarding already removes the presumed ordinary round trip. Store continuation retains cleanup/check/span semantics. Static census, no timing claim. |
| R148 filename-filter suspension | Committed `46e3746e` | 305 focused public checks per actual11/10 and four Python goldens. Genuine pending iteration, cancellation, awaited cleanup, refusal and budget reuse covered; full delivery batches. |
| Prepared maps, call arenas/control, shared string windows | Held/restored prototypes | Slower or complex variants and useful independent semantic fixes remain in history; no permanent bans. |

## Evidence and uncertainty

[BENCHMARKS.md](docs/BENCHMARKS.md) separates compilation, warm and compile-to-result.
Measured65ed / CPython3.13.16 complete CSV/text/JSON-report/search ratios:
1.13–1.17× /1.49–1.51× /1.35× /1.34–1.35×. Warm:1.15–1.17× /1.56–1.60× /
1.37–1.38× /1.61–1.63×. Compile roughly1.05–1.09×, search0.95×. Variable controls
remain visible; older rows retain their own sources. Includes mediated RAM-file I/O,
full output checks and prior-result cleanup; excludes startup/reset/protocol/final
cache teardown. Pending I/O, embedding tails and large-tree/file throughput unknown.
Search input has2,049 physical lines and exits at1,025; both engines run the same work.

Native helper returns: allocation−19.92/19.31%, distinct from diagnostic elapsed.
Formatting: allocation−8.67%; controlled B102 elapsed/CPU−5–8% supports retention,
while original adverse15.125ms remains unexplained and retained. No unchanged campaign.

R142: text allocation−15.1%; quiet affected pipelines improve, supporting CPU.
Compile allocation+1.3–1.6% and report control+1.17–4.54%elapsed/+0.39–4.44%CPU
remain accepted/unresolved debt. Original desktop JSON adversity survives. No final-
binary timing claim or attempt to settle this by comparing unrelated checkpoints.

R145: remove PyFunction, its mode/177-line duplicate dispatcher, runtime lambda
lowering/compilation and unused bodies; preserve actual executable capture facts
and real lowered consumers. Complete class-callable CSV/text/JSON warm allocation
−23–26%/−74–76%/−56–57%; quiet elapsed−9–12%/−38–39%/−13–15%, supporting CPU.
Compile allocation+3.2–5.2% accepted; report control+0.05–1.12%elapsed/0–4.44%coarseCPU
uncertain. Source pairs are not CPython/shape ratios. Measured source65ed remains
explicit after58d3's scope correction. [Evidence](benchmarks/results/2026-11-09-callable-consolidation/README.md).

## Prioritized non-regex deliverables

1. **R149 direct native-callback argument transport.** Active bounded redesign:
   CallableInvocation currently rents three thread-local argument-array shapes,
   then functions/builtins copy them into owned binding storage. Let the existing
   binders consume short managed spans synchronously; retain owned arrays for
   other callable implementations that may retain them. Remove the three pools,
   rent/return/clearing lifecycles and unnecessary async forwarding state machines.
   No new pool, callable interface, dispatcher, configuration or public API.
   Affects JSON/CSV/text helper callbacks, map/filter, sort keys and protocols;
   compare complete callback-heavy record/text/report scripts with unchanged
   ordinary-script controls. Hypothesis: less packaging/lifecycle work, with owned
   binding completed before suspension. Do not infer CPU benefit from allocation.
   Preserve defaults/keyword-only/variadics, bound receivers, recursion, exception
   origins/order, reentrancy, generators, current cancellation, refusal and funded
   pending users. Focused actual11/10 checks, short controlled allocation/elapsed
   diagnostic before bounded quiet confirmation if useful. Stop/refine if dynamic
   fallback regression outweighs deletion; retain adverse evidence. Batch full
   qualification with R148 at the delivery boundary.

   **R148 complete:** source confirmed fnmatch.filter
   consumed ToSequence synchronously through a sync-only builtin, even under
   RunAsync. Reproduced with a genuinely pending file-backed generator; now uses
   the existing async iteration/cursor
   mechanism while preserving the synchronous route and native UTF-8 matcher. No
   regex producer dependency, new dispatch framework, materialization or I/O fallback.
   Delete the duplicate/sync-only consumption route rather than wrapping it in a
   background task. Preserve name identity/order, first invalid-item/iterator error,
   active cancellation/refusal and awaited iterator cleanup; retained output stays
   charged and result disposal returns shared allowance to baseline. Focused native
   matching/filter, pending iteration/cancel/cleanup/admission checks on actual11/10.
   Before/after short complete file-name processing diagnostic only if useful; no
   performance claim from fixing capability dispatch. Stop this probe after20min if
   no gap; record uncertainty and resume performance selection below. Publication held.

2. **Select the next coherent execution redesign from current evidence.** Remaining
   warm text/search gaps are real; current profiles do not isolate one removable cause.
   Start with general instruction/operand/call representation across complete scripts,
   then remaining text/record work. State the current duplicated work or storage and
   displaced code before implementation. R147 confirms direct input/result forwarding
   and nonmirrored maintained modules/helpers already exist; do not reimplement them.
   Retained store continuations protect pending disposal and publication ordering.
   No new arena, dispatch framework, guard VM, per-call cache or syntax-specific trick.

   Source/design gate at most20min per actual hypothesis. Static counts and inclusive
   samples are not savings. If no coherent deletion is found, record that and move to
   the independent next family without another capture/unchanged timing campaign.
   A selected milestone names affected CSV/text/JSON/report/file scripts and controls,
   preserves Python order/errors/scopes/protocols, current cancellation, terminal
   refusal, stack safety and explicit owners, then compares compile/allocation/warm
   separately. Use a short diagnostic and bounded quiet confirmation where material.
   Finish by deleting displaced implementation and deciding remaining regression debt.

3. **Remaining text/frontend and per-record gates.** Direct final UTF-8/managed bulk
   ASCII casing, one Unicode mapping pass, fused final-word splitting, flat callable
   facts and commit without root resizing already exist. Ordinary counters skip
   separate magnitude admission. Do not infer scalar CPU dominance from boxing.
   Inspect remaining conversions/repeated analysis only where a current phase is
   demonstrated; preserve Unicode expansion/scalar offsets, aliases and diagnostics.
   No heavyweight JIT/tagged-value or class/import compiler rewrite from inclusive
   counts. Each new gate has the same20min stopping rule and coherent deletion target.

   CSV already stages a record, admits field/row capacity once and adopts storage;
   JSON shares layouts. Historical bulk-CSV6–8% benefits remain promising evidence,
   but the copying premise has been displaced. Reopen for a current duplicate phase
   or measured control issue; no automatic promotion or percentage veto. Slower
   call-arena/control lessons remain explicit. Refresh CPython after another substantial
   coherent checkpoint, not per tweak; R146 is complete and needs no unchanged replay.

## Independent regex deliverable

Core owns Python semantics, native UTF-8 names, byte ranges/scalar positions, original
windows, effective flags, errors/replacements, current tokens, explicit owners and one
frontend/runtime/import provider. Continue independent contract/implementation/semantic
work; missing published producer APIs defer only affected final adapter qualification.
Adapter-local bridges, test providers and pinned development producers are acceptable.
Keep forwarding/unwind, semantic validation and actual backend performance distinct.

Optional nonpackable adapter pin0.4.0; official index checked2026-11-09. Dev55/d6067925
already86 internal/514 public eachactual11/10 pass; no unchanged replay/sibling edits.
Missing released capabilities: DetailedData with distinct preparation/working owners,
native-name enumeration and cursor creation without an earlier caller token. Current
Lython-owned byte-range/capture-buffer contract is independent of those bridges.

## Iteration and lasting constraints

Timeouts, unstable controls and inconclusive observations establish uncertainty, not
failed designs. Allow bounded confirmation/refinement/measurement correction when
evidence justifies it. Retain original adverse/failed conditions. Percentages inform
decisions, not automatic vetoes; distinguish simplification, allocation and CPU benefit.

AGENTS.md is authoritative: fully managed memory safety and managed stack admission;
host mediation/current cancellation; coarse borrowed shared budget/preflights/capacity/
replacement overlap; escaping results/caches/aliases/pending users funded through
awaited cleanup. First refusal terminal. No unsafe/native probing, fuel/quotas/caps/
hidden allowance, tracing/weak reclaim/forced GC or abandoned work. Focused Release
checks during iteration; batch full platform/Stress/installed consumers at delivery.
No overlapping local builds/tests/timing; force nonincremental after source restores.
Release packages only via tools/pack.ps1 into artifacts/nuget; no publication.

VM lokad@20.166.121.73/key ~/.ssh/id_lython-bench.pem. ThroughB503 terminal/cached/local
SHA verified, no users/fixtures; never requery. Finite service/lease, persistent workers/
catalog/raw separate from RAM, joined users/unmount/archive under lease. Space recovery
requires fresh idle exact bytes/all aliases/SHA/owner/group/mode/parents and persisted
pre-mutation plan; preserve every path/byte/floor. CI observations at least5min apart
using recorded UTC clocks; cache terminal once. Through42588611410 terminal/cached.
