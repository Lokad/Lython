from pathlib import Path
repo=Path('D:/code/Lython');p=repo/'PLAN.md';s=p.read_text(encoding='utf-8')
a=s.index('## Prioritized execution');b=s.index('## Substantial redesign roadmap',a)
s=s[:a]+'''## Prioritized execution

1. **Close R513 delivery without retiming.** Committed/pushed10ee56c7, measured
   2ede09fc: ordinary split/splitlines write directly into admitted final storage;
   eager range inventories/growth/copy/loan lifecycle removed. Genuine cased
   iteration keeps its required ranges. Each target119internal/298public,
   334independent CPython-backed assertions perAPI, sixgoldens/budgetreuse pass.
   Allocation17.319%lower; refined textwarm1.84–2.30%lower elapsed/supportingCPU,
   fresh1.31–2.72%lower elapsed/supportingCPU. Conservative accountedpeak+1.12%
   and earlier denial accepted. Calls inconclusive(5.22/8.37%process spreads),
   debt to revisit at a representative helper checkpoint. Originalf572/B937/B938
   adverse conditions remain separate; no subtraction/recovery/universal claim.
   Full44234151651running; Ubuntu originalstress/Windows10 ordinary at04:11UTC.
   Verify16summaries/2,389inputs/587production against2ede09fc after actualGREEN.
   No inherited qualification, unchanged timing replay or publication.
2. **R514 complete call-entry gate active.** One current original/helper-list text
   CPU capture B940 launched04:14UTC on quietVM;32-file image and actual custom
   catalog goldens pass. Reuse existing profiler, all-thread samples, default
   GC/tiering plus diagnostic perf maps only. This is attribution, not a speedup
   comparison. Await joined users/SHA-archived RAM evidence before cleanup or
   analysis. Identify a whole removable stage in current call/guard/publication
   work versus useful UTF8; final slots/borrowed args already direct. Preserve
   admission/refund reentry, stack/recursion, exceptions/current cancellation,
   aliases and actual suspension. Gate stops with a concrete deletion map or
   precise missing fact; do not repeat unchanged captures or rebuild a call arena.
3. **External comparison checkpoint complete.** R511 qualified2e585229/1bce52ad
   versus stockCPython3.13.16: two affected scripts, compile/warm/fresh phases,
   sixjobs226.36s. Text0.95–0.96×/1.60×/1.47–1.48×; floating0.91–0.93×/
   1.61–1.66×/1.38–1.47×. Floatingfresh CPython control4.91%limits precision;
   earlier adverse controls retained. I/O/cleanup boundaries explicit in guide.
   Older named CSV/JSON/record rows remain historical. No currentHEAD ratio.
   Refresh representative comparisons at the next coherent substantial delivery,
   not each isolated experiment. [Evidence](benchmarks/results/2026-11-18-affected-cpython-checkpoint/README.md).
4. **Continue the wider roadmap.** Select coherent work/storage elimination from
   current attribution. A successful gate or CI run is not completion of the
   performance objective. Regex development remains independent. Focused Release
   iteration, then full qualification at a coherent retained boundary.

'''+s[b:]
a=s.index('Next bulk-text source gate:');b=s.index('## Independent regex track',a)
s=s[:a]+'''R512 allocation attribution and R513 construction are completed source gates.
Their original failures, changed-source refinement, adverse/unstable timings,
retained-source decision and exact source/images remain in
[experimental history](benchmarks/EXPERIMENTS.md) and
[construction evidence](benchmarks/results/2026-11-18-direct-split-construction/refined/README.md).
R510 buffered yields and R513 direct construction remove different stages; do not
sum percentages or claim a common cause. Remaining generic drains are not evidence
for a universal tagged-value/buffer rewrite. Full R513 qualification is pending.

'''+s[b:]
p.write_text(s,encoding='utf-8',newline='\n')
print('Ignored active plan condensed; completed work preserved, current R513/R514 states and bounded redesign gates explicit.')
