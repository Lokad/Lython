from pathlib import Path
import subprocess
r=Path(__file__).resolve().parent;out=r.parent/'call-entry-r514-corrected';out.mkdir(exist_ok=False)
s=(r/'prepare.py').read_text(encoding='utf-8').replace('call-entry-b940-20261118','call-entry-b941-20261118').replace('lython-b940-call-entry-20261118','lython-b941-call-entry-20261118').replace('lython-b940-fixtures','lython-b941-fixtures')
s=s.replace('buffered-yield-transport/observations.tgz','direct-global-operands/refined/observations.tgz').replace('buffered-yield-b935-20261118/','direct-globals-refined-b934-20261118/')
s=s.replace('count = 64 # Complete current original/helper scripts;8s warmup,5s capture per case,12s total guest capture guard.','count = 256 # Correct128x64warmup shortfall; original failedcondition retained. Same8s warmup/5s capture/12s total guest cap.')
s=s.replace("(r/'ops-profile.py').write_text(s,encoding='utf-8',newline='\\n')", "s=s.replace('elapsed += result[\"elapsedTicks\"] / result[\"clockFrequency\"]','record.setdefault(\"warmupBatches\",[]).append(result); elapsed += result[\"elapsedTicks\"] / result[\"clockFrequency\"]')\n(r/'ops-profile.py').write_text(s,encoding='utf-8',newline='\\n')")
(out/'prepare.py').write_text(s,encoding='utf-8',newline='\n')
s=(r/'collect.py').read_text(encoding='utf-8').replace('call-entry-b940-20261118','call-entry-b941-20261118').replace('R514/B940','R514/B941')
s=s.replace("  assert sorted(p.name for p in fixture.iterdir()) in [[],['profiles']]",'''  manifest=[]
  for p in fixture.rglob('*'):
   m=p.lstat();assert not p.is_symlink()and m.st_uid==os.getuid()
   manifest.append(dict(path=p.relative_to(fixture).as_posix(),bytes=m.st_size,mode=oct(m.st_mode),uid=m.st_uid))
  (root/'ram-manifest.json').write_text(json.dumps(manifest,indent=2)+'\\n')''')
s=s.replace("   if trace.exists():archive.add(trace,arcname='profiles')","   for name in raw:archive.add(fixture/name,arcname=name)")
(out/'collect.py').write_text(s,encoding='utf-8',newline='\n')
subprocess.run(['C:/Python313/python.exe','-X','utf8',str(out/'prepare.py')],check=True)
print('Separate corrected condition prepared; original warmup/cleanup failure and recovery preserved.')
