from pathlib import Path
import subprocess
r=Path(__file__).resolve().parent
code='''from pathlib import Path
import fcntl,json,os,subprocess
root=Path('/home/lokad/lython-bench-checks/call-entry-b940-20261118')
with(root.parent/'comparison-vm.lock').open('a')as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record'],capture_output=True).returncode==1
 print(json.dumps(dict(idle=True,files=[dict(path=str(p.relative_to(root/'guest-fixtures')),bytes=p.lstat().st_size,mode=oct(p.lstat().st_mode),uid=p.lstat().st_uid,link=p.is_symlink())for p in (root/'guest-fixtures').rglob('*')],record=json.loads((root/'guest-fixtures/profiles/text-original/record.json').read_text()))))
'''
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
p=subprocess.run(ssh+['python3 -'],input=code,text=True,encoding='utf-8',capture_output=True,timeout=30)
(r/'failure-inspection.json').write_text(p.stdout,encoding='utf-8');assert p.returncode==0,p.stderr;print(p.stdout)
