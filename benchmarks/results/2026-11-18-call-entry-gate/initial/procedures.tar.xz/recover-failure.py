from pathlib import Path
import subprocess
r=Path(__file__).resolve().parent
code='''from pathlib import Path
import fcntl,json,os,stat,subprocess,tarfile,hashlib,shutil
root=Path('/home/lokad/lython-bench-checks/call-entry-b940-20261118');fixture=root/'guest-fixtures'
with(root.parent/'comparison-vm.lock').open('a')as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record'],capture_output=True).returncode==1
 state=subprocess.check_output(['systemctl','show','lython-b940-call-entry-20261118.service','--property=MainPID,ActiveState'],text=True);assert'MainPID=0'in state and'ActiveState=failed'in state
 assert os.path.ismount(fixture)
 manifest=[];regular={}
 for p in fixture.rglob('*'):
  m=p.lstat();assert not p.is_symlink()and m.st_uid==os.getuid()
  item=dict(path=p.relative_to(fixture).as_posix(),mode=oct(m.st_mode),bytes=m.st_size,uid=m.st_uid)
  if stat.S_ISREG(m.st_mode):item['sha256']=hashlib.sha256(p.read_bytes()).hexdigest();regular[item['path']]=item['sha256']
  else:assert stat.S_ISDIR(m.st_mode)or stat.S_ISFIFO(m.st_mode)or stat.S_ISSOCK(m.st_mode)
  manifest.append(item)
 (root/'ram-manifest.json').write_text(json.dumps(manifest,indent=2)+'\\n')
 assert not(root/'observations.tgz').exists()
 with tarfile.open(root/'observations.tgz','w:gz')as archive:
  for p in root.iterdir():
   if p.is_file()and p.name!='observations.tgz':archive.add(p,arcname=p.name)
  for name in regular:archive.add(fixture/name,arcname=name)
 with tarfile.open(root/'observations.tgz')as archive:
  for name,h in regular.items():assert hashlib.sha256(archive.extractfile(name).read()).hexdigest()==h
 subprocess.run(['sudo','-n','umount',str(fixture)],check=True);fixture.rmdir()
 assert shutil.disk_usage(root).free>252*1024*1024
 receipt=dict(complete=False,allWorkersJoined=True,quietBeforeAndAfter=True,guestFixturesRemoved=True,archivedAndVerifiedUnderLease=True,ramTraceArchivedAndVerifiedBeforeUnmount=True,freeBytes=shutil.disk_usage(root).free,archiveSHA256=hashlib.sha256((root/'observations.tgz').read_bytes()).hexdigest(),failure='128x64 warmup did not reach8guestseconds; no CPU capture; collector unexpected joined-worker CLR FIFO/socket assertion. Original files retained, manifest records nonregular diagnostics; no runtime design finding.',performanceComparison=False)
 (root/'archive-receipt.json').write_text(json.dumps(receipt,indent=2)+'\\n');print(json.dumps(receipt))
'''
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
p=subprocess.run(ssh+['python3 -'],input=code,text=True,encoding='utf-8',capture_output=True,timeout=45)
(r/'failure-recovery.log').write_text(p.stdout+p.stderr,encoding='utf-8');assert p.returncode==0,p.stdout+p.stderr;print(p.stdout)
