from pathlib import Path
import json,shutil,tarfile
r=Path(__file__).resolve().parent;repo=Path('D:/code/Lython');out=repo/'benchmarks/results/2026-11-18-call-entry-gate/initial';out.mkdir(parents=True,exist_ok=False)
q=json.loads((r/'archive-receipt.json').read_text(encoding='utf-8'));assert not q['complete']and q['ramTraceArchivedAndVerifiedBeforeUnmount']and q['allWorkersJoined']
for n in ['archive-receipt.json','observations.tgz','terminal-status.json','actual-worker-preflight.json','identity.json','failure-inspection.json','failure-recovery.log','source-facts.json']:shutil.copyfile(r/n,out/n)
with tarfile.open(out/'procedures.tar.xz','w:xz')as a:
 for p in sorted(r.glob('*.py')):a.add(p,arcname=p.name)
(out/'README.md').write_text('''# Initial current call-entry attribution: warmup shortfall

R514/B940,2026-11-18UTC, committed10ee56c7/measured2ede09fc. Current32-file image
and actual two-case original/helper catalog goldens pass. First original script
128batches of64invocations did not reach8guestseconds; capture never started.
This establishes a measurement-sizing shortfall, not a design failure or CPU result.

Worker joined by termination after warmup failure. Its native perf map was copied
and hash-verified before temporary-map retirement. The collector's extra assertion
then rejected remaining CLR diagnostic FIFO/socket entries. Recovery under the idle
lease recorded metadata, SHA-archived every regular RAM byte, verified the archive
before unmount, and preserved the252MiB floor. No live users/mount remain. The
failure, journal, original scripts and native map remain in the linked evidence.

A separately identified256batch correction retains8s warmup/5s capture per case
and12s total guest capture guard. No runtime/source change, favorable selection,
speedup claim or repeated backend qualification follows. Current normal adapter0.4
unchanged, publication postponed.
''',encoding='utf-8',newline='\n')
with(repo/'benchmarks/EXPERIMENTS.md').open('a',encoding='utf-8',newline='\n')as f:f.write('''

R514/B940 [initial current call-entry gate](results/2026-11-18-call-entry-gate/initial/README.md):32-file current2ede09fc/goldens pass;128x64warmup shortfall stopped before CPU capture. Strict residual-directory assertion also interrupted archival; joined-worker CLR FIFOs/socket metadata and every regular RAM byte subsequently archived/SHA-verified under idle lease before unmount. No remaining users/mount,252MiBfloor intact. This is measurement uncertainty, no design finding; separateB941256batch correction keeps original warmup/capture guards. No runtime change/performance claim.
''')
p=repo/'PLAN.md';s=p.read_text(encoding='utf-8').replace('CPU capture B940 launched04:14UTC on quietVM;32-file image and actual custom','CPU capture B940 stopped before sampling:128x64warmup shortfall. Initial failure/\n   joined-worker diagnostic metadata/RAM bytes archived and verified before cleanup.\n   SeparateB941256batch correction launched04:17UTC, original guards retained.\n   Current32-file image and actual custom');p.write_text(s,encoding='utf-8',newline='\n')
print('Failed original sizing/cleanup condition preserved separately; no CPU finding inferred.')
