from pathlib import Path
import hashlib,json,shutil,tarfile
r=Path(__file__).resolve().parent;repo=Path('D:/code/Lython');out=repo/'benchmarks/results/2026-11-18-call-entry-gate/corrected';out.mkdir(parents=True,exist_ok=False)
q=json.loads((r/'archive-receipt.json').read_text(encoding='utf-8'));assert q['complete']and q['allWorkersJoined']and q['ramTraceArchivedAndVerifiedBeforeUnmount']
assert hashlib.sha256((r/'observations.tgz').read_bytes()).hexdigest()==q['archiveSHA256']
lines=(r/'strings.il').read_text(encoding='utf-8-sig').splitlines();start=next(i for i,line in enumerate(lines)if"instance object '<.cctor>b__81_7'"in line);end=next(i for i in range(start,len(lines))if"end of method '<>c'::'<.cctor>b__81_7'"in lines[i])
(r/'sampled-wrapper.il').write_text('\n'.join(lines[start-1:end+1])+'\n',encoding='utf-8')
facts=dict(source='Committed10ee56c7/frozen2ede09fc, fully qualified R513',state='Source gate complete; no whole redundant call-entry stage established',cases=[dict(label=v['label'],samples=v['sampleCount'],unknownLeaves=v['unmappedLeafSamples'],invocations=v['invocations'],guestSeconds=v['guestClockSeconds'])for v in json.loads((r/'attribution.json').read_text(encoding='utf-8'))['rows']],conclusions=['Current calls use final local slots and borrowed operands, not old argument packaging.','341helper inclusive entry samples include NativeExecution body/receiver work, not a removable entry share.','Hot StringMembers .cctor b__81_7 is ExpandTabs, confirmed against exact measured IL; useful inlined text work, not strip-dispatch overhead.','Raw map/stack samples include reset, host I/O/protocol/goldens/cleanup;20percent unknown leaves and sampling/inlining constrain attribution.','No whole call-entry replacement justified by these samples. Do not remove stack/reentry guards or revive slower arenas/controllers.'],next='R515 bounded known-size working-drain construction: reuse existing Cursor.KnownCount to admit initial capacity once; retain generic live iteration/growth and protocol cleanup. Eliminates initial geometric growth/copy/admission lifecycle without new storage framework. Measure original/helper text plus nontext controls; allocation benefit is a hypothesis until measured.',regexProducerObservation='Read-only sibling16dc3122. Metadata/cursor interfaces unchanged from7e683b2d; group-name enumeration, retained creation token, result-staging bridges remain. No normal pin promotion or repeated qualification.',performanceComparison=False,publicationHeld=True)
(r/'decision.json').write_text(json.dumps(facts,indent=2)+'\n',encoding='utf-8')
for n in ['observations.tgz','archive-receipt.json','terminal-status.json','actual-worker-preflight.json','identity.json','attribution.json','decision.json','sampled-wrapper.il']:shutil.copyfile(r/n,out/n)
with tarfile.open(out/'procedures.tar.xz','w:xz')as a:
 for p in sorted(r.glob('*.py')):a.add(p,arcname=p.name)
(out/'README.md').write_text('''# Current original/helper call-entry attribution

R514/B941,2026-11-18UTC, committed10ee56c7/measured2ede09fc, now fully qualified.
Corrected batch256; same8guestsecond warmup/5second capture per case/12guestsecond
total capture guard. Original[128x64failure](../initial/README.md) remains separate.
32-file hashes/actual custom two-case goldens pass; defaultGC/tiering plus perf
maps only. All users joined, RAM evidence SHA-archived/verified before unmount.

Original:988all-thread samples/5,888invocations/4.641guestseconds; helper-list:
1,016samples/4,096invocations/4.821guestseconds. Boundaries include reset, mediated
I/O, checks, protocol and cleanup, wider than execution clocks. Unknown leaves:
206/186. This is source attribution, not a controlled performance comparison.

Ordinary calls already bind final slots/borrow operands. The341helper inclusive
function-entry samples contain body/receiver work and cannot be treated as a
removable stage. The hottest StringMembers .cctor b__81_7 wrapper actually calls
expandtabs, confirmed against the exact measured[IL](sampled-wrapper.il). Sampling
and inlining do not justify deleting safety guards or selecting a complete new
call controller. Heuristic overlapping groups are navigation aids; broad
ExecutionState matching is not isolated invocation-setup cost.

Next bounded construction milestone uses existing known-size facts for private
drains: remove initial geometric growth/copy/admission for fixed-size sequences;
preserve live mutable iteration, underestimates, first refusal and awaited cleanup.
No new arena/owner/cache/buffer framework. Controlled source-pair allocation and
CPU checks decide retention; no gain is established here. Wider roadmap remains
active; normal adapter0.4/core dependencies unchanged, publication postponed.

[Decision](decision.json),[attribution](attribution.json),[raw](observations.tgz),
[identity](identity.json),[checks](actual-worker-preflight.json),
[custody](archive-receipt.json),[procedures](procedures.tar.xz).
''',encoding='utf-8',newline='\n')
with(repo/'benchmarks/EXPERIMENTS.md').open('a',encoding='utf-8',newline='\n')as f:f.write('''

R514/B941 [corrected current original/helper CPU gate](results/2026-11-18-call-entry-gate/corrected/README.md):256batch/unchanged8s warmup/5s capture succeeds;988/1,016all-thread samples,206/186unknown leaves,5,888/4,096invocations. Existing final slots/borrowed arguments confirmed;341inclusive helper-entry samples include useful body. Exact measured IL identifies hot StringMembers b81_7 as expandtabs, not strip dispatch. No complete redundant call-entry stage established; preserve guards, do not revive slower arenas/controllers. Source gate ends with nextR515known-size working-drain lifecycle, existing Cursor facts/live iteration, no new framework; no CPU/allocation claim yet. All usersjoined/quiet gates/RAMSHAarchive/cleanup pass. Read-only producer16dc3122metadata/cursor surfaces unchanged7e; normal0.4pinunchanged, publicationheld.
''')
p=repo/'PLAN.md';s=p.read_text(encoding='utf-8');a=s.index('2. **R514');b=s.index('3. **External comparison',a)
s=s[:a]+'''2. **R514 source gate complete; R515 construction next.** One bounded correction
   after initial warmup shortfall; both conditions preserved. Current original/
   helper capture succeeds, all32hashes/goldens/quiet/join/RAMSHAarchive pass.
   Inclusive helper-entry341samples include useful body, not removable entry;
   hot wrapper is expandtabs(exact measuredIL). Unknown206/186leaves constrain
   attribution; no whole redundant call-entry stage established or CPU claim.
   Preserve guards; do not resurrect slower arenas/controllers. R515 uses existing
   Cursor.KnownCount to admit fixed-size working capacity once, removing initial
   geometric growth/copy/admission while keeping generic live iteration, mutable
   underestimates, maximumItems, first refusal/cancellation and awaited cleanup.
   No new framework/owner/policy. Focused drain/join/ownership/semantics on both
   targets; one bounded original/helper text comparison plus floating/call controls
   decides retention/refinement/regression debt. Then resume wider roadmap.
'''+s[b:]
s=s.replace('## Prioritized execution','| Fully qualified | R51310ee56c7/measured2ede09fc direct split construction; GREEN44234151651 verifies16summaries/2,389inputs/587production. Allocation17.319%lower; refined named text elapsed/CPU improve, peak+1.12%/call uncertainty remain. |\n\n## Prioritized execution',1)
p.write_text(s,encoding='utf-8',newline='\n');print('Current gate archived with exact limits/deletion hypothesis; next construction milestone selected, no CPU claim.')
