from pathlib import Path
import ast,hashlib,io,json,os,shutil,subprocess,tarfile
r=Path(__file__).resolve().parent;repo=Path('D:/code/Lython');prior=r.parent/'config-cost-r508';split=r.parent/'direct-split-r513'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
remote='/home/lokad/lython-bench-checks/call-entry-b941-20261118';old='/home/lokad/lython-bench-checks/config-cost-b932-20261118'
names=['scripts.text-normalization.large','scripts.text-normalization.helper-list']
catalog=json.loads((r.parent/'private-construction-r480/catalog.json').read_text(encoding='utf-8'))
catalog['cases']=[next(c for c in catalog['cases']if c['id']==n)for n in names]
(r/'catalog.json').write_text(json.dumps(catalog,indent=2)+'\n',encoding='utf-8')
frozen=json.loads((split/'frozen/identity.json').read_text(encoding='utf-8'));image=split/'frozen/candidate';files=frozen['imageFiles']['candidate']
assert len(files)==32 and all(sha(image/n)==h for n,h in files.items())
assert files['Lokad.Lython.dll']=='2ede09fc3c7271eafe2efc992e22d24fce45ed13f20cf133375a8e8020824f26'
dotnet=Path('C:/Users/JoannesVermorel/.dotnet11/dotnet.exe');env=os.environ.copy();env.update(DOTNET_ROOT=str(dotnet.parent),DOTNET_ROOT_X64=str(dotnet.parent));env['PATH']=str(dotnet.parent)+os.pathsep+env['PATH']
with(r/'actual-worker-preflight.log').open('w',encoding='utf-8')as log:
 p=subprocess.run([str(dotnet),str(image/'Lokad.Lython.Benchmarks.dll'),'--compare','verify','--catalog',str(r/'catalog.json'),'--dotnet',str(dotnet),'--python','C:/Python313/python.exe','--python-worker',str(repo/'benchmarks/cpython-worker.py'),'--out',str(r/'actual-worker-preflight.json')],env=env,stdout=log,stderr=subprocess.STDOUT)
assert p.returncode==0,(r/'actual-worker-preflight.log').read_text(encoding='utf-8')
identity=dict(sourceRevision='Committed10ee56c7/frozen2ede09fc; R513 delivery separate.',purpose='One current original/helper-list complete text CPU attribution; ordinary final-slot calls already direct, seek whole redundant entry/storage stage. No elapsed comparison.',imageFiles={'candidate':files},coreSHA256={'candidate':files['Lokad.Lython.dll']},catalogSHA256=sha(r/'catalog.json'),normalAdapterPin='0.4.0',publicationHeld=True)
(r/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8')
s=(prior/'ops-profile.py').read_text(encoding='utf-8').replace(old,remote)
s=s.replace("[('configuration','scripts.config-edit.small','compile-run')]",repr([('text-original',names[0],'warm'),('text-helper',names[1],'warm')]))
s=s.replace('count = 1024 # Same complete captured script per source; bounded attribution,not a timing comparison.','count = 256 # Correct128x64warmup shortfall; original failedcondition retained. Same8s warmup/5s capture/12s total guest cap.')
s=s.replace('elapsed += result["elapsedTicks"] / result["clockFrequency"]','record.setdefault("warmupBatches",[]).append(result); elapsed += result["elapsedTicks"] / result["clockFrequency"]')
(r/'ops-profile.py').write_text(s,encoding='utf-8',newline='\n')
(r/'run.sh').write_text((prior/'run.sh').read_text(encoding='utf-8').replace(old,remote),encoding='utf-8',newline='\n')
# Retain the established all-thread, owner-only classifier; add entry categories.
s=(r.parent/'current-cpu-r508/analyze.py').read_text(encoding='utf-8').replace("['floating','configuration']","['text-original','text-helper']")
s=s.replace("current=[]if header[1]in record['activeCpuTids']else None","current=[]")
s=s.replace("inclusive={name:sum(any(any(part in method for part in parts)for method in stack)for stack in samples)for name,parts in groups.items()}","def method_key(method):\n  head=method.split('(',1)[0]\n  if '::' not in head:return head\n  owner,name=head.rsplit('::',1);return owner.split()[-1]+'::'+name\n groups.update({'receiver entry':['InvokeReceiverMethod','TryInvokeClosedReceiver'],'interpreter guard':['EnterInterpreterFrame','LeaveInterpreterFrame','GuardedInvocation'],'function complete entry':['StartNativeCall','TryStartBoundInvocation','BindIntoSlots','EnterFunctionCall','LeaveFunctionCall','InitializeFrame'],'storage admission':['MemoryReservation','MemoryScope','MemoryBudget','MemoryGovernor']})\n inclusive={name:sum(any(any(part in method_key(method)for part in parts)for method in stack)for stack in samples)for name,parts in groups.items()}")
s=s.replace('Current complete floating warm/configuration compile-to-result whole-worker sampled CPU; selected active threads retain all-thread raw data/counts;', 'Current original/helper text ALL-thread whole-worker sampled CPU; method-owner-only groups, activeCpuTids remains guest subset;')
(r/'analyze.py').write_text(s,encoding='utf-8',newline='\n')
for name in ['launch.py','retrieve.py']:
 s=(prior/name).read_text(encoding='utf-8').replace('Configuration-only CPU attribution with corrected batch sizing source comparison','Current original/helper CPU attribution').replace('seconds=110','seconds=100').replace('before110seconds','before100seconds')
 if name=='retrieve.py':
  s=s.replace("assert status['exitCode']=='0'and status['receipt']['complete']and not status['remainingWorkers']and not status['remainingTrace']","assert status['receipt']and not status['remainingWorkers']and not status['remainingTrace']")
  s=s.replace("assert status['receipt']['ramTraceArchivedAndVerifiedBeforeUnmount']and status['receipt']['quietBeforeAndAfter']","assert status['receipt']['ramTraceArchivedAndVerifiedBeforeUnmount']")
 (r/name).write_text(s,encoding='utf-8',newline='\n')
# Prove one exact archived raw replica, not a general disk cleanup.
canonical='benchmarks/results/2026-11-18-direct-global-operands/refined/observations.tgz'
blob=subprocess.check_output(['git','show','HEAD:'+canonical],cwd=repo);assert blob==(repo/canonical).read_bytes()
member='confirmation/confirmation.json'
with tarfile.open(fileobj=io.BytesIO(blob))as a:data=a.extractfile(member).read()
proof=dict(kind='archived-raw-observation-replica',sha256=hashlib.sha256(data).hexdigest(),bytes=len(data),canonical=canonical,canonicalSHA256=hashlib.sha256(blob).hexdigest(),member=member,committedBlobVerified=True,paths=['direct-globals-refined-b934-20261118/'+member],links=1)
stage=['ops-profile.py','collect.py','run.sh','identity.json']
with tarfile.open(r/'payload.tgz','w:gz')as a:
 for n in stage:a.add(r/n,arcname=n)
c=dict(root=remote,unit='lython-b941-call-entry-20261118',source='/home/lokad/lython-bench-checks/direct-split-refined-b939-20261118',sourceFiles=files,sourceCatalogSHA256=json.loads((split/'quiet/config.json').read_text(encoding='utf-8'))['catalogSHA256'],catalogSource='/home/lokad/lython-bench-checks/private-text-costs-b894-20261117/catalog.json',catalogSHA256=sha(r/'catalog.json'),identity=identity,retireGroups=[proof],payloadBytes=(r/'payload.tgz').stat().st_size,payloadSHA256=sha(r/'payload.tgz'),unpackedBytes=sum((r/n).stat().st_size for n in stage))
(r/'config.json').write_text(json.dumps(c,indent=2)+'\n',encoding='utf-8')
s=(prior/'remote-launch.py').read_text(encoding='utf-8');a=s.index('c=');b=s.index('\nb=Path(',a);s=s[:a]+'c='+repr(c)+s[b:]
s=s.replace("source/'representative.json'","source/'representative.json'")
s=s.replace("for role in ['reference','candidate']:","for role in ['candidate']:")
s=s.replace('lython-b932-fixtures','lython-b941-fixtures')
(r/'remote-launch.py').write_text(s,encoding='utf-8',newline='\n')
for p in r.glob('*.py'):ast.parse(p.read_text(encoding='utf-8'))
print('Current32-file image/custom two-case actual-worker goldens pass; existing profiler reused, no runtime changes. Exact committed raw replica eligible:',len(data),'bytes. Stage bytes:',c['unpackedBytes'])
