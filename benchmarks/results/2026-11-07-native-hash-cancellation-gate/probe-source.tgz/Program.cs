using Lokad.Lython;
using Lokad.Lython.Runtime;
using Lokad.Lython.Runtime.Text;
using System.Text.Json;
using System.Security.Cryptography;

using var cancellation = new CancellationTokenSource();
var budget = new LythonMemoryBudget(1024 * 1024);
using var scope = budget.CreateScope();
var context = new LythonRuntime.ExecutionContext(new EmptyHost(),
    new LythonRunOptions { CancellationToken = cancellation.Token, MemoryBudget = scope });
var span = new LythonSourceSpan(1, 1, 1, 5);
var first = PyString.FromString("first", context.MemoryGovernor, span);
var second = PyString.FromString("second", context.MemoryGovernor, span);
var explicitToken = PyString.FromString("third", context.MemoryGovernor, span);
cancellation.Cancel();
bool syncReturned = false, asyncReturned = false, explicitTokenRefused = false;
try { _ = PyHashProtocols.PrepareKeyHash(first, context, span); syncReturned = true; }
catch (LythonRuntimeException error) when (error.Attribution?.Reason == LythonFailureReason.Cancelled) { }
try { _ = await PyHashProtocols.PrepareKeyHashAsync(second, context, span); asyncReturned = true; }
catch (LythonRuntimeException error) when (error.Attribution?.Reason == LythonFailureReason.Cancelled) { }
try { _ = explicitToken.GetHashCode(cancellation.Token, span); }
catch (LythonRuntimeException error) when (error.Attribution?.Reason == LythonFailureReason.Cancelled) { explicitTokenRefused = true; }
context.State.CloseResources();
scope.Dispose();
Console.WriteLine(JsonSerializer.Serialize(new { syncReturned, asyncReturned, explicitTokenRefused,
    tokenCancelled = cancellation.IsCancellationRequested, finalBudgetBytes = budget.ReservedBytes,
    coreSHA256 = Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(typeof(LythonEngine).Assembly.Location))) }));

sealed class EmptyHost : ILythonHost
{
    public string Cwd => "/";
    public DateTimeOffset LocalNow => DateTimeOffset.UnixEpoch;
    public DateTimeOffset UtcNow => DateTimeOffset.UnixEpoch;
    public ValueTask<bool> ExistsAsync(LythonPathRequest path, CancellationToken token) => throw new NotSupportedException();
    public ValueTask<IReadOnlyList<string>> ListDirAsync(LythonPathRequest path, CancellationToken token) => throw new NotSupportedException();
    public ValueTask MkDirAsync(LythonPathRequest path, CancellationToken token) => throw new NotSupportedException();
    public ValueTask RemoveAsync(LythonPathRequest path, CancellationToken token) => throw new NotSupportedException();
    public ValueTask CopyAsync(LythonPathRequest from, LythonPathRequest to, CancellationToken token) => throw new NotSupportedException();
    public ValueTask MoveAsync(LythonPathRequest from, LythonPathRequest to, CancellationToken token) => throw new NotSupportedException();
    public ValueTask<LythonPathStat> StatAsync(LythonPathRequest path, CancellationToken token) => throw new NotSupportedException();
}
