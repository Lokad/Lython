from pathlib import Path
import datetime,json,subprocess,time

r=Path(__file__).parent;expected='4aa2d46dadc6793e20159cf0a43316c14890d7d8'
assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()==expected
remote=subprocess.check_output(['git','ls-remote','origin','refs/heads/master'],text=True).split()[0]
assert remote==expected,remote
subprocess.run(['gh','workflow','run','ci.yml','--ref','master','-f','stress=true'],check=True)
time.sleep(10)
rows=json.loads(subprocess.check_output(['gh','run','list','--workflow','ci.yml','--event','workflow_dispatch','--branch','master','--limit','3','--json','databaseId,headSha,status,conclusion,url,createdAt'],text=True))
matches=[row for row in rows if row['headSha']==expected]
assert len(matches)==1,rows
row=matches[0];now=datetime.datetime.now(datetime.timezone.utc)
(r/'delivery-ci-initial.json').write_text(json.dumps(row,indent=2)+'\n',encoding='utf-8')
(r/'delivery-ci-status.json').write_text(json.dumps(row,indent=2)+'\n',encoding='utf-8')
(r/'delivery-ci-next-query.json').write_text(json.dumps(dict(observedUTC=now.isoformat(),notBeforeUTC=(now+datetime.timedelta(minutes=5)).isoformat(),terminal=row['status']=='completed'),indent=2)+'\n',encoding='utf-8')
print(json.dumps(row));print('Next query no earlier than',(now+datetime.timedelta(minutes=5)).isoformat())
