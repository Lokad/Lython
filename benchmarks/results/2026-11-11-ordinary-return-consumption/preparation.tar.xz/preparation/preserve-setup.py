from pathlib import Path
import json,shutil

r=Path(__file__).parent;p=r/'warm-sync';out=r/'initial-driver-path-failure';out.mkdir()
for name in ['measurements.json','stderr.log']:
    (p/name).rename(out/name)
(r/'setup-corrections.json').write_text(json.dumps(dict(
    internalBuild='The existing direct white-box native-call test required the new explicit consumption argument; updated its real caller, no compatibility overload.',
    diagnosticStartup='Passed image directories to an existing driver that requires core assembly file paths. FileLoadException before first workload; empty stdout and original stderr preserved.',
    correction='Pass the same already-frozen exact DLL files. No source/image/settings/threshold change, no completed measurement discarded.',
    cancellationMarker='Placed the late-side-effect marker after outer() using a single-line replacement independent of source newline encoding; cancellation tests rerun.'),indent=2)+'\n',encoding='utf-8')
print('Preserved original startup failure; only existing driver assembly path arguments corrected.')
