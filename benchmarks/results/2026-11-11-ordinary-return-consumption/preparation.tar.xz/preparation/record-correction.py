from pathlib import Path
import json

r=Path(__file__).parent;repo=Path.cwd();p=repo/'PLAN.md';s=p.read_text(encoding='utf-8')
s=s.replace('600internal/2649public','600internal/2653public')
s=s.replace('diagnostics are next; no quiet collection or retention decision yet.',
'''diagnostics complete on initial and corrected variants; captured-text allocation
  falls4.84%both APIs, compile allocation+0.05–0.16%. All original elapsed adversity
  retained; no CPU conclusion. B570two-job quiet confirmation active; no retention
  decision yet. See owned deadline below.''')
s+='''
R225 correctness refinement: first prototype copied final result consumption onto
the intermediate casing call. Four independent Python error-type cases failed;
the frozen pre-change core independently fails one. Fusion now reads the actual
split consumer only after exact native-chain validation; intermediate calls retain
their own use. Corrected600internal/2653public per actual target pass. Preserve
this correction if the broader optimization is withdrawn. Original initial and
corrected desktop sources/images/all timing/adversity remain separate. The corrected
source rerun is justified by semantic changes, not unchanged retiming.

B570active: iteration-returns-b570-20261111, unitlython-b570-iteration-returns-20261111,
PID3534378. Ack03:25:05.279UTC; do not observe before03:28:05.279UTC
(120owner/30stop/30margin). Setupfree266,133,504B, fixed240MiBfloor/12MiBheadroom.
Fresh lease and protectedc271/9dadd images verified. Exact committed compressed
B569/B461/B459/B465/B464 duplicates retired after path/UID/nlink/size/SHA proofs;
their remote archive paths are now off limits. No core image retirement or other
VM activity; original desktop uncertainty remains. Never re-query completed CI.

Independent regex input changed: read-only sibling HEAD8f953a93 records immutable
0.5.0-dev.68 acceptance. Assess only Lython-relevant API/package changes after the
R225 safe checkpoint; do not edit the sibling or repeat unchanged dev67 qualification.
Normal adapter0.4 and its exact three final-capability gaps remain until verified.
'''
p.write_text(s,encoding='utf-8')
record=dict(baseline='ba6ea8b4 fresh f6c8fd22 isolated public-boundary test image, one failed/three passed.',initial='Four failed custom-casing cases, initial-intermediate-result-net11.trx.',corrected='Four passed; full600internal/2653public eachactualtarget.',
    change='First call keeps its own metadata. Exact fused chain resolves the final split call consumer from existing instructions after dynamic guard. No copied final flags on intermediate calls.',
    retention='Preserve independently useful correction if ordinary return forwarding is withdrawn.',
    diagnostic='Initial and corrected six-script desktop observations retained separately. Corrected-source comparison justified by this semantic change. No runtime config/timing-setting change.')
(r/'consumption-correction.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8')
print('Recorded correction, source-qualified counts and active VM ownership/deadline in PLAN.')
