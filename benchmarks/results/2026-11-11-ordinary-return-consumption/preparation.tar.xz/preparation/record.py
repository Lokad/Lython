from pathlib import Path
import hashlib,io,json,shutil,subprocess,tarfile,xml.etree.ElementTree as ET

repo=Path.cwd();r=Path(__file__).parent;out=repo/'benchmarks/results/2026-11-11-ordinary-return-consumption';out.mkdir(exist_ok=True)
revision='4aa2d46dadc6793e20159cf0a43316c14890d7d8'
measured=json.loads((r/'corrected/diagnostic-identity.json').read_text(encoding='utf-8'))
with tarfile.open(fileobj=io.BytesIO(subprocess.check_output(['git','archive',revision,'src/Lokad.Lython'])))as a:
    source={m.name:hashlib.sha256(a.extractfile(m).read().replace(b'\r\n',b'\n')).hexdigest()for m in a if m.isfile()and m.name.endswith('.cs')}
assert len(source)==568 and source==measured['measuredSource']
checks={}
for f in sorted((r/'tests').glob('*.trx')):
    checks[f.name]=ET.parse(f).find('.//{*}Counters').attrib
    if f.name.startswith('corrected-'):assert int(checks[f.name]['failed'])==0,f
assert int(checks['baseline-intermediate-result-net11.trx']['failed'])==1
assert int(checks['initial-intermediate-result-net11.trx']['failed'])==4
(out/'focused-checks.json').write_text(json.dumps(checks,indent=2)+'\n',encoding='utf-8')
identity=dict(runtimeRevision=revision,normalizedSource=source,before=json.loads((r/'before.json').read_text(encoding='utf-8')),
    correctedCoreSHA256={f:hashlib.sha256((r/'corrected/cores'/f/'Lokad.Lython.dll').read_bytes()).hexdigest()for f in ['net11.0','net10.0']},
    sourceQualification='Committed retained R225;600internal/2653public focused checks pass on each actual.NET11/.NET10. Full CI42953725339 active on exact4aa2d46d, includes R222. Previous full4625 remains separate.',
    decision='Retain complete transient-construction removal, measured4.84%CLR allocation and15.06%coarse execution-allowance peak reduction, plus independent custom-casing correctness fix. Quiet elapsed/control uncertainty and all adverse original conditions remain. No universal CPU or current CPython claim.')
(out/'source-identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8')
for variant,folder in [('initial',r),('corrected',r/'corrected')]:
    target=out/variant;target.mkdir(exist_ok=True)
    shutil.copyfile(folder/'diagnostic-identity.json',target/'diagnostic-identity.json')
    for phase in ['warm-sync','warm-async','compile']:
        d=target/phase;d.mkdir(exist_ok=True)
        for name in ['measurements.json','summary.json']:
            shutil.copyfile(folder/phase/name,d/name)
quiet=out/'quiet';quiet.mkdir(exist_ok=True)
for name in ['observations.tgz','summary.json','archive-receipt.json','terminal-status.json','identity.json','exact-copies.json','footprint.json','observe-not-before.json']:
    shutil.copyfile(r/'b570'/name,quiet/name)
shutil.copyfile(r/'b570/retrieved/space-recovery.json',quiet/'space-recovery.json')
for name in ['semantic-goldens.json','intermediate-goldens.json','setup-corrections.json','consumption-correction.json','delivery-ci-initial.json','catalog.json']:
    shutil.copyfile(r/name,out/name)
receipt=json.loads((quiet/'archive-receipt.json').read_text(encoding='utf-8'))
assert receipt['complete']and receipt['jobs']==2 and receipt['allWorkersJoined']and receipt['guestFixturesRemoved']
assert hashlib.sha256((quiet/'observations.tgz').read_bytes()).hexdigest()==receipt['archiveSHA256']
seen={}
def add(archive,f,name):
    if f.suffix=='.dll':
        digest=hashlib.sha256(f.read_bytes()).hexdigest()
        if digest in seen:
            info=archive.gettarinfo(str(f),name);info.type=tarfile.LNKTYPE;info.linkname=seen[digest];info.size=0;archive.addfile(info);return
        seen[digest]=name
    archive.add(f,arcname=name)
with tarfile.open(out/'preparation.tar.xz','w:xz')as a:
    for f in sorted(r.rglob('*')):
        parts=f.relative_to(r).parts
        if not f.is_file()or any(k in parts for k in ['images','baseline','cores','baseline-custom-tests','retrieved','bin','obj','__pycache__']):continue
        if f.suffix not in ['.py','.json','.log','.md','.cs','.csproj','.props','.patch','.trx','.stdout','.stderr']:continue
        add(a,f,'preparation/'+f.relative_to(r).as_posix())
    for framework in ['net11.0','net10.0']:
        add(a,r/'baseline'/framework/'Lokad.Lython.dll',f'cores/before/{framework}/Lokad.Lython.dll')
        add(a,r/'corrected/cores'/framework/'Lokad.Lython.dll',f'cores/corrected/{framework}/Lokad.Lython.dll')
    add(a,r/'images/candidate/Lokad.Lython.dll','cores/initial/net11.0/Lokad.Lython.dll')
    for name in ['Lokad.Lython.Benchmarks.dll','Lokad.Lython.Benchmarks.deps.json','Lokad.Lython.Benchmarks.runtimeconfig.json','Lokad.Lython.Utf8Regex.dll','Lokad.Utf8Regex.dll','Lokad.Utf8Regex.PythonRe.dll']:
        add(a,r/'images/before'/name,'desktop-common/'+name)
    for name in ['complete-jobs.dll','complete-jobs.deps.json','complete-jobs.runtimeconfig.json']:
        add(a,r/'tool/bin/Release/net11.0'/name,'desktop-driver/'+name)
    for name in ['Lokad.Lython.PublicApi.Tests.dll','Lokad.Lython.PublicApi.Tests.deps.json','Lokad.Lython.PublicApi.Tests.runtimeconfig.json']:
        add(a,r/'baseline-custom-tests'/name,'baseline-regression-witness/'+name)
    for name in subprocess.check_output(['git','diff','--name-only','ba6ea8b4',revision,'--','src','tests'],text=True).splitlines():
        add(a,repo/name,'delivery/'+name)
    add(a,repo/'PLAN.md','active-plan-at-recording.md')
manifest={}
for name in ['preparation.tar.xz','quiet/observations.tgz']:
    f=out/name
    with tarfile.open(f)as a:
        for m in a:
            if m.isfile():a.extractfile(m).read()
    manifest[name]=dict(bytes=f.stat().st_size,sha256=hashlib.sha256(f.read_bytes()).hexdigest())
(out/'archive-identity.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8')
readme='''# R225 — ordinary direct-return iteration consumption

Retained runtime4aa2d46d,2026-11-11; fresh forced ba6ea8b4 reference. All568
production-source hashes match the measured corrected candidate. Normal adapter/
producer0.4 remains unchanged; no core package edge or new backend/option.
[Source identity](source-identity.json). Full [CI42953725339](https://github.com/Lokad/Lython/actions/runs/42953725339)
is active on exact4aa, including earlier R222; focused delivery is complete.

Ordinary direct returns now inherit their immediate-iteration caller's intent
through existing call/work/frame state, including promotion and real suspension.
They reuse the existing private cased-whitespace cursor. This removes the per-record
PyList, word-reference array and range-construction phase seen in R224. Guest-local
stores, exposed values, generators and other observable results keep real lists.
Native helper proofs are preserved; no new proof backend, packet, owner or policy.

The compiler records adjacency before operand forwarding, where a local store
cannot be hidden. One consumption rule serves ordinary and native entries. All
word capacities are admitted before caller-loop effects; pending users and cleanup
remain funded. Coarse admission and conservative retention remain the contract.

## Measured results

| Captured-helper text,3,072 lines | Result |
| --- | --- |
| CLR allocation, warm sync/async | −4.84% on both APIs |
| Estimated execution allowance peak | 1,958,019→1,663,039 B,−15.06%; accounting estimate, not RSS |
| Compilation allocation, six scripts | +0.05–0.16%; immutable call-use metadata |
| Quiet warm elapsed | −1.88..+0.34%; inconclusive |
| Wider process CPU | −3.43..−0.58%; modest supporting observation, not internal CPU attribution |
| Unchanged ordinary text | elapsed−2.81..+3.25%, CPU−3.99..+3.31%; neutrality unresolved |

Retain the construction/ownership simplification and useful allocation/allowance
reductions with explicit control debt. No demonstrated general elapsed gain,
CPython-ratio update, embedding-tail/RSS claim or completion of the larger objective.

Desktop diagnostics use the existing complete-job driver, two identical reference
images and one candidate, shared CoreLib/JIT/process GC,256warmups/image,
5rotated16-invocation rounds. Six identical complete scripts cover two counter
variants and ordinary text/CSV/report/JSON controls. Only core DLLs differ; all
goldens, stable allowance/final zero and fixture cleanup pass. Compilation/warm
sync/async are separate. [Initial](initial/) and [corrected](corrected/) observations
remain separate. Both show4.84%target allocation reduction; other warm bytes flat
within small measurement noise. Allocation counts are distinct from elapsed clocks.

Original desktop adversity remains: initial ordinary-text sync+16.91..23.62%, async
report+9.49..11.29%; corrected async JSON+11.26..19.49%, report+10.49..19.18%,
compile CSV+14.54..16.45%. Controls move substantially, including18.14%initial JSON
and14.73%corrected report. No favorable reinterpretation or CPU/neutrality claim.

Two quiet jobs finish75.187seconds on the reference AzureF4as_v7/Ubuntu24.04.4,
four EPYC9V45vCPUs,16GiB/no swap,actual.NET11RC3,ordinaryGC/tiering. Fixedfec79
worker/host/normal0.4adapter; exactf6c8fd22 reference versus9ee7e700 corrected core.
Four independent processes/job,5swarmups/7rotated400msrounds. Ranges span all four
process-median pairings, not confidence intervals. Target reference/candidate
spread0.36%/1.89%, maxIQR1.39%; ordinary control spread4.87%/1.05%, maxIQR0.87%.
[Exact medians/CPU/IQR](quiet/summary.json),[raw observations](quiet/observations.tgz).

Quiet warm includes mediatedRAM I/O, full per-invocation checks and prior-result
cleanup; excludes compile/reset/separate verification/protocol/startup/final caches.
Desktop additionally includes fixture reset and result disposal; execution-only
and wider clocks remain separate. WiderCPU includes surrounding work/coarse ticks.
These results do not establish genuinely pending-I/O latency.

## Correctness and original failed conditions

**600internal/2,653public focused checks pass per actual.NET11/.NET10** on corrected
source. Seven independent CPython3.13.2 scenarios, Unicode expansion/context cases,
retained projection/aliases, genuineIO and cancellation held through cleanup cover
the changed paths. Captured/forwarded preflight tests preserve the first terminal
refusal, funding before loop effects, cleanup and allowance reuse.
[All original/final counts](focused-checks.json),[Python goldens](semantic-goldens.json).

Review found a separate correctness issue: fusion copied final-result consumption
onto the intermediate lower() call, even when a custom method declined the native
chain. The frozen baseline fails one of four independent error-type regressions;
the first prototype fails all four. Fusion now reads the final split consumer only
after native-chain validation, retaining every intermediate call's real use.
Corrected source passes all four. Keep this fix independently if future work changes
the optimization. [Goldens](intermediate-goldens.json),[correction](consumption-correction.json).

The existing internal direct caller needed the new explicit intent argument; no
compatibility overload was added. Initial comparison setup used directory/core
paths where the unchanged driver requires its benchmark entry assembly. Failures
precede warmup and are preserved. The isolated baseline-test runner's unsupported
framework argument and existing-directory correction are likewise preserved.
The corrected-source measurement repeats because semantics changed; no unchanged
retiming or source/image/settings change hides original results.
[Setup record](setup-corrections.json),[exact source/images/logs/TRXs/recipes](preparation.tar.xz).

All quiet identity/output/ownership/quiet/Closed/zeroexit/join/RAM/unmount/archive
checks pass. Terminal is cached; no users/fixtures remain.120sowner/30stop/30margin.
Only five exact committed compressed duplicates were retired after fresh lease,
path/UID/link/size/SHA proof; protectedc271/9dadd images unchanged. Finalfree262,049,792B,
240MiBfloor preserved;12MiBsetupheadroom unchanged. [Receipt](quiet/archive-receipt.json),
[recovery](quiet/space-recovery.json),[archive hashes](archive-identity.json).
Publication and final producer qualification remain separate/postponed.
'''
(out/'README.md').write_text(readme,encoding='utf-8')
print('Recorded initial/corrected sources, original failures, focused checks and quiet receipts; archive contents independently verified.')
