from pathlib import Path
import hashlib,json,shutil,subprocess,tarfile

repo=Path.cwd();r=Path(__file__).parent;prior=r.parent/'incoming-lexical-stores-r221'
catalog=json.loads((prior/'catalog.json').read_text(encoding='utf-8'))
with tarfile.open(repo/'benchmarks/results/2026-11-11-json-cpython-checkpoint/observations.tgz')as a:
    ordinary=json.loads(a.extractfile('representative.json').read())
report=next(c for c in ordinary['cases']if c['id']=='scripts.report-render.large')
catalog['cases']=[report if c['id']=='scripts.report-render.nonlocal-counter.large'else c for c in catalog['cases']]
assert len(catalog['cases'])==6
(r/'catalog.json').write_text(json.dumps(catalog,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
tool=r/'tool';tool.mkdir()
for name in ['Directory.Build.props','complete-jobs.csproj']:
    shutil.copyfile(prior/'tool'/name,tool/name)
s=(prior/'tool/Program.cs').read_text(encoding='utf-8')
s=s.replace('Require three whole-script lexical-store variants and three unchanged controls.', 'Require two counter variants and four complete-script controls.')
s=s.replace('R221 owner-aware incoming lexical stores; identical complete scripts and fixed common images', 'R225 ordinary return consumption; identical whole scripts and fixed common images')
(tool/'Program.cs').write_text(s,encoding='utf-8')
shutil.copyfile(prior/'summarize.py',r/'summarize.py')
out=r/'images/candidate';out.mkdir()
for f in (r/'images/before').iterdir():
    if f.is_file():shutil.copyfile(f,out/f.name)
shutil.copyfile(repo/'src/Lokad.Lython/bin/Release/net11.0/Lokad.Lython.dll',out/'Lokad.Lython.dll')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
images={role:{p.name:sha(p)for p in(r/'images'/role).iterdir()if p.is_file()}for role in ['before','candidate']}
assert [name for name in images['before']if images['before'][name]!=images['candidate'][name]]==['Lokad.Lython.dll']
paths=subprocess.check_output(['git','ls-files','src/Lokad.Lython'],text=True).splitlines()
identity=dict(before=json.loads((r/'before.json').read_text(encoding='utf-8')),images=images,
    measuredSource={p:hashlib.sha256((repo/p).read_bytes().replace(b'\r\n',b'\n')).hexdigest()for p in paths if p.endswith('.cs')},
    qualification='225initial public;600internal/2649public focused iteration/function/generator/cancellation/memory checks plus new independent CPython/lifetime cases tracked per actual target. Full platform/package only at retained delivery.',
    boundary='Existing complete-job driver; two counter variants and four complete-script controls. Compilation separate. Warm includes public execution, fixture reset, mediated I/O, full validation and result disposal; startup/final cache teardown excluded. OrdinaryGC/tiering; desktop elapsed/coarse CPU diagnostic, allocation separate.')
(r/'diagnostic-identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8')
(r/'measured-source.patch').write_bytes(subprocess.check_output(['git','diff','--','src']))
for phase in ['warm-sync','warm-async','compile']:
    folder=r/phase;folder.mkdir()
    shutil.copyfile(prior/'warm-sync/hash-witness.json',folder/'hash-witness.json')
print('Prepared fixed common images, six complete scripts and existing driver. No timing started.')
