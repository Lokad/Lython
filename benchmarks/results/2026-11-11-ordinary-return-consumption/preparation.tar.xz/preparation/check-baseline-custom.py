from pathlib import Path
import hashlib,json,os,shutil,subprocess

repo=Path.cwd();r=Path(__file__).parent;out=r/'baseline-custom-tests';out.mkdir(exist_ok=True)
for f in(repo/'tests/Lokad.Lython.PublicApi.Tests/bin/Release/net11.0').iterdir():
    if f.is_file():shutil.copyfile(f,out/f.name)
    elif f.name not in ['TestResults']:shutil.copytree(f,out/f.name,dirs_exist_ok=True)
shutil.copyfile(r/'baseline/net11.0/Lokad.Lython.dll',out/'Lokad.Lython.dll')
before=json.loads((r/'before.json').read_text(encoding='utf-8'))
assert hashlib.sha256((out/'Lokad.Lython.dll').read_bytes()).hexdigest()==before['coreSHA256']['net11.0']
env=os.environ.copy();env['DOTNET_ROOT']='C:/Users/JoannesVermorel/.dotnet11';env['PATH']=env['DOTNET_ROOT']+os.pathsep+env['PATH']
command=[env['DOTNET_ROOT']+'/dotnet.exe','vstest',str(out/'Lokad.Lython.PublicApi.Tests.dll'),
    '--TestCaseFilter:FullyQualifiedName~CustomCasingResultIsConsumed',
    '--Logger:trx;LogFileName=baseline-intermediate-result-net11.trx',
    '--ResultsDirectory:'+str(r/'tests')]
done=subprocess.run(command,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,env=env)
(r/'baseline-intermediate-result.log').write_bytes(done.stdout)
assert done.returncode in (0,1),done.stdout.decode('utf-8')
assert (r/'tests/baseline-intermediate-result-net11.trx').is_file(),done.stdout.decode('utf-8')
print(done.stdout.decode('utf-8')[-6000:])
