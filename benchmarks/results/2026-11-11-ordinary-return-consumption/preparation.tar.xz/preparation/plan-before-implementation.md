# Lokad.Lython 0.11.0

Updated 2026-11-11. Git-ignored: never force-add. Publication/tagging postponed.
Objective: coherent simplification and substantial complete-script improvements,
including compilation. Another isolated experiment does not complete the objective.

## Actual delivery status

- **Committed source:** R222 frontend correction31e66aa6, global-barrier coverage
  4e1d373e; runtime R2214625d83e includes R2191208a681. All pushed. Evidence2c58ab26/6c11b5cf.
- **Fully qualified R219/R221:** exact4625, cached GREEN42942735331, inspected
  02:24:40UTC: Windows/Ubuntu, actual.NET11/.NET10 ordinary and original stress,
  installed Release consumers. Every required step inspected. Never query again.
  This does not qualify later R222. [Receipt](benchmarks/results/2026-11-11-incoming-lexical-stores/delivery-ci.json).
- **R222 focused-qualified:** 1393public/505internal per actual target; seven
  independent CPython goldens, target-isolation checks and11-case global-barrier
  suite per target. Both APIs, runtime error types and budget reuse/final zero.
  Full platform/package qualification joins the next coherent source boundary.
- **Earlier fully qualified:** JSON e122/7714144f cachedGREEN42931921242;
  69644713 cachedGREEN42918112217; e543bf15 cachedGREEN42898279287;
  439e91d9 cachedGREEN42888642699. No unchanged qualification/status replay.
- **R223 complete:** six jobs164.378s/all gates at qualified4625/cb03; ordinary text
  warm1.41–1.43× / complete1.35–1.40× CPython; captured-helper/counter warm2.61–2.62× /
  complete2.29–2.37×. Compilation separate. No active VM workers/runtime prototype.
- **R224 source gate complete:**1166samples/4.20%unknown; actual ordinary helper
  materializes split lists before caller iteration.236SplitCore stacks, no private
  preparation. Call entry alone does not explain the full gap. All owners joined.
- **Next R225:** ordinary direct-return consumption forwarding; concrete construction
  phase selected below. No active VM workers or production prototype.

## Completed milestones and evidence

| Delivered work | Established result / limits |
| --- | --- |
| Shared compiler facts | Corrects exponential shared-expression traversal and reuses binding/module facts. No ordinary compilation-dominance inference. |
| Direct UTF-8 formatting/storage | Fully qualified; CLR allocation−8.67%; controlled elapsed/CPU about5–8% lower. Original adverse15.125ms retained, unexplained. No unchanged retiming required. |
| Native helper returns | Fully qualified; CLR allocation−19.92%sync/−19.31%async. Original elapsed changes diagnostic; no remaining delivery checks. |
| Invocation/call consolidation | Shared immutable builtin metadata, reused async startup workers, direct/shared binding, receiver-aware entry and deferred contexts delivered. Mutable namespaces/defaults remain isolated/live. Slower alternative arenas/maps/control paths removed. |
| CSV record construction | Earlier6–8% opportunity reassessed and delivered as shared canonical keys/funded row-array adoption. No presumed second row copy/list shell/per-field admission remains. Original growth/control adversity retained. |
| Native dictionary accumulation | One probe for ordinary updates delivered; source-specific whole CSV/text gains with possible report control debt preserved. |
| R198 method contexts | Fully qualified66eb; class-report allocation−28.5%, quiet elapsed about7–10%sync/5–10%async; ordinary-report uncertainty remains. |
| R203 private split consumption | Fully qualifieddba; shared scanner/writer removes transient list/value arrays. Text allocation−5.2%, quiet sync elapsed1–3% lower with supporting CPU; other controls uncertain. |
| R207/R208 loop/tuple construction | Fully qualified439/e543; direct same-suite jumps and span constructors remove cleanup/copy/admission phases. CSV allocation−2.47%/−3.04%; CPU/control debt remains explicit. |
| R196/R217 JSON construction/strings | Fully qualified8d44/e122. Iterative construction and native admitted final UTF-8 remove recursive completion and backend rewrite/unescape/copy chain;156net runtime lines removed in R217. Allocation flat for current short strings; original adversity and quiet uncertainty retained. |
| R210/R215 regex contract/dev inputs | Qualified696; immutabledev67 passes86internal/524public Validate and86/528 development AssumeValid per target,29-file normal isolation proofs. Normal0.4 unchanged. |
| R220 source/cost attribution | Existing R21164Monitor leaves uniquely mapped:38aggregate split/26string-line admissions. No demonstrated contention/duplicate resize/removable CPU; no new budget mechanism/capture. |
| R219 regex working storage | Fully qualified4625. Prepared operation owns one coordinate array/cursor; two per-match arrays/reservation and caller plumbing deleted. Unicode iteration allocation−17–18%; desktop clocks/control adversity preclude CPU claims. |
| R221 incoming lexical stores | Fully qualified4625. Existing owner updates live slot/namespace once after operand cleanup; removes context promotion/name search/duplicate synchronization. Counter CSV/text/report allocation−41.4/47.9/27.5%; quiet warm elapsed−16–17/19–21/12–15%, supporting widerCPU. Ordinary-text neutrality unresolved (~+1.2%possible debt); all desktop adversity preserved. |
| R222 nonlocal diagnostics | Reuses scope validation's resolved targets, without another visitor or call-effect tracing. Declared nested nonlocal targets use runtime unbound checks after deletion/handler cleanup; ordinary certain-local diagnostics remain. Read-only declarations also conservatively defer diagnosis; documented compatibility tradeoff. No performance claim. |

Current source-labelled external comparisons: [BENCHMARKS](docs/BENCHMARKS.md).
All earlier completed items, failures, source variants, rejected designs and detailed
qualification remain in the [experimental index](benchmarks/EXPERIMENTS.md) and its
immutable evidence. Prior plans/source gates stay under .git/agent-notes/review-20261031/.
Do not repeat unchanged qualification or put experimental history in docs/.

## Prioritized roadmap

### P0 — finish current comparison and record the delivery boundary

R219/R221 full delivery and source-labelled CPython guide/evidence are committed
6c11b5cf. Cached receipt recorded; never re-query that run. R222's later frontend
correction remains separately focused-qualified. No new full cycle for a docs-only
change. Preserve original R221 frontend failure/goldens alongside the corrected
R222 semantics; no runtime behavior was removed to satisfy a source assumption.

**R223 complete:** existing ordinary text and captured-helper/counter text against
stockCPython3.13.16, exact qualified4625/cb03. Six jobs164.378s, all source/output/
ownership/quiet/Closed/join/RAMcleanup/archive checks pass. Both complete scripts
use identical source/fixtures/checks per engine; ordinary hashes equal priore543.
Ordinary warm1.41–1.43× / complete1.35–1.40×, completeCPython control2.94% variable.
Captured helper warm2.61–2.62× / complete2.29–2.37×, compile0.82–0.83×. Compilation
does not explain its warm gap. Wrapping changes locality and the counter changes
helper work; cross-script difference is not an isolated counter-cost measurement.
Current BENCHMARKS rows are updated, earlier evidence preserved. Later R222 is
separate. [Evidence](benchmarks/results/2026-11-11-text-cpython-checkpoint/README.md).

Boundary: mediatedRAM I/O/full output checks/prior-result cleanup included;
reset/separate verification/protocol/startup/final caches excluded. Compilation
includes construction/disposal; phase medians need not add. No pendingI/O/RSS/tail
latency or one-change attribution. All adverse original conditions survive.

### P1 — next substantial complete-script redesign

**R224 complete:** one warmed6swall capture, qualified4625/cb03,1166execution-thread
samples/49unknown(4.20%);5.86guest CPU/5.936worker execution seconds. Zero ambiguous
leaves; all-containing-range lookup retains stub aliases explicitly.236stacks
contain materializing SplitCore, none private preparation. Source confirms ordinary
returns lose existing immediate-iteration intent. Binding already reuses compiler-
sized local/operand storage, and this helper doesn't create a lexical context.
Call-entry leaves5.23%/operand-result9.78% include useful/inlined work; neither
predicts the entire external gap or removable CPU. All source/output/quiet/ownership/
Closed/join/RAM/archive gates pass; no elapsed comparison or runtime edit.
[Evidence](benchmarks/results/2026-11-11-captured-helper-cost/README.md).

**R225 next coherent migration — ordinary direct-return consumption:** forward the
existing caller's private iteration intent across ordinary executable direct
returns, including captured helpers, using the existing engine/kernel. Eliminate
the per-record PyList/word-reference-array/split-range construction phase that
R224 demonstrates; do not extend native-body proofs or add another backend/packet/
policy. Real guest-visible lists retain their existing materializer. This is
construction removal, not a promise to solve the whole2.61× gap.

Source-level completion: private results flow only from a direct returned producer
to a caller's immediate iteration; no observable local-store/alias/projection may
contain them. Propagate intent through existing call/work/frame state, including
promotion/suspension, without retaining borrowed operand spans. Retire native-only
intent forwarding where a shared existing path can serve it; no partial new route
promoted alone. Preserve measured native helper returns and genuine general calls.

Acceptance: ordinary versus immediate-iteration calls to the same callable; real
list type/identity/indexing/mutation and retained aliases; nested/captured/bound
helpers and dynamic/default/protocol evaluation; generators' StopIteration values;
try/with/finally unwind, overridden returns and exceptions; actual async I/O and
current-token cancellation; complete-word preflight before first caller loop effect,
terminal refusal and shared allowance reuse. Funding survives actual cleanup/users;
no new ownership subsystem or earlier refund. Conservative retention remains allowed.

Freeze current committed source before edits. One existing complete-job before/after:
captured-helper text target plus unchanged ordinary text/CSV/report controls; warm
sync/async and compilation separate. Record eliminated storage, compile/retained
costs and all adverse controls. Quiet confirmation only if justified. Retain/refine/
withdraw at a complete forwarding milestone with explicit regression debt; no fixed
percentage veto or broader call-stack/compiler rewrite. After a retained boundary,
batch full platform/stress/installed consumers including the R222 frontend fix.

Use the checkpoint to identify the remaining useful-script gap. Existing R211
ordinary-text stacks and R206 allocation associations remain available; they do
not establish exact per-type bytes or current counter-workload CPU shares. Reuse
them when source/workload facts still apply. If the changed helper shape needs
attribution, permit one bounded six-second capture answering that specific question;
do not repeat unchanged ordinary profiles or launch an ownership-audit campaign.

| Boundary / workloads | Required eliminated phase and semantic acceptance |
| --- | --- |
| Complete calls/frames; CSV/text helpers and class reports | Direct binding, native helper returns, deferred contexts, shared workspace and receiver entry already exist. Select an actual repeated complete construction phase; remove displaced binder/frame/transport work at completion. Preserve defaults, keyword mapping, descriptors, closures, handler context, evaluation order, suspension and source diagnostics. R204 mapped packets and R214 target mutation did not simplify the necessary binder. |
| Operand/scalar transport; counters/aggregation | Boxed integers remain material allocations; old scalar CPU shares are modest. A coherent representation must cover producers/consumers, identity, aliases, exact overflow promotion and public ingress/projection. Remove the displaced transport, rather than adding another sidecar. R176/R188 bytes alone did not justify their dispatch complexity. |
| Per-record collections; CSV/JSON aggregation | CSV already shares keys and adopts funded capacity. Native dictionaries and live module/environment views are real IPyDictStorage consumers; self-routing alone is not a demonstrated dominant phase. Select only an actual remaining parse/construction/copy boundary, preserving mutable headers, insertion order, duplicate keys, protocols, retention and reentrant refusal. |
| Remaining text boundaries; text/report/JSON | Casing, whitespace split, formatting and JSON strings already write final UTF-8. .NET11 numeric formatting uses UTF-8 TryFormat; .NET10's admitted char bridge avoids the allocating inherited interface. Require a real remaining conversion/intermediate phase; preserve Unicode context/expansion, hooks, error offsets and cancellation. |
| Frontend; config/search/compile-to-result | Shared binding/module/scope facts, precedence climbing, compact declaration metadata and direct child traversal are delivered. Existing visitors retain different facts; no blind merger or eligibility inventory. Select repeated analysis only when current source/cost evidence establishes its relevance. Preserve diagnostics and dynamic Python semantics. |

For every selected redesign record hypothesis, eliminated work/storage/functions,
affected complete scripts, compile/retained-memory costs, semantic checks, and one
bounded before/after with unchanged controls. No partial preparatory abstraction
promoted alone. Temporary regression debt needs an explicit completion milestone
and retain/refine/withdraw decision. Remove displaced-only machinery at that point.
No predicted speedup from sample shares; do not manufacture another narrow patch.

### P2 — maintained representative comparisons

R209CSV/text is source-labellede543, R218JSON/report source-labellede122; both retain
full measurements and qualification. R223 refreshes affected text coverage at4625.
Other rows keep their historical revisions. Refresh further workloads only after
material retained milestones or a material fairness gap, separating compilation,
warm execution, I/O/cleanup and startup. Pending I/O/RSS/embedding impact remain
unqualified. CPython is the primary external baseline; Lython source-pair gains
belong separately. A checkpoint is evidence, not completion of the objective.

## Independent regex track

Core Python-specific UTF-8 contract, effective flags, byte ranges/scalar positions,
original windows, current tokens and explicit ownership are delivered; no backend
package edge. Optional adapter remains non-packable/normal0.4. Dev67qualification
is complete; don't repeat it unchanged or promote the normal pin without evidence.
Missing producer capabilities defer only affected final adapter qualification:

- Single-match working ownership independent of retained results.
- Native UTF-8 group-name enumeration; native lookup already exists.
- Token-independent cursor creation with cancellable preparation. Per-move tokens
  exist; creating with None does not establish interruption during preparation.

Continue core/contract implementation independently. Development producers and
adapter-local bridges are allowed. Native single-match migration must retire
discarded DetailedData projections and preserve Match/FullMatch alternative
selection, captures, original windows and working/result funding; filtering Search
is not equivalent. Retire bridges when native APIs arrive, then qualify an immutable
released producer. Separate contract/semantic tests from actual backend performance,
safety and SizeOf assessment. No new memory infrastructure or silent dialect fallback.

## Iteration and lasting constraints

Timeouts, unstable unchanged controls and inconclusive measurements mean uncertainty,
not failed design. Allow bounded confirmation/refinement/correction with evidence;
retain original failures/adversity. Percentages inform, never automatically veto.
Distinguish deletion, allocation, demonstrated CPU, retained memory and latency.

Focused Release correctness/cancellation/ownership checks during development; no
overlapping local build/test/timing. Force nonincremental builds after restored
source. Batch Windows/Ubuntu, actual11/10, original stress and installed Release
consumers at meaningful boundaries; keep working while CI runs. Active CI queries
at least5min apart, cache terminals and never query completed runs. Publication/tag
postponed; only core Release packages via tools/pack.ps1 into artifacts/nuget/.

Fully managed/memory-safe: no unsafe, Unsafe APIs, raw pointers, P/Invoke or native
stack probing. Preserve managed stack admission, host capabilities, current-token
checks through actual long work, cycle detection, XML depth, checked representation
bounds and bounded I/O chunks. No fuel/host quotas, independent resource caps/hidden
allowances, guest tracing/root inventories, weak reclamation, forced GC, admission
retry or abandoned users. All filesystem operations keep LythonPathRequest/Cwd and
host component resolution; never delete a destination to emulate copy/replacement.

Borrowed shared memory funds major capacity/replacement overlap and results/aliases/
caches/pending users until awaited cleanup. Scope creation reserves zero. First
refusal fails the command with its original structured origin despite suppression/
finally returns; native cleanup stays available. Guest MemoryError remains catchable.
Long streaming uses bounded host commands, not guest-reference tracing.

## VM ownership and retained evidence

VMlokad@20.166.121.73, key~/.ssh/id_lython-bench.pem. Persistent evidence; RAM only
owned guest fixtures. B568 is terminal/cached/no users or RAM fixtures, archiveSHA
4056baa1 verified locally; do not query again. Finalfree262,844,416B; setupfree
265,764,864B, fixed240MiBfloor/12MiBsetupheadroom unchanged. R224 also completed under a fresh lease; no overlapping collection or stale recipe.

B565/B566/B567 and all older runs terminal/cached. Protected qualified B565/reference
c27160d5 (b8/696) and B566/candidate9dadd59b (e122) are hash-verified unchanged.
R221frozencb03source4625 is now fully qualified; do not relabel it laterR222.
B568retired exact compressed B566/B567/B463 duplicates only after fresh idle lease,
path/UID/nlink/size/SHA proof against committed archives; those remote archive paths
are off limits. B567retired B457/B453/B451compressed duplicates; earlier B558/B561/
B562/B563/B564/B565compressed copies, B563raw/map/B562map and B561/B564confirmation
remain retired. Earlier0e/2f9/101/Dbe/039/E294/379/67 aliases are off limits; do not
probe them. Canonical archives preserve all original sources/observations. New
staging needs a fresh lease/identity/disk proof; never replay stale launch recipes.

B569captured-text profile is terminal/cached, archiveSHA02764041 verified locally;
no users/RAM remain and no repeat service query. Setupfree264,650,752B; final floor
>240MiB verified by successful archive assertion, exact final free bytes unmeasured.
Only the exact committed B568 compressed archive was additionally retired; that
remote observations.tgz path is now off limits. Both protected qualified images
remain unchanged. Any future collection needs a fresh idle/disk lease; no VM work
is selected while the R225 source migration is prepared.
