from pathlib import Path
import json, subprocess, sys

r=Path(__file__).parent
cases=[
('captured-and-forwarded', '''def outer():
 count=0
 def words(value=' A B '):
  nonlocal count
  count+=1
  return value.lower().split()
 def forward(value):return words(value=value)
 for word in forward(' C D '):print(word)
 result=forward(' E F ')
 result.append('g')
 print(type(result).__name__,result)
 words.__defaults__=(' NEW WORD ',)
 print([word for word in words()])
 print(count)
outer()
'''),
('stored-result-remains-observable', '''kept=[]
def outer():
 count=0
 def words(value):
  nonlocal count
  count+=1
  result=value.lower().split()
  kept.append(result)
  return result
 seen=[]
 for word in words(' A B '):
  seen.append(word)
  if word=='a':kept[0].append('c')
 print(seen,type(kept[0]).__name__,count)
outer()
'''),
('cleanup-and-overridden-return', '''events=[]
class Manager:
 def __enter__(self):events.append('enter')
 def __exit__(self,*args):events.append('exit');return False
def outer():
 count=0
 def words(value,override=False):
  nonlocal count
  count+=1
  with Manager():
   try:return value.upper().split()
   finally:
    events.append('finally')
    if override:return ['override']
 for word in words(' a b '):events.append(word)
 for word in words(' ignored ',True):events.append(word)
 result=words(' c d ')
 print(events,type(result).__name__,result,count)
outer()
'''),
('generator-return-and-yield-from', '''def outer():
 count=0
 def words(value):
  nonlocal count
  count+=1
  return value.lower().split()
 def generate():
  yield 'start'
  return words(' A B ')
 generator=generate()
 print(next(generator))
 try:next(generator)
 except StopIteration as done:print(type(done.value).__name__,done.value)
 def delegated():yield from words(' C D ')
 print(list(delegated()),count)
outer()
'''),
('bound-default-and-dynamic-protocol', '''class Words:
 def __init__(self):self.count=0
 def words(self,value=' A B '):
  self.count+=1
  return value.lower().split()
class Text:
 def lower(self):print('lower');return self
 def split(self):print('split');return ['custom']
instance=Words()
saved=instance.words
print([word for word in saved()])
Words.words.__defaults__=(' C D ',)
print([word for word in instance.words()])
print([word for word in saved(value=Text())])
print(type(saved()).__name__,instance.count)
'''),
('handler-and-return-exception', '''def outer():
 count=0
 def words(value):
  nonlocal count
  count+=1
  try:raise ValueError('local')
  except ValueError as error:
   return value.lower().split()
 try:raise RuntimeError('outer')
 except RuntimeError as previous:
  for word in words(' A B '):
   try:raise LookupError(word)
   except LookupError as error:print(word,error.__context__ is previous)
 print(count)
outer()
'''),
('direct-branch-versus-stored-branch', '''kept=[]
def outer():
 count=0
 def words(value,store):
  nonlocal count
  count+=1
  if store:
   result=value.upper().rsplit()
   kept.append(result)
   return result
  return value.lower().split()
 print([word for word in words(' A B ',False)])
 for word in words(' c d ',True):
  print(word,type(kept[-1]).__name__)
 print(words(' E F ',False),count)
outer()
''')]
records=[]
for name,source in cases:
    done=subprocess.run([sys.executable,'-X','utf8','-I','-c',source],capture_output=True,text=True,encoding='utf-8',check=True)
    assert not done.stderr,done.stderr
    records.append(dict(name=name,source=source,expected=done.stdout))
(r/'semantic-goldens.json').write_text(json.dumps(dict(reference=sys.version,cases=records),ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
rows='\n'.join('        { '+', '.join(json.dumps(record[k],ensure_ascii=True)for k in ['name','source','expected'])+' },'for record in records)
test='''using Lokad.Lython.Tests.Harness;

namespace Lokad.Lython.PublicApi.Tests;

public sealed class ReturnedIterationTests
{
    public static TheoryData<string, string, string> PythonGoldens => new()
    {
ROWS
    };

    [Theory]
    [MemberData(nameof(PythonGoldens))]
    public async Task DirectReturnConsumptionPreservesObservablePythonValues(string name, string source, string expected)
    {
        var budget = new LythonMemoryBudget(4 * 1024 * 1024);
        using (var script = new LythonEngine().Compile(source, budget))
        {
            Assert.True(script.IsValid, name + ": " + string.Join("; ", script.Diagnostics.Select(d => d.Message)));
            var baseline = budget.ReservedBytes;
            var options = new LythonRunOptions { MemoryBudget = budget };
            foreach (var asynchronous in new[] { false, true })
            {
                using (var result = asynchronous ? await script.RunAsync(new MockLythonHost(), options)
                    : script.Run(new MockLythonHost(), options))
                {
                    Assert.True(result.Success, name + ": " + result.Failure?.Message);
                    Assert.Equal(expected, result.StandardOutput);
                }
                Assert.Equal(baseline, budget.ReservedBytes);
            }
        }
        Assert.Equal(0, budget.ReservedBytes);
    }
}
'''.replace('ROWS',rows)
Path('tests/Lokad.Lython.PublicApi.Tests/ReturnedIterationTests.cs').write_text(test,encoding='utf-8')
print(f'{len(records)} independent CPython goldens verified; public returned-iteration tests written.')
