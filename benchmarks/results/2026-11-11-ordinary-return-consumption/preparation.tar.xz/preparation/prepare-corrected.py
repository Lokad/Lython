from pathlib import Path
import hashlib,json,shutil,subprocess

repo=Path.cwd();root=Path(__file__).parent;r=root/'corrected';r.mkdir()
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for name in ['catalog.json','before.json','summarize.py']:
    shutil.copyfile(root/name,r/name)
for role in ['before','candidate']:
    shutil.copytree(root/'images/before',r/'images'/role)
shutil.copyfile(repo/'src/Lokad.Lython/bin/Release/net11.0/Lokad.Lython.dll',r/'images/candidate/Lokad.Lython.dll')
for framework in ['net11.0','net10.0']:
    p=r/'cores'/framework;p.mkdir(parents=True)
    shutil.copyfile(repo/f'src/Lokad.Lython/bin/Release/{framework}/Lokad.Lython.dll',p/'Lokad.Lython.dll')
images={role:{p.name:sha(p)for p in(r/'images'/role).iterdir()if p.is_file()}for role in ['before','candidate']}
assert [n for n in images['before']if images['before'][n]!=images['candidate'][n]]==['Lokad.Lython.dll']
paths=subprocess.check_output(['git','ls-files','src/Lokad.Lython'],text=True).splitlines()
data=json.loads((root/'diagnostic-identity.json').read_text(encoding='utf-8'))
data.update(images=images,measuredSource={p:sha(repo/p) if b'\r\n'not in(repo/p).read_bytes()else hashlib.sha256((repo/p).read_bytes().replace(b'\r\n',b'\n')).hexdigest()for p in paths if p.endswith('.cs')},
    qualification='Corrected600internal/2653public focused checks pass per actual.NET11/.NET10. Four independently verified custom-casing regressions pass; pre-change frozen baseline fails one, initial prototype fails all four. No platform/package claim yet.',
    refinement='Fusion reads the final call consumer after native-chain validation; intermediate calls retain their actual result use. Original source/images/all desktop adversity preserved separately. Fresh same-source rerun is justified by this semantic correction, not unchanged retiming.')
(r/'diagnostic-identity.json').write_text(json.dumps(data,indent=2)+'\n',encoding='utf-8')
(r/'measured-source.patch').write_bytes(subprocess.check_output(['git','diff','--','src']))
s=(root/'measure.py').read_text(encoding='utf-8').replace("r/'tool/bin/Release/net11.0/complete-jobs.dll'", "r.parent/'tool/bin/Release/net11.0/complete-jobs.dll'")
(r/'measure.py').write_text(s,encoding='utf-8')
for phase in ['warm-sync','warm-async','compile']:
    p=r/phase;p.mkdir()
    shutil.copyfile(root/phase/'hash-witness.json',p/'hash-witness.json')
print(json.dumps(dict(correctedCoreSHA256={f:sha(r/'cores'/f/'Lokad.Lython.dll')for f in ['net11.0','net10.0']},initialVariantRetained=True,sourceCount=len(data['measuredSource']))))
