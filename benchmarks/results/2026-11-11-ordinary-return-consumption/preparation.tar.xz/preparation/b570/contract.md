# R225 — bounded whole-script confirmation

Two existing complete text scripts, changed captured-helper/counter and unchanged
ordinary control; identical source/fixtures/full output checks across both engines.
Fresh forced f6c8 reference versus corrected9ee7 prototype, fixedfec79 worker/host/
normal0.4 adapter. Four independent source/control processes,5swarmup/7rotated400ms
rounds, ordinaryGC/tiering; warm sync only. Desktop async/compilation/allocation and
all original/refined adverse observations stay separate.120sowner/30stop/30margin.
Full mediated RAM I/O/per-invocation checks/prior-result cleanup included; compile/
reset/separate verification/protocol/startup/final caches excluded. WiderCPU includes
surrounding work/coarse ticks. No expected speedup, fixed percentage veto, current
CPython ratio or package/producer claim. Retain/refine/withdraw with control debt
explicit; preserve the independent custom-casing correctness fix if withdrawn.
