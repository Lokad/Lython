from pathlib import Path
import ast,fcntl,hashlib,io,json,os,shutil,stat,subprocess,sys,tarfile
config={'payloadBytes': 3772538, 'payloadSHA256': '55e5263662a230c055526141ccc1965b2ef5d934569208ac800896a9c47b50c3', 'required': 275849216, 'coresToRetire': [], 'expectedCores': {'reference': 'f6c8fd22df7341c8a4959e791fd288aacd7d3e8770cb38fec83cc8e9efddb61e', 'reference-control': 'f6c8fd22df7341c8a4959e791fd288aacd7d3e8770cb38fec83cc8e9efddb61e', 'candidate': '9ee7e700580399ff80d803f0a7535d2de5ff0f10d35a736370f457383be1b67f', 'candidate-control': '9ee7e700580399ff80d803f0a7535d2de5ff0f10d35a736370f457383be1b67f'}, 'exactCopies': [{'path': 'captured-text-b569-20261111/observations.tgz', 'canonical': 'benchmarks/results/2026-11-11-captured-helper-cost/observations.tgz', 'bytes': 2108316, 'sha256': '027640410044aabeaa0e94a1db5c2f258fd24df234b0750758a3cc2c1eb43097'}, {'path': 'completed-json-b461-20261108/observations.tgz', 'canonical': 'benchmarks/results/2026-11-08-unified-json-encoding/observations.tar.xz', 'bytes': 3898957, 'sha256': '298dbc75d22589d653f61758411c725de414df7d544f086e5347f27304e72975', 'canonicalMember': 'b461/observations.tgz'}, {'path': 'default-rsplit-b459-20261108/observations.tgz', 'canonical': 'benchmarks/results/2026-11-08-default-rsplit-preparation/observations.tar.xz', 'bytes': 3886953, 'sha256': 'e29426df82c56de14f7f35214a96a466440aed9ecb1d1cb346fe8725b530007e', 'canonicalMember': 'b459/observations.tgz'}, {'path': 'refined-conditional-helpers-b465-20261108/observations.tgz', 'canonical': 'benchmarks/results/2026-11-08-native-conditional-helpers-final/observations.tar.xz', 'bytes': 3888358, 'sha256': '8f596064ea9405cf44f345197a5e67b5b71d4a414c7d59b748079a2a23b32497', 'canonicalMember': 'b465/observations.tgz'}, {'path': 'conditional-helpers-b464-20261108/observations.tgz', 'canonical': 'benchmarks/results/2026-11-08-native-conditional-helpers/observations.tar.xz', 'bytes': 3889736, 'sha256': 'b5a032305febde922ef9b85edceba9d67ceb00ba84fd3dac866e072fa40e7399', 'canonicalMember': 'b464/observations.tgz'}]}
base=Path('/home/lokad/lython-bench-checks').resolve();root=base/'iteration-returns-b570-20261111';source=base/'json-cpython-b566-20261111/candidate';fixture=root/'guest-fixtures'
with(base/'comparison-vm.lock').open('a')as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert not root.exists()and not list(Path('/dev/shm').glob('lython-comparison-files-*'))
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record|[c]omplete-jobs.dll|[p]ython3.*cpython-worker.py'],capture_output=True).returncode==1
 payload=sys.stdin.buffer.read(config['payloadBytes']+1);assert len(payload)==config['payloadBytes']and hashlib.sha256(payload).hexdigest()==config['payloadSHA256']
 with tarfile.open(fileobj=io.BytesIO(payload),mode='r:gz')as a:
  for name,role in [('baseline-core.dll','reference'),('current-core.dll','candidate')]:
   assert hashlib.sha256(a.extractfile(name).read()).hexdigest()==config['expectedCores'][role]
 assert hashlib.sha256((source/'Lokad.Lython.dll').read_bytes()).hexdigest()=='9dadd59bd75528186c66a9a95e2efcf411e611e0ccaa718ff38c4facdb191e33'
 stable=source/'Lokad.Lython.dll'
 assert hashlib.sha256(stable.read_bytes()).hexdigest()=='9dadd59bd75528186c66a9a95e2efcf411e611e0ccaa718ff38c4facdb191e33'
 protected=base/'json-string-b565-20261111/reference/Lokad.Lython.dll'
 assert hashlib.sha256(protected.read_bytes()).hexdigest()=='c27160d53d66489976b181fb425b2f46c927fa85156433b80dc6f5477a3e5506'
 protocol=base/'prepared-call-layout-b384-20261107/cpython-worker.py'
 assert hashlib.sha256(protocol.read_bytes()).hexdigest()=='02ca606af6b937a5bec8da744da36e6dbea45ef14ee7207732f34da052ad32f1'
 before=shutil.disk_usage(base).free;retired=[];reclaim=0
 if before<=config['required']:
  for proof in config['coresToRetire']:
   firstPath=base/proof['knownPath'];first=firstPath.lstat();key=(first.st_dev,first.st_ino)
   assert first.st_size==proof['bytes']and hashlib.sha256(firstPath.read_bytes()).hexdigest()==proof['sha256']
   aliases=[]
   for folder,dirs,files in os.walk(base):
    for name in files:
     path=Path(folder)/name;st=path.lstat()
     if(st.st_dev,st.st_ino)!=key:continue
     assert path.resolve(strict=True).is_relative_to(base)and stat.S_ISREG(st.st_mode)and st.st_uid==os.getuid()
     aliases.append(path.relative_to(base).as_posix())
   assert len(aliases)==first.st_nlink and aliases and proof['knownPath']in aliases
   assert proof['sha256']not in[config['expectedCores']['reference'],'9dadd59bd75528186c66a9a95e2efcf411e611e0ccaa718ff38c4facdb191e33']
   reclaim+=first.st_blocks*512;retired.append(dict(proof,paths=aliases,allocatedBytes=first.st_blocks*512,allHardlinkAliasesVerified=True))
  for exact in config['exactCopies']:
   path=base/exact['path'];st=path.lstat()
   assert path.resolve(strict=True).is_relative_to(base)and stat.S_ISREG(st.st_mode)and st.st_uid==os.getuid()and st.st_nlink==1
   assert st.st_size==exact['bytes']and hashlib.sha256(path.read_bytes()).hexdigest()==exact['sha256']
   reclaim+=st.st_blocks*512;retired.append(dict(exact,paths=[exact['path']],allocatedBytes=st.st_blocks*512,allHardlinkAliasesVerified=True))
  assert before+reclaim>config['required'],(before,reclaim,config['required'])
  for proof in retired:
   for path in proof['paths']:(base/path).unlink()
 assert hashlib.sha256(stable.read_bytes()).hexdigest()=='9dadd59bd75528186c66a9a95e2efcf411e611e0ccaa718ff38c4facdb191e33'
 assert hashlib.sha256((source/'Lokad.Lython.dll').read_bytes()).hexdigest()=='9dadd59bd75528186c66a9a95e2efcf411e611e0ccaa718ff38c4facdb191e33'
 assert hashlib.sha256(protected.read_bytes()).hexdigest()=='c27160d53d66489976b181fb425b2f46c927fa85156433b80dc6f5477a3e5506'
 assert shutil.disk_usage(base).free>config['required']
 beforeExtractionFreeBytes=shutil.disk_usage(base).free
 with tarfile.open(fileobj=io.BytesIO(payload),mode='r:gz')as a:root.mkdir();a.extractall(root,filter='data')
 recovery=dict(beforeFreeBytes=before,afterRecoveryFreeBytes=beforeExtractionFreeBytes,postExtractionFreeBytes=shutil.disk_usage(base).free,requiredFreeBytes=config['required'],freshIdleLease=True,verifiedReplacementInPayload=True,files=retired,osFloorMiB=240,evidenceHeadroomMiB=12,fullyQualifiedE122AndB8Preserved=True)
 (root/'space-recovery.json').write_text(json.dumps(recovery,indent=2)+'\n')
 shutil.copyfile(protocol,root/'cpython-worker.py')
 for role in ['reference','candidate']:
  shutil.copytree(source,root/role,copy_function=os.link)
  (root/role/'Lokad.Lython.dll').unlink();os.link(root/('baseline-core.dll'if role=='reference'else'current-core.dll'),root/role/'Lokad.Lython.dll')
 identity=json.loads((root/'identity.json').read_text())
 for role in ['reference','candidate']:
  for name,digest in{**identity['auxiliaryFiles'],'Lokad.Lython.dll':identity['coreSHA256'][role]}.items():assert hashlib.sha256((root/role/name).read_bytes()).hexdigest()==digest,(role,name)
 assert hashlib.sha256((root/'representative.json').read_bytes()).hexdigest()==identity['catalogSHA256']
 for name in ['collect.py','archive-owned.py']:ast.parse((root/name).read_text())
 subprocess.run(['/bin/sh','-n',str(root/'run.sh')],check=True)
 fixture.mkdir();subprocess.run(['sudo','-n','mount','-t','tmpfs','-o','size=128m,mode=0700,uid=lokad,gid=lokad','lython-b570-fixtures',str(fixture)],check=True)
 setup=dict(freeBytes=shutil.disk_usage(base).free,imagesVerified=True,jobs=2,ownerSeconds=120,stopSeconds=30,marginSeconds=30,osFloorMiB=240,evidenceHeadroomMiB=12)
 assert setup['freeBytes']>252*1024*1024
 (root/'setup.json').write_text(json.dumps(setup,indent=2)+'\n');print(json.dumps(setup),flush=True)
try:
 subprocess.run(['sudo','-n','systemd-run','--unit=lython-b570-iteration-returns-20261111','--property=User=lokad','--property=WorkingDirectory='+str(root),'--property=RuntimeMaxSec=120','--property=TimeoutStopSec=30','--property=KillMode=control-group','/bin/sh',str(root/'run.sh')],check=True)
except BaseException:
 subprocess.run(['sudo','-n','umount',str(fixture)],check=True);fixture.rmdir();raise
live=subprocess.check_output(['systemctl','show','lython-b570-iteration-returns-20261111.service','--property=ActiveState,MainPID,RuntimeMaxUSec'],text=True)
assert'ActiveState=active'in live and'MainPID=0'not in live;print(live,flush=True)
