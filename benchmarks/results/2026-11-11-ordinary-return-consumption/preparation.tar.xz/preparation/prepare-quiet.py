from pathlib import Path
import ast,hashlib,io,json,subprocess,tarfile

repo=Path.cwd();r=Path(__file__).parent;out=r/'b570';out.mkdir()
old=r.parent/'incoming-lexical-stores-r221/b567'
write=lambda p,s:p.write_text(s,encoding='utf-8',newline='\n')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
ids=['scripts.text-summary-helpers.nonlocal-counter.large','scripts.text-summary-helpers.large']
catalog=json.loads((r/'catalog.json').read_text(encoding='utf-8'))
catalog['cases']=[next(c for c in catalog['cases']if c['id']==name)for name in ids]
write(out/'representative.json',json.dumps(catalog,ensure_ascii=False,indent=2)+'\n')
before=r/'baseline/net11.0/Lokad.Lython.dll';candidate=r/'corrected/cores/net11.0/Lokad.Lython.dll'
aux=json.loads((old/'identity.json').read_text(encoding='utf-8'))['auxiliaryFiles']
identity=dict(sourceRevision='R225 fresh forced ba6ea8b4/f6c8fd22 reference versus exact corrected ordinary-return-consumption9ee7e700 prototype.600internal/2653public eachactualtarget pass. Includes custom-casing intermediate-result correction; baseline separately fails one new regression, first prototype fails four. Original/refined desktop adversity retained; no full source delivery yet.',
    coreSHA256={role:sha(before if role.startswith('reference')else candidate)for role in ['reference','reference-control','candidate','candidate-control']},
    auxiliaryFiles=aux,catalogSHA256=sha(out/'representative.json'),performanceQualified=False)
write(out/'identity.json',json.dumps(identity,indent=2)+'\n')
for name in ['collect.py','archive-owned.py','run.sh','retrieve.py','summarize.py']:
    s=(old/name).read_text(encoding='utf-8').replace('lexical-stores-b567-20261111','iteration-returns-b570-20261111').replace('lython-b567-lexical-stores-20261111','lython-b570-iteration-returns-20261111')
    s=s.replace('len(jobs)==4','len(jobs)==2').replace("len(raw['jobs'])==4","len(raw['jobs'])==2").replace('jobs=4','jobs=2').replace("['jobs']==4","['jobs']==2").replace("['elapsedSeconds']<180","['elapsedSeconds']<120")
    s=s.replace('[d]otnet.* --compare worker|[p]erf record', '[d]otnet.* --compare worker|[p]erf record|[p]ython3.*cpython-worker.py')
    if name=='collect.py':
        lines=s.splitlines();i=next(i for i,line in enumerate(lines)if line.startswith('jobs='));lines[i]='jobs='+repr([[name,'warm']for name in ids]);s='\n'.join(lines)+'\n'
        s=s.replace('time.monotonic()-started < 140','time.monotonic()-started < 80')
        a=s.index("purpose='");b=s.index("',\n",a)
        s=s[:a]+"purpose='R225 complete captured-helper-counter text versus unchanged ordinary text. Corrected ordinary direct-return private-consumption forwarding removes per-record list/reference-array/range construction. Exact f6c8 forced reference and9ee7 corrected prototype, fixed worker/normal0.4 adapter. Allocation and every original desktop adversity remain separate; no CPython ratio or universal CPU claim"+s[b:]
    if name.endswith('.py'):ast.parse(s)
    write(out/name,s)
write(out/'contract.md','''# R225 — bounded whole-script confirmation

Two existing complete text scripts, changed captured-helper/counter and unchanged
ordinary control; identical source/fixtures/full output checks across both engines.
Fresh forced f6c8 reference versus corrected9ee7 prototype, fixedfec79 worker/host/
normal0.4 adapter. Four independent source/control processes,5swarmup/7rotated400ms
rounds, ordinaryGC/tiering; warm sync only. Desktop async/compilation/allocation and
all original/refined adverse observations stay separate.120sowner/30stop/30margin.
Full mediated RAM I/O/per-invocation checks/prior-result cleanup included; compile/
reset/separate verification/protocol/startup/final caches excluded. WiderCPU includes
surrounding work/coarse ticks. No expected speedup, fixed percentage veto, current
CPython ratio or package/producer claim. Retain/refine/withdraw with control debt
explicit; preserve the independent custom-casing correctness fix if withdrawn.
''')
exact=[]
mapping=[('captured-text-b569-20261111/observations.tgz','2026-11-11-captured-helper-cost','observations.tgz',None),
 ('completed-json-b461-20261108/observations.tgz','2026-11-08-unified-json-encoding','observations.tar.xz','b461/observations.tgz'),
 ('default-rsplit-b459-20261108/observations.tgz','2026-11-08-default-rsplit-preparation','observations.tar.xz','b459/observations.tgz'),
 ('refined-conditional-helpers-b465-20261108/observations.tgz','2026-11-08-native-conditional-helpers-final','observations.tar.xz','b465/observations.tgz'),
 ('conditional-helpers-b464-20261108/observations.tgz','2026-11-08-native-conditional-helpers','observations.tar.xz','b464/observations.tgz')]
for remote,folder,name,member in mapping:
    relative='benchmarks/results/'+folder+'/'+name;data=(repo/relative).read_bytes()
    assert data==subprocess.check_output(['git','show','HEAD:'+relative])
    if member:
        with tarfile.open(fileobj=io.BytesIO(data))as a:data=a.extractfile(member).read()
    proof=dict(path=remote,canonical=relative,bytes=len(data),sha256=hashlib.sha256(data).hexdigest())
    if member:proof['canonicalMember']=member
    exact.append(proof)
write(out/'exact-copies.json',json.dumps(exact,indent=2)+'\n');write(out/'superseded-cores.json','[]\n')
with tarfile.open(out/'payload.tgz','w:gz')as a:
    for name in ['representative.json','identity.json','collect.py','archive-owned.py','run.sh','contract.md']:a.add(out/name,arcname=name)
    a.add(before,arcname='baseline-core.dll');a.add(candidate,arcname='current-core.dll')
with tarfile.open(out/'payload.tgz')as a:footprint=sum(((m.size+4095)//4096)*4096 for m in a.getmembers()if m.isfile())+128*1024
size=(out/'payload.tgz').stat().st_size
write(out/'footprint.json',json.dumps(dict(payloadBytes=size,footprintBytes=footprint,requiredFreeBytes=252*1024*1024+max(footprint,3*size)),indent=2)+'\n')
s=(old/'launch.py').read_text(encoding='utf-8').replace('lexical-stores-b567-20261111','iteration-returns-b570-20261111').replace('lython-b567-lexical-stores-20261111','lython-b570-iteration-returns-20261111').replace('lexical-stores-b567-launch.py','iteration-returns-b570-launch.py').replace('lython-b567-fixtures','lython-b570-fixtures')
s=s.replace('jobs=4,ownerSeconds=180','jobs=2,ownerSeconds=120').replace('RuntimeMaxSec=180','RuntimeMaxSec=120').replace('ownerSeconds=180','ownerSeconds=120').replace('seconds=240','seconds=180')
ast.parse(s);write(out/'launch.py',s)
s=(r.parent/'text-cpython-r223/inventory.py').read_text(encoding='utf-8').replace("r / 'b568/exact-copies.json'","r / 'b570/exact-copies.json'")
write(r/'inventory.py',s)
print(json.dumps(dict(payloadBytes=size,requiredFreeBytes=252*1024*1024+max(footprint,3*size),canonicalDuplicatesBytes=sum(p['bytes']for p in exact))))
