from pathlib import Path
import hashlib,json,os,subprocess

r=Path(__file__).resolve().parent
dotnet=Path('C:/Users/JoannesVermorel/.dotnet11/dotnet.exe')
env=os.environ.copy();env['DOTNET_ROOT']=str(dotnet.parent)
env['PATH']=str(dotnet.parent)+os.pathsep+env['PATH']
ids=json.loads((r/'diagnostic-identity.json').read_text(encoding='utf-8'))
for role in ['before','candidate']:
    for name,h in ids['images'][role].items():
        assert hashlib.sha256((r/'images'/role/name).read_bytes()).hexdigest()==h,(role,name)
for phase in ['warm-sync','warm-async','compile']:
    folder=r/phase
    assert not (folder/'measurements.json').exists()
    command=[str(dotnet),str(r/'tool/bin/Release/net11.0/complete-jobs.dll'),
        str(r/'images/before/Lokad.Lython.Benchmarks.dll'),str(r/'images/candidate/Lokad.Lython.Benchmarks.dll'),str(r/'catalog.json'),str(folder/'hash-witness.json'),
        'forward','compile' if phase=='compile' else 'warm','async' if phase=='warm-async' else 'sync']
    with (folder/'measurements.json').open('wb')as stdout,(folder/'stderr.log').open('wb')as stderr:
        done=subprocess.run(command,stdout=stdout,stderr=stderr,env=env)
    assert done.returncode==0,(phase,done.returncode,(folder/'stderr.log').read_text(encoding='utf-8'))
    data=json.loads((folder/'measurements.json').read_text(encoding='utf-8-sig'))
    assert data['allGoldensPassed'] and data['allBalancesZero'] and data['ownedFixturesRemoved']
    print(phase+' completed; all goldens, ownership balances and fixture cleanup pass.',flush=True)
subprocess.run(['C:/Python313/python.exe','-X','utf8',str(r/'summarize.py')],check=True)
