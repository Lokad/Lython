from pathlib import Path
import json,subprocess,sys

records=[]
for forwarding in [False,True]:
    for captured in [False,True]:
        source="def outer():\n count=0\n class Text:\n  def lower(self):\n"+("   nonlocal count\n   count+=1\n"if captured else "")+"   return ' A B '.lower().split()\n def words(value):\n  nonlocal count\n  count+=1\n  return value.lower().split()\n try:\n  for word in "+("words(Text())"if forwarding else"Text().lower().split()")+":pass\n except AttributeError as error:print(\"'list'\" in str(error),\"'split'\" in str(error))\nouter()"
        result=subprocess.run([sys.executable,'-X','utf8','-I','-c',source],capture_output=True,text=True,encoding='utf-8',check=True)
        assert result.stdout=='True True\n'and not result.stderr
        records.append(dict(forwarding=forwarding,captured=captured,source=source,expected=result.stdout))
(Path(__file__).parent/'intermediate-goldens.json').write_text(json.dumps(dict(reference=sys.version,cases=records),indent=2)+'\n',encoding='utf-8')
print('All four independent CPython custom-casing result goldens pass.')
