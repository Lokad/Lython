from pathlib import Path

repo=Path.cwd();r=Path(__file__).parent;p=repo/'PLAN.md';s=p.read_text(encoding='utf-8')
(r/'plan-before-implementation.md').write_text(s,encoding='utf-8')
s=s.replace('- **Next R225:** ordinary direct-return consumption forwarding; concrete construction\n  phase selected below. No active VM workers or production prototype.',
'''- **Active R225 prototype:** existing call/work/frame state forwards immediate
  iteration intent across direct returns; guest-local stores keep actual lists.
  600internal/2649public focused checks pass per actual target, including independent
  CPython goldens, real I/O, cancellation with held cleanup, refusal and budget reuse.
  Fresh forced ba6baseline and exact candidate are frozen. Six complete-job desktop
  diagnostics are next; no quiet collection or retention decision yet.''')
s=s.replace('**R225 next coherent migration — ordinary direct-return consumption:**', '**R225 active coherent migration — ordinary direct-return consumption:**')
s=s.replace('Freeze current committed source before edits. One existing complete-job before/after:',
'''Frozen pre-edit sourceba6ea8b4, forced fresh Release solution/both targets; baseline
f6c8fd22(net11)/cbaa27dc(net10), all568source hashes. Candidate adds two booleans in
existing immutable call metadata/work state and reuses the current interpreter;
native proofs/backends unchanged. Generic ordinary/frame/native return entry uses
one consumption rule. No public option or new memory owner. Initial internal test
build caught the changed signature; direct white-box caller updated, no shim.
Focused checks600internal/2649public per actual target pass. Seven independent
CPython scenarios, Unicode cases, pending I/O and held-cleanup cancellation added.

One existing complete-job before/after:''')
p.write_text(s,encoding='utf-8')
print('PLAN records active exact-source R225 implementation and focused qualification.')
