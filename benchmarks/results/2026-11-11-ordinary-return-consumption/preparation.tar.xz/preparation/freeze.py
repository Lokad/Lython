from pathlib import Path
import hashlib,json,shutil,subprocess

repo=Path.cwd();r=Path(__file__).parent
assert subprocess.run(['git','diff','--quiet','--','src'],check=False).returncode==0
revision=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
paths=subprocess.check_output(['git','ls-files','src/Lokad.Lython'],text=True).splitlines()
source={p:hashlib.sha256((repo/p).read_bytes().replace(b'\r\n',b'\n')).hexdigest()for p in paths if p.endswith('.cs')}
assert len(source)==568
core={}
for framework in ['net11.0','net10.0']:
    out=r/'baseline'/framework;out.mkdir(parents=True)
    f=repo/f'src/Lokad.Lython/bin/Release/{framework}/Lokad.Lython.dll'
    shutil.copyfile(f,out/f.name);core[framework]=hashlib.sha256(f.read_bytes()).hexdigest()
out=r/'images/before';out.mkdir(parents=True)
for f in (repo/'benchmarks/Lokad.Lython.Benchmarks/bin/Release/net11.0').iterdir():
    if f.is_file():shutil.copyfile(f,out/f.name)
assert hashlib.sha256((out/'Lokad.Lython.dll').read_bytes()).hexdigest()==core['net11.0']
(r/'before.json').write_text(json.dumps(dict(revision=revision,normalizedSource=source,coreSHA256=core,build='Fresh forced nonincremental Release solution, both targets, zero warnings/errors.',qualification='Production includes focused-qualifiedR222 on top of fully qualifiedR221. No full current-source claim.'),indent=2)+'\n',encoding='utf-8')
print(json.dumps(dict(revision=revision,coreSHA256=core,sourceCount=len(source))))
