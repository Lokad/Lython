from pathlib import Path
import json

r=Path(__file__).parent;p=r/'warm-sync';out=r/'initial-core-entry-failure';out.mkdir()
for name in ['measurements.json','stderr.log']:(p/name).rename(out/name)
f=r/'setup-corrections.json';d=json.loads(f.read_text(encoding='utf-8'))
d['diagnosticSecondStartup']='Core assembly path loaded successfully but does not define benchmark fixtures. Existing Image constructor requires the benchmark worker DLL entry point; it loads the neighboring core itself. TypeLoadException before fixture creation/warmup; original stdout/stderr preserved.'
d['correction']='Use the exact existing benchmark worker files in the already-frozen image directories. Both images have equal worker/auxiliary hashes and differ only in core. No source/image/settings/threshold change, no timing discarded.'
f.write_text(json.dumps(d,indent=2)+'\n',encoding='utf-8')
print('Preserved second startup failure; existing driver now receives its benchmark entry assembly.')
