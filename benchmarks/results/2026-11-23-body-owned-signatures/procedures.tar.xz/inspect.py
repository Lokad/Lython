from pathlib import Path
import hashlib,json,os,shutil,subprocess
lab=Path(__file__).resolve().parent
repo=lab.parents[3]
comparison=lab/"comparison"
inspection=lab.parent/"demanded-jump-targets-20261122"
earlier_suite=lab.parent/"syntax-binding-presence-20261123"
out=lab/"inspection"
out.mkdir()
def read(p): return json.loads(p.read_text(encoding="utf-8-sig"))
def sha(data): return hashlib.sha256(data).hexdigest()
def digest(p): return sha(p.read_bytes())
def hashes(p): return {v.name:digest(v) for v in sorted(p.iterdir()) if v.is_file()}
def save(p,v): p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+"\n",encoding="utf-8",newline="\n")
core="Lokad.Lython.dll"
known=read(comparison/"identity.json")["imageFiles"]
catalog=read(earlier_suite/"comparison/inspection-catalog.json")
sources=read(comparison/"representative.json")
cases={row["id"]:row for row in catalog["cases"]}
for row in sources["cases"]: cases.setdefault(row["id"],row)
input_file=out/"tapes.json"
save(input_file,{**catalog,"cases":list(cases.values())})
probe=inspection/"reference/inspect"
manifest=read(inspection/"inspection-identity.json")["workerImages"]["reference"]["inspect"]
assert manifest==hashes(probe)
sdk=Path.home()/".dotnet11"
dotnet=sdk/"dotnet.exe"
env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk),PATH=str(sdk)+os.pathsep+os.environ["PATH"])
compiler=lab.parent/"direct-suite-bindings-20261123/comparison/frozen-reference"
rows={}
for role in ("reference","candidate"):
    frozen=comparison/f"frozen-{role}"
    assert {n:digest(frozen/n) for n in known[role]}==known[role]
    p=out/role
    shutil.copytree(probe,p)
    shutil.copyfile(frozen/core,p/core)
    assert hashes(p)=={**manifest,core:known[role][core]}
    receipt=out/f"{role}-tape.json"
    subprocess.run([dotnet,p/"Inspect.dll",input_file,receipt],env=env,check=True,timeout=45)
    state=read(receipt)
    assert state["coreSHA256"]==known[role][core]
    rows[role]=state["rows"]
    for suffix in (".dll",".deps.json",".runtimeconfig.json"):
        n="CompileAllocation"+suffix
        shutil.copyfile(compiler/n,frozen/n)
    with (out/f"{role}-compile-allocation.json").open("wb") as sink:
        subprocess.run([dotnet,frozen/"CompileAllocation.dll",comparison/"representative.json"],env=env,check=True,timeout=90,stdout=sink)
assert rows["reference"]==rows["candidate"] and len(rows["reference"])==len(cases)
print(len(cases),"identical executable tape fixtures")
for role in ("reference","candidate"):
    result=read(out/f"{role}-compile-allocation.json")
    assert result["coreSha256"]==known[role][core]
    print(role,[(x["id"],x.get("allocatedBytesPerInvocation",x.get("allocatedBytes"))) for x in result["rows"]])
