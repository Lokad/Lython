; Assembly listing for method Lokad.Lython.Runtime.PyExecutableFunction:StartNativeCall(Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,bool,bool,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,byref,byref):this (FullOpts)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; FullOpts code
; optimized code
; rbp based frame
; partially interruptible
; No PGO data
; 1 inlinees with PGO data; 28 single block inlinees; 7 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       push     r15
       push     r14
       push     r13
       push     r12
       push     rdi
       push     rsi
       push     rbx
       sub      rsp, 520
       lea      rbp, [rsp+0x240]
       xor      eax, eax
       mov      qword ptr [rbp-0x1D8], rax
       vxorps   xmm4, xmm4, xmm4
       vmovdqa  xmmword ptr [rbp-0x1D0], xmm4
       mov      rax, -384
 
G_M000_IG24:                ;; offset=0x003A
       vmovdqa  xmmword ptr [rbp+rax-0x40], xmm4
       vmovdqa  xmmword ptr [rbp+rax-0x30], xmm4
       vmovdqa  xmmword ptr [rbp+rax-0x20], xmm4
       add      rax, 48
       jne      SHORT G_M000_IG24
       mov      qword ptr [rbp-0x40], rax
       mov      rbx, rcx
       mov      rdi, rdx
       mov      rsi, r9
       mov      r14, gword ptr [rbp+0x38]
       mov      r15, bword ptr [rbp+0x60]
 
G_M000_IG02:                ;; offset=0x0067
       mov      r13, bword ptr [r8]
       mov      r12d, dword ptr [r8+0x08]
       test     rsi, rsi
       jne      G_M000_IG09
 
G_M000_IG03:                ;; offset=0x0077
       mov      rdx, gword ptr [rbx+0x38]
       cmp      byte  ptr [rdx+0xE7], 0
       je       G_M000_IG09
       cmp      byte  ptr [rbp+0x48], 0
       je       SHORT G_M000_IG05
       cmp      r12d, dword ptr [rdx+0xCC]
       jne      G_M000_IG09
       mov      bword ptr [rbp-0x1A8], r13
       mov      dword ptr [rbp-0x1A0], r12d
       lea      rdx, [rbp-0x1A8]
       mov      rcx, rbx
       mov      r8, r14
       mov      r9, r15
       call     [Lokad.Lython.Runtime.PyExecutableFunction:TryStartDirectIntegerReturn[Lokad.Lython.Runtime.LythonRuntime+SlotIntegerOperands](Lokad.Lython.Runtime.LythonRuntime+SlotIntegerOperands,Lokad.Lython.LythonSourceSpan,byref):bool:this]
       test     eax, eax
       je       G_M000_IG09
 
G_M000_IG04:                ;; offset=0x00C7
       mov      rsi, bword ptr [rbp+0x58]
       mov      byte  ptr [rsi], 0
       xor      rax, rax
       mov      rdi, bword ptr [rbp+0x68]
       mov      gword ptr [rdi], rax
       jmp      G_M000_IG13
 
G_M000_IG05:                ;; offset=0x00DC
       xor      ecx, ecx
       mov      qword ptr [r15], rcx
       mov      qword ptr [r15+0x08], rcx
       mov      rcx, gword ptr [rbx+0x38]
       mov      r10, gword ptr [rcx+0xB0]
       mov      gword ptr [rbp-0x1E0], r10
       cmp      byte  ptr [rdi+0x34], 0
       je       G_M000_IG07
       mov      rdx, gword ptr [r10+0x08]
       mov      edx, dword ptr [rdx+0x08]
       cmp      edx, dword ptr [rcx+0xCC]
       jne      G_M000_IG07
       mov      rcx, rbx
       mov      rdx, r10
       mov      r8d, r12d
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:HasPreparedOmittedArguments(Lokad.Lython.Frontend.FunctionParameterLayout,int):bool:this]
       test     eax, eax
       je       SHORT G_M000_IG07
       mov      rax, gword ptr [rbp+0x30]
       mov      rdx, gword ptr [rax+0x98]
       mov      gword ptr [rbp-0x1E8], rdx
       cmp      byte  ptr [rdx], dl
       mov      rcx, rdx
       call     [Lokad.Lython.Runtime.ExecutionState:get_CanContinue():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG06
       mov      rcx, gword ptr [rbp-0x1E8]
       mov      rdx, r14
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
 
G_M000_IG06:                ;; offset=0x0158
       mov      gword ptr [rbp-0x190], rbx
       mov      rdx, gword ptr [rbp-0x1E0]
       mov      gword ptr [rbp-0x188], rdx
       mov      bword ptr [rbp-0x180], r13
       mov      dword ptr [rbp-0x178], r12d
       lea      rdx, [rbp-0x190]
       mov      rcx, rbx
       mov      r8, r14
       mov      r9, r15
       call     [Lokad.Lython.Runtime.PyExecutableFunction:TryStartDirectIntegerReturn[Lokad.Lython.Runtime.LythonRuntime+DefaultIntegerOperands](Lokad.Lython.Runtime.LythonRuntime+DefaultIntegerOperands,Lokad.Lython.LythonSourceSpan,byref):bool:this]
       mov      ecx, eax
       jmp      SHORT G_M000_IG08
 
G_M000_IG07:                ;; offset=0x0195
       xor      ecx, ecx
 
G_M000_IG08:                ;; offset=0x0197
       test     ecx, ecx
       jne      G_M000_IG04
 
G_M000_IG09:                ;; offset=0x019F
       vxorps   ymm0, ymm0, ymm0
       vmovdqu  ymmword ptr [rbp-0x138], ymm0
       vmovdqu  ymmword ptr [rbp-0x118], ymm0
       vmovdqu  ymmword ptr [rbp-0xF8], ymm0
       vmovdqu  ymmword ptr [rbp-0xD8], ymm0
       vmovdqu  ymmword ptr [rbp-0xB8], ymm0
       vmovdqu  ymmword ptr [rbp-0x98], ymm0
       vmovdqu  ymmword ptr [rbp-0x78], ymm0
       vmovdqu  ymmword ptr [rbp-0x58], ymm0
       mov      rcx, gword ptr [rbx+0x38]
       mov      r10d, dword ptr [rcx+0xDC]
       mov      dword ptr [rbp-0x194], r10d
       cmp      r10d, 16
       ja       G_M000_IG19
       cmp      byte  ptr [rbp+0x48], 0
       jne      G_M000_IG15
       mov      rcx, gword ptr [rcx+0xB0]
       mov      rdx, gword ptr [rcx+0x08]
       mov      edx, dword ptr [rdx+0x08]
       cmp      edx, r10d
       ja       G_M000_IG19
       lea      r9, bword ptr [rbp-0x138]
       mov      bword ptr [rbp-0x1B8], r9
       mov      dword ptr [rbp-0x1B0], edx
       xor      rdx, rdx
       mov      bword ptr [rbp-0x1C8], rdx
 
G_M000_IG10:                ;; offset=0x0237
       mov      dword ptr [rbp-0x1C0], edx
       mov      gword ptr [rsp+0x20], rcx
       mov      rcx, gword ptr [rbp+0x30]
       mov      gword ptr [rsp+0x28], rcx
 
G_M000_IG11:                ;; offset=0x024B
       mov      dword ptr [rsp+0x30], edx
       mov      gword ptr [rsp+0x38], rsi
       mov      gword ptr [rsp+0x40], rdi
       mov      bword ptr [rbp-0x1D8], r13
       mov      dword ptr [rbp-0x1D0], r12d
       lea      rcx, [rbp-0x1B8]
       lea      rdx, [rbp-0x1C8]
       lea      r9, [rbp-0x1D8]
       mov      qword ptr [rsp+0x48], r9
       mov      r9, rbx
       mov      r8, r14
       call     [Lokad.Lython.Runtime.LythonRuntime:BindFunctionArgumentsInto(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.ReadOnlySpan`1[Lokad.Lython.Runtime.CallArgumentValue],Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.FunctionBindingPlan,Lokad.Lython.Frontend.FunctionParameterLayout,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,bool,System.Object,Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):int]
 
G_M000_IG12:                ;; offset=0x028D
       vxorps   ymm0, ymm0, ymm0
       vmovdqu  ymmword ptr [rbp-0x170], ymm0
       lea      rdx, bword ptr [rbp-0x138]
       mov      bword ptr [rbp-0x1B8], rdx
       mov      esi, dword ptr [rbp-0x194]
       mov      dword ptr [rbp-0x1B0], esi
       movzx    rdx, byte  ptr [rbp+0x40]
       mov      dword ptr [rsp+0x20], edx
       mov      rsi, bword ptr [rbp+0x50]
       mov      bword ptr [rsp+0x28], rsi
       mov      rsi, bword ptr [rbp+0x58]
       mov      bword ptr [rsp+0x30], rsi
       mov      bword ptr [rsp+0x38], r15
       mov      rdi, bword ptr [rbp+0x68]
       mov      bword ptr [rsp+0x40], rdi
       lea      rdx, [rbp-0x150]
       mov      qword ptr [rsp+0x48], rdx
       lea      rdx, [rbp-0x1B8]
       lea      r8, [rbp-0x170]
       mov      rcx, rbx
       mov      r9, r14
       call     [Lokad.Lython.Runtime.PyExecutableFunction:StartInline(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.Nullable`1[Lokad.Lython.Runtime.BoundFunctionArguments],Lokad.Lython.LythonSourceSpan,bool,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,byref,byref,byref):this]
 
G_M000_IG13:                ;; offset=0x0301
       nop      
 
G_M000_IG14:                ;; offset=0x0302
       add      rsp, 520
       pop      rbx
       pop      rsi
       pop      rdi
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG15:                ;; offset=0x0316
       xor      eax, eax
       test     rsi, rsi
       je       SHORT G_M000_IG16
       mov      eax, 1
       test     r10d, r10d
       je       G_M000_IG23
       mov      gword ptr [rbp-0x138], rsi
       xor      ecx, ecx
       mov      qword ptr [rbp-0x130], rcx
 
G_M000_IG16:                ;; offset=0x033B
       cmp      eax, r10d
       ja       SHORT G_M000_IG19
       lea      rcx, bword ptr [rbp-0x138]
       mov      edx, eax
       shl      rdx, 4
       add      rcx, rdx
       mov      edx, r10d
       sub      edx, eax
       cmp      r12d, edx
       ja       SHORT G_M000_IG22
 
G_M000_IG17:                ;; offset=0x035A
       mov      r8d, r12d
       shl      r8, 4
       cmp      r8, 0x4000
       ja       SHORT G_M000_IG21
 
G_M000_IG18:                ;; offset=0x036A
       mov      rdx, r13
       call     System.Buffer:BulkMoveWithWriteBarrierInternal(byref,byref,nuint)
       cmp      dword ptr [(reloc 0x7ffa37082aa8)], 0
       je       G_M000_IG12
       jmp      SHORT G_M000_IG20
 
G_M000_IG19:                ;; offset=0x0381
       call     [System.ThrowHelper:ThrowArgumentOutOfRangeException()]
       int3     
 
G_M000_IG20:                ;; offset=0x0388
       call     CORINFO_HELP_POLL_GC
       jmp      G_M000_IG12
 
G_M000_IG21:                ;; offset=0x0392
       mov      rdx, r13
       call     [System.Buffer:BulkMoveWithWriteBarrierBatch(byref,byref,nuint)]
       jmp      G_M000_IG12
 
G_M000_IG22:                ;; offset=0x03A0
       call     [System.ThrowHelper:ThrowArgumentException_DestinationTooShort()]
       int3     
 
G_M000_IG23:                ;; offset=0x03A7
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
; Total bytes of code 941

; Assembly listing for method Lokad.Lython.Runtime.LythonRuntime:BindFunctionArgumentsInto(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.ReadOnlySpan`1[Lokad.Lython.Runtime.CallArgumentValue],Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.FunctionBindingPlan,Lokad.Lython.Frontend.FunctionParameterLayout,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,bool,System.Object,Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):int (FullOpts)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; FullOpts code
; optimized code
; rbp based frame
; fully interruptible
; No PGO data
; 0 inlinees with PGO data; 30 single block inlinees; 5 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       push     r15
       push     r14
       push     r13
       push     r12
       push     rdi
       push     rsi
       push     rbx
       sub      rsp, 328
       lea      rbp, [rsp+0x180]
       vxorps   xmm4, xmm4, xmm4
       vmovdqu  ymmword ptr [rbp-0xC0], ymm4
       vmovdqu  ymmword ptr [rbp-0xA0], ymm4
       vmovdqu  ymmword ptr [rbp-0x80], ymm4
       vmovdqu  ymmword ptr [rbp-0x60], ymm4
       xor      eax, eax
       mov      qword ptr [rbp-0x40], rax
       mov      rsi, rdx
       mov      r14, r8
       mov      rdi, r9
       mov      rbx, gword ptr [rbp+0x30]
       mov      r9, gword ptr [rbp+0x38]
       mov      r15, gword ptr [rbp+0x48]
       mov      r13, gword ptr [rbp+0x50]
       mov      rdx, bword ptr [rbp+0x58]
 
G_M000_IG02:                ;; offset=0x005C
       mov      r12, bword ptr [rdx]
       mov      eax, dword ptr [rdx+0x08]
       mov      dword ptr [rbp-0x90], eax
       mov      r10, bword ptr [rcx]
       mov      bword ptr [rbp-0xF8], r10
       mov      r11d, dword ptr [rcx+0x08]
       mov      dword ptr [rbp-0x8C], r11d
 
G_M000_IG03:                ;; offset=0x007D
       xor      r8d, r8d
       cmp      dword ptr [rbx+0x4C], 0
       jge      G_M000_IG07
       test     r13, r13
       je       G_M000_IG06
       movzx    rcx, byte  ptr [r13+0x34]
       test     ecx, ecx
       je       SHORT G_M000_IG07
 
G_M000_IG04:                ;; offset=0x009C
       mov      ecx, dword ptr [rbx+0x3C]
       test     r15, r15
       setne    dl
       movzx    rdx, dl
       sub      ecx, edx
       cmp      ecx, eax
       jl       G_M000_IG38
       test     r15, r15
       je       SHORT G_M000_IG05
       mov      dword ptr [rbp-0x5C], 1
       test     r11d, r11d
       je       G_M000_IG41
       mov      rcx, r10
       mov      rdx, r15
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       xor      edx, edx
       mov      rax, bword ptr [rbp-0xF8]
       mov      qword ptr [rax+0x08], rdx
       mov      r8d, dword ptr [rbp-0x5C]
       mov      r9, gword ptr [rbp+0x38]
       mov      r10, bword ptr [rbp-0xF8]
       mov      r11d, dword ptr [rbp-0x8C]
 
G_M000_IG05:                ;; offset=0x00F5
       mov      eax, dword ptr [rbp-0x90]
       test     eax, eax
       je       G_M000_IG18
       xor      ecx, ecx
       mov      dword ptr [rbp-0xD4], eax
       jmp      G_M000_IG29
 
G_M000_IG06:                ;; offset=0x0110
       cmp      dword ptr [rsi+0x08], 0
       je       SHORT G_M000_IG04
 
G_M000_IG07:                ;; offset=0x0116
       mov      bword ptr [rbp-0xA0], r10
       mov      dword ptr [rbp-0x98], r11d
 
G_M000_IG08:                ;; offset=0x0124
       vmovdqu  xmm0, xmmword ptr [rsi]
       vmovdqu  xmmword ptr [rbp-0xB0], xmm0
 
G_M000_IG09:                ;; offset=0x0130
       mov      gword ptr [rsp+0x20], rbx
       mov      gword ptr [rsp+0x28], r9
       mov      gword ptr [rsp+0x30], r15
       mov      gword ptr [rsp+0x38], r13
       mov      bword ptr [rbp-0xC0], r12
       mov      dword ptr [rbp-0xB8], eax
       lea      rcx, [rbp-0x40]
       mov      qword ptr [rsp+0x48], rcx
       lea      rcx, [rbp-0x48]
       mov      qword ptr [rsp+0x50], rcx
       lea      rcx, [rbp-0x50]
       mov      qword ptr [rsp+0x58], rcx
       lea      rcx, [rbp-0x58]
       mov      qword ptr [rsp+0x60], rcx
       lea      rcx, [rbp-0xA0]
       lea      rdx, [rbp-0xB0]
       lea      r8, [rbp-0xC0]
       mov      qword ptr [rsp+0x40], r8
       mov      r9, rdi
       mov      r8, r14
       call     [Lokad.Lython.Runtime.LythonRuntime:BindSuppliedFunctionArguments(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.ReadOnlySpan`1[Lokad.Lython.Runtime.CallArgumentValue],Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.FunctionBindingPlan,Lokad.Lython.Frontend.FunctionParameterLayout,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,System.Object,Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,byref,byref,byref):int]
       mov      dword ptr [rbp-0x5C], eax
 
G_M000_IG10:                ;; offset=0x019E
       mov      edx, dword ptr [rbp-0x5C]
       mov      eax, edx
       cmp      eax, dword ptr [rbx+0x3C]
       jge      G_M000_IG14
 
G_M000_IG11:                ;; offset=0x01AC
       cmp      eax, dword ptr [rbp-0x8C]
       jae      G_M000_IG41
       mov      r9, rax
       shl      r9, 4
       mov      qword ptr [rbp-0xC8], r9
       mov      r11, bword ptr [rbp-0xF8]
       cmp      gword ptr [r11+r9], 0
       jne      SHORT G_M000_IG13
 
G_M000_IG12:                ;; offset=0x01D4
       mov      edx, dword ptr [rbx+0x3C]
       mov      qword ptr [rbp-0xE0], rax
       sub      edx, eax
       lea      r8, [rbp-0x80]
       mov      rcx, rdi
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:TryGetPositionalDefault(int,byref):bool:this]
       test     eax, eax
       je       G_M000_IG40
       mov      r8, qword ptr [rbp-0xC8]
       add      r8, bword ptr [rbp-0xF8]
       mov      rcx, r8
       mov      bword ptr [rbp-0x100], rcx
       mov      rdx, gword ptr [rbp-0x80]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      r8, qword ptr [rbp-0x78]
       mov      rdx, bword ptr [rbp-0x100]
       mov      qword ptr [rdx+0x08], r8
       mov      rax, qword ptr [rbp-0xE0]
 
G_M000_IG13:                ;; offset=0x022E
       inc      eax
       cmp      eax, dword ptr [rbx+0x3C]
       jl       G_M000_IG11
 
G_M000_IG14:                ;; offset=0x0239
       mov      dword ptr [rbp-0x60], -1
       cmp      dword ptr [rbx+0x40], 0
       je       G_M000_IG15
       mov      r11, bword ptr [rbp-0xF8]
       mov      bword ptr [rbp-0xA0], r11
       mov      r10d, dword ptr [rbp-0x8C]
       mov      dword ptr [rbp-0x98], r10d
       mov      gword ptr [rsp+0x20], r14
       lea      r8, [rbp-0xA0]
       mov      rdx, rbx
       mov      rcx, rdi
       mov      r9, gword ptr [rbp+0x38]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:TryFillPreparedKeywordDefaults(Lokad.Lython.Frontend.FunctionParameterLayout,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG15
       mov      rax, bword ptr [rbp-0xF8]
       mov      bword ptr [rbp-0xA0], rax
       mov      r10d, dword ptr [rbp-0x8C]
       mov      dword ptr [rbp-0x98], r10d
       mov      r9, gword ptr [rbp+0x38]
       mov      gword ptr [rsp+0x20], r9
       movzx    rcx, byte  ptr [rbp+0x40]
       mov      dword ptr [rsp+0x28], ecx
       lea      rcx, [rbp-0xA0]
       mov      rdx, r14
       mov      r8, rdi
       mov      r9, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime:CompleteLiveKeywordDefaults(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.FunctionBindingPlan,Lokad.Lython.Frontend.FunctionParameterLayout,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,bool):int]
       mov      dword ptr [rbp-0x60], eax
 
G_M000_IG15:                ;; offset=0x02CE
       cmp      dword ptr [rbx+0x50], 0
       jl       G_M000_IG17
       cmp      gword ptr [rbp-0x50], 0
       jne      SHORT G_M000_IG16
       mov      r9, gword ptr [rbp+0x38]
       mov      rdi, gword ptr [r9+0x98]
       mov      rcx, 0x7FF9D78310B8
       call     CORINFO_HELP_NEWSFAST
       mov      gword ptr [rbp-0xE8], rax
       mov      rdi, gword ptr [rdi+0x88]
       lea      rcx, bword ptr [rax+0x10]
       mov      rdx, rdi
       call     CORINFO_HELP_ASSIGN_REF
       mov      rax, gword ptr [rbp-0xE8]
       lea      rcx, bword ptr [rax+0x18]
       mov      rdx, r14
       call     CORINFO_HELP_ASSIGN_REF
       mov      rax, gword ptr [rbp-0xE8]
       mov      byte  ptr [rax+0x54], 0
       mov      rcx, rax
       mov      r9, r14
       mov      r8, rdi
       xor      edx, edx
       call     [Lokad.Lython.Runtime.PyDict:InitializeNativeStorage(int,Lokad.Lython.Runtime.MemoryGovernor,Lokad.Lython.LythonSourceSpan):this]
       mov      rdi, gword ptr [rbp-0xE8]
       lea      rcx, bword ptr [rdi+0x08]
       mov      rdx, rdi
       call     CORINFO_HELP_ASSIGN_REF
       mov      gword ptr [rbp-0x50], rdi
 
G_M000_IG16:                ;; offset=0x0359
       mov      r9, gword ptr [rbp+0x38]
       mov      rdi, gword ptr [r9+0x98]
       cmp      byte  ptr [rdi], dil
       mov      rcx, rdi
       call     [Lokad.Lython.Runtime.ExecutionState:get_CanContinue():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG17
       mov      rcx, rdi
       mov      rdx, r14
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
 
G_M000_IG17:                ;; offset=0x0380
       mov      edx, dword ptr [rbx+0x4C]
       test     edx, edx
       jl       G_M000_IG35
       cmp      edx, dword ptr [rbp-0x8C]
       jae      G_M000_IG41
       mov      edi, edx
       shl      rdi, 4
       add      rdi, bword ptr [rbp-0xF8]
       cmp      dword ptr [rbp-0x48], 0
       je       G_M000_IG33
       mov      bword ptr [rbp-0xC0], r12
       mov      r12d, dword ptr [rbp-0x90]
       mov      dword ptr [rbp-0xB8], r12d
       mov      edx, dword ptr [rbp-0x40]
       mov      dword ptr [rsp+0x20], edx
       mov      edx, dword ptr [rbp-0x48]
       mov      dword ptr [rsp+0x28], edx
       mov      r9, gword ptr [rbp+0x38]
       mov      gword ptr [rsp+0x30], r9
       mov      gword ptr [rsp+0x38], r14
       lea      rdx, [rbp-0xC0]
       mov      rcx, rsi
       mov      r8, r13
       mov      r9, r15
       call     [Lokad.Lython.Runtime.LythonRuntime:CreateVariadicPositionalTuple(System.ReadOnlySpan`1[Lokad.Lython.Runtime.CallArgumentValue],System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],Lokad.Lython.Frontend.ExecutableCallSite,System.Object,int,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.PyTuple]
       mov      rdx, rax
       jmp      G_M000_IG34
 
G_M000_IG18:                ;; offset=0x03FD
       mov      dword ptr [rbp-0x5C], r8d
       jmp      G_M000_IG10
 
G_M000_IG19:                ;; offset=0x0406
       mov      rax, gword ptr [rbp-0x70]
       mov      r9, 0x19883003970
       cmp      rax, gword ptr [r9]
       je       G_M000_IG26
       cmp      qword ptr [rbp-0x68], 0
       jne      SHORT G_M000_IG20
       mov      rax, gword ptr [rbp-0x70]
       mov      dword ptr [rbp-0x5C], r8d
       jmp      G_M000_IG32
 
G_M000_IG20:                ;; offset=0x0431
       cmp      qword ptr [rbp-0x68], 0
       jle      G_M000_IG25
       mov      dword ptr [rbp-0x5C], r8d
       mov      rdx, gword ptr [rbp-0x70]
       mov      rcx, 0x7FF9D7934238
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       mov      gword ptr [rbp-0xF0], rax
       test     rax, rax
       jne      SHORT G_M000_IG22
 
G_M000_IG21:                ;; offset=0x045F
       mov      r8d, dword ptr [rbp-0x5C]
       mov      r10, bword ptr [rbp-0xF8]
       mov      r11d, dword ptr [rbp-0x8C]
       jmp      G_M000_IG25
 
G_M000_IG22:                ;; offset=0x0476
       mov      r8d, dword ptr [rbp-0x68]
       dec      r8d
       mov      dword ptr [rbp-0x88], r8d
       mov      rdx, gword ptr [rax+0x08]
       mov      rcx, 0x7FF9D7142560
       call     CORINFO_HELP_ISINSTANCEOFARRAY
       test     rax, rax
       je       SHORT G_M000_IG23
       mov      r8d, dword ptr [rbp-0x88]
       cmp      r8d, dword ptr [rax+0x08]
       jae      G_M000_IG41
       mov      ecx, r8d
       mov      rax, gword ptr [rax+8*rcx+0x10]
       jmp      SHORT G_M000_IG24
 
G_M000_IG23:                ;; offset=0x04B7
       mov      r8d, dword ptr [rbp-0x88]
       mov      rcx, gword ptr [rbp-0xF0]
       mov      edx, r8d
       call     [Lokad.Lython.Runtime.PyTuple:WritableValueSlot(int):byref:this]
       mov      rcx, rax
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishSharedInteger():System.Object:this]
 
G_M000_IG24:                ;; offset=0x04D7
       mov      gword ptr [rbp-0x70], rax
       xor      ecx, ecx
       mov      qword ptr [rbp-0x68], rcx
       mov      r8d, dword ptr [rbp-0x5C]
       mov      r10, bword ptr [rbp-0xF8]
       mov      r11d, dword ptr [rbp-0x8C]
 
G_M000_IG25:                ;; offset=0x04F3
       mov      rax, gword ptr [rbp-0x70]
       mov      dword ptr [rbp-0x5C], r8d
       jmp      G_M000_IG32
 
G_M000_IG26:                ;; offset=0x0500
       mov      dword ptr [rbp-0x5C], r8d
       mov      rcx, 0x7FF9D7176488
       call     CORINFO_HELP_NEWSFAST
       vmovsd   xmm0, qword ptr [rbp-0x68]
       vmovsd   qword ptr [rax+0x08], xmm0
       mov      gword ptr [rbp-0x70], rax
       xor      ecx, ecx
       mov      qword ptr [rbp-0x68], rcx
       mov      rcx, qword ptr [rbp-0xD0]
       mov      r8d, dword ptr [rbp-0x5C]
       mov      r10, bword ptr [rbp-0xF8]
       mov      r11d, dword ptr [rbp-0x8C]
 
G_M000_IG27:                ;; offset=0x0540
       lea      eax, [r8+0x01]
       mov      dword ptr [rbp-0x5C], eax
       cmp      r8d, r11d
       jae      G_M000_IG41
       mov      r8d, r8d
       shl      r8, 4
       add      r8, r10
       mov      bword ptr [rbp-0x108], r8
       mov      qword ptr [rbp-0xD0], rcx
       lea      r9, bword ptr [r12+rcx]
       mov      bword ptr [rbp-0x110], r9
       mov      rdx, gword ptr [r9]
       mov      rcx, r8
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rdx, bword ptr [rbp-0x110]
       mov      rdx, qword ptr [rdx+0x08]
       mov      r8, bword ptr [rbp-0x108]
       mov      qword ptr [r8+0x08], rdx
       mov      rcx, qword ptr [rbp-0xD0]
       add      rcx, 16
       mov      edx, dword ptr [rbp-0xD4]
       dec      edx
       mov      dword ptr [rbp-0xD4], edx
       je       G_M000_IG10
 
G_M000_IG28:                ;; offset=0x05B3
       mov      r8d, dword ptr [rbp-0x5C]
       mov      r9, gword ptr [rbp+0x38]
       mov      r10, bword ptr [rbp-0xF8]
       mov      r11d, dword ptr [rbp-0x8C]
 
G_M000_IG29:                ;; offset=0x05C9
       cmp      gword ptr [r12+rcx], 0
       jne      G_M000_IG27
 
G_M000_IG30:                ;; offset=0x05D4
       mov      qword ptr [rbp-0xD0], rcx
       vmovdqu  xmm0, xmmword ptr [r12+rcx]
       vmovdqu  xmmword ptr [rbp-0x70], xmm0
 
G_M000_IG31:                ;; offset=0x05E6
       mov      rax, gword ptr [rbp-0x70]
       mov      r9, 0x19883003968
       cmp      rax, gword ptr [r9]
       jne      G_M000_IG19
       mov      dword ptr [rbp-0x5C], r8d
       lea      rcx, [rbp-0x70]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishInteger():System.Object:this]
 
G_M000_IG32:                ;; offset=0x060B
       test     rax, rax
       mov      rcx, qword ptr [rbp-0xD0]
       mov      r8d, dword ptr [rbp-0x5C]
       mov      r10, bword ptr [rbp-0xF8]
       mov      r11d, dword ptr [rbp-0x8C]
       jne      G_M000_IG27
       jmp      G_M000_IG39
 
G_M000_IG33:                ;; offset=0x0632
       mov      rdx, 0x19883001C18
       mov      rdx, gword ptr [rdx]
 
G_M000_IG34:                ;; offset=0x063F
       mov      rcx, rdi
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       xor      ecx, ecx
       mov      qword ptr [rdi+0x08], rcx
 
G_M000_IG35:                ;; offset=0x064D
       cmp      gword ptr [rbp-0x50], 0
       je       SHORT G_M000_IG37
       mov      ecx, dword ptr [rbx+0x50]
       cmp      ecx, dword ptr [rbp-0x8C]
       jae      G_M000_IG41
       mov      ebx, ecx
       shl      rbx, 4
       add      rbx, bword ptr [rbp-0xF8]
       mov      rdx, gword ptr [rbp-0x50]
       mov      rcx, rbx
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       xor      ecx, ecx
       mov      qword ptr [rbx+0x08], rcx
 
G_M000_IG36:                ;; offset=0x0682
       mov      gword ptr [rbp-0x50], rcx
 
G_M000_IG37:                ;; offset=0x0686
       mov      edi, dword ptr [rbp-0x60]
       mov      dword ptr [rbp-0x84], edi
       jmp      G_M000_IG42
 
G_M000_IG38:                ;; offset=0x0694
       mov      rcx, rdi
       mov      rax, qword ptr [rdi]
       mov      rax, qword ptr [rax+0x40]
       call     [rax+0x28]Lokad.Lython.Runtime.FunctionBindingPlan:get_CallableKind():int:this
       mov      ebx, eax
       mov      rcx, rdi
       mov      rax, qword ptr [rdi]
       mov      rax, qword ptr [rax+0x40]
       call     [rax+0x20]Lokad.Lython.Runtime.FunctionBindingPlan:get_CallableName():System.String:this
       mov      rdx, rax
       mov      ecx, ebx
       mov      r8, r14
       call     [Lokad.Lython.Runtime.CallErrors:TooManyPositional(int,System.String,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.LythonRuntimeException]
       mov      rcx, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG39:                ;; offset=0x06C7
       mov      rcx, 0x7FF9D72A94A8
       call     CORINFO_HELP_NEWSFAST
       mov      rdi, rax
       mov      rcx, rdi
       mov      rdx, 0x1B8A9A90228
       call     [System.InvalidOperationException:.ctor(System.String):this]
       mov      rcx, rdi
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG40:                ;; offset=0x06F5
       mov      rax, qword ptr [rbp-0xE0]
       mov      esi, eax
       mov      rcx, rdi
       mov      rax, qword ptr [rdi]
       mov      rax, qword ptr [rax+0x40]
       call     [rax+0x28]Lokad.Lython.Runtime.FunctionBindingPlan:get_CallableKind():int:this
       mov      r15d, eax
       mov      rcx, rdi
       mov      rax, qword ptr [rdi]
       mov      rax, qword ptr [rax+0x40]
       call     [rax+0x20]Lokad.Lython.Runtime.FunctionBindingPlan:get_CallableName():System.String:this
       mov      rdx, rax
       mov      rcx, gword ptr [rbx+0x08]
       cmp      esi, dword ptr [rcx+0x08]
       jae      SHORT G_M000_IG41
       mov      r8d, esi
       mov      r8, gword ptr [rcx+8*r8+0x10]
       mov      ecx, r15d
       mov      r9, r14
       call     [Lokad.Lython.Runtime.CallErrors:MissingArgument(int,System.String,System.String,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.LythonRuntimeException]
       mov      rcx, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG41:                ;; offset=0x0744
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG42:                ;; offset=0x074A
       call     G_M000_IG48
       nop      
 
G_M000_IG43:                ;; offset=0x0750
       mov      eax, dword ptr [rbp-0x84]
 
G_M000_IG44:                ;; offset=0x0756
       add      rsp, 328
       pop      rbx
       pop      rsi
       pop      rdi
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG45:                ;; offset=0x076A
       sub      rsp, 104
 
G_M000_IG46:                ;; offset=0x076E
       mov      r9, gword ptr [rbp+0x38]
       mov      rcx, gword ptr [r9+0x98]
       mov      rcx, gword ptr [rcx+0x88]
       mov      rdx, qword ptr [rbp-0x58]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.MemoryGovernor:Release(long):this]
       nop      
 
G_M000_IG47:                ;; offset=0x078D
       add      rsp, 104
       ret      
 
G_M000_IG48:                ;; offset=0x0792
       sub      rsp, 104
 
G_M000_IG49:                ;; offset=0x0796
       cmp      gword ptr [rbp-0x50], 0
       je       SHORT G_M000_IG54
 
G_M000_IG50:                ;; offset=0x079D
       mov      rbx, gword ptr [rbp-0x50]
       cmp      byte  ptr [rbx], bl
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.PyDict:RefundAbortedConstruction():this]
       xor      rcx, rcx
       mov      gword ptr [rbx+0x08], rcx
 
G_M000_IG51:                ;; offset=0x07B2
       mov      gword ptr [rbx+0x28], rcx
 
G_M000_IG52:                ;; offset=0x07B6
       mov      gword ptr [rbx+0x30], rcx
 
G_M000_IG53:                ;; offset=0x07BA
       call     G_M000_IG45
       nop      
 
G_M000_IG54:                ;; offset=0x07C0
       add      rsp, 104
       ret      
 
; Total bytes of code 1989

