from dataclasses import dataclass, field

def factory(seed):
    marker = []
    def helper(first, /, second=seed, *, tag=marker, **extras):
        return first, second, tag is marker, list(extras.items())
    def iterator(value=seed + 10000, /):
        yield value
    return helper, iterator, (lambda first=seed, /, *, add=5: first + add)

first, iterator, transform = factory(7)
second, _, _ = factory(8)
print(first(1, **{"first": 9, "new": 6}))
first.__defaults__ = (11,)
first.__kwdefaults__ = {"tag": None}
print(first(2), second(2), transform(add=3))
kept = iterator.__defaults__[0]
print(next(iterator()) is kept)

class Base:
    def get(self, field=2):
        return field
class Child(Base):
    def get(self, field=3, /):
        return super().get(field) + 10
class Getter:
    def __get__(self, receiver, owner):
        def select(key, /, *, default=2):
            return owner.__name__, key + default
        return select
class Subscript:
    __class_getitem__ = Getter()
print(Child().get(), Subscript[6])

@dataclass(order=True, kw_only=True)
class Record:
    value: int
    labels: list = field(default_factory=list)
    limit: int = 2
a = Record(value=7)
b = Record(value=8)
print(a < b, a == b, a.labels is b.labels, a.limit)
