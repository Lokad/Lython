calls = []
def collect(label, **fields):
    calls.append(label)
    with open('text.txt') as input_file:
        fields['status'] = label + input_file.read()
    return fields
key = ''.join(['dynamic', '_key'])
value = []
fresh = collect('fresh', **{key: None, 'next': 1, key: value})
named = {key: value}
other = collect('other', **named)
def make_record(label):
    return collect(label, **{'fixed': value})
record = make_record('record')
repeated = make_record('repeated')
print(list(fresh), next(iter(fresh)) is key, fresh[key] is value)
print(other is not named, 'status' not in named, record['fixed'] is value)
print(record is not repeated, repeated['fixed'] is value)
print(fresh['status'], other['status'], record['status'], repeated['status'])
try: collect('unreachable', **{'label': 1, 5: value})
except TypeError as error: print('keywords must be strings' in str(error))
try: collect('unreachable', **{'label': 1})
except TypeError as error: print('multiple values' in str(error))
print(calls)
