from pathlib import Path
import ast,gzip,hashlib,json,re,subprocess,tarfile
r=Path(__file__).resolve().parent;repo=Path('D:/code/Lython');prior=r.parent/'record-cpython-r502';old=prior/'quiet';q=r/'quiet';q.mkdir(exist_ok=False)
f=json.loads((r.parent/'generator-facts-r503/frozen/identity.json').read_text(encoding='utf-8'));files=f['imageFiles']['candidate'];image=r.parent/'generator-facts-r503/frozen/candidate'
assert len(files)==32 and all(hashlib.sha256((image/n).read_bytes()).hexdigest()==h for n,h in files.items())
assert json.loads((r/'preflight.json').read_text(encoding='utf-8'))
catalog_hash=hashlib.sha256((r/'catalog.json').read_bytes()).hexdigest()
identity=dict(sourceRevision='Qualified62786960 production/frozen5ae019db versus CPython3.13.16. Later commits evidence only.',purpose='Existing complete config-edit.small compile/warm/fresh, report-render.large warm and affected floating report warm/fresh. Separate fixed invocation costs from bulk runtime work before a redesign; no predicted source gain.',coreSHA256={role:files['Lokad.Lython.dll']for role in ['candidate','candidate-control']},imageFiles=dict(candidate=files),auxiliaryFiles={n:h for n,h in files.items()if n!='Lokad.Lython.dll'},sourceInputsArchiveSHA256=hashlib.sha256((r.parent/'generator-facts-r503/candidate-sources.tar.xz').read_bytes()).hexdigest(),productionFiles=585,catalogSHA256=catalog_hash,normalAdapterPin='0.4.0',publicationHeld=True)
(q/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8',newline='\n')
jobs=[['scripts.config-edit.small',lane]for lane in ['compile','warm','compile-run']]+[['scripts.report-render.large','warm']]+[['scripts.numeric-squared-error.floating.large',lane]for lane in ['warm','compile-run']]
s=(old/'collect.py').read_text(encoding='utf-8');a=s.index('jobs=');b=s.index('\nenv =',a);s=s[:a]+'jobs='+repr(jobs)+'\nassert len(jobs)==6 and all(case in cases for case,lane in jobs)\n'+s[b:];s=re.sub(r'time.monotonic\(\)-started < \d+','time.monotonic()-started < 270',s);(q/'collect.py').write_text(s,encoding='utf-8',newline='\n')
s=(old/'archive-owned.py').read_text(encoding='utf-8');s=re.sub(r"len\(raw\['jobs'\]\)==\d+","len(raw['jobs'])==6",s);s=re.sub(r'jobs=\d+','jobs=6',s);assert "len(raw['jobs'])==6"in s;(q/'archive-owned.py').write_text(s,encoding='utf-8',newline='\n')
remote='/home/lokad/lython-bench-checks/agent-checkpoint-b929-20261118';unit='lython-b929-agent-checkpoint-20261118';oldconfig=json.loads((old/'config.json').read_text(encoding='utf-8'))
(q/'run.sh').write_text((old/'run.sh').read_text(encoding='utf-8').replace(oldconfig['root'],remote),encoding='utf-8',newline='\n');(q/'representative.json').write_bytes((r/'catalog.json').read_bytes())
canonical='benchmarks/results/2026-11-17-constant-record-keys/candidate-core.dll.gz';blob=subprocess.check_output(['git','show','HEAD:'+canonical],cwd=repo);assert blob==(repo/canonical).read_bytes();data=gzip.decompress(blob);assert hashlib.sha256(data).hexdigest()!=files['Lokad.Lython.dll']
subjects=[dict(kind='superseded-core',sha256=hashlib.sha256(data).hexdigest(),bytes=len(data),canonical=canonical,canonicalSHA256=hashlib.sha256(blob).hexdigest(),member='gzip-payload',committedBlobVerified=True)]
s=(r.parent/'json-scalars-r492/prepare-quiet.py').read_text(encoding='utf-8');a=s.index("code = '''")+len("code = '''");b=s.index("'''.replace",a);code=s[a:b].replace('SUBJECTS',repr(subjects)).replace('json-cpython-b908-20261117','generator-facts-b928-20261117')
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
p=subprocess.run(ssh+['python3 -'],input=code,text=True,encoding='utf-8',capture_output=True,timeout=60);assert p.returncode==0,p.stdout+p.stderr;groups=json.loads(p.stdout);(r/'retirement-candidates.json').write_text(p.stdout,encoding='utf-8')
names=['collect.py','archive-owned.py','run.sh','identity.json','representative.json']
with tarfile.open(q/'payload.tgz','w:gz')as a:
 for n in names:a.add(q/n,arcname=n)
c=dict(root=remote,unit=unit,source='/home/lokad/lython-bench-checks/generator-facts-b928-20261117',sourceRole='candidate',sourceFiles=files,sourceCatalogSHA256=f['catalogSHA256'],catalogSHA256=catalog_hash,identity=identity,retireGroups=groups,payloadBytes=(q/'payload.tgz').stat().st_size,payloadSHA256=hashlib.sha256((q/'payload.tgz').read_bytes()).hexdigest(),unpackedBytes=sum((q/n).stat().st_size for n in names))
(q/'config.json').write_text(json.dumps(c,indent=2)+'\n',encoding='utf-8',newline='\n')
s=(old/'remote-launch.py').read_text(encoding='utf-8');a=s.index('c=');b=s.index('\nb=Path(',a);s=s[:a]+'c='+repr(c)+s[b:]
s=s.replace(" os.link(source/'representative.json',root/'representative.json')\n",'');s=re.sub(r'RuntimeMaxSec=\d+','RuntimeMaxSec=330',s).replace('lython-b927-fixtures','lython-b929-fixtures');assert 'RuntimeMaxSec=330'in s;(q/'remote-launch.py').write_text(s,encoding='utf-8',newline='\n')
s=(prior/'launch.py').read_text(encoding='utf-8');s=re.sub(r'seconds=\d+','seconds=280',s).replace('before180seconds','before280seconds').replace('Three-job record CPython checkpoint','Six-job complete-agent checkpoint');(r/'launch.py').write_text(s,encoding='utf-8',newline='\n')
s=(old/'retrieve.py').read_text(encoding='utf-8');s=re.sub(r"\['jobs'\]==\d+","['jobs']==6",s).replace('B927','B929');(q/'retrieve.py').write_text(s,encoding='utf-8',newline='\n')
s=(prior/'summarize.py').read_text(encoding='utf-8');s=re.sub(r"len\(raw\['jobs'\]\)==\d+","len(raw['jobs'])==6",s);(r/'summarize.py').write_text(s,encoding='utf-8',newline='\n')
for p in list(q.glob('*.py'))+[r/'launch.py',r/'summarize.py']:ast.parse(p.read_text(encoding='utf-8'))
assert "['jobs']==6"in(q/'retrieve.py').read_text(encoding='utf-8')and "len(raw['jobs'])==6"in(r/'summarize.py').read_text(encoding='utf-8')
print(json.dumps(dict(prepared=True,jobs=6,image=files['Lokad.Lython.dll'][:8],catalogBytes=(r/'catalog.json').stat().st_size,collectorCap=270,serviceCap=330,oldCoreAliasesOnly=groups[0]['paths'])))
