from pathlib import Path
import hashlib,json,tarfile
r=Path(__file__).resolve().parent;repo=Path('D:/code/Lython');source=repo/'benchmarks/results/2026-11-12-config-report-costs/cost-profiles.tgz'
with tarfile.open(source)as a:catalog=json.loads(a.extractfile('catalog.json').read())
cases=catalog['cases'];print('Existing captured cases:',[(c['id'],c['sourceSha256'])for c in cases],flush=True)
chosen=[c for c in cases if c['id']in ['scripts.config-edit.small','scripts.report-render.large']];assert len(chosen)==2,[c['id']for c in cases]
for c in chosen:
 name='config-edit'if'config-edit'in c['id']else'report-render'
 assert (repo/('benchmarks/scripts/'+name+'.py')).read_text(encoding='utf-8')==c['source'],c['id']
 assert hashlib.sha256(c['source'].encode()).hexdigest()==c['sourceSha256']
catalog['cases']=chosen;(r/'catalog.json').write_text(json.dumps(catalog,indent=2,ensure_ascii=False)+'\n',encoding='utf-8',newline='\n')
(r/'catalog-origin.json').write_text(json.dumps(dict(existingEvidence=source.relative_to(repo).as_posix(),archiveSHA256=hashlib.sha256(source.read_bytes()).hexdigest(),maintainedSourceTextEqual=True,independentExistingGoldens=True,selected=[c['id']for c in chosen]),indent=2)+'\n',encoding='utf-8',newline='\n')
print('Two existing complete workloads; source text equals maintained scripts, original fixtures/goldens reused.')
