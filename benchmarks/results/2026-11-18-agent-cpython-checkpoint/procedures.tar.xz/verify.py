from pathlib import Path
import hashlib,json,os,subprocess
r=Path(__file__).resolve().parent;repo=Path('D:/code/Lython');image=r.parent/'generator-facts-r503/frozen/candidate';f=json.loads((r.parent/'generator-facts-r503/frozen/identity.json').read_text(encoding='utf-8'))
assert len(f['imageFiles']['candidate'])==32 and all(hashlib.sha256((image/n).read_bytes()).hexdigest()==h for n,h in f['imageFiles']['candidate'].items())
d=Path('C:/Users/JoannesVermorel/.dotnet11/dotnet.exe');env=os.environ.copy();env.update(DOTNET_ROOT=str(d.parent),DOTNET_ROOT_X64=str(d.parent));env['PATH']=str(d.parent)+os.pathsep+env['PATH']
commands=[('preflight',[str(d),str(image/'Lokad.Lython.Benchmarks.dll'),'--compare','verify','--catalog',str(r/'catalog.json'),'--dotnet',str(d),'--python','C:/Python313/python.exe','--python-worker',str(repo/'benchmarks/cpython-worker.py'),'--out',str(r/'preflight.json')]),('allocation',[str(d),str(image/'ValidatedAllocation.dll'),str(image),str(r/'catalog.json'),str(r/'allocation.json')])]
for label,cmd in commands:
 with(r/(label+'.log')).open('w',encoding='utf-8')as log:p=subprocess.run(cmd,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=180)
 assert p.returncode==0,(r/(label+'.log')).read_text(encoding='utf-8');print(label,'passes',flush=True)
