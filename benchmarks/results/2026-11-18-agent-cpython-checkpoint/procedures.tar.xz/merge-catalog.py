from pathlib import Path
import json,shutil
r=Path(__file__).resolve().parent;p=r/'catalog.json';assert not(r/'two-case-catalog.json').exists();shutil.copyfile(p,r/'two-case-catalog.json')
catalog=json.loads(p.read_text(encoding='utf-8'));other=json.loads((r.parent/'generator-facts-r503/catalog.json').read_text(encoding='utf-8'));case=next(c for c in other['cases']if c['id']=='scripts.numeric-squared-error.floating.large')
assert len(catalog['cases'])==2;catalog['cases'].append(case);p.write_text(json.dumps(catalog,indent=2,ensure_ascii=False)+'\n',encoding='utf-8',newline='\n')
for name in ['preflight.json','preflight.log','allocation.json','allocation.log']:
 (r/name).rename(r/('two-case-'+name))
print('Merged unchanged floating case with current config/report sources; merged catalog requires actual-image verification.')
