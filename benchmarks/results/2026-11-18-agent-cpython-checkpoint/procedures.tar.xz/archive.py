from pathlib import Path
import hashlib,json,shutil,tarfile
r=Path(__file__).resolve().parent;repo=Path('D:/code/Lython')
out=repo/'benchmarks/results/2026-11-18-agent-cpython-checkpoint';out.mkdir(exist_ok=False)
for n in ['summary.json','catalog.json','catalog-origin.json','allocation.json','preflight.json']:
    shutil.copyfile(r/n,out/n)
for n in ['identity.json','archive-receipt.json','terminal-status.json','observations.tgz']:
    shutil.copyfile(r/'quiet'/n,out/n)
identity=json.loads((out/'identity.json').read_text(encoding='utf-8'))
assert hashlib.sha256((repo/'benchmarks/results/2026-11-17-generator-field-facts/candidate-sources.tar.xz').read_bytes()).hexdigest()==identity['sourceInputsArchiveSHA256']
with tarfile.open(out/'procedures.tar.xz','w:xz')as a:
    for p in sorted(r.rglob('*')):
        if not p.is_file()or 'retrieved'in p.relative_to(r).parts:continue
        if p.suffix not in ['.py','.json','.log','.sh']:continue
        a.add(p,arcname=p.relative_to(r).as_posix())
summary=json.loads((out/'summary.json').read_text(encoding='utf-8'))
names={'scripts.config-edit.small':'Configuration edit','scripts.report-render.large':'Formatted report','scripts.numeric-squared-error.floating.large':'Floating JSON numeric report'}
def measurement(row):
    times=row['medianMilliseconds'];a=[times[x]for x in ['candidate','candidate-control']];b=[times[x]for x in ['CPython','CPython-control']]
    return f'{min(a):.3f}–{max(a):.3f} ms',f'{min(b):.3f}–{max(b):.3f} ms',f"{min(row['ratioRange']):.2f}–{max(row['ratioRange']):.2f}×",f"Diagnostic627/5ae; controls L/C {row['lythonControlPercent']:.2f}/{row['cpythonControlPercent']:.2f}%; IQR≤{row['maxIqrPercent']:.2f}%"
table=[]
for row in summary['timing']:
    phase={'compile':'Compilation only','warm':'Warm execution','compile-run':'Compile-to-result'}[row['lane']]
    table.append('| '+names[row['case']]+' | '+phase+' | '+' | '.join(measurement(row))+' |')
(out/'README.md').write_text('''# Targeted complete-agent-script CPython checkpoint

B929,2026-11-18 UTC, qualified62786960 production/frozen5ae019db versus stock
CPython3.13.16(PGO/LTO,GIL,no JIT). Quiet AzureF4as_v7/4vCPU AMD EPYC9V45/16GiB,
Ubuntu24.04.4/.NET11RC3, normal GC/tiering. Six jobs226.58s; six-second full-request
warmups/five rotated rounds/two processes per engine. Existing workers/catalog.

| Complete script | Phase | Lython | CPython | Lython / CPython | Status |
| --- | --- | ---: | ---: | ---: | --- |
'''+ '\n'.join(table)+'''

Configuration edits181B/16paths; report3072records/189441B; floating4096pairs/56495B.
Config/report source text equals the maintained scripts and archived R469 catalog.
All32image hashes, actual-worker catalog verification, goldens and shared-budget
cleanup pass. Local process-wide allocation diagnostics are separate from VM timing;
their first compile/run clocks are cold, uncontrolled observations.

Warm guest clocks include Run, mediated RAM-backed I/O, output/file goldens and
previous-result cleanup. Fresh adds compilation/compiled-owner disposal. Compilation
includes owner disposal. Startup/reset/request framing/final cache teardown excluded;
wider process CPU includes reset/protocol. Separately warmed phases are not additive.
CPython's native file APIs do not provide equivalent containment/ownership checks.

Config warm controls<0.8%/fresh<0.4% support a modest remaining latency gap, not
setup attribution. Report CPython control2.47%/maxIQR5.34%limits precision.
Floating identical Lython processes differ5.49%warm/8.33%fresh despite small IQRs:
keep this source/process uncertainty explicit; do not infer a causal R503 gain from
older collections or select one favorable process. No broad unchanged retiming.
The large floating gap persists; profile-guided redesign remains active.

Persistent archive verified under owned lease before RAM teardown; all users joined,
quiet gates passed, local SHA verified. Only exact committed supersededcf core aliases
retired after fresh identity/link/path proof; current5ae/catalog/toolchains retained,
254/252MiB guards unchanged. No publication or performance-universality claim.

[Summary](summary.json),[raw](observations.tgz),[identity](identity.json),
[catalog](catalog.json),[actual-worker verification](preflight.json),
[allocation/reuse](allocation.json),[procedures](procedures.tar.xz).
''',encoding='utf-8',newline='\n')
guide=repo/'docs/BENCHMARKS.md';s=guide.read_text(encoding='utf-8')
for row in summary['timing']:
    title=names[row['case']];fields=measurement(row)
    if row['lane']=='warm':
        size={'Configuration edit':'181 B / 16 paths','Formatted report':'3,072 records / 189,441 B','Floating JSON numeric report':'4,096 pairs / 56,495 B'}[title]
        line='| '+title+' | '+size+' | '+' | '.join(fields)+' |'
        if title=='Floating JSON numeric report':
            lines=s.splitlines();indices=[i for i,line in enumerate(lines)if line.startswith('| Floating JSON numeric report | 4,096')];assert len(indices)==1;lines[indices[0]]=line;s='\n'.join(lines)+'\n'
        else:
            needle='| JSON-lines record transform | 4,096';assert needle in s;s=s.replace(needle,line+'\n'+needle,1)
    elif title=='Configuration edit':
        phase='Compilation only'if row['lane']=='compile'else'Compile-to-result'
        needle='| JSON-lines record transform | Compilation only';assert needle in s
        s=s.replace(needle,'| '+title+' | '+phase+' | '+' | '.join(fields)+' |\n'+needle,1)
    else:
        lines=s.splitlines();indices=[i for i,line in enumerate(lines)if line.startswith('| Floating JSON numeric report | Compile and execute once')];assert len(indices)==1
        lines[indices[0]]='| '+title+' | Compile-to-result | '+' | '.join(fields)+' |';s='\n'.join(lines)+'\n'
s=s.replace('The CSV/text/aggregation/floating rows were measured','The CSV/text/aggregation rows and floating compilation-only row were measured')
needle='Warm clocks include Run, mediated RAM-backed file I/O';assert needle in s
s=s.replace(needle,'''The configuration/report/floating execution rows are a **2026-11-18** checkpoint
of qualified **62786960 production / frozen5ae019db**, same machine/toolchains:
six jobs226.58s. Config controls are small; report CPython IQR5.34% and floating
Lython control spread5.49%warm/8.33%fresh limit precision. The remaining floating
gap is clear; exact source gains are not inferred across collections.
[Sources, controls and raw data](../benchmarks/results/2026-11-18-agent-cpython-checkpoint/README.md).

'''+needle,1)
s=s.replace("Floating\ncompile-to-result's4.78%Lython control movement limits precision; no unchanged retiming\nis needed to establish the remaining large gap.","Floating\ncompile-to-result's8.33%Lython control movement limits precision; the original4.78%\ncondition remains in the earlier checkpoint. No broad unchanged retiming is needed\nto establish the remaining gap.")
s=s.replace('The floating fresh control, text warm CPython control and other distributions stay','The floating process controls, report IQR, text warm CPython control and other distributions stay')
guide.write_text(s,encoding='utf-8',newline='\n')
with(repo/'benchmarks/EXPERIMENTS.md').open('a',encoding='utf-8',newline='\n')as h:
    h.write('\nR505/B929 [complete-agent checkpoint](results/2026-11-18-agent-cpython-checkpoint/README.md): qualified627/5ae versus stockCPython3.13.16,6jobs226.58s/all32image/goldens/reuse/quiet/join/archiveSHA pass. Config compile1.05–1.08×,warm1.25–1.26×,fresh1.08×; reportwarm1.07–1.10×; floatingwarm1.66–1.75×/fresh1.47–1.60×. Floating identical-process controls5.49/8.33% and reportCP IQR5.34%retained; no causal source-gain claim or favorable-process selection. Config costs do not themselves attribute setup. Guide refreshes affected/new cases, old namedCSV/text/JSON/record evidence retained; no unchanged broad replay/publication.\n')
print('B929 archived and current guide refreshed.')
