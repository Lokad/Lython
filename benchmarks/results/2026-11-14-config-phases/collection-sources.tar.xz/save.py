from pathlib import Path
import hashlib,json,shutil,tarfile
r=Path(__file__).parent
timing=json.loads((r/'summary.json').read_text(encoding='utf-8'))
receipt=json.loads((r/'archive-receipt.json').read_text(encoding='utf-8'))
assert timing['complete']and timing['jobs']==3 and receipt['allWorkersJoined']and receipt['guestFixturesRemoved']
assert hashlib.sha256((r/'observations.tgz').read_bytes()).hexdigest()==receipt['archiveSHA256']
out=Path('benchmarks/results/2026-11-14-config-phases');out.mkdir()
for name in ['summary.json','identity.json','python-control.json','worker-verification.json','archive-receipt.json','terminal-status.json','observations.tgz']:shutil.copyfile(r/name,out/name)
with tarfile.open(out/'collection-sources.tar.xz','w:xz')as t:
    for name in ['prepare.py','verify.py','collect.py','archive-owned.py','run.sh','retrieve.py','summarize.py','launch.py','launch-command.py','launch.log','observe-not-before.json','catalog.json','config.json','render-catalog.log','render-before-script-data.log','save.py']:t.add(r/name,arcname=name)
table='| Phase | Lython µs | CPython µs | Lython/CPython | Process spread Lython/CPython | Max IQR |\n| --- | ---: | ---: | ---: | ---: | ---: |\n'
for row in timing['timing']:
    l=[1000*v for k,v in row['medianMilliseconds'].items()if k.startswith('candidate')]
    c=[1000*v for k,v in row['medianMilliseconds'].items()if k.startswith('CPython')]
    ratios=row['ratioRange']
    table+=f"|{row['lane']}|{min(l):.2f}–{max(l):.2f}|{min(c):.2f}–{max(c):.2f}|{min(ratios):.3f}–{max(ratios):.3f}×|{row['lythonControlPercent']:.2f}/{row['cpythonControlPercent']:.2f}%|{row['maxIqrPercent']:.2f}%|\n"
(out/'README.md').write_text(f'''# Small configuration edit: compilation and complete execution

2026-11-14UTC, R336/B707: committedcdd92944/frozenf4c4f027 versus stock
CPython3.13.16. Focused R335Release11/10 checks pass; full platform/stress/package
qualification is[still running43536449801](https://github.com/Lokad/Lython/actions/runs/43536449801).
This is a new phase-selection observation, not a runtime prototype or speedup
against an older Lython. No unchanged source qualification is repeated.

{table}
The existing `scripts.config-edit.empty` case reads96B of JSON, changes enabled/
retries, appends a path, writes sorted UTF8 JSON plus newline, and prints the path
count. `empty` means an initially empty paths collection; it is a complete357B
file-processing script, not an empty program. It preserves non-ASCII data and a
nested field. Input differs from the181B historical config row, which is retained.
Current fixed worker renders the existing catalog; script/fixture/output identities
are exact. Independent local CPython3.13.2 and frozen-worker goldens pass first.

B707completes{timing['elapsedSeconds']:.3f}s/all gates under one240s owner, quiet
AzureF4as_v7/Ubuntu24.04.4/.NET11RC3, ordinary workstation GC/tiering and CPython
GIL/GC. Two independent processes per engine/phase, five-second full-request wall
warmups and five rotating0.5s wall-sized batches. Ratios span all four process
median pairings, not confidence intervals. All raw samples and wider CPU survive.
Fresh CPython process spread2.27% and one Lython fresh IQR3.65% remain explicit.

Warm clocks include mediated RAM-file I/O, full stdout/file validation and
prior-result cleanup; compilation/startup, fixture reset/protocol and final caches
are excluded. Compile is compilation/compiled-owner disposal only; compile-run
adds both to execution. Each lane warms independently. **Do not add/subtract these
medians to attribute costs within one execution.** Wider process CPU includes
reset/protocol; its near-equal fresh medians are not isolated interpreter CPU.
Cancellation latency, shared-budget contention, RSS and embedding tails are not
measured here. Both engines use the same Python source/fixtures/goldens.

## Phase decision and stopping condition

Compilation is relevant for this short job but no disproportionate compiler cliff
is demonstrated:36.6–37.3µs versus34.3–34.4µs CPython. Warm and fresh gaps remain.
These observations do not establish repeated frontend facts, builtin construction
or a particular call/frame allocation as the dominant removable cost. Existing
[R297owning-source evidence](../2026-11-13-config-cpu-source-gate/README.md)
has prominent mediated resolution/open work and substantial unknown kernel leaves;
its CPU shares are historical, not inferred current fractions. Do not bypass host
containment or claim those costs are core interpreter work.

This bounded gate ends without a shared-type/cache or frontend-visitor prototype.
Current source already prepares shared lexical facts. Continue whole-script
construction/transport work from concrete remaining phases; materially different
evidence can justify refinement. No broad retiming or new benchmark framework.
No allocation reduction, source-pair gain or performance-objective completion is
claimed. The useful phase/CPU uncertainty is retained rather than declared failure.

All identity/golden/balance/quiet/join/archive gates pass. Exact current core/
581source inputs live in the[R335source archive](../2026-11-14-incremental-xml/source-checks.tar.xz).
No new producer/core build or pin change. Initial local selection found no config
in an older trimmed catalog; frozen catalog rendering then needed its script data.
Those setup-only conditions precede timing; the original missing-data log survives.
The corrected renderer uses the same fixed worker and existing script data.
The VM collection itself completes once; all users join, RAM fixtures unmount and
persistent evidence SHA verifies. No image/evidence retirement or disk-floor change.
Publication remains held.

[Summary/wider CPU](summary.json), [raw](observations.tgz),
[collection sources and setup conditions](collection-sources.tar.xz).
''',encoding='utf-8',newline='\n')
p=Path('benchmarks/EXPERIMENTS.md')
with p.open('a',encoding='utf-8',newline='\n')as f:f.write('''
## R336 — short configuration phases

[Three current-image phases](results/2026-11-14-config-phases/README.md), one
101.301s quiet collection/all gates, compare identical96B file edits atcdd92944/
f4c4f027 with stockCPython3.13.16. Compile36.6–37.3vs34.3–34.4µs(1.06–1.09×),
warm75.3–76.4vs59.6–59.7µs(1.26–1.28×), compile-run136.5–137.3vs121.4–124.2µs
(1.10–1.13×). Independently warmed clocks are not additive attribution. Fresh
process/IQR uncertainty and setup-only catalog/script-data failures survive.
No compiler cliff or dominant removable setup stage is established; reuse R297
historical owning-source limits rather than select a blind metadata/visitor/cache
prototype. No source-pair/allocation gain or broader objective completion claim.
R335full qualification continues; no unchanged tests/pin promotion repeated.
''')
p=Path('PLAN.md');s=p.read_text(encoding='utf-8')
s=s.replace('allocation−19.92%Run/−19.31%Async','allocation−19.92%CSVhelpers/−19.31%JSONhelpers')
a=s.index('2. **R336 active:');b=s.index('\n3. **Select',a)
s=s[:a]+'''2. **R336 phase gate complete; choose the next coherent removal from owning work.**
   B707three jobs/101.301s/all gates, committedcdd/f4, same96B config edit vs stock
   CPython3.13.16: compile1.06–1.09×, warm1.26–1.28×, fresh1.10–1.13×. Both current
   phase/source identities, actual I/O/checks/cleanup and adverse controls persist.
   These independently warmed medians cannot be added/subtracted as attribution.
   No compiler cliff or dominant removable setup stage is established. Historical
   R297 shows prominent mediated resolution/open work and unknown kernel leaves;
   do not bypass capabilities or call that core interpreter cost. Current lexical
   facts are already shared. No blind visitor/metadata/cache prototype is selected.
   Stop this phase collection with its usable uncertainty; do not repeat it without
   a changed source/question. [Evidence](benchmarks/results/2026-11-14-config-phases/README.md).
   Resume the substantial call/operand/construction roadmap below. Any next owning-
   source capture must target a concrete remaining phase and preserve unknowns;
   use one bounded capture only if existing evidence cannot select the removal.
   This measurement does not complete a redesign or the performance objective.
''' +s[b:]
p.write_text(s,encoding='utf-8',newline='\n')
print('Saved R336 current config phases and decision; corrected helper-return CSV/JSON labels, no runtime gain inferred.',flush=True)
