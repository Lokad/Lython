from pathlib import Path
import importlib.util,json,os,subprocess,tempfile
r=Path(__file__).parent
spec=importlib.util.spec_from_file_location('protocol',r.parent/'xml-iterparse-r335/b706/retrieved/cpython-worker.py')
protocol=importlib.util.module_from_spec(spec);spec.loader.exec_module(protocol)
case=json.loads((r/'catalog.json').read_text(encoding='utf-8'))['cases'][0]
env=dict(os.environ);env['DOTNET_ROOT']='C:/Users/JoannesVermorel/.dotnet11'
with tempfile.TemporaryDirectory(prefix='lython-comparison-files-')as folder:
    p=subprocess.Popen([env['DOTNET_ROOT']+'/dotnet.exe',str((r.parent/'xml-iterparse-r335/candidate/Lokad.Lython.Benchmarks.dll').resolve()),'--compare','worker','--catalog',str((r/'catalog.json').resolve())],cwd=folder,env=env,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
    try:
        ready=protocol.read_frame(p.stdout);assert ready is not None and ready['status']=='Ready'
        request={k:case[k]for k in ['sourceSha256','fixtureSha256','expectedOutputSha256']}
        request.update(protocolVersion=2,requestId=1,operation='verify',caseId=case['id'],lane='warm',iterations=2)
        protocol.write_frame(p.stdin,request);response=protocol.read_frame(p.stdout)
        assert response is not None and response['status']=='Equivalent',response
        assert response['actualFilesSha256']==case['expectedFilesSha256']and response['actualOutputSha256']==case['expectedOutputSha256']
        protocol.write_frame(p.stdin,dict(protocolVersion=2,requestId=2,operation='quit'))
        assert protocol.read_frame(p.stdout)['status']=='Closed'
        assert p.wait(timeout=15)==0 and not p.stderr.read()
        (r/'worker-verification.json').write_text(json.dumps(dict(ready=ready,response=response,workersJoined=True,fixturesRemoved=True),indent=2)+'\n',encoding='utf-8',newline='\n')
    finally:
        if p.poll()is None:p.kill();p.wait()
        p.stdin.close();p.stdout.close();p.stderr.close()
print('Config goldens, worker identity and allowance reuse pass before timing.',flush=True)
