from pathlib import Path
import ast,base64,hashlib,json,os,shutil,subprocess,tarfile,tempfile
r=Path(__file__).parent
prior=r.parent/'checkpoint-cpython-r332/b704'
full=r/'rendered-catalog.json'
if not full.exists():
    env=dict(os.environ);env['DOTNET_ROOT']='C:/Users/JoannesVermorel/.dotnet11'
    if(r/'render-catalog.log').exists():(r/'render-before-script-data.log').write_bytes((r/'render-catalog.log').read_bytes())
    renderer=r/'catalog-renderer';renderer.mkdir(exist_ok=True)
    for file in(r.parent/'xml-iterparse-r335/candidate').iterdir():
        if file.is_file():shutil.copyfile(file,renderer/file.name)
    if not(renderer/'RepresentativeScripts').exists():shutil.copytree('benchmarks/scripts',renderer/'RepresentativeScripts')
    done=subprocess.run([env['DOTNET_ROOT']+'/dotnet.exe',str((renderer/'Lokad.Lython.Benchmarks.dll').resolve()),'--compare','list','--profile','representative','--out',str(full.resolve())],capture_output=True,env=env)
    (r/'render-catalog.log').write_bytes(done.stdout+done.stderr);assert done.returncode==0
catalog=json.loads(full.read_text(encoding='utf-8'))
selected=[c for c in catalog['cases']if 'config-edit'in c['id']]
print('Available configuration controls',[(c['id'],c['size'])for c in selected],flush=True)
assert selected
case=min(selected,key=lambda c:c['size'])
assert case['size']==0,case['id']
catalog['cases']=[case]
(r/'catalog.json').write_text(json.dumps(catalog,separators=(',',':'),ensure_ascii=False)+'\n',encoding='utf-8',newline='\n')
fixture=json.loads(case['fixtureJson'])
with tempfile.TemporaryDirectory(prefix='config-python-control-',dir=r.resolve())as folder:
    work=Path(folder).resolve();assert work.parent==r.resolve()
    for name,payload in fixture['inputFiles'].items():(work/name).write_bytes(base64.b64decode(payload))
    done=subprocess.run(['C:/Python313/python.exe','-I','-S','-X','utf8','-c',case['source']],cwd=work,capture_output=True,text=True,encoding='utf-8',timeout=15)
    assert done.returncode==0 and not done.stderr and done.stdout==case['expectedOutput'],(done.stdout,done.stderr)
    for name,payload in fixture['outputFiles'].items():assert(work/name).read_bytes()==base64.b64decode(payload)
(r/'python-control.json').write_text(json.dumps(dict(reference='CPython3.13.2 isolated',case=case['id'],sourceSHA256=case['sourceSha256'],fixtureSHA256=case['fixtureSha256'],inputBytes={name:len(base64.b64decode(value))for name,value in fixture['inputFiles'].items()},output=done.stdout,exactFiles=True),indent=2)+'\n',encoding='utf-8',newline='\n')
frozen=r.parent/'xml-iterparse-r335/candidate-identity.json'
source=json.loads(frozen.read_text(encoding='utf-8'))
assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==sha for p,sha in source['sources'].items())
aux=json.loads((r.parent/'xml-iterparse-r335/b706/identity.json').read_text(encoding='utf-8'))['candidateAuxiliaryFiles']
identity=dict(sourceRevision='Committedcdd92944/frozenf4c4f027; R335 full delivery running43536449801',purpose='Small complete config-edit compile/warm/compile-to-result phase selection, CPython3.13.16 controls. No new runtime prototype or general redesign claim.',coreSHA256={label:source['coreSHA256']['candidate']for label in ['reference','reference-control','candidate','candidate-control']},auxiliaryFiles=aux,catalogSHA256=hashlib.sha256((r/'catalog.json').read_bytes()).hexdigest(),sourceIdentitySHA256=hashlib.sha256(frozen.read_bytes()).hexdigest(),sourceAndScriptDifferIntentionally=False)
(r/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8',newline='\n')
oldroot='/home/lokad/lython-bench-checks/current-external-b704-20261113'
root='/home/lokad/lython-bench-checks/config-phases-b707-20261114'
unit='lython-b707-config-phases-20261114'
jobs=[[case['id'],lane]for lane in ['compile','warm','compile-run']]
for name in ['collect.py','archive-owned.py','run.sh','retrieve.py','summarize.py','launch.py']:
    s=(prior/name).read_text(encoding='utf-8').replace(oldroot,root).replace('lython-b704-current-external-20261113',unit).replace('B704','B707')
    for old,new in [("len(raw['jobs'])==7","len(raw['jobs'])==3"),("['jobs']==7","['jobs']==3"),('jobs=7','jobs=3')]:s=s.replace(old,new)
    if name=='collect.py':
        a=s.index('jobs=');b=s.index('\nenv =',a)
        s=s[:a]+'jobs='+repr(jobs)+'\nassert len(jobs)==3 and all(case in cases for case,lane in jobs)\n'+s[b:]
        s=s.replace('time.monotonic()-started < 300','time.monotonic()-started < 180')
    if name=='launch.py':
        s=s.replace("r.parent.parent/'dictionary-boundaries-r331/candidate-identity.json'","r.parent/'xml-iterparse-r335/candidate-identity.json'")
        s=s.replace('RuntimeMaxSec=360','RuntimeMaxSec=240').replace('timedelta(seconds=300)','timedelta(seconds=180)').replace('ownerSeconds=360','ownerSeconds=240')
        s=s.replace('lython-b704-fixtures','lython-b707-fixtures')
    if name=='retrieve.py':s=s.replace("['elapsedSeconds']<360","['elapsedSeconds']<240")
    if name.endswith('.py'):ast.parse(s)
    (r/name).write_text(s,encoding='utf-8',newline='\n')
with tarfile.open(r/'payload.tgz','w:gz')as t:
    for name in ['identity.json','collect.py','archive-owned.py','run.sh']:t.add(r/name,arcname=name)
    t.add(r/'catalog.json',arcname='representative.json')
with tarfile.open(r/'payload.tgz')as t:unpacked=sum(m.size for m in t.getmembers())
config=dict(root=root,sourceRoot='/home/lokad/lython-bench-checks/xml-iterparse-b706-20261114',unit=unit,identity=identity,payloadBytes=(r/'payload.tgz').stat().st_size,payloadSHA256=hashlib.sha256((r/'payload.tgz').read_bytes()).hexdigest(),unpackedBytes=unpacked)
(r/'config.json').write_text(json.dumps(config,indent=2)+'\n',encoding='utf-8',newline='\n')
print('Prepared three config phases from existing full catalog; exact current image reused without rebuild or repeated qualification.',flush=True)
