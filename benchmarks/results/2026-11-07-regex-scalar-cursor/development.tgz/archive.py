from pathlib import Path
import hashlib,json,shutil,subprocess,tarfile
r=Path(__file__).parent;repo=Path('D:/code/Lython');o=repo/'benchmarks/results/2026-11-07-regex-scalar-cursor';o.mkdir(exist_ok=True);b=r/'b392'
receipt=json.loads((b/'archive-receipt.json').read_text(encoding='utf-8'));assert receipt['complete'] and receipt['jobs']==5 and receipt['allWorkersJoined'] and receipt['archivedAndVerifiedUnderLease']
assert hashlib.sha256((b/'observations.tgz').read_bytes()).hexdigest()==receipt['archiveSHA256']
checks=json.loads((r/'focused-initial.json').read_text(encoding='utf-8'))
for tfm,digest in checks['coreSHA256'].items():assert hashlib.sha256((repo/f'src/Lokad.Lython/bin/Release/{tfm}/Lokad.Lython.dll').read_bytes()).hexdigest()==digest
def write(p,s):p.write_text(s,encoding='utf-8',newline='\n')
for name in ['observations.tgz','archive-receipt.json','terminal-status.json','identity.json','contract.md']:shutil.copyfile(b/name,o/name)
for name in ['comparison-summary.json','summary.json','focused-initial.json','active-cancellation.json','catalog-verification.json']:shutil.copyfile(r/name,o/name)
shutil.copyfile(repo/'src/Lokad.Lython/Runtime/LythonRuntime.RegexMatcher.cs',r/'final-RegexMatcher.cs')
shutil.copyfile(repo/'tests/Lokad.Lython.PublicApi.Tests/RegexScalarCursorTests.cs',r/'final-RegexScalarCursorTests.cs')
shutil.copyfile(repo/'tests/Lokad.Lython.Tests/RegexScalarCursorCancellationTests.cs',r/'final-RegexScalarCursorCancellationTests.cs')
write(r/'assembly-provenance.json',json.dumps({'beforeInformationalVersion':'0.11.0+79fddd4a389cc9710bfea39a5634a05ec045d358','candidateInformationalVersion':'0.11.0+3604f93589d1063adadf5b218b864f56eeecffe5','source':'Candidate built before R40 commit, b0889a46 production plus only RegexMatcher cursor change; later metadata commits do not rebuild or qualify it.'},indent=2)+'\n')
(r/'source.patch').write_bytes(subprocess.check_output(['git','diff','--','src/Lokad.Lython/Runtime/LythonRuntime.RegexMatcher.cs']))
with tarfile.open(o/'development.tgz','w:gz') as t:
 for p in sorted(r.rglob('*')):
  rel=p.relative_to(r)
  if not p.is_file() or any(part in rel.parts for part in ['bin','obj','out','images','baseline','b392']):continue
  if p.suffix in ['.py','.cs','.csproj','.props','.json','.jsonl','.log','.stderr','.txt','.md','.patch']:t.add(p,arcname=str(rel))
 for tfm in ['net11.0','net10.0']:
  t.add(r/f'baseline/{tfm}/Lokad.Lython.dll',arcname=f'baseline/{tfm}/Lokad.Lython.dll')
  t.add(repo/f'src/Lokad.Lython/bin/Release/{tfm}/Lokad.Lython.dll',arcname=f'candidate/{tfm}/Lokad.Lython.dll')
 t.add(r/'baseline/LythonRuntime.RegexMatcher.cs',arcname='baseline/LythonRuntime.RegexMatcher.cs')
with tarfile.open(o/'collection-commands.tgz','w:gz') as t:
 for p in b.iterdir():
  if p.is_file() and p.suffix in ['.py','.json','.md','.sh']:t.add(p,arcname=p.name)
write(o/'README.md','''# Unicode capture scalar cursor — R40

2026-11-07. Baseline fully qualified b0889a46/corec21c0c4b; candidateeb6052d0
(.NET11)/49f2de02(.NET10) changes only core scalar projection. Precommit image
SourceLink3604f935 versus baseline79fddd4a is recorded separately; frozen source/
images match the recorded production changes. The optional normal0.4 producer,
core provider contract and memory ownership are unchanged.

ProjectScalarBounds previously restarted at byte/scalar0 whenever a lookbehind
capture preceded the previous whole-match end. Consecutive nearby captures rescanned
growing prefixes. Seek from the nearer known byte boundary: retain origin for far
captures, otherwise decode backwards with the existing cursor, then project sorted
endpoints forwards. This removes the unconditional nearby-prefix restart. No dense
index/cache, pool, owner, policy, API or backend route. Existing capture validation,
leases, metadata arrays, original-subject/result ownership and first-refusal behavior
remain. Both scan directions check current cancellation; cursor publication stays
after successful projection. Arbitrary far captures can still require long walks;
this does not promise linear matching for every regex.

## Controlled complete diagnostic scripts

B392 uses the unchanged b94fa98c worker/host/normal PythonRe0.4, quiet AzureF4as_v7/
Ubuntu24.04.4/.NET11RC3, normal GC/tiering. Two baseline/two current processes,
5s warmup per role/job, seven rotated150ms rounds. Four source-pair combinations
are included in each change range; role differences are not confidence intervals.

| Workload | Baseline ms | Current ms | Elapsed change | Current/reference role spread |
| --- | ---: | ---: | ---: | ---: |
| Unicode lookbehind,1,024scalars |1.983–2.080|1.363|−34.50 to−31.28%|0.02/4.66%|
| Unicode lookbehind,4,096scalars |15.450–16.604|5.226–5.325|−68.53 to−65.54%|1.86/7.47%|
| Unicode lookbehind,8,192scalars |49.842–50.403|10.349–10.472|−79.47 to−78.99%|1.18/1.11%|
| ASCII lookbehind,8,192scalars |8.267–8.382|8.368–8.788|−0.16 to+6.31%|4.78/1.39%|
| Unicode forward captures,4,096scalars |2.359–2.424|2.342–2.429|−3.38 to+2.96%|3.70/2.69%|

Scripts construct their subject, iterate real backend captures and aggregate Python
scalar starts/ends with full checksum validation. No file I/O; the owned fixture is
empty. Elapsed includes public execution, actual backend/guest work, complete output/
file checks and prior-result cleanup. Compile/startup/staging/reset/final cached
teardown excluded. This is a growing-input diagnostic, not the primary representative
CPython comparison, isolated projection CPU or a general regex speedup. Controls
remain variable and possible ASCII overhead is accepted debt; neither parity nor
its cause is established. Retain the algorithmic change; no unchanged retiming.

All5jobs complete143.7459s. Ready/core/every auxiliary, goldens, terminal funding,
quiet endpoints, Closed/exit/joins, fixture removal and archive verification under
lease pass. Observe07:55:25UTC after07:55:07.649950bound(210+30+40s). Terminal
inactive/exit0/no users or fixtures; retrieved archive2a808f28 independently verified.
No more service queries. Raw process-CPU samples stay separate; no compound gains.

## Correctness, ownership and separate allocation

Focused Release853internal/1,224public pass per actual target. Four independent
CPython3.13.2 cases exercise consecutive lookbehind, lookahead/empty matches, real
substitution callbacks and original pos/endpos windows through both APIs. Six new
scaling/control scripts also pass supervised .NET/CPython verification. All script/
result cleanup returns shared funding to baseline and final zero.

An additional active-backward-scan test passes on each framework (183/188ms). It
warms the private projection entry and subject count, starts a substantial funded
scan, verifies its user remains active, then cancels. Structured current-token/span,
unpublished cursor, funding through actual joined completion and root reuse pass.
No provider or interpreter exit supplies that cancellation. The8M-scalar fixture
uses one admitted16MiB UTF8 buffer; no host string copy/GC forcing/checkpoint counter.
It joins even after assertion failure. Test-only builds use --no-dependencies;
frozen core hashes remain unchanged. The small result receipt transcribes tool
output without rerunning unchanged checks merely to capture a log.

Separate same-ALC/CoreLib/process-GC precise allocation is essentially flat; all
admitted peaks match. All six output/file/isolation/balance/fixture gates pass.
Desktop clocks are diagnostic:4,096input can be slower than8,192on the original,
consistent with unresolved tiering/process effects, not a scaling proof. Preserve
all raw medians, non-monotonic/adverse conditions and original source/images; no
desktop CPU claim or subtraction/combination of unrelated phase medians.

R36/R38 full delivery42351006316 is green and excludes R40. Batch R40 full platform/
original Stress/installed-package qualification at the next coherent delivery
boundary; focused/VM checks do not replace it. Publication remains postponed and
the larger complete-script performance objective continues.

[Controlled summary](comparison-summary.json), [raw capture/gates](observations.tgz),
[allocation/desktop observations](summary.json), [focused checks](focused-initial.json),
[active cancellation](active-cancellation.json), [supervised semantics](catalog-verification.json),
[source/images/all development conditions](development.tgz), [commands](collection-commands.tgz).
''')
p=repo/'.gitattributes';s=p.read_text(encoding='utf-8');s+='\n# Preserve the Unicode scalar-cursor source pair, controls and validation.\nbenchmarks/results/2026-11-07-regex-scalar-cursor/** -text whitespace=cr-at-eol\n';write(p,s)
p=repo/'CHANGELOG.md';s=p.read_text(encoding='utf-8');s=s.replace('## 0.11.0 - Unreleased\n','''## 0.11.0 - Unreleased

- Avoid repeated Unicode prefix scans for nearby overlapping regex captures by
  moving the existing scalar cursor backwards when nearer. Preserve original
  capture coordinates, current cancellation and subject/result ownership.
''',1);write(p,s)
p=repo/'docs/RUNTIME.md';s=p.read_text(encoding='utf-8');mark='Python matches retain immutable byte/scalar ranges and their original funded\n';insert='''Unicode scalar projection carries one cursor across matches and seeks from the
nearer known byte boundary for lookbehind captures. Forward and backward scans
observe current cancellation; no dense coordinate index is retained. Arbitrary
far captures can still require long walks.

''';s=s.replace(mark,insert+mark,1);write(p,s)
p=repo/'tests/README.md';s=p.read_text(encoding='utf-8');mark='## Test responsibilities\n';s=s.replace(mark,mark+'''
[Regex scalar positions](Lokad.Lython.PublicApi.Tests/RegexScalarCursorTests.cs)
check consecutive Unicode lookbehind/lookahead, callbacks and original windows
against independent Python output. [Active projection cancellation](Lokad.Lython.Tests/RegexScalarCursorCancellationTests.cs)
keeps its subject/captures funded until the scan actually ends, preserves the
unpublished cursor on cancellation and verifies shared-budget reuse.
''',1);write(p,s)
p=repo/'docs/BENCHMARKS.md';s=p.read_text(encoding='utf-8');mark='| Demand-bound annotation analysis / compilation |';row='''| Unicode lookbehind / scalar positions;8,192constructed characters | Warm elapsed −78.99–79.47% versusb0889a46, about50ms→10.4ms with the same optional0.4 backend | Growing-input diagnostic; allocation essentially flat. ASCII/forward controls variable, possible ASCII debt up to+6.31%. Focused/VM checks pass; full delivery pending. [R40](../benchmarks/results/2026-11-07-regex-scalar-cursor/README.md) |
''';s=s.replace(mark,row+mark,1).replace('including R36/R38','including R36/R38/R40');write(p,s)
p=repo/'benchmarks/EXPERIMENTS.md';s=p.read_text(encoding='utf-8');s+='''

## R40 Unicode capture scalar cursor — B392

[R40](results/2026-11-07-regex-scalar-cursor/README.md) replaces unconditional
origin restarts for nearby lookbehind with the existing bidirectional scalar
cursor, preserving origin when nearer and all leases/owners/validation. B392
completes143.75s/all5gates: Unicode1,024−31.28–34.50%,4,096−65.54–68.53%,
8,192−78.99–79.47% elapsed versusb0889a46 with normal0.4 unchanged. These complete
growing-input scripts include backend/guest work, not isolated projection CPU or
the primary CPython table. ASCII−0.16 to+6.31%/4.78%current spread and forward
−3.38 to+2.96% remain variable; possible ASCII debt accepted, no parity/cause claim.
Allocation essentially flat/peaks identical; desktop non-monotonic clocks retained.
853internal/1,224public per actual target plus one active cancellation/owner test
each and six supervised .NET/CPython cases pass. Full R40 delivery is batched later;
the green R36/R38 receipt excludes it. No retiming, publication or goal completion.
''';write(p,s)
print('R40 retained source, immutable evidence and current documentation prepared.')
