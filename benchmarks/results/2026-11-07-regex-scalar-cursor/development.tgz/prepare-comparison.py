from pathlib import Path
import ast
r=Path(__file__).parent
s=(r.parent/'annotation-demand-r38/prepare-comparison.py').read_text(encoding='utf-8-sig')
s=s.replace("home/'b389'","home/'b392'").replace('annotation-demand-b389-20261107','regex-scalar-cursor-b392-20261107')
s=s.replace("home/'identity-before.json'","home/'before.json'")
s=s.replace("'79fddd4a plus R38 annotation demand; frozen'","'b0889a46 plus R40 scalar cursor; frozen'").replace("'committed/focused79fddd4a; frozen'","'fully qualified b0889a46 production; frozen'")
s=s.replace('R38 demand-bound conservative annotation flow; report/text compile, config fresh, unchanged text warm and full-flow regex compile controls; two baseline/two current','R40 native Unicode lookbehind scaling with ASCII/forward controls; two baseline/two current')
s=s.replace("diagnosticDifferential=dict(cases=524,identical=524,providerRoles=['normal optional0.4','missing']),","semanticVerification='Six .NET/CPython cases, four independent byte/scalar/window/callback probes on both APIs, actual11/10 focused853internal/1224public pass; new-scan cancellation still pending',")
s=s.replace('src/Lokad.Lython/Frontend/AnnotationDiagnostics.cs','src/Lokad.Lython/Runtime/LythonRuntime.RegexMatcher.cs')
a=s.index('jobs=');b=s.index('\ncollect=',a)
jobs=[('diagnostic.regex.unicode-lookbehind-1024','warm'),('diagnostic.regex.unicode-lookbehind-4096','warm'),('diagnostic.regex.unicode-lookbehind-8192','warm'),('diagnostic.regex.ascii-lookbehind-8192','warm'),('diagnostic.regex.unicode-forward-4096','warm')]
s=s[:a]+'jobs='+repr(jobs)+s[b:]
a=s.index("contract='''");b=s.index("'''\n(root/'contract.md')",a)
contract='''R40 changes only core scalar projection: use the existing cursor bidirectionally, starting at byte0 when nearer and otherwise decoding backwards to validated capture boundaries. Nearby overlapping lookbehind no longer rescans every growing prefix; no general linear-regex guarantee for arbitrary far captures. Retain all range validation, capture leases/metadata arrays/result/subject ownership and current cancellation/terminal refusal. No provider/API/adapter change, dense index, pool, new owner or quota. Focused853internal/1224public per actual11/10 and independent Python probes pass; six supervised .NET/CPython scaling/control cases agree. New-loop cancellation validation remains pending, so this comparison alone does not finish retention/delivery. Before images/source/raw desktop conditions preserved. Desktop growing-input gains are diagnostic with non-monotonic timings; allocations essentially flat and all admitted peaks unchanged. Five warm jobs: Unicode nearest-lookbehind1024/4096/8192 scalars, ASCII8192 and forward Unicode4096 controls. Both source roles use identical frozenb94 worker/host/normal optional0.4, ordinary .NET11RC3 GC/tiering on quiet AzureF4as_v7/Ubuntu24.04.4.5s warmup per role/job, seven rotated150ms rounds, two baseline/two current processes. Timed complete public runs include subject construction, actual backend matching, guest span/checksum work, full output/file checks and prior-result cleanup; no file I/O, empty owned fixture. Compile/startup/staging/reset/final cached teardown excluded. Not isolated projection CPU, a representative CPython refresh or broad regex performance claim. Require Ready/source/aux/golden/funding/quiet/Closed/joins/fixture/archive gates.210s owner+30s stop+40s margin; observe after280s, no early query/restart. Keep all adverse/variable conditions; no fixed improvement veto. R36/R38 delivery42351006316 is green and excludes R40. Publication postponed; substantial whole-script objective remains active.'''
s=s[:a]+"contract='''"+contract+s[b:]
s=s.replace('lython-b389-annotation-demand-20261107','lython-b392-regex-scalar-cursor-20261107').replace('annotation-demand-b389-launch.py','regex-scalar-cursor-b392-launch.py')
s=s.replace("/\'b389\'","/\'b392\'").replace('retrieve-b389.py','retrieve-b392.py')
s=s.replace("root=Path(__file__).parent/","root=Path(__file__).resolve().parent/")
ast.parse(s);(r/'prepare-comparison-expanded.py').write_text(s,encoding='utf-8',newline='\n')
exec(compile(s,str(r/'prepare-comparison-expanded.py'),'exec'))
