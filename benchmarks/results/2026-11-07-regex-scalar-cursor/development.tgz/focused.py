from pathlib import Path
r=Path(__file__).parent
s=(r.parent/'cold-string-hash-r33/focused.py').read_text(encoding='utf-8-sig')
families=['Regex','SharedMemory','Admission','Cancellation','Projection','InstructionFailure','NativeHash','Structural']
a=s.index('families=');b=s.index('\nselection=',a);s=s[:a]+'families='+repr(families)+s[b:]
exec(compile(s,str(r/'focused-expanded.py'),'exec'))
