from pathlib import Path
import copy,hashlib,json,shutil
r=Path(__file__).parent;prior=r.parent/'annotation-demand-r38';tool=r/'tool';tool.mkdir(exist_ok=True)
for name in ['Directory.Build.props','complete-jobs.csproj']:shutil.copyfile(prior/'tool'/name,tool/name)
s=(prior/'tool/Program.cs').read_text(encoding='utf-8-sig').replace('Require the existing five scripts and regex compile control.','Require four Unicode scaling cases and ASCII/forward controls.').replace('R38 annotation demand diagnostic','R40 scalar projection diagnostic')
s=s.replace('var warmups = phase == "warm" ? 32 : 32;','var warmups = 4;').replace('var batch = 16;','var batch = 1;')
(tool/'Program.cs').write_text(s,encoding='utf-8',newline='\n')
catalog=json.loads((prior/'catalog.json').read_text(encoding='utf-8'));template=next(c for c in catalog['cases'] if c['id']=='scripts.regex-capture-summary.large')
cases=[]
for name,n,char,pattern,expected in [(f'unicode-lookbehind-{n}',n,'α',r'(?<=(..))(.)',n*(n-2)) for n in [256,1024,4096,8192]]+[
 ('ascii-lookbehind-8192',8192,'a',r'(?<=(..))(.)',8192*(8192-2)),
 ('unicode-forward-4096',4096,'α',r'(.)(.)',4096*4096//2)]:
 c=copy.deepcopy(template);c['id']='diagnostic.regex.'+name;c['family']='regex-scalar-cursor';c['category']='diagnostic';c['size']=n
 c['source']=f"import re\ntext={char!r}*{n}\nchecksum=0\nfor match in re.finditer({pattern!r},text):\n checksum+=match.start(1)+match.end(2)\nprint(checksum)\n"
 c['fixtureJson']=json.dumps(dict(size=n,text=None,inputFiles={},outputFiles={}),ensure_ascii=False,separators=(',',':'))
 c['expectedOutput']=str(expected)+'\n'
 for field,value in [('source',c['source']),('expectedOutput',c['expectedOutput'])]:
  c[field+'Utf8Bytes']=len(value.encode('utf-8'));c[field+'Sha256']=hashlib.sha256(value.encode('utf-8')).hexdigest()
 c['fixtureSha256']=hashlib.sha256(c['fixtureJson'].encode('utf-8')).hexdigest();c['fixtureTextUtf8Bytes']=0;c['fixtureTextCodePoints']=0;c['expectedFilesSha256']=hashlib.sha256(bytes(4)).hexdigest()
 cases.append(c)
catalog['cases']=cases;(r/'catalog.json').write_text(json.dumps(catalog,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
s=(prior/'measure.py').read_text(encoding='utf-8-sig').replace("root/'identity-before.json'","root/'before.json'")
s=s.replace('five representative scripts and existing regex control','normal0.4 Unicode lookbehind scaling plus ASCII/forward controls').replace("for phase in ['compile','warm','fresh']:","for phase in ['warm']:")
(r/'measure.py').write_text(s,encoding='utf-8',newline='\n')
s=(prior/'summarize.py').read_text(encoding='utf-8-sig').replace("['compile','warm','fresh']","['warm']")
(r/'summarize.py').write_text(s,encoding='utf-8',newline='\n')
verify=(r.parent/'canonical-formatted-instructions-r35/verify-catalog.py').read_text(encoding='utf-8-sig').replace('all four cases','all six scaling/control cases')
(r/'verify-catalog.py').write_text(verify,encoding='utf-8',newline='\n')
p=Path('PLAN.md');s=p.read_text(encoding='utf-8');s=s.replace('before/after at growing inputs with a cooperating provider separates core projection\nfrom actual backend matching. Separately check normal0.4 semantics/performance;', 'before/after at growing inputs holds normal0.4 matching constant, with ASCII and\nforward-capture controls. Clocks include actual backend/guest work, not isolated\nprojection CPU. Use a cooperating provider only if a specific isolation/cancellation\nfact remains missing; existing contract/unwind tests remain independent.')
p.write_text(s,encoding='utf-8',newline='\n')
print('Existing short driver: four growing-input jobs, ASCII/forward controls, same normal0.4 producer; no new framework.')
