from pathlib import Path
import hashlib,json,shutil
r=Path(__file__).parent;repo=Path('D:/code/Lython');b=r/'baseline';b.mkdir(exist_ok=True)
source=repo/'src/Lokad.Lython/Runtime/LythonRuntime.RegexMatcher.cs';shutil.copyfile(source,b/source.name)
images={}
for tfm,expected in [('net11.0','c21c0c4b3537c731d76fe5f96afb0c8f13f2c99a8335e09902c2f4c29a1e7fea'),('net10.0','deb66c945e0d1c21cb0657ac01f1fce890750e1d09f1e120435984ada8fbe072')]:
 p=repo/f'src/Lokad.Lython/bin/Release/{tfm}/Lokad.Lython.dll';actual=hashlib.sha256(p.read_bytes()).hexdigest();assert actual==expected
 dest=b/tfm;dest.mkdir(exist_ok=True);shutil.copyfile(p,dest/p.name);images[tfm]=actual
(r/'before.json').write_text(json.dumps({'source':'b0889a46; metadata HEAD3604f935','coreSHA256':images,'modifiedSourceSHA256':hashlib.sha256(source.read_bytes()).hexdigest()},indent=2)+'\n',encoding='utf-8',newline='\n')
sources=json.loads((r/'sources.json').read_text(encoding='utf-8'));rows=[json.loads(l) for l in (r/'before-sync.jsonl').read_text(encoding='utf-8').splitlines()]
assert len(rows)==len(sources)==4 and all(x['Matches'] and x['Compared'] for x in rows)
entries='\n'.join('        { '+json.dumps(s,ensure_ascii=False)+', '+json.dumps(x['CPython']['StandardOutput'],ensure_ascii=False)+' },' for s,x in zip(sources,rows))
test='''using Lokad.Lython.Tests.Harness;

namespace Lokad.Lython.PublicApi.Tests;

public sealed class RegexScalarCursorTests
{
    // Independently compared with isolated CPython 3.13.2.
    public static TheoryData<string, string> Cases => new()
    {
ENTRIES
    };

    [Theory]
    [MemberData(nameof(Cases))]
    public async Task OverlappingLookbehindAndLookaheadKeepOriginalScalarPositions(string source, string expected)
    {
        var budget = new LythonMemoryBudget(2 * 1024 * 1024);
        using var script = new LythonEngine(Utf8RegexProvider.Instance).Compile(source, budget);
        Assert.True(script.IsValid, string.Join(" | ", script.Diagnostics.Select(d => d.Message)));
        var baseline = budget.ReservedBytes;
        foreach (var asynchronous in new[] { false, true })
        {
            using (var result = asynchronous ? await script.RunAsync(new MockLythonHost()) : script.Run(new MockLythonHost()))
            {
                Assert.True(result.Success, result.Failure?.Message);
                Assert.Equal(expected, result.StandardOutput);
            }
            Assert.Equal(baseline, budget.ReservedBytes);
        }
        script.Dispose();
        Assert.Equal(0, budget.ReservedBytes);
    }
}
'''.replace('ENTRIES',entries)
(repo/'tests/Lokad.Lython.PublicApi.Tests/RegexScalarCursorTests.cs').write_text(test,encoding='utf-8',newline='\n')
p=repo/'PLAN.md';s=p.read_text(encoding='utf-8');mark='## Priority 2 — independent regex architecture\n';text='''
**R40 active core projection milestone:** source-proved repeated-prefix cost in
ProjectScalarBounds: any capture before the previous whole-match end resets the
Unicode cursor to byte/scalar0. Consecutive nearby fixed lookbehind therefore
rescans growing prefixes. Four baseline CPython probes (eight API comparisons)
agree on semantics: lookbehind, lookahead/empty matches, callbacks and original
pos/endpos windows. This is not yet a measured speedup or backend attribution.

Use the existing scalar cursor bidirectionally, seeking from byte0 when that is
closer and otherwise decoding backwards to the validated scalar boundary. Remove
unconditional origin restarts for nearby captures; preserve the origin choice for
far captures to avoid trading one large scan for two. No dense map/cache, pool,
provider API, adapter pin or memory-management layer. Retain all current capture
leases, range validation, effect order and result/subject owners. Allocation should
remain flat. Add current-token/first-refusal checks in the new nonallocating rewind.

Acceptance: independent Python/reg/coordinate semantics, retained aliases and
cleanup/refusal, actual in-flight cancellation on the new scan; short bounded
before/after at growing inputs with a cooperating provider separates core projection
from actual backend matching. Separately check normal0.4 semantics/performance;
no producer release gate. Record all adverse controls. Nearby fixed-width scans
should avoid repeated prefixes; make no general linear-regex/large-prefix guarantee.
Stop after a coherent cursor change, focused checks and bounded comparison, then
continue the substantial non-regex roadmap while R36/R38 delivery runs separately.

''';s=s.replace(mark,mark+text,1)
s=s.replace('B390 CSV cost capture owns120+30+30s through07:31:21.464121UTC; do not observe\nearlier or restart on observation timeout.','B390 failed before worker startup (tuple environment key); original archive\nverified and RAM/users cleaned. B391 corrects only that setup entry and owns\n120+30+30s through07:36:11.836724UTC. No early observation or restart on timeout.')
s=s.replace('No local tests or measurements running. Publication\npostponed.','R40 source/images preserved before prototype; local focused checks next.\nPublication postponed.')
p.write_text(s,encoding='utf-8',newline='\n')
print('R40 source/images saved, semantic fixtures and bounded design recorded.')
