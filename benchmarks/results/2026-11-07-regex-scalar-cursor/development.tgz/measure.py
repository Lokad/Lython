from pathlib import Path
import hashlib,json,os,shutil,subprocess
root=Path(__file__).parent
env=os.environ.copy();env['DOTNET_ROOT']='C:/Users/JoannesVermorel/.dotnet11';env['DOTNET_HOST_PATH']=env['DOTNET_ROOT']+'/dotnet.exe';env['PATH']=env['DOTNET_ROOT']+os.pathsep+'C:/Python313'+os.pathsep+env['PATH']
with (root/'build-diagnostic.log').open('w',encoding='utf-8') as output:
    result=subprocess.run([env['DOTNET_HOST_PATH'],'build',str(root/'tool/complete-jobs.csproj'),'-c','Release','--nologo','--tl:off','-o',str(root/'tool/out')],env=env,stdout=output,stderr=subprocess.STDOUT)
assert result.returncode==0,(root/'build-diagnostic.log').read_text(encoding='utf-8')[-3000:]
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
baseline=root/'baseline/net11.0/Lokad.Lython.dll'
candidate=Path('src/Lokad.Lython/bin/Release/net11.0/Lokad.Lython.dll')
checks=json.loads((root/'focused-initial.json').read_text(encoding='utf-8'))
assert sha(baseline)==json.loads((root/'before.json').read_text(encoding='utf-8'))['coreSHA256']['net11.0']
assert sha(candidate)==checks['coreSHA256']['net11.0']
aux=Path('benchmarks/Lokad.Lython.Benchmarks/bin/Release/net11.0');images=root/'images';images.mkdir()
for role,core in [('before',baseline),('candidate',candidate)]:
    target=images/role;target.mkdir()
    for file in aux.iterdir():
        if file.is_dir():shutil.copytree(file,target/file.name)
        elif file.suffix!='.pdb':shutil.copy2(core if file.name=='Lokad.Lython.dll' else file,target/file.name)
    assert sha(target/'Lokad.Lython.dll')==sha(core)
(root/'diagnostic-identity.json').write_text(json.dumps(dict(coreSHA256=dict(before=sha(baseline),candidate=sha(candidate)),
    toolSHA256=sha(root/'tool/out/complete-jobs.dll'),catalogSHA256=sha(root/'catalog.json'),
    boundary='Existing complete-job driver; normal0.4 Unicode lookbehind scaling plus ASCII/forward controls. Compile/program disposal separate from warm execution/reset/I/O/goldens/prior-result disposal; startup excluded. Process allocation precise, desktop clocks not quiet-machine performance proof. Normal GC/tiering; no forced collection.'),indent=2)+'\n',encoding='utf-8',newline='\n')
for phase in ['warm']:
    folder=root/phase;folder.mkdir()
    witness=folder/'hash-witness.json';witness.write_text(json.dumps(dict(source="return [hash('Lython-é😀'), hash((1, 2.0, True))]\n"),ensure_ascii=False)+'\n',encoding='utf-8',newline='\n')
    with (folder/'measurements.json').open('w',encoding='utf-8') as output,(folder/'stderr.txt').open('w',encoding='utf-8') as errors:
        result=subprocess.run([env['DOTNET_HOST_PATH'],str(root/'tool/out/complete-jobs.dll'),str(images/'before/Lokad.Lython.Benchmarks.dll'),
                               str(images/'candidate/Lokad.Lython.Benchmarks.dll'),str(root/'catalog.json'),str(witness),'reverse',phase,'sync'],env=env,stdout=output,stderr=errors)
    assert result.returncode==0,(folder/'stderr.txt').read_text(encoding='utf-8')[-3000:]
    data=json.loads((folder/'measurements.json').read_text(encoding='utf-8'))
    assert all(data[k] for k in ['allGoldensPassed','allBalancesZero','ownedFixturesRemoved','imageIsolationVerified'])
    print(phase,'all output/file/ownership/isolation/fixture gates pass',flush=True)
