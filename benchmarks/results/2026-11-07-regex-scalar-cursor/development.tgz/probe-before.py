from pathlib import Path
import hashlib,json,os,subprocess
r=Path(__file__).parent
sources=[
 "import re\ntext='αβγδεζηθ'\nfor match in re.finditer(r'(?<=(..))(?P<value>.)',text):\n print(match.span(),match.span(1),match.group(1),match.group('value'))",
 "import re\ntext='aé😀bç🦊d'\np=re.compile(r'(?<=(..))(?=(..))')\nfor match in p.finditer(text):print(match.regs,match.groups())",
 "import re\ntext='αβγδεζηθ'\np=re.compile(r'(?<=(..))(.)')\nprint(p.sub(lambda m:repr((m.span(),m.span(1),m.groups())),text))",
 "import re\ntext='aé😀bç🦊d'\np=re.compile(r'(?<=(..))(.)')\nfor match in p.finditer(text,2,6):print(match.regs,match.pos,match.endpos,match.groups())",
]
(r/'sources.json').write_text(json.dumps(sources,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
core=Path('tools/LythonProbe/bin/Release/net11.0/Lokad.Lython.dll');digest=hashlib.sha256(core.read_bytes()).hexdigest();assert digest=='c21c0c4b3537c731d76fe5f96afb0c8f13f2c99a8335e09902c2f4c29a1e7fea'
env=os.environ.copy();env['DOTNET_ROOT']='C:/Users/JoannesVermorel/.dotnet11';env['PATH']=env['DOTNET_ROOT']+os.pathsep+env['PATH']
for asynchronous in [False,True]:
 args=[env['DOTNET_ROOT']+'/dotnet.exe','tools/LythonProbe/bin/Release/net11.0/LythonProbe.dll','--batch-json','--compare-python','--python','C:/Python313/python.exe']+(['--async'] if asynchronous else [])
 result=subprocess.run(args,input=json.dumps(sources),text=True,encoding='utf-8',env=env,capture_output=True,timeout=60)
 role='async' if asynchronous else 'sync'
 (r/f'before-{role}.jsonl').write_text(result.stdout,encoding='utf-8',newline='\n');(r/f'before-{role}.stderr').write_text(result.stderr,encoding='utf-8',newline='\n')
 print(role,'exit',result.returncode,flush=True)
 for line in result.stdout.splitlines():
  value=json.loads(line);print(json.dumps(value,ensure_ascii=False)[:1000],flush=True)
