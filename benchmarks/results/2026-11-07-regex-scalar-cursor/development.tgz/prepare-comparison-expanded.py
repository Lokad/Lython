from pathlib import Path
import ast,hashlib,json,shutil,subprocess,tarfile
home=Path(__file__).parent;root=home/'b392';root.mkdir(exist_ok=False)
old=home.parent/'canonical-formatted-instructions-r35/b386'
old_remote='/home/lokad/lython-bench-checks/canonical-format-instructions-b386-20261107'
remote='/home/lokad/lython-bench-checks/regex-scalar-cursor-b392-20261107'
checks=json.loads((home/'focused-initial.json').read_text(encoding='utf-8'))
before=json.loads((home/'before.json').read_text(encoding='utf-8'))
candidate=home/'images/candidate/Lokad.Lython.dll';reference=home/'baseline/net11.0/Lokad.Lython.dll'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(candidate)==checks['coreSHA256']['net11.0']
assert sha(reference)==before['coreSHA256']['net11.0']
aux=json.loads((home.parent/'report-cost-r34/identity.json').read_text(encoding='utf-8-sig'))['auxiliaryFiles']
identity=dict(sourceRevision='b0889a46 plus R40 scalar cursor; frozen'+sha(candidate),
 referenceSourceRevision='fully qualified b0889a46 production; frozen'+sha(reference),
 purpose='R40 native Unicode lookbehind scaling with ASCII/forward controls; two baseline/two current',
 qualification=checks,semanticVerification='Six .NET/CPython cases, four independent byte/scalar/window/callback probes on both APIs, actual11/10 focused853internal/1224public pass; new-scan cancellation still pending',
 coreSHA256=dict(candidate=sha(candidate),control=sha(candidate),reference=sha(reference),**{'reference-control':sha(reference)}),
 auxiliaryFiles=aux,modifiedSourceSHA256={'src/Lokad.Lython/Runtime/LythonRuntime.RegexMatcher.cs':sha(Path('src/Lokad.Lython/Runtime/LythonRuntime.RegexMatcher.cs'))})
(root/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8',newline='\n')
shutil.copyfile(home/'catalog.json',root/'representative.json');shutil.copyfile('PLAN.md',root/'pre-measurement-plan.md')
jobs=[('diagnostic.regex.unicode-lookbehind-1024', 'warm'), ('diagnostic.regex.unicode-lookbehind-4096', 'warm'), ('diagnostic.regex.unicode-lookbehind-8192', 'warm'), ('diagnostic.regex.ascii-lookbehind-8192', 'warm'), ('diagnostic.regex.unicode-forward-4096', 'warm')]
collect=(old/'collect.py').read_text(encoding='utf-8-sig').replace(old_remote,remote)
a=collect.index('jobs=');b=collect.index('\nenv =',a)
collect=collect[:a]+'jobs='+repr(jobs)+'\nassert len(jobs)==5 and all(case in cases for case,lane in jobs)\n'+collect[b:]
(root/'collect.py').write_text(collect,encoding='utf-8',newline='\n')
for name in ['archive-owned.py','run.sh']:(root/name).write_text((old/name).read_text(encoding='utf-8-sig').replace(old_remote,remote),encoding='utf-8',newline='\n')
contract='''R40 changes only core scalar projection: use the existing cursor bidirectionally, starting at byte0 when nearer and otherwise decoding backwards to validated capture boundaries. Nearby overlapping lookbehind no longer rescans every growing prefix; no general linear-regex guarantee for arbitrary far captures. Retain all range validation, capture leases/metadata arrays/result/subject ownership and current cancellation/terminal refusal. No provider/API/adapter change, dense index, pool, new owner or quota. Focused853internal/1224public per actual11/10 and independent Python probes pass; six supervised .NET/CPython scaling/control cases agree. New-loop cancellation validation remains pending, so this comparison alone does not finish retention/delivery. Before images/source/raw desktop conditions preserved. Desktop growing-input gains are diagnostic with non-monotonic timings; allocations essentially flat and all admitted peaks unchanged. Five warm jobs: Unicode nearest-lookbehind1024/4096/8192 scalars, ASCII8192 and forward Unicode4096 controls. Both source roles use identical frozenb94 worker/host/normal optional0.4, ordinary .NET11RC3 GC/tiering on quiet AzureF4as_v7/Ubuntu24.04.4.5s warmup per role/job, seven rotated150ms rounds, two baseline/two current processes. Timed complete public runs include subject construction, actual backend matching, guest span/checksum work, full output/file checks and prior-result cleanup; no file I/O, empty owned fixture. Compile/startup/staging/reset/final cached teardown excluded. Not isolated projection CPU, a representative CPython refresh or broad regex performance claim. Require Ready/source/aux/golden/funding/quiet/Closed/joins/fixture/archive gates.210s owner+30s stop+40s margin; observe after280s, no early query/restart. Keep all adverse/variable conditions; no fixed improvement veto. R36/R38 delivery42351006316 is green and excludes R40. Publication postponed; substantial whole-script objective remains active.'''
(root/'contract.md').write_text(contract+'\n',encoding='utf-8',newline='\n')
(root/'setup-contract.json').write_text(json.dumps(dict(referenceTemplate='/home/lokad/lython-bench-checks/delivery-comparison-b388-20261107/candidate',roles=['candidate','reference','control','reference-control'],ownerSeconds=210,stopSeconds=30,observeAfterSeconds=280,jobs=jobs),indent=2)+'\n',encoding='utf-8',newline='\n')
(root/'source.patch').write_bytes(subprocess.check_output(['git','diff','--','src','tests/Lokad.Lython.PublicApi.Tests/AnnotationFlowBoundaryTests.cs']))
for name in ['collect.py','archive-owned.py']:ast.parse((root/name).read_text(encoding='utf-8'))
with tarfile.open(root/'payload.tgz','w:gz') as t:
 for name in ['identity.json','representative.json','collect.py','archive-owned.py','run.sh','contract.md','pre-measurement-plan.md','setup-contract.json','source.patch']:t.add(root/name,arcname=name)
 t.add(candidate,arcname='current-core.dll');t.add(reference,arcname='baseline-core.dll')
launch=(old/'launch.py').read_text(encoding='utf-8-sig').replace('canonical-format-instructions-b386-20261107','regex-scalar-cursor-b392-20261107').replace('report-cost-b385-20261107/candidate','delivery-comparison-b388-20261107/candidate').replace('lython-b386-canonical-format-20261107','lython-b392-regex-scalar-cursor-20261107').replace('canonical-format-b386-launch.py','regex-scalar-cursor-b392-launch.py')
launch=launch.replace(" (root/'reference').symlink_to(reference,target_is_directory=True)"," shutil.copytree(reference,root/'reference',symlinks=True,copy_function=os.link)\n (root/'reference/Lokad.Lython.dll').unlink()\n (root/'baseline-core.dll').replace(root/'reference/Lokad.Lython.dll')")
assert 'symlink_to(reference' not in launch
ast.parse(launch);(root/'launch.py').write_text(launch,encoding='utf-8',newline='\n')
retrieve=(home.parent/'canonical-formatted-instructions-r35/retrieve-b387.py').read_text(encoding='utf-8-sig')
retrieve=retrieve.replace("root=Path(__file__).resolve().parent/'b387'","root=Path(__file__).resolve().parent/'b392'").replace('canonical-format-instructions-b387-20261107','regex-scalar-cursor-b392-20261107').replace('lython-b387-canonical-format-20261107','lython-b392-regex-scalar-cursor-20261107')
assert "root=Path(__file__).resolve().parent/'b392'" in retrieve
(home/'retrieve-b392.py').write_text(retrieve,encoding='utf-8',newline='\n')
print('Prepared five existing jobs, two verified source images; no collection started.')
