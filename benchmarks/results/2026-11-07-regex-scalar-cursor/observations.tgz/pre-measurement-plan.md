# Lokad.Lython 0.11.0

Updated 2026-11-07. Git-ignored: never force-add. Publication/tagging postponed.
Objective: coherent simplification and substantial complete-script performance.
Completion of one experiment/checkpoint does not complete that objective.

## Actual delivery status

- **Fully qualified:** R35 exact42101cd5, terminal GREEN42347124351: Windows/
  Ubuntu Release, ordinary actual.NET11/10, original Stress both targets and
  installed-package consumers. Includes R30 class facts, R31 shared parameter
  layouts, R32 canonical parameter prefix, R33 current-token native hashing and
  the corrected5000-definition shared-layout stress contract. No repeat queries.
  R35 removes the generic formatting detour/four wrapper records; dynamic native
  specs avoid contexts, real protocols promote/await, transient values retain the
  helper lifetime fence. Focused203internal/1,141public per target plus independent
  Python/ownership checks. Full receipt and representative B388 committed dab4774b.
- **Fully qualified within b0889a46:** R36 root identity79fddd4a. User classes named
  object/type now retain normal attributes/instances; original builtin aliases
  stay immutable. Delete display-name root heuristics using existing graph facts,
  no new cache/flag/owner.986internal/2,765public per actual target, eight isolated
  Python goldens/both APIs, balance/reuse pass. R36/R38 terminal GREEN42351006316 includes full Windows/Ubuntu actual11/10,
  original Stress and installed consumers; R35 receipt remains historical. No performance claim.
- **Committed/focused R38 b0889a46:** demand-bound annotation dataflow; baseline
  79fddd4a/images preserved.919internal/2,015public per actual target and524/524
  diagnostic cases pass. Compile allocation−4.38–8.94%, regex+304B/+0.117%; warm
  essentially flat. B389 completes140.29s/all5gates: report compile−6.51–8.02%, text compile−8.25–9.13%,
  config fresh−0.54–2.42%. Warm text inconclusive; regex up to+1.66% accepted
  possible overhead. Retained and fully qualified: terminal GREEN42351006316 onb0889a46,
  all required platform/runtime/Stress/package gates. Receipt committed; no requery. R37 call transport is not selected: native slices already borrow storage;
  removing adjacent loads alone adds snapshot/span metadata without deleting it.
- **Independent regex:** immutabledev48/sourcef6b2175e passed85internal/488public
  per actual target on R30 consumer. Normal adapter remains nonpackable/pinned0.4;
  core decoupled. This is neither current-HEAD nor final producer certification.
- **History separate:** benchmarks/EXPERIMENTS.md and immutable results retain
  original failed/withdrawn sources, controls and adverse observations. R28 windows/
  mask withdrawn; slower call-arena/control lessons remain. R36 unsupported fixture
  and masked probe preserved; supported type-subclass fixture corrects the test.

## Established measurements and uncertainty

| Milestone | Established outcome | Limit / decision |
| --- | --- | --- |
| Shared compiler-fact correction | Shared inferred-value traversal fixes exponential work; qualified | Preserve callback correction; no warm CPU claim. |
| Native helper returns | Full qualification; allocation−19.92/−19.31% | Earlier elapsed improvements diagnostic, not current-HEAD gains. |
| Direct UTF8 formatting/storage | Allocation−8.67%; controlled B102 elapsed/CPU−5–8% supports retain | Original adverse15.125ms remains unexplained/preserved. |
| R20/R25 record construction | Shared keys/independent values; completed CSV arrays transferred. R25 allocation−7.31/−6.55%, native warm−7.72–8.04% | Selectively revisits old6–8% bulk rejection with coherent transfer. Coarse CPU/text controls mixed. |
| R29 completed calls | Synthetic pause/completion deleted; text warm−4.25–7.61%sync/−7.63–8.64%async vsR26 | Allocation flat; report/CSV uncertainty and prior debt remain. |
| R30–R32 shared facts/layouts | Repeated class/parameter analysis/storage removed; qualified | Class allocation/time improve; compilation storage grows. Prior moving text/CSV controls and adverse pairings remain debt. |
| R33 hashing | Current token reaches4096-byte str/bytes scans, caches do not retain callers | Short primitive allocation flat, no CPU claim. |
| R35 direct formatting | Dynamic-width complete report warm allocation~−15.35%both APIs; quiet elapsed−10.09–13.19% | Static warm favorable, fresh/text variable; CSV+0.13–2.36% accepted possible debt. Original B386/refinement retained; no broad CPU/compound claim. |

**Current representative CPython checkpoint:** B388/exact42101cd5/frozen6ab7367f,
before R36. All15jobs311.96s/all gates, source/full delivery verified. Primary
docs/BENCHMARKS.md refreshed; previous B380/source81036f25 remains immutable.
Warm CSV1.20x,text1.67–1.75x,JSON1.02–1.04x,report1.40–1.42x,config1.26x CPython.
Compile45–75us separate; fresh CSV1.23–1.30x,text1.70x,report1.34–1.41x. Most
cases variable: text4.87% warm role spread, report6.18%IQR, CSV5.20%fresh spread.
Includes mediated RAM I/O, complete checks and prior-result cleanup; fresh adds
compile/program disposal. Excludes startup/staging/reset/final cached teardown.
No median subtraction, per-change causal attribution or algebraic debt repayment.
Startup, genuinely pending I/O, heap/RSS and embedding tails remain unmeasured.

## Priority 1 — substantial execution/storage milestone

Use complete text/CSV/JSON/report/config/file scripts, including new compile-once/
run-once scripts inside a warm host. Preserve compile/warm/fresh clock boundaries;
keep mediated I/O/check/cleanup inclusion explicit. Existing profiles before new
captures; source-select actual removable work/storage, not stale review claims.

**Current evidence/source gate:** R34 report916guest samples/4.62CPU seconds,
63unknown. Formatting241inclusive/37self partly addressed by R35; JSON220inclusive/
25self and ReadJsonString50self remain. BeginPendingCall441inclusive/10self includes
useful helper execution, not demonstrated binding dominance. Earlier text-prefix
21% includes inlined work; addition~3% and calls~2% alone do not justify universal
value/frame rewrites. Existing source already has direct native calls/receiver
dispatch, final local/operand backing, lazy contexts, result forwarding, bulk casing/
split, synchronous completed JSON, direct small-number parsing and native key reuse.
R36 setup gate finds fixed functions/signatures already shared; broader type-graph
sharing needs descriptor/isolation/owner proof and current cost evidence.

| Selected design boundary | Hypothesis / displaced work to establish | Affected scripts / acceptance |
| --- | --- | --- |
| Text/operand transport, first | Resolve the remaining text-prefix cost before changing representation. Select a whole transport/publication phase if material; do not revive general windows solely from allocation shares. | Text/helpers and report; Unicode width/expansion, identity/aliases, exception/effect order, managed stack, actual suspension, current cancellation, funded input/results. |
| Per-record JSON construction | Check whether another capacity/copy/publication phase remains after shared keys and completed CSV values. Existing SetRecordItem already fills matching prefixes directly; ordinary completed parsing is synchronous. Delete a demonstrated intermediate rather than add another key cache. | JSON/report/CSV controls; duplicates/order, escaped names, nested hooks, reentry, independent values, aliases, retained capacity/replacement admission. |
| Complete calls/frames | Reuse direct operands/native returns/deferred contexts. Require evidence for a remaining binding/context/continuation phase, then replace it coherently and remove its old driver/transport. No new caller arena. | Small helpers, constructors, comprehensions, genuinely pending hooks; defaults/keywords/closures, spans, stack admission, borrows and cleanup. |
| Scoped scalar transport | Assess boxed counters with reads/publication/retirement; select a bounded representation change only after hot-work proof. No universal tagged slots from allocation shares alone. | Aggregation/indexes; exact promotion, Python identity/aliases/hash/projection, checked arithmetic and substantial-storage funding. |
| Frontend/setup | Remove an actual repeated analysis or retained representation after shared lexical/class/parameter facts. Compile cost distinct from warm; caching identical scripts is not the answer. | Config/new helper/comprehension scripts; diagnostics, shared-graph correctness, binding, cancellation/admission and isolated per-run state. |

**R37 source gate completed:** current JSON already uses synchronous completed
container loops, direct UTF8 small-number parsing and key reuse; escaped strings
use UTF8 CopyString. Shared record prefixes already fill directly. No new JSON
intermediate selected. Existing R29 same-process code/address mapping identifies
118/1,095 samples in fetch/reload/check/switch blocks, within233prefix samples;
required checks are mixed in, and this is historical, not removable CPU today.
No aggregate recapture or runtime prototype selected from these facts.

**R37 call-transport gate:** static census shows native call slices already
borrow storage; dropping adjacent loads retains that storage and adds evaluated-
snapshot/error-span metadata. No new transport prototype selected.

**R39 closed cost gate:** B391/currentb0889a46 completes all source/golden/quiet/
funding/Closed/join/archive gates:1,127guest samples/5.68CPU seconds,58unknown.
BeginPendingCall550inclusive/32self includes helper execution; work-state26/18,
binding22/18,resume11/11 do not establish a dominant removable frame phase. CSV
parsing/record construction competes. No frame arena/rewrite or repeat aggregate
profile selected; shared layouts/final backing/idle workspaces already exist.
Original B390 setup failed before worker creation; source/condition archived before
one environment-key correction. Historical evidence now in ordinary-csv-cost.

**R38 retained:** irrelevant annotation binding suffixes removed; required control
exit facts and full regex conservative flow preserved. Source b0889a46, focused/
allocation/quiet outcomes recorded above; original3failures and refinement archived
under annotation-demand. Full delivery42351006316 is green and excludes the active R40 prototype. No repeated measurements or qualification selected.

**Completion for a retained redesign:** old displaced route/storage removed;
focused Python/cancellation/first-refusal/alias/cleanup checks; short exact-allocation
and quiet controlled before/after observations sized to be usable. Separate
architectural deletion, allocation reduction and demonstrated CPU improvement.
Temporary regressions require a finish milestone and explicit debt disposition.
Batch full platform/Stress/package checks at a coherent retained checkpoint, then
refresh external comparison only if materially affected. Continue the roadmap.

## Experimental policy

Timeouts, unstable unchanged controls and inconclusive measurements establish
uncertainty, not permanent design rejection. Bounded confirmation, source-justified
refinement or measurement correction is permitted; never repeat until favorable.
Size runs for the existing quiet VM. Preserve all adverse observations/original
failed conditions and independently verify source/image provenance. Percentages
inform retention, not automatic vetoes of useful simplification. No compound gains
or parity claims from variable data. Completed qualification is recorded once.

## Priority 2 — independent regex architecture

**R40 active core projection milestone:** source-proved repeated-prefix cost in
ProjectScalarBounds: any capture before the previous whole-match end resets the
Unicode cursor to byte/scalar0. Consecutive nearby fixed lookbehind therefore
rescans growing prefixes. Four baseline CPython probes (eight API comparisons)
agree on semantics: lookbehind, lookahead/empty matches, callbacks and original
pos/endpos windows. This is not yet a measured speedup or backend attribution.

Use the existing scalar cursor bidirectionally, seeking from byte0 when that is
closer and otherwise decoding backwards to the validated scalar boundary. Remove
unconditional origin restarts for nearby captures; preserve the origin choice for
far captures to avoid trading one large scan for two. No dense map/cache, pool,
provider API, adapter pin or memory-management layer. Retain all current capture
leases, range validation, effect order and result/subject owners. Allocation should
remain flat. Add current-token/first-refusal checks in the new nonallocating rewind.

Acceptance: independent Python/reg/coordinate semantics, retained aliases and
cleanup/refusal, actual in-flight cancellation on the new scan; short bounded
before/after at growing inputs holds normal0.4 matching constant, with ASCII and
forward-capture controls. Clocks include actual backend/guest work, not isolated
projection CPU. Use a cooperating provider only if a specific isolation/cancellation
fact remains missing; existing contract/unwind tests remain independent.
no producer release gate. Record all adverse controls. Nearby fixed-width scans
should avoid repeated prefixes; make no general linear-regex/large-prefix guarantee.
Stop after a coherent cursor change, focused checks and bounded comparison, then
continue the substantial non-regex roadmap while R36/R38 delivery runs separately.


Continue Lython-owned Python/nativeUTF8 semantics: byte ranges/scalar positions,
original-subject windows, captures/replacements/errors/cache ownership, current
cancellation through real work. Build on U04 caller-owned captures/R23 validated-
program reuse; no repeated unchanged qualification. Development producers and
adapter-local conversions/bridges support implementation and contract/semantic
tests. Producer publication defers only affected final adapter qualification.

Missing producer capabilities: DetailedData has no independent Prepare working
owner; native names lack enumeration; cursors mix creation/current token authority.
Exactdev48 adds no documented API removing these limits. Keep conservative
preflight/local conversion/qualified CTS bridge where needed. Qualify final released
immutable package and managed safety separately; no silent promotion, sibling
edits, dialect fallback, regex quota or abandoned background matching.

## Delivery constraints / current resources

AGENTS.md is authoritative. Fully managed/memory-safe; no unsafe/Unsafe/pointers/
PInvoke/native probing. Preserve managed stack/recursion, current cancellation,
host-mediated contained paths, cycles, coarse shared admission/preflights/overlap,
retained aliases and awaited actual-user cleanup. First memory refusal is terminal.
No tracing/weak reclamation/forced GC/fuel/quotas/caps/hidden default allowance.
Bounded host-driven streaming; XML depth constraint remains.

Focused Release iteration, no overlapping local builds/tests. Preserve original
Stress scales/timeouts and GC nonparallel groups. Full Windows/Ubuntu/actual11/10/
original Stress/installed consumers batched at meaningful boundaries. Never query
terminal CI42347124351 or earlier terminal runs again; receipts are committed.

Quiet VM lokad@20.166.121.73, key~/.ssh/id_lython-bench.pem. B385–B389 terminal/archived; no more service queries of those collections.
B390/B391 terminal, all users ended and archives independently verified; no
more service queries. No owned VM work remains. R40 prototype/focused checks pass
853internal/1,224public per actual target; timing and new-loop cancellation remain
pending. R36/R38 full CI excludes R40. Persistent inputs/evidence,
archive/verify RAM traces under lease before removal; record owner+stop+margin
before observation and never restart on observation timeout. Disk nearly full:
retire only exact redundant expanded files with independent committed backup,
matching hashes, ended users and checked file/directory link dependencies.
R36/R38 full delivery42351006316 is terminal GREEN; no further queries.
R40 prototype is outside that receipt. B389 observed terminal after07:24:01.727783UTC, all users joined/archive verified;
never query it again. R40 source/images preserved before prototype; local focused checks next.
Publication postponed.
