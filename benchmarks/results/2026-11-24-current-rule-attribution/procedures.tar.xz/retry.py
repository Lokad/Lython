from pathlib import Path
import hashlib,json,shutil

lab=Path(__file__).resolve().parent
failed=lab/"initial"
failed.mkdir(exist_ok=False)
terminal=json.loads((lab/"terminal-status.json").read_text(encoding="utf-8"))
assert not terminal["live"] and terminal["receipt"]["allWorkersJoined"] and not terminal["fixtures"]
assert not terminal["receipt"]["complete"] and "bounded warmup did not finish" in terminal["journal"]
raw=lab/"observations.tar.xz"
assert hashlib.sha256(raw.read_bytes()).hexdigest()==terminal["receipt"]["archiveSHA256"]
for name in ("terminal-status.json","observations.tar.xz","retrieve.log","launch.log","ops-profile.py","quiet.py"):
    shutil.copyfile(lab/name,failed/name)
ops=(lab/"ops-profile.py").read_text(encoding="utf-8")
assert ops.count("        count = 128")==1
ops=ops.replace("        count = 128","        count = 256")
compile(ops,"ops-profile.py","exec")
(lab/"ops-profile.py").write_text(ops,encoding="utf-8",newline="\n")
launcher=(lab/"quiet.py").read_text(encoding="utf-8")
launcher=launcher.replace("current-rule-attribution-b1627-20261124","current-rule-attribution-b1627-retry-20261124")
launcher=launcher.replace("lython-b1627-current-rule-attribution-20261124","lython-b1627-current-rule-attribution-retry-20261124")
compile(launcher,"quiet.py","exec")
(lab/"quiet.py").write_text(launcher,encoding="utf-8",newline="\n")
