from pathlib import Path
import json

lab=Path(__file__).resolve().parent
baseline=lab.with_name("forwarded-positional-framed-20261124")
identity=json.loads((lab/"identity.json").read_text(encoding="utf-8"))
eager={}
for role,core in identity["coreSHA256"].items():
    data=json.loads((baseline/(role+"-tape")/"tape.json").read_text(encoding="utf-8"))
    assert data["coreSHA256"]==core
    eager[role]=next(row["codes"] for row in data["rows"] if row["id"]=="scripts.annotated-rule-closures")
assert eager["reference"]==eager["candidate"]
body=next(code for code in eager["candidate"] if code["name"]=="<module>")
tape=body["tape"]
forwarded,update=tape[10],tape[12]
assert forwarded["<OpCode>k__BackingField"]==42 and forwarded["_secondaryOperand"]==2
assert update["<OpCode>k__BackingField"]==74 and update["_secondaryOperand"]==15
result=dict(coreSHA256=identity["coreSHA256"],candidateSource=identity["productionSources"]["candidate"],
    identicalMetadata=True, sites=[dict(index=10,existingOperation="Call",target="compile_rule",
         potentialDirectRoute="TryStartForwardedComputedDefinition"),
      dict(index=12,existingOperation="IntegerCallUpdate",target="latest",
           potentialDirectRoute="TryEvaluateIntegerCallUpdate")],
    sourceFactsOnly=True)
(lab/"eager-tape-summary.json").write_text(json.dumps(result,indent=2)+"\n",encoding="utf-8")
