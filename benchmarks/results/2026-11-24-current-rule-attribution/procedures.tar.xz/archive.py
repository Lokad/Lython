from pathlib import Path
import hashlib,json,shutil,tarfile

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
out=repo/"benchmarks/results/2026-11-24-current-rule-attribution"
read=lambda name:json.loads((lab/name).read_text(encoding="utf-8-sig"))
digest=lambda path:hashlib.sha256(path.read_bytes()).hexdigest()
terminal=read("terminal-status.json")
receipt=terminal["receipt"]
assert not terminal["live"] and not terminal["fixtures"] and terminal["exitCode"]=="0"
assert all(receipt[key] for key in ("complete","quietBeforeAndAfter","allWorkersJoined","guestFixturesRemoved","archivedAndVerifiedUnderLease"))
archive=lab/"observations.tar.xz"
assert digest(archive)==receipt["archiveSHA256"]
identity=read("identity.json")
assert identity["productionSources"]["candidate"].startswith("6466fbb52")
assert identity["productionSources"]["reference"].startswith("48790b2c7")
for role in ("candidate","reference"):
    proof=read(role+"-verification.json")
    assert proof["state"]=="Completed" and proof["caseCount"]==2
    assert proof["launched"]["library"]["sha256"]==identity["coreSHA256"][role]
    assert proof["catalogSha256"]==identity["profileCatalogSHA256"]
rows=read("attribution.json")["rows"]
assert len(rows)==3 and [(r["label"],r["case"],r["role"]) for r in rows]==[tuple(p) for p in identity["profiles"]]
with tarfile.open(archive) as bundle:
    assert json.load(bundle.extractfile("identity.json"))==identity
    for row in rows:
        record=json.load(bundle.extractfile("profiles/"+row["label"]+"/record.json"))
        assert record["exitCode"]==0 and record["closed"]["status"]=="Closed"
        assert record["response"]["completedInvocations"]==row["invocations"]
        assert record["verificationBefore"]["actualOutputSha256"]==record["verificationAfter"]["actualOutputSha256"]
        actual_core=next(item["sha256"] for item in record["identity"]["libraries"] if Path(item["path"]).name=="Lokad.Lython.dll")
        assert actual_core==identity["coreSHA256"][row["role"]]
out.mkdir(exist_ok=True)
failed=read("initial/terminal-status.json")
assert not failed["live"] and not failed["receipt"]["complete"] and not failed["fixtures"]
assert "bounded warmup did not finish" in failed["journal"]
assert digest(lab/"initial/observations.tar.xz")==failed["receipt"]["archiveSHA256"]
assert read("eager-tape-summary.json")["identicalMetadata"]
for name in ("identity.json","attribution.json","terminal-status.json","observations.tar.xz","eager-tape-summary.json"):
    shutil.copyfile(lab/name,out/name)
files=("prepare.py","quiet.py","collect.py","ops-profile.py","analyze.py","archive.py","run.sh",
       "catalog.json","candidate-verification.json","reference-verification.json","prepare.log","launch.log","catalog-custody.json",
       "inspect-eager.py","retry.py","initial/terminal-status.json","initial/observations.tar.xz",
       "initial/launch.log","initial/retrieve.log","initial/ops-profile.py","initial/quiet.py")
with tarfile.open(out/"procedures.tar.xz","w:xz") as procedures:
    for name in files:procedures.add(lab/name,arcname=name,recursive=False)
