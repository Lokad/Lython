from pathlib import Path
import hashlib, json, os, shutil, subprocess

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
template = lab.with_name("current-defaulted-report-cpu-20261124")
donor = lab.with_name("forwarded-positional-framed-20261124")
quiet = donor / "comparison/quiet"
read = lambda p: json.loads(p.read_text(encoding="utf-8"))
digest = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
write = lambda p, s: p.write_text(s, encoding="utf-8", newline="\n")
save = lambda p, d: write(p, json.dumps(d, indent=2) + "\n")
identity = read(quiet / "identity.json")
receipt = read(quiet / "terminal-status.json")["receipt"]
assert receipt["complete"] and receipt["allWorkersJoined"] and receipt["archivedAndVerifiedUnderLease"]
assert digest(quiet / "observations.tar.xz") == receipt["archiveSHA256"]
base = identity["comparisonRevision"]
current = subprocess.check_output(["git","rev-parse","6466fbb52"], cwd=repo, text=True).strip()
patch = subprocess.check_output(["git","diff","--binary",base,current,"--","src","tests"],cwd=repo)
assert hashlib.sha256(patch).hexdigest() == identity["sourcePatchSHA256"]
assert patch == (donor / "candidate.patch").read_bytes()
profiles = [("eager-before", "scripts.annotated-rule-closures", "reference"),
            ("eager-after", "scripts.annotated-rule-closures", "candidate"),
            ("defaulted", "scripts.rule-default-closures", "candidate")]
ids = {case for _, case, _ in profiles}
catalog = read(quiet / "representative.json")
catalog["cases"] = [entry for entry in catalog["cases"] if entry["id"] in ids]
assert len(catalog["cases"]) == 2
save(lab / "catalog.json", catalog)
identity["coreSHA256"] = {role: files["Lokad.Lython.dll"] for role, files in identity["imageFiles"].items()}
identity.update(productionSources=dict(reference=base,candidate=current), donorArchiveSHA256=receipt["archiveSHA256"],
                profiles=profiles, profileCatalogSHA256=digest(lab / "catalog.json"),
                purpose="Attribute defaulted-rule remaining costs and the same-tape eager CPU debt")
save(lab / "identity.json", identity)
sdk = Path.home()/".dotnet11"
dotnet = sdk/"dotnet.exe"
env = dict(os.environ, DOTNET_ROOT=str(sdk), DOTNET_ROOT_X64=str(sdk))
worker = repo / "benchmarks/cpython-worker.py"
assert digest(worker) == identity["cpythonWorkerSHA256"]
for role, files in identity["imageFiles"].items():
    image = donor/role
    assert {p.name:digest(p) for p in image.iterdir()} == files and len(files)==32
    verification = lab / (role + "-verification.json")
    subprocess.run([dotnet,image/"Lokad.Lython.Benchmarks.dll","--compare","verify","--catalog",lab/"catalog.json",
        "--dotnet",dotnet,"--python","C:/Python313/python.exe","--python-worker",worker,"--out",verification],
        cwd=repo, env=env, check=True, timeout=75)

collect = (template/"collect.py").read_text(encoding="utf-8")
collect = collect.replace("closed-capture-seeded-b1603-20261124", "forwarded-positional-framed-b1624-20261124")
collect = collect.replace("b1605-fixtures", "b1627-fixtures").replace(">= 4*1024*1024", ">= 6*1024*1024")
launcher = (template/"quiet.py").read_text(encoding="utf-8")
launcher = launcher.replace("current-defaulted-report-cpu-b1605-20261124", "current-rule-attribution-b1627-20261124")
launcher = launcher.replace("lython-b1605-current-defaulted-report-cpu-20261124", "lython-b1627-current-rule-attribution-20261124")
launcher = launcher.replace("closed-capture-pair-seeded-20261124", "forwarded-positional-framed-20261124")
launcher = launcher.replace('"candidate-verification.json","ops-profile.py"', '"candidate-verification.json","reference-verification.json","ops-profile.py"')
launcher = launcher.replace("'candidate-verification.json','ops-profile.py'", "'candidate-verification.json','reference-verification.json','ops-profile.py'")
launcher = launcher.replace(">= 5*1024*1024", ">= 7*1024*1024").replace("Staged two profiles","Staged three profiles")
launcher = launcher.replace("seconds=76","seconds=87")
for name, code in (("collect.py",collect),("quiet.py",launcher)):
    compile(code,name,"exec")
    write(lab/name,code)
for name in ("ops-profile.py","run.sh","analyze.py"):
    shutil.copyfile(template/name,lab/name)
assert b"\r" not in (lab/"run.sh").read_bytes()
print("Prepared three bounded profiles against sealed Lython images.")
