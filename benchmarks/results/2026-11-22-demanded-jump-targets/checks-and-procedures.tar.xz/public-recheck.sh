#!/bin/bash
set -euo pipefail
cd /mnt/d/code/Lython/.git/agent-worktrees/demanded-jump-targets-20261122
export DOTNET_ROOT="$HOME/.dotnet"
export PATH="$DOTNET_ROOT:$PATH"
logs=/mnt/d/code/Lython/.git/agent-notes/review-20261031/demanded-jump-targets-20261122
public='Category!=Stress&(FullyQualifiedName~Exception|FullyQualifiedName~Generator|FullyQualifiedName~Comprehension|FullyQualifiedName~ControlFlow|FullyQualifiedName~Stack|FullyQualifiedName~Budget|FullyQualifiedName~Cancellation)'
mv "$logs/public-ubuntu.log" "$logs/initial-public-ubuntu.log"
dotnet test tests/Lokad.Lython.PublicApi.Tests -c Release -f net10.0 --no-build --filter "$public" --verbosity normal > "$logs/public-ubuntu.log" 2>&1
