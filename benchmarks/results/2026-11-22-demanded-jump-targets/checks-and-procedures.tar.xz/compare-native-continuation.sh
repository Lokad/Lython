#!/bin/bash
set -euo pipefail
export DOTNET_ROOT="$HOME/.dotnet"
export PATH="$DOTNET_ROOT:$PATH"
export DOTNET_PROCESSOR_COUNT=1
ulimit -c 0
root=/mnt/d/code/Lython/.git/agent-worktrees
logs=/mnt/d/code/Lython/.git/agent-notes/review-20261031/demanded-jump-targets-20261122
reference="$root/direct-default-instructions-20261122"
candidate="$root/demanded-jump-targets-20261122"
for name in reference candidate; do
    work="${!name}"
    fixture="$work/tests/Lokad.Lython.WorkerFixture/bin/Release/net10.0/Lokad.Lython.WorkerFixture.dll"
    lib="$work/src/Lokad.Lython/bin/Release/net10.0/Lokad.Lython.dll"
    test -f "$fixture"
    test -f "$lib"
    sha256sum "$lib"
    for attempt in 1 2 3; do
        timeout 25s dotnet "$fixture" stack-guard "$lib" native-call-continuation > "$logs/$name-stack-$attempt.json" 2> "$logs/$name-stack-$attempt.stderr"
        test ! -s "$logs/$name-stack-$attempt.stderr"
    done
done
