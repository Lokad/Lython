from pathlib import Path
import hashlib
import json
import shutil
import subprocess

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
worktree = repo / ".git/agent-worktrees/demanded-jump-targets-20261122"
donor = lab.parent / "direct-default-instructions-20261122"
def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
def read(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))
def revision(root, expression="HEAD"):
    return subprocess.check_output(["git","rev-parse",expression],cwd=root,text=True).strip()

reference = revision(repo,"fd41c741e")
candidate = revision(worktree)
assert candidate.startswith("067665c0e") and revision(worktree,"HEAD~2") == reference
assert not subprocess.check_output(["git","status","--porcelain"],cwd=worktree)
subprocess.run(["git","diff","--exit-code","2aa1b17e2",reference,"--","src","tests"],cwd=repo,check=True)
donor_image = donor / "frozen/candidate"
before = read(donor/"quiet/identity.json")["imageFiles"]["candidate"]
assert len(before) == 32 and {n:sha(donor_image/n) for n in before} == before
core = "Lokad.Lython.dll"
images = {}
for role in ("reference","candidate"):
    out = lab/"frozen"/role
    out.mkdir(parents=True)
    for name in before:
        source = lab/"frozen-candidate-core.dll" if role=="candidate" and name==core else donor_image/name
        shutil.copyfile(source,out/name)
    images[role] = {name:sha(out/name) for name in before}
assert images["reference"] == before
assert [name for name in before if before[name] != images["candidate"][name]] == [core]
inspection = read(lab/"inspection-identity.json")
for role,files in images.items():
    assert inspection["workerImages"][role]["inspect"][core] == files[core]
    assert inspection["workerImages"][role]["compile"][core] == files[core]
(lab/"identity.json").write_text(json.dumps(dict(reference=reference,candidate=candidate,imageFiles=images),indent=2)+"\n",
    encoding="utf-8",newline="\n")
print("Verifiable 32-file images copied for the exact rebased source pair.")
