#!/bin/bash
set -euo pipefail
cd /mnt/d/code/Lython/.git/agent-worktrees/demanded-jump-targets-20261122
export DOTNET_ROOT="$HOME/.dotnet"
export PATH="$DOTNET_ROOT:$PATH"
logs=/mnt/d/code/Lython/.git/agent-notes/review-20261031/demanded-jump-targets-20261122
white='Category!=Stress&(FullyQualifiedName~Executable|FullyQualifiedName~Compiler|FullyQualifiedName~Frontend|FullyQualifiedName~Assertion)'
public='Category!=Stress&(FullyQualifiedName~Exception|FullyQualifiedName~Generator|FullyQualifiedName~Comprehension|FullyQualifiedName~ControlFlow|FullyQualifiedName~Stack|FullyQualifiedName~Budget|FullyQualifiedName~Cancellation)'
dotnet test tests/Lokad.Lython.Tests -c Release -f net10.0 --filter "$white" --verbosity quiet > "$logs/white-ubuntu.log" 2>&1 || { tail -30 "$logs/white-ubuntu.log"; exit 1; }
dotnet build tools/LythonProbe/LythonProbe.csproj -c Release -f net10.0 > "$logs/probe-ubuntu.log" 2>&1 || { tail -30 "$logs/probe-ubuntu.log"; exit 1; }
dotnet test tests/Lokad.Lython.PublicApi.Tests -c Release -f net10.0 --filter "$public" --verbosity quiet > "$logs/public-ubuntu.log" 2>&1 || { tail -30 "$logs/public-ubuntu.log"; exit 1; }
grep -H "Passed!" "$logs/white-ubuntu.log" "$logs/public-ubuntu.log"
