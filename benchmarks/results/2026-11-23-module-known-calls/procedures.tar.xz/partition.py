from collections import defaultdict
from pathlib import Path
import json
import re

workspace = Path(".git/agent-worktrees/module-known-calls-20261123")
root = workspace / "src/Lokad.Lython"
contract_file = root / "Frontend/StaticContracts.KnownCalls.cs"
signatures = sorted(root.glob("Runtime/Calls/LythonKnownCallableSignatures.*.cs"))
lab = Path(__file__).resolve().parent

def read(path):
    return path.read_text(encoding="utf-8")

def write(path, source):
    path.write_text(source, encoding="utf-8", newline="\n")

def indent(body, spaces=4):
    return "\n".join((" " * spaces + line) if line else "" for line in body.splitlines())

names: dict[str, tuple[str, str, str]] = {}
module_ids = {"argparse": "Argparse", "csv": "Csv", "dataclasses": "Dataclasses", "datetime": "DateTime",
    "difflib": "Difflib", "filecmp": "Filecmp", "fnmatch": "Fnmatch", "functools": "Functools", "gzip": "Gzip",
    "hashlib": "Hashlib", "html": "Html", "importlib": "Importlib", "io": "Io", "itertools": "Itertools",
    "json": "Json", "openpyxl": "OpenPyxl", "pathlib": "Pathlib", "pkgutil": "Pkgutil", "re": "Regex",
    "shlex": "Shlex", "shutil": "Shutil", "subprocess": "Subprocess", "textwrap": "Textwrap",
    "urllib": "UrlLib", "xml": "ElementTree", "zipfile": "Zipfile", "zlib": "Zlib"}
helpers = defaultdict(list)
module_file = {}
definition = re.compile(r"^    public static readonly LythonCallableSignature (\w+) =\s*LythonCallableSignature.Create\(\s*\"([^\"]+)\"[^;]*;", re.M)
prefixes = {"urllib": ("UrlLib", "UrlParse", "Urllib"), "re": ("Regex", "Re"), "xml": ("ElementTree",)}

for file in signatures:
    source = read(file)
    expected = len(re.findall(r"^    public static readonly LythonCallableSignature ", source, re.M))
    found = list(definition.finditer(source))
    assert len(found) == expected, file
    group_definitions = defaultdict(list)
    for match in found:
        old, target = match.groups()
        module, member = target.split(".", 1)
        owner = module_ids.get(module, module.capitalize())
        prefix = next((name for name in prefixes.get(module, (owner,)) if old.startswith(name)), "")
        leaf = old[len(prefix):]
        if leaf in ("", owner) or leaf[0].isdigit():
            leaf = old
        assert old not in names and ("LythonKnownCallableSignatures." + old) not in match[0]
        names[old] = (module, f"{owner}.{leaf}", target)
        if module in module_file:
            assert module_file[module] == file
        module_file[module] = file
        group_definitions[module].append(match[0].replace(f" {old} =", f" {leaf} =", 1))

    unconsumed = definition.sub("", source)
    additional = [s for s in unconsumed.splitlines() if "private static readonly string[]" in s]
    if additional:
        assert len(additional) == 2 and all("Subprocess" in s for s in additional)
        helpers["subprocess"] = [s.replace("Subprocess", "", 1) for s in additional]
        group_definitions["subprocess"] = [s.replace("SubprocessParameters", "Parameters").replace(
            "SubprocessPopenParameters", "PopenParameters") for s in group_definitions["subprocess"]]
        for s in additional:
            unconsumed = unconsumed.replace(s, "")
    assert unconsumed.strip() == "namespace Lokad.Lython.Runtime;\n\ninternal static partial class LythonKnownCallableSignatures\n{" + "\n" * (unconsumed.strip().count("\n") - 3) + "}", (file, unconsumed)
    begins = source[:source.index("{\n")+2]
    sections=[]
    for module, members in group_definitions.items():
        owner = module_ids.get(module, module.capitalize())
        fields = []
        if helpers[module]:
            fields.extend(helpers[module])
            fields.append("")
        fields.extend(members)
        sections.append(f"    internal static class {owner}\n    {{\n" + indent("\n".join(fields)) + "\n    }")
    write(file, begins + "\n\n".join(sections) + "\n}\n")

assert len(names) == 493 and len(set(v[2] for v in names.values())) == len(names)
assert len(set(v[1] for v in names.values())) == len(names)
references = re.compile(r"\bLythonKnownCallableSignatures\.(\w+)\b")
def qualify(match):
    symbol = match[1]
    assert symbol in names, symbol
    return "LythonKnownCallableSignatures." + names[symbol][1]

reference_count = 0
for folders in (workspace/"src", workspace/"tests"):
    for file in folders.rglob("*.cs"):
        data = read(file)
        if file != contract_file and references.search(data):
            replaced, count = references.subn(qualify, data)
            reference_count += count
            write(file, replaced)

source = read(contract_file)
array_start = source.index("    private static StaticKnownCallContract[] CreateKnownCallContracts() =>")
array_end = source.index("    ];", array_start)
group_contracts = defaultdict(list)
metadata = []
comments = []
for line in source[array_start:array_end].splitlines()[2:]:
    if line.lstrip().startswith("//"):
        comments.append(line)
    elif line.strip():
        hit = references.search(line)
        assert hit is not None and line.strip().startswith("new(") and line.rstrip().endswith("),"), line
        key = hit[1]
        module, qualified, target = names[key]
        group_contracts[module].extend(comments)
        comments.clear()
        group_contracts[module].append(references.sub(qualify, line))
        metadata.append(dict(target=target, baselineField=key, candidateField=qualified, contractArguments=line[hit.end():].strip()))
assert not comments and len(metadata) == 487
names_by_module = {module: module_ids.get(module, module.capitalize()) for module in group_contracts}
head = source[:array_start]
lookup = """    public static bool TryGetKnownCallContract(string targetName, out StaticKnownCallContract contract)
    {
        // Qualified aliases enter here with their canonical target. Select its
        // owning module without allocating another string.
        var separator = targetName.IndexOf('.');
        var index = separator > 0 ? targetName.AsSpan(0, separator) switch
        {
"""
for module, owner in sorted(names_by_module.items()):
    lookup += f'            "{module}" => {owner}Calls.ByName,\n'
lookup += """            _ => null,
        } : null;

        if (index is not null)
            return index.TryGetValue(targetName, out contract);
        contract = default;
        return false;
    }

"""
tail_start = source.index("    public static bool TryGetKnownCallReturn")
tail = source[tail_start:source.rindex("}")].rstrip()
body = []
for module, owner in sorted(names_by_module.items()):
    declarations = indent("\n".join(group_contracts[module]), 4).splitlines()
    declarations[-1] = declarations[-1].removesuffix(",")
    body.append(f"""    private static class {owner}Calls
    {{
        internal static readonly Dictionary<string, StaticKnownCallContract> ByName = Index(
{chr(10).join(declarations)});
    }}""")
write(contract_file, head + lookup + tail + """

    private static Dictionary<string, StaticKnownCallContract> Index(params StaticKnownCallContract[] declarations)
        => declarations.ToDictionary(static declaration => declaration.TargetName, StringComparer.Ordinal);

""" + "\n\n".join(body) + "\n}\n")
print(len(names), "runtime signatures,", len(metadata), "analyzed callables,",
      len(group_contracts), "module owners,", reference_count, "other uses")
write(lab/"inventory.json", json.dumps(dict(
    signatures=[dict(baselineField=k,module=v[0],candidateField=v[1],target=v[2]) for k,v in sorted(names.items())],
    knownCalls=metadata
), indent=2)+"\n")
