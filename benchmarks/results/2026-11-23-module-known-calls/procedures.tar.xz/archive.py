from pathlib import Path
import gzip
import hashlib
import json
import shutil
import tarfile

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
comparison=lab/"comparison"
quiet=comparison/"quiet"
read=lambda p:json.loads(p.read_text(encoding="utf-8"))
save=lambda p,data:p.write_text(json.dumps(data,indent=2)+"\n",encoding="utf-8",newline="\n")
digest=lambda bytes_:hashlib.sha256(bytes_).hexdigest()
dest=repo/"benchmarks/results/2026-11-23-module-known-calls"
identity=read(comparison/"identity.json")
status=read(quiet/"terminal-status.json")
assert status["exitCode"]=="0"
assert digest((quiet/"observations.tar.xz").read_bytes())==status["receipt"]["archiveSHA256"]
alloc=read(lab/"allocation-summary.json")
traces=read(lab/"constructor-traces/summary.json")
candidate=identity["candidate"]
core=(comparison/"frozen-candidate/Lokad.Lython.dll").read_bytes()
assert digest(core)==identity["coreSHA256"]["candidate"]
assert alloc["roles"]==identity["coreSHA256"]
dest.mkdir()
save(dest/"source.json",identity)
save(dest/"allocation-summary.json",alloc["results"])
save(dest/"constructor-summary.json",traces)
save(dest/"parity-summary.json",read(lab/"parity-summary.json"))
shutil.copyfile(quiet/"terminal-status.json",dest/"terminal-status.json")
shutil.copyfile(quiet/"observations.tar.xz",dest/"observations.tar.xz")
shutil.copyfile(quiet/"summary.json",dest/"summary.json")
(dest/"candidate-core.dll.gz").write_bytes(gzip.compress(core,mtime=0))
with tarfile.open(dest/"procedures.tar.xz","w:xz") as t:
    def add(name):t.add(lab/name,arcname=name,recursive=False)
    for name in ["freeze.py","partition.py","inventory.json","reference-contracts.json","candidate-contracts.json",
                  "contract-parity/Program.cs","contract-parity/ContractParity.csproj","stage.py","quiet.py","summarize.py","constructor-traces.py","allocations.py",
                 "allocation-driver/Program.cs","allocation-driver/Allocation.csproj","trace-reader/Program.cs","trace-reader/TraceReader.csproj",
                 "windows-white.log","windows-public.log","wsl-white.log","wsl-public.log","allocation-summary.json",
                 "comparison/reference-verify.json","comparison/candidate-verify.json","comparison/source.patch",
                 "comparison/quiet/launch.log","comparison/quiet/observe-not-before"]:
        add(name)
    for trace in traces:
        name="constructor-traces/"+trace["trace"]
        assert digest((lab/name).read_bytes())==trace["traceSha256"]
        add(name)
        add(str(Path(name).with_suffix(".log")))
    for p in sorted((lab/"constructor-traces").glob("*.small.json")):
        add(str(p.relative_to(lab)))
    add("constructor-traces/control.empty.control.json")
    t.add(lab/"archive.py",arcname="archive.py",recursive=False)
assert digest(gzip.decompress((dest/"candidate-core.dll.gz").read_bytes()))==identity["coreSHA256"]["candidate"]
print(candidate,dest)
