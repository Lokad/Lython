from pathlib import Path
import hashlib
import json
import os
import shutil
from statistics import median
import subprocess

root=Path(__file__).resolve().parent
comparison=root/"comparison"
directory=root/"allocation-driver"
identity=json.loads((comparison/"identity.json").read_text(encoding="utf-8"))
proof=json.loads((comparison/"reference-verify.json").read_text(encoding="utf-8"))
dotnet=Path(proof["launched"]["dotnet"]["path"])
reference=Path(proof["launched"]["adapter"]["path"]).parent
active={"reference":reference,"candidate":comparison/"frozen-candidate"}
binary=next(directory.glob("bin/**/Allocation.dll")).parent
environment=dict(os.environ,DOTNET_ROOT=str(dotnet.parent),DOTNET_ROOT_X64=str(dotnet.parent))
rows=[]
groups={}
for role,image in active.items():
    target=directory/role
    target.mkdir()
    for name in ["Allocation.dll","Allocation.deps.json","Allocation.runtimeconfig.json"]:
        shutil.copyfile(binary/name,target/name)
    payload=image/"Lokad.Lython.dll"
    shutil.copyfile(payload,target/payload.name)
    assert hashlib.sha256((target/payload.name).read_bytes()).hexdigest()==identity["coreSHA256"][role]
    groups[role]=target

plans=(
    ("control.empty.control",comparison/"representative.json"),
    ("control.tiny.control",comparison/"representative.json"),
    ("scripts.config-edit.small",comparison/"representative.json"),
    ("scripts.csv-meter-report.typed-ascii",comparison/"representative.json"),
    ("xml.parse-select.small",comparison/"representative.json"),
    ("compiler.generated-read-only-branches",comparison/"representative.json"),
    ("scripts.json-lines-shipment.expanded-options.large",comparison/"representative.json"),
)
for repeat in range(5):
    names=["reference","candidate"]
    if repeat%2:names.reverse()
    for name,manifest in plans:
        for role in names:
            result=subprocess.run([dotnet,groups[role]/"Allocation.dll",manifest,name],env=environment,
                capture_output=True,encoding="utf-8",check=True,timeout=20)
            observed=json.loads(result.stdout);observed.update(role=role,repeat=repeat)
            rows.append(observed)
summary={}
for case,_ in plans:
    summary[case]={}
    for role in groups:
        observations=[r for r in rows if r["id"]==case and r["role"]==role]
        warm=[r for process in observations for r in process["warm"]]
        assert len(observations)==5 and len(warm)==125
        cold=[r["cold"] for r in observations]
        result=dict(coldAllocated=median(c["AllocatedBytes"] for c in cold),warmAllocated=median(c["AllocatedBytes"] for c in warm),
            coldPeaks=sorted({c["PeakAllowance"] for c in cold}),warmPeaks=sorted({c["PeakAllowance"] for c in warm}))
        summary[case][role]=result
        print(case,role,result)
    first,second=summary[case]["reference"],summary[case]["candidate"]
    assert first["coldPeaks"]==first["warmPeaks"]==second["coldPeaks"]==second["warmPeaks"]
(root/"allocation-summary.json").write_text(json.dumps(dict(roles=identity["coreSHA256"],results=summary,observations=rows),indent=2)+"\n",encoding="utf-8")
