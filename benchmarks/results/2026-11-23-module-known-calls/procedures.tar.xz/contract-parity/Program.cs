using System.Collections;
using System.Reflection;
using System.Runtime.Loader;
using System.Text.Json;

var assembly = AssemblyLoadContext.Default.LoadFromAssemblyPath(Path.GetFullPath(args[0]));
using var inventory = JsonDocument.Parse(File.ReadAllBytes(args[1]));
var candidate = args[2] == "candidate";
const BindingFlags Lookup = BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Static | BindingFlags.Instance;
Type Type(string @namespace, string name) => assembly.GetType($"Lokad.Lython.{@namespace}.{name}", throwOnError: true)!;

var scope = Type("Runtime", "LythonKnownCallableSignatures");
var contracts = Type("Frontend", "StaticContracts");
var catalog = Type("Frontend", "StaticModuleCatalog");
var lookup = contracts.GetMethod("TryGetKnownCallContract", Lookup)!;
var resolveAlias = contracts.GetMethod("TryGetModuleMemberValue", Lookup)!;
var span = Activator.CreateInstance(resolveAlias.GetParameters()[2].ParameterType, 0, 0, 0, 0);
var callableTargets = inventory.RootElement.GetProperty("knownCalls").EnumerateArray()
    .Select(row => row.GetProperty("target").GetString()!).ToHashSet(StringComparer.Ordinal);

object? Get(object instance, string property) => instance.GetType().GetProperty(property, Lookup)?.GetValue(instance);
object? Limit(object? limit) => limit is null ? null : new { bounded = Get(limit, "IsBounded"), maximum = Get(limit, "Maximum") };

var snapshots = new List<object>();
foreach (var row in inventory.RootElement.GetProperty("signatures").EnumerateArray().OrderBy(item => item.GetProperty("target").GetString(), StringComparer.Ordinal))
{
    var target = row.GetProperty("target").GetString()!;
    var path = row.GetProperty(candidate ? "candidateField" : "baselineField").GetString()!.Split('.');
    var owner = candidate ? scope.GetNestedType(path[0], BindingFlags.Public | BindingFlags.NonPublic)! : scope;
    var runtime = owner.GetField(path[^1], Lookup)!.GetValue(null)!;
    if (!Equals(Get(runtime, "Name"), target)) throw new InvalidDataException("Signature name mismatch for " + target);
    var arguments = new object?[] { target, null };
    var visible = (bool)lookup.Invoke(null, arguments)!;
    if (visible != callableTargets.Contains(target))
        throw new InvalidDataException("Known-call membership mismatch for " + target);
    var contract = visible ? arguments[1] : null;
    if (visible && !ReferenceEquals(Get(contract!, "Signature"), runtime))
        throw new InvalidDataException("Frontend and runtime use different signatures for " + target);
    var layout = Get(runtime, "Parameters")!;
    var names = (Get(layout, "ParameterNames") as IEnumerable)?.Cast<string>().ToArray();
    snapshots.Add(new
    {
        target, visible, name = Get(runtime, "Name"), kind = layout.GetType().Name, names,
        minimumArguments = Get(layout, "MinimumArgumentCount"),
        maxArguments = Limit(Get(layout, "MaximumArgumentCount")),
        maxPositional = Limit(Get(layout, "MaximumPositionalArgumentCount")),
        required = Get(layout, "RequiredCount"),
        variadicKeywords = Get(layout, "AllowsExtraKeywords"),
        variadicPositionals = Get(layout, "AllowsExtraPositional"),
        positionalOnly = Get(layout, "PositionalOnlyCount"),
        diagnostic = visible ? Get(contract!, "DiagnosticCode") : null,
        message = visible ? Get(contract!, "Message") : null,
        returnShape = visible ? Get(contract!, "ReturnShape")?.ToString() : null,
    });
}

var aliases = new SortedDictionary<string, string>(StringComparer.Ordinal);
foreach (var entry in (IEnumerable)catalog.GetField("CallableAliases", Lookup)!.GetValue(null)!)
{
    var member = Get(entry, "Key")!;
    var canonical = (string)Get(entry, "Value")!;
    var module = (string)Get(member, "ModuleName")!;
    var name = (string)Get(member, "MemberName")!;
    var parameters = new[] { module, name, span, null };
    if (!(bool)resolveAlias.Invoke(null, parameters)!)
        throw new InvalidDataException("Unresolved alias " + module + "." + name);
    var value = parameters[3]!;
    if (Get(value, "Kind")?.ToString() != "KnownCallable") throw new InvalidDataException("Alias is not callable.");
    var actual = (string)value.GetType().GetMethod("RequireText", Lookup)!.Invoke(value, null)!;
    if (actual != canonical || !callableTargets.Contains(actual))
        throw new InvalidDataException("Alias target mismatch.");
    aliases.Add(module + "." + name, canonical);
}

foreach (var name in new[] { "", ".", "json", ".json", "JSON.loads", "json.Loads", "json.loads.more", "glob.unknown", "other.loads", "xml.etree.fromstring" })
    if ((bool)lookup.Invoke(null, new object?[] { name, null })!)
        throw new InvalidDataException("Unexpected known-call match for " + name);

Console.WriteLine(JsonSerializer.Serialize(new { signatures = snapshots, aliases }));

