from pathlib import Path
from statistics import median,quantiles
import hashlib,json,tarfile

lab=Path(__file__).resolve().parent
comparison=lab/"comparison"
quiet=comparison/"quiet"
read=lambda p:json.loads(p.read_text(encoding="utf-8"))
status=read(quiet/"terminal-status.json")
archive=quiet/"observations.tar.xz"
assert not status["live"] and not status["fixtures"] and status["exitCode"]=="0"
receipt=status["receipt"]
assert all(receipt[k] for k in ["complete","allWorkersJoined","guestFixturesRemoved","quietBeforeAndAfter","archivedAndVerifiedUnderLease"])
assert receipt["warmJobs"] == 5 and receipt["freshPairs"]==70
assert hashlib.sha256(archive.read_bytes()).hexdigest()==receipt["archiveSHA256"]
identity=read(comparison/"identity.json")
jobs=read(comparison/"jobs.json")
cases={case["id"]:case for case in read(comparison/"representative.json")["cases"]}
with tarfile.open(archive) as frozen:
    packed=lambda name:json.load(frozen.extractfile(name))
    assert identity==packed("identity.json")
    assert jobs==packed("jobs.json")
    warm=packed("confirmation/confirmation.json")
    assert warm["complete"] and len(warm["jobs"])==5
    assert [(job["case"],job["lane"]) for job in warm["jobs"]]==[tuple(row) for row in jobs["warm"]]
    warm_rows=[]
    for job in warm["jobs"]:
        assert job["workersJoinedAndFixturesRemoved"] and len(job["samples"])==28
        case=cases[job["case"]]
        stats={}
        for role,proof in job["identities"].items():
            assert [lib["sha256"] for lib in proof["libraries"] if Path(lib["path"]).name=="Lokad.Lython.dll"]==[identity["coreSHA256"][role]]
            assert proof["runtimeVersion"]=="11.0.0"
            elapsed=[]
            cpu=[]
            for row in job["samples"]:
                if row["engine"]!=role:continue
                response=row["response"]
                count=response["completedInvocations"]
                assert count>0 and response["status"]=="Completed"
                assert all(response[k]==case[k] for k in ["sourceSha256","expectedOutputSha256","fixtureSha256"])
                assert response.get("actualOutputSha256") == (None if job["lane"]=="compile" else case["expectedOutputSha256"])
                assert response.get("actualFilesSha256") == (None if job["lane"]=="compile" else case.get("expectedFilesSha256"))
                elapsed.append(response["elapsedTicks"]*1000/response["clockFrequency"]/count)
                cpu.append(row["externalProcessCpuTicks"]*1000/row["externalCpuFrequency"]/count)
            assert len(elapsed)==len(cpu)==7
            q=quantiles(elapsed,n=4,method="inclusive")
            stats[role]=dict(elapsed=median(elapsed),cpu=median(cpu),iqrPercent=100*(q[2]-q[0])/median(elapsed))
        def spread(role):
            a=stats[role]["elapsed"]; b=stats[role+"-control"]["elapsed"]
            return (max(a,b)/min(a,b)-1)*100
        def change(metric):
            pairs=[(stats[a][metric]/stats[b][metric]-1)*100
                for a in ("candidate","candidate-control")for b in ("reference","reference-control")]
            return min(pairs),max(pairs)
        row=dict(case=case["id"],lane=job["lane"],medianByWorker=stats,referenceControlPercent=spread("reference"),
            candidateControlPercent=spread("candidate"),elapsedChangePercent=change("elapsed"),cpuChangePercent=change("cpu"))
        warm_rows.append(row)
        print(job["lane"],case["id"],"elapsed",row["elapsedChangePercent"],"CPU",row["cpuChangePercent"],"spread",row["referenceControlPercent"],row["candidateControlPercent"])

    counts={case:{"reference":[],"candidate":[],"reference-cpython":[],"candidate-cpython":[]} for case in jobs["cold"]}
    for repeat in range(7):
        catalog_name=f"confirmation/fresh-catalog-{repeat}.json"
        catalog=frozen.extractfile(catalog_name).read()
        active=json.loads(catalog)["cases"]
        assert set(row["id"] for row in active)==set(jobs["cold"])
        for role in ["reference","candidate"]:
            report=packed(f"confirmation/fresh-{repeat}-{role}.json")
            assert report["catalogSha256"]==hashlib.sha256(catalog).hexdigest()
            assert report["state"]=="Completed" and report["caseCount"]==5
            assert report["launched"]["library"]["sha256"]==identity["coreSHA256"][role]
            assert report["launched"]["python"]["sha256"]==identity["expectedCPythonSHA256"]
            for entry in report["rows"]:
                observation=entry["observation"]
                response=observation["response"]
                case=cases[response["caseId"]]
                assert observation["status"]=="Equivalent" and response["completedInvocations"]==1
                assert response["actualOutputSha256"]==case["expectedOutputSha256"]
                assert response.get("actualFilesSha256")==case.get("expectedFilesSha256")
                series=role if entry["engine"]=="Lython" else role+"-cpython"
                counts[case["id"]][series].append(observation["elapsedTicks"]*1000/observation["clockFrequency"])

cold_rows=[]
for case,series in counts.items():
    assert all(len(e)==7 for e in series.values())
    first=series["reference"]; second=series["candidate"]
    changes=[(b/a-1)*100 for a,b in zip(first,second,strict=True)]
    row=dict(case=case,sourcePairedChangeRangePercent=[min(changes),max(changes)],
        sourcePairedMedianChangePercent=median(changes),medianChangePercent=(median(second)/median(first)-1)*100,
        medianMs={key:median(values) for key,values in series.items()},
        rangeMs={key:[min(values),max(values)] for key,values in series.items()})
    cold_rows.append(row)
    print("fresh",case,row["medianMs"],"change",row["medianChangePercent"],"pair range",row["sourcePairedChangeRangePercent"])
(quiet/"summary.json").write_text(json.dumps(dict(source=identity["sourceRevision"],candidate=identity["candidate"],
        freshPairs=receipt["freshPairs"],warmTimedBatches=140,firstUse=cold_rows,warmCompile=warm_rows),indent=2)+"\n",encoding="utf-8")
