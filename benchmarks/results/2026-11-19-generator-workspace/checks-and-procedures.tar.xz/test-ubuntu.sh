export DOTNET_ROOT=~/.dotnet
lab=/mnt/d/code/Lython/.git/agent-notes/review-20261031/generator-workspace-r688
~/.dotnet/dotnet test tests/Lokad.Lython.PublicApi.Tests/Lokad.Lython.PublicApi.Tests.csproj -c Release -f net10.0 --artifacts-path "$lab/ubuntu" --filter '(FullyQualifiedName~Generator|FullyQualifiedName~OrdinaryFunctionTransportTests|FullyQualifiedName~HelperLocalLifetimeTests)&Category!=Stress' >"$lab/ubuntu-public.log" 2>&1
code=$?
tail -n 13 "$lab/ubuntu-public.log"
if test "$code" -ne 0; then exit "$code"; fi
~/.dotnet/dotnet test tests/Lokad.Lython.Tests/Lokad.Lython.Tests.csproj -c Release -f net10.0 --artifacts-path "$lab/ubuntu" --filter '(FullyQualifiedName~Generator|FullyQualifiedName~OrdinaryFunctionTransportTests|FullyQualifiedName~HelperLocalLifetimeTests)&Category!=Stress' >"$lab/ubuntu-whitebox.log" 2>&1
code=$?
tail -n 9 "$lab/ubuntu-whitebox.log"
exit "$code"
