from difflib import unified_diff
from pathlib import Path
import hashlib
import json
import os
import shutil
import subprocess
import zipfile

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
donor = lab.with_name("direct-record-helper-20261126")
template = lab.with_name("shipment-integer-store-20261126")
checkpoint = lab.with_name("record-field-cpython-20261126-retry") / "comparison/quiet"
invoice_catalog = lab.with_name("staged-csv-rows-20261126") / "comparison/quiet/representative.json"
read = lambda p: json.loads(p.read_text(encoding="utf-8"))
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
write = lambda p, s: p.write_text(s, encoding="utf-8", newline="\n")
git = lambda *args: subprocess.check_output(["git", *args], cwd=repo)
head = git("rev-parse", "bc93d4d74").decode().strip()
assert not git("diff", head, "--", "src")

base_image = read(checkpoint / "identity.json")["imageFiles"]["candidate"]
assert len(base_image) == 32 and {p.name: sha(p) for p in (donor / "candidate").iterdir()} == base_image
snapshot = lab / "source.zip"
subprocess.run(["git", "archive", "--format=zip", "--output", snapshot, head, "--", "src",
                "Directory.Build.props", "Directory.Build.targets", "Directory.Build.rsp",
                "Directory.Packages.props", "global.json", "NuGet.Config"], cwd=repo, check=True)
source = lab / "source"
with zipfile.ZipFile(snapshot) as archive:
    assert all(not Path(name).is_absolute() and ".." not in Path(name).parts for name in archive.namelist())
    archive.extractall(source)

catalog = read(checkpoint / "representative.json")
cases = list(catalog["cases"])
if invoice_catalog.is_file():
    invoice = [row for row in read(invoice_catalog)["cases"] if row["id"] == "scripts.csv-invoice.method-policy.quoted-control"]
    assert len(invoice) == 1
    cases.extend(invoice)
catalog["cases"] = [case | dict(runAsync=mode) for case in cases for mode in (False, True)]
write(lab / "cases.json", json.dumps(catalog, ensure_ascii=False))

names = ["BufferedCsvScan", "BorrowedCsvLine", "BorrowedCsvLineBytes",
         "UniversalNonNumericCsvLine", "LiteralCsvRecord", "LiteralCsvRecordBytes"]
patch = []
def instrument(relative, changes):
    path = source / relative
    original = path.read_text(encoding="utf-8")
    edited = original
    for old, new in changes:
        assert edited.count(old) == 1, old
        edited = edited.replace(old, new)
    write(path, edited)
    patch.extend(unified_diff(original.splitlines(keepends=True), edited.splitlines(keepends=True),
                              "a/" + relative, "b/" + relative))

runtime = "src/Lokad.Lython/Runtime/"
anchor = "    internal sealed class CsvRecordSource"
wire = "            if (TryDescribeLiteralRecord(line, out var nextField)) return PublishRecord(line, destination, dictionary);"
instrument(runtime + "LythonRuntime.CsvModule.cs", [
    (anchor, "".join(f"    internal static int Diagnostic{name};\n" for name in names) + "\n" + anchor),
    ("        internal bool CanBorrowNativeLine => _parser.CanDescribeLiteralRecord;",
     "        internal bool CanBorrowNativeLine => _parser.CanDescribeLiteralRecord;\n"
     "        internal bool DiagnosticNoNumericCoercion => _parser.DiagnosticNoNumericCoercion;"),
    ("        internal bool CanDescribeLiteralRecord =>",
     "        internal bool DiagnosticNoNumericCoercion => _options.Quoting != CsvQuotingMode.NonNumeric;\n\n"
     "        internal bool CanDescribeLiteralRecord =>"),
    (wire, """            if (TryDescribeLiteralRecord(line, out var nextField))
            {
                Interlocked.Increment(ref DiagnosticLiteralCsvRecord);
                Interlocked.Add(ref DiagnosticLiteralCsvRecordBytes, line.Length);
                return PublishRecord(line, destination, dictionary);
            }""")
])
instrument(runtime + "LythonRuntime.TextFileHandle.Read.cs", [
    ("                if (start == bytes.Length) return false;\n"
     "                var end = TextLineScanning.FindLineEndByte(bytes, start, _newline);",
     "                if (start == bytes.Length) return false;\n"
     "                Interlocked.Increment(ref DiagnosticBufferedCsvScan);\n"
     "                var end = TextLineScanning.FindLineEndByte(bytes, start, _newline);"),
    ("                fields = source.ConsumeBorrowedNativeLine(bytes[start..end], destination, dictionary);",
     "                Interlocked.Increment(ref DiagnosticBorrowedCsvLine);\n"
     "                Interlocked.Add(ref DiagnosticBorrowedCsvLineBytes, end - start);\n"
     "                if (_newline is TextNewlineMode.PreserveUniversal or TextNewlineMode.TranslateUniversal &&\n"
     "                    source.DiagnosticNoNumericCoercion)\n"
     "                    Interlocked.Increment(ref DiagnosticUniversalNonNumericCsvLine);\n"
     "                fields = source.ConsumeBorrowedNativeLine(bytes[start..end], destination, dictionary);")
])
write(lab / "diagnostic.patch", "".join(patch))
program = (template / "Program.cs").read_text(encoding="utf-8")
program = program.replace('["IntegerStoreCandidates", "IntegerStoreExisting", "IntegerStoreNativePrefix", "IntegerStorePackedKeys"]',
                          json.dumps(names)).replace("Lokad.Lython.Runtime.LythonRuntime+ExecutionContext",
                                                     "Lokad.Lython.Runtime.LythonRuntime")
write(lab / "Program.cs", program)
shutil.copyfile(template / "RouteProbe.csproj", lab / "RouteProbe.csproj")
image = lab / "image"
image.mkdir()
for name, digest in base_image.items():
    shutil.copyfile(donor / "candidate" / name, image / name)
    assert sha(image / name) == digest
sdk = Path.home() / ".dotnet11"
dotnet = sdk / "dotnet.exe"
environment = dict(os.environ, DOTNET_ROOT=str(sdk))
def run(args, name):
    with (lab / name).open("wb") as output:
        subprocess.run([dotnet, *args], stdout=output, stderr=subprocess.STDOUT,
                       cwd=repo, env=environment, check=True, timeout=160)
run(["build", source / "src/Lokad.Lython/Lokad.Lython.csproj", "-c", "Release",
     "-f", "net11.0", "--no-incremental", "-o", lab / "core"], "core.log")
shutil.copyfile(lab / "core/Lokad.Lython.dll", image / "Lokad.Lython.dll")
run(["build", lab / "RouteProbe.csproj", "-c", "Release", "-o", lab / "probe"], "probe.log")
for p in (lab / "probe").glob("RouteProbe*"):
    shutil.copyfile(p, image / p.name)
run([image / "RouteProbe.dll", image, lab / "cases.json", lab / "routes.json"], "verify.log")
write(lab / "identity.json", json.dumps(dict(referenceRevision=head, baseImage=base_image,
      diagnosticCoreSHA256=sha(image / "Lokad.Lython.dll"),
      patchSHA256=sha(lab / "diagnostic.patch"), catalogSHA256=sha(lab / "cases.json")), indent=2) + "\n")
for row in read(lab / "routes.json")["rows"]:
    print(row["id"], row["asynchronous"], row["routes"])
