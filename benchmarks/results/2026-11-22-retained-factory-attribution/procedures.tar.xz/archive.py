from pathlib import Path
import hashlib, json, shutil, tarfile

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
out=repo/"benchmarks/results/2026-11-22-retained-factory-attribution"
load=lambda p:json.loads(p.read_text(encoding="utf-8"))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
receipt=load(lab/"archive-receipt.json")
identity=load(lab/"identity.json")
terminal=load(lab/"terminal-status.json")
assert identity["sourceRevision"].startswith("4337b7765")
assert receipt==terminal["receipt"] and terminal["exitCode"]=="0"
for key in ("complete","allWorkersJoined","quietBeforeAndAfter","guestFixturesRemoved",
            "archivedAndVerifiedUnderLease","persistentTraceArchivedAndVerifiedBeforeUnmount"):
    assert receipt[key]
assert sha(lab/"observations.tgz")==receipt["archiveSHA256"]
files=identity["imageFiles"]["candidate"]
assert len(files)==32 and {n:sha(lab/"candidate"/n) for n in files}==files
assert load(lab/"verify.json")["state"]=="Completed" and sha(lab/"catalog.json")==identity["catalogSHA256"]
for row in load(lab/"attribution.json")["rows"]:
    record=load(lab/"retrieved/profiles"/row["label"]/"record.json")
    assert record["workload"]==row["case"] and record["exitCode"]==0 and record["closed"]["status"]=="Closed"
    assert record["verificationBefore"]["status"]==record["verificationAfter"]["status"]=="Equivalent"
    assert record["response"]["completedInvocations"]>0
    assert all(b["status"]=="Completed" and b["actualOutputSha256"]==record["verificationBefore"]["actualOutputSha256"] for b in record["batches"])
out.mkdir(exist_ok=False)
for name in ("observations.tgz","archive-receipt.json","attribution.json","terminal-status.json","README.md"):
    shutil.copyfile(lab/name,out/name)
with tarfile.open(out/"procedures.tar.xz","w:xz") as dst:
    for name in ("archive.py","launch.py","remote-launch.py","ops-profile.py","collect.py",
                 "analyze.py","retrieve.py","run.sh","identity.json","config.json","catalog.json","verify.json",
                 "launch.log","observe-not-before.json"):
        dst.add(lab/name,arcname=name)
print("B1310 raw profiles, identity, verification and analysis archived.")
