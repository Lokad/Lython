from pathlib import Path
import json,re,subprocess,tempfile,textwrap
source=Path('tests/Lokad.Lython.PublicApi.Tests/FnmatchSuspendedIterationTests.cs').read_text(encoding='utf-8')
programs=[textwrap.dedent(m.group(1)).strip()+'\n' for m in re.finditer(r'"""(.*?)"""',source,re.S)][:4]
assert len(programs)==4
rows=[]
for index,program in enumerate(programs):
    with tempfile.TemporaryDirectory(prefix='lython-fnmatch-r148-') as temporary:
        path=Path(temporary)/'names'
        path.write_text('alpha.txt\nbeta.md\né😀.txt\n',encoding='utf-8')
        trusted=program.replace("'/names'",repr(path.as_posix()))
        trusted=re.sub(r'^return (fnmatch.filter\(.*\))$',r'print(\1)',trusted,flags=re.M)
        done=subprocess.run(['C:/Python313/python.exe','-I','-S','-X','utf8','-c',trusted],capture_output=True,encoding='utf-8',timeout=10)
        expected="['alpha.txt', 'é😀.txt']\n" if index<3 else "['a', 'bad', 'type'] later.txt\nTrue\n"
        assert done.returncode==0 and not done.stderr and done.stdout==expected,(index,done)
        rows.append(dict(originalLythonSource=program,pythonSource=trusted,stdout=done.stdout,
                         transformation='Top-level Lython return displayed with print; virtual input path mapped to owned fixture. Other source unchanged.'))
Path(__file__).with_name('python-goldens.json').write_text(json.dumps(rows,indent=2,ensure_ascii=False),encoding='utf-8')
print('Four independently checked CPython3.13 file/iterator/error/identity goldens pass.')
