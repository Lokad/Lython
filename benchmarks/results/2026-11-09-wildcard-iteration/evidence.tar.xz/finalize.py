from pathlib import Path
import hashlib,json,shutil,subprocess,tarfile
r=Path(__file__).parent
out=Path('benchmarks/results/2026-11-09-wildcard-iteration')
out.mkdir(exist_ok=True)
proof=dict(baselineSource='7af1c86b',baseline='RunAsync fails with open_file cannot run synchronously while fnmatch.filter consumes a file-backed generator.',
           implementation='One existing cursor loop: use active API for acquisition/pulls/disposal. Remove sync-only ToSequence consumer; keep native UTF8 matching, no regex producer or new dispatch infrastructure.',
           focusedPerFramework=305,actualFrameworks=['net11.0','net10.0'],newCases=10,independentPythonGoldens=4,
           validated='Generator/user __iter__/__next__ suspension; cancellation waits for gated native cleanup without refunding active storage; first invalid item/retained iterator/name identity; terminal admission refusal prevents output despite handler; same shared allowance reusable after cleanup.',
           qualification='Focused Release complete. Full platform/Stress/installed-package checks batch at next coherent delivery; prior R145 fully qualified on58d3. Publication postponed.',
           performance='No speedup claim. This fixes capability dispatch; before/after includes failing async case, passing synchronous control, successful genuine suspension and unwind. No new benchmark framework or producer replay.',
           productionSources={'src/Lokad.Lython/Runtime/LythonRuntime.FnMatchModule.cs':hashlib.sha256(Path('src/Lokad.Lython/Runtime/LythonRuntime.FnMatchModule.cs').read_bytes()).hexdigest()})
(out/'validation.json').write_text(json.dumps(proof,indent=2),encoding='utf-8')
shutil.copyfile(r/'python-goldens.json',out/'python-goldens.json')
(r/'source.patch').write_bytes(subprocess.check_output(['git','diff','--binary','--','src/Lokad.Lython']))
with tarfile.open(out/'evidence.tar.xz','w:xz') as archive:
    for p in r.iterdir():
        if p.is_file():archive.add(p,arcname=p.name)
    archive.add('tests/Lokad.Lython.PublicApi.Tests/FnmatchSuspendedIterationTests.cs',arcname='FnmatchSuspendedIterationTests.cs')
print('Original regression, independent goldens, implementation and focused actual11/10 checks archived; no CPU claim.')
