from pathlib import Path
import gzip, hashlib, json, subprocess

r = Path(__file__).parent
repo = Path('D:/code/Lython')
canonical = 'benchmarks/results/2026-11-17-float-transport/refined/candidate-core.dll.gz'
blob = subprocess.check_output(['git', 'show', 'HEAD:' + canonical], cwd=repo)
assert blob == (repo / canonical).read_bytes()
data = gzip.decompress(blob)
sha = hashlib.sha256(data).hexdigest()
code = '''from pathlib import Path
import fcntl,hashlib,json,os,stat,subprocess,shutil
b=Path('/home/lokad/lython-bench-checks')
with(b/'comparison-vm.lock').open('a')as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 workers=subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record|[p]ython3.*cpython-worker.py'],capture_output=True,text=True).stdout
 own={str(os.getpid()),str(os.getppid())};assert all(line.split(maxsplit=1)[0]in own for line in workers.splitlines()),workers
 assert not any(os.path.ismount(p)for p in b.glob('*/guest-fixtures'))
 groups={}
 for p in b.glob('*/*/Lokad.Lython.dll'):
  m=p.lstat();key=(m.st_dev,m.st_ino)
  if key not in groups:groups[key]=dict(sha256=hashlib.sha256(p.read_bytes()).hexdigest(),bytes=m.st_size,links=m.st_nlink,uid=m.st_uid,paths=[])
  groups[key]['paths'].append(str(p.relative_to(b)))
 selected=[key for key,g in groups.items()if g['sha256']==SHA]
 assert len(selected)==1
 aliases=[]
 for base,dirs,names in os.walk(b):
  for name in names:
   p=Path(base)/name;m=p.lstat()
   if(m.st_dev,m.st_ino)==selected[0]:aliases.append(str(p.relative_to(b)))
 result=dict(cores=list(groups.values()),selected=groups[selected[0]]|dict(paths=aliases),archives=[dict(path=str(p.relative_to(b)),bytes=p.stat().st_size)for p in b.glob('*/observations.tgz')],freeBytes=shutil.disk_usage(b).free)
 print(json.dumps(result))
'''.replace('SHA', repr(sha))
ssh = ['C:/Windows/System32/OpenSSH/ssh.exe', '-i', 'C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem', '-o', 'BatchMode=yes', '-o', 'ConnectTimeout=15', 'lokad@20.166.121.73']
p = subprocess.run(ssh + ['python3 -'], input=code, text=True, encoding='utf-8', capture_output=True)
assert p.returncode == 0, p.stdout + p.stderr
value = json.loads(p.stdout)
(r / 'working-image-inspection.json').write_text(json.dumps(value, indent=2) + '\n', encoding='utf-8')
selected = value['selected']
assert len(selected['paths']) == selected['links'] and selected['uid'] == 1000 and selected['bytes'] == len(data)
proof = dict(paths=selected['paths'], bytes=len(data), links=selected['links'], sha256=sha, canonical=canonical, canonicalSHA256=hashlib.sha256(blob).hexdigest(), member='gzip-payload', committedBlobVerified=True, supersededQualifiedSource='dc480d38 fully replaced by qualifiedabcbd9fd/currentca1a8239; exact historical source/core kept committed')
(r / 'superseded-core-proof.json').write_text(json.dumps(proof, indent=2) + '\n', encoding='utf-8')
print('Current working core groups:', json.dumps(value['cores']))
print('Superseded5ec core all aliases proven; currentca1 remains. Archives:', json.dumps(value['archives']))
