from pathlib import Path
import hashlib, json, os, shutil, subprocess, tarfile

r = Path(__file__).parent
repo = Path('D:/code/Lython')
work = repo / '.git/agent-worktrees/call-operands-r470'
old = r.parent / 'generator-sum-r475'
frozen = r / 'frozen'; frozen.mkdir(exist_ok=False)
prior = json.loads((old / 'frozen/identity.json').read_text(encoding='utf-8'))['imageFiles']['candidate']
for role in ['reference', 'candidate']:
    target = frozen / role; target.mkdir()
    for name, sha in prior.items():
        source = old / 'frozen/candidate' / name
        assert hashlib.sha256(source.read_bytes()).hexdigest() == sha, name
        shutil.copyfile(source, target / name)
    if role == 'candidate': shutil.copyfile(work / 'src/Lokad.Lython/bin/Release/net11.0/Lokad.Lython.dll', target / 'Lokad.Lython.dll')
    for p in (old / 'frozen/candidate').glob('ValidatedAllocation.*'): shutil.copyfile(p, target / p.name)
images = {role: {name: hashlib.sha256((frozen / role / name).read_bytes()).hexdigest() for name in prior} for role in ['reference', 'candidate']}
assert [name for name in prior if images['reference'][name] != images['candidate'][name]] == ['Lokad.Lython.dll']
names = list(json.loads((old / 'delivery/inputs.json').read_text(encoding='utf-8'))['inputs']) + ['tests/Lokad.Lython.PublicApi.Tests/ClosedBuiltinResultTests.cs']
inputs = {name: hashlib.sha256((work / name).read_bytes()).hexdigest() for name in names}
with tarfile.open(r / 'candidate-sources.tar.xz', 'w:xz') as archive:
    for name in inputs: archive.add(work / name, arcname=name)
production = [name for name in names if name.startswith('src/Lokad.Lython/')]
different = [name for name in production if (work / name).read_text(encoding='utf-8-sig') != (repo / name).read_text(encoding='utf-8-sig')]
expected = ['LythonRuntime.BuiltinIterables.Aggregates.cs', 'LythonRuntime.BuiltinIterables.cs', 'LythonRuntime.Builtins.ObjectAndBytes.cs', 'LythonRuntime.Builtins.cs', 'LythonRuntime.Calls.cs', 'LythonRuntime.Executable.NativeCalls.cs', 'LythonRuntime.Executable.NativePrefix.cs']
assert sorted(different) == sorted('src/Lokad.Lython/Runtime/' + name for name in expected), different
identity = dict(referenceSource='Qualifiedabcbd9fd/frozenca1a8239 GREEN44041981387', candidateSource='PrivateR477 onb38d7552: one executable-slot result convention replaces Delegate signatures/boxing/native repacking; seven production files, no new owner/backend/metadata', imageFiles=images, sourceInputs=inputs, productionFiles=len(production), changedProductionFiles=different, catalogSHA256=hashlib.sha256((r / 'catalog.json').read_bytes()).hexdigest(), normalAdapterPin='0.4.0', publicationHeld=True)
(frozen / 'identity.json').write_text(json.dumps(identity, indent=2) + '\n', encoding='utf-8')
dotnet = Path('C:/Users/JoannesVermorel/.dotnet11/dotnet.exe')
env = os.environ.copy(); env.update(DOTNET_ROOT=str(dotnet.parent), DOTNET_ROOT_X64=str(dotnet.parent)); env['PATH'] = str(dotnet.parent) + os.pathsep + env['PATH']
for role in ['reference', 'candidate']:
    image = frozen / role
    with (r / (role + '-preflight.log')).open('w', encoding='utf-8') as log:
        p = subprocess.run([str(dotnet), str(image / 'Lokad.Lython.Benchmarks.dll'), '--compare', 'verify', '--catalog', str(r / 'catalog.json'), '--dotnet', str(dotnet), '--python', 'C:/Python313/python.exe', '--python-worker', str(repo / 'benchmarks/cpython-worker.py'), '--out', str(r / (role + '-preflight.json'))], env=env, stdout=log, stderr=subprocess.STDOUT)
    assert p.returncode == 0, (r / (role + '-preflight.log')).read_text(encoding='utf-8')
    print(role, 'actual frozen3case worker/CPython goldens pass', flush=True)
    with (r / (role + '-allocation.log')).open('w', encoding='utf-8') as log:
        p = subprocess.run([str(dotnet), str(image / 'ValidatedAllocation.dll'), str(image), str(r / 'catalog.json'), str(r / (role + '-allocation.json'))], env=env, stdout=log, stderr=subprocess.STDOUT)
    assert p.returncode == 0, (r / (role + '-allocation.log')).read_text(encoding='utf-8')
    for row in json.loads((r / (role + '-allocation.json')).read_text(encoding='utf-8'))['rows']:
        assert row['sharedBudgetBaselineRestored']
        print(role, row['id'], row['allocatedBytesPerInvocation'], row['peakExecutionMemoryBytes'], flush=True)
print('Frozen copied32file images/585production sources, only core differs:', images['candidate']['Lokad.Lython.dll'])
