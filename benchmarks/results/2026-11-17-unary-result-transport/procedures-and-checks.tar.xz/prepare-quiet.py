from pathlib import Path
import ast, hashlib, json, shutil, subprocess, tarfile

r = Path(__file__).parent
repo = Path('D:/code/Lython')
old = r.parent / 'generator-sum-r475'
q = r / 'quiet'; q.mkdir(exist_ok=False)
remote = '/home/lokad/lython-bench-checks/unary-slot-results-b889-20261117'
f = json.loads((r / 'frozen/identity.json').read_text(encoding='utf-8'))
source_config = json.loads((old / 'cpython-focused/quiet/config.json').read_text(encoding='utf-8'))
reference = f['imageFiles']['reference']['Lokad.Lython.dll']
candidate = f['imageFiles']['candidate']['Lokad.Lython.dll']
identity = dict(sourceRevision='Qualifiedabcbd9fd/frozenca1a8239 versus privateR477 onb38d7552/frozen' + candidate,
    purpose='One executable-slot result convention for closed unary builtin calls removes Delegate/signature bridge and native repacking; fresh int/len/float remain private until observation. Complete numeric CSV warm/fresh/compile plus original integer CSV and text controls.',
    coreSHA256={'reference': reference, 'reference-control': reference, 'candidate': candidate, 'candidate-control': candidate},
    imageFiles=f['imageFiles'], auxiliaryFiles={n:h for n,h in f['imageFiles']['reference'].items() if n != 'Lokad.Lython.dll'},
    sourceInputsArchiveSHA256=hashlib.sha256((r / 'candidate-sources.tar.xz').read_bytes()).hexdigest(), productionFiles=585,
    catalogSHA256=f['catalogSHA256'], catalogInitialization='Actual-worker-verified3case catalog; same127031B CSV fixture for new numeric script and original invoice, helper text control; interleaved6s warmups and five rotated samples.', normalAdapterPin='0.4.0', publicationHeld=True)
(q / 'identity.json').write_text(json.dumps(identity, indent=2) + '\n', encoding='utf-8')
jobs = [['scripts.csv-numeric-quality.large', lane] for lane in ['warm', 'compile-run']] + [['scripts.csv-invoice.large', 'warm'], ['scripts.text-normalization.helper-list', 'warm'], ['scripts.csv-numeric-quality.large', 'compile']]
s = (old / 'quiet/collect.py').read_text(encoding='utf-8')
a = s.index('jobs='); b = s.index('\nenv =', a)
s = s[:a] + 'jobs=' + repr(jobs) + '\nassert len(jobs)==5 and all(case in cases for case,lane in jobs)\n' + s[b:]
(q / 'collect.py').write_text(s, encoding='utf-8', newline='\n')
shutil.copyfile(old / 'quiet/archive-owned.py', q / 'archive-owned.py')
(q / 'run.sh').write_text((old / 'quiet/run.sh').read_text(encoding='utf-8').replace('/home/lokad/lython-bench-checks/generator-sum-b886-20261117', remote), encoding='utf-8', newline='\n')
(q / 'candidate').mkdir(); shutil.copyfile(r / 'frozen/candidate/Lokad.Lython.dll', q / 'candidate/Lokad.Lython.dll')
shutil.copyfile(r / 'catalog.json', q / 'representative.json')
groups = [json.loads((r / 'superseded-core-proof.json').read_text(encoding='utf-8'))]
for proof in groups:
    blob = subprocess.check_output(['git', 'show', 'HEAD:' + proof['canonical']], cwd=repo)
    assert hashlib.sha256(blob).hexdigest() == proof['canonicalSHA256'] and blob == (repo / proof['canonical']).read_bytes()
for canonical, path in [
    ('benchmarks/results/2026-11-17-current-script-costs/observations.tgz', 'current-script-costs-b888-20261117/observations.tgz'),
    ('benchmarks/results/2026-11-17-current-pipeline-attribution/observations.tgz', 'current-pipeline-b869-20261117/observations.tgz'),
    ('benchmarks/results/2026-11-17-call-operand-forwarding/first-pair/observations.tgz', 'call-operands-b876-20261117/observations.tgz'),
    ('benchmarks/results/2026-11-17-call-operand-forwarding/confirmation/observations.tgz', 'call-operands-b877-20261117/observations.tgz')]:
    blob = subprocess.check_output(['git', 'show', 'HEAD:' + canonical], cwd=repo)
    assert blob == (repo / canonical).read_bytes()
    groups.append(dict(paths=[path], bytes=len(blob), links=1, sha256=hashlib.sha256(blob).hexdigest(), canonical=canonical, canonicalSHA256=hashlib.sha256(blob).hexdigest(), member='whole-archive', committedBlobVerified=True))
names = ['collect.py', 'archive-owned.py', 'run.sh', 'identity.json', 'representative.json', 'candidate/Lokad.Lython.dll']
with tarfile.open(q / 'payload.tgz', 'w:gz') as archive:
    for name in names: archive.add(q / name, arcname=name)
c = dict(root=remote, unit='lython-b889-unary-slot-results-20261117', source=source_config['root'], sourceRole='candidate', sourceFiles=f['imageFiles']['reference'], sourceCatalogSHA256=source_config['catalogSHA256'], catalogSHA256=f['catalogSHA256'], identity=identity, retireGroups=groups,
    payloadBytes=(q / 'payload.tgz').stat().st_size, payloadSHA256=hashlib.sha256((q / 'payload.tgz').read_bytes()).hexdigest(), unpackedBytes=sum((q / name).stat().st_size for name in names))
(q / 'config.json').write_text(json.dumps(c, indent=2) + '\n', encoding='utf-8')
s = (old / 'quiet/remote-launch.py').read_text(encoding='utf-8'); a = s.index('c='); b = s.index('\nb=Path(', a); s = s[:a] + 'c=' + repr(c) + s[b:]
s = s.replace(" os.link(source/'representative.json',root/'representative.json')", " # Custom catalog was verified with both actual images before payload staging.")
s = s.replace('lython-b886-fixtures', 'lython-b889-fixtures')
(q / 'remote-launch.py').write_text(s, encoding='utf-8', newline='\n')
(r / 'launch.py').write_text((old / 'launch.py').read_text(encoding='utf-8').replace('generator-sum', 'unary-slot-results'), encoding='utf-8', newline='\n')
(q / 'retrieve.py').write_text((old / 'quiet/retrieve.py').read_text(encoding='utf-8').replace('B886', 'B889'), encoding='utf-8', newline='\n')
shutil.copyfile(old / 'summarize.py', r / 'summarize.py')
for p in list(q.glob('*.py')) + [r / 'launch.py', r / 'summarize.py']: ast.parse(p.read_text(encoding='utf-8'))
print('Prepared5jobs, stage', c['unpackedBytes'], 'retire only superseded5ec core8aliases and committed evidence replicas', sum(g['bytes'] for g in groups), 'currentca1 preserved; candidate', candidate)
