from pathlib import Path
import base64, copy, hashlib, json, struct, subprocess, tempfile

r = Path(__file__).parent
old = r.parent / 'generator-sum-r475'
catalog = json.loads((old / 'catalog.json').read_text(encoding='utf-8'))
template = next(c for c in catalog['cases'] if c['id'] == 'scripts.csv-invoice.large')
source = '''import csv

def reading(row):
    return float(row['unit_cents']) * 0.01

count = 0
total = 0.0
energy = 0.0
with open('input.csv', newline='') as stream:
    for row in csv.DictReader(stream):
        quantity = float(row['quantity'])
        value = reading(row)
        total += quantity * value
        energy += value * value
        count += 1
with open('quality.txt', 'w', newline='') as target:
    target.write(f'records={count}\\ntotal={total:.3f}\\nenergy={energy:.3f}\\n')
print(count)
'''
fixture = json.loads(template['fixtureJson'])
with tempfile.TemporaryDirectory(prefix='lython-unary-csv-golden-') as temporary:
    root = Path(temporary)
    for name, payload in fixture['inputFiles'].items():
        target = root / name; target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(base64.b64decode(payload))
    script = root / 'quality.py'; script.write_text(source, encoding='utf-8')
    run = subprocess.run(['C:/Python313/python.exe', '-X', 'utf8', '-I', str(script)], cwd=root, text=True, encoding='utf-8', capture_output=True)
    assert run.returncode == 0, run.stderr
    output = (root / 'quality.txt').read_bytes()
    expected = run.stdout
fixture['outputFiles'] = {'quality.txt': base64.b64encode(output).decode('ascii')}
fixture_json = json.dumps(fixture, separators=(',', ':'), ensure_ascii=True)
case = copy.deepcopy(template)
case.update(id='scripts.csv-numeric-quality.large', source=source, fixtureJson=fixture_json, expectedOutput=expected,
    sourceUtf8Bytes=len(source.encode('utf-8')), expectedOutputUtf8Bytes=len(expected.encode('utf-8')),
    sourceSha256=hashlib.sha256(source.encode('utf-8')).hexdigest(), fixtureSha256=hashlib.sha256(fixture_json.encode('utf-8')).hexdigest(),
    expectedOutputSha256=hashlib.sha256(expected.encode('utf-8')).hexdigest())
digest = hashlib.sha256()
def number(n): digest.update(struct.pack('>i', n))
number(1)
name = b'quality.txt'; number(len(name)); digest.update(name); number(len(output)); digest.update(output)
case['expectedFilesSha256'] = digest.hexdigest()
cases = [case] + [c for c in catalog['cases'] if c['id'] in ['scripts.csv-invoice.large', 'scripts.text-normalization.helper-list']]
catalog['cases'] = cases
(r / 'catalog.json').write_text(json.dumps(catalog, indent=2) + '\n', encoding='utf-8')
(r / 'case.json').write_text(json.dumps(case, indent=2) + '\n', encoding='utf-8')
(r / 'golden.json').write_text(json.dumps(dict(reference='CPython3.13.2 isolated trusted script, unchanged127031B/4096record CSV fixture', source=source, stdout=expected, files={'quality.txt': output.decode('utf-8')}, case=case['id']), indent=2) + '\n', encoding='utf-8')
print('Existing worker catalog: one complete numeric CSV report plus original integer CSV/text controls;', (r / 'catalog.json').stat().st_size, 'bytes; golden', output.decode('utf-8'))
