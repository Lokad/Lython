from pathlib import Path
w = Path('D:/code/Lython/.git/agent-worktrees/call-operands-r470/src/Lokad.Lython/Runtime')
def edit(name, pairs):
    p = w / name
    s = p.read_text(encoding='utf-8-sig')
    for old, new in pairs:
        assert old in s, (name, old)
        s = s.replace(old, new)
    p.write_text(s, encoding='utf-8', newline='\n')
edit('LythonRuntime.Builtins.cs', [
    ('Func<object, LythonSourceSpan, ExecutionContext, object> NativeStrOperation', 'Func<object, LythonSourceSpan, ExecutionContext, ExecutableSlot> NativeStrOperation'),
    ('=> PyRendering.ToInterpolatedPyString(value, new PyRenderingContext(context));', '=> ExecutableSlot.FromObject(PyRendering.ToInterpolatedPyString(value, new PyRenderingContext(context)));'),
    ('return NativeStrOperation(bound.Values[0], span, context);', 'return NativeStrOperation(bound.Values[0], span, context).Object.RequireNotNull();'),
    ('Func<object, LythonSourceSpan, ExecutionContext, BigInteger> IntegerTextOperation', 'Func<object, LythonSourceSpan, ExecutionContext, ExecutableSlot> IntegerTextOperation'),
    ('=> ParseOwnedIntegerText(value, 10, context, span);', '=> NativeIntegerResult(ParseOwnedIntegerText(value, 10, context, span));'),
    ('Func<object, LythonSourceSpan, ExecutionContext, object> AbsoluteOperation', 'Func<object, LythonSourceSpan, ExecutionContext, ExecutableSlot> AbsoluteOperation'),
    ('=> AbsValueWithoutProtocols(value, context, span);', '=> ExecutableSlot.FromObject(AbsValueWithoutProtocols(value, context, span));'),
])
edit('LythonRuntime.Builtins.ObjectAndBytes.cs', [
    ('Func<object, LythonSourceSpan, ExecutionContext, object> FloatTextOperation\n        = static (value, span, context) => ParseOwnedFloatText(value, context, span);', '''Func<object, LythonSourceSpan, ExecutionContext, ExecutableSlot> FloatTextOperation
        = static (value, span, context) =>
        {
            ExecutableSlot result = default;
            result.SetDouble(ParseOwnedFloatText(value, context, span));
            return result;
        };'''),
])
edit('LythonRuntime.BuiltinIterables.cs', [
    ('Func<object, LythonSourceSpan, ExecutionContext, BigInteger> LengthOperation = GetLength;', 'Func<object, LythonSourceSpan, ExecutionContext, ExecutableSlot> LengthOperation\n        = static (value, span, context) => NativeIntegerResult(GetLength(value, span, context));'),
])
edit('LythonRuntime.BuiltinIterables.Aggregates.cs', [
    ('Func<object, LythonSourceSpan, ExecutionContext, object> SumBytesOperation', 'Func<object, LythonSourceSpan, ExecutionContext, ExecutableSlot> SumBytesOperation'),
    ('=> SumExactBytes((PyBytes)bytes, BigInteger.Zero, span, context);', '=> ExecutableSlot.FromObject(SumExactBytes((PyBytes)bytes, BigInteger.Zero, span, context));'),
])
edit('LythonRuntime.Executable.NativeCalls.cs', [
    ('private static Delegate? SelectNativeUnaryOperation(', 'private static Func<object, LythonSourceSpan, ExecutionContext, ExecutableSlot>? SelectNativeUnaryOperation('),
    ('    // A closed operation cannot invoke guest protocols.', '''    // Fresh integer results share the same private result convention as
    // floating parses. Large results keep their existing admitted object owner.
    private static ExecutableSlot NativeIntegerResult(BigInteger value)
        => TryMachineInteger(value, out var small) ? ExecutableSlot.FromInteger(small)
            : ExecutableSlot.FromObject(value);

    // A closed operation cannot invoke guest protocols.'''),
])
edit('LythonRuntime.Executable.NativePrefix.cs', [
    ('''                    if (operation is not null && closed)
                    {
                        if (operation is Func<object, LythonSourceSpan, ExecutionContext, BigInteger> integerOperation)
                        {
                            var integer = InvokeSingleInput(argument!, integerOperation, call.CallSpan, _scope);
                            if (TryMachineInteger(integer, out var integerResult)) result.SetInteger(integerResult);
                            else result.Object = integer;
                        }
                        else result.Object = InvokeSingleInput(argument!, operation, call.CallSpan, _scope);
                    }''', '''                    if (operation is not null && closed)
                        result = InvokeSingleInput(argument!, operation, call.CallSpan, _scope);'''),
])
p = w / 'LythonRuntime.Calls.cs'
s = p.read_text(encoding='utf-8-sig')
a = s.index('    // The selector has just these two result signatures.')
b = s.index('    {\n        context.EnterInterpreterFrame(span);', a)
s = s[:a] + '''    // Completed builtin calls share one result convention with executable
    // operands. Observation/publication owns materialization, not this boundary.
    private static ExecutableSlot InvokeSingleInput(object value,
        Func<object, LythonSourceSpan, ExecutionContext, ExecutableSlot> operation,
        LythonSourceSpan span, ExecutionContext context)
''' + s[b:]
p.write_text(s, encoding='utf-8', newline='\n')
print('R477: one existing-slot result convention replaces Delegate/signature bridge and native-only scalar repacking. No new owner/backend/metadata.')
