from pathlib import Path
import json,statistics
r=Path(__file__).resolve().parent;raw=json.loads((r/'quiet/retrieved/confirmation/confirmation.json').read_text(encoding='utf-8'));assert raw['complete']and len(raw['jobs'])==3;rows=[]
for job in raw['jobs']:
 med={};cpu={};iqr={}
 for label in job['identities']:
  values=[s for s in job['samples']if s['engine']==label]
  times=[s['response']['elapsedTicks']/s['response']['clockFrequency']/s['response']['completedInvocations']*1000 for s in values]
  med[label]=statistics.median(times);q=statistics.quantiles(times,n=4,method='inclusive');iqr[label]=(q[2]-q[0])/med[label]*100
  cpu[label]=statistics.median(s['externalProcessCpuTicks']/s['externalCpuFrequency']/s['response']['completedInvocations']*1000 for s in values)
 spread=lambda a,b:(max(med[a],med[b])/min(med[a],med[b])-1)*100
 ratios=sorted(med[a]/med[b]for a in ['candidate','candidate-control']for b in ['CPython','CPython-control'])
 rows.append(dict(case=job['case'],lane=job['lane'],medianMilliseconds=med,widerCpuMilliseconds=cpu,ratioRange=ratios,lythonControlPercent=spread('candidate','candidate-control'),cpythonControlPercent=spread('CPython','CPython-control'),maxIqrPercent=max(iqr.values()),iqrPercent=iqr))
summary=dict(complete=True,elapsedSeconds=raw['elapsedSeconds'],timing=rows,performanceQualified=False,causalSourceGainClaim=False,allUsersJoined=True,quietBeforeAndAfter=True)
(r/'summary.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8',newline='\n')
for x in rows:print(x['case'],x['lane'],'Lython/CPython',x['ratioRange'],'controls',x['lythonControlPercent'],x['cpythonControlPercent'],'maxIQR',x['maxIqrPercent'])
