from pathlib import Path
import ast, hashlib, io, json, subprocess, tarfile

base = Path(__file__).parent
r = base / 'cpython'; r.mkdir(exist_ok=False)
q = r / 'quiet'; q.mkdir()
repo = Path('D:/code/Lython')
old = base.parent / 'floating-transport-r471/cpython'
f = json.loads((base / 'frozen/identity.json').read_text(encoding='utf-8'))
prior = json.loads((base / 'quiet/config.json').read_text(encoding='utf-8'))
remote = '/home/lokad/lython-bench-checks/unary-cpython-b891-20261117'
identity = dict(sourceRevision='Committedd8611c85/frozen0315de0a', purpose='Fill primary external baseline for the new complete numericCSV/report. Compilation,warm,fresh separated against stockCPython3.13.16. Existing actual-worker-verified3case catalog; no causal gains across collections.',
    coreSHA256={'candidate': f['imageFiles']['candidate']['Lokad.Lython.dll'], 'candidate-control': f['imageFiles']['candidate']['Lokad.Lython.dll']},
    auxiliaryFiles={n:h for n,h in f['imageFiles']['candidate'].items() if n != 'Lokad.Lython.dll'}, imageFiles={'candidate': f['imageFiles']['candidate']},
    sourceInputsArchiveSHA256=hashlib.sha256((base / 'candidate-sources.tar.xz').read_bytes()).hexdigest(), productionFiles=585, catalogSHA256=f['catalogSHA256'], normalAdapterPin='0.4.0', publicationHeld=True)
(q / 'identity.json').write_text(json.dumps(identity, indent=2) + '\n', encoding='utf-8')
for name in ['collect.py', 'archive-owned.py']:
    s = (old / 'quiet' / name).read_text(encoding='utf-8').replace('scripts.numeric-squared-error.floating.large', 'scripts.csv-numeric-quality.large')
    (q / name).write_text(s, encoding='utf-8', newline='\n')
(q / 'run.sh').write_text((old / 'quiet/run.sh').read_text(encoding='utf-8').replace('/home/lokad/lython-bench-checks/float-cpython-b881-20261117', remote), encoding='utf-8', newline='\n')
groups = []
for canonical, prefix, raw_members in [
    ('benchmarks/results/2026-11-17-unary-result-transport/confirmation/observations.tgz', 'unary-slot-confirm-b890-20261117', ['confirmation/confirmation.json', '__pycache__/cpython-worker.cpython-312.pyc']),
    ('benchmarks/results/2026-11-17-unary-result-transport/first-pair/observations.tgz', 'unary-slot-results-b889-20261117', ['__pycache__/cpython-worker.cpython-312.pyc']),
    ('benchmarks/results/2026-11-17-float-transport/first/source-pair/observations.tgz', 'float-transport-b878-20261117', []),
    ('benchmarks/results/2026-11-17-float-transport/first/integer-confirmation/observations.tgz', 'float-control-b879-20261117', [])]:
    blob = subprocess.check_output(['git', 'show', 'HEAD:' + canonical], cwd=repo)
    assert blob == (repo / canonical).read_bytes()
    with tarfile.open(fileobj=io.BytesIO(blob)) as archive:
        for member in raw_members:
            data = archive.extractfile(member).read()
            groups.append(dict(paths=[prefix + '/' + member], bytes=len(data), links=1, sha256=hashlib.sha256(data).hexdigest(), canonical=canonical, canonicalSHA256=hashlib.sha256(blob).hexdigest(), member=member, committedBlobVerified=True))
    if len(raw_members) != 1:
        groups.append(dict(paths=[prefix + '/observations.tgz'], bytes=len(blob), links=1, sha256=hashlib.sha256(blob).hexdigest(), canonical=canonical, canonicalSHA256=hashlib.sha256(blob).hexdigest(), member='whole-archive', committedBlobVerified=True))
names = ['collect.py', 'archive-owned.py', 'run.sh', 'identity.json']
with tarfile.open(q / 'payload.tgz', 'w:gz') as archive:
    for name in names: archive.add(q / name, arcname=name)
c = dict(root=remote, unit='lython-b891-unary-cpython-20261117', source=prior['root'], sourceRole='candidate', sourceFiles=f['imageFiles']['candidate'], sourceCatalogSHA256=f['catalogSHA256'], catalogSHA256=f['catalogSHA256'], identity=identity, retireGroups=groups,
    payloadBytes=(q / 'payload.tgz').stat().st_size, payloadSHA256=hashlib.sha256((q / 'payload.tgz').read_bytes()).hexdigest(), unpackedBytes=sum((q / name).stat().st_size for name in names))
(q / 'config.json').write_text(json.dumps(c, indent=2) + '\n', encoding='utf-8')
s = (old / 'quiet/remote-launch.py').read_text(encoding='utf-8'); a = s.index('c='); b = s.index('\nb=Path(', a); s = s[:a] + 'c=' + repr(c) + s[b:]
s = s.replace("for role in ['reference','candidate']:", "for role in ['candidate']:").replace('lython-b881-fixtures', 'lython-b891-fixtures')
(q / 'remote-launch.py').write_text(s, encoding='utf-8', newline='\n')
for name in ['launch.py', 'summarize.py']:
    (r / name).write_text((old / name).read_text(encoding='utf-8').replace('floating CPython baseline', 'numeric CSV CPython baseline'), encoding='utf-8', newline='\n')
(q / 'retrieve.py').write_text((old / 'quiet/retrieve.py').read_text(encoding='utf-8').replace('B881', 'B891'), encoding='utf-8', newline='\n')
for p in list(q.glob('*.py')) + list(r.glob('*.py')): ast.parse(p.read_text(encoding='utf-8'))
print('Prepared3phase material-gap CPython baseline, stage', c['unpackedBytes'], 'retire only', sum(g['bytes'] for g in groups), 'exact committed raw/archive/bytecode-cache replicas; both current measured cores preserved.')
