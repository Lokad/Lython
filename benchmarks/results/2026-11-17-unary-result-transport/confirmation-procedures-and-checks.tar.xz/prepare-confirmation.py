from pathlib import Path
import ast, hashlib, io, json, shutil, subprocess, tarfile

base = Path(__file__).parent
r = base / 'confirm'; r.mkdir(exist_ok=False)
q = r / 'quiet'; q.mkdir()
repo = Path('D:/code/Lython')
old = base / 'quiet'
prior = json.loads((old / 'config.json').read_text(encoding='utf-8'))
remote = '/home/lokad/lython-bench-checks/unary-slot-confirm-b890-20261117'
identity = dict(prior['identity'])
identity['purpose'] = 'One bounded unchanged-image confirmation of numericCSV warm/fresh after moving first fresh reference and warm uncertainty. Same source/catalog/controls;8s interleaved full-request warmup; retain original conditions.'
(q / 'identity.json').write_text(json.dumps(identity, indent=2) + '\n', encoding='utf-8')
s = (old / 'collect.py').read_text(encoding='utf-8')
a = s.index('jobs='); b = s.index('\nenv =', a)
s = s[:a] + "jobs=[['scripts.csv-numeric-quality.large','warm'],['scripts.csv-numeric-quality.large','compile-run']]\nassert len(jobs)==2 and all(case in cases for case,lane in jobs)\n" + s[b:]
s = s.replace('6seconds', '8seconds').replace('warmupSeconds=6', 'warmupSeconds=8').replace('min(warmed)<6', 'min(warmed)<8').replace('warmed[i]>=6', 'warmed[i]>=8')
(q / 'collect.py').write_text(s, encoding='utf-8', newline='\n')
s = (old / 'archive-owned.py').read_text(encoding='utf-8').replace('==5', '==2').replace('jobs=5', 'jobs=2')
(q / 'archive-owned.py').write_text(s, encoding='utf-8', newline='\n')
(q / 'run.sh').write_text((old / 'run.sh').read_text(encoding='utf-8').replace(prior['root'], remote), encoding='utf-8', newline='\n')
canonical = 'benchmarks/results/2026-11-17-unary-result-transport/first-pair/observations.tgz'
blob = subprocess.check_output(['git', 'show', 'HEAD:' + canonical], cwd=repo)
assert blob == (repo / canonical).read_bytes()
with tarfile.open(fileobj=io.BytesIO(blob)) as archive: raw = archive.extractfile('confirmation/confirmation.json').read()
groups = []
for suffix, data, member in [('confirmation/confirmation.json', raw, 'confirmation/confirmation.json'), ('observations.tgz', blob, 'whole-archive')]:
    groups.append(dict(paths=['unary-slot-results-b889-20261117/' + suffix], bytes=len(data), links=1, sha256=hashlib.sha256(data).hexdigest(), canonical=canonical, canonicalSHA256=hashlib.sha256(blob).hexdigest(), member=member, committedBlobVerified=True))
names = ['collect.py', 'archive-owned.py', 'run.sh', 'identity.json']
with tarfile.open(q / 'payload.tgz', 'w:gz') as archive:
    for name in names: archive.add(q / name, arcname=name)
c = dict(root=remote, unit='lython-b890-unary-slot-confirm-20261117', source=prior['root'], sourceRole='reference', sourceFiles=identity['imageFiles']['reference'], sourceCatalogSHA256=prior['catalogSHA256'], catalogSHA256=prior['catalogSHA256'], identity=identity, retireGroups=groups,
    payloadBytes=(q / 'payload.tgz').stat().st_size, payloadSHA256=hashlib.sha256((q / 'payload.tgz').read_bytes()).hexdigest(), unpackedBytes=sum((q / name).stat().st_size for name in names))
(q / 'config.json').write_text(json.dumps(c, indent=2) + '\n', encoding='utf-8')
s = (old / 'remote-launch.py').read_text(encoding='utf-8'); a = s.index('c='); b = s.index('\nb=Path(', a); s = s[:a] + 'c=' + repr(c) + s[b:]
s = s.replace("os.link(source/c['sourceRole']/n,p)", "os.link(source/role/n,p)")
s = s.replace(' # Custom catalog was verified with both actual images before payload staging.', " os.link(source/'representative.json',root/'representative.json')")
s = s.replace('lython-b889-fixtures', 'lython-b890-fixtures')
(q / 'remote-launch.py').write_text(s, encoding='utf-8', newline='\n')
(r / 'launch.py').write_text((base / 'launch.py').read_text(encoding='utf-8').replace('seconds=230', 'seconds=125').replace('230seconds', '125seconds').replace('Five-job', 'Two-job'), encoding='utf-8', newline='\n')
(q / 'retrieve.py').write_text((old / 'retrieve.py').read_text(encoding='utf-8').replace('B889', 'B890').replace("['jobs']==5", "['jobs']==2"), encoding='utf-8', newline='\n')
s = (base / 'summarize.py').read_text(encoding='utf-8').split('reference=json.loads')[0].replace("len(raw['jobs'])==5", "len(raw['jobs'])==2")
(r / 'summarize.py').write_text(s + "print('confirmation seconds',raw['elapsedSeconds'])\n", encoding='utf-8', newline='\n')
for p in list(q.glob('*.py')) + list(r.glob('*.py')): ast.parse(p.read_text(encoding='utf-8'))
print('Prepared unchanged2job confirmation, stage', c['unpackedBytes'], 'retire only committed first raw/archive replicas', sum(g['bytes'] for g in groups), 'both current images preserved.')
