from pathlib import Path
import json, os, re, subprocess, textwrap
r = Path(__file__).parent
repo = Path('D:/code/Lython')
work = repo / '.git/agent-worktrees/call-operands-r470'
s = (work / 'tests/Lokad.Lython.PublicApi.Tests/ClosedBuiltinResultTests.cs').read_text(encoding='utf-8')
rows = []
for i, body in enumerate(re.findall(r'"""(.*?)"""', s, re.S)[:3]):
    source = textwrap.dedent(body).replace("return 'ok'", "print('ok')")
    p = subprocess.run(['C:/Python313/python.exe', '-X', 'utf8', '-I', '-c', source], capture_output=True, text=True, encoding='utf-8')
    assert p.returncode == 0 and p.stdout == 'ok\n', (i, p.stdout, p.stderr)
    rows.append(dict(index=i, source=source, stdout=p.stdout, exitCode=p.returncode))
(r / 'cpython-semantic-goldens.json').write_text(json.dumps(dict(referenceVersion='CPython3.13.2 Windows', rows=rows), indent=2) + '\n', encoding='utf-8')
dotnet = Path('C:/Users/JoannesVermorel/.dotnet11/dotnet.exe')
env = os.environ.copy(); env.update(DOTNET_ROOT=str(dotnet.parent), DOTNET_ROOT_X64=str(dotnet.parent)); env['PATH'] = str(dotnet.parent) + os.pathsep + env['PATH']
with (r / 'candidate-thirteen-preflight.log').open('w', encoding='utf-8') as log:
    p = subprocess.run([str(dotnet), str(r / 'frozen/candidate/Lokad.Lython.Benchmarks.dll'), '--compare', 'verify', '--catalog', str(r.parent / 'generator-sum-r475/catalog.json'), '--dotnet', str(dotnet), '--python', 'C:/Python313/python.exe', '--python-worker', str(repo / 'benchmarks/cpython-worker.py'), '--out', str(r / 'candidate-thirteen-preflight.json')], env=env, stdout=log, stderr=subprocess.STDOUT)
assert p.returncode == 0, (r / 'candidate-thirteen-preflight.log').read_text(encoding='utf-8')
print('Three independent CPython programs agree; current frozen candidate passes all13previous worker catalog goldens as well as the new3case catalog.')
