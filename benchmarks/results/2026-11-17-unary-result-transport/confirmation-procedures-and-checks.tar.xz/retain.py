from pathlib import Path
import hashlib, json, shutil, tarfile

r = Path(__file__).parent
repo = Path('D:/code/Lython')
work = repo / '.git/agent-worktrees/call-operands-r470'
out = repo / 'benchmarks/results/2026-11-17-unary-result-transport'
receipt = json.loads((r / 'confirm/quiet/archive-receipt.json').read_text(encoding='utf-8'))
assert receipt['complete'] and receipt['jobs'] == 2 and receipt['allWorkersJoined'] and receipt['guestFixturesRemoved'] and receipt['quietBeforeAndAfter']
assert hashlib.sha256((r / 'confirm/quiet/observations.tgz').read_bytes()).hexdigest() == receipt['archiveSHA256']
confirmation = out / 'confirmation'; confirmation.mkdir(exist_ok=False)
for name in ['observations.tgz', 'archive-receipt.json', 'terminal-status.json']:
    shutil.copyfile(r / 'confirm/quiet' / name, confirmation / name)
shutil.copyfile(r / 'confirm/summary.json', out / 'confirmation-summary.json')
shutil.copyfile(r / 'cpython-semantic-goldens.json', out / 'cpython-semantic-goldens.json')
with tarfile.open(out / 'confirmation-procedures-and-checks.tar.xz', 'w:xz') as archive:
    for p in list(r.glob('*.py')) + list(r.glob('*.json')) + list(r.glob('*.log')):
        archive.add(p, arcname=p.name)
    for p in (r / 'confirm').rglob('*'):
        if p.is_file() and 'retrieved' not in p.parts and p.name not in ['payload.tgz', 'observations.tgz']:
            archive.add(p, arcname=p.relative_to(r).as_posix())
decision = dict(retain=True, basis='One existing-slot result convention removes heterogeneous Delegate/signature bridge and native-only integer repacking; established complete-script allocation reduction5.26%, unchanged accounted peaks. No substantial CPU gain claim.',
    warmConfirmation='Elapsed−1.57..−0.18%, widerCPU−2.79..0.00%; controls reference0.24/candidate1.17%.',
    freshConfirmation='Elapsed−1.39..+0.73%, widerCPU−0.89..+1.80%; controls1.36/0.79%. Original first fresh−11.02..−4.89%not reproduced; cause not isolated.',
    explicitDebt='First text control small mixed/adverse; fresh CPU uncertain/slightly adverse. R471 integer and R460 async/tuple debts remain. No further unchanged-source retiming needed for this retention decision.',
    removed=['Delegate result carrier over two signatures', 'runtime signature/type switch at ordinary unary boundary', 'generic invocation overload', 'native-only integer unpack/repack branch'],
    preserved=['managed stack/cancellation/callable translation', 'native parsing and major allocation preflights', 'public materialization and canonical aliases', 'abs/str/sum(bytes) object behavior', 'terminal refusal and awaited cleanup'],
    fullDeliveryPending=True, publicationHeld=True)
(out / 'decision.json').write_text(json.dumps(decision, indent=2) + '\n', encoding='utf-8')
validation = dict(eachActualWindowsTarget=dict(publicFocused=433, internalFocused=107, publicBoundaryAndCancellation=211, internalActualAsyncProtocols=6), countsMayOverlap=True, newObservablePublicCases=5,
    independentCPythonPrograms=3, independentCompleteCsvGolden=True, candidatePriorCatalogGoldens=13, actualFrozenReferenceAndCandidateCatalogGoldens=3,
    productionFilesChanged=7, productionSnapshotFiles=585, copiedWorkerImageFiles=32, fullDelivery='Pending coherent Windows/Ubuntu actual11/10, originalstress and installed Release package consumers.', publicationHeld=True)
(out / 'validation.json').write_text(json.dumps(validation, indent=2) + '\n', encoding='utf-8')
p = out / 'README.md'
s = p.read_text(encoding='utf-8')
s = s.replace('# Closed unary builtin result transport: decision pending', '# Closed unary builtin result transport')
s = s.replace('**Prototype only; not promoted or qualified.**', '**Retain for simplification and allocation; full delivery pending.**')
s = s.replace('One bounded unchanged-image warm/fresh confirmation is\njustified; no source/performance promotion or preferred-sign conclusion yet.', 'One bounded unchanged-image warm/fresh confirmation follows below. The original\nfavorable fresh magnitude is not confirmed; do not select only that observation.')
s = s.replace('Root production unchanged;\npublication held;', 'Retained source and five observable cases promoted; full delivery pending;\npublication held;')
s += '''
## B890 unchanged-image confirmation and decision

Two jobs95.71s; same source/images/catalog/rotation, interleaved8s full-request
warmups instead of6s, because the first fresh reference moved6.04% and warm was
inconclusive. No source tuning, forced GC or timing repair.

| Numeric CSV report | Elapsed change | Wider CPU change | Reference / candidate controls |
| --- | ---: | ---: | ---: |
| Warm | −1.57..−0.18% | −2.79..0.00% | 0.24 / 1.17% |
| Compile and execute once | **−1.39..+0.73%** | **−0.89..+1.80%** | 1.36 / 0.79% |

Retain for the shared smaller result boundary and demonstrated5.26%allocation
reduction, not a substantial CPU claim. Original fresh advantage is not reproduced;
its cause is unisolated. Small warm benefit, essentially flat fresh elapsed and
uncertain/slightly adverse fresh wider CPU remain separate. Preserve the first
small adverse text control; no prior integer/async debt is declared resolved.
No further unchanged-source timing is needed to make this retention decision.

Both collections pass all gates/users joined/RAM removed; raw/terminals cached.
Confirmation retires only465772Bof exact committed first working evidence
replicas under fresh UID/path/hash/link/all-alias proof, keeping both measured
cores/toolchains/canonicals and254/252MiBfloors. Three independent CPython
semantic programs and all13previous catalog goldens also pass the candidate.
No public API or contract break; full delivery is a separate checkpoint.

[Confirmation](confirmation-summary.json),[raw](confirmation/observations.tgz),
[decision](decision.json),[validation](validation.json),
[additional checks/procedures](confirmation-procedures-and-checks.tar.xz).
'''
p.write_text(s, encoding='utf-8', newline='\n')
with (repo / 'benchmarks/EXPERIMENTS.md').open('a', encoding='utf-8', newline='\n') as stream:
    stream.write('''
R477/B890 confirmation: retain the smaller shared result convention and−5.26%
allocation, not a substantial CPU gain. Same source/images/catalog,8sinterleaved
warmups,2jobs95.71s. Warm−1.57..−0.18%/CPU−2.79..0%;fresh−1.39..+0.73%/
CPU−0.89..+1.80%. Original first fresh advantage not reproduced,cause unisolated;
first adverse text/older debts retained. Removed Delegate/signature/generic bridge
and native-only repacking; source7files/five observable tests promoted, full delivery
pending. Both raw conditions/procedures preserved; all users joined/RAM removed.
No more unchanged retiming for this decision; broader objective/publicationheld.
''')
paths = json.loads((r / 'frozen/identity.json').read_text(encoding='utf-8'))['changedProductionFiles'] + ['tests/Lokad.Lython.PublicApi.Tests/ClosedBuiltinResultTests.cs']
for name in paths: shutil.copyfile(work / name, repo / name)
print('R477 retained: one result boundary,−5.26%allocation; fresh CPU uncertain, original adversity preserved; full delivery pending.')
