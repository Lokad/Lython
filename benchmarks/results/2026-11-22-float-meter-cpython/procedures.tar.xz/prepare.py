from pathlib import Path
import gzip, hashlib, json, os, shutil, subprocess, tarfile

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
prior = lab.parent / "direct-float-text-20261122"
template = lab.parent / "latest-checkpoint-cpython-20261121"
quiet = lab / "quiet"
core = "Lokad.Lython.dll"
def load(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))
def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
def emit(path, source):
    if path.suffix == ".py": compile(source, str(path), "exec")
    path.write_text(source, encoding="utf-8", newline="\n")
def save(path, value):
    emit(path, json.dumps(value, indent=2) + "\n")

source_run = prior/"quiet"
configured = load(source_run/"config.json")
verified = load(source_run/"archive-receipt.json")
assert verified["complete"] and verified["archivedAndVerifiedUnderLease"]
assert sha(source_run/"observations.tgz") == verified["archiveSHA256"]
source_files = configured["identity"]["imageFiles"]["candidate"]
source_image = prior/"frozen/candidate"
assert len(source_files)==32 and {name:sha(source_image/name) for name in source_files} == source_files
protocol = repo/"benchmarks/cpython-worker.py"
assert sha(protocol) == configured["protocolSHA256"]
revision = subprocess.check_output(["git","rev-parse","HEAD"],cwd=repo,text=True).strip()
measured = configured["identity"]["sourceRevision"].split()[-1]
assert measured.startswith("7d57b2f26")
subprocess.run(["git","diff","--exit-code",measured,revision,"--","src","tests"],cwd=repo,check=True)
assert revision == subprocess.check_output(["git","rev-parse","origin/master"],cwd=repo,text=True).strip()
assert not subprocess.check_output(["git","status","--porcelain"],cwd=repo)
image = lab/"frozen"
image.mkdir()
for name in source_files:
    shutil.copyfile(source_image/name,image/name)
files = {name:sha(image/name) for name in source_files}
assert files == source_files

quiet.mkdir()
manifest = quiet/"representative.json"
catalog = load(source_run/"representative.json")
assert len(catalog["cases"]) == 4
shutil.copyfile(source_run/"representative.json",manifest)
dotnet = Path.home()/".dotnet11/dotnet.exe"
env = dict(os.environ,DOTNET_ROOT=str(dotnet.parent),DOTNET_ROOT_X64=str(dotnet.parent),
           PATH=str(dotnet.parent)+os.pathsep+os.environ["PATH"])
proof_path = lab/"verify.json"
subprocess.run([dotnet,image/"Lokad.Lython.Benchmarks.dll","--compare","verify","--catalog",manifest,
    "--dotnet",dotnet,"--python","C:/Python313/python.exe","--python-worker",protocol,"--out",proof_path],
    env=env,check=True,timeout=95)
proof=load(proof_path)
assert proof["state"]=="Completed" and proof["caseCount"]==4 and proof["catalogSha256"]==sha(manifest)
assert {name:sha(image/name) for name in files}==files

retire=[]

identity=dict(sourceRevision=measured,productionEquivalent=revision,imageSource=measured,
              purpose="Direct float-text meter reports against stock CPython",
              imageFiles=dict(candidate=files),catalogSHA256=sha(manifest),
              cpythonWorkerSHA256=sha(protocol),auxiliaryFiles={name:h for name,h in files.items() if name!=core},
              coreSHA256={label:files[core] for label in ("candidate","candidate-control")})
save(quiet/"identity.json",identity)
root="/home/lokad/lython-bench-checks/float-meter-cpython-b1313-20261122"
unit="lython-b1313-float-meter-cpython-20261122"
old=load(template/"quiet/config.json")
ascii="scripts.csv-meter-report.typed-ascii"
explicit="scripts.csv-meter-report.explicit-float"
unicode="scripts.csv-meter-report.typed-unicode"
invoice="scripts.csv-invoice.large"
jobs=[(ascii,"warm"),(ascii,"compile"),(ascii,"compile-run"),(explicit,"warm"),(unicode,"warm"),(invoice,"warm")]
assert set(case for case,_ in jobs)=={case["id"] for case in catalog["cases"]}
for name in ("collect.py","archive-owned.py","run.sh","retrieve.py"):
    original=(template/"quiet"/name).read_text(encoding="utf-8").replace(old["root"],root).replace(old["unit"],unit)
    if name=="collect.py":
        start=original.index("    for case_id,lane in ")
        stop=original.index("        assert time.monotonic()",start)
        original=original[:start]+f"    for case_id,lane in {jobs!r}:\n"+original[stop:]
    elif name=="archive-owned.py":
        original=original.replace("len(raw['jobs'])==5","len(raw['jobs'])==6").replace("jobs=5,","jobs=6,")
    elif name=="retrieve.py":
        original=original.replace("['jobs']==5","['jobs']==6")
    emit(quiet/name,original.replace("B1307","B1313"))
assert b"\r" not in (quiet/"run.sh").read_bytes()
(quiet/"candidate").mkdir()
parts=("identity.json","representative.json","collect.py","archive-owned.py","run.sh")
payload=quiet/"payload.tgz"
with tarfile.open(payload,"w:gz") as archive:
    for name in parts: archive.add(quiet/name,arcname=name)
config=dict(root=root,unit=unit,identity=identity,source=configured["root"],sourceRole="candidate",
            sourceFiles=source_files,sourceCatalogSHA256=configured["catalogSHA256"],
            donorArchiveSHA256=verified["archiveSHA256"],catalogSHA256=identity["catalogSHA256"],
            retireGroups=retire,cpythonWorkerSHA256=identity["cpythonWorkerSHA256"],
            payloadBytes=payload.stat().st_size,payloadSHA256=sha(payload),
            unpackedBytes=sum((quiet/name).stat().st_size for name in parts))
save(quiet/"config.json",config)
original=(template/"quiet/remote-launch.py").read_text(encoding="utf-8")
start,end=original.index("\nc=")+1,original.index("\nb=Path(")
original=original[:start]+"c="+repr(config)+original[end:]
emit(quiet/"remote-launch.py",original.replace("lython-b1307-fixtures","lython-b1313-fixtures"))
emit(lab/"launch.py",(template/"launch.py").read_text(encoding="utf-8")
     .replace("B1307 checkpoint CPython","B1313 meter reports against CPython").replace("345","390"))
print("Prepared six short lanes. Exact checkpoint and all four CPython goldens verified.")
