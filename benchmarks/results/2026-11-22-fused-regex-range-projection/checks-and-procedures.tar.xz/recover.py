from pathlib import Path
import hashlib, json, subprocess, tarfile
lab = Path(".git/agent-notes/review-20261031/fused-regex-range-projection-20261122").resolve()
quiet = lab/"quiet"
config = json.loads((quiet/"config.json").read_text(encoding="utf-8"))
attempts = sorted(quiet.glob("observation-*.json"))
original = json.loads(attempts[-1].read_text(encoding="utf-8"))
assert original["exitCode"]=="1" and original["receipt"] is None
assert not original["remainingWorkers"] and not original["remainingTrace"]
assert "archive-owned.py" in original["journal"] and "AssertionError" in original["journal"]
recovery = r'''
from pathlib import Path
import fcntl, hashlib, json, subprocess
config = CONFIG
root = Path(config["root"])
with (root.parent/"comparison-vm.lock").open("a") as lease:
    fcntl.flock(lease, fcntl.LOCK_EX|fcntl.LOCK_NB)
    assert (root/"exit-code.txt").read_text().strip()=="1"
    assert not (root/"guest-fixtures").exists() and not (root/"archive-receipt.json").exists()
    assert subprocess.run(["pgrep","-af","[d]otnet.* --compare worker|[p]erf record"],capture_output=True).returncode==1
    service = subprocess.run(["systemctl","show",config["unit"]+".service","--property=ActiveState,Result,MainPID,ExecMainStatus"],check=True,capture_output=True,text=True).stdout
    assert all(line in service for line in ("ActiveState=failed","Result=exit-code","MainPID=0","ExecMainStatus=1"))
    identity = json.loads((root/"identity.json").read_text())
    assert identity==config["identity"]
    for role,files in identity["imageFiles"].items():
        assert len(files)==32
        assert {name:hashlib.sha256((root/role/name).read_bytes()).hexdigest() for name in files}==files
    original = root/"archive-owned.py"
    source = original.read_text()
    assert source.count("len(raw['jobs'])==5")==1
    corrected = source.replace("len(raw['jobs'])==5","len(raw['jobs'])==4")
    corrected = corrected.replace("performanceQualified=False", "performanceQualified=False,recoveredAfterArchiveFailure=True,originalServiceExitCode=1")
    path = root/"archive-recovery.py"
    with path.open("x") as file: file.write(corrected)
    subprocess.run(["python3",str(path)],check=True)
'''.replace("CONFIG", repr(config))
(quiet/"recover-owned.py").write_text(recovery,encoding="utf-8",newline="\n")
key = str(Path.home()/".ssh/id_lython-bench.pem")
options = ["-i",key,"-o","BatchMode=yes","-o","ConnectTimeout=15"]
host = "lokad@20.166.121.73"
done = subprocess.run(["C:/Windows/System32/OpenSSH/ssh.exe",*options,host,"python3 -"],input=recovery,text=True,encoding="utf-8",capture_output=True,check=True)
receipt = json.loads(done.stdout); print(done.stdout)
assert receipt["complete"] and receipt["jobs"] == 4 and receipt["originalServiceExitCode"] == 1
for name in ("archive-receipt.json","observations.tgz"):
    subprocess.run(["C:/Windows/System32/OpenSSH/scp.exe",*options,host+":"+config["root"]+"/"+name,str(quiet/name)],check=True,capture_output=True)
assert hashlib.sha256((quiet/"observations.tgz").read_bytes()).hexdigest()==receipt["archiveSHA256"]
assert json.loads((quiet/"archive-receipt.json").read_text(encoding="utf-8"))==receipt
(quiet/"terminal-status.json").write_text(json.dumps(original,indent=2)+"\n",encoding="utf-8",newline="\n")
out = quiet/"retrieved"; out.mkdir()
with tarfile.open(quiet/"observations.tgz") as a:
    members = a.getmembers()
    regular = [member for member in members if member.isfile() or member.isdir()]
    assert all(member.isfifo() and member.size==0 for member in members if member not in regular)
    a.extractall(out, members=regular, filter="data")
