#!/bin/bash
set -euo pipefail
cd /mnt/d/code/Lython/.git/agent-worktrees/fused-regex-range-projection-20261122
export DOTNET_ROOT="$HOME/.dotnet"
export PATH="$DOTNET_ROOT:$PATH"
dir=/mnt/d/code/Lython/.git/agent-notes/review-20261031/fused-regex-range-projection-20261122
filter='Category!=Stress&(FullyQualifiedName~Regex|FullyQualifiedName~ReProvider|FullyQualifiedName~Fnmatch|FullyQualifiedName~Glob)'
dotnet test tests/Lokad.Lython.Tests -c Release -f net10.0 --filter "$filter" --verbosity quiet > "$dir/white-ubuntu.log" 2>&1 || { tail -30 "$dir/white-ubuntu.log"; exit 1; }
dotnet test tests/Lokad.Lython.PublicApi.Tests -c Release -f net10.0 --filter "$filter" --verbosity quiet > "$dir/public-ubuntu.log" 2>&1 || { tail -30 "$dir/public-ubuntu.log"; exit 1; }
grep -H 'Passed!' "$dir/white-ubuntu.log" "$dir/public-ubuntu.log"
