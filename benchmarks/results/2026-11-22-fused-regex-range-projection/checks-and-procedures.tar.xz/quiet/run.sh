set -eu
root=/home/lokad/lython-bench-checks/fused-regex-range-projection-b1349-20261122
trap 'result=$?; printf "%s\n" "$result" > "$root/exit-code.txt"' EXIT
python3 "$root/collect.py"
