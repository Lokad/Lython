from pathlib import Path
import ast,datetime,hashlib,io,json,shlex,subprocess,tarfile
base=Path('.git/agent-notes/review-20261031');r=base/'text-loop-r407';r.mkdir();prior=base/'search-attribution-r400'
identity=json.loads((base/'arithmetic-r405/quiet/identity.json').read_text(encoding='utf-8'));identity.update(sourceRevision='Committed43bce13a/frozen9e890d18',runtimeCommit='43bce13a334a5b44ad750562ea67b4cd08cccba7',purpose='One current captured-text CPU capture with same-process optimized bulk-loop disassembly; identify whole control/transport work versus useful text/hash work, not an elapsed comparison.',coreSHA256={k:v for k,v in identity['coreSHA256'].items()if k=='candidate'},roleMeaning=dict(candidate='Committed43bce13a/frozen9e890d18'),qualification='Focused actual11/10 passed; full43737584665 active');identity.pop('referenceDelivery',None)
(r/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8',newline='\n')
for name in ['ops-profile.py','collect.py','run.sh','retrieve.py']:
 s=(prior/name).read_text(encoding='utf-8').replace('search-attribution-b785-20261115','text-loop-b793-20261115').replace('lython-b785-search-attribution-20261115','lython-b793-text-loop-20261115').replace('B785','B793').replace("['search']","['text']")
 s=s.replace("[('search','scripts.file-search.large.protected','warm')]","[('text','scripts.text-summary-helpers.nonlocal-counter.large','warm')]")
 s=s.replace('Committed51e3c2c1/frozen22e5b72c; R400 complete search CPU attribution','Committed43bce13a/frozen9e890d18; R407 current text-loop interior attribution')
 if name=='ops-profile.py':
  assert "[('text','scripts.text-summary-helpers.nonlocal-counter.large','warm')]"in s
  s=s.replace('log = (folder / "worker.stderr").open("w")','env["DOTNET_JitDisasm"]="TryExecuteDictionaryLoop"\n        env["DOTNET_JitStdOutFile"]=str(folder/"dictionary-loop-jit.txt")\n        log = (folder / "worker.stderr").open("w")')
  s=s.replace('for k in ["DOTNET_PerfMapEnabled"]','for k in ["DOTNET_PerfMapEnabled","DOTNET_JitDisasm","DOTNET_JitStdOutFile"]')
 if name.endswith('.py'):ast.parse(s)
 (r/name).write_text(s,encoding='utf-8',newline='\n')
# Retire only two already-committed archived B784 working duplicates for diagnostic headroom.
head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();canonical='benchmarks/results/2026-11-15-csv-cpython-checkpoint/observations.tgz';data=subprocess.check_output(['git','show',head+':'+canonical]);assert data==Path(canonical).read_bytes();retire=[]
with tarfile.open(fileobj=io.BytesIO(data))as t:
 b=t.extractfile('confirmation/confirmation.json').read();retire.append(dict(path='csv-cpython-b784-20261115/confirmation/confirmation.json',bytes=len(b),sha256=hashlib.sha256(b).hexdigest(),canonicalCommit=head,canonicalPath=canonical,member='confirmation/confirmation.json',archiveSHA256=hashlib.sha256(data).hexdigest()))
retire.append(dict(path='csv-cpython-b784-20261115/observations.tgz',bytes=len(data),sha256=hashlib.sha256(data).hexdigest(),canonicalCommit=head,canonicalPath=canonical,member=None))
with tarfile.open(r/'payload.tgz','w:gz')as t:
 for n in ['identity.json','ops-profile.py','collect.py','run.sh']:t.add(r/n,arcname=n)
config=dict(root='/home/lokad/lython-bench-checks/text-loop-b793-20261115',source='/home/lokad/lython-bench-checks/arithmetic-b790-20261115',unit='lython-b793-text-loop-20261115',identity=identity,payloadBytes=(r/'payload.tgz').stat().st_size,payloadSHA256=hashlib.sha256((r/'payload.tgz').read_bytes()).hexdigest(),retire=retire)
(r/'config.json').write_text(json.dumps(config,indent=2)+'\n',encoding='utf-8',newline='\n')
s=(prior/'launch-command.py').read_text(encoding='utf-8');start=s.index('config=');end=s.index('\nbase=',start);s=s[:start]+'config='+repr(config)+s[end:]
s=s.replace('import fcntl,hashlib,io,json,os,shutil,subprocess,sys,tarfile','import fcntl,hashlib,io,json,os,shutil,stat,subprocess,sys,tarfile')
s=s.replace(" assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record|[p]ython3.*cpython-worker.py'],capture_output=True).returncode==1", " probe=subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record|[p]ython3.*cpython-worker.py'],capture_output=True,text=True)\n own={str(os.getpid()),str(os.getppid())}\n assert all(line.split(maxsplit=1)[0]in own for line in probe.stdout.splitlines()),probe.stdout")
needle=' assert shutil.disk_usage(base).free>max(254*1024*1024+65536,252*1024*1024+2621440)';assert needle in s
s=s.replace(needle,""" paths=[]
 for v in config['retire']:
  p=base/v['path'];m=p.lstat()
  assert p.resolve()==p and p.is_relative_to(base) and stat.S_ISREG(m.st_mode)and m.st_uid==os.getuid()and m.st_nlink==1 and m.st_size==v['bytes']and sha(p)==v['sha256']
  paths.append(p)
 assert shutil.disk_usage(base).free+sum(v['bytes']for v in config['retire'])>max(254*1024*1024+65536,252*1024*1024+2621440)
 for p in paths:p.unlink()
 assert shutil.disk_usage(base).free>max(254*1024*1024+65536,252*1024*1024+2621440)""")
s=s.replace(" os.link(source/'representative.json',root/'catalog.json')"," os.link(source/'representative.json',root/'catalog.json')\n (root/'retirement-receipt.json').write_text(json.dumps(dict(retiredOnly=config['retire'],canonicalBytesVerifiedLocally=True,allHashesPathsLinksOwnershipVerified=True,freshIdleLease=True,freeBytes=shutil.disk_usage(base).free),indent=2)+'\\n')")
s=s.replace('lython-b785-fixtures','lython-b793-fixtures');ast.parse(s);(r/'launch-command.py').write_text(s,encoding='utf-8',newline='\n')
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73'];p=subprocess.run(ssh+['python3 -c '+shlex.quote(s)],input=(r/'payload.tgz').read_bytes(),capture_output=True,timeout=45);(r/'launch.log').write_bytes(p.stdout+p.stderr);assert p.returncode==0,(p.stdout+p.stderr).decode('utf-8','replace')
now=datetime.datetime.now(datetime.timezone.utc);(r/'observe-not-before.json').write_text(json.dumps(dict(startedUTC=now.isoformat(),doNotObserveBeforeUTC=(now+datetime.timedelta(seconds=90)).isoformat(),ownerSeconds=120),indent=2)+'\n',encoding='utf-8',newline='\n');print((p.stdout+p.stderr).decode());print('Observe same B793 after',now+datetime.timedelta(seconds=90))
