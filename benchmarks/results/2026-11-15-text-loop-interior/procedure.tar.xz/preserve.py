from pathlib import Path
import hashlib,json,shutil,tarfile
base=Path('.git/agent-notes/review-20261031');r=base/'text-loop-r407';out=Path('benchmarks/results/2026-11-15-text-loop-interior');out.mkdir()
for n in ['attribution-text.json','dictionary-loop-instruction-groups.json','archive-receipt.json','terminal-status.json','observations.tgz']:shutil.copyfile(r/n,out/n)
with tarfile.open(out/'procedure.tar.xz','w:xz')as t:
 for p in r.iterdir():
  if p.is_file() and p.name not in {'observations.tgz','payload.tgz'}:t.add(p,arcname=p.name,recursive=False)
 t.add(base/'prepare-text-loop-r407.py',arcname='prepare-text-loop-r407.py',recursive=False)
source={p.as_posix():hashlib.sha256(p.read_bytes()).hexdigest()for p in [Path('src/Lokad.Lython/Runtime/Text/PyStringOps.Whitespace.cs'),Path('src/Lokad.Lython/Runtime/Text/PyStringOps.Helpers.cs'),Path('src/Lokad.Lython/Runtime/LythonRuntime.Executable.DictionaryAccumulation.cs'),Path('src/Lokad.Lython/Runtime/PyDict.Accumulation.cs')]}
(out/'decision.json').write_text(json.dumps(dict(source='Committed43bce13a/frozen9e890d18',sourceFiles=source,attributionClosed=True,runtimeChanged=False,interpretation='993guest leaves/96unknown/0ambiguous;151in exact9912byte optimized loop. Mixed metadata/transport/hash/probe work does not identify a complete activation to remove. Useful text preparation remains prominent; no exact removable CPU fraction.',selectedMilestone='R408 single-pass whitespace/case preparation retaining ranges, removing deferred per-word conversion; not the slower R343 whole-buffer extra-scan design',semanticBoundary='Eager all-word preflight before guest effects; independent escaped words, active/nested loans, current token/refusal, publication-before-callback and joined funded cleanup',performanceComparison=False),indent=2)+'\n',encoding='utf-8',newline='\n')
(out/'README.md').write_text('''# Current captured-text loop interior

R407/B793,2026-11-15, committed **43bce13a / frozen9e890d18**. One5s199Hz
cpu-clock/frame-pointer capture after8guest-seconds warmup, unchanged complete
3072-line/35,840B text workload. Perf maps and same-process loop JIT disassembly
are explicit diagnostic overrides; no elapsed/allocation/CPython gain claim.

993guest leaves/5.01guest CPU seconds;96unknown leaves,0ambiguous. Exactly151
leaves map into the unique optimized **9912B** dictionary-loop body, with every
sample assigned to a validated instruction group. The largest group has15leaves
and copies the compact word; other groups mix metadata, hash, bucket/key probing
and scalar updates. They do not establish a dominant removable complete call/frame
or justify another arena, dispatch controller or isolated struct-copy tweak.
Inlining/skid and mixed groups limit source attribution; zero samples mean no
proof of zero cost. Earlier R342 reaches a similar conclusion at its named source.

Cased preparation has115resolved leaves, UTF8 case writing33 and scalar mapping28.
These separate leaves include useful work and are not removable fractions.
Source still inventories original byte ranges, then cases each word during
consumption. The revised **R408 proposal** combines boundary discovery and casing
in one preparation pass, retaining ranges over final admitted bytes, then copies
completed word bytes. It removes deferred per-word conversion/source retention.
Keep eager all-word funding, Unicode/context rules, independent escaped strings,
private-binding publication before callbacks, nested loans and awaited cleanup.

This is materially different from [withdrawnR343](../2026-11-14-bulk-cased-buffer-withdrawn/README.md),
which removed ranges but added whole-buffer scans, saved only88B/job and measured
8–23%slower with stable CSV controls. Do not replay it unchanged or forecast a
speedup. Retaining ranges avoids those new scans but adds reusable scratch and
can deny earlier for long lines. Measure that tradeoff at an explicit completion
gate before retention. Existing bulk ASCII, shared scans, cursor loans and
one-probe dictionary updates are the starting point.

All identity/golden/budget/quiet/Closed/exit/join checks pass. Every RAM byte is
archived/verified persistently under lease before unmount; no users or fixtures
remain. The initial idle preflight finds an already-retired B784 duplicate and
refuses before mutation/service start; preserve that failure. Fresh read-only
inventory then identifies one exact committed archived B776working replica,
verified by Git/local/remote hashes, path/UID/link proof under an idle lease.
Only that replica is retired; current images/canonical evidence/toolchains stay,
254/252MiB floors remain. B793 is terminal cached, never requery.

[Wider attribution](attribution-text.json),[all exact instruction groups](dictionary-loop-instruction-groups.json),
[decision/source map](decision.json),[raw evidence](observations.tgz),
[cleanup](archive-receipt.json),[procedures and original conditions](procedure.tar.xz).
''',encoding='utf-8',newline='\n')
p=Path('PLAN.md');s=p.read_text(encoding='utf-8');a=s.index('3. **R407 next finite gate');b=s.index('4. **Next whole',a)
s=s[:a]+'''3. **R407 complete; R408 selected — one-pass cased-word preparation.**
   [Current attribution/source gate](benchmarks/results/2026-11-15-text-loop-interior/README.md):
   993guest leaves/96unknown/0ambiguous;151in exact9912Bloop. Mixed transport,
   metadata/hash/probe groups do not justify another frame/controller/copy tweak.
   Preparation115leaves, case writing33, mapping28 motivate a whole stage removal;
   these include useful work and predict no speedup. No more unchanged capture.

   R408 hypothesis: combine whitespace discovery and Unicode casing into one pass,
   retaining ranges over final UTF8 bytes, eliminating deferred per-word casing,
   original-source/mapping retention and its repeated conversion setup. Use the
   existing funded cursor/range loan and governed byte builder; no new pool/owner,
   cap, value layout or dispatcher. Share the existing Unicode mapping/ASCII kernels,
   not a duplicate casing implementation. Keep ordinary split semantics and paths
   until the shared scanner can preserve them; no extra complete-buffer scan.
   Displaced code: CasedWhitespaceIteration's deferred source/mapping state and
   case-writing MoveNext/TryReadWord; replace with completed-byte copy/materialization.
   Keep ranges: R343's removed-range design added scans and measured8–23%slower
   with flat allocation/stable control. This changed pipeline must remove that work,
   not replay the same version or infer a win from a source simplification.

   Acceptance: all Python whitespace, Unicode expansion/final-sigma/context,
   split boundaries/independent strings/aliases, eager all-word admission before
   loop effects, capacity/replacement overlap, nested/active/late cursor loans,
   reentrant refunds/publication, actual suspension/cancellation/terminal refusal
   and shared-budget reuse. Extra reusable byte scratch/earlier long-line denial
   are explicit tradeoffs, not hidden allowances. Preserve all original stress.
   Focused actual11/10 checks, short complete-job allocation screen, then bounded
   quiet-VM source pair on captured text warm/fresh, ordinary text and unchanged
   fulfillment/JSON controls. All original/adverse data remain; allow justified
   refinement. Completion: old deferred stage gone, no extra byte pass, semantics
   preserved, controlled CPU/allocation/storage decision. Decide remaining debt
   explicitly; withdraw/refine if added scratch/scans outweigh benefit. Full batch
   only at retained changed-runtime boundary. Publication stays held.
''' +s[b:]
s=s.replace('No live VM job; B792','No live VM job; B793 complete/archived with users/fixtures cleaned. B792');p.write_text(s,encoding='utf-8',newline='\n')
with Path('benchmarks/EXPERIMENTS.md').open('a',encoding='utf-8',newline='\n')as f:f.write('''\n\n[R407 current loop interior](results/2026-11-15-text-loop-interior/README.md)
at43bce13a/9e89 maps151of993guest leaves into an exact9912Boptimized body,96unknown,
0ambiguous. Mixed useful/control work supports no new call arena or isolated copy
patch. Source selects R408one-pass whitespace/casing preparation retaining ranges,
displacing deferred per-word conversion, distinct from R343's slower extra scans.
No speedup forecast; eager funding/Unicode/alias/cancellation/refusal/cleanup and
scratch/earlier-denial tradeoffs require the named completion gate. All users
joined; RAM bytes archived/verified before unmount. Original missing-duplicate
preflight and exact committed replica retirement survive; floors unchanged.
''')
print('Closed R407 with exact same-process evidence; selected concrete R408 deletion/replacement and bounded acceptance before code.')
