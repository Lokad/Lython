from pathlib import Path
import hashlib,json,shutil,subprocess,tarfile,zipfile

r=Path(__file__).resolve().parent;repo=Path('D:/code/Lython')
before=json.loads((r/'normal-state-before.json').read_text(encoding='utf-8'))
after={n:hashlib.sha256((repo/n).read_bytes()).hexdigest()for n in before};assert before==after
(r/'normal-state-proof.json').write_text(json.dumps({'passed':True,'fileCount':len(before),'before':before,'after':after,'scope':'Normal source/pins/locks/assets and pre-existing build outputs unchanged; private feed/cache/locks/assets/outputs isolated.'},indent=2)+'\n',encoding='utf-8')
q=json.loads((r/'qualification.json').read_text(encoding='utf-8'))
loaded={}
for tfm in ['net11.0','net10.0']:
    for suite,count in [('Lokad.Lython.Tests',86),('Lokad.Lython.PublicApi.Tests',532)]:assert q['checks'][suite+'-'+tfm]['passed']==count
    loaded[tfm]={}
    for name in ['Lokad.Utf8Regex','Lokad.Utf8Regex.PythonRe']:
        with zipfile.ZipFile(r/'feed'/(name+'.0.5.0-dev.73.nupkg'))as a:data=a.read('lib/'+tfm+'/'+name+'.dll')
        digest=hashlib.sha256(data).hexdigest();assert digest==q['checks'][tfm+'-loadedFiles'][name]
        loaded[tfm][name]=digest
prior='a7e985ed2c1bb4ac7d63a09c74e3ba0a74ccb9b9';current='eae880c88f7a54ed4331715c2fd8f4b0fc6e6d63'
for name in ['Cursor','Metadata','Memory','Detailed']:
    path='src/Lokad.Utf8Regex.PythonRe/Utf8PythonRegex.'+name+'.cs'
    assert subprocess.check_output(['git','-C','D:/code/utf8regex','show',prior+':'+path])==subprocess.check_output(['git','-C','D:/code/utf8regex','show',current+':'+path])
changed=subprocess.check_output(['git','-C','D:/code/utf8regex','diff','--name-only',prior,current,'--','src/Lokad.Utf8Regex.PythonRe'],text=True).splitlines()
assessment={'producerVersion':'0.5.0-dev.73','producerSource':current,'priorQualifiedDevelopmentSource':prior,'changedPythonReFiles':changed,'fourRelevantPublicApiFilesByteIdentical':True,'missing':['Independent single-match working/result owners.','Native UTF-8 group-name enumeration; lookup already exists.','Token-independent cursor creation with cancellable preparation.'],'loadedBinaries':loaded,'scope':'Development compatibility on retained Lython2ec9d67f, unchanged Validate bridge; no normal-pin promotion, final published-producer, backend performance or source-safety certification.','decision':'Changed producer parsing/capture/scalar/value paths justify new-binary focused qualification. No new core plumbing or bridge rewrite is justified by unchanged relevant APIs.'}
(r/'capability-assessment.json').write_text(json.dumps(assessment,indent=2)+'\n',encoding='utf-8')
out=repo/'benchmarks/results/2026-11-12-regex-development-73';assert not out.exists();out.mkdir()
for n in ['identity.json','qualification.json','normal-state-proof.json','proposal.json','capability-assessment.json']:shutil.copyfile(r/n,out/n)
with tarfile.open(out/'preparation.tar.xz','w:xz')as a:
    for f in sorted(r.iterdir()):
        if f.is_file()and f.suffix in ['.py','.cs','.json','.log','.props','.Config','.patch']:a.add(f,arcname=f.name)
    for subdir in ['feed','locks','test-results']:
        for f in sorted((r/subdir).iterdir()):
            if f.is_file():a.add(f,arcname=subdir+'/'+f.name)
    for tfm in ['net11.0','net10.0']:
        folder=r/'out/Lokad.Lython.PublicApi.Tests/Release'/tfm
        for name in ['Lokad.Lython','Lokad.Lython.Utf8Regex','Lokad.Utf8Regex','Lokad.Utf8Regex.PythonRe']:
            a.add(folder/(name+'.dll'),arcname='qualified/'+tfm+'/'+name+'.dll')
(out/'README.md').write_text('''# Immutable dev73 adapter input

2026-11-12. Retained Lython `2ec9d67f`, immutable producer **0.5.0-dev.73** from
`eae880c88f7a54ed4331715c2fd8f4b0fc6e6d63`. Packages are copied from the accepted
unpublished candidate feed, with package SHA, dual-target DLL and nuspec commit
verification. Moving sibling HEAD and live package outputs are not substituted.
[Identity](identity.json), [source/capability assessment](capability-assessment.json).

**86 internal and 532 public checks pass on each actual .NET 11/10**, including
semantics, UTF-8/scalar/window behavior, effective flags, current cancellation,
refusal, cursor lifetime and budget reuse. The unchanged development bridge uses
Validate, cursor-local working admission and per-operation cancellation forwarding.
Loaded backend hashes match exact supplied package bytes. All 29 normal-state
source/pin/lock/asset/output files remain byte-identical. [Qualification](qualification.json),
[isolation proof](normal-state-proof.json). Normal adapter dependency remains 0.4;
core stays independent, adapter nonpackable, and no sibling edits/builds/repack occur.

The initial public .NET 11 log has no terminal outcome. Process inspection proved
runner/test children absent before resuming unfinished checks against the same
frozen binaries. The partial log, resumed logs and terminal TRX remain preserved;
no runtime failure or cause is inferred from the missing original result.

Changed producer private parsing/capture/scalar/value paths justify qualifying a
new binary. Four relevant public API files are byte-identical to qualified dev68.
The same final producer gaps remain:

- Single-match working ownership separate from retained result ownership.
- Native UTF-8 group-name enumeration; native name lookup already exists.
- Token-independent cursor creation with cancellable preparation; per-move tokens
  alone do not establish interruption during preparation.

No new bridge/core abstraction is selected. Temporary conversions remain adapter-
local. This is development-input semantic/contract qualification, not backend CPU,
source-safety, AssumeValid, normal-pin promotion or final published-package
certification. Missing producer APIs defer only affected final adapter qualification.
Lython's separate exact-source full platform/stress/package delivery is green in
[43119174279](https://github.com/Lokad/Lython/actions/runs/43119174279).
Publication remains postponed. [Exact packages, bridge, commands and logs](preparation.tar.xz),
[archive identity](archive-identity.json).
''',encoding='utf-8')
with tarfile.open(out/'preparation.tar.xz')as a:
    for m in a:
        if m.isfile():a.extractfile(m).read()
(out/'archive-identity.json').write_text(json.dumps({p.name:{'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}for p in sorted(out.iterdir())if p.is_file()and p.name!='archive-identity.json'},indent=2)+'\n',encoding='utf-8')
history=repo/'benchmarks/EXPERIMENTS.md';text=history.read_text(encoding='utf-8');at=text.index('The retained native storage/input migration')
text=text[:at]+'''[Immutable regex dev73](results/2026-11-12-regex-development-73/README.md) passes
86 internal/532 public focused checks per actual target with the unchanged Validate
development bridge. Exact loaded-package and 29-file normal-state isolation proofs
pass. Three final producer capability gaps remain unchanged; normal adapter 0.4
and core dependencies are untouched. Partial first observation and resumed terminal
checks are preserved. This is development compatibility, not final backend speed,
safety or published-package certification.

'''+text[at:];history.write_text(text,encoding='utf-8')
print(json.dumps({'passedPerTarget':618,'normalStateFiles':len(before),'loadedPackagesVerified':True,'capabilityGaps':len(assessment['missing'])}))
