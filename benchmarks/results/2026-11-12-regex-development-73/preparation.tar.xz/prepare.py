from pathlib import Path
import hashlib,json,shutil,subprocess,xml.etree.ElementTree as ET,zipfile
r=Path(__file__).resolve().parent;repo=Path.cwd();old=r.parent/'regex-dev68-r226'
assert not(r/'feed').exists()
normal=json.loads((old/'normal-state-before.json').read_text(encoding='utf-8'))
(r/'normal-state-before.json').write_text(json.dumps({n:hashlib.sha256((repo/n).read_bytes()).hexdigest()for n in normal},indent=2)+'\n',encoding='utf-8')
for n in ['Directory.Build.props','Directory.Packages.props','NuGet.Config','Utf8RegexProvider.cs','CursorAdmissionTests.cs','workflow-fixture-manifest.json','qualify.py']:
 s=(old/n).read_text(encoding='utf-8').replace('regex-dev68-r226','regex-dev73-r252').replace('0.5.0-dev.68','0.5.0-dev.73')
 (r/n).write_text(s,encoding='utf-8')
origin=Path('D:/code/utf8regex/artifacts/package-candidates/0.5.0-dev.73')
manifest=json.loads((origin/'candidate.json').read_text(encoding='utf-8'));commit='eae880c88f7a54ed4331715c2fd8f4b0fc6e6d63'
assert manifest['SourceRevision']==commit and manifest['CleanSource']and not manifest['Published']
(r/'feed').mkdir();packages={}
for name in ['Lokad.Utf8Regex','Lokad.Utf8Regex.PythonRe']:
 filename=name+'.0.5.0-dev.73.nupkg';p=origin/'feed'/filename;b=p.read_bytes();rows=[x for x in manifest['Packages']if x['Id']==name]
 assert {x['TargetFramework']for x in rows}=={'net11.0','net10.0'}
 digest=hashlib.sha256(b).hexdigest();assert all(x['PackageSha256'].lower()==digest for x in rows)
 with zipfile.ZipFile(p)as a:
  xml=ET.fromstring(a.read(next(n for n in a.namelist()if n.endswith('.nuspec'))))
  assert next(e.attrib['commit']for e in xml.iter()if e.tag.endswith('repository'))==commit
  for row in rows:assert hashlib.sha256(a.read('lib/'+row['TargetFramework']+'/'+name+'.dll')).hexdigest()==row['AssemblySha256'].lower()
  dependencies=[e.attrib for e in xml.iter()if e.tag.endswith('dependency')]
 shutil.copyfile(p,r/'feed'/filename);packages[filename]=dict(sha256=digest,repositoryCommit=commit,dependencies=dependencies)
for name in ['Utf8PythonRegex.Cursor.cs','Utf8PythonRegex.Metadata.cs','Utf8PythonRegex.Memory.cs','Utf8PythonRegex.Detailed.cs']:
 path='src/Lokad.Utf8Regex.PythonRe/'+name
 assert subprocess.check_output(['git','-C','D:/code/utf8regex','show','a7e985ed2c1bb4ac7d63a09c74e3ba0a74ccb9b9:'+path])==subprocess.check_output(['git','-C','D:/code/utf8regex','show',commit+':'+path]),name
identity=dict(consumerRevision=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),consumerRuntime='Retained2ec9d67f, full43119174279 active separately; normal/installed consumer checks pass both platforms/targets, stress pending. B597combined source pair and B598CPython checkpoint terminal/cached.',producerVersion='0.5.0-dev.73',producerSourceHead=commit,packages=packages,bridge='Unchanged dev68 Validate bridge and cursor working-admission controls. Isolated feed/cache/assets/locks/outputs. No normal source/pin changes or sibling edits/builds/repack.',providerSourceSHA256=hashlib.sha256((r/'Utf8RegexProvider.cs').read_bytes()).hexdigest(),limitations='Development semantic/cancellation/ownership input qualification only. No normal promotion, final published producer, source-safety or backend performance certification.')
(r/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8')
(r/'producer-relevant.patch').write_bytes(subprocess.check_output(['git','-C','D:/code/utf8regex','diff','a7e985ed2c1bb4ac7d63a09c74e3ba0a74ccb9b9',commit,'--','src']))
(r/'proposal.json').write_text(json.dumps(dict(scope='One bounded qualification of immutable dev73 with the unchanged validated development bridge on current Lython. Both actual targets, loaded-image and29normal-file isolation proofs.',rationale='Changed producer binaries/private parsing/capture/value paths justify focused correctness checks; four relevant public API files are byte-identical to dev68, not a new contract opportunity.',missing=['Independent single-match working/result owners.','Native UTF8 group-name enumeration.','Token-independent cursor creation with cancellable preparation.'],stop='Stop after focused semantics/cancellation/refusal/ownership and exact package/loaded-image/isolation proofs, or preserve concrete failures. No new core plumbing, bridge rewrite, performance campaign, normal promotion or publication.'),indent=2)+'\n',encoding='utf-8')
print('Immutable dev73 packages and dual-target binaries verified from accepted candidate feed; no moving HEAD/live package substitution. Unchanged isolated bridge prepared; normal files untouched.')
