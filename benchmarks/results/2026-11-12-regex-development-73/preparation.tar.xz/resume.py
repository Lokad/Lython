from pathlib import Path
import hashlib,json,os,re,subprocess,sys

r=Path(__file__).resolve().parent
repo=Path('D:/code/Lython')
env=os.environ.copy();env['DOTNET_ROOT']='C:/Users/JoannesVermorel/.dotnet11'
env['DOTNET_HOST_PATH']=env['DOTNET_ROOT']+'/dotnet.exe'
env['PATH']=env['DOTNET_ROOT']+os.pathsep+env['PATH']
before=json.loads((r/'normal-state-before.json').read_text(encoding='utf-8'))
assert all(hashlib.sha256((repo/n).read_bytes()).hexdigest()==h for n,h in before.items())
checks={}
for name in ['Lokad.Lython.Tests','Lokad.Lython.PublicApi.Tests']:
    text=(r/('build-'+name+'.log')).read_text(encoding='utf-8')
    assert 'Build succeeded.' in text
    checks['build-'+name]={'exitCode':0}
first=(r/'Lokad.Lython.Tests-net11.0.log').read_text(encoding='utf-8')
assert re.search(r'Failed:\s+0, Passed:\s+86,',first)
checks['Lokad.Lython.Tests-net11.0']={'passed':86}
props=[f'-p:DirectoryBuildPropsPath={r}/Directory.Build.props',f'-p:DirectoryPackagesPropsPath={r}/Directory.Packages.props',f'-p:RestoreConfigFile={r}/NuGet.Config']
selection='Category!=Stress&(FullyQualifiedName~Regex|FullyQualifiedName~Fnmatch|FullyQualifiedName~Glob|FullyQualifiedName~CursorAdmissionTests)'
for suite,tfm in [('Lokad.Lython.PublicApi.Tests','net11.0'),('Lokad.Lython.Tests','net10.0'),('Lokad.Lython.PublicApi.Tests','net10.0')]:
    label=suite+'-'+tfm; log=r/(label+'-resume.log')
    assert not log.exists()
    with log.open('w',encoding='utf-8') as output:
        p=subprocess.run([env['DOTNET_HOST_PATH'],'test','tests/'+suite,'-c','Release','-f',tfm,'--no-build','--no-restore','--filter',selection,'--logger','trx;LogFileName='+label+'.trx','--results-directory',str(r/'test-results'),*props],cwd=repo,env=env,stdout=output,stderr=subprocess.STDOUT)
    text=log.read_text(encoding='utf-8')
    (r/(label+'-exit.json')).write_text(json.dumps({'exitCode':p.returncode})+'\n',encoding='utf-8')
    print(label,p.returncode,text[-1500:],flush=True)
    if p.returncode:sys.exit(p.returncode)
    m=re.search(r'Passed:\s+(\d+)',text);assert m
    checks[label]={'passed':int(m[1])}
for tfm in ['net11.0','net10.0']:
    folder=r/f'out/Lokad.Lython.PublicApi.Tests/Release/{tfm}'
    checks[tfm+'-loadedFiles']={n:hashlib.sha256((folder/(n+'.dll')).read_bytes()).hexdigest() for n in ['Lokad.Lython','Lokad.Lython.Utf8Regex','Lokad.Utf8Regex','Lokad.Utf8Regex.PythonRe']}
(r/'qualification.json').write_text(json.dumps({'identity':json.loads((r/'identity.json').read_text(encoding='utf-8')),'checks':checks,'interruptedObservation':'Initial public11 log has no terminal outcome; process inventory confirmed all runner/test children absent before resuming unfinished frozen checks. Original partial log retained, no runtime fault inferred.','limitations':'Private immutable development adapter only; normal pin/source unchanged; final producer/safety qualification separate'},indent=2)+'\n',encoding='utf-8')
