from pathlib import Path
import ast,hashlib,json,os,shutil,subprocess,tarfile

r=Path(__file__).parent;base=r.parent;old=base/'sequence-construction-r72'
focused=json.loads((r/'focused.json').read_text(encoding='utf-8'))
for target in ['net11','net10']:
 assert focused['checks']['internal-'+target]['passed']==257
 assert focused['checks']['public-'+target]['passed']==1160
 assert focused['checks']['semantic-'+target]['tokenCount']==2191 and not focused['checks']['semantic-'+target]['failures']
shutil.copytree(r/'images/before',r/'images/candidate',copy_function=os.link)
core=r/'images/candidate/Lokad.Lython.dll';core.unlink();shutil.copyfile('src/Lokad.Lython/bin/Release/net11.0/Lokad.Lython.dll',core)
shutil.copyfile(core,r/'current-core.dll');assert hashlib.sha256(core.read_bytes()).hexdigest()==focused['checks']['net11-coreSHA256']
full=json.loads((base/'returned-record-calls-r69/representative.json').read_text(encoding='utf-8'))
names=['scripts.numeric-report.float.large','scripts.numeric-report.integer.large','scripts.csv-summary-functions.large','scripts.text-summary-helpers.large','scripts.report-render.large']
full['cases']=[next(c for c in full['cases']if c['id']==name)for name in names]
for name in ['catalog.json','representative.json']:(r/name).write_text(json.dumps(full,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
baseline=json.loads((r/'baseline.json').read_text(encoding='utf-8'))
local=dict(sourceRevision='21b0bc72 plus R74 default JSON UTF-8 floating entry replacement',baseline=baseline,
 coreSHA256={role:hashlib.sha256((r/'images'/role/'Lokad.Lython.dll').read_bytes()).hexdigest()for role in ['before','candidate']},
 productionSources={str(p).replace('\\','/'):hashlib.sha256(p.read_bytes()).hexdigest()for p in Path('src/Lokad.Lython').rglob('*.cs')if not any(x in ['bin','obj']for x in p.parts)})
(r/'identity.json').write_text(json.dumps(local,indent=2)+'\n',encoding='utf-8')
(r/'source.patch').write_bytes(subprocess.check_output(['git','diff','--binary','--','src','tests']))
prior=json.loads((old/'vm-identity.json').read_text(encoding='utf-8'))
jobs=[['scripts.numeric-report.float.large','warm'],['scripts.numeric-report.float.large','warm-async'],['scripts.numeric-report.integer.large','warm'],['scripts.text-summary-helpers.large','warm']]
identity=dict(sourceRevision=local['sourceRevision'],sourcePairBaseline='Production68d5bffe/corea0aef9ef: focused actual11/10 and B428/B429 complete goldens/ownership/cleanup; full CI42428096630 pending at selection, eventual status separate.',originalVariant='Reassessment of 2026-11-01 float entry:2191 semantic goldens passed, original whole-job baseline drift36.7% inconclusive. Original source/results preserved, no component retiming or causal prediction.',coreSHA256={role:(baseline['coreSHA256']if role.startswith('reference')else local['coreSHA256']['candidate'])for role in ['reference','reference-control','candidate','candidate-control']},auxiliaryFiles=prior['auxiliaryFiles'],productionSources=local['productionSources'],jobs=jobs,included=prior['included'])
(r/'vm-identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8')
for name in ['collect.py','archive-owned.py','run.sh','launch.py','retrieve.py','assess-vm.py']:
 s=(old/name).read_text(encoding='utf-8').replace('sequence-construction-b428-20261108','json-float-entry-b430-20261108').replace('lython-b428-sequence-construction-20261108','lython-b430-json-float-entry-20261108').replace('lython-b428-fixtures','lython-b430-fixtures')
 if name=='collect.py':s='\n'.join(('jobs='+repr(jobs))if line.startswith('jobs=')else line for line in s.splitlines())+'\n'
 if name=='launch.py':
  s=s.replace("reference=base/'binding-transport-b427-20261108/candidate'", "reference=base/'sequence-construction-b428-20261108/candidate'")
  s=s.replace('sequence-construction-b428-launch.py','json-float-entry-b430-launch.py')
  start=s.index('  required=sum(');end=s.index('  assert shutil.disk_usage(base).free>required',start)+len('  assert shutil.disk_usage(base).free>required')
  source=(base/'returned-record-cpython-r73/launch.py').read_text(encoding='utf-8');a=source.index('  required=sum(');b=source.index('  assert shutil.disk_usage(base).free>required',a)+len('  assert shutil.disk_usage(base).free>required')
  s=s[:start]+source[a:b]+s[end:]
  s=s.replace("  if reclaim:(root/'reclaimed-redundant-extract.json').write_text(json.dumps(reclaim,indent=2)+'\\n')", "  (root/'reclaimed-prototype-links.json').write_text(json.dumps(reclaims,indent=2)+'\\n')")
 if name=='archive-owned.py':s=s.replace("if (root/'reclaimed-redundant-extract.json').exists():t.add(root/'reclaimed-redundant-extract.json',arcname='reclaimed-redundant-extract.json')", "if (root/'reclaimed-prototype-links.json').exists():t.add(root/'reclaimed-prototype-links.json',arcname='reclaimed-prototype-links.json')")
 if name.endswith('.py'):ast.parse(s)
 (r/name).write_text(s,encoding='utf-8',newline='\n')
for name in ['measure.py','assess-local.py']:
 s=(old/name).read_text(encoding='utf-8');ast.parse(s);(r/name).write_text(s,encoding='utf-8')
shutil.copyfile('PLAN.md',r/'pre-measurement-plan.md');shutil.copyfile(old/'setup-contract.json',r/'setup-contract.json')
(r/'contract.md').write_text('''R74/B430 selective confirmation of default JSON floating conversion entry: current double.Parse replaced by public UTF-8 Utf8Parser with complete consumption, no fallback/retry or extra grammar. Integer/hook paths unchanged. No new storage/owner/cache/policy/dependency/unsafe mechanism. Prior2191 semantic corpus reused on actual11/10,257internal/1160public per target, matching probes; no component retiming. Original old36.7% control drift remains inconclusive, not permanent design rejection. Current-source pair normalGC/tiering/quietF4as_v7: complete float-report warm/warm-async affected, integer-report/text warm controls; two baseline/two candidate processes,5s warmup/role/job,7rotated150ms,150+30+30s bound. Same frozen worker7cf37ca5/normal optional0.4adapter/full scripts/goldens, no benchmark framework. RAM mediated I/O/full validation/prior cleanup included, compile/startup/reset/staging/protocol/final teardown excluded. BCL numeric conversion is atomic, surrounding scan/token checks cooperative; no hard deadline/RSS/startup/pending-I/O/embedding-tail claim. Source/core/every auxiliary/actualReady/runtime/golden/quiet/Closed/exit/join/emptyfixture/archive gates. Persistent evidence separate128MiB RAM fixtures,256MiB staging floor; conditional exact verified redundant retired-prototype core links may be reclaimed with immutable/local archives retained and paths/free bytes recorded. Observe210s, never restart an observation timeout. Existing five-script allocation diagnostic separate, preserve all adverse/variable results and explicit retained/restored/debt decision. Full checkpoint and publication status independent; whole-script objective remains active.
''',encoding='utf-8')
with tarfile.open(r/'payload.tgz','w:gz')as archive:
 for name in ['collect.py','archive-owned.py','run.sh','current-core.dll','representative.json','pre-measurement-plan.md','setup-contract.json','contract.md','focused.json']:archive.add(r/name,arcname=name)
 archive.add(r/'vm-identity.json',arcname='identity.json');archive.add(r/'source.patch',arcname='source.patch')
print('R74 frozen with exact source and semantic/focused gates:',local['coreSHA256']['candidate'])
