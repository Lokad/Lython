from pathlib import Path
import hashlib,json,os,re,shutil,subprocess

r=Path(__file__).parent;semantic=r/'semantic';semantic.mkdir(exist_ok=False)
original=Path('benchmarks/results/2026-11-01-json-float-entry-rejected/semantic')
for name in ['Program.cs','semantic.csproj','tokens.json']:shutil.copyfile(original/name,semantic/name)
env=os.environ.copy();env['DOTNET_ROOT']='C:/Users/JoannesVermorel/.dotnet11';env['DOTNET_HOST_PATH']=env['DOTNET_ROOT']+'/dotnet.exe';env['PATH']=env['DOTNET_ROOT']+os.pathsep+'C:/Python313'+os.pathsep+env['PATH']
checks={}
def run(name,args):
 with(r/(name+'.log')).open('w',encoding='utf-8')as log:done=subprocess.run([env['DOTNET_HOST_PATH'],*args],env=env,stdout=log,stderr=subprocess.STDOUT)
 text=(r/(name+'.log')).read_text(encoding='utf-8');print(name,done.returncode,text[-800:],flush=True);assert done.returncode==0
 count=re.search(r'Passed!\s+- Failed:\s+0, Passed:\s+(\d+)',text);checks[name]=dict(exitCode=0,passed=int(count[1])if count else None)
run('semantic-build',['build',str(semantic/'semantic.csproj'),'-c','Release'])
for target in ['net11.0','net10.0']:
 suffix='net11'if target=='net11.0'else'net10'
 run('semantic-'+suffix,[str(semantic/'bin/Release'/target/'semantic.dll'),str(semantic/'tokens.json')])
 data=json.loads((r/('semantic-'+suffix+'.log')).read_text(encoding='utf-8'));assert data['tokenCount']==2191 and not data['failures'];checks['semantic-'+suffix]=data
 run('probe-'+suffix,['build','tools/LythonProbe/LythonProbe.csproj','-c','Release','-f',target])
 run('internal-'+suffix,['test','tests/Lokad.Lython.Tests/Lokad.Lython.Tests.csproj','-c','Release','-f',target,'--filter','(FullyQualifiedName~Json|FullyQualifiedName~JSON|FullyQualifiedName~Number|FullyQualifiedName~Float|FullyQualifiedName~InstructionFailure)&Category!=Stress','--logger','console;verbosity=minimal'])
 run('public-'+suffix,['test','tests/Lokad.Lython.PublicApi.Tests/Lokad.Lython.PublicApi.Tests.csproj','-c','Release','-f',target,'--filter','(FullyQualifiedName~Json|FullyQualifiedName~JSON|FullyQualifiedName~NativeOperationAdmissionTests|FullyQualifiedName~NativeCallbackUnwindTests|FullyQualifiedName~NativeCallbackProtocolTests|FullyQualifiedName~ComparisonFileWorkerTests|FullyQualifiedName~AdmissionFailureCommandTests)&Category!=Stress','--logger','console;verbosity=minimal'])
 core=Path('src/Lokad.Lython/bin/Release')/target/'Lokad.Lython.dll';probe=Path('tools/LythonProbe/bin/Release')/target/'Lokad.Lython.dll';assert hashlib.sha256(core.read_bytes()).digest()==hashlib.sha256(probe.read_bytes()).digest()
 checks[suffix+'-coreSHA256']=hashlib.sha256(core.read_bytes()).hexdigest()
(r/'focused.json').write_text(json.dumps(dict(checks=checks,matchingProbes=True,semanticOnlyNoComponentTiming=True,corpusSHA256=hashlib.sha256((semantic/'tokens.json').read_bytes()).hexdigest()),indent=2)+'\n',encoding='utf-8')
