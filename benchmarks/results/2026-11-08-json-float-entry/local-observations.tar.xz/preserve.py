from pathlib import Path
import hashlib,json,re,shutil,tarfile

r=Path(__file__).parent;out=Path('benchmarks/results/2026-11-08-json-float-entry');out.mkdir(exist_ok=True)
assert not(out/'README.md').exists()
receipt=json.loads((r/'archive-receipt.json').read_text(encoding='utf-8'));assert receipt['complete']and receipt['jobs']==4
assert hashlib.sha256((r/'observations.tgz').read_bytes()).hexdigest()==receipt['archiveSHA256']
identity=json.loads((r/'identity.json').read_text(encoding='utf-8'))
assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==h for p,h in identity['productionSources'].items())
for name in ['observations.tgz','archive-receipt.json','terminal-status.json','identity.json','vm-identity.json','assessment.json','local-assessment.json','focused.json','selected-plan.md','contract.md']:
 shutil.copyfile(r/name,out/name)
shutil.copyfile(r/'retrieved/reclaimed-prototype-links.json',out/'reclaimed-prototype-links.json')
with tarfile.open(out/'local-observations.tar.xz','w:xz')as archive:
 for p in r.iterdir():
  if p.is_file()and p.suffix in ['.py','.json','.log','.md','.patch']:archive.add(p,arcname=p.name)
 for folder in ['warm-sync','warm-async']:archive.add(r/folder,arcname=folder)
 for p in (r/'semantic').iterdir():
  if p.is_file():archive.add(p,arcname='semantic/'+p.name)
 archive.add(r/'images/before/Lokad.Lython.dll',arcname='baseline-core.dll')
 archive.add(r/'baseline-net10-core.dll',arcname='baseline-net10-core.dll')
 archive.add(r/'current-core.dll',arcname='current-core.dll')
 archive.add('src/Lokad.Lython/bin/Release/net10.0/Lokad.Lython.dll',arcname='current-net10-core.dll')
raw=json.loads((r/'assessment.json').read_text(encoding='utf-8'))
table='| Complete job | Elapsed change, all process pairs | Baseline / current spread |\n| --- | ---: | ---: |\n'
for job in raw['jobs']:
 values=[v for pair in job['elapsedPercent'].values()for v in pair]
 table+=f"| {job['case'].removeprefix('scripts.')} / {job['lane']} | {min(values):+.2f} to {max(values):+.2f}% | {abs(job['baselineSpreadPercent']):.2f}% / {abs(job['candidateSpreadPercent']):.2f}% |\n"
(out/'README.md').write_text('''# Validated JSON floating conversion — R74/B430

2026-11-08. Retained production change on21b0bc72, baseline production68d5bffe
(fully qualified CI42428096630). Measured candidatebb6e72b5 (.NET11); exact both-
target binaries/source inventories/patches remain. New-source full delivery is
pending, separate from the completed baseline. Publication postponed.

## Why reassess, and what changed

The [old candidate](../2026-11-01-json-float-entry-rejected/README.md) passed2,191
CPython rounding/consumption cases, but its unchanged whole-job CPU control shifted
36.7%; candidate equalled the final control. That demonstrated uncertainty, not a
stable design failure. Its no-retiming/permanent-stop rule is historical and
superseded by the user's current policy. All original source, conditions, failed
fixture and adverse results remain unchanged; no old component timing is repeated.

Current JSON still used the original invariant double.Parse entry. Replace the
entire default floating conversion entry with public UTF-8 Utf8Parser after the
existing prefix lexer validates the token. Require complete consumption; failure
is an invariant defect, never another-parser fallback/retry. General culture/
format entry overhead disappears. No parser framework, alternate execution mode,
representation, storage owner/cache, quota, unsafe API or dependency is added.
This does not retrospectively prove the old source would have improved, or explain
the cause of its unstable control.

Integer and explicit parse_float/parse_constant hooks retain existing behavior and
funded raw tokens. Grammar/error offsets, exact binary64 rounding/signed zero,
long mantissas/huge exponents and infinity/underflow remain. Both BCL conversions
are atomic: surrounding token scans/operations remain cancellable; no hard deadline
or abandoned background work is introduced. Public APIs are unchanged.

## Semantic, cancellation and ownership qualification

Existing semantic-only corpus, **2,191 independent CPython binary64/consumption
goldens**, matches both BCL entries on actual.NET11RC3 and.NET10.0.8. The reused
driver's historical B21 caption is retained; these are new semantic checks, no
component retiming. **257internal/1,160public Release checks per actual11/10 pass**,
matching probes. JSON scalar/nested/raw prefixes/options/hooks, actual callback
suspension/cancellation, admission/first terminal refusal, retained result/input
aliases and deterministic cleanup/budget reuse remain. No new architecture-only
test, changed expected Python result, relaxed assertion or timeout.

Existing five-script diagnostic uses independent old/current/old-control assemblies
sharing CoreLib/GC/hashing, both APIs, normal GC/tiering. Every full golden, shared
balance, image isolation and owned-fixture cleanup passes. **Allocation is neutral**
for float reports and essentially neutral for integer/CSV/text/report controls.
Desktop clocks are diagnostic: float sync−5.22to−12.91% with8.11%old drift, async
about−5.2%; integer sync is adverse+7.75–12.57%, text async+12.68/−5.12% with18.75%
old drift. Preserve all observations; they do not establish absence of regression.

## Controlled complete-script source pair

Quiet F4as_v7/Ubuntu24.04.4/.NET11RC3, same worker7cf37ca5/normal optional0.4adapter,
maintained numeric-report.py (read two arrays, sum, compute variance, JSON report)
and independent CLR full-output goldens. Float input56,495B, integer36,231B;
each has two4,096-element arrays. No new kernel or benchmark framework.
Two independent baseline/two current processes, five-second warmup/role/job,
seven rotated150ms rounds, normal GC/tiering. Four jobs complete in **115.362s**.
Negative elapsed means faster.

'''+table+'''
Float sync elapsed improves11.40–12.03%; async10.05–14.08% with2.2–2.4%between-
process spreads. Integer stays−1.02to+0.61%, text−0.49to−1.05%. The adverse local
integer result is not reproduced here; its cause remains unproven. Coarse whole-
process CPU is also favourable for floats (sync−10.93–11.86%, async−4.14–11.79%)
and near-flat for controls. Ten-millisecond quantization/protocol/background work
limit precise causal CPU claims. Retain the simpler validated entry and controlled
whole-script benefit. No universal speedup, current CPython multiplier, allocation
gain or repayment of unrelated text debt is claimed. Whole-script roadmap stays
active; this single confirmation does not complete the performance objective.

Warm includes invocation, mediated RAM I/O, full stdout/file validation and prior-
result cleanup. Compile/startup/staging/reset/protocol/final cached teardown excluded.
Async timing uses completed I/O; genuine suspension is correctness-tested.
No RSS/startup/pending-I/O/embedding-tail claim; desktop clocks include additional
fixture reset/disposal and cannot be compared absolutely.

All source/core/every auxiliary/actualReady/runtime/golden/quiet/Closed/exit/join/
empty-fixture gates pass. Persistent records stay outside owned128MiB RAM fixtures;
all users join/mounts disappear before archive verification under lease and locally.
Staging271,749,120B passes256MiB after reclaiming exactly two redundant B424 retired-
prototype core links, verified against archived81fba80c and SHA42020660. Immutable
VM and independent local archives retain all bytes. Exact path/free-byte receipt
remains.150sowner+30stop+30margin; no timeout/restart or terminal requery.
B430 is terminal/archived/verified. Source68d5bffe's full green baseline receipt is
separate; new-source qualification is pending. Publication postponed.

[Controlled assessment](assessment.json), [allocation/adverse desktop](local-assessment.json),
[focused/semantic checks](focused.json), [exact identities](identity.json), [VM identities](vm-identity.json),
[source gate](selected-plan.md), [contract](contract.md),
[reclaimed redundant core links](reclaimed-prototype-links.json),
[VM raw archive](observations.tgz), [local sources/cores/corpus/logs/raw](local-observations.tar.xz).
''',encoding='utf-8')
receipt['localArchiveSHA256']=hashlib.sha256((out/'local-observations.tar.xz').read_bytes()).hexdigest()
(out/'archive-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8')
p=Path('docs/BENCHMARKS.md');s=p.read_text(encoding='utf-8');anchor='| General UTF-8 integer parsing'
s=s.replace(anchor,'| Validated JSON floating conversion / numeric report | Allocation neutral; controlled warm elapsed −11.40–12.03% sync/−10.05–14.08% async | Integer/text controls near baseline; old inconclusive and adverse desktop retained, full new-source delivery pending. [R74](../benchmarks/results/2026-11-08-json-float-entry/README.md) |\n'+anchor);p.write_text(s,encoding='utf-8')
p=Path('benchmarks/EXPERIMENTS.md');p.write_text(p.read_text(encoding='utf-8')+'''
## Validated floating-entry reassessment

[R74/B430](results/2026-11-08-json-float-entry/README.md) revisits the old candidate
withdrawn under36.7%unchanged-control drift/no-retiming policy. Current source uses
the same original entry, so a bounded current confirmation is justified. Preserve
the complete older evidence; no component retiming. Replace invariant double.Parse
for lexer-validated default JSON floats with public Utf8Parser/complete consumption;
no fallback/new framework/cache/owner/dependency/unsafe mechanism.2,191semantic
goldens and257internal/1,160public per actual11/10 pass, including cancellation,
actual hooks/suspension/refusal/retained aliases/cleanup. Allocation neutral.
Four-job controlled pair115.362s/all gates: float elapsed−11.40–12.03%sync and
−10.05–14.08%async; integer−1.02to+0.61%, text−0.49to−1.05%. CoarseCPU favourable
but quantized; adverse desktop integer+7.75–12.57% and variable text stay visible.
Retain current simpler entry/whole-script benefit without claiming old causality,
universalCPU/CPython gain or objective completion. Fully green source68d5bffe is
the baseline only; new full delivery pending. Verified B424 redundant prototype
core links reclaimed with all immutable/local archives retained. B430 terminal/
archived/verified; publication postponed, broader roadmap remains active.
''',encoding='utf-8')
for p in [out/'README.md',Path('docs/BENCHMARKS.md')]:
 for target in re.findall(r'\]\(([^)]+)\)',p.read_text(encoding='utf-8')):
  if '://'not in target and not target.startswith('#'):assert(p.parent/target.split('#',1)[0]).exists(),(p,target)
print('R74 retained with controlled whole-script benefit; original inconclusive/adverse evidence, precise qualification status and every source/archive/link gate preserved.')
