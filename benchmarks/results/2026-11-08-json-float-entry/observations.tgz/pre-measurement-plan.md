# Lokad.Lython 0.11.0

Updated 2026-11-08. Git-ignored; never force-add. Publication and tagging postponed.
Objective: coherent design simplification and substantial complete-script performance.
An isolated experiment does not complete that objective. Historical narratives,
original failed conditions and raw measurements remain in benchmarks/EXPERIMENTS.md
and results; docs describe the current implementation.

## Delivery status

| Work | Actual status |
| --- | --- |
| Shared compiler facts, direct UTF-8 formatting/storage, native helper returns | Committed and fully qualified. Native-return allocation −19.92%/−19.31%; original elapsed diagnostic. Formatting allocation −8.67%; controlled B102 elapsed/CPU −5–8%, original adverse 15.125 ms preserved and unexplained. Do not repeat unchanged qualification. |
| R62 / 70267889 | Fully qualified CI42412531882, cached terminal green. |
| R65/R66 / 824fc6bb | Fully qualified CI42418518578: Windows/Ubuntu Release actual .NET 11/10, original Stress and installed core consumers. |
| R67 / 5076359c | Current CPython guide measures 824fc6bb/core15c04e2a, 23 jobs/478.32 s. Compile, warm and compile-to-result separate; I/O/validation/cleanup boundaries explicit. Original failed B406 and historical 55e510ff preserved. Not today's HEAD. |
| R68 / 5076359c | Exact immutable dev55/d6067925: 86 internal/514 public per actual 11/10, unchanged adapter bridge. Normal optional 0.4 pin/core unchanged. Development compatibility only. |
| R69 / fd5ab1c1 | Complete returned-record CSV script, independent goldens/CPython checks and current attribution committed; production unchanged. |
| R70 / 7a81a629 | Fully qualified CI42422556519: Windows/Ubuntu Release actual 11/10, original Stress and installed consumers. Cached terminal receipt; never requery. Immutable tuple unpacking removes iterator/list/copy/reservation work. Allocation −13.57% sync/−14.40% async; controlled affected elapsed −6.45–7.45% sync/−7.01–9.34% async. |
| R71 / f88191f7 + a34f56b5 | f88191f7 fully qualified CI42426106105, cached terminal green. Subsequent readonly transport correction: 1,366 internal/244 public per actual11/10, B427 complete; full corrected delivery batches with R72. B424/B425 adverse originals retained. |
| R72 / 68d5bffe | Committed/pushed. 1,729 internal/597 public per actual11/10, matching probes, 20 baseline cases. B428 complete/archived/verified: allocation −23.48% sync/−21.69% async; affected controlled elapsed −1.92–4.79% sync/−2.76–6.49% async. Combined full platform/Stress/package delivery dispatched once, pending. |

## Retained checkpoint / pending delivery

R71's route consolidation (f88191f7) is fully qualified by cached green
CI42426106105. The readonly descriptor correction (a34f56b5) and complete intrinsic
list/tuple construction deletion (68d5bffe) are committed/pushed. Their combined
full delivery CI42428096630 is in progress: Windows/Ubuntu actual11/10, original
Stress and installed core consumers. Observe no earlier than00:21:30 UTC, then at
least five minutes apart; cache terminal receipts once. Never requery old green
runs or dispatch unchanged qualification. Continue independent development while
CI runs. Publication/tagging remain postponed.

B429/R73 is complete: five jobs/107.441s, source68d5bffe/corea0aef9ef, exact
source/Ready/reference/runtime/golden/quiet/join/fixture/archive gates pass.
Returned-record CSV compile1.07–1.10×, warm1.32–1.35×, compile-to-result1.31–1.34×
CPython3.13.16 (variable control/compilation IQR). Current ordinary CSV warm
1.16–1.19× variable, text1.67–1.68× diagnostic. Authoritative docs/BENCHMARKS.md
marks new revision/date, separates all three boundaries, and preserves valid older
source824fc6bb rows. No inferred source-pair ratio, wholesale replay or general CPU
gain. Histories/raw evidence stay under benchmarks/results and EXPERIMENTS.

R71/B425's large ordinary-CSV adverse observation is not reproduced after concrete
Linux transport correction; its full cause is unproven. R72 retains text mixed/
adverse coarse CPU up to+6.67%. Original conditions/results stay visible; no debt
repayment by unrelated improvements. Further release acceptance must decide any
remaining regression debt. The complete-script performance objective is still open.

## Active R74 — reassess a promising complete JSON conversion entry

The bounded operand/call-frame gate found direct slots, native helpers, skipped
local stores and native string-key dictionary paths already implemented. A tiny
carrier rewrite or another dispatch path is not selected. Larger class-fact fusion
still requires distinct demands and is not justified as an immediate ordinary-script
win. Preserve R63/R64/R65 and rejected call-arena/control/window lessons.

Selected existing evidence: the 2026-11-01 JSON float-entry candidate was withdrawn
after an unchanged control shifted36.7%; no whole-job gain or stable regression was
established. It matched2,191 CPython rounding/consumption cases on actual11/10;
standalone entry timing was43% lower. Current default JSON uses the same original
invariant double.Parse. Historical no-retiming/stop instructions are superseded,
not a reason to leave promising uncertainty permanently closed.

Hypothesis/work removed: replace the entire lexer-validated default floating entry
with public UTF-8 Utf8Parser, removing general culture/format entry overhead. It
adds no conversion copy, parser framework, cache, owner, public option or dependency.
Complete float JSON reports are affected; integer report and ordinary text/CSV are
controls. No predicted whole-script gain; old inclusive samples are diagnostic.

Acceptance and bounded completion:
- Preserve exact IEEE bits, signed zero, huge exponents/mantissas, overflow/underflow,
  prefix grammar/errors, hooks/raw tokens, current cancellation, admission/aliases/
  retained results and cleanup. Both BCL conversions remain atomic; no hard deadline.
- Reuse semantic-only2,191-token corpus without component retiming; focused Release
  actual11/10 JSON/protocol/cancellation/refusal/ownership tests, matching probes.
- Existing five-script allocation diagnostic and one four-job quiet-VM pair:
  float report warm/warm-async, integer report/text warm; two old/two current roles,
 5s warmup/role,7rotated150ms,150+30+30s bound. Every identity/golden/quiet/cleanup/
  archive gate remains. Keep original and new adverse/variable observations.
- Finish with retained/restored source, actual code deletion, explicit regression
  disposition and documentation. No fallback/retry, forced percentage veto or
  wholesale primary-baseline refresh. Batch full delivery if retained. Then select
  the next coherent roadmap boundary; this does not complete the performance goal.

## Following substantial redesign boundaries

| Boundary | Evidence / eliminated work / acceptance |
| --- | --- |
| Complete calls/frames and operand transport | Indexed operands/native returns/final slots/deferred contexts already exist. R63 text attribution includes useful arithmetic/dispatch; inclusive calls are not removable CPU. Select a complete remaining transport/activation phase, remove its displaced path. Preserve callbacks, exception state, exact integer promotion/identity, aliases and public projection. No universal tagged-value or arena rewrite without dominant-cost evidence. |
| Per-record storage | R20/R25 shared CSV keys/array transfer/direct JSON slots and R70 tuple borrow supersede the rigidly rejected bulk-CSV attempt. Its 6–8% benefit and adverse control remain historical. Reassess a real remaining construction/copy/capacity phase; no automatic revival. Preserve row mutation/reentry/hooks/order/retained aliases. |
| Bulk text/JSON | Direct UTF-8 casing/lower-split/formatting/native parsing, completed JSON loop and shared line scanner delivered. R61 measured ordinary JSON has no escaped tokens. Select a demonstrated whole conversion/storage phase, preserve Unicode/context/hooks/async I/O; no succession of narrow special cases. |
| Frontend facts | R55/R58/R62/R65 remove repeated lexical/graph/validity/module work. Remaining class/function demands have distinct scope/annotation rules. Require concrete repeated-walk deletion with exact diagnostics; no speculative visitor/cache/parser migration. |

For each selected milestone record the hypothesis, work/storage eliminated, affected
complete scripts, semantic/cancellation/admission acceptance and old implementation
removed. One bounded source/generated-code assessment; focused attribution only if
existing evidence cannot select. Stop at a concrete phase or insufficient evidence,
then choose another boundary. Prior call-arena/call-control slowdowns remain lessons,
not dormant alternatives. Architectural simplification, allocation reduction, elapsed
and CPU are distinct. Fixed improvement percentages inform judgment, never automatic
vetoes. A timeout or unstable unchanged control establishes uncertainty. Allow bounded
confirmation/refinement/measurement correction when justified, retaining all original
adverse and failed conditions. No blanket one-attempt/no-retiming/permanent closure.

At the next combined retained checkpoint refresh representative CPython comparisons:
compilation, warm execution and compile-to-result separately; identical full scripts/
goldens, explicit I/O/validation/cleanup and startup boundaries. Current R67 guide
remains accurate for its named source; do not rerun unchanged qualification after
every experiment or imply that its tables describe today's HEAD.

## Independent regex track

Core owns Python/native UTF-8 semantics, byte ranges/scalar positions/original-subject
windows, flags/captures/replacements/errors, cache ownership/current tokens and one
provider through frontend/runtime/imports. No Utf8Regex core dependency. Optional
adapter stays nonpackable, normal 0.4 pin. Contract tests, semantic compatibility and
actual backend performance are separate. Development producers/adapter-local bridges
support implementation; missing publication defers only affected final qualification.

Precise dev55 gaps: DetailedData has no separate preparation/working-owner input;
native name lookup lacks enumeration; cursor creation retains its token despite
current-move overloads. Existing bridges remain justified. No sibling edits/builds,
producer-CI replay, dialect fallback, quotas, memory subsystem or abandoned matching.
Released-package/managed-safety/backend-performance qualification remains outstanding;
it must not stop independent core development or performance work.

## Lasting validation and ownership constraints

AGENTS.md governs fully managed/memory-safe code and managed stack admission: no
unsafe/Unsafe/PInvoke/raw pointers/native probes. Preserve host capabilities, effective
cancellation, checked representation bounds, XML depth and bounded I/O chunks.
Borrow the shared allowance for coarse preflights, capacity/replacement overlap,
retained aliases and escaping caches/results. Scope creation reserves nothing; no
hidden allowances/caps/fuel/quotas/tracing/weak reclamation/forced GC. Initial long
streams use bounded host-driven executions. First structured refusal is terminal
through guest suppression/finally returns; native refunds/cleanup remain awaited.
Never retry admission or skip optional storage to recover.

Focused Release checks during iteration; build matching probes, exclude Stress
explicitly when a custom filter is supplied. No overlapping local builds/tests/
measurements. Force nonincremental builds after timestamp-preserving source restores.
Batch full Windows/Ubuntu actual 11/10, original Stress and installed core consumers
at coherent retained boundaries. Use explicit UTF-8. Only core Release pack via
tools/pack.ps1 into artifacts/nuget; no adapter packages/publication/tag promotion.

VM lokad@20.166.121.73, key ~/.ssh/id_lython-bench.pem. B385–B429 are terminal,
archived/locally verified; never query again. No active VM collection. Persistent
workers/records remain separate from owned RAM fixtures; keep 256 MiB staging floor,
join all users/unmount/archive under lease and verify locally. Reclaim only verified
redundant extracts while retaining immutable evidence. No sole RAM evidence. Space
GitHub status observations at least five minutes apart; never requery cached terminal
runs or duplicate dispatch. Continue the roadmap while CI runs.
