from pathlib import Path
from textwrap import dedent, indent
tree=Path('.git/agent-worktrees/dictreader-activation-20261123')
p=tree/'src/Lokad.Lython/Runtime/LythonRuntime.CsvObjects.cs'
source=p.read_text(encoding='utf-8')
start=source.index('        private async ValueTask<object> GetFieldNamesAsync')
end=source.index('        private PyList RestFields',start)
old=source[start:end]
fast=old[old.index('                var recordKeys = _recordKeys;'):old.index('                var result = new PyDict(_context.MemoryGovernor')]
fast=dedent(fast).replace('row = null; // The dictionary now owns this funded capacity.','ownsRow = false; // The dictionary now owns this funded capacity.').replace('return PyIterationResult.Yield(adopted);','return new(PyIterationResult.Yield(adopted));').replace('return PyIterationResult.Yield(record);','return new(PyIterationResult.Yield(record));')
general=old[old.index('                var result = new PyDict(_context.MemoryGovernor'):old.index('            finally\n            {\n                if (row is not null)')]
general=dedent(general[:general.rindex('            }')])
new="""        private ValueTask<object[]?> ReadRow(bool asynchronous)
            => asynchronous ? Rows.TryMoveNextAsync() : new(Rows.TryMoveNext(out var row) ? row : null);

        private ValueTask<object> GetFieldNamesAsync(bool asynchronous)
        {
            if (_fieldNames is not PyNone) return new(CompleteFieldNames(null));
            var pending = ReadRow(asynchronous);
            return pending.IsCompletedSuccessfully ? new(CompleteFieldNames(pending.Result)) : AwaitFieldNamesAsync(pending);
        }

        private async ValueTask<object> AwaitFieldNamesAsync(ValueTask<object[]?> pending)
            => CompleteFieldNames(await pending.ConfigureAwait(false));

        private object CompleteFieldNames(object[]? row)
        {
            if (row is not null) _fieldNames = Rows.AdoptRecord(row);
            _lineNumber.SetInteger(Rows.PhysicalLineCount);
            return _fieldNames;
        }

        public PyIterationResult TryMoveNext() => Next(false).GetAwaiter().GetResult();
        public ValueTask<PyIterationResult> TryMoveNextAsync() => Next(true);

        private ValueTask<PyIterationResult> Next(bool asynchronous)
        {
            _context.CheckExecution(_span);
            var hasCount = _lineNumber.TryGetInteger(out var count);
            return hasCount && count != 0 ? ReadDataRow(asynchronous) : ReadAfterInitialHeaderAsync(hasCount, asynchronous);
        }

        private async ValueTask<PyIterationResult> ReadAfterInitialHeaderAsync(bool hasCount, bool asynchronous)
        {
            var needsHeader = hasCount;
            if (!hasCount)
            {
                // DictReader allows guest-assigned values and honors their protocols.
                var lineNumber = _lineNumber.Object.RequireNotNull();
                var zero = asynchronous
                    ? await EvaluateBinaryOperatorAsync(BinaryOperatorSyntax.Equal, lineNumber, BigInteger.Zero, _context, _span).ConfigureAwait(false)
                    : EvaluateBinaryOperator(BinaryOperatorSyntax.Equal, lineNumber, BigInteger.Zero, _context, _span);
                needsHeader = asynchronous ? await IsTruthyAsync(zero, _context, _span).ConfigureAwait(false)
                    : LythonRuntime.IsTruthy(zero, _context, _span);
            }
            if (needsHeader)
                _ = await GetFieldNamesAsync(asynchronous).ConfigureAwait(false);
            return await ReadDataRow(asynchronous).ConfigureAwait(false);
        }

        private ValueTask<PyIterationResult> ReadDataRow(bool asynchronous)
        {
            var pending = ReadRow(asynchronous);
            return pending.IsCompletedSuccessfully ? CompleteDataRow(pending.Result, asynchronous)
                : AwaitDataRowAsync(pending, asynchronous);
        }

        private async ValueTask<PyIterationResult> AwaitDataRowAsync(ValueTask<object[]?> pending, bool asynchronous)
            => await CompleteDataRow(await pending.ConfigureAwait(false), asynchronous).ConfigureAwait(false);

        private ValueTask<PyIterationResult> CompleteDataRow(object[]? row, bool asynchronous)
        {
            if (row is null) return new(PyIterationResult.End);
            _lineNumber.SetInteger(Rows.PhysicalLineCount);
            if (row.Length != 0) return BuildRow(row, asynchronous);
            Rows.ReleaseRecord(row);
            return SkipBlankRowsAsync(asynchronous);
        }

        private async ValueTask<PyIterationResult> SkipBlankRowsAsync(bool asynchronous)
        {
            while (await ReadRow(asynchronous).ConfigureAwait(false) is { } row)
            {
                if (row.Length != 0) return await BuildRow(row, asynchronous).ConfigureAwait(false);
                Rows.ReleaseRecord(row);
            }
            return PyIterationResult.End;
        }

        private ValueTask<PyIterationResult> BuildRow(object[] row, bool asynchronous)
        {
            // A suspended row pull can change fieldnames. Resolve the actual
            // header while the row's storage is still owned by this operation.
            ValueTask<object> pending;
            try { pending = GetFieldNamesAsync(asynchronous); }
            catch { Rows.ReleaseRecord(row); throw; }
            return pending.IsCompletedSuccessfully ? BuildRecord(row, pending.Result, asynchronous)
                : AwaitHeaderAndBuildAsync(row, pending, asynchronous);
        }

        private async ValueTask<PyIterationResult> AwaitHeaderAndBuildAsync(object[] row, ValueTask<object> pending, bool asynchronous)
        {
            object fields;
            try { fields = await pending.ConfigureAwait(false); }
            catch { Rows.ReleaseRecord(row); throw; }
            return await BuildRecord(row, fields, asynchronous).ConfigureAwait(false);
        }

        private ValueTask<PyIterationResult> BuildRecord(object[] row, object fields, bool asynchronous)
        {
            var ownsRow = true;
            try
            {
""" + indent(fast, ' '*16) + """                var result = BuildProtocolRecordAsync(row, fields, asynchronous);
                ownsRow = false;
                return result;
            }
            finally
            {
                if (ownsRow) Rows.ReleaseRecord(row);
            }
        }

        private async ValueTask<PyIterationResult> BuildProtocolRecordAsync(object[] row, object fields, bool asynchronous)
        {
            try
            {
""" + indent(general, ' '*16) + """
            }
            finally { Rows.ReleaseRecord(row); }
        }

"""
p.write_text(source[:start]+new+source[end:],encoding='utf-8',newline='\n')
lab=Path('.git/agent-notes/review-20261031/dictreader-activation-20261123')
oldtest=lab.parent/'buffered-csv-read-completion-20261123'/'test-platform.py'
t=oldtest.read_text(encoding='utf-8').replace('buffered-csv-read-completion-20261123','dictreader-activation-20261123')
t=t.replace('DOTNET_HOST_PATH=str(windows_dotnet))','DOTNET_HOST_PATH=str(windows_dotnet),PATH=str(windows_dotnet.parent)+os.pathsep+os.environ["PATH"])')
(lab/'test-platform.py').write_text(t,encoding='utf-8',newline='\n')
