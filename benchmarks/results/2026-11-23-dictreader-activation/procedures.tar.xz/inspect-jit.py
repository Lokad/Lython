from pathlib import Path
import json,hashlib,os,re,subprocess
lab=Path(__file__).resolve().parent
identity=json.loads((lab/'comparison/identity.json').read_text(encoding='utf-8'))
dotnet=Path.home()/'.dotnet11/dotnet.exe'
env=dict(os.environ,DOTNET_ROOT=str(dotnet.parent),DOTNET_ROOT_X64=str(dotnet.parent))
rows=[]
for role,files in identity['imageFiles'].items():
    image=lab/role
    assert all(hashlib.sha256((image/name).read_bytes()).hexdigest()==digest for name,digest in files.items())
    log=lab/(role+'-reader.asm')
    output=lab/(role+'-jit-allocation.json')
    subprocess.run([dotnet,image/'ValidatedAllocation.dll',image,lab/'representative.json',output],
        env=dict(env,DOTNET_JitDisasm="*CsvDictReaderObject*:Next* *CsvDictReaderObject*:ReadDataRow *CsvDictReaderObject*:BuildRecord *CsvDictReaderObject*:TryMoveNext",
                 DOTNET_JitStdOutFile=str(log)),timeout=50,check=True)
    assert all(row['sharedBudgetBaselineRestored'] for row in json.loads(output.read_text(encoding='utf-8'))['rows'])
    methods=[]
    for entry in log.read_text(encoding='utf-8-sig').split('; Assembly listing for method ')[1:]:
        signature, asm=entry.split('\n',1)
        method=re.search(r':([A-Za-z0-9_]+)\(',signature)[1]
        stack=re.search(r"\bsub\s+rsp,\s*(\d+)\b",asm)
        totals=re.search("Total bytes of code (\\d+)",asm)
        methods.append(dict(signature=signature,method=method,tier=signature.rsplit(' (',1)[-1].strip(')'),
                     stack=int(stack[1]) if stack else 0,bytes=int(totals[1])))
    print(role,[(item['method'],item['stack'],item['bytes']) for item in methods if item['tier']=='Tier1'])
    assert any('TryMoveNext' in method['signature'] for method in methods)
    rows.append(dict(role=role,methods=methods,coreSHA256=files['Lokad.Lython.dll']))
(lab/'jit-summary.json').write_text(json.dumps(rows,indent=2)+'\n',encoding='utf-8',newline='\n')
