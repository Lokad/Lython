using System.Reflection;
using System.Reflection.Emit;
using System.Reflection.Metadata;
using System.Reflection.Metadata.Ecma335;
using System.Reflection.PortableExecutable;

using var pe = new PEReader(File.OpenRead(args[0]));
var metadata = pe.GetMetadataReader();
var opcodes = typeof(OpCodes).GetFields(BindingFlags.Public | BindingFlags.Static)
    .Select(field => (OpCode)field.GetValue(null)!)
    .ToDictionary(opcode => (ushort)opcode.Value);
foreach (var handle in metadata.TypeDefinitions)
{
    var type = metadata.GetTypeDefinition(handle);
    if (!metadata.GetString(type.Name).StartsWith("<NextAsync>")) continue;
    var declaring = metadata.GetTypeDefinition(type.GetDeclaringType());
    if (metadata.GetString(declaring.Name) != "CsvDictReaderObject") continue;
    var token = MetadataTokens.GetToken(type.GetMethods().First(method =>
        metadata.GetString(metadata.GetMethodDefinition(method).Name) == "MoveNext"));
    var target = 0;
    var method = metadata.GetMethodDefinition(MetadataTokens.MethodDefinitionHandle(token & 0x00ffffff));
    var bytes = pe.GetMethodBody(method.RelativeVirtualAddress).GetILBytes()!;
    Console.WriteLine($"{metadata.GetString(method.Name)} ({token:x8}), target IL{target:x4}");
    for (var i = 0; i < bytes.Length;)
    {
        var offset = i;
        var opcode = opcodes[bytes[i] == 0xfe ? (ushort)(0xfe00 + bytes[++i]) : bytes[i]];
        i++;
        var size = opcode.OperandType switch
        {
            OperandType.InlineNone => 0,
            OperandType.ShortInlineBrTarget or OperandType.ShortInlineI or OperandType.ShortInlineVar => 1,
            OperandType.InlineVar => 2,
            OperandType.InlineI8 or OperandType.InlineR => 8,
            OperandType.InlineSwitch => checked(4 + 4 * BitConverter.ToInt32(bytes, i)),
            _ => 4
        };
        if (opcode == OpCodes.Newobj || opcode == OpCodes.Call || opcode == OpCodes.Callvirt || opcode == OpCodes.Ret)
        {
            var operand = Convert.ToHexString(bytes.AsSpan(i, size));
            if (opcode.OperandType is OperandType.InlineField or OperandType.InlineMethod or OperandType.InlineType
                or OperandType.InlineTok)
            {
                var edit = MetadataTokens.EntityHandle(BitConverter.ToInt32(bytes, i));
                operand = edit.Kind switch
                {
                    HandleKind.MethodDefinition => NameOfMethod((MethodDefinitionHandle)edit),
                    HandleKind.FieldDefinition => metadata.GetString(metadata.GetFieldDefinition((FieldDefinitionHandle)edit).Name),
                    HandleKind.MemberReference => metadata.GetString(metadata.GetMemberReference((MemberReferenceHandle)edit).Name),
                    HandleKind.TypeDefinition => metadata.GetString(metadata.GetTypeDefinition((TypeDefinitionHandle)edit).Name),
                    HandleKind.TypeReference => metadata.GetString(metadata.GetTypeReference((TypeReferenceHandle)edit).Name),
                    _ => operand
                };
            }
            Console.WriteLine($"IL{offset:x4} {opcode.Name} {operand}");
        }
        i += size;
    }
}

string NameOfMethod(MethodDefinitionHandle handle)
{
    var method = metadata.GetMethodDefinition(handle);
    return metadata.GetString(metadata.GetTypeDefinition(method.GetDeclaringType()).Name) + "." + metadata.GetString(method.Name);
}
