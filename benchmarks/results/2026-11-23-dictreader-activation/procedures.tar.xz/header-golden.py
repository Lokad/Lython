import csv
class Source:
    i=0
    def __iter__(self):
        return self
    def __next__(self):
        self.i += 1
        if self.i == 1:
            return '1,2'
        if self.i == 2:
            reader.fieldnames=['x','y']
            return '3,4'
        raise StopIteration
reader=csv.DictReader(Source(),fieldnames=['a','b'])
first=next(reader)
second=next(reader)
print(first,second,reader.line_num)
