; Assembly listing for method Lokad.Lython.Runtime.LythonRuntime+CsvDictReaderObject:TryMoveNext():Lokad.Lython.Runtime.PyIterationResult:this (Tier0)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; Tier0 code
; rbp based frame
; partially interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 96
       lea      rbp, [rsp+0x60]
       vxorps   xmm4, xmm4, xmm4
       vmovdqu  ymmword ptr [rbp-0x40], ymm4
       vmovdqu  ymmword ptr [rbp-0x20], ymm4
       mov      gword ptr [rbp+0x10], rcx
       mov      qword ptr [rbp+0x18], rdx
 
G_M000_IG02:                ;; offset=0x0020
       lea      rdx, [rbp-0x20]
       mov      rcx, gword ptr [rbp+0x10]
       xor      r8d, r8d
       call     [Lokad.Lython.Runtime.LythonRuntime+CsvDictReaderObject:NextAsync(bool):System.Threading.Tasks.ValueTask`1[Lokad.Lython.Runtime.PyIterationResult]:this]
       lea      rdx, [rbp-0x40]
       lea      rcx, [rbp-0x20]
       call     [System.Threading.Tasks.ValueTask`1[Lokad.Lython.Runtime.PyIterationResult]:GetAwaiter():System.Runtime.CompilerServices.ValueTaskAwaiter`1[Lokad.Lython.Runtime.PyIterationResult]:this]
       lea      rcx, [rbp-0x40]
       mov      rdx, qword ptr [rbp+0x18]
       call     [System.Runtime.CompilerServices.ValueTaskAwaiter`1[Lokad.Lython.Runtime.PyIterationResult]:GetResult():Lokad.Lython.Runtime.PyIterationResult:this]
       mov      rax, qword ptr [rbp+0x18]
 
G_M000_IG03:                ;; offset=0x0051
       add      rsp, 96
       pop      rbp
       ret      
 
; Total bytes of code 87

; Assembly listing for method Lokad.Lython.Runtime.LythonRuntime+CsvDictReaderObject:NextAsync(bool):System.Threading.Tasks.ValueTask`1[Lokad.Lython.Runtime.PyIterationResult]:this (Tier0)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; Tier0 code
; rbp based frame
; partially interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 288
       lea      rbp, [rsp+0x120]
       vxorps   xmm4, xmm4, xmm4
       vmovdqa  xmmword ptr [rbp-0x100], xmm4
       mov      rax, -240
 
G_M000_IG04:                ;; offset=0x0026
       vmovdqa  xmmword ptr [rax+rbp], xmm4
       vmovdqa  xmmword ptr [rbp+rax+0x10], xmm4
       vmovdqa  xmmword ptr [rbp+rax+0x20], xmm4
       add      rax, 48
       jne      SHORT G_M000_IG04
       mov      gword ptr [rbp+0x10], rcx
       mov      qword ptr [rbp+0x18], rdx
       mov      dword ptr [rbp+0x20], r8d
 
G_M000_IG02:                ;; offset=0x0049
       lea      rcx, [rbp-0xC8]
       call     [System.Runtime.CompilerServices.AsyncValueTaskMethodBuilder`1[Lokad.Lython.Runtime.PyIterationResult]:Create():System.Runtime.CompilerServices.AsyncValueTaskMethodBuilder`1[Lokad.Lython.Runtime.PyIterationResult]]
       mov      rax, gword ptr [rbp+0x10]
       mov      gword ptr [rbp-0x100], rax
       mov      eax, dword ptr [rbp+0x20]
       mov      byte  ptr [rbp-0xCC], al
       mov      dword ptr [rbp-0xD8], -1
       lea      rdx, [rbp-0x100]
       lea      rcx, [rbp-0xC8]
       call     [System.Runtime.CompilerServices.AsyncValueTaskMethodBuilder`1[Lokad.Lython.Runtime.PyIterationResult]:Start[Lokad.Lython.Runtime.LythonRuntime+CsvDictReaderObject+<NextAsync>d__19](byref):this]
       lea      rcx, [rbp-0xC8]
       mov      rdx, qword ptr [rbp+0x18]
       call     [System.Runtime.CompilerServices.AsyncValueTaskMethodBuilder`1[Lokad.Lython.Runtime.PyIterationResult]:get_Task():System.Threading.Tasks.ValueTask`1[Lokad.Lython.Runtime.PyIterationResult]:this]
       mov      rax, qword ptr [rbp+0x18]
 
G_M000_IG03:                ;; offset=0x009D
       add      rsp, 288
       pop      rbp
       ret      
 
; Total bytes of code 166

; Assembly listing for method Lokad.Lython.Runtime.LythonRuntime+CsvDictReaderObject:TryMoveNext():Lokad.Lython.Runtime.PyIterationResult:this (Instrumented Tier0)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; Instrumented Tier0 code
; rbp based frame
; partially interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 96
       lea      rbp, [rsp+0x60]
       vxorps   xmm4, xmm4, xmm4
       vmovdqu  ymmword ptr [rbp-0x40], ymm4
       vmovdqu  ymmword ptr [rbp-0x20], ymm4
       mov      gword ptr [rbp+0x10], rcx
       mov      qword ptr [rbp+0x18], rdx
 
G_M000_IG02:                ;; offset=0x0020
       lea      rdx, [rbp-0x20]
       mov      rcx, gword ptr [rbp+0x10]
       xor      r8d, r8d
       call     [Lokad.Lython.Runtime.LythonRuntime+CsvDictReaderObject:NextAsync(bool):System.Threading.Tasks.ValueTask`1[Lokad.Lython.Runtime.PyIterationResult]:this]
       lea      rdx, [rbp-0x40]
       lea      rcx, [rbp-0x20]
       call     [System.Threading.Tasks.ValueTask`1[Lokad.Lython.Runtime.PyIterationResult]:GetAwaiter():System.Runtime.CompilerServices.ValueTaskAwaiter`1[Lokad.Lython.Runtime.PyIterationResult]:this]
       lea      rcx, [rbp-0x40]
       mov      rdx, qword ptr [rbp+0x18]
       call     [System.Runtime.CompilerServices.ValueTaskAwaiter`1[Lokad.Lython.Runtime.PyIterationResult]:GetResult():Lokad.Lython.Runtime.PyIterationResult:this]
       mov      rax, qword ptr [rbp+0x18]
 
G_M000_IG03:                ;; offset=0x0051
       add      rsp, 96
       pop      rbp
       ret      
 
; Total bytes of code 87

; Assembly listing for method Lokad.Lython.Runtime.LythonRuntime+CsvDictReaderObject:NextAsync(bool):System.Threading.Tasks.ValueTask`1[Lokad.Lython.Runtime.PyIterationResult]:this (Instrumented Tier0)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; Instrumented Tier0 code
; rbp based frame
; partially interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 288
       lea      rbp, [rsp+0x120]
       vxorps   xmm4, xmm4, xmm4
       vmovdqa  xmmword ptr [rbp-0x100], xmm4
       mov      rax, -240
 
G_M000_IG04:                ;; offset=0x0026
       vmovdqa  xmmword ptr [rax+rbp], xmm4
       vmovdqa  xmmword ptr [rbp+rax+0x10], xmm4
       vmovdqa  xmmword ptr [rbp+rax+0x20], xmm4
       add      rax, 48
       jne      SHORT G_M000_IG04
       mov      gword ptr [rbp+0x10], rcx
       mov      qword ptr [rbp+0x18], rdx
       mov      dword ptr [rbp+0x20], r8d
 
G_M000_IG02:                ;; offset=0x0049
       lea      rcx, [rbp-0xC8]
       call     [System.Runtime.CompilerServices.AsyncValueTaskMethodBuilder`1[Lokad.Lython.Runtime.PyIterationResult]:Create():System.Runtime.CompilerServices.AsyncValueTaskMethodBuilder`1[Lokad.Lython.Runtime.PyIterationResult]]
       mov      rax, gword ptr [rbp+0x10]
       mov      gword ptr [rbp-0x100], rax
       mov      eax, dword ptr [rbp+0x20]
       mov      byte  ptr [rbp-0xCC], al
       mov      dword ptr [rbp-0xD8], -1
       lea      rdx, [rbp-0x100]
       lea      rcx, [rbp-0xC8]
       call     [System.Runtime.CompilerServices.AsyncValueTaskMethodBuilder`1[Lokad.Lython.Runtime.PyIterationResult]:Start[Lokad.Lython.Runtime.LythonRuntime+CsvDictReaderObject+<NextAsync>d__19](byref):this]
       lea      rcx, [rbp-0xC8]
       mov      rdx, qword ptr [rbp+0x18]
       call     [System.Runtime.CompilerServices.AsyncValueTaskMethodBuilder`1[Lokad.Lython.Runtime.PyIterationResult]:get_Task():System.Threading.Tasks.ValueTask`1[Lokad.Lython.Runtime.PyIterationResult]:this]
       mov      rax, qword ptr [rbp+0x18]
 
G_M000_IG03:                ;; offset=0x009D
       add      rsp, 288
       pop      rbp
       ret      
 
; Total bytes of code 166

; Assembly listing for method Lokad.Lython.Runtime.LythonRuntime+CsvDictReaderObject:TryMoveNext():Lokad.Lython.Runtime.PyIterationResult:this (Tier1)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; Tier1 code
; optimized code
; optimized using Synthesized PGO
; rbp based frame
; fully interruptible
; with Synthesized PGO: fgCalledCount is 100
; No PGO data
; 4 inlinees with PGO data; 10 single block inlinees; 2 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       push     rdi
       push     rsi
       push     rbx
       sub      rsp, 424
       lea      rbp, [rsp+0x1C0]
       xor      eax, eax
       mov      qword ptr [rbp-0x188], rax
       vxorps   xmm4, xmm4, xmm4
       vmovdqa  xmmword ptr [rbp-0x180], xmm4
       mov      rax, -336
 
G_M000_IG36:                ;; offset=0x0032
       vmovdqa  xmmword ptr [rbp+rax-0x20], xmm4
       vmovdqa  xmmword ptr [rbp+rax-0x10], xmm4
       vmovdqa  xmmword ptr [rax+rbp], xmm4
       add      rax, 48
       jne      SHORT G_M000_IG36
       mov      qword ptr [rbp-0x20], rax
       mov      rbx, rdx
 
G_M000_IG02:                ;; offset=0x0050
       mov      gword ptr [rbp-0x118], rcx
       mov      byte  ptr [rbp-0xE4], 0
       mov      dword ptr [rbp-0xF0], -1
       mov      rcx, qword ptr GS:[0x0058]
       mov      rcx, qword ptr [rcx+0x48]
       cmp      dword ptr [rcx+0x250], 5
       jle      G_M000_IG18
       mov      rcx, gword ptr [rcx+0x258]
       mov      rax, bword ptr [rcx+0x28]
       test     rax, rax
       je       G_M000_IG18
 
G_M000_IG03:                ;; offset=0x0096
       mov      rsi, gword ptr [rax+0x10]
       test     rsi, rsi
       jne      SHORT G_M000_IG05
 
G_M000_IG04:                ;; offset=0x009F
       call     [System.Threading.Thread:InitializeCurrentThread():System.Threading.Thread]
       mov      rsi, rax
 
G_M000_IG05:                ;; offset=0x00A8
       mov      gword ptr [rbp-0x190], rsi
       mov      rdx, gword ptr [rsi+0x08]
       mov      gword ptr [rbp-0x198], rdx
       mov      rdx, gword ptr [rsi+0x10]
       mov      gword ptr [rbp-0x1A0], rdx
 
G_M000_IG06:                ;; offset=0x00C5
       lea      rcx, [rbp-0x118]
       call     [Lokad.Lython.Runtime.LythonRuntime+CsvDictReaderObject+<NextAsync>d__19:MoveNext():this]
       nop      
 
G_M000_IG07:                ;; offset=0x00D3
       mov      rdx, gword ptr [rbp-0x1A0]
       cmp      rdx, gword ptr [rsi+0x10]
       jne      G_M000_IG19
 
G_M000_IG08:                ;; offset=0x00E4
       mov      r8, gword ptr [rsi+0x08]
       cmp      gword ptr [rbp-0x198], r8
       jne      G_M000_IG20
 
G_M000_IG09:                ;; offset=0x00F5
       mov      rcx, gword ptr [rbp-0xE0]
       mov      rax, 0x19CE74022D0
       cmp      rcx, gword ptr [rax]
       jne      G_M000_IG21
 
G_M000_IG10:                ;; offset=0x010F
       vmovdqu  xmm0, xmmword ptr [rbp-0xD8]
       vmovdqu  xmmword ptr [rbp-0x168], xmm0
 
G_M000_IG11:                ;; offset=0x011F
       vmovdqu  ymm0, ymmword ptr [rbp-0x178]
       vmovdqu  ymmword ptr [rbp-0x138], ymm0
 
G_M000_IG12:                ;; offset=0x012F
       xor      rsi, rsi
 
G_M000_IG13:                ;; offset=0x0131
       test     rsi, rsi
       jne      G_M000_IG25
 
G_M000_IG14:                ;; offset=0x013A
       vmovdqu  xmm0, xmmword ptr [rbp-0x128]
       vmovdqu  xmmword ptr [rbp-0x188], xmm0
 
G_M000_IG15:                ;; offset=0x014A
       vmovdqu  xmm0, xmmword ptr [rbp-0x188]
       vmovdqu  xmmword ptr [rbx], xmm0
 
G_M000_IG16:                ;; offset=0x0156
       mov      rax, rbx
 
G_M000_IG17:                ;; offset=0x0159
       vzeroupper 
       add      rsp, 424
       pop      rbx
       pop      rsi
       pop      rdi
       pop      rbp
       ret      
 
G_M000_IG18:                ;; offset=0x0168
       mov      ecx, 5
       call     CORINFO_HELP_GETDYNAMIC_GCTHREADSTATIC_BASE_NOCTOR_OPTIMIZED
       jmp      G_M000_IG03
 
G_M000_IG19:                ;; offset=0x0177
       lea      rcx, bword ptr [rsi+0x10]
       call     CORINFO_HELP_ASSIGN_REF
       jmp      G_M000_IG08
 
G_M000_IG20:                ;; offset=0x0185
       mov      rcx, rsi
       mov      rdx, gword ptr [rbp-0x198]
       call     [System.Threading.ExecutionContext:RestoreChangedContextToThread(System.Threading.Thread,System.Threading.ExecutionContext,System.Threading.ExecutionContext)]
       jmp      G_M000_IG09
 
G_M000_IG21:                ;; offset=0x019A
       mov      rsi, gword ptr [rbp-0xE0]
       test     rsi, rsi
       jne      SHORT G_M000_IG22
       mov      rcx, 0x7FF9FD648D30
       call     CORINFO_HELP_NEWSFAST
       mov      rsi, rax
       mov      rcx, rsi
       call     [System.Threading.Tasks.Task:.ctor():this]
       mov      gword ptr [rbp-0xE0], rsi
 
G_M000_IG22:                ;; offset=0x01C8
       vxorps   xmm0, xmm0, xmm0
       vmovdqu  xmmword ptr [rbp-0x148], xmm0
 
G_M000_IG23:                ;; offset=0x01D4
       vmovdqu  ymm0, ymmword ptr [rbp-0x158]
       vmovdqu  ymmword ptr [rbp-0x138], ymm0
 
G_M000_IG24:                ;; offset=0x01E4
       jmp      G_M000_IG13
 
G_M000_IG25:                ;; offset=0x01E9
       mov      rdx, rsi
       mov      rcx, 0x7FF9FD648D30
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       mov      rdi, rax
       test     rdi, rdi
       je       SHORT G_M000_IG28
       mov      ecx, dword ptr [rdi+0x34]
       and      ecx, 0x11000000
       cmp      ecx, 0x1000000
       je       SHORT G_M000_IG26
       mov      rcx, rdi
       xor      edx, edx
       call     [System.Runtime.CompilerServices.TaskAwaiter:HandleNonSuccessAndDebuggerNotification(System.Threading.Tasks.Task,int)]
 
G_M000_IG26:                ;; offset=0x021F
       vmovdqu  xmm0, xmmword ptr [rdi+0x38]
       vmovdqu  xmmword ptr [rbp-0x188], xmm0
 
G_M000_IG27:                ;; offset=0x022C
       jmp      G_M000_IG15
 
G_M000_IG28:                ;; offset=0x0231
       lea      rdx, [rbp-0x188]
       mov      rcx, rsi
       mov      r11, 0x7FF9FCD229F8
       xor      r8d, r8d
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[Lokad.Lython.Runtime.PyIterationResult]:GetResult(short):Lokad.Lython.Runtime.PyIterationResult:this
       jmp      G_M000_IG15
 
G_M000_IG29:                ;; offset=0x0250
       sub      rsp, 40
 
G_M000_IG30:                ;; offset=0x0254
       mov      rdx, gword ptr [rbp-0x1A0]
       mov      rcx, gword ptr [rbp-0x190]
       cmp      rdx, gword ptr [rcx+0x10]
       je       SHORT G_M000_IG32
 
G_M000_IG31:                ;; offset=0x0268
       lea      rcx, bword ptr [rcx+0x10]
       call     CORINFO_HELP_ASSIGN_REF
       mov      rcx, gword ptr [rbp-0x190]
 
G_M000_IG32:                ;; offset=0x0278
       mov      r8, gword ptr [rcx+0x08]
       cmp      gword ptr [rbp-0x198], r8
       je       SHORT G_M000_IG34
 
G_M000_IG33:                ;; offset=0x0285
       mov      rdx, gword ptr [rbp-0x198]
       call     [System.Threading.ExecutionContext:RestoreChangedContextToThread(System.Threading.Thread,System.Threading.ExecutionContext,System.Threading.ExecutionContext)]
 
G_M000_IG34:                ;; offset=0x0292
       nop      
 
G_M000_IG35:                ;; offset=0x0293
       vzeroupper 
       add      rsp, 40
       ret      
 
; Total bytes of code 667

; Assembly listing for method Lokad.Lython.Runtime.LythonRuntime+CsvDictReaderObject:NextAsync(bool):System.Threading.Tasks.ValueTask`1[Lokad.Lython.Runtime.PyIterationResult]:this (Tier1)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; Tier1 code
; optimized code
; optimized using Synthesized PGO
; rbp based frame
; fully interruptible
; with Synthesized PGO: fgCalledCount is 100
; No PGO data
; 2 inlinees with PGO data; 4 single block inlinees; 2 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       push     rsi
       push     rbx
       sub      rsp, 416
       lea      rbp, [rsp+0x1B0]
       vxorps   xmm4, xmm4, xmm4
       vmovdqa  xmmword ptr [rbp-0x170], xmm4
       mov      rax, -336
 
G_M000_IG31:                ;; offset=0x0028
       vmovdqa  xmmword ptr [rbp+rax-0x10], xmm4
       vmovdqa  xmmword ptr [rax+rbp], xmm4
       vmovdqa  xmmword ptr [rbp+rax+0x10], xmm4
       add      rax, 48
       jne      SHORT G_M000_IG31
       mov      rbx, rdx
 
G_M000_IG02:                ;; offset=0x0042
       mov      gword ptr [rbp-0x110], rcx
       mov      byte  ptr [rbp-0xDC], r8b
       mov      dword ptr [rbp-0xE8], -1
       mov      rcx, qword ptr GS:[0x0058]
       mov      rcx, qword ptr [rcx+0x48]
       cmp      dword ptr [rcx+0x250], 5
       jle      G_M000_IG17
       mov      rcx, gword ptr [rcx+0x258]
       mov      rax, bword ptr [rcx+0x28]
       test     rax, rax
       je       G_M000_IG17
 
G_M000_IG03:                ;; offset=0x0088
       mov      rsi, gword ptr [rax+0x10]
       test     rsi, rsi
       jne      SHORT G_M000_IG05
 
G_M000_IG04:                ;; offset=0x0091
       call     [System.Threading.Thread:InitializeCurrentThread():System.Threading.Thread]
       mov      rsi, rax
 
G_M000_IG05:                ;; offset=0x009A
       mov      gword ptr [rbp-0x178], rsi
       mov      rdx, gword ptr [rsi+0x08]
       mov      gword ptr [rbp-0x180], rdx
       mov      rdx, gword ptr [rsi+0x10]
       mov      gword ptr [rbp-0x188], rdx
 
G_M000_IG06:                ;; offset=0x00B7
       lea      rcx, [rbp-0x110]
       call     [Lokad.Lython.Runtime.LythonRuntime+CsvDictReaderObject+<NextAsync>d__19:MoveNext():this]
       nop      
 
G_M000_IG07:                ;; offset=0x00C5
       mov      rdx, gword ptr [rbp-0x188]
       cmp      rdx, gword ptr [rsi+0x10]
       jne      G_M000_IG18
 
G_M000_IG08:                ;; offset=0x00D6
       mov      r8, gword ptr [rsi+0x08]
       cmp      gword ptr [rbp-0x180], r8
       jne      G_M000_IG19
 
G_M000_IG09:                ;; offset=0x00E7
       mov      rcx, gword ptr [rbp-0xD8]
       mov      rax, 0x19CE74022D0
       cmp      rcx, gword ptr [rax]
       jne      G_M000_IG20
 
G_M000_IG10:                ;; offset=0x0101
       vmovdqu  xmm0, xmmword ptr [rbp-0xD0]
       vmovdqu  xmmword ptr [rbp-0x160], xmm0
 
G_M000_IG11:                ;; offset=0x0111
       vmovdqu  ymm0, ymmword ptr [rbp-0x170]
       vmovdqu  ymmword ptr [rbp-0x130], ymm0
 
G_M000_IG12:                ;; offset=0x0121
       xor      rsi, rsi
 
G_M000_IG13:                ;; offset=0x0123
       mov      gword ptr [rbp-0x130], rsi
 
G_M000_IG14:                ;; offset=0x012A
       vmovdqu  ymm0, ymmword ptr [rbp-0x130]
       vmovdqu  ymmword ptr [rbx], ymm0
 
G_M000_IG15:                ;; offset=0x0136
       mov      word  ptr [rbx+0x08], 0
       mov      byte  ptr [rbx+0x0A], 1
       mov      rax, rbx
 
G_M000_IG16:                ;; offset=0x0143
       vzeroupper 
       add      rsp, 416
       pop      rbx
       pop      rsi
       pop      rbp
       ret      
 
G_M000_IG17:                ;; offset=0x0151
       mov      ecx, 5
       call     CORINFO_HELP_GETDYNAMIC_GCTHREADSTATIC_BASE_NOCTOR_OPTIMIZED
       jmp      G_M000_IG03
 
G_M000_IG18:                ;; offset=0x0160
       lea      rcx, bword ptr [rsi+0x10]
       call     CORINFO_HELP_ASSIGN_REF
       jmp      G_M000_IG08
 
G_M000_IG19:                ;; offset=0x016E
       mov      rcx, rsi
       mov      rdx, gword ptr [rbp-0x180]
       call     [System.Threading.ExecutionContext:RestoreChangedContextToThread(System.Threading.Thread,System.Threading.ExecutionContext,System.Threading.ExecutionContext)]
       jmp      G_M000_IG09
 
G_M000_IG20:                ;; offset=0x0183
       mov      rsi, gword ptr [rbp-0xD8]
       test     rsi, rsi
       jne      SHORT G_M000_IG21
       mov      rcx, 0x7FF9FD648D30
       call     CORINFO_HELP_NEWSFAST
       mov      rsi, rax
       mov      rcx, rsi
       call     [System.Threading.Tasks.Task:.ctor():this]
       mov      gword ptr [rbp-0xD8], rsi
 
G_M000_IG21:                ;; offset=0x01B1
       vxorps   xmm0, xmm0, xmm0
       vmovdqu  xmmword ptr [rbp-0x140], xmm0
 
G_M000_IG22:                ;; offset=0x01BD
       vmovdqu  ymm0, ymmword ptr [rbp-0x150]
       vmovdqu  ymmword ptr [rbp-0x130], ymm0
 
G_M000_IG23:                ;; offset=0x01CD
       jmp      G_M000_IG13
 
G_M000_IG24:                ;; offset=0x01D2
       sub      rsp, 40
 
G_M000_IG25:                ;; offset=0x01D6
       mov      rdx, gword ptr [rbp-0x188]
       mov      rcx, gword ptr [rbp-0x178]
       cmp      rdx, gword ptr [rcx+0x10]
       je       SHORT G_M000_IG27
 
G_M000_IG26:                ;; offset=0x01EA
       lea      rcx, bword ptr [rcx+0x10]
       call     CORINFO_HELP_ASSIGN_REF
       mov      rcx, gword ptr [rbp-0x178]
 
G_M000_IG27:                ;; offset=0x01FA
       mov      r8, gword ptr [rcx+0x08]
       cmp      gword ptr [rbp-0x180], r8
       je       SHORT G_M000_IG29
 
G_M000_IG28:                ;; offset=0x0207
       mov      rdx, gword ptr [rbp-0x180]
       call     [System.Threading.ExecutionContext:RestoreChangedContextToThread(System.Threading.Thread,System.Threading.ExecutionContext,System.Threading.ExecutionContext)]
 
G_M000_IG29:                ;; offset=0x0214
       nop      
 
G_M000_IG30:                ;; offset=0x0215
       vzeroupper 
       add      rsp, 40
       ret      
 
; Total bytes of code 541

