; Assembly listing for method Lokad.Lython.Runtime.LythonRuntime+CsvDictReaderObject:TryMoveNext():Lokad.Lython.Runtime.PyIterationResult:this (Tier0)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; Tier0 code
; rbp based frame
; partially interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 96
       lea      rbp, [rsp+0x60]
       vxorps   xmm4, xmm4, xmm4
       vmovdqu  ymmword ptr [rbp-0x40], ymm4
       vmovdqu  ymmword ptr [rbp-0x20], ymm4
       mov      gword ptr [rbp+0x10], rcx
       mov      qword ptr [rbp+0x18], rdx
 
G_M000_IG02:                ;; offset=0x0020
       lea      rdx, [rbp-0x20]
       mov      rcx, gword ptr [rbp+0x10]
       xor      r8d, r8d
       call     [Lokad.Lython.Runtime.LythonRuntime+CsvDictReaderObject:Next(bool):System.Threading.Tasks.ValueTask`1[Lokad.Lython.Runtime.PyIterationResult]:this]
       lea      rdx, [rbp-0x40]
       lea      rcx, [rbp-0x20]
       call     [System.Threading.Tasks.ValueTask`1[Lokad.Lython.Runtime.PyIterationResult]:GetAwaiter():System.Runtime.CompilerServices.ValueTaskAwaiter`1[Lokad.Lython.Runtime.PyIterationResult]:this]
       lea      rcx, [rbp-0x40]
       mov      rdx, qword ptr [rbp+0x18]
       call     [System.Runtime.CompilerServices.ValueTaskAwaiter`1[Lokad.Lython.Runtime.PyIterationResult]:GetResult():Lokad.Lython.Runtime.PyIterationResult:this]
       mov      rax, qword ptr [rbp+0x18]
 
G_M000_IG03:                ;; offset=0x0051
       add      rsp, 96
       pop      rbp
       ret      
 
; Total bytes of code 87

; Assembly listing for method Lokad.Lython.Runtime.LythonRuntime+CsvDictReaderObject:Next(bool):System.Threading.Tasks.ValueTask`1[Lokad.Lython.Runtime.PyIterationResult]:this (Tier0)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; Tier0 code
; rbp based frame
; partially interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 48
       lea      rbp, [rsp+0x30]
       xor      eax, eax
       mov      dword ptr [rbp-0x04], eax
       mov      qword ptr [rbp-0x10], rax
       mov      gword ptr [rbp+0x10], rcx
       mov      qword ptr [rbp+0x18], rdx
       mov      dword ptr [rbp+0x20], r8d
 
G_M000_IG02:                ;; offset=0x001F
       mov      rax, gword ptr [rbp+0x10]
       mov      rdx, gword ptr [rax+0x28]
       mov      rax, gword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax+0x20]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CheckExecution(Lokad.Lython.LythonSourceSpan):this]
       lea      rdx, [rbp-0x10]
       mov      rax, gword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, gword ptr [rbp+0x10]
       lea      rcx, bword ptr [rax+0x48]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:TryGetInteger(byref):bool:this]
       mov      dword ptr [rbp-0x04], eax
       cmp      dword ptr [rbp-0x04], 0
       je       SHORT G_M000_IG03
       cmp      qword ptr [rbp-0x10], 0
       jne      SHORT G_M000_IG05
 
G_M000_IG03:                ;; offset=0x005F
       movzx    r9, byte  ptr [rbp+0x20]
       mov      rcx, gword ptr [rbp+0x10]
       mov      rdx, qword ptr [rbp+0x18]
       mov      r8d, dword ptr [rbp-0x04]
       call     [Lokad.Lython.Runtime.LythonRuntime+CsvDictReaderObject:ReadAfterInitialHeaderAsync(bool,bool):System.Threading.Tasks.ValueTask`1[Lokad.Lython.Runtime.PyIterationResult]:this]
       mov      rax, qword ptr [rbp+0x18]
 
G_M000_IG04:                ;; offset=0x007A
       add      rsp, 48
       pop      rbp
       ret      
 
G_M000_IG05:                ;; offset=0x0080
       movzx    r8, byte  ptr [rbp+0x20]
       mov      rcx, gword ptr [rbp+0x10]
       mov      rdx, qword ptr [rbp+0x18]
       call     [Lokad.Lython.Runtime.LythonRuntime+CsvDictReaderObject:ReadDataRow(bool):System.Threading.Tasks.ValueTask`1[Lokad.Lython.Runtime.PyIterationResult]:this]
       mov      rax, qword ptr [rbp+0x18]
 
G_M000_IG06:                ;; offset=0x0097
       add      rsp, 48
       pop      rbp
       ret      
 
; Total bytes of code 157

; Assembly listing for method Lokad.Lython.Runtime.LythonRuntime+CsvDictReaderObject:ReadDataRow(bool):System.Threading.Tasks.ValueTask`1[Lokad.Lython.Runtime.PyIterationResult]:this (Tier0)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; Tier0 code
; rbp based frame
; partially interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 96
       lea      rbp, [rsp+0x60]
       xor      eax, eax
       mov      qword ptr [rbp-0x38], rax
       vxorps   xmm4, xmm4, xmm4
       vmovdqu  ymmword ptr [rbp-0x30], ymm4
       vmovdqa  xmmword ptr [rbp-0x10], xmm4
       mov      gword ptr [rbp+0x10], rcx
       mov      qword ptr [rbp+0x18], rdx
       mov      dword ptr [rbp+0x20], r8d
 
G_M000_IG02:                ;; offset=0x002A
       lea      rdx, [rbp-0x18]
       movzx    r8, byte  ptr [rbp+0x20]
       mov      rcx, gword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+CsvDictReaderObject:ReadRow(bool):System.Threading.Tasks.ValueTask`1[System.Object[]]:this]
       lea      rcx, [rbp-0x18]
       mov      rdx, 0x7FF9FD619828
       call     [System.Threading.Tasks.ValueTask`1[System.__Canon]:get_IsCompletedSuccessfully():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG06
 
G_M000_IG03:                ;; offset=0x0055
       vmovdqu  xmm0, xmmword ptr [rbp-0x18]
       vmovdqu  xmmword ptr [rbp-0x30], xmm0
       mov      rax, qword ptr [rbp-0x08]
       mov      qword ptr [rbp-0x20], rax
 
G_M000_IG04:                ;; offset=0x0067
       lea      r8, [rbp-0x30]
       movzx    r9, byte  ptr [rbp+0x20]
       mov      rdx, qword ptr [rbp+0x18]
       mov      rcx, gword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+CsvDictReaderObject:AwaitDataRowAsync(System.Threading.Tasks.ValueTask`1[System.Object[]],bool):System.Threading.Tasks.ValueTask`1[Lokad.Lython.Runtime.PyIterationResult]:this]
       mov      rax, qword ptr [rbp+0x18]
 
G_M000_IG05:                ;; offset=0x0082
       add      rsp, 96
       pop      rbp
       ret      
 
G_M000_IG06:                ;; offset=0x0088
       lea      rcx, [rbp-0x18]
       mov      rdx, 0x7FF9FD619828
       call     [System.Threading.Tasks.ValueTask`1[System.__Canon]:get_Result():System.__Canon:this]
       mov      gword ptr [rbp-0x38], rax
       mov      r8, gword ptr [rbp-0x38]
       movzx    r9, byte  ptr [rbp+0x20]
       mov      rdx, qword ptr [rbp+0x18]
       mov      rcx, gword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+CsvDictReaderObject:CompleteDataRow(System.Object[],bool):System.Threading.Tasks.ValueTask`1[Lokad.Lython.Runtime.PyIterationResult]:this]
       mov      rax, qword ptr [rbp+0x18]
 
G_M000_IG07:                ;; offset=0x00BB
       add      rsp, 96
       pop      rbp
       ret      
 
; Total bytes of code 193

; Assembly listing for method Lokad.Lython.Runtime.LythonRuntime+CsvDictReaderObject:BuildRecord(System.Object[],System.Object,bool):System.Threading.Tasks.ValueTask`1[Lokad.Lython.Runtime.PyIterationResult]:this (Instrumented Tier0)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; Instrumented Tier0 code
; rbp based frame
; fully interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 576
       lea      rbp, [rsp+0x240]
       xor      eax, eax
       mov      qword ptr [rbp-0x218], rax
       vxorps   xmm4, xmm4, xmm4
       vmovdqa  xmmword ptr [rbp-0x210], xmm4
       vmovdqa  xmmword ptr [rbp-0x200], xmm4
       mov      rax, -432
 
G_M000_IG49:                ;; offset=0x0037
       vmovdqa  xmmword ptr [rbp+rax-0x40], xmm4
       vmovdqa  xmmword ptr [rbp+rax-0x30], xmm4
       vmovdqa  xmmword ptr [rbp+rax-0x20], xmm4
       add      rax, 48
       jne      SHORT G_M000_IG49
       mov      qword ptr [rbp-0x40], rax
       mov      gword ptr [rbp+0x10], rcx
       mov      qword ptr [rbp+0x18], rdx
       mov      gword ptr [rbp+0x20], r8
       mov      gword ptr [rbp+0x28], r9
 
G_M000_IG02:                ;; offset=0x0063
       mov      dword ptr [rbp-0x1BC], 0x3E8
       mov      dword ptr [rbp-0x3C], 1
 
G_M000_IG03:                ;; offset=0x0074
       mov      rax, gword ptr [rbp+0x10]
       mov      rax, gword ptr [rax+0x40]
       mov      gword ptr [rbp-0x48], rax
       mov      rdx, gword ptr [rbp+0x28]
       mov      rcx, 0x7FF9FD56DEB0
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      gword ptr [rbp-0x50], rax
       cmp      gword ptr [rbp-0x50], 0
       je       G_M000_IG11
       cmp      gword ptr [rbp-0x48], 0
       jne      SHORT G_M000_IG04
       xor      rax, rax
       mov      gword ptr [rbp-0x188], rax
       jmp      SHORT G_M000_IG05
 
G_M000_IG04:                ;; offset=0x00B5
       mov      rcx, 0x7FF9FD6365F0
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, gword ptr [rbp+0x10]
       mov      rax, gword ptr [rax+0x28]
       mov      gword ptr [rsp+0x20], rax
       mov      rax, gword ptr [rbp+0x10]
       mov      r9, gword ptr [rax+0x20]
       mov      rcx, gword ptr [rbp-0x48]
       mov      rdx, gword ptr [rbp-0x50]
       mov      r8, gword ptr [rbp+0x20]
       call     [Lokad.Lython.Runtime.PyDict+RecordKeys:TryAdoptRecord(Lokad.Lython.Runtime.PyList,System.Object[],Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.PyDict:this]
       mov      gword ptr [rbp-0x188], rax
 
G_M000_IG05:                ;; offset=0x00F2
       mov      rax, gword ptr [rbp-0x188]
       mov      gword ptr [rbp-0x58], rax
       cmp      gword ptr [rbp-0x58], 0
       je       SHORT G_M000_IG10
       mov      rcx, 0x7FF9FD6365F4
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, gword ptr [rbp+0x10]
       lea      rcx, bword ptr [rax+0x40]
       mov      rdx, gword ptr [rbp-0x48]
       call     CORINFO_HELP_ASSIGN_REF
       xor      eax, eax
       mov      dword ptr [rbp-0x3C], eax
       lea      rcx, [rbp-0x1B8]
       mov      rdx, gword ptr [rbp-0x58]
       call     [Lokad.Lython.Runtime.PyIterationResult:Yield(System.Object):Lokad.Lython.Runtime.PyIterationResult]
 
G_M000_IG06:                ;; offset=0x013A
       vmovdqu  xmm0, xmmword ptr [rbp-0x1B8]
       vmovdqu  xmmword ptr [rbp-0x1D0], xmm0
 
G_M000_IG07:                ;; offset=0x014A
       lea      rdx, [rbp-0x1D0]
       lea      rcx, [rbp-0x1A8]
       call     [System.Threading.Tasks.ValueTask`1[Lokad.Lython.Runtime.PyIterationResult]:.ctor(Lokad.Lython.Runtime.PyIterationResult):this]
 
G_M000_IG08:                ;; offset=0x015E
       vmovdqu  ymm0, ymmword ptr [rbp-0x1A8]
       vmovdqu  ymmword ptr [rbp-0x80], ymm0
 
G_M000_IG09:                ;; offset=0x016B
       jmp      G_M000_IG36
 
G_M000_IG10:                ;; offset=0x0170
       mov      rcx, 0x7FF9FD6365F8
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG11:                ;; offset=0x017F
       mov      rdx, gword ptr [rbp+0x28]
       mov      rcx, 0x7FF9FD56DEB0
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      gword ptr [rbp-0x60], rax
       cmp      gword ptr [rbp-0x60], 0
       je       G_M000_IG33
       mov      rcx, gword ptr [rbp+0x10]
       mov      rdx, gword ptr [rbp-0x60]
       call     [Lokad.Lython.Runtime.LythonRuntime+CsvDictReaderObject:HasStringFieldNames(Lokad.Lython.Runtime.PyList):bool:this]
       test     eax, eax
       je       SHORT G_M000_IG12
       mov      rcx, gword ptr [rbp-0x60]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.PyList:get_Count():int:this]
       mov      dword ptr [rbp-0xD4], eax
       mov      rax, gword ptr [rbp+0x20]
       mov      eax, dword ptr [rax+0x08]
       mov      dword ptr [rbp-0xD8], eax
       mov      rcx, gword ptr [rbp-0x60]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.PyList:get_Count():int:this]
       cmp      eax, dword ptr [rbp-0xD8]
       setl     al
       movzx    rax, al
       add      eax, dword ptr [rbp-0xD4]
       jo       G_M000_IG31
       mov      dword ptr [rbp-0x84], eax
       mov      rax, gword ptr [rbp+0x10]
       mov      rax, gword ptr [rax+0x40]
       mov      gword ptr [rbp-0xE0], rax
       mov      rax, gword ptr [rbp-0xE0]
       mov      gword ptr [rbp-0xE8], rax
       cmp      gword ptr [rbp-0xE0], 0
       jne      SHORT G_M000_IG13
       xor      rax, rax
       mov      gword ptr [rbp-0xF0], rax
       jmp      SHORT G_M000_IG14
 
G_M000_IG12:                ;; offset=0x022F
       mov      rcx, 0x7FF9FD6365FC
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG33
 
G_M000_IG13:                ;; offset=0x0243
       mov      rcx, 0x7FF9FD636600
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, gword ptr [rbp+0x10]
       mov      rdx, gword ptr [rax+0x20]
       mov      rax, gword ptr [rbp+0x10]
       mov      r8, gword ptr [rax+0x28]
       mov      rcx, gword ptr [rbp-0xE8]
       mov      r9d, dword ptr [rbp-0x84]
       call     [Lokad.Lython.Runtime.PyDict+RecordKeys:CreateRecord(Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,int):Lokad.Lython.Runtime.PyDict:this]
       mov      gword ptr [rbp-0xF0], rax
 
G_M000_IG14:                ;; offset=0x027D
       mov      rax, gword ptr [rbp-0xF0]
       mov      gword ptr [rbp-0xF8], rax
       cmp      gword ptr [rbp-0xF0], 0
       jne      SHORT G_M000_IG15
       mov      rcx, 0x7FF9FD636604
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, 0x7FF9FD272430
       call     CORINFO_HELP_NEWSFAST
       mov      gword ptr [rbp-0x180], rax
       mov      rax, gword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax+0x20]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:get_MemoryGovernor():Lokad.Lython.Runtime.MemoryGovernor:this]
       mov      gword ptr [rbp-0x1D8], rax
       xor      eax, eax
       mov      dword ptr [rsp+0x20], eax
       mov      r8, gword ptr [rbp-0x1D8]
       mov      rax, gword ptr [rbp+0x10]
       mov      r9, gword ptr [rax+0x28]
       mov      edx, dword ptr [rbp-0x84]
       mov      rcx, gword ptr [rbp-0x180]
       call     [Lokad.Lython.Runtime.PyDict:.ctor(int,Lokad.Lython.Runtime.MemoryGovernor,Lokad.Lython.LythonSourceSpan,bool):this]
       mov      rax, gword ptr [rbp-0x180]
       mov      gword ptr [rbp-0xF8], rax
 
G_M000_IG15:                ;; offset=0x0307
       mov      rax, gword ptr [rbp-0xF8]
       mov      gword ptr [rbp-0x90], rax
       xor      eax, eax
       mov      dword ptr [rbp-0x94], eax
       jmp      G_M000_IG19
 
G_M000_IG16:                ;; offset=0x0322
       mov      rax, gword ptr [rbp+0x10]
       mov      rdx, gword ptr [rax+0x28]
       mov      rax, gword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax+0x20]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CheckExecution(Lokad.Lython.LythonSourceSpan):this]
       mov      rcx, gword ptr [rbp-0x60]
       mov      edx, dword ptr [rbp-0x94]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.PyList:get_Item(int):System.Object:this]
       mov      gword ptr [rbp-0x1E0], rax
       mov      rdx, gword ptr [rbp-0x1E0]
       mov      rcx, 0x7FF9FD2377F0
       call     [CORINFO_HELP_CHKCASTCLASS]
       mov      gword ptr [rbp-0x100], rax
       mov      rax, gword ptr [rbp-0x90]
       mov      gword ptr [rbp-0x108], rax
       mov      rax, gword ptr [rbp-0x100]
       mov      gword ptr [rbp-0x110], rax
       mov      rax, gword ptr [rbp+0x20]
       mov      eax, dword ptr [rax+0x08]
       cmp      eax, dword ptr [rbp-0x94]
       jg       SHORT G_M000_IG17
       mov      rax, gword ptr [rbp-0x108]
       mov      gword ptr [rbp-0x118], rax
       mov      rax, gword ptr [rbp-0x110]
       mov      gword ptr [rbp-0x120], rax
       mov      rax, gword ptr [rbp+0x10]
       mov      rax, gword ptr [rax+0x18]
       mov      gword ptr [rbp-0x128], rax
       jmp      SHORT G_M000_IG18
 
G_M000_IG17:                ;; offset=0x03C9
       mov      rcx, 0x7FF9FD636608
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, gword ptr [rbp-0x108]
       mov      gword ptr [rbp-0x118], rax
       mov      rax, gword ptr [rbp-0x110]
       mov      gword ptr [rbp-0x120], rax
       mov      rax, gword ptr [rbp+0x20]
       mov      ecx, dword ptr [rbp-0x94]
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG32
       mov      edx, ecx
       lea      rax, bword ptr [rax+8*rdx+0x10]
       mov      rax, gword ptr [rax]
       mov      gword ptr [rbp-0x128], rax
 
G_M000_IG18:                ;; offset=0x0418
       mov      rcx, 0x7FF9FD63660C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, gword ptr [rbp+0x10]
       mov      rax, gword ptr [rax+0x28]
       mov      gword ptr [rsp+0x20], rax
       mov      rax, gword ptr [rbp+0x10]
       mov      r9, gword ptr [rax+0x20]
       mov      rcx, gword ptr [rbp-0x118]
       mov      rdx, gword ptr [rbp-0x120]
       mov      r8, gword ptr [rbp-0x128]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.PyDict:SetRecordItem(Lokad.Lython.Runtime.Text.PyString,System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):this]
       mov      eax, dword ptr [rbp-0x94]
       inc      eax
       mov      dword ptr [rbp-0x94], eax
 
G_M000_IG19:                ;; offset=0x0467
       mov      eax, dword ptr [rbp-0x1BC]
       dec      eax
       mov      dword ptr [rbp-0x1BC], eax
       cmp      dword ptr [rbp-0x1BC], 0
       jg       SHORT G_M000_IG21
 
G_M000_IG20:                ;; offset=0x047E
       lea      rcx, [rbp-0x1BC]
       mov      edx, 269
       call     CORINFO_HELP_PATCHPOINT
       jmp      rax
 
G_M000_IG21:                ;; offset=0x0491
       mov      rcx, gword ptr [rbp-0x60]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.PyList:get_Count():int:this]
       cmp      eax, dword ptr [rbp-0x94]
       jg       G_M000_IG16
       mov      rax, gword ptr [rbp+0x20]
       mov      eax, dword ptr [rax+0x08]
       mov      dword ptr [rbp-0x12C], eax
       mov      rcx, gword ptr [rbp-0x60]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.PyList:get_Count():int:this]
       cmp      eax, dword ptr [rbp-0x12C]
       jge      G_M000_IG26
       mov      rax, gword ptr [rbp+0x10]
       mov      r8, gword ptr [rax+0x28]
       lea      rcx, [rbp-0xB0]
       mov      rax, gword ptr [rbp+0x10]
       mov      rdx, gword ptr [rax+0x20]
       call     [Lokad.Lython.Runtime.PyStructuralGuard:PushAmbient(Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.PyStructuralGuard+AmbientScope]
       nop      
 
G_M000_IG22:                ;; offset=0x04EC
       mov      rcx, 0x7FF9FD636610
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, gword ptr [rbp+0x10]
       mov      rdx, gword ptr [rax+0x28]
       mov      rax, gword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime:ValidateDictionaryKey(System.Object,Lokad.Lython.LythonSourceSpan):System.Object]
       mov      gword ptr [rbp-0x168], rax
       mov      rcx, gword ptr [rbp-0x60]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.PyList:get_Count():int:this]
       mov      dword ptr [rbp-0x1E4], eax
       mov      edx, dword ptr [rbp-0x1E4]
       lea      rcx, [rbp-0x178]
       call     [System.Numerics.BigInteger:.ctor(int):this]
 
G_M000_IG23:                ;; offset=0x053D
       vmovdqu  xmm0, xmmword ptr [rbp-0x178]
       vmovdqu  xmmword ptr [rbp-0x1F8], xmm0
 
G_M000_IG24:                ;; offset=0x054D
       lea      r8, [rbp-0x1F8]
       mov      rdx, gword ptr [rbp+0x20]
       mov      rcx, gword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+CsvDictReaderObject:RestFields(System.Object[],System.Numerics.BigInteger):Lokad.Lython.Runtime.PyList:this]
       mov      gword ptr [rbp-0x200], rax
       mov      r8, gword ptr [rbp-0x200]
       mov      rdx, gword ptr [rbp-0x168]
       mov      rcx, gword ptr [rbp-0x90]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.PyDict:SetItem(System.Object,System.Object):this]
       nop      
 
G_M000_IG25:                ;; offset=0x0587
       call     G_M000_IG42
       nop      
 
G_M000_IG26:                ;; offset=0x058D
       mov      rcx, 0x7FF9FD636618
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, gword ptr [rbp+0x10]
       mov      rdx, gword ptr [rax+0x20]
       mov      rax, gword ptr [rbp+0x10]
       mov      r8, gword ptr [rax+0x28]
       mov      rcx, gword ptr [rbp-0x90]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.PyDict:ShareRecordKeys(Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.PyDict+RecordKeys:this]
       mov      rdx, rax
       mov      rax, gword ptr [rbp+0x10]
       lea      rcx, bword ptr [rax+0x40]
       call     CORINFO_HELP_ASSIGN_REF
       lea      rcx, [rbp-0x160]
       mov      rdx, gword ptr [rbp-0x90]
       call     [Lokad.Lython.Runtime.PyIterationResult:Yield(System.Object):Lokad.Lython.Runtime.PyIterationResult]
 
G_M000_IG27:                ;; offset=0x05DF
       vmovdqu  xmm0, xmmword ptr [rbp-0x160]
       vmovdqu  xmmword ptr [rbp-0x210], xmm0
 
G_M000_IG28:                ;; offset=0x05EF
       lea      rdx, [rbp-0x210]
       lea      rcx, [rbp-0x150]
       call     [System.Threading.Tasks.ValueTask`1[Lokad.Lython.Runtime.PyIterationResult]:.ctor(Lokad.Lython.Runtime.PyIterationResult):this]
 
G_M000_IG29:                ;; offset=0x0603
       vmovdqu  ymm0, ymmword ptr [rbp-0x150]
       vmovdqu  ymmword ptr [rbp-0x80], ymm0
 
G_M000_IG30:                ;; offset=0x0610
       jmp      SHORT G_M000_IG37
 
G_M000_IG31:                ;; offset=0x0612
       call     CORINFO_HELP_OVERFLOW
       int3     
 
G_M000_IG32:                ;; offset=0x0618
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG33:                ;; offset=0x061E
       movzx    rax, byte  ptr [rbp+0x30]
       mov      dword ptr [rsp+0x20], eax
       lea      rdx, [rbp-0xD0]
       mov      rcx, gword ptr [rbp+0x10]
       mov      r8, gword ptr [rbp+0x20]
       mov      r9, gword ptr [rbp+0x28]
       call     [Lokad.Lython.Runtime.LythonRuntime+CsvDictReaderObject:BuildProtocolRecordAsync(System.Object[],System.Object,bool):System.Threading.Tasks.ValueTask`1[Lokad.Lython.Runtime.PyIterationResult]:this]
       xor      eax, eax
       mov      dword ptr [rbp-0x3C], eax
 
G_M000_IG34:                ;; offset=0x0644
       vmovdqu  ymm0, ymmword ptr [rbp-0xD0]
       vmovdqu  ymmword ptr [rbp-0x80], ymm0
 
G_M000_IG35:                ;; offset=0x0651
       call     G_M000_IG45
       jmp      SHORT G_M000_IG38
 
G_M000_IG36:                ;; offset=0x0658
       call     G_M000_IG45
       jmp      SHORT G_M000_IG38
 
G_M000_IG37:                ;; offset=0x065F
       call     G_M000_IG45
       nop      
 
G_M000_IG38:                ;; offset=0x0665
       mov      rcx, 0x7FF9FD636624
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, qword ptr [rbp+0x18]
 
G_M000_IG39:                ;; offset=0x0678
       vmovdqu  ymm0, ymmword ptr [rbp-0x80]
       vmovdqu  ymmword ptr [rax], ymm0
 
G_M000_IG40:                ;; offset=0x0681
       mov      rax, qword ptr [rbp+0x18]
 
G_M000_IG41:                ;; offset=0x0685
       vzeroupper 
       add      rsp, 576
       pop      rbp
       ret      
 
G_M000_IG42:                ;; offset=0x0691
       sub      rsp, 40
 
G_M000_IG43:                ;; offset=0x0695
       mov      rcx, 0x7FF9FD636614
       call     CORINFO_HELP_COUNTPROFILE32
       lea      rcx, [rbp-0xB0]
       call     [Lokad.Lython.Runtime.PyStructuralGuard+AmbientScope:Dispose():this]
       nop      
 
G_M000_IG44:                ;; offset=0x06B2
       vzeroupper 
       add      rsp, 40
       ret      
 
G_M000_IG45:                ;; offset=0x06BA
       sub      rsp, 40
 
G_M000_IG46:                ;; offset=0x06BE
       cmp      dword ptr [rbp-0x3C], 0
       je       SHORT G_M000_IG47
       mov      rcx, 0x7FF9FD63661C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, gword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+CsvDictReaderObject:get_Rows():Lokad.Lython.Runtime.LythonRuntime+CsvRecordSource:this]
       mov      gword ptr [rbp-0x218], rax
       mov      rcx, gword ptr [rbp-0x218]
       mov      rdx, gword ptr [rbp+0x20]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+CsvRecordSource:ReleaseRecord(System.Object[]):this]
 
G_M000_IG47:                ;; offset=0x06F7
       mov      rcx, 0x7FF9FD636620
       call     CORINFO_HELP_COUNTPROFILE32
       nop      
 
G_M000_IG48:                ;; offset=0x0707
       vzeroupper 
       add      rsp, 40
       ret      
 
; Total bytes of code 1807

; Assembly listing for method Lokad.Lython.Runtime.LythonRuntime+CsvDictReaderObject:TryMoveNext():Lokad.Lython.Runtime.PyIterationResult:this (Instrumented Tier0)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; Instrumented Tier0 code
; rbp based frame
; partially interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 96
       lea      rbp, [rsp+0x60]
       vxorps   xmm4, xmm4, xmm4
       vmovdqu  ymmword ptr [rbp-0x40], ymm4
       vmovdqu  ymmword ptr [rbp-0x20], ymm4
       mov      gword ptr [rbp+0x10], rcx
       mov      qword ptr [rbp+0x18], rdx
 
G_M000_IG02:                ;; offset=0x0020
       lea      rdx, [rbp-0x20]
       mov      rcx, gword ptr [rbp+0x10]
       xor      r8d, r8d
       call     [Lokad.Lython.Runtime.LythonRuntime+CsvDictReaderObject:Next(bool):System.Threading.Tasks.ValueTask`1[Lokad.Lython.Runtime.PyIterationResult]:this]
       lea      rdx, [rbp-0x40]
       lea      rcx, [rbp-0x20]
       call     [System.Threading.Tasks.ValueTask`1[Lokad.Lython.Runtime.PyIterationResult]:GetAwaiter():System.Runtime.CompilerServices.ValueTaskAwaiter`1[Lokad.Lython.Runtime.PyIterationResult]:this]
       lea      rcx, [rbp-0x40]
       mov      rdx, qword ptr [rbp+0x18]
       call     [System.Runtime.CompilerServices.ValueTaskAwaiter`1[Lokad.Lython.Runtime.PyIterationResult]:GetResult():Lokad.Lython.Runtime.PyIterationResult:this]
       mov      rax, qword ptr [rbp+0x18]
 
G_M000_IG03:                ;; offset=0x0051
       add      rsp, 96
       pop      rbp
       ret      
 
; Total bytes of code 87

; Assembly listing for method Lokad.Lython.Runtime.LythonRuntime+CsvDictReaderObject:Next(bool):System.Threading.Tasks.ValueTask`1[Lokad.Lython.Runtime.PyIterationResult]:this (Instrumented Tier0)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; Instrumented Tier0 code
; rbp based frame
; partially interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 48
       lea      rbp, [rsp+0x30]
       xor      eax, eax
       mov      dword ptr [rbp-0x04], eax
       mov      qword ptr [rbp-0x10], rax
       mov      gword ptr [rbp+0x10], rcx
       mov      qword ptr [rbp+0x18], rdx
       mov      dword ptr [rbp+0x20], r8d
 
G_M000_IG02:                ;; offset=0x001F
       mov      rax, gword ptr [rbp+0x10]
       mov      rdx, gword ptr [rax+0x28]
       mov      rax, gword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax+0x20]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CheckExecution(Lokad.Lython.LythonSourceSpan):this]
       lea      rdx, [rbp-0x10]
       mov      rax, gword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, gword ptr [rbp+0x10]
       lea      rcx, bword ptr [rax+0x48]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:TryGetInteger(byref):bool:this]
       mov      dword ptr [rbp-0x04], eax
       cmp      dword ptr [rbp-0x04], 0
       je       SHORT G_M000_IG04
       cmp      qword ptr [rbp-0x10], 0
       jne      SHORT G_M000_IG06
 
G_M000_IG03:                ;; offset=0x005F
       mov      rcx, 0x7FF9FD7FF5D8
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG04:                ;; offset=0x006E
       mov      rcx, 0x7FF9FD7FF5DC
       call     CORINFO_HELP_COUNTPROFILE32
       movzx    r9, byte  ptr [rbp+0x20]
       mov      rcx, gword ptr [rbp+0x10]
       mov      rdx, qword ptr [rbp+0x18]
       mov      r8d, dword ptr [rbp-0x04]
       call     [Lokad.Lython.Runtime.LythonRuntime+CsvDictReaderObject:ReadAfterInitialHeaderAsync(bool,bool):System.Threading.Tasks.ValueTask`1[Lokad.Lython.Runtime.PyIterationResult]:this]
       mov      rax, qword ptr [rbp+0x18]
 
G_M000_IG05:                ;; offset=0x0098
       add      rsp, 48
       pop      rbp
       ret      
 
G_M000_IG06:                ;; offset=0x009E
       mov      rcx, 0x7FF9FD7FF5E0
       call     CORINFO_HELP_COUNTPROFILE32
       movzx    r8, byte  ptr [rbp+0x20]
       mov      rcx, gword ptr [rbp+0x10]
       mov      rdx, qword ptr [rbp+0x18]
       call     [Lokad.Lython.Runtime.LythonRuntime+CsvDictReaderObject:ReadDataRow(bool):System.Threading.Tasks.ValueTask`1[Lokad.Lython.Runtime.PyIterationResult]:this]
       mov      rax, qword ptr [rbp+0x18]
 
G_M000_IG07:                ;; offset=0x00C4
       add      rsp, 48
       pop      rbp
       ret      
 
; Total bytes of code 202

; Assembly listing for method Lokad.Lython.Runtime.LythonRuntime+CsvDictReaderObject:ReadDataRow(bool):System.Threading.Tasks.ValueTask`1[Lokad.Lython.Runtime.PyIterationResult]:this (Instrumented Tier0)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; Instrumented Tier0 code
; rbp based frame
; partially interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 96
       lea      rbp, [rsp+0x60]
       xor      eax, eax
       mov      qword ptr [rbp-0x38], rax
       vxorps   xmm4, xmm4, xmm4
       vmovdqu  ymmword ptr [rbp-0x30], ymm4
       vmovdqa  xmmword ptr [rbp-0x10], xmm4
       mov      gword ptr [rbp+0x10], rcx
       mov      qword ptr [rbp+0x18], rdx
       mov      dword ptr [rbp+0x20], r8d
 
G_M000_IG02:                ;; offset=0x002A
       lea      rdx, [rbp-0x18]
       movzx    r8, byte  ptr [rbp+0x20]
       mov      rcx, gword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+CsvDictReaderObject:ReadRow(bool):System.Threading.Tasks.ValueTask`1[System.Object[]]:this]
       lea      rcx, [rbp-0x18]
       mov      rdx, 0x7FF9FD619828
       call     [System.Threading.Tasks.ValueTask`1[System.__Canon]:get_IsCompletedSuccessfully():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG06
       mov      rcx, 0x7FF9FD7FF618
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG03:                ;; offset=0x0064
       vmovdqu  xmm0, xmmword ptr [rbp-0x18]
       vmovdqu  xmmword ptr [rbp-0x30], xmm0
       mov      rax, qword ptr [rbp-0x08]
       mov      qword ptr [rbp-0x20], rax
 
G_M000_IG04:                ;; offset=0x0076
       lea      r8, [rbp-0x30]
       movzx    r9, byte  ptr [rbp+0x20]
       mov      rdx, qword ptr [rbp+0x18]
       mov      rcx, gword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+CsvDictReaderObject:AwaitDataRowAsync(System.Threading.Tasks.ValueTask`1[System.Object[]],bool):System.Threading.Tasks.ValueTask`1[Lokad.Lython.Runtime.PyIterationResult]:this]
       mov      rax, qword ptr [rbp+0x18]
 
G_M000_IG05:                ;; offset=0x0091
       add      rsp, 96
       pop      rbp
       ret      
 
G_M000_IG06:                ;; offset=0x0097
       mov      rcx, 0x7FF9FD7FF61C
       call     CORINFO_HELP_COUNTPROFILE32
       lea      rcx, [rbp-0x18]
       mov      rdx, 0x7FF9FD619828
       call     [System.Threading.Tasks.ValueTask`1[System.__Canon]:get_Result():System.__Canon:this]
       mov      gword ptr [rbp-0x38], rax
       mov      r8, gword ptr [rbp-0x38]
       movzx    r9, byte  ptr [rbp+0x20]
       mov      rdx, qword ptr [rbp+0x18]
       mov      rcx, gword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+CsvDictReaderObject:CompleteDataRow(System.Object[],bool):System.Threading.Tasks.ValueTask`1[Lokad.Lython.Runtime.PyIterationResult]:this]
       mov      rax, qword ptr [rbp+0x18]
 
G_M000_IG07:                ;; offset=0x00D9
       add      rsp, 96
       pop      rbp
       ret      
 
; Total bytes of code 223

; Assembly listing for method Lokad.Lython.Runtime.LythonRuntime+CsvDictReaderObject:BuildRecord(System.Object[],System.Object,bool):System.Threading.Tasks.ValueTask`1[Lokad.Lython.Runtime.PyIterationResult]:this (Instrumented Tier0)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; Instrumented Tier0 code
; rbp based frame
; fully interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 576
       lea      rbp, [rsp+0x240]
       xor      eax, eax
       mov      qword ptr [rbp-0x218], rax
       vxorps   xmm4, xmm4, xmm4
       vmovdqa  xmmword ptr [rbp-0x210], xmm4
       vmovdqa  xmmword ptr [rbp-0x200], xmm4
       mov      rax, -432
 
G_M000_IG49:                ;; offset=0x0037
       vmovdqa  xmmword ptr [rbp+rax-0x40], xmm4
       vmovdqa  xmmword ptr [rbp+rax-0x30], xmm4
       vmovdqa  xmmword ptr [rbp+rax-0x20], xmm4
       add      rax, 48
       jne      SHORT G_M000_IG49
       mov      qword ptr [rbp-0x40], rax
       mov      gword ptr [rbp+0x10], rcx
       mov      qword ptr [rbp+0x18], rdx
       mov      gword ptr [rbp+0x20], r8
       mov      gword ptr [rbp+0x28], r9
 
G_M000_IG02:                ;; offset=0x0063
       mov      dword ptr [rbp-0x1BC], 0x3E8
       mov      dword ptr [rbp-0x3C], 1
 
G_M000_IG03:                ;; offset=0x0074
       mov      rax, gword ptr [rbp+0x10]
       mov      rax, gword ptr [rax+0x40]
       mov      gword ptr [rbp-0x48], rax
       mov      rdx, gword ptr [rbp+0x28]
       mov      rcx, 0x7FF9FD56DEB0
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      gword ptr [rbp-0x50], rax
       cmp      gword ptr [rbp-0x50], 0
       je       G_M000_IG11
       cmp      gword ptr [rbp-0x48], 0
       jne      SHORT G_M000_IG04
       xor      rax, rax
       mov      gword ptr [rbp-0x188], rax
       jmp      SHORT G_M000_IG05
 
G_M000_IG04:                ;; offset=0x00B5
       mov      rcx, 0x7FF9FD6365F0
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, gword ptr [rbp+0x10]
       mov      rax, gword ptr [rax+0x28]
       mov      gword ptr [rsp+0x20], rax
       mov      rax, gword ptr [rbp+0x10]
       mov      r9, gword ptr [rax+0x20]
       mov      rcx, gword ptr [rbp-0x48]
       mov      rdx, gword ptr [rbp-0x50]
       mov      r8, gword ptr [rbp+0x20]
       call     [Lokad.Lython.Runtime.PyDict+RecordKeys:TryAdoptRecord(Lokad.Lython.Runtime.PyList,System.Object[],Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.PyDict:this]
       mov      gword ptr [rbp-0x188], rax
 
G_M000_IG05:                ;; offset=0x00F2
       mov      rax, gword ptr [rbp-0x188]
       mov      gword ptr [rbp-0x58], rax
       cmp      gword ptr [rbp-0x58], 0
       je       SHORT G_M000_IG10
       mov      rcx, 0x7FF9FD6365F4
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, gword ptr [rbp+0x10]
       lea      rcx, bword ptr [rax+0x40]
       mov      rdx, gword ptr [rbp-0x48]
       call     CORINFO_HELP_ASSIGN_REF
       xor      eax, eax
       mov      dword ptr [rbp-0x3C], eax
       lea      rcx, [rbp-0x1B8]
       mov      rdx, gword ptr [rbp-0x58]
       call     [Lokad.Lython.Runtime.PyIterationResult:Yield(System.Object):Lokad.Lython.Runtime.PyIterationResult]
 
G_M000_IG06:                ;; offset=0x013A
       vmovdqu  xmm0, xmmword ptr [rbp-0x1B8]
       vmovdqu  xmmword ptr [rbp-0x1D0], xmm0
 
G_M000_IG07:                ;; offset=0x014A
       lea      rdx, [rbp-0x1D0]
       lea      rcx, [rbp-0x1A8]
       call     [System.Threading.Tasks.ValueTask`1[Lokad.Lython.Runtime.PyIterationResult]:.ctor(Lokad.Lython.Runtime.PyIterationResult):this]
 
G_M000_IG08:                ;; offset=0x015E
       vmovdqu  ymm0, ymmword ptr [rbp-0x1A8]
       vmovdqu  ymmword ptr [rbp-0x80], ymm0
 
G_M000_IG09:                ;; offset=0x016B
       jmp      G_M000_IG36
 
G_M000_IG10:                ;; offset=0x0170
       mov      rcx, 0x7FF9FD6365F8
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG11:                ;; offset=0x017F
       mov      rdx, gword ptr [rbp+0x28]
       mov      rcx, 0x7FF9FD56DEB0
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      gword ptr [rbp-0x60], rax
       cmp      gword ptr [rbp-0x60], 0
       je       G_M000_IG33
       mov      rcx, gword ptr [rbp+0x10]
       mov      rdx, gword ptr [rbp-0x60]
       call     [Lokad.Lython.Runtime.LythonRuntime+CsvDictReaderObject:HasStringFieldNames(Lokad.Lython.Runtime.PyList):bool:this]
       test     eax, eax
       je       SHORT G_M000_IG12
       mov      rcx, gword ptr [rbp-0x60]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.PyList:get_Count():int:this]
       mov      dword ptr [rbp-0xD4], eax
       mov      rax, gword ptr [rbp+0x20]
       mov      eax, dword ptr [rax+0x08]
       mov      dword ptr [rbp-0xD8], eax
       mov      rcx, gword ptr [rbp-0x60]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.PyList:get_Count():int:this]
       cmp      eax, dword ptr [rbp-0xD8]
       setl     al
       movzx    rax, al
       add      eax, dword ptr [rbp-0xD4]
       jo       G_M000_IG31
       mov      dword ptr [rbp-0x84], eax
       mov      rax, gword ptr [rbp+0x10]
       mov      rax, gword ptr [rax+0x40]
       mov      gword ptr [rbp-0xE0], rax
       mov      rax, gword ptr [rbp-0xE0]
       mov      gword ptr [rbp-0xE8], rax
       cmp      gword ptr [rbp-0xE0], 0
       jne      SHORT G_M000_IG13
       xor      rax, rax
       mov      gword ptr [rbp-0xF0], rax
       jmp      SHORT G_M000_IG14
 
G_M000_IG12:                ;; offset=0x022F
       mov      rcx, 0x7FF9FD6365FC
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG33
 
G_M000_IG13:                ;; offset=0x0243
       mov      rcx, 0x7FF9FD636600
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, gword ptr [rbp+0x10]
       mov      rdx, gword ptr [rax+0x20]
       mov      rax, gword ptr [rbp+0x10]
       mov      r8, gword ptr [rax+0x28]
       mov      rcx, gword ptr [rbp-0xE8]
       mov      r9d, dword ptr [rbp-0x84]
       call     [Lokad.Lython.Runtime.PyDict+RecordKeys:CreateRecord(Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,int):Lokad.Lython.Runtime.PyDict:this]
       mov      gword ptr [rbp-0xF0], rax
 
G_M000_IG14:                ;; offset=0x027D
       mov      rax, gword ptr [rbp-0xF0]
       mov      gword ptr [rbp-0xF8], rax
       cmp      gword ptr [rbp-0xF0], 0
       jne      SHORT G_M000_IG15
       mov      rcx, 0x7FF9FD636604
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, 0x7FF9FD272430
       call     CORINFO_HELP_NEWSFAST
       mov      gword ptr [rbp-0x180], rax
       mov      rax, gword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax+0x20]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:get_MemoryGovernor():Lokad.Lython.Runtime.MemoryGovernor:this]
       mov      gword ptr [rbp-0x1D8], rax
       xor      eax, eax
       mov      dword ptr [rsp+0x20], eax
       mov      r8, gword ptr [rbp-0x1D8]
       mov      rax, gword ptr [rbp+0x10]
       mov      r9, gword ptr [rax+0x28]
       mov      edx, dword ptr [rbp-0x84]
       mov      rcx, gword ptr [rbp-0x180]
       call     [Lokad.Lython.Runtime.PyDict:.ctor(int,Lokad.Lython.Runtime.MemoryGovernor,Lokad.Lython.LythonSourceSpan,bool):this]
       mov      rax, gword ptr [rbp-0x180]
       mov      gword ptr [rbp-0xF8], rax
 
G_M000_IG15:                ;; offset=0x0307
       mov      rax, gword ptr [rbp-0xF8]
       mov      gword ptr [rbp-0x90], rax
       xor      eax, eax
       mov      dword ptr [rbp-0x94], eax
       jmp      G_M000_IG19
 
G_M000_IG16:                ;; offset=0x0322
       mov      rax, gword ptr [rbp+0x10]
       mov      rdx, gword ptr [rax+0x28]
       mov      rax, gword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax+0x20]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CheckExecution(Lokad.Lython.LythonSourceSpan):this]
       mov      rcx, gword ptr [rbp-0x60]
       mov      edx, dword ptr [rbp-0x94]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.PyList:get_Item(int):System.Object:this]
       mov      gword ptr [rbp-0x1E0], rax
       mov      rdx, gword ptr [rbp-0x1E0]
       mov      rcx, 0x7FF9FD2377F0
       call     [CORINFO_HELP_CHKCASTCLASS]
       mov      gword ptr [rbp-0x100], rax
       mov      rax, gword ptr [rbp-0x90]
       mov      gword ptr [rbp-0x108], rax
       mov      rax, gword ptr [rbp-0x100]
       mov      gword ptr [rbp-0x110], rax
       mov      rax, gword ptr [rbp+0x20]
       mov      eax, dword ptr [rax+0x08]
       cmp      eax, dword ptr [rbp-0x94]
       jg       SHORT G_M000_IG17
       mov      rax, gword ptr [rbp-0x108]
       mov      gword ptr [rbp-0x118], rax
       mov      rax, gword ptr [rbp-0x110]
       mov      gword ptr [rbp-0x120], rax
       mov      rax, gword ptr [rbp+0x10]
       mov      rax, gword ptr [rax+0x18]
       mov      gword ptr [rbp-0x128], rax
       jmp      SHORT G_M000_IG18
 
G_M000_IG17:                ;; offset=0x03C9
       mov      rcx, 0x7FF9FD636608
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, gword ptr [rbp-0x108]
       mov      gword ptr [rbp-0x118], rax
       mov      rax, gword ptr [rbp-0x110]
       mov      gword ptr [rbp-0x120], rax
       mov      rax, gword ptr [rbp+0x20]
       mov      ecx, dword ptr [rbp-0x94]
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG32
       mov      edx, ecx
       lea      rax, bword ptr [rax+8*rdx+0x10]
       mov      rax, gword ptr [rax]
       mov      gword ptr [rbp-0x128], rax
 
G_M000_IG18:                ;; offset=0x0418
       mov      rcx, 0x7FF9FD63660C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, gword ptr [rbp+0x10]
       mov      rax, gword ptr [rax+0x28]
       mov      gword ptr [rsp+0x20], rax
       mov      rax, gword ptr [rbp+0x10]
       mov      r9, gword ptr [rax+0x20]
       mov      rcx, gword ptr [rbp-0x118]
       mov      rdx, gword ptr [rbp-0x120]
       mov      r8, gword ptr [rbp-0x128]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.PyDict:SetRecordItem(Lokad.Lython.Runtime.Text.PyString,System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):this]
       mov      eax, dword ptr [rbp-0x94]
       inc      eax
       mov      dword ptr [rbp-0x94], eax
 
G_M000_IG19:                ;; offset=0x0467
       mov      eax, dword ptr [rbp-0x1BC]
       dec      eax
       mov      dword ptr [rbp-0x1BC], eax
       cmp      dword ptr [rbp-0x1BC], 0
       jg       SHORT G_M000_IG21
 
G_M000_IG20:                ;; offset=0x047E
       lea      rcx, [rbp-0x1BC]
       mov      edx, 269
       call     CORINFO_HELP_PATCHPOINT
       jmp      rax
 
G_M000_IG21:                ;; offset=0x0491
       mov      rcx, gword ptr [rbp-0x60]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.PyList:get_Count():int:this]
       cmp      eax, dword ptr [rbp-0x94]
       jg       G_M000_IG16
       mov      rax, gword ptr [rbp+0x20]
       mov      eax, dword ptr [rax+0x08]
       mov      dword ptr [rbp-0x12C], eax
       mov      rcx, gword ptr [rbp-0x60]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.PyList:get_Count():int:this]
       cmp      eax, dword ptr [rbp-0x12C]
       jge      G_M000_IG26
       mov      rax, gword ptr [rbp+0x10]
       mov      r8, gword ptr [rax+0x28]
       lea      rcx, [rbp-0xB0]
       mov      rax, gword ptr [rbp+0x10]
       mov      rdx, gword ptr [rax+0x20]
       call     [Lokad.Lython.Runtime.PyStructuralGuard:PushAmbient(Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.PyStructuralGuard+AmbientScope]
       nop      
 
G_M000_IG22:                ;; offset=0x04EC
       mov      rcx, 0x7FF9FD636610
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, gword ptr [rbp+0x10]
       mov      rdx, gword ptr [rax+0x28]
       mov      rax, gword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime:ValidateDictionaryKey(System.Object,Lokad.Lython.LythonSourceSpan):System.Object]
       mov      gword ptr [rbp-0x168], rax
       mov      rcx, gword ptr [rbp-0x60]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.PyList:get_Count():int:this]
       mov      dword ptr [rbp-0x1E4], eax
       mov      edx, dword ptr [rbp-0x1E4]
       lea      rcx, [rbp-0x178]
       call     [System.Numerics.BigInteger:.ctor(int):this]
 
G_M000_IG23:                ;; offset=0x053D
       vmovdqu  xmm0, xmmword ptr [rbp-0x178]
       vmovdqu  xmmword ptr [rbp-0x1F8], xmm0
 
G_M000_IG24:                ;; offset=0x054D
       lea      r8, [rbp-0x1F8]
       mov      rdx, gword ptr [rbp+0x20]
       mov      rcx, gword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+CsvDictReaderObject:RestFields(System.Object[],System.Numerics.BigInteger):Lokad.Lython.Runtime.PyList:this]
       mov      gword ptr [rbp-0x200], rax
       mov      r8, gword ptr [rbp-0x200]
       mov      rdx, gword ptr [rbp-0x168]
       mov      rcx, gword ptr [rbp-0x90]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.PyDict:SetItem(System.Object,System.Object):this]
       nop      
 
G_M000_IG25:                ;; offset=0x0587
       call     G_M000_IG42
       nop      
 
G_M000_IG26:                ;; offset=0x058D
       mov      rcx, 0x7FF9FD636618
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, gword ptr [rbp+0x10]
       mov      rdx, gword ptr [rax+0x20]
       mov      rax, gword ptr [rbp+0x10]
       mov      r8, gword ptr [rax+0x28]
       mov      rcx, gword ptr [rbp-0x90]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.PyDict:ShareRecordKeys(Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.PyDict+RecordKeys:this]
       mov      rdx, rax
       mov      rax, gword ptr [rbp+0x10]
       lea      rcx, bword ptr [rax+0x40]
       call     CORINFO_HELP_ASSIGN_REF
       lea      rcx, [rbp-0x160]
       mov      rdx, gword ptr [rbp-0x90]
       call     [Lokad.Lython.Runtime.PyIterationResult:Yield(System.Object):Lokad.Lython.Runtime.PyIterationResult]
 
G_M000_IG27:                ;; offset=0x05DF
       vmovdqu  xmm0, xmmword ptr [rbp-0x160]
       vmovdqu  xmmword ptr [rbp-0x210], xmm0
 
G_M000_IG28:                ;; offset=0x05EF
       lea      rdx, [rbp-0x210]
       lea      rcx, [rbp-0x150]
       call     [System.Threading.Tasks.ValueTask`1[Lokad.Lython.Runtime.PyIterationResult]:.ctor(Lokad.Lython.Runtime.PyIterationResult):this]
 
G_M000_IG29:                ;; offset=0x0603
       vmovdqu  ymm0, ymmword ptr [rbp-0x150]
       vmovdqu  ymmword ptr [rbp-0x80], ymm0
 
G_M000_IG30:                ;; offset=0x0610
       jmp      SHORT G_M000_IG37
 
G_M000_IG31:                ;; offset=0x0612
       call     CORINFO_HELP_OVERFLOW
       int3     
 
G_M000_IG32:                ;; offset=0x0618
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG33:                ;; offset=0x061E
       movzx    rax, byte  ptr [rbp+0x30]
       mov      dword ptr [rsp+0x20], eax
       lea      rdx, [rbp-0xD0]
       mov      rcx, gword ptr [rbp+0x10]
       mov      r8, gword ptr [rbp+0x20]
       mov      r9, gword ptr [rbp+0x28]
       call     [Lokad.Lython.Runtime.LythonRuntime+CsvDictReaderObject:BuildProtocolRecordAsync(System.Object[],System.Object,bool):System.Threading.Tasks.ValueTask`1[Lokad.Lython.Runtime.PyIterationResult]:this]
       xor      eax, eax
       mov      dword ptr [rbp-0x3C], eax
 
G_M000_IG34:                ;; offset=0x0644
       vmovdqu  ymm0, ymmword ptr [rbp-0xD0]
       vmovdqu  ymmword ptr [rbp-0x80], ymm0
 
G_M000_IG35:                ;; offset=0x0651
       call     G_M000_IG45
       jmp      SHORT G_M000_IG38
 
G_M000_IG36:                ;; offset=0x0658
       call     G_M000_IG45
       jmp      SHORT G_M000_IG38
 
G_M000_IG37:                ;; offset=0x065F
       call     G_M000_IG45
       nop      
 
G_M000_IG38:                ;; offset=0x0665
       mov      rcx, 0x7FF9FD636624
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, qword ptr [rbp+0x18]
 
G_M000_IG39:                ;; offset=0x0678
       vmovdqu  ymm0, ymmword ptr [rbp-0x80]
       vmovdqu  ymmword ptr [rax], ymm0
 
G_M000_IG40:                ;; offset=0x0681
       mov      rax, qword ptr [rbp+0x18]
 
G_M000_IG41:                ;; offset=0x0685
       vzeroupper 
       add      rsp, 576
       pop      rbp
       ret      
 
G_M000_IG42:                ;; offset=0x0691
       sub      rsp, 40
 
G_M000_IG43:                ;; offset=0x0695
       mov      rcx, 0x7FF9FD636614
       call     CORINFO_HELP_COUNTPROFILE32
       lea      rcx, [rbp-0xB0]
       call     [Lokad.Lython.Runtime.PyStructuralGuard+AmbientScope:Dispose():this]
       nop      
 
G_M000_IG44:                ;; offset=0x06B2
       vzeroupper 
       add      rsp, 40
       ret      
 
G_M000_IG45:                ;; offset=0x06BA
       sub      rsp, 40
 
G_M000_IG46:                ;; offset=0x06BE
       cmp      dword ptr [rbp-0x3C], 0
       je       SHORT G_M000_IG47
       mov      rcx, 0x7FF9FD63661C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, gword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+CsvDictReaderObject:get_Rows():Lokad.Lython.Runtime.LythonRuntime+CsvRecordSource:this]
       mov      gword ptr [rbp-0x218], rax
       mov      rcx, gword ptr [rbp-0x218]
       mov      rdx, gword ptr [rbp+0x20]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+CsvRecordSource:ReleaseRecord(System.Object[]):this]
 
G_M000_IG47:                ;; offset=0x06F7
       mov      rcx, 0x7FF9FD636620
       call     CORINFO_HELP_COUNTPROFILE32
       nop      
 
G_M000_IG48:                ;; offset=0x0707
       vzeroupper 
       add      rsp, 40
       ret      
 
; Total bytes of code 1807

; Assembly listing for method Lokad.Lython.Runtime.LythonRuntime+CsvDictReaderObject:TryMoveNext():Lokad.Lython.Runtime.PyIterationResult:this (Tier1)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; Tier1 code
; optimized code
; optimized using Synthesized PGO
; rsp based frame
; partially interruptible
; with Synthesized PGO: fgCalledCount is 100
; No PGO data
; 23 inlinees with PGO data; 29 single block inlinees; 0 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     r15
       push     r14
       push     r13
       push     r12
       push     rdi
       push     rsi
       push     rbp
       push     rbx
       sub      rsp, 168
       vxorps   xmm4, xmm4, xmm4
       vmovdqu  ymmword ptr [rsp+0x20], ymm4
       vmovdqu  ymmword ptr [rsp+0x40], ymm4
       vmovdqu  ymmword ptr [rsp+0x60], ymm4
       vmovdqu  ymmword ptr [rsp+0x80], ymm4
       xor      eax, eax
       mov      qword ptr [rsp+0xA0], rax
       mov      rbx, rcx
       mov      rsi, rdx
 
G_M000_IG02:                ;; offset=0x0042
       mov      rcx, gword ptr [rbx+0x20]
       mov      rdx, gword ptr [rbx+0x28]
       mov      rcx, gword ptr [rcx+0x98]
       mov      rax, gword ptr [rcx+0x88]
       cmp      gword ptr [rax+0x20], 0
       jne      G_M000_IG41
       mov      rax, gword ptr [rcx+0x180]
       test     rax, rax
       jne      G_M000_IG40
 
G_M000_IG03:                ;; offset=0x0073
       lea      rdi, bword ptr [rbx+0x48]
       mov      rdx, 0x1DA078020C0
       mov      rbp, gword ptr [rdx]
       cmp      gword ptr [rdi], rbp
       je       G_M000_IG39
 
G_M000_IG04:                ;; offset=0x008D
       cmp      qword ptr [rdi+0x08], 0
       jg       G_M000_IG21
 
G_M000_IG05:                ;; offset=0x0098
       mov      rcx, gword ptr [rdi]
       test     rcx, rcx
       jne      G_M000_IG24
 
G_M000_IG06:                ;; offset=0x00A4
       xor      eax, eax
       mov      qword ptr [rsp+0x80], rax
 
G_M000_IG07:                ;; offset=0x00AE
       test     eax, eax
       je       G_M000_IG45
       cmp      qword ptr [rsp+0x80], 0
       je       G_M000_IG45
 
G_M000_IG08:                ;; offset=0x00C5
       mov      rdi, gword ptr [rbx+0x30]
       mov      r14, gword ptr [rdi+0x08]
       cmp      gword ptr [r14+0x50], 0
       jne      SHORT G_M000_IG11
 
G_M000_IG09:                ;; offset=0x00D4
       cmp      byte  ptr [rdi+0x40], 0
       jne      G_M000_IG46
 
G_M000_IG10:                ;; offset=0x00DE
       mov      rcx, rdi
       call     [Lokad.Lython.Runtime.LythonRuntime+CsvRecordSource:Pull():this]
       mov      r14, gword ptr [rdi+0x08]
       cmp      gword ptr [r14+0x50], 0
       je       SHORT G_M000_IG09
 
G_M000_IG11:                ;; offset=0x00F2
       mov      rdi, gword ptr [r14+0x50]
       xor      rcx, rcx
       mov      gword ptr [r14+0x50], rcx
 
G_M000_IG12:                ;; offset=0x00FC
       test     rdi, rdi
       je       G_M000_IG47
 
G_M000_IG13:                ;; offset=0x0105
       lea      r14, bword ptr [rbx+0x48]
       mov      rcx, gword ptr [rbx+0x30]
       movsxd   r15, dword ptr [rcx+0x3C]
       mov      rcx, r14
       mov      rdx, rbp
       call     CORINFO_HELP_ASSIGN_REF
       mov      qword ptr [r14+0x08], r15
       cmp      dword ptr [rdi+0x08], 0
       je       G_M000_IG50
       lea      rdx, [rsp+0x60]
       mov      rcx, rbx
       mov      r8, rdi
       xor      r9d, r9d
       call     [Lokad.Lython.Runtime.LythonRuntime+CsvDictReaderObject:BuildRow(System.Object[],bool):System.Threading.Tasks.ValueTask`1[Lokad.Lython.Runtime.PyIterationResult]:this]
 
G_M000_IG14:                ;; offset=0x013E
       mov      rdi, gword ptr [rsp+0x60]
       movsx    rbp, word  ptr [rsp+0x68]
 
G_M000_IG15:                ;; offset=0x0149
       vmovdqu  ymm0, ymmword ptr [rsp+0x60]
       vmovdqu  ymmword ptr [rsp+0x88], ymm0
 
G_M000_IG16:                ;; offset=0x0158
       test     rdi, rdi
       jne      G_M000_IG51
 
G_M000_IG17:                ;; offset=0x0161
       vmovdqu  xmm0, xmmword ptr [rsp+0x98]
       vmovdqu  xmmword ptr [rsp+0x30], xmm0
 
G_M000_IG18:                ;; offset=0x0170
       vmovdqu  xmm0, xmmword ptr [rsp+0x30]
       vmovdqu  xmmword ptr [rsi], xmm0
 
G_M000_IG19:                ;; offset=0x017A
       mov      rax, rsi
 
G_M000_IG20:                ;; offset=0x017D
       vzeroupper 
       add      rsp, 168
       pop      rbx
       pop      rbp
       pop      rsi
       pop      rdi
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       ret      
 
G_M000_IG21:                ;; offset=0x0194
       mov      rdx, gword ptr [rdi]
       mov      rcx, rdx
       test     rcx, rcx
       je       SHORT G_M000_IG23
 
G_M000_IG22:                ;; offset=0x019F
       mov      rax, 0x7FF9FD453FD0
       cmp      qword ptr [rcx], rax
       jne      G_M000_IG42
 
G_M000_IG23:                ;; offset=0x01B2
       test     rcx, rcx
       je       G_M000_IG05
       mov      edx, dword ptr [rdi+0x08]
       dec      edx
       lea      r8, [rsp+0x80]
       call     [Lokad.Lython.Runtime.PyTuple:TryReadInteger(int,byref):bool:this]
       jmp      G_M000_IG07
 
G_M000_IG24:                ;; offset=0x01D3
       mov      r8, 0x7FF9FD1BDDB8
       cmp      qword ptr [rcx], r8
       jne      G_M000_IG06
 
G_M000_IG25:                ;; offset=0x01E6
       mov      rdi, gword ptr [rcx+0x08]
       mov      r14d, dword ptr [rcx+0x10]
       test     r14d, r14d
       je       G_M000_IG33
 
G_M000_IG26:                ;; offset=0x01F7
       test     rdi, rdi
       je       G_M000_IG36
 
G_M000_IG27:                ;; offset=0x0200
       cmp      r14d, -1
       je       G_M000_IG35
 
G_M000_IG28:                ;; offset=0x020A
       xor      r15d, r15d
       mov      r13d, dword ptr [rdi+0x08]
       lea      r12d, [r13-0x01]
       cmp      r12d, r13d
       jae      G_M000_IG55
       mov      ecx, r12d
       mov      rax, qword ptr [rdi+8*rcx+0x10]
       mov      rcx, rax
 
G_M000_IG29:                ;; offset=0x0229
       xor      edx, edx
       lzcnt    rdx, rcx
       shr      edx, 3
       mov      eax, edx
       neg      eax
       add      eax, 7
       xor      edx, edx
       test     eax, eax
       cmovg    edx, eax
 
G_M000_IG30:                ;; offset=0x0241
       lea      eax, [8*rdx]
       shrx     rcx, rcx, rax
       movzx    rcx, cl
       and      ecx, 128
       and      r15d, 128
       cmp      ecx, r15d
       setne    cl
       movzx    rcx, cl
       test     ecx, ecx
       setne    cl
       movzx    rcx, cl
       lea      ecx, [rdx+rcx+0x01]
       test     rdi, rdi
       je       SHORT G_M000_IG32
 
G_M000_IG31:                ;; offset=0x0277
       mov      r13d, dword ptr [rdi+0x08]
       sub      r13d, 1
       imul     eax, r13d, 8
       jo       G_M000_IG56
       add      ecx, eax
       jo       G_M000_IG56
 
G_M000_IG32:                ;; offset=0x0291
       cmp      ecx, 8
       jg       G_M000_IG43
 
G_M000_IG33:                ;; offset=0x029A
       mov      gword ptr [rsp+0x20], rdi
       mov      dword ptr [rsp+0x28], r14d
       lea      rcx, [rsp+0x20]
       call     [System.Numerics.BigInteger:op_Explicit(System.Numerics.BigInteger):long]
       mov      qword ptr [rsp+0x80], rax
       mov      ecx, 1
 
G_M000_IG34:                ;; offset=0x02BC
       mov      eax, ecx
       jmp      G_M000_IG07
 
G_M000_IG35:                ;; offset=0x02C3
       mov      r15d, 255
       lea      rcx, bword ptr [rdi+0x10]
       mov      r13d, dword ptr [rdi+0x08]
       mov      r8d, r13d
       xor      edx, edx
       call     [System.SpanHelpers:NonPackedIndexOfValueType[long,System.SpanHelpers+Negate`1[long]](byref,long,int):int]
       lea      r12d, [r13-0x01]
       cmp      r12d, r13d
       jae      G_M000_IG55
       mov      ecx, r12d
       mov      rcx, qword ptr [rdi+8*rcx+0x10]
       not      rcx
       lea      rdx, [rcx+0x01]
       cmp      r12d, eax
       cmove    rcx, rdx
       jmp      SHORT G_M000_IG37
 
G_M000_IG36:                ;; offset=0x0301
       mov      r15d, 255
       xor      ecx, ecx
       test     r14d, r14d
       cmovge   r15d, ecx
       movsxd   rcx, r14d
 
G_M000_IG37:                ;; offset=0x0313
       test     r15d, r15d
       je       G_M000_IG29
 
G_M000_IG38:                ;; offset=0x031C
       mov      rax, rcx
       not      rax
       lzcnt    rax, rax
       shr      eax, 3
       neg      eax
       add      eax, 7
       xor      edx, edx
       test     eax, eax
       cmovg    edx, eax
       jmp      G_M000_IG30
 
G_M000_IG39:                ;; offset=0x033B
       mov      rax, qword ptr [rdi+0x08]
       mov      qword ptr [rsp+0x80], rax
       mov      eax, 1
       jmp      G_M000_IG07
 
G_M000_IG40:                ;; offset=0x0351
       cmp      dword ptr [rax+0x20], 0
       setne    al
       movzx    rax, al
       test     eax, eax
       je       G_M000_IG03
 
G_M000_IG41:                ;; offset=0x0363
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
       jmp      G_M000_IG03
 
G_M000_IG42:                ;; offset=0x036E
       mov      rcx, rax
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       mov      rcx, rax
       jmp      G_M000_IG23
 
G_M000_IG43:                ;; offset=0x037E
       xor      ecx, ecx
       mov      qword ptr [rsp+0x80], rcx
 
G_M000_IG44:                ;; offset=0x0388
       jmp      G_M000_IG34
 
G_M000_IG45:                ;; offset=0x038D
       lea      rdx, [rsp+0x88]
       mov      rcx, rbx
       mov      r8d, eax
       xor      r9d, r9d
       call     [Lokad.Lython.Runtime.LythonRuntime+CsvDictReaderObject:ReadAfterInitialHeaderAsync(bool,bool):System.Threading.Tasks.ValueTask`1[Lokad.Lython.Runtime.PyIterationResult]:this]
       mov      rdi, gword ptr [rsp+0x88]
       movsx    rbp, word  ptr [rsp+0x90]
       jmp      G_M000_IG16
 
G_M000_IG46:                ;; offset=0x03BA
       xor      rdi, rdi
       jmp      G_M000_IG12
 
G_M000_IG47:                ;; offset=0x03C1
       vxorps   xmm0, xmm0, xmm0
       vmovdqu  xmmword ptr [rsp+0x50], xmm0
 
G_M000_IG48:                ;; offset=0x03CB
       vmovdqu  ymm0, ymmword ptr [rsp+0x40]
       vmovdqu  ymmword ptr [rsp+0x60], ymm0
 
G_M000_IG49:                ;; offset=0x03D7
       mov      byte  ptr [rsp+0x6A], 1
       jmp      G_M000_IG14
 
G_M000_IG50:                ;; offset=0x03E1
       mov      rcx, gword ptr [rbx+0x30]
       mov      rdx, rdi
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+CsvRecordSource:ReleaseRecord(System.Object[]):this]
       lea      rdx, [rsp+0x60]
       mov      rcx, rbx
       xor      r8d, r8d
       call     [Lokad.Lython.Runtime.LythonRuntime+CsvDictReaderObject:SkipBlankRowsAsync(bool):System.Threading.Tasks.ValueTask`1[Lokad.Lython.Runtime.PyIterationResult]:this]
       jmp      G_M000_IG14
 
G_M000_IG51:                ;; offset=0x0406
       mov      rdx, rdi
       mov      rcx, 0x7FF9FD637D50
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       mov      rbx, rax
       test     rbx, rbx
       je       SHORT G_M000_IG54
       mov      ecx, dword ptr [rbx+0x34]
       and      ecx, 0x11000000
       cmp      ecx, 0x1000000
       je       SHORT G_M000_IG52
       mov      rcx, rbx
       xor      edx, edx
       call     [System.Runtime.CompilerServices.TaskAwaiter:HandleNonSuccessAndDebuggerNotification(System.Threading.Tasks.Task,int)]
 
G_M000_IG52:                ;; offset=0x043C
       vmovdqu  xmm0, xmmword ptr [rbx+0x38]
       vmovdqu  xmmword ptr [rsp+0x30], xmm0
 
G_M000_IG53:                ;; offset=0x0447
       jmp      G_M000_IG18
 
G_M000_IG54:                ;; offset=0x044C
       lea      rdx, [rsp+0x30]
       mov      rcx, rdi
       mov      r8d, ebp
       mov      r11, 0x7FF9FCD129C0
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[Lokad.Lython.Runtime.PyIterationResult]:GetResult(short):Lokad.Lython.Runtime.PyIterationResult:this
       jmp      G_M000_IG18
 
G_M000_IG55:                ;; offset=0x0469
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG56:                ;; offset=0x046F
       call     CORINFO_HELP_OVERFLOW
       int3     
 
; Total bytes of code 1141

; Assembly listing for method Lokad.Lython.Runtime.LythonRuntime+CsvDictReaderObject:Next(bool):System.Threading.Tasks.ValueTask`1[Lokad.Lython.Runtime.PyIterationResult]:this (Tier1)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; Tier1 code
; optimized code
; optimized using Synthesized PGO
; rsp based frame
; partially interruptible
; with Synthesized PGO: fgCalledCount is 87686
; 20 inlinees with PGO data; 25 single block inlinees; 0 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     r15
       push     r14
       push     r13
       push     r12
       push     rdi
       push     rsi
       push     rbp
       push     rbx
       sub      rsp, 200
       vxorps   xmm4, xmm4, xmm4
       vmovdqu  ymmword ptr [rsp+0x20], ymm4
       vmovdqu  ymmword ptr [rsp+0x40], ymm4
       vmovdqu  ymmword ptr [rsp+0x60], ymm4
       vmovdqu  ymmword ptr [rsp+0x80], ymm4
       vmovdqu  ymmword ptr [rsp+0xA0], ymm4
       xor      eax, eax
       mov      qword ptr [rsp+0xC0], rax
       mov      rbx, rcx
       mov      rsi, rdx
       mov      edi, r8d
 
G_M000_IG02:                ;; offset=0x004E
       mov      rcx, gword ptr [rbx+0x20]
       mov      rdx, gword ptr [rbx+0x28]
       mov      rcx, gword ptr [rcx+0x98]
       mov      rax, gword ptr [rcx+0x88]
       cmp      gword ptr [rax+0x20], 0
       jne      G_M000_IG40
       mov      rax, gword ptr [rcx+0x180]
       test     rax, rax
       jne      G_M000_IG39
 
G_M000_IG03:                ;; offset=0x007F
       lea      rbp, bword ptr [rbx+0x48]
       mov      rdx, 0x1DA078020C0
       mov      r14, gword ptr [rdx]
       cmp      gword ptr [rbp], r14
       je       G_M000_IG38
 
G_M000_IG04:                ;; offset=0x009A
       cmp      qword ptr [rbp+0x08], 0
       jg       G_M000_IG20
 
G_M000_IG05:                ;; offset=0x00A5
       mov      rcx, gword ptr [rbp]
       test     rcx, rcx
       jne      G_M000_IG23
 
G_M000_IG06:                ;; offset=0x00B2
       xor      eax, eax
       mov      qword ptr [rsp+0xC0], rax
 
G_M000_IG07:                ;; offset=0x00BC
       test     eax, eax
       je       G_M000_IG44
       cmp      qword ptr [rsp+0xC0], 0
       je       G_M000_IG44
 
G_M000_IG08:                ;; offset=0x00D3
       test     dil, dil
       jne      G_M000_IG46
       mov      rbp, gword ptr [rbx+0x30]
       mov      r15, gword ptr [rbp+0x08]
       cmp      gword ptr [r15+0x50], 0
       jne      SHORT G_M000_IG11
 
G_M000_IG09:                ;; offset=0x00EB
       cmp      byte  ptr [rbp+0x40], 0
       jne      G_M000_IG45
 
G_M000_IG10:                ;; offset=0x00F5
       mov      rcx, rbp
       call     [Lokad.Lython.Runtime.LythonRuntime+CsvRecordSource:Pull():this]
       mov      r15, gword ptr [rbp+0x08]
       cmp      gword ptr [r15+0x50], 0
       je       SHORT G_M000_IG09
 
G_M000_IG11:                ;; offset=0x0109
       mov      rbp, gword ptr [r15+0x50]
       xor      rcx, rcx
       mov      gword ptr [r15+0x50], rcx
 
G_M000_IG12:                ;; offset=0x0113
       xor      r15, r15
       xor      r13d, r13d
       mov      r12d, 1
 
G_M000_IG13:                ;; offset=0x011F
       test     r15, r15
       jne      G_M000_IG47
 
G_M000_IG14:                ;; offset=0x0128
       test     rbp, rbp
       je       G_M000_IG53
 
G_M000_IG15:                ;; offset=0x0131
       lea      r15, bword ptr [rbx+0x48]
       mov      rcx, gword ptr [rbx+0x30]
       movsxd   r13, dword ptr [rcx+0x3C]
       mov      rcx, r15
       mov      rdx, r14
       call     CORINFO_HELP_ASSIGN_REF
       mov      qword ptr [r15+0x08], r13
       cmp      dword ptr [rbp+0x08], 0
       je       G_M000_IG56
       movzx    r9, dil
       lea      rdx, [rsp+0x68]
       mov      rcx, rbx
       mov      r8, rbp
       call     [Lokad.Lython.Runtime.LythonRuntime+CsvDictReaderObject:BuildRow(System.Object[],bool):System.Threading.Tasks.ValueTask`1[Lokad.Lython.Runtime.PyIterationResult]:this]
 
G_M000_IG16:                ;; offset=0x016B
       vmovdqu  ymm0, ymmword ptr [rsp+0x68]
       vmovdqu  ymmword ptr [rsp+0xA0], ymm0
 
G_M000_IG17:                ;; offset=0x017A
       vmovdqu  ymm0, ymmword ptr [rsp+0xA0]
       vmovdqu  ymmword ptr [rsi], ymm0
 
G_M000_IG18:                ;; offset=0x0187
       mov      rax, rsi
 
G_M000_IG19:                ;; offset=0x018A
       vzeroupper 
       add      rsp, 200
       pop      rbx
       pop      rbp
       pop      rsi
       pop      rdi
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       ret      
 
G_M000_IG20:                ;; offset=0x01A1
       mov      rdx, gword ptr [rbp]
       mov      rcx, rdx
       test     rcx, rcx
       je       SHORT G_M000_IG22
 
G_M000_IG21:                ;; offset=0x01AD
       mov      rax, 0x7FF9FD453FD0
       cmp      qword ptr [rcx], rax
       jne      G_M000_IG41
 
G_M000_IG22:                ;; offset=0x01C0
       test     rcx, rcx
       je       G_M000_IG05
       mov      edx, dword ptr [rbp+0x08]
       dec      edx
       lea      r8, [rsp+0xC0]
       call     [Lokad.Lython.Runtime.PyTuple:TryReadInteger(int,byref):bool:this]
       jmp      G_M000_IG07
 
G_M000_IG23:                ;; offset=0x01E1
       mov      r8, 0x7FF9FD1BDDB8
       cmp      qword ptr [rcx], r8
       jne      G_M000_IG06
 
G_M000_IG24:                ;; offset=0x01F4
       mov      rbp, gword ptr [rcx+0x08]
       mov      r15d, dword ptr [rcx+0x10]
       test     r15d, r15d
       je       G_M000_IG32
 
G_M000_IG25:                ;; offset=0x0205
       test     rbp, rbp
       je       G_M000_IG35
 
G_M000_IG26:                ;; offset=0x020E
       cmp      r15d, -1
       je       G_M000_IG34
 
G_M000_IG27:                ;; offset=0x0218
       xor      r13d, r13d
       mov      r12d, dword ptr [rbp+0x08]
       lea      eax, [r12-0x01]
       cmp      eax, r12d
       jae      G_M000_IG57
       mov      ecx, eax
       mov      r10, qword ptr [rbp+8*rcx+0x10]
 
G_M000_IG28:                ;; offset=0x0234
       xor      eax, eax
       lzcnt    rax, r10
       shr      eax, 3
       mov      ecx, eax
       neg      ecx
       add      ecx, 7
       xor      eax, eax
       test     ecx, ecx
       cmovg    eax, ecx
 
G_M000_IG29:                ;; offset=0x024C
       lea      ecx, [8*rax]
       shrx     rcx, r10, rcx
       movzx    rcx, cl
       and      ecx, 128
       and      r13d, 128
       cmp      ecx, r13d
       setne    cl
       movzx    rcx, cl
       test     ecx, ecx
       setne    cl
       movzx    rcx, cl
       lea      ecx, [rax+rcx+0x01]
       test     rbp, rbp
       je       SHORT G_M000_IG31
 
G_M000_IG30:                ;; offset=0x0282
       mov      r12d, dword ptr [rbp+0x08]
       sub      r12d, 1
       imul     eax, r12d, 8
       jo       G_M000_IG58
       add      ecx, eax
       jo       G_M000_IG58
 
G_M000_IG31:                ;; offset=0x029C
       cmp      ecx, 8
       jg       G_M000_IG42
 
G_M000_IG32:                ;; offset=0x02A5
       mov      gword ptr [rsp+0x38], rbp
       mov      dword ptr [rsp+0x40], r15d
       lea      rcx, [rsp+0x38]
       call     [System.Numerics.BigInteger:op_Explicit(System.Numerics.BigInteger):long]
       mov      qword ptr [rsp+0xC0], rax
       mov      ecx, 1
 
G_M000_IG33:                ;; offset=0x02C7
       mov      eax, ecx
       jmp      G_M000_IG07
 
G_M000_IG34:                ;; offset=0x02CE
       mov      r13d, 255
       lea      rcx, bword ptr [rbp+0x10]
       mov      r12d, dword ptr [rbp+0x08]
       mov      r8d, r12d
       xor      edx, edx
       call     [System.SpanHelpers:NonPackedIndexOfValueType[long,System.SpanHelpers+Negate`1[long]](byref,long,int):int]
       lea      ecx, [r12-0x01]
       cmp      ecx, r12d
       jae      G_M000_IG57
       mov      edx, ecx
       mov      rdx, qword ptr [rbp+8*rdx+0x10]
       mov      r10, rdx
       not      r10
       lea      rdx, [r10+0x01]
       cmp      ecx, eax
       cmove    r10, rdx
       jmp      SHORT G_M000_IG36
 
G_M000_IG35:                ;; offset=0x030E
       mov      r13d, 255
       xor      r10d, r10d
       test     r15d, r15d
       cmovge   r13d, r10d
       movsxd   r10, r15d
 
G_M000_IG36:                ;; offset=0x0321
       test     r13d, r13d
       je       G_M000_IG28
 
G_M000_IG37:                ;; offset=0x032A
       mov      rcx, r10
       not      rcx
       lzcnt    rcx, rcx
       shr      ecx, 3
       neg      ecx
       add      ecx, 7
       xor      eax, eax
       test     ecx, ecx
       cmovg    eax, ecx
       jmp      G_M000_IG29
 
G_M000_IG38:                ;; offset=0x0349
       mov      rax, qword ptr [rbp+0x08]
       mov      qword ptr [rsp+0xC0], rax
       mov      eax, 1
       jmp      G_M000_IG07
 
G_M000_IG39:                ;; offset=0x035F
       cmp      dword ptr [rax+0x20], 0
       setne    al
       movzx    rax, al
       test     eax, eax
       je       G_M000_IG03
 
G_M000_IG40:                ;; offset=0x0371
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
       jmp      G_M000_IG03
 
G_M000_IG41:                ;; offset=0x037C
       mov      rcx, rax
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       mov      rcx, rax
       jmp      G_M000_IG22
 
G_M000_IG42:                ;; offset=0x038C
       xor      ecx, ecx
       mov      qword ptr [rsp+0xC0], rcx
 
G_M000_IG43:                ;; offset=0x0396
       jmp      G_M000_IG33
 
G_M000_IG44:                ;; offset=0x039B
       movzx    r9, dil
       mov      rcx, rbx
       mov      rdx, rsi
       mov      r8d, eax
       call     [Lokad.Lython.Runtime.LythonRuntime+CsvDictReaderObject:ReadAfterInitialHeaderAsync(bool,bool):System.Threading.Tasks.ValueTask`1[Lokad.Lython.Runtime.PyIterationResult]:this]
       jmp      G_M000_IG18
 
G_M000_IG45:                ;; offset=0x03B3
       xor      rbp, rbp
       jmp      G_M000_IG12
 
G_M000_IG46:                ;; offset=0x03BA
       mov      rcx, gword ptr [rbx+0x30]
       lea      rdx, [rsp+0x88]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+CsvRecordSource:TryMoveNextAsync():System.Threading.Tasks.ValueTask`1[System.Object[]]:this]
       mov      r15, gword ptr [rsp+0x88]
       mov      rbp, gword ptr [rsp+0x90]
       movsx    r13, word  ptr [rsp+0x98]
       movzx    r12, byte  ptr [rsp+0x9A]
       jmp      G_M000_IG13
 
G_M000_IG47:                ;; offset=0x03F5
       mov      rdx, r15
       mov      rcx, 0x7FF9FD83C3C8
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG48
       mov      rcx, rax
       call     [System.Threading.Tasks.Task:get_IsCompletedSuccessfully():bool:this]
       jmp      SHORT G_M000_IG49
 
G_M000_IG48:                ;; offset=0x0417
       mov      rcx, r15
       mov      edx, r13d
       mov      r11, 0x7FF9FCD129C8
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[System.__Canon]:GetStatus(short):int:this
       cmp      eax, 1
       sete     al
       movzx    rax, al
 
G_M000_IG49:                ;; offset=0x0433
       test     eax, eax
       jne      SHORT G_M000_IG50
       mov      gword ptr [rsp+0x20], r15
       mov      gword ptr [rsp+0x28], rbp
       mov      word  ptr [rsp+0x30], r13w
       mov      byte  ptr [rsp+0x32], r12b
       lea      r8, [rsp+0x20]
       movzx    r9, dil
       lea      rdx, [rsp+0xA0]
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+CsvDictReaderObject:AwaitDataRowAsync(System.Threading.Tasks.ValueTask`1[System.Object[]],bool):System.Threading.Tasks.ValueTask`1[Lokad.Lython.Runtime.PyIterationResult]:this]
       jmp      G_M000_IG17
 
G_M000_IG50:                ;; offset=0x046B
       mov      rdx, r15
       mov      rcx, 0x7FF9FD83C3C8
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       mov      rbp, rax
       test     rbp, rbp
       je       SHORT G_M000_IG52
       mov      ecx, dword ptr [rbp+0x34]
       and      ecx, 0x11000000
       cmp      ecx, 0x1000000
       je       SHORT G_M000_IG51
       mov      rcx, rbp
       xor      edx, edx
       call     [System.Runtime.CompilerServices.TaskAwaiter:HandleNonSuccessAndDebuggerNotification(System.Threading.Tasks.Task,int)]
 
G_M000_IG51:                ;; offset=0x04A1
       mov      rbp, gword ptr [rbp+0x38]
       jmp      G_M000_IG14
 
G_M000_IG52:                ;; offset=0x04AA
       mov      rcx, r15
       mov      edx, r13d
       mov      r11, 0x7FF9FCD129D0
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[System.__Canon]:GetResult(short):System.__Canon:this
       mov      rbp, rax
       jmp      G_M000_IG14
 
G_M000_IG53:                ;; offset=0x04C5
       vxorps   xmm0, xmm0, xmm0
       vmovdqu  xmmword ptr [rsp+0x58], xmm0
 
G_M000_IG54:                ;; offset=0x04CF
       vmovdqu  ymm0, ymmword ptr [rsp+0x48]
       vmovdqu  ymmword ptr [rsp+0x68], ymm0
 
G_M000_IG55:                ;; offset=0x04DB
       mov      byte  ptr [rsp+0x72], 1
       jmp      G_M000_IG16
 
G_M000_IG56:                ;; offset=0x04E5
       mov      rcx, gword ptr [rbx+0x30]
       mov      rdx, rbp
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+CsvRecordSource:ReleaseRecord(System.Object[]):this]
       movzx    r8, dil
       lea      rdx, [rsp+0x68]
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+CsvDictReaderObject:SkipBlankRowsAsync(bool):System.Threading.Tasks.ValueTask`1[Lokad.Lython.Runtime.PyIterationResult]:this]
       jmp      G_M000_IG16
 
G_M000_IG57:                ;; offset=0x050B
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG58:                ;; offset=0x0511
       call     CORINFO_HELP_OVERFLOW
       int3     
 
; Total bytes of code 1303

; Assembly listing for method Lokad.Lython.Runtime.LythonRuntime+CsvDictReaderObject:ReadDataRow(bool):System.Threading.Tasks.ValueTask`1[Lokad.Lython.Runtime.PyIterationResult]:this (Tier1)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; Tier1 code
; optimized code
; optimized using Synthesized PGO
; rsp based frame
; partially interruptible
; with Synthesized PGO: fgCalledCount is 89504
; 7 inlinees with PGO data; 11 single block inlinees; 0 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     r15
       push     r14
       push     r13
       push     rdi
       push     rsi
       push     rbp
       push     rbx
       sub      rsp, 144
       vxorps   xmm4, xmm4, xmm4
       vmovdqu  ymmword ptr [rsp+0x20], ymm4
       vmovdqu  ymmword ptr [rsp+0x40], ymm4
       vmovdqu  ymmword ptr [rsp+0x60], ymm4
       vmovdqa  xmmword ptr [rsp+0x80], xmm4
       mov      rbx, rcx
       mov      rsi, rdx
       mov      edi, r8d
 
G_M000_IG02:                ;; offset=0x0039
       test     dil, dil
       jne      G_M000_IG14
       mov      rbp, gword ptr [rbx+0x30]
       mov      r14, gword ptr [rbp+0x08]
       cmp      gword ptr [r14+0x50], 0
       jne      SHORT G_M000_IG05
 
G_M000_IG03:                ;; offset=0x0051
       cmp      byte  ptr [rbp+0x40], 0
       jne      G_M000_IG13
 
G_M000_IG04:                ;; offset=0x005B
       mov      rcx, rbp
       call     [Lokad.Lython.Runtime.LythonRuntime+CsvRecordSource:Pull():this]
       mov      r14, gword ptr [rbp+0x08]
       cmp      gword ptr [r14+0x50], 0
       je       SHORT G_M000_IG03
 
G_M000_IG05:                ;; offset=0x006F
       mov      rbp, gword ptr [r14+0x50]
       xor      rcx, rcx
       mov      gword ptr [r14+0x50], rcx
 
G_M000_IG06:                ;; offset=0x0079
       xor      r14, r14
       xor      r15d, r15d
       mov      r13d, 1
 
G_M000_IG07:                ;; offset=0x0085
       test     r14, r14
       jne      G_M000_IG15
 
G_M000_IG08:                ;; offset=0x008E
       test     rbp, rbp
       je       G_M000_IG21
 
G_M000_IG09:                ;; offset=0x0097
       lea      r14, bword ptr [rbx+0x48]
       mov      rcx, gword ptr [rbx+0x30]
       movsxd   r15, dword ptr [rcx+0x3C]
       mov      rcx, 0x1DA078020C0
       mov      rdx, gword ptr [rcx]
       mov      rcx, r14
       call     CORINFO_HELP_ASSIGN_REF
       mov      qword ptr [r14+0x08], r15
       cmp      dword ptr [rbp+0x08], 0
       je       G_M000_IG24
       movzx    r9, dil
       lea      rdx, [rsp+0x58]
       mov      rcx, rbx
       mov      r8, rbp
       call     [Lokad.Lython.Runtime.LythonRuntime+CsvDictReaderObject:BuildRow(System.Object[],bool):System.Threading.Tasks.ValueTask`1[Lokad.Lython.Runtime.PyIterationResult]:this]
 
G_M000_IG10:                ;; offset=0x00DB
       vmovdqu  ymm0, ymmword ptr [rsp+0x58]
       vmovdqu  ymmword ptr [rsi], ymm0
 
G_M000_IG11:                ;; offset=0x00E5
       mov      rax, rsi
 
G_M000_IG12:                ;; offset=0x00E8
       vzeroupper 
       add      rsp, 144
       pop      rbx
       pop      rbp
       pop      rsi
       pop      rdi
       pop      r13
       pop      r14
       pop      r15
       ret      
 
G_M000_IG13:                ;; offset=0x00FD
       xor      rbp, rbp
       jmp      G_M000_IG06
 
G_M000_IG14:                ;; offset=0x0104
       mov      rcx, gword ptr [rbx+0x30]
       lea      rdx, [rsp+0x78]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+CsvRecordSource:TryMoveNextAsync():System.Threading.Tasks.ValueTask`1[System.Object[]]:this]
       mov      r14, gword ptr [rsp+0x78]
       mov      rbp, gword ptr [rsp+0x80]
       movsx    r15, word  ptr [rsp+0x88]
       movzx    r13, byte  ptr [rsp+0x8A]
       jmp      G_M000_IG07
 
G_M000_IG15:                ;; offset=0x0139
       mov      rdx, r14
       mov      rcx, 0x7FF9FD83C3C8
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG16
       mov      rcx, rax
       call     [System.Threading.Tasks.Task:get_IsCompletedSuccessfully():bool:this]
       jmp      SHORT G_M000_IG17
 
G_M000_IG16:                ;; offset=0x015B
       mov      rcx, r14
       mov      edx, r15d
       mov      r11, 0x7FF9FCD129D8
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[System.__Canon]:GetStatus(short):int:this
       cmp      eax, 1
       sete     al
       movzx    rax, al
 
G_M000_IG17:                ;; offset=0x0177
       test     eax, eax
       jne      SHORT G_M000_IG18
       mov      gword ptr [rsp+0x20], r14
       mov      gword ptr [rsp+0x28], rbp
       mov      word  ptr [rsp+0x30], r15w
       mov      byte  ptr [rsp+0x32], r13b
       lea      r8, [rsp+0x20]
       movzx    r9, dil
       mov      rdx, rsi
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+CsvDictReaderObject:AwaitDataRowAsync(System.Threading.Tasks.ValueTask`1[System.Object[]],bool):System.Threading.Tasks.ValueTask`1[Lokad.Lython.Runtime.PyIterationResult]:this]
       jmp      G_M000_IG11
 
G_M000_IG18:                ;; offset=0x01AA
       mov      rdx, r14
       mov      rcx, 0x7FF9FD83C3C8
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       mov      rbp, rax
       test     rbp, rbp
       je       SHORT G_M000_IG20
       mov      ecx, dword ptr [rbp+0x34]
       and      ecx, 0x11000000
       cmp      ecx, 0x1000000
       je       SHORT G_M000_IG19
       mov      rcx, rbp
       xor      edx, edx
       call     [System.Runtime.CompilerServices.TaskAwaiter:HandleNonSuccessAndDebuggerNotification(System.Threading.Tasks.Task,int)]
 
G_M000_IG19:                ;; offset=0x01E0
       mov      rbp, gword ptr [rbp+0x38]
       jmp      G_M000_IG08
 
G_M000_IG20:                ;; offset=0x01E9
       mov      rcx, r14
       mov      edx, r15d
       mov      r11, 0x7FF9FCD129E0
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[System.__Canon]:GetResult(short):System.__Canon:this
       mov      rbp, rax
       jmp      G_M000_IG08
 
G_M000_IG21:                ;; offset=0x0204
       vxorps   xmm0, xmm0, xmm0
       vmovdqu  xmmword ptr [rsp+0x48], xmm0
 
G_M000_IG22:                ;; offset=0x020E
       vmovdqu  ymm0, ymmword ptr [rsp+0x38]
       vmovdqu  ymmword ptr [rsp+0x58], ymm0
 
G_M000_IG23:                ;; offset=0x021A
       mov      byte  ptr [rsp+0x62], 1
       jmp      G_M000_IG10
 
G_M000_IG24:                ;; offset=0x0224
       mov      rcx, gword ptr [rbx+0x30]
       mov      rdx, rbp
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+CsvRecordSource:ReleaseRecord(System.Object[]):this]
       movzx    r8, dil
       lea      rdx, [rsp+0x58]
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+CsvDictReaderObject:SkipBlankRowsAsync(bool):System.Threading.Tasks.ValueTask`1[Lokad.Lython.Runtime.PyIterationResult]:this]
       jmp      G_M000_IG10
 
; Total bytes of code 586

; Assembly listing for method Lokad.Lython.Runtime.LythonRuntime+CsvDictReaderObject:BuildRecord(System.Object[],System.Object,bool):System.Threading.Tasks.ValueTask`1[Lokad.Lython.Runtime.PyIterationResult]:this (Tier1)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; Tier1 code
; optimized code
; optimized using Synthesized PGO
; rbp based frame
; fully interruptible
; with Synthesized PGO: fgCalledCount is 156128
; 26 inlinees with PGO data; 73 single block inlinees; 0 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       push     r15
       push     r14
       push     r13
       push     r12
       push     rdi
       push     rsi
       push     rbx
       sub      rsp, 280
       lea      rbp, [rsp+0x150]
       vxorps   xmm4, xmm4, xmm4
       vmovdqa  xmmword ptr [rbp-0x110], xmm4
       mov      rax, -192
 
G_M000_IG85:                ;; offset=0x0031
       vmovdqa  xmmword ptr [rbp+rax-0x40], xmm4
       vmovdqa  xmmword ptr [rbp+rax-0x30], xmm4
       vmovdqa  xmmword ptr [rbp+rax-0x20], xmm4
       add      rax, 48
       jne      SHORT G_M000_IG85
       mov      gword ptr [rbp+0x10], rcx
       mov      qword ptr [rbp+0x18], rdx
       mov      gword ptr [rbp+0x20], r8
       mov      gword ptr [rbp+0x28], r9
       mov      rdx, r8
 
G_M000_IG02:                ;; offset=0x005C
       mov      dword ptr [rbp-0x3C], 1
 
G_M000_IG03:                ;; offset=0x0063
       mov      rbx, gword ptr [rcx+0x40]
       mov      gword ptr [rbp-0x100], rbx
       test     r9, r9
       je       G_M000_IG33
 
G_M000_IG04:                ;; offset=0x0077
       mov      rax, 0x7FF9FD56DEB0
       cmp      qword ptr [r9], rax
       jne      G_M000_IG33
 
G_M000_IG05:                ;; offset=0x008A
       test     rbx, rbx
       je       G_M000_IG34
 
G_M000_IG06:                ;; offset=0x0093
       mov      rsi, gword ptr [rcx+0x20]
       mov      rdi, gword ptr [rcx+0x28]
       mov      r14, rdx
       mov      rax, gword ptr [rsi+0x98]
       mov      r8, gword ptr [rax+0x88]
       cmp      gword ptr [r8+0x20], 0
       jne      G_M000_IG48
       mov      r8, gword ptr [rax+0x180]
       test     r8, r8
       jne      G_M000_IG47
 
G_M000_IG07:                ;; offset=0x00C7
       mov      rax, gword ptr [rbx+0x10]
       test     rax, rax
       je       G_M000_IG49
       mov      r8, gword ptr [rsi+0x98]
       cmp      rax, gword ptr [r8+0x88]
       jne      G_M000_IG49
       mov      r9, gword ptr [rbp+0x28]
       mov      eax, dword ptr [r9+0x28]
       mov      r8d, dword ptr [rbx+0x20]
       cmp      eax, r8d
       jne      G_M000_IG50
       mov      r15d, dword ptr [r14+0x08]
       cmp      r15d, r8d
       jne      G_M000_IG50
       xor      r13d, r13d
       cmp      dword ptr [rbx+0x20], 0
       jle      SHORT G_M000_IG10
 
G_M000_IG08:                ;; offset=0x0113
       mov      rax, gword ptr [rsi+0x98]
       mov      r8, gword ptr [rax+0x88]
       cmp      gword ptr [r8+0x20], 0
       jne      G_M000_IG52
       mov      r8, gword ptr [rax+0x180]
       test     r8, r8
       jne      G_M000_IG51
 
G_M000_IG09:                ;; offset=0x013C
       mov      rax, gword ptr [rbx+0x08]
       cmp      r13d, dword ptr [rax+0x08]
       jae      G_M000_IG60
       lea      r8, [r13+4*r13]
       mov      rax, gword ptr [rax+8*r8+0x10]
       mov      r9, gword ptr [rbp+0x28]
       mov      r8, gword ptr [r9+0x08]
       cmp      r13d, dword ptr [r8+0x08]
       jae      G_M000_IG60
       cmp      rax, gword ptr [r8+8*r13+0x10]
       jne      G_M000_IG50
       inc      r13d
       cmp      r13d, dword ptr [rbx+0x20]
       jl       SHORT G_M000_IG08
 
G_M000_IG10:                ;; offset=0x017A
       mov      r13, gword ptr [rbx+0x10]
       cmp      byte  ptr [r13], r13b
       mov      rcx, 0x7FF9FD18CE88
       call     CORINFO_HELP_NEWSFAST
       mov      r12, rax
       lea      rcx, bword ptr [r12+0x08]
       mov      rdx, r13
       call     CORINFO_HELP_ASSIGN_REF
       mov      r13, gword ptr [r12+0x08]
       test     r13, r13
       je       G_M000_IG53
       mov      rcx, r13
       mov      r8, rdi
       mov      edx, 192
       call     [Lokad.Lython.Runtime.MemoryGovernor:Reserve(long,Lokad.Lython.LythonSourceSpan):this]
       cmp      gword ptr [r12+0x08], 0
       je       G_M000_IG54
       mov      rcx, qword ptr [r12+0x10]
       mov      rdx, 0x7FFFFFFFFFFFFF3F
       cmp      rcx, rdx
       jg       G_M000_IG55
       add      rcx, 192
       mov      qword ptr [r12+0x10], rcx
       mov      gword ptr [rbp-0x108], r12
 
G_M000_IG11:                ;; offset=0x01F7
       mov      rcx, gword ptr [rsi+0x98]
       mov      rdx, gword ptr [rcx+0x88]
       cmp      gword ptr [rdx+0x20], 0
       jne      G_M000_IG18
       mov      rdx, gword ptr [rcx+0x180]
       test     rdx, rdx
       jne      G_M000_IG17
 
G_M000_IG12:                ;; offset=0x0220
       mov      r9, gword ptr [rbp+0x28]
       mov      ecx, dword ptr [r9+0x28]
       mov      edx, dword ptr [rbx+0x20]
       cmp      ecx, edx
       jne      G_M000_IG19
       cmp      r15d, edx
       jne      G_M000_IG19
       xor      r13d, r13d
       cmp      dword ptr [rbx+0x20], 0
       jle      SHORT G_M000_IG15
 
G_M000_IG13:                ;; offset=0x0245
       mov      rcx, gword ptr [rsi+0x98]
       mov      rdx, gword ptr [rcx+0x88]
       cmp      gword ptr [rdx+0x20], 0
       jne      G_M000_IG21
       mov      rdx, gword ptr [rcx+0x180]
       test     rdx, rdx
       jne      G_M000_IG20
 
G_M000_IG14:                ;; offset=0x026E
       mov      rcx, gword ptr [rbx+0x08]
       cmp      r13d, dword ptr [rcx+0x08]
       jae      G_M000_IG24
       lea      rax, [r13+4*r13]
       mov      rcx, gword ptr [rcx+8*rax+0x10]
       mov      r9, gword ptr [rbp+0x28]
       mov      rax, gword ptr [r9+0x08]
       cmp      r13d, dword ptr [rax+0x08]
       jae      G_M000_IG24
       cmp      rcx, gword ptr [rax+8*r13+0x10]
       jne      G_M000_IG19
       inc      r13d
       cmp      r13d, dword ptr [rbx+0x20]
       jl       SHORT G_M000_IG13
 
G_M000_IG15:                ;; offset=0x02AC
       mov      rcx, 0x7FF9FD272430
       call     CORINFO_HELP_NEWSFAST
       mov      rsi, rax
       mov      r13, gword ptr [rbx+0x08]
       mov      r12, qword ptr [rbx+0x18]
       mov      rdx, gword ptr [rbx+0x10]
       lea      rcx, bword ptr [rsi+0x10]
       call     CORINFO_HELP_ASSIGN_REF
       lea      rcx, bword ptr [rsi+0x18]
       mov      rdx, rdi
       call     CORINFO_HELP_ASSIGN_REF
       lea      rcx, bword ptr [rsi+0x08]
       mov      rdx, rsi
       call     CORINFO_HELP_ASSIGN_REF
       lea      rcx, bword ptr [rsi+0x28]
       mov      rdx, r13
       call     CORINFO_HELP_ASSIGN_REF
       lea      rcx, bword ptr [rsi+0x20]
       mov      rdx, rbx
       call     CORINFO_HELP_ASSIGN_REF
       mov      qword ptr [rsi+0x38], r12
       mov      rcx, 0x1DA07802078
       mov      rdx, gword ptr [rcx]
       lea      rcx, bword ptr [rsi+0x30]
       call     CORINFO_HELP_ASSIGN_REF
       lea      rcx, bword ptr [rsi+0x30]
       mov      rdx, r14
       call     CORINFO_HELP_ASSIGN_REF
       mov      dword ptr [rsi+0x4C], r15d
       mov      ecx, r15d
       imul     rcx, rcx, 80
       jo       G_M000_IG25
       add      rcx, 64
       jo       G_M000_IG25
       add      rcx, 192
       jo       G_M000_IG25
       mov      qword ptr [rsi+0x40], rcx
 
G_M000_IG16:                ;; offset=0x0355
       mov      r12, gword ptr [rbp-0x108]
       mov      rcx, gword ptr [r12+0x08]
       test     rcx, rcx
       je       G_M000_IG22
       mov      rax, qword ptr [r12+0x10]
       cmp      rax, 192
       jl       G_M000_IG23
       mov      rdx, qword ptr [rcx+0x28]
       mov      r8, rdx
       mov      r10d, 192
       cmp      r8, 192
       cmovl    r10, r8
       sub      rdx, r10
       mov      qword ptr [rcx+0x28], rdx
       add      r10, qword ptr [rcx+0x30]
       jo       G_M000_IG25
       mov      qword ptr [rcx+0x30], r10
       add      rax, -192
       mov      qword ptr [r12+0x10], rax
       mov      gword ptr [rbp-0x110], rsi
       jmp      G_M000_IG26
 
G_M000_IG17:                ;; offset=0x03BF
       cmp      dword ptr [rdx+0x20], 0
       setne    dl
       movzx    rdx, dl
       test     edx, edx
       je       G_M000_IG12
 
G_M000_IG18:                ;; offset=0x03D1
       mov      rdx, rdi
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
       jmp      G_M000_IG12
 
G_M000_IG19:                ;; offset=0x03DF
       xor      rdx, rdx
       mov      gword ptr [rbp-0x110], rdx
       mov      r12, gword ptr [rbp-0x108]
       jmp      G_M000_IG26
 
G_M000_IG20:                ;; offset=0x03F4
       cmp      dword ptr [rdx+0x20], 0
       setne    dl
       movzx    rdx, dl
       test     edx, edx
       je       G_M000_IG14
 
G_M000_IG21:                ;; offset=0x0406
       mov      rdx, rdi
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
       jmp      G_M000_IG14
 
G_M000_IG22:                ;; offset=0x0414
       mov      rcx, 0x7FF9FD172DF0
       call     CORINFO_HELP_NEWSFAST
       mov      r15, rax
       mov      rcx, r15
       mov      rdx, 0x1FA2E1BBBA8
       call     [System.ObjectDisposedException:.ctor(System.String):this]
       mov      rcx, r15
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG23:                ;; offset=0x0442
       mov      rcx, 0x7FF9FCF3A220
       call     CORINFO_HELP_NEWSFAST
       mov      rdi, rax
       mov      rcx, rdi
       mov      rdx, 0x1FA2E1E5460
       call     [System.InvalidOperationException:.ctor(System.String):this]
       mov      rcx, rdi
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG24:                ;; offset=0x0470
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG25:                ;; offset=0x0476
       call     CORINFO_HELP_OVERFLOW
       int3     
 
G_M000_IG26:                ;; offset=0x047C
       call     G_M000_IG74
       nop      
 
G_M000_IG27:                ;; offset=0x0482
       mov      r12, gword ptr [rbp-0x110]
       mov      rbx, gword ptr [rbp-0x100]
 
G_M000_IG28:                ;; offset=0x0490
       test     r12, r12
       je       SHORT G_M000_IG34
 
G_M000_IG29:                ;; offset=0x0495
       mov      rcx, gword ptr [rbp+0x10]
       lea      rcx, bword ptr [rcx+0x40]
       mov      rdx, rbx
       call     CORINFO_HELP_ASSIGN_REF
       xor      ecx, ecx
       mov      dword ptr [rbp-0x3C], ecx
 
G_M000_IG30:                ;; offset=0x04AA
       xor      rbx, rbx
 
G_M000_IG31:                ;; offset=0x04AC
       xor      esi, esi
       mov      edi, 1
 
G_M000_IG32:                ;; offset=0x04B3
       xor      r14d, r14d
       mov      r15d, edi
       mov      edi, esi
       mov      rsi, rbx
       jmp      G_M000_IG67
 
G_M000_IG33:                ;; offset=0x04C3
       mov      r9, gword ptr [rbp+0x28]
       test     r9, r9
       je       G_M000_IG41
 
G_M000_IG34:                ;; offset=0x04D0
       mov      rcx, gword ptr [rbp+0x10]
       mov      rdx, gword ptr [rbp+0x20]
       mov      r9, gword ptr [rbp+0x28]
       mov      rax, 0x7FF9FD56DEB0
       cmp      qword ptr [r9], rax
       jne      G_M000_IG41
 
G_M000_IG35:                ;; offset=0x04EF
       mov      rsi, r9
       mov      rdx, r9
       call     [Lokad.Lython.Runtime.LythonRuntime+CsvDictReaderObject:HasStringFieldNames(Lokad.Lython.Runtime.PyList):bool:this]
       test     eax, eax
       mov      r9, gword ptr [rbp+0x28]
       je       G_M000_IG41
       mov      r8d, dword ptr [rsi+0x28]
       mov      rdx, gword ptr [rbp+0x20]
       mov      r15d, dword ptr [rdx+0x08]
       cmp      r15d, r8d
       setg     dil
       movzx    rdi, dil
       add      edi, r8d
       jo       G_M000_IG61
       mov      rcx, gword ptr [rbp+0x10]
       mov      r9, gword ptr [rcx+0x40]
       test     r9, r9
       jne      G_M000_IG56
       xor      r12, r12
 
G_M000_IG36:                ;; offset=0x053B
       test     r12, r12
       jne      SHORT G_M000_IG37
       mov      rax, gword ptr [rcx+0x20]
       mov      r12, gword ptr [rax+0x98]
       mov      rcx, 0x7FF9FD272430
       call     CORINFO_HELP_NEWSFAST
       mov      r14, rax
       xor      r8d, r8d
       mov      dword ptr [rsp+0x20], r8d
       mov      r8, gword ptr [r12+0x88]
       mov      rcx, gword ptr [rbp+0x10]
       mov      r9, gword ptr [rcx+0x28]
       mov      rcx, r14
       mov      edx, edi
       call     [Lokad.Lython.Runtime.PyDict:.ctor(int,Lokad.Lython.Runtime.MemoryGovernor,Lokad.Lython.LythonSourceSpan,bool):this]
       mov      r12, r14
       mov      rcx, gword ptr [rbp+0x10]
 
G_M000_IG37:                ;; offset=0x0587
       xor      ebx, ebx
       cmp      dword ptr [rsi+0x28], 0
       jg       G_M000_IG44
 
G_M000_IG38:                ;; offset=0x0593
       cmp      r15d, dword ptr [rsi+0x28]
       jg       G_M000_IG62
 
G_M000_IG39:                ;; offset=0x059D
       mov      rbx, gword ptr [rbp+0x10]
       mov      r8, gword ptr [rbx+0x28]
       mov      rdx, gword ptr [rbx+0x20]
       mov      rcx, r12
       call     [Lokad.Lython.Runtime.PyDict:ShareRecordKeys(Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.PyDict+RecordKeys:this]
       mov      rdx, rax
       lea      rcx, bword ptr [rbx+0x40]
       call     CORINFO_HELP_ASSIGN_REF
       lea      rcx, [rbp-0x88]
       mov      rdx, r12
       call     [Lokad.Lython.Runtime.PyIterationResult:Yield(System.Object):Lokad.Lython.Runtime.PyIterationResult]
       mov      r12, gword ptr [rbp-0x88]
       mov      r14, qword ptr [rbp-0x80]
       xor      rdx, rdx
       xor      rsi, rsi
 
G_M000_IG40:                ;; offset=0x05DD
       xor      edi, edi
       mov      r15d, 1
       jmp      G_M000_IG67
 
G_M000_IG41:                ;; offset=0x05EA
       mov      rcx, gword ptr [rbp+0x10]
       movzx    r8, byte  ptr [rbp+0x30]
       mov      dword ptr [rsp+0x20], r8d
       lea      rdx, [rbp-0x78]
       mov      r8, gword ptr [rbp+0x20]
       call     [Lokad.Lython.Runtime.LythonRuntime+CsvDictReaderObject:BuildProtocolRecordAsync(System.Object[],System.Object,bool):System.Threading.Tasks.ValueTask`1[Lokad.Lython.Runtime.PyIterationResult]:this]
       xor      ecx, ecx
       mov      dword ptr [rbp-0x3C], ecx
       mov      rsi, gword ptr [rbp-0x78]
       movsx    rdi, word  ptr [rbp-0x70]
       movzx    r15, byte  ptr [rbp-0x6E]
       mov      r12, gword ptr [rbp-0x68]
       mov      r14, qword ptr [rbp-0x60]
       jmp      G_M000_IG67
 
G_M000_IG42:                ;; offset=0x0626
       mov      rdx, r8
       cmp      r15d, ebx
       jle      G_M000_IG59
       mov      rax, gword ptr [rbp+0x20]
       mov      r8, gword ptr [rax+8*rbx+0x10]
 
G_M000_IG43:                ;; offset=0x063B
       mov      rcx, gword ptr [rbp+0x10]
       mov      r9, gword ptr [rcx+0x28]
       mov      gword ptr [rsp+0x20], r9
       mov      r9, gword ptr [rcx+0x20]
       mov      rcx, r12
       call     [Lokad.Lython.Runtime.PyDict:SetRecordItem(Lokad.Lython.Runtime.Text.PyString,System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):this]
       inc      ebx
       cmp      ebx, dword ptr [rsi+0x28]
       jge      G_M000_IG38
 
G_M000_IG44:                ;; offset=0x0660
       mov      rcx, gword ptr [rbp+0x10]
       mov      rax, gword ptr [rcx+0x20]
       mov      rdi, gword ptr [rcx+0x28]
       mov      r14, gword ptr [rax+0x98]
       cmp      byte  ptr [r14], r14b
       mov      rcx, r14
       call     [Lokad.Lython.Runtime.ExecutionState:get_CanContinue():bool:this]
       test     eax, eax
       je       G_M000_IG57
 
G_M000_IG45:                ;; offset=0x0687
       mov      r9, gword ptr [rsi+0x08]
       cmp      ebx, dword ptr [r9+0x08]
       jae      G_M000_IG60
       mov      rdx, gword ptr [r9+8*rbx+0x10]
       mov      r8, rdx
       test     r8, r8
       je       SHORT G_M000_IG42
 
G_M000_IG46:                ;; offset=0x06A2
       mov      rcx, 0x7FF9FD2377F0
       cmp      qword ptr [r8], rcx
       je       G_M000_IG42
       jmp      G_M000_IG58
 
G_M000_IG47:                ;; offset=0x06BA
       cmp      dword ptr [r8+0x20], 0
       setne    r8b
       movzx    r8, r8b
       test     r8d, r8d
       je       G_M000_IG07
 
G_M000_IG48:                ;; offset=0x06D0
       mov      rcx, rax
       mov      rdx, rdi
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
       jmp      G_M000_IG07
 
G_M000_IG49:                ;; offset=0x06E1
       mov      rcx, 0x7FF9FCF3A220
       call     CORINFO_HELP_NEWSFAST
       mov      rbx, rax
       mov      rcx, rbx
       mov      rdx, 0x1FA2E1E82F8
       call     [System.InvalidOperationException:.ctor(System.String):this]
       mov      rcx, rbx
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG50:                ;; offset=0x070F
       xor      r12, r12
       jmp      G_M000_IG28
 
G_M000_IG51:                ;; offset=0x0717
       cmp      dword ptr [r8+0x20], 0
       setne    r8b
       movzx    r8, r8b
       test     r8d, r8d
       je       G_M000_IG09
 
G_M000_IG52:                ;; offset=0x072D
       mov      rcx, rax
       mov      rdx, rdi
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
       jmp      G_M000_IG09
 
G_M000_IG53:                ;; offset=0x073E
       mov      rcx, 0x7FF9FD172DF0
       call     CORINFO_HELP_NEWSFAST
       mov      rbx, rax
       mov      rcx, rbx
       mov      rdx, 0x1FA2E1BBBA8
       call     [System.ObjectDisposedException:.ctor(System.String):this]
       mov      rcx, rbx
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG54:                ;; offset=0x076C
       mov      rcx, r13
       mov      edx, 192
       call     [Lokad.Lython.Runtime.MemoryGovernor:ReleaseReserved(long):this]
       mov      rcx, r13
       call     [Lokad.Lython.Runtime.MemoryGovernor:ThrowIfAdmissionFailed():this]
       mov      rcx, 0x7FF9FD172DF0
       call     CORINFO_HELP_NEWSFAST
       mov      rbx, rax
       mov      rcx, rbx
       mov      rdx, 0x1FA2E1BBBA8
       call     [System.ObjectDisposedException:.ctor(System.String):this]
       mov      rcx, rbx
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG55:                ;; offset=0x07B1
       mov      qword ptr [r13+0x40], 192
       mov      rcx, r13
       call     [Lokad.Lython.Runtime.MemoryGovernor:get_CurrentAccountedBytes():long:this]
       mov      rdx, rax
       lea      rcx, [rbp-0xA8]
       call     [System.Nullable`1[long]:.ctor(long):this]
       lea      rcx, [rbp-0xB8]
       mov      edx, 192
       call     [System.Nullable`1[long]:.ctor(long):this]
       mov      byte  ptr [rbp-0xC8], 0
       xor      r8d, r8d
       mov      qword ptr [rbp-0xC0], r8
       vmovups  xmm0, xmmword ptr [rbp-0xA8]
       vmovups  xmmword ptr [rbp-0xD8], xmm0
       vmovups  xmm0, xmmword ptr [rbp-0xB8]
       vmovups  xmmword ptr [rbp-0xE8], xmm0
       lea      r8, [rbp-0xC8]
       mov      qword ptr [rsp+0x20], r8
       lea      r8, [rbp-0xD8]
       mov      qword ptr [rsp+0x28], r8
       lea      r8, [rbp-0xE8]
       mov      qword ptr [rsp+0x30], r8
       mov      r8, rdi
       mov      rcx, 0x1FA2E1B75F0
       mov      rdx, 0x1FA2E1BBE00
       mov      r9d, 8
       call     [Lokad.Lython.Runtime.RuntimeErrors:Attributed(System.String,System.String,Lokad.Lython.LythonSourceSpan,int,System.Nullable`1[long],System.Nullable`1[long],System.Nullable`1[long]):Lokad.Lython.Runtime.LythonRuntimeException]
       mov      r12, rax
       lea      rcx, bword ptr [r13+0x20]
       mov      rdx, r12
       call     CORINFO_HELP_ASSIGN_REF
       mov      rcx, r12
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG56:                ;; offset=0x0874
       mov      r8, gword ptr [rcx+0x28]
       mov      rdx, gword ptr [rcx+0x20]
       mov      rcx, r9
       mov      r9d, edi
       call     [Lokad.Lython.Runtime.PyDict+RecordKeys:CreateRecord(Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,int):Lokad.Lython.Runtime.PyDict:this]
       mov      r12, rax
       mov      rcx, gword ptr [rbp+0x10]
       jmp      G_M000_IG36
 
G_M000_IG57:                ;; offset=0x0894
       mov      rcx, r14
       mov      rdx, rdi
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
       jmp      G_M000_IG45
 
G_M000_IG58:                ;; offset=0x08A5
       call     CORINFO_HELP_CHKCASTCLASS
       int3     
 
G_M000_IG59:                ;; offset=0x08AB
       mov      rcx, gword ptr [rbp+0x10]
       mov      r8, gword ptr [rcx+0x18]
       jmp      G_M000_IG43
 
G_M000_IG60:                ;; offset=0x08B8
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG61:                ;; offset=0x08BE
       call     CORINFO_HELP_OVERFLOW
       int3     
 
G_M000_IG62:                ;; offset=0x08C4
       mov      rcx, gword ptr [rbp+0x10]
       mov      rdx, gword ptr [rcx+0x20]
       mov      r8, gword ptr [rcx+0x28]
       lea      rcx, [rbp-0x58]
       call     [Lokad.Lython.Runtime.PyStructuralGuard:PushAmbient(Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.PyStructuralGuard+AmbientScope]
       nop      
 
G_M000_IG63:                ;; offset=0x08DB
       mov      rcx, gword ptr [rbp+0x10]
       mov      rcx, gword ptr [rcx+0x10]
       mov      rbx, gword ptr [rbp+0x10]
       mov      rdx, gword ptr [rbx+0x28]
       call     [Lokad.Lython.Runtime.LythonRuntime:ValidateDictionaryKey(System.Object,Lokad.Lython.LythonSourceSpan):System.Object]
       mov      rdi, rax
       mov      edx, dword ptr [rsi+0x28]
       lea      rcx, [rbp-0x98]
       call     [System.Numerics.BigInteger:.ctor(int):this]
 
G_M000_IG64:                ;; offset=0x0904
       vmovdqu  xmm0, xmmword ptr [rbp-0x98]
       vmovdqu  xmmword ptr [rbp-0xF8], xmm0
 
G_M000_IG65:                ;; offset=0x0914
       lea      r8, [rbp-0xF8]
       mov      rdx, gword ptr [rbp+0x20]
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+CsvDictReaderObject:RestFields(System.Object[],System.Numerics.BigInteger):Lokad.Lython.Runtime.PyList:this]
       mov      r8, rax
       mov      rdx, rdi
       mov      rcx, r12
       call     [Lokad.Lython.Runtime.PyDict:SetItem(System.Object,System.Object):this]
       nop      
 
G_M000_IG66:                ;; offset=0x0938
       lea      rcx, [rbp-0x58]
       call     [Lokad.Lython.Runtime.PyStructuralGuard+AmbientScope:Dispose():this]
       jmp      G_M000_IG39
 
G_M000_IG67:                ;; offset=0x0947
       cmp      dword ptr [rbp-0x3C], 0
       jne      SHORT G_M000_IG70
 
G_M000_IG68:                ;; offset=0x094D
       mov      rax, qword ptr [rbp+0x18]
       mov      gword ptr [rax], rsi
       mov      word  ptr [rax+0x08], di
       mov      byte  ptr [rax+0x0A], r15b
       mov      gword ptr [rax+0x10], r12
       mov      qword ptr [rax+0x18], r14
 
G_M000_IG69:                ;; offset=0x0964
       add      rsp, 280
       pop      rbx
       pop      rsi
       pop      rdi
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG70:                ;; offset=0x0978
       mov      rbx, gword ptr [rbp+0x10]
       mov      rcx, gword ptr [rbx+0x30]
       mov      rdx, gword ptr [rbp+0x20]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+CsvRecordSource:ReleaseRecord(System.Object[]):this]
       jmp      SHORT G_M000_IG68
 
G_M000_IG71:                ;; offset=0x098E
       sub      rsp, 56
 
G_M000_IG72:                ;; offset=0x0992
       lea      rcx, [rbp-0x58]
       call     [Lokad.Lython.Runtime.PyStructuralGuard+AmbientScope:Dispose():this]
       nop      
 
G_M000_IG73:                ;; offset=0x099D
       add      rsp, 56
       ret      
 
G_M000_IG74:                ;; offset=0x09A2
       sub      rsp, 56
 
G_M000_IG75:                ;; offset=0x09A6
       mov      r12, gword ptr [rbp-0x108]
       lea      rdx, bword ptr [r12+0x08]
       xor      rcx, rcx
       xchg     gword ptr [rdx], rcx
       test     rcx, rcx
       je       SHORT G_M000_IG77
       mov      rdx, qword ptr [r12+0x10]
       xor      eax, eax
       mov      qword ptr [r12+0x10], rax
       test     rdx, rdx
       jle      SHORT G_M000_IG77
 
G_M000_IG76:                ;; offset=0x09CD
       mov      rax, qword ptr [rcx+0x28]
       mov      r8, rax
       cmp      rdx, r8
       cmovg    rdx, r8
       test     rdx, rdx
       je       SHORT G_M000_IG77
       sub      rax, rdx
       mov      rdx, rax
       mov      qword ptr [rcx+0x28], rdx
       add      rdx, qword ptr [rcx+0x30]
       jo       SHORT G_M000_IG79
       call     [Lokad.Lython.Runtime.MemoryGovernor:ResizeOwnership(long):bool:this]
 
G_M000_IG77:                ;; offset=0x09F6
       nop      
 
G_M000_IG78:                ;; offset=0x09F7
       add      rsp, 56
       ret      
 
G_M000_IG79:                ;; offset=0x09FC
       call     CORINFO_HELP_OVERFLOW
       int3     
 
G_M000_IG80:                ;; offset=0x0A02
       sub      rsp, 56
 
G_M000_IG81:                ;; offset=0x0A06
       cmp      dword ptr [rbp-0x3C], 0
       je       SHORT G_M000_IG83
 
G_M000_IG82:                ;; offset=0x0A0C
       mov      rbx, gword ptr [rbp+0x10]
       mov      rcx, gword ptr [rbx+0x30]
       mov      rdx, gword ptr [rbp+0x20]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+CsvRecordSource:ReleaseRecord(System.Object[]):this]
 
G_M000_IG83:                ;; offset=0x0A20
       nop      
 
G_M000_IG84:                ;; offset=0x0A21
       add      rsp, 56
       ret      
 
; Total bytes of code 2598

