from pathlib import Path
import hashlib,json,shutil,tarfile
r=Path(__file__).parent
out=Path('benchmarks/results/2026-11-12-utf16-cpython-checkpoint');out.mkdir(exist_ok=True)
summary=json.loads((r/'summary.json').read_text(encoding='utf-8'))
assert summary['complete']and len(summary['timing'])==7
assert json.loads((r/'terminal-status.json').read_text(encoding='utf-8'))['exitCode']=='0'
for name in ['observations.tgz','archive-receipt.json','summary.json','terminal-status.json','extraction.json']:shutil.copyfile(r/name,out/name)
with tarfile.open(out/'preparation.tar.xz','w:xz')as t:
    for name in ['prepare.py','remote-launch.py','launch.py','launch.log','launch-corrected.log','config.json','prepare-retrieval.py','retrieve.py','summarize.py','publish-evidence.py','observe-not-before.json']:
        t.add(r/name,arcname=name)
doc=Path('docs/BENCHMARKS.md');text=doc.read_text(encoding='utf-8')
(out/'prior-BENCHMARKS.md').write_text(text,encoding='utf-8',newline='\n')
rows={}
workloads={'scripts.text-summary-helpers.nonlocal-counter.large':'Text / captured helper + counter','scripts.report-render.utf16.large':'JSON-to-Markdown / UTF-16 output','scripts.report-render.large':'JSON-to-Markdown report','scripts.config-edit.small':'Config edit'}
inputs={'scripts.text-summary-helpers.nonlocal-counter.large':'3,072 lines /35,840 B','scripts.report-render.utf16.large':'3,072 records /189,441 B','scripts.report-render.large':'3,072 records /189,441 B','scripts.config-edit.small':'181 B / one JSON file'}
def bounds(values,decimals):
    lo,hi=min(values),max(values)
    return f'{lo:.{decimals}f}–{hi:.{decimals}f}'
for row in summary['timing']:
    case,lane=row['case'],row['lane'];m=row['medianMilliseconds']
    config=case=='scripts.config-edit.small';scale=1000 if config else 1;unit='µs'if config else'ms';decimals=2 if lane=='compile'else 1 if config else 3
    ly=bounds([m[k]*scale for k in ['candidate','candidate-control']],decimals)+' '+unit
    py=bounds([m[k]*scale for k in ['CPython','CPython-control']],decimals)+' '+unit
    ratio=bounds(row['ratioRange'],2)+'×'
    control=row['controlsPercent'];iqr=max(row['iqrPercent'].values())
    status='Variable'if case=='scripts.text-summary-helpers.nonlocal-counter.large'and lane=='compile-run'else'Diagnostic'
    ending=f' | {ly} | {py} | {ratio} | `41bd869b` | {status}; L{control["Lython"]:.2f}%, P{control["CPython"]:.2f}% / {iqr:.2f}% |'
    rows[(workloads[case],lane)]='| '+workloads[case]+(' | '+inputs[case]if lane=='compile-run'else'')+ending
section='compile-run';result=[];changed=set()
for line in text.splitlines():
    if line.startswith('Warm execution reuses'):section='warm'
    if line.startswith('Compilation alone includes'):section='compile'
    label=line.split('|')[1].strip()if line.startswith('| ')else''
    key=(label,section)
    if key in rows:
        assert key not in changed,key
        line=rows[key];changed.add(key)
    result.append(line)
assert changed==set(rows),(changed,set(rows))
text='\n'.join(result)+'\n'
start=text.index('**Measured sources:**');end=text.index('Earlier rows remain historical:',start)
text=text[:start]+'''**Measured sources:** collected 2026-11-12: qualified `41bd869b` for captured
text and UTF-16 report warm/compile-to-result, UTF-8 report warm, and config
compilation/compile-to-result. [Exact identities, controls and boundaries](../benchmarks/results/2026-11-12-utf16-cpython-checkpoint/README.md).
Captured-text compile-to-result has5.19% Lython process spread and remains variable.
`8ec7bfab` retains file search/JSON-lines all phases; `da9e5066` retains CSV
validation/guarded search; `983bab96` retains ordinary text, report/captured-text
compilation and UTF-8 report compile-to-result. `82ed92d4` retains keyword-default
search. All use stock CPython3.13.16 on the same quiet VM; each row names its source.
''' +text[end:]
text=text.replace('five-second warmups per role/job and seven rotated 250 ms rounds for `8ec7bfab`','five-second warmups per role/job and seven rotated250ms rounds for `41bd869b`\n(frozen `f0b736b2`); captured-text/UTF16 warmups are twelve seconds. `8ec7bfab`')
text=text.replace('(frozen `641c3f75`); captured-text warmup is twelve seconds. Earlier CSV/guarded','uses frozen`641c3f75` with the recorded5s/12s warmups. Earlier CSV/guarded')
text=text.replace('quiet, joined-user and archival checks pass. Original/adverse controls and','quiet, joined-user and archival checks pass. The [latest selected checkpoint](../benchmarks/results/2026-11-12-utf16-cpython-checkpoint/README.md)\nretains the captured-text fresh variability and significant warm gaps. Original/adverse controls and')
doc.write_text(text,encoding='utf-8',newline='\n')
manifest={p.name:dict(bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())for p in out.iterdir()if p.is_file()and p.name not in ('manifest.json','README.md')}
(out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8',newline='\n')
print('Seven source-labelled rows replaced; prior guide, all raw observations and initial launch failure preserved.')
