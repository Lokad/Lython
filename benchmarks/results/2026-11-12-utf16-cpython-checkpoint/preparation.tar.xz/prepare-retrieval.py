from pathlib import Path
import ast
r=Path(__file__).parent
old=r.parent/'bulk-utf16-r276/b632'
text=(old/'retrieve.py').read_text(encoding='utf-8')
text=text.replace('/home/lokad/lython-bench-checks/bulk-utf16-b632-20261112','/home/lokad/lython-bench-checks/utf16-cpython-b633-20261112').replace('lython-b632-bulk-utf16-20261112','lython-b633-cpython-checkpoint-20261112')
text=text.replace("['jobs']==3","['jobs']==7").replace("['elapsedSeconds']<300","['elapsedSeconds']<480").replace('B632 three-job','B633 seven-job')
ast.parse(text)
(r/'retrieve.py').write_text(text,encoding='utf-8',newline='\n')
text=(r.parent/'reader-line-windows-r271/b625/summarize.py').read_text(encoding='utf-8').replace('retrieved/external-phases/confirmation.json','retrieved/confirmation/confirmation.json').replace("len(raw['jobs'])==4","len(raw['jobs'])==7").replace("revision='8ec7bfab'","revision='41bd869beee1bb53880da89124d4a1e98b2105df'")
ast.parse(text)
(r/'summarize.py').write_text(text,encoding='utf-8',newline='\n')
print('Existing retrieval and summarizer adapted to seven-job catalog and exact source.')
