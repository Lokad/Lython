from pathlib import Path
import ast,fcntl,hashlib,io,json,os,shutil,subprocess,sys,tarfile
config=CONFIG
base=Path('/home/lokad/lython-bench-checks').resolve()
root=Path(config['root']); source=base/'bulk-utf16-b632-20261112/candidate'
assert root.parent==base and not root.exists()
digest=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
with(base/'comparison-vm.lock').open('a')as lease:
    fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
    users=subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record|[c]omplete-jobs.dll|[p]ython3.*cpython-worker.py'],capture_output=True,text=True)
    assert users.returncode in(0,1) and not [line for line in users.stdout.splitlines()if int(line.split()[0])!=os.getpid()],users.stdout
    assert not list(Path('/dev/shm').glob('lython-comparison-files-*'))
    assert digest(source/'Lokad.Lython.dll')==config['identity']['coreSHA256']['candidate']
    for name,h in config['identity']['auxiliaryFiles'].items():assert digest(source/name)==h,name
    protocol=base/'prepared-call-layout-b384-20261107/cpython-worker.py'
    assert digest(protocol)=='02ca606af6b937a5bec8da744da36e6dbea45ef14ee7207732f34da052ad32f1'
    before=shutil.disk_usage(base).free
    assert before>config['requiredFreeBytes'],before
    payload=sys.stdin.buffer.read(config['payloadBytes']+1)
    assert len(payload)==config['payloadBytes']and hashlib.sha256(payload).hexdigest()==config['payloadSHA256']
    with tarfile.open(fileobj=io.BytesIO(payload),mode='r:gz')as t:
        root.mkdir();t.extractall(root,filter='data')
    shutil.copytree(source,root/'candidate',copy_function=os.link)
    assert digest(root/'candidate/Lokad.Lython.dll')==config['identity']['coreSHA256']['candidate']
    shutil.copyfile(protocol,root/'cpython-worker.py')
    assert digest(root/'representative.json')==config['identity']['catalogSHA256']
    for name in ['collect.py','archive-owned.py']:ast.parse((root/name).read_text())
    subprocess.run(['/bin/sh','-n',str(root/'run.sh')],check=True)
    fixture=root/'guest-fixtures';fixture.mkdir()
    subprocess.run(['sudo','-n','mount','-t','tmpfs','-o','size=128m,mode=0700,uid=lokad,gid=lokad','lython-b633-fixtures',str(fixture)],check=True)
    setup=dict(beforeFreeBytes=before,freeBytes=shutil.disk_usage(base).free,existingImageVerifiedAndReused=True,jobs=7,ownerSeconds=420,stopSeconds=30,marginSeconds=30,osFloorMiB=240,evidenceHeadroomMiB=12,priorEvidenceRemoved=False)
    assert setup['freeBytes']>252*1024*1024
    (root/'setup.json').write_text(json.dumps(setup,indent=2)+'\n');print(json.dumps(setup),flush=True)
try:
    subprocess.run(['sudo','-n','systemd-run','--unit='+config['unit'],'--property=User=lokad','--property=WorkingDirectory='+str(root),'--property=RuntimeMaxSec=420','--property=TimeoutStopSec=30','--property=KillMode=control-group','/bin/sh',str(root/'run.sh')],check=True)
except BaseException:
    subprocess.run(['sudo','-n','umount',str(fixture)],check=True);fixture.rmdir();raise
live=subprocess.check_output(['systemctl','show',config['unit']+'.service','--property=ActiveState,MainPID,RuntimeMaxUSec'],text=True)
assert'ActiveState=active'in live and'MainPID=0'not in live;print(live,flush=True)
