from pathlib import Path
import ast, hashlib, io, json, tarfile

here=Path(__file__).parent
notes=here.parent
root='/home/lokad/lython-bench-checks/utf16-cpython-b633-20261112'
unit='lython-b633-cpython-checkpoint-20261112'
old=notes/'reader-line-windows-r271/b625'
prior=json.loads((notes/'bulk-utf16-r276/b632/config.json').read_text(encoding='utf-8'))
head='41bd869beee1bb53880da89124d4a1e98b2105df'
identity=dict(sourceRevision=head, coreSHA256={k:prior['identity']['coreSHA256']['candidate'] for k in ['candidate','candidate-control']},auxiliaryFiles=prior['identity']['auxiliaryFiles'],catalogSHA256=prior['identity']['catalogSHA256'],sourceEvidence='benchmarks/results/2026-11-12-bulk-utf16/development.tar.xz; retained refined source; exact committed sources qualified separately')
jobs=[['scripts.text-summary-helpers.nonlocal-counter.large','warm'],['scripts.text-summary-helpers.nonlocal-counter.large','compile-run'],['scripts.report-render.utf16.large','warm'],['scripts.report-render.utf16.large','compile-run'],['scripts.report-render.large','warm'],['scripts.config-edit.small','compile'],['scripts.config-edit.small','compile-run']]
assert all(l in ('warm','compile','compile-run')for c,l in jobs)
data=json.loads((notes/'bulk-utf16-r276/b632/representative.json').read_text(encoding='utf-8'))
config_case=next(c for c in json.loads((notes/'config-report-costs-r275/catalog.json').read_text(encoding='utf-8'))['cases'] if c['id']=='scripts.config-edit.small')
data['cases'].append(config_case)
catalog=(json.dumps(data,indent=2)+'\n').encode('utf-8')
identity['catalogSHA256']=hashlib.sha256(catalog).hexdigest()
cases={v['id'] for v in json.loads(catalog)['cases']}
assert all(c in cases for c,l in jobs), (cases,jobs)
def replace_once(text,old,new):
    assert text.count(old)==1,(old,text.count(old))
    return text.replace(old,new)
text=(old/'collect-external-phases.py').read_text(encoding='utf-8')
text=text.replace('/home/lokad/lython-bench-checks/reader-windows-b622-20261112',root)
text=text.replace("'identity-cpython.json'","'identity.json'").replace("'external-phases'","'confirmation'")
start=text.index('jobs=');end=text.index('\nenv = ',start)
text=text[:start]+'jobs='+repr(jobs)+"\nassert len(jobs)==7 and all(case in cases for case,lane in jobs)\n"+text[end:]
text=replace_once(text,"purpose='8ec7bfab representative CPython3.13.16 checkpoint: separate compilation/compile-plus-one-run of current native search/JSON; actual engine identities and duplicate processes; preserve all adverse/uncertain outcomes.'","purpose='Qualified 41bd869b representative CPython3.13.16 checkpoint: captured text, UTF16 report, UTF8 control and config; separate compile/warm/compile-to-result; preserve adverse and uncertain outcomes.'")
text=replace_once(text,"< 145, 'Reserve35seconds for final owned work/cleanup.'","< 380, 'Reserve40seconds for final owned work/cleanup.'")
text=text.replace('archive-external-phases.py','archive-owned.py')
text=replace_once(text,'case_id=="scripts.text-summary-helpers.nonlocal-counter.large"','case_id in ("scripts.text-summary-helpers.nonlocal-counter.large","scripts.report-render.utf16.large")')
text=text.replace('capturedWarmupSeconds=12','capturedAndUtf16WarmupSeconds=12')
ast.parse(text)
(here/'collect.py').write_text(text,encoding='utf-8',newline='\n')
archive=(notes/'bulk-utf16-r276/b632/archive-owned.py').read_text(encoding='utf-8')
archive=archive.replace('/home/lokad/lython-bench-checks/bulk-utf16-b632-20261112',root).replace("==3 ","==7 ").replace('jobs=3','jobs=7')
ast.parse(archive)
(here/'archive-owned.py').write_text(archive,encoding='utf-8',newline='\n')
shell=(notes/'bulk-utf16-r276/b632/run.sh').read_text(encoding='utf-8').replace('/home/lokad/lython-bench-checks/bulk-utf16-b632-20261112',root).replace('lython-b632-bulk-utf16-20261112',unit)
(here/'run.sh').write_text(shell,encoding='utf-8',newline='\n')
(here/'representative.json').write_bytes(catalog)
(here/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8',newline='\n')
with tarfile.open(here/'payload.tgz','w:gz') as t:
    for name in ['collect.py','archive-owned.py','run.sh','representative.json','identity.json']:
        t.add(here/name,arcname=name)
payload=(here/'payload.tgz').read_bytes()
config=dict(root=root,unit=unit,payloadBytes=len(payload),payloadSHA256=hashlib.sha256(payload).hexdigest(),identity=identity,requiredFreeBytes=264*1024*1024,ownerSeconds=420,stopSeconds=30,marginSeconds=30,jobs=jobs)
(here/'config.json').write_text(json.dumps(config,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps(dict(payloadBytes=len(payload),jobs=jobs,core=identity['coreSHA256']['candidate'])))
