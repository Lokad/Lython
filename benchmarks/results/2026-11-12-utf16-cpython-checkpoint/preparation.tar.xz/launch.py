from pathlib import Path
import datetime,json,subprocess
r=Path(__file__).parent
assert not(r/'observe-not-before.json').exists()
config=json.loads((r/'config.json').read_text(encoding='utf-8'))
delivery=r.parent/'bulk-utf16-r276/delivery/terminal-status.json'
ci=json.loads(delivery.read_text(encoding='utf-8'))
assert ci['status']=='completed'and ci['conclusion']=='success'and ci['headSha']==config['identity']['sourceRevision']
script=(r/'remote-launch.py').read_text(encoding='utf-8').replace('config=CONFIG','config='+repr(config))
(r/'launch-command.py').write_text(script,encoding='utf-8',newline='\n')
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
import shlex
command='python3 -c '+shlex.quote(script)
done=subprocess.run(ssh+[command],input=(r/'payload.tgz').read_bytes(),capture_output=True)
name='launch.log'if not(r/'launch.log').exists()else'launch-corrected.log'
assert not(r/name).exists()
(r/name).write_bytes(done.stdout+done.stderr)
print((done.stdout+done.stderr).decode('utf-8'),flush=True)
assert done.returncode==0
(r/'observe-not-before.json').write_text(json.dumps(dict(launchedUTC=datetime.datetime.now(datetime.timezone.utc).isoformat(),doNotObserveBeforeUTC=(datetime.datetime.now(datetime.timezone.utc)+datetime.timedelta(seconds=480)).isoformat()),indent=2)+'\n',encoding='utf-8',newline='\n')
