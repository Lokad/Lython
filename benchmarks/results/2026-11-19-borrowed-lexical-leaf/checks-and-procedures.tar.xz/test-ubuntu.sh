export DOTNET_ROOT=~/.dotnet
lab=/mnt/d/code/Lython/.git/agent-notes/review-20261031/borrowed-lexical-child-r681
~/.dotnet/dotnet test tests/Lokad.Lython.PublicApi.Tests/Lokad.Lython.PublicApi.Tests.csproj -c Release -f net10.0 --artifacts-path "$lab/ubuntu" --filter '(FullyQualifiedName~HelperLocalLifetimeTests|FullyQualifiedName~OrdinaryUnpackingTests|FullyQualifiedName~FramedFunctionExecutionTests|FullyQualifiedName~NativeReceiverPipelineTests|FullyQualifiedName~FunctionDefaultMetadataTests|FullyQualifiedName~ProtectedHelperExecutionTests|FullyQualifiedName~FrameIntegerLifetimeTests|FullyQualifiedName~GeneratorCleanupCompositionTests)&Category!=Stress' >"$lab/ubuntu-public.log" 2>&1
code=$?
tail -n 20 "$lab/ubuntu-public.log"
if test "$code" -ne 0; then exit "$code"; fi
~/.dotnet/dotnet test tests/Lokad.Lython.Tests/Lokad.Lython.Tests.csproj -c Release -f net10.0 --artifacts-path "$lab/ubuntu" --filter '(FullyQualifiedName~SimpleFunctionExecutionBoundaryTests|FullyQualifiedName~MethodBodyCompilationBoundaryTests|FullyQualifiedName~PreparedFunctionExecutionTests|FullyQualifiedName~OrdinaryFunctionTransportTests|FullyQualifiedName~SynchronousGeneratorAdvanceTests)&Category!=Stress' >"$lab/ubuntu-whitebox.log" 2>&1
code=$?
tail -n 10 "$lab/ubuntu-whitebox.log"
exit "$code"
