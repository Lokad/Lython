from pathlib import Path
r=Path(__file__).parent
s=(r.parent/'matched-calls-r414/analyze.py').read_text(encoding='utf-8').replace("['inline','helper']","['report']")
a=s.index(' groups=');b=s.index(' inclusive=',a)
s=s[:a]+" groups={'template/field parsing':['FormatTemplate','FormatFieldAsync','FormatStringAsync','ParseInterpolatedFormatSpecifier','TryParseFormatIndex'],'call/arguments':['InvokeCallable','CallBinder','TryGetCallArguments','ExecuteCallSite','InvokeBorrowed','RawBoundCallable','CustomMethod'],'frame/transport':['NativeContinuation','PrepareTransfer','CreateNative','StartNativeCall','StartInline','TryStartBoundInvocation','BindFunctionArgumentsInto'],'format/append work':['AppendInterpolated','AppendPadded','FormatInteger','FormatFloat','GovernedByteBuilder','TryAppend'],'cooperative admission/checks':['CheckExecution','CheckCancellation','ReserveTemporary','TryReserve']}\n"+s[b:]
(r/'analyze.py').write_text(s,encoding='utf-8',newline='\n')
