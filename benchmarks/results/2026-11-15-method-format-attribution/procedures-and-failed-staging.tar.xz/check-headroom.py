from pathlib import Path
import json,shlex,subprocess
r=Path(__file__).parent;q=r/'profile'
code='''from pathlib import Path
import fcntl,json,shutil
b=Path('/home/lokad/lython-bench-checks')
with(b/'comparison-vm.lock').open('a') as f:
 fcntl.flock(f,fcntl.LOCK_EX|fcntl.LOCK_NB)
 candidates=[p for p in b.glob('*/observations.tgz') if p.is_file()]
 print(json.dumps(dict(freeBytes=shutil.disk_usage(b).free,archives=[dict(path=str(p.relative_to(b)),bytes=p.stat().st_size) for p in candidates]),indent=2))
'''
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
p=subprocess.run(ssh+['python3 -c '+shlex.quote(code)],capture_output=True,timeout=30)
(q/'headroom.json').write_bytes(p.stdout);assert p.returncode==0,p.stderr
print(p.stdout.decode('utf-8'))
