from pathlib import Path
import json,shutil,tarfile
r=Path(__file__).parent;q=r/'profile';out=Path('benchmarks/results/2026-11-15-method-format-attribution');out.mkdir()
for source,name in [(r/'attribution.json','attribution.json'),(r/'compiler-facts.json','compiler-facts.json'),(r/'facts-image.json','facts-image.json'),(q/'identity.json','identity.json'),(q/'observations.tgz','observations.tgz'),(q/'archive-receipt.json','archive-receipt.json'),(q/'terminal-status.json','terminal-status.json')]:shutil.copyfile(source,out/name)
with tarfile.open(out/'procedures-and-failed-staging.tar.xz','w:xz') as a:
 for p in r.rglob('*'):
  if not p.is_file() or 'facts-image' in p.parts or 'retrieved' in p.parts or p.suffix in {'.dll','.exe','.pdb','.tgz'}:continue
  a.add(p,arcname=p.relative_to(r))
(out/'README.md').write_text('''# Complete method-format report attribution

R417 / B811, qualified**b06b8593 / frozen8afb146e** on2026-11-15UTC.
One existing complete JSON-to-Markdown report,1,024records/189,441B JSON,
ordinary str.format; same stdout/file goldens as the f-string version.
Quiet F4as_v7 Ubuntu24.04.4/four EPYC9V45vCPUs/16GiB/no swap,.NET11RC3
normal GC/tiering. One current source,8s full-request warmup,5.55s guest clocks,
199Hz perf frame-pointer sampling. DOTNET_PerfMapEnabled=3 is diagnostic.
Whole worker includes mediated RAM I/O, validation/reset/protocol and prior-result
cleanup, wider than execution clocks. Not a timing pair or removable-share estimate.

**1,052 active-thread samples**,161unknown leaves; all unknowns, overlapping stacks
and other-thread CPU retained. Template/field paths appear in476samples, call/argument
paths161, frame/transport78, actual format/append work195; categories overlap useful
and inlined work. Nearest-frame evidence includes77template,64field,44format-root,
37argument-wrapper and27native-spec-parser samples. Admission Reserve has87 nearest
samples; no conclusion that reservation itself can be removed. Source facts confirm
both report helpers native-eligible/unmirrored, but str.format lacks a registered
receiver method and promotes at LoadCallMember. Promotion frequency is not instrumented.

**Decision:** investigate one reusable format layout per existing execution-owned
bound method, replacing repeated template/field/spec metadata construction for both
format/map through the same executor. Preserve effect/error order, custom hooks,
tokens, retained ownership and genuine suspension. This is a selected redesign,
not a measured improvement. Native frame promotion and argument transport remain
separate debt; no controller or parallel native formatter added.

Capture passes full-image identity/golden/quiet/Closed/exit/join/archive gates.
RAM traces archived/hash-verified persistently under lease before unmount; no users
remain;254/252MiB floors preserved. Three initial pre-worker staging failures remain:
insufficient conservative headroom, then an older root-owned archive failing the
UID check, then the same check with diagnostic detail. No trace or partial worker
was started. Final retirement only removes exact committed archived lokad-owned
replicas after full path/hash/link/all-alias proof. Local early retrieval was refused
before its75s observation bound; final terminal state is cached forever.

[All samples](attribution.json),[compiler facts](compiler-facts.json),
[complete image](identity.json),[raw capture](observations.tgz),
[procedures/original staging conditions](procedures-and-failed-staging.tar.xz).
The fully qualified binary/source proof is [R416](../2026-11-15-formatting-final-sink/delivery/README.md).
[CPython phase gap](../2026-11-15-format-cpython-checkpoint/README.md) is independent.
''',encoding='utf-8',newline='\n')
p=Path('benchmarks/EXPERIMENTS.md');s=p.read_text(encoding='utf-8');s+='\n\n[R417 complete method-format attribution](results/2026-11-15-method-format-attribution/README.md): qualifiedb06/8afb,1,052active samples/all unknowns retained. Repeated template/field construction selected for a reusable-layout design; no improvement/removable-share claim. B811quiet/goldens/cleanup pass, failed staging preserved. Native promotion/call transport remain debt.\n';p.write_text(s,encoding='utf-8',newline='\n')
p=Path('PLAN.md');s=p.read_text(encoding='utf-8');s=s.replace('**R417**, source/attribution only; no runtime edits/prototype.','**R417** attribution completed; **R418** reusable format layout design selected, no runtime edits yet.');a=s.index('**Next R417:');b=s.index('\n| Following milestone',a)
s=s[:a]+'''**R417 closed:** [complete report attribution](benchmarks/results/2026-11-15-method-format-attribution/README.md), B811all gates/cleanup.1,052active samples/161unknown leaves retained;476template/field,161call/argument,78frame/transport overlapping samples are not removable shares. Ordinary format promotes at member load; actual frequency uninstrumented. Repeated construction is selected before a speculative runner redesign.

**Next R418: reusable method-format layout.** Hypothesis: parsing the same UTF8
template/field/native specs and constructing metadata per record causes material
whole-report cost. Prepare immutable layout once on the existing execution-owned
bound method, funded through its existing scope; no cache in shared literal values,
new allowance, ledger, global cache or caller token retained. Replace the per-call
template/field parser with one layout executor for both format/map. Defer errors to
their original execution stage: earlier callbacks/lookups still run, native-invalid
specs still reach custom hooks. Preserve named/automatic/nested/Unicode semantics,
method identity, recursion, real suspension, cancellation/first refusal, retained
aliases/pending users and joined cleanup. Argument transport/native promotion remain
explicit debt rather than adding a second formatter/controller. Conservative retained
layout estimates may reject earlier and persist until execution cleanup.

Completion: displaced parser route removed, focused Release actual11/10 semantics/
cancellation/ownership and allocation diagnostics pass; one bounded warm/fresh complete
report source pair with f-string/CSV controls. Judge simplification/allocation/CPU
separately, refine when evidence justifies, decide regression debt; full delivery only
at retention. Stop with a retained coherent replacement or remove prototype with its
source/adverse evidence preserved. Broader roadmap remains active.
'''+s[b:];p.write_text(s,encoding='utf-8',newline='\n')
print('Preserved R417; PLAN selects coherent R418 with explicit ownership/semantics/displacement/measurement gate.')
