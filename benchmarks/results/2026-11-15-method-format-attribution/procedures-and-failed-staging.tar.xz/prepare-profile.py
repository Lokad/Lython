from pathlib import Path
import ast,hashlib,json,shutil
r=Path(__file__).parent;q=r/'profile';q.mkdir()
old=r.parent/'matched-calls-r414/profile';base=r.parent/'format-sinks-r416/checkpoint'
catalog=base/'retrieved/additional.json'
assert len(json.loads(catalog.read_text(encoding='utf-8'))['cases'])==1
shutil.copyfile(catalog,q/'catalog.json')
v=json.loads((base/'identity.json').read_text(encoding='utf-8'))
identity=dict(sourceRevision=v['sourceRevision'],runtimeCommit=v['runtimeCommit'],purpose='R417 one bounded complete method-format report CPU attribution; distinguish parsing, call transport and frame promotion, no speedup/removable-share claim.',coreSHA256=dict(candidate=v['coreSHA256']['candidate']),auxiliaryFiles=v['auxiliaryFiles'],catalogSHA256=hashlib.sha256(catalog.read_bytes()).hexdigest(),qualification='Fully qualified43765117358;594source inputs matchb06b8593',publicationHeld=True)
(q/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8',newline='\n')
for n in ['ops-profile.py','collect.py','run.sh','retrieve.py']:
 s=(old/n).read_text(encoding='utf-8').replace('matched-calls-b808-20261115','format-program-b811-20261115').replace('lython-b808-matched-calls-20261115','lython-b811-format-program-20261115').replace('B808','B811')
 s=s.replace("[('inline','scripts.helper-boundary.inline','warm'),('helper','scripts.helper-boundary.helper','warm')]","[('report','scripts.report-render.format-method.large','warm')]").replace("['inline','helper']","['report']")
 s=s.replace('count = 512 # Existing complete matched scripts; bounded warmed CPU attribution.','count = 128 # Complete report; ~0.7s batches, one bounded capture.')
 s=s.replace('Committed2865f619/frozen55ba4c8a; R414 matched helper/inline attribution','Qualifiedb06b8593/frozen8afb146e; R417 method-format report attribution')
 if n.endswith('.py'):ast.parse(s)
 (q/n).write_text(s,encoding='utf-8',newline='\n')
s=(r.parent/'matched-calls-r414/launch.py').read_text(encoding='utf-8')
s=s.replace("old=r.parent/'prepared-stores-r413'","old=r.parent/'prepared-stores-r413'")
a=s.index('retire=[]');b=s.index("c=dict(root=",a)
s=s[:a]+'''retire=[]
for name,canonical,member in [('format-cpython-b810-20261115/observations.tgz','benchmarks/results/2026-11-15-format-cpython-checkpoint/observations.tgz',None),('format-cpython-b810-20261115/confirmation/confirmation.json','benchmarks/results/2026-11-15-format-cpython-checkpoint/observations.tgz','confirmation/confirmation.json'),('invoice-attribution-b789-20261115/observations.tgz','benchmarks/results/2026-11-15-invoice-call-attribution/observations.tgz',None)]:
 raw=(repo/canonical).read_bytes();assert subprocess.check_output(['git','show',head+':'+canonical])==raw
 if member:
  with tarfile.open(fileobj=io.BytesIO(raw)) as t:raw=t.extractfile(member).read()
 retire.append(dict(path=name,bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest(),canonicalCommit=head,canonicalPath=canonical,member=member))
'''+s[b:]
s=s.replace("['identity.json','catalog.json','ops-profile.py','collect.py','run.sh']","['identity.json','ops-profile.py','collect.py','run.sh']")
s=s.replace('matched-calls-b808-20261115','format-program-b811-20261115').replace('lython-b808-matched-calls-20261115','lython-b811-format-program-20261115').replace('stores-cpython-b807-20261115','format-cpython-b810-20261115')
s=s.replace("assert sha(root/'catalog.json')==c['identity']['catalogSHA256']","os.link(source/'additional.json',root/'catalog.json');assert sha(root/'catalog.json')==c['identity']['catalogSHA256']")
ast.parse(s);(r/'launch-profile.py').write_text(s,encoding='utf-8',newline='\n')
print('Prepared single current-report attribution; unchanged worker,full-image verification and254/252MiB floors.')
