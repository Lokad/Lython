from pathlib import Path
import hashlib,json,os,shutil,subprocess
r=Path(__file__).parent;d=r/'facts-image';shutil.copytree(r.parent/'matched-calls-r414/local-facts',d)
core=r.parent/'format-sinks-r416/frozen/candidate/Lokad.Lython.dll';shutil.copyfile(core,d/'Lokad.Lython.dll');expected='8afb146e835dcd2692150026e4beb6566b2a483349b2a8b5c24b5e6eba58e6ed';assert hashlib.sha256(core.read_bytes()).hexdigest()==expected
hashes={p.name:hashlib.sha256(p.read_bytes()).hexdigest()for p in d.iterdir()if p.is_file()};env=dict(os.environ);env['DOTNET_ROOT']='C:/Users/JoannesVermorel/.dotnet11'
p=subprocess.run([env['DOTNET_ROOT']+'/dotnet.exe',str(d/'Inspect.dll'),str(r.parent/'format-sinks-r416/catalog.json'),str(r/'compiler-facts.json')],capture_output=True,text=True,encoding='utf-8',env=env,timeout=30);assert p.returncode==0,p.stderr;facts=json.loads((r/'compiler-facts.json').read_text(encoding='utf-8'));assert facts['coreSHA256']==expected
(r/'facts-image.json').write_text(json.dumps(hashes,indent=2)+'\n',encoding='utf-8',newline='\n');print([(x['id'],[(c['name'],c['native'],c['mirrors'],c['capacity'])for c in x['codes']])for x in facts['rows']])
