import json
import subprocess
import sys
from pathlib import Path

lab = Path(__file__).resolve().parent
previous = lab.parent / 'validator-native-roundtrip-r706'
stage = (previous / 'stage-quiet.py').read_text(encoding='utf-8')
stage = stage.replace('postfix-cpython-b1130', 'integer-transport-cpython-b1136')
stage = stage.replace('native-integer-transport-b1135', 'prepared-local-destination-b1138')
stage = stage.replace('lython-b1135-native-integer-transport', 'lython-b1138-prepared-local-destination')
stage = stage.replace('lython-b1135-fixtures', 'lython-b1138-fixtures')
stage = stage.replace('R706 direct short integer result and failure transport', 'R707 prepared local result destinations')
stage = stage.replace('Native integer transport source pair', 'Prepared local destination source pair')
stage = stage.replace('    shutil.copyfile(lab / "frozen" / role / core, image / core)',
                      '    if role == "candidate":\n        shutil.copyfile(lab / "frozen" / role / core, image / core)')
stage = stage.replace('"reference/" + core, "candidate/" + core', '"candidate/" + core')
stage = stage.replace('assert sha(quiet / "reference" / core) == images["reference"][core]',
                      'assert source_files[core] == images["reference"][core]')
start = stage.index('        jobs = [')
end = stage.index('\n', start)
catalog = json.loads((lab / 'catalog.json').read_text(encoding='utf-8'))
jobs = [(case['id'], 'warm') for case in catalog['cases']]
jobs.append(('scripts.annotated-rule-closures', 'compile-run'))
assert len(jobs) == 6
stage = stage[:start] + '        jobs = ' + repr(jobs) + stage[end:]
stage = stage.replace('len(jobs)==5', 'len(jobs)==6').replace("len(raw['jobs'])==5", "len(raw['jobs'])==6")
stage = stage.replace('jobs=5,', 'jobs=6,').replace("['jobs']==5", "['jobs']==6")
stage = stage.replace('.replace("==6","==5")', '')
stage = stage.replace('"295"', '"350"').replace('seconds=295', 'seconds=350')
stage = stage.replace('five-case, five-job', 'five-case, six-job')
proof = (previous / 'prove-quiet-space.py').read_text(encoding='utf-8')
start = proof.index('pairs = ')
end = proof.index('\n', start)
pairs = [('postfix-cpython-b1130', '2026-11-19-postfix-cpython-checkpoint', 'candidate', 'measured-core.dll.gz')]
proof = proof[:start] + 'pairs = ' + repr(pairs) + proof[end:]
for name, contents in [('prove-quiet-space.py', proof), ('stage-quiet.py', stage)]:
    (lab / name).write_text(contents, encoding='utf-8', newline='\n')
    subprocess.run([sys.executable, '-X', 'utf8', lab / name], check=True)
