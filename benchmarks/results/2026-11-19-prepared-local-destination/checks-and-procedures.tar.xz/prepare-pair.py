import json
import subprocess
import sys
from pathlib import Path

lab = Path(__file__).resolve().parent
previous = lab.parent / 'validator-native-roundtrip-r706'
load = lambda path: json.loads(path.read_text(encoding='utf-8-sig'))
catalog = load(lab.parent / 'current-rule-profile-b1137/catalog.json')
controls = ('scripts.csv-invoice.large', 'scripts.config-generated-guards.medium')
existing = load(previous / 'catalog.json')['cases']
for name in controls:
    case, = (case for case in existing if case['id'] == name)
    catalog['cases'].append(case)
assert len(catalog['cases']) == 5
(lab / 'catalog.json').write_text(json.dumps(catalog, indent=2, ensure_ascii=False) + '\n', encoding='utf-8', newline='\n')
source = (previous / 'freeze-and-verify.py').read_text(encoding='utf-8')
source = source.replace("previous=lab.parent/'postfix-cpython-b1130'", "previous=lab.parent/'integer-transport-cpython-b1136'")
source = source.replace('native-conversion-failure-r704', 'prepared-local-destination-r707')
source = source.replace("git('rev-parse','365335ea8')", "git('rev-parse','e20604ef4')")
source = source.replace('if name==core:\n            origin=lab/role/', 'if name==core and role=="candidate":\n            origin=lab/role/')
assert 'if name==core and role=="candidate"' in source
(lab / 'freeze-and-verify.py').write_text(source, encoding='utf-8', newline='\n')
subprocess.run([sys.executable, '-X', 'utf8', lab / 'freeze-and-verify.py'], check=True)
