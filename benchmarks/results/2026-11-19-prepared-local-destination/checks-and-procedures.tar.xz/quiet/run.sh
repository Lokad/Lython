set -eu
root=/home/lokad/lython-bench-checks/prepared-local-destination-b1138-20261119
trap 'result=$?; printf "%s\n" "$result" > "$root/exit-code.txt"' EXIT
python3 "$root/collect.py"
