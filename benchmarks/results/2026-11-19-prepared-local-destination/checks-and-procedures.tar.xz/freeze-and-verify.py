from pathlib import Path
import hashlib, json, os, shutil, statistics, subprocess

lab=Path(__file__).resolve().parent
repo=Path.cwd()
previous=lab.parent/'integer-transport-cpython-b1136'
old_selector=lab.parent/'native-format-selectors-r615'
trial=repo/'.git/agent-worktrees/prepared-local-destination-r707'
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda b:hashlib.sha256(b).hexdigest()
write=lambda p,d:p.write_text(json.dumps(d,indent=2,ensure_ascii=False)+'\n',encoding='utf-8',newline='\n')
git=lambda *args:subprocess.check_output(['git',*args])
ref=git('rev-parse','e20604ef4').decode().strip()
can=git('-C',str(trial),'rev-parse','HEAD').decode().strip()
manifest=load(previous/'identity.json')
assert not git('diff','--name-only',manifest['sourceRevision'],ref,'--',
    'benchmarks/Lokad.Lython.Benchmarks','benchmarks/cpython-worker.py','src/Lokad.Lython.Utf8Regex')
assert git('merge-base',ref,can).decode().strip()==ref
assert not git('-C',str(trial),'status','--porcelain')
assert not git('diff','--name-only',ref,can,'--','benchmarks/Lokad.Lython.Benchmarks','benchmarks/cpython-worker.py','src/Lokad.Lython.Utf8Regex')
(lab/'measured-source.patch').write_bytes(git('diff','--binary',ref,can,'--','src','tests'))
catalog_path=lab/'catalog.json'
assert len(load(catalog_path)["cases"]) == 5
python=Path('C:/Python313/python.exe')
sdk=Path.home()/'.dotnet11'
dotnet=sdk/'dotnet.exe'
env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk),PATH=str(sdk)+os.pathsep+os.environ['PATH'])
source=previous/'frozen/candidate'
files=manifest['imageFiles']['candidate']
core='Lokad.Lython.dll'
assert len(files)==32 and {name:sha((source/name).read_bytes()) for name in files}==files
images={}
for role in ('reference','candidate'):
    image=lab/'frozen'/role
    image.mkdir(parents=True,exist_ok=True)
    expected=files.copy()
    for name in files:
        origin=source/name
        if name==core and role=="candidate":
            origin=lab/role/'bin/Lokad.Lython/release_net11.0'/name
            expected[name]=sha(origin.read_bytes())
        if not (image/name).exists():shutil.copyfile(origin,image/name)
    for extra in (old_selector/'frozen/candidate').glob('ValidatedAllocation.*'):
        if not (image/extra.name).exists():shutil.copyfile(extra,image/extra.name)
    if role=='candidate':assert expected[core]!=files[core]
    assert {name:sha((image/name).read_bytes()) for name in files}==expected
    with (lab/(role+'-verify.log')).open('wb') as log:
        subprocess.run([dotnet,image/'Lokad.Lython.Benchmarks.dll','--compare','verify','--catalog',catalog_path,
            '--dotnet',dotnet,'--python',python,'--python-worker',repo/'benchmarks/cpython-worker.py',
            '--out',lab/(role+'-verify.json')],env=env,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=120)
    verified=load(lab/(role+'-verify.json'))
    assert verified['state']=='Completed' and verified['catalogSha256']==sha(catalog_path.read_bytes())
    with (lab/(role+'-allocation.log')).open('wb') as log:
        subprocess.run([dotnet,image/'ValidatedAllocation.dll',image,catalog_path,lab/(role+'-allocation.json')],
            env=env,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=120)
    assert {name:sha((image/name).read_bytes()) for name in files}==expected
    images[role]=expected
write(lab/'frozen-identity.json',dict(referenceCommit=ref,candidateCommit=can,casesSHA256=sha(catalog_path.read_bytes()),images=images))
for left,right in zip(*[load(lab/(role+'-allocation.json'))['rows'] for role in ('reference','candidate')],strict=True):
    assert left['id']==right['id'] and left['sharedBudgetBaselineRestored'] and right['sharedBudgetBaselineRestored']
    a,b=[statistics.median(r['allocatedBytesPerInvocation']) for r in (left,right)]
    print(left['id'],f'{a:,} to {b:,}',f'{100*(b/a-1):+.2f}%',left['peakExecutionMemoryBytes'],right['peakExecutionMemoryBytes'],flush=True)
print('Both complete images and all five cases verified against CPython.')



assert images['reference'][core] != images['candidate'][core]
