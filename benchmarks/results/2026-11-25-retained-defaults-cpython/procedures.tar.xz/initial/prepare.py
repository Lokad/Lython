from pathlib import Path
import hashlib,json,os,shutil,subprocess,tarfile

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
baseline=lab.with_name('shared-locals-cpython-20261125')
shared=lab.with_name('tagged-default-ownership-20261125')
callback=lab.with_name('shared-locals-cpython-20261125')
quiet=lab/'external'
quiet.mkdir(exist_ok=True)
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
write=lambda p,s:p.write_text(s,encoding='utf-8',newline='\n')
save=lambda p,d:write(p,json.dumps(d,ensure_ascii=False,indent=2)+'\n')
git=lambda args:subprocess.check_output(['git',*args],cwd=repo,text=True).strip()
source=git(['rev-parse','c1984f96b'])
assert not git(['diff','--name-only',source,'--','src','Directory.Build.props','Directory.Build.targets','Directory.Packages.props','global.json'])
assert not git(['status','--short','--','src','benchmarks/Lokad.Lython.Benchmarks','benchmarks/cpython-worker.py','Directory.Build.props','Directory.Build.targets','Directory.Packages.props','global.json'])
assert not git(['diff','--name-only','ac9f9211b',source,'--','benchmarks/Lokad.Lython.Benchmarks','benchmarks/cpython-worker.py',
    'src/Lokad.Lython.Utf8Regex','Directory.Build.props','Directory.Build.targets','Directory.Packages.props','global.json'])
old=read(lab.with_name('ordinary-defaults-cpython-20261125')/'external/identity.json')
donor=read(shared/'comparison/quiet/identity.json')
image=lab/'candidate'
image.mkdir(exist_ok=True)
files=donor['imageFiles']['candidate']
assert len(files)==32 and old['auxiliaryFiles']=={n:v for n,v in files.items() if n!='Lokad.Lython.dll'}
patch=subprocess.check_output(['git','diff','--binary',donor['sourceRevision'],source,'--','src'],cwd=repo)
assert patch==(shared/'candidate.patch').read_bytes() and hashlib.sha256(patch).hexdigest()==donor['sourcePatchSHA256']
for name,digest in files.items():
    assert sha(shared/'candidate'/name)==digest
    shutil.copyfile(shared/'candidate'/name,image/name)
assert {p.name:sha(p) for p in image.iterdir()}==files
core=image/'Lokad.Lython.dll'
location='retained-defaults-cpython-b1685-20261125'
identity=dict(sourceRevision=source,candidate=source,productionSource=source,
    imageFiles={'candidate':files},frozenImage='/home/lokad/lython-bench-checks/'+location+'/candidate',
    auxiliaryFiles=old['auxiliaryFiles'],coreSHA256=dict(candidate=sha(core),**{'candidate-control':sha(core)}),
    expectedCPythonSHA256=old['expectedCPythonSHA256'],cpythonWorkerSHA256=old['cpythonWorkerSHA256'],
    auxiliaryImageReference='B1682',productionBuild='B1682 nonincremental Release core; measured patch matches c1984f96b exactly',
    sourcePatchSHA256=donor['sourcePatchSHA256'], sourcePatchBase=donor['sourceRevision'])

plain='diagnostic.generated-ordinary-definitions'
rule='scripts.rule-default-closures'
shipment='diagnostic.shipment-routing-callbacks'
invoice='scripts.csv-invoice.method-policy.quoted-control'
eager='scripts.annotated-rule-closures'
post='scripts.annotated-rule-closures.nested-factories.postponed'
catalog=read(shared/'comparison/quiet/representative.json')
cases={r['id']:r for r in catalog['cases']}
catalog['cases']=[cases[k] for k in (plain,rule,shipment,invoice,eager,post)]
catalog['fixtureEncoding']='Canonical base64 file maps for shipment and invoice. Generated definitions and rule pairs have no files.'
jobs=[(plain,'warm'),(rule,'compile'),(eager,'warm'),(shipment,'warm'),(plain,'compile-run'),(rule,'warm'),
      (plain,'compile'),(invoice,'warm'),(rule,'compile-run'),(post,'warm'),(shipment,'compile-run')]
save(quiet/'representative.json',catalog)
save(quiet/'jobs.json',jobs)
identity['catalogs']={n:dict(sha256=sha(quiet/n)) for n in ('representative.json','jobs.json')}
save(quiet/'identity.json',identity)
protocol=repo/'benchmarks/cpython-worker.py'
assert sha(protocol)==identity['cpythonWorkerSHA256']
sdk=Path.home()/'.dotnet11'
env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk))
dotnet=sdk/'dotnet.exe'
proof=quiet/'candidate-verify.json'
subprocess.run([dotnet,image/'Lokad.Lython.Benchmarks.dll','--compare','verify','--catalog',quiet/'representative.json',
    '--dotnet',dotnet,'--python','C:/Python313/python.exe','--python-worker',protocol,'--out',proof],env=env,cwd=repo,
    check=True,timeout=80)
checked=read(proof)
assert checked['state']=='Completed' and checked['caseCount']==6 and checked['catalogSha256']==identity['catalogs']['representative.json']['sha256']
assert checked['launched']['library']['sha256']==identity['coreSHA256']['candidate']
assert {p.name:sha(p) for p in image.iterdir()}==files
shutil.copyfile(baseline/'external/run.sh',quiet/'run.sh')
assert b'\r' not in (quiet/'run.sh').read_bytes()
collector=(baseline/'external/collect.py').read_text(encoding='utf-8').replace('b1663-fixtures','b1685-fixtures')
collector=collector.replace('len(jobs) == 9','len(jobs) == 11').replace('* .28','* .46').replace('*.28','*.46')
collector=collector.replace("<308,'Leave time", "<476,'Leave time")
collector=collector.replace('CPython checkpoint for lazy default tuples and consolidated compilation',
    'Current CPython checkpoint after shared map operands and callable default ownership')
compile(collector,'collect.py','exec')
write(quiet/'collect.py',collector)
summary=(baseline/'external/summarize.py').read_text(encoding='utf-8').replace('len(raw["jobs"])==9','len(raw["jobs"])==11').replace('receipt["warmJobs"]==9','receipt["warmJobs"]==11')
compile(summary,'summarize.py','exec')
write(quiet/'summarize.py',summary)
payload=quiet/'payload.tar.gz'
with tarfile.open(payload,'w:gz',compresslevel=3) as bundle:
    for name in ('identity.json','jobs.json','representative.json','collect.py','run.sh'):
        bundle.add(quiet/name,arcname=name)
assert sha(core)==files[core.name]
save(quiet/'upload.json',dict(root=location,reference='tagged-default-ownership-b1682-20261125',
    payloadSHA256=sha(payload),payloadBytes=payload.stat().st_size))
save(lab/'verified-raw-replicas.json',[])
previous=read(shared/'comparison/quiet/terminal-status.json')['receipt']
assert previous['complete'] and previous['allWorkersJoined'] and sha(shared/'comparison/quiet/observations.tar.xz')==previous['archiveSHA256']
previous_lab=lab.with_name('ordinary-defaults-cpython-20261125')
launcher=(previous_lab/'quiet.py').read_text(encoding='utf-8').replace('b1677','b1685')
launcher=launcher.replace('lython-b1685-ordinary-defaults-cpython-20261125','lython-b1685-retained-defaults-cpython-20261125')
launcher=launcher.replace('ca73cdc2a5871f0e182398fd220fe54fcf48c17349e50fdedd4c7a93373bd627',previous['archiveSHA256'])
launcher=launcher.replace(",'candidate-core.dll'",'').replace("  if name=='Lokad.Lython.dll': (root/'candidate-core.dll').rename(image/name)\n  else: os.link(reference/'candidate'/name,image/name)","  os.link(reference/'candidate'/name,image/name)")
launcher=launcher.replace('seconds=291','seconds=390').replace('RuntimeMaxSec=385','RuntimeMaxSec=480')
assert 'candidate-core.dll' not in launcher and previous['archiveSHA256'] in launcher
compile(launcher,'quiet.py','exec')
write(lab/'quiet.py',launcher)
print('Verified the retained image on six goldens and prepared eleven independent phase lanes.')
