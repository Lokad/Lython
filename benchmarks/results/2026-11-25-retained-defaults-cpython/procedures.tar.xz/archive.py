from pathlib import Path
import hashlib,json,shutil,tarfile

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
quiet=lab/'external'
out=repo/'benchmarks/results/2026-11-25-retained-defaults-cpython'
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
terminal=read(quiet/'terminal-status.json')
receipt=terminal['receipt']
assert not terminal['live'] and not terminal['fixtures'] and terminal['exitCode']=='0'
assert receipt['warmJobs']==11 and all(receipt[k] for k in ('complete','allWorkersJoined','guestFixturesRemoved',
    'quietBeforeAndAfter','archivedAndVerifiedUnderLease'))
assert sha(quiet/'observations.tar.xz')==receipt['archiveSHA256']
identity=read(quiet/'identity.json')
summary=read(quiet/'summary.json')
assert identity['productionSource']==identity['sourceRevision']==summary['source']
assert summary['timedBatches']==308 and summary['cpythonExecutableSHA256']==identity['expectedCPythonSHA256']
assert [(v['case'],v['lane']) for v in summary['rows']]==list(map(tuple,read(quiet/'jobs.json')))
assert len(identity['imageFiles']['candidate'])==32 and {p.name:sha(p) for p in (lab.with_name('retained-defaults-cpython-20261125')/'candidate').iterdir()}==identity['imageFiles']['candidate']
with tarfile.open(quiet/'observations.tar.xz') as archive:
    for when in ('before','after'):
        assert json.load(archive.extractfile(f'confirmation/machine-{when}.json'))['gate']['quiet']
out.mkdir(exist_ok=True)
for name in ('identity.json','summary.json','terminal-status.json','observations.tar.xz'):
    shutil.copyfile(quiet/name,out/name)
initial=lab.with_name('retained-defaults-cpython-20261125')
failed=read(initial/'external/failure-status.json')
assert failed['exitCode']=='1' and not failed['startedTiming'] and not failed['workerFixturesPresent']
for n, expected in failed['files'].items():assert sha(initial/'external'/n)==expected
for n in ('representative.json','jobs.json'):
    assert (initial/'external'/n).read_bytes()==(quiet/n).read_bytes()
assert read(initial/'external/identity.json')['imageFiles']==identity['imageFiles']
shutil.copyfile(initial/'external/failure-status.json',out/'initial-failure.json')
members={n:lab/n for n in ['quiet.py','archive.py','render.py','external/launch.log','external/retrieve.log','external/candidate-verify.json',
    'external/collect.py','external/summarize.py','external/run.sh','external/storage-custody.json','external/upload.json']}
for n in ('prepare.py','quiet.py','external/launch.log','external/collect.py','external/summarize.py','external/identity.json','external/jobs.json','external/representative.json','external/run.sh','external/failure-status.json'):
    members['initial/'+n]=initial/n
with tarfile.open(out/'procedures.tar.xz','w:xz') as archive:
    for n,path in members.items():archive.add(path,arcname=n,recursive=False)
with tarfile.open(out/'procedures.tar.xz') as archive:
    assert all(archive.extractfile(n).read()==path.read_bytes() for n,path in members.items())
