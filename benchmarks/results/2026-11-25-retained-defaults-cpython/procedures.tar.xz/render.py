from pathlib import Path
import json

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
results = repo / "benchmarks/results/2026-11-25-retained-defaults-cpython"
summary = json.loads((results / "summary.json").read_text(encoding="utf-8"))
assert summary["source"].startswith("c1984f96b") and summary["timedBatches"] == 308
shapes = {
    "Generated ordinary definitions": "diagnostic.generated-ordinary-definitions",
    "Generated rules with defaults": "scripts.rule-default-closures",
    "Shipment callback report": "diagnostic.shipment-routing-callbacks",
    "Quote-heavy CSV policy invoice": "scripts.csv-invoice.method-policy.quoted-control",
    "Eager annotated rules": "scripts.annotated-rule-closures",
    "Postponed nested annotated rules": "scripts.annotated-rule-closures.nested-factories.postponed",
}
rows = {(row["case"], row["lane"]): row for row in summary["rows"]}
phases = {"Compilation only": "compile", "Compile-to-result": "compile-run"}

def interval(values, digits):
    return "–".join(f"{value:.{digits}f}" for value in values)

def format_values(row):
    lython = interval(row["lythonMs"], 5) + " ms"
    python = interval(row["cpythonMs"], 5) + " ms"
    ratio = interval(row["ratio"], 3) + "×"
    return [lython, python, ratio]

def status(row):
    spread = max(row["lythonControlPercent"], row["cpythonControlPercent"])
    note = "Diagnostic."
    if row["ratio"][0] <= 1 <= row["ratio"][1]: note += " Ratio spans parity."
    if spread >= 3: note += f" Worker spread up to {spread:.2f}%."
    return note + " [B1685]."

path = repo / "docs/BENCHMARKS.md"
text = path.read_text(encoding="utf-8")
assert "[B1685]" not in text
updated = []
out = []
for line in text.splitlines():
    if line.startswith("| "):
        fields = [value.strip() for value in line.strip("|").split("|")]
        if len(fields) == 6:
            name = fields[0].split(", ")[0]
            pair = (shapes.get(name), phases.get(fields[1], "warm"))
            if pair in rows:
                row = rows[pair]
                line = "| " + " | ".join(fields[:2] + format_values(row) + [status(row)]) + " |"
                updated.append(pair)
    out.append(line)
assert set(updated) == set(rows) and len(updated) == 11, updated
text = "\n".join(out) + "\n"
start = text.index("two workers per engine. B1677 measures")
end = text.index("\n\nThe quiet comparison machine", start)
text = text[:start] + """two workers per engine. B1685 measures retained runtime `c1984f96b` on
November 25, 2026 UTC for the marked definition, shipment and invoice
phases. Other rows retain their original revisions. B1669 measures the
manifest at `a45b6da7f`. B1656 measures the short report and classifier
at `6b41db7b3`. Comprehension compilation uses `b9b20aa98`. Earlier
standalone eager and captured rule phases use `d6a168491`. The earlier
short report and invoice compile-only and invoice time-to-result phases
use `6466fbb52`. The earlier manifest compile-only and sparse validator
use `0bf516c79`. Postponed compilation and time to result use `5313f9e71`.
JSON export uses `2cf721f73`, and the CSV meters use `8aef89b09`.
[B1685] · [B1677] · [B1669] · [B1656] · [B1643] · [B1633] · [B1625] · [B1614] · [B1593] · [B1587] · [B1568].""" + text[end:]
text += "[B1685]: ../benchmarks/results/2026-11-25-retained-defaults-cpython/README.md\n"
path.write_text(text, encoding="utf-8", newline="\n")
