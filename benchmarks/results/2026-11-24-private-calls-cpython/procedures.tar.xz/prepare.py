from pathlib import Path
import ast
import hashlib
import json
import os
import shutil
import subprocess

lab = Path(__file__).resolve().parent
root = lab.parents[3]
donor = lab.with_name('private-call-isolation-20261124')
template = lab.with_name('closed-pairs-cpython-20261124')
out = lab/'external'
out.mkdir(exist_ok=True)
read = lambda p: json.loads(p.read_text(encoding='utf-8'))
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
write = lambda path, content: path.write_text(content, encoding='utf-8', newline='\n')
save = lambda path, data: write(path, json.dumps(data, indent=2, ensure_ascii=False) + '\n')
meta = read(donor/'comparison/identity.json')
quiet = donor/'comparison/quiet'
receipt = read(quiet/'terminal-status.json')['receipt']
assert receipt['complete'] and receipt['archivedAndVerifiedUnderLease']
assert sha(quiet/'observations.tar.xz') == receipt['archiveSHA256']
source = subprocess.check_output(['git','rev-parse','c40540135'],cwd=root,text=True).strip()
subprocess.run(['git','diff','--exit-code',meta['candidate'],source,'--','src','tests'],cwd=root,check=True)
files = meta['imageFiles']['candidate']
assert len(files) == 32
frozen = lab/'candidate'
frozen.mkdir(exist_ok=True)
for name in files:
    shutil.copyfile(donor/'candidate'/name, frozen/name)
assert {p.name:sha(p) for p in frozen.iterdir()} == files
location = 'private-calls-cpython-b1600-20261124'
original = 'private-call-isolation-b1599-20261124'
identity = dict(sourceRevision=meta['candidate'],candidate=meta['candidate'],productionSource=source,
    imageFiles={'candidate':files},frozenImage='/home/lokad/lython-bench-checks/'+location+'/candidate',
    auxiliaryFiles={n:h for n,h in files.items() if n!='Lokad.Lython.dll'},
    coreSHA256={k:meta['coreSHA256'][k] for k in ('candidate','candidate-control')},
    expectedCPythonSHA256=meta['expectedCPythonSHA256'],cpythonWorkerSHA256=meta['cpythonWorkerSHA256'])
catalog = read(donor/'comparison/representative.json')
ids = ('scripts.captured-rule-closures', 'scripts.annotated-rule-closures.nested-factories.postponed',
       'scripts.csv-invoice.method-policy.quoted-control')
catalog['cases'] = [next(c for c in catalog['cases'] if c['id']==key) for key in ids]
save(out/'representative.json',catalog)
jobs = [(case,'warm') for case in ids] + [(ids[0],lane) for lane in ('compile','compile-run')]
save(out/'jobs.json',jobs)
identity['catalogs'] = {name:{'sha256':sha(out/name)} for name in ('representative.json','jobs.json')}
save(out/'identity.json',identity)
sdk = Path.home()/'.dotnet11'
dotnet = sdk/'dotnet.exe'
env = dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk),PATH=str(sdk)+os.pathsep+os.environ['PATH'])
protocol = root/'benchmarks/cpython-worker.py'
assert sha(protocol) == identity['cpythonWorkerSHA256']
subprocess.run([dotnet,frozen/'Lokad.Lython.Benchmarks.dll','--compare','verify','--catalog',out/'representative.json',
    '--dotnet',dotnet,'--python','C:/Python313/python.exe','--python-worker',protocol,'--out',out/'candidate-verify.json'],
    env=env,cwd=root,check=True,timeout=85)
check = read(out/'candidate-verify.json')
assert check['state']=='Completed' and check['caseCount']==len(ids)
assert check['launched']['library']['sha256']==identity['coreSHA256']['candidate']
assert check['catalogSha256']==sha(out/'representative.json')
shutil.copyfile(template/'external/run.sh',out/'run.sh')
assert b'\r' not in (out/'run.sh').read_bytes()
for filename in ('collect.py','summarize.py'):
    content=(template/'external'/filename).read_text(encoding='utf-8')
    content=content.replace('b1597-','b1600-').replace('len(jobs) == 7','len(jobs) == 5').replace('started<392','started<278')
    content=content.replace('len(raw["jobs"])==7 and receipt["warmJobs"]==7','len(raw["jobs"])==5 and receipt["warmJobs"]==5')
    content=content.replace('CPython checkpoint for the delivered closed pairs and captured-rule debt','CPython checkpoint for the delivered private calls and two affected controls')
    compile(content,filename,'exec')
    write(out/filename,content)
launcher=(template/'external-before-space-recovery.py').read_text(encoding='utf-8')
launcher=launcher.replace('closed-factory-pairs-entry-20261124/comparison/quiet','private-call-isolation-20261124/comparison/quiet')
launcher=launcher.replace('closed-factory-pairs-entry-b1596-20261124',original).replace('closed-pairs-cpython-b1597-20261124',location)
launcher=launcher.replace('lython-b1597-closed-pairs-cpython','lython-b1600-private-calls-cpython')
launcher=launcher.replace('RuntimeMaxSec=460','RuntimeMaxSec=330').replace('seconds=405','seconds=303')
remote,=(item.value for item in ast.walk(ast.parse(launcher)) if isinstance(item,ast.Constant) and isinstance(item.value,str) and 'staged=sum' in item.value)
compile(remote,'remote-stage','exec')
assert 'duplicate.unlink' not in remote
write(lab/'external.py',launcher)
archiver=(template/'archive.py').read_text(encoding='utf-8')
archiver=archiver.replace('benchmarks/results/2026-11-24-closed-pairs-cpython','benchmarks/results/2026-11-24-private-calls-cpython')
archiver=archiver.replace('==7 and sha','==5 and sha').replace("'70b04c0af'","'c40540135'").replace('==196','==140')
archiver=archiver.replace(",'recover-space.py','recover-raw.py','external-before-space-recovery.py','external-before-raw-recovery.py'",'')
archiver=archiver.replace('B1597 with 196','B1600 with 140')
assert 'benchmarks/results/2026-11-24-private-calls-cpython' in archiver and 'recover-space.py' not in archiver
compile(archiver,'archive.py','exec')
write(lab/'archive.py',archiver)
print('Prepared five short lanes on the delivered c40540135 runtime and three verified goldens.')
