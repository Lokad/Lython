from pathlib import Path
import hashlib
import json
import shutil
import tarfile

lab=Path(__file__).resolve().parent
root=lab.parents[3]
external=lab/'external'
out=root/'benchmarks/results/2026-11-24-private-calls-cpython'
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
terminal=read(external/'terminal-status.json')
receipt=terminal['receipt']
assert not terminal['live'] and not terminal['fixtures'] and terminal['exitCode']=='0'
assert all(receipt[k] for k in ('complete','allWorkersJoined','guestFixturesRemoved','quietBeforeAndAfter','archivedAndVerifiedUnderLease'))
assert receipt['warmJobs']==5 and sha(external/'observations.tar.xz')==receipt['archiveSHA256']
identity=read(external/'identity.json')
summary=read(external/'summary.json')
assert identity['productionSource'].startswith('c40540135') and identity['candidate']==summary['source']
assert summary['timedBatches']==140 and summary['cpythonExecutableSHA256']==identity['expectedCPythonSHA256']
assert [(row['case'],row['lane']) for row in summary['rows']]==[tuple(job) for job in read(external/'jobs.json')]
verification=read(external/'candidate-verify.json')
assert verification['state']=='Completed' and verification['caseCount']==3
assert verification['catalogSha256']==identity['catalogs']['representative.json']['sha256']
assert verification['launched']['library']['sha256']==identity['coreSHA256']['candidate']
assert len(identity['imageFiles']['candidate'])==32
assert {p.name:sha(p) for p in (lab/'candidate').iterdir()}==identity['imageFiles']['candidate']
out.mkdir(exist_ok=True)
for item in ('identity.json','summary.json','terminal-status.json','observations.tar.xz'):
    shutil.copyfile(external/item,out/item)
procedures=('prepare.py','external.py','archive.py','external/collect.py','external/summarize.py',
            'external/launch.log','external/candidate-verify.json','external/run.sh')
with tarfile.open(out/'procedures.tar.xz','w:xz') as archive:
    for item in procedures:archive.add(lab/item,arcname=item)
with tarfile.open(out/'procedures.tar.xz') as archive:
    assert all(hashlib.sha256(archive.extractfile(item).read()).hexdigest()==sha(lab/item) for item in procedures)
print('Archived B1600 with 140 attested batches and the exact frozen image')
