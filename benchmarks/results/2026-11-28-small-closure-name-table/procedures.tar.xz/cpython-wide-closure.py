def outer():
    a, b, c, d, e, f = 1, 2, 3, 4, 5, 6
    def middle():
        def update():
            nonlocal e
            before = (f, e, d, c, b, a)
            e += 100
            return before, e
        def clear():
            nonlocal e
            del e
        return update, clear
    return middle()
update, clear = outer()
print(update())
print(update())
clear()
try:
    update()
except NameError:
    print('unbound')
