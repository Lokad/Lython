from pathlib import Path
import hashlib
import json
import shutil
import tarfile

lab = Path(__file__).resolve().parent
confirmed = lab / "readiness-confirmation"
dest = lab.parents[3] / "benchmarks/results/2026-11-23-retained-factory-cpu"
read = lambda p: json.loads(p.read_text(encoding="utf-8-sig"))
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
terminal = read(confirmed / "terminal-status.json")
assert terminal["exitCode"] == "0" and terminal["receipt"]["archivedAndVerifiedUnderLease"]
assert terminal["receipt"]["allWorkersJoined"] and terminal["receipt"]["guestFixturesRemoved"]
assert sha(confirmed / "observations.tar.xz") == terminal["receipt"]["archiveSHA256"]
failure = read(lab / "failure-recovery.json")
assert failure["originalExitCode"] == 1 and failure["archivedAndVerifiedUnderRecoveryLease"]
assert sha(lab / "original-failed-observations.tar.xz") == failure["sha256"]
identity = read(lab / "identity.json")
image = lab.parent / "ordered-locals-snapshots-20261123/candidate"
assert len(identity["imageFiles"]["candidate"]) == 32
assert all(sha(image/name) == digest for name,digest in identity["imageFiles"]["candidate"].items())
assert len(read(confirmed / "attribution.json")["rows"]) == 4
dest.mkdir(exist_ok=True)
for name in ("terminal-status.json","attribution.json","observations.tar.xz"):
    shutil.copyfile(confirmed / name, dest / name)
for name in ("identity.json","failure-recovery.json","original-partial-attribution.json","original-failed-observations.tar.xz"):
    shutil.copyfile(lab / name, dest / name)
with tarfile.open(dest / "procedures.tar.xz","w:xz") as out:
    for owner in (lab, confirmed):
        for file in sorted(owner.iterdir()):
            if file.is_file() and file.suffix in (".py",".sh",".json",".log") and file.name not in (
                    "attribution.json","terminal-status.json","identity.json","original-partial-attribution.json","failure-recovery.json"):
                out.add(file, arcname=file.relative_to(lab).as_posix(), recursive=False)
print(dest)
