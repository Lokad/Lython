from pathlib import Path
import hashlib, json, shlex, subprocess

lab = Path(".git/agent-notes/review-20261031/retained-factory-cpu-20261123")
host = "lokad@20.166.121.73"
root = "/home/lokad/lython-bench-checks/retained-factory-cpu-b1469-20261123"
ssh_options = ["-i", str(Path.home()/".ssh/id_lython-bench.pem"), "-o", "BatchMode=yes", "-o", "ConnectTimeout=14"]
ssh = ["C:/Windows/System32/OpenSSH/ssh.exe", *ssh_options, host]
scp = ["C:/Windows/System32/OpenSSH/scp.exe", *ssh_options]
recovery = r"""
from pathlib import Path
import fcntl, hashlib, json, os, stat, subprocess, tarfile
root = Path('/home/lokad/lython-bench-checks/retained-factory-cpu-b1469-20261123')
unit = 'lython-b1469-retained-factory-cpu-20261123.service'
fixtures = root / 'guest-fixtures'
archive = root / 'original-failed-observations.tar.xz'
digest = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
with (root.parent/'comparison-vm.lock').open('a') as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 state = subprocess.check_output(['systemctl','show',unit,'--property=MainPID,ActiveState,Result'])
 assert b'MainPID=0' in state and b'ActiveState=failed' in state
 assert (root/'exit-code.txt').read_text().strip() == '1'
 assert subprocess.run(['pgrep','-af','[d]otnet.*--compare worker.*'+str(root)+'|[p]erf record.*'+str(root)],capture_output=True).returncode == 1
 assert subprocess.check_output(['findmnt','--mountpoint',fixtures,'--noheadings','--output','SOURCE']).strip() == b'b1469-fixtures'
 assert os.stat(fixtures).st_dev != os.stat(root).st_dev
 (root/'failure-journal.txt').write_bytes(subprocess.check_output(['journalctl','-u',unit,'--no-pager']))
 inventory = []
 for entry in sorted(fixtures.iterdir()):
  status = entry.lstat()
  assert stat.S_ISFIFO(status.st_mode) or stat.S_ISSOCK(status.st_mode)
  assert entry.name.startswith(('clr-debug-pipe-', 'dotnet-diagnostic-'))
  inventory.append(dict(name=entry.name, mode=stat.filemode(status.st_mode), uid=status.st_uid))
 (root/'failure-fixture-inventory.json').write_text(json.dumps(inventory,indent=2)+'\n')
 expected = {p.relative_to(root).as_posix():digest(p) for p in root.rglob('*')
             if stat.S_ISREG(p.lstat().st_mode) and p != archive}
 with tarfile.open(archive,'w:xz') as frozen:
  for name in sorted(expected): frozen.add(root/name,arcname=name,recursive=False)
 with tarfile.open(archive) as frozen:
  assert {m.name:hashlib.sha256(frozen.extractfile(m).read()).hexdigest()
          for m in frozen if m.isfile()} == expected
 subprocess.run(['sudo','-n','umount',fixtures],check=True)
 assert not list(fixtures.iterdir())
 fixtures.rmdir()
 print(json.dumps(dict(archivedAndVerifiedUnderRecoveryLease=True, sha256=digest(archive),
   storedRegularFiles=len(expected), workersJoined=True, fixtureRemoved=True,
   originalExitCode=1, originalFixtureInventory=inventory)))
"""
receipt = subprocess.check_output(ssh+["python3 -c "+shlex.quote(recovery)], timeout=35)
report = json.loads(receipt)
(lab/"failure-recovery.json").write_bytes(receipt)
archive = lab/"original-failed-observations.tar.xz"
subprocess.run(scp+[host+":"+root+"/"+archive.name,archive], check=True, timeout=35)
assert hashlib.sha256(archive.read_bytes()).hexdigest() == report["sha256"]
print(receipt.decode(), end="")
