from pathlib import Path
import hashlib
import gzip
import json
import os
import subprocess
import tarfile

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
reference = lab.with_name('combined-cased-split-cpython-20261123')
original = reference / 'comparison/quiet'
quiet = lab / 'comparison/quiet'
quiet.mkdir(parents=True, exist_ok=True)
name = 'current-csv-cpython-b1543-20261124'
digest = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
read = lambda path: json.loads(path.read_text(encoding='utf-8-sig'))


def save(file, value):
    (quiet / file).write_text(json.dumps(value, indent=2, ensure_ascii=False) + '\n', encoding='utf-8', newline='\n')


identity = read(original / 'identity.json')
assert identity['sourceRevision'] == identity['candidate'] and identity['candidate'].startswith('43688c753')
image = reference / 'candidate'
files = identity['imageFiles']['candidate']
assert len(files) == 32 and all(digest(image / name) == sha for name, sha in files.items())
receipt = read(original / 'terminal-status.json')['receipt']
assert receipt['complete'] and digest(original / 'observations.tar.xz') == receipt['archiveSHA256']
protocol = repo / 'benchmarks/cpython-worker.py'
assert digest(protocol) == identity['cpythonWorkerSHA256']

catalog = read(lab.with_name('short-csv-utf8-cpython-20261123') / 'comparison/quiet/representative.json')
explicit, = catalog['cases']
typed = next(case for case in read(lab.with_name('strict-short-float-20261123') / 'comparison/representative.json')['cases']
    if case['id'] == 'scripts.csv-meter-report.typed-unicode')
assert explicit['id'] == 'scripts.csv-meter-report.explicit-float'
catalog['cases'] = [explicit, typed]
save('representative.json', catalog)
save('jobs.json', [[explicit['id'], lane] for lane in ('warm', 'compile-run', 'compile')] + [[typed['id'], 'warm']])
identity['catalogs'] = {name: dict(sha256=digest(quiet / name)) for name in ('representative.json', 'jobs.json')}
save('identity.json', identity)

dotnet = Path.home() / '.dotnet11/dotnet.exe'
env = dict(os.environ, DOTNET_ROOT=str(dotnet.parent), DOTNET_ROOT_X64=str(dotnet.parent))
verified = quiet / 'candidate-verify.json'
subprocess.run([dotnet, image / 'Lokad.Lython.Benchmarks.dll', '--compare', 'verify', '--catalog', quiet / 'representative.json',
    '--dotnet', dotnet, '--python', 'C:/Python313/python.exe', '--python-worker', protocol, '--out', verified],
    check=True, env=env, timeout=75)
observed = read(verified)
assert observed['state'] == 'Completed' and observed['caseCount'] == 2
assert observed['launched']['library']['sha256'] == files['Lokad.Lython.dll']

collector = (original / 'collect.py').read_text(encoding='utf-8').replace('lython-b1539-fixtures', 'lython-b1543-fixtures').replace(
    'CPython checkpoint after isolating native cased splits', 'CPython checkpoint for the two retained CSV meter scripts')
compile(collector, 'collect.py', 'exec')
(quiet / 'collect.py').write_text(collector, encoding='utf-8', newline='\n')
(quiet / 'run.sh').write_bytes((original / 'run.sh').read_bytes())
assert b'\r' not in (quiet / 'run.sh').read_bytes()
(quiet / 'summarize.py').write_bytes((original / 'summarize.py').read_bytes())
payload = quiet / 'payload.tar.gz'
with tarfile.open(payload, 'w:gz') as bundle:
    for item in ('identity.json', 'representative.json', 'jobs.json', 'collect.py', 'run.sh'):
        bundle.add(quiet / item, arcname=item)
donor = Path(identity['frozenImage']).parent.name
save('upload.json', dict(root=name, reference=donor, payloadBytes=payload.stat().st_size,
    payloadSHA256=digest(payload), sourceArchiveSHA256=receipt['archiveSHA256']))

record = 'benchmarks/results/2026-11-24-native-inline-transfer/'
tracked = lambda name: subprocess.check_output(['git', 'show', 'origin/master:' + record + name], cwd=repo)
reused = {}
for prefix in ('initial', 'confirmation'):
    finalized = json.loads(tracked(prefix + '-terminal-status.json'))['receipt']
    assert finalized['complete'] and finalized['archivedAndVerifiedUnderLease']
    assert hashlib.sha256(tracked(prefix + '-observations.tar.xz')).hexdigest() == finalized['archiveSHA256']
    reused[prefix] = finalized['archiveSHA256']
recorded = json.loads(tracked('identity.json'))['imageFiles']['candidate']['Lokad.Lython.dll']
assert hashlib.sha256(gzip.decompress(tracked('candidate-core.dll.gz'))).hexdigest() == recorded
save('prior-replica.json', dict(path='native-inline-transfer-b1541-20261124/candidate/Lokad.Lython.dll',
    confirmation='native-inline-transfer-b1542-20261124/observations.tar.xz',
    observations=reused, coreSHA256=recorded, tracked=record))

launch = (reference / 'quiet.py').read_text(encoding='utf-8').replace('b1539-cased-split-cpython-20261123',
    'b1543-current-csv-cpython-20261124').replace('b1539-', 'b1543-')
launch = '\n'.join(line for line in launch.split('\n') if 'configuration["duplicates"]' not in line)
launch = launch.replace('configuration["remote"]=remote',
    'configuration["remote"]=remote\nconfiguration["replica"]=json.loads((quiet/"prior-replica.json").read_text(encoding="utf-8"))')
start = launch.index('with (base/')
end = launch.index("subprocess.run(['sudo','-n','systemd-run'", start)
launch = launch[:start] + '''with (base/'comparison-vm.lock').open('a') as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert donor['archiveSHA256']==configuration['sourceArchiveSHA256']
 assert payload.parent==base and payload.stat().st_size==configuration['payloadBytes'] and digest(payload)==configuration['payloadSHA256']
 room=shutil.disk_usage(base).free
 block=os.statvfs(base).f_frsize
 with tarfile.open(payload) as archive:
  assert {entry.name for entry in archive.getmembers()}=={'identity.json','representative.json','jobs.json','run.sh','collect.py'}
  assert all(entry.isfile() for entry in archive.getmembers())
  staged=sum(((entry.size+block-1)//block)*block for entry in archive.getmembers())
  minimum=11 * 1024 * 1024 + staged
  retired=None
  if room<minimum:
   saved=configuration['replica']
   replica=base/saved['path']
   assert replica.resolve()==replica and replica.is_file() and replica.stat().st_nlink==1
   assert digest(replica)==saved['coreSHA256']
   assert digest(replica.parent.parent/'observations.tar.xz')==saved['observations']['initial']
   assert digest(base/saved['confirmation'])==saved['observations']['confirmation']
   assert room+replica.stat().st_blocks*512>=minimum
   replica.unlink()
   retired=saved
  assert shutil.disk_usage(base).free>=minimum
  root.mkdir()
  archive.extractall(root,filter='data')
 payload.unlink()
 identity=json.loads((root/'identity.json').read_text())
 assert Path(identity['frozenImage']) == reference/'candidate'
 assert digest(root/'representative.json')==identity['catalogs']['representative.json']['sha256']
 files=identity['imageFiles']['candidate']
 assert len(files)==32
 for name,sha in files.items(): assert digest(reference/'candidate'/name)==sha,(name,sha)
 os.link(reference/'cpython-worker.py',root/'cpython-worker.py')
 assert digest(root/'cpython-worker.py')==identity['cpythonWorkerSHA256']
 assert bytes([13]) not in (root/'run.sh').read_bytes()
 print(json.dumps(dict(reusedVerifiedImage=True,verifiedDuplicateRetired=retired,freeBeforeLaunch=shutil.disk_usage(base).free)),flush=True)
''' + launch[end:]
(lab / 'quiet.py').write_text(launch, encoding='utf-8', newline='\n')
