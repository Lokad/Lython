from pathlib import Path

lab = Path(__file__).resolve().parent
previous = lab.with_name('retained-meter-allocation-20261123')
script = (previous / 'profile-allocation.py').read_text(encoding='utf-8')
start = script.index('proof=json.loads(')
end = script.index('expected=proof', start)
script = script[:start] + '''reference=lab.with_name('combined-cased-split-cpython-20261123')
proof=json.loads((reference/'comparison/quiet/identity.json').read_text(encoding='utf-8'))
proof['revision']=proof['candidate']
proof['protocolSHA256']=proof['cpythonWorkerSHA256']
image=reference/'candidate'
''' + script[end:]
start = script.index('catalog=json.loads(')
end = script.index('cases=[', start)
script = script[:start] + '''catalog=json.loads((lab/'comparison/quiet/representative.json').read_text(encoding='utf-8'))
ids=('scripts.csv-meter-report.explicit-float', 'scripts.csv-meter-report.typed-unicode')
''' + script[end:]
script = script.replace("('explicit-float','typed-ascii')", "('explicit-float','typed-unicode')")
compile(script, 'profile-allocation.py', 'exec')
(lab / 'profile-allocation.py').write_text(script, encoding='utf-8', newline='\n')
