
from pathlib import Path
import hashlib
import importlib.util
import json
import os
import subprocess
import tempfile

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
comparison=lab/"comparison"
identity=json.loads((comparison/"identity.json").read_text(encoding="utf-8"))
protocol=repo/"benchmarks/cpython-worker.py"
assert hashlib.sha256(protocol.read_bytes()).hexdigest()==identity["protocolSHA256"]
spec=importlib.util.spec_from_file_location("proto",protocol)
proto=importlib.util.module_from_spec(spec);spec.loader.exec_module(proto)
catalog=comparison/"representative.json"
cases=json.loads(catalog.read_text(encoding="utf-8"))["cases"]
sdk=Path.home()/".dotnet11"
for role in ("reference","candidate"):
    image=comparison/f"frozen-{role}"
    expected=identity["imageFiles"][role]
    assert {n:hashlib.sha256((image/n).read_bytes()).hexdigest()for n in expected}==expected
    log=lab/f"{role}-direct-integer-jit.asm"
    env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk),PATH=str(sdk)+os.pathsep+os.environ["PATH"],
         DOTNET_TieredCompilation="0",DOTNET_JitDisasm="*TryEvaluateDirectIntegerReturn*",DOTNET_JitStdOutFile=str(log))
    with tempfile.TemporaryDirectory(prefix="lython-comparison-files-") as cwd:
        with subprocess.Popen([sdk/"dotnet.exe",image/"Lokad.Lython.Benchmarks.dll","--compare","worker","--catalog",catalog],
                             cwd=cwd,env=env,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE)as child:
            try:
                first=proto.read_frame(child.stdout)
                assert first["status"]=="Ready" and first["catalogSha256"]==identity["catalogSHA256"]
                assert next(m["sha256"] for m in first["libraries"]if Path(m["path"]).name=="Lokad.Lython.dll")==expected["Lokad.Lython.dll"]
                for seq,case in enumerate((cases[0],cases[3]),1):
                    request={k:case[k]for k in ("sourceSha256","fixtureSha256","expectedOutputSha256")}
                    request.update(protocolVersion=proto.PROTOCOL_VERSION,requestId=seq,operation="verify",caseId=case["id"],
                                   lane="warm",iterations=3)
                    proto.write_frame(child.stdin,request)
                    observed=proto.read_frame(child.stdout)
                    assert observed["status"]=="Equivalent" and observed["actualOutputSha256"]==case["expectedOutputSha256"]
                proto.write_frame(child.stdin,dict(protocolVersion=proto.PROTOCOL_VERSION,requestId=3,operation="quit"))
                assert proto.read_frame(child.stdout)["status"]=="Closed"
                assert child.wait(timeout=10)==0 and not child.stderr.read()
            finally:
                if child.poll() is None:child.kill()
    assert log.stat().st_size>0
    bodies=[line for line in log.read_text(encoding="utf-8",errors="replace").splitlines()if line.startswith("; Assembly listing")]
    print(role,*bodies,sep="\n",flush=True)
    if role=="candidate":
        assert any("DefaultIntegerOperands" in line for line in bodies)
        assert any("SlotIntegerOperands" in line for line in bodies)

