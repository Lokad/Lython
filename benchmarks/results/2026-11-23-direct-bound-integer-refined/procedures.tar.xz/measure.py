
from pathlib import Path
import hashlib
import json
import os
import shutil
import statistics
import subprocess
import textwrap

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
tree=repo/".git/agent-worktrees/direct-bound-integer-20261123"
reference=lab.parent/"cpython-checkpoint-20261123"
control=lab.parent/"direct-single-def-default-20261123"/"comparison"
out=lab/"comparison"
out.mkdir()
def read(p):return json.loads(p.read_text(encoding="utf-8-sig"))
sha=lambda b:hashlib.sha256(b).hexdigest()
def h(p):return sha(p.read_bytes())
def save(p,v):p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+"\n",encoding="utf-8",newline="\n")
def git(*args,cwd=repo):return subprocess.check_output(["git",*args],cwd=cwd)
core="Lokad.Lython.dll"
ref=read(reference/"comparison/quiet/identity.json")
known=ref["imageFiles"]["candidate"]
assert len(known)==32 and {n:h(reference/"frozen"/n)for n in known}==known
original=read(control/"representative.json")
assert len(original["cases"])==5
python=Path("C:/Python313/python.exe")
test=(tree/"tests/Lokad.Lython.PublicApi.Tests/FunctionDefaultMetadataTests.cs").read_text(encoding="utf-8")
new_script=textwrap.dedent(test.split('{ """\n',1)[1].split('""",',1)[0])
assert "missing observed" in new_script
completed=subprocess.run([python,"-I","-S","-X","utf8","-c",new_script],check=True,capture_output=True,timeout=15)
expected=completed.stdout.decode("utf-8").replace("\r\n","\n")
assert expected=="9 21\nmissing observed\nTrue True\nmissing unused\n9\n" and not completed.stderr
(lab/"default-identity-cpython.log").write_text(expected,encoding="utf-8",newline="\n")

catalog=out/"representative.json"
shutil.copyfile(control/"representative.json",catalog)
sdk=Path.home()/".dotnet11"
dotnet=sdk/"dotnet.exe"
env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk),PATH=str(sdk)+os.pathsep+os.environ["PATH"])
protocol=repo/"benchmarks/cpython-worker.py"
assert h(protocol)==ref["protocolSHA256"]
head=git("rev-parse","89579aae7^",cwd=tree).decode().strip()
assert head.startswith("df5f19ee5") and not git("diff","--name-only",ref["candidate"],head,"--","src","tests")
patch=git("diff","--binary",head,"--","src","tests",cwd=tree)
assert patch.count(b"diff --git ")==4
(out/"source.patch").write_bytes(patch)
images={}
results={}
for role,built in (("reference",reference/"frozen"/core),("candidate",lab/"windows/bin/Lokad.Lython/release_net11.0"/core)):
    image=out/f"frozen-{role}"
    image.mkdir()
    files={**known,core:h(built)}
    for name in files:shutil.copyfile(built if name==core else reference/"frozen"/name,image/name)
    assert files=={n:h(image/n)for n in files}
    images[role]=files
    for suffix in (".dll",".deps.json",".runtimeconfig.json"):
        n="ValidatedAllocation"+suffix
        shutil.copyfile(control/"frozen-reference"/n,image/n)
    proof=out/f"{role}-verify.json"
    subprocess.run([dotnet,image/"Lokad.Lython.Benchmarks.dll","--compare","verify","--catalog",catalog,
        "--dotnet",dotnet,"--python",python,"--python-worker",protocol,"--out",proof],
        env=env,cwd=repo,check=True,timeout=90)
    verify=read(proof)
    assert verify["state"]=="Completed" and verify["caseCount"]==5 and verify["catalogSha256"]==h(catalog)
    report=out/f"{role}-allocation.json"
    subprocess.run([dotnet,image/"ValidatedAllocation.dll",image,catalog,report],env=env,cwd=repo,check=True,timeout=85)
    rows=read(report)["rows"]
    assert len(rows)==5 and all(row["sharedBudgetBaselineRestored"] for row in rows)
    results[role]=rows
    assert files=={n:h(image/n)for n in files}
save(out/"identity.json",dict(reference=ref["candidate"],patchBase=head,sourcePatchSHA256=h(out/"source.patch"),imageFiles=images,
                             protocolSHA256=h(protocol),catalogSHA256=h(catalog)))
for before,after in zip(results["reference"],results["candidate"],strict=True):
    assert before["id"]==after["id"]
    a,b=(statistics.median(x["allocatedBytesPerInvocation"]) for x in (before,after))
    print(before["id"],a,b,b-a,round(100*(b/a-1),3),before["peakExecutionMemoryBytes"],after["peakExecutionMemoryBytes"],flush=True)

