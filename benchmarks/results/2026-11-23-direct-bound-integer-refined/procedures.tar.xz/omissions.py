def factory(slope, offset):
    def calculate(value, /, factor=slope, *, pad=offset, spare=None):
        return (value * factor) + pad
    return calculate

calculate = factory(3, 5)
print(calculate(7), calculate(-4, 2), calculate(9, pad=8))
try:
    calculate()
except TypeError:
    print("missing positional")
calculate.__defaults__ = (99, 4, 5)
print(calculate(), calculate(2))
calculate.__defaults__ = (-1, 1 << 90)
print(calculate(3) == (3 << 90) + 5)

class Extra:
    def __radd__(self, other):
        print("addition protocol")
        return other + 101

other = factory(2, Extra())
print(other(4))

class Key:
    def __hash__(self):
        return hash("pad")
    def __eq__(self, name):
        print("lookup", name)
        return name == "pad"

calculate.__kwdefaults__ = {Key(): 7, "spare": []}
print(calculate(2, 3))
del calculate.__kwdefaults__["spare"]
try:
    calculate(2, 3)
except TypeError:
    print("missing unused keyword")

def modulo(value, divisor=0):
    return value % divisor

try:
    modulo(8)
except ZeroDivisionError:
    print("zero divisor")
print(modulo(-7, 3), modulo(7, -3))

