from pathlib import Path
import ast
import hashlib
import json
import os
import subprocess
import tarfile

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
quiet = lab/'comparison/quiet'
quiet.mkdir(parents=True, exist_ok=True)
donor = lab.parent/'short-path-cpython-20261126'
archive = donor/'comparison/quiet'
previous = lab.parent/'direct-zip-starmap-20261126'
profile = lab.parent/'affix-text-attribution-20261126'/'comparison/quiet'
launch = lab.parent/'file-processing-profile-20261126'/'quiet.py'
read = lambda path: json.loads(path.read_text(encoding='utf-8-sig'))
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
def write(path, body): path.write_text(body,encoding='utf-8',newline='\n')
def save(path, body): write(path,json.dumps(body,ensure_ascii=False,indent=2)+'\n')

record = read(archive/'identity.json')
receipt = read(archive/'terminal-status.json')['receipt']
assert receipt['complete'] and receipt['archiveSHA256']==sha(archive/'observations.tar.xz')
files = record['imageFiles']['candidate']
assert len(files)==32 and {p.name:sha(p) for p in (donor/'candidate').iterdir()}==files
baseline = record['sourceRevision']
head = subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()
changes = subprocess.check_output(['git','diff','--name-only',baseline,head,'--','src'],cwd=repo,text=True).splitlines()
assert changes==['src/Lokad.Lython/Runtime/LythonRuntime.Json.Deserialize.cs'],changes
catalog = read(previous/'comparison/quiet/representative.json')
bound='diagnostic.shipment-bound-starmap'
unbound='diagnostic.shipment-routing-callbacks'
catalog['cases']=[case for case in catalog['cases'] if case['id'] in (bound,unbound)]
assert len(catalog['cases'])==2
assert next(c for c in catalog['cases'] if c['id']==bound)==next(c for c in read(archive/'representative.json')['cases'] if c['id']==bound)
save(quiet/'catalog.json',catalog)
manifest=dict(sourceRevision=baseline, inspectedHead=head, sourceDifference=changes, imageFiles={'candidate':files},
              coreSHA256={'candidate':files['Lokad.Lython.dll']}, donorArchiveSHA256=receipt['archiveSHA256'],
              profileCatalogSHA256=sha(quiet/'catalog.json'), profiles=[['bound-shipment-async',bound,'candidate'],
              ['ordinary-shipment-async',unbound,'candidate']], purpose='Locate shared shipment costs after removing short zip tuple publication.')
save(quiet/'identity.json',manifest)
for name in ('collect.py','ops-profile.py','analyze.py','run.sh'):
    body=(profile/name).read_text(encoding='utf-8-sig')
    body=body.replace('direct-affix-return-b1746b-20261126','short-path-cpython-b1750-20261126').replace('b1748-fixtures','b1752-fixtures')
    body=body.replace("'PyMapIterator::', 'PyZipIterator::'", "'PyMapIterator::', 'PyZipIterator::', 'PyStarmapIterator::'")
    if name in ('collect.py','ops-profile.py','analyze.py'):
        code=ast.parse(body)
        if name=='collect.py':
            required={node.slice.value for node in ast.walk(code) if isinstance(node,ast.Subscript)
                      and isinstance(node.value,ast.Name) and node.value.id=='identity' and isinstance(node.slice,ast.Constant)}
            assert required<=manifest.keys(),required-manifest.keys()
    write(quiet/name,body)
assert b'\r' not in (quiet/'run.sh').read_bytes()

source=launch.read_text(encoding='utf-8-sig')
source=source.replace('lython-b1745-file-processing-profile-20261126','lython-b1752-shipment-cpu-20261126')
source=source.replace('native-cursor-stack-b1743-20261126','short-path-cpython-b1750-20261126')
source=source.replace("assert bytes>cfg['payloadBytes']+3*1024*1024", "assert bytes>cfg['payloadBytes']+15*1024*1024")
source=source.replace('RuntimeMaxSec=155','RuntimeMaxSec=125').replace('seconds=110','seconds=85')
compile(source,'quiet.py','exec');write(lab/'quiet.py',source)
sdk=Path.home()/'.dotnet11';dotnet=sdk/'dotnet.exe'
env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk))
worker=repo/'benchmarks/cpython-worker.py'
assert sha(worker)==record['cpythonWorkerSHA256']
proof=quiet/'verification.json'
subprocess.run([dotnet,donor/'candidate/Lokad.Lython.Benchmarks.dll','--compare','verify','--catalog',quiet/'catalog.json',
                '--dotnet',dotnet,'--python','C:/Python313/python.exe','--python-worker',worker,'--out',proof],
               cwd=repo,env=env,check=True,timeout=55)
data=read(proof)
assert data['state']=='Completed' and data['caseCount']==2 and data['catalogSha256']==manifest['profileCatalogSHA256']
assert data['launched']['library']['sha256']==files['Lokad.Lython.dll']
payload=quiet/'stage.tar.gz'
with tarfile.open(payload,'w:gz',compresslevel=6) as bundle:
    for name in ('identity.json','catalog.json','collect.py','ops-profile.py','run.sh'):
        bundle.add(quiet/name,arcname=name,recursive=False)
save(quiet/'upload.json',dict(root='shipment-cpu-b1752-20261126',payloadSHA256=sha(payload),payloadBytes=payload.stat().st_size,
                            expectedDonorArchiveSHA256=receipt['archiveSHA256']))
