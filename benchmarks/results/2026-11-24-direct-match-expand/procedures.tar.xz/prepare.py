from pathlib import Path
import contextlib
import hashlib
import io
import json
import os
import shutil
import subprocess

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
tree=repo/'.git/agent-worktrees/direct-match-expand-20261124'
donor=lab.with_name('json-encoding-flags-20261124')
comparison=lab/'comparison'
comparison.mkdir(exist_ok=True)


def read(path):
    return json.loads(path.read_text(encoding='utf-8'))


def sha(value):
    return hashlib.sha256(value.encode('utf-8')).hexdigest()


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def save(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2)+'\n',encoding='utf-8',newline='\n')


metadata = read(donor/'comparison/identity.json')
reference = metadata['candidate']
assert reference.startswith('eabbf02ed')
subprocess.run(['git','diff','--exit-code',reference,'HEAD','--','src','tests'],cwd=repo,check=True)
assert not subprocess.check_output(['git','status','--porcelain','--','src','tests'],cwd=tree)
candidate=subprocess.check_output(['git','rev-parse','HEAD'],cwd=tree,text=True).strip()
assert candidate.startswith('83ae1e2fa')
catalog=read(donor/'comparison/representative.json')
cases=[]
for label, iterations, subject, operation, length in (
    ('wide',256,"'é尾' * 512",r"match.expand(r'<\g<word>>:<\1>:\377')",2055),
    ('short',1024,"'é尾'",r"match.expand(r'<\g<word>>:<\1>:\377')",11),
    ('literal',1024,"'é尾'",r"match.expand('final é尾')",8),
    ('sub',1024,"'é尾'",r"pattern.sub(r'<\g<word>>:<\1>:\377', text)",11),
):
    source=(
        "import re\n"
        "pattern = re.compile(r'(?P<word>.+)')\n"
        f"text = {subject}\n"
        "match = pattern.fullmatch(text)\n"
        "total = 0\n"
        f"for _ in range({iterations}):\n"
        f"    item = {operation}\n"
        "    total += len(item)\n"
        "print(total, item[:2], item[-2:])\n"
    )
    stdout=io.StringIO()
    with contextlib.redirect_stdout(stdout):
        exec(compile(source,label+'.py','exec'),{'__name__':'__main__'})
    result=stdout.getvalue()
    assert int(result.split(' ',1)[0]) == iterations*length,(label,result)
    fixture='{"size":'+str(iterations)+',"text":null}'
    cases.append(dict(id='scripts.regex-expand-storage.'+label, family='scripts',category='whole-script',
        scale='medium',size=iterations,source=source,fixtureJson=fixture,expectedOutput=result,
        sourceUtf8Bytes=len(source.encode('utf-8')),expectedOutputUtf8Bytes=len(result.encode('utf-8')),
        fixtureTextUtf8Bytes=0,fixtureTextCodePoints=0,sourceSha256=sha(source),fixtureSha256=sha(fixture),
        expectedOutputSha256=sha(result)))
catalog['cases']=cases
representative=comparison/'representative.json'
save(representative,catalog)
save(comparison/'jobs.json',{'warm':[[case['id'],'warm'] for case in cases]})

files=metadata['imageFiles']['candidate']
runtime=Path.home()/'.dotnet11'
dotnet=runtime/'dotnet.exe'
protocol=repo/'benchmarks/cpython-worker.py'
assert digest(protocol)==metadata['cpythonWorkerSHA256']
env=dict(os.environ,DOTNET_ROOT=str(runtime),DOTNET_ROOT_X64=str(runtime))
assert len(files)==32 and all(digest(donor/'candidate'/name)==expected for name,expected in files.items())
core='Lokad.Lython.dll'
images={}
helpers={}
for role in ('reference','candidate'):
    image=lab/role
    image.mkdir(exist_ok=True)
    for name in files:
        source=lab/'frozen/bin/Lokad.Lython/release_net11.0'/core if role=='candidate' and name==core else donor/'candidate'/name
        shutil.copyfile(source,image/name)
    for suffix in ('.dll','.deps.json','.runtimeconfig.json'):
        helper='ValidatedAllocation'+suffix
        shutil.copyfile(donor/'candidate'/helper,image/helper)
        helpers[helper]=digest(donor/'candidate'/helper)
    observed={name:digest(image/name) for name in files}
    result=comparison/(role+'-verify.json')
    subprocess.run([dotnet,image/'Lokad.Lython.Benchmarks.dll','--compare','verify','--catalog',
        representative,'--dotnet',dotnet,'--python','C:/Python313/python.exe',
        '--python-worker',protocol,'--out',result],env=env,check=True,timeout=90)
    receipt=read(result)
    assert receipt['state']=='Completed' and receipt['caseCount']==4 and receipt['launched']['library']['sha256']==observed[core]
    assert all(digest(image/name)==expected for name,expected in observed.items())
    assert all(digest(image/name)==expected for name,expected in helpers.items())
    images[role]=observed
assert files==images['reference']
assert [name for name in files if images['reference'][name]!=images['candidate'][name]]==[core]
save(comparison/'identity.json',dict(sourceRevision=reference,candidate=candidate,
    purpose='B1558 write regex Match.expand output into final admitted UTF-8 storage',
    imageFiles=images,helperFiles=helpers,cpythonWorkerSHA256=metadata['cpythonWorkerSHA256'],
    expectedCPythonSHA256=metadata['expectedCPythonSHA256'],
    catalogs={name:dict(sha256=digest(comparison/name)) for name in ('representative.json','jobs.json')},
    coreSHA256={label:images[role][core] for role in images for label in (role,role+'-control')}))
shutil.copyfile(donor/'allocations.py',lab/'allocations.py')

