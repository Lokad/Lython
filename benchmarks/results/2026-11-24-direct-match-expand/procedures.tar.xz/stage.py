from pathlib import Path
import gzip
import hashlib
import json
import shutil
import subprocess
import tarfile

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
donor = lab.with_name('json-encoding-flags-20261124')
comparison = lab/'comparison'
quiet = comparison/'quiet'
quiet.mkdir(exist_ok=True)
core = 'Lokad.Lython.dll'
reference = 'json-encoding-flags-b1553-20261124'
root = 'direct-match-expand-b1558-20261124'


def sha(data):
    return hashlib.sha256(data).hexdigest()


def digest(path):
    return sha(path.read_bytes())


def write(path, value):
    path.write_text(value,encoding='utf-8',newline='\n')


def save(path, value):
    write(path,json.dumps(value,indent=2)+'\n')


archive='benchmarks/results/2026-11-24-cased-empty-iteration/'
def tracked(file):
    return subprocess.check_output(['git','show','origin/master:'+archive+file],cwd=repo)
receipt=json.loads(tracked('terminal-status.json'))['receipt']
assert receipt['complete'] and receipt['archivedAndVerifiedUnderLease']
assert sha(tracked('observations.tar.xz'))==receipt['archiveSHA256']
binary=sha(gzip.decompress(tracked('candidate-core.dll.gz')))
assert json.loads(tracked('identity.json'))['imageFiles']['candidate'][core]==binary
replica=dict(path='cased-empty-iteration-b1557-20261124/candidate/'+core,sha256=binary,
    observationSHA256=receipt['archiveSHA256'],trackedArchive=archive)
save(lab/'verified-replicas.json',[replica])

original=donor/'comparison/quiet'
collector=(original/'collect.py').read_text(encoding='utf-8').replace('b1553-','b1558-')
assert collector.count("'typed-csv-text-b1550-20261124'/'candidate'")==1
collector=collector.replace("'typed-csv-text-b1550-20261124'/'candidate'",repr(reference)+"/'candidate'")
compile(collector,'collect.py','exec')
write(quiet/'collect.py',collector)
shutil.copyfile(original/'run.sh',quiet/'run.sh')
assert b'\r' not in (quiet/'run.sh').read_bytes()
payload=quiet/'payload.tar.gz'
with tarfile.open(payload,'w:gz') as bundle:
    for name in ('identity.json','representative.json','jobs.json'):
        bundle.add(comparison/name,arcname=name)
    for name in ('collect.py','run.sh'):
        bundle.add(quiet/name,arcname=name)
    bundle.add(lab/'candidate'/core,arcname='candidate-core.dll')
save(quiet/'upload.json',dict(root=root,reference=reference,payloadSHA256=digest(payload),payloadBytes=payload.stat().st_size))
launch=(donor/'quiet.py').read_text(encoding='utf-8').replace('b1553-json-encoding-flags','b1558-direct-match-expand').replace('b1553-','b1558-')
compile(launch,'quiet.py','exec')
write(lab/'quiet.py',launch)
shutil.copyfile(donor/'summarize.py',lab/'summarize.py')
