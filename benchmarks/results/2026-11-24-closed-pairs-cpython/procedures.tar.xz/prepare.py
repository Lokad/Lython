from pathlib import Path
import ast
import hashlib
import json
import os
import shutil
import subprocess
import tarfile

lab = Path(__file__).resolve().parent
root = lab.parents[3]
donor = lab.parent / 'closed-factory-pairs-entry-20261124'
template = lab.parent / 'annotated-factories-cpython-20261124'
out = lab / 'external'
out.mkdir(exist_ok=True)
read = lambda path: json.loads(path.read_text(encoding='utf-8'))
sha = lambda payload: hashlib.sha256(payload).hexdigest()
digest = lambda path: sha(path.read_bytes())
write = lambda path, content: path.write_text(content, encoding='utf-8', newline='\n')
save = lambda path, content: write(path, json.dumps(content, indent=2, ensure_ascii=False) + '\n')
meta = read(donor / 'comparison/identity.json')
quiet = donor / 'comparison/quiet'
receipt = read(quiet / 'terminal-status.json')['receipt']
assert receipt['complete'] and receipt['archivedAndVerifiedUnderLease']
assert digest(quiet / 'observations.tar.xz') == receipt['archiveSHA256']
source = subprocess.check_output(['git', 'rev-parse', '70b04c0af'], cwd=root, text=True).strip()
subprocess.run(['git', 'diff', '--exit-code', meta['candidate'], source, '--', 'src', 'tests'], cwd=root, check=True)
files = meta['imageFiles']['candidate']
assert len(files) == 32
frozen = lab / 'candidate'
frozen.mkdir(exist_ok=True)
for name in files:
    shutil.copyfile(donor / 'candidate' / name, frozen / name)
assert {p.name: digest(p) for p in frozen.iterdir()} == files
location = 'closed-pairs-cpython-b1597-20261124'
original = 'closed-factory-pairs-entry-b1596-20261124'
identity = dict(sourceRevision=meta['candidate'], candidate=meta['candidate'], productionSource=source,
    imageFiles={'candidate':files}, frozenImage='/home/lokad/lython-bench-checks/'+location+'/candidate',
    auxiliaryFiles={name:expected for name,expected in files.items() if name != 'Lokad.Lython.dll'},
    coreSHA256={key:meta['coreSHA256'][key] for key in ('candidate','candidate-control')},
    expectedCPythonSHA256=meta['expectedCPythonSHA256'], cpythonWorkerSHA256=meta['cpythonWorkerSHA256'])
catalog = read(donor / 'comparison/representative.json')
ids = ('scripts.rule-default-closures', 'scripts.captured-rule-closures', 'diagnostic.text-summary.nonlocal-computed-width.large')
catalog['cases'] = [next(case for case in catalog['cases'] if case['id'] == case_id) for case_id in ids]
save(out / 'representative.json', catalog)
jobs = [(case, 'warm') for case in ids] + [(case, lane) for case in ids[:2] for lane in ('compile', 'compile-run')]
save(out / 'jobs.json', jobs)
identity['catalogs'] = {name: {'sha256': digest(out / name)} for name in ('representative.json','jobs.json')}
save(out / 'identity.json', identity)

sdk = Path.home() / '.dotnet11'
dotnet = sdk / 'dotnet.exe'
env = dict(os.environ, DOTNET_ROOT=str(sdk), DOTNET_ROOT_X64=str(sdk), PATH=str(sdk)+os.pathsep+os.environ['PATH'])
protocol = root / 'benchmarks/cpython-worker.py'
assert digest(protocol) == identity['cpythonWorkerSHA256']
subprocess.run([dotnet, frozen / 'Lokad.Lython.Benchmarks.dll', '--compare', 'verify', '--catalog', out / 'representative.json',
    '--dotnet', dotnet, '--python', 'C:/Python313/python.exe', '--python-worker', protocol, '--out', out / 'candidate-verify.json'],
    env=env, cwd=root, check=True, timeout=85)
check = read(out / 'candidate-verify.json')
assert check['state'] == 'Completed' and check['caseCount'] == len(ids)
assert check['launched']['library']['sha256'] == identity['coreSHA256']['candidate']
assert check['catalogSha256'] == identity['catalogs']['representative.json']['sha256']

with tarfile.open(root / 'benchmarks/results/2026-11-24-annotated-factories-cpython/observations.tar.xz') as bundle:
    launcher_script = bundle.extractfile('run.sh').read()
assert b'\r' not in launcher_script
(out / 'run.sh').write_bytes(launcher_script)
for filename in ('collect.py','summarize.py'):
    content = (template / 'external' / filename).read_text(encoding='utf-8')
    content = content.replace('b1593-', 'b1597-').replace('len(jobs) == 8','len(jobs) == 7').replace('started<450','started<392')
    content = content.replace('len(raw["jobs"])==8 and receipt["warmJobs"]==8','len(raw["jobs"])==7 and receipt["warmJobs"]==7')
    content = content.replace('CPython checkpoint for eager and postponed annotated rule factories','CPython checkpoint for the delivered closed pairs and captured-rule debt')
    compile(content, filename, 'exec')
    write(out / filename, content)
launcher = (template / 'external.py').read_text(encoding='utf-8')
launcher = launcher.replace('decoded-closed-defaults-20261124/comparison/quiet','closed-factory-pairs-entry-20261124/comparison/quiet')
launcher = launcher.replace('decoded-closed-defaults-b1591-20261124',original).replace('annotated-factories-cpython-b1593-20261124',location)
launcher = launcher.replace('lython-b1593-annotated-factories-cpython', 'lython-b1597-closed-pairs-cpython')
launcher = launcher.replace("('collect.py','identity.json','jobs.json','representative.json')", "('collect.py','identity.json','jobs.json','representative.json','run.sh')")
launcher = launcher.replace(" for name in ('cpython-worker.py','run.sh'):os.link(original/name,root/name)", " os.link(original/'cpython-worker.py',root/'cpython-worker.py')")
launcher = launcher.replace('RuntimeMaxSec=495','RuntimeMaxSec=460').replace('seconds=436','seconds=405')
remote, = (n.value for n in ast.walk(ast.parse(launcher)) if isinstance(n,ast.Constant) and isinstance(n.value,str) and 'staged=sum' in n.value)
compile(remote,'remote-stage','exec')
assert 'original/name,root/name)' not in remote and '\r' not in launcher
write(lab / 'external.py', launcher)
archiver = (template / 'archive.py').read_text(encoding='utf-8')
archiver = archiver.replace("'2026-11-24-annotated-factories-cpython'", "'2026-11-24-closed-pairs-cpython'")
archiver = archiver.replace("==8 and sha", "==7 and sha").replace("'5313f9e71'", "'70b04c0af'").replace('==224','==196').replace('==4\n','==3\n')
archiver = archiver.replace("'external/launch.log','external/candidate-verify.json'", "'external/launch.log','external/candidate-verify.json','external/run.sh'")
archiver = archiver.replace('B1593 with 224', 'B1597 with 196')
compile(archiver,'archive.py','exec')
write(lab / 'archive.py', archiver)
print('Prepared seven short lanes with three verified CPython goldens.')
