from pathlib import Path
import ast
import gzip
import hashlib
import json
import subprocess

lab = Path(__file__).resolve().parent
root = lab.parents[3]
old = root / 'benchmarks/results/2026-11-24-closed-factory-pairs'
read=lambda p: json.loads(p.read_text(encoding='utf-8'))
sha=lambda payload: hashlib.sha256(payload).hexdigest()
terminal=read(old / 'terminal-status.json')
receipt=terminal['receipt']
assert not terminal['live'] and not terminal['fixtures'] and terminal['exitCode']=='0'
assert all(receipt[k] for k in ('complete','allWorkersJoined','guestFixturesRemoved','quietBeforeAndAfter','archivedAndVerifiedUnderLease'))
assert sha((old/'observations.tar.xz').read_bytes()) == receipt['archiveSHA256']
binary=old/'candidate-core.dll.gz'
shipped=subprocess.check_output(['git','show','origin/master:'+binary.relative_to(root).as_posix()],cwd=root)
assert shipped == binary.read_bytes()
wanted=sha(gzip.decompress(shipped))
assert wanted == read(old/'identity.json')['coreSHA256']['candidate']
launcher=lab/'external.py'
source=launcher.read_text(encoding='utf-8')
(lab/'external-before-space-recovery.py').write_text(source,encoding='utf-8',newline='\n')
old_name="closed-factory-pairs-b1594-20261124"
recovery=f''' free=shutil.disk_usage(base).free
 if free < minimum:
  archived=base/{old_name!r}
  duplicate=archived/'candidate/Lokad.Lython.dll'
  assert duplicate.resolve()==duplicate and duplicate.is_file() and duplicate.stat().st_nlink==1
  assert digest(archived/'observations.tar.xz')=={receipt['archiveSHA256']!r}
  assert not (archived/'guest-fixtures').exists()
  assert digest(duplicate)=={wanted!r}
  duplicate.unlink()
  print(json.dumps(dict(originalFree=free,required=minimum,retired=duplicate.relative_to(base).as_posix(),sha256={wanted!r},observationSHA256={receipt['archiveSHA256']!r},remainingFree=shutil.disk_usage(base).free)))
 assert shutil.disk_usage(base).free>=minimum
'''
marker=' assert shutil.disk_usage(base).free>=minimum\n'
assert source.count(marker)==1
source=source.replace(marker,recovery)
remote,=(item.value for item in ast.walk(ast.parse(source)) if isinstance(item,ast.Constant) and isinstance(item.value,str) and 'staged=sum' in item.value)
compile(remote,'remote-stage','exec')
launcher.write_text(source,encoding='utf-8',newline='\n')
