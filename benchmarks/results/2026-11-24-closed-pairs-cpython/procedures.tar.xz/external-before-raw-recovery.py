from pathlib import Path
import datetime
import hashlib
import json
import subprocess
import sys

lab = Path(__file__).resolve().parent
quiet = lab.parent / 'closed-factory-pairs-entry-20261124/comparison/quiet'
output = lab / 'external'
output.mkdir(exist_ok=True)
remote = '/home/lokad/lython-bench-checks'
unit = 'lython-b1597-closed-pairs-cpython-20261124'
location = 'closed-pairs-cpython-b1597-20261124'
original = 'closed-factory-pairs-entry-b1596-20261124'
host = 'lokad@20.166.121.73'
common = ['-i', str(Path.home() / '.ssh/id_lython-bench.pem'), '-o', 'BatchMode=yes', '-o', 'ConnectTimeout=15']
ssh = ['C:/Windows/System32/OpenSSH/ssh.exe', *common, host, 'python3 -']
scp = ['C:/Windows/System32/OpenSSH/scp.exe', *common]
now = lambda: datetime.datetime.now(datetime.timezone.utc)
sha = lambda b: hashlib.sha256(b).hexdigest()
prefix = "from pathlib import Path\nimport json,fcntl,hashlib,os,subprocess,shutil\n"
prefix += f"base=Path({remote!r}).resolve(); root=base/{location!r}; original=base/{original!r}; unit={unit!r}\n"
prefix += "digest=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()\n"


def invoke(script):
    result = subprocess.run(ssh, input=prefix + script, encoding='utf-8', capture_output=True, timeout=35)
    assert result.returncode == 0, (result.stdout, result.stderr)
    return result.stdout


if sys.argv[1] == 'launch':
    previous = json.loads((quiet/'terminal-status.json').read_text(encoding='utf-8'))['receipt']
    payload = {name:(output/name).read_text(encoding='utf-8') for name in ('collect.py','identity.json','jobs.json','representative.json','run.sh')}
    script = f"payload={payload!r}; checksum={previous['archiveSHA256']!r}\n" + """
with (base/'comparison-vm.lock').open('a') as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert digest(original/'observations.tar.xz')==checksum
 assert not (original/'guest-fixtures').exists()
 block=os.statvfs(base).f_frsize
 staged=sum((len(content.encode('utf-8'))+block-1)//block*block for content in payload.values())
 minimum=staged+3840*1024
 free=shutil.disk_usage(base).free
 if free < minimum:
  archived=base/'closed-factory-pairs-b1594-20261124'
  duplicate=archived/'candidate/Lokad.Lython.dll'
  assert duplicate.resolve()==duplicate and duplicate.is_file() and duplicate.stat().st_nlink==1
  assert digest(archived/'observations.tar.xz')=='f4ca0675614034dcf221d94dad456f25cfa1518e389f6aa24d107f90e23088bc'
  assert not (archived/'guest-fixtures').exists()
  assert digest(duplicate)=='332eb83360fb2955e36fda9e0cd3fcaceaeb8fd1898937a9e1aa2b179c9e9d13'
  duplicate.unlink()
  print(json.dumps(dict(originalFree=free,required=minimum,retired=duplicate.relative_to(base).as_posix(),sha256='332eb83360fb2955e36fda9e0cd3fcaceaeb8fd1898937a9e1aa2b179c9e9d13',observationSHA256='f4ca0675614034dcf221d94dad456f25cfa1518e389f6aa24d107f90e23088bc',remainingFree=shutil.disk_usage(base).free)))
 assert shutil.disk_usage(base).free>=minimum
 assert not root.exists()
 root.mkdir()
 (root/'candidate').mkdir()
 for name, content in payload.items(): (root/name).write_text(content,encoding='utf-8')
 identity=json.loads((root/'identity.json').read_text(encoding='utf-8'))
 files=identity['imageFiles']['candidate']
 assert len(files)==32
 for name, sha in files.items():
  item=original/'candidate'/name
  assert digest(item)==sha
  os.link(item,root/'candidate'/name)
 os.link(original/'cpython-worker.py',root/'cpython-worker.py')
 assert digest(root/'representative.json')==identity['catalogs']['representative.json']['sha256']
 assert digest(root/'jobs.json')==identity['catalogs']['jobs.json']['sha256']
 assert digest(root/'cpython-worker.py')==identity['cpythonWorkerSHA256']
 assert bytes([13]) not in (root/'run.sh').read_bytes()
 assert shutil.disk_usage(base).free>=3584*1024
subprocess.run(['sudo','-n','systemd-run','--unit='+unit,'--property=User=lokad','--property=WorkingDirectory='+str(root),
 '--property=RuntimeMaxSec=460','--property=TimeoutStopSec=20','--property=KillMode=control-group','/bin/sh',str(root/'run.sh')],check=True)
"""
    receipt = invoke(script)
    (output / 'launch.log').write_text(receipt, encoding='utf-8')
    (output / 'observe-not-before').write_text((now()+datetime.timedelta(seconds=405)).isoformat(), encoding='utf-8')
    print(unit, receipt)
else:
    assert sys.argv[1] == 'retrieve'
    assert now() >= datetime.datetime.fromisoformat((output / 'observe-not-before').read_text(encoding='utf-8'))
    state = invoke("""
service=subprocess.run(['systemctl','show',unit+'.service','--property=ActiveState,SubState,MainPID,Result,ExecMainStatus'],capture_output=True,text=True).stdout
if 'ActiveState=active' in service:
 print(json.dumps(dict(live=True,service=service)))
else:
 with (base/'comparison-vm.lock').open('a') as lease:
  fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
  outcome=root/'exit-code.txt'
  receipt=root/'archive-receipt.json'
  print(json.dumps(dict(live=False,service=service,exitCode=outcome.read_text().strip() if outcome.exists() else None,
   receipt=json.loads(receipt.read_text()) if receipt.exists() else None, fixtures=(root/'guest-fixtures').exists(),
   journal=subprocess.run(['journalctl','-u',unit+'.service','-n','36','--no-pager'],capture_output=True,text=True).stdout)))
""")
    status = json.loads(state)
    print(state)
    (output / ('status-' + now().strftime('%H%M%S') + '.json')).write_text(state, encoding='utf-8')
    if status.get('receipt') is not None:
        archive = output / 'observations.tar.xz'
        subprocess.run(scp+[host+':'+remote+'/'+location+'/'+archive.name,archive],check=True,timeout=35)
        assert sha(archive.read_bytes()) == status['receipt']['archiveSHA256']
        (output / 'terminal-status.json').write_text(state, encoding='utf-8')
