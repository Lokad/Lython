from pathlib import Path
import hashlib
import io
import json
import subprocess
import tarfile

lab = Path(__file__).resolve().parent
root = lab.parents[3]
old = root / 'benchmarks/results/2026-11-24-closed-factory-pairs'
archive = old / 'observations.tar.xz'
receipt = json.loads((old/'terminal-status.json').read_text(encoding='utf-8'))['receipt']
assert receipt['complete'] and receipt['archivedAndVerifiedUnderLease']
shipped = subprocess.check_output(['git','show','origin/master:'+archive.relative_to(root).as_posix()],cwd=root)
assert shipped == archive.read_bytes()
sha = lambda b:hashlib.sha256(b).hexdigest()
assert sha(shipped) == receipt['archiveSHA256']
with tarfile.open(fileobj=io.BytesIO(shipped),mode='r:xz') as tar:
    wanted=sha(tar.extractfile('confirmation/confirmation.json').read())
candidate=lab/'external.py'
contents=candidate.read_text(encoding='utf-8')
(lab/'external-before-raw-recovery.py').write_text(contents,encoding='utf-8',newline='\n')
contents=(lab/'external-before-space-recovery.py').read_text(encoding='utf-8')
marker=' assert shutil.disk_usage(base).free>=minimum\n'
recovery=f''' free=shutil.disk_usage(base).free
 if free < minimum:
  archived=base/'closed-factory-pairs-b1594-20261124'
  duplicate=archived/'confirmation/confirmation.json'
  assert duplicate.resolve()==duplicate and duplicate.is_file() and duplicate.stat().st_nlink==1
  assert not (archived/'guest-fixtures').exists()
  assert digest(archived/'observations.tar.xz')=={receipt['archiveSHA256']!r}
  assert digest(duplicate)=={wanted!r}
  duplicate.unlink()
  print(json.dumps(dict(originalFree=free,required=minimum,retired=duplicate.relative_to(base).as_posix(),sha256={wanted!r},observationSHA256={receipt['archiveSHA256']!r},remainingFree=shutil.disk_usage(base).free)))
 assert shutil.disk_usage(base).free>=minimum
'''
assert contents.count(marker)==1
contents=contents.replace(marker,recovery)
compile(contents,'external.py','exec')
candidate.write_text(contents,encoding='utf-8',newline='\n')
archive_program=lab/'archive.py'
contents=archive_program.read_text(encoding='utf-8')
contents=contents.replace("'external/launch.log','external/candidate-verify.json','external/run.sh'", "'external/launch.log','external/candidate-verify.json','external/run.sh','recover-space.py','recover-raw.py','external-before-space-recovery.py','external-before-raw-recovery.py'")
compile(contents,'archive.py','exec')
archive_program.write_text(contents,encoding='utf-8',newline='\n')
