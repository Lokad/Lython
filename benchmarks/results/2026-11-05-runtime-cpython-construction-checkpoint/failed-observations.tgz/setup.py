from pathlib import Path
import json,hashlib,shutil
root=Path('/home/lokad/lython-bench-checks/runtime-cpython-b250-20261105')
(root/'candidate').symlink_to('/home/lokad/lython-bench-checks/format-construction-b249-20261105/candidate',target_is_directory=True)
(root/'reference').symlink_to('/home/lokad/lython-bench-checks/runtime-cpython-b240-20261105/candidate',target_is_directory=True)
i=json.loads((root/'identity.json').read_text(encoding='utf-8'))
for label in ('candidate','control','reference'):
 folder=root/('candidate' if label=='control' else label)
 assert hashlib.sha256((folder/'Lokad.Lython.dll').read_bytes()).hexdigest()==i['coreSHA256'][label]
 for name,sha in i['auxiliaryFiles'].items():assert hashlib.sha256((folder/name).read_bytes()).hexdigest()==sha
assert shutil.disk_usage(root).free>64*1024*1024
