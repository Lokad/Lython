from pathlib import Path
import hashlib,json,tarfile,subprocess
root=Path("/home/lokad/lython-bench-checks/runtime-cpython-b250-20261105")
r=json.loads((root/'confirmation/confirmation.json').read_text());assert r['complete'] and len(r['jobs'])==14
assert all(j['workersJoinedAndFixturesRemoved'] for j in r['jobs'])
assert not list(Path('/dev/shm').glob('lython-comparison-files-*'))
assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[c]omplete-jobs.dll'],capture_output=True).returncode==1
assert json.loads((root/'confirmation/machine-after.json').read_text())['gate']['quiet']
with tarfile.open(root/'observations.tgz','w:gz') as t:
 for n in ['confirmation','identity.json','representative.json','collect.py','cpython-worker.py','pre-measurement-plan.md','setup.py','source.patch','source-snapshot.tgz']:t.add(root/n,arcname=n)
result=dict(complete=True,jobs=14,elapsedSeconds=r['elapsedSeconds'],allWorkersJoined=True,guestFixtureDirectories=[],quietBeforeAndAfter=True,archiveSHA256=hashlib.sha256((root/'observations.tgz').read_bytes()).hexdigest())
(root/'archive-receipt.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
