from pathlib import Path
import hashlib,json,tarfile,shutil

lab=Path(__file__).resolve().parent
old=lab.with_name("builtin-shadowing-20261124")/"comparison"
reference=lab.with_name("abstract-collection-graphs-20261124")/"comparison"
native=lab/"boxed/quiet"
output=lab/"compiler-confirmation"
quiet=output/"quiet"
quiet.mkdir(parents=True,exist_ok=True)
read=lambda p:json.loads(p.read_text(encoding="utf-8-sig"))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
save=lambda p,x:p.write_text(json.dumps(x,indent=2)+"\n",encoding="utf-8",newline="\n")
identity=read(old/"identity.json")
base=read(reference/"identity.json")
target=read(native/"identity.json")
assert identity["imageFiles"]["reference"]==base["imageFiles"]["candidate"]
assert identity["imageFiles"]["candidate"]==target["imageFiles"]["reference"]
for role,expected in identity["imageFiles"].items():
    assert len(expected)==32 and {p.name:sha(p)for p in (old/role).iterdir()}==expected
    proof=read(old/f"{role}-verify.json")
    assert proof["state"]=="Completed" and proof["caseCount"]==4
    assert proof["launched"]["library"]["sha256"]==expected["Lokad.Lython.dll"]
    assert proof["catalogSha256"]==identity["catalogs"]["representative.json"]["sha256"]
identity["sourceRevision"]="0bf516c798528ed4ecfa7d3ce78e867043e1b4fd"
identity["comparisonRevision"]=identity["sourceRevision"]
identity["candidateRevision"]="556c8d71cd233fcc5eaf99fe4effc3726c059faa"
identity["purpose"]="Quiet confirmation of the delivered static builtin resolution timing"
identity["expectedCPythonSHA256"]=target["expectedCPythonSHA256"]
assert identity["cpythonWorkerSHA256"]==target["cpythonWorkerSHA256"]
shutil.copyfile(old/"representative.json",quiet/"representative.json")
assert sha(quiet/"representative.json")==identity["catalogs"]["representative.json"]["sha256"]
jobs=read(old/"jobs.json")
jobs["warm"]=[lane for lane in jobs["warm"] if lane[0]!="scripts.csv-summary-functions.small"]
assert len(jobs["warm"])==5
save(quiet/"jobs.json",jobs)
identity["catalogs"]["jobs.json"]["sha256"]=sha(quiet/"jobs.json")
save(quiet/"identity.json",identity)
collector=(native/"collect.py").read_text(encoding="utf-8").replace("b1619-fixtures","b1620-fixtures")
(quiet/"collect.py").write_text(collector,encoding="utf-8",newline="\n")
shutil.copyfile(native/"run.sh",quiet/"run.sh")
assert b"\r" not in (quiet/"run.sh").read_bytes()
payload=quiet/"payload.tar.gz"
with tarfile.open(payload,"w:gz",compresslevel=3) as bundle:
    for name in ("identity.json","jobs.json","representative.json","collect.py","run.sh"):
        bundle.add(quiet/name,arcname=name,recursive=False)
candidate_sha=read(native/"terminal-status.json")["receipt"]["archiveSHA256"]
reference_sha=read(reference/"quiet/terminal-status.json")["receipt"]["archiveSHA256"]
save(quiet/"upload.json",dict(root="builtin-shadowing-confirmation-b1620-20261124",reference="abstract-collection-graphs-b1613-20261124",
                             candidateDonor="unused-json-write-result-b1619-20261124",
                             candidateArchiveSHA256=candidate_sha,payloadSHA256=sha(payload),payloadBytes=payload.stat().st_size))
save(output/"verified-raw-replicas.json",[])
launch=(lab/"boxed/quiet.py").read_text(encoding="utf-8")
launch=launch.replace("lython-b1619-unused-json-write-result-","lython-b1620-builtin-shadowing-confirmation-").replace("b1619-","b1620-")
assert read((lab/"comparison/quiet/terminal-status.json"))["receipt"]["archiveSHA256"] in launch
launch=launch.replace(read((lab/"comparison/quiet/terminal-status.json"))["receipt"]["archiveSHA256"],reference_sha)
launch=launch.replace("with (base/'comparison-vm.lock').open('a') as lease:\n fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)\n free=shutil.disk_usage(base).free",
"""other=base/configuration['candidateDonor']
other_receipt=json.loads((other/'archive-receipt.json').read_text())
assert other_receipt['complete'] and digest(other/'observations.tar.xz')==other_receipt['archiveSHA256']==configuration['candidateArchiveSHA256']
with (base/'comparison-vm.lock').open('a') as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 free=shutil.disk_usage(base).free""")
launch=launch.replace("'collect.py','candidate-core.dll'","'collect.py'")
start=launch.index("   if name=='Lokad.Lython.dll' and role=='candidate':")
end=launch.index("   assert digest(image/name)==sha",start)
launch=launch[:start]+"""   frozen=reference/'candidate' if role=='reference' else other/'reference'
   os.link(frozen/name,image/name)
"""+launch[end:]
launch=launch.replace("needs one core, receipts and working room","needs receipts and working room")
compile(launch,"quiet.py","exec")
(output/"quiet.py").write_text(launch,encoding="utf-8",newline="\n")
print("Prepared the five compiler lanes against two already frozen, verified source images")
