from pathlib import Path
import hashlib,json,subprocess,tarfile

lab=Path(__file__).resolve().parent
root=lab.parents[3]
work=lab/"compiler-confirmation"
out=root/"benchmarks/results/2026-11-24-builtin-shadowing/quiet-confirmation"
read=lambda p:json.loads(p.read_text(encoding="utf-8-sig"))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
selected=read(work/"quiet/identity.json")
previous=read(lab.with_name("builtin-shadowing-20261124")/"comparison/identity.json")
patch=subprocess.check_output(["git","diff","--binary","b65d6bd96","556c8d71c","--","src","tests"],cwd=root)
assert hashlib.sha256(patch).hexdigest()==selected["sourcePatchSHA256"]==previous["sourcePatchSHA256"]
assert selected["imageFiles"]==previous["imageFiles"]
assert read(out/"quiet-summary.json")["timedBatches"]==140
assert sha(out/"quiet-observations.tar.xz")==read(out/"quiet-terminal-status.json")["receipt"]["archiveSHA256"]
procedures=("archive-compiler-confirmation.py","prepare-compiler-confirmation.py","compiler-confirmation/quiet.py",
            "compiler-confirmation/archive-quiet.py","compiler-confirmation/quiet-launch.log",
            "compiler-confirmation/quiet-retrieve.log","compiler-confirmation/quiet/identity.json",
            "compiler-confirmation/quiet/storage-custody.json")
with tarfile.open(out/"procedures.tar.xz","w:xz") as bundle:
    for p in procedures:bundle.add(lab/p,arcname=p)
with tarfile.open(out/"procedures.tar.xz") as bundle:
    assert all(hashlib.sha256(bundle.extractfile(p).read()).hexdigest()==sha(lab/p) for p in procedures)
