from pathlib import Path
import hashlib
import json
import os
import subprocess
import sys

lab = Path(__file__).resolve().parent
root = lab.parents[3]
sdk = Path.home() / ".dotnet11"
env = dict(os.environ, DOTNET_ROOT=str(sdk), DOTNET_ROOT_X64=str(sdk))
reference = lab.parent / "abstract-collection-graphs-20261124"
original = json.loads((reference / "shadow-input.json").read_text(encoding="utf-8"))
snippets = original + [
    'if callable(lambda: None):\n len = lambda x: "branch"\nprint(len(3))\n',
    'if not callable(lambda: None):\n pass\nelse:\n int = lambda x: "branch"\nprint(len(int(3)))\n',
    'def call(): return len(3)\nlen = lambda x: "late"\nprint(call())\n',
    'def outer():\n def call(): return len(3)\n len = lambda x: "outer"\n return call()\nprint(outer())\n',
    'def maker(): return lambda x: "unpacked"\n(len,) = [maker()]\nprint(len(3))\n',
    'def maker(): return [lambda x: "unpacked"]\n(len,) = maker()\nprint(len(3))\n',
    'data = [1]\ndef maker(): return lambda x: data.append("ok")\nlen = maker()\nlen(3)\nprint(data[1].upper())\n',
    'class Context:\n def __enter__(self): return lambda x: "with"\n def __exit__(self, a, b, c): return False\nwith Context() as len:\n print(len(3))\nprint(len(4))\n',
    'handler = lambda x: "match"\nmatch handler:\n case len:\n  print(len(3))\nprint(len(4))\n',
    'print((len := lambda x: "walrus")(3))\nprint(len(4))\n',
    'len = "before"\ntry:\n raise ValueError("caught")\nexcept ValueError as len:\n print(str(len))\nprint(len("x"))\n',
    'input = lambda value: value + 1\nprint(input(3))\n',
    'sum = lambda value: value + 1\nprint(sum(3))\n',
    'len = lambda value: 0\nitems = [1]\nif len(items) == 0:\n print(items[0])\n',
]
(lab / "snippets.json").write_text(json.dumps(snippets, indent=2) + "\n", encoding="utf-8")
name = sys.argv[1]
probe = (root / "tools/LythonProbe/bin/Release/net11.0" if name == "candidate" else reference / "probe-candidate") / "LythonProbe.dll"
print(name, hashlib.sha256(probe.with_name("Lokad.Lython.dll").read_bytes()).hexdigest())
for mode in ("sync", "async"):
    run = subprocess.run([sdk / "dotnet.exe", probe, "--batch-json", "--compare-python", "--python", "C:/Python313/python.exe",
                          *(["--async"] if mode == "async" else [])], input=json.dumps(snippets), capture_output=True,
                         text=True, encoding="utf-8", env=env, timeout=75)
    (lab / f"{name}-{mode}.jsonl").write_text(run.stdout, encoding="utf-8", newline="\n")
    rows = [json.loads(line) for line in run.stdout.splitlines()]
    assert len(rows) == len(snippets), run.stderr
    assert all(r["CPython"]["Success"] for r in rows)
    for row in rows:
        print(mode, row["Index"], row["Matches"], row["Lython"]["StandardOutput"].strip().replace("\n", " / "),
              [d["Code"] for d in row["Lython"]["Diagnostics"]], row["Lython"]["Failure"])
    if name == "candidate":
        assert all(r["Matches"] for r in rows)

