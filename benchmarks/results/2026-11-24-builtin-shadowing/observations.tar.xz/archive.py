from pathlib import Path
from statistics import median
import hashlib
import json
import shutil
import tarfile

lab = Path(__file__).resolve().parent
root = lab.parents[3]
comparison = lab / "comparison"
out = root / "benchmarks/results/2026-11-24-builtin-shadowing"
read = lambda path: json.loads(path.read_text(encoding="utf-8-sig"))
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
identity = read(comparison / "identity.json")
for role, expected in identity["imageFiles"].items():
    assert len(expected) == 32
    assert {path.name:sha(path) for path in (comparison/role).iterdir()} == expected
    goldens = read(comparison / f"{role}-verify.json")
    assert goldens["state"] == "Completed" and goldens["caseCount"] == 4
    assert goldens["launched"]["library"]["sha256"] == expected["Lokad.Lython.dll"]
assert sha(lab/"candidate.patch") == identity["sourcePatchSHA256"]

raw = read(comparison / "confirmation/confirmation.json")
assert raw["complete"] and raw["sourceRevision"] == identity["sourceRevision"]
assert len(raw["jobs"]) == 6 and all(job["workersJoinedAndFixturesRemoved"] for job in raw["jobs"])
rows=[]
for job in raw["jobs"]:
    assert len(job["samples"]) == 20 and set(job["identities"]) == set(identity["coreSHA256"])
    elapsed, cpu = {}, {}
    for worker, ready in job["identities"].items():
        own_core = next(entry["sha256"] for entry in ready["libraries"] if Path(entry["path"]).name == "Lokad.Lython.dll")
        assert own_core == identity["coreSHA256"][worker]
        assert ready["catalogSha256"] == identity["catalogs"]["representative.json"]["sha256"]
        samples = [sample for sample in job["samples"] if sample["engine"] == worker]
        assert len(samples) == 5
        elapsed[worker] = median(sample["response"]["elapsedTicks"]*1000/sample["response"]["clockFrequency"]/sample["response"]["completedInvocations"] for sample in samples)
        cpu[worker] = median(sample["externalProcessCpuTicks"]*1000/sample["externalCpuFrequency"]/sample["response"]["completedInvocations"] for sample in samples)
    def changes(values):
        comparisons = [(values[c]/values[r]-1)*100 for c in ("candidate","candidate-control") for r in ("reference","reference-control")]
        return [min(comparisons),max(comparisons)]
    spreads = [(max(elapsed[role],elapsed[role+"-control"]) / min(elapsed[role],elapsed[role+"-control"])-1)*100 for role in ("reference","candidate")]
    row = dict(case=job["case"], lane=job["lane"], elapsedPercent=changes(elapsed), cpuPercent=changes(cpu),
               elapsedMediansMs=elapsed, widerCpuMediansMs=cpu, sameSourceElapsedSpreadPercent=spreads)
    print(job["lane"], job["case"], *([f"{n:+.2f}%" for n in row[name]] for name in ("elapsedPercent","cpuPercent","sameSourceElapsedSpreadPercent")))
    rows.append(row)

cases = read(lab/"snippets.json")
assert len(cases) == 22
for role, expected in (("reference", 1),("candidate", 22)):
    for mode in ("sync","async"):
        path = lab / f"{role}-{mode}.jsonl"
        probes = [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines()]
        assert len(probes) == len(cases) and all(probe["CPython"]["Success"] for probe in probes)
        assert sum(probe["Matches"] for probe in probes) == expected
for system in ("windows","ubuntu"):
    assert "Passed:   265" in (lab / f"{system}-public.log").read_text(encoding="utf-8-sig")
    assert "Passed:    32" in (lab / f"{system}-white.log").read_text(encoding="utf-8-sig")

summary = dict(sourcePatch=identity["sourcePatchSHA256"], reference=identity["comparisonRevision"],
               totalBatches=120, elapsedSeconds=raw["elapsedSeconds"], performanceQualified=False, rows=rows)
out.mkdir(exist_ok=True)
(out / "summary.json").write_text(json.dumps(summary,indent=2)+"\n",encoding="utf-8",newline="\n")
shutil.copyfile(comparison/"identity.json",out/"identity.json")
paths = ("archive.py","compare.py","prepare.py","candidate.patch","snippets.json",
         "reference-sync.jsonl","reference-async.jsonl","candidate-sync.jsonl","candidate-async.jsonl",
         "prepare.log","comparison.log","probe-build.log","windows-public.log","windows-white.log",
         "ubuntu-public.log","ubuntu-white.log","test-ubuntu.sh",
         "comparison/representative.json","comparison/jobs.json","comparison/collect.py",
         "comparison/reference-verify.json","comparison/candidate-verify.json","comparison/confirmation/confirmation.json")
with tarfile.open(out/"observations.tar.xz","w:xz") as bundle:
    for name in paths:
        bundle.add(lab/name,arcname=name)
with tarfile.open(out/"observations.tar.xz") as bundle:
    assert all(hashlib.sha256(bundle.extractfile(path).read()).hexdigest() == sha(lab/path) for path in paths)
