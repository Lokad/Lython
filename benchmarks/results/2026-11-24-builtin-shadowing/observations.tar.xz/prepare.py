from pathlib import Path
import hashlib
import json
import os
import shutil
import subprocess

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
previous = lab.parent / "abstract-collection-graphs-20261124"
comparison = lab / "comparison"
comparison.mkdir(exist_ok=True)
read = lambda p: json.loads(p.read_text(encoding="utf-8-sig"))
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
def save(path, value):
    path.write_text(json.dumps(value, indent=2)+"\n", encoding="utf-8", newline="\n")

reference = previous / "candidate"
expected = read(previous / "identity.json")["imageFiles"]["candidate"]
assert len(expected) == 32 and {asset.name: sha(asset) for asset in reference.iterdir()} == expected
core = "Lokad.Lython.dll"
fresh = repo / "tools/LythonProbe/bin/Release/net11.0" / core
assert sha(fresh) != expected[core]
images = dict(reference=expected, candidate=expected | {core:sha(fresh)})
for role, manifest in images.items():
    image = comparison / role
    image.mkdir(exist_ok=True)
    for name in manifest:
        shutil.copyfile(fresh if role=="candidate" and name==core else reference/name, image/name)
    assert {asset.name:sha(asset) for asset in image.iterdir()} == manifest

catalog = comparison / "representative.json"
shutil.copyfile(previous / "catalog.json", catalog)
worker = comparison / "cpython-worker.py"
shutil.copyfile(repo / "benchmarks/cpython-worker.py", worker)
cases = [case["id"] for case in read(catalog)["cases"]]
assert len(cases) == 4
save(comparison/"jobs.json", {"warm":[[case, lane] for case in cases for lane in (("compile","compile-run") if case in cases[:2] else ("compile",))]})

head = subprocess.check_output(["git","rev-parse","HEAD"], cwd=repo, text=True).strip()
assert head.startswith("b65d6bd96")
patch = subprocess.check_output(["git","diff","--binary","--","src","tests"], cwd=repo)
(lab/"candidate.patch").write_bytes(patch)
identity = dict(sourceRevision=head, purpose="Short WSL developer diagnostic for builtin shadowing, no quiet-machine gate", 
                sourcePatchSHA256=sha(lab/"candidate.patch"), comparisonRevision="0bf516c798528ed4ecfa7d3ce78e867043e1b4fd",
                imageFiles=images, cpythonWorkerSHA256=sha(worker),
                coreSHA256={role+suffix: assets[core] for role,assets in images.items() for suffix in ("","-control")},
                catalogs={name: {"sha256":sha(comparison/name)} for name in ("representative.json","jobs.json")})
save(comparison/"identity.json",identity)

sdk=Path.home()/".dotnet11"
dotnet=sdk/"dotnet.exe"
python=Path("C:/Python313/python.exe")
env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk))
for role in images:
    output=comparison/f"{role}-verify.json"
    subprocess.run([dotnet, comparison/role/"Lokad.Lython.Benchmarks.dll", "--compare","verify",
        "--catalog",catalog,"--dotnet",dotnet,"--python",python,"--python-worker",worker,"--out",output],
        check=True,cwd=repo,env=env,timeout=60)
    result=read(output)
    assert result["state"]=="Completed" and result["caseCount"]==len(cases)
    assert result["catalogSha256"]==sha(catalog) and result["launched"]["library"]["sha256"]==images[role][core]

previous_collector=previous/"comparison/quiet/collect.py"
collector=previous_collector.read_text(encoding="utf-8")
collector=collector[:collector.index("def archive(")]
collector=collector.replace("dotnet = Path('/home/lokad/lython-bench-toolchains/dotnet/11.0.100-rc.3.26522.148/dotnet')",
                            "dotnet = Path.home() / '.dotnet/dotnet'")
collector=collector.replace("python = Path('/home/lokad/lython-bench-toolchains/cpython/3.13.16/bin/python3.13')\n","")
start=collector.index("        if not label.startswith('CPython'):")
end=collector.index("        self.request('verify', 2)",start)
collector=collector[:start]+"""        core = next(v for v in self.identity['libraries'] if Path(v['path']).name == 'Lokad.Lython.dll')
        assert core['sha256'].lower() == identity['coreSHA256'][label].lower()
        assert not self.identity['serverGc'] and not any(self.identity['runtimeOverrides'].values())
"""+collector[end:]
collector=collector.replace("    assert digest(python)==identity['expectedCPythonSHA256']\n","")
collector=collector.replace("owned_ram=root/'guest-fixtures'", "owned_ram=Path(tempfile.mkdtemp(prefix='lython-builtin-compare-', dir='/dev/shm'))")
collector=collector.replace("warmupSeconds=8, targetBatchSeconds=.36, rounds=7", "warmupSeconds=2, targetBatchSeconds=.18, rounds=5")
collector=collector.replace("accumulate 8 seconds", "accumulate 2 seconds").replace("range(7)", "range(record['rounds'])")
start=collector.index("    time.sleep(12)")
end=collector.index("    record.update(",start)
collector=collector[:start]+collector[end:]
collector+="""check_image()
try:
    result=warm()
    check_image()
    assert not list(owned_ram.iterdir())
finally:
    owned_ram.rmdir()
"""
(comparison/"collect.py").write_text(collector,encoding="utf-8",newline="\n")
print("Both stable 32-file images passed all four full-output CPython goldens")
