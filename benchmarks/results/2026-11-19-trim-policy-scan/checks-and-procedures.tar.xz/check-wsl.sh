set -e
cd /mnt/d/code/Lython/.git/agent-worktrees/inline-trim-membership-r632
export PATH="$HOME/.dotnet:$PATH"
out=/mnt/d/code/Lython/artifacts/r634-wsl
filter='(FullyQualifiedName~StringStrip|FullyQualifiedName~StringJoinIteration|FullyQualifiedName~StringMethodAccounting|FullyQualifiedName~StringMethodCompatibility|FullyQualifiedName~ExpandedStringArgument|FullyQualifiedName~StringReceiverBinding|FullyQualifiedName~CasedSplit|FullyQualifiedName~Whitespace|FullyQualifiedName~TextCancellation|FullyQualifiedName~GovernedMemoryContractTests)&Category!=Stress'
dotnet test tests/Lokad.Lython.PublicApi.Tests -c Release -f net10.0 --artifacts-path "$out" --filter "$filter"
dotnet test tests/Lokad.Lython.Tests -c Release -f net10.0 --artifacts-path "$out" --filter "$filter"
