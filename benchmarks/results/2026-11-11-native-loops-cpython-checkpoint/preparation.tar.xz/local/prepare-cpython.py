from pathlib import Path
import ast,hashlib,json,shutil,subprocess,tarfile
r=Path(__file__).resolve().parent;q=r/'b577';q.mkdir(exist_ok=False)
old=r.parent/'patch-workflow-r229/b573';prior=r/'b576';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();assert head.startswith('fe6648b2')
meta=json.loads((r/'diagnostic-identity.json').read_text(encoding='utf-8'))
for name,h in meta['sourceHashes'].items():assert sha(Path(name))==h,name
catalog=json.loads((r/'catalog.json').read_text(encoding='utf-8'))
# Keep the published CSV shape, rather than silently replacing it with the
# separately maintained captured-builtin variant used in source-pair controls.
with tarfile.open('benchmarks/results/2026-11-10-construction-cpython-checkpoint/observations.tgz')as t:
 original={c['id']:c for c in json.load(t.extractfile('representative.json'))['cases']}
case_id='scripts.csv-validated-records.large'
catalog['cases']=[original[case_id]if c['id']==case_id else c for c in catalog['cases']]
with tarfile.open('benchmarks/results/2026-11-11-text-cpython-checkpoint/observations.tgz')as t:
 text_cases={c['id']:c for c in json.load(t.extractfile('representative.json'))['cases']}
for c in catalog['cases']:
 if c['id'].startswith('scripts.text-summary-helpers'):
  assert all(c[k]==text_cases[c['id']][k]for k in ['sourceSha256','fixtureSha256','expectedOutputSha256']),c['id']
(q/'representative.json').write_text(json.dumps(catalog,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
root='/home/lokad/lython-bench-checks/native-loops-cpython-b577-20261111';unit='lython-b577-native-loops-cpython-20261111'
identity=json.loads((prior/'identity.json').read_text(encoding='utf-8'))
identity.update(sourceRevision='Committedfe6648b2 exact568 production sources; measured frozen precommit core from1ce metadata. Both text and original CSV shapes unchanged from their published CPython checkpoints. Core qualified with2692 focused actual11/10 checks; full exactfe delivery in progress separately.',coreSHA256={role:meta['images']['candidate']['Lokad.Lython.dll']for role in ['candidate','candidate-control']},catalogSHA256=sha(q/'representative.json'))
(q/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8')
(q/'source-identity.json').write_text(json.dumps(dict(revision=head,coreIsMeasuredPrecommitFreeze=True,sourceSHA256=meta['sourceHashes'],coreSHA256=meta['images']['candidate']['Lokad.Lython.dll'],fullQualification='Pending exactfe Windows/Ubuntu actual11/10, originalStress and installed consumers; do not imply completion.'),indent=2)+'\n',encoding='utf-8')
jobs=[[case,lane]for case in ['scripts.text-summary-helpers.nonlocal-counter.large','scripts.text-summary-helpers.large','scripts.csv-validated-records.large']for lane in ['compile','warm','compile-run']]
text=(old/'collect.py').read_text(encoding='utf-8').replace('/patch-cpython-b573-20261111','/native-loops-cpython-b577-20261111')
begin=text.index('jobs=');end=text.index('\nenv = ',begin)
text=text[:begin]+'jobs='+repr(jobs)+'\nassert len(jobs)==9 and all(case in cases for case,lane in jobs)\n'+text[end:]
text=text.replace("< 140, 'Reserve40seconds","< 290, 'Reserve40seconds")
begin=text.index("purpose='R229");end=text.index("',\n                  warmupSeconds",begin)
text=text[:begin]+"purpose='R237 retainedfe6648b2 versus stockCPython3.13.16, two unchanged text scripts and original CSV validation. Separate compile/warm/compile-run. Warm and compile-run include mediated RAM I/O/full output checks/prior-result cleanup, exclude startup/reset/protocol/final caches. No individual source-change attribution"+text[end:]
ast.parse(text);(q/'collect.py').write_text(text,encoding='utf-8',newline='\n')
for name in ['archive-owned.py','run.sh','retrieve.py','summarize.py']:
 text=(prior/name).read_text(encoding='utf-8').replace('native-counter-loops-b576','native-loops-cpython-b577').replace('lython-b576-native-counter-loops','lython-b577-native-loops-cpython').replace('==5','==9').replace('jobs=5','jobs=9').replace("jobs']==5","jobs']==9").replace("elapsedSeconds']<210","elapsedSeconds']<330").replace('B576 five-job','B577 nine-job')
 if name=='summarize.py':text=(old/name).read_text(encoding='utf-8').replace('==4','==9')
 if name.endswith('.py'):ast.parse(text)
 (q/name).write_text(text,encoding='utf-8',newline='\n')
text=(prior/'launch.py').read_text(encoding='utf-8').replace('native-counter-loops-b576-launch','native-loops-cpython-b577-launch').replace('seconds=270','seconds=390').replace('ownerSeconds=210','ownerSeconds=330')
(q/'launch.py').write_text(text,encoding='utf-8',newline='\n')
with tarfile.open(q/'payload.tgz','w:gz')as t:
 for name in ['representative.json','source-identity.json','identity.json','collect.py','archive-owned.py','run.sh']:t.add(q/name,arcname=name)
with tarfile.open(q/'payload.tgz')as t:expanded=sum(((m.size+4095)//4096)*4096 for m in t.getmembers())
config=dict(root=root,unit=unit,payloadBytes=(q/'payload.tgz').stat().st_size,payloadSHA256=sha(q/'payload.tgz'),requiredFreeBytes=252*1024*1024+expanded+65536,retire=[],identity=identity)
(q/'config.json').write_text(json.dumps(config,indent=2)+'\n',encoding='utf-8')
text=(prior/'remote-launch.py').read_text(encoding='utf-8').replace("source=base/'constructor-binding-b574-20261111/candidate'","source=base/'native-counter-loops-b576-20261111/candidate'")
text=text.replace("with(base/'comparison-vm.lock')", "protected[source/'Lokad.Lython.dll']=config['identity']['coreSHA256']['candidate']\nwith(base/'comparison-vm.lock')")
begin=text.index(" for role in ['reference','candidate']:shutil.copytree")
end=text.index(" shutil.copyfile(protocol",begin)
text=text[:begin]+" os.link(source/'Lokad.Lython.dll',root/'current-core.dll')\n shutil.copytree(source,root/'candidate',copy_function=os.link)\n assert digest(root/'candidate/Lokad.Lython.dll')==config['identity']['coreSHA256']['candidate']\n"+text[end:]
text=text.replace('lython-b576-fixtures','lython-b577-fixtures').replace('jobs=5','jobs=9').replace('ownerSeconds=210','ownerSeconds=330').replace('RuntimeMaxSec=210','RuntimeMaxSec=330')
ast.parse(text.replace('config=CONFIG','config='+repr(config)).replace('inventoryOnly=INVENTORY_ONLY','inventoryOnly=True'))
(q/'remote-launch.py').write_text(text,encoding='utf-8',newline='\n')
print('Prepared9 bounded CPython jobs:3scripts x compile/warm/compile-run.330sowner, no new core upload or retirement; source shapes verified against historical external baselines.')
