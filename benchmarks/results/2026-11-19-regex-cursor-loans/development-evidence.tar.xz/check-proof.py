from pathlib import Path
import hashlib,json,os,subprocess
lab=Path(__file__).resolve().parent
identity=json.loads((lab/'image-identity.json').read_text(encoding='utf-8'))
sdk=Path.home()/'.dotnet11'
env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk),PATH=str(sdk)+os.pathsep+os.environ['PATH'])
rows=[]
for target in ('net11.0','net10.0'):
    image=lab/'proof/bin/Release'/target
    expected=identity['images'][target]
    for name,digest in expected.items():
        if 'Tests' not in name:assert hashlib.sha256((image/name).read_bytes()).hexdigest()==digest
    for stage in ('funding','compile','match','cursor'):
        result=subprocess.run([sdk/'dotnet.exe',image/'Proof.dll',*([stage] if stage!='funding' else [])],
                              env=env,timeout=25,capture_output=True)
        name=f'{target}-{stage}'
        (lab/(name+'.json')).write_bytes(result.stdout)
        (lab/(name+'.stderr')).write_bytes(result.stderr)
        row=dict(framework=target,stage=stage,exitCode=result.returncode)
        if result.returncode==0:
            row.update(json.loads(result.stdout))
        else:row['stderr']=result.stderr.decode('utf-8',errors='replace')
        rows.append(row)
        print(row,flush=True)
(lab/'proof-result.json').write_text(json.dumps(rows,indent=2)+'\n',encoding='utf-8')
assert all(row['exitCode']==0 for row in rows)