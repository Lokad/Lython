from pathlib import Path
import hashlib,json,os,shutil,subprocess,zipfile

lab=Path(__file__).resolve().parent
root=Path.cwd()
prior=lab.parent/'regex-dev106-r543'
producer=Path('D:/code/utf8regex/artifacts/package-candidates/0.5.0-dev.107')
sha=lambda bytes_:hashlib.sha256(bytes_).hexdigest()
receipt=json.loads((producer/'candidate.json').read_text(encoding='utf-8-sig'))
assert receipt['PackageVersion']=='0.5.0-dev.107' and receipt['CleanSource'] and not receipt['Published']
assert receipt['SourceRevision']=='7be42c66c60a63afea78523cd26df8ecc108316a'
for target in ('net11.0','net10.0'):
    bindir=lab/'binaries'/target
    bindir.mkdir(parents=True)
    hashes={}
    for row in receipt['Packages']:
        if row['Id'] not in ('Lokad.Utf8Regex','Lokad.Utf8Regex.PythonRe') or row['TargetFramework']!=target:
            continue
        package=producer/row['RelativePath']
        assert sha(package.read_bytes())==row['PackageSha256'].lower()
        with zipfile.ZipFile(package) as z:
            dll=z.read(f"lib/{target}/{row['Id']}.dll")
        assert sha(dll)==row['AssemblySha256'].lower()
        (bindir/(row['Id']+'.dll')).write_bytes(dll)
        hashes[row['Id']]=sha(dll)
    assert len(hashes)==2

source=(prior/'adapter/Utf8RegexProvider.cs').read_text(encoding='utf-8-sig')
def replace(old,new):
    global source
    assert source.count(old)==1,old
    source=source.replace(old,new)
replace('''        catch (PythonRePatternException error)
        { throw PatternError(error, token, utf8Pattern, patternSource); }''','''        catch (Utf8MemoryAdmissionException error)
        { throw ProducerAdmission(error); }
        catch (PythonRePatternException error)
        { throw PatternError(error, token, utf8Pattern, patternSource); }''')
anchor='    private static LythonRegexException PatternError(PythonRePatternException error, CancellationToken token,'
replace(anchor,'''    private static LythonRegexException ProducerAdmission(Utf8MemoryAdmissionException error)
        => new(LythonRegexFailure.MemoryAdmission, error.Message,
            requestedBytes: error.RequestedBytes <= long.MaxValue ? (long)error.RequestedBytes : null);

'''+anchor)
replace('''                    Reserve(_owner, subject.MatchBytes);
                    using var registration = Forward(token);
                    _cursor = Backend(() => subject.Pattern.Regex.CreateMatchCursor(subject.BoundedInput, subject._startByte, _cancellation.Token), token, patternSource: subject.Pattern.Regex);
                }
                catch { Dispose(); throw; }
            }

            private CancellationTokenRegistration Forward(CancellationToken token)
                => token.Register(static state => ((CancellationTokenSource)state!).Cancel(), _cancellation);''','''                    // Admit the adapter cursor and its managed wrappers before producer setup.
                    var allowance = new CursorAllowance(Reserve(_owner, 256));
                    using (token.Register(static state => ((CancellationTokenSource)state!).Cancel(), _cancellation))
                    {
                        _cursor = Backend(() => subject.Pattern.Regex.CreateMatchCursor(subject.BoundedInput,
                            subject._startByte, _cancellation.Token, workingMemoryAllowance: allowance),
                            token, patternSource: subject.Pattern.Regex);
                    }
                    token.ThrowIfCancellationRequested();
                }
                catch (OperationCanceledException) when (token.IsCancellationRequested)
                { Dispose(); throw new OperationCanceledException(token); }
                catch { Dispose(); throw; }
            }''')
replace('''                    if (Advance(token, out var data))
                    {
                        CopyCaptures(data, captures, token);
                        lastIndex = data.LastIndex;
                        return true;
                    }''','''                    if (Advance(token, out var funded))
                    {
                        using (funded)
                        {
                            var data = funded!.Match;
                            CopyCaptures(data, captures, token);
                            lastIndex = data.LastIndex;
                        }
                        return true;
                    }''')
replace('''            private bool Advance(CancellationToken token, out Utf8PythonRangeMatch data)
            {
                try { return _cursor!.MoveNext(out data, token); }
                catch (PythonRePatternException error)''','''            private bool Advance(CancellationToken token, out Utf8PythonRetainedRangeMatch? data)
            {
                try { return _cursor!.MoveNextRetained(out data, token); }
                catch (Utf8MemoryAdmissionException error)
                { throw ProducerAdmission(error); }
                catch (PythonRePatternException error)''')
anchor='''        private sealed class Cursor : ILythonRegexCursor'''
replace(anchor,'''        private sealed class CursorAllowance(ILythonMemoryReservation reservation) : IUtf8MemoryAllowance
        {
            private readonly object _gate = new();
            private readonly long _baseBytes = reservation.Bytes;
            private long _producerBytes;

            public bool TryReserve(ulong bytes)
            {
                lock (_gate)
                {
                    if (bytes > (ulong)(long.MaxValue - _baseBytes - _producerBytes)) return false;
                    var next = _producerBytes + (long)bytes;
                    if (next + _baseBytes > reservation.Bytes && !reservation.TryResize(next + _baseBytes))
                        return false;
                    _producerBytes = next;
                    return true;
                }
            }

            public void Release(ulong bytes)
            {
                lock (_gate)
                {
                    _producerBytes -= (long)bytes;
                    // The producer releases the exact amount it received. A host
                    // that declines a shrink leaves conservative funding until close.
                    reservation.TryResize(_baseBytes + _producerBytes);
                }
            }
        }

'''+anchor)
(lab/'adapter/Utf8RegexProvider.cs').write_text(source,encoding='utf-8',newline='\n')
project=(prior/'adapter/Adapter.csproj').read_text(encoding='utf-8')
project=project.replace(prior.as_posix(),lab.as_posix())
(lab/'adapter/Adapter.csproj').write_text(project,encoding='utf-8',newline='\n')
sdk=Path.home()/'.dotnet11'
dotnet=sdk/'dotnet.exe'
env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk),DOTNET_HOST_PATH=str(dotnet),PATH=str(sdk)+os.pathsep+os.environ['PATH'])
with (lab/'build.log').open('wb') as log:
    subprocess.run([dotnet,'build',lab/'adapter/Adapter.csproj','-c','Release','--no-incremental'],
                   env=env,stdout=log,stderr=subprocess.STDOUT,timeout=100,check=True)
hashes={}
for target in ('net11.0','net10.0'):
    image=lab/'consumers'/target
    shutil.copytree(prior/'consumers'/target,image,copy_function=shutil.copyfile)
    fixture=image/'tests/Lokad.Lython.WorkerFixture/bin/Release'/target
    for filename in ('Lokad.Lython.Utf8Regex.dll','Lokad.Utf8Regex.PythonRe.dll','Lokad.Utf8Regex.dll'):
        source=(lab/'adapter/bin/Release'/target/filename if filename=='Lokad.Lython.Utf8Regex.dll'
                else lab/'binaries'/target/filename)
        shutil.copyfile(source,image/filename)
        shutil.copyfile(source,fixture/filename)
        assert sha((image/filename).read_bytes())==sha((fixture/filename).read_bytes())
    hashes[target]={n:sha((image/n).read_bytes()) for n in ('Lokad.Lython.dll','Lokad.Lython.Utf8Regex.dll',
                    'Lokad.Utf8Regex.dll','Lokad.Utf8Regex.PythonRe.dll','Lokad.Lython.PublicApi.Tests.dll')}
(lab/'image-identity.json').write_text(json.dumps(dict(images=hashes,producer=receipt['SourceRevision'],
    packageVersion=receipt['PackageVersion'],retainedCursorLoans=True),indent=2)+'\n',encoding='utf-8')
shutil.copyfile(prior/'qualify.py',lab/'qualify.py')
print('Built the exact dev.107 adapter images with retained cursor range loans.')