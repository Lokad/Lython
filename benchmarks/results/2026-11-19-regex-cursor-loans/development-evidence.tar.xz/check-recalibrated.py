from pathlib import Path
import hashlib,json,os,shutil,subprocess,xml.etree.ElementTree as E
lab=Path(__file__).resolve().parent
identity=json.loads((lab/'image-identity.json').read_text(encoding='utf-8'))
sdk=Path.home()/'.dotnet11'
dotnet=sdk/'dotnet.exe'
env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk),DOTNET_HOST_PATH=str(dotnet),
         PATH=str(sdk)+os.pathsep+os.environ['PATH'])
sha=lambda path:hashlib.sha256(path.read_bytes()).hexdigest()
rows=[]
child='Lokad.Lython.WorkerFixture'
for target in ('net11.0','net10.0'):
    image=lab/'recalibrated-consumers'/target
    shutil.copytree(lab/'consumers'/target,image,copy_function=shutil.copyfile)
    fixture=image/f'tests/{child}/bin/Release'/target
    output=lab/'recalibrated-worker'/target
    with (lab/f'worker-{target}.log').open('wb') as log:
        subprocess.run([dotnet,'build',lab/'proof/Proof.csproj','-c','Release','-f',target,'--no-incremental',
                        f'-p:AssemblyName={child}','--output',output],env=env,stdout=log,stderr=subprocess.STDOUT,timeout=90,check=True)
    for extension in ('dll','deps.json','runtimeconfig.json'):
        name=f'{child}.{extension}'
        shutil.copyfile(output/name,fixture/name)
    for name,digest in identity['images'][target].items():
        assert sha(image/name)==digest
        if 'Tests' not in name:
            assert sha(fixture/name)==digest==sha(output/name)
    check=lab/'recalibrated-checks'/target
    check.mkdir(parents=True)
    with (check/'test.log').open('wb') as log:
        process=subprocess.run([dotnet,'vstest',image/'Lokad.Lython.PublicApi.Tests.dll',
                    '--TestCaseFilter:Category!=Stress&FullyQualifiedName~Regex',
                    '--Logger:trx;LogFileName=regex.trx',f'--ResultsDirectory:{check}'],
                    env=env,stdout=log,stderr=subprocess.STDOUT,timeout=100)
    counters=E.parse(check/'regex.trx').find('.//{http://microsoft.com/schemas/VisualStudio/TeamTest/2010}Counters').attrib
    row=dict(framework=target,exitCode=process.returncode,counts=counters,fixtureSHA256=sha(fixture/f'{child}.dll'))
    rows.append(row)
    print(row,flush=True)
(lab/'recalibrated-checks.json').write_text(json.dumps(rows,indent=2)+'\n',encoding='utf-8')
assert all(row['exitCode']==0 for row in rows)