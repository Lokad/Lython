using System.Diagnostics.CodeAnalysis;
using System.Text.Json;
using Lokad.Lython;
using Lokad.Lython.Utf8Regex;

if (args is ["regex-cancellation", var stage]) return RegexCancellationFixture.Run(stage);
if (args.Length != 0) return RegexCancellationFixture.Run(args[0]);

var programBudget = new LythonMemoryBudget();
var working = new ObservedBudget(new LythonMemoryBudget());
using var pattern = Utf8RegexProvider.Instance.Compile("(?P<left>a+)(?P<right>b)"u8.ToArray(), new(32, false), programBudget, default);
using var subject = pattern.Prepare("aaaabaaaab"u8.ToArray(), new(0, 10, 0, 10), working, default);
var captures = new LythonRegexCapture?[pattern.CaptureSlotCount];
using var earlier = new CancellationTokenSource();

using (var cursor = subject.Find(earlier.Token))
{
    earlier.Cancel();
    var before = working.Current;
    Check(cursor.TryNext(captures, out var lastIndex, default) && lastIndex == 2, "first pull");
    Check(captures[0] == new LythonRegexCapture(0, 5) && captures[1] == new LythonRegexCapture(0, 4) &&
          captures[2] == new LythonRegexCapture(4, 5), "capture coordinates");
    Check(working.Growths > 0 && working.Shrinks > 0 && working.Peak > before, "producer temporary funding");
}
Check(working.Current == 0, "refund after cursor retirement");
using (var cursor = subject.Find(default))
{
    working.RefuseGrowth = true;
    try
    {
        _ = cursor.TryNext(captures, out _, default);
        throw new InvalidOperationException("producer admission should have failed");
    }
    catch (LythonRegexException error)
    {
        Check(error.Failure == LythonRegexFailure.MemoryAdmission && error.RequestedBytes == working.RefusedAmount,
            "exact admission origin");
    }
    finally { working.RefuseGrowth = false; }
    Check(working.Refusals == 1 && working.Current == 0, "no retry and terminal cleanup");
}
using (var cursor = subject.Find(default))
    Check(cursor.TryNext(captures, out _, default), "owner remains usable");
Check(working.Current == 0, "final refund");
Console.WriteLine(JsonSerializer.Serialize(new
{
    working.Growths, working.Shrinks, working.Peak, working.Refusals, working.RefusedAmount, working.Current
}));
return 0;

static void Check(bool value, string stage)
{
    if (!value) throw new InvalidOperationException(stage);
}

sealed class ObservedBudget(LythonMemoryBudget inner) : ILythonMemoryBudget
{
    public int Growths { get; private set; }
    public int Shrinks { get; private set; }
    public int Refusals { get; private set; }
    public long RefusedAmount { get; private set; }
    public long Current => inner.ReservedBytes;
    public long Peak { get; private set; }
    public bool RefuseGrowth { get; set; }

    public ILythonMemoryScope CreateScope() => new Scope(this, inner.CreateScope());
    public bool TryReserve(long bytes, [NotNullWhen(true)] out ILythonMemoryReservation? reservation)
        => Reserve(this, inner, bytes, out reservation);

    private static bool Reserve(ObservedBudget budget, ILythonMemoryBudget inner, long bytes,
        [NotNullWhen(true)] out ILythonMemoryReservation? reservation)
    {
        reservation = inner.TryReserve(bytes, out var acquired) ? new Reservation(budget, acquired) : null;
        return reservation is not null;
    }

    private sealed class Scope(ObservedBudget budget, ILythonMemoryScope inner) : ILythonMemoryScope
    {
        public ILythonMemoryScope CreateScope() => new Scope(budget, inner.CreateScope());
        public bool TryReserve(long bytes, [NotNullWhen(true)] out ILythonMemoryReservation? reservation)
            => Reserve(budget, inner, bytes, out reservation);
        public void Dispose() => inner.Dispose();
    }

    private sealed class Reservation(ObservedBudget budget, ILythonMemoryReservation inner) : ILythonMemoryReservation
    {
        public long Bytes => inner.Bytes;
        public bool TryResize(long bytes)
        {
            var delta = bytes - inner.Bytes;
            if (delta > 0 && budget.RefuseGrowth)
            {
                budget.Refusals++;
                budget.RefusedAmount = delta;
                return false;
            }
            if (!inner.TryResize(bytes)) return false;
            if (delta > 0) budget.Growths++;
            if (delta < 0) budget.Shrinks++;
            budget.Peak = Math.Max(budget.Peak, budget.Current);
            return true;
        }
        public void Dispose() => inner.Dispose();
    }
}