from pathlib import Path
import json,os,subprocess
r=Path(__file__).parent;d=r/'original-stack-condition';d.mkdir();env=dict(os.environ);sdk='C:/Users/JoannesVermorel/.dotnet11';env.update(DOTNET_ROOT=sdk,DOTNET_ROOT_X64=sdk,DOTNET_PROCESSOR_COUNT='1');rows=[]
for label,framework,core in [('candidate11-repeat','net11.0',Path('src/Lokad.Lython/bin/Release/net11.0/Lokad.Lython.dll')),('candidate10','net10.0',Path('src/Lokad.Lython/bin/Release/net10.0/Lokad.Lython.dll')),('baseline11','net11.0',r.parent/'line-construction-r430/frozen/candidate/Lokad.Lython.dll')]:
 fixture=Path('tests/Lokad.Lython.WorkerFixture/bin/Release')/framework/'Lokad.Lython.WorkerFixture.dll';p=subprocess.run([sdk+'/dotnet.exe',str(fixture.resolve()),'stack-guard',str(core.resolve()),'native-call-continuation'],env=env,capture_output=True,text=True,encoding='utf-8',timeout=25)
 row=dict(label=label,framework=framework,exitCode=p.returncode,stdout=p.stdout,stderr=p.stderr);rows.append(row);print(json.dumps(row),flush=True)
(d/'controlled-observations.json').write_text(json.dumps(rows,indent=2)+'\n',encoding='utf-8',newline='\n')
