from pathlib import Path
import hashlib,json,shutil,subprocess,tarfile
r=Path(__file__).parent;q=r/'quiet';out=Path('benchmarks/results/2026-11-16-completed-async-entry');out.mkdir()
receipt=json.loads((q/'archive-receipt.json').read_text(encoding='utf-8'));assert receipt['complete']and receipt['allWorkersJoined']and receipt['quietBeforeAndAfter']
assert hashlib.sha256((q/'observations.tgz').read_bytes()).hexdigest()==receipt['archiveSHA256']
v=json.loads((r/'summary.json').read_text(encoding='utf-8'));assert v['complete'];v.update(retentionDecisionPending=False,retained=False,fullQualificationRequiredForWithdrawnRuntime=False,decision='Withdraw runtime prototype. Completed-entry state traffic is plausible, but two new handwritten control layers add83net runtime lines without material allocation reduction or a whole-frame simplification. Normalization async is lower with moving reference; protected search is inconclusive and synchronous controls move. Not a failed design or a fixed-percent veto: reconsider only with a changed integration removing existing machinery or demonstrated representative dominance. Preserve useful independent held-operation fixture correction; fully qualifiedecd runtime restored.')
(out/'summary.json').write_text(json.dumps(v,indent=2)+'\n',encoding='utf-8',newline='\n')
for name in ['identity.json','observations.tgz','archive-receipt.json','terminal-status.json']:shutil.copyfile(q/name,out/name)
for name in ['allocation-summary.json','focused-checks.json','selection.json']:shutil.copyfile(r/name,out/name)
shutil.copyfile(r/'frozen/sources-and-checks.tar.xz',out/'candidate-source-and-checks.tar.xz')
with tarfile.open(out/'procedure-and-prototype.tar.xz','w:xz')as a:
 for name in ['identity.json','candidate/Lokad.Lython.dll']:a.add(r/'frozen'/name,arcname='frozen/'+name)
 for p in sorted(r.glob('*.py')):a.add(p,arcname='procedure/'+p.name)
 for name in ['build.log','fixture-build.log','historical-aliases.json']:a.add(r/name,arcname=name)
 for folder in ['original','original-stack-condition','minimal-fixture-condition']:
  for p in sorted((r/folder).rglob('*')):
   if p.is_file()and 'baseline11'not in p.parts:a.add(p,arcname=p.relative_to(r).as_posix())
 for name in ['Program.cs','Allocation.csproj','build.log','reference.json','candidate.json']:
  p=r/'allocation-short'/name
  if p.exists():a.add(p,arcname='allocation-short/'+name)
 for p in sorted(q.iterdir()):
  if p.is_file()and p.name not in ['observations.tgz','payload.tgz']:a.add(p,arcname='quiet/'+p.name)
selection=json.loads((r/'selection.json').read_text(encoding='utf-8'))
for n,h in selection['paths'].items():
 old=(r/'original'/n).read_bytes();assert hashlib.sha256(old).hexdigest()==h
 committed=subprocess.check_output(['git','show','HEAD:'+n]);assert old.replace(b'\r\n',b'\n')==committed.replace(b'\r\n',b'\n')
 Path(n).write_bytes(old)
(out/'README.md').write_text('''# Completed async entry: withdrawn prototype

R433/B830,2026-11-16UTC: candidate **7c592066** versus fully qualified
**86d9344e /ecd9e956**. Candidate never committed to production or fully qualified.
The source, exact candidate core, all original failures and controls are preserved.

**Decision: withdraw the runtime change.** Plain completed prefixes and one pending
continuation avoid entering two generated async bodies for completed calls/yields,
but add83net runtime lines and retain the existing instruction/exception machine.
They remove no argument/frame storage or complete execution representation.
Whole-job allocation and accounting peaks are effectively unchanged. Lower async
normalization time alone does not justify the additional control-flow machinery.
This is a complexity/evidence decision, not a rigid improvement cutoff, failed
design or permanent prohibition. A coherent replacement with changed evidence is
still eligible. No remaining performance debt is introduced by withdrawn code.

| Complete warm job | Elapsed candidate/reference | Wider CPU | Ref/candidate median spreads |
| --- | ---: | ---: | ---: |
| Async normalization | −7.70..−1.76% | −8.12..−0.76% | 5.49/0.90% |
| Sync normalization control | −4.10..−0.48% | −4.23..+0.73% | 0.41/3.35% |
| Async protected file search | −3.98..+3.34% | −3.42..+1.59% | 2.14/5.37% |
| Sync JSON control | −0.40..+2.18% | 0..+2.72% | 1.43/1.15% |

All four process pairings, not confidence intervals. Five rotated approximately
0.5s batches after5s full-request warmup, two processes/source;140.053s and all
image/golden/quiet/Closed/exit/join/archive gates. Reference/control movement limits
precise attribution; all adverse samples retained. Local natural-GC whole-job
allocation changes are −0.0067%,−0.0030%,0%,+0.0114%; accounting peaks unchanged.
No allocation, synchronous-CPU, startup or embedding-tail improvement is claimed.

Same F4as_v7/Ubuntu24.04.4,four EPYC9V45vCPUs,16GiB/no swap,.NET11RC3
normal tiering/workstation GC. Warm includes mediated RAM I/O, full stdout/file
goldens and prior-result cleanup; excludes compilation/startup, reset/protocol and
final cache teardown. Wider process CPU includes reset/protocol. The host completes
I/O synchronously; pending operations are correctness-tested, not latency-benchmarked.
No CPython refresh, heap/RSS or contention measurement. This candidate could not
explain the published synchronous CPython gap.

Candidate focused actual.NET11/10 each128internal/495public pass, including
generators, closures/protocols, cancellation/refusal, retained owners and pending
cleanup. The initial public run failed only a controlled subprocess thread-placement
assertion: guest recursion/recovery succeeded and budget returned to zero, but an
extra fixture async wrapper let the CLR continuation hop off the owned256KiB stack.
Returning the actual held operation removes that wrapper; all original physical
owned-thread/256KiB/deadline/recovery/refund assertions remain. Three candidate
checks eachactual11/10 and onebaseline11 pass. An earlier baseline attempt was
rejected by its binary-hash guard and proves no baseline behavior; original evidence
is retained. Keep this fixture correction independently and verify it after restoring
the qualified runtime; it does not change managed stack policy.

Persistent archive hash-verified before owned RAM teardown; all users joined.
Only exact committed working replicas were retired with fresh lease/path/ownership/
hash/all-alias proof. Current images/catalogs/toolchains and254/252MiB floors kept.
Terminal cached. Publication remains held; whole-script performance work continues.

[All controls](summary.json),[raw observations](observations.tgz),
[allocation](allocation-summary.json),[candidate checks](focused-checks.json),
[complete candidate source/checks](candidate-source-and-checks.tar.xz),
[prototype/procedures/original failures](procedure-and-prototype.tar.xz).
Baseline auxiliary images are unchanged from the
[retained line-construction image](../2026-11-16-line-construction/README.md).
''',encoding='utf-8',newline='\n')
p=Path('benchmarks/EXPERIMENTS.md');s=p.read_text(encoding='utf-8');s+='\n\n[R433/B830 completed async entry withdrawn](results/2026-11-16-completed-async-entry/README.md):7c592066/ecd9e956,140.053s/all gates; allocation/peaks flat. Async normalization elapsed1.76–7.70%lower with5.49%moving reference; protected search mixed and sync controls move. Two handwritten entry layers add83net runtime lines, displace no complete frame/storage representation. Withdraw for complexity/evidence; not a fixed threshold or permanent ban. Exact source, original fixture placement failures and invalid baseline hash attempt retained; minimal held-operation fixture correction kept independently, original256KiB/owned-thread/refund assertions intact. No new production debt; broader objective open.\n';p.write_text(s,encoding='utf-8',newline='\n')
p=Path('PLAN.md');s=p.read_text(encoding='utf-8');a=s.index('| Active uncommitted prototype | **R433');b=s.index('\n| Latest external baseline |',a);s=s[:a]+'''| Withdrawn measured prototype; independent fixture correction active | **R433 /7c592066** completed async entry removed; qualifiedecd9 runtime restored. [B830](benchmarks/results/2026-11-16-completed-async-entry/README.md):140.053s/all gates, allocation/peaks flat. Async normalization lower with5.49%moving reference; search/control uncertainty. Added control layers displace no entire frame/storage stage. Candidate128internal/495public eachactual11/10; original fixture-placement failures preserved. Minimal held-operation fixture retains256KiB/owned-thread/refund assertions; restored-runtime checks next. |'''+s[b:]
a=s.index('3. **R433 selected:');b=s.index('\n4. **Next substantial-cost',a);s=s[:a]+'''3. **R433 decision complete; fixture correction verification next.** Withdraw two
   handwritten completed-entry layers: allocation/peaks flat, source complexity
   increases, moving controls and mixed protected search. Original source/results/
   failures preserved; a changed integrated design remains eligible. Restore the
   fully qualified runtime, verify the independent minimal held-operation fixture
   on actual11/10, then commit that correction/evidence. No repeated unchanged full
   runtime qualification. This experiment does not complete the performance objective.
'''+s[b:]
p.write_text(s,encoding='utf-8',newline='\n');print('R433 prototype evidence retained; runtime restored exactly, independent fixture correction remains.')
