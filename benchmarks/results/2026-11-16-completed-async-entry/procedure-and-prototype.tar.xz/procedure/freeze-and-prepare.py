from pathlib import Path
import hashlib,json,shutil,subprocess,tarfile,xml.etree.ElementTree as E
r=Path(__file__).parent;base=r.parent/'line-construction-r430';f=r/'frozen';f.mkdir();v=json.loads((base/'frozen/identity.json').read_text(encoding='utf-8'));images={}
for role in ['reference','candidate']:
 target=f/role;shutil.copytree(base/'frozen/candidate',target)
 if role=='candidate':shutil.copyfile('src/Lokad.Lython/bin/Release/net11.0/Lokad.Lython.dll',target/'Lokad.Lython.dll')
 images[role]={p.name:hashlib.sha256(p.read_bytes()).hexdigest()for p in target.iterdir()if p.is_file()}
assert images['reference']['Lokad.Lython.dll']=='ecd9e956b007224f927de3c722c612668da094529aa125ca6adcd456184eaab2'
assert all(images['candidate'][n]==h for n,h in images['reference'].items()if n!='Lokad.Lython.dll')
paths=list(v['sources'])+['tests/Lokad.Lython.WorkerFixture/NativeCallStackFixture.cs'];assert len(set(paths))==601
with tarfile.open(f/'sources-and-checks.tar.xz','w:xz')as a:
 for n in paths:a.add(n,arcname=n)
 for n in ['checks','second-checks']:a.add(r/n,arcname=n)
v.update(buildSourceCommit=json.loads((r/'selection.json').read_text(encoding='utf-8'))['baseCommit'],sourceSnapshotCommit=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),prototype=True,images=images,sources={n:hashlib.sha256(Path(n).read_bytes()).hexdigest()for n in paths},contracts='Completed async call runner and generator yields use ordinary prefixes; actual pending/cleanup/fault users keep awaited frame ownership. Synchronous runner and instruction engine retained. No new controller/view/cache/option. Minimal held test operation preserves256KiB/owned-thread/refund assertions; original placement failure archived.')
(f/'identity.json').write_text(json.dumps(v,indent=2)+'\n',encoding='utf-8',newline='\n')
ns={'t':'http://microsoft.com/schemas/VisualStudio/TeamTest/2010'};selected=[r/'checks/r433-internal-net11.0.trx',r/'second-checks/r433-internal-net10.0.trx',r/'second-checks/r433-public-net11.0.trx',r/'second-checks/r433-public-net10.0.trx'];checks=[dict(file=str(p.relative_to(r)),**E.parse(p).find('t:ResultSummary/t:Counters',ns).attrib)for p in selected];assert sorted(int(x['passed'])for x in checks)==[128,128,495,495]and all(x['failed']=='0'for x in checks)
(r/'focused-checks.json').write_text(json.dumps(dict(checks=checks,nonincrementalReleaseBuild=True,fixtureOnlyFinalBuildNoDependencies=True,fullQualificationPending=True,originalFixturePlacementFailurePreserved=True,smallManagedStackAndOwnedThreadAssertionsUnchanged=True),indent=2)+'\n',encoding='utf-8',newline='\n')
catalog=json.loads((base/'catalog.json').read_text(encoding='utf-8'))
with tarfile.open('benchmarks/results/2026-11-15-store-cpython-checkpoint/observations.tgz')as a:older=json.loads(a.extractfile('representative.json').read())
search=next(c for c in older['cases']if c['id']=='scripts.file-search.large.protected')
extra=dict(catalog);extra['cases']=[search]
(r/'extra.json').write_text(json.dumps(extra,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
catalog['cases']=[next(c for c in catalog['cases']if c['id']=='scripts.text-normalization.large'),search,next(c for c in catalog['cases']if c['id']=='scripts.json-summary-helpers.large')]
for c in catalog['cases']:
 for field,text in [('sourceSha256','source'),('fixtureSha256','fixtureJson'),('expectedOutputSha256','expectedOutput')]:assert hashlib.sha256(c[text].encode()).hexdigest()==c[field]
(r/'catalog.json').write_text(json.dumps(catalog,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
d=r/'allocation-short';d.mkdir();shutil.copyfile(base/'allocation-short/Allocation.csproj',d/'Allocation.csproj')
s=(base/'allocation-short/Program.cs').read_text(encoding='utf-8');s=s.replace('    var source = item.GetProperty("source").GetString()!;', '    var source = item.GetProperty("source").GetString()!;\n    var asynchronous = item.TryGetProperty("runAsync", out var mode) && mode.GetBoolean();');s=s.replace('using (var result = script.Run(host))','using (var result = asynchronous ? script.RunAsync(host).GetAwaiter().GetResult() : script.Run(host))');s=s.replace('rows.Add(new { id = item.GetProperty("id").GetString(),','rows.Add(new { id = item.GetProperty("id").GetString(), asynchronous,');(d/'Program.cs').write_text(s,encoding='utf-8',newline='\n')
diag=dict(catalog);diag['cases']=[]
for c in catalog['cases']:
 for mode in ([True,False]if c['id']=='scripts.text-normalization.large'else[True]if c['id']==search['id']else[False]):
  case=dict(c);case.update(id=c['id']+('.async'if mode else'.sync'),runAsync=mode);diag['cases'].append(case)
(d/'catalog.json').write_text(json.dumps(diag,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n');shutil.copyfile(base/'measure-allocation.py',r/'measure-allocation.py')
s=(base/'inspect-vm.py').read_text(encoding='utf-8').replace('consume-text-b822-20261116/candidate','line-construction-b827-20261116/reference').replace('810dafdd2afb684158374098c5b16e850369b7a6ebe2a56e451f3bd96f741d46','efd8270751e008587042c729869e214f000f1730a4e05683ae6ed4c6351f62db');(r/'inspect-vm.py').write_text(s,encoding='utf-8',newline='\n')
print('601inputs frozen; core',images['candidate']['Lokad.Lython.dll'],'focused128/495 eachactual11/10. Async normalization/protected search and sync controls ready.')
