from pathlib import Path
import hashlib,json,os,shutil,subprocess
r=Path(__file__).parent;d=r/'minimal-fixture-condition';d.mkdir();env=dict(os.environ);sdk='C:/Users/JoannesVermorel/.dotnet11';env.update(DOTNET_ROOT=sdk,DOTNET_ROOT_X64=sdk,DOTNET_PROCESSOR_COUNT='1');rows=[]
baseline=d/'baseline11';shutil.copytree('tests/Lokad.Lython.WorkerFixture/bin/Release/net11.0',baseline);shutil.copyfile(r.parent/'line-construction-r430/frozen/candidate/Lokad.Lython.dll',baseline/'Lokad.Lython.dll')
for label,framework,folder,attempts in [('candidate11','net11.0',Path('tests/Lokad.Lython.WorkerFixture/bin/Release/net11.0'),3),('candidate10','net10.0',Path('tests/Lokad.Lython.WorkerFixture/bin/Release/net10.0'),3),('baseline11','net11.0',baseline,1)]:
 for attempt in range(attempts):
  p=subprocess.run([sdk+'/dotnet.exe',str((folder/'Lokad.Lython.WorkerFixture.dll').resolve()),'stack-guard',str((folder/'Lokad.Lython.dll').resolve()),'native-call-continuation'],env=env,capture_output=True,text=True,encoding='utf-8',timeout=25);row=dict(label=label,framework=framework,attempt=attempt,coreSHA256=hashlib.sha256((folder/'Lokad.Lython.dll').read_bytes()).hexdigest(),exitCode=p.returncode,stdout=p.stdout,stderr=p.stderr);rows.append(row);print(json.dumps(row),flush=True)
(d/'controlled-observations.json').write_text(json.dumps(rows,indent=2)+'\n',encoding='utf-8',newline='\n')
assert all(x['exitCode']==0 for x in rows),'Original small-stack/thread assertions must all pass; do not relax.'
