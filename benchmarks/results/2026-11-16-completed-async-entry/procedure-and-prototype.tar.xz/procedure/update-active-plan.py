from pathlib import Path
p=Path('PLAN.md');s=p.read_text(encoding='utf-8')
old='Nonincremental Release succeeds; initial128internal pass,494/495public with a fixture placement failure (guest recursion/refunds correct, CLR continuation hopped). Simplified held test operation retains original256KiB/owned-thread/budget assertions;3candidate checks eachactual11/10 and1baseline11 pass. Broadened focused checks active; no performance or retention claim yet.'
new='Nonincremental Release succeeds; final128internal/495public pass eachactual11/10. Original fixture placement failures retained (guest recursion/refunds correct, CLR continuation hopped). Minimal held-operation fixture preserves256KiB/owned-thread/budget assertions;3candidate checks eachactual11/10 and1baseline11 pass. Four-case whole-job allocation diagnostic effectively flat, peaks unchanged; B830source pair active. No CPU or retention claim yet.'
assert old in s;s=s.replace(old,new)
s=s.replace('Receipt is being committed separately from active\n   R433prototype.', 'Receipt committed/pushed **ea1cf25d**, separately from active\n   R433prototype.')
needle='   Regex development remains independent of missing final producer capabilities.\n'
assert s.count(needle)==1
s=s.replace(needle,needle+'''
4. **Next substantial-cost selection remains open after R433.** Its completed-entry
   result decides only that candidate. Review existing whole-script profiles against
   current call/frame source, separating useful callee work from activation, operand
   transport, reset, I/O and cleanup. A changed hot-path claim needs a short current
   profile of a representative complete script before another redesign. Prefer an
   entire displaced storage/lifetime stage. Do not replace an unresolved whole-frame
   design with another arena, helper specialization or repeated unchanged source gate.
   Compilation is already near CPython in named cases; distinguish its share rather
   than counting passes. Keep the historical CPU/regression debts and current external
   baseline uncertainty visible. Stop each investigation with evidence and the next
   actionable decision, not a claim that the broad performance objective is complete.
''')
p.write_text(s,encoding='utf-8',newline='\n');print('PLAN actual qualification/focused/allocation state refreshed; broader objective remains open.')
