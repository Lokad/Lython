from pathlib import Path
import hashlib,json,shutil,subprocess
r=Path(__file__).parent;o=r/'original';o.mkdir()
paths=['src/Lokad.Lython/Runtime/LythonRuntime.Executable.Calls.cs','src/Lokad.Lython/Runtime/LythonRuntime.Generators.cs']
for n in paths:
 p=o/n;p.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(n,p)
selection=dict(baseCommit=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),baselineCoreSHA256='ecd9e956b007224f927de3c722c612668da094529aa125ca6adcd456184eaab2',paths={n:hashlib.sha256(Path(n).read_bytes()).hexdigest()for n in paths},hypothesis='Async public hosting repeatedly enters call-runner and generator advancement state machines even when frame work completes inline. Remove those unconditional state-machine entries; plain completed prefixes feed one iterative pending continuation and existing cleanup. Existing instruction engine, synchronous runner, generator frame and managed stack policy remain. No new controller/view/arena/cache or claimed explanation of synchronous CPython gap. Dominance/benefit remains to be measured in complete RunAsync scripts with synchronous controls.',sourceTradeoff='More explicit completed/pending control in two entry methods replaces unconditional generated state entry. Existing ExecuteUntilCallAsync stays: manually rebuilding its routing/disposal phase machine is outside this bounded change. Do not claim all async state machines or duplicate dispatch are removed.',acceptance='RunAsync normalization and protected file search, sync normalization and JSON controls; focused actual11/10 generators/protocols/closures/deep async stack/cancellation/refusal/awaited cleanup. Preserve ValueTask single consumption and entered-frame state through actual pending work; nonstarting injection and guest StopIteration behavior unchanged. One bounded source pair with controls and allocation; retain/refine/remove with debt explicit, no fixed-percent veto.')
(r/'selection.json').write_text(json.dumps(selection,indent=2)+'\n',encoding='utf-8',newline='\n')
p=Path('PLAN.md');s=p.read_text(encoding='utf-8');a=s.index('3. **Resume substantial call/frame/operand work.**');b=s.index('\nR429retains',a)
s=s[:a]+'''3. **R433 selected: completed async call/frame advancement.** NativeExecution is
   a stack-only Span view, not a persistent generator frame. Sharing it with a
   suspended generator would require a broader storage/dispatch redesign; do not
   add a second generator backend or fake function. R431found plain builtin
   metadata already shared and JSON already native/iterative; no duplicate value
   pipeline to remove there. R403controller/R411tail-loan regressions remain lessons.

   **Hypothesis/work eliminated:** current ExecuteAsync call runner and generator
   AdvanceAsync unconditionally enter generated state-machine bodies on completed
   CPU work. Replace those entry layers with plain completed prefixes and one
   iterative pending continuation, retaining current instruction execution and
   synchronous paths. Delete the old unconditional async entry bodies; generated
   continuation state is needed only for true suspension/terminal cleanup/faults.
   No new controller, operand view, arena, cache, public option or time policy.
   Existing ExecuteUntilCallAsync remains: rebuilding its exception/disposal phase
   machine would add disproportionate complexity. Source control is more explicit;
   this is not a claim of fewer source lines or removal of every async machine.

   **Acceptance:** complete RunAsync normalization and protected file search,
   synchronous normalization/JSON controls; focused actual11/10 generators,
   closures, protocols, deep managed stack, true pending I/O, current token,
   terminal refusal and joined cleanup. Consume each ValueTask exactly once;
   entered frames/owners survive pending work, return to baseline after cleanup.
   Preserve unstarted injection, send/throw/close, exception context/StopIteration,
   binding and effect order. One bounded source pair/alloc diagnostic establishes
   whether these layers matter; source alone does not prove dominant CPU cost.
   Stop at retain/refine/remove with adverse conditions and debt explicit. This
   targets hosting strategy; it cannot explain the synchronous CPython gap.
   Regex development remains independent of missing final producer capabilities.
'''+s[b:];p.write_text(s,encoding='utf-8',newline='\n')
print('R433 bounded two-layer async completion prototype selected; no new engine/controller/storage abstraction.')
