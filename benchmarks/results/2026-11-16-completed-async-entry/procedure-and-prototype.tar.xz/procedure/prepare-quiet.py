from pathlib import Path
import ast, datetime, hashlib, io, json, subprocess, tarfile
r=Path(__file__).parent; q=r/'quiet';q.mkdir(exist_ok=True)
old=r.parent/'line-construction-r430/confirmation'
sha=lambda data:hashlib.sha256(data).hexdigest()
commit=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
def committed(path):
 data=Path(path).read_bytes();assert data==subprocess.check_output(['git','show',commit+':'+path]);return data
proofs=[]
def proof(archive,member,paths,links=1):
 raw=committed(archive)
 with tarfile.open(fileobj=io.BytesIO(raw))as a:data=a.extractfile(member).read()if member else raw
 proofs.append(dict(sha256=sha(data),bytes=len(data),links=links,paths=paths,custody=dict(commit=commit,archive=archive,archiveSHA256=sha(raw),member=member)))
aliases=json.loads((r/'historical-aliases.json').read_text(encoding='utf-8'))
proof('benchmarks/results/2026-11-16-line-construction/source-checks-and-procedure.tar.xz','frozen/reference/Lokad.Lython.dll',aliases['paths'],aliases['links'])
archives=[('line-cpython-b829-20261116','benchmarks/results/2026-11-16-line-cpython-checkpoint/observations.tgz'),('line-construction-b827-20261116','benchmarks/results/2026-11-16-line-construction/observations.tgz'),('line-confirm-b828-20261116','benchmarks/results/2026-11-16-line-construction/confirmation/observations.tgz'),('bulk-text-b826-20261116','benchmarks/results/2026-11-16-bulk-text-construction/refined/observations.tgz')]
for root,archive in archives:
 raw=committed(archive)
 with tarfile.open(fileobj=io.BytesIO(raw))as a:
  names=a.getnames();pycs=[n for n in names if n.startswith('__pycache__/')and n.endswith('.pyc')];assert len(pycs)==1
 for member in pycs+['confirmation/machine-before.json','confirmation/machine-after.json']:proof(archive,member,[root+'/'+member])
 if root.startswith('line-cpython'):
  proof(archive,'confirmation/confirmation.json',[root+'/confirmation/confirmation.json'])
  proof(archive,None,[root+'/observations.tgz'])
source=json.loads((r.parent/'line-cpython-r432/checkpoint/config.json').read_text(encoding='utf-8'))
frozen=json.loads((r/'frozen/identity.json').read_text(encoding='utf-8'))
files=json.loads((old/'config.json').read_text(encoding='utf-8'))['sourceFiles'];images={role:{n:frozen['images'][role][n]for n in files}for role in ['reference','candidate']}
assert files==images['reference']
remote='/home/lokad/lython-bench-checks/completed-async-b830-20261116';unit='lython-b830-completed-async-20261116'
identity=dict(sourceRevision='R433 prototype7c592066 versus qualified86d9344e/ecd9e956',purpose='Bounded completed-async-entry source pair: actual RunAsync complete scripts and synchronous controls. Allocation essentially flat; no pre-existing CPU claim.',coreSHA256={label:images['candidate'if label.startswith('candidate')else'reference']['Lokad.Lython.dll']for label in ['reference','reference-control','candidate','candidate-control']},imageFiles=images,prototype=True,publicationHeld=True,referenceQualification='43805966777GREEN Windows/Ubuntu actual11/10 ordinary/stress/installed Release consumers; receipt ea1cf25d; never requery.',candidateFocusedChecks=json.loads((r/'focused-checks.json').read_text(encoding='utf-8')),candidateSourceIdentitySHA256=sha((r/'frozen/identity.json').read_bytes()))
(q/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8',newline='\n')
for name in ['archive-owned.py','run.sh','retrieve.py','collect.py']:
 s=(old/name).read_text(encoding='utf-8').replace('/home/lokad/lython-bench-checks/line-confirm-b828-20261116',remote).replace('lython-b828-line-confirm-20261116',unit).replace('B828','B830')
 if name=='collect.py':
  s=s.replace("manifest_hash = hashlib.sha256(catalog.read_bytes()).hexdigest()", "cases.update({c['id']:c for c in json.loads((root/'extra.json').read_text())['cases']})\nmanifest_hash = hashlib.sha256(catalog.read_bytes()).hexdigest()")
  start=s.index('jobs=');end=s.index('\nassert len(jobs)',start)
  s=s[:start]+"jobs=[['scripts.text-normalization.large','warm-async'],['scripts.text-normalization.large','warm'],['scripts.file-search.large.protected','warm-async'],['scripts.json-summary-helpers.large','warm']]"+s[end:]
  s=s.replace("        catalog = root/'representative.json'", "        catalog = root/('extra.json'if case_id=='scripts.file-search.large.protected'else'representative.json')")
 (q/name).write_text(s,encoding='utf-8',newline='\n')
payloadfiles={n:(q/n).read_bytes()for n in ['identity.json','collect.py','archive-owned.py','run.sh']}
payloadfiles['extra.json']=(r/'extra.json').read_bytes();payloadfiles['candidate/Lokad.Lython.dll']=(r/'frozen/candidate/Lokad.Lython.dll').read_bytes()
with tarfile.open(q/'payload.tgz','w:gz')as a:
 for n,data in payloadfiles.items():
  item=tarfile.TarInfo(n);item.size=len(data);a.addfile(item,io.BytesIO(data))
config=dict(root=remote,unit=unit,source=source['root'],sourceFiles=files,sourceCatalogSHA256=source['sourceCatalogSHA256'],catalogSHA256=source['sourceCatalogSHA256'],identity=identity,retireGroups=proofs,payloadBytes=(q/'payload.tgz').stat().st_size,payloadSHA256=sha((q/'payload.tgz').read_bytes()),unpackedBytes=sum(len(v)for v in payloadfiles.values()))
(q/'config.json').write_text(json.dumps(config,indent=2)+'\n',encoding='utf-8',newline='\n')
s=(old/'remote-launch.py').read_text(encoding='utf-8');start=s.index('c=');end=s.index("\nb=Path",start);s=s[:start]+'c='+repr(config)+s[end:]
s=s.replace(" for role in ['reference','candidate']:\n  for n,h in c['identity']['imageFiles'][role].items():assert sha(source/role/n)==h\n",'')
s=s.replace("assert not original['complete']and original['workloadJobsComplete']and original['allWorkersJoined']and original['guestFixturesRemoved']", "assert original['complete']and original['allWorkersJoined']and original['guestFixturesRemoved']and original['archivedAndVerifiedUnderLease']")
s=s.replace('os.link(source/role/n,p)',"os.link(source/'candidate'/n,p)").replace('lython-b828-fixtures','lython-b830-fixtures')
ast.parse(s);(q/'remote-launch.py').write_text(s,encoding='utf-8',newline='\n')
for n in ['collect.py','archive-owned.py','retrieve.py']:ast.parse((q/n).read_text(encoding='utf-8'))
print(json.dumps(dict(candidate=images['candidate']['Lokad.Lython.dll'],retireBytes=sum(v['bytes']for v in proofs),unpackedBytes=config['unpackedBytes'],payloadBytes=config['payloadBytes'],proofs=len(proofs))))
