from pathlib import Path
import base64,json,os,subprocess,tempfile
root=Path(__file__).resolve().parent
catalog=json.loads((root/'catalog-full.json').read_text(encoding='utf-8'))
cases=[c for c in catalog['cases'] if c['id'].startswith('scripts.csv-summary-functions.') or c['id']=='scripts.csv-summary-helpers.large']
records=[]
for case in cases:
 with tempfile.TemporaryDirectory(prefix='lython-csv-ref-') as folder:
  directory=Path(folder);fixture=json.loads(case['fixtureJson'])
  for name,data in fixture['inputFiles'].items():
   path=directory/name;path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(base64.b64decode(data))
  result=subprocess.run(['C:/Python313/python.exe','-I','-S','-X','utf8','-c',case['source']],cwd=directory,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=5)
  assert result.returncode==0 and not result.stderr
  # Standalone Windows stdout translates print's newline. The protocol worker
  # uses StringIO; Linux's independent preflight keeps exact raw LF comparison.
  assert result.stdout==case['expectedOutput'].replace('\n',os.linesep).encode('utf-8')
  for name,data in fixture['outputFiles'].items():assert (directory/name).read_bytes()==base64.b64decode(data)
  records.append(dict(case=case['id'],sourceSHA256=case['sourceSha256'],stdout=result.stdout.decode('utf-8'),fullOutputFilesPassed=True))
(root/'windows-reference-validation.json').write_text(json.dumps(dict(python='3.13.2',standaloneStdoutNewline=repr(os.linesep),records=records,originalRawLFCheckFailedBeforeAnyVMUpload=True),indent=2)+'\n',encoding='utf-8')
print('Four complete sources match CPython; stdout uses Windows newline, file goldens exact')
