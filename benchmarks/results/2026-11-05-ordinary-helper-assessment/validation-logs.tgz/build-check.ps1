$ErrorActionPreference='Stop'
$env:DOTNET_ROOT='C:/Users/JoannesVermorel/.dotnet11'
$env:DOTNET_HOST_PATH=$env:DOTNET_ROOT+'/dotnet.exe'
$env:PATH=$env:DOTNET_ROOT+';'+$env:PATH
$notes='D:/code/Lython/.git/agent-notes/review-20261031/ordinary-helper-d32'
foreach($project in 'benchmarks/Lokad.Lython.Benchmarks','tests/Lokad.Lython.PublicApi.Tests') {
    $name=Split-Path $project -Leaf
    dotnet build $project -c Release --no-restore -p:BuildProjectReferences=false *> ($notes+'/'+$name+'-build.log')
    $buildExit=$LASTEXITCODE
    Get-Content ($notes+'/'+$name+'-build.log') -Tail 10
    if($buildExit -ne 0){exit $buildExit}
}
foreach($framework in 'net11.0','net10.0') {
    $logPath=$notes+'/comparison-'+$framework+'.log'
    dotnet test tests/Lokad.Lython.PublicApi.Tests -c Release -f $framework --no-build --filter 'Category!=Stress&FullyQualifiedName~ComparisonFileWorkerTests' *> $logPath
    $testExit=$LASTEXITCODE
    Get-Content $logPath -Tail 20
    if($testExit -ne 0){exit $testExit}
}
dotnet benchmarks/Lokad.Lython.Benchmarks/bin/Release/net11.0/Lokad.Lython.Benchmarks.dll --compare list --profile representative --out ($notes+'/catalog-full.json')
exit $LASTEXITCODE
