from pathlib import Path
import hashlib,json,shutil
root=Path('/home/lokad/lython-bench-checks/ordinary-helper-b254-20261105')
base=Path('/home/lokad/lython-bench-checks/native-format-refined-b253-20261105/candidate')
# The executable/deps/runtimeconfig are actual local files; only dependencies link.
# Keep the existing immutable core, avoiding both duplicate storage and B250 staging.
for f in base.iterdir():
 if f.name in ['Lokad.Lython.Benchmarks.dll','Lokad.Lython.Benchmarks.deps.json','Lokad.Lython.Benchmarks.runtimeconfig.json','Lokad.Lython.pdb']:continue
 (root/'candidate'/f.name).symlink_to(f.resolve(),target_is_directory=f.is_dir())
for name,expected in json.loads((root/'identity.json').read_text())['files'].items():
 assert hashlib.sha256((root/'candidate'/name).read_bytes()).hexdigest()==expected
assert shutil.disk_usage(root).free>64*1024*1024
