from pathlib import Path
import gzip, hashlib, json, shutil, subprocess, sys, tarfile
from io import BytesIO

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
source=lab.parent/sys.argv[1]
template=lab.parent/'normalize-json-cpython'
q=lab/'quiet'
previous=template/'confirmation/quiet'
def read(p): return p.read_text(encoding='utf-8')
def load(p): return json.loads(read(p))
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def emit(p,s):
    if p.suffix=='.py': compile(s,str(p),'exec')
    p.write_text(s,encoding='utf-8',newline='\n')
def save(p,v): emit(p,json.dumps(v,indent=2,ensure_ascii=False)+'\n')
index=load(source/'identity.json')
revision=index['candidate']
assert revision.startswith('9bf720efa')
assert not subprocess.check_output(['git','diff','--name-only',revision,'HEAD','--','src'],cwd=repo)
assert not subprocess.check_output(['git','diff','--name-only','HEAD','--','src'],cwd=repo)
retained=subprocess.check_output(['git','log','-1','--format=%H','--','src'],cwd=repo,text=True).strip()
measured="../2026-11-21-bulk-csv-field-output/candidate-core.dll.gz"
payload_source=repo/"benchmarks/results"/measured.removeprefix("../")
assert gzip.decompress(payload_source.read_bytes())==(source/'frozen/candidate/Lokad.Lython.dll').read_bytes()
save(lab/'selected-source.json',dict(lab=sys.argv[1],retained=retained,measuredCore=measured))
verified=load(source/'candidate-verify.json')
assert index['candidate']==revision and verified['state']=='Completed'
files=index['imageFiles']['candidate']
image=source/'frozen/candidate'
assert len(files)==32 and {n:sha(image/n) for n in files}==files
assert verified['catalogSha256']==index['catalogSHA256']==sha(source/'representative.json')
assert index['pythonWorkerSHA256']==sha(repo/'benchmarks/cpython-worker.py')
staging=load(source/'quiet/config.json')
receipt=load(source/'quiet/archive-receipt.json')
assert receipt['complete'] and receipt['archivedAndVerifiedUnderLease']
assert receipt['archiveSHA256']==sha(source/'quiet/observations.tgz')
q.mkdir()
identity=dict(sourceRevision=revision,imageSource=revision,purpose='CSV restock exports at the bulk-writer checkpoint against stock CPython',
              imageFiles=dict(candidate=files),catalogSHA256=index['catalogSHA256'],cpythonWorkerSHA256=index['pythonWorkerSHA256'],
              auxiliaryFiles={name:digest for name,digest in files.items() if name!='Lokad.Lython.dll'},
              coreSHA256={name:files['Lokad.Lython.dll'] for name in ('candidate','candidate-control')})
save(q/'identity.json',identity)
shutil.copyfile(repo/'benchmarks/cpython-worker.py',q/'cpython-worker.py')

prior=load(previous/'config.json')
root='/home/lokad/lython-bench-checks/csv-restock-cpython-b1278-20261121'
unit='lython-b1278-csv-restock-cpython-20261121'
normalize='scripts.json-normalized-records.large'
ordinary='scripts.csv-restock-export.ordinary'
escaped='scripts.csv-restock-export.escaped'
for name in ('collect.py','archive-owned.py','retrieve.py','run.sh'):
    s=read(previous/name).replace(prior['root'],root).replace(prior['unit'],unit).replace('B1253','B1278')
    if name == 'collect.py':
        begin=s.index("    for case_id,lane in ")
        end=s.index("        assert time.monotonic()",begin)
        lanes=[(ordinary,'warm'),(ordinary,'compile-run'),(ordinary,'compile'),(escaped,'warm')]
        s=s[:begin]+f"    for case_id,lane in {lanes!r}:\n"+s[end:]
        s=s.replace("time.monotonic()+16","time.monotonic()+8").replace("n*.85","n*.65")
    if name in ('archive-owned.py','retrieve.py'):
        s=s.replace("==2","==4").replace("jobs=2,","jobs=4,")
    if name == 'run.sh':
        assert '\r' not in s
    emit(q/name,s)
assert b'\r' not in (q/'run.sh').read_bytes()
parts=('identity.json','collect.py','archive-owned.py','run.sh','cpython-worker.py')
archive=q/'payload.tgz'
with tarfile.open(archive,'w:gz') as f:
    for n in parts: f.add(q/n,arcname=n)
config=dict(root=root,unit=unit,identity=identity,source=staging['root'],sourceRole='candidate',
            sourceFiles=files,sourceCatalogSHA256=identity['catalogSHA256'],catalogSHA256=identity['catalogSHA256'],
            cpythonWorkerSHA256=identity['cpythonWorkerSHA256'],retireGroups=[],donorArchiveSHA256=receipt['archiveSHA256'],
            payloadBytes=archive.stat().st_size,payloadSHA256=sha(archive),unpackedBytes=sum((q/n).stat().st_size for n in parts))
save(q/'config.json',config)
s=read(previous/'remote-launch.py')
a,b=s.index('\nc=')+1,s.index('\nb=Path(')
s=(s[:a]+'c='+repr(config)+s[b:]).replace('lython-b1253-fixtures','lython-b1278-fixtures')
s=s.replace("176160768+c['unpackedBytes']+32*1024*1024","176160768+c['unpackedBytes']+8*1024*1024")
emit(q/'remote-launch.py',s)
launch=read(lab.parent/'casing-checkpoint-cpython/launch.py').replace("B1274 casing checkpoint","B1278 CSV restock").replace("260","245")
emit(lab/'launch.py',launch)
