from pathlib import Path
import hashlib,json,shutil,tarfile
r=Path(__file__).resolve().parent;repo=Path('D:/code/Lython');out=repo/'benchmarks/results/2026-11-16-regex-dev105';out.mkdir();f=out/'fixture-identity';f.mkdir()
checks=json.loads((r/'checks.json').read_text(encoding='utf-8'));assert len(checks)==5
assert checks[0]['counts']['failed']=='3'and all(x['counts']['passed']=='363'and x['counts']['failed']=='0'for x in checks[1:])
for n in ['checks.json','identity.json']:shutil.copyfile(r/n,f/n)
with tarfile.open(f/'sources-assets-checks.tar.xz','w:xz')as t:
 for p in r.glob('*.py'):t.add(p,arcname='procedure/'+p.name)
 for n in ['checks','normal-checks']:t.add(r/n,arcname=n)
 for n in ['fixture-build.log','reference-build.log','candidate-build.log']:t.add(r/n,arcname=n)
 for n in ['tests/Lokad.Lython.PublicApi.Tests/RegexAdapterLifetimeTests.cs','tests/Lokad.Lython.WorkerFixture/RegexCancellationFixture.cs']:t.add(repo/n,arcname=n)
 for role in ['reference','candidate']:
  t.add(r/role/'Adapter.csproj',arcname=role+'/Adapter.csproj');t.add(r/role/'Utf8RegexProvider.cs',arcname=role+'/Utf8RegexProvider.cs')
  for tfm in ['net11.0','net10.0']:
   for p in(r/'assets'/role/tfm).iterdir():
    if p.name!='Lokad.Lython.dll':t.add(p,arcname='assets/'+role+'/'+tfm+'/'+p.name)
   t.add(r/role/'bin/Release'/tfm/'Lokad.Lython.Utf8Regex.dll',arcname=role+'/'+tfm+'/Lokad.Lython.Utf8Regex.dll')
 t.add(r/'assets/packages',arcname='packages')
(f/'README.md').write_text('''# Exact subprocess identity for regex cancellation qualification

R443,2026-11-16UTC. The real-adapter cancellation subprocess now reports SHA256
of its loaded core,adapter and two producer libraries. The parent requires exact
equality with its own loaded images before accepting cancellation evidence. The
runtime/provider contract is unchanged; this is controlled fixture output only.

The prior R409 private-parent script copied development assemblies into its test
image but located the normal repository WorkerFixture through Directory.Build.props.
It did not qualify the development producer in those three isolated child checks.
Their exact historical child bytes were not recorded,so do not infer them now.
Historical parent semantics/allocation/timing evidence remains; private-producer
in-flight cancellation was not established by that receipt. This correction is
linked alongside the original evidence without overwriting its observations.

A deliberate dev105parent/normal-child negative control fails all3stages on the
library-hash assertion. Full isolated images then provide their own root marker
and matching subprocess files: both the old immutable0.5candidate and newly
accepted0.5.0-dev.105 pass363public regex checks each on actual.NET11and10,
including real compile/match/cursor interruption,original tokens,zero cleanup
balances,flags/windows/captures,refusal and retained ownership. Normal0.4passes
all6lifetime cases each target. No timeout,assertion or guest contract is relaxed.

Both private adapters use identical R409native source. Dev105packages are copied
and SHA-verified before extracting target assets; mutable producer build outputs
are never consumed. PythonRe package89ad65d7/core49c0d0c2 are distinct from R409's
9370a922/42f1c4f9. No normal adapter pin/core dependency changes. Native names,
preparation-token plumbing and separate result-stage ownership remain final
adapter limitations. New affected-script comparison and cumulative platform/
stress/package qualification are tracked separately; publication held.

[Checks and deliberate failure](checks.json),[asset/image identity](identity.json),
[source,immutable assets,logs,TRX and procedures](sources-assets-checks.tar.xz).
''',encoding='utf-8',newline='\n')
p=repo/'tests/README.md';s=p.read_text(encoding='utf-8');needle='cannot leave matching work running in the test host. Its semantic goldens use';assert needle in s
s=s.replace(needle,'cannot leave matching work running in the test host. The child reports loaded\ncore, adapter and producer hashes; the parent requires exact image equality,\nincluding for private development providers. Its semantic goldens use');p.write_text(s,encoding='utf-8',newline='\n')
p=repo/'benchmarks/results/2026-11-15-regex-range-prototype/README.md';s=p.read_text(encoding='utf-8');needle='## Displacement and semantics';assert needle in s
s=s.replace(needle,'''## Qualification correction

[R443 fixture identity](../2026-11-16-regex-dev105/fixture-identity/README.md)
finds that the private-parent qualification located the normal repository child
fixture. These three subprocess checks did not establish development-producer
in-flight cancellation. Historical child bytes were not recorded. Parent semantics
and timing/allocation evidence remain. R443 adds exact parent/child image checks
and separately qualifies both immutable producers with matching private fixtures.

'''+needle);p.write_text(s,encoding='utf-8',newline='\n')
p=repo/'benchmarks/EXPERIMENTS.md';s=p.read_text(encoding='utf-8');a=s.index('[R442 complete call/frame design pass]');s=s[:a]+'''[R443 exact regex subprocess identity](results/2026-11-16-regex-dev105/fixture-identity/README.md)
corrects R409's private-parent/normal-child qualification gap. All3deliberate
mismatches fail hash equality; matching private images pass363regex checks each
actual11/10 for both old0.5and immutabledev105. Normal0.4passes6lifetime cases per
target. Same native adapter source; new producer packages frozen/hashed. Parent
semantics/timing evidence remains,old private in-flight claim was unproven. No
runtime/core dependency or normal pin change; affected comparison/full delivery pending.

'''+s[a:];p.write_text(s,encoding='utf-8',newline='\n')
print('Exact-image fixture correction and updated immutable-asset qualification preserved; original evidence retained with linked correction.')
