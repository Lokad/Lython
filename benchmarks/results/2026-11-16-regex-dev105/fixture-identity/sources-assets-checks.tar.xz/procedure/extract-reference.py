from pathlib import Path
import tarfile
r=Path(__file__).resolve().parent;repo=Path('D:/code/Lython')
with tarfile.open(repo/'benchmarks/results/2026-11-15-regex-range-prototype/sources-assets-and-checks.tar.xz')as t:
 for n in ['native/Utf8RegexProvider.cs','procedure/prepare-prototype.py','procedure/prepare-comparison.py','procedure/measure-allocation.py','allocation/catalog.json']:
  m=t.getmember(n);out=r/'prior'/n;out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes(t.extractfile(m).read())
print('Prior native adapter and existing qualification procedures extracted from committed immutable evidence.')
