from pathlib import Path
import hashlib,json,os,subprocess,time,xml.etree.ElementTree as E
r=Path(__file__).resolve().parent;repo=Path('D:/code/Lython');identity=json.loads((r/'identity.json').read_text(encoding='utf-8'));sdk='C:/Users/JoannesVermorel/.dotnet11'
env=dict(os.environ);env.update(DOTNET_ROOT=sdk,DOTNET_ROOT_X64=sdk,DOTNET_HOST_PATH=sdk+'/dotnet.exe',PATH=sdk+';'+env['PATH']);rows=[]
ns={'t':'http://microsoft.com/schemas/VisualStudio/TeamTest/2010'}
def run(image,role,tfm,filter,label):
 results=r/'checks'/label/tfm/role;results.mkdir(parents=True);log=results/'test.log';start=time.monotonic()
 with log.open('w',encoding='utf-8')as output:p=subprocess.run([sdk+'/dotnet.exe','vstest',str(image/'Lokad.Lython.PublicApi.Tests.dll'),'--TestCaseFilter:'+filter,'--Logger:trx;LogFileName=regex.trx','--ResultsDirectory:'+str(results)],env=env,stdout=output,stderr=subprocess.STDOUT,cwd=repo,timeout=180)
 trx=E.parse(results/'regex.trx');counts=trx.find('t:ResultSummary/t:Counters',ns).attrib
 row=dict(role=role,tfm=tfm,label=label,returncode=p.returncode,elapsedSeconds=time.monotonic()-start,counts=counts,log=str(log.relative_to(r)));rows.append(row);(r/'checks.json').write_text(json.dumps(rows,indent=2)+'\n',encoding='utf-8',newline='\n');print(row,flush=True)
 return p,trx
negative=r/'consumers/net11.0/candidate'
assert not(negative/'Directory.Build.props').exists()
p,trx=run(negative,'candidate','net11.0','FullyQualifiedName~ActualBackendWorkObservesInFlightCancellationAndUnwinds','wrong-subprocess-negative-control')
assert p.returncode!=0 and trx.find('t:ResultSummary/t:Counters',ns).get('failed')=='3'
expected=identity['images']['candidate/net11.0']['Lokad.Lython.Utf8Regex.dll'].upper()
messages=[n.text or''for n in trx.findall('.//t:ErrorInfo/t:Message',ns)]
# xUnit truncates values in presentation; equality failures must identify the
# actual library mismatch,not timeout,matching failure or missing fixtures.
assert len(messages)==3 and all('Assert.Equal' in x and expected[:12] in x for x in messages),messages
for tfm in ['net11.0','net10.0']:
 for role in ['reference','candidate']:
  image=r/'consumers'/tfm/role
  (image/'Directory.Build.props').write_text('<Project/>\n',encoding='utf-8',newline='\n')
  fixture=image/'tests/Lokad.Lython.WorkerFixture/bin/Release'/tfm
  for n,h in identity['images'][role+'/'+tfm].items():assert hashlib.sha256((image/n).read_bytes()).hexdigest()==h,n
  for n in ['Lokad.Lython.dll','Lokad.Lython.Utf8Regex.dll','Lokad.Utf8Regex.dll','Lokad.Utf8Regex.PythonRe.dll']:assert (image/n).read_bytes()==(fixture/n).read_bytes(),n
  p,trx=run(image,role,tfm,'Category!=Stress&FullyQualifiedName~Regex','private-parent-and-child')
  assert p.returncode==0,(r/'checks/private-parent-and-child'/tfm/role/'test.log').read_text(encoding='utf-8')[-4500:]
print('Both immutable producer versions qualified through private parent and child images; deliberate mismatched child rejected.')
