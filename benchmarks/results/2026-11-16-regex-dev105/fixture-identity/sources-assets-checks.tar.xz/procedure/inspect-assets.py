from pathlib import Path
import hashlib,tarfile,zipfile
repo=Path('D:/code/Lython')
with tarfile.open(repo/'benchmarks/results/2026-11-15-regex-range-prototype/sources-assets-and-checks.tar.xz')as t:
 for m in t.getmembers():
  if m.isfile()and m.name.endswith('.dll')and any(x in m.name for x in ['assets/','native/bin/']):print(m.name,m.size)
for package in ['Lokad.Utf8Regex','Lokad.Utf8Regex.PythonRe']:
 p=Path('D:/code/utf8regex/artifacts/nuget')/(package+'.0.5.0-dev.105.nupkg')
 print(p.name,p.stat().st_size,hashlib.sha256(p.read_bytes()).hexdigest())
 with zipfile.ZipFile(p)as z:
  print([n for n in z.namelist()if n.endswith(('.nuspec','.dll'))])
