from pathlib import Path
import hashlib,json,os,shutil,subprocess,tarfile,zipfile
import xml.etree.ElementTree as E
r=Path(__file__).resolve().parent;repo=Path('D:/code/Lython');sha=lambda b:hashlib.sha256(b).hexdigest()
assert 'Build succeeded.'in(r/'fixture-build.log').read_text(encoding='utf-8')
ns={'t':'http://microsoft.com/schemas/VisualStudio/TeamTest/2010'}
checks=[E.parse(p).find('t:ResultSummary/t:Counters',ns).attrib for p in(r/'normal-checks').glob('*.trx')]
assert len(checks)==2 and all(x['passed']=='6'and x['failed']=='0'for x in checks)
assets=r/'assets';assets.mkdir();packages=assets/'packages';packages.mkdir();records=[]
for name in ['Lokad.Utf8Regex','Lokad.Utf8Regex.PythonRe']:
 p=Path('D:/code/utf8regex/artifacts/nuget')/(name+'.0.5.0-dev.105.nupkg');frozen=packages/p.name;shutil.copyfile(p,frozen);assert p.read_bytes()==frozen.read_bytes()
 with zipfile.ZipFile(frozen)as z:
  for tfm in ['net11.0','net10.0']:
   d=assets/'candidate'/tfm;d.mkdir(parents=True,exist_ok=True);data=z.read('lib/'+tfm+'/'+name+'.dll');(d/(name+'.dll')).write_bytes(data)
   records.append(dict(role='candidate',id=name,tfm=tfm,packageSHA256=sha(frozen.read_bytes()),assemblySHA256=sha(data)))
prior=json.loads((repo/'benchmarks/results/2026-11-15-regex-range-prototype/prototype-identity.json').read_text(encoding='utf-8'))
with tarfile.open(repo/'benchmarks/results/2026-11-15-regex-range-prototype/sources-assets-and-checks.tar.xz')as t:
 for tfm in ['net11.0','net10.0']:
  d=assets/'reference'/tfm;d.mkdir(parents=True)
  for name in ['Lokad.Utf8Regex','Lokad.Utf8Regex.PythonRe']:
   data=t.extractfile('assets/'+tfm+'/'+name+'.dll').read();old=next(x for x in prior['assets']if x['id']==name and x['tfm']==tfm);assert sha(data)==old['assemblySHA256'].lower();(d/(name+'.dll')).write_bytes(data)
   records.append(dict(role='reference',id=name,tfm=tfm,packageSHA256=old['packageSHA256'].lower(),assemblySHA256=sha(data)))
code=(r/'prior/native/Utf8RegexProvider.cs').read_bytes();assert sha(code)==prior['nativeSourceSHA256']
sdk='C:/Users/JoannesVermorel/.dotnet11';env=dict(os.environ);env.update(DOTNET_ROOT=sdk,DOTNET_ROOT_X64=sdk,PATH=sdk+';'+env['PATH']);images={}
for role in ['reference','candidate']:
 for tfm in ['net11.0','net10.0']:shutil.copyfile(repo/'src/Lokad.Lython/bin/Release'/tfm/'Lokad.Lython.dll',assets/role/tfm/'Lokad.Lython.dll')
 project=r/role;project.mkdir();(project/'Utf8RegexProvider.cs').write_bytes(code)
 csproj='''<Project Sdk="Microsoft.NET.Sdk"><PropertyGroup><TargetFrameworks>net11.0;net10.0</TargetFrameworks><AssemblyName>Lokad.Lython.Utf8Regex</AssemblyName><Version>0.11.0</Version><AssemblyVersion>0.11.0.0</AssemblyVersion><IsPackable>false</IsPackable><AllowUnsafeBlocks>false</AllowUnsafeBlocks><EnableSourceControlManagerQueries>false</EnableSourceControlManagerQueries></PropertyGroup><ItemGroup>'''
 for name in ['Lokad.Lython','Lokad.Utf8Regex','Lokad.Utf8Regex.PythonRe']:csproj+=f'<Reference Include="{name}"><HintPath>../assets/{role}/$(TargetFramework)/{name}.dll</HintPath></Reference>'
 csproj+='</ItemGroup></Project>\n';(project/'Adapter.csproj').write_text(csproj,encoding='utf-8',newline='\n')
 with(r/(role+'-build.log')).open('w',encoding='utf-8')as log:p=subprocess.run([sdk+'/dotnet.exe','build',str(project/'Adapter.csproj'),'-c','Release','--no-incremental'],env=env,stdout=log,stderr=subprocess.STDOUT,timeout=120)
 assert p.returncode==0,(r/(role+'-build.log')).read_text(encoding='utf-8')[-3000:]
 print(role,'adapter built for both targets',flush=True)
 for tfm in ['net11.0','net10.0']:
  image=r/'consumers'/tfm/role;image.parent.mkdir(parents=True,exist_ok=True);shutil.copytree(repo/'tests/Lokad.Lython.PublicApi.Tests/bin/Release'/tfm,image,copy_function=shutil.copyfile)
  for path in(assets/role/tfm).iterdir():shutil.copyfile(path,image/path.name)
  shutil.copyfile(project/'bin/Release'/tfm/'Lokad.Lython.Utf8Regex.dll',image/'Lokad.Lython.Utf8Regex.dll')
  fixture=image/'tests/Lokad.Lython.WorkerFixture/bin/Release'/tfm
  shutil.copytree(repo/'tests/Lokad.Lython.WorkerFixture/bin/Release'/tfm,fixture,copy_function=shutil.copyfile)
  for name in ['Lokad.Lython.dll','Lokad.Lython.Utf8Regex.dll','Lokad.Utf8Regex.dll','Lokad.Utf8Regex.PythonRe.dll']:
   shutil.copyfile(image/name,fixture/name);assert sha((image/name).read_bytes())==sha((fixture/name).read_bytes())
  shutil.copytree(repo/'tests/Fixtures/Workflows/RegexRewrite',image/'Fixtures/Workflows/RegexRewrite',copy_function=shutil.copyfile,dirs_exist_ok=True)
  images[role+'/'+tfm]={n:sha((image/n).read_bytes())for n in ['Lokad.Lython.dll','Lokad.Lython.Utf8Regex.dll','Lokad.Utf8Regex.dll','Lokad.Utf8Regex.PythonRe.dll','Lokad.Lython.PublicApi.Tests.dll']}
# Deliberately leave the root marker absent until the negative control has
# demonstrated rejection of the normal repository subprocess fixture.
(r/'identity.json').write_text(json.dumps(dict(assets=records,images=images,nativeSourceSHA256=sha(code),sameAdapterSourceBothRoles=True,onlyProducerChangesApartFromNecessaryReferenceRecompilation=True,normalPinUnchanged=True,coreProductionUnchanged=True,privateSubprocessImagesCopiedAndHashVerified=True,publicationHeld=True),indent=2)+'\n',encoding='utf-8',newline='\n')
print('Immutable producer assets and both-target private parent/child images prepared; no normal package pin changed.')
