from pathlib import Path
import datetime,json,urllib.request
r=Path(__file__).resolve().parent;url='https://api.nuget.org/v3-flatcontainer/lokad.utf8regex.pythonre/index.json'
with urllib.request.urlopen(url,timeout=20)as response:
 data=response.read();headers=dict(response.headers)
(r/'published-versions.json').write_bytes(data)
v=json.loads(data);(r/'published-observation.json').write_text(json.dumps(dict(url=url,observedUTC=datetime.datetime.now(datetime.timezone.utc).isoformat(),versions=v['versions'],headers=headers),indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps(dict(publishedVersions=v['versions'],development105Published='0.5.0-dev.105'in v['versions'])))
