from pathlib import Path
import ast,contextlib,hashlib,io,json,shutil,subprocess,tarfile
r=Path(__file__).resolve().parent;repo=Path('D:/code/Lython');old=r.parent/'cased-word-stream-r440/refined';q=r/'quiet';q.mkdir();f=r/'frozen';f.mkdir();sha=lambda b:hashlib.sha256(b).hexdigest()
subprocess.run(['git','-C',str(repo),'diff','--exit-code','312f5911','HEAD','--','src/Lokad.Lython','Directory.Build.props','Directory.Packages.props','global.json'],check=True,stdout=subprocess.DEVNULL)
images={}
for role in ['reference','candidate']:
 shutil.copytree(old/'frozen/reference',f/role)
 for n in ['Lokad.Utf8Regex.dll','Lokad.Utf8Regex.PythonRe.dll']:shutil.copyfile(r/'assets'/role/'net11.0'/n,f/role/n)
 shutil.copyfile(r/role/'bin/Release/net11.0/Lokad.Lython.Utf8Regex.dll',f/role/'Lokad.Lython.Utf8Regex.dll')
 images[role]={p.name:sha(p.read_bytes())for p in(f/role).iterdir()if p.is_file()}
allowed={'Lokad.Lython.Utf8Regex.dll','Lokad.Utf8Regex.dll','Lokad.Utf8Regex.PythonRe.dll'}
assert {n for n in images['reference']if images['reference'][n]!=images['candidate'][n]}==allowed
catalog=(r.parent/'regex-producer-050-r409/comparison/catalog.json').read_bytes();manifest=json.loads(catalog)
assert len(manifest['cases'])==2
for c in manifest['cases']:
 ast.parse(c['source']);output=io.StringIO()
 with contextlib.redirect_stdout(output):exec(c['source'],{})
 assert output.getvalue()==c['expectedOutput']
 for name,key in [('source','sourceSha256'),('fixtureJson','fixtureSha256'),('expectedOutput','expectedOutputSha256')]:assert sha(c[name].encode())==c[key]
(q/'representative.json').write_bytes(catalog)
before=json.loads((old/'quiet/config.json').read_text(encoding='utf-8'));root='/home/lokad/lython-bench-checks/regex-dev105-b845-20261116';unit='lython-b845-regex-dev105-20261116'
files=before['sourceFiles'];imageFiles={role:{n:images[role][n]for n in files}for role in images}
ident=dict(sourceRevision='R443 old immutable0.5 versus0.5.0-dev.105; identical native adapter source and qualified0443core',purpose='Complete extraction/rewrite source-pair development producer comparison; no core or CPython gain attribution. Private parent+child semantics/cancellation qualified separately.',coreSHA256={label:images['reference']['Lokad.Lython.dll']for label in ['reference','reference-control','candidate','candidate-control']},imageFiles=imageFiles,candidateFocusedChecks=json.loads((r/'checks.json').read_text(encoding='utf-8')),nativeSourceSHA256=sha((r/'candidate/Utf8RegexProvider.cs').read_bytes()),assets=json.loads((r/'identity.json').read_text(encoding='utf-8'))['assets'],warmupSecondsPerProcess=4,normalPinUnchanged=True,coreProductionSourceMatchesQualifiedCommit=True,publicationHeld=True)
(q/'identity.json').write_text(json.dumps(ident,indent=2)+'\n',encoding='utf-8',newline='\n');(f/'identity.json').write_text(json.dumps(dict(images=images,scope=ident['sourceRevision'],publicationHeld=True),indent=2)+'\n',encoding='utf-8',newline='\n')
for n in ['collect.py','archive-owned.py','run.sh','retrieve.py']:
 s=(old/'quiet'/n).read_text(encoding='utf-8')
 if n=='collect.py':
  a=s.index('jobs=');b=s.index('\nenv =',a);s=s[:a]+"jobs=[['scripts.regex-range.extract','warm'],['scripts.regex-range.rewrite','warm']]\nassert len(jobs)==2 and all(case in cases for case,lane in jobs)\n"+s[b:]
 if n=='run.sh':s=s.replace('root='+before['root'],'root='+root)
 s=s.replace("len(raw['jobs'])==7","len(raw['jobs'])==2").replace('jobs=7','jobs=2').replace("['jobs']==7","['jobs']==2").replace('B843','B845')
 assert before['root']not in s and before['unit']not in s
 if n.endswith('.py'):ast.parse(s)
 (q/n).write_text(s,encoding='utf-8',newline='\n')
payload={n:(q/n).read_bytes()for n in ['identity.json','representative.json','collect.py','archive-owned.py','run.sh']}
for role in ['reference','candidate']:
 for n in allowed:payload[role+'/'+n]=(f/role/n).read_bytes()
with tarfile.open(q/'payload.tgz','w:gz')as t:
 for n,b in payload.items():m=tarfile.TarInfo(n);m.size=len(b);t.addfile(m,io.BytesIO(b))
c=dict(root=root,unit=unit,source=before['root'],sourceFiles=files,sourceCatalogSHA256=before['catalogSHA256'],catalogSHA256=sha(catalog),identity=ident,retireGroups=[],payloadBytes=(q/'payload.tgz').stat().st_size,payloadSHA256=sha((q/'payload.tgz').read_bytes()),unpackedBytes=sum(map(len,payload.values())))
(q/'config.json').write_text(json.dumps(c,indent=2)+'\n',encoding='utf-8',newline='\n')
s=(old/'quiet/remote-launch.py').read_text(encoding='utf-8');a=s.index('c=');b=s.index('\nb=Path',a);s=s[:a]+'c='+repr(c)+s[b:]
s=s.replace('lython-b843-fixtures','lython-b845-fixtures').replace(" os.link(source/'representative.json',root/'representative.json')\n",'')
ast.parse(s);(q/'remote-launch.py').write_text(s,encoding='utf-8',newline='\n')
s=(old/'launch-quiet.py').read_text(encoding='utf-8').replace('seconds=200','seconds=90').replace('Seven-job cased-word comparison','Two-job immutable-producer comparison').replace('before200seconds','before90seconds');ast.parse(s);(r/'launch.py').write_text(s,encoding='utf-8',newline='\n')
s=(old/'summarize.py').read_text(encoding='utf-8').replace("len(raw['jobs'])==7","len(raw['jobs'])==2");ast.parse(s);(r/'summarize.py').write_text(s,encoding='utf-8',newline='\n')
a=r/'allocation-short';a.mkdir()
for n in ['Program.cs','Allocation.csproj']:shutil.copyfile(old/'allocation-short'/n,a/n)
(a/'catalog.json').write_bytes(catalog);shutil.copytree(old/'allocation-short/bin',a/'bin');shutil.copyfile(old/'measure-allocation.py',r/'measure-allocation.py')
for n in ['collect.py','archive-owned.py']:assert 'Path(__file__).resolve().parent'in(q/n).read_text(encoding='utf-8')and '/home/lokad/lython-bench-checks/'not in(q/n).read_text(encoding='utf-8')
assert 'root='+root in(q/'run.sh').read_text(encoding='utf-8');assert "config=json.loads((r/'config.json')"in(q/'retrieve.py').read_text(encoding='utf-8')
with tarfile.open(q/'payload.tgz')as t:
 for n,b in payload.items():assert t.extractfile(n).read()==b
print(json.dumps(dict(jobs=2,catalogCases=2,goldensIndependentlyChecked=True,onlyProducerAndNecessaryAdapterRecompilationDiffer=True,core=images['reference']['Lokad.Lython.dll'],unpackedBytes=c['unpackedBytes'],retireGroups=0,allConcretePathsValidated=True)))
