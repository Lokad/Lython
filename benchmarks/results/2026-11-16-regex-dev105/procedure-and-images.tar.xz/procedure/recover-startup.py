from pathlib import Path
import hashlib,json,subprocess,tarfile
r=Path(__file__).resolve().parent/'quiet';c=json.loads((r/'config.json').read_text(encoding='utf-8'))
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
code=r'''from pathlib import Path
import fcntl,hashlib,json,os,shutil,subprocess,tarfile
c=CONFIG;r=Path(c['root']);base=r.parent
assert base==Path('/home/lokad/lython-bench-checks')and r.resolve()==r
with(base/'comparison-vm.lock').open('a')as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 state=subprocess.check_output(['systemctl','show',c['unit']+'.service','--property=ActiveState,MainPID,Result,ExecMainStatus'],text=True)
 assert 'ActiveState=failed'in state and'MainPID=0'in state and'ExecMainStatus=1'in state
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record'],capture_output=True).returncode==1
 ram=r/'guest-fixtures';assert ram.resolve()==ram and os.path.ismount(ram)
 raw={p.relative_to(ram).as_posix():hashlib.sha256(p.read_bytes()).hexdigest()for p in ram.rglob('*')if p.is_file()}
 stderr={str(p.relative_to(r)):p.read_text()for p in(r/'confirmation').glob('*.stderr')}
 (r/'initial-failure.json').write_text(json.dumps(dict(service=state,stderr=stderr,ramFiles=raw,journal=subprocess.check_output(['journalctl','-u',c['unit']+'.service','--no-pager'],text=True)),indent=2)+'\n')
 archive=r/'initial-failed-observations.tgz';assert not archive.exists()
 with tarfile.open(archive,'w:gz',dereference=True)as t:
  for p in sorted(r.iterdir()):
   if p.is_file()and p!=archive:t.add(p,arcname=p.name)
  t.add(r/'confirmation',arcname='confirmation');t.add(ram,arcname='guest-fixtures')
 with tarfile.open(archive)as t:
  for name,h in raw.items():assert hashlib.sha256(t.extractfile('guest-fixtures/'+name).read()).hexdigest()==h
 assert shutil.disk_usage(r).free>252*1024*1024
 subprocess.run(['sudo','-n','umount',str(ram)],check=True);ram.rmdir()
 receipt=dict(failedBeforeReady=True,serviceTerminal=True,allUsersJoined=True,allRamBytesArchivedAndVerifiedUnderLease=True,guestFixturesRemoved=True,archiveSHA256=hashlib.sha256(archive.read_bytes()).hexdigest(),stderr=stderr)
 (r/'initial-failed-cleanup.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt))
'''.replace('CONFIG',repr(c))
p=subprocess.run(ssh+['python3 -'],input=code,text=True,encoding='utf-8',capture_output=True,timeout=60);assert p.returncode==0,p.stderr
v=json.loads(p.stdout);(r/'initial-failed-cleanup.json').write_text(p.stdout,encoding='utf-8',newline='\n')
scp=['C:/Windows/System32/OpenSSH/scp.exe','-i',ssh[2],'-o','BatchMode=yes','-o','ConnectTimeout=15']
p=subprocess.run(scp+['lokad@20.166.121.73:'+c['root']+'/initial-failed-observations.tgz',str(r/'initial-failed-observations.tgz')],capture_output=True,timeout=60);assert p.returncode==0,p.stderr
assert hashlib.sha256((r/'initial-failed-observations.tgz').read_bytes()).hexdigest()==v['archiveSHA256']
with tarfile.open(r/'initial-failed-observations.tgz')as t:
 v2=json.loads(t.extractfile('initial-failure.json').read());(r/'initial-failure.json').write_text(json.dumps(v2,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps(v,indent=2))
