from pathlib import Path
import ast,hashlib,io,json,tarfile
r=Path(__file__).resolve().parent;old=r/'quiet';q=r/'corrected-quiet';q.mkdir();before=json.loads((old/'config.json').read_text(encoding='utf-8'));sha=lambda b:hashlib.sha256(b).hexdigest()
failure=json.loads((old/'initial-failed-cleanup.json').read_text(encoding='utf-8'));assert failure['serviceTerminal']and failure['allUsersJoined']and failure['allRamBytesArchivedAndVerifiedUnderLease']and failure['guestFixturesRemoved']
catalog=(r.parent/'regex-producer-050-r409/corrected-quiet/representative.json').read_bytes();manifest=json.loads(catalog);original=json.loads((old/'representative.json').read_text(encoding='utf-8'))
for a,b in zip(original['cases'],manifest['cases']):
 assert a['id']==b['id']and a['source']==b['source']and a['expectedOutput']==b['expectedOutput']
 fixture=json.loads(b['fixtureJson']);assert fixture['size']==b['size']and fixture['text']is None and fixture['inputFiles']=={}and fixture['outputFiles']=={}
(q/'representative.json').write_bytes(catalog)
root='/home/lokad/lython-bench-checks/regex-dev105-corrected-b846-20261116';unit='lython-b846-regex-dev105-corrected-20261116'
ident=dict(before['identity'],originalFailedStartupPreserved=True,fixtureMetadataCorrectionOnly=True)
(q/'identity.json').write_text(json.dumps(ident,indent=2)+'\n',encoding='utf-8',newline='\n')
for n in ['collect.py','archive-owned.py','run.sh','retrieve.py']:
 s=(old/n).read_text(encoding='utf-8').replace('B845','B846')
 if n=='run.sh':s=s.replace('root='+before['root'],'root='+root)
 assert before['root']not in s and before['unit']not in s
 if n.endswith('.py'):ast.parse(s)
 (q/n).write_text(s,encoding='utf-8',newline='\n')
payload={n:(q/n).read_bytes()for n in ['identity.json','representative.json','collect.py','archive-owned.py','run.sh']}
with tarfile.open(q/'payload.tgz','w:gz')as t:
 for n,b in payload.items():m=tarfile.TarInfo(n);m.size=len(b);t.addfile(m,io.BytesIO(b))
c=dict(root=root,unit=unit,source=before['root'],sourceFiles=ident['imageFiles']['reference'],sourceCatalogSHA256=before['catalogSHA256'],catalogSHA256=sha(catalog),identity=ident,retireGroups=[],payloadBytes=(q/'payload.tgz').stat().st_size,payloadSHA256=sha((q/'payload.tgz').read_bytes()),unpackedBytes=sum(map(len,payload.values())))
(q/'config.json').write_text(json.dumps(c,indent=2)+'\n',encoding='utf-8',newline='\n')
s=(old/'remote-launch.py').read_text(encoding='utf-8');a=s.index('c=');b=s.index('\nb=Path',a);s=s[:a]+'c='+repr(c)+s[b:]
s=s.replace(" original=json.loads((source/'archive-receipt.json').read_text());assert original['complete']and original['allWorkersJoined']and original['guestFixturesRemoved']and original['archivedAndVerifiedUnderLease']", " original=json.loads((source/'initial-failed-cleanup.json').read_text());assert original['serviceTerminal']and original['allUsersJoined']and original['guestFixturesRemoved']and original['allRamBytesArchivedAndVerifiedUnderLease']")
assert "source/'archive-receipt.json'"not in s
s=s.replace("os.link(source/'reference'/n,p)","os.link(source/role/n,p)").replace('lython-b845-fixtures','lython-b846-fixtures')
ast.parse(s);(q/'remote-launch.py').write_text(s,encoding='utf-8',newline='\n')
s=(r/'launch.py').read_text(encoding='utf-8').replace("parent/'quiet'","parent/'corrected-quiet'");ast.parse(s);(r/'launch-corrected.py').write_text(s,encoding='utf-8',newline='\n')
s=(r/'summarize.py').read_text(encoding='utf-8').replace("quiet/retrieved/confirmation/confirmation.json","corrected-quiet/retrieved/confirmation/confirmation.json");ast.parse(s);(r/'summarize-corrected.py').write_text(s,encoding='utf-8',newline='\n')
for n in ['collect.py','archive-owned.py']:assert 'Path(__file__).resolve().parent'in(q/n).read_text(encoding='utf-8')
assert 'root='+root in(q/'run.sh').read_text(encoding='utf-8');assert "config=json.loads((r/'config.json')"in(q/'retrieve.py').read_text(encoding='utf-8')
with tarfile.open(q/'payload.tgz')as t:
 for n,b in payload.items():assert t.extractfile(n).read()==b
print(json.dumps(dict(originalFailurePreserved=True,metadataCorrected=True,scriptsAndGoldensUnchanged=True,fullImagesUnchanged=True,jobs=2,newUnit=unit,unpackedBytes=c['unpackedBytes'])))
