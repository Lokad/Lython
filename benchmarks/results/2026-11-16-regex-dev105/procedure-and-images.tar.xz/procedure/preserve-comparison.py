from pathlib import Path
import hashlib,json,shutil,tarfile
r=Path(__file__).resolve().parent;repo=Path('D:/code/Lython');out=repo/'benchmarks/results/2026-11-16-regex-dev105';q=r/'corrected-quiet'
receipt=json.loads((q/'archive-receipt.json').read_text(encoding='utf-8'));assert receipt['complete']and receipt['jobs']==2 and receipt['allWorkersJoined']and receipt['quietBeforeAndAfter']
assert hashlib.sha256((q/'observations.tgz').read_bytes()).hexdigest()==receipt['archiveSHA256']
for n in ['identity.json','observations.tgz','archive-receipt.json','terminal-status.json']:shutil.copyfile(q/n,out/n)
v=json.loads((r/'summary.json').read_text(encoding='utf-8'));v.update(retentionDecisionPending=False,developmentQualificationComplete=True,normalAdapterPinChanged=False,decision='Qualify immutabledev105 for continued development. Same native adapter source and qualified0443core. Rewrite elapsed/CPU lower,extraction uncertain,allocation flat. Final released-package qualification remains pending precise producer gaps. No normal pin/dependency or safety-certification change.')
(r/'summary.json').write_text(json.dumps(v,indent=2)+'\n',encoding='utf-8',newline='\n')
for n in ['summary.json','allocation-summary.json','published-versions.json','published-observation.json']:shutil.copyfile(r/n,out/n)
for n in ['initial-failed-observations.tgz','initial-failed-cleanup.json','initial-failure.json']:shutil.copyfile(r/'quiet'/n,out/n)
with tarfile.open(out/'procedure-and-images.tar.xz','w:xz')as t:
 for p in r.glob('*.py'):t.add(p,arcname='procedure/'+p.name)
 for p in r.glob('preflight-*'):t.add(p,arcname=p.name)
 for n in ['Program.cs','Allocation.csproj','catalog.json','reference.json','candidate.json','image-hashes.json']:t.add(r/'allocation-short'/n,arcname='allocation/'+n)
 t.add(r/'frozen/identity.json',arcname='frozen/identity.json')
 for role in ['reference','candidate']:
  for n in ['Lokad.Lython.Utf8Regex.dll','Lokad.Utf8Regex.dll','Lokad.Utf8Regex.PythonRe.dll']:t.add(r/'frozen'/role/n,arcname='frozen/'+role+'/'+n)
 for label,folder in [('initial-quiet',r/'quiet'),('corrected-quiet',q)]:
  for p in folder.iterdir():
   if p.is_file()and p.name not in ['observations.tgz','payload.tgz','initial-failed-observations.tgz']:t.add(p,arcname=label+'/'+p.name)
rows=[]
for name,x in zip(['Extract512named integer captures','Rewrite512named captures'],v['rows']):
 e=x['elapsedChangePercent'];c=x['cpuChangePercent'];rows.append(f"| {name} | {min(e):+.2f}..{max(e):+.2f}% | {min(c):+.2f}..{max(c):+.2f}% | {x['referenceSpreadPercent']:.2f}/{x['candidateSpreadPercent']:.2f}% |")
(out/'README.md').write_text('''# Immutable dev105 regex development qualification

R443/B846,2026-11-16UTC. Compare the earlier immutable0.5producer qualified under
R409 against0.5.0-dev.105. Both use identical R409native adapter source,qualified
0443core and unchanged comparison workers. Only the two producer assemblies and
necessary adapter-reference recompilation differ. This is development qualification;
the normal nonpackable adapter remains0.4,and core has no producer dependency.

| Complete warm script | Elapsed change | Wider process CPU change | Ref/candidate elapsed control spread |
| --- | ---: | ---: | ---: |
'''+ '\n'.join(rows)+'''

All four source-process median pairings remain. Rewrite has supporting elapsed/
CPU improvement; extraction is inconclusive with2.12%candidate-control movement.
Allocation is unchanged: extraction341592B and rewrite170432B per local complete
invocation. Accounted peaks174351/21803B are unchanged. No core/CPython gain,
cross-producer attribution to a particular optimization,physical heap or latency
claim. Earlier R409adapter-transport improvements remain a separate source pair.

Both immutable producers pass363public regex checks each on actual.NET11and10,
using matching private parent/child images. [Fixture identity correction](fixture-identity/README.md)
documents the historical private-parent/normal-child gap and three deliberate
hash-mismatch failures. Real current-token compile/match/cursor interruption,
unwind,refused admission,retained owners and budget reuse pass. Core's cooperating-
provider contract tests remain separate from actual-backend qualification.

Retain dev105as a qualified development input,not a normal pin or released adapter.
Native cursor ranges/current advance tokens and program disposal work. Keep the
UTF8flag/construction-token/coarse-storage bridges. Native UTF8name enumeration,
preparation with the current token and separate per-match result-stage allowance
remain precise final adapter limitations. Single-shot matching still uses backend
detailed snapshots; native range-only cursor transport does not imply all producer
string projection disappears. No producer unsafe-policy certification follows.
The official NuGet index still lists only0.1through0.4at the recorded observation;
no newer published asset was assumed. Producer timing does not block core work.

Same two complete Unicode/capture scripts and independent output/file goldens in
every source process. Quiet F4as_v7/Ubuntu24.04.4/four EPYC9V45vCPUs,16GiB/no swap,
.NET11RC3 workstation GC/normal tiering. Four-second full-request warmups,five
rotated approximately0.5s rounds. Warm includes Run,output/file goldens and prior-
result cleanup; excludes compilation/startup,fixture reset/protocol and final cache
teardown. Wider CPU includes reset/protocol. The explicit empty file host performs
no guest I/O. Local allocation includes reset/validation/cleanup and uses natural
GC process counters; it does not establish elapsed/CPU. Compilation/startup,
pending-I/O,contention and embedding tails were not measured.

Initial B845fails before Ready because the reused historical comparison catalog
omitted required fixture size/text metadata. No timing observations exist. All
workers joined; failure/journal and every RAM byte were archived/verified before
unmount. B846uses the actual corrected historical catalog: only those unused
metadata fields and their digest change; scripts,inputs,outputs,binaries/settings
remain identical. Both frozen images then pass the existing local comparison
verify command against independent CPython,with no timing claim. This preflight
should precede future VM staging. All initial conditions remain preserved.

B846finishes64.057s; full-image/golden/quiet/Closed/join/archive gates pass. All
users joined and RAM fixtures removed; terminal cached forever. No working-copy
retirement was needed; canonical assets/current images and254/252MiBfloors remain.
Cumulative core Windows/Ubuntu,actual11/10,stress and installed-package delivery
43869939863 is independent and pending at this record. Publication remains held;
non-regex complete-script execution gaps remain unresolved.

[Raw](observations.tgz),[medians/controls](summary.json),[allocation](allocation-summary.json),
[asset/worker identity](identity.json),[procedures/images/preflight](procedure-and-images.tar.xz),
[initial failure](initial-failed-observations.tgz),[published-version observation](published-observation.json).
''',encoding='utf-8',newline='\n')
p=repo/'benchmarks/EXPERIMENTS.md';s=p.read_text(encoding='utf-8');a=s.index('[R443 exact regex subprocess identity]');s=s[:a]+'''[R443/B846 immutable dev105](results/2026-11-16-regex-dev105/README.md)
qualifies changed producer assets with identical native adapter source/0443core.
Rewrite elapsed−8.59..−6.25%/CPU−8.09..−6.61%; extraction inconclusive with2.12%
candidate control,allocation flat.363regex checks eachactual11/10 for both private
producers include actual matched child cancellation.64.057s/all gates; original
metadata startup failure/no timings and correction preserved. Normal0.4pin/core
dependency unchanged,three final capability gaps explicit. Full43869939863pending;
publication held and non-regex whole-script uncertainty remains.

'''+s[a:];p.write_text(s,encoding='utf-8',newline='\n')
p=repo/'AGENTS.md';s=p.read_text(encoding='utf-8');needle='against its recorded hashes before use; checking only the core DLL is insufficient.';assert needle in s
s=s.replace(needle,needle+'\nValidate custom comparison catalogs through the existing verification command with\nthe actual frozen worker images before staging a quiet-VM collection.');p.write_text(s,encoding='utf-8',newline='\n')
p=repo/'benchmarks/README.md';s=p.read_text(encoding='utf-8');needle='reported separately. Complete output checks and declared owners remain active.';assert needle in s
s=s.replace(needle,needle+'\nRun the existing `--compare verify` command against each frozen worker image and\ncustom catalog before VM staging. Even file-only fixtures require their matching\n`size` and nullable `text` metadata; parser success alone does not validate the\nworker protocol.');p.write_text(s,encoding='utf-8',newline='\n')
p=repo/'PLAN.md';s=p.read_text(encoding='utf-8');s=s.replace('Updated2026-11-16UTC(R442closed/R443development-adapter).','Updated2026-11-16UTC(R443development-qualified/cumulative-delivery-active).')
s=s.replace('immutable development0.5 and normal0.4 each361public regex checks per actual11/10. Contract tests,adapter semantics and backend performance are separate. Normal pin unchanged; missing capabilities defer only affected final adapter qualification.','immutable development0.5 parent semantics originally361eachactual11/10; three child checks did not prove private producer identity. R443corrects that gap with actual matched-child363checks eachtarget for old0.5/dev105. Contract,semantics and performance remain separate. Normal pin unchanged; missing capabilities defer only affected final adapter qualification.')
needle='| Independent adapter prototype |';a=s.index(needle);s=s[:a]+'''| Qualified development input | [R443/B846](benchmarks/results/2026-11-16-regex-dev105/README.md),old immutable0.5 versusdev105,same native source/0443core. Rewrite elapsed−8.59..−6.25%/CPU−8.09..−6.61%; extraction uncertain,allocation flat.363regex checks eachactual11/10 per producer with matching subprocess hashes. Initial startup-metadata failure/correction retained. No normal pin/core dependency or safety certification. |
| Committed,full qualification active | Exact fixture identityc18babe9 and cumulative independent ownership coverage. Full43869939863dispatch,Windows/Ubuntu actual11/10+original stress+installed Release consumers; terminal not yet known. New snapshots/receipts pending,do not claim fully qualified. |
'''+s[a:]
a=s.index('### 1. R443:');b=s.index('### 2. Remaining substantial roadmap',a)
s=s[:a]+'''### 1. Close cumulative delivery; preserve independent remaining work

**Active delivery.** c18babe9corrects actual regex-subprocess evidence and includes
the independent pending-cleanup/cased ownership regressions since R436. Normal0.4
passes6lifetime cases eachactual11/10. Full43869939863is running Windows/Ubuntu,
actual11/10,original stress and installed Release consumers. Cache terminal/logs
and verify the meaningful summaries plus committed input identity when complete.
Poll at least240s apart; do independent work meanwhile. Do not repeat unchanged
past qualification. Publication/tagging remain held.

**Completed independent milestone.** R443freezes immutabledev105packages and
qualifies363regex cases eachactual11/10 against both old0.5/dev105with matching
private children. Three deliberate wrong-child hashes fail. Same native source/
qualified0443core; B846rewrite6–9%lower elapsed with supporting CPU,extraction
uncertain,allocation flat. Initial B845metadata failure has no timing observations;
all raw conditions,cleanup and correction retained. Local frozen-worker verification
passes; it precedes future VM staging. No normal0.4pin/core dependency change.

**Remaining development.** R442complete call/frame design pass closes unresolved:
final-slot binding already exists,consumed-operand reuse adds aliasing/lifetime
obligations beyond slowerR411,and managed block compilation lacks a demonstrated
one-shot/full-replacement case. Preserve qualified native code and all adversity;
do not relabel whole-script gaps solved. Continue only with a genuinely displaced
stage and explicit compile-to-result/semantic/controlled comparison gate,not another
carrier or narrow opcode fusion. The substantial roadmap below remains independent
of producer publication. R443's precise final adapter gaps stay in track3.

'''+s[b:]
s=s.replace('0.5.0-dev.105 selected underR443. R409 evidence is historical,not this new package.','0.5.0-dev.105 qualified underR443(363regex checks eachactual11/10 with real\nmatching private subprocesses). R409 evidence is historical,not this new package.')
p.write_text(s,encoding='utf-8',newline='\n')
print('R443 qualified development assets/performance and original failed conditions preserved; normal pin unchanged,cumulative CI active.')
