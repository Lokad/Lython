from pathlib import Path
import hashlib,json,os,subprocess

lab=Path(__file__).resolve().parent
donor=lab.parent/'abstract-value-facts-r589'
older=lab.parent/'post-transport-cpython-r580'
annotation=lab.parent/'function-annotation-storage-r583'
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def save(name,value):
    (lab/name).write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
old=load(older/'representative.json')
annotation_case=next(c for c in load(annotation/'catalog.json')['cases'] if c['id']=='scripts.annotated-rule-closures')
old['cases']=[c for c in old['cases'] if c['id'] in {'scripts.report-forwarding.expanded','scripts.rule-default-closures'}]
old['cases'].append(annotation_case)
assert len(old['cases'])==3
save('representative.json',old)
frozen=donor/'frozen/reference'
manifest=load(donor/'frozen-identity.json')
assert manifest['referenceCommit']=='faeec7e81'
files=manifest['images']['reference']
assert len(files)==32 and {name:sha(frozen/name) for name in files}==files
assert not subprocess.check_output(['git','diff','--name-only','8b8f5d4e1','faeec7e81','--','src','tests'])
sdk=Path.home()/'.dotnet11'
dotnet=sdk/'dotnet.exe'
env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk),PATH=str(sdk)+os.pathsep+os.environ['PATH'])
catalog=lab/'representative.json'
with (lab/'verify.log').open('wb') as log:
    subprocess.run([dotnet,frozen/'Lokad.Lython.Benchmarks.dll','--compare','verify','--catalog',catalog,
        '--dotnet',dotnet,'--python','C:/Python313/python.exe','--python-worker',Path.cwd()/'benchmarks/cpython-worker.py',
        '--out',lab/'verify.json'],env=env,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=75)
check=load(lab/'verify.json')
assert check['state']=='Completed' and check['catalogSha256']==sha(catalog)
stage=(older/'stage.py').read_text(encoding='utf-8')
stage=stage.replace('exact-keyword-transport-r579','abstract-value-facts-r589')
stage=stage.replace('phase = lab.parent / "retained-cpython-r576"', 'phase = lab.parent / "post-transport-cpython-r580"')
stage=stage.replace('prior["identity"]["imageFiles"]["candidate"]','prior["identity"]["imageFiles"]["reference"]')
stage=stage.replace('startswith("d97f6f98")','startswith("'+files['Lokad.Lython.dll'][:8]+'")')
stage=stage.replace('"frozen/candidate"','"frozen/reference"')
stage=stage.replace('post-transport-cpython-b1006-20261118','annotation-and-forwarding-cpython-b1016-20261118')
stage=stage.replace('lython-b1006-post-transport-cpython-20261118','lython-b1016-annotation-and-forwarding-cpython-20261118')
stage=stage.replace('sourceRevision="03bb07cf5"','sourceRevision="faeec7e81"')
stage=stage.replace('"1e7f1d526","03bb07cf5","--","src"','"8b8f5d4e1","faeec7e81","--","src","tests"')
stage=stage.replace('replace("B1002","B1006").replace("started<390","started<300")','replace("B1006","B1016")')
stage=stage.replace('/home/lokad/lython-bench-checks/retained-cpython-b1002-20261118','/home/lokad/lython-bench-checks/post-transport-cpython-b1006-20261118')
stage=stage.replace('sourceRole="candidate"','sourceRole="reference"')
stage=stage.replace('lython-b1005-fixtures","lython-b1006-fixtures','lython-b1015-fixtures","lython-b1016-fixtures')
stage=stage.replace('.replace("seconds=345","seconds=235").replace("345 seconds","235 seconds").replace("B1002","B1006")',
                    '.replace("B1006","B1016")')
stage=stage.replace('.replace("[\'jobs\']==5","[\'jobs\']==3").replace("B1002","B1006")','.replace("B1006","B1016")')
compile(stage,'stage.py','exec')
(lab/'stage.py').write_text(stage,encoding='utf-8',newline='\n')
print("Verified R587 checkpoint source for the three external cases",files['Lokad.Lython.dll'][:8])
