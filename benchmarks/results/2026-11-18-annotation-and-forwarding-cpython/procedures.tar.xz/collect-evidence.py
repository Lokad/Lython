from pathlib import Path

lab=Path(__file__).resolve().parent
script=(lab.parent/'retained-cpython-r576/archive.py').read_text(encoding='utf-8')
script=script.replace('2026-11-18-direct-defaults-cpython-checkpoint','2026-11-18-annotation-and-forwarding-cpython')
script=script.replace('53df08565','faeec7e81').replace('B1002','B1016')
script=script.replace('== 5','== 3')
exec(compile(script,str(__file__),'exec'))
