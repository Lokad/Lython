from pathlib import Path
import hashlib,json,shutil,tarfile

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
out=repo/'benchmarks/results/2026-11-24-retained-rule-factory-cpu'
out.mkdir(exist_ok=True)
read=lambda path:json.loads(path.read_text(encoding='utf-8'))
sha=lambda data:hashlib.sha256(data).hexdigest()
digest=lambda path:sha(path.read_bytes())
status=read(lab/'terminal-status.json')
assert not status['live'] and not status['fixtures'] and status['exitCode']=='0'
receipt=status['receipt']
assert all(receipt[k] for k in ('complete','quietBeforeAndAfter','allWorkersJoined','guestFixturesRemoved','archivedAndVerifiedUnderLease'))
assert digest(lab/'observations.tar.xz')==receipt['archiveSHA256']
identity=read(lab/'identity.json')
verification=read(lab/'verification.json')
assert verification['state']=='Completed' and verification['caseCount']==2
assert verification['catalogSha256']==identity['profileCatalogSHA256']==digest(lab/'catalog.json')
assert verification['launched']['library']['sha256']==identity['coreSHA256']['candidate']
catalog=read(lab/'catalog.json')
assert len(identity['imageFiles']['candidate'])==32
assert all(digest(lab.with_name('external-arithmetic-operands-20261124')/'candidate'/name)==checksum
           for name,checksum in identity['imageFiles']['candidate'].items())
by_id={row['id']:row for row in catalog['cases']}
rows=read(lab/'attribution.json')['rows']
with tarfile.open(lab/'observations.tar.xz') as captured:
    assert sha(captured.extractfile('identity.json').read())==digest(lab/'identity.json')
    assert sha(captured.extractfile('catalog.json').read())==digest(lab/'catalog.json')
    assert len(rows)==len(by_id)==2
    for row in rows:
        label=row['label']
        case=by_id[row['case']]
        record=json.load(captured.extractfile(f'profiles/{label}/record.json'))
        assert record['exitCode']==0 and record['closed']['status']=='Closed'
        assert record['workload']==row['case'] and record['lane']=='warm' and record['warmupSeconds']>=8
        assert record['response']['completedInvocations']==row['invocations']
        assert all(batch['actualOutputSha256']==case['expectedOutputSha256'] for batch in record['batches'])
        assert sum(row['exclusiveNearestRuntimeGroups'].values())==row['guestRuntimeAncestry']
        assert row['sampleCount']>=1000
for name in ('attribution.json','identity.json','verification.json','terminal-status.json','observations.tar.xz'):
    shutil.copyfile(lab/name,out/name)
inputs=('prepare.py','archive.py','analyze.py','quiet.py','ops-profile.py','collect.py','run.sh','catalog.json','launch.log')
with tarfile.open(out/'procedures.tar.xz','w:xz') as archive:
    for name in inputs:archive.add(lab/name,arcname=name,recursive=False)
with tarfile.open(out/'procedures.tar.xz') as evidence:
    assert len(evidence.getnames())==len(inputs)
    assert all(sha(evidence.extractfile(name).read())==digest(lab/name) for name in inputs)

