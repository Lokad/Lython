from pathlib import Path
import hashlib,json,shutil,subprocess
lab=Path(__file__).resolve().parent
repo=lab.parents[3]
root=lab.parent
prior=root/'current-rule-cpu-20261124'
donor=root/'external-arithmetic-operands-20261124'
external=root/'rule-activation-cpython-20261124'/'external'
def read(path):
    return json.loads(path.read_text(encoding='utf-8'))
def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
def write(name,value):
    (lab/name).write_text(value,encoding='utf-8',newline='\n')
def save(name,value):
    write(name,json.dumps(value,ensure_ascii=False,indent=2)+'\n')
def script(name,changes):
    source=(prior/name).read_text(encoding='utf-8')
    for before,after in changes:
        assert before in source,(name,before)
        source=source.replace(before,after)
    if name.endswith('.py'): compile(source,name,'exec')
    write(name,source)
identity=read(external/'identity.json')
subprocess.run(['git','diff','--exit-code',identity['sourceRevision'],'f17898c19','--','src','tests'],cwd=repo,check=True)
receipt=read(donor/'comparison/quiet/terminal-status.json')['receipt']
assert receipt['complete'] and receipt['archivedAndVerifiedUnderLease']
assert digest(donor/'comparison/quiet/observations.tar.xz')==receipt['archiveSHA256']
assert len(identity['imageFiles']['candidate'])==32
assert all(digest(donor/'candidate'/name)==checksum for name,checksum in identity['imageFiles']['candidate'].items())
catalog=read(external/'representative.json')
catalog['cases']=[case for case in catalog['cases'] if case['id'] in (
    'scripts.captured-rule-closures','scripts.rule-default-closures')]
assert len(catalog['cases'])==2
save('catalog.json',catalog)
identity.update(purpose='B1577 attribute rule factories after eliminating scalar helper activations',
    donorArchiveSHA256=receipt['archiveSHA256'],profileCatalogSHA256=digest(lab/'catalog.json'),
    externalTimingSHA256=digest(external/'observations.tar.xz'))
save('identity.json',identity)
script('collect.py',[
    ('exact-unicode-float-b1560-20261124/candidate','external-arithmetic-operands-b1574-20261124/candidate'),
    ('b1565-fixtures','b1577-fixtures')])
script('quiet.py',[
    ('current-rule-cpu-b1565-20261124','retained-rule-factory-cpu-b1577-20261124'),
    ('b1565-current-rule-cpu','b1577-retained-rule-factory-cpu'),
    ('exact-unicode-float-20261124/candidate','external-arithmetic-operands-20261124/candidate'),
    ('checked["caseCount"]==3','checked["caseCount"]==2'),
    ('the three generated rule scripts','two generated rule scripts')])
script('ops-profile.py',[
    ("[('default-warm', 'scripts.rule-default-closures', 'warm'), ('annotated-warm', 'scripts.annotated-rule-closures', 'warm'), ('captured-warm', 'scripts.captured-rule-closures', 'warm')]",
     "[('default-warm', 'scripts.rule-default-closures', 'warm'), ('captured-warm', 'scripts.captured-rule-closures', 'warm')]")])
script('analyze.py',[
    ("['default-warm', 'annotated-warm', 'captured-warm']","['default-warm', 'captured-warm']")])
script('archive.py',[
    ('2026-11-24-generated-rule-cpu','2026-11-24-retained-rule-factory-cpu'),
    ("verification['caseCount']==3","verification['caseCount']==2"),
    ("len(rows)==len(by_id)==3","len(rows)==len(by_id)==2"),
    ("lab.with_name('exact-unicode-float-20261124')","lab.with_name('external-arithmetic-operands-20261124')")])
shutil.copyfile(prior/'run.sh',lab/'run.sh')
assert b'\r' not in (lab/'run.sh').read_bytes()
