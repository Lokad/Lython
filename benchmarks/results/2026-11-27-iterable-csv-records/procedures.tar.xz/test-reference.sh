set -eu
source=/mnt/d/code/Lython
target="$HOME/lython-starmap-rows-8066Vm"
for file in src/Lokad.Lython/Runtime/LythonRuntime.CsvModule.cs src/Lokad.Lython/Runtime/LythonRuntime.CsvObjects.cs tests/Lokad.Lython.Tests/CsvPrivateRecordOwnershipTests.cs; do
    cp -- "$source/$file" "$target/$file"
    cmp -- "$source/$file" "$target/$file"
done
cd "$target"
"$HOME/.dotnet/dotnet" test tests/Lokad.Lython.Tests/Lokad.Lython.Tests.csproj -c Release -f net10.0 --no-restore --filter FullyQualifiedName~IterableRecordAdmissionProtectsTheRowAndRevalidatesTheHeader