from base64 import b64decode
import csv
from pathlib import Path
from hashlib import sha256
import json

lab = Path(__file__).resolve().parent
notes = lab.parent
earlier = notes / 'inline-whole-regex-match-20261127'
read = lambda path: json.loads(path.read_text(encoding='utf-8-sig'))
digest = lambda text: sha256(text.encode('utf-8')).hexdigest()
base = read(notes / 'annotation-demand-r38/b389/representative.json')
control = next(row for row in base['cases'] if row['id'] == 'scripts.csv-summary-functions.large')
quoted_id = 'scripts.csv-invoice.method-policy.quoted-control'
quoted = next(row for row in read(notes / 'csv-window-source-gate-20261126/local/representative.json')['cases']
              if row['id'] == quoted_id)
source = control['source']
original = '    for row in csv.DictReader(source):'
assert source.count(original) == 1
list_id = 'diagnostic.csv-summary-list-input'
iterator_id = 'diagnostic.csv-summary-iterator-input'
list_source = source.replace(original, '    for row in csv.DictReader(source.read().splitlines(keepends=True)):')
iterator_source = source.replace(original, '    for row in csv.DictReader(lines(source)):')

def lines_prefix(source):
    return 'def lines(source):\n    for line in source:\n        yield line\n\n' + source

def variant(name, script):
    return control | dict(id=name, source=script, sourceUtf8Bytes=len(script.encode('utf-8')), sourceSha256=digest(script))

def write(name, data):
    (lab / name).write_text(json.dumps(data, ensure_ascii=False, indent=2) + '\n', encoding='utf-8', newline='\n')

fixture = json.loads(control['fixtureJson'])
payload = b64decode(fixture['inputFiles']['input.csv'])
lines = payload.decode('utf-8').splitlines(keepends=True)
rows = list(csv.reader(lines))
assert len(rows) == 4097
assert len(set(rows[0])) == len(rows[0]) and all(len(row) == len(rows[0]) for row in rows)
quoted_fixture = json.loads(quoted['fixtureJson'])
quoted_rows = list(csv.reader(b64decode(quoted_fixture['inputFiles']['input.csv']).decode('utf-8').splitlines(keepends=True)))
write('representative.json', base | {'cases': [variant(list_id, list_source),
                                              variant(iterator_id, lines_prefix(iterator_source)), control, quoted]})
write('fixture-census.json', dict(records=len(rows)-1, bytes=len(payload), header=rows[0],
                                quotedRecords=len(quoted_rows)-1, quotedInputBytes=sum(
                                len(b64decode(value)) for value in quoted_fixture['inputFiles'].values())))

def emit(name, text):
    (lab / name).write_text(text, encoding='utf-8', newline='\n')

prep = (earlier / 'prepare.py').read_text(encoding='utf-8')
for before, after in (
    ("image_base=lab.with_name('nested-json-layouts-20261127')/'local'", "image_base=lab.with_name('inline-whole-regex-match-20261127')/'local'"),
    ("assert head.startswith('3cb9a1240')", "assert head.startswith('6bed7e6c0')"),
    ("assert pin['sourceRevision'].startswith('f48ab7583')", "assert pin['sourceRevision'].startswith('3cb9a1240')"),
    ("file_fed='diagnostic.shipment-file-fed-map'\nwhole='diagnostic.regex-extract-whole'\ncaptured='diagnostic.regex-extract-captured'",
     "file_fed='scripts.csv-summary-functions.large'\nlist_input='diagnostic.csv-summary-list-input'\n"
     "iterator_input='diagnostic.csv-summary-iterator-input'\nquoted='scripts.csv-invoice.method-policy.quoted-control'"),
    ("{file_fed,whole,captured}", "{file_fed,list_input,iterator_input,quoted}"),
    ("lython-inline-whole-regex-match-fixture-", "lython-iterable-csv-records-fixture-"),
    ("[[file_fed,'warm-async'],[whole,'warm'],[captured,'warm'],[whole,'warm-async']]",
     "[[file_fed,'warm-async'],[list_input,'warm'],[quoted,'warm'],[iterator_input,'warm-async']]"),
    ("['git','rev-parse','3cb9a1240']", "['git','rev-parse','6bed7e6c0']"),
    ("Store the sole projected whole-match range in the existing result. Named captures and file-fed map are controls.",
     "Use existing direct DictReader row admission for list and iterator input. Buffered and quoted inputs are controls."),
    ("checked['caseCount']==3", "checked['caseCount']==4"),
):
    assert prep.count(before) == 1, before
    prep = prep.replace(before, after)
compile(prep,'prepare.py','exec')
emit('prepare.py', prep)
emit('stage.sh', (earlier / 'stage.sh').read_text(encoding='utf-8').replace('lython-inline-whole-regex-match-', 'lython-iterable-csv-records-'))
emit('summarize.py', (earlier / 'summarize.py').read_text(encoding='utf-8'))
