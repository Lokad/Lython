from hashlib import sha256
from pathlib import Path
from shutil import copyfile, copytree
import json
import subprocess


root = Path(__file__).resolve().parent
repo = root.parents[3]
pair = root.parent / 'borrow-regex-arguments-20261127/comparison'
previous = root.parent / 'wsl-shipment-cpython-20261127'
read = lambda p: json.loads(p.read_bytes())


def sha(path):
    return sha256(path.read_bytes()).hexdigest()


def write(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n', encoding='utf-8', newline='\n')


trial = read(pair / 'identity.json')
inspected = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repo, text=True).strip()
source = subprocess.check_output(['git', 'diff', '--binary', trial['sourceRevision'], inspected, '--',
                                 'src'], cwd=repo)
assert sha256(source).hexdigest() == trial['sourcePatchSHA256']
assert not subprocess.check_output(['git', 'diff', trial['sourceRevision'], inspected, '--', 'src/Lokad.Lython.Utf8Regex'], cwd=repo)
assert not subprocess.check_output(['git', 'status', '--porcelain', '--', 'src'], cwd=repo)
frozen = trial['imageFiles']['candidate']
assert {p.name: sha(p) for p in (pair / 'candidate').iterdir()} == frozen
copytree(pair / 'candidate', root / 'candidate')
assert {p.name: sha(p) for p in (root / 'candidate').iterdir()} == frozen

catalog = read(pair / 'representative.json')
assert sha(pair / 'representative.json') == trial['catalogs']['representative.json']['sha256']
nested = root.parent / 'nested-json-layouts-20261127/local/representative.json'
donor = read(nested)
shapes = {case['id']: case for case in donor['cases']}
document = 'diagnostic.nested-json-document'
lines = 'diagnostic.nested-json-lines'
file_map = 'diagnostic.shipment-file-fed-map'
prior = root.parent / 'post-ready-insertion-cpython-20261127/comparison/quiet'
prior_cases = {case['id']: case for case in read(prior / 'representative.json')['cases']}
for key in ('sourceSha256', 'fixtureSha256', 'expectedOutputSha256', 'expectedFilesSha256'):
    assert shapes[document].get(key) == prior_cases[document].get(key)
donor['cases'] = [shapes[case] for case in (document, lines, file_map)]
write(root / 'representative.json', donor)
write(root / 'jobs.json', [[document, 'paired'], [lines, 'paired'], [file_map, 'warm-async']])
pin = read(previous / 'identity.json')
for name in ('cpython-worker.py', 'run.sh'):
    copyfile(previous / name, root / name)
assert sha(root / 'cpython-worker.py') == pin['cpythonWorkerSHA256']
assert b'\r' not in (root / 'run.sh').read_bytes()
producer = root.parent / 'bench-cpython-3.13.16-runtime'
archives = read(producer / 'identity.json')
assert {p.relative_to(producer / 'runtime').as_posix():sha(p)
        for p in (producer / 'runtime').rglob('*') if p.is_file()} == archives['files']
assert archives['source']['sha256'] == trial['expectedCPythonSHA256'] == pin['expectedCPythonSHA256']
pin.update(sourceRevision=inspected, inspectedHead=inspected, imageFiles={'candidate': frozen},
           purpose='Compare current nested JSON document and Lines processing against stock CPython.',
           frozenImage=trial['cpythonPath'].split('/bench-cpython-')[0] + '/wsl-nested-json-cpython-20261127/candidate',
           signedPackageSHA256=trial['signedPackageSHA256'])
pin['coreSHA256'] = {r: frozen['Lokad.Lython.dll'] for r in ('candidate', 'candidate-control')}
pin['auxiliaryFiles'] = frozen
pin['catalogs'] = {name: {'sha256': sha(root / name)} for name in ('representative.json', 'jobs.json')}
write(root / 'identity.json', pin)
collector = (previous / 'collect.py').read_text(encoding='utf-8')
collector = collector.replace('assert len(jobs) == 3', 'assert len(jobs) == 3')
collector = collector.replace('lython-b1881-shipment-guest-', 'lython-b1888-nested-json-guest-')
compile(collector, 'collect.py', 'exec')
(root / 'collect.py').write_text(collector, encoding='utf-8', newline='\n')
