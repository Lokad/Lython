from pathlib import Path
from shutil import copyfile, copytree
from hashlib import sha256
import json
p=Path(__file__).resolve().parent
origin=p.parent
read=lambda path:json.loads(path.read_bytes())
def sha(path):return sha256(path.read_bytes()).hexdigest()
def write(path,value):path.write_text(json.dumps(value,indent=2)+'\n', encoding='utf-8',newline='\n')
identity=read(origin/'identity.json')
frozen=identity['imageFiles']['candidate']
assert {f.name:sha(f) for f in (origin/'candidate').iterdir()}==frozen
copytree(origin/'candidate',p/'candidate')
assert {f.name:sha(f) for f in (p/'candidate').iterdir()}==frozen
for name in ('cpython-worker.py','run.sh','representative.json'):copyfile(origin/name,p/name)
assert sha(p/'representative.json')==identity['catalogs']['representative.json']['sha256']
assert sha(p/'cpython-worker.py')==identity['cpythonWorkerSHA256']
assert b'\r' not in (p/'run.sh').read_bytes()
identity['frozenImage']=identity['frozenImage'].replace('/candidate','/repeat/candidate')
identity['purpose']='Confirm the nested document lane with the same images in reverse worker order.'
write(p/'jobs.json',[['diagnostic.nested-json-document','paired']])
identity['catalogs']['jobs.json']['sha256']=sha(p/'jobs.json')
write(p/'identity.json',identity)
compile((p/'collect.py').read_bytes(),'collect.py','exec')