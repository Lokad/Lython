import json
import subprocess
import sys
from pathlib import Path

lab = Path(__file__).resolve().parent
old = lab.parent/'prepared-local-destination-r707'
profile = lab.parent/'current-csv-profile-b1140'
load = lambda path: json.loads(path.read_text(encoding='utf-8-sig'))
catalog = load(profile/'catalog.json')
text_control = next(case for case in load(lab.parent/'csv-final-payload-r379/catalog.json')['cases']
                    if case['id'] == 'scripts.text-summary-helpers.nonlocal-counter.large')
catalog['cases'].append(text_control)
assert len(catalog['cases']) == 4
(lab/'catalog.json').write_text(json.dumps(catalog,indent=2,ensure_ascii=False)+'\n',encoding='utf-8',newline='\n')

source = (old/'freeze-and-verify.py').read_text(encoding='utf-8')
source = source.replace('prepared-local-destination-r707','csv-search-sets-r711')
source = source.replace("git('rev-parse','e20604ef4')", "git('rev-parse','fdacfbe20')")
source = source.replace('len(load(catalog_path)["cases"]) == 5','len(load(catalog_path)["cases"]) == 4')
source = source.replace('if name==core and role=="candidate":', 'if name==core:')
source = source.replace("origin=lab/role/'bin/Lokad.Lython/release_net11.0'/name",
    "build_dir='windows' if role=='candidate' else 'reference'\n            origin=lab/build_dir/'bin/Lokad.Lython/release_net11.0'/name")
source = source.replace('all five cases','all four cases')
assert "trial=repo/'.git/agent-worktrees/csv-search-sets-r711'" in source and "build_dir='windows'" in source
assert "git('rev-parse','fdacfbe20')" in source
(lab/'freeze-and-verify.py').write_text(source,encoding='utf-8',newline='\n')
subprocess.run([sys.executable,'-X','utf8',lab/'freeze-and-verify.py'],check=True)

