import json
import subprocess
import sys
from pathlib import Path

lab = Path(__file__).resolve().parent
old = lab.parent/'validator-native-roundtrip-r706'
stage = (old/'stage-quiet.py').read_text(encoding='utf-8')
stage = stage.replace('postfix-cpython-b1130','integer-transport-cpython-b1136')
stage = stage.replace('native-integer-transport-b1135','csv-search-sets-b1141')
stage = stage.replace('lython-b1135-native-integer-transport','lython-b1141-csv-search-sets')
stage = stage.replace('lython-b1135-fixtures','lython-b1141-fixtures')
stage = stage.replace('R706 direct short integer result and failure transport','R711 prepared CSV search sets')
stage = stage.replace('Native integer transport','Prepared CSV search sets')
start = stage.index('        jobs = [')
end = stage.index('\n', start)
catalog = json.loads((lab/'catalog.json').read_text(encoding='utf-8'))
jobs = [(case['id'],'warm') for case in catalog['cases']]
jobs.append(('scripts.csv-invoice.large','compile-run'))
assert len(jobs) == 5
stage = stage[:start] + '        jobs = ' + repr(jobs) + stage[end:]
stage = stage.replace('five-case, five-job','four-case, five-job')
stage = stage.replace('}) == 5','}) == 4')
proof = (old/'prove-quiet-space.py').read_text(encoding='utf-8')
start = proof.index('pairs = ')
end = proof.index('\n',start)
pairs = [('parse-annotation-frontiers-r708/quiet','2026-11-19-parser-annotation-bounds','candidate','measured-core.dll.gz'),
         ('private-keyword-mapping-r660/quiet','2026-11-19-private-keyword-mapping','candidate','measured-core.dll.gz')]
proof = proof[:start] + 'pairs = ' + repr(pairs) + proof[end:]
for name,value in [('prove-quiet-space.py',proof),('stage-quiet.py',stage)]:
    (lab/name).write_text(value,encoding='utf-8',newline='\n')
    subprocess.run([sys.executable,'-X','utf8',lab/name],check=True)

