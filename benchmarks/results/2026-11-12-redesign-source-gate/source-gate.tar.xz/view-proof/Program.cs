using System.Runtime.CompilerServices;

// Language/storage proof only: not interpreter or semantic qualification.
var caller = new object?[] { "caller" };
FrameState inlineState = default;
InlineSlots inline = default;
Span<object?> inlineValues = inline;
caller.AsSpan().CopyTo(inlineValues); // writable callee slots never alias caller locals
var borrowed = new FrameView(ref inlineState, inlineValues);
Advance(ref borrowed);
if (!Equals(caller[0], "caller") || inlineState.Instruction != 2 || inlineState.Stack.LiveExtent != 2)
    throw new InvalidOperationException("Borrowed view did not preserve state/argument separation.");
var promoted = Promote(ref borrowed);
if (!Equals(promoted.Values![0], "callee") || !Equals(promoted.Values[1], "effect") || promoted.Instruction != 2)
    throw new InvalidOperationException("Promotion lost completed state.");
var retained = new FrameView(ref promoted, promoted.Values);
retained.Stack.Publish(2, "resumed");
if (promoted.Stack.LiveExtent != 3 || !Equals(promoted.Values[2], "resumed"))
    throw new InvalidOperationException("Retained view did not share the same operations.");
Console.WriteLine("Managed ref-state/span view, array/inline storage and copy promotion compile and execute; runtime lifetimes remain unqualified.");

static void Advance(ref FrameView frame)
{
    frame.Stack.Publish(0, "callee");
    frame.Stack.Publish(1, "effect");
    frame.State.Instruction = 2;
}
static FrameState Promote(ref FrameView view)
{
    var result = view.State;
    result.Values = view.Values.ToArray();
    return result;
}
[InlineArray(32)] struct InlineSlots { private object? _first; }
struct StackState { public int LiveExtent; }
struct FrameState { public int Instruction; public StackState Stack; public object?[]? Values; }
ref struct FrameView
{
    private ref FrameState _state;
    private Span<object?> _values;
    public FrameView(ref FrameState state, Span<object?> values) { _state = ref state; _values = values; }
    public ref FrameState State => ref _state;
    public Span<object?> Values => _values;
    public StackView Stack => new(ref _state.Stack, _values);
}
ref struct StackView
{
    private ref StackState _state;
    private Span<object?> _values;
    public StackView(ref StackState state, Span<object?> values) { _state = ref state; _values = values; }
    public void Publish(int slot, object value) { _values[slot] = value; _state.LiveExtent = slot + 1; }
}
