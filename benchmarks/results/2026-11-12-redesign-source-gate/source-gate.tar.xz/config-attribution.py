"""Offline attribution of the existing R275 stacks. No new VM capture or timing."""
from pathlib import Path
import bisect,collections,hashlib,json,re,sys
r=Path(__file__).parent
case=sys.argv[1]if len(sys.argv)>1 else'config-compile'
assert case in ('config-compile','config-fresh')
p=r.parent/'config-report-costs-r275/b630/retrieved/profiles'/case
record=json.loads((p/'record.json').read_text(encoding='utf-8'))
tids=set(record['profiledTids'])
if len(sys.argv)>2:
    assert sys.argv[2]=='guest'
    tids=set(record['guestTids']);assert tids
ranges=[]
for line in (p/'perf.map').read_text(encoding='utf-8').splitlines():
    start,size,name=line.split(' ',2);ranges.append((int(start,16),int(size,16),name))
ranges=sorted(set(ranges));starts=[a for a,n,name in ranges];ends=[]
for a,n,name in ranges:ends.append(max(a+n,ends[-1]if ends else 0))
def resolve(ip,fallback):
    i=bisect.bisect_right(starts,ip)-1;names=set()
    while i>=0 and ends[i]>ip:
        a,n,name=ranges[i]
        if a<=ip<a+n:names.add(name)
        i-=1
    return next(iter(names))if len(names)==1 else fallback
def family(name):
    # Classify declaring types, not frontend types appearing in runtime signatures.
    declared=name.partition('::')[0].rsplit(' ',1)[-1]
    if not declared.startswith('Lokad.Lython.Frontend.'):return None
    if 'LoweredScript'in declared:return 'lowering'
    if 'Executable'in declared:return 'executable construction'
    if 'Parser'in declared or 'PythonTokenization'in declared:return 'parse/tokenize'
    if 'Static'in declared or 'AnnotationDiagnostic'in declared:return 'analysis'
    if 'Scope' in declared or 'SyntaxValidity' in declared or 'PostponedAnnotation' in declared:return 'syntax/scope preparation'
    return 'other frontend'
samples=[];current=None
for line in (p/'perf-stacks.txt').read_text(encoding='utf-8').splitlines():
    m=re.match(r'\s*(\d+)/(\d+)\s*$',line)
    if m:
        current=[]if m[2]in tids else None
        if current is not None:samples.append(current)
        continue
    m=re.match(r'\s+([0-9a-f]+)\s+(.+)',line)
    if m and current is not None:current.append(resolve(int(m[1],16),m[2]))
leaf=collections.Counter();inclusive=collections.Counter();traversal=collections.Counter()
for stack in samples:
    if not stack:continue
    leaf[stack[0]]+=1
    inclusive.update(set(filter(None,map(family,stack))))
    if 'ExpressionSyntaxTraversal+Enumerator::MoveNext'in stack[0]:
        owner=next((n for n in stack[1:]if 'Lokad.Lython.Frontend.'in n and 'ExpressionSyntaxTraversal'not in n),'[no mapped frontend caller]')
        traversal[owner]+=1
out=dict(originalRecordSHA256=hashlib.sha256((p/'record.json').read_bytes()).hexdigest(),profiledTids=sorted(tids),guestTids=record['guestTids'],samples=len(samples),leafCounts=leaf.most_common(),inclusiveFamilies=dict(inclusive),traversalLeafMappedCallers=traversal.most_common(),limits='Same R275 trace; explicit selected threads; inclusive categories overlap, unknown/truncated/inlined stacks prevent exact phase attribution; sample counts are not elapsed improvements or removable-time forecasts.')
(r/(case+('-guest'if len(sys.argv)>2 else'')+'-attribution.json')).write_text(json.dumps(out,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps(dict(samples=len(samples),inclusiveFamilies=dict(inclusive),traversalCallers=traversal.most_common(6),leafFamilies=dict(collections.Counter({f:sum(n for name,n in leaf.items()if family(name)==f)for f in inclusive})),limits=out['limits']),indent=2))
