# R278 initial source facts — no prototype yet

## Source-gate decision

The proposed form is not selected. Direct comparison with R268 milestone.md,
storage-stage.patch, paired-profile and positional-refinement evidence confirms
that R268 already implemented this concrete span/inline view, one shared prefix,
funded live-state export and native graph deletion. After shared positional fill,
native search remained22–26% slower with stable controls; entry/dispatch, not just
argument packaging, displaced the removed guard/evaluator. No production edit or
VM replay is justified by the present proposal. A later materially different
design must eliminate that recurring work explicitly. This is not a permanent ban.

The private language-only toy stopped on nullable-flow diagnostic CS8602 (not a
ref-safety failure). It does not establish runtime promotion/ownership and is not
worth refining now that the full prior implementation supplies stronger evidence.
Existing locals/operand aliasing, span binding and deferred incoming closures are
already implemented; the earlier candidate language must not count them as gains.

HEAD41bd869b, R276 committed and full CI43265529241 active. Fully qualified
production1011ed0b; no VM users/RAM fixtures remain. PLAN is ignored.

Normal public execution already uses executable instructions. Both APIs share
ExecuteInstructionPrefix; BeginBoundCall defers lexical context with owned
ExecutableWorkState. Incoming closure cells are supported; captured locals,
class/annotation/type-parameter scopes and handler/mirroring contexts retain
real frames. Do not claim these optimizations as new.

Native helpers additionally compile a separate NativeReturnValue graph, run
GuardNativeBody/GuardNativeReturn recursively, then evaluate that graph. R272
profile guard/eval5.7/5.8% includes genuine/inlined work, not removable forecast.
Native formatted guards read actual field values; do not cache them across later
admission/effects. General subscript guard leaves unknown result shape. A compact
input type table alone cannot replace all dynamic correlation/protocol checks.

PyExecutableFunction native parameter capacity is16, an optimization threshold.
Native exact positional calls can borrow read-only caller operands; default/
keyword binding uses safe inline slots. Ordinary binder fills existing admitted
workspace. A new design must preserve parameter snapshots and avoid mutating
caller locals when operands are forwarded directly. Do not add per-call packing.

Candidate for proof: one existing executable handler implementation over borrowed
managed slots and retained array-backed frames; promote before actual observation/
suspension, preserve effects/owned temporaries/closures, then delete separate native
graph builder/metadata/guard/evaluator. No new backend/options/unsafe/ref-safety
bypass; keep shared operation preflight/rollback helpers. Do not implement a wrapper
around the old graph and leave it dormant. A complete deletion/promotion proof is
required before code. Check prior call-arena/control and ordered-prefix prototypes
to avoid repeating measured transport/controller regressions. This remains a
source gate; no success/speedup or feasible-lifetime claim has been made.

Additional confirmed sources:
- ExecutableWorkState.Locals and ExecutableValueStorage.Values refer to the same
  object[]; CreateExecutableWorkState borrows bound.Values and allocates local
  cells only for genuinely captured locals. No second locals array/copy exists.
- BindFunctionArgumentsInto already takes Span<object>; reuse this authority.
- ExecutableValueStorage stores arrays, iteration positions, lookup owner, owned
  byte balance and pending disposal chain; prefix handlers currently require this
  resumable array-backed state. Array-backed async ownership must remain real.
- NativeParameterCapacity is16. Do not overwrite forwarded caller operands as
  writable callee locals; current native borrowing is read-only.
- ExecuteInstructionPrefix returns ContextRequired before scope-sensitive or
  protocol work; BeginBoundCall currently permits only completion/ContextRequired
  from a borrowed prefix. Nested partial child calls and promotion are a specific
  unresolved lifetime/control requirement, not a solved design.

Next source-gate action: inspect prior ordered-prefix/call-arena/control prototypes
and map all ReadOnlyMemory/array-dependent prefix consumers. A private C# compile
proof may establish that one span/ref-state view can serve heap and inline slots
without unsafe/ref-safety bypass, but is not runtime-semantic qualification. Do
not start production migration until the full promotion/deletion map is coherent.
Do not turn this into another input-constraint type solver: formatted guards read
actual dictionary field values, and those cannot be cached across admission/effects.
