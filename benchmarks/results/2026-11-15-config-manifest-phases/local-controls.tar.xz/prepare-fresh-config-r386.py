from pathlib import Path
import base64,contextlib,hashlib,importlib.util,io,json,os,subprocess,tempfile

base=Path(__file__).parent;r=base/'fresh-config-r386';r.mkdir(exist_ok=True)
if (r/'local-verification.json').exists():
    index=1
    while (r/f'local-verification-attempt-{index}.json').exists():index+=1
    (r/'local-verification.json').rename(r/f'local-verification-attempt-{index}.json')
if (r/'worker-verification.stderr').exists():
    index=1
    while(r/f'worker-verification-attempt-{index}.stderr').exists():index+=1
    (r/'worker-verification.stderr').rename(r/f'worker-verification-attempt-{index}.stderr')
source=Path('benchmarks/scripts/config-manifest.py').read_text(encoding='utf-8').replace('\r\n','\n')
config=dict(project=' demo-agent ',defaults=dict(labels=[' Internal ','Café','internal']),targets=[dict(name='API',path=' ./src/api ',labels=['LINUX',' café ']),dict(name='Worker',path=' ./src/worker ',enabled=True,labels=['Batch','Internal']),dict(name='legacy',path='./legacy',enabled=False),dict(name='Docs',path=' ./docs ',labels=['Public','Café'],enabled=True)],options=dict(strict=True,attempts=3))
requirements='# generated declarations\n Widgets_Core==1.2.0 # pinned\nreports==2.0\nunversioned\nwidgets_core==1.3.0\n  café_utils == 0.9\n'
targets=[dict(name='api',path='./src/api',labels=['café','internal','linux']),dict(name='worker',path='./src/worker',labels=['batch','café','internal']),dict(name='docs',path='./docs',labels=['café','internal','public'])]
dependencies=[dict(name='café-utils',version='0.9'),dict(name='reports',version='2.0'),dict(name='unversioned',version=None),dict(name='widgets-core',version='1.3.0')]
expected_config=dict(config,project='demo-agent',targets=targets,summary=dict(targets=3,dependencies=4))
manifest=dict(project='demo-agent',targets=targets,dependencies=dependencies)
encode=lambda x:(json.dumps(x,ensure_ascii=False,indent=2,sort_keys=True)+'\n').encode('utf-8')
inputs={'config.json':encode(config),'requirements.txt':requirements.encode('utf-8')}
outputs={'config.json':encode(expected_config),'manifest.json':encode(manifest)}
expected='3 targets / 4 dependencies\n'
with tempfile.TemporaryDirectory(prefix='lython-config-control-')as folder:
    work=Path(folder)
    for name,data in inputs.items():(work/name).write_bytes(data)
    (work/'workload.py').write_text(source,encoding='utf-8',newline='\n')
    capture="import contextlib,io,runpy,sys\ntext=io.StringIO()\nwith contextlib.redirect_stdout(text):runpy.run_path(sys.argv[1],run_name='__main__')\nsys.stdout.buffer.write(text.getvalue().encode('utf-8'))\n"
    done=subprocess.run(['C:/Python313/python.exe','-I','-S','-X','utf8','-c',capture,str(work/'workload.py')],cwd=work,capture_output=True,timeout=20)
    assert done.returncode==0 and done.stdout==expected.encode('utf-8')and not done.stderr,done.stderr
    assert all((work/name).read_bytes()==data for name,data in outputs.items())
catalog=json.loads((base/'retained-cpython-r383/retrieved/representative.json').read_text(encoding='utf-8'))
template=next(c for c in catalog['cases']if c['id']=='scripts.file-search.large.protected')
fixture=dict(size=4,text=None,inputFiles={n:base64.b64encode(b).decode('ascii')for n,b in inputs.items()},outputFiles={n:base64.b64encode(b).decode('ascii')for n,b in outputs.items()})
fixture_json=json.dumps(fixture,ensure_ascii=False,separators=(',',':'))
spec=importlib.util.spec_from_file_location('protocol','benchmarks/cpython-worker.py');protocol=importlib.util.module_from_spec(spec);spec.loader.exec_module(protocol)
digest=lambda text:hashlib.sha256(text.encode('utf-8')).hexdigest()
case=dict(template,id='scripts.config-manifest.small',scale='small',size=4,source=source,fixtureJson=fixture_json,expectedOutput=expected,sourceUtf8Bytes=len(source.encode('utf-8')),expectedOutputUtf8Bytes=len(expected.encode('utf-8')),fixtureTextUtf8Bytes=0,fixtureTextCodePoints=0,sourceSha256=digest(source),fixtureSha256=digest(fixture_json),expectedOutputSha256=digest(expected),expectedFilesSha256=protocol.file_digest(outputs))
catalog['cases']=[case];catalog['performanceQualified']=False
(r/'catalog.json').write_text(json.dumps(catalog,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
(r/'fixture-design.json').write_text(json.dumps(dict(purpose='A complete newly generated helper-rich configuration edit and manifest, not an artificial helper count. Separate compile/warm/fresh through existing workers.',source='benchmarks/scripts/config-manifest.py',sourceBytes=case['sourceUtf8Bytes'],helpers=6,inputBytes=sum(map(len,inputs.values())),outputBytes=sum(map(len,outputs.values())),inputFiles={n:len(b)for n,b in inputs.items()},outputFiles={n:len(b)for n,b in outputs.items()},manualExpected='Three enabled normalized targets, four sorted de-duplicated dependencies with last version winning; original defaults/options retained; project trimmed; two exact UTF8 JSON outputs.',cpythonControl='Isolated stock CPython3.13.2 matched independent expected stdout/files.',newFramework=False,publicationHeld=True),indent=2)+'\n',encoding='utf-8',newline='\n')
# Verify the maintained script through the unchanged public comparison worker.
sdk='C:/Users/JoannesVermorel/.dotnet11';env={k:v for k,v in os.environ.items()if k.casefold()!='path'}
env['DOTNET_ROOT']=sdk;env['PATH']=sdk+';'+next(v for k,v in os.environ.items()if k.casefold()=='path')
worker=base/'function-slot-binding-r384/candidate/Lokad.Lython.Benchmarks.dll'
with tempfile.TemporaryDirectory(prefix='lython-comparison-files-')as folder:
    with (r/'worker-verification.stderr').open('w+b')as errors:
        process=subprocess.Popen([sdk+'/dotnet.exe',str(worker.resolve()),'--compare','worker','--catalog',str((r/'catalog.json').resolve())],cwd=folder,env=env,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=errors)
        try:
            ready=protocol.read_frame(process.stdout)
            assert ready['status']=='Ready'
            request={k:case[k]for k in ['sourceSha256','fixtureSha256','expectedOutputSha256']}
            request.update(protocolVersion=2,requestId=1,operation='verify',caseId=case['id'],lane='warm',iterations=2)
            protocol.write_frame(process.stdin,request);verified=protocol.read_frame(process.stdout)
            (r/'local-verification.json').write_text(json.dumps(dict(ready=ready,response=verified),indent=2)+'\n',encoding='utf-8',newline='\n')
            assert verified is not None,'Worker exited before verification response; persistent stderr retained.'
            protocol.write_frame(process.stdin,dict(protocolVersion=2,requestId=2,operation='quit'));closed=protocol.read_frame(process.stdout)
            assert process.wait(timeout=15)==0 and closed['status']=='Closed'
            assert verified['status']=='Equivalent',verified
            assert verified['actualOutputSha256']==case['expectedOutputSha256']and verified['actualFilesSha256']==case['expectedFilesSha256']
        finally:
            if process.poll()is None:process.kill();process.wait()
            with contextlib.suppress(OSError):process.stdin.close()
            with contextlib.suppress(OSError):process.stdout.close()
            errors.flush();errors.seek(0);stderr=errors.read();(r/'worker.stderr').write_bytes(stderr)
            (r/'worker-exit.json').write_text(json.dumps(dict(exitCode=process.returncode,stderrRetained=True,allUsersJoined=True))+'\n',encoding='utf-8',newline='\n')
        assert not stderr,stderr
print(json.dumps(dict(prepared=True,helpers=6,sourceBytes=case['sourceUtf8Bytes'],inputBytes=sum(map(len,inputs.values())),manualAndPythonAndLythonGoldensPassed=True,unchangedWorker=True)),flush=True)
