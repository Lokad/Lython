from pathlib import Path
import ast,hashlib,json,subprocess,tarfile

r=Path(__file__).parent;base=r.parent;old=base/'retained-cpython-r383'
assert not(r/'payload.tgz').exists()
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
local=json.loads((r/'local-verification.json').read_text(encoding='utf-8'));assert local['response']['status']=='Equivalent'
f=json.loads((base/'function-slot-binding-r384/candidate-identity.json').read_text(encoding='utf-8'))
assert all(sha(p)==h for p,h in f['sources'].items())
full=json.loads((base/'function-slot-binding-r384/delivery/ci-terminal.json').read_text(encoding='utf-8'));assert full['conclusion']=='success'
remote='/home/lokad/lython-bench-checks/fresh-config-b774-20261115';unit='lython-b774-fresh-config-20261115'
prior=json.loads((old/'config.json').read_text(encoding='utf-8'))
identity=dict(prior['identity'],sourceRevision='810379bed830f3d2baf2a8b0ddff57b60a60d3df/frozen8fbfa3f0',runtimeCommit='810379bed830f3d2baf2a8b0ddff57b60a60d3df',purpose='Complete helper-rich small configuration edit and manifest: compare compile/warm/fresh with stockCPython, no frontend rewrite or cross-collection gain inferred.',coreSHA256={role:f['coreSHA256']['candidate']for role in ['reference','reference-control','candidate','candidate-control']},catalogSHA256=sha(r/'catalog.json'),fullSourceIdentitySHA256=sha(base/'function-slot-binding-r384/candidate-identity.json'),committedSourceProofSHA256=sha(base/'function-slot-binding-r384/delivery/source-proof.json'),qualification='43689267617GREEN terminal cached; Windows/Ubuntu actual11/10 ordinary/originalstress/installed consumers.')
(r/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8',newline='\n')
prospective=dict(case='scripts.config-manifest.small',phases=['compile','warm','compile-run'],question='Do ordinary helper-rich newly generated scripts expose a material frontend or invocation gap hidden by long-record warm runs?',control='Manual expected files plus isolatedCPython3.13.2 and unchanged Lython public worker pass.',acceptance='Existing command-v2 identities/goldens/quiet/ownership/Closed/join/archive gates, two independent processes per engine, five rotating rounds; keep all adverse controls.',warmupSeconds=5,targetRequestSeconds=.5,ownerSeconds=180,storage='Reuse verified immutable8fbfB773image and B772CPython worker. New catalog only; no image retirement/upload and254/252MiBfloors unchanged.',stoppingCriterion='Complete three phases; profile a demonstrated material gap before choosing a coherent displaced stage, otherwise close with that evidence. No new framework or blind retiming.',publicationHeld=True)
(r/'prospective.json').write_text(json.dumps(prospective,indent=2)+'\n',encoding='utf-8',newline='\n')
for name in ['collect.py','archive-owned.py','run.sh','retrieve.py','summarize.py']:
    s=(old/name).read_text(encoding='utf-8').replace('retained-cpython-b772-20261115','fresh-config-b774-20261115').replace('lython-b772-retained-cpython-20261115',unit).replace('B772','B774')
    if name=='collect.py':
        a=s.index('\njobs=')+1;b=s.index('\nenv =',a)
        s=s[:a]+"jobs=[['scripts.config-manifest.small','compile'],['scripts.config-manifest.small','warm'],['scripts.config-manifest.small','compile-run']]\nassert len(jobs)==3 and all(case in cases for case,lane in jobs)\n"+s[b:]
        s=s.replace("< 330, 'Reserve60seconds","< 120, 'Reserve60seconds")
    elif name in ['archive-owned.py','summarize.py']:s=s.replace('==7','==3').replace('jobs=7','jobs=3')
    elif name=='retrieve.py':s=s.replace('==7','==3').replace('<390','<180').replace('seven-job','three-job')
    if name.endswith('.py'):ast.parse(s)
    (r/name).write_text(s,encoding='utf-8',newline='\n')
with tarfile.open(r/'payload.tgz','w:gz')as tar:
    for name in ['identity.json','prospective.json','fixture-design.json','collect.py','archive-owned.py','run.sh']:tar.add(r/name,arcname=name)
    tar.add(r/'catalog.json',arcname='representative.json')
with tarfile.open(r/'payload.tgz')as tar:unpacked=sum(m.size for m in tar.getmembers())
config=dict(prior,root=remote,sourceRoot='/home/lokad/lython-bench-checks/entry-stage-b773-20261115',catalogRoot='/home/lokad/lython-bench-checks/entry-stage-b773-20261115',pythonRoot='/home/lokad/lython-bench-checks/retained-cpython-b772-20261115',unit=unit,identity=identity,payloadBytes=(r/'payload.tgz').stat().st_size,payloadSHA256=sha(r/'payload.tgz'),unpackedBytes=unpacked)
s=(old/'launch-command.py').read_text(encoding='utf-8');a=s.index('config=');b=s.index('\nbase=',a);s=s[:a]+'config='+repr(config)+s[b:]
s=s.replace(" assert digest(catalog/'representative.json')==config['identity']['catalogSHA256']\n",'')
s=s.replace(" assert digest(source/'cpython-worker.py')==config['pythonWorkerSHA256']"," python_source=Path(config['pythonRoot']);assert python_source.parent==base and python_source.resolve()==python_source\n assert digest(python_source/'cpython-worker.py')==config['pythonWorkerSHA256']")
oldlink=" os.link(catalog/'representative.json',root/'representative.json');os.link(source/'cpython-worker.py',root/'cpython-worker.py')";assert s.count(oldlink)==1
s=s.replace(oldlink," assert digest(root/'representative.json')==config['identity']['catalogSHA256']\n os.link(python_source/'cpython-worker.py',root/'cpython-worker.py')")
s=s.replace('lython-b772-fixtures','lython-b774-fixtures').replace("'--property=RuntimeMaxSec=390'","'--property=RuntimeMaxSec=180'").replace('noNewImageOrCatalogUpload=True','noNewImageUpload=True,newSmallCatalog=True')
ast.parse(s);(r/'launch-command.py').write_text(s,encoding='utf-8',newline='\n')
(r/'config.json').write_text(json.dumps(config,indent=2)+'\n',encoding='utf-8',newline='\n')
s=(old/'launch.py').read_text(encoding='utf-8').replace('B772','B774');a=s.index('prior=json.loads(');b=s.index('\nnow=',a)
s=s[:a]+"prior=json.loads((r.parent/'entry-stage-r385/terminal-status.json').read_text(encoding='utf-8'))\nassert prior['receipt']['complete']and not prior['remainingWorkers']and not prior['remainingTrace']\n"+s[b:]
s=s.replace('seconds=300','seconds=120').replace('ownerSeconds=390','ownerSeconds=180')
ast.parse(s);(r/'launch.py').write_text(s,encoding='utf-8',newline='\n')
print(json.dumps(dict(prepared=True,phases=3,payloadBytes=(r/'payload.tgz').stat().st_size,unpackedBytes=unpacked,core=f['coreSHA256']['candidate'],noNewFrameworkOrImageUpload=True)),flush=True)
