from pathlib import Path
import hashlib,json,shutil,tarfile
r=Path(__file__).parent;q=r/'quiet';repo=Path.cwd();w=repo/'.git/agent-worktrees/kernel-r436';out=repo/'benchmarks/results/2026-11-16-iteration-slot-transport/refined';out.mkdir(exist_ok=True);identity=json.loads((r/'frozen/identity.json').read_text(encoding='utf-8'));receipt=json.loads((q/'archive-receipt.json').read_text(encoding='utf-8'));assert receipt['complete']and receipt['allWorkersJoined']and receipt['quietBeforeAndAfter']and receipt['guestFixturesRemoved'];assert hashlib.sha256((q/'observations.tgz').read_bytes()).hexdigest()==receipt['archiveSHA256']
for n in ['identity.json','observations.tgz','archive-receipt.json','terminal-status.json']:shutil.copyfile(q/n,out/n)
v=json.loads((r/'summary.json').read_text(encoding='utf-8'));v.update(retentionDecisionPending=False,retainedFor='Remove range boxing from ordinary execution through existing final slots, preserving native direct advancement.',fullQualificationPending=True,limitations='CSV control moves3.58% in both sources and does not prove neutrality; no substantial complete-file/CPython gain inferred. Original adverse prototype retained.');(r/'summary.json').write_text(json.dumps(v,indent=2)+'\n',encoding='utf-8',newline='\n')
for n in ['summary.json','allocation-summary.json','focused-checks.json']:shutil.copyfile(r/n,out/n)
shutil.copyfile(r/'frozen/sources-and-checks.tar.xz',out/'source-and-checks.tar.xz')
with tarfile.open(out/'procedure-and-image.tar.xz','w:xz')as t:
 for n in ['identity.json','candidate/Lokad.Lython.dll']:t.add(r/'frozen'/n,arcname='frozen/'+n)
 for p in sorted(r.glob('*.py')):t.add(p,arcname='procedure/'+p.name)
 for n in ['build.log','historical-aliases.json','raw-retirement-proof.json']:t.add(r/n,arcname=n)
 for p in sorted(q.iterdir()):
  if p.is_file()and p.name not in ['payload.tgz','observations.tgz']:t.add(p,arcname='quiet/'+p.name)
 for p in (r/'checks').glob('stress-*'):t.add(p,arcname='stress/'+p.name)
 for n in ['Program.cs','Allocation.csproj','catalog.json','reference.json','candidate.json','image-hashes.json']:t.add(r/'allocation-short'/n,arcname='allocation/'+n)
(out/'README.md').write_text('''# Final-slot range iteration: retained refinement

R436/B834,2026-11-16UTC; measured **0443b5cf** versus fully qualified
**6581454d /1c8e1be5**. Retained; full platform/package qualification pending.
[Original c7/B833 and adverse controls](../README.md) remain unchanged.

Ordinary/persistent and async ForNext now carry exact-range results directly in
existing executable slots, removing the intermediate boxed integer transport.
Native helpers retain direct cursor advancement; one redundant native publication
helper disappears. A computed exact-range fact avoids probing unrelated cursors.
Builtin sequences retain canonical references, general protocols and larger bounds
retain their exact paths. No new owner, ledger, policy, cache, controller or engine.
This closes one operand-transport boundary, not the broader call/frame redesign.

| Complete warm job | Elapsed change | Wider CPU change | Ref/candidate median spreads |
| --- | ---: | ---: | ---: |
| Integer module /Run | −25.55..−24.38% | −25.61..−23.14% | 0.81/0.76% |
| Integer module /RunAsync | −27.44..−27.03% | −27.08..−26.18% | 0.43/0.13% |
| Generator draining | −7.96..−6.05% | −8.30..−5.88% | 0.12/1.95% |
| Native helper control | −0.29..+0.91% | −1.90..+0.58% | 0.90/0.30% |
| Complete CSV validation control | −2.02..+5.12% | −1.74..+3.38% | 3.58/3.58% |

Four process pairings, not confidence intervals. Five jobs/171.940s, two processes
per source, unchanged four-case catalog,5s full-request warmup/five rotated roughly
0.5s rounds. All image/golden/quiet/Closed/exit/join/archive gates pass; IQR≤1.77%.
Native-helper result is approximately flat in this run, not causal proof that the
earlier adversity was solely the added helper. CSV is inconclusive; accept that
uncertainty without claiming broad file-script neutrality or retiming unchanged work.

Separate local natural-GC allocation: integer module−97.8%both APIs, generator
−13.7%; helper/positional-call/CSV/JSON effectively flat, all accounted peaks
unchanged. Later observation can still box.446internal/1,992public focused and
original14internal stress pass eachactual.NET11/10 after nonincremental Release
builds. Seven added public cases exercise call aliases, generator yield identity,
machine endpoints and real suspended I/O with cleanup/budget reuse. Existing checks
cover cancellation, refusal, protocol behavior and managed stack admission.

Quiet F4as_v7/Ubuntu24.04.4,four EPYC9V45vCPUs,16GiB/no swap,.NET11RC3 natural
workstation GC/normal tiering. Warm includes stdout/file goldens, prior-result cleanup
and mediated RAM I/O where used; excludes compilation/startup, reset/protocol and
final cache teardown. Wider CPU includes reset/protocol. No fresh/CPython/heap/
pending-I/O/embedding-tail claim. Whole-script performance objective remains open.

Original staging headroom refusal preserved; stopped before mutation. Only exact
committed c7 image/raw working replicas retired after fresh lease/UID/path/hash/
all-alias proof. Baseline/current images, toolchains and254/252MiB floors preserved.
Raw archive persisted/verified before RAM teardown; no users remain. Terminal
cached.607frozen inputs include updated seven-case source. Publication held.

[Controls](summary.json),[allocation](allocation-summary.json),[raw](observations.tgz),
[source/checks](source-and-checks.tar.xz),[image/procedure/original refusal](procedure-and-image.tar.xz).
''',encoding='utf-8',newline='\n')
paths=[n for n in identity['sources']if n.startswith('src/')and(repo/n).read_bytes().replace(b'\r\n',b'\n')!=(w/n).read_bytes().replace(b'\r\n',b'\n')]+['tests/Lokad.Lython.PublicApi.Tests/RangeSlotTransportTests.cs'];assert len(paths)==8
for n in paths:shutil.copyfile(w/n,repo/n)
print('Retained seven production edits and seven-case public test; original measurements preserved, full delivery pending.')
