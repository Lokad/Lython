from pathlib import Path
import ast,hashlib,io,json,shutil,subprocess,tarfile,xml.etree.ElementTree as E
r=Path(__file__).parent;parent=r.parent;w=Path('D:/code/Lython/.git/agent-worktrees/kernel-r436');sha=lambda b:hashlib.sha256(b).hexdigest()
old=json.loads((parent/'frozen/identity.json').read_text(encoding='utf-8'));f=r/'frozen';f.mkdir();images={}
for role in ['reference','candidate']:
 shutil.copytree(parent/'frozen'/role,f/role)
 if role=='candidate':shutil.copyfile(w/'src/Lokad.Lython/bin/Release/net11.0/Lokad.Lython.dll',f/role/'Lokad.Lython.dll')
 images[role]={p.name:sha(p.read_bytes())for p in(f/role).iterdir()if p.is_file()}
assert images['reference']==old['images']['reference']
assert all(images['candidate'][n]==h for n,h in images['reference'].items()if n!='Lokad.Lython.dll')
identity=dict(old,images=images,sources={n:sha((w/n).read_bytes())for n in old['sources']},contract='Final-slot iteration transport, native direct advancement restored and computed exact-range selection before integer cursor probe. Seven public cases. Full qualification pending; original adverse c7 image preserved.')
(f/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8',newline='\n')
ns={'t':'http://microsoft.com/schemas/VisualStudio/TeamTest/2010'};checks=[dict(file=p.name,**E.parse(p).find('t:ResultSummary/t:Counters',ns).attrib)for p in(r/'checks').glob('*.trx')]
assert sorted(int(x['passed'])for x in checks)==[446,446,1992,1992]and all(x['failed']=='0'for x in checks)
(r/'focused-checks.json').write_text(json.dumps(dict(checks=checks,nonincrementalReleaseBuild=True,fullQualificationPending=True),indent=2)+'\n',encoding='utf-8',newline='\n')
with tarfile.open(f/'sources-and-checks.tar.xz','w:xz')as a:
 for n in identity['sources']:a.add(w/n,arcname=n)
 a.add(r/'checks',arcname='checks');a.add(r/'build.log',arcname='build.log')
d=r/'allocation-short';d.mkdir()
for name in ['catalog.json','Program.cs','Allocation.csproj']:shutil.copyfile(parent/'allocation-short'/name,d/name)
shutil.copytree(parent/'allocation-short/bin',d/'bin')
shutil.copyfile(parent/'measure-allocation.py',r/'measure-allocation.py')
q=r/'quiet';q.mkdir();before=json.loads((parent/'quiet/config.json').read_text(encoding='utf-8'));c=dict(before)
root='/home/lokad/lython-bench-checks/iteration-refine-b834-20261116';unit='lython-b834-iteration-refine-20261116'
source=before['root'];files=before['identity']['imageFiles']['reference'];imageFiles={role:{n:images[role][n]for n in files}for role in ['reference','candidate']}
ident=dict(before['identity'],sourceRevision='R436 refined '+images['candidate']['Lokad.Lython.dll'][:8]+' versus qualified6581454d/1c8e1be5',imageFiles=imageFiles,candidateFocusedChecks=json.loads((r/'focused-checks.json').read_text(encoding='utf-8')),candidateSourceIdentitySHA256=sha((f/'identity.json').read_bytes()),testOnlyAliasCasesAddedAfterFreeze=False,originalAdversePrototypePreserved=True)
ident['coreSHA256']={label:imageFiles['candidate'if label.startswith('candidate')else'reference']['Lokad.Lython.dll']for label in ['reference','reference-control','candidate','candidate-control']}
(q/'identity.json').write_text(json.dumps(ident,indent=2)+'\n',encoding='utf-8',newline='\n')
for name in ['collect.py','archive-owned.py','run.sh','retrieve.py','representative.json']:
 s=(parent/'quiet'/name).read_text(encoding='utf-8').replace(before['root'],root).replace(before['unit'],unit).replace('B833','B834')
 if name.endswith('.py'):ast.parse(s)
 (q/name).write_text(s,encoding='utf-8',newline='\n')
commit=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();archive='benchmarks/results/2026-11-16-iteration-slot-transport/procedure-and-image.tar.xz';raw=Path(archive).read_bytes();assert raw==subprocess.check_output(['git','show',commit+':'+archive])
with tarfile.open(fileobj=io.BytesIO(raw))as a:core=a.extractfile('frozen/candidate/Lokad.Lython.dll').read()
alias=json.loads((r/'historical-aliases.json').read_text(encoding='utf-8'));assert sha(core)==alias['sha256']and len(core)==alias['bytes']
proof=dict(alias);proof.pop('freeBytes');proof['custody']=dict(commit=commit,archive=archive,archiveSHA256=sha(raw),member='frozen/candidate/Lokad.Lython.dll')
payload={n:(q/n).read_bytes()for n in ['identity.json','collect.py','archive-owned.py','run.sh','representative.json']};payload['candidate/Lokad.Lython.dll']=(f/'candidate/Lokad.Lython.dll').read_bytes()
with tarfile.open(q/'payload.tgz','w:gz')as a:
 for n,b in payload.items():m=tarfile.TarInfo(n);m.size=len(b);a.addfile(m,io.BytesIO(b))
c.update(root=root,unit=unit,source=source,sourceFiles=files,sourceCatalogSHA256=before['catalogSHA256'],catalogSHA256=sha(payload['representative.json']),identity=ident,retireGroups=[proof],payloadBytes=(q/'payload.tgz').stat().st_size,payloadSHA256=sha((q/'payload.tgz').read_bytes()),unpackedBytes=sum(len(b)for b in payload.values()))
(q/'config.json').write_text(json.dumps(c,indent=2)+'\n',encoding='utf-8',newline='\n')
s=(parent/'quiet/remote-launch.py').read_text(encoding='utf-8');a=s.index('c=');b=s.index('\nb=Path',a);s=s[:a]+'c='+repr(c)+s[b:];s=s.replace("source/'candidate'","source/'reference'").replace('lython-b833-fixtures','lython-b834-fixtures');ast.parse(s);(q/'remote-launch.py').write_text(s,encoding='utf-8',newline='\n')
shutil.copyfile(parent/'launch-quiet.py',r/'launch-quiet.py');shutil.copyfile(parent/'summarize.py',r/'summarize.py')
print(json.dumps(dict(candidate=images['candidate']['Lokad.Lython.dll'],checks=checks,inputs=len(identity['sources']),catalogSHA256=c['catalogSHA256'],retireBytes=len(core),unpackedBytes=c['unpackedBytes'])))
