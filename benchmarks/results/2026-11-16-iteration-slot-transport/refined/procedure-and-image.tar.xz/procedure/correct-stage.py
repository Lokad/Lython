from pathlib import Path
import ast,hashlib,io,json,shlex,subprocess,tarfile
r=Path(__file__).parent;q=r/'quiet';c=json.loads((q/'config.json').read_text(encoding='utf-8'));sha=lambda b:hashlib.sha256(b).hexdigest();commit=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();archive='benchmarks/results/2026-11-16-iteration-slot-transport/observations.tgz';raw=Path(archive).read_bytes();assert raw==subprocess.check_output(['git','show',commit+':'+archive]);proofs=[]
for member,rel in [('confirmation/confirmation.json','iteration-slots-b833-20261116/confirmation/confirmation.json'),(None,'iteration-slots-b833-20261116/observations.tgz')]:
 with tarfile.open(fileobj=io.BytesIO(raw))as t:data=t.extractfile(member).read()if member else raw
 proofs.append(dict(bytes=len(data),sha256=sha(data),links=1,paths=[rel],custody=dict(commit=commit,archive=archive,archiveSHA256=sha(raw),member=member)))
code='''from pathlib import Path
import fcntl,hashlib,json,os,stat
b=Path('/home/lokad/lython-bench-checks');proofs=PROOFS
with(b/'comparison-vm.lock').open('a')as f:
 fcntl.flock(f,fcntl.LOCK_EX|fcntl.LOCK_NB)
 for proof in proofs:
  p=b/proof['paths'][0];m=p.lstat();assert p.resolve()==p and stat.S_ISREG(m.st_mode)and m.st_uid==os.getuid()and m.st_nlink==1 and m.st_size==proof['bytes']and hashlib.sha256(p.read_bytes()).hexdigest()==proof['sha256']
 print(json.dumps(dict(freshRegularOwnedSingleLinkProofs=proofs)))
'''.replace('PROOFS',repr(proofs))
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73'];p=subprocess.run(ssh+['python3 -c '+shlex.quote(code)],capture_output=True,text=True,encoding='utf-8',timeout=45);assert p.returncode==0,p.stderr
(r/'raw-retirement-proof.json').write_text(p.stdout,encoding='utf-8');c['retireGroups']+=proofs
with tarfile.open(q/'payload.tgz')as t:payload={m.name:t.extractfile(m).read()for m in t.getmembers()if m.name!='representative.json'}
with tarfile.open(q/'payload.tgz','w:gz')as t:
 for n,b in payload.items():m=tarfile.TarInfo(n);m.size=len(b);t.addfile(m,io.BytesIO(b))
c.update(payloadBytes=(q/'payload.tgz').stat().st_size,payloadSHA256=sha((q/'payload.tgz').read_bytes()),unpackedBytes=sum(len(b)for b in payload.values()))
(q/'config.json').write_text(json.dumps(c,indent=2)+'\n',encoding='utf-8',newline='\n')
s=(q/'remote-launch.py').read_text(encoding='utf-8');a=s.index('c=');b=s.index('\nb=Path',a);s=s[:a]+'c='+repr(c)+s[b:];s=s.replace(" os.link(source/'cpython-worker.py'"," os.link(source/'representative.json',root/'representative.json')\n os.link(source/'cpython-worker.py'");ast.parse(s);(q/'remote-launch.py').write_text(s,encoding='utf-8',newline='\n')
(q/'launch.log').rename(q/'launch-stage-headroom-refusal.log')
print('Exact committed raw copies verified; unchanged catalog will be linked, with original staging refusal preserved.')
