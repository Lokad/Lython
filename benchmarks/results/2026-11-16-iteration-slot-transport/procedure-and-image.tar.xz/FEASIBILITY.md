# R436: common operand execution kernel

Subsequent selection: the full kernel remains a larger proposal. The source gate
identified a smaller complete storage boundary to remove first: ordinary ForNext
boxes machine-range values through PyIterationResult, while NativeExecution uses
TryMoveNextInteger. The active isolated R436 prototype shares advancement into
existing ExecutableSlot results across execution strategies, including builtin
sequence transport. No common view/controller or second engine was added. Five
production files plus five public semantic cases;446internal/1990public pass each
actual.NET11/10. Allocation/complete-script timing/retention still pending. Do not
claim the whole-kernel replacement below has been implemented.

Source checkpoint320b39d2; runtime1c8e1be5. No prototype/runtime edit yet.
R435 corrected full delivery43816267076 runs independently. R434119exclusive
instruction-loop leaves justify examining dispatch, not predicting a speedup.

Raw ReadExecutableOperand and arithmetic kernels are already shared. Their small
caller wrappers are not a new removable operand representation. ExecutableSlot
Object reads cache the eventual immutable identity; copying an unpublished scalar
before an observing finally/alias boundary can change that identity. Preserve the
existing TakeReturnOperand observation rule, not merely numerical equality.

The viable shape is a transient managed Span over final ExecutableSlot storage,
with a reference to the existing execution metadata. It must be the storage used
by one kernel, not a controller feeding the old two loops. A private synchronous
call can borrow InlineArray slots; persistent frames/generators borrow their
already-admitted arrays. Only metadata/arrays survive suspension. No Unsafe APIs,
new per-call object, interface dispatch, function façade or second generator engine.

| Boundary | Current fact | Required common-kernel behavior |
| --- | --- | --- |
| Bind/start | NativeValues span or final bound argument array; existing function owns caches and closure facts | Preserve final slots/direct binding. Do not turn every completed helper into an array/frame allocation. |
| Private prefix | NativeExecution keeps code/PC/live extent, prepares exact transfer, handles only closed operations | Common operations read the borrowed span; unknown protocols require a frame before effects. Preserve raw scalar/tuple returns until observation. |
| Ordinary frame | ExecutableWorkState retains code/locals/Stack/PC; Stack owns lookup/iteration/disposal state | Reuse existing persistent state. Do not retain Span or copy operands merely to enter the common kernel. |
| Private retirement | Native Trim disposes owned wrappers first, keeps dead private references until exit/transfer | Preserve bounded private lifetime and clear before promotion. This is not permission to keep dead references in a persistent frame. |
| Persistent retirement | Stack.RetireTo clears references and can queue async cursors; slots are cleared before reentrant disposal | Preserve no-double-disposal, pending funding and current-token cleanup. Do not just delete Array.Clear. |
| Promotion | CreateNativeContinuation transfers same PC/live extent/failure, adopting a prepared child and funded bound storage | Admit durable storage before callbacks can suspend; no effect replay or lost child/owner. Reuse ordinary routing. |
| True await | Current driver owns actual ValueTask and all pending cleanup | Consume once; borrowed view ends first, frame ownership survives. Do not add another completion controller. |
| Generator yield | Existing frame owns Resume/send/injection, yielded object and current exception | Reconstruct view over that frame on each prefix; preserve StopIteration rewriting, throw/close and exception context. |
| Return/finally | Ordinary TakeReturnOperand publishes identity when cleanup can inspect aliases | Keep this rule. Native unpacked tuple return is legal only for unobserved immediate consumption. |
| Binding cleanup | CloseInvocation retains Locals array after other work retires, returns full compiler capacity once | Locals currently carries a real loan-return handle. Do not delete it as a duplicate without relocating that required handle to an existing lifetime. |
| Frontend eligibility | SupportsNativeInstructions duplicates opcode inventory, plus real class/cell/mirroring facts | Delete duplicate opcode inventory once one kernel promotes correctly. Preserve semantic state-admission facts, no compiler-defect fallback. |

Implementation must move common operand/read/publish/retire semantics into the
single borrowed-slot kernel, migrate both callers, then remove NativeExecution's
duplicate switch/helpers and superseded opcode eligibility in the same coherent
milestone. Handler/protocol slow operations, imports/classes/annotations and
lowered fallbacks retain their genuine consumers. Existing exception driver owns
routing; do not reproduce it in the view. Persistent cursor disposal, raw return
identity, borrowed callback arguments and pending-child ownership are completion
gates, not follow-up correctness debt.

One feasible storage shape is existing persistent metadata plus a transient
borrowed-slot view whose mutations refer to that metadata. A heap frame can expose
such a view directly from its class field; a native prefix can borrow a local
metadata value and its private InlineArray. Do not make the persistent metadata
itself a ref struct or store a Span in it. Avoid ref-escape annotations, per-call
heap records or virtual storage just to make signatures compile. Opaque async
handlers still operate on their real frame and reconstruct a view only for
completed work. No view crosses an await or is retained by a delegate.

This replaces an execution stage, not the earlier R403 call controller/R411 tail
loan. Stop/refine before a prototype if the shape requires per-call allocation,
eager scalar boxing, a broad new exception state machine or lasting duplicate
dispatch. A temporary CPU setback is acceptable only during this named completion;
retention must explicitly decide any remaining regression debt after source cleanup.

Focused gates: existing native/ordinary function boundaries, arithmetic/identity,
tuple return, live defaults/closure/class locals, protected finally/abrupt exits,
real pending host operations, generator send/throw/close, cancellation/refusal,
alias funding, joined cleanup and small managed stacks. Add tests only for a real
semantic gap; no internal checkpoint counters. Then one bounded source pair of
complete captured text/invoice/protected search/report with duplicate source
controls. Distinguish allocation/CPU/compilation and moving controls. Full
Windows/Ubuntu actual11/10, original stress and installed Release consumers at
retention; representative CPython phases at the coherent kernel checkpoint.
