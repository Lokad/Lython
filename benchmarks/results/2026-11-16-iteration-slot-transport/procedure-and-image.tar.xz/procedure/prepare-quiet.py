from pathlib import Path
import ast,hashlib,io,json,subprocess,tarfile
r=Path(__file__).parent;q=r/'quiet';q.mkdir();old=r.parent/'subtext-storage-r435/quiet';before=json.loads((old/'config.json').read_text(encoding='utf-8'));frozen=json.loads((r/'frozen/identity.json').read_text(encoding='utf-8'));files=before['identity']['imageFiles']['candidate'];images={role:{n:frozen['images'][role][n]for n in files}for role in ['reference','candidate']};assert images['reference']==files
sha=lambda b:hashlib.sha256(b).hexdigest();commit=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();proofs=[]
def proof(archive,member,paths,links=1):
 raw=Path(archive).read_bytes();assert raw==subprocess.check_output(['git','show',commit+':'+archive])
 with tarfile.open(fileobj=io.BytesIO(raw))as a:data=a.extractfile(member).read()if member else raw
 p=dict(sha256=sha(data),bytes=len(data),links=links,paths=paths,custody=dict(commit=commit,archive=archive,archiveSHA256=sha(raw),member=member));proofs.append(p);return p
aliases=json.loads((r/'historical-aliases.json').read_text(encoding='utf-8'));p=proof('benchmarks/results/2026-11-16-line-construction/source-checks-and-procedure.tar.xz','frozen/candidate/Lokad.Lython.dll',aliases['paths'],aliases['links']);assert p['sha256']==aliases['sha256']and p['bytes']==aliases['bytes']
archive='benchmarks/results/2026-11-16-shared-subtext/observations.tgz'
for c in json.loads((r/'catalog-aliases.json').read_text(encoding='utf-8')):
 p=proof(archive,c['name'],c['paths'],c['links']);assert p['sha256']==c['sha256']and p['bytes']==c['bytes']
proof(archive,'confirmation/confirmation.json',['subtext-storage-b832-20261116/confirmation/confirmation.json']);proof(archive,None,['subtext-storage-b832-20261116/observations.tgz'])
allocation=json.loads((r/'allocation-short/catalog.json').read_text(encoding='utf-8'));full=json.loads((r/'catalog-full.json').read_text(encoding='utf-8'));rep=json.loads((r/'catalog-representative.json').read_text(encoding='utf-8'));find=lambda c,id:next(x for x in c['cases']if x['id']==id)
catalog=dict(rep);catalog['cases']=[find(full,'loops.integer.large'),find(allocation,'loops.integer.native-helper.control'),find(full,'generators.drain.large'),find(rep,'scripts.csv-validated-records.large')]
for c in catalog['cases']:
 for key,field in [('sourceSha256','source'),('fixtureSha256','fixtureJson'),('expectedOutputSha256','expectedOutput')]:assert sha(c[field].encode())==c[key]
(q/'representative.json').write_text(json.dumps(catalog,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
root='/home/lokad/lython-bench-checks/iteration-slots-b833-20261116';unit='lython-b833-iteration-slots-20261116'
identity=dict(sourceRevision='R436 isolatedc7e25f12 versus qualified6581454d/1c8e1be5',purpose='One bounded common-iteration-slot source pair: module sync/async, generator drain, native helper and complete CSV control. No predicted CPU or broad agent-workload gain.',coreSHA256={label:images['candidate'if label.startswith('candidate')else'reference']['Lokad.Lython.dll']for label in ['reference','reference-control','candidate','candidate-control']},imageFiles=images,prototype=True,publicationHeld=True,referenceQualification='43819495111GREEN Windows/Ubuntu actual11/10 ordinary/original stress/installed Release consumers;606inputs/16summaries; receipt d5e75994, never requery.',candidateFocusedChecks=json.loads((r/'focused-checks.json').read_text(encoding='utf-8')),candidateSourceIdentitySHA256=sha((r/'frozen/identity.json').read_bytes()),testOnlyAliasCasesAddedAfterFreeze=True,supersededCatalogWorkingCopiesRetiredOnlyAfterExactCommittedCustody=True)
(q/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8',newline='\n')
for name in ['collect.py','archive-owned.py','run.sh','retrieve.py']:
 s=(old/name).read_text(encoding='utf-8').replace(before['root'],root).replace(before['unit'],unit).replace('B832','B833')
 if name=='collect.py':
  a=s.index('jobs=');b=s.index('\nassert len(jobs)',a);s=s[:a]+"jobs=[['loops.integer.large','warm'],['loops.integer.large','warm-async'],['generators.drain.large','warm'],['loops.integer.native-helper.control','warm'],['scripts.csv-validated-records.large','warm']]"+s[b:]
 s=s.replace('len(jobs)==4','len(jobs)==5').replace("len(raw['jobs'])==4","len(raw['jobs'])==5").replace('jobs=4','jobs=5').replace("['jobs']==4","['jobs']==5").replace('four-job','five-job').replace('four jobs','five jobs')
 if name.endswith('.py'):ast.parse(s)
 (q/name).write_text(s,encoding='utf-8',newline='\n')
payload={n:(q/n).read_bytes()for n in ['identity.json','collect.py','archive-owned.py','run.sh','representative.json']};payload['candidate/Lokad.Lython.dll']=(r/'frozen/candidate/Lokad.Lython.dll').read_bytes()
with tarfile.open(q/'payload.tgz','w:gz')as a:
 for n,data in payload.items():
  m=tarfile.TarInfo(n);m.size=len(data);a.addfile(m,io.BytesIO(data))
c=dict(root=root,unit=unit,source=before['root'],sourceFiles=files,sourceCatalogSHA256=before['catalogSHA256'],catalogSHA256=sha(payload['representative.json']),identity=identity,retireGroups=proofs,payloadBytes=(q/'payload.tgz').stat().st_size,payloadSHA256=sha((q/'payload.tgz').read_bytes()),unpackedBytes=sum(len(b)for b in payload.values()))
(q/'config.json').write_text(json.dumps(c,indent=2)+'\n',encoding='utf-8',newline='\n')
s=(old/'remote-launch.py').read_text(encoding='utf-8');a=s.index('c=');b=s.index('\nb=Path',a);s=s[:a]+'c='+repr(c)+s[b:]
s=s.replace(" os.link(source/'representative.json',root/'representative.json')",'')
s=s.replace(";os.link(source/'additional.json',root/'additional.json')",'').replace('lython-b832-fixtures','lython-b833-fixtures');ast.parse(s);(q/'remote-launch.py').write_text(s,encoding='utf-8',newline='\n')
s=(r.parent/'subtext-storage-r435/launch-quiet.py').read_text(encoding='utf-8');(r/'launch-quiet.py').write_text(s,encoding='utf-8',newline='\n')
s=(r.parent/'subtext-storage-r435/summarize.py').read_text(encoding='utf-8').replace("len(raw['jobs'])==4","len(raw['jobs'])==5");(r/'summarize.py').write_text(s,encoding='utf-8',newline='\n')
print(json.dumps(dict(candidate=images['candidate']['Lokad.Lython.dll'],retireBytes=sum(p['bytes']for p in proofs),unpackedBytes=c['unpackedBytes'],jobs=5,catalogBytes=len(payload['representative.json']),minimumFreeBefore=254*1024*1024+c['unpackedBytes']+65536-sum(p['bytes']for p in proofs))))
