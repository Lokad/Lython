from pathlib import Path
import hashlib,json,shutil,subprocess,tarfile,xml.etree.ElementTree as E
r=Path(__file__).parent;w=Path('D:/code/Lython/.git/agent-worktrees/kernel-r436');base=r.parent/'subtext-storage-r435';f=r/'frozen';f.mkdir();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();old=json.loads((base/'final-source/identity.json').read_text(encoding='utf-8'));images={}
for role in ['reference','candidate']:
 shutil.copytree(base/'frozen/candidate',f/role)
 for n,h in old['images']['candidate'].items():assert sha(f/role/n)==h,n
 if role=='candidate':shutil.copyfile(w/'src/Lokad.Lython/bin/Release/net11.0/Lokad.Lython.dll',f/role/'Lokad.Lython.dll')
 images[role]={p.name:sha(p)for p in(f/role).iterdir()if p.is_file()}
assert images['reference']['Lokad.Lython.dll'].startswith('1c8e1be5')and all(images['candidate'][n]==h for n,h in images['reference'].items()if n!='Lokad.Lython.dll')
paths=list(old['sources'])+['tests/Lokad.Lython.PublicApi.Tests/RangeSlotTransportTests.cs'];assert len(set(paths))==607
identity=dict(buildSourceCommit=subprocess.check_output(['git','-C',str(w),'rev-parse','HEAD'],text=True).strip(),prototype=True,images=images,sources={n:sha(w/n)for n in paths},contract='Existing exact integer cursor returns ExecutableSlot into native and ordinary iteration. No new owner/view/controller/policy. Existing object/protocol/large-bound paths retained; input publication/cleanup/cancellation unchanged. Five public alias/boundary/real-I/O cases added. Full qualification pending, no CPU/retention claim.')
(f/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8',newline='\n')
with tarfile.open(f/'sources-and-checks.tar.xz','w:xz')as a:
 for n in paths:a.add(w/n,arcname=n)
 a.add(r/'checks',arcname='checks');a.add(r/'full-build.log',arcname='full-build.log')
ns={'t':'http://microsoft.com/schemas/VisualStudio/TeamTest/2010'};checks=[dict(file=p.name,**E.parse(p).find('t:ResultSummary/t:Counters',ns).attrib)for p in(r/'checks').glob('*.trx')];assert sorted(int(x['passed'])for x in checks)==[446,446,1990,1990]and all(x['failed']=='0'for x in checks)
(r/'focused-checks.json').write_text(json.dumps(dict(checks=checks,nonincrementalReleaseBuild=True,fullQualificationPending=True),indent=2)+'\n',encoding='utf-8',newline='\n')
full=json.loads((r/'catalog-full.json').read_text(encoding='utf-8'));representative=json.loads((r/'catalog-representative.json').read_text(encoding='utf-8'));catalog=dict(representative);cases=[]
def find(catalog,id):return next(c for c in catalog['cases']if c['id']==id)
loop=find(full,'loops.integer.large')
for asynchronous in [False,True]:
 c=dict(loop);c.update(id=loop['id']+('.async'if asynchronous else'.sync'),runAsync=asynchronous);cases.append(c)
# A diagnostic native-helper control of the same checksum; the independent CLR
# golden and N are unchanged. This is labelled separately from the file scripts.
helper=dict(loop);helper.update(id='loops.integer.native-helper.control',source='N = 16384\ndef fold():\n    total=0\n    for i in range(N):\n        total+=i\n    return total\nprint(fold())\n',runAsync=False);helper['sourceSha256']=hashlib.sha256(helper['source'].encode()).hexdigest();cases.append(helper)
for id in ['calls.positional.large','generators.drain.large']:cases.append(dict(find(full,id),runAsync=False))
for id in ['scripts.csv-validated-records.large','scripts.json-summary-helpers.large']:cases.append(dict(find(representative,id),runAsync=False))
catalog['cases']=cases;d=r/'allocation-short';d.mkdir()
for n in ['Allocation.csproj','Program.cs']:shutil.copyfile(base/'allocation-short'/n,d/n)
s=(d/'Program.cs').read_text(encoding='utf-8');s=s.replace('var fixture = parse.Invoke(null, [item.GetProperty("fixtureJson").GetString()])!;','var fixture = parse.Invoke(null, [item.GetProperty("fixtureJson").GetString()]);');s=s.replace('var host = (ILythonHost)Activator.CreateInstance(hostType, all, null, [fixture, folder], null)!;','var host = fixture is null ? (ILythonHost)new BareHost()\n        : (ILythonHost)Activator.CreateInstance(hostType, all, null, [fixture, folder], null)!;');s=s.replace('            reset.Invoke(host, null);','            if (fixture is not null) reset.Invoke(host, null);');s=s.replace('                var files = check.Invoke(host, null);','                if (fixture is not null)\n                {\n                var files = check.Invoke(host, null);');s=s.replace('throw new InvalidDataException("File golden mismatch.");','throw new InvalidDataException("File golden mismatch.");\n                }');s+='\nsealed class BareHost : ILythonHost { }\n';(d/'Program.cs').write_text(s,encoding='utf-8',newline='\n')
(d/'catalog.json').write_text(json.dumps(catalog,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n');shutil.copyfile(base/'measure-allocation.py',r/'measure-allocation.py')
print(json.dumps(dict(coreSHA256=images['candidate']['Lokad.Lython.dll'],inputs=len(paths),cases=[c['id']for c in cases],sourcePairTimingPending=True)))
