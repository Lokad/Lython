from pathlib import Path
import json
r=Path(__file__).parent
identity=json.loads((r.parent/'subtext-storage-r435/frozen/identity.json').read_text(encoding='utf-8'))
s=(r.parent/'completed-async-r433/inspect-vm.py').read_text(encoding='utf-8').replace('line-construction-b827-20261116/reference/Lokad.Lython.dll','subtext-storage-b832-20261116/reference/Lokad.Lython.dll').replace('efd8270751e008587042c729869e214f000f1730a4e05683ae6ed4c6351f62db',identity['images']['reference']['Lokad.Lython.dll'])
(r/'inspect-vm.py').write_text(s,encoding='utf-8',newline='\n');print('Inspect only supersededecd9 aliases; current1c8e/c7e images and toolchains retained.')
