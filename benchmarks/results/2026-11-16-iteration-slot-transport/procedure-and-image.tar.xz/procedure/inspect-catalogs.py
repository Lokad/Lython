from pathlib import Path
import json,subprocess
r=Path(__file__).parent
code='''from pathlib import Path
import fcntl,hashlib,json,os,stat,subprocess
b=Path('/home/lokad/lython-bench-checks');root=b/'subtext-storage-b832-20261116'
with(b/'comparison-vm.lock').open('a')as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 workers=subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record|[p]ython3.*cpython-worker.py'],capture_output=True,text=True).stdout
 own={str(os.getpid()),str(os.getppid())};assert all(line.split(maxsplit=1)[0]in own for line in workers.splitlines()),workers
 assert not any(os.path.ismount(p)for p in b.glob('*/guest-fixtures'))
 rows=[];inodes={}
 for name in ['representative.json','additional.json']:
  p=root/name;m=p.lstat();assert stat.S_ISREG(m.st_mode)and m.st_uid==os.getuid()
  row=dict(name=name,sha256=hashlib.sha256(p.read_bytes()).hexdigest(),bytes=m.st_size,links=m.st_nlink,paths=[]);rows.append(row);inodes[m.st_dev,m.st_ino]=row
 for base,dirs,names in os.walk(b):
  for name in names:
   p=Path(base)/name;m=p.lstat();row=inodes.get((m.st_dev,m.st_ino))
   if row is not None:row['paths'].append(str(p.relative_to(b)))
 assert all(len(row['paths'])==row['links']for row in rows)
 print(json.dumps(rows))
'''
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73'];p=subprocess.run(ssh+['python3 -'],input=code,capture_output=True,text=True,encoding='utf-8',timeout=45);assert p.returncode==0,p.stderr
(r/'catalog-aliases.json').write_text(p.stdout,encoding='utf-8',newline='\n');print(p.stdout)
