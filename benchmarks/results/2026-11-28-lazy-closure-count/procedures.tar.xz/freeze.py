from hashlib import sha256
from pathlib import Path
from shutil import copy2, copytree
from subprocess import check_output
import json

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
prior=lab.parent/'direct-loop-position-b1953-20261128/comparison'
template=lab.parent/'generator-expression-preflight-b1952-20261128'
pair=lab/'comparison'
build=lab/'ubuntu-artifacts/bin/Lokad.Lython/release_net11.0/Lokad.Lython.dll'
read=lambda path:json.loads(path.read_bytes())
digest=lambda path:sha256(path.read_bytes()).hexdigest()
files=lambda folder:{path.name:digest(path) for path in folder.iterdir()}

def git(*args):
    return check_output(['git',*args],cwd=repo)

def write(path,data):
    path.write_text(json.dumps(data,indent=2)+'\n',encoding='utf-8',newline='\n')

old=read(prior/'identity.json')
head=git('rev-parse','HEAD').decode().strip()
assert head.startswith('2806d7d75')
assert sha256(git('diff','--binary',old['sourceRevision'],head,'--','src/Lokad.Lython','tests')).hexdigest()==old['sourcePatchSHA256']
assert not git('diff','--binary',head,'--','Directory.Packages.props','src/Lokad.Lython.Utf8Regex','tests')
frozen=old['imageFiles']['candidate']
assert len(frozen)==32 and files(prior/'candidate')==frozen
pair.mkdir()
for role in ('reference','candidate'):
    copytree(prior/'candidate',pair/role)
copy2(build,pair/'candidate/Lokad.Lython.dll')
assert not (pair/'candidate/Lokad.Lython.dll').samefile(build)
images={role:files(pair/role) for role in ('reference','candidate')}
assert {name for name,checksum in frozen.items() if images['candidate'][name]!=checksum}=={'Lokad.Lython.dll'}
assert images['reference']==frozen
patch=git('diff','--binary',head,'--','src/Lokad.Lython')
assert patch.count(b'diff --git ')==2
(lab/'candidate.patch').write_bytes(patch)
for name in ('representative.json','cpython-worker.py','run.sh','jobs.json','collect.py'):
    copy2(template/'comparison'/name,pair/name)
reference_catalog=read(template/'comparison/identity.json')
assert digest(pair/'representative.json')==reference_catalog['catalogs']['representative.json']['sha256']
assert digest(pair/'cpython-worker.py')==old['cpythonWorkerSHA256']
assert len(read(pair/'jobs.json')['warm'])==5
write(pair/'identity.json',dict(sourceRevision=head,sourcePatchSHA256=sha256(patch).hexdigest(),imageFiles=images,
    coreSHA256={r+s:v['Lokad.Lython.dll'] for r,v in images.items() for s in ('','-control')},
    expectedCPythonSHA256=old['expectedCPythonSHA256'],cpythonWorkerSHA256=old['cpythonWorkerSHA256'],
    catalogs={name:{'sha256':digest(pair/name)} for name in ('representative.json','jobs.json')},
    purpose='Read retained namespace counts without materializing an empty dictionary.'))
for name in ('measure-allocation.py','check-admission.py','summarize.py'):
    copy2(template/name,lab/name)
assert b'\r' not in (pair/'run.sh').read_bytes()
print('Frozen 32 files per role, four goldens and five local warm lanes.')
