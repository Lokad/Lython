# R229 controlled patch comparison

One complete1024-line two-input UTF-8 patch job, exact67597input bytes, independently
constructed file/stdout goldens already validated under both engines at three sizes.
Use the unchanged frozen worker/qualified4aa runtime and stockCPython3.13.16 with
normalGC/tiering,5s warmups/role/job,7rotated150ms rounds and independent identical
roles. Separate compile/warm/compile-to-result; one existing small config warm
control exposes process variability. All unfavorable signs remain visible.

MediatedRAM I/O/full output checks/prior-result cleanup included. Fixture reset,
protocol, startup/final cache teardown excluded; wider process CPU includes surrounds.
No source-pair speedup, pending-I/O, exact heap/RSS or embedding-latency claim.
Stop after four jobs with identity/golden/budget/quiet/Closed/join/RAM/archive gates.
Select a runtime phase only for a material gap grounded in these results and source;
one subsequent cost capture only for a concrete unanswered question. No broad campaign.
Finite180s owner/30sstop/30smargin; persistent evidence, RAM only guest fixtures.
