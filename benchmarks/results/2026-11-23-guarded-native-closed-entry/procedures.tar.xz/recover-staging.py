from pathlib import Path
import gzip
import hashlib
import json
import shutil
import subprocess

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
older = lab.parent / "closure-result-consumer-20261123"
tracked = "benchmarks/results/2026-11-23-closure-result-consumer/"
sha = lambda data: hashlib.sha256(data).hexdigest()
def pushed(name):
    return subprocess.check_output(["git", "show", "origin/master:" + tracked + name], cwd=repo)

proofs = []
for prefix in ("", "confirmation/"):
    state = json.loads(pushed(prefix + "terminal-status.json"))
    receipt = state["receipt"]
    assert receipt["complete"] and receipt["allWorkersJoined"] and receipt["archivedAndVerifiedUnderLease"]
    assert sha(pushed(prefix + "observations.tar.xz")) == receipt["archiveSHA256"]
    proofs.append(receipt["archiveSHA256"])
files = json.loads(pushed("identity.json"))["imageFiles"]["candidate"]
assert len(files) == 32 and all(sha((older / "candidate" / name).read_bytes()) == value for name, value in files.items())
core = gzip.decompress(pushed("candidate-core.dll.gz"))
assert sha(core) == files["Lokad.Lython.dll"]
witness = dict(sha=sha(core), size=len(core), archive=proofs[0], repeat=proofs[1])
shutil.copyfile(lab / "stage.log", lab / "first-stage.log")
shutil.copyfile(lab / "quiet.py", lab / "first-quiet.py")
assert "needs one core, publication archive and working-room floor" in (lab / "first-stage.log").read_text(encoding="utf-8")
source = (lab / "quiet.py").read_text(encoding="utf-8")
proof_line = next(line for line in source.splitlines() if line.startswith("   proof="))
source = source.replace(proof_line, "   proof=" + repr(witness))
source = source.replace("complete-native-closed-entry-b1507-20261123", "closure-result-consumer-b1497-20261123")
source = source.replace("complete-native-closed-control-b1508-20261123", "closure-result-confirmation-b1498-20261123")
assert "b1507-20261123" not in source
compile(source, "quiet.py", "exec")
(lab / "quiet.py").write_text(source, encoding="utf-8", newline="\n")
