from pathlib import Path
import gzip
import hashlib
import json
import shutil
import subprocess

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
prior = lab.parent / "complete-native-closed-entry-20261123"
template = lab.parent / "supplied-scalar-return-20261123"

def install(name, donor, replacements):
    source = (donor / name).read_text(encoding="utf-8")
    for old, new in replacements:
        assert old in source, (name, old)
        source = source.replace(old, new)
    compile(source, name, "exec")
    (lab / name).write_text(source, encoding="utf-8", newline="\n")

install("prepare.py", prior, [
    ('case_ids = [eager, postponed, omitted, "scripts.factory-observed-defaults", module_call,',
     'case_ids = [eager, omitted, module_call,'),
    ('B1507 complete all existing closed returns before native activation',
     'B1509 skip the shared closed return for ordinary native bodies'),
])
install("stage.py", template, [
    ("supplied-scalar-return-b1504-20261123", "guarded-native-closed-entry-b1509-20261123"),
    ("eager-isolated-definition-b1502-20261123", "supplied-scalar-return-b1504-20261123"),
    ("'lython-b1504-fixtures'", "'lython-b1509-fixtures'"),
])
tracked = "benchmarks/results/2026-11-23-complete-native-closed-entry/"
def pushed(name):
    return subprocess.check_output(["git", "show", "origin/master:" + tracked + name], cwd=repo)
sha = lambda data: hashlib.sha256(data).hexdigest()
identity = json.loads(pushed("identity.json"))
terminal = json.loads(pushed("terminal-status.json"))
repeat = json.loads(pushed("repeat-terminal-status.json"))
for state, filename in ((terminal, "observations.tar.xz"), (repeat, "repeat-observations.tar.xz")):
    assert state["receipt"]["complete"] and state["receipt"]["allWorkersJoined"]
    assert state["receipt"]["archivedAndVerifiedUnderLease"]
    assert sha(pushed(filename)) == state["receipt"]["archiveSHA256"]
files = identity["imageFiles"]["candidate"]
assert len(files) == 32 and all(sha((prior / "candidate" / name).read_bytes()) == value for name, value in files.items())
core = gzip.decompress(pushed("candidate-core.dll.gz"))
assert sha(core) == files["Lokad.Lython.dll"]
proof = dict(sha=sha(core), size=len(core), archive=terminal["receipt"]["archiveSHA256"],
             repeat=repeat["receipt"]["archiveSHA256"])

install("quiet.py", template, [
    ("lython-b1504-supplied-scalar-return-20261123", "lython-b1509-guarded-native-closed-entry-20261123"),
    (".+b1504-", ".+b1509-"),
    ("lython-b1504-stage-", "lython-b1509-stage-"),
    ("  assert free >= minimum,", """
  if free < minimum:
   proof=RETIREMENT_PROOF
   prior=base/'complete-native-closed-entry-b1507-20261123'
   repeat=base/'complete-native-closed-control-b1508-20261123'
   replica=prior/'candidate/Lokad.Lython.dll'
   info=replica.lstat()
   assert replica.resolve()==replica and stat.S_ISREG(info.st_mode)
   assert info.st_uid==os.getuid() and info.st_nlink==1 and info.st_size==proof['size']
   assert digest(replica)==proof['sha']
   assert digest(prior/'observations.tar.xz')==proof['archive']
   assert digest(repeat/'observations.tar.xz')==proof['repeat']
   assert not (prior/'guest-fixtures').exists() and not (repeat/'guest-fixtures').exists()
   replica.unlink()
   free=shutil.disk_usage(base).free
   print(json.dumps(dict(retiredWorkingReplica=str(replica),sha256=proof['sha'],freeAfterRetirement=free)),flush=True)
  assert free >= minimum,""".replace("RETIREMENT_PROOF", repr(proof))),
])
for name in ("allocations.py", "summarize.py"):
    shutil.copyfile(template / name, lab / name)
