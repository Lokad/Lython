; Assembly listing for method Lokad.Lython.Runtime.PyExecutableFunction:StartNativeCall(Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,bool,bool,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,byref,byref):this (FullOpts)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; FullOpts code
; optimized code
; rbp based frame
; partially interruptible
; No PGO data
; 1 inlinees with PGO data; 12 single block inlinees; 5 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       push     r15
       push     r14
       push     rdi
       push     rsi
       push     rbx
       sub      rsp, 440
       lea      rbp, [rsp+0x1E0]
       vxorps   xmm4, xmm4, xmm4
       vmovdqa  xmmword ptr [rbp-0x190], xmm4
       mov      rax, -336
 
G_M000_IG16:                ;; offset=0x002D
       vmovdqa  xmmword ptr [rbp+rax-0x30], xmm4
       vmovdqa  xmmword ptr [rbp+rax-0x20], xmm4
       vmovdqa  xmmword ptr [rbp+rax-0x10], xmm4
       add      rax, 48
       jne      SHORT G_M000_IG16
       mov      qword ptr [rbp-0x30], rax
       mov      rbx, rcx
       mov      rsi, bword ptr [rbp+0x48]
 
G_M000_IG02:                ;; offset=0x0050
       mov      rax, bword ptr [r8]
       mov      edi, dword ptr [r8+0x08]
       mov      r14, gword ptr [rdx+0x18]
       mov      rcx, gword ptr [rbx+0x40]
       mov      r15d, dword ptr [rcx+0xE8]
       cmp      r15d, 16
       ja       G_M000_IG11
       cmp      byte  ptr [rbp+0x40], 0
       jne      G_M000_IG07
 
G_M000_IG03:                ;; offset=0x007A
       mov      rcx, gword ptr [rbx+0x08]
       mov      rcx, gword ptr [rcx+0x08]
       mov      ecx, dword ptr [rcx+0x08]
       cmp      ecx, r15d
       ja       G_M000_IG11
       lea      r8, bword ptr [rbp-0x128]
       mov      bword ptr [rbp-0x170], r8
       mov      dword ptr [rbp-0x168], ecx
       xor      rcx, rcx
       mov      bword ptr [rbp-0x180], rcx
 
G_M000_IG04:                ;; offset=0x00AB
       mov      dword ptr [rbp-0x178], ecx
       mov      rcx, gword ptr [rbp+0x30]
       mov      gword ptr [rsp+0x20], rcx
       xor      ecx, ecx
       mov      dword ptr [rsp+0x28], ecx
       mov      gword ptr [rsp+0x30], r9
       mov      gword ptr [rsp+0x38], rdx
       mov      bword ptr [rbp-0x190], rax
       mov      dword ptr [rbp-0x188], edi
       lea      rcx, [rbp-0x170]
       lea      rdx, [rbp-0x180]
       lea      r9, [rbp-0x190]
       mov      qword ptr [rsp+0x40], r9
       mov      r9, rbx
       mov      r8, r14
       call     [Lokad.Lython.Runtime.LythonRuntime:BindFunctionArgumentsInto(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.ReadOnlySpan`1[Lokad.Lython.Runtime.CallArgumentValue],Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.FunctionBindingPlan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,bool,System.Object,Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):int]
 
G_M000_IG05:                ;; offset=0x00FD
       vxorps   ymm0, ymm0, ymm0
       vmovdqu  ymmword ptr [rbp-0x160], ymm0
       lea      rdx, bword ptr [rbp-0x128]
       mov      bword ptr [rbp-0x170], rdx
       mov      dword ptr [rbp-0x168], r15d
       movzx    rdx, byte  ptr [rbp+0x38]
       mov      dword ptr [rsp+0x20], edx
       mov      bword ptr [rsp+0x28], rsi
       mov      rsi, bword ptr [rbp+0x50]
       mov      bword ptr [rsp+0x30], rsi
       mov      rsi, bword ptr [rbp+0x58]
       mov      bword ptr [rsp+0x38], rsi
       mov      rsi, bword ptr [rbp+0x60]
       mov      bword ptr [rsp+0x40], rsi
       lea      rdx, [rbp-0x140]
       mov      qword ptr [rsp+0x48], rdx
       lea      rdx, [rbp-0x170]
       lea      r8, [rbp-0x160]
       mov      rcx, rbx
       mov      r9, r14
       call     [Lokad.Lython.Runtime.PyExecutableFunction:StartInline(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.Nullable`1[Lokad.Lython.Runtime.BoundFunctionArguments],Lokad.Lython.LythonSourceSpan,bool,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,byref,byref,byref):this]
       nop      
 
G_M000_IG06:                ;; offset=0x016D
       add      rsp, 440
       pop      rbx
       pop      rsi
       pop      rdi
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG07:                ;; offset=0x017D
       xor      ecx, ecx
       test     r9, r9
       je       SHORT G_M000_IG08
       mov      ecx, 1
       test     r15d, r15d
       je       G_M000_IG15
       mov      gword ptr [rbp-0x128], r9
       xor      edx, edx
       mov      qword ptr [rbp-0x120], rdx
 
G_M000_IG08:                ;; offset=0x01A2
       cmp      ecx, r15d
       ja       SHORT G_M000_IG11
       lea      rdx, bword ptr [rbp-0x128]
       mov      r8d, ecx
       shl      r8, 4
       add      r8, rdx
       mov      edx, r15d
       sub      edx, ecx
       cmp      edi, edx
       ja       SHORT G_M000_IG14
 
G_M000_IG09:                ;; offset=0x01C1
       mov      ecx, edi
       shl      rcx, 4
       mov      r10, rcx
       cmp      r10, 0x4000
       ja       SHORT G_M000_IG13
 
G_M000_IG10:                ;; offset=0x01D3
       mov      rcx, r8
       mov      rdx, rax
       mov      r8, r10
       call     System.Buffer:BulkMoveWithWriteBarrierInternal(byref,byref,nuint)
       cmp      dword ptr [(reloc 0x7ffa18222aa8)], 0
       je       G_M000_IG05
       jmp      SHORT G_M000_IG12
 
G_M000_IG11:                ;; offset=0x01F0
       call     [System.ThrowHelper:ThrowArgumentOutOfRangeException()]
       int3     
 
G_M000_IG12:                ;; offset=0x01F7
       call     CORINFO_HELP_POLL_GC
       jmp      G_M000_IG05
 
G_M000_IG13:                ;; offset=0x0201
       mov      rcx, r8
       mov      rdx, rax
       mov      r8, r10
       call     [System.Buffer:BulkMoveWithWriteBarrierBatch(byref,byref,nuint)]
       jmp      G_M000_IG05
 
G_M000_IG14:                ;; offset=0x0215
       call     [System.ThrowHelper:ThrowArgumentException_DestinationTooShort()]
       int3     
 
G_M000_IG15:                ;; offset=0x021C
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
; Total bytes of code 546

