from pathlib import Path
import json
import os
import re
import subprocess

lab = Path(__file__).resolve().parent
dotnet = Path.home() / ".dotnet11/dotnet.exe"
env = dict(os.environ, DOTNET_ROOT=str(dotnet.parent), DOTNET_ROOT_X64=str(dotnet.parent),
           DOTNET_TieredCompilation="0", DOTNET_JitDisasm="StartNativeCall TryCompleteNativeReturn TryStartPreparedIntegerReturn TryReturnDefinition")
catalog_file = lab / "comparison/representative.json"
catalog = json.loads(catalog_file.read_text(encoding="utf-8"))
assert len(catalog["cases"]) == 5
summary = []
for case in (catalog["cases"][i] for i in (0, 1, 3)):
    name = case["id"].rsplit(".", 1)[1]
    fixture = lab / (name + "-only.json")
    fixture.write_text(json.dumps(dict(catalog, cases=[case]), indent=2) + "\n", encoding="utf-8", newline="\n")
    row = dict(case=case["id"], methods={})
    for role in ("reference", "candidate"):
        image = lab / role
        asm = lab / (name + "-" + role + ".asm")
        assert not asm.exists()
        result = lab / (name + "-" + role + "-jit-alloc.json")
        subprocess.run([dotnet, image / "ValidatedAllocation.dll", image, fixture, result],
                       env=dict(env, DOTNET_JitStdOutFile=str(asm)), check=True, timeout=45)
        assert all(r["sharedBudgetBaselineRestored"] for r in json.loads(result.read_text(encoding="utf-8"))["rows"])
        text = asm.read_text(encoding="utf-8-sig")
        row["methods"][role] = re.findall(r"^; Assembly listing for method ([^(:]+(?::[^(:]+)+)\(", text, re.M)
    summary.append(row)
(lab / "jit-entry-summary.json").write_text(json.dumps(summary, indent=2) + "\n", encoding="utf-8", newline="\n")
print(json.dumps(summary, indent=2))
