from pathlib import Path
import hashlib
import json
import os
import shutil
import subprocess

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
prior = lab.parent / "supplied-scalar-return-20261123"
comparison = lab / "comparison"
comparison.mkdir(exist_ok=True)
read = lambda path: json.loads(path.read_text(encoding="utf-8"))
sha = lambda data: hashlib.sha256(data).hexdigest()
def write(path, value):
    path.write_text(json.dumps(value, indent=2) + "\n", encoding="utf-8", newline="\n")

catalog = read(lab.parent / "closed-native-workspace-20261123/representative.json")
by_id = {row["id"]: row for row in catalog["cases"]}
module_call = "scripts.ordinary-fully-supplied-helper"
supplied = by_id[module_call]
assert supplied == read(prior / "comparison/representative.json")["cases"][0]
omitted = "scripts.ordinary-helper-with-omitted-default"
source = supplied["source"].replace("base, weight):", "base, weight=7):").replace(", index % 7 + 1)", ")")
assert source != supplied["source"] and "weight=7" in source
python = "C:/Python313/python.exe"
golden = subprocess.run([python, "-I", "-X", "utf8", "-c", source], check=True, capture_output=True, timeout=10).stdout
golden = golden.decode("utf-8").replace("\r\n", "\n")
by_id[omitted] = dict(supplied, id=omitted, source=source, sourceSha256=sha(source.encode()),
    sourceUtf8Bytes=len(source.encode()), expectedOutput=golden, expectedOutputSha256=sha(golden.encode()),
    expectedOutputUtf8Bytes=len(golden.encode()))
eager = "scripts.annotated-rule-closures.nested-factories"
postponed = eager + ".postponed"
case_ids = [eager, omitted, module_call,
            "calls.positional.wide-native-buffer", "scripts.csv-invoice.method-policy.quoted-control"]
catalog["cases"] = [by_id[name] for name in case_ids]
representative = comparison / "representative.json"
write(representative, catalog)
write(comparison / "jobs.json", {"warm": [[name, "warm"] for name in case_ids] + [[eager, "compile-run"]]})

identity = read(prior / "comparison/identity.json")
files = identity["imageFiles"]["candidate"]
tree = repo / ".git/agent-worktrees/complete-native-closed-entry-20261123"
assert not subprocess.check_output(["git", "-C", tree, "status", "--porcelain"])
revision = subprocess.check_output(["git", "-C", tree, "rev-parse", "HEAD"], text=True, encoding="utf-8").strip()
base = subprocess.check_output(["git", "rev-parse", "a2bde38b2"], cwd=repo, text=True, encoding="utf-8").strip()
assert not subprocess.check_output(["git", "diff", "--name-only", base, identity["candidate"], "--", "src", "tests"], cwd=repo)
dotnet = Path.home() / ".dotnet11/dotnet.exe"
env = dict(os.environ, DOTNET_ROOT=str(dotnet.parent), DOTNET_ROOT_X64=str(dotnet.parent))
protocol = repo / "benchmarks/cpython-worker.py"
assert sha(protocol.read_bytes()) == identity["cpythonWorkerSHA256"]
new_images = {}
for role in ("reference", "candidate"):
    image = lab / role
    image.mkdir(exist_ok=True)
    for name, digest in files.items():
        source = prior / "candidate" / name
        assert sha(source.read_bytes()) == digest
        if name == "Lokad.Lython.dll" and role == "candidate":
            source = lab / "frozen/bin/Lokad.Lython/release_net11.0" / name
        shutil.copyfile(source, image / name)
    for name in ("ValidatedAllocation.dll", "ValidatedAllocation.deps.json", "ValidatedAllocation.runtimeconfig.json"):
        shutil.copyfile(prior / "candidate" / name, image / name)
    hashes = {name: sha((image / name).read_bytes()) for name in files}
    new_images[role] = hashes
    receipt = comparison / (role + "-verify.json")
    subprocess.run([dotnet, image / "Lokad.Lython.Benchmarks.dll", "--compare", "verify", "--catalog", representative,
                    "--dotnet", dotnet, "--python", python, "--python-worker", protocol,
                    "--out", receipt], env=env, timeout=90, check=True)
    proof = read(receipt)
    assert proof["state"] == "Completed" and proof["caseCount"] == len(case_ids)
    assert proof["launched"]["library"]["sha256"] == hashes["Lokad.Lython.dll"]
    assert all(sha((image / name).read_bytes()) == digest for name, digest in hashes.items())
assert [name for name in files if new_images["reference"][name] != new_images["candidate"][name]] == ["Lokad.Lython.dll"]
write(comparison / "identity.json", dict(sourceRevision=base, sourceImageRevision=identity["candidate"],
    candidate=revision, purpose="B1509 skip the shared closed return for ordinary native bodies",
    imageFiles=new_images, coreSHA256={key: new_images[role]["Lokad.Lython.dll"] for role in new_images for key in (role, role+"-control")},
    cpythonWorkerSHA256=identity["cpythonWorkerSHA256"], expectedCPythonSHA256=identity["expectedCPythonSHA256"],
    catalogs={name: dict(sha256=sha((comparison / name).read_bytes())) for name in ("representative.json", "jobs.json")}))
