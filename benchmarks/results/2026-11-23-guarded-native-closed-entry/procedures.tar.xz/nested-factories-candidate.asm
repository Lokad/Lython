; Assembly listing for method Lokad.Lython.Runtime.PyExecutableFunction:TryCompleteNativeReturn(Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,bool,byref):bool:this (FullOpts)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; FullOpts code
; optimized code
; rsp based frame
; partially interruptible
; No PGO data
; 0 inlinees with PGO data; 17 single block inlinees; 2 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     r15
       push     r14
       push     rdi
       push     rsi
       push     rbp
       push     rbx
       sub      rsp, 120
       xor      eax, eax
       mov      qword ptr [rsp+0x28], rax
       vxorps   xmm4, xmm4, xmm4
       vmovdqu  ymmword ptr [rsp+0x30], ymm4
       vmovdqu  ymmword ptr [rsp+0x50], ymm4
       mov      qword ptr [rsp+0x70], rax
       mov      rbx, rcx
       mov      rsi, bword ptr [rsp+0xE0]
 
G_M000_IG02:                ;; offset=0x0033
       mov      rdi, bword ptr [r8]
       mov      ebp, dword ptr [r8+0x08]
       xor      ecx, ecx
       mov      qword ptr [rsi], rcx
       mov      qword ptr [rsi+0x08], rcx
       mov      r14, gword ptr [rdx+0x18]
       mov      r15, gword ptr [rbx+0x40]
       cmp      byte  ptr [r15+0xF5], 0
       je       G_M000_IG09
 
G_M000_IG03:                ;; offset=0x0059
       cmp      byte  ptr [rsp+0xD8], 0
       je       SHORT G_M000_IG05
       test     r9, r9
       setne    dl
       movzx    rdx, dl
       add      edx, ebp
       cmp      edx, dword ptr [r15+0xD8]
       jne      G_M000_IG10
       test     r9, r9
       jne      SHORT G_M000_IG04
       mov      bword ptr [rsp+0x38], rdi
       mov      dword ptr [rsp+0x40], ebp
       lea      rdx, [rsp+0x38]
       mov      rcx, rbx
       mov      r8, r14
       mov      r9, rsi
       call     [Lokad.Lython.Runtime.PyExecutableFunction:TryStartDirectIntegerReturn[Lokad.Lython.Runtime.LythonRuntime+SlotIntegerOperands](Lokad.Lython.Runtime.LythonRuntime+SlotIntegerOperands,Lokad.Lython.LythonSourceSpan,byref):bool:this]
       jmp      G_M000_IG14
 
G_M000_IG04:                ;; offset=0x00A2
       mov      gword ptr [rsp+0x60], r9
       mov      bword ptr [rsp+0x68], rdi
       mov      dword ptr [rsp+0x70], ebp
       lea      rdx, [rsp+0x60]
       mov      rcx, rbx
       mov      r8, r14
       mov      r9, rsi
       call     [Lokad.Lython.Runtime.PyExecutableFunction:TryStartDirectIntegerReturn[Lokad.Lython.Runtime.LythonRuntime+BoundIntegerOperands](Lokad.Lython.Runtime.LythonRuntime+BoundIntegerOperands,Lokad.Lython.LythonSourceSpan,byref):bool:this]
       jmp      G_M000_IG14
 
G_M000_IG05:                ;; offset=0x00C9
       test     r9, r9
       jne      G_M000_IG10
       xor      ecx, ecx
       mov      qword ptr [rsi], rcx
       mov      qword ptr [rsi+0x08], rcx
       cmp      byte  ptr [rdx+0x34], 0
       je       SHORT G_M000_IG07
       mov      rcx, gword ptr [rbx+0x08]
       mov      rcx, gword ptr [rcx+0x08]
       mov      ecx, dword ptr [rcx+0x08]
       mov      rdx, gword ptr [rbx+0x40]
       cmp      ecx, dword ptr [rdx+0xD8]
       jne      SHORT G_M000_IG07
       mov      rcx, rbx
       mov      edx, ebp
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:HasPreparedOmittedArguments(int):bool:this]
       test     eax, eax
       je       SHORT G_M000_IG07
       mov      r15, gword ptr [rsp+0xD0]
       mov      r15, gword ptr [r15+0xA0]
       cmp      byte  ptr [r15], r15b
       mov      rcx, r15
       call     [Lokad.Lython.Runtime.ExecutionState:get_CanContinue():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG06
       mov      rcx, r15
       mov      rdx, r14
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
 
G_M000_IG06:                ;; offset=0x0132
       mov      gword ptr [rsp+0x48], rbx
       mov      bword ptr [rsp+0x50], rdi
       mov      dword ptr [rsp+0x58], ebp
       lea      rdx, [rsp+0x48]
       mov      rcx, rbx
       mov      r8, r14
       mov      r9, rsi
       call     [Lokad.Lython.Runtime.PyExecutableFunction:TryStartDirectIntegerReturn[Lokad.Lython.Runtime.LythonRuntime+DefaultIntegerOperands](Lokad.Lython.Runtime.LythonRuntime+DefaultIntegerOperands,Lokad.Lython.LythonSourceSpan,byref):bool:this]
       jmp      SHORT G_M000_IG08
 
G_M000_IG07:                ;; offset=0x0156
       xor      eax, eax
 
G_M000_IG08:                ;; offset=0x0158
       jmp      SHORT G_M000_IG14
 
G_M000_IG09:                ;; offset=0x015A
       cmp      byte  ptr [rsp+0xD8], 0
       je       SHORT G_M000_IG10
       test     r9, r9
       jne      SHORT G_M000_IG10
       cmp      ebp, 1
       jne      SHORT G_M000_IG10
       mov      rdx, gword ptr [r15+0x58]
       test     rdx, rdx
       jne      SHORT G_M000_IG12
 
G_M000_IG10:                ;; offset=0x0177
       xor      eax, eax
 
G_M000_IG11:                ;; offset=0x0179
       add      rsp, 120
       pop      rbx
       pop      rbp
       pop      rsi
       pop      rdi
       pop      r14
       pop      r15
       ret      
 
G_M000_IG12:                ;; offset=0x0186
       vmovdqu  xmm0, xmmword ptr [rdi]
       vmovdqu  xmmword ptr [rsp+0x28], xmm0
 
G_M000_IG13:                ;; offset=0x0190
       mov      bword ptr [rsp+0x20], rsi
       lea      r8, [rsp+0x28]
       mov      rcx, rbx
       mov      r9, r14
       call     [Lokad.Lython.Runtime.PyExecutableFunction:TryReturnDefinition(Lokad.Lython.Frontend.ExecutableCreateFunction,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot,Lokad.Lython.LythonSourceSpan,byref):bool:this]
 
G_M000_IG14:                ;; offset=0x01A6
       movzx    rax, al
 
G_M000_IG15:                ;; offset=0x01A9
       add      rsp, 120
       pop      rbx
       pop      rbp
       pop      rsi
       pop      rdi
       pop      r14
       pop      r15
       ret      
 
; Total bytes of code 438

; Assembly listing for method Lokad.Lython.Runtime.PyExecutableFunction:TryReturnDefinition(Lokad.Lython.Frontend.ExecutableCreateFunction,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot,Lokad.Lython.LythonSourceSpan,byref):bool:this (FullOpts)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; FullOpts code
; optimized code
; rbp based frame
; fully interruptible
; No PGO data
; 0 inlinees with PGO data; 28 single block inlinees; 2 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       push     r14
       push     rdi
       push     rsi
       push     rbx
       sub      rsp, 80
       lea      rbp, [rsp+0x70]
       vxorps   xmm4, xmm4, xmm4
       vmovdqu  xmmword ptr [rbp-0x38], xmm4
       xor      eax, eax
       mov      qword ptr [rbp-0x28], rax
       mov      gword ptr [rbp+0x10], rcx
       mov      gword ptr [rbp+0x28], r9
       mov      rsi, rdx
       mov      rbx, r8
       mov      rdi, bword ptr [rbp+0x30]
 
G_M000_IG02:                ;; offset=0x0030
       xor      eax, eax
       mov      qword ptr [rdi], rax
       mov      qword ptr [rdi+0x08], rax
 
G_M000_IG03:                ;; offset=0x0039
       xor      r14, r14
       mov      rcx, rsi
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCreateFunction:get_InputCount():int:this]
       test     eax, eax
       je       SHORT G_M000_IG14
 
G_M000_IG04:                ;; offset=0x004B
       mov      rcx, gword ptr [rbp+0x10]
       lea      rdx, bword ptr [rcx+0x58]
       mov      r8, gword ptr [rdx]
       test     r8, r8
       je       SHORT G_M000_IG06
 
G_M000_IG05:                ;; offset=0x005B
       mov      rax, 0x7FF9B88E0E20
       cmp      qword ptr [r8], rax
       je       SHORT G_M000_IG09
 
G_M000_IG06:                ;; offset=0x006A
       test     r8, r8
       je       SHORT G_M000_IG08
 
G_M000_IG07:                ;; offset=0x006F
       mov      rax, 0x7FF9B88FEBB0
       xor      r10, r10
       cmp      qword ptr [r8], rax
       cmovne   r8, r10
 
G_M000_IG08:                ;; offset=0x0083
       test     r8, r8
       je       SHORT G_M000_IG10
 
G_M000_IG09:                ;; offset=0x0088
       xor      r14, r14
       jmp      SHORT G_M000_IG11
 
G_M000_IG10:                ;; offset=0x008D
       mov      r14, gword ptr [rdx]
 
G_M000_IG11:                ;; offset=0x0090
       test     r14, r14
       je       G_M000_IG23
       mov      rdx, gword ptr [rcx+0x40]
 
G_M000_IG12:                ;; offset=0x009D
       vmovdqu  xmm0, xmmword ptr [rbx]
       vmovdqu  xmmword ptr [rbp-0x38], xmm0
 
G_M000_IG13:                ;; offset=0x00A6
       mov      rcx, rdx
       lea      rdx, [rbp-0x38]
       lea      r8, [rbp-0x28]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryReadClosedDefinitionDefault(Lokad.Lython.Frontend.ExecutableCodeObject,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot,byref):bool]
       test     eax, eax
       je       G_M000_IG23
 
G_M000_IG14:                ;; offset=0x00BF
       mov      rcx, gword ptr [rbp+0x10]
       mov      rdx, gword ptr [rcx+0x28]
       mov      rcx, gword ptr [rdx+0xA0]
       mov      rdx, gword ptr [rbp+0x28]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.ExecutionState:EnterFunctionCall(Lokad.Lython.LythonSourceSpan):this]
       mov      rcx, gword ptr [rbp+0x10]
       mov      r8, gword ptr [rcx+0x28]
       mov      rdx, gword ptr [r8+0xA0]
       mov      rdx, gword ptr [rdx+0x148]
       mov      gword ptr [rbp-0x40], rdx
 
G_M000_IG15:                ;; offset=0x00F4
       test     r14, r14
       jne      SHORT G_M000_IG16
       mov      rdx, r8
       mov      r9, gword ptr [rcx+0x40]
       mov      r9, gword ptr [r9+0x98]
       cmp      dword ptr [r9+0x08], 0
       jbe      G_M000_IG19
       mov      r9, gword ptr [r9+0x10]
       mov      r8, rbx
       mov      rcx, rsi
       call     [Lokad.Lython.Runtime.LythonRuntime:CreateClosedFunctionDefinition(Lokad.Lython.Frontend.ExecutableCreateFunction,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.PyFunctionBase]
       mov      rbx, rax
       jmp      SHORT G_M000_IG17
 
G_M000_IG16:                ;; offset=0x0127
       mov      gword ptr [rsp+0x20], r14
       mov      rdx, gword ptr [rcx+0x40]
       mov      rcx, rsi
       mov      r9, qword ptr [rbp-0x28]
       call     [Lokad.Lython.Runtime.LythonRuntime:CreateClosedComputedDefinition(Lokad.Lython.Frontend.ExecutableCreateFunction,Lokad.Lython.Frontend.ExecutableCodeObject,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,long,System.Object):Lokad.Lython.Runtime.PyFunctionBase]
       mov      rbx, rax
 
G_M000_IG17:                ;; offset=0x0140
       mov      rcx, gword ptr [rbp+0x10]
       mov      rax, gword ptr [rcx+0x28]
       mov      rdx, gword ptr [rcx+0x40]
       mov      rdx, gword ptr [rdx+0x98]
       mov      r8d, dword ptr [rdx+0x08]
       lea      r10d, [r8-0x01]
       cmp      r10d, r8d
       jae      SHORT G_M000_IG19
       mov      r8d, r10d
       shl      r8, 5
       mov      rsi, gword ptr [rdx+r8+0x10]
       mov      r14, gword ptr [rax+0xA0]
       cmp      byte  ptr [r14], r14b
       mov      rcx, r14
       call     [Lokad.Lython.Runtime.ExecutionState:get_CanContinue():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG18
       mov      rcx, r14
       mov      rdx, rsi
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
 
G_M000_IG18:                ;; offset=0x018F
       mov      rcx, rdi
       mov      rdx, rbx
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       xor      ecx, ecx
       mov      qword ptr [rdi+0x08], rcx
       jmp      SHORT G_M000_IG20
 
G_M000_IG19:                ;; offset=0x01A2
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG20:                ;; offset=0x01A8
       mov      rcx, gword ptr [rbp+0x10]
       mov      rdx, gword ptr [rcx+0x28]
       mov      rsi, gword ptr [rdx+0xA0]
       mov      rbx, rsi
       lea      rcx, bword ptr [rbx+0x148]
       mov      rdx, gword ptr [rbp-0x40]
       call     CORINFO_HELP_ASSIGN_REF
       mov      rcx, rsi
       call     [Lokad.Lython.Runtime.ExecutionState:LeaveFunctionCall():this]
       nop      
 
G_M000_IG21:                ;; offset=0x01D4
       mov      eax, 1
 
G_M000_IG22:                ;; offset=0x01D9
       add      rsp, 80
       pop      rbx
       pop      rsi
       pop      rdi
       pop      r14
       pop      rbp
       ret      
 
G_M000_IG23:                ;; offset=0x01E4
       xor      eax, eax
 
G_M000_IG24:                ;; offset=0x01E6
       add      rsp, 80
       pop      rbx
       pop      rsi
       pop      rdi
       pop      r14
       pop      rbp
       ret      
 
G_M000_IG25:                ;; offset=0x01F1
       sub      rsp, 40
 
G_M000_IG26:                ;; offset=0x01F5
       mov      rbx, rcx
       cmp      gword ptr [rbp-0x40], 0
       je       SHORT G_M000_IG27
       mov      rcx, rbx
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntimeException:get_OriginalPythonException():Lokad.Lython.Runtime.PyException:this]
       cmp      rax, gword ptr [rbp-0x40]
       je       SHORT G_M000_IG27
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntimeException:get_PythonContext():Lokad.Lython.Runtime.PyException:this]
       test     rax, rax
       jne      SHORT G_M000_IG27
       mov      rcx, rbx
       mov      rdx, gword ptr [rbp-0x40]
       call     [Lokad.Lython.Runtime.LythonRuntimeException:set_PythonContext(Lokad.Lython.Runtime.PyException):this]
 
G_M000_IG27:                ;; offset=0x022B
       call     CORINFO_HELP_RETHROW
       int3     
 
G_M000_IG28:                ;; offset=0x0231
       sub      rsp, 40
 
G_M000_IG29:                ;; offset=0x0235
       mov      rcx, gword ptr [rbp+0x10]
       mov      rdx, gword ptr [rcx+0x28]
       mov      rbx, gword ptr [rdx+0xA0]
       lea      rcx, bword ptr [rbx+0x148]
       mov      rdx, gword ptr [rbp-0x40]
       call     CORINFO_HELP_ASSIGN_REF
       mov      rcx, gword ptr [rbp+0x10]
       mov      rax, gword ptr [rcx+0x28]
       mov      rcx, gword ptr [rax+0xA0]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.ExecutionState:LeaveFunctionCall():this]
       nop      
 
G_M000_IG30:                ;; offset=0x026C
       add      rsp, 40
       ret      
 
G_M000_IG31:                ;; offset=0x0271
       sub      rsp, 40
 
G_M000_IG32:                ;; offset=0x0275
       mov      rbx, rcx
       mov      rcx, gword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.PyFunctionBase:get_Closure():Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:this]
       mov      rsi, rax
       mov      rcx, gword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.PyFunctionBase:get_Name():System.String:this]
       mov      r8, rax
       mov      rdx, rsi
       mov      rcx, rbx
       mov      r9, gword ptr [rbp+0x28]
       call     [Lokad.Lython.Runtime.PyFunctionBinding:AnnotateException(Lokad.Lython.Runtime.LythonRuntimeException,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,System.String,Lokad.Lython.LythonSourceSpan)]
       call     CORINFO_HELP_RETHROW
       int3     
 
; Total bytes of code 680

