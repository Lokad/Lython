from pathlib import Path
import gzip
import hashlib
import json
import shutil
import subprocess
import tarfile

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
quiet = lab / "comparison/quiet"
dest = repo / "benchmarks/results/2026-11-23-guarded-native-closed-entry"
sha = lambda data: hashlib.sha256(data).hexdigest()
read = lambda path: json.loads(path.read_text(encoding="utf-8"))
identity = read(lab / "comparison/identity.json")
terminal = read(quiet / "terminal-status.json")
receipt = terminal["receipt"]
assert not terminal["live"] and terminal["exitCode"] == "0" and not terminal["fixtures"]
assert all(receipt[name] for name in ("complete", "archivedAndVerifiedUnderLease", "allWorkersJoined",
                                      "guestFixturesRemoved", "quietBeforeAndAfter"))
assert sha((quiet / "observations.tar.xz").read_bytes()) == receipt["archiveSHA256"]
assert read(quiet / "summary.json")["timedBatches"] == 168
assert all(row["peakAdmission"][0] == row["peakAdmission"][1] for row in read(lab / "allocation-summary-six.json"))
assert "needs one core, publication archive and working-room floor" in (lab / "first-stage.log").read_text(encoding="utf-8")
assert "AssertionError" in (lab / "second-stage.log").read_text(encoding="utf-8")
patch = subprocess.check_output(["git", "diff", "--binary", identity["sourceRevision"], identity["candidate"],
                                 "--", "src", "tests"], cwd=repo)
(lab / "comparison.patch").write_bytes(patch)
identity["comparisonPatchSHA256"] = sha(patch)
identity["retainedRevision"] = None
dest.mkdir(exist_ok=True)
assert all(path.name == "README.md" for path in dest.iterdir())
for role, files in identity["imageFiles"].items():
    assert len(files) == 32 and all(sha((lab / role / name).read_bytes()) == digest for name, digest in files.items())
    core = lab / role / "Lokad.Lython.dll"
    image = dest / "candidate-core.dll.gz" if role == "candidate" else dest.parent / "2026-11-23-supplied-scalar-return/candidate-core.dll.gz"
    if role == "candidate":
        image.write_bytes(gzip.compress(core.read_bytes(), mtime=0))
    assert sha(gzip.decompress(image.read_bytes())) == files[core.name]
(dest / "identity.json").write_text(json.dumps(identity, indent=2) + "\n", encoding="utf-8", newline="\n")
for name in ("observations.tar.xz", "summary.json", "terminal-status.json"):
    shutil.copyfile(quiet / name, dest / name)
for name in ("allocation-summary-six.json", "jit-entry-summary.json"):
    shutil.copyfile(lab / name, dest / name)
with tarfile.open(dest / "procedures.tar.xz", "w:xz") as archive:
    for name in (
        "setup.py", "prepare.py", "stage.py", "recover-staging.py", "quiet.py", "first-quiet.py", "second-quiet.py",
        "recovered-quiet.py", "inspect-entry.py", "inspect-entry.log", "archive.py", "comparison.patch", "summarize.py",
        "allocations.py", "allocations.log", "windows-frozen.log", "windows-white.log", "ubuntu-public.log",
        "ubuntu-white.log", "test-ubuntu.sh", "stage.log", "first-stage.log", "second-stage.log", "retrieval.log",
        "comparison/reference-verify.json", "comparison/candidate-verify.json", "comparison/quiet/observe-not-before"):
        archive.add(lab / name, arcname=name)
    archive.add(lab.parent / "complete-native-closed-entry-20261123/refined-windows-public.log",
                arcname="windows-public.log")
    for pattern in ("*.asm", "*-only.json", "*-jit-alloc.json", "*-allocation-six.json"):
        for path in sorted(lab.glob(pattern)):
            archive.add(path, arcname=path.name)
print(dest)
