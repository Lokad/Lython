set -e
export DOTNET_ROOT=/home/vermorel/.dotnet
export DOTNET_ROOT_X64=$DOTNET_ROOT
lab=/mnt/d/code/Lython/.git/agent-notes/review-20261031/guarded-native-closed-entry-20261123
public='FullyQualifiedName~NativeIntegerChain|FullyQualifiedName~OrdinalFunctionTransport|FullyQualifiedName~FunctionDefaultMetadata|FullyQualifiedName~NativeTuple|FullyQualifiedName~StackGuardScenario'
white='FullyQualifiedName~NativeIntegerChain|FullyQualifiedName~NativeTupleReturn|FullyQualifiedName~ComposedNativeCall|FullyQualifiedName~SimpleFunctionExecutionBoundary'
for kind in public white; do
  if [ "$kind" = public ]; then p=Lokad.Lython.PublicApi.Tests; filter=$public; else p=Lokad.Lython.Tests; filter=$white; fi
  out="$lab/ubuntu-$kind.log"
  $DOTNET_ROOT/dotnet test "tests/$p/$p.csproj" -c Release -f net10.0 --artifacts-path "$lab/ubuntu" --filter "$filter" > "$out" 2>&1 || { tail -35 "$out"; exit 1; }
  tail -6 "$out"
done
