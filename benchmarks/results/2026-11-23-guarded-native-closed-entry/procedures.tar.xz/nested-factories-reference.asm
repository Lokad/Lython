; Assembly listing for method Lokad.Lython.Runtime.PyExecutableFunction:StartNativeCall(Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,bool,bool,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,byref,byref):this (FullOpts)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; FullOpts code
; optimized code
; rbp based frame
; partially interruptible
; No PGO data
; 1 inlinees with PGO data; 25 single block inlinees; 7 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       push     r15
       push     r14
       push     r13
       push     r12
       push     rdi
       push     rsi
       push     rbx
       sub      rsp, 504
       lea      rbp, [rsp+0x230]
       vxorps   xmm4, xmm4, xmm4
       vmovdqa  xmmword ptr [rbp-0x1D0], xmm4
       mov      rax, -384
 
G_M000_IG22:                ;; offset=0x0031
       vmovdqa  xmmword ptr [rbp+rax-0x40], xmm4
       vmovdqa  xmmword ptr [rbp+rax-0x30], xmm4
       vmovdqa  xmmword ptr [rbp+rax-0x20], xmm4
       add      rax, 48
       jne      SHORT G_M000_IG22
       mov      qword ptr [rbp-0x40], rax
       mov      rbx, rcx
       mov      rdi, rdx
       mov      rsi, r9
       mov      r14, gword ptr [rbp+0x38]
       mov      r15, bword ptr [rbp+0x60]
 
G_M000_IG02:                ;; offset=0x005E
       mov      r13, bword ptr [r8]
       mov      r12d, dword ptr [r8+0x08]
       test     rsi, rsi
       sete     r8b
       movzx    r8, r8b
       movzx    rax, byte  ptr [rbp+0x48]
       mov      dword ptr [rbp-0x1D4], eax
       test     r8d, eax
       je       SHORT G_M000_IG06
 
G_M000_IG03:                ;; offset=0x007F
       cmp      r12d, 1
       jne      SHORT G_M000_IG06
       mov      r8, gword ptr [rbx+0x40]
       mov      rdx, gword ptr [r8+0x58]
       test     rdx, rdx
       je       SHORT G_M000_IG06
       mov      r8, gword ptr [rbx+0x28]
       cmp      byte  ptr [r8+0x104], 0
       jne      SHORT G_M000_IG06
 
G_M000_IG04:                ;; offset=0x00A0
       vmovdqu  xmm0, xmmword ptr [r13]
       vmovdqu  xmmword ptr [rbp-0x1A0], xmm0
 
G_M000_IG05:                ;; offset=0x00AE
       mov      bword ptr [rsp+0x20], r15
       lea      r8, [rbp-0x1A0]
       mov      rcx, rbx
       mov      r9, r14
       call     [Lokad.Lython.Runtime.PyExecutableFunction:TryReturnDefinition(Lokad.Lython.Frontend.ExecutableCreateFunction,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot,Lokad.Lython.LythonSourceSpan,byref):bool:this]
       test     eax, eax
       jne      G_M000_IG15
 
G_M000_IG06:                ;; offset=0x00CE
       cmp      dword ptr [rbp-0x1D4], 0
       jne      G_M000_IG08
       test     rsi, rsi
       jne      G_M000_IG08
       mov      rcx, gword ptr [rbx+0x40]
       cmp      byte  ptr [rcx+0xF5], 0
       je       G_M000_IG08
       xor      ecx, ecx
       mov      qword ptr [r15], rcx
       mov      qword ptr [r15+0x08], rcx
       cmp      byte  ptr [rdi+0x34], 0
       je       G_M000_IG08
       mov      rcx, gword ptr [rbx+0x08]
       mov      rcx, gword ptr [rcx+0x08]
       mov      ecx, dword ptr [rcx+0x08]
       mov      rdx, gword ptr [rbx+0x40]
       cmp      ecx, dword ptr [rdx+0xD8]
       jne      SHORT G_M000_IG08
       mov      rcx, rbx
       mov      edx, r12d
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:HasPreparedOmittedArguments(int):bool:this]
       test     eax, eax
       je       SHORT G_M000_IG08
       mov      rax, gword ptr [rbp+0x30]
       mov      rdx, gword ptr [rax+0xA0]
       mov      gword ptr [rbp-0x1E0], rdx
       cmp      byte  ptr [rdx], dl
       mov      rcx, rdx
       call     [Lokad.Lython.Runtime.ExecutionState:get_CanContinue():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG07
       mov      rcx, gword ptr [rbp-0x1E0]
       mov      rdx, r14
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
 
G_M000_IG07:                ;; offset=0x0160
       mov      gword ptr [rbp-0x188], rbx
       mov      bword ptr [rbp-0x180], r13
       mov      dword ptr [rbp-0x178], r12d
       lea      rdx, [rbp-0x188]
       mov      rcx, rbx
       mov      r8, r14
       mov      r9, r15
       call     [Lokad.Lython.Runtime.PyExecutableFunction:TryStartDirectIntegerReturn[Lokad.Lython.Runtime.LythonRuntime+DefaultIntegerOperands](Lokad.Lython.Runtime.LythonRuntime+DefaultIntegerOperands,Lokad.Lython.LythonSourceSpan,byref):bool:this]
       test     eax, eax
       jne      G_M000_IG15
 
G_M000_IG08:                ;; offset=0x0193
       vxorps   ymm0, ymm0, ymm0
       vmovdqu  ymmword ptr [rbp-0x138], ymm0
       vmovdqu  ymmword ptr [rbp-0x118], ymm0
       vmovdqu  ymmword ptr [rbp-0xF8], ymm0
       vmovdqu  ymmword ptr [rbp-0xD8], ymm0
       vmovdqu  ymmword ptr [rbp-0xB8], ymm0
       vmovdqu  ymmword ptr [rbp-0x98], ymm0
       vmovdqu  ymmword ptr [rbp-0x78], ymm0
       vmovdqu  ymmword ptr [rbp-0x58], ymm0
       mov      rcx, gword ptr [rbx+0x40]
       mov      r10d, dword ptr [rcx+0xE8]
       mov      dword ptr [rbp-0x18C], r10d
       cmp      r10d, 16
       ja       G_M000_IG17
       cmp      dword ptr [rbp-0x1D4], 0
       jne      G_M000_IG11
       mov      rcx, gword ptr [rbx+0x08]
       mov      rcx, gword ptr [rcx+0x08]
       mov      ecx, dword ptr [rcx+0x08]
       cmp      ecx, r10d
       ja       G_M000_IG17
       lea      rdx, bword ptr [rbp-0x138]
       mov      bword ptr [rbp-0x1B0], rdx
       mov      dword ptr [rbp-0x1A8], ecx
       xor      rcx, rcx
       mov      bword ptr [rbp-0x1C0], rcx
 
G_M000_IG09:                ;; offset=0x022B
       mov      dword ptr [rbp-0x1B8], ecx
       mov      rcx, gword ptr [rbp+0x30]
       mov      gword ptr [rsp+0x20], rcx
       xor      ecx, ecx
       mov      dword ptr [rsp+0x28], ecx
       mov      gword ptr [rsp+0x30], rsi
       mov      gword ptr [rsp+0x38], rdi
       mov      bword ptr [rbp-0x1D0], r13
       mov      dword ptr [rbp-0x1C8], r12d
       lea      rcx, [rbp-0x1B0]
       lea      rdx, [rbp-0x1C0]
       lea      r9, [rbp-0x1D0]
       mov      qword ptr [rsp+0x40], r9
       mov      r9, rbx
       mov      r8, r14
       call     [Lokad.Lython.Runtime.LythonRuntime:BindFunctionArgumentsInto(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.ReadOnlySpan`1[Lokad.Lython.Runtime.CallArgumentValue],Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.FunctionBindingPlan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,bool,System.Object,Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):int]
 
G_M000_IG10:                ;; offset=0x027E
       vxorps   ymm0, ymm0, ymm0
       vmovdqu  ymmword ptr [rbp-0x170], ymm0
       lea      rdx, bword ptr [rbp-0x138]
       mov      bword ptr [rbp-0x1B0], rdx
       mov      esi, dword ptr [rbp-0x18C]
       mov      dword ptr [rbp-0x1A8], esi
       movzx    rdx, byte  ptr [rbp+0x40]
       mov      dword ptr [rsp+0x20], edx
       mov      rsi, bword ptr [rbp+0x50]
       mov      bword ptr [rsp+0x28], rsi
       mov      rsi, bword ptr [rbp+0x58]
       mov      bword ptr [rsp+0x30], rsi
       mov      bword ptr [rsp+0x38], r15
       mov      rdi, bword ptr [rbp+0x68]
       mov      bword ptr [rsp+0x40], rdi
       lea      rdx, [rbp-0x150]
       mov      qword ptr [rsp+0x48], rdx
       lea      rdx, [rbp-0x1B0]
       lea      r8, [rbp-0x170]
       mov      rcx, rbx
       mov      r9, r14
       call     [Lokad.Lython.Runtime.PyExecutableFunction:StartInline(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.Nullable`1[Lokad.Lython.Runtime.BoundFunctionArguments],Lokad.Lython.LythonSourceSpan,bool,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,byref,byref,byref):this]
       jmp      SHORT G_M000_IG16
 
G_M000_IG11:                ;; offset=0x02F4
       xor      eax, eax
       test     rsi, rsi
       je       SHORT G_M000_IG12
       mov      eax, 1
       test     r10d, r10d
       je       G_M000_IG21
       mov      gword ptr [rbp-0x138], rsi
       xor      ecx, ecx
       mov      qword ptr [rbp-0x130], rcx
 
G_M000_IG12:                ;; offset=0x0319
       cmp      eax, r10d
       ja       SHORT G_M000_IG17
       lea      rcx, bword ptr [rbp-0x138]
       mov      edx, eax
       shl      rdx, 4
       add      rcx, rdx
       mov      edx, r10d
       sub      edx, eax
       cmp      r12d, edx
       ja       SHORT G_M000_IG20
 
G_M000_IG13:                ;; offset=0x0338
       mov      r8d, r12d
       shl      r8, 4
       cmp      r8, 0x4000
       ja       SHORT G_M000_IG19
 
G_M000_IG14:                ;; offset=0x0348
       mov      rdx, r13
       call     System.Buffer:BulkMoveWithWriteBarrierInternal(byref,byref,nuint)
       cmp      dword ptr [(reloc 0x7ffa18222aa8)], 0
       je       G_M000_IG10
       jmp      SHORT G_M000_IG18
 
G_M000_IG15:                ;; offset=0x035F
       mov      rsi, bword ptr [rbp+0x58]
       mov      byte  ptr [rsi], 0
       xor      rax, rax
       mov      rdi, bword ptr [rbp+0x68]
       mov      gword ptr [rdi], rax
 
G_M000_IG16:                ;; offset=0x036F
       add      rsp, 504
       pop      rbx
       pop      rsi
       pop      rdi
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG17:                ;; offset=0x0383
       call     [System.ThrowHelper:ThrowArgumentOutOfRangeException()]
       int3     
 
G_M000_IG18:                ;; offset=0x038A
       call     CORINFO_HELP_POLL_GC
       jmp      G_M000_IG10
 
G_M000_IG19:                ;; offset=0x0394
       mov      rdx, r13
       call     [System.Buffer:BulkMoveWithWriteBarrierBatch(byref,byref,nuint)]
       jmp      G_M000_IG10
 
G_M000_IG20:                ;; offset=0x03A2
       call     [System.ThrowHelper:ThrowArgumentException_DestinationTooShort()]
       int3     
 
G_M000_IG21:                ;; offset=0x03A9
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
; Total bytes of code 943

; Assembly listing for method Lokad.Lython.Runtime.PyExecutableFunction:TryReturnDefinition(Lokad.Lython.Frontend.ExecutableCreateFunction,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot,Lokad.Lython.LythonSourceSpan,byref):bool:this (FullOpts)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; FullOpts code
; optimized code
; rbp based frame
; fully interruptible
; No PGO data
; 0 inlinees with PGO data; 28 single block inlinees; 2 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       push     r14
       push     rdi
       push     rsi
       push     rbx
       sub      rsp, 80
       lea      rbp, [rsp+0x70]
       vxorps   xmm4, xmm4, xmm4
       vmovdqu  xmmword ptr [rbp-0x38], xmm4
       xor      eax, eax
       mov      qword ptr [rbp-0x28], rax
       mov      gword ptr [rbp+0x10], rcx
       mov      gword ptr [rbp+0x28], r9
       mov      rsi, rdx
       mov      rbx, r8
       mov      rdi, bword ptr [rbp+0x30]
 
G_M000_IG02:                ;; offset=0x0030
       xor      eax, eax
       mov      qword ptr [rdi], rax
       mov      qword ptr [rdi+0x08], rax
 
G_M000_IG03:                ;; offset=0x0039
       xor      r14, r14
       mov      rcx, rsi
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCreateFunction:get_InputCount():int:this]
       test     eax, eax
       je       SHORT G_M000_IG14
 
G_M000_IG04:                ;; offset=0x004B
       mov      rcx, gword ptr [rbp+0x10]
       lea      rdx, bword ptr [rcx+0x58]
       mov      r8, gword ptr [rdx]
       test     r8, r8
       je       SHORT G_M000_IG06
 
G_M000_IG05:                ;; offset=0x005B
       mov      rax, 0x7FF9B8900E00
       cmp      qword ptr [r8], rax
       je       SHORT G_M000_IG09
 
G_M000_IG06:                ;; offset=0x006A
       test     r8, r8
       je       SHORT G_M000_IG08
 
G_M000_IG07:                ;; offset=0x006F
       mov      rax, 0x7FF9B891EBB0
       xor      r10, r10
       cmp      qword ptr [r8], rax
       cmovne   r8, r10
 
G_M000_IG08:                ;; offset=0x0083
       test     r8, r8
       je       SHORT G_M000_IG10
 
G_M000_IG09:                ;; offset=0x0088
       xor      r14, r14
       jmp      SHORT G_M000_IG11
 
G_M000_IG10:                ;; offset=0x008D
       mov      r14, gword ptr [rdx]
 
G_M000_IG11:                ;; offset=0x0090
       test     r14, r14
       je       G_M000_IG23
       mov      rdx, gword ptr [rcx+0x40]
 
G_M000_IG12:                ;; offset=0x009D
       vmovdqu  xmm0, xmmword ptr [rbx]
       vmovdqu  xmmword ptr [rbp-0x38], xmm0
 
G_M000_IG13:                ;; offset=0x00A6
       mov      rcx, rdx
       lea      rdx, [rbp-0x38]
       lea      r8, [rbp-0x28]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryReadClosedDefinitionDefault(Lokad.Lython.Frontend.ExecutableCodeObject,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot,byref):bool]
       test     eax, eax
       je       G_M000_IG23
 
G_M000_IG14:                ;; offset=0x00BF
       mov      rcx, gword ptr [rbp+0x10]
       mov      rdx, gword ptr [rcx+0x28]
       mov      rcx, gword ptr [rdx+0xA0]
       mov      rdx, gword ptr [rbp+0x28]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.ExecutionState:EnterFunctionCall(Lokad.Lython.LythonSourceSpan):this]
       mov      rcx, gword ptr [rbp+0x10]
       mov      r8, gword ptr [rcx+0x28]
       mov      rdx, gword ptr [r8+0xA0]
       mov      rdx, gword ptr [rdx+0x148]
       mov      gword ptr [rbp-0x40], rdx
 
G_M000_IG15:                ;; offset=0x00F4
       test     r14, r14
       jne      SHORT G_M000_IG16
       mov      rdx, r8
       mov      r9, gword ptr [rcx+0x40]
       mov      r9, gword ptr [r9+0x98]
       cmp      dword ptr [r9+0x08], 0
       jbe      G_M000_IG19
       mov      r9, gword ptr [r9+0x10]
       mov      r8, rbx
       mov      rcx, rsi
       call     [Lokad.Lython.Runtime.LythonRuntime:CreateClosedFunctionDefinition(Lokad.Lython.Frontend.ExecutableCreateFunction,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.PyFunctionBase]
       mov      rbx, rax
       jmp      SHORT G_M000_IG17
 
G_M000_IG16:                ;; offset=0x0127
       mov      gword ptr [rsp+0x20], r14
       mov      rdx, gword ptr [rcx+0x40]
       mov      rcx, rsi
       mov      r9, qword ptr [rbp-0x28]
       call     [Lokad.Lython.Runtime.LythonRuntime:CreateClosedComputedDefinition(Lokad.Lython.Frontend.ExecutableCreateFunction,Lokad.Lython.Frontend.ExecutableCodeObject,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,long,System.Object):Lokad.Lython.Runtime.PyFunctionBase]
       mov      rbx, rax
 
G_M000_IG17:                ;; offset=0x0140
       mov      rcx, gword ptr [rbp+0x10]
       mov      rax, gword ptr [rcx+0x28]
       mov      rdx, gword ptr [rcx+0x40]
       mov      rdx, gword ptr [rdx+0x98]
       mov      r8d, dword ptr [rdx+0x08]
       lea      r10d, [r8-0x01]
       cmp      r10d, r8d
       jae      SHORT G_M000_IG19
       mov      r8d, r10d
       shl      r8, 5
       mov      rsi, gword ptr [rdx+r8+0x10]
       mov      r14, gword ptr [rax+0xA0]
       cmp      byte  ptr [r14], r14b
       mov      rcx, r14
       call     [Lokad.Lython.Runtime.ExecutionState:get_CanContinue():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG18
       mov      rcx, r14
       mov      rdx, rsi
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
 
G_M000_IG18:                ;; offset=0x018F
       mov      rcx, rdi
       mov      rdx, rbx
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       xor      ecx, ecx
       mov      qword ptr [rdi+0x08], rcx
       jmp      SHORT G_M000_IG20
 
G_M000_IG19:                ;; offset=0x01A2
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG20:                ;; offset=0x01A8
       mov      rcx, gword ptr [rbp+0x10]
       mov      rdx, gword ptr [rcx+0x28]
       mov      rsi, gword ptr [rdx+0xA0]
       mov      rbx, rsi
       lea      rcx, bword ptr [rbx+0x148]
       mov      rdx, gword ptr [rbp-0x40]
       call     CORINFO_HELP_ASSIGN_REF
       mov      rcx, rsi
       call     [Lokad.Lython.Runtime.ExecutionState:LeaveFunctionCall():this]
       nop      
 
G_M000_IG21:                ;; offset=0x01D4
       mov      eax, 1
 
G_M000_IG22:                ;; offset=0x01D9
       add      rsp, 80
       pop      rbx
       pop      rsi
       pop      rdi
       pop      r14
       pop      rbp
       ret      
 
G_M000_IG23:                ;; offset=0x01E4
       xor      eax, eax
 
G_M000_IG24:                ;; offset=0x01E6
       add      rsp, 80
       pop      rbx
       pop      rsi
       pop      rdi
       pop      r14
       pop      rbp
       ret      
 
G_M000_IG25:                ;; offset=0x01F1
       sub      rsp, 40
 
G_M000_IG26:                ;; offset=0x01F5
       mov      rbx, rcx
       cmp      gword ptr [rbp-0x40], 0
       je       SHORT G_M000_IG27
       mov      rcx, rbx
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntimeException:get_OriginalPythonException():Lokad.Lython.Runtime.PyException:this]
       cmp      rax, gword ptr [rbp-0x40]
       je       SHORT G_M000_IG27
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntimeException:get_PythonContext():Lokad.Lython.Runtime.PyException:this]
       test     rax, rax
       jne      SHORT G_M000_IG27
       mov      rcx, rbx
       mov      rdx, gword ptr [rbp-0x40]
       call     [Lokad.Lython.Runtime.LythonRuntimeException:set_PythonContext(Lokad.Lython.Runtime.PyException):this]
 
G_M000_IG27:                ;; offset=0x022B
       call     CORINFO_HELP_RETHROW
       int3     
 
G_M000_IG28:                ;; offset=0x0231
       sub      rsp, 40
 
G_M000_IG29:                ;; offset=0x0235
       mov      rcx, gword ptr [rbp+0x10]
       mov      rdx, gword ptr [rcx+0x28]
       mov      rbx, gword ptr [rdx+0xA0]
       lea      rcx, bword ptr [rbx+0x148]
       mov      rdx, gword ptr [rbp-0x40]
       call     CORINFO_HELP_ASSIGN_REF
       mov      rcx, gword ptr [rbp+0x10]
       mov      rax, gword ptr [rcx+0x28]
       mov      rcx, gword ptr [rax+0xA0]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.ExecutionState:LeaveFunctionCall():this]
       nop      
 
G_M000_IG30:                ;; offset=0x026C
       add      rsp, 40
       ret      
 
G_M000_IG31:                ;; offset=0x0271
       sub      rsp, 40
 
G_M000_IG32:                ;; offset=0x0275
       mov      rbx, rcx
       mov      rcx, gword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.PyFunctionBase:get_Closure():Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:this]
       mov      rsi, rax
       mov      rcx, gword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.PyFunctionBase:get_Name():System.String:this]
       mov      r8, rax
       mov      rdx, rsi
       mov      rcx, rbx
       mov      r9, gword ptr [rbp+0x28]
       call     [Lokad.Lython.Runtime.PyFunctionBinding:AnnotateException(Lokad.Lython.Runtime.LythonRuntimeException,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,System.String,Lokad.Lython.LythonSourceSpan)]
       call     CORINFO_HELP_RETHROW
       int3     
 
; Total bytes of code 680

