using System.Collections;
using System.Reflection;
using System.Security.Cryptography;
using System.Text.Json;
using Lokad.Lython;

const BindingFlags Flags = BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance;
using var catalog = JsonDocument.Parse(File.ReadAllBytes(args[0]));
var rows = new List<object>();
var shapeFields = new[]
{
    "Name", "EntryIndex", "FirstTemporarySlot", "OperandCapacity", "PatternStorageCount", "PatternStorageStart",
    "LastOwnedTemporarySlot", "ValueStorageCapacity", "NativePrefixEnd", "CanRunNativeInstructions",
    "RequiresLocalVariableMirroring", "UsesOnlyLexicalSlots", "LocalNames", "ClosureNames",
    "CapturedLocalSlots", "Instructions", "ExceptionRegions", "CallSites", "_operandReadSpans"
};

foreach (var item in catalog.RootElement.GetProperty("cases").EnumerateArray())
{
    var id = item.GetProperty("id").GetString();
    var budget = new LythonMemoryBudget();
    var objects = new List<object>();
    var seen = new HashSet<object>(ReferenceEqualityComparer.Instance);
    using (var script = new LythonEngine().Compile(item.GetProperty("source").GetString()!, budget))
    {
        if (!script.IsValid) throw new InvalidOperationException($"{id}: {string.Join("\n", script.Diagnostics)}");
        var executable = typeof(LythonCompiledScript).GetField("_executable", Flags)!.GetValue(script)!;
        Visit(Read(executable, "EntryPoint")!);
        rows.Add(new { id, retainedAdmission = budget.ReservedBytes, objects });
    }
    if (budget.ReservedBytes != 0) throw new InvalidOperationException($"{id}: Compilation retained allowance.");

    void Visit(object code)
    {
        if (!seen.Add(code)) return;
        objects.Add(shapeFields.ToDictionary(name => name, name => Encode(Read(code, name))));
        foreach (var constant in (object?[])Read(code, "Constants")!)
        {
            var child = constant?.GetType().Name switch
            {
                "ExecutableCreateClass" => Read(constant!, "Body"),
                "ExecutableCreateFunction" or "ExecutableCreateGeneratorExpression" => Read(constant!, "CodeObject"),
                _ => null,
            };
            if (child is not null) Visit(child);
        }
    }
}
var core = typeof(LythonEngine).Assembly.Location;
var hash = Convert.ToHexStringLower(SHA256.HashData(File.ReadAllBytes(core)));
File.WriteAllText(args[1], JsonSerializer.Serialize(new { coreSHA256 = hash, rows }, new JsonSerializerOptions { WriteIndented = true }));

static object? Read(object item, string name)
{
    var type = item.GetType();
    if (type.GetProperty(name, Flags) is { } property) return property.GetValue(item);
    return (type.GetField(name, Flags) ?? throw new MissingFieldException(type.Name, name)).GetValue(item);
}

static object? Encode(object? value)
{
    if (value is null or string or LythonSourceSpan) return value;
    var type = value.GetType();
    if (type.IsEnum) return value.ToString();
    if (type.IsPrimitive) return value;
    if (value is IEnumerable items) return items.Cast<object?>().Select(Encode).ToArray();
    if (type.Namespace == "Lokad.Lython.Frontend")
        return type.GetFields(Flags).OrderBy(field => field.Name, StringComparer.Ordinal)
            .ToDictionary(field => field.Name, field => Encode(field.GetValue(value)));
    return value.ToString();
}
