from pathlib import Path
import json, shutil, tarfile, hashlib, re
lab=Path(__file__).resolve().parent
out=lab.parents[3]/'benchmarks/results/2026-11-25-single-formatted-field-scan/confirmation'
quiet=lab/'comparison/quiet'
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
identity=read(quiet/'identity.json')
assert sha(lab/'scanner.patch')==identity['scannerDeltaSHA256']
assert sha(lab/'candidate.patch')==identity['sourcePatchSHA256']
assert read(lab/'tape-summary.json')['identical']
for name,num in (('Lokad.Lython.PublicApi.Tests-win11.log',351),('Lokad.Lython.PublicApi.Tests-ubuntu10.log',351),
                 ('Lokad.Lython.Tests-win11.log',25),('Lokad.Lython.Tests-ubuntu10.log',25)):
    assert re.search(rf'Failed:\s+0, Passed:\s+{num},', (lab/name).read_text(encoding='utf-8-sig'))
for name in ('identity.json','storage-custody.json'):
    shutil.copyfile(quiet/name,out/name)
for name in ('compile-allocation-summary.json','tape-summary.json'):
    shutil.copyfile(lab/name,out/name)
with tarfile.open(out/'procedures.tar.xz','w:xz') as bundle:
    for name in ('package-evidence.py','candidate.patch','scanner.patch','scanner-tests.patch','tests.patch',
       'prepare.py','prepare.log','quiet.py','bench-build.log','archive.py','test-ubuntu.sh',
       'compile-allocation.py','compile-allocation.log','reference-compiler-owner.json','candidate-compiler-owner.json',
       'Lokad.Lython.PublicApi.Tests-win11.log','Lokad.Lython.Tests-win11.log','Lokad.Lython.PublicApi.Tests-ubuntu10.log',
       'Lokad.Lython.Tests-ubuntu10.log','verified-raw-replicas.json','launch-console.log','retrieve.log',
       'comparison/reference-verify.json','comparison/candidate-verify.json','tape-summary.json','check-tape.py',
       'tape/Program.cs','tape/Tape.csproj','tape-candidate.json','tape-reference.json','tape.log',
       'recover-working-space.py','initial-image-custody.json'):
        bundle.add(lab/name,arcname=name,recursive=False)
