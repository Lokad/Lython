from pathlib import Path
import hashlib, json, os, shutil, subprocess
lab=Path(__file__).resolve().parent
donor=lab.with_name("terminal-backed-operand-layout-20261124")
read=lambda p: json.loads(p.read_text(encoding="utf-8-sig"))
sha=lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
quiet=lab/"comparison/quiet"
identity=read(quiet/"identity.json")
sdk=Path.home()/".dotnet11"
env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk))
subprocess.run([sdk/"dotnet.exe","build",lab/"tape/Tape.csproj","-c","Release","-o",lab/"tape-output"],
               env=env,cwd=lab.parents[3],check=True,timeout=40)
rows={}
for role in ("reference","candidate"):
    core=lab/role/"Lokad.Lython.dll"
    assert sha(core)==identity["coreSHA256"][role]
    image=lab/("tape-"+role)
    image.mkdir(exist_ok=True)
    for p in (lab/"tape-output").glob("Tape.*"): shutil.copyfile(p,image/p.name)
    shutil.copyfile(core,image/core.name)
    result=lab/("tape-"+role+".json")
    subprocess.run([sdk/"dotnet.exe",image/"Tape.dll",quiet/"representative.json",result],
                   cwd=lab.parents[3],env=env,check=True,timeout=25)
    raw=read(result)
    assert raw["coreSHA256"]==identity["coreSHA256"][role]
    rows[role]=raw["rows"]
for old,new in zip(rows["reference"],rows["candidate"],strict=True):
    for i,(before,after) in enumerate(zip(old["objects"],new["objects"],strict=True)):
        for key in before:
            if before[key]!=after[key]:
                raise AssertionError((old["id"],i,before["Name"],key,
                                      next(((j,x,y)for j,(x,y) in enumerate(zip(before[key],after[key])) if x!=y),None)
                                      if isinstance(before[key],list) and isinstance(after[key],list) else (before[key],after[key])))
    assert old==new,(old["id"],old["retainedAdmission"],new["retainedAdmission"])
summary=dict(sources=len(rows["reference"]),codeObjects=sum(len(r["objects"]) for r in rows["reference"]),
    instructions=sum(len(o["Instructions"]) for r in rows["reference"] for o in r["objects"]),
    identical=True,coreSHA256={r:identity["coreSHA256"][r] for r in rows})
(lab/"tape-summary.json").write_text(json.dumps(summary,indent=2)+"\n",encoding="utf-8",newline="\n")
print(summary)
