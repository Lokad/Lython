from pathlib import Path
import ast,hashlib,io,json,shutil,subprocess,tarfile
parent=Path(__file__).parent;r=parent/'b590';r.mkdir(exist_ok=False)
old=parent.parent/'native-closure-sequence-r243/b584'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
meta=json.loads((parent/'refined/diagnostic-identity.json').read_text(encoding='utf-8'))
for name,h in meta['sourceHashes'].items():assert sha(Path(name))==h,name
head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();assert head.startswith('8f8628a4')
name='dictionary-checkpoint-b590-20261111';unit='lython-b590-dictionary-checkpoint-20261111'
def replace(t):return t.replace('captured-checkpoint-b584-20261111',name).replace('lython-b584-captured-checkpoint-20261111',unit).replace('lython-b584-fixtures','lython-b590-fixtures').replace('captured-checkpoint-b584-launch.py','dictionary-checkpoint-b590-launch.py')
core=meta['images']['candidate']['Lokad.Lython.dll']
identity=json.loads((old/'identity.json').read_text(encoding='utf-8'))
identity.update(sourceRevision='Retained8f8628a4 dictionary integer storage, exact frozen refined R245 source/core with precommit metadata; all production hashes verified. 5092focused actual11/10 and4Python goldens pass. Full43081976930 separately pending. Six unchanged complete scripts versus stockCPython3.13.16; no single-change attribution from separate checkpoints. Original adverse source-pair data and report CPU debt preserved.',coreSHA256={'candidate':core,'candidate-control':core})
source=dict(retainedRevision=head,prototypeUncommitted=False,frozenPrecommitMetadata=True,sourceSHA256=meta['sourceHashes'],coreSHA256=core,qualification='Focused5092actual11/10+4Python goldens; full43081976930pending independently. Current snapshot matches retained runtime exactly.')
(r/'source-identity.json').write_text(json.dumps(source,indent=2)+'\n',encoding='utf-8')
shutil.copyfile(old/'representative.json',r/'representative.json')
identity['catalogSHA256']=sha(r/'representative.json')
(r/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8')
(r/'prior-BENCHMARKS.md').write_bytes(subprocess.check_output(['git','show','HEAD:docs/BENCHMARKS.md']))
for filename in ['collect.py','archive-owned.py','run.sh','remote-launch.py','launch.py','retrieve.py','summarize.py']:
 t=replace((old/filename).read_text(encoding='utf-8')).replace('B584','B590')
 if filename=='collect.py':t=t.replace('R243 retained6904093e','R245 retained8f8628a4')
 if filename=='remote-launch.py':
  t=t.replace("source=base/'captured-sequence-b583-20261111/candidate'","source=base/'dictionary-values-b589-20261111/candidate'")
  start=t.index('protected=');end=t.index("with(base/'comparison-vm.lock')",start)
  t=t[:start]+"protected={source/'Lokad.Lython.dll':config['identity']['coreSHA256']['candidate']}\n"+t[end:]
 (r/filename).write_text(t,encoding='utf-8',newline='\n')
 if filename.endswith('.py')and filename!='remote-launch.py':ast.parse(t)
buf=io.BytesIO()
with tarfile.open(fileobj=buf,mode='w:gz')as archive:
 for filename in ['collect.py','archive-owned.py','run.sh','identity.json','source-identity.json','representative.json']:archive.add(r/filename,arcname=filename)
(r/'payload.tgz').write_bytes(buf.getvalue())
canonical=Path('benchmarks/results/2026-11-11-dictionary-integer-storage/initial/quiet/observations.tgz');data=canonical.read_bytes()
assert data==subprocess.check_output(['git','show','HEAD:'+canonical.as_posix()])
retire=[dict(kind='exact',knownPath='dictionary-values-b588-20261111/observations.tgz',bytes=len(data),sha256=hashlib.sha256(data).hexdigest(),canonicalStorage=canonical.as_posix(),canonicalCommit=head,reason='Terminal initial R245 archive duplicate, exact canonical committed Git bytes verified; preserve current refined core and all original observations. Fresh absolute path/UID/inode/all-alias proof before retirement.')]
config=dict(root='/home/lokad/lython-bench-checks/'+name,unit=unit,payloadBytes=(r/'payload.tgz').stat().st_size,payloadSHA256=sha(r/'payload.tgz'),requiredFreeBytes=252*1024*1024+(r/'payload.tgz').stat().st_size+1024*1024,retire=retire,identity=identity)
(r/'config.json').write_text(json.dumps(config,indent=2)+'\n',encoding='utf-8')
remote=(r/'remote-launch.py').read_text(encoding='utf-8').replace('config=CONFIG','config='+repr(config)).replace('inventoryOnly=INVENTORY_ONLY','inventoryOnly=True');ast.parse(remote)
assert "jobs=18,ownerSeconds=570"in remote and'RuntimeMaxSec=570'in remote
assert "len(raw['jobs'])==18"in(r/'archive-owned.py').read_text(encoding='utf-8')
print('Prepared existing18-job checkpoint for retained8f8628a4, fixed worker/adapter/protocol. Owner570s, observe630s, no VM mutation. Only one canonical archive duplicate proposed for retirement.')
