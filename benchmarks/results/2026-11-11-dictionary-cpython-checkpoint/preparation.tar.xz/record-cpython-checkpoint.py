from pathlib import Path
import hashlib,json,shutil,tarfile
p=Path(__file__).parent;r=p/'b590';out=Path('benchmarks/results/2026-11-11-dictionary-cpython-checkpoint')
assert not out.exists()
receipt=json.loads((r/'archive-receipt.json').read_text(encoding='utf-8'));summary=json.loads((r/'summary.json').read_text(encoding='utf-8'))
assert receipt['complete']and receipt['jobs']==18 and receipt['allWorkersJoined']and receipt['guestFixturesRemoved']and receipt['quietBeforeAndAfter']and receipt['archivedAndVerifiedUnderLease']
assert hashlib.sha256((r/'observations.tgz').read_bytes()).hexdigest()==receipt['archiveSHA256']
core=summary['coreSHA256']['candidate']
with tarfile.open(r/'observations.tgz')as archive:
 assert hashlib.sha256(archive.extractfile('current-core.dll').read()).hexdigest()==core
 raw=json.loads(archive.extractfile('confirmation/confirmation.json').read())
 assert raw['complete']and len(raw['jobs'])==18
 for job in raw['jobs']:
  assert job['workersJoinedAndFixturesRemoved']
  for name,identity in job['identities'].items():
   if name.startswith('candidate'):assert next(v['sha256']for v in identity['libraries']if Path(v['path']).name=='Lokad.Lython.dll').lower()==core
out.mkdir()
for name in ['prior-BENCHMARKS.md','summary.json','identity.json','source-identity.json','archive-receipt.json','observations.tgz','terminal-status.json','inventory.json','config.json','observe-not-before.json','launch.log']:
 shutil.copyfile(r/name,out/name)
with tarfile.open(out/'preparation.tar.xz','w:xz')as archive:
 for f in [*r.glob('*.py'),r/'run.sh',p/'prepare-cpython-checkpoint.py',p/'record-cpython-checkpoint.py']:archive.add(f,arcname=f.name)
mapping={'scripts.text-summary-helpers.nonlocal-counter.large':'Text / captured helper + counter','scripts.text-summary-helpers.large':'Text summary/helpers','scripts.csv-validated-records.large':'CSV validation/helper calls','scripts.json-summary-helpers.large':'JSON-lines/helpers','scripts.report-render.large':'JSON-to-Markdown report','scripts.file-search.large':'File search / keyword-default helper'}
rows={(mapping[j['case']],j['lane']):j for j in summary['timing']}
def times(v):
 multiplier,unit,digits=(1,'ms',3)if max(v)>=.5 else(1000,'µs',2)
 return f'{min(v)*multiplier:.{digits}f}–{max(v)*multiplier:.{digits}f} {unit}'
guide=Path('docs/BENCHMARKS.md');text=guide.read_text(encoding='utf-8');lane='compile-run';count=0;lines=[]
for line in text.splitlines():
 if line=='## Warm execution, compilation and startup':lane='warm'
 if line.startswith('Compilation alone includes'):lane='compile'
 fields=line.split('|')
 if len(fields)>=7 and fields[1].strip()in mapping.values():
  row=rows[(fields[1].strip(),lane)];start=3 if lane=='compile-run' else 2
  fields[start]=' '+times(row['timeRangeMilliseconds'])+' '
  fields[start+1]=' '+times(row['pythonTimeRangeMilliseconds'])+' '
  fields[start+2]=f" {min(row['ratioRange']):.2f}–{max(row['ratioRange']):.2f}× "
  fields[start+3]=' `8f8628a4` '
  fields[start+4]=f" {row['status']}; L{row['controlPercent']:.2f}%, P{row['pythonControlPercent']:.2f}% / {max(row['iqrPercent'].values()):.2f}% "
  line='|'.join(fields);count+=1
 lines.append(line)
assert count==18,count
text='\n'.join(lines)+'\n'
start=text.index('**Measured source:**');end=text.index('The captured-helper variant',start)
text=text[:start]+f'''**Measured source:** retained `8f8628a4`, 2026-11-11, frozen refined core
`{core[:8]}` with precommit metadata. All production source hashes match.
The six refreshed scripts use stock CPython 3.13.16 on the same VM. Focused
actual .NET 11/10 checks pass; exact-source Windows/Ubuntu, original stress and
installed Release-consumer qualification is separately pending. Earlier rows remain
historical: `4aa` = qualified `4aa2d46d` (patch, 2026-11-11), `ee44` = `ee448715`
(config/original search, 2026-11-10), `6f76` = `6f76f99d` (CSV summary, 2026-11-08),
`4598` = `459813a3` (manifest, 2026-11-09). They do not describe current HEAD.

The [six-script checkpoint](../benchmarks/results/2026-11-11-dictionary-cpython-checkpoint/README.md)
refreshes compilation, warm execution and compile-to-result with existing workers
and unchanged sources/fixtures. All identity/output/ownership/quiet/join/archive
gates pass. Its [prior guide](../benchmarks/results/2026-11-11-dictionary-cpython-checkpoint/prior-BENCHMARKS.md)
preserves the replaced `6904093e` measurements and earlier links, including adverse
and inconclusive cases. Separate checkpoints cannot attribute a gain to one change.

'''+text[end:]
start=text.index('Actual .NET 11 RC3');end=text.index('Identical scripts and fixtures',start)
text=text[:start]+f'''Actual .NET 11 RC3 and isolated CPython 3.13.16 use ordinary GC/tiering;
five-second warmups per role/job and seven rotated 150 ms rounds. Six current
scripts use core `{core[:8]}` (retained `8f8628a4` production sources), fixed common
worker `fec79afd` and optional adapter 0.4. Other rows keep their recorded images.
These source-labelled observations do not qualify a newer regex producer.

'''+text[end:]
start=text.index('Captured text remains about twice');end=text.index('Original literal-prefix search and config',start)
text=text[:start]+'''Captured text retains a substantial warm gap at 1.77–1.84× CPython;
keyword-default search is 1.54–1.57×. Ordinary text is 1.06–1.11×, CSV 1.04–1.05×
and JSON-lines 0.84–0.87×. Captured/ordinary text controls are variable. Report
1.28–1.35× is variable and overlaps the earlier checkpoint's range; no regression
or neutrality follows from that overlap. Search compile-to-result 1.45–1.60× has
4.7% controls on both engines. All original measurements remain in the prior guide.
Separate asynchronous report source-pair CPU debt remains unresolved; these
synchronous external comparisons do not settle it. Allocation reduction does not
establish CPU gain. Compilation and warm medians are independent.

'''+text[end:]
guide.write_text(text,encoding='utf-8')
print('Updated18 source-labelled timing rows; prior guide, all original measurements and raw identities preserved. Full delivery remains separate/pending.')
