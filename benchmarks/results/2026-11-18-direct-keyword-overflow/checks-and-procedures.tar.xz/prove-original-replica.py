from pathlib import Path
import gzip
import hashlib
import json
import subprocess

lab = Path(__file__).resolve().parent
canonical = "benchmarks/results/2026-11-18-direct-keyword-overflow-screen/confirmation/candidate-core.dll.gz"
archive = subprocess.check_output(["git", "show", f"origin/master:{canonical}"])
assert archive == Path(canonical).read_bytes()
image = gzip.decompress(archive)
sha = lambda value: hashlib.sha256(value).hexdigest()
relative = "keyword-forwarding-b990-20261118/candidate/Lokad.Lython.dll"
identity = json.loads((lab / "quiet/identity.json").read_text(encoding="utf-8"))
assert sha(image) == identity["coreSHA256"]["candidate"]
proof = dict(paths=[relative], canonical=canonical, canonicalSHA256=sha(archive), sha256=sha(image),
             bytes=len(image), links=1, kind="exact committed B990 prototype core replica", committedBlobVerified=True)
remote = r'''
from pathlib import Path
import fcntl,hashlib,json,os,shutil,stat,subprocess
proof=PROOF
root=Path('/home/lokad/lython-bench-checks').resolve()
assert root==Path('/home/lokad/lython-bench-checks')
with (root/'comparison-vm.lock').open('a') as lease:
    fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
    assert not subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record|[p]ython3.13.*cpython-worker.py'],capture_output=True).stdout
    assert not any(os.path.ismount(p) for p in root.glob('*/guest-fixtures'))
    path=root/proof['paths'][0]
    v=path.lstat()
    assert path.resolve()==path and stat.S_ISREG(v.st_mode) and v.st_uid==os.getuid()
    assert v.st_size==proof['bytes'] and v.st_nlink==proof['links']
    assert hashlib.sha256(path.read_bytes()).hexdigest()==proof['sha256']
    print(json.dumps(dict(freeBytes=shutil.disk_usage(root).free,replicas=[proof])))
'''.replace("PROOF", repr(proof))
ssh = ["C:/Windows/System32/OpenSSH/ssh.exe", "-i", str(Path.home() / ".ssh/id_lython-bench.pem"),
       "-o", "BatchMode=yes", "-o", "ConnectTimeout=15", "lokad@20.166.121.73"]
result = subprocess.run(ssh + ["python3 -"], input=remote.encode("utf-8"), capture_output=True, timeout=40, check=True)
space = json.loads(result.stdout)
(lab / "quiet-space-corrected.json").write_text(json.dumps(space, indent=2) + "\n", encoding="utf-8")
print(space["freeBytes"], "bytes free and exact B990 prototype present")
