from pathlib import Path
import hashlib
import json
import os
import shutil
import subprocess

lab = Path(__file__).resolve().parent
repo = Path.cwd()
work = repo / ".git/agent-worktrees/direct-keyword-overflow-r565"
catalog = lab / "catalog.json"
load = lambda path: json.loads(path.read_text(encoding="utf-8-sig"))
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
sdk = Path.home() / ".dotnet11"
dotnet = sdk / "dotnet.exe"
python = Path("C:/Python313/python.exe")
env = dict(os.environ, DOTNET_ROOT=str(sdk), DOTNET_ROOT_X64=str(sdk),
           PATH=str(sdk) + os.pathsep + os.environ["PATH"])
core = "Lokad.Lython.dll"
worker = "Lokad.Lython.Benchmarks.dll"
old = load(lab / "frozen-identity.json")
assert old["casesSHA256"] == sha(catalog)
src = work / "src/Lokad.Lython/bin/Release/net11.0" / core
test = work / "tests/Lokad.Lython.Tests/bin/Release/net11.0" / core
assert sha(src) == sha(test) and sha(src) != old["images"]["candidate"][core]
identities = {}
for role, files in old["images"].items():
    base = lab / "frozen" / role
    assert {name: sha(base / name) for name in files} == files
    image = lab / "final-frozen" / role
    image.mkdir(parents=True)
    for name in files:
        source = src if role == "candidate" and name == core else base / name
        shutil.copyfile(source, image / name)
    for artifact in base.glob("ValidatedAllocation.*"):
        shutil.copyfile(artifact, image / artifact.name)
    identities[role] = {name: sha(image / name) for name in files}
    with (lab / f"final-{role}-verify.log").open("w", encoding="utf-8") as log:
        subprocess.run([dotnet, image / worker, "--compare", "verify", "--catalog", catalog, "--dotnet", dotnet,
                        "--python", python, "--python-worker", repo / "benchmarks/cpython-worker.py",
                        "--out", lab / f"final-{role}-verify.json"], env=env, cwd=repo, stdout=log,
                       stderr=subprocess.STDOUT, check=True, timeout=45)
    subprocess.run([dotnet, image / "ValidatedAllocation.dll", image, catalog, lab / f"final-{role}-allocation.json"],
                   env=env, cwd=repo, check=True, timeout=45)
    assert {name: sha(image / name) for name in files} == identities[role]
image_manifest = dict(old, images=identities)
(lab / "final-frozen-identity.json").write_text(json.dumps(image_manifest, indent=2) + "\n", encoding="utf-8")
(lab / "final-source.patch").write_bytes(subprocess.check_output(
    ["git", "-C", work, "diff", "--binary", "25d3005f8", "--", "src", "tests"]))
print("Verified corrected frozen images", {role: files[core] for role, files in identities.items()})
