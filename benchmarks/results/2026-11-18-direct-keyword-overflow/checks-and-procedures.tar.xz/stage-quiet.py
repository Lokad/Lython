from pathlib import Path
import ast
import hashlib
import json
import shutil
import sys
import tarfile

lab = Path(__file__).resolve().parent
donor = lab.parent / "lexical-binding-order-r563"
previous = donor / "quiet"
corrected = "--corrected" in sys.argv
quiet_name = "quiet-corrected" if corrected else "quiet"
quiet = lab / quiet_name
quiet.mkdir(exist_ok=False)
def read(path):
    return path.read_text(encoding="utf-8")

def load(path):
    return json.loads(read(path))

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def write(path, source):
    if path.suffix == ".py":
        ast.parse(source)
    path.write_text(source, encoding="utf-8", newline="\n")

def save(path, data):
    write(path, json.dumps(data, ensure_ascii=False, indent=2) + "\n")

prior = load((lab / "quiet" if corrected else previous) / "config.json")
source_role = "reference" if corrected else "candidate"
screen = load(lab / ("final-frozen-identity.json" if corrected else "frozen-identity.json"))
space = load(lab / ("quiet-space-corrected.json" if corrected else "quiet-space.json"))
catalog = lab / "catalog.json"
images = screen["images"]
donor_image = prior["identity"]["imageFiles"][source_role]
core = "Lokad.Lython.dll"
assert screen["casesSHA256"] == sha(catalog)
for role, files in images.items():
    assert len(files) == 32 and files == donor_image | {core: files[core]}
    frozen = lab / ("final-frozen" if corrected else "frozen") / role
    assert {name: sha(frozen / name) for name in files} == files
    verified = load(lab / f"{'final-' if corrected else ''}{role}-verify.json")
    assert verified["state"] == "Completed" and verified["catalogSha256"] == sha(catalog)
    (quiet / role).mkdir()
    if not corrected or role == "candidate":
        shutil.copyfile(frozen / core, quiet / role / core)

target = "scripts.report-forwarding.keywords"
control = "calls.positional.large"
jobs = [(target, "warm"), (control, "warm"), (target, "compile-run"), (target, "compile")]
if corrected:
    jobs = jobs[:2]
identity = dict(sourceRevision="25d3005f8 versus " + ("R565 with contextual hashing" if corrected else "the archived R565 prototype"),
                purpose="R565 keyword forwarding paired elapsed and process CPU confirmation",
                imageFiles=images, normalAdapterPin="0.4.0", catalogSHA256=sha(catalog),
                coreSHA256={label: images[role][core] for role in images for label in [role, role + "-control"]})
root = "/home/lokad/lython-bench-checks/keyword-forwarding-b990-20261118"
unit = "lython-b990-keyword-forwarding-20261118"
if corrected:
    root = "/home/lokad/lython-bench-checks/keyword-hash-b991-20261118"
    unit = "lython-b991-keyword-hash-20261118"
job_count = len(jobs)
runner = read(previous / "collect.py").replace("Lexical binding order source pair", "Keyword forwarding source pair")
start = runner.index("\njobs = ")
end = runner.index("\nassert len(jobs)", start)
runner = (runner[:start] + "\njobs = " + repr(jobs) + runner[end:]).replace("len(jobs)==5", f"len(jobs)=={job_count}")
write(quiet / "collect.py", runner)
write(quiet / "archive-owned.py", read(previous / "archive-owned.py").replace("==5", f"=={job_count}").replace("jobs=5", f"jobs={job_count}"))
write(quiet / "run.sh", read(previous / "run.sh").replace(load(previous / "config.json")["root"], root))
assert b"\r" not in (quiet / "run.sh").read_bytes()
save(quiet / "identity.json", identity)
shutil.copyfile(catalog, quiet / "representative.json")
names = ["collect.py", "archive-owned.py", "run.sh", "identity.json", "representative.json",
         f"candidate/{core}"] + ([] if corrected else [f"reference/{core}"])
payload = quiet / "payload.tgz"
with tarfile.open(payload, "w:gz") as archive:
    for name in names:
        archive.add(quiet / name, arcname=name)
unpacked = sum((quiet / name).stat().st_size for name in names)
need = 254 * 1024 * 1024 + unpacked + 512 * 1024
available = space["freeBytes"]
selected = []
for candidate in sorted(space["replicas"], key=lambda item: -item["bytes"]):
    if available >= need:
        break
    selected.append(candidate)
    available += candidate["bytes"]
assert available >= need, (available, need, space["replicas"])
config = dict(root=root, unit=unit, source=prior["root"], sourceRole=source_role, sourceFiles=donor_image,
              sourceCatalogSHA256=prior["catalogSHA256"], catalogSHA256=sha(catalog), identity=identity,
              retireGroups=selected, payloadBytes=payload.stat().st_size, payloadSHA256=sha(payload), unpackedBytes=unpacked)
save(quiet / "config.json", config)
launcher = read(previous / "remote-launch.py")
start = launcher.index("\nc=") + 1
end = launcher.index("\nb=Path(")
launcher = launcher[:start] + "c=" + repr(config) + launcher[end:]
launcher = launcher.replace("lython-b989-fixtures", "lython-b991-fixtures" if corrected else "lython-b990-fixtures")
write(quiet / "remote-launch.py", launcher)
retrieve = read(previous / "retrieve.py").replace("==5", f"=={job_count}").replace("Lexical binding order source pair", "Keyword forwarding source pair")
write(quiet / "retrieve.py", retrieve)
launch = read(donor / "launch.py").replace("Lexical binding order source pair", "Keyword forwarding source pair")
hold = 125 if corrected else 215
launch = launch.replace("seconds=255", f"seconds={hold}").replace("before255seconds", f"before {hold} seconds")
launch = launch.replace("parent/'quiet'", f"parent/'{quiet_name}'")
write(lab / f"launch-{quiet_name}.py", launch)
summarize = read(donor / "summarize.py").replace("len(raw['jobs'])==5", f"len(raw['jobs'])=={job_count}")
summarize = summarize.replace("r/'summary.json'", "r/'quiet-summary.json'").replace(
    "archivalOnlyRecovery=None", "archivalOnlyRecovery=json.loads((r/'quiet/retrieved/retirement-receipt.json').read_text(encoding='utf-8'))")
if corrected:
    summarize = summarize.replace("quiet/retrieved", f"{quiet_name}/retrieved").replace("quiet-summary.json", "corrected-quiet-summary.json")
    for prefix in ("reference-", "candidate-"):
        summarize = summarize.replace(f"/'{prefix}allocation.json'", f"/'final-{prefix}allocation.json'")
    summarize = summarize.replace("r/'allocation-summary.json'", "r/'final-allocation-summary.json'")
write(lab / f"summarize-{quiet_name}.py", summarize)
print("Staged", payload.stat().st_size, "bytes for the quiet pair, with", len(selected), "verified old replicas to reclaim")
