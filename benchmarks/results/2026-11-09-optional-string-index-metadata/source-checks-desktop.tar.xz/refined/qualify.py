from pathlib import Path
import hashlib,json,os,re,subprocess
base=Path(__file__).parent.parent;r=Path(__file__).parent;env=os.environ.copy();env['DOTNET_ROOT']='C:/Users/JoannesVermorel/.dotnet11';env['PATH']=env['DOTNET_ROOT']+os.pathsep+'C:/Python313'+os.pathsep+env['PATH']
dotnet=env['DOTNET_ROOT']+'/dotnet.exe';checks={}
def run(label,args):
    with (r/(label+'.log')).open('w',encoding='utf-8')as log:
        done=subprocess.run([dotnet,*args],env=env,stdout=log,stderr=subprocess.STDOUT)
    text=(r/(label+'.log')).read_text(encoding='utf-8');print(label,done.returncode,text[-450:],flush=True)
    assert done.returncode==0,label
    m=re.search(r'Passed:\s+(\d+)',text)
    if m:checks[label]=int(m[1])
    return text
for framework in ['net11.0','net10.0']:
    if True:
        run('focused-internal-'+framework,['test','tests/Lokad.Lython.Tests','-c','Release','-f',framework,'--no-restore','--filter','Category!=Stress&(FullyQualifiedName~PyString|FullyQualifiedName~StringStorage|FullyQualifiedName~StringIndexCache|FullyQualifiedName~StringWindow|FullyQualifiedName~TerminalString|FullyQualifiedName~StringHash|FullyQualifiedName~NativeTextKey)'])
    run('model-current-'+framework,['run','--project',str(base/'Shape.csproj'),'-c','Release','-f',framework,'--',f'src/Lokad.Lython/bin/Release/{framework}/Lokad.Lython.dll'])
    run('focused-public-'+framework,['test','tests/Lokad.Lython.PublicApi.Tests','-c','Release','-f',framework,'--no-restore','--filter','Category!=Stress&(FullyQualifiedName~String|FullyQualifiedName~Utf8|FullyQualifiedName~Text|FullyQualifiedName~Regex|FullyQualifiedName~Csv|FullyQualifiedName~Json)'])
(r/'qualification.json').write_text(json.dumps(dict(checks=checks,net11InternalInitial=42,stressExcluded=True,limitations='Focused current string/storage/Unicode/CSV/JSON/regex checks only; full platform/stress/package batches at next coherent boundary.'),indent=2)+'\n',encoding='utf-8')
