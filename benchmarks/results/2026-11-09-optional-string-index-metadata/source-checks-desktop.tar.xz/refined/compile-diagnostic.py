from pathlib import Path
import json,os,statistics,subprocess
r=Path(__file__).parent;base=r.parent.parent
folder=r/'compile';folder.mkdir();witness=folder/'hash-witness.json'
witness.write_bytes((r/'warm-sync/hash-witness.json').read_bytes())
env=os.environ.copy();env['DOTNET_ROOT']='C:/Users/JoannesVermorel/.dotnet11';env['PATH']=env['DOTNET_ROOT']+os.pathsep+env['PATH']
with (folder/'measurements.json').open('w',encoding='utf-8')as out,(folder/'stderr.txt').open('w',encoding='utf-8')as err:
    done=subprocess.run([env['DOTNET_ROOT']+'/dotnet.exe',str(base/'bulk-whitespace-r157/tool/out/complete-jobs.dll'),str(r/'images/before/Lokad.Lython.Benchmarks.dll'),str(r/'images/candidate/Lokad.Lython.Benchmarks.dll'),str(r/'catalog.json'),str(witness),'reverse','compile','sync'],env=env,stdout=out,stderr=err,timeout=120)
assert done.returncode==0,(folder/'stderr.txt').read_text(encoding='utf-8')[-1800:]
data=json.loads((folder/'measurements.json').read_text(encoding='utf-8'));assert all(data[k]for k in ['allGoldensPassed','allBalancesZero','ownedFixturesRemoved','imageIsolationVerified'])
summary=[]
for case in data['observations']:
    values={role:statistics.median(s['allocatedBytes']/s['jobs']for s in case['samples']if s['image']==role)for role in ['before','before-control','candidate']}
    summary.append(dict(case=case['caseId'],allocatedBytes=values,changePercent=[100*(values['candidate']/values[role]-1)for role in ['before','before-control']],limits='Compilation construction/disposal only; short desktop batches do not qualify compile CPU.'))
(r/'compile-allocation.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8');print(summary,flush=True)
