from pathlib import Path
import subprocess
r=Path(__file__).parent
code='''from pathlib import Path
import json,subprocess
r=Path('/home/lokad/lython-bench-checks/string-index-storage-b518-20261109')
print(subprocess.check_output(['journalctl','-u','lython-b518-string-index-storage-20261109.service','--no-pager','-n','65','-o','cat'],text=True))
p=r/'confirmation/confirmation.json'
if p.exists():
 v=json.loads(p.read_text());print('Partial jobs',len(v['jobs']),[(j['case'],j['lane'])for j in v['jobs']])
print('Owned RAM entries',[p.name for p in (r/'guest-fixtures').iterdir()]if(r/'guest-fixtures').exists()else[])
'''
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
done=subprocess.run(ssh+['python3 -'],input=code,text=True,encoding='utf-8',capture_output=True,timeout=45)
(r/'collection-failure.log').write_text(done.stdout+'\n'+done.stderr,encoding='utf-8');print(done.stdout+done.stderr)
assert done.returncode==0
