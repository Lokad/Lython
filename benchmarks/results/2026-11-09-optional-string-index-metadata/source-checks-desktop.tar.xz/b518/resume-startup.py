from pathlib import Path
from datetime import datetime,timedelta,timezone
import hashlib,json,subprocess
r=Path(__file__).parent;initial=(r/'identity.json').read_bytes();identity=json.loads(initial)
failure=json.loads((r/'auxiliary-startup-failure.json').read_text(encoding='utf-8'))
assert not failure['workers'] and not failure['fixtureExists'] and 'LoadState=not-found'in failure['service']
assert all(m['name'].endswith(('.pdb','.exe'))for m in failure['mismatches'])
identity['unusedDesktopFiles']={n:h for n,h in identity['auxiliaryFiles'].items()if n.endswith(('.pdb','.exe'))}
identity['auxiliaryFiles']={n:h for n,h in identity['auxiliaryFiles'].items()if not n.endswith(('.pdb','.exe'))}
identity['startupCorrection']='The Linux command is dotnet worker.dll. Desktop Windows apphost/symbols are not executed or used for profiling; all managed DLLs/deps/runtimeconfigs remain exact. Original failed startup/identity retained; no guest work ran before correction.'
remote='''from pathlib import Path
import ast,fcntl,hashlib,json,shutil,subprocess
base=Path('/home/lokad/lython-bench-checks');root=base/'string-index-storage-b518-20261109'
originalSHA=ORIGINAL
identity=IDENTITY
failure=FAILURE
with(base/'comparison-vm.lock').open('a')as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 state=subprocess.check_output(['systemctl','show','lython-b518-string-index-storage-20261109.service','--property=LoadState,ActiveState,MainPID'],text=True)
 assert 'LoadState=not-found'in state and not(root/'guest-fixtures').exists()
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record'],capture_output=True).returncode==1
 assert hashlib.sha256((root/'identity.json').read_bytes()).hexdigest()==originalSHA
 for role in ['reference','candidate']:
  assert hashlib.sha256((root/role/'Lokad.Lython.dll').read_bytes()).hexdigest()==identity['coreSHA256'][role]
  for name,expected in identity['auxiliaryFiles'].items():assert hashlib.sha256((root/role/name).read_bytes()).hexdigest()==expected,name
 assert hashlib.sha256((root/'representative.json').read_bytes()).hexdigest()==identity['catalogSHA256']
 assert shutil.disk_usage(base).free>252*1024*1024
 with(root/'identity-initial.json').open('xb')as f:f.write((root/'identity.json').read_bytes())
 (root/'identity.json').write_text(json.dumps(identity,indent=2)+'\\n')
 (root/'auxiliary-startup-failure.json').write_text(json.dumps(failure,indent=2)+'\\n')
 record=dict(noPreviousWorkers=True,noPreviousService=True,allManagedAuxiliariesExact=True,unusedDesktopFiles=identity['unusedDesktopFiles'],reason=identity['startupCorrection'])
 (root/'startup-resume.json').write_text(json.dumps(record,indent=2)+'\\n')
 p=root/'archive-owned.py';source=p.read_text();source=source.replace("'final-source.json']","'final-source.json','identity-initial.json','auxiliary-startup-failure.json','startup-resume.json']");ast.parse(source);p.write_text(source)
 for name in ['collect.py','archive-owned.py']:ast.parse((root/name).read_text())
 subprocess.run(['/bin/sh','-n',str(root/'run.sh')],check=True)
 fixture=root/'guest-fixtures';fixture.mkdir();subprocess.run(['sudo','-n','mount','-t','tmpfs','-o','size=128m,mode=0700,uid=lokad,gid=lokad','lython-b518-fixtures',str(fixture)],check=True)
 try:
  setup=dict(freeBytes=shutil.disk_usage(base).free,ownerSeconds=210,stopSeconds=30,marginSeconds=30,osFreeFloorMiB=240,evidenceHeadroomMiB=12,startupCorrection=record)
  (root/'setup.json').write_text(json.dumps(setup,indent=2)+'\\n');print(json.dumps(setup),flush=True)
  fcntl.flock(lease,fcntl.LOCK_UN)
  subprocess.run(['sudo','-n','systemd-run','--unit=lython-b518-string-index-storage-20261109','--property=User=lokad','--property=WorkingDirectory='+str(root),'--property=RuntimeMaxSec=210','--property=TimeoutStopSec=30','--property=KillMode=control-group','/bin/sh',str(root/'run.sh')],check=True)
 except BaseException:
  subprocess.run(['sudo','-n','umount',str(fixture)],check=True);fixture.rmdir();raise
'''.replace('ORIGINAL',repr(hashlib.sha256(initial).hexdigest())).replace('IDENTITY',repr(identity)).replace('FAILURE',repr(failure))
compile(remote,'startup-resume','exec');(r/'resume-startup-command.py').write_text(remote,encoding='utf-8')
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
done=subprocess.run(ssh+['python3 -'],input=remote,text=True,encoding='utf-8',capture_output=True)
(r/'resume-startup.log').write_text(done.stdout+'\n'+done.stderr,encoding='utf-8');print(done.stdout+done.stderr,flush=True)
assert done.returncode==0
(r/'identity-initial.json').write_bytes(initial);(r/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8')
now=datetime.now(timezone.utc);p=r/'observe-not-before.json';assert not p.exists()
p.write_text(json.dumps(dict(acknowledgedUTC=now.isoformat(),doNotObserveBeforeUTC=(now+timedelta(seconds=270)).isoformat(),ownerSeconds=210,stopSeconds=30,marginSeconds=30),indent=2)+'\n',encoding='utf-8')
print('Collection first started; observe after',(now+timedelta(seconds=270)).isoformat())
