from pathlib import Path
import subprocess
r=Path(__file__).parent
remote='''from pathlib import Path
import json,hashlib,subprocess
r=Path('/home/lokad/lython-bench-checks/string-index-storage-b518-20261109')
i=json.loads((r/'identity.json').read_text());m=[]
for role in ['reference','candidate']:
 for n,h in i['auxiliaryFiles'].items():
  actual=hashlib.sha256((r/role/n).read_bytes()).hexdigest() if (r/role/n).is_file() else None
  if actual!=h:m.append(dict(role=role,name=n,expected=h,actual=actual))
print(json.dumps(dict(mismatches=m,workers=subprocess.run(['pgrep','-af','[d]otnet.* --compare worker'],capture_output=True,text=True).stdout,fixtureExists=(r/'guest-fixtures').exists(),service=subprocess.run(['systemctl','show','lython-b518-string-index-storage-20261109.service','--property=LoadState,ActiveState,MainPID'],capture_output=True,text=True).stdout)))
'''
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
done=subprocess.run(ssh+['python3 -'],input=remote,text=True,encoding='utf-8',capture_output=True)
(r/'auxiliary-startup-failure.json').write_text(done.stdout,encoding='utf-8')
(r/'auxiliary-inspection.log').write_text(done.stderr,encoding='utf-8')
assert done.returncode==0,done.stderr
print(done.stdout)
