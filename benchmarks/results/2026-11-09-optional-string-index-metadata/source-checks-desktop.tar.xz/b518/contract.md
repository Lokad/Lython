R173 one bounded quiet confirmation: CSV sync, text sync/async, JSON report
sync, Unicode-index report sync. Same complete sources/fixtures/goldens per image;
four processes (two per source),5s warmup/role,7rotated150ms rounds, normal GC/tiering.
Expected145s,210s owner/30stop/30margin. Shared checked worker/adapter, current core
only differs; exact hashes/source preserved. Include RAM guest I/O/full output
checks/prior-result cleanup, exclude startup/reset/protocol/final caches. Coarse
process CPU has wider boundary. No CPython lane or producer qualification. Keep
all adverse/control-limited data; distinguish confirmed allocation savings from
elapsed/CPU and optional indexed-carrier cost. No fixed percentage veto. All
identity/quiet/output/ownership/join/RAM/archive-under-lease/localSHA gates required.
