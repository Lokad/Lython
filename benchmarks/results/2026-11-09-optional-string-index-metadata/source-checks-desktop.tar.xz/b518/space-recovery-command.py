from pathlib import Path
import fcntl,hashlib,json,os,shutil,stat,subprocess
base=Path('/home/lokad/lython-bench-checks')
spec=[{'path': '/home/lokad/lython-bench-checks/native-inputs-b493-20261109/observations.tgz', 'sha256': 'edaa334c3e716ca123ca371a3023ce90bd1f8c394e61530f15a21d374edb4f69', 'size': 3830113, 'preservedLocal': 'D:/code/Lython/benchmarks/results/2026-11-09-native-inputs/observations.tgz', 'tracked': True}, {'path': '/home/lokad/lython-bench-checks/native-inputs-b492-20261109/observations.tgz', 'sha256': 'e0549b063b67fbcb99f80555c4435a54a2b7c78c6d34de691b647d8015ea7cdc', 'size': 3828654, 'preservedLocal': 'D:/code/Lython/benchmarks/results/2026-11-09-native-inputs/before-prefix-observations.tgz', 'tracked': True}, {'path': '/home/lokad/lython-bench-checks/declaration-layout-b487-20261109/observations.tgz', 'sha256': '536b9258ede616b2a8e3011b8ad99ef6cb789e8d3efbb35c7d677a0beabaa822', 'size': 3819880, 'preservedLocal': 'D:/code/Lython/benchmarks/results/2026-11-09-declaration-metadata/observations.tgz', 'tracked': True}, {'path': '/home/lokad/lython-bench-checks/literal-construction-b489-20261109/observations.tgz', 'sha256': 'd530e2aabd257b0eb3695affeecb90b23a33c15ce7f003d09b175a02e18d156f', 'size': 3813901, 'preservedLocal': 'D:/code/Lython/benchmarks/results/2026-11-09-literal-construction/observations.tgz', 'tracked': True}, {'path': '/home/lokad/lython-bench-checks/json-runtime-b505-20261109/observations.tgz', 'sha256': '59c4a92971759a700cdcbd26abe673ddd90579747045b222876879a7730e4004', 'size': 2138069, 'preservedLocal': 'D:/code/Lython/benchmarks/results/2026-11-09-json-runtime-attribution/observations.tgz', 'tracked': True}, {'path': '/home/lokad/lython-bench-checks/cpython-checkpoint-b517-20261109/observations.tgz', 'sha256': 'df152e38e1e993cda80222493814cdcb5b1a1e64582b94b2c95a8440b9c32f9a', 'size': 2008876, 'preservedLocal': 'D:/code/Lython/benchmarks/results/2026-11-09-current-cpython-checkpoint/observations.tgz', 'tracked': True}]
with (base/'comparison-vm.lock').open('a') as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert not (base/'string-index-storage-b518-20261109').exists()
 assert not list(Path('/dev/shm').glob('lython-comparison-files-*')) and not Path('/dev/shm/lython-b512').exists()
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record|[o]ps-profile.py'],capture_output=True).returncode==1
 free=shutil.disk_usage(base).free
 if free>276512768:
  print(json.dumps(dict(skipped=True,beforeFreeBytes=free,requiredFreeBytes=276512768,reason='Fresh space sufficient; no mutation')));__import__('sys').exit(0)
 rows=[];unavailable=[]
 for entry in spec:
  p=Path(entry['path'])
  if not p.exists():unavailable.append(entry['path']);continue
  assert p.resolve(strict=True)==p and p.parent.parent==base and p.name=='observations.tgz'
  info=p.lstat();assert stat.S_ISREG(info.st_mode) and info.st_nlink==1 and info.st_uid==os.getuid() and info.st_gid==os.getgid()
  assert info.st_size==entry['size'] and hashlib.sha256(p.read_bytes()).hexdigest()==entry['sha256']
  receipt=json.loads((p.parent/'archive-receipt.json').read_text());assert receipt['complete'] and receipt['allWorkersJoined'] and receipt['archiveSHA256']==entry['sha256']
  parents=[]
  for parent in p.parents:
   meta=parent.lstat();assert stat.S_ISDIR(meta.st_mode) and not parent.is_symlink()
   parents.append(dict(path=str(parent),uid=meta.st_uid,gid=meta.st_gid,mode=oct(meta.st_mode)))
  rows.append(dict(**entry,device=info.st_dev,inode=info.st_ino,links=info.st_nlink,uid=info.st_uid,gid=info.st_gid,mode=oct(info.st_mode),parents=parents,allAliases=[str(p)]))
  if free+sum(Path(e['path']).stat().st_blocks*512 for e in rows)>276512768:break
 assert free+sum(Path(e['path']).stat().st_blocks*512 for e in rows)>276512768, ('Exact copies cannot fund unchanged payload/floors; no mutation',dict(freeBytes=free,requiredBytes=276512768,selectedBytes=sum(Path(e['path']).stat().st_blocks*512 for e in rows),unavailable=unavailable))
 plan=dict(requiredFreeBytes=276512768,freshIdleLease=True,beforeFreeBytes=free,osFloorMiB=240,evidenceHeadroomMiB=12,files=rows,unavailable=unavailable,operation='Remove only redundant remote compressed archives. Their raw trees, receipts, frozen workers and byte-identical tracked local archives survive.')
 target=base/'string-index-storage-b518-space-plan.json'
 with target.open('x') as f:f.write(json.dumps(plan,indent=2)+'\n');f.flush();os.fsync(f.fileno())
 for entry in rows:
  p=Path(entry['path']);info=p.lstat()
  assert info.st_dev==entry['device'] and info.st_ino==entry['inode'] and info.st_nlink==1 and hashlib.sha256(p.read_bytes()).hexdigest()==entry['sha256']
  p.unlink()
 plan['afterFreeBytes']=shutil.disk_usage(base).free
 assert plan['afterFreeBytes']>free and plan['afterFreeBytes']>(240+12)*1024*1024
 (base/'string-index-storage-b518-space-receipt.json').write_text(json.dumps(plan,indent=2)+'\n')
 print(json.dumps(plan))
