from pathlib import Path
import fcntl,hashlib,json,shutil,subprocess,tarfile
base=Path('/home/lokad/lython-bench-checks');root=base/'string-index-storage-b518-20261109'
with(base/'comparison-vm.lock').open('a')as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 state=subprocess.check_output(['systemctl','show','lython-b518-string-index-storage-20261109.service','--property=ActiveState,MainPID'],text=True)
 assert 'MainPID=0'in state and 'ActiveState=active'not in state
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record'],capture_output=True).returncode==1
 assert not(root/'confirmation').exists()
 fixture=root/'guest-fixtures';assert fixture.is_dir()and not list(fixture.iterdir())
 failed=root/'first-start';failed.mkdir()
 for name in ['run.sh','started.utc','stopped.utc','exit-code.txt','live-unit.txt']:
  data=(root/name).read_bytes();(failed/name).write_bytes(data)
 (failed/'journal.txt').write_text(subprocess.check_output(['journalctl','-u','lython-b518-string-index-storage-20261109.service','--no-pager','-n','65','-o','cat'],text=True))
 (failed/'cleanup.json').write_text(json.dumps(dict(noGuestRequests=True,noWorkers=True,ownedRamEmpty=True,reason='Protocol import link was part of the initial launcher after the auxiliary check; startup correction omitted it. No guest process or measurements started.'))+'\n')
 subprocess.run(['sudo','-n','umount',str(fixture)],check=True);fixture.rmdir()
 with tarfile.open(root/'first-start-failure.tgz','w:gz')as archive:archive.add(failed,arcname='first-start')
 target=base/'prepared-call-layout-b384-20261107/cpython-worker.py'
 assert target.is_file()and hashlib.sha256(target.read_bytes()).hexdigest()=='02ca606af6b937a5bec8da744da36e6dbea45ef14ee7207732f34da052ad32f1'
 assert not(root/'cpython-worker.py').exists();(root/'cpython-worker.py').symlink_to(target)
 i=json.loads((root/'identity.json').read_text())
 for role in ['reference','candidate']:
  assert hashlib.sha256((root/role/'Lokad.Lython.dll').read_bytes()).hexdigest()==i['coreSHA256'][role]
  for name,h in i['auxiliaryFiles'].items():assert hashlib.sha256((root/role/name).read_bytes()).hexdigest()==h
 for name in ['started.utc','stopped.utc','exit-code.txt','live-unit.txt']:
  assert(root/name).read_bytes()==(failed/name).read_bytes();(root/name).unlink()
 p=root/'run.sh';p.write_text(p.read_text().replace('lython-b518-string-index-storage-20261109.service','lython-b518-string-index-storage-run2-20261109.service'))
 p=root/'archive-owned.py';p.write_text(p.read_text().replace("'startup-resume.json']","'startup-resume.json','first-start','first-start-failure.tgz']"))
 assert shutil.disk_usage(root).free>252*1024*1024
 fixture.mkdir();subprocess.run(['sudo','-n','mount','-t','tmpfs','-o','size=128m,mode=0700,uid=lokad,gid=lokad','lython-b518-fixtures',str(fixture)],check=True)
 try:
  fcntl.flock(lease,fcntl.LOCK_UN)
  subprocess.run(['sudo','-n','systemd-run','--unit=lython-b518-string-index-storage-run2-20261109','--property=User=lokad','--property=WorkingDirectory='+str(root),'--property=RuntimeMaxSec=210','--property=TimeoutStopSec=30','--property=KillMode=control-group','/bin/sh',str(root/'run.sh')],check=True)
 except BaseException:
  subprocess.run(['sudo','-n','umount',str(fixture)],check=True);fixture.rmdir();raise
 print(json.dumps(dict(firstStartFailureArchived=True,ramCleanedBeforeRestart=True,protocolSHA256='02ca606af6b937a5bec8da744da36e6dbea45ef14ee7207732f34da052ad32f1',coreAndManagedAuxiliariesUnchanged=True,newUnit='lython-b518-string-index-storage-run2-20261109',ownerSeconds=210)))
