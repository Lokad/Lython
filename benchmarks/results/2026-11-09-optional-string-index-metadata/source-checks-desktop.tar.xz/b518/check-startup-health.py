from pathlib import Path
import subprocess
r=Path(__file__).parent
code='''from pathlib import Path
import json,subprocess
r=Path('/home/lokad/lython-bench-checks/string-index-storage-b518-20261109')
state=subprocess.check_output(['systemctl','show','lython-b518-string-index-storage-run2-20261109.service','--property=ActiveState,SubState,MainPID,Result'],text=True)
p=r/'confirmation/confirmation.json';record=json.loads(p.read_text())if p.exists()else None
print(json.dumps(dict(service=state,recordExists=record is not None,completedJobs=len(record['jobs'])if record else None,complete=record.get('complete')if record else None)))
'''
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
done=subprocess.run(ssh+['python3 -'],input=code,text=True,encoding='utf-8',capture_output=True,timeout=30)
(r/'startup-health.json').write_text(done.stdout,encoding='utf-8');assert done.returncode==0,done.stderr;print(done.stdout)
