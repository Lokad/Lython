from pathlib import Path
import base64,copy,hashlib,json,os,re,shutil,struct,subprocess
r=Path(__file__).parent;repo=Path('D:/code/Lython');prior=r.parent/'text-key-r172/final'
catalog=json.loads((prior/'catalog.json').read_text(encoding='utf-8'))
source='''total = 0
with open('input.txt') as source:
    for line in source:
        total += ord(line[0]) + ord(line[1]) + len(line)
with open('report.txt', 'w', newline='') as target:
    target.write(str(total) + chr(10))
print(total)
'''
payload=('α😀β\n'*1024).encode('utf-8');expected=b'132568064\n'
work=r/'unicode-golden-validated';work.mkdir()
(work/'input.txt').write_bytes(payload);(work/'workload.py').write_text(source,encoding='utf-8',newline='\n')
golden=subprocess.run(['C:/Python313/python.exe','-I','-S','-X','utf8','workload.py'],cwd=work,capture_output=True,check=True)
assert golden.stdout.replace(b'\r\n', b'\n')==expected and (work/'report.txt').read_bytes()==expected
version=subprocess.check_output(['C:/Python313/python.exe','--version'],text=True).strip()
(r/'unicode-golden.json').write_text(json.dumps(dict(version=version,source=source,inputSHA256=hashlib.sha256(payload).hexdigest(),output=golden.stdout.replace(b'\r\n', b'\n').decode(),physicalStdoutBase64=base64.b64encode(golden.stdout).decode(),stdoutNormalization='Windows physical CRLF becomes logical LF; report file must independently contain exact LF bytes.',files={'report.txt':expected.decode()},purpose='Independent trusted CPython golden, not a timing baseline',preparationCorrections='Original source wrote a literal backslash-n; corrected source uses chr(10). Initial capture also compared physical Windows stdout CRLF with logical LF. Both original fixture directories/scripts remain; no timed data existed.'),ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
fixture=json.dumps(dict(size=1024,text=None,inputFiles={'input.txt':base64.b64encode(payload).decode()},outputFiles={'report.txt':base64.b64encode(expected).decode()}),ensure_ascii=False,separators=(',',':'))
def digest(value):return hashlib.sha256(value.encode()).hexdigest()
h=hashlib.sha256();path=b'report.txt'
for part in [struct.pack('>i',1),struct.pack('>i',len(path)),path,struct.pack('>i',len(expected)),expected]:h.update(part)
c=copy.deepcopy(catalog['cases'][-1]);c.update(id='scripts.unicode-index-report.control',family='scripts',category='whole-script',scale='control',size=1024,source=source,fixtureJson=fixture,expectedOutput=expected.decode(),sourceUtf8Bytes=len(source.encode()),expectedOutputUtf8Bytes=len(expected),fixtureTextUtf8Bytes=0,fixtureTextCodePoints=0,sourceSha256=digest(source),fixtureSha256=digest(fixture),expectedOutputSha256=hashlib.sha256(expected).hexdigest(),expectedFilesSha256=h.hexdigest())
catalog['cases']=[c if 'file-search' in item['id'] else item for item in catalog['cases']]
assert len(catalog['cases'])==5 and any(item['id']==c['id']for item in catalog['cases'])
(r/'catalog.json').write_text(json.dumps(catalog,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
env=os.environ.copy();env['DOTNET_ROOT']='C:/Users/JoannesVermorel/.dotnet11';env['PATH']=env['DOTNET_ROOT']+os.pathsep+env['PATH']
folder=r/'frozen-old';shutil.copytree(repo/'tests/Lokad.Lython.Tests/bin/Release/net11.0',folder)
shutil.copyfile(prior/'images/candidate/Lokad.Lython.dll',folder/'Lokad.Lython.dll')
with (r/'frozen-old.log').open('w',encoding='utf-8')as log:
    done=subprocess.run([env['DOTNET_ROOT']+'/dotnet.exe','test',str(folder/'Lokad.Lython.WhiteBox.Tests.dll'),'--filter','FullyQualifiedName~StringStoragePublicationTests'],env=env,stdout=log,stderr=subprocess.STDOUT)
text=(r/'frozen-old.log').read_text(encoding='utf-8');print(text[-1700:],flush=True)
assert done.returncode!=0 and 'Failed:     1, Passed:     3' in text
(r/'regression-proof.json').write_text(json.dumps(dict(baselineRevision='R172102bed2b-equivalent precommit core, source230a0572 equivalent',coreSHA256=hashlib.sha256((folder/'Lokad.Lython.dll').read_bytes()).hexdigest(),testAssemblySHA256=hashlib.sha256((folder/'Lokad.Lython.WhiteBox.Tests.dll').read_bytes()).hexdigest(),failed=1,passed=3,condition='Admission callback recursively constructs the same rune index. Old code commits two caches, new code reuses the published one and refunds only unpublished working admission. Other stable-view cases pass old/new.'),indent=2)+'\n',encoding='utf-8')
print('Five-case catalog includes independent Unicode-index control; old deterministic reentry overcharge proven.')
