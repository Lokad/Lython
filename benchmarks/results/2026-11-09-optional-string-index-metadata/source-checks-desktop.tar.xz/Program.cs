using System.Reflection;
using System.Runtime.Loader;
using System.Text.Json;

var assembly = AssemblyLoadContext.Default.LoadFromAssemblyPath(Path.GetFullPath(args[0]));
var type = assembly.GetType("Lokad.Lython.Runtime.Text.PyString", throwOnError: true)!;
var method = type.GetMethod("FromOwnedUtf8", BindingFlags.Static | BindingFlags.NonPublic,
    binder: null, types: [typeof(byte[])], modifiers: null)!;
var actual = method.CreateDelegate<Func<byte[], object>>();
Func<byte[], object> model = static bytes => new StorageShape { Storage = bytes };
byte[] payload = [65];
foreach (var factory in new[] { actual, model })
    for (var index = 0; index < 8192; index++) Volatile.Write(ref Sink.Value, factory(payload));
long Observe(Func<byte[], object> factory)
{
    var before = GC.GetAllocatedBytesForCurrentThread();
    for (var index = 0; index < 8192; index++) Volatile.Write(ref Sink.Value, factory(payload));
    return (GC.GetAllocatedBytesForCurrentThread() - before) / 8192;
}
Console.WriteLine(JsonSerializer.Serialize(new
{
    runtime = System.Runtime.InteropServices.RuntimeInformation.FrameworkDescription,
    corePath = assembly.Location,
    coreSha256 = Convert.ToHexString(System.Security.Cryptography.SHA256.HashData(File.ReadAllBytes(assembly.Location))),
    actualBeforeBytes = Observe(actual), modelBytes = Observe(model), actualAfterBytes = Observe(actual),
    note = "Metadata only, preallocated payload, synthetic managed storage-union shape. Not a runtime implementation, guest allocation result or CPU measurement. No collection requested."
}));

static class Sink { public static object? Value; }
sealed class StorageShape
{
    public object? Storage = null;
    public object? MemoryGovernor = null;
    public long InlineUtf8 = 0;
    public byte InlineCapacity = 0;
    public int ByteLength = 1;
    public int RuneLength = -1;
    public int HashCode = 0;
    public bool HashCodeComputed = false;
}
