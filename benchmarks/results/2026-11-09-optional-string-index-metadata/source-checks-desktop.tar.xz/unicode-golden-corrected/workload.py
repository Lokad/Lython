total = 0
with open('input.txt') as source:
    for line in source:
        total += ord(line[0]) + ord(line[1]) + len(line)
with open('report.txt', 'w', newline='') as target:
    target.write(str(total) + chr(10))
print(total)
