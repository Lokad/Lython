#!/bin/bash
set -euo pipefail
cd /mnt/d/code/Lython/.git/agent-notes/review-20261031/current-regex-attribution-b1984-20261128
export DOTNET_ROOT="$HOME/.dotnet"
layout=attribution/layout
"$DOTNET_ROOT/dotnet" build "$layout/InspectLayout.csproj" -c Release --nologo --artifacts-path "$layout/build" --no-incremental --disable-build-servers > "$layout/build.log" 2>&1
"$DOTNET_ROOT/dotnet" "$layout/build/bin/InspectLayout/release_net11.0/InspectLayout.dll" comparison/quiet/local-image comparison/quiet/representative.json > "$layout/layout.json"