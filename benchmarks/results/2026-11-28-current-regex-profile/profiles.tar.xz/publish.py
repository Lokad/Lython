from hashlib import sha256
from pathlib import Path
from shutil import copy2
import json
import tarfile

lab = Path(__file__).resolve().parent
out = lab.parents[3] / 'benchmarks/results/2026-11-28-current-regex-profile'
profile = lab / 'attribution/profile'
quiet = lab / 'comparison/quiet'
layout = lab / 'attribution/layout'
read = lambda path: json.loads(path.read_bytes())
digest = lambda path: sha256(path.read_bytes()).hexdigest()
identity = read(profile / 'identity.json')
summary = read(profile / 'run-summary.json')
assert identity['sourceRevision'] == summary['sourceRevision']
assert summary['allProcessesJoined'] and not summary['timingQualification']
image = identity['imageFiles']['candidate']
assert len(image) == 32 and {p.name: digest(p) for p in (quiet / 'local-image').iterdir()} == image
verify = read(quiet / 'candidate-local-verify.json')
assert verify['state'] == 'Completed' and verify['caseCount'] == 2
assert verify['launched']['library']['sha256'] == image['Lokad.Lython.dll']
assert verify['launched']['python']['sha256'] == identity['expectedCPythonSHA256']
assert verify['catalogSha256'] == identity['catalogs']['representative.json']['sha256']
details=read(layout/'layout.json')
assert details['core']==image['Lokad.Lython.dll'] and details['catalog']==verify['catalogSha256']
assert len(details['observations'])==2 and all(not item['layouts'][0]['canRunNative'] for item in details['observations'])

raw = {name: lab / name for name in ('prepare.py','publish.py','run-profile.sh','verify.sh','profile.log','inspect.sh')}
raw.update({name: profile / name for name in ('run.sh','collect.py','analyze-managed.py')})
raw.update({name: quiet / name for name in ('candidate-local-verify.json','representative.json')})
raw.update({f'layout/{name}': layout/name for name in ('Program.cs','InspectLayout.csproj','build.log')})
batches = 0
for role, _, _ in identity['profiles']:
    folder = profile / role
    record = read(folder / 'record.json')
    assert record['allProcessesJoined'] and record['coreSha'] == image['Lokad.Lython.dll']
    assert record['nettraceSha'] == digest(folder / 'run.nettrace')
    batches += len(record['batches'])
    for path in folder.iterdir():
        if path.is_file(): raw[f'{role}/{path.name}'] = path
assert batches == summary['totalVerifiedBatches'] == 62

out.mkdir(exist_ok=True)
for name, path in {'identity.json': profile/'identity.json', 'summary.json': profile/'run-summary.json',
    'attribution.json': profile/'managed-attribution.json', 'layout.json': layout/'layout.json'}.items():
    copy2(path, out/name)
    assert digest(out/name) == digest(path)
with tarfile.open(out/'profiles.tar.xz','w:xz') as archive:
    for name, path in raw.items(): archive.add(path, arcname=name)
with tarfile.open(out/'profiles.tar.xz') as archive:
    for name, path in raw.items(): assert sha256(archive.extractfile(name).read()).hexdigest() == digest(path)
print('Verified both complete traces, two goldens and 62 batches.')
