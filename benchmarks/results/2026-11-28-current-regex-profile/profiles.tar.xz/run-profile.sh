#!/bin/bash
set -euo pipefail
cd /mnt/d/code/Lython
lab=.git/agent-notes/review-20261031/current-regex-attribution-b1984-20261128
unset DOTNET_BUNDLE_EXTRACT_BASE_DIR
bash "$lab/verify.sh"
cp "$lab/comparison/quiet/candidate-local-verify.json" "$lab/attribution/candidate-verify.json"
bash "$lab/attribution/profile/run.sh"
export DOTNET_ROOT="$HOME/.dotnet"
for role in compiled-log module-log; do
    "$HOME/.dotnet/tools/dotnet-trace" convert "$lab/attribution/profile/$role/run.nettrace" --format Speedscope
done
python3 "$lab/attribution/profile/analyze-managed.py"
