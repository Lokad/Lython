from pathlib import Path
import datetime
import gzip
import hashlib
import io
import tarfile
import json
import subprocess
import sys

lab=Path(__file__).resolve().parent
quiet=lab/"comparison/quiet"
configuration=json.loads((quiet/"upload.json").read_text(encoding="utf-8"))
remote="/home/lokad/lython-bench-checks"
unit="lython-b1544-csv-unpack-bindings-20261124"
host="lokad@20.166.121.73"
key=Path.home()/".ssh/id_lython-bench.pem"
common=["-i",str(key),"-o","BatchMode=yes","-o","ConnectTimeout=15"]
ssh=["C:/Windows/System32/OpenSSH/ssh.exe",*common,host,"python3 -"]
scp=["C:/Windows/System32/OpenSSH/scp.exe",*common]
configuration["unit"]=unit
configuration["duplicates"]=json.loads((quiet/"verified-replicas.json").read_text(encoding="utf-8"))
configuration["remote"]=remote
prefix="from pathlib import Path\nimport fcntl,hashlib,json,os,shutil,stat,subprocess,tarfile,tempfile\nconfiguration="+repr(configuration)+"\nbase=Path(configuration['remote']).resolve()\nroot=base/configuration['root']\nunit=configuration['unit']\n"
now=lambda:datetime.datetime.now(datetime.timezone.utc)

def invoke(script):
    result=subprocess.run(ssh,input=prefix+script,encoding="utf-8",capture_output=True,timeout=35)
    assert result.returncode==0,(result.stdout,result.stderr)
    return result.stdout

if sys.argv[1]=="launch":
    payload=quiet/"payload.tar.gz"
    assert hashlib.sha256(payload.read_bytes()).hexdigest()==configuration["payloadSHA256"]
    uploaded=remote+"/.+b1544-"+configuration["payloadSHA256"][:12]+".tar.gz"
    if sys.argv[2:] != ["already-uploaded"]:
        subprocess.run(scp+[payload,host+":"+uploaded],check=True,timeout=35)
    receipt=invoke("payload=Path("+repr(uploaded)+")\n"+"""digest=lambda path:hashlib.sha256(path.read_bytes()).hexdigest()
reference=base/configuration['reference']
marker=reference/'archive-receipt.json'
donor=json.loads(marker.read_text())
assert donor['complete'] and digest(reference/'observations.tar.xz')==donor['archiveSHA256']
assert donor['archiveSHA256']==configuration['donorArchiveSHA256']
with (base/'comparison-vm.lock').open('a') as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert payload.parent==base and payload.stat().st_size==configuration['payloadBytes'] and digest(payload)==configuration['payloadSHA256']
 with tempfile.TemporaryDirectory(prefix='lython-b1544-stage-',dir='/dev/shm') as spool_folder:
  spool=Path(spool_folder)/'payload.tar.gz'
  shutil.copyfile(payload,spool)
  assert digest(spool)==configuration['payloadSHA256']
  payload.unlink()
  free=shutil.disk_usage(base).free
  block=os.statvfs(base).f_frsize
  with tarfile.open(spool) as archive:
   assert {entry.name for entry in archive.getmembers()}=={'identity.json','representative.json',
    'jobs.json','collect.py','run.sh','candidate-core.dll','reference-core.dll'}
   assert all(entry.isfile() for entry in archive.getmembers())
   staged=sum(((entry.size+block-1)//block)*block for entry in archive.getmembers())
   minimum=staged + 10 * 1024 * 1024 + 1536 * 1024
   verified=[]
   available=free
   if available<minimum:
    for saved in configuration['duplicates']:
     files=[base/record['path'] for record in saved['copies']]
     identities=[]
     for path,record in zip(files,saved['copies'],strict=True):
      assert path.resolve()==path and path.is_file() and path.is_relative_to(base)
      item=path.stat()
      assert item.st_nlink==len(files)
      identities.append((item.st_dev,item.st_ino))
      assert digest(path.parent.parent/'observations.tar.xz')==record['observationSHA256']
     assert len(set(identities))==1 and digest(files[0])==saved['coreSHA256']
     available+=files[0].stat().st_blocks*512
     verified.append((files,saved))
     if available>=minimum: break
   assert available>=minimum,(available,minimum)
   for files,saved in verified:
    for path in files: path.unlink()
   assert shutil.disk_usage(base).free>=minimum
   root.mkdir()
   archive.extractall(root,filter='data')
 identity=json.loads((root/'identity.json').read_text())
 assert digest(root/'representative.json')==identity['catalogs']['representative.json']['sha256']
 for role,files in identity['imageFiles'].items():
  image=root/role
  image.mkdir()
  assert len(files)==32
  for name,sha in files.items():
   if name=='Lokad.Lython.dll':
    (root/(role+'-core.dll')).rename(image/name)
   else:
    os.link(reference/'candidate'/name,image/name)
   assert digest(image/name)==sha,(role,name)
 os.link(reference/'cpython-worker.py',root/'cpython-worker.py')
 assert digest(root/'cpython-worker.py')==identity['cpythonWorkerSHA256']
 assert bytes([13]) not in (root/'run.sh').read_bytes()
 print(json.dumps(dict(verifiedDuplicatesRetired=[saved for _,saved in verified],
  freeBefore=free,freeBeforeLaunch=shutil.disk_usage(base).free)),flush=True)
subprocess.run(['sudo','-n','systemd-run','--unit='+unit,'--property=User=lokad','--property=WorkingDirectory='+str(root),
 '--property=RuntimeMaxSec=345','--property=TimeoutStopSec=20','--property=KillMode=control-group','/bin/sh',str(root/'run.sh')],check=True)
""")
    (quiet/"launch.log").write_text(receipt,encoding="utf-8")
    started=now()
    (quiet/"observe-not-before").write_text((started+datetime.timedelta(seconds=275)).isoformat(),encoding="utf-8")
    print(receipt, unit)
else:
    assert sys.argv[1]=="retrieve"
    assert now()>=datetime.datetime.fromisoformat((quiet/"observe-not-before").read_text(encoding="utf-8"))
    state=invoke("""
service=subprocess.run(['systemctl','show',unit+'.service','--property=ActiveState,SubState,MainPID,Result,ExecMainStatus'],capture_output=True,text=True).stdout
if 'ActiveState=active' in service:
 print(json.dumps(dict(live=True,service=service)))
else:
 with (base/'comparison-vm.lock').open('a') as lease:
  fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
  outcome=(root/'exit-code.txt')
  receipt=(root/'archive-receipt.json')
  print(json.dumps(dict(live=False,service=service,exitCode=outcome.read_text().strip() if outcome.exists() else None,
  receipt=json.loads(receipt.read_text()) if receipt.exists() else None, fixtures=(root/'guest-fixtures').exists(),
  journal=subprocess.run(['journalctl','-u',unit+'.service','-n','36','--no-pager'],capture_output=True,text=True).stdout)))
""")
    result=json.loads(state)
    (quiet/("status-"+now().strftime("%H%M%S")+".json")).write_text(state,encoding="utf-8")
    if not result["live"] and result["receipt"] is not None:
        name="observations.tar.xz"
        archive=quiet/name
        subprocess.run(scp+[host+":"+remote+"/"+configuration["root"]+"/"+name,archive],check=True,timeout=35)
        assert hashlib.sha256(archive.read_bytes()).hexdigest()==result["receipt"]["archiveSHA256"]
        (quiet/"terminal-status.json").write_text(state,encoding="utf-8")
        assert not result["fixtures"] and result["exitCode"]=="0" and result["receipt"]["complete"],state
    print(state)
