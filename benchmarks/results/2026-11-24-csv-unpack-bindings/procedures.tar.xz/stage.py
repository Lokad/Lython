from pathlib import Path
import gzip
import hashlib
import json
import subprocess
import tarfile

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
previous = lab.with_name('native-inline-transfer-20261123')
comparison = lab / 'comparison'
quiet = comparison / 'quiet'
quiet.mkdir(exist_ok=True)
run = 'csv-unpack-bindings-b1544-20261124'
donor = 'combined-cased-split-cpython-b1539-20261123'
verify_path = 'benchmarks/results/'
sha = lambda content: hashlib.sha256(content).hexdigest()
digest = lambda path: sha(path.read_bytes())
read = lambda path: json.loads(path.read_text(encoding='utf-8'))


def tracked(group, name):
    return subprocess.check_output(['git', 'show', 'origin/master:' + verify_path + group + '/' + name], cwd=repo)


def save(name, value):
    (quiet / name).write_text(json.dumps(value, indent=2) + '\n', encoding='utf-8', newline='\n')


groups = [
    [('closed-factory-operand-b1529-20261123','2026-11-23-closed-factory-operand'),
     ('closed-factory-cpython-b1530-20261123','2026-11-23-closed-factory-cpython')],
    [('plain-class-namespace-b1533-20261123','2026-11-23-owned-class-module-slots'),
     ('owned-class-cpython-b1534-20261123','2026-11-23-owned-class-cpython'),
     ('short-text-cpu-boundaries-b1535-20261123','2026-11-23-short-text-boundaries')],
]
retirements = []
for group in groups:
    canonical = group[0][1]
    core = sha(gzip.decompress(tracked(canonical, 'candidate-core.dll.gz')))
    assert core == json.loads(tracked(canonical, 'identity.json'))['imageFiles']['candidate']['Lokad.Lython.dll']
    copies = []
    for run_name, evidence in group:
        receipt = json.loads(tracked(evidence, 'terminal-status.json'))['receipt']
        assert receipt['complete'] and receipt['archivedAndVerifiedUnderLease']
        assert sha(tracked(evidence, 'observations.tar.xz')) == receipt['archiveSHA256']
        copies.append(dict(path=run_name + '/candidate/Lokad.Lython.dll',
            observationSHA256=receipt['archiveSHA256'], tracked=verify_path + evidence))
    retirements.append(dict(coreSHA256=core, copies=copies, trackedCore=verify_path + canonical + '/candidate-core.dll.gz'))
save('verified-replicas.json', retirements)

worker = (previous / 'comparison/quiet/collect.py').read_text(encoding='utf-8')
worker = worker.replace(f"'reference':root.parent/'{donor}'/'candidate'", "'reference':root/'reference'")
assert "'reference':root/'reference'" in worker
worker = worker.replace('lython-b1541-fixtures', 'lython-b1544-fixtures')
assert 'while min(warmed)<8:' in worker
worker = worker.replace('while min(warmed)<8:', "while min(warmed)<record['warmupSeconds']:")
worker = worker.replace('if warmed[i]>=8:', "if warmed[i]>=record['warmupSeconds']:")
compile(worker, 'collect.py', 'exec')
(quiet / 'collect.py').write_text(worker, encoding='utf-8', newline='\n')
(quiet / 'run.sh').write_bytes((previous / 'comparison/quiet/run.sh').read_bytes())
assert b'\r' not in (quiet / 'run.sh').read_bytes()
payload = quiet / 'payload.tar.gz'
with tarfile.open(payload, 'w:gz') as archive:
    for name in ('identity.json', 'representative.json', 'jobs.json'):
        archive.add(comparison / name, arcname=name)
    for name in ('collect.py', 'run.sh'):
        archive.add(quiet / name, arcname=name)
    for role in ('reference', 'candidate'):
        archive.add(lab / role / 'Lokad.Lython.dll', arcname=role + '-core.dll')
archive_sha = json.loads(tracked('2026-11-23-combined-cased-split-cpython', 'terminal-status.json'))['receipt']['archiveSHA256']
assert sha(tracked('2026-11-23-combined-cased-split-cpython', 'observations.tar.xz')) == archive_sha
save('upload.json', dict(root=run, reference=donor, payloadBytes=payload.stat().st_size,
    payloadSHA256=digest(payload), donorArchiveSHA256=archive_sha))

launch = (previous / 'quiet.py').read_text(encoding='utf-8').replace(
    'b1541-native-inline-transfer-20261124', 'b1544-csv-unpack-bindings-20261124').replace('b1541-', 'b1544-')
launch = launch.replace('lab/"verified-replicas.json"', 'quiet/"verified-replicas.json"')
start = launch.index('with (base/')
end = launch.index("subprocess.run(['sudo','-n','systemd-run'", start)
launch = launch[:start] + '''assert donor['archiveSHA256']==configuration['donorArchiveSHA256']
with (base/'comparison-vm.lock').open('a') as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert payload.parent==base and payload.stat().st_size==configuration['payloadBytes'] and digest(payload)==configuration['payloadSHA256']
 with tempfile.TemporaryDirectory(prefix='lython-b1544-stage-',dir='/dev/shm') as spool_folder:
  spool=Path(spool_folder)/'payload.tar.gz'
  shutil.copyfile(payload,spool)
  assert digest(spool)==configuration['payloadSHA256']
  payload.unlink()
  free=shutil.disk_usage(base).free
  block=os.statvfs(base).f_frsize
  with tarfile.open(spool) as archive:
   assert {entry.name for entry in archive.getmembers()}=={'identity.json','representative.json',
    'jobs.json','collect.py','run.sh','candidate-core.dll','reference-core.dll'}
   assert all(entry.isfile() for entry in archive.getmembers())
   staged=sum(((entry.size+block-1)//block)*block for entry in archive.getmembers())
   minimum=staged + 10 * 1024 * 1024 + 1536 * 1024
   verified=[]
   available=free
   if available<minimum:
    for saved in configuration['duplicates']:
     files=[base/record['path'] for record in saved['copies']]
     identities=[]
     for path,record in zip(files,saved['copies'],strict=True):
      assert path.resolve()==path and path.is_file() and path.is_relative_to(base)
      item=path.stat()
      assert item.st_nlink==len(files)
      identities.append((item.st_dev,item.st_ino))
      assert digest(path.parent.parent/'observations.tar.xz')==record['observationSHA256']
     assert len(set(identities))==1 and digest(files[0])==saved['coreSHA256']
     available+=files[0].stat().st_blocks*512
     verified.append((files,saved))
     if available>=minimum: break
   assert available>=minimum,(available,minimum)
   for files,saved in verified:
    for path in files: path.unlink()
   assert shutil.disk_usage(base).free>=minimum
   root.mkdir()
   archive.extractall(root,filter='data')
 identity=json.loads((root/'identity.json').read_text())
 assert digest(root/'representative.json')==identity['catalogs']['representative.json']['sha256']
 for role,files in identity['imageFiles'].items():
  image=root/role
  image.mkdir()
  assert len(files)==32
  for name,sha in files.items():
   if name=='Lokad.Lython.dll':
    (root/(role+'-core.dll')).rename(image/name)
   else:
    os.link(reference/'candidate'/name,image/name)
   assert digest(image/name)==sha,(role,name)
 os.link(reference/'cpython-worker.py',root/'cpython-worker.py')
 assert digest(root/'cpython-worker.py')==identity['cpythonWorkerSHA256']
 assert bytes([13]) not in (root/'run.sh').read_bytes()
 print(json.dumps(dict(verifiedDuplicatesRetired=[saved for _,saved in verified],
  freeBefore=free,freeBeforeLaunch=shutil.disk_usage(base).free)),flush=True)
''' + launch[end:]
launch = launch.replace('seconds=220', 'seconds=275')
(lab / 'quiet.py').write_text(launch, encoding='utf-8', newline='\n')
(lab / 'summarize.py').write_bytes((previous / 'summarize.py').read_bytes())
