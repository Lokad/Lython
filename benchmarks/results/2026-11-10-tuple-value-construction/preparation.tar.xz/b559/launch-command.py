from pathlib import Path
import ast,fcntl,hashlib,io,json,os,shutil,stat,subprocess,sys,tarfile
config={'payloadBytes': 1901706, 'payloadSHA256': '3a6740c078e717f3d4a277677f8e7e086655052f83e75b59701e38ce5d4b6148', 'required': 270282752, 'coresToRetire': [{'knownPath': 'deferred-method-b548-20261110/candidate/Lokad.Lython.dll', 'sha256': '039dc975c341d77400e8df8189524480990b042d0694a2e60e27240abcfc61d1', 'bytes': 5660160, 'canonical': 'benchmarks/results/2026-11-10-current-text-attribution/observations.tgz:current-core.dll', 'archiveSHA256': 'efa4ad30b9f81cac544f1c5e3794097a385bd80a89fec4a51aa52f3845ef924c'}, {'knownPath': 'json-cpython-b546-20261110/candidate/Lokad.Lython.dll', 'sha256': 'e294fad194255fa086a3356a6adc57061ac3f764cc632f83bc459fa784f41ed9', 'bytes': 5660160, 'canonical': 'benchmarks/results/2026-11-10-json-cpython-checkpoint/observations.tgz:current-core.dll', 'archiveSHA256': 'b744d9435637a1fc7bb2fce546a8dfc3cb42a4b6c7837e65af5f92fb32345a24'}], 'expectedCores': {'reference': 'dbe94d4dfdcdc8f86de537ad904ee789664d749f60282713d7ac30c0d0467334', 'reference-control': 'dbe94d4dfdcdc8f86de537ad904ee789664d749f60282713d7ac30c0d0467334', 'candidate': '379a2d640be8a9d5f17a6374e6f1c9a026f961aeacd7e285e39f115d15f63096', 'candidate-control': '379a2d640be8a9d5f17a6374e6f1c9a026f961aeacd7e285e39f115d15f63096'}}
base=Path('/home/lokad/lython-bench-checks').resolve();root=base/'tuple-values-b559-20261110';source=base/'lexical-loop-b558-20261110/candidate';fixture=root/'guest-fixtures'
with(base/'comparison-vm.lock').open('a')as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert not root.exists()and not list(Path('/dev/shm').glob('lython-comparison-files-*'))
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record|[c]omplete-jobs.dll'],capture_output=True).returncode==1
 payload=sys.stdin.buffer.read(config['payloadBytes']+1);assert len(payload)==config['payloadBytes']and hashlib.sha256(payload).hexdigest()==config['payloadSHA256']
 with tarfile.open(fileobj=io.BytesIO(payload),mode='r:gz')as a:
  for name,role in [('current-core.dll','candidate')]:
   assert hashlib.sha256(a.extractfile(name).read()).hexdigest()==config['expectedCores'][role]
 assert hashlib.sha256((source/'Lokad.Lython.dll').read_bytes()).hexdigest()==config['expectedCores']['reference']
 stable=base/'transient-split-b555-20261110/candidate/Lokad.Lython.dll'
 assert hashlib.sha256(stable.read_bytes()).hexdigest()=='101ba9d3e5237b8d0da09689a94abf9b7dbbe276634becedac61e859e84ac897'
 protocol=base/'prepared-call-layout-b384-20261107/cpython-worker.py'
 assert hashlib.sha256(protocol.read_bytes()).hexdigest()=='02ca606af6b937a5bec8da744da36e6dbea45ef14ee7207732f34da052ad32f1'
 before=shutil.disk_usage(base).free;retired=[];reclaim=0
 if before<=config['required']:
  for proof in config['coresToRetire']:
   firstPath=base/proof['knownPath'];first=firstPath.lstat();key=(first.st_dev,first.st_ino)
   assert first.st_size==proof['bytes']and hashlib.sha256(firstPath.read_bytes()).hexdigest()==proof['sha256']
   aliases=[]
   for folder,dirs,files in os.walk(base):
    for name in files:
     path=Path(folder)/name;st=path.lstat()
     if(st.st_dev,st.st_ino)!=key:continue
     assert path.resolve(strict=True).is_relative_to(base)and stat.S_ISREG(st.st_mode)and st.st_uid==os.getuid()
     aliases.append(path.relative_to(base).as_posix())
   assert len(aliases)==first.st_nlink and aliases and proof['knownPath']in aliases
   assert proof['sha256']not in[config['expectedCores']['reference'],'101ba9d3e5237b8d0da09689a94abf9b7dbbe276634becedac61e859e84ac897']
   reclaim+=first.st_blocks*512;retired.append(dict(proof,paths=aliases,allocatedBytes=first.st_blocks*512,allHardlinkAliasesVerified=True))
  assert before+reclaim>config['required'],(before,reclaim,config['required'])
  for proof in retired:
   for path in proof['paths']:(base/path).unlink()
 assert hashlib.sha256(stable.read_bytes()).hexdigest()=='101ba9d3e5237b8d0da09689a94abf9b7dbbe276634becedac61e859e84ac897'
 assert hashlib.sha256((source/'Lokad.Lython.dll').read_bytes()).hexdigest()==config['expectedCores']['reference']
 assert shutil.disk_usage(base).free>config['required']
 with tarfile.open(fileobj=io.BytesIO(payload),mode='r:gz')as a:root.mkdir();a.extractall(root,filter='data')
 recovery=dict(beforeFreeBytes=before,afterRecoveryFreeBytes=shutil.disk_usage(base).free,requiredFreeBytes=config['required'],freshIdleLease=True,verifiedReplacementInPayload=True,files=retired,osFloorMiB=240,evidenceHeadroomMiB=12,qualified101AndBeforeDbePreserved=True)
 (root/'space-recovery.json').write_text(json.dumps(recovery,indent=2)+'\n')
 shutil.copyfile(protocol,root/'cpython-worker.py')
 os.link(source/'Lokad.Lython.dll',root/'baseline-core.dll')
 for role in ['reference','candidate']:
  shutil.copytree(source,root/role,copy_function=os.link)
  (root/role/'Lokad.Lython.dll').unlink();os.link(root/('baseline-core.dll'if role=='reference'else'current-core.dll'),root/role/'Lokad.Lython.dll')
 identity=json.loads((root/'identity.json').read_text())
 for role in ['reference','candidate']:
  for name,digest in{**identity['auxiliaryFiles'],'Lokad.Lython.dll':identity['coreSHA256'][role]}.items():assert hashlib.sha256((root/role/name).read_bytes()).hexdigest()==digest,(role,name)
 assert hashlib.sha256((root/'representative.json').read_bytes()).hexdigest()==identity['catalogSHA256']
 for name in ['collect.py','archive-owned.py']:ast.parse((root/name).read_text())
 subprocess.run(['/bin/sh','-n',str(root/'run.sh')],check=True)
 fixture.mkdir();subprocess.run(['sudo','-n','mount','-t','tmpfs','-o','size=128m,mode=0700,uid=lokad,gid=lokad','lython-b559-fixtures',str(fixture)],check=True)
 setup=dict(freeBytes=shutil.disk_usage(base).free,imagesVerified=True,jobs=3,ownerSeconds=150,stopSeconds=30,marginSeconds=30,osFloorMiB=240,evidenceHeadroomMiB=12)
 assert setup['freeBytes']>252*1024*1024
 (root/'setup.json').write_text(json.dumps(setup,indent=2)+'\n');print(json.dumps(setup),flush=True)
try:
 subprocess.run(['sudo','-n','systemd-run','--unit=lython-b559-tuple-values-20261110','--property=User=lokad','--property=WorkingDirectory='+str(root),'--property=RuntimeMaxSec=150','--property=TimeoutStopSec=30','--property=KillMode=control-group','/bin/sh',str(root/'run.sh')],check=True)
except BaseException:
 subprocess.run(['sudo','-n','umount',str(fixture)],check=True);fixture.rmdir();raise
live=subprocess.check_output(['systemctl','show','lython-b559-tuple-values-20261110.service','--property=ActiveState,MainPID,RuntimeMaxUSec'],text=True)
assert'ActiveState=active'in live and'MainPID=0'not in live;print(live,flush=True)
