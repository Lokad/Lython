using System.Reflection;
using System.Reflection.Emit;
using System.Text.Json;
var assembly = Assembly.LoadFrom(Path.GetFullPath(args[0]));
var codes = typeof(OpCodes).GetFields(BindingFlags.Public | BindingFlags.Static)
    .Select(f => (OpCode)f.GetValue(null)!).GroupBy(c => c.Value).ToDictionary(g => g.Key, g => g.First());
var rows = new List<object>();
foreach (var type in assembly.GetTypes())
foreach (var method in type.GetMethods(BindingFlags.DeclaredOnly | BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Static | BindingFlags.Instance).Cast<MethodBase>()
    .Concat(type.GetConstructors(BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Static | BindingFlags.Instance)))
{
    var il = method.GetMethodBody()?.GetILAsByteArray();
    if (il is null) continue;
    for (var position = 0; position < il.Length;)
    {
        var at = position;
        short key = il[position++];
        if (key == 0xfe) key = (short)(0xfe00 | il[position++]);
        var code = codes[key];
        if (code == OpCodes.Newobj)
        {
            var target = method.Module.ResolveMethod(BitConverter.ToInt32(il, position), type.GetGenericArguments(), method.IsGenericMethod ? method.GetGenericArguments() : null)!;
            if (target.DeclaringType?.FullName == "Lokad.Lython.Runtime.PyTuple")
                rows.Add(new { owner = type.FullName, method = method.Name, offset = at,
                    parameters = target.GetParameters().Select(p => p.ParameterType.ToString()).ToArray() });
        }
        position += code.OperandType switch
        {
            OperandType.InlineNone => 0,
            OperandType.ShortInlineBrTarget or OperandType.ShortInlineI or OperandType.ShortInlineVar => 1,
            OperandType.InlineVar => 2,
            OperandType.InlineI8 or OperandType.InlineR => 8,
            OperandType.InlineSwitch => 4 + 4 * BitConverter.ToInt32(il, position),
            _ => 4
        };
    }
}
File.WriteAllText(args[1], JsonSerializer.Serialize(rows, new JsonSerializerOptions { WriteIndented = true }));
Console.WriteLine($"Inspected {rows.Count} tuple construction sites; emitted signatures saved.");
