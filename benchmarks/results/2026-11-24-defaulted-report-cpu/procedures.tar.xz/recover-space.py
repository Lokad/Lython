from pathlib import Path
import hashlib
import json
import subprocess
import tarfile

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
folder = 'benchmarks/results/2026-11-24-private-call-source-cpu'
receipt = json.loads((repo / folder / 'terminal-status.json').read_text(encoding='utf-8'))['receipt']
local_archive = repo / folder / 'observations.tar.xz'
sha = lambda data: hashlib.sha256(data).hexdigest()
assert receipt['complete'] and receipt['archivedAndVerifiedUnderLease']
assert sha(local_archive.read_bytes()) == receipt['archiveSHA256']
assert sha(subprocess.check_output(['git', 'show', f'origin/master:{folder}/observations.tar.xz'], cwd=repo)) == receipt['archiveSHA256']
with tarfile.open(local_archive) as file:
    members = {member.name: [member.size, sha(file.extractfile(member).read())]
               for member in file if member.isfile() and member.name.startswith('profiles/')
               and member.name.endswith(('/perf.data', '/perf.map.gz', '/record.json'))}
assert len(members) == 15
source = f'''
from pathlib import Path
import fcntl, hashlib, json, shutil, stat, tarfile
root = Path('/home/lokad/lython-bench-checks').resolve()
run = root / 'private-call-source-cpu-b1601-20261124'
assert run == run.resolve() and run.is_relative_to(root)
minimum = 6 * 1024 * 1024
members = {members!r}
sha = lambda data: hashlib.sha256(data).hexdigest()
with (root/'comparison-vm.lock').open('a') as lock:
    fcntl.flock(lock, fcntl.LOCK_EX|fcntl.LOCK_NB)
    assert not (run/'guest-fixtures').exists() and (run/'exit-code.txt').read_text().strip() == '0'
    receipt = json.loads((run/'archive-receipt.json').read_text())
    assert receipt['complete'] and receipt['allWorkersJoined'] and receipt['archivedAndVerifiedUnderLease']
    archive = run/'observations.tar.xz'
    assert receipt['archiveSHA256'] == {receipt['archiveSHA256']!r} == sha(archive.read_bytes())
    free = available = shutil.disk_usage(root).free
    reclaim = []
    with tarfile.open(archive) as file:
        for name, (size, expected) in sorted(members.items(), key=lambda item: item[1][0], reverse=True):
            if available >= minimum:
                break
            raw = run / name
            assert raw.resolve() == raw and raw.is_relative_to(run/'profiles')
            if not raw.exists():
                continue
            info = raw.lstat()
            assert stat.S_ISREG(info.st_mode) and info.st_nlink==1 and info.st_size==size
            assert sha(raw.read_bytes()) == expected == sha(file.extractfile(name).read())
            reclaim.append((raw, name, size, expected))
            available += info.st_blocks * 512
    assert available >= minimum, (free, available)
    for raw, _, _, _ in reclaim:
        raw.unlink()
    assert sha(archive.read_bytes()) == receipt['archiveSHA256']
    new_free = shutil.disk_usage(root).free
    print(json.dumps(dict(freeBefore=free, freeAfter=new_free, archivedRun=run.name,
          archiveSHA256=receipt['archiveSHA256'], replicas=[dict(name=name,size=size,sha256=expected)
          for _,name,size,expected in reclaim])))
    assert new_free >= minimum
'''
ssh = ['C:/Windows/System32/OpenSSH/ssh.exe', '-i', str(Path.home()/'.ssh/id_lython-bench.pem'),
       '-o', 'BatchMode=yes', '-o', 'ConnectTimeout=14', 'lokad@20.166.121.73', 'python3 -']
result = subprocess.run(ssh, input=source.encode('utf-8'), capture_output=True, timeout=30)
(lab / 'space-recovery.json').write_bytes(result.stdout)
result.check_returncode()
print(result.stdout.decode(), end='')