from pathlib import Path
import hashlib
import json
import re
import shutil
import tarfile

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
output = repo / 'benchmarks/results/2026-11-24-defaulted-report-cpu'
digest = lambda data: hashlib.sha256(data).hexdigest()
read = lambda name: json.loads((lab / name).read_text(encoding='utf-8-sig'))
terminal = read('terminal-status.json')
receipt = terminal['receipt']
assert not terminal['live'] and not terminal['fixtures'] and terminal['exitCode'] == '0'
assert all(receipt[key] for key in ('complete','quietBeforeAndAfter','allWorkersJoined','guestFixturesRemoved','archivedAndVerifiedUnderLease'))
assert digest((lab / 'observations.tar.xz').read_bytes()) == receipt['archiveSHA256']
identity = read('identity.json')
verification = read('candidate-verification.json')
assert verification['caseCount'] == len(identity['profiles']) == 2
assert verification['state'] == 'Completed' and verification['catalogSha256'] == identity['profileCatalogSHA256']
assert identity['productionSource'] == '0400f185c'
core = identity['imageFiles']['candidate']['Lokad.Lython.dll']
assert core == verification['launched']['library']['sha256'] == read('tapes.json')['coreSHA256']
assert [(r['label'],r['case'],r['role']) for r in read('attribution.json')['rows']] == [tuple(r) for r in identity['profiles']]
assert read('space-recovery.json')['freeBefore'] == 3997696
assert read('space-recovery.json')['freeAfter'] >= 6 * 1024 * 1024
assert b'AssertionError: 3997696' in (lab / 'launch-insufficient-space.log').read_bytes()
assert b'\r' not in (lab / 'run.sh').read_bytes()
for name in ('identity.json','attribution.json','observations.tar.xz','terminal-status.json','space-recovery.json'):
    shutil.copyfile(lab / name, output / name)
procedures = ('prepare.py','quiet.py','recover-space.py','collect.py','ops-profile.py','analyze.py','archive.py','run.sh',
              'catalog.json','candidate-verification.json','launch-insufficient-space.log','launch.log','tapes.json',
              'tape-inspector/Program.cs','tape-inspector/Inspect.csproj')
with tarfile.open(output / 'procedures.tar.xz', 'w:xz') as file:
    for name in procedures:
        file.add(lab / name, arcname=name, recursive=False)
with tarfile.open(output / 'procedures.tar.xz') as file:
    assert {member.name:digest(file.extractfile(member).read()) for member in file} == {
        name:digest((lab / name).read_bytes()) for name in procedures}
for target in re.findall(r'\]\(([^)]+)\)', (output / 'README.md').read_text(encoding='utf-8')):
    assert (output / target).is_file(), target
print('Archived B1605 with two attested profiles and exact-source tapes.')