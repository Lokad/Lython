from pathlib import Path
import hashlib
import json
import shutil
import subprocess

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
previous = lab.with_name('private-call-source-cpu-20261124')
donor = lab.with_name('closed-capture-pair-seeded-20261124')
comparison = donor / 'comparison'
read = lambda path: json.loads(path.read_text(encoding='utf-8-sig'))
digest = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
write = lambda name, source: (lab / name).write_text(source, encoding='utf-8', newline='\n')
save = lambda name, data: write(name, json.dumps(data, indent=2) + '\n')
source = '0400f185c'
old_root = 'private-call-isolation-b1599-20261124'
donor_root = 'closed-capture-seeded-b1603-20261124'
assert read(comparison / 'quiet/upload.json')['root'] == donor_root
identity = read(comparison / 'identity.json')
subprocess.run(['git', 'diff', '--exit-code', identity['candidate'], source, '--', 'src', 'tests'], cwd=repo, check=True)
subprocess.run(['git', 'diff', '--exit-code', source, 'HEAD', '--', 'src', 'tests'], cwd=repo, check=True)
files = identity['imageFiles']['candidate']
assert len(files) == 32 and {p.name: digest(p) for p in (donor / 'candidate').iterdir()} == files
receipt = read(comparison / 'quiet/terminal-status.json')['receipt']
assert receipt['complete'] and receipt['archivedAndVerifiedUnderLease']
assert digest(comparison / 'quiet/observations.tar.xz') == receipt['archiveSHA256']
profiles = [
    ('defaulted', 'scripts.rule-default-closures', 'candidate'),
    ('unicode-report', 'diagnostic.text-summary.nonlocal-computed-width.large', 'candidate'),
]
catalog = read(comparison / 'representative.json')
catalog['cases'] = [next(item for item in catalog['cases'] if item['id'] == case) for _, case, _ in profiles]
save('catalog.json', catalog)
identity['imageFiles'] = {'candidate': files}
identity['coreSHA256'] = {'candidate': files['Lokad.Lython.dll']}
identity.update(productionSource=source, donorArchiveSHA256=receipt['archiveSHA256'], profiles=profiles,
                profileCatalogSHA256=digest(lab / 'catalog.json'),
                purpose='Distinguish remaining native call and text work on two complete scripts at the delivered source')
save('identity.json', identity)

collector = (previous / 'collect.py').read_text(encoding='utf-8')
collector = collector.replace(old_root, donor_root).replace('b1601-fixtures', 'b1605-fixtures')
collector = collector.replace('7*1024*1024', '4*1024*1024')
compile(collector, 'collect.py', 'exec')
write('collect.py', collector)
shutil.copyfile(previous / 'ops-profile.py', lab / 'ops-profile.py')
shutil.copyfile(previous / 'run.sh', lab / 'run.sh')
assert b'\r' not in (lab / 'run.sh').read_bytes()

launcher = (previous / 'quiet.py').read_text(encoding='utf-8')
launcher = launcher.replace('private-call-source-cpu-b1601-20261124', 'current-defaulted-report-cpu-b1605-20261124')
launcher = launcher.replace('lython-b1601-private-call-source-cpu-', 'lython-b1605-current-defaulted-report-cpu-')
launcher = launcher.replace("'private-call-isolation-20261124'", "'closed-capture-pair-seeded-20261124'")
launcher = launcher.replace('checked["caseCount"]==3', 'checked["caseCount"]==2')
launcher = launcher.replace('"reference-verification.json",', '').replace("'reference-verification.json',", '')
launcher = launcher.replace('    replicas=json.loads((lab/"verified-raw-replicas.json").read_text(encoding="utf-8"))\n', '')
start = launcher.index(' need = 8*1024*1024'); end = launcher.index(' root.mkdir()', start)
launcher = launcher[:start] + ''' free = shutil.disk_usage(root.parent).free
 assert free >= 5*1024*1024, free
 assert not root.exists()
 custody=dict(freeBefore=free)
''' + launcher[end:]
launcher = launcher.replace('Staged five profiles', 'Staged two profiles').replace('RuntimeMaxSec=205','RuntimeMaxSec=125').replace('seconds=134', 'seconds=76')
compile(launcher, 'quiet.py', 'exec')
assert 'raw.unlink' not in launcher and 'reference-verification' not in launcher
write('quiet.py', launcher)

analyzer = (previous / 'analyze.py').read_text(encoding='utf-8')
start = analyzer.index(" if label=='captured-current':")
end = analyzer.index(' nearest_lython=', start)
analyzer = analyzer[:start] + ''' regions=collections.Counter()
 region_leaves=collections.defaultdict(collections.Counter)
 for stack in guest:
  runtime=[key for key in map(method_key,stack) if key.startswith('Lokad.Lython.Runtime.')]
  if label=='defaulted' and any('TryReturnDefinition' in key or 'CreateClosedFunctionDefinition' in key or 'CreateClosedComputedDefinition' in key or 'TryCompleteImmediatelyCalledDefinition' in key or 'ClosedDefinitionPair' in key for key in runtime):
   region='definition construction'
  elif any('StartNativeWorkspace' in key for key in runtime):
   region='native workspace'
  elif any('TryStartDirectIntegerReturn' in key for key in runtime):
   region='closed integer consumer'
  elif label=='unicode-report' and any('Cased' in key or 'NativeTextIndex' in key or 'Whitespace' in key for key in runtime):
   region='word preparation or indexing'
  elif label=='unicode-report' and any('PyFileObject' in key or 'TextFileHandle' in key or 'ComparisonFileHost' in frame for key,frame in zip(map(method_key,stack),stack)):
   region='file or host I/O'
  else:
   region='other or unresolved boundary'
  regions[region]+=1
  region_leaves[region][runtime[0]]+=1
 assert sum(regions.values())==len(guest)
 rows[-1]['runtimeRegions']=dict(regions)
 rows[-1]['runtimeRegionLeaves']={region:methods.most_common() for region,methods in region_leaves.items()}
''' + analyzer[end:]
compile(analyzer, 'analyze.py', 'exec')
write('analyze.py', analyzer)
print('Prepared two serial profiles on the delivered frozen image.')