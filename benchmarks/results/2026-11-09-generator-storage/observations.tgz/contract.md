
### R142 selected migration (2026-11-09)

Source gate confirms that eager, separately compiled generator definitions discard
known lexical facts, force namespace mirroring through their parents, and require a
second generator-only locals/cell initializer. Compile these definitions with the
existing enclosing builder instead; class-suite generators remain prepared with
incomplete lexical facts and mirrored namespaces. Remove the eager generator-code
tuple/definition path, unconditional mirroring for complete scopes, and the duplicate
retained-frame initializer. Pass bound values to the existing work-state constructor;
retained generators copy into their own admitted storage, never borrow returned pools.
Generator lambdas retain their existing separate preparation in this bounded milestone.

Validate Python captures/deletions/nonlocal writes, suspended sibling closures,
locals, class/global barriers and super; creation stays lazy and send/throw/close/
yield-from retain cleanup. Existing generator expression and pending async cleanup,
first-refusal/cancellation, aliases/budget reuse and managed stack checks remain.
Compare complete generator-pipeline CSV/text/JSON scripts plus unchanged controls,
compile and warm separately, both execution APIs; one short local diagnostic first.
Only confirm quiet VM timings where material. This is an active prototype until
source deletion and focused checks pass, with allocation/CPU claims kept separate.
