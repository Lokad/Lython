# R142 bounded confirmation

Confirm complete CSV/text/JSON generator pipelines, report control; four source-pair
jobs, four independent roles, normal GC/tiering, five-second warmups, seven rotated
150ms batches. Same source/input/golden per pair. Included clocks: mediated RAM-file
I/O, full output validation and previous-result cleanup; excludes compilation,
startup/reset/protocol/final cache teardown. Wider process CPU separate.
Keep adverse desktop JSON +6–8% and variable controls, compile allocation +1.3–1.6%.
No percentage veto or universal CPU claim. One usable bounded confirmation stops
this comparison; meaningful regression requires a debt decision before delivery.
Retain source proof/raw cores and common tooling. Join all users, remove RAM,
archive under lease and verify local SHA. No floor relaxation or background users.
