from pathlib import Path
import hashlib, json, os, subprocess

r = Path(__file__).parent
env = os.environ.copy()
env['DOTNET_ROOT'] = 'C:/Users/JoannesVermorel/.dotnet11'
env['DOTNET_HOST_PATH'] = env['DOTNET_ROOT'] + '/dotnet.exe'
env['PATH'] = env['DOTNET_ROOT'] + os.pathsep + env['PATH']
for phase, api in [('warm', 'sync'), ('warm', 'async'), ('compile', 'sync')]:
    folder = r / (phase + '-' + api)
    folder.mkdir()
    witness = folder / 'hash-witness.json'
    witness.write_text(json.dumps(dict(source="return [hash('Lython-é😀'), hash((1, 2.0, True))]\n"), ensure_ascii=False) + '\n', encoding='utf-8')
    with (folder / 'measurements.json').open('w', encoding='utf-8') as out, (folder / 'stderr.txt').open('w', encoding='utf-8') as err:
        done = subprocess.run([env['DOTNET_HOST_PATH'], str(r.parent / 'integer-utf8-r45/tool/out/complete-jobs.dll'),
                               str(r/'images/before/Lokad.Lython.Benchmarks.dll'), str(r/'images/candidate/Lokad.Lython.Benchmarks.dll'),
                               str(r/'catalog.json'), str(witness), 'reverse', phase, api], env=env, stdout=out, stderr=err)
    assert done.returncode == 0, (folder / 'stderr.txt').read_text(encoding='utf-8')[-4000:]
    data = json.loads((folder / 'measurements.json').read_text(encoding='utf-8'))
    assert all(data[k] for k in ['allGoldensPassed', 'allBalancesZero', 'ownedFixturesRemoved', 'imageIsolationVerified'])
    print(phase, api, 'all five golden/ownership/isolation/cleanup gates pass.', flush=True)
proof = dict(baseline=json.loads((r/'baseline.json').read_text(encoding='utf-8-sig')),
             candidateCoreSHA256=hashlib.sha256((r/'images/candidate/Lokad.Lython.dll').read_bytes()).hexdigest(),
             productionSources={p.as_posix(): hashlib.sha256(p.read_bytes()).hexdigest()
                                for p in Path('src/Lokad.Lython').rglob('*.cs') if 'obj' not in p.parts})
(r/'identity.json').write_text(json.dumps(proof, indent=2), encoding='utf-8')
