from pathlib import Path
import hashlib, json, shutil, subprocess, tarfile

r = Path(__file__).parent
v = r/'b500'
out = Path('benchmarks/results/2026-11-09-generator-storage')
out.mkdir()
measured = json.loads((r/'identity.json').read_text(encoding='utf-8'))
delta = {}
for name, previous in measured['productionSources'].items():
    current = hashlib.sha256(Path(name).read_bytes()).hexdigest()
    if current != previous: delta[name] = dict(measuredSHA256=previous, deliverySHA256=current)
assert set(delta) == {'src/Lokad.Lython/Public/LythonEngine.cs', 'src/Lokad.Lython/Runtime/LythonRuntime.Executable.cs'}, delta
proof = dict(measuredBaseline=measured['baseline'], measuredCoreSHA256=measured['candidateCoreSHA256'],
             postMeasurementSourceDelta=delta,
             postMeasurementChanges='Restore the original between-phase cancellation/refusal checks inside the expanded generator-diagnostic catch; remove now-unused InitializeExecutableBindings and update four white-box fixture calls to explicit work data. No measured guest-path change or final-binary timing claim.',
             finalFocusedPerFramework=dict(internal=184, public=628, compilerDiagnostics=37),
             actualFrameworks=['net11.0', 'net10.0'], independentPythonGoldens=8,
             validation='Live/deleted incoming/local/transitive cells, nonlocal writes, locals/default snapshots, retained arguments, class/super barriers, lazy creation, metadata, send/throw/close/delegation, genuinely pending I/O, cancellation/first refusal, awaited cleanup, aliases and shared allowance reuse. Full platform/package/Stress qualification still batches at delivery.',
             decision='Retain shared lexical compilation/state construction and affected workload benefit. Warm text allocation minus15.1percent; compile allocation plus1.3to1.6percent retained as debt. Quiet report control plus1.17to4.54percent elapsed and plus0.39to4.44percent CPU unresolved; no neutrality/universal speedup or unchanged retiming claim. Generator lambdas/incomplete class/type scopes retain existing bridges.')
(r/'delivery-source.json').write_text(json.dumps(proof, indent=2), encoding='utf-8')
(r/'delivery-source.patch').write_bytes(subprocess.check_output(['git', 'diff', '--binary', '--', 'src/Lokad.Lython', 'tests']))
for target, source in [('observations.tgz', v/'observations.tgz'), ('summary.json', v/'assessment.json'),
                       ('terminal.json', v/'terminal-status.json'), ('identity.json', v/'identity.json'),
                       ('local-summary.json', r/'assessment-local.json'), ('compile-allocation.json', r/'compile-allocation.json'),
                       ('delivery-source.json', r/'delivery-source.json'), ('pipeline-goldens.json', r/'pipeline-goldens.json')]:
    shutil.copyfile(source, out/target)
names = [p for p in r.iterdir() if p.is_file() and p.name not in ['plan-before.md']]
folders = [r/name for name in ['warm-sync', 'warm-async', 'compile-sync', 'initial-identity-refusal']]
vm_files = [p for p in v.iterdir() if p.is_file() and p.name not in ['payload.tgz', 'observations.tgz']]
with tarfile.open(out/'preparation.tar.xz', 'w:xz') as t:
    for p in names + folders: t.add(p, arcname=p.name)
    for p in vm_files: t.add(p, arcname='b500/'+p.name)
    t.add('tests/Lokad.Lython.PublicApi.Tests/GeneratorStorageSemanticsTests.cs', arcname='GeneratorStorageSemanticsTests.cs')
with tarfile.open(out/'preparation.tar.xz') as t:
    assert set(p.name for p in names) <= set(t.getnames())
print('Archived controlled observations, adverse conditions, preparation, final source differences and focused checks.')
