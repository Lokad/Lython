from pathlib import Path
r = Path(__file__).parent
data = (r.parent/'text-runtime-r140/retrieve.py').read_text(encoding='utf-8')
data = data.replace('text-runtime-b499-20261109', 'generator-storage-b500-20261109')
data = data.replace('lython-b499-text-runtime-20261109', 'lython-b500-generator-storage-20261109')
data = data.replace("status['receipt']['capturedSeconds']<16", "status['receipt']['jobs']==4 and status['receipt']['elapsedSeconds']<150")
data = data.replace("remainingTrace=Path('/dev/shm/lython-b499').exists()", "remainingTrace=(root/'guest-fixtures').exists()")
data = data.replace('Persistent raw profile/code/unknown evidence independently verified; no remaining VM users or RAM traces.',
                    'Four-job raw observations/cores independently SHA-verified; terminal cached, no remaining VM users or RAM fixtures.')
(r/'b500/retrieve.py').write_text(data, encoding='utf-8', newline='\n')
