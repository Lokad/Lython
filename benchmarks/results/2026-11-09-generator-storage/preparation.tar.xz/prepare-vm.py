from pathlib import Path
import hashlib, json, shutil, subprocess, tarfile

r = Path(__file__).parent
v = r/'b500'
v.mkdir()
old = r.parent/'lexical-operands-r139/b498'
remote = '/home/lokad/lython-bench-checks/generator-storage-b500-20261109'
previous = '/home/lokad/lython-bench-checks/lexical-operands-b498-20261109'
for name in ['collect.py', 'archive-owned.py', 'run.sh']:
    data = (old/name).read_text(encoding='utf-8').replace(previous, remote).replace('lython-b498-lexical-operands-20261109', 'lython-b500-generator-storage-20261109')
    if name == 'collect.py':
        start = data.index('jobs=[')
        end = data.index('\nenv =', start)
        jobs = [[c['id'], 'warm'] for c in json.loads((r/'catalog.json').read_text(encoding='utf-8'))['cases'][:4]]
        assert len(jobs) == 4
        data = data[:start] + 'jobs=' + repr(jobs) + '\nassert len(jobs)==4 and all(case in cases for case,lane in jobs)\n' + data[end:]
        a = data.index("purpose='R139")
        b = data.index('\n                  warmupSeconds=', a)
        data = data[:a] + "purpose='R142 existing enclosing lexical compilation and shared generator-state construction. Three complete CSV/text/JSON generator pipelines and unchanged report control. Desktop text allocation minus15.1percent; compile allocation plus1.3to1.6percent. Adverse desktop JSONplus6to8percent and unstable controls preserved. Simplification, allocation and CPU claims separated.'," + data[b:]
        data = data.replace(' < 210,', ' < 150,')
    if name == 'archive-owned.py':
        data = data.replace("len(r['jobs'])==7", "len(r['jobs'])==4").replace('jobs=7,', 'jobs=4,')
        data = data.replace("'sizing.json']", "'sizing.json','common-worker.dll','common-adapter.dll','common-worker.deps.json','common-worker.runtimeconfig.json']")
    (v/name).write_text(data, encoding='utf-8', newline='\n')

shutil.copyfile(r/'catalog.json', v/'representative.json')
for name, source in [('baseline-core.dll', r/'images/before/Lokad.Lython.dll'),
                     ('current-core.dll', r/'images/candidate/Lokad.Lython.dll'),
                     ('common-worker.dll', r/'images/before/Lokad.Lython.Benchmarks.dll'),
                     ('common-adapter.dll', r/'images/before/Lokad.Lython.Utf8Regex.dll'),
                     ('common-worker.deps.json', r/'images/before/Lokad.Lython.Benchmarks.deps.json'),
                     ('common-worker.runtimeconfig.json', r/'images/before/Lokad.Lython.Benchmarks.runtimeconfig.json'),
                     ('baseline-source.json', r/'baseline.json'), ('contract.md', r/'pre-edit-plan.md')]:
    shutil.copyfile(source, v/name)
(v/'source.patch').write_bytes(subprocess.check_output(['git', 'diff', '--binary', '--', 'src/Lokad.Lython']))
core = {role: hashlib.sha256((v/name).read_bytes()).hexdigest()
        for role, name in [('reference', 'baseline-core.dll'), ('reference-control', 'baseline-core.dll'),
                           ('candidate', 'current-core.dll'), ('candidate-control', 'current-core.dll')]}
identity = dict(sourceRevision='Committed7aa637bf before R142 versus working R142; freshly built core d1c9 versus2ce8; same frozen worker/adapter both roles', coreSHA256=core,
                auxiliaryFiles={p.name: hashlib.sha256(p.read_bytes()).hexdigest()
                                for p in (r/'images/before').glob('*.dll') if p.name != 'Lokad.Lython.dll'},
                catalogSHA256=hashlib.sha256((v/'representative.json').read_bytes()).hexdigest())
(v/'identity.json').write_text(json.dumps(identity, indent=2), encoding='utf-8')
(v/'focused.json').write_text(json.dumps(dict(actualFrameworks=['net11.0', 'net10.0'], internalPerFramework=153,
                                             publicPerFramework=628, additionalLeasePerFramework=35,
                                             independentPythonGoldens=8, allPipelineOutputsIndependentlyVerified=True), indent=2), encoding='utf-8')
(v/'sizing.json').write_text(json.dumps(dict(jobs=4, warmupPerRoleSeconds=5, rounds=7, targetBatchSeconds=.15,
                                           expectedSeconds=130, ownerSeconds=180), indent=2), encoding='utf-8')
(v/'setup-contract.json').write_text(json.dumps(dict(ownerSeconds=180, stopSeconds=30, marginSeconds=30,
                                                   osFreeFloorMiB=240, evidenceHeadroomMiB=12, jobs=4,
                                                   unchangedWorkerAndProtocol=True), indent=2), encoding='utf-8')
(v/'pre-measurement-plan.md').write_text('''# R142 bounded confirmation

Confirm complete CSV/text/JSON generator pipelines, report control; four source-pair
jobs, four independent roles, normal GC/tiering, five-second warmups, seven rotated
150ms batches. Same source/input/golden per pair. Included clocks: mediated RAM-file
I/O, full output validation and previous-result cleanup; excludes compilation,
startup/reset/protocol/final cache teardown. Wider process CPU separate.
Keep adverse desktop JSON +6–8% and variable controls, compile allocation +1.3–1.6%.
No percentage veto or universal CPU claim. One usable bounded confirmation stops
this comparison; meaningful regression requires a debt decision before delivery.
Retain source proof/raw cores and common tooling. Join all users, remove RAM,
archive under lease and verify local SHA. No floor relaxation or background users.
''', encoding='utf-8')

with tarfile.open(v/'payload.tgz', 'w:gz') as t:
    for p in v.iterdir():
        if p.name != 'payload.tgz': t.add(p, arcname=p.name)
print('Four jobs; payload bytes', (v/'payload.tgz').stat().st_size, 'expected130s/owner180s +30stop +30margin')
