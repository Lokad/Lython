from pathlib import Path

r = Path(__file__).parent
old = r.parent/'lexical-operands-r139/b498/launch-after-space.py'
data = old.read_text(encoding='utf-8')
data = data.replace("'lexical-operands-b498-20261109'", "'generator-storage-b500-20261109'")
data = data.replace('lython-b498-lexical-operands-20261109', 'lython-b500-generator-storage-20261109')
data = data.replace('lexical-operands-b498-launch-after-space.py', 'generator-storage-b500-launch.py')
data = data.replace('assert len(jobs)==7 ', 'assert len(jobs)==4 ')
data = data.replace('ownerSeconds=240', 'ownerSeconds=180').replace('RuntimeMaxSec=240', 'RuntimeMaxSec=180')
data = data.replace('seconds=300', 'seconds=240').replace('allSevenJobsValidated', 'allFourJobsValidated')
needle = " for role in ['reference','candidate']:\n  assert hashlib.sha256"
replacement = """ for role in ['reference','candidate']:
  for target,name in [('Lokad.Lython.Benchmarks.dll','common-worker.dll'),('Lokad.Lython.Utf8Regex.dll','common-adapter.dll'),('Lokad.Lython.Benchmarks.deps.json','common-worker.deps.json'),('Lokad.Lython.Benchmarks.runtimeconfig.json','common-worker.runtimeconfig.json')]:
   (root/role/target).unlink();os.link(root/name,root/role/target)
 for role in ['reference','candidate']:
  assert hashlib.sha256"""
assert needle in data
data = data.replace(needle, replacement)
(r/'b500/launch.py').write_text(data, encoding='utf-8', newline='\n')
print('Reused finite collector/lease/headroom gates with four jobs and common frozen auxiliaries.')
