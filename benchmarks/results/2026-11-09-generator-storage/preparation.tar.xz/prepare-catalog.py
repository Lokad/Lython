from pathlib import Path
import base64, copy, hashlib, json, subprocess, tempfile

r = Path(__file__).parent
catalog = json.loads((r.parent / 'lexical-operands-r139/catalog.json').read_text(encoding='utf-8'))
selected = {}
for item in catalog['cases']:
    stem = item['id'].split('.')[1]
    selected[stem] = copy.deepcopy(item)

sources = {name: Path('benchmarks/scripts', name + '.py').read_text(encoding='utf-8')
           for name in ['csv-validated-records', 'text-summary-helpers', 'json-summary-helpers', 'report-render', 'file-search']}

csv = sources['csv-validated-records']
csv = csv.replace('totals = {}', '''def validated_records(rows):
    for row in rows:
        item = validated_record(row, minimum=0)
        if item is not None:
            yield item


totals = {}''', 1)
csv = csv.replace('''    for row in csv.DictReader(source):
        item = validated_record(row, minimum=0)
        if item is None:
            continue
        kind, amount = item''', '''    for kind, amount in validated_records(csv.DictReader(source)):''', 1)

text = sources['text-summary-helpers'].replace('''def words_from_line(line:str)->list:
    return line.lower().split()''', '''def words_from_line(line):
    for word in line.lower().split():
        yield word''', 1)

js = sources['json-summary-helpers']
js = js.replace('totals = {}', '''def records_from_lines(source):
    for line in source:
        if line.strip():
            yield json.loads(line)


totals = {}''', 1)
js = js.replace('''    for line in source:
        if line.strip():
            record = json.loads(line)
            amount = record_amount(record)
            if amount >= 0:
                kind = record['kind']
                totals[kind] = totals.get(kind, 0) + amount
                accepted += 1''', '''    for record in records_from_lines(source):
        amount = record_amount(record)
        if amount >= 0:
            kind = record['kind']
            totals[kind] = totals.get(kind, 0) + amount
            accepted += 1''', 1)

catalog['cases'] = []
proof = []
for name, body in [('csv-validated-records', csv), ('text-summary-helpers', text), ('json-summary-helpers', js),
                   ('report-render', sources['report-render']), ('file-search', sources['file-search'])]:
    item = selected[name]
    item['source'] = body
    item['id'] = 'scripts.' + name + ('.generator' if name not in ['report-render', 'file-search'] else '.control') + '.large'
    item['sourceUtf8Bytes'] = len(body.encode())
    item['sourceSha256'] = hashlib.sha256(body.encode()).hexdigest()
    fixture = json.loads(item['fixtureJson'])
    with tempfile.TemporaryDirectory(prefix='lython-r142-golden-') as folder:
        folder = Path(folder)
        for path, encoded in fixture['inputFiles'].items():
            dest = folder/path
            dest.parent.mkdir(parents=True, exist_ok=True)
            dest.write_bytes(base64.b64decode(encoded, validate=True))
        done = subprocess.run(['C:/Python313/python.exe', '-I', '-S', '-X', 'utf8', '-c', body], cwd=folder,
                              encoding='utf-8', capture_output=True)
        assert done.returncode == 0 and done.stdout == item['expectedOutput'] and not done.stderr, (item['id'], done)
        for path, encoded in fixture['outputFiles'].items():
            assert (folder/path).read_bytes() == base64.b64decode(encoded, validate=True), (item['id'], path)
        proof.append(dict(case=item['id'], source=body, sourceSHA256=item['sourceSha256'], stdout=done.stdout,
                          allOutputFilesEqual=True, fixtureSHA256=item['fixtureSha256']))
    catalog['cases'].append(item)
assert csv != sources['csv-validated-records'] and text != sources['text-summary-helpers'] and js != sources['json-summary-helpers']
(r/'catalog.json').write_text(json.dumps(catalog, ensure_ascii=False, indent=2), encoding='utf-8')
(r/'pipeline-goldens.json').write_text(json.dumps(proof, ensure_ascii=False, indent=2), encoding='utf-8')
print('Three complete generator pipeline variants + two unchanged controls: CPython stdout/files pass; fixtures unchanged.')
