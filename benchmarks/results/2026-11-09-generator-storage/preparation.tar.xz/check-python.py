from pathlib import Path
import json, re, subprocess, textwrap

root = Path(__file__).parent
source = Path('tests/Lokad.Lython.PublicApi.Tests/GeneratorStorageSemanticsTests.cs').read_text(encoding='utf-8')
cases = []
for name, body, encoded in re.findall(r'\{ "([^"]+)", """\n(.*?)\n            """, "((?:\\.|[^"\\])*)" \}', source, re.S):
    body = textwrap.dedent(body) + '\n'
    expected = json.loads('"' + encoded + '"')
    result = subprocess.run(['C:/Python313/python.exe', '-I', '-S', '-X', 'utf8', '-c', body], capture_output=True, encoding='utf-8')
    cases.append(dict(name=name, source=body, expected=expected, actual=result.stdout, stderr=result.stderr, exitCode=result.returncode))
    assert result.returncode == 0 and result.stdout == expected, cases[-1]
assert len(cases) == 8, len(cases)
(root / 'python-goldens.json').write_text(json.dumps(cases, ensure_ascii=False, indent=2), encoding='utf-8')
print('Eight independent CPython 3.13 goldens pass.')
