from pathlib import Path
import json, statistics
r = Path(__file__).parent
d = json.loads((r/'compile-sync/measurements.json').read_text(encoding='utf-8'))
out = []
for o in d['observations']:
    values = {role: statistics.median(s['allocatedBytes']/s['jobs'] for s in o['samples'] if s['image'] == role)
              for role in ['before', 'before-control', 'candidate']}
    percentages = [100 * (values['candidate'] / values[b] - 1) for b in ['before', 'before-control']]
    out.append(dict(case=o['caseId'], allocation=values, allocationPercent=percentages))
    print(o['caseId'], 'compile allocation%', [round(p, 3) for p in percentages])
(r/'compile-allocation.json').write_text(json.dumps(out, indent=2), encoding='utf-8')
