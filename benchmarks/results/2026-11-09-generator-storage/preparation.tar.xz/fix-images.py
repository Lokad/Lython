from pathlib import Path
import hashlib, json, shutil

r = Path(__file__).resolve().parent
images = r/'images'
assert images.is_relative_to(Path('D:/code/Lython').resolve())
rows = {p.name: dict(before=hashlib.sha256(p.read_bytes()).hexdigest(),
                      rebuilt=hashlib.sha256((images/'candidate'/p.name).read_bytes()).hexdigest())
        for p in (images/'before').glob('Lokad.*.dll')}
assert not (images/'rebuilt-candidate').exists()
(images/'candidate').rename(images/'rebuilt-candidate')
shutil.copytree(images/'before', images/'candidate')
shutil.copyfile(images/'rebuilt-candidate/Lokad.Lython.dll', images/'candidate/Lokad.Lython.dll')
assert all((images/'before'/p.name).read_bytes() == p.read_bytes()
           for p in (images/'candidate').glob('Lokad.*.dll') if p.name != 'Lokad.Lython.dll')
assert not (r/'initial-identity-refusal').exists()
(r/'warm-sync').rename(r/'initial-identity-refusal')
(r/'image-normalization.json').write_text(json.dumps(dict(
    reason='Fresh nonincremental builds changed worker/adapter bits despite unchanged sources. Identity guard refused before sampling. Preserve rebuilt bits; compare exactly one shared frozen worker/adapter with only core substituted.',
    rawHashes=rows, normalizedAllAuxiliaryEqual=True,
    baselineCore=rows['Lokad.Lython.dll']['before'], candidateCore=rows['Lokad.Lython.dll']['rebuilt'],
    unchangedSources={p.as_posix(): hashlib.sha256(p.read_bytes()).hexdigest()
                      for base in ['benchmarks/Lokad.Lython.Benchmarks', 'src/Lokad.Lython.Utf8Regex']
                      for p in Path(base).rglob('*.cs') if 'obj' not in p.parts}), indent=2), encoding='utf-8')
print('Original identity refusal retained; both images now use byte-identical worker/adapter/dependencies and their own core.')
