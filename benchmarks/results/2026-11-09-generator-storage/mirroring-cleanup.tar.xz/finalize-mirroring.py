from pathlib import Path
import json, shutil, subprocess, tarfile
r = Path(__file__).parent
out = Path('benchmarks/results/2026-11-09-generator-storage')
shutil.copyfile(r/'ci-terminal.json', out/'failed-delivery-ci.json')
shutil.copyfile(r/'ci-terminal.json', r/'ci-terminal-42577712653.json')
files = ['tests/Lokad.Lython.Tests/ExecutableAugmentedSubscriptTests.cs',
         'tests/Lokad.Lython.Tests/ExecutableAugmentedSliceTests.cs']
assert not subprocess.check_output(['git', 'diff', '--name-only', '--', 'src/Lokad.Lython']).strip()
(r/'mirroring-only.patch').write_bytes(subprocess.check_output(['git', 'diff', '--binary', '--', *files]))
names = ['ci-failed.log', 'ci-terminal-42577712653.json', 'stale-mirroring-before.log', 'mirroring-only.patch',
         'mirroring-cleanup-build-net11.0.log', 'mirroring-cleanup-build-net10.0.log',
         'mirroring-cleanup-net11.0.log', 'mirroring-cleanup-net10.0.log', 'finalize-mirroring.py']
with tarfile.open(out/'mirroring-cleanup.tar.xz', 'w:xz') as t:
    for name in names: t.add(r/name, arcname=name)
    for name in files: t.add(name, arcname=name)
print('Original failed delivery and four reproduced stale assertions retained; 31 focused checks pass each actual framework. No runtime change.')
