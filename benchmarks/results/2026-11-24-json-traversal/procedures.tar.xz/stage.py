from pathlib import Path
import ast
import hashlib
import json
import shutil
import tarfile

lab = Path(__file__).resolve().parent
donor = lab.with_name('json-ascii-runs-20261124')
comparison = lab/'comparison'
quiet = comparison/'quiet'
quiet.mkdir(exist_ok=True)

def emit(path, source):
    compile(source, str(path), 'exec')
    path.write_text(source, encoding='utf-8', newline='\n')

collector = (donor/'comparison/quiet/collect.py').read_text(encoding='utf-8').replace('b1585-', 'b1586-')
emit(quiet/'collect.py', collector)
shutil.copyfile(donor/'comparison/quiet/run.sh', quiet/'run.sh')
assert b'\r' not in (quiet/'run.sh').read_bytes()
payload = quiet/'payload.tar.gz'
with tarfile.open(payload, 'w:gz') as bundle:
    bundle.add(comparison/'identity.json', arcname='identity.json')
    for name in ('collect.py', 'run.sh'):
        bundle.add(quiet/name, arcname=name)
    bundle.add(lab/'candidate/Lokad.Lython.dll', arcname='candidate-core.dll')
configuration = dict(root='json-traversal-b1586-20261124', reference='json-ascii-runs-b1585-20261124',
    payloadSHA256=hashlib.sha256(payload.read_bytes()).hexdigest(), payloadBytes=payload.stat().st_size)
(quiet/'upload.json').write_text(json.dumps(configuration, indent=2)+'\n',encoding='utf-8',newline='\n')

launch = (donor/'quiet.py').read_text(encoding='utf-8').replace('b1585-json-ascii-runs-20261124', 'b1586-json-traversal-20261124').replace('b1585-', 'b1586-')
launch = launch.replace('1536 * 1024', '1024 * 1024')
launch = launch.replace("assert archive!=reference and not (archive/'guest-fixtures').exists()",
    "assert archive==reference and replica==reference/'candidate/Lokad.Lython.dll'\n     assert not (archive/'guest-fixtures').exists()")
launch = launch.replace("'needs two cores, receipts and working room'", "'needs one core, receipts and working room'")
launch = launch.replace("{'identity.json','representative.json','jobs.json','run.sh','collect.py','candidate-core.dll','reference-core.dll'}",
    "{'identity.json','run.sh','collect.py','candidate-core.dll'}")
launch = launch.replace(" assert digest(root/'representative.json')==identity['catalogs']['representative.json']['sha256']",
    " for name,meta in identity['catalogs'].items():\n  os.link(reference/name,root/name)\n  assert digest(root/name)==meta['sha256']")
launch = launch.replace("if name=='Lokad.Lython.dll':", "if name=='Lokad.Lython.dll' and role=='candidate':")
launch = launch.replace("os.link(reference/'candidate'/name,image/name)", "os.link(reference/'reference'/name,image/name)")
remote_stage, = (n.value for n in ast.walk(ast.parse(launch)) if isinstance(n, ast.Constant) and isinstance(n.value, str) and n.value.startswith('digest=lambda path:'))
compile(remote_stage, 'remote-stage', 'exec')
emit(lab/'quiet.py', launch)
