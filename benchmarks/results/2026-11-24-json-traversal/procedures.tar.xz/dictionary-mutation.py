import json


def encode(change, mode):
    record = {'first': {1}, 'next': 1}

    def fallback(value):
        if change == 'replace':
            record['next'] = 2
        elif change == 'insert':
            record['new'] = 1
        else:
            del record['next']
        return 'v'

    if mode == 'compact':
        return json.dumps(record, default=fallback)
    if mode == 'indented':
        return json.dumps(record, default=fallback, indent=0)
    if mode == 'sorted':
        return json.dumps(record, default=fallback, sort_keys=True)
    return ''.join(json.JSONEncoder(default=fallback).iterencode(record))


for mode in ('compact', 'indented', 'sorted', 'incremental'):
    for change in ('replace', 'insert', 'remove'):
        try:
            print(mode, change, repr(encode(change, mode)))
        except RuntimeError as error:
            print(mode, change, type(error).__name__, str(error))
