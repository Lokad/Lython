; Assembly listing for method Lokad.Lython.Runtime.LythonRuntime+JsonEncodeIterator+<WriteRootToBuilderAsync>d__20:MoveNext():this (FullOpts)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; FullOpts code
; optimized code
; rbp based frame
; fully interruptible
; No PGO data
; 3 inlinees with PGO data; 30 single block inlinees; 5 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       push     r15
       push     r14
       push     rdi
       push     rsi
       push     rbx
       sub      rsp, 88
       lea      rbp, [rsp+0x80]
       xor      eax, eax
       mov      qword ptr [rbp-0x58], rax
       vxorps   xmm4, xmm4, xmm4
       vmovdqu  ymmword ptr [rbp-0x50], ymm4
       mov      bword ptr [rbp+0x10], rcx
 
G_M000_IG02:                ;; offset=0x0027
       mov      edx, dword ptr [rcx+0x38]
       mov      dword ptr [rbp-0x2C], edx
 
G_M000_IG03:                ;; offset=0x002D
       cmp      dword ptr [rbp-0x2C], 0
       je       SHORT G_M000_IG04
       mov      rdx, gword ptr [rcx]
       mov      rdx, gword ptr [rdx+0xA0]
       mov      rdx, gword ptr [rdx+0x88]
       lea      rcx, bword ptr [rcx+0x28]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rcx, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rcx+0x28]
       mov      rbx, bword ptr [rbp+0x10]
       mov      r8, gword ptr [rbx+0x08]
       mov      edx, 224
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.MemoryGovernor:Reserve(long,Lokad.Lython.LythonSourceSpan):this]
       mov      rcx, rbx
 
G_M000_IG04:                ;; offset=0x006D
       cmp      dword ptr [rbp-0x2C], 0
       je       G_M000_IG07
       mov      rax, gword ptr [rcx]
       mov      rbx, gword ptr [rcx+0x08]
       mov      rsi, gword ptr [rax+0xA0]
       cmp      byte  ptr [rsi], sil
       mov      rcx, rsi
       call     [Lokad.Lython.Runtime.ExecutionState:get_CanContinue():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG05
       mov      rcx, rsi
       mov      rdx, rbx
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
 
G_M000_IG05:                ;; offset=0x00A1
       mov      rcx, 0x7FF9CD1B3370
       call     CORINFO_HELP_NEWSFAST
       mov      rbx, rax
       mov      rcx, bword ptr [rbp+0x10]
       mov      rsi, gword ptr [rcx+0x10]
       mov      rdi, gword ptr [rcx+0x18]
       mov      r14, gword ptr [rcx]
       mov      r15, gword ptr [rcx+0x08]
       test     byte  ptr [(reloc 0x7ff9cd1b9760)], 1
       je       G_M000_IG23
 
G_M000_IG06:                ;; offset=0x00D3
       mov      rdx, 0x17CC0802990
       mov      rdx, gword ptr [rdx]
       lea      rcx, bword ptr [rbx+0x20]
       call     CORINFO_HELP_ASSIGN_REF
       lea      rcx, bword ptr [rbx+0x30]
       mov      rdx, rsi
       call     CORINFO_HELP_ASSIGN_REF
       lea      rcx, bword ptr [rbx+0x08]
       mov      rdx, rdi
       call     CORINFO_HELP_ASSIGN_REF
       lea      rcx, bword ptr [rbx+0x10]
       mov      rdx, r14
       call     CORINFO_HELP_ASSIGN_REF
       lea      rcx, bword ptr [rbx+0x18]
       mov      rdx, r15
       call     CORINFO_HELP_ASSIGN_REF
       mov      rcx, bword ptr [rbp+0x10]
       lea      rcx, bword ptr [rcx+0x30]
       mov      rdx, rbx
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rcx, bword ptr [rbp+0x10]
 
G_M000_IG07:                ;; offset=0x012D
       cmp      dword ptr [rbp-0x2C], 0
       jne      SHORT G_M000_IG11
 
G_M000_IG08:                ;; offset=0x0133
       vmovdqu  xmm0, xmmword ptr [rcx+0x48]
       vmovdqu  xmmword ptr [rbp-0x40], xmm0
 
G_M000_IG09:                ;; offset=0x013D
       xor      eax, eax
       mov      qword ptr [rcx+0x48], rax
       mov      qword ptr [rcx+0x50], rax
       mov      dword ptr [rbp-0x2C], -1
       mov      dword ptr [rcx+0x38], -1
 
G_M000_IG10:                ;; offset=0x0155
       mov      rcx, bword ptr [rbp+0x10]
       mov      rbx, gword ptr [rbp-0x40]
       test     rbx, rbx
       jne      G_M000_IG16
       mov      ax, word  ptr [rbp-0x34]
       mov      word  ptr [rbp-0x58], ax
       jmp      G_M000_IG19
 
G_M000_IG11:                ;; offset=0x0173
       mov      rax, gword ptr [rcx]
       mov      rbx, gword ptr [rcx+0x08]
       mov      rsi, gword ptr [rax+0xA0]
       cmp      byte  ptr [rsi], sil
       mov      rcx, rsi
       call     [Lokad.Lython.Runtime.ExecutionState:get_CanContinue():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG12
       mov      rcx, rsi
       mov      rdx, rbx
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
 
G_M000_IG12:                ;; offset=0x019D
       mov      rbx, bword ptr [rbp+0x10]
       movzx    r9, byte  ptr [rbx+0x3C]
       mov      r8, gword ptr [rbx+0x20]
       mov      rcx, gword ptr [rbx+0x30]
       lea      rdx, [rbp-0x50]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+JsonEncodeIterator:AdvanceAsync(Lokad.Lython.Runtime.Text.GovernedByteBuilder,bool):System.Threading.Tasks.ValueTask`1[System.ValueTuple`2[bool,bool]]:this]
       mov      rdx, gword ptr [rbp-0x50]
       movzx    rcx, byte  ptr [rbp-0x44]
       movzx    rax, byte  ptr [rbp-0x43]
       movsx    r8, word  ptr [rbp-0x48]
       mov      gword ptr [rbp-0x40], rdx
       mov      word  ptr [rbp-0x38], r8w
       mov      byte  ptr [rbp-0x36], 0
       mov      byte  ptr [rbp-0x34], cl
       mov      byte  ptr [rbp-0x33], al
       mov      rsi, gword ptr [rbp-0x40]
       test     rsi, rsi
       je       G_M000_IG10
       mov      rdx, rsi
       mov      rcx, 0x7FF9CD1BAB20
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       jne      SHORT G_M000_IG15
       mov      rcx, rsi
       movsx    rdx, word  ptr [rbp-0x38]
       mov      r11, 0x7FF9CC8F2CB8
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[System.ValueTuple`2[bool,bool]]:GetStatus(short):int:this
       test     eax, eax
       jne      G_M000_IG10
 
G_M000_IG13:                ;; offset=0x021F
       xor      ecx, ecx
       mov      dword ptr [rbp-0x2C], ecx
 
G_M000_IG14:                ;; offset=0x0224
       mov      rbx, bword ptr [rbp+0x10]
       mov      dword ptr [rbx+0x38], ecx
       lea      rsi, bword ptr [rbx+0x48]
       mov      rdx, gword ptr [rbp-0x40]
       mov      rcx, rsi
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rdx, qword ptr [rbp-0x38]
       mov      qword ptr [rsi+0x08], rdx
       lea      rdx, bword ptr [rbx+0x40]
       mov      rcx, rbx
       call     [System.Runtime.CompilerServices.AsyncTaskMethodBuilder`1[System.Threading.Tasks.VoidTaskResult]:GetStateMachineBox[Lokad.Lython.Runtime.LythonRuntime+JsonEncodeIterator+<WriteRootToBuilderAsync>d__20](byref,byref):System.Runtime.CompilerServices.IAsyncStateMachineBox]
       mov      rdx, rax
       lea      rcx, [rbp-0x40]
       call     [System.Runtime.CompilerServices.AsyncTaskMethodBuilder`1[System.Threading.Tasks.VoidTaskResult]:AwaitUnsafeOnCompleted[System.Runtime.CompilerServices.ConfiguredValueTaskAwaitable`1+ConfiguredValueTaskAwaiter[System.ValueTuple`2[bool,bool]]](byref,System.Runtime.CompilerServices.IAsyncStateMachineBox)]
       jmp      G_M000_IG22
 
G_M000_IG15:                ;; offset=0x0262
       test     dword ptr [rax+0x34], 0x1600000
       jne      G_M000_IG10
       jmp      SHORT G_M000_IG13
 
G_M000_IG16:                ;; offset=0x0271
       mov      rdx, rbx
       mov      rcx, 0x7FF9CD1BAB20
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       mov      rsi, rax
       test     rsi, rsi
       jne      SHORT G_M000_IG17
       mov      rcx, rbx
       movsx    rdx, word  ptr [rbp-0x38]
       mov      r11, 0x7FF9CC8F2CC0
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[System.ValueTuple`2[bool,bool]]:GetResult(short):System.ValueTuple`2[bool,bool]:this
       mov      word  ptr [rbp-0x58], ax
       mov      rcx, bword ptr [rbp+0x10]
       jmp      SHORT G_M000_IG19
 
G_M000_IG17:                ;; offset=0x02AA
       mov      ecx, dword ptr [rsi+0x34]
       and      ecx, 0x11000000
       cmp      ecx, 0x1000000
       jne      SHORT G_M000_IG20
 
G_M000_IG18:                ;; offset=0x02BB
       mov      cx, word  ptr [rsi+0x38]
       mov      word  ptr [rbp-0x58], cx
       mov      rcx, bword ptr [rbp+0x10]
 
G_M000_IG19:                ;; offset=0x02C7
       cmp      byte  ptr [rbp-0x58], 0
       jne      G_M000_IG11
       jmp      SHORT G_M000_IG21
 
G_M000_IG20:                ;; offset=0x02D3
       mov      rcx, rsi
       xor      edx, edx
       call     [System.Runtime.CompilerServices.TaskAwaiter:HandleNonSuccessAndDebuggerNotification(System.Threading.Tasks.Task,int)]
       jmp      SHORT G_M000_IG18
 
G_M000_IG21:                ;; offset=0x02E0
       cmp      dword ptr [rbp-0x2C], 0
       jge      SHORT G_M000_IG24
       mov      rcx, gword ptr [rcx+0x30]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+JsonEncodeIterator:Finish():this]
       mov      rcx, bword ptr [rbp+0x10]
       jmp      SHORT G_M000_IG24
 
G_M000_IG22:                ;; offset=0x02F8
       call     G_M000_IG32
       jmp      SHORT G_M000_IG25
 
G_M000_IG23:                ;; offset=0x02FF
       mov      rcx, 0x7FF9CD1B96D8
       call     CORINFO_HELP_GET_GCSTATIC_BASE
       jmp      G_M000_IG06
 
G_M000_IG24:                ;; offset=0x0313
       call     G_M000_IG35
       jmp      SHORT G_M000_IG27
 
G_M000_IG25:                ;; offset=0x031A
       cmp      dword ptr [rbp-0x2C], 0
       jge      SHORT G_M000_IG29
       mov      rbx, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rbx+0x28]
       mov      rdx, qword ptr [rcx+0x28]
       mov      rax, rdx
       mov      r8d, 224
       cmp      rax, 224
       cmovl    r8, rax
       test     r8, r8
       je       SHORT G_M000_IG29
       sub      rdx, r8
       mov      qword ptr [rcx+0x28], rdx
       add      rdx, qword ptr [rcx+0x30]
       jo       SHORT G_M000_IG26
       call     [Lokad.Lython.Runtime.MemoryGovernor:ResizeOwnership(long):bool:this]
       jmp      SHORT G_M000_IG29
 
G_M000_IG26:                ;; offset=0x0359
       call     CORINFO_HELP_OVERFLOW
       int3     
 
G_M000_IG27:                ;; offset=0x035F
       mov      rbx, bword ptr [rbp+0x10]
       mov      dword ptr [rbx+0x38], -2
       xor      rcx, rcx
       mov      gword ptr [rbx+0x28], rcx
       lea      rcx, bword ptr [rbx+0x40]
       cmp      gword ptr [rcx], 0
       jne      SHORT G_M000_IG31
 
G_M000_IG28:                ;; offset=0x037A
       mov      rdx, 0x17CC0802360
       mov      rdx, gword ptr [rdx]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
 
G_M000_IG29:                ;; offset=0x038C
       nop      
 
G_M000_IG30:                ;; offset=0x038D
       add      rsp, 88
       pop      rbx
       pop      rsi
       pop      rdi
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG31:                ;; offset=0x039A
       mov      rcx, gword ptr [rcx]
       xor      edx, edx
       call     [System.Runtime.CompilerServices.AsyncTaskMethodBuilder`1[System.Threading.Tasks.VoidTaskResult]:SetExistingTaskResult(System.Threading.Tasks.Task`1[System.Threading.Tasks.VoidTaskResult],System.Threading.Tasks.VoidTaskResult)]
       jmp      SHORT G_M000_IG29
 
G_M000_IG32:                ;; offset=0x03A7
       sub      rsp, 40
 
G_M000_IG33:                ;; offset=0x03AB
       cmp      dword ptr [rbp-0x2C], 0
       jge      SHORT G_M000_IG34
       mov      rbx, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rbx+0x30]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+JsonEncodeIterator:Finish():this]
       nop      
 
G_M000_IG34:                ;; offset=0x03C2
       add      rsp, 40
       ret      
 
G_M000_IG35:                ;; offset=0x03C7
       sub      rsp, 40
 
G_M000_IG36:                ;; offset=0x03CB
       cmp      dword ptr [rbp-0x2C], 0
       jge      SHORT G_M000_IG37
       mov      rbx, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rbx+0x28]
       mov      rdx, qword ptr [rcx+0x28]
       mov      rax, rdx
       mov      r8d, 224
       cmp      rax, 224
       cmovl    r8, rax
       test     r8, r8
       je       SHORT G_M000_IG37
       sub      rdx, r8
       mov      qword ptr [rcx+0x28], rdx
       add      rdx, qword ptr [rcx+0x30]
       jo       SHORT G_M000_IG38
       call     [Lokad.Lython.Runtime.MemoryGovernor:ResizeOwnership(long):bool:this]
       nop      
 
G_M000_IG37:                ;; offset=0x0409
       add      rsp, 40
       ret      
 
G_M000_IG38:                ;; offset=0x040E
       call     CORINFO_HELP_OVERFLOW
       int3     
 
G_M000_IG39:                ;; offset=0x0414
       sub      rsp, 40
 
G_M000_IG40:                ;; offset=0x0418
       mov      rdx, rcx
       mov      rbx, bword ptr [rbp+0x10]
       mov      dword ptr [rbx+0x38], -2
       xor      rcx, rcx
       mov      gword ptr [rbx+0x28], rcx
       lea      rcx, bword ptr [rbx+0x40]
       call     [System.Runtime.CompilerServices.AsyncValueTaskMethodBuilder:SetException(System.Exception):this]
       lea      rax, G_M000_IG29
 
G_M000_IG41:                ;; offset=0x043D
       add      rsp, 40
       ret      
 
; Total bytes of code 1090

; Assembly listing for method Lokad.Lython.Runtime.LythonRuntime+JsonEncodeIterator:AdvanceAsync(Lokad.Lython.Runtime.Text.GovernedByteBuilder,bool):System.Threading.Tasks.ValueTask`1[System.ValueTuple`2[bool,bool]]:this (FullOpts)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; FullOpts code
; optimized code
; rsp based frame
; partially interruptible
; No PGO data
; 1 inlinees with PGO data; 19 single block inlinees; 7 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     r15
       push     r14
       push     r13
       push     r12
       push     rdi
       push     rsi
       push     rbp
       push     rbx
       sub      rsp, 120
       xor      eax, eax
       mov      qword ptr [rsp+0x38], rax
       vxorps   xmm4, xmm4, xmm4
       vmovdqu  ymmword ptr [rsp+0x40], ymm4
       vmovdqa  xmmword ptr [rsp+0x60], xmm4
       mov      qword ptr [rsp+0x70], rax
       mov      rbx, rcx
       mov      rdi, rdx
       mov      rsi, r8
       mov      ebp, r9d
 
G_M000_IG02:                ;; offset=0x0038
       mov      r8, gword ptr [rbx+0x30]
       test     r8, r8
       jne      G_M000_IG28
 
G_M000_IG03:                ;; offset=0x0045
       cmp      dword ptr [rbx+0x40], 0
       je       SHORT G_M000_IG08
 
G_M000_IG04:                ;; offset=0x004B
       mov      r14d, dword ptr [rbx+0x40]
       dec      r14d
       jne      SHORT G_M000_IG06
 
G_M000_IG05:                ;; offset=0x0054
       lea      r15, bword ptr [rbx+0x50]
       jmp      SHORT G_M000_IG07
 
G_M000_IG06:                ;; offset=0x005A
       mov      rcx, gword ptr [rbx+0x20]
       lea      eax, [r14-0x01]
       cmp      eax, dword ptr [rcx+0x08]
       jae      G_M000_IG33
       lea      rax, [rax+8*rax]
       lea      r15, bword ptr [rcx+8*rax+0x10]
 
G_M000_IG07:                ;; offset=0x0074
       cmp      byte  ptr [r15+0x2C], 0
       je       SHORT G_M000_IG09
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+JsonEncodeIterator:CloseFrame():this]
       cmp      dword ptr [rbx+0x40], 0
       jne      SHORT G_M000_IG04
 
G_M000_IG08:                ;; offset=0x008A
       xor      rcx, rcx
       mov      gword ptr [rdi], rcx
       mov      word  ptr [rdi+0x08], 0
       mov      byte  ptr [rdi+0x0A], 1
       mov      word  ptr [rdi+0x0C], 0
       jmp      G_M000_IG29
 
G_M000_IG09:                ;; offset=0x00A4
       cmp      byte  ptr [r15+0x2D], 0
       je       G_M000_IG25
       mov      r13, gword ptr [r15+0x08]
       test     r13, r13
       jne      G_M000_IG18
       movzx    r9, bpl
       lea      rdx, [rsp+0x50]
       mov      rcx, rbx
       mov      r8d, r14d
       call     [Lokad.Lython.Runtime.LythonRuntime+JsonEncodeIterator:TryTakePairAsync(int,bool):System.Threading.Tasks.ValueTask`1[System.ValueTuple`3[bool,System.Object,System.Object]]:this]
       mov      r15, gword ptr [rsp+0x50]
       test     r15, r15
       je       SHORT G_M000_IG12
       mov      rdx, r15
       mov      rcx, 0x7FF9CD1BE0F0
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       jne      SHORT G_M000_IG11
       mov      rcx, r15
       movsx    rdx, word  ptr [rsp+0x58]
       mov      r11, 0x7FF9CC8F2CD8
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[System.ValueTuple`3[bool,System.__Canon,System.__Canon]]:GetStatus(short):int:this
       test     eax, eax
       jne      SHORT G_M000_IG12
 
G_M000_IG10:                ;; offset=0x010C
       mov      gword ptr [rsp+0x20], rsi
       movzx    r8, bpl
       mov      dword ptr [rsp+0x28], r8d
       lea      r8, [rsp+0x50]
       mov      rcx, rbx
       mov      rdx, rdi
       mov      r9d, r14d
       call     [Lokad.Lython.Runtime.LythonRuntime+JsonEncodeIterator:CompletePairAsync(System.Threading.Tasks.ValueTask`1[System.ValueTuple`3[bool,System.Object,System.Object]],int,Lokad.Lython.Runtime.Text.GovernedByteBuilder,bool):System.Threading.Tasks.ValueTask`1[System.ValueTuple`2[bool,bool]]:this]
       jmp      G_M000_IG29
 
G_M000_IG11:                ;; offset=0x0133
       test     dword ptr [rax+0x34], 0x1600000
       je       SHORT G_M000_IG10
 
G_M000_IG12:                ;; offset=0x013C
       mov      r13, gword ptr [rsp+0x50]
       movsx    r15, word  ptr [rsp+0x58]
       test     r13, r13
       je       SHORT G_M000_IG16
       mov      rdx, r13
       mov      rcx, 0x7FF9CD1BE0F0
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       mov      r12, rax
       test     r12, r12
       jne      SHORT G_M000_IG13
       lea      rdx, [rsp+0x38]
       mov      rcx, r13
       mov      r8d, r15d
       mov      r11, 0x7FF9CC8F2CE0
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[System.ValueTuple`3[bool,System.__Canon,System.__Canon]]:GetResult(short):System.ValueTuple`3[bool,System.__Canon,System.__Canon]:this
       jmp      SHORT G_M000_IG17
 
G_M000_IG13:                ;; offset=0x0180
       mov      ecx, dword ptr [r12+0x34]
       and      ecx, 0x11000000
       cmp      ecx, 0x1000000
       jne      G_M000_IG32
 
G_M000_IG14:                ;; offset=0x0197
       vmovdqu  xmm0, xmmword ptr [r12+0x38]
       vmovdqu  xmmword ptr [rsp+0x38], xmm0
       mov      r9, qword ptr [r12+0x48]
       mov      qword ptr [rsp+0x48], r9
 
G_M000_IG15:                ;; offset=0x01AE
       jmp      SHORT G_M000_IG17
 
G_M000_IG16:                ;; offset=0x01B0
       vmovdqu  xmm0, xmmword ptr [rsp+0x60]
       vmovdqu  xmmword ptr [rsp+0x38], xmm0
       mov      r9, qword ptr [rsp+0x70]
       mov      qword ptr [rsp+0x48], r9
 
G_M000_IG17:                ;; offset=0x01C6
       mov      gword ptr [rsp+0x20], rsi
       movzx    r9, bpl
       mov      dword ptr [rsp+0x28], r9d
       lea      r9, [rsp+0x38]
       mov      rcx, rbx
       mov      rdx, rdi
       mov      r8d, r14d
       call     [Lokad.Lython.Runtime.LythonRuntime+JsonEncodeIterator:AdvancePairAsync(int,System.ValueTuple`3[bool,System.Object,System.Object],Lokad.Lython.Runtime.Text.GovernedByteBuilder,bool):System.Threading.Tasks.ValueTask`1[System.ValueTuple`2[bool,bool]]:this]
       jmp      G_M000_IG29
 
G_M000_IG18:                ;; offset=0x01ED
       mov      r14d, dword ptr [r15+0x28]
       mov      r12d, dword ptr [r15+0x24]
       mov      rcx, r13
       mov      r11, 0x7FF9CC8F2CC8
       call     [r11]System.Collections.Generic.IReadOnlyCollection`1[System.__Canon]:get_Count():int:this
       cmp      eax, r12d
       jle      G_M000_IG20
       mov      rcx, r13
       mov      edx, r12d
       mov      r11, 0x7FF9CC8F2CD0
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       mov      r13, rax
       test     r12d, r12d
       jle      SHORT G_M000_IG19
       mov      rdx, gword ptr [rbx+0x08]
       mov      rdx, gword ptr [rdx+0x20]
       mov      r9, gword ptr [rbx+0x18]
       mov      r8, gword ptr [rbx+0x10]
       mov      rcx, rsi
       call     [Lokad.Lython.Runtime.LythonRuntime+JsonModule:AppendSeparator(Lokad.Lython.Runtime.Text.GovernedByteBuilder,Lokad.Lython.Runtime.Text.PyString,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan)]
 
G_M000_IG19:                ;; offset=0x0242
       mov      rdx, gword ptr [rbx+0x18]
       mov      gword ptr [rsp+0x20], rdx
       mov      rdx, gword ptr [rbx+0x08]
       mov      rdx, gword ptr [rdx+0x18]
       mov      r9, gword ptr [rbx+0x10]
       lea      r8d, [r14+0x01]
       mov      rcx, rsi
       call     [Lokad.Lython.Runtime.LythonRuntime+JsonModule:AppendJsonIndent(Lokad.Lython.Runtime.Text.GovernedByteBuilder,Lokad.Lython.Runtime.Text.PyString,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan)]
       inc      dword ptr [r15+0x24]
       mov      gword ptr [rsp+0x20], rsi
       movzx    r9, bpl
       mov      dword ptr [rsp+0x28], r9d
       xor      r9d, r9d
       mov      dword ptr [rsp+0x30], r9d
       lea      r9d, [r14+0x01]
       mov      rcx, rbx
       mov      rdx, rdi
       mov      r8, r13
       call     [Lokad.Lython.Runtime.LythonRuntime+JsonEncodeIterator:AdvanceValueAsync(System.Object,int,Lokad.Lython.Runtime.Text.GovernedByteBuilder,bool,int):System.Threading.Tasks.ValueTask`1[System.ValueTuple`2[bool,bool]]:this]
       jmp      G_M000_IG29
 
G_M000_IG20:                ;; offset=0x0296
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+JsonEncodeIterator:CloseFrame():this]
       test     r12d, r12d
       jle      SHORT G_M000_IG23
       mov      rcx, gword ptr [rbx+0x08]
       mov      r15, gword ptr [rcx+0x18]
       mov      rbp, gword ptr [rbx+0x10]
       mov      rbx, gword ptr [rbx+0x18]
       test     r15, r15
       je       SHORT G_M000_IG23
       mov      edx, dword ptr [rsi+0x28]
       cmp      edx, 0x7FFFFFFE
       jg       G_M000_IG31
       inc      edx
       mov      rcx, gword ptr [rsi+0x08]
       cmp      dword ptr [rcx+0x08], edx
       jge      SHORT G_M000_IG21
       mov      rcx, rsi
       xor      r8, r8
       call     [Lokad.Lython.Runtime.Text.GovernedByteBuilder:Grow(int,System.Threading.CancellationToken):this]
 
G_M000_IG21:                ;; offset=0x02DF
       mov      rcx, gword ptr [rsi+0x08]
       mov      edx, dword ptr [rsi+0x28]
       lea      r8d, [rdx+0x01]
       mov      dword ptr [rsi+0x28], r8d
       cmp      edx, dword ptr [rcx+0x08]
       jae      G_M000_IG33
       mov      byte  ptr [rcx+rdx+0x10], 10
       test     r14d, r14d
       jle      SHORT G_M000_IG23
 
G_M000_IG22:                ;; offset=0x0301
       mov      rcx, rsi
       mov      rdx, r15
       mov      r8, rbp
       mov      r9, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+JsonModule:AppendSeparator(Lokad.Lython.Runtime.Text.GovernedByteBuilder,Lokad.Lython.Runtime.Text.PyString,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan)]
       dec      r14d
       jne      SHORT G_M000_IG22
 
G_M000_IG23:                ;; offset=0x0318
       mov      edx, dword ptr [rsi+0x28]
       cmp      edx, 0x7FFFFFFE
       jg       G_M000_IG31
       inc      edx
       mov      rcx, gword ptr [rsi+0x08]
       cmp      dword ptr [rcx+0x08], edx
       jge      SHORT G_M000_IG24
       mov      rcx, rsi
       xor      r8, r8
       call     [Lokad.Lython.Runtime.Text.GovernedByteBuilder:Grow(int,System.Threading.CancellationToken):this]
 
G_M000_IG24:                ;; offset=0x033E
       mov      rcx, gword ptr [rsi+0x08]
       mov      edx, dword ptr [rsi+0x28]
       lea      r8d, [rdx+0x01]
       mov      dword ptr [rsi+0x28], r8d
       cmp      edx, dword ptr [rcx+0x08]
       jae      G_M000_IG33
       mov      byte  ptr [rcx+rdx+0x10], 93
       jmp      SHORT G_M000_IG27
 
G_M000_IG25:                ;; offset=0x035D
       mov      rcx, rbx
       mov      rdx, r15
       mov      r8d, r14d
       call     [Lokad.Lython.Runtime.LythonRuntime+JsonEncodeIterator:OpenFrame(byref,int):this]
       mov      ebx, 91
       mov      ecx, 123
       cmp      gword ptr [r15+0x08], 0
       cmove    ebx, ecx
       mov      edx, dword ptr [rsi+0x28]
       cmp      edx, 0x7FFFFFFE
       jg       G_M000_IG31
       inc      edx
       mov      rcx, gword ptr [rsi+0x08]
       cmp      dword ptr [rcx+0x08], edx
       jge      SHORT G_M000_IG26
       mov      rcx, rsi
       xor      r8, r8
       call     [Lokad.Lython.Runtime.Text.GovernedByteBuilder:Grow(int,System.Threading.CancellationToken):this]
 
G_M000_IG26:                ;; offset=0x03A4
       mov      rdx, gword ptr [rsi+0x08]
       mov      ecx, dword ptr [rsi+0x28]
       lea      eax, [rcx+0x01]
       mov      dword ptr [rsi+0x28], eax
       cmp      ecx, dword ptr [rdx+0x08]
       jae      G_M000_IG33
       mov      byte  ptr [rdx+rcx+0x10], bl
 
G_M000_IG27:                ;; offset=0x03BE
       xor      rdx, rdx
       mov      gword ptr [rdi], rdx
       mov      word  ptr [rdi+0x08], 0
       mov      byte  ptr [rdi+0x0A], 1
       mov      word  ptr [rdi+0x0C], 257
       jmp      SHORT G_M000_IG29
 
G_M000_IG28:                ;; offset=0x03D5
       xor      rcx, rcx
       mov      gword ptr [rbx+0x30], rcx
       mov      gword ptr [rsp+0x20], rsi
       movzx    rcx, bpl
       mov      dword ptr [rsp+0x28], ecx
       xor      ecx, ecx
       mov      dword ptr [rsp+0x30], ecx
       mov      rcx, rbx
       mov      rdx, rdi
       xor      r9d, r9d
       call     [Lokad.Lython.Runtime.LythonRuntime+JsonEncodeIterator:AdvanceValueAsync(System.Object,int,Lokad.Lython.Runtime.Text.GovernedByteBuilder,bool,int):System.Threading.Tasks.ValueTask`1[System.ValueTuple`2[bool,bool]]:this]
 
G_M000_IG29:                ;; offset=0x03FD
       mov      rax, rdi
 
G_M000_IG30:                ;; offset=0x0400
       add      rsp, 120
       pop      rbx
       pop      rbp
       pop      rsi
       pop      rdi
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       ret      
 
G_M000_IG31:                ;; offset=0x0411
       mov      rdx, gword ptr [rsi+0x18]
       mov      rcx, 0x19CE7505AA0
       call     [Lokad.Lython.Runtime.RuntimeErrors:Runtime(System.String,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.LythonRuntimeException]
       mov      rcx, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG32:                ;; offset=0x042E
       mov      rcx, r12
       xor      edx, edx
       call     [System.Runtime.CompilerServices.TaskAwaiter:HandleNonSuccessAndDebuggerNotification(System.Threading.Tasks.Task,int)]
       jmp      G_M000_IG14
 
G_M000_IG33:                ;; offset=0x043E
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
; Total bytes of code 1092

