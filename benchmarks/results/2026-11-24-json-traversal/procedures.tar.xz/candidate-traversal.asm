; Assembly listing for method Lokad.Lython.Runtime.LythonRuntime+JsonEncodeIterator+<WriteRootToBuilderAsync>d__20:MoveNext():this (FullOpts)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; FullOpts code
; optimized code
; rbp based frame
; fully interruptible
; No PGO data
; 5 inlinees with PGO data; 28 single block inlinees; 2 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       push     r15
       push     r14
       push     rdi
       push     rsi
       push     rbx
       sub      rsp, 88
       lea      rbp, [rsp+0x80]
       vxorps   xmm4, xmm4, xmm4
       vmovdqu  ymmword ptr [rbp-0x50], ymm4
       mov      bword ptr [rbp+0x10], rcx
 
G_M000_IG02:                ;; offset=0x0021
       mov      edx, dword ptr [rcx+0x38]
       mov      dword ptr [rbp-0x2C], edx
 
G_M000_IG03:                ;; offset=0x0027
       cmp      dword ptr [rbp-0x2C], 0
       je       SHORT G_M000_IG04
       mov      rdx, gword ptr [rcx]
       mov      rdx, gword ptr [rdx+0xA0]
       mov      rdx, gword ptr [rdx+0x88]
       lea      rcx, bword ptr [rcx+0x28]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rcx, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rcx+0x28]
       mov      rbx, bword ptr [rbp+0x10]
       mov      r8, gword ptr [rbx+0x08]
       mov      edx, 224
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.MemoryGovernor:Reserve(long,Lokad.Lython.LythonSourceSpan):this]
       mov      rcx, rbx
 
G_M000_IG04:                ;; offset=0x0067
       cmp      dword ptr [rbp-0x2C], 0
       je       G_M000_IG07
       mov      rax, gword ptr [rcx]
       mov      rbx, gword ptr [rcx+0x08]
       mov      rsi, gword ptr [rax+0xA0]
       cmp      byte  ptr [rsi], sil
       mov      rcx, rsi
       call     [Lokad.Lython.Runtime.ExecutionState:get_CanContinue():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG05
       mov      rcx, rsi
       mov      rdx, rbx
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
 
G_M000_IG05:                ;; offset=0x009B
       mov      rcx, 0x7FF9CD1D32B0
       call     CORINFO_HELP_NEWSFAST
       mov      rbx, rax
       mov      rcx, bword ptr [rbp+0x10]
       mov      rsi, gword ptr [rcx+0x10]
       mov      rdi, gword ptr [rcx+0x18]
       mov      r14, gword ptr [rcx]
       mov      r15, gword ptr [rcx+0x08]
       test     byte  ptr [(reloc 0x7ff9cd1d87f8)], 1
       je       G_M000_IG20
 
G_M000_IG06:                ;; offset=0x00CD
       mov      rdx, 0x1C953402988
       mov      rdx, gword ptr [rdx]
       lea      rcx, bword ptr [rbx+0x20]
       call     CORINFO_HELP_ASSIGN_REF
       lea      rcx, bword ptr [rbx+0x30]
       mov      rdx, rsi
       call     CORINFO_HELP_ASSIGN_REF
       lea      rcx, bword ptr [rbx+0x08]
       mov      rdx, rdi
       call     CORINFO_HELP_ASSIGN_REF
       lea      rcx, bword ptr [rbx+0x10]
       mov      rdx, r14
       call     CORINFO_HELP_ASSIGN_REF
       lea      rcx, bword ptr [rbx+0x18]
       mov      rdx, r15
       call     CORINFO_HELP_ASSIGN_REF
       mov      rcx, bword ptr [rbp+0x10]
       lea      rcx, bword ptr [rcx+0x30]
       mov      rdx, rbx
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rcx, bword ptr [rbp+0x10]
 
G_M000_IG07:                ;; offset=0x0127
       cmp      dword ptr [rbp-0x2C], 0
       jne      SHORT G_M000_IG10
       lea      rbx, bword ptr [rcx+0x48]
 
G_M000_IG08:                ;; offset=0x0131
       vmovdqu  xmm0, xmmword ptr [rbx]
       vmovdqu  xmmword ptr [rbp-0x40], xmm0
 
G_M000_IG09:                ;; offset=0x013A
       xor      r9d, r9d
       mov      qword ptr [rbx], r9
       mov      qword ptr [rbx+0x08], r9
       mov      dword ptr [rbp-0x2C], -1
       mov      dword ptr [rcx+0x38], -1
       jmp      SHORT G_M000_IG11
 
G_M000_IG10:                ;; offset=0x0154
       xor      r9d, r9d
       mov      dword ptr [rsp+0x20], r9d
       movzx    r9, byte  ptr [rcx+0x3C]
       mov      r8, gword ptr [rcx+0x20]
       mov      rcx, gword ptr [rcx+0x30]
       lea      rdx, [rbp-0x50]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+JsonEncodeIterator:EmitAsync(Lokad.Lython.Runtime.Text.GovernedByteBuilder,bool,bool):System.Threading.Tasks.ValueTask`1[bool]:this]
       mov      rdx, gword ptr [rbp-0x50]
       movzx    rcx, byte  ptr [rbp-0x46]
       movsx    rax, word  ptr [rbp-0x48]
       mov      gword ptr [rbp-0x40], rdx
       mov      word  ptr [rbp-0x38], ax
       mov      byte  ptr [rbp-0x36], cl
       mov      byte  ptr [rbp-0x35], 0
       mov      rbx, gword ptr [rbp-0x40]
       test     rbx, rbx
       jne      SHORT G_M000_IG12
 
G_M000_IG11:                ;; offset=0x019A
       mov      rbx, gword ptr [rbp-0x40]
       test     rbx, rbx
       je       G_M000_IG18
       jmp      G_M000_IG16
 
G_M000_IG12:                ;; offset=0x01AC
       mov      rdx, rbx
       mov      rcx, 0x7FF9CD0CCE58
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG13
       test     dword ptr [rax+0x34], 0x1600000
       setne    sil
       movzx    rsi, sil
       jmp      SHORT G_M000_IG14
 
G_M000_IG13:                ;; offset=0x01D4
       mov      rcx, rbx
       movsx    rdx, word  ptr [rbp-0x38]
       mov      r11, 0x7FF9CC912CB8
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[bool]:GetStatus(short):int:this
       test     eax, eax
       setne    sil
       movzx    rsi, sil
 
G_M000_IG14:                ;; offset=0x01F3
       test     esi, esi
       jne      SHORT G_M000_IG11
       xor      ecx, ecx
       mov      dword ptr [rbp-0x2C], ecx
 
G_M000_IG15:                ;; offset=0x01FC
       mov      rbx, bword ptr [rbp+0x10]
       mov      dword ptr [rbx+0x38], ecx
       lea      rcx, bword ptr [rbx+0x48]
       mov      rsi, rcx
       mov      rdx, gword ptr [rbp-0x40]
       mov      rcx, rsi
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rdx, qword ptr [rbp-0x38]
       mov      qword ptr [rsi+0x08], rdx
       lea      rdx, bword ptr [rbx+0x40]
       mov      rcx, rbx
       call     [System.Runtime.CompilerServices.AsyncTaskMethodBuilder`1[System.Threading.Tasks.VoidTaskResult]:GetStateMachineBox[Lokad.Lython.Runtime.LythonRuntime+JsonEncodeIterator+<WriteRootToBuilderAsync>d__20](byref,byref):System.Runtime.CompilerServices.IAsyncStateMachineBox]
       mov      rdx, rax
       lea      rcx, [rbp-0x40]
       call     [System.Runtime.CompilerServices.AsyncTaskMethodBuilder`1[System.Threading.Tasks.VoidTaskResult]:AwaitUnsafeOnCompleted[System.Runtime.CompilerServices.ConfiguredValueTaskAwaitable`1+ConfiguredValueTaskAwaiter[bool]](byref,System.Runtime.CompilerServices.IAsyncStateMachineBox)]
       jmp      G_M000_IG21
 
G_M000_IG16:                ;; offset=0x023D
       mov      rdx, rbx
       mov      rcx, 0x7FF9CD0CCE58
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG17
       mov      ecx, dword ptr [rax+0x34]
       and      ecx, 0x11000000
       cmp      ecx, 0x1000000
       je       SHORT G_M000_IG18
       mov      rcx, rax
       xor      edx, edx
       call     [System.Runtime.CompilerServices.TaskAwaiter:HandleNonSuccessAndDebuggerNotification(System.Threading.Tasks.Task,int)]
       jmp      SHORT G_M000_IG18
 
G_M000_IG17:                ;; offset=0x0272
       mov      rcx, rbx
       movsx    rdx, word  ptr [rbp-0x38]
       mov      r11, 0x7FF9CC912CC0
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[bool]:GetResult(short):bool:this
       nop      
 
G_M000_IG18:                ;; offset=0x0288
       cmp      dword ptr [rbp-0x2C], 0
       jge      SHORT G_M000_IG19
       mov      rbx, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rbx+0x30]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+JsonEncodeIterator:Finish():this]
       nop      
 
G_M000_IG19:                ;; offset=0x029F
       xor      rdx, rdx
       mov      rbx, bword ptr [rbp+0x10]
       mov      gword ptr [rbx+0x30], rdx
       jmp      SHORT G_M000_IG22
 
G_M000_IG20:                ;; offset=0x02AB
       mov      rcx, 0x7FF9CD1D8770
       call     CORINFO_HELP_GET_GCSTATIC_BASE
       jmp      G_M000_IG06
 
G_M000_IG21:                ;; offset=0x02BF
       call     G_M000_IG30
       jmp      SHORT G_M000_IG23
 
G_M000_IG22:                ;; offset=0x02C6
       cmp      dword ptr [rbp-0x2C], 0
       jge      SHORT G_M000_IG25
       mov      rcx, gword ptr [rbx+0x28]
       mov      rdx, qword ptr [rcx+0x28]
       mov      rax, rdx
       mov      r8d, 224
       cmp      rax, 224
       cmovl    r8, rax
       test     r8, r8
       je       SHORT G_M000_IG25
       sub      rdx, r8
       mov      qword ptr [rcx+0x28], rdx
       add      rdx, qword ptr [rcx+0x30]
       jo       SHORT G_M000_IG24
       call     [Lokad.Lython.Runtime.MemoryGovernor:ResizeOwnership(long):bool:this]
       jmp      SHORT G_M000_IG25
 
G_M000_IG23:                ;; offset=0x0301
       call     G_M000_IG33
       jmp      SHORT G_M000_IG27
 
G_M000_IG24:                ;; offset=0x0308
       call     CORINFO_HELP_OVERFLOW
       int3     
 
G_M000_IG25:                ;; offset=0x030E
       mov      dword ptr [rbx+0x38], -2
       xor      rcx, rcx
       mov      gword ptr [rbx+0x28], rcx
       lea      rcx, bword ptr [rbx+0x40]
       cmp      gword ptr [rcx], 0
       jne      SHORT G_M000_IG29
 
G_M000_IG26:                ;; offset=0x0325
       mov      rdx, 0x1C953402360
       mov      rdx, gword ptr [rdx]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
 
G_M000_IG27:                ;; offset=0x0337
       nop      
 
G_M000_IG28:                ;; offset=0x0338
       add      rsp, 88
       pop      rbx
       pop      rsi
       pop      rdi
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG29:                ;; offset=0x0345
       mov      rcx, gword ptr [rcx]
       xor      edx, edx
       call     [System.Runtime.CompilerServices.AsyncTaskMethodBuilder`1[System.Threading.Tasks.VoidTaskResult]:SetExistingTaskResult(System.Threading.Tasks.Task`1[System.Threading.Tasks.VoidTaskResult],System.Threading.Tasks.VoidTaskResult)]
       jmp      SHORT G_M000_IG27
 
G_M000_IG30:                ;; offset=0x0352
       sub      rsp, 40
 
G_M000_IG31:                ;; offset=0x0356
       cmp      dword ptr [rbp-0x2C], 0
       jge      SHORT G_M000_IG32
       mov      rbx, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rbx+0x30]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+JsonEncodeIterator:Finish():this]
       nop      
 
G_M000_IG32:                ;; offset=0x036D
       add      rsp, 40
       ret      
 
G_M000_IG33:                ;; offset=0x0372
       sub      rsp, 40
 
G_M000_IG34:                ;; offset=0x0376
       cmp      dword ptr [rbp-0x2C], 0
       jge      SHORT G_M000_IG35
       mov      rbx, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rbx+0x28]
       mov      rdx, qword ptr [rcx+0x28]
       mov      rax, rdx
       mov      r8d, 224
       cmp      rax, 224
       cmovl    r8, rax
       test     r8, r8
       je       SHORT G_M000_IG35
       sub      rdx, r8
       mov      qword ptr [rcx+0x28], rdx
       add      rdx, qword ptr [rcx+0x30]
       jo       SHORT G_M000_IG36
       call     [Lokad.Lython.Runtime.MemoryGovernor:ResizeOwnership(long):bool:this]
       nop      
 
G_M000_IG35:                ;; offset=0x03B4
       add      rsp, 40
       ret      
 
G_M000_IG36:                ;; offset=0x03B9
       call     CORINFO_HELP_OVERFLOW
       int3     
 
G_M000_IG37:                ;; offset=0x03BF
       sub      rsp, 40
 
G_M000_IG38:                ;; offset=0x03C3
       mov      rdx, rcx
       mov      rbx, bword ptr [rbp+0x10]
       mov      dword ptr [rbx+0x38], -2
       xor      rcx, rcx
       mov      gword ptr [rbx+0x28], rcx
       lea      rcx, bword ptr [rbx+0x40]
       call     [System.Runtime.CompilerServices.AsyncValueTaskMethodBuilder:SetException(System.Exception):this]
       lea      rax, G_M000_IG27
 
G_M000_IG39:                ;; offset=0x03E8
       add      rsp, 40
       ret      
 
; Total bytes of code 1005

; Assembly listing for method Lokad.Lython.Runtime.LythonRuntime+JsonEncodeIterator+<EmitAsync>d__26:MoveNext():this (FullOpts)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; FullOpts code
; optimized code
; rbp based frame
; fully interruptible
; No PGO data
; 11 inlinees with PGO data; 60 single block inlinees; 6 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       push     r15
       push     r14
       push     r13
       push     rdi
       push     rsi
       push     rbx
       sub      rsp, 192
       lea      rbp, [rsp+0xF0]
       xor      eax, eax
       mov      qword ptr [rbp-0xB8], rax
       vxorps   xmm4, xmm4, xmm4
       vmovdqu  ymmword ptr [rbp-0xB0], ymm4
       vmovdqu  ymmword ptr [rbp-0x90], ymm4
       vmovdqu  ymmword ptr [rbp-0x70], ymm4
       vmovdqu  ymmword ptr [rbp-0x50], ymm4
       mov      bword ptr [rbp+0x10], rcx
 
G_M000_IG02:                ;; offset=0x0044
       mov      eax, dword ptr [rcx+0x10]
       mov      rbx, gword ptr [rcx]
 
G_M000_IG03:                ;; offset=0x004A
       cmp      eax, 3
       ja       G_M000_IG20
 
G_M000_IG04:                ;; offset=0x0053
       mov      eax, eax
       lea      rdx, [reloc @RWD00]
       mov      edx, dword ptr [rdx+4*rax]
       lea      r8, G_M000_IG02
       add      rdx, r8
       jmp      rdx
 
G_M000_IG05:                ;; offset=0x006B
       lea      rsi, bword ptr [rcx+0x30]
 
G_M000_IG06:                ;; offset=0x006F
       vmovdqu  xmm0, xmmword ptr [rsi]
       vmovdqu  xmmword ptr [rbp-0x40], xmm0
 
G_M000_IG07:                ;; offset=0x0078
       xor      eax, eax
       mov      qword ptr [rsi], rax
       mov      qword ptr [rsi+0x08], rax
       mov      dword ptr [rcx+0x10], -1
       jmp      G_M000_IG33
 
G_M000_IG08:                ;; offset=0x008D
       vmovdqu  ymm0, ymmword ptr [rcx+0x40]
       vmovdqu  ymmword ptr [rbp-0x78], ymm0
       mov      rax, qword ptr [rcx+0x60]
       mov      qword ptr [rbp-0x58], rax
 
G_M000_IG09:                ;; offset=0x009F
       xor      eax, eax
       mov      qword ptr [rcx+0x40], rax
       mov      qword ptr [rcx+0x48], rax
       mov      qword ptr [rcx+0x50], rax
       mov      qword ptr [rcx+0x58], rax
       mov      qword ptr [rcx+0x60], rax
       mov      dword ptr [rcx+0x10], -1
 
G_M000_IG10:                ;; offset=0x00BC
       mov      rdi, gword ptr [rbp-0x78]
       test     rdi, rdi
       jne      G_M000_IG29
 
G_M000_IG11:                ;; offset=0x00C9
       vmovdqu  xmm0, xmmword ptr [rbp-0x68]
       vmovdqu  xmmword ptr [rbp-0xB8], xmm0
       mov      r8, qword ptr [rbp-0x58]
       mov      qword ptr [rbp-0xA8], r8
 
G_M000_IG12:                ;; offset=0x00E1
       jmp      G_M000_IG32
 
G_M000_IG13:                ;; offset=0x00E6
       lea      rsi, bword ptr [rcx+0x30]
 
G_M000_IG14:                ;; offset=0x00EA
       vmovdqu  xmm0, xmmword ptr [rsi]
       vmovdqu  xmmword ptr [rbp-0x40], xmm0
 
G_M000_IG15:                ;; offset=0x00F3
       xor      eax, eax
       mov      qword ptr [rsi], rax
       mov      qword ptr [rsi+0x08], rax
       mov      dword ptr [rcx+0x10], -1
       jmp      G_M000_IG38
 
G_M000_IG16:                ;; offset=0x0108
       lea      rsi, bword ptr [rcx+0x30]
 
G_M000_IG17:                ;; offset=0x010C
       vmovdqu  xmm0, xmmword ptr [rsi]
       vmovdqu  xmmword ptr [rbp-0x40], xmm0
 
G_M000_IG18:                ;; offset=0x0115
       xor      eax, eax
       mov      qword ptr [rsi], rax
       mov      qword ptr [rsi+0x08], rax
       mov      dword ptr [rcx+0x10], -1
       jmp      G_M000_IG50
 
G_M000_IG19:                ;; offset=0x012A
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+JsonEncodeIterator:CloseFrame():this]
 
G_M000_IG20:                ;; offset=0x0133
       mov      rax, gword ptr [rbx+0x10]
       mov      rsi, gword ptr [rbx+0x18]
       mov      rdi, gword ptr [rax+0xA0]
       cmp      byte  ptr [rdi], dil
       mov      rcx, rdi
       call     [Lokad.Lython.Runtime.ExecutionState:get_CanContinue():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG22
 
G_M000_IG21:                ;; offset=0x0152
       mov      rcx, rdi
       mov      rdx, rsi
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
 
G_M000_IG22:                ;; offset=0x015E
       mov      esi, 1
       mov      r8, gword ptr [rbx+0x30]
       test     r8, r8
       jne      G_M000_IG49
       mov      r9d, dword ptr [rbx+0x40]
       test     r9d, r9d
       je       G_M000_IG48
       dec      r9d
       mov      rcx, bword ptr [rbp+0x10]
       mov      dword ptr [rcx+0x14], r9d
       mov      r9d, dword ptr [rcx+0x14]
       test     r9d, r9d
       jne      SHORT G_M000_IG24
 
G_M000_IG23:                ;; offset=0x0191
       lea      rdi, bword ptr [rbx+0x50]
       jmp      SHORT G_M000_IG25
 
G_M000_IG24:                ;; offset=0x0197
       mov      r8, gword ptr [rbx+0x20]
       dec      r9d
       cmp      r9d, dword ptr [r8+0x08]
       jae      G_M000_IG73
       lea      r9, [r9+8*r9]
       lea      rdi, bword ptr [r8+8*r9+0x10]
 
G_M000_IG25:                ;; offset=0x01B1
       cmp      byte  ptr [rdi+0x2C], 0
       jne      G_M000_IG19
 
G_M000_IG26:                ;; offset=0x01BB
       cmp      byte  ptr [rdi+0x2D], 0
       je       G_M000_IG44
       mov      r14, gword ptr [rdi+0x08]
       test     r14, r14
       jne      G_M000_IG36
       movzx    r9, byte  ptr [rcx+0x18]
       mov      r8d, dword ptr [rcx+0x14]
       lea      rdx, [rbp-0xA0]
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+JsonEncodeIterator:TryTakePairAsync(int,bool):System.Threading.Tasks.ValueTask`1[System.ValueTuple`3[bool,System.Object,System.Object]]:this]
       mov      rdx, gword ptr [rbp-0xA0]
       mov      rcx, gword ptr [rbp-0x90]
       mov      rax, gword ptr [rbp-0x88]
       movzx    r8, byte  ptr [rbp-0x80]
       movsx    r10, word  ptr [rbp-0x98]
       mov      gword ptr [rbp-0x78], rdx
       mov      word  ptr [rbp-0x70], r10w
       mov      byte  ptr [rbp-0x6E], 0
       mov      gword ptr [rbp-0x68], rcx
       mov      gword ptr [rbp-0x60], rax
       mov      byte  ptr [rbp-0x58], r8b
       mov      rsi, gword ptr [rbp-0x78]
       test     rsi, rsi
       je       G_M000_IG10
       mov      rdx, rsi
       mov      rcx, 0x7FF9CD1DBFB8
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       jne      G_M000_IG28
       mov      rcx, rsi
       movsx    rdx, word  ptr [rbp-0x70]
       mov      r11, 0x7FF9CC912CF8
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[System.ValueTuple`3[bool,System.__Canon,System.__Canon]]:GetStatus(short):int:this
       test     eax, eax
       jne      G_M000_IG10
 
G_M000_IG27:                ;; offset=0x026B
       mov      rcx, bword ptr [rbp+0x10]
       mov      dword ptr [rcx+0x10], 2
       lea      rbx, bword ptr [rcx+0x40]
       mov      rdx, gword ptr [rbp-0x78]
       mov      rcx, rbx
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rcx, qword ptr [rbp-0x70]
       mov      qword ptr [rbx+0x08], rcx
       lea      rcx, bword ptr [rbx+0x10]
       mov      rdx, gword ptr [rbp-0x68]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       lea      rcx, bword ptr [rbx+0x18]
       mov      rdx, gword ptr [rbp-0x60]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rdx, qword ptr [rbp-0x58]
       mov      qword ptr [rbx+0x20], rdx
       mov      rcx, bword ptr [rbp+0x10]
       lea      rdx, bword ptr [rcx+0x20]
       call     [System.Runtime.CompilerServices.AsyncTaskMethodBuilder`1[bool]:GetStateMachineBox[Lokad.Lython.Runtime.LythonRuntime+JsonEncodeIterator+<EmitAsync>d__26](byref,byref):System.Runtime.CompilerServices.IAsyncStateMachineBox]
       mov      r8, rax
       lea      rdx, [rbp-0x78]
       mov      rcx, 0x7FF9CD1DC698
       call     [System.Runtime.CompilerServices.AsyncTaskMethodBuilder`1[bool]:AwaitUnsafeOnCompleted[System.Runtime.CompilerServices.ConfiguredValueTaskAwaitable`1+ConfiguredValueTaskAwaiter[System.ValueTuple`3[bool,System.__Canon,System.__Canon]]](byref,System.Runtime.CompilerServices.IAsyncStateMachineBox)]
       jmp      G_M000_IG76
 
G_M000_IG28:                ;; offset=0x02DA
       test     dword ptr [rax+0x34], 0x1600000
       jne      G_M000_IG10
       jmp      SHORT G_M000_IG27
 
G_M000_IG29:                ;; offset=0x02E9
       mov      rdx, rdi
       mov      rcx, 0x7FF9CD1DBFB8
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       mov      r14, rax
       test     r14, r14
       jne      SHORT G_M000_IG30
       lea      rdx, [rbp-0xB8]
       mov      rcx, rdi
       movsx    r8, word  ptr [rbp-0x70]
       mov      r11, 0x7FF9CC912D00
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[System.ValueTuple`3[bool,System.__Canon,System.__Canon]]:GetResult(short):System.ValueTuple`3[bool,System.__Canon,System.__Canon]:this
       jmp      SHORT G_M000_IG32
 
G_M000_IG30:                ;; offset=0x0321
       mov      ecx, dword ptr [r14+0x34]
       and      ecx, 0x11000000
       cmp      ecx, 0x1000000
       jne      G_M000_IG67
 
G_M000_IG31:                ;; offset=0x0337
       vmovdqu  xmm0, xmmword ptr [r14+0x38]
       vmovdqu  xmmword ptr [rbp-0xB8], xmm0
       mov      r8, qword ptr [r14+0x48]
       mov      qword ptr [rbp-0xA8], r8
 
G_M000_IG32:                ;; offset=0x0350
       mov      rcx, bword ptr [rbp+0x10]
       mov      r8, gword ptr [rcx+0x08]
       mov      gword ptr [rsp+0x20], r8
       movzx    r8, byte  ptr [rcx+0x18]
       mov      dword ptr [rsp+0x28], r8d
       mov      r8d, dword ptr [rcx+0x14]
       lea      r9, [rbp-0xB8]
       lea      rdx, [rbp-0x50]
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+JsonEncodeIterator:AdvancePairAsync(int,System.ValueTuple`3[bool,System.Object,System.Object],Lokad.Lython.Runtime.Text.GovernedByteBuilder,bool):System.Threading.Tasks.ValueTask`1[bool]:this]
       mov      rdx, gword ptr [rbp-0x50]
       movzx    rcx, byte  ptr [rbp-0x46]
       movsx    rax, word  ptr [rbp-0x48]
       mov      gword ptr [rbp-0x40], rdx
       mov      word  ptr [rbp-0x38], ax
       mov      byte  ptr [rbp-0x36], cl
       mov      byte  ptr [rbp-0x35], 0
       mov      rsi, gword ptr [rbp-0x40]
       test     rsi, rsi
       jne      G_M000_IG68
 
G_M000_IG33:                ;; offset=0x03A8
       mov      rcx, bword ptr [rbp+0x10]
       mov      rsi, gword ptr [rbp-0x40]
       test     rsi, rsi
       jne      G_M000_IG71
 
G_M000_IG34:                ;; offset=0x03B9
       movzx    rsi, byte  ptr [rbp-0x36]
 
G_M000_IG35:                ;; offset=0x03BE
       jmp      G_M000_IG52
 
G_M000_IG36:                ;; offset=0x03C3
       mov      r15d, dword ptr [rdi+0x28]
       mov      r13d, dword ptr [rdi+0x24]
       mov      rcx, r14
       mov      r11, 0x7FF9CC912CC8
       call     [r11]System.Collections.Generic.IReadOnlyCollection`1[System.__Canon]:get_Count():int:this
       cmp      eax, r13d
       jle      G_M000_IG41
       mov      rcx, r14
       mov      edx, r13d
       mov      r11, 0x7FF9CC912CD0
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       mov      rsi, rax
       test     r13d, r13d
       jle      SHORT G_M000_IG37
       mov      rdx, gword ptr [rbx+0x08]
       mov      rdx, gword ptr [rdx+0x20]
       mov      rcx, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rcx+0x08]
       mov      r8, gword ptr [rbx+0x10]
       mov      r9, gword ptr [rbx+0x18]
       call     [Lokad.Lython.Runtime.LythonRuntime+JsonModule:AppendSeparator(Lokad.Lython.Runtime.Text.GovernedByteBuilder,Lokad.Lython.Runtime.Text.PyString,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan)]
 
G_M000_IG37:                ;; offset=0x041D
       mov      rdx, gword ptr [rbx+0x18]
       mov      gword ptr [rsp+0x20], rdx
       mov      rdx, gword ptr [rbx+0x08]
       mov      rdx, gword ptr [rdx+0x18]
       mov      rcx, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rcx+0x08]
       mov      r9, gword ptr [rbx+0x10]
       lea      r8d, [r15+0x01]
       call     [Lokad.Lython.Runtime.LythonRuntime+JsonModule:AppendJsonIndent(Lokad.Lython.Runtime.Text.GovernedByteBuilder,Lokad.Lython.Runtime.Text.PyString,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan)]
       inc      dword ptr [rdi+0x24]
       mov      rcx, bword ptr [rbp+0x10]
       mov      r9, gword ptr [rcx+0x08]
       mov      gword ptr [rsp+0x20], r9
       movzx    r9, byte  ptr [rcx+0x18]
       mov      dword ptr [rsp+0x28], r9d
       xor      r9d, r9d
       mov      dword ptr [rsp+0x30], r9d
       lea      r9d, [r15+0x01]
       lea      rdx, [rbp-0x50]
       mov      rcx, rbx
       mov      r8, rsi
       call     [Lokad.Lython.Runtime.LythonRuntime+JsonEncodeIterator:AdvanceValueAsync(System.Object,int,Lokad.Lython.Runtime.Text.GovernedByteBuilder,bool,int):System.Threading.Tasks.ValueTask`1[bool]:this]
       mov      rdx, gword ptr [rbp-0x50]
       movzx    rcx, byte  ptr [rbp-0x46]
       movsx    rax, word  ptr [rbp-0x48]
       mov      gword ptr [rbp-0x40], rdx
       mov      word  ptr [rbp-0x38], ax
       mov      byte  ptr [rbp-0x36], cl
       mov      byte  ptr [rbp-0x35], 0
       mov      r13, gword ptr [rbp-0x40]
       test     r13, r13
       jne      G_M000_IG61
 
G_M000_IG38:                ;; offset=0x04A3
       mov      rdi, gword ptr [rbp-0x40]
       test     rdi, rdi
       jne      G_M000_IG64
 
G_M000_IG39:                ;; offset=0x04B0
       movzx    rsi, byte  ptr [rbp-0x36]
 
G_M000_IG40:                ;; offset=0x04B5
       jmp      G_M000_IG52
 
G_M000_IG41:                ;; offset=0x04BA
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+JsonEncodeIterator:CloseFrame():this]
       test     r13d, r13d
       jle      SHORT G_M000_IG42
       mov      rdx, gword ptr [rbx+0x18]
       mov      gword ptr [rsp+0x20], rdx
       mov      rdx, gword ptr [rbx+0x08]
       mov      rdx, gword ptr [rdx+0x18]
       mov      rcx, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rcx+0x08]
       mov      r9, gword ptr [rbx+0x10]
       mov      r8d, r15d
       call     [Lokad.Lython.Runtime.LythonRuntime+JsonModule:AppendJsonIndent(Lokad.Lython.Runtime.Text.GovernedByteBuilder,Lokad.Lython.Runtime.Text.PyString,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan)]
 
G_M000_IG42:                ;; offset=0x04EE
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdi, gword ptr [rcx+0x08]
       mov      edx, dword ptr [rdi+0x28]
       cmp      edx, 0x7FFFFFFE
       jg       G_M000_IG60
       inc      edx
       mov      r8, gword ptr [rdi+0x08]
       cmp      dword ptr [r8+0x08], edx
       jge      SHORT G_M000_IG43
       mov      rcx, rdi
       xor      r8, r8
       call     [Lokad.Lython.Runtime.Text.GovernedByteBuilder:Grow(int,System.Threading.CancellationToken):this]
 
G_M000_IG43:                ;; offset=0x051D
       mov      rdx, gword ptr [rdi+0x08]
       mov      eax, dword ptr [rdi+0x28]
       lea      r8d, [rax+0x01]
       mov      dword ptr [rdi+0x28], r8d
       cmp      eax, dword ptr [rdx+0x08]
       jae      G_M000_IG73
       mov      byte  ptr [rdx+rax+0x10], 93
       jmp      G_M000_IG52
 
G_M000_IG44:                ;; offset=0x053F
       mov      r8d, dword ptr [rcx+0x14]
       mov      rcx, rbx
       mov      rdx, rdi
       call     [Lokad.Lython.Runtime.LythonRuntime+JsonEncodeIterator:OpenFrame(byref,int):this]
       mov      rcx, bword ptr [rbp+0x10]
       mov      r14, gword ptr [rcx+0x08]
       cmp      gword ptr [rdi+0x08], 0
       je       SHORT G_M000_IG45
       mov      edi, 91
       jmp      SHORT G_M000_IG46
 
G_M000_IG45:                ;; offset=0x0565
       mov      edi, 123
 
G_M000_IG46:                ;; offset=0x056A
       mov      edx, dword ptr [r14+0x28]
       cmp      edx, 0x7FFFFFFE
       jg       G_M000_IG59
       inc      edx
       mov      r8, gword ptr [r14+0x08]
       cmp      dword ptr [r8+0x08], edx
       jge      SHORT G_M000_IG47
       mov      rcx, r14
       xor      r8, r8
       call     [Lokad.Lython.Runtime.Text.GovernedByteBuilder:Grow(int,System.Threading.CancellationToken):this]
 
G_M000_IG47:                ;; offset=0x0592
       mov      rdx, gword ptr [r14+0x08]
       mov      eax, dword ptr [r14+0x28]
       lea      r8d, [rax+0x01]
       mov      dword ptr [r14+0x28], r8d
       cmp      eax, dword ptr [rdx+0x08]
       jae      G_M000_IG73
       mov      byte  ptr [rdx+rax+0x10], dil
       jmp      SHORT G_M000_IG52
 
G_M000_IG48:                ;; offset=0x05B2
       xor      edx, edx
       jmp      G_M000_IG75
 
G_M000_IG49:                ;; offset=0x05B9
       xor      rdx, rdx
       mov      gword ptr [rbx+0x30], rdx
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rcx+0x08]
       mov      gword ptr [rsp+0x20], rdx
       movzx    rdx, byte  ptr [rcx+0x18]
       mov      dword ptr [rsp+0x28], edx
       xor      edx, edx
       mov      dword ptr [rsp+0x30], edx
       lea      rdx, [rbp-0x50]
       mov      rcx, rbx
       xor      r9d, r9d
       call     [Lokad.Lython.Runtime.LythonRuntime+JsonEncodeIterator:AdvanceValueAsync(System.Object,int,Lokad.Lython.Runtime.Text.GovernedByteBuilder,bool,int):System.Threading.Tasks.ValueTask`1[bool]:this]
       mov      rdx, gword ptr [rbp-0x50]
       movzx    rcx, byte  ptr [rbp-0x46]
       movsx    rax, word  ptr [rbp-0x48]
       mov      gword ptr [rbp-0x40], rdx
       mov      word  ptr [rbp-0x38], ax
       mov      byte  ptr [rbp-0x36], cl
       mov      byte  ptr [rbp-0x35], 0
       mov      rsi, gword ptr [rbp-0x40]
       test     rsi, rsi
       jne      SHORT G_M000_IG53
 
G_M000_IG50:                ;; offset=0x060F
       mov      rsi, gword ptr [rbp-0x40]
       test     rsi, rsi
       jne      G_M000_IG56
 
G_M000_IG51:                ;; offset=0x061C
       movzx    rsi, byte  ptr [rbp-0x36]
 
G_M000_IG52:                ;; offset=0x0621
       mov      rcx, bword ptr [rbp+0x10]
       movzx    rdx, byte  ptr [rcx+0x19]
       test     edx, esi
       je       G_M000_IG20
       mov      rdx, gword ptr [rcx+0x08]
       cmp      dword ptr [rdx+0x28], 0
       je       G_M000_IG20
       mov      edx, 1
       jmp      G_M000_IG75
 
G_M000_IG53:                ;; offset=0x0649
       mov      rdx, rsi
       mov      rcx, 0x7FF9CD0CCE58
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG54
       test     dword ptr [rax+0x34], 0x1600000
       setne    dil
       movzx    rdi, dil
       jmp      SHORT G_M000_IG55
 
G_M000_IG54:                ;; offset=0x0671
       mov      rcx, rsi
       movsx    rdx, word  ptr [rbp-0x38]
       mov      r11, 0x7FF9CC912CD8
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[bool]:GetStatus(short):int:this
       test     eax, eax
       setne    dil
       movzx    rdi, dil
 
G_M000_IG55:                ;; offset=0x0690
       test     edi, edi
       jne      G_M000_IG50
       xor      ecx, ecx
       mov      rbx, bword ptr [rbp+0x10]
       mov      dword ptr [rbx+0x10], ecx
       lea      rsi, bword ptr [rbx+0x30]
       mov      rdx, gword ptr [rbp-0x40]
       mov      rcx, rsi
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rdx, qword ptr [rbp-0x38]
       mov      qword ptr [rsi+0x08], rdx
       lea      rdx, bword ptr [rbx+0x20]
       mov      rcx, rbx
       call     [System.Runtime.CompilerServices.AsyncTaskMethodBuilder`1[bool]:GetStateMachineBox[Lokad.Lython.Runtime.LythonRuntime+JsonEncodeIterator+<EmitAsync>d__26](byref,byref):System.Runtime.CompilerServices.IAsyncStateMachineBox]
       mov      rdx, rax
       lea      rcx, [rbp-0x40]
       call     [System.Runtime.CompilerServices.AsyncTaskMethodBuilder`1[bool]:AwaitUnsafeOnCompleted[System.Runtime.CompilerServices.ConfiguredValueTaskAwaitable`1+ConfiguredValueTaskAwaiter[bool]](byref,System.Runtime.CompilerServices.IAsyncStateMachineBox)]
       jmp      G_M000_IG76
 
G_M000_IG56:                ;; offset=0x06D8
       mov      rdx, rsi
       mov      rcx, 0x7FF9CD0CCE58
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       mov      rdi, rax
       test     rdi, rdi
       je       SHORT G_M000_IG58
       mov      ecx, dword ptr [rdi+0x34]
       and      ecx, 0x11000000
       cmp      ecx, 0x1000000
       je       SHORT G_M000_IG57
       mov      rcx, rdi
       xor      edx, edx
       call     [System.Runtime.CompilerServices.TaskAwaiter:HandleNonSuccessAndDebuggerNotification(System.Threading.Tasks.Task,int)]
 
G_M000_IG57:                ;; offset=0x070E
       movzx    rsi, byte  ptr [rdi+0x38]
       jmp      G_M000_IG52
 
G_M000_IG58:                ;; offset=0x0718
       mov      rcx, rsi
       movsx    rdx, word  ptr [rbp-0x38]
       mov      r11, 0x7FF9CC912CE0
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[bool]:GetResult(short):bool:this
       mov      esi, eax
       jmp      G_M000_IG52
 
G_M000_IG59:                ;; offset=0x0734
       mov      rdx, gword ptr [r14+0x18]
       mov      rcx, 0x1C94A175AA0
       call     [Lokad.Lython.Runtime.RuntimeErrors:Runtime(System.String,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.LythonRuntimeException]
       mov      rcx, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG60:                ;; offset=0x0751
       mov      rdx, gword ptr [rdi+0x18]
       mov      rcx, 0x1C94A175AA0
       call     [Lokad.Lython.Runtime.RuntimeErrors:Runtime(System.String,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.LythonRuntimeException]
       mov      rcx, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG61:                ;; offset=0x076E
       mov      rdx, r13
       mov      rcx, 0x7FF9CD0CCE58
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG62
       test     dword ptr [rax+0x34], 0x1600000
       setne    r15b
       movzx    r15, r15b
       jmp      SHORT G_M000_IG63
 
G_M000_IG62:                ;; offset=0x0796
       mov      rcx, r13
       movsx    rdx, word  ptr [rbp-0x38]
       mov      r11, 0x7FF9CC912CE8
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[bool]:GetStatus(short):int:this
       test     eax, eax
       setne    r15b
       movzx    r15, r15b
 
G_M000_IG63:                ;; offset=0x07B5
       test     r15d, r15d
       jne      G_M000_IG38
       mov      rcx, bword ptr [rbp+0x10]
       mov      dword ptr [rcx+0x10], 1
       lea      rsi, bword ptr [rcx+0x30]
       mov      rbx, rsi
       mov      rdx, gword ptr [rbp-0x40]
       mov      rcx, rbx
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rdx, qword ptr [rbp-0x38]
       mov      qword ptr [rbx+0x08], rdx
       mov      rcx, bword ptr [rbp+0x10]
       lea      rdx, bword ptr [rcx+0x20]
       call     [System.Runtime.CompilerServices.AsyncTaskMethodBuilder`1[bool]:GetStateMachineBox[Lokad.Lython.Runtime.LythonRuntime+JsonEncodeIterator+<EmitAsync>d__26](byref,byref):System.Runtime.CompilerServices.IAsyncStateMachineBox]
       mov      rdx, rax
       lea      rcx, [rbp-0x40]
       call     [System.Runtime.CompilerServices.AsyncTaskMethodBuilder`1[bool]:AwaitUnsafeOnCompleted[System.Runtime.CompilerServices.ConfiguredValueTaskAwaitable`1+ConfiguredValueTaskAwaiter[bool]](byref,System.Runtime.CompilerServices.IAsyncStateMachineBox)]
       jmp      G_M000_IG76
 
G_M000_IG64:                ;; offset=0x0804
       mov      rdx, rdi
       mov      rcx, 0x7FF9CD0CCE58
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       mov      rsi, rax
       test     rsi, rsi
       je       SHORT G_M000_IG66
       mov      ecx, dword ptr [rsi+0x34]
       and      ecx, 0x11000000
       cmp      ecx, 0x1000000
       je       SHORT G_M000_IG65
       mov      rcx, rsi
       xor      edx, edx
       call     [System.Runtime.CompilerServices.TaskAwaiter:HandleNonSuccessAndDebuggerNotification(System.Threading.Tasks.Task,int)]
 
G_M000_IG65:                ;; offset=0x083A
       movzx    rsi, byte  ptr [rsi+0x38]
       jmp      G_M000_IG40
 
G_M000_IG66:                ;; offset=0x0844
       mov      rcx, rdi
       movsx    rdx, word  ptr [rbp-0x38]
       mov      r11, 0x7FF9CC912CF0
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[bool]:GetResult(short):bool:this
       mov      esi, eax
       jmp      G_M000_IG40
 
G_M000_IG67:                ;; offset=0x0860
       mov      rcx, r14
       xor      edx, edx
       call     [System.Runtime.CompilerServices.TaskAwaiter:HandleNonSuccessAndDebuggerNotification(System.Threading.Tasks.Task,int)]
       jmp      G_M000_IG31
 
G_M000_IG68:                ;; offset=0x0870
       mov      rdx, rsi
       mov      rcx, 0x7FF9CD0CCE58
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG69
       test     dword ptr [rax+0x34], 0x1600000
       setne    dil
       movzx    rdi, dil
       jmp      SHORT G_M000_IG70
 
G_M000_IG69:                ;; offset=0x0898
       mov      rcx, rsi
       movsx    rdx, word  ptr [rbp-0x38]
       mov      r11, 0x7FF9CC912D08
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[bool]:GetStatus(short):int:this
       test     eax, eax
       setne    dil
       movzx    rdi, dil
 
G_M000_IG70:                ;; offset=0x08B7
       test     edi, edi
       jne      G_M000_IG33
       mov      rcx, bword ptr [rbp+0x10]
       mov      dword ptr [rcx+0x10], 3
       lea      rsi, bword ptr [rcx+0x30]
       mov      rdx, gword ptr [rbp-0x40]
       mov      rcx, rsi
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rdx, qword ptr [rbp-0x38]
       mov      qword ptr [rsi+0x08], rdx
       mov      rcx, bword ptr [rbp+0x10]
       lea      rdx, bword ptr [rcx+0x20]
       call     [System.Runtime.CompilerServices.AsyncTaskMethodBuilder`1[bool]:GetStateMachineBox[Lokad.Lython.Runtime.LythonRuntime+JsonEncodeIterator+<EmitAsync>d__26](byref,byref):System.Runtime.CompilerServices.IAsyncStateMachineBox]
       mov      rdx, rax
       lea      rcx, [rbp-0x40]
       call     [System.Runtime.CompilerServices.AsyncTaskMethodBuilder`1[bool]:AwaitUnsafeOnCompleted[System.Runtime.CompilerServices.ConfiguredValueTaskAwaitable`1+ConfiguredValueTaskAwaiter[bool]](byref,System.Runtime.CompilerServices.IAsyncStateMachineBox)]
       jmp      G_M000_IG76
 
G_M000_IG71:                ;; offset=0x0902
       mov      rdx, rsi
       mov      rcx, 0x7FF9CD0CCE58
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       mov      rdi, rax
       test     rdi, rdi
       je       SHORT G_M000_IG74
       mov      ecx, dword ptr [rdi+0x34]
       and      ecx, 0x11000000
       cmp      ecx, 0x1000000
       je       SHORT G_M000_IG72
       mov      rcx, rdi
       xor      edx, edx
       call     [System.Runtime.CompilerServices.TaskAwaiter:HandleNonSuccessAndDebuggerNotification(System.Threading.Tasks.Task,int)]
 
G_M000_IG72:                ;; offset=0x0938
       movzx    rsi, byte  ptr [rdi+0x38]
       mov      rcx, bword ptr [rbp+0x10]
       jmp      G_M000_IG35
 
G_M000_IG73:                ;; offset=0x0946
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG74:                ;; offset=0x094C
       mov      rcx, rsi
       movsx    rdx, word  ptr [rbp-0x38]
       mov      r11, 0x7FF9CC912D10
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[bool]:GetResult(short):bool:this
       mov      esi, eax
       mov      rcx, bword ptr [rbp+0x10]
       jmp      G_M000_IG35
 
G_M000_IG75:                ;; offset=0x096C
       mov      rcx, bword ptr [rbp+0x10]
       mov      dword ptr [rcx+0x10], -2
       add      rcx, 32
       cmp      gword ptr [rcx], 0
       jne      SHORT G_M000_IG78
       mov      byte  ptr [rcx+0x08], dl
       mov      rdx, 0x1C953402660
       mov      rdx, gword ptr [rdx]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
 
G_M000_IG76:                ;; offset=0x0996
       nop      
 
G_M000_IG77:                ;; offset=0x0997
       vzeroupper 
       add      rsp, 192
       pop      rbx
       pop      rsi
       pop      rdi
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG78:                ;; offset=0x09AC
       mov      rcx, gword ptr [rcx]
       call     [System.Runtime.CompilerServices.AsyncTaskMethodBuilder`1[bool]:SetExistingTaskResult(System.Threading.Tasks.Task`1[bool],bool)]
       jmp      SHORT G_M000_IG76
 
G_M000_IG79:                ;; offset=0x09B7
       sub      rsp, 56
 
G_M000_IG80:                ;; offset=0x09BB
       mov      rdx, rcx
       mov      rbx, bword ptr [rbp+0x10]
       mov      dword ptr [rbx+0x10], -2
       lea      rcx, bword ptr [rbx+0x20]
       call     [System.Runtime.CompilerServices.AsyncValueTaskMethodBuilder`1[bool]:SetException(System.Exception):this]
       lea      rax, G_M000_IG76
 
G_M000_IG81:                ;; offset=0x09DA
       vzeroupper 
       add      rsp, 56
       ret      
 
RWD00  	dd	000000C4h ; case G_M000_IG16
       	dd	000000A2h ; case G_M000_IG13
       	dd	00000049h ; case G_M000_IG08
       	dd	00000027h ; case G_M000_IG05

; Total bytes of code 2530

