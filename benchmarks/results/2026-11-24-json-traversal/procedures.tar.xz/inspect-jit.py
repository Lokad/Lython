from pathlib import Path
import hashlib
import json
import os
import re
import subprocess

lab = Path(__file__).resolve().parent
metadata = json.loads((lab/'comparison/identity.json').read_text(encoding='utf-8'))
dotnet = Path.home()/'.dotnet11/dotnet.exe'
env = dict(os.environ, DOTNET_ROOT=str(dotnet.parent), DOTNET_ROOT_X64=str(dotnet.parent),
    DOTNET_TieredCompilation='0', DOTNET_JitDisasm='*EmitAsync*:MoveNext *AdvanceAsync *WriteRootToBuilderAsync*:MoveNext')
rows = []
for role, files in metadata['imageFiles'].items():
    image = lab/role
    assert all(hashlib.sha256((image/name).read_bytes()).hexdigest() == digest for name,digest in (files | metadata['helperFiles']).items())
    log = lab/(role+'-traversal.asm')
    verified = lab/(role+'-jit-verified.json')
    subprocess.run([dotnet, image/'ValidatedAllocation.dll', image, lab/'comparison/representative.json', verified],
        env=dict(env, DOTNET_JitStdOutFile=str(log)), timeout=100, check=True)
    assert all(row['sharedBudgetBaselineRestored'] for row in json.loads(verified.read_text(encoding='utf-8'))['rows'])
    sizes = []
    records = log.read_text(encoding='utf-8-sig').split('; Assembly listing for method ')
    for record in records:
        if 'JsonEncodeIterator' not in record.split('\n',1)[0]: continue
        if size := re.search(r'Total bytes of code (\d+)', record):
            sizes.append(dict(method=record.split('\n',1)[0], emittedBytes=int(size.group(1))))
    assert len(sizes) == ({'reference':2,'candidate':2}[role]), sizes
    rows.append(dict(role=role, coreSHA256=files['Lokad.Lython.dll'], methods=sizes))
    print(rows[-1])
(lab/'jit-summary.json').write_text(json.dumps(rows,indent=2)+'\n',encoding='utf-8',newline='\n')
