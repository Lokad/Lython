from pathlib import Path
import gzip
import hashlib
import json
import subprocess

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
donor = lab.with_name('json-ascii-runs-20261124')

def emit(name, source):
    compile(source, name, 'exec')
    (lab/name).write_text(source, encoding='utf-8', newline='\n')

prepare = (donor/'prepare.py').read_text(encoding='utf-8')
prepare = prepare.replace("donor=lab.with_name('prepared-tuple-exit-refined-20261124')", "donor=lab.with_name('json-ascii-runs-20261124')")
start = prepare.index('original=lab.with_name')
stop = prepare.index("runtime=Path.home()", start)
prepare = prepare[:start] + """for name in ('representative.json', 'jobs.json'):
    shutil.copyfile(donor/'comparison'/name, comparison/name)
    assert digest(comparison/name) == metadata['catalogs'][name]['sha256']
representative = comparison/'representative.json'
files = metadata['imageFiles']['reference']
""" + prepare[stop:]
prepare = prepare.replace("digest(donor/'candidate'/name)", "digest(donor/'reference'/name)")
prepare = prepare.replace("shutil.copyfile(donor/'candidate'/helper", "shutil.copyfile(donor/'reference'/helper")
start = prepare.index('        if name==core:')
stop = prepare.index('        shutil.copyfile(source', start)
prepare = prepare[:start] + """        source=lab/'frozen/bin/Lokad.Lython/release_net11.0'/core if name==core and role=='candidate' else donor/'reference'/name
""" + prepare[stop:]
prepare = prepare.replace('B1585 replace scalar JSON ASCII classifications with bounded byte runs',
                          'B1586 drain completed JSON tokens inside the shared traversal')
emit('prepare.py', prepare)
for name in ('allocations.py', 'summarize.py'):
    emit(name, (donor/name).read_text(encoding='utf-8'))

record = '2026-11-24-json-ascii-runs'
archive = lambda name: subprocess.check_output(['git','show',f'origin/master:benchmarks/results/{record}/{name}'],cwd=repo)
receipt = json.loads(archive('terminal-status.json'))['receipt']
assert receipt['complete'] and receipt['archivedAndVerifiedUnderLease']
assert hashlib.sha256(archive('observations.tar.xz')).hexdigest() == receipt['archiveSHA256']
candidate = hashlib.sha256(gzip.decompress(archive('candidate-core.dll.gz'))).hexdigest()
assert json.loads(archive('identity.json'))['imageFiles']['candidate']['Lokad.Lython.dll'] == candidate
replicas = [dict(sha256=candidate, coreArchive=f'{record}/candidate-core.dll.gz',
    aliases=[dict(path='json-ascii-runs-b1585-20261124/candidate/Lokad.Lython.dll',
    observationSHA256=receipt['archiveSHA256'], source=record)])]
(lab/'verified-replicas.json').write_text(json.dumps(replicas, indent=2)+'\n',encoding='utf-8',newline='\n')
