from hashlib import sha256
from pathlib import Path
from shutil import copy2, copytree
from subprocess import check_output
import json

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
reference = lab.parent / 'current-shipment-checkpoint-b1943-20261128/comparison/quiet'
procedures = lab.parent / 'private-generator-sum-b1940-20261128'
pair = lab / 'comparison'
build = lab / 'ubuntu-artifacts/bin/Lokad.Lython/release_net11.0/Lokad.Lython.dll'
read = lambda path: json.loads(path.read_bytes())
digest = lambda path: sha256(path.read_bytes()).hexdigest()
files = lambda folder: {path.name: digest(path) for path in folder.iterdir()}

def git(*args):
    return check_output(['git', *args], cwd=repo)

def write(path, data):
    path.write_text(json.dumps(data, indent=2) + '\n', encoding='utf-8', newline='\n')

previous = read(reference / 'identity.json')
head = git('rev-parse', 'HEAD').decode().strip()
assert previous['sourceRevision'].startswith('bf10eeaea')
assert not git('diff', '--binary', previous['sourceRevision'], head, '--', 'src', 'Directory.Packages.props')
assert not git('diff', '--binary', 'HEAD', '--', 'src/Lokad.Lython.Utf8Regex', 'Directory.Packages.props', 'tests')
prior_image = files(reference / 'local-image')
assert len(prior_image) == 32 and prior_image == previous['imageFiles']['candidate']
pair.mkdir()
for role in ('reference', 'candidate'):
    copytree(reference / 'local-image', pair / role)
copy2(build, pair / 'candidate/Lokad.Lython.dll')
images = {role: files(pair / role) for role in ('reference', 'candidate')}
assert images['reference'] == prior_image
assert not (pair / 'candidate/Lokad.Lython.dll').samefile(build)
assert {name for name, checksum in prior_image.items() if images['candidate'][name] != checksum} == {'Lokad.Lython.dll'}
patch = git('diff', '--binary', 'HEAD', '--', 'src/Lokad.Lython')
(lab / 'candidate.patch').write_bytes(patch)

for name in ('representative.json', 'cpython-worker.py'):
    copy2(reference / name, pair / name)
assert digest(pair / 'representative.json') == previous['catalogs']['representative.json']['sha256']
assert digest(pair / 'cpython-worker.py') == previous['cpythonWorkerSHA256']
jobs = read(reference / 'jobs.json')
assert len(jobs) == 6
write(pair / 'jobs.json', {'warm': jobs})
write(pair / 'identity.json', dict(sourceRevision=head, comparisonReference=previous['sourceRevision'],
    sourcePatchSHA256=sha256(patch).hexdigest(), imageFiles=images,
    coreSHA256={label: images[role]['Lokad.Lython.dll'] for role in images for label in (role, role + '-control')},
    catalogs={name: {'sha256': digest(pair / name)} for name in ('representative.json', 'jobs.json')},
    cpythonWorkerSHA256=previous['cpythonWorkerSHA256'], expectedCPythonSHA256=previous['expectedCPythonSHA256'],
    purpose='Move generator-call shape checking to the existing executable layout and narrow cleanup bounds.'))
for name in ('run.sh', 'collect.py'):
    copy2(procedures / 'comparison' / name, pair / name)
collector = pair / 'collect.py'
collector_source = collector.read_text(encoding='utf-8')
assert collector_source.count('len(jobs) == 5') == 1
collector_source = collector_source.replace('len(jobs) == 5', 'len(jobs) == 6')
collector.write_text(collector_source, encoding='utf-8', newline='\n')
copy2(procedures / 'measure-allocation.py', lab / 'measure-allocation.py')
summary = (procedures / 'summarize.py').read_text(encoding='utf-8').replace('== 5', '== 6').replace('== 140', '== 168')
(lab / 'summarize.py').write_text(summary, encoding='utf-8', newline='\n')
assert b'\r' not in (pair / 'run.sh').read_bytes()
print(head, len(jobs), 'lanes with exact checkpoint reference and current candidate')
