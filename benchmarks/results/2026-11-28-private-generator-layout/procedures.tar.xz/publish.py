from hashlib import sha256
from pathlib import Path
from shutil import copy2
from subprocess import check_output
import json
import re
import tarfile

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
bench = lab / 'comparison'
out = repo / 'benchmarks/results/2026-11-28-private-generator-layout'
read = lambda path: json.loads(path.read_bytes())
digest = lambda path: sha256(path.read_bytes()).hexdigest()
identity = read(bench / 'identity.json')
assert identity['comparisonReference'].startswith('bf10eeaea')
assert check_output(['git', 'diff', '--binary', identity['sourceRevision'], '--', 'src/Lokad.Lython'], cwd=repo) == (lab / 'candidate.patch').read_bytes()
assert not check_output(['git', 'diff', '--binary', identity['sourceRevision'], '--', 'tests'], cwd=repo)
assert digest(lab / 'candidate.patch') == identity['sourcePatchSHA256']
for role, expected in identity['imageFiles'].items():
    assert len(expected) == 32 and {p.name:digest(p) for p in (bench/role).iterdir()} == expected
assert {n for n, checksum in identity['imageFiles']['reference'].items() if identity['imageFiles']['candidate'][n] != checksum} == {'Lokad.Lython.dll'}
summary = read(bench / 'summary.json')
assert summary['verifiedTimedBatches'] == 168 and len(summary['rows']) == 6
receipt = read(bench/'archive-receipt.json')
assert receipt['archiveSHA256'] == digest(bench/'observations.tar.xz')
assert all(receipt[k] for k in ('complete','allWorkersJoined','guestFixturesRemoved','archivedAndVerifiedUnderLease'))
alloc = read(lab/'allocation/summary.json')
assert len(alloc) == 8 and all(row['compiled'][0] == row['compiled'][1] and row['admittedPeak'][0] == row['admittedPeak'][1] for row in alloc)
assert all(abs(row['clr'][0] - row['clr'][1]) <= 56 for row in alloc)
logs = sorted(lab.glob('*-Lokad.Lython.*Tests-net*.log'))
assert len(logs) == 6
for log in logs:
    count = 738 if 'PublicApi' in log.name else 193
    assert re.search(rf'Failed: +0, Passed: +{count}, Skipped: +0', log.read_text(encoding='utf-8-sig')), log

layouts = {}
for role in ('reference','candidate'):
    observed = read(lab/f'layout/{role}.json')
    assert observed['core'] == identity['imageFiles'][role]['Lokad.Lython.dll']
    assert observed['catalog'] == identity['catalogs']['representative.json']['sha256']
    layouts[role] = {case['id']:case['layouts'] for case in observed['observations']}
assert all([x['opcodes'] for x in layouts['reference'][case]] == [x['opcodes'] for x in final] for case, final in layouts['candidate'].items())
file_map = 'diagnostic.shipment-file-fed-map'
assert layouts['candidate'][file_map] == layouts['reference'][file_map]
shipment = 'diagnostic.shipment-starmap-iterable-rows'
prior, final = (layouts[role][shipment][0] for role in ('reference','candidate'))
assert prior['lastOwnedTemporary'] == 11 and final['lastOwnedTemporary'] == 8
assert len(final['generatorOperands']) == 1 and final['generatorOperands'][0]['target'] is None
for case in ('diagnostic.shipment-row-generator-reduction','diagnostic.shipment-row-range-generator-reduction'):
    prior, final = (layouts[role][case][1] for role in ('reference','candidate'))
    assert final['lastOwnedTemporary'] == prior['lastOwnedTemporary'] == 3
    assert len(final['generatorOperands']) == 1 and final['generatorOperands'][0]['target'] == 2

out.mkdir(exist_ok=True)
(out/'operand-layout.json').write_text(json.dumps(layouts,indent=2)+'\n',encoding='utf-8',newline='\n')
artifacts = {name:bench/name for name in ('identity.json','summary.json','observations.tar.xz','archive-receipt.json')}
artifacts['allocation.json'] = lab/'allocation/summary.json'
for name, source in artifacts.items():
    copy2(source,out/name)
    assert digest(out/name) == digest(source)
procedures = {p.name:p for p in logs}
for name in ('candidate.patch','freeze.py','test-ubuntu.sh','test-windows.ps1','ubuntu-core-build.log','initial-windows-build.log',
             'initial-ubuntu-build.log','summarize.py','measure-allocation.py','publish.py'):
    procedures[name] = lab/name
for name in ('collection.log','reference-verify.json','candidate-verify.json','exit-code.txt'):
    procedures[name] = bench/name
for name in ('InspectLayout.csproj','Program.cs','build.log','reference.json','candidate.json'):
    procedures[f'layout/{name}'] = lab/'layout'/name
for name in ('collection.log','collect.py','exit-code.txt'):
    procedures[f'initial-collection/{name}'] = lab/'initial-collection'/name
for p in (lab/'allocation').glob('*.json'):
    procedures[f'allocation/{p.name}'] = p
with tarfile.open(out/'procedures.tar.xz','w:xz') as archive:
    for name, path in procedures.items(): archive.add(path, arcname=name)
with tarfile.open(out/'procedures.tar.xz') as archive:
    assert all(digest(path) == sha256(archive.extractfile(name).read()).hexdigest() for name,path in procedures.items())
print('Private generator layout source, evidence and custody verified.')
