from pathlib import Path
import hashlib,json,shutil,subprocess,tarfile,xml.etree.ElementTree as ET,zipfile
home=Path(__file__).resolve().parent;root=home.parent/'regex-dev46'
if root.exists():
 assert {str(p.relative_to(root)).replace('\\','/') for p in root.rglob('*') if p.is_file()}=={'feed/Lokad.Utf8Regex.0.5.0-dev.46.nupkg'}
 (root/'preparation-error.txt').write_text('Initial preparation assumed a specific nuspec XML namespace and stopped before any build/test or normal-input mutation. Use namespace-independent metadata selection; preserve immutable input copies.\n',encoding='utf-8')
else:root.mkdir()
old=home.parent/'regex-capture-u04/development44';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
normal=[Path('Directory.Packages.props'),Path('src/Lokad.Lython.Utf8Regex/Utf8RegexProvider.cs'),Path('src/Lokad.Lython.Utf8Regex/Lokad.Lython.Utf8Regex.csproj')]
identity=dict(consumerHead=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),developmentOnly=True,normalPin='0.4.0 unchanged',normalInputs={str(p):sha(p) for p in normal},packages={},baseProviderSHA256=sha(old/'Utf8RegexProvider.cs'))
feed=root/'feed';feed.mkdir(exist_ok=True)
for name in ['Lokad.Utf8Regex','Lokad.Utf8Regex.PythonRe']:
 source=Path('D:/code/utf8regex/artifacts/nuget')/(name+'.0.5.0-dev.46.nupkg');target=feed/source.name;shutil.copyfile(source,target);assert sha(target)==sha(source)
 with zipfile.ZipFile(target) as a:
  spec=ET.fromstring(a.read(name+'.nuspec'))
  metadata=spec.find('{*}metadata');assert metadata is not None
  version=metadata.find('{*}version').text;repository=metadata.find('{*}repository')
  assert version=='0.5.0-dev.46' and repository.get('commit')=='6957b35aa51ee5730252011085e21669767ee1f9'
  libraries={n:hashlib.sha256(a.read(n)).hexdigest() for n in a.namelist() if n.startswith('lib/') and n.endswith('.dll')}
  docs={n:sorted(m.get('name') for m in ET.fromstring(a.read(n)).findall('./members/member')) for n in a.namelist() if n.startswith('lib/') and n.endswith('.xml')}
 identity['packages'][name]=dict(version=version,revision=repository.get('commit'),sha256=sha(target),libraries=libraries)
 # Compare documented member identities with the actual qualified dev44 inputs;
 # compilation/tests below establish consumption, not documentation completeness.
 previous=home.parent/'adapter44/feed'/(name+'.0.5.0-dev.44.nupkg')
 with zipfile.ZipFile(previous) as a:
  priorDocs={n:set(m.get('name') for m in ET.fromstring(a.read(n)).findall('./members/member')) for n in docs}
 identity['packages'][name]['documentedSurfaceChanges']={n:dict(added=sorted(set(v)-priorDocs[n]),removed=sorted(priorDocs[n]-set(v))) for n,v in docs.items()}
for n in ['Directory.Build.props','Directory.Packages.props']:
 s=(old/n).read_text(encoding='utf-8').replace(str(old).replace('\\','/'),str(root).replace('\\','/')).replace('0.5.0-dev.44','0.5.0-dev.46')
 (root/n).write_text(s,encoding='utf-8')
(root/'NuGet.Config').write_text('<configuration><packageSources><clear /><add key="exact-local" value="'+str(feed).replace('\\','/')+'" /><add key="nuget.org" value="https://api.nuget.org/v3/index.json" /></packageSources></configuration>\n',encoding='utf-8')
for n in ['Utf8RegexProvider.cs','CursorAdmissionTests.cs']:shutil.copyfile(old/n,root/n)
assert sha(root/'Utf8RegexProvider.cs')==identity['baseProviderSHA256']
(root/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8')
s=(home.parent/'regex-capture-u04/qualify-development.py').read_text(encoding='utf-8')
s=s.replace("root=Path(__file__).resolve().parent/'development44'","root=Path(__file__).resolve().parent")
s=s.replace("root.parent.parent/'adapter40/workflow-fixture-manifest.json'","root.parent/'adapter40/workflow-fixture-manifest.json'")
(root/'qualify.py').write_text(s,encoding='utf-8')
print(root,[(k,v['sha256'],v['documentedSurfaceChanges']) for k,v in identity['packages'].items()],flush=True)
