from hashlib import sha256
import json
from pathlib import Path
from shutil import copy2
import tarfile


lab = Path(__file__).resolve().parent
out = lab.parents[3] / 'benchmarks/results/2026-11-28-shared-module-catalog-trial'
comparison = lab / 'comparison'


def read(path):
    return json.loads(path.read_bytes())


def digest(path):
    return sha256(path.read_bytes()).hexdigest()


identity = read(comparison / 'identity.json')
assert digest(lab / 'candidate.patch') == identity['sourcePatchSHA256']
for role, image in identity['imageFiles'].items():
    assert {path.name: digest(path) for path in (comparison / role).iterdir()} == image
    verification = read(comparison / f'{role}-verify.json')
    assert verification['state'] == 'Completed' and verification['caseCount'] == 4
    assert verification['launched']['library']['sha256'] == image['Lokad.Lython.dll']
assert digest(lab / 'reference-modules.json') == digest(lab / 'candidate-modules.json')
assert read(lab / 'allocation.json')['verifiedCompilations'] == 42
assert read(lab / 'cold-summary.json')['verifiedInvocations'] == 48
assert read(comparison / 'summary.json')['verifiedTimedBatches'] == 140
assert read(comparison / 'archive-receipt.json')['archiveSHA256'] == digest(comparison / 'observations.tar.xz')
for name in ('config', 'xml', 'generated'):
    first, second = [json.loads(line) for line in (lab / f'{name}-deferred.jsonl').read_text(encoding='utf-8-sig').splitlines()]
    assert first['after'] == 0 and second['moduleCount'] == 66 and second['concurrent'] == 16
    assert set(second['afterParallel']) - set(second['ready']) == {'argparse'}
for log in lab.glob('*net*.log'):
    assert ('Passed:   740' if 'PublicApi' in log.name else 'Passed:    67') in log.read_text(encoding='utf-8-sig')
assert len(list(lab.glob('*net*.log'))) == 6

out.mkdir(exist_ok=True)
for name, source in [('identity.json', comparison / 'identity.json'), ('warm-observations.tar.xz', comparison / 'observations.tar.xz'),
    ('warm-summary.json', comparison / 'summary.json'), *[(name, lab / name) for name in ('allocation.json', 'cold-summary.json')]]:
    copy2(source, out / name)
    assert digest(out / name) == digest(source)

paths = {file.name: file for file in lab.iterdir() if file.is_file() and file.suffix in ('.py', '.ps1', '.sh', '.json', '.jsonl', '.log', '.patch')}
for name in ('reference-verify.json', 'candidate-verify.json', 'archive-receipt.json', 'config.json', 'xml.json', 'generated.json'):
    paths[f'comparison/{name}'] = comparison / name
for name in ('ModuleProbe.csproj', 'Program.cs'):
    paths[f'probe/{name}'] = lab / 'probe' / name
with tarfile.open(out / 'procedures.tar.xz', 'w:xz') as archive:
    for name, path in paths.items():
        archive.add(path, arcname=name)
with tarfile.open(out / 'procedures.tar.xz') as archive:
    assert all(sha256(archive.extractfile(name).read()).hexdigest() == digest(path) for name, path in paths.items())
manifest = read(lab / 'reference-modules.json')
print(len(manifest['modules']), sum(len(row['names']) for row in manifest['rows']),
      sum(len(row['exports']) for row in manifest['rows']), sum(len(row['queries']) for row in manifest['rows']),
      len(manifest['diagnostics']), len(paths), 'files archived')
