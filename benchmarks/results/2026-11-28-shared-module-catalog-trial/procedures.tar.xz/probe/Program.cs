using System.Diagnostics;
using System.Collections;
using System.Reflection;
using System.Text.Json;

var assembly = Assembly.LoadFrom(Path.GetFullPath(args[0]));
var engineType = assembly.GetType("Lokad.Lython.LythonEngine", throwOnError: true)!;
var engine = Activator.CreateInstance(engineType)!;
if (args[1] == "--allocate")
{
    var budgetType = assembly.GetType("Lokad.Lython.LythonMemoryBudget", throwOnError: true)!;
    var budgetInterface = assembly.GetType("Lokad.Lython.ILythonMemoryBudget", throwOnError: true)!;
    var budget = Activator.CreateInstance(budgetType, [null])!;
    var compileWithBudget = engineType.GetMethod("Compile", [typeof(string), budgetInterface])!;
    using var catalog = JsonDocument.Parse(File.ReadAllBytes(args[2]));
    var source = catalog.RootElement.GetProperty("cases")[0].GetProperty("source").GetString()!;
    var start = Stopwatch.GetTimestamp();
    var before = GC.GetAllocatedBytesForCurrentThread();
    var script = (IDisposable)compileWithBudget.Invoke(engine, [source, budget])!;
    var allocated = GC.GetAllocatedBytesForCurrentThread() - before;
    var elapsedMilliseconds = Stopwatch.GetElapsedTime(start).TotalMilliseconds;
    var successful = (bool)Read(script, "IsValid")!;
    var admitted = (long)Read(budget, "ReservedBytes")!;
    script.Dispose();
    var after = (long)Read(budget, "ReservedBytes")!;
    if (!successful || admitted <= 0 || after != 0) throw new InvalidOperationException("Compilation or cleanup failed.");
    Console.WriteLine(JsonSerializer.Serialize(new { allocated, admitted, after, elapsedMilliseconds }));
    if (args.Length == 4 && args[3] == "--deferred")
    {
        const BindingFlags fields = BindingFlags.NonPublic | BindingFlags.Static | BindingFlags.Instance;
        var type = assembly.GetType("Lokad.Lython.Runtime.LythonRuntime+BuiltinModuleCatalog", throwOnError: true)!;
        var entries = (IEnumerable)type.GetField("Registrations", fields)!.GetValue(null)!;
        var surfaces = entries.Cast<object>().ToDictionary(entry => (string)Read(entry, "Key")!, entry => Read(entry, "Value")!,
            StringComparer.Ordinal);
        var field = surfaces.Values.First().GetType().GetField("_surface", fields)!;
        string[] Materialized() => surfaces.Where(entry => field.GetValue(entry.Value) != null)
            .Select(entry => entry.Key).Order(StringComparer.Ordinal).ToArray();
        var ready = Materialized();
        const string other = "argparse";
        if (ready.Contains(other)) throw new InvalidOperationException("Unrelated surface was already initialized.");
        var contractType = assembly.GetType("Lokad.Lython.Frontend.StaticContracts", throwOnError: true)!;
        var getMembers = contractType.GetMethod("GetModuleMemberNames")!;
        var getExports = contractType.GetMethod("GetModuleExportedMemberNames")!;
        var observedMembers = new object?[16];
        var observedExports = new object?[16];
        Parallel.For(0, observedMembers.Length, index =>
        {
            observedMembers[index] = getMembers.Invoke(null, [other]);
            observedExports[index] = getExports.Invoke(null, [other]);
        });
        if (observedMembers[0] is null || observedExports[0] is null ||
            observedMembers.Any(snapshot => !ReferenceEquals(snapshot, observedMembers[0])) ||
            observedExports.Any(snapshot => !ReferenceEquals(snapshot, observedExports[0])))
            throw new InvalidOperationException("Concurrent callers observed different snapshots.");
        var afterParallel = Materialized();
        if (!afterParallel.Except(ready).SequenceEqual([other]))
            throw new InvalidOperationException("Unexpected surface construction.");
        Console.WriteLine(JsonSerializer.Serialize(new { moduleCount = surfaces.Count, ready, afterParallel, concurrent = observedMembers.Length }));
    }
    return;
}

var contracts = assembly.GetType("Lokad.Lython.Frontend.StaticContracts", throwOnError: true)!;
var spanType = assembly.GetType("Lokad.Lython.LythonSourceSpan", throwOnError: true)!;
var span = Activator.CreateInstance(spanType, [0, 0, 1, 1])!;
var modules = (IReadOnlyList<string>)contracts.GetMethod("GetKnownBuiltinModuleNames")!.Invoke(null, null)!;
var members = contracts.GetMethod("GetModuleMemberNames")!;
var exported = contracts.GetMethod("GetModuleExportedMemberNames")!;
var lookup = contracts.GetMethod("TryGetModuleMemberValue")!;
string[] metadata = ["__dict__", "__name__", "__spec__", "__loader__", "__package__", "__path__", "__synthetic_absent__"];
var rows = modules.Append("__absent_module__").Select(module =>
{
    var names = (IReadOnlyList<string>)members.Invoke(null, [module])!;
    var exports = (IReadOnlyList<string>)exported.Invoke(null, [module])!;
    if (module != "__absent_module__" && (!ReferenceEquals(names, members.Invoke(null, [module])) ||
        !ReferenceEquals(exports, exported.Invoke(null, [module])))) throw new InvalidOperationException(module + " unstable inventory.");
    var queries = names.Concat(names.Select(static n => n.ToUpperInvariant())).Concat(metadata).Distinct(StringComparer.Ordinal).Select(name =>
    {
        object?[] arguments = [module, name, span, null];
        var found = (bool)lookup.Invoke(null, arguments)!;
        var value = arguments[3]!;
        var kind = Read(value, "Kind")!.ToString()!;
        var detail = kind switch
        {
            "String" or "Module" or "KnownCallable" => Call(value, "RequireText"),
            "Integer" => Call(value, "RequireInteger")!.ToString(),
            "Boolean" => Call(value, "RequireBoolean"),
            _ => null
        };
        return new { name, found, kind, detail, span = Read(value, "Span") };
    }).ToArray();
    return new { module, names, exports, queries };
}).ToArray();

var compile = engineType.GetMethod("Compile", [typeof(string)])!;
var cases = new Dictionary<string, string>
{
    ["constructor-shape"] = "from openpyxl.workbook import Workbook\nreturn Workbook(0, 0, 0)",
    ["reader-shape"] = "import openpyxl.reader.excel as reader\nreturn reader.load_workbook()",
    ["utility-shape"] = "from openpyxl.utils.cell import get_column_letter\nreturn get_column_letter()",
    ["ordinary-utility"] = "from openpyxl.utils import get_column_letter\nreturn get_column_letter()",
    ["identity-alias"] = "from openpyxl.styles import Font\nreturn Font(does_not_exist=1)",
    ["unknown-member"] = "import openpyxl.utils.cell as tools\nreturn tools.__missing()",
    ["shadowed-callable"] = "from openpyxl.workbook import Workbook\nWorkbook = lambda x: x\nreturn Workbook(7)",
    ["shadowed-module"] = "import openpyxl.reader.excel as reader\nclass Reader:\n def load_workbook(self): return 7\nreader = Reader()\nreturn reader.load_workbook()",
    ["merged-callables"] = "from openpyxl.workbook import Workbook as external\nfrom openpyxl import Workbook as root\nif supplied:\n make=external\nelse:\n make=root\nreturn make(1, 2, 3)",
    ["module-metadata"] = "import openpyxl.workbook as wrapped\nreturn wrapped.__name__",
    ["colocated-submodules"] = "import xml, collections, openpyxl\nreturn xml.etree, collections.abc, openpyxl.workbook",
    ["direct-imports"] = "from openpyxl.reader.excel import load_workbook as reader\nfrom openpyxl.utils.cell import get_column_letter as column\nreturn callable(reader), column(3)",
    ["known-callable"] = "import openpyxl.utils.cell as tools\nreturn tools.range_boundaries('C4:D5')"
};
var diagnostics = cases.Select(pair =>
{
    using var script = (IDisposable)compile.Invoke(engine, [pair.Value])!;
    return new { id = pair.Key, valid = Read(script, "IsValid"),
        diagnostics = JsonSerializer.SerializeToElement(Read(script, "Diagnostics")) };
}).ToArray();
File.WriteAllText(args[1], JsonSerializer.Serialize(new { modules, rows, diagnostics }));

static object? Read(object target, string property) => target.GetType().GetProperty(property)!.GetValue(target);
static object? Call(object target, string method) => target.GetType().GetMethod(method)!.Invoke(target, null);
