from pathlib import Path
import re


repo = Path(__file__).resolve().parents[4]
runtime = repo / 'src/Lokad.Lython/Runtime/LythonRuntime.BuiltinModuleCatalog.cs'
frontend = repo / 'src/Lokad.Lython/Frontend/StaticContracts.Modules.cs'
resolution = runtime.read_text(encoding='utf-8')
contracts = frontend.read_text(encoding='utf-8')

start = resolution.index('        private static readonly FrozenDictionary<string, BuiltinModuleRegistration> Registrations')
end = resolution.index('\n\n        private static readonly string[] KnownNames', start)
dispatch = dict(re.findall(r'^ +\["([^"]+)"\] = Module\(([^\n]+)\),$', resolution[start:end], re.M))
begin = contracts.index('    internal static readonly Dictionary<string, BuiltinModuleSurface> Surfaces')
after = contracts.index('\n\n    internal static readonly FrozenDictionary<ModuleMemberName, string> Submodules', begin)
surfaces = re.findall(r'^        \["([^"]+)"\] = (.*?),\n(?=        \["|    };)', contracts[begin:after], re.M | re.S)
assert len(dispatch) == len(surfaces) == 66 and {name for name, _ in surfaces} == set(dispatch)

lines = []
for name, surface in surfaces:
    declaration = f'    ["{name}"] = new({dispatch[name]},\n        static () => {surface}),'
    lines.append(declaration)

source = '''using System.Collections.Frozen;
using Lokad.Lython.Frontend;

namespace Lokad.Lython.Runtime;

internal sealed partial class LythonRuntime
{
    internal static partial class BuiltinModuleCatalog
    {
        // Module names have one registration. The member and runtime factories
        // are invoked independently when their corresponding layer needs them.
        private static readonly FrozenDictionary<string, BuiltinModuleRegistration> Registrations =
            new Dictionary<string, BuiltinModuleRegistration>(StringComparer.Ordinal)
            {
'''
source += '\n'.join('            ' + line for row in lines for line in row.splitlines()) + '\n'
source += '''            }.ToFrozenDictionary(StringComparer.Ordinal);

        private static StaticModuleCatalog.BuiltinModuleSurface Members(params string[] names)
            => new(names);

        private static StaticModuleCatalog.BuiltinModuleSurface ReexportedMembers(string callableModule, params string[] names)
            => new(names, callableModule);
    }
}
'''
old_subprocess = 'new(static _ => SubprocessModule.Instance, BuiltinModuleCapability.Subprocess,\n                '
assert old_subprocess in source
source = source.replace(old_subprocess, 'new(static _ => SubprocessModule.Instance,\n                ', 1)
subprocess_line = next(line for line in source.splitlines() if 'CalledProcessError' in line)
source = source.replace(subprocess_line, subprocess_line.removesuffix('),') + ', BuiltinModuleCapability.Subprocess),', 1)

resolution = resolution[:start] + resolution[end + 2:]
contracts = contracts[:begin] + contracts[after + 2:]
begin = contracts.index('    internal static readonly IReadOnlyList<string> Names')
after = contracts.index('    internal sealed class BuiltinModuleSurface', begin)
contracts = contracts[:begin] + contracts[after:]
resolution = resolution.replace('    private static class BuiltinModuleCatalog', '    internal static partial class BuiltinModuleCatalog')

runtime.write_text(resolution, encoding='utf-8', newline='\n')
frontend.write_text(contracts, encoding='utf-8', newline='\n')
runtime.with_name('LythonRuntime.BuiltinModuleCatalog.Registrations.cs').write_text(source, encoding='utf-8', newline='\n')
