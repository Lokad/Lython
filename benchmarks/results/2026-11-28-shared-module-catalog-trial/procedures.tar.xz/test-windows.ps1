$lab='.git/agent-notes/review-20261031/shared-module-catalog-b1988-20261128'
$sdk=Join-Path $env:USERPROFILE '.dotnet11/dotnet.exe'
$filter='Category!=Stress&(FullyQualifiedName~BuiltinModulePolicy|FullyQualifiedName~ModuleSingletonBehavior|FullyQualifiedName~CompilerCancellation|FullyQualifiedName~Static|FullyQualifiedName~ModuleContractParity|FullyQualifiedName~OpenPyxl|FullyQualifiedName~ModuleValidation|FullyQualifiedName~Import|FullyQualifiedName~CompilerMemory|FullyQualifiedName~AdmissionFailureCommandTests)'
foreach ($tfm in 'net11.0','net10.0') {
  foreach ($suite in 'Lokad.Lython.Tests','Lokad.Lython.PublicApi.Tests') {
    $log="$lab/windows-$suite-$tfm.log"
    & $sdk test "tests/$suite/$suite.csproj" -c Release -f $tfm --filter $filter *> $log
    $code=$LASTEXITCODE
    if ($code -ne 0) { Get-Content $log -Encoding utf8 -Tail 60; exit $code }
    Get-Content $log -Encoding utf8 -Tail 2
  }
}
