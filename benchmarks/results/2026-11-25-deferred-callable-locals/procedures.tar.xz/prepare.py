from pathlib import Path
import hashlib,json,shutil,subprocess,textwrap

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
anchor=lab.with_name('regex-shared-literal-refined-20261125')
prior=lab.with_name('ordinary-definition-inventory-20261125')
definitions=lab.with_name('direct-record-cpython-20261125')
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def git(*args): return subprocess.check_output(['git',*args],cwd=repo)
def save(path,value):path.write_text(json.dumps(value,indent=2,ensure_ascii=False)+'\n',encoding='utf-8',newline='\n')
head=git('rev-parse','HEAD').decode().strip()
assert head.startswith('35eace33b')
id=read(anchor/'identity.json')
recorded=anchor/'candidate.patch'
assert sha(recorded)==id['sourcePatchSHA256']
assert git('diff','--binary',id['sourceRevision'],head,'--','src')==recorded.read_bytes()
base=id['imageFiles']['candidate']
assert len(base)==32 and {p.name:sha(p)for p in (anchor/'candidate').iterdir()}==base
patch=git('diff','--binary','HEAD','--','src')
assert patch.count(b'diff --git ') == 5
(lab/'candidate.patch').write_bytes(patch)
(lab/'tests.patch').write_bytes(git('diff','--binary','HEAD','--','tests'))
core=lab/'bench/bin/Lokad.Lython/release_net11.0/Lokad.Lython.dll'
assert sha(core)==sha(lab/'bench/bin/Lokad.Lython.Benchmarks/release_net11.0/Lokad.Lython.dll')
images=dict(reference=base,candidate=base|{core.name:sha(core)})
for role,files in images.items():
    path=lab/role
    path.mkdir(exist_ok=True)
    for name in files:
        shutil.copyfile(core if role=='candidate' and name==core.name else anchor/'candidate'/name,path/name)
    assert {p.name:sha(p)for p in path.iterdir()}==files
catalog=read(anchor/'representative.json')
control=read(definitions/'external/representative.json')
cases={c['id']:c for c in catalog['cases']+control['cases']}
ordinary='diagnostic.generated-ordinary-definitions'
rules='scripts.rule-default-closures'
shipment='diagnostic.shipment-routing-callbacks'
observer,=read(prior/'observer.json')['cases']
test=(repo/'tests/Lokad.Lython.PublicApi.Tests/PreparedFunctionDefaultsTests.cs').read_text(encoding='utf-8')
test=test[test.index('Task DefaultExpressionCanPublishEarlierCallablesThroughAliasedLocals'):]
body=test.split('"""',2)[1]
source=textwrap.dedent(body.strip('\n')).rstrip()+'\n'
expected="25 29 (12,) 15 False\n"
observer=observer|dict(source=source,sourceUtf8Bytes=len(source.encode('utf-8')),
    sourceSha256=hashlib.sha256(source.encode('utf-8')).hexdigest(),expectedOutput=expected,
    expectedOutputUtf8Bytes=len(expected.encode('utf-8')),expectedOutputSha256=hashlib.sha256(expected.encode('utf-8')).hexdigest())
catalog['cases']=[cases[name]for name in (ordinary,rules,shipment)]+[observer]
save(lab/'representative.json',catalog)
save(lab/'identity.json',dict(sourceRevision=head,sourcePatchSHA256=sha(lab/'candidate.patch'),
    inputCatalogSHA256=sha(lab/'representative.json'),imageFiles=images,
    coreSHA256={role:files[core.name]for role,files in images.items()},cpythonWorkerSHA256=id['cpythonWorkerSHA256']))
