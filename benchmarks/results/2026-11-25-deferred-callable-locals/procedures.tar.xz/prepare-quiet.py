from pathlib import Path
import hashlib,json,shutil,tarfile

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
quiet=lab/'comparison/quiet'
template=lab.with_name('prepared-map-callback-20261125')
donor=lab.with_name('arithmetic-call-cpython-20261125')/'external'
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,s): p.write_text(s,encoding='utf-8',newline='\n')
def save(p,v): write(p,json.dumps(v,indent=2)+'\n')
source=read(lab/'identity.json')
for role,files in source['imageFiles'].items():
    verify=read(lab/(role+'-verify.json'))
    assert verify['state']=='Completed' and verify['caseCount']==4
    assert verify['catalogSha256']==source['inputCatalogSHA256']
    assert verify['launched']['library']['sha256']==files['Lokad.Lython.dll']
    assert {p.name:sha(p)for p in (lab/role).iterdir()}==files
assert read(lab/'shape.txt')['deferredSites']==93
assert read(lab/'shape.txt')['valueSlots']==194
assert source['coreSHA256']['candidate']==read(lab/'shape.txt')['core']
assert sha(quiet/'representative.json')==source['inputCatalogSHA256']
verify=read(donor/'terminal-status.json')['receipt']
assert verify['complete'] and sha(donor/'observations.tar.xz')==verify['archiveSHA256']
old=read(donor/'identity.json')
for name,value in old['imageFiles']['candidate'].items():
    if name!='Lokad.Lython.dll':
        assert source['imageFiles']['reference'][name]==source['imageFiles']['candidate'][name]==value
assert source['cpythonWorkerSHA256']==old['cpythonWorkerSHA256']
paths=read(quiet/'representative.json')['cases']
ordinary,rules,shipment,_=[case['id'] for case in paths]
jobs=[(ordinary,'warm'),(ordinary,'warm-async'),(rules,'warm'),(ordinary,'compile-run'),(shipment,'warm-async')]
save(quiet/'jobs.json',{'warm':jobs})
purpose='Keep evaluated defaults in admitted locals until a callable can be observed'
identity=source|dict(comparisonRevision=source['sourceRevision'],expectedCPythonSHA256=old['expectedCPythonSHA256'],
    coreSHA256={role+suffix:value for role,value in source['coreSHA256'].items()for suffix in ('','-control')},
    catalogs={name:dict(sha256=sha(quiet/name))for name in ('representative.json','jobs.json')},purpose=purpose)
save(quiet/'identity.json',identity)

collect=(template/'comparison/quiet/collect.py').read_text(encoding='utf-8')
collect=collect.replace('len(jobs) == 4','len(jobs) == 5').replace('b1733-fixtures','b1735-fixtures').replace('started < 237','started < 282')
compile(collect,'collect.py','exec')
write(quiet/'collect.py',collect)
shutil.copyfile(template/'comparison/quiet/run.sh',quiet/'run.sh')
assert b'\r' not in (quiet/'run.sh').read_bytes()

launcher=(template/'quiet.py').read_text(encoding='utf-8').replace('lython-b1733-prepared-map-callback','lython-b1735-deferred-callable-locals')
launcher=launcher.replace('RuntimeMaxSec=259','RuntimeMaxSec=320').replace('seconds=221','seconds=270')
launcher=launcher.replace("'run.sh','collect.py','candidate-core.dll'","'run.sh','collect.py','candidate-core.dll','reference-core.dll'")
launcher=launcher.replace("if name=='Lokad.Lython.dll' and role=='candidate':","if name=='Lokad.Lython.dll':")
launcher=launcher.replace('needs one core','needs two cores')
assert verify['archiveSHA256'] in launcher
launcher=launcher.replace("raw=archived/'confirmation/confirmation.json'","raw=archived/item['member']")
compile(launcher,'quiet.py','exec')
write(lab/'quiet.py',launcher)
archiver=(template/'archive.py').read_text(encoding='utf-8').replace('prepared-map-callback','deferred-callable-locals')
archiver=archiver.replace('==receipt["warmJobs"]==4','==receipt["warmJobs"]==5').replace('timedBatches=112,lanes=4','timedBatches=140,lanes=5')
compile(archiver,'archive.py','exec')
write(lab/'archive.py',archiver)

runs=[
   ('prepared-map-callback-b1733-20261125','2026-11-25-prepared-map-callback','quiet-observations.tar.xz'),
   ('arithmetic-call-cpython-b1731c-20261125','2026-11-25-arithmetic-call-cpython','observations.tar.xz'),
   ('shipment-comprehension-cpu-b1732-20261125','2026-11-25-shipment-comprehension-cpu','observations.tar.xz'),
   ('default-effects-cpu-b1729-20261125','2026-11-25-default-effects-cpu','observations.tar.xz'),
]
verified=[]
for location,folder,leaf in runs:
    evidence=repo/'benchmarks/results'/folder
    archive=evidence/leaf
    terminal=read(evidence/('quiet-terminal-status.json' if leaf.startswith('quiet-') else 'terminal-status.json'))
    assert terminal['receipt']['archiveSHA256']==sha(archive)
    with tarfile.open(archive) as bundle:
        for member in bundle:
            if not member.isfile() or not (member.name=='confirmation/confirmation.json' or member.name.startswith('profiles/')): continue
            blob=bundle.extractfile(member).read()
            if len(blob)<16384:continue
            verified.append(dict(location=location,member=member.name,bytes=len(blob),
                       rawSHA256=hashlib.sha256(blob).hexdigest(),archiveSHA256=terminal['receipt']['archiveSHA256']))
local=read(template/'comparison/quiet/identity.json')['imageFiles']['candidate']
assert {p.name:sha(p)for p in (template/'candidate').iterdir()}==local
oldcore=template/'candidate/Lokad.Lython.dll'
assert local[oldcore.name]==sha(oldcore)
terminal=read(repo/'benchmarks/results/2026-11-25-prepared-map-callback/quiet-terminal-status.json')
verified.append(dict(location=runs[0][0],member='candidate/Lokad.Lython.dll',bytes=oldcore.stat().st_size,
    rawSHA256=sha(oldcore),archiveSHA256=terminal['receipt']['archiveSHA256'],
    localFrozenImage=str(template/'candidate'),localImageFileCount=32))
save(lab/'verified-raw-replicas.json',verified)

payload=quiet/'payload.tar.gz'
with tarfile.open(payload,'w:gz',compresslevel=3) as bundle:
    for name in ('identity.json','jobs.json','representative.json','run.sh','collect.py'):
        bundle.add(quiet/name,arcname=name)
    for role in ('reference','candidate'):
        bundle.add(lab/role/'Lokad.Lython.dll',arcname=role+'-core.dll')
save(quiet/'upload.json',dict(root='deferred-callable-locals-b1735-20261125',reference=read(donor/'upload.json')['root'],
    payloadSHA256=sha(payload),payloadBytes=payload.stat().st_size))
