from pathlib import Path
import hashlib,json,shutil,tarfile

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
quiet=lab/'comparison/quiet'
prior=lab.with_name('deferred-callable-locals-20261125')
old=prior/'comparison/quiet'
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,s):p.write_text(s,encoding='utf-8',newline='\n')
def save(p,value):write(p,json.dumps(value,indent=2)+'\n')
identity=read(lab/'identity.json')
source=read(old/'identity.json')
assert identity['sourceRevision']==source['sourceRevision']
assert identity['imageFiles']['reference']==source['imageFiles']['reference']
receipt=read(old/'terminal-status.json')['receipt']
assert receipt['complete'] and sha(old/'observations.tar.xz')==receipt['archiveSHA256']
for role,files in identity['imageFiles'].items():
    checked=read(lab/(role+'-verify.json'))
    assert len(files)==32 and {p.name:sha(p)for p in (lab/role).iterdir()}==files
    assert checked['state']=='Completed' and checked['caseCount']==4
    assert checked['catalogSha256']==identity['inputCatalogSHA256']==sha(quiet/'representative.json')
    assert checked['launched']['library']['sha256']==files['Lokad.Lython.dll']
shape=read(lab/'shape.txt')
assert shape['deferredSites']==93 and shape['valueSlots']==194 and shape['core']==identity['coreSHA256']['candidate']

ordinary,rules,shipment,_=[case['id']for case in read(quiet/'representative.json')['cases']]
jobs=[(shipment,'warm-async'),(rules,'warm'),(ordinary,'compile-run'),(ordinary,'warm-async'),(ordinary,'warm')]
save(quiet/'jobs.json',{'warm':jobs})
proof=identity|dict(comparisonRevision=identity['sourceRevision'],expectedCPythonSHA256=source['expectedCPythonSHA256'],
    coreSHA256={role+suffix:core for role,core in identity['coreSHA256'].items()for suffix in ('','-control')},
    catalogs={name:dict(sha256=sha(quiet/name))for name in ('representative.json','jobs.json')},
    purpose='Defer callable construction with inline and compiled positional defaults')
save(quiet/'identity.json',proof)
shutil.copyfile(old/'run.sh',quiet/'run.sh')
assert b'\r' not in (quiet/'run.sh').read_bytes()
write(quiet/'collect.py',(old/'collect.py').read_text(encoding='utf-8').replace('b1735-fixtures','b1735c-fixtures'))

launcher=(prior/'quiet.py').read_text(encoding='utf-8').replace('lython-b1735-deferred-callable-locals','lython-b1735c-deferred-callable-locals')
a=launcher.index("assert donor['archiveSHA256']=='")
b=launcher.index('\n',a)
launcher=launcher[:a]+f"assert donor['archiveSHA256']=={receipt['archiveSHA256']!r}"+launcher[b:]
launcher=launcher.replace(",'reference-core.dll'","").replace("assert free>=minimum,(free,'needs two cores", "assert free>=minimum,(free,'needs one core")
launcher=launcher.replace("if name=='Lokad.Lython.dll':","if name=='Lokad.Lython.dll' and role=='candidate':")
launcher=launcher.replace("os.link(reference/'candidate'/name,image/name)","os.link(reference/'reference'/name,image/name)")
compile(launcher,'quiet.py','exec')
write(lab/'quiet.py',launcher)
archiver=(prior/'archive.py').read_text(encoding='utf-8').replace('2026-11-25-deferred-callable-locals"', '2026-11-25-deferred-callable-locals/confirmation"')
compile(archiver,'archive.py','exec')
write(lab/'archive.py',archiver)

# Keep the first candidate's complete immutable local image and its archived
# raw observations. If storage is tight, the prior remote copies are redundant.
image=prior/'candidate'
assert {p.name:sha(p)for p in image.iterdir()}==source['imageFiles']['candidate']
core=image/'Lokad.Lython.dll'
location=read(old/'upload.json')['root']
with tarfile.open(old/'observations.tar.xz') as bundle:
    raw=bundle.extractfile('confirmation/confirmation.json').read()
verified=[
    dict(location=location,member='confirmation/confirmation.json',bytes=len(raw),
        rawSHA256=hashlib.sha256(raw).hexdigest(),archiveSHA256=receipt['archiveSHA256']),
    dict(location=location,member='candidate/Lokad.Lython.dll',bytes=core.stat().st_size,
        rawSHA256=sha(core),archiveSHA256=receipt['archiveSHA256'],localFrozenImage=str(image),localImageFileCount=32),
]
save(lab/'verified-raw-replicas.json',verified)
payload=quiet/'payload.tar.gz'
with tarfile.open(payload,'w:gz',compresslevel=3) as bundle:
    for name in ('identity.json','jobs.json','representative.json','run.sh','collect.py'):
        bundle.add(quiet/name,arcname=name)
    bundle.add(lab/'candidate/Lokad.Lython.dll',arcname='candidate-core.dll')
save(quiet/'upload.json',dict(root='deferred-callable-locals-refined-b1735c-20261125',reference=location,
    payloadSHA256=sha(payload),payloadBytes=payload.stat().st_size))
