from pathlib import Path
import hashlib,json,shutil,subprocess,zipfile
from difflib import unified_diff

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
trial=lab.with_name('deferred-callable-locals-refined-20261125')
prior=lab.with_name('shipment-comprehension-routes-20261125')
source=lab/'source'
source.mkdir(exist_ok=False)
def git(*args):return subprocess.check_output(['git',*args],cwd=repo)
def write(path,contents):path.write_text(contents,encoding='utf-8',newline='\n')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
identity=json.loads((trial/'identity.json').read_text(encoding='utf-8'))
patch=git('diff','--binary','HEAD','--','src')
assert patch==(trial/'candidate.patch').read_bytes()
assert hashlib.sha256(patch).hexdigest()==identity['sourcePatchSHA256']
archive=lab/'source.zip'
git('archive','--format=zip','--output',str(archive),'HEAD','--','src','Directory.Build.props','Directory.Build.targets',
    'Directory.Build.rsp','Directory.Packages.props','global.json','NuGet.Config')
with zipfile.ZipFile(archive) as bundle:
    assert all(not Path(name).is_absolute() and '..' not in Path(name).parts for name in bundle.namelist())
    bundle.extractall(source)
for name in git('diff','--name-only','HEAD','--','src').decode().splitlines():
    shutil.copyfile(repo/name,source/name)
name='src/Lokad.Lython/Runtime/LythonRuntime.Executable.NativeDefinitions.cs'
path=source/name
before=path.read_text(encoding='utf-8')
s=before.replace('    internal ref partial struct NativeExecution',
    '''    internal static int DiagnosticDeferred;
    internal static int DiagnosticMaterialized;
    internal static int DiagnosticRefunded;

    internal ref partial struct NativeExecution''')
s=s.replace('            _hasDeferredDefinitions = true;',
    '            Interlocked.Increment(ref DiagnosticDeferred);\n            _hasDeferredDefinitions = true;')
s=s.replace('                positional.Object = callable;',
    '                positional.Object = callable;\n                Interlocked.Increment(ref DiagnosticMaterialized);')
s=s.replace('                positional = default;',
    '                positional = default;\n                Interlocked.Increment(ref DiagnosticRefunded);')
write(path,s)
write(lab/'diagnostic.patch',''.join(unified_diff(before.splitlines(keepends=True),s.splitlines(keepends=True),'a/'+name,'b/'+name)))
image=lab/'image'
image.mkdir(exist_ok=False)
files=identity['imageFiles']['candidate']
assert len(files)==32 and {f.name:sha(f)for f in (trial/'candidate').iterdir()}==files
for name in files:shutil.copyfile(trial/'candidate'/name,image/name)
shutil.copyfile(prior/'RouteProbe.csproj',lab/'RouteProbe.csproj')
catalog=json.loads((trial/'representative.json').read_text(encoding='utf-8'))
catalog['cases']=[case|{'runAsync':mode}for case in catalog['cases']for mode in (False,True)]
write(lab/'cases.json',json.dumps(catalog,ensure_ascii=False))
s=(prior/'Program.cs').read_text(encoding='utf-8')
a=s.index('string[] names')
b=s.index('foreach (var item',a)
s=s[:a]+'''string[] names = ["Deferred", "Materialized", "Refunded"];
var runtime = typeof(LythonEngine).Assembly.GetType("Lokad.Lython.Runtime.LythonRuntime", true)!;
var fields = names.Select(name => runtime.GetField("Diagnostic" + name, all)!).ToArray();
'''+s[b:]
s=s.replace('        transfers.Clear();\n','').replace('transfers = transfers.OrderBy(pair => pair.Key).ToDictionary(), ','')
write(lab/'Program.cs',s)
write(lab/'identity.json',json.dumps(dict(source=identity['sourceRevision'],patchSHA256=identity['sourcePatchSHA256'],
    diagnosticPatchSHA256=sha(lab/'diagnostic.patch'),candidateCoreSHA256=files['Lokad.Lython.dll']),indent=2)+'\n')
