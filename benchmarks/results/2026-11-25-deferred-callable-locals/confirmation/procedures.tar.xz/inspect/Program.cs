using System.Collections;
using System.Reflection;
using System.Security.Cryptography;
using System.Text.Json;
using Lokad.Lython;

const BindingFlags all = BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic;
object Read(object value, string name) => value.GetType().GetProperty(name, all)!.GetValue(value)!;
object[] Items(object value) => ((IEnumerable)value).Cast<object>().ToArray();
object[] Definitions(object code) => Items(Read(code, "Constants"))
    .Where(value => value?.GetType().Name == "ExecutableCreateFunction").ToArray();

using var catalog = JsonDocument.Parse(File.ReadAllText(args[0]));
var source = catalog.RootElement.GetProperty("cases").EnumerateArray()
    .Single(item => item.GetProperty("id").GetString() == "diagnostic.generated-ordinary-definitions");
var budget = new LythonMemoryBudget(32 * 1024 * 1024);
using (var script = new LythonEngine().Compile(source.GetProperty("source").GetString()!, budget))
{
    if (!script.IsValid) throw new InvalidOperationException(string.Join("\n", script.Diagnostics));
    var executable = typeof(LythonCompiledScript).GetField("_executable", all)!.GetValue(script)!;
    var module = Read(executable, "EntryPoint");
    var factory = Definitions(module).Select(definition => Read(definition,"CodeObject"))
        .Single(code => (string)Read(code,"Name") == "build");
    var definitions = Definitions(factory);
    var factoryLocals = (string[])Read(factory, "LocalNames");
    var instructions = Items(Read(factory, "Instructions"));
    var constants = Items(Read(factory, "Constants"));
    string Code(object i) => Read(i,"OpCode").ToString()!;
    var loads = instructions.Where(i => Code(i) == "LoadLocal")
        .GroupBy(i => factoryLocals[(int)Read(i,"LocalSlot")])
        .ToDictionary(group => group.Key, group => group.Count());
    var assignments = instructions.Select((step,index) => (step,index))
        .Where(pair => Code(pair.step) is "ApplyOperation" or "ApplyDeferredDefinition" &&
            constants[(int)Read(pair.step,"ConstantIndex")]?.GetType().Name == "ExecutableCreateFunction")
        .Select(pair => new {
            type = (string)Read(Read(constants[(int)Read(pair.step,"ConstantIndex")],"CodeObject"),"Name"),
            slot = pair.index+1 < instructions.Length && Code(instructions[pair.index+1])=="StoreLocal"
                ? factoryLocals[(int)Read(instructions[pair.index+1],"LocalSlot")] : null
        }).ToArray();
    if (assignments.Length != 96 || assignments.Any(pair => pair.slot is null))
        throw new InvalidDataException("Unexpected ordinary assignment shape.");
    Console.WriteLine(JsonSerializer.Serialize(new {
        core = Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(typeof(LythonEngine).Assembly.Location))).ToLowerInvariant(),
        sourceSHA256=source.GetProperty("sourceSha256").GetString(),
        valueSlots = (int)Read(factory, "ValueStorageCapacity"),
        localCount = factoryLocals.Length,
        definitions = definitions.Length,
        deferredSites = Items(Read(factory, "DeferredDefinitionSites")).Length,
        defined = assignments.Count(a => a.type != "<lambda>"),
        assignedLambdas = assignments.Count(a => a.type == "<lambda>"),
        closureCount=Items(Read(factory, "CapturedLocalSlots")).Length,
        declaredLoadInstructions = assignments.Where(a => loads.ContainsKey(a.slot!)).ToDictionary(a => a.slot!, a => loads[a.slot!]),
        defaultStartCount = instructions.Count(i => Read(i, "OpCode").ToString()=="StartFunctionDefaults"),
        defaultStoreCount = instructions.Count(i => Read(i, "OpCode").ToString()=="StoreFunctionDefault"),
        directScalarArgumentCount = instructions.Count(i => Read(i, "OpCode").ToString()=="LoadGlobalForArithmeticCall"),
    }, new JsonSerializerOptions { WriteIndented = true }));
}
if(budget.ReservedBytes != 0) throw new InvalidOperationException("An owner did not return allowance.");
