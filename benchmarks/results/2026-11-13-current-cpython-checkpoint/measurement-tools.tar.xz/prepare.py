from pathlib import Path
import ast, hashlib, json, tarfile
r=Path(__file__).parent
out=r/'b704';out.mkdir()
prior=r.parent/'checkpoint-cpython-r318/b683/retrieved/representative.json'
catalog=json.loads(prior.read_text(encoding='utf-8'))
current=json.loads((r/'catalog.json').read_text(encoding='utf-8'))
indexed={c['id']:c for c in catalog['cases']}
for case in current['cases']:
    old=indexed[case['id']]
    for name in ['sourceSha256','fixtureSha256','expectedOutputSha256','expectedFilesSha256']:
        assert old.get(name)==case.get(name),(case['id'],name)
jobs=[['scripts.csv-invoice.large','warm'],['scripts.csv-invoice.large','compile'],['scripts.csv-invoice.large','compile-run'],['scripts.text-summary-helpers.nonlocal-counter.large','warm'],['scripts.json-summary-helpers.large','warm'],['scripts.file-search.large','warm'],['scripts.report-render.large','warm']]
assert all(case in indexed for case,lane in jobs)
data=prior.read_bytes();(out/'catalog.json').write_bytes(data)
identity=json.loads((r/'identity.json').read_text(encoding='utf-8'))
identity['catalogSHA256']=hashlib.sha256(data).hexdigest()
identity['originalPreTimingFailure']='B703 supplied a two-case catalog; stopped before any guest work. Corrected B704 reuses exact B683 representative cases, with current text/search source/fixture/golden hashes verified equal.'
(out/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8')
oldroot='/home/lokad/lython-bench-checks/current-external-b703-20261113';root='/home/lokad/lython-bench-checks/current-external-b704-20261113'
for name in ['collect.py','archive-owned.py','run.sh','retrieve.py','summarize.py','launch.py','save.py']:
    s=(r/name).read_text(encoding='utf-8').replace(oldroot,root).replace('lython-b703-current-external-20261113','lython-b704-current-external-20261113').replace('B703','B704')
    if name in ['launch.py','save.py']:s=s.replace("r.parent/'dictionary-boundaries-r331", "r.parent.parent/'dictionary-boundaries-r331")
    if name=='save.py':
        s=s.replace("qualification is\n+tracked", "qualification is\n+tracked")
        s=s.replace("for name in ['summary.json'", "for name in ['summary.json'")
    if name.endswith('.py'):ast.parse(s)
    (out/name).write_text(s,encoding='utf-8',newline='\n')
with tarfile.open(out/'payload.tgz','w:gz')as t:
    for name in ['identity.json','collect.py','archive-owned.py','run.sh']:t.add(out/name,arcname=name)
    t.add(out/'catalog.json',arcname='representative.json')
with tarfile.open(out/'payload.tgz')as t:unpacked=sum(m.size for m in t.getmembers())
config=json.loads((r/'config.json').read_text(encoding='utf-8'))
config.update(root=root,unit='lython-b704-current-external-20261113',identity=identity,payloadBytes=(out/'payload.tgz').stat().st_size,payloadSHA256=hashlib.sha256((out/'payload.tgz').read_bytes()).hexdigest(),unpackedBytes=unpacked)
(out/'config.json').write_text(json.dumps(config,indent=2)+'\n',encoding='utf-8')
p=Path('PLAN.md');s=p.read_text(encoding='utf-8')
s=s.replace('   Stop after usable bounded observations; choose the next redesign from remaining', '''   B703 stops before guest work: a two-case catalog was mistakenly supplied.
   Original setup/journal are archived, empty mount removed under idle lease.
   B704 uses the established representative catalog; overlapping text/search source,
   fixture and output hashes match. Local case validation precedes corrected launch.
   Stop after usable bounded observations; choose the next redesign from remaining''')
p.write_text(s,encoding='utf-8',newline='\n')
print('Corrected seven-job catalog validated locally; all overlapping source/fixture/golden hashes unchanged.',flush=True)
