from pathlib import Path
import base64, hashlib, json, subprocess, tarfile
r=Path(__file__).parent
observations=sorted(r.glob('observation-*.json'))
assert len(observations)==1
status=json.loads(observations[0].read_text(encoding='utf-8'))
assert status['exitCode']=='1' and not status['remainingWorkers'] and status['remainingTrace']
(r/'terminal-status.json').write_text(json.dumps(status,indent=2)+'\n',encoding='utf-8')
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
code=r'''from pathlib import Path
import fcntl,hashlib,json,subprocess,tarfile
r=Path('/home/lokad/lython-bench-checks/current-external-b703-20261113');base=r.parent
with(base/'comparison-vm.lock').open('a')as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record|[p]ython3.*cpython-worker.py'],capture_output=True).returncode==1
 journal=subprocess.check_output(['sudo','-n','journalctl','-u','lython-b703-current-external-20261113.service','--no-pager'],text=True)
 assert 'assert len(jobs)==7' in journal
 (r/'failure-journal.txt').write_text(journal)
 assert not (r/'confirmation/confirmation.json').exists()
 fixture=r/'guest-fixtures';assert fixture.resolve()==fixture and fixture.parent==r and not list(fixture.iterdir())
 with tarfile.open(r/'failed-setup.tgz','w:gz')as t:
  for name in ['identity.json','representative.json','collect.py','archive-owned.py','run.sh','source-identity.json','space-preflight.json','exit-code.txt','failure-journal.txt']:t.add(r/name,arcname=name)
 with tarfile.open(r/'failed-setup.tgz')as t:assert 'failure-journal.txt' in t.getnames()
 digest=hashlib.sha256((r/'failed-setup.tgz').read_bytes()).hexdigest()
 subprocess.run(['sudo','-n','umount',str(fixture)],check=True);fixture.rmdir()
 result=dict(noGuestWorkOrTiming=True,noRemainingUsers=True,emptyFixtureRemoved=True,archiveSHA256=digest)
 (r/'failed-setup.json').write_text(json.dumps(result)+'\n');print(json.dumps(result))
'''
(r/'preserve-first-command.py').write_text(code,encoding='utf-8')
command="python3 -c 'import base64;exec(base64.b64decode(\""+base64.b64encode(code.encode()).decode()+"\"))'"
done=subprocess.run(ssh+[command],capture_output=True,text=True,encoding='utf-8')
(r/'preserve-first.log').write_text(done.stdout+done.stderr,encoding='utf-8')
assert done.returncode==0,done.stderr
print(done.stdout,flush=True)
scp=['C:/Windows/System32/OpenSSH/scp.exe','-i',ssh[2],'-o','BatchMode=yes','-o','ConnectTimeout=15']
for name in ['failed-setup.tgz','failed-setup.json']:
 done=subprocess.run(scp+['lokad@20.166.121.73:/home/lokad/lython-bench-checks/current-external-b703-20261113/'+name,str(r/name)],capture_output=True)
 assert done.returncode==0,done.stderr
receipt=json.loads((r/'failed-setup.json').read_text(encoding='utf-8'))
assert hashlib.sha256((r/'failed-setup.tgz').read_bytes()).hexdigest()==receipt['archiveSHA256']
with tarfile.open(r/'failed-setup.tgz')as t:assert 'failure-journal.txt' in t.getnames()
