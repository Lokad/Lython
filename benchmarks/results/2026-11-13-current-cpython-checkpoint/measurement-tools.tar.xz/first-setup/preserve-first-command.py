from pathlib import Path
import fcntl,hashlib,json,subprocess,tarfile
r=Path('/home/lokad/lython-bench-checks/current-external-b703-20261113');base=r.parent
with(base/'comparison-vm.lock').open('a')as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record|[p]ython3.*cpython-worker.py'],capture_output=True).returncode==1
 journal=subprocess.check_output(['sudo','-n','journalctl','-u','lython-b703-current-external-20261113.service','--no-pager'],text=True)
 assert 'assert len(jobs)==7' in journal
 (r/'failure-journal.txt').write_text(journal)
 assert not (r/'confirmation/confirmation.json').exists()
 fixture=r/'guest-fixtures';assert fixture.resolve()==fixture and fixture.parent==r and not list(fixture.iterdir())
 with tarfile.open(r/'failed-setup.tgz','w:gz')as t:
  for name in ['identity.json','representative.json','collect.py','archive-owned.py','run.sh','source-identity.json','space-preflight.json','exit-code.txt','failure-journal.txt']:t.add(r/name,arcname=name)
 with tarfile.open(r/'failed-setup.tgz')as t:assert 'failure-journal.txt' in t.getnames()
 digest=hashlib.sha256((r/'failed-setup.tgz').read_bytes()).hexdigest()
 subprocess.run(['sudo','-n','umount',str(fixture)],check=True);fixture.rmdir()
 result=dict(noGuestWorkOrTiming=True,noRemainingUsers=True,emptyFixtureRemoved=True,archiveSHA256=digest)
 (r/'failed-setup.json').write_text(json.dumps(result)+'\n');print(json.dumps(result))
