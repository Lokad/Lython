from pathlib import Path
import ast, hashlib, json, tarfile

r = Path(__file__).parent
prior = r.parent / 'checkpoint-cpython-r318/b683'
source = r.parent / 'dictionary-boundaries-r331'
oldroot = '/home/lokad/lython-bench-checks/retained-external-b683-20261113'
root = '/home/lokad/lython-bench-checks/current-external-b703-20261113'
unit = 'lython-b703-current-external-20261113'
frozen = json.loads((source / 'candidate-identity.json').read_text(encoding='utf-8'))
old = json.loads((source / 'b702/identity.json').read_text(encoding='utf-8'))
assert frozen['coreSHA256']['candidate'].startswith('798edc1d')
assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest() == sha for p, sha in frozen['sources'].items())
catalog = (source / 'catalog.json').read_bytes()
(r / 'catalog.json').write_bytes(catalog)
identity = dict(sourceRevision='Committedd90dd5fe/frozen798edc1d; R331 full delivery independently tracked',
    purpose='Current five representative whole scripts and separate invoice compilation/compile-to-result; CPython3.13.16, no source-pair attribution',
    coreSHA256={label: frozen['coreSHA256']['candidate'] for label in ['reference', 'candidate', 'reference-control', 'candidate-control']},
    auxiliaryFiles=old['candidateAuxiliaryFiles'], catalogSHA256=hashlib.sha256(catalog).hexdigest(),
    sourceIdentitySHA256=hashlib.sha256((source / 'candidate-identity.json').read_bytes()).hexdigest(),
    qualificationRun='43520131516', publicationPostponed=True)
(r / 'identity.json').write_text(json.dumps(identity, indent=2)+'\n', encoding='utf-8')
for name in ['collect.py', 'archive-owned.py', 'run.sh', 'retrieve.py', 'summarize.py']:
    s = (prior / name).read_text(encoding='utf-8').replace(oldroot, root).replace('lython-b683-retained-external-20261113', unit).replace('B683', 'B703')
    if name == 'collect.py':
        s = s.replace("        self.sequence += 1\n        request =", "        request_started = time.monotonic()\n        self.sequence += 1\n        request =")
        s = s.replace("        if operation == 'batch': self.last_cpu_ticks=process_cpu_ticks(self.process.pid)-before_cpu", "        if operation == 'batch': self.last_cpu_ticks=process_cpu_ticks(self.process.pid)-before_cpu\n        self.last_request_seconds = time.monotonic()-request_started")
        s = s.replace("seconds=response['elapsedTicks']/response['clockFrequency']", "seconds=w.last_request_seconds")
        s = s.replace("purpose='Current corrected qualified source: invoice compile/warm/compile-run and captured text/JSON/file-search/report warm; no historical rows relabeled'", "purpose=identity['purpose'], warmupBoundary='full request wall time; sum retained responses for guest totals', batchSizingBoundary='full request wall time, unchanged command-v2 guest timing'")
        s = s.replace("self.identity['serverGc']", "self.identity['serverGc']")
        s = s.replace("            assert not self.identity['serverGc']", "            for name, sha in identity['auxiliaryFiles'].items():\n                library = next((v for v in self.identity['libraries'] if Path(v['path']).name == name), None)\n                if library is not None: assert library['sha256'].lower() == sha\n            assert not self.identity['serverGc']")
    if name == 'retrieve.py':
        s = s.replace('Owned B657 remains active', 'Owned B703 remains active')
    if name.endswith('.py'): ast.parse(s)
    (r / name).write_text(s, encoding='utf-8', newline='\n')
with tarfile.open(r / 'payload.tgz', 'w:gz') as t:
    for name in ['identity.json', 'collect.py', 'archive-owned.py', 'run.sh']:
        t.add(r / name, arcname=name)
    t.add(r / 'catalog.json', arcname='representative.json')
with tarfile.open(r / 'payload.tgz') as t: unpacked = sum(m.size for m in t.getmembers())
config = dict(root=root, sourceRoot='/home/lokad/lython-bench-checks/dictionary-boundaries-b702-20261113',
    unit=unit, identity=identity, payloadBytes=(r / 'payload.tgz').stat().st_size,
    payloadSHA256=hashlib.sha256((r / 'payload.tgz').read_bytes()).hexdigest(), unpackedBytes=unpacked)
(r / 'config.json').write_text(json.dumps(config, indent=2)+'\n', encoding='utf-8')
p = Path('PLAN.md')
s = p.read_text(encoding='utf-8')
needle = '   casing already uses bulk Ascii APIs; native histograms already probe compact\n   UTF8 words without repeated string materialization. Do not recreate either.'
assert needle in s
s = s.replace(needle, needle+'''
   **R332 current external checkpoint active:** reuse frozen798/fixed acda workers,
   five maintained whole scripts and separate invoice compile/warm/fresh lanes,
   stock CPython3.13.16. Seven jobs under one360s owner; full-request wall warmup/
   batch sizing, unchanged guest clocks, two independent processes per engine,
   quiet/golden/ownership/join/archive gates. No production change or causal
   speedup claim. Qualification43520131516 runs independently; publish current
   table only with its actual status. Retain B683 and adverse/moving controls.
   Stop after usable bounded observations; choose the next redesign from remaining
   complete-script gaps and existing source proofs, without unchanged profiling.''')
p.write_text(s, encoding='utf-8', newline='\n')
print('Prepared seven-job current external checkpoint; no core upload or runtime mutation.', flush=True)
