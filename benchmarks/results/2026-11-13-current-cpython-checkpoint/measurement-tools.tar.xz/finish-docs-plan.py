from pathlib import Path
import json,re
r=Path(__file__).parent
summary=json.loads((r/'summary.json').read_text(encoding='utf-8'))
rows={(v['case'],v['lane']):v for v in summary['timing']}
for file in ['docs/BENCHMARKS.md','benchmarks/results/2026-11-13-current-cpython-checkpoint/README.md']:
    p=Path(file);s=p.read_text(encoding='utf-8')
    for row in rows.values():
        med=row['medianMilliseconds']
        for prefix in ['candidate','CPython']:
            values=[v for k,v in med.items()if k.startswith(prefix)]
            factor,unit=(1000,'µs')if max(values)<1 else(1,'ms')
            old=f'{min(values)*factor:.2f}–{max(values)*factor:.2f} {unit}'
            precision=1 if factor==1000 else 3
            new=f'{min(values)*factor:.{precision}f}–{max(values)*factor:.{precision}f} {unit}'
            s=s.replace(old,new)
    s=s.replace('**CPython3.13.16**. Focused actual .NET11/10 checks pass; full Windows/Ubuntu, original stress and installed-package qualification43520131516 is still pending.',
        '**CPython 3.13.16**. Focused .NET 11/10 checks pass; full Windows/Ubuntu,\noriginal stress and installed-package qualification is\n[pending](https://github.com/Lokad/Lython/actions/runs/43520131516).')
    s=s.replace('The quiet AzureF4as_v7 VM runs Ubuntu24.04.4, four AMD EPYC9V45 vCPUs,\n16GiB/no swap and .NET11RC3, ordinary workstation GC/tiering and CPython GIL/GC.',
        'The quiet Azure F4as_v7 VM runs Ubuntu 24.04.4, four AMD EPYC 9V45 vCPUs,\n16 GiB/no swap and .NET 11 RC3, ordinary workstation GC/tiering and CPython GIL/GC.')
    p.write_text(s,encoding='utf-8',newline='\n')
p=Path('PLAN.md');s=p.read_text(encoding='utf-8')
a=s.index('| Current external comparison |');b=s.index('\n',a)
s=s[:a]+'''| Current external comparison, full source qualification pending | R332/B704 committedd90dd5fe/frozen798,2026-11-13, CPython3.13.16/quietF4as_v7;7jobs/294.095s/all gates. Invoice warm1.25–1.26×, compile1.08–1.10×, fresh1.23–1.27×; text1.51–1.54×, search1.65–1.69×, JSON0.82–0.85×, report1.21–1.22×. Search/report maxIQR5.01/4.62% and moving process controls explicit; no causal gain claim against B683. [Current boundaries/evidence](docs/BENCHMARKS.md). |'''+s[b:]
a=s.index('   **R332 current external checkpoint active:**');b=s.index('\n\n2. **Regex',a)
s=s[:a]+'''   **R332 complete:** B704 refreshes all five representative scripts and invoice
   compile/warm/fresh lanes at798, with existing tooling and independent CPython
   baseline. All gates pass; original B703 pre-timing catalog failure and B704 space
   refusals remain. Only rebuildable apt downloads cleared; no evidence/image retired.
   The remaining text/search gaps support continuing execution/operand work, not
   another bulk-ASCII/CSV-construction rewrite already present. Invoice compilation
   is roughly102µs within7.7–7.9ms fresh execution; this does not establish frontend
   dominance for short configuration scripts. No new runtime prototype selected
   from mixed owning-frame shares. [Checkpoint](benchmarks/results/2026-11-13-current-cpython-checkpoint/README.md).
   Source review confirms Run/RunAsync share the instruction prefix, member cache
   and compiled functions; the old async review is not a current missing stage.
   Continue the construction/transport roadmap and independent regex/XML work;
   this completed measurement does not complete the performance objective.'''+s[b:]
p.write_text(s,encoding='utf-8',newline='\n')
print('Current metrics/limits recorded; completed evidence condensed, broader roadmap active.',flush=True)
