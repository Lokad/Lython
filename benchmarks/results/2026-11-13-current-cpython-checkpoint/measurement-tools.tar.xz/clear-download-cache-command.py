from pathlib import Path
import fcntl,json,shutil,subprocess
base=Path('/home/lokad/lython-bench-checks')
with(base/'comparison-vm.lock').open('a')as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record|[p]ython3.*cpython-worker.py'],capture_output=True).returncode==1
 assert not(base/'current-external-b704-20261113').exists()
 before=shutil.disk_usage(base).free
 done=subprocess.run(['sudo','-n','apt-get','clean'],text=True,capture_output=True)
 assert done.returncode==0,done.stderr
 print(json.dumps(dict(action='apt-get clean: rebuildable downloaded packages only',freshIdleLease=True,beforeFreeBytes=before,afterFreeBytes=shutil.disk_usage(base).free,stdout=done.stdout,stderr=done.stderr,noBenchmarkEvidenceOrImagesRemoved=True)))
