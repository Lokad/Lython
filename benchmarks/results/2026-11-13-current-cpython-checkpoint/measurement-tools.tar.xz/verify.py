from pathlib import Path
import hashlib,json,re,statistics,tarfile
r=Path(__file__).parent
out=Path('benchmarks/results/2026-11-13-current-cpython-checkpoint')
raw=json.loads((r/'retrieved/confirmation/confirmation.json').read_text(encoding='utf-8'))
summary=json.loads((out/'summary.json').read_text(encoding='utf-8'))
assert len(raw['jobs'])==len(summary['timing'])==7 and raw['complete']
for job,row in zip(raw['jobs'],summary['timing']):
    assert(job['case'],job['lane'])==(row['case'],row['lane'])
    med={label:statistics.median(1000*s['response']['elapsedTicks']/s['response']['clockFrequency']/s['response']['completedInvocations']for s in job['samples']if s['engine']==label)for label in job['identities']}
    assert med==row['medianMilliseconds']
    assert sorted(med[a]/med[b]for a in ['candidate','candidate-control']for b in ['CPython','CPython-control'])==row['ratioRange']
    assert job['workersJoinedAndFixturesRemoved']
receipt=json.loads((out/'archive-receipt.json').read_text(encoding='utf-8'))
assert hashlib.sha256((out/'observations.tgz').read_bytes()).hexdigest()==receipt['archiveSHA256']
with tarfile.open(out/'observations.tgz')as t:assert json.loads(t.extractfile('confirmation/confirmation.json').read())==raw
for p in [Path('docs/BENCHMARKS.md'),out/'README.md']:
    text=p.read_text(encoding='utf-8')
    assert 'd90dd5fe' in text and '798edc1d' in text
    for target in re.findall(r'\]\(([^)]+)\)',text):
        if '://' in target or target.startswith('#'):continue
        path=target.split('#')[0]
        assert(p.parent/path).exists(),(str(p),target)
with tarfile.open(out/'measurement-tools.tar.xz')as t:
    files={m.name:t.extractfile(m).read()for m in t.getmembers()if m.isfile()}
for name in ['finish-docs-plan.py','verify.py']:
    files[name]=(r/name).read_bytes()
import io
with tarfile.open(out/'measurement-tools.tar.xz','w:xz')as t:
    for name,data in sorted(files.items()):
        entry=tarfile.TarInfo(name);entry.size=len(data);t.addfile(entry,io.BytesIO(data))
print('Seven raw medians/all ratio pairings, owned archive SHA/content, exact source labels and current documentation links verified.',flush=True)
