from pathlib import Path
import hashlib,json,shutil,tarfile
r=Path(__file__).parent
failure=r/'full-catalog-space-refused';failure.mkdir()
for name in ['config.json','catalog.json','identity.json','payload.tgz','launch-command.py','launch.log']:
    shutil.copyfile(r/name,failure/name)
d=json.loads((r/'catalog.json').read_text(encoding='utf-8'))
ids={'scripts.csv-invoice.large','scripts.text-summary-helpers.nonlocal-counter.large','scripts.json-summary-helpers.large','scripts.file-search.large','scripts.report-render.large'}
old={c['id']:c for c in d['cases']}
assert ids<=old.keys()
d['cases']=[c for c in d['cases']if c['id']in ids]
assert len(d['cases'])==5
for c in d['cases']:assert c==old[c['id']]
data=(json.dumps(d,ensure_ascii=False,separators=(',',':'))+'\n').encode('utf-8')
(r/'catalog.json').write_bytes(data)
identity=json.loads((r/'identity.json').read_text(encoding='utf-8'))
identity['catalogSHA256']=hashlib.sha256(data).hexdigest()
identity['spacePreflightCorrection']='Full historical catalog failed unchanged space floor before staging. Keep only the five measured cases, retaining their exact source/fixture/golden fields; no input or workload reduced.'
(r/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8')
with tarfile.open(r/'payload.tgz','w:gz')as t:
    for name in ['identity.json','collect.py','archive-owned.py','run.sh']:t.add(r/name,arcname=name)
    t.add(r/'catalog.json',arcname='representative.json')
with tarfile.open(r/'payload.tgz')as t:unpacked=sum(m.size for m in t.getmembers())
c=json.loads((r/'config.json').read_text(encoding='utf-8'))
c.update(identity=identity,payloadBytes=(r/'payload.tgz').stat().st_size,payloadSHA256=hashlib.sha256((r/'payload.tgz').read_bytes()).hexdigest(),unpackedBytes=unpacked)
(r/'config.json').write_text(json.dumps(c,indent=2)+'\n',encoding='utf-8')
print('Unused catalog cases omitted; identical five measured cases, unpacked bytes',unpacked,flush=True)
