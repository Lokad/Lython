from pathlib import Path
import base64,json,shutil,subprocess
r=Path(__file__).parent
failure=r/'selected-catalog-space-refused';failure.mkdir()
for name in ['config.json','catalog.json','identity.json','payload.tgz','launch-command.py','launch.log']:shutil.copyfile(r/name,failure/name)
code=r'''from pathlib import Path
import fcntl,json,shutil,subprocess
base=Path('/home/lokad/lython-bench-checks')
with(base/'comparison-vm.lock').open('a')as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record|[p]ython3.*cpython-worker.py'],capture_output=True).returncode==1
 assert not(base/'current-external-b704-20261113').exists()
 before=shutil.disk_usage(base).free
 done=subprocess.run(['sudo','-n','apt-get','clean'],text=True,capture_output=True)
 assert done.returncode==0,done.stderr
 print(json.dumps(dict(action='apt-get clean: rebuildable downloaded packages only',freshIdleLease=True,beforeFreeBytes=before,afterFreeBytes=shutil.disk_usage(base).free,stdout=done.stdout,stderr=done.stderr,noBenchmarkEvidenceOrImagesRemoved=True)))
'''
(r/'clear-download-cache-command.py').write_text(code,encoding='utf-8')
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
command="python3 -c 'import base64;exec(base64.b64decode(\""+base64.b64encode(code.encode()).decode()+"\"))'"
done=subprocess.run(ssh+[command],capture_output=True,text=True,encoding='utf-8')
(r/'clear-download-cache.log').write_text(done.stdout+done.stderr,encoding='utf-8')
assert done.returncode==0,done.stderr
data=json.loads(done.stdout)
(r/'clear-download-cache.json').write_text(json.dumps(data,indent=2)+'\n',encoding='utf-8')
print(data,flush=True)
