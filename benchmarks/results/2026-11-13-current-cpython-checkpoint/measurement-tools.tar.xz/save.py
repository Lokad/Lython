from pathlib import Path
import hashlib, json, shutil, subprocess, tarfile

r=Path(__file__).parent
s=json.loads((r/'summary.json').read_text(encoding='utf-8'))
assert s['complete'] and s['jobs']==7
receipt=json.loads((r/'archive-receipt.json').read_text(encoding='utf-8'))
assert hashlib.sha256((r/'observations.tgz').read_bytes()).hexdigest()==receipt['archiveSHA256']
assert receipt['allWorkersJoined'] and receipt['guestFixturesRemoved'] and receipt['quietBeforeAndAfter']
source=r.parent.parent/'dictionary-boundaries-r331'
frozen=json.loads((source/'candidate-identity.json').read_text(encoding='utf-8'))
assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==sha for p,sha in frozen['sources'].items())
head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
assert head=='d90dd5fecafff2889cc0e5107fb9256db294afe4'
out=Path('benchmarks/results/2026-11-13-current-cpython-checkpoint')
out.mkdir()
for name in ['summary.json','identity.json','archive-receipt.json','terminal-status.json','observations.tgz']:
    shutil.copyfile(r/name,out/name)
first=json.loads((r.parent/'failed-setup.json').read_text(encoding='utf-8'))
assert hashlib.sha256((r.parent/'failed-setup.tgz').read_bytes()).hexdigest()==first['archiveSHA256']
shutil.copyfile(r.parent/'failed-setup.tgz',out/'first-setup-failed.tgz')
with tarfile.open(out/'measurement-tools.tar.xz','w:xz')as t:
    for name in ['prepare.py','trim-unused-cases.py','clear-download-cache.py','clear-download-cache-command.py','clear-download-cache.json','clear-download-cache.log','launch.py','launch-command.py','collect.py','archive-owned.py','run.sh','retrieve.py','summarize.py','save.py','catalog.json','config.json','launch.log','observe-not-before.json','extraction.json']:
        t.add(r/name,arcname=name)
    for name in ['full-catalog-space-refused','selected-catalog-space-refused']:
        t.add(r/name,arcname=name)
    for name in ['prepare.py','preserve-first.py','preserve-first-command.py','preserve-first.log','failed-setup.json','terminal-status.json']:
        t.add(r.parent/name,arcname='first-setup/'+name)
guide=Path('docs/BENCHMARKS.md')
prior=guide.read_text(encoding='utf-8')
(out/'prior-BENCHMARKS.md').write_text(prior,encoding='utf-8',newline='\n')
rows={(v['case'],v['lane']):v for v in s['timing']}
cases=[('scripts.csv-invoice.large','CSV invoice / pricing helpers','4,096 records /127,031 B'),
       ('scripts.text-summary-helpers.nonlocal-counter.large','Text / captured helper and counter','3,072 lines /35,840 B'),
       ('scripts.json-summary-helpers.large','JSON-lines / aggregation helpers','4,096 records /110,592 B'),
       ('scripts.file-search.large','File search / keyword-default helper','2,049 lines /42,010 B; stop after1,025'),
       ('scripts.report-render.large','JSON-to-Markdown report','3,072 records /189,441 B')]
def times(row,prefix):
    med=row['medianMilliseconds'];v=[med[k]for k in med if k.startswith(prefix)]
    factor,unit=(1000,'µs')if max(v)<1 else(1,'ms')
    return f'{min(v)*factor:.2f}–{max(v)*factor:.2f} {unit}'
def ratio(row):return f"{min(row['ratioRange']):.2f}–{max(row['ratioRange']):.2f}×"
def status(row):return f"Diagnostic; spreads{row['lythonControlPercent']:.2f}/{row['cpythonControlPercent']:.2f}%; maxIQR{row['maxIqrPercent']:.2f}%"
table='| Representative workload, warm execution | Input | Lython | CPython | Lython / CPython | Measurement status |\n| --- | --- | ---: | ---: | ---: | --- |\n'
for case,label,size in cases:
    row=rows[case,'warm'];table+=f'| {label} |{size}|{times(row,"candidate")}|{times(row,"CPython")}|{ratio(row)}|{status(row)}|\n'
invoice=rows['scripts.csv-invoice.large','compile'];fresh=rows['scripts.csv-invoice.large','compile-run']
qual=source/'delivery/ci-terminal.json'
green=qual.exists()and json.loads(qual.read_text(encoding='utf-8'))['conclusion']=='success'
qualification=('Full Windows/Ubuntu .NET11/10, original stress and installed-package qualification passes.'if green else'Focused actual .NET11/10 checks pass; full Windows/Ubuntu, original stress and installed-package qualification43520131516 is still pending.')
intro=f'''# Performance against CPython

{table}
**Ratio = Lython elapsed / CPython elapsed; above one means slower.** These are
complete embedding measurements, not isolated interpreter CPU. Spreads are the
Lython/CPython process-median differences; moving controls and IQRs remain visible.

Measured 2026-11-13 UTC: **runtime d90dd5fe / frozen798edc1d**, against stock
**CPython3.13.16**. {qualification}
The quiet AzureF4as_v7 VM runs Ubuntu24.04.4, four AMD EPYC9V45 vCPUs,
16GiB/no swap and .NET11RC3, ordinary workstation GC/tiering and CPython GIL/GC.

Warm clocks include mediated RAM-file I/O, full stdout/file validation and
prior-result cleanup. They exclude compilation, startup, fixture staging/reset,
protocol and final cache teardown. Two independent processes per engine, five
rotating rounds. Ranges span process medians and ratios all four pairings;
they are not confidence intervals. Warmup and batch sizing use full-request
wall time; guest-execution clocks remain unchanged. This refresh does not
attribute differences from older collections to individual changes.
[Exact sources, raw/wider CPU and controls](../benchmarks/results/2026-11-13-current-cpython-checkpoint/README.md).

## Compilation, compile-to-result and startup

The same invoice source separates frontend cost from execution:

| Phase | Lython | CPython | Lython / CPython | Status |
| --- | ---: | ---: | ---: | --- |
| Compilation alone |{times(invoice,'candidate')}|{times(invoice,'CPython')}|{ratio(invoice)}|{status(invoice)}|
| Compile and execute once in a running host |{times(fresh,'candidate')}|{times(fresh,'CPython')}|{ratio(fresh)}|{status(fresh)}|
| Process startup |—|—|—|No current comparison|

Compile-to-result includes compilation and compiled-owner disposal, plus warm
execution costs above. Wider process CPU includes fixture reset/protocol.
Startup, shared-budget contention, genuinely pending I/O, RSS/heap peaks and
embedding tail latency remain unmeasured. The
[previous fully qualified checkpoint](../benchmarks/results/2026-11-13-fixed-definitions-cpython-checkpoint/README.md)
retains its own exact revision, boundaries and adverse/variable observations.

'''
tail=prior[prior.index('## Additional qualified ZIP comparison'):]
guide.write_text(intro+tail,encoding='utf-8',newline='\n')
readme=f'''# Current representative CPython checkpoint

2026-11-13UTC, R332/B704. Committedd90dd5fe, frozen798edc1d; all578production
inputs match the R331 snapshot. Fixed B685workeracda3ef3 and optional nonpackable
adapter0.4, stock CPython3.13.16, quiet AzureF4as_v7/Ubuntu24.04.4/.NET11RC3,
four EPYC9V45vCPUs/16GiB/no swap, ordinary GC/tiering and CPython GIL/GC.
{qualification}

{table}
Invoice compilation {times(invoice,'candidate')} versus{times(invoice,'CPython')},
{ratio(invoice)}; compile-to-result {times(fresh,'candidate')} versus
{times(fresh,'CPython')},{ratio(fresh)}. All seven jobs complete in
{s['elapsedSeconds']:.3f}s under one360s owner, with two independent processes per
engine, five rotating rounds and unchanged command-v2 clocks.

Warm includes mediated RAM-file I/O, full stdout/files validation and prior-result
cleanup; excludes compilation, startup, fixture reset/protocol and final cache
disposal. Compile-to-result adds compilation/compiled-owner disposal. Compile-only
includes compilation/owner disposal. Wider CPU includes reset/protocol. Warmups
use full-request wall budgets (5s,12s for captured text/report); batch sizing
targets0.5s full-request wall time. Original warm responses remain available for
guest-time totals. Ranges pair process medians, not confidence intervals.

This is a current external diagnostic, not a source-pair CPU/allocation experiment.
No causal speedup is inferred against B683 or earlier sources. Keep moving controls,
all original adverse observations and earlier qualification labels. Identity,
golden-output, allowance/close, quiet, joined-user and archive checks pass. Guest
fixtures are removed/unmounted after all users end; observations remain persistent
and the resulting archive is independently SHA-verified. No working artifacts are
retired, no storage floor changed, no VM users remain. No embedding-tail, pending-I/O,
startup or live-heap claim follows. Publication remains postponed.

The original B703setup fails its case-presence assertion before guest work: a
two-case catalog was mistakenly supplied. Its journal/setup are preserved and
empty fixture mount joined/unmounted. Corrected B704 initially refuses staging
at the unchanged disk floor, both for the complete historical catalog and for
only its five measured cases. Cases retain exact source/fixture/golden fields;
omitting unused cases changes no measured workload. Under an idle lease,
apt-get clean removes only rebuildable downloaded packages, recovering131,891,200B;
benchmark images/evidence remain intact. Successful staging retains the floor.
Original failed commands, payloads and conditions remain in the tooling archive.

[Summary/wider CPU](summary.json), [raw](observations.tgz),
[exact tooling/catalog](measurement-tools.tar.xz), [first failed setup](first-setup-failed.tgz),
[previous guide](prior-BENCHMARKS.md).
The exact frozen sources/bits and focused checks are reused from
[R331](../2026-11-13-dictionary-boundaries/source-checks.tar.xz); qualification is
tracked [there](../2026-11-13-dictionary-boundaries/README.md), without repeating it.
'''
(out/'README.md').write_text(readme,encoding='utf-8',newline='\n')
p=Path('benchmarks/EXPERIMENTS.md')
with p.open('a',encoding='utf-8',newline='\n')as f:
    f.write(f'''\n## R332 — current representative external checkpoint\n\n[B704](results/2026-11-13-current-cpython-checkpoint/README.md) refreshes five\ncomplete scripts and separate invoice compilation/compile-to-result at committed\nd90dd5fe/frozen798;7jobs/{s['elapsedSeconds']:.3f}s. Existing fixed workers/catalog/\nprotocol; ordinary GC/tiering, two processes per engine, five rotating rounds.\nFull-request wall sizing/warmup and unchanged guest clocks are explicit. All\nidentity/output/allowance/quiet/join/persistent archival gates pass; no working\nevidence retired or floor changed. Current table retains moving controls; earlier\nB683 remains separately labelled. No allocation/source-pair CPU/causal speedup or\nobjective-completion claim. Full delivery43520131516 is independent. Publication held.\n''')
print('Saved current external diagnostics and concise guide; prior guide/source/qualification preserved.',flush=True)
