from pathlib import Path
import os,shutil,subprocess
r=Path(__file__).parent
shutil.copy2('src/Lokad.Lython/Runtime/MemoryGovernor.cs',r/'MemoryGovernor.initial.cs')
env=os.environ.copy();env['DOTNET_ROOT']='C:/Users/JoannesVermorel/.dotnet11';env['DOTNET_HOST_PATH']=env['DOTNET_ROOT']+'/dotnet.exe';env['PATH']=env['DOTNET_ROOT']+os.pathsep+env['PATH']
with(r/'redundant-refund-red.log').open('w',encoding='utf-8')as out:
 done=subprocess.run([env['DOTNET_HOST_PATH'],'test','tests/Lokad.Lython.Tests/Lokad.Lython.Tests.csproj','-c','Release','-f','net11.0','--filter','FullyQualifiedName~ReentrantAdmissionOwnershipTests.FailureBeforeFunding','--logger','console;verbosity=minimal'],env=env,stdout=out,stderr=subprocess.STDOUT)
text=(r/'redundant-refund-red.log').read_text(encoding='utf-8');assert done.returncode==1 and 'Assert.Null() Failure'in text,text[-3000:]
print('Current prototype reproduces redundant-refund callback side effect; source/log preserved.',flush=True)
