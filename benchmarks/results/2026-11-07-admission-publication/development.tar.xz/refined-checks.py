from pathlib import Path
r=Path(__file__).parent
s=(r/'checks.py').read_text(encoding='utf-8')
s=s.replace("assert not(r/'focused.json').exists()","target=r/'refined';target.mkdir();r=target")
exec(compile(s,str(r/'refined-checks-command.py'),'exec'),{'__file__':str(r/'refined-checks-command.py')})
