from pathlib import Path
import hashlib,json,os,shutil,subprocess,time
r=Path(__file__).parent;assert not(r/'focused.json').exists()
env=os.environ.copy();env['DOTNET_ROOT']='C:/Users/JoannesVermorel/.dotnet11';env['DOTNET_HOST_PATH']=env['DOTNET_ROOT']+'/dotnet.exe';env['PATH']=env['DOTNET_ROOT']+os.pathsep+'C:/Python313'+os.pathsep+env['PATH']
checks={}
for tfm in ['net11.0','net10.0']:
 for project,selection in [
  ('Lokad.Lython.Tests','Category!=Stress&(FullyQualifiedName~Admission|FullyQualifiedName~Ownership|FullyQualifiedName~Accounting|FullyQualifiedName~MemoryGovernor|FullyQualifiedName~MemoryBudget|FullyQualifiedName~SharedBudget|FullyQualifiedName~CooperativeExecutionGuard)'),
  ('Lokad.Lython.PublicApi.Tests','Category!=Stress&(FullyQualifiedName~Memory|FullyQualifiedName~Accounting|FullyQualifiedName~Ownership|FullyQualifiedName~SharedBudget|FullyQualifiedName~Refusal|FullyQualifiedName~RegexProviderContract|FullyQualifiedName~IntegerText|FullyQualifiedName~Streaming)')]:
  log=r/(project+'-'+tfm+'.log');start=time.monotonic()
  with log.open('w',encoding='utf-8')as stream:
   done=subprocess.run([env['DOTNET_HOST_PATH'],'test',f'tests/{project}/{project}.csproj','-c','Release','-f',tfm,'--filter',selection,'--logger','console;verbosity=minimal'],env=env,stdout=stream,stderr=subprocess.STDOUT)
  text=log.read_text(encoding='utf-8');checks[log.name]=dict(exitCode=done.returncode,selection=selection,elapsedSeconds=time.monotonic()-start,tail=text[-2500:])
  (r/'focused-progress.json').write_text(json.dumps(checks,indent=2)+'\n',encoding='utf-8')
  print(log.name,text.splitlines()[-1],flush=True)
  assert done.returncode==0,text[-5000:]
cores={}
for tfm in ['net11.0','net10.0']:
 target=r/'cores'/tfm;target.mkdir(parents=True)
 p=Path(f'src/Lokad.Lython/bin/Release/{tfm}/Lokad.Lython.dll');shutil.copy2(p,target/p.name);cores[tfm]=hashlib.sha256(p.read_bytes()).hexdigest()
sources={str(p):hashlib.sha256(p.read_bytes()).hexdigest()for p in Path('src/Lokad.Lython').rglob('*.cs')if not any(part in ['bin','obj']for part in p.parts)}
(r/'focused.json').write_text(json.dumps(dict(checks=checks,cores=cores,productionSources=sources),indent=2)+'\n',encoding='utf-8')
print('Focused both actual targets passed; exact production inventory/cores frozen.',flush=True)
