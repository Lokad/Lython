from pathlib import Path
import hashlib,json,os,shutil,subprocess
r=Path(__file__).parent
assert not(r/'baseline.json').exists()
env=os.environ.copy();env['DOTNET_ROOT']='C:/Users/JoannesVermorel/.dotnet11';env['DOTNET_HOST_PATH']=env['DOTNET_ROOT']+'/dotnet.exe';env['PATH']=env['DOTNET_ROOT']+os.pathsep+env['PATH']
log=r/'baseline-red.log'
with log.open('w',encoding='utf-8')as out:
 done=subprocess.run([env['DOTNET_HOST_PATH'],'test','tests/Lokad.Lython.Tests/Lokad.Lython.Tests.csproj','-c','Release','-f','net11.0','--no-build','--filter','FullyQualifiedName~ReentrantAdmissionOwnershipTests','--logger','console;verbosity=minimal'],env=env,stdout=out,stderr=subprocess.STDOUT)
text=log.read_text(encoding='utf-8');assert done.returncode==1 and 'Failed:     2'in text
shutil.copy2('src/Lokad.Lython/Runtime/MemoryGovernor.cs',r/'MemoryGovernor.before.cs')
shutil.copy2('tests/Lokad.Lython.Tests/ReentrantAdmissionOwnershipTests.cs',r/'Regression.before.cs')
record=dict(head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),hypothesisConfirmed=True,testsFailed=2,observation='A second root reservation can exceed shared physical live string payload+allowance because native after-admission callback allocation/refund shrinks aggregate ownership from stale totals. Both retained nested string and completed temporary scratch demonstrate it.',coreSHA256=hashlib.sha256(Path('src/Lokad.Lython/bin/Release/net11.0/Lokad.Lython.dll').read_bytes()).hexdigest(),sourceSHA256=hashlib.sha256(Path('src/Lokad.Lython/Runtime/MemoryGovernor.cs').read_bytes()).hexdigest())
(r/'baseline.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8');print(json.dumps(record),flush=True)
