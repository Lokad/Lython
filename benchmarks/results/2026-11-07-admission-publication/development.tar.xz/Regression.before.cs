using Lokad.Lython.Runtime;
using Lokad.Lython.Runtime.Text;
using Lokad.Lython.Tests.Harness;

namespace Lokad.Lython.Tests;

public sealed class ReentrantAdmissionOwnershipTests
{
    private static readonly LythonSourceSpan Span = new(120, 5, 12, 3);

    [Theory]
    [InlineData(false), InlineData(true)]
    public void AdmittedCallbackCannotRefundTheOuterPendingAllocation(bool temporary)
    {
        const long limit = 4096;
        var budget = new LythonMemoryBudget(limit);
        using (var owner = budget.CreateScope())
        {
            var hook = new AdmissionHookMemoryBudget(owner);
            var governor = new MemoryGovernor(hook);
            PyString? nested = null;
            var reached = false;
            hook.AfterGrowth = _ =>
            {
                hook.AfterGrowth = null;
                reached = true;
                if (temporary)
                {
                    using var scratch = governor.ReserveTemporary(1024, Span);
                }
                else nested = PyString.FromString(new string('n', 1000), governor, Span);
            };
            var outer = PyString.FromString(new string('o', 2000), governor, Span);
            Assert.True(reached);
            var retainedPayload = outer.Utf8Bytes.Length + (nested?.Utf8Bytes.Length ?? 0);
            var overcommit = budget.TryReserve(limit - retainedPayload + 1, out var unrelated);
            unrelated?.Dispose();
            Assert.False(overcommit, "Shared allowance admitted more than its limit while native strings remain retained.");
            Assert.True(budget.ReservedBytes >= retainedPayload);
            Assert.Equal(new string('o', 2000), outer.AsString());
            if (nested is not null) Assert.Equal(new string('n', 1000), nested.AsString());
            Assert.Equal(0, governor.CurrentReservedBytes);
        }
        Assert.Equal(0, budget.ReservedBytes);
    }
}
