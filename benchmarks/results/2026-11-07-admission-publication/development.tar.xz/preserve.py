from pathlib import Path
import hashlib,json,shutil,tarfile
r=Path(__file__).parent;out=Path('benchmarks/results/2026-11-07-admission-publication');out.mkdir(exist_ok=True)
checks=json.loads((r/'refined/focused.json').read_text(encoding='utf-8'))
for p,digest in checks['productionSources'].items():assert hashlib.sha256(Path(p).read_bytes()).hexdigest()==digest
for name in ['baseline.json','local-summary.json','comparison-identity.json']:shutil.copy2(r/name,out/name)
shutil.copy2(r/'focused.json',out/'initial-focused.json');shutil.copy2(r/'refined/focused.json',out/'focused.json')
source=r/'source-current';source.mkdir()
for p in ['src/Lokad.Lython/Runtime/MemoryGovernor.cs','src/Lokad.Lython/Public/ILythonMemoryBudget.cs','tests/Lokad.Lython.Tests/ReentrantAdmissionOwnershipTests.cs']:shutil.copy2(p,source/Path(p).name)
archive=out/'development.tar.xz'
with tarfile.open(archive,'w:xz')as a:
 for p in sorted(r.rglob('*')):
  relative=p.relative_to(r)
  if p.is_file()and relative.parts[0]not in ['images']:a.add(p,arcname=str(relative).replace('\\','/'))
decision=dict(retained=True,purpose='Correct aggregate ownership publication under host callback reentry, not a performance redesign.',confirmedBaseline='Two native regressions overcommit shared allowance with retained strings: after-growth allocation and completed scratch refund erase the pending outer charge. Exact original source/core/log preserved.',replacement='Publish pending counters before external resize; unify resize publication; roll back own pending bytes and preserve first refusal; skip unchanged rollback/no-op refunds. Permit same-governor allocation after a resize is visible, reject earlier reentry; independent governors can share root.',cleanup='Removed blind post-callback ownership publication and redundant callback during unchanged refund. No collector, identity ledger, new owner/pool, retries, fuel/quota or new capacity policy.',validation='Initial1400internal/1652public per actual11/10 pass. Final1401internal/1652public per actual11/10 pass, including10 focused native callback/funding cases. New rollback side-effect regression red on first prototype; exact source/log kept.',compatibility='Admission callbacks now see pending estimates. Same-execution allocation before changed host estimate is published fails terminally; this does not block independent executions. Exceptions release only unallocated pending storage, preserving retained callback aliases and cleanup. No public signature change.',performance='Complete search/text/CSV/JSON/report outputs, funding baselines/isolation/cleanup all pass in one short existing warm sync/async diagnostic. Allocation essentially flat (within0.08%); desktop clocks mixed, including sync CSV+3.31to+3.60% and search+6.69to+12.64% with5.58% unchanged-baseline drift. No CPU improvement, ordinary thresholds or quiet-runtime elapsed guarantee. Adverse observations retained.',fullDelivery='Pending coherent Windows/Ubuntu Release actual11/10, original Stress and installed consumer qualification.',archiveSHA256=hashlib.sha256(archive.read_bytes()).hexdigest(),publication='postponed')
(out/'decision.json').write_text(json.dumps(decision,indent=2)+'\n',encoding='utf-8')
print(json.dumps(dict(archiveBytes=archive.stat().st_size,archiveSHA256=decision['archiveSHA256'])),flush=True)
