from pathlib import Path
import hashlib,json,os,shutil
r=Path(__file__).parent;home=r.parent
checks=json.loads((r/'refined/focused.json').read_text(encoding='utf-8'))
for p,digest in checks['productionSources'].items():assert hashlib.sha256(Path(p).read_bytes()).hexdigest()==digest
for role in ['before','candidate']:
 target=r/'images'/role;shutil.copytree(home/'wildcard-utf8-r51/before-image',target,copy_function=os.link)
 (target/'Lokad.Lython.dll').unlink()
 source=home/'wildcard-utf8-r51/candidate-image/Lokad.Lython.dll'if role=='before'else r/'refined/cores/net11.0/Lokad.Lython.dll'
 shutil.copy2(source,target/'Lokad.Lython.dll')
shutil.copy2(home/'module-bindings-r49/catalog.json',r/'catalog.json')
s=(home/'integer-width-r50/measure.py').read_text(encoding='utf-8');(r/'measure.py').write_text(s,encoding='utf-8',newline='\n')
s=(home/'integer-width-r50/summarize.py').read_text(encoding='utf-8');(r/'summarize.py').write_text(s,encoding='utf-8',newline='\n')
identity=dict(baseline='55e510ff fully qualified production/core83af401e, information revision4c739dcb',candidate='d7df3147 plus final R53 pending-admission correction; exact sources/cores in refined/focused.json',coreSHA256={role:hashlib.sha256((r/'images'/role/'Lokad.Lython.dll').read_bytes()).hexdigest()for role in ['before','candidate']},driverSHA256=hashlib.sha256((home/'integer-utf8-r45/tool/out/complete-jobs.dll').read_bytes()).hexdigest(),protocol='Existing unchanged five-case driver, normal GC/tiering, shared ALCs/CoreLib/hash seed/process GC.32warmups/image,5rotated rounds*4complete jobs. Warm sync/async only; no frontend or CPU gain claim. Native driver purpose caption remains historical; these images/catalog govern the R53 comparison.',controls='Protected search/text/CSV/JSON/report unchanged original sources/fixtures/goldens; complete public execution/reset/mediated I/O/full validation/result cleanup. Compilation/startup/final cached teardown excluded.',fullDeliveryPending=True)
(r/'comparison-identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8',newline='\n')
print('Final R53 correction frozen for one short existing five-script before/after diagnostic; no timing yet.')
