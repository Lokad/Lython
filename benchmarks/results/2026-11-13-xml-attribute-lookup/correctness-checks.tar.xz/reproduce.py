from pathlib import Path
import subprocess
r=Path(__file__).parent
command=['C:/Users/JoannesVermorel/.dotnet11/dotnet.exe','test','tests/Lokad.Lython.PublicApi.Tests/Lokad.Lython.PublicApi.Tests.csproj','-c','Release','-f','net11.0','--no-restore','--filter','FullyQualifiedName~XmlAttributeLookupTests.AttributeKeyProtocolsAwaitRealHostReads','--logger','console;verbosity=normal']
done=subprocess.run(command,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=180)
(r/'before.log').write_bytes(done.stdout)
print(done.stdout.decode('utf-8',errors='replace')[-6000:],flush=True)
print('Original-source exit',done.returncode,flush=True)
assert done.returncode!=0,'The proposed regression did not fail; reassess before editing production.'
