from pathlib import Path
import json,re,shutil,subprocess,tempfile,textwrap,time
r=Path(__file__).parent
shutil.copyfile(r/'cpython-controls.json',r/'first-cpython-controls.json')
text=Path('tests/Lokad.Lython.PublicApi.Tests/XmlAttributeLookupTests.cs').read_text(encoding='utf-8')
source=textwrap.dedent(re.search(r'private const string ReadingKey = """\n(.*?)\n\s*""";',text,re.S)[1])
assert 'root.clear()'in source
with tempfile.TemporaryDirectory(prefix='lython-xml-key-control-')as folder:
    work=Path(folder)
    for name in ['hash.txt','equal.txt']:(work/name).write_text('name',encoding='utf-8')
    done=subprocess.run(['C:/Python313/python.exe','-I','-S','-X','utf8','-c',source],cwd=folder,text=True,encoding='utf-8',capture_output=True,timeout=30)
    assert done.returncode==0 and done.stdout=='kept\n' and (work/'out.txt').read_text(encoding='utf-8')=='kept',(done.stdout,done.stderr)
d=json.loads((r/'cpython-controls.json').read_text(encoding='utf-8'));d['cases'][-1]['source']=source
(r/'cpython-controls.json').write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print('CPython retains the bound map across root.clear and actual source reads.',flush=True)
for framework in ['net11.0','net10.0']:
    command=['C:/Users/JoannesVermorel/.dotnet11/dotnet.exe','test','tests/Lokad.Lython.PublicApi.Tests/Lokad.Lython.PublicApi.Tests.csproj','-c','Release','-f',framework,'--no-restore','--filter','FullyQualifiedName~XmlAttributeLookupTests','--logger','console;verbosity=minimal']
    with(r/('retained-map-'+framework+'.log')).open('wb')as log:done=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,timeout=180)
    print(framework,done.returncode,(r/('retained-map-'+framework+'.log')).read_text(encoding='utf-8')[-1200:],flush=True)
    assert done.returncode==0
