import xml.etree.ElementTree as E
r=E.fromstring('<r a="kept"/>')
events=[]
class Key:
    def __hash__(self):
        events.append('hash')
        return hash('a')
    def __eq__(self,other):
        events.append('eq')
        return other=='a'
print(r.get(Key(),'miss'),events)
print(r.attrib)
events.clear()
print(r.get(Key(),'miss'),events)
old=r.attrib
class ClearingKey(Key):
    def __hash__(self):
        r.clear()
        return hash('a')
print(r.get(ClearingKey(),'miss'),r.attrib,old)
