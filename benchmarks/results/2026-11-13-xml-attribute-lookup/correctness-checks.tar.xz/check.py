from pathlib import Path
import json,re,subprocess,tempfile,textwrap,time
r=Path(__file__).parent
test=Path('tests/Lokad.Lython.PublicApi.Tests/XmlAttributeLookupTests.cs').read_text(encoding='utf-8')
controls=[]
for name,source,expected in re.findall(r'yield return \["([^"]+)", """\n(.*?)\n\s*""", ("(?:\\.|[^"])*")\];',test,re.S):
    source=textwrap.dedent(source);expected=json.loads(expected)
    done=subprocess.run(['C:/Python313/python.exe','-I','-S','-X','utf8','-c',source],text=True,encoding='utf-8',capture_output=True,timeout=30)
    assert done.returncode==0 and done.stdout==expected,(name,done.stdout,done.stderr,expected)
    controls.append(dict(name=name,source=source,output=done.stdout,exitCode=done.returncode))
assert len(controls)==2
source=textwrap.dedent(re.search(r'private const string ReadingKey = """\n(.*?)\n\s*""";',test,re.S)[1])
with tempfile.TemporaryDirectory(prefix='lython-xml-key-control-')as folder:
    work=Path(folder)
    for name in ['hash.txt','equal.txt']:(work/name).write_text('name',encoding='utf-8')
    done=subprocess.run(['C:/Python313/python.exe','-I','-S','-X','utf8','-c',source],cwd=folder,text=True,encoding='utf-8',capture_output=True,timeout=30)
    assert done.returncode==0 and done.stdout=='kept\n' and (work/'out.txt').read_text(encoding='utf-8')=='kept',(done.stdout,done.stderr)
    controls.append(dict(name='host-read-key-protocols',source=source,output=done.stdout,outputFile='kept',exitCode=done.returncode))
(r/'cpython-controls.json').write_text(json.dumps(dict(reference='CPython3.13.2',cases=controls),ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print('Three isolated CPython controls match public expected values/files.',flush=True)
for framework in ['net11.0','net10.0']:
    for assembly in ['Lokad.Lython.PublicApi.Tests','Lokad.Lython.Tests']:
        category='public'if 'PublicApi'in assembly else'internal'
        command=['C:/Users/JoannesVermorel/.dotnet11/dotnet.exe','test','tests/'+assembly+'/'+assembly+'.csproj','-c','Release','-f',framework,'--no-restore','--filter','FullyQualifiedName~Xml|FullyQualifiedName~ElementTree','--logger','console;verbosity=minimal']
        started=time.monotonic()
        with(r/(category+'-'+framework+'.log')).open('wb')as log:
            done=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,timeout=240)
        data=(r/(category+'-'+framework+'.log')).read_text(encoding='utf-8')
        print(category,framework,'exit',done.returncode,'seconds',round(time.monotonic()-started,3),data[-1800:],flush=True)
        assert done.returncode==0
