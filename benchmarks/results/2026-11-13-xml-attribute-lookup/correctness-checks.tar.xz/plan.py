from pathlib import Path
r=Path(__file__).parent
p=Path('PLAN.md');s=p.read_text(encoding='utf-8')
s=s.replace('Updated 2026-11-13.','Updated 2026-11-14.')
at=s.index('1. **Continue substantial')
s=s[:at]+'''1. **R333 active: XML attribute protocols use ordinary dictionary lookup.**
   Element.get currently supplies only a synchronous, context-free implementation.
   Reproduce delayed __hash__/__eq__ I/O under RunAsync, then replace this duplicate
   route with DictMembers.Get/GetAsync. Preserve bound receiver/map identity,
   default aliases, Python errors, terminal refusal, joined cancellation and
   shared-budget cleanup. No new dispatch or ownership layer. Acceptance: CPython
   goldens, both APIs, actual delayed hash/equality, cancellation while pending,
   refusal through suppression and retained map aliases. Native string keys remain
   on the existing dictionary path; correctness work carries no speedup claim.
   Batch full delivery with the next coherent runtime milestone; reuse completed
   R331 qualification for its unchanged source only.

2. **Continue substantial'''+s[at+len('1. **Continue substantial'):]
s=s.replace('2. **Regex remains independent.**','3. **Regex remains independent.**').replace('3. **R320 later:','4. **R320 later:')
s=s.replace('   cached patterns retain no prior token. No unchanged producer requalification.','''   cached patterns retain no prior token. No unchanged producer requalification.
   Read-only dev83/a6303c45 API check: the three gaps still exist; cursor overloads
   still retain a construction token and group enumeration returns CLR strings.
   No sibling mutation, pin promotion or repeated dev80 qualification is selected.''')
p.write_text(s,encoding='utf-8',newline='\n')
print('R333 bounded correctness milestone recorded before implementation.',flush=True)
