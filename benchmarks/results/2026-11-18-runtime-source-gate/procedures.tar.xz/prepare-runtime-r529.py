from pathlib import Path
import ast, hashlib, io, json, os, subprocess, tarfile

repo=Path('D:/code/Lython'); notes=Path(__file__).parent
r=notes/'runtime-deletion-r529'; r.mkdir(exist_ok=True)
prior=notes/'call-entry-r514-corrected'; frontend=notes/'frontend-dispatch-r527'
old='/home/lokad/lython-bench-checks/call-entry-b941-20261118'
remote='/home/lokad/lython-bench-checks/runtime-deletion-b958-20261118'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
names=[('floating','scripts.numeric-squared-error.floating.large','warm'),('text-helper','scripts.text-normalization.helper-list','warm')]
catalog=json.loads((frontend/'quiet/representative.json').read_text(encoding='utf-8'))
catalog['cases']=[next(c for c in catalog['cases']if c['id']==n)for _,n,_ in names]
(r/'catalog.json').write_text(json.dumps(catalog,indent=2)+'\n',encoding='utf-8')
files=json.loads((frontend/'frozen/identity.json').read_text(encoding='utf-8'))['imageFiles']['candidate']
image=frontend/'frozen/candidate'
assert len(files)==32 and all(sha(image/n)==h for n,h in files.items())
assert files['Lokad.Lython.dll']=='2c6b304be4c81e2c70d4b0e0e89b71fb26e33521a561405255b939c2716d8226'
dotnet=Path('C:/Users/JoannesVermorel/.dotnet11/dotnet.exe'); env=os.environ.copy()
env.update(DOTNET_ROOT=str(dotnet.parent),DOTNET_ROOT_X64=str(dotnet.parent));env['PATH']=str(dotnet.parent)+os.pathsep+env['PATH']
with(r/'actual-worker-preflight.log').open('w',encoding='utf-8')as log:
 p=subprocess.run([str(dotnet),str(image/'Lokad.Lython.Benchmarks.dll'),'--compare','verify','--catalog',str(r/'catalog.json'),'--dotnet',str(dotnet),'--python','C:/Python313/python.exe','--python-worker',str(repo/'benchmarks/cpython-worker.py'),'--out',str(r/'actual-worker-preflight.json')],env=env,stdout=log,stderr=subprocess.STDOUT)
assert p.returncode==0,(r/'actual-worker-preflight.log').read_text(encoding='utf-8')
identity=dict(sourceRevision='Committed925397f65/frozen2c6b304b; fully qualified GREEN44280333217, terminal cached.',purpose='Current complete floating JSON report and helper text ALL-thread CPU attribution; seek a concrete removable lifecycle/conversion/storage stage. No elapsed comparison or removable inclusive fraction.',imageFiles={'candidate':files},coreSHA256={'candidate':files['Lokad.Lython.dll']},catalogSHA256=sha(r/'catalog.json'),normalAdapterPin='0.4.0',publicationHeld=True)
(r/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8')
for name in ['ops-profile.py','collect.py','run.sh','launch.py','retrieve.py','analyze.py']:
 s=(prior/name).read_text(encoding='utf-8').replace(old,remote).replace('b941','b958')
 s=s.replace("[('text-original', 'scripts.text-normalization.large', 'warm'), ('text-helper', 'scripts.text-normalization.helper-list', 'warm')]",repr(names))
 s=s.replace("['text-original','text-helper']","['floating','text-helper']")
 s=s.replace('R514/B941 committed10ee56c7/frozen2ede09fc; original/helper text attribution','R529/B958 committed925397f65/frozen2c6b304b; floating/helper text attribution')
 s=s.replace('Current original/helper text','Current floating/helper text').replace('Current original/helper CPU','Current floating/helper CPU')
 (r/name).write_text(s,encoding='utf-8',newline='\n')
assert b'\r'not in(r/'run.sh').read_bytes()
retire=[]
for canonical,member,path in [
 ('benchmarks/results/2026-11-18-frontend-dispatch/observations.tgz','confirmation/confirmation.json','frontend-dispatch-b957-20261118/confirmation/confirmation.json'),
 ('benchmarks/results/2026-11-18-frontend-dispatch/observations.tgz','whole-file','frontend-dispatch-b957-20261118/observations.tgz'),
 ('benchmarks/results/2026-11-18-operand-source-gate/observations.tgz','whole-file','operand-gate-b948-20261118/observations.tgz')]:
 blob=subprocess.check_output(['git','show','HEAD:'+canonical],cwd=repo);assert blob==(repo/canonical).read_bytes()
 if member=='whole-file':data=blob
 else:
  with tarfile.open(fileobj=io.BytesIO(blob))as a:data=a.extractfile(member).read()
 retire.append(dict(kind='archived-working-replica',sha256=hashlib.sha256(data).hexdigest(),bytes=len(data),canonical=canonical,canonicalSHA256=hashlib.sha256(blob).hexdigest(),member=member,committedBlobVerified=True,paths=[path],links=1,optional=True))
stage=['ops-profile.py','collect.py','run.sh','identity.json','catalog.json']
with tarfile.open(r/'payload.tgz','w:gz')as a:
 for n in stage:a.add(r/n,arcname=n)
sourceConfig=json.loads((frontend/'quiet/config.json').read_text(encoding='utf-8'))
c=dict(root=remote,unit='lython-b958-runtime-deletion-20261118',source='/home/lokad/lython-bench-checks/frontend-dispatch-b957-20261118',sourceFiles=files,sourceCatalogSHA256=sourceConfig['catalogSHA256'],catalogSHA256=sha(r/'catalog.json'),identity=identity,retireGroups=retire,payloadBytes=(r/'payload.tgz').stat().st_size,payloadSHA256=sha(r/'payload.tgz'),unpackedBytes=sum((r/n).stat().st_size for n in stage))
(r/'config.json').write_text(json.dumps(c,indent=2)+'\n',encoding='utf-8')
s=(prior/'remote-launch.py').read_text(encoding='utf-8');a=s.index('c=');b=s.index('\nb=Path(',a);s=s[:a]+'c='+repr(c)+s[b:]
a=s.index(' catalogSource=');b=s.index(" for n in ['collect.py'",a)
s=s[:a]+" assert sha(root/'catalog.json')==c['catalogSHA256']\n"+s[b:]
s=s.replace('lython-b941-fixtures','lython-b958-fixtures')
s=s.replace("subprocess.run(['/bin/sh','-n',str(root/'run.sh')],check=True)","assert b'\\r'not in(root/'run.sh').read_bytes()\n subprocess.run(['/bin/sh','-n',str(root/'run.sh')],check=True)")
(r/'remote-launch.py').write_text(s,encoding='utf-8',newline='\n')
for p in r.glob('*.py'):ast.parse(p.read_text(encoding='utf-8'))
print('Actual current32-file image/two-case goldens pass. Stage',c['unpackedBytes'],'bytes; eligible exact committed optional replicas',[(v['paths'],v['bytes'])for v in retire])
