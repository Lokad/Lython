from pathlib import Path
import hashlib,json,shutil,tarfile
r=Path(__file__).parent/'b710';out=Path('benchmarks/results/2026-11-14-native-cpython-checkpoint');out.mkdir()
d=json.loads((r/'summary.json').read_text(encoding='utf-8'));receipt=json.loads((r/'archive-receipt.json').read_text(encoding='utf-8'))
assert d['complete']and len(d['timing'])==8 and receipt['allWorkersJoined']and receipt['guestFixturesRemoved']
assert hashlib.sha256((r/'observations.tgz').read_bytes()).hexdigest()==receipt['archiveSHA256']
for name in ['summary.json','archive-receipt.json','terminal-status.json','observations.tgz','identity.json']:shutil.copyfile(r/name,out/name)
shutil.copyfile('docs/BENCHMARKS.md',out/'prior-BENCHMARKS.md')
with tarfile.open(out/'collection-tools.tar.xz','w:xz')as t:
 for name in ['config.json','collect.py','archive-owned.py','run.sh','retrieve.py','summarize.py','launch.py','launch-command.py','launch.log','observe-not-before.json','extraction.json']:t.add(r/name,arcname=name)
 for name in ['prepare-external.py','save-external.py']:t.add(r.parent/name,arcname=name)
 t.add(r.parent/'candidate-identity.json',arcname='source-identity.json')
table='| Complete script / phase | Lython | CPython | Lython / CPython | Lython/CPython process spread | Max IQR |\n| --- | ---: | ---: | ---: | ---: | ---: |\n'
for row in d['timing']:
 med=row['medianMilliseconds'];a=[med[k]for k in ['candidate','candidate-control']];b=[med[k]for k in ['CPython','CPython-control']];ratio=row['ratioRange']
 table+=f"|{row['case'].removeprefix('scripts.')} /{row['lane']}|{min(a):.6f}–{max(a):.6f}ms|{min(b):.6f}–{max(b):.6f}ms|{min(ratio):.2f}–{max(ratio):.2f}×|{row['lythonControlPercent']:.2f}/{row['cpythonControlPercent']:.2f}%|{row['maxIqrPercent']:.2f}%|\n"
(out/'README.md').write_text(f'''# Native-eligibility CPython checkpoint

2026-11-14UTC, exact committed1778c30d / frozen38c0562f,581production inputs,
stockCPython3.13.16, quiet AzureF4as_v7/Ubuntu24.04.4/.NET11RC3. The combined
R338/R339 full platform/stress/installed-consumer[delivery43545993574](https://github.com/Lokad/Lython/actions/runs/43545993574)
is pending at collection; focused637internal/1562public per actual11/10 pass.
The separate R341prototype is not part of these sources or observations.
Publication/tagging remain postponed.

{table}
Ratio is Lython elapsed divided by CPython elapsed; above one means slower.
These are diagnostic complete embedding jobs, not isolated interpreter CPU.
Invoice fresh has5.96%Lython process spread; captured text6.58%. Keep their
wider ranges/inconclusive stability visible; low within-process IQR does not
remove this disagreement. Report has2.79%CPython spread/maxIQR4.23%. No automatic
design veto, control neutrality or attribution from older collections is inferred.

The previous five representative sources/fixtures/goldens are unchanged. Add the
4096-row/nine-field fulfillment/pricing/aggregation/report job used in R339; local
isolatedCPython3.13.2 supplies independent file/stdout goldens, and every VM engine
verifies them before timing. The fixed B685.NET worker, Python protocol worker and
optional0.4adapter retain identical bytes. No core producer dependency or pin change.

Two fresh processes per engine/job, five rotating0.5s batches sized by full-request
wall time; five-second full-request warmups, twelve seconds for captured text/report.
Ordinary GC/tiering, stock Python GIL/GC; no performance overrides. Warm guest clocks
include mediated RAM-file I/O, complete stdout/file validation and prior-result
cleanup, excluding compilation/startup, reset/protocol and final cache teardown.
Compilation measures frontend/compiled owner disposal separately. Compile-to-result
adds compilation/disposal to execution. Wider CPU includes reset/protocol. These
independently warmed phase medians cannot be added/subtracted as attribution.
No startup, RSS, shared-budget contention, genuine pending I/O or embedding-tail claim.

B710eight jobs finish{d['elapsedSeconds']:.3f}s within one420s owner. All exact image/
source/golden/allowance/quiet/join/archive gates pass; no workers or RAM fixtures
remain. Persistent rawSHA{receipt['archiveSHA256']}. All adverse observations,
warmup responses and controls survive. No floor relaxation, evidence retirement,
framework expansion or repeated unchanged qualification. The first source remains
independently[archived](../2026-11-14-native-owned-slots/source-checks.tar.xz).

[Raw and wider CPU](observations.tgz), [summary/identities](summary.json),
[collection tools](collection-tools.tar.xz), [previous guide](prior-BENCHMARKS.md).
This checkpoint informs subsequent removals; it does not complete the performance objective.
''',encoding='utf-8',newline='\n')
p=Path('docs/BENCHMARKS.md');s=p.read_text(encoding='utf-8')
rows={row['case']+'|'+row['lane']:row for row in d['timing']}
def row(case,lane,label,input_size='',micro=False):
 data=rows[case+'|'+lane];med=data['medianMilliseconds'];factor=1000 if micro else 1;unit='µs'if micro else'ms';a=[factor*med[k]for k in ['candidate','candidate-control']];b=[factor*med[k]for k in ['CPython','CPython-control']];ratio=data['ratioRange'];status='Variable'if max(data['lythonControlPercent'],data['cpythonControlPercent'])>3 else'Diagnostic'
 cells=[label]+([input_size]if input_size else[])+[f'{min(a):.1f}–{max(a):.1f} {unit}'if micro else f'{min(a):.3f}–{max(a):.3f} {unit}',f'{min(b):.1f}–{max(b):.1f} {unit}'if micro else f'{min(b):.3f}–{max(b):.3f} {unit}',f'{min(ratio):.2f}–{max(ratio):.2f}×',f"{status}; spreads{data['lythonControlPercent']:.2f}/{data['cpythonControlPercent']:.2f}%; maxIQR{data['maxIqrPercent']:.2f}%"]
 return'| '+'|'.join(cells)+'|'
lines=s.splitlines()
mapping={'CSV invoice / pricing helpers':('scripts.csv-invoice.large','4,096 records /127,031 B',False),'Text / captured helper and counter':('scripts.text-summary-helpers.nonlocal-counter.large','3,072 lines /35,840 B',False),'JSON-lines / aggregation helpers':('scripts.json-summary-helpers.large','4,096 records /110,592 B',False),'File search / keyword-default helper':('scripts.file-search.large','2,049 lines /42,010 B; stop after1,025',True),'JSON-to-Markdown report':('scripts.report-render.large','3,072 records /189,441 B',False)}
for i,line in enumerate(lines):
 for label,(case,size,micro)in mapping.items():
  if line.startswith('| '+label+' |'):lines[i]=row(case,'warm',label,size,micro)
 if line.startswith('| Invoice compilation alone |'):lines[i]=row('scripts.csv-invoice.large','compile','Invoice compilation alone',micro=True)
 if line.startswith('| Invoice compile and execute once |'):lines[i]=row('scripts.csv-invoice.large','compile-run','Invoice compile and execute once')
s='\n'.join(lines)+'\n'
size=json.loads((r.parent/'workload-python-controls.json').read_text(encoding='utf-8'))['inputBytes']
anchor=next(l for l in s.splitlines()if l.startswith('| Configuration JSON edit |'))
s=s.replace(anchor,row('scripts.csv-fulfillment.large','warm','CSV fulfillment / pricing and validation',f'4,096 records /{size:,} B')+'\n'+anchor)
start=s.index('First five rows measured');end=s.index('The96 B configuration row',start)
s=s[:start]+'''First five rows and fulfillment measured2026-11-14UTC: **1778c30d / frozen38c0562f**,
against stock**CPython3.13.16**. Focused Release checks pass; combined full
Windows/Ubuntu .NET11/10, original stress and installed consumers are
[running](https://github.com/Lokad/Lython/actions/runs/43545993574).
[Exact sources, raw/wider CPU and controls](../benchmarks/results/2026-11-14-native-cpython-checkpoint/README.md).
Invoice compile-to-result and captured text have5.96%and6.58%Lython process spread;
their stability remains inconclusive despite small within-process IQRs.
'''+s[end:]
s=s.replace('[Exact sources, raw/wider CPU and controls](../benchmarks/results/2026-11-13-current-cpython-checkpoint/README.md).','[Previous checkpoint and all adverse observations](../benchmarks/results/2026-11-13-current-cpython-checkpoint/README.md).')
p.write_text(s,encoding='utf-8',newline='\n')
with Path('benchmarks/EXPERIMENTS.md').open('a',encoding='utf-8',newline='\n')as f:f.write('''
## R340 — coherent native-eligibility CPython checkpoint

[Eight-job B710](results/2026-11-14-native-cpython-checkpoint/README.md) refreshes
five warm representative scripts, invoice compile/compile-run and fulfillment at
exact committed1778c30d/frozen38c0562f vs stockCPython3.13.16.327.287s/all gates.
Invoice warm1.21–1.24×/compile1.09–1.10×/fresh1.20–1.28×; captured text1.51–1.63×,
JSON0.82–0.83×, search1.64–1.69×, report1.17–1.21×, fulfillment1.29–1.32×.
Invoice fresh5.96%and captured6.58%Lython process spreads remain inconclusive
stability, preserved alongside raw/wider CPU and previous results. No new source-
pair attribution, startup/tail claim or broad qualification campaign. Combined
full43545993574pending; separate R341prototype is excluded. Publication held.
''')
p=Path('PLAN.md');s=p.read_text(encoding='utf-8');(r/'PLAN-before-result.md').write_text(s,encoding='utf-8',newline='\n')
s=s.replace('2. **R340: refresh representative external evidence at this coherent checkpoint.**','2. **R340 complete: representative external evidence at this coherent checkpoint.**')
s=s.replace('   This refresh is evidence for choosing the next design, not a new framework.','''   This refresh is evidence for choosing the next design, not a new framework.
   B710eight jobs/327.287s/all gates: invoice warm1.21–1.24×/compile1.09–1.10×/
   fresh1.20–1.28×; captured1.51–1.63×, JSON0.82–0.83×, search1.64–1.69×,
   report1.17–1.21×, fulfillment1.29–1.32×. Fresh invoice5.96%and captured6.58%
   Lython process spreads remain inconclusive. No unchanged retiming is selected.
   [Exact current evidence](benchmarks/results/2026-11-14-native-cpython-checkpoint/README.md).''')
p.write_text(s,encoding='utf-8',newline='\n')
print('Archived eight-job CPython refresh; exact committed source and variable controls explicit; R341 excluded.',flush=True)
