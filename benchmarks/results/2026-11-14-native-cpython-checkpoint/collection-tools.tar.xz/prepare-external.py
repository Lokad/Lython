from pathlib import Path
import ast,hashlib,json,tarfile
r=Path(__file__).parent;out=r/'b710';out.mkdir()
prior=r.parent/'checkpoint-cpython-r332/b704'
catalog=json.loads((prior/'catalog.json').read_text(encoding='utf-8'))
fulfillment=next(c for c in json.loads((r/'catalog.json').read_text(encoding='utf-8'))['cases']if c['id']=='scripts.csv-fulfillment.large')
assert all(c['id']!=fulfillment['id']for c in catalog['cases']);catalog['cases'].append(fulfillment)
(out/'catalog.json').write_text(json.dumps(catalog,separators=(',',':'),ensure_ascii=False)+'\n',encoding='utf-8',newline='\n')
jobs=[['scripts.csv-invoice.large','warm'],['scripts.csv-invoice.large','compile'],['scripts.csv-invoice.large','compile-run'],['scripts.text-summary-helpers.nonlocal-counter.large','warm'],['scripts.json-summary-helpers.large','warm'],['scripts.file-search.large','warm'],['scripts.report-render.large','warm'],['scripts.csv-fulfillment.large','warm']]
index={c['id']:c for c in catalog['cases']};assert len(jobs)==8 and all(k in index for k,l in jobs)
source=json.loads((r/'candidate-identity.json').read_text(encoding='utf-8'))
aux=json.loads((r/'b709/identity.json').read_text(encoding='utf-8'))['candidateAuxiliaryFiles']
identity=dict(sourceRevision='1778c30d/frozen38c0562f; combined full CI43545993574 pending',purpose='Representative CPython checkpoint after coherent R338/R339 native eligibility delivery; identical complete scripts, explicit phase boundaries and unchanged workers.',coreSHA256={k:source['coreSHA256']['candidate']for k in ['reference','reference-control','candidate','candidate-control']},auxiliaryFiles=aux,catalogSHA256=hashlib.sha256((out/'catalog.json').read_bytes()).hexdigest(),sourceIdentitySHA256=hashlib.sha256((r/'candidate-identity.json').read_bytes()).hexdigest(),publicationHeld=True)
(out/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8',newline='\n')
old='/home/lokad/lython-bench-checks/current-external-b704-20261113';root='/home/lokad/lython-bench-checks/native-checkpoint-b710-20261114';unit='lython-b710-native-checkpoint-20261114'
for name in ['collect.py','archive-owned.py','run.sh','retrieve.py','summarize.py','launch.py']:
 s=(prior/name).read_text(encoding='utf-8').replace(old,root).replace('lython-b704-current-external-20261113',unit).replace('B704','B710')
 if name=='collect.py':
  a=s.index('jobs=');b=s.index('\nenv =',a);s=s[:a]+'jobs='+repr(jobs)+'\nassert len(jobs)==8 and all(case in cases for case,lane in jobs)\n'+s[b:]
  s=s.replace("< 300, 'Reserve60seconds", "< 360, 'Reserve60seconds")
 if name=='archive-owned.py':s=s.replace("==7", "==8").replace('jobs=7','jobs=8')
 if name=='retrieve.py':s=s.replace("['jobs']==7", "['jobs']==8").replace("['elapsedSeconds']<360", "['elapsedSeconds']<420")
 if name=='summarize.py':s=s.replace("==7", "==8").replace('jobs=7','jobs=8')
 if name=='launch.py':
  s=s.replace("r.parent.parent/'dictionary-boundaries-r331/candidate-identity.json'", "r.parent/'candidate-identity.json'")
  s=s.replace('RuntimeMaxSec=360','RuntimeMaxSec=420').replace('seconds=300','seconds=360').replace('ownerSeconds=360','ownerSeconds=420')
 if name.endswith('.py'):ast.parse(s)
 (out/name).write_text(s,encoding='utf-8',newline='\n')
with tarfile.open(out/'payload.tgz','w:gz')as t:
 for name in ['identity.json','collect.py','archive-owned.py','run.sh']:t.add(out/name,arcname=name)
 t.add(out/'catalog.json',arcname='representative.json')
with tarfile.open(out/'payload.tgz')as t:unpacked=sum(m.size for m in t.getmembers())
config=dict(root=root,sourceRoot='/home/lokad/lython-bench-checks/native-owned-slots-b709-20261114',unit=unit,identity=identity,payloadBytes=(out/'payload.tgz').stat().st_size,payloadSHA256=hashlib.sha256((out/'payload.tgz').read_bytes()).hexdigest(),unpackedBytes=unpacked)
(out/'config.json').write_text(json.dumps(config,indent=2)+'\n',encoding='utf-8',newline='\n')
print('Prepared eight-job420s external checkpoint; shared frozen worker/current core, no duplicated image or producer change.',flush=True)
