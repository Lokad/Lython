set -eu
root=/home/lokad/lython-bench-checks/native-checkpoint-b710-20261114
trap 'result=$?; printf "%s\n" "$result" > "$root/exit-code.txt"' EXIT
python3 "$root/collect.py"
