#!/usr/bin/env bash
set -euo pipefail
export DOTNET_ROOT="$HOME/.dotnet"
export PATH="$DOTNET_ROOT:$PATH"
cd /mnt/d/code/Lython
lab="$PWD/.git/agent-notes/review-20261031/generator-definition-cache-20261127"
export NUGET_PACKAGES="$PWD/.git/agent-notes/review-20261031/regex-released-050-20261127/packages-ubuntu"
internal=tests/Lokad.Lython.Tests/Lokad.Lython.Tests.csproj
public=tests/Lokad.Lython.PublicApi.Tests/Lokad.Lython.PublicApi.Tests.csproj
private_path="$lab/../current-quiet-script-checkpoint-20261127/cache-ubuntu"
internal_filter='Category!=Stress&(FullyQualifiedName~RecordFieldLookupOwnershipTests|FullyQualifiedName~ExecutableAsyncIteratorCleanupTests|FullyQualifiedName~CompiledGeneratorExpressionTests|FullyQualifiedName~ClassMethodExecutionBoundaryTests|FullyQualifiedName~GeneratorPreparedSliceOwnershipTests|FullyQualifiedName~SynchronousGeneratorAdvanceTests)'
public_filter='Category!=Stress&(FullyQualifiedName~GeneratorExpressionBoundary|FullyQualifiedName~GeneratorStorageSemantics|FullyQualifiedName~ComprehensionSuper|FullyQualifiedName~Starmap|FullyQualifiedName~BulkGeneratorConsumptionTests|FullyQualifiedName~BufferedGeneratorContinuationTests|FullyQualifiedName~GeneratorCleanupCompositionTests|FullyQualifiedName~IteratorProtocolScenarioTests|FullyQualifiedName~ExecutableCallLifetimeTests|FullyQualifiedName~CsvScenarioTests)'
for framework in net11.0 net10.0; do
    dotnet test "$internal" -c Release -f "$framework" --artifacts-path "$private_path" --filter "$internal_filter" 2>&1 | tee "$lab/ubuntu-whitebox-$framework.log"
    dotnet test "$public" -c Release -f "$framework" --artifacts-path "$private_path" --filter "$public_filter" 2>&1 | tee "$lab/ubuntu-public-$framework.log"
done
