from hashlib import sha256
from pathlib import Path
from shutil import copyfile
import json
import subprocess
import tarfile

root = Path(__file__).resolve().parent
repo = root.parents[3]
pair = root / "comparison"
quiet = pair / "quiet"
inputs = root.parent / "current-quiet-script-checkpoint-20261127"
read = lambda path: json.loads(path.read_bytes())
digest = lambda path: sha256(path.read_bytes()).hexdigest()
timed = [read(stage / "summary.json") for stage in (pair, quiet)]
assert timed[0]["sourceRevision"] == timed[1]["sourceRevision"]
assert timed[0]["candidatePatchSHA256"] == timed[1]["candidatePatchSHA256"] == digest(root / "candidate.patch")
assert all(row["verifiedTimedBatches"] == 112 for row in timed)
for folder in (pair, quiet):
    assert digest(folder / "observations.tar.xz") == read(folder / "archive-receipt.json")["archiveSHA256"]
assert subprocess.check_output(["git", "diff", "--binary", timed[0]["sourceRevision"], "--", "src"], cwd=repo) == (root / "candidate.patch").read_bytes()
assert subprocess.check_output(["git", "diff", "--binary", timed[0]["sourceRevision"], "--", "tests"], cwd=repo) == (root / "regression.patch").read_bytes()
win_bin = repo / "src/Lokad.Lython/bin/Release/net11.0/Lokad.Lython.dll"
assert digest(win_bin) == read(pair / "identity.json")["coreSHA256"]["candidate"]

records = read(root / "allocation/summary.json")
assert len(records) == 8 and all(peak["peak"][0] == peak["peak"][1] for peak in records)
out = repo / "benchmarks/results/2026-11-27-generator-definition-cache"
out.mkdir(exist_ok=True)
copyfile(root / "allocation/summary.json", out / "allocation-summary.json")
for name in ("identity.json", "summary.json", "archive-receipt.json", "observations.tar.xz", "stage-custody.json", "terminal-status.json"):
    copyfile(quiet / name, out / name)
for name in ("summary.json", "archive-receipt.json", "observations.tar.xz"):
    copyfile(pair / name, out / ("local-" + name))

sources = [root / name for name in ("prepare.py", "prepare.log", "prepare-quiet.py", "quiet-vm.py", "summarize.py", "archive.py",
                                    "candidate.patch", "regression.patch", "test-windows.ps1", "test-ubuntu.sh")]
sources += [quiet / name for name in ("reference-remote-verify.json", "candidate-remote-verify.json", "upload.json", "launch.log", "exit-code.txt")]
sources += [pair / name for name in ("reference-verify.json", "candidate-verify.json", "run.sh", "collection.log", "exit-code.txt")]
for name in ("cache-first-fixture-win11.log", "cache-first-fixture-ubuntu11.log", "cache-prototype-win11.log",
             "cache-prototype-ubuntu11.log", "ci-fix-win-net11.0.log", "ci-fix-win-net10.0.log"):
    sources.append(inputs / name)
sources += list((root / "allocation").glob("*.json"))
for platform in ("windows", "ubuntu"):
    for fw in ("net11.0", "net10.0"):
        for suite in ("public", "whitebox"):
            log = root / f"{platform}-{suite}-{fw}.log"
            assert "Passed!" in log.read_text(encoding="utf-8")
            sources.append(log)
names = {path: path.relative_to(root.parent).as_posix() for path in sources}
assert len(names) == len(sources)
with tarfile.open(out / "procedures.tar.xz", "w:xz") as archive:
    for path, name in names.items():
        archive.add(path, arcname=name)
with tarfile.open(out / "procedures.tar.xz") as archive:
    assert all(archive.extractfile(name).read() == path.read_bytes() for path, name in names.items())
print(f"{sum(run['verifiedTimedBatches'] for run in timed)} verified timed batches over both runs.")
