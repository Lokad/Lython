$ErrorActionPreference = 'Stop'
$env:DOTNET_ROOT = Join-Path $env:USERPROFILE '.dotnet11'
$dotnet = Join-Path $env:DOTNET_ROOT 'dotnet.exe'
$internal = 'tests/Lokad.Lython.Tests/Lokad.Lython.Tests.csproj'
$public = 'tests/Lokad.Lython.PublicApi.Tests/Lokad.Lython.PublicApi.Tests.csproj'
$internalFilter = 'Category!=Stress&(FullyQualifiedName~RecordFieldLookupOwnershipTests|FullyQualifiedName~ExecutableAsyncIteratorCleanupTests|FullyQualifiedName~CompiledGeneratorExpressionTests|FullyQualifiedName~ClassMethodExecutionBoundaryTests|FullyQualifiedName~GeneratorPreparedSliceOwnershipTests|FullyQualifiedName~SynchronousGeneratorAdvanceTests)'
$publicFilter = 'Category!=Stress&(FullyQualifiedName~GeneratorExpressionBoundary|FullyQualifiedName~GeneratorStorageSemantics|FullyQualifiedName~ComprehensionSuper|FullyQualifiedName~Starmap|FullyQualifiedName~BulkGeneratorConsumptionTests|FullyQualifiedName~BufferedGeneratorContinuationTests|FullyQualifiedName~GeneratorCleanupCompositionTests|FullyQualifiedName~IteratorProtocolScenarioTests|FullyQualifiedName~ExecutableCallLifetimeTests|FullyQualifiedName~CsvScenarioTests)'
foreach ($framework in 'net11.0', 'net10.0') {
    foreach ($test in @(@($internal, $internalFilter, 'whitebox'), @($public, $publicFilter, 'public'))) {
        & $dotnet test $test[0] -c Release -f $framework --filter $test[1] | Tee-Object (Join-Path $PSScriptRoot "windows-$($test[2])-$framework.log")
        if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
    }
}
