from hashlib import sha256
from pathlib import Path
from shutil import copyfile
import json
import tarfile

lab = Path(__file__).resolve().parent
pair = lab / "comparison"
prior = lab.parent / "quiet-generator-outer-20261127"
donor = lab.parent / "current-quiet-script-checkpoint-20261127/comparison/quiet"
quiet = pair / "quiet"
quiet.mkdir()
read = lambda path: json.loads(path.read_text(encoding="utf-8"))
digest = lambda path: sha256(path.read_bytes()).hexdigest()
def write(path, value):
    path.write_text(json.dumps(value, indent=2) + "\n", encoding="utf-8", newline="\n")

identity = read(pair / "identity.json")
receipt = read(donor / "terminal-status.json")["receipt"]
donor_files = read(donor / "identity.json")["imageFiles"]["candidate"]
assert receipt["quietBeforeAndAfter"] and receipt["allWorkersJoined"]
assert receipt["archiveSHA256"] == digest(donor / "observations.tar.xz")
assert identity["imageFiles"]["reference"] == donor_files
for role, files in identity["imageFiles"].items():
    assert {file.name: digest(file) for file in (pair / role).iterdir()} == files
    proof = read(pair / f"{role}-verify.json")
    assert proof["state"] == "Completed" and proof["caseCount"] == 4
    assert proof["launched"]["library"]["sha256"] == files["Lokad.Lython.dll"]
    assert proof["launched"]["adapter"]["sha256"] == files["Lokad.Lython.Benchmarks.dll"]
    assert proof["catalogSha256"] == identity["catalogs"]["representative.json"]["sha256"]
identity["donorArchiveSHA256"] = receipt["archiveSHA256"]
identity["purpose"] = "Quiet comparison of definition-owned lookup storage shared by interleaved generators."
for name in ("representative.json", "jobs.json", "cpython-worker.py"):
    copyfile(pair / name, quiet / name)
prior_quiet = prior / "comparison/quiet"
copyfile(prior_quiet / "run.sh", quiet / "run.sh")
assert b"\r" not in (quiet / "run.sh").read_bytes()
collector = (prior_quiet / "collect.py").read_text(encoding="utf-8")
collector = collector.replace("lython-b1895-generator-outer-fixtures", "lython-b1897-generator-cache-fixtures")
compile(collector, "collect.py", "exec")
(quiet / "collect.py").write_text(collector, encoding="utf-8", newline="\n")
write(quiet / "identity.json", identity)
payload_paths = {name: quiet / name for name in ("identity.json", "representative.json", "jobs.json", "cpython-worker.py", "run.sh", "collect.py")}
payload_paths["candidate/Lokad.Lython.dll"] = pair / "candidate/Lokad.Lython.dll"
payload = quiet / "stage.tar.gz"
with tarfile.open(payload, "w:gz") as archive:
    for name, source in payload_paths.items():
        archive.add(source, arcname=name)
files = {name: dict(length=file.stat().st_size, sha256=digest(file)) for name, file in payload_paths.items()}
write(quiet / "upload.json", dict(root="generator-cache-quiet-b1897-20261127",
    donor=read(donor / "upload.json")["root"], donorFiles=donor_files, donorArchive=receipt["archiveSHA256"],
    payloadSHA256=digest(payload), files=files, expandedBytes=sum(file["length"] for file in files.values()),
    minimumAfterStageBytes=12 * 1024 * 1024))
vm = (prior / "quiet-vm.py").read_text(encoding="utf-8")
vm = vm.replace("lython-b1895-generator-outer-quiet", "lython-b1897-generator-cache-quiet")
compile(vm, "quiet-vm.py", "exec")
(lab / "quiet-vm.py").write_text(vm, encoding="utf-8", newline="\n")
print("Prepared complete paired images for four lanes.")
