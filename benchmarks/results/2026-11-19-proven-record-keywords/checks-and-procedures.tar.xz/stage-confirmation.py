from pathlib import Path
import ast, copy, hashlib, json, tarfile

lab=Path(__file__).resolve().parent
old=lab/'quiet'
confirm=lab/'confirmation'
confirm.mkdir(exist_ok=False)
read=lambda p:p.read_text(encoding='utf-8-sig')
load=lambda p:json.loads(read(p))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def write(path,content):
    if path.suffix=='.py': ast.parse(content)
    path.write_text(content,encoding='utf-8',newline='\n')
def save(path,data): write(path,json.dumps(data,indent=2,ensure_ascii=False)+'\n')

prior=load(old/'config.json')
receipt=load(old/'archive-receipt.json')
assert receipt['complete'] and receipt['archivedAndVerifiedUnderLease']
assert receipt['archiveSHA256']==sha(old/'observations.tgz')
identity=copy.deepcopy(prior['identity'])
assert sha(lab/'catalog.json')==identity['catalogSHA256']
identity['purpose']='R694 reversed worker confirmation for shared record keys'
for role,files in identity['imageFiles'].items():
    assert len(files)==32 and {name:sha(lab/'frozen'/role/name) for name in files}==files
    v=load(lab/f'{role}-verify.json')
    assert v['state']=='Completed' and v['catalogSha256']==identity['catalogSHA256']
save(confirm/'identity.json',identity)
for name in ('collect.py','archive-owned.py','retrieve.py','run.sh'):
    text=read(old/name).replace('proven-record-keywords-b1124-20261119','proven-record-keywords-b1126-20261119')
    text=text.replace("len(raw['jobs'])==5","len(raw['jobs'])==4").replace("['jobs']==5","['jobs']==4").replace('jobs=5,','jobs=4,').replace('len(jobs)==5','len(jobs)==4')
    if name=='collect.py':
        a,b=text.index('\njobs = '),text.index('\nassert len(jobs)')
        cases=[('scripts.json-keyword-transform.large','warm'),('scripts.json-record-transform.large','warm'),
               ('scripts.csv-keyword-invoice.large','warm'),('scripts.report-forwarding.expanded','warm')]
        text=text[:a]+'\njobs = '+repr(cases)+text[b:]
        before='if job_index < 2: labels.reverse()'
        assert text.count(before)==1
        # The original target cases began reverse. The two controls began forward.
        text=text.replace(before,'if job_index in (1, 3): labels.reverse()')
    write(confirm/name,text)
names=('collect.py','archive-owned.py','run.sh','identity.json')
payload=confirm/'payload.tgz'
with tarfile.open(payload,'w:gz') as archive:
    for name in names: archive.add(confirm/name,arcname=name)
config=dict(root=prior['root'].replace('b1124','b1126'),unit=prior['unit'].replace('b1124','b1126'),
     source=prior['root'],identity=identity,sourceCatalogSHA256=identity['catalogSHA256'],
     catalogSHA256=identity['catalogSHA256'],retireGroups=[],donorArchiveSHA256=receipt['archiveSHA256'],
     payloadBytes=payload.stat().st_size,payloadSHA256=sha(payload),unpackedBytes=sum((confirm/name).stat().st_size for name in names))
save(confirm/'config.json',config)
source=read(old/'remote-launch.py')
a,b=source.index('\nc=')+1,source.index('\nb=Path(')
source=source[:a]+'c='+repr(config)+source[b:]
source=source.replace('lython-b1124-fixtures','lython-b1126-fixtures')
before=" for n,h in c['sourceFiles'].items():assert sha(source/c['sourceRole']/n)==h,n"
after=" for role,files in c['identity']['imageFiles'].items():\n  for n,h in files.items():assert sha(source/role/n)==h,n"
assert source.count(before)==1
source=source.replace(before,after).replace("os.link(source/c['sourceRole']/n,p)",'os.link(source/role/n,p)')
assert source.count('sourceRole')==0 and 'lython-b1126-fixtures' in source
write(confirm/'remote-launch.py',source)
launch=read(lab/'launch-quiet.py').replace("parent/'quiet'","parent/'confirmation'").replace('292','238')
write(lab/'launch-confirmation.py',launch)
summarize=read(lab/'summarize-quiet.py').replace("'quiet/retrieved/","'confirmation/retrieved/").replace('==5','==4').replace('quiet-summary.json','confirmation-summary.json')
assert 'confirmation-summary.json' in summarize
write(lab/'summarize-confirmation.py',summarize)
print('Prepared four unchanged-image work lanes and reversed every initial worker order.')