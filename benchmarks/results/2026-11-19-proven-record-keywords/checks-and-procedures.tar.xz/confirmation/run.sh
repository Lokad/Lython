set -eu
root=/home/lokad/lython-bench-checks/proven-record-keywords-b1126-20261119
trap 'result=$?; printf "%s\n" "$result" > "$root/exit-code.txt"' EXIT
python3 "$root/collect.py"
