from pathlib import Path
r=Path(__file__).resolve().parent
s=(r.parent/'constant-record-r499/freeze.py').read_text(encoding='utf-8')
s=s.replace("work=repo/'.git/agent-worktrees/constant-record-r499';prior=r.parent/'record-construction-r498/final'", "work=repo/'.git/agent-worktrees/transfer-dispatch-r501';prior=r.parent/'constant-record-r499'")
s=s.replace('len(production)==8','len(production)==2')
s=s.replace('Committed4b975a44/frozen5d9633a8; corrected function/container construction','Committedea8e9f91/frozencf847936; constant-key record construction')
s=s.replace('Private R499 on4b975a44: constant string-key displays transport values only; existing execution/function lookup cache and RecordKeys own immutable key storage. Auxiliary worker/adapter remain reference copies.', 'Private R501 one two-file change onea8: collapse owned-runner secondary transfer switch into primary dispatch; direct cold member helper. Native borrowed initialization and all ownership/cancellation unchanged. Auxiliary worker/adapter remain reference copies.')
s=s.replace('final R498 diagnostics','R499 diagnostics').replace('R498 final candidate5d9633a8','R499 candidatecf847936')
(r/'freeze.py').write_text(s,encoding='utf-8',newline='\n')
