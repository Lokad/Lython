from pathlib import Path
import gzip,hashlib,io,json,subprocess,tarfile
r=Path(__file__).resolve().parent;repo=Path('D:/code/Lython');subjects=[]
canonical='benchmarks/results/2026-11-17-function-container-construction/final/candidate-core.dll.gz'
blob=subprocess.check_output(['git','show','HEAD:'+canonical],cwd=repo);assert blob==(repo/canonical).read_bytes();data=gzip.decompress(blob)
subjects.append(dict(kind='superseded-core',sha256=hashlib.sha256(data).hexdigest(),bytes=len(data),canonical=canonical,canonicalSHA256=hashlib.sha256(blob).hexdigest(),member='gzip-payload',committedBlobVerified=True))
current=json.loads((r/'frozen/identity.json').read_text(encoding='utf-8'));assert subjects[0]['sha256']not in[v['Lokad.Lython.dll']for v in current['imageFiles'].values()]
canonical='benchmarks/results/2026-11-17-current-script-cpu/observations.tgz';blob=subprocess.check_output(['git','show','HEAD:'+canonical],cwd=repo);assert blob==(repo/canonical).read_bytes()
subjects.append(dict(kind='completed-replica',path='current-script-cpu-b925-20261117/observations.tgz',bytes=len(blob),sha256=hashlib.sha256(blob).hexdigest(),canonical=canonical,canonicalSHA256=hashlib.sha256(blob).hexdigest(),member='whole-archive',committedBlobVerified=True))
s=(r.parent/'json-scalars-r492/prepare-quiet.py').read_text(encoding='utf-8');a=s.index("code = '''")+len("code = '''");b=s.index("'''.replace",a)
code=s[a:b].replace('SUBJECTS',repr(subjects)).replace("else[b/'numeric-json-cost-b909-20261117/observations.tgz']","else[b/item['path']]").replace('json-cpython-b908-20261117','constant-record-b924-20261117')
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
p=subprocess.run(ssh+['python3 -'],input=code,text=True,encoding='utf-8',capture_output=True,timeout=60);assert p.returncode==0,p.stdout+p.stderr
proofs=json.loads(p.stdout);out=dict(proofs=proofs,eligibleBytes=sum(p['bytes']for p in proofs),currentCf847936Protected=True,allRetiredBytesAlreadyCommitted=True)
(r/'retirement-candidates.json').write_text(json.dumps(out,indent=2)+'\n',encoding='utf-8');print(json.dumps(dict(eligibleBytes=out['eligibleBytes'],groups=len(proofs),oldCoreAliases=proofs[0]['paths'])))
