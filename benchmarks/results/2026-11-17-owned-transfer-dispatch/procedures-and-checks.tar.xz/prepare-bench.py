from pathlib import Path
import ast
r=Path(__file__).resolve().parent
s=(r.parent/'constant-record-r499/prepare.py').read_text(encoding='utf-8')
s=s.replace("prior=r.parent/'record-construction-r498/final'", "prior=r.parent/'constant-record-r499'")
s=s.replace('constant-record-b924-20261117','transfer-dispatch-b926-20261117').replace('lython-b924-constant-record-20261117','lython-b926-transfer-dispatch-20261117').replace('lython-b924-fixtures','lython-b926-fixtures')
s=s.replace('Committed4b975a44/5d9633a8 versus privateR499/', 'Committedea8e9f91/cf847936 versus privateR501/')
s=s.replace('Constant string-key displays: remove key operands/private per-record key tables; existing RecordKeys/lookup owners, unchanged Python semantics. Complete record transform warm/fresh and helper/text/floating/call controls.', 'Collapse owned-runner secondary transfer dispatch into its existing primary loop; no new frame or transport view, native helpers unchanged. Complete text/floating warm/fresh plus record/call controls, no predicted gain.')
a=s.index('jobs=');b=s.index('\ns=',a)
jobs=[['scripts.text-normalization.large','warm'],['scripts.text-normalization.large','compile-run'],['scripts.numeric-squared-error.floating.large','warm'],['scripts.numeric-squared-error.floating.large','compile-run'],['scripts.json-record-transform.large','warm'],['calls.positional.large','warm']]
s=s[:a]+'jobs='+repr(jobs)+s[b:]
s=s.replace("'B923','B924'", "'B924','B926'").replace('Six-job constant-record source pair','Six-job primary-transfer source pair')
ast.parse(s);(r/'prepare.py').write_text(s,encoding='utf-8',newline='\n')
print('Prepared reproducible six-job changed-source gate; no staging yet.')
