from pathlib import Path
import gzip,hashlib,json,os,shutil,subprocess,tarfile
r=Path(__file__).resolve().parent;repo=Path('D:/code/Lython');work=repo/'.git/agent-worktrees/transfer-dispatch-r501';prior=r.parent/'constant-record-r499'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert 'Build succeeded.'in(r/'build.log').read_text(encoding='utf-8-sig')
base=json.loads((prior/'frozen/identity.json').read_text(encoding='utf-8'));frozen=r/'frozen';frozen.mkdir(exist_ok=False);images={}
for role in ['reference','candidate']:
 image=frozen/role;image.mkdir()
 for n,h in base['imageFiles']['candidate'].items():
  assert sha(prior/'frozen/candidate'/n)==h,n
  shutil.copyfile(prior/'frozen/candidate'/n,image/n)
 if role=='candidate':shutil.copyfile(work/'src/Lokad.Lython/bin/Release/net11.0/Lokad.Lython.dll',image/'Lokad.Lython.dll')
 images[role]={n:sha(image/n)for n in base['imageFiles']['candidate']}
 for p in(prior/'frozen/candidate').glob('ValidatedAllocation.*'):shutil.copyfile(p,image/p.name)
assert [n for n in images['reference']if images['reference'][n]!=images['candidate'][n]]==['Lokad.Lython.dll']
shutil.copyfile(prior/'catalog.json',r/'catalog.json')
inputs=json.loads((r.parent/'record-construction-r498/delivery/inputs.json').read_text(encoding='utf-8'))
names=list(inputs['inputs']);assert len(names)==2385
hashes={n:sha(work/n)for n in names}
with tarfile.open(r/'candidate-sources.tar.xz','w:xz')as a:
 for n in names:a.add(work/n,arcname=n)
changed=subprocess.check_output(['git','diff','--name-only'],cwd=work,text=True).splitlines();production=[n for n in changed if n.startswith('src/Lokad.Lython/')]
assert len(production)==2,production
(r/'prototype.patch.gz').write_bytes(gzip.compress(subprocess.check_output(['git','diff','--']+changed,cwd=work),mtime=0))
identity=dict(referenceSource='Committedea8e9f91/frozencf847936; constant-key record construction',candidateSource='Private R501 one two-file change onea8: collapse owned-runner secondary transfer switch into primary dispatch; direct cold member helper. Native borrowed initialization and all ownership/cancellation unchanged. Auxiliary worker/adapter remain reference copies.',imageFiles=images,sourceInputs=hashes,sourceInputsArchiveSHA256=sha(r/'candidate-sources.tar.xz'),productionFiles=585,changedProductionFiles=production,catalogSHA256=sha(r/'catalog.json'),normalAdapterPin='0.4.0',publicationHeld=True)
(frozen/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8',newline='\n')
dotnet=Path('C:/Users/JoannesVermorel/.dotnet11/dotnet.exe');env=os.environ.copy();env.update(DOTNET_ROOT=str(dotnet.parent),DOTNET_ROOT_X64=str(dotnet.parent));env['PATH']=str(dotnet.parent)+os.pathsep+env['PATH']
# Reference image/catalog are exact unchanged copies of R499 diagnostics.
for kind in ['preflight','allocation']:
 shutil.copyfile(prior/('candidate-'+kind+'.json'),r/('reference-'+kind+'.json'))
(r/'reference-reuse.json').write_text(json.dumps(dict(all32ImageHashesVerified=True,catalogSHA256=sha(r/'catalog.json'),source='R499 candidatecf847936'),indent=2)+'\n',encoding='utf-8')
image=frozen/'candidate'
commands=[
 ('preflight',[str(dotnet),str(image/'Lokad.Lython.Benchmarks.dll'),'--compare','verify',
  '--catalog',str(r/'catalog.json'),'--dotnet',str(dotnet),'--python','C:/Python313/python.exe',
  '--python-worker',str(repo/'benchmarks/cpython-worker.py'),'--out',str(r/'candidate-preflight.json')]),
 ('allocation',[str(dotnet),str(image/'ValidatedAllocation.dll'),str(image),str(r/'catalog.json'),
  str(r/'candidate-allocation.json')])
]
for label,cmd in commands:
 with(r/('candidate-'+label+'.log')).open('w',encoding='utf-8')as log:p=subprocess.run(cmd,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=180)
 assert p.returncode==0,(label,(r/('candidate-'+label+'.log')).read_text(encoding='utf-8'));print('candidate',label,'passes',flush=True)
print('Frozen changed core',images['candidate']['Lokad.Lython.dll'],flush=True)
