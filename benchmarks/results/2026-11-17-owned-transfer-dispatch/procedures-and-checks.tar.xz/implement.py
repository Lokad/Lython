from pathlib import Path
import re
r=Path(__file__).resolve().parent;work=Path('D:/code/Lython/.git/agent-worktrees/transfer-dispatch-r501')
p=work/'src/Lokad.Lython/Runtime/LythonRuntime.Executable.Interpreter.cs';s=p.read_text(encoding='utf-8')
a=s.index('        private static void ExecuteStackTransfer(');b=s.index('        private bool ExecuteStructure(',a)
method=s[a:b];parts=re.split(r'^                case ExecutableOpCode\.(\w+):\n',method,flags=re.MULTILINE);cases={parts[i]:parts[i+1]for i in range(1,len(parts),2)}
assert set(cases)=={'LoadConst','LoadGlobal','LoadName','LoadCallMember','LoadMember','PreloadImplicitSuperArguments','StoreGlobal','StoreName','Dup','PopTop'}
ordinary=['LoadConst','LoadGlobal','LoadName','PreloadImplicitSuperArguments','StoreGlobal','StoreName','Dup','PopTop']
out=[]
for name in ordinary:
 body=cases[name]
 if name=='PopTop':body=body[:body.rindex('            }')]
 body=body.rstrip();assert body.endswith('break;'),(name,body)
 body=body[:-len('break;')].rstrip()
 # Each case retains its own local scope after removing the helper's switch.
 out.append('                        case ExecutableOpCode.'+name+':\n                        {\n')
 if name in ['LoadName','PreloadImplicitSuperArguments','StoreGlobal','StoreName']:
  out.append('                            if (invocation is null) return InstructionPause.ContextRequired;\n')
 out.append('\n'.join('        '+line for line in body.splitlines())+'\n')
 out.append('                            break;\n                        }\n')
body=cases['LoadMember'].rstrip();assert body.endswith('break;');body=body[:-len('break;')].rstrip()
member='''        // Member protocols keep their cold helper; ordinary operand transfers
        // now execute directly in the primary loop, without a second switch.
        private static void ExecuteMemberLoad(ref ExecutableWorkState execution, ExecutionContext scope,
            ExecutionContext? invocation, in ExecutableInstruction instruction)
        {
            if (instruction.OpCode == ExecutableOpCode.LoadCallMember &&
                TryLoadDirectCallReceiver(ref execution, scope, invocation, instruction)) return;
'''+ '\n'.join(line[8:]for line in body.splitlines())+'\n        }\n\n'
p.write_text(s[:a]+member+s[b:],encoding='utf-8',newline='\n')
p=work/'src/Lokad.Lython/Runtime/LythonRuntime.Executable.Interpreter.Dispatch.cs';s=p.read_text(encoding='utf-8')
s=s.replace('if (!asynchronous) ExecuteStackTransfer(ref execution, scope, invocation, instruction);','if (!asynchronous) ExecuteMemberLoad(ref execution, scope, invocation, instruction);')
a=s.index('                        case ExecutableOpCode.LoadConst or');b=s.index('                        case ExecutableOpCode.MakeList:',a)
old=s[a:b];assert old.count('ExecuteStackTransfer')==1
s=s[:a]+''.join(out)+s[b:]
assert 'ExecuteStackTransfer'not in s
p.write_text(s,encoding='utf-8',newline='\n')
print('Collapsed eight ordinary transfer cases into primary dispatch; direct cold member helper has no secondary switch.')
