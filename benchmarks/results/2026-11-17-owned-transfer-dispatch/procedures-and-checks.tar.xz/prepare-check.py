from pathlib import Path
r=Path(__file__).resolve().parent
s=(r.parent/'constant-record-r499/check.py').read_text(encoding='utf-8').replace('constant-record-r499','transfer-dispatch-r501').replace("'SequenceConstructionOwnership'", "'SequenceConstructionOwnership','FunctionLookupLifetime'").replace("'RepresentativeProtocolCancellation'", "'RepresentativeProtocolCancellation','Dictionary','GovernedMemoryContract','MemoryDenialAttribution'")
(r/'check.py').write_text(s,encoding='utf-8',newline='\n')
