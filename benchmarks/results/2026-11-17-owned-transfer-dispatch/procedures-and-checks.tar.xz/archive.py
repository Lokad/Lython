from pathlib import Path
import gzip,json,shutil,tarfile
r=Path(__file__).resolve().parent;repo=Path('D:/code/Lython');out=repo/'benchmarks/results/2026-11-17-owned-transfer-dispatch';out.mkdir(exist_ok=False)
decision=dict(promoted=False,classification='Unproven CPU benefit; control uncertainty, not permanent design rejection.',reason='One switch removed but the actual operand work/storage remains; text warm flat, fresh CPU straddles zero and call CPU slightly adverse. No allocation reduction. Retention would not advance the substantial-performance objective enough on this evidence.',furtherWork='Bounded refinement/confirmation remains possible with a named cause or changed design; do not promote or infer recovery from source simplification alone.',source='Private R501 on ea8/corebfef519a versus committedea8 production/corecf847936',publicationHeld=True)
(r/'decision.json').write_text(json.dumps(decision,indent=2)+'\n',encoding='utf-8',newline='\n')
for n in ['summary.json','allocation-summary.json','candidate-allocation.json','candidate-preflight.json','candidate-sources.tar.xz','prototype.patch.gz','reference-reuse.json','checks.json','decision.json']:
 shutil.copyfile(r/n,out/n)
for n in ['archive-receipt.json','terminal-status.json','observations.tgz']:shutil.copyfile(r/'quiet'/n,out/n)
shutil.copyfile(r/'frozen/identity.json',out/'identity.json')
with gzip.open(out/'candidate-core.dll.gz','wb')as a:a.write((r/'frozen/candidate/Lokad.Lython.dll').read_bytes())
with tarfile.open(out/'procedures-and-checks.tar.xz','w:xz')as a:
 for p in sorted(r.rglob('*')):
  if not p.is_file()or any(n in p.relative_to(r).parts for n in ['frozen','retrieved']):continue
  if p.suffix in ['.dll','.xz','.tgz','.gz']:continue
  a.add(p,arcname=p.relative_to(r).as_posix())
summary=json.loads((out/'summary.json').read_text(encoding='utf-8'));summary['retentionDecisionPending']=False;summary['decision']=decision
(out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8',newline='\n')
(out/'README.md').write_text('''# Owned transfer dispatch source gate

Private R501/corebfef519a on ea8e9f91 versus committedea8production/corecf847936.
Two files move eight ordinary transfer cases into the existing primary opcode
loop, delete its secondary transfer switch and retain a direct cold member helper.
No new frame/operand view/opcode/policy; native borrowed helper initialization
stays separate after R495's adverse shared-runner designs. Net source lines flat.

B926 six jobs229.76s,2026-11-17 quiet F4as_v7/Ubuntu24.04.4/.NET11RC3, normalGC/
tiering, six-second warmups/five rotated rounds/two processes per source:

| Complete script/phase | Elapsed change | Process CPU change | Reference/candidate spread |
| --- | --- | --- | --- |
| Text normalization warm | −0.84..+0.18% | −1.93..+1.56% |0.87/0.15%|
| Text compile-to-result | −3.22..−1.56% | −1.89..+1.31% |1.64/0.07%|
| Floating report warm | −6.79..+1.22% | −7.58..+0.68% |0.40/8.16%|
| Floating compile-to-result | +0.09..+2.09% | −1.62..+0.69% |1.69/0.30%|
| Record transform warm | −3.63..+3.57% | −2.94..+4.55% |4.14/3.20%|
| Positional calls warm | −0.28..+1.85% | +0.79..+2.02% |0.14/2.00%|

Allocation and accounted peaks are effectively flat; six budget baselines restore.
Both actual11/10 each407internal/566public focused checks and six actual-image
goldens pass. These preserve contexts/spans/PCs, member/protocol suspension,
publication/aliases, cancellation/terminal refusal and cleanup. No new tests mirror
the deleted dispatcher. The unchanged cf reference diagnostics are reused only
after all32image hashes/catalog compare. Auxiliary worker/adapter are reference
copies; source archives/patches identify the two changed production files.

Decision: leave isolated and unpromoted. A secondary switch is removed, but no
storage or substantive operand work disappears. The measured CPU benefit is
unproven, with small adverse call CPU and unresolved source-control movement.
This is uncertainty, not a failed architecture or permanent rejection. Bounded
confirmation/refinement remains possible for a named cause or changed design.
Current evidence does not justify retaining this rearrangement as a substantial
performance improvement. No unchanged full qualification is requested.

Warm includes mediated RAM I/O/goldens/prior-result cleanup; fresh adds compilation/
compiled-owner disposal. Startup/reset/protocol/final cache teardown excluded;
process CPU is wider. All workers joined, quiet gates passed, persistent archive
SHA verified and fixtures removed. Exact committed old5dcore aliases/profile archive
only retired; current cf/prototype images/catalog/toolchains preserved. Original
254/252MiB floors unchanged. No CPython ratio inferred or publication.

[Summary](summary.json),[decision](decision.json),[allocation](allocation-summary.json),
[raw](observations.tgz),[identity](identity.json),[source](candidate-sources.tar.xz),
[procedures/checks](procedures-and-checks.tar.xz).
''',encoding='utf-8',newline='\n')
with(repo/'benchmarks/EXPERIMENTS.md').open('a',encoding='utf-8',newline='\n')as h:h.write('\nR501 [secondary owned transfer dispatch deletion](results/2026-11-17-owned-transfer-dispatch/README.md), privatebfef519a versuscf: two files/netLOCflat, no new frame/view/opcode. Six-job229.76s source pair shows textwarmflat/freshCPUstraddleszero, floating/record controlsuncertain and positionalCPU+0.79..+2.02%; allocation/peaksflat. Both targets407internal/566public/sixgoldens/reuse pass. Leave isolated/unpromoted: no substantive operand work removed or demonstrated CPU benefit. Uncertainty rather than permanent rejection; evidence-based bounded refinement remains possible. All sources/conditions/raw preserved, no full replay/publication.\n')
p=repo/'PLAN.md';s=p.read_text(encoding='utf-8');a=s.index('| Active private prototype | R501');b=s.index('\n',a)
s=s[:a]+'''| Private; unpromoted | R501bfef519a secondary owned-transfer switch deletion:407internal/566public eachtarget/sixgoldens/reuse pass; B926229.76s textwarmflat/freshCPUstraddleszero, floating/record control uncertainty, positionalCPU+0.79..+2.02%, allocation/peaksflat. No substantive operand work/storage removed. Keep isolated as unproven, not permanent rejection; sources/raw/decision retained. Do not treat the profile's leaf shares as removable time. |'''+s[b:]
p.write_text(s,encoding='utf-8',newline='\n');print('Preserved inconclusive source gate; prototype isolated, main runtime unchanged.')
