from pathlib import Path
import json,os,stat,hashlib,fcntl,subprocess,shutil
r=Path('/home/lokad/lython-bench-checks');lease=(r/'comparison-vm.lock').open('a');fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
assert not subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record|[p]ython3.*cpython-worker.py'],capture_output=True).stdout
proofs=[]
for spec in [{'path': 'conditional-helper-b612-20261112/observations.tgz', 'bytes': 1986965, 'sha256': 'c13da53bf67d4dc4d942d74925597839d4694f55eae4a9d23dea2c1593abc377', 'canonicalStorage': 'benchmarks/results/2026-11-12-conditional-helper-bodies/initial/b612/observations.tgz'}, {'path': 'conditional-confirmation-b613-20261112/observations.tgz', 'bytes': 1968749, 'sha256': 'b95f7ce9f1b8823be14f0f067cc2b9135c9e922a56f2c56a3dcca23e2070b212', 'canonicalStorage': 'benchmarks/results/2026-11-12-conditional-helper-bodies/confirmation/observations.tgz'}, {'path': 'conditional-normalized-b614-20261112/observations.tgz', 'bytes': 1978355, 'sha256': '24450d2ec64baf443e74e8735508d7cec836178770f55d9901b912474ab7b7c3', 'canonicalStorage': 'benchmarks/results/2026-11-12-conditional-helper-bodies/normalized/b614/observations.tgz'}]:
 p=r/spec['path']
 if not p.exists():continue
 s=p.lstat();assert p.resolve(strict=True)==p and p.is_relative_to(r)and stat.S_ISREG(s.st_mode)and s.st_uid==os.getuid()and s.st_nlink==1
 assert s.st_size==spec['bytes']and hashlib.sha256(p.read_bytes()).hexdigest()==spec['sha256']
 proofs.append(dict(spec,device=s.st_dev,inode=s.st_ino,allocatedBytes=s.st_blocks*512))
for proof in proofs:
 p=r/proof['path'];s=p.lstat();assert(s.st_dev,s.st_ino)==(proof['device'],proof['inode'])and s.st_nlink==1;p.unlink()
print(json.dumps(dict(freshIdleLease=True,files=proofs,freeBytes=shutil.disk_usage(r).free,protectedImagesUnchanged=True)))
