set -eu
root=/home/lokad/lython-bench-checks/reader-windows-b622-20261112
date -u +%FT%TZ > "$root/started.utc"
systemctl show lython-b625-cpython-phases-20261112.service --property=RuntimeMaxUSec,LoadState,ActiveState,MainPID > "$root/live-unit.txt"
trap 'exit 143' TERM
trap 'result=$?; printf "%s\n" "$result" > "$root/exit-code-external-phases.txt"; date -u +%FT%TZ > "$root/stopped.utc"' EXIT
python3 "$root/collect-external-phases.py"
