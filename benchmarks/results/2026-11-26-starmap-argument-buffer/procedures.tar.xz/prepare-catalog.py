from pathlib import Path
import copy
import hashlib
import json

lab = Path(__file__).resolve().parent
prior = lab.with_name('direct-zip-starmap-20261126')/'comparison/quiet/representative.json'
control = lab.with_name('borrowed-map-sources-20261126')/'local/representative.json'
read = lambda p: json.loads(p.read_text(encoding='utf-8'))
manifest = read(prior)
baseline = next(row for row in manifest['cases'] if row['id']=='diagnostic.shipment-bound-starmap')
meter = next(row for row in read(control)['cases'] if row['id']=='scripts.csv-meter-report.explicit-float')
new = []
for name, signature, replacement in (
    ('short', 'flag, preferred, alternative',
     'results = starmap(choose, ([flag, review, selected] for flag, selected in zip(held, primary)))'),
    ('wide', 'flag, preferred, alternative, unused_first=None, unused_second=None',
     'results = starmap(choose, ([flag, review, selected, None, None] for flag, selected in zip(held, primary)))'),
):
    row = copy.deepcopy(baseline)
    row['id'] = 'diagnostic.shipment-starmap-'+name+'-lists'
    source = row['source']
    expected = 'results = starmap(choose, zip(held, repeat(review), primary))'
    assert source.count(expected)==1
    source = source.replace(expected, replacement)
    assert source.count('flag, preferred, alternative')==1
    source = source.replace('flag, preferred, alternative', signature)
    row['source'] = source
    row['sourceUtf8Bytes'] = len(source.encode())
    row['sourceSha256'] = hashlib.sha256(source.encode()).hexdigest()
    new.append(row)
manifest['cases'] = [*new, baseline, meter]
(lab/'representative.json').write_text(json.dumps(manifest, ensure_ascii=False, indent=2)+'\n',
                                      encoding='utf-8',newline='\n')
for row in manifest['cases']:
    print(row['id'], row['sourceUtf8Bytes'])
