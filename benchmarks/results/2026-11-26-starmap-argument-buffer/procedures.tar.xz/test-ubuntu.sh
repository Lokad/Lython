set -eu
export DOTNET_ROOT="$HOME/.dotnet"
export PATH="$DOTNET_ROOT:$PATH"
filter='Category!=Stress&(FullyQualifiedName~Starmap|FullyQualifiedName~IteratorAdapter|FullyQualifiedName~IterationWorkspaceLifetime|FullyQualifiedName~CustomIterationModuleRouting|FullyQualifiedName~CallExpansion|FullyQualifiedName~StarredCall)'
for suite in Lokad.Lython.PublicApi.Tests Lokad.Lython.Tests; do
    log="../$suite-ubuntu10.log"
    if dotnet test "tests/$suite/$suite.csproj" -c Release -f net10.0 --artifacts-path ../ubuntu --filter "$filter" > "$log" 2>&1; then
        tail -8 "$log"
    else
        tail -45 "$log"
        exit 1
    fi
done
