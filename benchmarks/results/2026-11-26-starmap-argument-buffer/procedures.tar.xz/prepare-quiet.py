from pathlib import Path
import hashlib, json, shutil, tarfile

lab = Path(__file__).resolve().parent
local = lab / 'local'
quiet = lab / 'comparison/quiet'
quiet.mkdir(parents=True)
previous = lab.with_name('deferred-site-placement-20261126')
donor = lab.with_name('json-ascii-character-20261126')
read = lambda p: json.loads(p.read_text(encoding='utf-8-sig'))
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()

def write(path, data):
    path.write_text(data, encoding='utf-8', newline='\n')

def save(path, value):
    write(path, json.dumps(value, indent=2) + '\n')

def edit(text, *substitutions):
    for before, after in substitutions:
        assert text.count(before) == 1, before
        text = text.replace(before, after)
    return text

for name in ('representative.json', 'cpython-worker.py', 'run.sh'):
    source = previous/'comparison/quiet'/name if name == 'run.sh' else local/name
    shutil.copyfile(source, quiet/name)
assert b'\r' not in (quiet/'run.sh').read_bytes()
identity = read(local/'identity.json')
assert identity['sourcePatchSHA256'] == sha(lab/'candidate.patch')
assert identity['cpythonWorkerSHA256'] == sha(quiet/'cpython-worker.py')
assert identity['catalogs']['representative.json']['sha256'] == sha(quiet/'representative.json')
prior = read(donor/'comparison/repeat/identity.json')
assert identity['imageFiles']['reference'] == prior['imageFiles']['candidate']
assert identity['expectedCPythonSHA256'] == prior['expectedCPythonSHA256']
for role, files in identity['imageFiles'].items():
    assert len(files) == 32 and {p.name: sha(p) for p in (local/role).iterdir()} == files
    verified = read(lab/(role+'-verify.json'))
    assert verified['state'] == 'Completed' and verified['caseCount'] == 4
    assert verified['catalogSha256'] == sha(quiet/'representative.json')
    assert verified['launched']['library']['sha256'] == files['Lokad.Lython.dll']

jobs = read(local/'jobs.json')
jobs['warm'] = jobs['warm'][2:] + jobs['warm'][:2]
save(quiet/'jobs.json', jobs)
identity['catalogs']['jobs.json']['sha256'] = sha(quiet/'jobs.json')
save(quiet/'identity.json', identity)

collector = edit((previous/'comparison/quiet/collect.py').read_text(encoding='utf-8'),
    ('lython-b1789-fixtures', 'lython-b1793-fixtures'),
    ("        catalog = root/'representative.json'",
     "        assert shutil.disk_usage(root).free >= 5_000_000, 'Keep space for persistent lane evidence'\n"
     "        catalog = root/'representative.json'"))
compile(collector, 'collect.py', 'exec')
write(quiet/'collect.py', collector)

names = ('identity.json', 'jobs.json', 'representative.json', 'collect.py', 'run.sh', 'cpython-worker.py')
payload = quiet/'stage.tar.gz'
with tarfile.open(payload, 'w:gz', compresslevel=6) as package:
    for name in names:
        package.add(quiet/name, arcname=name, recursive=False)

# Reuse the original physical reference image, with its verified first-run
# archive and the completed retry receipt for the identical files.
first = donor/'comparison/quiet'
repeat = donor/'comparison/repeat'
first_receipt = read(first/'terminal-status.json')['receipt']
repeat_receipt = read(repeat/'terminal-status.json')['receipt']
assert not first_receipt['complete'] and repeat_receipt['complete']
assert first_receipt['archiveSHA256'] == sha(first/'observations.tar.xz')
assert repeat_receipt['archiveSHA256'] == sha(repeat/'observations.tar.xz')
core = local/'candidate/Lokad.Lython.dll'
save(quiet/'upload.json', dict(root='starmap-argument-buffer-b1793-20261126',
    payloadSHA256=sha(payload), payloadBytes=payload.stat().st_size,
    expandedBytes=sum((quiet/name).stat().st_size for name in names),
    coreBytes=core.stat().st_size, coreSHA256=sha(core),
    donorSHA256=first_receipt['archiveSHA256'],
    completedDonorSHA256=repeat_receipt['archiveSHA256'], minimumAfterStageBytes=9_000_000))

launcher = edit((donor/'quiet.py').read_text(encoding='utf-8'),
    ("unit='lython-b1790-json-ascii-character-20261126'", "unit='lython-b1793-starmap-argument-buffer-20261126'"),
    ("cfg['coreBytes']+5*1024*1024,bytes", "cfg['coreBytes']+cfg['minimumAfterStageBytes']+65536,bytes"),
    ("free>=expanded+4*1024*1024", "free>=expanded+cfg['minimumAfterStageBytes']"),
    ("donor=base/'deferred-site-placement-b1789-20261126'/'candidate'", "donor=base/'json-ascii-character-b1790-20261126'/'candidate'"),
    (" assert donor_receipt['complete'] and donor_receipt['archiveSHA256']==cfg['donorSHA256']==sha(donor.parent/'observations.tar.xz')",
     " assert donor_receipt['archiveSHA256']==cfg['donorSHA256']==sha(donor.parent/'observations.tar.xz')\n"
     " completed=base/'json-ascii-character-b1790-20261126-repeat'\n"
     " complete_receipt=json.loads((completed/'archive-receipt.json').read_text())\n"
     " assert (completed/'candidate').resolve()==donor and complete_receipt['complete']\n"
     " assert complete_receipt['archiveSHA256']==cfg['completedDonorSHA256']==sha(completed/'observations.tar.xz')"),
    (" print(json.dumps(dict(freeBeforeLaunchBytes=shutil.disk_usage(base).free,expandedBytes=expanded)),flush=True)",
     " free=shutil.disk_usage(base).free\n"
     " assert free>=cfg['minimumAfterStageBytes'],free\n"
     " print(json.dumps(dict(freeBeforeLaunchBytes=free,expandedBytes=expanded)),flush=True)"),
    ('seconds=207','seconds=166'),
    ("   shutil.copyfile(p,root/'candidate'/p.name)",
     "   assert p.is_file() and p.resolve()==p\n"
     "   os.link(p,root/'candidate'/p.name)"))
compile(launcher, 'quiet.py', 'exec')
write(lab/'quiet.py', launcher)
shutil.copyfile(previous/'summarize-quiet.py', lab/'summarize-quiet.py')
print(read(quiet/'upload.json'))
