set -eu
export DOTNET_ROOT="$HOME/.dotnet"
export PATH="$DOTNET_ROOT:$PATH"
filter='Category!=Stress&(FullyQualifiedName~AdmissionFailureCommand|FullyQualifiedName~StackGuardScenario|FullyQualifiedName~BuiltinIterationCancellation|FullyQualifiedName~GovernedCursorAdmission|FullyQualifiedName~ZipNative)'
dotnet test tests/Lokad.Lython.PublicApi.Tests -c Release -f net10.0 --artifacts-path ../ubuntu --no-build --filter "$filter" > ../containment-ubuntu10.log 2>&1
tail -10 ../containment-ubuntu10.log
