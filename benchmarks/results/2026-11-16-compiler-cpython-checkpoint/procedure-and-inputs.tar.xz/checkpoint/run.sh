set -eu
root=/home/lokad/lython-bench-checks/compiler-cpython-b821-20261116
trap 'result=$?; printf "%s\n" "$result" > "$root/exit-code.txt"' EXIT
python3 "$root/collect.py"
