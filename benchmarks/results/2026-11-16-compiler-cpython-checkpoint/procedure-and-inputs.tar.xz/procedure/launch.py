from pathlib import Path
import ast,datetime,hashlib,json,shlex,subprocess,tarfile

r=Path(__file__).parent;q=r/'checkpoint';q.mkdir();old=r.parent/'patch-checkpoint-r421/checkpoint'
base=r.parent/'compiler-instruction-store-r424';head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
assert head.startswith('a2d20928') and not subprocess.check_output(['git','status','--porcelain'],text=True).strip()
proof=json.loads((base/'delivery/source-proof.json').read_text(encoding='utf-8'))
assert proof['commit']==head and proof['inputCount']==590 and proof['allInputsMatchAfterExplicitUTF8NewlineNormalization']
image=json.loads((base/'quiet/identity.json').read_text(encoding='utf-8'))['imageFiles']['candidate']
assert image['Lokad.Lython.dll']=='9d26d408ac591aba042f92106167a7cc1df8148b6fc26554f65fa667af5cb5f0'
catalog=json.loads((base/'catalog.json').read_text(encoding='utf-8'))
catalog['cases']=[next(c for c in catalog['cases'] if c['id']=='scripts.config-manifest.small')]
reports=json.loads((r.parent/'format-layout-r418/catalog.json').read_text(encoding='utf-8'))
catalog['cases'] += [next(c for c in reports['cases'] if c['id']==n) for n in ['scripts.report-render.format-method.large','scripts.report-render.large']]
for c in catalog['cases']:
    for n,k in [('sourceSha256','source'),('fixtureSha256','fixtureJson'),('expectedOutputSha256','expectedOutput')]:assert hashlib.sha256(c[k].encode()).hexdigest()==c[n]
(q/'representative.json').write_text(json.dumps(catalog,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
additional=base/'quiet/retrieved/additional.json'
root='/home/lokad/lython-bench-checks/compiler-cpython-b821-20261116';unit='lython-b821-compiler-cpython-20261116'
identity=dict(sourceRevision=head+'/frozen9d26d408',runtimeCommit=head,
    purpose='Refresh complete manifest compile/fresh and method-report warm with original f-string control against CPython after retained compiler storage/format consolidation. Not a causal source comparison.',
    coreSHA256={n:image['Lokad.Lython.dll'] for n in ['candidate','candidate-control']},
    auxiliaryFiles={n:h for n,h in image.items() if n!='Lokad.Lython.dll'},
    catalogSHA256=hashlib.sha256((q/'representative.json').read_bytes()).hexdigest(),
    additionalCatalogSHA256=hashlib.sha256(additional.read_bytes()).hexdigest(),
    qualification='Committed/pusheda2d20928;151internal/1011public focused eachactual11/10;590committed inputs verified;full43789371043active',publicationHeld=True)
(q/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8',newline='\n')
jobs=[['scripts.config-manifest.small','compile'],['scripts.config-manifest.small','compile-run'],['scripts.report-render.format-method.large','warm'],['scripts.report-render.large','warm']]
for n in ['collect.py','archive-owned.py','run.sh','retrieve.py','summarize.py']:
    s=(old/n).read_text(encoding='utf-8').replace('patch-cpython-b816-20261116','compiler-cpython-b821-20261116').replace('lython-b816-patch-cpython-20261116',unit).replace('B816','B821')
    if n=='collect.py':
        a=s.index('jobs=');b=s.index('\nenv =',a)
        s=s[:a]+'jobs='+repr(jobs)+"\ncases.update({c['id']:c for c in json.loads((root/'additional.json').read_text())['cases']})\nassert len(jobs)==4 and all(case in cases for case,lane in jobs)\n"+s[b:]
    if n.endswith('.py'):ast.parse(s)
    (q/n).write_text(s,encoding='utf-8',newline='\n')
with tarfile.open(q/'payload.tgz','w:gz') as t:
    for n in ['identity.json','representative.json','collect.py','archive-owned.py','run.sh']:t.add(q/n,arcname=n)
with tarfile.open(q/'payload.tgz') as t:size=sum(m.size for m in t if m.isfile())
source='/home/lokad/lython-bench-checks/compiler-store-b820-20261116'
c=dict(root=root,unit=unit,source=source,catalog=source+'/representative.json',
    sourceCatalogSHA256=hashlib.sha256((base/'catalog.json').read_bytes()).hexdigest(),additional=source+'/additional.json',
    identity=identity,retire=[],payloadBytes=(q/'payload.tgz').stat().st_size,
    payloadSHA256=hashlib.sha256((q/'payload.tgz').read_bytes()).hexdigest(),unpackedBytes=size)
(q/'config.json').write_text(json.dumps(c,indent=2)+'\n',encoding='utf-8',newline='\n')
code=(old/'launch-command.py').read_text(encoding='utf-8');a=code.index('c=');b=code.index(';b=Path(',a)
code=code[:a]+'c='+repr(c)+code[b:]
code=code.replace('lython-b816-fixtures','lython-b821-fixtures')
ast.parse(code);(q/'launch-command.py').write_text(code,encoding='utf-8',newline='\n')
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
p=subprocess.run(ssh+['python3 -c '+shlex.quote(code)],input=(q/'payload.tgz').read_bytes(),capture_output=True,timeout=45)
(q/'launch.log').write_bytes(p.stdout+p.stderr);assert p.returncode==0,(p.stdout+p.stderr).decode('utf-8','replace')
now=datetime.datetime.now(datetime.timezone.utc)
(q/'observe-not-before.json').write_text(json.dumps(dict(startedUTC=now.isoformat(),doNotObserveBeforeUTC=(now+datetime.timedelta(seconds=200)).isoformat(),ownerSeconds=240),indent=2)+'\n',encoding='utf-8',newline='\n')
print(p.stdout.decode('utf-8'),flush=True)
