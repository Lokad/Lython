from pathlib import Path
import hashlib,json,shutil,tarfile

r=Path(__file__).parent;q=r/'checkpoint';out=Path('benchmarks/results/2026-11-16-compiler-cpython-checkpoint');out.mkdir(exist_ok=True)
d=json.loads((q/'summary.json').read_text(encoding='utf-8'));receipt=json.loads((q/'archive-receipt.json').read_text(encoding='utf-8'))
assert d['complete'] and d['jobs']==4 and receipt['complete'] and receipt['allWorkersJoined']
assert hashlib.sha256((q/'observations.tgz').read_bytes()).hexdigest()==receipt['archiveSHA256']
for n in ['identity.json','summary.json','observations.tgz','archive-receipt.json','terminal-status.json']:shutil.copyfile(q/n,out/n)
shutil.copyfile('docs/BENCHMARKS.md',out/'prior-BENCHMARKS.md')
with tarfile.open(out/'procedure-and-inputs.tar.xz','w:xz') as a:
    for p in q.iterdir():
        if p.is_file() and p.name!='observations.tgz':a.add(p,arcname='checkpoint/'+p.name)
    for p in r.iterdir():
        if p.is_file():a.add(p,arcname='procedure/'+p.name)
    for n in ['representative.json','additional.json','cpython-worker.py']:a.add(q/'retrieved'/n,arcname='inputs/'+n)
    a.add(r.parent/'compiler-instruction-store-r424/delivery/source-proof.json',arcname='source-proof.json')
rows=[];evidence=[]
for x in d['timing']:
    phase={'warm':'warm Run','compile':'compilation only','compile-run':'compile and execute once'}[x['lane']]
    config=x['case']=='scripts.config-manifest.small'
    method=x['case']=='scripts.report-render.format-method.large'
    name='Configuration / six-helper manifest' if config else 'Report / '+('format method' if method else 'f-string')
    size='833 B inputs / 1,877 B source' if config else '1,024 records / 189,441 B JSON'
    m=x['medianMilliseconds'];ly=[m[n] for n in ['candidate','candidate-control']];py=[m[n] for n in ['CPython','CPython-control']]
    times=[f'{min(v):.3f}–{max(v):.3f}' for v in [ly,py]]
    ratio=f"{min(x['ratioRange']):.2f}–{max(x['ratioRange']):.2f}×"
    status=f"Diagnostic; spreads {x['lythonControlPercent']:.2f}/{x['cpythonControlPercent']:.2f}%; IQR ≤{x['maxIqrPercent']:.2f}%"
    rows.append(f'| {name} / {phase} | {size} | {times[0]} ms | {times[1]} ms | {ratio} | {status} |')
    evidence.append(f"| {name} / {phase} | {times[0]} | {times[1]} | {ratio} | {x['lythonControlPercent']:.2f}/{x['cpythonControlPercent']:.2f}% | {x['maxIqrPercent']:.2f}% |")
(out/'README.md').write_text('''# Current manifest and report CPython checkpoint

R425/B821,2026-11-16UTC. Runtime **a2d20928 / measured9d26d408** versus stock
**CPython3.13.16**. Committed source has590verified production/build inputs;
151internal/1,011public focused checks per actual.NET11/10 pass. Full43789371043
platform/stress/installed-package qualification is pending at capture. No source
edit, new adapter qualification or causal cross-collection speedup is claimed.

Reuse the existing complete six-helper configuration/manifest (833Binput,
1,877Bsource) and JSON-to-Markdown reports (1,024records/189,441B). No generated
normalizer in this external comparison. Sources, fixtures and independent output/
file goldens are unchanged; the actual additional-catalog method report matches
all four planned hashes. No framework, fixture or golden redesign.

| Workload / phase | Lython ms | CPython ms | Lython/CPython | L/P control spread | Max IQR |
| --- | ---: | ---: | ---: | ---: | ---: |
'''+'\n'.join(evidence)+f'''

All four process-median pairings, not confidence intervals. **{d['elapsedSeconds']:.3f}s**
for four jobs, two processes/engine,5s full-request warmups, five rotated approximately
0.5s batches. Manifest compilation's unchanged Lython control moves4.89%; report
IQRs reach4.50%. Keep all adverse observations and moving controls; exact ratios
are diagnostic. Source-pair improvements cannot be inferred from earlier collections.

Quiet Azure F4as_v7/Ubuntu24.04.4, four AMD EPYC9V45vCPUs/16GiB/no swap,
.NET11RC3 ordinary tiering/natural workstationGC and CPython GIL/GC.
Warm includes Run, mediated RAM I/O, complete stdout/file goldens and prior-result
cleanup; excludes compilation/startup, reset/protocol and final cache teardown.
Compilation includes public compile/compiled-owner disposal with no guest I/O.
Compile-to-result includes compilation, one execution and compiled-owner disposal.
Separate phase medians are not additive. Wider process CPU includes reset/protocol.
CPython native buffered files do not provide equivalent containment; this is whole
embedding cost, not isolated interpreter CPU. No startup, pending-I/O, contention,
heap/RSS or embedding-tail comparison.

This refreshes older manifest/report warm rows after format consolidation/compiler
storage. Method formatting retains a material warm gap; manifest fresh is closer.
Report compilation/fresh, other workloads and all historical uncertainty keep their
actual earlier revision labels. Do not infer regression-debt recovery or general
Python parity. Broader call/operand/collection/text/frontend work remains independent.

All source/image/catalog/golden/budget/quiet/Closed/exit/join/archive gates pass.
Persistent archive verifies under lease before teardown; no workers/RAM fixtures
remain. No retirement or floor change; current images/toolchains and254/252MiB
floors remain. Terminal cached forever; publication held.
[Summary/all controls](summary.json),[identity](identity.json),
[raw observations](observations.tgz),[procedure/inputs/source proof](procedure-and-inputs.tar.xz),
[previous guide](prior-BENCHMARKS.md),
[measured runtime source pair](../2026-11-16-compiler-instruction-store/README.md).
''',encoding='utf-8',newline='\n')
p=Path('docs/BENCHMARKS.md');s=p.read_text(encoding='utf-8')
prefixes=['| Configuration / six-helper manifest /','| Report / format method / warm Run |','| Report / f-string / warm Run |']
s='\n'.join(line for line in s.splitlines() if not any(line.startswith(t) for t in prefixes))+'\n'
needle='| --- | --- | ---: | ---: | ---: | --- |';assert s.count(needle)==1
s=s.replace(needle,needle+'\n'+'\n'.join(rows),1)
a=s.index('**Report rows:');b=s.index('Measured **2026-11-15 UTC**',a)
s=s[:a]+'''**Manifest phases and report warm rows: a2d20928 / measured9d26d408**,2026-11-16UTC;
[current checkpoint](../benchmarks/results/2026-11-16-compiler-cpython-checkpoint/README.md)
passes all measurement/cleanup gates. Full platform/stress/installed-package
qualification is pending. Method report remains1.59–1.65×CPython warm; manifest
fresh is1.085–1.092×. Manifest compilation control moves4.89%, report IQRs reach4.50%.
**Report compilation/fresh retain58eeea6f/frozen9d071eba** and their
[earlier checkpoint](../benchmarks/results/2026-11-15-layout-cpython-checkpoint/README.md),
with [full runtime qualification](../benchmarks/results/2026-11-15-method-format-layout/delivery/README.md).
All preceding warm observations remain in the linked history; no source-change
speedup or recovery is inferred across collections.

''' +s[b:]
s=s.replace('file search and configuration:2865f619/frozen55ba4c8a','file search:2865f619/frozen55ba4c8a')
p.write_text(s,encoding='utf-8',newline='\n')
p=Path('benchmarks/EXPERIMENTS.md');s=p.read_text(encoding='utf-8');s+='\n\n[R425/B821 current manifest/report CPython phases](results/2026-11-16-compiler-cpython-checkpoint/README.md): a2d20928/9d26d408 versusCPython3.13.16; four jobs136.664s/all gates. Manifest compile1.22–1.28×/fresh1.085–1.092×; method report warm1.59–1.65×/f-string1.18–1.20×. Manifest control4.89%, report IQR≤4.50%retained. Phases/I/O/cleanup/source labels explicit; no causal source gain. Full43789371043pending; broader objective active/publication held.\n';p.write_text(s,encoding='utf-8',newline='\n')
print('\n'.join(rows));print('Current useful phases and all original controls archived; no causal speedup inferred.')
