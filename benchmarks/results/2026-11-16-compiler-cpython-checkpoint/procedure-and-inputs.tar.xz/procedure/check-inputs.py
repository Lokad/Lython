from pathlib import Path
import json
r=Path(__file__).parent/'checkpoint'
a=json.loads((r/'retrieved/additional.json').read_text(encoding='utf-8'))
b=json.loads((r/'representative.json').read_text(encoding='utf-8'))
name='scripts.report-render.format-method.large'
x=next(c for c in a['cases'] if c['id']==name);y=next(c for c in b['cases'] if c['id']==name)
keys=['sourceSha256','fixtureSha256','expectedOutputSha256','expectedFilesSha256']
assert all(x[k]==y[k] for k in keys),(x,y)
print('Actual additional-catalog method report matches all planned source/fixture/output/file hashes.')
