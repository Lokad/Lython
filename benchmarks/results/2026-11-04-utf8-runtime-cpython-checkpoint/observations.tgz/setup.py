from pathlib import Path
import json,hashlib,shutil
root=Path('/home/lokad/lython-bench-checks/runtime-cpython-b214-20261104')
(root/'candidate').symlink_to(Path('/home/lokad/lython-bench-checks/search-window-b213-20261104/candidate'),target_is_directory=True)
(root/'reference').symlink_to(Path('/home/lokad/lython-bench-checks/lexical-module-b211-20261104/candidate'),target_is_directory=True)
i=json.loads((root/'identity.json').read_text(encoding='utf-8'))
for label in ('candidate','control','reference'):
 folder=root/('candidate' if label=='control' else label)
 assert hashlib.sha256((folder/'Lokad.Lython.dll').read_bytes()).hexdigest()==i['coreSHA256'][label]
assert shutil.disk_usage(root).free>64*1024*1024
