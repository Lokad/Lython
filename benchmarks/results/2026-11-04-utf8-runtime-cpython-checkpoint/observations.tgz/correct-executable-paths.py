from pathlib import Path
import contextlib,fcntl,hashlib,importlib.util,json,os,shutil,subprocess,tempfile
root=Path('/home/lokad/lython-bench-checks/runtime-cpython-b214-20261104')
spec=importlib.util.spec_from_file_location('protocol',root/'cpython-worker.py');protocol=importlib.util.module_from_spec(spec);spec.loader.exec_module(protocol)
dotnet='/home/lokad/lython-bench-toolchains/dotnet/11.0.100-rc.3.26522.148/dotnet';env=os.environ.copy();env['DOTNET_ROOT']=str(Path(dotnet).parent);env['TMPDIR']='/dev/shm'
identity=json.loads((root/'identity.json').read_text(encoding='utf-8'))
def ready(label):
 with tempfile.TemporaryDirectory(prefix='lython-comparison-files-',dir='/dev/shm') as work:
  p=subprocess.Popen([dotnet,str(root/label/'Lokad.Lython.Benchmarks.dll'),'--compare','worker','--catalog',str(root/'representative.json')],cwd=work,env=env,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
  try:
   v=protocol.read_frame(p.stdout);assert v and v['status']=='Ready'
   protocol.write_frame(p.stdin,dict(protocolVersion=2,requestId=1,operation='quit'))
   assert protocol.read_frame(p.stdout)['status']=='Closed';assert p.wait(timeout=5)==0
   return v
  finally:
   if p.poll() is None:p.kill();p.wait()
   p.stdin.close();p.stdout.close();p.stderr.close()
with open('/home/lokad/lython-bench-checks/comparison-vm.lock','w') as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 failed=root/'initial-identity-failure';(root/'confirmation').rename(failed)
 before={label:ready(label) for label in ('candidate','reference')};(failed/'initial-ready-identities.json').write_text(json.dumps(before,indent=2)+'\n',encoding='utf-8')
 for label in ('candidate','reference'):
  folder=root/label;assert folder.is_symlink();old=root/(label+'-initial-link');folder.rename(old);folder.mkdir()
  for f in old.iterdir():
   if f.name in ('Lokad.Lython.Benchmarks.dll','Lokad.Lython.Benchmarks.deps.json','Lokad.Lython.Benchmarks.runtimeconfig.json'):shutil.copyfile(f,folder/f.name)
   else:(folder/f.name).symlink_to(f.resolve(),target_is_directory=f.is_dir())
 after={label:ready(label) for label in ('candidate','reference')}
 for label,v in after.items():
  core=next(l for l in v['libraries'] if Path(l['path']).name=='Lokad.Lython.dll')
  assert core['sha256'].lower()==identity['coreSHA256'][label]
 (root/'corrected-ready-identities.json').write_text(json.dumps(after,indent=2)+'\n',encoding='utf-8')
 for label,v in before.items():
  c=next(l for l in v['libraries'] if Path(l['path']).name=='Lokad.Lython.dll');print('Original',label,c['sha256'])
 print('Copied only executable/deps/runtimeconfig bytes locally into each role directory; all final loaded cores verified. No timed job occurred in original launch.')
