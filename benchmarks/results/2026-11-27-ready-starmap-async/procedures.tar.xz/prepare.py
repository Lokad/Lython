from pathlib import Path
from hashlib import sha256
from statistics import median
import json
import os
import shutil
import subprocess

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
previous=lab.with_name('shared-pending-zip-20261127')/'local'
image_base=lab.with_name('current-shipment-cpu-20261127')/'comparison/quiet'
run=lab/'local'
run.mkdir()
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
def sha(path):return sha256(path.read_bytes()).hexdigest()
def write(path,data):path.write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
def manifest(directory):return {p.name:sha(p) for p in directory.iterdir()}
core='Lokad.Lython.dll'
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()
assert head.startswith('6c459bbd8')
assert not subprocess.check_output(['git','diff','777750e6b',head,'--','src'],cwd=repo)
for area, name in (('src','candidate.patch'),('tests','regression.patch')):
    (run/name).write_bytes(subprocess.check_output(['git','diff','--binary','HEAD','--',area],cwd=repo))
pin=read(image_base/'identity.json')
assert pin['sourceRevision'].startswith('777750e6b')
reference_files=pin['imageFiles']['candidate']
assert len(reference_files)==32 and manifest(image_base/'candidate')==reference_files
new=repo/'tests/Lokad.Lython.PublicApi.Tests/bin/Release/net11.0'/core
assert sha(new)==sha(repo/'src/Lokad.Lython/bin/Release/net11.0'/core)
images={}
for role in ('reference','candidate'):
    target=run/role
    shutil.copytree(image_base/'candidate',target)
    if role=='candidate':shutil.copyfile(new,target/core)
    images[role]=manifest(target)
assert images['reference']==reference_files
assert [p for p,x in reference_files.items() if x!=images['candidate'][p]]==[core]
file_fed='diagnostic.shipment-file-fed-map'
short='diagnostic.shipment-starmap-short-lists'
wide='diagnostic.shipment-starmap-wide-lists'
bound='diagnostic.shipment-bound-starmap'
catalog=read(previous/'representative.json')
assert set(row['id'] for row in catalog['cases'])=={file_fed,short,wide,bound}
write(run/'representative.json',catalog)
collector=(previous/'collect.py').read_text(encoding='utf-8').replace('lython-shared-pending-zip-fixture-', 'lython-ready-starmap-fixture-')
compile(collector,'collect.py','exec')
(run/'collect.py').write_text(collector,encoding='utf-8',newline='\n')
shutil.copyfile(previous/'run.sh',run/'run.sh')
assert b'\r' not in (run/'run.sh').read_bytes()
shutil.copyfile(image_base/'cpython-worker.py',run/'cpython-worker.py')
assert sha(run/'cpython-worker.py')==pin['cpythonWorkerSHA256']
write(run/'jobs.json',{'warm':[[wide,'warm'],[file_fed,'warm-async'],[bound,'warm-async'],[wide,'warm-async']]})
identity=dict(sourceRevision=head,sourcePatchSHA256=sha(run/'candidate.patch'),imageFiles=images,cpythonWorkerSHA256=pin['cpythonWorkerSHA256'],
              coreSHA256={role+suffix:im[core] for role,im in images.items() for suffix in ('','-control')},
              catalogs={name:{'sha256':sha(run/name)} for name in ('representative.json','jobs.json')},
              referenceCoreSourceRevision=pin['sourceRevision'], comparisonHostRevision=pin['comparisonHostRevision'],
              purpose='Return ready async starmap rows directly, with wide sync and file-fed async controls.')
write(run/'identity.json',identity)

sdk=Path.home()/'.dotnet11';dotnet=sdk/'dotnet.exe'
env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk))
for role, im in images.items():
    report=run/f'{role}-verify.json'
    subprocess.run([dotnet,run/role/'Lokad.Lython.Benchmarks.dll','--compare','verify','--catalog',run/'representative.json','--dotnet',dotnet,
                    '--python','C:/Python313/python.exe','--python-worker',run/'cpython-worker.py','--out',report],cwd=repo,env=env,check=True,timeout=60)
    checked=read(report)
    assert checked['caseCount']==4 and checked['state']=='Completed'
    assert checked['catalogSha256']==identity['catalogs']['representative.json']['sha256']
    assert checked['launched']['library']['sha256']==im[core]
    diagnostic=run/f'{role}-allocated'
    shutil.copytree(run/role,diagnostic)
    for path in (previous/'candidate-allocated').glob('ValidatedAllocation*'):
        shutil.copyfile(path,diagnostic/path.name)
    assert all(sha(diagnostic/p)==h for p,h in im.items())
rows=[]
for mode in ('sync','async'):
    for case in catalog['cases']:case['runAsync']=mode=='async'
    selected=run/f'{mode}-allocation-catalog.json'
    write(selected,catalog)
    values=[]
    for role in ('reference','candidate'):
        diagnostic=run/f'{role}-allocated'
        report=run/f'{role}-{mode}-allocation.json'
        subprocess.run([dotnet,diagnostic/'ValidatedAllocation.dll',diagnostic,selected,report],env=env,check=True,timeout=75)
        values.append(read(report)['rows'])
    for before,after in zip(*values,strict=True):
        assert before['id']==after['id'] and before['sharedBudgetBaselineRestored'] and after['sharedBudgetBaselineRestored']
        row=dict(case=before['id'],mode=mode,clr=[median(r['allocatedBytesPerInvocation']) for r in (before,after)],peak=[r['peakExecutionMemoryBytes'] for r in (before,after)])
        rows.append(row)
        print(row,flush=True)
write(run/'allocation-summary.json',rows)
