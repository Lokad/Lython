set -eu
source_root=/mnt/d/code/Lython
target_root="$HOME/lython-starmap-rows-8066Vm"
test -d "$target_root"
for file in src/Lokad.Lython/Runtime/PyItertools.Transforms.cs; do
    cp -- "$source_root/$file" "$target_root/$file"
    cmp -- "$source_root/$file" "$target_root/$file"
done
cd "$target_root"
filter='Category!=Stress&(FullyQualifiedName~StarmapMaterializationParity|FullyQualifiedName~DelayedHostComposition|FullyQualifiedName~BuiltinIteratorSequenceFunction|FullyQualifiedName~IteratorAdapter|FullyQualifiedName~NativeGenerator|FullyQualifiedName~CallablePacketOwnership|FullyQualifiedName~IterationWorkspaceLifetime)'
for suite in Lokad.Lython.PublicApi.Tests Lokad.Lython.Tests; do
    "$HOME/.dotnet/dotnet" test "tests/$suite/$suite.csproj" -c Release -f net10.0 --no-restore --filter "$filter"
done
