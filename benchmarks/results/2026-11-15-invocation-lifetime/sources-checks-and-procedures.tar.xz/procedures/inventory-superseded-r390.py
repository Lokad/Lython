from pathlib import Path
import hashlib,json,subprocess,tarfile

out=Path(__file__).parent/'invocation-lifetime-r390'
proofs=[]
for archive,member,source in [
 ('benchmarks/results/2026-11-14-range-iteration-stage/refined/sources-checks-and-observations.tar.xz','refined/candidate-core.dll','range-checkpoint-b747-20261114/candidate/Lokad.Lython.dll'),
 ('benchmarks/results/2026-11-14-closed-range-construction/native-only/sources-checks-and-observations.tar.xz','candidate-core.dll','native-range-complete-b742-20261114/candidate/Lokad.Lython.dll')]:
    path=Path(archive);blob=subprocess.check_output(['git','show','HEAD:'+archive]);assert blob==path.read_bytes()
    with tarfile.open(path)as tar:core=tar.extractfile(member).read()
    proofs.append(dict(archive=archive,archiveSHA256=hashlib.sha256(blob).hexdigest(),member=member,coreSHA256=hashlib.sha256(core).hexdigest(),bytes=len(core),source=source))
code=r'''from pathlib import Path
import fcntl,hashlib,json,os,shutil,stat,subprocess
proofs=PROOFS
base=Path('/home/lokad/lython-bench-checks').resolve();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
with(base/'comparison-vm.lock').open('a')as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record|[p]ython3.*cpython-worker.py'],capture_output=True).returncode==1
 assert not any(os.path.ismount(p)for p in base.glob('*/guest-fixtures'))
 result=[]
 for proof in proofs:
  source=base/proof['source'];assert source.resolve()==source and sha(source)==proof['coreSHA256']
  found=subprocess.check_output(['find',str(base),'-xdev','-samefile',str(source),'-type','f','-print'],text=True).splitlines()
  paths=[Path(p)for p in found];metadata=[p.lstat()for p in paths]
  assert len(paths)==source.stat().st_nlink
  assert all(p.resolve()==p and p.is_relative_to(base)and stat.S_ISREG(m.st_mode)and m.st_uid==os.getuid()and m.st_size==proof['bytes']for p,m in zip(paths,metadata))
  assert all(sha(p)==proof['coreSHA256']for p in paths)
  result.append(dict(custody=proof,paths=[str(p.relative_to(base))for p in paths],links=len(paths)))
 print(json.dumps(dict(freshIdleLease=True,freeBytes=shutil.disk_usage(base).free,selected=result,predictedReclaimedBytes=sum(p['bytes']for p in proofs),noMutation=True)))
'''.replace('PROOFS',repr(proofs))
(out/'superseded-inventory-command.py').write_text(code,encoding='utf-8',newline='\n')
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
result=subprocess.run(ssh+['python3 -'],input=code,capture_output=True,text=True,encoding='utf-8',timeout=60)
(out/'superseded-inventory.log').write_text(result.stdout+result.stderr,encoding='utf-8')
assert result.returncode==0,result.stderr
(out/'superseded-inventory.json').write_text(result.stdout,encoding='utf-8')
print(result.stdout)
