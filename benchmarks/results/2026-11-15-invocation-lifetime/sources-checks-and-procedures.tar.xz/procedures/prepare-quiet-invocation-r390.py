from pathlib import Path
import ast,hashlib,json,tarfile

notes=Path(__file__).parent;r=notes/'invocation-lifetime-r390';out=r/'quiet';out.mkdir(exist_ok=False)
old=notes/'hosting-whole-r388';frozen=json.loads((r/'candidate-identity.json').read_text(encoding='utf-8'))
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert all(sha(name)==h for name,h in frozen['sources'].items())
local=json.loads((r/'local-screen.json').read_text(encoding='utf-8'));assert local['complete']and local['allUsersJoined']
remote_old='hosting-whole-b775-20261115';remote_new='invocation-lifetime-b777-20261115'
unit_old='lython-b775-hosting-whole-20261115';unit_new='lython-b777-invocation-lifetime-20261115'
config=json.loads((old/'config.json').read_text(encoding='utf-8'));config.update(root=config['root'].replace(remote_old,remote_new),unit=unit_new)
identity=config['identity'];identity.update(sourceRevision='R390 uncommitted prototype/frozen'+frozen['coreSHA256']['candidate'],purpose='Whole scheduled invocation lifetime versus qualified810379be: complete async captured text/file and unchanged synchronous text control; no portable CPU claim.',coreSHA256={label:frozen['coreSHA256']['candidate'if label.startswith('candidate')else'reference']for label in ['candidate','candidate-control','reference','reference-control']},qualification='Prototype focused Release actual.NET11/10:193public/92internal each; full platform/stress/package pending if retained.',roleMeaning={'candidate':'R390','candidate-control':'R390','reference':'810379be','reference-control':'810379be'})
(out/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8',newline='\n')
prospective=dict(question='Does eliminating the outer async ownership continuation reduce complete-script elapsed/wider CPU with unchanged synchronous controls?',cases=[['scripts.text-summary-helpers.nonlocal-counter.large','warm-async'],['scripts.file-search.large.protected','warm-async'],['scripts.text-summary-helpers.nonlocal-counter.large','warm']],warmupSeconds=5,capturedWarmupSeconds=12,targetRequestSeconds=.5,rounds=5,ownerSeconds=240,acceptance='Existing identities/goldens/quiet/balances/Closed/join/archive gates. Retain every moving/adverse control; separate architecture and CPU; short-case/source debts explicit.',stoppingCriterion='Finish three jobs; retain/refine/withdraw the invocation lifetime change. Qualify full delivery if retained; do not repeat unchanged qualification.',storage='One frozen core upload, existing immutable auxiliaries/catalog, retire only the two exact obsolete range images proved in committed archives; preserve current7161/8fbf and254/252MiBfloors.',publicationHeld=True)
(out/'prospective.json').write_text(json.dumps(prospective,indent=2)+'\n',encoding='utf-8',newline='\n')
for name in ['collect.py','archive-owned.py','run.sh','retrieve.py','summarize.py']:
    text=(old/name).read_text(encoding='utf-8').replace(remote_old,remote_new).replace(unit_old,unit_new).replace('B775','B777')
    if name=='collect.py':
        start=text.index('\njobs=')+1;end=text.index('\nenv =',start)
        text=text[:start]+'jobs='+repr(prospective['cases'])+'\nassert len(jobs)==3 and all(case in cases for case,lane in jobs)\n'+text[end:]
        text=text.replace("label, case, ('warm-async' if label.startswith('candidate') else 'warm'), 0",'label, case, lane, 0')
        text=text.replace("str(root/'candidate/Lokad.Lython.Benchmarks.dll')","str(root/('candidate' if label.startswith('candidate') else 'reference')/'Lokad.Lython.Benchmarks.dll')")
    elif name=='summarize.py':
        text=text.replace("assert job['executionLanes'] == {'reference': 'warm', 'reference-control': 'warm', 'candidate': 'warm-async', 'candidate-control': 'warm-async'}", "assert set(job['executionLanes'].values()) == {job['lane']}")
        text=text.replace("row = dict(case=job['case'],", "row = dict(case=job['case'], lane=job['lane'],")
        text=text.replace('elapsedAsyncOverSyncPercent','candidateOverReferenceElapsedPercent').replace('widerCpuAsyncOverSyncPercent','candidateOverReferenceWiderCpuPercent').replace('syncControlPercent','referenceControlPercent').replace('asyncControlPercent','candidateControlPercent').replace('runtimeChanged=False','runtimeChanged=True')
    if name.endswith('.py'):ast.parse(text)
    (out/name).write_text(text,encoding='utf-8',newline='\n')
with tarfile.open(out/'payload.tgz','w:gz')as archive:
    for name in ['identity.json','prospective.json','collect.py','archive-owned.py','run.sh']:archive.add(out/name,arcname=name)
    archive.add(r/'candidate-core.dll',arcname='candidate/Lokad.Lython.dll')
with tarfile.open(out/'payload.tgz')as archive:unpacked=sum(m.size for m in archive.getmembers())
config.update(payloadBytes=(out/'payload.tgz').stat().st_size,payloadSHA256=sha(out/'payload.tgz'),unpackedBytes=unpacked,inventory=json.loads((r/'superseded-inventory.json').read_text(encoding='utf-8')))
(out/'config.json').write_text(json.dumps(config,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps(dict(prepared=True,jobs=3,payloadBytes=config['payloadBytes'],unpackedBytes=unpacked,coreSHA256=identity['coreSHA256'])))
