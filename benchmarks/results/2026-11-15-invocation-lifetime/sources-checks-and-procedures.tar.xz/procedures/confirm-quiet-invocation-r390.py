from pathlib import Path
import ast,base64,datetime,hashlib,json,subprocess,tarfile

parent=Path(__file__).parent/'invocation-lifetime-r390';old=parent/'quiet';r=parent/'confirmation';r.mkdir(exist_ok=False)
assert json.loads((old/'terminal-status.json').read_text(encoding='utf-8'))['receipt']['complete']
config=json.loads((old/'config.json').read_text(encoding='utf-8'))
oldroot='invocation-lifetime-b777-20261115';newroot='invocation-confirm-b778-20261115'
oldunit='lython-b777-invocation-lifetime-20261115';newunit='lython-b778-invocation-confirm-20261115'
config.update(root=config['root'].replace(oldroot,newroot),sourceRoot=config['root'],unit=newunit)
config.pop('inventory')
identity=config['identity'];identity['purpose']='One justified captured-text confirmation after reference process spread6.56% and candidate spread4.03%; unchanged frozen cores, original adverse observations retained.'
(r/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8',newline='\n')
prospective=dict(question=identity['purpose'],case='scripts.text-summary-helpers.nonlocal-counter.large',lane='warm-async',independentProcessesPerSource=2,warmupSeconds=12,targetRequestSeconds=.5,rounds=5,ownerSeconds=150,stoppingCriterion='Finish this bounded confirmation, combine interpretation with original controls and file/sync evidence, then retain/refine/withdraw. No cherry-picking or automated restart.',noNewImageOrCatalogUpload=True,publicationHeld=True)
(r/'prospective.json').write_text(json.dumps(prospective,indent=2)+'\n',encoding='utf-8',newline='\n')
for name in ['collect.py','archive-owned.py','run.sh','retrieve.py','summarize.py']:
    text=(old/name).read_text(encoding='utf-8').replace(oldroot,newroot).replace(oldunit,newunit).replace('B777','B778')
    if name=='collect.py':
        start=text.index('\njobs=')+1;end=text.index('\nenv =',start)
        text=text[:start]+"jobs=[['scripts.text-summary-helpers.nonlocal-counter.large','warm-async']]\nassert len(jobs)==1 and all(case in cases for case,lane in jobs)\n"+text[end:]
        text=text.replace("< 180, 'Reserve60seconds", "< 90, 'Reserve60seconds")
    elif name in ['archive-owned.py','summarize.py']:text=text.replace('== 3','== 1').replace('==3','==1').replace('jobs=3','jobs=1')
    elif name=='retrieve.py':text=text.replace("['jobs']==3","['jobs']==1").replace('<240','<150')
    if name.endswith('.py'):ast.parse(text)
    (r/name).write_text(text,encoding='utf-8',newline='\n')
with tarfile.open(r/'payload.tgz','w:gz')as archive:
    for name in ['identity.json','prospective.json','collect.py','archive-owned.py','run.sh']:archive.add(r/name,arcname=name)
with tarfile.open(r/'payload.tgz')as archive:unpacked=sum(m.size for m in archive.getmembers())
config.update(payloadBytes=(r/'payload.tgz').stat().st_size,payloadSHA256=hashlib.sha256((r/'payload.tgz').read_bytes()).hexdigest(),unpackedBytes=unpacked)
(r/'config.json').write_text(json.dumps(config,indent=2)+'\n',encoding='utf-8',newline='\n')
code=r'''from pathlib import Path
import ast,fcntl,hashlib,io,json,os,shutil,subprocess,sys,tarfile
config=CONFIG
base=Path('/home/lokad/lython-bench-checks').resolve();root=Path(config['root']);source=Path(config['sourceRoot']);sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert root.parent==base and not root.exists()and source.parent==base and source.resolve()==source
with(base/'comparison-vm.lock').open('a')as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record|[p]ython3.*cpython-worker.py'],capture_output=True).returncode==1
 assert not(source/'guest-fixtures').exists()and(source/'exit-code.txt').read_text().strip()=='0'and json.loads((source/'archive-receipt.json').read_text())['complete']
 for role in ['candidate','reference']:
  assert sha(source/role/'Lokad.Lython.dll')==config['identity']['coreSHA256'][role]
  for name,h in config['identity']['auxiliaryFiles'].items():assert sha(source/role/name)==h
 assert sha(source/'representative.json')==config['identity']['catalogSHA256']
 payload=sys.stdin.buffer.read(config['payloadBytes']+1)
 assert len(payload)==config['payloadBytes']and hashlib.sha256(payload).hexdigest()==config['payloadSHA256']
 before=shutil.disk_usage(base).free;assert before>254*1024*1024+config['unpackedBytes']+32768
 root.mkdir()
 with tarfile.open(fileobj=io.BytesIO(payload),mode='r:gz')as archive:archive.extractall(root,filter='data')
 for role in ['candidate','reference']:
  (root/role).mkdir()
  for name in [*config['identity']['auxiliaryFiles'],'Lokad.Lython.dll']:os.link(source/role/name,root/role/name)
 os.link(source/'representative.json',root/'representative.json');os.link(source/'cpython-worker.py',root/'cpython-worker.py')
 for name in ['collect.py','archive-owned.py']:ast.parse((root/name).read_text())
 subprocess.run(['/bin/sh','-n',str(root/'run.sh')],check=True)
 fixture=root/'guest-fixtures';fixture.mkdir();assert shutil.disk_usage(base).free>254*1024*1024
 (root/'space-preflight.json').write_text(json.dumps(dict(beforeFreeBytes=before,afterFreeBytes=shutil.disk_usage(base).free,noNewImageOrCatalogUpload=True,noRetirement=True,floorsUnchanged=True))+chr(10))
 subprocess.run(['sudo','-n','mount','-t','tmpfs','-o','size=128m,mode=0700,uid=lokad,gid=lokad','lython-b778-fixtures',str(fixture)],check=True)
try:subprocess.run(['sudo','-n','systemd-run','--unit='+config['unit'],'--property=User=lokad','--property=WorkingDirectory='+str(root),'--property=RuntimeMaxSec=150','--property=TimeoutStopSec=30','--property=KillMode=control-group','/bin/sh',str(root/'run.sh')],check=True)
except BaseException:
 subprocess.run(['sudo','-n','umount',str(fixture)],check=True);fixture.rmdir();raise
print(subprocess.check_output(['systemctl','show',config['unit']+'.service','--property=ActiveState,MainPID,RuntimeMaxUSec'],text=True))
'''.replace('CONFIG',repr(config))
ast.parse(code);(r/'launch-command.py').write_text(code,encoding='utf-8',newline='\n')
command="python3 -c 'import base64;exec(base64.b64decode(\""+base64.b64encode(code.encode()).decode()+"\"))'"
now=datetime.datetime.now(datetime.timezone.utc);(r/'launch-attempt.json').write_text(json.dumps(dict(attemptedUTC=now.isoformat(),neverAutomaticallyRelaunch=True))+'\n',encoding='utf-8')
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
result=subprocess.run(ssh+[command],input=(r/'payload.tgz').read_bytes(),capture_output=True,timeout=60)
(r/'launch.log').write_bytes(result.stdout+result.stderr);assert result.returncode==0,(result.stdout+result.stderr).decode('utf-8')
now=datetime.datetime.now(datetime.timezone.utc);(r/'observe-not-before.json').write_text(json.dumps(dict(startedUTC=now.isoformat(),doNotObserveBeforeUTC=(now+datetime.timedelta(seconds=90)).isoformat(),ownerSeconds=150),indent=2)+'\n',encoding='utf-8',newline='\n')
print(result.stdout.decode('utf-8'));print('Earliest observation',(now+datetime.timedelta(seconds=90)).isoformat(),flush=True)
