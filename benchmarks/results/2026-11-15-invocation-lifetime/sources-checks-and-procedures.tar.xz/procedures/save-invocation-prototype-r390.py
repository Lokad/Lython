from pathlib import Path
import hashlib,json,shutil,subprocess,tarfile

notes=Path(__file__).parent;r=notes/'invocation-lifetime-r390'
target=Path('benchmarks/results/2026-11-15-invocation-lifetime');target.mkdir(exist_ok=False)
identity=json.loads((r/'candidate-identity.json').read_text(encoding='utf-8'))
assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==h for p,h in identity['sources'].items())
decision=dict(status='prototype',coreSHA256=identity['coreSHA256'],runtimeCommitted=False,
              simplification='One scheduled invocation lifetime owns setup, execution and cleanup; removes outer ownership continuation and old faulted-cancellation relay treatment. Caller publication stays asynchronous.',
              focusedRelease='193public/92internal each actual.NET11/10 pass, including genuine suspension, first refusal, funded cleanup, context, managed stack and owner-creation faults/cancellation.',
              initialQuiet='Async file elapsed -.40..-4.01%, wider CPU -10.77..-12.90%. Text -.24..+10.59%elapsed with6.56%reference/4.03%candidate spread. Unchanged sync text +.05..+1.44%elapsed.',
              confirmation='Same frozen images, fresh text processes: elapsed .0003..+8.76%, wider CPU -4.28..+6.75%; candidate spread7.11%. Original adverse results preserved.',
              conclusion='No general speedup proved. Favorable file wider CPU, unresolved text cost/process variation. Neither promote nor reject on unstable controls alone.',
              next='Use the existing complete-job shared-process driver for one bounded text method control: same CoreLib/hash witness, distinct images and unchanged reference control. Hash variation is a source-supported hypothesis, not a demonstrated cause. Decide retain/refine/withdraw before full delivery qualification.',
              publicCompatibility='Python and public cancellation status/token retained. Host scope setup moves to captured-context startup worker; no thread affinity promised. Internal relay cancellation state now canceled.',
              preserved='No new dispatcher/options/scheduler. Genuine I/O releases startup worker; all users/cleanup finish before disposal. Shared admission, retained results, terminal refusal and managed stack unchanged.',
              fullQualificationPending=True,publicationHeld=True)
(r/'decision.json').write_text(json.dumps(decision,indent=2)+'\n',encoding='utf-8',newline='\n')
for name in ['candidate-identity.json','local-screen.json','decision.json','focused-checks.json','focused-checks-net10.json']:
    shutil.copyfile(r/name,target/name)
for group in ['quiet','confirmation']:
    source=r/group;dest=target/group;dest.mkdir()
    status=json.loads((source/'terminal-status.json').read_text(encoding='utf-8'));receipt=status['receipt']
    assert receipt['complete']and not status['remainingWorkers']and not status['remainingTrace']
    assert hashlib.sha256((source/'observations.tgz').read_bytes()).hexdigest()==receipt['archiveSHA256']
    for name in ['summary.json','prospective.json','archive-receipt.json','terminal-status.json','observations.tgz']:
        shutil.copyfile(source/name,dest/name)
patch=subprocess.check_output(['git','diff','--','src/Lokad.Lython/Public/LythonCompiledScript.cs','src/Lokad.Lython/Runtime/ExecutionThreads.cs','tests/Lokad.Lython.Tests/AsyncExecutionThreadTests.cs'])
(r/'implementation.patch').write_bytes(patch)
with tarfile.open(target/'sources-checks-and-procedures.tar.xz','w:xz')as archive:
    names=['candidate-core.dll','candidate-sources.tar.xz','candidate-identity.json','implementation.patch',
           'LythonCompiledScript.before.cs','ExecutionThreads.before.cs','AsyncExecutionThreadTests.before.cs',
           'probe-build.log','probe-build-net10.log','public-net11.log','internal-net11.log','public-net10.log','internal-net10.log',
           'focused-checks.json','focused-checks-net10.json','local-screen.py','superseded-inventory-command-attempt-1.py',
           'superseded-inventory-attempt-1.log','superseded-inventory-command.py','superseded-inventory.log','superseded-inventory.json','inventory-command.py']
    for name in names:archive.add(r/name,arcname=name)
    for group in ['quiet','confirmation']:
        for name in ['config.json','launch-command.py','launch-attempt.json','launch.log','retrieve.py','summarize.py','observe-not-before.json']:
            archive.add(r/group/name,arcname=group+'/'+name)
    for name in ['check-invocation-lifetime-r390.py','check-net10-invocation-r390.py','freeze-invocation-r390.py','inventory-invocation-r390.py','inventory-superseded-r390.py','prepare-quiet-invocation-r390.py','launch-quiet-invocation-r390.py','confirm-quiet-invocation-r390.py','save-invocation-prototype-r390.py']:
        archive.add(notes/name,arcname='procedures/'+name)
print(json.dumps(dict(saved=str(target),status='prototype',core=identity['coreSHA256']['candidate'],unchangedSourcesVerified=589,allVmUsersJoined=True,fullQualificationPending=True)))
