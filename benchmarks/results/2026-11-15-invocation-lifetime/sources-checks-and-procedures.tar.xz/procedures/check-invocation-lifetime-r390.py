from pathlib import Path
import json
import subprocess
import time

root=Path.cwd();out=Path(__file__).parent/'invocation-lifetime-r390'
dotnet='C:/Users/JoannesVermorel/.dotnet11/dotnet.exe'
public='|'.join('FullyQualifiedName~'+name for name in ['AsyncInvocationOwnershipTests','AsyncExecutionWorkerLifetimeTests','ExecutionThreadContextTests','AsyncMidFlightCancellationTests','GovernedHostLifetimeTests','GovernedAdmissionPreflightTests','AdmissionFailureCommandTests','AsyncFunctionHostingTests','BoundMethodAsyncLifetimeTests','AsyncBoundaryContractTests','CooperativeCancellationTests','GovernedMemoryContractTests','StackGuardScenarioTests'])
internal='|'.join('FullyQualifiedName~'+name for name in ['AsyncExecutionThreadTests','AsyncExecutableFunctionTests','AsyncStructuralAmbientTests','StructuralGuardAsyncIsolationTests','CompletedHelperCallOwnershipTests','DeferredFunctionOwnershipTests','FunctionWorkspaceOwnershipTests','StorageOwnershipBalanceTests'])
jobs=[('probe-build',[dotnet,'build','tools/LythonProbe/LythonProbe.csproj','-c','Release','-f','net11.0','--no-restore']),
      ('public-net11',[dotnet,'test','tests/Lokad.Lython.PublicApi.Tests/Lokad.Lython.PublicApi.Tests.csproj','-c','Release','-f','net11.0','--no-restore','--filter',public]),
      ('internal-net11',[dotnet,'test','tests/Lokad.Lython.Tests/Lokad.Lython.Tests.csproj','-c','Release','-f','net11.0','--no-restore','--filter',internal])]
rows=[]
for name,command in jobs:
    start=time.perf_counter()
    with(out/(name+'.log')).open('w',encoding='utf-8',newline='\n')as log:
        result=subprocess.run(command,cwd=root,stdout=log,stderr=subprocess.STDOUT,timeout=240)
    row=dict(name=name,exit=result.returncode,seconds=time.perf_counter()-start,command=command);rows.append(row)
    (out/'focused-checks.json').write_text(json.dumps(rows,indent=2)+'\n',encoding='utf-8',newline='\n')
    print(json.dumps(row),flush=True)
    if name=='probe-build':assert result.returncode==0
assert all(r['exit']==0 for r in rows)
