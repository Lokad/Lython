from pathlib import Path
import ast
import hashlib
import json
import shutil
import tarfile

notes=Path(__file__).parent;out=notes/'invocation-lifetime-r390';old=notes/'function-slot-binding-r384'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert not(out/'candidate-identity.json').exists()
checks=[]
for file in ['focused-checks.json','focused-checks-net10.json']:
    rows=json.loads((out/file).read_text(encoding='utf-8'));assert len(rows)==3 and all(v['exit']==0 for v in rows);checks.extend(rows)
baseline=json.loads((old/'candidate-identity.json').read_text(encoding='utf-8'))
sources={name:sha(name)for name in baseline['sources']}
changed=[name for name,h in sources.items()if h!=baseline['sources'][name]]
assert sorted(changed)==['src/Lokad.Lython/Public/LythonCompiledScript.cs','src/Lokad.Lython/Runtime/ExecutionThreads.cs'],changed
core=Path('src/Lokad.Lython/bin/Release/net11.0/Lokad.Lython.dll')
assert all(sha(project/'bin/Release/net11.0/Lokad.Lython.dll')==sha(core)for project in [Path('tests/Lokad.Lython.Tests'),Path('tests/Lokad.Lython.PublicApi.Tests')])
for role in ['reference','candidate']:shutil.copytree(old/'candidate',out/role)
shutil.copyfile(core,out/'candidate/Lokad.Lython.dll');shutil.copyfile(core,out/'candidate-core.dll')
shutil.copyfile(old/'catalog.json',out/'catalog.json')
files={role:{p.name:sha(p)for p in (out/role).iterdir()if p.is_file()}for role in ['reference','candidate']}
assert files['reference']==baseline['frozenFiles']['candidate']
assert all(files['candidate'][n]==h for n,h in files['reference'].items()if n!='Lokad.Lython.dll')
with tarfile.open(out/'candidate-sources.tar.xz','w:xz')as archive:
    for name in sources:archive.add(name,arcname=name)
    for name in ['tests/Lokad.Lython.Tests/AsyncExecutionThreadTests.cs','tests/Lokad.Lython.PublicApi.Tests/AsyncInvocationOwnershipTests.cs']:archive.add(name,arcname=name)
identity=dict(sources=sources,sourceInputs=589,changedProductionInputs=changed,
              coreSHA256={role:files[role]['Lokad.Lython.dll']for role in files},frozenFiles=files,
              auxiliaryFiles={n:h for n,h in files['reference'].items()if n!='Lokad.Lython.dll'},
              referenceRevision='810379be',qualification='Focused Release actual11/10; full platform/stress/package pending if retained.',
              focusedChecks=checks,architecture='One scheduled invocation owns setup/cleanup; remove outer ownership continuation. Async publication stays. Relay cancellation as canceled, preserving public outcome/token.',publicationHeld=True)
(out/'candidate-identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8',newline='\n')
text=(old/'local-screen.py').read_text(encoding='utf-8')
start=text.index('\njobs=')+1;end=text.index('\nfor caseId,lane',start)
jobs=[('scripts.text-summary-helpers.nonlocal-counter.large','warm-async'),('scripts.file-search.large.protected','warm-async'),('scripts.csv-fulfillment.large','warm-async'),('scripts.text-summary-helpers.nonlocal-counter.large','warm'),('diagnostic.loop-helper.short-zero.large','warm-async'),('diagnostic.loop-helper.short-zero.large','warm')]
text=text[:start]+'jobs='+repr(jobs)+text[end:]
text=text.replace('Function-slot binding construction/transport diagnostic; no CPU or allocation attribution.','Invocation scheduling/ownership diagnostic; no CPU or allocation attribution.')
ast.parse(text);(out/'local-screen.py').write_text(text,encoding='utf-8',newline='\n')
print(json.dumps(dict(frozen=True,coreSHA256=identity['coreSHA256'],jobs=len(jobs),sourceInputs=589,changedProductionInputs=changed)))
