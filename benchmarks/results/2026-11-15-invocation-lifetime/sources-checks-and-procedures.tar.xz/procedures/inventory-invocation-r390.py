from pathlib import Path
import hashlib,json,subprocess,tarfile

out=Path(__file__).parent/'invocation-lifetime-r390'
archive=Path('benchmarks/results/2026-11-15-shared-executable-slots/completed-sources-and-checks.tar.xz')
blob=subprocess.check_output(['git','show','HEAD:'+archive.as_posix()]);assert blob==archive.read_bytes()
with tarfile.open(archive)as tar:core=tar.extractfile('candidate-core.dll').read()
proof=dict(archive=archive.as_posix(),archiveSHA256=hashlib.sha256(blob).hexdigest(),member='candidate-core.dll',coreSHA256=hashlib.sha256(core).hexdigest(),bytes=len(core),custodyCommit=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip())
assert proof['coreSHA256'].startswith('95798eb9')
rawarchive=Path('benchmarks/results/2026-11-15-retained-cpython-checkpoint/observations.tgz')
rawblob=subprocess.check_output(['git','show','HEAD:'+rawarchive.as_posix()]);assert rawblob==rawarchive.read_bytes()
with tarfile.open(rawarchive)as tar:raw=tar.extractfile('confirmation/confirmation.json').read()
rawproof=dict(root='retained-cpython-b772-20261115',path='confirmation/confirmation.json',archiveSHA256=hashlib.sha256(rawblob).hexdigest(),rawSHA256=hashlib.sha256(raw).hexdigest(),bytes=len(raw),committedArchive=rawarchive.as_posix())
code=r'''from pathlib import Path
import fcntl,hashlib,json,os,shutil,stat,subprocess
proof=PROOF
rawproof=RAWPROOF
base=Path('/home/lokad/lython-bench-checks').resolve();source=base/'shared-slots-b763-20261115/candidate/Lokad.Lython.dll'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
with(base/'comparison-vm.lock').open('a')as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record|[p]ython3.*cpython-worker.py'],capture_output=True).returncode==1
 assert not any(os.path.ismount(p)for p in base.glob('*/guest-fixtures'))
 assert source.resolve()==source and sha(source)==proof['coreSHA256']
 found=subprocess.check_output(['find',str(base),'-xdev','-samefile',str(source),'-type','f','-print'],text=True).splitlines()
 paths=[Path(p)for p in found];metadata=[p.lstat()for p in paths]
 assert len(paths)==source.stat().st_nlink
 assert all(p.resolve()==p and p.is_relative_to(base)and stat.S_ISREG(m.st_mode)and m.st_uid==os.getuid()and m.st_size==proof['bytes']for p,m in zip(paths,metadata))
 assert all(sha(p)==proof['coreSHA256']for p in paths)
 raw=base/rawproof['root']/rawproof['path'];m=raw.lstat()
 assert raw.resolve()==raw and raw.is_relative_to(base)and stat.S_ISREG(m.st_mode)and m.st_uid==os.getuid()and m.st_nlink==1 and m.st_size==rawproof['bytes']and sha(raw)==rawproof['rawSHA256']
 assert sha(base/rawproof['root']/'observations.tgz')==rawproof['archiveSHA256']
 print(json.dumps(dict(freshIdleLease=True,freeBytes=shutil.disk_usage(base).free,coreCustody=proof,paths=[str(p.relative_to(base))for p in paths],links=len(paths),rawCustody=rawproof)))
'''.replace('RAWPROOF',repr(rawproof)).replace('PROOF',repr(proof))
(out/'inventory-command.py').write_text(code,encoding='utf-8',newline='\n')
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
result=subprocess.run(ssh+['python3 -'],input=code,capture_output=True,text=True,encoding='utf-8',timeout=60)
assert result.returncode==0,result.stderr
(out/'space-inventory.json').write_text(result.stdout,encoding='utf-8')
print(result.stdout)
