from pathlib import Path
import ast

source=Path(__file__).with_name('check-invocation-lifetime-r390.py').read_text(encoding='utf-8')
source=source.replace("'net11.0'", "'net10.0'").replace("'probe-build'", "'probe-build-net10'").replace("'public-net11'", "'public-net10'").replace("'internal-net11'", "'internal-net10'").replace("'focused-checks.json'", "'focused-checks-net10.json'")
ast.parse(source)
exec(compile(source,str(__file__),'exec'))
