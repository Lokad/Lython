from pathlib import Path
import ast,base64,datetime,json,subprocess

r=Path(__file__).parent/'invocation-lifetime-r390/quiet';config=json.loads((r/'config.json').read_text(encoding='utf-8'))
assert not(r/'launch-attempt.json').exists()
code=r'''from pathlib import Path
import ast,fcntl,hashlib,io,json,os,shutil,stat,subprocess,sys,tarfile
config=CONFIG
base=Path('/home/lokad/lython-bench-checks').resolve();root=Path(config['root']);source=Path(config['sourceRoot']);sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert root.parent==base and not root.exists()and source.parent==base and source.resolve()==source
with(base/'comparison-vm.lock').open('a')as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record|[p]ython3.*cpython-worker.py'],capture_output=True).returncode==1
 assert not any(os.path.ismount(p)for p in base.glob('*/guest-fixtures'))
 state=subprocess.check_output(['systemctl','show',config['unit']+'.service','--property=LoadState,MainPID'],text=True)
 assert 'LoadState=not-found'in state and 'MainPID=0'in state
 assert sha(source/'candidate/Lokad.Lython.dll')==config['identity']['coreSHA256']['reference']
 for name,h in config['identity']['auxiliaryFiles'].items():assert sha(source/'candidate'/name)==h
 assert sha(source/'catalog.json')==config['identity']['catalogSHA256']
 python_source=Path(config['pythonRoot']);assert python_source.parent==base and python_source.resolve()==python_source
 assert sha(python_source/'cpython-worker.py')==config['pythonWorkerSHA256']
 payload=sys.stdin.buffer.read(config['payloadBytes']+1)
 assert len(payload)==config['payloadBytes']and hashlib.sha256(payload).hexdigest()==config['payloadSHA256']
 before=shutil.disk_usage(base).free;retired=[]
 for group in config['inventory']['selected']:
  proof=group['custody'];paths=[base/p for p in group['paths']];metadata=[p.lstat()for p in paths]
  assert len(paths)==group['links']
  assert len({(m.st_dev,m.st_ino)for m in metadata})==1
  assert all(p.resolve()==p and p.is_relative_to(base)and stat.S_ISREG(m.st_mode)and m.st_uid==os.getuid()and m.st_nlink==len(paths)and m.st_size==proof['bytes']and sha(p)==proof['coreSHA256']for p,m in zip(paths,metadata))
  assert proof['coreSHA256']not in config['identity']['coreSHA256'].values()
  retired.extend(paths)
 assert before+config['inventory']['predictedReclaimedBytes']>254*1024*1024+config['unpackedBytes']+65536
 for path in retired:path.unlink()
 assert shutil.disk_usage(base).free>254*1024*1024+config['unpackedBytes']+65536
 root.mkdir()
 with tarfile.open(fileobj=io.BytesIO(payload),mode='r:gz')as archive:archive.extractall(root,filter='data')
 for role in ['candidate','reference']:
  (root/role).mkdir(exist_ok=True)
  for name in config['identity']['auxiliaryFiles']:os.link(source/'candidate'/name,root/role/name)
 os.link(source/'candidate/Lokad.Lython.dll',root/'reference/Lokad.Lython.dll')
 assert sha(root/'candidate/Lokad.Lython.dll')==config['identity']['coreSHA256']['candidate']
 os.link(source/'catalog.json',root/'representative.json');os.link(python_source/'cpython-worker.py',root/'cpython-worker.py')
 (root/'retirement-receipt.json').write_text(json.dumps(dict(retiredOnly=[str(p)for p in retired],custody=config['inventory']['selected'],allMetadataAndHashesVerifiedBeforeMutation=True,incomingPayloadVerifiedBeforeRetirement=True,freshIdleLease=True,current7161And8fbfArchivesCatalogsWorkersToolchainsAndFloorsPreserved=True,freeBeforeBytes=before,freeAfterBytes=shutil.disk_usage(base).free),indent=2)+chr(10))
 for name in ['collect.py','archive-owned.py']:ast.parse((root/name).read_text())
 subprocess.run(['/bin/sh','-n',str(root/'run.sh')],check=True)
 fixture=root/'guest-fixtures';fixture.mkdir();assert shutil.disk_usage(base).free>254*1024*1024
 (root/'space-preflight.json').write_text(json.dumps(dict(beforeFreeBytes=before,afterFreeBytes=shutil.disk_usage(base).free,oneFrozenCoreUpload=True,floorsUnchanged=True))+chr(10))
 subprocess.run(['sudo','-n','mount','-t','tmpfs','-o','size=128m,mode=0700,uid=lokad,gid=lokad','lython-b777-fixtures',str(fixture)],check=True)
try:subprocess.run(['sudo','-n','systemd-run','--unit='+config['unit'],'--property=User=lokad','--property=WorkingDirectory='+str(root),'--property=RuntimeMaxSec=240','--property=TimeoutStopSec=30','--property=KillMode=control-group','/bin/sh',str(root/'run.sh')],check=True)
except BaseException:
 subprocess.run(['sudo','-n','umount',str(fixture)],check=True);fixture.rmdir();raise
print(subprocess.check_output(['systemctl','show',config['unit']+'.service','--property=ActiveState,MainPID,RuntimeMaxUSec'],text=True))
'''.replace('CONFIG',repr(config))
ast.parse(code);(r/'launch-command.py').write_text(code,encoding='utf-8',newline='\n')
command="python3 -c 'import base64;exec(base64.b64decode(\""+base64.b64encode(code.encode()).decode()+"\"))'"
now=datetime.datetime.now(datetime.timezone.utc);(r/'launch-attempt.json').write_text(json.dumps(dict(attemptedUTC=now.isoformat(),neverAutomaticallyRelaunch=True))+'\n',encoding='utf-8')
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
result=subprocess.run(ssh+[command],input=(r/'payload.tgz').read_bytes(),capture_output=True,timeout=60)
(r/'launch.log').write_bytes(result.stdout+result.stderr);assert result.returncode==0,(result.stdout+result.stderr).decode('utf-8')
now=datetime.datetime.now(datetime.timezone.utc);(r/'observe-not-before.json').write_text(json.dumps(dict(startedUTC=now.isoformat(),doNotObserveBeforeUTC=(now+datetime.timedelta(seconds=175)).isoformat(),ownerSeconds=240),indent=2)+'\n',encoding='utf-8',newline='\n')
print(result.stdout.decode('utf-8'));print('Earliest observation',(now+datetime.timedelta(seconds=175)).isoformat(),flush=True)
