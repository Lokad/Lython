from pathlib import Path
import fcntl,hashlib,json,os,shutil,stat,subprocess
proof={'archive': 'benchmarks/results/2026-11-15-shared-executable-slots/completed-sources-and-checks.tar.xz', 'archiveSHA256': 'a5e42e4eb1b1a0a014cda9c3bcf451d770926057efea1dbec423b1cf4fca9162', 'member': 'candidate-core.dll', 'coreSHA256': '95798eb99ca4945d06d10c05d4f0a64925719377190abb82c5a5775d91bb52b0', 'bytes': 5749760, 'custodyCommit': '42115627cf89f1bd29ced9210908eec071182971'}
rawproof={'root': 'retained-cpython-b772-20261115', 'path': 'confirmation/confirmation.json', 'archiveSHA256': 'b55bfa2ce916a5f1d7302dd7f4bcddf47144d04ea035310f09abf4702fc3fb6c', 'rawSHA256': '4cfa57e7fc67e32bcf96041a08c3d2e68fc7fc58982a60dc5ac616d7145e26c9', 'bytes': 596999, 'committedArchive': 'benchmarks/results/2026-11-15-retained-cpython-checkpoint/observations.tgz'}
base=Path('/home/lokad/lython-bench-checks').resolve();source=base/'shared-slots-b763-20261115/candidate/Lokad.Lython.dll'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
with(base/'comparison-vm.lock').open('a')as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record|[p]ython3.*cpython-worker.py'],capture_output=True).returncode==1
 assert not any(os.path.ismount(p)for p in base.glob('*/guest-fixtures'))
 assert source.resolve()==source and sha(source)==proof['coreSHA256']
 found=subprocess.check_output(['find',str(base),'-xdev','-samefile',str(source),'-type','f','-print'],text=True).splitlines()
 paths=[Path(p)for p in found];metadata=[p.lstat()for p in paths]
 assert len(paths)==source.stat().st_nlink
 assert all(p.resolve()==p and p.is_relative_to(base)and stat.S_ISREG(m.st_mode)and m.st_uid==os.getuid()and m.st_size==proof['bytes']for p,m in zip(paths,metadata))
 assert all(sha(p)==proof['coreSHA256']for p in paths)
 raw=base/rawproof['root']/rawproof['path'];m=raw.lstat()
 assert raw.resolve()==raw and raw.is_relative_to(base)and stat.S_ISREG(m.st_mode)and m.st_uid==os.getuid()and m.st_nlink==1 and m.st_size==rawproof['bytes']and sha(raw)==rawproof['rawSHA256']
 assert sha(base/rawproof['root']/'observations.tgz')==rawproof['archiveSHA256']
 print(json.dumps(dict(freshIdleLease=True,freeBytes=shutil.disk_usage(base).free,coreCustody=proof,paths=[str(p.relative_to(base))for p in paths],links=len(paths),rawCustody=rawproof)))
