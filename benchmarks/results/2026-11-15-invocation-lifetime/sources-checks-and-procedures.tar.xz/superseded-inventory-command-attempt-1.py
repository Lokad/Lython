from pathlib import Path
import fcntl,hashlib,json,os,shutil,stat,subprocess
proofs=[{'archive': 'benchmarks/results/2026-11-14-range-iteration-stage/refined/sources-checks-and-observations.tar.xz', 'archiveSHA256': 'c3d8a9936bf911f37cde2c2fa863a5dc10bd98b1e9ae14f2ad90dcd7ad809cd3', 'member': 'refined/candidate-core.dll', 'coreSHA256': '73a1b2339a649ab87ef249f17bf97939d6e8ce757dc9297ac7875dc2b7bbe3e8', 'bytes': 5746176, 'source': 'range-checkpoint-b747-20261114/candidate/Lokad.Lython.dll'}, {'archive': 'benchmarks/results/2026-11-14-closed-range-construction/owned-constructor/sources-checks-and-observations.tar.xz', 'archiveSHA256': 'e8ccaa2370f6054d19e3da7e42c71d99b9464475d0ed0d90471d9cb667cc42f3', 'member': 'candidate-core.dll', 'coreSHA256': '738a12da770f570797cc036ec17c6c651c99f44567b044b36dc826d84cc923b4', 'bytes': 5745664, 'source': 'native-range-complete-b742-20261114/candidate/Lokad.Lython.dll'}]
base=Path('/home/lokad/lython-bench-checks').resolve();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
with(base/'comparison-vm.lock').open('a')as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record|[p]ython3.*cpython-worker.py'],capture_output=True).returncode==1
 assert not any(os.path.ismount(p)for p in base.glob('*/guest-fixtures'))
 result=[]
 for proof in proofs:
  source=base/proof['source'];assert source.resolve()==source and sha(source)==proof['coreSHA256']
  found=subprocess.check_output(['find',str(base),'-xdev','-samefile',str(source),'-type','f','-print'],text=True).splitlines()
  paths=[Path(p)for p in found];metadata=[p.lstat()for p in paths]
  assert len(paths)==source.stat().st_nlink
  assert all(p.resolve()==p and p.is_relative_to(base)and stat.S_ISREG(m.st_mode)and m.st_uid==os.getuid()and m.st_size==proof['bytes']for p,m in zip(paths,metadata))
  assert all(sha(p)==proof['coreSHA256']for p in paths)
  result.append(dict(custody=proof,paths=[str(p.relative_to(base))for p in paths],links=len(paths)))
 print(json.dumps(dict(freshIdleLease=True,freeBytes=shutil.disk_usage(base).free,selected=result,predictedReclaimedBytes=sum(p['bytes']for p in proofs),noMutation=True)))
