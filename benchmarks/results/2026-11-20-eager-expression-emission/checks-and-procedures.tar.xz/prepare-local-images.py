from pathlib import Path

lab=Path(__file__).resolve().parent
donor=lab.parent/'executable-class-suites/reuse-confirmation'
text=(donor/'freeze-and-verify.py').read_text(encoding='utf-8-sig').replace('agent-worktrees/executable-class-suites','agent-worktrees/eager-expression-emission')
a=text.index('prior = ')
b=text.index('\ndef read',a)
text=text[:a]+"prior = lab.parent / 'executable-class-suites/reuse-confirmation'"+text[b:]
text=text.replace('2dad15d55','53d3b45d5')
text=text.replace("catalog=read(lab.parent/'catalog.json')","catalog=read(prior/'catalog.json')")
text=text.replace("lab.parent/'reuse-block-diagnostics'/core","trial/'src/Lokad.Lython/bin/Release/net11.0'/core")
text=text.replace("lab.parent.parent/'method-format-frame/frozen/reference'","prior/'frozen/reference'")
text=text.replace("lab.parent.parent/'direct-class-header/compile-allocation/reference'","prior/'frozen/reference'")
assert "trial/'src/Lokad.Lython/bin/Release/net11.0'/core" in text
(lab/'freeze-and-verify.py').write_text(text,encoding='utf-8',newline='\n')
text=(donor/'check-semantics.py').read_text(encoding='utf-8-sig').replace('agent-worktrees/executable-class-suites','agent-worktrees/eager-expression-emission')
a=text.index('load=lambda')
newcases=[
('expression-order', """events=[]
def seen(label,value):
    events.append(label)
    return value
def receive(*args,**kw):
    return args, kw
print(receive(seen('pos',1),*seen('star',[2,3]),**seen('kw',{'extra':4})))
print(seen('array',[0,1,2,3,4])[seen('start',1):seen('end',5):seen('step',2)])
print(events)
"""),
('annotation-and-default-order', """events=[]
def seen(label,value):
    events.append(label)
    return value
def make(factor):
    def method(a: seen('annotation',int)=seen('default',factor),/,*,b: seen('kw annotation',str)='hi') -> seen('return',tuple):
        return a,b
    return method
class Holder:
    flag = bytes
    def method(self,value: flag=seen('class default',b'x')):
        return value
f=make(7)
print(f(), f.__annotations__, Holder.method.__annotations__, events)
"""),
('nested-lazy-callables', """type Defaults = (lambda final=tuple(x + 1 for x in (2, 4)): final)
type Positions = (lambda x: x for x in range(3))
print(Defaults.__value__(), [function(5) for function in Positions.__value__])
""")]
text=text[:a]+''.join(f"cases[{key!r}]={value!r}\n" for key,value in newcases)+text[a:]
(lab/'check-semantics.py').write_text(text,encoding='utf-8',newline='\n')
