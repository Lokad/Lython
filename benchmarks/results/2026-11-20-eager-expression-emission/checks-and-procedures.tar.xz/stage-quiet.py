from pathlib import Path
import hashlib,json,tarfile

lab=Path(__file__).resolve().parent
prior=lab.parent/'executable-class-suites/reuse-confirmation'
donor_dir=prior/'quiet'
quiet=lab/'quiet'; quiet.mkdir(exist_ok=False)
read=lambda f:f.read_text(encoding='utf-8-sig')
load=lambda f:json.loads(read(f))
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()

def write(file,body):
    if file.suffix=='.py': compile(body,file,'exec')
    file.write_text(body,encoding='utf-8',newline='\n')

pair=load(lab/'frozen-identity.json')
donor=load(donor_dir/'config.json')
receipt=load(donor_dir/'archive-receipt.json')
assert receipt['complete'] and receipt['archivedAndVerifiedUnderLease'] and sha(donor_dir/'observations.tgz')==receipt['archiveSHA256']
assert donor['identity']['imageFiles']['candidate']==pair['images']['reference']
for role,files in pair['images'].items():
    assert len(files)==32 and {name:sha(lab/'frozen'/role/name)for name in files}==files
    verified=load(lab/f'{role}-verify.json')
    assert verified['state']=='Completed' and verified['catalogSha256']==pair['casesSHA256']
    for mode in (False,True):
        rows=[json.loads(row)for row in (lab/f'probe-{role}-{mode}.jsonl').read_bytes().splitlines()]
        assert len(rows)==11 and all(row['Matches']and row['Compared']for row in rows)

root='/home/lokad/lython-bench-checks/eager-expression-emission-b1197-20261120'
unit='lython-b1197-eager-expression-emission-20261120'
core='Lokad.Lython.dll'
purpose='Direct eager expression emission against the class-suite delivery'
jobs=[('scripts.dataclass-inherited-configuration.generated','compile'),('scripts.dataclass-inherited-configuration.generated','compile-run'),
      ('scripts.config-generated-guards.medium','compile-run'),('scripts.config-manifest.small','compile-run'),
      ('scripts.annotated-rule-closures','warm')]
identity=dict(sourceRevision=pair['referenceCommit']+' versus '+pair['candidateCommit'],purpose=purpose,
    imageFiles=pair['images'],catalogSHA256=pair['casesSHA256'],normalAdapterPin='0.4.0',
    coreSHA256={label:files[core]for role,files in pair['images'].items()for label in (role,role+'-control')})
write(quiet/'identity.json',json.dumps(identity,indent=2)+'\n')
quiet.joinpath('representative.json').write_bytes((lab/'catalog.json').read_bytes())
quiet.joinpath('cpython-worker.py').write_bytes(Path('benchmarks/cpython-worker.py').read_bytes())
assert sha(quiet/'representative.json')==pair['casesSHA256']==donor['catalogSHA256']
assert sha(quiet/'cpython-worker.py')==donor['protocolSHA256']
quiet.joinpath('candidate').mkdir()
quiet.joinpath('candidate',core).write_bytes((lab/'frozen/candidate'/core).read_bytes())
for name in ('collect.py','archive-owned.py','run.sh','retrieve.py'):
    text=read(donor_dir/name).replace(donor['root'],root).replace(donor['unit'],unit)
    text=text.replace('Executable class suites with shared compiler buffers',purpose)
    text=text.replace('len(jobs)==4','len(jobs)==5').replace("['jobs']==4","['jobs']==5")
    text=text.replace("len(raw['jobs'])==4","len(raw['jobs'])==5").replace('jobs=4,','jobs=5,')
    if name=='collect.py':
        a=text.index('\njobs = ')
        b=text.index('\nassert len(jobs)',a)
        text=text[:a]+'\njobs = '+repr(jobs)+text[b:]
    write(quiet/name,text)
assert b'\r' not in (quiet/'run.sh').read_bytes()
parts=['identity.json','cpython-worker.py','collect.py','archive-owned.py','run.sh','candidate/'+core]
payload=quiet/'payload.tgz'
with tarfile.open(payload,mode='w:gz')as tar:
    for name in parts:tar.add(quiet/name,arcname=name)
config=dict(root=root,unit=unit,source=donor['root'],sourceRole='candidate',sourceFiles=pair['images']['reference'],
    sourceCatalogSHA256=donor['catalogSHA256'],protocolSHA256=donor['protocolSHA256'],catalogSHA256=pair['casesSHA256'],
    identity=identity,retireGroups=[],donorArchiveSHA256=receipt['archiveSHA256'],
    payloadBytes=payload.stat().st_size,payloadSHA256=sha(payload),unpackedBytes=sum((quiet/n).stat().st_size for n in parts))
write(quiet/'config.json',json.dumps(config,indent=2)+'\n')
s=read(donor_dir/'remote-launch.py')
a=s.index('\nc=')+1;b=s.index('\nb=Path(',a)
s=s[:a]+'c='+repr(config)+s[b:]
s=s.replace('lython-b1195-fixtures','lython-b1197-fixtures')
assert '+64*1024*1024' in s
write(quiet/'remote-launch.py',s)
for name in ('launch-quiet.py','summarize-quiet.py'):
    text=read(prior/name).replace('Executable class suites with shared compiler buffers',purpose)
    text=text.replace('seconds=255','seconds=305').replace('before 255','before 305').replace("len(raw['jobs'])==4","len(raw['jobs'])==5")
    write(lab/name,text)
print('Complete images and 11 CPython probes verified. Five lanes staged.')
