from pathlib import Path
r=Path(__file__).resolve().parent
source=(r.parent/'activation-r404/capture-codegen.py').read_text(encoding='utf-8')
source=source.replace("old=r.parent/'activation-r403'", "old=r")
source=source.replace("old/'final-storage/catalog.json'", "old/'quiet/additional.json'")
source=source.replace('scripts.csv-invoice.large','scripts.config-manifest.small')
source=source.replace("old/'final-storage/reference'", "old/'frozen/reference'").replace("old/'retirement/candidate'", "old/'frozen/candidate'")
source=source.replace("('withdrawn',", "('candidate',")
source=source.replace("*RunCore* *ExecuteInstructionPrefix*", "*RunCore* *ExecuteInstructionPrefix* *ReadExecutableOperand*")
source=source.replace('complete-invoice', 'complete-config-manifest')
(r/'capture-codegen.py').write_text(source,encoding='utf-8')
