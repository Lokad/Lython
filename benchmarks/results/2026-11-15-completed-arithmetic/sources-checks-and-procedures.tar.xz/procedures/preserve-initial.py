from pathlib import Path
import hashlib,json,shutil,tarfile
r=Path(__file__).resolve().parent;repo=r.parents[3]
out=repo/'benchmarks/results/2026-11-15-completed-arithmetic';out.mkdir(exist_ok=False)
for name in ['summary.json','archive-receipt.json','terminal-status.json','observations.tgz']:
    shutil.copyfile(r/'quiet'/name,out/name)
identity=json.loads((r/'quiet/identity.json').read_text(encoding='utf-8'))
identity['originalInheritedRuntimeCommit']=identity['runtimeCommit'];identity['runtimeCommit']='51e3c2c1; reference only'
identity['qualification']='Corrected132internal net11/164internal net10;401public each target. Uncommitted R405; not retained/fully qualified.'
(out/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8')
shutil.copyfile(r/'frozen/allocation-summary.json',out/'allocation-summary.json')
archive=out/'sources-checks-and-procedures.tar.xz'
with tarfile.open(archive,'x:xz') as a:
    for p in (r/'frozen').iterdir():
        if p.is_file():a.add(p,arcname='frozen/'+p.name,recursive=False)
    a.add(r/'frozen/candidate/Lokad.Lython.dll',arcname='candidate-core.dll',recursive=False)
    for p in r.iterdir():
        if p.is_file():a.add(p,arcname='procedures/'+p.name,recursive=False)
    for p in (r/'quiet').iterdir():
        if p.is_file() and p.name not in {'payload.tgz','observations.tgz'}:a.add(p,arcname='quiet/'+p.name,recursive=False)
    for suite in ['Lokad.Lython.Tests','Lokad.Lython.PublicApi.Tests']:
        for p in (repo/'tests'/suite/'TestResults').glob('r405-*.trx'):
            a.add(p,arcname='checks/'+suite+'/'+p.name,recursive=False)
decision=dict(retained=False,fullyQualified=False,sourcePair='uncommitted9e890d18 versus qualified51e3/22e5; allocation reference6e/45dd',
    initialInvoiceGain='elapsed2.29..3.84% and CPU2.14..3.30% lower; source-pair evidence, no isolated causal claim',
    remainingUncertainty='Moving text/search controls and adverse fresh-config process remain; one same-bits text/fresh confirmation with longer full-request warmup selected.',
    allocation='Effectively flat across the four existing complete workloads',
    originalLifetimeFailure='Derived Locals lost the return handle after Stack.ReleaseStorage;51public failures. Existing handle restored without relaxing assertions or adding ownership machinery.',
    codegen='Shared reader92IL bytes; short config diagnostic captures Tier1 reader but no optimized prefix. Does not establish a CPU cause; source remains unchanged.',
    reconstruction='Exact changed core plus full per-image manifests; unchanged auxiliaries are in3c3eb130 canonical activation reference-image archive.',
    archiveSHA256=hashlib.sha256(archive.read_bytes()).hexdigest())
(out/'decision.json').write_text(json.dumps(decision,indent=2)+'\n',encoding='utf-8')
print(dict(bytes=archive.stat().st_size,sha256=decision['archiveSHA256']))
