from pathlib import Path
import json,statistics
r=Path(__file__).resolve().parent/'quiet'
raw=json.loads((r/'retrieved/confirmation/confirmation.json').read_text(encoding='utf-8'))
assert raw['complete'] and len(raw['jobs'])==6
rows=[]
for job in raw['jobs']:
    elapsed={};cpu={}
    for label in job['identities']:
        samples=[v for v in job['samples'] if v['engine']==label]
        elapsed[label]=statistics.median(v['response']['elapsedTicks']/v['response']['clockFrequency']/v['response']['completedInvocations']*1000 for v in samples)
        cpu[label]=statistics.median(v['externalProcessCpuTicks']/v['externalCpuFrequency']/v['response']['completedInvocations']*1000 for v in samples)
    change=lambda values:sorted(100*(values[a]/values[b]-1) for a in ['candidate','candidate-control'] for b in ['reference','reference-control'])
    spread=lambda values,role:100*(max(values[role],values[role+'-control'])/min(values[role],values[role+'-control'])-1)
    rows.append(dict(case=job['case'],lane=job['lane'],elapsedMilliseconds=elapsed,cpuMilliseconds=cpu,elapsedChangePercent=change(elapsed),cpuChangePercent=change(cpu),referenceSpreadPercent=spread(elapsed,'reference'),candidateSpreadPercent=spread(elapsed,'candidate')))
out=dict(complete=True,quietBeforeAndAfter=True,allUsersJoinedAndFixturesRemoved=True,rows=rows,retentionDecisionPending=True,CPythonRefreshed=False)
(r/'summary.json').write_text(json.dumps(out,indent=2)+'\n',encoding='utf-8')
for row in rows:print(row['case'],row['lane'],'elapsed',row['elapsedChangePercent'],'CPU',row['cpuChangePercent'],'spreads',row['referenceSpreadPercent'],row['candidateSpreadPercent'])
