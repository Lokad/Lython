from pathlib import Path
import subprocess
repo=Path(__file__).resolve().parents[4];r=repo/'src/Lokad.Lython/Runtime'
subprocess.run(['git','archive','--output='+str(Path(__file__).parent/'baseline-source.tar'),'fb5b0e1d','src','tests','global.json','Directory.Build.props'],cwd=repo,check=True)
p=r/'LythonRuntime.Executable.Binding.cs';s=p.read_text(encoding='utf-8')
a=s.index('        if (value is null)\n',s.index('    private static object LoadLocal('));b=s.index('    private static bool TryLoadClosure',a)
s=s[:a]+'''        return value ?? LoadMissingLocal(codeObject, slot, span, context);
    }

    private static object LoadMissingLocal(ExecutableCodeObject codeObject, int slot,
        LythonSourceSpan span, ExecutionContext context)
    {
        if (!codeObject.IsFunctionScope && !codeObject.LocalNames[slot].StartsWith('<'))
        {
            if (context.Variables.TryGetValue(codeObject.LocalNames[slot], out var globalValue)) return globalValue;
            if (context.TryGetBuiltin(codeObject.LocalNames[slot], out var builtin)) return builtin;
        }
        throw codeObject.IsFunctionScope
            ? RuntimeErrors.UnboundLocalVariable(codeObject.LocalNames[slot], span)
            : RuntimeErrors.NameNotDefined(codeObject.LocalNames[slot], span);
    }

'''+s[b:];p.write_text(s,encoding='utf-8')
p=r/'LythonRuntime.Executable.Inputs.cs';s=p.read_text(encoding='utf-8')
a=s.index('            // Closed machine values');b=s.index('            // A failed leaf read',a)
s=s[:a]+s[b:];p.write_text(s,encoding='utf-8')
p=r/'LythonRuntime.Executable.NativeCalls.cs';s=p.read_text(encoding='utf-8')
a=s.index('    private static bool CanUseNativeBinary(');b=s.index('    private static object InvokeNativeStringOperation(',a)
s=s[:a]+s[b:];p.write_text(s,encoding='utf-8')
p=r/'LythonRuntime.Executable.NativePrefix.cs';s=p.read_text(encoding='utf-8')
a=s.index('                    case ExecutableOpCode.Unary:');b=s.index('                    case ExecutableOpCode.CompareJumpIfFalse:',a)
s=s[:a]+'''                    case ExecutableOpCode.Binary:
                    case ExecutableOpCode.Augmented:
                        if (TryIntegerOperation()) break;
                        goto case ExecutableOpCode.Unary;
                    case ExecutableOpCode.Unary:
                        if (!TryEvaluateBuiltinArithmetic(Code, Values, Index, _scope, out var arithmetic)) return false;
                        Publish(instruction, arithmetic);
                        break;
'''+s[b:];p.write_text(s,encoding='utf-8')
p=r/'LythonRuntime.Executable.Interpreter.Dispatch.cs';s=p.read_text(encoding='utf-8')
old='''                        case ExecutableOpCode.Binary or ExecutableOpCode.Augmented or ExecutableOpCode.Unary or ExecutableOpCode.Subscript
                            or ExecutableOpCode.StoreSubscript or ExecutableOpCode.StoreSubscriptLast:
'''
new='''                        case ExecutableOpCode.Binary or ExecutableOpCode.Augmented or ExecutableOpCode.Unary:
                            if (TryExecuteBuiltinArithmetic(ref execution, scope, invocation, instruction)) break;
                            goto case ExecutableOpCode.Subscript;
                        case ExecutableOpCode.Subscript or ExecutableOpCode.StoreSubscript or ExecutableOpCode.StoreSubscriptLast:
'''
assert old in s;s=s.replace(old,new);p.write_text(s,encoding='utf-8')
