from pathlib import Path
r=Path(__file__).resolve().parent
source=(r.parent/'activation-r403/freeze-initial.py').read_text(encoding='utf-8')
source=source.replace("folder=root/'initial-unified'", "folder=root/'frozen'")
source=source.replace("('r403-initial-internal.trx','r403-internal-refined.trx')", "('r405-internal11.trx','r405-lifetime-corrected-internal11.trx','r405-internal10.trx')")
source=source.replace("('r403-initial-public.trx','r403-expanded-public.trx')", "('r405-public10.trx','r405-lifetime-corrected-public10.trx','r405-expanded-public11.trx')")
source=source.replace("baseRevision='02340b14'", "baseRevision='fb5b0e1d'")
source=source.replace('Uncommitted canonical activation;126internal/401expanded public net11 pass; no full or net10 qualification yet.', 'Uncommitted R405 completed arithmetic/shared operand reads; bound return handle retained.132internal/401public net11 and164internal/356public net10 pass. Not retained or fully qualified.')
exec(compile(source,str(r/'freeze.py'),'exec'))
measure=(r.parent/'activation-r403/measure-initial-allocation.py').read_text(encoding='utf-8').replace("/'initial-unified'", "/'frozen'")
(r/'measure-allocation.py').write_text(measure,encoding='utf-8')
