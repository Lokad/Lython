from pathlib import Path
r=Path(__file__).resolve().parent
tool=r/'inspect';tool.mkdir()
source=(r.parent/'activation-r404/Program.cs').read_text(encoding='utf-8')
source=source.replace('["NativeExecution"] = ["RunCore"]','["NativeExecution"] = ["Read", "RunCore"]')
source=source.replace('["ExecutionContext"] = ["ExecuteInstructionPrefix"]','["ExecutionContext"] = ["ReadOperand", "TryExecuteBuiltinArithmetic", "ExecuteInputInstruction"]')
source=source.replace('var selected = new Dictionary<string, string[]>\n{','var selected = new Dictionary<string, string[]>\n{\n    ["LythonRuntime"] = ["ReadExecutableOperand", "TryEvaluateBuiltinArithmetic"],')
(tool/'Program.cs').write_text(source,encoding='utf-8')
(tool/'Inspect.csproj').write_text((r.parent/'activation-r404/Inspect.csproj').read_text(encoding='utf-8'),encoding='utf-8')
