from pathlib import Path
import hashlib,io,json,subprocess,tarfile
r=Path(__file__).resolve().parent;repo=r.parents[3]
code=(r.parent/'activation-r403/prepare-quiet.py').read_text(encoding='utf-8')
code=code.replace("r/'final-storage", "r/'frozen")
code=code.replace('/home/lokad/lython-bench-checks/activation-b787-20261115','/home/lokad/lython-bench-checks/arithmetic-b790-20261115')
code=code.replace('lython-b787-canonical-activation-20261115','lython-b790-completed-arithmetic-20261115')
code=code.replace("r.parent/'config-phases-r336/catalog.json'", "r.parent/'fresh-config-r386/catalog.json'")
code=code.replace('scripts.config-edit.empty','scripts.config-manifest.small')
a=code.index('retire=[]');b=code.index("with tarfile.open(q/'payload.tgz'",a)
code=code[:a]+'retire=[]\n'+code[b:]
exec(compile(code,str(r/'prepare-quiet.py'),'exec'))
q=r/'quiet';sha=lambda b:hashlib.sha256(b).hexdigest()
identity=json.loads((q/'identity.json').read_text(encoding='utf-8'))
identity.update(sourceRevision='R405 uncommitted completed arithmetic/shared operand reads versus qualified51e3c2c1/frozen22e5b72c',
    purpose='Completed arithmetic bypasses generic async operand machinery; shared native/ordinary value semantics and operand reads. Full invoice/fulfillment/text/JSON/search and helper-rich config compile-to-result.',
    qualification='Corrected focused checks132internal/401public net11;164internal/356public net10; full qualification pending if retained.',
    roleMeaning={role:('R405 uncommitted' if role.startswith('candidate') else 'qualified51e3c2c1/frozen22e5b72c')for role in ['reference','reference-control','candidate','candidate-control']})
(q/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8')
retire=[]
def custody(p):
    name=p.relative_to(repo).as_posix();commit=subprocess.check_output(['git','log','-1','--format=%H','--',name],cwd=repo,text=True).strip()
    assert subprocess.check_output(['git','hash-object',str(p)],cwd=repo,text=True).strip()==subprocess.check_output(['git','rev-parse',f'{commit}:{name}'],cwd=repo,text=True).strip()
    return dict(commit=commit,archive=name,archiveSHA256=sha(p.read_bytes()))
p=repo/'benchmarks/results/2026-11-15-canonical-activation-prototype/refinement/sources-checks-and-observations.tar.xz';proof=custody(p)
with tarfile.open(p) as a:
    core=a.extractfile('retirement/candidate-core.dll').read()
    for path in ['activation-b788-20261115/candidate/Lokad.Lython.dll','invoice-attribution-b789-20261115/candidate/Lokad.Lython.dll']:
        retire.append(dict(path=path,bytes=len(core),sha256=sha(core),links=2,custody=dict(proof,member='retirement/candidate-core.dll')))
    blob=a.extractfile('quiet/observations.tgz').read()
    with tarfile.open(fileobj=io.BytesIO(blob)) as inner:raw=inner.extractfile('additional.json').read()
    retire.append(dict(path='activation-b788-20261115/additional.json',bytes=len(raw),sha256=sha(raw),custody=dict(proof,member='quiet/observations.tgz',nestedMember='additional.json')))
p=repo/'benchmarks/results/2026-11-15-canonical-activation-prototype/sources-images-checks-and-observations.tar.xz';proof=custody(p)
with tarfile.open(p) as a:
    blob=a.extractfile('quiet/observations.tgz').read()
    with tarfile.open(fileobj=io.BytesIO(blob)) as inner:raw=inner.extractfile('additional.json').read()
    retire.append(dict(path='activation-b787-20261115/additional.json',bytes=len(raw),sha256=sha(raw),custody=dict(proof,member='quiet/observations.tgz',nestedMember='additional.json')))
p=repo/'benchmarks/results/2026-11-15-tuple-operand-prototype/refined/quiet/observations.tgz';raw=p.read_bytes()
retire.append(dict(path='tuple-transport-b782-20261115/observations.tgz',bytes=len(raw),sha256=sha(raw),custody=custody(p)))
with tarfile.open(q/'payload.tgz','w:gz') as a:
    for name in ['identity.json','additional.json','collect.py','archive-owned.py','run.sh']:a.add(q/name,arcname=name)
    a.add(r/'frozen/candidate/Lokad.Lython.dll',arcname='candidate/Lokad.Lython.dll')
with tarfile.open(q/'payload.tgz') as a:unpacked=sum(m.size for m in a if m.isfile())
config=json.loads((q/'config.json').read_text(encoding='utf-8'))
config.update(identity=identity,retire=retire,unpackedBytes=unpacked,payloadBytes=(q/'payload.tgz').stat().st_size,payloadSHA256=sha((q/'payload.tgz').read_bytes()))
(q/'config.json').write_text(json.dumps(config,indent=2)+'\n',encoding='utf-8')
launch=(r.parent/'activation-r403/launch-quiet.py').read_text(encoding='utf-8')
launch=launch.replace('b787','b790').replace("canonical-activation",'completed-arithmetic')
launch=launch.replace(" paths=[]", " paths=[];groups={}")
launch=launch.replace("m.st_nlink==1", "m.st_nlink==proof.get('links',1)")
launch=launch.replace("  paths.append(p)", "  paths.append(p)\n  key=(m.st_dev,m.st_ino);group=groups.setdefault(key,dict(count=0,links=m.st_nlink,bytes=m.st_size));group['count']+=1")
launch=launch.replace(" assert before+sum(v['bytes']for v in config['retire'])", " assert all(v['count']==v['links']for v in groups.values())\n assert before+sum(v['bytes']for v in groups.values())")
(r/'launch-quiet.py').write_text(launch,encoding='utf-8')
retrieve=(r.parent/'activation-r403/quiet/retrieve.py').read_text(encoding='utf-8').replace('activation-b787','arithmetic-b790').replace('lython-b787-canonical-activation','lython-b790-completed-arithmetic').replace('B787','B790')
(q/'retrieve.py').write_text(retrieve,encoding='utf-8')
summary=(r.parent/'activation-r403/summarize-quiet.py').read_text(encoding='utf-8')
(r/'summarize-quiet.py').write_text(summary,encoding='utf-8')
print(dict(core=config['identity']['coreSHA256']['candidate'],stagedBytes=unpacked,retiredUniqueBytes=len(core)+sum(v['bytes']for v in retire[2:]),extraCases=[v['id']for v in json.loads((q/'additional.json').read_text(encoding='utf-8'))['cases']]))
