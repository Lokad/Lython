from pathlib import Path
import contextlib,hashlib,importlib.util,json,math,os,subprocess,tempfile,time
r=Path(__file__).resolve().parent;repo=r.parents[3];old=r
sdk='C:/Users/JoannesVermorel/.dotnet11'
spec=importlib.util.spec_from_file_location('protocol',repo/'benchmarks/cpython-worker.py')
protocol=importlib.util.module_from_spec(spec);spec.loader.exec_module(protocol)
catalog=(old/'quiet/additional.json').resolve()
case=next(c for c in json.loads(catalog.read_text(encoding='utf-8'))['cases'] if c['id']=='scripts.config-manifest.small')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
out=dict(purpose='One bounded complete-config-manifest JIT codegen comparison; explicit diagnostic override, no elapsed/CPU/portable performance claim.',case=case['id'],sourceSha256=case['sourceSha256'],images={})
for role,folder in [('reference',old/'frozen/reference'),('candidate',old/'frozen/candidate')]:
    dump=(r/(role+'-jit.txt')).resolve();assert not dump.exists()
    env=dict(os.environ);env['DOTNET_ROOT']=sdk
    assert not any(k.startswith(('DOTNET_','COMPlus_')) and k!='DOTNET_ROOT' for k in env)
    env['DOTNET_JitDisasm']='*RunCore* *ExecuteInstructionPrefix* *ReadExecutableOperand*'
    env['DOTNET_JitStdOutFile']=str(dump)
    records=[];ready=None
    with tempfile.TemporaryDirectory(prefix='lython-comparison-files-') as fixture, tempfile.TemporaryFile() as errors:
        process=subprocess.Popen([sdk+'/dotnet.exe',str((folder/'Lokad.Lython.Benchmarks.dll').resolve()),'--compare','worker','--catalog',str(catalog)],cwd=fixture,env=env,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=errors)
        sequence=0
        try:
            ready=protocol.read_frame(process.stdout);assert ready['status']=='Ready'
            core=next(v for v in ready['libraries'] if Path(v['path']).name=='Lokad.Lython.dll')
            assert core['sha256'].lower()==sha(folder/'Lokad.Lython.dll')
            def request(operation,count):
                global sequence
                sequence+=1;q={k:case[k]for k in ['sourceSha256','fixtureSha256','expectedOutputSha256']}
                q.update(protocolVersion=2,requestId=sequence,operation=operation,caseId=case['id'],lane='warm',iterations=count)
                start=time.monotonic();protocol.write_frame(process.stdin,q);response=protocol.read_frame(process.stdout)
                assert response['status']==('Equivalent' if operation=='verify' else 'Completed'),response
                assert response['completedInvocations']==count and response['actualOutputSha256']==case['expectedOutputSha256'] and response['actualFilesSha256']==case['expectedFilesSha256']
                records.append(response)
                return time.monotonic()-start
            request('verify',2)
            end=time.monotonic()+3;count=1
            while time.monotonic()<end:
                elapsed=request('batch',count);count=max(1,min(10000,math.ceil(count*.1/max(elapsed,.000001))))
        finally:
            if process.poll() is None:
                protocol.write_frame(process.stdin,dict(protocolVersion=2,requestId=sequence+1,operation='quit'))
                assert protocol.read_frame(process.stdout)['status']=='Closed'
            assert process.wait(timeout=10)==0
            process.stdin.close();process.stdout.close();errors.seek(0);assert not errors.read()
        # Input/output fixtures are intentionally persistent within the worker
        # cwd. The tool owns that directory and removes it after Closed/exit.
        stagedFiles=[p.relative_to(fixture).as_posix() for p in Path(fixture).rglob('*') if p.is_file()]
    assert not Path(fixture).exists()
    assert dump.is_file() and dump.stat().st_size>0
    out['images'][role]=dict(identity=ready,coreSHA256=sha(folder/'Lokad.Lython.dll'),requests=records,allUsersJoined=True,fixturesRemoved=True,stagedFilesBeforeOwnedDirectoryCleanup=stagedFiles,dumpBytes=dump.stat().st_size,dumpSHA256=sha(dump))
(r/'codegen.json').write_text(json.dumps(out,indent=2)+'\n',encoding='utf-8')
print([(role,row['dumpBytes'])for role,row in out['images'].items()])
