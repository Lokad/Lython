set -eu
lab="$PWD/.git/agent-notes/review-20261031/shared-callable-layout-20261125"
worktree="$PWD/.git/agent-worktrees/shared-callable-layout-20261125"
export DOTNET_ROOT="$HOME/.dotnet"
export PATH="$DOTNET_ROOT:$PATH"
filter='(FullyQualifiedName~Function|FullyQualifiedName~Binding|FullyQualifiedName~Generator|FullyQualifiedName~NativeDefinition|FullyQualifiedName~AdmissionFailureCommand|FullyQualifiedName~ManagedStackGuard)&Category!=Stress'
for target in net11.0 net10.0; do
 for suite in Lokad.Lython.Tests Lokad.Lython.PublicApi.Tests; do
    log="$lab/ubuntu-$target-$suite.log"
    if "$DOTNET_ROOT/dotnet" test "$worktree/tests/$suite/$suite.csproj" -c Release -f "$target" --artifacts-path "$lab/ubuntu" --filter "$filter" > "$log" 2>&1; then
        tail -3 "$log"
    else
        tail -48 "$log"
        exit 1
    fi
 done
done
