from pathlib import Path
import hashlib,json,os,shutil,subprocess,tarfile

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
quiet=lab/'comparison/quiet'
out=lab/'confirmation'
out.mkdir(exist_ok=True)
read=lambda f:json.loads(f.read_text(encoding='utf-8-sig'))
write=lambda p,s:p.write_text(s,encoding='utf-8',newline='\n')
save=lambda p,d:write(p,json.dumps(d,ensure_ascii=False,indent=2)+'\n')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
identity=read(quiet/'identity.json')
terminal=read(quiet/'terminal-status.json')['receipt']
assert terminal['complete'] and sha(quiet/'observations.tar.xz')==terminal['archiveSHA256']
catalog=read(quiet/'representative.json')
invoice='scripts.csv-invoice.method-policy.quoted-control'
manifest='diagnostic.generated-ordinary-definitions'
rules='scripts.rule-default-closures'
catalog['cases']=[row for row in catalog['cases'] if row['id'] in (invoice,manifest,rules)]
assert len(catalog['cases'])==3
save(out/'representative.json',catalog)
save(out/'jobs.json',dict(warm=[[invoice,'warm'],[rules,'compile-run'],[manifest,'warm']]))
identity['catalogs']={name:dict(sha256=sha(out/name)) for name in ('representative.json','jobs.json')}
identity['purpose']='Confirm the invoice control and rule time to result after sharing executable parameter layouts'
save(out/'identity.json',identity)
sdk=Path.home()/'.dotnet11'
env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk))
worker=repo/'benchmarks/cpython-worker.py'
assert sha(worker)==identity['cpythonWorkerSHA256']
for role,expected in identity['imageFiles'].items():
    image=lab/role
    assert len(expected)==32 and {p.name:sha(p) for p in image.iterdir()}==expected
    proof=out/f'{role}-verify.json'
    subprocess.run([sdk/'dotnet.exe',image/'Lokad.Lython.Benchmarks.dll','--compare','verify','--catalog',out/'representative.json',
        '--dotnet',sdk/'dotnet.exe','--python','C:/Python313/python.exe','--python-worker',worker,'--out',proof],env=env,cwd=repo,check=True,timeout=60)
    checked=read(proof)
    assert checked['state']=='Completed' and checked['caseCount']==3 and checked['launched']['library']['sha256']==expected['Lokad.Lython.dll']
    assert checked['catalogSha256']==identity['catalogs']['representative.json']['sha256']
shutil.copyfile(quiet/'run.sh',out/'run.sh')
assert b'\r' not in (out/'run.sh').read_bytes()
collector=(quiet/'collect.py').read_text(encoding='utf-8').replace('b1672-fixtures','b1672-confirm-fixtures').replace('len(jobs) == 6','len(jobs) == 3').replace('targetBatchSeconds=.65','targetBatchSeconds=.87')
compile(collector,'collect.py','exec')
write(out/'collect.py',collector)
donor=lab.with_name('defaulted-rule-phase-split-20261125')
launcher=(donor/'quiet.py').read_text(encoding='utf-8').replace("lab.parent / 'direct-operand-return-20261124/comparison/quiet'","lab / 'comparison/quiet'")
launcher=launcher.replace('lython-b1660-defaulted-rule-phase-split-20261125','lython-b1672-shared-callable-layout-confirm-20261125')
launcher=launcher.replace('defaulted-rule-phase-split-b1660-20261125','shared-callable-layout-confirm-b1672-20261125')
launcher=launcher.replace('direct-operand-return-b1659-20261124','shared-callable-layout-b1672-20261125')
launcher=launcher.replace('seconds=202','seconds=170').replace('RuntimeMaxSec=260','RuntimeMaxSec=235')
launcher=launcher.replace('lab/"verified-raw-replicas.json"','output/"verified-raw-replicas.json"')
compile(launcher,'quiet-confirm.py','exec')
write(lab/'quiet-confirm.py',launcher)
with tarfile.open(quiet/'observations.tar.xz') as saved:
    raw=saved.extractfile('confirmation/confirmation.json').read()
save(out/'verified-raw-replicas.json',[dict(location='shared-callable-layout-b1672-20261125',bytes=len(raw),
    archiveSHA256=terminal['archiveSHA256'],rawSHA256=hashlib.sha256(raw).hexdigest())])
report=(lab/'archive.py').read_text(encoding='utf-8').replace('lab/"comparison/quiet"','lab/"confirmation"')
report=report.replace('2026-11-25-shared-callable-layout"','2026-11-25-shared-callable-layout/confirmation"')
report=report.replace('receipt["warmJobs"]==6','receipt["warmJobs"]==3').replace('timedBatches=168,lanes=6','timedBatches=84,lanes=3')
compile(report,'archive-confirmation.py','exec')
write(lab/'archive-confirmation.py',report)
