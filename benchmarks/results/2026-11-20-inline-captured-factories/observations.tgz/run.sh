set -eu
root=/home/lokad/lython-bench-checks/inline-captured-factories-b1206-20261120
trap 'result=$?; printf "%s\n" "$result" > "$root/exit-code.txt"' EXIT
python3 "$root/collect.py"
