from pathlib import Path
import hashlib,json,os,shutil,subprocess

lab=Path(__file__).resolve().parent
cases={'conditional-cell-and-rebinding': 'def factory(value, install):\n    if not install:\n        return value\n    def first(): return value\n    value += 2\n    def second(): return value\n    return first, second\nprint(factory(10, False))\na,b=factory(10,True)\nprint(a(),b())\n', 'forwarding-through-nested-definition': 'def factory(value):\n    def middle(other):\n        def read(): return value, other\n        other += 1\n        return read\n    value += 1\n    return middle\nfirst = factory(4)(6)\nsecond = factory(9)(11)\nprint(first(),second(),first())\n', 'deletion-after-capture': "def factory(value):\n    def read(): return value\n    del value\n    return read\nread=factory(8)\ntry:read()\nexcept NameError: print('unbound')\n", 'binding-via-loop-target': 'def factory():\n    result=[]\n    for index in range(3):\n        def read(): return index\n        result.append(read)\n    return result\nprint([read() for read in factory()])\n', 'partial-capture-then-slow-definition': 'def factory(value):\n    second=4\n    def plain(): return value\n    def decorate(function): return function\n    @decorate\n    def decorated(): return value, second\n    value=5\n    second=7\n    return plain,decorated\na,b=factory(6)\nprint(a(),b())\n', 'retained-callable-from-protected-prefix': 'def factory(value):\n    def read(): return value\n    try:\n        value += 4\n        return read\n    finally:\n        value += 8\nprint(factory(1)())\n'}
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
sdk=Path.home()/'.dotnet11'
env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk),PATH=str(sdk)+os.pathsep+os.environ['PATH'])
probe=lab.parent/'format-continuation-scratch/probe/candidate'
pair=load(lab/'frozen-identity.json')
body=json.dumps(list(cases.values())).encode('utf-8')
(lab/'probe-cases.json').write_bytes(body)
for role,files in pair['images'].items():
    source=lab/'frozen'/role
    assert len(files)==32 and {n:sha(source/n) for n in files}==files
    image=lab/'probe'/role
    shutil.copytree(probe,image,dirs_exist_ok=True)
    for file in image.glob('Lokad.*.dll'):
        if file.name in files:
            shutil.copyfile(source/file.name,file)
            assert sha(file)==files[file.name]
    assert sha(image/'Lokad.Lython.dll')==files['Lokad.Lython.dll']
    for async_mode in (False,True):
        args=[sdk/'dotnet.exe',image/'LythonProbe.dll','--batch-json','--compare-python','--python','C:/Python313/python.exe']
        if async_mode:args.append('--async')
        process=subprocess.run(args,input=body,capture_output=True,timeout=55,env=env)
        (lab/f'probe-{role}-{async_mode}.jsonl').write_bytes(process.stdout)
        assert process.returncode==0,(role,async_mode,process.stderr.decode(),process.stdout.decode())
        reports=[json.loads(line) for line in process.stdout.splitlines()]
        assert len(reports)==len(cases) and all(row['Matches'] and row['Compared'] for row in reports)
print(f'{len(cases)} CPython semantic probes pass in sync and async modes for both source images.')
