from pathlib import Path
import hashlib,json,shutil,tarfile

lab=Path(__file__).resolve().parent
initial=lab.parent/'current-compile-attribution-r588'
target=Path('benchmarks/results/2026-11-18-current-compile-attribution')
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()

for directory,wanted in [(initial,False),(lab,True)]:
    receipt=read(directory/'archive-receipt.json')
    term=read(directory/'terminal-status.json')
    assert receipt['complete'] is wanted and term['receipt']==receipt
    assert term['exitCode']==('0' if wanted else '1')
    assert not term['remainingWorkers'] and not term['remainingTrace']
    assert all(receipt[k] for k in ('allWorkersJoined','quietBeforeAndAfter','guestFixturesRemoved',
        'archivedAndVerifiedUnderLease','ramTraceArchivedAndVerifiedBeforeUnmount'))
    assert sha(directory/'observations.tgz')==receipt['archiveSHA256']
    for name in ('identity.json','catalog.json','ops-profile.py','collect.py','run.sh'):
        assert sha(directory/name)==sha(directory/'retrieved'/name)
assert sha(lab/'identity.json')==sha(initial/'identity.json')
assert sha(lab/'catalog.json')==sha(initial/'catalog.json')
before=read(initial/'retrieved/profiles/manifest/record.json')
warmups=before['warmupBatches']
assert len(warmups)==128 and before['count']==256
assert abs(sum(row['elapsedTicks']/row['clockFrequency'] for row in warmups)-7.869925685)<1e-8
assert [job['case'] for job in read(lab/'attribution.json')['rows']]==[
    'scripts.config-manifest.small','scripts.config-generated-guards.medium']
for directory,path in [(initial,target/'initial'),(lab,target)]:
    path.mkdir(parents=True,exist_ok=True)
    for name in ('observations.tgz','archive-receipt.json','terminal-status.json'):
        shutil.copyfile(directory/name,path/name)
shutil.copyfile(lab/'attribution.json',target/'attribution.json')
with tarfile.open(target/'checks-and-procedures.tar.xz','w:xz',preset=6) as bundle:
    for role,directory in [('initial',initial),('confirmation',lab)]:
        for name in ('prepare.py','launch.py','retrieve.py','verify.json','verify.log','config.json','remote-launch.py','observe-not-before.json'):
            bundle.add(directory/name,arcname=f"{role}/{name}")
    bundle.add(lab/'analyze.py',arcname='confirmation/analyze.py')
    bundle.add(lab/'archive.py',arcname='confirmation/archive.py')
