from pathlib import Path
import bisect,collections,gzip,json,re
r=Path(__file__).parent;out=[]
for label in ['manifest','generated']:
 f=r/'retrieved/profiles'/label;record=json.loads((f/'record.json').read_text(encoding='utf-8'));ranges=[];malformed=[]
 for line in gzip.open(f/'perf.map.gz','rt',encoding='utf-8').read().splitlines(keepends=True):
  parts=line.rstrip().split(' ',2)
  if len(parts)!=3 or not line.endswith('\n'):malformed.append(line);continue
  start,size,name=parts;ranges.append((int(start,16),int(size,16),name))
 ranges=sorted(set(ranges));starts=[row[0]for row in ranges];prefix=[]
 for start,size,name in ranges:prefix.append(max(start+size,prefix[-1]if prefix else 0))
 def symbol(address,fallback):
  index=bisect.bisect_right(starts,address)-1;matches=set()
  while index>=0 and prefix[index]>address:
   start,size,name=ranges[index]
   if start<=address<start+size:matches.add(name)
   index-=1
  return next(iter(matches))if len(matches)==1 else'[ambiguous] '+repr(sorted(matches))if matches else fallback
 samples=[];current=None
 for line in gzip.open(f/'all-thread-stacks.txt.gz','rt',encoding='utf-8').read().splitlines():
  header=re.match(r'^.*?\s(\d+)\s+\d+\.\d+:\s+\d+\s+cpu-clock:',line)
  if header:
   current=[]if header[1]in record['activeCpuTids']else None
   if current is not None:samples.append(current)
   continue
  frame=re.match(r'^\s+([0-9a-f]+)\s+(.*)$',line)
  if current is not None and frame:current.append(symbol(int(frame[1],16),frame[2]))
 leaves=collections.Counter(s[0]for s in samples if s);nearest=collections.Counter(next((n for n in s if'Lokad.Lython.'in n),'[no Lython frame]')for s in samples if s);phases=collections.Counter();regionOwners=collections.Counter()
 for stack in samples:
  phase='other/CLR/protocol';owner=None
  for name in stack:
   method = name.split('(', 1)[0]
   if any(x in method for x in ['ExecutableStackLayout','ExecutableCodeObject','ExecutableScript']):phase='executable preparation';owner=name;break
   if any(x in method for x in ['LoweredScript','LoweredStatement']):phase='lowering';owner=name;break
   if any(x in method for x in ['StaticBindingEngine','StaticAnalyzer','StaticAnalysisContext','AnnotationDiagnostics','StaticNameBinding','StaticAbstractInterpreter','StaticAbstractValueResolver','AbstractState','StaticValue','StaticExpression','AbstractValue','AbstractBinding','StaticControlFlow']):phase='static/annotation analysis';owner=name;break
   if any(x in method for x in ['LexicalScopePreparation','ScopeDirectiveFacts','ScopeValidity','SyntaxValidity']):phase='scope/syntax facts';owner=name;break
   if any(x in method for x in ['.Parser','PythonTokenization','TokenizedSource']):phase='parse/tokenization';owner=name;break
  phases[phase]+=1
  if owner is not None:regionOwners[owner]+=1
 out.append(dict(case=record['workload'],activeCpuTids=record['activeCpuTids'],threadCpuSeconds=record['threadCpuSeconds'],sampleCount=len(samples),unmappedLeafSamples=sum(v for k,v in leaves.items()if'[unknown]'in k),ambiguousLeafSamples=sum(v for k,v in leaves.items()if k.startswith('[ambiguous]')),phaseOwners=phases.most_common(),nearestLythonFrame=nearest.most_common(35),topLeaves=leaves.most_common(35),phaseOwnerMethods=regionOwners.most_common(35),malformedMapLines=malformed,compileInvocations=record['response']['completedInvocations'],compiledClockSeconds=record['response']['elapsedTicks']/record['response']['clockFrequency']))
(r/'attribution.json').write_text(json.dumps(dict(kind='Diagnostic sampled CPU, nearest phase owners include useful/inlined work; not exclusive cost/removable shares or a timing comparison.',rows=out),indent=2)+'\n',encoding='utf-8',newline='\n')
for row in out:print(row['case'],row['sampleCount'],'samples; phases',row['phaseOwners'],'unknown',row['unmappedLeafSamples'],'ambiguous',row['ambiguousLeafSamples'])

