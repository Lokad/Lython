from pathlib import Path
import json, sys, tarfile, hashlib, os, subprocess

lab = Path(__file__).resolve().parent
previous = lab.parent / 'post-transport-attribution-r586'
donor = lab.parent / 'trailing-keyword-operands-r587'
archive = lab.parent / 'frontend-regions-r412'
load = lambda p: json.loads(p.read_text(encoding='utf-8-sig'))
def write(name, value):
    if name.endswith('.py'): compile(value,name,'exec')
    (lab/name).write_text(value,encoding='utf-8',newline='\n')
def save(name, value): write(name,json.dumps(value,ensure_ascii=False,indent=2)+'\n')
sha = lambda b: hashlib.sha256(b).hexdigest()
role, revision = sys.argv[1:3]
assert role in ['candidate','reference']
donor_config = load(donor/'quiet/config.json')
donor_manifest = load(donor/'frozen-identity.json')
terminal = load(donor/'quiet/terminal-status.json')
assert terminal['receipt']['complete'] and terminal['exitCode'] == '0' and not terminal['remainingWorkers']
assert sha((donor/'quiet/observations.tgz').read_bytes()) == terminal['receipt']['archiveSHA256']
image = donor/'frozen'/role
files = donor_manifest['images'][role]
assert len(files)==32 and {name:sha((image/name).read_bytes()) for name in files}==files
old_catalog = load(archive/'catalog.json')
ids = {'scripts.config-manifest.small','scripts.config-generated-guards.medium'}
old_catalog['cases'] = [case for case in old_catalog['cases'] if case['id'] in ids]
assert len(old_catalog['cases'])==2
save('catalog.json',old_catalog)
catalog_hash=sha((lab/'catalog.json').read_bytes())

sdk = Path.home()/'.dotnet11'
dotnet = sdk/'dotnet.exe'
env = dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk),PATH=str(sdk)+os.pathsep+os.environ['PATH'])
with (lab/'verify.log').open('wb') as out:
    subprocess.run([dotnet,image/'Lokad.Lython.Benchmarks.dll','--compare','verify','--catalog',lab/'catalog.json',
                    '--dotnet',dotnet,'--python','C:/Python313/python.exe','--python-worker',Path.cwd()/'benchmarks/cpython-worker.py',
                    '--out',lab/'verify.json'],env=env,stdout=out,stderr=subprocess.STDOUT,check=True,timeout=90)
verified=load(lab/'verify.json')
assert verified['state']=='Completed' and verified['catalogSha256']==catalog_hash
before=load(previous/'config.json')
root='/home/lokad/lython-bench-checks/current-compile-attribution-b1013-20261118'
unit='lython-b1013-current-compile-attribution-20261118'
core=files['Lokad.Lython.dll']
identity=dict(sourceRevision=revision,coreSHA256={'candidate':core},imageFiles={'candidate':files},
              purpose='Public compilation for manifest and generated guards',catalogSHA256=catalog_hash,
              diagnosticOnly=True,publicationHeld=True)
save('identity.json',identity)
jobs = [('manifest','scripts.config-manifest.small','compile'),('generated','scripts.config-generated-guards.medium','compile')]
ops = (previous/'ops-profile.py').read_text(encoding='utf-8').replace(before['root'],root)
i=ops.index('    for name, case_id, lane in ')
j=ops.index(':\n',i)
ops=ops[:i]+'    for name, case_id, lane in '+repr(jobs)+ops[j:]
ops=ops.replace('count = 256','count = 256 if name == "manifest" else 64')
write('ops-profile.py',ops)
collect = (previous/'collect.py').read_text(encoding='utf-8').replace(before['root'],root).replace(
    "['forwarding', 'mutable']", "['manifest', 'generated']")
lines = collect.splitlines(keepends=True)
for i,line in enumerate(lines):
    if 'R586/B1011' in line:
        lines[i] = line.replace('R586/B1011','R588/B1013').replace(before['identity']['sourceRevision'],revision).replace('d1b9f71b forwarding CPU attribution',core[:8]+' compilation CPU attribution')
collect=''.join(lines)
assert 'B1013' in collect
write('collect.py',collect)
write('run.sh',(previous/'run.sh').read_text(encoding='utf-8').replace(before['root'],root))
write('retrieve.py',(previous/'retrieve.py').read_text(encoding='utf-8'))
write('launch.py',(previous/'launch.py').read_text(encoding='utf-8').replace('Post-transport forwarding CPU attribution','Current public-compile CPU attribution'))
with tarfile.open(lab/'payload.tgz','w:gz') as tar:
    for n in ['identity.json','catalog.json','ops-profile.py','collect.py','run.sh']:tar.add(lab/n,arcname=n)
expanded = sum((lab/n).stat().st_size for n in ['identity.json','catalog.json','ops-profile.py','collect.py','run.sh'])
config = dict(root=root,unit=unit,source=donor_config['root'],sourceFiles=files,sourceCatalogSHA256=donor_config['catalogSHA256'],
              catalogSHA256=catalog_hash,identity=identity,retireGroups=[],payloadBytes=(lab/'payload.tgz').stat().st_size,
              payloadSHA256=sha((lab/'payload.tgz').read_bytes()),unpackedBytes=expanded)
save('config.json',config)
code=(previous/'remote-launch.py').read_text(encoding='utf-8')
i=code.index('\nc=')+1
j=code.index('\nb=Path(')
code=code[:i]+'c='+repr(config)+code[j:]
code=code.replace('lython-b1011-fixtures','lython-b1013-fixtures')
if role=='reference':
    code=code.replace("source/'candidate'/", "source/'reference'/")
write('remote-launch.py',code)
print('Verified both compile catalogs and the full frozen worker image',core[:8],flush=True)
