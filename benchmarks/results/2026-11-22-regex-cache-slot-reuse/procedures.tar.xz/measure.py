from pathlib import Path
import hashlib,json,os,shutil,statistics,subprocess

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
old=lab.parent/"short-borrowed-text-probe-20261122"/"comparison"
prev=lab.parent/"regex-adapter-operation-state-20261122"/"comparison"
read=lambda path:json.loads(path.read_text(encoding="utf-8-sig"))
sha=lambda path:hashlib.sha256(path.read_bytes()).hexdigest()
digest=lambda s:hashlib.sha256(s.encode("utf-8")).hexdigest()
save=lambda p,o:p.write_text(json.dumps(o,ensure_ascii=False,indent=2)+"\n",encoding="utf-8",newline="\n")
out=lab/"allocation"
out.mkdir(exist_ok=True)
assert not any(out.iterdir())
prior=read(old/"quiet/identity.json")
original=old/"frozen-candidate"
manifest=prior["imageFiles"]["candidate"]
assert len(manifest)==32 and {n:sha(original/n) for n in manifest}==manifest
source="""import re
total = 0
for turn in range(2):
    for i in range(640):
        pattern = re.compile(f'rule_{i}:(?P<word>[a-z]+)')
        text = f'rule_{i}:abc'
        if i == 0 and turn == 0:
            saved = pattern
        total += len(pattern.fullmatch(text).group('word'))
    re.purge()
print(total, saved.fullmatch('rule_0:abc').groupdict())
"""
template=read(old/"representative.json")
starter=read(prev/"catalog.json")
controls=[r for r in starter["cases"] if "rule" in r["id"] or "ascii" in r["id"]]
assert controls,[r["id"] for r in starter["cases"]]
want="3840 {'word': 'abc'}\n"
fixture='{"size":1280,"text":null}'
churn=dict(id="scripts.regex-cache.compile-evict-purge",family="scripts",category="whole-script",scale="two-batches",size=1280,
           source=source,fixtureJson=fixture,expectedOutput=want,sourceUtf8Bytes=len(source.encode()),
           expectedOutputUtf8Bytes=len(want.encode()),fixtureTextUtf8Bytes=0,fixtureTextCodePoints=0,
           sourceSha256=digest(source),fixtureSha256=digest(fixture),expectedOutputSha256=digest(want))
template["cases"]=[churn,*controls[:2]]
template["performanceQualified"]=False
catalog=out/"representative.json"
save(catalog,template)
sdk=Path.home()/".dotnet11"
dotnet=sdk/"dotnet.exe"
env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk),PATH=str(sdk)+os.pathsep+os.environ["PATH"])
protocol=repo/"benchmarks/cpython-worker.py"
assert sha(protocol)==prior["protocolSHA256"]
core="Lokad.Lython.dll"
candidate=lab/"windows/bin/Lokad.Lython/release_net11.0"/core
results={}
hashes={}
for role in ("reference","candidate"):
    image=out/f"frozen-{role}"
    image.mkdir()
    paths={n:candidate if n==core and role=="candidate" else original/n for n in manifest}
    for ext in (".dll",".deps.json",".runtimeconfig.json"):
        name="ValidatedAllocation"+ext
        paths[name]=original/name
    for name,path in paths.items():
        shutil.copyfile(path,image/name)
    hashes[role]={n:sha(p) for n,p in paths.items()}
    assert {n:sha(image/n) for n in paths}==hashes[role]
    report=out/f"{role}-verify.json"
    subprocess.run([dotnet,image/"Lokad.Lython.Benchmarks.dll","--compare","verify","--catalog",catalog,
        "--dotnet",dotnet,"--python","C:/Python313/python.exe","--python-worker",protocol,"--out",report],
        env=env,cwd=repo,check=True,timeout=90)
    assert read(report)["state"]=="Completed" and read(report)["caseCount"]==len(template["cases"])
    report=out/f"{role}-allocation.json"
    subprocess.run([dotnet,image/"ValidatedAllocation.dll",image,catalog,report],
        env=env,cwd=repo,check=True,timeout=85)
    assert {n:sha(image/n) for n in paths}==hashes[role]
    results[role]=read(report)["rows"]
save(out/"images.json",hashes)
assert all(r["sharedBudgetBaselineRestored"] for values in results.values() for r in values)
for before,after in zip(results["reference"],results["candidate"],strict=True):
    assert before["id"]==after["id"] and before["asynchronous"]==after["asynchronous"]
    assert before["peakExecutionMemoryBytes"]==after["peakExecutionMemoryBytes"]
    a,b=(statistics.median(x["allocatedBytesPerInvocation"]) for x in (before,after))
    print(before["id"], "async =",before["asynchronous"], "bytes",a,b,"delta",b-a,"pct",100*(b/a-1),flush=True)
