from pathlib import Path
import fcntl,json,os,subprocess,time,tarfile,hashlib,shutil,traceback
root=Path('/home/lokad/lython-bench-checks/current-lexical-costs-b1054-20261119')
with(root.parent/'comparison-vm.lock').open('a')as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 env=os.environ.copy();env['DOTNET_ROOT']='/home/lokad/lython-bench-toolchains/dotnet/11.0.100-rc.3.26522.148'
 worker=root/'candidate/Lokad.Lython.Benchmarks.dll';dotnet=env['DOTNET_ROOT']+'/dotnet'
 failed=None;before=after=False
 try:
  time.sleep(3)
  subprocess.run([dotnet,str(worker),'--compare','check-machine','--out',str(root/'machine-before.json')],env=env,check=True)
  before=json.loads((root/'machine-before.json').read_text())['gate']['quiet'];assert before
  subprocess.run(['python3',str(root/'ops-profile.py'),str(root/'guest-fixtures/profiles')],check=True)
 except BaseException:
  failed=traceback.format_exc();(root/'failure.txt').write_text(failed)
 finally:
  # The profiler joins users even after failure. Do not unmount live users.
  assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record'],capture_output=True).returncode==1
  time.sleep(3)
  subprocess.run([dotnet,str(worker),'--compare','check-machine','--out',str(root/'machine-after.json')],env=env,check=True)
  after=json.loads((root/'machine-after.json').read_text())['gate']['quiet']
  fixture=root/'guest-fixtures';trace=fixture/'profiles'
  manifest=[]
  for p in fixture.rglob('*'):
   m=p.lstat();assert not p.is_symlink()and m.st_uid==os.getuid()
   manifest.append(dict(path=p.relative_to(fixture).as_posix(),bytes=m.st_size,mode=oct(m.st_mode),uid=m.st_uid))
  (root/'ram-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
  raw={p.relative_to(fixture).as_posix():hashlib.sha256(p.read_bytes()).hexdigest()for p in fixture.rglob('*')if p.is_file()}
  with tarfile.open(root/'observations.tgz','w:gz',dereference=True)as archive:
   for p in sorted(root.iterdir()):
    if p.is_file()and p.name!='observations.tgz':archive.add(p,arcname=p.name)
   for name in raw:archive.add(fixture/name,arcname=name)
  with tarfile.open(root/'observations.tgz')as archive:
   for name,sha in raw.items():assert hashlib.sha256(archive.extractfile(name).read()).hexdigest()==sha
  subprocess.run(['sudo','-n','umount',str(fixture)],check=True);fixture.rmdir()
  assert shutil.disk_usage(root).free>228589568
  records=[json.loads(p.read_text())for p in []] # RAM evidence now immutable in the archive.
  with tarfile.open(root/'observations.tgz')as archive:
   for name in ['rules', 'captured', 'mutable']:
    try:records.append(json.loads(archive.extractfile('profiles/'+name+'/record.json').read()))
    except KeyError:pass
  complete=not failed and before and after and len(records)==3 and all(v['exitCode']==0 and v['closed']['status']=='Closed'for v in records)
  receipt=dict(complete=complete,allWorkersJoined=True,quietBeforeAndAfter=before and after,guestFixturesRemoved=True,archivedAndVerifiedUnderLease=True,ramTraceArchivedAndVerifiedBeforeUnmount=True,freeBytes=shutil.disk_usage(root).free,archiveSHA256=hashlib.sha256((root/'observations.tgz').read_bytes()).hexdigest(),source='R623/B1054 68a7fc465 rule and capture attribution',performanceComparison=False,failure=failed)
  (root/'archive-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt))
 if not complete:raise RuntimeError('Preserved and cleaned inconclusive/failed attribution; inspect immutable evidence.')
