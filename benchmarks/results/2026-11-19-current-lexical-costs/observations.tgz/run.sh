set -eu
root=/home/lokad/lython-bench-checks/current-lexical-costs-b1054-20261119
trap 'result=$?; printf "%s\n" "$result" > "$root/exit-code.txt"' EXIT
python3 "$root/collect.py"
