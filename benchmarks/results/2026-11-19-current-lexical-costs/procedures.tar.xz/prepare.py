from pathlib import Path
import ast,hashlib,json,os,subprocess,tarfile

lab=Path(__file__).resolve().parent
prior=lab.parent/'current-frame-costs-r606'
donor=lab.parent/'standalone-capture-cells-r622'
read=lambda p:p.read_text(encoding='utf-8-sig')
load=lambda p:json.loads(read(p))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def write(name,body):
    if name.endswith('.py'):ast.parse(body)
    (lab/name).write_text(body,encoding='utf-8',newline='\n')
def save(name,data):write(name,json.dumps(data,ensure_ascii=False,indent=2)+'\n')
old=load(prior/'config.json')
stage=load(donor/'quiet/config.json')
frozen=donor/'frozen/candidate'
files=stage['identity']['imageFiles']['candidate']
assert len(files)==32 and {name:sha(frozen/name) for name in files}==files
assert not subprocess.check_output(['git','diff','--name-only','6165aa771','68a7fc465','--','src','tests'])
retained=load(Path('benchmarks/results/2026-11-19-standalone-capture-cells/summary.json'))
assert retained['retainedCommit']=='68a7fc465' and retained['cores']['candidate']==files['Lokad.Lython.dll']
labels=['rules','captured','mutable']
variants=['scripts.rule-default-closures','scripts.captured-rule-closures','scripts.mutable-rule-counters']
catalog=load(donor/'catalog.json')
catalog['cases']=[next(c for c in catalog['cases'] if c['id']==name) for name in variants[:2]]
case=catalog['cases'][1].copy()
case.update(id=variants[2],source='''def make_counter(seed):
    offset = seed % 13
    count = 0
    def apply(record):
        nonlocal count
        count += 1
        return record + offset + count
    return apply

total = 0
for index in range(2048):
    apply = make_counter(index)
    total += apply(index) + apply(index + 1)
print(total)
''')
python=Path('C:/Python313/python.exe')
case['expectedOutput']=subprocess.check_output([python,'-I','-S','-X','utf8','-c',case['source']]).decode().replace('\r\n','\n')
for field in ('source','expectedOutput'):
    value=case[field].encode('utf-8')
    case[field+'Utf8Bytes']=len(value)
    case[field+'Sha256']=hashlib.sha256(value).hexdigest()
catalog['cases'].append(case)
save('catalog.json',catalog)
identity=dict(sourceRevision='68a7fc465',purpose='R623 current rule definition and mutable capture attribution',
    coreSHA256=dict(candidate=files['Lokad.Lython.dll']),imageFiles=dict(candidate=files),
    catalogSHA256=sha(lab/'catalog.json'),diagnosticOnly=True,publicationHeld=True)
save('identity.json',identity)
root='/home/lokad/lython-bench-checks/current-lexical-costs-b1054-20261119'
unit='lython-b1054-current-lexical-costs-20261119'
low=218*1024*1024
jobs=[(label,case,'warm') for label,case in zip(labels,variants,strict=True)]
profile=read(prior/'ops-profile.py').replace(old['root'],root)
a,b=profile.index("[('rules',"),profile.index(")]",profile.index("[('rules',"))+2
profile=profile[:a]+repr(jobs)+profile[b:]
write('ops-profile.py',profile)
collect=read(prior/'collect.py').replace(old['root'],root).replace("['rules', 'annotated', 'forwarding']",repr(labels))
collect=collect.replace('252*1024*1024',str(low)).replace('R606/B1033 e93356adc/b21ca2e4 frame and rule attribution','R623/B1054 68a7fc465 rule and capture attribution')
write('collect.py',collect)
write('run.sh',read(prior/'run.sh').replace(old['root'],root))
write('launch.py',read(prior/'launch.py').replace('Current frame attribution','Current lexical capture attribution'))
write('retrieve.py',read(prior/'retrieve.py'))
write('analyze.py',read(prior/'analyze.py').replace("['rules', 'annotated', 'forwarding']",repr(labels)))
names=['identity.json','catalog.json','ops-profile.py','collect.py','run.sh']
payload=lab/'payload.tgz'
with tarfile.open(payload,'w:gz') as stream:
    for name in names:stream.add(lab/name,arcname=name)
size=sum((lab/name).stat().st_size for name in names)
assert load(lab/'quiet-space.json')['freeBytes']>low+size+524288
config=dict(root=root,unit=unit,source=stage['root'],sourceFiles=files,sourceCatalogSHA256=stage['catalogSHA256'],
    catalogSHA256=identity['catalogSHA256'],identity=identity,retireGroups=[],payloadBytes=payload.stat().st_size,
    payloadSHA256=sha(payload),unpackedBytes=size)
save('config.json',config)
launcher=read(prior/'remote-launch.py')
a,b=launcher.index('\nc=')+1,launcher.index('\nb=Path(')
launcher=(launcher[:a]+'c='+repr(config)+launcher[b:]).replace('lython-b1033-fixtures','lython-b1054-fixtures')
write('remote-launch.py',launcher.replace('254*1024*1024',str(low)))
sdk=Path.home()/'.dotnet11'
dotnet=sdk/'dotnet.exe'
env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk),PATH=str(sdk)+os.pathsep+os.environ['PATH'])
with (lab/'verify.log').open('wb') as log:
    subprocess.run([dotnet,frozen/'Lokad.Lython.Benchmarks.dll','--compare','verify','--catalog',lab/'catalog.json',
        '--dotnet',dotnet,'--python',python,'--python-worker',Path.cwd()/'benchmarks/cpython-worker.py','--out',lab/'verify.json'],
        env=env,stdout=log,stderr=subprocess.STDOUT,timeout=90,check=True)
result=load(lab/'verify.json')
assert result['state']=='Completed' and result['catalogSha256']==identity['catalogSHA256']
assert {name:sha(frozen/name) for name in files}==files
print('Verified the retained 32-file image and all three rule goldens.')
