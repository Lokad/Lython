from hashlib import sha256
from pathlib import Path
from statistics import median
import json
import os
import subprocess

lab = Path(__file__).resolve().parent
catalog_path = lab.parent / 'post-ready-insertion-cpython-20261127/comparison/quiet/representative.json'
catalog = json.loads(catalog_path.read_bytes())
case = dict(next(c for c in catalog['cases'] if c['id'] == 'diagnostic.generated-ordinary-definitions'))
source = "import json\nprint(json.dumps('a' * 96))\n"
python = Path('C:/Python313/python.exe')
output = subprocess.check_output([python,'-I','-X','utf8','-c',source],timeout=10).decode('utf-8').replace('\r\n','\n')
fixture = json.dumps(dict(size=96,text=None),separators=(',',':'))
case.update(id='diagnostic.json-plain-root-string-96',source=source,sourceUtf8Bytes=len(source.encode()),
    sourceSha256=sha256(source.encode()).hexdigest(),size=96,fixtureJson=fixture,fixtureSha256=sha256(fixture.encode()).hexdigest(),
    expectedOutput=output,expectedOutputUtf8Bytes=len(output.encode()),expectedOutputSha256=sha256(output.encode()).hexdigest())
catalog['cases'] = [case]
sdk=Path.home()/'.dotnet11'
dotnet=sdk/'dotnet.exe'
env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk))
workspace=lab/'allocation'
write=lambda path,data:path.write_text(json.dumps(data,indent=2)+'\n',encoding='utf-8',newline='\n')
results=[]
for mode in ('sync','async'):
    case['runAsync']=mode=='async'
    manifest=workspace/f'plain-storage-{mode}.json'
    write(manifest,catalog)
    pair=[]
    for role in ('reference','candidate'):
        folder=workspace/role
        report=workspace/f'{role}-plain-storage-{mode}.json'
        subprocess.run([dotnet,folder/'ValidatedAllocation.dll',folder,manifest,report],env=env,check=True,timeout=35)
        row,=json.loads(report.read_bytes())['rows']
        assert row['sharedBudgetBaselineRestored'] and row['id']==case['id']
        pair.append(dict(clr=median(row['allocatedBytesPerInvocation']),peak=row['peakExecutionMemoryBytes']))
    results.append(dict(mode=mode,reference=pair[0],candidate=pair[1]))
    print(results[-1])
write(workspace/'plain-storage-summary.json',results)
