from hashlib import sha256
from pathlib import Path
from statistics import median
import json
import os
import shutil
import subprocess

lab = Path(__file__).resolve().parent
notes = lab.parent
repo = lab.parents[3]
prior = notes / 'csv-dictwriter-direct-fields-20261127'
first = notes / 'json-quoted-token-windows-20261127/comparison/local'
workers = lab / 'comparison/local'
allocation = lab / 'allocation'
workers.mkdir(parents=True)
allocation.mkdir()
read = lambda p: json.loads(p.read_text(encoding='utf-8-sig'))
write = lambda p, value: p.write_text(json.dumps(value, indent=2, ensure_ascii=False) + '\n', encoding='utf-8', newline='\n')
sha = lambda p: sha256(p.read_bytes()).hexdigest()
image = lambda p: {f.name: sha(f) for f in p.iterdir()}
core = 'Lokad.Lython.dll'
worker = 'Lokad.Lython.Benchmarks.dll'
python = Path('C:/Python313/python.exe')
sdk = Path.home() / '.dotnet11'
dotnet = sdk / 'dotnet.exe'
env = dict(os.environ, DOTNET_ROOT=str(sdk), DOTNET_ROOT_X64=str(sdk))
pinned = read(repo/'benchmarks/results/2026-11-27-csv-dictwriter-direct-fields/identity.json')
base = subprocess.check_output(['git','rev-parse','43ef47bba'],cwd=repo,text=True).strip()
assert not subprocess.check_output(['git','diff','--name-only',base,'HEAD','--','src'],cwd=repo)
assert sha256(subprocess.check_output(['git','diff','--binary',pinned['sourceRevision'],base,'--','src'],cwd=repo)).hexdigest()==pinned['sourcePatchSHA256']
patch=subprocess.check_output(['git','diff','--binary','HEAD','--','src'],cwd=repo)
assert b'CreateJsonStringSpecialBytes' in patch and patch.count(b'diff --git ')==1
(lab/'candidate.patch').write_bytes(patch)
original=prior/'comparison/local'
assert image(original/'candidate')==pinned['imageFiles']['candidate']
for role in ('reference','candidate'):
    shutil.copytree(original/'candidate',workers/role)
fresh=repo/'src/Lokad.Lython/bin/Release/net11.0'/core
assert sha(fresh)==sha(repo/'tests/Lokad.Lython.PublicApi.Tests/bin/Release/net11.0'/core)
shutil.copyfile(fresh,workers/'candidate'/core)
images={role:image(workers/role) for role in ('reference','candidate')}
assert [name for name, digest in images['reference'].items() if images['candidate'][name]!=digest]==[core]

for name in ('cpython-worker.py','run.sh'):
    shutil.copyfile(original/name,workers/name)
assert b'\r' not in (workers/'run.sh').read_bytes()
catalog=read(first/'representative.json')
assert sha(first/'representative.json')==read(first/'identity.json')['catalogs']['representative.json']['sha256']
shutil.copyfile(first/'representative.json',workers/'representative.json')
jobs=read(first/'jobs.json')['warm']
write(workers/'jobs.json',{'warm':list(reversed(jobs))})
identity=dict(sourceRevision=base,sourcePatchSHA256=sha(lab/'candidate.patch'),productionReference=base,imageFiles=images,
    coreSHA256={role+suffix:files[core] for role,files in images.items() for suffix in ('','-control')},
    comparisonHostRevision=pinned['comparisonHostRevision'],cpythonWorkerSHA256=sha(workers/'cpython-worker.py'),
    independentCPythonVersion=subprocess.check_output([python,'--version'],text=True).strip(),verificationPythonSHA256=sha(python),
    purpose='Compare single-window plain quoted tokens and the existing scalar escape continuation with the production writer.')
identity['catalogs']={name:{'sha256':sha(workers/name)} for name in ('representative.json','jobs.json')}
write(workers/'identity.json',identity)
collector=(original/'collect.py').read_text(encoding='utf-8').replace('lython-b1870-direct-field-fixture-','lython-b1873-plain-token-fixture-')
compile(collector,'collect.py','exec')
(workers/'collect.py').write_text(collector,encoding='utf-8',newline='\n')
for role, files in images.items():
    report=workers/f'{role}-verify.json'
    subprocess.run([dotnet,workers/role/worker,'--compare','verify','--catalog',workers/'representative.json',
        '--dotnet',dotnet,'--python',python,'--python-worker',workers/'cpython-worker.py','--out',report],env=env,check=True,timeout=75)
    proof=read(report)
    assert proof['state']=='Completed' and proof['caseCount']==3
    assert proof['catalogSha256']==identity['catalogs']['representative.json']['sha256']
    assert proof['launched']['adapter']['sha256']==files[worker] and proof['launched']['library']['sha256']==files[core]
    folder=allocation/role
    shutil.copytree(workers/role,folder)
    for path in (prior/'allocation/candidate').glob('ValidatedAllocation*'):
        shutil.copyfile(path,folder/path.name)
    assert all(sha(folder/name)==digest for name,digest in files.items())

rows=[]
for mode in ('sync','async'):
    for case in catalog['cases']:
        case['runAsync']=mode=='async'
    selection=allocation/f'{mode}-catalog.json'
    write(selection,catalog)
    pair=[]
    for role in images:
        folder=allocation/role
        report=allocation/f'{role}-{mode}.json'
        subprocess.run([dotnet,folder/'ValidatedAllocation.dll',folder,selection,report],env=env,check=True,timeout=90)
        pair.append(read(report)['rows'])
    for before, after in zip(*pair,strict=True):
        assert before['id']==after['id'] and before['sharedBudgetBaselineRestored'] and after['sharedBudgetBaselineRestored']
        row=dict(case=before['id'],mode=mode,clr=[median(r['allocatedBytesPerInvocation']) for r in (before,after)],
                peak=[r['peakExecutionMemoryBytes'] for r in (before,after)],compiled=[r['compiledReservedBytes'] for r in (before,after)])
        rows.append(row)
        print(row,flush=True)
write(allocation/'summary.json',rows)
