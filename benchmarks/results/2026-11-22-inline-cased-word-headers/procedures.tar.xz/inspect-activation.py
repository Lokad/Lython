from pathlib import Path
import hashlib,json,os,shutil,subprocess

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
base=lab.parent/"reuse-compiler-block-storage-20261122"
def read(path): return json.loads(path.read_text(encoding="utf-8-sig"))
def write(path,value): path.write_text(json.dumps(value,indent=2)+"\n",encoding="utf-8",newline="\n")
def hashes(root): return {p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in root.iterdir() if p.is_file()}
donor=base/"reference/inspect"
expected=read(base/"inspection-identity.json")["workerImages"]["reference"]["inspect"]
assert hashes(donor)==expected
candidate=lab/"inspect"
shutil.copytree(donor,candidate)
assert hashes(candidate)==expected
source=read(lab/"activation-memory-control/catalog.json")
text_case=next(r for r in read(lab/"comparison/catalog.json")["cases"] if r["id"]=="diagnostic.text-summary.nonlocal-computed-width.large")
source["cases"].append(text_case)
catalog=lab/"activation-inspect-catalog.json"
write(catalog,source)
output=lab/"activation-inspection.json"
sdk=Path.home()/".dotnet11"
env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk),PATH=str(sdk)+os.pathsep+os.environ["PATH"])
subprocess.run([sdk/"dotnet.exe",candidate/"Inspect.dll",catalog,output],env=env,check=True,timeout=35)
r=read(output)
assert r["coreSHA256"]==expected["Lokad.Lython.dll"]
for row in r["rows"]:
 print(row["id"])
 for code in row["codes"]:
    print({key:code[key] for key in ("name","native","nativeEnd","instructions","capacity","closures","calls","opcodeCounts")})
