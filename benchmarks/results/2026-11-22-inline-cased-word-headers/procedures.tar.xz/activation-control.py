from pathlib import Path
import base64
import hashlib
import io
import json
import os
import subprocess

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
out = lab/"activation-control"
out.mkdir(exist_ok=True)
frozen = lab.parent/"record-and-text-profile-20261122/comparison/frozen-candidate"
read = lambda p: json.loads(p.read_text(encoding="utf-8"))
def hash_bytes(data): return hashlib.sha256(data).hexdigest()
identity = read(lab/"comparison/images.json")
files = identity["imageFiles"]["reference"]
def verify_image():
    assert len(files)==32 and {name:hash_bytes((frozen/name).read_bytes()) for name in files}==files
verify_image()
worker = frozen/"Lokad.Lython.Benchmarks.dll"
protocol = repo/"benchmarks/cpython-worker.py"
assert hash_bytes(protocol.read_bytes())==identity["protocolSHA256"]

catalog = read(lab/"comparison/catalog.json")
original = next(r for r in catalog["cases"] if r["id"]=="diagnostic.text-summary.nonlocal-computed-width.large")
spec = json.loads(original["fixtureJson"])
data = base64.b64decode(spec["inputFiles"]["input.txt"],validate=True)
lines = list(io.StringIO(data.decode("utf-8"),newline=None))
assert len(lines)==3072 and len(data)==35840
spec["outputFiles"] = {}
fixture = json.dumps(spec,separators=(",",":"))
gold = f"{sum(len(line)*2+1 for line in lines)}\n"
prefix = """def measure():
    latest_width = 0
"""
body = """    widths = 0
    with open('input.txt') as source:
        for line in source:
            {}
            widths += latest_width
    assert latest_width == 3
    print(widths)

measure()
"""
cases = {
    "inline": ("", "latest_width = len(line)*2+1"),
    "value": ("""    def width_of(line):
        return len(line)*2+1
""", "latest_width = width_of(line)"),
    "captured": ("""    def update_width(line):
        nonlocal latest_width
        latest_width = len(line)*2+1
""", "update_width(line)"),
}
rows=[]
for label,(helper,action) in cases.items():
    code=prefix+helper+body.format(action)
    rows.append(dict(original, id="diagnostic.text-activation."+label, source=code, fixtureJson=fixture,
        expectedOutput=gold, sourceUtf8Bytes=len(code.encode()), expectedOutputUtf8Bytes=len(gold.encode()),
        sourceSha256=hash_bytes(code.encode()), fixtureSha256=hash_bytes(fixture.encode()),
        expectedOutputSha256=hash_bytes(gold.encode()), expectedFilesSha256=hash_bytes(bytes(4))))
catalog["cases"] = rows
manifest = out/"catalog.json"
manifest.write_text(json.dumps(catalog,indent=2)+"\n",encoding="utf-8",newline="\n")
dotnet=Path.home()/".dotnet11/dotnet.exe"
python=Path("C:/Python313/python.exe")
env=dict(os.environ, DOTNET_ROOT=str(dotnet.parent), DOTNET_ROOT_X64=str(dotnet.parent),
    PATH=str(dotnet.parent)+os.pathsep+os.environ["PATH"])
common=["--catalog",manifest,"--dotnet",dotnet,"--python",python,"--python-worker",protocol]
checked=out/"verify.json"
subprocess.run([dotnet,worker,"--compare","verify",*common,"--out",checked],env=env,check=True,timeout=100)
proof=read(checked)
assert proof["state"]=="Completed" and proof["caseCount"]==3 and proof["catalogSha256"]==hash_bytes(manifest.read_bytes())
# Twin workers run the same frozen Lython image. This diagnostic changes
# only the input scripts and retains CPython as a matched control.
reports = []
for round_number, order in enumerate((list(cases),list(reversed(cases)))):
    for label in order:
        row=next(row for row in rows if row["id"].endswith("."+label))
        report = out/f"{round_number}-{label}.json"
        result=subprocess.run([dotnet,worker,"--compare","micro",*common,"--baseline-worker",worker,
            "--lane","warm","--case",row["id"],"--out",report],env=env,capture_output=True,timeout=30)
        (out/f"{round_number}-{label}.log").write_bytes(result.stdout+result.stderr)
        record=dict(round=round_number,case=label,exitCode=result.returncode)
        if result.returncode==0:
            payload=read(report)
            assert payload["state"]=="Completed" and payload["catalogSha256"]==proof["catalogSha256"]
            record["results"]=payload["summaries"]
        reports.append(record)
        print(record,flush=True)
        (out/"summary.json").write_text(json.dumps(reports,indent=2)+"\n",encoding="utf-8",newline="\n")
verify_image()
