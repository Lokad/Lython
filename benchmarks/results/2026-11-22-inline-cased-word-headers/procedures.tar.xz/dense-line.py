from pathlib import Path
from collections import Counter
import base64
import hashlib
import json
import os
import subprocess

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
pair=lab/"comparison"
out=lab/"dense-line"
out.mkdir(exist_ok=True)
def digest(value):return hashlib.sha256(value).hexdigest()
def read(path):return json.loads(path.read_text(encoding="utf-8"))
def write(path, value):path.write_text(json.dumps(value,indent=2)+"\n",encoding="utf-8",newline="\n")
frozen={"reference":lab.parent/"record-and-text-profile-20261122/comparison/frozen-candidate",
        "candidate":pair/"frozen-candidate"}
identity=read(pair/"images.json")
protocol=repo/"benchmarks/cpython-worker.py"
assert digest(protocol.read_bytes())==identity["protocolSHA256"]
catalog=read(pair/"catalog.json")
template=next(row for row in catalog["cases"] if "nonlocal-computed-width" in row["id"])
text="A ß ΟΣ\t"*1365+"\n"
payload=text.encode("utf-8")
count=Counter(text.upper().split())
assert sum(count.values())==4095
source="""def report():
    counts = {}
    total = 0
    with open('input.txt') as source:
        for line in source:
            for word in line.upper().split():
                counts[word] = counts.get(word, 0) + 1
                total += 1
    print(total, counts['A'], counts['SS'], counts['ΟΣ'])

report()
"""
stdout=f"{sum(count.values())} {count['A']} {count['SS']} {count['ΟΣ']}\n"
fixture=json.dumps(dict(size=4095,text=None,inputFiles={"input.txt":base64.b64encode(payload).decode("ascii")},
                         outputFiles={}),separators=(",",":"))
row=dict(template,id="diagnostic.text-summary.dense-line",size=4095,source=source,fixtureJson=fixture,expectedOutput=stdout,
         sourceUtf8Bytes=len(source.encode()),expectedOutputUtf8Bytes=len(stdout.encode()),
         sourceSha256=digest(source.encode()),fixtureSha256=digest(fixture.encode()),expectedOutputSha256=digest(stdout.encode()),
         expectedFilesSha256=digest(bytes(4)))
catalog["cases"]=[row]
manifest=out/"catalog.json"
write(manifest,catalog)
sdk=Path.home()/".dotnet11"
dotnet=sdk/"dotnet.exe"
env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk),PATH=str(sdk)+os.pathsep+os.environ["PATH"])
result={}
for role,image in frozen.items():
    expected=identity["imageFiles"][role]
    def verify():assert len(expected)==32 and {name:digest((image/name).read_bytes())for name in expected}==expected
    verify()
    receipt=out/f"{role}-verify.json"
    subprocess.run([dotnet,image/"Lokad.Lython.Benchmarks.dll","--compare","verify","--catalog",manifest,
        "--dotnet",dotnet,"--python","C:/Python313/python.exe","--python-worker",protocol,"--out",receipt],
        env=env,check=True,timeout=90)
    proof=read(receipt)
    assert proof["state"]=="Completed" and proof["caseCount"]==1 and proof["catalogSha256"]==digest(manifest.read_bytes())
    evidence=out/f"{role}-allocation.json"
    subprocess.run([dotnet,image/"ValidatedAllocation.dll",image,manifest,evidence],env=env,check=True,timeout=90)
    sample,=read(evidence)["rows"]
    assert sample["id"]==row["id"] and sample["sharedBudgetBaselineRestored"]
    result[role]=sample
    verify()
write(out/"summary.json",dict(inputBytes=len(payload),words=4095,images=identity["imageFiles"],result=result))
print({k:(r["allocatedBytesPerInvocation"],r["peakExecutionMemoryBytes"]) for k,r in result.items()})
