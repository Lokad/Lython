#!/bin/bash
set -euo pipefail
cd /mnt/d/code/Lython/.git/agent-worktrees/inline-cased-word-headers-20261122
export DOTNET_ROOT="$HOME/.dotnet"
export PATH="$DOTNET_ROOT:$PATH"
dir=/mnt/d/code/Lython/.git/agent-notes/review-20261031/inline-cased-word-headers-20261122
white='Category!=Stress&(FullyQualifiedName~Cased|FullyQualifiedName~WordBufferLoan|FullyQualifiedName~Whitespace|FullyQualifiedName~NativeTextConstruction|FullyQualifiedName~DictionaryCountingLoopAdmission)'
public='Category!=Stress&(FullyQualifiedName~Cased|FullyQualifiedName~NativeWordBinding|FullyQualifiedName~ReturnedIteration|FullyQualifiedName~Whitespace|FullyQualifiedName~NativeInPlaceDictionary|FullyQualifiedName~StackSafety)'
dotnet test tests/Lokad.Lython.Tests -c Release -f net10.0 --filter "$white" --artifacts-path "$dir/ubuntu" --nologo > "$dir/white-ubuntu.log" 2>&1 || { tail -60 "$dir/white-ubuntu.log"; exit 1; }
dotnet test tests/Lokad.Lython.PublicApi.Tests -c Release -f net10.0 --filter "$public" --artifacts-path "$dir/ubuntu" --nologo > "$dir/public-ubuntu.log" 2>&1 || { tail -60 "$dir/public-ubuntu.log"; exit 1; }
awk '/Passed!/{count++;print} END{exit count!=2}' "$dir/white-ubuntu.log" "$dir/public-ubuntu.log"
