from pathlib import Path
import hashlib
import json
import os
import shutil
import statistics
import subprocess
import tarfile

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
out=lab/"comparison"
out.mkdir(exist_ok=True)
def read(path):return json.loads(path.read_text(encoding="utf-8-sig"))
def sha(blob):return hashlib.sha256(blob).hexdigest()
def save(path,data):path.write_text(json.dumps(data,indent=2)+"\n",encoding="utf-8",newline="\n")
def git(tree,*args):return subprocess.check_output(["git","-C",tree,*args])
history=repo/"benchmarks/results"
previous=read(history/"2026-11-22-unicode-decimal-normalization/source.json")
tree=repo/".git/agent-worktrees/inline-cased-word-headers-20261122"
refs=dict(reference=git(tree,"rev-parse","HEAD^").decode().strip(),candidate=git(tree,"rev-parse","HEAD").decode().strip())
patch=git(tree,"diff","HEAD^","HEAD","--","src","tests")
assert refs["reference"]==previous["candidate"]
assert not git(tree,"status","--porcelain")
(out/"source.patch").write_bytes(patch)
from_archive=[
    ("2026-11-22-computed-capture-stores","diagnostic.text-summary.nonlocal-computed-width.large"),
    ("2026-11-22-computed-capture-stores","scripts.text-summary-helpers.nonlocal-counter.large"),
    ("2026-11-21-cpython-casing-checkpoint","scripts.text-summary-helpers.map-callback.large.mixed-unicode"),
    ("2026-11-22-retained-call-transport-cpython","scripts.csv-invoice.method-policy.quoted-control"),
]
cases=[]
for folder,case in from_archive:
    archive=history/folder/"observations.tgz"
    relative=archive.relative_to(repo).as_posix()
    assert sha(archive.read_bytes())==sha(git(repo,"show","origin/master:"+relative))
    with tarfile.open(archive) as payload:
        catalog=json.load(payload.extractfile("representative.json"))
    cases.append(next(row for row in catalog["cases"] if row["id"]==case))
catalog["cases"]=cases
catalog["performanceQualified"]=False
catalog_path=out/"catalog.json"
save(catalog_path,catalog)
catalog_sha=sha(catalog_path.read_bytes())
core="Lokad.Lython.dll"
new=lab/"frozen-build/bin/Lokad.Lython/release_net11.0"/core
reference=lab.parent/"record-and-text-profile-20261122/comparison/frozen-candidate"
candidate=out/"frozen-candidate"
candidate.mkdir(exist_ok=True)
reference_files=previous["imageFiles"]["candidate"]
assert len(reference_files)==32
for name in reference_files:shutil.copyfile(new if name==core else reference/name,candidate/name)
for path in reference.glob("ValidatedAllocation.*"):shutil.copyfile(path,candidate/path.name)
files=dict(reference=reference_files,candidate=dict(reference_files,**{core:sha(new.read_bytes())}))
assert files["reference"][core]!=files["candidate"][core]
protocol=repo/"benchmarks/cpython-worker.py"
assert sha(protocol.read_bytes())==previous["protocolSHA256"]
sdk=Path.home()/".dotnet11"
dotnet=sdk/"dotnet.exe"
env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk),PATH=str(sdk)+os.pathsep+os.environ["PATH"])
alloc={}
for role,image in (("reference",reference),("candidate",candidate)):
    assert files[role]=={name:sha((image/name).read_bytes())for name in reference_files}
    receipt=out/(role+"-verify.json")
    subprocess.run([dotnet,image/"Lokad.Lython.Benchmarks.dll","--compare","verify","--catalog",catalog_path,
                    "--dotnet",dotnet,"--python","C:/Python313/python.exe","--python-worker",protocol,"--out",receipt],
                   env=env,check=True,timeout=100)
    proof=read(receipt)
    assert proof["state"]=="Completed" and proof["caseCount"]==4 and proof["catalogSha256"]==catalog_sha
    raw=out/(role+"-allocation.json")
    subprocess.run([dotnet,image/"ValidatedAllocation.dll",image,catalog_path,raw],env=env,check=True,timeout=100)
    alloc[role]=read(raw)["rows"]
    assert all(row["sharedBudgetBaselineRestored"] for row in alloc[role])
    assert files[role]=={name:sha((image/name).read_bytes())for name in reference_files}
summary=[]
for a,b in zip(alloc["reference"],alloc["candidate"],strict=True):
    assert a["id"]==b["id"]
    first,second=(statistics.median(row["allocatedBytesPerInvocation"])for row in (a,b))
    summary.append(dict(case=a["id"],reference=first,candidate=second,
                        allocationChangePercent=100*(second/first-1),
                        admittedReference=a["peakExecutionMemoryBytes"],admittedCandidate=b["peakExecutionMemoryBytes"]))
save(out/"allocation-summary.json",summary)
save(out/"images.json",dict(**refs,imageFiles=files,catalogSHA256=catalog_sha,sourcePatchSHA256=sha(patch),
                            protocolSHA256=previous["protocolSHA256"]))
for row in summary:print(row,flush=True)
