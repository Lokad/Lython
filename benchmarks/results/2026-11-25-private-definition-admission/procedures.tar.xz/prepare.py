from pathlib import Path
import hashlib
import json
import os
import shutil
import subprocess
import tarfile

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
tree = repo / ".git/agent-worktrees/private-definition-admission-20261125"
quiet = lab / "comparison/quiet"
quiet.mkdir(parents=True, exist_ok=True)
donor = lab.with_name("direct-record-cpython-20261125")
runner = lab.with_name("csv-direct-record-admission-20261125")
read = lambda path: json.loads(path.read_text(encoding="utf-8-sig"))
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()

def write(path, text):
    path.write_text(text, encoding="utf-8", newline="\n")

def save(path, value):
    write(path, json.dumps(value, indent=2) + "\n")

def git(cwd, *args):
    return subprocess.check_output(["git", *args], cwd=cwd)

base = git(tree, "rev-parse", "HEAD").decode().strip()
old = read(donor / "external/identity.json")
assert git(repo, "diff", "--binary", old["productionSource"], base, "--", "src", "tests") == b""
patch = git(tree, "diff", "--binary", base, "--", "src")
assert patch and patch.count(b"diff --git ") == 7
(lab / "candidate.patch").write_bytes(patch)
(lab / "tests.patch").write_bytes(git(tree, "diff", "--binary", base, "--", "tests"))
frozen = old["imageFiles"]["candidate"]
assert len(frozen) == 32 and {p.name: sha(p) for p in (donor / "candidate").iterdir()} == frozen
core = lab / "bench/bin/Lokad.Lython/release_net11.0/Lokad.Lython.dll"
copied = lab / "bench/bin/Lokad.Lython.Benchmarks/release_net11.0/Lokad.Lython.dll"
assert sha(core) == sha(copied) and sha(core) != frozen[core.name]

images = {"reference": frozen, "candidate": frozen | {core.name: sha(core)}}
for role, files in images.items():
    image = lab / role
    image.mkdir(exist_ok=True)
    for name in files:
        shutil.copyfile(core if role == "candidate" and name == core.name else donor / "candidate" / name, image / name)
    assert {p.name: sha(p) for p in image.iterdir()} == files

ordinary = "diagnostic.generated-ordinary-definitions"
rules = "scripts.rule-default-closures"
eager = "scripts.annotated-rule-closures"
postponed = "scripts.annotated-rule-closures.nested-factories.postponed"
shipment = "diagnostic.shipment-routing-callbacks"
text = "diagnostic.text-summary.nonlocal-computed-width.large"
jobs = [(ordinary, "warm"), (rules, "compile-run"), (eager, "warm"),
        (shipment, "warm-async"), (ordinary, "compile-run"), (postponed, "compile-run"),
        (rules, "warm"), (text, "warm"), (ordinary, "compile")]
catalog = read(donor / "external/representative.json")
other_cases = read(lab.with_name("callable-owned-rollback-20261125") / "comparison/quiet/representative.json")["cases"]
inputs = {c["id"]: c for c in [*other_cases, *catalog["cases"]]}
catalog["cases"] = [inputs[name] for name in dict(jobs)]
assert len(catalog["cases"]) == 6
save(quiet / "representative.json", catalog)
save(quiet / "jobs.json", {"warm": jobs})
identity = dict(sourceRevision=base, comparisonRevision=old["productionSource"], sourcePatchSHA256=sha(lab / "candidate.patch"),
    imageFiles=images, coreSHA256={role + suffix: files[core.name] for role, files in images.items() for suffix in ("", "-control")},
    expectedCPythonSHA256=old["expectedCPythonSHA256"], cpythonWorkerSHA256=old["cpythonWorkerSHA256"],
    catalogs={name: {"sha256": sha(quiet / name)} for name in ("representative.json", "jobs.json")},
    purpose="Prepay the callable with the existing private keyword default owner")
save(quiet / "identity.json", identity)

sdk = Path.home() / ".dotnet11"
dotnet = sdk / "dotnet.exe"
env = dict(os.environ, DOTNET_ROOT=str(sdk), DOTNET_ROOT_X64=str(sdk))
python_worker = repo / "benchmarks/cpython-worker.py"
assert sha(python_worker) == identity["cpythonWorkerSHA256"]
for role, files in images.items():
    evidence = lab / "comparison" / (role + "-verify.json")
    subprocess.run([dotnet, lab / role / "Lokad.Lython.Benchmarks.dll", "--compare", "verify",
                    "--catalog", quiet / "representative.json", "--dotnet", dotnet, "--python", "C:/Python313/python.exe",
                    "--python-worker", python_worker, "--out", evidence],
                   cwd=repo, env=env, check=True, timeout=80)
    report = read(evidence)
    assert report["state"] == "Completed" and report["caseCount"] == 6
    assert report["launched"]["library"]["sha256"] == files[core.name]
    assert {p.name: sha(p) for p in (lab / role).iterdir()} == files
assert patch == git(tree, "diff", "--binary", base, "--", "src")

collector = (runner / "comparison/quiet/collect.py").read_text(encoding="utf-8")
collector = collector.replace("len(jobs) == 7", f"len(jobs) == {len(jobs)}")
collector = collector.replace("b1719-fixtures", "b1721-fixtures").replace("started < 323", "started < 386")
compile(collector, "collect.py", "exec")
write(quiet / "collect.py", collector)
shutil.copyfile(runner / "comparison/quiet/run.sh", quiet / "run.sh")
assert b"\r" not in (quiet / "run.sh").read_bytes()

launcher = (runner / "quiet.py").read_text(encoding="utf-8").replace("lython-b1719-csv-direct-record-admission",
    "lython-b1721-private-definition-admission").replace("reference/'reference'/name", "reference/'candidate'/name")
launcher = launcher.replace("RuntimeMaxSec=365", "RuntimeMaxSec=430").replace("seconds=288", "seconds=355")
anchor = read(donor / "external/terminal-status.json")["receipt"]
assert anchor["complete"] and sha(donor / "external/observations.tar.xz") == anchor["archiveSHA256"]
a = launcher.index("assert donor['archiveSHA256']=='")
b = launcher.index("\n", a)
launcher = launcher[:a] + "assert donor['archiveSHA256']==" + repr(anchor["archiveSHA256"]) + launcher[b:]
compile(launcher, "quiet.py", "exec")
write(lab / "quiet.py", launcher)
save(lab / "verified-raw-replicas.json", [])

payload = quiet / "payload.tar.gz"
with tarfile.open(payload, "w:gz", compresslevel=3) as archive:
    for name in ("identity.json", "jobs.json", "representative.json", "run.sh", "collect.py"):
        archive.add(quiet / name, arcname=name)
    archive.add(lab / "candidate" / core.name, arcname="candidate-core.dll")
save(quiet / "upload.json", dict(root="private-definition-admission-b1721-20261125",
    reference=read(donor / "external/upload.json")["root"], payloadSHA256=sha(payload), payloadBytes=payload.stat().st_size))
archiver = (runner / "archive.py").read_text(encoding="utf-8").replace("csv-direct-record-admission", "private-definition-admission")
archiver = archiver.replace('==receipt["warmJobs"]==7', '==receipt["warmJobs"]==9').replace("timedBatches=196,lanes=7","timedBatches=252,lanes=9")
compile(archiver, "archive.py", "exec")
write(lab / "archive.py", archiver)
for name in ("compile-allocation.py", "allocations.py"):
    shutil.copyfile(runner / name, lab / name)
