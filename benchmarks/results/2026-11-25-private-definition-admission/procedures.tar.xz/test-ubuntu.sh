set -eu
export DOTNET_ROOT="$HOME/.dotnet"
export PATH="$DOTNET_ROOT:$PATH"
lab="$PWD/.git/agent-notes/review-20261031/private-definition-admission-20261125"
worktree="$PWD/.git/agent-worktrees/private-definition-admission-20261125"
filter='(FullyQualifiedName~FunctionDefault|FullyQualifiedName~DefinitionPair|FullyQualifiedName~AsyncFunctionHosting|FullyQualifiedName~DefinitionContext|FullyQualifiedName~ClosureRetention|FullyQualifiedName~NativeClosure|FullyQualifiedName~Annotation|FullyQualifiedName~Lambda|FullyQualifiedName~VirtualFrame|FullyQualifiedName~HostBudget)&Category!=Stress'
for suite in Lokad.Lython.Tests Lokad.Lython.PublicApi.Tests; do
  logfile="$lab/$suite-ubuntu10.log"
  if dotnet test "$worktree/tests/$suite/$suite.csproj" -c Release -f net10.0 --artifacts-path "$lab/ubuntu" --filter "$filter" > "$logfile" 2>&1; then
    tail -4 "$logfile"
  else
    tail -50 "$logfile"
    exit 1
  fi
done
