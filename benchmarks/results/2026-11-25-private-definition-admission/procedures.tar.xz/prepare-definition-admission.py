from pathlib import Path

lab = Path(__file__).resolve().parent
tree = lab.parents[3] / ".git/agent-worktrees/private-definition-admission-20261125"
src = tree / "src/Lokad.Lython"

def update(name, changes):
    p = src / name
    text = p.read_text(encoding="utf-8")
    for old, new in changes:
        assert text.count(old) == 1, (name, old[:80], text.count(old))
        text = text.replace(old, new)
    p.write_text(text, encoding="utf-8", newline="\n")

update("Frontend/ExecutableScript.SuspendingDefinitions.cs", [(
    "    internal bool IsLambda => Kind != ExecutableDefinitionKind.Statement;\n",
    """    internal bool IsLambda => Kind != ExecutableDefinitionKind.Statement;

    // The existing keyword operand can own the fixed callable admission
    // until both are published. Captures and annotation owners stay separate.
    internal bool PrepaysCallable { get; } = ParameterLayout.HasKeywordDefaults && !DirectKeywordDefault &&
        Kind != ExecutableDefinitionKind.NamespaceLambda && DecoratorCount == 0 && TypeParameters is null &&
        CodeObject.ClosureNames.Count == 0 && AnnotationOperandCount == 0 && DeferredAnnotations.Length == 0 &&
        PostponedAnnotations is null && EagerAnnotationReads is null;
""",
)])

update("Runtime/LythonRuntime.FunctionDefaults.cs", [
    ("private static void StartExecutableDefaults(FunctionParameterLayout layout, Span<ExecutableSlot> operands,",
     "private static void StartExecutableDefaults(ExecutableCreateFunction definition, Span<ExecutableSlot> operands,"),
    ("var defaults = AllocateFunctionDefaults(layout, keywordsOnly, context, span);",
     "var defaults = AllocateFunctionDefaults(definition.ParameterLayout, keywordsOnly, context, span, definition.PrepaysCallable);"),
    ("ExecutionContext context, LythonSourceSpan span)\n    {\n        var positionalCount",
     "ExecutionContext context, LythonSourceSpan span, bool prepayCallable = false)\n    {\n        var positionalCount"),
    ("var bytes = checked(positionalBytes + (keys is null ? 0 : PyDict.RecordKeys.RecordBytes(keywordCapacity)));",
     """var bytes = checked(positionalBytes + (keys is null ? 0 : PyDict.RecordKeys.RecordBytes(keywordCapacity)) +
            (prepayCallable ? FunctionValueBytes : 0));"""),
    ("? ExecutableSlot.OwnPrivateKeywordDefault(ExecutableSlot.FromObject(PyNone.Instance))\n                : ExecutableSlot.OwnPrivateDefault(new object?[keywordCapacity]);",
     """? ExecutableSlot.OwnPrivateKeywordDefault(ExecutableSlot.FromObject(PyNone.Instance), prepayCallable)
                : ExecutableSlot.OwnPrivateKeywordStorage(new object?[keywordCapacity], prepayCallable);"""),
    ("defaults = defaults with { Keywords = ExecutableSlot.OwnPrivateKeywordDefault(FunctionDefaults.PrepareInlineValue(value)) };",
     "defaults = defaults with { Keywords = defaults.Keywords.WithInlineKeywordDefault(FunctionDefaults.PrepareInlineValue(value)) };"),
])

for filename, owner in (
    ("LythonRuntime.Executable.NativePrefix.cs", "Code"),
    ("LythonRuntime.Executable.Interpreter.Dispatch.cs", "execution.Code"),
):
    line=f"StartExecutableDefaults(((ExecutableCreateFunction){owner}.Constants[instruction.ConstantIndex]!).ParameterLayout,"
    update("Runtime/"+filename, [(line, f"StartExecutableDefaults((ExecutableCreateFunction){owner}.Constants[instruction.ConstantIndex]!,")])

update("Runtime/LythonRuntime.Executable.Slot.cs", [
    ("private static readonly InlineDefaultInteger PrivateKeywordInteger = new(PrivateKeywordDefault);",
     """private static readonly InlineDefaultInteger PrivateKeywordInteger = new(PrivateKeywordDefault);
        private static readonly InlineDefaultInteger PrepaidKeywordInteger = new(PrepaidKeywordDefault);"""),
    ("private const long PrivatePositionalDefault = -3;",
     """private const long PrivatePositionalDefault = -3;
        private const long PrepaidKeywordStorage = -4;
        private const long PrepaidKeywordDefault = -5;"""),
    ("_integer is >= PrivatePositionalDefault and <= PrivateDefaultContainer",
     "_integer is >= PrepaidKeywordDefault and <= PrivateDefaultContainer"),
    ("internal readonly bool HasPrivateKeywordDefault => PrivateDefaultKind == PrivateKeywordDefault;",
     """internal readonly bool HasPrivateKeywordDefault => PrivateDefaultKind is PrivateKeywordDefault or PrepaidKeywordDefault;
        internal readonly bool HasPrepaidCallable => PrivateDefaultKind is PrepaidKeywordDefault or PrepaidKeywordStorage;"""),
    ("""        internal static ExecutableSlot OwnPrivateKeywordDefault(ExecutableSlot value)
            => OwnInlineDefault(value, PrivateKeywordInteger);
""",
     """        internal static ExecutableSlot OwnPrivateKeywordDefault(ExecutableSlot value, bool prepayCallable = false)
            => OwnInlineDefault(value, prepayCallable ? PrepaidKeywordInteger : PrivateKeywordInteger);

        internal static ExecutableSlot OwnPrivateKeywordStorage(object?[] values, bool prepayCallable)
            => new() { _value = values, _integer = prepayCallable ? PrepaidKeywordStorage : PrivateDefaultContainer };

        internal readonly ExecutableSlot WithInlineKeywordDefault(ExecutableSlot value)
            => OwnPrivateKeywordDefault(value, PrivateDefaultKind == PrepaidKeywordDefault);

        // The construction slot still owns both charges until publication.
        // The function receives ordinary default storage it can expose or replace.
        internal readonly ExecutableSlot ReadPrepaidKeywordStorage()
            => PrivateDefaultKind == PrepaidKeywordDefault
                ? OwnPrivateKeywordDefault(ReadDefaultOperand()) : OwnPrivateDefault(_value.RequireNotNull());
"""),
    ("""if (kind == PrivateKeywordDefault) governor.Release(PyDict.RecordKeys.SinglePreparedValueBytes);
                else if (storage is object?[] keywordValues) PyDict.RecordKeys.RefundPreparedValues(keywordValues, governor);""",
     """if (kind is PrivateKeywordDefault or PrepaidKeywordDefault)
                    governor.Release(PyDict.RecordKeys.SinglePreparedValueBytes + (kind == PrepaidKeywordDefault ? FunctionValueBytes : 0));
                else if (kind == PrepaidKeywordStorage)
                    governor.Release(PyDict.RecordKeys.RecordBytes(((object?[])storage!).Length) + FunctionValueBytes);
                else if (storage is object?[] keywordValues) PyDict.RecordKeys.RefundPreparedValues(keywordValues, governor);"""),
])

update("Runtime/LythonRuntime.Executable.Results.cs", [
    ("destination = ExecutableSlot.OwnPrivateKeywordDefault(FunctionDefaults.PrepareInlineValue(value));",
     "destination = destination.WithInlineKeywordDefault(FunctionDefaults.PrepareInlineValue(value));"),
])

update("Runtime/LythonRuntime.Executable.PreparedDefinitions.cs", [
    ("""        var governor = context.MemoryGovernor;
        if (preparedAnnotations.Values is null) governor.Reserve(bytes, span);
""",
     """        var governor = context.MemoryGovernor;
        var prepaid = defaults.Keywords.HasPrepaidCallable;
        if (prepaid)
        {
            System.Diagnostics.Debug.Assert(bytes == FunctionValueBytes && preparedAnnotations.Values is null);
            defaults = defaults with { Keywords = defaults.Keywords.ReadPrepaidKeywordStorage() };
        }
        else if (preparedAnnotations.Values is null) governor.Reserve(bytes, span);
"""),
    ("            governor.Commit(bytes);\n            if (cell is not null)", "            if (!prepaid) governor.Commit(bytes);\n            if (cell is not null)"),
    ("            if (preparedAnnotations.Values is null) governor.ReleaseReserved(bytes);",
     "            if (!prepaid && preparedAnnotations.Values is null) governor.ReleaseReserved(bytes);"),
    ("AllocateFunctionDefaults(definition.ParameterLayout, false, scope, instructions[0].Span);",
     "AllocateFunctionDefaults(definition.ParameterLayout, false, scope, instructions[0].Span, definition.PrepaysCallable);"),
    ("defaults = defaults with { Keywords = ExecutableSlot.OwnPrivateKeywordDefault(FunctionDefaults.PrepareInlineValue(keyword)) };",
     "defaults = defaults with { Keywords = defaults.Keywords.WithInlineKeywordDefault(FunctionDefaults.PrepareInlineValue(keyword)) };"),
    ("            if (member is not null)\n                governor.Release",
     "            if (member is not null && !defaults.Keywords.HasPrepaidCallable)\n                governor.Release"),
    ("defaults = AllocateFunctionDefaults(layout, false, scope, instructions[start].Span);",
     "defaults = AllocateFunctionDefaults(layout, false, scope, instructions[start].Span, definition.PrepaysCallable);"),
])
