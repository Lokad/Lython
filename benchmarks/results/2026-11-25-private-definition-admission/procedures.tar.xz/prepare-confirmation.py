from pathlib import Path
import subprocess
import sys

lab = Path(__file__).resolve().parent
source = lab.with_name("dictreader-completed-rows-20261125") / "confirm.py"
recipe = source.read_text(encoding="utf-8")

def amend(before, after):
    global recipe
    assert before in recipe, before
    recipe=recipe.replace(before, after)

a=recipe.index("jobs = ")
b=recipe.index("\nsave(quiet",a)
recipe=recipe[:a]+"""jobs = [
    ('diagnostic.generated-ordinary-definitions','compile'),
    ('scripts.rule-default-closures','warm'),
    ('diagnostic.text-summary.nonlocal-computed-width.large','warm'),
    ('diagnostic.generated-ordinary-definitions','warm'),
    ('scripts.annotated-rule-closures.nested-factories.postponed','compile-run'),
]"""+recipe[b:]
amend('verify["caseCount"] == 5','verify["caseCount"] == 6')
amend('"len(jobs) == 8", "len(jobs) == 4"', '"len(jobs) == 9", "len(jobs) == 5"')
amend('"started < 360", "started < 225"', '"started < 386", "started < 262"')
amend('"job_index in (0, 1, 3)"', '"job_index in (0, 1, 3, 4)"')
amend('"b1718-fixtures", "b1718b-fixtures"', '"b1721-fixtures", "b1721b-fixtures"')
amend('lython-b1718-dictreader-completed-rows", "lython-b1718b-dictreader-completed-rows',
      'lython-b1721-private-definition-admission", "lython-b1721b-private-definition-admission')
amend("RuntimeMaxSec=390", "RuntimeMaxSec=430")
amend("RuntimeMaxSec=252", "RuntimeMaxSec=285")
amend("seconds=305", "seconds=355")
amend("seconds=195", "seconds=259")
amend(r""",'candidate-core.dll','reference-core.dll'""".replace("'", r"\'"),
      r""",'candidate-core.dll'""".replace("'", r"\'"))
amend("dictreader-completed-rows-b1718b", "private-definition-admission-b1721b")
amend("dictreader-completed-rows-b1718", "private-definition-admission-b1721")
amend("2026-11-25-dictreader-completed-rows", "2026-11-25-private-definition-admission")
amend('==receipt["warmJobs"]==8', '==receipt["warmJobs"]==9')
amend('==receipt["warmJobs"]==4', '==receipt["warmJobs"]==5')
amend("timedBatches=224,lanes=8", "timedBatches=252,lanes=9")
amend("timedBatches=112,lanes=4", "timedBatches=140,lanes=5")
assert "b1718" not in recipe
(lab/"confirm.py").write_text(recipe,encoding="utf-8",newline="\n")
subprocess.run([sys.executable,"-X","utf8",lab/"confirm.py"],check=True)
