from pathlib import Path
import hashlib
import json
import os
import shutil
import subprocess

lab=Path(__file__).resolve().parent
donor=lab.with_name("native-call-construction-20261125")
sdk=Path.home()/".dotnet11"
env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk))
project=lab/"admission-probe"
project.mkdir(exist_ok=True)
source=(donor/"Program.cs").read_text(encoding="utf-8")
a=source.index("string[] names")
b=source.index("foreach (var item",a)
source=source[:a]+source[b:]
source=source.replace('    var asynchronous = item.TryGetProperty("runAsync", out var mode) && mode.GetBoolean();\n',"")
source=source.replace("var budget = new LythonMemoryBudget(256L * 1024 * 1024);", "var budget = new AdmissionWitness(new LythonMemoryBudget(256L * 1024 * 1024));")
source=source.replace("budget.ReservedBytes", "budget.Root.ReservedBytes")
source=source.replace("void Run()", "void Run(bool asynchronous)")
a=source.index("        foreach (var field")
b=source.index("        script.Dispose",a)
source=source[:a]+"""        foreach (var asynchronous in new[] { false, true })
        {
            budget.Growths.Clear();
            peakExecutionMemoryBytes = 0;
            Run(asynchronous);
            rows.Add(new { id = item.GetProperty("id").GetString(), asynchronous,
                resizeGrowths = budget.Growths.Values.Sum(), resizeGrowthsByBytes = new SortedDictionary<long,int>(budget.Growths),
                peakExecutionMemoryBytes, allowanceReturned = true });
        }
"""+source[b:]
source=source.replace("assembly = typeof(LythonEngine).Assembly.FullName",
    "coreSHA256 = Convert.ToHexString(System.Security.Cryptography.SHA256.HashData(File.ReadAllBytes(typeof(LythonEngine).Assembly.Location))).ToLowerInvariant()")
source=source.replace("Portable route evidence only from separately instrumented core. No timing.",
    "Observed positive resize requests through the public budget on the unmodified measurement images. No timing.")
source += """
internal sealed class AdmissionWitness(LythonMemoryBudget root) : ILythonMemoryBudget
{
    internal LythonMemoryBudget Root { get; } = root;
    internal Dictionary<long,int> Growths { get; } = new();

    public ILythonMemoryScope CreateScope() => new Scope(this, Root.CreateScope());

    public bool TryReserve(long bytes, [System.Diagnostics.CodeAnalysis.NotNullWhen(true)] out ILythonMemoryReservation? reservation)
        => TryReserve(Root, bytes, out reservation);

    private bool TryReserve(ILythonMemoryBudget scope, long bytes, [System.Diagnostics.CodeAnalysis.NotNullWhen(true)] out ILythonMemoryReservation? reservation)
    {
        reservation = null;
        if (!scope.TryReserve(bytes, out var inner)) return false;
        reservation = new Reservation(this, inner);
        return true;
    }

    private sealed class Scope(AdmissionWitness witness, ILythonMemoryScope inner) : ILythonMemoryScope
    {
        public ILythonMemoryScope CreateScope() => new Scope(witness, inner.CreateScope());
        public bool TryReserve(long bytes, [System.Diagnostics.CodeAnalysis.NotNullWhen(true)] out ILythonMemoryReservation? reservation)
            => witness.TryReserve(inner, bytes, out reservation);
        public void Dispose() => inner.Dispose();
    }

    private sealed class Reservation(AdmissionWitness witness, ILythonMemoryReservation inner) : ILythonMemoryReservation
    {
        public long Bytes => inner.Bytes;
        public bool TryResize(long bytes)
        {
            var growth = bytes - inner.Bytes;
            if (!inner.TryResize(bytes)) return false;
            if (growth > 0) witness.Growths[growth] = witness.Growths.GetValueOrDefault(growth) + 1;
            return true;
        }
        public void Dispose() => inner.Dispose();
    }
}
"""
(project/"Program.cs").write_text(source,encoding="utf-8",newline="\n")
csproj=(donor/"RouteProbe.csproj").read_text(encoding="utf-8").replace("RouteProbe", "AdmissionWitness")
csproj=csproj.replace("image/Lokad.", "../reference/Lokad.")
(project/"AdmissionWitness.csproj").write_text(csproj,encoding="utf-8",newline="\n")
dotnet=sdk/"dotnet.exe"
subprocess.run([dotnet,"build",project/"AdmissionWitness.csproj","-c","Release","--nologo"],cwd=lab,env=env,check=True,timeout=100)
files=project/"bin/Release/net11.0"
quiet=lab/"comparison/quiet"
identity=json.loads((quiet/"identity.json").read_text(encoding="utf-8"))
roles={}
for role in ("reference","candidate"):
    image=lab/(role+"-admission-probe")
    image.mkdir(exist_ok=True)
    for p in (lab/role).iterdir(): shutil.copyfile(p,image/p.name)
    for p in files.glob("AdmissionWitness.*"): shutil.copyfile(p,image/p.name)
    out=lab/(role+"-admission.json")
    subprocess.run([dotnet,image/"AdmissionWitness.dll",image,quiet/"representative.json",out],cwd=lab,env=env,check=True,timeout=60)
    result=json.loads(out.read_text(encoding="utf-8"))
    assert result["coreSHA256"]==identity["coreSHA256"][role]
    roles[role]=result["rows"]

rows=[]
for a,b in zip(roles["reference"], roles["candidate"],strict=True):
    assert (a["id"],a["asynchronous"])==(b["id"],b["asynchronous"]) and a["allowanceReturned"] and b["allowanceReturned"]
    row=dict(case=a["id"],asynchronous=a["asynchronous"],resizeGrowths=[a["resizeGrowths"],b["resizeGrowths"]],
        peakExecutionMemoryBytes=[a["peakExecutionMemoryBytes"],b["peakExecutionMemoryBytes"]])
    print(row)
    rows.append(row)
(lab/"admission-summary.json").write_text(json.dumps(rows,indent=2)+"\n",encoding="utf-8",newline="\n")
