Retain the combined preflight for the removed allowance requests and the
earlier refusal before guest effects. Ordinary warm elapsed is 0.29–3.57%
lower in the first block and 2.18–4.94% lower in confirmation. Defaulted
factories are 1.63–2.99% and 2.02–4.86% lower. Wider CPU crosses zero in one
block for each target. Compilation CPU rises 0.54–2.66% in the first block
and falls 0.71–3.11% in confirmation. The unchanged text and postponed
controls also improve in confirmation, with larger ranges. The measurements
leave the causal elapsed and CPU magnitudes uncertain.
