from pathlib import Path
import hashlib
import json
import shutil
import subprocess
import sys
import tarfile

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
tree=repo/".git/agent-worktrees/private-definition-admission-20261125"
out=repo/"benchmarks/results/2026-11-25-private-definition-admission"
quiet=lab/"comparison/quiet"
read=lambda path: json.loads(path.read_text(encoding="utf-8"))
sha=lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
identity=read(quiet/"identity.json")
diff=lambda folder: subprocess.check_output(["git","diff","--binary",identity["sourceRevision"],"--",folder],cwd=tree)
assert diff("src")== (lab/"candidate.patch").read_bytes()
assert sha(lab/"candidate.patch")==identity["sourcePatchSHA256"]
(lab/"tests.patch").write_bytes(diff("tests"))
assert len(diff("tests").split(b"diff --git "))==4
for role, files in identity["imageFiles"].items():
    assert {p.name:sha(p) for p in (lab/role).iterdir()}==files
shutil.copyfile(quiet/"identity.json",out/"identity.json")
for name in ("allocation-summary.json","compile-allocation-summary.json","admission-summary.json"):
    shutil.copyfile(lab/name,out/name)
procedures=[
    "prepare-definition-admission.py","prepare.py","quiet.py","archive.py","package-evidence.py",
    "prepare-confirmation.py","confirm.py", "confirmation-block/quiet.py", "confirmation-block/archive.py",
    "confirmation-block/launch-console.log","confirmation-block/retrieve.log",
    "confirmation-block/comparison/quiet/storage-custody.json",
    "assessment.md",
    "candidate.patch","tests.patch","candidate-build.log","prepare.log","launch-console.log","retrieve.log",
    "baseline-refusal-win11.log","debug-pair-win11.log",
    "test-ubuntu.sh","test-whitebox-ubuntu.sh","whitebox-final-ubuntu10.log","whitebox-final-win11.log",
    "allocations.py","allocations.log","compile-allocation.py","compile-allocation.log",
    "admission-probe.py","admission-probe.log","admission-probe/Program.cs","admission-probe/AdmissionWitness.csproj",
    "comparison/reference-verify.json","comparison/candidate-verify.json","comparison/quiet/storage-custody.json",
]
procedures.extend(p.name for p in lab.glob("Lokad.Lython.*.log"))
for role in ("reference","candidate"):
    procedures.extend(f"{role}-{name}.json" for name in ("allocation-final","compiler-owner","admission"))
with tarfile.open(out/"procedures.tar.xz","w:xz") as archive:
    for name in procedures:
        archive.add(lab/name,arcname=name)
with tarfile.open(out/"procedures.tar.xz") as archive:
    assert archive.getnames()==procedures
    for name in procedures:
        assert hashlib.sha256(archive.extractfile(name).read()).hexdigest()==sha(lab/name)

names={
    "diagnostic.generated-ordinary-definitions":"Generated ordinary definitions",
    "scripts.rule-default-closures":"Defaulted rule factories",
    "scripts.annotated-rule-closures":"Eager annotated rules",
    "scripts.annotated-rule-closures.nested-factories.postponed":"Postponed annotated rules",
    "diagnostic.shipment-routing-callbacks":"Shipment callback report",
    "diagnostic.text-summary.nonlocal-computed-width.large":"Nonlocal Unicode text",
}
phases={"warm":"Warm sync","warm-async":"Warm async","compile":"Compilation","compile-run":"Compile-to-result"}
def pct(values): return " to ".join(f"{v:+.2f}".replace("-", "−") for v in values)+"%"
def timing_table(summary):
    rows=["| Workload | Phase | Elapsed change | Wider CPU change | Reference / candidate elapsed spread |",
          "| --- | --- | ---: | ---: | ---: |"]
    for row in read(summary)["rows"]:
        cols=(names[row["case"]],phases[row["lane"]],pct(row["elapsedPercent"]),pct(row["cpuPercent"]),
              " / ".join(f"{v:.2f}%" for v in row["sameSourceElapsedSpreadPercent"]))
        rows.append("| "+" | ".join(cols)+" |")
    return "\n".join(rows)

assessment=Path(sys.argv[1]).read_text(encoding="utf-8").strip()
content=f"""# B1721 Admit fixed storage for private function definitions together

An unannotated, undecorated definition without captures can admit the
callable shell with its keyword-default storage. Both executable drivers
and the closed definition paths use the existing keyword-default slot to
carry the charge until the callable takes the storage. Failure retires both
charges before the next guest operation, including when a closed pair
fails after building its first member. Variable storage still needs its
own preflight.

The fixed combined charge can refuse earlier, before a default expression
that the separate default-storage preflight previously admitted. The
first refusal points to the definition. Successful operations keep the
original expression order and expose the usual defaults and their aliases.
A genuinely suspended default keeps its storage charged through cleanup.

The frozen reference uses the runtime of `7120ee55e`. The two 32-file
images differ only in the core DLL and verify six complete CPython-derived
output/file goldens. A separate local diagnostic counts positive allowance
resize requests on the same images.

| Complete script | Reference requests | Candidate requests | Peak execution admission on both |
| --- | ---: | ---: | ---: |
| Generated ordinary definitions | 3,093 | 1,557 | 971,730 B |
| Defaulted rule factories | 8,200 | 4,104 | 2,786,655 B |

The request counts and admitted peaks match between public sync and async
hosting. The four control workloads have the same resize counts in both
images. All runs return the borrowed allowance to their original balances.
The two affected scripts have identical warm and compilation CLR
allocations. The runtime report retains a small change in the unchanged
shipment allocation control.

The quiet Azure F4as_v7 ran Ubuntu 24.04.4 with .NET 11 RC3 on November 25,
2026 UTC. Two workers per image warm for five full-request seconds in the
first block and seven in confirmation, then contribute seven rotated batches
per phase. Ranges span the four pairings
of worker medians. Warm elapsed includes mediated RAM-backed I/O where
applicable, verification and prior-result cleanup. Wider CPU includes reset
and request framing. Compilation and compile-to-result are measured
separately from warm execution.

## First block

{timing_table(out/"quiet-summary.json")}

## Reordered confirmation

{timing_table(out/"confirmation/quiet-summary.json")}

{assessment}

Windows .NET 11 and Ubuntu .NET 10 each pass 610 focused Release checks.
The coverage includes an admission refusal before a default's side
effects, cancellation with a suspended default, default alias identity and
refund of unpublished pairs while their scope is still alive. All 392
timed batches verify. The persistent archive verifies under the quiet lease
after workers join and guest fixtures are removed.

[Identity](identity.json) · [Timings](quiet-summary.json) ·
[Allowance requests](admission-summary.json) · [Runtime allocation](allocation-summary.json) ·
[Compiler allocation](compile-allocation-summary.json) ·
[Observations](quiet-observations.tar.xz) · [Terminal receipt](quiet-terminal-status.json) ·
[Source and procedures](procedures.tar.xz) ·
[Confirmation timing](confirmation/quiet-summary.json) ·
[Confirmation observations](confirmation/quiet-observations.tar.xz) ·
[Confirmation terminal receipt](confirmation/quiet-terminal-status.json).
"""
(out/"README.md").write_text(content,encoding="utf-8",newline="\n")
print("Verified all procedure archive members.")
