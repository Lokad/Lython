from pathlib import Path
import ast,fcntl,hashlib,io,json,os,shutil,stat,subprocess,sys,tarfile
config={'qualification': {'status': 'completed', 'runId': 42813970365, 'url': 'https://github.com/Lokad/Lython/actions/runs/42813970365', 'headSHA': '8d44bd4ecdb0db96fee7a23113ba28b1e9cff558', 'event': 'workflow_dispatch', 'stress': True, 'requestedUTC': '2026-11-10T12:13:52.8995368+00:00', 'doNotObserveBeforeUTC': '2026-11-10T12:45:08.342784+00:00', 'required': ['Windows/Ubuntu', 'actual.NET11/10 ordinary', 'originalStress bothframeworks', 'installedReleasepackageconsumers'], 'terminal': True, 'conclusion': 'success', 'lastObservedUTC': '2026-11-10T12:40:08.342784+00:00', 'allRequiredGatesPassed': True}, 'payloadBytes': 1984064, 'payloadSHA256': 'b8cef4613f6f6c361c3f922e90c2239239539dfb47bf4194fc88eb6d3c8ed6f3', 'required': 270193344, 'copies': [{'path': 'iterative-json-b545-20261110/observations.tgz', 'bytes': 3891771, 'sha256': '285b18b74bc7f34bdb2eed54aa164297466f68ec7c1d9ee5ef3cec68bc09d809', 'canonical': 'benchmarks\\results\\2026-11-10-iterative-json-construction\\refined-observations.tgz'}, {'path': 'iterative-json-b545-20261110/source-checks.tar.xz', 'bytes': 68872, 'sha256': '3052ba9b65bf619cfec5c90469a5066eb7e2206a7cde1e60ff4dd680a76382c3', 'canonical': 'benchmarks\\results\\2026-11-10-iterative-json-construction\\refined-observations.tgz:source-checks.tar.xz'}, {'path': 'iterative-json-b545-20261110/confirmation/confirmation.json', 'bytes': 544468, 'sha256': '8776c807e8eddc56a4383c6fc01b33894904da86909d61651c876b8c140edf35', 'canonical': 'benchmarks\\results\\2026-11-10-iterative-json-construction\\refined-observations.tgz:confirmation/confirmation.json'}, {'path': 'iterative-json-b545-20261110/representative.json', 'bytes': 753467, 'sha256': 'd64ade9f47ae23d99f28bd4292583d11cc9eb63f3c3a1aecc887e774c475d70a', 'canonical': 'benchmarks\\results\\2026-11-10-iterative-json-construction\\refined-observations.tgz:representative.json'}]}
base=Path('/home/lokad/lython-bench-checks').resolve();root=base/'json-cpython-b546-20261110';source=base/'iterative-json-b545-20261110/candidate';fixture=root/'guest-fixtures'
with(base/'comparison-vm.lock').open('a')as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert not root.exists()and not list(Path('/dev/shm').glob('lython-comparison-files-*'))
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record|[c]omplete-jobs.dll'],capture_output=True).returncode==1
 payload=sys.stdin.buffer.read(config['payloadBytes']+1);assert len(payload)==config['payloadBytes']and hashlib.sha256(payload).hexdigest()==config['payloadSHA256']
 assert hashlib.sha256((source/'Lokad.Lython.dll').read_bytes()).hexdigest()=='678fc7df05e93fd542f6fb9fa48bcbbc923bc6cc655ed1d814bb50bdc4bdfc37'
 protocol=base/'prepared-call-layout-b384-20261107/cpython-worker.py'
 assert hashlib.sha256(protocol.read_bytes()).hexdigest()=='02ca606af6b937a5bec8da744da36e6dbea45ef14ee7207732f34da052ad32f1'
 before=shutil.disk_usage(base).free;retired=[];retiredSupersededAc6=[]
 if before<=config['required']:
  reclaim=0
  for copy in config['copies']:
   path=base/copy['path'];s=path.lstat()
   assert path.resolve(strict=True).is_relative_to(base)and stat.S_ISREG(s.st_mode)and s.st_uid==os.getuid()and s.st_nlink==1
   assert s.st_size==copy['bytes']and hashlib.sha256(path.read_bytes()).hexdigest()==copy['sha256']
   reclaim+=s.st_blocks*512;retired.append(dict(copy,allocatedBytes=s.st_blocks*512,allAliases=[str(path)]))
  original=base/'iterative-json-b545-20261110/baseline-core.dll';old=original.lstat()
  assert stat.S_ISREG(old.st_mode)and old.st_uid==os.getuid()and hashlib.sha256(original.read_bytes()).hexdigest()=='ac6edb6fc361dba9195d973830a5ca02caac10b62cc6d041f134ce31ef9a10d3'
  matches=subprocess.check_output(['find',str(base),'-xdev','-samefile',str(original),'-type','f'],text=True).splitlines()
  assert len(matches)==old.st_nlink
  for name in matches:
   path=Path(name);st=path.lstat();assert path.resolve(strict=True).is_relative_to(base)and stat.S_ISREG(st.st_mode)and st.st_uid==os.getuid()
   protected=(source/'Lokad.Lython.dll').stat();assert(st.st_dev,st.st_ino)!=(protected.st_dev,protected.st_ino)
  retiredSupersededAc6=matches;reclaim+=old.st_blocks*512
  assert before+reclaim>config['required'],(before,reclaim,config['required'])
  for name in matches:Path(name).unlink()
  for copy in config['copies']:(base/copy['path']).unlink()
 assert shutil.disk_usage(base).free>config['required']
 recovery=dict(beforeFreeBytes=before,afterFreeBytes=shutil.disk_usage(base).free,requiredFreeBytes=config['required'],freshIdleLease=True,qualifiedCurrent678Preserved=True,terminalFullQualification=config['qualification'],osFloorMiB=240,evidenceHeadroomMiB=12,files=retired,retiredSupersededAc6Aliases=retiredSupersededAc6,supersededAc6Canonical='benchmarks/results/2026-11-10-iterative-json-construction/refined-observations.tgz:baseline-core.dll')
 with tarfile.open(fileobj=io.BytesIO(payload),mode='r:gz')as a:root.mkdir();a.extractall(root,filter='data')
 (root/'space-recovery.json').write_text(json.dumps(recovery,indent=2)+'\n')
 shutil.copyfile(protocol,root/'cpython-worker.py')
 shutil.copytree(source,root/'candidate',copy_function=os.link)
 (root/'candidate/Lokad.Lython.dll').unlink();os.link(root/'current-core.dll',root/'candidate/Lokad.Lython.dll')
 identity=json.loads((root/'identity.json').read_text())
 for name,digest in {**identity['auxiliaryFiles'],'Lokad.Lython.dll':identity['coreSHA256']['candidate']}.items():assert hashlib.sha256((root/'candidate'/name).read_bytes()).hexdigest()==digest,name
 assert hashlib.sha256((root/'cpython-worker.py').read_bytes()).hexdigest()==identity['protocolSHA256']
 assert hashlib.sha256((root/'representative.json').read_bytes()).hexdigest()==identity['catalogSHA256']
 for name in ['collect.py','archive-owned.py']:ast.parse((root/name).read_text())
 subprocess.run(['/bin/sh','-n',str(root/'run.sh')],check=True)
 fixture.mkdir();subprocess.run(['sudo','-n','mount','-t','tmpfs','-o','size=128m,mode=0700,uid=lokad,gid=lokad','lython-b546-fixtures',str(fixture)],check=True)
 setup=dict(freeBytes=shutil.disk_usage(base).free,coreAndAuxiliaryImagesVerified=True,jobs=9,ownerSeconds=300,stopSeconds=30,marginSeconds=30,workerUnchanged=True,osFloorMiB=240,evidenceHeadroomMiB=12)
 assert setup['freeBytes']>(240+12)*1024*1024
 (root/'setup.json').write_text(json.dumps(setup,indent=2)+'\n');print(json.dumps(setup),flush=True)
try:
 subprocess.run(['sudo','-n','systemd-run','--unit=lython-b546-json-cpython-20261110','--property=User=lokad','--property=WorkingDirectory='+str(root),
  '--property=RuntimeMaxSec=300','--property=TimeoutStopSec=30','--property=KillMode=control-group','/bin/sh',str(root/'run.sh')],check=True)
except BaseException:
 subprocess.run(['sudo','-n','umount',str(fixture)],check=True);fixture.rmdir();raise
live=subprocess.check_output(['systemctl','show','lython-b546-json-cpython-20261110.service','--property=ActiveState,MainPID,RuntimeMaxUSec'],text=True)
assert 'ActiveState=active'in live and'MainPID=0'not in live;print(live,flush=True)
