from pathlib import Path
import ast,datetime,hashlib,json,shlex,subprocess
r=Path(__file__).parent
qualification=json.loads((r/'delivery-ci-status.json').read_text(encoding='utf-8'))
assert qualification['terminal']and qualification['allRequiredGatesPassed']and qualification['headSHA']=='8d44bd4ecdb0db96fee7a23113ba28b1e9cff558'
payload=(r/'payload.tgz').read_bytes()
config=dict(qualification=qualification,payloadBytes=len(payload),payloadSHA256=hashlib.sha256(payload).hexdigest(),required=(240+12)*1024*1024+3*len(payload),copies=json.loads((r/'exact-copies.json').read_text(encoding='utf-8')))
script=r'''from pathlib import Path
import ast,fcntl,hashlib,io,json,os,shutil,stat,subprocess,sys,tarfile
config=CONFIG
base=Path('/home/lokad/lython-bench-checks').resolve();root=base/'json-cpython-b546-20261110';source=base/'iterative-json-b545-20261110/candidate';fixture=root/'guest-fixtures'
with(base/'comparison-vm.lock').open('a')as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert not root.exists()and not list(Path('/dev/shm').glob('lython-comparison-files-*'))
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record|[c]omplete-jobs.dll'],capture_output=True).returncode==1
 payload=sys.stdin.buffer.read(config['payloadBytes']+1);assert len(payload)==config['payloadBytes']and hashlib.sha256(payload).hexdigest()==config['payloadSHA256']
 assert hashlib.sha256((source/'Lokad.Lython.dll').read_bytes()).hexdigest()=='678fc7df05e93fd542f6fb9fa48bcbbc923bc6cc655ed1d814bb50bdc4bdfc37'
 protocol=base/'prepared-call-layout-b384-20261107/cpython-worker.py'
 assert hashlib.sha256(protocol.read_bytes()).hexdigest()=='02ca606af6b937a5bec8da744da36e6dbea45ef14ee7207732f34da052ad32f1'
 before=shutil.disk_usage(base).free;retired=[];retiredSupersededAc6=[]
 if before<=config['required']:
  reclaim=0
  for copy in config['copies']:
   path=base/copy['path'];s=path.lstat()
   assert path.resolve(strict=True).is_relative_to(base)and stat.S_ISREG(s.st_mode)and s.st_uid==os.getuid()and s.st_nlink==1
   assert s.st_size==copy['bytes']and hashlib.sha256(path.read_bytes()).hexdigest()==copy['sha256']
   reclaim+=s.st_blocks*512;retired.append(dict(copy,allocatedBytes=s.st_blocks*512,allAliases=[str(path)]))
  original=base/'iterative-json-b545-20261110/baseline-core.dll';old=original.lstat()
  assert stat.S_ISREG(old.st_mode)and old.st_uid==os.getuid()and hashlib.sha256(original.read_bytes()).hexdigest()=='ac6edb6fc361dba9195d973830a5ca02caac10b62cc6d041f134ce31ef9a10d3'
  matches=subprocess.check_output(['find',str(base),'-xdev','-samefile',str(original),'-type','f'],text=True).splitlines()
  assert len(matches)==old.st_nlink
  for name in matches:
   path=Path(name);st=path.lstat();assert path.resolve(strict=True).is_relative_to(base)and stat.S_ISREG(st.st_mode)and st.st_uid==os.getuid()
   protected=(source/'Lokad.Lython.dll').stat();assert(st.st_dev,st.st_ino)!=(protected.st_dev,protected.st_ino)
  retiredSupersededAc6=matches;reclaim+=old.st_blocks*512
  assert before+reclaim>config['required'],(before,reclaim,config['required'])
  for name in matches:Path(name).unlink()
  for copy in config['copies']:(base/copy['path']).unlink()
 assert shutil.disk_usage(base).free>config['required']
 recovery=dict(beforeFreeBytes=before,afterFreeBytes=shutil.disk_usage(base).free,requiredFreeBytes=config['required'],freshIdleLease=True,qualifiedCurrent678Preserved=True,terminalFullQualification=config['qualification'],osFloorMiB=240,evidenceHeadroomMiB=12,files=retired,retiredSupersededAc6Aliases=retiredSupersededAc6,supersededAc6Canonical='benchmarks/results/2026-11-10-iterative-json-construction/refined-observations.tgz:baseline-core.dll')
 with tarfile.open(fileobj=io.BytesIO(payload),mode='r:gz')as a:root.mkdir();a.extractall(root,filter='data')
 (root/'space-recovery.json').write_text(json.dumps(recovery,indent=2)+'\n')
 shutil.copyfile(protocol,root/'cpython-worker.py')
 shutil.copytree(source,root/'candidate',copy_function=os.link)
 (root/'candidate/Lokad.Lython.dll').unlink();os.link(root/'current-core.dll',root/'candidate/Lokad.Lython.dll')
 identity=json.loads((root/'identity.json').read_text())
 for name,digest in {**identity['auxiliaryFiles'],'Lokad.Lython.dll':identity['coreSHA256']['candidate']}.items():assert hashlib.sha256((root/'candidate'/name).read_bytes()).hexdigest()==digest,name
 assert hashlib.sha256((root/'cpython-worker.py').read_bytes()).hexdigest()==identity['protocolSHA256']
 assert hashlib.sha256((root/'representative.json').read_bytes()).hexdigest()==identity['catalogSHA256']
 for name in ['collect.py','archive-owned.py']:ast.parse((root/name).read_text())
 subprocess.run(['/bin/sh','-n',str(root/'run.sh')],check=True)
 fixture.mkdir();subprocess.run(['sudo','-n','mount','-t','tmpfs','-o','size=128m,mode=0700,uid=lokad,gid=lokad','lython-b546-fixtures',str(fixture)],check=True)
 setup=dict(freeBytes=shutil.disk_usage(base).free,coreAndAuxiliaryImagesVerified=True,jobs=9,ownerSeconds=300,stopSeconds=30,marginSeconds=30,workerUnchanged=True,osFloorMiB=240,evidenceHeadroomMiB=12)
 assert setup['freeBytes']>(240+12)*1024*1024
 (root/'setup.json').write_text(json.dumps(setup,indent=2)+'\n');print(json.dumps(setup),flush=True)
try:
 subprocess.run(['sudo','-n','systemd-run','--unit=lython-b546-json-cpython-20261110','--property=User=lokad','--property=WorkingDirectory='+str(root),
  '--property=RuntimeMaxSec=300','--property=TimeoutStopSec=30','--property=KillMode=control-group','/bin/sh',str(root/'run.sh')],check=True)
except BaseException:
 subprocess.run(['sudo','-n','umount',str(fixture)],check=True);fixture.rmdir();raise
live=subprocess.check_output(['systemctl','show','lython-b546-json-cpython-20261110.service','--property=ActiveState,MainPID,RuntimeMaxUSec'],text=True)
assert 'ActiveState=active'in live and'MainPID=0'not in live;print(live,flush=True)
'''.replace('CONFIG',repr(config))
ast.parse(script);(r/'launch-command.py').write_text(script,encoding='utf-8',newline='\n')
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
stage='/home/lokad/lython-bench-checks/json-cpython-b546-launch.py'
code='from pathlib import Path;import sys;p=Path('+repr(stage)+');assert not p.exists();p.write_bytes(sys.stdin.buffer.read())'
done=subprocess.run(ssh+['python3 -c '+shlex.quote(code)],input=script.encode('utf-8'),capture_output=True);assert done.returncode==0,done.stderr
done=subprocess.run(ssh+['python3 '+stage],input=payload,capture_output=True)
(r/'launch.log').write_bytes(done.stdout+b'\n'+done.stderr);assert done.returncode==0,done.stderr.decode('utf-8')
assert b'ActiveState=active'in done.stdout and b'MainPID=0'not in done.stdout
now=datetime.datetime.now(datetime.timezone.utc)
(r/'observe-not-before.json').write_text(json.dumps(dict(acknowledgedUTC=now.isoformat(),doNotObserveBeforeUTC=(now+datetime.timedelta(seconds=360)).isoformat(),ownerSeconds=300,stopSeconds=30,marginSeconds=30),indent=2)+'\n',encoding='utf-8',newline='\n')
print(done.stdout.decode('utf-8'),flush=True);print('Observe after',(now+datetime.timedelta(seconds=360)).isoformat(),flush=True)
