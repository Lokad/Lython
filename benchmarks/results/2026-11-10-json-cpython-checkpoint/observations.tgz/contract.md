# R197 representative CPython checkpoint

Committed/pushed8d44bd4e, fresh postcommit nonincremental.NET11coreE294; actual
0.11.0 assembly. No precommit-binary identity claim. Source568-file hashes and
catalog are frozen locally. Existing common worker/adapter0.4/protocol, isolated
CPython3.13.16, same quietF4as_v7 machine. No runtime/pin/publication change.

Same complete report/text/JSON-lines scripts, inputs and fullstdout/file digests.
Ninejobs, compilation/warm/compile-to-result separately. Reuse the prior bounded
checkpoint sampler: two independent processes per engine,5stimewarmup,7rotated
150msrounds, ordinaryGC/tiering and referenceGIL. Size/guard before launch:300s
ownedrun,30sstop/30smargin; all users joined and persistent archive/SHA verified
before retiringRAM. No new framework or tenminute development lane.

Warm/complete clocks include mediatedRAMI/O, output validation and prior-result
cleanup; reset/staging/protocol/startup excluded. Compile includes construction
and prior-script disposal. ExternalCPU is wider and coarse. Cross-checkpoint
ranges cannot isolate one change or establish neutrality. Preserve all adverse/
inconclusive controls, and accurately label pending qualification/historical rows.

FullsourceCI42813970365 runs independently; guide updates must match actual
source/qualification status. This measurement documents useful scripts/current
remaining gaps; it does not end the broader performance roadmap. Publication held.

Newpostcommitcore requires persistent disk space. Keep current678/lastqualified
ac6 images and sole evidence protected. Use fresh idlelease, exact committed
canonical-copy proofs/allhardlinks, fixed240MiBOSfloor/12MiBheadroom and all normal
pre/post gates. Prepared here only; no remote unit exists yet. CI completion may
justify retiring the superseded qualifiedreference when the new candidate is
actually qualified; that is not assumed now.
