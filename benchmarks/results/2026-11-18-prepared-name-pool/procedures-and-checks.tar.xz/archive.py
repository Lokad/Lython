from pathlib import Path
import gzip,hashlib,json,shutil,tarfile
r=Path(__file__).parent;repo=Path('D:/code/Lython');out=repo/'benchmarks/results/2026-11-18-prepared-name-pool'
out.mkdir(exist_ok=False)
for name in ['candidate-sources.tar.xz','checks.json','candidate-preflight.json','candidate-allocation.json',
    'reference-combined-preflight.json','candidate-combined-preflight.json','summary.json','allocation-summary.json',
    'reference-compile-allocation.json','candidate-compile-allocation.json','compile-allocation-summary.json']:
    shutil.copyfile(r/name,out/name)
shutil.copyfile(r/'frozen/identity.json',out/'frozen-identity.json')
shutil.copyfile(r/'correction.patch.gz',out/'prototype.patch.gz')
for name in ['identity.json','terminal-status.json','archive-receipt.json','observations.tgz']:
    shutil.copyfile(r/'quiet'/name,out/name)
assert hashlib.sha256((out/'observations.tgz').read_bytes()).hexdigest()==json.loads((out/'archive-receipt.json').read_text(encoding='utf-8'))['archiveSHA256']
(out/'candidate-core.dll.gz').write_bytes(gzip.compress((r/'frozen/candidate/Lokad.Lython.dll').read_bytes(),mtime=0))
with tarfile.open(out/'procedures-and-checks.tar.xz','w:xz')as a:
    for p in sorted(r.rglob('*')):
        if not p.is_file() or {'frozen','retrieved','bin','obj','candidate','reference','compile-reference','compile-candidate'}&set(p.relative_to(r).parts):continue
        if p.name in {'payload.tgz','candidate-sources.tar.xz','observations.tgz','correction.patch.gz'}:continue
        a.add(p,arcname=p.relative_to(r).as_posix())
    for name in ['prepared-names-r525-build.log','prepared-names-r525-initial-command.log','prepared-names-r525-initial-compile.log',
        'implement-prepared-names-r525.py','prepare-freeze-names-r525.py','prepare-quiet-names-r525.py','check-prepared-names-r525.py']:
        a.add(r.parent/name,arcname=name)
print(out)
