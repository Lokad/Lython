from pathlib import Path
import json, os, subprocess
r = Path(__file__).parent
catalog = json.loads((r/'measurement-catalog.json').read_text(encoding='utf-8'))
assert len(catalog['cases']) == 4
all_cases = json.loads((r/'catalog.json').read_text(encoding='utf-8'))['cases']
catalog['cases'].append(next(c for c in all_cases if c['id']=='scripts.json-summary-helpers.large'))
(r/'combined-catalog.json').write_text(json.dumps(catalog, indent=2)+'\n', encoding='utf-8', newline='\n')
d=Path('C:/Users/JoannesVermorel/.dotnet11/dotnet.exe')
repo=Path('D:/code/Lython');env=os.environ.copy()
env.update(DOTNET_ROOT=str(d.parent),DOTNET_ROOT_X64=str(d.parent));env['PATH']=str(d.parent)+os.pathsep+env['PATH']
for role in ['reference','candidate']:
    cmd=[str(d),str(r/'frozen'/role/'Lokad.Lython.Benchmarks.dll'),'--compare','verify',
        '--catalog',str(r/'combined-catalog.json'),'--dotnet',str(d),'--python','C:/Python313/python.exe',
        '--python-worker',str(repo/'benchmarks/cpython-worker.py'),'--out',str(r/(role+'-combined-preflight.json'))]
    with (r/(role+'-combined-preflight.log')).open('w',encoding='utf-8') as log:
        p=subprocess.run(cmd,cwd=repo,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=120)
    assert p.returncode==0,(r/(role+'-combined-preflight.log')).read_text(encoding='utf-8')
    print(role,'five actual combined catalog goldens passed',flush=True)
