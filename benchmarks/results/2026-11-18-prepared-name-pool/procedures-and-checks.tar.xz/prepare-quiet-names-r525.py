from pathlib import Path
base=Path(__file__).parent
r=base/'prepared-names-r525'
s=(base/'native-index-context-r523/prepare-refined-quiet.py').read_text(encoding='utf-8')
a=s.index('canonical=');b=s.index('\ntemplate=',a)
s=s[:a]+'''subjects=[]
canonical='benchmarks/results/2026-11-18-native-index-context/refined/candidate-core.dll.gz'
blob=subprocess.check_output(['git','show','HEAD:'+canonical],cwd=repo);assert blob==(repo/canonical).read_bytes();data=gzip.decompress(blob)
assert hashlib.sha256(data).hexdigest()=='0284157e1b8655be1ec82cfaea76bc0360b44dcb1b6f5b6e5795edcdb513f17b'
subjects.append(dict(kind='withdrawn-prototype-core',sha256=hashlib.sha256(data).hexdigest(),bytes=len(data),canonical=canonical,canonicalSHA256=hashlib.sha256(blob).hexdigest(),member='gzip-payload',committedBlobVerified=True,knownPath='native-index-refined-b954-20261118/candidate/Lokad.Lython.dll'))
for canonical,folder in [('benchmarks/results/2026-11-18-native-index-context/refined/observations.tgz','native-index-refined-b954-20261118'),('benchmarks/results/2026-11-18-bindings-cpython-checkpoint/observations.tgz','bindings-cpython-b952-20261118')]:
 blob=subprocess.check_output(['git','show','HEAD:'+canonical],cwd=repo);assert blob==(repo/canonical).read_bytes();member='confirmation/confirmation.json'
 with tarfile.open(fileobj=io.BytesIO(blob))as a:data=a.extractfile(member).read()
 subjects.append(dict(kind='archived-raw-observation-replica',sha256=hashlib.sha256(data).hexdigest(),bytes=len(data),canonical=canonical,canonicalSHA256=hashlib.sha256(blob).hexdigest(),member=member,committedBlobVerified=True,knownPath=folder+'/'+member))
 if 'refined/' in canonical:
  subjects.append(dict(kind='archived-whole-observation-replica',sha256=hashlib.sha256(blob).hexdigest(),bytes=len(blob),canonical=canonical,canonicalSHA256=hashlib.sha256(blob).hexdigest(),member='whole-file',committedBlobVerified=True,knownPath=folder+'/observations.tgz'))
''' + s[b:]
a=s.index('identity=dict(');b=s.index("(q/'identity.json')",a)
s=s[:a]+'''identity=dict(sourceRevision='Qualified3f873227/frozena5038a28 GREEN44256409242 versus privateR525/f96cd8a9; both233internal/86public actual11/10; unpromoted.',
 purpose='Single prepared text/live-global-slot/String+Dict definition pool removes parallel slot allocation and repeated immediate method-name selection. Metadata grows; preserve exact receiver/code guards, current cancellation and ownership. Helper-text compile/warm/fresh, JSON-record warm, floating/call controls; no predicted speedup.',
 coreSHA256={role:f['imageFiles']['candidate'if role.startswith('candidate')else'reference']['Lokad.Lython.dll']for role in ['reference','reference-control','candidate','candidate-control']},imageFiles=f['imageFiles'],sourceInputsArchiveSHA256=sha(r/'candidate-sources.tar.xz'),productionFiles=587,catalogSHA256=sha(r/'combined-catalog.json'),normalAdapterPin='0.4.0',publicationHeld=True)
''' + s[b:]
a=s.index('jobs=');b=s.index('\ns=(old/',a)
jobs=[['scripts.text-normalization.helper-list',p]for p in ['compile','warm','compile-run']]+[['scripts.json-summary-helpers.large','warm'],['scripts.numeric-squared-error.floating.large','warm'],['calls.positional.large','warm']]
s=s[:a]+'jobs='+repr(jobs)+s[b:]
s=s.replace("s=s.replace('len(jobs)==5','len(jobs)==4');", "s=s.replace('len(jobs)==5','len(jobs)==6').replace('started < 210','started < 300');")
s=s.replace("len(raw['jobs'])==4", "len(raw['jobs'])==6").replace("jobs=4", "jobs=6")
s=s.replace("['jobs']==4", "['jobs']==6")
s=s.replace('native-index-refined-b954-20261118','prepared-names-b956-20261118')
# The retired prototype remains at its original exact path.
s=s.replace("knownPath='prepared-names-b956-20261118/candidate/Lokad.Lython.dll'", "knownPath='native-index-refined-b954-20261118/candidate/Lokad.Lython.dll'")
s=s.replace("'prepared-names-b956-20261118'),('benchmarks/results", "'native-index-refined-b954-20261118'),('benchmarks/results")
s=s.replace('lython-b954-native-index-refined-20261118','lython-b956-prepared-names-20261118')
s=s.replace("names=['collect.py'", "shutil.copyfile(r/'combined-catalog.json',q/'representative.json');names=['representative.json','collect.py'")
s=s.replace("sourceCatalogSHA256=identity['catalogSHA256']", "sourceCatalogSHA256=sha(r/'measurement-catalog.json')")
s=s.replace("s=s.replace('lython-b949-fixtures','lython-b954-fixtures');", "s=s.replace('lython-b949-fixtures','lython-b956-fixtures').replace('RuntimeMaxSec=330','RuntimeMaxSec=400').replace(\"os.link(source/'representative.json',root/'representative.json')\",\"if not(root/'representative.json').exists():os.link(source/'representative.json',root/'representative.json')\");")
s=s.replace("seconds=230", "seconds=340").replace("before230seconds", "before340seconds")
s=s.replace('Four-job native indexing source pair','Six-job prepared-name source pair')
s=s[:s.index("print('Four-job native-index comparison")]+"print('Six-job R525 pair prepared; both actual five-case goldens, all32image hashes, LF verified; only exact committed withdrawn-core/raw replicas eligible; current images/floors preserved.')\n"
(r/'prepare-quiet.py').write_text(s,encoding='utf-8',newline='\n')
print('Existing custody/collection/summarization tools reused; six bounded jobs with matching guard and service budget.')
