from pathlib import Path
import re

root = Path('D:/code/Lython/.git/agent-worktrees/prepared-names-r525')
def edit(relative, before, after):
    path = root / relative
    source = path.read_text(encoding='utf-8')
    assert before in source, (relative, before)
    path.write_text(source.replace(before, after), encoding='utf-8', newline='\n')

base = 'src/Lokad.Lython/'
edit(base+'Frontend/ExecutableScript.Builder.cs', 'List<string> _names', 'List<ExecutableName> _names')
edit(base+'Frontend/ExecutableScript.Infrastructure.cs', '_names.Add(name);', '_names.Add(new ExecutableName(name));')
edit(base+'Frontend/ExecutableScript.Infrastructure.cs', '        private int InternConstant(object? value)', '''        private int InternReceiverName(string name)
        {
            var index = InternName(name);
            _names[index] = LythonRuntime.PrepareReceiverName(_names[index]);
            return index;
        }

        private int InternConstant(object? value)''')
edit(base+'Frontend/ExecutableScript.Expressions.cs', 'var nameIndex = InternName(member.Member.MemberName);', 'var nameIndex = InternReceiverName(member.Member.MemberName);')
edit(base+'Frontend/ExecutableScript.cs', 'internal sealed partial class ExecutableCodeObject', '''// Compiler-owned immutable name facts. Receiver definitions contain no guest
// values or execution authority; global locations still require exact code identity.
internal readonly record struct ExecutableName(string Text, int ModuleGlobalSlot = -1,
    LythonRuntime.ReceiverMethod? StringMethod = null,
    LythonRuntime.ReceiverMethod? DictionaryMethod = null);

internal sealed partial class ExecutableCodeObject''')
edit(base+'Frontend/ExecutableScript.cs', 'string[] names,', 'ExecutableName[] names,')
edit(base+'Frontend/ExecutableScript.cs', 'public string[] Names { get; }', 'public ExecutableName[] Names { get; }')
edit(base+'Frontend/ExecutableScript.cs', '    internal int[] ModuleGlobalSlots { get; private set; } = [];\n', '')
edit(base+'Frontend/ExecutableScript.cs', '''        var slots = new int[Names.Length];
        for (var i = 0; i < slots.Length; i++)
        {
            if ((i & 1023) == 0) PythonTokenization.CheckCancellation(cancellationToken, 0);
            slots[i] = module.LocalNameToSlot.TryGetValue(Names[i], out var slot) ? slot : -1;
        }
        ModuleGlobalSlots = slots;''', '''        for (var i = 0; i < Names.Length; i++)
        {
            if ((i & 1023) == 0) PythonTokenization.CheckCancellation(cancellationToken, 0);
            Names[i] = Names[i] with
            {
                ModuleGlobalSlot = module.LocalNameToSlot.TryGetValue(Names[i].Text, out var slot) ? slot : -1
            };
        }''')

for path in (root/base/'Runtime').glob('*.cs'):
    text = path.read_text(encoding='utf-8')
    if re.search(r'\b(?:[Cc]ode|CodeObject|Code)\.Names\[', text):
        changed = re.sub(r'(\b(?:[Cc]ode|CodeObject|Code)\.Names\[[^\]]+\])', r'\1.Text', text)
        assert changed != text, path
        path.write_text(changed, encoding='utf-8', newline='\n')

edit(base+'Runtime/LythonRuntime.Executable.Binding.cs', 'code.ModuleGlobalSlots[nameIndex]', 'code.Names[nameIndex].ModuleGlobalSlot')
edit(base+'Runtime/LythonRuntime.Executable.Interpreter.cs', 'var operation = ResolveBuiltinReceiverMethod(receiver, name);', 'var operation = ResolveBuiltinReceiverMethod(receiver, execution.Code.Names[instruction.NameIndex]);')
edit(base+'Runtime/LythonRuntime.Executable.NativePrefix.cs', '''                        var name = Code.Names[instruction.NameIndex].Text;
                        var method = ResolveBuiltinReceiverMethod(receiver, name);''', '''                        var method = ResolveBuiltinReceiverMethod(receiver, Code.Names[instruction.NameIndex]);''')
edit(base+'Runtime/LythonRuntime.ReceiverMethods.cs', 'using Lokad.Lython.Runtime.Text;', 'using Lokad.Lython.Frontend;\nusing Lokad.Lython.Runtime.Text;')
edit(base+'Runtime/LythonRuntime.ReceiverMethods.cs', '''    private static ReceiverMethod? ResolveBuiltinReceiverMethod(object receiver, string name)
        => receiver switch
        {
            PyList when name == "append" => ReceiverMethods.ListAppend,
            PyDict => DictMembers.GetMethod(name),
            ExecutionContext.TextFileHandle when name == "write" => ReceiverMethods.TextWrite,
            ExecutionContext.BinaryFileHandle when name == "write" => ReceiverMethods.BinaryWrite,
            CsvWriterObject when name == "writerow" => ReceiverMethods.CsvWriterow,
            PyString => StringMembers.GetMethod(name),
            ReMatchObject => ReMatchMembers.GetMethod(name),
            _ => null,
        };''', '''    internal static ExecutableName PrepareReceiverName(in ExecutableName name)
        => name with
        {
            StringMethod = StringMembers.GetMethod(name.Text),
            DictionaryMethod = DictMembers.GetMethod(name.Text),
        };

    private static ReceiverMethod? ResolveBuiltinReceiverMethod(object receiver, in ExecutableName name)
        => receiver switch
        {
            PyList when name.Text == "append" => ReceiverMethods.ListAppend,
            PyDict => name.DictionaryMethod,
            ExecutionContext.TextFileHandle when name.Text == "write" => ReceiverMethods.TextWrite,
            ExecutionContext.BinaryFileHandle when name.Text == "write" => ReceiverMethods.BinaryWrite,
            CsvWriterObject when name.Text == "writerow" => ReceiverMethods.CsvWriterow,
            PyString => name.StringMethod,
            ReMatchObject => ReMatchMembers.GetMethod(name.Text),
            _ => null,
        };''')
edit('tests/Lokad.Lython.Tests/ExecutableMemberStoreTests.cs', '.NameIndex]);', '.NameIndex].Text);')
print('Private name pool replaces two arrays and prepares existing String/Dict definitions at call sites.')
