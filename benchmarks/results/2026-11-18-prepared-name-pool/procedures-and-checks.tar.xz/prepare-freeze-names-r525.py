from pathlib import Path
r = Path('D:/code/Lython/.git/agent-notes/review-20261031/prepared-names-r525')
source = (r.parent/'native-index-context-r523/freeze.py').read_text(encoding='utf-8')
source = source.replace("r=Path(__file__).resolve().parent", "r=Path(__file__).resolve().parent")
source = source.replace("work=repo/'.git/agent-worktrees/native-index-context-r523'", "work=repo/'.git/agent-worktrees/prepared-names-r525'")
source = source.replace('assert len(production)==2,production', 'assert len(production)==13,production')
source = source.replace("production+['tests/Lokad.Lython.Tests/StringIndexCacheCancellationTests.cs']", 'changed')
start = source.index('identity=dict(')
end = source.index("(frozen/'identity.json')", start)
source = source[:start]+'''identity=dict(referenceSource='Fully qualified3f873227/frozena5038a28; GREEN44256409242 cached',
    candidateSource='Private R525 one prepared name pool with text/live module slot/String+Dict definitions. Separate ModuleGlobalSlots array removed; existing name interning prepares receiver calls and cased-split reuses that fact. No guest value/token cache or new policy/owner/dispatch framework. Existing exact-type receiver guard and exact module-code guard retained. Both actual11/10 pass233internal/86public focused, including four new observable mixed-name/receiver/error-order cases. Metadata pool grows; no CPU/allocation gain claim.',
    imageFiles=images,sourceInputs=hashes,sourceInputsArchiveSHA256=sha(r/'candidate-sources.tar.xz'),productionFiles=587,
    changedProductionFiles=production,normalAdapterPin='0.4.0',publicationHeld=True)
''' + source[end:]
(r/'freeze.py').write_text(source, encoding='utf-8', newline='\n')
print('Existing copied-image/catalog/allocation verification reused; only the core image changes.')
