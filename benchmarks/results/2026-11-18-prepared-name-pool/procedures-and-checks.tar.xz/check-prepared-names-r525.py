from pathlib import Path
import json, os, subprocess
r = Path('D:/code/Lython/.git/agent-notes/review-20261031/prepared-names-r525')
r.mkdir(exist_ok=True)
work = Path('D:/code/Lython/.git/agent-worktrees/prepared-names-r525')
d = Path('C:/Users/JoannesVermorel/.dotnet11/dotnet.exe')
env = os.environ.copy()
env.update(DOTNET_ROOT=str(d.parent), DOTNET_ROOT_X64=str(d.parent))
env['PATH'] = str(d.parent) + os.pathsep + env['PATH']
filters = {
    'internal': ['DirectDictionaryGet', 'DirectString', 'ExecutableMemberStore',
        'NativeClosure', 'LoweringArchitectureSubsystem', 'StringIndexCacheCancellation',
        'TextOperationProvenance', 'InstructionFailureRouting', 'NativeScalarDispatchBoundary',
        'DictionaryReadBoundary', 'NativeHelper', 'CasedSplitOwnership'],
    'public': ['NativeReceiverPipeline', 'GlobalBindingPipeline', 'CompilerCancellation',
        'HelperLocalLifetime', 'GovernedMemoryContract', 'MemoryDenialAttribution',
        'BulkReplacement', 'FloatArithmeticPipeline', 'ContainerDisplayPipeline',
        'ProtectedHelperExecution', 'BufferedGeneratorContinuation'],
}
rows = []
for tfm in ['net11.0', 'net10.0']:
    for kind, parts in filters.items():
        project = 'Lokad.Lython.Tests' if kind == 'internal' else 'Lokad.Lython.PublicApi.Tests'
        cmd = [str(d), 'test', f'tests/{project}/{project}.csproj', '-c', 'Release', '-f', tfm,
            '--no-build', '--filter', '('+'|'.join('FullyQualifiedName~'+p for p in parts)+')&Category!=Stress']
        log_path = r / f'{kind}-{tfm}.log'
        with log_path.open('w', encoding='utf-8') as log:
            p = subprocess.run(cmd, cwd=work, env=env, stdout=log, stderr=subprocess.STDOUT, timeout=180)
        rows.append(dict(kind=kind, framework=tfm, command=cmd, exitCode=p.returncode))
        (r/'checks.json').write_text(json.dumps(rows, indent=2)+'\n', encoding='utf-8')
        output = log_path.read_text(encoding='utf-8')
        assert p.returncode == 0, output
        print(kind, tfm, output.splitlines()[-1], flush=True)
