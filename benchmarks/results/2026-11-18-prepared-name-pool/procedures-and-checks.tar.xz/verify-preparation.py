from pathlib import Path
import json
r=Path(__file__).parent
c=json.loads((r/'quiet/config.json').read_text(encoding='utf-8'))
s=(r/'quiet/remote-launch.py').read_text(encoding='utf-8')
assert 'RuntimeMaxSec=400' in s
assert "if not(root/'representative.json').exists():" in s
assert b'\r' not in (r/'quiet/run.sh').read_bytes()
assert 'started < 300' in (r/'quiet/collect.py').read_text(encoding='utf-8')
assert "['jobs']==6" in (r/'quiet/retrieve.py').read_text(encoding='utf-8')
assert "len(raw['jobs'])==6" in (r/'quiet/archive-owned.py').read_text(encoding='utf-8')
assert c['sourceCatalogSHA256']!=c['catalogSHA256']
assert len(c['retireGroups'])==4
print(c['root'],'payload',c['unpackedBytes'],'exact replicas',[(p['kind'],p['bytes'],p['links']) for p in c['retireGroups']])
