using Lokad.Lython.Frontend;
using Lokad.Lython.Runtime.Text;

namespace Lokad.Lython.Runtime;

internal sealed partial class LythonRuntime
{
    internal static ExecutableName PrepareReceiverName(in ExecutableName name)
        => name with
        {
            StringMethod = StringMembers.GetMethod(name.Text),
            DictionaryMethod = DictMembers.GetMethod(name.Text),
        };

    private static ReceiverMethod? ResolveBuiltinReceiverMethod(object receiver, in ExecutableName name)
        => receiver switch
        {
            PyList when name.Text == "append" => ReceiverMethods.ListAppend,
            PyDict => name.DictionaryMethod,
            ExecutionContext.TextFileHandle when name.Text == "write" => ReceiverMethods.TextWrite,
            ExecutionContext.BinaryFileHandle when name.Text == "write" => ReceiverMethods.BinaryWrite,
            CsvWriterObject when name.Text == "writerow" => ReceiverMethods.CsvWriterow,
            PyString => name.StringMethod,
            ReMatchObject => ReMatchMembers.GetMethod(name.Text),
            _ => null,
        };

    // Both instruction drivers use the same closed receiver calls. Declining
    // performs no operation or admission; protocols and actual I/O still promote.
    private static bool TryInvokeClosedReceiver(ReceiverMethod method, object receiver,
        Span<ExecutableSlot> arguments, LythonSourceSpan span, ExecutionContext context, out object result)
    {
        result = PyNone.Instance;
        if (arguments.IsEmpty && receiver is PyString or PyDict && method.AcceptsPositional(0))
        {
            result = InvokeReceiverMethod(method, receiver, span, context);
            return true;
        }
        if (arguments.Length == 1 && receiver is PyList && ReferenceEquals(method, ReceiverMethods.ListAppend))
        {
            var supplied = ReceiverArguments.Single(arguments[0].Object);
            result = InvokeReceiverMethod(method, receiver, supplied, span, context);
            return true;
        }
        if (receiver is PyString text && arguments.Length is >= 1 and <= 3
            && SelectNativeStringOperation(method, arguments.Length) is { } operation)
        {
            // Snapshot evaluated inputs before admission can reenter the host.
            var first = arguments[0].Object;
            var second = arguments.Length > 1 ? arguments[1].Object : null;
            var third = arguments.Length > 2 ? arguments[2].Object : null;
            if (!CanUseNativeStringCall(operation, first, second, third)) return false;
            result = InvokeNativeStringOperation(operation, text, first, second, third, span, context);
            return true;
        }
        if (receiver is PyDict dictionary && arguments.Length is 1 or 2
            && ReferenceEquals(method, ReceiverMethods.DictionaryGet))
        {
            var key = arguments[0].Object!;
            if (!dictionary.CanReadKeySynchronously(key)) return false;
            var fallback = arguments.Length == 2 ? arguments[1].Object! : PyNone.Instance;
            result = InvokeDictionaryGet(dictionary, key, fallback, span, context);
            return true;
        }
        return false;
    }

    // A shared implementation is not a Python callable until paired with a
    // receiver. Immediate calls keep that pair in the existing operand storage;
    // an attribute exposed as a value uses the ordinary bound-method wrapper.
    internal sealed class ReceiverMethod(
        LythonCallableSignature signature,
        Func<object, ReceiverArguments, LythonSourceSpan, ExecutionContext, object> implementation,
        Func<object, ReceiverArguments, LythonSourceSpan, ExecutionContext, ValueTask<object>>? asyncImplementation = null)
    {
        private readonly Func<object, LythonSourceSpan, ExecutionContext, object>? _noArgumentsImplementation;

        public ReceiverMethod(LythonCallableSignature signature,
            Func<object, LythonSourceSpan, ExecutionContext, object> implementation)
            : this(signature, (receiver, _, span, context) => implementation(receiver, span, context))
        {
            _noArgumentsImplementation = implementation;
        }

        public LythonCallableSignature Signature { get; } = signature;

        public bool AcceptsPositional(int count)
            => count >= Signature.Parameters.MinimumArgumentCount &&
               Signature.Parameters.MaximumArgumentCount.Accepts(count) &&
               (Signature.Parameters is not NamedCallableParameterLayout named ||
                named.MaximumPositionalArgumentCount.Accepts(count));

        // Reuse the existing fixed-arity wrapper for exposed zero-argument
        // values. It owns its bound receiver (including live mapping bridges)
        // and validates raw arguments without changing unrelated binder errors.
        public ICallable Bind(object receiver) => _noArgumentsImplementation is { } operation
            ? BoundCallable.CreateNoArguments(receiver, Signature.Name, operation)
            : BoundCallable.Create(receiver, this);

        public object Invoke(object receiver, ReceiverArguments arguments, LythonSourceSpan span, ExecutionContext context)
            => implementation(receiver, arguments, span, context);

        public object Invoke(object receiver, LythonSourceSpan span, ExecutionContext context)
            => _noArgumentsImplementation is { } operation ? operation(receiver, span, context)
                : implementation(receiver, default(ReceiverArguments), span, context);

        public ValueTask<object> InvokeAsync(object receiver, ReceiverArguments arguments, LythonSourceSpan span, ExecutionContext context)
            => asyncImplementation is null ? new(Invoke(receiver, arguments, span, context))
                : asyncImplementation(receiver, arguments, span, context);

    }

    private static object InvokeReceiverMethod(ReceiverMethod method, object receiver,
        LythonSourceSpan span, ExecutionContext context)
    {
        context.EnterInterpreterFrame(span);
        try
        {
            context.CheckExecution(span);
            return method.Invoke(receiver, span, context);
        }
        catch (Exception error) when (TryTranslateCallableException(error, span, out var translated)) { throw translated; }
        finally { context.LeaveInterpreterFrame(); }
    }

    private static object InvokeReceiverMethod(ReceiverMethod method, object receiver, ReceiverArguments arguments,
        LythonSourceSpan span, ExecutionContext context)
    {
        context.EnterInterpreterFrame(span);
        try
        {
            context.CheckExecution(span);
            return method.Invoke(receiver, arguments, span, context);
        }
        catch (Exception error) when (TryTranslateCallableException(error, span, out var translated)) { throw translated; }
        finally { context.LeaveInterpreterFrame(); }
    }

    private static ValueTask<object> InvokeReceiverMethodAsync(ReceiverMethod method, object receiver,
        ReceiverArguments arguments, LythonSourceSpan span, ExecutionContext context)
    {
        context.EnterInterpreterFrame(span);
        var transferred = false;
        try
        {
            context.CheckExecution(span);
            var pending = method.InvokeAsync(receiver, arguments, span, context);
            if (pending.IsCompleted) return new(pending.GetAwaiter().GetResult());
            transferred = true;
            return CompleteReceiverMethodAsync(pending, span, context);
        }
        catch (Exception error) when (TryTranslateCallableException(error, span, out var translated)) { throw translated; }
        finally { if (!transferred) context.LeaveInterpreterFrame(); }
    }

    // Only genuine suspension retains the guarded call. Completed native
    // operations use the ordinary synchronous cleanup and publication order.
    private static async ValueTask<object> CompleteReceiverMethodAsync(ValueTask<object> pending,
        LythonSourceSpan span, ExecutionContext context)
    {
        try { return await pending.ConfigureAwait(false); }
        catch (Exception error) when (TryTranslateCallableException(error, span, out var translated)) { throw translated; }
        finally { context.LeaveInterpreterFrame(); }
    }

    private static class ReceiverMethods
    {
        internal static readonly ReceiverMethod ListAppend = new(
            LythonCallableSignature.Create("list.append", ["value"], 1, 1, LythonVariadicParameters.None, 1),
            static (receiver, arguments, span, context) => ListMembers.Append((PyList)receiver, arguments[0]!, span, context));

        internal static readonly ReceiverMethod DictionaryGet = new(
            LythonCallableSignature.Create("dict.get", ["key", "default"], 1, 2, LythonVariadicParameters.None, 2),
            static (receiver, arguments, span, context) => DictMembers.Get((PyDict)receiver, arguments[0]!,
                arguments.Length == 2 ? arguments[1]! : PyNone.Instance, span, context),
            static (receiver, arguments, span, context) => ((PyDict)receiver).CanReadKeySynchronously(arguments[0]!)
                ? new(DictMembers.Get((PyDict)receiver, arguments[0]!, arguments.Length == 2 ? arguments[1]! : PyNone.Instance, span, context))
                : DictMembers.GetAsync((PyDict)receiver, arguments[0]!, arguments.Length == 2 ? arguments[1]! : PyNone.Instance, span, context));

        internal static readonly ReceiverMethod DictionarySetDefault = new(
            LythonCallableSignature.Create("dict.setdefault", ["key", "default"], 1, 2, LythonVariadicParameters.None, 2),
            static (receiver, arguments, span, context) => DictMembers.SetDefault((PyDict)receiver, arguments[0]!,
                arguments.Length == 2 ? arguments[1]! : PyNone.Instance, span, context));

        internal static readonly ReceiverMethod TextWrite = new(
            LythonCallableSignature.Create("file.write", ["text"]),
            static (receiver, arguments, span, _) => TextFileHandleMembers.Write((ExecutionContext.TextFileHandle)receiver, arguments[0]!, span),
            static (receiver, arguments, span, _) => TextFileHandleMembers.WriteAsync((ExecutionContext.TextFileHandle)receiver, arguments[0]!, span));

        internal static readonly ReceiverMethod BinaryWrite = new(
            LythonCallableSignature.Create("file.write", ["value"], 1, 1, LythonVariadicParameters.None, 1),
            static (receiver, arguments, span, _) => ((ExecutionContext.BinaryFileHandle)receiver).Write(arguments[0]!, span));

        internal static readonly ReceiverMethod CsvWriterow = new(
            LythonCallableSignature.Create("csv.writerow", ["row"]),
            static (receiver, arguments, span, context) => RuntimeValue(CsvWriterMembers.WriteRowFromValue((CsvWriterObject)receiver, arguments[0]!, span, context)),
            static async (receiver, arguments, span, context) => RuntimeValue(await CsvWriterMembers.WriteRowFromValueAsync((CsvWriterObject)receiver, arguments[0]!, span, context).ConfigureAwait(false)));

        internal static readonly ReceiverMethod StringJoin = new(
            LythonCallableSignature.Create("str.join", ["iterable"]),
            static (receiver, arguments, span, context) => StringMembers.Join((PyString)receiver, arguments[0]!, span, context),
            static (receiver, arguments, span, context) => StringMembers.JoinAsync((PyString)receiver, arguments[0]!, span, context));

        internal static readonly ReceiverMethod StringSplit = new(
            LythonCallableSignature.Create("str.split", ["sep", "maxsplit"], 0),
            static (receiver, arguments, span, context) => StringMembers.Split((PyString)receiver,
                arguments.Length >= 1 ? arguments[0] : null, arguments.Length == 2 ? arguments[1] : null, span, context),
            static (receiver, arguments, span, context) => arguments.Length == 2 && arguments[1] is PyInstance
                ? StringMembers.SplitAsync((PyString)receiver, arguments[0], arguments[1]!, span, context)
                : new(StringMembers.Split((PyString)receiver, arguments.Length >= 1 ? arguments[0] : null,
                    arguments.Length == 2 ? arguments[1] : null, span, context)));

        internal static readonly ReceiverMethod StringReplace = new(
            LythonCallableSignature.Create("str.replace", ["old", "new", "count"], 2),
            static (receiver, arguments, span, context) => StringMembers.Replace((PyString)receiver,
                arguments[0]!, arguments[1]!, arguments.Length == 3 ? arguments[2] : null, span, context),
            static (receiver, arguments, span, context) => StringMembers.ReplaceAsync((PyString)receiver,
                arguments[0]!, arguments[1]!, arguments.Length == 3 ? arguments[2] : null, span, context));

        internal static readonly ReceiverMethod StringStartsWith = Affix("str.startswith", true);
        internal static readonly ReceiverMethod StringEndsWith = Affix("str.endswith", false);

        private static ReceiverMethod Affix(string name, bool isStart)
            => new(LythonCallableSignature.Create(name, 1),
                (receiver, arguments, span, context) => StringMembers.InvokeStringAffix((PyString)receiver, arguments, span, context, isStart, false).GetAwaiter().GetResult(),
                (receiver, arguments, span, context) => StringMembers.InvokeStringAffix((PyString)receiver, arguments, span, context, isStart,
                    (arguments.Length >= 2 && arguments[1] is PyInstance) || (arguments.Length == 3 && arguments[2] is PyInstance)));
    }
}
