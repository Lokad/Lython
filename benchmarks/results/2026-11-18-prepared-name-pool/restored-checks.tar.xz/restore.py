from pathlib import Path
import hashlib,json,shutil,subprocess
r=Path(__file__).parent;repo=Path('D:/code/Lython');work=repo/'.git/agent-worktrees/prepared-names-r525'
f=json.loads((r/'frozen/identity.json').read_text(encoding='utf-8'))
assert all(hashlib.sha256((work/n).read_bytes()).hexdigest()==h for n,h in f['sourceInputs'].items())
assert not subprocess.check_output(['git','diff','--name-only'],cwd=repo,text=True).strip()
test='tests/Lokad.Lython.PublicApi.Tests/NativeReceiverPipelineTests.cs'
shutil.copyfile(work/test,repo/test)
changed=subprocess.check_output(['git','diff','--name-only'],cwd=work,text=True).splitlines()
assert len([n for n in changed if n.startswith('src/Lokad.Lython/')])==13
subprocess.run(['git','restore','--source=HEAD','--']+changed,cwd=work,check=True)
assert not subprocess.check_output(['git','diff','--name-only'],cwd=work,text=True).strip()
assert not subprocess.check_output(['git','diff','--name-only','--','src/Lokad.Lython'],cwd=repo,text=True).strip()
(r/'restored-production.json').write_text(json.dumps(dict(measuredSourcesVerified=2390,productionFilesRestored=13,
    privateWorktreeClean=True,mainProductionUnchanged=True,retainedObservableRegressions=4),indent=2)+'\n',encoding='utf-8')
print('Measured source verified; 13 production files and architecture assertion restored, private tree clean; four semantic regressions retained on main.')
