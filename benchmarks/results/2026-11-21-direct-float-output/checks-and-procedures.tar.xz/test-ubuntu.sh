set -euo pipefail
cd /mnt/d/code/Lython/.git/agent-worktrees/pinned-unicode-casing-20261121
export DOTNET_ROOT="$HOME/.dotnet"
export PATH="$DOTNET_ROOT:$PATH"
logs=/mnt/d/code/Lython/.git/agent-notes/review-20261031/direct-float-output
filter='(FullyQualifiedName~Json|FullyQualifiedName~Numeric|FullyQualifiedName~Float|FullyQualifiedName~Format|FullyQualifiedName~Render)&Category!=Stress'
dotnet test tests/Lokad.Lython.Tests -c Release -f net10.0 --filter "$filter" | tee "$logs/white-ubuntu.log"
dotnet test tests/Lokad.Lython.PublicApi.Tests -c Release -f net10.0 --filter "$filter" | tee "$logs/public-ubuntu.log"
