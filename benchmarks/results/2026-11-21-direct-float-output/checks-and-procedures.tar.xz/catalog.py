from pathlib import Path
import base64,hashlib,json,struct,subprocess,tempfile
lab=Path(__file__).resolve().parent
template=json.loads((lab.parent/"bulk-csv-field-output/representative.json").read_text(encoding="utf-8"))
sha=lambda b:hashlib.sha256(b).hexdigest()
b64=lambda b:base64.b64encode(b).decode("ascii")
size=3072
numbers=("0.0","-0.0","-0.00125","123456.125","5e-324","2.2250738585072014e-308",
         "1.2345678901234568e16","-4.779900000321e22","-1.0000000000000002","1.198006530640337e+89")
integer_tokens=tuple(str(x) for x in (0,-1,-70,123456,5,-14,82230,-45448,-1000000,45462))
body='''import csv
import json

with open("measurements.csv", encoding="utf-8", newline="") as source:
    records = []
    for row in csv.DictReader(source):
        records.append({"id": row["id"], "latency": @@type@@(row["latency"]), "rate": @@type@@(row["rate"]), "weight": @@type@@(row["weight"])})
with open("@@path@@", "w", encoding="utf-8", newline="") as target:
@@write@@
print(len(records))
'''
rows=[]
for label,tokens,number,output in (("finite-json",numbers,"float","records.json"),("finite-repr",numbers,"float","records.txt"),
                                    ("integer-json",integer_tokens,"int","records.json")):
    dataset=("id,latency,rate,weight\n"+"".join(f"S{i:05},{tokens[i%len(tokens)]},{tokens[(i+3)%len(tokens)]},{tokens[(i+6)%len(tokens)]}\n"
                                                    for i in range(size))).encode("utf-8")
    write='    json.dump(records, target, separators=(",", ":"))'
    if label=="finite-repr":
        write='    for row in records:\n        target.write(row["id"] + "\\t" + str(row["latency"]) + "\\t" + repr(row["rate"]) + "\\t" + str(row["weight"]) + "\\n")'
    source=body.replace("@@type@@",number).replace("@@path@@",output).replace("@@write@@",write)
    with tempfile.TemporaryDirectory(prefix="lython-numeric-catalog-") as d:
        files=Path(d)
        (files/"measurements.csv").write_bytes(dataset)
        proc=subprocess.run(["C:/Python313/python.exe","-I","-S","-X","utf8","-c",source],cwd=files,capture_output=True,check=True,timeout=15)
        out=proc.stdout.replace(b"\r\n",b"\n")
        result=(files/output).read_bytes()
    fixture=json.dumps(dict(size=size,text=None,inputFiles={"measurements.csv":b64(dataset)},outputFiles={output:b64(result)}),separators=(",",":"))
    key=output.encode("utf-8")
    rows.append(dict(id="scripts.measurement-export."+label,family="scripts",category="numeric-output",scale="large",size=size,
        source=source,fixtureJson=fixture,expectedOutput=out.decode(),sourceUtf8Bytes=len(source.encode()),expectedOutputUtf8Bytes=len(out),
        fixtureTextUtf8Bytes=0,fixtureTextCodePoints=0,sourceSha256=sha(source.encode()),fixtureSha256=sha(fixture.encode()),
        expectedOutputSha256=sha(out),expectedFilesSha256=sha(struct.pack(">ii",1,len(key))+key+struct.pack(">i",len(result))+result)))
    print(label,len(dataset),len(result),out.decode().strip())
template["cases"]=rows+[template["cases"][-1]]
(lab/"representative.json").write_text(json.dumps(template,indent=2)+"\n",encoding="utf-8",newline="\n")
