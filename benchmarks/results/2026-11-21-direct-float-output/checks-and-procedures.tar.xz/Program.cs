using System.Globalization;
using Lokad.Lython.Runtime.Numbers;

using var output = new StreamWriter(args[1], false, new System.Text.UTF8Encoding(false));
output.NewLine = "\n";
foreach (var line in File.ReadLines(args[0]))
    output.WriteLine(PyNumberOps.RenderFloat(BitConverter.UInt64BitsToDouble(
        ulong.Parse(line, NumberStyles.HexNumber, CultureInfo.InvariantCulture))));
