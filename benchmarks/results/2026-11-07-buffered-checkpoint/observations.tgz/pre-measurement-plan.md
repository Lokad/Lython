# Lokad.Lython 0.11.0

Updated 2026-11-07. Git-ignored; never force-add. Publication/tagging postponed.
Objective: coherent simplification and substantial complete-script performance.
An isolated experiment, qualification or source gate does not complete it.

## Delivery status

| Work | Actual state |
| --- | --- |
| Core through R58 / e66b8f72 | FULLY QUALIFIED: CI 42404834827 Windows/Ubuntu Release actual .NET 11/10, original Stress and installed consumers. Cached receipt 8937cf00; never query again. |
| f519e54b before R62 | Evidence/public decoded-text interoperability; qualified production unchanged. R57 product admission/cancellation/start correctness and R58 dense graph replacement preserved. |
| R62 demand-driven validation | Retained source,559 internal / 1,492 public per actual .NET 11/10;716 exact diagnostic comparisons; B418 controlled comparison/archive complete. Committed/pushed 70267889; FULLY QUALIFIED CI 42412531882: Windows/Ubuntu, actual .NET 11/10, original Stress and installed consumers. Terminal cached; never query again. |
| R59 immutable dev54 adapter |86 internal / 514 public per actual .NET 11/10 with existing development bridge. Normal optional 0.4 pin/core unchanged; final released adapter/safety/performance qualification remains separate. |
| R60 storage windows | Both variants WITHDRAWN; exact qualified production restored, forced builds and focused checks completed. No active representation prototype or architecture-only tests. Independent public regressions preserved. |

R62 eliminates unnecessary whole-script generator/type/future validation and
unchanged scope-set allocation; existing distinct rules/order remain. Controlled
compile elapsed−2.94–5.88%, fresh config−1.32–1.45%; compile allocation−3.15–4.07%.
Warm text−0.51/−0.42% is a control, not a runtime speedup. Quantized worker CPU,
adverse/unstable desktop clocks and initial staging failure remain in
[evidence](benchmarks/results/2026-11-07-syntax-validation/README.md).
No unchanged full qualification or old service/status queries.

## Completed work / measurement boundaries

- Shared compiler-fact correction, direct UTF-8 formatting/storage and native
  helper returns are delivered/qualified. Returns allocation−19.92/−19.31%; prior
  elapsed improvements remain diagnostic. Formatting allocation−8.67%; controlled
  B102 elapsed/CPU−5–8% supports retention. Original15.125ms adverse point remains
  unexplained/preserved; no further format correction is currently justified.
- Bulk CSV has been selectively reconsidered: R20/R25 shared keys/value transfer
  supersede the rigidly rejected constructor. Allocation−7.31/−6.55%, native warm
  −7.72–8.04%, controls mixed. No automatic promotion of the old implementation.
- Native returns/borrowed operands/final slots/deferred contexts/reused workspaces,
  shared bindings, UTF-8 integer parsing/wildcards, R55 lexical-prepass removal,
  R57 correct product funding and R58 graph consolidation remain. Do not rediscover
  these, direct UTF-8 casing/lower-split/final formatting, or native scalar sum.
- R54/R60 general text-window representations are withdrawn, with allocation wins
  but access/ownership complexity and adverse complete-script controls preserved.
  R61 finds zero escaped tokens in current JSON/report/config; existing native
  container loops/shared keys/direct slots rule out that proposed copy campaign.
  Slower call-arena/call-control designs remain lessons, not permanent design bans.

Keep details behind [history](benchmarks/EXPERIMENTS.md), current
[performance guide](docs/BENCHMARKS.md) and immutable results; do not repeat them
in active tasks. Primary CPython snapshot B409 / 55e510ff, CPython 3.13.16, is complete
and labeled by revision/date/machine. Compile, warm and compile-to-result are
separate; mediated RAM I/O/full validation/prior-result cleanup included, startup/
staging/reset/transport/final teardown excluded. Startup, pending-I/O latency,
RSS and embedding tails remain unmeasured. Refresh at the next substantial
retained runtime checkpoint; do not relabel historical measurements as HEAD.

## Next deliverable — material whole-script runtime redesign

While R62 full delivery runs, use current source and existing captures to select
one complete phase to remove. R52 report 927 samples locates JSON/format/dispatch;
binding 13 self / rent 3 / frame 3 do not prove dominant call packaging. R56 config 551
samples shows substantial host open/path work, not a justified lazy-builtin
subsystem; retain capability/path checks and document CPython host asymmetry.

R63/B419 current text attribution is COMPLETE: 1,086 guest CPU samples / 5.47
CPU seconds, 65 unknown leaves; all identity/golden/quiet/ownership/archive gates.
[Evidence](benchmarks/results/2026-11-07-text-cpu-current/README.md). Dispatch,
input handling and value publication are material regions. Inclusive native-call/
helper/split shares overlap; no dominant remaining binder/frame phase established.
No prototype or speedup claim. Native lower/split, native keys and cheap counter
admission already exist. This completes the investigation, not the objective.

R64 source gate COMPLETE: the common producer path already skips adjacent-store
dispatch and the temporary result write. Removing the retained store would relocate
target/span metadata and add delayed-cleanup continuation state. No complete
remaining phase established; no prototype/timing selected. Input-carrier presence
also does not prove machine-code traffic. [Source decision](benchmarks/results/2026-11-07-text-cpu-current/publication-source-gate.md).
Preserve the current funding, retirement order and source spans; future coherent
representation work remains possible with new evidence.

R65 selected deletion: module outward class-cell analysis has no consumer. The
executable builder admits hidden captures only for a parameterized function scope;
runtime module contexts use empty scope facts. Static analysis does not consume
module RequiresClassCell. Existing function/class/lambda/generator queries have
real callers and different postponed-annotation, nested-class and shadowing rules.
A general merge would require additional demand states; do not introduce it here.

Remove the final module ReferencesFromFunction walk in lexical preparation and
disable the same unused demand in the standalone ForModule fallback. Preserve
module bindings/order, all real capture queries, preloads and class-cell Scope.
No new helper/cache, public contract or runtime route. CSV/text/report/config
compilation is affected; no warm improvement predicted. Preserve diagnostics,
module globals/locals and nested captures, annotations, comprehension/default
boundaries, global/nonlocal, cancellation and terminal refusal. Existing scope/
class-cell/annotation/generator/admission regressions plus exact diagnostic/probe
comparison; one short existing-tool compilation/fresh/warm diagnostic. A pure
unused-analysis deletion needs no new VM campaign or unchanged full qualification.
Batch full delivery with the next coherent retained checkpoint; record deletion,
allocation and noisy elapsed separately. Larger binding/class-cell consolidation
and substantial runtime improvements remain open; this is no replacement objective.

For the selected redesign, before code record hypothesis, eliminated work/storage,
affected complete scripts, semantic/token/admission gates, displaced implementation
to delete and completion/debt decision. Permit temporary setbacks within an explicit
completion milestone; do not accumulate parallel old/new routes or special cases.

| Candidate boundary | Acceptance / displacement |
| --- | --- |
| Complete call/frame construction | CSV/text/report helpers; eliminate an actual remaining phase after existing borrowed/native paths. Preserve defaults/keywords/variadics/closures/recursion/evaluation order/errors/suspension and caller funding through cleanup. Delete displaced binding/frame machinery; previous slower arena/control designs are controls, not templates. |
| Operand / boxed-value dispatch | Counters, updates and helper results; remove repeated transport/dispatch if newly demonstrated material. Preserve public BigInteger, CLR ingress round trips, identity, exact promotion, protocols, cancellation and aliases. No universal tagged-value project based on boxing alone. |
| Per-record construction | CSV/JSON/report; shared keys/value transfer/direct record slots already exist. Select a real remaining capacity/copy phase, preserve hooks/order/reentry/mutation/overlap and delete replaced construction code. |
| Remaining text conversion | Text/report; preserve Unicode expansion/context, precision/formatting, hashes and native storage. Select whole conversion/storage phase, not speculative per-access tuning or hidden interning. |
| Repeated frontend analysis | R55/R58/R62 remove actual repeated work; lexical/validity scopes differ and must not be mechanically merged. Binding/parsing remain material historical targets; preserve diagnostics/order/dead scopes/annotations/imports/generators and remove displaced passes/facts. No compiler rewrite justified by LoweredScript2.6–3.0% alone. |

Each retained redesign gets focused correctness/ownership/cancellation checks and
one bounded before/after complete-script comparison with unchanged controls.
Report simplification, allocation, controlled elapsed and CPU separately; keep
adverse observations and unresolved regression debt explicit. Reconfirm/refine or
correct measurement when evidence warrants it. Timeouts/unstable unchanged controls
establish uncertainty, not a failed design. No blanket one-attempt/no-retiming/
permanent-closure rules; percentages inform decisions, not automatic vetoes.

## Independent regex deliverable

Core owns Python/native UTF-8, byte ranges/scalar positions/original windows,
flags/captures/replacements/errors, explicit cache ownership and current tokens.
No Utf8Regex runtime dependency; optional adapter remains nonpackable 0.4.0.
Completed contract/semantic work stands independently of producer publication.
Development producers and adapter-local bridges are acceptable; do not move them
into core or confuse compatibility tests with backend performance.

R59 immutable 0.5.0-dev.54 / 553acbdf compatibility is completed, with
[precise evidence](benchmarks/results/2026-11-07-regex-dev54/README.md).
Outstanding producer gaps: DetailedData has no distinct preparation/working-owner
input; UTF-8 name lookup lacks native enumeration; cursor creation retains its
token despite current-move overloads. Existing conservative bridges remain.
Qualify a supported immutable released package and managed-safety policy separately.
These gaps defer only affected final adapter qualification; no core stopping rule,
sibling edits, silent dialect fallback, regex quota or abandoned background work.

## Validation / lasting constraints

Focused Release with explicit Category!=Stress during iteration; matching probe
build before dependent tests. Actual11 normally, actual10 at coherent checkpoints.
No overlapping local builds/tests/measurements. After preserved-timestamp restore,
force a nonincremental build. Batch full Windows/Ubuntu, both targets, original
Stress and installed core consumers at retained milestones; continue during CI,
status checks at least 5 minutes apart, cache terminal results. No assertion/timeout
relaxation. Only core Release pack via tools/pack.ps1; publication postponed.

AGENTS.md governs fully managed memory safety, managed stack admission, host
capabilities, cooperative cancellation, shared allowance/preflights/replacement
overlap/retained aliases, terminal first refusal and awaited deterministic cleanup.
No unsafe/Unsafe/PInvoke/native probes, fuel/quotas/caps/hidden allowance, tracing,
weak reclamation or forced GC. XML depth remains; bounded streams use host batches.
Later compiler passes can finish before the next token check. Explicit UTF-8 text.

VM lokad@20.166.121.73, key ~/.ssh/id_lython-bench.pem. B385–B419 terminal,
archived/locally verified; never query old services. No active VM worker/mount.
Records/workers persistent, separate owned RAM guest fixtures; verify archives
under lease and locally, join all users/unmount. Keep 256 MiB staging headroom;
owned hard links avoid redundant core copies. Preserve original setup failures.
Docs describe current implementation; plans/history/receipts stay outside docs.



R65 module-only analysis deletion RETAINED: 591 internal / 1,793 public per actual
.NET 11/10, 716 exact diagnostic records and 32 CPython probes pass. Compile
allocation −3.53–4.64%; warm essentially unchanged. No CPU claim from adverse/
drifting desktop clocks. [Evidence](benchmarks/results/2026-11-07-module-class-facts/README.md).
No replacement mechanism or public contract; genuine capture queries remain.
Full new-source delivery batches at the next coherent checkpoint; do not relabel
R62's green 70267889 receipt as qualification of this newer source. Committed/pushed 5dd131bf;
resume the material runtime roadmap. No active local/VM worker or prototype.

R66 selected buffered-line redesign: one shared scanner/emission core for public
readline and native destination reads; synchronous-prefix completion for buffered
data, iterative async continuation only after a pending refill. Delete duplicated
sync/async line algorithms and per-line forwarding state machines. Keep current
UTF-8/newline/rune-limit logic and raw-window funding; caller-owned destinations
are never disposed here, private builders transfer to the sole continuation until
actual I/O and cleanup finish. No new owner, result framework, backend or option.
CSV/text/JSON-lines/search and both Run APIs are affected. Existing reader/codec/
newline/CSV/JSON/cancellation/refusal/retained-result tests plus genuine pending
refill/unwind coverage. One existing-tool sync/async allocation diagnostic and a
bounded quiet-VM source pair using warm/warm-async lanes if retained; no CPU gain
prediction, preserve adverse controls and first failure. Full delivery batches R65
and retained R66 at that coherent checkpoint; publication remains postponed.

R66/B420 declared:6warm/warm-async jobs, four independent old/current/control
roles;5s warmup/role,11rotated200ms rounds.240sowner+30sstop+30smargin; observe300s.
Combined source baseline70267889/frozen74c88248 fully qualified; local diagnostic
isolates R66 onR65. Allocation neutral, desktop CSV adverse/controls unstable;
no predicted gain or threshold veto. One new core, complete hard-linked images,
256MiB staging headroom and all Ready/golden/funding/quiet/join/fixture/archive
gates. Preserve original variant before any refinement.

R66 RETAINED after B420: 637 internal / 3,584 public per actual11/10, new12pending
cases also baseline-green; all source/golden/funding/quiet/archive gates. Async
text elapsed −2.32–8.26%, JSON −1.46–3.96%; allocation neutral. Between-process
variation/quantized CPU and adverse sync CSV/report remain uncertainty, not proved
general CPU/sync improvement. [Evidence](benchmarks/results/2026-11-07-buffered-lines/README.md).
No unchanged retiming now; bounded confirmation remains available when it changes
a decision. B420 terminal/archived/locally verified; no workers/mounts.
R66 committed/pushed 824fc6bb; dispatch combined R65/R66 full platform/Stress/package delivery.
Then refresh representative CPython comparisons at this coherent runtime checkpoint,
keeping compile/warm/fresh and I/O/cleanup boundaries explicit. Continue independent
roadmap while CI runs; never query cached R62 CI42412531882 again.

R67/B421 milestone refresh declared: unchanged23CPython jobs, two current-process
controls,5s warmup/role,7rotated150ms rounds.600sowner+30sstop+30smargin; observe660s.
Frozen15c04e2a corresponding to824fc6bb source, precommitSourceLink5dd131bf explicit;
full R65/R66 CI remains independent.256MiB staging floor, verified redundant
B415 reference extraction may be reclaimed; immutable archives remain. All source/
Ready/golden/quiet/join/fixture/archive gates; preserve adverse/control uncertainty
and compile/warm/fresh I/O/cleanup boundaries. No new framework/publication.
