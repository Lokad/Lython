$ErrorActionPreference='Stop'
$env:DOTNET_ROOT='C:/Users/JoannesVermorel/.dotnet11'
$env:DOTNET_HOST_PATH=$env:DOTNET_ROOT+'/dotnet.exe'
$env:PATH=$env:DOTNET_ROOT+';'+$env:PATH
$notes='D:/code/Lython/.git/agent-notes/review-20261031/native-format-refined-b253'
$filter='Category!=Stress&(FullyQualifiedName~Format|FullyQualifiedName~StringBuilderAdmission|FullyQualifiedName~GovernedOutputCompletion|FullyQualifiedName~NativeReturn|FullyQualifiedName~SimpleFunctionExecutionBoundary|FullyQualifiedName~Cancellation|FullyQualifiedName~GovernedMemoryContract|FullyQualifiedName~ExecutableCallLifetime)'
foreach($framework in 'net11.0','net10.0') {
    foreach($project in 'Lokad.Lython.Tests','Lokad.Lython.PublicApi.Tests') {
        $logPath=Join-Path $notes ($project+'-'+$framework+'.log')
        dotnet test ('tests/'+$project) -c Release -f $framework --no-build --filter $filter *> $logPath
        $testExit=$LASTEXITCODE
        Get-Content -LiteralPath $logPath -Tail 35
        if($testExit -ne 0){exit $testExit}
    }
}
