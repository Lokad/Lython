from pathlib import Path
import hashlib, json, os, shutil, subprocess, tarfile
r = Path(__file__).parent
old = r.parent / 'cased-pipeline-r300'
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
expected = json.loads((old / 'reference-identity.json').read_text(encoding='utf-8'))['sources']
assert all(sha(p) == h for p, h in expected.items())
assert 'Failed:     3, Passed:     1' in (r / 'regression-internal-net11.0-before.log').read_text(encoding='utf-8')
shutil.copytree(old / 'reference', r / 'reference', copy_function=os.link)
(r / 'reference/Lokad.Lython.dll').unlink()
shutil.copyfile('src/Lokad.Lython/bin/Release/net11.0/Lokad.Lython.dll', r / 'reference/Lokad.Lython.dll')
for name in ['catalog.json']: shutil.copyfile(old / name, r / name)
shutil.copytree(old / 'tool', r / 'tool', copy_function=os.link)
identity = dict(head=subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip(), runtimeSourceCommit='d413392c', sources=expected, coreSHA256=sha(r / 'reference/Lokad.Lython.dll'))
(r / 'reference-identity.json').write_text(json.dumps(identity, indent=2) + '\n', encoding='utf-8')
shutil.copyfile('src/Lokad.Lython/Runtime/MemoryGovernor.cs', r / 'MemoryGovernor.cs.before')
with tarfile.open(r / 'reference-sources.tar.xz', 'w:xz') as archive:
 for name in expected: archive.add(name, arcname=name)
print('Source-matched baseline frozen before production change:', identity['coreSHA256'], flush=True)
