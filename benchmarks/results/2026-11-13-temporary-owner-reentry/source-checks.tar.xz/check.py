from pathlib import Path
import os, subprocess, sys
r = Path(__file__).parent
sdk = Path('C:/Users/JoannesVermorel/.dotnet11')
env = os.environ.copy(); env['DOTNET_ROOT'] = str(sdk); env['PATH'] = str(sdk) + ';C:/Python313;' + env['PATH']
phase, label = sys.argv[1:]
if phase == 'build':
 jobs = [('solution', [str(sdk / 'dotnet.exe'), 'build', 'Lokad.Lython.slnx', '-c', 'Release', '--disable-build-servers', '-m:1'])]
elif phase == 'build-internal':
 jobs = [('net11', [str(sdk / 'dotnet.exe'), 'build', 'tests/Lokad.Lython.Tests/Lokad.Lython.Tests.csproj', '-c', 'Release', '-f', 'net11.0', '--disable-build-servers', '-m:1'])]
else:
 names = {'internal': ['TemporaryReservationOwnership', 'RuntimeStorageSubsystem', 'NativeFunctionRefund', 'ByteBuilderOwnershipTransaction', 'CasedSplitOwnership', 'DictionaryCountingLoopAdmission', 'DrainReservation', 'CallExpansion', 'Json', 'StableSort', 'MemoryBudget', 'Admission'],
          'public': ['CallInputLifetime', 'CooperativeCancellation', 'FirstRefusal', 'NativeClosureLifetime', 'HelperContinuationLifetime', 'JsonCallback', 'JsonLifetime', 'ExpandedCall', 'KeywordExpansion', 'Starred', 'SubprocessOwnership', 'RootLifetimeContainment']}
 if phase == 'regression': names = {'internal': ['TemporaryReservationOwnership']}
 jobs = []
 for framework in (['net11.0'] if phase == 'regression' else ['net11.0', 'net10.0']):
  for suite, selected in names.items():
   project = 'Lokad.Lython.Tests' if suite == 'internal' else 'Lokad.Lython.PublicApi.Tests'
   filt = 'Category!=Stress&(' + '|'.join('FullyQualifiedName~' + name for name in selected) + ')'
   jobs.append((suite + '-' + framework, [str(sdk / 'dotnet.exe'), 'test', f'tests/{project}/{project}.csproj', '-c', 'Release', '-f', framework, '--no-build', '--disable-build-servers', '--filter', filt]))
for name, args in jobs:
 p = r / f'{phase}-{name}-{label}.log'; assert not p.exists()
 with p.open('w', encoding='utf-8', newline='\n') as log: done = subprocess.run(args, env=env, stdout=log, stderr=subprocess.STDOUT)
 text = p.read_text(encoding='utf-8'); print(p.name, 'exit', done.returncode, text[-15000:], flush=True)
 if done.returncode or 'No test matches' in text: sys.exit(done.returncode or 1)
