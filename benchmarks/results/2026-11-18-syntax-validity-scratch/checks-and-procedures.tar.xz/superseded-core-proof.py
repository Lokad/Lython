from pathlib import Path
import fcntl, hashlib, json, os, shutil, stat, subprocess
root = Path('/home/lokad/lython-bench-checks').resolve()
with (root/'comparison-vm.lock').open('a') as lock:
    fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
    assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record|[p]ython3.*cpython-worker.py'],capture_output=True).returncode==1
    assert not any(os.path.ismount(p) for p in root.glob('*/guest-fixtures'))
    anchor=root/'branch-state-b976-20261118/candidate/Lokad.Lython.dll'
    assert anchor.is_file()
    info=anchor.lstat(); assert stat.S_ISREG(info.st_mode) and anchor.resolve()==anchor and info.st_uid==os.getuid()
    expected='4eb89711818f3d4732bc81f29e31608ef77dac28f061170bec94c4ec8b1e90eb'
    assert hashlib.sha256(anchor.read_bytes()).hexdigest()==expected
    paths=[]
    for parent,_,names in os.walk(root):
        for name in names:
            p=Path(parent)/name
            value=p.lstat()
            if (value.st_dev,value.st_ino)!=(info.st_dev,info.st_ino): continue
            assert p.resolve()==p and value.st_uid==os.getuid() and value.st_nlink==info.st_nlink and name==anchor.name
            paths.append(p.relative_to(root).as_posix())
    assert len(paths)==info.st_nlink and all(p.split('/')[0] in {'branch-state-b976-20261118','csv-line-number-b977-20261118'} for p in paths), paths
    print(json.dumps(dict(paths=sorted(paths),bytes=info.st_size,sha256=expected,links=info.st_nlink,free=shutil.disk_usage(root).free)))
