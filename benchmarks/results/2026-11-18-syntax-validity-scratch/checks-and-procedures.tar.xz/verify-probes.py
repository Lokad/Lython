from pathlib import Path
import json, os, subprocess

root=Path.cwd(); lab=root/'.git/agent-notes/review-20261031/syntax-validity-r559'
work=root/'.git/agent-worktrees'
sdk=Path.home()/'.dotnet11'; env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk),PATH=str(sdk)+os.pathsep+os.environ['PATH'])
examples=[
'def f(a,a): pass',
'def f(a,b): return a+b\nprint(f(a=2,b=3),f(a=4,b=5))',
'def f(a,b): return a+b\nprint(f(a=2,a=3),f(b=1,b=2))',
'function = lambda a,a: a',
'class C(metaclass=type, metaclass=type): pass',
'while True:\n def f():\n  break\n break',
'while False:\n pass\nelse:\n continue',
'y = [item for item in (seq:=[1, 2])]',
'xs = [(x:=x+1) for x in range(4)]',
'def f():\n x = 1\n global x',
'def f():\n nonlocal missing',
'def f(x):\n global x',
'def f():\n global x\n nonlocal x',
'if False:\n class C:\n  nonlocal x',
'def outer():\n v=1\n def inner():\n  nonlocal v\n  v+=2\n inner()\n return v\nprint(outer())',
'def outer():\n a=1\n if True:\n  class C:\n   nonlocal a\n   a=7\n return a\nprint(outer())',
'import re\nprint(re.compile("(?i)(a)").search("A").span(1))',
'match (1,2):\n case (x,x):\n  print(x)',
]
input_data=json.dumps(examples,ensure_ascii=False); (lab/'probe-input.json').write_text(input_data,encoding='utf-8')
for target in ('net11.0','net10.0'):
    rows=[]
    for role,checkout in (('reference','split-line-count-r557'),('candidate','syntax-validity-r559')):
        dll=work/checkout/'tools/LythonProbe/bin/Release'/target/'LythonProbe.dll'
        result=subprocess.run([sdk/'dotnet.exe',dll,'--batch-json'],input=input_data,text=True,encoding='utf-8',capture_output=True,env=env,timeout=60)
        (lab/f'{role}-probes-{target}.jsonl').write_text(result.stdout,encoding='utf-8')
        parsed=[json.loads(line) for line in result.stdout.splitlines()]
        assert result.returncode==1 and len(parsed)==len(examples),(result.stderr,len(parsed))
        rows.append(parsed)
    assert rows[0]==rows[1], [(i,a,b) for i,(a,b) in enumerate(zip(*rows)) if a!=b][:2]
    print(target,len(examples),'identical public results and diagnostic ordering')
