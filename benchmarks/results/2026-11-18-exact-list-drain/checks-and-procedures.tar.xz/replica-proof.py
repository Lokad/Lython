from pathlib import Path
import fcntl, hashlib, json, os, shutil, stat, subprocess
root=Path('/home/lokad/lython-bench-checks').resolve()
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
with (root/'comparison-vm.lock').open('a') as lease:
    fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
    assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record|[p]ython3.*cpython-worker.py'],capture_output=True).returncode==1
    assert not any(os.path.ismount(p) for p in root.glob('*/guest-fixtures'))
    anchor=root/'csv-line-number-b977-20261118/candidate/Lokad.Lython.dll'
    m=anchor.lstat(); assert sha(anchor)=='12643cec6271243e694c9d919f28d06c2e84560242fa2fb880fc6f327d636234'
    paths=[]
    for parent,_,names in os.walk(root):
        for n in names:
            p=Path(parent)/n; v=p.lstat()
            if (v.st_dev,v.st_ino)!=(m.st_dev,m.st_ino): continue
            assert p.resolve()==p and p.is_relative_to(root) and p.name==anchor.name and stat.S_ISREG(v.st_mode)
            assert v.st_uid==os.getuid() and v.st_size==m.st_size and v.st_nlink==m.st_nlink and sha(p)=='12643cec6271243e694c9d919f28d06c2e84560242fa2fb880fc6f327d636234'
            paths.append(p.relative_to(root).as_posix())
    assert len(paths)==m.st_nlink
    obs={'canonical': 'benchmarks/results/2026-11-18-line-count-cpython-checkpoint/observations.tgz', 'canonicalSHA256': 'd2b5bc001532fcde2a5005d5cd5a33234bd52aaa5ebcdfb6109cd746be818630', 'member': 'confirmation/confirmation.json', 'links': 1, 'bytes': 364121, 'sha256': '7a35f747531b7054e60a36b97405a23a888c68082ed881651e534079fcc0c682', 'paths': ['line-count-cpython-b984-20261118/confirmation/confirmation.json'], 'kind': 'exact committed raw observation replica', 'committedBlobVerified': True, 'optional': True}; p=root/obs['paths'][0]; recorded=None
    if p.exists():
        v=p.lstat(); assert p.resolve()==p and p.is_relative_to(root) and stat.S_ISREG(v.st_mode)
        assert v.st_uid==os.getuid() and v.st_nlink==1 and v.st_size==obs['bytes'] and sha(p)==obs['sha256']
        recorded=obs
    print(json.dumps(dict(freeBytes=shutil.disk_usage(root).free,core=dict(paths=sorted(paths),sha256='12643cec6271243e694c9d919f28d06c2e84560242fa2fb880fc6f327d636234',bytes=m.st_size,links=m.st_nlink),observation=recorded)))
