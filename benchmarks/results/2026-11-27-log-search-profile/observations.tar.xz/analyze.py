from collections import Counter
from pathlib import Path
import json


ROOT = Path(__file__).resolve().parent
WAIT = ('WaitSubsystem+ThreadWaitInfo.Wait', 'LowLevelThreadBlocker.TimedWait', 'PollGCWorker',
        'SynchronousWorkItem.Wait')
REGIONS = {
    'single matching': ('RegexMatcher.Match', 'RegexCompiler.TryMatch', 'Utf8RegexProvider+Pattern.TryMatch',
                        'Utf8PythonRegex.Match'),
    'module pattern resolution': ('RegexCompiler.ResolvePattern', 'RegexCompiler.ResolvePreparedPattern', 'RegexPatternCache.Find'),
    'argument binding': ('CallBinder.Bind',),
    'subject window': ('RegexMatcher.Window', 'RegexCompiler.CreateWindow', 'RegexCompiler.CreateSubjectRange'),
    'range validation': ('RegexMatcher.ValidateMatch', 'RegexCompiler.MatchResultError'),
    'retained match construction': ('RegexMatcher.CreateMatchObject', 'RegexMatcher.ProjectScalarBounds', 'ReMatchObject.CreateAdmitted'),
    'group access': ('GroupCoreAsync', 'GetSubscriptCoreAsync', 'MaterializeRegexRange'),
    'file transport': ('TextFileHandle', 'ChunkedTextFileReadState'),
}


def layer(frame):
    if frame.startswith('Lokad.Lython.Utf8Regex.'):
        return 'adapter'
    if frame.startswith('Lokad.Utf8Regex.'):
        return 'producer'
    if frame.startswith(('Lokad.Lython.Runtime.', 'Lokad.Lython.LythonMemoryBudget')):
        return 'core'
    return None


def analyze(role):
    capture = json.loads((ROOT / role / 'run.speedscope.json').read_bytes())
    names = [frame['name'].split('(', 1)[0].split('!', 1)[-1] for frame in capture['shared']['frames']]
    layers = Counter()
    inclusive = Counter()
    nearest = Counter()
    leaves = Counter()
    runner = 0.0
    for profile in capture['profiles']:
        assert profile['type'] == 'evented' and profile['unit'] == 'milliseconds'
        stack = []
        previous = profile['startValue']
        for event in profile['events']:
            elapsed = event['at'] - previous
            if elapsed > 0:
                active = [frame for frame in stack if layer(frame)]
                if active and not any(mark in frame for frame in stack for mark in WAIT):
                    runner += elapsed
                    method = active[-1]
                    layers[layer(method)] += elapsed
                    nearest[method] += elapsed
                    leaves[stack[-1]] += elapsed
                    for name, parts in REGIONS.items():
                        if any(part in frame for part in parts for frame in active):
                            inclusive[name] += elapsed
            if event['type'] == 'O':
                stack.append(names[event['frame']])
            else:
                assert stack.pop() == names[event['frame']]
            previous = event['at']
        assert not stack
    assert runner > 0 and len(layers) == 3
    return dict(role=role, resolvedRuntimeThreadMilliseconds=runner,
                nearestLayerMilliseconds=layers, inclusiveRegionMilliseconds=inclusive,
                nearestRuntimeMethods=nearest.most_common(40), leaves=leaves.most_common(40))


identity = json.loads((ROOT / 'identity.json').read_bytes())
rows = [analyze(profile[0]) for profile in identity['profiles']]
(ROOT / 'attribution.json').write_text(json.dumps(rows, indent=2) + '\n', encoding='utf-8', newline='\n')
for row in rows:
    denominator = row['resolvedRuntimeThreadMilliseconds']
    print(row['role'], round(denominator))
    for key in ('nearestLayerMilliseconds', 'inclusiveRegionMilliseconds', 'nearestRuntimeMethods'):
        values = row[key]
        for name, duration in values.items() if isinstance(values, dict) else values[:8]:
            print(f'  {duration * 100 / denominator:5.1f}% {name}')
