from pathlib import Path
import json,subprocess,sys
body="\nclass C:\n def attribute(self):\n  del self\n  return super().__self__\ntry:C().attribute()\nexcept Exception as e:print(type(e).__name__,str(e))\n"
rows=[]
for declaration in ['class Holder[T:super]:pass','class Holder[T=super]:pass','def holder[T:super]():pass','def holder[T=super]():pass','type Alias[T:super]=int']:
    source=declaration+body
    done=subprocess.run([sys.executable,'-I','-c',source],text=True,encoding='utf-8',capture_output=True,timeout=10)
    assert done.returncode==0 and not done.stderr,(declaration,done)
    assert done.stdout=="UnboundLocalError cannot access local variable 'self' where it is not associated with a value\n"
    rows.append(dict(source=source,stdout=done.stdout,python=sys.version))
Path(__file__).with_name('lazy-super-goldens.json').write_text(json.dumps(rows,indent=2),encoding='utf-8')
print('Five independent lazy type-bound/default/module-super goldens pass.')
