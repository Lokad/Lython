import json, subprocess, sys
from pathlib import Path

cases = [
    "def make():\n value=1\n class Holder:\n  read=lambda self:value\n def set_value(new):\n  nonlocal value\n  value=new\n def delete_value():\n  nonlocal value\n  del value\n return Holder(),set_value,delete_value\nh,set_value,delete_value=make()\nprint(h.read())\nset_value(7)\nprint(h.read())\ndelete_value()\ntry:h.read()\nexcept NameError:print('deleted')",
    "value=9\nclass Holder:\n value=2\n read=lambda self,initial=value:(initial,value)\nprint(Holder().read())",
    "value=9\ndef make():\n global value\n class Holder:\n  value=2\n  read=lambda self:value\n return Holder()\nh=make()\nvalue=7\nprint(h.read())",
    "def f(first=lambda:1,last=lambda:2):return first(),last()\nprint(f())\nclass Holder:\n first=lambda self:1\n last=lambda self:2\nprint(Holder().first(),Holder().last())",
    "class Base:\n def read(self):return 3\nclass Child(Base):\n read=lambda self:(yield super().read())\ng=Child().read()\nprint(next(g))\ntry:g.send(7)\nexcept StopIteration as done:print(done.value)",
    "type Alias[T]=((lambda initial=T:lambda:initial)(),(lambda:global_value)())\nglobal_value=9\nfirst,second=Alias.__value__\nprint(first().__name__,second)",
    "value='global'\nclass Holder:\n value='class'\n type Alias=((lambda:value)(),list((lambda:(yield value))()))\nprint(Holder.Alias.__value__)",
    "class Holder[T:(lambda:int)(),U=(lambda:str)()]:pass\nprint(Holder.__type_params__[0].__bound__.__name__,Holder.__type_params__[1].__default__.__name__)",
    "def f[T:(lambda:int)(),U=(lambda:str)()](value):return value\nprint(f.__type_params__[0].__bound__.__name__,f.__type_params__[1].__default__.__name__,f(7))",
]
records = []
for source in cases:
    p = subprocess.run([sys.executable, '-I', '-c', source], capture_output=True, text=True, timeout=10)
    if p.returncode: raise RuntimeError(p.stderr)
    records.append({'source':source,'stdout':p.stdout,'python':sys.version})
Path(__file__).with_name('python-goldens.json').write_text(json.dumps(records, indent=2), encoding='utf-8')
for item in records: print(repr(item['stdout']))
