from pathlib import Path
import hashlib,json,shutil,subprocess,tarfile

r=Path(__file__).parent
v=r/'b502'
out=Path('benchmarks/results/2026-11-09-callable-consolidation')
assert out.exists()
identity=json.loads((r/'identity.json').read_text(encoding='utf-8'))
assert all(hashlib.sha256(Path(name).read_bytes()).hexdigest()==digest for name,digest in identity['productionSources'].items())
proof=dict(productionSourceMatchesMeasuredFreeze=True,measuredCoreSHA256=identity['candidateCoreSHA256'],
           baseline=identity['baseline'],actualFrameworks=['net11.0','net10.0'],focusedPerFramework=dict(internal=357,public=1722,additionalCompilerLambda=46),
           independentPythonGoldens=9,postMeasurementChanges='Two additional independently checked class/function type-parameter bound/default tests; documentation only. No production source changes.',
           removed='PyFunction; UseSynchronousLoweredFunctionDispatch; duplicate177-line dispatcher; runtime lambda lowering/compilation; unused retained lambda Body/FunctionBody and eager generator-lambda code; nullable lowered-function backend selection.',
           preserved='Existing executable capture decisions; incomplete namespace bridges; lower evaluators for real consumers; Python scopes/defaults/class cells/generators; current cancellation and terminal first refusal; admitted cells/workspace/caches; escaping aliases and awaited pending cleanup.',
           limitations='Compile allocation plus3.18to5.24percent accepted; report control plus0.05to1.12percent elapsed and zeroTo4.44percent coarseCPU uncertain. Earlier R142 report debt unresolved. No startup/pending-I/O/CPython timing from this source pair.',
           delivery='Focused actual11/10 pass; full Windows/Ubuntu actual11/10, original Stress and installed-package qualification next. Publication postponed.')
(r/'delivery-source.json').write_text(json.dumps(proof,indent=2),encoding='utf-8')
(r/'final-source.patch').write_bytes(subprocess.check_output(['git','diff','--binary','--','src/Lokad.Lython','tests']))
for target,source in [('observations.tgz',v/'observations.tgz'),('summary.json',v/'assessment.json'),('terminal.json',v/'terminal-status.json'),
                      ('identity.json',r/'identity.json'),('local-summary.json',r/'assessment-local.json'),('delivery-source.json',r/'delivery-source.json'),
                      ('python-goldens.json',r/'python-goldens.json'),('script-goldens.json',r/'script-goldens.json')]:
    assert not (out/target).exists()
    shutil.copyfile(source,out/target)
with tarfile.open(out/'preparation.tar.xz','w:xz') as archive:
    for p in r.iterdir():
        if p.is_file():archive.add(p,arcname=p.name)
    for name in ['warm-sync','warm-async','compile-sync']:archive.add(r/name,arcname=name)
    for p in v.iterdir():
        if p.is_file() and p.name not in ['payload.tgz','observations.tgz','baseline-core.dll','current-core.dll','common-worker.dll','common-adapter.dll']:
            archive.add(p,arcname='b502/'+p.name)
    for name in ['LambdaExecutionTests.cs']:
        archive.add(Path('tests/Lokad.Lython.PublicApi.Tests')/name,arcname=name)
    archive.add('tests/Lokad.Lython.Tests/ExecutableFunctionInvocationBoundaryTests.cs',arcname='ExecutableFunctionInvocationBoundaryTests.cs')
with tarfile.open(out/'preparation.tar.xz') as archive:
    assert all(name in archive.getnames() for name in ['final-source.patch','public-net11.0.log','public-net11.0-lazy.log','final-public-net10.0.log','compiler-lambda-net10.0.log'])
print('Source equals measured freeze; original failures, all timing/control evidence and focused actual11/10 checks archived.')
