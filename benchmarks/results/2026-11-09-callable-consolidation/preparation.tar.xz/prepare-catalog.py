from pathlib import Path
import base64, copy, hashlib, json, subprocess, tempfile

r = Path(__file__).parent
catalog = json.loads((r.parent/'lexical-operands-r139/catalog.json').read_text(encoding='utf-8'))
selected = {item['id'].split('.')[1]:copy.deepcopy(item) for item in catalog['cases']}
sources = {name:Path('benchmarks/scripts',name+'.py').read_text(encoding='utf-8')
           for name in ['csv-validated-records','text-summary-helpers','json-summary-helpers','report-render','file-search']}
csv = sources['csv-validated-records'].replace('def validated_record',
    "class RecordFields:\n    amount = staticmethod(lambda record: int(record['amount']))\n\n\ndef validated_record",1)
csv = csv.replace("amount = int(record['amount'])", "amount = RecordFields.amount(record)",1)
text = sources['text-summary-helpers'].replace('def words_from_line(line:str)->list:\n    return line.lower().split()',
    'class Words:\n    from_line = lambda self,line:line.lower().split()\n\nwords_from_line = Words().from_line',1)
js = sources['json-summary-helpers'].replace("def record_amount(record:dict)->int:\n    return record['amount']",
    "class RecordFields:\n    amount = staticmethod(lambda record: record['amount'])\n\nrecord_amount = RecordFields.amount",1)
catalog['cases'] = []
proof = []
for name, body in [('csv-validated-records',csv),('text-summary-helpers',text),('json-summary-helpers',js),
                   ('report-render',sources['report-render']),('file-search',sources['file-search'])]:
    item = selected[name]
    item['source'] = body
    item['id'] = 'scripts.'+name+('.class-callable' if name not in ['report-render','file-search'] else '.control')+'.large'
    item['sourceUtf8Bytes'] = len(body.encode())
    item['sourceSha256'] = hashlib.sha256(body.encode()).hexdigest()
    fixture = json.loads(item['fixtureJson'])
    with tempfile.TemporaryDirectory(prefix='lython-r145-golden-') as folder:
        folder = Path(folder)
        for path, encoded in fixture['inputFiles'].items():
            dest = folder/path
            dest.parent.mkdir(parents=True,exist_ok=True)
            dest.write_bytes(base64.b64decode(encoded,validate=True))
        done = subprocess.run(['C:/Python313/python.exe','-I','-S','-X','utf8','-c',body], cwd=folder,
                              encoding='utf-8',capture_output=True,timeout=15)
        assert done.returncode == 0 and done.stdout == item['expectedOutput'] and not done.stderr, (item['id'],done)
        for path,encoded in fixture['outputFiles'].items():
            assert (folder/path).read_bytes() == base64.b64decode(encoded,validate=True),(item['id'],path)
        proof.append(dict(case=item['id'],source=body,sourceSHA256=item['sourceSha256'],stdout=done.stdout,
                          allOutputFilesEqual=True,fixtureSHA256=item['fixtureSha256']))
    catalog['cases'].append(item)
assert all(candidate != sources[name] for name,candidate in [('csv-validated-records',csv),('text-summary-helpers',text),('json-summary-helpers',js)])
(r/'catalog.json').write_text(json.dumps(catalog,ensure_ascii=False,indent=2),encoding='utf-8')
(r/'script-goldens.json').write_text(json.dumps(proof,ensure_ascii=False,indent=2),encoding='utf-8')
print('Three complete CSV/text/JSON class-callable scripts and two unchanged controls: independent CPython stdout/file goldens pass.')
