from pathlib import Path
import hashlib, json, shutil, subprocess, tarfile

r = Path(__file__).parent
v = r/'b502'
v.mkdir()
old = r.parent/'generator-storage-r142/b500'
old_root = '/home/lokad/lython-bench-checks/generator-storage-b500-20261109'
remote = '/home/lokad/lython-bench-checks/callable-consolidation-b502-20261109'
for name in ['collect.py','archive-owned.py','run.sh','launch.py','retrieve.py']:
    data = (old/name).read_text(encoding='utf-8').replace(old_root,remote)
    data = data.replace('generator-storage-b500-20261109','callable-consolidation-b502-20261109')
    data = data.replace('lython-b500-generator-storage-20261109','lython-b502-callable-consolidation-20261109')
    data = data.replace('generator-storage-b500-launch.py','callable-consolidation-b502-launch.py')
    data = data.replace('len(jobs)==4','len(jobs)==5').replace("len(r['jobs'])==4","len(r['jobs'])==5")
    data = data.replace("['receipt']['jobs']==4","['receipt']['jobs']==5").replace('jobs=4,','jobs=5,')
    data = data.replace('allFourJobsValidated','allFiveJobsValidated').replace('Four-job raw','Five-job raw')
    data = data.replace(' < 150,',' < 180,').replace("['elapsedSeconds']<150","['elapsedSeconds']<180")
    data = data.replace('ownerSeconds=180','ownerSeconds=210').replace('RuntimeMaxSec=180','RuntimeMaxSec=210')
    data = data.replace('seconds=240','seconds=270')
    data = data.replace('lython-b480-fixtures','lython-b502-fixtures')
    if name == 'collect.py':
        start = data.index('jobs=[')
        end = data.index('\nenv =',start)
        jobs = [[c['id'],'warm'] for c in json.loads((r/'catalog.json').read_text(encoding='utf-8'))['cases']]
        assert len(jobs) == 5
        data = data[:start]+'jobs='+repr(jobs)+'\nassert len(jobs)==5 and all(case in cases for case,lane in jobs)\n'+data[end:]
        start = data.index("purpose='R142")
        end = data.index('\n                  warmupSeconds=',start)
        data = data[:start]+"purpose='R145 one callable engine: compile namespace-backed lambdas once with existing lexical semantics; remove PyFunction, runtime lambda lowering and duplicate sync dispatch. Complete CSV/text/JSON class-callable scripts; unchanged report/search controls. Desktop elapsed adversity and controls retained. Allocation, phase deletion and CPU claims separate.',"+data[end:]
    compile(data,name,'exec') if name.endswith('.py') else None
    (v/name).write_text(data,encoding='utf-8',newline='\n')

for target,source in [('representative.json',r/'catalog.json'),('baseline-core.dll',r/'images/before/Lokad.Lython.dll'),
                      ('current-core.dll',r/'images/candidate/Lokad.Lython.dll'),('baseline-source.json',r/'baseline.json'),
                      ('contract.md',r/'pre-edit-plan.md'),('source.patch',r/'source.patch')]:
    shutil.copyfile(source,v/target)
for target,name in [('common-worker.dll','Lokad.Lython.Benchmarks.dll'),('common-adapter.dll','Lokad.Lython.Utf8Regex.dll'),
                    ('common-worker.deps.json','Lokad.Lython.Benchmarks.deps.json'),('common-worker.runtimeconfig.json','Lokad.Lython.Benchmarks.runtimeconfig.json')]:
    shutil.copyfile(r/'images/before'/name,v/target)
identity = dict(sourceRevision='Committed081052fa versus working R145; freshly built candidate; shared frozen worker/adapter',
                coreSHA256={role:hashlib.sha256((v/name).read_bytes()).hexdigest()
                            for role,name in [('reference','baseline-core.dll'),('reference-control','baseline-core.dll'),
                                              ('candidate','current-core.dll'),('candidate-control','current-core.dll')]},
                auxiliaryFiles={p.name:hashlib.sha256(p.read_bytes()).hexdigest()
                                for p in (r/'images/before').glob('*.dll') if p.name != 'Lokad.Lython.dll'},
                catalogSHA256=hashlib.sha256((v/'representative.json').read_bytes()).hexdigest())
(v/'identity.json').write_text(json.dumps(identity,indent=2),encoding='utf-8')
(v/'focused.json').write_text(json.dumps(dict(actualFrameworks=['net11.0','net10.0'],internalPerFramework=357,
                                             publicPerFramework=1722,independentPythonGoldens=7,allScriptGoldensIndependent=True),indent=2),encoding='utf-8')
(v/'sizing.json').write_text(json.dumps(dict(jobs=5,warmupPerRoleSeconds=5,rounds=7,targetBatchSeconds=.15,
                                           expectedSeconds=155,ownerSeconds=210),indent=2),encoding='utf-8')
(v/'setup-contract.json').write_text(json.dumps(dict(ownerSeconds=210,stopSeconds=30,marginSeconds=30,
                                                   osFreeFloorMiB=240,evidenceHeadroomMiB=12,jobs=5,unchangedWorkerAndProtocol=True),indent=2),encoding='utf-8')
(v/'pre-measurement-plan.md').write_text('''# R145 bounded confirmation

Five source-pair jobs, four independent roles: complete class-callable CSV/text/JSON
and unchanged report/search controls. Same source/input/golden per pair, ordinary
GC/tiering, five-second warmups and seven rotated 150ms rounds. Included warm clock:
mediated RAM-file I/O, full output checks and prior-result cleanup. Compilation,
startup/reset/protocol and final teardown excluded; wider process CPU separate.
Desktop controls/elapsed drift and any compilation increase remain original evidence.
Allocation reduction and duplicate backend deletion do not prove CPU speedup. Decide
remaining regression debt explicitly. This is a bounded confirmation, not a ban on
evidence-justified refinement. No full lanes or producer qualification replay.
Owner210s/stop30s/margin30s; expected155s; all users joined, RAM removed, evidence
archived and verified under lease and local SHA. Preserve floor/headroom and failures.
''',encoding='utf-8')
with tarfile.open(v/'payload.tgz','w:gz') as t:
    for p in v.iterdir():
        if p.name != 'payload.tgz':t.add(p,arcname=p.name)
print('Five jobs; payload bytes',(v/'payload.tgz').stat().st_size,'expected155s/owner210s +30stop+30margin')
