# R145 bounded confirmation

Five source-pair jobs, four independent roles: complete class-callable CSV/text/JSON
and unchanged report/search controls. Same source/input/golden per pair, ordinary
GC/tiering, five-second warmups and seven rotated 150ms rounds. Included warm clock:
mediated RAM-file I/O, full output checks and prior-result cleanup. Compilation,
startup/reset/protocol and final teardown excluded; wider process CPU separate.
Desktop controls/elapsed drift and any compilation increase remain original evidence.
Allocation reduction and duplicate backend deletion do not prove CPU speedup. Decide
remaining regression debt explicitly. This is a bounded confirmation, not a ban on
evidence-justified refinement. No full lanes or producer qualification replay.
Owner210s/stop30s/margin30s; expected155s; all users joined, RAM removed, evidence
archived and verified under lease and local SHA. Preserve floor/headroom and failures.
