# R145 callable compilation consolidation

R144 source gate: entry guards deliberately precede all admission/effects; execution
must reread live data after admission. A second guard VM, per-call cache or affix-only
shortcut would not remove that semantic requirement. Keep the measured target open;
do not infer removable cost from R143 sample shares or spend another capture here.

Selected coherent deletion: class-suite and other lowered-expression lambdas still
construct PyFunction, retaining a second function body engine and a synchronous-
dispatch flag/dispatcher. All normal functions already use executable code. Reuse
the existing lexical preparation walk to attach lambda closure candidates and known
parent completeness, respecting closest function/global bindings, comprehension
targets, opaque class barriers and type-parameter shadowing. Compile each lambda once
during lowering and reuse it in executable and real lowered consumers. No extra syntax
walk, runtime compilation/cache, new binder/frame framework or public option.

Delete PyFunction, its sync dispatch mode and orphaned synchronous dispatcher;
preserve lowered expression/statement helpers with actual class/annotation/opcode
callers. Lowered function definitions require their already-prepared class code.
Move white-box module-definition fixtures to the existing executable entry path;
retain independent binding, cancellation, side-effect, alias and cleanup assertions.
Opaque lexical scopes conservatively retain their namespace; new incoming captures
use the existing retained-cell admission. All code/storage owners survive actual users.

Acceptance: Python lambda defaults/keywords/metadata, live/deleted/transitive captures,
global/nonlocal/class barriers, comprehensions/walrus, type scopes, __class__/super,
generator lambdas/send/throw/close and genuine async protocols. First refusal remains
terminal; cancellation, managed stack, retained aliases and awaited cleanup/budget
reuse survive. No supported syntax is removed to eliminate a route.

Use focused Release regressions, independent CPython goldens and short full CSV/text/
JSON callback-script allocation/compile/warm diagnostics plus unchanged controls.
Use one bounded quiet confirmation only for material observations. Separate design
deletion, allocation and CPU; document any conservative-retention or regression debt.
Complete only when the old backend/mode/dispatch are removed and delivery checks pass.
Publication remains postponed; regex remains independent.

## Implementation refinement

The initial proposed lambda capture-candidate preparation was removed before
qualification: it duplicated the executable builder's actual lexical decisions.
The final prototype collects lambda syntax during the existing lexical walk,
including lazy alias/bound/default expressions. Actual executable sites compile
with their original enclosing builder. Remaining namespace-backed sites compile
after module construction, before execution. No second capture-analysis policy.

Prepared lambda metadata points back to syntax. Exclude that metadata from syntax
structural equality/hash to avoid recursion; preserve real syntax comparisons.
Original stack-overflow test output is retained. Class-cell capture uses the same
FunctionClosureContext as class methods. Seven independently checked Python goldens
and existing class/annotation cases cover the discovered gaps; do not hide failures.
