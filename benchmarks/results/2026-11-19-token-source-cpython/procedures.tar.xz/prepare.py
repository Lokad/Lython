from pathlib import Path
import ast
import hashlib
import json
import os
import shutil
import subprocess
import tarfile

lab = Path(__file__).resolve().parent
prior = lab.parent / 'retained-defaults-cpython-b1102'
donor = lab.parent / 'token-source-transport-r673'
read = lambda path: path.read_text(encoding='utf-8-sig')
load = lambda path: json.loads(read(path))
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
def write(name, data):
    if name.endswith('.py'): ast.parse(data)
    (lab/name).write_text(data,encoding='utf-8',newline='\n')
def save(name, data):
    write(name,json.dumps(data,ensure_ascii=False,indent=2)+'\n')

old = load(donor / 'quiet/config.json')
receipt = load(donor / 'quiet/archive-receipt.json')
pair = load(donor / 'frozen-identity.json')
files = pair['images']['candidate']
assert receipt['complete'] and receipt['archivedAndVerifiedUnderLease'] and receipt['guestFixturesRemoved']
assert files == old['identity']['imageFiles']['candidate'] and len(files)==32
revision = subprocess.check_output(['git','rev-parse','27f68744b'],text=True).strip()
subprocess.run(['git','diff','--exit-code',pair['candidateCommit'],revision,'--','src','tests'],check=True)
save('build-revision.json',dict(sourceRevision=revision,imageSource=pair['candidateCommit'],coreSHA256=files['Lokad.Lython.dll']))
frozen = lab / 'frozen/candidate'
frozen.mkdir(parents=True,exist_ok=True)
for name, expected in files.items():
    source = donor/'frozen/candidate'/name
    assert sha(source) == expected
    shutil.copyfile(source,frozen/name)
assert {name:sha(frozen/name) for name in files}==files
catalog = load(donor/'catalog.json')
selected = {'scripts.config-generated-guards.medium','scripts.config-manifest.small'}
catalog['cases'] = [case for case in catalog['cases'] if case['id'] in selected]
assert {case['id'] for case in catalog['cases']} == selected
save('representative.json', catalog)
worker = lab/'cpython-worker.py'
shutil.copyfile('benchmarks/cpython-worker.py',worker)
assert sha(worker) == load(prior/'identity.json')['cpythonWorkerSHA256']
catalog_hash = sha(lab/'representative.json')
worker_hash = sha(worker)
identity=dict(sourceRevision=revision,imageSource=pair['candidateCommit'],
    purpose='B1106 validator and manifest after token-source preparation against CPython',
    imageFiles={'candidate':files},auxiliaryFiles={k:v for k,v in files.items() if k!='Lokad.Lython.dll'},
    coreSHA256={role:files['Lokad.Lython.dll'] for role in ('candidate','candidate-control')},
    catalogSHA256=catalog_hash,cpythonWorkerSHA256=worker_hash,normalAdapterPin='0.4.0')
save('identity.json',identity)
sdk = Path.home()/'.dotnet11'
dotnet = sdk/'dotnet.exe'
env = dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk),PATH=str(sdk)+os.pathsep+os.environ['PATH'])
with (lab/'verify.log').open('wb') as log:
    subprocess.run([dotnet,frozen/'Lokad.Lython.Benchmarks.dll','--compare','verify','--catalog',
        lab/'representative.json','--dotnet',dotnet,'--python',Path('C:/Python313/python.exe'),
        '--python-worker',worker,'--out',lab/'verify.json'],env=env,stdout=log,stderr=subprocess.STDOUT,timeout=120,check=True)
verified=load(lab/'verify.json')
assert verified['state']=='Completed' and verified['catalogSha256']==catalog_hash
assert {name:sha(frozen/name) for name in files}==files

root='/home/lokad/lython-bench-checks/token-source-cpython-b1106-20261119'
unit='lython-b1106-token-source-cpython-20261119'
previous_root=load(prior/'config.json')['root']
jobs=[(case['id'],False) for case in catalog['cases']]
for name in ('collect.py','archive-owned.py','launch.py','retrieve.py','run.sh'):
    source=read(prior/name).replace(previous_root,root).replace('B1102','B1106')
    if name=='collect.py':
        a=source.index('    for case_id,diagnostic in ')
        b=source.index('\n',a)
        source=source[:a]+f'    for case_id,diagnostic in {jobs!r}:'+source[b:]
        a=source.index('        lanes = ')
        b=source.index('\n',a)
        source=source[:a]+'        lanes = ["compile-run", "compile"]'+source[b:]
        assert 'reversed(lanes)' in source and 'for lane in lanes' in source
    elif name=='archive-owned.py':
        source=source.replace("len(raw['jobs'])==7","len(raw['jobs'])==2").replace('jobs=7,','jobs=2,')
        assert "len(raw['jobs'])==2" in source and 'jobs=2,' in source
    elif name=='retrieve.py':
        source=source.replace("['jobs']==7","['jobs']==2")
        assert "['jobs']==2" in source
    elif name=='launch.py':
        source=source.replace('520','115')
        assert 'timedelta(seconds=115)' in source
    write(name,source)
assert bytes([13]) not in (lab/'run.sh').read_bytes()
names=['representative.json','identity.json','collect.py','archive-owned.py','run.sh','cpython-worker.py']
payload=lab/'payload.tgz'
with tarfile.open(payload,'w:gz') as archive:
    for name in names: archive.add(lab/name,arcname=name)
config=dict(root=root,unit=unit,source=old['root'],sourceRole='candidate',sourceFiles=files,
    sourceCatalogSHA256=old['catalogSHA256'],catalogSHA256=catalog_hash,identity=identity,retireGroups=[],
    donorArchiveSHA256=receipt['archiveSHA256'],payloadBytes=payload.stat().st_size,payloadSHA256=sha(payload),
    unpackedBytes=sum((lab/name).stat().st_size for name in names),cpythonWorkerSHA256=worker_hash)
assert receipt['freeBytesAfterArchive'] > 182452224+config['unpackedBytes']+1835008
save('config.json',config)
launcher=read(prior/'remote-launch.py')
a,b=launcher.index('\nc=')+1,launcher.index('\nb=Path(')
launcher=launcher[:a]+'c='+repr(config)+launcher[b:]
write('remote-launch.py',launcher.replace('lython-b1102-fixtures','lython-b1106-fixtures'))
print('Verified 32 files, two CPython goldens and both compile boundaries.')
