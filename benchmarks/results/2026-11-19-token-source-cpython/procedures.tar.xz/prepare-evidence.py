from pathlib import Path

lab = Path(__file__).resolve().parent
original = (lab.parent/'retained-defaults-cpython-b1102/collect-evidence.py').read_text(encoding='utf-8')
source = original.replace('2026-11-19-retained-defaults-cpython','2026-11-19-token-source-cpython')
source = source.replace('receipt["jobs"] == 7','receipt["jobs"] == 2').replace('len(cases) == 7','len(cases) == 2')
source = source.replace('tuple(lanes) == (("compile-run", "compile") if case["id"] == "scripts.config-generated-guards.medium" else ("warm", "compile-run", "compile"))','tuple(lanes) == ("compile-run", "compile")')
source = source.replace('assert len(rows) == 20','assert len(rows) == 4')
source = source.replace('B1102','B1106').replace('verifiedBatches=400','verifiedBatches=80')
(lab/'collect-evidence.py').write_text(source,encoding='utf-8',newline='\n')
