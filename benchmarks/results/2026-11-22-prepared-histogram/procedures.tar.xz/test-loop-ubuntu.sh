#!/bin/bash
set -euo pipefail
cd /mnt/d/code/Lython/.git/agent-worktrees/prepared-histogram-20261122
export DOTNET_ROOT="$HOME/.dotnet"
export PATH="$DOTNET_ROOT:$PATH"
export DOTNET_HOST_PATH="$DOTNET_ROOT/dotnet"
dir=/mnt/d/code/Lython/.git/agent-notes/review-20261031/prepared-histogram-20261122
filter='Category!=Stress&(FullyQualifiedName~NativeWordBinding|FullyQualifiedName~DictionaryCountingLoop|FullyQualifiedName~CooperativeCancellation)'
dotnet test tests/Lokad.Lython.PublicApi.Tests -c Release -f net10.0 --no-build --filter "$filter" --artifacts-path "$dir/ubuntu" --nologo 2>&1 | tee "$dir/loop-ubuntu.log"
