using Lokad.Lython.Frontend;

namespace Lokad.Lython.Runtime;

internal sealed partial class LythonRuntime
{
    internal sealed partial class ExecutionContext
    {
        private void PublishInstructionResult(in ExecutableInstruction instruction, object value)
            => PublishInstructionResult(ref _execution, this, instruction, value);

        private void PublishInstructionResult(in ExecutableInstruction instruction, ExecutableSlot value)
            => PublishInstructionResult(ref _execution, this, instruction, value);

        private static void PublishInstructionResult(ref ExecutableWorkState execution,
            ExecutionContext? invocation, in ExecutableInstruction instruction, object value)
            => PublishInstructionResult(ref execution, invocation, instruction, ExecutableSlot.FromObject(value));

        private static void PublishInstructionResult(ref ExecutableWorkState execution,
            ExecutionContext? invocation, in ExecutableInstruction instruction, ExecutableSlot value)
        {
            if (!instruction.HasResultConsumer)
            {
                execution.Stack.PublishSlot(instruction.ResultSlot, instruction.LiveExtent, value);
            }
            else CompleteResultConsumer(ref execution, invocation, instruction, value);
        }

        private static void CompleteResultConsumer(ref ExecutableWorkState execution,
            ExecutionContext? invocation, in ExecutableInstruction instruction, ExecutableSlot value)
        {
            // Preserve the original input retirement and its disposal order.
            // Pending cleanup must finish before the consumer becomes visible;
            // the unchanged driver and following consumer already implement that.
            if (instruction.LiveExtent < execution.Stack.LiveExtent) execution.Stack.RetireTo(instruction.LiveExtent);
            if (execution.Stack.HasPendingDisposals)
            {
                execution.Stack.PublishSlot(instruction.ResultSlot, instruction.LiveExtent, value);
                return;
            }

            execution.Stack.ForgetResultInput(instruction.ResultSlot);
            ref readonly var consumer = ref execution.Code.Instructions[execution.InstructionIndex + 1];
            var discard = consumer.OpCode == ExecutableOpCode.PopTop;
            // Discarded calls are neither directly returned nor consumed by
            // iteration, so cannot return private iteration loans. Their guest
            // results need neither publication nor scalar materialization.
            execution.Stack.CheckExecution(consumer.Span);
            if (discard)
            {
                if (value.IsUnassigned) _ = value.Object.RequireNotNull();
                execution.InstructionIndex++;
                return;
            }
            StoreLocalValue(execution.Code, execution.Locals, invocation, consumer.LocalSlot, value, consumer.Span);
            execution.InstructionIndex++;
        }
    }
}
