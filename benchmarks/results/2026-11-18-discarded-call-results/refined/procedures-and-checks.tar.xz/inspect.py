from pathlib import Path
import json,os,subprocess
r=Path(__file__).resolve().parent;prior=r.parent/'activation-source-r504';project=r/'inspect';project.mkdir(exist_ok=True)
(project/'Program.cs').write_bytes((prior/'inspect/Program.cs').read_bytes())
s=(prior/'inspect/inspect.csproj').read_text(encoding='utf-8');a=s.index('<HintPath>');b=s.index('</HintPath>',a);s=s[:a]+'<HintPath>D:/code/Lython/.git/agent-notes/review-20261031/direct-split-r513/frozen/candidate/Lokad.Lython.dll'+s[b:];(project/'inspect.csproj').write_text(s,encoding='utf-8')
d=Path('C:/Users/JoannesVermorel/.dotnet11/dotnet.exe');env=os.environ.copy();env.update(DOTNET_ROOT=str(d.parent),DOTNET_ROOT_X64=str(d.parent));env['PATH']=str(d.parent)+os.pathsep+env['PATH']
with(r/'inspect-build.log').open('w',encoding='utf-8')as log:p=subprocess.run([str(d),'build',str(project/'inspect.csproj'),'-c','Release','--no-incremental'],env=env,stdout=log,stderr=subprocess.STDOUT,timeout=90)
assert p.returncode==0,(r/'inspect-build.log').read_text(encoding='utf-8')
with(r/'inspect.log').open('w',encoding='utf-8')as log:p=subprocess.run([str(d),str(project/'bin/Release/net11.0/Lokad.Lython.WhiteBox.Tests.dll'),str(r.parent/'call-entry-r514/catalog.json'),str(r/'current-ir.json')],env=env,stdout=log,stderr=subprocess.STDOUT,timeout=60)
assert p.returncode==0,(r/'inspect.log').read_text(encoding='utf-8')
v=json.loads((r/'current-ir.json').read_text(encoding='utf-8-sig'));assert v['CoreSha256']=='2ede09fc3c7271eafe2efc992e22d24fce45ed13f20cf133375a8e8020824f26'
for w in v['Workloads']:
 for c in w['Codes']:print(w['Id'],c['Name'],'slots',c['ValueStorageCapacity'],'ops',c['OpcodeCounts'])
