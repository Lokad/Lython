from pathlib import Path
import json,os,subprocess
r=Path(__file__).resolve().parent;work=Path('D:/code/Lython/.git/agent-worktrees/discarded-results-r516')
d=Path('C:/Users/JoannesVermorel/.dotnet11/dotnet.exe');env=os.environ.copy();env.update(DOTNET_ROOT=str(d.parent),DOTNET_ROOT_X64=str(d.parent));env['PATH']=str(d.parent)+os.pathsep+env['PATH']
with(r/'build.log').open('w',encoding='utf-8')as log:p=subprocess.run([str(d),'build','Lokad.Lython.slnx','-c','Release','--no-incremental'],cwd=work,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=240)
assert p.returncode==0,(r/'build.log').read_text(encoding='utf-8');print('Nonincremental Release both-target build passes.',flush=True)
filters={'internal':['LoweringArchitectureSubsystem','ExecutableOperandStack','FunctionBodyTemporaryLifetime','OrdinaryFunctionTransport','NativeTextConstructionRollback','KnownDrainOwnership','DrainCleanupOwnership','CasedSplitOwnership','TemporaryReservationOwnership'], 'public':['NativeReceiverPipeline','HelperLocalLifetime','ClosedBuiltinResult','ProtectedHelperExecution','BufferedGeneratorContinuation','BulkGeneratorConsumption','GovernedMemoryContract','MemoryDenialAttribution','ContainerDisplayPipeline']}
rows=[]
for tfm in ['net11.0','net10.0']:
 for kind,parts in filters.items():
  project='Lokad.Lython.Tests'if kind=='internal'else'Lokad.Lython.PublicApi.Tests'
  filt='('+'|'.join('FullyQualifiedName~'+s for s in parts)+')&Category!=Stress'
  cmd=[str(d),'test',f'tests/{project}/{project}.csproj','-c','Release','-f',tfm,'--no-build','--filter',filt]
  file=r/('focused-'+kind+'-'+tfm+'.log')
  with file.open('w',encoding='utf-8')as log:p=subprocess.run(cmd,cwd=work,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=180)
  rows.append(dict(kind=kind,framework=tfm,command=cmd,exitCode=p.returncode));(r/'checks.json').write_text(json.dumps(rows,indent=2)+'\n',encoding='utf-8')
  output=file.read_text(encoding='utf-8');assert p.returncode==0,output;print(kind,tfm,output.splitlines()[-1],flush=True)
