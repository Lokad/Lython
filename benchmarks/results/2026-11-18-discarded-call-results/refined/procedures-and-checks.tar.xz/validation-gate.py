from pathlib import Path
import base64,copy,hashlib,json,os,subprocess
r=Path(__file__).resolve().parent;repo=Path('D:/code/Lython');out=r/'validation';out.mkdir(exist_ok=True);sha=lambda s:hashlib.sha256(s.encode('utf-8')).hexdigest()
catalog=json.loads((r.parent/'direct-split-r513/catalog.json').read_text(encoding='utf-8'));case=copy.deepcopy(next(c for c in catalog['cases']if c['id']=='scripts.csv-numeric-quality.large'));fixture=json.loads(case['fixtureJson']);raw=base64.b64decode(fixture['inputFiles']['input.csv']);assert raw.endswith(b'\n')and raw.startswith(b'category,quantity,unit_cents,')
# Reuse the maintained numeric CSV data, including Unicode/quoted newlines.
# Add32known malformed records; goldens follow fixed valid/invalid counts, never
# output observed from either measured runtime. No timing or favorable selection.
valid=4*fixture['size'];invalid=32;assert case['expectedOutput']==str(valid)+'\n'
raw+=b'bad,not-an-integer,1250,0,0,invalid\n'*invalid
fixture['size']=valid+invalid
fixture['inputFiles']['input.csv']=base64.b64encode(raw).decode('ascii');fixture['outputFiles']={}
source='''import csv

valid = invalid = 0
with open('input.csv', newline='') as source:
    for row in csv.DictReader(source):
        try:
            int(row['quantity'])
            float(row['unit_cents'])
        except ValueError:
            invalid += 1
        else:
            valid += 1
print(valid, invalid)
'''
case.update(id='scripts.csv-field-validation.large',size=valid+invalid,source=source,fixtureJson=json.dumps(fixture,separators=(',',':')),expectedOutput=f'{valid} {invalid}\n',sourceUtf8Bytes=len(source.encode()),expectedOutputUtf8Bytes=len(f'{valid} {invalid}\n'.encode()),fixtureTextUtf8Bytes=0,fixtureTextCodePoints=0,sourceSha256=sha(source),fixtureSha256=sha(json.dumps(fixture,separators=(',',':'))),expectedOutputSha256=sha(f'{valid} {invalid}\n'),expectedFilesSha256=hashlib.sha256(bytes(4)).hexdigest())
catalog['cases']=[case];(out/'catalog.json').write_text(json.dumps(catalog,indent=2)+'\n',encoding='utf-8')
facts=dict(purpose='Local allocation/semantic gate for actual removed scalar materialization, not a replacement for existing adverse/control cases or a CPU comparison',hypothesis='Complete CSV field validation discards int/float results; generic text helper mostly discards None. Existing slot-to-object PopTop may allocate scalar boxes that prepared consumer removes.',sourceSelection='Derived from maintained numeric CSV fixture;32known invalid records appended. Fixed golden4096valid/32invalid from generator counts, not observed guest output.',boundary='Both actual frozen32-file images through existing comparison verify/CPython goldens and existing allocation/reuse harness. No new benchmark framework or runtime policy.',includedIOAndEffects='Complete input file read/CSV parse/validation/error counts/stdout; current tokens, exception order, shared admission and cleanup unchanged.',performanceMeasured=False)
(out/'source-facts.json').write_text(json.dumps(facts,indent=2)+'\n',encoding='utf-8')
d=Path('C:/Users/JoannesVermorel/.dotnet11/dotnet.exe');env=os.environ.copy();env.update(DOTNET_ROOT=str(d.parent),DOTNET_ROOT_X64=str(d.parent));env['PATH']=str(d.parent)+os.pathsep+env['PATH']
identity=json.loads((r/'frozen/identity.json').read_text(encoding='utf-8'))
for role in ['reference','candidate']:
 image=r/'frozen'/role;assert all(hashlib.sha256((image/n).read_bytes()).hexdigest()==h for n,h in identity['imageFiles'][role].items())
 for kind,cmd in [('preflight',[str(d),str(image/'Lokad.Lython.Benchmarks.dll'),'--compare','verify','--catalog',str(out/'catalog.json'),'--dotnet',str(d),'--python','C:/Python313/python.exe','--python-worker',str(repo/'benchmarks/cpython-worker.py'),'--out',str(out/(role+'-preflight.json'))]),('allocation',[str(d),str(image/'ValidatedAllocation.dll'),str(image),str(out/'catalog.json'),str(out/(role+'-allocation.json'))])]:
  with(out/(role+'-'+kind+'.log')).open('w',encoding='utf-8')as log:p=subprocess.run(cmd,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=90)
  assert p.returncode==0,(out/(role+'-'+kind+'.log')).read_text(encoding='utf-8');print('validation',role,kind,'passes',flush=True)
import statistics
a=json.loads((out/'reference-allocation.json').read_text(encoding='utf-8'))['rows'][0];b=json.loads((out/'candidate-allocation.json').read_text(encoding='utf-8'))['rows'][0];before=statistics.median(a['allocatedBytesPerInvocation']);after=statistics.median(b['allocatedBytesPerInvocation']);assert a['sharedBudgetBaselineRestored']and b['sharedBudgetBaselineRestored']
summary=dict(referenceBytes=before,candidateBytes=after,changePercent=100*(after/before-1),referencePeak=a['peakExecutionMemoryBytes'],candidatePeak=b['peakExecutionMemoryBytes'],goldensAndSharedBudgetReuse=True,CPUClaim=False,inputBytes=len(raw),records=valid+invalid)
(out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8');print(json.dumps(summary))
