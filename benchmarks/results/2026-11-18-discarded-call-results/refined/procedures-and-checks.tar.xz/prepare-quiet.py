from pathlib import Path
import ast,hashlib,io,json,os,shutil,subprocess,tarfile
r=Path(__file__).resolve().parent;repo=Path('D:/code/Lython');prior=r.parent/'known-drain-r515';old=prior/'quiet';q=r/'quiet';q.mkdir(exist_ok=True);assert not any(q.iterdir());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
f=json.loads((r/'frozen/identity.json').read_text(encoding='utf-8'));assert all(sha(r/'frozen'/role/n)==h for role,files in f['imageFiles'].items()for n,h in files.items())
shutil.copyfile(prior/'measurement-catalog.json',r/'measurement-catalog.json');shutil.copyfile(prior/'candidate-measurement-preflight.json',r/'reference-measurement-preflight.json')
d=Path('C:/Users/JoannesVermorel/.dotnet11/dotnet.exe');env=os.environ.copy();env.update(DOTNET_ROOT=str(d.parent),DOTNET_ROOT_X64=str(d.parent));env['PATH']=str(d.parent)+os.pathsep+env['PATH']
with(r/'candidate-measurement-preflight.log').open('w',encoding='utf-8')as log:p=subprocess.run([str(d),str(r/'frozen/candidate/Lokad.Lython.Benchmarks.dll'),'--compare','verify','--catalog',str(r/'measurement-catalog.json'),'--dotnet',str(d),'--python','C:/Python313/python.exe','--python-worker',str(repo/'benchmarks/cpython-worker.py'),'--out',str(r/'candidate-measurement-preflight.json')],env=env,stdout=log,stderr=subprocess.STDOUT,timeout=90)
assert p.returncode==0,(r/'candidate-measurement-preflight.log').read_text(encoding='utf-8')
subjects=[]
for canonical,kind,knownPath,member in [('benchmarks/results/2026-11-17-tab-expansion/measured-core.tar.xz','superseded-historical-core',None,'tab-expansion-ae389c19.dll'),('benchmarks/results/2026-11-18-known-drain-construction/initial/observations.tgz','archived-observation-file-replica','known-drain-b942-20261118/observations.tgz','whole-file'),('benchmarks/results/2026-11-18-known-drain-construction/confirmation/observations.tgz','archived-raw-observation-replica','known-drain-confirm-b943-20261118/confirmation/confirmation.json','confirmation/confirmation.json')]:
 blob=subprocess.check_output(['git','show','HEAD:'+canonical],cwd=repo);assert blob==(repo/canonical).read_bytes()
 if member=='whole-file':data=blob
 elif member=='gzip-payload':
  import gzip
  data=gzip.decompress(blob)
 else:
  with tarfile.open(fileobj=io.BytesIO(blob))as a:data=a.extractfile(member).read()
 subject=dict(kind=kind,sha256=hashlib.sha256(data).hexdigest(),bytes=len(data),canonical=canonical,canonicalSHA256=hashlib.sha256(blob).hexdigest(),member=member,committedBlobVerified=True)
 if knownPath:subject['knownPath']=knownPath
 subjects.append(subject)
assert subjects[0]['sha256']=='ae389c192cc442fca80027746c74a8683314bb0a9da5af349d4ede4fbca58832'
template=(prior/'prove-space.py').read_text(encoding='utf-8');a=template.index("code='''")+len("code='''");b=template.index("'''.replace('SUBJECTS',repr(subjects))",a);code=template[a:b].replace('SUBJECTS',repr(subjects)).replace('current2edeImagesCatalogsToolchainsAndUnmatchedEvidencePreserved','current2edeAndA71ImagesCatalogsToolchainsAndUnmatchedEvidencePreserved')
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73'];p=subprocess.run(ssh+['python3 -'],input=code,text=True,encoding='utf-8',capture_output=True,timeout=60);(r/'retirement-proof.log').write_text(p.stdout+p.stderr,encoding='utf-8');assert p.returncode==0,p.stdout+p.stderr;proofs=json.loads(p.stdout)['proofs'];(r/'retirement-candidates.json').write_text(p.stdout,encoding='utf-8')
identity=dict(sourceRevision='Committedc2bd735b/frozena71abfed focused-qualified versus privateR516/'+f['imageFiles']['candidate']['Lokad.Lython.dll'][:8],purpose='Existing adjacent-result consumer generalizes local stores to discarded calls: remove ordinary discarded publication/materialization and PopTop hot dispatch, keep cold input-cleanup continuation and original guards/spans. No new opcode/owner/cache/framework; current private call-loan facts unchanged. Original/helper textwarm plus floating/call controls; no predicted speedup.',coreSHA256={role:f['imageFiles']['candidate'if role.startswith('candidate')else'reference']['Lokad.Lython.dll']for role in ['reference','reference-control','candidate','candidate-control']},imageFiles=f['imageFiles'],sourceInputsArchiveSHA256=sha(r/'candidate-sources.tar.xz'),productionFiles=587,catalogSHA256=sha(r/'measurement-catalog.json'),allocationCatalogSHA256=sha(r/'catalog.json'),normalAdapterPin='0.4.0',publicationHeld=True)
(q/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8')
s=(old/'collect.py').read_text(encoding='utf-8').replace('accumulate6seconds','accumulate8seconds').replace('warmupSeconds=6','warmupSeconds=8').replace('while min(warmed)<6:','while min(warmed)<8:').replace('if warmed[i]>=6:continue','if warmed[i]>=8:continue').replace('known-size working-drain source pair','prepared discarded-result consumer source pair');(q/'collect.py').write_text(s,encoding='utf-8',newline='\n');shutil.copyfile(old/'archive-owned.py',q/'archive-owned.py')
remote='/home/lokad/lython-bench-checks/discarded-results-b944-20261118';unit='lython-b944-discarded-results-20261118';previous=json.loads((prior/'confirmation/config.json').read_text(encoding='utf-8'))
(q/'run.sh').write_text((prior/'confirmation/run.sh').read_text(encoding='utf-8').replace(previous['root'],remote),encoding='utf-8',newline='\n')
(q/'candidate').mkdir();shutil.copyfile(r/'frozen/candidate/Lokad.Lython.dll',q/'candidate/Lokad.Lython.dll');names=['collect.py','archive-owned.py','run.sh','identity.json','candidate/Lokad.Lython.dll']
with tarfile.open(q/'payload.tgz','w:gz')as a:
 for n in names:a.add(q/n,arcname=n)
c=dict(root=remote,unit=unit,source=previous['root'],sourceRole='candidate',sourceFiles=f['imageFiles']['reference'],sourceCatalogSHA256=identity['catalogSHA256'],catalogSHA256=identity['catalogSHA256'],identity=identity,retireGroups=proofs,payloadBytes=(q/'payload.tgz').stat().st_size,payloadSHA256=sha(q/'payload.tgz'),unpackedBytes=sum((q/n).stat().st_size for n in names));(q/'config.json').write_text(json.dumps(c,indent=2)+'\n',encoding='utf-8')
s=(prior/'confirmation/remote-launch.py').read_text(encoding='utf-8');a=s.index('c=');b=s.index('\nb=Path(',a);s=s[:a]+'c='+repr(c)+s[b:];s=s.replace('os.link(source/role/n,p)',"os.link(source/c['sourceRole']/n,p)").replace('lython-b943-fixtures','lython-b944-fixtures');(q/'remote-launch.py').write_text(s,encoding='utf-8',newline='\n')
s=(prior/'launch.py').read_text(encoding='utf-8').replace('Four-job known-size drain','Four-job discarded-result consumer');(r/'launch.py').write_text(s,encoding='utf-8',newline='\n');(q/'retrieve.py').write_text((old/'retrieve.py').read_text(encoding='utf-8').replace('B942','B944'),encoding='utf-8',newline='\n');shutil.copyfile(prior/'summarize.py',r/'summarize.py')
for p in q.glob('*.py'):ast.parse(p.read_text(encoding='utf-8'))
print('Current32-file/timed4case goldens pass;8s warmup4jobs, exact archived superseded ae389/observation replicas;2ede/a71images preserved.')
