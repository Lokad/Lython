from pathlib import Path
import json
r=Path(__file__).resolve().parent;d=json.loads((r/'delivery/dispatch.json').read_text(encoding='utf-8'))
s=(r.parent/'direct-split-r513/finish-delivery.py').read_text(encoding='utf-8').replace('44234151651',str(d['run'])).replace('10ee56c7f53ca6dc1d7a7f688bb5c2437b9592fd',d['head'])
s=s.replace('2389','2390').replace('4837','4847').replace('all587ProductionInputsMatchMeasured2ede09fc','all587ProductionInputsMatchMeasured70f1ddf9')
s=s.replace('benchmarks/results/2026-11-18-direct-split-construction/refined/delivery','benchmarks/results/2026-11-18-discarded-call-results/delivery')
s=s.replace('Full construction qualification cached and verified; compare final frozen production separately before documenting.','Full joint qualification cached and verified against all587measured production inputs.')
(r/'finish-delivery.py').write_text(s,encoding='utf-8',newline='\n');print('Prepared16summary/2390input/587production verifier; requires actual GREEN terminal.')
