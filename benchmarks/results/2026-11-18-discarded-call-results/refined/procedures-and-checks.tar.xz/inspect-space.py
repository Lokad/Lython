from pathlib import Path
import subprocess
r=Path(__file__).resolve().parent
code='''from pathlib import Path
import fcntl,hashlib,json,os,subprocess
b=Path('/home/lokad/lython-bench-checks')
with(b/'comparison-vm.lock').open('a')as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record|[p]ython3.*cpython-worker.py'],capture_output=True).returncode==1
 assert not any(os.path.ismount(p)for p in b.glob('*/guest-fixtures'))
 groups={}
 for p in b.glob('*/*/Lokad.Lython.dll'):
  m=p.lstat();key=(m.st_dev,m.st_ino)
  if key not in groups:groups[key]=dict(sha256=hashlib.sha256(p.read_bytes()).hexdigest(),bytes=m.st_size,links=m.st_nlink,uid=m.st_uid,paths=[])
  groups[key]['paths'].append(str(p.relative_to(b)))
 print(json.dumps(dict(readOnly=True,scope='Named benchmark core image files only; no deletion or general filesystem audit',groups=list(groups.values()))))
'''
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73'];p=subprocess.run(ssh+['python3 -'],input=code,text=True,encoding='utf-8',capture_output=True,timeout=60);assert p.returncode==0,p.stderr
(r/'space-inspection.json').write_text(p.stdout,encoding='utf-8')
import json
for g in json.loads(p.stdout)['groups']:print(g['sha256'][:12],g['bytes'],g['links'],g['paths'][:2])
