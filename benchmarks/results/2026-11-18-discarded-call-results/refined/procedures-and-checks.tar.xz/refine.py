from pathlib import Path
r=Path(__file__).resolve().parent;out=r/'measured-first';out.mkdir(exist_ok=False)
names=['frozen','quiet','candidate-sources.tar.xz','prototype.patch.gz','candidate-preflight.json','candidate-preflight.log','candidate-allocation.json','candidate-allocation.log','summary.json','allocation-summary.json','checks.json','build.log','reference-ir.json','candidate-ir.json','result-consumer-facts.json','candidate-measurement-preflight.json','candidate-measurement-preflight.log','reference-measurement-preflight.json','retirement-candidates.json','retirement-proof.log','prestage-space-refused']
for n in names:(r/n).rename(out/n)
work=Path('D:/code/Lython/.git/agent-worktrees/discarded-results-r516')
for n in ['Runtime/LythonRuntime.Executable.NativePrefix.cs','Runtime/LythonRuntime.Executable.Results.cs']:
 p=work/'src/Lokad.Lython'/n;s=p.read_text(encoding='utf-8')
 if 'NativePrefix'in n:
  old='''            var discard = consumer.OpCode == ExecutableOpCode.PopTop;
            _scope.CheckExecution(consumer.Span);
            if (discard)
            {
                if (value.IsUnassigned) _ = value.Object.RequireNotNull();
                Index++;
                return;
            }
            Values[consumer.LocalSlot] = value;
            Index++;'''
  new='''            _scope.CheckExecution(consumer.Span);
            if (consumer.OpCode == ExecutableOpCode.StoreLocal)
                Values[consumer.LocalSlot] = value;
            else if (consumer.OpCode != ExecutableOpCode.PopTop)
                throw new InvalidOperationException("Invalid prepared result consumer.");
            else if (value.IsUnassigned) _ = value.Object.RequireNotNull();
            Index++;'''
 else:
  old='''            var discard = consumer.OpCode == ExecutableOpCode.PopTop;
            // Discarded calls are neither directly returned nor consumed by
            // iteration, so cannot return private iteration loans. Their guest
            // results need neither publication nor scalar materialization.
            execution.Stack.CheckExecution(consumer.Span);
            if (discard)
            {
                if (value.IsUnassigned) _ = value.Object.RequireNotNull();
                execution.InstructionIndex++;
                return;
            }
            StoreLocalValue(execution.Code, execution.Locals, invocation, consumer.LocalSlot, value, consumer.Span);
            execution.InstructionIndex++;'''
  new='''            execution.Stack.CheckExecution(consumer.Span);
            if (consumer.OpCode == ExecutableOpCode.StoreLocal)
                StoreLocalValue(execution.Code, execution.Locals, invocation, consumer.LocalSlot, value, consumer.Span);
            else if (consumer.OpCode != ExecutableOpCode.PopTop)
                throw new InvalidOperationException("Invalid prepared result consumer.");
            // Discarded calls cannot return private iteration loans. No
            // publication or scalar materialization is needed for their result.
            else if (value.IsUnassigned) _ = value.Object.RequireNotNull();
            execution.InstructionIndex++;'''
 assert old in s,n;s=s.replace(old,new);p.write_text(s,encoding='utf-8',newline='\n')
print('Original70f1source/images/observations preserved without relabelling. Refine existing consumer to validated StoreLocal first; no new feature, cleanup rule or prediction.')
