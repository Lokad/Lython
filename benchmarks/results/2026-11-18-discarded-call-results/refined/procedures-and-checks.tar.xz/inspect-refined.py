from pathlib import Path
import hashlib,json,os,subprocess
r=Path(__file__).resolve().parent;prior=r.parent/'activation-source-r504';project=r/'inspect-pair';project.mkdir(exist_ok=True)
base=(prior/'inspect/Program.cs').read_text(encoding='utf-8').replace('i.HasLocalResult,','HasResultConsumer = i.HAS_CONSUMER,').replace('exact qualified frozen core','exact frozen core')
csproj=(prior/'inspect/inspect.csproj').read_text(encoding='utf-8');a=csproj.index('<HintPath>');b=csproj.index('</HintPath>',a);csproj=csproj[:a]+'<HintPath>$(InspectionCorePath)'+csproj[b:];(project/'inspect.csproj').write_text(csproj,encoding='utf-8')
import shutil
shutil.copyfile(r/'measured-first/reference-ir.json',r/'reference-ir.json')
d=Path('C:/Users/JoannesVermorel/.dotnet11/dotnet.exe');env=os.environ.copy();env.update(DOTNET_ROOT=str(d.parent),DOTNET_ROOT_X64=str(d.parent));env['PATH']=str(d.parent)+os.pathsep+env['PATH']
for role in ['candidate']:
 core=r/'frozen'/role/'Lokad.Lython.dll';(project/'Program.cs').write_text(base.replace('HAS_CONSUMER','HasLocalResult'if role=='reference'else'HasResultConsumer'),encoding='utf-8')
 with(r/(role+'-inspect-build.log')).open('w',encoding='utf-8')as log:p=subprocess.run([str(d),'build',str(project/'inspect.csproj'),'-c','Release','--no-incremental','-p:InspectionCorePath='+str(core)],env=env,stdout=log,stderr=subprocess.STDOUT,timeout=90)
 assert p.returncode==0,(r/(role+'-inspect-build.log')).read_text(encoding='utf-8')
 with(r/(role+'-inspect.log')).open('w',encoding='utf-8')as log:p=subprocess.run([str(d),str(project/'bin/Release/net11.0/Lokad.Lython.WhiteBox.Tests.dll'),str(r.parent/'known-drain-r515/measurement-catalog.json'),str(r/(role+'-ir.json'))],env=env,stdout=log,stderr=subprocess.STDOUT,timeout=60)
 assert p.returncode==0,(r/(role+'-inspect.log')).read_text(encoding='utf-8')
 v=json.loads((r/(role+'-ir.json')).read_text(encoding='utf-8-sig'));assert v['CoreSha256']==hashlib.sha256(core.read_bytes()).hexdigest()
 for w in v['Workloads']:
  for c in w['Codes']:
   rows=c['Instructions'];discarded=[x for i,x in enumerate(rows[:-1])if x['OpCode']=='Call'and x['HasResultConsumer']and rows[i+1]['OpCode']=='PopTop']
   if discarded or c['Name']=='append_cleaned':print(role,w['Id'],c['Name'],'slots',c['ValueStorageCapacity'],'physicalInstructions',len(rows),'discardedResultConsumers',len(discarded))
