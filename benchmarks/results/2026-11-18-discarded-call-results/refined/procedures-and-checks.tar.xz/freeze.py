from pathlib import Path
import gzip,hashlib,json,os,shutil,subprocess,tarfile
r=Path(__file__).resolve().parent;repo=Path('D:/code/Lython');work=repo/'.git/agent-worktrees/discarded-results-r516';prior=r.parent/'known-drain-r515'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert 'Build succeeded.'in(r/'build.log').read_text(encoding='utf-8-sig')
checks=json.loads((r/'checks.json').read_text(encoding='utf-8'));assert len(checks)==4 and all(c['exitCode']==0 for c in checks)
base=json.loads((prior/'frozen/identity.json').read_text(encoding='utf-8'));frozen=r/'frozen';frozen.mkdir(exist_ok=False);images={}
for role in ['reference','candidate']:
 image=frozen/role;image.mkdir()
 for n,h in base['imageFiles']['candidate'].items():
  assert sha(prior/'frozen/candidate'/n)==h,n;shutil.copyfile(prior/'frozen/candidate'/n,image/n)
 if role=='candidate':shutil.copyfile(work/'src/Lokad.Lython/bin/Release/net11.0/Lokad.Lython.dll',image/'Lokad.Lython.dll')
 images[role]={n:sha(image/n)for n in base['imageFiles']['candidate']}
 for p in(prior/'frozen/candidate').glob('ValidatedAllocation.*'):shutil.copyfile(p,image/p.name)
assert [n for n in images['reference']if images['reference'][n]!=images['candidate'][n]]==['Lokad.Lython.dll']
shutil.copyfile(r.parent/'generator-sum-r475/catalog.json',r/'catalog.json')
names=list(base['sourceInputs']);assert len(names)==2390
hashes={n:sha(work/n)for n in names}
with tarfile.open(r/'candidate-sources.tar.xz','w:xz')as a:
 for n in names:a.add(work/n,arcname=n)
changed=subprocess.check_output(['git','diff','HEAD','--name-only'],cwd=work,text=True).splitlines();production=[n for n in changed if n.startswith('src/Lokad.Lython/')];assert len(production)==6,production
(r/'prototype.patch.gz').write_bytes(gzip.compress(subprocess.check_output(['git','diff','HEAD','--']+changed,cwd=work),mtime=0))
identity=dict(referenceSource='Committedc2bd735b/frozena71abfed; retained known-size drains, focused-qualified/full delivery pending coherent boundary',candidateSource='PrivateR516 onc2bd735b: existing adjacent-result consumer handles local stores and discarded calls. Ordinary discarded calls skip publication/materialization/PopTop hot dispatch; original consumer remains pending input-cleanup continuation. Same instruction extent field/size; no new opcode/cache/owner/framework. Discarded calls cannot return private iteration loans. Original spans/guards/preflights/actual IO and cleanup retained. Existing weak-lifetime check now uses executable path. Refined StoreLocal-first consumer removes branch/return duplication and exposes its opcode fact; initial70f1uncertainty remains separate. Only core DLL changes in measured image.',imageFiles=images,sourceInputs=hashes,sourceInputsArchiveSHA256=sha(r/'candidate-sources.tar.xz'),productionFiles=587,changedProductionFiles=production,catalogSHA256=sha(r/'catalog.json'),normalAdapterPin='0.4.0',publicationHeld=True)
(frozen/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8')
dotnet=Path('C:/Users/JoannesVermorel/.dotnet11/dotnet.exe');env=os.environ.copy();env.update(DOTNET_ROOT=str(dotnet.parent),DOTNET_ROOT_X64=str(dotnet.parent));env['PATH']=str(dotnet.parent)+os.pathsep+env['PATH']
for kind in ['preflight','allocation']:shutil.copyfile(prior/('candidate-'+kind+'.json'),r/('reference-'+kind+'.json'))
for role in ['candidate']:
 image=frozen/role
 for kind,cmd in [('preflight',[str(dotnet),str(image/'Lokad.Lython.Benchmarks.dll'),'--compare','verify','--catalog',str(r/'catalog.json'),'--dotnet',str(dotnet),'--python','C:/Python313/python.exe','--python-worker',str(repo/'benchmarks/cpython-worker.py'),'--out',str(r/(role+'-preflight.json'))]),('allocation',[str(dotnet),str(image/'ValidatedAllocation.dll'),str(image),str(r/'catalog.json'),str(r/(role+'-allocation.json'))])]:
  with(r/(role+'-'+kind+'.log')).open('w',encoding='utf-8')as log:p=subprocess.run(cmd,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=180)
  assert p.returncode==0,(r/(role+'-'+kind+'.log')).read_text(encoding='utf-8');print(role,kind,'passes',flush=True)
print('Frozen current32-file pair; unchanged reference goldens/allocation reused, new candidate13goldens/allocation/reuse. Candidate core:',images['candidate']['Lokad.Lython.dll'],flush=True)
