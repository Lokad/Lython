from pathlib import Path
import hashlib,json,shutil,subprocess
r=Path(__file__).resolve().parent;q=r/'quiet';repo=Path('D:/code/Lython');out=r/'prestage-space-refused';out.mkdir(exist_ok=False)
for n in ['launch.log','config.json','remote-launch.py']:shutil.copyfile(q/n,out/n)
assert 'owned-stage", line 30' in(q/'launch.log').read_text(encoding='utf-8')
c=json.loads((q/'config.json').read_text(encoding='utf-8'));canonical='benchmarks/results/2026-11-18-known-drain-construction/confirmation/observations.tgz';blob=subprocess.check_output(['git','show','HEAD:'+canonical],cwd=repo);assert blob==(repo/canonical).read_bytes();h=hashlib.sha256(blob).hexdigest()
c['retireGroups'].append(dict(kind='archived-observation-file-replica',sha256=h,bytes=len(blob),canonical=canonical,canonicalSHA256=h,member='whole-file',committedBlobVerified=True,paths=['known-drain-confirm-b943-20261118/observations.tgz'],links=1))
(q/'config.json').write_text(json.dumps(c,indent=2)+'\n',encoding='utf-8');s=(q/'remote-launch.py').read_text(encoding='utf-8');a=s.index('c=');b=s.index('\nb=Path(',a);s=s[:a]+'c='+repr(c)+s[b:];(q/'remote-launch.py').write_text(s,encoding='utf-8',newline='\n');(q/'launch.log').unlink()
print('Original floor refusal preserved before deletion/launch; add exact committed observation archive replica:',len(blob),'bytes.254/252MiB guards unchanged, all aliases freshly revalidated on stage.')
