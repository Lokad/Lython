from pathlib import Path
import json
r=Path(__file__).resolve().parent
s=(r/'prepare-quiet.py').read_text(encoding='utf-8')
a=s.index('for canonical,kind,knownPath,member in ');b=s.index('\n blob=',a)
subjects=[('benchmarks/results/2026-11-18-discarded-call-results/initial/candidate-core.dll.gz','superseded-prototype-core','discarded-results-b944-20261118/candidate/Lokad.Lython.dll','gzip-payload'),('benchmarks/results/2026-11-18-discarded-call-results/initial/observations.tgz','archived-raw-observation-replica','discarded-results-b944-20261118/confirmation/confirmation.json','confirmation/confirmation.json'),('benchmarks/results/2026-11-18-discarded-call-results/initial/observations.tgz','archived-observation-file-replica','discarded-results-b944-20261118/observations.tgz','whole-file'),('benchmarks/results/2026-11-18-call-entry-gate/initial/observations.tgz','archived-failed-observation-file-replica','call-entry-b940-20261118/observations.tgz','whole-file')]
s=s[:a]+'for canonical,kind,knownPath,member in '+repr(subjects)+':'+s[b:]
old=json.loads((r/'measured-first/frozen/identity.json').read_text(encoding='utf-8'))['imageFiles']['candidate']['Lokad.Lython.dll']
s=s.replace("assert subjects[0]['sha256']=='ae389c192cc442fca80027746c74a8683314bb0a9da5af349d4ede4fbca58832'","assert subjects[0]['sha256']=="+repr(old))
s=s.replace('discarded-results-b944-20261118','discarded-results-refined-b945-20261118').replace('lython-b944-discarded-results-20261118','lython-b945-discarded-results-refined-20261118').replace('lython-b944-fixtures','lython-b945-fixtures')
# Retirement subjects name the original condition, not the new collection.
s=s.replace("'discarded-results-refined-b945-20261118/candidate/Lokad.Lython.dll'","'discarded-results-b944-20261118/candidate/Lokad.Lython.dll'").replace("'discarded-results-refined-b945-20261118/confirmation/confirmation.json'","'discarded-results-b944-20261118/confirmation/confirmation.json'").replace("'discarded-results-refined-b945-20261118/observations.tgz'","'discarded-results-b944-20261118/observations.tgz'")
s=s.replace('Current32-file/timed4case goldens pass;8s warmup4jobs, exact archived superseded ae389/observation replicas;2ede/a71images preserved.','Refined32-file/timed4case goldens pass;8s4jobs. Original70f1/B944uncertainty retained; exact archived prototype/observation replicas only retired, current2ede/a71 preserved.')
s=s.replace('Original/helper textwarm plus floating/call controls; no predicted speedup.','StoreLocal-first source refinement exposes validated consumer opcode before checked LocalSlot getter; initial70f1/B944uncertainty retained. Original/helper textwarm plus floating/call controls, no source subtraction or JIT/CPU forecast.')
exec(compile(s,str(r/'prepare-refined-quiet.py'),'exec'),dict(__file__=str(r/'prepare-refined-quiet.py')))
