from pathlib import Path
import gzip,hashlib,json,shutil,tarfile
r=Path(__file__).resolve().parent;repo=Path('D:/code/Lython');work=repo/'.git/agent-worktrees/discarded-results-r516';out=repo/'benchmarks/results/2026-11-18-discarded-call-results/refined';out.mkdir(exist_ok=False)
q=json.loads((r/'quiet/archive-receipt.json').read_text(encoding='utf-8'));assert q['complete']and q['allWorkersJoined']and q['guestFixturesRemoved'];assert hashlib.sha256((r/'quiet/observations.tgz').read_bytes()).hexdigest()==q['archiveSHA256']
f=json.loads((r/'frozen/identity.json').read_text(encoding='utf-8'));prod=[n for n in f['sourceInputs']if n.startswith('src/Lokad.Lython/')];assert len(prod)==587
same=lambda a,b:a==b or a.decode('utf-8-sig').replace('\r\n','\n')==b.decode('utf-8-sig').replace('\r\n','\n')
changed=[]
for n in prod:
 data=(work/n).read_bytes();assert hashlib.sha256(data).hexdigest()==f['sourceInputs'][n]
 if not same((repo/n).read_bytes(),data):changed.append(n)
assert set(changed)==set(f['changedProductionFiles'])and len(changed)==6
for n in changed+['tests/Lokad.Lython.Tests/LoweringArchitectureSubsystemTests.cs','tests/Lokad.Lython.Tests/FunctionBodyTemporaryLifetimeTests.cs']:shutil.copyfile(work/n,repo/n)
assert all(same((repo/n).read_bytes(),(work/n).read_bytes())for n in prod)
decision=dict(retain=True,state='Integrated, focused-qualified; jointR515/R516full delivery next',reference='Committedc2bd735b/frozena71abfed',candidate='RefinedR516/c0367d98',eliminated='Ordinary immediately discarded call-result publication/materialization and separate hot PopTop dispatch, using existing prepared consumer extent. Original next instruction remains pending input-cleanup continuation. No new opcode/table/cache/owner/framework.',validation='Both targets121internal/78public,13goldens/reuse/timed4case32filechecks; existing weak-lifetime regression now executable. Ten new discard consumers with identical physical instructions/slots/continuations. Added complete numeric CSV validation gate bothimages/CPythongoldens/reuse passes.',established='Refined named helpertext warmelapsed0.82..3.09percent lower/supportingCPU. Allocationflat in original13case diagnostic; separate4128record/128183B numeric CSV validation allocation3405830to3176454B(-6.7348percent), accountedpeaksflat. No CSV CPU claim.',regressionDebt='Positional call control elapsed+0.88..+2.56percent with.65/1.00process spreads, CPU-.40..+6.21; accept this measured control slowdown for the coherent transport/named helper/allocation benefits. Floating remains uncertain with4.55candidate spread; originalnearparity. Recheck positional control with the next selected call/frame redesign; do not silently reclassify this debt or claim a universal gain.',history='Original70f1/B944uncertainty/ref12.79floatingprocessdifference preserved. Runtime StoreLocal-first refinement, no causal subtraction or JIT attribution. Validation fixture metadata mismatch rejected before guest work, corrected/goldens independently established.',all587ProductionInputsMatchMeasuredSource=True,binaryEqualityInferred=False,fullQualificationPending=True,publicationHeld=True)
(r/'decision.json').write_text(json.dumps(decision,indent=2)+'\n',encoding='utf-8')
for n in ['summary.json','allocation-summary.json','checks.json','candidate-sources.tar.xz','prototype.patch.gz','decision.json','candidate-allocation.json','candidate-measurement-preflight.json','result-consumer-facts.json','reference-ir.json','candidate-ir.json']:shutil.copyfile(r/n,out/n)
for n in ['archive-receipt.json','observations.tgz','terminal-status.json','identity.json']:shutil.copyfile(r/'quiet'/n,out/n)
(out/'candidate-core.dll.gz').write_bytes(gzip.compress((r/'frozen/candidate/Lokad.Lython.dll').read_bytes(),mtime=0));shutil.copytree(r/'validation',out/'validation')
with tarfile.open(out/'procedures-and-checks.tar.xz','w:xz')as a:
 for p in sorted(r.rglob('*')):
  if p.is_file()and not {'frozen','retrieved','bin','obj','measured-first'}&set(p.relative_to(r).parts)and p.suffix in ['.py','.json','.log','.sh']:a.add(p,arcname=p.relative_to(r).as_posix())
(out/'README.md').write_text('''# Discarded call results: refined source pair

R516/B945,2026-11-18UTC, **c0367d98 versus a71abfed**. Retained; joint R515/R516
platform/stress/installed-package delivery pending. All587production inputs match
the measured source; no rebuilt-binary equality inferred. Existing result-consumer
extent now covers local stores and discarded calls. Remove ordinary unused
publication/materialization/PopTop hot dispatch; keep real input-cleanup continuation.
Same instruction/slot representation; no new opcode/table/cache/owner/framework.
Validated StoreLocal-first runtime ordering is a refinement of the original
[70f1source](../initial/README.md), not evidence of a particular JIT cause.

Both actual11/10 each121internal/78public pass, including executable discarded-result
lifetime, cancellation, first refusal and ownership.13goldens/allocation/reuse plus
exact timed4case32-file checks pass. Ten new discard consumers; all other IR fields,
physical instructions/slots/spans/continuations remain unchanged. Private call loans
retain iteration/direct-return ownership rules; eager operations/preflights remain.

Four quietVM jobs188.12s;8s rotated warmups/five rounds/two processes per source,
defaultGC/tiering, AzureF4as_v7/Ubuntu24.04.4/.NET11RC3:

| Warm complete script | Elapsed change | Wider process CPU | Ref/candidate spread |
| --- | ---: | ---: | ---: |
| Original text |−0.40..+1.91%|−1.96..+1.36%|0.65/1.65%|
| Helper-list text |−3.09..−0.82%|−2.14..−0.17%|0.03/2.31%|
| Floating |−0.30..+4.77%|−1.70..+1.81%|0.51/4.55%|
| Positional calls |+0.88..+2.56%|−0.40..+6.21%|0.65/1.00%|

Named helper improvement is modest; original/floating CPU remain uncertain.
Positional calls measured slower: accept that control debt for this coherent
transport benefit and recheck with the next selected call/frame redesign. No
universal gain or subtraction from earlier source conditions. Original12.79%
floating reference-process disagreement and all adverse conditions stay preserved.

Original13case allocation/peaks are effectivelyflat. An additional local complete
CSV field-validation script exercises actual removed scalar materialization:
4,096valid/32invalid records,128,183B, maintained numeric CSV data including Unicode/
quoted newlines plus32known malformed records. Both frozen images pass independent
fixed goldens via CPython and shared-budget reuse. Allocation3,405,830→3,176,454B
(−6.7348%); accountedpeakunchanged. This is229,376B/56B per valid record in this
diagnostic, consistent with removed scalar boxing; no CSV CPU claim. Its selection
does not replace the original controls. Initial fixture size-metadata mismatch was
rejected before guest work and is retained in [validation evidence](validation/summary.json).

Warm includes Run/mediatedRAMI/O/goldens/prior-result cleanup; startup/reset/protocol/
finalcache teardown excluded, processCPU wider. All users joined/quiet/golden/SHA/
fixture teardown pass. Exact archived original prototype/observation replicas alone
retired under fresh byte/path/UID/hash/link/all-alias proof; current2ede/a71images/
catalogs/toolchains/unmatched evidence and254/252MiBguards preserved. Normal adapter
0.4unchanged, publication postponed; wider performance roadmap continues.

[Decision](decision.json),[summary](summary.json),[IR](result-consumer-facts.json),
[raw](observations.tgz),[source](candidate-sources.tar.xz),[patch](prototype.patch.gz),
[checks/procedures](procedures-and-checks.tar.xz),[original condition](../initial/README.md).
''',encoding='utf-8',newline='\n')
p=repo/'docs/BENCHMARKS.md';s=p.read_text(encoding='utf-8');needle='| Known-size working drains |';assert needle in s;s=s.replace(needle,'| Discarded call results | CSV-validation allocation6.73% lower; named helper elapsed0.8–3.1% lower with supporting CPU | Separatec0367d98 versusa71abfed pair; positional calls0.9–2.6%slower, floating uncertain. Focused checks pass; joint full delivery pending. [Evidence](../benchmarks/results/2026-11-18-discarded-call-results/refined/README.md). |\n'+needle);p.write_text(s,encoding='utf-8',newline='\n')
p=repo/'docs/RUNTIME.md';s=p.read_text(encoding='utf-8');needle='Supported expressions in executable code use instructions;';assert needle in s;s=s.replace(needle,'Adjacent operation results can complete a local store or an immediate discard\nwithout temporary publication. Discarded calls still perform their operation and\nadmission; the original consumer checkpoint and pending input-cleanup continuation\nremain. Unobserved native scalar results need no object materialization.\n\n'+needle);p.write_text(s,encoding='utf-8',newline='\n')
p=repo/'CHANGELOG.md';s=p.read_text(encoding='utf-8');s=s.replace('## 0.11.0 - Unreleased\n','## 0.11.0 - Unreleased\n\n- Reuse executable result forwarding for immediately discarded call results,\n  avoiding unused publication and scalar materialization while preserving eager\n  operations, admission, source checkpoints and pending cleanup.\n',1);p.write_text(s,encoding='utf-8',newline='\n')
with(repo/'benchmarks/EXPERIMENTS.md').open('a',encoding='utf-8',newline='\n')as a:a.write('''

R516/B945 [refined discarded-result source pair](results/2026-11-18-discarded-call-results/refined/README.md), retainedc0367d98 versusfocuseda71abfed: same prepared consumer representation, validated StoreLocal-first runtime shape, ordinary discarded publication/materialization/PopTop hot dispatch removed, real cleanup continuation retained. Both targets121internal/78public/13goldens/reuse/actual4case32files pass; all587source inputs match. Namedhelperwarm−3.09..−.82%elapsed/supportingCPU; originalnearparity, floating4.55%candidate disagreement/CPUuncertain; positional+0.88..+2.56%elapsed is accepted control debt for the next call/frame milestone, no universal gain. Additional complete4128record/128183B CSV validation allocation−6.7348%(3405830→3176454B), accountedpeakflat, bothimages/goldens/reuse pass; no CSV CPU claim or replacement of adverse controls. Original70f1/ref12.79%floating discrepancy preserved; no source subtraction/JIT attribution. JointR515/R516full qualification next, not inherited; normaladapter0.4/publicationheld.
''')
print('R516 integrated with587measured production inputs; named helper/allocation gains and positional regression debt explicit. Joint full delivery next.')
