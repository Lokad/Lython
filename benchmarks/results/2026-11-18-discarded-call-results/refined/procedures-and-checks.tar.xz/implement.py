from pathlib import Path
r=Path(__file__).resolve().parent;work=Path('D:/code/Lython/.git/agent-worktrees/discarded-results-r516')
files=['Frontend/ExecutableScript.cs','Frontend/ExecutableStackLayout.cs','Frontend/ExecutableScript.NativeSegments.cs','Runtime/LythonRuntime.Executable.IntegerChains.cs','Runtime/LythonRuntime.Executable.NativePrefix.cs','Runtime/LythonRuntime.Executable.Results.cs']
for n in files:
 p=work/'src/Lokad.Lython'/n;s=p.read_text(encoding='utf-8');s=s.replace('HasLocalResult','HasResultConsumer').replace('WithLocalResult','WithResultConsumer').replace('CompleteLocalResult','CompleteResultConsumer');p.write_text(s,encoding='utf-8',newline='\n')
p=work/'src/Lokad.Lython/Frontend/ExecutableScript.cs';s=p.read_text(encoding='utf-8');s=s.replace('A complemented prepared extent marks the adjacent local-result store.','A complemented prepared extent marks the adjacent result consumer.').replace('The following store retains its own source span and is also the','The following consumer retains its source span and is also the');p.write_text(s,encoding='utf-8',newline='\n')
p=work/'src/Lokad.Lython/Frontend/ExecutableStackLayout.cs';s=p.read_text(encoding='utf-8');old='''                if (instruction.OpCode == ExecutableOpCode.StoreLocal && first == int.MaxValue && kept > 0
                    && CanForwardResult(instructions[kept - 1], code.Constants))''';new='''                if (kept > 0 &&
                    ((instruction.OpCode == ExecutableOpCode.StoreLocal && first == int.MaxValue
                        && CanForwardResult(instructions[kept - 1], code.Constants))
                    || (instruction.OpCode == ExecutableOpCode.PopTop
                        && instructions[kept - 1].OpCode == ExecutableOpCode.Call)))''';assert old in s;s=s.replace(old,new);s=s.replace('Keep the store as the pending-cleanup continuation and for its','Keep the consumer as the pending-cleanup continuation and for its');p.write_text(s,encoding='utf-8',newline='\n')
p=work/'src/Lokad.Lython/Runtime/LythonRuntime.Executable.Results.cs';s=p.read_text(encoding='utf-8');old='''            ref readonly var store = ref execution.Code.Instructions[execution.InstructionIndex + 1];
            execution.Stack.CheckExecution(store.Span);
            StoreLocalValue(execution.Code, execution.Locals, invocation, store.LocalSlot, value, store.Span);
            execution.InstructionIndex++;''';new='''            ref readonly var consumer = ref execution.Code.Instructions[execution.InstructionIndex + 1];
            var discard = consumer.OpCode == ExecutableOpCode.PopTop;
            // Private owned results must be visible to unwind before the
            // consumer checkpoint can throw. Ordinary discarded values need
            // neither a temporary publication nor scalar materialization.
            var temporary = discard && value.Reference is ExecutableTemporaryValue;
            if (temporary) execution.Stack.PublishSlot(instruction.ResultSlot, instruction.LiveExtent, value);
            execution.Stack.CheckExecution(consumer.Span);
            if (discard)
            {
                if (value.IsUnassigned) _ = value.Object.RequireNotNull();
                // A failing disposal belongs to the original consumer, and
                // pending asynchronous disposal remains owned by this driver.
                execution.InstructionIndex++;
                if (temporary) execution.Stack.RetireTo(consumer.LiveExtent);
                return;
            }
            StoreLocalValue(execution.Code, execution.Locals, invocation, consumer.LocalSlot, value, consumer.Span);
            execution.InstructionIndex++;''';assert old in s;s=s.replace(old,new).replace('before the binding becomes visible','before the consumer becomes visible').replace('and following store already implement that','and following consumer already implement that');p.write_text(s,encoding='utf-8',newline='\n')
p=work/'src/Lokad.Lython/Runtime/LythonRuntime.Executable.NativePrefix.cs';s=p.read_text(encoding='utf-8');old='''            ref readonly var store = ref Code.Instructions[Index + 1];
            _scope.CheckExecution(store.Span);
            Values[store.LocalSlot] = value;
            Index++;''';new='''            ref readonly var consumer = ref Code.Instructions[Index + 1];
            var discard = consumer.OpCode == ExecutableOpCode.PopTop;
            var temporary = discard && value.Reference is ExecutableTemporaryValue;
            if (temporary) Put(instruction.ResultSlot, instruction.LiveExtent, value);
            _scope.CheckExecution(consumer.Span);
            if (discard)
            {
                if (value.IsUnassigned) _ = value.Object.RequireNotNull();
                Index++;
                if (temporary) Trim(consumer.LiveExtent);
                return;
            }
            Values[consumer.LocalSlot] = value;
            Index++;''';assert old in s;s=s.replace(old,new);p.write_text(s,encoding='utf-8',newline='\n')
p=work/'tests/Lokad.Lython.Tests/LoweringArchitectureSubsystemTests.cs';s=p.read_text(encoding='utf-8');s=s.replace('HasLocalResult','HasResultConsumer');p.write_text(s,encoding='utf-8',newline='\n')
p=work/'tests/Lokad.Lython.Tests/FunctionBodyTemporaryLifetimeTests.cs';s=p.read_text(encoding='utf-8');old='''        await LythonRuntime.ExecuteStatementsAsync(LoweredScript.Lower(frontend.Script.RequireNotNull()).Statements, root);''';new='''        var executable = ExecutableScript.Compile(LoweredScript.Lower(frontend.Script.RequireNotNull())).EntryPoint;
        await LythonRuntime.ExecuteExecutableCodeObjectAsync(executable, root, default, null);''';assert old in s;s=s.replace(old,new);p.write_text(s,encoding='utf-8',newline='\n')
print('Existing prepared result consumer generalized; ordinary discards avoid publication/boxing/PopTop hot dispatch, real cleanup continuation retained. Existing lifetime test now exercises executable public path.')
