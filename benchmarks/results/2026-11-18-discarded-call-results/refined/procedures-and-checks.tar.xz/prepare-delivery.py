from pathlib import Path
import json,subprocess
r=Path(__file__).resolve().parent;repo=Path('D:/code/Lython');prior=r.parent/'direct-split-r513'
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()
# Generate only after the measured runtime is retained and committed. No dispatch
# or new qualification follows from merely preparing this guarded procedure.
f=json.loads((r/'frozen/identity.json').read_text(encoding='utf-8'));names=[n for n in f['sourceInputs']if n.startswith('src/Lokad.Lython/')];assert len(names)==587
import hashlib
with __import__('tarfile').open(r/'candidate-sources.tar.xz')as a:
 for n in names:
  actual=subprocess.check_output(['git','show',head+':'+n],cwd=repo);measured=a.extractfile(n).read()
  assert actual==measured or actual.decode('utf-8-sig').replace('\r\n','\n')==measured.decode('utf-8-sig').replace('\r\n','\n'),n
s=(prior/'start-delivery.py').read_text(encoding='utf-8').replace("assert head.startswith('10ee56c7')","assert head=="+repr(head))
s=s.replace("notes.parent/'buffered-yield-r510/delivery/inputs.json'","notes.parent/'direct-split-r513/delivery/inputs.json'")
s=s.replace("names=sorted(list(old['inputs'])+['src/Lokad.Lython/Runtime/Text/PyStringOps.SplitScanner.cs'])","names=sorted(list(old['inputs'])+['tests/Lokad.Lython.Tests/KnownDrainOwnershipTests.cs'])")
s=s.replace('2389','2390').replace('ordinaryInternal=4837','ordinaryInternal=4847').replace('direct split construction delivery','known-drain / discarded-result delivery')
(r/'start-delivery.py').write_text(s,encoding='utf-8',newline='\n')
print('Prepared one coherent delivery dispatch; all587committed production inputs match measured candidate. No workflow dispatched by preparation.')
