from pathlib import Path
import gzip,hashlib,json,shutil,tarfile
r=Path(__file__).resolve().parent;repo=Path('D:/code/Lython');out=repo/'benchmarks/results/2026-11-18-discarded-call-results/initial';out.mkdir(parents=True,exist_ok=False)
v=json.loads((r/'quiet/archive-receipt.json').read_text(encoding='utf-8'));assert v['complete']and v['allWorkersJoined']and v['guestFixturesRemoved'];assert hashlib.sha256((r/'quiet/observations.tgz').read_bytes()).hexdigest()==v['archiveSHA256']
decision=dict(retain=False,state='Private; one changed-source result-consumer refinement selected',reference='Committedc2bd735b/focuseda71abfed; full delivery pending',candidate='PrivateR516/70f1ddf9',established='Same physical instructions/slots/extent field; ten new prepared discard consumers in fourcatalog. Ordinary discards avoid result publication/materialization and PopTop hot dispatch; pending input cleanup keeps original continuation. Both targets121internal/78public,13goldens/reuse,actual4case32filechecks pass; allocation/peaksflat.',uncertainty='B944helperelapsed-4.20..+1.14percent/CPU-3.69..+1.01 with4.16candidate spread; floatingref12.79percent/controlcandidate4.05percent differences, samples individuallystable. Originalnearparity; positional+0.04..+2.36elapsed/CPUstraddleszero. No consistent CPU improvement or regression established.',next='One source refinement puts validated StoreLocal consumer first, removing duplicated discard branch/return and allowing LocalSlot getter validation to follow an explicit opcode fact. This may improve code shape, not a demonstrated JIT/CPU cause. Rebuild/focus/freeze and one four-case source pair; no source-condition subtraction, repeated unchanged campaign or permanent design ban. Retain/refine/withdraw with explicit debt decision; broader objective continues.',publicationHeld=True)
(r/'initial-decision.json').write_text(json.dumps(decision,indent=2)+'\n',encoding='utf-8')
for n in ['summary.json','allocation-summary.json','checks.json','candidate-sources.tar.xz','prototype.patch.gz','initial-decision.json','reference-allocation.json','candidate-allocation.json','reference-measurement-preflight.json','candidate-measurement-preflight.json','result-consumer-facts.json','reference-ir.json','candidate-ir.json','source-gate.json']:shutil.copyfile(r/n,out/n)
for n in ['archive-receipt.json','observations.tgz','terminal-status.json','identity.json']:shutil.copyfile(r/'quiet'/n,out/n)
(out/'candidate-core.dll.gz').write_bytes(gzip.compress((r/'frozen/candidate/Lokad.Lython.dll').read_bytes(),mtime=0))
with tarfile.open(out/'procedures-and-checks.tar.xz','w:xz')as a:
 for p in sorted(r.rglob('*')):
  if p.is_file()and not {'frozen','retrieved','bin','obj'}&set(p.relative_to(r).parts)and p.suffix in ['.py','.json','.log','.sh']:a.add(p,arcname=p.relative_to(r).as_posix())
(out/'README.md').write_text('''# Discarded call results: initial source pair

R516/B944,2026-11-18UTC, private **70f1ddf9** versus committed/focused **c2bd735b /
a71abfed**. Neither new prototype nor reference inherits full qualification.
Generalize existing local-result forwarding to immediately discarded calls.
Same extent field/instruction size/physical instruction and slot counts; ten
prepared discard consumers in four catalog sources. Ordinary guest results skip
temporary publication/materialization/PopTop hot dispatch. Private call loans
remain limited to iteration/direct-return consumers. Input cleanup retains the
original following instruction as a real continuation; no new owner/cache/opcode.

Both actual11/10 each121internal/78public pass; existing weak-lifetime regression
now exercises executable hosting.13goldens/allocation/reuse and exact timed4case
32-file images/goldens pass. Allocation/peaks effectivelyflat. No CPU gain follows
from counts or source simplification. Four quietVM jobs186.51s;8s rotated warmups,
five rounds/two processes per source/defaultGC/tiering:

| Warm complete script | Elapsed change | Wider process CPU | Ref/candidate spread |
| --- | ---: | ---: | ---: |
| Original text |−0.50..+1.16%|−0.96..+1.31%|1.32/0.34%|
| Helper-list text |−4.20..+1.14%|−3.69..+1.01%|1.36/4.16%|
| Floating |−7.09..+9.04%|−6.70..+7.82%|12.79/4.05%|
| Positional calls |+0.04..+2.36%|−0.47..+2.47%|1.27/1.04%|

Identical floating reference processes disagree12.79% despite stable individual
samples; helper candidate processes disagree4.16%. CPU conclusions remain uncertain.
Do not select a favorable process or treat this as a failed design. One changed-
source refinement validates the existing StoreLocal case first, reducing branch/
return duplication and exposing the opcode fact before its checked LocalSlot
getter. That is a code-shape hypothesis, not an attribution of these timings.
Rebuild/focus/freeze and make one bounded affected/control comparison; preserve
these original conditions, no subtraction between different source collections.

All users joined, quiet/image/golden/exit/SHAarchive/fixture cleanup pass. First
space-floor refusal occurred before any mutation/launch and remains recorded.
Only exact committed historical ae389 and observation replicas retired with fresh
path/UID/hash/link/all-alias proof. Current2ede/a71images/catalogs/toolchains and
unmatched evidence preserved;254/252MiBguards intact. Normal adapter0.4unchanged,
publication postponed; wider roadmap active.

[Decision](initial-decision.json),[summary](summary.json),[IR facts](result-consumer-facts.json),
[raw](observations.tgz),[source](candidate-sources.tar.xz),[patch](prototype.patch.gz),
[checks/procedures](procedures-and-checks.tar.xz).
''',encoding='utf-8',newline='\n')
with(repo/'benchmarks/EXPERIMENTS.md').open('a',encoding='utf-8',newline='\n')as f:f.write('''

R516/B944 [initial discarded-call source pair](results/2026-11-18-discarded-call-results/initial/README.md), private70f1ddf9 versus focuseda71abfed: existing result-consumer extent generalizes to discards, no new opcode/owner/framework, ordinary publication/materialization/PopTop hot dispatch removed; real cleanup continuation retained. Both targets121internal/78public/13goldens/reuse/actual4case32files pass; allocation/peaksflat. Helper−4.20..+1.14%elapsed/CPUstraddleszero, floatingreference12.79%process disagreement/candidate4.05%, individualsamplesstable; originalnearparity/callsuncertain. No consistent CPU conclusion. One changed-source StoreLocal-first/code-shape refinement selected, no causal attribution/percent veto. Prestagefloorrefusal before mutation preserved; exact archivedhistoricalae389/observationreplicas onlyretired, current2ede/a71 preserved. Quiet/join/SHA/guards pass, publicationheld.
''')
print('Initial prototype/uncertain/adverse controls preserved separately; changed-source refinement selected, no CPU claim.')
