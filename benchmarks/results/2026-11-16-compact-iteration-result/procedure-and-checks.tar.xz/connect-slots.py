from pathlib import Path
w=Path('D:/code/Lython/.git/agent-worktrees/iteration-result-r448/src/Lokad.Lython/Runtime')
def edit(name,a,b):
 p=w/name;s=p.read_text(encoding='utf-8');assert a in s,name;p.write_text(s.replace(a,b),encoding='utf-8',newline='\n')
edit('Protocols/IPyIterableValue.cs','''    internal readonly bool TryGetInteger(out long value) => _value.TryGetInteger(out value);''','''    internal readonly bool TryGetInteger(out long value) => _value.TryGetInteger(out value);

    internal LythonRuntime.ExecutableSlot TakeSlotValue()
    {
        var value = _value;
        _value = default;
        return value;
    }''')
edit('PyItertools.cs','''        => ValueTask.FromResult<PyIterationResult>(
            (TryMoveNext() is { HasValue: true, Value: var value })
                ? PyIterationResult.Yield(value)
                : PyIterationResult.End);''','''        => new(TryMoveNext());''')
edit('PyIteration.cs','''                cursor._syncEnumerator = outer.Sequence.GetEnumerator();''','''                if (cursor._iterator is null) cursor._syncEnumerator = outer.Sequence.GetEnumerator();''')
edit('PyIteration.cs','''                else if (outer.AsyncSequence is not null)''','''                else if (cursor._iterator is not IPyAsyncIteratorValue && outer.AsyncSequence is not null)''')
p=w/'PyIteration.cs';s=p.read_text(encoding='utf-8');a=s.index('        internal bool TryMoveNextInteger(');b=s.index('        private PyIterationResult TryMoveNextCore()',a);s=s[:a]+s[b:];p.write_text(s,encoding='utf-8',newline='\n')
edit('LythonRuntime.Executable.cs','''                    if (!cursor.TryMoveNextInteger(out hasValue, out var integer))
                    {
                        next = default;
                        return false;
                    }
                    next = hasValue ? ExecutableSlot.FromInteger(integer) : default;
                    return true;''','''                    result = cursor.TryMoveNext();
                    break;''')
edit('LythonRuntime.Executable.cs','''            next = hasValue ? ExecutableSlot.FromObject(result.Value) : default;''','''            next = hasValue ? result.TakeSlotValue() : default;''')
p=w/'LythonRuntime.Executable.NativePrefix.cs';s=p.read_text(encoding='utf-8');a=s.index('                    case ExecutableOpCode.ForNext:');b=s.index('                    case ExecutableOpCode.MakeTuple:',a)
s=s[:a]+'''                    case ExecutableOpCode.ForNext:
                    {
                        var iterator = Values[instruction.InputStart].Object.RequireNotNull();
                        var next = iterator is PyStringOps.CasedWhitespaceIteration words ? words.MoveNext()
                            : ((PyIteration.Cursor)iterator).TryMoveNext();
                        if (!next.HasValue)
                        {
                            Trim(instruction.InputStart);
                            Index = instruction.TargetIndex;
                            continue;
                        }
                        Publish(instruction, next.TakeSlotValue());
                        break;
                    }
'''+s[b:];p.write_text(s,encoding='utf-8',newline='\n')
edit('LythonRuntime.Executable.Interpreter.cs','''            if (!(iterator.TryMoveNext() is { HasValue: true, Value: var value }))''','''            var next = iterator.TryMoveNext();
            if (!next.HasValue)''')
edit('LythonRuntime.Executable.Interpreter.cs','''            PublishInstructionResult(instruction, value);
            return false;
        }

        private void ExecuteValueOperation''','''            PublishInstructionResult(instruction, next.TakeSlotValue());
            return false;
        }

        private void ExecuteValueOperation''')
edit('LythonRuntime.Executable.Interpreter.Async.cs','''                PublishInstructionResult(instruction, next.Value);''','''                PublishInstructionResult(instruction, next.TakeSlotValue());''')
print('Single native result transports scalar slots through cursors and both executable paths; old range-only integer pull deleted.')
