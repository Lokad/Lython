from pathlib import Path
import re
w=Path('D:/code/Lython/.git/agent-worktrees/iteration-result-r448')
for p in (w/'tests').rglob('*.cs'):
 if {'bin','obj'}&set(p.parts):continue
 s=p.read_text(encoding='utf-8');original=s
 pattern=r'(?m)^(\s*)Assert.True\(\(([^\n]+\.TryMoveNext\(\)) is \{ HasValue: true, Value: var (\w+) \}\)\);'
 def bind(m):
  indent,call,name=m.groups();temporary='next'+name[0].upper()+name[1:]
  return f'{indent}var {temporary} = {call};\n{indent}Assert.True({temporary}.HasValue);\n{indent}var {name} = {temporary}.Value;'
 s=re.sub(pattern,bind,s)
 s=re.sub(r'(?m)^(\s*(?:else\s+|if\s*\(!asynchronous\)\s+)?)([\w.]+\.TryMoveNext\(\))\.HasValue;',r'\1\2;',s)
 if s!=original:p.write_text(s,encoding='utf-8',newline='\n')
p=w/'src/Lokad.Lython/Runtime/LythonRuntime.BuiltinIterables.Aggregates.cs';s=p.read_text(encoding='utf-8')
a=s.index('        var sequence = ToSequence(arguments[0], span, context);',s.index('    private static object Sum('));b=s.index('\n        return sum.Result;',a)
s=s[:a]+'''        using var cursor = PyIteration.Cursor.Create(arguments[0], span, context);
        ValidateSumStart(total, span);
        var sum = new SumState(total);
        while (true)
        {
            var next = cursor.TryMoveNext();
            if (!next.HasValue) break;
            if (sum.TryAddResult(ref next)) continue;
            var item = next.Value;
            var result = sum.Total is PyInstance || item is PyInstance
                ? EvaluateBinaryOperator(BinaryOperatorSyntax.Add, sum.Total, item, context, span)
                : EvaluateAdd(sum.Total, item, context, span);
            sum.CompleteAddition(item, result);
        }'''+s[b:]
s=s.replace('''                if (sum.TryAddNumber(item.Value)) continue;
                var result = sum.Total is PyInstance || item.Value is PyInstance
                    ? await EvaluateBinaryOperatorAsync(BinaryOperatorSyntax.Add, sum.Total, item.Value, context, span).ConfigureAwait(false)
                    : EvaluateAdd(sum.Total, item.Value, context, span);
                sum.CompleteAddition(item.Value, result);''','''                if (sum.TryAddResult(ref item)) continue;
                var value = item.Value;
                var result = sum.Total is PyInstance || value is PyInstance
                    ? await EvaluateBinaryOperatorAsync(BinaryOperatorSyntax.Add, sum.Total, value, context, span).ConfigureAwait(false)
                    : EvaluateAdd(sum.Total, value, context, span);
                sum.CompleteAddition(value, result);''')
needle='''        internal bool TryAddNumber(object item)
''';assert needle in s
s=s.replace(needle,'''        internal bool TryAddResult(ref PyIterationResult item)
        {
            if (_phase == SumPhase.General) return false;
            return item.TryGetInteger(out var integer) ? TryAddInteger(integer) : TryAddNumber(item.Value);
        }

        private bool TryAddInteger(long integer)
        {
            if (_phase == SumPhase.Float)
            {
                // Python 3.13 adds small integers without compensating them.
                _floating += integer;
                _numericAddition = true;
                return true;
            }
            try
            {
                _integer = checked(_integer + integer);
                _numericAddition = true;
                return true;
            }
            catch (OverflowException)
            {
                // Exact promotion uses the same guarded general addition.
                Total = Result;
                _numericAddition = false;
                return false;
            }
        }

'''+needle)
a=s.index('''                if (TryInt64(item, out var integer))\n''',s.index(needle));b=s.index('''                // At most 64 bits:''',a)
s=s[:a]+'''                if (TryInt64(item, out var integer)) return TryAddInteger(integer);
'''+s[b:]
a=s.index('''            if (TryInt64(item, out var small))''',s.index(needle));b=s.index('''            // A genuine general addition''',a)
s=s[:a]+'''            if (TryInt64(item, out var small)) return TryAddInteger(small);

'''+s[b:]
p.write_text(s,encoding='utf-8',newline='\n')
print('Shared native sum consumes compact results; general callbacks observe a canonical object once. Test assertions preserved with explicit result locals.')
