from pathlib import Path
import hashlib,json,os,subprocess
r=Path(__file__).resolve().parent;w=Path('D:/code/Lython/.git/agent-worktrees/iteration-result-r448');sdk='C:/Users/JoannesVermorel/.dotnet11';env=dict(os.environ,DOTNET_ROOT=sdk,DOTNET_ROOT_X64=sdk)
with(r/'layout-both-corrected-build.log').open('w',encoding='utf-8')as log:
 p=subprocess.run([sdk+'/dotnet.exe','build',str(r/'Layout.csproj'),'-c','Release'],env=env,stdout=log,stderr=subprocess.STDOUT,timeout=60)
assert p.returncode==0,(r/'layout-both-corrected-build.log').read_text(encoding='utf-8')[-1500:]
for tfm in ['net11.0','net10.0']:
 p=subprocess.run([sdk+'/dotnet.exe',str(r/'bin/Release'/tfm/'Layout.dll'),str(w/'src/Lokad.Lython/bin/Release'/tfm/'Lokad.Lython.dll')],env=env,capture_output=True,text=True,encoding='utf-8',timeout=30)
 assert p.returncode==0,p.stderr
 data=json.loads(p.stdout);assert all(x['measuredStrideBytes']==16 for x in data['rows']);assert tfm.removeprefix('net').split('.')[0]in data['framework']
 (r/('layout-candidate-'+tfm+'.json')).write_text(p.stdout,encoding='utf-8');print(tfm,data['framework'],'stride',data['rows'][0]['measuredStrideBytes'])
identity=json.loads((r/'frozen/identity.json').read_text(encoding='utf-8'))
for role,files in identity['imageFiles'].items():
 for n,h in files.items():assert hashlib.sha256((r/'frozen'/role/n).read_bytes()).hexdigest()==h
print('Frozen full images verified; actual Windows .NET 11/10 compact-result strides confirmed.')
