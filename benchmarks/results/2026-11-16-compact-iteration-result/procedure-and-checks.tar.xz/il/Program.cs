using System.Reflection.Metadata;
using System.Reflection.PortableExecutable;
using System.Security.Cryptography;
using System.Text.Json;
static Dictionary<string,string> Read(string path)
{
 using var file=File.OpenRead(path);using var pe=new PEReader(file);var m=pe.GetMetadataReader();
 string Type(TypeDefinitionHandle h) {var t=m.GetTypeDefinition(h);var p=t.GetDeclaringType();return (p.IsNil?m.GetString(t.Namespace):Type(p))+"."+m.GetString(t.Name);}
 var result=new Dictionary<string,string>();
 foreach(var h in m.MethodDefinitions){var d=m.GetMethodDefinition(h);if(d.RelativeVirtualAddress==0)continue;var b=pe.GetMethodBody(d.RelativeVirtualAddress);var name=Type(d.GetDeclaringType())+"."+m.GetString(d.Name)+"#"+Convert.ToHexString(m.GetBlobBytes(d.Signature));result.Add(name,Convert.ToHexString(SHA256.HashData(b.GetILBytes()!)));}
 return result;
}
var a=Read(args[0]);var b=Read(args[1]);var names=a.Keys.Union(b.Keys).Where(n=>a.GetValueOrDefault(n)!=b.GetValueOrDefault(n)).ToArray();Console.WriteLine(JsonSerializer.Serialize(new{methodILOnly=true,referenceMethods=a.Count,candidateMethods=b.Count,differentMethods=names,binaryEqualityInferred=false},new JsonSerializerOptions{WriteIndented=true}));
