from pathlib import Path
import base64,copy,hashlib,importlib.util,json,subprocess,tempfile
r=Path(__file__).resolve().parent;repo=Path('D:/code/Lython');sha=lambda b:hashlib.sha256(b).hexdigest()
all_cases=json.loads((r.parent/'generated-scripts-r444/all-catalog.json').read_text(encoding='utf-8'))
numeric=next(c for c in all_cases['cases']if c['id']=='scripts.numeric-report.integer.large')
source='''import json

def squared_error(planned, actual):
    difference = actual - planned
    return difference * difference

with open('numbers.json') as source:
    data = json.load(source)
count = len(data['planned'])
planned = sum(data['planned'])
actual = sum(data['actual'])
error = sum(squared_error(data['planned'][index], data['actual'][index])
            for index in range(count))
report = {'count': count, 'planned': planned, 'actual': actual,
          'variance': actual - planned, 'squared_error': error}
with open('report.json', 'w', newline='') as target:
    json.dump(report, target, sort_keys=True, separators=(',', ':'))
    target.write('\\n')
print(count)
'''
fixture=json.loads(numeric['fixtureJson']);assert fixture['size']==4096 and 'text'in fixture
with tempfile.TemporaryDirectory(prefix='lython-squared-error-golden-')as folder:
 root=Path(folder)
 for name,encoded in fixture['inputFiles'].items():
  p=root/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(base64.b64decode(encoded))
 p=subprocess.run(['C:/Python313/python.exe','-I','-S','-X','utf8','-c',source],cwd=root,capture_output=True,timeout=15)
 assert p.returncode==0 and not p.stderr,p.stderr
 outputs={name:(root/name).read_bytes()for name in fixture['outputFiles']}
 fixture['outputFiles']={name:base64.b64encode(data).decode()for name,data in outputs.items()}
 expected=p.stdout.decode('utf-8').replace('\r\n','\n');assert expected=='4096\n',repr(expected)
spec=importlib.util.spec_from_file_location('protocol',repo/'benchmarks/cpython-worker.py');protocol=importlib.util.module_from_spec(spec);spec.loader.exec_module(protocol)
prepared=copy.deepcopy(numeric);prepared.update(id='scripts.numeric-squared-error.large',source=source,sourceSha256=sha(source.encode()),fixtureJson=json.dumps(fixture,ensure_ascii=False,separators=(',',':')),expectedOutput=expected,expectedOutputSha256=sha(expected.encode()),expectedFilesSha256=protocol.file_digest(outputs),runAsync=False)
prepared['fixtureSha256']=sha(prepared['fixtureJson'].encode())
async_case=copy.deepcopy(prepared);async_case.update(id='scripts.numeric-squared-error.async',runAsync=True)
old=json.loads((r.parent/'generator-stage-r445/quiet/representative.json').read_text(encoding='utf-8'))
normal=next(c for c in old['cases']if c['id']=='scripts.text-normalization.large');calls=next(c for c in old['cases']if c['id']=='calls.positional.large')
catalog=copy.deepcopy(all_cases);catalog['cases']=[prepared,async_case,numeric,normal,calls]
raw=(json.dumps(catalog,ensure_ascii=False,indent=2)+'\n').encode();(r/'catalog.json').write_bytes(raw)
for c in catalog['cases']:
 for key,field in [('sourceSha256','source'),('fixtureSha256','fixtureJson'),('expectedOutputSha256','expectedOutput')]:assert sha(c[field].encode())==c[key]
 f=json.loads(c['fixtureJson']);assert f['size']==c['size']and'text'in f
 protocol.file_fixture(f)
receipt=dict(catalogSHA256=sha(raw),cases=[c['id']for c in catalog['cases']],affectedInputBytes=sum(len(base64.b64decode(data))for data in fixture['inputFiles'].values()),sourceUtf8Bytes=len(source.encode()),expectedOutput=expected,expectedFilesSha256=prepared['expectedFilesSha256'],independentCPythonGoldens=True,existingNumericFixtureReused=True,newBenchmarkFramework=False)
(r/'catalog-preparation.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8');print(json.dumps(receipt))
