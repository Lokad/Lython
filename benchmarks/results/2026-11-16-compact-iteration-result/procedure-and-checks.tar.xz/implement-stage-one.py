from pathlib import Path
w=Path('D:/code/Lython/.git/agent-worktrees/iteration-result-r448')
def edit(name,a,b):
 p=w/name;s=p.read_text(encoding='utf-8');assert a in s,name;p.write_text(s.replace(a,b),encoding='utf-8',newline='\n')
p=w/'src/Lokad.Lython/Runtime/Protocols/IPyIterableValue.cs';s=p.read_text(encoding='utf-8');a=s.index('internal readonly struct PyIterationResult');b=s.index('\ninternal interface IPyIterableValue',a)
s=s[:a]+'''// Like an executable operand, an unpublished scalar moves privately until its
// object identity is observed. Exhaustion uses the existing unassigned slot;
// guest None remains the ordinary non-null PyNone singleton.
internal struct PyIterationResult
{
    private LythonRuntime.ExecutableSlot _value;

    private PyIterationResult(LythonRuntime.ExecutableSlot value) => _value = value;

    public static PyIterationResult End => default;

    public static PyIterationResult Yield(object value)
    {
        ArgumentNullException.ThrowIfNull(value);
        return new(LythonRuntime.ExecutableSlot.FromObject(value));
    }

    internal static PyIterationResult Yield(LythonRuntime.ExecutableSlot value)
        => new(value);

    public readonly bool HasValue => !_value.IsUnassigned;

    internal readonly bool TryGetInteger(out long value) => _value.TryGetInteger(out value);

    // Observe through the owning local before passing an object to Python or
    // making an observable alias. The slot then preserves its canonical box.
    public object Value => HasValue ? _value.Object.RequireNotNull()
        : throw new InvalidOperationException("An exhausted iterator has no value.");

    public void Deconstruct(out bool hasValue, out object value)
    {
        hasValue = HasValue;
        value = HasValue ? Value : PyNone.Instance;
    }
}
''' +s[b:];p.write_text(s,encoding='utf-8',newline='\n')
edit('src/Lokad.Lython/Runtime/LythonRuntime.Executable.Interpreter.cs','internal object YieldValue { get; private set; } = PyNone.Instance;','internal ExecutableSlot YieldValue { get; private set; }')
edit('src/Lokad.Lython/Runtime/LythonRuntime.Executable.Interpreter.cs','YieldValue = PyNone.Instance;','YieldValue = default;')
edit('src/Lokad.Lython/Runtime/LythonRuntime.Executable.Interpreter.cs','        internal bool HasYield { get; private set; }','''        internal ExecutableSlot TakeYieldValue()
        {
            var value = YieldValue;
            YieldValue = default;
            return value;
        }

        internal bool HasYield { get; private set; }''')
edit('src/Lokad.Lython/Runtime/LythonRuntime.Executable.Interpreter.Async.cs','YieldValue = delegated.Value;','YieldValue = ExecutableSlot.FromObject(delegated.Value);')
edit('src/Lokad.Lython/Runtime/LythonRuntime.Executable.Interpreter.Dispatch.cs','invocation!.YieldValue = execution.Stack.TakeValue(instruction.InputStart, instruction.ResultSlot);','invocation!.YieldValue = execution.Stack.TakeSlotValue(instruction.InputStart, instruction.ResultSlot);')
edit('src/Lokad.Lython/Runtime/LythonRuntime.Generators.cs','if (frame.HasYield) return PyIterationResult.Yield(frame.YieldValue);','if (frame.HasYield) return PyIterationResult.Yield(frame.TakeYieldValue());')
print('Private stage one: compact result payload and move-only yield slot; synchronous protocol migration remains pending.')
