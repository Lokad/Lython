from pathlib import Path
import ast,hashlib,io,json,shutil,tarfile
r=Path(__file__).resolve().parent;prior=r.parent/'generator-stage-r445/quiet';q=r/'quiet';q.mkdir(exist_ok=False);sha=lambda b:hashlib.sha256(b).hexdigest();frozen=json.loads((r/'frozen/identity.json').read_text(encoding='utf-8'))
catalog=(r/'catalog.json').read_bytes();(q/'representative.json').write_bytes(catalog)
jobs=[['scripts.numeric-squared-error.large',phase]for phase in ['compile','warm','compile-run']]+[['scripts.numeric-squared-error.async','warm'],['scripts.numeric-report.integer.large','warm'],['scripts.text-normalization.large','warm'],['calls.positional.large','warm']]
identity=dict(sourceRevision='Reference R445 cc794368/16c37b02 qualified43884041092; candidate R448 private d545a2ad exact sources frozen',purpose='Single compact sync/async native iteration-result protocol; full JSON squared-error report with helpers/generator, ordinary numeric/text/call controls. Compile,warm,fresh separate.',imageFiles=frozen['imageFiles'],coreSHA256={n:frozen['imageFiles']['candidate'if n.startswith('candidate')else'reference']['Lokad.Lython.dll']for n in ['reference','candidate','reference-control','candidate-control']},catalogSHA256=sha(catalog),catalogInitialization='Same fixed five-case catalog in every worker; existing numeric-report fixture/source controls reused.',publicationHeld=True)
(q/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8')
s=(prior/'collect.py').read_text(encoding='utf-8');a=s.index('jobs=');b=s.index('\nenv =',a);s=s[:a]+'jobs='+repr(jobs)+'\nassert len(jobs)==7 and all(case in cases for case,lane in jobs)\n'+s[b:];ast.parse(s);(q/'collect.py').write_text(s,encoding='utf-8',newline='\n')
s=(prior/'archive-owned.py').read_text(encoding='utf-8').replace("len(raw['jobs'])==5","len(raw['jobs'])==7").replace('jobs=5','jobs=7');ast.parse(s);(q/'archive-owned.py').write_text(s,encoding='utf-8',newline='\n')
s=(prior/'retrieve.py').read_text(encoding='utf-8').replace("['jobs']==5","['jobs']==7").replace('B848','B849');ast.parse(s);(q/'retrieve.py').write_text(s,encoding='utf-8',newline='\n')
root='/home/lokad/lython-bench-checks/iteration-result-b849-20261116';unit='lython-b849-iteration-result-20261116'
s=(prior/'run.sh').read_text(encoding='utf-8').replace('generator-consolidation-b848-20261116','iteration-result-b849-20261116')
probe='''DOTNET_ROOT=/home/lokad/lython-bench-toolchains/dotnet/11.0.100-rc.3.26522.148 /home/lokad/lython-bench-toolchains/dotnet/11.0.100-rc.3.26522.148/dotnet "$root/layout/Layout.dll" "$root/candidate/Lokad.Lython.dll" > "$root/layout-linux.json"
python3 -c 'import json,sys; x=json.load(open(sys.argv[1])); assert all(v["measuredStrideBytes"]==16 for v in x["rows"])' "$root/layout-linux.json"
'''
s=s.replace('python3 "$root/collect.py"',probe+'python3 "$root/collect.py"');(q/'run.sh').write_text(s,encoding='utf-8',newline='\n')
payload={n:(q/n).read_bytes()for n in ['identity.json','representative.json','collect.py','archive-owned.py','run.sh']};payload['candidate/Lokad.Lython.dll']=(r/'frozen/candidate/Lokad.Lython.dll').read_bytes()
for n in ['Layout.dll','Layout.deps.json','Layout.runtimeconfig.json']:payload['layout/'+n]=(r/'bin/Release/net11.0'/n).read_bytes()
with tarfile.open(q/'payload.tgz','w:gz')as t:
 for n,data in payload.items():m=tarfile.TarInfo(n);m.size=len(data);t.addfile(m,io.BytesIO(data))
proofs=json.loads((r/'retirement-proof.json').read_text(encoding='utf-8'));assert len(proofs)==3
c=dict(root=root,unit=unit,source='/home/lokad/lython-bench-checks/generator-consolidation-b848-20261116',sourceRole='candidate',sourceFiles=frozen['imageFiles']['reference'],sourceCatalogSHA256=json.loads((prior/'config.json').read_text(encoding='utf-8'))['catalogSHA256'],catalogSHA256=sha(catalog),identity=identity,retireGroups=[dict(paths=[v['path']],bytes=v['bytes'],links=v['links'],sha256=v['sha256'],canonical=v['canonical'],canonicalSHA256=v['canonicalSHA256'],member=v['member'],committedBlobVerified=True)for v in proofs],payloadBytes=(q/'payload.tgz').stat().st_size,payloadSHA256=sha((q/'payload.tgz').read_bytes()),unpackedBytes=sum(map(len,payload.values())))
(q/'config.json').write_text(json.dumps(c,indent=2)+'\n',encoding='utf-8')
s=(prior/'remote-launch.py').read_text(encoding='utf-8');a=s.index('c=');b=s.index('\nb=Path',a);s=s[:a]+'c='+repr(c)+s[b:];s=s.replace("source/'reference'","source/c['sourceRole']").replace('lython-b847-fixtures','lython-b849-fixtures');ast.parse(s);(q/'remote-launch.py').write_text(s,encoding='utf-8',newline='\n')
s=(r.parent/'generator-stage-r445/launch.py').read_text(encoding='utf-8').replace('Five-phase generator consolidation','Seven-job compact iteration transport').replace('200','220');ast.parse(s);(r/'launch.py').write_text(s,encoding='utf-8',newline='\n')
print(json.dumps(dict(jobs=jobs,catalogSHA256=sha(catalog),coreSHA256=identity['coreSHA256'],unpackedBytes=c['unpackedBytes'],retiredOnlyCommittedJSONBytes=sum(v['bytes']for v in proofs),sourceRole='candidate',noFrameworkChange=True)))
