using Microsoft.CodeAnalysis;
using Microsoft.CodeAnalysis.CSharp;
using Microsoft.CodeAnalysis.CSharp.Syntax;
using System.Text;
using System.Text.Json;

var root = Path.GetFullPath(args[0]);
if (args.Contains("--tidy") || args.Contains("--clean-results"))
{
    var count = 0;
    foreach (var folder in new[] { "src", "tests" })
        foreach (var path in Directory.GetFiles(Path.Combine(root, folder), "*.cs", SearchOption.AllDirectories)
            .Where(p => !p.Contains("/obj/") && !p.Contains("/bin/") && !p.Contains("\\obj\\") && !p.Contains("\\bin\\")))
        {
            var original = File.ReadAllText(path, Encoding.UTF8);
            var tree = CSharpSyntaxTree.ParseText(original, new CSharpParseOptions(LanguageVersion.Preview));
            var changed = (args.Contains("--clean-results") ? new CleanResults() : (CSharpSyntaxRewriter)new TidyResults()).Visit(tree.GetRoot())!.ToFullString();
            if (changed != original) { File.WriteAllText(path, changed, new UTF8Encoding(false)); count++; }
        }
    Console.WriteLine(JsonSerializer.Serialize(new { tidied = count }));
    return;
}
var write = args.Contains("--write");
var referenceRoot = Directory.GetDirectories("C:/Users/JoannesVermorel/.dotnet11/packs/Microsoft.NETCore.App.Ref")
    .Single(p => Path.GetFileName(p).StartsWith("11."));
var references = Directory.GetFiles(Path.Combine(referenceRoot, "ref/net11.0"), "*.dll").Select(p => MetadataReference.CreateFromFile(p)).ToArray();
var groups = new[] { "src/Lokad.Lython", "tests/Lokad.Lython.Tests", "tests/Lokad.Lython.PublicApi.Tests", "tests/Lokad.Lython.WorkerFixture" };
var results = new List<object>();
foreach (var group in groups)
{
    var folder = Path.Combine(root, group);
    var files = Directory.GetFiles(folder, "*.cs", SearchOption.AllDirectories).Where(p => !p.Contains("/obj/") && !p.Contains("/bin/") && !p.Contains("\\obj\\") && !p.Contains("\\bin\\")).ToArray();
    var options = new CSharpParseOptions(LanguageVersion.Preview, preprocessorSymbols: ["NET", "NET11_0", "NETCOREAPP", "RELEASE"]);
    var trees = files.Select(p => CSharpSyntaxTree.ParseText(File.ReadAllText(p, Encoding.UTF8), options, p)).ToArray();
    var extra = CSharpSyntaxTree.ParseText("global using System; global using System.Collections.Generic; global using System.Linq; global using System.Threading; global using System.Threading.Tasks; global using System.IO;" + (group.StartsWith("tests/") ? " global using Xunit;" : ""), options);
    var assemblies = group.StartsWith("src/") ? references : references.Concat(Directory.GetFiles(Path.Combine(folder, "bin/Release/net11.0"), "*.dll").Select(p => MetadataReference.CreateFromFile(p))).ToArray();
    var name = group.EndsWith("Lokad.Lython.Tests") ? "Lokad.Lython.WhiteBox.Tests" : group.Split('/')[^1];
    var compilation = CSharpCompilation.Create(name, trees.Append(extra), assemblies, new CSharpCompilationOptions(OutputKind.DynamicallyLinkedLibrary, allowUnsafe: false));
    foreach (var tree in trees)
    {
        var rewriter = new ResultRewriter(compilation.GetSemanticModel(tree));
        var original = tree.GetRoot();
        var rewritten = rewriter.Visit(original)!;
        if (rewriter.Declarations != 0 || rewriter.Calls != 0 || rewriter.ExistingOut.Count != 0)
        {
            results.Add(new { path = Path.GetRelativePath(root, tree.FilePath), rewriter.Declarations, rewriter.Calls, remainingExistingOut = rewriter.ExistingOut });
            if (write) File.WriteAllText(tree.FilePath, rewritten.ToFullString(), new UTF8Encoding(false));
        }
    }
}

Console.WriteLine(JsonSerializer.Serialize(new { write, results }, new JsonSerializerOptions { WriteIndented = true }));

sealed class TidyResults : CSharpSyntaxRewriter
{
    private string? _value;
    public override SyntaxNode? VisitMethodDeclaration(MethodDeclarationSyntax node)
    {
        if (node.Identifier.ValueText != "TryMoveNext" || node.ReturnType.ToString() != "PyIterationResult" ||
            node.Body?.Statements.FirstOrDefault() is not LocalDeclarationStatementSyntax declaration ||
            declaration.Declaration.Type.ToString() is not ("object" or "object?")) return node;
        var previous = _value;
        _value = declaration.Declaration.Variables.Single().Identifier.ValueText;
        var body = (BlockSyntax)Visit(node.Body)!;
        if (body.DescendantNodes().OfType<IdentifierNameSyntax>().Any(n => n.Identifier.ValueText == _value))
        {
            var first = (LocalDeclarationStatementSyntax)body.Statements[0];
            first = first.WithDeclaration(first.Declaration.WithType(SyntaxFactory.ParseTypeName("object?").WithTriviaFrom(first.Declaration.Type)));
            body = body.WithStatements(body.Statements.Replace(body.Statements[0], first));
        }
        else body = body.WithStatements(body.Statements.RemoveAt(0));
        _value = previous;
        return node.WithBody(body);
    }
    public override SyntaxNode? VisitInvocationExpression(InvocationExpressionSyntax node)
        => _value is not null && node.Expression.ToString() == "PyIterationResult.Yield" && node.ArgumentList.Arguments is { Count: 1 } arguments &&
            arguments[0].Expression is IdentifierNameSyntax identifier && identifier.Identifier.ValueText == _value
            ? node.WithArgumentList(node.ArgumentList.WithArguments(SyntaxFactory.SingletonSeparatedList(arguments[0].WithExpression(SyntaxFactory.PostfixUnaryExpression(SyntaxKind.SuppressNullableWarningExpression, identifier)))))
            : base.VisitInvocationExpression(node);

    public override SyntaxNode? VisitBlock(BlockSyntax node)
    {
        var visited = (BlockSyntax)base.VisitBlock(node)!;
        if (_value is null) return visited;
        var statements = visited.Statements.ToList();
        for (var i = 0; i + 1 < statements.Count; i++)
        {
            if (statements[i] is not ExpressionStatementSyntax { Expression: AssignmentExpressionSyntax { Left: IdentifierNameSyntax name } assign } || name.Identifier.ValueText != _value ||
                statements[i + 1] is not ReturnStatementSyntax { Expression: { } returned } following) continue;
            if (returned is InvocationExpressionSyntax call && call.Expression.ToString() == "PyIterationResult.Yield" &&
                call.ArgumentList.Arguments.Count == 1 && call.ArgumentList.Arguments[0].Expression.ToString().TrimEnd('!') == _value)
            {
                statements[i] = following.WithExpression(call.WithArgumentList(call.ArgumentList.WithArguments(
                    SyntaxFactory.SingletonSeparatedList(SyntaxFactory.Argument(assign.Right))))).WithTriviaFrom(statements[i]);
                statements.RemoveAt(i + 1);
            }
            else if (returned.ToString() == "PyIterationResult.End" && assign.Right.ToString() is "PyNone.Instance" or "null")
            {
                statements[i] = following.WithTriviaFrom(statements[i]);
                statements.RemoveAt(i + 1);
            }
        }
        return visited.WithStatements(SyntaxFactory.List(statements));
    }
}

sealed class ResultRewriter(SemanticModel model) : CSharpSyntaxRewriter
{
    internal int Declarations, Calls;
    internal List<string> ExistingOut = [];
    private string? _outName;

    private bool IsTarget(InvocationExpressionSyntax call)
    {
        var name = call.Expression switch
        {
            MemberAccessExpressionSyntax member => member.Name.Identifier.ValueText,
            MemberBindingExpressionSyntax member => member.Name.Identifier.ValueText,
            IdentifierNameSyntax identifier => identifier.Identifier.ValueText,
            _ => null
        };
        if (name != "TryMoveNext" || call.ArgumentList.Arguments.Count != 1 ||
            !call.ArgumentList.Arguments[0].RefKindKeyword.IsKind(SyntaxKind.OutKeyword)) return false;
        var info = model.GetSymbolInfo(call);
        if (info.Symbol is null && info.CandidateSymbols.OfType<IMethodSymbol>().Any(m => m.Name == "TryMoveNext" && m.Parameters.Length == 0 && m.ReturnType.Name == "PyIterationResult")) return true;
        return (info.Symbol as IMethodSymbol) is { Name: "TryMoveNext", MethodKind: MethodKind.Ordinary,
            ReturnType.SpecialType: SpecialType.System_Boolean, Parameters.Length: 1 } method &&
            method.Parameters[0].RefKind == RefKind.Out && method.Parameters[0].Type.SpecialType == SpecialType.System_Object;
    }

    private static InvocationExpressionSyntax WithoutOut(InvocationExpressionSyntax call)
        => call.WithArgumentList(SyntaxFactory.ArgumentList());

    public override SyntaxNode? VisitMethodDeclaration(MethodDeclarationSyntax node)
    {
        if (node.Identifier.ValueText != "TryMoveNext" || node.ReturnType is not PredefinedTypeSyntax { Keyword.RawKind: (int)SyntaxKind.BoolKeyword } ||
            node.ParameterList.Parameters.Count != 1 || node.ParameterList.Parameters[0] is not { Type: PredefinedTypeSyntax { Keyword.RawKind: (int)SyntaxKind.ObjectKeyword } } parameter || !parameter.Modifiers.Any(SyntaxKind.OutKeyword))
            return base.VisitMethodDeclaration(node);
        Declarations++;
        var previous = _outName;
        _outName = parameter.Identifier.ValueText;
        var body = node.Body is not null ? (BlockSyntax)Visit(node.Body)! : node.ExpressionBody is not null
            ? SyntaxFactory.Block(SyntaxFactory.ReturnStatement(ResultExpression(node.ExpressionBody.Expression))) : null;
        if (body is not null && body.DescendantNodes().OfType<IdentifierNameSyntax>().Any(n => n.Identifier.ValueText == _outName))
        {
            var indentation = new string(' ', node.GetLocation().GetLineSpan().StartLinePosition.Character + 4);
            var declaration = SyntaxFactory.ParseStatement("object " + _outName + ";").WithLeadingTrivia(SyntaxFactory.Whitespace(indentation)).WithTrailingTrivia(SyntaxFactory.EndOfLine("\n"));
            body = body.WithStatements(body.Statements.Insert(0, declaration));
        }
        _outName = previous;
        return node.WithReturnType(SyntaxFactory.ParseTypeName("PyIterationResult").WithTriviaFrom(node.ReturnType))
            .WithParameterList(SyntaxFactory.ParameterList().WithTriviaFrom(node.ParameterList)).WithBody(body).WithExpressionBody(null)
            .WithSemicolonToken(body is null ? node.SemicolonToken : default);
    }

    private ExpressionSyntax ResultExpression(ExpressionSyntax expression)
    {
        if (expression.IsKind(SyntaxKind.TrueLiteralExpression)) return SyntaxFactory.ParseExpression("PyIterationResult.Yield(" + _outName + ")").WithTriviaFrom(expression);
        if (expression.IsKind(SyntaxKind.FalseLiteralExpression)) return SyntaxFactory.ParseExpression("PyIterationResult.End").WithTriviaFrom(expression);
        if (expression is InvocationExpressionSyntax call && IsTarget(call)) return WithoutOut(call);
        var condition = (ExpressionSyntax)Visit(expression)!;
        return SyntaxFactory.ParseExpression("(" + condition.ToString() + ") ? PyIterationResult.Yield(" + _outName + ") : PyIterationResult.End").WithTriviaFrom(expression);
    }

    public override SyntaxNode? VisitReturnStatement(ReturnStatementSyntax node)
        => _outName is not null && node.Expression is { } expression ? node.WithExpression(ResultExpression(expression)) : base.VisitReturnStatement(node);

    public override SyntaxNode? VisitSimpleLambdaExpression(SimpleLambdaExpressionSyntax node) => WithoutReturnRewrite(() => base.VisitSimpleLambdaExpression(node));
    public override SyntaxNode? VisitParenthesizedLambdaExpression(ParenthesizedLambdaExpressionSyntax node) => WithoutReturnRewrite(() => base.VisitParenthesizedLambdaExpression(node));
    public override SyntaxNode? VisitAnonymousMethodExpression(AnonymousMethodExpressionSyntax node) => WithoutReturnRewrite(() => base.VisitAnonymousMethodExpression(node));
    public override SyntaxNode? VisitLocalFunctionStatement(LocalFunctionStatementSyntax node) => WithoutReturnRewrite(() => base.VisitLocalFunctionStatement(node));
    private SyntaxNode? WithoutReturnRewrite(Func<SyntaxNode?> action)
    {
        var saved = _outName; _outName = null;
        try { return action(); } finally { _outName = saved; }
    }

    public override SyntaxNode? VisitInvocationExpression(InvocationExpressionSyntax node)
    {
        if (!IsTarget(node)) return base.VisitInvocationExpression(node);
        var argument = node.ArgumentList.Arguments[0];
        if (argument.Expression is DeclarationExpressionSyntax { Designation: SingleVariableDesignationSyntax variable })
        {
            Calls++;
            return SyntaxFactory.ParseExpression("(" + WithoutOut(node).ToString() + " is { HasValue: true, Value: var " + variable.Identifier.ValueText + " })").WithTriviaFrom(node);
        }
        if (argument.Expression is IdentifierNameSyntax { Identifier.ValueText: "_" })
        {
            Calls++;
            if (node.Parent is ExpressionStatementSyntax || node.Parent is LambdaExpressionSyntax lambda &&
                model.GetTypeInfo(lambda).ConvertedType is INamedTypeSymbol { DelegateInvokeMethod.ReturnsVoid: true }) return WithoutOut(node);
            return SyntaxFactory.ParseExpression(WithoutOut(node).ToString() + ".HasValue").WithTriviaFrom(node);
        }
        ExistingOut.Add(node.ToString());
        return node;
    }
}

sealed class CleanResults : CSharpSyntaxRewriter
{
    public override SyntaxNode? VisitMethodDeclaration(MethodDeclarationSyntax node)
    {
        if (node.Identifier.ValueText != "TryMoveNext" || node.ReturnType.ToString() != "PyIterationResult" ||
            node.Body?.Statements.FirstOrDefault() is not LocalDeclarationStatementSyntax declaration ||
            declaration.Declaration.Type.ToString() is not ("object" or "object?")) return node;
        var name = declaration.Declaration.Variables.Single().Identifier.ValueText;
        var body = node.Body;
        var redundant = body.DescendantNodes().OfType<ExpressionStatementSyntax>().Where(s =>
            s.Expression is AssignmentExpressionSyntax { Left: IdentifierNameSyntax id } assign &&
            id.Identifier.ValueText == name && assign.Right.ToString() is "PyNone.Instance" or "null").ToArray();
        body = body.RemoveNodes(redundant, SyntaxRemoveOptions.KeepExteriorTrivia)!;
        if (!body.DescendantNodes().OfType<IdentifierNameSyntax>().Any(n => n.Identifier.ValueText == name))
            body = body.WithStatements(body.Statements.RemoveAt(0));
        return node.WithBody(body);
    }
}
