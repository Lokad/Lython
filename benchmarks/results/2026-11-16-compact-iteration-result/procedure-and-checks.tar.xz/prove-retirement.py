from pathlib import Path
import hashlib,io,json,subprocess,tarfile
r=Path(__file__).resolve().parent;repo=Path('D:/code/Lython');sha=lambda b:hashlib.sha256(b).hexdigest()
inventory=json.loads((r/'vm-inventory.json').read_text(encoding='utf-8'))
want=['native-inputs-cpython-b598-20261112/confirmation/confirmation.json','dictionary-checkpoint-b590-20261111/confirmation/confirmation.json','captured-checkpoint-b584-20261111/confirmation/confirmation.json']
selected=[x for x in inventory['rows']if x['path']in want];assert len(selected)==3
archives=['2026-11-11-captured-helper-cpython-checkpoint','2026-11-11-dictionary-cpython-checkpoint','2026-11-12-native-inputs-cpython-checkpoint'];proofs=[]
for name in archives:
 p=repo/'benchmarks/results'/name/'observations.tgz';raw=p.read_bytes();assert raw==subprocess.check_output(['git','show','HEAD:'+p.relative_to(repo).as_posix()],cwd=repo)
 with tarfile.open(fileobj=io.BytesIO(raw))as t:
  for member in t.getmembers():
   if not member.isfile():continue
   for candidate in selected:
    if member.size==candidate['bytes']and sha(t.extractfile(member).read())==candidate['sha256']:
     proofs.append(dict(**candidate,canonical=p.relative_to(repo).as_posix(),canonicalSHA256=sha(raw),member=member.name,committedBlobVerified=True))
assert len(proofs)==3,proofs
(r/'retirement-proof.json').write_text(json.dumps(proofs,indent=2)+'\n',encoding='utf-8');print(json.dumps(dict(proofs=proofs,retiredBytes=sum(p['bytes']for p in proofs)),indent=2))
