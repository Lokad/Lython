from pathlib import Path
w=Path('D:/code/Lython/.git/agent-worktrees/iteration-result-r448')
def edit(name,a,b):
 p=w/'src/Lokad.Lython/Runtime'/name;s=p.read_text(encoding='utf-8');assert a in s,name;p.write_text(s.replace(a,b),encoding='utf-8',newline='\n')
p=w/'src/Lokad.Lython/Runtime/PyIteration.cs';s=p.read_text(encoding='utf-8')
a=s.index('        public PyIterationResult TryMoveNext()');b=s.index('\n        internal bool IsBuiltinRange',a)
s=s[:a]+'''        public PyIterationResult TryMoveNext()
        {
            CheckExecution();
            return TryMoveNextCore();
        }
'''+s[b:]
a=s.index('        private bool TryMoveNextCore(');b=s.index('\n        public ValueTask<PyIterationResult> TryMoveNextAsync()',a)
s=s[:a]+'''        private PyIterationResult TryMoveNextCore()
        {
            if (_disposed || _value is null) return PyIterationResult.End;
            if (_iterator is { } iterator) return iterator.TryMoveNext();

            if (_syncEnumerator is null && _value is (PyList or PyTuple))
            {
                var next = AdvanceBuiltinSequence(_value, ref _sequencePosition);
                // A retained list cursor cannot revive after append at EOF.
                if (!next.HasValue) _disposed = true;
                return next;
            }

            _syncEnumerator ??= (_syncSource ??= GetSyncEnumerable(_value, _span)).GetEnumerator();
            if (_syncEnumerator is PyRange.Enumerator { HasMachineBounds: true } integers)
                return integers.MoveNext()
                    ? PyIterationResult.Yield(LythonRuntime.ExecutableSlot.FromInteger(integers.MachineValue))
                    : PyIterationResult.End;
            return _syncEnumerator.MoveNext() ? PyIterationResult.Yield(_syncEnumerator.Current) : PyIterationResult.End;
        }
'''+s[b:]
s=s.replace('''            return ValueTask.FromResult(TryMoveNextCore(out var syncValue)
                ? PyIterationResult.Yield(syncValue)
                : PyIterationResult.End);''','''            return ValueTask.FromResult(TryMoveNextCore());''')
p.write_text(s,encoding='utf-8',newline='\n')
edit('LythonRuntime.Generators.cs','''        public PyIterationResult TryMoveNext()
        {
            object value;
            var result = Advance(PyNone.Instance, null);
            value = result.HasValue ? result.Value : PyNone.Instance;
            return (result.HasValue) ? PyIterationResult.Yield(value) : PyIterationResult.End;
        }''','''        public PyIterationResult TryMoveNext() => Advance(PyNone.Instance, null);''')
edit('PyBuiltinIterators.cs','''        if (_source.TryMoveNext(out value))''','''        if (_source.TryMoveNext() is { HasValue: true, Value: var observed })''')
edit('PyBuiltinIterators.cs','''            value = LythonRuntime.RuntimeValue(value);''','''            value = LythonRuntime.RuntimeValue(observed);''')
edit('PyItertools.cs','''                if (_current.TryMoveNext(out value)) { value = LythonRuntime.RuntimeValue(value); return PyIterationResult.Yield(value); }''','''                var next = _current.TryMoveNext();
                if (next.HasValue) return next;''')
edit('LythonRuntime.CsvModule.cs','''                    moved = _cursor!.TryMoveNext(out current!);''','''                    var next = _cursor!.TryMoveNext();
                    moved = next.HasValue;
                    current = moved ? next.Value : PyNone.Instance;''')
edit('LythonRuntime.MathModule.cs','''                var pHas = (pCursor.TryMoveNext() is { HasValue: true, Value: var pItem });
                var qHas = (qCursor.TryMoveNext() is { HasValue: true, Value: var qItem });''','''                var pNext = pCursor.TryMoveNext();
                var qNext = qCursor.TryMoveNext();
                var pHas = pNext.HasValue;
                var qHas = qNext.HasValue;
                var pItem = pHas ? pNext.Value : PyNone.Instance;
                var qItem = qHas ? qNext.Value : PyNone.Instance;''')
print('Forwarded native generator/range results and repaired paired-pull definite assignment without compatibility overloads.')
