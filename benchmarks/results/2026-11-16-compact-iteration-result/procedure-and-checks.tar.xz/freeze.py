from pathlib import Path
import hashlib,io,json,os,shutil,subprocess,tarfile
r=Path(__file__).resolve().parent;repo=Path('D:/code/Lython');w=repo/'.git/agent-worktrees/iteration-result-r448';sha=lambda b:hashlib.sha256(b).hexdigest();sdk='C:/Users/JoannesVermorel/.dotnet11';env=dict(os.environ,DOTNET_ROOT=sdk,DOTNET_ROOT_X64=sdk)
paths=subprocess.check_output(['git','ls-files','src','tests','docs','Directory.Build.props','Directory.Build.targets','global.json'],cwd=w).decode().splitlines();paths+=[ 'tests/Lokad.Lython.PublicApi.Tests/IteratorScalarIdentityTests.cs' ];inputs={n:sha((w/n).read_bytes())for n in sorted(set(paths))if(w/n).is_file()}
with(r/'frozen-core-build.log').open('w',encoding='utf-8')as log:p=subprocess.run([sdk+'/dotnet.exe','build','src/Lokad.Lython/Lokad.Lython.csproj','-c','Release','--no-incremental'],cwd=w,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=120)
assert p.returncode==0,(r/'frozen-core-build.log').read_text(encoding='utf-8')[-2000:]
for n,h in inputs.items():assert sha((w/n).read_bytes())==h,n
f=r/'frozen';f.mkdir(exist_ok=False)
old=r.parent/'generator-stage-r445';prior=json.loads((old/'quiet/identity.json').read_text(encoding='utf-8'));reference=prior['imageFiles']['candidate']
for role in ['reference','candidate']:
 (f/role).mkdir()
 for n,h in reference.items():
  assert sha((old/'frozen/candidate'/n).read_bytes())==h,n
  shutil.copy2(old/'frozen/candidate'/n,f/role/n)
shutil.copy2(w/'src/Lokad.Lython/bin/Release/net11.0/Lokad.Lython.dll',f/'candidate/Lokad.Lython.dll')
images={role:{p.name:sha(p.read_bytes())for p in sorted((f/role).iterdir())if p.is_file()}for role in ['reference','candidate']}
assert images['reference']['Lokad.Lython.dll'].startswith('16c37b02')
assert [n for n in images['candidate']if images['candidate'][n]!=images['reference'][n]]==['Lokad.Lython.dll']
identity=dict(referenceSource='R445 cc794368,qualified43884041092; frozen16c37b02 text-source parity verified by delivery',candidateSource='R448 uncommitted compact iteration-result migration at d545a2ad',imageFiles=images,inputs=inputs,catalogSHA256=sha((r/'catalog.json').read_bytes()),productionChanges='One compact sync/async result protocol and native scalar transport through generator/range/cursor/sum; no new runtime dependency,policy or cache',normalAdapterPin='0.4.0',publicationHeld=True)
(f/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8')
with tarfile.open(r/'candidate-sources.tar.xz','w:xz')as t:
 for n in inputs:t.add(w/n,arcname=n)
for tfm in ['net11.0','net10.0']:
 with(r/('layout-build-'+tfm+'.log')).open('w',encoding='utf-8')as log:
  p=subprocess.run([sdk+'/dotnet.exe','build',str(r/'Layout.csproj'),'-c','Release','-p:TargetFramework='+tfm],cwd=repo,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=60)
 assert p.returncode==0,(r/('layout-build-'+tfm+'.log')).read_text(encoding='utf-8')[-1500:]
 p=subprocess.run([sdk+'/dotnet.exe',str(r/'bin/Release'/tfm/'Layout.dll'),str(w/'src/Lokad.Lython/bin/Release'/tfm/'Lokad.Lython.dll')],env=env,capture_output=True,text=True,encoding='utf-8',timeout=30)
 assert p.returncode==0,p.stderr
 data=json.loads(p.stdout);assert all(x['measuredStrideBytes']==16 for x in data['rows'])
 (r/('layout-candidate-'+tfm+'.json')).write_text(p.stdout,encoding='utf-8')
print(json.dumps(dict(candidateCoreSHA256=images['candidate']['Lokad.Lython.dll'],sourceInputs=len(inputs),fullImagesFrozen=True,layoutBothActualTargets=16,coreBuild='Nonincremental Release,both targets')))
