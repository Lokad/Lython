from pathlib import Path
import hashlib,json,os,shutil,statistics,subprocess,tempfile,time
r=Path(__file__).resolve().parent;d=r/'allocation-short';d.mkdir(exist_ok=False)
identity=json.loads((r/'quiet/identity.json').read_text(encoding='utf-8'));sdk='C:/Users/JoannesVermorel/.dotnet11';env=dict(os.environ);env['DOTNET_ROOT']=sdk;data={};images={};start=time.monotonic()
harness=r.parent/'cased-word-stream-r440/refined/allocation-short'
shutil.copy2(harness/'Program.cs',d/'Program.cs');shutil.copy2(harness/'Allocation.csproj',d/'Allocation.csproj');shutil.copy2(r/'quiet/representative.json',d/'catalog.json')
with tempfile.TemporaryDirectory(prefix='lython-generator-allocation-')as directory:
 env['TEMP']=directory;env['TMP']=directory
 for role in ['reference','candidate']:
  image=d/role;image.mkdir()
  for n,h in identity['imageFiles'][role].items():
   shutil.copy2(r/'frozen'/role/n,image/n);assert hashlib.sha256((image/n).read_bytes()).hexdigest()==h
  for p in(harness/'bin/Release/net11.0').glob('ValidatedAllocation.*'):shutil.copy2(p,image/p.name)
  images[role]={p.name:hashlib.sha256(p.read_bytes()).hexdigest()for p in image.iterdir()if p.is_file()}
  output=d/(role+'.json')
  with(d/(role+'.log')).open('w',encoding='utf-8')as log:p=subprocess.run([sdk+'/dotnet.exe',str(image/'ValidatedAllocation.dll'),str(image),str(d/'catalog.json'),str(output)],env=env,stdout=log,stderr=subprocess.STDOUT,timeout=60)
  assert p.returncode==0,(d/(role+'.log')).read_text(encoding='utf-8')[-2000:];data[role]=json.loads(output.read_text(encoding='utf-8'));print(role,'complete',flush=True)
 assert not list(Path(directory).iterdir())
rows=[]
for x in data['reference']['rows']:
 y=next(v for v in data['candidate']['rows']if v['id']==x['id']);a=statistics.median(x['allocatedBytesPerInvocation']);b=statistics.median(y['allocatedBytesPerInvocation']);rows.append(dict(case=x['id'],referenceBytes=a,candidateBytes=b,changePercent=100*(b/a-1),referencePeakExecutionBytes=x['peakExecutionMemoryBytes'],candidatePeakExecutionBytes=y['peakExecutionMemoryBytes']))
(d/'image-hashes.json').write_text(json.dumps(images,indent=2)+'\n',encoding='utf-8');(r/'allocation-summary.json').write_text(json.dumps(dict(rows=rows,complete=True,elapsedSeconds=time.monotonic()-start,allOutputAndFileGoldensPassed=True,budgetBaselineAndCleanupPassed=True,CPUorElapsedClaim=False,boundary='Existing local whole warm jobs with reset/mediated I/O/full stdout and file hashing/result cleanup; compilation/startup excluded. Natural-GC whole-process allocation counters. Governor execution peaks are conservative admission,not heap/RSS.'),indent=2)+'\n',encoding='utf-8');print(json.dumps(rows))
