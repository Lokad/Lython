using System.Reflection;
using System.Security.Cryptography;
using System.Text.Json;

var core = Path.GetFullPath(args[0]);
var assembly = Assembly.LoadFrom(core);
var types = new[] { "Lokad.Lython.Runtime.PyIterationResult", "Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot" }
    .Select(name => assembly.GetType(name, throwOnError: true)!).ToArray();
// Managed allocation deltas establish actual array strides without Unsafe,
// pointers, native layout assumptions, marshaling or forced collection.
foreach (var type in types)
    foreach (var count in new[] { 1024, 4096 }) GC.KeepAlive(Array.CreateInstance(type, count));
var rows = new List<object>();
foreach (var type in types)
{
    var sizes = new List<long>();
    foreach (var count in new[] { 1024, 4096 })
    {
        var before = GC.GetAllocatedBytesForCurrentThread();
        var values = Array.CreateInstance(type, count);
        var bytes = GC.GetAllocatedBytesForCurrentThread() - before;
        GC.KeepAlive(values);
        sizes.Add(bytes);
    }
    rows.Add(new { type = type.FullName, arrayCounts = new[] { 1024, 4096 }, allocatedBytes = sizes,
        measuredStrideBytes = (sizes[1] - sizes[0]) / (4096 - 1024),
        fields = type.GetFields(BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic).Select(f => new { name = f.Name, type = f.FieldType.FullName }).ToArray() });
}
Console.WriteLine(JsonSerializer.Serialize(new { framework = System.Runtime.InteropServices.RuntimeInformation.FrameworkDescription,
    coreSHA256 = Convert.ToHexStringLower(SHA256.HashData(File.ReadAllBytes(core))), rows,
    boundary = "Managed natural-GC array allocation stride only; no Lython speedup, portability or identity proof." }, new JsonSerializerOptions { WriteIndented = true }));
