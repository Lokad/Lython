from pathlib import Path
import json,subprocess
r=Path(__file__).resolve().parent
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
code='''from pathlib import Path
import fcntl,hashlib,json,os,shutil,subprocess
b=Path('/home/lokad/lython-bench-checks')
with(b/'comparison-vm.lock').open('a')as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record|[p]ython3.13.*cpython-worker.py'],capture_output=True).returncode==1
 assert not any(os.path.ismount(p)for p in b.glob('*/guest-fixtures'))
 rows=[]
 for root in b.iterdir():
  if not root.is_dir():continue
  for p in [root/'observations.tgz',root/'confirmation/confirmation.json']:
   if p.is_file()and p.stat().st_size>300000:
    v=p.stat();rows.append(dict(path=str(p.relative_to(b)),bytes=v.st_size,links=v.st_nlink,uid=v.st_uid,sha256=hashlib.sha256(p.read_bytes()).hexdigest()))
 print(json.dumps(dict(freeBytes=shutil.disk_usage(b).free,rows=sorted(rows,key=lambda x:-x['bytes']))))
'''
p=subprocess.run(ssh+['python3 -'],input=code,text=True,encoding='utf-8',capture_output=True,timeout=45)
assert p.returncode==0,p.stderr
(r/'vm-inventory.json').write_text(p.stdout,encoding='utf-8')
data=json.loads(p.stdout)
print(json.dumps(dict(freeBytes=data['freeBytes'],largest=data['rows'][:12]),indent=2))
