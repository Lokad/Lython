using System.Buffers;
using System.Globalization;
using Lokad.Lython.Frontend;
using System.Numerics;
using System.Text;
using Lokad.Lython.Runtime.Numbers;
using Lokad.Lython.Runtime.Text;

namespace Lokad.Lython.Runtime;

internal sealed partial class LythonRuntime
{
    private static object Any(object[] arguments, LythonSourceSpan span, ExecutionContext context)
    {
        if (arguments.Length != 1)
        {
            throw new LythonRuntimeException("TypeError", "any() takes exactly one argument (" + arguments.Length + " given)", span);
        }

        if (arguments[0] is PyBytes bytes) return RuntimeValue(ReduceBytesTruth(bytes, false, span, context));

        foreach (var item in ToSequence(arguments[0], span, context))
        {
            if (IsTruthy(item, context, span))
            {
                return RuntimeValue(true);
            }
        }

        return RuntimeValue(false);
    }

    private static ValueTask<object> AnyAsync(object[] arguments, LythonSourceSpan span, ExecutionContext context)
        => arguments.Length == 1 && arguments[0] is PyBytes or PyRange
            ? new(Any(arguments, span, context))
            : AnyGeneralAsync(arguments, span, context);

    private static async ValueTask<object> AnyGeneralAsync(object[] arguments, LythonSourceSpan span, ExecutionContext context)
    {
        if (arguments.Length != 1)
        {
            throw new LythonRuntimeException("TypeError", "any() takes exactly one argument (" + arguments.Length + " given)", span);
        }

        var cursor = await PyIteration.Cursor.CreateAsync(arguments[0], span, context).ConfigureAwait(false);
        await using (cursor.ConfigureAwait(false))
        {
            while (true)
            {
                var item = await cursor.TryMoveNextAsync().ConfigureAwait(false);
                if (!item.HasValue) return RuntimeValue(false);
                if (await IsTruthyAsync(item.Value, context, span).ConfigureAwait(false)) return RuntimeValue(true);
            }
        }
    }

    private static object All(object[] arguments, LythonSourceSpan span, ExecutionContext context)
    {
        if (arguments.Length != 1)
        {
            throw new LythonRuntimeException("TypeError", "all() takes exactly one argument (" + arguments.Length + " given)", span);
        }

        if (arguments[0] is PyBytes bytes) return RuntimeValue(ReduceBytesTruth(bytes, true, span, context));

        foreach (var item in ToSequence(arguments[0], span, context))
        {
            if (!IsTruthy(item, context, span))
            {
                return RuntimeValue(false);
            }
        }

        return RuntimeValue(true);
    }

    private static ValueTask<object> AllAsync(object[] arguments, LythonSourceSpan span, ExecutionContext context)
        => arguments.Length == 1 && arguments[0] is PyBytes or PyRange
            ? new(All(arguments, span, context))
            : AllGeneralAsync(arguments, span, context);

    private static async ValueTask<object> AllGeneralAsync(object[] arguments, LythonSourceSpan span, ExecutionContext context)
    {
        if (arguments.Length != 1)
        {
            throw new LythonRuntimeException("TypeError", "all() takes exactly one argument (" + arguments.Length + " given)", span);
        }

        var cursor = await PyIteration.Cursor.CreateAsync(arguments[0], span, context).ConfigureAwait(false);
        await using (cursor.ConfigureAwait(false))
        {
            while (true)
            {
                var item = await cursor.TryMoveNextAsync().ConfigureAwait(false);
                if (!item.HasValue) return RuntimeValue(true);
                if (!await IsTruthyAsync(item.Value, context, span).ConfigureAwait(false)) return RuntimeValue(false);
            }
        }
    }

    private static bool ReduceBytesTruth(PyBytes bytes, bool all, LythonSourceSpan span, ExecutionContext context)
    {
        var source = bytes.Bytes;
        for (var i = 0; ; i++)
        {
            // Match checked iteration, including the final unsuccessful pull.
            if ((i & 63) == 0) context.CheckExecution(span);
            if (i == source.Length) return all;
            if ((source[i] != 0) != all) return !all;
        }
    }

    private static object Sum(object[] arguments, LythonSourceSpan span, ExecutionContext context)
    {
        var total = ReadSumStart(arguments, span);
        if (TrySumExactBytes(arguments[0], total, span, context, out var byteResult)) return byteResult;
        using var cursor = PyIteration.Cursor.Create(arguments[0], span, context);
        ValidateSumStart(total, span);
        var sum = new SumState(total);
        while (true)
        {
            var next = cursor.TryMoveNext();
            if (!next.HasValue) break;
            if (sum.TryAddResult(ref next)) continue;
            var item = next.Value;
            var result = sum.Total is PyInstance || item is PyInstance
                ? EvaluateBinaryOperator(BinaryOperatorSyntax.Add, sum.Total, item, context, span)
                : EvaluateAdd(sum.Total, item, context, span);
            sum.CompleteAddition(item, result);
        }
        return sum.Result;
    }

    private static async ValueTask<object> SumAsync(object[] arguments, LythonSourceSpan span, ExecutionContext context)
    {
        var total = ReadSumStart(arguments, span);
        // Exact range items and integer addition cannot invoke guest protocols.
        // Reuse checked synchronous iteration; other starts may suspend in __add__.
        if (arguments[0] is PyRange && PyNumberOps.IsInteger(total)) return Sum(arguments, span, context);
        if (TrySumExactBytes(arguments[0], total, span, context, out var byteResult)) return byteResult;
        var cursor = await PyIteration.Cursor.CreateAsync(arguments[0], span, context).ConfigureAwait(false);
        var sum = new SumState(total);
        await using (cursor.ConfigureAwait(false))
        {
            ValidateSumStart(total, span);
            while (true)
            {
                var item = await cursor.TryMoveNextAsync().ConfigureAwait(false);
                if (!item.HasValue) break;
                if (sum.TryAddResult(ref item)) continue;
                var value = item.Value;
                var result = sum.Total is PyInstance || value is PyInstance
                    ? await EvaluateBinaryOperatorAsync(BinaryOperatorSyntax.Add, sum.Total, value, context, span).ConfigureAwait(false)
                    : EvaluateAdd(sum.Total, value, context, span);
                sum.CompleteAddition(value, result);
            }
        }
        return sum.Result;
    }

    // Numeric phases are shared by the existing sync/async loops. Fixed 64-bit
    // eligibility keeps rounding independent of the embedding platform's C long.
    private enum SumPhase { Integer, Float, General }

    private struct SumState
    {
        private SumPhase _phase;
        private double _correction;
        private long _integer;
        private double _floating;
        private bool _numericAddition;

        internal SumState(object start)
        {
            Total = start;
            _correction = 0;
            _integer = 0;
            _floating = 0;
            _numericAddition = false;
            if (start is double floating)
            {
                _floating = floating;
                _phase = SumPhase.Float;
            }
            else if (start is not bool && TryInt64(start, out _integer)) _phase = SumPhase.Integer;
            else _phase = SumPhase.General;
        }

        // Preserve the supplied start's identity until an addition happens.
        // During a native prefix, the running value lives only in scalar fields.
        internal object Total { get; private set; }

        internal readonly object Result
        {
            get
            {
                if (!_numericAddition) return Total;
                if (_phase == SumPhase.Integer) return new BigInteger(_integer);
                // Keep signed zero/nonfinite behavior when no finite correction
                // needs folding into the completed numeric prefix.
                return _correction != 0 && double.IsFinite(_correction)
                    ? _floating + _correction : _floating;
            }
        }

        internal bool TryAddResult(ref PyIterationResult item)
        {
            if (_phase == SumPhase.General) return false;
            return item.TryGetInteger(out var integer) ? TryAddInteger(integer) : TryAddNumber(item.Value);
        }

        private bool TryAddInteger(long integer)
        {
            if (_phase == SumPhase.Float)
            {
                // Python 3.13 adds small integers without compensating them.
                _floating += integer;
                _numericAddition = true;
                return true;
            }
            try
            {
                _integer = checked(_integer + integer);
                _numericAddition = true;
                return true;
            }
            catch (OverflowException)
            {
                // Exact promotion uses the same guarded general addition.
                Total = Result;
                _numericAddition = false;
                return false;
            }
        }

        internal bool TryAddNumber(object item)
        {
            if (_phase == SumPhase.Integer)
            {
                if (TryInt64(item, out var integer)) return TryAddInteger(integer);
                // At most 64 bits: materialization uses the existing minor-scalar
                // headroom. Substantial integer promotion keeps its preflight.
                Total = Result;
                _numericAddition = false;
                return false;
            }
            if (_phase != SumPhase.Float) return false;
            if (item is double value)
            {
                var previous = _floating;
                var next = previous + value;
                _correction += Math.Abs(previous) >= Math.Abs(value)
                    ? (previous - next) + value : (value - next) + previous;
                _floating = next;
                _numericAddition = true;
                return true;
            }
            if (TryInt64(item, out var small)) return TryAddInteger(small);

            // A genuine general addition sees the completed corrected prefix.
            // A later double result never restarts compensation from this phase.
            Total = Result;
            _numericAddition = false;
            _correction = 0;
            _phase = SumPhase.General;
            return false;
        }

        internal void CompleteAddition(object item, object result)
        {
            if (_phase == SumPhase.Integer)
            {
                if (result is double floating)
                {
                    _phase = SumPhase.Float;
                    _floating = floating;
                }
                else if (!(TryInt64(item, out _) && TryInt64(result, out _integer))) _phase = SumPhase.General;
            }
            Total = result;
            _numericAddition = false;
        }

        private static bool TryInt64(object value, out long result)
        {
            if (PyNumberOps.TryAsInteger(value, out var integer) && integer >= long.MinValue && integer <= long.MaxValue)
            {
                result = (long)integer;
                return true;
            }
            result = 0;
            return false;
        }
    }

    private static readonly Func<object, LythonSourceSpan, ExecutionContext, object> SumBytesOperation
        = static (bytes, span, context) => SumExactBytes((PyBytes)bytes, BigInteger.Zero, span, context);

    private static bool TrySumExactBytes(object value, object start, LythonSourceSpan span, ExecutionContext context, out object result)
    {
        result = start;
        if (value is not PyBytes bytes || !PyNumberOps.IsInteger(start)) return false;
        result = SumExactBytes(bytes, start, span, context);
        return true;
    }

    private static object SumExactBytes(PyBytes bytes, object start, LythonSourceSpan span, ExecutionContext context)
    {
        var result = start;
        var source = bytes.Bytes;
        long subtotal = 0;
        for (var i = 0; ; i++)
        {
            // Match checked iteration, including the final unsuccessful pull.
            if ((i & 63) == 0) context.CheckExecution(span);
            if (i == source.Length) break;
            // Even a maximum-length CLR byte array totals less than 2^39.
            subtotal += source[i];
        }
        if (source.Length != 0)
        {
            _ = PyNumberOps.TryAsInteger(start, out var initial);
            result = AddExactIntegers(initial, new BigInteger(subtotal), context.MemoryGovernor, span);
        }
        return result;
    }

    private static object ReadSumStart(object[] arguments, LythonSourceSpan span)
    {
        if (arguments.Length is < 1 or > 2)
        {
            throw new LythonRuntimeException("TypeError", "sum(iterable[, start]) expects one iterable and optional start argument.", span);
        }

        return arguments.Length == 2 ? arguments[1] : BigInteger.Zero;
    }

    private static void ValidateSumStart(object total, LythonSourceSpan span)
    {
        // CPython acquires the iterator before checking the start type, without
        // pulling an item. Acquisition effects/errors precede this rejection.
        if (PyStringOps.TryAsString(total, out _))
        {
            throw new LythonRuntimeException("TypeError", "sum() can't sum strings [use ''.join(seq) instead]", span);
        }

        if (total is PyBytes)
        {
            throw new LythonRuntimeException("TypeError", "sum() can't sum bytes [use b''.join(seq) instead]", span);
        }
    }

}
