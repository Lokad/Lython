set -eu
root=/home/lokad/lython-bench-checks/iteration-result-b849-20261116
trap 'result=$?; printf "%s\n" "$result" > "$root/exit-code.txt"' EXIT
DOTNET_ROOT=/home/lokad/lython-bench-toolchains/dotnet/11.0.100-rc.3.26522.148 /home/lokad/lython-bench-toolchains/dotnet/11.0.100-rc.3.26522.148/dotnet "$root/layout/Layout.dll" "$root/candidate/Lokad.Lython.dll" > "$root/layout-linux.json"
python3 -c 'import json,sys; x=json.load(open(sys.argv[1])); assert all(v["measuredStrideBytes"]==16 for v in x["rows"])' "$root/layout-linux.json"
python3 "$root/collect.py"
