from pathlib import Path
import ast
import gzip
import hashlib
import json
import shutil
import subprocess
import tarfile

lab = Path(__file__).resolve().parent
repo = Path.cwd()
prior = lab.parent / "csv-line-number-r550/quiet"
previous = json.loads((prior / "config.json").read_text(encoding="utf-8"))
read = lambda path: path.read_text(encoding="utf-8")
sha = lambda data: hashlib.sha256(data).hexdigest()
ssh = ["C:/Windows/System32/OpenSSH/ssh.exe", "-i", str(Path.home() / ".ssh/id_lython-bench.pem"),
       "-o", "BatchMode=yes", "-o", "ConnectTimeout=15", "lokad@20.166.121.73"]

def write(path, content):
    if path.suffix == ".py":
        ast.parse(content)
    path.write_text(content, encoding="utf-8", newline="\n")

proofs = []
for name, tag, expected in [
    ("2026-11-18-string-slice-ownership/comparison/candidate-core.dll.gz", "string-slices-b971-20261118", "f2824fea"),
]:
    canonical = "benchmarks/results/" + name
    archive = (repo / canonical).read_bytes()
    assert archive == subprocess.check_output(["git", "show", "HEAD:" + canonical], cwd=repo)
    raw = gzip.decompress(archive)
    assert sha(raw).startswith(expected)
    proofs.append(dict(kind="exact superseded compiled replica", canonical=canonical,
                       canonicalSHA256=sha(archive), member=None, sha256=sha(raw), bytes=len(raw),
                       anchor=tag + "/candidate/Lokad.Lython.dll", committedBlobVerified=True))

proof_source = """from pathlib import Path
import fcntl, hashlib, json, os, shutil, stat, subprocess
root = Path('/home/lokad/lython-bench-checks').resolve()
proofs = PROOFS
with (root / 'comparison-vm.lock').open('a') as lease:
    fcntl.flock(lease, fcntl.LOCK_EX | fcntl.LOCK_NB)
    assert subprocess.run(['pgrep', '-af', '[d]otnet.* --compare worker|[p]erf record|[p]ython3.*cpython-worker.py'],
                          capture_output=True).returncode == 1
    assert not any(os.path.ismount(path) for path in root.glob('*/guest-fixtures'))
    inodes = {}
    for proof in proofs:
        anchor = root / proof.pop('anchor')
        info = anchor.lstat()
        assert anchor.resolve() == anchor and stat.S_ISREG(info.st_mode) and info.st_uid == os.getuid()
        assert info.st_size == proof['bytes'] and hashlib.sha256(anchor.read_bytes()).hexdigest() == proof['sha256']
        proof.update(links=info.st_nlink, paths=[])
        inodes[info.st_dev, info.st_ino] = proof
    for base, _, names in os.walk(root):
        for name in names:
            path = Path(base) / name
            info = path.lstat()
            if (proof := inodes.get((info.st_dev, info.st_ino))) is not None:
                assert path.resolve() == path and stat.S_ISREG(info.st_mode) and info.st_uid == os.getuid()
                assert info.st_nlink == proof['links'] and info.st_size == proof['bytes']
                assert name == 'Lokad.Lython.dll'
                proof['paths'].append(str(path.relative_to(root)))
    for proof in proofs:
        assert len(proof['paths']) == proof['links']
        proof['paths'].sort()
    print(json.dumps(dict(freeBytes=shutil.disk_usage(root).free, choices=proofs)))
""".replace("PROOFS", repr(proofs))
write(lab / "replica-proof.py", proof_source)
response = subprocess.run(ssh + ["python3 -"], input=proof_source, text=True, encoding="utf-8",
                          capture_output=True, timeout=55)
write(lab / "space.log", response.stdout + response.stderr)
assert response.returncode == 0, response.stderr
space = json.loads(response.stdout)
write(lab / "space.json", json.dumps(space, indent=2) + "\n")
assert len(space["choices"]) == 1
for relative in space["choices"][0]["paths"]:
    assert relative.split("/")[0] in {
        "string-slices-b971-20261118", "native-encoder-b972-20261118",
        "json-encoder-frames-b974-20261118",
    }, relative
identity = json.loads(read(lab / "frozen-identity.json"))
assert len(identity["imageFiles"]["reference"]) == 32
assert identity["imageFiles"]["reference"] == previous["identity"]["imageFiles"]["candidate"]
assert all(sha((lab / "frozen" / role / name).read_bytes()) == digest
           for role, files in identity["imageFiles"].items() for name, digest in files.items())
identity["purpose"] = "Transfer consumed executable slots into private local bindings"
assert not (lab / "quiet").exists()
quiet = lab / "quiet"
quiet.mkdir()
root = "/home/lokad/lython-bench-checks/local-store-slot-b979-20261118"
unit = "lython-b979-local-store-slot-20261118"
jobs = [("scripts.csv-invoice.large", "warm"), ("scripts.csv-invoice.large", "compile-run"),
        ("scripts.csv-validated-records.large", "warm"), ("calls.positional.large", "warm")]
write(lab / "jobs.json", json.dumps(jobs, indent=2) + "\n")
collector = read(prior / "collect.py").replace("CSV line-number source pair", "Local-store slot source pair").replace("len(jobs)==5", "len(jobs)==4")
start, end = collector.index("\njobs = "), collector.index("\nassert len(jobs)")
collector = collector[:start] + "\njobs = " + repr(jobs) + collector[end:]
write(quiet / "collect.py", collector)
write(quiet / "archive-owned.py", read(prior / "archive-owned.py").replace("len(raw['jobs'])==5", "len(raw['jobs'])==4").replace("jobs=5,elapsedSeconds", "jobs=4,elapsedSeconds"))
write(quiet / "run.sh", read(prior / "run.sh").replace(previous["root"], root))
write(quiet / "identity.json", json.dumps(identity, indent=2) + "\n")
shutil.copyfile(lab / "representative.json", quiet / "representative.json")
members = ["collect.py", "archive-owned.py", "run.sh", "identity.json", "representative.json",
           "candidate/Lokad.Lython.dll"]
(quiet / "candidate").mkdir()
shutil.copyfile(lab / "frozen" / members[-1], quiet / members[-1])
with tarfile.open(quiet / "payload.tgz", "w:gz") as out:
    for name in members:
        out.add(quiet / name, arcname=name)
total = sum((quiet / name).stat().st_size for name in members)
available = space["freeBytes"]
retire = []
for proof in space["choices"]:
    if available > 254 * 1024 * 1024 + total + 131072:
        break
    retire.append(proof)
    available += proof["bytes"]
assert available > 254 * 1024 * 1024 + total + 131072, (available, total)
payload = quiet / "payload.tgz"
settings = dict(root=root, unit=unit, source=previous["root"], sourceRole="candidate",
                sourceFiles=identity["imageFiles"]["reference"],
                sourceCatalogSHA256=previous["catalogSHA256"], catalogSHA256=identity["catalogSHA256"],
                identity=identity, retireGroups=retire, payloadBytes=payload.stat().st_size,
                payloadSHA256=sha(payload.read_bytes()), unpackedBytes=total)
write(quiet / "config.json", json.dumps(settings, indent=2) + "\n")
launcher = read(prior / "remote-launch.py")
start, end = launcher.index("\nc=") + 1, launcher.index("\nb=Path(")
launcher = launcher[:start] + "c=" + repr(settings) + launcher[end:]
write(quiet / "remote-launch.py", launcher.replace("lython-b977-fixtures", "lython-b979-fixtures"))
original_launch = read(prior.parent / "launch.py").replace("CSV line-number source pair", "Local-store slot source pair").replace("len(jobs)==5", "len(jobs)==4")
write(lab / "launch.py", original_launch.replace("255","215"))
retrieve = read(prior / "retrieve.py").replace("corrected-config.json", "config.json")
retrieve = retrieve.replace("corrected-observe-not-before.json", "observe-not-before.json")
write(quiet / "retrieve.py", retrieve.replace("CSV line-number source pair", "Local-store slot source pair").replace("receipt']['jobs']==5", "receipt']['jobs']==4"))
write(lab / "summarize.py", read(prior.parent / "summarize.py").replace("len(raw['jobs'])==5","len(raw['jobs'])==4"))
print("Ready", total, "bytes and", len(retire), "exact historical replica groups", flush=True)

