using Lokad.Lython.Frontend;
using System.Text.Json;

var catalog = JsonDocument.Parse(File.ReadAllText(args[0]));
var results = new List<object>();
foreach (var item in catalog.RootElement.GetProperty("cases").EnumerateArray())
{
    var id = item.GetProperty("id").GetString();
    var parsed = LythonFrontend.Compile(item.GetProperty("source").GetString()!);
    var code = ExecutableScript.Compile(LoweredScript.Lower(parsed.Script!)).EntryPoint;
    results.Add(new { id, functions = Inspect(code) });
}
Console.WriteLine(JsonSerializer.Serialize(results, new JsonSerializerOptions { WriteIndented = true }));

static object Inspect(ExecutableCodeObject code) => new
{
    code.Name,
    code.FirstTemporarySlot,
    code.NativePrefixEnd,
    code.LocalNames,
    instructions = code.Instructions.Select((op, index) => new
    {
        index, opcode = op.OpCode.ToString(), op.InputStart, op.SecondInput, local = op.OpCode is ExecutableOpCode.LoadLocal or ExecutableOpCode.StoreLocal ? op.LocalSlot : (int?)null,
        op.ResultSlot, op.HasResultConsumer,
        callArguments = op.OpCode == ExecutableOpCode.Call ? code.CallSites[op.CallSiteIndex].ArgumentCount : (int?)null
    }).ToArray(),
    children = code.Functions.Select(function => Inspect(function.CodeObject)).ToArray()
};


