from pathlib import Path
import hashlib
import json
import os
import shutil
import subprocess
from concurrent.futures import ThreadPoolExecutor

repo = Path.cwd()
lab = repo / ".git/agent-notes/review-20261031/local-store-slot-r552"
donor = lab.parent / "csv-line-number-r550"
work = repo / ".git/agent-worktrees/directive-presence-r547"
sdk = Path.home() / ".dotnet11"
dotnet = sdk / "dotnet.exe"
env = dict(os.environ, DOTNET_ROOT=str(sdk), DOTNET_ROOT_X64=str(sdk),
           PATH=str(sdk) + os.pathsep + os.environ["PATH"])

def read(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))

def save(path, value):
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

for tf in ["net11.0", "net10.0"]:
    assert all("Passed!" in (lab / f"windows-{group}-{tf}.log").read_text(encoding="utf-8-sig")
               for group in ["white", "public"])
core = "Lokad.Lython.dll"
base = donor / "frozen/candidate"
manifest = read(donor / "frozen-identity.json")["imageFiles"]["candidate"]
assert len(manifest) == 32 and manifest[core].startswith("12643cec")
assert all(sha(base / name) == checksum for name, checksum in manifest.items())
candidate = work / "src/Lokad.Lython/bin/Release/net11.0" / core
assert sha(candidate) == sha(work / "benchmarks/Lokad.Lython.Benchmarks/bin/Release/net11.0" / core)
root_catalog = read(donor / "representative.json")
extra = read(lab.parent / "call-preparation-r242/b582/catalog.json")
ids = ["scripts.csv-invoice.large", "scripts.csv-validated-records.large", "calls.positional.large"]
available = {item["id"]: item for item in (extra["cases"] + root_catalog["cases"])}
root_catalog["cases"] = [available[name] for name in ids]
catalog = lab / "representative.json"
save(catalog, root_catalog)

def verify(entry):
    role, dll = entry
    image = lab / "frozen" / role
    image.mkdir(parents=True)
    for name in manifest:
        shutil.copyfile(dll if name == core else base / name, image / name)
    for file in base.glob("ValidatedAllocation.*"):
        shutil.copyfile(file, image / file.name)
    image_hashes = {name: sha(image / name) for name in manifest}
    assert image_hashes == manifest | {core: sha(dll)}
    with (lab / f"{role}-verification.log").open("w", encoding="utf-8") as log:
        subprocess.run([dotnet, image / "Lokad.Lython.Benchmarks.dll", "--compare", "verify",
                        "--catalog", catalog, "--dotnet", dotnet,
                        "--python", "C:/Python313/python.exe", "--python-worker", repo / "benchmarks/cpython-worker.py",
                        "--out", lab / f"{role}-verification.json"], env=env, cwd=repo, stdout=log,
                       stderr=subprocess.STDOUT, check=True, timeout=90)
    subprocess.run([dotnet, image / "ValidatedAllocation.dll", image, catalog, lab / f"{role}-allocation.json"],
                   env=env, cwd=repo, check=True, timeout=90)
    assert all(sha(image / name) == checksum for name, checksum in image_hashes.items())
    print(role, image_hashes[core], "three verified scripts and baseline reuse", flush=True)
    return role, image_hashes

with ThreadPoolExecutor(max_workers=2) as executor:
    images = dict(executor.map(verify, [("reference", base / core), ("candidate", candidate)]))
save(lab / "frozen-identity.json", dict(
    sourceRevision="c14c7c92b versus transfer of consumed scalar temporaries",
    imageFiles=images, catalogSHA256=sha(catalog), normalAdapterPin="0.4.0",
    coreSHA256={label: images[role][core] for role in images for label in (role, role + "-control")}))
(lab / "prototype.patch").write_bytes(subprocess.check_output(
    ["git", "-C", work, "diff", "--binary", "c14c7c92b", "--", "src", "tests"]))


