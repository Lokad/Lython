from pathlib import Path
import fcntl, hashlib, json, os, shutil, stat, subprocess
root = Path('/home/lokad/lython-bench-checks').resolve()
proofs = [{'kind': 'exact superseded compiled replica', 'canonical': 'benchmarks/results/2026-11-18-string-slice-ownership/comparison/candidate-core.dll.gz', 'canonicalSHA256': '6530af0df81e3834d8dc8b068313353fdecc65b85dde216ffea8e3ca5a7140a9', 'member': None, 'sha256': 'f2824fea08ecfff7d6aabf6e642a47ef5546ff156a402e10f6791df70a1d41ab', 'bytes': 5760000, 'anchor': 'string-slices-b971-20261118/candidate/Lokad.Lython.dll', 'committedBlobVerified': True}]
with (root / 'comparison-vm.lock').open('a') as lease:
    fcntl.flock(lease, fcntl.LOCK_EX | fcntl.LOCK_NB)
    assert subprocess.run(['pgrep', '-af', '[d]otnet.* --compare worker|[p]erf record|[p]ython3.*cpython-worker.py'],
                          capture_output=True).returncode == 1
    assert not any(os.path.ismount(path) for path in root.glob('*/guest-fixtures'))
    inodes = {}
    for proof in proofs:
        anchor = root / proof.pop('anchor')
        info = anchor.lstat()
        assert anchor.resolve() == anchor and stat.S_ISREG(info.st_mode) and info.st_uid == os.getuid()
        assert info.st_size == proof['bytes'] and hashlib.sha256(anchor.read_bytes()).hexdigest() == proof['sha256']
        proof.update(links=info.st_nlink, paths=[])
        inodes[info.st_dev, info.st_ino] = proof
    for base, _, names in os.walk(root):
        for name in names:
            path = Path(base) / name
            info = path.lstat()
            if (proof := inodes.get((info.st_dev, info.st_ino))) is not None:
                assert path.resolve() == path and stat.S_ISREG(info.st_mode) and info.st_uid == os.getuid()
                assert info.st_nlink == proof['links'] and info.st_size == proof['bytes']
                assert name == 'Lokad.Lython.dll'
                proof['paths'].append(str(path.relative_to(root)))
    for proof in proofs:
        assert len(proof['paths']) == proof['links']
        proof['paths'].sort()
    print(json.dumps(dict(freeBytes=shutil.disk_usage(root).free, choices=proofs)))
