from hashlib import sha256
from pathlib import Path
import json
import os
import shutil
import subprocess
import tarfile

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
notes = lab.parent
previous = notes / 'current-cpython-checkpoint-20261127'
donor = previous / 'comparison/quiet'
frozen = notes / 'private-compiler-slots-20261127/local'
quiet = lab / 'comparison/quiet'
image = quiet / 'candidate'
quiet.mkdir(parents=True)
def sha(path): return sha256(path.read_bytes()).hexdigest()
def read(path): return json.loads(path.read_text(encoding='utf-8-sig'))
def write(path,data): path.write_text(json.dumps(data,indent=2,ensure_ascii=False)+'\n',encoding='utf-8',newline='\n')
def manifest(path): return {file.name:sha(file) for file in path.iterdir()}
head = subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()
assert head.startswith('a1b3a3325')
assert not subprocess.check_output(['git','diff','HEAD','--','src','benchmarks/Lokad.Lython.Benchmarks'],cwd=repo)
pin = read(frozen / 'identity.json')
assert manifest(frozen / 'candidate') == pin['imageFiles']['candidate']
committed = subprocess.check_output(['git','diff','--binary','43aef0247',head,'--','src'],cwd=repo)
assert committed == (frozen/'candidate.patch').read_bytes()
assert sha256(committed).hexdigest() == pin['sourcePatchSHA256']
shutil.copytree(frozen/'candidate',image)
core = 'Lokad.Lython.dll'
files = manifest(image)
prior = read(donor/'identity.json')
old_files = prior['imageFiles']['candidate']
assert len(files)==len(old_files)==32 and set(files)==set(old_files)
overlay = sorted(name for name,digest in files.items() if old_files[name]!=digest)
assert overlay == [core]
donor_name = Path(prior['frozenImage']).parent.name
donor_archive = read(donor/'terminal-status.json')['receipt']['archiveSHA256']
assert sha(donor/'observations.tar.xz') == donor_archive
root = 'current-cpython-b1844-20261127'
paths = [frozen/'representative.json',
         notes/'nested-json-layouts-20261127/local/representative.json',
         notes/'iterable-csv-records-20261127/local/representative.json',
         notes/'converted-entry-20261127/local/representative.json']
available = {row['id']:row for path in paths for row in read(path)['cases']}
jobs = [
    ['diagnostic.shipment-starmap-wide-lists','warm-async'],
    ['diagnostic.nested-json-document','warm'],
    ['diagnostic.csv-summary-list-input','warm'],
    ['diagnostic.generated-ordinary-definitions','compile'],
    ['diagnostic.nested-json-lines','warm-async'],
    ['diagnostic.csv-summary-iterator-input','warm-async'],
    ['diagnostic.generated-guarded-report','compile'],
    ['diagnostic.generated-guarded-report','compile-run'],
]
catalog = read(paths[0])
catalog['cases'] = [available[key] for key in dict.fromkeys(key for key,_ in jobs)]
assert len(catalog['cases'])==7
write(quiet/'representative.json',catalog)
write(quiet/'jobs.json',jobs)
shutil.copyfile(donor/'cpython-worker.py',quiet/'cpython-worker.py')
assert sha(quiet/'cpython-worker.py') == prior['cpythonWorkerSHA256']
identity=dict(sourceRevision=head,productionSource=head,comparisonHostRevision=prior['comparisonHostRevision'],
    frozenImage=f'/home/lokad/lython-bench-checks/{root}/candidate',
    auxiliaryFiles={name:digest for name,digest in files.items() if name!=core},
    overlay=overlay,imageFiles={'candidate':files},
    coreSHA256={'candidate':files[core],'candidate-control':files[core]},
    catalogs={name:{'sha256':sha(quiet/name)} for name in ('representative.json','jobs.json')},
    expectedCPythonSHA256=prior['expectedCPythonSHA256'],cpythonWorkerSHA256=prior['cpythonWorkerSHA256'],
    donorArchiveSHA256=donor_archive,sourcePatchSHA256=pin['sourcePatchSHA256'],
    purpose='Compare the delivered compiler, iterable CSV, nested JSON and wide shipment with CPython.')
write(quiet/'identity.json',identity)
collector = (donor/'collect.py').read_text(encoding='utf-8').replace('lython-b1834-fixtures','lython-b1844-fixtures')
compile(collector,'collect.py','exec')
(quiet/'collect.py').write_text(collector,encoding='utf-8',newline='\n')
for name in ('run.sh','summarize.py'):
    shutil.copyfile(donor/name,quiet/name)
assert b'\r' not in (quiet/'run.sh').read_bytes()

host = (previous/'quiet-vm.py').read_text(encoding='utf-8')
assert host.count('lython-b1834-current-cpython-20261127')==1
host=host.replace('lython-b1834-current-cpython-20261127','lython-b1844-current-cpython-20261127')
start=host.index(' deduplicated=[]\n if before<floor:')
end=host.index(' root.mkdir()',start)
host=host[:start]+''' assert before>=floor,(before,floor)
 cleared=before
'''+host[end:]
host=host.replace('deduplicated=deduplicated,','deduplicated=[],')
compile(host,'quiet-vm.py','exec')
(lab/'quiet-vm.py').write_text(host,encoding='utf-8',newline='\n')
sdk = Path.home()/'.dotnet11'
dotnet = sdk/'dotnet.exe'
result = quiet/'candidate-verify.json'
subprocess.run([dotnet,image/'Lokad.Lython.Benchmarks.dll','--compare','verify','--catalog',quiet/'representative.json',
    '--dotnet',dotnet,'--python','C:/Python313/python.exe','--python-worker',quiet/'cpython-worker.py','--out',result],
    cwd=repo,env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk)),check=True,timeout=65)
verified=read(result)
assert verified['state']=='Completed' and verified['caseCount']==7
assert verified['catalogSha256']==identity['catalogs']['representative.json']['sha256']
assert verified['launched']['adapter']['sha256']==files['Lokad.Lython.Benchmarks.dll']
assert verified['launched']['library']['sha256']==files[core]

names=['identity.json','representative.json','jobs.json','cpython-worker.py','run.sh','collect.py',f'candidate/{core}']
payload=quiet/'stage.tar.gz'
with tarfile.open(payload,'w:gz') as archive:
    for name in names: archive.add(quiet/name,arcname=name)
staged={name:dict(length=(quiet/name).stat().st_size,sha256=sha(quiet/name)) for name in names}
write(quiet/'upload.json',dict(root=root,donor=donor_name,donorFiles=old_files,donorArchive=donor_archive,
    payloadSHA256=sha(payload),files=staged,expandedBytes=sum(item['length'] for item in staged.values()),
    minimumAfterStageBytes=4*1024*1024))
print('Validated overlay bytes',sum(item['length'] for item in staged.values()), flush=True)
