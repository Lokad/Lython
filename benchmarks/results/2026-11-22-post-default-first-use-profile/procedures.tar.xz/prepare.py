from pathlib import Path
import gzip
import hashlib
import json
import os
import subprocess
import tarfile

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
donor=lab.parent/'direct-lexical-keyword-default-20261122'
quiet=donor/'quiet'
def read(path): return json.loads(path.read_text(encoding='utf-8-sig'))
def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
def write(path, contents): path.write_text(contents,encoding='utf-8',newline='\n')
donor_config=read(quiet/'config.json')
receipt=read(quiet/'archive-receipt.json')
assert receipt['complete'] and receipt['allWorkersJoined'] and receipt['guestFixturesRemoved'] and receipt['archivedAndVerifiedUnderLease']
assert sha(quiet/'observations.tgz')==receipt['archiveSHA256']
files=read(quiet/'identity.json')['imageFiles']['candidate']
image=donor/'frozen/candidate'
assert len(files)==32 and {name:sha(image/name) for name in files}==files
core='Lokad.Lython.dll'
assert gzip.decompress((repo/'benchmarks/results/2026-11-22-direct-lexical-keyword-defaults/candidate-core.dll.gz').read_bytes())==(image/core).read_bytes()
revision=subprocess.check_output(['git','rev-parse','285628a43'],cwd=repo,text=True).strip()
measured=read(quiet/'identity.json')['sourceRevision'].split()[-1]
subprocess.run(['git','diff','--exit-code',measured,revision,'--','src'],cwd=repo,check=True)
sdk=Path.home()/'.dotnet11'
dotnet=sdk/'dotnet.exe'
protocol=repo/'benchmarks/cpython-worker.py'
assert sha(protocol)==donor_config['protocolSHA256']
env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk),PATH=str(sdk)+os.pathsep+os.environ['PATH'])
catalog=lab/'catalog.json'
subprocess.run([dotnet,image/'Lokad.Lython.Benchmarks.dll','--compare','verify','--catalog',catalog,'--dotnet',dotnet,'--python','C:/Python313/python.exe','--python-worker',protocol,'--out',lab/'verify.json'],check=True,env=env,timeout=95)
proof=read(lab/'verify.json')
assert proof['state']=='Completed' and proof['caseCount']==2 and proof['catalogSha256']==sha(catalog)
identity=dict(sourceRevision=revision,purpose='Post-default factory CPU attribution',
              coreSHA256=dict(candidate=files[core]),imageFiles=dict(candidate=files),catalogSHA256=sha(catalog),diagnosticOnly=True)
write(lab/'identity.json',json.dumps(identity,indent=2)+'\n')
parts=('collect.py','ops-profile.py','run.sh','catalog.json','identity.json')
payload=lab/'payload.tgz'
with tarfile.open(payload,'w:gz') as archive:
    for name in parts:
        archive.add(lab/name,arcname=name)
retire=read(lab/'retire-proof.json')['proof']
inventory=lab/'retire-inventory.json'
if inventory.exists():
    available=read(inventory)
    minimum=176160768+sum((lab/name).stat().st_size for name in parts)+4*1024*1024
    if available['free']<=minimum:
        for proof in available['proofs']:
            if proof.get('verified'):
                retire.append({key:value for key,value in proof.items() if key!='verified'})
            if available['free']+sum(group['bytes'] for group in retire)>minimum:
                break
        assert available['free']+sum(group['bytes'] for group in retire)>minimum
configuration=dict(root='/home/lokad/lython-bench-checks/post-default-first-use-profile-b1353-20261122',
    unit='lython-b1353-post-default-first-use-profile-20261122',source=donor_config['root'],
    sourceFiles=dict(candidate=files),sourceCatalogSHA256=donor_config['catalogSHA256'],catalogSHA256=sha(catalog),
    identity=identity,retireGroups=retire,payloadBytes=payload.stat().st_size,payloadSHA256=sha(payload),
    unpackedBytes=sum((lab/name).stat().st_size for name in parts),donorArchive=receipt['archiveSHA256'])
write(lab/'config.json',json.dumps(configuration,indent=2)+'\n')
remote=lab/'remote-launch.py'
s=remote.read_text(encoding='utf-8')
start,end=s.index('\nc=')+1,s.index('\nb=Path(')
s=s[:start]+'c='+repr(configuration)+s[end:]
compile(s,str(remote),'exec')
write(remote,s)
print(f'Frozen image and two goldens verified. Working storage floor needs {176160768+configuration["unpackedBytes"]+4*1024*1024:,} bytes.')

