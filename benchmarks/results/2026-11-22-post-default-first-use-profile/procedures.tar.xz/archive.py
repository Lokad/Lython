from pathlib import Path
import gzip, hashlib, json, shutil, subprocess, tarfile
lab=Path(".git/agent-notes/review-20261031/post-default-first-use-profile-20261122").resolve()
out=Path("benchmarks/results/2026-11-22-post-default-first-use-profile")
donor=lab.parent/"direct-lexical-keyword-default-20261122"/"frozen"/"candidate"
def read(path): return json.loads(path.read_text(encoding="utf-8-sig"))
def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
identity=read(lab/"identity.json")
assert identity["sourceRevision"] == subprocess.check_output(["git","rev-parse","285628a43"],text=True).strip()
files=identity["imageFiles"]["candidate"]
assert len(files)==32 and {name:sha(donor/name) for name in files}==files
assert gzip.decompress(Path("benchmarks/results/2026-11-22-direct-lexical-keyword-defaults/candidate-core.dll.gz").read_bytes())==(donor/"Lokad.Lython.dll").read_bytes()
receipt=read(lab/"archive-receipt.json")
status=read(lab/"terminal-status.json")
assert status["receipt"]==receipt and status["exitCode"]=="0" and not status["remainingWorkers"] and not status["remainingTrace"]
assert all(receipt[k] for k in ("complete","quietBeforeAndAfter","allWorkersJoined","archivedAndVerifiedUnderLease","guestFixturesRemoved","persistentTraceArchivedAndVerifiedBeforeUnmount"))
assert receipt["archiveSHA256"]==sha(lab/"observations.tgz")
proof=read(lab/"verify.json")
assert proof["state"]=="Completed" and proof["caseCount"]==2 and proof["catalogSha256"]==sha(lab/"catalog.json")==identity["catalogSHA256"]
catalog={c["id"]:c for c in read(lab/"catalog.json")["cases"]}
rows=read(lab/"attribution.json")["rows"]
assert [r["sampleCount"] for r in rows]==[1156,1099,1108,1206]
assert [r["lane"] for r in rows]==["warm","compile-run","compile","warm"]
for row in rows:
    record=read(lab/"retrieved"/"profiles"/row["label"]/"record.json")
    assert record["workload"]==row["case"] and record["lane"]==row["lane"]
    assert record["exitCode"]==0 and record["closed"]["status"]=="Closed"
    case=catalog[row["case"]]
    for point in ("verificationBefore","verificationAfter"):
        assert record[point]["status"]=="Equivalent" and record[point]["actualOutputSha256"]==case["expectedOutputSha256"]
    assert record["response"]["completedInvocations"]>0 and record["warmupSeconds"]>=8
    for batch in record["batches"]:
        assert batch["status"]=="Completed"
        assert batch.get("actualOutputSha256")== (None if row["lane"]=="compile" else case["expectedOutputSha256"])
out.mkdir(exist_ok=False)
for name in ("README.md","attribution.json","archive-receipt.json","terminal-status.json","observations.tgz"):
    shutil.copyfile(lab/name,out/name)
with tarfile.open(out/"procedures.tar.xz","w:xz") as archive:
    for path in sorted(lab.iterdir()):
        if path.is_file() and path.suffix!=".tgz":
            archive.add(path,arcname=path.name)
print("All four profiles and complete image custody verified.")
