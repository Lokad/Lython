set -eu
root=/home/lokad/lython-bench-checks/post-default-first-use-profile-b1353-20261122
trap 'result=$?; printf "%s\n" "$result" > "$root/exit-code.txt"' EXIT
python3 "$root/collect.py"
