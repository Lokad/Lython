from pathlib import Path
import ast,hashlib,json,tarfile
lab=Path(__file__).resolve().parent
donor=lab.parent/'final-split-operands-r595'
phase=lab.parent/'annotation-and-forwarding-cpython-r590'
quit=donor/'quiet'
read=lambda path:path.read_text(encoding='utf-8-sig')
load=lambda path:json.loads(read(path))
sha=lambda value:hashlib.sha256(value).hexdigest()
def write(path,data):
    if path.suffix=='.py':ast.parse(data)
    path.write_text(data,encoding='utf-8',newline='\n')
def save(path,data):
    write(path,json.dumps(data,indent=2,ensure_ascii=False)+'\n')
catalog=lab/'representative.json'
catalog_hash=sha(catalog.read_bytes())
assert catalog.read_bytes()==(phase/'representative.json').read_bytes()
verified=load(lab/'verify.json')
assert verified['state']=='Completed' and verified['catalogSha256']==catalog_hash
prior=load(quit/'config.json')
files=prior['identity']['imageFiles']['candidate']
assert len(files)==32 and files['Lokad.Lython.dll'].startswith('589d6b7b')
assert {n:sha((donor/'frozen/candidate'/n).read_bytes()) for n in files}==files
root='/home/lokad/lython-bench-checks/definition-and-split-cpython-b1022-20261119'
unit='lython-b1022-definition-and-split-cpython-20261119'
script_hash=sha(Path('benchmarks/cpython-worker.py').read_bytes())
assert script_hash==load(phase/'identity.json')['cpythonWorkerSHA256']
identity=dict(sourceRevision='6ce82ba48',purpose='Definition completion and final split operand checkpoint',
              imageFiles={'candidate':files},auxiliaryFiles={k:v for k,v in files.items() if k!='Lokad.Lython.dll'},
              coreSHA256={role:files['Lokad.Lython.dll'] for role in ('candidate','candidate-control')},
              catalogSHA256=catalog_hash,cpythonWorkerSHA256=script_hash,normalAdapterPin='0.4.0')
save(lab/'identity.json',identity)
old_root=load(phase/'config.json')['root']
for name in ['collect.py','archive-owned.py','launch.py','retrieve.py','run.sh']:
    write(lab/name,read(phase/name).replace(old_root,root).replace('B1016','B1022'))
space=load(lab/'quiet-space.json')
payload=lab/'payload.tgz'
names=['representative.json','identity.json','collect.py','archive-owned.py','run.sh']
with tarfile.open(payload,'w:gz') as archive:
    for name in names:archive.add(lab/name,arcname=name)
unpacked=sum((lab/name).stat().st_size for name in names)
needed=254*1024*1024+unpacked+512*1024
available=space['freeBytes']
retire=[]
for proof in sorted(space['replicas'],key=lambda p:-p['bytes']):
    if available>=needed+49152:break
    retire.append(proof)
    available+=proof['bytes']
save(lab/'preflight.json',dict(available=available,required=needed,retired=retire))
assert available>=needed,(available,needed)
config=dict(root=root,unit=unit,source=prior['root'],sourceRole='candidate',sourceFiles=files,
            sourceCatalogSHA256=prior['catalogSHA256'],catalogSHA256=catalog_hash,identity=identity,
            retireGroups=retire,payloadBytes=payload.stat().st_size,payloadSHA256=sha(payload.read_bytes()),
            unpackedBytes=unpacked,cpythonWorkerSHA256=script_hash)
save(lab/'config.json',config)
launcher=read(quit/'remote-launch.py')
a,b=launcher.index('\nc=')+1,launcher.index('\nb=Path(')
launcher=launcher[:a]+'c='+repr(config)+launcher[b:]
launcher=launcher.replace("['reference','candidate']","['candidate']").replace('lython-b1021-fixtures','lython-b1022-fixtures')
launcher=launcher.replace(" payload=sys.stdin"," assert sha(source/'cpython-worker.py')==c['cpythonWorkerSHA256']\n payload=sys.stdin")
write(lab/'remote-launch.py',launcher)
print('Verified B1022 with',available-needed,'bytes of staging headroom.')