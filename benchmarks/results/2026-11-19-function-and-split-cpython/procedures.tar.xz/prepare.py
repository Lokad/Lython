from pathlib import Path
import hashlib,json,os,shutil,subprocess
lab=Path(__file__).resolve().parent
donor=lab.parent/'final-split-operands-r595'
prior=lab.parent/'annotation-and-forwarding-cpython-r590'
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
frozen=donor/'frozen/candidate'
manifest=load(donor/'frozen-identity.json')
files=manifest['images']['candidate']
assert len(files)==32 and files['Lokad.Lython.dll'].startswith('589d6b7b')
assert {name:sha(frozen/name) for name in files}==files
retained=(donor/'retained-commit.txt').read_text(encoding='utf-8-sig').strip()
assert retained.startswith('6ce82ba48')
assert not subprocess.check_output(['git','diff','--name-only',manifest['candidateCommit'],retained,'--','src'])
catalog=lab/'representative.json'
shutil.copyfile(prior/'representative.json',catalog)
cases=load(catalog)['cases']
assert {row['id'] for row in cases}=={'scripts.report-forwarding.expanded','scripts.rule-default-closures','scripts.annotated-rule-closures'}
sdk=Path.home()/'.dotnet11'
dotnet=sdk/'dotnet.exe'
env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk),PATH=str(sdk)+os.pathsep+os.environ['PATH'])
with (lab/'verify.log').open('wb') as log:
    subprocess.run([dotnet,frozen/'Lokad.Lython.Benchmarks.dll','--compare','verify','--catalog',catalog,
        '--dotnet',dotnet,'--python','C:/Python313/python.exe','--python-worker',Path.cwd()/'benchmarks/cpython-worker.py',
        '--out',lab/'verify.json'],env=env,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=75)
verified=load(lab/'verify.json')
assert verified['state']=='Completed' and verified['catalogSha256']==sha(catalog)
print('Verified the retained runtime, complete worker image and three unchanged external cases.')