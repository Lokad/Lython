from pathlib import Path
import ast,hashlib,json,shutil,tarfile
r=Path('.git/agent-notes/review-20261031/operand-gate-r519');r.mkdir(exist_ok=False);prior=r.parent/'call-entry-r514-corrected';source=r.parent/'entry-result-routing-r518';oldremote='/home/lokad/lython-bench-checks/call-entry-b941-20261118';remote='/home/lokad/lython-bench-checks/operand-gate-b948-20261118';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
f=json.loads((source/'frozen/identity.json').read_text(encoding='utf-8'));files=f['imageFiles']['candidate'];assert all(sha(source/'frozen/candidate'/n)==h for n,h in files.items())
shutil.copyfile(source/'measurement-catalog.json',r/'catalog.json');shutil.copyfile(source/'candidate-measurement-preflight.json',r/'actual-worker-preflight.json')
identity=dict(sourceRevision='Committed9e8eaba1/frozen84b1a159; full44250743374 pending, focused-qualified',purpose='One current complete floating warm CPU attribution after global/yield/result transport; seek coherent removable operand/collection lifecycle. Inclusive samples include useful work, not a removable share or timing comparison.',imageFiles=dict(candidate=files),coreSHA256=dict(candidate=files['Lokad.Lython.dll']),catalogSHA256=sha(r/'catalog.json'),normalAdapterPin='0.4.0',publicationHeld=True);(r/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8')
for n in ['ops-profile.py','collect.py','run.sh','analyze.py','launch.py','retrieve.py']:
 s=(prior/n).read_text(encoding='utf-8').replace(oldremote,remote).replace("[('text-original', 'scripts.text-normalization.large', 'warm'), ('text-helper', 'scripts.text-normalization.helper-list', 'warm')]","[('floating','scripts.numeric-squared-error.floating.large','warm')]").replace("['text-original','text-helper']","['floating']").replace('len(records)==2','len(records)==1').replace('Current original/helper text ALL-thread','Current floating ALL-thread').replace('Current original/helper CPU attribution','Current floating operand CPU attribution').replace('R514/B941 committed10ee56c7/frozen2ede09fc; original/helper text attribution','R519/B948 committed9e8eaba1/frozen84b1a159; floating attribution')
 if n=='analyze.py':s=s.replace("r/'attribution.json'","r/'attribution.json'")
 (r/n).write_text(s,encoding='utf-8',newline='\n')
stage=['ops-profile.py','collect.py','run.sh','identity.json']
with tarfile.open(r/'payload.tgz','w:gz')as a:
 for n in stage:a.add(r/n,arcname=n)
previous=json.loads((source/'quiet/config.json').read_text(encoding='utf-8'))
c=dict(root=remote,unit='lython-b948-operand-gate-20261118',source=previous['root'],sourceFiles=files,sourceCatalogSHA256=identity['catalogSHA256'],catalogSource=previous['root']+'/representative.json',catalogSHA256=identity['catalogSHA256'],identity=identity,retireGroups=[],payloadBytes=(r/'payload.tgz').stat().st_size,payloadSHA256=sha(r/'payload.tgz'),unpackedBytes=sum((r/n).stat().st_size for n in stage));(r/'config.json').write_text(json.dumps(c,indent=2)+'\n',encoding='utf-8')
s=(prior/'remote-launch.py').read_text(encoding='utf-8');a=s.index('c=');b=s.index('\nb=Path(',a);s=s[:a]+'c='+repr(c)+s[b:];s=s.replace('lython-b941-fixtures','lython-b948-fixtures');(r/'remote-launch.py').write_text(s,encoding='utf-8')
for p in r.glob('*.py'):ast.parse(p.read_text(encoding='utf-8'))
print('One current floating CPU capture prepared; actual32-file/four-case verification reused exactly, no retirement or runtime change.')
