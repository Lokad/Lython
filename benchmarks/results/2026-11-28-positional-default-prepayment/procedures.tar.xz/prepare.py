from hashlib import sha256
from pathlib import Path
from shutil import copyfile, copytree
from statistics import median
import json
import os
import re
import subprocess

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
pair = lab / "comparison"
notes = lab.parent
prior = notes / "small-closure-name-table-b1911-20261128/comparison"
read = lambda path: json.loads(path.read_bytes())
digest = lambda path: sha256(path.read_bytes()).hexdigest()
git = lambda *args: subprocess.check_output(["git", *args], cwd=repo)
def image(folder):
    return {p.name: digest(p) for p in folder.iterdir()}
def write(path, value):
    path.write_text(json.dumps(value, indent=2) + "\n", encoding="utf-8", newline="\n")

base = git("rev-parse", "HEAD").decode().strip()
original = read(prior / "identity.json")
assert sha256(git("diff", "--binary", original["sourceRevision"], base, "--", "src")).hexdigest() == original["sourcePatchSHA256"]
patch = git("diff", "--binary", base, "--", "src")
assert patch.count(b"diff --git ") == 6 and b"PrepaidPositionalDefault" in patch
(lab / "candidate.patch").write_bytes(patch)
(lab / "test.patch").write_bytes(git("diff", "--binary", base, "--", "tests"))
pair.mkdir()
assert image(prior / "candidate") == original["imageFiles"]["candidate"]
for role in ("reference", "candidate"):
    copytree(prior / "candidate", pair / role)
core = "Lokad.Lython.dll"
fresh = repo / "src/Lokad.Lython/bin/Release/net11.0" / core
assert digest(fresh) == digest(repo / "tests/Lokad.Lython.PublicApi.Tests/bin/Release/net11.0" / core) != original["imageFiles"]["candidate"][core]
copyfile(fresh, pair / "candidate" / core)
images = {role: image(pair / role) for role in ("reference", "candidate")}
assert [name for name, before in images["reference"].items() if images["candidate"][name] != before] == [core]
for name in ("cpython-worker.py", "run.sh"):
    copyfile(prior / name, pair / name)
assert digest(pair / "cpython-worker.py") == original["cpythonWorkerSHA256"]
assert b"\r" not in (pair / "run.sh").read_bytes()

def verified_catalog(folder):
    path = folder / "representative.json"
    assert digest(path) == read(folder / "identity.json")["catalogs"][path.name]["sha256"]
    return read(path)

cache = notes / "generator-definition-cache-20261127"
catalog = verified_catalog(prior)
original_cases = {case["id"]: case for case in catalog["cases"]}
ordinary = original_cases["diagnostic.generated-ordinary-definitions"]
escaping = original_cases["diagnostic.generated-escaping-definitions"]
python = "/mnt/d/code/Lython/.git/agent-notes/review-20261031/bench-cpython-3.13.16-runtime/runtime/bin/python3.13"

def positional_variant(case):
    source, count = re.subn(
        r"(?m)^(    def rule_(\d+)\(|    rule_(\d+) = lambda )value=.*(?:\): return |: )value \+ factor$",
        replace_header_parts, case["source"])
    assert count == 96
    source = source.replace("middle.__kwdefaults__['factor']", "middle.__defaults__")
    output = subprocess.run(["wsl", "--", python, "-I", "-S", "-X", "utf8", "-"],
                            input=source.encode("utf-8"), capture_output=True, timeout=30, check=True)
    assert output.stderr == b""
    return dict(case, id=case["id"] + ".positional",
                source=source, sourceUtf8Bytes=len(source.encode("utf-8")),
                sourceSha256=sha256(source.encode("utf-8")).hexdigest(),
                expectedOutput=output.stdout.decode("utf-8"), expectedOutputUtf8Bytes=len(output.stdout),
                expectedOutputSha256=sha256(output.stdout).hexdigest())

def replace_header_parts(match):
    prefix, statement, lambda_number = match.groups()
    number = statement or lambda_number
    close = "): return " if statement else ": "
    return f"{prefix}value=shift(offset + {number}){close}value + {int(number) % 7 + 1}"

a, b = positional_variant(ordinary), positional_variant(escaping)
catalog["cases"] = [a, b, escaping]
write(pair / "representative.json", catalog)
jobs = [[a["id"], "warm"], [b["id"], "warm-async"], [escaping["id"], "warm-async"],
        [a["id"], "warm-async"], [b["id"], "warm"], [b["id"], "compile-run"]]
write(pair / "jobs.json", {"warm": jobs})
identity = dict(sourceRevision=base, sourcePatchSHA256=digest(lab / "candidate.patch"),
                productionReference=base, imageFiles=images,
                coreSHA256={role + suffix: hashes[core] for role, hashes in images.items() for suffix in ("", "-control")},
                cpythonWorkerSHA256=original["cpythonWorkerSHA256"], cpythonPath=original["cpythonPath"],
                expectedCPythonSHA256=original["expectedCPythonSHA256"],
                purpose="Combine computed positional-default and callable admission.",
                catalogs={name: {"sha256": digest(pair / name)} for name in ("representative.json", "jobs.json")})
write(pair / "identity.json", identity)
collector = (prior / "collect.py").read_text(encoding="utf-8").replace("lython-small-closure-name-table-", "lython-positional-default-prepayment-").replace("len(jobs) == 5", "len(jobs) == 6")
compile(collector, "collect.py", "exec")
(pair / "collect.py").write_text(collector, encoding="utf-8", newline="\n")
print("Frozen", base, identity["sourcePatchSHA256"], flush=True)

allocation = lab / "allocation"
allocation.mkdir()
witness = cache / "allocation/candidate"
for role, files in images.items():
    folder = allocation / role
    copytree(pair / role, folder)
    for file in witness.glob("ValidatedAllocation*"):
        copyfile(file, folder / file.name)
    assert (folder / "ValidatedAllocation.dll").is_file()
    assert all(digest(folder / name) == checksum for name, checksum in files.items())
sdk = Path.home() / ".dotnet11"
env = dict(os.environ, DOTNET_ROOT=str(sdk), DOTNET_ROOT_X64=str(sdk))
rows = []
for mode in ("sync", "async"):
    for case in catalog["cases"]:
        case["runAsync"] = mode == "async"
    selection = allocation / f"{mode}-catalog.json"
    write(selection, catalog)
    comparisons = []
    for role in images:
        folder = allocation / role
        report = allocation / f"{role}-{mode}.json"
        subprocess.run([sdk / "dotnet.exe", folder / "ValidatedAllocation.dll", folder, selection, report], env=env, check=True, timeout=90)
        comparisons.append(read(report)["rows"])
    for before, after in zip(*comparisons, strict=True):
        assert before["id"] == after["id"]
        assert before["sharedBudgetBaselineRestored"] and after["sharedBudgetBaselineRestored"]
        row = dict(case=before["id"], mode=mode, clr=[median(r["allocatedBytesPerInvocation"]) for r in (before, after)],
                   peak=[r["peakExecutionMemoryBytes"] for r in (before, after)],
                   compiled=[r["compiledReservedBytes"] for r in (before, after)])
        rows.append(row)
        print(row, flush=True)
write(allocation / "summary.json", rows)



