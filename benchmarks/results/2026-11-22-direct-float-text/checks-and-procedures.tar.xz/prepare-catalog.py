from pathlib import Path
import base64, csv, collections, hashlib, io, json, struct
from decimal import Decimal

lab = Path(__file__).resolve().parent
old = lab.parent/'single-positional-default-20261122'/'representative.json'
manifest = json.loads(old.read_text(encoding='utf-8'))
manifest["cases"] = [next(x for x in manifest["cases"] if x['id']=='scripts.csv-invoice.large')]

template = """import csv
usage = {{}}
count = 0
with open('meters.csv', encoding='utf-8', newline='') as source:
    rows = csv.reader(source{quoting})
    next(rows)
    for site, kwh, peak, price, note in rows:
{conversion}        prior = usage.get(site, (0.0, 0.0, 0.0))
        usage[site] = (prior[0] + kwh, max(prior[1], peak), prior[2] + kwh * price)
        count += 1
with open('summary.csv', 'w', encoding='utf-8', newline='') as target:
    report = csv.writer(target, lineterminator='\\n')
    report.writerow(('site', 'kwh', 'peak', 'charge'))
    for site in sorted(usage):
        totals = usage[site]
        report.writerow((site, f'{{totals[0]:.4f}}', f'{{totals[1]:.4f}}', f'{{totals[2]:.4f}}'))
print(count, len(usage))
"""
records = [
    ('café',      '12.5', '6.25', '0.125', 'regular'),
    ('east',       '7.25', '3.5', '0.25', 'verified'),
    ('café',      '-1.5', '1.25', '0.125', 'meter, reset'),
    ('west',        '4', '2.75', '0.5', 'café 😀'),
]
repeat=1024
grouped=collections.defaultdict(list)
for site, kwh, peak, price, note in records:
    grouped[site].append((Decimal(kwh),Decimal(peak),Decimal(price)))
report=io.StringIO(newline='')
writer=csv.writer(report,lineterminator='\n')
writer.writerow(('site','kwh','peak','charge'))
for site,group in sorted(grouped.items()):
    aggregates=(sum(kwh for kwh,_,_ in group)*repeat,
                max(peak for _,peak,_ in group),
                sum(kwh*price for kwh,_,price in group)*repeat)
    writer.writerow((site,*(f'{value:.4f}' for value in aggregates)))
expected_report=report.getvalue().encode('utf-8')
expected=f'{repeat*len(records)} {len(grouped)}\n'
def sha(value):
    return hashlib.sha256(value.encode('utf-8') if isinstance(value,str) else value).hexdigest()
def file_digest(name,payload):
    return sha(struct.pack('>i',1)+struct.pack('>i',len(name))+name.encode('ascii')+
               struct.pack('>i',len(payload))+payload)
def b64(value):
    return base64.b64encode(value).decode('ascii')
def number(value, unicode):
    if not unicode: return value
    digits=str.maketrans('0123456789','٠١٢٣٤٥٦٧٨٩')
    first=value.lstrip('-')
    if len(first)>=2 and first[:2].isdigit():
        value=value[:-len(first)]+first[:1]+'_'+first[1:]
    return '\u00a0'+value.translate(digits)+'\u0085'
def quoted(s):
    return '"' + s.replace('"','""') + '"'
def case(suffix, typed, unicode=False):
    quot=', quoting=csv.QUOTE_NONNUMERIC' if typed else ''
    conv='' if typed else '        kwh, peak, price = float(kwh), float(peak), float(price)\n'
    script=template.format(quoting=quot,conversion=conv)
    pattern=''.join(','.join((quoted(site),*(number(n,unicode) for n in (kwh,peak,price)),quoted(note)))+'\n'
                     for site,kwh,peak,price,note in records)
    payload=('"site","kwh","peak","price","note"\n'+pattern*repeat).encode('utf-8')
    fixture=json.dumps(dict(size=repeat,text=None,inputFiles={'meters.csv':b64(payload)},
                      outputFiles={'summary.csv':b64(expected_report)}),ensure_ascii=False,separators=(',',':'))
    return dict(id='scripts.csv-meter-report.'+suffix,family='scripts',category='scripts',scale='large',
                size=repeat,source=script,fixtureJson=fixture,expectedOutput=expected,sourceUtf8Bytes=len(script.encode('utf-8')),
                expectedOutputUtf8Bytes=len(expected.encode('utf-8')),fixtureTextUtf8Bytes=None,fixtureTextCodePoints=None,
                sourceSha256=sha(script),fixtureSha256=sha(fixture),expectedOutputSha256=sha(expected),
                expectedFilesSha256=file_digest('summary.csv',expected_report))
for label,typed,unicode in [('typed-ascii',True,False),('explicit-float',False,False),('typed-unicode',True,True)]:
    manifest['cases'].append(case(label,typed,unicode))
(lab/'representative.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
print([(c['id'],len(base64.b64decode(next(iter(json.loads(c['fixtureJson'])['inputFiles'].values()))))) for c in manifest['cases']])

