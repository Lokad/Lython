set -e
cd /mnt/d/code/Lython/.git/agent-worktrees/detached-nonlocal-cells-r629
export PATH="$HOME/.dotnet:$PATH"
out=/mnt/d/code/Lython/artifacts/r629-wsl
filter='FullyQualifiedName~Closure|FullyQualifiedName~CapturedScalar|FullyQualifiedName~Nonlocal|FullyQualifiedName~ScopeDirective|FullyQualifiedName~Comprehension|FullyQualifiedName~Generator|FullyQualifiedName~Lambda|FullyQualifiedName~MatchGuard|FullyQualifiedName~ClassMethod|FullyQualifiedName~ImplicitClass|FullyQualifiedName~LocalNamespace|FullyQualifiedName~GovernedMemoryContractTests|FullyQualifiedName~CompilerCancellation|FullyQualifiedName~ExceptionBinding|FullyQualifiedName~Imported|FullyQualifiedName~Augmented|FullyQualifiedName~BoundLoopNameStorage|FullyQualifiedName~Annotations'
dotnet test tests/Lokad.Lython.PublicApi.Tests -c Release -f net10.0 --artifacts-path "$out" --filter "$filter"
dotnet test tests/Lokad.Lython.Tests -c Release -f net10.0 --artifacts-path "$out" --filter "$filter"
