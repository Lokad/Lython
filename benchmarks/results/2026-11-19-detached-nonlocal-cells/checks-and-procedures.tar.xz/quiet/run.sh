set -eu
root=/home/lokad/lython-bench-checks/detached-cells-confirmation-b1062-20261119
trap 'result=$?; printf "%s\n" "$result" > "$root/exit-code.txt"' EXIT
python3 "$root/collect.py"
