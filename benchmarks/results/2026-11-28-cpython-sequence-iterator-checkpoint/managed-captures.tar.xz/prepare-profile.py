from hashlib import sha256
from pathlib import Path
from shutil import copy2
import json

lab = Path(__file__).resolve().parent
prior = lab.parent / 'ordinary-reduction-profile-b1939-20261128/attribution/profile'
quiet = lab / 'comparison/quiet'
profile = lab / 'attribution/profile'
profile.mkdir(parents=True)
identity = json.loads((quiet / 'identity.json').read_bytes())
assert {p.name: sha256(p.read_bytes()).hexdigest() for p in (quiet / 'local-image').iterdir()} == identity['imageFiles']['candidate']
roles = [('reduction-async', 'diagnostic.shipment-row-generator-reduction', 'warm-async'),
         ('iterable-async', 'diagnostic.shipment-starmap-iterable-rows', 'warm-async'),
         ('map-async', 'diagnostic.shipment-file-fed-map', 'warm-async')]
identity.update(inspectedHead=identity['sourceRevision'], profiles=roles)
(profile / 'identity.json').write_text(json.dumps(identity, indent=2) + '\n', encoding='utf-8', newline='\n')
for name in ('representative.json', 'cpython-worker.py'):
    copy2(quiet / name, profile.parent / name)
copy2(quiet / 'candidate-local-verify.json', profile.parent / 'candidate-verify.json')
collect = (prior / 'collect.py').read_text(encoding='utf-8')
collect = collect.replace("lab.parents[2]/'current-shipment-checkpoint-b1937-20261128/comparison/quiet/local-image'", "lab.parents[1]/'comparison/quiet/local-image'")
old = "assert any(n[\"sha256\"].lower()==expected[\"Lokad.Lython.dll\"] for n in identity[\"libraries\"])"
new = "assert all(any(n['sha256'].lower() == expected[file] for n in identity['libraries']) for file in ('Lokad.Lython.dll', 'Lokad.Lython.Benchmarks.dll'))"
assert collect.count(old) == 1
collect = collect.replace(old, new)
analysis = (prior / 'analyze-managed.py').read_text(encoding='utf-8')
analysis = analysis.replace("('reduction-async', 'reduction-sync', 'map-async')", repr(tuple(role for role, case, lane in roles)))
analysis = analysis.replace("'instruction prefix':", "'async iterator move': ('ExecuteForNextAsync',), 'generator frame setup': ('InitializeGeneratorExecution', 'InitializeFreshOwned', 'DetachGeneratorExecution', 'SeedGeneratorOuter', 'ReleaseGeneratorTemporaries'), 'starmap row': ('PyStarmapIterator',), 'instruction prefix':")
for name, code in [('collect.py', collect), ('analyze-managed.py', analysis)]:
    compile(code, name, 'exec')
    (profile / name).write_text(code, encoding='utf-8', newline='\n')
copy2(prior / 'run.sh', profile / 'run.sh')
assert b'\r' not in (profile / 'run.sh').read_bytes()
print(identity['sourceRevision'], 'current async execution profiles prepared')
