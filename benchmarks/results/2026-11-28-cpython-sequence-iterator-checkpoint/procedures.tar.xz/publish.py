from hashlib import sha256
from pathlib import Path
from shutil import copy2
from subprocess import check_output
import json
import tarfile

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
quiet = lab / 'comparison/quiet'
profile = lab / 'attribution/profile'
out = repo / 'benchmarks/results/2026-11-28-cpython-sequence-iterator-checkpoint'
def digest(path):
    return sha256(path.read_bytes()).hexdigest()
def read(path):
    return json.loads(path.read_bytes())

def put_archive(target, files):
    with tarfile.open(target, 'w:xz') as archive:
        for name, path in files.items():
            archive.add(path, arcname=name)
    with tarfile.open(target) as archive:
        assert all(digest(path) == sha256(archive.extractfile(name).read()).hexdigest() for name, path in files.items())

identity = read(quiet / 'identity.json')
proof = read(quiet / 'summary.json')
revision = check_output(['git', 'rev-parse', 'bf10eeaea'], cwd=repo, text=True).strip()
assert revision == identity['sourceRevision'] == proof['source']
assert proof['passedQuietCheck'] and proof['timedBatches'] == 168 and len(proof['rows']) == 6
image = identity['imageFiles']['candidate']
assert len(image) == 32 and {p.name: digest(p) for p in (quiet / 'local-image').iterdir()} == image
assert digest(lab / 'ubuntu-core-build.log') == identity['buildLogSHA256']
local = read(quiet / 'candidate-local-verify.json')
assert local['state'] == 'Completed' and local['caseCount'] == 4
assert local['catalogSha256'] == identity['catalogs']['representative.json']['sha256']
assert local['launched']['library']['sha256'] == image['Lokad.Lython.dll']
assert local['launched']['adapter']['sha256'] == image['Lokad.Lython.Benchmarks.dll']
assert local['launched']['python']['sha256'] == identity['expectedCPythonSHA256']
out.mkdir(exist_ok=True)
for name in ('identity.json', 'summary.json', 'observations.tar.xz', 'terminal-status.json', 'stage-custody.json'):
    copy2(quiet / name, out / name)
    assert digest(quiet / name) == digest(out / name)
procedures = {name: quiet / name for name in ('candidate-local-verify.json', 'candidate-remote-verify.json',
              'local-verify.log', 'local-verify-initial.log', 'launch.log', 'archive-receipt.json', 'upload.json')}
procedures.update({name: lab / name for name in ('prepare.py', 'quiet-vm.py', 'verify.sh', 'summarize.py',
                  'publish.py', 'ubuntu-core-build.log')})
if (quiet / 'attempt-initial').is_dir():
    attempt = quiet / 'attempt-initial'
    failed = read(attempt / 'terminal-status.json')
    assert not failed['live'] and not failed['fixtures'] and failed['exitCode'] != '0'
    assert digest(attempt / 'observations.tar.xz') == failed['receipt']['archiveSHA256']
    procedures.update({f'attempt-initial/{p.name}': p for p in attempt.iterdir()})
    procedures['retry.py'] = lab / 'retry.py'
put_archive(out / 'procedures.tar.xz', procedures)

record = read(profile / 'run-summary.json')
profile_id = read(profile / 'identity.json')
assert record['sourceRevision'] == profile_id['sourceRevision'] == revision
assert profile_id['imageFiles'] == identity['imageFiles'] and record['allProcessesJoined']
assert record['catalogSha'] == identity['catalogs']['representative.json']['sha256']
roles = read(profile / 'managed-attribution.json')
assert [row['role'] for row in roles] == [role for role, case, lane in profile_id['profiles']]
profiles = {name: profile / name for name in ('run.sh', 'collect.py', 'analyze-managed.py', 'collection.log',
            'managed-analysis.log', 'identity.json', 'run-summary.json')}
profiles['prepare-profile.py'] = lab / 'prepare-profile.py'
batches = 0
for role, case, lane in profile_id['profiles']:
    folder = profile / role
    capture = read(folder / 'record.json')
    assert capture['role'] == role and capture['lane'] == lane and capture['workload'] == case and capture['allProcessesJoined']
    assert capture['nettraceSha'] == digest(folder / 'run.nettrace') and capture['coreSha'] == image['Lokad.Lython.dll']
    assert capture['batches'] and all(batch['status'] == 'Completed' for batch in capture['batches'])
    batches += len(capture['batches'])
    for name in ('run.nettrace', 'run.speedscope.json', 'record.json', 'exclusive.txt', 'inclusive.txt', 'capture.log', 'worker.stderr'):
        profiles[f'{role}/{name}'] = folder / name
assert batches == record['totalVerifiedBatches']
for name in ('managed-attribution.json', 'run-summary.json'):
    copy2(profile / name, out / name)
    assert digest(profile / name) == digest(out / name)
put_archive(out / 'managed-captures.tar.xz', profiles)
print('B1943 quiet comparison and matching managed captures verified.')
