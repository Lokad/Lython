from hashlib import sha256
from pathlib import Path
from shutil import copy2, copytree
from subprocess import check_output
import json
import tarfile

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
refined = lab.parent / 'sequence-iterator-refined-b1942-20261128/comparison'
previous = lab.parent / 'current-shipment-checkpoint-b1937-20261128'
donor = previous / 'comparison/quiet'
quiet = lab / 'comparison/quiet'
core = 'Lokad.Lython.dll'
worker = 'Lokad.Lython.Benchmarks.dll'
adapter = 'Lokad.Lython.Utf8Regex.dll'
build = lab / 'ubuntu-artifacts/bin/Lokad.Lython/release_net11.0' / core
stage = 'script-cpython-quiet-b1943-20261128'

def read(path):
    return json.loads(path.read_bytes())

def digest(path):
    return sha256(path.read_bytes()).hexdigest()

def files(folder):
    return {p.name: digest(p) for p in folder.iterdir()}

def write(path, data):
    save(path, json.dumps(data, indent=2) + '\n')

def git(*args):
    return check_output(['git', *args], cwd=repo)

def save(path, data):
    path.write_text(data, encoding='utf-8', newline='\n')
    assert b'\r' not in path.read_bytes()

head = git('rev-parse', 'HEAD').decode().strip()
assert head.startswith('bf10eeaea') and not git('status', '--porcelain')
with tarfile.open(repo / 'benchmarks/results/2026-11-28-direct-sequence-iterator/refined/diagnostic-validation.tar.xz') as proof:
    assert proof.extractfile('final-production.patch').read() == git('diff', '--binary', '405afff35', head, '--', 'src/Lokad.Lython')
    assert proof.extractfile('final-tests.patch').read() == git('diff', '--binary', '405afff35', head, '--', 'tests')
measured = read(refined / 'identity.json')
assert not git('diff', '--binary', measured['sourceRevision'], head, '--', 'src/Lokad.Lython.Utf8Regex', 'benchmarks/Lokad.Lython.Benchmarks', 'Directory.Packages.props')
refined_files = measured['imageFiles']['candidate']
assert len(refined_files) == 32 and files(refined / 'candidate') == refined_files
old_id = read(donor / 'identity.json')
donor_files = old_id['imageFiles']['candidate']
assert len(donor_files) == 32 and files(donor / 'local-image') == donor_files
old_state = read(donor / 'terminal-status.json')
assert not old_state['live'] and not old_state['fixtures'] and old_state['exitCode'] == '0'
receipt = old_state['receipt']
assert receipt['complete'] and receipt['allWorkersJoined'] and receipt['quietBeforeAndAfter']
assert digest(donor / 'observations.tar.xz') == receipt['archiveSHA256']

quiet.mkdir(parents=True)
copytree(refined / 'candidate', quiet / 'local-image')
copy2(build, quiet / 'local-image' / core)
image = files(quiet / 'local-image')
assert image[core] == digest(build) and len(image) == 32
assert {name for name, sha in refined_files.items() if image[name] != sha} == {core}
changed = {name for name, sha in donor_files.items() if image[name] != sha}
assert changed == {core, adapter}, changed
assert all(not p.samefile(refined / 'candidate' / p.name) for p in (quiet / 'local-image').iterdir())
assert not (quiet / 'local-image' / core).samefile(build)
for name in ('representative.json', 'cpython-worker.py'):
    copy2(refined / name, quiet / name)
assert digest(quiet / 'cpython-worker.py') == measured['cpythonWorkerSHA256'] == old_id['cpythonWorkerSHA256']
assert digest(quiet / 'representative.json') == measured['catalogs']['representative.json']['sha256']
assert measured['expectedCPythonSHA256'] == old_id['expectedCPythonSHA256']

ordinary = 'diagnostic.shipment-row-generator-reduction'
iterable = 'diagnostic.shipment-starmap-iterable-rows'
file_map = 'diagnostic.shipment-file-fed-map'
range_control = 'diagnostic.shipment-row-range-generator-reduction'
jobs = [(iterable, 'warm'), (iterable, 'warm-async'), (ordinary, 'warm'), (ordinary, 'warm-async'),
        (file_map, 'warm-async'), (range_control, 'warm-async')]
assert {case['id'] for case in read(quiet / 'representative.json')['cases']} == {case for case, lane in jobs}
write(quiet / 'jobs.json', jobs)
write(quiet / 'identity.json', dict(sourceRevision=head, productionHead=head,
    buildLogSHA256=digest(lab / 'ubuntu-core-build.log'),
    purpose='Quiet CPython comparison after direct generator reduction and exact sequence iterator delivery.',
    imageFiles={'candidate': image}, coreSHA256={role: image[core] for role in ('candidate', 'candidate-control')},
    auxiliaryFiles={name: sha for name, sha in image.items() if name != core},
    frozenImage=f'/home/lokad/lython-bench-checks/{stage}/candidate',
    catalogs={name: {'sha256': digest(quiet / name)} for name in ('representative.json', 'jobs.json')},
    expectedCPythonSHA256=measured['expectedCPythonSHA256'], cpythonWorkerSHA256=measured['cpythonWorkerSHA256'],
    donorArchiveSHA256=receipt['archiveSHA256']))

collect = (donor / 'collect.py').read_text(encoding='utf-8')
assert collect.count('len(jobs) == 5') == 1
collect = collect.replace('len(jobs) == 5', 'len(jobs) == 6').replace('lython-b1937-cpython-fixtures', 'lython-b1943-cpython-fixtures')
compile(collect, 'collect.py', 'exec')
save(quiet / 'collect.py', collect)
save(quiet / 'run.sh', (donor / 'run.sh').read_text(encoding='utf-8'))

paths = {name: quiet / name for name in ('identity.json', 'representative.json', 'jobs.json', 'cpython-worker.py', 'run.sh', 'collect.py')}
paths.update({f'candidate/{name}': quiet / 'local-image' / name for name in sorted(changed)})
payload = quiet / 'stage.tar.gz'
with tarfile.open(payload, 'w:gz') as archive:
    for name, path in paths.items():
        archive.add(path, arcname=name)
with tarfile.open(payload) as archive:
    assert all(archive.extractfile(name).read() == path.read_bytes() for name, path in paths.items())
manifest = {name: dict(length=path.stat().st_size, sha256=digest(path)) for name, path in paths.items()}
write(quiet / 'upload.json', dict(root=stage, donor=read(donor / 'upload.json')['root'], donorFiles=donor_files,
    donorArchive=receipt['archiveSHA256'], payloadSHA256=digest(payload), files=manifest,
    expandedBytes=sum(row['length'] for row in manifest.values()), minimumAfterStageBytes=16 * 1024 * 1024, caseCount=4))

launch = (previous / 'quiet-vm.py').read_text(encoding='utf-8')
assert launch.count('lython-b1937-current-cpython-retry') == 1
launch = launch.replace('lython-b1937-current-cpython-retry', 'lython-b1943-current-cpython')
# Reuse only stable, fully joined donor files. Read-only observation cannot launch.
compile(launch, 'quiet-vm.py', 'exec')
save(lab / 'quiet-vm.py', launch)

summary = (previous / 'summarize.py').read_text(encoding='utf-8').split("\nassert not terminal['receipt'].get('fixtures')")[0]
summary = summary.replace('e036d6597ca1ca11a1b2bc5327d4c2506b32d06c', head)
summary = summary.replace('==5', '==6').replace('==140', '==168').replace('{"donor":31}', '{"donor":30}')
compile(summary, 'summarize.py', 'exec')
save(lab / 'summarize.py', summary + '\n')
print(head, stage, len(jobs), 'lanes', len(changed), 'changed image files')
