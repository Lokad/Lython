using System.Collections;
using System.Reflection;
using System.Security.Cryptography;
using System.Text.Json;

var image = Path.GetFullPath(args[0]);
using var catalog = JsonDocument.Parse(File.ReadAllBytes(args[1]));
var assemblyPath = Path.Combine(image, "Lokad.Lython.dll");
var assembly = Assembly.LoadFrom(assemblyPath);
var engineType = assembly.GetType("Lokad.Lython.LythonEngine", throwOnError: true)!;
var engine = Activator.CreateInstance(engineType, [null])!;
var compile = engineType.GetMethod("Compile", [typeof(string)])!;
var observations = new List<object>();
foreach (var item in catalog.RootElement.GetProperty("cases").EnumerateArray())
{
    using var compiled = (IDisposable)compile.Invoke(engine, [item.GetProperty("source").GetString()])!;
    if (Property(compiled, "IsValid") is not true) throw new InvalidOperationException(item.GetProperty("id").GetString());
    var executable = compiled.GetType().GetField("_executable", BindingFlags.Instance | BindingFlags.NonPublic)!.GetValue(compiled)!;
    var entry = Property(executable, "EntryPoint")!;
    var layouts = new List<object>();
    Record(entry, layouts);
    observations.Add(new { id = item.GetProperty("id").GetString(), layouts });
}
Console.WriteLine(JsonSerializer.Serialize(new { core = Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(assemblyPath))).ToLowerInvariant(),
    catalog = Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(args[1]))).ToLowerInvariant(), observations },
    new JsonSerializerOptions { WriteIndented = true }));

static object? Property(object value, string name) => value.GetType().GetProperty(name,
    BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic)?.GetValue(value);

static void Record(object code, List<object> layouts)
{
    var instructions = (IEnumerable)Property(code, "Instructions")!;
    layouts.Add(new { name = Property(code, "Name"), firstTemporary = Property(code, "FirstTemporarySlot"),
        lastOwnedTemporary = Property(code, "LastOwnedTemporarySlot"), capacity = Property(code, "ValueStorageCapacity"),
        opcodes = instructions.Cast<object>().Select(ins => Property(ins, "OpCode")!.ToString()).ToArray() });
    foreach (var constant in (IEnumerable)Property(code, "Constants")!)
    {
        if (constant is null) continue;
        if (constant.GetType().Name == "ExecutableCodeObject") Record(constant, layouts);
        else if (Property(constant, "CodeObject") is { } nested && nested.GetType().Name == "ExecutableCodeObject") Record(nested, layouts);
    }
}
