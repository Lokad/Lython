#!/bin/bash
set -euo pipefail
root=/mnt/d/code/Lython/.git/agent-notes/review-20261031/matched-shipment-control-b1944-20261128/comparison/quiet
python=/mnt/d/code/Lython/.git/agent-notes/review-20261031/bench-cpython-3.13.16-runtime/runtime/bin/python3.13
export DOTNET_ROOT="$HOME/.dotnet"
"$DOTNET_ROOT/dotnet" "/mnt/d/code/Lython/.git/agent-notes/review-20261031/current-shipment-checkpoint-b1937-20261128/comparison/quiet/local-image/Lokad.Lython.Benchmarks.dll" --compare verify --catalog "$root/representative.json" --dotnet "$DOTNET_ROOT/dotnet" --python "$python" --python-worker "$root/cpython-worker.py" --out "$root/reference-local-verify.json"