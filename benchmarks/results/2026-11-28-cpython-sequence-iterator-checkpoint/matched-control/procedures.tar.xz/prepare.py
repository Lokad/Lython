from hashlib import sha256
from pathlib import Path
from shutil import copy2
import json
import tarfile

lab = Path(__file__).resolve().parent
old = lab.parent / 'current-shipment-checkpoint-b1937-20261128/comparison/quiet'
new = lab.parent / 'current-shipment-checkpoint-b1943-20261128/comparison/quiet'
quiet = lab / 'comparison/quiet'
quiet.mkdir(parents=True)
read = lambda p: json.loads(p.read_bytes())
digest = lambda p: sha256(p.read_bytes()).hexdigest()

def write(path, data):
    path.write_text(data, encoding='utf-8', newline='\n')
    assert b'\r' not in path.read_bytes()

def js(path, data):
    write(path, json.dumps(data, indent=2) + '\n')

images = {}
for role, folder in [('reference', old), ('candidate', new)]:
    identity = read(folder / 'identity.json')
    image = identity['imageFiles']['candidate']
    term = read(folder / 'terminal-status.json')
    assert not term['live'] and not term['fixtures'] and term['exitCode'] == '0'
    assert term['receipt']['complete'] and term['receipt']['allWorkersJoined'] and term['receipt']['quietBeforeAndAfter']
    assert digest(folder / 'observations.tar.xz') == term['receipt']['archiveSHA256']
    assert len(image) == 32 and {p.name: digest(p) for p in (folder / 'local-image').iterdir()} == image
    images[role] = dict(root=read(folder/'upload.json')['root'], archive=term['receipt']['archiveSHA256'],
                        files=image, revision=identity['sourceRevision'])
assert images['reference']['revision'].startswith('e036d6597') and images['candidate']['revision'].startswith('bf10eeaea')
assert {name for name, digest in images['reference']['files'].items() if images['candidate']['files'][name] != digest} == {'Lokad.Lython.dll', 'Lokad.Lython.Utf8Regex.dll'}
for name in ('representative.json', 'cpython-worker.py', 'run.sh'):
    copy2(new / name, quiet / name)
identity = read(new / 'identity.json')
assert digest(quiet/'representative.json') == identity['catalogs']['representative.json']['sha256']
assert digest(quiet/'cpython-worker.py') == identity['cpythonWorkerSHA256']
file_map = 'diagnostic.shipment-file-fed-map'
ordinary = 'diagnostic.shipment-row-generator-reduction'
js(quiet / 'jobs.json', [(file_map, 'warm-async'), (ordinary, 'warm-async')])
identity.pop('auxiliaryFiles')
identity.pop('donorArchiveSHA256')
identity.update(referenceRevision=images['reference']['revision'], donorArchives={role: d['archive'] for role, d in images.items()},
    purpose='Matched file-fed control and ordinary reduction after private generator and exact sequence iterator delivery.',
    frozenImage='/home/lokad/lython-bench-checks/script-matched-control-b1944-20261128/candidate',
    imageFiles={role: d['files'] for role, d in images.items()},
    coreSHA256={label: d['files']['Lokad.Lython.dll'] for role, d in images.items() for label in (role,role+'-control')})
identity['catalogs']['jobs.json']['sha256'] = digest(quiet/'jobs.json')
js(quiet/'identity.json', identity)
collect = (new/'collect.py').read_text(encoding='utf-8')
collect = collect.replace("{'candidate','candidate-control'}", "{'reference','reference-control','candidate','candidate-control'}")
a = collect.index('        command = (')
b = collect.index('        self.process =', a)
collect = collect[:a] + '''        role = label.removesuffix('-control')
        command = [str(dotnet), str(root / role / worker.name), '--compare', 'worker', '--catalog', str(catalog)]
''' + collect[b:]
a = collect.index("        if not label.startswith('CPython'):")
b = collect.index("        self.request('verify', 2)", a)
collect = collect[:a] + '''        expected = identity['imageFiles'][role]
        libraries = {Path(v['path']).name:v['sha256'].lower() for v in self.identity['libraries']}
        assert libraries['Lokad.Lython.dll'] == identity['coreSHA256'][label]
        assert libraries['Lokad.Lython.Benchmarks.dll'] == expected['Lokad.Lython.Benchmarks.dll']
        assert not self.identity['serverGc'] and not any(self.identity['runtimeOverrides'].values())
''' + collect[b:]
old_hash = "    for name, sha in identity['imageFiles']['candidate'].items():\n        assert hashlib.sha256((image/name).read_bytes()).hexdigest()==sha, name"
new_hash = "    for role, expected in identity['imageFiles'].items():\n        assert {path.name: digest(path) for path in (root/role).iterdir()} == expected"
assert collect.count(old_hash) == 1
collect = collect.replace(old_hash, new_hash).replace('len(jobs) == 6','len(jobs) == 2')
collect = collect.replace("['CPython','candidate-control','CPython-control','candidate']", "['reference','candidate-control','reference-control','candidate']")
collect = collect.replace('lython-b1943-cpython-fixtures','lython-b1944-matched-fixtures')
compile(collect, 'collect.py', 'exec')
write(quiet/'collect.py',collect)
paths = {name: quiet / name for name in ('identity.json','representative.json','jobs.json','cpython-worker.py','run.sh','collect.py')}
payload = quiet/'stage.tar.gz'
with tarfile.open(payload,'w:gz') as archive:
    for name,path in paths.items(): archive.add(path,arcname=name)
with tarfile.open(payload) as archive:
    assert all(archive.extractfile(name).read() == path.read_bytes() for name,path in paths.items())
js(quiet/'upload.json',dict(root='script-matched-control-b1944-20261128', donors=images, payloadSHA256=digest(payload),
    files={name:dict(length=path.stat().st_size,sha256=digest(path)) for name,path in paths.items()},
    expandedBytes=sum(path.stat().st_size for path in paths.values()), minimumAfterStageBytes=16*1024*1024, caseCount=4))
launch = (new.parents[1]/'quiet-vm.py').read_text(encoding='utf-8').replace('lython-b1943-current-cpython','lython-b1944-matched-control')
a = launch.index(" donor=base/cfg['donor']")
b = launch.index(' python=Path.home()',a)
launch = launch[:a] + ''' origins={}
 for role, donor in cfg['donors'].items():
  parent=base/donor['root']; origin=parent/'candidate'
  assert parent.parent==base and parent.resolve()==parent and origin.resolve()==origin
  receipt=json.loads((parent/'archive-receipt.json').read_text())
  assert receipt['complete'] and receipt['allWorkersJoined'] and receipt['quietBeforeAndAfter']
  assert sha(parent/'observations.tar.xz')==receipt['archiveSHA256']==donor['archive']
  assert {p.name:sha(p) for p in origin.iterdir()}==donor['files']
  origins[role]=origin
''' + launch[b:]
launch = launch.replace(" (root/'candidate').mkdir()", " for role in origins: (root/role).mkdir()")
a = launch.index(" assert image['donorArchiveSHA256']")
b = launch.index(" assert sha(python)",a)
launch = launch[:a] + ''' reused={}
 for role,origin in origins.items():
  expected=image['imageFiles'][role]
  assert len(expected)==32 and expected==cfg['donors'][role]['files']
  assert image['donorArchives'][role]==cfg['donors'][role]['archive']
  for name,digest in expected.items(): os.link(origin/name,root/role/name)
  assert {p.name:sha(p) for p in (root/role).iterdir()}==expected
  reused[role]=len(expected)
''' + launch[b:]
launch=launch.replace("'candidate-remote-verify.json','stage-custody.json'","'candidate-remote-verify.json','reference-remote-verify.json','stage-custody.json'")
compile(launch,'quiet-vm.py','exec')
write(lab/'quiet-vm.py',launch)
verify = (new.parents[1]/'verify.sh').read_text(encoding='utf-8')
verify = verify.replace(new.parents[1].name, lab.name).replace('"$root/local-image/Lokad.Lython.Benchmarks.dll"',
    '"'+old.as_posix().replace('D:/','/mnt/d/')+'/local-image/Lokad.Lython.Benchmarks.dll"')
verify = verify.replace('candidate-local-verify.json', 'reference-local-verify.json')
write(lab/'verify-reference.sh',verify)
print('Two matched lanes prepared from the completed frozen checkpoints.')
