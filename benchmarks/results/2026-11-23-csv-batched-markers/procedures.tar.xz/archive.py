from pathlib import Path
import gzip
import hashlib
import json
import shutil
import subprocess
import tarfile

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
quiet=lab/"comparison/quiet"
dest=repo/"benchmarks/results/2026-11-23-csv-batched-markers"
sha=lambda data:hashlib.sha256(data).hexdigest()
read=lambda path:json.loads(path.read_text(encoding="utf-8"))
def git(*args):
    return subprocess.check_output(["git",*args],cwd=repo)

identity=read(lab/"comparison/identity.json")
terminal=read(quiet/"terminal-status.json")
receipt=terminal["receipt"]
assert not terminal["live"] and terminal["exitCode"]=="0" and not terminal["fixtures"]
assert all(receipt[name] for name in ("complete","archivedAndVerifiedUnderLease","allWorkersJoined","guestFixturesRemoved","quietBeforeAndAfter"))
assert sha((quiet/"observations.tar.xz").read_bytes())==receipt["archiveSHA256"]
assert read(quiet/"summary.json")["timedBatches"]==168
assert all(row["peakAdmission"][0]==row["peakAdmission"][1] for row in read(lab/"allocation-summary-six.json"))
head=git("rev-parse","HEAD").decode().strip()
paths=git("diff","--name-only",identity["sourceRevision"],identity["candidate"],"--","src","tests").decode().splitlines()
assert len(paths)==2
source_diff=git("diff","--name-only",head,identity["candidate"],"--",*paths)
identity["retainedRevision"]=None if source_diff else head
assert not git("diff","--name-only",head,identity["candidate"],"--","tests")
identity["retainedTestRevision"]=head
patch=git("diff","--binary",identity["sourceRevision"],identity["candidate"],"--",*paths)
(lab/"comparison.patch").write_bytes(patch)
identity["comparisonPatchSHA256"]=sha(patch)
dest.mkdir(exist_ok=True)
assert all(path.name=="README.md" for path in dest.iterdir())
for role,files in identity["imageFiles"].items():
    assert len(files)==32 and all(sha((lab/role/name).read_bytes())==digest for name,digest in files.items())
    core=lab/role/"Lokad.Lython.dll"
    image=dest/"candidate-core.dll.gz" if role=="candidate" else dest.parent/"2026-11-23-retained-call-cpython/candidate-core.dll.gz"
    if role=="candidate":
        image.write_bytes(gzip.compress(core.read_bytes(),mtime=0))
    assert sha(gzip.decompress(image.read_bytes()))==files[core.name]
(dest/"identity.json").write_text(json.dumps(identity,indent=2)+"\n",encoding="utf-8",newline="\n")
for name in ("observations.tar.xz","summary.json","terminal-status.json"):
    shutil.copyfile(quiet/name,dest/name)
shutil.copyfile(lab/"allocation-summary-six.json",dest/"allocation-summary-six.json")
with tarfile.open(dest/"procedures.tar.xz","w:xz") as archive:
    for name in (
        "archive.py","prepare.py","stage.py","quiet.py","comparison.patch","summarize.py","allocations.py","allocations.log",
        "windows-frozen.log","windows-public.log","ubuntu-public.log","test-ubuntu.sh",
        "windows-retained.log","ubuntu-retained.log","test-ubuntu-retained.sh","quoted-crlf-test.patch",
        "reference-allocation-six.json","candidate-allocation-six.json","stage.log","retrieval.log",
        "comparison/reference-verify.json","comparison/candidate-verify.json","comparison/quiet/observe-not-before"):
        archive.add(lab/name,arcname=name)
print(dest,identity["retainedRevision"] or "private")
