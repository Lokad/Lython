set -e
export DOTNET_ROOT=/home/vermorel/.dotnet
export DOTNET_ROOT_X64=$DOTNET_ROOT
lab=/mnt/d/code/Lython/.git/agent-notes/review-20261031/csv-batched-markers-20261123
filter='FullyQualifiedName~Csv|FullyQualifiedName~StdlibCompatibilityMatrix'
$DOTNET_ROOT/dotnet test tests/Lokad.Lython.PublicApi.Tests/Lokad.Lython.PublicApi.Tests.csproj -c Release -f net10.0 --artifacts-path "$lab/ubuntu" --filter "$filter" > "$lab/ubuntu-public.log" 2>&1 || { tail -30 "$lab/ubuntu-public.log"; exit 1; }
tail -8 "$lab/ubuntu-public.log"
