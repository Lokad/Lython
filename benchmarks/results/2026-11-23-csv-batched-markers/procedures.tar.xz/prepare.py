from pathlib import Path
import gzip
import hashlib
import json
import os
import shutil
import subprocess

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
source=lab.parent/"retained-call-cpython-20261123"
prior=lab.parent/"supplied-scalar-return-20261123"
cases=lab.parent/"csv-deferred-number-20261123/comparison"
comparison=lab/"comparison"
comparison.mkdir(exist_ok=True)
read=lambda path:json.loads(path.read_text(encoding="utf-8"))
sha=lambda data:hashlib.sha256(data).hexdigest()
digest=lambda path:sha(path.read_bytes())
def git(*args):
    return subprocess.check_output(["git",*args],cwd=repo)
def install(name, donor, replacements):
    text=(donor/name).read_text(encoding="utf-8")
    for old,new in replacements:
        assert old in text,(name,old)
        text=text.replace(old,new)
    compile(text,name,"exec")
    (lab/name).write_text(text,encoding="utf-8",newline="\n")

base=read(source/"identity.json")
assert not git("diff","--name-only",base["sourceRevision"],"00ca00e7d","--","src","tests")
tree=repo/".git/agent-worktrees/csv-batched-markers-20261123"
assert not git("-C",tree,"status","--porcelain")
candidate=git("-C",tree,"rev-parse","HEAD").decode().strip()
assert git("-C",tree,"rev-parse","HEAD^")==git("rev-parse","00ca00e7d")
for name in ("representative.json","jobs.json"):
    shutil.copyfile(cases/name,comparison/name)
catalog=comparison/"representative.json"
core="Lokad.Lython.dll"
files=base["imageFiles"]["candidate"]
assert len(files)==32
images={}
dotnet=Path.home()/".dotnet11/dotnet.exe"
protocol=repo/"benchmarks/cpython-worker.py"
assert digest(protocol)==base["cpythonWorkerSHA256"]
env=dict(os.environ,DOTNET_ROOT=str(dotnet.parent),DOTNET_ROOT_X64=str(dotnet.parent))
for role in ("candidate","reference"):
    image=lab/role
    image.mkdir(exist_ok=True)
    for name,value in files.items():
        old=source/"candidate"/name
        assert digest(old)==value
        if role=="candidate" and name==core:
            old=lab/"frozen/bin/Lokad.Lython/release_net11.0"/core
        shutil.copyfile(old,image/name)
    images[role]={name:digest(image/name) for name in files}
    for name in ("ValidatedAllocation.dll","ValidatedAllocation.deps.json","ValidatedAllocation.runtimeconfig.json"):
        shutil.copyfile(prior/"candidate"/name,image/name)
    receipt=comparison/(role+"-verify.json")
    subprocess.run([dotnet,image/"Lokad.Lython.Benchmarks.dll","--compare","verify","--catalog",catalog,
                    "--dotnet",dotnet,"--python","C:/Python313/python.exe","--python-worker",protocol,"--out",receipt],
                   env=env,timeout=90,check=True)
    proof=read(receipt)
    assert proof["state"]=="Completed" and proof["caseCount"]==5
    assert proof["launched"]["library"]["sha256"]==images[role][core]
    assert all(digest(image/name)==h for name,h in images[role].items())
assert [name for name in files if images["reference"][name]!=images["candidate"][name]]==[core]
identity=dict(sourceRevision=base["sourceRevision"],sourceImageRevision=base["candidate"],candidate=candidate,
    purpose="B1511 reuse a managed CSV delimiter mask within the same admitted line",
    imageFiles=images,coreSHA256={key:images[role][core] for role in images for key in (role,role+"-control")},
    cpythonWorkerSHA256=base["cpythonWorkerSHA256"],expectedCPythonSHA256=base["expectedCPythonSHA256"],
    catalogs={name:dict(sha256=digest(comparison/name)) for name in ("representative.json","jobs.json")})
(comparison/"identity.json").write_text(json.dumps(identity,indent=2)+"\n",encoding="utf-8",newline="\n")

tracked="benchmarks/results/2026-11-23-supplied-scalar-return/"
def pushed(name): return git("show","origin/master:"+tracked+name)
old=json.loads(pushed("identity.json"))
tracked_receipts={}
for prefix in ("","repeat-"):
    result=json.loads(pushed(prefix+"terminal-status.json"))["receipt"]
    assert result["complete"] and result["allWorkersJoined"] and result["archivedAndVerifiedUnderLease"]
    assert sha(pushed(prefix+"observations.tar.xz"))==result["archiveSHA256"]
    tracked_receipts[prefix]=result["archiveSHA256"]
old_core=gzip.decompress(pushed("candidate-core.dll.gz"))
assert sha(old_core)==old["imageFiles"]["candidate"][core]
assert all(digest(prior/"candidate"/n)==h for n,h in old["imageFiles"]["candidate"].items())
proof=dict(core=sha(old_core),size=len(old_core),archive=tracked_receipts[""],repeat=tracked_receipts["repeat-"])
install("stage.py",prior,[
    ("supplied-scalar-return-b1504-20261123","csv-batched-markers-b1511-20261123"),
    ("eager-isolated-definition-b1502-20261123","retained-call-cpython-b1510-20261123"),
    ("'lython-b1504-fixtures'","'lython-b1511-fixtures'"),
])
install("quiet.py",prior,[
    ("lython-b1504-supplied-scalar-return-20261123","lython-b1511-csv-batched-markers-20261123"),
    (".+b1504-",".+b1511-"),
    ("lython-b1504-stage-","lython-b1511-stage-"),
    ("A 120 MiB","A 112 MiB"),("120 * 1024 * 1024","112 * 1024 * 1024"),
    ("staged_bytes + 1024 * 1024","staged_bytes + 3 * 1024 * 1024"),
    ("minimum_active + 1024 * 1024","minimum_active + 3 * 1024 * 1024"),
    ("  assert free >= minimum,", """
  if free < minimum:
   proof=RETIREMENT_PROOF
   earlier=base/'supplied-scalar-return-b1504-20261123'
   repeat=base/'supplied-scalar-control-b1505-20261123'
   replica=earlier/'candidate/Lokad.Lython.dll'
   info=replica.lstat()
   assert replica.resolve()==replica and stat.S_ISREG(info.st_mode)
   assert info.st_uid==os.getuid() and info.st_nlink==1 and info.st_size==proof['size']
   assert digest(replica)==proof['core']
   assert digest(earlier/'observations.tar.xz')==proof['archive']
   assert digest(repeat/'observations.tar.xz')==proof['repeat']
   assert not (earlier/'guest-fixtures').exists() and not (repeat/'guest-fixtures').exists()
   replica.unlink()
   free=shutil.disk_usage(base).free
   print(json.dumps(dict(retiredWorkingReplica=str(replica),sha256=proof['core'],freeAfterRetirement=free)),flush=True)
  assert free >= minimum,""".replace("RETIREMENT_PROOF",repr(proof))),
])
for name in ("allocations.py","summarize.py"):
    shutil.copyfile(prior/name,lab/name)
