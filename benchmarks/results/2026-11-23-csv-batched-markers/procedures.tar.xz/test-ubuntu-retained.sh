set -e
export DOTNET_ROOT=/home/vermorel/.dotnet
export DOTNET_ROOT_X64=$DOTNET_ROOT
lab=/mnt/d/code/Lython/.git/agent-notes/review-20261031/csv-batched-markers-20261123
$DOTNET_ROOT/dotnet test tests/Lokad.Lython.PublicApi.Tests/Lokad.Lython.PublicApi.Tests.csproj -c Release -f net10.0 --artifacts-path "$lab/ubuntu-retained" --filter 'FullyQualifiedName~CsvNativeInputTests' > "$lab/ubuntu-retained.log" 2>&1 || { tail -30 "$lab/ubuntu-retained.log"; exit 1; }
tail -9 "$lab/ubuntu-retained.log"
