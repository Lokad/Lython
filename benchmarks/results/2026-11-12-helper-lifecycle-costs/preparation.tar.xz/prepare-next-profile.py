from pathlib import Path
import ast,hashlib,json,subprocess,tarfile
r=Path('.git/agent-notes/review-20261031/helper-lifecycle-r258');r.mkdir();q=r/'b604';q.mkdir();old=r.parent/'current-runtime-r253/b599';last=r.parent/'receiver-operations-r256/b603'
sha=lambda b:hashlib.sha256(b).hexdigest();name='helper-lifecycle-b604-20261112';unit='lython-b604-helper-lifecycle-20261112'
identity=json.loads((last/'identity.json').read_text(encoding='utf-8'));identity['coreSHA256'].pop('candidate-control');identity['sourceRevision']='82ed92d4 production, unchanged9906efc8 evidence. Guarded/native helper-search CPU windows after R256; same worker/core0106/adapter0.4. Nearly equal allocation~88B/command apart, externalwarm2.30-2.33x versus1.61-1.64xCPython. No elapsed comparison or removable-share forecast; fullCI43139754244 originalstress active.'
(q/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8');(q/'source-identity.json').write_bytes((last/'source-identity.json').read_bytes());(q/'catalog.json').write_bytes((last/'representative.json').read_bytes())
meta=json.loads((r.parent/'receiver-operations-r256/refined/diagnostic-identity.json').read_text(encoding='utf-8'))
for n,h in meta['sourceHashes'].items():assert sha(Path(n).read_bytes())==h,n
for n in ['ops-profile.py','analyze-cpu-guest.py','archive.py','run.sh','launch.py','retrieve-original.py','remote-launch.py']:
 t=(old/n).read_text(encoding='utf-8').replace('current-runtime-b599-20261112',name).replace('lython-b599-current-runtime-20261112',unit).replace('current-runtime-b599-launch.py','helper-lifecycle-b604-launch.py').replace('lython-b599-fixtures','lython-b604-fixtures').replace('B599','B604').replace('captured-text','guarded-search').replace('helper-search','native-search')
 if n=='ops-profile.py':
  t=t.replace('scripts.text-summary-helpers.nonlocal-counter.large','scripts.file-search.guarded-helper.large')
  t=t.replace('TryExecuteDictionaryLoop TryExecuteCallInstruction EvaluateNativeReturn GuardNativeReturn','BeginPendingCall BeginBoundCall TryExecuteNativeCall ExecuteInstructionPrefix BindFunctionArgumentsInto')
 if n=='remote-launch.py':
  t=t.replace("source=base/'native-inputs-b597-20261112/candidate'", "source=base/'receiver-ops-b602-20261112/candidate'")
  a=t.index('protected=');b=t.index("with(base/'comparison-vm.lock')",a);t=t[:a]+"protected={source/'Lokad.Lython.dll':config['identity']['coreSHA256']['candidate'],base/'native-inputs-b597-20261112/candidate/Lokad.Lython.dll':'c9829194548b8c94b1f2bb4c4d5d3eea548d43b4b10a4920e27d273d9e64b351'}\n"+t[b:]
 if n=='retrieve-original.py':
  needle="r=Path(__file__).parent;assert not (r/'terminal-status.json').exists()"
  assert needle in t;t=t.replace(needle,needle+"\nbound=json.loads((r/'observe-not-before.json').read_text(encoding='utf-8'))\nassert datetime.datetime.now(datetime.timezone.utc)>=datetime.datetime.fromisoformat(bound['doNotObserveBeforeUTC'])")
 (q/n).write_text(t,encoding='utf-8',newline='\n')
 if n.endswith('.py')and n!='remote-launch.py':ast.parse(t)
with tarfile.open(q/'payload.tgz','w:gz')as a:
 for n in ['catalog.json','identity.json','source-identity.json','ops-profile.py','analyze-cpu-guest.py','archive.py','run.sh']:a.add(q/n,arcname=n)
with tarfile.open(q/'payload.tgz')as a:expanded=sum(((m.size+4095)//4096)*4096 for m in a.getmembers())
retire=[]
p=Path('benchmarks/results/2026-11-12-receiver-cpython-checkpoint/observations.tgz');b=p.read_bytes();assert b==subprocess.check_output(['git','show','HEAD:'+p.as_posix()])
retire.append(dict(kind='exact',knownPath='receiver-cpython-b603-20261112/observations.tgz',bytes=len(b),sha256=sha(b),canonicalStorage=p.as_posix(),reason='Exact committed terminal raw duplicate; fresh idle/UID/path/inode/allaliases proof. Current0106 and priorc982 protected, floors unchanged.'))
with tarfile.open(p)as a:data=a.extractfile('representative.json').read()
retire.append(dict(kind='exact',knownPath='receiver-cpython-b603-20261112/representative.json',bytes=len(data),sha256=sha(data),canonicalStorage=p.as_posix(),canonicalEntry='representative.json',canonicalArchiveSHA256=sha(b),reason='Exact committed unused terminal catalog duplicate; fresh path/UID/inode proof.'))
p=Path('benchmarks/results/2026-11-08-independent-native-proof/observations.tar.xz');container=p.read_bytes();assert container==subprocess.check_output(['git','show','HEAD:'+p.as_posix()])
with tarfile.open(p)as a:b=a.extractfile('b474/observations.tgz').read()
retire.append(dict(kind='exact',knownPath='independent-proof-b474-20261108/observations.tgz',bytes=len(b),sha256=sha(b),canonicalStorage=p.as_posix(),canonicalEntry='b474/observations.tgz',canonicalArchiveSHA256=sha(container),reason='Exact committed unused terminal raw duplicate; source/core/evidence preserved, fresh path/UID/inode/allaliases proof.'))
config=dict(root='/home/lokad/lython-bench-checks/'+name,unit=unit,payloadBytes=(q/'payload.tgz').stat().st_size,payloadSHA256=sha((q/'payload.tgz').read_bytes()),requiredFreeBytes=252*1024*1024+expanded+65536,retire=retire,identity=identity)
(q/'config.json').write_text(json.dumps(config,indent=2)+'\n',encoding='utf-8');ast.parse((q/'remote-launch.py').read_text(encoding='utf-8').replace('config=CONFIG','config='+repr(config)).replace('inventoryOnly=INVENTORY_ONLY','inventoryOnly=True'))
for n in ['ops-profile.py','run.sh','archive.py']:assert 'guarded-search'in(q/n).read_text(encoding='utf-8')and'native-search'in(q/n).read_text(encoding='utf-8'),n
print('Two6s guarded/native windows,120sowner/180sobservation; same existing protocol, source/fixture/cleanup gates; fresh inventory before mutation.')
