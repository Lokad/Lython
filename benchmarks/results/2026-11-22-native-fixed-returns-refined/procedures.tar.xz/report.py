from pathlib import Path
import json

lab=Path(__file__).resolve().parent
read=lambda path:json.loads(path.read_text(encoding="utf-8-sig"))
runs=read(lab/"quiet/quiet-summary.json")
ident=read(lab/"identity.json")
decision=read(lab/"decision.json")
alloc=read(lab/"allocation-summary.json")[0]
labels={
    "scripts.csv-invoice.helper-accumulation":"Nested-helper CSV invoice",
    "scripts.csv-invoice.large":"Ordinary CSV invoice",
    "scripts.csv-invoice.method-policy.quoted-control":"Quoted policy CSV invoice",
    "scripts.json-lines-shipment.expanded-options.large":"JSON Lines shipment report",
    "diagnostic.helper-placement.function-call":"Function-scoped helper",
    "diagnostic.helper-placement.module-call":"Module-scoped helper",
    "scripts.annotated-rule-closures.literal-positional-dynamic-keyword":"Mixed factory",
}
rows=["| Complete script | Boundary | Elapsed change | Wider process CPU change | Worker spread old/new |",
      "| --- | --- | ---: | ---: | ---: |"]
span=lambda a:f"{min(a):+.2f} to {max(a):+.2f}%"
for row in runs["rows"]:
    phase={"warm":"warm","compile-run":"compile to result"}[row["lane"]]
    rows.append(f"| {labels[row['case']]} | {phase} | {span(row['elapsedChangePercent'])} | {span(row['cpuChangePercent'])} | "
                f"{row['referenceSpreadPercent']:.2f} / {row['candidateSpreadPercent']:.2f}% |")
report=f"""# B1368 Isolate nested fixed return preparation

Compared the frozen `{ident['reference'][:9]}` core from delivery
`{ident['deliveryReference']}` with `{ident['candidate'][:9]}` on
November 22, 2026 UTC on the quiet Azure F4as_v7 with Ubuntu 24.04.4
and .NET 11 RC3. The rest of the 32-file image is identical, including
the benchmark worker and optional adapter.

The refinement keeps the ordinary call signature and retirement
check. The fixed path uses the tape's existing ownership bound.
Native-to-native calls forward a fixed tuple return into their
already-funded operand slots. The existing admission check still funds
its retained elements. The result stays private until the callee closes.
The same activation can update an exact dictionary when its existing
storage and key rules allow the write. Tuple length mismatches, capacity
growth, dynamic keys, protocols and actual suspension keep the ordinary
continuation path. The compiler emits the same 23 inspected tapes.

The helper-driven invoice allocates {alloc["candidateBytes"]:,} bytes
per warm run on Windows, down from {alloc["referenceBytes"]:,}
bytes (**{-alloc['allocationChangePercent']:.2f}%**). The implementation
removes the temporary returned tuple and an otherwise materialized
caller when the funded dictionary accepts the write. Every admitted
peak matches and every borrowed allowance returns to baseline.
All eight complete workloads and six targeted semantic probes match
CPython 3.13.2 on both frozen images.

## Quiet comparison

"""+ "\n".join(rows)+f"""

Negative changes favor the candidate. Ranges span all pairings of two
process medians per image. The sample has seven rotating batches per
worker after at least eight seconds of warmup. Warm clocks include the
run, applicable mediated RAM-backed I/O, output verification and
prior-result cleanup. Compile to result adds compilation and disposal
of the compiled owner. Wider CPU also includes the worker's reset and
request handling. Startup remains separate.

All 112 timed batches and both quiet gates passed in
{runs['elapsedSeconds']:.0f} seconds. Workers joined and the raw
archive was checked under the lease before cleanup. The exact source
pair passes 912 focused Release checks per platform. The checks cover
wider returns, repeated aliases, target order, capacity growth, real
host suspension, cancellation, refusal and shared allowance reuse.
The initial control regressions and the previous platform fixture
failure remain in B1367.

Local Windows x64 disassembly without tiering shows that the generic
instruction prefix returned from 11,970 bytes in B1367 to the original
11,896 bytes. The native call helper went from 809 bytes originally to
1,135 in B1367 and 871 here. This establishes the code-size change. The
quiet clocks use normal Linux tiering.

The first storage preflight stopped before contacting the VM. The
launch reused the byte-identical archived B1367 catalog, reverified
with both B1368 images and under the VM lease. The original disk floor,
timing phases and goldens remain in effect.

## Decision

{decision["readerDecision"]}

[Summary](summary.json) · [Local allocation](allocation-summary.json) ·
[Executable shape](shape-summary.json) · [Raw observations](observations.tgz) ·
[Verification and procedures](procedures.tar.xz) ·
[First version and adverse controls](../2026-11-22-native-fixed-returns/README.md).
"""
(lab/"README.md").write_text(report,encoding="utf-8",newline="\n")
