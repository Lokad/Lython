# Lokad.Lython 0.11.0

Updated November 22, 2026 UTC. Publication and tagging are postponed.
Current comparisons and revision-specific history are linked below.
[Benchmarks](docs/BENCHMARKS.md) · [Experiment index](benchmarks/EXPERIMENTS.md).

## Delivery

| Milestone | Status |
| --- | --- |
| Native nested fixed returns | B1367 keeps `2ae6b61c9` private. Helper-driven invoice warm elapsed falls 14.90–20.83% and allocation falls 39.75%. Quoted invoice elapsed rises 3.16–4.86%, and mixed time to result rises 2.38–7.79%. Function-helper timing is inconclusive. Both platforms pass 912 focused checks, 23 inspected code objects retain their layout and all 196 timed batches verify. Refinement `7a8df051a` keeps the normal call signature and existing retirement check. [B1367](benchmarks/results/2026-11-22-native-fixed-returns/README.md). |
| Checked private augmented operands | Committed at `3d88c8095` with the measured production and test source from `638fc1138`. The original bound check stays before the call and the augmented operation consumes the final local slot. One temporary disappears. The function-scoped helper runs 7.29–8.60% faster warm and allocates 45.89% less. The helper-driven CSV invoice allocates 2.10% less and its clocks span zero. Mixed first-use is 2.05–2.66% slower initially and reverses direction under a variable reference. Initial module-helper CPU rises 0.54–3.04%. Both platforms pass 666 focused checks and a nine-case rerun. Goldens, all 280 timed batches and allowance reuse verify. [B1364 and B1365](benchmarks/results/2026-11-22-checked-augmented-local/README.md). |
| Matched helper operand placement | B1363 holds the 2,048 calls and arithmetic constant. Wrapping the loop reduces Lython warm elapsed 11.81–14.46%, while CPython reduces elapsed 34.34–40.47%. With scope held fixed, both Lython call versions allocate 65,504 more bytes when the accumulator is read before each call. All 112 quiet batches and six local CPython goldens verify. The reordered scripts are diagnostics. [B1363](benchmarks/results/2026-11-22-matched-helper-placement/README.md). |
| Current CPython comparison and CPU attribution | B1361 verifies 140 timed batches on exact production `eb227dcac`. The range loop takes 1.052–1.061× CPython's time, the supplied helper 1.675–1.787×, ASCII meter 1.203–1.226× and quoted invoice 1.144–1.150×. Mixed time to result overlaps the prior reading with 8.88% Lython-worker spread. B1362 profiles the two loop scripts, with independent warmup and no file I/O in either. [B1361](benchmarks/results/2026-11-22-machine-arithmetic-cpython/README.md) · [B1362](benchmarks/results/2026-11-22-post-arithmetic-invocation-profile/README.md). |
| Direct signed arithmetic | Committed at `eb227dcac`. Replaces widened arithmetic and narrowing checks with signed overflow detection. Mixed and fully supplied factory warm CPU fall 1.95–3.36% and 0.82–2.70%. Mixed time to result and range-loop elapsed span zero. The quoted invoice takes 0.15–0.35% longer elapsed, and the ordinary invoice control varies 13.51%. Both platforms pass 486 focused checks. All 196 timed batches verify with flat allocation and full allowance refunds. [B1360](benchmarks/results/2026-11-22-signed-integer-kernel/README.md). |
| Prepared integer continuations | Committed at `15f4b06de`. Removes runtime successor discovery from both execution loops. The fully supplied helper uses 1.52–3.67% less warm CPU, and the ordinary invoice uses 0.95–2.88% less. Factory timings span zero. The typed ASCII control is unstable. Both platforms pass 447 focused checks on the measured source and 614 combined checks with regex mode validation. All 224 timed batches and 25 compiled code objects verify. [B1359](benchmarks/results/2026-11-22-prepared-integer-continuations/README.md). |
| First native capture construction | Fully qualified at `2f9f818b9`. Constructs a prepared first local cell with its callable and removes the general capture walk and separate reservation on that path. Mixed warm elapsed falls 2.11–7.56%, and time to result falls 8.95–13.16% with lower CPU. Eager, postponed and supplied controls span zero. Both platforms pass 575 focused checks. All 168 timed batches verify with matching admitted peaks and refunds. Windows and Ubuntu pass both Release targets, stress and installed-package consumers at source-equivalent `c8ab67ddd`. [B1354](benchmarks/results/2026-11-22-native-single-capture-construction/README.md) · [Passing gate](https://github.com/Lokad/Lython/actions/runs/45009843728). |
| Direct lexical keyword defaults | Fully qualified at `285628a43`. Uses the existing operand and shares one admission with the callable. Mixed warm elapsed falls 5.99–10.03%. Time to result falls 2.61–5.60% initially and 5.87–7.89% in confirmation. Warm allocation and admitted peaks match. Both platforms pass 497 focused checks and all 280 timed batches verify. Eager and fully supplied timing remain uncertain. Windows and Ubuntu pass both Release targets, stress and installed-package consumers. [B1352](benchmarks/results/2026-11-22-direct-lexical-keyword-defaults/README.md) · [Passing gate](https://github.com/Lokad/Lython/actions/runs/45006317326). |
| Direct range iteration | Committed at `72e1131b9`. Removes two iterator wrappers from executable loops. The arithmetic loop uses 14.04–15.28% less warm CPU. The mixed factory is inconclusive initially, then uses 2.50–7.20% less time-to-result CPU in confirmation. Its warm magnitude remains uncertain. Materialization timing spans zero. Both platforms pass 1,982 focused checks, and all 168 timed batches verify with equal peaks and full refunds. [B1350](benchmarks/results/2026-11-22-direct-range-cursors/README.md) · [Push CI](https://github.com/Lokad/Lython/actions/runs/45004054384). |
| Fused regex range projection | Fully qualified at `bcdf0ca6d`. ASCII group text uses 1.45–4.35% less warm CPU. Unicode timings span zero and allocation is flat. Both platforms pass 699 focused checks and all 112 batches verify. The original post-sampling archiver failure and recovered evidence are retained. Windows and Ubuntu pass both Release targets, original-scale stress and installed-package consumers. [B1349](benchmarks/results/2026-11-22-fused-regex-range-projection/README.md) · [Push CI](https://github.com/Lokad/Lython/actions/runs/45002869306) · [Delivery gate](https://github.com/Lokad/Lython/actions/runs/45002888396). |
| Computed integer capture stores | Committed at `12cecc6cf`. Computed-text warm elapsed falls 2.51–4.57% and local allocation falls 18.05% with equal admitted peaks and full refunds. The prior counter regression is absent in this source pair. Computed time to result and the fully supplied helper span zero. Both platforms pass 786 focused checks and all 140 timed batches verify. [B1348](benchmarks/results/2026-11-22-computed-capture-stores/README.md) · [Passing push CI](https://github.com/Lokad/Lython/actions/runs/45001509800). |
| On-demand executable jump targets | Committed at `f44a3c462`. Removes the eager traversal and separate jump-target array. Dataclass compilation uses 0.53–1.90% less CPU. Dead-heavy elapsed and validator time to result span zero. Both platforms pass 2,354 focused checks and all 140 timed batches verify. One initial Ubuntu stack-fixture failure did not recur on the same build. Push CI passes on both platforms. [B1346](benchmarks/results/2026-11-22-demanded-jump-targets/README.md) · [Push CI](https://github.com/Lokad/Lython/actions/runs/44999209850). |
| Direct function-default staging | Committed at `fd41c741e`. Two instructions replace three operation descriptors and their constant-table dispatch. Local compiler allocation falls by 304–424 bytes on affected scripts. Default-observing warm CPU falls 1.91–5.02%. Mixed time to result is 2.32–5.26% slower initially and spans zero with a moving unchanged control on confirmation. Both platforms pass 5,760 focused checks, all 252 timed batches verify, and both samples remain in the evidence. Windows and Ubuntu push CI pass. Windows and Ubuntu pass both Release targets, original-scale stress and installed-package consumers at production-equivalent `6b5ae7c26`. [B1343](benchmarks/results/2026-11-22-direct-default-instructions/README.md) · [Push CI](https://github.com/Lokad/Lython/actions/runs/44996823592) · [Full gate](https://github.com/Lokad/Lython/actions/runs/44997815480). |
| Short ASCII decimal parsing | Committed at `2d4fb517b`. Typed ASCII and explicit float warm elapsed fall 2.76–10.98% and 5.23–9.28%, with lower CPU. Typed ASCII time to result falls 5.33–8.38%. Allocation is flat. Unicode magnitude remains uncertain and the integer invoice spans zero. Both platforms pass 1,403 focused checks and all 140 timed batches verify. Push CI passes on both platforms. Both Release targets, original-scale stress and package consumers pass in the `6b5ae7c26` delivery. [B1339](benchmarks/results/2026-11-22-complete-decimal-ascii/README.md) · [Push CI](https://github.com/Lokad/Lython/actions/runs/44991744461). |
| Direct positional numeric calls | Fully qualified at `e961df912`. Three complete meter reports run 9.08–15.74% faster warm and allocate 30.64–43.68% less locally. Typed ASCII reaches the result 13.81–16.43% sooner. The sync invoice is 0.16–2.47% slower elapsed and its CPU spans zero. Both platforms pass 1,366 focused checks and all 140 timed batches verify. Windows and Ubuntu pass both Release targets, installed-package consumers and original-scale stress. [B1335](benchmarks/results/2026-11-22-numeric-extrema-operands/README.md) · [Push CI](https://github.com/Lokad/Lython/actions/runs/44988325754) · [Full delivery gate](https://github.com/Lokad/Lython/actions/runs/44988466219). |
| Literal positional defaults and direct CSV unpack | Fully qualified at `318bf0e0a`. The two literal factories allocate 15.51–18.09% less, and the mixed factory takes 10.71–14.42% less time to result. Dynamic-default and helper controls span zero. Typed ASCII and explicit-float CSV use 4.88–5.89% and 3.10–4.81% less warm CPU. Ordinary async invoice recovers and sync invoice spans zero. Windows and Ubuntu pass both Release targets, installed-package consumers and original-scale stress. [CSV](benchmarks/results/2026-11-22-csv-compiled-unpack/README.md) · [Defaults](benchmarks/results/2026-11-22-compiled-literal-defaults-keywords/README.md) · [Gate](https://github.com/Lokad/Lython/actions/runs/44980469927). |
| Shared lexical facts and retained CSV storage | Fully qualified at `8c81fb8d2`, including shared suite analysis, direct UTF-8 float parsing and quoted field ranges. Dataclass compilation takes 7.81–9.86% less time, while factory compilation spans zero. Quote-heavy reports use 5.31–5.99% less warm CPU and the plain invoice has a small elapsed regression. [Compiler](benchmarks/results/2026-11-22-sparse-lexical-preparation/README.md) · [Quoted ranges](benchmarks/results/2026-11-22-csv-quoted-ranges/README.md) · [Gate](https://github.com/Lokad/Lython/actions/runs/44971655453). |
| Callable metadata and UTF-8 ownership | Fully qualified through `4337b7765`. Inline keyword-default storage lowers eager and postponed factory allocation. Explicit UTF-8 ownership fixes retained borrowed-input aliases. [Defaults](benchmarks/results/2026-11-21-inline-keyword-default/README.md) · [Ownership](benchmarks/results/2026-11-21-explicit-utf8-ownership/README.md) · [Gate](https://github.com/Lokad/Lython/actions/runs/44960991856). |
| Original compiler facts, helper returns and formatting | The shared compiler graph correction `61237f58` and direct UTF-8 formatting/storage are delivered. Helper returns are fully qualified at `8f07764a`. Allocation falls 19.92% on CSV and 19.31% on JSON. Elapsed results and the adverse text control are diagnostic. Formatting allocates 8.67% less. Controlled confirmation supports 5–8% lower elapsed and CPU. The original adverse elapsed reading remains unexplained and merits reopening if reproduced. [Compiler facts](benchmarks/results/2026-11-20-shared-executable-graph/README.md) · [Native returns](benchmarks/results/2026-11-02-native-function-returns/README.md) · [Formatting](benchmarks/results/2026-11-02-formatting-confirmation/README.md). |

## Runtime roadmap

1. **Remove a complete stage of ordinary call setup or result
   transport.** The strongest retained results come from avoiding
   temporary storage and publication. B1364 removes one temporary
   and the eager scalar box before a call in a private local. It
   preserves the original unbound check and leaves captured or
   globally mutable values on the snapshot path. B1362 attributed
   many samples to instruction dispatch and arithmetic, including
   completed useful work. B1363 shows that the remaining helper
   gap spans both module and function scope. Earlier combined
   activation and argument arenas made whole scripts slower.

   Attribute the remaining fully supplied call on the delivered
   source using the function-scoped helper and the helper-driven
   invoice. Compare its existing final-slot binding and result
   consumption with useful arithmetic, dispatch and ownership
   cleanup. Select a representation only if it eliminates a full
   staging boundary or allocation. Keep scope guards, aliases,
   live default and target mutation, left-to-right errors, nested
   slots, true async transfer and managed stack checks. Reuse the
   ordinary execution machinery and remove the displaced path.

   B1366 finds 31 invoice samples closest to native frame creation
   and 27 memory reserves from tuple construction. The existing
   invoice tape shows a closed `price_line` return followed by
   fixed unpack in the native `accumulate` caller. Reuse the
   existing caller slots, tuple admission and return cleanup on
   that edge. Keep the helper native through a dictionary update
   only when the established exact key accepts the existing
   non-growing write. This eliminates a temporary tuple and the
   materialized frame on eligible rows. Reuse the existing
   continuation for dynamic unpack, growth, errors and suspension.
   Demonstrate exact tuple element identity, left-to-right binding,
   refused admission before visible output, and unchanged per-key
   mutation order before timing. Reassess the broader call cost
   after this whole-script transport stage.

   B1367 confirms the tuple and frame staging cost in the complete
   helper-driven invoice. Its quoted invoice and mixed factory
   regress. B1368 restores the ordinary retirement check, keeps
   the ordinary call signature and uses the existing tape bound
   to prove the rare fixed-return destination holds no owned
   temporary. Preserve forwarding and the exact dictionary write.
   Compare the complete affected invoice and the three original
   high-signal controls. Retain initial adverse evidence if the
   result stays uncertain. If the original sustained regression
   remains, weigh it against affected CSV gains before promotion.

   [B1366](benchmarks/results/2026-11-22-post-checked-local-call-profile/README.md).

   Check warm helper and mixed first use, both invoices and a
   representative JSON or text report. Retain the plain range loop
   and typed ASCII meter as shared controls. Report allocation and
   CPU separately. Revisit the module-helper CPU debt and original
   mixed first-use slowdown in this comparison. B1365 failed to
   reproduce the mixed direction with a 14.35% reference spread.
   Compilation alone spans zero. Keep that uncertainty visible.
   Keep callable and captured storage funded and preserve the
   fused first-cell and keyword-default construction.

   [B1364 and B1365](benchmarks/results/2026-11-22-checked-augmented-local/README.md) ·
   [B1363](benchmarks/results/2026-11-22-matched-helper-placement/README.md) ·
   [B1362](benchmarks/results/2026-11-22-post-arithmetic-invocation-profile/README.md) ·
   [Earlier complete call designs](benchmarks/results/2026-11-16-complete-call-design/README.md).

2. **Construct records and text in final storage.**
   Assess removing the decoded physical-line copy for complete literal
   CSV records. Process an existing reader window through final field
   materialization while it remains funded. Cross-window and escaped
   records can use the existing parser backing. Preserve line consumption
   on errors, bounded scans, reentrant admission and delayed close.
   Compare the ASCII and Unicode meters, ordinary and policy invoices,
   and a file-iteration control. Stop this design if it needs a new
   owner, changes reentrant read behavior or duplicates the scanner.
   The present reader ends its active read before field admission.
   An admission callback can then read the same file. Holding that
   read guard through materialization would change reentry. Transferring
   the window to the execution owner would keep otherwise temporary
   backing charged across the batch. Keep the existing copy until
   the reader can preserve both that reentry and the borrow lifetime.

   B1355 keeps `e04d22fc2` private. It removes both per-row identity
   scans for an unexposed automatic header and invalidates the proof
   if `fieldnames` becomes visible during admission. Ordinary invoice,
   policy invoice and restock timing span zero, and the typed-meter
   control uses 1.47–2.91% more CPU. Both platforms pass 528 focused
   checks, and all 140 timed batches verify with matching peaks and
   refunds. Revisit if the existing record layout can carry the proof
   or if further evidence shows header validation dominates.

   The bulk CSV reassessment kept final row backing, field ranges,
   bulk output, direct float parsing and fixed unpack into existing
   operands. Select a further design that removes a scan, copy,
   conversion or temporary container. Preserve quoting, error order,
   UTF-8 boundaries, async I/O, admission and retained aliases. Compare
   the typed ASCII, explicit-float and Unicode meters, ordinary and
   policy invoices, and affected JSON or text reports. Numeric tuple
   and CSV slot variants leave regressions, and JSON suffix decoding
   remains inconclusive. Refine only when a design removes work without
   widening common backing. The broad B1338 decimal variant remains
   private after adverse Unicode and invoice results. B1339 retains
   the narrower parser with flat allocation and uncertain Unicode CPU.
   [Bulk construction](benchmarks/results/2026-11-15-csv-final-payload/README.md) ·
   [B1355](benchmarks/results/2026-11-22-private-csv-header-layout/README.md) ·
   [CSV transport](benchmarks/results/2026-11-22-csv-numeric-slot-ingress/README.md) ·
   [JSON suffix](benchmarks/results/2026-11-22-json-decoded-suffix/confirmation/README.md) ·
   [B1338](benchmarks/results/2026-11-22-complete-decimal-token/README.md).

3. **Remove repeated frontend construction.**
   Displace a complete layout pass or intermediate tape. Preserve
   physical operand order, reachable instructions, exception regions,
   diagnostics, cancellation and disposal. Compare generated validator
   compilation and time to result, dataclasses, factories, a protected
   assertion tail and dead-heavy code. The retained direct jump layout
   removes the successor scan and two arrays. Packed blocks improved
   compiler elapsed but increased validator time to result and dense
   peak admission. Finalization fusion increased CPU on dead-heavy
   code. Keep those controls in the next comparison.
   B1344 keeps `46c7e347f` private. One block table replaces two
   arrays. The dataclass allocates 1,640 fewer bytes. Postponed
   factory compilation uses 0.38–1.00% more CPU and dead-heavy
   elapsed rises. Validator time to result spans zero. Both
   platforms and all 140 timed batches verify.
   B1346 retains one block table and demand-driven target resolution.
   Jump cycles, protected ranges, source spans and operand layout match
   83 code objects. This is a compiler simplification with modest
   local allocation savings. Next remove intermediate instruction
   backing or an analysis pass that survives these changes. Require
   a measured attribution signal before building another variant.

   [B1346](benchmarks/results/2026-11-22-demanded-jump-targets/README.md) ·
   [B1344](benchmarks/results/2026-11-22-shared-block-layout/README.md) ·
   [Retained jump layout](benchmarks/results/2026-11-22-direct-jump-layout/README.md) ·
   [Packed blocks](benchmarks/results/2026-11-22-packed-block-layout/README.md) ·
   [Finalization](benchmarks/results/2026-11-22-fused-executable-finalization/README.md).

## Independent regex track

One Lython-owned provider serves frontend and runtime, including imports.
Keep original-subject UTF-8 windows, byte captures, scalar positions,
effective Python flags, retained ownership and current-token
cancellation. Report contract tests, adapter semantics and backend
performance separately. [Provider contract](docs/RUNTIME.md#regex-providers).

Fused range projection is delivered in B1349. Continue against the
current Lython provider boundary and retain separate producer qualification.

Guest regex cache identity is fixed at `cf76cc9dc`. Omitted Unicode
flags and explicit `re.UNICODE` have separate cache entries with equal
effective flags and programs. The wrapper key retains plain requested
flags. Provider compilation and analysis use normalized options. New
sync and async regressions reproduce the prior identity defect and
match CPython 3.13.16. Both platforms pass 701 focused Release checks,
including cancellation, refusal, purge, eviction and allowance reuse.

Implicit Unicode provenance is delivered at `13785960e`. Frontend and
runtime share exact flag normalization and retain provenance in the
compiled-program key. The pinned adapter accepts bare `(?a)a`, rejects
explicit Unicode with `ValueError` and preserves scoped modes and
malformed-pattern precedence. A 20-case probe matches CPython 3.13.16,
and both platforms pass 702 focused checks. The cooperating provider
confirms independent compile handles, equality, runtime reuse and full
refunds. The adapter's 0.4.0 exception bridge is local and final producer
qualification remains independent.

Exact explicit mode validation follows pattern parsing at `251d298d1`.
The pinned adapter and a cooperating provider classify syntax and
incompatible modes separately. The four-case probe now matches
CPython for `ASCII | UNICODE` and `LOCALE` on valid and malformed
string patterns. Both platforms pass 704 focused checks. Preserve the
existing `DEBUG` diagnostic and custom flag operator order.

B1330 retains single-match window index borrowing. B1337's prepared
name reuse stays private after adverse Unicode CPU. B1342 keeps
`72a458bc1` private. Its ordered name table saves 1.36% allocation
before mapping projection. When rules observe every `groupindex`, it
allocates 3.72% more and uses 1.54–3.78% more CPU. Named-rule time
to result spans zero. Revisit if the Python proxy can borrow the
existing backing and preserve stable key/index identity, ordering,
current-token comparison and independent ownership.
[B1330](benchmarks/results/2026-11-22-regex-borrowed-window/README.md) ·
[B1337](benchmarks/results/2026-11-22-regex-prepared-group-metadata/README.md) ·
[B1342](benchmarks/results/2026-11-22-ordered-regex-group-metadata/README.md).

The public adapter pin remains PythonRe 0.4.0. Dev.117 establishes native
Unicode names, original-prefix lookbehind, full bounds and last-close
metadata. Reversed anchored windows and the exact pre-optimization
program key remain open. Development source `3476f1716` exposes
program and working allowances and still uses producer-side Unsafe
size estimates. Final adapter qualification needs an immutable
release and independently evidenced funding and interruption.
Adapter-local bridges support core development meanwhile.
The `4d33c5ed8` source check finds the same PythonRe window and metadata
implementation as dev.117, including truncation to `endOffsetInBytes`
before start validation. Through `3967d18d0`, producer compilation,
subject windows and metadata source remain unchanged. Recent anchored
and replacement changes leave those public PythonRe capabilities
open. Keep the existing direct qualification evidence until the
producer changes those paths.
[Development boundary](benchmarks/results/2026-11-21-regex-dev117-boundary/README.md) ·
[Published package](https://www.nuget.org/packages/Lokad.Utf8Regex.PythonRe).

## Delivery gates

- Preserve managed stack admission, host mediation, cooperative
  cancellation, conservative preflight and overlap, funded aliases,
  terminal refusal and awaited cleanup. Remove displaced runtime or
  compiler machinery before promotion.
- Use a bounded controlled comparison on exact images, verified
  goldens and representative complete scripts. Report work removed,
  allocation, CPU and elapsed separately. Preserve failed conditions
  and adverse results. Confirm or refine when uncertainty affects the
  decision. Evaluate any remaining regression debt before promotion.
- B1361 compares exact production `eb227dcac` against CPython 3.13.16.
  Warm execution, compilation and time to result retain separate
  boundaries. Include I/O, output verification and prior cleanup where
  applicable. Older comparisons remain at their recorded revisions.
  B1356 still supplies mixed factory compilation and ordinary-invoice
  observations. B1351 supplies JSON Lines time to result.
  [B1361](benchmarks/results/2026-11-22-machine-arithmetic-cpython/README.md) ·
  [B1356](benchmarks/results/2026-11-22-construction-csv-cpython/README.md) ·
  [B1351](benchmarks/results/2026-11-22-post-range-cpython/README.md).
- Full qualification for `3d88c8095` found a fixture assertion
  failure on Windows. Absolute spans address normalized LF source.
  `9e8ec712d` checks that representation independently of the
  checkout's line endings. The corrected full Windows and Ubuntu
  gate covers both Release targets, original-scale stress and
  installed-package consumers and is running.
  [Original gate](https://github.com/Lokad/Lython/actions/runs/45018461238) ·
  [Corrected gate](https://github.com/Lokad/Lython/actions/runs/45019489855).
- Use focused checks during development. Batch both Release targets,
  original-scale stress and installed-package consumers on Windows and
  Ubuntu at a meaningful delivery checkpoint. The full
  `285628a43` and `c8ab67ddd` checkpoints pass on both platforms. The
  latter uses the same production source as `2f9f818b9`. Standard CI
  passes for the regex wrapper cache revision `cf76cc9dc`. Both platforms
  pass both Release targets, stress and installed-package consumers for
  the regex flag provenance checkpoint `6d3f11ffa`. The subsequent
  explicit-mode and continuation changes pass focused combined checks.
  Both platforms pass 634 focused combined checks and standard push CI
  for signed arithmetic `eb227dcac`. The intermediate continuation
  run was canceled. Its tests remain covered by the later source and
  platform checks.
  [Previous full gate](https://github.com/Lokad/Lython/actions/runs/45006317326) ·
  [Passing push CI](https://github.com/Lokad/Lython/actions/runs/45008217346) ·
  [Current passing full gate](https://github.com/Lokad/Lython/actions/runs/45009843728) ·
  [Regex cache push CI](https://github.com/Lokad/Lython/actions/runs/45010707729) ·
  [Passing regex flags full gate](https://github.com/Lokad/Lython/actions/runs/45012665956) ·
  [Signed arithmetic push CI](https://github.com/Lokad/Lython/actions/runs/45014723964).
