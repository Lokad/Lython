from pathlib import Path
import hashlib
import json
import os
import shutil
import subprocess
import tarfile

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
donor=lab.with_name("async-map-prefix-20261125")
quiet=lab/"external"
quiet.mkdir(exist_ok=True)
read=lambda path:json.loads(path.read_text(encoding="utf-8-sig"))
digest=lambda data:hashlib.sha256(data).hexdigest()
sha=lambda path:digest(path.read_bytes())
save=lambda path, items:path.write_text(json.dumps(items,ensure_ascii=False,indent=2)+"\n",encoding="utf-8",newline="\n")
git=lambda *args:subprocess.check_output(["git",*args],cwd=repo)
source=git("rev-parse","f6cf9796c").decode().strip()
assert git("diff","--name-only",source,"--","src","benchmarks/cpython-worker.py","benchmarks/Lokad.Lython.Benchmarks")==b""
baseline=read(donor/"comparison/quiet/identity.json")
patch=git("diff","--binary",baseline["comparisonRevision"],source,"--","src")
assert patch==(donor/"candidate.patch").read_bytes() and digest(patch)==baseline["sourcePatchSHA256"]
files=baseline["imageFiles"]["candidate"]
assert len(files)==32
assert {p.name:sha(p) for p in (donor/"candidate").iterdir()}==files
image=lab/"candidate"
image.mkdir(exist_ok=True)
for name,value in files.items():
    shutil.copyfile(donor/"candidate"/name,image/name)
assert {p.name:sha(p) for p in image.iterdir()}==files
terminal=read(donor/"comparison/quiet/terminal-status.json")
donorArchive=donor/"comparison/quiet/observations.tar.xz"
assert terminal["receipt"]["complete"] and sha(donorArchive)==terminal["receipt"]["archiveSHA256"]
loc="retained-async-cpython-b1694-20261125"
externalDonor="async-map-prefix-b1692-20261125"

retained=repo/"benchmarks/results/2026-11-25-retained-defaults-cpython"
old=read(retained/"identity.json")
assert old["expectedCPythonSHA256"]==baseline["expectedCPythonSHA256"]
assert old["auxiliaryFiles"]=={name:value for name,value in files.items() if name!="Lokad.Lython.dll"}
cases={}
for path in (donor/"comparison/quiet/representative.json",
             lab.with_name("compiled-entry-20261125")/"comparison/focused-compile/representative.json"):
    catalog=read(path)
    for case in catalog["cases"]: cases[case["id"]]=case
ship="diagnostic.shipment-routing-callbacks"
bound="diagnostic.shipment-bound-starmap"
rules="scripts.rule-default-closures"
plain="diagnostic.generated-ordinary-definitions"
manifest="scripts.config-manifest.small"
invoice="scripts.csv-invoice.method-policy.quoted-control"
jobs=[(ship,"warm-async"),(plain,"warm"),(rules,"warm"),(ship,"warm"),(bound,"warm-async"),(plain,"compile"),
      (manifest,"compile-run"),(rules,"compile-run"),(ship,"compile-run"),(plain,"compile-run"),(invoice,"warm")]
catalog["cases"]=[cases[name] for name in (ship,bound,rules,plain,manifest,invoice)]
catalog["fixtureEncoding"]="Canonical base64 file maps. The warm-async lane selects Lython RunAsync and the same synchronous Python guest program."
save(quiet/"representative.json",catalog)
save(quiet/"jobs.json",jobs)
core=files["Lokad.Lython.dll"]
identity=dict(sourceRevision=source,candidate=source,productionSource=source,imageFiles={"candidate":files},
              frozenImage="/home/lokad/lython-bench-checks/"+loc+"/candidate",
              auxiliaryFiles=old["auxiliaryFiles"],coreSHA256={"candidate":core,"candidate-control":core},
              expectedCPythonSHA256=baseline["expectedCPythonSHA256"],cpythonWorkerSHA256=baseline["cpythonWorkerSHA256"],
              auxiliaryImageReference="B1692",productionBuild="B1692 nonincremental Release core. Exact patch is committed.",
              sourcePatchSHA256=digest(patch),sourcePatchBase=baseline["comparisonRevision"],
              catalogs={name:dict(sha256=sha(quiet/name)) for name in ("representative.json","jobs.json")})
save(quiet/"identity.json",identity)
protocol=repo/"benchmarks/cpython-worker.py"
assert sha(protocol)==identity["cpythonWorkerSHA256"]
sdk=Path.home()/".dotnet11"
dotnet=sdk/"dotnet.exe"
env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk))
evidence=quiet/"candidate-verify.json"
subprocess.run([dotnet,image/"Lokad.Lython.Benchmarks.dll","--compare","verify","--catalog",quiet/"representative.json",
    "--dotnet",dotnet,"--python","C:/Python313/python.exe","--python-worker",protocol,"--out",evidence],
    cwd=repo,env=env,check=True,timeout=80)
report=read(evidence)
assert report["state"]=="Completed" and report["caseCount"]==6
assert report["launched"]["library"]["sha256"]==core and report["catalogSha256"]==identity["catalogs"]["representative.json"]["sha256"]
assert {p.name:sha(p)for p in image.iterdir()}==files

with tarfile.open(retained/"procedures.tar.xz") as bundle:
    template={name:bundle.extractfile(name).read() for name in ("quiet.py","external/run.sh","external/collect.py","external/summarize.py")}
with tarfile.open(retained/"observations.tar.xz") as bundle:
    assert template["external/collect.py"]==bundle.extractfile("collect.py").read()
run=template["external/run.sh"]
assert b"\r" not in run
(quiet/"run.sh").write_bytes(run)
collect=template["external/collect.py"].decode().replace("b1685-fixtures","b1694-fixtures")
assert "len(jobs) == 11" in collect and "len(jobs) == 8" not in collect
collect=collect.replace("Current CPython checkpoint after shared map operands and callable default ownership",
     "Retained CPython checkpoint after direct compiled entry and async map")
summary=template["external/summarize.py"].decode()
assert 'len(raw["jobs"])==11' in summary and 'receipt["warmJobs"]==11' in summary
for filename,code in (("collect.py",collect),("summarize.py",summary)):
    compile(code,filename,"exec")
    (quiet/filename).write_text(code,encoding="utf-8",newline="\n")

launch=template["quiet.py"].decode().replace("b1685","b1694").replace(
    "lython-b1694-retained-defaults-cpython","lython-b1694-retained-async-cpython")
receipt=read(retained/"terminal-status.json")["receipt"]
# The archived launch links frozen references, and names B1682's exact archive.
oldDonor=read(lab.with_name("tagged-default-ownership-20261125")/"comparison/quiet/terminal-status.json")["receipt"]["archiveSHA256"]
assert oldDonor in launch and "candidate-core.dll" not in launch
launch=launch.replace(oldDonor,terminal["receipt"]["archiveSHA256"])
compile(launch,"quiet.py","exec")
(lab/"quiet.py").write_text(launch,encoding="utf-8",newline="\n")
payload=quiet/"payload.tar.gz"
with tarfile.open(payload,"w:gz",compresslevel=3) as bundle:
    for name in ("identity.json","jobs.json","representative.json","collect.py","run.sh"):
        bundle.add(quiet/name,arcname=name)
save(quiet/"upload.json",dict(root=loc,reference=externalDonor,payloadSHA256=sha(payload),payloadBytes=payload.stat().st_size))
replicas=[]
for name in ("async-map-prefix-20261125", "boolean-precedence-20261125", "resolved-guest-call-20261125"):
    sourceQuiet=lab.with_name(name)/"comparison/quiet"
    copyReceipt=read(sourceQuiet/"terminal-status.json")["receipt"]
    archive=sourceQuiet/"observations.tar.xz"
    assert copyReceipt["complete"] and sha(archive)==copyReceipt["archiveSHA256"]
    with tarfile.open(archive) as bundle:
        archivedRaw=bundle.extractfile("confirmation/confirmation.json").read()
    location=read(sourceQuiet/"upload.json")["root"]
    replicas.append(dict(location=location,bytes=len(archivedRaw),rawSHA256=digest(archivedRaw),archiveSHA256=copyReceipt["archiveSHA256"]))
save(lab/"verified-raw-replicas.json",replicas)
print("Eleven production phase lanes and six independent Python goldens are ready.")
