set -eu
root=/home/lokad/lython-bench-checks/cold-compiler-attribution-b1209-20261120
trap 'result=$?; printf "%s\n" "$result" > "$root/exit-code.txt"' EXIT
python3 "$root/collect.py"
