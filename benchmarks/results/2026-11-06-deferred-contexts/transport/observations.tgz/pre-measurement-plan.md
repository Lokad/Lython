# Lokad.Lython 0.11.0

Updated 2026-11-06. Git-ignored; never force-add. Publication/tagging postponed.
Objective: coherent simplification and substantial complete-script performance.
An isolated experiment or factoring step does not complete that objective.

## Delivery status

Last fully qualified source **88f12099**: focused both runtimes, full
local.NET11 (4,255 internal/16,176 public), both installed Release consumers,
and terminal CI **42208020544 GREEN/all eight** Windows/Ubuntu/runtime/original
Stress/package gates. Never query it again. Current HEAD **3eff1b37** contains
committed/pushed R13 A with focused qualification; it is not covered by that full
delivery. R13 B is now committed/pushed as **9a152ee0**. Its full delivery run
**42228235593** is active (Windows/Ubuntu, both runtimes, original Stress and
packages). Do not infer qualification from completed gates; cache the terminal
result once. Normal adapter0.4 remains nonpackable; core has no producer dependency.

R13 B is a **committed active implementation**, not a fully qualified delivery: the shared
instruction switch runs against borrowed work state, with ordinary context
adoption before scope/protocol/async work. Both-runtime focused checks and new
ownership/cancellation regressions pass. The first full local pass found one
missing Slice adoption guard (4,259 internal pass; 16,185 public pass, one failure).
The source correction and both-API slice regression pass. Final refined source
passes296internal/1,078public per actual runtime; broader Slice-corrected source
passed1,597internal/4,213public. Seven CPython goldens pass. Preserve
the failed condition; no alternate interpreter or replay was introduced.

**B346 is terminal and archived**, 12 compile/warm/fresh jobs in 228.43s, all
measurement/cleanup gates pass. Its pre-correction prototype showed CSV elapsed
improvements around 2–4%, adverse warm text/JSON/report, conflicting elapsed/CPU
and an 18% identical compiler-control divergence. These are uncertainty and debt,
not a CPU gain or final-source qualification. Confirm the corrected source with
the established five-second warmup; preserve B346 unchanged. No live B346 job.
**B347 is terminal/archived**,12jobs/328.10s, all gates, five-second warmup. CSV
warm elapsed−5.85/−6.24%, fresh−5.53/−5.83% versus88, with0.31–0.42% role differences.
Warm CSV CPU is flat. Warm text+3.40/+6.45%, JSON mixed/adverse, report variable;
some identical roles still differ2–4%. Provisionally retain the coherent design
with explicit debt, not a broad CPU/allocation claim or performance completion.
Both originals and the correction/refinement rationale are preserved in
benchmarks/results/2026-11-06-deferred-contexts/. No live VM job. The primary
CPython guide now describes this measured source; earlier async data is labeled.

Completed milestones stay recorded; detailed history/failed conditions/receipts
are in benchmarks/EXPERIMENTS.md and benchmarks/results/. Earlier plan is preserved
in .git/agent-notes/review-20261031/context-materialization-r13/plan-before-r13.md.
Current docs stay in docs/; experiments and plans do not move there.

| Completed | Result and qualification |
| --- | --- |
| Compiler facts/direct UTF8/native helper returns | Shared fact/class-cell correction preserved. Native returns allocation−19.92%/−19.31%, elapsed diagnostic. Formatting allocation−8.67%; controlled B102 elapsed/CPU−5–8% supports retention, original adverse15.125ms preserved/unexplained. Fully qualified; no replay. |
| K01/dd76df36 | One dict/set entry authority; side indexes, shadow inventories, BCL backing, structural rehash and scalar refund ledger deleted. Terminal42145148043 green. |
| F02–F05/1134d6e8 | One invocation/lexical context, shared compiler facts/lexical loads, lazy namespaces/final locals, nonlocal maps removed; receiver/function in operands. Closures/suspended users retained. Terminal42158371981 green. |
| Q01/bf741ec2 | One contextual key preparation; callback ordering fixed. Terminal42166983759 green. |
| R02/R04/794e552b | One active cycle path; one final tuple backing. Terminal42170841788 green. B329/B330 source pairs improve elapsed; no combined CPU claim. |
| R03/R05/51db4209 | Shared whitespace planner/ASCII runs, actual builtin class semantics. SearchValues variant removed. Terminal42174873217 green. B333 warm inconclusive/fresh small gain. |
| Q02/2adf73f3 | Genuine async hashing/native dict/set/view reads.21 Python goldens; terminal42180013420 green. B334/B335 async-text+3.72/+5.13% debt retained; mutations not generally async. |
| R07/4ace68ff | One native-key proof across get/subscript; completed values consumed directly. Terminal42185646656 green. B338 refresh below. |
| R06/a2a61290 | One admitted class extraction; metadata copy/URL HashSet/duplicate routes deleted;16 Python goldens. Terminal42191963552 green. B339 class warm+6.37–6.71%, fresh+3.38–4.09%; CSV also adverse. Explicit debt. |
| R09/933a7fff | Shared constructor sequence, direct receiver binding, four Python fixes/10 goldens. Terminal42201490733 green. B341 modest elapsed changes also seen in controls; no causal CPU/allocation claim. |
| R10/88f12099 | Ordinary constructors use existing frames; type operand/dual input dispatch removed, retained packets owned. Six new regressions. Fully qualified42208020544. B342 and source-justified B343 both retained; final class warm+2.75–3.47%, fresh+1.91–3.44% vs933 accepted as completion debt for shared frame policy. No gain/paid-debt claim. |

All terminal CI above is cached. Never requery completed runs or repeat unchanged
qualification. Private dev40 adapter work is independently scoped below.

## Runtime performance track

Primary guide: docs/BENCHMARKS.md, runtime **9a152ee0/B347**; frozen core1daf56c3
matches its normalized production sources. Fresh CSV1.37–1.38× CPython,
text1.88–1.94×, JSON1.20–1.24×, report1.46–1.51×; latter jobs control-limited/variable.
Compile/warm/fresh separate. B337 failed the actual loaded-core identity guard;
original evidence/correction preserved. Later R06/R10 debts do not silently update
that table. Refresh at a coherent retained redesign checkpoint, not each patch.

| Deliverable | Scope, deletion and acceptance |
| --- | --- |
| R12 source gate complete/1b9ae3cf | B345:22.63s/two scripts/1.886s capture,256 jobs each; source/golden/funding/quiet/join/archive gates pass. Actual guest threads, full origins/unknowns retained. CSV contexts424B/31.74% sampled bytes; text token storage dominates its sampled attribution. These are approximate triggering-type allocations, not CPU/exact/live fractions. Original B344 CRLF setup failure preserved. No live VM job. Evidence: benchmarks/results/2026-11-06-current-allocation/. |
| **R13 ACTIVE: context on demand** | A/3eff1b37 removes the frame base/constructors/hidden dispatch; B/9a152ee0 removes unconditional helper contexts through the shared instruction engine, existing locals/IP/storage adoption and one native write publication. Native returns/format remain active; no swap/pool/arena/second interpreter/owner. Native writes promote before growth; class-cell/capturing/protected bodies start normally. Semantic/cancellation/refusal/alias/real-I/O checks pass. B346 and corrected B347 are preserved; retain provisionally with measured warm-text/JSON/report debt. Finish delivery run42228235593 and installed consumers, then R13 C below; A/B alone do not complete the performance objective. |
| **R13 C NEXT: remove integration surcharge** | Hypothesis requiring proof: always-promoting helpers construct/transfer work state unnecessarily, and shared operand publication transports both defining scope and invocation when only shared cancellation services plus lexical stores are needed. Inspect these complete call/transport costs using existing source/profile evidence; use at most one short current capture if needed. Select one coherent removal, not a second dispatcher or context strategy. Share body facts with existing compiler analysis if needed; do not add another inventory/pass. Preserve the same instructions, dynamic binding/globals/class cells, first failure, native returns, owned borrows and real suspension. Delete displaced setup/parameters/branches. Completion: focused both-runtime semantic/ownership/cancellation checks, then bounded CSV warm/fresh plus unchanged warm text/JSON/report; explicitly decide remaining debt. If evidence does not identify a dominant removable cost, reject that hypothesis and select from the roadmap without declaring performance complete. Full CPython/platform refresh only at the next meaningful retained boundary. |

R13 C source gate: representative JSON `record_amount` and report `render`, like
the text helper, already use the retained NativeReturn route. Always-promoting
helper setup therefore does **not** explain those controls; defer that guess and
do not add new CFG facts/classification for it. Confirmed redundancy: publication
passes both defining scope and invocation, while scope is used only for the fused
store's cancellation check. Operand storage already holds the identical shared
ExecutionState. Select one removal: transport checks through those owned services
and remove the duplicate scope argument from publication/fused-store call sites.
Preserve NoInlining/liveness, current lexical stores, disposal order, first refusal
and actual suspension. This is a source simplification; CPU magnitude remains a
hypothesis requiring the bounded complete-script comparison above. No new helper
strategy, frontend pass, metadata array or standalone dispatch is justified here.
| Later record/scalar/frontend choices | B150 bulk CSV remains (~10% variable-width, peak+63,648B); original6–8% misses preserved. B01 cache withdrawn after flat ordinary/small variable benefit; shared keys require parallel mutation/query/iterator machinery. B61/B69 call records/arenas actually slower; do not rename/replay them. String-window costs remain documented. Arguments already bind final locals and namespaces/caches are lazy. Shared binding facts/nativeUTF8 JSON/completed parser paths exist; compile cost is smaller than representative execution. A new redesign must identify distinct dominant removable work/storage, semantic invariants and displaced code before coding; no speculative JIT/universal values or absent packaging phase. |

R13 B source refinement: the shared dispatch borrows the existing work state;
scope-sensitive instructions materialize the ordinary context at the current IP.
Native dictionary writes may proceed only when the same governor already funds
the table and no capacity growth or guest key protocol is possible. Promote before
growth/admission, rather than adding reentry/rollback machinery. Operand storage
needs only shared execution services, not lexical identity. Promotion transfers
the existing state and function admission; it never rebinds or replays effects.
Keep the accepted CSV mutation branch covered, not only early returns. The source
gate is complete enough to implement and test this bounded design; timings remain
unresolved until the complete implementation has passed semantic checks.

R13 investigations have a concrete stopping point: source/ownership proof before
activation, then one coherent implementation/comparison decision. If safe promotion
would require a second dispatcher or broad new lifetime mechanism, refine/reject
that design and remove unused prototype machinery. Preserve uncertainty and all
adverse data; do not declare the overall performance objective complete.

## Subsequent redesign decisions

| Area | Existing evidence, removable work and bounded decision |
| --- | --- |
| Complete calls/frames | Finish R13 first. If early promotion still dominates affected helpers, reuse compiler body facts to avoid building/transferring storage when every route needs a context; do not add another analysis inventory. Preserve dynamic callable rebinding, exact admission/cleanup and the same engine. Retain/rework R13 from whole-script results, with an explicit decision on remaining regression debt. |
| Operand/scalar transport | Arguments already bind final locals; one work state now owns IP/operands/results. B61/B69 records/arenas measured slower. BigInteger boxes are real storage, not proof of dominant CPU. After R13, reuse current stacks or one short capture to identify dominant removable dispatch/boxing work. Select a coherent shared-path redesign only with that evidence; no universal tagged value or new arena by default. Preserve exact integer promotion, identity/aliases, projection, cancellation and admission. Stop the investigation at one sourced proposal or explicit deferral. |
| Record construction | B150 bulk CSV is retained; B01 cached row layouts were flat and shared keys require substantial mutation/iterator machinery. Reopen only for distinct demonstrated removable work, with ordinary/variable-width CSV, JSON records and unchanged text controls. Preserve dictionary order, aliases, callback reentry, construction overlap and streaming ownership. No automatic promotion of an old favorable percentage. |
| Text/storage | Direct UTF8 formatting/JSON and fused case/whitespace splitting already exist. R12 sampled PyString/byte-array origins justify inspecting remaining per-value metadata and actual conversions, not proposing the same fusion again. Identify storage that can disappear without string-window lifetime debt, a per-object ledger or weaker failure origins. Use complete text/report scripts plus Unicode/expansion/cancellation/alias checks. Stop before implementation if the supposed cost is already eliminated or mandatory output storage. |
| Frontend/setup | Shared compiler facts are corrected and reused. Compile-only costs are materially below these scripts' execution, so a JIT or compiler rewrite is not the next investment. Assess immutable call-layout/signature construction separately from mutable defaults/namespaces; only share metadata with clear ownership and useful fresh-script benefit. Remove displaced per-definition rebuilding if selected; preserve annotations, closures, defaults mutation, diagnostics and compile cancellation. |

For every selected redesign, write the exact hypothesis, removed work/storage,
representative scripts, semantic acceptance, displaced implementation and bounded
same-source-pair comparison before activation. Useful simplification/allocation
reduction can survive a temporary performance setback, with a completion milestone
and explicit debt decision. Neither that allowance nor an isolated favorable run
completes the substantial whole-script performance objective.

## Independent regex track

Core owns Python/nativeUTF8 semantics: one provider across frontend/runtime/imports/
helpers; flags, names/captures, byte/scalar positions, original windows, replacements,
errors/cache ownership/current tokens. Missing published APIs defer only affected
final adapter qualification. Development pins and adapter-local bridges are allowed;
never edit the sibling repository or add backend edges to core.

Private **dev40 range-only** (producer6f6fdab9; Core packageeb5d3ad4/PythonRe31c8d9f2)
qualifies f145daa3/runtime88 with84 internal/421 public per actual.NET11/.NET10,
including earlier-token, real in-flight compile/match/cursor, refusal/retention/reuse.
The direct-token prototype allocated+2.29%; exact producer links creation/advance
tokens. Selected range-only refinement retains the local token bridge and allocates
−22.81% in the same cursor-only control. Both roles agree; busy Windows elapsed is
diagnostic. No whole-script CPU/safety/released-adapter promotion claim. Source,
patches and original harness failures: benchmarks/results/2026-11-06-development-cursor-ranges/.
Normal0.4 pin/locks untouched; selected private source is in .git/agent-notes/
review-20261031/adapter40/. Historical dev29 qualification does not cover newer bits.

Precise token need: creation cancellation must not remain an authority over later
independent advances. Creation validates whole input; None plus boundary checks
is insufficient. Keep the bridge until producer supports that distinction. Native
UTF8 names still use a string bridge; one-shot ranges/working/cache receipts and
reversed windows need exact API/semantic assessment rather than inherited blocker
claims. Continue contract/core work independently. Qualify final affected adapter
behavior against a released immutable package when available. No automatic
promotion; bounded source/measurement refinement is allowed when justified.

## Evidence and execution rules

Timeouts, unstable controls and inconclusive measurements establish uncertainty.
Allow bounded confirmation/refinement/correction. No blanket one-attempt/no-retiming/
permanent closure rules. Percentages inform decisions. Distinguish simplification,
allocation reduction and measured CPU; do not combine deltas across source pairs.

Use focused Release checks during development; batch full Windows/Ubuntu, both
runtimes, original Stress and installed consumers at meaningful boundaries. No
concurrent local builds/tests. After timestamp-preserving restoration, force a
nonincremental build. Reuse valid qualification and terminal receipts.

Quiet VM lokad@20.166.121.73, key~/.ssh/id_lython-bench.pem: lease/frozen workers,
actual loaded hashes, joined users and final funding/fixtures required. Near-full
disk: preflight expanded payload plus archive headroom; remove only verified
redundant owned transfers with retained copies and terminal owners. Never sole
evidence/dependencies. Persist raw RAM traces before collection ownership ends.
Timing includes mediated RAM I/O/full validation/prior-result cleanup; fresh adds
compile/disposal. Startup/staging/reset/transport/final teardown outside. CPython
imports persist; Lython imports isolated. RSS/embedding/pending-I/O latency unmeasured.

Follow AGENTS.md: fully managed/memory-safe; no unsafe/Unsafe/pointers/PInvoke/native
probing. Preserve managed stack/recursion, host capabilities/paths, cancellation,
cycles and shared admission/capacity/replacement/aliases/pending users. No fuel,
quotas/watchdogs/hidden caps, tracing/weak reclamation/forced GC or new memory
infrastructure. First refusal terminal, never retry/fallback; await actual cleanup.
Bounded host-driven streaming. Programs outlive users. No publication/tagging.
