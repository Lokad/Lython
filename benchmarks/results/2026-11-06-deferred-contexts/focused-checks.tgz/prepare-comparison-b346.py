from pathlib import Path
import hashlib,json,shutil,subprocess,tarfile
repo=Path('D:/code/Lython');root=Path(__file__).parent/'b346';root.mkdir(exist_ok=False)
old=root.parent.parent/'constructor-frames-refinement-r10'
remote='/home/lokad/lython-bench-checks/context-materialization-b346-20261106'
oldremote='/home/lokad/lython-bench-checks/constructor-frames-refinement-b343-20261106'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def write(name,text):
    with (root/name).open('w',encoding='utf-8',newline='\n') as f:f.write(text)
core=repo/'src/Lokad.Lython/bin/Release/net11.0/Lokad.Lython.dll'
shutil.copyfile(core,root/'Lokad.Lython.dll');candidate=sha(core)
checks=json.loads((root.parent/'stage-b-focused.json').read_text(encoding='utf-8'))
assert checks['Lokad.Lython.Tests-net11.0']['coreSHA256']==candidate
reference=json.loads((old/'identity.json').read_text(encoding='utf-8'))
changed=subprocess.check_output(['git','diff','88f12099','--name-only','--','src/Lokad.Lython'],cwd=repo,text=True).splitlines()
identity=dict(sourceRevision='3eff1b37 plus R13 B patch: deferred contexts through the shared instruction engine',
 referenceSourceRevision='88f1209929697ce1fb6a2d895fcaae5fb0ac2424; B343 source-equivalent core, exact qualified R10 source hashes',
 coreSHA256=dict(candidate=candidate,control=candidate,reference=reference['coreSHA256']['candidate']),
 sourceFiles={s:sha(repo/s) for s in changed},auxiliaryFiles=reference['auxiliaryFiles'],qualification=checks)
write('identity.json',json.dumps(identity,indent=2)+'\n');write('focused-results.json',json.dumps(checks,indent=2)+'\n')
(root/'source.patch').write_bytes(subprocess.check_output(['git','-c','core.safecrlf=false','diff','--','src','tests','docs/RUNTIME.md'],cwd=repo))
with tarfile.open(root/'source-snapshot.tgz','w:gz') as archive:
    for s in changed+['tests/Lokad.Lython.PublicApi.Tests/DeferredFunctionContextTests.cs','tests/Lokad.Lython.Tests/DeferredFunctionOwnershipTests.cs']:archive.add(repo/s,arcname=s)
catalog=json.loads((old.parent/'native-read-prefix-r07/checkpoint-b338/retrieved/representative.json').read_text(encoding='utf-8'))
selected=['scripts.csv-summary-functions.large','scripts.text-summary-helpers.large','scripts.json-summary-helpers.large','scripts.report-render.large']
ids=[c['id'] for c in catalog['cases']]
print('available cases',ids,flush=True)
assert all(s in ids for s in selected),ids
catalog['cases']=[next(c for c in catalog['cases'] if c['id']==s) for s in selected]
write('representative.json',json.dumps(catalog,ensure_ascii=False)+'\n')
contract='''# R13 complete-script comparison / B346
Compare the shared dispatch and context-on-demand milestone against qualified R10.
Four representative scripts, compile/warm/compile-run separately. CPython remains
the external baseline; candidate and an identical candidate role expose instability.
The unchanged worker and protocol validate every output and cleanup. Normal GC and
tiering, quiet VM, mediated RAM I/O. Warm/fresh include full validation and prior
result cleanup; fresh adds compilation/program disposal. Startup, staging/reset,
transport and final teardown are outside clocks. CPython imports persist; Lython
imports are isolated. No exact allocation, live-memory, RSS or host-tail-latency claim.
Use three-second warmups and seven rotating rounds of ~150ms batches: bounded usable
observations, not a ten-minute lane. Retain adverse observations and all failed
conditions. Review regression debt at this milestone; an unstable control justifies
bounded measurement correction, not automatic design rejection. No publication.
'''
write('contract.md',contract);shutil.copyfile(repo/'PLAN.md',root/'pre-measurement-plan.md')
jobs=[(s,lane) for s in selected for lane in ['compile','warm','compile-run']]
for name in ['collect.py','run.sh','launch.py','archive.py','archive-checkpoint.py','cpython-worker.py','summarize.py']:
    text=(old/name).read_text(encoding='utf-8').replace(oldremote,remote).replace('b343-payload.tgz','b346-payload.tgz').replace('lython-b343-constructor-frames-refinement-20261106','lython-b346-deferred-contexts-20261106')
    if name=='collect.py':
        a=text.index('jobs=[');b=text.index('\nassert len(jobs)',a);text=text[:a]+'jobs='+repr(jobs)+text[b:]
        a=text.index("purpose='");b=text.index("',\n",a);text=text[:a]+"purpose='R13 shared instruction engine/context-on-demand versus qualified R10: representative compile, warm and fresh; CPython plus two identical candidate roles. No exact allocation/RSS/embedding latency claim"+text[b:]
        text=text.replace('warmupSeconds=5','warmupSeconds=3').replace('end=time.monotonic()+5','end=time.monotonic()+3').replace('time.monotonic()-started < 130','time.monotonic()-started < 310')
    text=text.replace('len(jobs)==4','len(jobs)==12').replace("len(r['jobs'])==4","len(r['jobs'])==12").replace("len(data['jobs'])==4","len(data['jobs'])==12").replace('jobs=4','jobs=12').replace('RuntimeMaxSec=160','RuntimeMaxSec=360')
    write(name,text)
setup='''from pathlib import Path
import hashlib,json,os,shutil
root=Path('REMOTE');base=Path('BASE/candidate')
for label in ['candidate','reference']:
    folder=root/label;folder.mkdir()
    for f in base.iterdir():
        if f.name=='Lokad.Lython.pdb':continue
        if f.name in ['Lokad.Lython.Benchmarks.dll','Lokad.Lython.Benchmarks.deps.json','Lokad.Lython.Benchmarks.runtimeconfig.json']:
            os.link(f,folder/f.name)
        else:
            source=(root/'Lokad.Lython.dll' if label=='candidate' else base/'Lokad.Lython.dll') if f.name=='Lokad.Lython.dll' else f
            (folder/f.name).symlink_to(source.resolve(),target_is_directory=source.is_dir())
i=json.loads((root/'identity.json').read_text())
for label in ['candidate','control','reference']:
    folder=root/('candidate' if label=='control' else label)
    assert hashlib.sha256((folder/'Lokad.Lython.dll').read_bytes()).hexdigest()==i['coreSHA256'][label]
    for name,digest in i['auxiliaryFiles'].items():assert hashlib.sha256((folder/name).read_bytes()).hexdigest()==digest
assert shutil.disk_usage(root).free>12*1024*1024
print(json.dumps(dict(freeBytes=shutil.disk_usage(root).free,coreSHA256=i['coreSHA256'])))
'''.replace('REMOTE',remote).replace('BASE',oldremote)
write('setup.py',setup)
with tarfile.open(root/'payload.tgz','w:gz') as archive:
    for n in ['Lokad.Lython.dll','identity.json','source.patch','source-snapshot.tgz','representative.json','focused-results.json','pre-measurement-plan.md','contract.md','setup.py','collect.py','run.sh','launch.py','archive.py','archive-checkpoint.py','cpython-worker.py']:archive.add(root/n,arcname=n)
with tarfile.open(root/'payload.tgz') as archive:expanded=sum(m.size for m in archive.getmembers())
record=dict(core=candidate,payloadBytes=(root/'payload.tgz').stat().st_size,payloadSHA256=sha(root/'payload.tgz'),expandedBytes=expanded,requiredFreeBeforeTransfer=(root/'payload.tgz').stat().st_size+expanded+12*1024*1024)
write('transfer.json',json.dumps(record,indent=2)+'\n');print(json.dumps(record))
