from pathlib import Path
import hashlib,json,re,subprocess
repo=Path('D:/code/Lython');root=repo/'.git/agent-notes/review-20261031/context-materialization-r13';baseline=root/'baseline';baseline.mkdir(exist_ok=False)
assert not subprocess.check_output(['git','diff','--','src','tests'],cwd=repo)
changed={}
def write(p,s):
 old=p.read_text(encoding='utf-8')
 if s==old:return
 rel=p.relative_to(repo);copy=baseline/rel;copy.parent.mkdir(parents=True,exist_ok=True);copy.write_bytes(p.read_bytes());p.write_text(s,encoding='utf-8',newline='\n');changed[str(rel).replace('\\','/')]=hashlib.sha256(p.read_bytes()).hexdigest()
runtime=repo/'src/Lokad.Lython/Runtime'
p=runtime/'LythonRuntime.Executable.cs';s=p.read_text(encoding='utf-8');a=s.index('    internal class ExecutableFrameState : ExecutionFrame');b=s.index('        internal void InitializeExecutableBindings(',a)
s=s[:a]+'''    // Mutable execution data is distinct from the lexical context's identity.
    // The normal engine owns one inline state; handlers borrow it by reference.
    internal struct ExecutableWorkState
    {
        internal ExecutableCodeObject Code;
        internal object[] Locals;
        internal ExecutableCell?[]? LocalCells;
        internal IReadOnlyList<ExecutableCell>? ClosureCells;
        internal ExecutableValueStorage Stack;
        internal int InstructionIndex;

        public ExecutableWorkState()
        {
            Code = null!;
            Locals = [];
            LocalCells = null;
            ClosureCells = null;
            Stack = default;
            InstructionIndex = 0;
        }
    }

    internal sealed partial class ExecutionContext : ExecutionFrame
    {
        internal ExecutableWorkState _execution = new();

'''+s[b:]
s=s.replace('        protected void ClearExecutableBindings()', '        private void ClearExecutableBindings()')
# Replace only fields owned by these executable/context partial declarations.
fields={'_codeObject':'Code','_locals':'Locals','_localCells':'LocalCells','_closureCells':'ClosureCells','_stack':'Stack','_instructionIndex':'InstructionIndex'}
files=sorted(set(runtime.glob('LythonRuntime.Executable*.cs'))|set(runtime.glob('LythonRuntime.ExecutionContext*.cs')))
for f in files:
 text=s if f==p else f.read_text(encoding='utf-8')
 text=text.replace('        private ExecutableValueStorage _stack;\n','').replace('        private int _instructionIndex;\n','')
 text=re.sub(r'\b(_codeObject|_locals|_localCells|_closureCells|_stack|_instructionIndex)\b',lambda m:'_execution.'+fields[m[0]],text)
 text=text.replace('ExecutableFrameState','ExecutionContext').replace('partial class ExecutionContext : ExecutionContext','partial class ExecutionContext : ExecutionFrame')
 write(f,text)
# Replace representation-only types and reflected field access, retaining the
# independent value/reference/lifetime assertions against the real live arrays.
for f in (repo/'tests/Lokad.Lython.Tests').glob('*.cs'):
 text=f.read_text(encoding='utf-8')
 if 'LythonRuntime.ExecutableFrameState' not in text:continue
 text=text.replace('LythonRuntime.ExecutableFrameState','LythonRuntime.ExecutionContext')
 text=text.replace('''        var locals = typeof(LythonRuntime.ExecutionContext).GetField("_locals", BindingFlags.Instance | BindingFlags.NonPublic)!;
        var values = Assert.IsType<object[]>(locals.GetValue(frame));''','''        var values = Assert.IsType<object[]>(frame._execution.Locals);''')
 text=text.replace('''            var locals = typeof(LythonRuntime.ExecutionContext).GetField("_locals", BindingFlags.NonPublic | BindingFlags.Instance)!;
            Storage = Assert.IsType<object[]>(locals.GetValue(context.CurrentExecutableFrame));''','''            Storage = Assert.IsType<object[]>(context.CurrentExecutableFrame!._execution.Locals);''')
 for name,target in [('_locals','Locals'),('_codeObject','Code')]:
  pattern=r'typeof\(LythonRuntime\.ExecutionContext\)\s*\.GetField\("'+name+r'",\s*[^)]*\)!\.GetValue\(([^)]*)\)!?'
  text=re.sub(pattern,lambda m:'((LythonRuntime.ExecutionContext)'+m[1]+'!)._execution.'+target,text)
 pattern=r'(\w+)\.GetType\(\)\.GetField\("_stack",\s*[^)]*\)!\.GetValue\(\1\)!'
 text=re.sub(pattern,lambda m:'((LythonRuntime.ExecutionContext)'+m[1]+'!)._execution.Stack',text)
 if len(re.findall(r'\bfields\b',text))==1:text=re.sub(r'^\s*var fields = BindingFlags\.Instance \| BindingFlags\.NonPublic;\n','\n',text,flags=re.M)
 write(f,text)
(root/'stage-a-source.json').write_text(json.dumps(dict(sourceBase='1b9ae3cf (runtime88f12099)',phase='R13 A: inline mutable work state and redundant base removal; no native prefix activated',changed=changed),indent=2)+'\n',encoding='utf-8')
print('Changed',len(changed),'files; no new execution path/heap owner')
