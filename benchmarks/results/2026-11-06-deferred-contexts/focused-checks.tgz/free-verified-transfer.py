from pathlib import Path
import hashlib,json,shutil
root=Path('/home/lokad/lython-bench-checks')
old=root/'constructor-frames-refinement-b343-20261106'
receipt=json.loads((old/'archive-receipt.json').read_text())
assert receipt['complete'] and receipt['allWorkersJoined']
assert hashlib.sha256((old/'observations.tgz').read_bytes()).hexdigest()==receipt['archiveSHA256']
payload=root/'b343-payload.tgz'
assert payload.resolve().parent==root and not payload.is_symlink()
assert hashlib.sha256(payload.read_bytes()).hexdigest()=='a72e6b2749431ac94dfbed5c0c2739fe30aa90162967c7c7ff508c1055056025'
assert (old/'exit-code.txt').read_text().strip()=='0'
size=payload.stat().st_size;payload.unlink()
print(json.dumps(dict(removedOnlyVerifiedDuplicateTransfer=payload.name,retainedLocalSHA256='a72e6b2749431ac94dfbed5c0c2739fe30aa90162967c7c7ff508c1055056025',removedBytes=size,freeBytes=shutil.disk_usage(root).free)))
