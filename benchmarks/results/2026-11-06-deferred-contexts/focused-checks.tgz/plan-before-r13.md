# Lokad.Lython 0.11.0

Updated 2026-11-06. Git-ignored: never force-add. Publication/tagging postponed.
Objective: coherent simplification and substantial complete-script performance.
An isolated experiment or delivery checkpoint does not complete that objective.

## Actual delivery status

| State | Source / scope |
| --- | --- |
| Fully qualified, preserved | Shared compiler-fact/class-cell correction; direct UTF-8 formatting/storage; native helper returns; D61/D62 operands; managed depth; P01 prepared patterns. Native helper returns allocation −19.92%/−19.31%, elapsed diagnostic. Formatting allocation −8.67%; B102 controlled elapsed/CPU −5–8% supports retention, original adverse15.125ms unexplained/preserved. No unchanged qualification replay. |
| K01 / dd76df36 | One dict/set entry authority; side indexes, shadow inventories, BCL set backing, structural rehash and scalar refund ledger deleted. Cached42145148043 GREEN/all eight. |
| F02–F05 / 1134d6e8 | Shared lexical loads/compiler facts; one invocation/lexical context; nonlocal owner maps removed; immediate methods carry receiver/function in operands. Lazy namespaces/final locals already exist. Closures/suspended users retained. Cached42158371981 GREEN/all eight; receipt62d2c9ca. |
| Q01 / bf741ec2 | One contextual key preparation replaces duplicate classify/hash work and fixes callback ordering. Full local/both installed consumers; cached42166983759 GREEN/all eight. |
| R02/R04 / 794e552b | One active identity path replaces two cycle tables; tuple construction owns one final backing. Focused/full local/both consumers; cached42170841788 GREEN/all eight. B329 compound elapsed−14.8–17.1%; B330−6.17–12.29% versus separate source pairs. No compound/broad CPU claim. |
| R03/R05 / 51db4209 | One whitespace planner/direct ASCII runs; actual builtin class semantics remove source-name/synthetic-sequence dispatch. Original SearchValues variant withdrawn; B333 warm inconclusive/fresh slightly better. Full local/both consumers; cached42174873217 GREEN/all eight. |
| Q02 / 2adf73f3 | Async protocol hashing and native dictionary/set/view reads genuinely await existing callbacks.21 Python goldens, focused both runtimes, full local, both consumers; cached42180013420 GREEN/all eight. B334/B335 retain async-text+3.72/+5.13% debt and unstable CSV controls. Mutation/wrappers not generally asynchronous. |
| R07 / 4ace68ff, fully qualified | One existing native-key proof across direct/exposed get, prepared lookup and subscript; consume completed values directly. Receiver/arguments/table mutation semantics preserved. Focused1,018 public/431 internal per runtime; full local.NET11; both consumers; cached42185646656 GREEN/all eight Windows/Ubuntu/runtime/originalStress/package gates. Excludes later R06. |
| R06 / a2a61290, fully qualified | One admitted class extraction, descriptor metadata and contextual equality; full metadata array/whole-tuple decode/URL HashSet/duplicate routes deleted.16 Python goldens; focused3,057 public/320 internal per actual runtime; full local.NET11(4,239/16,160) and both installed consumers pass. Cached terminal42191963552 GREEN/all eight Windows/Ubuntu/runtime/originalStress/package gates. Never query again; later R09 excluded. Prior R07 receipt excludes R06. B339 records performance debt, not a gain. |

All terminal CI above is cached: never query again. Historical contracts, failed
conditions, raw observations and receipts: benchmarks/EXPERIMENTS.md and
benchmarks/results/. Previous longer plan: .git/agent-notes/review-20261031/.
Current documentation stays in docs/; history does not move there.

## 1. Active delivery and measurement

R07 B336 complete86.02s/all three jobs/golden/quiet/ownership/join/fixture gates:
async text−6.40–6.47% versusQ02; CSV−1.80/+0.25% inconclusive; sync text+1.51–2.11%
adverse/control debt. Retain common proof for simplification and affected async
gain; no CPU/allocation/RSS/embedding claim. Evidence:
benchmarks/results/2026-11-06-native-read-prefix/.

B338 final-source refresh CLOSED: final4ace68ff/frozena45b5c5d,381.56s/14jobs/all
golden/quiet/ownership/Closed/join/fixture gates. Primary guide refreshed: fresh
CSV1.44–1.45× CPython, text1.91–1.93×, JSON1.14–1.16×, report1.42–1.44× variable.
Compile and warm separate. VersusQ02 async text−6.91–7.14%; synchronous warm text
flat, fresh text+1.63–2.27% remains debt. No broad CPU/allocation/RSS claim.
B337 failed before timings at loaded-core identity guard; symlinked main worker
resolved beside old B336 core. Original failed archive, ENOSPC/headroom and both
setup corrections preserved; B338 Ready verified the actual loaded final core.
No live VM work. Evidence: benchmarks/results/2026-11-06-native-read-cpython/.
Receipt/docs commitddbda0cf; never replay unchanged qualification/measurement.

R06/B339 CLOSED measurement:86.64s/three whole-script jobs/all gates, finalR07
reference, two identical roles/CPython. Class-record warm+6.37–6.71%, fresh
+3.38–4.09%; unchangedCSV+2.12–2.29% also adverse. Retain corrected Python behavior
and common extraction with explicit debt; no speedup/allocation/causalCPU claim.
No raw semantic bypass or class-only special case to recover timing. Both owned
collections terminal, archived/hash-verified; no live workers/fixtures. Evidence:
benchmarks/results/2026-11-06-class-pattern-extraction/. Cached terminal42191963552 GREEN/all eight closes exacta2a61290 delivery.
Never query again or replay unchanged checks; later R09 excluded.

## 2. Prioritized coherent roadmap

| Milestone | Eliminated work, affected scripts, acceptance and stopping decision |
| --- | --- |
| R06 retained / delivery closed | Exacta2a61290. Full local/installed consumers and cached terminal42191963552 GREEN/all eight. Never query again; R09 excluded. Preserve16 Python goldens and measured regression debt; no unchanged replay. Pattern hooks still require synchronous completion; bodies/cleanup genuinely suspend. |
| R08 / B340 source gate CLOSED | Exacta2a61290/frozenf940bd54, text3.59guestCPU/711samples and class4.92/979. All236prefix samples uniquely map;125unknown/partial maps preserved. All golden/quiet/funding/Closed/join/fixture gates pass, archive hash verified, no live VM job. Text costs distributed; no universal value/frame/text rewrite justified. Distinct constructor transport is present and selected below; no more profiling in this gate. Evidence: benchmarks/results/2026-11-06-remaining-runtime-cost/. |
| R09 /933a7fff fully qualified | One constructor sequence; ordinary positional operands bind final locals; sealed allocator and compiled initializer copies/bound wrappers removed; shared entry preserves managed call admission. Four Python bugs fixed.10 CPython goldens; focused5,698public/915internal per actual runtime and full local.NET11(4,249/16,176) pass. Initial four zero-headroom allocator fixtures preserved/corrected: fund argument copies with less than an instance shell, still detect placeholders. Both-runtime30affected checks pass; no unchanged public replay. B341113.58s/fourjobs/all gates: class warm−2.35/−3.08%, fresh−2.04/−1.65%; unchangedCSV similarly improves, textmixed. Retain design/correctness; no causalCPU/allocation/broad gain or paid-debt claim. Production hashes unchanged after fixture correction. Both installed Release consumers pass, packageF1EE6721. Cached terminal42201490733 GREEN/all eight Windows/Ubuntu/runtime/originalStress/package gates on exact933a7fff. Never query again or replay unchanged checks. Later R10 excluded. Evidence: benchmarks/results/2026-11-06-constructor-operands/. |
| R10 /88f12099 fully qualified | One existing linear frame/completion/prepared value; no new runner/frame/owner. R09 type operand overloads, dual argument inputs and object/type operand dispatch deleted; shared dynamic allocation/init remains. Sealed allocator proof, one allocation and post-allocation init selection; retained native positional/keyword packets owned. Six new internal regressions; focused5,732public/925internal per actual runtime. Original B342113.65s/adverse and source-justified B343113.42s/fourjobs/all gates both archived/hash-verified; no live VM work. Final class warm+2.75–3.47%, fresh+1.91–3.44% versus933; CSV/text variation explicit. Accept debt at completion for shared frame policy/removal, no allocation/CPU/broad gain or paid-debt claim. Final full local.NET11(4,255internal/16,176public) pass; Both actual installed Release consumers pass (package908B7184). Cached terminal42208020544 GREEN/all eight Windows/Ubuntu/both runtimes/originalStress/package gates on exact88f12099; never query again. Later private dev40 experiments excluded. No further constructor-only timing without a distinct demonstrated defect. Evidence: benchmarks/results/2026-11-06-constructor-frames/. |
| R12 ACTIVE current whole-script allocation/lifecycle gate | B34 sourceae22392d attributed26%/19% text/CSV bytes to separate interpreter/context objects; F03 subsequently removed that representation, so those percentages are historical. B340 current CPU costs are distributed; R10 did not improve class scripts. Reuse the existing EventPipe collector/offline reader for one bounded current CSV/text allocation-origin capture (complete outputs, recorded guest threads, unknowns and funding retained), at most5s total capture/90s owned supervision; preflight persistent archive headroom first. Existing B343 source-equivalent1d1eff12/b94 worker reused; no binary transfer. Contract: .git/agent-notes/review-20261031/current-allocation-r12/contract.md. Initial B344 terminal shell-CRLF failure before any worker/measurement is preserved; explicit LF/syntax-checked B345 uses unchanged conditions. No new benchmark framework or CPU campaign. Use source facts plus current origins to select one coherent call/frame/operand, per-record storage or scalar redesign, naming actual work/implementation that disappears. Preserve identity/aliases/closures/generators, evaluation order, overflow/promotion, cancellation and shared admission. Produce a concrete source/lifetime decision before coding; if costs remain distributed, record uncertainty and select a broader justified phase rather than a new local tweak or rerun for favorable samples. Existing representative CPython guide stays exact4ace until a coherent redesign checkpoint. |
| Whole-script construction/call transport | Build on F03/F05/R02/R04; do not reintroduce arenas/control wrappers. Existing direct operands already bind final locals and namespaces are lazy. B327 found no absent generic packaging phase; B61/B69 actually slower. Select a distinct remaining allocation/callback/copy phase only with source + representative cost evidence. Complete call/frame or record-construction redesign must name displaced implementation, Python binding/closure/generator/evaluation-order acceptance and bounded whole-script comparison. No new pool/framework merely because calls are frequent. |
| Bulk records, text and frontend | B150 bulk CSV retained (~10% variable-width, peak+63,648B); original6–8% misses preserved. B01 header cache withdrawn: gain insufficient for lifetime complexity; prototype removed, semantic cases kept. Reopen selectively if current evidence identifies removable construction work. Shared binding facts and default native-UTF8 JSON/completed parser paths already exist; compile cost is smaller than representative execution. No speculative duplicate parser/JIT/universal tagged-value project. A source gate can reject an absent cost without coding. |

Before a new redesign record hypothesis, storage/work removed, affected complete
scripts, semantic/cancellation/admission/retention gates and displaced code to
delete. Temporary setbacks allowed within an explicit completion milestone;
decide remaining regression debt there. Continue the roadmap after local success.

## 3. Independent regex development

Core Python/native UTF-8 contract stays backend-free: one provider across frontend,
runtime/imports/helpers; effective flags, UTF-8 names/captures, byte/scalar ranges,
original subject windows, replacements/errors/cache ownership and current tokens.
Optional adapter0.4.0 remains nonpackable. Missing producer releases defer only
affected final adapter qualification. Test providers, explicit development pins
and adapter-local bridges are allowed; do not edit the sibling repository.

Normal adapter0.4 remains unchanged/nonpackable; core has no producer dependency.
Historical dev29/43435906 qualification covers cf3 source. Private dev40 range-only
milestone now qualifies current Lython f145daa3/runtime88f12099 with immutable
producer source6f6fdab9 (Core packageeb5d3ad4 / PythonRe31c8d9f2):84internal and
421public per actual.NET11/.NET10, including earlier-token, actual in-flight
compile/match/cursor, semantics/refusal/ownership/reuse. This is focused private
development qualification, not released-adapter promotion or producer safety/
exact working/cache receipt qualification. Source/patches/gates and original
harness failures are preserved: benchmarks/results/2026-11-06-development-cursor-ranges/.

Direct-current-token/range prototype allocated+2.29% per cursor versus original
adapter on the samedev40. Exact producer links its retained creation token with
each advance token. One source-justified refinement retains the existing local
bridge, uses native capture ranges and allocates−22.81% in the same cursor-only
control; both roles agree. Busy Windows elapsed is diagnostic, no CPU/whole-script
claim. Selected source stays isolated in .git/agent-notes/review-20261031/adapter40/;
normal pin/lockfiles unchanged. No automatic promotion; revisit timing only for a concrete new source or measurement defect.

Precise remaining token capability: cancellation during creation must not remain
an authority over later independent advances. Creation validates the whole input;
None plus boundary checks is insufficient. Keep the local bridge until the producer
supplies that distinction. Native UTF-8 capture-name enumeration still uses a
string bridge; one-shot range/working/cache receipt integration and reversed-window
support require exact API/semantic assessment rather than inheriting old blocker
claims. These affect the optional adapter only. Continue core/contract development;
qualify affected final adapter behavior against a released immutable package when
available. Never cache caller tokens or introduce regex quotas/background work.

## Evidence policy and validation

Timeouts, unstable unchanged controls and inconclusive observations establish
uncertainty. Allow bounded confirmation/refinement/measurement correction when
evidence justifies it. No blanket one-attempt/no-retiming/permanent closure.
Percentages inform decisions, not automatic vetoes. Preserve all original adverse
and failed conditions. Distinguish simplification, allocation and measured CPU;
never add deltas from separate source pairs.

Focused Release semantics/cancellation/ownership during iteration; batch full
Windows/Ubuntu, both runtimes, originalStress and installed consumers at coherent
delivery boundaries. No overlapping local builds/tests; force nonincremental build
after timestamp-preserving restoration. No unchanged qualification replay.

Quiet VM lokad@20.166.121.73, key~/.ssh/id_lython-bench.pem: existing lease/frozen
workers, persistent evidence, joined users, final funding/fixture checks. Near-full
disk: preflight uncompressed sizes; remove only hash-verified redundant owned
transfers with retained local copies and terminal owners. Never sole evidence or
dependencies. Timing includes mediated RAM I/O/full validation/prior-result cleanup;
fresh adds compile/disposal. Startup/staging/reset/transport/final teardown outside.
CPython imports persist, Lython execution imports isolated. Pending-I/O latency,
RSS and embedding latency unmeasured.

Follow AGENTS.md: fully managed memory safety and managed stack admission; host
capabilities/paths; cancellation/cycles; coarse shared funding for capacity,
replacement, aliases and pending users. No unsafe/Unsafe/pointers/PInvoke/native
probing, fuel/quotas/watchdogs/hidden caps, tracing/weak reclamation/forced GC.
First admission refusal terminal: never retry/fallback, await actual cleanup.
Bounded host-driven streaming; programs outlive actual users. No new memory
infrastructure, publication or tagging.

