from pathlib import Path
import hashlib,json,os,re,subprocess
repo=Path('D:/code/Lython');root=repo/'.git/agent-notes/review-20261031/context-materialization-r13'
env=os.environ.copy();env['DOTNET_ROOT']='C:/Users/JoannesVermorel/.dotnet11';env['DOTNET_HOST_PATH']=env['DOTNET_ROOT']+'/dotnet.exe';env['PATH']=env['DOTNET_ROOT']+os.pathsep+env['PATH']
common=['Function','Method','Class','Constructor','Scope','Stack','Recursion','Invocation','Closure','Generator','Global','Import','Comprehension','ControlFlow','Annotation','AdmissionFailureCommand','GovernedMemoryContract']
internal=common+['Executable','Direct','Frame','Ownership','Cancellation','LocalAugmented','OwnedFunctionLocals','PositionalCallTransport','CompletedInvocationLifetime']
results={}
for framework in ['net11.0','net10.0']:
 source=repo/f'src/Lokad.Lython/bin/Release/{framework}/Lokad.Lython.dll';digest=hashlib.sha256(source.read_bytes()).hexdigest()
 for suite,names in [('Lokad.Lython.Tests',internal),('Lokad.Lython.PublicApi.Tests',common)]:
  assert hashlib.sha256((repo/f'tests/{suite}/bin/Release/{framework}/Lokad.Lython.dll').read_bytes()).hexdigest()==digest
  selection='Category!=Stress&('+'|'.join('FullyQualifiedName~'+n for n in ['DeferredFunction'])+')';p=root/f'stage-b-new-{suite}-{framework}.log'
  with p.open('w',encoding='utf-8') as output:r=subprocess.run([env['DOTNET_HOST_PATH'],'test',f'tests/{suite}','-c','Release','-f',framework,'--no-build','--no-restore','--nologo','--filter',selection],cwd=repo,env=env,stdout=output,stderr=subprocess.STDOUT)
  text=p.read_text(encoding='utf-8');print(suite,framework,r.returncode,text[-400:],flush=True)
  if r.returncode:print(text[-12000:]);raise SystemExit(r.returncode)
  results[suite+'-'+framework]=dict(passed=int(re.search(r'Passed:\s+(\d+)',text)[1]),coreSHA256=digest)
(root/'stage-b-new-focused.json').write_text(json.dumps(results,indent=2)+'\n',encoding='utf-8')


