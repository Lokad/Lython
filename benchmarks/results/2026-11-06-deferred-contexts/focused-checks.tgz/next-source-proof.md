# R13 B implemented / next decision

B is now implemented. Do not rerun implement-shared-prefix.py: it would overwrite
later fixes. No timestamp-preserving restoration occurred. Final-v2 build/focus
logs are authoritative for the candidate now being qualified.

One existing ExecuteInstructionPrefix switch borrows ref ExecutableWorkState,
defining services and optional real invocation. Shared publication/local/operand/
control/native-call handlers execute both paths. ContextRequired stops before
scope/protocol/async effects; actual contexts adopt current locals/IP/operands.
Capturing/protected/implicit-class-cell bodies start normally. NativeReturn and
UTF8 paths remain active. Operand storage retains ExecutionState services only,
so adoption needs no context rebind. No second interpreter, state swap, arena,
owner, pool or policy. Function/interpreter admission transfers exactly once.

TryWriteKeyWithoutAdmission checks same governor/native string/no protocols,
performs one lookup and shares PublishNativeValue with ordinary writes. Funded
existing/spare-capacity writes finish; growth promotes before admission. The
original B346 predicate repeated lookup for full existing-key tables; removed.

B346 TERMINAL SUCCESS/archived/all12 gates/228.43s; pre-slice-fix source91628fe2.
Modest CSV favorable, warm text/JSON/report adverse, conflicting CPU and18%
identical compiler-control divergence: uncertainty/debt, not a CPU gain or current
HEAD qualification. Raw archive SHA8c5d5ba6...; b346/refinement.md preserves details.
Initial full local4259internal pass,16185public pass/1failure: Slice adoption guard
omitted by insertion script duplicating GetIter. Existing Slice case corrected;
both-API late-index golden added. Seven CPython goldens pass. Preserve originals.

Next finish final-v2 focus, prepare/launch B347 with established5s warmups and same
four scripts/compile-warm-fresh, seven150ms rounds/reference88/identical control/
CPython. Decide debt/refinement, then coherent platform/stress/installed consumers.
Do not declare the whole performance objective complete. No publication/tagging.

VM free16,605,184B after hash-verified redundant B343 transfer deletion. Local
payload+terminal raw archive retained, all remote images/dependencies/evidence
untouched. B347 preflight includes6MiB headroom beyond transfer/expansion. No live
VM service currently. Never query terminal B346 or CI42208020544 again. No B CI yet.

NativeReturnOperation.SplitLowerWhitespace/SplitUpperWhitespace and
PyStringOps.SplitCasedWhitespace already write final tokens without a cased
source; do not propose that fusion again. FunctionBindingPlan is in Runtime/Calls/.
PLAN stays ignored. Source proof/design history is in contract.md and snapshots.
