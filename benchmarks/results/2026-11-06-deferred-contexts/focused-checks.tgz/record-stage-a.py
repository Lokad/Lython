from pathlib import Path
import hashlib,json,shutil,subprocess,tarfile
repo=Path('D:/code/Lython');root=repo/'.git/agent-notes/review-20261031/context-materialization-r13';out=repo/'benchmarks/results/2026-11-06-executable-work-state';out.mkdir(exist_ok=False)
focused=json.loads((root/'stage-a-focused.json').read_text(encoding='utf-8'));assert len(focused)==4 and all(v['passed'] in [1593,4200] for v in focused.values())
for base in ['src/Lokad.Lython','tests/Lokad.Lython.Tests']:
 for p in (repo/base).rglob('*.cs'):
  if any(x in p.parts for x in ['obj','bin']):continue
  assert 'ExecutableFrameState' not in p.read_text(encoding='utf-8'),str(p)
changed=subprocess.check_output(['git','diff','--name-only','--','src','tests'],cwd=repo,text=True).splitlines()
v=dict(status='R13 A foundation only; no context-skipping execution path/performance claim. R13 B source/implementation/comparison/delivery remains active.',sourceBase='1b9ae3cf, production runtime88f12099',sourceFiles={p:hashlib.sha256((repo/p).read_bytes()).hexdigest() for p in changed},focused=focused,removed=['ExecutableFrameState type','three pass-through frame constructors','distributed code/locals/cell/operand/IP field declarations','hidden same-signature local lookup dispatch'],preserved=['one lexical/current context identity','one inline mutable work state','native-return/UTF8 formatting paths','live operand/reference/tail inspections','cancellation/refusal/retained aliases/actual async cleanup'],fullDelivery='Deferred to coherent R13 B boundary; terminal42208020544 covers source88 only.',publication='postponed')
(out/'validation.json').write_text(json.dumps(v,indent=2)+'\n',encoding='utf-8')
for name in ['contract.md','method-hiding-correction.md']:shutil.copyfile(root/name,out/name)
with tarfile.open(out/'focused-checks.tgz','w:gz') as a:
 for name in ['build-stage-a-initial-failure.log','build-stage-a-final.log','build-inspectors.log','run-focused.py','stage-a-source.json','factor-workstate.py','correct-method-hiding.py']:
  a.add(root/name,arcname=name)
 for p in sorted(root.glob('stage-a-*.log')):a.add(p,arcname=p.name)
(out/'README.md').write_text('''# Executable work-state foundation — 2026-11-06

R13 A groups code, locals/cells, operand storage and instruction position in one
inline ExecutableWorkState. The normal executable engine uses it directly inside
the existing lexical ExecutionContext. ExecutableFrameState and its three
pass-through constructors disappear; no extra heap object, caller record, arena,
pool, execution route, owner, policy or public API is introduced.

Removing inheritance exposes two methods that previously hid one another. The
slot-only reader is now explicit (TryReadExecutableLocal); TryResolveOwnLocal
retains lexical/inlined-scope behavior. The original duplicate-definition build
failure is preserved. White-box probes read actual work-state arrays and retain
live input/reference identity, tail clearing, weak lifetime and cleanup assertions;
no legacy field-name compatibility accessors or replacement layout-only tests.

Release solution builds both targets, zero warnings/errors. Focused checks pass
**1,593 internal / 4,200 public cases per actual .NET11/.NET10**, including direct
calls, scopes/classes/imports/annotations, closures/generators, managed depth,
first refusal/cancellation, real pending operations and retained storage/reuse.
No assertions/timeouts/stress scales were relaxed. All four test core copies match
the corresponding built core hash in validation.json. Native-return and direct
UTF8 formatting remain in use.

This is a foundation, **not a performance result or completion of R13**. No new
context-skipping path is active, no isolated timing/allocation claim is made, and
full platform/stress/package delivery is batched at the coherent B boundary.
Previous terminal42208020544 qualifies runtime88f12099 only.

The selected next source proof shares instruction handlers with a standalone
work state and materializes a real context before actual scope/protocol/async work.
It must adopt current locals/IP/ownership rather than rebind or restart, leave
module/closure identity unchanged, preserve native-return gains and admit all
storage/overlap before use. If that requires a parallel dispatcher or broad new
lifetime machinery, refine/reject it and remove unused prototype foundation.
See contract.md for semantics, comparison controls and the completion decision.
Publication remains postponed.
''',encoding='utf-8')
p=repo/'benchmarks/EXPERIMENTS.md';s=p.read_text(encoding='utf-8');s+='\n## Shared executable work state (2026-11-06)\n\n[R13 A foundation](results/2026-11-06-executable-work-state/README.md) removes the redundant frame base/pass-through constructors and groups mutable execution state without a new heap object or route. Distinct slot/lexical local reads preserve the old hidden-method semantics. Focused1,593 internal/4,200 public per actual runtime pass. No native prefix or performance claim; context-on-demand implementation/qualification remains active.\n';p.write_text(s,encoding='utf-8')
p=repo/'PLAN.md';s=p.read_text(encoding='utf-8').replace('R13 below is new development, not covered by that delivery.','R13 A below is new development, not covered by that delivery.');s=s.replace('First group mutable execution work state and remove redundant ExecutableFrameState/base constructors, preserving one context and existing handlers.','A implemented: one inline ExecutableWorkState; redundant ExecutableFrameState/three constructors and hidden-method dispatch removed. Both-target Release build and focused1,593 internal/4,200 public per runtime pass. Slot/lexical read semantics and live storage inspections preserved; no prefix/gain claim.');p.write_text(s,encoding='utf-8')
(root/'next-source-proof.md').write_text('''# Next R13 source proof (B not active)

Current source uses one inline _execution record in the concrete context. A is
focused-qualified, not full delivery/performance qualification. No prefix exists.

Do not temporarily replace module context fields: live globals/closures would see
callee slots. Do not replay B61 saved caller records/B69 slot arenas/context pools.
The shared synchronous prefix currently accesses pending/generator/handler state
and calls instance helpers; moving only the outer loop is insufficient.

Needed proof: common opcode implementations operate on ref ExecutableWorkState
plus defining scope and optional actual invocation identity. Calls that need
identity promote at the current instruction; no second native statement switch.
StoreLocalValue/LoadLocal/publication must not consult the module's active slots
or mirroring flags when handling standalone function state. Scope-sensitive ops,
closure/cell creation, handlers, user protocols, nested guest calls and real async
operations require a real context before effects; retained native-return paths
stay in use. Share existing value/call helpers rather than copying arithmetic.

The hard native-mutation boundary is admission reentry: a dictionary proven native
before capacity reservation can gain protocol keys in the host allowance hook.
A native write must revalidate before callbacks and either finish protocol-free
or request context adoption without repeating guest effects. Successful private
capacity admission is not a refused-admission retry; refusal still aborts. Do not
ship a safe-but-narrow path that merely avoids the accepted CSV branch's mutation
and declare the complete helper objective met.

Adoption must retain current bound local/operand values and IP, avoid fresh
initialization/rebinding, rebind storage cleanup context if necessary, and transfer
existing function/interpreter admission exactly once. Current stack storage has a
readonly context reference; verify it can preserve cancellation/cleanup identity
when adopting, rather than retaining the wrong defining scope. Error/traceback
metadata and native first-failure origin need correct locals/span without a new
admission after refusal. Pending users must keep funding until awaited cleanup.
No source snapshots restored this turn; builds are current. Use focused checks,
then the full delivery/controlled comparison at B completion. No more capture in
R12 without a concrete new measurement defect.
''',encoding='utf-8')
print(out)
