from pathlib import Path
import hashlib,json,re,subprocess,sys
root=Path(__file__).parent
source=Path('tests/Lokad.Lython.PublicApi.Tests/DeferredFunctionContextTests.cs').read_text(encoding='utf-8')
cases=re.findall(r'^\s*\{ ("(?:[^"\\]|\\.)*"), ("(?:[^"\\]|\\.)*") \},',source,re.M)
assert len(cases)==7
rows=[]
for i,(program,expected) in enumerate(cases):
    program=json.loads(program);expected=json.loads(expected)
    result=subprocess.run([sys.executable,'-I','-S','-X','utf8','-c',program],capture_output=True,text=True,encoding='utf-8')
    assert result.returncode==0 and result.stdout==expected,(i,result.stdout,result.stderr,expected)
    rows.append(dict(case=i,sourceSHA256=hashlib.sha256(program.encode('utf-8')).hexdigest(),outputSHA256=hashlib.sha256(result.stdout.encode('utf-8')).hexdigest(),passed=True))
(root/'cpython-goldens.json').write_text(json.dumps(dict(version=sys.version,cases=rows),indent=2)+'\n',encoding='utf-8')
print('seven CPython semantic goldens pass')
