from pathlib import Path
import re

repo=Path('D:/code/Lython'); runtime=repo/'src/Lokad.Lython/Runtime'
root=repo/'.git/agent-notes/review-20261031/context-materialization-r13'
snap=root/'before-b';snap.mkdir(exist_ok=True)
for p in runtime.glob('*.cs'):
    if p.name.startswith('LythonRuntime.Executable') or p.name in ['PyExecutableFunction.cs','PyFunctionBase.cs','PyFunctionBinding.cs','PyDict.cs']:
        (snap/p.name).write_bytes(p.read_bytes())
def read(name):return (runtime/name).read_text(encoding='utf-8')
def write(name,text):
    with (runtime/name).open('w',encoding='utf-8',newline='\n') as f:f.write(text)

# Return transport belongs to the same mutable invocation state as IP/operands.
for p in runtime.glob('LythonRuntime.Executable*.cs'):
    text=p.read_text(encoding='utf-8').replace('_frameReturnValue','_execution.ReturnValue').replace('_hasFrameReturn','_execution.HasReturn')
    if p.name=='LythonRuntime.Executable.Interpreter.cs':
        text=text.replace('        private object? _execution.ReturnValue;\n        private bool _execution.HasReturn;\n','')
    write(p.name,text)
text=read('LythonRuntime.Executable.cs')
text=text.replace('        internal int InstructionIndex;','        internal int InstructionIndex;\n        internal object? ReturnValue;\n        internal bool HasReturn;')
text=text.replace('            InstructionIndex = 0;','            InstructionIndex = 0;\n            ReturnValue = null;\n            HasReturn = false;',1)
# Storage uses shared services only, including after context adoption.
start=text.index('    internal struct ExecutableValueStorage');end=text.index('\n    public LythonExecutionResult Run(',start)
storage=text[start:end].replace('private readonly ExecutionContext _context;','private readonly ExecutionState _state;').replace('_context = context;','_state = context.State;').replace('_context.MemoryGovernor','_state.MemoryGovernor').replace('_context.CheckExecution','_state.CheckExecution')
text=text[:start]+storage+text[end:];write('LythonRuntime.Executable.cs',text)

# One publication implementation; existing async completions borrow their own state.
text=read('LythonRuntime.Executable.Results.cs')
text=text.replace('        private void PublishInstructionResult(in ExecutableInstruction instruction, object value)\n        {',
'''        private void PublishInstructionResult(in ExecutableInstruction instruction, object value)
            => PublishInstructionResult(ref _execution, this, this, instruction, value);

        private static void PublishInstructionResult(ref ExecutableWorkState execution, ExecutionContext scope,
            ExecutionContext? invocation, in ExecutableInstruction instruction, object value)
        {''')
start=text.index('        private static void PublishInstructionResult')
text=text[:start]+text[start:].replace('_execution.','execution.').replace('CompleteLocalResult(instruction, value)','CompleteLocalResult(ref execution, scope, invocation, instruction, value)').replace('private void CompleteLocalResult(in ExecutableInstruction instruction, object value)','private static void CompleteLocalResult(ref ExecutableWorkState execution, ExecutionContext scope,\n            ExecutionContext? invocation, in ExecutableInstruction instruction, object value)').replace('            CheckExecution(store.Span);','            scope.CheckExecution(store.Span);').replace('execution.LocalCells, this,','execution.LocalCells, invocation,')
write('LythonRuntime.Executable.Results.cs',text)

text=read('LythonRuntime.Executable.Interpreter.cs')
# Nullable invocation is valid only for the closed, unmirrored function path.
start=text.index('        private static void StoreLocalValue(');end=text.index('        private void ExecuteDefinitionOrFallback',start)
part=text[start:end].replace('ExecutionContext context,','ExecutionContext? context,').replace('context.GlobalNamespace is not null','context?.GlobalNamespace is not null').replace('context.MirrorLocalStores','context?.MirrorLocalStores == true').replace('context.Variables[name] = value','context!.Variables[name] = value')
part=part.replace('private void StoreExecutableLocal(in ExecutableInstruction instruction)','private static void StoreExecutableLocal(ref ExecutableWorkState execution, ExecutionContext? invocation, in ExecutableInstruction instruction)').replace('=> StoreLocalValue(_execution.Code, _execution.Locals, _execution.LocalCells, this, instruction.LocalSlot,\n                TakeOperand(instruction), instruction.Span);','=> StoreLocalValue(execution.Code, execution.Locals, execution.LocalCells, invocation, instruction.LocalSlot,\n                TakeOperand(ref execution, instruction), instruction.Span);')
part=part.replace('        private object ReadOperand(int source)\n            => source < 0 ? RuntimeValue(_execution.Code.Constants[~source]) : _execution.Stack[source];',
'''        private object ReadOperand(int source) => ReadOperand(ref _execution, source);

        private static object ReadOperand(ref ExecutableWorkState execution, int source)
            => source < 0 ? RuntimeValue(execution.Code.Constants[~source]) : execution.Stack[source];''')
part=part.replace('        private object TakeOperand(in ExecutableInstruction instruction)\n        {','        private static object TakeOperand(ref ExecutableWorkState execution, in ExecutableInstruction instruction)\n        {')
idx=part.index('        private static object TakeOperand');part=part[:idx]+part[idx:].replace('_execution.','execution.').replace('ReadOperand(instruction.InputStart)','ReadOperand(ref execution, instruction.InputStart)')
text=text[:start]+part+text[end:]

# Direct receiver resolution is shared; guest descriptors require a real context.
start=text.index('        private bool TryLoadDirectCallReceiver(');end=text.index('        internal void InitializeExecutableExecution',start)
part=text[start:end].replace('private bool TryLoadDirectCallReceiver(ExecutableInstruction instruction)','private static bool TryLoadDirectCallReceiver(ref ExecutableWorkState execution, ExecutionContext? invocation, ExecutableInstruction instruction)').replace('_execution.','execution.').replace('if (execution.Stack[instruction.InputStart] is PyInstance','if (invocation is not null && execution.Stack[instruction.InputStart] is PyInstance')
text=text[:start]+part+text[end:]
start=text.index('        private void ExecuteStackTransfer(');end=text.index('        private bool ExecuteStructure(',start)
part=text[start:end].replace('private void ExecuteStackTransfer(in ExecutableInstruction instruction)','private static void ExecuteStackTransfer(ref ExecutableWorkState execution, ExecutionContext scope, ExecutionContext? invocation, in ExecutableInstruction instruction)').replace('_execution.','execution.').replace('PublishInstructionResult(instruction,','PublishInstructionResult(ref execution, scope, invocation, instruction,').replace('TryLoadDirectCallReceiver(instruction)','TryLoadDirectCallReceiver(ref execution, invocation, instruction)')
part=part.replace(', this,',', invocation!,').replace(', this)',', invocation!)').replace('(this,','(invocation!,')
part=part.replace('instruction.Span, invocation!));\n                    break;\n\n                case ExecutableOpCode.LoadName:', 'instruction.Span, scope));\n                    break;\n\n                case ExecutableOpCode.LoadName:')
for method in ['TryReadMemberCache','PublishMemberCache']:
    part=part.replace(method+'(', 'invocation!.'+method+'(')
text=text[:start]+part+text[end:]

start=text.index('        private void ExecuteOperandValueOperation(');end=text.index('        // Ordinary returns',start)
part=text[start:end].replace('private void ExecuteOperandValueOperation(in ExecutableInstruction instruction)','private static void ExecuteOperandValueOperation(ref ExecutableWorkState execution, ExecutionContext scope, ExecutionContext? invocation, in ExecutableInstruction instruction)').replace('_execution.','execution.').replace('_preparedCallValue is not null','invocation?._preparedCallValue is not null').replace('InvokePreparedTypeSubscription(', 'invocation!.InvokePreparedTypeSubscription(').replace('ReadOperand(', 'ReadOperand(ref execution, ').replace(', this,',', scope,').replace(', this)',', scope)').replace('PublishInstructionResult(instruction,','PublishInstructionResult(ref execution, scope, invocation, instruction,')
text=text[:start]+part+text[end:]

start=text.index('        private bool DeliverReturn(');end=text.index('        private bool DeliverJump(',start)
part=text[start:end].replace('private bool DeliverReturn(object value, LythonSourceSpan span)','private static bool DeliverReturn(ref ExecutableWorkState execution, ExecutionContext? invocation, object value, LythonSourceSpan span)').replace('_execution.','execution.').replace('TryHandleAbrupt(execution.Code, this,','TryHandleAbrupt(execution.Code, invocation!,').replace('ref _pendingAbrupt','ref invocation!._pendingAbrupt')
text=text[:start]+part+text[end:]
start=text.index('        private bool ExecuteControlFlow(');end=text.index('        internal bool HasFrameReturn',start)
part=text[start:end].replace('private bool ExecuteControlFlow(in ExecutableInstruction instruction)','private static bool ExecuteControlFlow(ref ExecutableWorkState execution, ExecutionContext scope, ExecutionContext? invocation, in ExecutableInstruction instruction)').replace('_execution.','execution.').replace('this','invocation!').replace('State.','scope.State.')
for field in ['_pendingAbrupt','_savedActiveExceptions','ActiveHandlerVariables']:
    part=re.sub(r'(?<![\w.])'+field+r'\b','invocation!.'+field,part)
for method in ['DeliverJump','SavedActiveExceptions']:
    part=re.sub(r'(?<![\w.])'+method+r'\(', 'invocation!.'+method+'(',part)
part=part.replace('IsTruthy(execution.Stack.TakeValue(instruction.InputStart, instruction.LiveExtent), invocation!,','IsTruthy(execution.Stack.TakeValue(instruction.InputStart, instruction.LiveExtent), scope,')
part=part.replace('PublishInstructionResult(instruction,','PublishInstructionResult(ref execution, scope, invocation, instruction,').replace('DeliverReturn(TakeOperand(instruction),','DeliverReturn(ref execution, invocation, TakeOperand(ref execution, instruction),').replace('DeliverReturn(PyNone.Instance,','DeliverReturn(ref execution, invocation, PyNone.Instance,')
text=text[:start]+part+text[end:]
text=text.replace('ExecuteInstructionPrefix(true,','ExecuteInstructionPrefix(ref _execution, this, this, true,')
write('LythonRuntime.Executable.Interpreter.cs',text)

# Existing async code uses the same synchronous helpers on its actual context.
for name in ['LythonRuntime.Executable.Interpreter.Async.cs','LythonRuntime.Executable.Interpreter.Sync.cs']:
    text=read(name).replace('TryLoadDirectCallReceiver(instruction)','TryLoadDirectCallReceiver(ref _execution, this, instruction)').replace('ExecuteOperandValueOperation(instruction)','ExecuteOperandValueOperation(ref _execution, this, this, instruction)').replace('ExecuteInstructionPrefix(false,','ExecuteInstructionPrefix(ref _execution, this, this, false,')
    write(name,text)

# One instruction switch. Context-only cases stop BEFORE any effects when borrowed.
text=read('LythonRuntime.Executable.Interpreter.Dispatch.cs')
text=text.replace('Boundary, Operation, Disposal','Boundary, Operation, Disposal, ContextRequired')
text=text.replace('private InstructionPause ExecuteInstructionPrefix(bool asynchronous,','private static InstructionPause ExecuteInstructionPrefix(ref ExecutableWorkState execution, ExecutionContext scope,\n            ExecutionContext? invocation, bool asynchronous,')
text=text.replace('_execution.','execution.').replace('State.','scope.State.')
text=text.replace('if (_injectedException is not null && _delegation is null)','if (invocation is not null && invocation._injectedException is not null && invocation._delegation is null)')
for field in ['_injectedException','_delegation','_waitingForSend','_sentValue','HasYield','YieldValue']:
    text=re.sub(r'(?<![\w.])'+field+r'\b','invocation!.'+field,text)
text=text.replace('ReadOperand(', 'ReadOperand(ref execution, ').replace('StoreExecutableLocal(instruction)','StoreExecutableLocal(ref execution, invocation, instruction)').replace('PublishInstructionResult(instruction,','PublishInstructionResult(ref execution, scope, invocation, instruction,').replace('instruction.Span, this))','instruction.Span, scope))').replace('ExecuteStackTransfer(instruction)','ExecuteStackTransfer(ref execution, scope, invocation, instruction)').replace('TryLoadDirectCallReceiver(instruction)','TryLoadDirectCallReceiver(ref execution, invocation, instruction)').replace('ExecuteOperandValueOperation(instruction)','ExecuteOperandValueOperation(ref execution, scope, invocation, instruction)').replace('ExecuteControlFlow(instruction)','ExecuteControlFlow(ref execution, scope, invocation, instruction)')
methods=['ExecuteTargetInstruction','ExecutePreparedOperationAsync','ExecuteDelegationAsync','CompleteDelegatedStep','ExecuteDefinitionOrFallback','ExecuteDefinitionOrFallbackAsync','ExecuteMemberLoadAsync','ExecuteStructure','ExecuteContextManagerAsync','ExecuteOperandValueOperationAsync','TrySuspendForTypeSubscription','ExecuteForNext','ExecuteForNextAsync','TrySuspendForExecutableCall','ExecuteOrdinaryCall','ExecuteValueOperation','ExecuteGetIteratorAsync','ExecuteConditionalJumpAsync','TryRouteReturn','TryRouteControl','TryRouteRuntimeException']
for method in methods:
    text=re.sub(r'(?<![\w.])'+method+r'\(', 'invocation!.'+method+'(',text)
text=text.replace('instruction.Span, this), this, instruction.Span)', 'instruction.Span, invocation!), invocation!, instruction.Span)')
# Guard context-only groups at their existing entry labels.
guards=[
'                            if (!asynchronous) invocation!.ExecuteTargetInstruction',
'                            if (!asynchronous)\n                                invocation!.ExecutePreparedOperationAsync',
'                            invocation!.YieldValue =',
'                            if (asynchronous)\n                            {\n                                pending = invocation!.ExecuteDelegationAsync',
'                            if (!asynchronous) invocation!.ExecuteDefinitionOrFallback',
'                            jumped = invocation!.ExecuteStructure',
'                            if (!asynchronous) jumped = invocation!.ExecuteStructure',
'                            if (execution.Stack.TryAdvanceNativeIteration',
'                            if (execution.Stack.TryPrepareNativeIteration',
'                            if (!asynchronous) invocation!.ExecuteValueOperation',
'                            invocation!.ExecuteValueOperation(instruction);',
]
for match in guards:
    assert match in text,match
    text=text.replace(match,'                            if (invocation is null) return InstructionPause.ContextRequired;\n'+match,1)
# Scope-sensitive stack transfers keep the existing implementation after adoption.
needle='                            ExecuteStackTransfer(ref execution, scope, invocation, instruction);'
text=text.replace(needle,'''                            if (invocation is null && instruction.OpCode is not (ExecutableOpCode.LoadConst or ExecutableOpCode.LoadGlobal or ExecutableOpCode.Dup or ExecutableOpCode.PopTop))
                                return InstructionPause.ContextRequired;
'''+needle,1)
# Direct builtin receiver preparation is identity-free; all other members promote.
needle='                            if (!asynchronous) ExecuteStackTransfer(ref execution, scope, invocation, instruction);'
text=text.replace(needle,'''                            if (invocation is null)
                            {
                                if (!TryLoadDirectCallReceiver(ref execution, null, instruction)) return InstructionPause.ContextRequired;
                                break;
                            }
'''+needle)
# Native arithmetic has the same conservative shapes used by the async engine.
needle='                            if (!asynchronous ||\n                                (ReadOperand(ref execution, instruction.InputStart)'
text=text.replace(needle,'''                            if (invocation is null && !((ReadOperand(ref execution, instruction.InputStart) is BigInteger or double or bool &&
                                ReadOperand(ref execution, instruction.SecondInput) is BigInteger or double or bool) ||
                                (ReadOperand(ref execution, instruction.InputStart) is PyString && ReadOperand(ref execution, instruction.SecondInput) is PyString)))
                                return InstructionPause.ContextRequired;
'''+needle)
needle='                            if (!asynchronous || ReadOperand(ref execution, instruction.InputStart)'
text=text.replace(needle,'''                            if (invocation is null && ReadOperand(ref execution, instruction.InputStart) is not (BigInteger or double or bool))
                                return InstructionPause.ContextRequired;
'''+needle)
text=text.replace('                            if (invocation!.TrySuspendForTypeSubscription(instruction))', '''                            if (invocation is null && !((execution.Stack[instruction.InputStart + 1] is BigInteger &&
                                execution.Stack[instruction.InputStart] is PyList or PyTuple or PyBytes or PyString or PyRange) ||
                                (execution.Stack[instruction.InputStart] is PyDict nativeDictionary && nativeDictionary.CanReadKeySynchronously(execution.Stack[instruction.InputStart + 1]))))
                                return InstructionPause.ContextRequired;
                            if (invocation is not null && invocation.TrySuspendForTypeSubscription(instruction))''')
# Calls share native operation selection; no invocation for protocol-free get/int.
needle='                            if (invocation!.TrySuspendForExecutableCall(call, callStart, target))'
text=text.replace(needle,'''                            if (TryExecuteNativeCall(ref execution, scope, invocation, call, callStart, target, out var nativeResult))
                            {
                                PublishInstructionResult(ref execution, scope, invocation, instruction, nativeResult);
                                break;
                            }
                            if (invocation is null) return InstructionPause.ContextRequired;
'''+needle)
needle='                            if (!asynchronous || execution.Stack[instruction.InputStart] is not PyInstance)'
text=text.replace(needle,'''                            if (invocation is null && execution.Stack[instruction.InputStart] is not (PyNone or bool or BigInteger or double or PyString or PyBytes or PyList or PyTuple or PyDict or PySet or PyRange))
                                return InstructionPause.ContextRequired;
'''+needle)
needle='                            jumped = ExecuteControlFlow(ref execution, scope, invocation, instruction);\n                            break;\n                        default:'
text=text.replace(needle,'''                            if (invocation is null && instruction.OpCode is not (ExecutableOpCode.Jump or ExecutableOpCode.Return or ExecutableOpCode.ReturnNone))
                                return InstructionPause.ContextRequired;
'''+needle)
# No protected regions or callback signals are possible before context adoption.
text=text.replace('if (!invocation!.TryRouteReturn','if (invocation is null || !invocation.TryRouteReturn').replace('if (!invocation!.TryRouteControl','if (invocation is null || !invocation.TryRouteControl')
text=text.replace('                    if (!invocation!.TryRouteRuntimeException(error, instruction.Span)) throw;', '''                    if (invocation is null)
                    {
                        var previous = scope.State.CurrentException;
                        if (previous is not null && !ReferenceEquals(error.OriginalPythonException, previous)) error.PythonContext ??= previous;
                        throw;
                    }
                    if (!invocation.TryRouteRuntimeException(error, instruction.Span)) throw;''')
write('LythonRuntime.Executable.Interpreter.Dispatch.cs',text)
