from pathlib import Path
import re,shutil
repo=Path('D:/code/Lython');root=repo/'.git/agent-notes/review-20261031/context-materialization-r13'
shutil.copyfile(root/'build-stage-a.log',root/'build-stage-a-initial-failure.log')
# Preserve the old typed executable-frame read semantics, distinct from the
# lexical/inlined-scope wrapper that formerly hid it with 'new'.
for p in (root/'baseline/tests/Lokad.Lython.Tests').glob('*.cs'):
 original=p.read_text(encoding='utf-8')
 if 'LythonRuntime.ExecutableFrameState' not in original:continue
 target=repo/'tests/Lokad.Lython.Tests'/p.name;s=target.read_text(encoding='utf-8')
 s=re.sub(r'(\bFrame!?|\.Frame!?|\bframe)\.TryResolveOwnLocal\(',r'\1.TryReadExecutableLocal(',s)
 target.write_text(s,encoding='utf-8',newline='\n')
(root/'method-hiding-correction.md').write_text('''# Consolidating the hidden local-read methods

Removing ExecutableFrameState exposes two same-signature methods: slot-only read
and ExecutionContext's lexical/inlined-scope wrapper (formerly internal new).
Initial duplicate-definition build failure is retained. Keep distinct meanings:
TryReadExecutableLocal reads actual slots/cells; TryResolveOwnLocal retains lexical/
inlined handling. Enumeration and formerly typed frame assertions use the slot
reader. No recursive dispatch or silent scope change after removing inheritance.
''',encoding='utf-8')
