from pathlib import Path
import re
repo=Path('D:/code/Lython');tests=repo/'tests/Lokad.Lython.Tests'
for name in ['CompletedInvocationLifetimeTests.cs','OwnedFunctionLocalsTests.cs','DirectAppendExecutionTests.cs','DirectStringStartsWithTests.cs','ExecutableCallTransferTests.cs','ExecutableValueTransferTests.cs','PositionalCallTransportTests.cs']:
 p=tests/name;s=p.read_text(encoding='utf-8');s=s.replace('(object[])((LythonRuntime.ExecutionContext)frame!)._execution.Locals','((LythonRuntime.ExecutionContext)frame)._execution.Locals')
 s=s.replace('var stack = ((LythonRuntime.ExecutionContext)frame!)._execution.Stack;', 'var stack = ((LythonRuntime.ExecutionContext)frame)._execution.Stack;')
 if name=='CompletedInvocationLifetimeTests.cs':s=s.replace('var values = ((LythonRuntime.ExecutionContext)frame)._execution.Locals;', 'var values = frame._execution.Locals;')
 if name=='OwnedFunctionLocalsTests.cs':s=s.replace('(object[])((LythonRuntime.ExecutionContext)context.CurrentExecutableFrame!)._execution.Locals', 'context.CurrentExecutableFrame!._execution.Locals')
 if name=='PositionalCallTransportTests.cs':s=s.replace('var stack = ((LythonRuntime.ExecutionContext)frame)._execution.Stack;', 'var stack = frame._execution.Stack;')
 if 'BindingFlags' not in s and 'Reflection.' not in s:s=s.replace('using System.Reflection;\n','')
 p.write_text(s,encoding='utf-8',newline='\n')
