from pathlib import Path
import hashlib,json,os,re,subprocess
repo=Path('D:/code/Lython');root=Path(__file__).parent
env=os.environ.copy();env['DOTNET_ROOT']='C:/Users/JoannesVermorel/.dotnet11';env['DOTNET_HOST_PATH']=env['DOTNET_ROOT']+'/dotnet.exe';env['PATH']=env['DOTNET_ROOT']+os.pathsep+env['PATH']
expected=json.loads((root/'b346/identity.json').read_text(encoding='utf-8'))['coreSHA256']['candidate']
assert hashlib.sha256((repo/'src/Lokad.Lython/bin/Release/net11.0/Lokad.Lython.dll').read_bytes()).hexdigest()==expected
rows={}
for suite,framework,selection in [('Lokad.Lython.Tests','net11.0','Category!=Stress'),('Lokad.Lython.PublicApi.Tests','net11.0','Category!=Stress'),('Lokad.Lython.PublicApi.Tests','net10.0','FullyQualifiedName~DeferredFunction')]:
    path=root/f'delivery-{suite}-{framework}.log'
    with path.open('w',encoding='utf-8') as out:r=subprocess.run([env['DOTNET_HOST_PATH'],'test',f'tests/{suite}','-c','Release','-f',framework,'--no-build','--no-restore','--nologo','--filter',selection],cwd=repo,env=env,stdout=out,stderr=subprocess.STDOUT)
    content=path.read_text(encoding='utf-8');print(suite,framework,r.returncode,content[-450:],flush=True)
    if r.returncode:print(content[-16000:]);raise SystemExit(r.returncode)
    rows[suite+'-'+framework]=dict(passed=int(re.search(r'Passed:\s+(\d+)',content)[1]),selection=selection)
(root/'delivery-local.json').write_text(json.dumps(rows,indent=2)+'\n',encoding='utf-8')
