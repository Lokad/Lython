# R13 complete-script comparison / B346
Compare the shared dispatch and context-on-demand milestone against qualified R10.
Four representative scripts, compile/warm/compile-run separately. CPython remains
the external baseline; candidate and an identical candidate role expose instability.
The unchanged worker and protocol validate every output and cleanup. Normal GC and
tiering, quiet VM, mediated RAM I/O. Warm/fresh include full validation and prior
result cleanup; fresh adds compilation/program disposal. Startup, staging/reset,
transport and final teardown are outside clocks. CPython imports persist; Lython
imports are isolated. No exact allocation, live-memory, RSS or host-tail-latency claim.
Use three-second warmups and seven rotating rounds of ~150ms batches: bounded usable
observations, not a ten-minute lane. Retain adverse observations and all failed
conditions. Review regression debt at this milestone; an unstable control justifies
bounded measurement correction, not automatic design rejection. No publication.
