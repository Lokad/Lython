from pathlib import Path
import gzip
import hashlib
import json
import subprocess
import tarfile

lab = Path(__file__).resolve().parent
previous = lab.with_name('parallel-local-transfer-20261124')
repo = lab.parents[3]
tree = repo / '.git/agent-worktrees/csv-unpack-bindings-20261124'
comparison = lab / 'comparison'
comparison.mkdir(exist_ok=True)
quiet = comparison / 'quiet'
quiet.mkdir(exist_ok=True)
read = lambda p: json.loads(p.read_text(encoding='utf-8'))
sha = lambda b: hashlib.sha256(b).hexdigest()
digest = lambda p: sha(p.read_bytes())


def write(path, source):
    path.write_text(source, encoding='utf-8', newline='\n')


def save(path, value):
    write(path, json.dumps(value, indent=2) + '\n')


head = subprocess.check_output(['git','rev-parse','HEAD'],cwd=tree).decode().strip()
parent = subprocess.check_output(['git','rev-parse','HEAD^'],cwd=tree).decode().strip()
assert parent.startswith('81444bec1')
prepare = (previous / 'prepare.py').read_text(encoding='utf-8').replace('81444bec1',head)
prepare = prepare.replace("    'src/Lokad.Lython/Runtime/LythonRuntime.Executable.NativePrefix.cs',\n",'')
prepare = prepare.replace('B1545','B1546').replace('(names[2], names[1], names[3], names[0])','(names[0], names[3], names[2])')
write(lab / 'prepare.py', prepare)
jit = (previous / 'jit-check.py').read_text(encoding='utf-8').replace(
    '*ReverseAssignmentValues* *CompleteFixedUnpack*','*ReverseAssignmentValues* *CompleteFixedUnpack* *CompleteParallelAssignment*')
write(lab / 'jit-check.py',jit)
(lab / 'allocations.py').write_bytes((previous / 'allocations.py').read_bytes())


def stage():
    archives = 'benchmarks/results/2026-11-24-parallel-local-transfer/'
    known = lambda name: subprocess.check_output(['git', 'show', 'origin/master:' + archives + name], cwd=repo)
    receipt = json.loads(known('terminal-status.json'))['receipt']
    assert receipt['complete'] and receipt['archivedAndVerifiedUnderLease']
    assert sha(known('observations.tar.xz')) == receipt['archiveSHA256']
    old = sha(gzip.decompress(known('candidate-core.dll.gz')))
    assert old == json.loads(known('identity.json'))['imageFiles']['candidate']['Lokad.Lython.dll']
    replicas = [dict(path='parallel-local-transfer-b1545-20261124/candidate/Lokad.Lython.dll', sha256=old,
        observationSHA256=receipt['archiveSHA256'], trackedArchive=archives)]
    save(lab / 'verified-replicas.json', replicas)
    worker = (previous / 'comparison/quiet/collect.py').read_text(encoding='utf-8').replace(
        'lython-b1545-fixtures', 'lython-b1546-fixtures').replace('len(jobs) == 4','len(jobs) == 3')
    compile(worker, 'collect.py', 'exec')
    write(quiet / 'collect.py', worker)
    (quiet / 'run.sh').write_bytes((previous / 'comparison/quiet/run.sh').read_bytes())
    assert b'\r' not in (quiet / 'run.sh').read_bytes()
    payload = quiet / 'payload.tar.gz'
    with tarfile.open(payload, 'w:gz') as archive:
        for name in ('identity.json','representative.json','jobs.json'):
            archive.add(comparison / name, arcname=name)
        for name in ('collect.py','run.sh'):
            archive.add(quiet / name, arcname=name)
        archive.add(lab / 'candidate/Lokad.Lython.dll', arcname='candidate-core.dll')
    save(quiet / 'upload.json', dict(root='isolated-local-transfer-b1546-20261124', reference='csv-unpack-bindings-b1544-20261124',
        payloadSHA256=digest(payload), payloadBytes=payload.stat().st_size))
    launch = (previous / 'quiet.py').read_text(encoding='utf-8').replace(
        'b1545-parallel-local-transfer-20261124','b1546-isolated-local-transfer-20261124').replace('b1545-', 'b1546-')
    launch = launch.replace('seconds=275','seconds=215').replace('RuntimeMaxSec=345','RuntimeMaxSec=275')
    write(lab / 'quiet.py', launch)
    summary = (previous / 'summarize.py').read_text(encoding='utf-8').replace('receipt["warmJobs"] == 4',
        'receipt["warmJobs"] == 3').replace('len(warm["jobs"])==4','len(warm["jobs"])==3').replace('timedBatches=112','timedBatches=84')
    write(lab / 'summarize.py', summary)


if (comparison / 'parallel-bindings.json').is_file():
    stage()
