from pathlib import Path
import hashlib
import importlib.util
import json
import os
import re
import subprocess
import tempfile

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
comparison = lab / 'comparison'
catalog = comparison / 'representative.json'
identity = json.loads((comparison / 'identity.json').read_text(encoding='utf-8'))
cases = json.loads(catalog.read_text(encoding='utf-8'))['cases']
protocol = repo / 'benchmarks/cpython-worker.py'
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
assert sha(protocol) == identity['cpythonWorkerSHA256']
assert sha(catalog) == identity['catalogs']['representative.json']['sha256']
spec = importlib.util.spec_from_file_location('protocol', protocol)
proto = importlib.util.module_from_spec(spec)
spec.loader.exec_module(proto)
sdk = Path.home() / '.dotnet11'
all_methods = {}
for role in ('reference', 'candidate'):
    image = lab / role
    files = identity['imageFiles'][role]
    assert len(files) == 32 and all(sha(image / name) == h for name, h in files.items())
    log = lab / (role + '-jit.asm')
    env = dict(os.environ, DOTNET_ROOT=str(sdk), DOTNET_ROOT_X64=str(sdk), DOTNET_TieredCompilation='0',
               DOTNET_JitDisasm='*RunCore* *ExecuteInstructionPrefix* *MoveConsecutiveBindings* *ReverseAssignmentValues* *CompleteFixedUnpack* *CompleteParallelAssignment* *NativeExecution:Call*',
               DOTNET_JitStdOutFile=str(log))
    with tempfile.TemporaryDirectory(prefix='lython-comparison-files-') as folder:
        child = subprocess.Popen([sdk / 'dotnet.exe', image / 'Lokad.Lython.Benchmarks.dll', '--compare', 'worker',
                                  '--catalog', catalog], cwd=folder, env=env, stdin=subprocess.PIPE,
                                 stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        error_log = lab / (role + '-jit.stderr')
        try:
            ready = proto.read_frame(child.stdout)
            assert ready['status'] == 'Ready' and ready['catalogSha256'] == sha(catalog)
            assert next(row['sha256'] for row in ready['libraries'] if Path(row['path']).name == 'Lokad.Lython.dll') == files['Lokad.Lython.dll']
            for index, case in enumerate(cases, 1):
                proof = {key: case[key] for key in ('sourceSha256', 'fixtureSha256', 'expectedOutputSha256')}
                request = dict(proof, protocolVersion=proto.PROTOCOL_VERSION, requestId=index, operation='verify',
                               caseId=case['id'], lane='warm', iterations=2)
                proto.write_frame(child.stdin, request)
                got = proto.read_frame(child.stdout)
                assert got['status'] == 'Equivalent' and all(got[k] == v for k, v in proof.items())
                assert got['actualOutputSha256'] == case['expectedOutputSha256']
                assert got.get('actualFilesSha256') == case.get('expectedFilesSha256')
            proto.write_frame(child.stdin, dict(protocolVersion=proto.PROTOCOL_VERSION, requestId=len(cases)+1, operation='quit'))
            assert proto.read_frame(child.stdout)['status'] == 'Closed'
            assert child.wait(timeout=10) == 0
        finally:
            if child.poll() is None:
                child.kill()
                child.wait()
            child.stdin.close()
            child.stdout.close()
            error_log.write_bytes(child.stderr.read())
            child.stderr.close()
        assert not error_log.read_bytes()
    methods = {}
    for body in log.read_text(encoding='utf-8', errors='replace').split('; Assembly listing for method '):
        if not body.startswith(('Lokad.Lython.Runtime.LythonRuntime+', 'Lokad.Lython.Runtime.LythonRuntime:')):
            continue
        name = body.splitlines()[0].split('(')[0]
        size = re.search(r'; Total bytes of code (\d+)', body)
        assert size, name
        assert name not in methods
        methods[name] = int(size.group(1))
    all_methods[role] = methods
    assert any('NativeExecution:RunCore' in name for name in methods)
    assert any('ExecutionContext:ExecuteInstructionPrefix' in name for name in methods)
    print(role, methods, flush=True)
(lab / 'jit-summary.json').write_text(json.dumps(all_methods, indent=2) + '\n', encoding='utf-8')
