from pathlib import Path

lab = Path(__file__).resolve().parent
prior = lab.with_name('parallel-local-transfer-20261124')
source = (prior / 'archive.py').read_text(encoding='utf-8')
source = source.replace('benchmarks/results/2026-11-24-parallel-local-transfer','benchmarks/results/2026-11-24-isolated-local-transfer')
source = source.replace("'81444bec1'", "identity['candidate']")
source = source.replace("terminal['warmJobs'] == 4", "terminal['warmJobs'] == 3")
source = source.replace("summary['timedBatches'] == 112", "summary['timedBatches'] == 84")
source = source.replace("len(cases) == 4 and cases == {row['case'] for row in summary['rows']}",
    "len(cases) == 4 and len(summary['rows']) == 3 and {row['case'] for row in summary['rows']} < cases")
source = source.replace('    published = record / (role', "    output = record if role == 'candidate' else repo / 'benchmarks/results/2026-11-24-csv-unpack-bindings'\n    published = output / (role")
source = source.replace('    published.write_bytes(', "    if role == 'candidate': published.write_bytes(")
source = source.replace("all(row['allocatedBytes'][0] == row['allocatedBytes'][1]\n    and row['peakAdmission'][0] == row['peakAdmission'][1] for row in allocation)",
    "all(row['peakAdmission'][0] == row['peakAdmission'][1] for row in allocation)\nassert [row['allocatedBytes'][1]-row['allocatedBytes'][0] for row in allocation] == [0,-56,56,0]")
source = source.replace("identity['candidate'],identity['candidate'],'--','src'",
    "identity['sourceRevision'],identity['candidate'],'--','src/Lokad.Lython/Runtime/LythonRuntime.Executable.NativePrefix.cs'")
compile(source, 'archive.py', 'exec')
(lab / 'archive.py').write_text(source, encoding='utf-8', newline='\n')
