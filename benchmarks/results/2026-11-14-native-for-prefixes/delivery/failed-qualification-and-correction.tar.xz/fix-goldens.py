from pathlib import Path
import json,shutil
r=Path(__file__).parent;target=Path('tests/Lokad.Lython.PublicApi.Tests/ForHelperExecutionTests.cs');shutil.copyfile(target,r/'ForHelperExecutionTests-before-lf.cs')
data=json.loads((r.parent/'python-controls.json').read_text(encoding='utf-8'))
text=target.read_text(encoding='utf-8');start=text.index('    public static IEnumerable<object[]> PythonControls()');end=text.index('    [Theory]\n    [MemberData(nameof(PythonControls))]',start)
def literal(source):return '"""\n'+''.join('            '+line+'\n'for line in source.splitlines())+'            """'
rows=['        yield return ['+json.dumps(v['name'])+', '+literal(v['source'])+', '+json.dumps(v['stdout'],ensure_ascii=False)+'];'for v in data]
body='''    public static IEnumerable<object[]> PythonControls()
    {
        // Escaped LF output stays identical to the Python golden under CRLF checkout.
'''+ '\n'.join(rows)+'''
    }

'''
target.write_text(text[:start]+body+text[end:],encoding='utf-8',newline='\n')
(r/'golden-correction.json').write_text(json.dumps(dict(failedRun='43560252672',failedJob='132342113958',failedCases=5,passedWhiteBox=4738,passedPublic=17700,cause='Raw multiline C# expected-output strings inherited checkout CRLF, while Python-compatible stdout was correctly LF. Local source files had LF, so focused tests did not expose this portability defect.',correction='Regenerate only expected outputs as escaped LF literals from the original independent CPython controls; actual output comparison remains exact.',productionChanged=False,originalFailedLogPreserved=True,crlfBuildQualificationRequired=True),indent=2)+'\n',encoding='utf-8',newline='\n')
print('Expected outputs now preserve the original exact Python LF bytes on every checkout.',flush=True)
