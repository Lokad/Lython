from pathlib import Path
import hashlib,json,os,subprocess
r=Path(__file__).parent;p=Path('tests/Lokad.Lython.PublicApi.Tests/ForHelperExecutionTests.cs');original=p.read_bytes();assert b'\r\n'not in original
env=dict(os.environ);env['DOTNET_ROOT']='C:/Users/JoannesVermorel/.dotnet11';env['PATH']=env['DOTNET_ROOT']+';'+env['PATH'];rows=[]
try:
 p.write_bytes(original.replace(b'\n',b'\r\n'));assert b'\r\n'in p.read_bytes()
 for target in ['net11.0','net10.0']:
  build=r/('crlf-build-'+target+'.log')
  with build.open('w',encoding='utf-8',newline='\n')as f:done=subprocess.run([env['DOTNET_ROOT']+'/dotnet.exe','build','tests/Lokad.Lython.PublicApi.Tests/Lokad.Lython.PublicApi.Tests.csproj','-c','Release','-f',target,'--no-restore','--no-incremental','--disable-build-servers','-m:1'],env=env,stdout=f,stderr=subprocess.STDOUT,timeout=180)
  assert done.returncode==0,build.read_text(encoding='utf-8')[-4000:]
  log=r/('crlf-test-'+target+'.log')
  with log.open('w',encoding='utf-8',newline='\n')as f:done=subprocess.run([env['DOTNET_ROOT']+'/dotnet.exe','test','tests/Lokad.Lython.PublicApi.Tests/Lokad.Lython.PublicApi.Tests.csproj','-c','Release','-f',target,'--no-build','--filter','FullyQualifiedName~ForHelperExecutionTests','--logger','trx','--results-directory',str((r/('crlf-'+target)).resolve())],env=env,stdout=f,stderr=subprocess.STDOUT,timeout=120)
  print(target,done.returncode,log.read_text(encoding='utf-8')[-2400:],flush=True);rows.append(dict(target=target,returncode=done.returncode,sourcePhysicallyCRLF=True,nonincrementalBuildBeforeNoBuild=True));(r/'crlf-checks.json').write_text(json.dumps(rows,indent=2)+'\n',encoding='utf-8',newline='\n');assert done.returncode==0
finally:
 p.write_bytes(original)
 (r/'crlf-restoration.json').write_text(json.dumps(dict(restoredExactOriginalLFBytes=hashlib.sha256(p.read_bytes()).digest()==hashlib.sha256(original).digest(),freshNonincrementalBuildRequiredBeforeNextNoBuild=True,productionUnchanged=True),indent=2)+'\n',encoding='utf-8',newline='\n')
