from pathlib import Path
import datetime,json,subprocess,sys
r=Path(__file__).parent;candidate=json.loads((r/'delivery-candidate.json').read_text(encoding='utf-8'));terminal=r/'ci-terminal.json'
if terminal.exists():print('Cached terminal:',json.loads(terminal.read_text(encoding='utf-8'))['conclusion']);sys.exit()
if (datetime.datetime.now(datetime.timezone.utc)-datetime.datetime.fromisoformat(candidate['dispatchedUTC'])).total_seconds()<240:print('Delivery under four minutes old; no query.');sys.exit()
snapshots=sorted(r.glob('ci-2*.json'))
if snapshots and datetime.datetime.now().timestamp()-snapshots[-1].stat().st_mtime<240:print('Last observation under four minutes old; no query.');sys.exit()
done=subprocess.run(['C:/Program Files/GitHub CLI/gh.exe','run','view',candidate['runId'],'--json','headSha,status,conclusion,jobs,url,createdAt,updatedAt'],capture_output=True,text=True,encoding='utf-8');assert done.returncode==0,done.stderr
d=json.loads(done.stdout);assert d['headSha']==candidate['head']
p=r/('ci-'+datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%SZ')+'.json');p.write_text(done.stdout,encoding='utf-8',newline='\n')
if d['status']=='completed':terminal.write_text(done.stdout,encoding='utf-8',newline='\n')
print(d['status'],d['conclusion'],[(j['name'],j['status'],j['conclusion'])for j in d['jobs']],flush=True)
