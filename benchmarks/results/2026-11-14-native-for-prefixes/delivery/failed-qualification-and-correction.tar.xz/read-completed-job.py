from pathlib import Path
import json,re,shutil,subprocess
r=Path(__file__).parent;data=json.loads(max(r.glob('ci-2*.json'),key=lambda p:p.stat().st_mtime).read_text(encoding='utf-8'))
for job in data['jobs']:
 if job['status']!='completed'or job['conclusion']!='failure':continue
 path=r/(str(job['databaseId'])+'-direct.log')
 if not path.exists():
  receipt=r/(str(job['databaseId'])+'-direct-receipt.json')
  if receipt.exists():shutil.copyfile(receipt,r/(str(job['databaseId'])+'-escape-refusal.json'))
  done=subprocess.run(['C:/Program Files/GitHub CLI/gh.exe','api','--allow-escape-sequences','repos/Lokad/Lython/actions/jobs/'+str(job['databaseId'])+'/logs'],capture_output=True,text=True,encoding='utf-8',timeout=60)
  (r/(str(job['databaseId'])+'-direct-receipt.json')).write_text(json.dumps(dict(returncode=done.returncode,stderr=done.stderr),indent=2)+'\n',encoding='utf-8',newline='\n')
  assert done.returncode==0,done.stderr;path.write_text(done.stdout,encoding='utf-8',newline='\n')
 lines=path.read_text(encoding='utf-8').splitlines();keep=set()
 for i,line in enumerate(lines):
  if any(word in line for word in ['[FAIL]','Failed ','Error Message:','Expected:','Actual:','Stack Trace:','Exception:']):keep.update(range(max(0,i-1),min(len(lines),i+12)))
 print(re.sub(r'\x1b\[[0-?]*[ -/]*[@-~]','', '\n'.join(lines[i]for i in sorted(keep)))[-20000:])
