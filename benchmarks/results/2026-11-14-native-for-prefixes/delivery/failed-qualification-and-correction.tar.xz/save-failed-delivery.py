from pathlib import Path
import hashlib,json,re,shutil,subprocess,tarfile
r=Path(__file__).parent;candidate=json.loads((r/'delivery-candidate.json').read_text(encoding='utf-8'));terminal=json.loads((r/'ci-terminal.json').read_text(encoding='utf-8'))
assert terminal['status']=='completed'and terminal['conclusion']=='failure'and terminal['headSha']==candidate['head']
jobs={j['name']:j for j in terminal['jobs']};assert jobs['tests (ubuntu-latest)']['conclusion']=='success'and jobs['tests (windows-latest)']['conclusion']=='failure'
checks=json.loads((r/'crlf-checks.json').read_text(encoding='utf-8'));assert len(checks)==2 and all(v['returncode']==0 and v['sourcePhysicallyCRLF']for v in checks)
logs=r/'run-logs'
if not logs.exists():
 done=subprocess.run(['C:/Program Files/GitHub CLI/gh.exe','run','download',candidate['runId'],'--pattern','test-log-*','--dir',str(logs.resolve())],capture_output=True,text=True,encoding='utf-8',timeout=120)
 (r/'download.log').write_text(done.stdout+done.stderr,encoding='utf-8',newline='\n');assert done.returncode==0,done.stderr
identity=json.loads((r.parent/'candidate-identity.json').read_text(encoding='utf-8'));rows=[]
with tarfile.open(r.parent/'candidate-sources.tar.xz')as t:
 for path,sha in identity['sources'].items():
  frozen=t.extractfile(path).read();committed=subprocess.check_output(['git','show',candidate['head']+':'+path]);assert hashlib.sha256(frozen).hexdigest()==sha and frozen.replace(b'\r\n',b'\n')==committed.replace(b'\r\n',b'\n'),path
for path in logs.rglob('*.log'):
 text=path.read_text(encoding='utf-8-sig');summaries=[line for line in text.splitlines()if 'Passed!'in line or 'Failed!'in line or 'package consumer'in line.lower()]
 rows.append(dict(path=path.relative_to(r).as_posix(),sha256=hashlib.sha256(path.read_bytes()).hexdigest(),summaries=summaries))
(r/'partial-qualification.json').write_text(json.dumps(dict(head=candidate['head'],coreSHA256=candidate['coreSHA256'],runId=candidate['runId'],overall='failure; not fully qualified',windows='Release net11 failed only five CRLF-dependent expected-output fixtures; later checkpoint stages skipped.',ubuntu='Full actual11/10, original stress and installed Release consumer steps succeeded.',sourceInputs=581,allFrozenSourcesMatchCommitWithExplicitNewlineNormalization=True,logSummaries=rows,correction='Expected goldens regenerated as escaped LF literals. No actual-output normalization or runtime change.',focusedCRLF='12 public cases pass per actual11/10 after forced nonincremental builds of physically CRLF test source. These local checks run on the active R346 prototype; exact corrected R345/full descendant qualification remains pending.',rerun='Batch corrected goldens with the next coherent retained cursor milestone. Original failed qualification remains immutable.',publication='held'),indent=2)+'\n',encoding='utf-8',newline='\n')
out=Path('benchmarks/results/2026-11-14-native-for-prefixes/delivery');out.mkdir(exist_ok=True)
for name in ['ci-terminal.json','delivery-candidate.json','partial-qualification.json','golden-correction.json','crlf-checks.json','crlf-restoration.json']:shutil.copyfile(r/name,out/name)
with tarfile.open(out/'failed-qualification-and-correction.tar.xz','w:xz')as t:
 for p in sorted(r.rglob('*')):
  if p.is_file():t.add(p,arcname=p.relative_to(r).as_posix(),recursive=False)
(out/'README.md').write_text('''# Original native-for qualification: failed Windows golden fixtures

Run43560252672 qualifies exact `3d78d429`/frozen `8306699f` and remains **failed**.
Windows passes4738white-box and17700public cases, but five new public goldens
inherit CRLF from checkout while the runtime correctly emits LF. Later Windows
checkpoint stages are skipped. Ubuntu completes actual11/10, original stress and
installed Release consumer steps successfully. Logs and all581normalized frozen
source/commit matches are preserved; this is not full cross-platform qualification.

Only expected-output fixtures change to escaped LF literals generated from the
original independent Python controls. Actual output comparisons remain exact.
Forced nonincremental builds of physically CRLF source pass all12for-helper cases
per actual11/10. Those local checks use the active R346prototype, so full corrected
R345/descendant qualification remains pending. Batch it at the next retained cursor
checkpoint; do not rewrite this original failure or repeat unchanged timing.
Publication remains held.

[Terminal jobs/steps](ci-terminal.json), [source/log assessment](partial-qualification.json),
[correction](golden-correction.json), [raw logs, original fixtures and CRLF checks](failed-qualification-and-correction.tar.xz).
''',encoding='utf-8',newline='\n')
print('Original failed qualification archived; Ubuntu full success and Windows fixture correction are distinguished.',flush=True)
