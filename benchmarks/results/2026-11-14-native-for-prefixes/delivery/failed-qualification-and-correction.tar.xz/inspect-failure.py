from pathlib import Path
import json,subprocess
r=Path(__file__).parent;p=max(r.glob('ci-2*.json'),key=lambda p:p.stat().st_mtime);data=json.loads(p.read_text(encoding='utf-8'))
for j in data['jobs']:
 print(j['name'],j['status'],j['conclusion'],j['databaseId'],[(s['name'],s['conclusion'])for s in j['steps']if s['conclusion']=='failure'])
 if j['conclusion']=='failure':
  target=r/(str(j['databaseId'])+'-failed.log')
  if not target.exists():
   done=subprocess.run(['C:/Program Files/GitHub CLI/gh.exe','run','view',str(data.get('databaseId','43560252672')),'--job',str(j['databaseId']),'--log-failed'],capture_output=True,text=True,encoding='utf-8',timeout=60)
   target.write_text(done.stdout+done.stderr,encoding='utf-8',newline='\n');assert done.returncode==0,done.stderr
  lines=target.read_text(encoding='utf-8').splitlines();hits=[i for i,line in enumerate(lines)if any(word in line for word in ['[FAIL]','Failed ','Error Message:','Expected:','Actual:','Stack Trace:','Exception:'])]
  keep=set()
  for i in hits:
   keep.update(range(max(0,i-1),min(len(lines),i+10)))
  print('\n'.join(lines[i]for i in sorted(keep))[-17000:])
