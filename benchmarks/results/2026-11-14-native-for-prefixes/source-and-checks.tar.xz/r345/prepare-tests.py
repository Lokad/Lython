from pathlib import Path
import json,subprocess
r=Path(__file__).parent
programs=[('loop-control', '''def count(values):
    total=0
    item=None
    for item in values:
        if item==2: continue
        if item==5: break
        total+=item
    else: total+=100
    return item,total
print([count(values) for values in [[],[1],[1,2,3],[1,2,3,4,5,6],(1,2,3),range(3),b'123']])
def missing(values):
    for item in values: pass
    return item
try: missing([])
except UnboundLocalError: print('unbound')
'''),('nested-exits-and-words', '''def compute(values):
    total=0
    for i in values:
        for j in (1,2,3):
            if j==2: continue
            total+=i*10+j
            if i==2: break
        else: total+=100
    return total
print(compute([0,1,2,3]))
def words(value):
    first=None
    for word in value.upper().split():
        if first is None: first=word
        if word=='STOP': break
    return first,word
print(words('ßé café stop later'))
def select(values):
    for item in values:
        if item>2: return item
    return None
print(select((1,2,3,4)),select(()))
'''),('mutation-and-aliases', '''def take(values):
    total=0
    for item in values:
        if item==1: values.append(4)
        total+=item
    return item,total
values=[1,2,3]
print(take(values),values)
def change(values):
    for item in values:
        values['new']=9
    return item
try: change({'a':1,'b':2})
except RuntimeError: print('changed')
def keep(values):
    first=None
    for item in values:
        if first is None: first=item
    return first,item
values=[[1],[2]]
first,last=keep(values)
first.append(9)
print(first,last,first is values[0],last is values[1])
'''),('unicode-and-promotion', '''def collect(text):
    total=0
    for character in text:
        total+=len(character)
    return character,total
print(collect('α😀é𐐨'))
def grow(values):
    total=9223372036854775807
    for value in values: total=total*3+value
    alias=total
    return total,alias is total
print(grow((1,2,3)))
def count(values):
    total=0
    for value in values: total+=1
    return total
print(count({'a':1,'b':2}),count({1,2,3}))
'''),('iterator-and-body-transition', '''events=[]
class Values:
    def __iter__(self):
        events.append('iter')
        return iter((1,2,3))
def total(values):
    result=0
    for item in values: result+=item
    return result
print(total(Values()),events)
class Number:
    def __radd__(self,other):
        events.append(other)
        return other+7
print(total([1,2,Number(),4]),events)
''')]
entries=[];rows=[]
for name,source in programs:
 done=subprocess.run(['C:/Python313/python.exe','-I','-S','-X','utf8','-c',source],capture_output=True,text=True,encoding='utf-8',timeout=15)
 assert done.returncode==0 and not done.stderr,(name,done.stderr)
 (r/(name+'.py')).write_text(source,encoding='utf-8',newline='\n');(r/(name+'.stdout')).write_text(done.stdout,encoding='utf-8',newline='\n')
 entries.append(dict(name=name,source=source,stdout=done.stdout,reference='CPython3.13.2 isolated'))
 def literal(value):
  return '"""\n'+''.join('            '+line+'\n'for line in value.splitlines())+'            """'
 rows.append('        yield return ['+json.dumps(name)+', '+literal(source)+', '+literal(done.stdout)+' + "\\n"];')
(r/'python-controls.json').write_text(json.dumps(entries,indent=2,ensure_ascii=False)+'\n',encoding='utf-8',newline='\n')
template='''using Lokad.Lython.Tests.Harness;

namespace Lokad.Lython.PublicApi.Tests;

public sealed class ForHelperExecutionTests
{
    public static IEnumerable<object[]> PythonControls()
    {
ROWS
    }

    [Theory]
    [MemberData(nameof(PythonControls))]
    public async Task OrdinaryForHelpersPreservePythonBehavior(string name, string source, string expected)
    {
        _ = name;
        var budget = new LythonMemoryBudget(4 * 1024 * 1024);
        using (var script = new LythonEngine().Compile(source, budget))
        {
            Assert.True(script.IsValid, string.Join("; ", script.Diagnostics.Select(d => d.Message)));
            var baseline = budget.ReservedBytes;
            foreach (var asynchronous in new[] { false, true })
            {
                using (var result = asynchronous ? await script.RunAsync(new MockLythonHost()) : script.Run(new MockLythonHost()))
                {
                    Assert.True(result.Success, result.Failure?.Message);
                    Assert.Equal(expected, result.StandardOutput);
                }
                Assert.Equal(baseline, budget.ReservedBytes);
            }
        }
        Assert.Equal(0, budget.ReservedBytes);
    }
}
'''.replace('ROWS','\n'.join(rows))
Path('tests/Lokad.Lython.PublicApi.Tests/ForHelperExecutionTests.cs').write_text(template,encoding='utf-8',newline='\n')
print('Independent Python loop controls prepared.',flush=True)
