from pathlib import Path
import json,os,subprocess
r=Path(__file__).parent;env=dict(os.environ);env['DOTNET_ROOT']='C:/Users/JoannesVermorel/.dotnet11';env['PATH']=env['DOTNET_ROOT']+';'+env['PATH'];rows=[]
for target in ['net11.0','net10.0']:
 log=r/('promotion-'+target+'.log')
 with log.open('w',encoding='utf-8',newline='\n')as f:done=subprocess.run([env['DOTNET_ROOT']+'/dotnet.exe','test','tests/Lokad.Lython.Tests/Lokad.Lython.Tests.csproj','-c','Release','-f',target,'--no-restore','--disable-build-servers','-m:1','--filter','FullyQualifiedName~RefusedOrCancelledOutputAfterForPromotion','--logger','trx','--results-directory',str((r/('promotion-'+target)).resolve())],env=env,stdout=f,stderr=subprocess.STDOUT,timeout=180)
 print(target,done.returncode,log.read_text(encoding='utf-8')[-3500:],flush=True);rows.append(dict(target=target,returncode=done.returncode,log=log.name));(r/'promotion-checks.json').write_text(json.dumps(rows,indent=2)+'\n',encoding='utf-8',newline='\n');assert done.returncode==0
