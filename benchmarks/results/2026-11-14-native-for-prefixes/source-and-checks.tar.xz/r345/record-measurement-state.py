from pathlib import Path
import hashlib,json
r=Path(__file__).parent;identity=json.loads((r/'candidate-identity.json').read_text(encoding='utf-8'))
assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==sha for p,sha in identity['sources'].items())
for role in ['reference','candidate']:
 expected=dict(identity['auxiliaryFiles'][role],**{'Lokad.Lython.dll':identity['coreSHA256'][role]})
 assert expected=={p.name:hashlib.sha256(p.read_bytes()).hexdigest()for p in(r/role).iterdir()if p.is_file()}
original=json.loads((r/'allocation-summary.json').read_text(encoding='utf-8'))
assert all(hashlib.sha256((r/('allocation-'+role+'-catalog.json')).read_bytes()).hexdigest()==original['roleCatalogSHA256'][role]for role in ['reference','candidate'])
(r/'measurement-state.json').write_text(json.dumps(dict(frozenCore=identity['coreSHA256'],all581SourceInputsUnchanged=True,allCopiedImagesAndAuxiliaryHashesUnchanged=True,originalThreeAllocationCatalogsUnchanged=True,sourceHypothesisCorrection='The ordinary list/tuple prefix already defers its invocation context and uses a direct-position array. The text-input CSV route promotes at generic GetIter; its 25.31% allocation reduction must not be generalized to lists. The list variant allocates more, and CPU qualification is pending.',scope='Native opcode eligibility and exact builtin iteration, no new Python syntax support or whole-runtime speedup claim.',vm=json.loads((r/'b714/observe-not-before.json').read_text(encoding='utf-8')),firstStagingFailure='Missing immutable reference link after checked partial staging; service absent, no guest/measurement started. Same verified root completed under fresh idle lease. Original failure retained.'),indent=2)+'\n',encoding='utf-8',newline='\n')
p=Path('PLAN.md');text=p.read_text(encoding='utf-8');needle='   (360s work/60s cleanup); no10min lane or full benchmark campaign.';assert needle in text
text=text.replace(needle,needle+'\n   B714same frozen830/qualified53 pair is active; do not observe before52:10UTC\n   on2026-11-14. The first staging attempt omitted the immutable reference link\n   before any service/guest ran; preserve it. Complete the same verified partial\n   root under a new idle lease, keeping VM floors and all current evidence intact.\n   Baseline list/tuple iteration already defers its frame; do not generalize the\n   string-input allocation gain to lists or assume all for loops need a frame.')
p.write_text(text,encoding='utf-8',newline='\n')
print('Frozen source/image proof and active owned comparison recorded; no elapsed claim.',flush=True)
