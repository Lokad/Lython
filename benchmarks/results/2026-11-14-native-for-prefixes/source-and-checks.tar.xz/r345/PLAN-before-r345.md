# Lokad.Lython 0.11.0

Updated2026-11-14. Git-ignored; never force-add. Publication/tagging postponed.
Objective: coherent simplification and substantial complete-script performance,
including newly generated scripts. A green delivery or isolated experiment is a
checkpoint, not completion of this objective. Experimental history belongs in
[EXPERIMENTS](benchmarks/EXPERIMENTS.md), immutable results and saved plan history.

## Actual delivery status

| State | Evidence and limits |
| --- | --- |
| Previous fully qualified runtime | R338c48c93ae/e2482e0b removes backward-edge exclusion; R3391778c30d/38c0562f separates native eligibility from16-slot private transport.637internal/1562public per actual11/10; GREEN43545993574: Windows/Ubuntu actual11/10, original stress and installed consumers;581inputs/16summaries cached. [Delivery](benchmarks/results/2026-11-14-native-owned-slots/delivery/README.md). CSV check-digit warm−17..−19.5%/fresh−14.8..−16.8%, allocation flat. Fulfillment warm−12.88..−13.73%/fresh−14.57..−16.09%, allocation−9.84%. Wider CPU supports both affected results; control uncertainty remains. [R338](benchmarks/results/2026-11-14-native-backedges/README.md),[R339](benchmarks/results/2026-11-14-native-owned-slots/README.md). |
| Latest fully qualified runtime | R3412f606519/53becdb6shares closed arithmetic across ordinary/native bodies and removes the native-only file.927internal/1871public per actual11/10. Inline fulfillment allocation−10.45%, warm−2.98..−4.01%, fresh−1.40..−2.67%with wider CPU support; helper uncertainty/text adversity retained. GREEN43548640898: Windows/Ubuntu actual11/10, original stress and installed consumers;581inputs/16summaries cached. [Delivery](benchmarks/results/2026-11-14-shared-integer-chains/delivery/README.md). [Evidence](benchmarks/results/2026-11-14-shared-integer-chains/README.md). |
| Retained tests/evidence | e1bb0b84 commits the withdrawn R343 evidence and five public regressions; focused actual11/10 checks pass. Production and optional adapter are unchanged from the qualified baseline. The new tests are not separately full-platform qualified yet; batch them at the next runtime delivery. |
| Runtime prototypes | None retained. R343 bulk cased-buffer/range-inventory removal is withdrawn: captured text warm +8.35..+13.41%, direct text +12.48..+22.58%, wider CPU adverse, CSV control nearly flat and allocation effectively flat. All 581 qualified R341 input bytes restored exactly; useful public regressions retained. [Decision and evidence](benchmarks/results/2026-11-14-bulk-cased-buffer-withdrawn/README.md). |
| Current external comparison, committed evidence d2f11698 | R340/B710runtime1778c30d/frozen38,2026-11-14, stockCPython3.13.16: invoice warm1.21–1.24×, compile1.09–1.10×, fresh1.20–1.28×; captured text1.51–1.63×, search1.64–1.69×, JSON0.82–0.83×, report1.17–1.21×, fulfillment1.29–1.32×. Fresh invoice/text process spreads5.96/6.58%remain inconclusive. Config row retains qualifiedcdd/f4 source. These ratios describe their measured sources, not current HEAD. [Boundaries/evidence](docs/BENCHMARKS.md). |
| Remaining uncertainty | Historical formatting15.125ms adversity remains unexplained; two controlled confirmations support retention. Original native-return elapsed is diagnostic. R334 XML cost, earlier report/search controls, R338invoice and R339small-helper controls remain explicit debt. Do not infer release-wide neutrality or add percentages across source pairs. |

## Completed foundations

- Shared compiler facts/nonlocal correction, annotation demand and lowered-tree
  retention cleanup are delivered. [Compiler evidence](benchmarks/results/2026-11-02-shared-compiler-facts/README.md).
- Direct UTF8 formatting/storage: original allocation−8.67%, later pair−8.59%;
  two controlled report CPU/elapsed blocks support−5..−8%on those sources. Keep
  original adverse clocks/failed conditions. [Evidence](benchmarks/results/2026-11-02-formatting-confirmation/README.md).
- Native helper returns: historical whole-run allocation−19.92%CSVhelpers and
  −19.31%JSONhelpers, separate from diagnostic elapsed. Corrected full delivery
  8f07764a complete. [Evidence](benchmarks/results/2026-11-02-native-function-returns/README.md).
- Revised bulk CSV already selectively revisited the6–8%opportunity and shipped
  admitted array adoption/shared keys. R308/R314 alternatives remain withdrawn
  with useful lifetime regressions retained. [Evidence](benchmarks/results/2026-11-02-native-csv-records/README.md).
- Calls share final slots/linear continuations/native prefixes across Run/RunAsync.
  Integer chains/counters avoid many boxes. Tuple transport, immutable builtin
  definitions, positional ZIP and native UTF8 JSON input are delivered. R335adds
  incremental XML/shared construction. Keep real suspension and stack handoff.
- Slower call-arena/control designs remain lessons. R325/R327 do not establish a
  dominant removable packet/frame; all46native-entry samples resolve against
  same-process Tier1 code. Default dictionary work is actual work. R338's initial
  frame-allocation explanation was corrected: ordinary bound prefixes already
  defer contexts. No large frame/storage removal is claimed for eligibility alone.
- R328exact frozen316 initial CI failure remains a historical failure. Descendant
  qualification does not rewrite it. All failed/adverse evidence survives.

## Prioritized deliverables

1. **Qualified baseline and completed source gate.** R341 `2f606519`/frozen53 is
   fully green on Windows/Ubuntu actual11/10, original stress and installed consumers
   (43548640898). Terminal/source proof/16summaries are cached: no unchanged replay.
   R342 maps all168 dictionary-loop IPs to same-process code; useful hash/update and
   mixed transport work establish no dominant removable call packet. R343 replaces
   ranges with an owned full cased buffer, then is withdrawn after clear CPU adversity
   and flat allocation. Retain all failures/corrections and useful public semantics;
   exact baseline restoration passes103internal/484public plus3original64MiB rollback
   cases per actual11/10 after a forced nonincremental Release rebuild. No runtime
   prototype or VM user remains. [R342](benchmarks/results/2026-11-14-captured-loop-attribution/README.md),
   [R343](benchmarks/results/2026-11-14-bulk-cased-buffer-withdrawn/README.md).

2. **Next substantial runtime milestone: select a whole execution stage to remove.**
   Inspect the remaining ordinary/native dispatch and activation boundary on current
   complete search/text/CSV scripts. Hypothesis: shared prepared inputs and lazy
   activation may permit deleting duplicated operation routing, rather than another
   argument/default/entry special case. This is a source question, not an established
   CPU cause or a commitment to merge engines. First bound the comparison to current
   owning evidence and actual duplicate work; identify an entire displaced route,
   activation or representation and its callers. Initial source follow-up confirms
   shared final slots, already-deferred contexts and distinct stack/resumable lifetimes;
   do not equate two routers with duplicate runtime work. Select an owning complete
   stage before implementation, with no new dispatcher/arena/backend merely to
   rearrange the same work. [Source gate](benchmarks/results/2026-11-14-post-buffer-source-gates/README.md).

   Selected migration acceptance: exact evaluation/error order, live closures/defaults,
   ordinary/native/RunAsync equivalence, genuine suspension with once-only transfer,
   managed stack admission, current-token cancellation and funded pending cleanup.
   Compare affected complete scripts warm and compile-to-result plus an unchanged
   control; report allocation independently. Permit bounded refinement and temporary
   debt only with an explicit completion milestone and a decision on remaining debt.
   R343 cautions against adding repeated text scans to remove modest cached storage;
   a future text representation must remove actual work, not repeat the same design.
   R336 found no dominant setup/compile stage: do not repeat unchanged phase captures
   or subtract independent phase medians as attribution.

   | Area | Work/storage to eliminate; semantic acceptance and displacement |
   | --- | --- |
   | Complete calls/frames and operand transport | Existing final slots/native bound spans remove repackaging and unnecessary eligibility limits. Select a remaining full activation/storage stage only with owning evidence; remove its displaced route, no new arena/control backend. Preserve live defaults/receivers/closures, Python errors, pending transfers and awaited cleanup. Assess native iteration's remaining unsupported opcodes without assuming frame allocation. |
   | Per-record construction | CSV adopted/shared-key rows, native counters and iterative JSON are present; XML now avoids unused records. Next change must remove an actual representation/copy/pass in complete scripts and retire the constructor. Preserve mapping callbacks, mutation, aliases and admission-before-effect; do not relabel R308/R314. |
   | Scalar dispatch | Native integer chains/counter slots already reduce boxes. Object-valued operands remain. Establish remaining boxing/transport dominance before choosing a wider representation; exact promotion, identity and aliases are mandatory. A universal tagged-value VM is unselected. |
   | Bulk text conversion | ASCII casing/UTF8 word probes/direct formatting exist. Remove a remaining complete conversion/build stage, not isolated scalar tweaks. Preserve Unicode expansion/context, error order and actual callback suspension; delete superseded conversion code. |
   | Frontend analysis | Duplicate-name modeling accounted for only0.41–0.95%allocation on the studied source. Consolidate proven repeated facts/retained IR with diagnostics/scopes/nonlocals/cancellation and budget cleanup intact; multiple visitors alone do not prove dominance. |

   Before a selected prototype, record hypothesis, eliminated work/storage, affected
   complete scripts, semantic/cancellation/ownership acceptance, implementation to
   delete, bounded before/after/control comparison and regression-debt decision.
   Temporary setbacks are acceptable in a justified redesign with an explicit
   completion milestone. Stop an investigation once it can select or reject that
   bounded change; do not turn uncertainty into an open-ended audit.

3. **Regex develops independently.** Core owns Python-specific nativeUTF8/original
   windows/byte-scalar/capture/flag/error/current-token contract and existing owners/
   caches. Dev producers and adapter-local bridges remain permitted. Core has no
   backend edge. Completed dev80/15b248dc88internal/534public per11/10 checks are not
   rerun; normal29inputs/binaries/optional0.4nonpackable adapter remain unchanged.
   Read-only dev84worktreeae463cb4 and immutable package834162df are distinct source
   identities. Missing capabilities: separate one-match work/result owners, native
   UTF8group-name enumeration/copy, token-independent cursor construction with
   cancellable preparation. Only affected final adapter qualification defers.
   Select the next concrete change from changed Lython code/contract or new producer
   capability; no sibling mutation/pin promotion or repeated unchanged qualification.
   [Assessment](benchmarks/results/2026-11-14-regex-provider-capabilities/README.md).
   Distinguish contract tests, semantics and real backend performance/safety.

## Evidence policy and lasting constraints

Separate simplification, allocation reduction and demonstrated CPU improvement.
Percentages inform decisions, not automatic vetoes. Timeouts, unstable unchanged
controls and inconclusive observations establish uncertainty. Permit bounded
confirmation/refinement/measurement correction for an explicit reason, retaining
original failed conditions and all adverse points. No blanket one-attempt,
no-retiming or permanently-closed rule.

Use focused Release correctness/cancellation/ownership checks during iteration;
batch Windows/Ubuntu actual11/10, original stress and installed Release consumers
at coherent checkpoints. Remain fully managed/memory-safe; no unsafe compilation/
C#/APIs, pointers, P/Invoke or native probing. Preserve managed stack admission,
host capabilities/original paths+Cwd, cancellation, cycles/XML depth, checked
representation bounds and bounded I/O chunks. No fuel/quotas, hidden caps/default
allowance, regex work/time policy, heap tracing, weak reclamation, forced GC or
abandoned users. Borrowed allowance funds capacity/overlap, aliases/results/caches
and pending users. First refusal is terminal through suppression/finally; preserve
its origin, await cleanup, never retry. Long streams use bounded host executions.
Force nonincremental builds after restoration; copy/verify frozen sources/bits and
auxiliary worker/adapter. Persist evidence, join users, preserve VM floors/current
images. Current docs stay concise/Lython-centric. See[AGENTS](AGENTS.md).
