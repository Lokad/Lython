import csv

def digit_sum(value):
    total=0
    for character in value:
        total+=int(character)
    return total

totals={}
count=0
with open('input.csv',newline='') as source:
    for row in csv.DictReader(source):
        check=digit_sum(row['code'])
        group=row['group']
        totals[group]=totals.get(group,0)+check
        count+=1
with open('report.csv','w',newline='') as target:
    writer=csv.writer(target,lineterminator='\n')
    writer.writerow(['group','digit_sum'])
    for group in sorted(totals): writer.writerow([group,totals[group]])
print(count,sum(totals.values()))
