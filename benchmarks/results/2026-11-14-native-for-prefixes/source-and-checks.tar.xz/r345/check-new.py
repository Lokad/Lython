from pathlib import Path
import json,os,subprocess
r=Path(__file__).parent;env=dict(os.environ);env['DOTNET_ROOT']='C:/Users/JoannesVermorel/.dotnet11';env['PATH']=env['DOTNET_ROOT']+';'+env['PATH'];rows=[]
for target in ['net11.0','net10.0']:
 for assembly,filter in [('Lokad.Lython.Tests','FullyQualifiedName~SimpleFunctionExecutionBoundaryTests'),('Lokad.Lython.PublicApi.Tests','FullyQualifiedName~ForHelperExecutionTests|FullyQualifiedName~WhileHelperExecutionTests|FullyQualifiedName~NativeSequenceIterationTests|FullyQualifiedName~BulkCasedSplitTests')]:
  log=r/(assembly+'-new-'+target+'.log')
  with log.open('w',encoding='utf-8',newline='\n')as f:done=subprocess.run([env['DOTNET_ROOT']+'/dotnet.exe','test',f'tests/{assembly}/{assembly}.csproj','-c','Release','-f',target,'--no-restore','--disable-build-servers','-m:1','--filter',filter,'--logger','trx','--results-directory',str((r/(assembly+'-new-'+target)).resolve())],env=env,stdout=f,stderr=subprocess.STDOUT,timeout=180)
  print(assembly,target,done.returncode,log.read_text(encoding='utf-8')[-2500:],flush=True);rows.append(dict(assembly=assembly,target=target,returncode=done.returncode,log=log.name));(r/'new-checks.json').write_text(json.dumps(rows,indent=2)+'\n',encoding='utf-8',newline='\n');assert done.returncode==0
