from pathlib import Path
import ast,base64,datetime,hashlib,json,subprocess,tarfile
r=Path(__file__).parent;config=json.loads((r/'config.json').read_text(encoding='utf-8'))
assert (r/'launch.log').exists()and not(r/'observe-not-before.json').exists()
assert b'FileNotFoundError'in(r/'launch.log').read_bytes()
frozen=json.loads((r.parent/'candidate-identity.json').read_text(encoding='utf-8'))
assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==sha for p,sha in frozen['sources'].items())
with tarfile.open(r/'payload.tgz')as t:payloadFiles={m.name:hashlib.sha256(t.extractfile(m).read()).hexdigest()for m in t.getmembers()if m.isfile()}
code='''from pathlib import Path
import ast,fcntl,hashlib,json,os,shutil,subprocess
config=CONFIG
payloadFiles=PAYLOAD
base=Path('/home/lokad/lython-bench-checks').resolve();root=Path(config['root']);source=Path(config['sourceRoot'])
assert root.parent==base and source.parent==base and root.resolve()==root and source.resolve()==source
digest=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
with(base/'comparison-vm.lock').open('a')as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 state=subprocess.run(['systemctl','show',config['unit']+'.service','--property=LoadState,ActiveState,MainPID'],capture_output=True,text=True)
 assert 'LoadState=not-found'in state.stdout and 'MainPID=0'in state.stdout and 'ActiveState=inactive'in state.stdout,state.stdout
 assert not(root/'guest-fixtures').exists()and not(root/'confirmation').exists()and not(root/'exit-code.txt').exists()
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[d]otnet.*complete-jobs.dll|[p]erf record|[p]ython3.*cpython-worker.py'],capture_output=True).returncode==1
 assert all(p.name in set(payloadFiles)|{'cpython-worker.py','reference'}for p in root.iterdir())
 assert all(digest(root/name)==sha for name,sha in payloadFiles.items())
 for name,sha in config['identity']['candidateAuxiliaryFiles'].items():assert digest(source/'candidate'/name)==sha
 assert digest(source/'candidate/Lokad.Lython.dll')==config['identity']['coreSHA256']['reference']
 before=shutil.disk_usage(base).free;assert before>254*1024*1024
 os.link(source/'candidate/Lokad.Lython.dll',root/'reference-core.dll')
 for role in ['reference','candidate']:
  folder=root/role;folder.mkdir(exist_ok=True)
  expected=dict(config['identity'][role+'AuxiliaryFiles'],**{'Lokad.Lython.dll':config['identity']['coreSHA256'][role]})
  assert all(p.name in expected and p.is_file()and not p.is_symlink()for p in folder.iterdir())
  for name,sha in expected.items():
   p=folder/name
   if not p.exists():os.link(root/(role+'-core.dll')if name=='Lokad.Lython.dll'else source/'candidate'/name,p)
   assert digest(p)==sha
 for name in ['collect.py','archive-owned.py']:ast.parse((root/name).read_text())
 subprocess.run(['/bin/sh','-n',str(root/'run.sh')],check=True)
 after=shutil.disk_usage(base).free;assert after>254*1024*1024
 (root/'space-preflight.json').write_text(json.dumps(dict(freshIdleLease=True,beforeFreeBytes=before,afterStagingFreeBytes=after,osFloorMiB=240,evidenceHeadroomMiB=12,additionalArchiveHeadroomMiB=2,noRetirement=True,stagingCorrection='Complete same verified partial root after missing immutable reference link; no earlier service, guest or measurement.',priorServiceState=state.stdout))+'\\n')
 fixture=root/'guest-fixtures';fixture.mkdir()
 subprocess.run(['sudo','-n','mount','-t','tmpfs','-o','size=128m,mode=0700,uid=lokad,gid=lokad','lython-b714-fixtures',str(fixture)],check=True)
try:subprocess.run(['sudo','-n','systemd-run','--unit='+config['unit'],'--property=User=lokad','--property=WorkingDirectory='+str(root),'--property=RuntimeMaxSec=420','--property=TimeoutStopSec=30','--property=KillMode=control-group','/bin/sh',str(root/'run.sh')],check=True)
except BaseException:
 subprocess.run(['sudo','-n','umount',str(fixture)],check=True);fixture.rmdir();raise
print(subprocess.check_output(['systemctl','show',config['unit']+'.service','--property=ActiveState,MainPID,RuntimeMaxUSec'],text=True))
'''.replace('CONFIG',repr(config)).replace('PAYLOAD',repr(payloadFiles))
ast.parse(code);(r/'resume-launch-command.py').write_text(code,encoding='utf-8',newline='\n')
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
command="python3 -c 'import base64;exec(base64.b64decode(\""+base64.b64encode(code.encode()).decode()+"\"))'"
done=subprocess.run(ssh+[command],capture_output=True,timeout=45)
(r/'resume-launch.log').write_bytes(done.stdout+done.stderr);print((done.stdout+done.stderr).decode(),flush=True);assert done.returncode==0
now=datetime.datetime.now(datetime.timezone.utc)
(r/'observe-not-before.json').write_text(json.dumps(dict(startedUTC=now.isoformat(),doNotObserveBeforeUTC=(now+datetime.timedelta(seconds=360)).isoformat(),ownerSeconds=420,stopSeconds=30,firstStagingFailurePreserved=True),indent=2)+'\n',encoding='utf-8',newline='\n')
