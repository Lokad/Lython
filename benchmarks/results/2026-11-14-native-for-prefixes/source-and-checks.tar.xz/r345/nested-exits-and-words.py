def compute(values):
    total=0
    for i in values:
        for j in (1,2,3):
            if j==2: continue
            total+=i*10+j
            if i==2: break
        else: total+=100
    return total
print(compute([0,1,2,3]))
def words(value):
    first=None
    for word in value.upper().split():
        if first is None: first=word
        if word=='STOP': break
    return first,word
print(words('ßé café stop later'))
def select(values):
    for item in values:
        if item>2: return item
    return None
print(select((1,2,3,4)),select(()))
