from pathlib import Path
import json,shutil
r=Path(__file__).parent;out=r/'promotion-no-admission';out.mkdir()
for name in ['promotion-net11.0','promotion-net11.0.log','promotion-checks.json']:
 p=r/name
 if p.is_dir():shutil.copytree(p,out/name)
 else:shutil.copyfile(p,out/name)
p=Path('tests/Lokad.Lython.Tests/SimpleFunctionExecutionBoundaryTests.cs');shutil.copyfile(p,out/p.name)
text=p.read_text(encoding='utf-8');start=text.index('    public void RefusedOrCancelledForPromotionRetiresCursorBeforeCallingTheBody');end=text.index('    [Theory]',start)
replacement='''    public void RefusedOrCancelledOutputAfterForPromotionPreservesInputAndCleanup(bool cancel)
    {
        foreach (var driver in Enum.GetValues<Driver>())
        {
            var budget = new LythonMemoryBudget(1024 * 1024);
            using (var owner = budget.CreateScope())
            using (var cancellation = new CancellationTokenSource())
            {
                var hook = new AdmissionHookMemoryBudget(owner);
                var (function, context, code) = Function(
                    "def f(values):\\n    total=0\\n    for value in values:\\n        total+=value\\n        if value==2: touch(value)\\n    return total\\n",
                    new() { MemoryBudget = hook, CancellationToken = cancellation.Token });
                Assert.True(code.CanRunNativeInstructions);
                var callback = new ForPromotionCallback();
                function.DefinitionContext.Variables["touch"] = callback;
                var values = new PyTuple([BigInteger.One, new BigInteger(2), new BigInteger(3)], context.MemoryGovernor, CallSpan, context);
                Assert.Equal(BigInteger.Zero, Invoke(function, [CallArgumentValue.Positional(PyTuple.Empty)], context, driver));
                var committed = context.MemoryGovernor.CurrentCommittedBytes;
                hook.RefuseGrowth = _ => !cancel;
                hook.AfterGrowth = _ => { if (cancel) cancellation.Cancel(); };
                try
                {
                    var failure = Assert.Throws<LythonRuntimeException>(() => Invoke(function, [CallArgumentValue.Positional(values)], context, driver));
                    Assert.Equal(cancel ? LythonFailureReason.Cancelled : LythonFailureReason.SharedMemoryAllowance, failure.Attribution?.Reason);
                    if (!cancel) Assert.Same(context.MemoryGovernor.AdmissionFailure, failure);
                    Assert.Equal(0, callback.Calls);
                    Assert.Equal(committed, context.MemoryGovernor.CurrentCommittedBytes);
                    Assert.Equal(0, context.MemoryGovernor.CurrentReservedBytes);
                    Assert.Equal(0, context.State.CurrentInterpreterDepth);
                    Assert.Equal(0, context.State.CurrentRecursionDepth);
                    Assert.Equal(3, values.Count);
                    Assert.Equal(BigInteger.One, values[0]);
                }
                finally
                {
                    hook.RefuseGrowth = null;
                    hook.AfterGrowth = null;
                    context.State.CloseResources();
                }
            }
            Assert.Equal(0, budget.ReservedBytes);
        }
    }

    private sealed class ForPromotionCallback : LythonRuntime.ICallable
    {
        private static readonly string Payload = new('z', 4096);
        internal int Calls;
        public object Invoke(CallArgumentValue[] arguments, LythonSourceSpan span, LythonRuntime.ExecutionContext context)
        {
            var result = PyString.FromString(Payload, context.MemoryGovernor, span);
            Calls++;
            return result;
        }
    }

'''
text=text[:start]+replacement+text[end:];p.write_text(text,encoding='utf-8',newline='\n')
script=r/'check-promotion.py';text=script.read_text(encoding='utf-8').replace('FullyQualifiedName~RefusedOrCancelledForPromotion','FullyQualifiedName~RefusedOrCancelledOutputAfterForPromotion');script.write_text(text,encoding='utf-8',newline='\n')
(out/'assessment.json').write_text(json.dumps(dict(initialCallbackScopeCorrected=True,secondFailure='No admission occurs during frame promotion when bound capacity is already funded. The test stopped at its prepared frame before invoking a callback.',correction='Exercise real admitted output construction after promotion through all four existing call drivers. Warm existing workspace first, preserve first refusal, cancellation, no callback publication, balances and input assertions.',productionUnchanged=True,noTestOnlyCheckpointOrArtificialAdmission=True),indent=2)+'\n',encoding='utf-8',newline='\n')
print('Corrected test premise: already-funded promotion itself has no admission. Test real output after promotion.',flush=True)
