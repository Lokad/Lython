from pathlib import Path
import ast,hashlib,json,tarfile
r=Path(__file__).parent;prior=r.parent/'bulk-cased-buffer-r343';source=json.loads((r/'candidate-identity.json').read_text(encoding='utf-8'));out=r/'b714';out.mkdir(exist_ok=True)
assert not(out/'launch.log').exists()
aux=json.loads((prior/'b713/identity.json').read_text(encoding='utf-8'))['candidateAuxiliaryFiles'];assert all(source['auxiliaryFiles'][role][name]==sha for role in ['reference','candidate']for name,sha in aux.items())
identity=dict(sourceRevision='R345frozen'+source['coreSHA256']['candidate'][:8]+' vs fully qualified2f606519/frozen53becdb6',purpose='Same-source complete for-text CSV digit validation/report warm and compile-to-result; unchanged captured text and fulfillment controls. Native iteration eligibility only; no external timing.',coreSHA256={label:source['coreSHA256']['candidate'if label.startswith('candidate')else'reference']for label in ['reference','candidate','reference-control','candidate-control']},candidateAuxiliaryFiles=aux,referenceAuxiliaryFiles=aux,catalogSHA256=hashlib.sha256((r/'catalog.json').read_bytes()).hexdigest(),referenceCase='scripts.csv-check-digits.for-text.large',variantCase='scripts.csv-check-digits.for-text.large',controlCases=['scripts.text-summary-helpers.nonlocal-counter.large','scripts.csv-fulfillment.large'],sourceAndScriptDifferIntentionally=False)
(out/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8',newline='\n')
jobs=[['scripts.csv-check-digits.for-text.large','warm'],['scripts.csv-check-digits.for-text.large','compile-run'],['scripts.csv-check-digits.for-list.large','warm'],['scripts.text-summary-helpers.nonlocal-counter.large','warm'],['scripts.csv-fulfillment.large','warm']]
for name in ['collect.py','archive-owned.py','run.sh','retrieve.py','summarize.py','launch.py']:
 s=(prior/'b713'/name).read_text(encoding='utf-8').replace('/home/lokad/lython-bench-checks/bulk-cased-buffer-b713-20261114','/home/lokad/lython-bench-checks/native-for-b714-20261114').replace('lython-b713-bulk-cased-buffer-20261114','lython-b714-native-for-20261114').replace('B713','B714')
 if name=='collect.py':
  a=s.index('jobs=');b=s.index('\nenv =',a);s=s[:a]+'jobs='+repr(jobs)+'\nassert len(jobs)==5 and all(case in cases for case,lane in jobs)\n'+s[b:]
  s=s.replace('< 300, \'Reserve60seconds','< 360, \'Reserve60seconds').replace('Representative CPython delivery checkpoint','Native for-prefix source comparison')
 if name=='launch.py':
  s=s.replace("'candidate-core.dll','reference-core.dll','source-identity.json'", "'candidate-core.dll','source-identity.json'")
  s=s.replace("  os.link(source/'cpython-worker.py',root/'cpython-worker.py')", "  os.link(source/'candidate/Lokad.Lython.dll',root/'reference-core.dll')\n  assert digest(root/'reference-core.dll')==config['identity']['coreSHA256']['reference']\n  os.link(source/'cpython-worker.py',root/'cpython-worker.py')")
  s=s.replace('RuntimeMaxSec=360','RuntimeMaxSec=420').replace('seconds=300','seconds=360').replace('ownerSeconds=360','ownerSeconds=420')
 if name in ['archive-owned.py','summarize.py']:s=s.replace("len(raw['jobs'])==4","len(raw['jobs'])==5").replace('jobs=4','jobs=5')
 if name=='retrieve.py':s=s.replace("['jobs']==4","['jobs']==5").replace("['elapsedSeconds']<360","['elapsedSeconds']<420").replace('two-job raw','five-job raw')
 if name.endswith('.py'):ast.parse(s)
 (out/name).write_text(s,encoding='utf-8',newline='\n')
with tarfile.open(out/'payload.tgz','w:gz')as t:
 for name in ['identity.json','collect.py','archive-owned.py','run.sh']:t.add(out/name,arcname=name)
 for name,arc in [('catalog.json','representative.json'),('candidate-core.dll','candidate-core.dll'),('candidate-identity.json','source-identity.json'),('reference-identity.json','reference-source-identity.json')]:t.add(r/name,arcname=arc)
with tarfile.open(out/'payload.tgz')as t:unpacked=sum(m.size for m in t.getmembers())
config=dict(root='/home/lokad/lython-bench-checks/native-for-b714-20261114',sourceRoot='/home/lokad/lython-bench-checks/shared-arithmetic-b711-20261114',unit='lython-b714-native-for-20261114',identity=identity,payloadBytes=(out/'payload.tgz').stat().st_size,payloadSHA256=hashlib.sha256((out/'payload.tgz').read_bytes()).hexdigest(),unpackedBytes=unpacked)
(out/'config.json').write_text(json.dumps(config,indent=2)+'\n',encoding='utf-8',newline='\n')
for name in ['verify-worker.py','measure-allocation.py']:
 if not(r/name).exists():(r/name).write_bytes((prior/name).read_bytes())
for role in ['reference','candidate']:
 if not(r/('allocation-'+role+'-catalog.json')).exists():(r/('allocation-'+role+'-catalog.json')).write_bytes((r/'catalog.json').read_bytes())
print('Prepared five-job420s comparison, including known list-position tradeoff; ordinary tiering/GC,12s warmups/five1s batches.',flush=True)
