from pathlib import Path
import ast,hashlib,json,tarfile
r=Path(__file__).parent;prior=r/'b714';out=r/'b715';out.mkdir(exist_ok=True)
assert not(out/'launch.log').exists()
assert json.loads((prior/'terminal-status.json').read_text(encoding='utf-8'))['exitCode']=='0'
source=json.loads((r/'candidate-identity.json').read_text(encoding='utf-8'))
assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==sha for p,sha in source['sources'].items())
identity=json.loads((prior/'identity.json').read_text(encoding='utf-8'))
identity['purpose']='Same-binary reversed-process-order confirmation of adverse controls and unstable compile-to-result; no runtime changes, no new external baseline.'
(out/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8',newline='\n')
jobs=[['scripts.text-summary-helpers.nonlocal-counter.large','warm'],['scripts.csv-check-digits.for-text.large','compile-run'],['scripts.csv-fulfillment.large','warm']]
for name in ['collect.py','archive-owned.py','run.sh','retrieve.py','summarize.py']:
 s=(prior/name).read_text(encoding='utf-8').replace('native-for-b714-20261114','native-for-b715-20261114').replace('lython-b714-native-for-20261114','lython-b715-native-for-20261114').replace('B714','B715')
 if name=='collect.py':
  a=s.index('jobs=');b=s.index('\nenv =',a);s=s[:a]+'jobs='+repr(jobs)+'\nassert len(jobs)==3 and all(case in cases for case,lane in jobs)\n'+s[b:]
  s=s.replace("< 360, 'Reserve60seconds","< 240, 'Reserve60seconds").replace('if job_index >= 2: labels.reverse()','if job_index < 2: labels.reverse()')
 if name in ['archive-owned.py','summarize.py']:s=s.replace("len(raw['jobs'])==5","len(raw['jobs'])==3").replace('jobs=5','jobs=3')
 if name=='retrieve.py':s=s.replace("['jobs']==5","['jobs']==3").replace("['elapsedSeconds']<420","['elapsedSeconds']<300").replace('five-job raw','three-job raw')
 if name.endswith('.py'):ast.parse(s)
 (out/name).write_text(s,encoding='utf-8',newline='\n')
with tarfile.open(out/'payload.tgz','w:gz')as t:
 for name in ['identity.json','collect.py','archive-owned.py','run.sh']:t.add(out/name,arcname=name)
 for path,arc in [(r/'catalog.json','representative.json'),(r/'candidate-identity.json','source-identity.json'),(r/'reference-identity.json','reference-source-identity.json'),(prior/'retrieved/cpython-worker.py','cpython-worker.py')]:t.add(path,arcname=arc)
with tarfile.open(out/'payload.tgz')as t:unpacked=sum(m.size for m in t.getmembers())
config=dict(root='/home/lokad/lython-bench-checks/native-for-b715-20261114',sourceRoot='/home/lokad/lython-bench-checks/native-for-b714-20261114',unit='lython-b715-native-for-20261114',identity=identity,payloadBytes=(out/'payload.tgz').stat().st_size,payloadSHA256=hashlib.sha256((out/'payload.tgz').read_bytes()).hexdigest(),unpackedBytes=unpacked)
(out/'config.json').write_text(json.dumps(config,indent=2)+'\n',encoding='utf-8',newline='\n')
(out/'prospective.json').write_text(json.dumps(dict(reason='B714 candidate compile-run spread20.48%; text control+1.83..4.79%elapsed with CPU adversity, fulfillment+0.34..2.92%. Confirm these unchanged sources before retention, not a rejection based on uncertainty.',sourcesAndAllImagesUnchanged=True,order='Reverse fresh process/source construction relative to each matching B714 job; preserve12s full-request warmups and five1s batches.',jobs=jobs,ownerSeconds=300,workPhaseSeconds=240,originalAllAdversePointsRetained=True,noRecompileOrPinChange=True,noFurtherUnchangedRetimeSelected=True),indent=2)+'\n',encoding='utf-8',newline='\n')
print('Prepared same-bit three-job300s confirmation; reuse both immutable complete images, no producer/build changes.',flush=True)
