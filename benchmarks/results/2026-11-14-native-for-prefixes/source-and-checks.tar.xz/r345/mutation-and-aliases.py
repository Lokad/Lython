def take(values):
    total=0
    for item in values:
        if item==1: values.append(4)
        total+=item
    return item,total
values=[1,2,3]
print(take(values),values)
def change(values):
    for item in values:
        values['new']=9
    return item
try: change({'a':1,'b':2})
except RuntimeError: print('changed')
def keep(values):
    first=None
    for item in values:
        if first is None: first=item
    return first,item
values=[[1],[2]]
first,last=keep(values)
first.append(9)
print(first,last,first is values[0],last is values[1])
