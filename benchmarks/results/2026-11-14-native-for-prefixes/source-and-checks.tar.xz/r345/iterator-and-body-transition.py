events=[]
class Values:
    def __iter__(self):
        events.append('iter')
        return iter((1,2,3))
def total(values):
    result=0
    for item in values: result+=item
    return result
print(total(Values()),events)
class Number:
    def __radd__(self,other):
        events.append(other)
        return other+7
print(total([1,2,Number(),4]),events)
