from pathlib import Path
import base64,copy,hashlib,json,subprocess,tempfile
r=Path(__file__).parent;out=r/'b714'
assert not(out/'launch.log').exists()
assert json.loads((r/'allocation-summary.json').read_text(encoding='utf-8'))['complete']
catalog=json.loads((r/'catalog.json').read_text(encoding='utf-8'));assert len(catalog['cases'])==3
case=copy.deepcopy(catalog['cases'][0]);old="digit_sum(row['code'])";assert old in case['source']
case['source']=case['source'].replace(old,"digit_sum(list(row['code']))")
case.update(id='scripts.csv-check-digits.for-list.large',sourceUtf8Bytes=len(case['source'].encode()),sourceSha256=hashlib.sha256(case['source'].encode()).hexdigest())
fixture=json.loads(case['fixtureJson'])
with tempfile.TemporaryDirectory(prefix='for-list-python-',dir=r.resolve())as name:
 folder=Path(name)
 for path,payload in fixture['inputFiles'].items():(folder/path).write_bytes(base64.b64decode(payload))
 done=subprocess.run(['C:/Python313/python.exe','-I','-S','-X','utf8','-c',case['source']],cwd=folder,capture_output=True,text=True,encoding='utf-8',timeout=15)
 assert done.returncode==0 and not done.stderr and done.stdout==case['expectedOutput'],done
 for path,payload in fixture['outputFiles'].items():assert(folder/path).read_bytes()==base64.b64decode(payload)
 for path,payload in fixture['inputFiles'].items():assert(folder/path).read_bytes()==base64.b64decode(payload)
catalog['cases'].append(case)
(r/'catalog-before-list.json').write_bytes((r/'catalog.json').read_bytes())
(r/'catalog.json').write_text(json.dumps(catalog,separators=(',',':'),ensure_ascii=False)+'\n',encoding='utf-8',newline='\n')
catalog['cases']=[case]
for role in ['reference','candidate']:(r/('allocation-list-'+role+'-catalog.json')).write_text(json.dumps(catalog,separators=(',',':'),ensure_ascii=False)+'\n',encoding='utf-8',newline='\n')
(r/'list-workload-control.json').write_text(json.dumps(dict(case=case['id'],sameRuntimeSourcesAndGoldens=True,constructorIncludedInCompleteScript=True,sourceSha256=case['sourceSha256'],reference='CPython3.13.2 isolated',reason='Native generic list cursor replaces the ordinary direct-position iteration; explicitly check this likely tradeoff before promotion.',priorThreeCaseAllocationRetainedWithoutReplay=True,vmJobsBeforeLaunch=5,vmOwnerSeconds=420,measurementPhaseSeconds=360,unchangedWarmupAndBatchSizing=True),indent=2)+'\n',encoding='utf-8',newline='\n')
source=(r/'measure-allocation.py').read_text(encoding='utf-8')
source=source.replace("'allocation-fixtures'","'allocation-list-fixtures'").replace("role+'-allocation-'","role+'-list-allocation-'").replace("'allocation-'+role+'-catalog.json'","'allocation-list-'+role+'-catalog.json'").replace("'allocation-summary.json'","'allocation-list-summary.json'")
(r/'measure-list-allocation.py').write_text(source,encoding='utf-8',newline='\n')
# The accidental local invocation of the Linux-only collector stopped at import,
# before any paths, users, files or VM operations were reached.
(r/'local-collector-invocation.json').write_text(json.dumps(dict(command='python -X utf8 b714/collect.py on Windows',exitCode=1,error="ModuleNotFoundError: No module named 'fcntl'",stoppedAtLine=2,noGuestOrVMWorkStarted=True,noMeasurementClaim=True),indent=2)+'\n',encoding='utf-8',newline='\n')
p=Path('PLAN.md');text=p.read_text(encoding='utf-8');text=text.replace('   and compile-to-result, captured-text and fulfillment controls against frozen53.','   and compile-to-result, plus list-input CSV and captured-text/fulfillment controls\n   against frozen53. The list variant explicitly checks the cursor-vs-position tradeoff.');text=text.replace('   These are correctness gates; whole-script allocation/elapsed remain unmeasured.','   Separate four-process text-input CSV allocation is−25.31%; both unchanged controls\n   are flat. Elapsed remains unmeasured. Add the list variant without replaying those\n   allocation points. Five VM jobs retain12s warmups/five1s batches under420s ownership\n   (360s work/60s cleanup); no10min lane or full benchmark campaign.')
p.write_text(text,encoding='utf-8',newline='\n')
print('Added the known list-position tradeoff before any VM launch; original allocation observations retained.',flush=True)
