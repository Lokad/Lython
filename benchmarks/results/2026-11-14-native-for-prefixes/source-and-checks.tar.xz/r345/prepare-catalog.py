from pathlib import Path
import base64,copy,hashlib,json,subprocess,tempfile
r=Path(__file__).parent
old=json.loads((r.parent/'native-backedges-r338/catalog.json').read_text(encoding='utf-8'))
case=copy.deepcopy(next(c for c in old['cases']if c['id']=='scripts.csv-check-digits.large'))
source=case['source']
original='''def digit_sum(value):
    total=0
    while value>0:
        total+=value%10
        value//=10
    return total'''
replacement='''def digit_sum(value):
    total=0
    for character in value:
        total+=int(character)
    return total'''
assert original in source
source=source.replace(original,replacement).replace("digit_sum(int(row['code']))","digit_sum(row['code'])")
fixture=json.loads(case['fixtureJson'])
with tempfile.TemporaryDirectory(prefix='for-csv-python-',dir=r.resolve())as name:
 folder=Path(name)
 for path,payload in fixture['inputFiles'].items():(folder/path).write_bytes(base64.b64decode(payload))
 done=subprocess.run(['C:/Python313/python.exe','-I','-S','-X','utf8','-c',source],cwd=folder,capture_output=True,text=True,encoding='utf-8',timeout=15)
 assert done.returncode==0 and not done.stderr and done.stdout==case['expectedOutput'],done
 for path,payload in fixture['outputFiles'].items():assert(folder/path).read_bytes()==base64.b64decode(payload)
 for path,payload in fixture['inputFiles'].items():assert(folder/path).read_bytes()==base64.b64decode(payload)
case.update(id='scripts.csv-check-digits.for-text.large',source=source,sourceUtf8Bytes=len(source.encode()),sourceSha256=hashlib.sha256(source.encode()).hexdigest())
controls=json.loads((r.parent/'bulk-cased-buffer-r343/catalog.json').read_text(encoding='utf-8'))
old['cases']=[case]+[next(c for c in controls['cases']if c['id']==id)for id in ['scripts.text-summary-helpers.nonlocal-counter.large','scripts.csv-fulfillment.large']]
(r/'catalog.json').write_text(json.dumps(old,separators=(',',':'),ensure_ascii=False)+'\n',encoding='utf-8',newline='\n')
(r/'for-csv.py').write_text(source,encoding='utf-8',newline='\n')
(r/'workload-python-controls.json').write_text(json.dumps(dict(reference='CPython3.13.2 isolated',id=case['id'],sourceSha256=case['sourceSha256'],fixtureSha256=case['fixtureSha256'],inputBytes=sum(len(base64.b64decode(v))for v in fixture['inputFiles'].values()),rows=4096,sameStdoutAndFilesAsHistoricalDigitSum=True,sourcesIdenticalAcrossRuntimeRevisions=True,differentPythonAlgorithmThanHistoricalWhileCase=True,noTimingComparisonAgainstHistoricalScript=True,controls=[c['id']for c in old['cases'][1:]]),indent=2)+'\n',encoding='utf-8',newline='\n')
print('Complete for-text CSV/report case and two unchanged controls prepared; independent Python goldens match.',flush=True)
