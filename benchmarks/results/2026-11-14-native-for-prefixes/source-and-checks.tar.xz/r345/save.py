from pathlib import Path
import hashlib,json,shutil,tarfile,xml.etree.ElementTree as ET
r=Path(__file__).parent;out=Path('benchmarks/results/2026-11-14-native-for-prefixes');out.mkdir(exist_ok=True)
identity=json.loads((r/'candidate-identity.json').read_text(encoding='utf-8'))
assert len(identity['sources'])==581 and all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==sha for p,sha in identity['sources'].items())
focused=json.loads((r/'focused-checks.json').read_text(encoding='utf-8'));promotion=json.loads((r/'promotion-checks.json').read_text(encoding='utf-8'))
assert len(focused)==4 and len(promotion)==2 and all(v['returncode']==0 for v in focused+promotion)
for name in ['b714','b715']:
 status=json.loads((r/name/'terminal-status.json').read_text(encoding='utf-8'))
 assert status['exitCode']=='0'and status['receipt']['allWorkersJoined']and status['receipt']['archivedAndVerifiedUnderLease']
 assert hashlib.sha256((r/name/'observations.tgz').read_bytes()).hexdigest()==status['receipt']['archiveSHA256']
files=['prospective.json','candidate-identity.json','reference-identity.json','focused-checks.json','promotion-checks.json','allocation-summary.json','allocation-list-summary.json','workload-python-controls.json','list-workload-control.json','python-controls.json','worker-verification.json','worker-list-verification.json','measurement-state.json']
for name in files:shutil.copyfile(r/name,out/name)
for phase in ['b714','b715']:
 folder=out/phase;folder.mkdir(exist_ok=True)
 for name in ['summary.json','terminal-status.json','archive-receipt.json','observations.tgz','observe-not-before.json']:
  shutil.copyfile(r/phase/name,folder/name)
decision=dict(date='2026-11-14',state='retain implementation; full platform/stress/installed qualification pending',reference='2f606519/frozen53becdb6',candidateCore=identity['coreSHA256']['candidate'],removed='Whole-function exclusion and forced ordinary routing for GetIter/ForNext/unprotected loop exits. Reuse existing native storage, builtin cursors, shared operators and exact-PC ordinary continuation; no new engine, pool, policy or public API.',sourceFacts='Ordinary list/tuple helpers already defer context and use direct positions. Text-input helpers previously promote at generic GetIter. Do not claim that every former for helper built a frame.',allocation={'textInputCsvPercent':-25.312252049162076,'listInputCsvPercent':4.240555077314734,'unchangedTextAndFulfillmentControlsPercent':0},timing={'B714':json.loads((r/'b714/summary.json').read_text(encoding='utf-8'))['timing'],'B715':json.loads((r/'b715/summary.json').read_text(encoding='utf-8'))['timing']},retention='Text-input CSV warm is14.71..20.25%faster with CPU support. Same-binary reversed-order confirmation supports17.84..19.94%compile-to-result improvement. List-input CSV is7.55..11.01%faster with CPU support despite4.24%more allocation. The syntax-wide stage removal and complete-script benefits justify retention.',debt='Text control remains modestly adverse: B714+1.83..4.79%, confirmation+0.49..2.59%elapsed with CPU adversity. Accept explicit small debt at this milestone; do not claim release-wide neutrality. Fulfillment confirmation spans-3.31..+4.31%with moving processes and remains uncertain. Original compile-run candidate spread20.48%is preserved; confirmation2.38%. No unchanged further retiming selected.',next='Qualify retained iteration milestone, then assess the list cursor/enumerator representation as a coherent follow-up before choosing another design. Do not automatically create a new position pool, calling convention, engine or universal tagged values.',validation='123 internal/252 public per actual11/10 plus two post-promotion output cases per target, all passing. The latter each cover four call drivers. Active cursor/child I/O, cancellation, refusal, retained results, wide owned calls and allowance reuse included. Source-only eligibility tests establish the native path independently of semantics.',fixtureHistory='Promotion fixture initially installed the callback in caller scope, then assumed already-funded promotion must reserve, then used an atomic conversion without in-operation cancellation. All failed sources/logs/TRX retained. Correct test uses real cancellable bulk casing after promotion; no assertions/timeouts weakened, no production bug claim.',environment='First B714 staging failed on a missing immutable reference link before service/guest work. Same hash-verified partial root completed under a fresh idle lease. B714373.44s/420sowner; B715226.09s/300sowner. All users joined/RAMfixtures removed/archives verified, unchanged254/252MiBfloors and no VM retirement.',compatibility='No new public APIs or Python behavior. Native execution still promotes before user iteration/protocols or actual suspension, with active cursor state and owned inputs preserved. Minor storage/retention may differ; identical tiny-budget thresholds are not promised.',publication='held; no package pin change')
(out/'decision.json').write_text(json.dumps(decision,indent=2)+'\n',encoding='utf-8',newline='\n')
with tarfile.open(out/'source-and-checks.tar.xz','w:xz',preset=6)as tar:
 for p in sorted(r.rglob('*')):
  rel=p.relative_to(r)
  if not p.is_file()or rel.parts[0]in {'reference','candidate','delivery'}or p.name=='payload.tgz':continue
  tar.add(p,arcname='r345/'+rel.as_posix(),recursive=False)
 for name in ['tests/Lokad.Lython.Tests/SimpleFunctionExecutionBoundaryTests.cs','tests/Lokad.Lython.PublicApi.Tests/ForHelperExecutionTests.cs']:tar.add(name,arcname='retained/'+name)
(out/'README.md').write_text('''# Native builtin for-loop prefixes

2026-11-14, R345, qualified `2f606519`/frozen `53becdb6` versus prototype
`8306699f`. Two production files remove whole-function exclusion for GetIter,
ForNext and unprotected loop exits. Existing builtin cursors and final native
slots replace forced ordinary routing; custom iteration promotes before acquisition,
and active cursors/children transfer at the exact instruction without replay.
No new engine, pool, policy, public option or dependency is introduced.

| Complete workload | Allocation change | Elapsed change | Wider CPU change |
| --- | --- | --- | --- |
| CSV digit validation/report, text input, warm | −25.31% | −20.25..−14.71% | −20.90..−14.94% |
| Same script, compile-to-result confirmation | Not measured in this boundary | −19.94..−17.84% | −19.43..−17.40% |
| CSV digit validation/report, list input, warm | +4.24% | −11.01..−7.55% | −10.37..−7.48% |
| Captured text control, warm confirmation | Flat | +0.49..+2.59% | +0.61..+3.99% |
| Fulfillment control, warm confirmation | Flat | −3.31..+4.31% | −2.84..+4.74% |

Changes compare all fresh-process source pairings; positive means more/slower.
The complete4096-row CSV task reads codes, sums their digits with an ordinary
for helper, aggregates groups and writes/verifies a report. List input includes
constructing the list before the same helper call. Both revisions use identical
script/input/output bytes; isolated CPython3.13.2 validates stdout/files. This is
not a CPython timing comparison and not a timing comparison against the historical
while-based digit algorithm. Text-input allocation falls6,343,874→4,738,096B/job;
list-input rises6,180,202→6,442,277B/job. Allocation is a separate four-process
desktop diagnostic, with no elapsed claim.

B714 uses quiet Azure F4as_v7/Ubuntu24.04.4/.NET11, unchanged B685 worker/optional0.4
adapter, ordinary GC/tiering,12s full-request warmups and five rotating1s batches.
Warm includes mediated RAM-fixture I/O, output/file checks and prior-result cleanup.
Compile-to-result adds compilation/script disposal; startup, protocol/reset and final
cache shutdown are excluded. Wider CPU includes protocol/reset. No physical-heap,
tail-latency, universal speedup or release-wide neutrality is established.

Original compile-to-result candidate processes differ20.48%; retain that uncertainty
and every raw point. Same-binary B715 reverses process/source construction order and
confirms the affected fresh direction with2.38%candidate spread. Text control stays
modestly adverse (initial+1.83..4.79%, confirmation+0.49..2.59%elapsed with CPU support).
Fulfillment's confirmation has4.41%candidate/3.22%reference spread and remains
inconclusive. **Retain with explicit small text debt and list allocation tradeoff.**
No unchanged further retiming is selected. A bounded cursor/enumerator follow-up may
address actual extra representation; no new indexing pool or call framework is selected.

The baseline already defers contexts and uses direct positions for list/tuple loops;
do not generalize the text-input allocation gain or attribute it to every former for
helper. Source eligibility tests establish both small and owned-wide native loops.
123internal/252public focused cases per actual11/10 pass, plus two post-promotion
output cases per target through four existing call drivers. Python controls cover
loop exits/else, nested loops, mutation, Unicode, exact integers and aliases. Real
I/O/native-child transfer, cancellation, terminal refusal, retained results and budget
reuse preserve ownership. Early promotion-fixture failures and corrections survive;
they establish mistaken fixture assumptions, not production defects. Assertions,
timeouts and stress scales are unchanged. Full delivery qualification is pending.

First B714 staging failed before a service/guest started because the immutable
reference link was missing. Complete the same verified partial root under a fresh
idle lease; no image/evidence retirement or VM-floor relaxation. B714 completes in
373.44s under420s ownership; B715 in226.09s under300s. All workers join, RAM fixtures
are removed and archives are independently verified under ownership. Terminal
states are cached. Publication and adapter promotion remain held.

[B714 timings](b714/summary.json), [same-bit confirmation](b715/summary.json),
[allocation](allocation-summary.json), [list allocation](allocation-list-summary.json),
[decision](decision.json), [raw B714](b714/observations.tgz),
[raw B715](b715/observations.tgz), [sources, binaries, failures and tools](source-and-checks.tar.xz).
''',encoding='utf-8',newline='\n')
print('Saved retained native-for milestone and all adverse/source/fixture evidence; full delivery remains pending.',flush=True)
