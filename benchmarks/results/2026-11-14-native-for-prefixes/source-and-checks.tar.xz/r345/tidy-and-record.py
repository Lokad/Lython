from pathlib import Path
import json,re
p=Path('tests/Lokad.Lython.Tests/SimpleFunctionExecutionBoundaryTests.cs');text=p.read_text(encoding='utf-8')
start=text.index('        var budget =',text.index('public void BuiltinForLoopsFinishWithoutMaterializingAnInvocation'))
end=text.index('\n        }\n    }',start)
text=text[:start]+''.join('    '+line+'\n'for line in text[start:end].splitlines()).removesuffix('\n')+text[end:]
p.write_text(text,encoding='utf-8',newline='\n')
p=Path('PLAN.md');text=p.read_text(encoding='utf-8')
text,n=re.subn(r'Read-only dev84worktreeae463cb4 and immutable package834162df are distinct source\n\s+identities\.', 'Read-only producerbad2a143 leaves all three public integration files byte-identical\n   toae463cb4; immutable dev84 package834162df remains a separate identity.',text,count=1);assert n==1
text=text.replace('   exact baseline restoration passes103internal/484public plus3original64MiB rollback','   exact baseline restoration passes103internal/484public plus3original64MiB rollback')
needle='   Remove the prototype if cursor work outweighs the saved execution stage; do not\n   automatically add indexing tiers. Batch full qualification at retained delivery.'
assert needle in text
text=text.replace(needle,needle+'\n   Current candidate passes123internal/252public focused cases per actual11/10,\n   including refusal/cancellation, owned wide calls and nested native child transfer.\n   These are correctness gates; whole-script allocation/elapsed remain unmeasured.')
p.write_text(text,encoding='utf-8',newline='\n')
print('Documented native for lifetime behavior and current focused checks; no timing claim.',flush=True)
