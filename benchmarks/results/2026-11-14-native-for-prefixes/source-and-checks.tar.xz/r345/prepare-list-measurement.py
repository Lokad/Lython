from pathlib import Path
import json
r=Path(__file__).parent
assert len(json.loads((r/'worker-verification.json').read_text(encoding='utf-8')))==6
source=(r/'verify-worker.py').read_text(encoding='utf-8')
old="for role,index in [(role,index)for index in range(3)for role in ['reference','candidate']]:";assert old in source
source=source.replace(old,"for role,index in [(role,3)for role in ['reference','candidate']]:").replace('worker-verification.json','worker-list-verification.json').replace('verify-startup-','verify-list-startup-').replace('verify-request-','verify-list-request-')
(r/'verify-list-worker.py').write_text(source,encoding='utf-8',newline='\n')
print('List-only verification reuses frozen images; original six observations and allocation catalogs preserved.',flush=True)
