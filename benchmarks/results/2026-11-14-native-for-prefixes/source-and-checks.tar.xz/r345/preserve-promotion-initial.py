from pathlib import Path
import json,shutil
r=Path(__file__).parent;out=r/'promotion-initial';out.mkdir()
for name in ['promotion-net11.0','promotion-net11.0.log','promotion-checks.json']:
 p=r/name
 if p.is_dir():shutil.copytree(p,out/name)
 else:shutil.copyfile(p,out/name)
shutil.copyfile('tests/Lokad.Lython.Tests/SimpleFunctionExecutionBoundaryTests.cs',out/'SimpleFunctionExecutionBoundaryTests.cs')
(out/'assessment.json').write_text(json.dumps(dict(failedCases=2,actualAttribution=None,expected=['SharedMemoryAllowance','Cancelled'],fixtureIssue='The Function factory returns a separate caller context and function definition closure. The callback was incorrectly installed in caller variables, so native global lookup raised NameError before reaching promotion.',correction='Install the callback in function.DefinitionContext.Variables, matching existing fixtures. Preserve all original failure data and admission/cleanup assertions.',productionUnchanged=True),indent=2)+'\n',encoding='utf-8',newline='\n')
