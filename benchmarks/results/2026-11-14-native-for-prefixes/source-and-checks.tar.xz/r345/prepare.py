from pathlib import Path
import hashlib,json,shutil,tarfile,subprocess
r=Path(__file__).parent
previous=r.parent/'bulk-cased-buffer-r343'
identity=json.loads((previous/'reference-identity.json').read_text(encoding='utf-8'))
assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==sha for p,sha in identity['sources'].items())
assert subprocess.run(['git','diff','--quiet','HEAD','--','src/Lokad.Lython']).returncode==0
for name in ['reference-identity.json','reference-core.dll','reference-sources.tar.xz']:
 shutil.copyfile(previous/name,r/name)
shutil.copytree(previous/'reference',r/'reference')
record=dict(date='2026-11-14',headBeforeChanges=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),hypothesis='The opcode eligibility cliff moves ordinary for helpers to resumable execution. Exact builtin loops can remain in the existing native prefix, removing repeated ordinary routing and avoidable activation/storage without inventing a dispatcher or a value representation.',eliminated='Whole-function exclusion for GetIter/ForNext and unprotected break/continue. Existing shared operators, final slots, cursor and exact-PC continuation remain the implementation.',implementation='Add builtin-only GetIter/ForNext and unprotected AbruptJump to NativeExecution; reuse PyIteration.Cursor for exact builtin values and the existing cased-word cursor. Dynamic iterators promote before acquisition. Evaluate eligibility after final instruction preparation so dictionary accumulation retains its established route.',acceptance=['Python for/else, break/continue, nested loops, empty/unbound targets, mutation and retained aliases','Exact integers/Unicode and native/ordinary equivalence','Promotion during a body or later custom iterator without replay; real async protocol/I/O and joined cancellation','Native temporary cursor disposal at EOF, break, return, exception and transfer; first refusal remains terminal and funded retained results; shared allowance reuse','Managed stack/recursion safety and effective nonallocating-loop cancellation'],comparison='Complete CSV check-digit helper using ordinary for over its digit text, captured text control and unchanged fulfillment control. Same input/goldens on frozen qualified53 versus candidate. Warm and affected compile-to-result, separate short allocation diagnostics; one bounded quiet-VM comparison with justification for any confirmation.',tradeoffs='Existing generic cursor adds minor wrapper work for builtin values versus the ordinary list/tuple position optimization. Stop if the complete-workload cost outweighs removed routing; do not add a new position pool or a per-syntax backend.',completion='Retain only with semantic/ownership/cancellation acceptance and an explicit elapsed/allocation/debt decision, then batch original stress/platform/installed consumers. Preserve all adverse sources/results. No broad engine rewrite or arbitrary fixed percentage veto.')
(r/'prospective.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8',newline='\n')
p=Path('PLAN.md');text=p.read_text(encoding='utf-8');(r/'PLAN-before-r345.md').write_text(text,encoding='utf-8',newline='\n')
start=text.index('2. **Next substantial runtime milestone:')
end=text.index('   | Area |',start)
text=text[:start]+'''2. **R345 active: remove the ordinary-for helper eligibility cliff.** Source shows
   `while` branches are native but GetIter/ForNext and unprotected break/continue
   exclude the entire function. Reuse existing builtin cursors and native final
   storage; remove the forced ordinary routing/activation for closed for loops.
   No new dispatcher, position pool, owner or tagged representation. Custom iterators
   and actual suspension transfer to the existing ordinary frame at the exact PC.
   Determine eligibility after final dictionary-loop preparation, preserving that
   measured fast route. Exact builtin cursor wrappers may offset saved routing;
   this is a hypothesis, not a CPU/allocation claim.

   Acceptance: for/else, nested loops, break/continue/return, live list/dict mutation,
   Unicode, exact promotion, aliases, unbound/error order and both execution APIs.
   Dispose private cursors at EOF/abrupt exit/failure; transfer active ones once.
   Actual late I/O/custom-iterator suspension and cancellation join cleanup. Refused
   admission remains terminal with original origin and inputs/results funded.
   Preserve managed stack/recursion and nonallocating-loop cancellation.

   Compare complete CSV check-digit helper using for over its text, affected warm
   and compile-to-result, captured-text and fulfillment controls against frozen53.
   Keep allocation separate. One bounded quiet-VM source pair; allow evidence-led
   refinement, preserve adversity and decide regression debt before delivery.
   Remove the prototype if cursor work outweighs the saved execution stage; do not
   automatically add indexing tiers. Batch full qualification at retained delivery.
   R343 remains withdrawn; no unchanged full qualification or phase collection.

''' + text[end:]
text=text.replace('| Runtime prototypes | None retained.', '| Runtime prototypes | R345 native for-prefix work is active and unmeasured. R343 is not retained.')
text=text.replace('    Read-only dev84worktreeae463cb4 and immutable package834162df are distinct source\n    identities.','    Read-only producerbad2a143 leaves all three public integration files byte-identical\n    toae463cb4. Immutable dev84 package834162df remains a separate identity.')
p.write_text(text,encoding='utf-8',newline='\n')
print('Qualified reference copied and R345 hypothesis/acceptance recorded before implementation.',flush=True)
