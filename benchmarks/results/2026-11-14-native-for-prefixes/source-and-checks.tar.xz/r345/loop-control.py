def count(values):
    total=0
    item=None
    for item in values:
        if item==2: continue
        if item==5: break
        total+=item
    else: total+=100
    return item,total
print([count(values) for values in [[],[1],[1,2,3],[1,2,3,4,5,6],(1,2,3),range(3),b'123']])
def missing(values):
    for item in values: pass
    return item
try: missing([])
except UnboundLocalError: print('unbound')
