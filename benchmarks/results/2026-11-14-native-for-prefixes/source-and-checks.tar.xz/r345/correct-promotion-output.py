from pathlib import Path
import json,shutil
r=Path(__file__).parent;out=r/'promotion-atomic-conversion';out.mkdir()
for name in ['promotion-net11.0','promotion-net11.0.log','promotion-checks.json']:
 p=r/name
 if p.is_dir():shutil.copytree(p,out/name)
 else:shutil.copyfile(p,out/name)
p=Path('tests/Lokad.Lython.Tests/SimpleFunctionExecutionBoundaryTests.cs');shutil.copyfile(p,out/p.name)
text=p.read_text(encoding='utf-8')
text=text.replace('var callback = new ForPromotionCallback();',"var callback = new ForPromotionCallback(PyString.FromString(new string('A', 4096), context.MemoryGovernor, CallSpan));")
text=text.replace('private sealed class ForPromotionCallback : LythonRuntime.ICallable\n    {\n        private static readonly string Payload = new(\'z\', 4096);','private sealed class ForPromotionCallback(PyString payload) : LythonRuntime.ICallable\n    {')
text=text.replace('var result = PyString.FromString(Payload, context.MemoryGovernor, span);','var result = PyStringOps.Lower(payload, context, span);')
p.write_text(text,encoding='utf-8',newline='\n')
(out/'assessment.json').write_text(json.dumps(dict(refusalCasePassed=True,cancellationCaseFailed='The callback used atomic FromString conversion, then published its own counter before the caller observed cancellation. No cooperative check was promised inside that conversion.',correction='Use the real existing cancellable bulk lower operation over an independently funded retained input. Preserve every original refusal/cancellation, no-publication, balance and input assertion. No production change or test-only checkpoint introduced.'),indent=2)+'\n',encoding='utf-8',newline='\n')
