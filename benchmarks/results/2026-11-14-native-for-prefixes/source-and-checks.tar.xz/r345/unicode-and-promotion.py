def collect(text):
    total=0
    for character in text:
        total+=len(character)
    return character,total
print(collect('α😀é𐐨'))
def grow(values):
    total=9223372036854775807
    for value in values: total=total*3+value
    alias=total
    return total,alias is total
print(grow((1,2,3)))
def count(values):
    total=0
    for value in values: total+=1
    return total
print(count({'a':1,'b':2}),count({1,2,3}))
