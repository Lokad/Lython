using System.Numerics;
using Lokad.Lython.Runtime;
using Lokad.Lython.Runtime.Numbers;
using Lokad.Lython.Runtime.Text;

namespace Lokad.Lython.Frontend;

internal abstract record LoweredExpression
{
    /// <summary>Gets the source syntax represented by this lowered expression.</summary>
    public abstract ExpressionSyntax Syntax { get; }

    public LythonSourceSpan Span => Syntax.Span;
}

// Used only for already evaluated operands in a resumed executable operation.
internal sealed record LoweredCapturedExpression(ExpressionSyntax Original, object Value) : LoweredExpression
{
    public override ExpressionSyntax Syntax => Original;
}

internal sealed record LoweredUnpackedTypeExpression(UnpackedTypeExpressionSyntax Unpacked, LoweredExpression Value) : LoweredExpression
{
    public override ExpressionSyntax Syntax => Unpacked;
}

internal sealed record LoweredYieldExpression(YieldExpressionSyntax Yield, LoweredExpression? Value) : LoweredExpression
{
    public override ExpressionSyntax Syntax => Yield;
}

internal sealed record LoweredIdentifierExpression(
    IdentifierExpressionSyntax Identifier) : LoweredExpression
{
    public override ExpressionSyntax Syntax => Identifier;
}

internal sealed record LoweredStringLiteralExpression(
    StringLiteralExpressionSyntax Literal) : LoweredExpression
{
    public override ExpressionSyntax Syntax => Literal;
    public PyString Value { get; } = PyString.FromString(Literal.Value);
}

internal sealed record LoweredBytesLiteralExpression(
    BytesLiteralExpressionSyntax Literal) : LoweredExpression
{
    public override ExpressionSyntax Syntax => Literal;
    public PyBytes Value { get; } = new(Literal.Value.ToArray());
}

internal sealed record LoweredIntegerLiteralExpression(
    IntegerLiteralExpressionSyntax Literal) : LoweredExpression
{
    public override ExpressionSyntax Syntax => Literal;
    // The immutable magnitude belongs to the compiled program. Lowered consumers
    // still box the value independently when Python observes an integer object.
    public BigInteger Value { get; } = PyNumberOps.ParseInteger(Literal.ValueText);
}

internal sealed record LoweredImaginaryLiteralExpression(ImaginaryLiteralExpressionSyntax Literal) : LoweredExpression
{
    public override ExpressionSyntax Syntax => Literal;
}

internal sealed record LoweredFloatLiteralExpression(
    FloatLiteralExpressionSyntax Literal) : LoweredExpression
{
    public override ExpressionSyntax Syntax => Literal;
}

internal sealed record LoweredBooleanLiteralExpression(
    BooleanLiteralExpressionSyntax Literal) : LoweredExpression
{
    public override ExpressionSyntax Syntax => Literal;
}

internal sealed record LoweredNoneLiteralExpression(
    NoneLiteralExpressionSyntax Literal) : LoweredExpression
{
    public override ExpressionSyntax Syntax => Literal;
}

internal sealed record LoweredEllipsisLiteralExpression(
    EllipsisLiteralExpressionSyntax Literal) : LoweredExpression
{
    public override ExpressionSyntax Syntax => Literal;
}

internal abstract record LoweredFormattedStringPart;

internal sealed record LoweredFormattedStringTextPart(
    string Text) : LoweredFormattedStringPart;

internal sealed record LoweredFormattedStringExpressionPart(
    LoweredExpression Expression,
    char? Conversion,
    string? FormatSpecifier,
    IReadOnlyList<LoweredFormattedStringPart>? FormatSpecifierParts) : LoweredFormattedStringPart;

internal sealed record LoweredFormattedStringExpression(
    FormattedStringExpressionSyntax FormattedString,
    IReadOnlyList<LoweredFormattedStringPart> Parts) : LoweredExpression
{
    public override ExpressionSyntax Syntax => FormattedString;
}

internal sealed record LoweredParenthesizedExpression(
    ParenthesizedExpressionSyntax Parenthesized,
    LoweredExpression Inner) : LoweredExpression
{
    public override ExpressionSyntax Syntax => Parenthesized;
}

internal sealed record LoweredCollectionDisplayItem(
    CollectionDisplayItemSyntax Syntax,
    LoweredExpression Expression)
{
    public bool IsUnpacking => Syntax is CollectionUnpackingItemSyntax;

    public LythonSourceSpan Span => Syntax.Span;
}

internal sealed record LoweredListLiteralExpression(
    ListLiteralExpressionSyntax List,
    IReadOnlyList<LoweredCollectionDisplayItem> Items) : LoweredExpression
{
    public override ExpressionSyntax Syntax => List;
}

internal sealed record LoweredTupleLiteralExpression(
    TupleLiteralExpressionSyntax Tuple,
    IReadOnlyList<LoweredCollectionDisplayItem> Items) : LoweredExpression
{
    public override ExpressionSyntax Syntax => Tuple;
}

internal sealed record LoweredSetLiteralExpression(
    SetLiteralExpressionSyntax Set,
    IReadOnlyList<LoweredCollectionDisplayItem> Items) : LoweredExpression
{
    public override ExpressionSyntax Syntax => Set;
}

internal sealed record LoweredSetComprehensionExpression(
    SetComprehensionExpressionSyntax SetComprehension,
    LoweredExpression ItemExpression,
    IReadOnlyList<LoweredComprehensionClause> Clauses) : LoweredExpression
{
    public override ExpressionSyntax Syntax => SetComprehension;
    public ScopeDirectiveFacts ScopeFacts { get; } = ComprehensionSyntaxFacts.Bindings(Clauses.Select(clause => clause.Target));
}

internal sealed record LoweredComprehensionClause(
    LoopTargetSyntax Target,
    LoweredExpression Iterable,
    LoweredExpression? Condition,
    LythonSourceSpan Span);

internal sealed record LoweredListComprehensionExpression(
    ListComprehensionExpressionSyntax ListComprehension,
    LoweredExpression ItemExpression,
    IReadOnlyList<LoweredComprehensionClause> Clauses) : LoweredExpression
{
    public override ExpressionSyntax Syntax => ListComprehension;
    public ScopeDirectiveFacts ScopeFacts { get; } = ComprehensionSyntaxFacts.Bindings(Clauses.Select(clause => clause.Target));
}

internal sealed record LoweredGeneratorExpression(
    GeneratorExpressionSyntax Generator,
    LoweredExpression ItemExpression,
    IReadOnlyList<LoweredComprehensionClause> Clauses) : LoweredExpression
{
    public override ExpressionSyntax Syntax => Generator;
    public ScopeDirectiveFacts ScopeFacts { get; } = Generator.PreparedComprehensionScopeFacts ??
        ComprehensionSyntaxFacts.Bindings(Clauses.Select(clause => clause.Target), generator: true);
}

internal abstract record LoweredDictionaryDisplayItem(
    DictionaryDisplayItemSyntax Syntax,
    LoweredExpression Key,
    LoweredExpression Value,
    bool IsUnpacking);

internal sealed record LoweredDictionaryKeyValueItem(
    DictionaryKeyValueItemSyntax Item,
    LoweredExpression Key,
    LoweredExpression Value) : LoweredDictionaryDisplayItem(Item, Key, Value, false);

internal sealed record LoweredDictionaryUnpackingItem(
    DictionaryUnpackingItemSyntax Item,
    LoweredExpression Mapping) : LoweredDictionaryDisplayItem(Item, Mapping, Mapping, true);

internal sealed record LoweredDictLiteralExpression(
    DictLiteralExpressionSyntax Dict,
    IReadOnlyList<LoweredDictionaryDisplayItem> Items) : LoweredExpression
{
    public override ExpressionSyntax Syntax => Dict;
}

internal sealed record LoweredDictComprehensionExpression(
    DictComprehensionExpressionSyntax DictComprehension,
    LoweredExpression KeyExpression,
    LoweredExpression ValueExpression,
    IReadOnlyList<LoweredComprehensionClause> Clauses) : LoweredExpression
{
    public override ExpressionSyntax Syntax => DictComprehension;
    public ScopeDirectiveFacts ScopeFacts { get; } = ComprehensionSyntaxFacts.Bindings(Clauses.Select(clause => clause.Target));
}

internal sealed record LoweredMemberExpression(
    MemberExpressionSyntax Member,
    LoweredExpression Target) : LoweredExpression
{
    public override ExpressionSyntax Syntax => Member;
}

internal sealed record LoweredCallArgument(
    CallArgumentForm Form,
    LoweredExpression Expression)
{
    public CallArgumentKind Kind => Form.Kind;

    public string KeywordName => Form.KeywordName;
}

internal sealed record LoweredCallExpression(
    CallExpressionSyntax Call,
    LoweredExpression Target,
    IReadOnlyList<LoweredCallArgument> Arguments) : LoweredExpression
{
    public override ExpressionSyntax Syntax => Call;
}

internal sealed record LoweredSubscriptExpression(
    SubscriptExpressionSyntax Subscript,
    LoweredExpression Target,
    LoweredExpression Index) : LoweredExpression
{
    public override ExpressionSyntax Syntax => Subscript;
}

internal sealed record LoweredSliceExpression(
    SliceExpressionSyntax Slice,
    LoweredExpression Target,
    LoweredExpression? Start,
    LoweredExpression? End,
    LoweredExpression? Step) : LoweredExpression
{
    public override ExpressionSyntax Syntax => Slice;
}

internal sealed record LoweredSliceValueExpression(
    SliceValueExpressionSyntax Slice,
    LoweredExpression? Start,
    LoweredExpression? End,
    LoweredExpression? Step) : LoweredExpression
{
    public override ExpressionSyntax Syntax => Slice;
}

internal sealed record LoweredBinaryExpression(
    BinaryExpressionSyntax Binary,
    LoweredExpression Left,
    LoweredExpression Right) : LoweredExpression
{
    public override ExpressionSyntax Syntax => Binary;
}

internal sealed record LoweredChainedComparisonExpression(
    ChainedComparisonExpressionSyntax ChainedComparison,
    IReadOnlyList<LoweredExpression> Operands) : LoweredExpression
{
    public override ExpressionSyntax Syntax => ChainedComparison;
}

internal sealed record LoweredUnaryExpression(
    UnaryExpressionSyntax Unary,
    LoweredExpression Operand) : LoweredExpression
{
    public override ExpressionSyntax Syntax => Unary;
}

internal sealed record LoweredConditionalExpression(
    ConditionalExpressionSyntax Conditional,
    LoweredExpression Consequent,
    LoweredExpression Condition,
    LoweredExpression Alternative) : LoweredExpression
{
    public override ExpressionSyntax Syntax => Conditional;
}

internal sealed record LoweredAssignmentExpression(
    AssignmentExpressionSyntax Assignment,
    LoweredExpression Expression) : LoweredExpression
{
    public override ExpressionSyntax Syntax => Assignment;
}

internal sealed record LoweredLambdaExpression : LoweredExpression
{
    public LoweredLambdaExpression(LambdaExpressionSyntax lambda, LoweredExpression body)
    {
        Lambda = lambda;
        Body = body;
        Parameters = lambda.Parameters.Select(parameter => new LoweredFunctionParameter(
            parameter.Name, parameter.Kind,
            parameter.Annotation is null ? null : LoweredScript.LowerStandaloneExpression(parameter.Annotation),
            parameter.DefaultValue is null ? null : LoweredScript.LowerStandaloneExpression(parameter.DefaultValue))).ToArray();
        ParameterLayout = new(Parameters);
        FunctionBody = [new LoweredReturnStatement(new ReturnStatementSyntax(lambda.Body, lambda.Span), body)];
        ScopeFacts = ScopeDirectiveFactsCollector.ForLambda(lambda);
        if (GeneratorSyntaxFacts.ContainsYield(lambda.Body))
            GeneratorCode = ExecutableScript.CompileGenerator(Parameters, FunctionBody, ScopeFacts);
    }

    public LambdaExpressionSyntax Lambda { get; }
    public LoweredExpression Body { get; }
    public IReadOnlyList<LoweredFunctionParameter> Parameters { get; }
    public FunctionParameterLayout ParameterLayout { get; }
    public IReadOnlyList<LoweredStatement> FunctionBody { get; }
    public ScopeDirectiveFacts ScopeFacts { get; }
    public override ExpressionSyntax Syntax => Lambda;
    public ExecutableCodeObject? GeneratorCode { get; }
}
