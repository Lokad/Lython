namespace Lokad.Lython.Runtime;

internal static class PyTupleLike
{
    public static int ComputeHashCode(IEnumerable<object> items)
    {
        // Tuple hashing recurses into element hashes; bound deep nesting before CLR exhaustion.
        // The items enumerable is the live tuple storage for the common path, so guard its identity.
        using (PyStructuralGuard.EnterSingle(items, null))
        {
            var hash = new HashCode();
            foreach (var item in items)
            {
                PyStructuralGuard.NoteWork();
                hash.Add(PyValueComparer.Instance.GetHashCode(item));
            }

            return hash.ToHashCode();
        }
    }

    public static PyTuple CreateSlice(IReadOnlyList<object> items, IEnumerable<int> indices)
        => new(indices.Select(index => items[index]));

    public static bool TryGetItems(object value, out IReadOnlyList<object> items)
    {
        switch (value)
        {
            case PyIsoCalendarDate calendar:
                items = calendar;
                return true;
            case PyTuple tuple:
                items = tuple;
                return true;
            case PyDecimalTuple decimalTuple:
                items = decimalTuple;
                return true;
            case PyNamedTupleObject namedTuple:
                items = namedTuple;
                return true;
            case LythonRuntime.UrllibParseModule.UrlResult urlResult:
                items = urlResult;
                return true;
            case LythonRuntime.TimeStructTimeValue structTime:
                items = structTime;
                return true;
            default:
                items = Array.Empty<object>();
                return false;
        }
    }
}
