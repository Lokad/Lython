from pathlib import Path
import datetime,json,subprocess,sys
root=Path('.git/agent-notes/review-20261031/prepared-call-layout-r31')
b=json.loads((root/'b384/observe-not-before.json').read_text(encoding='utf-8'))
assert datetime.datetime.now(datetime.timezone.utc)>=datetime.datetime.fromisoformat(b['doNotObserveBeforeUTC'])
for name in ['retrieve-b384.py','summarize-b384.py']:
 r=subprocess.run([sys.executable,'-X','utf8',str(root/name)]);assert r.returncode==0
