from pathlib import Path
import hashlib,json,subprocess,tarfile
root=Path(__file__).parent
archive=Path('benchmarks/results/2026-11-06-remaining-runtime-cost/observations.tgz')
assert archive.read_bytes()==subprocess.check_output(['git','show','49d40b00:benchmarks/results/2026-11-06-remaining-runtime-cost/observations.tgz'])
remote='/home/lokad/lython-bench-checks/remaining-cost-b340-20261106';rows=[]
with tarfile.open(archive) as saved:
    for case in ['class-record','text']:
        for name in ['perf.map','perf-initial.map','perf-final.map']:
            member='perf/'+case+'/'+name;data=saved.extractfile(member).read()
            rows.append(dict(path=remote+'/'+member,bytes=len(data),sha256=hashlib.sha256(data).hexdigest()))
script=r'''from pathlib import Path
import fcntl,hashlib,json,os,shutil,subprocess
base=Path('/home/lokad/lython-bench-checks');root=Path('REMOTE');rows=ROWS
with (base/'comparison-vm.lock').open('a') as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record|[o]ps-profile.py'],capture_output=True).returncode==1
 assert not list(Path('/dev/shm').glob('lython-comparison-files-*'))
 targets=set()
 for row in rows:
  p=Path(row['path'])
  assert p.resolve()==p and root in p.parents and p.is_file() and not p.is_symlink() and p.stat().st_nlink==1
  assert p.stat().st_size==row['bytes'] and hashlib.sha256(p.read_bytes()).hexdigest()==row['sha256']
  targets.add(p)
 for raw in subprocess.check_output(['find',str(base),'-type','l','-print0']).split(b'\0'):
  if raw:assert Path(os.fsdecode(raw)).resolve() not in targets
 for p in targets:p.unlink()
 print(json.dumps(dict(retiredExpandedFiles=rows,independentCommittedArchive='49d40b00:benchmarks/results/2026-11-06-remaining-runtime-cost/observations.tgz',
  allUsersEnded=True,noSymlinkDependencies=True,freeBytes=shutil.disk_usage(base).free),indent=2))
'''.replace('REMOTE',remote).replace('ROWS',repr(rows))
compile(script,'remote','exec');(root/'retire-expanded-maps-command.py').write_text(script,encoding='utf-8',newline='\n')
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73','python3 -']
r=subprocess.run(ssh,input=script,text=True,encoding='utf-8',capture_output=True)
(root/'expanded-map-retirement.json').write_text(r.stdout,encoding='utf-8');assert r.returncode==0,r.stderr
print(r.stdout)
