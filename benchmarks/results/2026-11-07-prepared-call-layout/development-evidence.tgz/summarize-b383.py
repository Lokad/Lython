from pathlib import Path
import json, statistics

root = Path(__file__).resolve().parent
capture = json.loads((root / 'b383/retrieved/confirmation/confirmation.json').read_text(encoding='utf-8'))
rows = []
for job in capture['jobs']:
    elapsed, cpu, iqr = {}, {}, {}
    for role in ['candidate', 'control', 'reference', 'reference-control']:
        samples = [sample for sample in job['samples'] if sample['engine'] == role]
        times = [s['response']['elapsedTicks'] / s['response']['clockFrequency'] / s['response']['completedInvocations'] for s in samples]
        elapsed[role] = statistics.median(times)
        q = statistics.quantiles(times, n=4, method='inclusive')
        iqr[role] = 100 * (q[2] - q[0]) / elapsed[role]
        cpu[role] = statistics.median(s['externalProcessCpuTicks'] / s['externalCpuFrequency'] / s['response']['completedInvocations'] for s in samples)
    row = dict(case=job['case'], lane=job['lane'], elapsedMilliseconds={k:v*1000 for k,v in elapsed.items()},
               processCpuMilliseconds={k:v*1000 for k,v in cpu.items()}, iqrPercent=iqr,
               currentRoleDifferencePercent=100*abs(elapsed['control']-elapsed['candidate'])/elapsed['candidate'],
               referenceRoleDifferencePercent=100*abs(elapsed['reference-control']-elapsed['reference'])/elapsed['reference'],
               changePercent={f'{current}/{reference}':100*(elapsed[current]/elapsed[reference]-1)
                              for current in ['candidate','control'] for reference in ['reference','reference-control']})
    rows.append(row)
    print(json.dumps(row), flush=True)
(root/'comparison-summary.json').write_text(json.dumps(dict(rows=rows, complete=capture['complete'], elapsedSeconds=capture['elapsedSeconds']), indent=2)+'\n', encoding='utf-8')
