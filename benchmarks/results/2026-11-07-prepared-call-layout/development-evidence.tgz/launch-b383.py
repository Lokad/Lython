from pathlib import Path
import datetime,json,subprocess,sys
home=Path('.git/agent-notes/review-20261031/prepared-call-layout-r31')
v=json.loads((home/'catalog-verification.json').read_text(encoding='utf-8'));assert v['state']=='Completed' and v['caseCount']==4
r=subprocess.run([sys.executable,'-X','utf8',str(home/'prepare-b383-expanded.py')]);assert r.returncode==0
now=datetime.datetime.now(datetime.timezone.utc);bound=dict(acknowledgedUTC=now.isoformat(),doNotObserveBeforeUTC=(now+datetime.timedelta(seconds=300)).isoformat(),ownerSeconds=230,stopSeconds=30,marginSeconds=40)
(home/'b383/observe-not-before.json').write_text(json.dumps(bound,indent=2)+'\n',encoding='utf-8',newline='\n')
old=home.parent/'compiler-class-facts-r30'
for name in ['retrieve-b382.py','summarize-b382.py']:
    s=(old/name).read_text(encoding='utf-8').replace('b382','b383').replace('prepared-class-facts-b383','prepared-call-layout-b383').replace('lython-b383-prepared-class-facts','lython-b383-prepared-call-layout').replace("status['receipt']['jobs']==5","status['receipt']['jobs']==6")
    (home/name.replace('b382','b383')).write_text(s,encoding='utf-8',newline='\n')
p=Path('PLAN.md');s=p.read_text(encoding='utf-8');where='## Following redesign roadmap';a=s.index(where)
s=s[:a]+'''R31 prototype33384376/9a043078 passes1,080internal/4,616public per actual target,
including repeated function/default mutation plus complete run/budget reuse.
Precise local diagnostic: class warm allocation−10.65%, fresh−7.35%, compilation
+1,728B; text/CSV changes tiny, config flat. Desktop class warm/fresh elapsed is
adverse and preserved. Do not claim CPU from allocation. B383 now compares six
jobs/four roles on quiet VM; catalog passes supervised Lython/CPython validation.
Observe only after '''+bound['doNotObserveBeforeUTC']+'''; owner230+stop30+margin40.
Core source is frozen for this comparison. Retention/regression decision follows;
no automatic refinement series or unchanged qualification replay.

'''+s[a:];p.write_text(s,encoding='utf-8',newline='\n')
print(bound,flush=True)
