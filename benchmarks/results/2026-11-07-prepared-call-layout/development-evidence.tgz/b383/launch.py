from pathlib import Path
import fcntl,hashlib,io,json,os,shutil,subprocess,sys,tarfile
base=Path('/home/lokad/lython-bench-checks');root=Path('/home/lokad/lython-bench-checks/prepared-call-layout-b383-20261107');prior=Path('/home/lokad/lython-bench-checks/prepared-class-facts-b382-20261107')
with (base/'comparison-vm.lock').open('a') as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert not root.exists() and not list(Path('/dev/shm').glob('lython-comparison-files-*'))
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record'],capture_output=True).returncode==1
 payload=sys.stdin.buffer.read(1912235+1);assert len(payload)==1912235 and hashlib.sha256(payload).hexdigest()=='ec8d0e812eecc389dedb596f13f79f59e7de21264ecfc80be2aa1bbbbef0d0b3'
 with tarfile.open(fileobj=io.BytesIO(payload),mode='r:gz') as a:
  assert shutil.disk_usage(base).free>sum(((m.size+4095)//4096)*4096 for m in a.getmembers())+2*1024*1024
  root.mkdir();a.extractall(root,filter='data')
 for name in ['cpython-worker.py']:(root/name).symlink_to(prior/name)
 (root/'reference').symlink_to(prior/'candidate',target_is_directory=True)
 folder=root/'candidate';folder.mkdir()
 for p in (prior/'candidate').iterdir():
  if p.suffix=='.pdb':continue
  if p.name in ['Lokad.Lython.Benchmarks.dll','Lokad.Lython.Benchmarks.deps.json','Lokad.Lython.Benchmarks.runtimeconfig.json']:os.link(p,folder/p.name)
  else:(folder/p.name).symlink_to(root/p.name if p.name=='Lokad.Lython.dll' else p.resolve(),target_is_directory=p.is_dir())
 identity=json.loads((root/'identity.json').read_text());cases={c['id'] for c in json.loads((root/'representative.json').read_text())['cases']}
 assert all(c in cases for c in ['scripts.class-factory.small','scripts.text-summary-helpers.large'])
 for role in ['candidate','reference']:
  assert hashlib.sha256((root/role/'Lokad.Lython.dll').read_bytes()).hexdigest()==identity['coreSHA256'][role]
  for name,digest in identity['auxiliaryFiles'].items():assert hashlib.sha256((root/role/name).read_bytes()).hexdigest()==digest
 for name in ['collect.py','archive-owned.py']:
  text=(root/name).read_text();assert str(root) in text and 'b381' not in text;compile(text,str(root/name),'exec')
 assert str(root) in (root/'run.sh').read_text() and 'b381' not in (root/'run.sh').read_text()
 subprocess.run(['/bin/sh','-n',str(root/'run.sh')],check=True)
 assert shutil.disk_usage(base).free>2*1024*1024
 print(json.dumps(dict(freeBytes=shutil.disk_usage(base).free,allSixCatalogJobsValidated=True)),flush=True)
subprocess.run(['sudo','-n','systemd-run','--unit=lython-b383-prepared-call-layout-20261107','--property=User=lokad','--property=WorkingDirectory='+str(root),'--property=RuntimeMaxSec=230','--property=TimeoutStopSec=30','--property=KillMode=control-group','/bin/sh',str(root/'run.sh')],check=True)
