from pathlib import Path
root=Path('src/Lokad.Lython')
p=root/'Runtime/Calls/FunctionBindingPlan.cs';s=p.read_text(encoding='utf-8')
start=s.index('    public FunctionBindingPlan(');middle=s.index('            var nameStorageBytes',start);end=s.index('\n    public string CallableName',middle)
body=s[middle:s.index('            governor?.Commit(layoutBytes);',middle)]
body='\n'.join(line[4:] if line.startswith('    ') else line for line in body.splitlines())
# The default construction rollback remains unchanged; immutable tables have a
# separate existing compilation/generated-definition lifetime.
constructor='''    private readonly FunctionParameterLayout _layout;

    public FunctionBindingPlan(
        string callableName,
        PythonCallableKind callableKind,
        FunctionParameterLayout layout,
        IReadOnlyDictionary<string, object> defaultValues,
        LythonRuntime.ExecutionContext? context = null)
    {
        _layout = layout;
        CallableName = callableName;
        CallableKind = callableKind;
        var governor = context?.MemoryGovernor;
'''+body+'''\n    }

    // Native generated definitions have no compiled owner. Admit their immutable
    // tables through successful default construction, preserving full rollback.
    public static FunctionBindingPlan CreateDynamic(string callableName, PythonCallableKind callableKind,
        IReadOnlyList<LoweredFunctionParameter> parameters, IReadOnlyDictionary<string, object> defaultValues,
        LythonRuntime.ExecutionContext? context = null)
    {
        var bytes = FunctionParameterLayout.EstimateBytes(parameters.Count);
        using var storage = context?.MemoryGovernor.ReserveTemporary(bytes, null);
        var result = new FunctionBindingPlan(callableName, callableKind,
            new FunctionParameterLayout(parameters), defaultValues, context);
        storage?.Commit(bytes);
        return result;
    }
'''
s=s[:start]+constructor+s[end:]
for type_,name in [('IReadOnlyList<LoweredFunctionParameter>','PositionalParameters'),('IReadOnlyList<LoweredFunctionParameter>','KeywordOnlyParameters'),('IReadOnlyList<string>','LayoutParameterNames'),('IReadOnlyDictionary<string, int>','LayoutParameterIndex'),('int','NamedLayoutCount'),('int','PositionalOnlyCount'),('LoweredFunctionParameter?','VariadicList'),('LoweredFunctionParameter?','VariadicDictionary')]:
    old=f'public {type_} {name} {{ get; }}';assert old in s;s=s.replace(old,f'public {type_} {name} => _layout.{name};')
p.write_text(s,encoding='utf-8',newline='\n')
# Prepared definitions and executable record copies keep the same immutable shape.
p=root/'Frontend/LoweredStatement.cs';s=p.read_text(encoding='utf-8');old='    public override LoweredStatementKind Kind => LoweredStatementKind.FunctionDefinition;';assert old in s;s=s.replace(old,old+'\n    public FunctionParameterLayout ParameterLayout { get; } = new(Parameters);');p.write_text(s,encoding='utf-8',newline='\n')
p=root/'Frontend/LoweredExpression.cs';s=p.read_text(encoding='utf-8');s=s.replace('        FunctionBody = [new LoweredReturnStatement', '        ParameterLayout = new(Parameters);\n        FunctionBody = [new LoweredReturnStatement',1);old='    public IReadOnlyList<LoweredFunctionParameter> Parameters { get; }';assert s.count(old)==1;s=s.replace(old,old+'\n    public FunctionParameterLayout ParameterLayout { get; }');p.write_text(s,encoding='utf-8',newline='\n')
p=root/'Frontend/ExecutableScript.cs';s=p.read_text(encoding='utf-8');old='    public int DefaultCount { get; } = Parameters.Count';assert s.count(old)==1;s=s.replace(old,'    public required FunctionParameterLayout ParameterLayout { get; init; }\n\n'+old);p.write_text(s,encoding='utf-8',newline='\n')
p=root/'Frontend/ExecutableScript.Infrastructure.cs';s=p.read_text(encoding='utf-8');old='                functionDefinition.Docstring));';assert old in s;s=s.replace(old,'                functionDefinition.Docstring) { ParameterLayout = functionDefinition.ParameterLayout });');p.write_text(s,encoding='utf-8',newline='\n')
# Function objects receive the prepared shape; the mutable plan remains private.
for file in ['PyFunctionBase.cs','PyFunction.cs','PyExecutableFunction.cs','PyGeneratorFunction.cs']:
    p=root/'Runtime'/file;s=p.read_text(encoding='utf-8')
    s=s.replace('IReadOnlyList<LoweredFunctionParameter> parameters,','FunctionParameterLayout parameterLayout,')
    s=s.replace(': base(name, parameters,', ': base(name, parameterLayout,')
    s=s.replace('PythonCallableKind.Function, parameters,', 'PythonCallableKind.Function, parameterLayout,')
    s=s.replace('new FunctionBindingPlan(name, callableKind, parameters,', 'new FunctionBindingPlan(name, callableKind, parameterLayout,')
    s=s.replace('definition.Syntax.DeclaredName, definition.Parameters,', 'definition.Syntax.DeclaredName, definition.ParameterLayout,')
    p.write_text(s,encoding='utf-8',newline='\n')
p=root/'Runtime/LythonRuntime.Executable.Binding.cs';s=p.read_text(encoding='utf-8');s=s.replace('new PyGeneratorFunction(functionBinding.DeclaredName, functionBinding.Parameters,','new PyGeneratorFunction(functionBinding.DeclaredName, functionBinding.ParameterLayout,');s=s.replace('                    functionBinding.Parameters,\n                    functionBinding.CodeObject,','                    functionBinding.ParameterLayout,\n                    functionBinding.CodeObject,');p.write_text(s,encoding='utf-8',newline='\n')
p=root/'Runtime/LythonRuntime.Lowered.Shared.cs';s=p.read_text(encoding='utf-8');s=s.replace('new PyExecutableFunction(functionDefinition.Syntax.DeclaredName, functionDefinition.Parameters,','new PyExecutableFunction(functionDefinition.Syntax.DeclaredName, functionDefinition.ParameterLayout,');s=s.replace('            functionDefinition.Parameters,\n            functionDefinition.Body,','            functionDefinition.ParameterLayout,\n            functionDefinition.Body,');s=s.replace('new PyGeneratorFunction("<lambda>", parameters,','new PyGeneratorFunction("<lambda>", lambda.ParameterLayout,');s=s.replace('new PyExecutableFunction("<lambda>", parameters,','new PyExecutableFunction("<lambda>", lambda.ParameterLayout,');s=s.replace('new PyFunction("<lambda>", parameters,','new PyFunction("<lambda>", lambda.ParameterLayout,');p.write_text(s,encoding='utf-8',newline='\n')
p=root/'Runtime/PyDataclass.GeneratedMethods.cs';s=p.read_text(encoding='utf-8').replace('new FunctionBindingPlan(', 'FunctionBindingPlan.CreateDynamic(');p.write_text(s,encoding='utf-8',newline='\n')
# Tests constructing native-shaped plans use the actual dynamic admission path.
for p in Path('tests').rglob('*.cs'):
    if {'bin','obj'}.intersection(p.parts):continue
    s=p.read_text(encoding='utf-8');t=s.replace('new FunctionBindingPlan(', 'FunctionBindingPlan.CreateDynamic(')
    t=t.replace('new PyExecutableFunction("f", binding.Parameters,','new PyExecutableFunction("f", binding.ParameterLayout,')
    t=t.replace('new PyFunction("f", definition.Parameters,','new PyFunction("f", definition.ParameterLayout,')
    t=t.replace('new PyFunction("f", [], [],','new PyFunction("f", new FunctionParameterLayout([]), [],')
    # Standalone white-box functions model an already prepared definition.
    if p.name in ['BoundBoxCleanupTests.cs','FunctionAttributeAccountingTests.cs']:
        t=t.replace('            parameters,\n            [],', '            new FunctionParameterLayout(parameters),\n            [],')
    if t!=s:p.write_text(t,encoding='utf-8',newline='\n')
print('Canonical prepared layouts replace per-function table construction.',flush=True)
