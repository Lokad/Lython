from pathlib import Path
p=Path('PLAN.md');s=p.read_text(encoding='utf-8');marker='## Independent regex track';a=s.index(marker)
s=s[:a]+'''## Next source-backed consolidation

R32 candidate: feed R31's canonical parameter layout into executable slot-prefix
construction. Builder still loops over parameter kinds twice to establish the
same named/variadic prefix. Remove that second ordering algorithm; keep module
versus function distinction, local directives, captures and synthetic generator
bindings. Existing full layout includes only parameters, while the compiler's
local map also includes body locals; do not conflate the maps. Acceptance: identical
instruction/local/closure shapes for representative helpers, defaults/variadics,
comprehensions/generators/classes; compile allocation/time separate from warm.
No new runtime route, cache, owner or CPU forecast. First finish R31's decision
and coherent qualification boundary before changing its measured source.

Do not target captured-header cloning as ordinary-script overhead: source shows
it serves yielding function-definition headers. Retain real suspension ordering
and annotation behavior. A sync/async public probe with positional-only, regular,
variadic and keyword annotation effects matches CPython; no bug is inferred from
the source alone. Future consolidation requires actual affected workloads.

'''+s[a:];p.write_text(s,encoding='utf-8',newline='\n')
