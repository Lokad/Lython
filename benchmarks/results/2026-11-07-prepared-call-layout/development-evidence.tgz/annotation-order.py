seen = []
def tag(name):
    seen.append(name)
    return int
def call(a:tag('a'), /, b:tag('b'), *c:tag('c'), d:tag('d'), **e:tag('e')) -> tag('r'):
    pass
print(seen)
print(list(call.__annotations__))
