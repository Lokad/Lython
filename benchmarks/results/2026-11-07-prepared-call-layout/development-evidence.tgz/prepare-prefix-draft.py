from pathlib import Path
import difflib,json
root=Path('.git/agent-notes/review-20261031/prepared-call-layout-r31');draft=root/'compiler-prefix-draft';draft.mkdir()
repo=Path('src/Lokad.Lython/Frontend');changes={}
for name in ['ExecutableScript.Builder.cs','ExecutableScript.Infrastructure.cs','ExecutableScript.Statements.cs','ExecutableScript.Comprehensions.cs','ExecutableScript.SuspendingDefinitions.cs','LoweredExpression.cs','LoweredStatement.cs']:
    old=(repo/name).read_text(encoding='utf-8');s=old
    if name=='ExecutableScript.Builder.cs':
        s=s.replace('CompileGenerator(IReadOnlyList<LoweredFunctionParameter> parameters,','CompileGenerator(FunctionParameterLayout parameterLayout,').replace('new Builder(parameters, true,','new Builder(parameterLayout, true,').replace('new Builder(function.Parameters,','new Builder(function.ParameterLayout,')
        s=s.replace('IReadOnlyList<LoweredFunctionParameter>? _functionParameters','FunctionParameterLayout? _parameterLayout').replace('IReadOnlyList<LoweredFunctionParameter> functionParameters','FunctionParameterLayout parameterLayout').replace('IReadOnlyList<LoweredFunctionParameter>? functionParameters','FunctionParameterLayout? parameterLayout')
        s=s.replace('this(functionParameters, null,','this(parameterLayout, null,').replace('_functionParameters = functionParameters;','_parameterLayout = parameterLayout;')
        a=s.index('            // Match Python and FunctionBindingPlan:');b=s.index('            // Function locals include',a)
        s=s[:a]+'''            // Binding and executable locals use one prepared parameter order.
            // Body locals are appended below, without reclassifying the signature.
            if (_parameterLayout is not null)
                foreach (var name in _parameterLayout.LayoutParameterNames)
                    if (IsLocalBindingName(name)) InternLocal(name);
'''+s[b:]
        s=s.replace('_functionParameters','_parameterLayout')
    elif name=='ExecutableScript.Infrastructure.cs':
        s=s.replace('functionDefinition.Parameters, functionDefinition.Body,','functionDefinition.ParameterLayout, functionDefinition.Body,')
        s=s.replace('IReadOnlyList<LoweredFunctionParameter> parameters, IReadOnlyList<LoweredStatement> body,','FunctionParameterLayout parameterLayout, IReadOnlyList<LoweredStatement> body,').replace('new Builder(parameters, candidates,','new Builder(parameterLayout, candidates,').replace('_functionParameters','_parameterLayout')
    elif name=='ExecutableScript.Statements.cs':s=s.replace('_functionParameters','_parameterLayout')
    elif name=='ExecutableScript.Comprehensions.cs':s=s.replace('new Builder([], ChildClosureCandidates(),','new Builder(new FunctionParameterLayout([]), ChildClosureCandidates(),')
    elif name=='ExecutableScript.SuspendingDefinitions.cs':s=s.replace('CompileFunctionCode("<lambda>", lambda.Parameters,','CompileFunctionCode("<lambda>", lambda.ParameterLayout,')
    elif name=='LoweredExpression.cs':s=s.replace('CompileGenerator(Parameters, FunctionBody,','CompileGenerator(ParameterLayout, FunctionBody,')
    elif name=='LoweredStatement.cs':s=s.replace('CompileGenerator(Parameters, Body,','CompileGenerator(ParameterLayout, Body,')
    assert s!=old,name
    (draft/name).write_text(s,encoding='utf-8',newline='\n');changes[name]=''.join(difflib.unified_diff(old.splitlines(True),s.splitlines(True),fromfile=name,tofile=name))
(root/'compiler-prefix-draft.patch').write_text(''.join(changes.values()),encoding='utf-8',newline='\n')
print('Prepared seven-file compiler consolidation draft outside source; measured R31 source unchanged.',flush=True)
