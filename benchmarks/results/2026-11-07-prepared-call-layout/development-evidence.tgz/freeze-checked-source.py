from pathlib import Path
import hashlib,json,subprocess,tarfile
root=Path('.git/agent-notes/review-20261031/prepared-call-layout-r31')
checks=json.loads((root/'focused-initial.json').read_text(encoding='utf-8'))
for framework in ['net11.0','net10.0']:
 p=Path(f'src/Lokad.Lython/bin/Release/{framework}/Lokad.Lython.dll');assert hashlib.sha256(p.read_bytes()).hexdigest()==checks['coreSHA256'][framework]
(root/'candidate-source.patch').write_bytes(subprocess.check_output(['git','-c','core.safecrlf=false','diff','--','src','tests']))
# git diff excludes new files. Preserve them explicitly with the exact checked source.
with tarfile.open(root/'candidate-source-and-images.tgz','w:gz') as a:
 for p in Path('src/Lokad.Lython').rglob('*.cs'):
  if not {'bin','obj'}.intersection(p.parts):a.add(p,arcname=p)
 for framework in ['net11.0','net10.0']:
  a.add(Path(f'src/Lokad.Lython/bin/Release/{framework}/Lokad.Lython.dll'),arcname=f'checked-images/{framework}/Lokad.Lython.dll')
 a.add('tests/Lokad.Lython.PublicApi.Tests/PreparedFunctionDefaultsTests.cs',arcname='new-regressions/PreparedFunctionDefaultsTests.cs')
print('Exact R31 checked source, including new files, frozen images and patch preserved.',flush=True)
