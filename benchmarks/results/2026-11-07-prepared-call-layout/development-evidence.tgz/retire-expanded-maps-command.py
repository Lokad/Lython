from pathlib import Path
import fcntl,hashlib,json,os,shutil,subprocess
base=Path('/home/lokad/lython-bench-checks');root=Path('/home/lokad/lython-bench-checks/remaining-cost-b340-20261106');rows=[{'path': '/home/lokad/lython-bench-checks/remaining-cost-b340-20261106/perf/class-record/perf.map', 'bytes': 1572864, 'sha256': '188c22b1fc3ce31e1e753de1eb72f7ceedc3be20d3f6d79a0f15e8089b9075c5'}, {'path': '/home/lokad/lython-bench-checks/remaining-cost-b340-20261106/perf/class-record/perf-initial.map', 'bytes': 1572864, 'sha256': '188c22b1fc3ce31e1e753de1eb72f7ceedc3be20d3f6d79a0f15e8089b9075c5'}, {'path': '/home/lokad/lython-bench-checks/remaining-cost-b340-20261106/perf/class-record/perf-final.map', 'bytes': 1580037, 'sha256': '4276a6c212e0f518aae85da0024c2da520865970a4eba40d8eca94b0f5430346'}, {'path': '/home/lokad/lython-bench-checks/remaining-cost-b340-20261106/perf/text/perf.map', 'bytes': 1331200, 'sha256': 'e4bdd11de50117f5b0fc9025d966434c14aa57872d33a57509a85606b3898ce9'}, {'path': '/home/lokad/lython-bench-checks/remaining-cost-b340-20261106/perf/text/perf-initial.map', 'bytes': 1331200, 'sha256': 'e4bdd11de50117f5b0fc9025d966434c14aa57872d33a57509a85606b3898ce9'}, {'path': '/home/lokad/lython-bench-checks/remaining-cost-b340-20261106/perf/text/perf-final.map', 'bytes': 1339694, 'sha256': '72ae3927830d20ce35d1756db86c0b6e7153d478dc74f4f3d7e86e7570f6716c'}]
with (base/'comparison-vm.lock').open('a') as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record|[o]ps-profile.py'],capture_output=True).returncode==1
 assert not list(Path('/dev/shm').glob('lython-comparison-files-*'))
 targets=set()
 for row in rows:
  p=Path(row['path'])
  assert p.resolve()==p and root in p.parents and p.is_file() and not p.is_symlink() and p.stat().st_nlink==1
  assert p.stat().st_size==row['bytes'] and hashlib.sha256(p.read_bytes()).hexdigest()==row['sha256']
  targets.add(p)
 for raw in subprocess.check_output(['find',str(base),'-type','l','-print0']).split(b'\0'):
  if raw:assert Path(os.fsdecode(raw)).resolve() not in targets
 for p in targets:p.unlink()
 print(json.dumps(dict(retiredExpandedFiles=rows,independentCommittedArchive='49d40b00:benchmarks/results/2026-11-06-remaining-runtime-cost/observations.tgz',
  allUsersEnded=True,noSymlinkDependencies=True,freeBytes=shutil.disk_usage(base).free),indent=2))
