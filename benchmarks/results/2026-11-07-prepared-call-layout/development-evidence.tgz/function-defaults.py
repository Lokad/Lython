def make(seed):
    def call(value=seed, /, *extra, flag=seed, **named):
        return value, extra, flag, named, seed
    def stream(value=seed, *, flag=seed):
        yield value, flag, seed
    return call, stream, lambda value=seed, *, flag=seed: (value, flag, seed)
first, first_stream, first_lambda = make(2)
second, second_stream, second_lambda = make(7)
first.__defaults__ = (11,)
first.__kwdefaults__['flag'] = 13
first_stream.__kwdefaults__['flag'] = 17
first_lambda.__defaults__ = (19,)
print(first())
print(second(23, 29, value=31, flag=37))
print(list(first_stream()), list(second_stream()))
print(first_lambda(), second_lambda())
print(second.__defaults__, second.__kwdefaults__)
