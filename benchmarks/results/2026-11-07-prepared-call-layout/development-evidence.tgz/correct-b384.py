from pathlib import Path
import ast,datetime,hashlib,json,shutil,subprocess,tarfile
home=Path(__file__).parent;old=home/'b383';root=home/'b384';root.mkdir()
for name in ['identity.json','pre-measurement-plan.md','source.patch','contract.md','setup-contract.json','representative.json']:
    shutil.copyfile(old/name,root/name)
for name in ['collect.py','archive-owned.py','run.sh']:
    s=(old/name).read_text(encoding='utf-8').replace('prepared-call-layout-b383-20261107','prepared-call-layout-b384-20261107')
    s=s.replace('len(jobs)==5','len(jobs)==6').replace("len(r['jobs'])==5","len(r['jobs'])==6").replace('jobs=5','jobs=6')
    (root/name).write_text(s,encoding='utf-8',newline='\n')
collect=(root/'collect.py').read_text(encoding='utf-8');archive=(root/'archive-owned.py').read_text(encoding='utf-8')
tree=ast.parse(collect)
jobs=next(ast.literal_eval(n.value) for n in tree.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='jobs' for t in n.targets))
assert len(jobs)==6 and len(set(jobs))==6
assert 'assert len(jobs)==6 ' in collect and "len(r['jobs'])==6" in archive and 'jobs=6' in archive
assert 'b383' not in collect+archive+(root/'run.sh').read_text(encoding='utf-8')
ast.parse(archive)
with tarfile.open(root/'payload.tgz','w:gz') as a:
    for p in root.iterdir():
        if p.name!='payload.tgz':a.add(p,arcname=p.name)
payload=(root/'payload.tgz').read_bytes();oldpayload=(old/'payload.tgz').read_bytes()
script=(old/'launch.py').read_text(encoding='utf-8').replace('b383','b384')
script=script.replace(str(len(oldpayload)),str(len(payload))).replace(hashlib.sha256(oldpayload).hexdigest(),hashlib.sha256(payload).hexdigest())
a=script.index(" folder=root/'candidate';folder.mkdir()");b=script.index(' identity=json.loads',a)
script=script[:a]+" (root/'candidate').symlink_to(Path('/home/lokad/lython-bench-checks/prepared-call-layout-b383-20261107/candidate'),target_is_directory=True)\n"+script[b:]
script=script.replace(" for name in ['collect.py','archive-owned.py']:"," assert 'assert len(jobs)==6 ' in (root/'collect.py').read_text()\n assert \"len(r['jobs'])==6\" in (root/'archive-owned.py').read_text()\n for name in ['collect.py','archive-owned.py']:")
ast.parse(script);(root/'launch.py').write_text(script,encoding='utf-8',newline='\n')
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15']
p=subprocess.run(['C:/Windows/System32/OpenSSH/scp.exe',*ssh[1:],str(root/'launch.py'),'lokad@20.166.121.73:/home/lokad/lython-bench-checks/b384-launch.py'],capture_output=True);assert p.returncode==0,p.stderr
p=subprocess.run([*ssh,'lokad@20.166.121.73','python3 /home/lokad/lython-bench-checks/b384-launch.py'],input=payload,capture_output=True)
(root/'launch.log').write_bytes(p.stdout+p.stderr);assert p.returncode==0,(p.stdout+p.stderr).decode('utf-8')
now=datetime.datetime.now(datetime.timezone.utc);bound=dict(acknowledgedUTC=now.isoformat(),doNotObserveBeforeUTC=(now+datetime.timedelta(seconds=300)).isoformat(),ownerSeconds=230,stopSeconds=30,marginSeconds=40)
(root/'observe-not-before.json').write_text(json.dumps(bound,indent=2)+'\n',encoding='utf-8',newline='\n')
for name in ['retrieve-b383.py','summarize-b383.py']:
    (home/name.replace('b383','b384')).write_text((home/name).read_text(encoding='utf-8').replace('b383','b384'),encoding='utf-8',newline='\n')
p=Path('PLAN.md');s=p.read_text(encoding='utf-8');s+='\nB383 failed before workers on a stale five-job collector assertion; no timings.\nFailure archived, no users/fixtures. Generated B384 collector/archive job counts\nare now checked locally and remotely before launch. Same runtime/catalog/profile.\nObserve after '+bound['doNotObserveBeforeUTC']+'; no queries/restarts before bound.\n';p.write_text(s,encoding='utf-8',newline='\n')
print((p.stdout+p.stderr).decode('utf-8') if False else json.dumps(bound),flush=True)
