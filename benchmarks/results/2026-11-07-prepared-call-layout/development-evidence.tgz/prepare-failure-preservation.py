from pathlib import Path
root=Path('.git/agent-notes/review-20261031/prepared-call-layout-r31');old=root.parent/'compiler-class-facts-r30'
s=(old/'preserve-b381-failure.py').read_text(encoding='utf-8').replace('b381','b383').replace('prepared-class-facts','prepared-call-layout')
(root/'preserve-b383-failure.py').write_text(s,encoding='utf-8',newline='\n')
