from pathlib import Path
import json,os,subprocess
root=Path(__file__).parent
env=os.environ.copy();env['DOTNET_ROOT']='C:/Users/JoannesVermorel/.dotnet11';env['DOTNET_HOST_PATH']=env['DOTNET_ROOT']+'/dotnet.exe';env['PATH']=env['DOTNET_ROOT']+os.pathsep+'C:/Python313'+os.pathsep+env['PATH']
checks=[]
for tfm in ['net11.0','net10.0']:
    for asynchronous in [False,True]:
        command=[env['DOTNET_HOST_PATH'],f'tools/LythonProbe/bin/Release/{tfm}/LythonProbe.dll',str(root/'function-defaults.py'),'--compare-python','--json']
        if asynchronous:command.append('--async')
        result=subprocess.run(command,env=env,text=True,encoding='utf-8',capture_output=True)
        name=tfm+('-async' if asynchronous else '-sync')
        (root/(name+'-probe.json')).write_text(result.stdout,encoding='utf-8',newline='\n')
        assert result.returncode==0,result.stdout+result.stderr
        checks.append(dict(tfm=tfm,asynchronous=asynchronous,exitCode=0,stdout=result.stdout,stderr=result.stderr))
        print(name,'matched isolated CPython',flush=True)
(root/'probes.json').write_text(json.dumps(checks,indent=2)+'\n',encoding='utf-8',newline='\n')
