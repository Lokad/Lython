from pathlib import Path
p=Path('.git/agent-notes/review-20261031/prepared-call-layout-r31/focused.py')
s=Path('.git/agent-notes/review-20261031/compiler-class-facts-r30/focused.py').read_text(encoding='utf-8')
a=s.index('families=[');b=s.index('\nselection=',a)
s=s[:a]+"families=['Function','Binding','Bound','Keyword','Lambda','Generator','Dataclass','Class','Scope','Super','Annotation','SharedMemory','GovernedMemory','Cancellation']"+s[b:]
p.write_text(s,encoding='utf-8',newline='\n')
