from pathlib import Path
import re,subprocess,os,json
home=Path('.git/agent-notes/review-20261031/prepared-call-layout-r31')
source=Path('tests/Lokad.Lython.PublicApi.Tests/PreparedFunctionDefaultsTests.cs').read_text(encoding='utf-8').split('const string source = """\n',1)[1].split('\n""";',1)[0]+'\n'
(home/'function-defaults.py').write_text(source,encoding='utf-8',newline='\n')
s=(home.parent/'compiler-class-facts-r30/probes.py').read_text(encoding='utf-8').replace("root/'class-factory.py'","root/'function-defaults.py'")
(home/'probes.py').write_text(s,encoding='utf-8',newline='\n')
