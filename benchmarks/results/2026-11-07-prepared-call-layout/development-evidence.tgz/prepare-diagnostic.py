from pathlib import Path
import ast,copy,json,shutil
root=Path('.git/agent-notes/review-20261031/prepared-call-layout-r31');old=root.parent/'compiler-class-facts-r30'
(root/'tool').mkdir()
for name in ['Directory.Build.props','complete-jobs.csproj']:shutil.copyfile(old/'tool'/name,root/'tool'/name)
s=(old/'tool/Program.cs').read_text(encoding='utf-8').replace('cases.Length != 2','cases.Length != 4').replace('Require one class-factory job and one unchanged text control.','Require class-factory, configuration, text and CSV cases.').replace('R30 bounded class-fact diagnostic','R31 prepared function-layout diagnostic')
(root/'tool/Program.cs').write_text(s,encoding='utf-8',newline='\n')
catalog=json.loads((old/'catalog.json').read_text(encoding='utf-8'))
complete=json.loads((root.parent/'compact-fragments-b205/catalog.json').read_text(encoding='utf-8'))
ids=['scripts.config-edit.small','scripts.csv-summary-functions.large']
print('Available configuration cases:',[c['id'] for c in complete['cases'] if 'config' in c['id']])
for case_id in ids:
    case=next((c for c in complete['cases'] if c['id']==case_id),None)
    if case is None:
        prior=Path('.git/agent-notes/review-20261031/delivery-comparison-b380/retrieved/representative.json')
        if prior.exists():case=next((c for c in json.loads(prior.read_text(encoding='utf-8'))['cases'] if c['id']==case_id),None)
    assert case is not None,case_id
    catalog['cases'].append(case)
assert len(catalog['cases'])==4
(root/'catalog.json').write_text(json.dumps(catalog,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
s=(old/'measure.py').read_text(encoding='utf-8').replace("root.parent/'execution-transport-r29/allocation/candidate/Lokad.Lython.dll'","root.parent/'compiler-class-facts-r30/images/candidate/Lokad.Lython.dll'")
s=s.replace("['baselineSHA256']","['coreSHA256']['net11.0']").replace('one32-class-factory job and unchanged text control','class-factory, configuration, text and CSV complete jobs').replace("for phase in ['compile','warm']:","for phase in ['compile','warm','fresh']:")
ast.parse(s);(root/'measure.py').write_text(s,encoding='utf-8',newline='\n')
s=(old/'summarize.py').read_text(encoding='utf-8').replace("['compile','warm']","['compile','warm','fresh']")
(root/'summarize.py').write_text(s,encoding='utf-8',newline='\n')
print('Prepared four-case diagnostic through existing driver, compile/warm/fresh separate.',flush=True)
