from pathlib import Path
import json,statistics
root=Path(__file__).parent;rows=[]
for phase in ['compile','warm','fresh']:
    data=json.loads((root/phase/'measurements.json').read_text(encoding='utf-8'))
    assert all(data[k] for k in ['allGoldensPassed','allBalancesZero','ownedFixturesRemoved','imageIsolationVerified'])
    for case in data['observations']:
        values={};elapsed={};phase_times={}
        for role in ['before','candidate','before-control']:
            samples=[s for s in case['samples'] if s['image']==role]
            values[role]=statistics.median(s['allocatedBytes']/s['jobs'] for s in samples)
            elapsed[role]=statistics.median(s['elapsedMilliseconds']/s['jobs'] for s in samples)
            phase_times[role]=statistics.median(s['executionMilliseconds']/s['jobs'] for s in samples)
        row=dict(phase=phase,case=case['caseId'],allocatedBytesPerJob=values,
                 allocatedChangePercent=100*(values['candidate']/values['before']-1),
                 desktopElapsedMilliseconds=elapsed,desktopPhaseMilliseconds=phase_times,
                 admittedPeaks=case['admittedPeaks'])
        rows.append(row);print(json.dumps(row),flush=True)
(root/'summary.json').write_text(json.dumps(dict(rows=rows,allSemanticAndOwnershipGatesPassed=True,
    performanceQualified=False,limitations='Precise complete-job process allocation includes reset/I/O/checks and prior-result disposal for warm; compile is separate. Shared-ALC process GC and desktop/tiering variation make clocks diagnostic only, not CPU or whole-script quiet-machine performance proof.'),indent=2)+'\n',encoding='utf-8',newline='\n')
