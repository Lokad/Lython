from pathlib import Path
import subprocess,os,json
root=Path('.git/agent-notes/review-20261031/prepared-call-layout-r31');source='''seen = []
def tag(name):
    seen.append(name)
    return int
def call(a:tag('a'), /, b:tag('b'), *c:tag('c'), d:tag('d'), **e:tag('e')) -> tag('r'):
    pass
print(seen)
print(list(call.__annotations__))
'''
(root/'annotation-order.py').write_text(source,encoding='utf-8',newline='\n')
env=os.environ.copy();env['DOTNET_ROOT']='C:/Users/JoannesVermorel/.dotnet11';env['PATH']=env['DOTNET_ROOT']+os.pathsep+'C:/Python313'+os.pathsep+env['PATH']
rows=[]
for asynchronous in [False,True]:
 command=[env['DOTNET_ROOT']+'/dotnet.exe','tools/LythonProbe/bin/Release/net11.0/LythonProbe.dll',str(root/'annotation-order.py'),'--compare-python','--json']
 if asynchronous:command.append('--async')
 r=subprocess.run(command,env=env,text=True,encoding='utf-8',capture_output=True);rows.append(dict(asynchronous=asynchronous,exitCode=r.returncode,stdout=r.stdout,stderr=r.stderr));print(r.stdout,flush=True)
(root/'annotation-order-probes.json').write_text(json.dumps(rows,indent=2)+'\n',encoding='utf-8',newline='\n')
