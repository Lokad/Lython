from pathlib import Path
root=Path('.git/agent-notes/review-20261031/prepared-call-layout-r31')
s=Path('.git/agent-notes/review-20261031/execution-transport-r29/retire-archived-r24.py').read_text(encoding='utf-8')
s=s.replace('2026-11-07-current-script-cpu','2026-11-06-remaining-runtime-cost').replace('81036f25:','49d40b00:').replace("remote='/home/lokad/lython-bench-checks/current-cpu-b371-20261107'","remote='/home/lokad/lython-bench-checks/remaining-cost-b340-20261106'")
s=s.replace("['text-warm','report-warm']","['class-record','text']").replace("['perf.data','perf.map','perf-stacks.txt','record.json']","['perf.map','perf-initial.map','perf-final.map']")
s=s.replace('retire-archived-r24-command.py','retire-expanded-maps-command.py').replace('r24-expanded-retirement.json','expanded-map-retirement.json')
(root/'retire-expanded-maps.py').write_text(s,encoding='utf-8',newline='\n')
