from pathlib import Path
import hashlib,json,shutil,tarfile
r=Path(__file__).parent;q=r/'checkpoint';out=Path('benchmarks/results/2026-11-16-normalization-cpython-checkpoint');out.mkdir(exist_ok=True)
d=json.loads((q/'summary.json').read_text(encoding='utf-8'));receipt=json.loads((q/'archive-receipt.json').read_text(encoding='utf-8'))
assert d['complete'] and d['jobs']==2 and receipt['complete'] and receipt['allWorkersJoined']
assert hashlib.sha256((q/'observations.tgz').read_bytes()).hexdigest()==receipt['archiveSHA256']
for n in ['identity.json','summary.json','observations.tgz','archive-receipt.json','terminal-status.json']:shutil.copyfile(q/n,out/n)
shutil.copyfile('docs/BENCHMARKS.md',out/'prior-BENCHMARKS.md')
with tarfile.open(out/'procedure-and-inputs.tar.xz','w:xz') as a:
 for p in q.iterdir():
  if p.is_file() and p.name!='observations.tgz':a.add(p,arcname='checkpoint/'+p.name)
 for p in r.iterdir():
  if p.is_file():a.add(p,arcname='procedure/'+p.name)
 for n in ['representative.json','additional.json','cpython-worker.py']:a.add(q/'retrieved'/n,arcname='inputs/'+n)
 a.add(r.parent/'consume-text-r426/delivery/source-proof.json',arcname='source-proof.json')
rows=[];detail=[]
for x in d['timing']:
 phase='warm Run' if x['lane']=='warm' else 'compile and execute once'
 m=x['medianMilliseconds'];l=[m[n] for n in ['candidate','candidate-control']];p=[m[n] for n in ['CPython','CPython-control']]
 lt=f'{min(l):.3f}–{max(l):.3f} ms';pt=f'{min(p):.3f}–{max(p):.3f} ms';ratio=f"{min(x['ratioRange']):.2f}–{max(x['ratioRange']):.2f}×"
 status=f"Diagnostic; spreads {x['lythonControlPercent']:.2f}/{x['cpythonControlPercent']:.2f}%; IQR ≤{x['maxIqrPercent']:.2f}%"
 rows.append(f'| File normalization / {phase} | 4,096 lines / 52,224 B | {lt} | {pt} | {ratio} | {status} |')
 detail.append(f'| {phase} | {lt} | {pt} | {ratio} | {status} |')
(out/'README.md').write_text('''# Complete file-normalization CPython checkpoint

R427/B823, 2026-11-16 UTC. Runtime **116fe6e0 / measured810dafdd** versus
**CPython3.13.16**. The 593 production/build/test inputs match committed source.
This comparison uses the unchanged R426 core. Its initial full delivery later failed
on six stale accounting expectations and one Windows process-allocation assertion;
test-only corrections are being qualified. Measurement gates do not establish full
runtime qualification. Original identity text saying CI was active describes capture
time; retain it unchanged.

One complete Unicode file-normalization script reads 52,224 bytes / 4,096 lines,
normalizes mixed newlines and tabs, trims lines, joins and writes 54,269 bytes /
4,095 lines. Café/emoji, CJK, Straße, Greek and blank lines are represented. Complete
stdout and file bytes agree with independently constructed goldens and CPython.
This fills a useful new workload gap; it is not a causal source-pair speedup.

| Phase | Lython | CPython | Lython / CPython | Measurement status |
| --- | ---: | ---: | ---: | --- |
'''+ '\n'.join(detail)+f'''

All four process-median pairings are shown, not confidence intervals. Two jobs in
**{d['elapsedSeconds']:.3f}s**; two processes/engine, five-second full-request warmups
and five rotated approximately half-second batches. Lython's fresh control moves
5.11% and IQR reaches 7.35%. Keep the uncertainty in exact ratios; a material gap
remains and justifies one bounded current-source CPU capture before a redesign.

Quiet Azure F4as_v7 / Ubuntu24.04.4, four AMD EPYC9V45 vCPUs, 16 GiB/no swap,
.NET11RC3 ordinary tiering/natural workstation GC and CPython GIL/GC.
Warm includes Run, mediated RAM I/O, full stdout/file goldens and prior-result
cleanup; excludes compilation/startup, reset/protocol and final cache teardown.
Compile-to-result adds compilation, one execution and compiled-owner disposal.
Separate medians are not additive. Wider CPU includes reset/protocol. Native
CPython buffered files provide different containment; this measures embedding
cost, not isolated interpreter CPU. No startup, pending-I/O, contention, heap/RSS
or embedding-tail comparison.

All image/catalog/golden/budget/quiet/Closed/exit/join/archive gates pass. Every RAM
trace was archived and verified under the lease before teardown. No workers or
guest fixtures remain. An exact redundant historical catalog was retired only
after Git custody and fresh path/ownership/hash checks; toolchains/current images
and the original 254/252 MiB floors remain. Terminal cached; publication held.

[All controls](summary.json), [identity](identity.json), [raw observations](observations.tgz),
[procedure/inputs/source proof](procedure-and-inputs.tar.xz), [previous guide](prior-BENCHMARKS.md),
[runtime source pair](../2026-11-16-consuming-text-completion/README.md).
''',encoding='utf-8',newline='\n')
p=Path('docs/BENCHMARKS.md');s=p.read_text(encoding='utf-8');needle='| --- | --- | ---: | ---: | ---: | --- |';assert s.count(needle)==1
s=s.replace(needle,needle+'\n'+'\n'.join(rows),1)
needle='**Patch phases and CSV warm:'
idx=s.index(needle)
s=s[:idx]+'''**File normalization: 116fe6e0 / measured810dafdd**, 2026-11-16 UTC;
[complete warm/fresh checkpoint](../benchmarks/results/2026-11-16-normalization-cpython-checkpoint/README.md).
All measurement/cleanup gates pass; initial full runtime CI found accounting-test
corrections, now under qualification. Warm remains 1.63–1.68× CPython; fresh
1.49–1.58× with 5.11% Lython control spread / 7.35% maximum IQR. This new workload
baseline is diagnostic, not evidence of a source-change speedup.

'''+s[idx:]
p.write_text(s,encoding='utf-8',newline='\n')
p=Path('benchmarks/EXPERIMENTS.md');s=p.read_text(encoding='utf-8');s+='\n\n[R427/B823 complete file-normalization CPython phases](results/2026-11-16-normalization-cpython-checkpoint/README.md): 116fe6e0/810dafdd vs CPython3.13.16; two jobs71.314s/all measurement gates. Warm1.63–1.68×, fresh1.49–1.58×; fresh control5.11%/IQR7.35% retained. New useful workload, no causal source gain. Initial runtime CI failed accounting-test expectations; corrections active. One bounded current-source profile follows; broader objective remains open.\n';p.write_text(s,encoding='utf-8',newline='\n')
print('\n'.join(rows))
