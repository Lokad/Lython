from pathlib import Path
import ast,datetime,hashlib,io,json,shlex,subprocess,tarfile

r=Path(__file__).parent;q=r/'checkpoint';q.mkdir();old=r.parent/'patch-checkpoint-r421/checkpoint'
base=r.parent/'consume-text-r426';head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
assert head.startswith('116fe6e0') and not subprocess.check_output(['git','status','--porcelain'],text=True).strip()
proof=json.loads((base/'delivery/source-proof.json').read_text(encoding='utf-8'))
assert proof['commit']==head and proof['inputCount']==593 and proof['allInputsMatchAfterExplicitUTF8NewlineNormalization']
image=json.loads((base/'quiet/identity.json').read_text(encoding='utf-8'))['imageFiles']['candidate']
assert image['Lokad.Lython.dll']=='810dafdd2afb684158374098c5b16e850369b7a6ebe2a56e451f3bd96f741d46'
catalog=json.loads((base/'catalog.json').read_text(encoding='utf-8'))
catalog['cases']=[next(c for c in catalog['cases'] if c['id']=='scripts.text-normalization.large')]
for c in catalog['cases']:
    for n,k in [('sourceSha256','source'),('fixtureSha256','fixtureJson'),('expectedOutputSha256','expectedOutput')]:assert hashlib.sha256(c[k].encode()).hexdigest()==c[n]
(q/'representative.json').write_text(json.dumps(catalog,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
additional=base/'quiet/retrieved/additional.json'
root='/home/lokad/lython-bench-checks/normalization-cpython-b823-20261116';unit='lython-b823-normalization-cpython-20261116'
identity=dict(sourceRevision=head+'/frozen810dafdd',runtimeCommit=head,
    purpose='Complete Unicode file normalization warm/fresh against CPython; fill new useful workload gap to prioritize a whole generator/iteration/text pipeline, not a causal source comparison.',
    coreSHA256={n:image['Lokad.Lython.dll'] for n in ['candidate','candidate-control']},
    auxiliaryFiles={n:h for n,h in image.items() if n!='Lokad.Lython.dll'},
    catalogSHA256=hashlib.sha256((q/'representative.json').read_bytes()).hexdigest(),
    additionalCatalogSHA256=hashlib.sha256(additional.read_bytes()).hexdigest(),
    qualification='Committed/pushed116fe6e0;87internal/2547public focused eachactual11/10;593committed inputs verified;full43797131423active',publicationHeld=True)
(q/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8',newline='\n')
jobs=[['scripts.text-normalization.large','warm'],['scripts.text-normalization.large','compile-run']]
for n in ['collect.py','archive-owned.py','run.sh','retrieve.py','summarize.py']:
    s=(old/n).read_text(encoding='utf-8').replace('patch-cpython-b816-20261116','normalization-cpython-b823-20261116').replace('lython-b816-patch-cpython-20261116',unit).replace('B816','B823')
    if n=='collect.py':
        a=s.index('jobs=');b=s.index('\nenv =',a)
        s=s[:a]+'jobs='+repr(jobs)+"\ncases.update({c['id']:c for c in json.loads((root/'additional.json').read_text())['cases']})\nassert len(jobs)==4 and all(case in cases for case,lane in jobs)\n"+s[b:]
    s=s.replace("len(jobs)==4", "len(jobs)==2").replace("len(raw['jobs'])==4", "len(raw['jobs'])==2").replace("['jobs']==4", "['jobs']==2").replace('jobs=4', 'jobs=2')
    if n.endswith('.py'):ast.parse(s)
    (q/n).write_text(s,encoding='utf-8',newline='\n')
with tarfile.open(q/'payload.tgz','w:gz') as t:
    for n in ['identity.json','representative.json','collect.py','archive-owned.py','run.sh']:t.add(q/n,arcname=n)
with tarfile.open(q/'payload.tgz') as t:size=sum(m.size for m in t if m.isfile())
source='/home/lokad/lython-bench-checks/consume-text-b822-20261116'
canonical='benchmarks/results/2026-11-16-finally-prefix/source-checks-and-procedure.tar.xz'
raw=Path(canonical).read_bytes();assert subprocess.check_output(['git','show',head+':'+canonical])==raw
with tarfile.open(fileobj=io.BytesIO(raw)) as a:old_catalog=a.extractfile('procedure/catalog.json').read()
retire=[dict(path='finally-prefix-b819-20261116/representative.json',bytes=len(old_catalog),sha256=hashlib.sha256(old_catalog).hexdigest(),
    canonicalCommit=head,canonicalPath=canonical,member='procedure/catalog.json')]
c=dict(root=root,unit=unit,source=source,catalog=source+'/representative.json',
    sourceCatalogSHA256=hashlib.sha256((base/'catalog.json').read_bytes()).hexdigest(),additional=source+'/additional.json',
    identity=identity,retire=retire,payloadBytes=(q/'payload.tgz').stat().st_size,
    payloadSHA256=hashlib.sha256((q/'payload.tgz').read_bytes()).hexdigest(),unpackedBytes=size)
(q/'config.json').write_text(json.dumps(c,indent=2)+'\n',encoding='utf-8',newline='\n')
code=(old/'launch-command.py').read_text(encoding='utf-8');a=code.index('c=');b=code.index(';b=Path(',a)
code=code[:a]+'c='+repr(c)+code[b:]
code=code.replace('lython-b816-fixtures','lython-b823-fixtures')
ast.parse(code);(q/'launch-command.py').write_text(code,encoding='utf-8',newline='\n')
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
p=subprocess.run(ssh+['python3 -c '+shlex.quote(code)],input=(q/'payload.tgz').read_bytes(),capture_output=True,timeout=45)
(q/'launch.log').write_bytes(p.stdout+p.stderr);assert p.returncode==0,(p.stdout+p.stderr).decode('utf-8','replace')
now=datetime.datetime.now(datetime.timezone.utc)
(q/'observe-not-before.json').write_text(json.dumps(dict(startedUTC=now.isoformat(),doNotObserveBeforeUTC=(now+datetime.timedelta(seconds=120)).isoformat(),ownerSeconds=240),indent=2)+'\n',encoding='utf-8',newline='\n')
print(p.stdout.decode('utf-8'),flush=True)
