from pathlib import Path
import ast
r=Path(__file__).parent
s=(r.parent/'compiler-checkpoint-r425/launch.py').read_text(encoding='utf-8')
s=s.replace('import ast,datetime,hashlib,json,shlex,subprocess,tarfile','import ast,datetime,hashlib,io,json,shlex,subprocess,tarfile')
s=s.replace("base=r.parent/'compiler-instruction-store-r424'", "base=r.parent/'consume-text-r426'")
s=s.replace("'a2d20928'", "'116fe6e0'").replace("==590", "==593")
s=s.replace('9d26d408ac591aba042f92106167a7cc1df8148b6fc26554f65fa667af5cb5f0','810dafdd2afb684158374098c5b16e850369b7a6ebe2a56e451f3bd96f741d46')
a=s.index("catalog['cases']=[");b=s.index("for c in catalog['cases']:",a)
s=s[:a]+"catalog['cases']=[next(c for c in catalog['cases'] if c['id']=='scripts.text-normalization.large')]\n"+s[b:]
s=s.replace('compiler-cpython-b821-20261116','normalization-cpython-b823-20261116').replace('lython-b821-compiler-cpython-20261116','lython-b823-normalization-cpython-20261116')
s=s.replace('/frozen9d26d408','/frozen810dafdd')
s=s.replace('Refresh complete manifest compile/fresh and method-report warm with original f-string control against CPython after retained compiler storage/format consolidation. Not a causal source comparison.',
            'Complete Unicode file normalization warm/fresh against CPython; fill new useful workload gap to prioritize a whole generator/iteration/text pipeline, not a causal source comparison.')
s=s.replace('Committed/pusheda2d20928;151internal/1011public focused eachactual11/10;590committed inputs verified;full43789371043active',
            'Committed/pushed116fe6e0;87internal/2547public focused eachactual11/10;593committed inputs verified;full43797131423active')
a=s.index('jobs=');b=s.index('\nfor n in',a)
s=s[:a]+"jobs=[['scripts.text-normalization.large','warm'],['scripts.text-normalization.large','compile-run']]"+s[b:]
s=s.replace(".replace('B816','B821')", ".replace('B816','B823')")
s=s.replace("    if n.endswith('.py'):ast.parse(s)", '''    s=s.replace("len(jobs)==4", "len(jobs)==2").replace("len(raw['jobs'])==4", "len(raw['jobs'])==2").replace("['jobs']==4", "['jobs']==2").replace('jobs=4', 'jobs=2')
    if n.endswith('.py'):ast.parse(s)''')
s=s.replace("source='/home/lokad/lython-bench-checks/compiler-store-b820-20261116'", "source='/home/lokad/lython-bench-checks/consume-text-b822-20261116'")
needle="c=dict(root=root,unit=unit,source=source,catalog=source+'/representative.json',"
assert needle in s
s=s.replace(needle,'''canonical='benchmarks/results/2026-11-16-finally-prefix/source-checks-and-procedure.tar.xz'
raw=Path(canonical).read_bytes();assert subprocess.check_output(['git','show',head+':'+canonical])==raw
with tarfile.open(fileobj=io.BytesIO(raw)) as a:old_catalog=a.extractfile('procedure/catalog.json').read()
retire=[dict(path='finally-prefix-b819-20261116/representative.json',bytes=len(old_catalog),sha256=hashlib.sha256(old_catalog).hexdigest(),
    canonicalCommit=head,canonicalPath=canonical,member='procedure/catalog.json')]
'''+needle)
s=s.replace('identity=identity,retire=[],','identity=identity,retire=retire,')
s=s.replace("'lython-b821-fixtures'", "'lython-b823-fixtures'")
s=s.replace('datetime.timedelta(seconds=200)','datetime.timedelta(seconds=120)')
assert "jobs=[['scripts.text-normalization.large','warm'],['scripts.text-normalization.large','compile-run']]" in s
ast.parse(s);(r/'launch.py').write_text(s,encoding='utf-8',newline='\n')
print('Existing two-phase CPython comparison prepared, current committed810 source and exact archived historical catalog retirement.')
