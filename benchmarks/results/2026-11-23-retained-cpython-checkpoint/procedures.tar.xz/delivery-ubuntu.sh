#!/bin/bash
set -euo pipefail
cd /mnt/d/code/Lython
test "$(git rev-parse --short HEAD)" = 1b841b597
export DOTNET_ROOT="$HOME/.dotnet"
export PATH="$DOTNET_ROOT:$PATH"
export DOTNET_HOST_PATH="$DOTNET_ROOT/dotnet"
lab=/mnt/d/code/Lython/.git/agent-notes/review-20261031/direct-suite-bindings-20261123
filter='Category!=Stress&(FullyQualifiedName~Lexical|FullyQualifiedName~ScopeDirective|FullyQualifiedName~NameBinding|FullyQualifiedName~Dataclass|FullyQualifiedName~FunctionAttribute|FullyQualifiedName~CsvNativeInput)'
dotnet test tests/Lokad.Lython.Tests -c Release -f net10.0 --artifacts-path "$lab/delivery-ubuntu" --filter "$filter" > "$lab/delivery-white-ubuntu.log" 2>&1 || { tail -45 "$lab/delivery-white-ubuntu.log"; exit 1; }
dotnet test tests/Lokad.Lython.PublicApi.Tests -c Release -f net10.0 --artifacts-path "$lab/delivery-ubuntu" --filter "$filter" > "$lab/delivery-public-ubuntu.log" 2>&1 || { tail -45 "$lab/delivery-public-ubuntu.log"; exit 1; }
awk '/Passed!/{count++;print} END{exit count!=2}' "$lab/delivery-white-ubuntu.log" "$lab/delivery-public-ubuntu.log"

