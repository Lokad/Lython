
from pathlib import Path
import gzip
import hashlib
import io
import json
import os
import shutil
import subprocess
import tarfile

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
prior=lab.parent/"current-cpython-refresh-20261122"
csv=lab.parent/"direct-suite-bindings-20261123"
donor=lab.parent/"direct-single-def-default-20261123"/"comparison"/"quiet"
comparison=lab/"comparison"
quiet=comparison/"quiet"
quiet.mkdir(parents=True)
core="Lokad.Lython.dll"
def read(p):return json.loads(p.read_text(encoding="utf-8-sig"))
sha=lambda b:hashlib.sha256(b).hexdigest()
def h(p):return sha(p.read_bytes())
def git(*args):return subprocess.check_output(["git",*args],cwd=repo)
def write(p,s):
    if p.suffix==".py":compile(s,str(p),"exec")
    p.write_text(s,encoding="utf-8",newline="\n")
def save(p,o):write(p,json.dumps(o,ensure_ascii=False,indent=2)+"\n")
def committed(folder,leaf):return git("show",f"origin/master:benchmarks/results/{folder}/{leaf}")
def archived(folder):
    info=json.loads(committed(folder,"archive-receipt.json"))
    data=committed(folder,"observations.tgz")
    assert all(info[k] for k in ("complete","allWorkersJoined","archivedAndVerifiedUnderLease"))
    assert sha(data)==info["archiveSHA256"]
    return data,info["archiveSHA256"]

current=git("rev-parse","1b841b597").decode().strip()
assert git("rev-parse","HEAD").decode().startswith("61fdfe594") and not git("diff","--name-only",current,"HEAD","--","src","tests")
assert not git("diff","--name-only","6ac96ea93",current,"--","benchmarks/Lokad.Lython.Benchmarks","benchmarks/cpython-worker.py","src/Lokad.Lython.Utf8Regex")
prior_name="2026-11-22-callable-checkpoint-cpython"
raw,prior_digest=archived(prior_name)
past=json.loads(committed(prior_name,"source.json"))
catalog=quiet/"representative.json"
with tarfile.open(fileobj=io.BytesIO(raw))as t:
    catalog.write_bytes(t.extractfile("representative.json").read())
assert h(catalog)==past["catalogs"]["representative.json"]["sha256"]
assert len(read(catalog)["cases"])==6
sdk=Path.home()/".dotnet11"
dotnet=sdk/"dotnet.exe"
env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk),PATH=str(sdk)+os.pathsep+os.environ["PATH"])
protocol=repo/"benchmarks/cpython-worker.py"
assert h(protocol)==past["protocolSHA256"]
image=lab/"frozen"
image.mkdir()
worker="Lokad.Lython.Benchmarks.dll"
files=past["imageFiles"]["candidate"]
assert len(files)==32 and {n:h(prior/"frozen"/n)for n in files}==files
built=csv/"delivery-windows/bin/Lokad.Lython/release_net11.0"/core
assert "Passed!" in (csv/"delivery-white-windows.log").read_text(encoding="utf-8")
assert "Passed!" in (csv/"delivery-public-windows.log").read_text(encoding="utf-8")
for n in files:shutil.copyfile(built if n==core else prior/"frozen"/n,image/n)
new={**files,core:h(built)}
assert new=={n:h(image/n)for n in files} and new[core]!=files[core]
proof=lab/"verify.json"
subprocess.run([dotnet,image/worker,"--compare","verify","--catalog",catalog,"--dotnet",dotnet,
    "--python","C:/Python313/python.exe","--python-worker",protocol,"--out",proof],
    env=env,cwd=repo,check=True,timeout=90)
verify=read(proof)
assert verify["state"]=="Completed" and verify["caseCount"]==6 and verify["catalogSha256"]==h(catalog)
assert new=={n:h(image/n)for n in files}
previous=read(donor/"config.json")
latest="2026-11-23-singleton-positional-default"
_,donor_digest=archived(latest)
old=json.loads(committed(latest,"source.json"))
assert previous["identity"]["imageFiles"]==old["imageFiles"] and set(old["imageFiles"]["reference"])==set(new)
assert all(hval==new[name]for name,hval in old["imageFiles"]["reference"].items()if name!=core)
old_name=previous["root"].split("/")[-1]
retire=[]
for role in ("reference","candidate"):
    data=gzip.decompress(committed(latest,f"{role}-core.dll.gz"))
    assert sha(data)==old["imageFiles"][role][core] and sha(data)!=new[core]
    retire.append(dict(paths=[old_name+"/"+role+"/"+core],bytes=len(data),sha256=sha(data),links=1,
                       archives={old_name+"/observations.tgz":donor_digest}))
source=prior/"comparison/quiet"
old_run=read(source/"config.json")
assert old_run["identity"]["imageFiles"]["candidate"]==files
assert old_run["identity"]["catalogs"]["representative.json"]["sha256"]==h(catalog)
root="/home/lokad/lython-bench-checks/retained-current-cpython-b1429-20261123"
unit="lython-b1429-retained-current-cpython-20261123"
identity={**old_run["identity"],"sourceRevision":current,"candidate":current,
          "purpose":"Refresh the full representative checkpoint after CSV, function metadata and frontend delivery.",
          "imageFiles":{"candidate":new},"coreSHA256":{role:new[core]for role in ("candidate","candidate-control")},
          "auxiliaryFiles":{n:hval for n,hval in new.items()if n!=core},"B1419CatalogArchiveSHA256":prior_digest}
save(quiet/"identity.json",identity)
(quiet/"candidate").mkdir()
shutil.copyfile(built,quiet/"candidate"/core)
for name in ("collect.py","run.sh","archive-owned.py","retrieve.py"):
    s=(source/name).read_text(encoding="utf-8").replace(old_run["root"],root).replace(old_run["unit"],unit).replace("B1419","B1429")
    write(quiet/name,s)
assert b"\r" not in (quiet/"run.sh").read_bytes()
parts=("identity.json","representative.json","collect.py","run.sh","archive-owned.py","candidate/"+core)
payload=quiet/"payload.tgz"
with tarfile.open(payload,"w:gz")as t:
    for n in parts:t.add(quiet/n,arcname=n)
cfg={**old_run,"root":root,"unit":unit,"identity":identity,"source":previous["root"],"sourceRole":"reference",
     "sourceFiles":old["imageFiles"]["reference"],"sourceCatalogSHA256":old["catalogs"]["representative.json"]["sha256"],
     "donorArchiveSHA256":donor_digest,"retireGroups":retire,
     "payloadBytes":payload.stat().st_size,"payloadSHA256":h(payload),"unpackedBytes":sum((quiet/n).stat().st_size for n in parts)}
save(quiet/"config.json",cfg)
s=(source/"remote-launch.py").read_text(encoding="utf-8")
a,b=s.index("\nc=")+1,s.index("\nb=Path(")
write(quiet/"remote-launch.py",(s[:a]+"c="+repr(cfg)+s[b:]).replace("b1419-fixtures","b1429-fixtures"))
write(comparison/"launch.py",(prior/"comparison/launch.py").read_text(encoding="utf-8").replace("B1419","B1429"))
print(current,root,cfg["unpackedBytes"],flush=True)

