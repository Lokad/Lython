from pathlib import Path
import hashlib, json, tarfile

lab=Path('.git/agent-notes/review-20261031/lazy-positional-defaults')
reference=lab.parent/'report-cpython-checkpoint'
old=lab.parent/'utf8-expanded-format'
quiet=lab/'quiet'
quiet.mkdir(exist_ok=True)
read=lambda p:p.read_text(encoding='utf-8-sig')
load=lambda p:json.loads(read(p))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,s):
    p.write_text(s,encoding='utf-8',newline='\n')
    if p.suffix=='.py': compile(s,p,'exec')
old_config=load(old/'quiet/config.json')
donor=load(reference/'config.json')
donor_receipt=load(reference/'archive-recovery.json')
pair=load(lab/'frozen-identity.json')
assert donor_receipt['complete'] and donor_receipt['verifiedAfterCollectionUnderIdleLease']
assert sha(reference/'observations.tgz')==donor_receipt['archiveSHA256']
auxiliary={n:sha for n,sha in donor['identity']['imageFiles']['candidate'].items() if n!='Lokad.Lython.dll'}
assert all({n:sha for n,sha in files.items() if n!='Lokad.Lython.dll'}==auxiliary for files in pair['images'].values())
assert all(len(files)==32 and {n:sha(lab/'frozen'/role/n) for n in files}==files for role,files in pair['images'].items())
assert all(load(lab/f'{role}-verify.json')['catalogSha256']==pair['casesSHA256'] for role in pair['images'])
root='/home/lokad/lython-bench-checks/lazy-positional-defaults-b1174-20261120'
unit='lython-b1174-lazy-positional-defaults-20261120'
purpose='Positional defaults on observation'
core='Lokad.Lython.dll'
identity=dict(sourceRevision=pair['referenceCommit']+' versus '+pair['candidateCommit'],purpose=purpose,
    imageFiles=pair['images'],catalogSHA256=pair['casesSHA256'],normalAdapterPin='0.4.0',
    coreSHA256={label:files[core] for role,files in pair['images'].items() for label in (role,role+'-control')})
write(quiet/'identity.json',json.dumps(identity,indent=2)+'\n')
quiet.joinpath('representative.json').write_bytes((lab/'catalog.json').read_bytes())
worker=quiet/'cpython-worker.py'
worker.write_bytes(Path('benchmarks/cpython-worker.py').read_bytes())
assert sha(worker)==donor['cpythonWorkerSHA256']
for role in pair['images']:
    quiet.joinpath(role).mkdir(exist_ok=True)
    quiet.joinpath(role,core).write_bytes((lab/'frozen'/role/core).read_bytes())
jobs=[('scripts.rule-default-closures', 'warm'), ('scripts.annotated-rule-closures', 'warm'), ('scripts.annotated-rule-closures.nested-factories', 'warm'), ('scripts.rule-default-closures.observed', 'warm'), ('scripts.dataclass-inherited-configuration.generated', 'warm'), ('scripts.csv-invoice.large', 'warm'), ('scripts.rule-default-closures', 'compile-run')]
floor=168*1024*1024
prior_floor=168*1024*1024
archive_headroom=1310720
for name in ('collect.py','archive-owned.py','run.sh','retrieve.py'):
    s=read(old/'quiet'/name).replace(old_config['root'],root).replace(old_config['unit'],unit)
    s=s.replace('Native UTF-8 expanded format source pair',purpose).replace(str(prior_floor),str(floor))
    if name=='collect.py':
        a=s.index('\njobs = '); b=s.index('\nassert len(jobs)',a)
        s=s[:a]+'\njobs = '+repr(jobs)+s[b:]
    write(quiet/name,s.replace("==6 and", "==7 and").replace("jobs=6,", "jobs=7,").replace("['jobs']==6", "['jobs']==7"))
assert quiet.joinpath('run.sh').read_bytes().endswith(b'\n') and b'\r' not in quiet.joinpath('run.sh').read_bytes()
for name in ('launch-quiet.py','summarize-quiet.py'):
    s=read(old/name).replace('Native keyword snapshots source pair',purpose)
    write(lab/name,s.replace("seconds=355", "seconds=420").replace("before 355", "before 420")
        .replace("len(raw['jobs'])==6", "len(raw['jobs'])==7"))
parts=['identity.json','representative.json','cpython-worker.py','collect.py','archive-owned.py','run.sh','candidate/'+core,'reference/'+core]
payload=quiet/'payload.tgz'
with tarfile.open(payload,'w:gz') as archive:
    for name in parts: archive.add(quiet/name,arcname=name)
expanded=sum((quiet/n).stat().st_size for n in parts)
space=load(lab/'quiet-space.json')
observed=space['freeBytes']
selected=[]
for proof in space['replicas']:
    if observed>floor+expanded+archive_headroom+262144: break
    assert proof['committedBlobVerified'] and proof['sha256'] not in identity['coreSHA256'].values()
    observed += proof['bytes']
    selected.append(proof)
assert observed>floor+expanded+archive_headroom+262144,(observed,floor,expanded)
config=dict(root=root,unit=unit,source=donor['root'],sourceRole='candidate',sourceFiles=auxiliary,
    sourceCatalogSHA256=donor['catalogSHA256'],protocolSHA256=sha(worker),catalogSHA256=pair['casesSHA256'],identity=identity,
    retireGroups=selected,donorArchiveSHA256=donor_receipt['archiveSHA256'],payloadBytes=payload.stat().st_size,
    payloadSHA256=sha(payload),unpackedBytes=expanded)
write(quiet/'config.json',json.dumps(config,indent=2)+'\n')
s=read(old/'quiet/remote-launch.py')
a=s.index('\nc=')+1; b=s.index('\nb=Path(',a)
s=s[:a]+'c='+repr(config)+s[b:]
s=s.replace("source/'catalog.json'","source/'representative.json'").replace('lython-b1172-fixtures','lython-b1174-fixtures')
s=s.replace(str(prior_floor),str(floor))
write(quiet/'remote-launch.py',s)
print('Seven paired workload phases. Free space after staging and archive allowance:',observed-expanded-archive_headroom)
