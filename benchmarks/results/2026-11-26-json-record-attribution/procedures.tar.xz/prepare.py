from pathlib import Path
import hashlib
import json
import os
import subprocess
import tarfile

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
quiet = lab / "comparison/quiet"
quiet.mkdir(parents=True)
prior = lab.with_name("json-ready-construction-20261126")
donor = prior / "comparison/quiet"
template = lab.with_name("post-update-json-attribution-20261126")
base = json.loads((donor / "identity.json").read_text(encoding="utf-8"))
read = lambda path: json.loads(path.read_text(encoding="utf-8"))
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
write = lambda path, source: path.write_text(source, encoding="utf-8", newline="\n")
save = lambda path, value: write(path, json.dumps(value, ensure_ascii=False, indent=2) + "\n")
head = subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=repo, text=True).strip()
production = subprocess.check_output(["git", "rev-parse", "e222c5221"], cwd=repo, text=True).strip()
subprocess.run(["git", "diff", "--exit-code", production, "--", "src"], cwd=repo, check=True)
prior_patch = subprocess.check_output(
    ["git", "diff", "--binary", base["sourceRevision"], production, "--", "src"], cwd=repo
)
assert hashlib.sha256(prior_patch).hexdigest() == base["sourcePatchSHA256"]
receipt = read(donor / "terminal-status.json")["receipt"]
assert all(receipt[key] for key in ("complete", "allWorkersJoined", "quietBeforeAndAfter"))
assert sha(donor / "observations.tar.xz") == receipt["archiveSHA256"]
image = prior / "frozen/candidate"
files = base["imageFiles"]["candidate"]
assert len(files) == 32 and {p.name:sha(p) for p in image.iterdir()} == files
catalog = read(donor / "representative.json")
profiles = [["json-service-totals", "diagnostic.json-service-quantity-totals", "candidate"],
            ["json-lines-helpers", "scripts.json-summary-helpers.large", "candidate"]]
catalog["cases"] = [next(case for case in catalog["cases"] if case["id"] == name)
                    for label, name, role in profiles]
save(quiet / "catalog.json", catalog)
identity = dict(sourceRevision=production, inspectedHead=head, sourceDifference=[],
    imageFiles={"candidate":files}, coreSHA256={"candidate":files["Lokad.Lython.dll"]},
    donorArchiveSHA256=receipt["archiveSHA256"], profileCatalogSHA256=sha(quiet / "catalog.json"),
    profiles=profiles, purpose="Attribute current per-record construction and append costs after B1776.")
save(quiet / "identity.json", identity)

for name in ("collect.py", "ops-profile.py", "analyze.py", "run.sh"):
    source = (template / "comparison/quiet" / name).read_text(encoding="utf-8")
    source = source.replace("converted-dictionary-update-b1763-20261126", "ready-json-construction-b1776-20261126")
    source = source.replace("b1767-fixtures", "b1779-fixtures")
    if name.endswith(".py"):
        compile(source, name, "exec")
    write(quiet / name, source)
assert b"\r" not in (quiet / "run.sh").read_bytes()
source = (template / "quiet.py").read_text(encoding="utf-8")
source = source.replace("converted-dictionary-update-b1763-20261126", "ready-json-construction-b1776-20261126")
source = source.replace("lython-b1767-post-update-json-attribution-20261126", "lython-b1779-json-record-attribution-20261126")
compile(source, "quiet.py", "exec")
write(lab / "quiet.py", source)
source = (prior / "compact-for-quiet.py").read_text(encoding="utf-8")
assert source.count("2026-11-2*") == 1 and source.count("+5*1024*1024+512*1024") == 1
source = source.replace("2026-11-2*", "2026-11-*").replace("+5*1024*1024+512*1024", "+8*1024*1024")
compile(source, "compact-for-quiet.py", "exec")
write(lab / "compact-for-quiet.py", source)

worker = repo / "benchmarks/cpython-worker.py"
assert sha(worker) == base["cpythonWorkerSHA256"]
sdk = Path.home() / ".dotnet11"
dotnet = sdk / "dotnet.exe"
env = dict(os.environ, DOTNET_ROOT=str(sdk), DOTNET_ROOT_X64=str(sdk))
verification = quiet / "verification.json"
subprocess.run([dotnet, image / "Lokad.Lython.Benchmarks.dll", "--compare", "verify", "--catalog",
                quiet / "catalog.json", "--dotnet", dotnet, "--python", "C:/Python313/python.exe",
                "--python-worker", worker, "--out", verification],
               cwd=repo, env=env, check=True, timeout=70)
proof = read(verification)
assert proof["state"] == "Completed" and proof["caseCount"] == 2
assert proof["catalogSha256"] == identity["profileCatalogSHA256"]
assert proof["launched"]["library"]["sha256"] == files["Lokad.Lython.dll"]
payload = quiet / "stage.tar.gz"
entries = [quiet / name for name in ("identity.json", "catalog.json", "collect.py", "ops-profile.py", "run.sh")]
with tarfile.open(payload, "w:gz", compresslevel=6) as package:
    for path in entries:
        package.add(path, arcname=path.name, recursive=False)
save(quiet / "upload.json", dict(root="json-record-attribution-b1779-20261126", payloadSHA256=sha(payload),
    payloadBytes=payload.stat().st_size, expandedBytes=sum(p.stat().st_size for p in entries),
    expectedDonorArchiveSHA256=receipt["archiveSHA256"]))
