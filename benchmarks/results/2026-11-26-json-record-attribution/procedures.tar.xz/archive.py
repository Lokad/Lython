from pathlib import Path
from shutil import copyfile
import hashlib
import json
import tarfile

lab = Path(__file__).resolve().parent
quiet = lab / "comparison/quiet"
destination = lab.parents[3] / "benchmarks/results/2026-11-26-json-record-attribution"
destination.mkdir(exist_ok=True)
read = lambda path: json.loads(path.read_text(encoding="utf-8"))
status = read(quiet / "terminal-status.json")
receipt = status["receipt"]
assert status["exitCode"] == "0" and not status["live"] and not status["fixtures"]
assert all(receipt[key] for key in ("complete", "quietBeforeAndAfter", "allWorkersJoined",
                                   "guestFixturesRemoved", "archivedAndVerifiedUnderLease"))
assert hashlib.sha256((quiet / "observations.tar.xz").read_bytes()).hexdigest() == receipt["archiveSHA256"]
with tarfile.open(quiet / "observations.tar.xz") as observations:
    identity = json.load(observations.extractfile("identity.json"))
    assert identity == read(quiet / "identity.json")
    assert hashlib.sha256(observations.extractfile("catalog.json").read()).hexdigest() == identity["profileCatalogSHA256"]
assert len(read(quiet / "attribution.json")["rows"]) == 2
for name in ("observations.tar.xz", "identity.json", "attribution.json", "terminal-status.json"):
    copyfile(quiet / name, destination / name)
with tarfile.open(destination / "procedures.tar.xz", "w:xz") as archive:
    for name in ("archive.py", "prepare.py", "quiet.py", "compact-for-quiet.py", "launch-console.log",
                 "prepare.log", "retrieve.log", "analyze.log"):
        archive.add(lab / name, arcname=name, recursive=False)
    for name in ("verification.json", "launch.log", "analyze.py", "storage-profile-only-preview.log",
                 "storage-preview.log", "storage-compact.log", "upload.json"):
        archive.add(quiet / name, arcname=name, recursive=False)
