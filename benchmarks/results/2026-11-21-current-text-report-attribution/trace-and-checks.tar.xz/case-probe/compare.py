import collections,pathlib,sys,unicodedata
assert sys.version_info[:2]==(3,13) and unicodedata.unidata_version=='15.1.0'
p=pathlib.Path(__file__).resolve().parent
baseline={}
for line in (p/sys.argv[1]).read_text(encoding='utf-8-sig').splitlines():
 row=line.split(); baseline[int(row[0],16)]=tuple(bytes.fromhex(x).decode('utf-8') for x in row[1:])
names=('lower','upper','title','swapcase')
counts=collections.Counter(); differences=[]
for cp in range(128,0x110000):
 if 0xd800<=cp<=0xdfff:continue
 ch=chr(cp)
 expected=tuple(getattr(ch,name)() for name in names)
 actual=baseline.get(cp,(ch,)*4)
 for name,a,e in zip(names,actual,expected):
  if a!=e:
   counts[name]+=1
   differences.append(f'{cp:04X} {unicodedata.name(ch, "???")} {name}: {a.encode().hex()} -> {e.encode().hex()}')
print(dict(counts));print(*differences,sep='\n')
