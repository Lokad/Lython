using System;
using System.Text;
using Lokad.Lython.Runtime.Text;

for (var codepoint = 128; codepoint <= 0x10ffff; codepoint++)
{
    if (!Rune.TryCreate(codepoint, out var rune)) continue;
    var value = PyString.FromString(rune.ToString());
    var lower = PyStringOps.Lower(value);
    var upper = PyStringOps.Upper(value);
    var title = PyStringOps.Title(value);
    var swap = PyStringOps.SwapCase(value);
    if (lower.Equals(value) && upper.Equals(value) && title.Equals(value) && swap.Equals(value)) continue;
    Console.WriteLine($"{codepoint:x} {Convert.ToHexString(lower.Utf8Span)} {Convert.ToHexString(upper.Utf8Span)} {Convert.ToHexString(title.Utf8Span)} {Convert.ToHexString(swap.Utf8Span)}");
}
