import collections,json,pathlib
p=pathlib.Path(__file__).resolve().parent
raw=json.loads((p/'text-report.speedscope.json').read_text(encoding='utf-8-sig'))
frames=[x['name'] for x in raw['shared']['frames']]
core='Lokad.Lython!'
work='Lokad.Lython!Lokad.Lython.Runtime.LythonRuntime+ExecutionContext.Execute()'
report={}
for profile in raw['profiles']:
 stack=[];last=0;count=collections.Counter();leaves=collections.Counter();ancestry=collections.Counter()
 for event in profile['events']:
  at=event['at']; elapsed=at-last; last=at
  if elapsed and stack:
   count['total']+=elapsed
   if any(frame.startswith(work) for frame in stack):
    count['guest']+=elapsed
    methods=[frame.split('(',1)[0].removeprefix(core).removeprefix('Lokad.Lython.') for frame in stack if frame.startswith(core)]
    leaves[methods[-1]]+=elapsed
    for method in set(methods): ancestry[method]+=elapsed
  frame=frames[event['frame']]
  if event['type']=='O': stack.append(frame)
  else: assert stack.pop()==frame
 report[profile['name']]={'duration':dict(count),'nearest':dict(leaves.most_common()),'inclusive':dict(ancestry.most_common())}
(p/'summary.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
for thread,row in report.items():
 if 'guest' not in row['duration']: continue
 guest=row['duration']['guest']
 print(thread,'total',round(row['duration']['total'],1),'guest',round(guest,1))
 for group in ('nearest','inclusive'):
  print(group)
  for method,dt in list(row[group].items())[:18]: print(round(100*dt/guest,2),method)
