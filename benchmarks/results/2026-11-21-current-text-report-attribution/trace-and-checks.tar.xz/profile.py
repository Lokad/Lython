from pathlib import Path
import hashlib, importlib.util, json, os, shutil, subprocess, tempfile, time

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
donor=lab.parent/'parser-endpoint-spans'
catalog_source=lab.parent/'native-callback-entry/representative.json'
catalog=lab/'representative.json'
shutil.copyfile(catalog_source,catalog)
identity=json.loads((donor/'identity.json').read_text(encoding='utf-8'))
source_image=donor/'frozen/candidate'
image=lab/'image'
image.mkdir()
sha=lambda path:hashlib.sha256(path.read_bytes()).hexdigest()
files=identity['imageFiles']['candidate']
assert len(files)==32 and {n:sha(source_image/n) for n in files}==files
for name in files:
    shutil.copyfile(source_image/name,image/name)
assert {n:sha(image/n) for n in files}==files
worker_program=repo/'benchmarks/cpython-worker.py'
spec=importlib.util.spec_from_file_location('protocol',worker_program)
protocol=importlib.util.module_from_spec(spec)
spec.loader.exec_module(protocol)
selected='scripts.text-summary-helpers.map-callback.large'
case=next(c for c in json.loads(catalog.read_text(encoding='utf-8'))['cases'] if c['id']==selected)
sdk=Path.home()/'.dotnet11'
dotnet=sdk/'dotnet.exe'
trace=Path.home()/'.dotnet/tools/dotnet-trace.exe'
env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk),PATH=str(sdk)+os.pathsep+os.environ['PATH'])
worker=image/'Lokad.Lython.Benchmarks.dll'
with (lab/'catalog-check.json').open('wb') as log:
    verified=lab/'verified.json'
    subprocess.run([dotnet,worker,'--compare','verify','--catalog',catalog,'--dotnet',dotnet,
        '--python','C:/Python313/python.exe','--python-worker',worker_program,'--out',verified],
        stdout=log,stderr=subprocess.STDOUT,check=True,env=env,timeout=80)
    receipt=json.loads(verified.read_text(encoding='utf-8'))
    assert receipt['state']=='Completed' and receipt['catalogSha256']==sha(catalog)
profile=lab/'text-report.nettrace'
record=dict(source=identity['candidate'], retainedSource='d09acaf69', coreSHA256=files['Lokad.Lython.dll'],
            catalogSHA256=sha(catalog),imageFiles=files,case=selected,profile='dotnet-sampled-thread-time',
            boundary='Windows local attribution with verified warm report batches. Includes process host fixture, protocol, output checks and cleanup. Samples estimate managed thread residency.')
with tempfile.TemporaryDirectory(prefix='lython-comparison-files-') as folder, (lab/'worker.stderr').open('wb') as log:
    worker_process=subprocess.Popen([dotnet,worker,'--compare','worker','--catalog',catalog],cwd=folder,
                                       stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=log,env=env)
    profiler=None
    sequence=0
    def request(operation, count=2):
        global sequence
        sequence+=1
        data=dict(protocolVersion=protocol.PROTOCOL_VERSION,requestId=sequence,operation=operation)
        if operation!='quit':
            data.update(caseId=case['id'],lane='warm',iterations=count,**{k:case[k] for k in ('sourceSha256','fixtureSha256','expectedOutputSha256')})
        protocol.write_frame(worker_process.stdin,data)
        response=protocol.read_frame(worker_process.stdout)
        assert response['status']=={'verify':'Equivalent','batch':'Completed','quit':'Closed'}[operation],response
        assert response['requestId']==sequence
        if operation!='quit':
            assert response['completedInvocations']==count
            assert response['actualOutputSha256']==case['expectedOutputSha256'] and response.get('actualFilesSha256')==case.get('expectedFilesSha256')
        return response
    try:
        ready=protocol.read_frame(worker_process.stdout)
        assert ready['status']=='Ready' and ready['catalogSha256']==sha(catalog)
        loaded=next(lib for lib in ready['libraries'] if Path(lib['path']).name=='Lokad.Lython.dll')
        assert loaded['sha256'].lower()==files['Lokad.Lython.dll']
        record['verificationBefore']=request('verify')
        target=time.monotonic()+5
        while time.monotonic()<target: request('batch',256)
        with (lab/'collector.log').open('wb') as trace_log:
            profiler=subprocess.Popen([trace,'collect','--process-id',str(worker_process.pid),'--profile',
                'dotnet-sampled-thread-time','--duration','00:00:06','--format','Speedscope','--output',profile],
                env=env,stdout=trace_log,stderr=subprocess.STDOUT)
            record['batches']=[]
            expires=time.monotonic()+18
            while profiler.poll() is None and time.monotonic()<expires:
                record['batches'].append(request('batch',256))
            assert profiler.wait(timeout=3)==0 and len(record['batches'])>=2
        record['verificationAfter']=request('verify')
        request('quit')
        assert worker_process.wait(timeout=5)==0
        record['joined']=True
    finally:
        if profiler and profiler.poll() is None:
            profiler.terminate()
            profiler.wait(timeout=5)
        if worker_process.poll() is None:
            worker_process.kill()
            worker_process.wait(timeout=5)
        worker_process.stdin.close()
        worker_process.stdout.close()
assert {n:sha(image/n) for n in files}==files
record['traceSHA256']=sha(profile)
(lab/'profile.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8',newline='\n')
print(sum(row['completedInvocations'] for row in record['batches']),'verified complete text reports around the sample window')
