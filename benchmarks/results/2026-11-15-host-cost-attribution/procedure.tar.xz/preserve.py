import hashlib
import json
from pathlib import Path
import shutil
import tarfile

repo = Path(__file__).resolve().parents[4]
source = Path(__file__).resolve().parent
target = repo / 'benchmarks/results/2026-11-15-host-cost-attribution'
target.mkdir(exist_ok=False)
for name in ('identity.json', 'summary.json', 'archive-receipt.json', 'terminal-status.json', 'observations.tgz'):
    shutil.copyfile(source / name, target / name)
assert hashlib.sha256((target / 'observations.tgz').read_bytes()).hexdigest() == json.loads((target / 'archive-receipt.json').read_text(encoding='utf-8'))['archiveSHA256']
with tarfile.open(target / 'procedure.tar.xz', 'w:xz') as archive:
    for name in ('analyze.py', 'preserve.py', 'collect.py', 'run.sh', 'config.json', 'launch-command.py', 'launch.log',
                 'build.log', 'build-final.log', 'local-check.json', 'local-check.log', 'observation-20261115T121313Z.json',
                 'observe-not-before.json', 'receipt-normalized.json', 'tool/Program.cs', 'tool/HostTiming.cs', 'tool/HostCost.csproj'):
        archive.add(source / name, arcname=name, recursive=False)
    for name in ('launch-host-cost-r401.py', 'retrieve-host-cost-r401.py'):
        archive.add(source.parent / name, arcname=name, recursive=False)
print(target)
