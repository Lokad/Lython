"""Reproduce the host diagnostic summary; wall spans are not removable CPU."""
import json
from pathlib import Path
from statistics import median

root = Path(__file__).resolve().parent
raw = json.loads((root / 'retrieved/observation.json').read_text(encoding='utf-8'))
frequency = raw['frequency']
rows = []
for role in ('raw', 'forwarded', 'timed'):
    samples = [s for s in raw['samples'] if s['role'] == role]
    def micros(s, key):
        return s[key] * 1_000_000 / frequency / s['jobs']
    row = dict(role=role,
               runMicroseconds=median(micros(s, 'runTicks') for s in samples),
               cleanupMicroseconds=median(micros(s, 'cleanupTicks') for s in samples),
               fullMicroseconds=median(micros(s, 'completeJobTicks') for s in samples),
               wideCpuMicroseconds=median(s['processCpuMilliseconds'] * 1000 / s['jobs'] for s in samples),
               samples=[micros(s, 'runTicks') for s in samples])
    if role != 'raw':
        row['operations'] = []
        for op in samples[0]['host']:
            parts = [(s, next(p for p in s['host'] if p['operation'] == op['operation'])) for s in samples]
            if not any(p['calls'] for _, p in parts):
                continue
            row['operations'].append(dict(operation=op['operation'],
                callsPerRun=sorted({p['calls'] / s['jobs'] for s, p in parts}),
                microsecondsPerRun=median(p['ticks'] * 1_000_000 / frequency / s['jobs'] for s, p in parts)))
        row['totalHostMicroseconds'] = [sum(p['ticks'] for p in s['host']) * 1_000_000 / frequency / s['jobs'] for s in samples]
        row['medianHostMicroseconds'] = median(row['totalHostMicroseconds'])
        row['medianHostSharePercent'] = median(100 * sum(p['ticks'] for p in s['host']) / s['runTicks'] for s in samples)
    rows.append(row)
summary = dict(sourceRevision=raw['sourceRevision'], coreSHA256=raw['coreSHA256'], rows=rows,
    hostShareInTimedRunPercent=rows[2]['medianHostSharePercent'],
    forwardOnlyOverRawPercent=100 * (rows[1]['runMicroseconds'] / rows[0]['runMicroseconds'] - 1),
    timedOverRawPercent=100 * (rows[2]['runMicroseconds'] / rows[0]['runMicroseconds'] - 1),
    performanceComparison=False)
(root / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n', encoding='utf-8')
print(json.dumps({k:v for k,v in summary.items() if k != 'rows'}, indent=2))
