from pathlib import Path
import ast,base64,datetime,hashlib,json,subprocess,tarfile
base=Path(__file__).parent;r=base/'host-cost-r401'
identity=json.loads((r/'identity.json').read_text(encoding='utf-8'))
old=json.loads((base/'tuple-transport-r397/quiet/identity.json').read_text(encoding='utf-8'))
assert all(hashlib.sha256((r/'image'/n).read_bytes()).hexdigest()==h for n,h in identity['files'].items())
tools=['HostCost.dll','HostCost.deps.json','HostCost.runtimeconfig.json']
run='''from pathlib import Path
import fcntl,hashlib,json,os,shutil,subprocess,tarfile,time
root=Path('/home/lokad/lython-bench-checks/host-cost-b786-20261115')
dotnet='/home/lokad/lython-bench-toolchains/dotnet/11.0.100-rc.3.26522.148/dotnet'
env=os.environ.copy();env['DOTNET_ROOT']=str(Path(dotnet).parent);env['TMPDIR']=str(root/'guest-fixtures')
assert not any(k.startswith(('DOTNET_','COMPlus_'))and k!='DOTNET_ROOT'for k in env)
with(root.parent/'comparison-vm.lock').open('a')as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 identity=json.loads((root/'identity.json').read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
 for n,h in identity['vmFiles'].items():assert sha(root/'candidate'/n)==h
 assert sha(root/'catalog.json')==identity['catalogSHA256']
 time.sleep(3)
 subprocess.run([dotnet,str(root/'candidate/Lokad.Lython.Benchmarks.dll'),'--compare','check-machine','--out',str(root/'machine-before.json')],env=env,check=True)
 assert json.loads((root/'machine-before.json').read_text())['gate']['quiet']
 started=time.monotonic()
 with(root/'driver.log').open('w')as log:
  process=subprocess.run([dotnet,str(root/'candidate/HostCost.dll'),str(root/'candidate'),str(root/'catalog.json'),str(root/'observation.json')],env=env,stdout=log,stderr=subprocess.STDOUT,timeout=90)
 assert process.returncode==0,(root/'driver.log').read_text()
 data=json.loads((root/'observation.json').read_text());assert data['allGoldensPassed']and data['allBalancesZero']and data['allFixturesRemoved']and data['normalGc']
 assert data['coreSHA256']==identity['coreSHA256']and data['catalogSHA256']==identity['catalogSHA256']
 time.sleep(3)
 subprocess.run([dotnet,str(root/'candidate/Lokad.Lython.Benchmarks.dll'),'--compare','check-machine','--out',str(root/'machine-after.json')],env=env,check=True)
 assert json.loads((root/'machine-after.json').read_text())['gate']['quiet']
 assert subprocess.run(['pgrep','-af','[d]otnet.*HostCost.dll|[d]otnet.* --compare worker'],capture_output=True).returncode==1
 assert not list((root/'guest-fixtures').iterdir())
 with tarfile.open(root/'observations.tgz','w:gz')as archive:
  for name in ['identity.json','observation.json','driver.log','collect.py','run.sh','machine-before.json','machine-after.json']:archive.add(root/name,arcname=name)
 with tarfile.open(root/'observations.tgz')as archive:assert archive.extractfile('observation.json').read()==(root/'observation.json').read_bytes()
 assert shutil.disk_usage(root).free>252*1024*1024
 subprocess.run(['sudo','-n','umount',str(root/'guest-fixtures')],check=True);(root/'guest-fixtures').rmdir()
 receipt=dict(complete=True,elapsedSeconds=time.monotonic()-started,allActualUsersJoined=True,allGoldensAndBalancesPassed=True,guestFixturesRemoved=True,quietBeforeAndAfter=True,archivedAndVerifiedUnderLease=True,archiveSHA256=sha(root/'observations.tgz'),freeBytes=shutil.disk_usage(root).free,performanceComparison=False)
 (root/'archive-receipt.json').write_text(json.dumps(receipt,indent=2)+'\\n');print(json.dumps(receipt))
'''
ast.parse(run);(r/'collect.py').write_text(run,encoding='utf-8',newline='\n')
(r/'run.sh').write_text('set -eu\nroot=/home/lokad/lython-bench-checks/host-cost-b786-20261115\ntrap \'result=$?; printf "%s\\n" "$result" > "$root/exit-code.txt"\' EXIT\npython3 "$root/collect.py"\n',encoding='utf-8',newline='\n')
identity['vmFiles']={**old['auxiliaryFiles'],'Lokad.Lython.dll':identity['coreSHA256'],**{n:identity['files'][n]for n in tools}}
(r/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8',newline='\n')
with tarfile.open(r/'payload.tgz','w:gz')as a:
    for n in ['identity.json','collect.py','run.sh']:a.add(r/n,arcname=n)
    for n in tools:a.add(r/'image'/n,arcname='candidate/'+n)
with tarfile.open(r/'payload.tgz')as a:unpacked=sum(m.size for m in a.getmembers())
config=dict(root='/home/lokad/lython-bench-checks/host-cost-b786-20261115',source='/home/lokad/lython-bench-checks/tuple-transport-b782-20261115',unit='lython-b786-host-cost-20261115',identity=identity,payloadBytes=(r/'payload.tgz').stat().st_size,payloadSHA256=hashlib.sha256((r/'payload.tgz').read_bytes()).hexdigest(),unpackedBytes=unpacked)
code='''from pathlib import Path
import fcntl,hashlib,io,json,os,shutil,subprocess,sys,tarfile
config=CONFIG
base=Path('/home/lokad/lython-bench-checks').resolve();root=Path(config['root']);source=Path(config['source']);sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert root.parent==base and not root.exists()and source.parent==base and source.resolve()==source
with(base/'comparison-vm.lock').open('a')as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record|[d]otnet.*HostCost.dll|[p]ython3.*cpython-worker.py'],capture_output=True).returncode==1
 assert not any(os.path.ismount(p)for p in base.glob('*/guest-fixtures'))
 state=subprocess.check_output(['systemctl','show',config['unit']+'.service','--property=LoadState,MainPID'],text=True);assert 'LoadState=not-found'in state and 'MainPID=0'in state
 assert shutil.disk_usage(base).free>254*1024*1024+config['unpackedBytes']+65536
 for name,h in config['identity']['vmFiles'].items():
  if not name.startswith('HostCost'):assert sha(source/'candidate'/name)==h
 assert sha(source/'representative.json')==config['identity']['catalogSHA256']
 payload=sys.stdin.buffer.read(config['payloadBytes']+1);assert len(payload)==config['payloadBytes']and hashlib.sha256(payload).hexdigest()==config['payloadSHA256']
 root.mkdir()
 with tarfile.open(fileobj=io.BytesIO(payload),mode='r:gz')as a:a.extractall(root,filter='data')
 for name in config['identity']['vmFiles']:
  if not name.startswith('HostCost'):os.link(source/'candidate'/name,root/'candidate'/name)
 os.link(source/'representative.json',root/'catalog.json')
 assert shutil.disk_usage(base).free>254*1024*1024
 fixture=root/'guest-fixtures';fixture.mkdir()
 subprocess.run(['sudo','-n','mount','-t','tmpfs','-o','size=128m,mode=0700,uid=lokad,gid=lokad','lython-b786-fixtures',str(fixture)],check=True)
try:subprocess.run(['sudo','-n','systemd-run','--unit='+config['unit'],'--property=User=lokad','--property=WorkingDirectory='+str(root),'--property=RuntimeMaxSec=120','--property=TimeoutStopSec=30','--property=KillMode=control-group','/bin/sh',str(root/'run.sh')],check=True)
except BaseException:
 subprocess.run(['sudo','-n','umount',str(fixture)],check=True);fixture.rmdir();raise
print(subprocess.check_output(['systemctl','show',config['unit']+'.service','--property=ActiveState,MainPID,RuntimeMaxUSec'],text=True))
'''.replace('CONFIG',repr(config))
ast.parse(code);(r/'launch-command.py').write_text(code,encoding='utf-8',newline='\n');(r/'config.json').write_text(json.dumps(config,indent=2)+'\n',encoding='utf-8',newline='\n')
command="python3 -c 'import base64;exec(base64.b64decode(\""+base64.b64encode(code.encode()).decode()+"\"))'"
p=subprocess.run(['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73',command],input=(r/'payload.tgz').read_bytes(),capture_output=True,timeout=30)
(r/'launch.log').write_bytes(p.stdout+p.stderr);assert p.returncode==0,(p.stdout+p.stderr).decode()
now=datetime.datetime.now(datetime.timezone.utc);(r/'observe-not-before.json').write_text(json.dumps(dict(startedUTC=now.isoformat(),doNotObserveBeforeUTC=(now+datetime.timedelta(seconds=45)).isoformat(),ownerSeconds=120),indent=2)+'\n',encoding='utf-8',newline='\n')
print((p.stdout+p.stderr).decode(),flush=True);print('Observe same owned unit after',(now+datetime.timedelta(seconds=45)).isoformat(),flush=True)
