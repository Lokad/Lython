from pathlib import Path
import fcntl,hashlib,json,os,shutil,subprocess,tarfile,time
root=Path('/home/lokad/lython-bench-checks/host-cost-b786-20261115')
dotnet='/home/lokad/lython-bench-toolchains/dotnet/11.0.100-rc.3.26522.148/dotnet'
env=os.environ.copy();env['DOTNET_ROOT']=str(Path(dotnet).parent);env['TMPDIR']=str(root/'guest-fixtures')
assert not any(k.startswith(('DOTNET_','COMPlus_'))and k!='DOTNET_ROOT'for k in env)
with(root.parent/'comparison-vm.lock').open('a')as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 identity=json.loads((root/'identity.json').read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
 for n,h in identity['vmFiles'].items():assert sha(root/'candidate'/n)==h
 assert sha(root/'catalog.json')==identity['catalogSHA256']
 time.sleep(3)
 subprocess.run([dotnet,str(root/'candidate/Lokad.Lython.Benchmarks.dll'),'--compare','check-machine','--out',str(root/'machine-before.json')],env=env,check=True)
 assert json.loads((root/'machine-before.json').read_text())['gate']['quiet']
 started=time.monotonic()
 with(root/'driver.log').open('w')as log:
  process=subprocess.run([dotnet,str(root/'candidate/HostCost.dll'),str(root/'candidate'),str(root/'catalog.json'),str(root/'observation.json')],env=env,stdout=log,stderr=subprocess.STDOUT,timeout=90)
 assert process.returncode==0,(root/'driver.log').read_text()
 data=json.loads((root/'observation.json').read_text());assert data['allGoldensPassed']and data['allBalancesZero']and data['allFixturesRemoved']and data['normalGc']
 assert data['coreSHA256']==identity['coreSHA256']and data['catalogSHA256']==identity['catalogSHA256']
 time.sleep(3)
 subprocess.run([dotnet,str(root/'candidate/Lokad.Lython.Benchmarks.dll'),'--compare','check-machine','--out',str(root/'machine-after.json')],env=env,check=True)
 assert json.loads((root/'machine-after.json').read_text())['gate']['quiet']
 assert subprocess.run(['pgrep','-af','[d]otnet.*HostCost.dll|[d]otnet.* --compare worker'],capture_output=True).returncode==1
 assert not list((root/'guest-fixtures').iterdir())
 with tarfile.open(root/'observations.tgz','w:gz')as archive:
  for name in ['identity.json','observation.json','driver.log','collect.py','run.sh','machine-before.json','machine-after.json']:archive.add(root/name,arcname=name)
 with tarfile.open(root/'observations.tgz')as archive:assert archive.extractfile('observation.json').read()==(root/'observation.json').read_bytes()
 assert shutil.disk_usage(root).free>252*1024*1024
 subprocess.run(['sudo','-n','umount',str(root/'guest-fixtures')],check=True);(root/'guest-fixtures').rmdir()
 receipt=dict(complete=True,elapsedSeconds=time.monotonic()-started,allActualUsersJoined=True,allGoldensAndBalancesPassed=True,guestFixturesRemoved=True,quietBeforeAndAfter=True,archivedAndVerifiedUnderLease=True,archiveSHA256=sha(root/'observations.tgz'),freeBytes=shutil.disk_usage(root).free,performanceComparison=False)
 (root/'archive-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt))
