import hashlib
import json
from pathlib import Path
import re
import tarfile

repo = Path(__file__).resolve().parents[4]
root = repo / 'benchmarks/results/2026-11-15-host-cost-attribution'
for name in ('identity.json','summary.json','archive-receipt.json','terminal-status.json','source-map.json'):
    json.loads((root/name).read_text(encoding='utf-8'))
with tarfile.open(root/'observations.tgz') as archive:
    names=archive.getnames()
    observation=[n for n in names if n.rsplit('/',1)[-1]=='observation.json']
    assert len(observation)==1
    data=json.load(archive.extractfile(observation[0]))
    assert data['allGoldensPassed'] and data['allBalancesZero'] and data['allFixturesRemoved']
    assert len(data['samples'])==15
    assert {s['jobs'] for s in data['samples']}=={256}
receipt=json.loads((root/'archive-receipt.json').read_text(encoding='utf-8'))
assert receipt['archiveSHA256']==hashlib.sha256((root/'observations.tgz').read_bytes()).hexdigest()
assert all(receipt[k] for k in ('complete','allActualUsersJoined','allGoldensAndBalancesPassed','guestFixturesRemoved','quietBeforeAndAfter','archivedAndVerifiedUnderLease'))
for target in re.findall(r'\]\(([^)]+)\)', (root/'README.md').read_text(encoding='utf-8')):
    assert (root/target.split('#')[0]).exists(), target
with tarfile.open(root/'procedure.tar.xz') as procedure:
    assert {'analyze.py','source-map.py','verify.py','tool/HostTiming.cs','tool/Program.cs'} <= set(procedure.getnames())
print('All 15 sample blocks, archive SHA, source-map JSON, custody gates and README links pass.')
