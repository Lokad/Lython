import hashlib
import json
from pathlib import Path
import subprocess

repo = Path(__file__).resolve().parents[4]
facts = {
    'src/Lokad.Lython/Public/LythonMemoryBudget.cs': 'One shared State.Gate; scope and reservation balances share it.',
    'src/Lokad.Lython/Runtime/MemoryGovernor.cs': 'Single ownership reservation; existing one-idle invocation workspace cache.',
    'src/Lokad.Lython/Frontend/ExecutableScript.cs': 'Compact instruction record reuses primary/secondary operands and result/live fields.',
    'src/Lokad.Lython/Runtime/LythonRuntime.Executable.Interpreter.Dispatch.cs': 'Ordinary dispatch reads instructions ref readonly.',
    'src/Lokad.Lython/Runtime/LythonRuntime.Executable.NativePrefix.cs': 'Native dispatch reads ref readonly; child calls recurse through StartNativeCall and preserve exact transfer state.',
    'src/Lokad.Lython/Runtime/LythonRuntime.StringMembers.cs': 'Default affix bounds are byte-span boundaries; no scalar-count pass.',
    'src/Lokad.Lython/Runtime/LythonRuntime.ExecutionContext.Builtins.cs': 'Plain builtin definitions and immutable signatures already shared.',
    'src/Lokad.Lython/Runtime/LythonRuntime.Json.Construction.cs': 'One iterative construction loop with continuation only for actual pending callbacks.',
    'src/Lokad.Lython/Runtime/PyExecutableFunction.cs': 'Fixed sixteen-slot prefix; direct binding; separate function entry, completion and transfer shell.',
    'src/Lokad.Lython/Runtime/LythonRuntime.Calls.Binding.cs': 'Binding fills final slots; pooled arrays already cover larger/suspended calls.',
}
entries = []
for name, fact in facts.items():
    work = (repo / name).read_bytes().replace(b'\r\n', b'\n')
    committed = subprocess.check_output(['git', 'show', f'51e3c2c1:{name}'], cwd=repo).replace(b'\r\n', b'\n')
    assert work == committed, name
    entries.append(dict(path=name, normalizedSHA256=hashlib.sha256(work).hexdigest(), fact=fact))
target = repo / 'benchmarks/results/2026-11-15-host-cost-attribution/source-map.json'
target.write_text(json.dumps(dict(sourceRevision='51e3c2c1', normalization='CRLF to LF only', entries=entries), indent=2)+'\n', encoding='utf-8')
print(f'{len(entries)} committed source inputs verified')
