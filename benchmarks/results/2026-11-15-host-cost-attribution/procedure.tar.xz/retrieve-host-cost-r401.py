from pathlib import Path
import base64,datetime,hashlib,json,subprocess,tarfile
r=Path(__file__).parent/'host-cost-r401';c=json.loads((r/'config.json').read_text(encoding='utf-8'))
assert not(r/'terminal-status.json').exists(),'Terminal cached; never requery'
code='''from pathlib import Path
import fcntl,json,subprocess
c=CONFIG;root=Path(c['root'])
p=subprocess.run(['systemctl','show',c['unit']+'.service','--property=ActiveState,SubState,MainPID,Result,ExecMainStatus'],capture_output=True,text=True)
if 'ActiveState=active'in p.stdout:print(json.dumps(dict(live=True,service=p.stdout)));raise SystemExit(0)
with(root.parent/'comparison-vm.lock').open('a')as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 receipt=(root/'archive-receipt.json').read_text()if(root/'archive-receipt.json').exists()else None
 print(json.dumps(dict(live=False,service=p.stdout,exitCode=(root/'exit-code.txt').read_text().strip()if(root/'exit-code.txt').exists()else None,receiptText=receipt,remainingWorkers=subprocess.run(['pgrep','-af','[d]otnet.*HostCost.dll|[d]otnet.* --compare worker|[p]erf record'],capture_output=True,text=True).stdout,remainingTrace=(root/'guest-fixtures').exists(),journal=subprocess.run(['journalctl','-u',c['unit']+'.service','-n','10','--no-pager'],capture_output=True,text=True).stdout)))
'''.replace('CONFIG',repr(c))
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
p=subprocess.run(ssh+['python3 -'],input=code,capture_output=True,text=True,encoding='utf-8',timeout=30);assert p.returncode==0,p.stderr
x=json.loads(p.stdout);(r/('observation-'+datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%SZ')+'.json')).write_text(p.stdout,encoding='utf-8',newline='\n');print(p.stdout,flush=True)
if x['live']:raise SystemExit(0)
assert x['exitCode']=='0' and not x['remainingWorkers'] and not x['remainingTrace']
try:receipt=json.loads(x['receiptText'])
except json.JSONDecodeError:
    assert x['receiptText'].endswith('\\n');receipt=json.loads(x['receiptText'][:-2])
    (r/'receipt-format-correction.json').write_text(json.dumps(dict(originalPreserved=True,reason='Receipt ended in literal backslash-n, not whitespace; payload unchanged, no recapture'),indent=2)+'\n',encoding='utf-8',newline='\n')
assert receipt['complete']and receipt['allActualUsersJoined']and receipt['allGoldensAndBalancesPassed']and receipt['guestFixturesRemoved']
x['receipt']=receipt
(r/'terminal-status.json').write_text(json.dumps(x,indent=2)+'\n',encoding='utf-8',newline='\n')
scp=['C:/Windows/System32/OpenSSH/scp.exe','-i',ssh[2],'-o','BatchMode=yes','-o','ConnectTimeout=15']
for name in ['observations.tgz','archive-receipt.json']:
    p=subprocess.run(scp+['lokad@20.166.121.73:'+c['root']+'/'+name,str(r/name)],capture_output=True,timeout=30);assert p.returncode==0,p.stderr
assert hashlib.sha256((r/'observations.tgz').read_bytes()).hexdigest()==receipt['archiveSHA256']
(r/'receipt-normalized.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8',newline='\n')
with tarfile.open(r/'observations.tgz')as a:a.extractall(r/'retrieved',filter='data')
print('One raw/forwarded/timed diagnostic complete; image and archive verified, all users joined and fixtures removed')
