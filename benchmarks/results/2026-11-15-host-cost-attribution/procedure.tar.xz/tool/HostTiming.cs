using System.Diagnostics;
using Lokad.Lython;

enum HostOperation { Cwd, LocalNow, UtcNow, Open, Position, Length, Read, Write, Flush, Dispose, Rewind, ReadableLength, ReadAt }

sealed class HostTiming(bool timed)
{
    internal readonly long[] Calls = new long[Enum.GetValues<HostOperation>().Length];
    internal readonly long[] Ticks = new long[Enum.GetValues<HostOperation>().Length];
    internal bool Capture;
    internal long Start(HostOperation op)
    {
        if (!Capture) return 0;
        Calls[(int)op]++;
        return timed ? Stopwatch.GetTimestamp() : 0;
    }
    internal void End(HostOperation op, long start)
    {
        if (start != 0) Ticks[(int)op] += Stopwatch.GetTimestamp() - start;
    }
    internal void Reset() { Array.Clear(Calls); Array.Clear(Ticks); }
    internal ValueTask<T> Complete<T>(ValueTask<T> pending, HostOperation op, long start)
    {
        if (!Capture) return pending;
        if (pending.IsCompletedSuccessfully)
        {
            var result = pending.Result;
            End(op, start);
            return ValueTask.FromResult(result);
        }
        return Await(pending, op, start);
    }
    private async ValueTask<T> Await<T>(ValueTask<T> pending, HostOperation op, long start)
    {
        try { return await pending.ConfigureAwait(false); }
        finally { End(op, start); }
    }
    internal ValueTask Complete(ValueTask pending, HostOperation op, long start)
    {
        if (!Capture) return pending;
        if (pending.IsCompletedSuccessfully)
        {
            pending.GetAwaiter().GetResult(); End(op, start);
            return ValueTask.CompletedTask;
        }
        return Await(pending, op, start);
    }
    private async ValueTask Await(ValueTask pending, HostOperation op, long start)
    {
        try { await pending.ConfigureAwait(false); }
        finally { End(op, start); }
    }
}

sealed class ForwardHost(ILythonHost inner, HostTiming timing) : ILythonHost, ILythonSynchronousHostCapability
{
    public bool CompletesSynchronously => inner is ILythonSynchronousHostCapability sync && sync.CompletesSynchronously;
    public string Cwd { get { var s=timing.Start(HostOperation.Cwd); try{return inner.Cwd;}finally{timing.End(HostOperation.Cwd,s);} } }
    public DateTimeOffset LocalNow { get { var s=timing.Start(HostOperation.LocalNow); try{return inner.LocalNow;}finally{timing.End(HostOperation.LocalNow,s);} } }
    public DateTimeOffset UtcNow { get { var s=timing.Start(HostOperation.UtcNow); try{return inner.UtcNow;}finally{timing.End(HostOperation.UtcNow,s);} } }
    public ILythonTextInput? StandardInput => inner.StandardInput;
    public ILythonTextOutput? StandardOutput => inner.StandardOutput;
    public ILythonTextOutput? StandardError => inner.StandardError;
    public ILythonSubprocessRunner? SubprocessRunner => inner.SubprocessRunner;
    public ILythonTiming? Timing => inner.Timing;

    public ValueTask<ILythonByteFile> OpenFileAsync(LythonPathRequest path, LythonFileOpenOptions options, ILythonMemoryBudget budget, CancellationToken token)
    {
        var start=timing.Start(HostOperation.Open);
        ValueTask<ILythonByteFile> pending;
        try { pending=inner.OpenFileAsync(path,options,budget,token); }
        catch { timing.End(HostOperation.Open,start); throw; }
        if (pending.IsCompletedSuccessfully)
        {
            var file=pending.Result; timing.End(HostOperation.Open,start);
            return ValueTask.FromResult(Wrap(file));
        }
        return FinishOpen(pending,start);
    }
    private async ValueTask<ILythonByteFile> FinishOpen(ValueTask<ILythonByteFile> pending,long start)
    {
        ILythonByteFile file;
        try { file=await pending.ConfigureAwait(false); }
        finally { timing.End(HostOperation.Open,start); }
        return Wrap(file);
    }
    private ILythonByteFile Wrap(ILythonByteFile file) => file is ILythonPositionalByteFile positional
        ? new ForwardPositionalFile(positional,timing) : new ForwardFile(file,timing);

    public ValueTask<bool> ExistsAsync(LythonPathRequest p,CancellationToken t)=>inner.ExistsAsync(p,t);
    public ValueTask<IReadOnlyList<string>> ListDirAsync(LythonPathRequest p,CancellationToken t)=>inner.ListDirAsync(p,t);
    public ValueTask MkDirAsync(LythonPathRequest p,CancellationToken t)=>inner.MkDirAsync(p,t);
    public ValueTask RemoveAsync(LythonPathRequest p,CancellationToken t)=>inner.RemoveAsync(p,t);
    public ValueTask RemoveFileAsync(LythonPathRequest p,bool missingOk,CancellationToken t)=>inner.RemoveFileAsync(p,missingOk,t);
    public ValueTask RemoveDirectoryAsync(LythonPathRequest p,CancellationToken t)=>inner.RemoveDirectoryAsync(p,t);
    public ValueTask ReplaceAsync(LythonPathRequest s,LythonPathRequest d,CancellationToken t)=>inner.ReplaceAsync(s,d,t);
    public ValueTask CopyAsync(LythonPathRequest s,LythonPathRequest d,CancellationToken t)=>inner.CopyAsync(s,d,t);
    public ValueTask MoveAsync(LythonPathRequest s,LythonPathRequest d,CancellationToken t)=>inner.MoveAsync(s,d,t);
    public ValueTask<LythonPathStat> StatAsync(LythonPathRequest p,CancellationToken t)=>inner.StatAsync(p,t);
}

class ForwardFile(ILythonByteFile inner, HostTiming timing) : ILythonByteFile, ILythonSynchronousHostCapability
{
    protected ILythonByteFile Inner => inner;
    protected HostTiming Metrics => timing;
    public bool CompletesSynchronously=>inner is ILythonSynchronousHostCapability sync && sync.CompletesSynchronously;
    public long Position {get{var s=timing.Start(HostOperation.Position);try{return inner.Position;}finally{timing.End(HostOperation.Position,s);}}}
    public long? LengthHint {get{var s=timing.Start(HostOperation.Length);try{return inner.LengthHint;}finally{timing.End(HostOperation.Length,s);}}}
    public ValueTask<int> ReadAsync(Memory<byte> buffer,CancellationToken token)
    {
        var s=timing.Start(HostOperation.Read);
        try{return timing.Complete(inner.ReadAsync(buffer,token),HostOperation.Read,s);}
        catch{timing.End(HostOperation.Read,s);throw;}
    }
    public ValueTask<LythonFileWriteResult> WriteAsync(ReadOnlyMemory<byte> buffer,CancellationToken token)
    {
        var s=timing.Start(HostOperation.Write);
        try{return timing.Complete(inner.WriteAsync(buffer,token),HostOperation.Write,s);}
        catch{timing.End(HostOperation.Write,s);throw;}
    }
    public ValueTask FlushAsync(CancellationToken token)
    {
        var s=timing.Start(HostOperation.Flush);
        try{return timing.Complete(inner.FlushAsync(token),HostOperation.Flush,s);}
        catch{timing.End(HostOperation.Flush,s);throw;}
    }
    public ValueTask DisposeAsync()
    {
        var s=timing.Start(HostOperation.Dispose);
        try{return timing.Complete(inner.DisposeAsync(),HostOperation.Dispose,s);}
        catch{timing.End(HostOperation.Dispose,s);throw;}
    }
    public ValueTask RewindAndTruncateAsync(CancellationToken token)
    {
        var s=timing.Start(HostOperation.Rewind);
        try{return timing.Complete(inner.RewindAndTruncateAsync(token),HostOperation.Rewind,s);}
        catch{timing.End(HostOperation.Rewind,s);throw;}
    }
}

sealed class ForwardPositionalFile(ILythonPositionalByteFile inner,HostTiming timing) : ForwardFile(inner,timing),ILythonPositionalByteFile
{
    private ILythonPositionalByteFile Positional => (ILythonPositionalByteFile)Inner;
    public long ReadableLength{get{var s=Metrics.Start(HostOperation.ReadableLength);try{return Positional.ReadableLength;}finally{Metrics.End(HostOperation.ReadableLength,s);}}}
    public ValueTask<int> ReadAtAsync(long offset,Memory<byte> buffer,CancellationToken token)
    {
        var s=Metrics.Start(HostOperation.ReadAt);
        try{return Metrics.Complete(Positional.ReadAtAsync(offset,buffer,token),HostOperation.ReadAt,s);}
        catch{Metrics.End(HostOperation.ReadAt,s);throw;}
    }
}
