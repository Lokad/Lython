using System.Diagnostics;
using System.Reflection;
using System.Security.Cryptography;
using System.Text.Json;
using Lokad.Lython;
using Lokad.Lython.Utf8Regex;

var image=Path.GetFullPath(args[0]);
using var catalog=JsonDocument.Parse(File.ReadAllBytes(args[1]));
var item=catalog.RootElement.GetProperty("cases").EnumerateArray().Single(x=>x.GetProperty("id").GetString()=="scripts.file-search.large.protected");
const BindingFlags flags=BindingFlags.Public|BindingFlags.NonPublic|BindingFlags.Static|BindingFlags.Instance;
var assembly=Assembly.LoadFrom(Path.Combine(image,"Lokad.Lython.Benchmarks.dll"));
var fixtureType=assembly.GetType("Lokad.Lython.Benchmarks.Comparison.ComparisonFileFixture",true)!;
var hostType=assembly.GetType("Lokad.Lython.Benchmarks.Comparison.ComparisonFileHost",true)!;
var fixture=fixtureType.GetMethod("Parse",flags)!.Invoke(null,[item.GetProperty("fixtureJson").GetString()])!;
var reset=hostType.GetMethod("Reset",flags)!;var outputs=hostType.GetMethod("ReadOutputs",flags)!;
var budget=new LythonMemoryBudget();
using var script=new LythonEngine(Utf8RegexProvider.Instance).Compile(item.GetProperty("source").GetString()!,budget);
if(!script.IsValid)throw new InvalidDataException(string.Join(";",script.Diagnostics));
var baseline=budget.ReservedBytes;
var roles=new List<Role>();var samples=new List<object>();
try
{
    foreach(var name in new[]{"raw","forwarded","timed"})
    {
        var path=Path.Combine(Path.GetTempPath(),"lython-comparison-files-"+Guid.NewGuid().ToString("N"));
        var host=(ILythonHost)Activator.CreateInstance(hostType,flags,null,[fixture,path],null)!;
        var timing=new HostTiming(name=="timed");
        roles.Add(new(name,path,host,name=="raw"?host:new ForwardHost(host,timing),timing));
    }
    foreach(var role in roles)
    {
        var warm=Stopwatch.StartNew();
        do{Once(role);}while(warm.Elapsed.TotalSeconds<5);
    }
    for(var round=0;round<5;round++)for(var offset=0;offset<3;offset++)
    {
        var role=roles[(round+offset)%3];role.Timing.Reset();role.Timing.Capture=true;
        long runTicks=0,cleanupTicks=0;
        var allocated=GC.GetTotalAllocatedBytes(precise:true);
        var cpu=Process.GetCurrentProcess().TotalProcessorTime;
        var full=Stopwatch.StartNew();
        for(var i=0;i<256;i++){var elapsed=Once(role);runTicks+=elapsed.Run;cleanupTicks+=elapsed.Cleanup;}
        full.Stop();role.Timing.Capture=false;
        samples.Add(new{round,role=role.Name,jobs=256,runTicks,cleanupTicks,completeJobTicks=full.ElapsedTicks,processCpuMilliseconds=(Process.GetCurrentProcess().TotalProcessorTime-cpu).TotalMilliseconds,allocatedBytes=GC.GetTotalAllocatedBytes(precise:true)-allocated,host=Enum.GetValues<HostOperation>().Select(op=>new{operation=op.ToString(),calls=role.Timing.Calls[(int)op],ticks=role.Timing.Ticks[(int)op]}).ToArray()});
    }
    script.Dispose();if(budget.ReservedBytes!=0)throw new InvalidDataException("Compiled owner did not end.");
}
finally
{
    foreach(var role in roles)
    {
        (role.Raw as IDisposable)?.Dispose();
        var path=Path.GetFullPath(role.Path);
        if(Path.GetDirectoryName(path)!=Path.GetFullPath(Path.GetTempPath()).TrimEnd(Path.DirectorySeparatorChar)||!Path.GetFileName(path).StartsWith("lython-comparison-files-",StringComparison.Ordinal))throw new InvalidDataException("Unexpected owned fixture.");
        if(Directory.Exists(path))Directory.Delete(path,true);
    }
}
File.WriteAllText(args[2],JsonSerializer.Serialize(new{sourceRevision="51e3c2c1",coreSHA256=Convert.ToHexStringLower(SHA256.HashData(File.ReadAllBytes(typeof(LythonEngine).Assembly.Location))),catalogSHA256=Convert.ToHexStringLower(SHA256.HashData(File.ReadAllBytes(args[1]))),runtime=System.Runtime.InteropServices.RuntimeInformation.FrameworkDescription,frequency=Stopwatch.Frequency,rounds=5,batch=256,warmupFullRequestSecondsPerRole=5,samples,allGoldensPassed=true,allBalancesZero=true,allFixturesRemoved=true,normalGc= !System.Runtime.GCSettings.IsServerGC,performanceComparison=false,boundary="Diagnostic same-process raw/forwarded/timed public Run. Run ticks exclude fixture reset/goldens/result disposal; cleanup is separate; completeJob includes them. Actual host spans are inside instrumented Run, not removable CPU or isolated interpreter time; forwarding/counting/timer overhead stays visible."},new JsonSerializerOptions{WriteIndented=true}));
Console.WriteLine("Complete host attribution; raw/forwarded/timed controls, goldens, budget reuse and fixture cleanup pass.");

(long Run,long Cleanup) Once(Role role)
{
    reset.Invoke(role.Raw,null);
    var started=Stopwatch.GetTimestamp();
    var result=script.Run(role.Active);
    var run=Stopwatch.GetTimestamp()-started;
    long cleanup;
    try
    {
        if(!result.Success||result.StandardOutput!=item.GetProperty("expectedOutput").GetString()||result.StandardError!="")throw new InvalidDataException(result.Failure?.Message??result.StandardOutput);
        outputs.Invoke(role.Raw,null);
    }
    finally{started=Stopwatch.GetTimestamp();result.Dispose();cleanup=Stopwatch.GetTimestamp()-started;}
    if(budget.ReservedBytes!=baseline)throw new InvalidDataException("Execution owner did not end.");
    return(run,cleanup);
}

sealed record Role(string Name,string Path,ILythonHost Raw,ILythonHost Active,HostTiming Timing);
