from pathlib import Path
p=Path('src/Lokad.Lython/Runtime/LythonRuntime.Executable.Calls.cs');s=p.read_text(encoding='utf-8')
s=s.replace('        private PyExecutableFunction? _pendingFunction;\n        private object? _pendingReceiver;\n','')
a=s.index('        public void Execute()');b=s.index('        private bool TrySuspendForExecutableCall',a)
s=s[:a]+'''        public void Execute()
        {
            ExecutionContext? current = this;
            while (current is not null)
            {
                Exception? failure = null;
                ExecutionContext? child = null;
                try { child = current.ExecuteUntilCall(); }
                catch (Exception error) { failure = error; }
                current = child ?? CompleteCallFrame(current, failure);
            }
        }

        public async ValueTask ExecuteAsync()
        {
            ExecutionContext? current = this;
            while (current is not null)
            {
                Exception? failure = null;
                ExecutionContext? child = null;
                try { child = await current.ExecuteUntilCallAsync().ConfigureAwait(false); }
                catch (Exception error) { failure = error; }
                current = child ?? CompleteCallFrame(current, failure);
            }
        }

''' +s[b:]
s=s.replace('private bool TrySuspendForExecutableCall(ExecutableCallSite site, int start, object target)', 'private bool TryBeginExecutableCall(ExecutableCallSite site, int start, object target,\n            bool asynchronous, out ValueTask<ExecutionContext?> next)')
s=s.replace('            if (target is PyType type) return TrySuspendForExecutableConstructor(type, site, start);', '            next = default;\n            if (target is PyType type) return TryBeginExecutableConstructor(type, site, start, asynchronous, out next);')
a=s.index('            _pendingCallSite = site;',s.index('private bool TryBeginExecutableCall'));b=s.index('\n        // Type subscription',a)
s=s[:a]+'''            next = BeginFunctionCall(function, receiver, site, start, site.CallSpan,
                CallCompletion.Call, asynchronous);
            return true;
        }

        private bool TryBeginExecutableConstructor(PyType type, ExecutableCallSite site, int start,
            bool asynchronous, out ValueTask<ExecutionContext?> next)
        {
            next = default;
            if (!type.CanPrepareExecutableConstructor) return false;
            EnterInterpreterFrame(site.CallSpan);
            var transferred = false;
            try
            {
                var instance = new PyInstance(type, MemoryGovernor, site.CallSpan);
                CheckExecution(site.CallSpan);
                _preparedCallValue = instance;
                // Admission may change live metadata. Continue the generic init
                // stage on this same instance when it no longer fits the runner.
                if (!type.TryGetExecutableInitializer(out var initialize)) return false;
                transferred = true; // The call entry owns admission even on failure.
                next = BeginFunctionCall(initialize, instance, site, start, site.CallSpan,
                    CallCompletion.Constructor, asynchronous, callEntered: true);
                return true;
            }
            finally { if (!transferred) LeaveInterpreterFrame(); }
        }
''' +s[b:]
s=s.replace('private bool TrySuspendForTypeSubscription(in ExecutableInstruction instruction, object receiver, object key)', 'private bool TryBeginTypeSubscription(in ExecutableInstruction instruction, object receiver, object key,\n            bool asynchronous, out ValueTask<ExecutionContext?> next)')
s=s.replace('            var start = instruction.ResultSlot;\n            if (_preparedCallValue', '            next = default;\n            var start = instruction.ResultSlot;\n            if (_preparedCallValue',1)
s=s.replace('                if (!TryPrepareSubscriptionCallable(prepared, instruction.Span, start)) return false;\n                _preparedCallValue = null;\n                return true;', '                return TryBeginSubscriptionCallable(prepared, instruction.Span, start, asynchronous, out next);')
a=s.index('                _pendingFunction = function;');b=s.index('\n            }',a)
s=s[:a]+'''                next = BeginFunctionCall(function, descriptor, null, start, instruction.Span,
                    CallCompletion.TypeGetter, asynchronous);
                return true;''' +s[b:]
s=s.replace('            if (TryPrepareSubscriptionCallable(member, instruction.Span, start)) return true;', '            if (TryBeginSubscriptionCallable(member, instruction.Span, start, asynchronous, out next)) return true;')
s=s.replace('private bool TryPrepareSubscriptionCallable(object callable, LythonSourceSpan span, int start)', 'private bool TryBeginSubscriptionCallable(object callable, LythonSourceSpan span, int start,\n            bool asynchronous, out ValueTask<ExecutionContext?> next)')
s=s.replace('            var function = callable as PyExecutableFunction;', '            next = default;\n            var function = callable as PyExecutableFunction;',1)
a=s.index('            _pendingFunction = function;');b=s.index('\n        private ValueTask<object> InvokePreparedTypeSubscription',a)
s=s[:a]+'''            _preparedCallValue = null;
            next = BeginFunctionCall(function, receiver, null, start, span,
                CallCompletion.TypeSubscription, asynchronous);
            return true;
        }
''' +s[b:]
s=s.replace('private static ExecutionContext? AdvanceCallFrames(ExecutionContext current, Exception? failure,\n            bool asynchronous, out ValueTask<ExecutionContext?> pending)\n        {\n            pending = default;\n            if (failure is null && current._pendingFunction is not null)\n            {\n                try { return current.BeginPendingCall(asynchronous, out pending); }\n                catch (Exception error) { current.CompletePendingCall(null, error); return current; }\n            }', 'private static ExecutionContext? CompleteCallFrame(ExecutionContext current, Exception? failure)\n        {')
a=s.index('        private ExecutionContext? BeginPendingCall');b=s.index('        // Binding locals own this descriptor',a)
s=s[:a]+'''        // Binding is prepared at the call instruction, rather than staged on
        // the caller and replayed by the frame driver. A completed body publishes
        // only after its binding/work/admission cleanup has finished.
        private ValueTask<ExecutionContext?> BeginFunctionCall(PyExecutableFunction function, object? receiver,
            ExecutableCallSite? site, int start, LythonSourceSpan span, CallCompletion completion,
            bool asynchronous, bool callEntered = false)
        {
            var ordinaryCall = site is not null;
            var argumentStart = ordinaryCall ? start + site!.ArgumentOffset
                : start + (completion == CallCompletion.TypeGetter ? 2 : 1);
            var argumentCount = ordinaryCall ? site!.ArgumentCount
                : completion == CallCompletion.TypeGetter ? 2 : 1;
            var prepared = false;
            try
            {
                if (ordinaryCall && !callEntered)
                {
                    EnterInterpreterFrame(span);
                    callEntered = true;
                }
                CheckExecution(span);
                var operands = _execution.Stack.Slice(argumentStart, argumentCount).Span;
                var positional = !ordinaryCall || site!.IsPositionalOnly && function.SupportsDirectPositional;
                var nativeAttempted = ordinaryCall && positional && function.CanBorrowPositionalArguments(argumentCount, receiver);
                if (positional)
                {
                    var bound = function.BindPositionalOperands(operands, span, this, receiver);
                    prepared = true;
                    return new(BeginBoundCall(function, bound, site, start, span, completion, callEntered, nativeAttempted));
                }
                if (!asynchronous)
                {
                    var bound = function.BindCallOperands(operands, span, this, receiver, site!);
                    prepared = true;
                    return new(BeginBoundCall(function, bound, site, start, span, completion, callEntered, nativeAttempted: false));
                }
                var binding = function.BindCallOperandsAsync(operands, span, this, receiver, site!);
                if (!binding.IsCompleted)
                {
                    prepared = true;
                    return AwaitPendingBinding(binding, function, site, start, span, completion, callEntered);
                }
                var supplied = binding.GetAwaiter().GetResult();
                prepared = true;
                return new(BeginBoundCall(function, supplied, site, start, span, completion, callEntered, nativeAttempted: false));
            }
            catch (Exception error)
            {
                if (TryTranslateCallableException(error, span, out var translated)) error = translated;
                ApplyCallResult(start, span, completion, null, error);
                return new(this);
            }
            finally { if (!prepared && callEntered) LeaveInterpreterFrame(); }
        }

        private async ValueTask<ExecutionContext?> AwaitPendingBinding(ValueTask<BoundCallArguments> binding,
            PyExecutableFunction function, ExecutableCallSite? site, int start, LythonSourceSpan span,
            CallCompletion completion, bool callEntered)
        {
            var prepared = false;
            try
            {
                var bound = await binding.ConfigureAwait(false);
                prepared = true;
                return BeginBoundCall(function, bound, site, start, span, completion, callEntered, nativeAttempted: false);
            }
            catch (Exception error)
            {
                if (TryTranslateCallableException(error, span, out var translated)) error = translated;
                ApplyCallResult(start, span, completion, null, error);
                return this;
            }
            finally { if (!prepared && callEntered) LeaveInterpreterFrame(); }
        }

''' +s[b:]
s=s.replace('private ExecutionContext BeginBoundCall(in BoundCallArguments bound, bool callEntered, bool nativeAttempted)\n        {\n            var function = _pendingFunction!;\n            var span = PendingCallSpan;\n            var consumedByIteration = _callCompletion == CallCompletion.Call && _pendingCallSite is { } site\n                && CallResultConsumedByIteration(in _execution, site);', 'private ExecutionContext BeginBoundCall(PyExecutableFunction function, in BoundCallArguments bound,\n            ExecutableCallSite? site, int start, LythonSourceSpan span, CallCompletion completion,\n            bool callEntered, bool nativeAttempted)\n        {\n            var consumedByIteration = completion == CallCompletion.Call && site is not null\n                && CallResultConsumedByIteration(in _execution, site);\n            object? completedValue = null;')
s=s.replace('                    CompletePendingCall(nativeValue, null);\n                    return this;', '                    completedValue = nativeValue;\n                    goto Completed;')
s=s.replace('                        CompletePendingCall(work.ReturnValue ?? PyNone.Instance, null);\n                        return this;', '                        completedValue = work.ReturnValue ?? PyNone.Instance;\n                        goto Completed;')
s=s.replace('ExecuteInstructionPrefix(ref work, scope, null, false, out _, out _)', 'ExecuteInstructionPrefix(ref work, scope, null, false, out _, out _, out _)')
s=s.replace('                        CompletePendingCall(value, null);\n                        return this;', '                        completedValue = value;\n                        goto Completed;')
s=s.replace('                frame._caller = this;', '''                // Only a real child establishes a suspended caller. No reverse
                // link or preparation packet is needed for completed prefixes.
                _pendingCallSite = site;
                _protocolCallSpan = site is null ? span : null;
                _pendingCallStart = start;
                _callCompletion = completion;
                frame._caller = this;''')
s=s.replace('                CompletePendingCall(null, error);\n                return this;', '                ExceptionDispatchInfo.Throw(error);\n                throw;')
needle='''            }
        }

        private void CloseInvocation'''
assert needle in s;s=s.replace(needle,'''            }
        Completed:
            ApplyCallResult(start, span, completion, completedValue, null);
            return this;
        }

        private void CloseInvocation''',1)
s=s.replace('            _pendingFunction = null;\n            _pendingReceiver = null;\n','')
s=s.replace('            if (_pendingFunction is not null) throw new InvalidOperationException("Executable call has not completed.");\n','')
needle='''            _completedCallError = null;
            if (completion == CallCompletion.Constructor)'''
assert needle in s;s=s.replace(needle,'''            _completedCallError = null;
            try { ApplyCallResult(start, span, completion, value, failure); }
            catch (LythonRuntimeException error) { _injectedException = error; }
        }

        private void ApplyCallResult(int start, LythonSourceSpan span, CallCompletion completion,
            object? value, Exception? failure)
        {
            if (completion == CallCompletion.Constructor)''')
s=s.replace('''            if (completion == CallCompletion.TypeSubscription) CheckExecution(span);
                if (failure is not null)
            {
                _execution.Stack.RetireTo(start);
                if (failure is LythonRuntimeException runtimeError) _injectedException = runtimeError;
                else ExceptionDispatchInfo.Throw(failure);
            }''','''            if (completion == CallCompletion.TypeSubscription) CheckExecution(span);
            if (failure is not null)
            {
                _execution.Stack.RetireTo(start);
                ExceptionDispatchInfo.Throw(failure);
            }''')
assert '_pendingFunction'not in s and '_pendingReceiver'not in s and 'BeginPendingCall'not in s
p.write_text(s,encoding='utf-8')
print('Call preparation now direct; removed pending function/receiver and runner preparation stage. Drivers next.')
