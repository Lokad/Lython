from pathlib import Path
p=Path('src/Lokad.Lython/Runtime/LythonRuntime.Executable.Calls.cs');s=p.read_text(encoding='utf-8')
s=s.replace('''            catch (Exception error)
            {
                if (TryTranslateCallableException(error, span, out var translated)) error = translated;
                ApplyCallResult(start, span, completion, null, error);''','''            catch (Exception error)
            {
                if (prepared) throw; // Bound execution already owns postprocessing.
                if (TryTranslateCallableException(error, span, out var translated)) error = translated;
                ApplyCallResult(start, span, completion, null, error);''')
s=s.replace('            object? completedValue = null;','            object? completedValue = null;\n            Exception? completedError = null;')
s=s.replace('                ExceptionDispatchInfo.Throw(error);\n                throw;','                completedError = error;')
s=s.replace('ApplyCallResult(start, span, completion, completedValue, null);','ApplyCallResult(start, span, completion, completedValue, completedError);')
p.write_text(s,encoding='utf-8')
p=Path('src/Lokad.Lython/Runtime/LythonRuntime.Executable.Interpreter.Dispatch.cs');s=p.read_text(encoding='utf-8');s=s.replace('Continue, Boundary, Operation, Disposal, ContextRequired','Continue, Boundary, Call, Operation, Disposal, ContextRequired')
s=s.replace('bool asynchronous, out ValueTask<bool> pending, out LythonSourceSpan? pendingSpan)', 'bool asynchronous, out ValueTask<bool> pending, out LythonSourceSpan? pendingSpan,\n            out ValueTask<ExecutionContext?> nextCall)')
s=s.replace('            pending = default;\n            pendingSpan = default;','            pending = default;\n            pendingSpan = default;\n            nextCall = default;',1)
s=s.replace('asynchronous, out pending, out pendingSpan)', 'asynchronous, out pending, out pendingSpan, out nextCall)')
old='                            if (invocation!.TrySuspendForExecutableCall(call, callStart, target)) return InstructionPause.Boundary;'
new='''                            if (invocation!.TryBeginExecutableCall(call, callStart, target, asynchronous, out nextCall))
                            {
                                if (!nextCall.IsCompletedSuccessfully || !ReferenceEquals(nextCall.Result, invocation))
                                    return InstructionPause.Call;
                                nextCall = default;
                                // Completed calls already published after cleanup.
                                jumped = true;
                                break;
                            }'''
assert old in s;s=s.replace(old,new);p.write_text(s,encoding='utf-8')
p=Path('src/Lokad.Lython/Runtime/LythonRuntime.Executable.Inputs.cs');s=p.read_text(encoding='utf-8');s=s.replace('out ValueTask<bool> pending, out LythonSourceSpan? pendingSpan)', 'out ValueTask<bool> pending, out LythonSourceSpan? pendingSpan,\n            out ValueTask<ExecutionContext?> nextCall)');s=s.replace('            pendingSpan = null;','            pendingSpan = null;\n            nextCall = default;',1)
s=s.replace('invocation.TrySuspendForTypeSubscription(instruction, first, second!))','invocation.TryBeginTypeSubscription(instruction, first, second!, asynchronous, out nextCall))')
s=s.replace('''                    return InstructionPause.Boundary;
                }
                if (immediate)''','''                    return InstructionPause.Call;
                }
                if (immediate)''')
p.write_text(s,encoding='utf-8')
p=Path('src/Lokad.Lython/Runtime/LythonRuntime.Executable.Interpreter.Sync.cs');s=p.read_text(encoding='utf-8');s=s.replace('private void ExecuteUntilCall()', 'private ExecutionContext? ExecuteUntilCall()')
s=s.replace('                _ = ExecuteInstructionPrefix(ref _execution, this, this, false, out _, out _);','''                while (true)
                {
                    var pause = ExecuteInstructionPrefix(ref _execution, this, this, false, out _, out _, out var nextCall);
                    if (pause != InstructionPause.Call) return null;
                    var child = nextCall.GetAwaiter().GetResult();
                    if (!ReferenceEquals(child, this)) return child;
                }''')
p.write_text(s,encoding='utf-8')
p=Path('src/Lokad.Lython/Runtime/LythonRuntime.Executable.Interpreter.cs');s=p.read_text(encoding='utf-8');s=s.replace('            _pendingFunction = null;\n            _pendingReceiver = null;\n','')
s=s.replace('private async ValueTask ExecuteUntilCallAsync()', 'private async ValueTask<ExecutionContext?> ExecuteUntilCallAsync()')
s=s.replace('ExecuteInstructionPrefix(ref _execution, this, this, true, out var pending, out var span)', 'ExecuteInstructionPrefix(ref _execution, this, this, true, out var pending, out var span, out var nextCall)')
s=s.replace('''                    if (pause == InstructionPause.Boundary) return;
                    var jumped = false;
                    if (pause == InstructionPause.Operation)''','''                    if (pause == InstructionPause.Boundary) return null;
                    var jumped = false;
                    if (pause == InstructionPause.Call)
                    {
                        var callSpan = _execution.Code.Instructions[_execution.InstructionIndex].Span;
                        try
                        {
                            var child = nextCall.IsCompletedSuccessfully ? nextCall.Result : await nextCall.ConfigureAwait(false);
                            if (!ReferenceEquals(child, this)) return child;
                            jumped = true; // The call published and advanced its opcode.
                        }
                        catch (ReturnSignal signal)
                        {
                            if (!TryRouteReturn(signal, callSpan)) return null;
                            jumped = true;
                        }
                        catch (ControlSignal signal)
                        {
                            if (!TryRouteControl(signal, callSpan)) throw;
                            jumped = true;
                        }
                        catch (LythonRuntimeException error)
                        {
                            if (!TryRouteRuntimeException(error, callSpan)) throw;
                            jumped = true;
                        }
                        finally { nextCall = default; }
                    }
                    else if (pause == InstructionPause.Operation)''')
a=s.index('        private async ValueTask<ExecutionContext?> ExecuteUntilCallAsync()');prefix=s[:a];tail=s[a:];tail=tail.replace('if (!TryRouteReturn(signal, operationSpan)) return;', 'if (!TryRouteReturn(signal, operationSpan)) return null;').replace('if (_execution.ReturnValue is not null || HasYield) return;', 'if (_execution.ReturnValue is not null || HasYield) return null;');s=prefix+tail;p.write_text(s,encoding='utf-8')
print('Existing sync/async drivers consume real call transitions; no new persistent call owner or dispatcher.')
