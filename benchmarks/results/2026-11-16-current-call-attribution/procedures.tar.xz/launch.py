from pathlib import Path
import ast,datetime,hashlib,io,json,shlex,subprocess,tarfile
r=Path(__file__).parent;q=r/'profile';identity=json.loads((q/'identity.json').read_text(encoding='utf-8'));proof=json.loads((r/'historical-aliases.json').read_text(encoding='utf-8'));custody=proof['custody'];raw=Path(custody['archive']).read_bytes();assert subprocess.check_output(['git','show',custody['commit']+':'+custody['archive']])==raw
with tarfile.open(fileobj=io.BytesIO(raw)) as a:core=a.extractfile(custody['member']).read()
assert hashlib.sha256(raw).hexdigest()==custody['archiveSHA256'] and hashlib.sha256(core).hexdigest()==proof['sha256'] and len(core)==proof['bytes']
with tarfile.open(q/'payload.tgz','w:gz') as a:
 for n in ['identity.json','ops-profile.py','collect.py','run.sh']:a.add(q/n,arcname=n)
with tarfile.open(q/'payload.tgz') as a:unpacked=sum(m.size for m in a if m.isfile())
files=dict(identity['auxiliaryFiles']);files['Lokad.Lython.dll']=identity['coreSHA256']['candidate']
c=dict(root='/home/lokad/lython-bench-checks/current-calls-b815-20261115',unit='lython-b815-current-calls-20261115',source='/home/lokad/lython-bench-checks/format-operation-b814-20261115',sourceFiles=files,sourceCatalogSHA256=identity['catalogSHA256'],identity=identity,retireGroups=[proof],payloadBytes=(q/'payload.tgz').stat().st_size,payloadSHA256=hashlib.sha256((q/'payload.tgz').read_bytes()).hexdigest(),unpackedBytes=unpacked)
(q/'config.json').write_text(json.dumps(c,indent=2)+'\n',encoding='utf-8',newline='\n')
s=(r.parent/'format-operation-r419/quiet/remote-launch.py').read_text(encoding='utf-8');tree=ast.parse(s);n=next(n for n in tree.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='c' for t in n.targets));lines=s.splitlines(keepends=True);s=''.join(lines[:n.lineno-1])+'c='+repr(c)+'\n'+''.join(lines[n.end_lineno:])
s=s.replace(" assert sha(source/'representative.json')==c['sourceCatalogSHA256']"," assert sha(source/'additional.json')==c['sourceCatalogSHA256']\n assert json.loads((source/'archive-receipt.json').read_text())['allWorkersJoined']")
a=s.index(" for role in ['reference','candidate']:");b=s.index(' subprocess.run([\'/bin/sh\'',a)
s=s[:a]+''' (root/'candidate').mkdir()
 for n,h in c['sourceFiles'].items():os.link(source/'candidate'/n,root/'candidate'/n);assert sha(root/'candidate'/n)==h,n
 os.link(source/'additional.json',root/'catalog.json');assert sha(root/'catalog.json')==c['identity']['catalogSHA256']
 for n in ['collect.py','ops-profile.py']:ast.parse((root/n).read_text())
'''+s[b:]
s=s.replace('254*1024*1024+c[\'unpackedBytes\']+65536','max(254*1024*1024,252*1024*1024+2621440)+c[\'unpackedBytes\']+65536').replace('free>254*1024*1024','free>max(254*1024*1024,252*1024*1024+2621440)').replace('size=32m','size=128m').replace('lython-b809-fixtures','lython-b815-fixtures').replace('RuntimeMaxSec=240','RuntimeMaxSec=120')
ast.parse(s);(q/'launch-command.py').write_text(s,encoding='utf-8',newline='\n')
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73'];done=subprocess.run(ssh+['python3 -c '+shlex.quote(s)],input=(q/'payload.tgz').read_bytes(),capture_output=True,timeout=45);(q/'launch.log').write_bytes(done.stdout+done.stderr);assert done.returncode==0,done.stdout+done.stderr
now=datetime.datetime.now(datetime.timezone.utc);(q/'observe-not-before.json').write_text(json.dumps(dict(launchedUTC=now.isoformat(),doNotObserveBeforeUTC=(now+datetime.timedelta(seconds=75)).isoformat()),indent=2)+'\n',encoding='utf-8',newline='\n');print(done.stdout.decode('utf-8'))
