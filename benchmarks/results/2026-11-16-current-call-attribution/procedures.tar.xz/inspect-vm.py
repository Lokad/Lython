from pathlib import Path
import hashlib,io,json,shlex,subprocess,tarfile
r=Path(__file__).parent;head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();archive='benchmarks/results/2026-11-15-method-format-layout/source-checks-and-procedure.tar.xz';raw=Path(archive).read_bytes();assert subprocess.check_output(['git','show',head+':'+archive])==raw
member='frozen/reference/Lokad.Lython.dll'
with tarfile.open(fileobj=io.BytesIO(raw)) as a:core=a.extractfile(member).read()
sha=hashlib.sha256(core).hexdigest();assert sha=='8afb146e835dcd2692150026e4beb6566b2a483349b2a8b5c24b5e6eba58e6ed'
s=(r.parent/'format-sinks-r416/inspect-vm.py').read_text(encoding='utf-8').replace('arithmetic-b790-20261115/candidate','format-layout-b812-20261115/reference').replace('9e890d187e5ff2af2b335b1e7dfe0cf1edd9de6a55b389bef1df6e469993e7f8',sha)
(r/'inspect-vm-generated.py').write_text(s,encoding='utf-8',newline='\n');p=subprocess.run(['C:/Python313/python.exe','-X','utf8',str(r/'inspect-vm-generated.py')],capture_output=True,timeout=45);assert p.returncode==0,p.stderr
v=json.loads((r/'historical-aliases.json').read_text(encoding='utf-8'));assert v['sha256']==sha and v['bytes']==len(core)
v['custody']=dict(commit=head,archive=archive,archiveSHA256=hashlib.sha256(raw).hexdigest(),member=member)
(r/'historical-aliases.json').write_text(json.dumps(v,indent=2)+'\n',encoding='utf-8',newline='\n');print(json.dumps(v))
