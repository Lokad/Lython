from pathlib import Path
import ast,hashlib,json,shutil
r=Path(__file__).parent;q=r/'profile';q.mkdir();old=r.parent/'format-program-r417/profile';base=r.parent/'format-operation-r419'
catalog=base/'quiet/retrieved/additional.json';assert len(json.loads(catalog.read_text(encoding='utf-8'))['cases'])==1
shutil.copyfile(catalog,q/'catalog.json');v=json.loads((base/'quiet/identity.json').read_text(encoding='utf-8'));image=v['imageFiles']['candidate']
identity=dict(sourceRevision='c023042d/frozen0393331a',runtimeCommit='c023042d',purpose='R420 one bounded complete method-report CPU capture after layout/executor consolidation. Select a whole call/frame/operand displacement or state unresolved cost; no source speedup/removable-share claim.',coreSHA256=dict(candidate=image['Lokad.Lython.dll']),auxiliaryFiles={n:h for n,h in image.items() if n!='Lokad.Lython.dll'},catalogSHA256=hashlib.sha256(catalog.read_bytes()).hexdigest(),qualification='6internal/691public actual11/10;595source inputs/deletions verified, full43774159426active',publicationHeld=True)
(q/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8',newline='\n')
for n in ['ops-profile.py','collect.py','run.sh','retrieve.py']:
 s=(old/n).read_text(encoding='utf-8').replace('format-program-b811-20261115','current-calls-b815-20261115').replace('lython-b811-format-program-20261115','lython-b815-current-calls-20261115').replace('B811','B815')
 s=s.replace('Qualifiedb06b8593/frozen8afb146e; R417 method-format report attribution','Committedc023042d/frozen0393331a; R420 current complete method-report call attribution')
 if n.endswith('.py'):ast.parse(s)
 (q/n).write_text(s,encoding='utf-8',newline='\n')
s=(r.parent/'format-program-r417/inspect.py').read_text(encoding='utf-8').replace("r.parent/'format-sinks-r416/frozen/candidate/Lokad.Lython.dll'","r.parent/'format-operation-r419/frozen/candidate/Lokad.Lython.dll'").replace('8afb146e835dcd2692150026e4beb6566b2a483349b2a8b5c24b5e6eba58e6ed',image['Lokad.Lython.dll']).replace("r.parent/'format-sinks-r416/catalog.json'","r.parent/'format-operation-r419/catalog.json'")
(r/'inspect-facts.py').write_text(s,encoding='utf-8',newline='\n')
# Only old8afb is eligible for retirement: current0393 and qualified9d stay.
s=(r.parent/'format-operation-r419/inspect-vm.py').read_text(encoding='utf-8').replace('2026-11-15-formatting-final-sink/source-checks-and-procedure.tar.xz','2026-11-15-method-format-layout/source-checks-and-procedure.tar.xz').replace('55ba4c8a24f3ae110a937f6b9b2b11179c90720a991a8f119cba1dab035fa2b2','8afb146e835dcd2692150026e4beb6566b2a483349b2a8b5c24b5e6eba58e6ed').replace('format-sinks-b809-20261115/reference','format-layout-b812-20261115/reference')
(r/'inspect-vm.py').write_text(s,encoding='utf-8',newline='\n');print('Prepared one current capture and exact-image facts/old-runtime custody checks; not launched.')
