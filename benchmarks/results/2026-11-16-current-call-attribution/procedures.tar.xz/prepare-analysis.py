from pathlib import Path
r=Path(__file__).parent;s=(r.parent/'format-program-r417/analyze.py').read_text(encoding='utf-8')
a=s.index(' groups=');b=s.index(' inclusive=',a)
s=s[:a]+" groups={'entry/frame retirement':['CreateNativeContinuation','EnterInvocationFrame','CreateExecutableWorkState','StartInline','StartNativeCall','EnterFunctionCall','LeaveFunctionCall','AdoptExecutableExecution','RentFunctionArgumentStorage','CloseInvocation'],'call/packet transport':['InvokeExecutableGeneralTargetAsync','PrepareExecutableCallArguments','InvokeBorrowedCallableTarget','CustomMethodCallable','FormatStringAsync','CallBinder','BoundCallable'],'method operation':['MethodFormatOperation','AppendTemplateAsync'],'native formatting':['AppendInterpolated','AppendIntegerFormat','AppendFormattedString','TryAppendNumeric'],'JSON input':['ReadJsonString','Deserialize','ReadJson'],'admission/checks':['MemoryGovernor::Reserve','TryResize','CheckExecution','ReserveTemporary','ReleaseReserved'],'byte storage':['GovernedByteBuilder']}\n"+s[b:]
s=s.replace("kind='Matched complete-script sampled CPU;", "kind='Current complete-script sampled CPU;")
(r/'analyze.py').write_text(s,encoding='utf-8',newline='\n')
