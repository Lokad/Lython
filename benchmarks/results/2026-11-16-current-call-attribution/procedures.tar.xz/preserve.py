from pathlib import Path
import hashlib,json,shutil,tarfile

r=Path(__file__).parent;q=r/'profile';out=Path('benchmarks/results/2026-11-16-current-call-attribution');out.mkdir(exist_ok=True)
receipt=json.loads((q/'archive-receipt.json').read_text(encoding='utf-8'))
assert receipt['complete'] and receipt['allWorkersJoined'] and receipt['quietBeforeAndAfter'] and receipt['ramTraceArchivedAndVerifiedBeforeUnmount']
assert hashlib.sha256((q/'observations.tgz').read_bytes()).hexdigest()==receipt['archiveSHA256']
for source,name in [(r/'attribution.json','attribution.json'),(r/'compiler-facts.json','compiler-facts.json'),(r/'facts-image.json','facts-image.json'),(q/'identity.json','identity.json'),(q/'observations.tgz','observations.tgz'),(q/'archive-receipt.json','archive-receipt.json'),(q/'terminal-status.json','terminal-status.json')]:shutil.copyfile(source,out/name)
with tarfile.open(out/'procedures.tar.xz','w:xz') as a:
    for p in r.rglob('*'):
        if not p.is_file() or 'facts-image' in p.parts or 'retrieved' in p.parts or p.suffix in {'.dll','.exe','.pdb','.tgz'}:continue
        a.add(p,arcname=p.relative_to(r))
(out/'README.md').write_text('''# Current complete-report call and frame attribution

R420 / B815, captured2026-11-15UTC; recorded2026-11-16UTC.
Committedc023042d / frozen0393331a, subsequently fully qualified by
[43774159426](../2026-11-15-runtime-format-operation/delivery/README.md).
Existing1,024record/189,441B JSON-to-Markdown method-format report, unchanged
stdout/file goldens. Quiet F4as_v7 Ubuntu24.04.4, four EPYC9V45vCPUs,
16GiB/no swap,.NET11RC3 normal tiering/natural workstation GC.

Eight guest seconds warmup,5.342guest seconds/1,280invocations sampled at199Hz
with perf CPU-clock/frame-pointer and diagnostic DOTNET_PerfMapEnabled=3.
Whole worker includes mediated RAM I/O, reset/protocol/goldens and prior-result
cleanup; wider than execution clocks. No comparison or speedup is measured.

**1,016active-thread samples /146unknown leaves**, all unknowns and other-thread
samples/CPU retained. Inclusive overlapping groups:568call/packet,251method
operation,170JSON input,157byte storage,140native formatting,97entry/frame
retirement,86admission/checks. These include useful/inlined work and are not
removable overhead shares. Nearest frames include95instruction prefix,76Reserve,
53string append,51general target invoke,41template executor,40JSON construction,
39method operation and29StartInline. Active thread5.11CPU seconds, GC.22/JIT.05;
no conclusion that either accounting or all call activity can be eliminated.

Compiler facts confirm native-eligible/unmirrored render helpers, capacity6for
f-strings/9for method formatting; ordinary format still promotes at LoadCallMember.
Its frequency and exclusive binding/storage cost are not instrumented. Imports
already execute code objects; protected try/except native helpers, lazy namespaces,
borrowed callable entry, small JSON scalar parsing and final UTF8 strings are
already delivered. They cannot be counted as new removal opportunities.

**Decision:** close this bounded capture without selecting an ABI/frame rewrite.
Broad call counts do not isolate a dominant removable packet or activation cost.
R403controller and R411tail-borrow regressions remain relevant; do not reintroduce
them under another view/arena. A complete storage/transport replacement remains
eligible when source evidence identifies its lifetime invariant and displaced work.
Move to a different representative workload/source gate rather than another format
micro-optimization or unchanged capture. The performance objective remains open.

Every image/golden/quiet/Closed/exit/join/archive gate passes; persistent trace
hash-verified under lease before RAM unmount, all users joined. Only the obsolete
8afb core's exact committed archived replicas were retired after fresh ownership,
path/hash/all-alias proof; current039and qualified9d images/toolchains retained.
254/252MiB floors preserved; no users or RAM fixture remain. Terminal cached.

[All samples](attribution.json),[compiler facts](compiler-facts.json),
[complete image](identity.json),[raw capture](observations.tgz),
[procedures and custody](procedures.tar.xz).
No runtime edit, prototype, allocation improvement or causal timing claim.
''',encoding='utf-8',newline='\n')
p=Path('benchmarks/EXPERIMENTS.md');s=p.read_text(encoding='utf-8');s+='\n\n[R420current call/frame attribution](results/2026-11-16-current-call-attribution/README.md): c023042d/0393331a, B8151,016active samples/146unknown leaves/all other-thread CPU retained. Broad overlapping call groups include useful work; no isolated dominant ABI/storage cost or runtime prototype selected. Compiler facts and already-delivered routes verified. All image/golden/quiet/join/archive gates pass; terminal cached, no users/RAM remain. Next different workload/source gate; no repeated unchanged capture or new format micro-tweak.\n';p.write_text(s,encoding='utf-8',newline='\n')
p=Path('PLAN.md');s=p.read_text(encoding='utf-8').replace('Updated2026-11-15UTC.','Updated2026-11-16UTC.')
a=s.index('| Last fully qualified runtime |');b=s.index('| Latest external checkpoint |',a)
s=s[:a]+'''| Last fully qualified runtime | **c023042d / frozen0393331a**, [R419delivery](benchmarks/results/2026-11-15-runtime-format-operation/delivery/README.md). **43774159426GREEN** at0e978c0b; Windows/Ubuntu actual11/10 each4,777internal/17,894public ordinary, original13/406stress and installed Release consumers.16summaries/595frozen inputs/deleted paths verified. Terminal cached forever. |
| Active implementation | No runtime prototype or unqualified source change. R420current call/frame gate completed; next coherent replacement must be selected from concrete source and affected workload evidence. |
'''+s[b:]
a=s.index('**R420 bounded gate:**');b=s.index('Stop this gate',a)
s=s[:a]+'''**R420 closed:** [current complete-report attribution](benchmarks/results/2026-11-16-current-call-attribution/README.md), B815all gates/cleanup.1,016active samples/146unknown leaves and all other-thread CPU retained.568inclusive call/packet samples include useful formatting work;97entry/frame samples do not establish a dominant isolated storage cost. Current compiler facts confirm method promotion but not frequency. No ABI/controller/arena/view prototype selected. Do not repeat unchanged capture or declare ordinary protected helpers/import execution/JSON UTF8 storage unsolved; these are delivered.

**Next R421 — different-workload source gate.** Inspect complete captured-text/
configuration scripts and existing attribution for a concrete duplicate call/value/
frontend representation. Select one complete replacement with displaced machinery,
or record the exact unresolved cost and move on. No new timing campaign before a
source design, no additional format-only tweak series. Broader A1–A4 remain ordered
by demonstrated work, not the size of overlapping sampled groups.

'''+s[b:]
s=s.replace('Full43774159426active.','Full43774159426GREEN, archived above.')
p.write_text(s,encoding='utf-8',newline='\n')
print('R420 preserved; PLAN reflects qualified R419, closed attribution gate and next different-workload source gate.')
