from pathlib import Path
import ast,gzip,hashlib,io,json,shutil,subprocess,tarfile
r=Path(__file__).parent;notes=r.parent;repo=Path('D:/code/Lython');q=r/'quiet';q.mkdir(exist_ok=False);old=notes/'utf8-width-r483/refined'
f=json.loads((r/'frozen/identity.json').read_text(encoding='utf-8'));prior=json.loads((old/'cpython/quiet/config.json').read_text(encoding='utf-8'))
qualification=json.loads((repo/'benchmarks/results/2026-11-17-utf8-widths/refined/delivery/qualification.json').read_text(encoding='utf-8'));assert qualification['conclusion']=='success'and qualification['run']==44080812207
canonical='benchmarks/results/2026-11-17-unary-result-transport/candidate-core.dll.gz';blob=subprocess.check_output(['git','show','HEAD:'+canonical],cwd=repo);assert blob==(repo/canonical).read_bytes();data=gzip.decompress(blob);sha=hashlib.sha256(data).hexdigest()
s=(notes/'instruction-global-slots-r479/inspect-retirement.py').read_text(encoding='utf-8');a=s.index("code='''");b=s.index('ssh=');scope={'sha':sha};exec(s[a:b],scope)
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
p=subprocess.run(ssh+['python3 -'],input=scope['code'],text=True,encoding='utf-8',capture_output=True,timeout=60);assert p.returncode==0,p.stdout+p.stderr;selected=json.loads(p.stdout);assert selected['bytes']==len(data)
groups=[selected|dict(canonical=canonical,canonicalSHA256=hashlib.sha256(blob).hexdigest(),member='gzip-payload',committedBlobVerified=True,supersededQualifiedSource='Qualified0315 superseded by fullyqualifieda95/44080812207; preserve currenta95 and canonicals')]
canonical='benchmarks/results/2026-11-17-utf8-widths/first/observations.tgz';blob=subprocess.check_output(['git','show','HEAD:'+canonical],cwd=repo);assert blob==(repo/canonical).read_bytes();member='representative.json'
with tarfile.open(fileobj=io.BytesIO(blob))as a:data=a.extractfile(member).read()
groups.append(dict(paths=['utf8-widths-b898-20261117/'+member],bytes=len(data),links=1,sha256=hashlib.sha256(data).hexdigest(),canonical=canonical,canonicalSHA256=hashlib.sha256(blob).hexdigest(),member=member,committedBlobVerified=True))
remote='/home/lokad/lython-bench-checks/borrowed-binding-b902-20261117';reference=f['imageFiles']['reference']['Lokad.Lython.dll'];candidate=f['imageFiles']['candidate']['Lokad.Lython.dll']
identity=dict(sourceRevision='Qualifieddbdf8262/frozena95ff2a4 versus R485 on4bf82ddb/frozen'+candidate,purpose='General positional borrowed binding input removes up-front packet preparation. Includes independent packet lifetime/admission correction; four new tests fail qualified baseline/pass candidate. Wider view/indirections are measurement risks, no forecast. Whole JSON-lines warm/fresh, report/text helper and native call/floating controls.',coreSHA256={'reference':reference,'reference-control':reference,'candidate':candidate,'candidate-control':candidate},imageFiles=f['imageFiles'],auxiliaryFiles={n:h for n,h in f['imageFiles']['reference'].items()if n!='Lokad.Lython.dll'},sourceInputsArchiveSHA256=hashlib.sha256((r/'candidate-sources.tar.xz').read_bytes()).hexdigest(),productionFiles=586,catalogSHA256=f['catalogSHA256'],normalAdapterPin='0.4.0',publicationHeld=True)
(q/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8')
s=(old/'quiet/collect.py').read_text(encoding='utf-8');a=s.index('jobs=');b=s.index('\nenv =',a);jobs=[['scripts.json-summary-helpers.large','warm'],['scripts.json-summary-helpers.large','compile-run'],['scripts.report-render.helper-list','warm'],['scripts.text-normalization.helper-list','warm'],['calls.positional.large','warm'],['scripts.numeric-squared-error.floating.large','warm']];s=s[:a]+'jobs='+repr(jobs)+'\nassert len(jobs)==6 and all(case in cases for case,lane in jobs)\n'+s[b:];s=s.replace('R483 bulk UTF8 width','R485 borrowed binding');(q/'collect.py').write_text(s,encoding='utf-8',newline='\n')
(q/'archive-owned.py').write_text((old/'quiet/archive-owned.py').read_text(encoding='utf-8'),encoding='utf-8',newline='\n')
(q/'run.sh').write_text((old/'quiet/run.sh').read_text(encoding='utf-8').replace('/home/lokad/lython-bench-checks/utf8-widths-b899-20261117',remote),encoding='utf-8',newline='\n')
(q/'candidate').mkdir();shutil.copyfile(r/'frozen/candidate/Lokad.Lython.dll',q/'candidate/Lokad.Lython.dll');shutil.copyfile(r/'catalog.json',q/'representative.json')
names=['collect.py','archive-owned.py','run.sh','identity.json','representative.json','candidate/Lokad.Lython.dll']
with tarfile.open(q/'payload.tgz','w:gz')as a:
 for n in names:a.add(q/n,arcname=n)
c=dict(root=remote,unit='lython-b902-borrowed-binding-20261117',source=prior['root'],sourceRole='candidate',sourceFiles=f['imageFiles']['reference'],sourceCatalogSHA256=prior['catalogSHA256'],catalogSHA256=f['catalogSHA256'],identity=identity,retireGroups=groups,payloadBytes=(q/'payload.tgz').stat().st_size,payloadSHA256=hashlib.sha256((q/'payload.tgz').read_bytes()).hexdigest(),unpackedBytes=sum((q/n).stat().st_size for n in names));(q/'config.json').write_text(json.dumps(c,indent=2)+'\n',encoding='utf-8')
s=(old/'quiet/remote-launch.py').read_text(encoding='utf-8');a=s.index('c=');b=s.index('\nb=Path(',a);s=s[:a]+'c='+repr(c)+s[b:];s=s.replace('lython-b899-fixtures','lython-b902-fixtures');(q/'remote-launch.py').write_text(s,encoding='utf-8',newline='\n')
(r/'launch.py').write_text((old/'launch.py').read_text(encoding='utf-8').replace('bulk UTF8 widths','borrowed argument binding'),encoding='utf-8',newline='\n')
s=(old/'quiet/retrieve.py').read_text(encoding='utf-8').replace('B899','B902');(q/'retrieve.py').write_text(s,encoding='utf-8',newline='\n')
shutil.copyfile(old/'summarize.py',r/'summarize.py')
for p in list(q.glob('*.py'))+[r/'launch.py',r/'summarize.py']:ast.parse(p.read_text(encoding='utf-8'))
print('Six-job source pair prepared; currentqualifieda95 preserved. Only verified superseded0315 aliases/committed old catalog eligible for retirement:',selected['paths'])

