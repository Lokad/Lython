from pathlib import Path
import hashlib,json,os,shutil,subprocess,tarfile
r=Path(__file__).parent;notes=r.parent;repo=Path('D:/code/Lython');reference=notes/'utf8-width-r483/refined';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
catalog=json.loads((notes/'generator-sum-r475/catalog.json').read_text(encoding='utf-8'));names=['scripts.json-summary-helpers.large','scripts.report-render.helper-list','scripts.text-normalization.helper-list','calls.positional.large','scripts.numeric-squared-error.floating.large'];catalog['cases']=[next(c for c in catalog['cases']if c['id']==n)for n in names];(r/'catalog.json').write_text(json.dumps(catalog,indent=2)+'\n',encoding='utf-8')
files=json.loads((reference/'frozen/identity.json').read_text(encoding='utf-8'))['imageFiles']['candidate'];frozen=r/'frozen';frozen.mkdir(exist_ok=False)
for role in ['reference','candidate']:
 image=frozen/role;image.mkdir()
 for n,h in files.items():assert sha(reference/'frozen/candidate'/n)==h;shutil.copyfile(reference/'frozen/candidate'/n,image/n)
 if role=='candidate':shutil.copyfile(repo/'src/Lokad.Lython/bin/Release/net11.0/Lokad.Lython.dll',image/'Lokad.Lython.dll')
 for p in(reference/'frozen/candidate').glob('ValidatedAllocation.*'):shutil.copyfile(p,image/p.name)
images={role:{n:sha(frozen/role/n)for n in files}for role in ['reference','candidate']};assert[n for n in files if images['reference'][n]!=images['candidate'][n]]==['Lokad.Lython.dll']
old=json.loads((reference/'frozen/identity.json').read_text(encoding='utf-8'));new=['src/Lokad.Lython/Runtime/Calls/BorrowedCallArguments.cs','tests/Lokad.Lython.Tests/CallablePacketOwnershipTests.cs'];inputs={n:sha(repo/n)for n in sorted(list(old['sourceInputs'])+new)};assert len(inputs)==2383
with tarfile.open(r/'candidate-sources.tar.xz','w:xz')as a:
 for n in inputs:a.add(repo/n,arcname=n)
with tarfile.open(reference/'candidate-sources.tar.xz')as a:
 changed=[n for n in inputs if n.startswith('src/Lokad.Lython/')and(n in new or(repo/n).read_text(encoding='utf-8-sig')!=a.extractfile(n).read().decode('utf-8-sig').replace('\r\n','\n'))]
assert len(changed)==12,changed
identity=dict(referenceSource='Qualifieddbdf8262/frozena95ff2a4 GREEN44080812207',candidateSource='R485 borrowed general-call/binding input on4bf82ddb plus independently verified copied-packet funding correction; prototype only',imageFiles=images,sourceInputs=inputs,productionFiles=586,changedProductionFiles=changed,catalogSHA256=sha(r/'catalog.json'),normalAdapterPin='0.4.0',publicationHeld=True)
(frozen/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8')
dotnet=Path('C:/Users/JoannesVermorel/.dotnet11/dotnet.exe');env=os.environ.copy();env.update(DOTNET_ROOT=str(dotnet.parent),DOTNET_ROOT_X64=str(dotnet.parent));env['PATH']=str(dotnet.parent)+os.pathsep+env['PATH']
for role in ['reference','candidate']:
 image=frozen/role
 for label,cmd in [('preflight',[str(dotnet),str(image/'Lokad.Lython.Benchmarks.dll'),'--compare','verify','--catalog',str(r/'catalog.json'),'--dotnet',str(dotnet),'--python','C:/Python313/python.exe','--python-worker',str(repo/'benchmarks/cpython-worker.py'),'--out',str(r/(role+'-preflight.json'))]),('allocation',[str(dotnet),str(image/'ValidatedAllocation.dll'),str(image),str(r/'catalog.json'),str(r/(role+'-allocation.json'))])]:
  with(r/(role+'-'+label+'.log')).open('w',encoding='utf-8')as log:p=subprocess.run(cmd,env=env,stdout=log,stderr=subprocess.STDOUT)
  assert p.returncode==0,(r/(role+'-'+label+'.log')).read_text(encoding='utf-8');print(role,label,'pass',flush=True)
print('Copied32file workers verified; source12changes/586production/2383inputs, candidate',images['candidate']['Lokad.Lython.dll'],flush=True)

