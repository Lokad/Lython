from pathlib import Path
import gzip,json,shutil,subprocess,tarfile
r=Path(__file__).parent;repo=Path('D:/code/Lython');out=repo/'benchmarks/results/2026-11-17-borrowed-binding';out.mkdir(exist_ok=False)
v=json.loads((r/'summary.json').read_text(encoding='utf-8'));assert v['complete']and v['quietBeforeAndAfter']and v['allUsersJoinedAndFixturesRemoved'];v['retentionDecisionPending']=False;(r/'summary.json').write_text(json.dumps(v,indent=2)+'\n',encoding='utf-8')
for source,target in [(r/'summary.json','summary.json'),(r/'allocation-summary.json','allocation-summary.json'),(r/'frozen/identity.json','identity.json'),(r/'candidate-sources.tar.xz','candidate-sources.tar.xz'),(r/'quiet/observations.tgz','observations.tgz'),(r/'quiet/archive-receipt.json','archive-receipt.json'),(r/'quiet/terminal-status.json','terminal-status.json')]:shutil.copyfile(source,out/target)
with gzip.open(out/'candidate-core.dll.gz','wb')as f:f.write((r/'frozen/candidate/Lokad.Lython.dll').read_bytes())
with tarfile.open(out/'procedures-and-checks.tar.xz','w:xz')as a:
 for p in r.rglob('*'):
  if p.is_file()and not{'frozen','retrieved','__pycache__'}&set(p.relative_to(r).parts)and p.suffix in{'.py','.log','.json','.txt','.sh'}:a.add(p,arcname=p.relative_to(r).as_posix())
decision=dict(retainRepresentation=False,retainIndependentFundingCorrection=True,basis='No established substantial JSON warm gain/flat allocation; view widens binding transport, adds two source modes/collection bridge, still creates CallArgumentValue on reads. Added machinery not justified by small fresh/report gains. Not a fixed threshold veto or permanent design ban.',reference='Qualifieddbdf8262/frozena95ff2a4',candidate='R485on4bf82ddb/frozen912735fe',baselineNewRegressions='4fail after nonincremental qualified-source build; same4pass candidate on actual11/10',focused='38internal each; public11=1063including13stress/public10=1050ordinary, not identical filter scopes',fullQualificationOfWithdrawnPrototypeRequested=False,allUsersJoinedAndFixturesRemoved=True,publicationHeld=True,broaderPerformanceObjectiveComplete=False)
(out/'decision.json').write_text(json.dumps(decision,indent=2)+'\n',encoding='utf-8')
table=[]
for x in v['rows']:
 fmt=lambda k:f"{min(x[k]):+.2f}..{max(x[k]):+.2f}%"
 table.append(f"| {x['case']} / {x['lane']} | {fmt('elapsedChangePercent')} | {fmt('cpuChangePercent')} | {x['referenceSpreadPercent']:.2f}/{x['candidateSpreadPercent']:.2f}% |")
(out/'README.md').write_text('''# Borrowed binding input: representation withdrawn

R485/B902,2026-11-17UTC. Qualifieddbdf8262/frozena95ff2a4 versus12file prototype
on4bf82ddb/frozen912735fe. Withdraw the two-mode borrowed argument view/collection
bridge and all signature migrations. Preserve the independently demonstrated copy
funding/lifetime correction and four useful regressions. No full qualification
of this discarded representation, unchanged retiming or permanent design ban.

The prototype reads positional arguments from final executable slots, retaining
packets for keywords/constructors/protocols. Bindings still reconstruct a
CallArgumentValue per read; wider transport and another decoding mode add machinery.
One controlled pair does not justify retaining it for the small fresh/report
changes below. Moving controls establish uncertainty, not a stable design failure.

| Complete workload / lane | Elapsed change | Wider CPU change | Reference/candidate control spread |
| --- | ---: | ---: | ---: |
'''+ '\n'.join(table)+'''

Allocation effectively flat (−0.066..+0.003%), accounted peaks unchanged, every
shared-budget baseline restored. Actual copied32file images pass5case CPython
goldens; source snapshot includes586production/2383inputs. Windows actual11/10each
38internal pass. Public11 1063 includes13stress; public10 1050ordinary. Scopes
differ and are not summed or represented as identical qualification.

Four new copy-admission/cancellation regressions fail qualified4bfsource after
fresh nonincremental build and pass candidate. The default copied packet and
non-function bound receiver prefix were not independently funded through pending
users. Retain the shared existing estimate, preflight before allocation/body
effects, references and funding until awaited cleanup, then refund/reuse. Preserve
this correction even when withdrawing the performance view; no scalar tracing,
quota, extra allowance, background work or API compatibility layer.

Quiet AzureF4as_v7/Ubuntu24.04.4/.NET11RC3,6jobs230.19s,6s rotated warmups/five
samples/four processes; normalGC/tiering. I/O/full goldens/prior-result cleanup
included; compilation only fresh; reset/staging/protocol/startup/cache teardown
excluded. WiderCPU is quantized. All quiet/golden/Closed/exit/join/archive checks
pass; RAM removed and terminal cached. Only verified superseded0315core aliases
and exact committed old catalog retired after fresh path/UID/hash/link/all-alias
proof. Currentqualifieda95/toolchains/canonicals and254/252MiB floors preserved.
Publication held; complete-script performance objective remains active.

[Decision](decision.json),[summary](summary.json),[allocation](allocation-summary.json),
[raw](observations.tgz),[source](candidate-sources.tar.xz),[identity](identity.json),
[procedures/baseline failures](procedures-and-checks.tar.xz).
''',encoding='utf-8',newline='\n')
# Preserve exact candidate text, then remove the representation rather than
# leaving a dormant binding mode. Reapply only the independently tested funding.
fixes={}
with tarfile.open(r/'candidate-sources.tar.xz')as a:
 for name in ['src/Lokad.Lython/Runtime/LythonRuntime.Calls.cs','src/Lokad.Lython/Runtime/PyBoundMethod.cs','src/Lokad.Lython/Runtime/LythonRuntime.Executable.Binding.cs']:
  frozen=a.extractfile(name).read().decode('utf-8-sig').replace('\r\n','\n');assert(repo/name).read_text(encoding='utf-8-sig')==frozen;fixes[name]=frozen
for name in json.loads((r/'frozen/identity.json').read_text(encoding='utf-8'))['changedProductionFiles']:
 path=repo/name;assert path.resolve().is_relative_to((repo/'src/Lokad.Lython').resolve())
 with tarfile.open(r/'candidate-sources.tar.xz')as a:frozen=a.extractfile(name).read().decode('utf-8-sig').replace('\r\n','\n')
 assert path.read_text(encoding='utf-8-sig')==frozen,name
 if name.endswith('/BorrowedCallArguments.cs'):path.unlink()
 else:
  data=subprocess.check_output(['git','show','4bf82ddb:'+name],cwd=repo).decode('utf-8-sig');path.write_text(data.replace('\r\n','\n'),encoding='utf-8',newline='\n')
for name,text in fixes.items():
 text=text.replace('BorrowedCallArguments','ReadOnlySpan<CallArgumentValue>').replace('arguments.ToArray(context, span)','arguments.ToArray()').replace('arguments.CopyTo(bound.AsSpan(1), context, span)','arguments.CopyTo(bound.AsSpan(1))')
 (repo/name).write_text(text,encoding='utf-8',newline='\n')
p=repo/'src/Lokad.Lython/Runtime/LythonRuntime.Executable.Calls.Invoke.cs';text=p.read_text(encoding='utf-8').replace('ReserveExecutableCallArguments(call, this)','ReserveCallArgumentStorage(call.ArgumentCount, this, call.CallSpan)');p.write_text(text,encoding='utf-8',newline='\n')
p=repo/'benchmarks/EXPERIMENTS.md';text=p.read_text(encoding='utf-8');text+='\nR485/B902 [borrowed binding input](results/2026-11-17-borrowed-binding/README.md): representation withdrawn. JSONwarm−0.28..+2.30%/candidate2.52%movement, fresh−2.06..−0.47%, report−1.94..−0.57%; controls/mixedCPU/flat allocation do not justify wider view/bridge that still creates packet entries per read. All12production changes removed, four-file independent copy funding correction retained for final qualification;4newtests fail qualified baseline/pass candidate. Full original evidence/adversity remains; all gates/join/archive pass, no permanent ban or unchanged campaign. Publication held, broader objective active.\n';p.write_text(text,encoding='utf-8',newline='\n')
print('Two-mode borrowed view/bridge removed; only four-file independent copied-packet funding correction and4regressions remain.')

