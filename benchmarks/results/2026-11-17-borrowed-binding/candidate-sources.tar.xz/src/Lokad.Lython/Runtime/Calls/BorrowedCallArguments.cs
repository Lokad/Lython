using System.Runtime.CompilerServices;

namespace Lokad.Lython.Runtime;

// A binding input borrows either existing packets or final executable operands.
// It is consumed synchronously before a callable returns pending work. Only a
// real owned/pending packet materializes an array; no second operand owner exists.
[CollectionBuilder(typeof(BorrowedCallArguments), nameof(Create))]
internal readonly ref struct BorrowedCallArguments
{
    private readonly ReadOnlySpan<CallArgumentValue> _packets;
    private readonly Span<LythonRuntime.ExecutableSlot> _operands;

    private BorrowedCallArguments(ReadOnlySpan<CallArgumentValue> packets)
    {
        _packets = packets;
        _operands = default;
    }

    private BorrowedCallArguments(Span<LythonRuntime.ExecutableSlot> operands)
    {
        _packets = default;
        _operands = operands;
    }

    public static BorrowedCallArguments Create(ReadOnlySpan<CallArgumentValue> packets) => new(packets);
    internal static BorrowedCallArguments Positional(Span<LythonRuntime.ExecutableSlot> operands) => new(operands);
    internal int Length => _operands.IsEmpty ? _packets.Length : _operands.Length;
    internal bool IsEmpty => Length == 0;

    internal CallArgumentValue this[int index] => _operands.IsEmpty ? _packets[index]
        : CallArgumentValue.Positional(_operands[index].Object.RequireNotNull());

    internal BorrowedCallArguments Slice(int start, int count)
        => _operands.IsEmpty ? new(_packets.Slice(start, count)) : new(_operands.Slice(start, count));
    internal BorrowedCallArguments this[Range range] => _operands.IsEmpty
        ? new(_packets[range]) : new(_operands[range]);

    internal void CopyTo(Span<CallArgumentValue> destination, LythonRuntime.ExecutionContext? context = null,
        LythonSourceSpan? span = null)
    {
        if (destination.Length < Length) throw new ArgumentException("Destination is too short.", nameof(destination));
        if (_operands.IsEmpty) { _packets.CopyTo(destination); return; }
        context ??= PyStructuralGuard.AmbientContext;
        span ??= PyStructuralGuard.AmbientSpan;
        for (var index = 0; index < Length; index++)
        {
            if ((index & 1023) == 0) context?.CheckExecution(span);
            destination[index] = this[index];
        }
        context?.CheckExecution(span);
    }

    internal CallArgumentValue[] ToArray(LythonRuntime.ExecutionContext? context = null, LythonSourceSpan? span = null)
    {
        var result = new CallArgumentValue[Length];
        CopyTo(result, context, span);
        return result;
    }

    public Enumerator GetEnumerator() => new(this);
    internal ref struct Enumerator(BorrowedCallArguments arguments)
    {
        private readonly BorrowedCallArguments _arguments = arguments;
        private int _index = -1;
        public bool MoveNext() => ++_index < _arguments.Length;
        public CallArgumentValue Current => _arguments[_index];
    }

    public static implicit operator BorrowedCallArguments(CallArgumentValue[] arguments) => new(arguments.AsSpan());
    public static implicit operator BorrowedCallArguments(ReadOnlySpan<CallArgumentValue> arguments) => new(arguments);
    public static implicit operator BorrowedCallArguments(Span<CallArgumentValue> arguments) => new(arguments);
}

