from pathlib import Path
r=Path(__file__).resolve().parent
text=(r/'focus.py').read_text(encoding='utf-8').replace("r=Path(__file__).parent;", "r=Path(__file__).parent/'restored';r.mkdir(exist_ok=True);")
(r/'check-restored.py').write_text(text,encoding='utf-8')
