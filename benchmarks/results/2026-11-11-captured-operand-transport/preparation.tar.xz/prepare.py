from pathlib import Path
import hashlib,json,shutil,subprocess
r=Path(__file__).parent;prior=r.parent/'constructor-binding-r233';repo=Path.cwd();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert not (r/'before.json').exists()
assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip().startswith('64b6800c')
baseline=json.loads((repo/'benchmarks/results/2026-11-11-constructor-text-confirmation/source-identity.json').read_text(encoding='utf-8'))
for p,h in baseline['sourceSHA256'].items():assert sha(repo/p)==h,p
shutil.copyfile(r.parent/'iteration-returns-r225/catalog.json',r/'catalog.json')
for role in ['before','candidate']:shutil.copytree(prior/'images/candidate',r/'images'/role)
for phase in ['warm-sync','warm-async','compile']:
 (r/phase).mkdir();shutil.copyfile(prior/phase/'hash-witness.json',r/phase/'hash-witness.json')
paths=['src/Lokad.Lython/Frontend/ExecutableStackLayout.cs','src/Lokad.Lython/Runtime/LythonRuntime.Executable.Interpreter.cs','src/Lokad.Lython/Runtime/LythonRuntime.Executable.DictionaryAccumulation.cs','src/Lokad.Lython/Runtime/PyExecutableFunction.cs']
for p in paths:
 dest=r/'originals'/p;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(repo/p,dest)
(r/'before.json').write_text(json.dumps(dict(head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),runtimeRevision='15f457f7786703bfe2ee251b3fe84145ad155fbe',allSources=baseline['sourceSHA256'],images={role:{p.name:sha(p)for p in(r/'images'/role).iterdir()if p.is_file()}for role in ['before','candidate']},
 hypothesis='Forward captured operands through existing constant/cell read bank, eliminating eligible LoadClosure publication/retirement and dispatch. No storage sidecar/opcode/engine. Native-return proof is built before forwarding and remains separate; dictionary lookahead must retain its constants/locals proof. Missing-cell deferred work must promote to its actual invocation before namespace fallback.',
 acceptance='Original spans/read order, missing-cell behavior, reentry/aliases, custom protocols/suspension, cancellation/refusal and cleanup; captured CSV/text plus unchanged report/text/CSV/JSON controls, compile separate. Source/instruction savings are not CPU claims. Ordinary text2% prior latency debt remains visible.'),indent=2)+'\n',encoding='utf-8')
print('R235 exact qualified15f production/frozen core and common9a4272de worker preserved; six existing counter/ordinary complete-script cases.')
