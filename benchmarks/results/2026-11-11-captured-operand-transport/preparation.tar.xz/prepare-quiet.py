from pathlib import Path
import ast,hashlib,json,shutil,subprocess,tarfile
r=Path(__file__).resolve().parent;q=r/'b575';q.mkdir(exist_ok=False)
old=r.parent/'constructor-binding-r233/b574';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
meta=json.loads((r/'diagnostic-identity.json').read_text(encoding='utf-8'));before=json.loads((r/'before.json').read_text(encoding='utf-8'))
all_sources=dict(before['allSources'],**meta['sourceHashes'])
for p,h in all_sources.items():assert sha(Path(p))==h,p
core=meta['images']['candidate']['Lokad.Lython.dll'];reference=meta['images']['before']['Lokad.Lython.dll']
root='/home/lokad/lython-bench-checks/closure-operands-b575-20261111';unit='lython-b575-closure-operands-20261111'
source=dict(runtimeReference=before['runtimeRevision'],prototypeUncommitted=True,sourceBase=before['head'],sourceSHA256=all_sources,coreSHA256=core,all568SourcesVerified=True,focusChecks=530,
  purpose='R235 refined captured operand transport; captured CSV both APIs, captured text async and ordinary text async control; only core changes within the frozen common quiet images. No allocation/compilation/CPython ratio or isolated CPU claim from this collection.')
(q/'source-identity.json').write_text(json.dumps(source,indent=2)+'\n',encoding='utf-8')
aux=json.loads((old/'identity.json').read_text(encoding='utf-8'))['auxiliaryFiles']
identity=dict(sourceRevision=source['purpose'],coreSHA256={'reference':reference,'reference-control':reference,'candidate':core,'candidate-control':core},auxiliaryFiles=aux,catalogSHA256=sha(r/'catalog.json'),
  fixedQuietImagesDifferFromLocal=True,localWorkerSHA256=meta['images']['candidate']['Lokad.Lython.Benchmarks.dll'],commonQuietWorkerSHA256=aux['Lokad.Lython.Benchmarks.dll'])
(q/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8');shutil.copyfile(r/'catalog.json',q/'representative.json')
jobs=[['scripts.csv-validated-records.nonlocal-counter.large','warm'],['scripts.csv-validated-records.nonlocal-counter.large','warm-async'],['scripts.text-summary-helpers.nonlocal-counter.large','warm-async'],['scripts.text-summary-helpers.large','warm-async']]
text=(old/'collect.py').read_text(encoding='utf-8').replace('/constructor-binding-b574-20261111','/closure-operands-b575-20261111')
begin=text.index('jobs=');end=text.index('\nenv = ',begin)
text=text[:begin]+'jobs='+repr(jobs)+'\nassert len(jobs)==4 and all(case in cases for case,lane in jobs)\n'+text[end:]
text=text.replace("< 170, 'Reserve40seconds","< 140, 'Reserve40seconds")
begin=text.index("purpose='R234");end=text.index("',\n                  warmupSeconds",begin)
text=text[:begin]+"purpose='R235 refined prototype versus exact qualified15f, four affected complete-script source pairs, same frozen common images and fixtures, no CPython/isolatedCPU claim. Warm includes mediated RAM I/O/full checks/prior-result cleanup, excludes compile/startup/reset/protocol/final caches"+text[end:]
ast.parse(text);(q/'collect.py').write_text(text,encoding='utf-8',newline='\n')
text=(old/'archive-owned.py').read_text(encoding='utf-8').replace('/constructor-binding-b574-20261111','/closure-operands-b575-20261111').replace('==5','==4').replace('jobs=5','jobs=4')
ast.parse(text);(q/'archive-owned.py').write_text(text,encoding='utf-8',newline='\n')
text=(old/'run.sh').read_text(encoding='utf-8').replace('/constructor-binding-b574-20261111','/closure-operands-b575-20261111').replace('lython-b573-patch-cpython-20261111',unit)
assert unit+'.service'in text and'b573'not in text
(q/'run.sh').write_text(text,encoding='utf-8',newline='\n');shutil.copyfile(r/'images/candidate/Lokad.Lython.dll',q/'current-core.dll')
retire=[]
for canonical,known,member in [
 ('benchmarks/results/2026-11-11-json-cpython-checkpoint/observations.tgz','json-cpython-b566-20261111/candidate/Lokad.Lython.dll','current-core.dll'),
 ('benchmarks/results/2026-11-11-constructor-text-confirmation/observations.tgz','constructor-binding-b574-20261111/observations.tgz',None),
 ('benchmarks/results/2026-11-11-patch-workflow/quiet/observations.tgz','patch-cpython-b573-20261111/observations.tgz',None),
 ('benchmarks/results/2026-11-11-current-helper-prefix/observations.tgz','return-prefix-b572-20261111/profiles/text-warm/perf.map','profiles/text-warm/perf.map')]:
 p=Path(canonical);subprocess.run(['git','ls-files','--error-unmatch',canonical],check=True,capture_output=True)
 if member:
  with tarfile.open(p)as t:raw=t.extractfile(member).read()
 else:raw=p.read_bytes()
 spec=dict(kind='core'if member=='current-core.dll'else'exact',knownPath=known,canonical=canonical,bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
 if member:spec['canonicalMember']=member
 assert spec['sha256']not in {core,reference,'9ee7e700580399ff80d803f0a7535d2de5ff0f10d35a736370f457383be1b67f'}
 retire.append(spec)
with tarfile.open(q/'payload.tgz','w:gz')as t:
 for name in ['current-core.dll','representative.json','source-identity.json','identity.json','collect.py','archive-owned.py','run.sh']:t.add(q/name,arcname=name)
with tarfile.open(q/'payload.tgz')as t:expanded=sum(((m.size+4095)//4096)*4096 for m in t.getmembers())
config=dict(root=root,unit=unit,payloadBytes=(q/'payload.tgz').stat().st_size,payloadSHA256=sha(q/'payload.tgz'),requiredFreeBytes=252*1024*1024+expanded+65536,retire=retire,identity=identity)
(q/'config.json').write_text(json.dumps(config,indent=2)+'\n',encoding='utf-8')
text=(old/'remote-launch.py').read_text(encoding='utf-8')
text=text.replace("source=base/'iteration-returns-b570-20261111/candidate'","source=base/'constructor-binding-b574-20261111/candidate'")
text=text.replace("base/'json-cpython-b566-20261111/candidate/Lokad.Lython.dll':'9dadd59bd75528186c66a9a95e2efcf411e611e0ccaa718ff38c4facdb191e33'","base/'iteration-returns-b570-20261111/candidate/Lokad.Lython.dll':'9ee7e700580399ff80d803f0a7535d2de5ff0f10d35a736370f457383be1b67f'")
text=text.replace('lython-b574-fixtures','lython-b575-fixtures').replace('jobs=5','jobs=4').replace('ownerSeconds=210','ownerSeconds=180').replace('RuntimeMaxSec=210','RuntimeMaxSec=180').replace("canonicalCommit='15f457f7'","canonicalCommit='64b6800c'")
text=text.replace("proof=dict(spec);proof.update", "assert spec['kind']!='exact'or s.st_nlink==1\n   proof=dict(spec);proof.update")
ast.parse(text.replace('config=CONFIG','config='+repr(config)).replace('inventoryOnly=INVENTORY_ONLY','inventoryOnly=True'))
(q/'remote-launch.py').write_text(text,encoding='utf-8',newline='\n')
text=(old/'launch.py').read_text(encoding='utf-8').replace('constructor-binding-b574-launch','closure-operands-b575-launch').replace('seconds=270','seconds=240').replace('ownerSeconds=210','ownerSeconds=180')
(q/'launch.py').write_text(text,encoding='utf-8',newline='\n')
text=(old/'retrieve.py').read_text(encoding='utf-8').replace('constructor-binding-b574-20261111','closure-operands-b575-20261111').replace('lython-b574-constructor-binding','lython-b575-closure-operands').replace("jobs']==5","jobs']==4").replace("elapsedSeconds']<210","elapsedSeconds']<180").replace('B574 five-job','B575 four-job')
(q/'retrieve.py').write_text(text,encoding='utf-8',newline='\n')
text=(old/'summarize.py').read_text(encoding='utf-8').replace("len(raw['jobs'])==5","len(raw['jobs'])==4").replace('jobs=5','jobs=4')
text=text[:text.index('identity=json.loads')]+"identity=json.loads((r/'identity.json').read_text(encoding='utf-8'))\n(r/'summary.json').write_text(json.dumps(dict(complete=True,jobs=4,elapsedSeconds=raw['elapsedSeconds'],sourceRevision=identity['sourceRevision'],coreSHA256=identity['coreSHA256'],timing=rows,externalBaseline=False),indent=2)+'\\n',encoding='utf-8')\n"
ast.parse(text);(q/'summarize.py').write_text(text,encoding='utf-8',newline='\n')
print('B575 four-job180sowner prepared; fresh idle lease/identity/disk proof required. Keep current15f/selected9ee7 references; older archived9dadd is eligible for exact retirement, not an immortal protected copy.')
