from pathlib import Path
import json,os,subprocess,xml.etree.ElementTree as ET
r=Path(__file__).parent;dotnet='C:/Users/JoannesVermorel/.dotnet11/dotnet.exe'
env=os.environ.copy();env['DOTNET_ROOT']=str(Path(dotnet).parent);env['PATH']=env['DOTNET_ROOT']+';C:/Python313;'+env['PATH']
groups={
'Lokad.Lython.Tests':['DirectOperandOwnershipTests','ExecutableOperandStackBoundaryTests','SimpleFunctionExecutionBoundaryTests','DeferredFunctionOwnershipTests','FunctionBodyTemporaryLifetimeTests','FunctionClassCellBoundaryTests','FunctionWorkspaceOwnershipTests','DictionaryAccumulation'],
'Lokad.Lython.PublicApi.Tests':['OperandReadFailureTests','NonlocalRebindingTests','TransitiveClosureCompatibilityTests','GeneratorExpressionBoundaryTests','GeneratorExpressionBoundaryLifetimeTests','GeneratorStatementCompositionTests','FunctionDefaultMetadataTests','NamedFunctionBindingTests','RepresentativeProtocolCancellationTests','RawDrainClosureTests']}
checks={}
for framework in ['net11.0','net10.0']:
 for project,names in groups.items():
  name=project+'-'+framework;filter='('+'|'.join('FullyQualifiedName~'+x for x in names)+')&Category!=Stress'
  cmd=[dotnet,'test','tests/'+project+'/'+project+'.csproj','-c','Release','-f',framework,'--no-build','--no-restore','--filter',filter,'--logger','trx;LogFileName='+name+'.trx','--results-directory',str(r/'tests')]
  with(r/(name+'.log')).open('wb')as log:done=subprocess.run(cmd,env=env,stdout=log,stderr=subprocess.STDOUT)
  counts=ET.parse(r/'tests'/(name+'.trx')).find('.//{*}Counters').attrib
  checks[name]=dict(command=cmd,exitCode=done.returncode,counts=counts)
  (r/'focused-checks.json').write_text(json.dumps(checks,indent=2)+'\n',encoding='utf-8')
  print(name,counts,flush=True)
  assert done.returncode==0 and counts['failed']=='0',(name,(r/(name+'.log')).read_text(encoding='utf-8')[-6000:])
