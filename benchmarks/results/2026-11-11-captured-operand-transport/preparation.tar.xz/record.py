from pathlib import Path
import hashlib,json,shutil,tarfile
r=Path(__file__).resolve().parent;out=Path('benchmarks/results/2026-11-11-captured-operand-transport');out.mkdir(exist_ok=False)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
ids=json.loads((r/'diagnostic-identity.json').read_text(encoding='utf-8'))
for p,h in ids['sourceHashes'].items():assert sha(Path(p))==h,p
for phase in ['warm-sync','warm-async','compile']:
 for prefix,target in [(r,out),(r/'initial',out/'initial')]:
  data=json.loads((prefix/phase/'measurements.json').read_text(encoding='utf-8'))
  assert data['allGoldensPassed']and data['allBalancesZero']and data['ownedFixturesRemoved']
  shutil.copytree(prefix/phase,target/phase)
for name in ['before.json','diagnostic-identity.json','catalog.json','focused-checks.json']:shutil.copyfile(r/name,out/name)
shutil.copyfile(r/'initial/refinement-decision.json',out/'refinement-decision.json')
refined=r/'refined-source'
for name in ids['sourceHashes']:
 dest=refined/name;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(Path(name),dest)
with tarfile.open(out/'preparation.tar.xz','w:xz')as t:
 for p in sorted(r.iterdir()):
  if p.is_file()and p.name!='candidate-net10.dll':t.add(p,arcname=p.name)
 for folder in ['originals','refined-source','tests','jit']:t.add(r/folder,arcname=folder)
 for p in sorted((r/'initial').iterdir()):
  if p.name not in ['warm-sync','warm-async','compile']:t.add(p,arcname='initial/'+p.name)
 t.add(r/'candidate-net10.dll',arcname='candidate-net10.dll')
 for role in ['before','candidate']:t.add(r/'images'/role/'Lokad.Lython.dll',arcname=role+'-core.dll')
 for name in ['Lokad.Lython.Benchmarks.dll','Lokad.Lython.Benchmarks.deps.json','Lokad.Lython.Benchmarks.runtimeconfig.json','Lokad.Lython.Utf8Regex.dll','Lokad.Utf8Regex.dll','Lokad.Utf8Regex.PythonRe.dll']:t.add(r/'images/before'/name,arcname='common-worker/'+name)
with tarfile.open(out/'preparation.tar.xz')as t:
 for role in ['before','candidate']:assert hashlib.sha256(t.extractfile(role+'-core.dll').read()).hexdigest()==ids['images'][role]['Lokad.Lython.dll']
files={p.relative_to(out).as_posix():dict(bytes=p.stat().st_size,sha256=sha(p))for p in out.rglob('*')if p.is_file()}
(out/'archive-identity.json').write_text(json.dumps(dict(files=files,allSourcePairsAndChecksVerified=True,initialAndRefinedCoresPreserved=True,allGoldensPassed=True,allBalancesZero=True,ownedFixturesRemoved=True,performanceQualified=False,prototypeUncommitted=True),indent=2)+'\n',encoding='utf-8')
print('Initial/refined five-file bank design, exact sources/cores, JIT probe, all raw controls/goldens/ownership checks preserved. Quiet outcome remains separate.')
