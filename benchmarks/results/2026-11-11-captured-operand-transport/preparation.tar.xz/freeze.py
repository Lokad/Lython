from pathlib import Path
import hashlib,json,shutil,subprocess
r=Path(__file__).parent;repo=Path.cwd();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
before=json.loads((r/'before.json').read_text(encoding='utf-8'))
changed=subprocess.check_output(['git','diff','--name-only','--','src/Lokad.Lython'],text=True,stderr=subprocess.DEVNULL).splitlines()
assert set(changed)=={'src/Lokad.Lython/Frontend/ExecutableStackLayout.cs','src/Lokad.Lython/Runtime/LythonRuntime.Executable.Interpreter.cs','src/Lokad.Lython/Runtime/LythonRuntime.Executable.Binding.cs','src/Lokad.Lython/Runtime/LythonRuntime.Executable.DictionaryAccumulation.cs','src/Lokad.Lython/Runtime/PyExecutableFunction.cs'}
for p,h in before['allSources'].items():
 if p not in changed:assert sha(repo/p)==h,p
shutil.copyfile(repo/'src/Lokad.Lython/bin/Release/net11.0/Lokad.Lython.dll',r/'images/candidate/Lokad.Lython.dll')
shutil.copyfile(repo/'src/Lokad.Lython/bin/Release/net10.0/Lokad.Lython.dll',r/'candidate-net10.dll')
ids=dict(beforeRevision=before['runtimeRevision'],purpose=before['hypothesis'],sourceHashes={p:sha(repo/p)for p in changed},images={role:{p.name:sha(p)for p in(r/'images'/role).iterdir()if p.is_file()}for role in ['before','candidate']},net10SHA256=sha(r/'candidate-net10.dll'))
for name,h in ids['images']['before'].items():
 if name!='Lokad.Lython.dll':assert ids['images']['candidate'][name]==h,name
(r/'diagnostic-identity.json').write_text(json.dumps(ids,indent=2)+'\n',encoding='utf-8')
(r/'source.patch').write_bytes(subprocess.check_output(['git','diff','--','src/Lokad.Lython','tests'],stderr=subprocess.DEVNULL))
for name in ['measure.py','summarize.py']:
 text=(r.parent/'constructor-binding-r233'/name).read_text(encoding='utf-8')
 if name=='measure.py':text=text.replace('stdout=stdout,stderr=stderr,env=env)','stdout=stdout,stderr=stderr,env=env,timeout=240)')
 (r/name).write_text(text,encoding='utf-8')
print('Five-file refined source pair frozen; fixed common9a4272de images differ only in core.530 focused checks pass. Each diagnostic phase has240sowned process bound.')
