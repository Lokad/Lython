from pathlib import Path
import hashlib, json, os, shutil, subprocess, tarfile

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
out=lab/"comparison"
out.mkdir(exist_ok=True)
previous=lab.parent/"uniform-eager-annotation-20261122/comparison"
reference=previous/"frozen-candidate"
prior=json.loads((previous/"images.json").read_text(encoding="utf-8"))
assert prior["candidate"].startswith("70ea1083d")
suite_path=lab.parent/"direct-lexical-keyword-default-20261122/representative.json"
suite=json.loads(suite_path.read_text(encoding="utf-8-sig"))
ids=["scripts.ordinary-fully-supplied-helper",
     "scripts.annotated-rule-closures.nested-factories",
     "scripts.annotated-rule-closures.nested-factories.postponed",
     "scripts.factory-observed-defaults",
     "scripts.csv-invoice.method-policy.quoted-control"]
other=lab.parent/"single-positional-default-20261122/representative.json"
other_suite=json.loads(other.read_text(encoding="utf-8-sig"))
rows={r["id"]:r for r in other_suite["cases"]}
rows.update((r["id"],r) for r in suite["cases"])
with tarfile.open(repo/"benchmarks/results/2026-11-22-retained-source-cpython/observations.tgz") as evidence:
    rows.update((r["id"],r) for r in json.load(evidence.extractfile("representative.json"))["cases"]
                if r["id"]=="scripts.csv-invoice.method-policy.quoted-control")
suite["cases"]=[rows[id] for id in ids]
suite["performanceQualified"]=False
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(path,value):path.write_text(json.dumps(value,indent=2)+"\n",encoding="utf-8",newline="\n")
catalog=out/"catalog.json"
write(catalog,suite)
src=lab/"frozen-build/bin/Lokad.Lython/release_net11.0/Lokad.Lython.dll"
candidate=out/"frozen-candidate"
candidate.mkdir(exist_ok=True)
expected=prior["imageFiles"]["candidate"]
assert len(expected)==32
def hashes(path):return {name:sha(path/name)for name in expected}
assert hashes(reference)==expected
core=src.name
for name in expected:shutil.copyfile(src if name==core else reference/name,candidate/name)
files={"reference":expected,"candidate":{**expected,core:sha(src)}}
assert files["reference"][core]!=files["candidate"][core]
sdk=Path.home()/".dotnet11"
dotnet=sdk/"dotnet.exe"
env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk),PATH=str(sdk)+os.pathsep+os.environ["PATH"])
protocol=repo/"benchmarks/cpython-worker.py"
assert sha(protocol)==prior["protocolSHA256"]
for role,image in (("reference",reference),("candidate",candidate)):
    assert hashes(image)==files[role]
    receipt=out/(role+"-verify.json")
    subprocess.run([dotnet,image/"Lokad.Lython.Benchmarks.dll","--compare","verify",
        "--catalog",catalog,"--dotnet",dotnet,"--python","C:/Python313/python.exe",
        "--python-worker",protocol,"--out",receipt],env=env,check=True,timeout=70)
    data=json.loads(receipt.read_text(encoding="utf-8-sig"))
    assert data["state"]=="Completed" and data["caseCount"]==len(ids) and data["catalogSha256"]==sha(catalog)
def patch(base,candidate):
    return subprocess.check_output(["git","diff","--binary",base,candidate,"--","src","tests"],cwd=repo)
assert not patch("70ea1083d","5fa0abec9")
measured=patch("5fa0abec9","2cd7317e3")
(out/"source.patch").write_bytes(measured)
write(out/"images.json",dict(reference="70ea1083d",candidate="2cd7317e3",
    imageFiles=files,catalogSHA256=sha(catalog),sourcePatchSHA256=hashlib.sha256(measured).hexdigest(),
    protocolSHA256=prior["protocolSHA256"]))
