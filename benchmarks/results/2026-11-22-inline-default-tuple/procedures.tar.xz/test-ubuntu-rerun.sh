#!/bin/bash
set -euo pipefail
cd /mnt/d/code/Lython/.git/agent-worktrees/inline-default-tuple-20261122
export DOTNET_ROOT="$HOME/.dotnet"
export PATH="$DOTNET_ROOT:$PATH"
export DOTNET_HOST_PATH="$DOTNET_ROOT/dotnet"
dir=/mnt/d/code/Lython/.git/agent-notes/review-20261031/inline-default-tuple-20261122
artifact="$dir/ubuntu"
white='Category!=Stress&(FullyQualifiedName~Tuple|FullyQualifiedName~FunctionDefault|FullyQualifiedName~FunctionAttribute|FullyQualifiedName~SimpleFunctionExecutionBoundary|FullyQualifiedName~PyValueNormalization|FullyQualifiedName~GeneralBoundMethodDefaultLifetime)'
public='Category!=Stress&(FullyQualifiedName~Tuple|FullyQualifiedName~FunctionDefault|FullyQualifiedName~FunctionAttribute|FullyQualifiedName~FunctionBinding|FullyQualifiedName~BindingPlanConstruction|FullyQualifiedName~GeneratorStorageSemantics|FullyQualifiedName~OrdinaryMethodCall|FullyQualifiedName~NativeReturn)'
dotnet test tests/Lokad.Lython.Tests -c Release -f net10.0 --filter "$white" --artifacts-path "$artifact" --nologo > "$dir/white-ubuntu.log" 2>&1 || { tail -55 "$dir/white-ubuntu.log"; exit 1; }
fixture="$artifact/bin/Lokad.Lython.PublicApi.Tests/release_net10.0/Fixtures/Language/Values"
mkdir -p "$fixture"
cp -a tests/Fixtures/Language/Values/FloatAndTuple "$fixture/"
dotnet test tests/Lokad.Lython.PublicApi.Tests -c Release -f net10.0 --filter "$public" --artifacts-path "$artifact" --nologo > "$dir/public-ubuntu-rerun.log" 2>&1 || { tail -55 "$dir/public-ubuntu-rerun.log"; exit 1; }
awk '/Passed!/{count++;print} END{exit count!=2}' "$dir/white-ubuntu.log" "$dir/public-ubuntu-rerun.log"
