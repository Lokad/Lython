from pathlib import Path
base=Path(".git/agent-notes/review-20261031")
old=base/"uniform-eager-annotation-20261122"
lab=base/"inline-default-tuple-20261122"
s=(old/"stage-comparison.py").read_text(encoding="utf-8")
s=s.replace('past=lab.parent/"current-cpython-checkpoint-20261122/comparison"',
            'past=lab.parent/"uniform-eager-annotation-20261122/comparison"')
s=s.replace('lab.parent/"current-cpython-checkpoint-20261122/frozen"','past/"frozen-candidate"')
s=s.replace('archive_dir="2026-11-22-retained-source-cpython"','archive_dir="2026-11-22-repeated-eager-annotations"')
s=s.replace('uniform-eager-annotation-b1398-20261122','inline-default-tuple-b1400-20261122')
s=s.replace('lython-b1398-uniform-eager-annotation-20261122','lython-b1400-inline-default-tuple-20261122')
s=s.replace('evidence["caseCount"]==4','evidence["caseCount"]==5')
s=s.replace('Snapshot repeated eager annotations with one read and one stored value','Own the dynamic singleton default slot directly in its tuple')
s=s.replace('jobs=[(eager,"warm"),(eager,"compile-run"),(postponed,"warm"),(observed,"warm"),(helper,"warm")]\nassert len(jobs)==5',
    '''quote=next(case for case in ids if "quoted-control" in case)
jobs=[(postponed,"warm"),(postponed,"compile-run"),(eager,"warm"),(observed,"warm"),(helper,"warm"),(quote,"warm")]
assert len(jobs)==6''')
s=s.replace('.replace("B1396","B1398")','.replace("B1396","B1400")\n    data=data.replace("len(jobs)==5","len(jobs)==6").replace("len(raw[\'jobs\'])==5","len(raw[\'jobs\'])==6").replace("jobs=5,","jobs=6,").replace("[\'jobs\']==5","[\'jobs\']==6").replace("started < 290","started < 345")')
start=s.index('older="')
end=s.index('available={}',start)
s=s[:start]+s[end:]
start=s.index(" core=b/'retained-source-")
end=s.index(" observations=[]",start)
s=s[:start]+s[end:]
s=s.replace('or p.parent.name in owners or p.parent.name==','or p.parent.name==')
start=s.index(' print(json.dumps(dict(free=shutil.disk_usage(b).free,bytes=m.st_size,')
end=s.index('\n"""',start)
s=s[:start]+' print(json.dumps(dict(free=shutil.disk_usage(b).free,redundant=observations)))'+s[end:]
start=s.index("history={")
end=s.index("def check_archive",start)
s=s[:start]+s[end:]
start=s.index('for source,digest in proof["receipts"].items()')
end=s.index('for name,size,digest,folder in sorted',start)
s=s[:start]+'retire=[]\nfree=proof["free"]\n'+s[end:]
s=s.replace('.replace("lython-b1396-fixtures","lython-b1398-fixtures")',
            '.replace("lython-b1396-fixtures","lython-b1400-fixtures").replace("RuntimeMaxSec=342","RuntimeMaxSec=405")')
s=s.replace('.replace("Compiled default admission","Repeated eager annotations")',
            '.replace("Compiled default admission","Inline dynamic default tuple").replace("294","351")')
s=s.replace('(programs/"summarize.py").read_text(encoding="utf-8"))',
            '(programs/"summarize.py").read_text(encoding="utf-8").replace("len(raw[\'jobs\'])==5","len(raw[\'jobs\'])==6"))')
s=s.replace('four complete source goldens','five complete source goldens')
compile(s,"B1400 staging","exec")
(lab/"stage-comparison.py").write_text(s,encoding="utf-8",newline="\n")
