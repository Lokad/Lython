def factory(seed):
    def pick(value=seed+10000):
        return value
    return pick
first = factory(3)
second = factory(3)
value = first()
saved = first.__defaults__
print(type(saved) is tuple, tuple(saved) == saved, saved is second.__defaults__)
print(value is saved[-1], next(iter(saved)) is value, saved.count(value), saved.index(value))
print({saved: 'old'}[(10003,)], saved[:], hash(saved) == hash((10003,)))
first.__defaults__ = second.__defaults__
print(first() is second.__defaults__[0], saved[0] is value)
