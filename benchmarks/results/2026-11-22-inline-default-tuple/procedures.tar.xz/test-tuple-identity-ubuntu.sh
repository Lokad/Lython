#!/bin/bash
set -euo pipefail
cd /mnt/d/code/Lython
export DOTNET_ROOT="$HOME/.dotnet"
export PATH="$DOTNET_ROOT:$PATH"
export DOTNET_HOST_PATH="$DOTNET_ROOT/dotnet"
dir=/mnt/d/code/Lython/.git/agent-notes/review-20261031/inline-default-tuple-20261122
artifact="$dir/identity-ubuntu"
fixture="$artifact/bin/Lokad.Lython.PublicApi.Tests/release_net10.0/Fixtures/Language/Values"
mkdir -p "$fixture"
cp -a tests/Fixtures/Language/Values/FloatAndTuple "$fixture/"
filter='Category!=Stress&(FullyQualifiedName~Tuple|FullyQualifiedName~FunctionDefaultMetadata)'
dotnet test tests/Lokad.Lython.PublicApi.Tests -c Release -f net10.0 --filter "$filter" --artifacts-path "$artifact" --nologo > "$dir/identity-tests-ubuntu.log" 2>&1 || { tail -55 "$dir/identity-tests-ubuntu.log"; exit 1; }
awk '/Passed!/{count++;print} END{exit count!=1}' "$dir/identity-tests-ubuntu.log"
