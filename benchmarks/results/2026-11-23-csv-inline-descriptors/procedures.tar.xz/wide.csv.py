import csv
word = 'é'*20
row = ','.join([word]*1025)
inputs = ['', 'a,b,c,d', '1,2,3,4,5', row, 'a,b,c,d,"begin\n', 'ending",f,g,h', 'k', '']
reader = csv.reader(inputs, strict=True)
kept = []
for fields in reader:
    kept.append(fields)
    print(len(fields), reader.line_num, sum(len(val) for val in fields), fields[:1], fields[-1:])
print(kept[1], kept[2], len(kept[3]), kept[3][512], repr(kept[4][4]), kept[-1])
