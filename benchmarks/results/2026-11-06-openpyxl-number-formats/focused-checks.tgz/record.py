from pathlib import Path
import hashlib,json,shutil,tarfile,subprocess
root=Path(__file__).parent
out=Path('benchmarks/results/2026-11-06-openpyxl-number-formats');out.mkdir()
for name in ('reference.json','focused-results.json'): shutil.copyfile(root/name,out/name)
with tarfile.open(out/'focused-checks.tgz','w:gz') as a:
    for p in sorted(root.iterdir()):
        if p.is_file():a.add(p,arcname=p.name)
(out/'README.md').write_text('''# Excel numeric format correction — P01

Source base: committed text-operation provenance `1e9f53a9`; candidate is the
number-format classifier change recorded with this evidence, not a timing study.

Replace normalized-string construction, broad substring date tests and elapsed
prefix tests with a direct first-section scan. Ignore color/condition/locale
brackets and literals/escapes; recognize exact elapsed tokens. Reuse classification
for numeric conversion, and forward active cancellation into long scans. Keep
existing date conversion/epoch rules, XML bounds and ownership.

CPython 3.13/openpyxl 3.1.5 independently checks 60 numeric rows and 120 ordinary
or cached-formula cells, including all eight standard colors, negative/zero values,
negative-only color/date sections, metadata and escaped/quoted letters. All remain
numeric with their original type/value. Nine genuine date/time/elapsed formats
remain classified. The reference script and output are preserved; this is no claim
of full openpyxl or complete Excel formatting-engine compatibility.

Focused Release: 169 public / 45 internal checks pass on actual .NET 11 RC3 and
.NET 10.0.8; public checks include both public execution APIs, formula caches,
shared allowance cleanup and existing workbook/date-system coverage. Builds have
zero warnings/errors. Original failed build is preserved with its correction.
Full platform/original Stress/installed-package qualification is batched with R17
at this delivery checkpoint. No performance magnitude is inferred from this fix.
''',encoding='utf-8')
p=Path('PLAN.md');s=p.read_text(encoding='utf-8')
start=s.index('## Next high priority: P01 numeric Excel formats')
end=s.index('## R17 closeout:',start)
s=s[:start]+'''## P01 delivered patch: numeric Excel formats

Handoff integrated/removed; original retained privately. Direct first-section
classification replaces normalized strings and misleading substring/prefix tests.
Colors/conditions/locale metadata and literals no longer turn numbers or formula
caches into dates/durations. Exact elapsed tokens and existing epochs remain.
Long scans receive the active cancellation token; no regex dependency required.
CPython/openpyxl3.1.5 reference passes60rows/120cells and9real formats. Focused
Release169public/45internal per actual11/10 pass, including shared-budget cleanup.
Evidence benchmarks/results/2026-11-06-openpyxl-number-formats/. Batch R17+P01
platform/original Stress/installed packages now; no broader workbook redesign.

'''+s[end:]
s=s.replace('## Independent U03: native cursor working admission','## Next independent U03: native cursor working admission')
p.write_text(s,encoding='utf-8')
subprocess.run(['git','diff','--check'],check=True)
paths=['src/Lokad.Lython/Runtime/LythonRuntime.OpenPyxlHelpers.cs',
       'src/Lokad.Lython/Runtime/LythonRuntime.OpenPyxlPackage.LoadWorksheet.cs',
       'tests/Lokad.Lython.PublicApi.Tests/OpenPyxlNumberFormatTests.cs','docs/MODULES.md',str(out)]
subprocess.run(['git','add','--',*paths],check=True)
subprocess.run(['git','diff','--cached','--check'],check=True)
subprocess.run(['git','commit','-m','Preserve numeric Excel values through color format metadata [skip ci]'],check=True)
