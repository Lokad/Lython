import hashlib, json, pathlib, subprocess, time
root = pathlib.Path(__file__).parent
dotnet = 'C:/Users/JoannesVermorel/.dotnet11/dotnet.exe'
results = []
def run(label, args):
    start = time.monotonic()
    with (root/(label+'.log')).open('w', encoding='utf-8') as log:
        p = subprocess.run([dotnet,*args],stdout=log,stderr=subprocess.STDOUT)
    tail = (root/(label+'.log')).read_text(encoding='utf-8')[-1800:]
    results.append({'label':label,'arguments':args,'exitCode':p.returncode,'seconds':time.monotonic()-start,'tail':tail})
    print(label, p.returncode, tail[-450:], flush=True)
    if p.returncode: raise SystemExit(p.returncode)
run('build-internal',['build','tests/Lokad.Lython.Tests','-c','Release'])
for framework in ('net11.0','net10.0'):
    for project, selection in (
        ('Lokad.Lython.PublicApi.Tests','OpenPyxl|FullyQualifiedName~GovernedMemoryContractTests'),
        ('Lokad.Lython.Tests','OpenPyxl|FullyQualifiedName~TextOperationProvenanceTests|FullyQualifiedName~StringWindowOwnershipTests|FullyQualifiedName~DirectStringLowerTests|FullyQualifiedName~InstructionFailureRoutingTests')):
        run(project+'-'+framework,['test','tests/'+project,'-c','Release','-f',framework,'--no-build',
            '--filter','Category!=Stress&(FullyQualifiedName~'+selection+')'])
(root/'focused-results.json').write_text(json.dumps({'checks':results,'coreSHA256':{
    framework:hashlib.sha256(pathlib.Path('src/Lokad.Lython/bin/Release',framework,'Lokad.Lython.dll').read_bytes()).hexdigest()
    for framework in ('net11.0','net10.0')}}, indent=2)+'\n',encoding='utf-8')
