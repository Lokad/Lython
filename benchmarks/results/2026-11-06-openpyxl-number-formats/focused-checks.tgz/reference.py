import io, json, pathlib, re, zipfile, xml.etree.ElementTree as ET
import openpyxl
from openpyxl.styles.numbers import is_date_format, is_timedelta_format

root = pathlib.Path(__file__).parent
text = pathlib.Path('tests/Lokad.Lython.PublicApi.Tests/OpenPyxlNumberFormatTests.cs').read_text(encoding='utf-8')
section = text.split('private static readonly string[] NumericFormats =', 1)[1].split('];', 1)[0]
formats = [json.loads(m.group(0)) for m in re.finditer(r'"(?:\\.|[^"\\])*"', section)]
book = openpyxl.Workbook()
rows = []
for fmt in formats:
    for value in (1.56, -1.56, 0):
        row = len(rows) + 1
        for col, val in ((1, value), (2, f'=A{row}')):
            cell = book.active.cell(row, col, val)
            cell.number_format = fmt
            assert not cell.is_date, fmt
        rows.append((row, fmt, value))
buf = io.BytesIO()
book.save(buf)
parts = {}
with zipfile.ZipFile(buf) as z:
    parts = {name:z.read(name) for name in z.namelist()}
ns = {'m':'http://schemas.openxmlformats.org/spreadsheetml/2006/main'}
sheet = ET.fromstring(parts['xl/worksheets/sheet1.xml'])
for row in sheet.findall('m:sheetData/m:row', ns):
    cells = row.findall('m:c', ns)
    cells[1].find('m:v', ns).text = cells[0].find('m:v', ns).text
parts['xl/worksheets/sheet1.xml'] = ET.tostring(sheet)
buf = io.BytesIO()
with zipfile.ZipFile(buf, 'w') as z:
    for name, data in parts.items(): z.writestr(name, data)
data = openpyxl.load_workbook(io.BytesIO(buf.getvalue()), data_only=True)
formulas = openpyxl.load_workbook(io.BytesIO(buf.getvalue()), data_only=False)
results = []
for row, fmt, value in rows:
    assert formulas.active.cell(row,2).value == f'=A{row}'
    for col in (1,2):
        cell = data.active.cell(row,col)
        assert cell.value == value and type(cell.value) is type(value), (fmt, cell.value)
        assert cell.number_format == fmt and cell.data_type == 'n' and not cell.is_date
    results.append({'format':fmt,'value':value,'type':type(value).__name__,'numericFormulaCache':True})
elapsed = ['[h]','[hh]:mm:ss','[m]','[mm]:ss','[s]','[ss].000']
date = ['[Red]yyyy-mm-dd','[Blue]h:mm:ss','[Yellow]yyyy-mm-dd h:mm:ss']
for fmt in elapsed + date: assert is_date_format(fmt)
for fmt in elapsed: assert is_timedelta_format(fmt)
(root/'reference.json').write_text(json.dumps({'python':__import__('sys').version,'openpyxl':openpyxl.__version__,
    'rows':results,'dateFormats':date,'elapsedFormats':elapsed}, indent=2)+'\n', encoding='utf-8')
print(f'openpyxl {openpyxl.__version__}: {len(rows)} numeric rows / {len(rows)*2} numeric and formula cells; 9 real date/time formats passed')
