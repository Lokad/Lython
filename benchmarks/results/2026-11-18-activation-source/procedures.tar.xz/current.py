from pathlib import Path
import hashlib,json,os,subprocess
r=Path(__file__).resolve().parent
p=r/'inspect/inspect.csproj'
s=p.read_text(encoding='utf-8').replace('frozen/reference/','frozen/candidate/')
p.write_text(s,encoding='utf-8',newline='\n')
d=Path('C:/Users/JoannesVermorel/.dotnet11/dotnet.exe')
env=os.environ.copy();env.update(DOTNET_ROOT=str(d.parent),DOTNET_ROOT_X64=str(d.parent));env['PATH']=str(d.parent)+os.pathsep+env['PATH']
with(r/'current.log').open('w',encoding='utf-8')as log:
    result=subprocess.run([str(d),'run','--project',str(p),'-c','Release','-f','net11.0','--',str(r.parent/'generator-facts-r503/catalog.json'),str(r/'current-ir.json')],env=env,stdout=log,stderr=subprocess.STDOUT,timeout=120)
assert result.returncode==0,(r/'current.log').read_text(encoding='utf-8')
v=json.loads((r/'current-ir.json').read_text(encoding='utf-8-sig'))
f=json.loads((r.parent/'generator-facts-r503/frozen/identity.json').read_text(encoding='utf-8'))
assert v['CoreSha256']==f['imageFiles']['candidate']['Lokad.Lython.dll']
for w in v['Workloads']:
    for c in w['Codes']:
        if c['IsFunctionScope']:
            print(w['Id'],c['Name'],c['ValueStorageCapacity'],c['LookupCacheCount'],c['OpcodeCounts'])
