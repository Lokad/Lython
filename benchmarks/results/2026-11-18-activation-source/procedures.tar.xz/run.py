from pathlib import Path
import hashlib,json,os,subprocess
r=Path(__file__).resolve().parent;d=Path('C:/Users/JoannesVermorel/.dotnet11/dotnet.exe');env=os.environ.copy();env.update(DOTNET_ROOT=str(d.parent),DOTNET_ROOT_X64=str(d.parent));env['PATH']=str(d.parent)+os.pathsep+env['PATH']
if (r/'inspect.log').exists()and not(r/'first-framework-selection.log').exists():(r/'inspect.log').rename(r/'first-framework-selection.log')
cmd=[str(d),'run','--project',str(r/'inspect/inspect.csproj'),'-c','Release','-f','net11.0','--',str(r.parent/'generator-facts-r503/catalog.json'),str(r/'ir.json')]
with(r/'inspect.log').open('w',encoding='utf-8')as log:p=subprocess.run(cmd,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=120)
assert p.returncode==0,(r/'inspect.log').read_text(encoding='utf-8');v=json.loads((r/'ir.json').read_text(encoding='utf-8-sig'));f=json.loads((r.parent/'generator-facts-r503/frozen/identity.json').read_text(encoding='utf-8'));assert v['CoreSha256']==f['imageFiles']['reference']['Lokad.Lython.dll']
for w in v['Workloads']:
 for c in w['Codes']:print(w['Id'],c['Name'],'mirror',c['RequiresLocalVariableMirroring'],'slots',c['ValueStorageCapacity'],'cache',c['LookupCacheCount'],'counts',c['OpcodeCounts'],flush=True)
