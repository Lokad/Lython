from pathlib import Path
from shutil import copyfile
import hashlib
import json
import tarfile

lab = Path(__file__).resolve().parent
first = lab / "comparison/quiet"
repeat = lab.with_name(lab.name + "-confirmation")
quiet = repeat / "comparison/quiet"
target = lab.parents[3] / "benchmarks/results/2026-11-26-borrowed-loop-iterators/confirmation"
read = lambda path: json.loads(path.read_text(encoding="utf-8"))
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
state = read(quiet / "terminal-status.json")
receipt = state["receipt"]
assert state["exitCode"] == "0" and not state["live"] and not state["fixtures"]
assert all(receipt[key] for key in ("complete", "allWorkersJoined", "guestFixturesRemoved", "quietBeforeAndAfter",
                                  "archivedAndVerifiedUnderLease"))
assert receipt["archiveSHA256"] == sha(quiet / "observations.tar.xz") and read(quiet / "summary.json")["timedBatches"] == 112
initial = read(first / "identity.json")
confirmed = read(quiet / "identity.json")
assert initial["imageFiles"] == confirmed["imageFiles"]
assert initial["sourceRevision"] == confirmed["sourceRevision"]
assert initial["sourcePatchSHA256"] == confirmed["sourcePatchSHA256"] == sha(lab / "candidate.patch")
assert initial["catalogs"]["representative.json"] == confirmed["catalogs"]["representative.json"]
assert confirmed["donorArchiveSHA256"] == sha(first / "observations.tar.xz")
with tarfile.open(quiet / "observations.tar.xz") as observations:
    for name in ("representative.json", "jobs.json", "identity.json"):
        assert hashlib.sha256(observations.extractfile(name).read()).hexdigest() == sha(quiet / name)
target.mkdir(parents=True, exist_ok=True)
for name in ("identity.json", "terminal-status.json", "observations.tar.xz", "summary.json"):
    copyfile(quiet / name, target / name)
with tarfile.open(target / "procedures.tar.xz", "w:xz") as archive:
    for folder, names in [(lab, ("archive-confirmation.py", "prepare-confirmation.py")),
                          (repeat, ("quiet.py", "summarize-quiet.py", "launch-console.log", "retrieve.log")),
                          (quiet, ("launch.log", "upload.json"))]:
        for name in names:
            archive.add(folder / name, arcname=name, recursive=False)
