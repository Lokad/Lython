set -eu
export DOTNET_ROOT="$HOME/.dotnet"
export PATH="$DOTNET_ROOT:$PATH"
lab="$PWD/.git/agent-notes/review-20261031/borrowed-loop-iterators-20261126"
filter='Category!=Stress&(FullyQualifiedName~Iteration|FullyQualifiedName~Generator|FullyQualifiedName~Zip|FullyQualifiedName~Csv|FullyQualifiedName~Chunked|FullyQualifiedName~TextFile|FullyQualifiedName~OwnedByteFile|FullyQualifiedName~ManagedStack|FullyQualifiedName~Iterator)'
for suite in Lokad.Lython.Tests Lokad.Lython.PublicApi.Tests; do
    log="$lab/$suite-delivery-ubuntu10.log"
    if dotnet test "tests/$suite/$suite.csproj" -c Release -f net10.0 --artifacts-path "$lab/delivery-ubuntu" --filter "$filter" > "$log" 2>&1; then
        tail -5 "$log"
    else
        tail -40 "$log"
        exit 1
    fi
done
