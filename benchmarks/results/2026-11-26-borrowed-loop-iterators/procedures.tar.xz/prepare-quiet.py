from pathlib import Path
from shutil import copyfile
import hashlib
import json
import tarfile

lab = Path(__file__).resolve().parent
donor = lab.with_name("direct-text-file-loop-20261126")
profile = lab.with_name("json-record-attribution-20261126")
quiet = lab / "comparison/quiet"
local = lab / "local"
quiet.mkdir(parents=True)
read = lambda path: json.loads(path.read_text(encoding="utf-8"))
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
write = lambda path, data: path.write_text(data, encoding="utf-8", newline="\n")
save = lambda path, data: write(path, json.dumps(data, indent=2) + "\n")
base = donor / "comparison/quiet"
identity = read(local / "identity.json")
candidate = local / "candidate"
assert len(identity["imageFiles"]["candidate"]) == 32
assert {p.name:sha(p) for p in candidate.iterdir()} == identity["imageFiles"]["candidate"]
receipt = read(base / "terminal-status.json")["receipt"]
assert receipt["complete"] and receipt["archiveSHA256"] == sha(base / "observations.tar.xz")
assert identity["imageFiles"]["reference"] == read(base / "identity.json")["imageFiles"]["candidate"]
for name in ("identity.json", "jobs.json", "representative.json", "cpython-worker.py", "run.sh"):
    copyfile(local / name, quiet / name)
collect = (base / "collect.py").read_text(encoding="utf-8")
assert collect.count("lython-b1781-fixtures") == 1 and "len(jobs) == 5" in collect
collect = collect.replace("lython-b1781-fixtures", "lython-b1782-fixtures")
compile(collect, "collect.py", "exec")
write(quiet / "collect.py", collect)
entries = [("new-core.dll", candidate / "Lokad.Lython.dll")]
entries.extend((name, quiet / name) for name in (
    "identity.json", "representative.json", "jobs.json", "collect.py", "run.sh", "cpython-worker.py"))
payload = quiet / "stage.tar.gz"
with tarfile.open(payload, "w:gz", compresslevel=6) as archive:
    for name, path in entries:
        archive.add(path, arcname=name, recursive=False)
save(quiet / "upload.json", dict(root="borrowed-loop-iterators-b1782-20261126", payloadSHA256=sha(payload),
    payloadBytes=payload.stat().st_size, expandedBytes=sum(p.stat().st_size for _,p in entries),
    donorSHA256=receipt["archiveSHA256"]))
launcher = (donor / "quiet.py").read_text(encoding="utf-8")
for before, after in (
    ("lython-b1781-direct-text-file-loop-20261126", "lython-b1782-borrowed-loop-iterators-20261126"),
    ("ready-json-construction-b1776-20261126", "direct-text-file-loop-b1781-20261126"),
    ("verified['caseCount']==3", "verified['caseCount']==4"),
):
    assert launcher.count(before) == 1
    launcher = launcher.replace(before, after)
compile(launcher, "quiet.py", "exec")
write(lab / "quiet.py", launcher)
copyfile(donor / "summarize-quiet.py", lab / "summarize-quiet.py")
compact = (profile / "compact-for-quiet.py").read_text(encoding="utf-8")
assert compact.count("+8*1024*1024") == 1
compact = compact.replace("+8*1024*1024", "+5*1024*1024+512*1024")
compile(compact, "compact-for-quiet.py", "exec")
write(lab / "compact-for-quiet.py", compact)
