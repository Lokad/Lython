from pathlib import Path
import hashlib, json, shutil, tarfile

base = Path(__file__).parent
r = base / 'cpython-focused'
repo = Path('D:/code/Lython')
out = repo / 'benchmarks/results/2026-11-17-generator-sum/cpython'
out.mkdir(exist_ok=False)
summary = json.loads((r / 'summary.json').read_text(encoding='utf-8'))
receipt = json.loads((r / 'quiet/archive-receipt.json').read_text(encoding='utf-8'))
assert summary['complete'] and receipt['complete'] and receipt['jobs'] == 4
assert receipt['allWorkersJoined'] and receipt['guestFixturesRemoved'] and receipt['quietBeforeAndAfter']
assert hashlib.sha256((r / 'quiet/observations.tgz').read_bytes()).hexdigest() == receipt['archiveSHA256']
shutil.copyfile(r / 'summary.json', out / 'summary.json')
for name in ['observations.tgz', 'archive-receipt.json', 'terminal-status.json', 'identity.json', 'representative.json']:
    shutil.copyfile(r / 'quiet' / name, out / name)
with tarfile.open(out / 'procedures-and-checks.tar.xz', 'w:xz') as archive:
    for p in list(base.glob('*cpython*.py')):
        archive.add(p, arcname=p.name)
    for folder in ['cpython', 'cpython-focused']:
        for p in (base / folder).rglob('*'):
            if p.is_file() and 'retrieved' not in p.parts and p.name not in ['payload.tgz', 'observations.tgz']:
                archive.add(p, arcname=p.relative_to(base).as_posix())
retirement = json.loads((r / 'quiet/retrieved/retirement-receipt.json').read_text(encoding='utf-8'))
retired = sum(g['bytes'] for g in retirement['retiredOnly'])
(out / 'README.md').write_text(f'''# Generator sum: current CPython checkpoint

B887,2026-11-17UTC. **abcbd9fd / frozenca1a8239 versus stock CPython3.13.16**.
Four separated jobs137.80s; no causal comparison with earlier collections.

| Complete script | Phase | Lython | CPython | Lython / CPython | L/C control spread; maximum IQR |
| --- | --- | ---: | ---: | ---: | --- |
| Floating JSON numeric report | Compilation | 0.0561–0.0562ms | 0.0609–0.0614ms | 0.91–0.92× | 0.19/0.83%;0.80% |
| Same | Warm | 1.614–1.633ms | 0.817–0.826ms | **1.95–2.00×** | 1.22/1.10%;1.28% |
| Same | Compile and execute once | 1.771–1.813ms | 0.965–0.966ms | **1.83–1.88×** | 2.39/0.15%;0.52% |
| CSV invoice | Warm | 6.923–7.151ms | 6.058–6.106ms | **1.13–1.18×** | **3.29**/0.79%;1.03% |

Ratio above one means slower. Floating input4,096paired records/56,495B;
CSV4,096records/127,031B. Complete source/input/output goldens are in the catalog.
Ranges pair two independent process medians/engine, not confidence intervals.
CSV's Lython control moves3.29%; retain uncertainty. No source-change gain or
regression debt closure inferred from earlier ratios.

Quiet AzureF4as_v7/Ubuntu24.04.4,4EPYC9V45vCPUs,16GiB/no swap; .NET11RC3
natural workstation GC/normal tiering, CPythonGIL/GC. Interleaved5s full-request
warmups, five rotated approximately0.5s samples. Warm includes synchronous Run,
mediated RAM I/O, complete stdout/file goldens and prior-result cleanup; excludes
compile/startup/reset/protocol/final cache teardown. Fresh adds compile/compiled
owner disposal; compile includes compiled-owner disposal. Wider CPU includes more
protocol/reset work; phase medians are not additive. Native CPython buffered files
have no equivalent capability/shared-budget checks. No startup, async suspension,
RSS, contention or embedding-tail comparison.

Both frozen32file images passed actual-worker/CPython2case goldens before staging.
All identities/outputs/quiet/Closed/exits/joins/archive checks pass, RAM removed and
terminal cached. Full runtime delivery44041981387 is separate/pending. Initial
six-job catalog staging was refused for disk headroom **before mutation or workers**;
its error/configuration is preserved. A smaller two-case/four-job collection fills
material gaps. No timing was repeated to repair that staging failure. Exact
committed replica proofs retired{retired:,}B; present/absent paths and all inode
aliases were checked, preserving images/toolchains/canonicals and254/252MiBfloors.
Earlier text/report/configuration/search measurements keep their source labels.
Publication remains postponed.

[Summary](summary.json),[catalog](representative.json),[identity](identity.json),
[raw observations](observations.tgz),[custody](archive-receipt.json),
[procedures/checks/original staging failure](procedures-and-checks.tar.xz).
''', encoding='utf-8', newline='\n')
p = repo / 'docs/BENCHMARKS.md'
s = p.read_text(encoding='utf-8-sig')
lines = s.splitlines()
for i, line in enumerate(lines):
    if line.startswith('| Floating JSON numeric report | 4,096'):
        lines[i] = '| Floating JSON numeric report | 4,096 records / 56,495 B | 1.614–1.633 ms | 0.817–0.826 ms | 1.95–2.00× | R475; diagnostic; controls L/C 1.22/1.10%; IQR≤1.28% |'
    elif line.startswith('| CSV invoice | 4,096'):
        lines[i] = '| CSV invoice | 4,096 records / 127,031 B | 6.923–7.151 ms | 6.058–6.106 ms | 1.13–1.18× | R475; diagnostic; moving Lython control 3.29%, CPython 0.79%; IQR≤1.03% |'
    elif line.startswith('| Floating JSON numeric report | Compilation only'):
        lines[i] = '| Floating JSON numeric report | Compilation only | 0.056–0.056 ms | 0.061–0.061 ms | 0.91–0.92× | R475; diagnostic; controls L/C 0.19/0.83%; IQR≤0.80% |'
    elif line.startswith('| Floating JSON numeric report | Compile and execute once'):
        lines[i] = '| Floating JSON numeric report | Compile and execute once | 1.771–1.813 ms | 0.965–0.966 ms | 1.83–1.88× | R475; diagnostic; controls L/C 2.39/0.15%; IQR≤0.52% |'
s = '\n'.join(lines) + '\n'
a = s.index('Measured **2026-11-17 UTC**:')
b = s.index('The two helper workloads', a)
s = s[:a] + '''Measured **2026-11-17 UTC**: floating and CSV warm use **abcbd9fd /
frozenca1a8239**, stock **CPython3.13.16**. Runtime delivery qualification is
pending. Four separated jobs finish137.80s with all measurement gates passed;
same machine and5s boundaries below. [Current checkpoint](../benchmarks/results/2026-11-17-generator-sum/cpython/README.md).
The earlier [R471 baseline](../benchmarks/results/2026-11-17-float-transport/cpython/README.md)
remains preserved, with its fully qualified runtime source and original controls.
''' + s[b:]
s = s.replace('CSV,generator\nnormalization,JSON and search remain earlier', 'CSV compilation/fresh, generator\nnormalization, JSON and search remain earlier')
needle = '| Floating arithmetic-to-iteration transport / complete JSON numeric report |'
entry = '| Native generator sum / complete JSON numeric report | Warm6–10%lower elapsed, fresh15–18%lower, with supporting CPU | Allocation+168–192B/run, accounted numeric peak unchanged. Integer magnitude uncertain (candidate control9.98%); text−0.55..+2.11%with moving reference. [Source pair and checks](../benchmarks/results/2026-11-17-generator-sum/README.md); full delivery pending. |\n'
assert needle in s
s = s.replace(needle, entry + needle, 1)
p.write_text(s, encoding='utf-8', newline='\n')
with (repo / 'benchmarks/EXPERIMENTS.md').open('a', encoding='utf-8', newline='\n') as stream:
    stream.write('''
[R475/B887 CPython checkpoint](results/2026-11-17-generator-sum/cpython/README.md):
abcbd9fd/frozenca1a8239 warm floating1.95–2.00×,fresh1.83–1.88×,compile0.91–0.92×;
CSVwarm1.13–1.18×with3.29%Lython control movement. Fourjobs137.80s, all measurement
gates pass/users joined/RAM removed. Initial larger staging refused before mutation/
workers; reduced catalog fills material gaps, original failure preserved. No causal
source gain across collections. Full runtime delivery separate; publication held.
''')
p = repo / 'PLAN.md'
s = p.read_text(encoding='utf-8').replace('3. Complete B887\'s affected CPython refresh:', '3. B887 CPython refresh complete:')
s = s.replace('   Report exact revision, input, controls, RAM I/O and cleanup boundaries.', '   [Current abcbd9fd baseline](benchmarks/results/2026-11-17-generator-sum/cpython/README.md):\n   floating warm1.95–2.00×, fresh1.83–1.88×, compile0.91–0.92×; CSVwarm1.13–1.18×\n   with moving3.29%Lython control. All gates/join/archive pass in137.80s. Exact\n   revision, input, controls, RAM I/O and cleanup boundaries are recorded.')
p.write_text(s, encoding='utf-8', newline='\n')
print('Current CPython baseline/evidence preserved; no cross-collection gain inferred. Retired only', retired, 'verified replica bytes.')
