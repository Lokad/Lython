from pathlib import Path
import ast, hashlib, io, json, os, shutil, subprocess, tarfile

base = Path(__file__).parent
r = base / 'cpython'
r.mkdir(exist_ok=False)
q = r / 'quiet'; q.mkdir()
repo = Path('D:/code/Lython')
old = base.parent / 'floating-transport-r471/cpython'
f = json.loads((base / 'frozen/identity.json').read_text(encoding='utf-8'))
catalog = json.loads((base / 'catalog.json').read_text(encoding='utf-8'))
ids = ['scripts.numeric-squared-error.floating.large', 'scripts.csv-invoice.large', 'scripts.text-normalization.helper-list', 'scripts.report-render.helper-list']
catalog['cases'] = [c for c in catalog['cases'] if c['id'] in ids]
assert len(catalog['cases']) == 4
(q / 'representative.json').write_text(json.dumps(catalog, indent=2) + '\n', encoding='utf-8')
dotnet = Path('C:/Users/JoannesVermorel/.dotnet11/dotnet.exe')
env = os.environ.copy(); env.update(DOTNET_ROOT=str(dotnet.parent), DOTNET_ROOT_X64=str(dotnet.parent)); env['PATH'] = str(dotnet.parent) + os.pathsep + env['PATH']
for role in ['reference', 'candidate']:
    with (r / (role + '-preflight.log')).open('w', encoding='utf-8') as log:
        p = subprocess.run([str(dotnet), str(base / 'frozen' / role / 'Lokad.Lython.Benchmarks.dll'), '--compare', 'verify', '--catalog', str(q / 'representative.json'), '--dotnet', str(dotnet), '--python', 'C:/Python313/python.exe', '--python-worker', str(repo / 'benchmarks/cpython-worker.py'), '--out', str(r / (role + '-preflight.json'))], env=env, stdout=log, stderr=subprocess.STDOUT)
    assert p.returncode == 0, (r / (role + '-preflight.log')).read_text(encoding='utf-8')
remote = '/home/lokad/lython-bench-checks/generator-sum-cpython-b887-20261117'
identity = dict(sourceRevision='abcbd9fd/frozenca1a8239', purpose='Delivery checkpoint: floating compile/warm/fresh and representative CSV/text/report warm against stock CPython3.13.16. No causal cross-collection gain.',
    coreSHA256={'candidate': f['imageFiles']['candidate']['Lokad.Lython.dll'], 'candidate-control': f['imageFiles']['candidate']['Lokad.Lython.dll']},
    auxiliaryFiles={n:h for n,h in f['imageFiles']['candidate'].items() if n != 'Lokad.Lython.dll'}, imageFiles=f['imageFiles'],
    sourceInputsArchiveSHA256=hashlib.sha256((base / 'candidate-sources.tar.xz').read_bytes()).hexdigest(), productionFiles=585,
    catalogSHA256=hashlib.sha256((q / 'representative.json').read_bytes()).hexdigest(), normalAdapterPin='0.4.0', publicationHeld=True)
(q / 'identity.json').write_text(json.dumps(identity, indent=2) + '\n', encoding='utf-8')
jobs = [[ids[0], 'compile'], [ids[0], 'warm'], [ids[0], 'compile-run']] + [[c, 'warm'] for c in ids[1:]]
s = (old / 'quiet/collect.py').read_text(encoding='utf-8')
a = s.index('jobs='); b = s.index('\nenv =', a)
s = s[:a] + 'jobs=' + repr(jobs) + '\nassert len(jobs)==6 and all(case in cases for case,lane in jobs)\n' + s[b:]
(q / 'collect.py').write_text(s, encoding='utf-8', newline='\n')
(q / 'archive-owned.py').write_text((old / 'quiet/archive-owned.py').read_text(encoding='utf-8').replace('==3', '==6').replace('jobs=3', 'jobs=6'), encoding='utf-8', newline='\n')
(q / 'run.sh').write_text((old / 'quiet/run.sh').read_text(encoding='utf-8').replace('/home/lokad/lython-bench-checks/float-cpython-b881-20261117', remote), encoding='utf-8', newline='\n')
groups = []
for canonical, prefix, raw in [
    ('benchmarks/results/2026-11-17-generator-sum/observations.tgz', 'generator-sum-b886-20261117', True),
    ('benchmarks/results/2026-11-17-float-transport/refined/observations.tgz', 'float-refined-b880-20261117', True),
    ('benchmarks/results/2026-11-17-module-global-bindings/first-pair/observations.tgz', 'global-bindings-b883-20261117', False),
    ('benchmarks/results/2026-11-17-module-global-bindings/confirmation/observations.tgz', 'global-binding-control-b884-20261117', False)]:
    blob = subprocess.check_output(['git', 'show', 'HEAD:' + canonical], cwd=repo)
    assert blob == (repo / canonical).read_bytes()
    if raw:
        with tarfile.open(fileobj=io.BytesIO(blob)) as archive:
            data = archive.extractfile('confirmation/confirmation.json').read()
        groups.append(dict(paths=[prefix + '/confirmation/confirmation.json'], bytes=len(data), links=1, sha256=hashlib.sha256(data).hexdigest(), canonical=canonical, canonicalSHA256=hashlib.sha256(blob).hexdigest(), member='confirmation/confirmation.json', committedBlobVerified=True, optional=True))
    groups.append(dict(paths=[prefix + '/observations.tgz'], bytes=len(blob), links=1, sha256=hashlib.sha256(blob).hexdigest(), canonical=canonical, canonicalSHA256=hashlib.sha256(blob).hexdigest(), member='whole-archive', committedBlobVerified=True, optional=True))
names = ['collect.py', 'archive-owned.py', 'run.sh', 'identity.json', 'representative.json']
with tarfile.open(q / 'payload.tgz', 'w:gz') as archive:
    for name in names: archive.add(q / name, arcname=name)
c = dict(root=remote, unit='lython-b887-generator-cpython-20261117', source='/home/lokad/lython-bench-checks/generator-sum-b886-20261117', sourceRole='candidate', sourceFiles=f['imageFiles']['candidate'], sourceCatalogSHA256=f['diagnosticCatalogSHA256'], catalogSHA256=identity['catalogSHA256'], identity=identity, retireGroups=groups, payloadBytes=(q / 'payload.tgz').stat().st_size, payloadSHA256=hashlib.sha256((q / 'payload.tgz').read_bytes()).hexdigest(), unpackedBytes=sum((q / n).stat().st_size for n in names))
(q / 'config.json').write_text(json.dumps(c, indent=2) + '\n', encoding='utf-8')
s = (old / 'quiet/remote-launch.py').read_text(encoding='utf-8')
a = s.index('c='); b = s.index('\nb=Path(', a); s = s[:a] + 'c=' + repr(c) + s[b:]
s = s.replace(" os.link(source/'representative.json',root/'representative.json')", " # Verified custom catalog arrived in the payload.")
s = s.replace('lython-b881-fixtures', 'lython-b887-fixtures').replace('RuntimeMaxSec=240', 'RuntimeMaxSec=300')
(q / 'remote-launch.py').write_text(s, encoding='utf-8', newline='\n')
s = (old / 'launch.py').read_text(encoding='utf-8').replace('seconds=125', 'seconds=260').replace('125seconds', '260seconds').replace('Three-job', 'Six-job').replace('floating baseline', 'representative checkpoint')
(r / 'launch.py').write_text(s, encoding='utf-8', newline='\n')
(q / 'retrieve.py').write_text((old / 'quiet/retrieve.py').read_text(encoding='utf-8').replace('B881', 'B887').replace("['jobs']==3", "['jobs']==6"), encoding='utf-8', newline='\n')
(r / 'summarize.py').write_text((old / 'summarize.py').read_text(encoding='utf-8').replace("len(raw['jobs'])==3", "len(raw['jobs'])==6"), encoding='utf-8', newline='\n')
for p in list(q.glob('*.py')) + list(r.glob('*.py')): ast.parse(p.read_text(encoding='utf-8'))
print('Verified4case custom catalog on both actual images/CPython;6bounded jobs. Stage', c['unpackedBytes'], 'available committed replica retirement', sum(g['bytes'] for g in groups))
