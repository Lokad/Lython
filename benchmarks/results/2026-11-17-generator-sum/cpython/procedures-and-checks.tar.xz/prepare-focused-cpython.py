from pathlib import Path
r = Path(__file__).parent
s = (r / 'prepare-cpython.py').read_text(encoding='utf-8')
s = s.replace("r = base / 'cpython'", "r = base / 'cpython-focused'")
s = s.replace(", 'scripts.text-normalization.helper-list', 'scripts.report-render.helper-list'", '')
s = s.replace("len(catalog['cases']) == 4", "len(catalog['cases']) == 2")
s = s.replace('len(jobs)==6', 'len(jobs)==4').replace("'==6'", "'==4'").replace("'jobs=6'", "'jobs=4'").replace("['jobs']==6", "['jobs']==4").replace("len(raw['jobs'])==6", "len(raw['jobs'])==4")
s = s.replace("    ('benchmarks/results/2026-11-17-generator-sum/observations.tgz'", "    ('benchmarks/results/2026-11-17-float-transport/cpython/observations.tgz', 'float-cpython-b881-20261117', False),\n    ('benchmarks/results/2026-11-17-generator-sum/observations.tgz'")
s = s.replace('seconds=260', 'seconds=170').replace('260seconds', '170seconds').replace('RuntimeMaxSec=300', 'RuntimeMaxSec=240')
s = s.replace('floating compile/warm/fresh and representative CSV/text/report warm', 'floating compile/warm/fresh and representative CSV warm; initial larger staging refused before mutation/workers, reduced catalog to fit persistent headroom')
s = s.replace('Verified4case custom catalog', 'Verified2case custom catalog').replace('6bounded jobs', '4bounded jobs')
(r / 'prepare-cpython-focused-run.py').write_text(s, encoding='utf-8', newline='\n')
print('Prepared smaller material-gap comparison, preserving original pre-worker staging refusal.')
