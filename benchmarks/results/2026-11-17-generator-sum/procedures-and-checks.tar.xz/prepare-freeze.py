from pathlib import Path
import json, re, subprocess, textwrap

r = Path(__file__).parent
old = r.parent / 'subscript-entry-r474'
source = (old / 'freeze.py').read_text(encoding='utf-8')
source = source.replace("['Runtime/LythonRuntime.Executable.Inputs.cs','Runtime/LythonRuntime.Executable.Interpreter.Dispatch.cs']", "['Runtime/LythonRuntime.BuiltinIterables.Aggregates.cs','Runtime/LythonRuntime.Executable.Interpreter.cs','Runtime/LythonRuntime.Generators.cs']")
source = source.replace("+'GlobalBindingPipelineTests.cs'", "+'GlobalBindingPipelineTests.cs'")
source = source.replace("+['tests/Lokad.Lython.PublicApi.Tests/GlobalBindingPipelineTests.cs']", "+['tests/Lokad.Lython.PublicApi.Tests/GlobalBindingPipelineTests.cs','tests/Lokad.Lython.PublicApi.Tests/NativeGeneratorSumTests.cs']")
source = source.replace('PrivateR474 onc06bc334, two production files: one subscript entry, original numeric/cache/protocol consumers and ownership; no new metadata/owner/backend', 'PrivateR475 on081d2634, three production files: native sum borrows existing generator yield destination; 64B admitted accumulator, general protocols outside running frame, no new owner/backend')
source = source.replace('two-file subscript', 'three-file generator-sum')
(r / 'freeze.py').write_text(source, encoding='utf-8', newline='\n')
work = Path('D:/code/Lython/.git/agent-worktrees/call-operands-r470')
test = (work / 'tests/Lokad.Lython.PublicApi.Tests/NativeGeneratorSumTests.cs').read_text(encoding='utf-8')
rows = []
for i, body in enumerate(re.findall(r'"""(.*?)"""', test, re.S)[:4]):
    body = textwrap.dedent(body).replace("return 'ok'", "print('ok')")
    p = subprocess.run(['C:/Python313/python.exe', '-X', 'utf8', '-I', '-c', body], capture_output=True, text=True, encoding='utf-8')
    assert p.returncode == 0 and p.stdout == 'ok\n', (i, p.stdout, p.stderr)
    rows.append(dict(index=i, source=body, stdout=p.stdout, exitCode=p.returncode))
(r / 'cpython-semantic-goldens.json').write_text(json.dumps(dict(referenceVersion='CPython3.13.2 Windows', rows=rows), indent=2) + '\n', encoding='utf-8')
print('Four independent CPython programs agree; freeze procedure prepared.')
