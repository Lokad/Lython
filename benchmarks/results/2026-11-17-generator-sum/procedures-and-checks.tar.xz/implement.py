from pathlib import Path

work = Path('D:/code/Lython/.git/agent-worktrees/call-operands-r470')
p = work / 'src/Lokad.Lython/Runtime/LythonRuntime.BuiltinIterables.Aggregates.cs'
s = p.read_text(encoding='utf-8-sig')
start = s.index('    private static object Sum(object[]')
end = s.index('    // Numeric phases', start)
s = s[:start] + '''    private static object Sum(object[] arguments, LythonSourceSpan span, ExecutionContext context)
    {
        var total = ReadSumStart(arguments, span);
        if (TrySumExactBytes(arguments[0], total, span, context, out var byteResult)) return byteResult;
        using var cursor = PyIteration.Cursor.Create(arguments[0], span, context);
        ValidateSumStart(total, span);
        // The private accumulator is borrowed by this command's generator only
        // until AdvanceBuffered returns. Fund it through all pulls and cleanup.
        context.MemoryGovernor.Reserve(64, span);
        try
        {
            var sum = new SumState(total);
            var generator = cursor.GetBulkGenerator(context);
            while (true)
            {
                var next = generator is not null && sum.CanBuffer
                    ? generator.AdvanceBuffered(sum, 0) : cursor.TryMoveNext();
                if (!next.HasValue) break;
                if (sum.TryAddResult(ref next)) continue;
                var item = next.Value;
                var result = sum.Total is PyInstance || item is PyInstance
                    ? EvaluateBinaryOperator(BinaryOperatorSyntax.Add, sum.Total, item, context, span)
                    : EvaluateAdd(sum.Total, item, context, span);
                sum.CompleteAddition(item, result);
            }
            return sum.Result;
        }
        finally { context.MemoryGovernor.ReleaseReserved(64); }
    }

    private static async ValueTask<object> SumAsync(object[] arguments, LythonSourceSpan span, ExecutionContext context)
    {
        var total = ReadSumStart(arguments, span);
        // Exact range items and integer addition cannot invoke guest protocols.
        // Reuse checked synchronous iteration; other starts may suspend in __add__.
        if (arguments[0] is PyRange && PyNumberOps.IsInteger(total)) return Sum(arguments, span, context);
        if (TrySumExactBytes(arguments[0], total, span, context, out var byteResult)) return byteResult;
        var cursor = await PyIteration.Cursor.CreateAsync(arguments[0], span, context).ConfigureAwait(false);
        await using (((IAsyncDisposable)cursor).ConfigureAwait(false))
        {
            ValidateSumStart(total, span);
            context.MemoryGovernor.Reserve(64, span);
            try
            {
                var sum = new SumState(total);
                var generator = cursor.GetBulkGenerator(context);
                while (true)
                {
                    var item = generator is not null && sum.CanBuffer
                        ? await generator.AdvanceBufferedAsync(sum, 0).ConfigureAwait(false)
                        : await cursor.TryMoveNextAsync().ConfigureAwait(false);
                    if (!item.HasValue) break;
                    if (sum.TryAddResult(ref item)) continue;
                    var value = item.Value;
                    var result = sum.Total is PyInstance || value is PyInstance
                        ? await EvaluateBinaryOperatorAsync(BinaryOperatorSyntax.Add, sum.Total, value, context, span).ConfigureAwait(false)
                        : EvaluateAdd(sum.Total, value, context, span);
                    sum.CompleteAddition(value, result);
                }
                return sum.Result;
            }
            finally { context.MemoryGovernor.ReleaseReserved(64); }
        }
    }

''' + s[end:]
s = s.replace('    private struct SumState', '    private sealed class SumState')
s = s.replace('        internal readonly object Result', '        internal bool CanBuffer => _phase != SumPhase.General;\n\n        internal object Result')
p.write_text(s, encoding='utf-8', newline='\n')
p = work / 'src/Lokad.Lython/Runtime/LythonRuntime.Generators.cs'
s = p.read_text(encoding='utf-8-sig')
start = s.index('            var frame = _frame;', s.index('private bool AppendBatchCore'))
end = s.index('            if (!next.HasValue)', start)
wrapped = s[start:end]
s = s[:start] + '            var next = AdvanceBuffered(items, limit);\n' + s[end:]
start = s.index('            var frame = _frame;', s.index('private async ValueTask<bool> AppendBatchCoreAsync'))
end = s.index('            if (!next.HasValue)', start)
async_wrapped = s[start:end]
s = s[:start] + '            var next = await AdvanceBufferedAsync(items, limit).ConfigureAwait(false);\n' + s[end:]
marker = '        private PyIterationResult Advance(object sent, LythonRuntimeException? injected)'
methods = '''        // Only same-command consumers borrow the existing yield destination.
        // Unsupported values leave the running frame before consumer protocols.
        internal PyIterationResult AdvanceBuffered(object destination, int limit)
        {
''' + wrapped.replace('BufferYields(items, limit)', 'BufferYields(destination, limit)') + '''            return next;
        }

        internal async ValueTask<PyIterationResult> AdvanceBufferedAsync(object destination, int limit)
        {
''' + async_wrapped.replace('BufferYields(items, limit)', 'BufferYields(destination, limit)') + '''            return next;
        }

'''
assert marker in s
s = s.replace(marker, methods + marker)
p.write_text(s, encoding='utf-8', newline='\n')
p = work / 'src/Lokad.Lython/Runtime/LythonRuntime.Executable.Interpreter.cs'
s = p.read_text(encoding='utf-8-sig')
old = '''            if (destination is PyList list)
            {
                if (list.Count >= Math.Min(_yieldLimit, list.Capacity) - 1) return false;'''
new = '''            if (destination is SumState sum)
            {
                // Native addition invokes no guest code. Leave an unsupported
                // value untouched for ordinary advancement and general addition.
                var item = PyIterationResult.Yield(YieldValue);
                if (!sum.TryAddResult(ref item)) return false;
                TakeYieldValue();
            }
            else if (destination is PyList list)
            {
                if (list.Count >= Math.Min(_yieldLimit, list.Capacity) - 1) return false;'''
assert old in s
s = s.replace(old, new)
p.write_text(s, encoding='utf-8', newline='\n')
print('R475: existing batch lifetime reused for explicitly funded native accumulator; general protocols remain outside running frame.')
