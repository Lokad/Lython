from pathlib import Path
import gzip, hashlib, json, shutil, subprocess, tarfile

r = Path(__file__).parent
repo = Path('D:/code/Lython')
work = repo / '.git/agent-worktrees/call-operands-r470'
out = repo / 'benchmarks/results/2026-11-17-generator-sum'
out.mkdir(exist_ok=False)
decision = 'Retain coherent native generator aggregation: repeated frame entry/exit eliminated; floating warm and fresh elapsed/CPU favorable. Preserve moving integer and text controls, small allocation increase and earlier integer debt.'
summary = json.loads((r / 'summary.json').read_text(encoding='utf-8'))
summary.update(retentionDecisionPending=False, decision=decision)
(out / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n', encoding='utf-8')
for name in ['allocation-summary.json', 'candidate-sources.tar.xz', 'cpython-semantic-goldens.json']:
    shutil.copyfile(r / name, out / name)
shutil.copyfile(r / 'frozen/identity.json', out / 'identity.json')
patch = subprocess.check_output(['git', '-C', str(work), 'diff', '--', 'src'])
assert patch
with gzip.open(out / 'prototype.patch.gz', 'wb') as stream:
    stream.write(patch)
with gzip.open(out / 'candidate-core.dll.gz', 'wb') as stream:
    stream.write((r / 'frozen/candidate/Lokad.Lython.dll').read_bytes())
with gzip.open(out / 'candidate-core.dll.gz', 'rb') as stream:
    assert stream.read() == (r / 'frozen/candidate/Lokad.Lython.dll').read_bytes()
receipt = json.loads((r / 'quiet/archive-receipt.json').read_text(encoding='utf-8'))
assert receipt['complete'] and receipt['allWorkersJoined'] and receipt['guestFixturesRemoved'] and receipt['quietBeforeAndAfter']
assert hashlib.sha256((r / 'quiet/observations.tgz').read_bytes()).hexdigest() == receipt['archiveSHA256']
for name in ['observations.tgz', 'archive-receipt.json', 'terminal-status.json']:
    shutil.copyfile(r / 'quiet' / name, out / name)
with tarfile.open(out / 'procedures-and-checks.tar.xz', 'w:xz') as archive:
    for p in list(r.glob('*.py')) + list(r.glob('*.json')) + list(r.glob('*.log')):
        archive.add(p, arcname=p.name)
    for p in (r / 'quiet').iterdir():
        if p.is_file() and p.name not in ['payload.tgz', 'observations.tgz']:
            archive.add(p, arcname='quiet/' + p.name)
tests = ['tests/Lokad.Lython.PublicApi.Tests/NativeGeneratorSumTests.cs', 'tests/Lokad.Lython.PublicApi.Tests/BuiltinIterationCancellationTests.cs']
with tarfile.open(out / 'final-tests.tar.xz', 'w:xz') as archive:
    for name in tests:
        archive.add(work / name, arcname=name)
validation = dict(productionFiles=3, eachActualWindowsTarget=dict(publicFocused=102, internalFocused=54, existingCancellation=50, finalTargetedCancellationAndGenerator=30), countsOverlap=True,
    independentCPythonPrograms=4, candidateFullCatalogGoldens=13, actualFrozenReferenceAndCandidateCatalogGoldens=3,
    finalTestOnlyChanges='Four generator cancellation rows added after frozen snapshot; final-tests.tar.xz preserves their exact source, production unchanged.',
    priorFailedCondition='Initial new-test expected CLR int instead of projected BigInteger; corrected assertion, original failing log retained. No runtime semantic failure.',
    fullQualification='Pending combined Windows/Ubuntu actual11/10, originalstress and installed Release package consumers.', publicationHeld=True)
(out / 'validation.json').write_text(json.dumps(validation, indent=2) + '\n', encoding='utf-8')
(out / 'README.md').write_text('''# Native sum shares the existing generator batch lifetime

R475/B886,2026-11-17UTC. Qualified dc480d38/frozen5ecb2599 versus three-file
prototype/frozenca1a8239. **Retain this coherent change; full delivery pending.**
Same-command native integer/compensated-floating prefixes use the existing yield
destination, without a materialized batch or repeated generator frame/exception/
managed stack entry per value. General addition runs after ordinary advancement
leaves the frame; unsupported values are not replayed. Existing private-list
buffering shares the extracted entry. No new backend, owner, cache or iterator
framework. The private accumulator changes from a stack struct to one64B-admitted
object, held until its users finish. Nongenerator sum still uses ordinary pulls.
Tiny budgets can reject earlier; the substantial resource protections remain.

| Complete script | Phase | Elapsed change | Wider CPU change | Reference / candidate control spread |
| --- | --- | ---: | ---: | ---: |
| Floating JSON numeric report | Warm | **−10.21..−6.14%** | **−9.69..−5.28%** | 2.68 / 1.81% |
| Same | Compile and execute once | **−17.59..−14.53%** | **−17.12..−13.73%** | 2.14 / 1.55% |
| Integer numeric report | Warm | −13.42..−4.76% | −13.75..−3.98% | 0.03 / **9.98%** |
| Helper text control | Warm | −0.55..+2.11% | −0.79..+1.33% | 2.20 / 0.47% |
| Floating report | Compilation | −0.52..+1.33% | −1.84..+1.86% | 1.81 / 0.04% |

The floating whole-script CPU improvement supports retention; it is distinct from
allocation. Integer magnitude remains uncertain despite favorable pairings, and
R471's earlier integer debt is not declared resolved. Text movement includes a
small adverse result with a moving reference; retain that uncertainty. No causal
attribution of all movement or additive phase subtraction. Natural-GC allocation
increases168B/integer run and192B/floating run (about0.03/0.04%); text flat.
Numeric accounted peak906,718B unchanged, all shared budgets restore baseline.

Five jobs193.92s on quiet AzureF4as_v7/Ubuntu24.04.4/.NET11RC3, natural
workstation GC/normal tiering. Four processes/job, interleaved6s full-request
warmups and five rotated approximately0.5s samples. Ranges pair all process
medians, not confidence intervals. Warm includes synchronous Run, mediated RAM
I/O, complete stdout/file goldens and prior-result cleanup; excludes compilation,
startup/reset/protocol/final cache teardown. Fresh adds compile/compiled-owner
disposal; external CPU is wider. No async, CPython, RSS or embedding-tail gain
inferred. External baseline/representative controls are a separate checkpoint.

Both actual Windows.NET11/10 pass102public/54internal focused checks,50existing
cancellation checks and30final targeted checks (overlapping counts). Four new
generator cancellation cases exercise actual integer/floating drains. Numeric
compensation, overflow, consumer errors outside suspended handlers, reentry,
delegation, active exception restoration, genuine pending I/O, terminal refusal,
awaited cleanup and budget reuse pass. Four independent CPython3.13.2programs
agree. Copied32file images pass actual-worker3case goldens for each source plus
13candidate goldens. Full585production snapshot/nonincremental build preserved;
post-freeze test-only additions preserved separately. Original test-type assertion
failure is retained in the procedure archive, with correction documented.

All image/golden/quiet/Closed/exit/join/archive checks pass; RAM removed and
terminal cached. Fresh UID/path/hash/link/all-alias proofs retire only6,448,719B
of committed withdrawn-core/evidence replicas, preserving current images,
toolchains/canonicals and254/252MiBstaging/final floors. Publication held.

[Summary](summary.json), [allocation](allocation-summary.json),
[raw](observations.tgz), [custody](archive-receipt.json),
[source snapshot](candidate-sources.tar.xz), [final tests](final-tests.tar.xz),
[prototype](prototype.patch.gz), [core](candidate-core.dll.gz),
[identity](identity.json), [validation](validation.json),
[checks/procedures](procedures-and-checks.tar.xz).
''', encoding='utf-8', newline='\n')
with (repo / 'benchmarks/EXPERIMENTS.md').open('a', encoding='utf-8', newline='\n') as stream:
    stream.write('''
[R475/B886 native generator sum](results/2026-11-17-generator-sum/README.md):
retain existing batch-lifetime reuse. Three production files remove repeated frame/
exception/managed-stack entry for closed numeric prefixes; general additions remain
outside the running generator. Floating warm−10.21..−6.14%,fresh−17.59..−14.53%
with supporting widerCPU. Integer favorable but candidate controls9.98%; text
−0.55..+2.11%with moving reference. Allocation+168/+192B, numericpeak unchanged.
No earlier-debt closure inferred. All exact sources/core/observations/failed fixture
condition preserved; pending-I/O/refusal/cancellation/ownership focused checks pass
both actual targets. All VM users joined/RAM removed. Full delivery and external
baseline refresh pending; publication held, broader roadmap remains active.
''')
for name in ['src/Lokad.Lython/Runtime/LythonRuntime.BuiltinIterables.Aggregates.cs', 'src/Lokad.Lython/Runtime/LythonRuntime.Generators.cs', 'src/Lokad.Lython/Runtime/LythonRuntime.Executable.Interpreter.cs'] + tests:
    shutil.copyfile(work / name, repo / name)
print('R475 retained source/tests and complete evidence copied; full delivery pending.')
