from hashlib import sha256
from pathlib import Path
from shutil import copy2, copytree
from subprocess import check_output
import json

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
prior = lab.parent / 'combined-reduction-profile-b1961-20261128'
sample = lab.parent / 'current-mixed-cpython-b1978-20261128/comparison/quiet'
base = lab.parent / 'current-iterable-cpython-b1981-20261128/comparison/quiet'
quiet = lab / 'comparison/quiet'
profile = lab / 'attribution/profile'
layout = lab / 'attribution/layout'
core = 'Lokad.Lython.dll'
read = lambda path: json.loads(path.read_bytes())
digest = lambda path: sha256(path.read_bytes()).hexdigest()
hashes = lambda folder: {path.name: digest(path) for path in folder.iterdir()}


def write(path, text):
    path.write_text(text, encoding='utf-8', newline='\n')


def save(path, data):
    write(path, json.dumps(data, indent=2) + '\n')


head = check_output(['git','rev-parse','HEAD'], cwd=repo, text=True).strip()
assert head.startswith('f231ce76a') and not check_output(['git','status','--porcelain'], cwd=repo)
old = read(base / 'identity.json')
frozen = old['imageFiles']['candidate']
assert len(frozen) == 32 and hashes(base / 'local-image') == frozen
quiet.mkdir(parents=True)
copytree(base / 'local-image', quiet / 'local-image')
measured = old['sourceRevision']
assert measured.startswith('f231ce76a')
assert not check_output(['git','diff',measured,head,'--','src','tests'], cwd=repo)
image = hashes(quiet / 'local-image')
assert image == frozen
assert all(not file.samefile(base / 'local-image' / file.name) for file in (quiet / 'local-image').iterdir())

sample_identity = read(sample / 'identity.json')
assert digest(sample / 'representative.json') == sample_identity['catalogs']['representative.json']['sha256']
catalog = read(sample / 'representative.json')
case_id = 'diagnostic.file-search-first-line'
roles = [('first-line-sync', case_id, 'warm'), ('first-line-async', case_id, 'warm-async')]
catalog['cases'] = [next(case for case in catalog['cases'] if case['id'] == case_id)]
save(quiet / 'representative.json', catalog)
copy2(base / 'cpython-worker.py', quiet / 'cpython-worker.py')
assert digest(quiet / 'cpython-worker.py') == old['cpythonWorkerSHA256']
identity = dict(sourceRevision=measured, inspectedHead=head, imageFiles={'candidate':image},
    expectedCPythonSHA256=old['expectedCPythonSHA256'], cpythonWorkerSHA256=old['cpythonWorkerSHA256'],
    catalogs={'representative.json': {'sha256': digest(quiet / 'representative.json')}}, profiles=roles)
profile.mkdir(parents=True)
layout.mkdir()
save(profile / 'identity.json', identity)
for name in ('representative.json','cpython-worker.py'):
    copy2(quiet / name, profile.parent / name)
scripts = prior / 'attribution/profile'
for name in ('run.sh','analyze-managed.py'):
    copy2(scripts / name, profile / name)
source = (scripts / 'collect.py').read_text(encoding='utf-8')
assert source.count('verification["caseCount"]==5') == 1
write(profile / 'collect.py', source.replace('verification["caseCount"]==5', 'verification["caseCount"]==1'))
assert b'\r' not in (profile / 'run.sh').read_bytes()
for name in ('InspectLayout.csproj','packages.lock.json','Program.cs'):
    copy2(prior / 'attribution/layout' / name, layout / name)
script = (base.parents[1] / 'verify.sh').read_text(encoding='utf-8')
write(lab / 'verify.sh', script.replace('current-iterable-cpython-b1981-20261128', lab.name))
print(head, 'two prepared warmed profiles')
