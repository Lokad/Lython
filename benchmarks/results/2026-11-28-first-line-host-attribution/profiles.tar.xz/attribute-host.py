from collections import Counter
from pathlib import Path
import json

root=Path(__file__).resolve().parent/'attribution/profile'
wait_marks=('WaitSubsystem+ThreadWaitInfo.Wait','LowLevelThreadBlocker.TimedWait','PollGCWorker','SynchronousWorkItem.Wait')
rows=[]
for role in ('first-line-sync','first-line-async'):
    capture=json.loads((root/role/'run.speedscope.json').read_bytes())
    frames=[f['name'].split('(',1)[0].split('!',1)[-1] for f in capture['shared']['frames']]
    leaves={kind: Counter() for kind in ('open','wrapper')}
    for profile in capture['profiles']:
        stack=[]
        previous=profile['startValue']
        for event in profile['events']:
            interval=event['at']-previous
            if interval>0 and stack and stack[-1]!='UNMANAGED_CODE_TIME' and not any(mark in f for f in stack for mark in wait_marks):
                concrete=next((f for f in reversed(stack) if f not in ('CPU_TIME','UNMANAGED_CODE_TIME')),None)
                if any('ExecutionState+' in f and '<OpenFileAsync>b__' in f for f in stack):
                    leaves['open'][concrete]+=interval
                if any('HostOperation+<AwaitAsync>' in f for f in stack):
                    leaves['wrapper'][concrete]+=interval
            if event['type']=='O': stack.append(frames[event['frame']])
            else: assert stack.pop() == frames[event['frame']]
            previous=event['at']
    rows.append(dict(role=role, regions={kind:dict(resolvedMilliseconds=sum(leaf.values()),leafMilliseconds=leaf.most_common(20)) for kind,leaf in leaves.items()}))
(root/'host-leaves.json').write_text(json.dumps(rows,indent=2)+'\n',encoding='utf-8',newline='\n')
for row in rows:
    for kind,region in row['regions'].items():
        print(row['role'],kind,round(region['resolvedMilliseconds'],2),
              [(name,round(ms,2)) for name,ms in region['leafMilliseconds'][:4]])
