from pathlib import Path
import ast,datetime,hashlib,json,shlex,subprocess

r=Path(__file__).resolve().parent;payload=(r/'payload.tgz').read_bytes()
footprint=json.loads((r/'footprint.json').read_text(encoding='utf-8'))
config=dict(payloadBytes=len(payload),payloadSHA256=hashlib.sha256(payload).hexdigest(),
    required=footprint['requiredFreeBytes'],coresToRetire=json.loads((r/'superseded-cores.json').read_text(encoding='utf-8')),
    expectedCores=json.loads((r/'identity.json').read_text(encoding='utf-8'))['coreSHA256'],exactCopies=json.loads((r/'exact-copies.json').read_text(encoding='utf-8')))
script=r'''from pathlib import Path
import ast,fcntl,hashlib,io,json,os,shutil,stat,subprocess,sys,tarfile
config=CONFIG
base=Path('/home/lokad/lython-bench-checks').resolve();root=base/'json-cpython-b566-20261111';source=base/'json-string-b565-20261111/reference';fixture=root/'guest-fixtures'
with(base/'comparison-vm.lock').open('a')as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert not root.exists()and not list(Path('/dev/shm').glob('lython-comparison-files-*'))
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record|[c]omplete-jobs.dll|[p]ython3.13.*cpython-worker.py'],capture_output=True).returncode==1
 payload=sys.stdin.buffer.read(config['payloadBytes']+1);assert len(payload)==config['payloadBytes']and hashlib.sha256(payload).hexdigest()==config['payloadSHA256']
 with tarfile.open(fileobj=io.BytesIO(payload),mode='r:gz')as a:
  for name,role in [('current-core.dll','candidate')]:
   assert hashlib.sha256(a.extractfile(name).read()).hexdigest()==config['expectedCores'][role]
 assert hashlib.sha256((source/'Lokad.Lython.dll').read_bytes()).hexdigest()=='c27160d53d66489976b181fb425b2f46c927fa85156433b80dc6f5477a3e5506'
 stable=source/'Lokad.Lython.dll'
 assert hashlib.sha256(stable.read_bytes()).hexdigest()=='c27160d53d66489976b181fb425b2f46c927fa85156433b80dc6f5477a3e5506'
 protocol=base/'prepared-call-layout-b384-20261107/cpython-worker.py'
 assert hashlib.sha256(protocol.read_bytes()).hexdigest()=='02ca606af6b937a5bec8da744da36e6dbea45ef14ee7207732f34da052ad32f1'
 before=shutil.disk_usage(base).free;retired=[];reclaim=0
 if before<=config['required']:
  for proof in config['coresToRetire']:
   firstPath=base/proof['knownPath'];first=firstPath.lstat();key=(first.st_dev,first.st_ino)
   assert first.st_size==proof['bytes']and hashlib.sha256(firstPath.read_bytes()).hexdigest()==proof['sha256']
   aliases=[]
   for folder,dirs,files in os.walk(base):
    for name in files:
     path=Path(folder)/name;st=path.lstat()
     if(st.st_dev,st.st_ino)!=key:continue
     assert path.resolve(strict=True).is_relative_to(base)and stat.S_ISREG(st.st_mode)and st.st_uid==os.getuid()
     aliases.append(path.relative_to(base).as_posix())
   assert len(aliases)==first.st_nlink and aliases and proof['knownPath']in aliases
   assert proof['sha256']not in[config['expectedCores']['candidate'],'c27160d53d66489976b181fb425b2f46c927fa85156433b80dc6f5477a3e5506']
   reclaim+=first.st_blocks*512;retired.append(dict(proof,paths=aliases,allocatedBytes=first.st_blocks*512,allHardlinkAliasesVerified=True))
  for exact in config['exactCopies']:
   path=base/exact['path'];st=path.lstat()
   assert path.resolve(strict=True).is_relative_to(base)and stat.S_ISREG(st.st_mode)and st.st_uid==os.getuid()and st.st_nlink==1
   assert st.st_size==exact['bytes']and hashlib.sha256(path.read_bytes()).hexdigest()==exact['sha256']
   reclaim+=st.st_blocks*512;retired.append(dict(exact,paths=[exact['path']],allocatedBytes=st.st_blocks*512,allHardlinkAliasesVerified=True))
  assert before+reclaim>config['required'],(before,reclaim,config['required'])
  for proof in retired:
   for path in proof['paths']:(base/path).unlink()
 assert hashlib.sha256(stable.read_bytes()).hexdigest()=='c27160d53d66489976b181fb425b2f46c927fa85156433b80dc6f5477a3e5506'
 assert hashlib.sha256((source/'Lokad.Lython.dll').read_bytes()).hexdigest()=='c27160d53d66489976b181fb425b2f46c927fa85156433b80dc6f5477a3e5506'
 assert shutil.disk_usage(base).free>config['required']
 beforeExtractionFreeBytes=shutil.disk_usage(base).free
 with tarfile.open(fileobj=io.BytesIO(payload),mode='r:gz')as a:root.mkdir();a.extractall(root,filter='data')
 recovery=dict(beforeFreeBytes=before,afterRecoveryFreeBytes=beforeExtractionFreeBytes,postExtractionFreeBytes=shutil.disk_usage(base).free,requiredFreeBytes=config['required'],freshIdleLease=True,verifiedReplacementInPayload=True,files=retired,osFloorMiB=240,evidenceHeadroomMiB=12,qualifiedB8BaselinePreserved=True)
 (root/'space-recovery.json').write_text(json.dumps(recovery,indent=2)+'\n')
 shutil.copyfile(protocol,root/'cpython-worker.py')
 for role in ['candidate']:
  shutil.copytree(source,root/role,copy_function=os.link)
  (root/role/'Lokad.Lython.dll').unlink();os.link(root/('baseline-core.dll'if role=='reference'else'current-core.dll'),root/role/'Lokad.Lython.dll')
 identity=json.loads((root/'identity.json').read_text())
 for role in ['candidate']:
  for name,digest in{**identity['auxiliaryFiles'],'Lokad.Lython.dll':identity['coreSHA256'][role]}.items():assert hashlib.sha256((root/role/name).read_bytes()).hexdigest()==digest,(role,name)
 assert hashlib.sha256((root/'representative.json').read_bytes()).hexdigest()==identity['catalogSHA256']
 for name in ['collect.py','archive-owned.py']:ast.parse((root/name).read_text())
 subprocess.run(['/bin/sh','-n',str(root/'run.sh')],check=True)
 fixture.mkdir();subprocess.run(['sudo','-n','mount','-t','tmpfs','-o','size=128m,mode=0700,uid=lokad,gid=lokad','lython-b566-fixtures',str(fixture)],check=True)
 setup=dict(freeBytes=shutil.disk_usage(base).free,imagesVerified=True,jobs=6,ownerSeconds=210,stopSeconds=30,marginSeconds=30,osFloorMiB=240,evidenceHeadroomMiB=12)
 assert setup['freeBytes']>252*1024*1024
 (root/'setup.json').write_text(json.dumps(setup,indent=2)+'\n');print(json.dumps(setup),flush=True)
try:
 subprocess.run(['sudo','-n','systemd-run','--unit=lython-b566-json-cpython-20261111','--property=User=lokad','--property=WorkingDirectory='+str(root),'--property=RuntimeMaxSec=210','--property=TimeoutStopSec=30','--property=KillMode=control-group','/bin/sh',str(root/'run.sh')],check=True)
except BaseException:
 subprocess.run(['sudo','-n','umount',str(fixture)],check=True);fixture.rmdir();raise
live=subprocess.check_output(['systemctl','show','lython-b566-json-cpython-20261111.service','--property=ActiveState,MainPID,RuntimeMaxUSec'],text=True)
assert'ActiveState=active'in live and'MainPID=0'not in live;print(live,flush=True)
'''.replace('CONFIG',repr(config))
ast.parse(script);(r/'launch-command.py').write_text(script,encoding='utf-8',newline='\n')
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
stage='/home/lokad/lython-bench-checks/json-cpython-b566-launch.py'
code='from pathlib import Path;import sys;p=Path('+repr(stage)+');assert not p.exists();p.write_bytes(sys.stdin.buffer.read())'
done=subprocess.run(ssh+['python3 -c '+shlex.quote(code)],input=script.encode('utf-8'),capture_output=True);assert done.returncode==0,done.stderr
done=subprocess.run(ssh+['python3 '+stage],input=payload,capture_output=True)
(r/'launch.log').write_bytes(done.stdout+b'\n'+done.stderr);assert done.returncode==0,done.stderr.decode('utf-8')
assert b'ActiveState=active'in done.stdout and b'MainPID=0'not in done.stdout
now=datetime.datetime.now(datetime.timezone.utc)
(r/'observe-not-before.json').write_text(json.dumps(dict(acknowledgedUTC=now.isoformat(),doNotObserveBeforeUTC=(now+datetime.timedelta(seconds=270)).isoformat(),ownerSeconds=210,stopSeconds=30,marginSeconds=30),indent=2)+'\n',encoding='utf-8',newline='\n')
print(done.stdout.decode('utf-8'),flush=True);print('Observe after',(now+datetime.timedelta(seconds=270)).isoformat(),flush=True)
