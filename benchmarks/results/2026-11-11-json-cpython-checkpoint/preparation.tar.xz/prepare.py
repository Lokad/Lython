from pathlib import Path
import ast,hashlib,io,json,shutil,subprocess,tarfile

root=Path(__file__).resolve().parent;repo=Path('D:/code/Lython');out=root/'b566';out.mkdir()
old=root.parent/'cpython-construction-r209/b561';launch_base=root.parent/'json-string-decoder-r217/b565'
write=lambda p,s:p.write_text(s,encoding='utf-8',newline='\n')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
runtime='e122bdf6787bdf46e600a328b4e73ddd00766a5c'
assert subprocess.run(['git','diff','--quiet',runtime,'--','src/Lokad.Lython'],cwd=repo).returncode==0
assert subprocess.run(['git','diff','--quiet','69644713','b8b05ccc','--','src/Lokad.Lython','Directory.Build.props','Directory.Packages.props','global.json'],cwd=repo).returncode==0
names=subprocess.check_output(['git','ls-files','src/Lokad.Lython'],cwd=repo,text=True).splitlines()
sources={n:hashlib.sha256((repo/n).read_bytes().replace(b'\r\n',b'\n')).hexdigest()for n in names if n.endswith('.cs')}
assert len(sources)==568
source_identity=dict(runtimeRevision=runtime,buildRevision=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip(),normalizedSource=sources,
    coreSHA256={f:sha(repo/f'src/Lokad.Lython/bin/Release/{f}/Lokad.Lython.dll')for f in ['net11.0','net10.0']},
    boundary='Forced fresh postcommit Release benchmark/core/adapter build, both targets; all production sources equal committed e122. Actual core images frozen before use. Full deliveryCI42928757271 remains separate/pending.')
write(out/'source-identity.json',json.dumps(source_identity,indent=2)+'\n')
core=repo/'src/Lokad.Lython/bin/Release/net11.0/Lokad.Lython.dll'
shutil.copyfile(core,out/'current-core.dll')
def committed(path):
    relative=path.relative_to(repo).as_posix();blob=path.read_bytes()
    assert blob==subprocess.check_output(['git','show','HEAD:'+relative],cwd=repo)
    return blob,relative
archive=repo/'benchmarks/results/2026-11-10-json-cpython-checkpoint/observations.tgz'
blob,_=committed(archive)
with tarfile.open(fileobj=io.BytesIO(blob))as t:catalog=json.loads(t.extractfile('representative.json').read())
ids=['scripts.report-render.large','scripts.json-summary-helpers.large']
catalog['cases']=[next(c for c in catalog['cases']if c['id']==name)for name in ids]
write(out/'representative.json',json.dumps(catalog,ensure_ascii=False,indent=2)+'\n')
base=json.loads((old/'identity.json').read_text(encoding='utf-8'))
identity=dict(sourceRevision='Fresh postcommit7714144f, all568production sources equal committed e122bdf6/0.11.0 complete JSON string decoder;193internal/811public JSON checks per actual11/10 pass. DeliveryCI42928757271 pending separately. Two unchanged representative JSON/report scripts, three phases, no single-change attribution.',coreSHA256={n:sha(core)for n in ['candidate','candidate-control']},auxiliaryFiles=base['auxiliaryFiles'],catalogSHA256=sha(out/'representative.json'),performanceQualified=False)
write(out/'identity.json',json.dumps(identity,indent=2)+'\n')
for name in ['collect.py','archive-owned.py','run.sh','retrieve.py','summarize.py']:
    s=(old/name).read_text(encoding='utf-8').replace('construction-cpython-b561-20261110','json-cpython-b566-20261111').replace('lython-b561-construction-cpython-20261110','lython-b566-json-cpython-20261111')
    s=s.replace('B561','B566').replace("['elapsedSeconds']<300","['elapsedSeconds']<210")
    if name=='collect.py':
        lines=s.splitlines();i=next(i for i,line in enumerate(lines)if line.startswith('jobs='));lines[i]='jobs='+repr([[name,lane]for name in ids for lane in ['compile','warm','compile-run']]);s='\n'.join(lines)+'\n'
        s=s.replace('time.monotonic()-started < 260','time.monotonic()-started < 170')
        a=s.index("purpose='");b=s.index("',\n",a)
        s=s[:a]+"purpose='R218 committed e122bdf6 complete JSON/report checkpoint versus stockCPython3.13.16. Fresh postcommit771 build, all568 source hashes verified;193internal/811public eachtarget pass, deliveryCI pending. Compile/warm/compile-to-result separate; full I/O/checks/prior-result cleanup included, reset/protocol/startup excluded; no single-change attribution"+s[b:]
    if name.endswith('.py'):ast.parse(s)
    write(out/name,s)
write(out/'contract.md','''# R218 JSON/report CPython checkpoint

Two unchanged complete representative scripts,6jobs across compile/warm/compile-run.
Fresh postcommit7714144f binary equals committed e122 production source; both actual
TFMs built, .NET11 timed. Fixed fec79 worker/host/0.4 adapter and CPython3.13.16.
Four independent engine/control processes,5swarmup,7rotated150msrounds,normalGC/tiering.
210sowner/30stop/30margin. Included: full mediated RAM I/O, output/file validation,
prior-result cleanup. Excluded: fixture reset, separate verification, protocol,
startup/final cache teardown. Source-labelled absolute comparison, no attribution
to one change, pending-I/O/embedding-tail claim or new framework. Preserve all
controls/adversity; final platform/package source qualification remains separate.
''')
prep=repo/'benchmarks/results/2026-11-11-json-string-decoder/preparation.tar.xz'
blob,canonical=committed(prep)
with tarfile.open(fileobj=io.BytesIO(blob))as t:baseline=t.extractfile('baseline/net11.0/Lokad.Lython.dll').read()
protected=hashlib.sha256(baseline).hexdigest()
before=json.loads((repo/'benchmarks/results/2026-11-11-json-string-decoder/identity.json').read_text(encoding='utf-8'))['base']
assert protected==before['coreSHA256']['net11.0']
promotion=dict(protectedVMPath='json-string-b565-20261111/reference/Lokad.Lython.dll',protectedSHA256=protected,canonical=canonical,member='baseline/net11.0/Lokad.Lython.dll',bytes=len(baseline),runtimeSource='b8b05ccc production/configuration equals fully qualified69644713; cachedGREEN42918112217. Fresh forced baseline build/source map and exact committed bytes retained.',sourceEquivalenceVerified=True,sourceCount=len(before['normalizedSource']),prior0eSuperseded=True)
write(out/'qualified-baseline-promotion.json',json.dumps(promotion,indent=2)+'\n')
retire=[]
for path,member,known in [
 (repo/'benchmarks/results/2026-11-10-construction-cpython-checkpoint/observations.tgz','current-core.dll','construction-cpython-b561-20261110/candidate/Lokad.Lython.dll'),
 (repo/'benchmarks/results/2026-11-11-json-string-decoder/quiet/observations.tgz','current-core.dll','json-string-b565-20261111/candidate/Lokad.Lython.dll')]:
    blob,canonical=committed(path)
    with tarfile.open(fileobj=io.BytesIO(blob))as t:data=t.extractfile(member).read()
    retire.append(dict(knownPath=known,canonical=canonical,member=member,bytes=len(data),sha256=hashlib.sha256(data).hexdigest()))
assert retire[0]['sha256']=='0e2bc55bac5ebfafd9d30014e34e2afb3e9776bbe6b5d83a53cc710c0d99c492'
assert protected not in [r['sha256']for r in retire]and sha(core)not in[r['sha256']for r in retire]
blob,canonical=committed(repo/'benchmarks/results/2026-11-11-json-string-decoder/quiet/observations.tgz')
exact=[dict(path='json-string-b565-20261111/observations.tgz',canonical=canonical,bytes=len(blob),sha256=hashlib.sha256(blob).hexdigest())]
write(out/'superseded-cores.json',json.dumps(retire,indent=2)+'\n');write(out/'exact-copies.json',json.dumps(exact,indent=2)+'\n')
with tarfile.open(out/'payload.tgz','w:gz')as t:
    for name in ['representative.json','identity.json','collect.py','archive-owned.py','run.sh','contract.md','current-core.dll']:t.add(out/name,arcname=name)
with tarfile.open(out/'payload.tgz')as t:footprint=sum(((m.size+4095)//4096)*4096 for m in t.getmembers()if m.isfile())+128*1024
size=(out/'payload.tgz').stat().st_size
write(out/'footprint.json',json.dumps(dict(payloadBytes=size,footprintBytes=footprint,requiredFreeBytes=(240+12)*1024*1024+max(footprint,3*size)),indent=2)+'\n')
s=(launch_base/'launch.py').read_text(encoding='utf-8').replace('json-string-b565-20261111','json-cpython-b566-20261111').replace('lython-b565-json-string-20261111','lython-b566-json-cpython-20261111').replace('json-string-b565-launch.py','json-cpython-b566-launch.py').replace('lython-b565-fixtures','lython-b566-fixtures')
s=s.replace("source=base/'construction-cpython-b561-20261110/candidate'","source=base/'json-string-b565-20261111/reference'")
s=s.replace("[('baseline-core.dll','reference'),('current-core.dll','candidate')]","[('current-core.dll','candidate')]")
s=s.replace("config['expectedCores']['reference']","config['expectedCores']['candidate']")
s=s.replace('0e2bc55bac5ebfafd9d30014e34e2afb3e9776bbe6b5d83a53cc710c0d99c492',protected)
s=s.replace("for role in ['reference','candidate']:","for role in ['candidate']:")
s=s.replace('fullyQualified0ePreserved=True','qualifiedB8BaselinePreserved=True')
s=s.replace('jobs=3,ownerSeconds=150','jobs=6,ownerSeconds=210').replace('RuntimeMaxSec=150','RuntimeMaxSec=210').replace('ownerSeconds=150','ownerSeconds=210').replace('seconds=210','seconds=270')
ast.parse(s);write(out/'launch.py',s)
assert 'current-text-b562'not in s and'transient-split-b555'not in s
print('Prepared six-job checkpoint; current core',sha(core),'required bytes',json.loads((out/'footprint.json').read_text())['requiredFreeBytes'],flush=True)
