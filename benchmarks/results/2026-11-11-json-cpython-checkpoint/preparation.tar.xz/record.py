from pathlib import Path
import hashlib
import json
import shutil
import subprocess
import tarfile

repo = Path('D:/code/Lython')
source = Path(__file__).parent / 'b566'
target = repo / 'benchmarks/results/2026-11-11-json-cpython-checkpoint'
target.mkdir(exist_ok=True)
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
summary = json.loads((source / 'summary.json').read_text(encoding='utf-8'))
receipt = json.loads((source / 'archive-receipt.json').read_text(encoding='utf-8'))
identity = json.loads((source / 'source-identity.json').read_text(encoding='utf-8'))
assert summary['complete'] and summary['jobs'] == 6
assert sha(source / 'observations.tgz') == receipt['archiveSHA256']
assert sha(source / 'current-core.dll') == summary['coreSHA256']['candidate']
for name, digest in identity['normalizedSource'].items():
    content = subprocess.check_output(['git', 'show', identity['runtimeRevision'] + ':' + name], cwd=repo)
    assert hashlib.sha256(content.replace(b'\r\n', b'\n')).hexdigest() == digest, name
assert len(identity['normalizedSource']) == 568

guide = repo / 'docs/BENCHMARKS.md'
shutil.copyfile(guide, target / 'prior-BENCHMARKS.md')
for name in ['summary.json', 'identity.json', 'source-identity.json', 'archive-receipt.json',
             'terminal-status.json', 'extraction.json', 'observations.tgz',
             'qualified-baseline-promotion.json']:
    shutil.copyfile(source / name, target / name)
shutil.copyfile(source / 'retrieved/space-recovery.json', target / 'space-recovery.json')

# Preserve the original misleading console print in the preparation archive;
# correct the reusable local recipe only after capturing it.
with tarfile.open(target / 'preparation.tar.xz', 'w:xz') as archive:
    for path in sorted(source.iterdir()):
        if path.is_file() and path.suffix in {'.json', '.py', '.sh', '.md', '.log'}:
            archive.add(path, arcname=path.name)
    archive.add(source / 'current-core.dll', arcname='final/net11.0/Lokad.Lython.dll')
    for name in ['build.log', 'prepare.py', 'record.py']:
        archive.add(source.parent / name, arcname=name)

for name in ['preparation.tar.xz', 'observations.tgz']:
    with tarfile.open(target / name) as archive:
        for member in archive.getmembers():
            if member.isfile():
                assert len(archive.extractfile(member).read()) == member.size
(target / 'archive-identity.json').write_text(json.dumps({name: {
    'bytes': (target / name).stat().st_size, 'sha256': sha(target / name)}
    for name in ['preparation.tar.xz', 'observations.tgz']}, indent=2) + '\n', encoding='utf-8')

retrieve = source / 'retrieve.py'
retrieve.write_text(retrieve.read_text(encoding='utf-8').replace('B566 nine-job', 'B566 six-job'), encoding='utf-8')

def table_row(row, include_input=False):
    report = row['case'] == 'scripts.report-render.large'
    label = 'JSON-to-Markdown report' if report else 'JSON-lines/helpers'
    cells = [label]
    if include_input:
        cells.append('3,072 records / 189,441 B' if report else '4,096 records / 110,592 B')
    compile_only = row['lane'] == 'compile'
    def times(values):
        factor, decimals, unit = (1000, 1, 'µs') if compile_only else (1, 3, 'ms')
        return f'{values[0] * factor:.{decimals}f}–{values[-1] * factor:.{decimals}f} {unit}'
    cells += [times(row['timeRangeMilliseconds']), times(row['pythonTimeRangeMilliseconds']),
              f"{min(row['ratioRange']):.2f}–{max(row['ratioRange']):.2f}×", '`e122`',
              f"{row['status']}; L{row['controlPercent']:.2f}%, P{row['pythonControlPercent']:.2f}% / {max(row['iqrPercent'].values()):.2f}%"]
    return '| ' + ' | '.join(cells) + ' |'

text = guide.read_text(encoding='utf-8')
lines = text.splitlines()
lane = 'compile-run'
for i, line in enumerate(lines):
    if line.startswith('Warm execution reuses'):
        lane = 'warm'
    if line.startswith('Compilation alone includes'):
        lane = 'compile'
    if line.startswith('| JSON-lines/helpers |') or line.startswith('| JSON-to-Markdown report |'):
        report = line.startswith('| JSON-to-Markdown report |')
        row = next(r for r in summary['timing'] if r['lane'] == lane and (r['case'] == 'scripts.report-render.large') == report)
        lines[i] = table_row(row, include_input=lane == 'compile-run')
text = '\n'.join(lines) + '\n'
text = text.replace('**Measured sources:** `e543` = committed `e543bf15`, 2026-11-10 (CSV validation\nand text); `8d44` = `8d44bd4e`, 2026-11-10 (report and JSON-lines);',
    '**Measured sources:** `e122` = committed `e122bdf6`, 2026-11-11 (report and\nJSON-lines); `e543` = `e543bf15`, 2026-11-10 (CSV validation and text);')
text = text.replace('Other rows retain their recorded sources: [report/JSON-lines](../benchmarks/results/2026-11-10-json-cpython-checkpoint/README.md),',
    'The [report/JSON-lines checkpoint](../benchmarks/results/2026-11-11-json-cpython-checkpoint/README.md)\nuses fresh postcommit core `9dadd59b` from build `7714144f`, all568 source hashes\nmatching runtime `e122bdf6`. Full platform qualification is pending separately.\nOther rows retain their recorded sources:')
text = text.replace('core `0e2bc55b` (`e543bf15`); report/JSON-lines use `e294fad1` (`8d44bd4e`);',
    'core `0e2bc55b` (`e543bf15`); report/JSON-lines use `9dadd59b` (`e122bdf6`);')
old = '''Report and JSON-lines retain the earlier `8d44` checkpoint. Report warm max IQR
4.94% and complete Lython 3.86% / CPython 9.70% control spread remain explicit.
JSON-lines warm Lython spread 2.50% / max IQR 5.47%, compile max IQR 3.36% and
complete CPython spread 2.35% remain variable. Keyword-default search retains
earlier-source warm 1.50–1.52×. All original observations survive.'''
new = '''The current report/JSON-lines checkpoint completes six jobs in165.178seconds,
with all collection gates passing. Report warm is1.18–1.23× CPython and complete
execution1.09–1.13×. Warm max IQR6.35% and complete CPython control3.35% / max
IQR6.61% limit precision. JSON-lines warm0.86–0.89× and complete0.86–0.88× are
also variable: warm Lython control2.32%, compile3.81% and complete max IQR5.66%.
These state measurements do not isolate the JSON decoder change. The previous
`8d44` measurements and their adversity remain linked in the checkpoint evidence.
Keyword-default search retains earlier-source warm1.50–1.52×.'''
assert old in text
text = text.replace(old, new)
guide.write_text(text, encoding='utf-8', newline='\n')

rows = '\n'.join(table_row(r) for r in summary['timing'])
readme = f'''# R218 — current JSON/report checkpoint against CPython

Measured2026-11-11 on the quiet Azure F4as_v7, Ubuntu24.04.4, four EPYC9V45
vCPUs,16GiB/no swap; actual.NET11RC3 and isolated CPython3.13.16, ordinary
GC/tiering. Runtime **{identity['runtimeRevision']}**, fresh forced postcommit
build **{identity['buildRevision']}**, core SHA256
**{summary['coreSHA256']['candidate']}**, assembly0.11.0.
All568 normalized production sources match the committed runtime. Both target
builds pass without warnings; focused JSON checks pass193internal/811public per
actual11/10. [Source proof](source-identity.json). Full platform qualification is
pending against7714144f in CI42931921242, independently of these observations.
An earlier mistaken dispatch42928757271 targeted b8b05ccc; it was cancelled and
does not qualify this source. Original measurement identities retain their then
pending run number; no raw observation was rewritten.

Six jobs complete in **{summary['elapsedSeconds']:.3f}seconds**: the two unchanged
R197 scripts in compile, warm and compile-run phases. Four independent processes
per job (two per engine),5s warmups and seven rotated150msrounds. Workerfec79afd,
optional adapter0.4 and the existing protocol remain fixed. Every identity,
golden, ownership balance, quiet endpoint, Closed/exit/join, fixture-removal and
archive/SHA gate passes. No workers or RAM fixtures remain; terminal is cached.

| Workload | Lython | CPython | Lython / CPython | Source | Status; control / max IQR |
| --- | ---: | ---: | ---: | --- | --- |
'''
# Retain phase labels in the evidence table; the current guide separates tables.
for r in summary['timing']:
    line = table_row(r)
    label = 'JSON-to-Markdown report' if r['case'] == 'scripts.report-render.large' else 'JSON-lines/helpers'
    readme += line.replace('| ' + label + ' |', '| ' + label + ' / ' + r['lane'] + ' |', 1) + '\n'
readme += '''
Report input3,072records/189,441B; JSON-lines4,096records/110,592B. Time ranges
span two process medians per engine; ratios include all four pairings, not
confidence intervals. Ratio above one means Lython slower. Diagnostic/Variable
describe observations, not design vetoes. Report remains slower and JSON-lines
faster in this diagnostic checkpoint; variation limits precision. This is not
single-change attribution, a universal CPU gain or resolution of earlier adversity.

Warm/compile-run include mediated RAM-file I/O, complete per-invocation stdout/file
checks and prior-result cleanup. Compile-run includes compilation in an already
running host; compile measures construction/disposal. Fixture staging/reset,
separate controller verification, protocol, process startup and final cache
teardown are excluded. External process CPU includes surrounding work and coarse
ticks. Independent phase medians need not add. Pending I/O, RSS and embedding tail
latency remain unmeasured.

[Raw observations and exact loaded images](observations.tgz),
[medians, clocks, IQR and all pairings](summary.json),
[receipt](archive-receipt.json), [cached terminal](terminal-status.json),
[preparation and final frozen core](preparation.tar.xz),
[archive hashes](archive-identity.json).
The inherited retrieval print incorrectly said “nine-job”; payload, assertions,
receipt and raw records consistently contain six. Original print preserved in
preparation; local recipe corrected without rerunning timing.

[Recovery](space-recovery.json) preserves the fixed240MiB floor/12MiB setup
headroom. The qualified baseline advances to exact b8b05ccc/696 bytes only after
[committed archive and source/config equivalence proof](qualified-baseline-promotion.json).
Superseded0e aliases and pre-cleanup measured JSON prototype aliases, plus the B565
compressed duplicate, are retired only after canonical/all-alias/UID/path/size/SHA
checks. Do not probe retired paths again. Final free space266,706,944B.

The [prior guide](prior-BENCHMARKS.md) preserves replaced8d44 measurements and
their uncertainty. CSV/text and other historical rows retain their own sources.
Publication remains postponed; whole-script runtime and independent regex work
continue. Final adapter qualification is not implied.
'''
(target / 'README.md').write_text(readme, encoding='utf-8', newline='\n')
index = repo / 'benchmarks/EXPERIMENTS.md'
text = index.read_text(encoding='utf-8')
mark = 'The [R217 JSON string decoder]'
at = text.index(mark)
text = text[:at] + '''The [R218 current JSON/report checkpoint](results/2026-11-11-json-cpython-checkpoint/README.md)
finishes six jobs165.178s/all gates at committed e122 runtime, all568source hashes.
Report warm1.18–1.23× CPython/complete1.09–1.13×; JSON-lines warm0.86–0.89×/
complete0.86–0.88×. Both remain variable; compilation is separate. Fixed workers,
adapter and complete scripts; no single-change attribution. Replaced8d44 rows,
all original observations and the misdirected CI dispatch remain explicit.

''' + text[at:]
index.write_text(text, encoding='utf-8', newline='\n')
print('R218 recorded: six jobs, all source/image/archive proofs; only affected CPython rows refreshed.')
