# R218 JSON/report CPython checkpoint

Two unchanged complete representative scripts,6jobs across compile/warm/compile-run.
Fresh postcommit7714144f binary equals committed e122 production source; both actual
TFMs built, .NET11 timed. Fixed fec79 worker/host/0.4 adapter and CPython3.13.16.
Four independent engine/control processes,5swarmup,7rotated150msrounds,normalGC/tiering.
210sowner/30stop/30margin. Included: full mediated RAM I/O, output/file validation,
prior-result cleanup. Excluded: fixture reset, separate verification, protocol,
startup/final cache teardown. Source-labelled absolute comparison, no attribution
to one change, pending-I/O/embedding-tail claim or new framework. Preserve all
controls/adversity; final platform/package source qualification remains separate.
