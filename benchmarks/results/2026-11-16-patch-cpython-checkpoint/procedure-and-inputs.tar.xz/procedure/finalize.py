from pathlib import Path
import json,re

r=Path(__file__).parent
p=Path('docs/BENCHMARKS.md');s=p.read_text(encoding='utf-8').replace('| 0.82–0.82× |','| 0.817–0.825× |');p.write_text(s,encoding='utf-8',newline='\n')
p=Path('benchmarks/results/2026-11-16-patch-cpython-checkpoint/README.md');s=p.read_text(encoding='utf-8').replace('| 0.82–0.82× |','| 0.817–0.825× |');s=s.replace('This fills a current useful-workload gap. Do not infer a causal improvement over R229','This fills a current useful-workload gap: patch warm0.817–0.825× and fresh0.797–0.820×\nCPython do not establish a performance problem for this fixture. CSV1.107–1.149×\nhas2.95%Lython control movement; retain it without inferring a source regression.\nDo not infer a causal improvement over R229');p.write_text(s,encoding='utf-8',newline='\n')
p=Path('PLAN.md');s=p.read_text(encoding='utf-8').replace('| Current measurement |','| Latest completed comparison |')
a=s.index('**R421 completed:**');b=s.index('\n## Substantial redesign roadmap',a)
s=s[:a]+'''**R421 completed:** B816 archived/joined; all controls and failed conditions retained.
Patch warm 0.817–0.825× and fresh 0.797–0.820× CPython confirm no demonstrated gap
for this single-edit fixture. CSV warm 1.107–1.149× has 2.95% unchanged Lython control
movement; no causal regression is inferred. Current patch/CSV guide rows identify all
phases/costs and source. No matcher redesign selected. R229's original evidence stays.

**Next:** return to A1/A2's complete operand/collection representation, using existing
captured-text/search and numerical-record evidence. Stop source assessment once the
complete storage/transport invariant and displaced work are specified, or record why
no coherent candidate is justified. Do not repeat already-established routes, broad
profiles or arbitrary small optimizations. The substantial performance objective
remains open; no runtime prototype is currently selected.
''' + s[b:]
p.write_text(s,encoding='utf-8',newline='\n')
v=json.loads((r/'producer-availability.json').read_text(encoding='utf-8-sig'));assert v['versions']==['0.1.0','0.2.0','0.3.0','0.4.0'];old=json.loads((r.parent/'regex-producer-050-r409/prototype-identity.json').read_text(encoding='utf-8'));assert {x['Hash']for x in v['developmentPackages']}=={x['packageSHA256']for x in old['assets']}
for p in [Path('benchmarks/results/2026-11-16-patch-cpython-checkpoint/README.md'),Path('benchmarks/results/2026-11-16-current-call-attribution/README.md'),Path('benchmarks/results/2026-11-15-runtime-format-operation/delivery/README.md')]:
    for link in re.findall(r'\]\(([^)]+)\)',p.read_text(encoding='utf-8')):
        if not link.startswith(('http:','https:','#')):assert (p.parent/link.split('#')[0]).exists(),(p,link)
print('Local evidence links and exact unchanged development package identities verified; PLAN remains Git-ignored.')
