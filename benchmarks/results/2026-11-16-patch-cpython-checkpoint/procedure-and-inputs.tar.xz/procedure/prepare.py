from pathlib import Path
import ast,datetime,hashlib,json,shlex,subprocess,tarfile

r=Path(__file__).parent;q=r/'checkpoint';q.mkdir(exist_ok=True);assert not (q/'launch.log').exists();old=r.parent/'format-layout-r418/checkpoint'
root='/home/lokad/lython-bench-checks/patch-cpython-b816-20261116';unit='lython-b816-patch-cpython-20261116'
base=r.parent/'format-operation-r419';image=json.loads((base/'quiet/identity.json').read_text(encoding='utf-8'))['imageFiles']['candidate']
source_catalog=base/'quiet/retrieved/representative.json';additional=base/'quiet/retrieved/additional.json'
v=json.loads(source_catalog.read_text(encoding='utf-8'));patch=json.loads(Path('benchmarks/results/2026-11-11-patch-workflow/catalog.json').read_text(encoding='utf-8'))
v['cases']=[next(c for c in patch['cases']if c['id']=='scripts.patch-generation.large'),next(c for c in v['cases']if c['id']=='scripts.csv-invoice.large')]
source=Path('benchmarks/scripts/patch-generation.py').read_text(encoding='utf-8');assert v['cases'][0]['source']==source and hashlib.sha256(source.encode()).hexdigest()==v['cases'][0]['sourceSha256']
catalog=q/'representative.json';catalog.write_text(json.dumps(v,indent=2)+'\n',encoding='utf-8',newline='\n')
jobs=[['scripts.patch-generation.large','warm'],['scripts.patch-generation.large','compile'],['scripts.patch-generation.large','compile-run'],['scripts.csv-invoice.large','warm']]
cases={c['id']for c in json.loads(catalog.read_text(encoding='utf-8'))['cases']};assert all(case in cases for case,lane in jobs)
head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
identity=dict(sourceRevision=head+'/frozen0393331a',runtimeCommit='c023042d',purpose='Current complete patch-generation CPython phases plus CSV control; fill historical workload gap, not causal source comparison or isolated matcher cost.',coreSHA256={n:image['Lokad.Lython.dll']for n in ['candidate','candidate-control']},auxiliaryFiles={n:h for n,h in image.items()if n!='Lokad.Lython.dll'},catalogSHA256=hashlib.sha256(catalog.read_bytes()).hexdigest(),additionalCatalogSHA256=hashlib.sha256(additional.read_bytes()).hexdigest(),qualification='Full43774159426 GREEN Windows/Ubuntu actual11/10 ordinary/original stress/installed Release consumers;595source inputs/deletions verified',publicationHeld=True)
(q/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8',newline='\n')
for n in ['collect.py','archive-owned.py','run.sh','retrieve.py','summarize.py']:
    s=(old/n).read_text(encoding='utf-8').replace('layout-cpython-b813-20261115','patch-cpython-b816-20261116').replace('lython-b813-layout-cpython-20261115',unit).replace('B813','B816')
    if n=='collect.py':
        a=s.index('jobs=');b=s.index('\nenv =',a);s=s[:a]+'jobs='+repr(jobs)+"\ncases.update({c['id']:c for c in json.loads((root/'additional.json').read_text())['cases']})\nassert len(jobs)==4 and all(case in cases for case,lane in jobs)\n"+s[b:]
    if n.endswith('.py'):ast.parse(s)
    (q/n).write_text(s,encoding='utf-8',newline='\n')
with tarfile.open(q/'payload.tgz','w:gz')as t:
    for n in ['identity.json','representative.json','collect.py','archive-owned.py','run.sh']:t.add(q/n,arcname=n)
with tarfile.open(q/'payload.tgz')as t:size=sum(m.size for m in t if m.isfile())
c=dict(root=root,unit=unit,source='/home/lokad/lython-bench-checks/format-operation-b814-20261115',catalog='/home/lokad/lython-bench-checks/format-operation-b814-20261115/representative.json',sourceCatalogSHA256=hashlib.sha256(source_catalog.read_bytes()).hexdigest(),additional='/home/lokad/lython-bench-checks/format-operation-b814-20261115/additional.json',identity=identity,retire=[],payloadBytes=(q/'payload.tgz').stat().st_size,payloadSHA256=hashlib.sha256((q/'payload.tgz').read_bytes()).hexdigest(),unpackedBytes=size)
(q/'config.json').write_text(json.dumps(c,indent=2)+'\n',encoding='utf-8',newline='\n')
tree=ast.parse((old/'launch-command.py').read_text(encoding='utf-8'));node=next(n for n in tree.body if isinstance(n,ast.Assign)and any(isinstance(t,ast.Name)and t.id=='c'for t in n.targets));old_start=node.value.col_offset;line=(old/'launch-command.py').read_text(encoding='utf-8').splitlines()[2];assert line.startswith('c=')
code=(old/'launch-command.py').read_text(encoding='utf-8');start=code.index('c=');end=code.index(';b=Path(',start);code=code[:start]+'c='+repr(c)+code[end:];code=code.replace('lython-b813-fixtures','lython-b816-fixtures')
code=code.replace("sha(Path(c['catalog']))==c['identity']['catalogSHA256']","sha(Path(c['catalog']))==c['sourceCatalogSHA256']")
code=code.replace("os.link(c['catalog'],root/'representative.json');","assert sha(root/'representative.json')==c['identity']['catalogSHA256'];")
ast.parse(code);(q/'launch-command.py').write_text(code,encoding='utf-8',newline='\n')
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
p=subprocess.run(ssh+['python3 -c '+shlex.quote(code)],input=(q/'payload.tgz').read_bytes(),capture_output=True,timeout=45);(q/'launch.log').write_bytes(p.stdout+p.stderr);assert p.returncode==0,(p.stdout+p.stderr).decode('utf-8','replace')
now=datetime.datetime.now(datetime.timezone.utc);(q/'observe-not-before.json').write_text(json.dumps(dict(startedUTC=now.isoformat(),doNotObserveBeforeUTC=(now+datetime.timedelta(seconds=200)).isoformat(),ownerSeconds=240),indent=2)+'\n',encoding='utf-8',newline='\n');print(p.stdout.decode('utf-8'),flush=True)
