from pathlib import Path
import hashlib,json,shutil,tarfile

r=Path(__file__).parent;q=r/'checkpoint';out=Path('benchmarks/results/2026-11-16-patch-cpython-checkpoint');out.mkdir(exist_ok=True)
d=json.loads((q/'summary.json').read_text(encoding='utf-8'));receipt=json.loads((q/'archive-receipt.json').read_text(encoding='utf-8'))
assert d['complete'] and d['jobs']==4 and receipt['complete'] and receipt['allWorkersJoined']
assert hashlib.sha256((q/'observations.tgz').read_bytes()).hexdigest()==receipt['archiveSHA256']
for n in ['identity.json','summary.json','observations.tgz','archive-receipt.json','terminal-status.json']:shutil.copyfile(q/n,out/n)
shutil.copyfile('docs/BENCHMARKS.md',out/'prior-BENCHMARKS.md')
with tarfile.open(out/'procedure-and-inputs.tar.xz','w:xz')as a:
    for p in q.iterdir():
        if p.is_file()and p.name!='observations.tgz':a.add(p,arcname='checkpoint/'+p.name)
    a.add(r/'prepare.py',arcname='procedure/prepare.py')
    for n in ['representative.json','additional.json','cpython-worker.py']:a.add(q/'retrieved'/n,arcname='inputs/'+n)
rows=[];artifact_rows=[]
for x in d['timing']:
    patch=x['case']=='scripts.patch-generation.large';phase={'warm':'warm Run','compile':'compilation only','compile-run':'compile and execute once'}[x['lane']]
    m=x['medianMilliseconds'];ly=[m[n]for n in ['candidate','candidate-control']];py=[m[n]for n in ['CPython','CPython-control']]
    status=f"Diagnostic; spreads {x['lythonControlPercent']:.2f}/{x['cpythonControlPercent']:.2f}%; IQR ≤{x['maxIqrPercent']:.2f}%"
    ratios=f"{min(x['ratioRange']):.2f}–{max(x['ratioRange']):.2f}×"
    times=[f'{min(v):.3f}–{max(v):.3f}'for v in [ly,py]]
    rows.append(f"| {'Patch generation'if patch else'CSV invoice'} / {phase} | {'Two 1,024-line files / 67,597 B'if patch else'4,096 records / 127,031 B'} | {times[0]} ms | {times[1]} ms | {ratios} | {status} |")
    artifact_rows.append(f"| {'Patch'if patch else'CSV'} / {phase} | {times[0]} | {times[1]} | {ratios} | {x['lythonControlPercent']:.2f}/{x['cpythonControlPercent']:.2f}% | {x['maxIqrPercent']:.2f}% |")
text=f'''# Current patch-generation CPython checkpoint

R421/B816,2026-11-16UTC. Runtime **c023042d / measured0393331a**,
source/evidence head09bf8cbb, versus stock **CPython3.13.16**. Runtime already
[fully qualified](../2026-11-15-runtime-format-operation/delivery/README.md);
no production edit, new backend qualification or source speedup is claimed.

Existing complete patch script reads two1,024-line UTF8 Python files (67,597B),
generates unified_diff and writes change.patch. One central replacement between
unique lines; independent CLR-constructed exact patch/stdout goldens reused from
[R229](../2026-11-11-patch-workflow/README.md), not new arbitrary-diff coverage.
Current patch source hash matches the committed maintained script. CSV invoice
control uses4,096records/127,031B. Original private setup assertion found that the
reduced recent catalog omits patch: before remote work, reuse its existing canonical
case plus the CSV case in a two-case catalog. No fixture/golden/worker redesign.

| Workload / phase | Lython ms | CPython ms | Lython/CPython | L/P control spread | Max IQR |
| --- | ---: | ---: | ---: | ---: | ---: |
'''+ '\n'.join(artifact_rows)+f'''

All four pairings of process medians, not confidence intervals. Four jobs complete
in **{d['elapsedSeconds']:.3f}s**, two processes per engine,5s full-request warmups,
five rotated approximately0.5s rounds. Keep every moving/adverse control and IQR;
this is diagnostic complete embedding cost, not isolated matcher/interpreter CPU.
Quiet Azure F4as_v7/Ubuntu24.04.4, four EPYC9V45vCPUs/16GiB/no swap,.NET11RC3
ordinary tiering/natural workstationGC, CPython GIL/GC.

Warm includes synchronous Run, mediated RAM-file I/O, full stdout/file validation
and prior-result cleanup; excludes compile/startup/reset/protocol/finalcache teardown.
Compilation includes compiled-owner disposal; fresh includes compilation, execution
and compiled-owner disposal. Separate medians are not additive. Wider process CPU
includes reset/protocol. CPython native buffered files provide different containment.
No pending-I/O, contention, heap/RSS, startup or embedding-tail comparison.

This fills a current useful-workload gap. Do not infer a causal improvement over R229
or select a matcher redesign from private Python-facing collections alone. The
single-edit fixture does not establish arbitrary diff throughput. Call/operand and
captured-text questions remain separate; broader performance work remains open.

All image/catalog/golden/budget/quiet/Closed/exit/join/archive gates pass. Persistent
archive hash-verifies under the lease; all workers and RAM fixtures are gone.
No retirement or floor change; current images/toolchains and254/252MiB floors remain.
Terminal cached forever. [Summary/all controls](summary.json),[identity](identity.json),
[raw observations](observations.tgz),[procedure/inputs](procedure-and-inputs.tar.xz),
[previous guide](prior-BENCHMARKS.md). Publication held.
'''
(out/'README.md').write_text(text,encoding='utf-8',newline='\n')
p=Path('docs/BENCHMARKS.md');s=p.read_text(encoding='utf-8');s='\n'.join(line for line in s.splitlines()if not line.startswith('| CSV invoice / warm Run |'))+'\n';needle='| --- | --- | ---: | ---: | ---: | --- |';assert s.count(needle)==1;s=s.replace(needle,needle+'\n'+'\n'.join(rows),1)
needle='**Report rows:58eeea6f/frozen9d071eba**;';s=s.replace(needle,'''**Patch phases and CSV warm: c023042d / measured0393331a**,2026-11-16UTC;
[current checkpoint](../benchmarks/results/2026-11-16-patch-cpython-checkpoint/README.md)
passes measurement/cleanup gates and [full runtime qualification](../benchmarks/results/2026-11-15-runtime-format-operation/delivery/README.md).
Patch is one central edit between unique lines, not arbitrary diff throughput.
CSV compilation/fresh rows below retain their earlier revision.

'''+needle,1);s=s.replace('**CSV invoice, captured warm text, JSON,','**CSV invoice compilation/fresh, captured warm text, JSON,')
p.write_text(s,encoding='utf-8',newline='\n')
availability=Path('benchmarks/results/2026-11-15-regex-range-prototype/availability-20261116.json');shutil.copyfile(r/'producer-availability.json',availability)
p=Path('benchmarks/EXPERIMENTS.md');s=p.read_text(encoding='utf-8');s+=f'\n\n[R421/B816 current patch/CSV phases](results/2026-11-16-patch-cpython-checkpoint/README.md): c023042d/0393331a versus CPython3.13.16; four jobs {d["elapsedSeconds"]:.3f}s, all image/golden/quiet/budget/Closed/join/archive gates. No source edit, causal speedup or arbitrary diff claim; every control retained. [Producer availability](results/2026-11-15-regex-range-prototype/availability-20261116.json): NuGet still0.4; local0.5 package hashes equal qualified R409 and PythonRe source changes only its README, so unchanged backend tests not repeated.\n';p.write_text(s,encoding='utf-8',newline='\n')
p=Path('PLAN.md');s=p.read_text(encoding='utf-8');s=s.replace('Four jobs, approximately 140 seconds, 240-second owner. Reuse checked workers and independent goldens; no new framework. Active results are not yet evidence.',f'Four jobs complete in {d["elapsedSeconds"]:.3f}s, all image/golden/quiet/budget/join/archive gates; [results](benchmarks/results/2026-11-16-patch-cpython-checkpoint/README.md). Reused checked workers/goldens; no source speedup or arbitrary-diff claim. Terminal cached.')
s=s.replace('**R421 acceptance:** archive/join B816; retain all controls and failed conditions;','**R421 completed:** B816 archived/joined; all controls and failed conditions retained;')
s=s.replace('update useful patch rows with current identity, phases and included costs. Historical','current patch/CSV rows now name actual identity, phases and included costs. Historical')
s=s.replace('Normal adapter remains at 0.4.0 until a released immutable replacement is verified.','Normal adapter remains at 0.4.0 until a released immutable replacement is verified.\n+  Checked 2026-11-16: NuGet still lists 0.4; local 0.5 hashes match R409 and PythonRe\n+  source changes only README. No unchanged requalification.').replace('\n+  ','\n  ')
p.write_text(s,encoding='utf-8',newline='\n')
print('\n'.join(rows));print('Evidence/guide/PLAN saved; no source speedup or completion of broader objective inferred.')
