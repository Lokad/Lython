from pathlib import Path
import json
import os
import subprocess

lab = Path(__file__).resolve().parent
source = json.loads((lab.parent / "function-record-keys-r601/probes.json").read_text(encoding="utf-8"))
source.append("""def factory(seed):
    def apply(a: int = seed, /, b: int = 2, *, required, clé: int = seed+1, other, z=9) -> int:
        return a + b + required + clé + other + z
    return apply
f, g = factory(1), factory(10)
print(f(required=3, other=4), g(required=3, other=4))
print(f.__defaults__, list(f.__kwdefaults__), list(f.__annotations__))
memo = f.__kwdefaults__
memo['new'] = memo.pop('clé')
memo['clé'] = 5
print(list(memo), list(g.__kwdefaults__), f(required=3, other=4), g(required=3, other=4))
""")
path = lab / "probes.json"
path.write_text(json.dumps(source, ensure_ascii=False) + "\n", encoding="utf-8")
python = Path("C:/Python313/python.exe")
goldens = []
for program in source:
    result = subprocess.run([python, "-I", "-S", "-X", "utf8", "-c", program],
                            capture_output=True, timeout=10, check=True)
    assert not result.stderr, result.stderr
    goldens.append(result.stdout.decode("utf-8").replace("\r\n", "\n"))
sdk = Path.home() / ".dotnet11"
env = dict(os.environ, DOTNET_ROOT=str(sdk), DOTNET_ROOT_X64=str(sdk), PATH=str(sdk) + os.pathsep + os.environ["PATH"])
work = Path(".git/agent-worktrees/definition-record-construction-r604")
probe = work / "tools/LythonProbe/bin/Release/net11.0/LythonProbe.dll"
checks = []
for mode in ("sync", "async"):
    args = [sdk / "dotnet.exe", probe, "--batch-json", "--max-memory-bytes", "4194304"]
    if mode == "async":
        args += ["--async"]
    output = subprocess.run(args, input=path.read_bytes(), env=env, capture_output=True, timeout=70, check=True)
    (lab / f"{mode}.jsonl").write_bytes(output.stdout)
    actual = [json.loads(line)["Lython"] for line in output.stdout.decode("utf-8-sig").splitlines()]
    assert len(actual) == len(source) and not output.stderr
    for row, expected in zip(actual, goldens, strict=True):
        assert row["Success"] and row["StandardOutput"] == expected and not row["StandardError"], (mode, row, expected)
    checks.append(dict(mode=mode, matching=len(actual)))
summary = dict(cpythonGoldens=goldens, checks=checks)
(lab / "probe-summary.json").write_text(json.dumps(summary, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
print(checks, flush=True)
