set -eu
root=/home/lokad/lython-bench-checks/definition-records-b1031-20261119
trap 'result=$?; printf "%s\n" "$result" > "$root/exit-code.txt"' EXIT
python3 "$root/collect.py"
