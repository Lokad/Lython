from pathlib import Path
import re
root=Path(".git/agent-worktrees/borrowed-builtin-bindings-20261125/src/Lokad.Lython/Runtime")
def update(name,transform):
    p=root/name
    old=p.read_text(encoding="utf-8")
    text=transform(old)
    assert text!=old,name
    p.write_text(text,encoding="utf-8",newline="\n")

def binder(text):
    a=text.index("    private static BoundBuiltinArguments BindNamedArgumentsCore<T>(")
    b=text.index("        extras = [];",a)
    decl=text[a:b]
    decl=decl[:decl.rindex("    {\n")]
    expanded="""    internal static int BindFixedExecutableArguments(Span<LythonRuntime.ExecutableSlot> operands,
        ExecutableCallSite call, LythonCallableSignature signature, LythonRuntime.ExecutionContext context,
        scoped Span<object> values)
        => BindArgumentValues(new OperandInputs(operands, call.Arguments, context),
            call.CallSpan, signature.Name, PythonCallableKind.Builtin, signature.Parameters,
            out _, out _, out _, values);

"""
    expanded+=decl+"""    {
        _ = BindArgumentValues(arguments, span, callableName, callableKind, parameters, out extras,
            out var values, out var assigned, default, preservePresence, collectExtras, useNullForOmittedArguments);
        return new BoundBuiltinArguments(values!, assigned);
    }

    // Validate the input shape once, then write the selected final storage.
    // A synchronous fixed-width caller supplies its own managed stack slots.
    private static int BindArgumentValues<T>(T arguments, LythonSourceSpan span, string callableName,
        PythonCallableKind callableKind, CallableParameterLayout parameters,
        out KeyValuePair<string, object>[] extras, out object[]? values, out ArgumentPresence resultAssigned,
        scoped Span<object> destination, bool preservePresence = false, bool collectExtras = false,
        bool useNullForOmittedArguments = false) where T : IBindingInputs, allows ref struct
    {
        values = null;
"""
    text=text[:a]+expanded+text[b:]
    assert text.count("            var positionalOnly = new object[arguments.Length];")==1
    text=text.replace("            var positionalOnly = new object[arguments.Length];",
        """            Span<object> positionalOnly = destination.IsEmpty
                ? values = new object[arguments.Length]
                : destination[..arguments.Length];""")
    text=text.replace("            return new BoundBuiltinArguments(positionalOnly, ArgumentPresence.Empty);",
        "            resultAssigned = ArgumentPresence.Empty;\n            return positionalOnly.Length;")
    text=text.replace("        var result = length == 0 ? Array.Empty<object>() : new object[length];",
        """        Span<object> result = destination.IsEmpty
            ? values = length == 0 ? [] : new object[length]
            : destination[..length];""")
    text=text.replace("if (!useNullForOmittedArguments) Array.Fill(result, PyNone.Instance);",
        "if (!useNullForOmittedArguments) result.Fill(PyNone.Instance);")
    return text.replace("""        var resultAssigned = assigned.WithLength(length);
        resultAssigned.MarkRange(count, extraPositionalCount);
        return new BoundBuiltinArguments(result, resultAssigned);""",
        """        resultAssigned = assigned.WithLength(length);
        resultAssigned.MarkRange(count, extraPositionalCount);
        return length;""")
update("Calls/CallBinder.cs",binder)

def callables(text):
    a=text.index("    private abstract class DelegateBoundArgumentsCallable")
    b=text.index("    // Builtin type constructors",a)
    text=text[:a]+text[b:]
    a=text.index("        int IOperandBoundCallable.GetOperandBindingCapacity",text.index("    private abstract class BoundArgumentsCallable"))
    b=text.index("            context.CheckExecution(call.CallSpan);",a)
    text=text[:a]+"""        int IOperandBoundCallable.GetOperandBindingCapacity(ExecutableCallSite call) => GetBindingCapacity(call);

        protected virtual int GetBindingCapacity(ExecutableCallSite call)
            => OperandBindingCapacity(Signature, call.ArgumentCount);

        ValueTask<object> IOperandBoundCallable.InvokeFromOperands(Span<ExecutableSlot> operands, ExecutableCallSite call,
            ExecutionContext context, bool asynchronous) => InvokeFromOperands(operands, call, context, asynchronous);

        protected virtual ValueTask<object> InvokeFromOperands(Span<ExecutableSlot> operands, ExecutableCallSite call,
            ExecutionContext context, bool asynchronous)
        {
"""+text[b:]
    text=text.replace("class BuiltinCallable : DelegateBoundArgumentsCallable,","class BuiltinCallable : BoundArgumentsCallable,")
    a=text.index("        protected BuiltinCallable(",text.index("    private class BuiltinCallable"))
    b=text.index("        private readonly Func<BoundBuiltinArguments",a)
    text=text[:a]+"""        private readonly Func<object[], LythonSourceSpan, ExecutionContext, object>? _implementation;
        private readonly Func<object[], LythonSourceSpan, ExecutionContext, ValueTask<object>>? _asyncImplementation;

        protected BuiltinCallable(LythonCallableSignature signature) : base(signature, PythonCallableKind.Builtin) { }

        protected BuiltinCallable(LythonCallableSignature signature,
            Func<object[], LythonSourceSpan, ExecutionContext, object> implementation,
            Func<object[], LythonSourceSpan, ExecutionContext, ValueTask<object>>? asyncImplementation)
            : this(signature)
        {
            _implementation = implementation;
            _asyncImplementation = asyncImplementation;
        }

        protected override object InvokeBound(object[] arguments, LythonSourceSpan span, ExecutionContext context)
            => (_implementation ?? throw new InvalidOperationException("Missing bound builtin implementation."))(arguments, span, context);

        protected override ValueTask<object> InvokeBoundAsync(object[] arguments, LythonSourceSpan span, ExecutionContext context)
            => _asyncImplementation is null ? new(InvokeBound(arguments, span, context)) : _asyncImplementation(arguments, span, context);

        public static BuiltinCallable CreateBorrowed(LythonCallableSignature signature,
            Func<ReadOnlySpan<object>, LythonSourceSpan, ExecutionContext, object> implementation)
            => new BorrowedBuiltinCallable(signature, implementation);

        private sealed class BorrowedBuiltinCallable : BuiltinCallable
        {
            private const int Capacity = 4;
            [System.Runtime.CompilerServices.InlineArray(Capacity)]
            private struct FinalValues { private object _first; }

            private readonly Func<ReadOnlySpan<object>, LythonSourceSpan, ExecutionContext, object> _body;

            internal BorrowedBuiltinCallable(LythonCallableSignature signature,
                Func<ReadOnlySpan<object>, LythonSourceSpan, ExecutionContext, object> body) : base(signature)
            {
                if (signature.Parameters is not NamedCallableParameterLayout
                    { ParameterNames.Length: <= Capacity, AllowsExtraPositional: false, AllowsExtraKeywords: false })
                    throw new InvalidOperationException("Borrowed builtin binding requires a fixed small signature.");
                _body = body;
            }

            protected override int GetBindingCapacity(ExecutableCallSite call) => 0;

            protected override ValueTask<object> InvokeFromOperands(Span<ExecutableSlot> operands, ExecutableCallSite call,
                ExecutionContext context, bool asynchronous)
            {
                context.CheckExecution(call.CallSpan);
                FinalValues values = default;
                var count = CallBinder.BindFixedExecutableArguments(operands, call, Signature, context, values);
                return new(_body(values[..count], call.CallSpan, context));
            }

            protected override object InvokeBound(object[] arguments, LythonSourceSpan span, ExecutionContext context)
                => _body(arguments, span, context);
        }

"""+text[b:]
    text=text.replace(': this(signature, static (object[] _, LythonSourceSpan __, ExecutionContext ___) => throw new InvalidOperationException("Missing argument presence"), null)',': this(signature)')
    return text
update("LythonRuntime.Calls.cs",callables)

# Migrate the complete fixed-width synchronous part of the scalar math family.
a=(root/"LythonRuntime.Modules.cs").read_text(encoding="utf-8")
keep={"Hypot","Gcd","Lcm","Prod","Fsum","Dist","SumProd"}
names=set(re.findall(r'BuiltinCallable\.Create\(LythonKnownCallableSignatures\.Math\.\w+, (\w+)\)',a))-keep
for name in sorted(names):
    a,n=re.subn(r'BuiltinCallable\.Create\((LythonKnownCallableSignatures\.Math\.\w+, '+name+r'\))',r'BuiltinCallable.CreateBorrowed(\1',a)
    assert n==1,name
helpers={"ExpectUnaryReal","ExpectBinaryReal","UnaryFloat","UnaryBool","BinaryFloat","UnaryCheckedFloat"}
def math_bodies(text):
    for name in names|helpers:
        text=re.sub(r'(private static [^\r\n]+\b'+name+r'\()object\[\] arguments',r'\1ReadOnlySpan<object> arguments',text)
    return text
(root/"LythonRuntime.Modules.cs").write_text(math_bodies(a),encoding="utf-8",newline="\n")
update("LythonRuntime.MathModule.cs",math_bodies)
print(len(names), "fixed-width synchronous math callables")
