from pathlib import Path
import json
import shutil
lab=Path(__file__).resolve().parent
baseline=lab.with_name("unified-builtin-reservation-20261125")
older=lab.with_name("direct-builtin-operands")/"refined/quiet"
read=lambda p:json.loads(p.read_text(encoding="utf-8-sig"))
write=lambda path,src:path.write_text(src,encoding="utf-8",newline="\n")
catalog=read(baseline/"input-catalog.json")
cases={c["id"]:c for c in catalog["cases"]}
wide_math=next(c for c in read(older/"representative.json")["cases"] if c["id"]=="scripts.measurement-tolerance.explicit-options")
cases[wide_math["id"]]=wide_math
case_order=[
    ("diagnostic.measurement-tolerance.short-options","warm"),
    ("scripts.json-lines-shipment.explicit-options.large","warm"),
    (wide_math["id"],"warm"),
    ("scripts.json-lines-shipment.default-options.large","warm"),
    ("diagnostic.measurement-tolerance.short-options","warm-async"),
    ("scripts.json-lines-shipment.explicit-wide-options.large","warm"),
    ("diagnostic.generated-ordinary-definitions","warm"),
]
catalog["cases"]=[cases[name] for name in dict.fromkeys(row[0] for row in case_order)]
assert len(catalog["cases"])==6
write(lab/"input-catalog.json",json.dumps(catalog,ensure_ascii=False,indent=2)+"\n")
shutil.copyfile(baseline/"archived-duplicates.json",lab/"archived-duplicates.json")
text=(baseline/"freeze.py").read_text(encoding="utf-8").replace("unified-builtin-reservation-20261125","borrowed-builtin-bindings-20261125")
text=text.replace('git("rev-parse", "60ecf0d3b")','git("rev-parse", "e4cc71d6e")')
a=text.index('prior = lab.with_name("native-dictionary')
b=text.index("cores =",a)
text=text[:a]+'''prior = lab.with_name("unified-builtin-reservation-20261125")
prior_identity = json.loads((prior / "comparison/quiet/identity.json").read_text(encoding="utf-8"))
assert git("diff","--binary",prior_identity["comparisonRevision"],base,"--","src")==(prior/"candidate.patch").read_bytes()
old=prior_identity["imageFiles"]["candidate"]
assert {p.name:sha(p) for p in (prior/"candidate").iterdir()}==old
terminal=json.loads((prior/"comparison/quiet/terminal-status.json").read_text(encoding="utf-8"))["receipt"]
assert terminal["complete"] and sha(prior/"comparison/quiet/observations.tar.xz")==terminal["archiveSHA256"]
baseline=prior/"candidate/Lokad.Lython.dll"
assert sha(baseline)!=sha(core)
'''+text[b:]
text=text.replace('prior / "reference" / name','prior / "candidate" / name')
text=text.replace("Keep fixed builtin binding reservations in the existing frame","Borrow final managed slots for fixed-width synchronous math calls")
compile(text,"freeze.py","exec")
write(lab/"freeze.py",text)
text=(baseline/"prepare.py").read_text(encoding="utf-8")
a=text.index("jobs =")
b=text.index("save(quiet",a)
text=text[:a]+"jobs = "+repr({"warm":case_order})+"\n"+text[b:]
text=text.replace('prior = lab.with_name("native-dictionary-prepared-consumers-20261125")','prior = lab.with_name("unified-builtin-reservation-20261125")')
text=text.replace('digest(prior/"reference"/name)','digest(prior/"candidate"/name)')
a=text.index('collector =')
b=text.index('anchor=read',a)
text=text[:a]+'''collector = (donor / "collect.py").read_text(encoding="utf-8").replace("b1714b-fixtures","b1715-fixtures").replace("len(jobs) == 6","len(jobs) == 7")
compile(collector,"collect.py","exec")
write(quiet/"collect.py",collector)
shutil.copyfile(donor/"run.sh",quiet/"run.sh")
assert b"\\r" not in (quiet/"run.sh").read_bytes()
launcher=(prior/"quiet.py").read_text(encoding="utf-8").replace("b1714b","b1715").replace(
    "lython-b1715-unified-builtin-reservation","lython-b1715-borrowed-builtin-bindings").replace(
    "RuntimeMaxSec=350","RuntimeMaxSec=382").replace("seconds=255","seconds=300")
launcher=launcher.replace(",'reference-core.dll'","").replace("if name=='Lokad.Lython.dll':","if name=='Lokad.Lython.dll' and role=='candidate':")
'''+text[b:]
text=text.replace('    out.add(lab / "reference/Lokad.Lython.dll", arcname="reference-core.dll")\n',"")
text=text.replace('root="unified-builtin-reservation-b1714b-20261125"','root="borrowed-builtin-bindings-b1715-20261125"').replace(
    'reference="native-dictionary-prepared-consumers-b1712b-20261125"','reference="unified-builtin-reservation-b1714b-20261125"')
compile(text,"prepare.py","exec")
write(lab/"prepare.py",text)
text=(baseline/"archive.py").read_text(encoding="utf-8").replace("2026-11-25-unified-builtin-operands/fixed-reservation","2026-11-25-borrowed-builtin-bindings").replace(
    '==receipt["warmJobs"]==6','==receipt["warmJobs"]==7').replace("timedBatches=168,lanes=6","timedBatches=196,lanes=7")
write(lab/"archive.py",text)
shutil.copyfile(baseline/"allocations.py",lab/"allocations.py")
