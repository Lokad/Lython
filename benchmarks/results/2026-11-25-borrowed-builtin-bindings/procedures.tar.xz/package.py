from pathlib import Path
import hashlib
import json
import shutil
import subprocess
import tarfile

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
out=repo/"benchmarks/results/2026-11-25-borrowed-builtin-bindings"
wt=repo/".git/agent-worktrees/borrowed-builtin-bindings-20261125"
quiet=lab/"comparison/quiet"
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
identity=json.loads((quiet/"identity.json").read_text(encoding="utf-8"))
assert subprocess.check_output(["git","-C",wt,"diff","--binary","--","tests"])==b""
assert subprocess.check_output(["git","-C",wt,"diff","--binary","--","src"])==(lab/"candidate.patch").read_bytes()
assert sha(lab/"candidate.patch")==identity["sourcePatchSHA256"]
for role,files in identity["imageFiles"].items():
    assert {p.name:sha(p) for p in (lab/role).iterdir()}==files
for name in ("allocation-summary.json",):
    shutil.copyfile(lab/name,out/name)
for name in ("identity.json","storage-custody.json"):
    shutil.copyfile(quiet/name,out/name)
paths=("candidate.patch","prototype.py","prepare-prototype.py","freeze.py","prepare.py","archive.py","package.py",
       "quiet.py","input-catalog.json","candidate-build.log","allocations.py","candidate-allocation-final.json",
       "reference-allocation-final.json","windows-Lokad.Lython.Tests.log","windows-Lokad.Lython.PublicApi.Tests.log",
       "test-ubuntu.sh","ubuntu-net10-Lokad.Lython.Tests.log","ubuntu-net10-Lokad.Lython.PublicApi.Tests.log",
       "comparison/candidate-verify.json","comparison/reference-verify.json","comparison/quiet/launch.log",
       "comparison/quiet/storage-custody.json","comparison/quiet/observe-not-before","retrieve.log")
with tarfile.open(out/"procedures.tar.xz","w:xz") as bundle:
    for name in paths:
        assert (lab/name).is_file(),name
        bundle.add(lab/name,arcname=name,recursive=False)
with tarfile.open(out/"procedures.tar.xz") as bundle:
    assert bundle.getnames()==list(paths)
    assert all(bundle.extractfile(name).read()==(lab/name).read_bytes() for name in paths)
