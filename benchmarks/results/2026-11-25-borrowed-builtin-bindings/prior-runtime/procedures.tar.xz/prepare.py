from pathlib import Path
import hashlib
import json
import os
import shutil
import subprocess
import tarfile

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
original=lab.with_name("unified-builtin-operands-20261125")
final=lab.with_name("borrowed-builtin-bindings-20261125")
original_quiet=original/"comparison/quiet"
final_quiet=final/"comparison/quiet"
quiet=lab/"comparison/quiet"
quiet.mkdir(parents=True,exist_ok=True)
read=lambda p:json.loads(p.read_text(encoding="utf-8-sig"))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def write(path,s):path.write_text(s,encoding="utf-8",newline="\n")
def save(path,obj):write(path,json.dumps(obj,ensure_ascii=False,indent=2)+"\n")
original_id=read(original_quiet/"identity.json")
final_id=read(final_quiet/"identity.json")
core="Lokad.Lython.dll"
references={}
for role,pair,folder in (("reference",original,"reference"),("candidate",final,"candidate")):
    stage=pair/"comparison/quiet"
    terminal=read(stage/"terminal-status.json")
    assert terminal["receipt"]["complete"] and terminal["exitCode"]=="0"
    digest=terminal["receipt"]["archiveSHA256"]
    assert sha(stage/"observations.tar.xz")==digest
    sources=read(stage/"identity.json")["imageFiles"][folder]
    assert {p.name:sha(p)for p in (pair/folder).iterdir()}==sources
    references[role]=dict(root=read(stage/"upload.json")["root"],folder=folder,archive=digest,files=sources)
    output=lab/role
    output.mkdir(exist_ok=True)
    for name in sources:shutil.copyfile(pair/folder/name,output/name)
    assert {p.name:sha(p)for p in output.iterdir()}==sources
old=references["reference"]["files"]
new=references["candidate"]["files"]
assert len(new)==32 and old[core]!=new[core]
assert all(old[name]==value for name,value in new.items() if name!=core)
case="diagnostic.measurement-tolerance.short-options"
catalog=read(final_quiet/"representative.json")
catalog["cases"]=[item for item in catalog["cases"] if item["id"]==case]
assert len(catalog["cases"])==1
save(quiet/"representative.json",catalog)
save(quiet/"jobs.json",{"warm":[[case,"warm"],[case,"warm-async"]]})
first_patch=subprocess.check_output(["git","diff","--binary",original_id["comparisonRevision"],final_id["comparisonRevision"],"--","src"],cwd=repo)
current=(final/"candidate.patch").read_bytes()
assert hashlib.sha256(current).hexdigest()==final_id["sourcePatchSHA256"]
(lab/"interim.patch").write_bytes(first_patch)
(lab/"borrowed.patch").write_bytes(current)
identity=dict(sourceRevision=original_id["comparisonRevision"], comparisonRevision=original_id["comparisonRevision"],
    sourcePatchSHA256=hashlib.sha256(first_patch+current).hexdigest(), candidateBase=final_id["comparisonRevision"],
    stagePatchSHA256=[hashlib.sha256(data).hexdigest() for data in (first_patch,current)],
    coreSHA256={role+suffix:proof["files"][core] for role,proof in references.items() for suffix in ("","-control")},
    imageFiles={role:proof["files"] for role,proof in references.items()},
    expectedCPythonSHA256=final_id["expectedCPythonSHA256"], cpythonWorkerSHA256=final_id["cpythonWorkerSHA256"],
    catalogs={name:dict(sha256=sha(quiet/name)) for name in ("representative.json","jobs.json")},
    purpose="Compare exact borrowed binding to the earlier short-call runtime on the adverse tolerance workload")
save(quiet/"identity.json",identity)
sdk=Path.home()/".dotnet11"
env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk))
protocol=repo/"benchmarks/cpython-worker.py"
assert sha(protocol)==identity["cpythonWorkerSHA256"]
for role in references:
    report=lab/"comparison"/(role+"-verify.json")
    subprocess.run([sdk/"dotnet.exe",lab/role/"Lokad.Lython.Benchmarks.dll","--compare","verify","--catalog",
                    quiet/"representative.json","--dotnet",sdk/"dotnet.exe","--python","C:/Python313/python.exe",
                    "--python-worker",protocol,"--out",report],cwd=repo,env=env,check=True,timeout=55)
    results=read(report)
    assert results["state"]=="Completed" and results["caseCount"]==1
    assert results["catalogSha256"]==identity["catalogs"]["representative.json"]["sha256"] and results["launched"]["library"]["sha256"]==identity["coreSHA256"][role]
run=shutil.copyfile(final_quiet/"run.sh",quiet/"run.sh")
assert b"\r" not in (quiet/"run.sh").read_bytes()
collector=(final_quiet/"collect.py").read_text(encoding="utf-8").replace("b1715-fixtures","b1715b-fixtures").replace("len(jobs) == 7","len(jobs) == 2")
compile(collector,"collect.py","exec")
write(quiet/"collect.py",collector)
launcher=(final/"quiet.py").read_text(encoding="utf-8").replace("lython-b1715-borrowed-builtin-bindings","lython-b1715b-borrowed-builtin-baseline").replace(
    "seconds=300","seconds=105").replace("RuntimeMaxSec=382","RuntimeMaxSec=166")
start=launcher.index("assert donor['archiveSHA256']=='")
end=launcher.index("\n",start)
launcher=launcher[:start]+"""assert donor['archiveSHA256']==configuration['donors']['reference']['archive']
for label,source in configuration['donors'].items():
 location=base/source['root']
 assert location.is_dir() and location.resolve().parent==base
 assert digest(location/'observations.tar.xz')==source['archive']
 candidate_receipt=json.loads((location/'archive-receipt.json').read_text())
 assert candidate_receipt['complete'] and candidate_receipt['archivedAndVerifiedUnderLease']
"""+launcher[end:]
launcher=launcher.replace(",'candidate-core.dll'","")
a=launcher.index("   if name=='Lokad.Lython.dll'")
b=launcher.index("   assert digest(image/name)",a)
launcher=launcher[:a]+"""   donor=configuration['donors'][role]
   os.link(base/donor['root']/donor['folder']/name,image/name)
"""+launcher[b:]
compile(launcher,"quiet.py","exec")
write(lab/"quiet.py",launcher)
result=(final/"archive.py").read_text(encoding="utf-8").replace("2026-11-25-borrowed-builtin-bindings","2026-11-25-borrowed-builtin-bindings/prior-runtime").replace(
    '==receipt["warmJobs"]==7','==receipt["warmJobs"]==2').replace("timedBatches=196,lanes=7","timedBatches=56,lanes=2")
write(lab/"archive.py",result)
save(lab/"verified-raw-replicas.json",[])
payload=quiet/"payload.tar.gz"
with tarfile.open(payload,"w:gz",compresslevel=3) as tar:
    for name in ("identity.json","jobs.json","representative.json","run.sh","collect.py"):tar.add(quiet/name,arcname=name)
save(quiet/"upload.json",dict(root="borrowed-builtin-baseline-b1715b-20261125",reference=references["reference"]["root"],
    payloadSHA256=sha(payload),payloadBytes=payload.stat().st_size,donors={role:{k:v for k,v in info.items() if k!="files"}
        for role,info in references.items()}))
