from pathlib import Path
import hashlib
import json
import shutil
import tarfile
lab=Path(__file__).resolve().parent
repo=lab.parents[3]
out=repo/"benchmarks/results/2026-11-25-borrowed-builtin-bindings/prior-runtime"
quiet=lab/"comparison/quiet"
sha=lambda data:hashlib.sha256(data).hexdigest()
identity=json.loads((quiet/"identity.json").read_text(encoding="utf-8"))
patches=[(lab/path).read_bytes() for path in ("interim.patch","borrowed.patch")]
assert list(map(sha,patches))==identity["stagePatchSHA256"] and sha(b"".join(patches))==identity["sourcePatchSHA256"]
for role,files in identity["imageFiles"].items():
    assert {p.name:sha(p.read_bytes()) for p in (lab/role).iterdir()}==files
for name in ("identity.json","storage-custody.json"):
    shutil.copyfile(quiet/name,out/name)
paths=("interim.patch","borrowed.patch","prepare.py","quiet.py","archive.py","package.py","retrieve.log",
       "comparison/candidate-verify.json","comparison/reference-verify.json","comparison/quiet/representative.json",
       "comparison/quiet/storage-custody.json","comparison/quiet/launch.log","comparison/quiet/observe-not-before",
       "comparison/quiet/upload.json")
with tarfile.open(out/"procedures.tar.xz","w:xz") as bundle:
    for name in paths:
        assert (lab/name).is_file(),name
        bundle.add(lab/name,arcname=name,recursive=False)
with tarfile.open(out/"procedures.tar.xz") as bundle:
    assert bundle.getnames()==list(paths)
    assert all(bundle.extractfile(name).read()==(lab/name).read_bytes() for name in paths)
