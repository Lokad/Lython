from pathlib import Path
import ast
import hashlib
import json
import os
import shutil
import subprocess
import tarfile

lab = Path(__file__).resolve().parent
template = lab.parent/'postponed-cpython-b1156'
pair = lab.parent/'generated-method-defaults'
profile = lab.parent/'owned-annotation-values'
donor = pair/'quiet'
core = 'Lokad.Lython.dll'
read = lambda p: p.read_text(encoding='utf-8-sig')
load = lambda p: json.loads(read(p))
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()

def write(name, source):
    if name.endswith('.py'): ast.parse(source)
    (lab/name).write_text(source,encoding='utf-8',newline='\n')

def save(name, value): write(name,json.dumps(value,ensure_ascii=False,indent=2)+'\n')

old=load(donor/'config.json')
receipt=load(donor/'archive-receipt.json')
assert receipt['complete'] and receipt['archivedAndVerifiedUnderLease'] and receipt['allWorkersJoined']
assert sha(donor/'observations.tgz')==receipt['archiveSHA256']
identity=load(pair/'frozen-identity.json')
measured=identity['referenceCommit']
retained=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
assert not subprocess.check_output(['git','status','--porcelain'])
subprocess.run(['git','diff','--exit-code',measured,retained,'--','src/Lokad.Lython.Utf8Regex','Directory.Build.props','Directory.Packages.props',
                'benchmarks/Lokad.Lython.Benchmarks','benchmarks/cpython-worker.py','global.json'],check=True)
source=pair/'frozen'/'reference'
image=lab/'frozen/candidate'
image.mkdir(parents=True,exist_ok=True)
donor_files=identity['images']['reference']
assert len(donor_files)==32 and donor_files==old['identity']['imageFiles']['reference']
assert {name:sha(source/name) for name in donor_files}==donor_files
sdk=Path.home()/'.dotnet11'
dotnet=sdk/'dotnet.exe'
env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk),PATH=str(sdk)+os.pathsep+os.environ['PATH'])
with (lab/'current-build.log').open('wb') as log:
    subprocess.run([dotnet,'build','src/Lokad.Lython','-c','Release','-f','net11.0','--no-incremental','--artifacts-path',lab/'build-win'],
                   env=env,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=120)
new_core=lab/'build-win/bin/Lokad.Lython/release_net11.0'/core
files=donor_files | {core:sha(new_core)}
for name in files: shutil.copyfile(new_core if name==core else source/name,image/name)
assert {name:sha(image/name) for name in files}==files

catalog=load(pair/'catalog.json')
cases={case['id']:case for case in load(profile/'catalog.json')['cases']+catalog['cases']}
ids=['scripts.dataclass-inherited-configuration.generated','scripts.annotated-rule-closures',
     'scripts.annotated-rule-closures.nested-factories','scripts.csv-invoice.large']
assert retained.startswith('ab2aa9554') and all(case in cases for case in ids)
catalog['cases']=[cases[key] for key in ids]
save('representative.json',catalog)
catalog_hash=sha(lab/'representative.json')
shutil.copyfile(donor/'cpython-worker.py',lab/'cpython-worker.py')
protocol_hash=sha(lab/'cpython-worker.py')
assert protocol_hash==old['protocolSHA256']==sha(Path('benchmarks/cpython-worker.py'))
current=dict(sourceRevision=retained,imageSource=retained,purpose='Dataclass and factory scripts against CPython',
    imageFiles={'candidate':files},auxiliaryFiles={name:digest for name,digest in files.items() if name!=core},
    coreSHA256={'candidate':files[core],'candidate-control':files[core]},catalogSHA256=catalog_hash,cpythonWorkerSHA256=protocol_hash)
save('identity.json',current)
save('build-revision.json',dict(sourceRevision=retained,imageSource=retained,coreSHA256=files[core]))
with (lab/'verify.log').open('wb') as log:
    subprocess.run([dotnet,image/'Lokad.Lython.Benchmarks.dll','--compare','verify','--catalog',lab/'representative.json',
         '--dotnet',dotnet,'--python','C:/Python313/python.exe','--python-worker',lab/'cpython-worker.py',
         '--out',lab/'verify.json'],env=env,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=120)
verified=load(lab/'verify.json')
assert verified['state']=='Completed' and verified['catalogSha256']==catalog_hash

print('Four CPython goldens and the complete ab2aa9554 image verified.')
