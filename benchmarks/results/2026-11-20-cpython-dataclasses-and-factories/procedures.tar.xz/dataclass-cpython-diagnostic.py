import contextlib
import cProfile
import dataclasses
import io
import json
from pathlib import Path
import pstats
import sys
import timeit

catalog = json.loads(Path(sys.argv[1]).read_text(encoding='utf-8'))
case = next(item for item in catalog['cases'] if item['id']=='scripts.dataclass-inherited-configuration.generated')
code = compile(case['source'], '<benchmark>', 'exec')
def run():
    output = io.StringIO()
    with contextlib.redirect_stdout(output):
        exec(code, {'__name__':'__main__'})
    assert output.getvalue() == case['expectedOutput']

run()
print('Median of five local 50-run batches with dataclasses already imported:', sorted(timeit.repeat(run, repeat=5, number=50))[2] * 20, 'ms')
profile = cProfile.Profile()
profile.runcall(run)
report = pstats.Stats(profile).sort_stats('cumulative')
report.print_stats('dataclasses.py', 14)
report.print_stats('builtins.exec', 4)
