from pathlib import Path
import ast
import json
import hashlib
import tarfile
from shutil import copyfile

base=Path('.git/agent-notes/review-20261031')
lab=base/'cpython-dataclass-factories'
template=base/'nov20-cpython-checkpoint'
donor=base/'generated-method-defaults/quiet'
def read(path):return path.read_text(encoding='utf-8-sig')
def load(path):return json.loads(read(path))
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def write(name, text):
    if name.endswith('.py'): ast.parse(text)
    (lab/name).write_text(text,encoding='utf-8',newline='\n')
def save(name,value):write(name,json.dumps(value,indent=2)+'\n')

identity=load(lab/'identity.json')
files=identity['imageFiles']['candidate']
assert identity['sourceRevision'].startswith('ab2aa9554') and len(files)==32
assert sha(lab/'representative.json')==identity['catalogSHA256']==load(lab/'verify.json')['catalogSha256']
assert sha(lab/'cpython-worker.py')==identity['cpythonWorkerSHA256']
assert all(sha(lab/'frozen/candidate'/name)==value for name,value in files.items())
old=load(donor/'config.json')
receipt=load(donor/'archive-receipt.json')
assert receipt['complete'] and receipt['archivedAndVerifiedUnderLease'] and sha(donor/'observations.tgz')==receipt['archiveSHA256']
assert all(old['identity']['imageFiles']['reference'][name]==value for name,value in identity['auxiliaryFiles'].items())
root='/home/lokad/lython-bench-checks/cpython-dataclass-factories-b1168-20261120'
unit='lython-b1168-cpython-dataclass-factories-20261120'
old_config=load(template/'config.json')
floor=174*1024*1024
catalog=load(lab/'representative.json')
ids=[case['id'] for case in catalog['cases']]
assert len(ids)==4 and ids[-1]=='scripts.csv-invoice.large'
for name in ('collect.py','archive-owned.py','launch.py','retrieve.py','run.sh'):
    source=read(template/name).replace(old_config['root'],root).replace('B1162','B1168').replace('180355072',str(floor))
    if name=='collect.py':
        start=source.index('    for case_id,diagnostic in ')
        end=source.index('\n',start)
        source=source[:start]+f'    for case_id,diagnostic in {[(key,False) for key in ids]!r}:'+source[end:]
    if name=='launch.py':
        source=source.replace('B1168 representative comparison','B1168 dataclasses and factories comparison')
    write(name,source)
assert b'\r' not in (lab/'run.sh').read_bytes()
staged=lab/'candidate'
staged.mkdir(exist_ok=True)
core='Lokad.Lython.dll'
copyfile(lab/'frozen/candidate'/core,staged/core)
names=('representative.json','identity.json','collect.py','archive-owned.py','run.sh','cpython-worker.py','candidate/'+core)
payload=lab/'payload.tgz'
with tarfile.open(payload,'w:gz') as archive:
    for name in names:archive.add(lab/name,arcname=name)
expanded=sum((lab/name).stat().st_size for name in names)
space=load(lab/'quiet-space.json')
available=space['freeBytes']
selected=[]
for proof in space['replicas']:
    if available>floor+expanded+1835008+131072:break
    assert proof['committedBlobVerified'] and proof['sha256']!=files[core]
    selected.append(proof)
    available+=proof['bytes']
assert available>floor+expanded+1835008,(available,expanded)
config=dict(root=root,unit=unit,source=old['root'],sourceRole='reference',sourceFiles=identity['auxiliaryFiles'],
    sourceCatalogSHA256=old['catalogSHA256'],catalogSHA256=identity['catalogSHA256'],identity=identity,retireGroups=selected,
    donorArchiveSHA256=receipt['archiveSHA256'],payloadBytes=payload.stat().st_size,payloadSHA256=sha(payload),unpackedBytes=expanded,
    cpythonWorkerSHA256=identity['cpythonWorkerSHA256'])
save('config.json',config)
launcher=read(template/'remote-launch.py')
start,end=launcher.index('\nc=')+1,launcher.index('\nb=Path(')
launcher=launcher[:start]+'c='+repr(config)+launcher[end:]
write('remote-launch.py',launcher.replace('lython-b1162-fixtures','lython-b1168-fixtures').replace('180355072',str(floor)))
print('Verified ab2aa9554 image and CPython goldens. Four scripts use ten case/phase pairs.')
