from pathlib import Path
import datetime,hashlib,json,shlex,subprocess
r=Path(__file__).resolve().parent;payload=(r/'payload.tgz').read_bytes()
remote=r'''from pathlib import Path
import ast,fcntl,hashlib,io,json,os,shutil,subprocess,sys,tarfile
base=Path('/home/lokad/lython-bench-checks');root=base/'native-construction-b516-20261109';reference=base/'config-boundary-b509-20261109/candidate'
with(base/'comparison-vm.lock').open('a')as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB);assert not root.exists() and not list(Path('/dev/shm').glob('lython-comparison-files-*'))
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[c]ollector.dll|[p]erf record'],capture_output=True).returncode==1
 payload=sys.stdin.buffer.read(SIZE+1);assert len(payload)==SIZE and hashlib.sha256(payload).hexdigest()=='DIGEST'
 with tarfile.open(fileobj=io.BytesIO(payload),mode='r:gz')as a:
  required=sum(((m.size+4095)//4096)*4096 for m in a.getmembers())+(240+12)*1024*1024
  assert shutil.disk_usage(base).free>required,(shutil.disk_usage(base).free,required)
  root.mkdir();a.extractall(root,filter='data')
 previous=base/'shared-comparison-b514-20261109'
 for n in ['common-worker.dll','common-adapter.dll','common-worker.deps.json','common-worker.runtimeconfig.json','representative.json']:os.link(previous/n,root/n)
 os.link(previous/'current-core.dll',root/'baseline-core.dll')
 identity=json.loads((root/'identity.json').read_text());assert set(identity['coreSHA256'])=={'reference','reference-control','candidate','candidate-control'}
 assert hashlib.sha256((root/'representative.json').read_bytes()).hexdigest()==identity['catalogSHA256']
 assert hashlib.sha256((root/'baseline-core.dll').read_bytes()).hexdigest()==identity['coreSHA256']['reference']
 assert hashlib.sha256((root/'current-core.dll').read_bytes()).hexdigest()==identity['coreSHA256']['candidate']
 for role in ['reference','candidate']:
  shutil.copytree(reference,root/role,copy_function=os.link)
 for role,name in [('reference','baseline-core.dll'),('candidate','current-core.dll')]:
  (root/role/'Lokad.Lython.dll').unlink();os.link(root/name,root/role/'Lokad.Lython.dll')
 for role in ['reference','candidate']:
  for target,name in [('Lokad.Lython.Benchmarks.dll','common-worker.dll'),('Lokad.Lython.Utf8Regex.dll','common-adapter.dll'),('Lokad.Lython.Benchmarks.deps.json','common-worker.deps.json'),('Lokad.Lython.Benchmarks.runtimeconfig.json','common-worker.runtimeconfig.json')]:
   (root/role/target).unlink();os.link(root/name,root/role/target)
 for role in ['reference','candidate']:
  assert hashlib.sha256((root/role/'Lokad.Lython.dll').read_bytes()).hexdigest()==identity['coreSHA256'][role]
  for n,h in identity['auxiliaryFiles'].items():assert hashlib.sha256((root/role/n).read_bytes()).hexdigest()==h
 (root/'cpython-worker.py').symlink_to(base/'prepared-call-layout-b384-20261107/cpython-worker.py')
 for n in ['collect.py','archive-owned.py']:ast.parse((root/n).read_text())
 assert 'assert len(jobs)==4 'in(root/'collect.py').read_text();subprocess.run(['/bin/sh','-n',str(root/'run.sh')],check=True)
 fixture=root/'guest-fixtures';fixture.mkdir();subprocess.run(['sudo','-n','mount','-t','tmpfs','-o','size=128m,mode=0700,uid=lokad,gid=lokad','lython-b516-fixtures',str(fixture)],check=True)
 try:
  setup=dict(freeBytes=shutil.disk_usage(base).free,coreAndEveryAuxiliaryVerified=True,allConfiguredJobsValidated=True,roles=4,ownerSeconds=180,stopSeconds=30,marginSeconds=30,osFreeFloorMiB=240,evidenceHeadroomMiB=12)
  assert setup['freeBytes']>(240+12)*1024*1024
  (root/'setup.json').write_text(json.dumps(setup,indent=2)+'\n');print(json.dumps(setup),flush=True)
  fcntl.flock(lease,fcntl.LOCK_UN)
  subprocess.run(['sudo','-n','systemd-run','--unit=lython-b516-native-construction-20261109','--property=User=lokad','--property=WorkingDirectory='+str(root),'--property=RuntimeMaxSec=180','--property=TimeoutStopSec=30','--property=KillMode=control-group','/bin/sh',str(root/'run.sh')],check=True)
 except BaseException:
  subprocess.run(['sudo','-n','umount',str(fixture)],check=True);fixture.rmdir();raise
'''.replace('SIZE',str(len(payload))).replace('DIGEST',hashlib.sha256(payload).hexdigest())
compile(remote,'launch','exec');(r/'launch-command.py').write_text(remote,encoding='utf-8',newline='\n')
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73'];stage='/home/lokad/lython-bench-checks/native-construction-b516-launch.py'
code='from pathlib import Path; import sys; p=Path('+repr(stage)+'); assert not p.exists(); p.write_bytes(sys.stdin.buffer.read())'
done=subprocess.run(ssh+['python3 -c '+shlex.quote(code)],input=remote.encode(),capture_output=True);assert done.returncode==0,done.stderr
done=subprocess.run(ssh+['python3 '+stage],input=payload,capture_output=True);(r/'launch.log').write_bytes(done.stdout+b'\n'+done.stderr);print((done.stdout+done.stderr).decode(),flush=True);assert done.returncode==0
now=datetime.datetime.now(datetime.timezone.utc);(r/'observe-not-before.json').write_text(json.dumps(dict(acknowledgedUTC=now.isoformat(),doNotObserveBeforeUTC=(now+datetime.timedelta(seconds=240)).isoformat(),ownerSeconds=180,stopSeconds=30,marginSeconds=30),indent=2)+'\n',encoding='utf-8');print('Observe after '+(now+datetime.timedelta(seconds=240)).isoformat(),flush=True)
