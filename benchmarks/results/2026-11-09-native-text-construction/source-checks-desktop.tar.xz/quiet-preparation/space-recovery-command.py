from pathlib import Path
import fcntl,hashlib,json,os,shutil,stat,subprocess
base=Path('/home/lokad/lython-bench-checks')
spec=[{'path': '/home/lokad/lython-bench-checks/text-runtime-b515-20261109/observations.tgz', 'sha256': 'f4a65136c57fb0b077b4b52a41999f359e0154806141f535aa9a0bd1860b10a4', 'size': 2145472, 'preservedLocal': 'D:/code/Lython/benchmarks/results/2026-11-09-current-text-runtime/observations.tgz', 'tracked': True}, {'path': '/home/lokad/lython-bench-checks/cpython-checkpoint-b496-20261109/observations.tgz', 'sha256': 'dc0cbcd05f63b1e90338da00df955a336a61e16d387dd96ddf575bb4f263c563', 'size': 2131241, 'preservedLocal': 'D:/code/Lython/benchmarks/results/2026-11-09-cpython-checkpoint/observations.tgz', 'tracked': True}, {'path': '/home/lokad/lython-bench-checks/native-booleans-b495-20261109/observations.tgz', 'sha256': '1185652e9315380834bdcef538159ba1c7d7bcf1bd06acfb06850cd8ad5c3858', 'size': 3816659, 'preservedLocal': 'D:/code/Lython/benchmarks/results/2026-11-09-native-booleans/observations.tgz', 'tracked': True}, {'path': '/home/lokad/lython-bench-checks/static-call-shape-b494-20261109/observations.tgz', 'sha256': 'a3e6a42d8fd1ee9a65345de2697e7c1fde3c307e66a838ba5f4a4a28a5e66ec3', 'size': 3817276, 'preservedLocal': 'D:/code/Lython/benchmarks/results/2026-11-09-static-call-shape/observations.tgz', 'tracked': True}]
with (base/'comparison-vm.lock').open('a') as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert not (base/'native-construction-b516-20261109').exists()
 assert not list(Path('/dev/shm').glob('lython-comparison-files-*')) and not Path('/dev/shm/lython-b512').exists()
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record|[o]ps-profile.py'],capture_output=True).returncode==1
 free=shutil.disk_usage(base).free
 if free>270155776:
  print(json.dumps(dict(skipped=True,beforeFreeBytes=free,requiredFreeBytes=270155776,reason='Fresh space sufficient; no mutation')));__import__('sys').exit(0)
 rows=[]
 for entry in spec:
  p=Path(entry['path']);assert p.resolve(strict=True)==p and p.parent.parent==base and p.name=='observations.tgz'
  info=p.lstat();assert stat.S_ISREG(info.st_mode) and info.st_nlink==1 and info.st_uid==os.getuid() and info.st_gid==os.getgid()
  assert info.st_size==entry['size'] and hashlib.sha256(p.read_bytes()).hexdigest()==entry['sha256']
  receipt=json.loads((p.parent/'archive-receipt.json').read_text());assert receipt['complete'] and receipt['allWorkersJoined'] and receipt['archiveSHA256']==entry['sha256']
  parents=[]
  for parent in p.parents:
   meta=parent.lstat();assert stat.S_ISDIR(meta.st_mode) and not parent.is_symlink()
   parents.append(dict(path=str(parent),uid=meta.st_uid,gid=meta.st_gid,mode=oct(meta.st_mode)))
  rows.append(dict(**entry,device=info.st_dev,inode=info.st_ino,links=info.st_nlink,uid=info.st_uid,gid=info.st_gid,mode=oct(info.st_mode),parents=parents,allAliases=[str(p)]))
  if free+sum(Path(e['path']).stat().st_blocks*512 for e in rows)>270155776:break
 assert free+sum(Path(e['path']).stat().st_blocks*512 for e in rows)>270155776, ('Exact copies cannot fund unchanged payload/floors; no mutation',dict(freeBytes=free,requiredBytes=270155776,selectedBytes=sum(Path(e['path']).stat().st_blocks*512 for e in rows)))
 plan=dict(requiredFreeBytes=270155776,freshIdleLease=True,beforeFreeBytes=free,osFloorMiB=240,evidenceHeadroomMiB=12,files=rows,operation='Remove only redundant remote compressed archives. Their raw trees, receipts, frozen workers and byte-identical tracked local archives survive.')
 target=base/'native-construction-b516-space-plan.json'
 with target.open('x') as f:f.write(json.dumps(plan,indent=2)+'\n');f.flush();os.fsync(f.fileno())
 for entry in rows:
  p=Path(entry['path']);info=p.lstat()
  assert info.st_dev==entry['device'] and info.st_ino==entry['inode'] and info.st_nlink==1 and hashlib.sha256(p.read_bytes()).hexdigest()==entry['sha256']
  p.unlink()
 plan['afterFreeBytes']=shutil.disk_usage(base).free
 assert plan['afterFreeBytes']>free and plan['afterFreeBytes']>(240+12)*1024*1024
 (base/'native-construction-b516-space-receipt.json').write_text(json.dumps(plan,indent=2)+'\n')
 print(json.dumps(plan))
