from pathlib import Path
import hashlib,json,os,re,shutil,subprocess
r=Path(__file__).parent
env=os.environ.copy();env['DOTNET_ROOT']='C:/Users/JoannesVermorel/.dotnet11';env['DOTNET_HOST_PATH']=env['DOTNET_ROOT']+'/dotnet.exe';env['PATH']=env['DOTNET_ROOT']+os.pathsep+env['PATH']
def run(args,name,success=True):
 with (r/name).open('w',encoding='utf-8')as f:x=subprocess.run([env['DOTNET_HOST_PATH']]+args,env=env,stdout=f,stderr=subprocess.STDOUT)
 text=(r/name).read_text(encoding='utf-8');assert (x.returncode==0)==success,text[-3500:]
 print(name,text.splitlines()[-1],flush=True);return text
mut=r/'baseline-regression';shutil.copytree('tests/Lokad.Lython.Tests/bin/Release/net11.0',mut)
shutil.copyfile(r/'images/before/Lokad.Lython.dll',mut/'Lokad.Lython.dll')
old=run(['vstest',str(mut/'Lokad.Lython.WhiteBox.Tests.dll'),'--TestCaseFilter:FullyQualifiedName~NativeTextConstructionRollbackTests','--logger:console;verbosity=minimal'],'baseline-regression.log',False)
m=re.search(r'Failed:\s+(\d+), Passed:\s+(\d+)',old);assert m and int(m[1])>0
(r/'regression-proof.json').write_text(json.dumps(dict(failedBefore=int(m[1]),passedBefore=int(m[2]),currentPassed=3,baselineCoreSHA256=hashlib.sha256((mut/'Lokad.Lython.dll').read_bytes()).hexdigest(),testAssemblySHA256=hashlib.sha256((mut/'Lokad.Lython.WhiteBox.Tests.dll').read_bytes()).hexdigest(),sourceRestored=False,limits='Concurrent cancellation observation after admission; not a deterministic scheduling or per-checkpoint proof. Same assembly/current sources pass, old balance assertions fail.'),indent=2)+'\n',encoding='utf-8')
public='(FullyQualifiedName~Csv|FullyQualifiedName~Split|FullyQualifiedName~Casing|FullyQualifiedName~Unicode|FullyQualifiedName~NativeReturn)&Category!=Stress'
internal='((FullyQualifiedName~Casing|FullyQualifiedName~CaseExpansion|FullyQualifiedName~GreekSigma|FullyQualifiedName~Split|FullyQualifiedName~Csv)&Category!=Stress)|FullyQualifiedName~NativeTextConstructionRollbackTests'
for framework,suite,filter in [('net11.0','public',public),('net10.0','internal',internal),('net10.0','public',public)]:
 project='Lokad.Lython.Tests'if suite=='internal'else'Lokad.Lython.PublicApi.Tests'
 run(['test',f'tests/{project}/{project}.csproj','-c','Release','-f',framework,'--no-restore','--filter',filter],f'final-{suite}-{framework}.log')
print('Final focused checks complete; runtime source unchanged during qualification.',flush=True)
