from pathlib import Path
import hashlib,json,shutil,subprocess,tarfile
r=Path(__file__).parent;v=r/'b516';v.mkdir(exist_ok=False);old=r.parent/'scalar-comparison-r163/b513'
proof=json.loads((r/'final/identity.json').read_text(encoding='utf-8'));assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==h for p,h in proof['productionSources'].items())
jobs=[['scripts.csv-validated-records.large','warm'],['scripts.text-summary-helpers.large','warm'],['scripts.file-search.large','warm-async'],['scripts.config-edit.small','warm-async']]
for n in ['collect.py','archive-owned.py','run.sh','launch.py','retrieve.py','assess-vm.py']:
 s=(old/n).read_text(encoding='utf-8').replace('scalar-comparison-b513','native-construction-b516').replace('lython-b513-scalar-comparison','lython-b516-native-construction').replace('lython-b513-fixtures','lython-b516-fixtures')
 if n=='collect.py':
  a=s.index('jobs=[');z=s.index('\nenv =',a);s=s[:a]+'jobs='+repr(jobs)+'\nassert len(jobs)==4 and all(case in cases for case,lane in jobs)\n'+s[z:]
  a=s.index("purpose='");z=s.index('\n                  warmupSeconds=',a);s=s[:a]+"purpose='R167 bulk native UTF-8 construction ownership; affected CSV/text sync and adverse desktop search/config async controls. Original source/adversity retained; no claim from allocation.',"+s[z:]
 if n=='launch.py':
  s=s.replace("root.mkdir();a.extractall(root,filter='data')","root.mkdir();a.extractall(root,filter='data')\n previous=base/'shared-comparison-b514-20261109'\n for n in ['common-worker.dll','common-adapter.dll','common-worker.deps.json','common-worker.runtimeconfig.json','representative.json']:os.link(previous/n,root/n)\n os.link(previous/'current-core.dll',root/'baseline-core.dll')")
 if n.endswith('.py'):compile(s,n,'exec')
 (v/n).write_text(s,encoding='utf-8',newline='\n')
shutil.copyfile(r/'final/images/candidate/Lokad.Lython.dll',v/'current-core.dll')
shutil.copyfile(r/'baseline-proof.json',v/'baseline-source.json');shutil.copyfile(r/'final/identity.json',v/'final-source.json')
shutil.copyfile('src/Lokad.Lython/Runtime/Text/PyString.cs',v/'ScalarComparison.cs')
(v/'source.patch').write_bytes(subprocess.check_output(['git','diff','--','src/Lokad.Lython']))
before=r/'images/before';bh=hashlib.sha256((before/'Lokad.Lython.dll').read_bytes()).hexdigest();assert bh=='80a3540d915f3f8c0623a50bf215627815a80574e3506b7d18e97c54d18a14bd'
i=dict(sourceRevision='R164/R165 final precommit80a3540d, production-source equivalent to96e534f9/dc319b1a, versus final R167 freshly nonincremental working source. Common unchanged worker; not a postcommit/CPython measurement.',coreSHA256={k:bh if k.startswith('reference')else proof['candidateCoreSHA256']for k in ['reference','reference-control','candidate','candidate-control']},auxiliaryFiles={p.name:hashlib.sha256(p.read_bytes()).hexdigest()for p in before.glob('*.dll')if p.name!='Lokad.Lython.dll'},catalogSHA256=hashlib.sha256((r/'catalog.json').read_bytes()).hexdigest())
(v/'identity.json').write_text(json.dumps(i,indent=2)+'\n',encoding='utf-8')
(v/'focused.json').write_text(json.dumps(dict(internalPerFramework=386,publicPerFramework=824,frameworks=['actual11','actual10'],newRegressionsFailOld=3,currentRegressionsPass=3,limits='Concurrent cancellation fixture accepts successful funded completion if token arrives later; exact balances on cancelled failure.'),indent=2)+'\n',encoding='utf-8')
for n in ['contract.md','pre-measurement-plan.md']:(v/n).write_text('Four bounded jobs using the unchanged checked comparison driver. Affected CSV/text sync and original adverse search/config async controls. Four independent processes,5s warmup/role/seven rotated150ms rounds,180s owner/30s stop/30s margin. Preserve original desktop text+4.77to6.83%, CSVasync+3.76to6.03%, refined adverse async controls. Allocation flat; no causal inlining explanation, no CPU/equivalence claim from desktop. Decide retention/debt at this coherent construction milestone. Includes I/O, validation, prior-result cleanup; excludes compile/startup/reset/protocol/final cache teardown.\n',encoding='utf-8')
(v/'setup-contract.json').write_text(json.dumps(dict(jobs=4,roles=4,ownerSeconds=180,stopSeconds=30,marginSeconds=30,osFreeFloorMiB=240,evidenceHeadroomMiB=12),indent=2)+'\n',encoding='utf-8')
(v/'sizing.json').write_text(json.dumps(dict(jobs=4,warmupSeconds=5,rounds=7,targetBatchSeconds=.15,expectedSeconds=115,ownerSeconds=180),indent=2)+'\n',encoding='utf-8')
with tarfile.open(v/'payload.tgz','w:gz')as t:
 for p in v.iterdir():
  if p.name!='payload.tgz':t.add(p,arcname=p.name)
with tarfile.open(v/'payload.tgz')as t:required=sum(((m.size+4095)//4096)*4096 for m in t.getmembers())+252*1024*1024
(v/'payload-sizing.json').write_text(json.dumps(dict(requiredFreeBytes=required,payloadBytes=(v/'payload.tgz').stat().st_size,floorsUnchanged=True),indent=2)+'\n',encoding='utf-8')
s=(r.parent/'text-runtime-r166/recover-space.py').read_text(encoding='utf-8')
a=s.index('for remote,local in ');z=s.index(':\n',a);s=s[:a]+"for remote,local in [('text-runtime-b515-20261109','2026-11-09-current-text-runtime'),('cpython-checkpoint-b496-20261109','2026-11-09-cpython-checkpoint'),('native-booleans-b495-20261109','2026-11-09-native-booleans')]"+s[z:]
s=s.replace('text-runtime-b515-space','native-construction-b516-space').replace("base/'text-runtime-b515-20261109'","base/'native-construction-b516-20261109'").replace('264282112',str(required))
compile(s,'recover-space','exec');(v/'recover-space.py').write_text(s,encoding='utf-8')
p=Path('PLAN.md');s=p.read_text(encoding='utf-8')+'\nR167 final386internal/824public each11/10 pass; all3 corrected tests fail frozen\nbaseline balances. Source/fixture refinements and every initial failure/diagnostic\nretained. One bounded B516 four-job quiet confirmation uses CSV/text sync + adverse\nsearch/config async controls, existing driver,180s owner+30sstop/+30smargin. Only new\ncore ships; baseline/catalog/auxiliaries verified persistent links. Original floors\nunchanged; select exact tracked B515/B496/B495 duplicate compressed archives only\nif fresh deficit demands, with minimum prefix/metadata/hash/alias/receipt proof.\n';p.write_text(s,encoding='utf-8',newline='\n');print('Final R167 frozen/source verified, four jobs expected115s, required free',required)
