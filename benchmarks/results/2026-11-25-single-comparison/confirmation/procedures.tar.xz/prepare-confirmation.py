from pathlib import Path
import hashlib,json,os,shutil,subprocess,tarfile

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
quiet=lab/'comparison/quiet'
out=lab/'confirmation'
out.mkdir(exist_ok=True)
read=lambda f:json.loads(f.read_text(encoding='utf-8-sig'))
write=lambda p,s:p.write_text(s,encoding='utf-8',newline='\n')
save=lambda p,d:write(p,json.dumps(d,ensure_ascii=False,indent=2)+'\n')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
identity=read(quiet/'identity.json')
terminal=read(quiet/'terminal-status.json')['receipt']
assert terminal['complete'] and sha(quiet/'observations.tar.xz')==terminal['archiveSHA256']
catalog=read(quiet/'representative.json')
invoice='scripts.rule-default-closures'
manifest='scripts.config-generated-guards.medium.bad-0.sparse-lexical'
rules='unused'
catalog['cases']=[row for row in catalog['cases'] if row['id'] in (invoice,manifest,rules)]
assert len(catalog['cases'])==2
save(out/'representative.json',catalog)
save(out/'jobs.json',dict(warm=[[manifest,'compile'],[invoice,'compile'],[invoice,'warm'],[invoice,'compile-run']]))
identity['catalogs']={name:dict(sha256=sha(out/name)) for name in ('representative.json','jobs.json')}
identity['purpose']='Separate rule compilation, warm execution and time to result after removing single-comparison chain storage'
save(out/'identity.json',identity)
sdk=Path.home()/'.dotnet11'
env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk))
worker=repo/'benchmarks/cpython-worker.py'
assert sha(worker)==identity['cpythonWorkerSHA256']
for role,expected in identity['imageFiles'].items():
    image=lab/role
    assert len(expected)==32 and {p.name:sha(p) for p in image.iterdir()}==expected
    proof=out/f'{role}-verify.json'
    subprocess.run([sdk/'dotnet.exe',image/'Lokad.Lython.Benchmarks.dll','--compare','verify','--catalog',out/'representative.json',
        '--dotnet',sdk/'dotnet.exe','--python','C:/Python313/python.exe','--python-worker',worker,'--out',proof],env=env,cwd=repo,check=True,timeout=60)
    checked=read(proof)
    assert checked['state']=='Completed' and checked['caseCount']==2 and checked['launched']['library']['sha256']==expected['Lokad.Lython.dll']
    assert checked['catalogSha256']==identity['catalogs']['representative.json']['sha256']
shutil.copyfile(quiet/'run.sh',out/'run.sh')
assert b'\r' not in (out/'run.sh').read_bytes()
collector=(quiet/'collect.py').read_text(encoding='utf-8').replace('b1668-fixtures','b1668-confirm-fixtures').replace('len(jobs) == 5','len(jobs) == 4').replace('targetBatchSeconds=.63','targetBatchSeconds=.87')
compile(collector,'collect.py','exec')
write(out/'collect.py',collector)
donor=lab.with_name('defaulted-rule-phase-split-20261125')
launcher=(donor/'quiet.py').read_text(encoding='utf-8').replace("lab.parent / 'direct-operand-return-20261124/comparison/quiet'","lab / 'comparison/quiet'")
launcher=launcher.replace('lython-b1660-defaulted-rule-phase-split-20261125','lython-b1668-single-comparison-confirm-20261125')
launcher=launcher.replace('defaulted-rule-phase-split-b1660-20261125','single-comparison-confirm-b1668-20261125')
launcher=launcher.replace('direct-operand-return-b1659-20261124','single-comparison-b1668-20261125')
launcher=launcher.replace('seconds=202','seconds=215').replace('RuntimeMaxSec=260','RuntimeMaxSec=280')
launcher=launcher.replace('lab/"verified-raw-replicas.json"','output/"verified-raw-replicas.json"')
compile(launcher,'quiet-confirm.py','exec')
write(lab/'quiet-confirm.py',launcher)
with tarfile.open(quiet/'observations.tar.xz') as saved:
    raw=saved.extractfile('confirmation/confirmation.json').read()
save(out/'verified-raw-replicas.json',[dict(location='single-comparison-b1668-20261125',bytes=len(raw),
    archiveSHA256=terminal['archiveSHA256'],rawSHA256=hashlib.sha256(raw).hexdigest())])
report=(lab/'archive.py').read_text(encoding='utf-8').replace('lab/"comparison/quiet"','lab/"confirmation"')
report=report.replace('2026-11-25-single-comparison"','2026-11-25-single-comparison/confirmation"')
report=report.replace('receipt["warmJobs"]==5','receipt["warmJobs"]==4').replace('timedBatches=140,lanes=5','timedBatches=112,lanes=4')
compile(report,'archive-confirmation.py','exec')
write(lab/'archive-confirmation.py',report)
