from pathlib import Path
import hashlib,json,os,shutil,subprocess
lab=Path(__file__).parent; donor=lab.with_name('shared-parser-statements-20261124')/'reference-diagnostics'
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
sdk=Path.home()/'.dotnet11';env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk))
identity=read(lab/'comparison/quiet/identity.json')
operators=('<','<=','>','>=','==','!=','in','not in','is','is not')
sources=['print(2)','print(not True)','print(2 not False)','print(2 not)','print(2 is not)','print(2 < 3 not False)','print(2 < 3 is not)']
for op in operators:
 sources.extend((f'print(2 {op} parts)',f'print(2 {op})',f'print(not 2 {op} parts or True)'))
 for following in operators:
  sources.extend((f'print(2 {op} anything {following} parts)',f'print(2 {op} anything {following})'))
for end in ('\n','\r\n','\r'):
 sources.extend(end.join(('x = 1','y = 2',f'if x {op} y:','    print(x)',''))for op in operators)
sources.extend(['print('+'1 < '*count+'1)' for count in (1,2,100,200)])
input=lab/'diagnostic-input.json';input.write_text(json.dumps(sources)+'\n',encoding='utf-8',newline='\n')
reports=[]
for role,files in identity['imageFiles'].items():
 frozen=lab/role/'Lokad.Lython.dll';assert sha(frozen)==files[frozen.name]
 folder=lab/f'{role}-diagnostics';folder.mkdir(exist_ok=True)
 for p in donor.iterdir():shutil.copyfile(frozen if p.name==frozen.name else p,folder/p.name)
 output=lab/f'{role}-diagnostics.json'
 subprocess.run([sdk/'dotnet.exe',folder/'Inspect.dll',input,output],env=env,check=True,timeout=45)
 report=read(output);assert report['core']==files[frozen.name];reports.append(report['rows'])
assert reports[0]==reports[1],[(i,a,b) for i,(a,b) in enumerate(zip(*reports,strict=True)) if a!=b]
print(f'{len(sources)} exact diagnostic and refund comparisons, {sum(r["IsValid"] for r in reports[0])} valid.')
