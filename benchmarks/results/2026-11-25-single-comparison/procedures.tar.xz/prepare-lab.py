from pathlib import Path
import shutil
lab=Path(__file__).parent; source=lab.with_name('map-slots-20261125'); shared=lab.with_name('shared-function-local-slots-20261125')
read=lambda p:p.read_text(encoding='utf-8')
def write(name,s):
 compile(s,name,'exec');(lab/name).write_text(s,encoding='utf-8',newline='\n')
freeze=read(source/'freeze.py').replace("repo=lab.parents[3]", "repo=lab.parents[2]/'agent-worktrees/comparison-parser-20261125'").replace("revision.startswith('ac9f9211b')", "revision.startswith('0a4100a56')").replace("len(changed)==2 and all(p.startswith('src/Lokad.Lython/Runtime/') for p in changed)", "changed==['src/Lokad.Lython/Frontend/Parser.Expressions.cs']").replace('isolated map patch','isolated parser patch')
write('freeze.py',freeze)
prepare=read(source/'prepare.py')
first=prepare.index("catalog=read(");last=prepare.index('ident=dict(',first)
prepare=prepare[:first]+'''catalog=read(prior/'comparison/quiet/representative.json')
validator='scripts.config-generated-guards.medium.bad-0.sparse-lexical'
rules='scripts.rule-default-closures'
manifest='scripts.config-manifest.small'
selected=(validator,rules,manifest)
catalog['cases']=[r for r in catalog['cases'] if r['id'] in selected]
assert len(catalog['cases'])==3
python=Path('C:/Python313/python.exe')
save(quiet/'representative.json',catalog)
save(quiet/'jobs.json',dict(warm=[[validator,'compile'],[validator,'compile-run'],[manifest,'compile'],[rules,'compile'],[rules,'compile-run']]))
'''+prepare[last:]
prepare=prepare.replace("cwd=repo)==patch.read_bytes()", "cwd=lab.parents[2]/'agent-worktrees/comparison-parser-20261125')==patch.read_bytes()")
prepare=prepare.replace('Carry short map callback inputs and direct returns in native operand slots','Construct ordinary comparison syntax without chain storage').replace('b1667-fixtures','b1668-fixtures').replace('map-slots-b1667-20261125','single-comparison-b1668-20261125').replace('lython-b1667-single-comparison','lython-b1668-single-comparison').replace("'lython-b1667-map-slots-20261125'", "'lython-b1668-single-comparison-20261125'").replace(".replace('b1665','b1667')", ".replace('b1665','b1668')").replace('2026-11-25-map-slots','2026-11-25-single-comparison').replace('shipment report and two controls','validator, manifest and defaulted rules')
write('prepare.py',prepare)
shutil.copyfile(shared/'compile-allocation.py',lab/'compile-allocation.py')
