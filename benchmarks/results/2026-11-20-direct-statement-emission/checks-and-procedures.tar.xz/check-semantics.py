from pathlib import Path
import hashlib,json,os,shutil,subprocess

lab=Path(__file__).resolve().parent
cases={'definition-docstrings-and-class-cells': "class Base:\n    def value(self):\n        return 2\ndef make(add):\n    class Derived(Base):\n        def value(self):\n            'derived method'\n            return super().value() + add\n    return Derived\nitem=make(5)\nprint(item().value(), item.value.__doc__)\n", 'lazy-alias-uses-updated-function-and-class-names': 'def make():\n    label=int\n    type Alias = label\n    label=str\n    return Alias\nclass Example:\n    label=int\n    type Alias = label\n    label=str\nprint(make().__value__ is str, Example.Alias.__value__ is str)\n', 'alias-through-handler-and-nonlocal-scope': "def outer():\n    saved=None\n    def replace():\n        nonlocal saved\n        try:\n            raise ValueError('handled')\n        except ValueError:\n            type saved = tuple\n    replace()\n    return saved\nprint(outer().__value__ is tuple)\n", 'target-read-and-assignment-order': "events=[]\ndef value(name, result):\n    events.append(name)\n    return result\nitems=[0,0,0]\nvalue('target',items)[value('start',0):value('end',2)]=value('source',[4,5])\nvalue('receive',items)[value('index',0)]+=value('added',2)\nprint(items, events)\n", 'guard-and-generator-finally': "events=[]\ndef make():\n    try:\n        for packet in [(1,2),(4,5)]:\n            match packet:\n                case x,y if x > 2:\n                    yield x+y\n                case _:\n                    events.append(packet)\n    finally:\n        events.append('closed')\nitems=make()\nprint(next(items))\nitems.close()\nprint(events)\n", 'deferred-class-lambda-and-generators': "class Example:\n    numbers=(value * 2 for value in [1,2])\n    decorate=lambda self, text: '<{text}>'.format(text=text)\nprint(list(Example.numbers), Example().decorate('x'))\n"}
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
sdk=Path.home()/'.dotnet11'
env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk),PATH=str(sdk)+os.pathsep+os.environ['PATH'])
probe=Path('.git/agent-worktrees/direct-statement-emission/tools/LythonProbe/bin/Release/net11.0')
pair=load(lab/'frozen-identity.json')
body=json.dumps(list(cases.values())).encode('utf-8')
(lab/'probe-cases.json').write_bytes(body)
for role,files in pair['images'].items():
    source=lab/'frozen'/role
    assert len(files)==32 and {n:sha(source/n) for n in files}==files
    image=lab/'probe'/role
    shutil.copytree(probe,image,dirs_exist_ok=True)
    for file in image.glob('Lokad.*.dll'):
        if file.name in files:
            shutil.copyfile(source/file.name,file)
            assert sha(file)==files[file.name]
    assert sha(image/'Lokad.Lython.dll')==files['Lokad.Lython.dll']
    for async_mode in (False,True):
        args=[sdk/'dotnet.exe',image/'LythonProbe.dll','--batch-json','--compare-python','--python','C:/Python313/python.exe']
        if async_mode:args.append('--async')
        process=subprocess.run(args,input=body,capture_output=True,timeout=55,env=env)
        (lab/f'probe-{role}-{async_mode}.jsonl').write_bytes(process.stdout)
        assert process.returncode==0,(role,async_mode,process.stderr.decode(),process.stdout.decode())
        reports=[json.loads(line) for line in process.stdout.splitlines()]
        assert len(reports)==len(cases) and all(row['Matches'] and row['Compared'] for row in reports)
print(f'{len(cases)} CPython semantic probes pass in sync and async modes for both source images.')
