set -eu
export DOTNET_ROOT="$HOME/.dotnet"
lab=$PWD/.git/agent-notes/review-20261031/direct-statement-emission
export PATH="$DOTNET_ROOT:$lab/../compiler-callback-ownership/tools:$PATH"
command -v python
cd .git/agent-worktrees/direct-statement-emission
dotnet build tools/LythonProbe/LythonProbe.csproj -c Release -f net10.0 --no-incremental >"$lab/probe-ubuntu.log" 2>&1 || { tail -n 35 "$lab/probe-ubuntu.log"; exit 1; }
filter='(FullyQualifiedName~Compilation|FullyQualifiedName~CompilerCancellation|FullyQualifiedName~LoweringArchitecture|FullyQualifiedName~Annotation|FullyQualifiedName~Lambda|FullyQualifiedName~TypeAlias|FullyQualifiedName~Generator|FullyQualifiedName~Class|FullyQualifiedName~ProtectedLoop|FullyQualifiedName~Match|FullyQualifiedName~Import|FullyQualifiedName~AdmissionFailureCommand)&Category!=Stress'
for suite in Lokad.Lython.Tests Lokad.Lython.PublicApi.Tests; do
    log="$lab/$suite-ubuntu.log"
    dotnet test "tests/$suite/$suite.csproj" -c Release -f net10.0 --filter "$filter" >"$log" 2>&1 || { tail -n 55 "$log"; exit 1; }
    tail -n 7 "$log"
done
