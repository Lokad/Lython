set -eu
export DOTNET_ROOT="$HOME/.dotnet"
lab=$PWD/.git/agent-notes/review-20261031/direct-statement-emission-confirmation
export PATH="$DOTNET_ROOT:$lab/../compiler-callback-ownership/tools:$PATH"
cd .git/agent-worktrees/direct-statement-emission
filter='(FullyQualifiedName~ParserCompatibilityTests|FullyQualifiedName~FunctionDefinitionIsolationTests|FullyQualifiedName~ParameterLocalOrderTests|FullyQualifiedName~ReviewHardeningPublicTests|FullyQualifiedName~NativeReturnFunctionTests)&Category!=Stress'
log="$lab/supplemental-ubuntu.log"
dotnet test tests/Lokad.Lython.PublicApi.Tests/Lokad.Lython.PublicApi.Tests.csproj -c Release -f net10.0 --no-build --filter "$filter" >"$log" 2>&1 || { tail -n 48 "$log"; exit 1; }
tail -n 7 "$log"
