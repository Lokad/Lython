from pathlib import Path
import hashlib
import json
import shutil
import sys
import tarfile

lab = Path(__file__).resolve().parent
initial = lab.parent / 'direct-statement-emission'
quiet = lab / 'quiet'
out = Path('benchmarks/results/2026-11-20-direct-statement-emission/confirmation')
load = lambda p: json.loads(p.read_text(encoding='utf-8-sig'))
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
terminal = load(quiet / 'terminal-status.json')
receipt = load(quiet / 'archive-receipt.json')
assert terminal['exitCode'] == '0' and terminal['receipt'] == receipt and not terminal['live']
assert not terminal['remainingWorkers'] and not terminal['remainingTrace']
assert all(receipt[name] for name in ('complete','quietBeforeAndAfter','allWorkersJoined','guestFixturesRemoved','archivedAndVerifiedUnderLease'))
assert receipt['jobs'] == 3 and receipt['archiveSHA256'] == sha(quiet / 'observations.tgz')

pair = load(initial / 'frozen-identity.json')
assert pair['referenceCommit'].startswith('b418fa7d8') and pair['candidateCommit'].startswith('2131039a4')
assert pair['casesSHA256'] == sha(initial / 'catalog.json')
cases = {case['id']: case for case in load(initial / 'catalog.json')['cases']}
assert len(cases) == 5

for role, files in pair['images'].items():
    assert len(files) == 32 and {name: sha(initial / 'frozen' / role / name) for name in files} == files
    verified = load(initial / (role + '-verify.json'))
    assert verified['state'] == 'Completed' and verified['catalogSha256'] == pair['casesSHA256']
    assert all(row['sharedBudgetBaselineRestored'] for row in load(initial / (role+'-allocation.json'))['rows'])
    assert load(initial / (role+'-compile-allocation.log'))['coreSha256'] == files['Lokad.Lython.dll']
    for mode in (False, True):
        records = [json.loads(row) for row in (initial / f'probe-{role}-{mode}.jsonl').read_bytes().splitlines()]
        assert len(records) == 6 and all(r['Matches'] and r['Compared'] for r in records)

raw = load(quiet / 'retrieved/confirmation/confirmation.json')
assert raw['complete'] and raw['warmupSeconds'] >= 18 and len(raw['jobs']) == 3
batches = 0
for lane in raw['jobs']:
    assert lane['workersJoinedAndFixturesRemoved']
    case = cases[lane['case']]
    for label, worker in lane['identities'].items():
        files = pair['images'][label.split('-', 1)[0]]
        libraries = {Path(lib['path']).name: lib['sha256'].lower() for lib in worker['libraries']}
        assert libraries['Lokad.Lython.dll'] == files['Lokad.Lython.dll']
        assert all(libraries[name] == files[name] for name in libraries.keys() & files.keys())
    for sample in lane['samples']:
        response = sample['response']
        assert response['status'] == 'Completed' and response['completedInvocations'] > 0
        assert all(response[k] == case[k] for k in ('sourceSha256','fixtureSha256','expectedOutputSha256'))
        assert response.get('actualOutputSha256') == (None if lane['lane'] == 'compile' else case['expectedOutputSha256'])
        assert response.get('actualFilesSha256') == (None if lane['lane'] == 'compile' else case.get('expectedFilesSha256'))
        batches += 1
assert batches == 84

checks = ['Lokad.Lython.Tests-refined-win.log','Lokad.Lython.Tests-ubuntu.log',
    'Lokad.Lython.PublicApi.Tests-refined-win.log','Lokad.Lython.PublicApi.Tests-ubuntu.log']
for name, count in zip(checks, (545,545,4643,4643), strict=True):
    assert f'Failed:     0, Passed: {count:>5}' in (initial / name).read_text(encoding='utf-8-sig')

for platform in ('windows', 'ubuntu'):
    assert 'Failed:     0, Passed:   164' in (lab / f'supplemental-{platform}.log').read_text(encoding='utf-8-sig')

decision = sys.argv[1]
assert decision in ('retained', 'private')
out.mkdir(exist_ok=False)
for name in ('archive-receipt.json','terminal-status.json','observations.tgz'):
    shutil.copyfile(quiet / name, out / name)
inspection = load(lab / 'instruction-inspection-summary.json')
assert len(inspection) == 5 and all(row['sameCanonicalInstructionShape'] for row in inspection.values())
for role in ('reference', 'candidate'):
    assert load(lab / (role + '-instructions.json'))['imageSha256'] == pair['images'][role]['Lokad.Lython.dll']
shutil.copyfile(lab / 'instruction-inspection-summary.json', out / 'instruction-inspection-summary.json')
summary = load(lab / 'quiet-summary.json')
summary.pop('retentionDecisionPending', None)
summary.update(retentionDecision=decision, reference=pair['referenceCommit'], candidate=pair['candidateCommit'],
    cores={role: files['Lokad.Lython.dll'] for role, files in pair['images'].items()}, archiveSHA256=receipt['archiveSHA256'],
    verifiedBatches=batches, measuredCore='../measured-core.dll.gz',
    referenceCore='../reference-core.dll.gz', comparedInstructionShapeForFiveWorkloads=True)
(out / 'summary.json').write_text(json.dumps(summary,indent=2)+'\n', encoding='utf-8', newline='\n')
with tarfile.open(out / 'checks-and-procedures.tar.xz', 'w:xz', preset=6) as archive:
    for name in ('archive-evidence.py','stage-quiet.py','launch-quiet.py','summarize-quiet.py',
                 'retrieval.log','instruction-inspection/Program.cs','instruction-inspection/Inspection.csproj',
                 'reference-instructions.json','candidate-instructions.json','supplemental-windows.log',
                 'supplemental-windows-first.log','supplemental-ubuntu.log','test-supplemental.sh'):
        archive.add(lab / name, arcname=name)
    for name in ('identity.json','config.json','collect.py','archive-owned.py','run.sh','remote-launch.py',
                 'retrieve.py','launch.log','observe-not-before.json'):
        archive.add(quiet / name, arcname='quiet/'+name)
print('Verified both complete images, five CPython workload goldens, six semantic probes in both modes, and 84 timed batches.')
