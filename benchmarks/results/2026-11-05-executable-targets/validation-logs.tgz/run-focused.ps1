$ErrorActionPreference = 'Stop'
$env:DOTNET_ROOT='C:/Users/JoannesVermorel/.dotnet11'
$env:DOTNET_HOST_PATH="$env:DOTNET_ROOT/dotnet.exe"
$env:PATH="$env:DOTNET_ROOT;$env:PATH"
$targetNotes=Join-Path $PSScriptRoot ''
$targetPublicFilter='Category!=Stress&(FullyQualifiedName~Assignment|FullyQualifiedName~Augmented|FullyQualifiedName~Target|FullyQualifiedName~Unpack|FullyQualifiedName~Slice|FullyQualifiedName~Scope|FullyQualifiedName~Function|FullyQualifiedName~Closure|FullyQualifiedName~Generator|FullyQualifiedName~Class|FullyQualifiedName~Exception|FullyQualifiedName~Cancellation|FullyQualifiedName~GovernedMemory|FullyQualifiedName~Admission|FullyQualifiedName~Refus|FullyQualifiedName~Lifetime|FullyQualifiedName~Ownership|FullyQualifiedName~Shared|FullyQualifiedName~Protocol)'
dotnet test tests/Lokad.Lython.PublicApi.Tests/Lokad.Lython.PublicApi.Tests.csproj -c Release -f net11.0 --no-build --no-restore --filter $targetPublicFilter --logger 'console;verbosity=minimal' 2>&1 | Tee-Object -FilePath (Join-Path $targetNotes 'public-net11.0.log')
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
dotnet test tests/Lokad.Lython.Tests/Lokad.Lython.Tests.csproj -c Release -f net10.0 --no-build --no-restore --filter 'Category!=Stress' --logger 'console;verbosity=minimal' 2>&1 | Tee-Object -FilePath (Join-Path $targetNotes 'internal-net10.0.log')
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
dotnet test tests/Lokad.Lython.PublicApi.Tests/Lokad.Lython.PublicApi.Tests.csproj -c Release -f net10.0 --no-build --no-restore --filter $targetPublicFilter --logger 'console;verbosity=minimal' 2>&1 | Tee-Object -FilePath (Join-Path $targetNotes 'public-net10.0.log')
exit $LASTEXITCODE
