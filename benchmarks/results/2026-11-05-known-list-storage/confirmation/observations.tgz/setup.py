from pathlib import Path
import hashlib,json,shutil
root=Path("/home/lokad/lython-bench-checks/known-list-confirm-b256-20261105")
previous=Path('/home/lokad/lython-bench-checks/known-list-storage-b255-20261105')
if not (root/'baseline').is_symlink():(root/'baseline').symlink_to(previous/'baseline',target_is_directory=True)
assert (root/'baseline').resolve()==(previous/'baseline').resolve()
(root/'candidate').mkdir(exist_ok=True)
for f in (previous/'candidate').iterdir():
 (root/'candidate'/f.name).symlink_to(f.resolve(),target_is_directory=f.is_dir())
assert shutil.disk_usage(root).free>64*1024*1024
