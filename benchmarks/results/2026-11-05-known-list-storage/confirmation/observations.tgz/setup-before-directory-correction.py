from pathlib import Path
import hashlib,json,shutil
root=Path("/home/lokad/lython-bench-checks/known-list-confirm-b256-20261105")
previous=Path('/home/lokad/lython-bench-checks/known-list-storage-b255-20261105')
(root/'baseline').symlink_to(previous/'baseline',target_is_directory=True)
for f in (previous/'candidate').iterdir():
 if f.name=='Lokad.Lython.dll':continue
 (root/'candidate'/f.name).symlink_to(f.resolve(),target_is_directory=f.is_dir())
assert shutil.disk_usage(root).free>64*1024*1024
