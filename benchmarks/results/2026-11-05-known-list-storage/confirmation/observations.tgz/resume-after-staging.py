from pathlib import Path
import json,subprocess
root=Path('/home/lokad/lython-bench-checks/known-list-confirm-b256-20261105')
assert not (root/'started.utc').exists()
(root/'staging-correction.json').write_text(json.dumps(dict(initialSetupFailedBeforeService=True,cause='omitted empty candidate directory when reusing immutable core; no job timing',correction='create candidate directory and link exact original candidate core/auxiliaries; all parameters and binary hashes unchanged'),indent=2)+'\n')
subprocess.run(['python3',str(root/'setup.py')],check=True)
subprocess.run(['sudo','-n','systemd-run','--unit=lython-b256-known-list-confirm-20261105','--property=User=lokad','--property=WorkingDirectory='+str(root),'--property=RuntimeMaxSec=75','--property=TimeoutStopSec=30','--property=KillMode=control-group','/bin/sh',str(root/'collect.sh')],check=True)
