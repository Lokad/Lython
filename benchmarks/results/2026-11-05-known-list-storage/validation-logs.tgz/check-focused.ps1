$ErrorActionPreference='Stop'
$env:DOTNET_ROOT='C:/Users/JoannesVermorel/.dotnet11'
$env:DOTNET_HOST_PATH=$env:DOTNET_ROOT+'/dotnet.exe'
$env:PATH=$env:DOTNET_ROOT+';'+$env:PATH
$notes='D:/code/Lython/.git/agent-notes/review-20261031/known-list-storage-d33'
dotnet build tests/Lokad.Lython.Tests -c Release --no-restore -p:BuildProjectReferences=false *> ($notes+'/test-only-build.log')
if($LASTEXITCODE -ne 0){Get-Content ($notes+'/test-only-build.log') -Tail 20;exit $LASTEXITCODE}
$internal='Category!=Stress&(FullyQualifiedName~List|FullyQualifiedName~Csv|FullyQualifiedName~String|FullyQualifiedName~Json|FullyQualifiedName~NativeOperation|FullyQualifiedName~Governed|FullyQualifiedName~Admission|FullyQualifiedName~Ownership|FullyQualifiedName~Cancellation|FullyQualifiedName~PrimitiveStorage|FullyQualifiedName~RuntimeStorage|FullyQualifiedName~PartialNative)'
$public='Category!=Stress&(FullyQualifiedName~List|FullyQualifiedName~Csv|FullyQualifiedName~String|FullyQualifiedName~Json|FullyQualifiedName~NativeSequence|FullyQualifiedName~ComparisonFile|FullyQualifiedName~GovernedMemory|FullyQualifiedName~CooperativeCancellation|FullyQualifiedName~Ownership|FullyQualifiedName~Lifetime)'
foreach($framework in 'net11.0','net10.0') {
 foreach($suite in 'internal','public') {
  $project=if($suite -eq 'internal'){'tests/Lokad.Lython.Tests'}else{'tests/Lokad.Lython.PublicApi.Tests'}
  $filter=if($suite -eq 'internal'){$internal}else{$public}
  $logPath=$notes+'/'+$suite+'-'+$framework+'.log'
  dotnet test $project -c Release -f $framework --no-build --filter $filter *> $logPath
  $testExit=$LASTEXITCODE
  Get-Content $logPath -Tail 35
  if($testExit -ne 0){exit $testExit}
 }
}
