from pathlib import Path
import hashlib,importlib.util,json,os,shutil,subprocess,tempfile,time
r=Path(__file__).resolve().parent;repo=Path('D:/code/Lython');prior=r.parent/'buffered-yield-r510'
f=json.loads((prior/'frozen/identity.json').read_text(encoding='utf-8'));image=prior/'frozen/candidate'
assert all(hashlib.sha256((image/n).read_bytes()).hexdigest()==h for n,h in f['imageFiles']['candidate'].items())
assert f['imageFiles']['candidate']['Lokad.Lython.dll'].startswith('1bce52ad')
catalog=prior/'catalog.json';case=next(c for c in json.loads(catalog.read_text(encoding='utf-8'))['cases']if c['id']=='scripts.text-normalization.large')
spec=importlib.util.spec_from_file_location('protocol',repo/'benchmarks/cpython-worker.py');protocol=importlib.util.module_from_spec(spec);spec.loader.exec_module(protocol)
d=Path('C:/Users/JoannesVermorel/.dotnet11/dotnet.exe');env=os.environ.copy();env.update(DOTNET_ROOT=str(d.parent),DOTNET_ROOT_X64=str(d.parent));env['PATH']=str(d.parent)+os.pathsep+env['PATH']
fixture=Path(tempfile.mkdtemp(prefix='lython-r512-text-'));errors=(r/'worker.stderr').open('wb');worker=None;trace=None;seq=0;rows=[]
def request(operation,count):
 global seq
 seq+=1;v={k:case[k]for k in ['sourceSha256','fixtureSha256','expectedOutputSha256']};v.update(protocolVersion=2,requestId=seq,operation=operation,caseId=case['id'],lane='warm',iterations=count)
 protocol.write_frame(worker.stdin,v);reply=protocol.read_frame(worker.stdout)
 assert reply['requestId']==seq and reply['status']==('Equivalent'if operation=='verify'else'Completed'),reply
 assert reply['completedInvocations']==count and all(reply[k]==case[k]for k in ['sourceSha256','fixtureSha256','expectedOutputSha256'])
 assert reply['actualOutputSha256']==case['expectedOutputSha256']and reply['actualFilesSha256']==case['expectedFilesSha256']
 return reply
try:
 worker=subprocess.Popen([str(d),str(image/'Lokad.Lython.Benchmarks.dll'),'--compare','worker','--catalog',str(catalog)],cwd=fixture,env=env,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=errors)
 ready=protocol.read_frame(worker.stdout);assert ready['status']=='Ready'
 core=next(v for v in ready['libraries']if Path(v['path']).name=='Lokad.Lython.dll');assert core['sha256'].lower()==f['imageFiles']['candidate']['Lokad.Lython.dll']
 request('verify',2);warmup=[];started=time.monotonic()
 while time.monotonic()-started<3:warmup.append(request('batch',256))
 cmd=['C:/Users/JoannesVermorel/.dotnet/tools/dotnet-trace.exe','collect','--process-id',str(worker.pid),'--profile','gc-verbose','--buffersize','32','--duration','00:00:00:06','--output',str(r/'text.nettrace')]
 with(r/'trace.log').open('wb')as trace_log:
  trace=subprocess.Popen(cmd,env=env,stdout=trace_log,stderr=subprocess.STDOUT)
  # Keep the warmed worker active throughout startup and the bounded capture.
  started=time.monotonic()
  while trace.poll()is None and time.monotonic()-started<20:rows.append(request('batch',256))
  trace.wait(timeout=15);assert trace.returncode==0,(r/'trace.log').read_text(encoding='utf-8')
 (r/'capture.json').write_text(json.dumps(dict(boundary='One local warmed whole-worker allocation diagnostic, not a quiet elapsed comparison. GC tick sampling includes fixture resets, protocol, validation and cleanup; not exact per-type allocation bytes or removable CPU.',coreSHA256=core['sha256'],all32ImageFilesVerified=True,workerReady=ready,command=cmd,case=case['id'],warmup=warmup,responses=rows,traceBytes=(r/'text.nettrace').stat().st_size,traceSHA256=hashlib.sha256((r/'text.nettrace').read_bytes()).hexdigest(),publicationHeld=True),indent=2)+'\n',encoding='utf-8')
 print('One local allocation capture complete;',len(rows),'verified batches; bytes',(r/'text.nettrace').stat().st_size,flush=True)
finally:
 if trace is not None and trace.poll()is None:trace.terminate();trace.wait(timeout=15)
 if worker is not None:
  try:
   if worker.poll()is None:
    seq+=1;protocol.write_frame(worker.stdin,dict(protocolVersion=2,requestId=seq,operation='quit'));assert protocol.read_frame(worker.stdout)['status']=='Closed'
   assert worker.wait(timeout=10)==0
  finally:
   if worker.poll()is None:worker.kill();worker.wait()
   worker.stdin.close();worker.stdout.close()
 errors.close();assert fixture.parent==Path(tempfile.gettempdir())and fixture.name.startswith('lython-r512-text-');shutil.rmtree(fixture)
 assert (r/'worker.stderr').stat().st_size==0
