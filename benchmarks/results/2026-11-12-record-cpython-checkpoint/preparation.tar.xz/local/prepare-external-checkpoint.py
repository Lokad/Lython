from pathlib import Path
import ast,hashlib,json,shutil,subprocess,tarfile
r=Path(__file__).resolve().parent;q=r/'b616';q.mkdir(exist_ok=False)
old=r.parent/'text-output-batches-r263/b609';current=r.parent/'conditional-helper-r266/normalized/b614'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
identity=json.loads((current/'identity.json').read_text(encoding='utf-8'));h=identity['coreSHA256']['candidate'];identity['coreSHA256']={k:h for k in ['candidate','candidate-control']}
identity['sourceRevision']='da9e5066 compiler-only conditional helper; 34f2f325 evidence-only followup. Exact568 production hashes/a552 image. Full CI43183343974 pending. Refresh older CSV/JSON/guarded-search external rows at coherent delivery checkpoint; one capturedtext warm control tracks existing uncertainty. CPython3.13.16. Compile/warm/compile-run separate; no individual attribution or compounded source-pair gains.'
catalog=json.loads((r/'b615/catalog.json').read_text(encoding='utf-8'));more=json.loads((r.parent/'receiver-operations-r256/b603/representative.json').read_text(encoding='utf-8'))
cases={c['id']:c for c in catalog['cases']+more['cases']};selected=['scripts.csv-validated-records.large','scripts.json-summary-helpers.large','scripts.file-search.guarded-helper.large','scripts.text-summary-helpers.nonlocal-counter.large'];catalog['cases']=[cases[k]for k in selected]
(q/'representative.json').write_text(json.dumps(catalog,indent=2)+'\n',encoding='utf-8');identity['catalogSHA256']=sha(q/'representative.json');(q/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8');shutil.copyfile(current/'source-identity.json',q/'source-identity.json')
jobs=[[c,l]for c in selected[:3]for l in ['compile','warm','compile-run']]+[[selected[-1],'warm']]
name='record-cpython-b616-20261112';unit='lython-b616-record-cpython-20261112'
for n in ['collect.py','archive-owned.py','run.sh','launch.py','retrieve.py','summarize.py','remote-launch.py']:
 s=(old/n).read_text(encoding='utf-8').replace('output-cpython-b609-20261112',name).replace('lython-b609-output-cpython-20261112',unit).replace('output-cpython-b609-launch.py','record-cpython-b616-launch.py').replace('lython-b609-fixtures','lython-b616-fixtures').replace('B609','B616')
 if n=='collect.py':
  a=s.index('jobs=');b=s.index('\nenv =',a);s=s[:a]+'jobs='+repr(jobs)+'\nassert len(jobs)==10 and all(case in cases for case,lane in jobs)\n'+s[b:]
  a=s.index("purpose='");b=s.index("',\n                  warmupSeconds",a);s=s[:a]+"purpose='Retainedda9 complete CSVJSONguardedsearch checkpoint versusstockCPython3.13.16, capturedtextwarmuncertainty. Separatecompile/warm/compile-run; fixedworker/host/validation/cleanup. No isolatedattribution"+s[b:]
  s=s.replace(' < 355',' < 325')
  # Preserve the existing collection shape; longer warmup only for the known
  # captured-text uncertainty, without reinterpreting original adverse controls.
  s=s.replace('warmup_seconds = 5','warmup_seconds = 12 if case_id == "scripts.text-summary-helpers.nonlocal-counter.large" else 5')
 if n=='remote-launch.py':
  s=s.replace("source=base/'text-batches-b608-20261112/candidate'","source=base/'conditional-normalized-b614-20261112/candidate'")
  a=s.index('protected=');b=s.index('\nwith(base/',a);s=s[:a]+"protected={source/'Lokad.Lython.dll':config['identity']['coreSHA256']['candidate'],base/'text-batches-b608-20261112/candidate/Lokad.Lython.dll':'b2cbfdb6ebec288a356233356e81b72e9dfccdd57065ec53f668acd4ad1597fe'}"+s[b:]
  s=s.replace('jobs=12,ownerSeconds=390','jobs=10,ownerSeconds=360').replace('RuntimeMaxSec=390','RuntimeMaxSec=360')
 if n=='launch.py':s=s.replace('seconds=450','seconds=420').replace('ownerSeconds=390','ownerSeconds=360')
 if n=='archive-owned.py':s=s.replace("len(raw['jobs'])==12","len(raw['jobs'])==10").replace('complete=True,jobs=12','complete=True,jobs=10')
 if n=='retrieve.py':s=s.replace("['jobs']==12","['jobs']==10").replace("['elapsedSeconds']<390","['elapsedSeconds']<360").replace('twelve-job','ten-job')
 if n=='summarize.py':s=s.replace("len(raw['jobs'])==12","len(raw['jobs'])==10").replace('len(external)==12','len(external)==10')
 (q/n).write_text(s,encoding='utf-8',newline='\n')
 if n.endswith('.py')and n!='remote-launch.py':ast.parse(s)
with tarfile.open(q/'payload.tgz','w:gz')as t:
 for n in ['representative.json','source-identity.json','identity.json','collect.py','archive-owned.py','run.sh']:t.add(q/n,arcname=n)
with tarfile.open(q/'payload.tgz')as t:expanded=sum(((m.size+4095)//4096)*4096 for m in t.getmembers())
retire=[];archive=Path('benchmarks/results/2026-11-12-record-call-attribution/observations.tgz');assert archive.read_bytes()==subprocess.check_output(['git','show','HEAD:'+archive.as_posix()])
for member in [None,'catalog.json']:
 with tarfile.open(archive)as t:b=archive.read_bytes()if member is None else t.extractfile(member).read()
 spec=dict(kind='exact',knownPath='record-call-profile-b615-20261112/'+(member or 'observations.tgz'),bytes=len(b),sha256=hashlib.sha256(b).hexdigest(),canonicalStorage=archive.as_posix(),reason='Only terminal exact B615 evidence duplicates; committed34f2f325 canonicalGitSHA verified. Source a552 and referenceb2 protected, original adverseconditions preserved. Freshidle/UID/path/inode/all-alias proof, unchanged floors.')
 if member:spec.update(canonicalEntry=member,canonicalArchiveSHA256=sha(archive))
 retire.append(spec)
config=dict(root='/home/lokad/lython-bench-checks/'+name,unit=unit,payloadBytes=(q/'payload.tgz').stat().st_size,payloadSHA256=sha(q/'payload.tgz'),requiredFreeBytes=expanded+252*1024*1024,retire=retire,identity=identity)
(q/'config.json').write_text(json.dumps(config,indent=2)+'\n',encoding='utf-8')
ast.parse((q/'remote-launch.py').read_text(encoding='utf-8').replace('config=CONFIG','config='+repr(config)).replace('inventoryOnly=INVENTORY_ONLY','inventoryOnly=True'))
for n,needle in [('collect.py','len(jobs)==10'),('archive-owned.py',"len(raw['jobs'])==10"),('retrieve.py',"['jobs']==10"),('remote-launch.py','RuntimeMaxSec=360'),('launch.py','seconds=420'),('summarize.py','len(external)==10')]:assert needle in(q/n).read_text(encoding='utf-8'),n
print('10 existing-worker jobs,360sowner/325slaststart/420sobservation; refreshed material old rows and one uncertainty control, no new framework.')
