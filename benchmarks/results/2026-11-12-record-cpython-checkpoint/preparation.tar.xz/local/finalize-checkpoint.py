from pathlib import Path
import ast,hashlib,json,shutil,subprocess,tarfile
r=Path(__file__).resolve().parent;q=r/'b616';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for name in ['inventory.stdout','inventory.stderr','config.json','collect.py','payload.tgz']:shutil.copyfile(q/name,q/(name+'.first-staging'))
p=q/'collect.py';s=p.read_text(encoding='utf-8');s=s.replace('warmupSeconds=5, targetBatchSeconds=.15','warmupSeconds=5, capturedTextWarmupSeconds=12, targetBatchSeconds=.15');s=s.replace('count=1; end=time.monotonic()+5; rows=[]','count=1; end=time.monotonic()+(12 if case_id == "scripts.text-summary-helpers.nonlocal-counter.large" else 5); rows=[]');ast.parse(s);p.write_text(s,encoding='utf-8',newline='\n')
config=json.loads((q/'config.json').read_text(encoding='utf-8'));archive=Path('benchmarks/results/2026-11-12-record-call-attribution/observations.tgz');assert archive.read_bytes()==subprocess.check_output(['git','show','HEAD:'+archive.as_posix()])
with tarfile.open(archive)as t:
 for m in t.getmembers():
  if not m.isfile()or not m.size or not m.name.startswith('profiles/'):continue
  b=t.extractfile(m).read();config['retire'].append(dict(kind='exact',knownPath='record-call-profile-b615-20261112/'+m.name,bytes=len(b),sha256=hashlib.sha256(b).hexdigest(),canonicalStorage=archive.as_posix(),canonicalEntry=m.name,canonicalArchiveSHA256=sha(archive),reason='Only exact completed B615 raw profiles/maps/stacks/JIT duplicates; canonical committed34f2f325 Git/SHA verified locally. Fresh idle lease/UID/resolved path/inode/all-alias proof; current/reference core images protected, floors unchanged. Original first staging shortfall preserved.'))
with tarfile.open(q/'payload.tgz','w:gz')as t:
 for n in ['representative.json','source-identity.json','identity.json','collect.py','archive-owned.py','run.sh']:t.add(q/n,arcname=n)
with tarfile.open(q/'payload.tgz')as t:expanded=sum(((m.size+4095)//4096)*4096 for m in t.getmembers())
config.update(payloadBytes=(q/'payload.tgz').stat().st_size,payloadSHA256=sha(q/'payload.tgz'),requiredFreeBytes=expanded+252*1024*1024)
(q/'config.json').write_text(json.dumps(config,indent=2)+'\n',encoding='utf-8');print('First floor shortfall preserved, unchanged floors; exact committed profile duplicates added. Captured control warmup explicitly12s before any observation.')
