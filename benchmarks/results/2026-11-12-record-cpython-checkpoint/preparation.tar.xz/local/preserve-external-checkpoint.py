from pathlib import Path
import hashlib,json,shutil,tarfile
r=Path(__file__).resolve().parent;q=r/'b616';d=Path('benchmarks/results/2026-11-12-record-cpython-checkpoint');d.mkdir(exist_ok=False)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
receipt=json.loads((q/'archive-receipt.json').read_text(encoding='utf-8'));identity=json.loads((q/'identity.json').read_text(encoding='utf-8'))
assert receipt['complete']and receipt['jobs']==10 and receipt['allWorkersJoined']and receipt['guestFixturesRemoved']and receipt['quietBeforeAndAfter']and receipt['archivedAndVerifiedUnderLease']
assert sha(q/'observations.tgz')==receipt['archiveSHA256']
with tarfile.open(q/'observations.tgz')as t:assert hashlib.sha256(t.extractfile('current-core.dll').read()).hexdigest()==identity['coreSHA256']['candidate']
raw=json.loads((q/'retrieved/confirmation/confirmation.json').read_text(encoding='utf-8'))
for job in raw['jobs']:
 assert job['workersJoinedAndFixturesRemoved']
 for role,v in job['identities'].items():
  if not role.startswith('CPython'):assert next(x['sha256'].lower()for x in v['libraries']if Path(x['path']).name=='Lokad.Lython.dll')==identity['coreSHA256'][role]
shutil.copyfile('docs/BENCHMARKS.md',d/'prior-BENCHMARKS.md')
for n in ['observations.tgz','archive-receipt.json','identity.json','source-identity.json','summary.json','terminal-status.json','inventory.json','launch.log','observe-not-before.json']:shutil.copyfile(q/n,d/n)
shutil.copyfile(r/'operand-proof.md',d/'operand-proof.md')
with tarfile.open(d/'preparation.tar.xz','w:xz')as t:
 for p in q.iterdir():
  if p.is_file()and p.name not in ['observations.tgz','payload.tgz']:t.add(p,arcname=p.name)
 for n in ['prepare-external-checkpoint.py','finalize-checkpoint.py','preserve-external-checkpoint.py']:t.add(r/n,arcname='local/'+n)
(d/'README.md').write_text('''# Current CSV, JSON and guarded-search CPython checkpoint

2026-11-12, retained `da9e5066`, frozen a55202fb with precommit assembly metadata.
All 568 production sources match the exact fully qualified revision; later
34f2f325 changes evidence only. Fixed fec79 worker/optional nonpackable adapter0.4,
stock CPython3.13.16, quiet Azure F4as_v7 / Ubuntu24.04.4 / actual .NET11RC3,
ordinary GC/tiering. [Full delivery](../2026-11-12-conditional-helper-bodies/delivery/README.md)
passes Windows/Ubuntu, actual .NET11/10, original stress and installed consumers.

Ten jobs complete in 301.542 seconds: CSV validation, JSON-lines helpers and
guarded search, each with separate compile/warm/compile-to-result, plus captured
text warm control. Two independent processes per engine, seven rotating150ms
rounds, 5s warmups except captured text12s. Same scripts/fixtures on both engines.
All actual-image, stdout/files, allowance, quiet/join/RAM/persistent archival gates
pass; local SHA verifies the archive. Terminal cached; no remaining users.

| Script | Warm Lython / CPython | Compile-to-result | Limits |
| --- | --- | --- | --- |
| CSV validation | 1.03–1.04× | 1.05–1.09× | Warm IQR3.28%; result Lython process spread2.88% |
| JSON-lines | 0.85–0.91× | 0.85–0.87× | Warm Lython spread5.82%; compilation IQR3.50% |
| Guarded search | 1.81–1.99× | 1.61–1.78× | Warm spreads L5.82%/P3.55%; result L8.02%; compile IQR5.44% |
| Captured text | 1.65–1.67× | Not refreshed | This absolute control is stable; it does not resolve causality or disprove original source-pair adversity |

Ratios span all four process-median pairings, not confidence intervals. Separate
source pairs are not compounded into these ratios. Captured-text compile/result
and other unrefreshed guide rows retain their original source/date labels.

Warm/result clocks include public invocation, mediated RAM I/O, complete stdout/
file validation and prior-result cleanup; exclude startup, compile in warm,
fixture staging/reset, protocol and final cache disposal. Compilation includes
construction/disposal under the shared allowance. Wider process CPU includes
reset/protocol. No RSS, pending-I/O, embedding-tail or large-file claim.

Guarded search and captured text retain material gaps, reports retain their
separately measured gap, and CSV/JSON no longer justify broad collection rewrites
from old timings. The [bounded operand source proof](operand-proof.md) records
real transport/effect-order obstacles; no duplicate frame or speculative new
dispatcher, arena, proof scratch vector or tagged-value layer is introduced.
This checkpoint guides the continuing roadmap, not completion of the objective.

First staging refused before mutation: available256659456 plus exact reclaim
3256320 was below required264699904. Add only exact committed B615 raw profile/
map/stack/JIT duplicates, preserving the initial condition and unchanged floors.
Fresh lease, UID/resolved-path/inode/link-count and canonical Git/SHA proofs
precede removal. A unique POSIX link already proves the complete alias set;
multi-link images still require enumeration. Current/reference cores stay
protected. Final archive leaves262340608 bytes free, above the240MiB OS floor.
Publication/tagging and final released-adapter qualification remain postponed.
''',encoding='utf-8')
p=Path('docs/BENCHMARKS.md');s=p.read_text(encoding='utf-8');data=json.loads((q/'summary.json').read_text(encoding='utf-8'));rows={(x['case'],x['lane']):x for x in data['timing']}
mapping={'CSV validation/helper calls':'scripts.csv-validated-records.large','JSON-lines/helpers':'scripts.json-summary-helpers.large','File search / guarded helper':'scripts.file-search.guarded-helper.large','Text / captured helper + counter':'scripts.text-summary-helpers.nonlocal-counter.large'}
seen={k:0 for k in mapping};output=[]
for line in s.splitlines():
 label=next((k for k in mapping if line.startswith('| '+k+' |')),None)
 if label:
  i=seen[label];seen[label]+=1;lane=['compile-run','warm','compile'][i];x=rows.get((mapping[label],lane))
  if x is not None:
   cells=[v.strip()for v in line.split('|')[1:-1]];prefix=cells[:2]if i==0 else cells[:1]
   def fmt(values):
    a,b=min(values),max(values)
    return f'{a*1000:.2f}–{b*1000:.2f} µs'if b<1 else f'{a:.3f}–{b:.3f} ms'
   cells=prefix+[fmt(x['timeRangeMilliseconds']),fmt(x['pythonTimeRangeMilliseconds']),f"{min(x['ratioRange']):.2f}–{max(x['ratioRange']):.2f}×",'`da9e5066`',f"{x['status']}; L{x['controlPercent']:.2f}%, P{x['pythonControlPercent']:.2f}% / {max(x['iqrPercent'].values()):.2f}%"]
   line='| '+' | '.join(cells)+' |'
 output.append(line)
assert all(v==3 for v in seen.values());s='\n'.join(output)+'\n'
a=s.index('**Measured sources:**');b=s.index('Earlier rows remain historical:',a)
s=s[:a]+'''**Measured sources:** collected 2026-11-12: `da9e5066` for CSV validation,
JSON-lines, guarded search and captured-text warm execution, frozen core `a55202fb`.
[Full delivery](../benchmarks/results/2026-11-12-conditional-helper-bodies/delivery/README.md)
passes Windows/Ubuntu, actual .NET 11/10, original stress and installed Release
consumers; all 568 frozen production source files match. `983bab96` remains the
UTF-8/UTF-16 reports, ordinary text, and captured-text compilation/compile-to-result,
frozen `b2cbfdb6`, [fully qualified](../benchmarks/results/2026-11-12-text-output-batches/delivery/README.md).
`82ed92d4` remains keyword-default search. All use stock CPython 3.13.16 on the same
quiet VM. Sources are labelled per row; these collections do not describe later HEAD.
'''+s[b:]
a=s.index('The [current four-script checkpoint]');b=s.index('The captured-helper variant',a)
s=s[:a]+'''The [current record/search checkpoint](../benchmarks/results/2026-11-12-record-cpython-checkpoint/README.md)
and [report/text checkpoint](../benchmarks/results/2026-11-12-output-cpython-checkpoint/README.md)
separate compilation, warm execution and compile-to-result. Guarded search,
captured text and reports retain material warm gaps. CSV is close and JSON-lines
is faster in these observations, with variability shown. All output, ownership,
quiet, joined-user and archival checks pass. Original/adverse controls and
replaced rows remain linked; cross-collection differences do not isolate a change.

'''+s[b:]
a=s.index('five-second warmups per role/job');b=s.index('These observations do not qualify',a)
s=s[:a]+'''five-second warmups per role/job and seven rotated 150 ms rounds; the latest
captured-text warm control uses twelve-second warmups. Current record/search rows
use `a55202fb`/`da9e5066`; report/text rows retain `b2cbfdb6`/`983bab96` as labelled.
Keyword-default search keeps `0106a711`/`82ed92d4`. All reuse common worker `fec79afd`
and adapter 0.4. Other rows retain their recorded images.
'''+s[b:]
s=s.replace('Full delivery pending. [Source pair](../benchmarks/results/2026-11-12-conditional-helper-bodies/normalized/README.md)','Windows/Ubuntu, both targets, original stress and installed consumers pass. [Source pair](../benchmarks/results/2026-11-12-conditional-helper-bodies/normalized/README.md)',1)
p.write_text(s,encoding='utf-8')
p=Path('benchmarks/EXPERIMENTS.md');s=p.read_text(encoding='utf-8');i=s.index('[Current CSV/report attribution]');s=s[:i]+'''[Current record/search CPython checkpoint](results/2026-11-12-record-cpython-checkpoint/README.md)
finishes10jobs301.542s, all identity/output/ownership/quiet/join/RAM/archive gates.
Qualified da9e5066 warm CSV1.03–1.04×, JSON-lines0.85–0.91×, guardedsearch1.81–1.99×;
captured text1.65–1.67× absolute control is stable. Compile/result stay separate;
guarded/JSON spreads and all adversity survive. Captured source-pair causality
remains unresolved. No compounded gains or equivalence claim. Bounded operand
proof identifies actual array/suspension/effect-order obstacles without a new
runtime prototype. Publication held; substantial performance work continues.

'''+s[i:];p.write_text(s,encoding='utf-8')
files={p.relative_to(d).as_posix():sha(p)for p in d.rglob('*')if p.is_file()};(d/'files-sha256.json').write_text(json.dumps(files,indent=2)+'\n',encoding='utf-8')
with Path('.gitattributes').open('a',encoding='utf-8')as f:f.write('\nbenchmarks/results/2026-11-12-record-cpython-checkpoint/** -text whitespace=cr-at-eol\n')
print('Current external rows, separate phases, limits and old guide preserved; full qualification linked without repeating it.')
