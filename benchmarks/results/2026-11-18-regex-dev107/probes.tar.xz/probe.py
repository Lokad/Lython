from pathlib import Path
import hashlib, json, os, shutil, subprocess, zipfile

lab = Path(__file__).resolve().parent
repo = Path.cwd()
source = Path('D:/code/utf8regex/artifacts/package-candidates/0.5.0-dev.107')
base = lab.parent / 'regex-dev106-r543'
load = lambda path: json.loads(path.read_text(encoding='utf-8-sig'))
sha = lambda data: hashlib.sha256(data).hexdigest()
receipt = load(source / 'candidate.json')
assert receipt['PackageVersion'] == '0.5.0-dev.107' and receipt['CleanSource'] and not receipt['Published']
assert receipt['SourceRevision'] == '7be42c66c60a63afea78523cd26df8ecc108316a'
sdk = Path.home() / '.dotnet11'
env = dict(os.environ, DOTNET_ROOT=str(sdk), DOTNET_ROOT_X64=str(sdk),
           PATH=str(sdk)+os.pathsep+os.environ['PATH'])
report = dict(producer=receipt['SourceRevision'], packageVersion=receipt['PackageVersion'],
              coreSource='7a0bc456b', probes=[], files={})
for target in ['net11.0','net10.0']:
    image = lab / 'probes' / target
    shutil.copytree(base / 'probes-supported' / target, image, copy_function=shutil.copyfile)
    # The current built runtime has the same Lython provider ABI as the
    # separately compiled development adapter from R543.
    core = lab.parent / 'function-annotation-storage-r583/frozen/candidate/Lokad.Lython.dll' if target == 'net11.0' else repo / 'src/Lokad.Lython/bin/Release/net10.0/Lokad.Lython.dll'
    shutil.copyfile(core, image / core.name)
    image_hashes = {}
    for row in receipt['Packages']:
        if row['Id'] not in ['Lokad.Utf8Regex', 'Lokad.Utf8Regex.PythonRe'] or row['TargetFramework'] != target: continue
        package = source / row['RelativePath']
        assert sha(package.read_bytes()) == row['PackageSha256'].lower()
        filename = row['Id'] + '.dll'
        with zipfile.ZipFile(package) as nupkg:
            assembly = nupkg.read(f'lib/{target}/{filename}')
        assert sha(assembly) == row['AssemblySha256'].lower()
        (image / filename).write_bytes(assembly)
        image_hashes[filename] = dict(packageSha256=row['PackageSha256'], assemblySha256=row['AssemblySha256'])
    assert len(image_hashes) == 2
    hashes = {str(p.relative_to(image)).replace(chr(92), '/'): sha(p.read_bytes()) for p in image.rglob('*') if p.is_file()}
    report['files'][target] = dict(imageHashes=hashes, producerHashes=image_hashes)
    for api in ['sync', 'async']:
        assert all(sha((image / name).read_bytes()) == digest for name, digest in hashes.items())
        args = [sdk / 'dotnet.exe', image / 'LythonProbe.dll', lab/'semantics.py', '--json',
                '--compare-python', '--python', 'C:/Python313/python.exe', '--max-memory-bytes', '4194304']
        if api == 'async': args += ['--async']
        run = subprocess.run(args, env=env, capture_output=True, timeout=30)
        name = f'{target}-{api}.json'
        (lab / name).write_bytes(run.stdout)
        (lab / f'{target}-{api}.stderr').write_bytes(run.stderr)
        data = json.loads(run.stdout.decode('utf-8'))
        report['probes'].append(dict(framework=target, api=api, exitCode=run.returncode, match=data['Matches']))
        (lab / 'result.json').write_text(json.dumps(report,indent=2)+'\n', encoding='utf-8')
        print(target, api, run.returncode, data['Matches'], flush=True)
