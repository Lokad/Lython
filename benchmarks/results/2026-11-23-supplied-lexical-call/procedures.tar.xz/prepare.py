from pathlib import Path
import copy, hashlib, json, os, shutil, subprocess, textwrap

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
tree = repo / '.git/agent-worktrees/supplied-operand-window-20261123'
prior = lab.parent / 'supplied-operand-window-20261123'
comparison = lab / 'comparison'
comparison.mkdir(exist_ok=True)
read = lambda p: json.loads(p.read_text(encoding='utf-8-sig'))
sha = lambda data: hashlib.sha256(data).hexdigest()
digest = lambda path: sha(path.read_bytes())
def write(path, data):
    path.write_text(json.dumps(data, indent=2, ensure_ascii=False) + '\n', encoding='utf-8', newline='\n')
git = lambda *args: subprocess.check_output(['git','-C',tree,*args]).decode().strip()
reference, candidate = git('rev-parse','HEAD^'), git('rev-parse','HEAD')
assert not git('status','--porcelain')
assert reference.startswith('faf86299e')
dotnet = Path.home() / '.dotnet11/dotnet.exe'
python = 'C:/Python313/python.exe'
env = dict(os.environ, DOTNET_ROOT=str(dotnet.parent), DOTNET_ROOT_X64=str(dotnet.parent))

catalog = read(prior/'comparison/representative.json')
module, function, quote, floating, _ = catalog['cases']
assert module['id']=='scripts.ordinary-fully-supplied-helper'
assert function['id']==module['id']+'.local-function'
write(comparison/'representative.json',catalog)
jobs = [(function['id'],'warm'), (function['id'],'compile-run'), (module['id'],'warm'),
    (quote['id'],'warm'), (floating['id'],'warm')]
write(comparison/'jobs.json',{'warm':jobs})

protocol = repo/'benchmarks/cpython-worker.py'
proof = read(prior/'comparison/identity.json')
assert digest(protocol) == proof['cpythonWorkerSHA256']
core = 'Lokad.Lython.dll'
actual = {}
for role in ('reference','candidate'):
    image = lab/role
    image.mkdir(exist_ok=True)
    files = proof['imageFiles']['candidate']
    assert len(files) == 32
    for name, expected in files.items():
        donor = prior/'candidate'/name
        assert digest(donor) == expected
        if role == 'candidate' and name == core:
            donor = prior/'generic-entry/bin/Lokad.Lython/release_net11.0'/core
        shutil.copyfile(donor,image/name)
    actual[role] = {name:digest(image/name) for name in files}
    for helper in ('ValidatedAllocation','Inspect'):
        for suffix in ('.dll','.deps.json','.runtimeconfig.json'):
            name = helper+suffix
            shutil.copyfile(prior/'candidate'/name,image/name)
    subprocess.run([dotnet,image/'Inspect.dll',comparison/'representative.json',lab/(role+'-tape.json')],
        env=env, check=True, timeout=35)
    verification = comparison/(role+'-verify.json')
    subprocess.run([dotnet,image/'Lokad.Lython.Benchmarks.dll','--compare','verify','--catalog',comparison/'representative.json',
        '--dotnet',dotnet,'--python',python,'--python-worker',protocol,'--out',verification],env=env,check=True,timeout=95)
    data = read(verification)
    assert data['state']=='Completed' and data['caseCount']==5
    assert data['launched']['library']['sha256']==actual[role][core]
    assert all(digest(image/name)==expected for name,expected in actual[role].items())
assert [name for name in files if actual['reference'][name]!=actual['candidate'][name]]==[core]
assert actual['reference'][core] == proof['imageFiles']['candidate'][core]
write(comparison/'identity.json',dict(sourceRevision=reference,candidate=candidate,
    purpose='B1526 use one prepared exact-integer update entry after ordinary and checked local reads',
    imageFiles=actual,coreSHA256={k:rows[core] for role,rows in actual.items() for k in (role,role+'-control')},
    cpythonWorkerSHA256=proof['cpythonWorkerSHA256'],expectedCPythonSHA256=proof['expectedCPythonSHA256'],
    catalogs={name:dict(sha256=digest(comparison/name)) for name in ('representative.json','jobs.json')}))

def adapt(name, replacements):
    source = (prior/name).read_text(encoding='utf-8')
    for before, after in replacements:
        assert before in source, (name,before)
        source = source.replace(before, after)
    compile(source,str(lab/name),'exec')
    (lab/name).write_text(source,encoding='utf-8',newline='\n')

adapt('allocations.py',())
adapt('stage.py',(
    ('supplied-operand-window-b1524-20261123','supplied-lexical-call-b1526-20261123'),
    ('supplied-call-accumulation-b1522-20261123','supplied-operand-window-b1524-20261123'),
    ('lython-b1524-fixtures','lython-b1526-fixtures'),('len(jobs) == 6','len(jobs) == 5'),('< 320,','< 270,'),
))
adapt('quiet.py',(
    ('lython-b1524-supplied-operand-window-20261123','lython-b1526-supplied-lexical-call-20261123'),
    ('.+b1524-','.+b1526-'),('lython-b1524-stage-','lython-b1526-stage-'),
    ('Six bounded lanes write under 1 MiB of receipts. A 47 MiB',
     'Five bounded lanes write under 1 MiB of receipts. A 40 MiB'),
    ('47 * 1024 * 1024','40 * 1024 * 1024'),
    ('RuntimeMaxSec=380','RuntimeMaxSec=320'),('seconds=294','seconds=248'),
))
adapt('summarize.py',(
    ('== 6\nassert hashlib','== 5\nassert hashlib'),('len(warm["jobs"])==6','len(warm["jobs"])==5'),
    ('timedBatches=168','timedBatches=140'),
))
adapt('tape_diff.py',())
