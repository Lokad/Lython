from pathlib import Path
import json
import re

lab = Path(__file__).resolve().parent
read = lambda path: json.loads(path.read_text(encoding='utf-8-sig'))
old = read(lab/'reference-tape.json')
new = read(lab/'candidate-tape.json')
source = (lab.parents[3]/'src/Lokad.Lython/Frontend/ExecutableScript.cs').read_text(encoding='utf-8')
names = re.findall(r'^\s*(\w+),\s*$',source.split('enum ExecutableOpCode',1)[1].split('}',1)[0],re.M)
changes = []
code_count = 0
for before, after in zip(old['rows'],new['rows'],strict=True):
    assert before['id']==after['id']
    for a,b in zip(before['codes'],after['codes'],strict=True):
        code_count += 1
        for index,(first,second) in enumerate(zip(a['tape'],b['tape'],strict=True)):
            if first == second:
                continue
            diffs = {k:(first[k],second[k]) for k in first if first[k] != second[k]}
            changes.append(dict(case=before['id'],scope=a['name'],index=index,
                opcode=names[first['<OpCode>k__BackingField']],changes=diffs))
print(code_count,changes)
result = dict(reference=old['coreSHA256'],candidate=new['coreSHA256'],
    inspectedBodies=code_count,onlyInstructionChanges=changes)
(lab/'tape-summary.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8',newline='\n')
