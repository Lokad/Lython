from pathlib import Path
import hashlib, json, os, re, subprocess, textwrap

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
tree=repo/'.git/agent-worktrees/supplied-operand-window-20261123'
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
write=lambda p,data:p.write_text(json.dumps(data,indent=2)+'\n',encoding='utf-8',newline='\n')
catalog=read(lab/'comparison/representative.json')
programs=(tree/'tests/Lokad.Lython.PublicApi.Tests/SharedIntegerChainTests.cs').read_text(encoding='utf-8')
programs=re.findall(r'const string source = """\n(.*?)\n\s+""";',programs,re.S)
cancel=next(text for text in programs if 'def increase(number, adjustment):' in text)
identity=next(text for text in programs if 'print(local(observed, 512, item, 500))' in text)
def case(name, source):
    item=catalog['cases'][0].copy()
    source=textwrap.dedent(source)+'\n'
    item.update(id=name,source=source,sourceUtf8Bytes=len(source.encode()),
        sourceSha256=hashlib.sha256(source.encode()).hexdigest())
    return item
catalog['cases']=[case('cancellation-and-cleanup',cancel),case('observing-fallback-and-suspension',identity)]
path=lab/'test-tape-catalog.json'
write(path,catalog)
dotnet=Path.home()/'.dotnet11/dotnet.exe'
env=dict(os.environ,DOTNET_ROOT=str(dotnet.parent),DOTNET_ROOT_X64=str(dotnet.parent))
out=lab/'test-tape.json'
subprocess.run([dotnet,lab/'candidate/Inspect.dll',path,out], env=env,check=True,timeout=35)
source=(tree/'src/Lokad.Lython/Frontend/ExecutableScript.cs').read_text(encoding='utf-8')
opcodes=re.findall(r'^\s*(\w+),\s*$',source.split('enum ExecutableOpCode',1)[1].split('}',1)[0],re.M)
opcode=opcodes.index('IntegerCallUpdate')
selected={}
for item in read(out)['rows']:
    selected[item['id']]=[(body['name'],i) for body in item['codes'] for i, op in enumerate(body['tape'])
        if op['<OpCode>k__BackingField']==opcode]
print(selected)
assert any(scope=='compute' for scope,_ in selected['cancellation-and-cleanup'])
assert any(scope=='local' for scope,_ in selected['observing-fallback-and-suspension'])
write(lab/'test-tape-summary.json',selected)
