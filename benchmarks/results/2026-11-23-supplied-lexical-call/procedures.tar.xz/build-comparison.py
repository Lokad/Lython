from pathlib import Path

lab = Path(__file__).resolve().parent
original = lab.parent/'supplied-operand-window-20261123/prepare.py'
source = original.read_text(encoding='utf-8')
begin = source.index('original = read(')
end = source.index('protocol =',begin)
source = source[:begin]+"""catalog = read(prior/'comparison/representative.json')
module, function, quote, floating, _ = catalog['cases']
assert module['id']=='scripts.ordinary-fully-supplied-helper'
assert function['id']==module['id']+'.local-function'
write(comparison/'representative.json',catalog)
jobs = [(function['id'],'warm'), (function['id'],'compile-run'), (module['id'],'warm'),
    (quote['id'],'warm'), (floating['id'],'warm')]
write(comparison/'jobs.json',{'warm':jobs})

"""+source[end:]
updates = (
    ("prior = lab.parent / 'supplied-call-accumulation-20261123'", "prior = lab.parent / 'supplied-operand-window-20261123'"),
    ("reference.startswith('4b2700e5a')","reference.startswith('faf86299e')"),
    ("lab/'frozen/bin/Lokad.Lython/release_net11.0'/core","prior/'generic-entry/bin/Lokad.Lython/release_net11.0'/core"),
    ('B1524 reuse the exact integer argument window and accumulator before closed calls',
     'B1526 use one prepared exact-integer update entry after ordinary and checked local reads'),
    ("('supplied-call-accumulation-b1522-20261123','supplied-operand-window-b1524-20261123')",
     "('supplied-operand-window-b1524-20261123','supplied-lexical-call-b1526-20261123')"),
    ("('csv-short-utf8-typed-reader-b1520-20261123','supplied-call-accumulation-b1522-20261123')",
     "('supplied-call-accumulation-b1522-20261123','supplied-operand-window-b1524-20261123')"),
)
for a,b in updates:
    assert source.count(a)==1,a
    source=source.replace(a,b)
start=source.index("adapt('allocations.py'")
source=source[:start]+"""adapt('allocations.py',())
adapt('stage.py',(
    ('supplied-operand-window-b1524-20261123','supplied-lexical-call-b1526-20261123'),
    ('supplied-call-accumulation-b1522-20261123','supplied-operand-window-b1524-20261123'),
    ('lython-b1524-fixtures','lython-b1526-fixtures'),('len(jobs) == 6','len(jobs) == 5'),('< 320,','< 270,'),
))
adapt('quiet.py',(
    ('lython-b1524-supplied-operand-window-20261123','lython-b1526-supplied-lexical-call-20261123'),
    ('.+b1524-','.+b1526-'),('lython-b1524-stage-','lython-b1526-stage-'),
    ('Six bounded lanes write under 1 MiB of receipts. A 47 MiB',
     'Five bounded lanes write under 1 MiB of receipts. A 40 MiB'),
    ('47 * 1024 * 1024','40 * 1024 * 1024'),
    ('RuntimeMaxSec=380','RuntimeMaxSec=320'),('seconds=294','seconds=248'),
))
adapt('summarize.py',(
    ('== 6\\nassert hashlib','== 5\\nassert hashlib'),('len(warm["jobs"])==6','len(warm["jobs"])==5'),
    ('timedBatches=168','timedBatches=140'),
))
adapt('tape_diff.py',())
"""
target=lab/'prepare.py'
compile(source,str(target),'exec')
target.write_text(source,encoding='utf-8',newline='\n')
