#!/bin/bash
set -euo pipefail
export DOTNET_ROOT="$HOME/.dotnet"
export PATH="$DOTNET_ROOT:$PATH"
cd /mnt/d/code/Lython
lab="$PWD/.git/agent-notes/review-20261031/generator-resume-protocol-20261127"
export NUGET_PACKAGES="$PWD/.git/agent-notes/review-20261031/regex-released-050-20261127/packages-ubuntu"
public=tests/Lokad.Lython.PublicApi.Tests/Lokad.Lython.PublicApi.Tests.csproj
internal=tests/Lokad.Lython.Tests/Lokad.Lython.Tests.csproj
public_filter='Category!=Stress&(FullyQualifiedName~GeneratorExpressionBoundary|FullyQualifiedName~GeneratorStorageSemantics|FullyQualifiedName~ComprehensionSuper|FullyQualifiedName~Starmap|FullyQualifiedName~BulkGeneratorConsumptionTests|FullyQualifiedName~BufferedGeneratorContinuationTests|FullyQualifiedName~GeneratorCleanupCompositionTests|FullyQualifiedName~IteratorProtocolScenarioTests|FullyQualifiedName~StarredCall|FullyQualifiedName~ExpandedCallExecutionTests|FullyQualifiedName~ExecutableCallLifetimeTests|FullyQualifiedName~PositionalCallSemanticsTests|FullyQualifiedName~PreparedCallArgumentTests)'
internal_filter='Category!=Stress&(FullyQualifiedName~CallablePacketOwnershipTests|FullyQualifiedName~IterationWorkspaceLifetimeTests|FullyQualifiedName~SynchronousGeneratorAdvanceTests|FullyQualifiedName~ExecutableAsyncIteratorCleanupTests|FullyQualifiedName~ExecutableIteratorCleanupTests|FullyQualifiedName~GeneratorPreparedSliceOwnershipTests)'
cp /dev/null "$lab/ubuntu.log"
{
  dotnet restore "$public" --locked-mode --artifacts-path "$lab/ubuntu" --source https://api.nuget.org/v3/index.json
  dotnet restore "$internal" --locked-mode --artifacts-path "$lab/ubuntu" --source https://api.nuget.org/v3/index.json
  for framework in net10.0; do
    dotnet test "$public" -c Release -f "$framework" --no-restore --artifacts-path "$lab/ubuntu" --filter "$public_filter"
    dotnet test "$internal" -c Release -f "$framework" --no-restore --artifacts-path "$lab/ubuntu" --filter "$internal_filter"
  done
} 2>&1 | tee "$lab/ubuntu.log"
