set -eu
root=/home/lokad/lython-bench-checks/activation-allocation-b261-20261105
dotnet=/home/lokad/lython-bench-toolchains/dotnet/11.0.100-rc.3.26522.148/dotnet
export DOTNET_ROOT=/home/lokad/lython-bench-toolchains/dotnet/11.0.100-rc.3.26522.148
export TMPDIR=/dev/shm
exec 9>/home/lokad/lython-bench-checks/comparison-vm.lock
flock -n 9
sleep 5
date -u +%FT%TZ > "$root/started.utc"
trap 'exit 143' TERM
trap 'result=$?; printf "%s\n" "$result" > "$root/exit-code.txt"; date -u +%FT%TZ > "$root/stopped.utc"' EXIT
worker=/home/lokad/lython-bench-checks/runtime-cpython-b260-20261105/candidate/Lokad.Lython.Benchmarks.dll
"$dotnet" "$worker" --compare check-machine --out "$root/machine-before.json"
python3 "$root/profile.py"
sleep 5
"$dotnet" "$worker" --compare check-machine --out "$root/machine-after.json"
