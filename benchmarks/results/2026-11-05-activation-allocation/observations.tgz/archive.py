from pathlib import Path
import fcntl,hashlib,json,subprocess,tarfile

root=Path('/home/lokad/lython-bench-checks/activation-allocation-b261-20261105')
status=subprocess.check_output(['systemctl','show','lython-b261-activation-allocation-20261105','--property=LoadState,ActiveState,MainPID,Result'],text=True)
assert 'ActiveState=inactive' in status and 'MainPID=0' in status and 'Result=success' in status,status
assert (root/'exit-code.txt').read_text().strip()=='0'
records=json.loads((root/'records.json').read_text());assert len(records)==2
assert all(r['workerClosedAndJoined'] and r['collectorJoined'] and r['collector']['eventsLost']==0 for r in records)
for n in ('before','after'):assert json.loads((root/f'machine-{n}.json').read_text())['gate']['quiet']
(root/'final-service-status.txt').write_text(status,encoding='utf-8')
with (root.parent/'comparison-vm.lock').open('a') as lease:
    fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
    assert not list(Path('/dev/shm').glob('lython-comparison-files-*'))
    assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[d]otnet.*collector.dll'],capture_output=True).returncode==1
    with tarfile.open(root/'observations.tgz','w:gz') as archive:
        for f in root.iterdir():
            if f.is_file() and f.name!='observations.tgz':archive.add(f,arcname=f.name)
        for name in ('text','ordinary'):archive.add(root/name,arcname=name)
        for name in ('Program.cs','collector.csproj','collector.dll','collector.deps.json','collector.runtimeconfig.json'):
            archive.add(root/'collector'/name,arcname='collector/'+name)
print(hashlib.sha256((root/'observations.tgz').read_bytes()).hexdigest())
