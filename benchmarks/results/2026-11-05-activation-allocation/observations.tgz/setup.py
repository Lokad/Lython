from pathlib import Path
import hashlib,json,shutil
root=Path('/home/lokad/lython-bench-checks/activation-allocation-b261-20261105')
base=Path('/home/lokad/lython-bench-checks/runtime-cpython-b260-20261105/candidate')
for f in base.iterdir():
 if not (root/'collector'/f.name).exists():
  (root/'collector'/f.name).symlink_to(f.resolve(),target_is_directory=f.is_dir())
i=json.loads((root/'identity.json').read_text())
assert hashlib.sha256((base/'Lokad.Lython.dll').read_bytes()).hexdigest()==i['coreSHA256']
assert hashlib.sha256((root/'collector/collector.dll').read_bytes()).hexdigest()==i['collectorSHA256']
for name,sha in i['dependencies'].items():assert hashlib.sha256((root/'collector'/name).read_bytes()).hexdigest()==sha,name
assert shutil.disk_usage(root).free>24*1024*1024
