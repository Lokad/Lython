from pathlib import Path
import itertools
import json
import os
import subprocess

repo=Path.cwd()
lab=repo/".git/agent-notes/review-20261031/trimmed-split-join-r555"
work=repo/".git/agent-worktrees/directive-presence-r547"
sdk=Path.home()/".dotnet11"
env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk),PATH=str(sdk)+os.pathsep+os.environ["PATH"])
source=[]
for i,(delimiter,sep) in enumerate(itertools.product(["\n","§","😀","::"],["","|","א😀"])):
    for lines in [[],["  ","α\u3000","","😀\x1c"],["中\t","b\u0085","   ","🇫🇷\u2029 ",""]]:
        text=delimiter.join(lines)
        # The second spelling enters the ordinary initialized driver after a
        # genuine guest call, while the first can start in the native prefix.
        source.append(
            ("def normalize(value, delimiter, sep):\n"
             " return sep.join(part.rstrip() for part in value.split(delimiter))\n"
             f"print(normalize({text!r}, {delimiter!r}, {sep!r}))") if i % 2 else
            f"text={text!r}\ndelimiter={delimiter!r}\nseparator={sep!r}\nprint(separator.join(part.rstrip() for part in text.split(delimiter)))")
source.extend([
    """events=[]
class Source:
 def split(self, s):
  events.append('split')
  return ['a ', 'b  ']
class Joiner:
 def join(self, g):
  events.append(type(g).__name__)
  return list(g)
print('-'.join(x.rstrip() for x in Source().split('!')))
print(Joiner().join(x.rstrip() for x in 'p !q '.split('!')))
print(events)""",
    """try:
 separator=''
 print('-'.join(x.rstrip() for x in 'abc'.split(separator)))
except ValueError:
 print('empty separator')""",
    """hits=[]
def joiner():
 hits.append('joiner')
 return '|'
def text():
 hits.append('source')
 return 'a  /b  '
def split():
 hits.append('separator')
 return '/'
print(joiner().join(x.rstrip() for x in text().split(split())),hits)""",
])
input_data=json.dumps(source,ensure_ascii=False)
(lab/"probe-input.json").write_text(input_data,encoding="utf-8")
for framework in ["net11.0","net10.0"]:
    image=work/"tools/LythonProbe/bin/Release"/framework
    for mode in ["sync","async"]:
        args=[sdk/"dotnet.exe",image/"LythonProbe.dll","--batch-json","--compare-python","--python","C:/Python313/python.exe"]
        if mode=="async": args.append("--async")
        result=subprocess.run(args,input=input_data,text=True,encoding="utf-8",capture_output=True,env=env,timeout=90)
        (lab/f"probe-{framework}-{mode}.jsonl").write_text(result.stdout,encoding="utf-8")
        rows=[json.loads(line) for line in result.stdout.splitlines()]
        assert len(rows)==len(source)
        failed=[r for r in rows if not r["Matches"] or not r["Lython"]["Success"]]
        assert not failed,(framework,mode,failed[:1])
        assert result.returncode==0,result.stderr
        print(framework,mode,len(rows),"matching CPython probes",flush=True)

