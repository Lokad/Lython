from pathlib import Path
import hashlib,json,subprocess,tarfile
r=Path('.git/agent-notes/review-20261031/cased-preparation-r408');old=Path('.git/agent-notes/review-20261031/activation-r403/final-storage/candidate/Lokad.Lython.dll');print('local withdrawn core exists',old.exists());p=Path('benchmarks/results/2026-11-15-canonical-activation-prototype/sources-images-checks-and-observations.tar.xz')
with tarfile.open(p)as a:
 b=a.extractfile('final-storage/candidate-core.dll').read();proof=dict(canonicalPath=p.as_posix(),member='final-storage/candidate-core.dll',sha256=hashlib.sha256(b).hexdigest(),bytes=len(b),canonicalCommit=subprocess.check_output(['git','log','-1','--format=%H','--',p.as_posix()],text=True).strip());assert b==old.read_bytes()
assert subprocess.check_output(['git','show',proof['canonicalCommit']+':'+p.as_posix()])==p.read_bytes();proof['canonicalArchiveSHA256']=hashlib.sha256(p.read_bytes()).hexdigest();(r/'withdrawn-core-custody.json').write_text(json.dumps(proof,indent=2)+'\n',encoding='utf-8',newline='\n')
script='''from pathlib import Path
import fcntl,hashlib,json,os,shutil,subprocess
base=Path('/home/lokad/lython-bench-checks')
with(base/'comparison-vm.lock').open('a')as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record|[p]ython3.*cpython-worker.py'],capture_output=True).returncode==1
 p=base/'activation-b787-20261115/candidate/Lokad.Lython.dll';rows=[]
 if p.exists():
  m=p.lstat()
  for q in base.glob('*/**/Lokad.Lython.dll'):
   n=q.lstat()
   if(n.st_dev,n.st_ino)==(m.st_dev,m.st_ino):rows.append(dict(path=q.relative_to(base).as_posix(),bytes=n.st_size,links=n.st_nlink,inode=n.st_ino,uid=n.st_uid,sha256=hashlib.sha256(q.read_bytes()).hexdigest()))
 print(json.dumps(dict(freeBytes=shutil.disk_usage(base).free,withdrawnCoreExists=p.exists(),aliases=rows)))
'''
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73'];p=subprocess.run(ssh+['python3 -'],input=script,capture_output=True,text=True,encoding='utf-8',timeout=30);assert p.returncode==0,p.stderr;(r/'retirement-preflight.json').write_text(p.stdout,encoding='utf-8');print(p.stdout)
