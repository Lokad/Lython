from pathlib import Path
import json,subprocess,tarfile
repo=Path.cwd();r=repo/'.git/agent-notes/review-20261031/cased-preparation-r408';r.mkdir()
assert not subprocess.check_output(['git','status','--porcelain'],text=True).strip()
files=['src/Lokad.Lython/Runtime/Text/PyStringOps.Whitespace.cs','src/Lokad.Lython/Runtime/Text/PyStringOps.Helpers.cs','src/Lokad.Lython/Runtime/Text/GovernedByteBuilder.cs','src/Lokad.Lython/Runtime/MemoryGovernor.cs']
with tarfile.open(r/'baseline.tar.xz','w:xz')as t:
 for n in files:t.add(repo/n,arcname=n,recursive=False)
(r/'baseline-revision.txt').write_text(subprocess.check_output(['git','rev-parse','HEAD'],text=True),encoding='utf-8',newline='\n')
p=repo/files[2];s=p.read_text(encoding='utf-8');s=s.replace('internal Memory<byte> GetWriteWindow(int count)\n    {\n        EnsureAdditionalCapacity(count);','internal Memory<byte> GetWriteWindow(int count, LythonRuntime.ExecutionContext? context = null, LythonSourceSpan? span = null)\n    {\n        EnsureAdditionalCapacity(count, context, span);')
s=s.replace('private void EnsureAdditionalCapacity(int additionalBytes)','private void EnsureAdditionalCapacity(int additionalBytes, LythonRuntime.ExecutionContext? context = null, LythonSourceSpan? span = null)')
a=s.index('private void EnsureAdditionalCapacity');before=s[:a];tail=s[a:].replace('Grow(requiredCapacity);','Grow(requiredCapacity, context, span);').replace('private void Grow(int requiredCapacity)','private void Grow(int requiredCapacity, LythonRuntime.ExecutionContext? context, LythonSourceSpan? span)')
tail=tail.replace('"byte buffer allocation is too large.", _allocationSpan','"byte buffer allocation is too large.", span ?? _allocationSpan').replace('_memoryGovernor.Reserve(newCapacity, _allocationSpan);','_memoryGovernor.Reserve(newCapacity, span ?? _allocationSpan);')
old='''            expanded = new byte[newCapacity];
            _buffer.AsSpan(0, _length).CopyTo(expanded);
            _memoryGovernor?.Commit(newCapacity);''';assert old in tail
tail=tail.replace(old,'''            context?.CheckExecution(span ?? _allocationSpan);
            expanded = new byte[newCapacity];
            if (context is null) _buffer.AsSpan(0, _length).CopyTo(expanded);
            else for (var offset = 0; offset < _length;)
            {
                context.CheckExecution(span ?? _allocationSpan);
                var count = Math.Min(4096, _length - offset);
                _buffer.AsSpan(offset, count).CopyTo(expanded.AsSpan(offset, count));
                offset += count;
            }
            _memoryGovernor?.Commit(newCapacity);''')
p.write_text(before+tail,encoding='utf-8',newline='\n')
p=repo/files[1];s=p.read_text(encoding='utf-8');old='''            var mapped = MapCaseRune(rune, selected, source, offset, context, span, out var expansion);
            var count = expansion.IsEmpty ? mapped.Utf8SequenceLength : expansion.Length;
            if (expansion.IsEmpty) mapped.EncodeToUtf8(output[written..]);
            else expansion.CopyTo(output[written..]);
            written = checked(written + count);''';assert old in s
s=s.replace(old,'''            written = checked(written + WriteCaseRune(rune, selected, source, offset,
                output[written..], context, span));''')
needle='    private static void WriteAsciiCase('
helper='''    private static int WriteCaseRune(Rune rune, CaseMapping mapping, ReadOnlySpan<byte> source,
        int offset, Span<byte> output, LythonRuntime.ExecutionContext? context, LythonSourceSpan? span)
    {
        var mapped = MapCaseRune(rune, mapping, source, offset, context, span, out var expansion);
        if (expansion.IsEmpty) return mapped.EncodeToUtf8(output);
        expansion.CopyTo(output);
        return expansion.Length;
    }

''';assert needle in s;s=s.replace(needle,helper+needle,1);p.write_text(s,encoding='utf-8',newline='\n')
p=repo/files[0];s=p.read_text(encoding='utf-8');s=s.replace('ref prepared, context.MemoryGovernor, span, context, mapping);','ref prepared, context.MemoryGovernor, span, context, mapping, prepared.Encoded);',1)
s=s.replace('result.Initialize(value, upper, context, span, count);','result.Initialize(context, span, count);',1)
s=s.replace('''        finally { if (prepared is not null) context.MemoryGovernor.ReturnWordRanges(prepared, count); }
    }

    internal sealed class''','''        finally
        {
            if (prepared is not null)
            {
                // No cursor escaped. Drop failed working bytes before returning
                // the existing metadata loan; never cache a cancelled huge scan.
                try { prepared.Encoded.Release(); }
                finally { context.MemoryGovernor.ReturnWordRanges(prepared, count); }
            }
        }
    }

    internal sealed class''',1)
s=s.replace('''        private PyString? _source;
        private CaseMapping _mapping;''','''        internal GovernedByteBuilder Encoded { get; private set; }''',1)
s=s.replace('checked(128L + 16L * capacity)','checked(192L + 16L * capacity)',1)
s=s.replace('''            Ranges = new (int Start, int End, int Capacity)[capacity];
        }''','''            Ranges = new (int Start, int End, int Capacity)[capacity];
            Encoded = new GovernedByteBuilder(owner);
        }

        internal void AdoptScratchFrom(CasedWhitespaceIteration previous)
            => (Encoded, previous.Encoded) = (previous.Encoded, Encoded);

        internal void ReleaseStorage()
        {
            try { Encoded.Release(); }
            finally { _owner.Release(StorageBytes); }
        }''',1)
s=s.replace('            _source = null;','            Encoded.Clear();',1)
s=s.replace('''        internal void Initialize(PyString source, bool upper,
            LythonRuntime.ExecutionContext context, LythonSourceSpan span,
            int count)
        {
            _source = source;
            _mapping = upper ? CaseMapping.Upper : CaseMapping.Lower;''','''        internal void Initialize(LythonRuntime.ExecutionContext context, LythonSourceSpan span, int count)
        {''',1)
s=s.replace('''var word = CreateSplitFragment(_source!.Utf8Span, range, _mapping,
                _owner, _span, _context);''','''var word = CreateSplitFragment(Encoded.WrittenSpan, range, null,
                _owner, _span, _context);''',1)
s=s.replace('''word.Value = CreateSplitFragment(_source!.Utf8Span, range, _mapping,
                    _owner, _span, _context);''','''word.Value = CreateSplitFragment(Encoded.WrittenSpan, range, null,
                    _owner, _span, _context);''',1)
s=s.replace('''                word.Length = WriteCaseUtf8(_source!.Utf8Span[range.Start..range.End],
                    (Span<byte>)word.Utf8, _mapping, _context!, _span!);''','''                word.Length = range.End - range.Start;
                Encoded.WrittenSpan[range.Start..range.End].CopyTo((Span<byte>)word.Utf8);''',1)
s=s.replace('''        internal readonly int MaximumCaseWidth = casing is null ? 0''','''        internal readonly CaseMapping? Mapping = casing;
        internal readonly int MaximumCaseWidth = casing is null ? 0''',1)
s=s.replace('''LythonSourceSpan? span, LythonRuntime.ExecutionContext? context, CaseMapping? casing)
    {
        var state = new WhitespaceRangeState(maxSplit, casing);
        while (TryReadWhitespaceRange(source, ref state, context, span, out var range))''','''LythonSourceSpan? span, LythonRuntime.ExecutionContext? context, CaseMapping? casing,
        GovernedByteBuilder? encoded = null)
    {
        var state = new WhitespaceRangeState(maxSplit, casing);
        while (TryReadWhitespaceRange(source, ref state, context, span, out var range, encoded))''',1)
s=s.replace('''out (int Start, int End, int Capacity) range)
    {
        var start = -1;''','''out (int Start, int End, int Capacity) range, GovernedByteBuilder? encoded = null)
    {
        var outputStart = encoded?.Length ?? 0;
        var start = -1;''',1)
s=s.replace('''            int width;
            bool whitespace;
            if (source[position] < 0x80)''','''            int width;
            Rune rune = default;
            bool whitespace;
            if (source[position] < 0x80)''',1)
s=s.replace('Rune.DecodeFromUtf8(source[position..], out var rune, out width);','Rune.DecodeFromUtf8(source[position..], out rune, out width);',1)
s=s.replace('''                    range = (start, position, state.MaximumCaseWidth == 0 ? position - start
                        : CheckCaseOutputCapacity(position - start + extraCapacity, span));''','''                    range = encoded is not null ? (outputStart, encoded.Length, encoded.Length - outputStart)
                        : (start, position, state.MaximumCaseWidth == 0 ? position - start
                            : CheckCaseOutputCapacity(position - start + extraCapacity, span));''',1)
# Only private unlimited cased iteration supplies encoded storage; ordinary maxsplit semantics remain unchanged.
needle='''            state.Position += width;
        }
        if (start >= 0)
        {
            range = (start, source.Length, state.MaximumCaseWidth == 0 ? source.Length - start
                : CheckCaseOutputCapacity(source.Length - start + extraCapacity, span));''';assert needle in s
s=s.replace(needle,'''            if (!whitespace && encoded is not null)
            {
                var mapping = state.Mapping!.Value;
                if (source[position] < 0x80)
                {
                    var output = encoded.GetWriteWindow(width, context, span).Span;
                    context?.CheckExecution(span);
                    var previousWasCased = false;
                    WriteAsciiCase(source.Slice(position, width), output, mapping, position, ref previousWasCased);
                    encoded.Advance(width);
                }
                else
                {
                    var output = encoded.GetWriteWindow(state.MaximumCaseWidth, context, span).Span;
                    context?.CheckExecution(span);
                    encoded.Advance(WriteCaseRune(rune, mapping, source, position, output, context, span));
                }
            }
            state.Position += width;
        }
        if (start >= 0)
        {
            range = encoded is not null ? (outputStart, encoded.Length, encoded.Length - outputStart)
                : (start, source.Length, state.MaximumCaseWidth == 0 ? source.Length - start
                    : CheckCaseOutputCapacity(source.Length - start + extraCapacity, span));''',1)
s=s.replace('''            if (previous is not null) governor?.ReturnWordRanges(previous, count);''','''            if (previous is not null)
            {
                // The scanner keeps this same byte builder while range capacity
                // grows; transfer it before the old cursor can reenter the cache.
                replacement?.AdoptScratchFrom(previous);
                governor?.ReturnWordRanges(previous, count);
            }''',1)
assert '_source'not in s[:s.index('internal struct CompactWord')]
p.write_text(s,encoding='utf-8',newline='\n')
p=repo/files[3];s=p.read_text(encoding='utf-8');s=s.replace('Release(cached.StorageBytes);','cached.ReleaseStorage();').replace('else Release(words.StorageBytes);','else words.ReleaseStorage();');p.write_text(s,encoding='utf-8',newline='\n')
print('R408 uncommitted prototype: fused scanner/casing, existing cursor owns reusable final-byte scratch, old deferred source/mapping stage removed.')
