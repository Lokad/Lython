from pathlib import Path
import json,shutil,tarfile
repo=Path.cwd();r=repo/'.git/agent-notes/review-20261031/cased-preparation-r408';out=repo/'benchmarks/results/2026-11-15-fused-cased-preparation/refined';out.mkdir()
for n in ['summary.json','archive-receipt.json','terminal-status.json','observations.tgz']:shutil.copyfile(r/'refined-quiet'/n,out/n)
for n in ['identity.json','allocation-summary.json']:shutil.copyfile(r/'refined'/n,out/n)
with tarfile.open(out/'sources-checks-and-procedures.tar.xz','w:xz')as a:
 for p in r.iterdir():
  if p.is_file():a.add(p,arcname='procedures/'+p.name,recursive=False)
 for p in (r/'refined').iterdir():
  if p.is_file():a.add(p,arcname='refined/'+p.name,recursive=False)
 a.add(r/'refined/candidate/Lokad.Lython.dll',arcname='refined-core.dll',recursive=False)
 for p in (r/'refined-quiet').iterdir():
  if p.is_file()and p.name not in ['payload.tgz','observations.tgz']:a.add(p,arcname='refined-quiet/'+p.name,recursive=False)
 for suite in ['Lokad.Lython.Tests','Lokad.Lython.PublicApi.Tests']:
  for p in (repo/'tests'/suite/'TestResults').glob('r408-refined-*.trx'):a.add(p,arcname='checks/'+suite+'/'+p.name,recursive=False)
(out/'README.md').write_text('''# Cursor-owned cased capacity — changed-source refinement

R408/B795,2026-11-15, **0edc0c1c** versus qualified **43bce13a/9e890d18**.
Restore the general byte builder byte-for-byte. The existing cursor directly owns
its private byte array and admits conservative capacity/replacement overlap only
between lines. Old scratch is not copied; written length stays in scanner state.
A standalone builder object and unrelated growth/call changes disappear. Final
ranges/independent eventual words, eager funding and the single scan/case pass
remain. No new owner, allocator, pool, option or dispatcher. **Not retained yet.**

| Complete workload | Elapsed change | Wider process CPU change |
| --- | ---: | ---: |
| Captured text / warm | +0.75..+5.34% | +0.45..+7.51% |
| Captured text / compile-to-result | −7.91..+0.08% | −8.79..+0.28% |
| Direct text / warm | −7.65..−3.96% | −7.94..−2.55% |
| Fulfillment control / warm | −0.45..+1.05% | −1.96..+0.43% |
| JSON control / warm | −2.95..+0.94% | −4.02..+0.84% |

All process-median pairings stay. Captured warm reference/candidate spreads are
3.57/0.95%; fresh4.72/3.77%; direct1.09/2.88%; fulfillment0.55/0.95%; JSON2.78/1.21%.
Direct text supports a useful complete-script gain, captured warm remains adverse,
fresh/control magnitudes are uncertain. Mixed JSON does not prove that the earlier
adverse source recovered because of a specific method change. Allocation remains
effectively flat (+128B/+0.029%captured text). Several-times-output scratch and
earlier long-line denial remain explicit conservative ownership tradeoffs.

Five jobs finish259.695s with the same12sfull-request text/5scontrol warmup,
five rotated0.5s batches, two processes/source, scripts, inputs, full goldens,
VM/runtime/host and clock boundaries as the [original collection](../README.md).
No original process or failed condition is discarded.196internal/439public per
actual.NET11/10 include the original3×64MiB stress cases, Unicode/context,
retained funding, actual suspension, cancellation, first refusal and cleanup.
The full nonincremental solution build precedes these checks and immutable images.

**Bounded same-bits confirmation selected:** captured warm/fresh and JSON only,
original0ed/9e images, before the retention/debt decision. Do not repeat the stable
direct-text comparison, the entire five-job matrix or unchanged correctness/full
qualification. Useful gains, adverse captured warm and wider-capacity costs must
all inform the decision; a fixed-percent gate does not decide it automatically.
No new CPython, startup, heap/RSS, pending-I/O or tail claim.

All identity/golden/budget/quiet/Closed/exit/join/archive gates pass; no users or
RAM fixtures remain. Only the exact committed archived previous candidate and
working observation duplicates are retired with path/UID/hash/link/lease proof.
Current qualified images, source/evidence and toolchains remain;254/252MiB floors
stay. B795 is terminal cached forever. Full delivery/publication is pending.

[All controls](summary.json),[allocation](allocation-summary.json),[image/source identity](identity.json),
[raw](observations.tgz),[cleanup](archive-receipt.json),
[exact refined core/source/checks/procedures](sources-checks-and-procedures.tar.xz).
''',encoding='utf-8',newline='\n')
source=repo/'.git/agent-notes/review-20261031/regex-producer-050-r409/assessment.json';data=json.loads(source.read_text(encoding='utf-8'));data['dateUTC']='2026-11-15';data['newCoreReleaseGate']=False;data['producerStatusBoundary']='Local committed acceptance atc5e02a27; not an assertion about current NuGet availability';data['dependencyPolicy']='Source assessment is not package safety/semantic/performance qualification; Lython core remains decoupled and introduces no backend types or Unsafe APIs.'
p=repo/'benchmarks/results/2026-11-14-regex-provider-capabilities/source-update-c5e02a27.json';p.write_text(json.dumps(data,indent=2)+'\n',encoding='utf-8',newline='\n')
p=repo/'PLAN.md';s=p.read_text(encoding='utf-8');s=s.replace('**B795same-five-job changed-source comparison live**, observe after17:49:26UTC; keep same unit. No CI live.','B795terminal/archived, all users/fixtures cleaned. Directtext−3.96..−7.65%elapsed; capturedwarm+0.75..+5.34%, fresh/JSON move. One bounded same-bits capturedwarm/fresh+JSON confirmation selected; no live VM/CI job yet.')
s=s.replace('Source/asset assessment is in private\nregex-producer-050-r409/assessment.json until its implementation/evidence milestone.','[Source/asset assessment](benchmarks/results/2026-11-14-regex-provider-capabilities/source-update-c5e02a27.json) records local acceptance atc5, not current NuGet availability. No backend-policy gate is restored to core releases.')
s=s.replace('Next: observe existing owner after guard, verify all controls/users/archive;','''[RefinedB795](benchmarks/results/2026-11-15-fused-cased-preparation/refined/README.md)
   directtext elapsed−3.96..−7.65%/CPU−2.55..−7.94%; capturedwarm remains
   +0.75..+5.34%elapsed/+0.45..+7.51%CPU. Fresh/JSON move. All gates pass,
   no users/fixtures remain. Select one unchanged-binary confirmation of captured
   warm/fresh+JSON to clarify the retention/debt decision; do not repeat stable
   directtext or full five-job/correctness matrices. Then''')
p.write_text(s,encoding='utf-8',newline='\n')
with(repo/'benchmarks/EXPERIMENTS.md').open('a',encoding='utf-8',newline='\n')as f:f.write('''\n\n[R408refinedB795](results/2026-11-15-fused-cased-preparation/refined/README.md)
0ed/9e restores general builder, uses existing cursor's coarse capacity replacement
only between lines.196internal/439public per11/10 including3original64MiB cases
pass. Allocationflat(+128Btext). Same5jobs259.695s/allgates:directtext−3.96..−7.65%
elapsed/CPU−2.55..−7.94%;capturedwarm+0.75..+5.34%/CPU+0.45..+7.51%;fresh/JSONmove.
Keep original4e49adversity. One same-bits capturedwarm/fresh+JSON confirmation
selected before retention; no full/stable-row repetition or causal recovery claim.
[R409source update](results/2026-11-14-regex-provider-capabilities/source-update-c5e02a27.json)
records exact locally qualified0.5candidate hashes atc5e02a27, not publication or
Lython adapter qualification. New effective-flags/range/cursor funding APIs support
independent development; remaining three precise gaps defer affected final checks
only. Core dependency/pin unchanged; no producer-policy gate added to core.
''')
print('Preserved refined0ed source/core/all controls and refreshed precise0.5source/asset status; neither is a final adapter or R408 retention claim.')
