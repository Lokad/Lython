# Lokad.Lython 0.11.0

Updated 2026-11-15 UTC. Git-ignored; never force-add. Publication/tagging postponed.
Objective: coherent simplification and substantial complete-script performance,
including compile-once/run-once work. An isolated experiment is not completion.
Current contracts stay in docs; history/adversity stay in
[EXPERIMENTS](benchmarks/EXPERIMENTS.md) and immutable linked results.

## Actual delivery status

| State | Evidence and limits |
| --- | --- |
| Fully qualified runtime | **43bce13a / measured9e890d18**, [delivery](benchmarks/results/2026-11-15-completed-arithmetic/delivery/README.md). Cached43737584665GREEN: Windows/Ubuntu actual11/10 each4781internal/17865public ordinary,13/406original stress, installed Release consumers.586production inputs match;4build inputs unchanged from qualified6e. Never requery terminal CI or repeat unchanged qualification. |
| Committed | Runtime43bce13a, CPython/recovery evidence2f900d6b/6334c24c, current-loop attribution79388190; later source is R408 prototype. |
| Active uncommitted prototype | **R408** fused scanning/casing, existing cursor owns reusable byte scratch; no performance measurement yet. Corrected66internal/268public each actual11/10 plus3original64MiB stress cases each pass; one-window refinement69internal/268public each actual11/10 (including3original64MiB cases) pass; allocation flat(+152Btext); B7945jobs259.624s complete, original controls preserved, no users/fixtures. Refined cursor-only capacity change passes196internal/439public per actual11/10; allocation flat(+128Btext); changed-source B795 live, no CI live. Three original ownership-fixture failures/source preserved. Changed-source R408/B795 VM comparison live; no CI live. |
| Current external comparisons | [Eight phases](benchmarks/results/2026-11-15-arithmetic-cpython-checkpoint/README.md) at43bce13a/9e89. Invoice warm1.10–1.13×, fresh1.09–1.13×, fulfillment1.11–1.12×; text1.36–1.41×, JSON0.84–0.86×, search1.81–1.93×, configfresh1.05–1.06×. Moving controls/archive-floor recovery explicit; historical rows retain actual revisions. |

## Track A — runtime delivery, then substantial redesigns

**R405 fully qualified** (cached43737584665). [Original source pair](benchmarks/results/2026-11-15-completed-arithmetic/README.md),
[same-bits controls/decision](benchmarks/results/2026-11-15-completed-arithmetic/confirmation/README.md).
One shared completed numeric/bool/text-add/unary/scalar-comparison selection and
operand reader displace duplicate native selectors/reads and the old generic
numeric probe. Existing integer/chain kernels, retirement/publication, dynamic
operators and genuine suspension remain. No new controller, owner or value layout.
B790 invoice elapsed−3.84..−2.29%, CPU−3.30..−2.14%; allocation flat.
B791 longer full-request warmup: text elapsed−1.30..+0.81%, fresh−0.28..+0.33%;
fresh wider CPU remains+0.35..+3.08%. Original adverse/moving observations remain.
Accept this modest uncertainty for shared semantics and stable invoice benefit;
do not claim broad neutrality, isolated causality or substantial-objective completion.
The attempted locals-handle removal was wrong (51public failures); original loan
handle restored, no assertion weakened. Preserve failed conditions.

1. R405 delivery and representative CPython refresh are complete. Keep all original
   controls/archive-floor recovery explicit; no repeated unchanged qualification.
   Continue R408, then the substantial roadmap. Publication remains held.
2. **R406 source gate closed without another replay:** historical bulk CSV work
   is already delivered. Current parser constructs final row/payload once and
   DictReader adopts funded values with shared keys. R379 already addresses long
   fields. Header identity proofs bracket admission for reentry; per-row shells
   and Python strings are observable storage, not removable generic intermediates.
   No changed ownership argument or remaining dominant construction stage justifies
   reintroducing ranges, a new row arena, or threshold-driven B74 replay.
   Existing call buffers/final-slot binding/native integer returns also already
   exist; do not claim another missing argument array or boxed native result.
3. **R407 complete; R408 uncommitted prototype — one-pass cased-word preparation.**
   [Current attribution/source gate](benchmarks/results/2026-11-15-text-loop-interior/README.md):
   993guest leaves/96unknown/0ambiguous;151in exact9912Bloop. Mixed transport,
   metadata/hash/probe groups do not justify another frame/controller/copy tweak.
   Preparation115leaves, case writing33, mapping28 motivate a whole stage removal;
   these include useful work and predict no speedup. No more unchanged capture.

   R408 hypothesis: combine whitespace discovery and Unicode casing into one pass,
   retaining ranges over final UTF8 bytes, eliminating deferred per-word casing,
   original-source/mapping retention and its repeated conversion setup. Use the
   existing funded cursor/range loan and governed byte builder; no new pool/owner,
   cap, value layout or dispatcher. Share the existing Unicode mapping/ASCII kernels,
   not a duplicate casing implementation. Keep ordinary split semantics and paths
   until the shared scanner can preserve them; no extra complete-buffer scan.
   Displaced code: CasedWhitespaceIteration's deferred source/mapping state and
   case-writing MoveNext/TryReadWord; replace with completed-byte copy/materialization.
   Keep ranges: R343's removed-range design added scans and measured8–23%slower
   with flat allocation/stable control. This changed pipeline must remove that work,
   not replay the same version or infer a win from a source simplification.

   Acceptance: all Python whitespace, Unicode expansion/final-sigma/context,
   split boundaries/independent strings/aliases, eager all-word admission before
   loop effects, capacity/replacement overlap, nested/active/late cursor loans,
   reentrant refunds/publication, actual suspension/cancellation/terminal refusal
   and shared-budget reuse. Extra reusable byte scratch/earlier long-line denial
   are explicit tradeoffs, not hidden allowances. Preserve all original stress.
   Focused actual11/10 checks, short complete-job allocation screen, then bounded
   quiet-VM source pair on captured text warm/fresh, ordinary text and unchanged
   fulfillment/JSON controls. All original/adverse data remain; allow justified
   refinement. Completion: old deferred stage gone, no extra byte pass, semantics
   preserved, controlled CPU/allocation/storage decision. Decide remaining debt
   explicitly; withdraw/refine if added scratch/scans outweigh benefit. B794 text warm−3.40..+6.81%(candidate9%spread), freshCPU favorable but moving;
   JSON+2.53..+5.79%elapsed/+2.17..+7.96%CPU. Initial4e49 not retained.
   [Original source/core/all observations](benchmarks/results/2026-11-15-fused-cased-preparation/README.md).
   Refine by restoring the general builder completely: cursor capacity replaces
   only between lines, so direct ordinary coarse preflight removes builder object,
   retained-length state and pointless previous-byte copies. Existing cursor is
   the owner; no allocator layer. No causal JSON claim. Refined0edc0c1c passes196internal/439public per actual11/10 including3original64MiB cases; allocation flat(+128Btext). Same five-job/settings B795 changed-source comparison live; observe only after recorded280s guard and retain the same unit until authoritative terminal state. Decide retention only after its full controls/ownership/cleanup gates. No full qualification yet. Full batch
   only at retained changed-runtime boundary. Publication stays held.
   Initial .NET11 build passes;57/60 focused checks pass. Three ownership fixture
   failures expose new scratch capacity missing from the reported complete loan,
   and old cache capacity being discarded on a failed same-size request. Include
   bytes in the live storage report, release base metadata separately, keep only
   earlier capacity on failure and drop new growth. Capture total loan size before
   disposal in the existing balance assertion; do not relax it or other assertions.
   Original TRX/source stay preserved. Corrected66internal/268public per actual11/10
   plus3original64MiB stress cases each pass. Before timing, replace per-chunk write
   windows with one conservative line-capacity admission; no sizing scan added.
   Bound is source byte length × maximum mapped scalar width (lower4/upper maximum),
   with retained capacity/replacement peaks funded. This can retain several times
   actual output/deny earlier; measure the complete working-set tradeoff. Preserve
   the checked chunked source/core/TRX separately. Refined69internal/268public per actual11/10 pass including3original64MiB stress cases; immutable full images/source frozen, allocation/timing pending.
4. **Next whole call/frame or frontend milestone:** use measured current costs to
   select complete construction/transport or a removable dominant frontend stage.
   Ordered live binding/defaults, closures/identity, fault spans, protected cleanup,
   generators and suspension are required. Existing final slots/direct calls/compiler
   facts/native returns stay. New arenas/controllers that merely move the same state
   repeat R403's demonstrated failure. Name displaced implementation, representative
   scripts, bounded controls and explicit completion/regression-debt decision before
   starting. Temporary setbacks are acceptable within that finite milestone.

R404 [paired attribution](benchmarks/results/2026-11-15-invoice-call-attribution/README.md)
is closed. Qualified binding/workspace/namespace-frame counts0/0/0 do not justify
another frame cache. Native/ordinary dispatch and value operations dominate
resolved samples; inclusive counts overlap useful work. Windows IL/code size is
not Linux CPU causality. No further unchanged capture. R403 common activation and
retirement refinement are withdrawn with all adverse results; no dormant code.

Complete-script gains, compile-once/run-once latency and meaningful simplification
remain the objective. Startup, pending-I/O, contention, heap/RSS and embedding tails
are unmeasured. Never substitute another isolated local optimization for this roadmap.

## Track B — independent regex contract and final adapter qualification

Core is complete: Python/effective flags, native UTF8 subjects/names, byte ranges,
scalar positions/original windows, explicit owners/current tokens across frontend,
runtime/imports. Core has no Utf8Regex runtime edge; fnmatch/glob use their native
cancellable matcher. Cooperating tests cover actual provider interruption and
awaited funded cleanup. Build on completed plumbing/qualification.

Nonpackable normal adapter remains pinned0.4.0. Read-only source now**c5e02a27**:
0.5.0 immutable candidate matches the producer's exact acceptance hashes; producer
records qualified/**not published or adopted**. Its separate uncommitted engine
edits are not consumed. Lython has not qualified that candidate. Old4a/4d source
status is historical, not current. Development can use this exact pinned candidate
without changing normal CI restores to an unavailable public version.

**R409 adapter-local simplification next:** use validated EffectiveOptions instead
of the handwritten inline-flag parser; use byte-range cursor advances in place of
captured-text projections; bridge existing Lython scopes into program/working/result
allowances and dispose program owners explicitly where APIs permit. No core types,
dependency edges or memory infrastructure added. Preserve flags/errors/offsets,
original windows, cancelled-token isolation and retained results. Contract tests,
semantic checks and backend performance remain separate; qualify both frameworks
and a short regex-only source pair before normal adoption.

Precise remaining0.5 source gaps: GetGroupNames still enumerates CLR strings
(UTF8 lookup is not enumeration); cursor construction still retains its token,
while token-free construction cannot cancel preparation; one-match working/result
staging defaults to program allowance rather than separate scratch/escaping owners.
Range-only advances, explicit cursor working allowance, retained-range receipts and
per-advance tokens are present and should be used for development; do not list them
as absent. Only those affected final adapter qualifications wait, never independent
core/runtime/contract implementation. Source/asset assessment is in private
regex-producer-050-r409/assessment.json until its implementation/evidence milestone.

## Completed milestones and retained debt

R403 [canonical activation and changed retirement refinement](benchmarks/results/2026-11-15-canonical-activation-prototype/refinement/README.md)
are completed, withdrawn experiments, not delivered runtime improvements.
77a allocation ends effectively flat after preserving large intermediate regressions.
B787 stable-control elapsed worsens invoice28–33%, fulfillment15–17%, text47–50%,
JSON14–15%, search44–55%. Changed17b/B788 remains invoice25–30%, fulfillment16%,
text32–38%, JSON12–14%, search34–41%, with adverse CPU. Fresh configuration controls
move. Both finite six-job runs finish (~171/172s), preserve all observations and
join/clean up users under the lease. Source consolidation alone is insufficient.
All585production inputs are restored to6e/02340; forced actual11/10 builds and
108internal/72public checks each pass. Keep the independent TypeError-handler case.

R402 [live keyword defaults](benchmarks/results/2026-11-15-live-keyword-defaults/README.md)
is fully qualified at6e276759. It removes pre-admission async protocol snapshots;
actual suspending lookup, cancellation, terminal refusal and joined cleanup are
covered. Its desktop elapsed screen retains adverse+3.21% and5–30% unchanged
drift; no CPU gain is claimed. R402's separate native-only activation stack was
not implemented: duplicating unwind/context construction beside the runner would
add a controller. That does not establish that all consolidation must be slow.

Shared compiler-fact/callback correction61237f58 and native helper returns8f07764a
are fully qualified. Helper returns establish19–20%less allocation; elapsed stays
diagnostic. Direct UTF8 formatting/storage establishes8.67%less allocation and
controlled5–8%report elapsed/CPU support; original adverse15.125ms is unexplained
and preserved. Do not repeat completed qualification.

R379 bulk CSV/final long-field payload: metadata-heavy allocation−5.557%, ordinary
CSV flat, elapsed/CPU mixed. The historical6–8%proposal has been reassessed; do
not automatically promote it again or add separate gains. Shared slotsR373,
private word segmentR376, final-slot bindingR384 and scheduled invocation lifetime
R390 are delivered. [Historical debt/decisions](benchmarks/results/2026-11-15-runtime-roadmap-review/README.md)
remain; R391 shared hashes did not explain elapsed variability.

**R395–R398 tuple milestone delivered:** [final source/controls](benchmarks/results/2026-11-15-tuple-operand-prototype/refined/README.md).
Final integer tuple storage/transport removes eager boxes/object-array transfer.
Invoice allocation−8.56%, elapsed−10.10..−8.55%, CPU−10.81..−6.42%; fulfillment
−5.32%allocation/−5.01..−3.85%elapsed/−4.62..−2.67%CPU. Original1b88 text
regressions remain. Refined text controls move8.90%then5.40%; JSON crosseszero after
one bounded same-bits confirmation. Accept remaining small control uncertainty
for0.11, not neutrality or a causal recovery claim. No more unchanged tuple timing
campaign; materially new defects/evidence remain eligible. Wider capacity/eventual
boxes are admitted up front; private item borrows can retain their source tuple.

Withdrawn tuple-headerR287, call arenas, R378 entry reroute and R382 shared prefix
retain exact code/adverse results; dormant implementations are gone. These designs
actually measured slower or offered insufficient benefit for their complexity.
Materially different designs remain eligible; no automatic replay or permanent ban.

## Evidence policy and lasting constraints

Timeouts, unstable controls and inconclusive samples establish uncertainty. Allow
bounded confirmation/refinement/measurement correction when justified, preserving
every original condition. No blanket one-attempt/no-retiming rule or fixed-percent
veto. Distinguish simplification, allocation reduction and demonstrated CPU gain.

[AGENTS](AGENTS.md) remains binding: fully managed/memory-safe, no unsafe/Unsafe/
pointers/PInvoke/native probing; managed stack admission stays. Tokens govern time,
no fuel/quotas. Borrowed shared allowance funds capacity/overlap, retained aliases,
results/caches/pending users; first refusal terminal, cleanup awaited. No hidden
caps, retries, tracing, weak reclamation, forced GC or abandoned work. Long streams
use bounded host commands. Preserve capabilities, original paths+Cwd, checked
representation bounds, bounded I/O and cycles.

Focused Release during iteration; full platform/originalstress/installed consumers
at meaningful changed-runtime delivery boundaries. Freeze copies/complete hashes;
force rebuilding after timestamp-preserved restores. UTF8 text. VM evidence and
workers persist outside RAM fixtures; archive/verify under lease before teardown,
join users before refunds. Keep current22e5/f304/8fb/7161 images, canonical evidence,
toolchains and 254 / 252 MiB floors; retire only exact proved archived working copies.
Only core is packaged, adapter nonpackable. Cached terminal CI is never requeried.
