from pathlib import Path
import ast,hashlib,io,json,subprocess,tarfile
r=Path('.git/agent-notes/review-20261031/cased-preparation-r408');q=r/'refined-quiet';q.mkdir();old=r/'quiet';remote='/home/lokad/lython-bench-checks/cased-preparation-b795-20261115';unit='lython-b795-refined-cased-preparation-20261115'
f=json.loads((r/'refined/identity.json').read_text(encoding='utf-8'));identity=json.loads((old/'identity.json').read_text(encoding='utf-8'));identity.update(sourceRevision='Refined R408 uncommitted0edc0c1c versus fully qualified43bce13a/frozen9e890d18',purpose='Cursor directly owns replace-between-lines scratch; original general byte builder restored. Same five complete scripts/settings as B794, original adverse data preserved.',coreSHA256={k:f['coreSHA256']['candidate'if k.startswith('candidate')else'reference']for k in ['candidate','candidate-control','reference','reference-control']},candidateSourceIdentitySHA256=hashlib.sha256((r/'refined/identity.json').read_bytes()).hexdigest(),qualification='196internal/439public per actual11/10 including3original64MiB tests; prototype not retained/fully qualified',roleMeaning={k:'Refined R408 uncommitted0edc0c1c'if k.startswith('candidate')else'Fully qualified43bce13a/frozen9e890d18'for k in ['candidate','candidate-control','reference','reference-control']})
(q/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8',newline='\n')
for n in ['collect.py','archive-owned.py','run.sh','additional.json','retrieve.py']:
 s=(old/n).read_text(encoding='utf-8').replace('cased-preparation-b794-20261115','cased-preparation-b795-20261115').replace('lython-b794-cased-preparation-20261115',unit).replace('B794','B795')
 (q/n).write_text(s,encoding='utf-8',newline='\n')
commit=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();retire=[];sha=lambda b:hashlib.sha256(b).hexdigest()
canonical='benchmarks/results/2026-11-15-fused-cased-preparation/sources-checks-and-procedures.tar.xz';raw=subprocess.check_output(['git','show',commit+':'+canonical]);assert raw==Path(canonical).read_bytes()
with tarfile.open(fileobj=io.BytesIO(raw))as t:core=t.extractfile('candidate-core.dll').read()
retire.append(dict(path='cased-preparation-b794-20261115/candidate/Lokad.Lython.dll',bytes=len(core),sha256=sha(core),custody=dict(commit=commit,archive=canonical,member='candidate-core.dll',archiveSHA256=sha(raw))))
canonical='benchmarks/results/2026-11-15-fused-cased-preparation/observations.tgz';raw=subprocess.check_output(['git','show',commit+':'+canonical]);assert raw==Path(canonical).read_bytes()
with tarfile.open(fileobj=io.BytesIO(raw))as t:data=t.extractfile('confirmation/confirmation.json').read()
for path,data,member in [('confirmation/confirmation.json',data,'confirmation/confirmation.json'),('observations.tgz',raw,None)]:retire.append(dict(path='cased-preparation-b794-20261115/'+path,bytes=len(data),sha256=sha(data),custody=dict(commit=commit,archive=canonical,member=member,archiveSHA256=sha(raw))))
canonical='benchmarks/results/2026-11-15-text-loop-interior/observations.tgz';raw=subprocess.check_output(['git','show',commit+':'+canonical]);assert raw==Path(canonical).read_bytes();retire.append(dict(path='text-loop-b793-20261115/observations.tgz',bytes=len(raw),sha256=sha(raw),custody=dict(commit=commit,archive=canonical)))
with tarfile.open(q/'payload.tgz','w:gz')as t:
 for n in ['identity.json','additional.json','collect.py','archive-owned.py','run.sh']:t.add(q/n,arcname=n)
 t.add(r/'refined/candidate/Lokad.Lython.dll',arcname='candidate/Lokad.Lython.dll')
with tarfile.open(q/'payload.tgz')as t:unpacked=sum(m.size for m in t if m.isfile())
config=dict(root=remote,sourceRoot='/home/lokad/lython-bench-checks/arithmetic-b790-20261115',unit=unit,identity=identity,payloadBytes=(q/'payload.tgz').stat().st_size,payloadSHA256=sha((q/'payload.tgz').read_bytes()),unpackedBytes=unpacked,retire=retire)
(q/'config.json').write_text(json.dumps(config,indent=2)+'\n',encoding='utf-8',newline='\n')
s=(r/'launch-quiet.py').read_text(encoding='utf-8').replace("parent/'quiet'","parent/'refined-quiet'").replace('lython-b794-fixtures','lython-b795-fixtures');(r/'launch-refined-quiet.py').write_text(s,encoding='utf-8',newline='\n')
s=(r/'summarize-quiet.py').read_text(encoding='utf-8').replace("/'quiet'","/'refined-quiet'");(r/'summarize-refined-quiet.py').write_text(s,encoding='utf-8',newline='\n')
print(dict(stagedBytes=unpacked,retiredBytes=sum(v['bytes']for v in retire),sameJobsAndSettings=True,refinedCore=f['coreSHA256']['candidate']))
