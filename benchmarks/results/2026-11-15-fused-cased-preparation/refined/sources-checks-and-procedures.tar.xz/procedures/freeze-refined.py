from pathlib import Path
import hashlib,json,shutil,subprocess,tarfile
repo=Path.cwd();r=repo/'.git/agent-notes/review-20261031/cased-preparation-r408';f=r/'refined';f.mkdir()
ref=repo/'.git/agent-notes/review-20261031/arithmetic-r405/frozen/candidate';manifest={}
for role in ['reference','candidate']:
 target=f/role;target.mkdir()
 for p in ref.iterdir():
  if p.is_file():shutil.copyfile(p,target/p.name)
 if role=='candidate':shutil.copyfile(repo/'src/Lokad.Lython/bin/Release/net11.0/Lokad.Lython.dll',target/'Lokad.Lython.dll')
 manifest[role]={p.name:hashlib.sha256(p.read_bytes()).hexdigest()for p in target.iterdir()if p.is_file()}
assert manifest['reference']['Lokad.Lython.dll']=='9e890d187e5ff2af2b335b1e7dfe0cf1edd9de6a55b389bef1df6e469993e7f8'
for n in manifest['reference']:
 if n!='Lokad.Lython.dll':assert manifest['candidate'][n]==manifest['reference'][n],n
shutil.copyfile(ref.parent/'catalog.json',f/'catalog.json');sources={}
with tarfile.open(f/'sources-and-checks.tar.xz','w:xz')as a:
 paths=subprocess.check_output(['git','ls-files','src/Lokad.Lython'],text=True).splitlines()+['Directory.Build.props','Directory.Packages.props','NuGet.Config','global.json','tests/Lokad.Lython.Tests/WordBufferLoanTests.cs']
 for n in paths:
  p=repo/n;sources[n]=hashlib.sha256(p.read_bytes()).hexdigest();a.add(p,arcname=n,recursive=False)
 for suite in ['Lokad.Lython.Tests','Lokad.Lython.PublicApi.Tests']:
  for p in (repo/'tests'/suite/'TestResults').glob('r408-*.trx'):a.add(p,arcname='checks/'+suite+'/'+p.name,recursive=False)
identity=dict(referenceRevision='Fully qualified43bce13a/frozen9e890d18',baseRevision=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),prototype=True,coreSHA256={k:v['Lokad.Lython.dll']for k,v in manifest.items()},files=manifest,sources=sources,semanticState='Refined cursor-only R408 prototype,196internal/439public each actual11/10 including3original64MiB cases; shared builder restored; not retained or fully qualified',storageTradeoff='One conservative source-byte-count times maximum mapped scalar width scratch window; capacity retained by existing loan/cache; independent words preflight before guest effects. Earlier long-line denial possible.')
(f/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8',newline='\n')
s=(repo/'.git/agent-notes/review-20261031/arithmetic-r405/measure-allocation.py').read_text(encoding='utf-8');(r/'measure-refined-allocation.py').write_text(s.replace("/'frozen'","/'refined'"),encoding='utf-8',newline='\n')
print('Copied complete immutable images and full production/build/test snapshots.',identity['coreSHA256'],flush=True)
