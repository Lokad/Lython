from pathlib import Path
import tarfile
r=Path('.git/agent-notes/review-20261031/cased-preparation-r408')
with tarfile.open(r/'baseline.tar.xz')as t:
 n='src/Lokad.Lython/Runtime/Text/GovernedByteBuilder.cs';Path(n).write_bytes(t.extractfile(n).read())
p=Path('src/Lokad.Lython/Runtime/Text/PyStringOps.Whitespace.cs');s=p.read_text(encoding='utf-8')
s=s.replace('prepared.Encoded.CommittedCapacity','prepared.EncodedCapacity').replace('prepared.Encoded.Release()','prepared.ReleaseEncoded()').replace('context, mapping, prepared.Encoded);','context, mapping, prepared);')
s=s.replace('internal GovernedByteBuilder Encoded { get; private set; }','private byte[] _encoded = [];\n        internal int EncodedCapacity => _encoded.Length;')
s=s.replace('checked(192L + 16L * capacity)','checked(128L + 16L * capacity)',1)
s=s.replace('checked(EstimateStorageBytes(Ranges.Length) + Encoded.CommittedCapacity)','checked(EstimateStorageBytes(Ranges.Length) + EncodedStorageBytes(_encoded.Length))',1)
s=s.replace('            Encoded = new GovernedByteBuilder(owner);\n','',1)
s=s.replace('=> (Encoded, previous.Encoded) = (previous.Encoded, Encoded);','=> (_encoded, previous._encoded) = (previous._encoded, _encoded);',1)
s=s.replace('try { Encoded.Release(); }','try { ReleaseEncoded(); }',1)
s=s.replace('            Encoded.Clear();\n','',1)
s=s.replace('Encoded.WrittenSpan','_encoded.AsSpan()')
needle='''        internal void BeginLoan() => _loaned = true;''';assert needle in s
s=s.replace(needle,'''        private static long EncodedStorageBytes(int capacity) => capacity == 0 ? 0 : 32L + capacity;

        internal Span<byte> PrepareEncoded(int capacity, LythonRuntime.ExecutionContext context, LythonSourceSpan? span)
        {
            if (capacity > _encoded.Length)
            {
                // Only a new line can replace scratch. Prior cached bytes have
                // no user; reserve overlap, but never copy them into the new line.
                var bytes = EncodedStorageBytes(capacity);
                using var replacement = _owner.ReserveTemporary(bytes, span);
                context.CheckExecution(span);
                var encoded = new byte[capacity];
                replacement.Commit(bytes);
                var previous = _encoded;
                _encoded = encoded;
                _owner.Release(EncodedStorageBytes(previous.Length));
            }
            return _encoded.AsSpan(0, capacity);
        }

        internal void ReleaseEncoded()
        {
            var previous = _encoded;
            _encoded = [];
            _owner.Release(EncodedStorageBytes(previous.Length));
        }

'''+needle,1)
s=s.replace('        internal int Position;\n','        internal int Position;\n        internal int Written;\n',1)
s=s.replace('GovernedByteBuilder? encoded = null)','CasedWhitespaceIteration? encoded = null)',1)
s=s.replace('''var encodedBytes = encoded is null ? default : encoded.GetWriteWindow(
            CheckCaseOutputCapacity((long)source.Length * state.MaximumCaseWidth, span), context, span).Span;''','''var encodedBytes = encoded is null ? default : encoded.PrepareEncoded(
            CheckCaseOutputCapacity((long)source.Length * state.MaximumCaseWidth, span), context!, span);''',1)
s=s.replace('out var range, encoded, encodedBytes)','out var range, encodedBytes)',1)
s=s.replace('''out (int Start, int End, int Capacity) range, GovernedByteBuilder? encoded = null,
        Span<byte> encodedBytes = default)''','''out (int Start, int End, int Capacity) range, Span<byte> encodedBytes = default)''',1)
s=s.replace('var outputStart = encoded?.Length ?? 0;','var outputStart = state.Written;\n        var writeCased = !encodedBytes.IsEmpty;',1)
s=s.replace('encoded is not null ? (outputStart, encoded.Length, encoded.Length - outputStart)','writeCased ? (outputStart, state.Written, state.Written - outputStart)')
s=s.replace('if (!whitespace && encoded is not null)','if (!whitespace && writeCased)',1)
s=s.replace('encodedBytes.Slice(encoded.Length, width)','encodedBytes.Slice(state.Written, width)',1).replace('encoded.Advance(width);','state.Written += width;',1)
s=s.replace('encodedBytes.Slice(encoded.Length, state.MaximumCaseWidth)','encodedBytes.Slice(state.Written, state.MaximumCaseWidth)',1).replace('encoded.Advance(WriteCaseRune(rune, mapping, source, position, output, context, span));','state.Written += WriteCaseRune(rune, mapping, source, position, output, context, span);',1)
assert 'GovernedByteBuilder'not in s and 'Encoded.'not in s
p.write_text(s,encoding='utf-8',newline='\n')
p=Path('PLAN.md');s=p.read_text(encoding='utf-8');s=s.replace('allocation screen next.','allocation flat(+152Btext); B7945jobs259.624s complete, original controls preserved, no users/fixtures. Refined cursor-only capacity change now checking.')
s=s.replace('Full batch\n   only at retained changed-runtime boundary.', '''B794 text warm−3.40..+6.81%(candidate9%spread), freshCPU favorable but moving;
   JSON+2.53..+5.79%elapsed/+2.17..+7.96%CPU. Initial4e49 not retained.
   [Original source/core/all observations](benchmarks/results/2026-11-15-fused-cased-preparation/README.md).
   Refine by restoring the general builder completely: cursor capacity replaces
   only between lines, so direct ordinary coarse preflight removes builder object,
   retained-length state and pointless previous-byte copies. Existing cursor is
   the owner; no allocator layer. No causal JSON claim. Recheck semantics/allocation
   and one changed-source complete-script comparison before retention. Full batch
   only at retained changed-runtime boundary.''',1)
p.write_text(s,encoding='utf-8',newline='\n')
print('Refined R408: general builder restored exactly, existing cursor directly owns its preflighted replace-between-lines bytes.')
