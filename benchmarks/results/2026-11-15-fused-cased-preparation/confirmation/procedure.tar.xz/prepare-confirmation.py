from pathlib import Path
import ast,hashlib,io,json,subprocess,tarfile
r=Path('.git/agent-notes/review-20261031/cased-preparation-r408');q=r/'confirmation';q.mkdir();prior=r/'refined-quiet';remote='/home/lokad/lython-bench-checks/casing-controls-b796-20261115';unit='lython-b796-casing-controls-20261115';identity=json.loads((prior/'identity.json').read_text(encoding='utf-8'));identity.update(sourceRevision='Same immutable0edc0c1c/9e890d18; R408captured warm/fresh and JSON confirmation',purpose='Clarify moving captured-source and JSON controls before retention/debt decision; no source/data/settings change, original B794/B795 retained.')
(q/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8',newline='\n')
for n in ['collect.py','archive-owned.py','run.sh','retrieve.py']:
 s=(prior/n).read_text(encoding='utf-8').replace('cased-preparation-b795-20261115','casing-controls-b796-20261115').replace('lython-b795-refined-cased-preparation-20261115',unit).replace('B795','B796')
 if n=='collect.py':
  a=s.index('jobs=');b=s.index('\ncases.update',a);s=s[:a]+"jobs=[['scripts.text-summary-helpers.nonlocal-counter.large','warm'],['scripts.text-summary-helpers.nonlocal-counter.large','compile-run'],['scripts.json-summary-helpers.large','warm']]"+s[b:];s=s.replace(' < 290,',' < 180,')
 s=s.replace("len(raw['jobs'])==5","len(raw['jobs'])==3").replace("['jobs']==5","['jobs']==3").replace('jobs=5,','jobs=3,').replace("elapsedSeconds']<360","elapsedSeconds']<240").replace('five-job','three-job')
 if n.endswith('.py'):ast.parse(s)
 (q/n).write_text(s,encoding='utf-8',newline='\n')
with tarfile.open(q/'payload.tgz','w:gz')as a:
 for n in ['identity.json','collect.py','archive-owned.py','run.sh']:a.add(q/n,arcname=n)
head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();canonical='benchmarks/results/2026-11-15-fused-cased-preparation/refined/observations.tgz';raw=subprocess.check_output(['git','show',head+':'+canonical]);assert raw==Path(canonical).read_bytes()
with tarfile.open(fileobj=io.BytesIO(raw))as a:data=a.extractfile('confirmation/confirmation.json').read()
retire=[]
for path,b,member in [('confirmation/confirmation.json',data,'confirmation/confirmation.json'),('observations.tgz',raw,None)]:retire.append(dict(path='cased-preparation-b795-20261115/'+path,bytes=len(b),sha256=hashlib.sha256(b).hexdigest(),custody=dict(commit=head,archive=canonical,member=member,archiveSHA256=hashlib.sha256(raw).hexdigest())))
with tarfile.open(q/'payload.tgz')as a:unpacked=sum(m.size for m in a if m.isfile())
config=dict(root=remote,sourceRoot='/home/lokad/lython-bench-checks/cased-preparation-b795-20261115',unit=unit,identity=identity,retire=retire,payloadBytes=(q/'payload.tgz').stat().st_size,payloadSHA256=hashlib.sha256((q/'payload.tgz').read_bytes()).hexdigest(),unpackedBytes=unpacked)
(q/'config.json').write_text(json.dumps(config,indent=2)+'\n',encoding='utf-8',newline='\n')
s=(r.parent/'arithmetic-r405/launch-confirmation.py').read_text(encoding='utf-8').replace('RuntimeMaxSec=200','RuntimeMaxSec=240').replace('lython-b791-fixtures','lython-b796-fixtures').replace('timedelta(seconds=150)','timedelta(seconds=205)');(r/'launch-confirmation.py').write_text(s,encoding='utf-8',newline='\n')
s=(r/'summarize-refined-quiet.py').read_text(encoding='utf-8').replace("/'refined-quiet'","/'confirmation'").replace("len(raw['jobs'])==5","len(raw['jobs'])==3");(r/'summarize-confirmation.py').write_text(s,encoding='utf-8',newline='\n')
print(dict(retireOnlyArchivedDuplicates=sum(v['bytes']for v in retire),payloadBytes=config['payloadBytes'],sameSource=True,jobs=3))
