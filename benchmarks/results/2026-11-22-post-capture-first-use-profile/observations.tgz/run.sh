set -eu
root=/home/lokad/lython-bench-checks/post-capture-first-use-profile-b1357-20261122
trap 'result=$?; printf "%s\n" "$result" > "$root/exit-code.txt"' EXIT
python3 "$root/collect.py"
