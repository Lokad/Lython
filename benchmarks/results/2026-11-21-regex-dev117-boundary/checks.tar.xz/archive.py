from pathlib import Path
import hashlib, json, shutil, tarfile, zipfile

lab=Path(__file__).resolve().parent
out=Path("benchmarks/results/2026-11-21-regex-dev117-boundary")

def load(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))

def sha(data):
    return hashlib.sha256(data).hexdigest()

manifest=load(lab/"producer-candidate.json")
assert manifest["SourceRevision"].startswith("d657d7e61") and manifest["PackageVersion"]=="0.5.0-dev.117"
replay=load(lab/"producer-lython-replay.json")
assert len(replay["downstream"])==4 and all(row["Passed"]==405 for row in replay["downstream"])
for framework in ("net10.0","net11.0"):
    log=(lab/(framework+".log")).read_text(encoding="utf-8")
    assert "Reversed direct refuses startOffsetInBytes" in log
    assert "Reversed cursor refuses startOffsetInBytes" in log
    assert "Running .NET "+framework[3:] in log
    assert "UTF-8 name, unshifted lookbehind, bounded full match and outer lastIndex pass." in log
    for item in manifest["Packages"]:
        if item["TargetFramework"] != framework or item["Id"] not in ("Lokad.Utf8Regex","Lokad.Utf8Regex.PythonRe"):
            continue
        assembly=lab/"probes"/framework/(item["Id"]+".dll")
        digest=sha(assembly.read_bytes())
        assert digest==item["AssemblySha256"].lower() and digest in log.lower()
assert b"Unsafe.SizeOf<T>" in (lab/"producer-managed-scan.txt").read_bytes()
assert "((2, 2), (2, 2)) 1 2 1" in (lab/"cpython.log").read_text(encoding="utf-8")
out.mkdir(exist_ok=True)
shutil.copyfile(lab/"README.md",out/"README.md")
shutil.copyfile(lab/"producer-candidate.json",out/"producer-candidate.json")
with tarfile.open(out/"checks.tar.xz","w:xz",preset=6) as archive:
    for name in ("verify.py","archive.py","producer-lython-replay.json","producer-managed-scan.txt","cpython-probe.py",
                 "cpython.log","net10.0.log","net11.0.log","build.log","DirectProbe/Program.cs","DirectProbe/DirectProbe.csproj"):
        archive.add(lab/name,arcname=name)
print("Dev.117 package identities, runtime reports and replay receipt verified.")
