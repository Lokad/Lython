from pathlib import Path
import hashlib, json, os, shutil, subprocess, zipfile

lab = Path(__file__).resolve().parent
producer = Path("D:/code/utf8regex")
version = "0.5.0-dev.117"
candidate = producer / "artifacts/package-candidates" / version
accepted = producer / "artifacts/package-acceptance" / version
def load(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))
def sha(data):
    return hashlib.sha256(data).hexdigest()
def emit(path, value):
    path.write_text(json.dumps(value, indent=2) + "\n",encoding="utf-8",newline="\n")

manifest = load(candidate/"candidate.json")
revision = "d657d7e61696643ceeaa6cd1a53aebf7348457d5"
assert manifest["SourceRevision"] == revision and manifest["PackageVersion"] == version
assert manifest["CleanSource"] and manifest["Configuration"]=="Release" and not manifest["Published"]
accepted_manifest = load(accepted/"final-integrity.json")
assert accepted_manifest["source"] == revision and accepted_manifest["version"] == version
intake = load(accepted/"host-inputs.json")["lython"]
assert intake["Commit"].startswith("98b9f87f7") and intake["ExactPackage"] == f"Lokad.Utf8Regex.PythonRe [{version}]"
packages = {}
for item in manifest["Packages"]:
    if item["Id"] not in ("Lokad.Utf8Regex","Lokad.Utf8Regex.PythonRe"): continue
    framework = item["TargetFramework"]
    package = candidate / item["RelativePath"]
    data = package.read_bytes()
    assert sha(data) == item["PackageSha256"].lower()
    assert sha((producer/"artifacts/nuget"/package.name).read_bytes()) == sha(data)
    assembly = item["Id"]+".dll"
    with zipfile.ZipFile(package) as archive:
        payload = archive.read("lib/"+framework+"/"+assembly)
    assert sha(payload) == item["AssemblySha256"].lower()
    out = lab/"probes"/framework
    out.mkdir(parents=True,exist_ok=True)
    (out/assembly).write_bytes(payload)
    packages[item["Id"],framework] = dict(PackageSha256=sha(data),AssemblySha256=sha(payload))
assert len(packages) == 4
downstream = [row for row in accepted_manifest["downstream"] if row["Host"]=="lython"]
assert {(row["Platform"],row["Framework"]) for row in downstream} == {
    (platform,framework) for platform in ("Windows","Linux") for framework in ("net10.0","net11.0")}
for row in downstream:
    assert row["Passed"] == 405
    for package in row["Packages"]:
        if package["Id"] not in ("Lokad.Utf8Regex","Lokad.Utf8Regex.PythonRe"): continue
        assert package["Version"] == version
        assert all(package[key] == value for key,value in packages[package["Id"],row["Framework"]].items())
emit(lab/"producer-lython-replay.json",dict(input=intake,downstream=downstream))
shutil.copyfile(candidate/"candidate.json",lab/"producer-candidate.json")
scan = subprocess.run(["git","-C",producer,"grep","-n","Unsafe.SizeOf<T>",revision,"--",
    "src/Lokad.Utf8Regex/Internal/Construction/Utf8ConstructionBudget.cs"],check=True,capture_output=True)
assert b"Unsafe.SizeOf<T>" in scan.stdout
(lab/"producer-managed-scan.txt").write_bytes(scan.stdout)
template = lab.parent/"regex-dev116-boundary/DirectProbe/DirectProbe.csproj"
shutil.copyfile(template,lab/"DirectProbe/DirectProbe.csproj")
sdk = Path.home()/".dotnet11"
dotnet = sdk/"dotnet.exe"
env = dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk),PATH=str(sdk)+os.pathsep+os.environ["PATH"])
with (lab/"build.log").open("wb") as log:
    subprocess.run([dotnet,"build",lab/"DirectProbe/DirectProbe.csproj","-c","Release"],env=env,check=True,
                   timeout=75,stdout=log,stderr=subprocess.STDOUT)
for framework in ("net10.0","net11.0"):
    run = subprocess.run([dotnet,lab/"DirectProbe/bin/Release"/framework/"DirectProbe.dll"],env=env,
                         check=True,capture_output=True,text=True,encoding="utf-8",timeout=20)
    (lab/(framework+".log")).write_text(run.stdout,encoding="utf-8",newline="\n")
    assert "Running .NET "+framework.removeprefix("net") in run.stdout
    assert all(entry["AssemblySha256"] in run.stdout.lower() for (_,target),entry in packages.items() if target==framework)
    assert "Reversed direct refuses startOffsetInBytes" in run.stdout
    assert "Reversed cursor refuses startOffsetInBytes" in run.stdout
    print(run.stdout,flush=True)
code = """
import re, sys
s='xé!'
m=re.compile(r'(?P<é>(?<=x)(é))').fullmatch(s,1,2)
assert m.regs == ((1,2),(1,2),(1,2)) and m.lastindex == 1
r=re.compile(r'(?P<é>)').match(s,2,1)
assert r.regs == ((2,2),(2,2)) and (r.lastindex,r.pos,r.endpos)==(1,2,1)
print(sys.version)
print(m.regs,m.lastindex,r.regs,r.lastindex,r.pos,r.endpos)
"""
(lab/"cpython-probe.py").write_text(code,encoding="utf-8",newline="\n")
raw = subprocess.run(["C:/Python313/python.exe","-I","-X","utf8",lab/"cpython-probe.py"],
                     check=True,capture_output=True,text=True,encoding="utf-8",timeout=12)
(lab/"cpython.log").write_text(raw.stdout,encoding="utf-8",newline="\n")
print(raw.stdout)
