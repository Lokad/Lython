from pathlib import Path
import gzip
import hashlib
import json
import os
import shutil
import subprocess
import tarfile

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
prior = lab.parent / "packed-annotations-in-creation"
donor = prior / "quiet"
out = lab / "quiet"
out.mkdir()

def load(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))

def sha_bytes(data):
    return hashlib.sha256(data).hexdigest()

def sha(path):
    return sha_bytes(path.read_bytes())

def emit(path, source):
    if path.suffix == ".py":
        compile(source, str(path), "exec")
    path.write_text(source, encoding="utf-8", newline="\n")

def save(path, value):
    emit(path, json.dumps(value, indent=2) + "\n")

def tracked(path):
    return subprocess.check_output(["git", "show", "origin/master:" + path], cwd=repo)

def recoverable(artifact, paths, links, expected_sha, archives):
    base = "benchmarks/results/"
    binary = gzip.decompress(tracked(base + artifact))
    assert sha_bytes(binary) == expected_sha
    checked = {}
    for remote, (published, digest) in archives.items():
        assert sha_bytes(tracked(base + published)) == digest
        checked[remote + "/observations.tgz"] = digest
    return dict(paths=paths, links=links, bytes=len(binary), sha256=expected_sha, archives=checked, optional=False)

history = "2026-11-21-native-callback-entry/"
retire = [recoverable(
    history + "measured-candidate-core.dll.gz",
    [f"{name}/candidate/Lokad.Lython.dll" for name in ("native-callback-entry-b1256-20261121-space-audited",
         "native-callback-entry-confirm-b1257-20261121", "native-callback-text-cpython-b1258-20261121")],
    3, "f33be6fcc3b776a96787f67b4b121fe9c1a2a2de608685c0c75d3eed4d282d9d",
    {
      "native-callback-entry-b1256-20261121-space-audited": (history + "observations.tgz", "a37689a15df875a62ce7c1e67c72b9b42304411123dd5c35b8b1f9d74f42d731"),
      "native-callback-entry-confirm-b1257-20261121": (history + "confirmation/observations.tgz", "b751a1a5f1da62b2a0dc16416e93e04aa71c10e502b949c21d3526da18fda4fe"),
      "native-callback-text-cpython-b1258-20261121": ("2026-11-21-cpython-callback-text/observations.tgz", "a60e934f0c2d146aff9a99165a714bf002899cab3fca5bbc9031c8f4185ebd0f")
    }
)]
history = "2026-11-21-annotations-in-creation/"
retire.append(recoverable(
    history + "candidate-core.dll.gz",
    [f"{name}/candidate/Lokad.Lython.dll" for name in ("annotations-in-creation-b1291-20261121",
         "annotations-in-creation-confirm-b1292-20261121")],
    2, "53cdf0d831d315ffc0da0f329edd430ebae904d0987f4264b0b0787ab123233d",
    {
      "annotations-in-creation-b1291-20261121": (history + "observations.tgz", "c8cc5c2cb2e4b4cdef13b92c421d6971089fce0f9adb6d6cc974af9e0c5b81ae"),
      "annotations-in-creation-confirm-b1292-20261121": (history + "confirmation/observations.tgz", "3221ffc921a4a453faca1934a32ec22042f4522b0983e5394a4526ce982558b4")
    }
))
prior_config = load(donor / "config.json")
prior_receipt = load(donor / "archive-receipt.json")
prior_identity = load(donor / "identity.json")
reference_donor = prior_identity["imageFiles"]["reference"]
assert prior_receipt["complete"] and prior_receipt["archivedAndVerifiedUnderLease"]
assert len(reference_donor) == 32 and reference_donor == {p.name:sha(p) for p in (prior / "quiet-workers/reference").iterdir()}

manifest = out / "representative.json"
catalog = load(lab / "representative.json")
cases = ["scripts.fully-supplied-methods", "scripts.csv-invoice.method-policy", "scripts.ordinary-fully-supplied-helper"]
catalog["cases"] = [case for id in cases for case in catalog["cases"] if case["id"] == id]
assert [c["id"] for c in catalog["cases"]] == cases
save(manifest, catalog)
local = load(lab / "identity.json")
reference, candidate = (subprocess.check_output(["git", "rev-parse", local[key]], cwd=repo, text=True).strip()
                       for key in ("reference", "candidate"))
assert reference.startswith("8ff3a3371") and candidate.startswith("ec3e76b89")
image_files = local["imageFiles"]
core = "Lokad.Lython.dll"
for role, hashes in image_files.items():
    image = lab / "frozen" / role
    assert len(hashes) == 32 and {name: sha(image / name) for name in hashes} == hashes
    assert all(reference_donor[name] == value for name, value in hashes.items() if name != core)
    for suite, count in (("white", 269), ("public", 1557)):
        log = (lab / f"{suite}-win.log").read_text(encoding="utf-8-sig")
        assert "Passed!" in log and f"Passed: {count:5d}, Skipped:" in log
    sdk = Path.home() / ".dotnet11"
    dotnet = sdk / "dotnet.exe"
    env = dict(os.environ, DOTNET_ROOT=str(sdk), DOTNET_ROOT_X64=str(sdk), PATH=str(sdk) + os.pathsep + os.environ["PATH"])
    receipt = lab / f"quiet-{role}-verify.json"
    protocol = repo / "benchmarks/cpython-worker.py"
    assert sha(protocol) == prior_config["protocolSHA256"]
    subprocess.run([dotnet, image / "Lokad.Lython.Benchmarks.dll", "--compare", "verify",
        "--catalog", manifest, "--dotnet", dotnet, "--python", "C:/Python313/python.exe",
        "--python-worker", protocol, "--out", receipt], check=True, env=env, timeout=95)
    proof = load(receipt)
    assert proof["state"] == "Completed" and proof["caseCount"] == 3 and proof["catalogSha256"] == sha(manifest)

identity = dict(sourceRevision=reference + " versus " + candidate, purpose="Direct positional receiver and operand fill",
                imageFiles=image_files, normalAdapterPin="0.4.0", catalogSHA256=sha(manifest),
                coreSHA256={role + suffix: hashes[core] for role, hashes in image_files.items() for suffix in ("", "-control")})
save(out / "identity.json", identity)
root = "/home/lokad/lython-bench-checks/direct-positional-methods-b1294-20261121"
unit = "lython-b1294-direct-positional-methods-20261121"
jobs = [(case, "warm") for case in cases]
for name in ("collect.py", "archive-owned.py", "run.sh", "retrieve.py"):
    original = (donor / name).read_text(encoding="utf-8").replace(prior_config["root"], root).replace(prior_config["unit"], unit)
    if name == "collect.py":
        start, end = original.index("\njobs = "), original.index("\nassert len(jobs)")
        original = (original[:start] + "\njobs = " + repr(jobs) + original[end:]).replace("len(jobs)==5", "len(jobs)==3")
    if name == "archive-owned.py":
        original = original.replace("len(raw['jobs'])==5", "len(raw['jobs'])==3").replace("jobs=5,", "jobs=3,")
    if name == "retrieve.py":
        original = original.replace("['jobs']==5", "['jobs']==3")
    emit(out / name, original)
assert b"\r" not in (out / "run.sh").read_bytes()
for role in image_files:
    (out / role).mkdir()
    shutil.copyfile(lab / "frozen" / role / core, out / role / core)
    assert sha(out / role / core) == image_files[role][core]
parts = ("identity.json", "collect.py", "archive-owned.py", "run.sh", "representative.json",
         "reference/" + core, "candidate/" + core)
payload = out / "payload.tgz"
with tarfile.open(payload, "w:gz") as file:
    for name in parts:
        file.add(out / name, arcname=name)
stage = dict(root=root, unit=unit, identity=identity, source=prior_config["root"], sourceRole="reference",
             sourceFiles=reference_donor, sourceCatalogSHA256=prior_config["catalogSHA256"],
             donorArchiveSHA256=prior_receipt["archiveSHA256"], protocolSource=prior_config["root"] + "/cpython-worker.py",
             protocolSHA256=prior_config["protocolSHA256"], payloadBytes=payload.stat().st_size,
             payloadSHA256=sha(payload), retireGroups=retire, catalogSHA256=sha(manifest),
             unpackedBytes=sum((out / name).stat().st_size for name in parts))
save(out / "config.json", stage)
source = (donor / "remote-launch.py").read_text(encoding="utf-8")
start, end = source.index("\nc=") + 1, source.index("\nb=Path(")
source = source[:start] + "c=" + repr(stage) + source[end:]
source = source.replace("lython-b1291-fixtures", "lython-b1294-fixtures")
assert "c['unpackedBytes']+3*512*1024" in source
source = source.replace("c['unpackedBytes']+3*512*1024", "c['unpackedBytes']+640*1024")
emit(out / "remote-launch.py", source)
emit(lab / "launch.py", (prior / "launch.py").read_text(encoding="utf-8")
     .replace("Annotations in callable creation comparison", "Fully supplied positional methods comparison").replace("355", "225"))
emit(lab / "summarize.py", (prior / "summarize.py").read_text(encoding="utf-8").replace("len(raw['jobs'])==5", "len(raw['jobs'])==3"))
print(f"Prepared three lanes with {stage['unpackedBytes']} bytes of persistent working data.")
