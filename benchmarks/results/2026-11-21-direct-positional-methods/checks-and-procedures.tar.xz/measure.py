from pathlib import Path
import hashlib
import json
import os
import shutil
import statistics
import subprocess

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
baseline = "8ff3a3371"
candidate = "ec3e76b89"
worktree = repo / ".git/agent-worktrees/direct-positional-methods-20261121"
donor = lab.parent / "packed-annotations-in-creation"
prior = lab.parent / "direct-regex-group-copy"
source_owner = lab.parent / "observed-regex-coordinates/frozen/reference"
dotnet = Path.home() / ".dotnet11/dotnet.exe"
python = Path("C:/Python313/python.exe")
protocol = repo / "benchmarks/cpython-worker.py"
env = dict(os.environ, DOTNET_ROOT=str(dotnet.parent), DOTNET_ROOT_X64=str(dotnet.parent),
           PATH=str(dotnet.parent) + os.pathsep + os.environ["PATH"])

def sha(data):
    return hashlib.sha256(data).hexdigest()

def load(p):
    return json.loads(p.read_text(encoding="utf-8-sig"))

def save(p, value):
    p.write_text(json.dumps(value, indent=2) + "\n", encoding="utf-8", newline="\n")

assert subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=worktree, text=True).startswith(candidate)
assert not subprocess.check_output(["git", "status", "--porcelain"], cwd=worktree)
catalog = load(lab / "all-shape-cases.json")
by_id = {row["id"]: row for row in catalog["cases"]}
ordinary = by_id["scripts.ordinary-fully-supplied-helper"]
invoice = by_id["scripts.csv-invoice.large"]
exact_method = """class Policy:
    def evaluate(self, record, base, weight, /):
        return (record + base) * weight

policy = Policy()
evaluate = policy.evaluate

total = 0
for index in range(2048):
    base = index % 11
    weight = index % 7 + 1
    if index % 2 == 0:
        total += policy.evaluate(index, base, weight)
    else:
        total += evaluate(index, base, weight)
print(total)
"""
changed_invoice = invoice["source"].replace(
    "def rounded_basis_points(amount, rate):\n    return (amount * rate + 5000) // 10000",
    "class TaxPolicy:\n    def rounded_basis_points(self, amount, rate, /):\n"
    "        return (amount * rate + 5000) // 10000\n\n\npolicy = TaxPolicy()")
changed_invoice = changed_invoice.replace(" = rounded_basis_points(", " = policy.rounded_basis_points(")
assert changed_invoice != invoice["source"] and changed_invoice.count("policy.rounded_basis_points(") == 2

def variant(base, case_id, src):
    metadata = dict(base, id=case_id, source=src, sourceSha256=sha(src.encode("utf-8")))
    if "sourceUtf8Bytes" in metadata: metadata["sourceUtf8Bytes"] = len(src.encode("utf-8"))
    return metadata

catalog["cases"] = [
    variant(ordinary, "scripts.fully-supplied-methods", exact_method),
    variant(invoice, "scripts.csv-invoice.method-policy", changed_invoice),
    ordinary,
    invoice,
]
manifest = lab / "representative.json"
save(manifest, catalog)

identity = load(donor / "quiet/identity.json")["imageFiles"]["reference"]
reference = donor / "quiet-workers/reference"
assert len(identity) == 32 and {name: sha((reference / name).read_bytes()) for name in identity} == identity
images = {}
core = "Lokad.Lython.dll"
for role, root in (("reference", repo), ("candidate", worktree)):
    image = lab / "frozen" / role
    image.mkdir(parents=True, exist_ok=True)
    for name in identity:
        origin = reference / name
        if name == core:
            origin = (lab.parent / "regex-shared-group-utf8/frozen/candidate" / name if role == "reference"
                      else root / "src/Lokad.Lython/bin/Release/net11.0" / name)
        shutil.copyfile(origin, image / name)
    images[role] = {name: sha((image / name).read_bytes()) for name in identity}
    for path in source_owner.glob("ValidatedAllocation.*"):
        shutil.copyfile(path, image / path.name)
    receipt = lab / f"{role}-verify.json"
    subprocess.run([dotnet, image / "Lokad.Lython.Benchmarks.dll", "--compare", "verify", "--catalog", manifest,
         "--dotnet", dotnet, "--python", python, "--python-worker", protocol, "--out", receipt],
         env=env, check=True, timeout=90)
    proof = load(receipt)
    assert proof["state"] == "Completed" and proof["caseCount"] == 4 and proof["catalogSha256"] == sha(manifest.read_bytes())
    subprocess.run([dotnet, image / "ValidatedAllocation.dll", image, manifest, lab / f"{role}-allocation.json"],
                   env=env, check=True, timeout=90)
    assert {name: sha((image / name).read_bytes()) for name in identity} == images[role]
assert [name for name in identity if images["reference"][name] != images["candidate"][name]] == [core]
save(lab / "identity.json", dict(reference=baseline, candidate=candidate,
     catalogSHA256=sha(manifest.read_bytes()), imageFiles=images))
before, after = [load(lab / f"{role}-allocation.json")["rows"] for role in ("reference", "candidate")]
result = []
for left, right in zip(before, after, strict=True):
    assert left["id"] == right["id"] and left["sharedBudgetBaselineRestored"] and right["sharedBudgetBaselineRestored"]
    start, end = [statistics.median(row["allocatedBytesPerInvocation"]) for row in (left, right)]
    result.append(dict(case=left["id"], reference=start, candidate=end, allocationChangePercent=100*(end/start-1),
                       referenceAccountedPeak=left["peakExecutionMemoryBytes"], candidateAccountedPeak=right["peakExecutionMemoryBytes"],
                       allowanceRestored=True))
    print(result[-1])
save(lab / "allocation-summary.json", result)
