from pathlib import Path
import hashlib, json, os, shutil, statistics, subprocess

lab=Path(__file__).resolve().parent
repo=Path.cwd()
previous=lab.parent/'prepared-compiler-bindings-r627'
qual=lab.parent/'prepared-definition-text-r611'
old_selector=lab.parent/'native-format-selectors-r615'
trial=repo/'.git/agent-worktrees/detached-nonlocal-cells-r629'
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda b:hashlib.sha256(b).hexdigest()
write=lambda p,d:p.write_text(json.dumps(d,indent=2,ensure_ascii=False)+'\n',encoding='utf-8',newline='\n')
git=lambda *args:subprocess.check_output(['git',*args])
ref=git('rev-parse','d4b2088d4').decode().strip()
can=git('-C',str(trial),'rev-parse','HEAD').decode().strip()
manifest=load(previous/'frozen-identity.json')
assert not git('diff','--name-only',manifest['candidateCommit'],ref,'--','src','tests')
assert not git('-C',str(trial),'status','--porcelain')
assert not git('diff','--name-only',ref,can,'--','benchmarks','src/Lokad.Lython.Utf8Regex')
(lab/'measured-source.patch').write_bytes(git('diff','--binary',ref,can,'--','src','tests'))
catalog_path=lab/'catalog.json'
catalog=load(previous/'catalog.json')
python=Path('C:/Python313/python.exe')
variants=('scripts.mutable-rule-counters','scripts.captured-rule-closures','scripts.rule-default-closures',
          'scripts.annotated-rule-closures','scripts.report-forwarding.expanded')
catalog['cases']=[c for c in catalog['cases'] if c['id'] in variants]
old=load(lab.parent/'prepared-capture-slots-r624/catalog.json')
catalog['cases'].append(next(c for c in old['cases'] if c['id']=='calls.positional.large'))
retained=catalog['cases'][0].copy()
fixture=trial/'tests/Lokad.Lython.PublicApi.Tests/ClosureRetentionAccountingScenarioTests.cs'
doc=fixture.read_text(encoding='utf-8-sig')
section=doc.split('Task RetainedNonlocalSiblingsShareTheirCellWithinTheBorrowedAllowance',1)[1]
from textwrap import dedent
literal = chr(34) * 3
source = dedent(section.split('Compile(' + literal, 1)[1].split(literal + ');', 1)[0]).strip()+'\n'
source=source.replace('return [previous, unbound, assign(previous) is previous, functions[0][0](0)]',
    'print(previous, unbound, assign(previous) is previous, functions[0][0](0))')
retained.update(id='scripts.retained-nonlocal-factories', source=source, size=240, fixtureJson='{"size":240,"text":null}')
retained['expectedOutput']=subprocess.check_output([python,'-I','-S','-X','utf8','-c',source]).decode().replace('\r\n','\n')
for field in ('source','expectedOutput','fixtureJson'):
    content=retained[field].encode('utf-8')
    if field!='fixtureJson':retained[field+'Utf8Bytes']=len(content)
    retained[('fixture' if field=='fixtureJson' else field)+'Sha256']=sha(content)
catalog['cases'].append(retained)
assert len(catalog['cases'])==7
write(catalog_path,catalog)
sdk=Path.home()/'.dotnet11'
dotnet=sdk/'dotnet.exe'
env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk),PATH=str(sdk)+os.pathsep+os.environ['PATH'])
source=previous/'frozen/candidate'
files=manifest['images']['candidate']
core='Lokad.Lython.dll'
assert len(files)==32 and {name:sha((source/name).read_bytes()) for name in files}==files
images={}
for role in ('reference','candidate'):
    image=lab/'frozen'/role
    image.mkdir(parents=True,exist_ok=True)
    expected=files.copy()
    for name in files:
        origin=source/name
        if role=='candidate' and name==core:
            origin=trial/'src/Lokad.Lython/bin/Release/net11.0'/name
            expected[name]=sha(origin.read_bytes())
        if not (image/name).exists():shutil.copyfile(origin,image/name)
    for extra in (old_selector/'frozen/candidate').glob('ValidatedAllocation.*'):
        if not (image/extra.name).exists():shutil.copyfile(extra,image/extra.name)
    if role=='candidate':assert expected[core]!=files[core]
    assert {name:sha((image/name).read_bytes()) for name in files}==expected
    with (lab/(role+'-verify.log')).open('wb') as log:
        subprocess.run([dotnet,image/'Lokad.Lython.Benchmarks.dll','--compare','verify','--catalog',catalog_path,
            '--dotnet',dotnet,'--python',python,'--python-worker',repo/'benchmarks/cpython-worker.py',
            '--out',lab/(role+'-verify.json')],env=env,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=120)
    verified=load(lab/(role+'-verify.json'))
    assert verified['state']=='Completed' and verified['catalogSha256']==sha(catalog_path.read_bytes())
    with (lab/(role+'-allocation.log')).open('wb') as log:
        subprocess.run([dotnet,image/'ValidatedAllocation.dll',image,catalog_path,lab/(role+'-allocation.json')],
            env=env,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=120)
    assert {name:sha((image/name).read_bytes()) for name in files}==expected
    images[role]=expected
write(lab/'frozen-identity.json',dict(referenceCommit=ref,candidateCommit=can,casesSHA256=sha(catalog_path.read_bytes()),images=images))
for left,right in zip(*[load(lab/(role+'-allocation.json'))['rows'] for role in ('reference','candidate')],strict=True):
    assert left['id']==right['id'] and left['sharedBudgetBaselineRestored'] and right['sharedBudgetBaselineRestored']
    a,b=[statistics.median(r['allocatedBytesPerInvocation']) for r in (left,right)]
    print(left['id'],f'{a:,} to {b:,}',f'{100*(b/a-1):+.2f}%',left['peakExecutionMemoryBytes'],right['peakExecutionMemoryBytes'],flush=True)
print('Both complete images and all seven cases verified against CPython.')
