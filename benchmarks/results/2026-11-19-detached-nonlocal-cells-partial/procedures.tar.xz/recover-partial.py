from pathlib import Path
import hashlib,json,subprocess
lab=Path('.git/agent-notes/review-20261031/detached-nonlocal-cells-r629')
q=lab/'quiet'
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
config=load(q/'config.json')
original=load(next(q.glob('observation-*.json')))
assert original['exitCode']=='1' and not original['live'] and original['remainingTrace'] and not original['remainingWorkers']
assert "actualFilesSha256" in original['journal']
remote=r'''
from pathlib import Path
import fcntl,hashlib,json,os,subprocess,tarfile
config=CONFIG
root=Path(config['root'])
assert root.resolve()==root and root.name=='detached-nonlocal-cells-b1060-20261119'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
with(root.parent/'comparison-vm.lock').open('a') as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 service=subprocess.check_output(['systemctl','show',config['unit']+'.service','--property=MainPID,Result,ExecMainStatus'],text=True)
 assert 'MainPID=0' in service and 'ExecMainStatus=1' in service
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record|[p]ython3.13.*cpython-worker.py'],capture_output=True).returncode==1
 for role,files in config['identity']['imageFiles'].items():
  assert {name:sha(root/role/name)for name in files}==files
 raw_path=root/'confirmation/confirmation.json'
 raw=json.loads(raw_path.read_text())
 assert not raw['complete'] and len(raw['jobs'])==2 and all(j['case']=='scripts.mutable-rule-counters'and j['workersJoinedAndFixturesRemoved']and len(j['samples'])==20 for j in raw['jobs'])
 assert sha(root/'representative.json')==config['catalogSHA256']
 fixture=root/'guest-fixtures'
 assert fixture.resolve()==fixture and fixture.is_mount()
 sources={p.relative_to(root).as_posix():p for category in ('confirmation','guest-fixtures') for p in (root/category).rglob('*') if p.is_file()}
 for name in ('identity.json','representative.json','collect.py','archive-owned.py','run.sh','exit-code.txt','retirement-receipt.json'):
  sources[name]=root/name
 for p in sources.values(): assert p.resolve()==p and p.stat().st_uid==os.getuid()
 path=root/'partial-observations.tgz'
 assert not path.exists()
 with tarfile.open(path,'w:gz') as tar:
  for name,p in sources.items():tar.add(p,arcname=name)
 with tarfile.open(path) as tar:
  for name,p in sources.items():assert tar.extractfile(name).read()==p.read_bytes()
 subprocess.run(['sudo','-n','umount',str(fixture)],check=True);fixture.rmdir()
 proof=dict(originalExitCode=1,complete=False,timedJobs=2,batches=40,allWorkersJoined=True,guestFixturesRemoved=True,
            archiveSHA256=sha(path),archiveVerifiedUnderIdleLease=True,reason='Unrelated expectedFilesSha256 on stdout-only retained case')
 (root/'partial-recovery.json').write_text(json.dumps(proof,indent=2)+'\n')
 print(json.dumps(proof))
'''.replace('CONFIG',repr(config))
key=str(Path.home()/'.ssh/id_lython-bench.pem')
opts=['-i',key,'-o','BatchMode=yes','-o','ConnectTimeout=15']
reply=subprocess.run(['C:/Windows/System32/OpenSSH/ssh.exe',*opts,'lokad@20.166.121.73','python3 -'],input=remote,text=True,encoding='utf-8',capture_output=True,timeout=45)
assert reply.returncode==0,reply.stderr
receipt=json.loads(reply.stdout)
for name in ('partial-observations.tgz','partial-recovery.json'):
 subprocess.run(['C:/Windows/System32/OpenSSH/scp.exe',*opts,'lokad@20.166.121.73:'+config['root']+'/'+name,str(q/name)],check=True,timeout=40)
assert receipt==load(q/'partial-recovery.json')
assert hashlib.sha256((q/'partial-observations.tgz').read_bytes()).hexdigest()==receipt['archiveSHA256']
print(json.dumps(receipt))
