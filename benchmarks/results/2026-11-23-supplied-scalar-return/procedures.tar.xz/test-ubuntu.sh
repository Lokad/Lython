set -e
export DOTNET_ROOT=/home/vermorel/.dotnet
export DOTNET_ROOT_X64=$DOTNET_ROOT
export DOTNET_NOLOGO=1
lab=/mnt/d/code/Lython/.git/agent-notes/review-20261031/supplied-scalar-return-20261123
public='FullyQualifiedName~NativeIntegerChain|FullyQualifiedName~OrdinalFunctionTransport|FullyQualifiedName~FunctionDefaultMetadata|FullyQualifiedName~NativeTuple|FullyQualifiedName~StackSafety|FullyQualifiedName~MemoryAdmission|FullyQualifiedName~Cancellation'
white='FullyQualifiedName~Executable|FullyQualifiedName~FunctionBinding|FullyQualifiedName~MemoryGovernor'
$DOTNET_ROOT/dotnet test tests/Lokad.Lython.PublicApi.Tests/Lokad.Lython.PublicApi.Tests.csproj -c Release -f net10.0 --artifacts-path $lab/ubuntu --filter "$public" > "$lab/ubuntu-public.log" 2>&1 || { tail -28 "$lab/ubuntu-public.log"; exit 1; }
tail -15 "$lab/ubuntu-public.log"
$DOTNET_ROOT/dotnet test tests/Lokad.Lython.Tests/Lokad.Lython.Tests.csproj -c Release -f net10.0 --artifacts-path $lab/ubuntu --filter "$white" > "$lab/ubuntu-white.log" 2>&1 || { tail -28 "$lab/ubuntu-white.log"; exit 1; }
tail -15 "$lab/ubuntu-white.log"
