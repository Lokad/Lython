from pathlib import Path
import json
import os
import re
import subprocess

lab = Path(__file__).resolve().parent
dotnet = Path.home() / ".dotnet11/dotnet.exe"
env = dict(os.environ, DOTNET_ROOT=str(dotnet.parent), DOTNET_ROOT_X64=str(dotnet.parent),
           DOTNET_TieredCompilation="0", DOTNET_JitDisasm="StartNativeCall TryStartSuppliedIntegerReturn")
source = lab / "comparison/representative.json"
catalog = json.loads(source.read_text(encoding="utf-8"))
catalog['cases'] = [item for item in catalog['cases'] if item['id'] == 'scripts.ordinary-fully-supplied-helper']
assert len(catalog['cases']) == 1
case = lab / "supplied-only.json"
case.write_text(json.dumps(catalog, indent=2) + "\n", encoding="utf-8", newline="\n")
summary = {}
for role in ("reference", "candidate"):
    image = lab / role
    asm = lab / (role + "-entry.asm")
    assert not asm.exists()
    result = lab / (role + "-jit-allocation.json")
    subprocess.run([dotnet, image / "ValidatedAllocation.dll", image, case, result], env=dict(
        env, DOTNET_JitStdOutFile=str(asm)), check=True, timeout=45)
    assert all(row['sharedBudgetBaselineRestored'] for row in json.loads(result.read_text(encoding='utf-8'))['rows'])
    listing = asm.read_text(encoding='utf-8-sig')
    summary[role] = re.findall(r'^; Assembly listing for method ([^(:]+(?::[^(:]+)+)\(', listing, re.M)
    assert summary[role], listing[:800]
(lab / 'jit-entry-summary.json').write_text(json.dumps(summary, indent=2) + '\n', encoding='utf-8', newline='\n')
print(json.dumps(summary, indent=2))
