from pathlib import Path
import gzip
import hashlib
import json
import shutil
import subprocess
import tarfile

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
quiet = lab / "comparison/quiet"
repeat = lab / "confirmation"
dest = repo / "benchmarks/results/2026-11-23-supplied-scalar-return"
sha = lambda data: hashlib.sha256(data).hexdigest()
read = lambda path: json.loads(path.read_text(encoding="utf-8"))
identity = read(lab / "comparison/identity.json")
terminal = read(quiet / "terminal-status.json")
assert not terminal["live"] and terminal["exitCode"] == "0" and not terminal["fixtures"]
assert all(terminal["receipt"][name] for name in (
    "complete", "archivedAndVerifiedUnderLease", "allWorkersJoined", "guestFixturesRemoved", "quietBeforeAndAfter"))
assert sha((quiet / "observations.tar.xz").read_bytes()) == terminal["receipt"]["archiveSHA256"]
assert read(quiet / "summary.json")["timedBatches"] == 168
repeated = read(repeat / "terminal-status.json")
assert not repeated["live"] and repeated["exitCode"] == "0" and not repeated["fixtures"]
assert all(repeated["receipt"][name] for name in (
    "complete", "archivedAndVerifiedUnderLease", "allWorkersJoined", "guestFixturesRemoved", "quietBeforeAndAfter"))
assert sha((repeat / "observations.tar.xz").read_bytes()) == repeated["receipt"]["archiveSHA256"]
assert read(repeat / "summary.json")["timedBatches"] == 84
assert all(row["peakAdmission"][0] == row["peakAdmission"][1] for row in read(lab / "allocation-summary-six.json"))
head = subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=repo, encoding="utf-8").strip()
source_diff = subprocess.check_output(["git", "diff", "--name-only", head, identity["candidate"], "--", "src"], cwd=repo)
identity["retainedRevision"] = None if source_diff else head
patch = subprocess.check_output(["git", "diff", "--binary", identity["sourceRevision"], identity["candidate"], "--", "src", "tests"], cwd=repo)
(lab / "comparison.patch").write_bytes(patch)
identity["comparisonPatchSHA256"] = sha(patch)
dest.mkdir(exist_ok=False)
for role, files in identity["imageFiles"].items():
    assert len(files) == 32 and all(sha((lab / role / name).read_bytes()) == digest for name, digest in files.items())
    core = lab / role / "Lokad.Lython.dll"
    image = dest / "candidate-core.dll.gz" if role == "candidate" else dest.parent / "2026-11-23-eager-isolated-definition/candidate-core.dll.gz"
    if role == "candidate":
        image.write_bytes(gzip.compress(core.read_bytes(), mtime=0))
    assert sha(gzip.decompress(image.read_bytes())) == files[core.name]
(dest / "identity.json").write_text(json.dumps(identity, indent=2) + "\n", encoding="utf-8", newline="\n")
for name in ("observations.tar.xz", "summary.json", "terminal-status.json"):
    shutil.copyfile(quiet / name, dest / name)
    shutil.copyfile(repeat / name, dest / ("repeat-" + name))
for name in ("allocation-summary-six.json", "jit-entry-summary.json"):
    shutil.copyfile(lab / name, dest / name)
with tarfile.open(dest / "procedures.tar.xz", "w:xz") as archive:
    for name in (
        "prepare.py", "freeze.py", "stage.py", "quiet.py", "summarize.py", "allocations.py", "archive.py",
        "inspect-entry.py", "reference-entry.asm", "candidate-entry.asm", "supplied-only.json", "comparison.patch",
        "windows-public.log", "windows-white.log", "windows-frozen.log", "test-ubuntu.sh", "ubuntu-public.log", "ubuntu-white.log",
        "qualify-semantics.py", "scalar-unpack-semantics.json", "reference-scalar-unpack.json", "candidate-scalar-unpack.json",
        "reference-allocation-six.json", "candidate-allocation-six.json", "stage.log", "retrieval.log",
        "comparison/reference-verify.json", "comparison/candidate-verify.json", "comparison/quiet/observe-not-before",
        "confirm.py", "summarize-confirmation.py", "confirmation-launch.log", "confirmation-retrieval.log",
        "confirmation/reference-verify.json", "confirmation/candidate-verify.json", "confirmation/observe-not-before"):
        archive.add(lab / name, arcname=name, recursive=False)
print(dest, identity["retainedRevision"] or "private")
