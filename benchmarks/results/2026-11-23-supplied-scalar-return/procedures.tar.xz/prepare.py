from pathlib import Path
import json
import shutil

lab = Path(__file__).resolve().parent
prior = lab.parent / "eager-isolated-definition-20261123"
donor = lab.parent / "bound-integer-return-20261122/comparison/quiet/representative.json"


def install(name, replacements):
    text = (prior / name).read_text(encoding="utf-8")
    for old, new in replacements:
        assert old in text, (name, old)
        text = text.replace(old, new)
    compile(text, name, "exec")
    (lab / name).write_text(text, encoding="utf-8", newline="\n")


def read(path):
    return json.loads(path.read_text(encoding="utf-8"))


def write(name, value):
    (lab / name).write_text(json.dumps(value, indent=2) + "\n", encoding="utf-8", newline="\n")


catalog = read(prior / "representative.json")
records = {case["id"]: case for case in catalog["cases"] + read(donor)["cases"]}
module_call = "scripts.ordinary-fully-supplied-helper"
local_call = "diagnostic.helper-placement.function-call"
invoice = "scripts.csv-invoice.helper-accumulation"
factory = "scripts.annotated-rule-closures.nested-factories.postponed"
quoted = "scripts.csv-invoice.method-policy.quoted-control"
case_ids = [module_call, local_call, invoice, factory, quoted]
for case in catalog["cases"]:
    if case["id"] in case_ids:
        assert records[case["id"]] == case
catalog["cases"] = [records[case] for case in case_ids]
write("representative.json", catalog)
write("jobs.json", {"warm": [[case, "warm"] for case in case_ids] + [[module_call, "compile-run"]]})

install("freeze.py", [
    ("direct-computed-definition-20261123", "eager-isolated-definition-20261123"),
    ('agent-worktrees/eager-isolated-definition-20261123', 'agent-worktrees/supplied-scalar-return-20261123'),
    ('a61b79041', 'b32bf6b6b'),
    ("lab.parent.parent/'eager-isolated-b1502/windows/bin/Lokad.Lython/release_net11.0'", "lab/'frozen/bin/Lokad.Lython/release_net11.0'"),
    ('B1502 isolate eager annotation admission from the postponed factory',
     'B1504 displace unpack and native activation setup for fully supplied scalar returns'),
    ('five CPython goldens on both factory images', 'five CPython goldens on both scalar-call images'),
])
install("stage.py", [
    ('eager-isolated-definition-b1502-20261123', 'supplied-scalar-return-b1504-20261123'),
    ('direct-computed-definition-b1500-20261123', 'eager-isolated-definition-b1502-20261123'),
    ('lython-b1502', 'lython-b1504'),
])
install("quiet.py", [
    ('eager-isolated-definition-20261123', 'supplied-scalar-return-20261123'),
    ('lython-b1502', 'lython-b1504'),
    ('.+b1502-', '.+b1504-'),
])
for name in ("summarize.py", "allocations.py"):
    shutil.copyfile(prior / name, lab / name)
