; Assembly listing for method Lokad.Lython.Runtime.PyExecutableFunction:StartNativeCall(Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,bool,bool,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,byref,byref):this (FullOpts)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; FullOpts code
; optimized code
; rbp based frame
; partially interruptible
; No PGO data
; 1 inlinees with PGO data; 28 single block inlinees; 7 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       push     r15
       push     r14
       push     r13
       push     r12
       push     rdi
       push     rsi
       push     rbx
       sub      rsp, 520
       lea      rbp, [rsp+0x240]
       vxorps   xmm4, xmm4, xmm4
       vmovdqa  xmmword ptr [rbp-0x1E0], xmm4
       vmovdqa  xmmword ptr [rbp-0x1D0], xmm4
       mov      rax, -384
 
G_M000_IG26:                ;; offset=0x0039
       vmovdqa  xmmword ptr [rbp+rax-0x40], xmm4
       vmovdqa  xmmword ptr [rbp+rax-0x30], xmm4
       vmovdqa  xmmword ptr [rbp+rax-0x20], xmm4
       add      rax, 48
       jne      SHORT G_M000_IG26
       mov      qword ptr [rbp-0x40], rax
       mov      rbx, rcx
       mov      rdi, rdx
       mov      rsi, r9
       mov      r14, gword ptr [rbp+0x38]
       mov      r15, bword ptr [rbp+0x60]
 
G_M000_IG02:                ;; offset=0x0066
       mov      r13, bword ptr [r8]
       mov      r12d, dword ptr [r8+0x08]
       test     rsi, rsi
       sete     r8b
       movzx    r8, r8b
       movzx    rax, byte  ptr [rbp+0x48]
       mov      dword ptr [rbp-0x1E4], eax
       test     r8d, eax
       je       SHORT G_M000_IG06
 
G_M000_IG03:                ;; offset=0x0087
       cmp      r12d, 1
       jne      SHORT G_M000_IG06
       mov      r8, gword ptr [rbx+0x40]
       mov      rdx, gword ptr [r8+0x58]
       test     rdx, rdx
       je       SHORT G_M000_IG06
       mov      r8, gword ptr [rbx+0x28]
       cmp      byte  ptr [r8+0x104], 0
       jne      SHORT G_M000_IG06
 
G_M000_IG04:                ;; offset=0x00A8
       vmovdqu  xmm0, xmmword ptr [r13]
       vmovdqu  xmmword ptr [rbp-0x1A0], xmm0
 
G_M000_IG05:                ;; offset=0x00B6
       mov      bword ptr [rsp+0x20], r15
       lea      r8, [rbp-0x1A0]
       mov      rcx, rbx
       mov      r9, r14
       call     [Lokad.Lython.Runtime.PyExecutableFunction:TryReturnDefinition(Lokad.Lython.Frontend.ExecutableCreateFunction,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot,Lokad.Lython.LythonSourceSpan,byref):bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG07
 
G_M000_IG06:                ;; offset=0x00D2
       test     rsi, rsi
       jne      G_M000_IG12
       mov      rdx, gword ptr [rbx+0x40]
       cmp      byte  ptr [rdx+0xF5], 0
       je       G_M000_IG12
       cmp      dword ptr [rbp-0x1E4], 0
       je       SHORT G_M000_IG08
       cmp      r12d, dword ptr [rdx+0xD8]
       jne      G_M000_IG12
       mov      bword ptr [rbp-0x1B0], r13
       mov      dword ptr [rbp-0x1A8], r12d
       lea      rdx, [rbp-0x1B0]
       mov      rcx, rbx
       mov      r8, r14
       mov      r9, r15
       call     [Lokad.Lython.Runtime.PyExecutableFunction:TryStartDirectIntegerReturn[Lokad.Lython.Runtime.LythonRuntime+SlotIntegerOperands](Lokad.Lython.Runtime.LythonRuntime+SlotIntegerOperands,Lokad.Lython.LythonSourceSpan,byref):bool:this]
       test     eax, eax
       je       G_M000_IG12
 
G_M000_IG07:                ;; offset=0x012E
       mov      rsi, bword ptr [rbp+0x58]
       mov      byte  ptr [rsi], 0
       xor      rax, rax
       mov      rdi, bword ptr [rbp+0x68]
       mov      gword ptr [rdi], rax
       jmp      G_M000_IG15
 
G_M000_IG08:                ;; offset=0x0143
       xor      ecx, ecx
       mov      qword ptr [r15], rcx
       mov      qword ptr [r15+0x08], rcx
       cmp      byte  ptr [rdi+0x34], 0
       je       G_M000_IG10
       mov      rcx, gword ptr [rbx+0x08]
       mov      rcx, gword ptr [rcx+0x08]
       mov      ecx, dword ptr [rcx+0x08]
       mov      rdx, gword ptr [rbx+0x40]
       cmp      ecx, dword ptr [rdx+0xD8]
       jne      SHORT G_M000_IG10
       mov      rcx, rbx
       mov      edx, r12d
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:HasPreparedOmittedArguments(int):bool:this]
       test     eax, eax
       je       SHORT G_M000_IG10
       mov      rax, gword ptr [rbp+0x30]
       mov      rdx, gword ptr [rax+0xA0]
       mov      gword ptr [rbp-0x1F0], rdx
       cmp      byte  ptr [rdx], dl
       mov      rcx, rdx
       call     [Lokad.Lython.Runtime.ExecutionState:get_CanContinue():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG09
       mov      rcx, gword ptr [rbp-0x1F0]
       mov      rdx, r14
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
 
G_M000_IG09:                ;; offset=0x01AE
       mov      gword ptr [rbp-0x188], rbx
       mov      bword ptr [rbp-0x180], r13
       mov      dword ptr [rbp-0x178], r12d
       lea      rdx, [rbp-0x188]
       mov      rcx, rbx
       mov      r8, r14
       mov      r9, r15
       call     [Lokad.Lython.Runtime.PyExecutableFunction:TryStartDirectIntegerReturn[Lokad.Lython.Runtime.LythonRuntime+DefaultIntegerOperands](Lokad.Lython.Runtime.LythonRuntime+DefaultIntegerOperands,Lokad.Lython.LythonSourceSpan,byref):bool:this]
       mov      ecx, eax
       jmp      SHORT G_M000_IG11
 
G_M000_IG10:                ;; offset=0x01DD
       xor      ecx, ecx
 
G_M000_IG11:                ;; offset=0x01DF
       test     ecx, ecx
       jne      G_M000_IG07
 
G_M000_IG12:                ;; offset=0x01E7
       vxorps   ymm0, ymm0, ymm0
       vmovdqu  ymmword ptr [rbp-0x138], ymm0
       vmovdqu  ymmword ptr [rbp-0x118], ymm0
       vmovdqu  ymmword ptr [rbp-0xF8], ymm0
       vmovdqu  ymmword ptr [rbp-0xD8], ymm0
       vmovdqu  ymmword ptr [rbp-0xB8], ymm0
       vmovdqu  ymmword ptr [rbp-0x98], ymm0
       vmovdqu  ymmword ptr [rbp-0x78], ymm0
       vmovdqu  ymmword ptr [rbp-0x58], ymm0
       mov      rcx, gword ptr [rbx+0x40]
       mov      r10d, dword ptr [rcx+0xE8]
       mov      dword ptr [rbp-0x18C], r10d
       cmp      r10d, 16
       ja       G_M000_IG21
       cmp      dword ptr [rbp-0x1E4], 0
       jne      G_M000_IG17
       mov      rcx, gword ptr [rbx+0x08]
       mov      rcx, gword ptr [rcx+0x08]
       mov      ecx, dword ptr [rcx+0x08]
       cmp      ecx, r10d
       ja       G_M000_IG21
       lea      rdx, bword ptr [rbp-0x138]
       mov      bword ptr [rbp-0x1C0], rdx
       mov      dword ptr [rbp-0x1B8], ecx
       xor      rcx, rcx
       mov      bword ptr [rbp-0x1D0], rcx
 
G_M000_IG13:                ;; offset=0x027F
       mov      dword ptr [rbp-0x1C8], ecx
       mov      rcx, gword ptr [rbp+0x30]
       mov      gword ptr [rsp+0x20], rcx
       xor      ecx, ecx
       mov      dword ptr [rsp+0x28], ecx
       mov      gword ptr [rsp+0x30], rsi
       mov      gword ptr [rsp+0x38], rdi
       mov      bword ptr [rbp-0x1E0], r13
       mov      dword ptr [rbp-0x1D8], r12d
       lea      rcx, [rbp-0x1C0]
       lea      rdx, [rbp-0x1D0]
       lea      r9, [rbp-0x1E0]
       mov      qword ptr [rsp+0x40], r9
       mov      r9, rbx
       mov      r8, r14
       call     [Lokad.Lython.Runtime.LythonRuntime:BindFunctionArgumentsInto(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.ReadOnlySpan`1[Lokad.Lython.Runtime.CallArgumentValue],Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.FunctionBindingPlan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,bool,System.Object,Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):int]
 
G_M000_IG14:                ;; offset=0x02D2
       vxorps   ymm0, ymm0, ymm0
       vmovdqu  ymmword ptr [rbp-0x170], ymm0
       lea      rdx, bword ptr [rbp-0x138]
       mov      bword ptr [rbp-0x1C0], rdx
       mov      esi, dword ptr [rbp-0x18C]
       mov      dword ptr [rbp-0x1B8], esi
       movzx    rdx, byte  ptr [rbp+0x40]
       mov      dword ptr [rsp+0x20], edx
       mov      rsi, bword ptr [rbp+0x50]
       mov      bword ptr [rsp+0x28], rsi
       mov      rsi, bword ptr [rbp+0x58]
       mov      bword ptr [rsp+0x30], rsi
       mov      bword ptr [rsp+0x38], r15
       mov      rdi, bword ptr [rbp+0x68]
       mov      bword ptr [rsp+0x40], rdi
       lea      rdx, [rbp-0x150]
       mov      qword ptr [rsp+0x48], rdx
       lea      rdx, [rbp-0x1C0]
       lea      r8, [rbp-0x170]
       mov      rcx, rbx
       mov      r9, r14
       call     [Lokad.Lython.Runtime.PyExecutableFunction:StartInline(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.Nullable`1[Lokad.Lython.Runtime.BoundFunctionArguments],Lokad.Lython.LythonSourceSpan,bool,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,byref,byref,byref):this]
 
G_M000_IG15:                ;; offset=0x0346
       nop      
 
G_M000_IG16:                ;; offset=0x0347
       add      rsp, 520
       pop      rbx
       pop      rsi
       pop      rdi
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG17:                ;; offset=0x035B
       xor      eax, eax
       test     rsi, rsi
       je       SHORT G_M000_IG18
       mov      eax, 1
       test     r10d, r10d
       je       G_M000_IG25
       mov      gword ptr [rbp-0x138], rsi
       xor      ecx, ecx
       mov      qword ptr [rbp-0x130], rcx
 
G_M000_IG18:                ;; offset=0x0380
       cmp      eax, r10d
       ja       SHORT G_M000_IG21
       lea      rcx, bword ptr [rbp-0x138]
       mov      edx, eax
       shl      rdx, 4
       add      rcx, rdx
       mov      edx, r10d
       sub      edx, eax
       cmp      r12d, edx
       ja       SHORT G_M000_IG24
 
G_M000_IG19:                ;; offset=0x039F
       mov      r8d, r12d
       shl      r8, 4
       cmp      r8, 0x4000
       ja       SHORT G_M000_IG23
 
G_M000_IG20:                ;; offset=0x03AF
       mov      rdx, r13
       call     System.Buffer:BulkMoveWithWriteBarrierInternal(byref,byref,nuint)
       cmp      dword ptr [(reloc 0x7ffa30e42aa8)], 0
       je       G_M000_IG14
       jmp      SHORT G_M000_IG22
 
G_M000_IG21:                ;; offset=0x03C6
       call     [System.ThrowHelper:ThrowArgumentOutOfRangeException()]
       int3     
 
G_M000_IG22:                ;; offset=0x03CD
       call     CORINFO_HELP_POLL_GC
       jmp      G_M000_IG14
 
G_M000_IG23:                ;; offset=0x03D7
       mov      rdx, r13
       call     [System.Buffer:BulkMoveWithWriteBarrierBatch(byref,byref,nuint)]
       jmp      G_M000_IG14
 
G_M000_IG24:                ;; offset=0x03E5
       call     [System.ThrowHelper:ThrowArgumentException_DestinationTooShort()]
       int3     
 
G_M000_IG25:                ;; offset=0x03EC
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
; Total bytes of code 1010

