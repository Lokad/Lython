; Assembly listing for method Lokad.Lython.Runtime.PyExecutableFunction:TryStartSuppliedIntegerReturn(System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.Object,Lokad.Lython.LythonSourceSpan,byref):bool:this (FullOpts)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; FullOpts code
; optimized code
; rsp based frame
; partially interruptible
; No PGO data
; 0 inlinees with PGO data; 6 single block inlinees; 0 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     rsi
       push     rbx
       sub      rsp, 72
       vxorps   xmm4, xmm4, xmm4
       vmovdqu  ymmword ptr [rsp+0x20], ymm4
       xor      eax, eax
       mov      qword ptr [rsp+0x40], rax
       mov      rax, r9
       mov      r9, bword ptr [rsp+0x80]
 
G_M000_IG02:                ;; offset=0x0022
       mov      rbx, bword ptr [rdx]
       mov      esi, dword ptr [rdx+0x08]
       xor      edx, edx
       mov      qword ptr [r9], rdx
       mov      qword ptr [r9+0x08], rdx
       mov      rdx, gword ptr [rcx+0x40]
       cmp      byte  ptr [rdx+0xF5], 0
       je       SHORT G_M000_IG07
 
G_M000_IG03:                ;; offset=0x003E
       test     r8, r8
       setne    r10b
       movzx    r10, r10b
       add      r10d, esi
       cmp      r10d, dword ptr [rdx+0xD8]
       jne      SHORT G_M000_IG07
       test     r8, r8
       jne      SHORT G_M000_IG05
       mov      bword ptr [rsp+0x20], rbx
       mov      dword ptr [rsp+0x28], esi
       lea      rdx, [rsp+0x20]
       mov      r8, rax
       call     [Lokad.Lython.Runtime.PyExecutableFunction:TryStartDirectIntegerReturn[Lokad.Lython.Runtime.LythonRuntime+SlotIntegerOperands](Lokad.Lython.Runtime.LythonRuntime+SlotIntegerOperands,Lokad.Lython.LythonSourceSpan,byref):bool:this]
       nop      
 
G_M000_IG04:                ;; offset=0x0072
       add      rsp, 72
       pop      rbx
       pop      rsi
       ret      
 
G_M000_IG05:                ;; offset=0x0079
       mov      gword ptr [rsp+0x30], r8
       mov      bword ptr [rsp+0x38], rbx
       mov      dword ptr [rsp+0x40], esi
       lea      rdx, [rsp+0x30]
       mov      r8, rax
       call     [Lokad.Lython.Runtime.PyExecutableFunction:TryStartDirectIntegerReturn[Lokad.Lython.Runtime.LythonRuntime+BoundIntegerOperands](Lokad.Lython.Runtime.LythonRuntime+BoundIntegerOperands,Lokad.Lython.LythonSourceSpan,byref):bool:this]
       nop      
 
G_M000_IG06:                ;; offset=0x0096
       add      rsp, 72
       pop      rbx
       pop      rsi
       ret      
 
G_M000_IG07:                ;; offset=0x009D
       xor      eax, eax
 
G_M000_IG08:                ;; offset=0x009F
       add      rsp, 72
       pop      rbx
       pop      rsi
       ret      
 
; Total bytes of code 166

