from pathlib import Path
import hashlib
import json
import os
import subprocess
from textwrap import dedent

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
tree = repo / ".git/agent-worktrees/supplied-scalar-return-20261123"
test = tree / "tests/Lokad.Lython.PublicApi.Tests/NativeIntegerChainTests.cs"
program = dedent(test.read_text(encoding="utf-8").split('SuppliedScalarUnpack = """\n', 1)[1].split('""";', 1)[0])
python = "C:/Python313/python.exe"
result = subprocess.run([python, "-I", "-X", "utf8", "-c", program],
                        text=True, encoding="utf-8", capture_output=True, check=True, timeout=15)
golden = result.stdout
assert golden == "42 9223372036854775808\ncannot unpack\ncannot unpack\ncannot unpack\n"
sha = lambda text: hashlib.sha256(text.encode("utf-8")).hexdigest()
data = json.loads((lab / "comparison/representative.json").read_text(encoding="utf-8"))
record = data["cases"][0].copy()
record.update(source=program, expectedOutput=golden, sourceSha256=sha(program),
              expectedOutputSha256=sha(golden), sourceUtf8Bytes=len(program.encode("utf-8")),
              expectedOutputUtf8Bytes=len(golden.encode("utf-8")))
data["cases"] = [record]
catalog = lab / "scalar-unpack-semantics.json"
catalog.write_text(json.dumps(data, indent=2) + "\n", encoding="utf-8", newline="\n")
dotnet = Path.home() / ".dotnet11/dotnet.exe"
env = dict(os.environ, DOTNET_ROOT=str(dotnet.parent), DOTNET_ROOT_X64=str(dotnet.parent))
for role in ("reference", "candidate"):
    worker = lab / role / "Lokad.Lython.Benchmarks.dll"
    receipt = lab / (role + "-scalar-unpack.json")
    subprocess.run([dotnet, worker, "--compare", "verify", "--catalog", catalog, "--dotnet", dotnet,
                    "--python", python, "--python-worker", repo / "benchmarks/cpython-worker.py",
                    "--out", receipt], env=env, timeout=45, check=True)
    artifact = json.loads(receipt.read_text(encoding="utf-8"))
    assert artifact["state"] == "Completed" and artifact["caseCount"] == 1
