from pathlib import Path
from shutil import copy2
from hashlib import sha256
from subprocess import check_output
import json,re,tarfile

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
root=lab/'comparison'
output=repo/'benchmarks/results/2026-11-28-direct-executable-frame-initialization'
def read(p):return json.loads(p.read_bytes())
def digest(p):return sha256(p.read_bytes()).hexdigest()
id=read(root/'identity.json')
assert id['sourcePatchSHA256']==digest(lab/'candidate.patch')
assert check_output(['git','diff','--binary',id['sourceRevision'],'--','src/Lokad.Lython'],cwd=repo)==(lab/'candidate.patch').read_bytes()
for role,manifest in id['imageFiles'].items():
    assert len(manifest)==32 and {p.name:digest(p) for p in (root/role).iterdir()}==manifest
summary=read(root/'summary.json')
assert len(summary['rows'])==7 and summary['verifiedTimedBatches']==196
receipt=read(root/'archive-receipt.json')
assert receipt['complete'] and receipt['allWorkersJoined'] and receipt['guestFixturesRemoved']
assert receipt['archiveSHA256']==digest(root/'observations.tar.xz')
rows=read(lab/'allocation/summary.json')
assert len(rows)==8 and all(row['compiled'][0]==row['compiled'][1] and row['admittedPeak'][0]==row['admittedPeak'][1] for row in rows)
assert max(abs(row['clr'][0]-row['clr'][1]) for row in rows)==230
logs=list(lab.glob('windows-Lokad*.log'))+list(lab.glob('ubuntu-Lokad*.log'))
assert len(logs)==5
for log in logs:
    count=2652 if 'PublicApi' in log.name else 773
    assert re.search(f'Failed: +0, Passed: +{count}, Skipped: +0',log.read_text(encoding='utf-8-sig')),log
output.mkdir(exist_ok=True)
artifacts={name:root/name for name in ('identity.json','summary.json','observations.tar.xz','archive-receipt.json')}
artifacts['allocation.json']=lab/'allocation/summary.json'
for name in ('il-evidence.json','activation-costs.json'):
    artifacts[name]=lab/name
for name,source in artifacts.items():
    copy2(source,output/name)
    assert digest(output/name)==digest(source)
details={p.name:p for p in logs}
for name in ('candidate.patch','frame-initialization.il','test-ubuntu.sh','summarize.py','measure-allocation.py','publish.py'):
    details[name]=lab/name
for name in ('collection.log','reference-verify.json','candidate-verify.json','exit-code.txt'):
    details[name]=root/name
for p in (lab/'allocation').glob('*.json'):
    details['allocation/'+p.name]=p
with tarfile.open(output/'procedures.tar.xz','w:xz') as bundle:
    for name,source in details.items():
        bundle.add(source,arcname=name)
with tarfile.open(output/'procedures.tar.xz') as bundle:
    assert all(digest(path)==sha256(bundle.extractfile(name).read()).hexdigest() for name,path in details.items())
print('Verified timing, allocations, and source archives')
