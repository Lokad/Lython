.method private hidebysig static 
		void InitializeExecutableFrame (
			class Lokad.Lython.Frontend.ExecutableCodeObject codeObject,
			class Lokad.Lython.Runtime.LythonRuntime/ExecutionContext context,
			valuetype Lokad.Lython.Runtime.BoundFunctionArguments boundArguments,
			valuetype Lokad.Lython.Runtime.LythonRuntime/ExecutableCaptures closureCells,
			[opt] class Lokad.Lython.Runtime.PyExecutableFunction lookupOwner,
			[opt] bool returnConsumedByIteration,
			[opt] bool continuingNative
		) cil managed 
	{
		.param [5] = nullref
			.custom instance void [System.Runtime]System.Runtime.CompilerServices.NullableAttribute::.ctor(uint8) = (
				01 00 02 00 00
			)
		.param [6] = bool(false)
		.param [7] = bool(false)
		// Method begins at RVA 0x24704
		// Header size: 12
		// Code size: 37 (0x25)
		.maxstack 8
		.locals init (
			[0] valuetype Lokad.Lython.Runtime.LythonRuntime/ExecutableWorkState
		)

		IL_0000: ldarg.0
		IL_0001: ldarg.1
		IL_0002: ldarg.2
		IL_0003: ldarg.3
		IL_0004: ldarg.s lookupOwner
		IL_0006: ldarg.s returnConsumedByIteration
		IL_0008: ldc.i4.0
		IL_0009: ldarg.s continuingNative
		IL_000b: call valuetype Lokad.Lython.Runtime.LythonRuntime/ExecutableWorkState Lokad.Lython.Runtime.LythonRuntime::CreateExecutableWorkState(class Lokad.Lython.Frontend.ExecutableCodeObject, class Lokad.Lython.Runtime.LythonRuntime/ExecutionContext, valuetype Lokad.Lython.Runtime.BoundFunctionArguments, valuetype Lokad.Lython.Runtime.LythonRuntime/ExecutableCaptures, class Lokad.Lython.Runtime.PyFunctionBase, bool, bool, bool)
		IL_0010: stloc.0
		IL_0011: ldarg.1
		IL_0012: ldloca.s 0
		IL_0014: ldarg.1
		IL_0015: callvirt instance class Lokad.Lython.Runtime.ExecutionState Lokad.Lython.Runtime.LythonRuntime/ExecutionContext::get_State()
		IL_001a: callvirt instance class Lokad.Lython.Runtime.PyException Lokad.Lython.Runtime.ExecutionState::get_CurrentException()
		IL_001f: callvirt instance void Lokad.Lython.Runtime.LythonRuntime/ExecutionContext::AdoptExecutableExecution(valuetype Lokad.Lython.Runtime.LythonRuntime/ExecutableWorkState&, class Lokad.Lython.Runtime.PyException)
		IL_0024: ret
	} // end of method LythonRuntime::InitializeExecutableFrame

.method assembly hidebysig 
			instance void AdoptExecutableExecution (
				valuetype Lokad.Lython.Runtime.LythonRuntime/ExecutableWorkState& execution,
				class Lokad.Lython.Runtime.PyException entryException
			) cil managed 
		{
			.custom instance void [System.Runtime]System.Runtime.CompilerServices.NullableContextAttribute::.ctor(uint8) = (
				01 00 02 00 00
			)
			// Method begins at RVA 0xf9bba
			// Header size: 1
			// Code size: 27 (0x1b)
			.maxstack 8

			IL_0000: ldarg.0
			IL_0001: ldarg.1
			IL_0002: ldobj Lokad.Lython.Runtime.LythonRuntime/ExecutableWorkState
			IL_0007: stfld valuetype Lokad.Lython.Runtime.LythonRuntime/ExecutableWorkState Lokad.Lython.Runtime.LythonRuntime/ExecutionContext::_execution
			IL_000c: ldarg.0
			IL_000d: ldarg.2
			IL_000e: stfld class Lokad.Lython.Runtime.PyException Lokad.Lython.Runtime.LythonRuntime/ExecutionContext::_entryActiveException
			IL_0013: ldarg.1
			IL_0014: initobj Lokad.Lython.Runtime.LythonRuntime/ExecutableWorkState
			IL_001a: ret
		} // end of method ExecutionContext::AdoptExecutableExecution

.method assembly hidebysig 
			instance void AdoptGeneratorExecution (
				valuetype Lokad.Lython.Runtime.LythonRuntime/ExecutableWorkState& execution,
				class Lokad.Lython.Runtime.MemoryGovernor storageOwner
			) cil managed 
		{
			.custom instance void [System.Runtime]System.Runtime.CompilerServices.NullableContextAttribute::.ctor(uint8) = (
				01 00 02 00 00
			)
			// Method begins at RVA 0xf9bd6
			// Header size: 1
			// Code size: 26 (0x1a)
			.maxstack 8

			IL_0000: ldarg.0
			IL_0001: ldarg.1
			IL_0002: ldarg.0
			IL_0003: call instance class Lokad.Lython.Runtime.ExecutionState Lokad.Lython.Runtime.LythonRuntime/ExecutionContext::get_State()
			IL_0008: callvirt instance class Lokad.Lython.Runtime.PyException Lokad.Lython.Runtime.ExecutionState::get_CurrentException()
			IL_000d: call instance void Lokad.Lython.Runtime.LythonRuntime/ExecutionContext::AdoptExecutableExecution(valuetype Lokad.Lython.Runtime.LythonRuntime/ExecutableWorkState&, class Lokad.Lython.Runtime.PyException)
			IL_0012: ldarg.0
			IL_0013: ldarg.2
			IL_0014: stfld class Lokad.Lython.Runtime.MemoryGovernor Lokad.Lython.Runtime.LythonRuntime/ExecutionContext::_boundStorageOwner
			IL_0019: ret
		} // end of method ExecutionContext::AdoptGeneratorExecution

.method assembly hidebysig 
			instance void InitializeExecutableFrame (
				class Lokad.Lython.Frontend.ExecutableCodeObject code,
				valuetype Lokad.Lython.Runtime.BoundFunctionArguments arguments,
				valuetype Lokad.Lython.Runtime.LythonRuntime/ExecutableCaptures captures,
				[opt] class Lokad.Lython.Runtime.PyFunctionBase lookupOwner,
				[opt] bool returnConsumedByIteration,
				[opt] bool continuingNative
			) cil managed 
		{
			.param [4] = nullref
				.custom instance void [System.Runtime]System.Runtime.CompilerServices.NullableAttribute::.ctor(uint8) = (
					01 00 02 00 00
				)
			.param [5] = bool(false)
			.param [6] = bool(false)
			// Method begins at RVA 0xf9b74
			// Header size: 12
			// Code size: 40 (0x28)
			.maxstack 9

			IL_0000: ldarg.0
			IL_0001: ldflda valuetype Lokad.Lython.Runtime.LythonRuntime/ExecutableWorkState Lokad.Lython.Runtime.LythonRuntime/ExecutionContext::_execution
			IL_0006: ldarg.1
			IL_0007: ldarg.0
			IL_0008: ldarg.2
			IL_0009: ldarg.3
			IL_000a: ldarg.s lookupOwner
			IL_000c: ldarg.s returnConsumedByIteration
			IL_000e: ldc.i4.0
			IL_000f: ldarg.s continuingNative
			IL_0011: call void Lokad.Lython.Runtime.LythonRuntime::InitializeExecutableWorkState(valuetype Lokad.Lython.Runtime.LythonRuntime/ExecutableWorkState&, class Lokad.Lython.Frontend.ExecutableCodeObject, class Lokad.Lython.Runtime.LythonRuntime/ExecutionContext, valuetype Lokad.Lython.Runtime.BoundFunctionArguments, valuetype Lokad.Lython.Runtime.LythonRuntime/ExecutableCaptures, class Lokad.Lython.Runtime.PyFunctionBase, bool, bool, bool)
			IL_0016: ldarg.0
			IL_0017: ldarg.0
			IL_0018: call instance class Lokad.Lython.Runtime.ExecutionState Lokad.Lython.Runtime.LythonRuntime/ExecutionContext::get_State()
			IL_001d: callvirt instance class Lokad.Lython.Runtime.PyException Lokad.Lython.Runtime.ExecutionState::get_CurrentException()
			IL_0022: stfld class Lokad.Lython.Runtime.PyException Lokad.Lython.Runtime.LythonRuntime/ExecutionContext::_entryActiveException
			IL_0027: ret
		} // end of method ExecutionContext::InitializeExecutableFrame

.method private hidebysig static 
		void InitializeExecutableWorkState (
			valuetype Lokad.Lython.Runtime.LythonRuntime/ExecutableWorkState& execution,
			class Lokad.Lython.Frontend.ExecutableCodeObject codeObject,
			class Lokad.Lython.Runtime.LythonRuntime/ExecutionContext context,
			valuetype Lokad.Lython.Runtime.BoundFunctionArguments boundArguments,
			valuetype Lokad.Lython.Runtime.LythonRuntime/ExecutableCaptures closureCells,
			[opt] class Lokad.Lython.Runtime.PyFunctionBase lookupOwner,
			[opt] bool returnConsumedByIteration,
			[opt] bool borrowedInvocation,
			[opt] bool continuingNative
		) cil managed 
	{
		.param [6] = nullref
			.custom instance void [System.Runtime]System.Runtime.CompilerServices.NullableAttribute::.ctor(uint8) = (
				01 00 02 00 00
			)
		.param [7] = bool(false)
		.param [8] = bool(false)
		.param [9] = bool(false)
		// Method begins at RVA 0x24704
		// Header size: 12
		// Code size: 455 (0x1c7)
		.maxstack 9
		.locals init (
			[0] valuetype Lokad.Lython.Frontend.ExecutableInstruction[],
			[1] class Lokad.Lython.LythonSourceSpan,
			[2] int64,
			[3] int32,
			[4] valuetype Lokad.Lython.Runtime.LythonRuntime/ExecutableValueStorage,
			[5] class [System.Runtime]System.Collections.Generic.IEnumerator`1<int32>,
			[6] int32,
			[7] valuetype Lokad.Lython.Runtime.LythonRuntime/ExecutableSlot[],
			[8] bool,
			[9] int32,
			[10] int32
		)

		IL_0000: ldarg.1
		IL_0001: callvirt instance valuetype Lokad.Lython.Frontend.ExecutableInstruction[] Lokad.Lython.Frontend.ExecutableCodeObject::get_Instructions()
		IL_0006: stloc.0
		IL_0007: ldloc.0
		IL_0008: ldlen
		IL_0009: brfalse.s IL_0019

		IL_000b: ldloc.0
		IL_000c: ldc.i4.0
		IL_000d: ldelema Lokad.Lython.Frontend.ExecutableInstruction
		IL_0012: call instance class Lokad.Lython.LythonSourceSpan Lokad.Lython.Frontend.ExecutableInstruction::get_Span()
		IL_0017: br.s IL_001a

		IL_0019: ldnull

		IL_001a: stloc.1
		IL_001b: ldarg.1
		IL_001c: callvirt instance int32 Lokad.Lython.Frontend.ExecutableCodeObject::get_PatternStorageCount()
		IL_0021: conv.i8
		IL_0022: ldc.i4.s 64
		IL_0024: conv.i8
		IL_0025: mul.ovf
		IL_0026: stloc.2
		IL_0027: ldarg.1
		IL_0028: callvirt instance class [System.Runtime]System.Collections.Generic.IReadOnlyList`1<int32> Lokad.Lython.Frontend.ExecutableCodeObject::get_CapturedLocalSlots()
		IL_002d: callvirt instance int32 class [System.Runtime]System.Collections.Generic.IReadOnlyCollection`1<int32>::get_Count()
		IL_0032: stloc.3
		IL_0033: ldarg.s continuingNative
		IL_0035: brfalse.s IL_0087

		IL_0037: ldloc.3
		IL_0038: brfalse.s IL_0087

		IL_003a: ldarg.1
		IL_003b: callvirt instance class [System.Runtime]System.Collections.Generic.IReadOnlyList`1<int32> Lokad.Lython.Frontend.ExecutableCodeObject::get_CapturedLocalSlots()
		IL_0040: callvirt instance class [System.Runtime]System.Collections.Generic.IEnumerator`1<!0> class [System.Runtime]System.Collections.Generic.IEnumerable`1<int32>::GetEnumerator()
		IL_0045: stloc.s 5
		.try
		{
			IL_0047: br.s IL_0070
			// loop start (head: IL_0070)
				IL_0049: ldloc.s 5
				IL_004b: callvirt instance !0 class [System.Runtime]System.Collections.Generic.IEnumerator`1<int32>::get_Current()
				IL_0050: stloc.s 6
				IL_0052: ldarga.s boundArguments
				IL_0054: call instance valuetype Lokad.Lython.Runtime.LythonRuntime/ExecutableSlot[] Lokad.Lython.Runtime.BoundFunctionArguments::get_Values()
				IL_0059: ldloc.s 6
				IL_005b: ldelema Lokad.Lython.Runtime.LythonRuntime/ExecutableSlot
				IL_0060: call instance object Lokad.Lython.Runtime.LythonRuntime/ExecutableSlot::get_Reference()
				IL_0065: isinst Lokad.Lython.Runtime.LythonRuntime/ExecutableCell
				IL_006a: brfalse.s IL_0070

				IL_006c: ldloc.3
				IL_006d: ldc.i4.1
				IL_006e: sub
				IL_006f: stloc.3

				IL_0070: ldloc.s 5
				IL_0072: callvirt instance bool [System.Runtime]System.Collections.IEnumerator::MoveNext()
				IL_0077: brtrue.s IL_0049
			// end loop

			IL_0079: leave.s IL_0087
		} // end .try
		finally
		{
			IL_007b: ldloc.s 5
			IL_007d: brfalse.s IL_0086

			IL_007f: ldloc.s 5
			IL_0081: callvirt instance void [System.Runtime]System.IDisposable::Dispose()

			IL_0086: endfinally
		} // end handler

		IL_0087: ldloc.2
		IL_0088: ldc.i4.s 96
		IL_008a: conv.i8
		IL_008b: ldloc.3
		IL_008c: conv.i8
		IL_008d: mul.ovf
		IL_008e: add.ovf
		IL_008f: stloc.2
		IL_0090: ldloca.s 4
		IL_0092: ldarg.1
		IL_0093: callvirt instance int32 Lokad.Lython.Frontend.ExecutableCodeObject::get_ValueStorageCapacity()
		IL_0098: ldarg.1
		IL_0099: callvirt instance int32 Lokad.Lython.Frontend.ExecutableCodeObject::get_FirstTemporarySlot()
		IL_009e: ldarg.1
		IL_009f: callvirt instance int32 Lokad.Lython.Frontend.ExecutableCodeObject::get_LastOwnedTemporarySlot()
		IL_00a4: ldarg.2
		IL_00a5: ldloc.1
		IL_00a6: ldloc.2
		IL_00a7: ldarga.s boundArguments
		IL_00a9: call instance valuetype Lokad.Lython.Runtime.LythonRuntime/ExecutableSlot[] Lokad.Lython.Runtime.BoundFunctionArguments::get_Values()
		IL_00ae: ldarg.s lookupOwner
		IL_00b0: call instance void Lokad.Lython.Runtime.LythonRuntime/ExecutableValueStorage::.ctor(int32, int32, int32, class Lokad.Lython.Runtime.LythonRuntime/ExecutionContext, class Lokad.Lython.LythonSourceSpan, int64, valuetype Lokad.Lython.Runtime.LythonRuntime/ExecutableSlot[], class Lokad.Lython.Runtime.PyFunctionBase)
		.try
		{
			IL_00b5: ldloca.s 4
			IL_00b7: call instance valuetype Lokad.Lython.Runtime.LythonRuntime/ExecutableSlot[] Lokad.Lython.Runtime.LythonRuntime/ExecutableValueStorage::get_Values()
			IL_00bc: stloc.s 7
			IL_00be: ldarg.1
			IL_00bf: callvirt instance bool Lokad.Lython.Frontend.ExecutableCodeObject::get_UsesOnlyLexicalSlots()
			IL_00c4: brfalse.s IL_00f3

			IL_00c6: ldarg.s borrowedInvocation
			IL_00c8: brtrue.s IL_00f0

			IL_00ca: ldarg.2
			IL_00cb: callvirt instance bool Lokad.Lython.Runtime.LythonRuntime/ExecutionContext::get_MirrorLocalStores()
			IL_00d0: brtrue.s IL_00ed

			IL_00d2: ldarg.2
			IL_00d3: callvirt instance bool Lokad.Lython.Runtime.LythonRuntime/ExecutionContext::get_IsClassBody()
			IL_00d8: brtrue.s IL_00ed

			IL_00da: ldarg.2
			IL_00db: callvirt instance bool Lokad.Lython.Runtime.LythonRuntime/ExecutionContext::get_IsAnnotationScope()
			IL_00e0: brtrue.s IL_00ed

			IL_00e2: ldarg.2
			IL_00e3: callvirt instance class Lokad.Lython.Runtime.LythonRuntime/ExecutionContext Lokad.Lython.Runtime.LythonRuntime/ExecutionContext::get_InlinedComprehensionLookup()
			IL_00e8: ldnull
			IL_00e9: ceq
			IL_00eb: br.s IL_00f4

			IL_00ed: ldc.i4.0
			IL_00ee: br.s IL_00f4

			IL_00f0: ldc.i4.1
			IL_00f1: br.s IL_00f4

			IL_00f3: ldc.i4.0

			IL_00f4: stloc.s 8
			IL_00f6: ldc.i4.0
			IL_00f7: stloc.s 9
			IL_00f9: br.s IL_016c
			// loop start (head: IL_016c)
				IL_00fb: ldarg.1
				IL_00fc: callvirt instance class [System.Runtime]System.Collections.Generic.IReadOnlyList`1<int32> Lokad.Lython.Frontend.ExecutableCodeObject::get_CapturedLocalSlots()
				IL_0101: ldloc.s 9
				IL_0103: callvirt instance !0 class [System.Runtime]System.Collections.Generic.IReadOnlyList`1<int32>::get_Item(int32)
				IL_0108: stloc.s 10
				IL_010a: ldarg.s continuingNative
				IL_010c: brfalse.s IL_0123

				IL_010e: ldloc.s 7
				IL_0110: ldloc.s 10
				IL_0112: ldelema Lokad.Lython.Runtime.LythonRuntime/ExecutableSlot
				IL_0117: call instance object Lokad.Lython.Runtime.LythonRuntime/ExecutableSlot::get_Reference()
				IL_011c: isinst Lokad.Lython.Runtime.LythonRuntime/ExecutableCell
				IL_0121: brtrue.s IL_0166

				IL_0123: ldloc.s 7
				IL_0125: ldloc.s 10
				IL_0127: ldelema Lokad.Lython.Runtime.LythonRuntime/ExecutableSlot
				IL_012c: ldloc.s 8
				IL_012e: brtrue.s IL_0153

				IL_0130: ldloc.s 7
				IL_0132: ldloc.s 10
				IL_0134: ldelema Lokad.Lython.Runtime.LythonRuntime/ExecutableSlot
				IL_0139: call instance object Lokad.Lython.Runtime.LythonRuntime/ExecutableSlot::get_Object()
				IL_013e: ldarg.2
				IL_013f: ldarg.1
				IL_0140: callvirt instance class [System.Runtime]System.Collections.Generic.IReadOnlyList`1<string> Lokad.Lython.Frontend.ExecutableCodeObject::get_LocalNames()
				IL_0145: ldloc.s 10
				IL_0147: callvirt instance !0 class [System.Runtime]System.Collections.Generic.IReadOnlyList`1<string>::get_Item(int32)
				IL_014c: newobj instance void Lokad.Lython.Runtime.LythonRuntime/ExecutableCell::.ctor(object, class Lokad.Lython.Runtime.LythonRuntime/ExecutionContext, string)
				IL_0151: br.s IL_0161

				IL_0153: ldloc.s 7
				IL_0155: ldloc.s 10
				IL_0157: ldelem Lokad.Lython.Runtime.LythonRuntime/ExecutableSlot
				IL_015c: newobj instance void Lokad.Lython.Runtime.LythonRuntime/ExecutableCell::.ctor(valuetype Lokad.Lython.Runtime.LythonRuntime/ExecutableSlot)

				IL_0161: call instance void Lokad.Lython.Runtime.LythonRuntime/ExecutableSlot::set_Object(object)

				IL_0166: ldloc.s 9
				IL_0168: ldc.i4.1
				IL_0169: add
				IL_016a: stloc.s 9

				IL_016c: ldloc.s 9
				IL_016e: ldarg.1
				IL_016f: callvirt instance class [System.Runtime]System.Collections.Generic.IReadOnlyList`1<int32> Lokad.Lython.Frontend.ExecutableCodeObject::get_CapturedLocalSlots()
				IL_0174: callvirt instance int32 class [System.Runtime]System.Collections.Generic.IReadOnlyCollection`1<int32>::get_Count()
				IL_0179: blt.s IL_00fb
			// end loop

			IL_017b: ldarg.0
			IL_017c: ldloc.s 7
			IL_017e: stfld valuetype Lokad.Lython.Runtime.LythonRuntime/ExecutableSlot[] Lokad.Lython.Runtime.LythonRuntime/ExecutableWorkState::Locals
			IL_0183: ldarg.0
			IL_0184: ldarg.s closureCells
			IL_0186: stfld valuetype Lokad.Lython.Runtime.LythonRuntime/ExecutableCaptures Lokad.Lython.Runtime.LythonRuntime/ExecutableWorkState::Captures
			IL_018b: ldarg.0
			IL_018c: ldloc.s 4
			IL_018e: stfld valuetype Lokad.Lython.Runtime.LythonRuntime/ExecutableValueStorage Lokad.Lython.Runtime.LythonRuntime/ExecutableWorkState::Stack
			IL_0193: ldarg.0
			IL_0194: ldarg.s returnConsumedByIteration
			IL_0196: stfld bool Lokad.Lython.Runtime.LythonRuntime/ExecutableWorkState::ReturnConsumedByIteration
			IL_019b: ldarg.0
			IL_019c: ldarg.1
			IL_019d: callvirt instance int32 Lokad.Lython.Frontend.ExecutableCodeObject::get_EntryIndex()
			IL_01a2: stfld int32 Lokad.Lython.Runtime.LythonRuntime/ExecutableWorkState::InstructionIndex
			IL_01a7: ldarg.0
			IL_01a8: ldflda valuetype Lokad.Lython.Runtime.LythonRuntime/ExecutableSlot Lokad.Lython.Runtime.LythonRuntime/ExecutableWorkState::ReturnValue
			IL_01ad: initobj Lokad.Lython.Runtime.LythonRuntime/ExecutableSlot
			IL_01b3: ldarg.0
			IL_01b4: ldarg.1
			IL_01b5: stfld class Lokad.Lython.Frontend.ExecutableCodeObject Lokad.Lython.Runtime.LythonRuntime/ExecutableWorkState::Code
			IL_01ba: leave.s IL_01c6
		} // end .try
		catch [System.Runtime]System.Object
		{
			IL_01bc: pop
			IL_01bd: ldloca.s 4
			IL_01bf: call instance void Lokad.Lython.Runtime.LythonRuntime/ExecutableValueStorage::ReleaseStorage()
			IL_01c4: rethrow
		} // end handler

		IL_01c6: ret
	} // end of method LythonRuntime::InitializeExecutableWorkState

.method assembly hidebysig 
			instance void InitializeGeneratorExecution (
				class Lokad.Lython.Frontend.ExecutableCodeObject code,
				valuetype Lokad.Lython.Runtime.BoundFunctionArguments arguments,
				valuetype Lokad.Lython.Runtime.LythonRuntime/ExecutableCaptures captures,
				class Lokad.Lython.Runtime.PyGeneratorFunction lookupOwner
			) cil managed 
		{
			.param [4]
				.custom instance void [System.Runtime]System.Runtime.CompilerServices.NullableAttribute::.ctor(uint8) = (
					01 00 02 00 00
				)
			// Method begins at RVA 0xf9bc4
			// Header size: 1
			// Code size: 27 (0x1b)
			.maxstack 8

			IL_0000: ldarg.0
			IL_0001: ldarg.1
			IL_0002: ldarg.2
			IL_0003: ldarg.3
			IL_0004: ldarg.s lookupOwner
			IL_0006: ldc.i4.0
			IL_0007: ldc.i4.0
			IL_0008: call instance void Lokad.Lython.Runtime.LythonRuntime/ExecutionContext::InitializeExecutableFrame(class Lokad.Lython.Frontend.ExecutableCodeObject, valuetype Lokad.Lython.Runtime.BoundFunctionArguments, valuetype Lokad.Lython.Runtime.LythonRuntime/ExecutableCaptures, class Lokad.Lython.Runtime.PyFunctionBase, bool, bool)
			IL_000d: ldarg.0
			IL_000e: ldarga.s arguments
			IL_0010: call instance class Lokad.Lython.Runtime.MemoryGovernor Lokad.Lython.Runtime.BoundFunctionArguments::get_StorageOwner()
			IL_0015: stfld class Lokad.Lython.Runtime.MemoryGovernor Lokad.Lython.Runtime.LythonRuntime/ExecutionContext::_boundStorageOwner
			IL_001a: ret
		} // end of method ExecutionContext::InitializeGeneratorExecution

.method private hidebysig static 
			class Lokad.Lython.Runtime.LythonRuntime/ExecutionContext PromoteBorrowedInvocation (
				class Lokad.Lython.Runtime.PyExecutableFunction function,
				[in] valuetype Lokad.Lython.Runtime.BoundFunctionArguments& bound,
				valuetype Lokad.Lython.Runtime.LythonRuntime/ExecutableWorkState& work,
				class Lokad.Lython.LythonSourceSpan span,
				class Lokad.Lython.Runtime.PyException entryException,
				valuetype Lokad.Lython.Runtime.LythonRuntime/ExecutionContext/InstructionPause pause,
				valuetype [System.Runtime]System.Threading.Tasks.ValueTask`1<class Lokad.Lython.Runtime.LythonRuntime/ExecutionContext> nextCall
			) cil managed 
		{
			.param [2]
				.custom instance void [System.Runtime]System.Runtime.CompilerServices.IsReadOnlyAttribute::.ctor() = (
					01 00 00 00
				)
			.param [5]
				.custom instance void [System.Runtime]System.Runtime.CompilerServices.NullableAttribute::.ctor(uint8) = (
					01 00 02 00 00
				)
			.param [7]
				.custom instance void [System.Runtime]System.Runtime.CompilerServices.NullableAttribute::.ctor(uint8[]) = (
					01 00 02 00 00 00 00 02 00 00
				)
			// Method begins at RVA 0xf5a38
			// Header size: 12
			// Code size: 166 (0xa6)
			.maxstack 5
			.locals init (
				[0] class Lokad.Lython.Runtime.LythonRuntime/ExecutionContext,
				[1] class Lokad.Lython.Runtime.LythonRuntime/ExecutionContext,
				[2] valuetype Lokad.Lython.Frontend.ExecutableInstruction&,
				[3] class Lokad.Lython.Runtime.LythonRuntime/ExecutionContext
			)

			IL_0000: ldarg.s pause
			IL_0002: ldc.i4.3
			IL_0003: beq.s IL_0015

			IL_0005: ldarg.s pause
			IL_0007: ldc.i4.5
			IL_0008: beq.s IL_0015

			IL_000a: ldstr "A borrowed invocation cannot suspend."
			IL_000f: newobj instance void [System.Runtime]System.InvalidOperationException::.ctor(string)
			IL_0014: throw

			IL_0015: ldarg.s pause
			IL_0017: ldc.i4.3
			IL_0018: beq.s IL_001d

			IL_001a: ldnull
			IL_001b: br.s IL_0024

			IL_001d: ldarga.s nextCall
			IL_001f: call instance !0 valuetype [System.Runtime]System.Threading.Tasks.ValueTask`1<class Lokad.Lython.Runtime.LythonRuntime/ExecutionContext>::get_Result()

			IL_0024: stloc.0
			.try
			{
				IL_0025: ldarg.0
				IL_0026: ldarg.1
				IL_0027: ldobj Lokad.Lython.Runtime.BoundFunctionArguments
				IL_002c: ldarg.3
				IL_002d: ldc.i4.0
				IL_002e: callvirt instance class Lokad.Lython.Runtime.LythonRuntime/ExecutionContext Lokad.Lython.Runtime.PyFunctionBase::EnterInvocationFrame(valuetype Lokad.Lython.Runtime.BoundFunctionArguments, class Lokad.Lython.LythonSourceSpan, bool)
				IL_0033: stloc.1
				IL_0034: ldloc.0
				IL_0035: brfalse.s IL_0077

				IL_0037: ldarg.2
				IL_0038: ldfld class Lokad.Lython.Frontend.ExecutableCodeObject Lokad.Lython.Runtime.LythonRuntime/ExecutableWorkState::Code
				IL_003d: callvirt instance valuetype Lokad.Lython.Frontend.ExecutableInstruction[] Lokad.Lython.Frontend.ExecutableCodeObject::get_Instructions()
				IL_0042: ldarg.2
				IL_0043: ldfld int32 Lokad.Lython.Runtime.LythonRuntime/ExecutableWorkState::InstructionIndex
				IL_0048: ldelema Lokad.Lython.Frontend.ExecutableInstruction
				IL_004d: stloc.2
				IL_004e: ldloc.1
				IL_004f: ldloc.0
				IL_0050: ldarg.2
				IL_0051: ldfld class Lokad.Lython.Frontend.ExecutableCodeObject Lokad.Lython.Runtime.LythonRuntime/ExecutableWorkState::Code
				IL_0056: callvirt instance class [System.Runtime]System.Collections.Generic.IReadOnlyList`1<class Lokad.Lython.Frontend.ExecutableCallSite> Lokad.Lython.Frontend.ExecutableCodeObject::get_CallSites()
				IL_005b: ldloc.2
				IL_005c: call instance int32 Lokad.Lython.Frontend.ExecutableInstruction::get_CallSiteIndex()
				IL_0061: callvirt instance !0 class [System.Runtime]System.Collections.Generic.IReadOnlyList`1<class Lokad.Lython.Frontend.ExecutableCallSite>::get_Item(int32)
				IL_0066: ldloc.2
				IL_0067: call instance int32 Lokad.Lython.Frontend.ExecutableInstruction::get_ResultSlot()
				IL_006c: ldloc.0
				IL_006d: ldfld class Lokad.Lython.Runtime.MemoryGovernor Lokad.Lython.Runtime.LythonRuntime/ExecutionContext::_boundStorageOwner
				IL_0072: callvirt instance void Lokad.Lython.Runtime.LythonRuntime/ExecutionContext::AdoptPreparedChild(class Lokad.Lython.Runtime.LythonRuntime/ExecutionContext, class Lokad.Lython.Frontend.ExecutableCallSite, int32, class Lokad.Lython.Runtime.MemoryGovernor)

				IL_0077: ldloc.1
				IL_0078: ldarg.2
				IL_0079: ldarg.s entryException
				IL_007b: callvirt instance void Lokad.Lython.Runtime.LythonRuntime/ExecutionContext::AdoptExecutableExecution(valuetype Lokad.Lython.Runtime.LythonRuntime/ExecutableWorkState&, class Lokad.Lython.Runtime.PyException)
				IL_0080: ldloc.1
				IL_0081: stloc.3
				IL_0082: leave.s IL_00a4
			} // end .try
			catch [System.Runtime]System.Object
			{
				IL_0084: pop
				IL_0085: ldloc.0
				IL_0086: brfalse.s IL_00a2
				.try
				{
					IL_0088: ldloc.0
					IL_0089: ldloc.0
					IL_008a: ldfld class Lokad.Lython.Runtime.MemoryGovernor Lokad.Lython.Runtime.LythonRuntime/ExecutionContext::_boundStorageOwner
					IL_008f: call void Lokad.Lython.Runtime.LythonRuntime/ExecutionContext::AbortPreparedCall(class Lokad.Lython.Runtime.LythonRuntime/ExecutionContext, class Lokad.Lython.Runtime.MemoryGovernor)
					IL_0094: leave.s IL_00a2
				} // end .try
				finally
				{
					IL_0096: ldarg.0
					IL_0097: callvirt instance class Lokad.Lython.Runtime.LythonRuntime/ExecutionContext Lokad.Lython.Runtime.PyExecutableFunction::get_DefinitionContext()
					IL_009c: callvirt instance void Lokad.Lython.Runtime.LythonRuntime/ExecutionContext::LeaveInterpreterFrame()
					IL_00a1: endfinally
				} // end handler

				IL_00a2: rethrow
			} // end handler

			IL_00a4: ldloc.3
			IL_00a5: ret
		} // end of method ExecutionContext::PromoteBorrowedInvocation
