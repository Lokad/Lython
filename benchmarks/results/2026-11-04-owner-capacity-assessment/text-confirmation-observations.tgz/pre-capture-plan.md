# B198 bounded refinement: no minimum capacity loan

Final-boundary41ab5b4a passes182 internal/179 public cases per actual runtime;
broader reservation selection yields1884PASS/229FAIL. Preserve all229 failures,
including initial-allocation, exact logical/root delta and next-callback fixtures.
No final qualification claim. The completed-source VM run is already owned and
will be joined and archived under its actual source, not relabeled.

Refine ONE sizing rule: amounts below4KiB are funded exactly; at and above4KiB,
round to the existing4KiB capacity. This avoids a minimum loan for small owners
and unnecessary migration of independent tiny-storage tests. No retry, mode,
option, tier/identity table or additional owner. One capacity invariant remains:
logical<=actual admitted. Large execution owners still reuse their funded tail.
Result-boundary unused-capacity release remains required for capture; cleanup
cannot round up. No exact-size retry after any refused substantial loan.

Restore prototype-only fixture migrations before rechecking the existing wider
reservation selection; preserve independently useful sequential result disposal.
Adapt only genuine substantial-capacity boundaries/actual requested reporting.
Source acceptance includes original cancellation/preflight/retention/cleanup,
small owner can use a1-byte allowance, substantial refusal has no exact retry,
retained/working estimates covered through release and result-boundary trimming.

If correctness passes, one short actual-refinement-source five-script/control
pair both APIs qualifies it separately. Keep all prior observations, mixed
controls and failures. No CPython rerun or new campaign/framework. If this needs
new lifecycle machinery, precisely defer instead of broadening the design.
