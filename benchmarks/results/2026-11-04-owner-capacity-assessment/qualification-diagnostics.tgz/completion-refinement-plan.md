# B198 loan lifetime completion before final source

Initial327b7976 finishes12 whole-script/control jobs with goldens/balances/gates/
joins,239.836s capture/240.445s service, allocation flat and several3–6% favorable
elapsed points. Preserve exact source and all mixed controls. ArchiveSHA
dd0ff83670656737349a6e351dd08f092338d03846607f6aa06ca68e5d3058c0.

Native/public focused checks uncover a real boundary interaction: a shared root
can be full of the execution's conservative capacity loan at failure, so a separate
captured-output projection can be denied. The retained-row test sees empty capture;
an independent trusted probe compiles against the same root and leaves a different
margin, so it still prints rows. Sequential result disposal alone does not fix the
test. Preserve failed run and diagnostic conditions; don't relax output assertions.

Complete the ownership contract with one explicit existing lifecycle boundary:
release the governor's UNUSED capacity at successful/failure result construction,
before the FIRST capture/projection admission. Keep all live logical storage funded.
This relinquishes the loan for future guest allocations after guest work, not the
stored data or any pending user. No retry of denied projection, optional-storage
recovery, new owner/scope class, policy flag or public option. Cleanup/refunds remain
available after terminal failure. If future internal projection work needs storage,
ordinary preflight can fund it; no enforcement mode is introduced.

A private ReleaseUnusedCapacity calls the existing capacity reconciliation with
CurrentAccountedBytes. Existing Release/ReleaseReserved must only SHRINK capacity:
min(current admitted, rounded remaining logical), because the result boundary may
leave an unrounded exact loan. No boolean phase flag or hysteresis. Current peak
still reports actual high-water capacity, first refusal remains unchanged.

Source criteria: original retained-row captured-output assertions pass on both APIs
with shared allowance; disposal also restores baseline. Main153 internal/177 public
families and actual11/10; original capture/probe failures retained. One short
completion-source pair (old B197/new/old, five complete scripts both APIs, same
existing protocol/control/allocation) qualifies actual final source separately.
No CPython campaign or full local run. If trimming needs a new lifetime framework
or loses pending-user funding, stop and withdraw rather than expand this milestone.
