using Lokad.Lython.Runtime;

namespace Lokad.Lython.Tests;

public sealed class MemoryGovernorCapacityTests
{
    [Fact]
    public void ResultBoundaryReturnsOnlyUnusedCapacityAndCleanupCannotGrowIt()
    {
        var budget = new LythonMemoryBudget(16384);
        using var owner = budget.CreateScope();
        var governor = new MemoryGovernor(owner);
        governor.Reserve(100, null);
        governor.Commit(80);
        Assert.True(budget.ReservedBytes > 100);

        governor.ReleaseUnusedCapacity();
        Assert.Equal(100, budget.ReservedBytes);
        governor.ReleaseReserved(20);
        Assert.InRange(budget.ReservedBytes, 80, 100);
        governor.Release(80);
        Assert.Equal(0, budget.ReservedBytes);
    }

    [Fact]
    public void RepeatedWorkingStorageReturnsFundingWithoutRefundingRetainedData()
    {
        const long retained = 100000;
        var budget = new LythonMemoryBudget(262144);
        using var owner = budget.CreateScope();
        var governor = new MemoryGovernor(owner);
        governor.Reserve(retained, null);
        governor.Commit(retained);
        var baseline = budget.ReservedBytes;
        for (var pass = 0; pass < 4; pass++)
        {
            using (governor.ReserveTemporary(retained, null))
            {
                Assert.True(budget.ReservedBytes >= 2 * retained);
                Assert.True(budget.ReservedBytes <= budget.LimitBytes);
            }
            Assert.Equal(retained, governor.CurrentCommittedBytes);
            Assert.Equal(0, governor.CurrentReservedBytes);
            Assert.Equal(baseline, budget.ReservedBytes);
        }
        governor.Release(retained);
        Assert.Equal(0, budget.ReservedBytes);
    }

    [Fact]
    public void LiveOwnerCanReuseFundingWhileAnotherOwnerFillsTheAllowance()
    {
        const long limit = 16384;
        var budget = new LythonMemoryBudget(limit);
        using var owner = budget.CreateScope();
        var governor = new MemoryGovernor(owner);
        Assert.Equal(0, budget.ReservedBytes);
        governor.Reserve(64, null);
        governor.Commit(64);
        var funded = budget.ReservedBytes;
        Assert.True(funded > 64);
        Assert.True(budget.TryReserve(limit - funded, out var other));
        using (other)
        {
            // This storage is already funded by the live owner, even though
            // the shared allowance has no room for another capacity loan.
            governor.Reserve(funded - 64, null);
            governor.Commit(funded - 64);
            Assert.Equal(funded, governor.CurrentCommittedBytes);
            Assert.Equal(limit, budget.ReservedBytes);
            var failure = Assert.Throws<LythonRuntimeException>(() => governor.Reserve(1, null));
            Assert.Equal(LythonFailureReason.SharedMemoryAllowance, failure.Attribution?.Reason);
            Assert.Same(failure, governor.AdmissionFailure);
            Assert.Equal(funded, governor.CurrentCommittedBytes);
            Assert.Equal(0, governor.CurrentReservedBytes);
            governor.Release(funded);
            Assert.Equal(limit - funded, budget.ReservedBytes);
            Assert.True(other.TryResize(limit));
        }
        Assert.Equal(0, budget.ReservedBytes);
    }

    [Fact]
    public void RefusedConservativeAdmissionDoesNotRetryTheLogicalSize()
    {
        var budget = new LythonMemoryBudget(1);
        using var owner = budget.CreateScope();
        var governor = new MemoryGovernor(owner);
        var span = new LythonSourceSpan(7, 2, 1, 3);
        var failure = Assert.Throws<LythonRuntimeException>(() => governor.Reserve(1, span));
        Assert.Equal(LythonFailureReason.SharedMemoryAllowance, failure.Attribution?.Reason);
        Assert.True(failure.Attribution?.Requested > 1);
        Assert.Equal(span, failure.Span);
        Assert.Equal(0, governor.CurrentAccountedBytes);
        Assert.Equal(0, budget.ReservedBytes);
        Assert.Same(failure, Assert.Throws<LythonRuntimeException>(() => governor.Reserve(1, null)));
        Assert.Equal(0, budget.ReservedBytes);
    }
}
