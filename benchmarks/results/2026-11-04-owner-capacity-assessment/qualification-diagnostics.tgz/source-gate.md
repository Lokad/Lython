# B198 cooperative owner-capacity admission source gate

Production ee2b4529 committed/pushed; delivery41771244039 running. B197 final
comparison and focused source are complete; do not repeat them or wait on CI.
B198 is source design only here, no prototype, no speedup claim.

Demonstrated: MemoryGovernor.Reserve calls its owned ILythonMemoryReservation's
TryResize for every positive logical increase; Release/ReleaseReserved do the same
on decreases. LythonMemoryBudget.Reservation.TryResize always takes the shared
State.Gate. The default scope tree already uses ONE flat root gate; do not invent
nested-lock overhead or a scope-tree rewrite. B191 report monitor-related chains
are about10.4% of samples, mixed/inlined attribution, not proof all are this gate.
Coarse storage/capacity ownership and bounded host-driven execution already exist.

Proposed bounded replacement: one governor-owned reservation retains conservatively
admitted capacity while its existing logical reserved/committed balances change.
Only capacity changes cross the borrowed root; no new budget/scope/reservation API,
no separate allowance/cap, no per-object identity tracking. Candidate fixed small
rounding headroom (e.g.4KiB) is FUNDING borrowed from the same root, never a hidden
standalone limit. Scope creation still reserves zero. Live logical storage must
always fit actual admitted capacity BEFORE allocation. Major released storage
returns allowance promptly; zero balance and owner end return all capacity. The
unused tail remains charged to that live owner, not refunded while aliases/users
remain. Do not retain a whole historical high-water mark or cumulative allocations.

Expected code removal/consolidation: three unconditional parent-resize funnels
become one capacity reconciliation invariant using the existing reservation; keep
rollback, commit/refund balances and TemporaryMemoryReservation's genuine storage
lifetime behavior. No hysteresis/pooling framework/configuration switches without
concrete evidence. If a useful design needs those, stop and precisely defer instead
of accumulating mechanisms. Integer constant prototypes remain withdrawn.

Required contract settlement BEFORE code:
- Extra conservative headroom can reject earlier; identical tiny-budget thresholds
  are not promised. A denied conservative request is terminal; NEVER retry exact
  bytes or skip headroom to recover. Preserve first span/reason and report actual
  requested/observed funding truthfully, not an invented logical request size.
- Peak/aggregate reporting must distinguish/fund actual admitted capacity from
  logical reserve/commit/refund balances. No uncharged tail, budget-owned guest
  storage or hidden default allowance. Standalone no-limit behavior stays unlimited.
- Reuse of already funded capacity is not a fresh host admission. Dynamic test hosts
  refusing the next request cannot imply every object must consult the host; retain
  their independent preallocation/mutation/refusal/cleanup assertions at a genuine
  admission boundary, without enforcing callback counts or relocating quotas.
- Public scope disposal invalidates reservations, and callers must already await
  users/serialize disposal. Check whether any supported Lython-owned early-disposal
  path relies on per-allocation parent validation; do not mask it with cached funding.
  Do not weaken pending-borrow/result/cache lifetime guarantees. Refused shrink or
  disposal must not make cached capacity pretend unfunded bytes are still owned.
- Checked rounding overflow is an actual representation constraint, not a new cap.
  Cleanup/refunds remain available after terminal refusal and are awaited; no GC.

Finish this gate with exact owner/release/reporting changes and one capacity
invariant, or precise deferral. This is not a general ownership audit. If selected,
focused tests cover two executions sharing one root, sequential baseline reuse,
funded retained results/caches/aliases and pending async users, construction overlap,
failed admission before allocation/mutation, cancellation and first-origin unwind.
Keep representative bounded CSV/text/JSON and report goldens. Use existing short
complete-script pair/unchanged controls; a diagnostic resize-call count is permitted
as evidence, never enforcement/fuel. Allocation, CPU/elapsed and root-headroom costs
are separate decisions. No fresh CPython campaign until a retained checkpoint.
