# B198 capacity admission candidate — before code

Source ee2b4529, delivery41771244039 live; B197 is committed, not fully qualified
yet. Do not repeat its comparisons or full tests. This candidate changes only the
existing MemoryGovernor admission granularity and associated current docs/tests.

Invariant: logical reserved+committed estimates <= capacity actually held by the
governor's existing root reservation. Reserve zero/construct scopes reserves zero.
Positive growth within already funded capacity needs no parent call. Crossing a
capacity boundary asks ONCE for rounded capacity before any allocation/mutation.
Use4KiB fixed estimate headroom, saturating only at the existing long representation
maximum. No exact-size retry, independent allowance, hidden default cap, tracing,
new scope/lease/cache type or options. Without a budget the existing default is
still unbounded. This is capacity funding, not execution fuel or allocation counts.

Release/refund rounds DOWN to the capacity needed for remaining live estimates;
substantial relinquished storage returns promptly and logical zero returns zero.
At most4095bytes unused tail per governor stays charged to that same owner until
the next shrink/owner end. There are only two production governor constructors:
compilation and shared execution state, not one governor per object/generator.
No sticky whole high-water reservation or cumulative allocation counter. Existing
program/execution/result/cache owners and awaited users remain unchanged.

Deletion/replacement: remove unconditional parent TryResize calls in Reserve,
Release and ReleaseReserved and the separate logical-peak update. One private
capacity reconciliation helper updates cached admitted capacity only after a
successful parent resize; peak reports actual funded capacity. Logical reserve/
commit/refund balances and real TemporaryMemoryReservation rollback/lifetimes stay.
If shrink is refused, keep actual cached funding, never pretend it was refunded;
explicit scope disposal still releases the reservation. Cleanup works after a
terminal failure. Growth refusal preserves old balances and first origin with
requested CAPACITY DELTA and observed owned capacity. Representation overflow
checks stay distinct from shared-budget failure; no new public APIs.

Intentional contract: some small allowances deny earlier due to capacity headroom.
Already funded storage does not ask the host for every object; refusing a future
request does not invalidate prior funding. Tiny exact thresholds/callback counts
are not guaranteed. Host parent disposal must already await users and serialize
with subtree operations, as ILythonMemoryScope states. Public reservation and
scope disposal semantics stay unchanged; live supported owners must not dispose
their governor's parent early. No new check loop or watchdog to detect invalid
caller disposal. Verify retained and pending users in existing acceptance cases.

Focused actual11/10 tests: governor invariant logical balances/rollback (adjust
their100-byte fixture to a useful shared allowance and assert funded balance remains
unchanged by invalid commits/releases), shared-budget parallel/sequential runs,
retained results/caches/aliases, terminal admission/unwind, cancellation, bounded
CSV/text/JSON and native working ownership. Preserve independent side effects and
unfunded-allocation assertions; do not relax timeouts/containment or merely hide
failures. Tests assuming the very next small logical change must call the host need
an actual capacity boundary, not new test-only enforcement/checkpoint counters.

One short existing complete five-script pair both APIs versus frozen B197, two
unchanged old roles, normal GC/tiering and ownership/hash/quiet/join checks; separate
allocation observations. Add a private diagnostic parent-resize tally if useful,
never production counters. ~4min/420s bound, no CPython campaign. Establish CPU/
elapsed and changed root capacity separately; no promise that B191's10.4% monitor
bucket is all removable. Retain, refine or withdraw with explicit contract/debt
decision; bounded confirmation only when evidence warrants it. Stop rather than
start a scope-tree redesign or broad ownership audit if this invariant is insufficient.
