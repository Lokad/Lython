from pathlib import Path
import hashlib,json,subprocess,tarfile
root=Path('/home/lokad/lython-bench-checks/text-prefix-b365-20261106');folder=root/'perf/text-warm'
r=json.loads((folder/'record.json').read_text())
assert r['exitCode']==0 and r['closed']['status']=='Closed'
assert (folder/'worker.stderr').stat().st_size==0
assert json.loads((root/'machine-before.json').read_text())['gate']['quiet']
assert json.loads((root/'machine-after.json').read_text())['gate']['quiet']
assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record'],capture_output=True).returncode==1
assert not list(Path('/dev/shm').glob('lython-comparison-files-*'))
code=(folder/'prefix-code.txt').read_text();assert 'ExecuteInstructionPrefix' in code and 'offset=' in code
with tarfile.open(root/'observations.tgz','w:gz') as a:
 for n in ['identity.json','catalog.json','pre-capture-plan.md','ops-profile.py','analyze-cpu-guest.py','archive.py','run.sh','machine-before.json','machine-after.json','started.utc']:a.add((root/n).resolve(),arcname=n)
 for p in sorted((root/'perf').rglob('*')):
  if p.is_file():a.add(p,arcname=str(p.relative_to(root)))
with tarfile.open(root/'observations.tgz') as a:assert json.loads(a.extractfile('perf/text-warm/record.json').read())['exitCode']==0
receipt=dict(complete=True,allWorkersJoined=True,guestFixturesRemoved=True,quietBeforeAndAfter=True,archivedAndVerifiedUnderLease=True,capturedSeconds=r['response']['elapsedTicks']/r['response']['clockFrequency'],archiveSHA256=hashlib.sha256((root/'observations.tgz').read_bytes()).hexdigest(),performanceQualified=False)
(root/'archive-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt))
