# Lokad.Lython 0.11.0

Updated 2026-11-06. Git-ignored; never force-add. Publication/tagging postponed.
Objective: coherent simplification and substantial complete-script performance.
One experiment, allocation reduction or delivery checkpoint does not complete it.

## Actual status

- **Committed/pushed:** runtime f2ce53db (R20 shared record keys); evidence and
  current guides1fdca591. Worktree clean. No active runtime prototype.
- **Local qualification:** focused735 internal/2,400 public and full ordinary
  Release4,274 internal/16,200 public per actual11/10, all pass. Explicit Release
  package installed consumers pass both; artifacts/nuget/ only, core zero runtime
  dependencies, optional adapter nonpackable. No unchanged local-suite rerun.
- **Delivery pending:** CI42294911136, head1fdca591, Windows/Ubuntu, actual11/10,
  original Stress and installed consumers. Last observed21:19UTC:both platforms
  ordinary11/10 and installed consumers pass; original Stress running21:28UTC.
  Space status checks minutes apart; keep independent work moving meanwhile.
- **Previous fully qualified:** b542b601 U04, GREEN42279409059; earlier b6650f09
  GREEN42258608463. Cached delivery-ci.json in their evidence; never query again.
- **Unresolved:** possible text regression after R20, coarse adverse CSV CPU,
  warm-text gap to CPython, startup/suspended-I/O/RSS/embedding-tail costs, and
  the precise producer capabilities below. None stops core development.

Historical plans/snapshots/raw handoffs: .git/agent-notes/review-20261031/;
full pre-condensation plan in record-layout-r20/PLAN-before-delivery-condense.md.
Immutable evidence under benchmarks/results/; index benchmarks/EXPERIMENTS.md.
docs/ describes current implementation only, without experimental narratives.

## Completed milestones and measurement decisions

- Shared compiler facts, direct UTF8 formatting/storage, native helper returns,
  R13C/R14 provenance, R17 text provenance and P01 number formats are delivered.
  Preserve K01/F02–F05/Q01/Q02/R02–R14, final call/local slots, executable imports/
  lambdas, immutable builtin metadata, native functions and genuine suspension.
- Native returns: allocation−19.92/−19.31% established, elapsed diagnostic.
  Formatting: allocation−8.67%; controlledB102 elapsed/CPU−5–8% supports retention.
  Original adverse15.125ms remains unexplained and preserved. Do not retime these
  completed questions or transfer their percentages to current HEAD.
- R17 retains allocation savings with measured text+1.6–2.2% debt. R18 shared
  targets withdrawn after two source pairs; mixed JSON/text/CSV results did not
  justify extra branches. B61/B69 call-arena/control slower designs remain lessons.
- U04 replaces match carriers/per-success arrays with caller spans; retained
  matches own ranges and copy groups on access, add regs. Direct cursor allocation
  −20.34% is separate from complete extraction warm−3.62–5.17%/fresh−4.58–6.40%.
  Fully qualified b542b601; no old API/stubs. Evidence2026-11-06-regex-capture-ownership.
- R19: current text/report CPU sample,14.41s guest. Prefix including inlined work
  20.64% text; ordinary calls/binding under2%; report JSON reading11.92%. These are
  leaf shares, not dispatch-only cost or predicted savings. No new capture planned.
- **R20 retained:** canonical keys/values split, shared JSON/CSV metadata, sets omit
  value storage. Delete coupled entries and separate sorted JSON hint/comparer/
  matched flags. Keep real protocol snapshots and namespace bridge. Existing owner
  funds frozen keys; rows fund independent actual values capacity. Delete/clear
  needs no metadata allocation; insert first admits private replacement. Preserve
  aliases, reentrant mutation and a real cancellation-after-admission correction.
  Conservative rejection/retained layouts/sparse scans are explicit tradeoffs.
  Complete-job allocation: CSV−12.73/−11.57%, JSON−14.99/−14.98%, report−9.43/−9.43%
  sync/async; text/scalar controls flat. Separate quiet B361: JSON warm−10.89–12.53%,
  report warm−5.36–8.80%/fresh−8.53–10.52%. CSV elapsed−1.22–2.46%, CPU adverse.
  Text B361+5.01/−0.53% with5.28% identical-build spread; B362 confirmation+0.90/
  −1.21%, then+2.73/+5.53%, CPU adverse in second block. **Possible text regression
  is accepted debt**, not parity or an all-workload speedup. Retain for coherent
  record/storage gains; prioritize text next. No more retiming scheduled for R20.
  Evidence2026-11-06-record-layout includes every failure/partial/adverse condition.
  B359–B362 terminal; never query their services again.

Primary external baseline remains B352/b6650f09, compile/warm/fresh separated:
fresh CSV1.31x,text1.75–1.83x,JSON1.12x,report1.44–1.46x,config1.21–1.22x CPython.
It does not describe today's HEAD. R20 selected current blocks show JSON warm
1.06–1.08x, report warm1.34–1.39x/fresh1.32–1.34x, CSV warm1.29–1.31x; confirmed
text remains about1.8–1.9x. Include mediated RAM I/O, validation/prior-result cleanup;
exclude startup/staging/final teardown. Never subtract independent medians.

## Priority 1 — R21 complete text aggregation / operand path

Hypothesis: repeated operand publication/resolution and native proof/evaluation
work can be eliminated across complete scripts. R20's possible ordinary-container
cost belongs in this assessment. Ordinary call/binding under2% does not justify
another argument-array tweak or a universal tagged value based only on boxing.

Source gate now active, before any new runtime prototype. Actual source findings:
record-layout-r20/R21-source-map.md under the private historical root above.
Current compile-only census under text-operands-r21/ reuses the old census tool:
text module85instructions, fourteen ordinary instructions in its word loop;
words_from_line already native (three nodes). Existing flat storage/forwarding/
direct targets leave no justified duplicate-frame/input-packet rewrite. The mixed
prefix20.64% share cannot choose between dispatch and inlined work. One R21
text-only diagnostic capture with JIT code bytes/offsets is justified to resolve
that attribution, not an unchanged R19 replay or timing comparison. Reuse owned
profile protocol, six-second warmup/about seven-second capture, explicit overrides,
quiet/goldens/joins/cleanup/under-lease archive; no production instrumentation.
Stop with a block-level hotspot map and concrete removed-work design, or record
unresolved attribution without automatically launching another capture.
1. Inspect counts.get/update, instruction prefix, native guards/evaluation and
   local publication together against existing R19 samples. Locals/temporaries
   already share a backing; direct arguments, receiver separation, ForwardValues
   and deferred contexts already exist. Do not rediscover them as new designs.
2. Identify one coherent eliminated-work/storage boundary and displaced code.
   General operand forwarding must capture evaluated values before admission or
   callbacks can rebind them; a live argument view is not a free replacement.
   Native proofs precede effects; do not reuse guarded reads after admission or
   add shape scratch/another backend that erases the measured native benefit.
3. Stop this gate after a concrete representation/lifetime design plus semantic
   mapping, or document why it is unjustified and select another evidenced
   candidate. No broad new profiling/audit campaign or speculative fusion series.

Selected implementation acceptance: preserve binding/defaults/keywords, closures,
classes/generators, lookup/evaluation order, late mutation, first refusal, actual
suspension, cooperative cancellation and funded aliases through awaited cleanup.
Remove displaced representations/dispatch; complete canonical migration before
delivery. Focused regressions, then one bounded complete text/report source pair
with ordinary controls and separate allocation diagnostics. Decide remaining debt
at its explicit completion milestone; no indefinite half-migrated mode.

Remaining redesign candidates, select from evidence rather than cycling tweaks:
- Per-record construction: R20 closes the concrete metadata boundary. Historical
  bulk CSV6–8% is not vetoed by its old threshold; field bulk admission/row transfer
  already exist. Require a new remaining builder/copy before another prototype.
- Text/JSON: UTF8 storage, direct tokens, one-pass casing and bulk whitespace are
  delivered. Require an actual remaining conversion/ownership boundary to remove.
- Call/frame/scalars: preserve final slots/native helpers. R16 exposes broad exact
  promotion/hash/identity/projection costs; do not add a second scalar convention.
- Frontend: shared lexical facts are delivered; current compile44–72us alone is
  not dominant. Remove a real duplicate pass/representation and compare fresh
  complete scripts before investing in heavier compilation.

## Independent regex track

Core Python-specific UTF8/byte-range/scalar-window/flags/ownership/cancellation
work does not wait for a release. U04 works with normal0.4 and private immutable
dev44 bridge. The latter qualifies native high-water working admission and256KiB
bounded matching; prior peak32,880→2,064B, allocation+128B/cursor, diagnostic
elapsed+9.1% remain separate evidence. Normal0.4 pin remains unchanged.

Final adapter capabilities still missing: DetailedData cannot choose Prepare's
independent working owner; keep conservative one-shot preflight. Native UTF8
lookup cannot enumerate names; keep adapter-local name conversion. Creation-token
coupling needs per-operation forwarding through actual work. Normal0.4 reversed
windows fail explicitly. Development producers/adapter-local bridges are allowed;
qualify the final immutable released package and managed-safety compliance when
available. No core dependency/type edges, dialect fallback, quotas or sibling edits.

## Working/measurement contract

Unstable controls, timeouts and inconclusive data establish uncertainty, not a
failed design. Allow bounded justified confirmation/refinement/correction; retain
original conditions and adverse data. Percentages inform decisions, not automatic
vetoes/permanent closures. Distinguish simplification, allocation, elapsed and CPU.
Refresh representative CPython at coherent checkpoints, separating compile/warm/
fresh and explicit I/O/cleanup; no another framework or10min development lanes.

Follow AGENTS.md: fully managed/memory-safe; no unsafe/Unsafe/pointers/PInvoke/native
stack probing. Preserve managed stack/recursion, host mediation/contained paths,
cycles, host CancellationToken and borrowed shared admission/capacity/replacement/
escaping aliases. First refusal fails the command, no retry/recovery. No fuel,
quotas, hidden caps/default allowance, tracing, weak reclamation or forced GC.
Await all users/cleanup. Initial streaming uses bounded host executions; XML depth
constraint remains. Never fund a still-retained alias by refunding its owner.

Focused Release iteration; no overlapping local builds/tests. Nonincremental build
after timestamp-preserving restore. Batch platform/actual11/10/original Stress/
installed consumers at coherent boundaries; don't repeat completed qualification.
Quiet VM lokad@20.166.121.73,key~/.ssh/id_lython-bench.pem: owned lease, actual Ready
hashes, manifest IDs/quiet/goldens/funding/joins and verified persistent archives.
No SSH during capture. Disk near full: verify real headroom and retire only exact
redundant copies with independent backups, ended users and dependency checks.
Keep executing after a delivery/experiment; publication/tagging remain postponed.
