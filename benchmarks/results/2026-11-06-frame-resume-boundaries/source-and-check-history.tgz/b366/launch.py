from pathlib import Path
import fcntl,hashlib,io,json,os,shutil,stat,subprocess,sys,tarfile
base=Path('/home/lokad/lython-bench-checks');root=Path('/home/lokad/lython-bench-checks/resume-boundary-b366-20261106');prior=Path('/home/lokad/lython-bench-checks/record-layout-b361-20261106');retired=base/'text-prefix-b365-20261106';perf=retired/'perf'
with (base/'comparison-vm.lock').open('a') as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert not root.exists() and not list(Path('/dev/shm').glob('lython-comparison-files-*'))
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record'],capture_output=True).returncode==1
 assert hashlib.sha256((retired/'recovered-observations.tgz').read_bytes()).hexdigest()=='d58279a660bbece6edc5d3ee7ea0b8794d4f7a20b30f55396a2880a1172edbbd'
 assert perf.resolve().is_relative_to(base) and not perf.is_symlink()
 assert not [p for p in base.rglob('*') if p.is_symlink() and p.resolve().is_relative_to(perf)]
 files=[]
 with tarfile.open(retired/'recovered-observations.tgz') as a:
  for m in a.getmembers():
   if m.isfile() and m.name.startswith('perf/'):
    p=retired/m.name;assert p.resolve().is_relative_to(perf) and not p.is_symlink() and p.stat().st_nlink==1
    assert p.read_bytes()==a.extractfile(m).read();files.append(p)
 assert {p for p in perf.rglob('*') if p.is_file()}==set(files)
 pipes=set(perf.rglob('*'))-set(files)-{p for p in perf.rglob('*') if p.is_dir()}
 assert pipes=={perf/'text-warm'/n for n in ['control','ack']} and all(stat.S_ISFIFO(p.lstat().st_mode) for p in pipes)
 for p in files+list(pipes):p.unlink()
 for p in sorted(perf.rglob('*'),key=lambda p:len(p.parts),reverse=True):p.rmdir()
 perf.rmdir()
 payload=sys.stdin.buffer.read(1903995+1);assert len(payload)==1903995 and hashlib.sha256(payload).hexdigest()=='1e91885e4b8ee94bce592130cb06f24a5ac6f9018acb6ba1fdee10ba9d3dd2f1'
 with tarfile.open(fileobj=io.BytesIO(payload),mode='r:gz') as a:
  assert shutil.disk_usage(base).free>sum(((m.size+4095)//4096)*4096 for m in a.getmembers())+128*1024+6*1024*1024
  root.mkdir();a.extractall(root,filter='data')
 for n in ['representative.json','cpython-worker.py']:(root/n).symlink_to(prior/n)
 (root/'reference').symlink_to(prior/'candidate',target_is_directory=True)
 folder=root/'candidate';folder.mkdir()
 for p in (prior/'candidate').iterdir():
  if p.suffix=='.pdb':continue
  if p.name in ['Lokad.Lython.Benchmarks.dll','Lokad.Lython.Benchmarks.deps.json','Lokad.Lython.Benchmarks.runtimeconfig.json']:os.link(p,folder/p.name)
  else:(folder/p.name).symlink_to(root/p.name if p.name=='Lokad.Lython.dll' else p.resolve(),target_is_directory=p.is_dir())
 i=json.loads((root/'identity.json').read_text());cases={c['id'] for c in json.loads((root/'representative.json').read_text())['cases']}
 assert all(c in cases for c in ['scripts.text-summary-helpers.large','scripts.report-render.large','scripts.csv-summary-functions.large','scripts.json-summary-helpers.large'])
 for role in ['candidate','reference']:
  assert hashlib.sha256((root/role/'Lokad.Lython.dll').read_bytes()).hexdigest()==i['coreSHA256'][role]
  for n,digest in i['auxiliaryFiles'].items():assert hashlib.sha256((root/role/n).read_bytes()).hexdigest()==digest
 for n in ['collect.py','archive-owned.py']:compile((root/n).read_text(),str(root/n),'exec')
 subprocess.run(['/bin/sh','-n',str(root/'run.sh')],check=True)
 assert shutil.disk_usage(base).free>6*1024*1024
 print(json.dumps(dict(freeBytes=shutil.disk_usage(base).free,retiredVerifiedExpandedProfileFiles=len(files),independentLocalAndRemoteRawArchivesPreserved=True)),flush=True)
subprocess.run(['sudo','-n','systemd-run','--unit=lython-b366-resume-boundary-20261106','--property=User=lokad','--property=WorkingDirectory='+str(root),'--property=RuntimeMaxSec=170','--property=TimeoutStopSec=30','--property=KillMode=control-group','/bin/sh',str(root/'run.sh')],check=True)
