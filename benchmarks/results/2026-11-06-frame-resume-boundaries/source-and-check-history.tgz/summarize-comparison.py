from pathlib import Path
import json,statistics
root=Path(__file__).resolve().parent;median=statistics.median
r=json.loads((root/'b366/retrieved/confirmation/confirmation.json').read_text(encoding='utf-8'));rows=[]
for j in r['jobs']:
 elapsed={};cpu={};iqr={}
 for role in ['candidate','control','reference']:
  samples=[s for s in j['samples'] if s['engine']==role]
  times=[s['response']['elapsedTicks']/s['response']['clockFrequency']/s['response']['completedInvocations'] for s in samples]
  elapsed[role]=median(times);q=statistics.quantiles(times,n=4,method='inclusive');iqr[role]=100*(q[2]-q[0])/median(times)
  cpu[role]=median(s['externalProcessCpuTicks']/s['externalCpuFrequency']/s['response']['completedInvocations'] for s in samples)
 row=dict(case=j['case'],lane=j['lane'],elapsedMilliseconds={k:v*1000 for k,v in elapsed.items()},processCpuMilliseconds={k:v*1000 for k,v in cpu.items()},iqrPercent=iqr,currentRoleDifferencePercent=100*abs(elapsed['control']-elapsed['candidate'])/elapsed['candidate'],candidateChangePercent={k:100*(elapsed[k]/elapsed['reference']-1) for k in ['candidate','control']})
 rows.append(row);print(json.dumps(row),flush=True)
(root/'comparison-summary.json').write_text(json.dumps(dict(rows=rows,complete=r['complete'],elapsedSeconds=r['elapsedSeconds']),indent=2)+'\n',encoding='utf-8')
a=json.loads((root/'allocation/sync/measurements.json').read_text(encoding='utf-8'));alloc=[]
for c in a['observations']:
 medians={role:median(s['allocatedBytes']/s['jobs'] for s in c['samples'] if s['image']==role) for role in ['before','candidate','before-control']}
 alloc.append(dict(case=c['caseId'],allocatedBytesPerJob=medians,candidateChangePercent=100*(medians['candidate']/medians['before']-1),admittedPeaks=c['admittedPeaks']))
(root/'allocation-summary.json').write_text(json.dumps(dict(api='sync',rows=alloc,allGoldensPassed=a['allGoldensPassed'],allBalancesZero=a['allBalancesZero'],ownedFixturesRemoved=a['ownedFixturesRemoved']),indent=2)+'\n',encoding='utf-8')
print('Allocation:',[(x['case'],round(x['candidateChangePercent'],3)) for x in alloc],flush=True)
