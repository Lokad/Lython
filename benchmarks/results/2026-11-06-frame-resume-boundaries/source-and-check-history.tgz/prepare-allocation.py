from pathlib import Path
home=Path(__file__).resolve().parent
s=(home.parent/'record-layout-r20/measure-allocation.py').read_text(encoding='utf-8').replace("for api in ['sync','async']:","for api in ['sync']:")
(home/'measure-allocation.py').write_text(s,encoding='utf-8')
exec(compile(s,str(home/'measure-allocation.py'),'exec'),{'__file__':str(home/'measure-allocation.py'),'__name__':'__main__'})
