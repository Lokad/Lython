from pathlib import Path
import fcntl,hashlib,io,json,os,shutil,subprocess,sys,tarfile
base=Path('/home/lokad/lython-bench-checks');root=Path('/home/lokad/lython-bench-checks/text-prefix-b364-20261106');old=Path('/home/lokad/lython-bench-checks/text-prefix-b363-20261106')
with (base/'comparison-vm.lock').open('a') as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert (old/'exit-code.txt').read_text().strip()=='1' and not root.exists()
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record'],capture_output=True).returncode==1
 assert not list(Path('/dev/shm').glob('lython-comparison-files-*'))
 r=json.loads((old/'perf/text-warm/record.json').read_text());pid=r['identity']['processId'];assert not Path('/proc/'+str(pid)).exists()
 for prefix in ['perf','perfinfo']:
  p=Path('/tmp')/(prefix+'-'+str(pid)+'.map')
  if p.exists():
   assert not p.is_symlink() and p.stat().st_uid==os.getuid()
   target=old/'perf/text-warm'/(prefix+'.map');shutil.copyfile(p,target)
   assert target.read_bytes()==p.read_bytes();p.unlink()
 (old/'terminal-journal.txt').write_text(subprocess.check_output(['journalctl','--unit=lython-b363-text-prefix-20261106','--no-pager'],text=True))
 with tarfile.open(old/'failed-observations.tgz','w:gz') as a:
  for n in ['identity.json','ops-profile.py','archive.py','run.sh','machine-before.json','exit-code.txt','started.utc','stopped.utc','terminal-journal.txt']:a.add(old/n,arcname=n)
  for p in (old/'perf').rglob('*'):
   if p.is_file():a.add(p,arcname=str(p.relative_to(old)))
 retired=None
 if shutil.disk_usage(base).free<13*1024*1024:
  p=base/'activation-storage-b170-20261103/payload.tgz'
  assert p.resolve()==p and p.parent.parent==base and not p.is_symlink() and p.stat().st_nlink==1
  assert not [q for q in base.rglob('*') if q.is_symlink() and q.resolve()==p]
  assert subprocess.run(['fuser',str(p)],capture_output=True).returncode==1
  assert hashlib.sha256(p.read_bytes()).hexdigest()=='ca21553beb1ebb2b40d30ecd68e5c537ffcc4e1b7ae79ea95b3a081b276a28af'
  retired=dict(file=str(p),bytes=p.stat().st_size,independentLocalBackupSHA256='ca21553beb1ebb2b40d30ecd68e5c537ffcc4e1b7ae79ea95b3a081b276a28af');p.unlink()
 payload=sys.stdin.buffer.read(11535+1);assert len(payload)==11535 and hashlib.sha256(payload).hexdigest()=='7a2f3a5786fea4684b5d6f6fc6655d992427ed86e1d601884d1ade1da83d9510'
 with tarfile.open(fileobj=io.BytesIO(payload),mode='r:gz') as a:
  assert shutil.disk_usage(base).free>sum(m.size for m in a.getmembers())+10*1024*1024
  root.mkdir();a.extractall(root,filter='data')
 (root/'candidate').symlink_to(old/'candidate',target_is_directory=True);(root/'catalog.json').symlink_to(old/'catalog.json')
 for n in ['ops-profile.py','archive.py','analyze-cpu-guest.py']:compile((root/n).read_text(),str(root/n),'exec')
 print(json.dumps(dict(freeBytes=shutil.disk_usage(base).free,retiredRedundantUpload=retired,failedArchiveSHA256=hashlib.sha256((old/'failed-observations.tgz').read_bytes()).hexdigest())),flush=True)
