from pathlib import Path
import hashlib,json,shutil,subprocess,tarfile
home=Path(__file__).resolve().parent;root=home/'b366';root.mkdir()
old=home.parent/'record-layout-r20/b361';prior='/home/lokad/lython-bench-checks/record-layout-b361-20261106';remote='/home/lokad/lython-bench-checks/resume-boundary-b366-20261106'
def write(n,s):
 with (root/n).open('w',encoding='utf-8',newline='\n') as f:f.write(s)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
core=Path('src/Lokad.Lython/bin/Release/net11.0/Lokad.Lython.dll');checks=json.loads((home/'focused-results.json').read_text(encoding='utf-8'))
assert sha(core)==checks['checks']['net11.0']['coreSHA256']
identity=json.loads((home.parent/'record-layout-r20/b359/identity.json').read_text(encoding='utf-8'))
identity.update(sourceRevision='90a00002 plus R21 pending-error/return boundary simplification',referenceSourceRevision='f2ce53db qualified runtime, frozen R20 core67f84196',purpose='R21 three-role source pair; complete text warm/fresh, report/CSV warm and JSON compile control; not a new CPython baseline',qualification=checks)
identity['coreSHA256']=dict(candidate=sha(core),control=sha(core),reference='67f841962f56ef0df5a1bbcfe78a0f4d60259bb5d17b6490508f32bde80992f6')
identity['sourceSHA256']={str(p).replace('\\','/'):sha(p) for p in Path('src/Lokad.Lython').rglob('*.cs') if not {'bin','obj'}.intersection(p.parts)}
write('identity.json',json.dumps(identity,indent=2)+'\n');shutil.copyfile(core,root/'Lokad.Lython.dll')
shutil.copyfile('PLAN.md',root/'pre-measurement-plan.md')
(root/'source.patch').write_bytes(subprocess.check_output(['git','-c','core.safecrlf=false','diff','--','src']))
write('contract.md','''R21 removes repeated pending-exception/return polling, with existing guards and cleanup retained. No new dispatcher/state wrapper/configuration. Three independent checked roles: reference,current,identical current. Normal GC/tiering, unchanged b94 worker/host/catalog, five-second warmup and seven rotated150ms batches. Text warm/fresh, report/CSV warm, unaffected JSON compile control; all catalog IDs checked. Warm includes mediated RAM I/O, full validation and prior-result cleanup; fresh also compile/program disposal. Startup/staging/final teardown excluded.170sowner+30sstop,130sjob-start guard; no SSH until200s after launch. Keep every adverse result/failed condition. No CPython/CPU-allocation inference. Stop after this source pair and decide retention/debt; bounded correction only for a concrete observation, no fixed-percent veto.\n''')
write('setup-contract.json',json.dumps(dict(reference=prior+'/candidate',roles=['candidate','reference','control'],ownerSeconds=170,stopSeconds=30,observeAfterSeconds=200,unaffectedControl='scripts.json-summary-helpers.large compile'),indent=2)+'\n')
for n in ['collect.py','archive-owned.py','run.sh']:
 s=(old/n).read_text(encoding='utf-8').replace(prior,remote)
 if n=='collect.py':
  a=s.index('jobs=[');b=s.index('\nenv =',a)
  s=s[:a]+"jobs=[('scripts.text-summary-helpers.large','warm'),('scripts.text-summary-helpers.large','compile-run'),('scripts.report-render.large','warm'),('scripts.csv-summary-functions.large','warm'),('scripts.json-summary-helpers.large','compile')]\nassert len(jobs)==5 and all(case in cases for case,lane in jobs)\n"+s[b:]
  s=s.replace("labels=['CPython','candidate','reference','control']","labels=['candidate','reference','control']").replace('< 175','< 130')
  a=s.index("purpose='")+len("purpose='");b=s.index("',",a);s=s[:a]+identity['purpose']+s[b:]
 write(n,s)
with tarfile.open(root/'payload.tgz','w:gz') as a:
 for n in ['Lokad.Lython.dll','identity.json','pre-measurement-plan.md','source.patch','contract.md','setup-contract.json','collect.py','archive-owned.py','run.sh']:a.add(root/n,arcname=n)
data=(root/'payload.tgz').read_bytes()
receipt=json.loads((home/'b365/recovery-receipt.json').read_text(encoding='utf-8'))
assert sha(home/'b365/recovered-observations.tgz')==receipt['archiveSHA256']
script=r'''from pathlib import Path
import fcntl,hashlib,io,json,os,shutil,stat,subprocess,sys,tarfile
base=Path('/home/lokad/lython-bench-checks');root=Path('REMOTE');prior=Path('PRIOR');retired=base/'text-prefix-b365-20261106';perf=retired/'perf'
with (base/'comparison-vm.lock').open('a') as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert not root.exists() and not list(Path('/dev/shm').glob('lython-comparison-files-*'))
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record'],capture_output=True).returncode==1
 assert hashlib.sha256((retired/'recovered-observations.tgz').read_bytes()).hexdigest()=='ARCHIVEHASH'
 assert perf.resolve().is_relative_to(base) and not perf.is_symlink()
 assert not [p for p in base.rglob('*') if p.is_symlink() and p.resolve().is_relative_to(perf)]
 files=[]
 with tarfile.open(retired/'recovered-observations.tgz') as a:
  for m in a.getmembers():
   if m.isfile() and m.name.startswith('perf/'):
    p=retired/m.name;assert p.resolve().is_relative_to(perf) and not p.is_symlink() and p.stat().st_nlink==1
    assert p.read_bytes()==a.extractfile(m).read();files.append(p)
 assert {p for p in perf.rglob('*') if p.is_file()}==set(files)
 pipes=set(perf.rglob('*'))-set(files)-{p for p in perf.rglob('*') if p.is_dir()}
 assert pipes=={perf/'text-warm'/n for n in ['control','ack']} and all(stat.S_ISFIFO(p.lstat().st_mode) for p in pipes)
 for p in files+list(pipes):p.unlink()
 for p in sorted(perf.rglob('*'),key=lambda p:len(p.parts),reverse=True):p.rmdir()
 perf.rmdir()
 payload=sys.stdin.buffer.read(PAYLOADBYTES+1);assert len(payload)==PAYLOADBYTES and hashlib.sha256(payload).hexdigest()=='PAYLOADHASH'
 with tarfile.open(fileobj=io.BytesIO(payload),mode='r:gz') as a:
  assert shutil.disk_usage(base).free>sum(((m.size+4095)//4096)*4096 for m in a.getmembers())+128*1024+6*1024*1024
  root.mkdir();a.extractall(root,filter='data')
 for n in ['representative.json','cpython-worker.py']:(root/n).symlink_to(prior/n)
 (root/'reference').symlink_to(prior/'candidate',target_is_directory=True)
 folder=root/'candidate';folder.mkdir()
 for p in (prior/'candidate').iterdir():
  if p.suffix=='.pdb':continue
  if p.name in ['Lokad.Lython.Benchmarks.dll','Lokad.Lython.Benchmarks.deps.json','Lokad.Lython.Benchmarks.runtimeconfig.json']:os.link(p,folder/p.name)
  else:(folder/p.name).symlink_to(root/p.name if p.name=='Lokad.Lython.dll' else p.resolve(),target_is_directory=p.is_dir())
 i=json.loads((root/'identity.json').read_text());cases={c['id'] for c in json.loads((root/'representative.json').read_text())['cases']}
 assert all(c in cases for c in ['scripts.text-summary-helpers.large','scripts.report-render.large','scripts.csv-summary-functions.large','scripts.json-summary-helpers.large'])
 for role in ['candidate','reference']:
  assert hashlib.sha256((root/role/'Lokad.Lython.dll').read_bytes()).hexdigest()==i['coreSHA256'][role]
  for n,digest in i['auxiliaryFiles'].items():assert hashlib.sha256((root/role/n).read_bytes()).hexdigest()==digest
 for n in ['collect.py','archive-owned.py']:compile((root/n).read_text(),str(root/n),'exec')
 subprocess.run(['/bin/sh','-n',str(root/'run.sh')],check=True)
 assert shutil.disk_usage(base).free>6*1024*1024
 print(json.dumps(dict(freeBytes=shutil.disk_usage(base).free,retiredVerifiedExpandedProfileFiles=len(files),independentLocalAndRemoteRawArchivesPreserved=True)),flush=True)
subprocess.run(['sudo','-n','systemd-run','--unit=lython-b366-resume-boundary-20261106','--property=User=lokad','--property=WorkingDirectory='+str(root),'--property=RuntimeMaxSec=170','--property=TimeoutStopSec=30','--property=KillMode=control-group','/bin/sh',str(root/'run.sh')],check=True)
'''.replace('REMOTE',remote).replace('PRIOR',prior).replace('ARCHIVEHASH',receipt['archiveSHA256']).replace('PAYLOADBYTES',str(len(data))).replace('PAYLOADHASH',hashlib.sha256(data).hexdigest())
write('launch.py',script)
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15']
r=subprocess.run(['C:/Windows/System32/OpenSSH/scp.exe',*ssh[1:],str(root/'launch.py'),'lokad@20.166.121.73:/home/lokad/lython-bench-checks/b366-launch.py'],capture_output=True);assert r.returncode==0,r.stderr
r=subprocess.run([*ssh,'lokad@20.166.121.73','python3 /home/lokad/lython-bench-checks/b366-launch.py'],input=data,capture_output=True)
(root/'launch.log').write_bytes(r.stdout+r.stderr);assert r.returncode==0,(r.stdout+r.stderr).decode('utf-8');print((r.stdout+r.stderr).decode('utf-8'),flush=True)
