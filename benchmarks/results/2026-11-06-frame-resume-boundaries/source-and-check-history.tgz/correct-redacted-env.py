from pathlib import Path
import hashlib,json,subprocess,tarfile
home=Path(__file__).resolve().parent;old=home/'b364';root=home/'b365';root.mkdir()
prior='/home/lokad/lython-bench-checks/text-prefix-b364-20261106';remote=prior.replace('b364','b365')
for n in ['identity.json','pre-capture-plan.md','analyze-cpu-guest.py','archive.py','run.sh','ops-profile.py']:
 s=(old/n).read_text(encoding='utf-8').replace(prior,remote)
 if n=='ops-profile.py':s=s.replace("assert all(not v or k in allowed and v==env.get(k) for k,v in record['identity']['runtimeOverrides'].items())","assert all(not v or k in allowed and env.get(k) and v in ('<present>',env[k]) for k,v in record['identity']['runtimeOverrides'].items())")
 with (root/n).open('w',encoding='utf-8',newline='\n') as f:f.write(s)
# Validate against the actual frozen worker's Ready representation before another
# owner starts; unknown nonempty overrides still fail. Exact launch values remain
# separately recorded by the collector, without relying on a redacted echo.
r=json.loads((old/'failed-record.json').read_text(encoding='utf-8'))
allowed={'DOTNET_PerfMapEnabled','DOTNET_JitDisasm','DOTNET_JitDisasmWithCodeBytes','DOTNET_JitDisasmWithAddress','DOTNET_JitStdOutFile'}
assert all(not v or k in allowed and r['diagnosticOverrides'].get(k) and v in ('<present>',r['diagnosticOverrides'][k]) for k,v in r['identity']['runtimeOverrides'].items())
with tarfile.open(root/'payload.tgz','w:gz') as a:
 for n in ['identity.json','pre-capture-plan.md','analyze-cpu-guest.py','archive.py','run.sh','ops-profile.py']:a.add(root/n,arcname=n)
data=(root/'payload.tgz').read_bytes()
script=r'''from pathlib import Path
import fcntl,hashlib,io,json,os,shutil,subprocess,sys,tarfile
base=Path('/home/lokad/lython-bench-checks');root=Path('REMOTE');old=Path('PRIOR')
with (base/'comparison-vm.lock').open('a') as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert (old/'exit-code.txt').read_text().strip()=='1' and not root.exists()
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record'],capture_output=True).returncode==1
 assert not list(Path('/dev/shm').glob('lython-comparison-files-*'))
 r=json.loads((old/'perf/text-warm/record.json').read_text());pid=r['identity']['processId'];assert not Path('/proc/'+str(pid)).exists()
 assert 'response' not in r and r['verificationBefore']['status']=='Equivalent'
 for prefix in ['perf','perfinfo']:
  p=Path('/tmp')/(prefix+'-'+str(pid)+'.map')
  if p.exists():
   assert not p.is_symlink() and p.stat().st_uid==os.getuid()
   target=old/'perf/text-warm'/(prefix+'.map');shutil.copyfile(p,target)
   assert target.read_bytes()==p.read_bytes();p.unlink()
 (old/'terminal-journal.txt').write_text(subprocess.check_output(['journalctl','--unit=lython-b364-text-prefix-20261106','--no-pager'],text=True))
 with tarfile.open(old/'failed-observations.tgz','w:gz') as a:
  for n in ['identity.json','ops-profile.py','archive.py','run.sh','machine-before.json','exit-code.txt','started.utc','stopped.utc','terminal-journal.txt']:a.add(old/n,arcname=n)
  for p in (old/'perf').rglob('*'):
   if p.is_file():a.add(p,arcname=str(p.relative_to(old)))
 payload=sys.stdin.buffer.read(PAYLOADBYTES+1);assert len(payload)==PAYLOADBYTES and hashlib.sha256(payload).hexdigest()=='PAYLOADHASH'
 with tarfile.open(fileobj=io.BytesIO(payload),mode='r:gz') as a:
  assert shutil.disk_usage(base).free>sum(m.size for m in a.getmembers())+10*1024*1024
  root.mkdir();a.extractall(root,filter='data')
 (root/'candidate').symlink_to(old/'candidate',target_is_directory=True);(root/'catalog.json').symlink_to(old/'catalog.json')
 for n in ['ops-profile.py','archive.py','analyze-cpu-guest.py']:compile((root/n).read_text(),str(root/n),'exec')
 print(json.dumps(dict(freeBytes=shutil.disk_usage(base).free,frozenRedactedIdentityValidated=True,failedArchiveSHA256=hashlib.sha256((old/'failed-observations.tgz').read_bytes()).hexdigest())),flush=True)
'''.replace('REMOTE',remote).replace('PRIOR',prior).replace('PAYLOADBYTES',str(len(data))).replace('PAYLOADHASH',hashlib.sha256(data).hexdigest())
(root/'prepare.py').write_text(script,encoding='utf-8')
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15']
scp=['C:/Windows/System32/OpenSSH/scp.exe',*ssh[1:]]
r=subprocess.run([*scp,str(root/'prepare.py'),'lokad@20.166.121.73:/home/lokad/lython-bench-checks/b365-prepare.py'],capture_output=True);assert r.returncode==0,r.stderr
r=subprocess.run([*ssh,'lokad@20.166.121.73','python3 /home/lokad/lython-bench-checks/b365-prepare.py'],input=data,capture_output=True)
(root/'prepare.log').write_bytes(r.stdout+r.stderr);assert r.returncode==0,(r.stdout+r.stderr).decode('utf-8')
print((r.stdout+r.stderr).decode('utf-8'),flush=True)
r=subprocess.run([*scp,'lokad@20.166.121.73:'+prior+'/failed-observations.tgz',str(old/'failed-observations.tgz')],capture_output=True);assert r.returncode==0,r.stderr
with tarfile.open(old/'failed-observations.tgz') as a:a.extractall(old/'failed-retrieved',filter='data')
r=subprocess.run([*ssh,'lokad@20.166.121.73','sudo -n systemd-run --unit=lython-b365-text-prefix-20261106 --property=User=lokad --property=WorkingDirectory='+remote+' --property=RuntimeMaxSec=90 --property=TimeoutStopSec=30 --property=KillMode=control-group /bin/sh '+remote+'/run.sh'],capture_output=True)
(root/'launch.log').write_bytes(r.stdout+r.stderr);assert r.returncode==0,(r.stdout+r.stderr).decode('utf-8')
print((r.stdout+r.stderr).decode('utf-8'),flush=True)
