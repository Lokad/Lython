from pathlib import Path
import hashlib,json,subprocess,tarfile
home=Path(__file__).resolve().parent;root=home/'b365';remote='/home/lokad/lython-bench-checks/text-prefix-b365-20261106'
s=(root/'analyze-cpu-guest.py').read_text(encoding='utf-8').replace('["sudo", "-n", "perf", "script"','["perf", "script"')
(root/'analyze-recovered.py').write_text(s,encoding='utf-8')
script=r'''from pathlib import Path
import fcntl,hashlib,json,os,shutil,subprocess,tarfile
root=Path('REMOTE');folder=root/'perf/text-warm';base=root.parent
with (base/'comparison-vm.lock').open('a') as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert (root/'exit-code.txt').read_text().strip()=='1'
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record'],capture_output=True).returncode==1
 assert not list(Path('/dev/shm').glob('lython-comparison-files-*'))
 r=json.loads((folder/'record.json').read_text());assert r['response']['status']=='Completed' and r['response']['completedInvocations']==3072
 assert r['response']['actualOutputSha256']==r['verificationBefore']['actualOutputSha256']
 assert r['response']['actualFilesSha256']==r['verificationBefore']['actualFilesSha256']
 assert 'closed' not in r and r['exitCode']!=0
 pid=r['identity']['processId'];assert not Path('/proc/'+str(pid)).exists()
 assert not (folder/'perf.data').is_symlink() and (folder/'perf.data').stat().st_uid==os.getuid()
 for prefix in ['perf','perfinfo']:
  p=Path('/tmp')/(prefix+'-'+str(pid)+'.map')
  if p.exists():
   assert not p.is_symlink() and p.stat().st_uid==os.getuid()
   target=folder/(prefix+'-final.map');shutil.copyfile(p,target);assert p.read_bytes()==target.read_bytes();p.unlink()
 # Analyze the original capture with its capture-end map; retain any later map
 # separately. User-owned data is read by user perf, without sudo/owner override.
 subprocess.run(['python3',str(root/'analyze-recovered.py'),str(folder)],check=True)
 (root/'terminal-journal.txt').write_text(subprocess.check_output(['journalctl','--unit=lython-b365-text-prefix-20261106','--no-pager'],text=True))
 limitation=dict(capturedBatchCompleted=True,outputAndFileGoldensPassed=True,normalManagedShutdown=False,immediateFinalQuietGate=False,originalOwnerExitCode=1,allProcessesSettled=True,guestFixturesRemoved=True,performanceQualified=False,correction='Offline user perf export only, no recapture/retiming; original root perf report rejected user-owned data. Killed idle worker cannot regain normal managed-shutdown proof.',jitOutputMayBeTruncated=True)
 (root/'recovery-limitations.json').write_text(json.dumps(limitation,indent=2)+'\n')
 with tarfile.open(root/'recovered-observations.tgz','w:gz') as a:
  for n in ['identity.json','catalog.json','pre-capture-plan.md','ops-profile.py','analyze-cpu-guest.py','analyze-recovered.py','archive.py','run.sh','machine-before.json','started.utc','stopped.utc','exit-code.txt','terminal-journal.txt','recovery-limitations.json']:a.add((root/n).resolve(),arcname=n)
  for p in sorted((root/'perf').rglob('*')):
   if p.is_file():a.add(p,arcname=str(p.relative_to(root)))
 with tarfile.open(root/'recovered-observations.tgz') as a:assert json.loads(a.extractfile('perf/text-warm/record.json').read())['response']['status']=='Completed'
 receipt=dict(archiveSHA256=hashlib.sha256((root/'recovered-observations.tgz').read_bytes()).hexdigest(),archivedAndVerifiedUnderRecoveryLease=True,performanceQualified=False,allProcessesSettled=True,normalManagedShutdown=False)
 (root/'recovery-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt),flush=True)
'''.replace('REMOTE',remote)
(root/'recover.py').write_text(script,encoding='utf-8')
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73'];scp=['C:/Windows/System32/OpenSSH/scp.exe','-i',ssh[2],'-o','BatchMode=yes','-o','ConnectTimeout=15']
for n in ['analyze-recovered.py','recover.py']:
 r=subprocess.run([*scp,str(root/n),'lokad@20.166.121.73:'+remote+'/'+n],capture_output=True);assert r.returncode==0,r.stderr
r=subprocess.run([*ssh,'python3 '+remote+'/recover.py'],capture_output=True)
(root/'recovery.log').write_bytes(r.stdout+r.stderr);assert r.returncode==0,(r.stdout+r.stderr).decode('utf-8');print((r.stdout+r.stderr).decode('utf-8'),flush=True)
for n in ['recovered-observations.tgz','recovery-receipt.json']:
 r=subprocess.run([*scp,'lokad@20.166.121.73:'+remote+'/'+n,str(root/n)],capture_output=True);assert r.returncode==0,r.stderr
receipt=json.loads((root/'recovery-receipt.json').read_text(encoding='utf-8'));assert hashlib.sha256((root/'recovered-observations.tgz').read_bytes()).hexdigest()==receipt['archiveSHA256']
with tarfile.open(root/'recovered-observations.tgz') as a:a.extractall(root/'retrieved',filter='data')
print('Recovered original diagnostic data with explicit missing gates; no retiming',flush=True)
