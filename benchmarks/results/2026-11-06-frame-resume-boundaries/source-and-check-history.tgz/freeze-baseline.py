from pathlib import Path
import hashlib,json,shutil,subprocess,tarfile
root=Path(__file__).resolve().parent;repo=Path('D:/code/Lython');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
paths=[p for p in (repo/'src/Lokad.Lython').rglob('*.cs') if not {'bin','obj'}.intersection(p.parts)]
identity=dict(head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),runtimeSource='f2ce53db',sourceSHA256={str(p.relative_to(repo)).replace('\\','/'):sha(p) for p in paths},coreSHA256={})
for framework in ['net11.0','net10.0']:
 folder=root/'baseline'/framework;folder.mkdir(parents=True)
 for n in ['Lokad.Lython.dll','Lokad.Lython.Utf8Regex.dll','Lokad.Utf8Regex.dll','Lokad.Utf8Regex.PythonRe.dll']:
  source=repo/'benchmarks/Lokad.Lython.Benchmarks/bin/Release'/framework/n
  if n=='Lokad.Lython.dll':source=repo/'src/Lokad.Lython/bin/Release'/framework/n
  shutil.copyfile(source,folder/n)
 identity['coreSHA256'][framework]=sha(folder/'Lokad.Lython.dll')
(root/'baseline.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8')
with tarfile.open(root/'baseline-source.tgz','w:gz') as a:
 for p in paths:a.add(p,arcname=str(p.relative_to(repo)))
shutil.copyfile(repo/'PLAN.md',root/'PLAN-before-implementation.md')
print(identity['head'],identity['coreSHA256'])
