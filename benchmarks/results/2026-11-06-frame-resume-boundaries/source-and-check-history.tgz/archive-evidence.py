from pathlib import Path
import json,shutil,tarfile
root=Path(__file__).resolve().parent;out=Path('benchmarks/results/2026-11-06-frame-resume-boundaries');out.mkdir(exist_ok=True)
for n in ['baseline.json','focused-results.json','delivery-local.json','comparison-summary.json','allocation-summary.json']:
 shutil.copyfile(root/n,out/n)
for block,names in [('b363',['failed-observations.tgz','terminal-status.json']),('b364',['failed-observations.tgz','terminal-status.json']),('b365',['recovered-observations.tgz','recovery-receipt.json','terminal-status.json','prefix-exact-attribution.json']),('b366',['observations.tgz','archive-receipt.json','terminal-status.json'])]:
 folder=root if block=='b363' else root/block
 for n in names:
  p=folder/n
  if p.exists():shutil.copyfile(p,out/(block+'-'+n))
shutil.copyfile(root/'b365/retrieved/perf/text-warm/prefix-attribution.json',out/'prefix-attribution.json')
shutil.copyfile(root/'census.json',out/'census.json')
with tarfile.open(out/'source-and-check-history.tgz','w:gz') as a:
 for p in sorted(root.glob('*.py')):a.add(p,arcname=p.name)
 for p in sorted(root.glob('*.log')):a.add(p,arcname=p.name)
 for n in ['Program.cs','census.csproj']:a.add(root/'census'/n,arcname='census/'+n)
 a.add(root/'b366/source.patch',arcname='source.patch')
 for block in ['b364','b365','b366']:
  for p in sorted((root/block).glob('*')):
   if p.is_file() and p.suffix in ['.py','.log']:a.add(p,arcname=block+'/'+p.name)
with tarfile.open(out/'allocation-diagnostics.tgz','w:gz') as a:
 for n in ['identity.json','catalog.json']:a.add(root/'allocation'/n,arcname=n)
 for n in ['measurements.json','hash-witness.json','stderr.txt']:a.add(root/'allocation/sync'/n,arcname='sync/'+n)
print(out,flush=True)
