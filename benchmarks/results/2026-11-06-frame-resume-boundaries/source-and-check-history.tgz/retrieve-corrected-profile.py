from pathlib import Path
p=Path(__file__).resolve().parent/'retrieve-profile.py'
s=p.read_text(encoding='utf-8').replace('root=Path(__file__).resolve().parent;remote=',"root=Path(__file__).resolve().parent/'b364';remote=").replace('b363','b364')
exec(compile(s,str(p),'exec'),{'__file__':str(p.resolve()),'__name__':'__main__'})
