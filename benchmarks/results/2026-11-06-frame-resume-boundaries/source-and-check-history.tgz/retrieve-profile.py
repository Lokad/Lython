from pathlib import Path
import hashlib,json,subprocess,tarfile
root=Path(__file__).resolve().parent;remote='/home/lokad/lython-bench-checks/text-prefix-b363-20261106'
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
script=r'''from pathlib import Path
import json,subprocess
root=Path('REMOTE')
print(json.dumps(dict(service=subprocess.check_output(['systemctl','show','lython-b363-text-prefix-20261106.service','--property=ActiveState,SubState,MainPID,Result,ExecMainStatus'],text=True),exitCode=(root/'exit-code.txt').read_text().strip() if (root/'exit-code.txt').exists() else None,receipt=json.loads((root/'archive-receipt.json').read_text()) if (root/'archive-receipt.json').exists() else None,remainingWorkers=subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record'],capture_output=True,text=True).stdout,remainingFixtures=[str(p) for p in Path('/dev/shm').glob('lython-comparison-files-*')])))
'''.replace('REMOTE',remote)
r=subprocess.run([*ssh,'python3 -'],input=script,text=True,encoding='utf-8',capture_output=True)
(root/'terminal-status.json').write_text(r.stdout,encoding='utf-8');assert r.returncode==0,r.stderr
status=json.loads(r.stdout);print(status,flush=True)
assert status['exitCode']=='0' and status['receipt']['complete']
assert not status['remainingWorkers'] and not status['remainingFixtures'] and 'MainPID=0' in status['service']
scp=['C:/Windows/System32/OpenSSH/scp.exe','-i',ssh[2],'-o','BatchMode=yes','-o','ConnectTimeout=15']
for n in ['observations.tgz','archive-receipt.json']:
 r=subprocess.run([*scp,'lokad@20.166.121.73:'+remote+'/'+n,str(root/n)],capture_output=True);assert r.returncode==0,r.stderr
receipt=json.loads((root/'archive-receipt.json').read_text(encoding='utf-8'));assert hashlib.sha256((root/'observations.tgz').read_bytes()).hexdigest()==receipt['archiveSHA256']
with tarfile.open(root/'observations.tgz') as a:a.extractall(root/'retrieved',filter='data')
print('Verified persistent capture, code and archive',receipt,flush=True)
