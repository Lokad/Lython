from pathlib import Path
import hashlib,json,os,re,subprocess,sys
root=Path(__file__).resolve().parent;repo=Path('D:/code/Lython')
env=os.environ.copy();env['DOTNET_ROOT']='C:/Users/JoannesVermorel/.dotnet11';env['DOTNET_HOST_PATH']=env['DOTNET_ROOT']+'/dotnet.exe';env['PATH']=env['DOTNET_ROOT']+os.pathsep+'C:/Python313'+os.pathsep+env['PATH']
families=['Executable','Generator','Function','Exception','InstructionFailureRouting','Return','GovernedMemory','LocalAugmentedLifetime','Constructor','HashReadAsync']
selection='Category!=Stress&('+'|'.join('FullyQualifiedName~'+f for f in families)+')'
checks={}
for framework in ['net11.0','net10.0']:
 for name in ['Lokad.Lython.Tests','Lokad.Lython.PublicApi.Tests']:
  key=name+'-'+framework;log=root/('focused-'+key+'.log');assert not log.exists()
  with log.open('w',encoding='utf-8') as out:
   r=subprocess.run([env['DOTNET_HOST_PATH'],'test',str(repo/'tests'/name/(name+'.csproj')),'-c','Release','-f',framework,'--no-build','--no-restore','--nologo','--tl:off','--filter',selection],cwd=repo,env=env,stdout=out,stderr=subprocess.STDOUT)
  text=log.read_text(encoding='utf-8');print(key,r.returncode,text[-1000:],flush=True)
  checks[key]=dict(exitCode=r.returncode,summaries=re.findall(r'(?:Passed!|Failed!)\s+[^\r\n]+',text))
  (root/'focused-results.json').write_text(json.dumps(dict(checks=checks,selection=selection),indent=2)+'\n',encoding='utf-8')
  if r.returncode:sys.exit(r.returncode)
 checks[framework]=dict(coreSHA256=hashlib.sha256((repo/'src/Lokad.Lython/bin/Release'/framework/'Lokad.Lython.dll').read_bytes()).hexdigest())
(root/'focused-results.json').write_text(json.dumps(dict(checks=checks,selection=selection,sourceBase='90a00002 plus R21 resume/return simplification'),indent=2)+'\n',encoding='utf-8')
