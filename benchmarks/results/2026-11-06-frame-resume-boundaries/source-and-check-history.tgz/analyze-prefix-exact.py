from pathlib import Path
import bisect,collections,json,re,sys
folder=Path(sys.argv[1]);code=(folder/'prefix-code.txt').read_text(encoding='utf-8')
sections=[];section=None;offset=None;block=None
for line in code.splitlines():
 if line.startswith('; Assembly listing for method '):
  section=dict(header=line,blocks=[],instructions=[],totalBytes=None);sections.append(section)
 if section is None:continue
 m=re.match(r'(G_M\d+_IG\d+):\s*;; offset=0x([0-9A-Fa-f]+)',line)
 if m:
  block=dict(label=m[1],offset=int(m[2],16),lines=[]);section['blocks'].append(block);offset=block['offset'];continue
 if block is not None:block['lines'].append(line)
 m=re.match(r'\s+([0-9A-Fa-f]+)\s+([a-z][^\n]*)$',line)
 if m and offset is not None and len(m[1])%2==0:
  size=len(m[1])//2;section['instructions'].append(dict(offset=offset,size=size,block=block['label'],assembly=m[2]));offset+=size
 m=re.search(r'; Total bytes of code (\d+)',line)
 if m:section['totalBytes']=int(m[1]);offset=None;block=None
assert sections
print('Disassembly sections:',[(s['header'].split('):int ')[-1],s['totalBytes'],len(s['instructions'])) for s in sections],flush=True)
if not (folder/'perf-leaves.txt').exists():raise SystemExit(0)
r=json.loads((folder/'record.json').read_text(encoding='utf-8'));tids=set(r['guestTids']);maps=[]
for line in (folder/'perf.map').read_text(encoding='utf-8').splitlines():
 start,size,name=line.split(' ',2);maps.append((int(start,16),int(size,16),name))
maps.sort();starts=[x[0] for x in maps];all_samples=0;prefix_samples=0;unresolved=collections.Counter();ips=collections.Counter();blocks=collections.Counter();chosen={}
for line in (folder/'perf-leaves.txt').read_text(encoding='utf-8').splitlines():
 m=re.match(r'\s*(\d+)/(\d+)\s+([0-9a-fx]+)\s*(.*)',line)
 if not m or m[2] not in tids:continue
 all_samples+=1;address=int(m[3],16);i=bisect.bisect_right(starts,address)-1
 if i<0:continue
 start,size,name=maps[i]
 if address>=start+size or '::ExecuteInstructionPrefix(' not in name:continue
 prefix_samples+=1;relative=address-start
 candidates=[s for s in sections if s['totalBytes']==size]
 if not candidates:unresolved[(name,size)]+=1;continue
 # Tier names disambiguate identical-sized quick/instrumented code. Optimized
 # sections generally have a unique size; never borrow code from another build.
 if len(candidates)>1:
  marker='Instrumented' if '[InstrumentedTier]' in name else 'Tier0' if '[QuickJitted]' in name else 'Tier1'
  candidates=[s for s in candidates if marker in s['header']]
 if len(candidates)!=1:unresolved[(name,size)]+=1;continue
 s=candidates[0];instructions=s['instructions'];positions=[v['offset'] for v in instructions];j=bisect.bisect_right(positions,relative)-1
 if j<0 or relative>=instructions[j]['offset']+instructions[j]['size']:unresolved[('instruction gap',size)]+=1;continue
 inst=instructions[j];key=(size,inst['offset'],inst['assembly']);ips[key]+=1;blocks[(size,inst['block'])]+=1;chosen[size]=s
summary=dict(purpose='Diagnostic leaf IP/block attribution, not speedup or pure dispatch cost',allGuestSamples=all_samples,prefixSamples=prefix_samples,resolvedPrefixSamples=sum(ips.values()),unresolved=[dict(method=k[0],codeBytes=k[1],samples=v) for k,v in unresolved.items()],sections=[dict(header=s['header'],totalBytes=s['totalBytes'],instructions=len(s['instructions'])) for s in sections],topInstructions=[dict(codeBytes=k[0],offset=hex(k[1]),assembly=k[2],samples=v) for k,v in ips.most_common(30)],topBlocks=[])
for (size,label),count in blocks.most_common(24):
 block=next(b for b in chosen[size]['blocks'] if b['label']==label)
 summary['topBlocks'].append(dict(codeBytes=size,label=label,offset=hex(block['offset']),samples=count,assembly=block['lines']))
(folder/'prefix-attribution.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8')
print(json.dumps({k:v for k,v in summary.items() if k not in ['topBlocks','sections']},indent=2),flush=True)
assert prefix_samples and sum(ips.values())/prefix_samples>=.9,'Keep unresolved mapping explicit; no attribution claim.'
