from pathlib import Path
import fcntl,hashlib,io,json,shutil,subprocess,sys,tarfile
base=Path('/home/lokad/lython-bench-checks');root=Path('/home/lokad/lython-bench-checks/text-prefix-b363-20261106');prior=base/'record-layout-b361-20261106'
with (base/'comparison-vm.lock').open('a') as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert not root.exists() and not list(Path('/dev/shm').glob('lython-comparison-files-*'))
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record'],capture_output=True).returncode==1
 payload=sys.stdin.buffer.read(11414+1);assert len(payload)==11414 and hashlib.sha256(payload).hexdigest()=='56dfc3087fa20c307650f9f0e4a084acf566ca13aa0a8f08c89ebaa334ebdf61'
 with tarfile.open(fileobj=io.BytesIO(payload),mode='r:gz') as a:
  assert shutil.disk_usage(base).free>sum(m.size for m in a.getmembers())+10*1024*1024
  root.mkdir();a.extractall(root,filter='data')
 (root/'candidate').symlink_to(prior/'candidate',target_is_directory=True)
 (root/'catalog.json').symlink_to(prior/'representative.json')
 i=json.loads((root/'identity.json').read_text());assert hashlib.sha256((root/'candidate/Lokad.Lython.dll').read_bytes()).hexdigest()==i['files']['Lokad.Lython.dll']
 for name in ['ops-profile.py','analyze-cpu-guest.py','archive.py']:compile((root/name).read_text(),str(root/name),'exec')
 subprocess.run(['/bin/sh','-n',str(root/'run.sh')],check=True)
 print(json.dumps(dict(freeBytes=shutil.disk_usage(base).free,workerCoreSHA256=i['files']['Lokad.Lython.dll'],productionEdits=False)),flush=True)
subprocess.run(['sudo','-n','systemd-run','--unit=lython-b363-text-prefix-20261106','--property=User=lokad','--property=WorkingDirectory='+str(root),'--property=RuntimeMaxSec=90','--property=TimeoutStopSec=30','--property=KillMode=control-group','/bin/sh',str(root/'run.sh')],check=True)
