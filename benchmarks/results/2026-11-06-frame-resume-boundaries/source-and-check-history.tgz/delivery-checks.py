from pathlib import Path
home=Path(__file__).resolve().parent
s=(home.parent/'record-layout-r20/delivery-checks.py').read_text(encoding='utf-8').replace('db55033e plus R20 prototype; frozen focused-results hashes','90a00002 plus R21 resume/return simplification; frozen focused-results hashes').replace("package='Pending retention decision'","package='Batch installed/platform/Stress at next coherent delivery; f2ce53db is the prior qualified runtime'")
(home/'delivery-script.py').write_text(s,encoding='utf-8')
exec(compile(s,str(home/'delivery-script.py'),'exec'),{'__file__':str(home/'delivery-script.py'),'__name__':'__main__'})
