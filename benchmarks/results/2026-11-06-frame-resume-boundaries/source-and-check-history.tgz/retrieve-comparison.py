from pathlib import Path
home=Path(__file__).resolve().parent
s=(home.parent/'delivery-comparison-b352/retrieve.py').read_text(encoding='utf-8')
s=s.replace('root=Path(__file__).parent',"root=Path(__file__).resolve().parent/'b366'")
s=s.replace('delivery-comparison-b352','resume-boundary-b366').replace('lython-b352-delivery-comparison','lython-b366-resume-boundary')
s=s.replace("['jobs']==15","['jobs']==5")
exec(compile(s,str(Path(__file__).resolve()),'exec'),{'__file__':str(Path(__file__).resolve()),'__name__':'__main__'})
