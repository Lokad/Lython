from pathlib import Path
import hashlib,json,subprocess,tarfile
root=Path(__file__).resolve().parent;old=root.parent/'current-cpu-r19'
remote='/home/lokad/lython-bench-checks/text-prefix-b363-20261106'
prior='/home/lokad/lython-bench-checks/current-cpu-b358-20261106'
def write(n,s):
 with (root/n).open('w',encoding='utf-8',newline='\n') as f:f.write(s)
identity=dict(sourceRevision='f2ce53db runtime source, frozen R20 core67f84196; no production changes',files={'Lokad.Lython.dll':'67f841962f56ef0df5a1bbcfe78a0f4d60259bb5d17b6490508f32bde80992f6'},purpose='R21 text-only instruction/block attribution, not elapsed/source-pair performance qualification',diagnosticOverrides={'DOTNET_PerfMapEnabled':'3','DOTNET_JitDisasm':'ExecuteInstructionPrefix','DOTNET_JitDisasmWithCodeBytes':'1','DOTNET_JitDisasmWithAddress':'1','DOTNET_JitStdOutFile':'owned per-worker prefix-code.txt'},optionReference='https://github.com/dotnet/runtime/blob/main/src/coreclr/jit/jitconfigvalues.h',limitation='Pinned runtime must demonstrate actual output; address option may be unavailable in release, code bytes plus labelled offsets remain useful. No unsafe/native probing added to Lython.')
write('identity.json',json.dumps(identity,indent=2)+'\n')
s=(old/'ops-profile.py').read_text(encoding='utf-8').replace(prior,remote)
s=s.replace('        ("report-warm", "scripts.report-render.large", "warm"),\n','')
s=s.replace('if perf_mode:env["DOTNET_PerfMapEnabled"] = "3"','''if perf_mode:env["DOTNET_PerfMapEnabled"] = "3"
env['DOTNET_JitDisasm']='ExecuteInstructionPrefix'
env['DOTNET_JitDisasmWithCodeBytes']='1'
env['DOTNET_JitDisasmWithAddress']='1' ''')
s=s.replace('        folder.mkdir()','''        folder.mkdir()
        env['DOTNET_JitStdOutFile']=str(folder/'prefix-code.txt')''')
s=s.replace('"diagnosticOverrides": {"DOTNET_PerfMapEnabled": "3"} if perf_mode else {},','"diagnosticOverrides": {k:v for k,v in env.items() if k.startswith("DOTNET_") and k!="DOTNET_ROOT"},')
s=s.replace('            assert profiler.returncode == 0','''            assert profiler.returncode == 0
            datafile=folder/'perf.data'
            assert datafile.resolve().is_relative_to(folder.resolve()) and not datafile.is_symlink()
            subprocess.run(['sudo','-n','chown',str(os.getuid())+':'+str(os.getgid()),str(datafile)],check=True)''')
write('ops-profile.py',s)
shutil_source=(old/'analyze-cpu-guest.py').read_text(encoding='utf-8');write('analyze-cpu-guest.py',shutil_source)
write('pre-capture-plan.md',Path('PLAN.md').read_text(encoding='utf-8'))
write('run.sh','''set -eu
root=REMOTE
dotnet=/home/lokad/lython-bench-toolchains/dotnet/11.0.100-rc.3.26522.148/dotnet
export DOTNET_ROOT=/home/lokad/lython-bench-toolchains/dotnet/11.0.100-rc.3.26522.148
export TMPDIR=/dev/shm
date -u +%FT%TZ > "$root/started.utc"
trap 'exit 143' TERM
trap 'result=$?; printf "%s\\n" "$result" > "$root/exit-code.txt"; date -u +%FT%TZ > "$root/stopped.utc"' EXIT
exec 9>/home/lokad/lython-bench-checks/comparison-vm.lock
flock -n 9
sleep 5
"$dotnet" "$root/candidate/Lokad.Lython.Benchmarks.dll" --compare check-machine --out "$root/machine-before.json"
python3 "$root/ops-profile.py" "$root/perf"
sleep 5
"$dotnet" "$root/candidate/Lokad.Lython.Benchmarks.dll" --compare check-machine --out "$root/machine-after.json"
python3 "$root/analyze-cpu-guest.py" "$root/perf/text-warm"
python3 "$root/archive.py"
'''.replace('REMOTE',remote))
write('archive.py',r'''from pathlib import Path
import hashlib,json,subprocess,tarfile
root=Path('REMOTE');folder=root/'perf/text-warm'
r=json.loads((folder/'record.json').read_text())
assert r['exitCode']==0 and r['closed']['status']=='Closed'
assert (folder/'worker.stderr').stat().st_size==0
assert json.loads((root/'machine-before.json').read_text())['gate']['quiet']
assert json.loads((root/'machine-after.json').read_text())['gate']['quiet']
assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record'],capture_output=True).returncode==1
assert not list(Path('/dev/shm').glob('lython-comparison-files-*'))
code=(folder/'prefix-code.txt').read_text();assert 'ExecuteInstructionPrefix' in code and 'offset=' in code
with tarfile.open(root/'observations.tgz','w:gz') as a:
 for n in ['identity.json','catalog.json','pre-capture-plan.md','ops-profile.py','analyze-cpu-guest.py','archive.py','run.sh','machine-before.json','machine-after.json','started.utc']:a.add((root/n).resolve(),arcname=n)
 for p in sorted((root/'perf').rglob('*')):
  if p.is_file():a.add(p,arcname=str(p.relative_to(root)))
with tarfile.open(root/'observations.tgz') as a:assert json.loads(a.extractfile('perf/text-warm/record.json').read())['exitCode']==0
receipt=dict(complete=True,allWorkersJoined=True,guestFixturesRemoved=True,quietBeforeAndAfter=True,archivedAndVerifiedUnderLease=True,capturedSeconds=r['response']['elapsedTicks']/r['response']['clockFrequency'],archiveSHA256=hashlib.sha256((root/'observations.tgz').read_bytes()).hexdigest(),performanceQualified=False)
(root/'archive-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt))
'''.replace('REMOTE',remote))
names=['identity.json','pre-capture-plan.md','ops-profile.py','analyze-cpu-guest.py','archive.py','run.sh']
with tarfile.open(root/'payload.tgz','w:gz') as a:
 for n in names:a.add(root/n,arcname=n)
data=(root/'payload.tgz').read_bytes()
write('launch.py',r'''from pathlib import Path
import fcntl,hashlib,io,json,shutil,subprocess,sys,tarfile
base=Path('/home/lokad/lython-bench-checks');root=Path('REMOTE');prior=base/'record-layout-b361-20261106'
with (base/'comparison-vm.lock').open('a') as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert not root.exists() and not list(Path('/dev/shm').glob('lython-comparison-files-*'))
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record'],capture_output=True).returncode==1
 payload=sys.stdin.buffer.read(PAYLOADBYTES+1);assert len(payload)==PAYLOADBYTES and hashlib.sha256(payload).hexdigest()=='PAYLOADHASH'
 with tarfile.open(fileobj=io.BytesIO(payload),mode='r:gz') as a:
  assert shutil.disk_usage(base).free>sum(m.size for m in a.getmembers())+10*1024*1024
  root.mkdir();a.extractall(root,filter='data')
 (root/'candidate').symlink_to(prior/'candidate',target_is_directory=True)
 (root/'catalog.json').symlink_to(prior/'representative.json')
 i=json.loads((root/'identity.json').read_text());assert hashlib.sha256((root/'candidate/Lokad.Lython.dll').read_bytes()).hexdigest()==i['files']['Lokad.Lython.dll']
 for name in ['ops-profile.py','analyze-cpu-guest.py','archive.py']:compile((root/name).read_text(),str(root/name),'exec')
 subprocess.run(['/bin/sh','-n',str(root/'run.sh')],check=True)
 print(json.dumps(dict(freeBytes=shutil.disk_usage(base).free,workerCoreSHA256=i['files']['Lokad.Lython.dll'],productionEdits=False)),flush=True)
subprocess.run(['sudo','-n','systemd-run','--unit=lython-b363-text-prefix-20261106','--property=User=lokad','--property=WorkingDirectory='+str(root),'--property=RuntimeMaxSec=90','--property=TimeoutStopSec=30','--property=KillMode=control-group','/bin/sh',str(root/'run.sh')],check=True)
'''.replace('REMOTE',remote).replace('PAYLOADBYTES',str(len(data))).replace('PAYLOADHASH',hashlib.sha256(data).hexdigest()))
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15']
r=subprocess.run(['C:/Windows/System32/OpenSSH/scp.exe',*ssh[1:],str(root/'launch.py'),'lokad@20.166.121.73:/home/lokad/lython-bench-checks/b363-launch.py'],capture_output=True);assert r.returncode==0,r.stderr
r=subprocess.run([*ssh,'lokad@20.166.121.73','python3 /home/lokad/lython-bench-checks/b363-launch.py'],input=data,capture_output=True)
(root/'launch.log').write_bytes(r.stdout+r.stderr);assert r.returncode==0,(r.stdout+r.stderr).decode('utf-8')
print((r.stdout+r.stderr).decode('utf-8'),flush=True)
