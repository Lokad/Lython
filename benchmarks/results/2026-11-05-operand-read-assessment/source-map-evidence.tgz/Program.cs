using System.Collections;
using System.Reflection;
using System.Runtime.Loader;
using System.Security.Cryptography;
using System.Text.Json;

// Adapt the existing B132 compile-only census. No guest execution/instrumentation.
const BindingFlags Flags = BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic;
object? Get(object owner, string property) => owner.GetType().GetProperty(property, Flags)!.GetValue(owner);
object[] Items(object owner, string property) => ((IEnumerable)Get(owner, property)!).Cast<object>().ToArray();
var corePath = Path.GetFullPath(args[0]);
var core = AssemblyLoadContext.Default.LoadFromAssemblyPath(corePath);
var instructionType=core.GetType("Lokad.Lython.Frontend.ExecutableInstruction",true)!;
GC.KeepAlive(Array.CreateInstance(instructionType,1));
var beforeArray=GC.GetAllocatedBytesForCurrentThread();
var instructionArray=Array.CreateInstance(instructionType,1024);
var instructionArrayBytes=GC.GetAllocatedBytesForCurrentThread()-beforeArray;
GC.KeepAlive(instructionArray);
var engineType = core.GetType("Lokad.Lython.LythonEngine", true)!;
var engine = Activator.CreateInstance(engineType)!;
var compile = engineType.GetMethod("Compile", [typeof(string), core.GetType("Lokad.Lython.ILythonMemoryBudget", true)!])!;
using var catalog = JsonDocument.Parse(File.ReadAllBytes(args[1]));
var ids = new HashSet<string>(["scripts.text-summary-helpers.large", "scripts.csv-summary-helpers.large",
    "scripts.report-render.large", "scripts.config-edit.large", "scripts.json-summary-helpers.large"]);
var cases = new List<object>();
foreach (var item in catalog.RootElement.GetProperty("cases").EnumerateArray())
{
    if (!ids.Contains(item.GetProperty("id").GetString()!)) continue;
    using var script = (IDisposable)compile.Invoke(engine, [item.GetProperty("source").GetString(), null])!;
    if (!(bool)Get(script, "IsValid")!) throw new InvalidDataException("Census requires valid maintained source.");
    var runner = (Delegate)script.GetType().GetField("_runner", Flags)!.GetValue(script)!;
    var executable = runner.Target!.GetType().GetField("executableScript", Flags)!.GetValue(runner.Target)!;
    var codes = new List<object>();
    var seen = new HashSet<object>(ReferenceEqualityComparer.Instance);
    void Visit(object code)
    {
        if (!seen.Add(code)) return;
        var operations = new List<object>();
        var counts = new Dictionary<string, int>(StringComparer.Ordinal);
        var constants = Items(code, "Constants");
        var instructions = Items(code, "Instructions");
        var sites = Items(code, "CallSites");
        for (var index = 0; index < instructions.Length; index++)
        {
            var instruction = instructions[index];
            var op = Get(instruction, "OpCode")!.ToString()!;
            counts[op] = counts.GetValueOrDefault(op) + 1;
            var span = Get(instruction, "Span")!;
            var fields = new Dictionary<string, object?> { ["index"] = index, ["op"] = op,
                ["line"] = Get(span, "Line"), ["start"] = Get(span, "Start"), ["length"] = Get(span, "Length") };
            foreach (var name in new[] { "InputStart", "SecondInput", "ResultSlot", "LiveExtent" }) fields[name]=Get(instruction,name);
            foreach (var name in new[] { "NativeFirst", "NativeSecond" }) fields[name]=Get(code,"NativeReturnRoot") is not null ? Get(instruction,name) : null;
            foreach (var name in new[] { "FirstReadSpanIndex", "SecondReadSpanIndex" }) fields[name]=instruction.GetType().GetProperty(name,Flags)?.GetValue(instruction) ?? -1;
            if (op is "LoadConst" or "ApplyOperation")
            {
                var constant = constants[(int)Get(instruction,"ConstantIndex")!];
                fields["constantKind"] = constant.GetType().Name;
                var value=constant.ToString();fields["constant"] = value?.Length>100 ? value[..100] : value;
            }
            if (op is "LoadLocal" or "StoreLocal") fields["LocalSlot"] = Get(instruction,"LocalSlot");
            if (op is "LoadGlobal" or "LoadName" or "StoreGlobal" or "StoreName" or "LoadMember" or "LoadCallMember" or "LoadCallReceiver") fields["name"]=Items(code,"Names")[(int)Get(instruction,"NameIndex")!];
            if (op is "Jump" or "JumpIfFalse" or "ForNext" or "AbruptJump" or "EndFinally") fields["TargetIndex"]=Get(instruction,"TargetIndex");
            if (op=="Call")
            {
                var site=sites[(int)Get(instruction,"CallSiteIndex")!];
                fields["arguments"]=Get(site,"ArgumentCount");fields["receiver"]=Get(site,"HasReceiver");
                fields["argumentKinds"]=Items(site,"Arguments").Select(a=>Get(a,"Kind")!.ToString()).ToArray();
            }
            operations.Add(fields);
        }
        codes.Add(new { name = Get(code, "Name"), locals = Items(code, "LocalNames"),
            isFunction=Get(code,"IsFunctionScope"),requiresMirroring = Get(code, "RequiresLocalVariableMirroring"),
            capturedLocalSlots=Items(code,"CapturedLocalSlots"),closures=Items(code,"ClosureNames"),
            exceptionRegions=Items(code,"ExceptionRegions").Select(r=>new {start=Get(r,"ProtectedStartIndex"),end=Get(r,"ProtectedEndIndex"),depth=Get(r,"StackDepth")}).ToArray(),
            nativeRoot=Get(code,"NativeReturnRoot"),firstTemporary=Get(code,"FirstTemporarySlot"),
            instructionCount=counts.Values.Sum(),operandCapacity=Get(code,"OperandCapacity"),counts,operations });
        foreach(var function in Items(code,"Functions"))Visit(Get(function,"CodeObject")!);
    }
    Visit(Get(executable,"EntryPoint")!);
    cases.Add(new {id=item.GetProperty("id").GetString(),sourceSha256=item.GetProperty("sourceSha256").GetString(),source=item.GetProperty("source").GetString(),codes});
}
if (cases.Count!=ids.Count)throw new InvalidDataException("Missing representative source.");
File.WriteAllText(args[2],JsonSerializer.Serialize(new {
    purpose="Compile-only current operand-use map; static counts are not CPU shares or predicted speedup",
    coreSHA256=Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(corePath))),
    runtime=System.Runtime.InteropServices.RuntimeInformation.FrameworkDescription,
    instructionArrayElements=1024,instructionArrayBytes,
    noGuestExecution=true,noProductionEdits=true,cases
},new JsonSerializerOptions {WriteIndented=true}));
