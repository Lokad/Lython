using Lokad.Lython.Frontend;
using Lokad.Lython.Runtime;
using Lokad.Lython.Runtime.Text;
using Lokad.Lython.Tests.Harness;

namespace Lokad.Lython.Tests;

public sealed class LoweringArchitectureSubsystemTests
{
    [Fact]
    public void LoweredScript_PreservesStatementOrderAndFunctionBodies()
    {
        var frontend = LythonFrontend.Compile("""
import json

def helper():
    if True:
        return 1
    return 1

value = 2
""",regexProvider:Utf8RegexProvider.Instance);

        var lowered = LoweredScript.Lower(frontend.Script.RequireNotNull());

        Assert.Equal(lowered.Syntax.Statements.Count, lowered.Statements.Count);
        Assert.IsType<LoweredImportStatement>(lowered.Statements[0]);
        var function = Assert.IsType<LoweredFunctionDefinitionStatement>(lowered.Statements[1]);
        var assignment = Assert.IsType<LoweredNameAssignmentStatement>(lowered.Statements[2]);
        var loweredIf = Assert.IsType<LoweredIfStatement>(function.Body[0]);
        Assert.IsType<LoweredBooleanLiteralExpression>(loweredIf.Condition);
        Assert.Contains(function.Body, statement => statement is LoweredReturnStatement);
        Assert.IsType<LoweredIntegerLiteralExpression>(assignment.Expression);
    }

    [Fact]
    public void LoweredScript_LowersControlFlowBodiesRecursively()
    {
        var frontend = LythonFrontend.Compile("""
for item in [1]:
    with open("x") as handle:
        try:
            print = item
        except Exception:
            pass
""",regexProvider:Utf8RegexProvider.Instance);

        var lowered = LoweredScript.Lower(frontend.Script.RequireNotNull());
        var loop = Assert.IsType<LoweredForStatement>(Assert.Single(lowered.Statements));
        Assert.IsType<LoweredListLiteralExpression>(loop.Iterable);
        var withStatement = Assert.IsType<LoweredWithStatement>(Assert.Single(loop.Body));
        Assert.IsType<LoweredCallExpression>(withStatement.ContextExpression);
        var tryStatement = Assert.IsType<LoweredTryStatement>(Assert.Single(withStatement.Body));
        Assert.Single(tryStatement.TryBody);
        Assert.Single(Assert.Single(tryStatement.ExceptClauses).Body);
    }

    [Fact]
    public void LoweredScript_LowersFormattedStringsAndComprehensions()
    {
        var frontend = LythonFrontend.Compile("""
values = [f"{item:03d}" for item in [1, 2] if item]
mapping = {item: f"{item!s}" for item in [1, 2]}
unique = {f"{item}" for item in [1, 2] if item}
""",regexProvider:Utf8RegexProvider.Instance);

        var lowered = LoweredScript.Lower(frontend.Script.RequireNotNull());
        var listAssignment = Assert.IsType<LoweredNameAssignmentStatement>(lowered.Statements[0]);
        var listComprehension = Assert.IsType<LoweredListComprehensionExpression>(listAssignment.Expression);
        var listFormatted = Assert.IsType<LoweredFormattedStringExpression>(listComprehension.ItemExpression);
        var listPart = Assert.IsType<LoweredFormattedStringExpressionPart>(Assert.Single(listFormatted.Parts));
        Assert.Equal("03d", listPart.FormatSpecifier);
        Assert.Single(listComprehension.Clauses);
        Assert.IsType<LoweredListLiteralExpression>(listComprehension.Clauses[0].Iterable);
        Assert.IsType<LoweredIdentifierExpression>(listComprehension.Clauses[0].Condition);

        var dictAssignment = Assert.IsType<LoweredNameAssignmentStatement>(lowered.Statements[1]);
        var dictComprehension = Assert.IsType<LoweredDictComprehensionExpression>(dictAssignment.Expression);
        Assert.IsType<LoweredIdentifierExpression>(dictComprehension.KeyExpression);
        var dictFormatted = Assert.IsType<LoweredFormattedStringExpression>(dictComprehension.ValueExpression);
        var dictPart = Assert.IsType<LoweredFormattedStringExpressionPart>(Assert.Single(dictFormatted.Parts));
        Assert.Equal('s', dictPart.Conversion);

        var setAssignment = Assert.IsType<LoweredNameAssignmentStatement>(lowered.Statements[2]);
        var setComprehension = Assert.IsType<LoweredSetComprehensionExpression>(setAssignment.Expression);
        Assert.IsType<LoweredFormattedStringExpression>(setComprehension.ItemExpression);
        Assert.Single(setComprehension.Clauses);
        Assert.IsType<LoweredListLiteralExpression>(setComprehension.Clauses[0].Iterable);
        Assert.IsType<LoweredIdentifierExpression>(setComprehension.Clauses[0].Condition);
    }

    [Fact]
    public void LoweredScript_LowersMemberCallAndOperatorExpressions()
    {
        var frontend = LythonFrontend.Compile("""
value = helper.items[1] + (-count if ready else 0)
result = helper.run(*items, **mapping)
ok = left < middle < right
""",regexProvider:Utf8RegexProvider.Instance);

        var lowered = LoweredScript.Lower(frontend.Script.RequireNotNull());

        var valueAssignment = Assert.IsType<LoweredNameAssignmentStatement>(lowered.Statements[0]);
        var binary = Assert.IsType<LoweredBinaryExpression>(valueAssignment.Expression);
        var subscript = Assert.IsType<LoweredSubscriptExpression>(binary.Left);
        Assert.IsType<LoweredMemberExpression>(subscript.Target);
        var parenthesized = Assert.IsType<LoweredParenthesizedExpression>(binary.Right);
        var conditional = Assert.IsType<LoweredConditionalExpression>(parenthesized.Inner);
        Assert.IsType<LoweredUnaryExpression>(conditional.Consequent);

        var resultAssignment = Assert.IsType<LoweredNameAssignmentStatement>(lowered.Statements[1]);
        var call = Assert.IsType<LoweredCallExpression>(resultAssignment.Expression);
        Assert.IsType<LoweredMemberExpression>(call.Target);
        Assert.Contains(call.Arguments, argument => argument.Kind == CallArgumentKind.StarredList);
        Assert.Contains(call.Arguments, argument => argument.Kind == CallArgumentKind.StarredDictionary);

        var comparisonAssignment = Assert.IsType<LoweredNameAssignmentStatement>(lowered.Statements[2]);
        var chained = Assert.IsType<LoweredChainedComparisonExpression>(comparisonAssignment.Expression);
        Assert.Equal(3, chained.Operands.Count);
    }

    [Fact]
    public void LoweredScript_LowersLambdaAndSimpleControlStatements()
    {
        var frontend = LythonFrontend.Compile("""
fn = lambda x, *, step=1: x + step
assert ready, "bad"
del items[0]
if ready:
    pass
else:
    raise Error("bad")
""",regexProvider:Utf8RegexProvider.Instance);

        var lowered = LoweredScript.Lower(frontend.Script.RequireNotNull());

        var lambdaAssignment = Assert.IsType<LoweredNameAssignmentStatement>(lowered.Statements[0]);
        var lambda = Assert.IsType<LoweredLambdaExpression>(lambdaAssignment.Expression);
        Assert.IsType<LoweredBinaryExpression>(lambda.Body);
        Assert.Equal(FunctionParameterKind.KeywordOnly, lambda.Lambda.Parameters[1].Kind);

        var assertStatement = Assert.IsType<LoweredAssertStatement>(lowered.Statements[1]);
        Assert.IsType<LoweredIdentifierExpression>(assertStatement.Condition);
        Assert.IsType<LoweredStringLiteralExpression>(assertStatement.Message);

        var deleteStatement = Assert.IsType<LoweredDeleteStatement>(lowered.Statements[2]);
        Assert.IsType<LoweredSubscriptExpression>(deleteStatement.Target);

        var ifStatement = Assert.IsType<LoweredIfStatement>(lowered.Statements[3]);
        Assert.IsType<LoweredPassStatement>(Assert.Single(ifStatement.ThenStatements));
        Assert.IsType<LoweredRaiseStatement>(Assert.Single(ifStatement.ElseStatements.RequireNotNull()));
    }

    [Fact]
    public void LoweredScript_LowersAssignmentExpressionsAndLoopElse()
    {
        var frontend = LythonFrontend.Compile("""
if (n := 1):
    pass

for item in [1]:
    pass
else:
    pass

while False:
    pass
else:
    pass
""",regexProvider:Utf8RegexProvider.Instance);

        var lowered = LoweredScript.Lower(frontend.Script.RequireNotNull());

        var ifStatement = Assert.IsType<LoweredIfStatement>(lowered.Statements[0]);
        var condition = Assert.IsType<LoweredParenthesizedExpression>(ifStatement.Condition);
        Assert.IsType<LoweredAssignmentExpression>(condition.Inner);

        var forStatement = Assert.IsType<LoweredForStatement>(lowered.Statements[1]);
        Assert.NotNull(forStatement.ElseStatements);
        Assert.Single(forStatement.ElseStatements.RequireNotNull());

        var whileStatement = Assert.IsType<LoweredWhileStatement>(lowered.Statements[2]);
        Assert.NotNull(whileStatement.ElseStatements);
        Assert.Single(whileStatement.ElseStatements.RequireNotNull());
    }

    [Fact]
    public void LoweredScript_LowersGeneratorsBytesNestedDefsAndMemberAssignments()
    {
        var frontend = LythonFrontend.Compile("""
def outer():
    def inner(*, suffix="!"):
        return (b"ab"[0], (x for x in [1, 2]), suffix)
    return inner

helper.value = b"x"
""",regexProvider:Utf8RegexProvider.Instance);

        var lowered = LoweredScript.Lower(frontend.Script.RequireNotNull());
        var outer = Assert.IsType<LoweredFunctionDefinitionStatement>(lowered.Statements[0]);
        var inner = Assert.IsType<LoweredFunctionDefinitionStatement>(outer.Body[0]);
        Assert.Equal(FunctionParameterKind.KeywordOnly, inner.Parameters[0].Kind);

        var returnStatement = Assert.IsType<LoweredReturnStatement>(inner.Body[0]);
        var tuple = Assert.IsType<LoweredTupleLiteralExpression>(returnStatement.Expression);
        Assert.IsType<LoweredBytesLiteralExpression>(Assert.IsType<LoweredSubscriptExpression>(tuple.Items[0].Expression).Target);
        Assert.IsType<LoweredGeneratorExpression>(tuple.Items[1].Expression);

        var assignment = Assert.IsType<LoweredMemberAssignmentStatement>(lowered.Statements[1]);
        Assert.Equal("value", assignment.Assignment.MemberName);
        Assert.IsType<LoweredBytesLiteralExpression>(assignment.Expression);
    }

    [Fact]
    public void LoweredScript_LowersUnparenthesizedTupleExpressionLists()
    {
        var frontend = LythonFrontend.Compile(
            """
value = 1, 2
return value, 3
""",regexProvider:Utf8RegexProvider.Instance);

        Assert.Empty(frontend.Diagnostics);
        var lowered = LoweredScript.Lower(frontend.Script.RequireNotNull());

        var assignment = Assert.IsType<LoweredNameAssignmentStatement>(lowered.Statements[0]);
        Assert.Equal(2, Assert.IsType<LoweredTupleLiteralExpression>(assignment.Expression).Items.Count);
        var returnStatement = Assert.IsType<LoweredReturnStatement>(lowered.Statements[1]);
        Assert.Equal(2, Assert.IsType<LoweredTupleLiteralExpression>(returnStatement.Expression).Items.Count);
    }

    [Fact]
    public void LoweredScript_RepresentsEveryAssignmentFormWithItsClosedVariant()
    {
        var frontend = LythonFrontend.Compile(
            """
value = 1
first = second = 2
annotated: int = 3
value += 4
items[0] += 5
items[1:2] += [6]
owner.member += 7
left, right = (8, 9)
items[0] = 10
items[1:2] = [11]
owner.member = 12
""",regexProvider:Utf8RegexProvider.Instance);

        Assert.Empty(frontend.Diagnostics);
        var statements = LoweredScript.Lower(frontend.Script.RequireNotNull()).Statements;

        Assert.IsType<LoweredNameAssignmentStatement>(statements[0]);
        Assert.IsType<LoweredChainedAssignmentStatement>(statements[1]);
        Assert.IsType<LoweredAnnotatedAssignmentStatement>(statements[2]);
        Assert.IsType<LoweredNameAugmentedAssignmentTarget>(Assert.IsType<LoweredAugmentedAssignmentStatement>(statements[3]).Target);
        Assert.IsType<LoweredSubscriptAugmentedAssignmentTarget>(Assert.IsType<LoweredAugmentedAssignmentStatement>(statements[4]).Target);
        Assert.IsType<LoweredSliceAugmentedAssignmentTarget>(Assert.IsType<LoweredAugmentedAssignmentStatement>(statements[5]).Target);
        Assert.IsType<LoweredMemberAugmentedAssignmentTarget>(Assert.IsType<LoweredAugmentedAssignmentStatement>(statements[6]).Target);
        Assert.IsType<LoweredUnpackingAssignmentStatement>(statements[7]);
        Assert.IsType<LoweredSubscriptAssignmentStatement>(statements[8]);
        Assert.IsType<LoweredSliceAssignmentStatement>(statements[9]);
        Assert.IsType<LoweredMemberAssignmentStatement>(statements[10]);
    }

    [Fact]
    public void LoweredScript_LowersMatchStatementsWithoutGenericFallback()
    {
        var frontend = LythonFrontend.Compile("""
import pathlib

match pathlib.Path("/docs/guide.md"):
    case pathlib.Path(name=name, suffix=suffix):
        value = name
    case _:
        value = suffix
""",regexProvider:Utf8RegexProvider.Instance);

        var lowered = LoweredScript.Lower(frontend.Script.RequireNotNull());
        var matchStatement = Assert.IsType<LoweredMatchStatement>(lowered.Statements[1]);
        Assert.IsType<LoweredCallExpression>(matchStatement.Subject);
        Assert.DoesNotContain(FlattenStatements(lowered.Statements), statement => statement is LoweredOtherStatement);
    }

    [Fact]
    public void LoweredScript_DoesNotUseGenericFallbacksForRepresentativeSupportedSubset()
    {
        var frontend = LythonFrontend.Compile("""
import json, re

def helper(xs, prefix="v"):
    total = 0
    for item in xs:
        total += item
    return f"{prefix}:{total}"

values = [helper([1, 2]), helper([3], prefix="x")]
mapping = {item: item.upper() for item in values if item}
assert values[0].startswith("v")
""",regexProvider:Utf8RegexProvider.Instance);

        var lowered = LoweredScript.Lower(frontend.Script.RequireNotNull());
        Assert.DoesNotContain(FlattenStatements(lowered.Statements), statement => statement is LoweredOtherStatement);
    }

    [Fact]
    public void LoweredScript_DoesNotUseGenericFallbacksForOrdinaryParserShapes()
    {
        var frontend = LythonFrontend.Compile("""
from __future__ import annotations

match = "alpha"
case = "beta"
value = "a" + \
    "b"

def helper(*parts, sep="|", suffix):
    typed: list[str] = ["x"]
    return sep.join(parts) + suffix + typed[0]

line = [match, case][0].upper().splitlines(True)[0]
result = helper(*["a", "b"], suffix="?")
""",regexProvider:Utf8RegexProvider.Instance);

        var lowered = LoweredScript.Lower(frontend.Script.RequireNotNull());
        Assert.DoesNotContain(FlattenStatements(lowered.Statements), statement => statement is LoweredOtherStatement);
    }

    [Fact]
    public void ExecutableScript_CompilesSimpleAssignmentsIntoLocalsAndConstants()
    {
        var frontend = LythonFrontend.Compile("""
x = 1
y = x + 2
y
""",regexProvider:Utf8RegexProvider.Instance);

        var lowered = LoweredScript.Lower(frontend.Script.RequireNotNull());
        var executable = ExecutableScript.Compile(lowered);
        var entry = executable.EntryPoint;

        Assert.Equal(["x", "y"], entry.LocalNames);
        Assert.Empty(entry.Names);
        Assert.Equal(2, entry.Constants.OfType<System.Numerics.BigInteger>().Count());
        Assert.Contains(new System.Numerics.BigInteger(1), entry.Constants);
        Assert.Contains(new System.Numerics.BigInteger(2), entry.Constants);

        var instructions = entry.Instructions;
        Assert.Collection(
            instructions,
            instruction =>
            {
                Assert.Equal(ExecutableOpCode.StoreLocal, instruction.OpCode);
                Assert.Equal(new System.Numerics.BigInteger(1), entry.Constants[~instruction.InputStart]);
            },
            instruction =>
            {
                Assert.Equal(ExecutableOpCode.Binary, instruction.OpCode);
                Assert.Equal(BinaryOperatorSyntax.Add, instruction.BinaryOperator);
                Assert.Equal(new System.Numerics.BigInteger(2), entry.Constants[~instruction.SecondInput]);
            },
            instruction => Assert.Equal(ExecutableOpCode.StoreLocal, instruction.OpCode),
            instruction => Assert.Equal(ExecutableOpCode.LoadLocal, instruction.OpCode),
            instruction => Assert.Equal(ExecutableOpCode.PopTop, instruction.OpCode),
            instruction => Assert.Equal(ExecutableOpCode.Complete, instruction.OpCode));
    }

    [Fact]
    public void ExecutableScript_TypesAugmentedAndSliceInstructionPayloads()
    {
        var frontend = LythonFrontend.Compile("""
total = 1
total += 2
values = [0, 1, 2, 3, 4]
values[1:4:2]
""",regexProvider:Utf8RegexProvider.Instance);

        var lowered = LoweredScript.Lower(frontend.Script.RequireNotNull());
        var executable = ExecutableScript.Compile(lowered);
        var instructions = executable.EntryPoint.Instructions.ToArray();

        var augmented = Assert.Single(instructions, instruction => instruction.OpCode == ExecutableOpCode.Augmented);
        Assert.Equal(ExecutableAugmentedOperator.Add, augmented.AugmentedOperator);

        var slice = Assert.Single(instructions, instruction => instruction.OpCode == ExecutableOpCode.Slice);
        Assert.Equal(
            ExecutableSliceParts.Start | ExecutableSliceParts.End | ExecutableSliceParts.Step,
            slice.SliceParts);
    }

    [Fact]
    public void ExecutableScript_InternsLargeConstantTablesWithoutChangingOrder()
    {
        var source = string.Join(
            Environment.NewLine,
            Enumerable.Range(0, 4_000)
                .Select(index => $"value_{index} = \"constant-{index}\"")
                .Append("duplicate = \"constant-0\""));

        var frontend = LythonFrontend.Compile(source,regexProvider:Utf8RegexProvider.Instance);
        var lowered = LoweredScript.Lower(frontend.Script.RequireNotNull());
        var executable = ExecutableScript.Compile(lowered);

        Assert.Equal(4_000, executable.EntryPoint.Constants.Count);
        Assert.Equal(PyString.FromString("constant-0"), executable.EntryPoint.Constants[0]);
        Assert.Equal(PyString.FromString("constant-3999"), executable.EntryPoint.Constants[^1]);
    }

    [Fact]
    public void ExecutableScript_CompilesConditionalAndLoopControlFlow()
    {
        var frontend = LythonFrontend.Compile("""
count = 0
if ready:
    count = count + 1
else:
    count = count + 2

while count:
    count = count - 1
else:
    count = 99
""",regexProvider:Utf8RegexProvider.Instance);

        var lowered = LoweredScript.Lower(frontend.Script.RequireNotNull());
        var executable = ExecutableScript.Compile(lowered);
        var entry = executable.EntryPoint;

        Assert.Equal(["count"], entry.LocalNames);
        Assert.Contains(entry.Instructions, instruction => instruction.OpCode == ExecutableOpCode.JumpIfFalse);
        Assert.Contains(entry.Instructions, instruction => instruction.OpCode == ExecutableOpCode.Jump);
        Assert.Contains(entry.Instructions, instruction =>
            instruction.OpCode == ExecutableOpCode.Binary && instruction.BinaryOperator == BinaryOperatorSyntax.Subtract);
    }

    [Fact]
    public void ExecutableScript_NormalizesJumpChainsAndPrunesDeadBlocks()
    {
        var frontend = LythonFrontend.Compile("""
if True:
    value = 1
else:
    value = 2

return value
""",regexProvider:Utf8RegexProvider.Instance);

        var lowered = LoweredScript.Lower(frontend.Script.RequireNotNull());
        var executable = ExecutableScript.Compile(lowered);

        Assert.DoesNotContain(
            executable.EntryPoint.Instructions,
            instruction => instruction.OpCode == ExecutableOpCode.Jump &&
                           executable.EntryPoint.Instructions[instruction.TargetIndex].OpCode == ExecutableOpCode.Jump);
    }

    [Fact]
    public void ExecutableScript_CompilesClassDefinitionFallback()
    {
        var frontend = LythonFrontend.Compile("""
class Box:
    pass
""",regexProvider:Utf8RegexProvider.Instance);

        var lowered = LoweredScript.Lower(frontend.Script.RequireNotNull());
        var executable = ExecutableScript.Compile(lowered);

        Assert.NotEmpty(executable.EntryPoint.StatementFallbacks);
    }

    [Fact]
    public void ExecutableSubsetScript_ExecutesThroughExecutablePipeline()
    {
        var frontend = LythonFrontend.Compile("""
count = 0
if ready:
    count = count + 1
else:
    count = count + 2

while count > 1:
    count = count - 1

return count
""",regexProvider:Utf8RegexProvider.Instance);

        var lowered = LoweredScript.Lower(frontend.Script.RequireNotNull());
        var executable = ExecutableScript.Compile(lowered);
        var result = new LythonRuntime().Run(
            executable,
            new MockLythonHost(),
            new LythonRunOptions
            {
                Globals = new Dictionary<string, object?> { ["ready"] = true }
            });

        Assert.True(result.Success, result.Failure?.Message);
        Assert.Equal(new System.Numerics.BigInteger(1), result.ReturnValue);
    }

    [Fact]
    public void ExecutableSubset_ForLoopBreakContinueAndElse_ExecuteThroughExecutablePipeline()
    {
        var frontend = LythonFrontend.Compile("""
total = 0
for item in [1, 2, 3, 4]:
    if item == 2:
        continue
    if item == 4:
        break
    total = total + item
else:
    total = 99

return total
""",regexProvider:Utf8RegexProvider.Instance);

        var lowered = LoweredScript.Lower(frontend.Script.RequireNotNull());
        var executable = ExecutableScript.Compile(lowered);
        var result = new LythonRuntime().Run(executable, new MockLythonHost(), null);

        Assert.True(result.Success, result.Failure?.Message);
        Assert.Equal(new System.Numerics.BigInteger(4), result.ReturnValue);
    }

    [Fact]
    public void ExecutableSubset_BuiltinCall_ExecutesThroughExecutablePipeline()
    {
        var frontend = LythonFrontend.Compile("""
return len([1, 2, 3])
""",regexProvider:Utf8RegexProvider.Instance);

        var lowered = LoweredScript.Lower(frontend.Script.RequireNotNull());
        var executable = ExecutableScript.Compile(lowered);
        var result = new LythonRuntime().Run(executable, new MockLythonHost(), null);

        Assert.True(result.Success, result.Failure?.Message);
        Assert.Equal(new System.Numerics.BigInteger(3), result.ReturnValue);
    }

    [Fact]
    public void ExecutableSubset_ImportMemberCall_ExecutesThroughExecutablePipeline()
    {
        var frontend = LythonFrontend.Compile("""
import math
return math.sqrt(9)
""",regexProvider:Utf8RegexProvider.Instance);

        var lowered = LoweredScript.Lower(frontend.Script.RequireNotNull());
        var executable = ExecutableScript.Compile(lowered);
        Assert.True(executable.EntryPoint.MemberCacheCount > 0);
        Assert.Single(executable.EntryPoint.CallSites);
        var result = new LythonRuntime().Run(executable, new MockLythonHost(), null);

        Assert.True(result.Success, result.Failure?.Message);
        Assert.Equal(3.0, result.ReturnValue);
    }

    [Fact]
    public void ExecutableSubset_DictTupleAndSubscript_ExecuteThroughExecutablePipeline()
    {
        var frontend = LythonFrontend.Compile("""
payload = {"items": (1, 2, 3)}
return payload["items"][1]
""",regexProvider:Utf8RegexProvider.Instance);

        var lowered = LoweredScript.Lower(frontend.Script.RequireNotNull());
        var executable = ExecutableScript.Compile(lowered);
        var result = new LythonRuntime().Run(executable, new MockLythonHost(), null);

        Assert.True(result.Success, result.Failure?.Message);
        Assert.Equal(new System.Numerics.BigInteger(2), result.ReturnValue);
    }

    [Fact]
    public void ExecutableSubset_SetLiteralAndSlice_ExecuteThroughExecutablePipeline()
    {
        var frontend = LythonFrontend.Compile("""
ok = 2 in {1, 2, 3}
part = [1, 2, 3, 4][1:3]
value = part[0] + part[1]
if ok:
    return value
return 0
""",regexProvider:Utf8RegexProvider.Instance);

        var lowered = LoweredScript.Lower(frontend.Script.RequireNotNull());
        var executable = ExecutableScript.Compile(lowered);
        var result = new LythonRuntime().Run(executable, new MockLythonHost(), null);

        Assert.True(result.Success, result.Failure?.Message);
        Assert.Equal(new System.Numerics.BigInteger(5), result.ReturnValue);
    }

    [Fact]
    public void ExecutableSubset_AugmentedAndChainedAssignments_ExecuteThroughExecutablePipeline()
    {
        var frontend = LythonFrontend.Compile("""
a = b = 1
a += 2
return a + b
""",regexProvider:Utf8RegexProvider.Instance);

        var lowered = LoweredScript.Lower(frontend.Script.RequireNotNull());
        var executable = ExecutableScript.Compile(lowered);
        var result = new LythonRuntime().Run(executable, new MockLythonHost(), null);

        Assert.True(result.Success, result.Failure?.Message);
        Assert.Equal(new System.Numerics.BigInteger(4), result.ReturnValue);
    }

    [Fact]
    public void ExecutableSubset_UnpackingAssignments_ExecuteThroughExecutablePipeline()
    {
        var frontend = LythonFrontend.Compile("""
first, *middle, last = [1, 2, 3, 4]
return first + len(middle) + last
""",regexProvider:Utf8RegexProvider.Instance);

        var lowered = LoweredScript.Lower(frontend.Script.RequireNotNull());
        var executable = ExecutableScript.Compile(lowered);
        var result = new LythonRuntime().Run(executable, new MockLythonHost(), null);

        Assert.True(result.Success, result.Failure?.Message);
        Assert.Equal(new System.Numerics.BigInteger(7), result.ReturnValue);
    }

    [Fact]
    public void ExecutableSubset_FunctionDefinitions_ExecuteThroughExecutablePipeline()
    {
        var frontend = LythonFrontend.Compile("""
def helper(value, step=1):
    return value + step

return helper(2)
""",regexProvider:Utf8RegexProvider.Instance);

        var lowered = LoweredScript.Lower(frontend.Script.RequireNotNull());
        var executable = ExecutableScript.Compile(lowered);
        Assert.Single(executable.EntryPoint.Functions);
        Assert.NotNull(executable.EntryPoint.Functions[0].CodeObject);
        var result = new LythonRuntime().Run(executable, new MockLythonHost(), null);

        Assert.True(result.Success, result.Failure?.Message);
        Assert.Equal(new System.Numerics.BigInteger(3), result.ReturnValue);
    }

    [Fact]
    public void ExecutableSubset_NestedExecutableFunctions_ExecuteThroughExecutablePipeline()
    {
        var frontend = LythonFrontend.Compile("""
def outer(value):
    def inner(step=2):
        return value + step
    return inner()

return outer(3)
""",regexProvider:Utf8RegexProvider.Instance);

        var lowered = LoweredScript.Lower(frontend.Script.RequireNotNull());
        var executable = ExecutableScript.Compile(lowered);
        Assert.Single(executable.EntryPoint.Functions);
        Assert.NotNull(executable.EntryPoint.Functions[0].CodeObject);
        var result = new LythonRuntime().Run(executable, new MockLythonHost(), null);

        Assert.True(result.Success, result.Failure?.Message);
        Assert.Equal(new System.Numerics.BigInteger(5), result.ReturnValue);
    }

    [Fact]
    public void ExecutableSubset_NestedExecutableFunctions_UseClosureSlots()
    {
        var frontend = LythonFrontend.Compile("""
def outer(value):
    def inner():
        return value
    value = value + 1
    return inner()

return outer(3)
""",regexProvider:Utf8RegexProvider.Instance);

        var lowered = LoweredScript.Lower(frontend.Script.RequireNotNull());
        var executable = ExecutableScript.Compile(lowered);
        var outer = Assert.Single(executable.EntryPoint.Functions);
        var inner = Assert.Single(outer.CodeObject.RequireNotNull().Functions);
        var innerCode = inner.CodeObject.RequireNotNull();

        Assert.Equal(["value"], innerCode.ClosureNames);
        Assert.Contains(
            innerCode.Instructions,
            instruction => instruction.OpCode == ExecutableOpCode.LoadClosure);

        var result = new LythonRuntime().Run(executable, new MockLythonHost(), null);

        Assert.True(result.Success, result.Failure?.Message);
        Assert.Equal(new System.Numerics.BigInteger(4), result.ReturnValue);
    }

    [Fact]
    public void ExecutableSubset_TryExceptElseFinally_ExecutesThroughExecutablePipeline()
    {
        var frontend = LythonFrontend.Compile("""
value = 0
try:
    value = 1
except ValueError:
    value = 2
else:
    value = value + 3
finally:
    value = value + 4

return value
""",regexProvider:Utf8RegexProvider.Instance);

        var lowered = LoweredScript.Lower(frontend.Script.RequireNotNull());
        var executable = ExecutableScript.Compile(lowered);

        Assert.NotEmpty(executable.EntryPoint.ExceptionRegions);

        var result = new LythonRuntime().Run(executable, new MockLythonHost(), null);

        Assert.True(result.Success, result.Failure?.Message);
        Assert.Equal(new System.Numerics.BigInteger(8), result.ReturnValue);
    }

    [Fact]
    public void ExecutableSubset_TryExceptFinally_CatchesExceptionsThroughExecutableRegions()
    {
        var frontend = LythonFrontend.Compile("""
value = 0
try:
    raise ValueError("boom")
except ValueError as ex:
    value = len(ex.message)
finally:
    value = value + 1

return value
""",regexProvider:Utf8RegexProvider.Instance);

        var lowered = LoweredScript.Lower(frontend.Script.RequireNotNull());
        var executable = ExecutableScript.Compile(lowered);
        var result = new LythonRuntime().Run(executable, new MockLythonHost(), null);

        Assert.True(result.Success, result.Failure?.Message);
        Assert.Equal(new System.Numerics.BigInteger(5), result.ReturnValue);
    }

    [Fact]
    public void ExecutableSubset_UnmatchedInnerHandlerContinuesToOuterHandler()
    {
        var frontend = LythonFrontend.Compile("""
value = "unhandled"
try:
    try:
        raise ValueError("boom")
    except TypeError:
        value = "inner"
except Exception:
    value = "outer"

return value
""",regexProvider:Utf8RegexProvider.Instance);

        var lowered = LoweredScript.Lower(frontend.Script.RequireNotNull());
        var executable = ExecutableScript.Compile(lowered);
        var result = new LythonRuntime().Run(executable, new MockLythonHost(), null);

        Assert.True(result.Success, result.Failure?.Message);
        Assert.Equal("outer", result.ReturnValue);
    }

    [Fact]
    public void ExecutableSubset_ExceptionHandlersRestoreEnclosingLoopStackDepth()
    {
        var frontend = LythonFrontend.Compile("""
values = []
for value in [0, 1]:
    try:
        values.append(str(4 // value))
    except ZeroDivisionError as ex:
        values.append(ex.type)
return "|".join(values)
""",regexProvider:Utf8RegexProvider.Instance);

        var lowered = LoweredScript.Lower(frontend.Script.RequireNotNull());
        var executable = ExecutableScript.Compile(lowered);
        var result = new LythonRuntime().Run(executable, new MockLythonHost(), null);

        Assert.True(result.Success, result.Failure?.Message);
        Assert.Equal("ZeroDivisionError|4", result.ReturnValue);
    }

    [Fact]
    public void ExecutableSubset_TryFinally_HonorsReturnThroughExecutableRegions()
    {
        var frontend = LythonFrontend.Compile("""
try:
    return 1
finally:
    marker = 2
""",regexProvider:Utf8RegexProvider.Instance);

        var lowered = LoweredScript.Lower(frontend.Script.RequireNotNull());
        var executable = ExecutableScript.Compile(lowered);
        var result = new LythonRuntime().Run(executable, new MockLythonHost(), null);

        Assert.True(result.Success, result.Failure?.Message);
        Assert.Equal(new System.Numerics.BigInteger(1), result.ReturnValue);
    }

    [Fact]
    public void ExecutableSubset_WithStatement_ExecutesThroughExecutablePipeline()
    {
        var frontend = LythonFrontend.Compile("""
with open("/sample.txt", "w") as handle:
    handle.write("alpha")

return open("/sample.txt").read()
""",regexProvider:Utf8RegexProvider.Instance);

        var lowered = LoweredScript.Lower(frontend.Script.RequireNotNull());
        var executable = ExecutableScript.Compile(lowered);
        var result = new LythonRuntime().Run(executable, new MockLythonHost(), null);

        Assert.True(result.Success, result.Failure?.Message);
        Assert.Equal("alpha", result.ReturnValue);
    }

    [Fact]
    public void ExecutableSubset_WithStatement_InvokesUnsuppressingExitOnce()
    {
        var frontend = LythonFrontend.Compile("""
events = []

class Manager:
    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc, traceback):
        events.append(exc_type.__name__)
        return False

try:
    with Manager():
        raise ValueError("boom")
except ValueError:
    events.append("caught")

return "|".join(events)
""",regexProvider:Utf8RegexProvider.Instance);

        var lowered = LoweredScript.Lower(frontend.Script.RequireNotNull());
        var executable = ExecutableScript.Compile(lowered);
        var result = new LythonRuntime().Run(executable, new MockLythonHost(), null);

        Assert.True(result.Success, result.Failure?.Message);
        Assert.Equal("ValueError|caught", result.ReturnValue);
    }

    [Fact]
    public void ExecutableSubset_MatchStatement_ExecutesThroughExecutablePipeline()
    {
        var frontend = LythonFrontend.Compile("""
def choose(value):
    match value:
        case {"x": x, "y": y} if x < y:
            return x + y
        case _:
            return 0

return choose({"x": 2, "y": 5})
""",regexProvider:Utf8RegexProvider.Instance);

        var lowered = LoweredScript.Lower(frontend.Script.RequireNotNull());
        var executable = ExecutableScript.Compile(lowered);
        var result = new LythonRuntime().Run(executable, new MockLythonHost(), null);

        Assert.True(result.Success, result.Failure?.Message);
        Assert.Equal(new System.Numerics.BigInteger(7), result.ReturnValue);
    }

    [Fact]
    public void ExecutableSubset_StarredCalls_ExecuteThroughFallbackInsideExecutablePipeline()
    {
        var frontend = LythonFrontend.Compile("""
return sorted(*[[3, 1, 2]], reverse=True)
""",regexProvider:Utf8RegexProvider.Instance);

        var lowered = LoweredScript.Lower(frontend.Script.RequireNotNull());
        var executable = ExecutableScript.Compile(lowered);
        var result = new LythonRuntime().Run(executable, new MockLythonHost(), null);

        Assert.True(result.Success, result.Failure?.Message);
        Assert.Equal(new object?[] { new System.Numerics.BigInteger(3), new System.Numerics.BigInteger(2), new System.Numerics.BigInteger(1) }, result.ReturnValue);
    }

    [Fact]
    public void Engine_FallsBackToLoweredInterpreter_WhenExecutableIrIsNotAvailable()
    {
        var result = new LythonEngine(Utf8RegexProvider.Instance).Run("""
def helper():
    return 7

return helper()
""", new MockLythonHost());

        Assert.True(result.Success, result.Failure?.Message);
        Assert.Equal(new System.Numerics.BigInteger(7), result.ReturnValue);
    }

    [Fact]
    public void Engine_UsesExecutablePipeline_ForStarredCallViaFallbackExpression()
    {
        var result = new LythonEngine(Utf8RegexProvider.Instance).Run("""
return len(sorted(*[[3, 1, 2]], reverse=True))
""", new MockLythonHost());

        Assert.True(result.Success, result.Failure?.Message);
        Assert.Equal(new System.Numerics.BigInteger(3), result.ReturnValue);
    }

    [Fact]
    public void ExecutableSubset_TupleForLoopTarget_ExecutesThroughExecutablePipeline()
    {
        var frontend = LythonFrontend.Compile("""
total = 0
for left, right in [(1, 2), (3, 4)]:
    total = total + left + right

return total
""",regexProvider:Utf8RegexProvider.Instance);

        var lowered = LoweredScript.Lower(frontend.Script.RequireNotNull());
        var executable = ExecutableScript.Compile(lowered);
        var result = new LythonRuntime().Run(executable, new MockLythonHost(), null);

        Assert.True(result.Success, result.Failure?.Message);
        Assert.Equal(new System.Numerics.BigInteger(10), result.ReturnValue);
    }

    [Fact]
    public void SupportedSubsetScript_ExecutesThroughLoweredPipelineWithoutFallbacks()
    {
        var result = new LythonEngine(Utf8RegexProvider.Instance).Run("""
import json

def helper(values, suffix="!"):
    total = 0
    for value in values:
        if value % 2 == 0:
            continue
        total += value
    return f"{total}{suffix}"

payload = {"items": [1, 2, 3], "ok": True}
text = json.dumps(payload)
return helper(payload["items"]) + "|" + text
""", new MockLythonHost());

        Assert.True(result.Success, result.Failure?.Message);
        Assert.Equal("4!|{\"items\": [1, 2, 3], \"ok\": true}", result.ReturnValue);
    }

    private static IEnumerable<LoweredStatement> FlattenStatements(IEnumerable<LoweredStatement> statements)
    {
        foreach (var statement in statements)
        {
            yield return statement;
            switch (statement)
            {
                case LoweredFunctionDefinitionStatement functionDefinition:
                    foreach (var nested in FlattenStatements(functionDefinition.Body))
                    {
                        yield return nested;
                    }
                    break;
                case LoweredIfStatement ifStatement:
                    foreach (var nested in FlattenStatements(ifStatement.ThenStatements))
                    {
                        yield return nested;
                    }

                    if (ifStatement.ElseStatements is not null)
                    {
                        foreach (var nested in FlattenStatements(ifStatement.ElseStatements))
                        {
                            yield return nested;
                        }
                    }
                    break;
                case LoweredForStatement forStatement:
                    foreach (var nested in FlattenStatements(forStatement.Body))
                    {
                        yield return nested;
                    }
                    if (forStatement.ElseStatements is not null)
                    {
                        foreach (var nested in FlattenStatements(forStatement.ElseStatements))
                        {
                            yield return nested;
                        }
                    }
                    break;
                case LoweredWhileStatement whileStatement:
                    foreach (var nested in FlattenStatements(whileStatement.Body))
                    {
                        yield return nested;
                    }
                    if (whileStatement.ElseStatements is not null)
                    {
                        foreach (var nested in FlattenStatements(whileStatement.ElseStatements))
                        {
                            yield return nested;
                        }
                    }
                    break;
                case LoweredWithStatement withStatement:
                    foreach (var nested in FlattenStatements(withStatement.Body))
                    {
                        yield return nested;
                    }
                    break;
                case LoweredTryStatement tryStatement:
                    foreach (var nested in FlattenStatements(tryStatement.TryBody))
                    {
                        yield return nested;
                    }

                    foreach (var exceptClause in tryStatement.ExceptClauses)
                    {
                        foreach (var nested in FlattenStatements(exceptClause.Body))
                        {
                            yield return nested;
                        }
                    }

                    if (tryStatement.ElseBody is not null)
                    {
                        foreach (var nested in FlattenStatements(tryStatement.ElseBody))
                        {
                            yield return nested;
                        }
                    }

                    if (tryStatement.FinallyBody is not null)
                    {
                        foreach (var nested in FlattenStatements(tryStatement.FinallyBody))
                        {
                            yield return nested;
                        }
                    }
                    break;
            }
        }
    }

    private static IEnumerable<LoweredExpression> FlattenExpressions(IEnumerable<LoweredStatement> statements)
    {
        foreach (var statement in FlattenStatements(statements))
        {
            switch (statement)
            {
                case LoweredFunctionDefinitionStatement functionDefinition:
                    foreach (var parameter in functionDefinition.Parameters)
                    {
                        if (parameter.DefaultValue is not null)
                        {
                            foreach (var expression in FlattenExpressions(parameter.DefaultValue))
                            {
                                yield return expression;
                            }
                        }
                    }
                    break;
                case LoweredAssignmentStatement assignment:
                    foreach (var loweredExpression in GetAssignmentExpressions(assignment))
                    {
                        foreach (var expression in FlattenExpressions(loweredExpression))
                        {
                            yield return expression;
                        }
                    }
                    break;
                case LoweredExpressionStatement expressionStatement:
                    foreach (var expression in FlattenExpressions(expressionStatement.Expression))
                    {
                        yield return expression;
                    }
                    break;
                case LoweredIfStatement ifStatement:
                    foreach (var expression in FlattenExpressions(ifStatement.Condition))
                    {
                        yield return expression;
                    }
                    break;
                case LoweredForStatement forStatement:
                    foreach (var expression in FlattenExpressions(forStatement.Iterable))
                    {
                        yield return expression;
                    }
                    break;
                case LoweredWhileStatement whileStatement:
                    foreach (var expression in FlattenExpressions(whileStatement.Condition))
                    {
                        yield return expression;
                    }
                    break;
                case LoweredWithStatement withStatement:
                    foreach (var expression in FlattenExpressions(withStatement.ContextExpression))
                    {
                        yield return expression;
                    }
                    break;
                case LoweredAssertStatement assertStatement:
                    foreach (var expression in FlattenExpressions(assertStatement.Condition))
                    {
                        yield return expression;
                    }

                    if (assertStatement.Message is not null)
                    {
                        foreach (var expression in FlattenExpressions(assertStatement.Message))
                        {
                            yield return expression;
                        }
                    }
                    break;
                case LoweredDeleteStatement deleteStatement:
                    foreach (var expression in FlattenExpressions(deleteStatement.Target))
                    {
                        yield return expression;
                    }
                    break;
                case LoweredReturnStatement returnStatement when returnStatement.Expression is not null:
                    foreach (var expression in FlattenExpressions(returnStatement.Expression))
                    {
                        yield return expression;
                    }
                    break;
                case LoweredRaiseStatement raiseStatement when raiseStatement.Expression is not null:
                    foreach (var expression in FlattenExpressions(raiseStatement.Expression))
                    {
                        yield return expression;
                    }
                    break;
            }
        }
    }

    private static IEnumerable<LoweredExpression> GetAssignmentExpressions(LoweredAssignmentStatement assignment)
    {
        switch (assignment)
        {
            case LoweredNameAssignmentStatement name:
                yield return name.Expression;
                break;
            case LoweredChainedAssignmentStatement chained:
                yield return chained.Expression;
                break;
            case LoweredAnnotatedAssignmentStatement annotated:
                yield return annotated.Annotation;
                if (annotated.Expression is not null)
                {
                    yield return annotated.Expression;
                }
                break;
            case LoweredAugmentedAssignmentStatement augmented:
                foreach (var expression in GetAugmentedTargetExpressions(augmented.Target))
                {
                    yield return expression;
                }
                yield return augmented.Expression;
                break;
            case LoweredUnpackingAssignmentStatement unpacking:
                yield return unpacking.Expression;
                break;
            case LoweredSubscriptAssignmentStatement subscript:
                yield return subscript.Receiver;
                yield return subscript.Index;
                yield return subscript.Expression;
                break;
            case LoweredSliceAssignmentStatement slice:
                yield return slice.Receiver;
                if (slice.Start is not null)
                {
                    yield return slice.Start;
                }
                if (slice.End is not null)
                {
                    yield return slice.End;
                }
                if (slice.Step is not null)
                {
                    yield return slice.Step;
                }
                yield return slice.Expression;
                break;
            case LoweredMemberAssignmentStatement member:
                yield return member.Receiver;
                yield return member.Expression;
                break;
        }
    }

    private static IEnumerable<LoweredExpression> GetAugmentedTargetExpressions(LoweredAugmentedAssignmentTarget target)
    {
        switch (target)
        {
            case LoweredSubscriptAugmentedAssignmentTarget subscript:
                yield return subscript.Receiver;
                yield return subscript.Index;
                break;
            case LoweredSliceAugmentedAssignmentTarget slice:
                yield return slice.Receiver;
                if (slice.Start is not null)
                {
                    yield return slice.Start;
                }
                if (slice.End is not null)
                {
                    yield return slice.End;
                }
                if (slice.Step is not null)
                {
                    yield return slice.Step;
                }
                break;
            case LoweredMemberAugmentedAssignmentTarget member:
                yield return member.Receiver;
                break;
        }
    }

    private static IEnumerable<LoweredExpression> FlattenExpressions(LoweredExpression expression)
    {
        yield return expression;

        switch (expression)
        {
            case LoweredFormattedStringExpression formatted:
                foreach (var part in formatted.Parts.OfType<LoweredFormattedStringExpressionPart>())
                {
                    foreach (var nested in FlattenExpressions(part.Expression))
                    {
                        yield return nested;
                    }
                }
                break;
            case LoweredParenthesizedExpression parenthesized:
                foreach (var nested in FlattenExpressions(parenthesized.Inner))
                {
                    yield return nested;
                }
                break;
            case LoweredListLiteralExpression list:
                foreach (var item in list.Items.SelectMany(static item => FlattenExpressions(item.Expression)))
                {
                    yield return item;
                }
                break;
            case LoweredTupleLiteralExpression tuple:
                foreach (var item in tuple.Items.SelectMany(static item => FlattenExpressions(item.Expression)))
                {
                    yield return item;
                }
                break;
            case LoweredSetLiteralExpression set:
                foreach (var item in set.Items.SelectMany(static item => FlattenExpressions(item.Expression)))
                {
                    yield return item;
                }
                break;
            case LoweredListComprehensionExpression listComprehension:
                foreach (var nested in FlattenExpressions(listComprehension.ItemExpression))
                {
                    yield return nested;
                }
                foreach (var clause in listComprehension.Clauses)
                {
                    foreach (var nested in FlattenExpressions(clause.Iterable))
                    {
                        yield return nested;
                    }
                    if (clause.Condition is not null)
                    {
                        foreach (var nested in FlattenExpressions(clause.Condition))
                        {
                            yield return nested;
                        }
                    }
                }
                break;
            case LoweredSetComprehensionExpression setComprehension:
                foreach (var nested in FlattenExpressions(setComprehension.ItemExpression))
                {
                    yield return nested;
                }
                foreach (var clause in setComprehension.Clauses)
                {
                    foreach (var nested in FlattenExpressions(clause.Iterable))
                    {
                        yield return nested;
                    }
                    if (clause.Condition is not null)
                    {
                        foreach (var nested in FlattenExpressions(clause.Condition))
                        {
                            yield return nested;
                        }
                    }
                }
                break;
            case LoweredGeneratorExpression generator:
                foreach (var nested in FlattenExpressions(generator.ItemExpression))
                {
                    yield return nested;
                }
                foreach (var clause in generator.Clauses)
                {
                    foreach (var nested in FlattenExpressions(clause.Iterable))
                    {
                        yield return nested;
                    }
                    if (clause.Condition is not null)
                    {
                        foreach (var nested in FlattenExpressions(clause.Condition))
                        {
                            yield return nested;
                        }
                    }
                }
                break;
            case LoweredDictLiteralExpression dict:
                foreach (var pair in dict.Items)
                {
                    foreach (var nested in FlattenExpressions(pair.Key))
                    {
                        yield return nested;
                    }
                    foreach (var nested in FlattenExpressions(pair.Value))
                    {
                        yield return nested;
                    }
                }
                break;
            case LoweredDictComprehensionExpression dictComprehension:
                foreach (var nested in FlattenExpressions(dictComprehension.KeyExpression))
                {
                    yield return nested;
                }
                foreach (var nested in FlattenExpressions(dictComprehension.ValueExpression))
                {
                    yield return nested;
                }
                foreach (var clause in dictComprehension.Clauses)
                {
                    foreach (var nested in FlattenExpressions(clause.Iterable))
                    {
                        yield return nested;
                    }
                    if (clause.Condition is not null)
                    {
                        foreach (var nested in FlattenExpressions(clause.Condition))
                        {
                            yield return nested;
                        }
                    }
                }
                break;
            case LoweredMemberExpression member:
                foreach (var nested in FlattenExpressions(member.Target))
                {
                    yield return nested;
                }
                break;
            case LoweredCallExpression call:
                foreach (var nested in FlattenExpressions(call.Target))
                {
                    yield return nested;
                }
                foreach (var argument in call.Arguments.SelectMany(argument => FlattenExpressions(argument.Expression)))
                {
                    yield return argument;
                }
                break;
            case LoweredSubscriptExpression subscript:
                foreach (var nested in FlattenExpressions(subscript.Target))
                {
                    yield return nested;
                }
                foreach (var nested in FlattenExpressions(subscript.Index))
                {
                    yield return nested;
                }
                break;
            case LoweredSliceExpression slice:
                foreach (var nested in FlattenExpressions(slice.Target))
                {
                    yield return nested;
                }
                if (slice.Start is not null)
                {
                    foreach (var nested in FlattenExpressions(slice.Start))
                    {
                        yield return nested;
                    }
                }
                if (slice.End is not null)
                {
                    foreach (var nested in FlattenExpressions(slice.End))
                    {
                        yield return nested;
                    }
                }
                if (slice.Step is not null)
                {
                    foreach (var nested in FlattenExpressions(slice.Step))
                    {
                        yield return nested;
                    }
                }
                break;
            case LoweredBinaryExpression binary:
                foreach (var nested in FlattenExpressions(binary.Left))
                {
                    yield return nested;
                }
                foreach (var nested in FlattenExpressions(binary.Right))
                {
                    yield return nested;
                }
                break;
            case LoweredChainedComparisonExpression chained:
                foreach (var nested in chained.Operands.SelectMany(FlattenExpressions))
                {
                    yield return nested;
                }
                break;
            case LoweredUnaryExpression unary:
                foreach (var nested in FlattenExpressions(unary.Operand))
                {
                    yield return nested;
                }
                break;
            case LoweredConditionalExpression conditional:
                foreach (var nested in FlattenExpressions(conditional.Consequent))
                {
                    yield return nested;
                }
                foreach (var nested in FlattenExpressions(conditional.Condition))
                {
                    yield return nested;
                }
                foreach (var nested in FlattenExpressions(conditional.Alternative))
                {
                    yield return nested;
                }
                break;
            case LoweredLambdaExpression lambda:
                foreach (var nested in FlattenExpressions(lambda.Body))
                {
                    yield return nested;
                }
                break;
        }
    }
}
