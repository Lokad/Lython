from pathlib import Path
import re

root=Path('.git/agent-worktrees/eager-expression-emission/src/Lokad.Lython/Frontend')
def change(name,edit):
    file=root/f'ExecutableScript.{name}.cs'
    before=file.read_text(encoding='utf-8')
    after=edit(before)
    assert after!=before,file
    file.write_text(after,encoding='utf-8',newline='\n')

def expressions(text):
    old='''        private int CompileExpression(ExpressionSyntax expression, int currentBlock)
            => CompileExpression(LoweredScript.LowerExpression(expression), currentBlock);

        private int CompileExpression(LoweredExpression expression, int currentBlock)'''
    new='''        private int CompileExpression(LoweredExpression expression, int currentBlock)
            => CompileExpression(expression.Syntax, currentBlock);

        private int CompileExpression(ExpressionSyntax expression, int currentBlock)'''
    assert old in text
    text=text.replace(old,new)
    mapping='UnpackedType Yield Parenthesized StringLiteral FormattedString Lambda BytesLiteral IntegerLiteral ImaginaryLiteral FloatLiteral BooleanLiteral NoneLiteral EllipsisLiteral Identifier Member Call ListComprehension Generator SetComprehension DictComprehension ListLiteral TupleLiteral SetLiteral DictLiteral Subscript Slice SliceValue Binary Unary Conditional ChainedComparison Assignment'.split()
    pattern=re.compile(r'\bLowered('+'|'.join(mapping)+r')Expression\b')
    text=pattern.sub(r'\1ExpressionSyntax',text)
    for old,new in {
        'yielded.Yield.Delegated':'yielded.Delegated',
        'CompileLambda(lambda, currentBlock)':'CompileLambda((LoweredLambdaExpression)LoweredScript.LowerExpression(lambda), currentBlock)',
        'CompileGeneratorExpression(generator, currentBlock)':'CompileGeneratorExpression(generator, currentBlock)',
        'InternConstant(text.Value)':'InternConstant(PyString.FromString(text.Value))',
        'InternConstant(bytes.Value)':'InternConstant(new PyBytes(bytes.Value.ToArray()))',
        'imaginary.ImaginaryPart':'imaginary.Value',
        'boolean.Literal.Value':'boolean.Value',
        'identifier.Identifier.Name':'identifier.Name',
        'member.Member.MemberName':'member.MemberName',
        'member.MemberName':'member.MemberName',
        'Member.MemberName:':'MemberName:',
        'list.List.HasUnpacking':'list.HasUnpacking',
        'tuple.Tuple.HasUnpacking':'tuple.HasUnpacking',
        'set.Set.HasUnpacking':'set.HasUnpacking',
        'InternConstant(((StringLiteralExpressionSyntax)item.Key).Value)':'InternConstant(PyString.FromString(((StringLiteralExpressionSyntax)item.Key).Value))',
        'binary.Binary.Operator':'binary.Operator',
        'binary.Binary.Span':'binary.Span',
        'unary.Unary.Operator':'unary.Operator',
        'chained.ChainedComparison.Operators':'chained.Operators',
        'walrus.Assignment.Name':'walrus.Name',
        'call.Call.PreloadImplicitSuperArguments':'call.PreloadImplicitSuperArguments',
        'conditional.Conditional.Span':'conditional.Span',
        'CompileComprehension(comprehension.ScopeFacts, comprehension.Clauses,':'CompileComprehension(comprehension.Clauses,',
    }.items():
        text=text.replace(old,new)
    return text

def suspending(text):
    return (text.replace('LoweredCallExpression','CallExpressionSyntax')
        .replace('LoweredDictLiteralExpression','DictLiteralExpressionSyntax')
        .replace('LoweredFormattedStringPart','FormattedStringPartSyntax')
        .replace('LoweredFormattedStringTextPart','FormattedStringTextPartSyntax')
        .replace('LoweredFormattedStringExpressionPart','FormattedStringExpressionPartSyntax')
        .replace('LoweredCollectionDisplayItem','CollectionDisplayItemSyntax')
        .replace('item.Syntax.Span','item.Span'))

def comprehensions(text):
    return (text.replace('CompileGeneratorExpression(LoweredGeneratorExpression expression,','CompileGeneratorExpression(GeneratorExpressionSyntax syntax,')
        .replace('            if (expression.PreparedCode is null)','            var expression = (LoweredGeneratorExpression)LoweredScript.LowerExpression(syntax);\n            if (expression.PreparedCode is null)',1)
        .replace('IsTrimmedSplitGenerator(LoweredGeneratorExpression expression)','IsTrimmedSplitGenerator(GeneratorExpressionSyntax expression)')
        .replace('LoweredCallExpression','CallExpressionSyntax')
        .replace('LoweredMemberExpression','MemberExpressionSyntax')
        .replace('Member.MemberName:','MemberName:')
        .replace('LoweredIdentifierExpression','IdentifierExpressionSyntax')
        .replace('item.Identifier.Name','item.Name')
        .replace('CompileComprehension(ScopeDirectiveFacts facts,\n            IReadOnlyList<LoweredComprehensionClause> clauses, LoweredExpression item,\n            LoweredExpression? value,',
            'CompileComprehension(IReadOnlyList<ComprehensionClauseSyntax> clauses, ExpressionSyntax item,\n            ExpressionSyntax? value,')
        .replace('            // The outer iterable', '            var facts = ComprehensionSyntaxFacts.Bindings(clauses.Select(static clause => clause.Target));\n            // The outer iterable',1)
        .replace('IReadOnlyList<LoweredComprehensionClause> clauses,\n            LoweredExpression item, LoweredExpression? value,',
            'IReadOnlyList<ComprehensionClauseSyntax> clauses,\n            ExpressionSyntax item, ExpressionSyntax? value,')
        .replace('CompileStoreTarget(clause.StoreTarget,','CompileStoreTarget(LoweredStoreTarget.FromLoop(clause.Target, clause.Iterable.Span),'))

change('Expressions',expressions)
change('SuspendingExpressions',suspending)
change('Comprehensions',comprehensions)
change('Infrastructure',lambda text:text.replace('InternCallSite(LoweredCallExpression call','InternCallSite(CallExpressionSyntax call')
    .replace('call.Target is LoweredMemberExpression { Member.MemberName:', 'call.Target is MemberExpressionSyntax { MemberName:'))
change('Builder',lambda text:text.replace('CompileComprehensionBody(generatorExpression.Clauses, generatorExpression.ItemExpression,',
    'CompileComprehensionBody(generatorExpression.Generator.Clauses, generatorExpression.Generator.ItemExpression,'))
