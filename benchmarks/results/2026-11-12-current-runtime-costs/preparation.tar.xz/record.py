from pathlib import Path
import hashlib,json,shutil,tarfile

r=Path(__file__).resolve().parent;q=r/'b599';out=Path('benchmarks/results/2026-11-12-current-runtime-costs');assert not out.exists();out.mkdir()
receipt=json.loads((q/'archive-receipt.json').read_text(encoding='utf-8'));assert receipt['complete']and receipt['allWorkersJoined']and receipt['guestFixturesRemoved']and receipt['quietBeforeAndAfter']and receipt['archivedAndVerifiedUnderLease']
assert hashlib.sha256((q/'observations.tgz').read_bytes()).hexdigest()==receipt['archiveSHA256']
with tarfile.open(q/'observations.tgz')as a:
    manifest=json.loads(a.extractfile('profile-archive-manifest.json').read())
    for n,h in manifest.items():assert hashlib.sha256(a.extractfile(n).read()).hexdigest()==h,n
for n in ['identity.json','source-identity.json','archive-receipt.json','observations.tgz','terminal-status.json','inventory.json','config.json','observe-not-before.json','launch.log']:shutil.copyfile(q/n,out/n)
with tarfile.open(out/'preparation.tar.xz','w:xz')as a:
    for f in [r/'prepare.py',r/'record.py',*q.glob('*.py'),q/'run.sh']:a.add(f,arcname=f.name)
summaries={n:json.loads((q/'retrieved/profiles'/n/'guest-cpu-leaves.json').read_text(encoding='utf-8'))for n in ['captured-text','helper-search']}
(out/'assessment.json').write_text(json.dumps({'profiles':summaries,'nextHypothesis':'Native body nodes already form a bounded postorder expression tree. One linear shape-proof pass could replace recursive guard dispatch without a new guest operand representation or caching values across effects. Existing depth16 bounds small unmanaged shape scratch; compilation must validate exact postorder consumption. Preserve dynamic defaults/cells, all-branches conservative proof, formatting dictionary reads, first refusal and real protocols.','otherFindings':['Histogram and split preparation remain material for captured text; do not treat instruction labels as removable shares.','Caller/binder owns real inputs; no absent frame/argument copying claim.','Native proof and binding are material for search; measured-slower known-call maps/arenas remain withdrawn.'],'limitations':'Two instrumented current-source captures, not a speed comparison, exact allocation attribution or additive removable-cost estimate. No further unchanged capture selected.'},indent=2)+'\n',encoding='utf-8')
(out/'README.md').write_text('''# Current runtime costs after native input/storage simplification

2026-11-12. Fully qualified runtime `2ec9d67f`, production unchanged in `16a6f23b`,
exact frozen `c9829194` core and `fec79afd` worker, normal optional adapter 0.4.
Two bounded synchronous captures on the quiet F4as_v7 use actual loaded maps/code.

| Complete script | Guest CPU seconds | Guest leaf samples | Unknown |
| --- | ---: | ---: | ---: |
| Captured text / Run | 5.85 | 1,162 | 63 |
| Keyword-default file search / Run | 4.53 | 895 | 38 |

Captured text associates 210 leaves with the histogram segment, 116 with split
preparation, 111 with shared instruction dispatch, 61 with word consumption,
60 with native proof, 50 with native evaluation and 49 with closure stores.
Search associates 157 with dispatch, 92 with native proof, 62 with real native
binding, 35 with input dispatch and 28 with native evaluation. Inlining/useful work
overlaps labels; these are not additive removable shares or predicted gains.

The next source gate assesses replacing recursive native proof with a linear pass
over its existing bounded postorder nodes. Compilation must validate consumption;
the proof keeps only transient enum shapes, never values cached across admission
or effects. This is a hypothesis, not a selected speedup. Preserve conditional/
closure/format semantics, dynamic protocols, missing arguments, refusal, genuine
async suspension and managed stack admission. No call-arena/known-call-map revival.
Histogram construction/preparation remains a later independent source target.

Two six-second collection windows contain 10.981 seconds of execution clocks;
guest CPU has a different boundary. Normal GC/tiering plus recorded perf/JIT
instrumentation; host/reset/protocol threads, all samples and unknowns survive.
No elapsed comparison, allocation attribution or source-pair gain is claimed.

All loaded-image/output/file/allowance/quiet/join/archive gates pass. All 37 archive
payloads are independently SHA-verified while persistent; owned RAM is unmounted,
workers joined and B599 terminal/cached. Only terminal B598 raw/catalog and B440
raw/catalog duplicates were retired after exact committed Git, path, UID, inode
and all-hardlink proofs; selected old/current cores remain protected.

[Assessment](assessment.json), [raw/maps/code](observations.tgz), [source proof](source-identity.json),
[receipt](archive-receipt.json), [preparation](preparation.tar.xz) and
[archive identities](archive-identity.json). Current CPython timings remain in
[BENCHMARKS](../../../docs/BENCHMARKS.md); full delivery is already green and is
not repeated for this unchanged-source capture. Publication remains postponed.
''',encoding='utf-8')
(out/'archive-identity.json').write_text(json.dumps({p.name:{'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}for p in sorted(out.iterdir())if p.is_file()and p.name!='archive-identity.json'},indent=2)+'\n',encoding='utf-8')
h=Path('benchmarks/EXPERIMENTS.md');text=h.read_text(encoding='utf-8');at=text.index('[Immutable regex dev73]')
text=text[:at]+'''[Current retained-source CPU captures](results/2026-11-12-current-runtime-costs/README.md)
complete two bounded windows: captured text 1,162 leaves/5.85 guest CPU seconds,
helper search 895/4.53. Histogram/preparation dominate text labels; shared dispatch,
proof and real binding are material in search. These are overlapping labels, not
removable-cost estimates or timing gains. The next source gate assesses linear
native proof over existing postorder nodes, retaining dynamic semantics and effects.
All gates/joins/persistent SHA/RAM cleanup pass; no unchanged repeat capture selected.

'''+text[at:];h.write_text(text,encoding='utf-8')
p=Path('PLAN.md');text=p.read_text(encoding='utf-8')
a=text.index('1. Refresh **two bounded CPU captures');b=text.index('2. Implement the selected coherent milestone',a)
text=text[:a]+'''1. Current-source CPU gate completed in B599: captured text1162leaves/5.85guest
   CPU seconds; keyword-default search895/4.53. Histogram/preparation remain
   material in text; dispatch/native proof/real binding in search. Labels overlap,
   not removable shares. All37raw payloads SHA-verified, joins/RAM/archive pass;
   terminal/cached. [Evidence](benchmarks/results/2026-11-12-current-runtime-costs/README.md).
   No further unchanged captures selected.
   **Next bounded prototype:** replace recursive native whole-body proof with a
   linear pass over its existing postorder nodes. Validate operand consumption
   during compilation. Existing expression-depth16 bounds transient enum-shape
   scratch; no guest-value arena, cache, per-call owner or new execution route.
   Delete recursive GuardNativeReturn/GuardNativeFormattedValue dispatch, retain
   actual pure formatting reads and re-read live values during execution. Preserve
   all-branch proof, closure store ordering, dynamic defaults/builtin identity,
   missing arguments, Python protocol fallback, current cancellation/first refusal,
   reentry and stack safety. Complete helper search and captured/ordinary text
   are affected; CSV/JSON/report controls and separate compile. Stop source gate
   after focused semantic/ownership/cancellation checks and one complete-script
   diagnostic; refine only on concrete evidence before bounded quiet confirmation.
   A faster proof is a hypothesis, not a claim that its full samples disappear.
'''+text[b:]
text=text.replace('B576–B598terminal/cached','B576–B599terminal/cached')
p.write_text(text,encoding='utf-8')
print('Current profile and source gate recorded; no runtime prototype yet.')
