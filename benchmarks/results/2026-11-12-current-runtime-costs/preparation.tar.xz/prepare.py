from pathlib import Path
import ast,hashlib,json,subprocess,tarfile

r=Path(__file__).resolve().parent;q=r/'b599';q.mkdir()
old=r.parent/'word-materialization-r250/b596'
name='current-runtime-b599-20261112';unit='lython-b599-current-runtime-20261112'
sha=lambda b:hashlib.sha256(b).hexdigest()
source=json.loads((r.parent/'native-inputs-r251/b598/source-identity.json').read_text(encoding='utf-8'))
for n,h in source['sourceSHA256'].items():assert sha(Path(n).read_bytes())==h,n
identity=json.loads((r.parent/'native-inputs-r251/b598/identity.json').read_text(encoding='utf-8'))
identity['coreSHA256'].pop('candidate-control')
identity['sourceRevision']='Fully qualified2ec9d67f, unchanged production in16a6f23b. Current captured-text Run and keyword-default helper-search Run CPU capture after retained native storage/input redesign. Six-script B598CPython checkpoint complete. Two6s windows with actual loaded maps; no elapsed comparison, additive removable-cost estimate or unchanged profile replay.'
catalog=r.parent/'native-inputs-r251/b598/representative.json'
identity['catalogSHA256']=sha(catalog.read_bytes())
(q/'catalog.json').write_bytes(catalog.read_bytes())
(q/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8')
source['qualification']='Exact production2ec9d67f fully qualified43119174279 Windows/Ubuntu actual11/10 originalstress and installedconsumers.'
(q/'source-identity.json').write_text(json.dumps(source,indent=2)+'\n',encoding='utf-8')
def replace(t):return t.replace('word-control-profile-b596-20261111',name).replace('lython-b596-word-control-profile-20261111',unit).replace('word-control-profile-b596-launch.py','current-runtime-b599-launch.py').replace('lython-b596-fixtures','lython-b599-fixtures').replace('B596','B599')
for n in ['ops-profile.py','analyze-cpu-guest.py','archive.py','run.sh','launch.py','retrieve-original.py','remote-launch.py']:
    s=replace((old/n).read_text(encoding='utf-8'))
    if n=='ops-profile.py':
        s=s.replace('[("reference", "scripts.file-search.large", "warm-async"), ("candidate", "scripts.file-search.large", "warm-async")]','[("captured-text", "scripts.text-summary-helpers.nonlocal-counter.large", "warm"), ("helper-search", "scripts.file-search.large", "warm")]')
        s=s.replace('tree / name / "Lokad.Lython.Benchmarks.dll"','tree / "candidate/Lokad.Lython.Benchmarks.dll"').replace("expected['coreSHA256'][name]","expected['coreSHA256']['candidate']")
        s=s.replace('TryExecuteInstruction TryExecuteCallInstruction TryExecuteWithoutFrame EvaluateNativeReturn GuardNativeReturn','TryExecuteDictionaryLoop TryExecuteCallInstruction EvaluateNativeReturn GuardNativeReturn')
    if n in ['run.sh','archive.py']:s=s.replace('reference candidate','captured-text helper-search').replace("['reference','candidate']","['captured-text','helper-search']")
    if n=='remote-launch.py':
        s=s.replace("source=base/'word-materialization-b595-20261111/reference'","source=base/'native-inputs-b597-20261112/candidate'")
        a=s.index('protected=');b=s.index("with(base/'comparison-vm.lock')",a)
        s=s[:a]+"protected={source/'Lokad.Lython.dll':config['identity']['coreSHA256']['candidate'],base/'native-inputs-b597-20261112/reference/Lokad.Lython.dll':config['identity']['protectedPriorReferenceSHA256']}\n"+s[b:]
        a=s.index(" for role in ['reference','candidate']:");b=s.index(' shutil.copyfile(protocol',a)
        s=s[:a]+" shutil.copytree(source,root/'candidate',copy_function=os.link)\n assert digest(root/'candidate/Lokad.Lython.dll')==config['identity']['coreSHA256']['candidate']\n os.link(root/'candidate/Lokad.Lython.dll',root/'current-core.dll')\n"+s[b:]
    (q/n).write_text(s,encoding='utf-8',newline='\n')
    if n.endswith('.py')and n!='remote-launch.py':ast.parse(s)
with tarfile.open(q/'payload.tgz','w:gz')as a:
    for n in ['catalog.json','identity.json','source-identity.json','ops-profile.py','analyze-cpu-guest.py','archive.py','run.sh']:a.add(q/n,arcname=n)
with tarfile.open(q/'payload.tgz')as a:expanded=sum(((m.size+4095)//4096)*4096 for m in a.getmembers())
retire=[]
for remote,canonical,entry,kind in [
    ('native-inputs-cpython-b598-20261112/observations.tgz','benchmarks/results/2026-11-12-native-inputs-cpython-checkpoint/observations.tgz',None,'exact'),
    ('native-inputs-cpython-b598-20261112/representative.json','benchmarks/results/2026-11-12-native-inputs-cpython-checkpoint/observations.tgz','representative.json','exact'),
    ('inline-cpython-b440-20261108/observations.tgz','benchmarks/results/2026-11-08-inline-checkpoint/observations.tgz',None,'exact'),
    ('inline-cpython-b440-20261108/representative.json','benchmarks/results/2026-11-08-inline-checkpoint/observations.tgz','representative.json','all-aliases')]:
    p=Path(canonical);b=p.read_bytes();assert b==subprocess.check_output(['git','show','HEAD:'+p.as_posix()])
    if entry:
        with tarfile.open(p)as a:data=a.extractfile(entry).read()
    else:data=b
    spec=dict(kind=kind,knownPath=remote,bytes=len(data),sha256=sha(data),canonicalStorage=canonical,reason='Terminal duplicate evidence; exact canonical committed Git bytes verified. Fresh path/UID/inode/all-alias proof; both selected core roles protected.')
    if entry:spec.update(canonicalEntry=entry,canonicalArchiveSHA256=sha(b))
    retire.append(spec)
config=dict(root='/home/lokad/lython-bench-checks/'+name,unit=unit,payloadBytes=(q/'payload.tgz').stat().st_size,payloadSHA256=sha((q/'payload.tgz').read_bytes()),requiredFreeBytes=252*1024*1024+expanded+65536,retire=retire,identity=identity)
(q/'config.json').write_text(json.dumps(config,indent=2)+'\n',encoding='utf-8')
ast.parse((q/'remote-launch.py').read_text(encoding='utf-8').replace('config=CONFIG','config='+repr(config)).replace('inventoryOnly=INVENTORY_ONLY','inventoryOnly=True'))
assert 'captured-text'in(q/'ops-profile.py').read_text(encoding='utf-8')
print('Prepared two current-source CPU captures;120sowner/180sobservation, no source change. Fresh proof required.')
