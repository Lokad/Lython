from pathlib import Path
import hashlib,json,os,subprocess,sys
r=Path(__file__).parent
env=os.environ.copy();env['DOTNET_ROOT']='C:/Users/JoannesVermorel/.dotnet11';env['DOTNET_HOST_PATH']=env['DOTNET_ROOT']+'/dotnet.exe';env['PATH']=env['DOTNET_ROOT']+os.pathsep+'C:/Python313'+os.pathsep+env['PATH']
programs=["print(int('١٢'))","print(int('１２'))","print(int('𝟙𝟚'))","print(int('٠x_f',0))","print(int('٠_٠',0))","print(int('٠١',0))","print(int('  +1_234  '))","print(int(b'\\xd9\\xa1'))"]
(r/'cases.json').write_text(json.dumps(programs,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
with (r/'probe-build.log').open('w',encoding='utf-8') as log:
 done=subprocess.run([env['DOTNET_HOST_PATH'],'build','tools/LythonProbe/LythonProbe.csproj','-c','Release','-f','net11.0','--nologo','-v','quiet'],env=env,stdout=log,stderr=subprocess.STDOUT)
assert done.returncode==0,(r/'probe-build.log').read_text(encoding='utf-8')[-2000:]
done=subprocess.run([env['DOTNET_HOST_PATH'],'tools/LythonProbe/bin/Release/net11.0/LythonProbe.dll','--batch-json','--compare-python'],input=json.dumps(programs,ensure_ascii=False),env=env,capture_output=True,text=True,encoding='utf-8')
(r/'before-probe.ndjson').write_text(done.stdout,encoding='utf-8',newline='\n');(r/'before-probe.stderr').write_text(done.stderr,encoding='utf-8',newline='\n')
assert done.returncode in [0,1],done.stderr
rows=[json.loads(line)for line in done.stdout.splitlines()if line.strip()]
assert len(rows)==len(programs)
print('Probe exit',done.returncode,'cases',len(rows),'row keys',list(rows[0]),flush=True)
for source,row in zip(programs,rows):print(json.dumps(dict(source=source,result=row),ensure_ascii=True)[:1000],flush=True)
