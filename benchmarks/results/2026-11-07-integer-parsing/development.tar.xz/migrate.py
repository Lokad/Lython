from pathlib import Path
import hashlib,json
r=Path(__file__).parent;p=Path('src/Lokad.Lython/Runtime/LythonRuntime.Builtins.cs')
before=json.loads((r/'before.json').read_text(encoding='utf-8'))
assert hashlib.sha256(p.read_bytes()).hexdigest()==before['productionSources'][str(p)]
s=p.read_text(encoding='utf-8');start=s.index('        // UTF-8 bytes upper-bound decoded UTF-16 units.',s.index('private static object ParseOwnedIntegerText'))
end=s.index('    // CPython resolves int(instance)',start)
s=s[:start]+'''        MemoryGovernor.TemporaryMemoryReservation? admission = null;
        try
        {
            var result = ParseIntegerUtf8(utf8, source is PyString, numberBase, span, source, context, ref admission);
            context.CheckExecution(span);
            object box = result;
            if (admission is not null)
                admission.Commit(RuntimeMemoryEstimates.EstimateBigIntegerBytes(result));
            return box;
        }
        finally { admission?.Dispose(); }
    }

'''+s[end:]
assert 'ParsePythonIntegerText' not in s
p.write_text(s,encoding='utf-8',newline='\n')
print('Removed decoded copy/estimate and old UTF-16 per-character parser; native short decimal path preserved.')
