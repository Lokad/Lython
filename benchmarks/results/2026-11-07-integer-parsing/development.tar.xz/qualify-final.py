from pathlib import Path
r=Path(__file__).parent
s=(r/'qualify.py').read_text(encoding='utf-8')
start=s.index('filters={');end=s.index('\nchecks={}',start)
filters={
 'Lokad.Lython.Tests':'Category!=Stress&(FullyQualifiedName~IntegerTextAdmission|FullyQualifiedName~IntegerTextCancellation|FullyQualifiedName~SimpleFunctionExecutionBoundary)',
 'Lokad.Lython.PublicApi.Tests':'Category!=Stress&(FullyQualifiedName~Utf8IntegerParseTests|FullyQualifiedName~UnicodeIntegerTextTests|FullyQualifiedName~GeneralIntegerTextTests)'}
s=s[:start]+'filters='+repr(filters)+s[end:]
s=s.replace("r/'focused.json'","r/'final-focused.json'").replace("name=project+","name='final-'+project+").replace("r/'candidate'","r/'refined'")
exec(compile(s,str(r/'final-qualification-command.py'),'exec'),{'__file__':str(r/'final-qualification-command.py')})
