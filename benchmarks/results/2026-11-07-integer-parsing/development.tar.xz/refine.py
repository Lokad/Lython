from pathlib import Path
import hashlib,json,shutil,zipfile
r=Path(__file__).parent;identity=json.loads((r/'diagnostic-identity.json').read_text(encoding='utf-8'))
assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==h for p,h in identity['productionSources'].items())
with zipfile.ZipFile(r/'source-initial.zip','x',zipfile.ZIP_DEFLATED) as a:
 for p in identity['productionSources']:a.write(p,p)
shutil.copy2(r/'focused.json',r/'initial-focused.json')
p=Path('src/Lokad.Lython/Runtime/LythonRuntime.IntegerParsing.cs');s=p.read_text(encoding='utf-8')
old='''        var end = input.Length;
        var nextCheck = start;'''
new='''        var end = input.Length;
        // The caller just checked. Resume checking at the next scan chunk.
        var nextCheck = Math.Min(4096, end);'''
assert s.count(old)==1;s=s.replace(old,new);p.write_text(s,encoding='utf-8',newline='\n')
for p in [Path('tests/Lokad.Lython.PublicApi.Tests/Lokad.Lython.PublicApi.Tests.csproj'),Path('tests/Lokad.Lython.Tests/IntegerTextAdmissionTests.cs')]:
 s=p.read_text(encoding='utf-8');p.write_text(s,encoding='utf-8',newline='\n')
print('Initial source/results preserved; one duplicate entry check removed, scan/promotion/flush/publication checks retained.')
