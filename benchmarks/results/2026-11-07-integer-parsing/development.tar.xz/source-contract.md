# R45 selected source boundary (before implementation)

Baseline production77703a42, metadata now3480aa55. Frozen before.json/core and eight
public CPython comparisons: five Unicode decimal mismatches, three controls match.
R43 source5fb25354 fully qualified42365045704; R44 later twelve-check deletion has
103internal/862public actual11 only. No active test/CI/VM or R45 code prototype.

Keep ParseOwnedIntegerText's existing <=20-byte signed decimal Utf8Parser path;
ordinary maintained CSV already uses it. General source still decodes to CLR text,
reserves decoded+three-magnitude scratch and performs multiply/add per UTF16 char.
Replace the general loop and decoded copy; no new scalar representation/framework.

Selected native general kernel: read original UTF8 (PyString) or ASCII grammar
(PyBytes). Rune.GetUnicodeCategory/NumericValue already serve isdecimal and format
indices: reuse that policy, no new Unicode data table. Byte inputs must reject
nonASCII even when bytes happen to encode Unicode digits. Unicode zero can precede
ASCII b/o/x prefixes; full-width x is not a prefix. For base mismatches, e.g.
int('0b1',16), b is an ordinary digit. Handle one optional prefix underscore,
otherwise underscores only between digits; sign ASCII only. Base0 unprefixed
leading-zero numbers may contain only zeros. Int ASCII whitespace is six bytes
(09–0d,20), not the extra C0 separators accepted by str.isspace; nonASCII string
whitespace follows the existing Python whitespace classification. Trim both ends
with cancellable scalar-boundary chunks. Keep lazy IntFailureDisplay(original).

Accumulate in ulong until the next digit would overflow. Small scalar boxes use
existing control/container headroom. Before promotion reserve conservative THREE
upper-bound magnitudes including metadata through existing ReserveTemporary, check
execution after admission, then construct BigInteger. GuardIntegerParseBytes only
reserves TWO and still serves JSON; do not remove or silently change that helper.
No decoded-copy charge is needed. After promotion accumulate native radix chunks
whose power fits uint, flushing result*power+chunk instead of BigInteger per digit.
Check cancellation in nonallocating scanning chunks and before/after large flushes.
Commit only the valid retained large result from the working reservation; release
all scratch after actual users end on every failure. First refusal never retries.

Small regression for cancellation after general admission: private kernel delegate
with AdmissionHookMemoryBudget cancelling AfterGrowth, valid21 nines (beyond ulong),
both str/bytes; assert Cancelled and refunded scratch/retained input. Leading-zero
21-byte input is unsuitable once small values no longer reserve. Old code returns
the parsed integer after cancellation, making this an observable operation gap.
Add actual in-flight long-loop stress separately, with owned/drained finite work;
do not add test checkpoint counters or relax timeouts. Confirm before implementation.

Affected whole script can reuse the maintained CSV SOURCE unchanged. fixtureJson
contains base64 inputFiles['input.csv']; use independent csv.reader/writer to pad
numeric amount fields with signs/leading zeros/edge whitespace beyond20bytes while
preserving values, output/file goldens. Recompute exact fixtureJson/fixture hash,
record input size and distinguish this affected fixture from ordinary CSV. Ordinary
CSV/text/JSON are controls. Reuse existing complete-job tooling; no new framework,
phase-median subtraction, quota or unsupported lane (worker uses compile-run).
Freeze before/after source/images, preserve adverse conditions, measure compile/warm
and I/O/cleanup boundaries separately. Do not claim ordinary CSV dominance or CPU
benefit before evidence. Full delivery of R44+R45 is the next batched checkpoint.
