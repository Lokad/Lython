from pathlib import Path
import shutil
r=Path(__file__).parent
shutil.copy2(r/'Lokad.Lython.Tests-net11.0.log',r/'failed-internal-net11.0.log');shutil.copy2(r/'focused.json',r/'failed-focused.json')
p=Path('tests/Lokad.Lython.Tests/SimpleFunctionExecutionBoundaryTests.cs');s=p.read_text(encoding='utf-8');start=s.index('    [Fact]\n    public void CompoundReturnRefusalAfterTextWorkKeepsOriginAndInputOwner()');end=s.index('    private static (PyExecutableFunction Function',start)
(r/'compound-refusal-before.cs').write_text(s[start:end],encoding='utf-8',newline='\n')
s=s[:start]+'''    [Fact]
    public void CompoundReturnRefusalAfterTextWorkKeepsOriginAndInputOwner()
    {
        foreach (var driver in Enum.GetValues<Driver>())
        {
            const int digits = 4096;
            var budget = new LythonMemoryBudget(64 * 1024);
            using (var inputOwner = budget.CreateScope())
            {
                var input = PyString.FromString(" " + new string('9', digits) + " ",
                    new MemoryGovernor(inputOwner), CallSpan);
                var inputCharge = budget.ReservedBytes;
                using (var executionOwner = budget.CreateScope())
                {
                    var hook = new AdmissionHookMemoryBudget(executionOwner);
                    var (function, context, code) = Function("def f(value):\\n    return int(value.strip()) + 1\\n",
                        new LythonRunOptions { MemoryBudget = hook });
                    var refused = false;
                    // Allow argument/frame metadata, then refuse substantial
                    // magnitude construction. No decoded text is required.
                    hook.RefuseGrowth = bytes =>
                    {
                        if (bytes < digits) return false;
                        refused = true;
                        return true;
                    };
                    var active = new PyException("RuntimeError", "outer", PyNone.Instance);
                    context.State.SetCurrentException(active);
                    try
                    {
                        var error = Assert.Throws<LythonRuntimeException>(() =>
                            Invoke(function, [CallArgumentValue.Positional(input)], context, driver));
                        Assert.True(refused);
                        Assert.True(budget.ReservedBytes >= inputCharge + digits,
                            "The preceding stripped value must remain funded by the source owner.");
                        Assert.Equal(LythonFailureReason.SharedMemoryAllowance, error.Attribution?.Reason);
                        Assert.Same(code.CallSites.MaxBy(site => site.CallSpan.Length)!.CallSpan, error.Span);
                        Assert.Same(context.MemoryGovernor.AdmissionFailure, error);
                        Assert.Same(active, error.PythonContext);
                        Assert.Same(active, context.State.CurrentException);
                        Assert.Equal(0, context.State.CurrentInterpreterDepth);
                        Assert.Equal(0, context.State.CurrentRecursionDepth);
                        Assert.Equal(0, context.MemoryGovernor.CurrentReservedBytes);
                        Assert.Equal(digits + 2, input.Length);
                    }
                    finally { context.State.CloseResources(); }
                }
                // Fresh slices conservatively share the source owner.
                Assert.True(budget.ReservedBytes >= inputCharge);
                Assert.Equal(digits + 2, input.Length);
            }
            Assert.Equal(0, budget.ReservedBytes);
        }
    }

'''+s[end:]
p.write_text(s,encoding='utf-8',newline='\n');print('Compound refusal fixture denies actual magnitude storage after text work, input50000→4096; assertions retained/strengthened.')
