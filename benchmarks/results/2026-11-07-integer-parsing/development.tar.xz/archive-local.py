from pathlib import Path
import hashlib,json,shutil,subprocess,tarfile
r=Path(__file__).parent;out=Path('benchmarks/results/2026-11-07-integer-parsing');out.mkdir()
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
identity=json.loads((r/'b399/identity.json').read_text(encoding='utf-8'))
assert all(sha(Path(p))==h for p,h in identity['productionSources'].items()),'Do not silently change timed production source.'
for name in ['before.json','initial-focused.json','final-focused.json','fixture-validation.json','local-summary.json','comparison-summary.json']:
 (out/name).write_text((r/name).read_text(encoding='utf-8'),encoding='utf-8',newline='\n')
(out/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8',newline='\n')
target=out/'b399';target.mkdir()
for name in ['observations.tgz','archive-receipt.json','terminal-status.json']:
 if name.endswith('.json'):(target/name).write_text((r/'b399'/name).read_text(encoding='utf-8'),encoding='utf-8',newline='\n')
 else:shutil.copy2(r/'b399'/name,target/name)
receipt=json.loads((target/'archive-receipt.json').read_text());assert sha(target/'observations.tgz')==receipt['archiveSHA256']
(r/'final-source.patch').write_bytes(subprocess.check_output(['git','-c','core.autocrlf=false','diff','--','src','tests','docs','CHANGELOG.md']))
with tarfile.open(out/'development.tar.xz','w:xz',preset=9) as a:
 for p in r.iterdir():
  if p.is_file() and p.suffix in ['.py','.json','.md','.cs','.log','.ndjson','.stderr','.zip','.patch']:a.add(p,arcname=p.name)
 for folder in ['baseline','candidate','refined','warm-sync','warm-async','compile-sync']:
  for p in (r/folder).rglob('*'):
   if p.is_file():a.add(p,arcname=p.relative_to(r))
 for name in ['complete-jobs.csproj','Program.cs']:a.add(r/'tool'/name,arcname='tool/'+name)
 for p in (r/'tool/out').glob('complete-jobs.*'):a.add(p,arcname='tool/out/'+p.name)
 for p in (r/'b399').iterdir():
  if p.is_file() and p.suffix in ['.py','.json','.md','.log','.sh']:a.add(p,arcname=p.relative_to(r))
 for name in ['src/Lokad.Lython/Runtime/LythonRuntime.IntegerParsing.cs','tests/Lokad.Lython.Tests/IntegerTextCancellationTests.cs','tests/Lokad.Lython.PublicApi.Tests/GeneralIntegerTextTests.cs','tests/Lokad.Lython.PublicApi.Tests/UnicodeIntegerTextTests.cs']:
  a.add(name,arcname='new-files/'+name)
 for p in Path('tests/Lokad.Lython.PublicApi.Tests/Fixtures/IntegerParsing').iterdir():
  if p.is_file():a.add(p,arcname='new-fixture/'+p.name)
with tarfile.open(out/'development.tar.xz') as a:assert a.getmember('new-files/src/Lokad.Lython/Runtime/LythonRuntime.IntegerParsing.cs').size>0
print('All source/failure/initial/final/VM evidence preserved; development bytes', (out/'development.tar.xz').stat().st_size,'SHA256',sha(out/'development.tar.xz'))
