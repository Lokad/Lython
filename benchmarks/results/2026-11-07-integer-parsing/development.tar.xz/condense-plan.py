from pathlib import Path
import shutil
r=Path(__file__).parent;p=Path('PLAN.md');s=p.read_text(encoding='utf-8');shutil.copy2(p,r/'PLAN-before-consolidation.md')
start=s.index('- **Committed/pushed R43');end=s.index('- **Committed/pushed R44',start)
s=s[:start]+'''- **R43 committed/pushed `5fb25354`, fully qualified:** fewer operand loads and
  one physical-layout pass; original spans/aliases/native helpers preserved.
  No frame cache or extra charge. B397 setup failure and all intermediate/adverse
  data are archived; corrected B398 passes all gates. Retain consolidation without
  a substantial CPU claim. Full details live in its benchmark evidence.
'''+s[end:]
anchor='| R42 cost gate |';end=s.index('\n',s.index(anchor));s=s[:end]+'''
| R43 ordinary operands | Fewer instructions/smaller immutable payload; compile allocation +0.20–0.87%; full delivery green | Text warm −1.37 to +1.11%, fresh −2.23 to −0.15%; CSV variable, JSON −2.37 to +6.81%/6.66% identical-current spread, report −2.19 to −0.73%/3.92% IQR. No substantial CPU claim; debt stays. |'''+s[end:]
start=s.index('## Priority 1 —');next_boundary=s.index('## Next redesign boundaries',start)
r45=s[s.index('### R45 —',start):next_boundary].replace('### R45 — general UTF-8 integer parsing and cooperative promotion (next)','## Priority 1 — R45 general UTF-8 integer parsing and cooperative promotion')
status='''R43 is fully delivered; R44's bounded deletion is committed. R44 removes twelve
checks immediately after checked managed frame entry, preserving constructor
post-admission/opcode/loop/resume checks and cleanup. Its short four-script
diagnostic passes all gates with flat allocation/identical peaks and variable
desktop clocks; no CPU gain. Full R44 qualification is batched with R45. Broader
opcode-check hoisting lacks proof and is not selected. Details are in
benchmarks/results/2026-11-07-call-entry-checks/.

'''
s=s[:start]+r45+status+s[next_boundary:]
s=s.replace('R43 completes the selected ordinary-operation representation. Assess its complete-script result before selecting a further dispatch/frame redesign; no automatic chain of leaf-specific rewrites.', 'R43 retained smaller code and fewer instructions, with CPU improvement unproved. No further leaf-specific rewrite without materially new evidence.')
s=s.replace('R42 prefix self includes inlined protection work; source has repeated cancellation/refusal checks around completed operations. This is a hypothesis, not measured guard CPU. After R43 assess a coherent boundary placement, removing genuinely redundant work while preserving loop/long-operation/current-token checks, admission/effect order and first-refusal propagation. No replacement counters, quotas or weaker containment; stop if source proof needs them.', 'R44 completes twelve provably immediate duplicates. Wider opcode hoisting lacks a complete cancellation/refusal/error-order proof and is not selected. R42 prefix self is not guard CPU. Keep meaningful checkpoints; no replacement counters/quotas or weaker containment.')
p.write_text(s,encoding='utf-8',newline='\n');print('Active plan',len(s.splitlines()),'lines; completed detail linked to immutable evidence; R45 is the next explicit milestone.')
