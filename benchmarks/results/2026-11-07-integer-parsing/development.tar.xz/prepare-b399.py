from pathlib import Path
import ast,hashlib,json,shutil,subprocess,tarfile,zipfile
home=Path(__file__).parent;r=home/'b399';r.mkdir();old=home.parent/'operand-sources-r43/b398'
old_remote='/home/lokad/lython-bench-checks/operand-transport-b398-20261107';remote='/home/lokad/lython-bench-checks/integer-parsing-b399-20261107'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
checks=json.loads((home/'final-focused.json').read_text(encoding='utf-8'));assert len(checks['checks'])==4 and len(checks['coreSHA256'])==2
baseline=json.loads((home/'before.json').read_text(encoding='utf-8'))
candidate=home/'refined/net11.0/Lokad.Lython.dll';reference=home/'baseline/net11.0/Lokad.Lython.dll'
assert sha(candidate)==checks['coreSHA256']['net11.0'] and sha(reference)==baseline['coreSHA256']
identity={'auxiliaryFiles':json.loads((old/'identity.json').read_text(encoding='utf-8'))['auxiliaryFiles']}
identity.update(sourceRevision='3480aa55 plus R45 native UTF-8 general integer parser; frozen'+sha(candidate),
 purpose='R45 padded CSV / JSON numeric strings, warm and compile-run, plus ordinary CSV/text/JSON controls',qualification=checks,
 productionSources={str(p):sha(p) for p in Path('src/Lokad.Lython').rglob('*.cs')if not any(x in p.parts for x in ['obj','bin'])},
 originalComparison='Initial UTF8 prototype allocation evidence preserved: CSV−14.70/−13.35%, JSON−62.99/−62.98%; desktop favorable affected cases but moving controls. Final refinement removes one duplicate entry check before the first whitespace scan.',
 baselineSource=baseline['source'],baselineQualification='R43 full5fb green42365045704; later R44 baseline777 has focused103/862actual11, batch full delivery with R45 pending.')
identity['coreSHA256']={'reference':sha(reference),'reference-control':sha(reference),'candidate':sha(candidate),'control':sha(candidate)}
(r/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8',newline='\n')
shutil.copy2(home/'catalog.json',r/'representative.json');shutil.copy2(home/'fixture-validation.json',r/'fixture-validation.json')
jobs=[('scripts.csv-summary-functions.large-padded-integers','warm'),('scripts.csv-summary-functions.large-padded-integers','compile-run'),('scripts.json-summary-helpers.large-integer-strings','warm'),('scripts.json-summary-helpers.large-integer-strings','compile-run'),('scripts.csv-summary-functions.large','warm'),('scripts.text-summary-helpers.large','warm'),('scripts.json-summary-helpers.large','warm')]
for name in ['collect.py','archive-owned.py','run.sh']:
 s=(old/name).read_text(encoding='utf-8').replace(old_remote,remote)
 if name=='collect.py':
  start=s.index('jobs=[');end=s.index('\nassert len(jobs)',start);s=s[:start]+'jobs='+repr(jobs)+s[end:]
  s=s.replace('len(jobs)==5','len(jobs)==7').replace('time.monotonic()-started < 140','time.monotonic()-started < 230')
  s=s.replace('R43 text warm/fresh and CSV/JSON/report controls; two baseline/two current','R45 integer parsing: affected CSV/JSON warm/compile-run and ordinary controls; two baseline/two current')
 if name=='archive-owned.py':
  s=s.replace("len(r['jobs'])==5","len(r['jobs'])==7").replace('jobs=5','jobs=7').replace("'source-current.zip','focused.json'","'source-current.zip','focused.json','fixture-validation.json'")
 (r/name).write_text(s,encoding='utf-8',newline='\n')
contract='''R45 replaces general int text decoding/per-character BigInteger operations with original UTF8 scanning, native ulong accumulation and exact chunked promotion. Preserve the measured<=20byte decimal path, Python bases/signs/prefixes/underscores/whitespace/error/bytes semantics; Unicode decimal strings now correct using existing Rune classification, no database. Before major allocation reserve3conservative overlapping magnitudes through the existing owner; commit only retained result, release scratch after users end. Cooperative cancellation in nonallocating scans and before/after major work; no quota/counter/unsafe/tracing/retry/new allowance. Two cancellation regressions first fail on baseline (valid21nines return despite cancelled admission), then pass;189independent CPython corpus cases plus legacy semantic/ownership controls. Initial broad160internal/776public per actual11/10 pass after correcting one stale decoded-copy fixture (input50000→4096, controlled actual-magnitude refusal, origin/input/cleanup checks retained). Final41internal/280public per target pass after removing one redundant no-allocation entry check; actual in-flight Stress passes separately. Full delivery of R44+R45 pending. Initial complete allocation reduction CSV14.70/13.35%, JSON62.99/62.98% sync/async; ordinary controls/compilation flat. Desktop elapsed moving/adverse preserved. CSV affected fixture keeps source unchanged, 4096padded32digit amounts/191505B. JSON uses explicit int(record['amount']) with4096forty-digit strings/278528B. CPython3.13.2 independently validates full stdout/files; do not project these diagnostics onto ordinary inputs. Existing quiet F4as_v7/.NET11RC3/normalGC/tiering, worker7cf37ca5/adapter27211dbe/normal optional0.4. Two baseline/two current processes;5s warmup/role/job,7rotated150ms rounds. Timed public commands include RAM host I/O, aggregation/goldens and prior-result cleanup; compile-run adds compile/program disposal. Startup/staging/reset/transport/final cached teardown excluded. Seven jobs include both affected warm/compile-run and ordinary CSV/text/JSON controls. Require Ready/core/aux/golden/funding/quiet/Closed/exit/join/fixture/archive gates.270s owner+30s stop+30s margin, observe after330s; never restart on observation timeout. Preserve all adverse results; distinguish allocation/elapsed/CPU/embedding latency. No core/provider publication or new producer dependency.'''
(r/'contract.md').write_text(contract+'\n',encoding='utf-8',newline='\n')
(r/'setup-contract.json').write_text(json.dumps(dict(referenceTemplate='/home/lokad/lython-bench-checks/receiver-methods-b394-20261107/candidate',roles=['candidate','reference','control','reference-control'],ownerSeconds=270,stopSeconds=30,observeAfterSeconds=330,jobs=jobs),indent=2)+'\n',encoding='utf-8',newline='\n')
shutil.copy2('PLAN.md',r/'pre-measurement-plan.md');shutil.copy2(home/'final-focused.json',r/'focused.json')
(r/'source.patch').write_bytes(subprocess.check_output(['git','-c','core.autocrlf=false','diff','--','src','tests']))
with zipfile.ZipFile(r/'source-current.zip','x',zipfile.ZIP_DEFLATED) as a:
 for p in identity['productionSources']:a.write(p,p)
for name in ['collect.py','archive-owned.py']:ast.parse((r/name).read_text(encoding='utf-8'))
with tarfile.open(r/'payload.tgz','w:gz') as a:
 for name in ['identity.json','representative.json','collect.py','archive-owned.py','run.sh','contract.md','pre-measurement-plan.md','setup-contract.json','source.patch','source-current.zip','focused.json','fixture-validation.json']:a.add(r/name,arcname=name)
 a.add(candidate,arcname='current-core.dll');a.add(reference,arcname='baseline-core.dll')
s=(old/'launch.py').read_text(encoding='utf-8').replace(old_remote,remote).replace('operand-transport-b398-20261107','integer-parsing-b399-20261107').replace('lython-b398-operand-transport-20261107','lython-b399-integer-parsing-20261107').replace('operand-transport-b398-launch.py','integer-parsing-b399-launch.py')
old_line=" shutil.copytree(reference,root/'reference',symlinks=True,copy_function=os.link)"
assert s.count(old_line)==1
s=s.replace(old_line,old_line+"\n (root/'reference/Lokad.Lython.dll').unlink()\n (root/'baseline-core.dll').replace(root/'reference/Lokad.Lython.dll')")
s=s.replace('len(jobs)==5','len(jobs)==7').replace("len(r['jobs'])==5","len(r['jobs'])==7").replace('allFiveJobsValidated','allSevenJobsValidated')
s=s.replace('ownerSeconds=180','ownerSeconds=270').replace('RuntimeMaxSec=180','RuntimeMaxSec=270').replace('seconds=240','seconds=330')
ast.parse(s);(r/'launch.py').write_text(s,encoding='utf-8',newline='\n')
s=(home.parent/'operand-sources-r43/retrieve-b398.py').read_text(encoding='utf-8').replace("parent/'b398'","parent/'b399'").replace(old_remote,remote).replace('lython-b398-operand-transport-20261107','lython-b399-integer-parsing-20261107').replace("status['receipt']['jobs']==5","status['receipt']['jobs']==7")
ast.parse(s);(home/'retrieve-b399.py').write_text(s,encoding='utf-8',newline='\n')
print('B399 prepared, not launched: seven jobs,270+30+30s; both core images staged and every auxiliary checked.')
