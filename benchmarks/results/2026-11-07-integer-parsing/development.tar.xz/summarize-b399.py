from pathlib import Path
r=Path(__file__).parent
s=(r.parent/'builtin-methods-r41/summarize-b394.py').read_text(encoding='utf-8')
s=s.replace("'b394/retrieved/confirmation/confirmation.json'","'b399/retrieved/confirmation/confirmation.json'").replace("'refined-comparison-summary.json'","'comparison-summary.json'")
exec(compile(s,str(r/'summary-command.py'),'exec'),{'__file__':str(r/'summary-command.py')})
