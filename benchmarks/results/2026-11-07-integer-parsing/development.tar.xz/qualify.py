from pathlib import Path
import hashlib,json,os,shutil,subprocess
r=Path(__file__).parent
env=os.environ.copy();env['DOTNET_ROOT']='C:/Users/JoannesVermorel/.dotnet11';env['DOTNET_HOST_PATH']=env['DOTNET_ROOT']+'/dotnet.exe';env['PATH']=env['DOTNET_ROOT']+os.pathsep+'C:/Python313'+os.pathsep+env['PATH']
filters={
 'Lokad.Lython.Tests':'Category!=Stress&('+'|'.join('FullyQualifiedName~'+n for n in ['IntegerText','IntegerConversion','IntegerProtocol','IntegerFromBytes','IntegerAdditionAdmission','SimpleFunctionExecutionBoundary','InstructionFailureRouting','CompletedHelperCallOwnership','NativeReturn'])+')',
 'Lokad.Lython.PublicApi.Tests':'Category!=Stress&('+'|'.join('FullyQualifiedName~'+n for n in ['IntegerText','Utf8IntegerParse','IntegerConversion','IntegerPayload','IntegerParse','IntegerHeap','IntegerFromBytes','NumericProtocol','NumericIngress','BoundedNumeric','ExactInteger','ReceiverMethodSemantics','NativeCallback'])+')'}
checks={};cores={}
for target in ['net11.0','net10.0']:
 for project,selection in filters.items():
  name=project+'-'+target+'.log'
  with (r/name).open('w',encoding='utf-8') as log:
   done=subprocess.run([env['DOTNET_HOST_PATH'],'test',f'tests/{project}/{project}.csproj','-c','Release','-f',target,'--filter',selection,'--nologo','-v','quiet'],env=env,stdout=log,stderr=subprocess.STDOUT)
  result=(r/name).read_text(encoding='utf-8')[-2000:];checks[name]=dict(exitCode=done.returncode,selection=selection,summary=result)
  print(target,project,done.returncode,result[-650:],flush=True)
  (r/'focused.json').write_text(json.dumps(dict(checks=checks,fullDeliveryPending=True),indent=2)+'\n',encoding='utf-8',newline='\n')
  assert done.returncode==0,result
 p=Path('src/Lokad.Lython/bin/Release',target,'Lokad.Lython.dll');cores[target]=hashlib.sha256(p.read_bytes()).hexdigest()
 (r/'candidate'/target).mkdir(parents=True);shutil.copy2(p,r/'candidate'/target/p.name)
(r/'focused.json').write_text(json.dumps(dict(checks=checks,coreSHA256=cores,fullDeliveryPending=True),indent=2)+'\n',encoding='utf-8',newline='\n')
