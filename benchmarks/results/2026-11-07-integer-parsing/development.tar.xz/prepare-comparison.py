from pathlib import Path
import base64,copy,csv,hashlib,importlib.util,io,json,os,shutil,subprocess,sys,tempfile
r=Path(__file__).parent;prior=r.parent/'operand-sources-r43';old=r.parent/'builtin-methods-r41'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
checks=json.loads((r/'focused.json').read_text(encoding='utf-8'));assert len(checks['checks'])==4 and len(checks['coreSHA256'])==2
baseline=json.loads((r/'before.json').read_text(encoding='utf-8'))
assert sha(r/'baseline/net11.0/Lokad.Lython.dll')==baseline['coreSHA256']
assert sha(r/'candidate/net11.0/Lokad.Lython.dll')==checks['coreSHA256']['net11.0']
for role,core in [('before',r/'baseline/net11.0/Lokad.Lython.dll'),('candidate',r/'candidate/net11.0/Lokad.Lython.dll')]:
 target=r/'images'/role;shutil.copytree(prior/'images/final',target,copy_function=os.link)
 (target/'Lokad.Lython.dll').unlink();shutil.copy2(core,target/'Lokad.Lython.dll')
catalog=json.loads((prior/'catalog.json').read_text(encoding='utf-8'))
csv_case=copy.deepcopy(next(c for c in catalog['cases']if 'csv' in c['id']))
json_case=copy.deepcopy(next(c for c in catalog['cases']if 'json' in c['id']))
csv_case['id']+='-padded-integers';json_case['id']+='-integer-strings'
fixture=json.loads(csv_case['fixtureJson']);original_csv=base64.b64decode(fixture['inputFiles']['input.csv'])
rows=list(csv.reader(io.StringIO(original_csv.decode('utf-8'),newline='')));amount=rows[0].index('amount')
for row in rows[1:]:row[amount]=' '+format(int(row[amount]),'+032d')+' '
output=io.StringIO(newline='');writer=csv.writer(output,lineterminator='\n');writer.writerows(rows)
fixture['inputFiles']['input.csv']=base64.b64encode(output.getvalue().encode('utf-8')).decode('ascii');csv_case['fixtureJson']=json.dumps(fixture,separators=(',',':'))
fixture=json.loads(json_case['fixtureJson']);original_json=base64.b64decode(fixture['inputFiles']['input.jsonl']);rows=[]
for line in original_json.decode('utf-8').splitlines():
 if not line.strip():rows.append('');continue
 record=json.loads(line);value=record['amount'];magnitude=10**39+abs(value)
 record['amount']=str(-magnitude if value<0 else magnitude);rows.append(json.dumps(record,ensure_ascii=False,separators=(',',':')))
fixture['inputFiles']['input.jsonl']=base64.b64encode(('\n'.join(rows)+'\n').encode('utf-8')).decode('ascii');json_case['fixtureJson']=json.dumps(fixture,separators=(',',':'))
assert json_case['source'].count("return record['amount']")==1
json_case['source']=json_case['source'].replace("return record['amount']","return int(record['amount'])")
spec=importlib.util.spec_from_file_location('existing_reference_worker',prior/'b398/retrieved/cpython-worker.py');protocol=importlib.util.module_from_spec(spec);spec.loader.exec_module(protocol)
parent=r/'python-fixtures';parent.mkdir();validation=[]
for case in [csv_case,json_case]:
 fixture=json.loads(case['fixtureJson'])
 with tempfile.TemporaryDirectory(prefix='owned-',dir=parent) as folder:
  owned=Path(folder).resolve();owned.relative_to(r.resolve())
  for name,data in fixture['inputFiles'].items():
   path=(owned/name).resolve();path.relative_to(owned);path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(base64.b64decode(data))
  done=subprocess.run([sys.executable,'-I','-S','-X','utf8','-c',case['source']],cwd=owned,capture_output=True,text=True,encoding='utf-8');assert done.returncode==0 and not done.stderr,done.stderr
  outputs={name:(owned/name).read_bytes()for name in fixture['outputFiles']}
  if case is csv_case:
   assert done.stdout==case['expectedOutput'];assert outputs=={k:base64.b64decode(v)for k,v in fixture['outputFiles'].items()}
  fixture['outputFiles']={k:base64.b64encode(v).decode('ascii')for k,v in outputs.items()}
 case['fixtureJson']=json.dumps(fixture,ensure_ascii=False,separators=(',',':'))
 case['expectedOutput']=done.stdout
 for key,field in [('sourceSha256','source'),('fixtureSha256','fixtureJson'),('expectedOutputSha256','expectedOutput')]:case[key]=hashlib.sha256(case[field].encode('utf-8')).hexdigest()
 case['sourceUtf8Bytes']=len(case['source'].encode('utf-8'));case['expectedOutputUtf8Bytes']=len(done.stdout.encode('utf-8'));case['expectedFilesSha256']=protocol.file_digest(outputs)
 validation.append(dict(case=case['id'],records=4096,inputBytes=sum(len(base64.b64decode(v))for v in fixture['inputFiles'].values()),sourceChanged=case is json_case,output=done.stdout,expectedFilesSha256=case['expectedFilesSha256'],cpython=sys.version))
catalog['cases']=[csv_case,json_case,*[copy.deepcopy(c)for c in catalog['cases']if 'report' not in c['id']]]
assert len(catalog['cases'])==5
(r/'catalog.json').write_text(json.dumps(catalog,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
(r/'fixture-validation.json').write_text(json.dumps(validation,indent=2)+'\n',encoding='utf-8',newline='\n')
tool=r/'tool';tool.mkdir();shutil.copy2(old/'tool/complete-jobs.csproj',tool/'complete-jobs.csproj')
s=(old/'tool/Program.cs').read_text(encoding='utf-8');assert s.count('cases.Length != 4')==1
s=s.replace('cases.Length != 4','cases.Length != 5').replace('Require regex, JSON, text and CSV complete scripts.','Require two affected integer scripts and three unchanged controls.').replace('R41 shared receiver method diagnostic','R45 general UTF-8 integer parser diagnostic')
(tool/'Program.cs').write_text(s,encoding='utf-8',newline='\n')
env=os.environ.copy();env['DOTNET_ROOT']='C:/Users/JoannesVermorel/.dotnet11';env['DOTNET_HOST_PATH']=env['DOTNET_ROOT']+'/dotnet.exe';env['PATH']=env['DOTNET_ROOT']+os.pathsep+env['PATH']
with (r/'tool-build.log').open('w',encoding='utf-8') as log:
 done=subprocess.run([env['DOTNET_HOST_PATH'],'build',str(tool/'complete-jobs.csproj'),'-c','Release','--nologo','-v','quiet','-o',str(tool/'out')],env=env,stdout=log,stderr=subprocess.STDOUT)
assert done.returncode==0,(r/'tool-build.log').read_text(encoding='utf-8')[-2000:]
identity=dict(baselineSource=baseline['source'],baselineCore=baseline['coreSHA256'],candidateCore=checks['coreSHA256'],metadataHead=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),
 productionSources={str(p):sha(p) for p in Path('src/Lokad.Lython').rglob('*.cs')if not any(x in p.parts for x in ['obj','bin'])},
 workerSHA256=sha(r/'images/before/Lokad.Lython.Benchmarks.dll'),toolSHA256=sha(tool/'out/complete-jobs.dll'),catalogSHA256=sha(r/'catalog.json'),fixtureValidation=validation,fullDeliveryPending=True)
(r/'diagnostic-identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps(validation,indent=2),flush=True);print('Frozen before/after inputs and existing five-case diagnostic adaptation; no timing yet.',flush=True)
