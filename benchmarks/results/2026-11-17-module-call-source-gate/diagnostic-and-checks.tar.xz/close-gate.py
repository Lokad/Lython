from pathlib import Path
import json, re, shutil, subprocess, textwrap
r = Path(__file__).parent
repo = Path('D:/code/Lython')
work = repo / '.git/agent-worktrees/call-operands-r470'
p = work / 'tests/Lokad.Lython.PublicApi.Tests/ModuleFunctionIdentityTests.cs'
source = p.read_text(encoding='utf-8')
shutil.copyfile(p, r / 'ModuleFunctionIdentityTests.cs')
program = textwrap.dedent(re.search(r'"""(.*?)"""', source, re.S)[1]).replace("return 'ok'", "print('ok')")
run = subprocess.run(['C:/Python313/python.exe', '-X', 'utf8', '-I', '-c', program], text=True, encoding='utf-8', capture_output=True)
assert run.returncode == 0 and run.stdout == 'ok\n', (run.stdout, run.stderr)
(r / 'cpython-golden.json').write_text(json.dumps(dict(reference='CPython3.13.2 Windows', source=program, stdout=run.stdout), indent=2) + '\n', encoding='utf-8')
assert 'Passed:     2' in (r / 'baseline-identity.log').read_text(encoding='utf-8')
p.unlink()  # Exact agent-created temporary diagnostic, copied above first.
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=work, text=True).strip()
gate = dict(source='d8611c85', decision='No new production design justified. Actual builtin module lookups already use PyModule.TryGetCachedMember, stabilizing factory results in the existing metadata cache; JSON default loads/dumps and short call packet bypasses already exist.',
    stalePlanCorrection='Local imports already compile ExecutableScript and run its Code synchronously/asynchronously since840621405. No later import consolidation project remains.',
    evidence=['Both public API routes pass repeated independent attribute/getattr identity checks on all4JSON functions, aliases and budget reuse; CPython3.13.2 agrees.', 'PyModule.TryGetCachedMember checks existing cache before calling TryGetMember; JsonModuleCallable has readonly metadata, not per-record wrapper construction.', 'Existing ImportArchitectureSubsystemTests/PyModulePrimitiveTests cover module identity and mutable script namespace behavior.'],
    avoided='Do not add four explicit JSON definitions behind an existing stable-definition cache or replace already stack-backed argument packets.',
    temporaryDiagnosticRemoved=True, prototypeCreated=False, productionUnchanged=True, publicationHeld=True)
(r / 'source-gate.json').write_text(json.dumps(gate, indent=2) + '\n', encoding='utf-8')
plan = repo / 'PLAN.md'
s = plan.read_text(encoding='utf-8')
a = s.index('**R478 active source/semantic gate')
b = s.index('\n## Independent regex track', a)
s = s[:a] + '''**R478 source/semantic gate complete, no runtime prototype.** Ordinary builtin
module lookups already use PyModule.TryGetCachedMember; JSON factories run on
cache misses, not each record. Both API routes pass repeated independent attribute/
getattr identity and budget-reuse checks; CPython agrees. Temporary diagnostic
removed, source/log preserved in agent notes; existing module-identity regressions
remain. Do not add explicit definitions behind the existing stable metadata cache.
No more unchanged checks needed for this gate. Next design selection must identify
remaining complete work/storage, not the already-removed import/default-JSON/short-
packet stages. R477 delivery continues independently; no runtime edits here.
''' + s[b:]
plan.write_text(s, encoding='utf-8', newline='\n')
print('Gate complete: existing module metadata cache already removes proposed repeated work. No production prototype or duplicate test retained; stale import task removed.')
