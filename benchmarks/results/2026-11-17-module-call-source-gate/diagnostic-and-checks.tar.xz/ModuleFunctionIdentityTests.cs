using Lokad.Lython.Tests.Harness;

namespace Lokad.Lython.PublicApi.Tests;

public sealed class ModuleFunctionIdentityTests
{
    [Theory]
    [InlineData(false)]
    [InlineData(true)]
    public async Task JsonFunctionsKeepIdentityAcrossIndependentLookups(bool asynchronous)
    {
        const string source = """
            import json
            assert json.loads is json.loads
            assert json.dumps is json.dumps
            assert json.load is json.load
            assert json.dump is json.dump
            for name in ['load', 'loads', 'dump', 'dumps']:
                first = getattr(json, name)
                second = getattr(json, name)
                assert first is second
            assert json.loads('{"x":3}') == {'x':3}
            assert json.dumps({'x':3}, sort_keys=True) == '{"x": 3}'
            return 'ok'
            """;
        var budget = new LythonMemoryBudget(2 * 1024 * 1024);
        using (var script = new LythonEngine().Compile(source, budget))
        {
            Assert.True(script.IsValid, string.Join("; ", script.Diagnostics));
            var baseline = budget.ReservedBytes;
            using (var result = asynchronous ? await script.RunAsync(new MockLythonHost()) : script.Run(new MockLythonHost()))
            {
                Assert.True(result.Success, result.Failure?.Message);
                Assert.Equal("ok", result.ReturnValue);
            }
            Assert.Equal(baseline, budget.ReservedBytes);
        }
        Assert.Equal(0, budget.ReservedBytes);
    }
}
