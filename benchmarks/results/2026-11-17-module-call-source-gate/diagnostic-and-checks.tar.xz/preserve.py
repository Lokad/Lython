from pathlib import Path
import hashlib, json, shutil, tarfile
r = Path(__file__).parent
repo = Path('D:/code/Lython')
out = repo / 'benchmarks/results/2026-11-17-module-call-source-gate'
out.mkdir(exist_ok=False)
shutil.copyfile(r / 'source-gate.json', out / 'source-gate.json')
shutil.copyfile(r / 'cpython-golden.json', out / 'cpython-golden.json')
with tarfile.open(out / 'diagnostic-and-checks.tar.xz', 'w:xz') as archive:
    for p in r.iterdir():
        if p.is_file(): archive.add(p, arcname=p.name)
names = ['src/Lokad.Lython/Runtime/PyModule.cs', 'src/Lokad.Lython/Runtime/LythonRuntime.Imports.cs', 'src/Lokad.Lython/Runtime/LythonRuntime.JsonModule.cs', 'src/Lokad.Lython/Runtime/LythonRuntime.Json.Options.cs', 'src/Lokad.Lython/Runtime/LythonRuntime.Executable.Calls.Invoke.cs', 'src/Lokad.Lython/Runtime/Calls/CallableInvocation.cs']
(out / 'source-inputs.json').write_text(json.dumps(dict(revision='d8611c85', inputs={name:hashlib.sha256((repo / name).read_bytes()).hexdigest() for name in names}), indent=2) + '\n', encoding='utf-8')
(out / 'README.md').write_text('''# Module/call source gate: existing paths already consolidated

R478,2026-11-17UTC, d8611c85. **No runtime prototype or new performance claim.**
Public repeated attribute/getattr identity checks on all four JSON functions pass
both APIs and shared-budget cleanup; independent CPython3.13.2agrees.

PyModule.TryGetCachedMember already preserves immutable factory results. The
new expressions in JsonModule.TryGetMember are cache-miss factories, not wrapper
allocation per record. Explicit JSON fields behind that cache would add duplicate
machinery. Default loads/dumps already bypass unused option binding, default
options already share immutable metadata, and short general calls already use
stack-backed borrowed packets. No discarded internal architecture is enforced.

Local imports already compile ExecutableScript and execute its Code under both
APIs since840621405. The later import-consolidation task in PLAN was stale and
is removed; explicit mirroring for mutable module exports/escaping functions stays.
Public compilation already retains only real lowered consumers, not whole AST/
lowered snapshots. These are source corrections, not newly delivered optimizations.

The bounded gate ends here. Temporary two-case diagnostic source/build/logs are
archived, then removed from the test project. Existing module identity and script
mutation regressions remain. R477 qualification continues independently; no full
unchanged qualification, VM timing or alternative cache/registry introduced.
Publication held and broader design selection remains active.

[Source decision](source-gate.json),[source identity](source-inputs.json),
[independent Python program](cpython-golden.json),
[temporary diagnostic/build/logs](diagnostic-and-checks.tar.xz).
''', encoding='utf-8', newline='\n')
with (repo / 'benchmarks/EXPERIMENTS.md').open('a', encoding='utf-8', newline='\n') as stream:
    stream.write('''
[R478 module/call source gate](results/2026-11-17-module-call-source-gate/README.md):
no runtime prototype. Both API identity/budget checks and CPython agree; builtin
module factory outputs already use the stable metadata cache. DefaultJSON options/
binding bypasses and borrowed short packets already exist. Local imports already
use executable Code since840621405; stale planned consolidation removed. Temporary
diagnostic archived/removed, existing semantic regressions retained. No duplicate
cache layer, new framework, timing or repeated full qualification. R477 delivery
independent, broader design selection active, publication held.
''')
print('R478 source corrections/evidence preserved, no runtime change or new test scaffolding.')
