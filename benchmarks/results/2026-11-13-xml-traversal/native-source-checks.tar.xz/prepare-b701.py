from pathlib import Path
import ast, hashlib, json, tarfile
r=Path(__file__).parent;prior=r/'b700';out=r/'b701';out.mkdir()
source=json.loads((r/'native/candidate-identity.json').read_text(encoding='utf-8'));identity=json.loads((prior/'identity.json').read_text(encoding='utf-8'))
identity['sourceRevision']='R330 refined965c7e0f vs qualifiedR329/frozenc16b44f0; native synchronous pulls, real asynchronous tag protocols; int depth after ushort gave no storage benefit'
identity['purpose']+='; refined native pull removes unconditional async state-machine entry; retain original adverse B700 and narrowed allocation result'
identity['coreSHA256']={label:source['coreSHA256']['candidate'if label.startswith('candidate')else'reference']for label in['reference','candidate','reference-control','candidate-control']}
(out/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8')
oldroot='/home/lokad/lython-bench-checks/xml-traversal-b700-20261113';root='/home/lokad/lython-bench-checks/xml-traversal-b701-20261113';unit='lython-b701-xml-traversal-20261113'
for name in['collect.py','archive-owned.py','run.sh','retrieve.py','summarize.py']:
 s=(prior/name).read_text(encoding='utf-8').replace(oldroot,root).replace('lython-b700-xml-traversal-20261113',unit).replace('B700','B701')
 if name.endswith('.py'):ast.parse(s)
 (out/name).write_text(s,encoding='utf-8',newline='\n')
with tarfile.open(out/'payload.tgz','w:gz')as t:
 for name in['identity.json','collect.py','archive-owned.py','run.sh']:t.add(out/name,arcname=name)
 t.add(r/'catalog.json',arcname='representative.json');t.add(r/'native/candidate-core.dll',arcname='candidate-core.dll');t.add(r/'native/candidate-identity.json',arcname='source-identity.json')
with tarfile.open(out/'payload.tgz')as t:unpacked=sum(m.size for m in t.getmembers())
config=dict(root=root,sourceRoot='/home/lokad/lython-bench-checks/xml-select-b699-20261113',unit=unit,identity=identity,retire=json.loads((r/'final-retirement-inspection.json').read_text(encoding='utf-8'))['retire'],payloadBytes=(out/'payload.tgz').stat().st_size,payloadSHA256=hashlib.sha256((out/'payload.tgz').read_bytes()).hexdigest(),unpackedBytes=unpacked)
(out/'config.json').write_text(json.dumps(config,indent=2)+'\n',encoding='utf-8')
s=(prior/'launch.py').read_text(encoding='utf-8').replace("r.parent/'candidate-identity.json'","r.parent/'native/candidate-identity.json'").replace("r.parent / 'candidate-identity.json'","r.parent / 'native/candidate-identity.json'")
s=s.replace("['xml-utf8-input-b696-','xml-utf8-input-b697-','xml-select-b698-','xml-select-b699-','positional-zip-b684-','positional-zip-b685-']","['xml-traversal-b700-','xml-select-b698-']").replace('lython-b700-fixtures','lython-b701-fixtures')
ast.parse(s);(out/'launch.py').write_text(s,encoding='utf-8',newline='\n')
print('Prepared refined source-pair comparison on the original catalog/clocks,180s owner; initial adverse evidence remains.',flush=True)
