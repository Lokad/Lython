from pathlib import Path
import ast, hashlib, json, subprocess, tarfile
r=Path(__file__).parent;proofs=[]
for canonical,member,remote in [('benchmarks/results/2026-11-13-xml-traversal/first-source-checks.tar.xz','candidate-core.dll','xml-traversal-b700-20261113/candidate/Lokad.Lython.dll'),('benchmarks/results/2026-11-13-xml-selection/b698/observations.tgz','representative.json','xml-select-b698-20261113/representative.json')]:
 p=Path(canonical);assert subprocess.check_output(['git','show','HEAD:'+canonical])==p.read_bytes()
 with tarfile.open(p)as t:data=t.extractfile(member).read()
 proofs.append(dict(path=remote,canonical=canonical,member=member,sha256=hashlib.sha256(data).hexdigest(),bytes=len(data)))
s=(r/'retirement-inspection-command.py').read_text(encoding='utf-8');a=s.index('proofs=');b=s.index('\nwith(',a);s=s[:a]+'proofs='+repr(proofs)+s[b:]
s=s.replace("['xml-utf8-input-b696-','xml-utf8-input-b697-','xml-select-b698-','xml-select-b699-','positional-zip-b684-','positional-zip-b685-']","['xml-traversal-b700-','xml-select-b698-']")
ast.parse(s);(r/'final-retirement-inspection-command.py').write_text(s,encoding='utf-8')
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
done=subprocess.run(ssh+['python3 -'],input=s,text=True,encoding='utf-8',capture_output=True)
(r/'final-retirement-inspection.log').write_text(done.stdout+done.stderr,encoding='utf-8');assert done.returncode==0,done.stderr
d=json.loads(done.stdout);(r/'final-retirement-inspection.json').write_text(json.dumps(d,indent=2)+'\n',encoding='utf-8');print(d,flush=True)
