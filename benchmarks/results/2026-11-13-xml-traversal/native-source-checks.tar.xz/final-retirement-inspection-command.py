from pathlib import Path
import fcntl,hashlib,json,os,shutil,stat,subprocess
base=Path('/home/lokad/lython-bench-checks').resolve();proofs=[{'path': 'xml-traversal-b700-20261113/candidate/Lokad.Lython.dll', 'canonical': 'benchmarks/results/2026-11-13-xml-traversal/first-source-checks.tar.xz', 'member': 'candidate-core.dll', 'sha256': '53f3eb87192abcd1015c0535e1c2ded7fe650c46d7d7225012b0ad7a2dd34b36', 'bytes': 5714944}, {'path': 'xml-select-b698-20261113/representative.json', 'canonical': 'benchmarks/results/2026-11-13-xml-selection/b698/observations.tgz', 'member': 'representative.json', 'sha256': '933f84c8a8d5c84a110fd9ce044f0fa3a8a7b3055b79564803cde50ee5d770f1', 'bytes': 109831}]
with(base/'comparison-vm.lock').open('a')as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[d]otnet.*complete-jobs.dll|[p]erf record|[p]ython3.*cpython-worker.py'],capture_output=True).returncode==1
 rows=[]
 for proof in proofs:
  p=base/proof['path'];s=p.lstat();assert p.resolve(strict=True)==p and p.is_relative_to(base)and stat.S_ISREG(s.st_mode)and s.st_uid==os.getuid()and s.st_size==proof['bytes']and hashlib.sha256(p.read_bytes()).hexdigest()==proof['sha256']
  aliases=[]
  for folder,dirs,files in os.walk(base,followlinks=False):
   for name in files:
    q=Path(folder)/name;t=q.lstat()
    if(t.st_dev,t.st_ino)==(s.st_dev,s.st_ino):aliases.append(str(q.relative_to(base)))
  assert len(aliases)==s.st_nlink
  assert all(any(prefix in name for prefix in ['xml-traversal-b700-','xml-select-b698-'])for name in aliases),(proof['path'],aliases)
  rows.append(dict(**proof,device=s.st_dev,inode=s.st_ino,links=s.st_nlink,allocatedBytes=s.st_blocks*512,aliases=aliases))
 print(json.dumps(dict(freshIdleLease=True,readOnly=True,freeBytes=shutil.disk_usage(base).free,retire=rows)))
