from pathlib import Path
import hashlib, json, shutil, tarfile
r=Path(__file__).parent;source=r/'native';out=Path('benchmarks/results/2026-11-13-xml-traversal')
identity=json.loads((source/'candidate-identity.json').read_text(encoding='utf-8'));assert len(identity['sources'])==578
assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==sha for p,sha in identity['sources'].items())
folder=out/'b701';folder.mkdir(exist_ok=True)
for name in['observations.tgz','archive-receipt.json','terminal-status.json','summary.json']:shutil.copy2(r/'b701'/name,folder/name)
assert json.loads((r/'b701/summary.json').read_text(encoding='utf-8'))['complete']
with tarfile.open(out/'native-source-checks.tar.xz','w:xz')as t:
 for name in['candidate-core.dll','candidate-identity.json','candidate-sources.tar.xz','freeze.py','freeze-build.log','catalog.json','allocation-reference-catalog.json','allocation-candidate-catalog.json','measure-allocation.py','allocation-summary.json','verify-workers.py','worker-reference-validation.json','worker-candidate-validation.json','worker-reference.stderr','worker-candidate.stderr','check.py','check-budget-comparison.py']:
  t.add(source/name,arcname=name)
 for pattern in['*-allocation-*.*','*net11.0.log','*net10.0.log']:
  for p in source.glob(pattern):t.add(p,arcname=p.name)
 for name in['prepare-b701.py','inspect-final-retirement.py','final-retirement-inspection-command.py','final-retirement-inspection.log','final-retirement-inspection.json','narrowing-decision.json','save-final.py']:t.add(r/name,arcname=name)
 for p in(r/'b701').glob('*.py'):t.add(p,arcname='b701/'+p.name)
 for name in['config.json','launch.log','observe-not-before.json']:t.add(r/'b701'/name,arcname='b701/'+name)
 for name in['tests/Lokad.Lython.PublicApi.Tests/XmlTraversalTests.cs','tests/Lokad.Lython.Tests/XmlTraversalOwnershipTests.cs']:t.add(name,arcname=name)
shutil.copy2(source/'allocation-summary.json',out/'native-allocation-summary.json')
p=out/'README.md';s=p.read_text(encoding='utf-8').replace('# Native XML traversal: initial evidence','# Native XML traversal and alias-safe clear')
if '## Original and discarded forms' in s:s='# Native XML traversal and alias-safe clear\n\n'+s.split('## Original and discarded forms',1)[1].lstrip()
at=s.index('2026-11-13.')
s=s[:at]+'''2026-11-13. Retain refined965c7e0f against qualifiedR329/frozenc16b44f0 for
Python compatibility and bounded traversal storage, with no demonstrated CPU gain.
One funded nonrecursive cursor powers iter/itertext; a conservative subtree-depth
bound admits its fixed stack before publication. clear replaces attributes before
discarding child-reference backing, preserving old maps/text/child aliases. No new
pool, ownership subsystem, runtime policy or public option. Incremental input is separate.

Native pulls now share one synchronous path across Run/RunAsync; only user-defined
tag equality enters the constant-space async protocol loop. Both actual.NET11/10
targets pass32internal/55public focused cases, including real async equality,
in-flight cancellation, suppressed admission refusal, alias retention, pre-mutation
refusal, lazy errors, deep trees and exhausted-stack release. Full platform/stress/
installed-consumer qualification is pending; publication is held.

B701 repeats the original catalog/clocks on refined965, completing151.668s/all gates:

| Refined result | Allocated-byte change | Elapsed change | Wider process CPU change |
| --- | ---: | ---: | ---: |
| Aggregation: iter versus findall |−0.41%|−1.05..+2.57%|−0.36..+1.98%|
| Unchanged XML settings |+0.62..+0.63%|−2.16..−0.46%|−2.18..−0.75%|

Aggregation process spreads1.49%candidate/2.09%reference keep the apparent small
difference uncertain; settings candidate spread1.69% also limits precision. The
initial8–10%adverse direction is no longer established, not proof of a universal
improvement. Accept small unresolved aggregation CPU debt and the8B/element depth
metadata cost. No unchanged retiming or further field-packing work at this checkpoint.
Native traversal succeeds with4KiBspare where materialized selection needs capacity
for every match; the0.4%whole-invocation allocation reduction is separate and modest.
Original/adverse conditions and discarded narrowing remain below.

[Final source/checks](native-source-checks.tar.xz), [allocated bytes](native-allocation-summary.json),
[B701raw](b701/observations.tgz) record the578source inputs and exact measured images.

## Original and discarded forms

'''+s[at:]
p.write_text(s,encoding='utf-8',newline='\n')
print('Refined965 source/checks/comparison archived; retain compatibility/working-storage benefit with explicit allocation and CPU debt.',flush=True)
