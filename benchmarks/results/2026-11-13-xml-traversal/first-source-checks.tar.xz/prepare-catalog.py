from pathlib import Path
import base64, copy, hashlib, json, struct, subprocess, tempfile
r=Path(__file__).parent;prior=r.parent/'xml-select-r329'
catalog=json.loads((prior/'catalog.json').read_text(encoding='utf-8'));control=catalog['cases'][0]
n=2048
text='<records>'+''.join(f'<row count="{i}">café Ω😀 {i}</row>'for i in range(n))+'</records>'
template='''import xml.etree.ElementTree as ET
with open('input.xml') as source:
    root=ET.fromstring(source.read())
total=0
count=0
for row in SELECTION:
    total+=int(row.get('count'))
    count+=1
with open('report.txt','w',newline='') as report:
    report.write(str(count)+'\\n'+str(total)+'\\n')
print(count,total)
'''
expected=f'{n} {n*(n-1)//2}\n';report=f'{n}\n{n*(n-1)//2}\n'
fixture=json.loads(control['fixtureJson']);fixture.update(size=n,text='',inputFiles={'input.xml':base64.b64encode(text.encode()).decode()},outputFiles={'report.txt':base64.b64encode(report.encode()).decode()})
fixture_json=json.dumps(fixture,separators=(',',':'),ensure_ascii=False)
sha=lambda v:hashlib.sha256(v.encode()).hexdigest()
h=hashlib.sha256();h.update(struct.pack('>i',1));name=b'report.txt';data=report.encode();h.update(struct.pack('>i',len(name)));h.update(name);h.update(struct.pack('>i',len(data)));h.update(data)
cases=[]
for label,selection in [('findall',"root.findall('.//row')"),('iter',"root.iter('row')")]:
 source=template.replace('SELECTION',selection);case=copy.deepcopy(control)
 case.update(id='scripts.xml-records.'+label+'.large',size=n,source=source,expectedOutput=expected,fixtureJson=fixture_json,sourceUtf8Bytes=len(source.encode()),expectedOutputUtf8Bytes=len(expected.encode()),fixtureTextUtf8Bytes=0,fixtureTextCodePoints=0,sourceSha256=sha(source),fixtureSha256=sha(fixture_json),expectedOutputSha256=sha(expected),expectedFilesSha256=h.hexdigest())
 cases.append(case)
 with tempfile.TemporaryDirectory(prefix='lython-xml-records-',dir=r.resolve())as folder:
  p=Path(folder).resolve();assert p.parent==r.resolve()and p.is_relative_to(Path.cwd().resolve())and p.name.startswith('lython-xml-records-')
  (p/'input.xml').write_bytes(text.encode());done=subprocess.run(['C:/Python313/python.exe','-I','-S','-X','utf8','-c',source],cwd=folder,capture_output=True,encoding='utf-8',timeout=10)
  assert done.returncode==0 and not done.stderr and done.stdout==expected,(label,done.stdout,done.stderr)
  assert(p/'report.txt').read_bytes()==report.encode()and(p/'input.xml').read_bytes()==text.encode()
catalog['cases']=[*cases,control]
(r/'catalog.json').write_text(json.dumps(catalog,separators=(',',':'),ensure_ascii=False)+'\n',encoding='utf-8')
for role,case in zip(['reference','candidate'],cases):
 allocation=copy.deepcopy(catalog);selected=copy.deepcopy(case);selected['id']='scripts.xml-records.large';allocation['cases']=[selected,control]
 (r/('allocation-'+role+'-catalog.json')).write_text(json.dumps(allocation,separators=(',',':'),ensure_ascii=False)+'\n',encoding='utf-8')
(r/'workload-python-goldens.json').write_text(json.dumps(dict(python='3.13.2',inputBytes=len(text.encode()),rows=n,lookupFormsIntentionallyDiffer=True,onlySourceDifference='root.findall(\'.//row\') vs root.iter(\'row\')',identicalStdoutAndFiles=True,expectedOutput=expected,expectedFilesSHA256=h.hexdigest(),sources=[dict(case=c['id'],sourceSHA256=c['sourceSha256'])for c in cases],unchangedControl=control['id'],performanceNotMeasured=True),indent=2)+'\n',encoding='utf-8')
print('Two exact CPython aggregation/report goldens pass; native traversal and materialized selection differ intentionally; unchanged XML settings control.',flush=True)
