from pathlib import Path
import ast, hashlib, json, subprocess, tarfile
r=Path(__file__).parent
proofs=[]
for canonical,member,remote in [('benchmarks/results/2026-11-13-xml-utf8-input/source-checks.tar.xz','candidate-core.dll','xml-utf8-input-b696-20261113/candidate/Lokad.Lython.dll'),('benchmarks/results/2026-11-13-positional-zip/comparison/observations.tgz','representative.json','positional-zip-b685-20261113/representative.json')]:
 p=Path(canonical);assert subprocess.check_output(['git','show','HEAD:'+canonical])==p.read_bytes()
 with tarfile.open(p)as t:data=t.extractfile(member).read()
 proofs.append(dict(path=remote,canonical=canonical,member=member,sha256=hashlib.sha256(data).hexdigest(),bytes=len(data)))
assert proofs[0]['sha256']=='316142ab117c0b9d0729200161d65f5902966be2c29c5c01dd23c8ee67c08768'
s='''from pathlib import Path
import fcntl,hashlib,json,os,shutil,stat,subprocess
base=Path('/home/lokad/lython-bench-checks').resolve();proofs=PROOFS
with(base/'comparison-vm.lock').open('a')as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[d]otnet.*complete-jobs.dll|[p]erf record|[p]ython3.*cpython-worker.py'],capture_output=True).returncode==1
 rows=[]
 for proof in proofs:
  p=base/proof['path'];s=p.lstat();assert p.resolve(strict=True)==p and p.is_relative_to(base)and stat.S_ISREG(s.st_mode)and s.st_uid==os.getuid()and s.st_size==proof['bytes']and hashlib.sha256(p.read_bytes()).hexdigest()==proof['sha256']
  aliases=[]
  for folder,dirs,files in os.walk(base,followlinks=False):
   for name in files:
    q=Path(folder)/name;t=q.lstat()
    if(t.st_dev,t.st_ino)==(s.st_dev,s.st_ino):aliases.append(str(q.relative_to(base)))
  assert len(aliases)==s.st_nlink
  assert all(any(prefix in name for prefix in ['xml-utf8-input-b696-','xml-utf8-input-b697-','xml-select-b698-','xml-select-b699-','positional-zip-b684-','positional-zip-b685-'])for name in aliases),(proof['path'],aliases)
  rows.append(dict(**proof,device=s.st_dev,inode=s.st_ino,links=s.st_nlink,allocatedBytes=s.st_blocks*512,aliases=aliases))
 print(json.dumps(dict(freshIdleLease=True,readOnly=True,freeBytes=shutil.disk_usage(base).free,retire=rows)))
'''.replace('PROOFS',repr(proofs))
ast.parse(s);(r/'retirement-inspection-command.py').write_text(s,encoding='utf-8')
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
done=subprocess.run(ssh+['python3 -'],input=s,text=True,encoding='utf-8',capture_output=True)
old=r/'retirement-inspection.log'
if old.exists()and not(r/'first-retirement-inspection.log').exists():(r/'first-retirement-inspection.log').write_bytes(old.read_bytes())
old.write_text(done.stdout+done.stderr,encoding='utf-8');assert done.returncode==0,done.stderr
d=json.loads(done.stdout);(r/'retirement-inspection.json').write_text(json.dumps(d,indent=2)+'\n',encoding='utf-8');print(d,flush=True)
