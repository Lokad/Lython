from pathlib import Path
import ast, hashlib, json, tarfile
r=Path(__file__).parent;prior=r.parent/'xml-select-r329/b698';out=r/'b700';out.mkdir()
source=json.loads((r/'candidate-identity.json').read_text(encoding='utf-8'));identity=json.loads((prior/'identity.json').read_text(encoding='utf-8'))
identity['sourceRevision']='R330 frozen53f3eb87 vs qualifiedR329/frozenc16b44f0; native tree traversal vs materialized selection; fixed B685 workers/adapter0.4'
identity['purpose']='Complete XML aggregation/report: reference findall vs candidate iter intentionally differ; unchanged XML settings control exposes parser-metadata cost; allocation measured separately'
identity['coreSHA256']={label:source['coreSHA256']['candidate'if label.startswith('candidate')else'reference']for label in['reference','candidate','reference-control','candidate-control']}
identity['catalogSHA256']=hashlib.sha256((r/'catalog.json').read_bytes()).hexdigest()
identity['referenceCase']='scripts.xml-records.findall.large';identity['variantCase']='scripts.xml-records.iter.large';identity['controlCase']='scripts.xml-settings.large';identity['sourceAndScriptDifferIntentionally']=True
(out/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8')
oldroot='/home/lokad/lython-bench-checks/xml-select-b698-20261113';root='/home/lokad/lython-bench-checks/xml-traversal-b700-20261113';unit='lython-b700-xml-traversal-20261113'
for name in ['collect.py','archive-owned.py','run.sh','retrieve.py','summarize.py']:
 s=(prior/name).read_text(encoding='utf-8').replace(oldroot,root).replace('lython-b698-xml-select-20261113',unit).replace('B698','B700')
 if name=='collect.py':s=s.replace("jobs=[['scripts.xml-settings.large','warm'],['scripts.file-search.large','warm']]","jobs=[['scripts.xml-records.findall.large','warm'],['scripts.xml-settings.large','warm']]")
 if name=='summarize.py':s=s.replace('sourceAndScriptDifferIntentionally=False','sourceAndScriptDifferIntentionally=True')
 if name.endswith('.py'):ast.parse(s)
 (out/name).write_text(s,encoding='utf-8',newline='\n')
with tarfile.open(out/'payload.tgz','w:gz')as t:
 for name in ['identity.json','collect.py','archive-owned.py','run.sh']:t.add(out/name,arcname=name)
 t.add(r/'catalog.json',arcname='representative.json');t.add(r/'candidate-core.dll',arcname='candidate-core.dll');t.add(r/'candidate-identity.json',arcname='source-identity.json')
with tarfile.open(out/'payload.tgz')as t:unpacked=sum(m.size for m in t.getmembers())
config=dict(root=root,sourceRoot='/home/lokad/lython-bench-checks/xml-select-b699-20261113',unit=unit,identity=identity,retire=json.loads((r/'retirement-inspection.json').read_text(encoding='utf-8'))['retire'],payloadBytes=(out/'payload.tgz').stat().st_size,payloadSHA256=hashlib.sha256((out/'payload.tgz').read_bytes()).hexdigest(),unpackedBytes=unpacked)
(out/'config.json').write_text(json.dumps(config,indent=2)+'\n',encoding='utf-8')
s=(r.parent/'xml-utf8-input-r328/b696/launch.py').read_text(encoding='utf-8')
s=s.replace("['word-buffer-loan-b690-', 'word-buffer-loan-b691-', 'post-loan-profile-b692-', 'final-slot-binding-b693-', 'final-slot-binding-b694-']","['xml-utf8-input-b696-','xml-utf8-input-b697-','xml-select-b698-','xml-select-b699-','positional-zip-b684-','positional-zip-b685-']").replace('lython-b696-fixtures','lython-b700-fixtures')
ast.parse(s);(out/'launch.py').write_text(s,encoding='utf-8',newline='\n')
print('Prepared two complete XML jobs,4Lython roles,12s wall warmups/1s batches/180s owner; intent and unchanged control explicit.',flush=True)
