from pathlib import Path
import os, subprocess
r = Path(__file__).parent
env = dict(os.environ)
env['DOTNET_ROOT'] = 'C:/Users/JoannesVermorel/.dotnet11'
env['PATH'] = env['DOTNET_ROOT'] + ';C:/Python313;' + env['PATH']
for framework in ['net11.0', 'net10.0']:
    for label, project, selection in [('internal', 'tests/Lokad.Lython.Tests/Lokad.Lython.Tests.csproj', 'FullyQualifiedName~XmlUtf8ReaderTests|FullyQualifiedName~ElementTreeAccountingTests|FullyQualifiedName~XmlSelectionOwnershipTests|FullyQualifiedName~XmlTraversalOwnershipTests'), ('public', 'tests/Lokad.Lython.PublicApi.Tests/Lokad.Lython.PublicApi.Tests.csproj', 'FullyQualifiedName~ElementTreeCompatibilityTests|FullyQualifiedName~XmlSelectionTests|FullyQualifiedName~XmlTraversalTests')]:
        log = r / (label + '-' + framework + '.log')
        with log.open('w', encoding='utf-8', newline='\n') as f:
            done = subprocess.run([env['DOTNET_ROOT'] + '/dotnet.exe', 'test', project, '-c', 'Release', '-f', framework, '--filter', selection, '--nologo'], env=env, stdout=f, stderr=subprocess.STDOUT)
        print(framework, label, done.returncode, '\n'.join(log.read_text(encoding='utf-8').splitlines()[-14:]), flush=True)
        assert done.returncode == 0
