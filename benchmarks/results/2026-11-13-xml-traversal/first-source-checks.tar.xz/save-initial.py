from pathlib import Path
import json, shutil, tarfile
r=Path(__file__).parent;out=Path('benchmarks/results/2026-11-13-xml-traversal');out.mkdir(exist_ok=True)
for stem,source in [('first',r),('narrowed',r/'refined')]:
 with tarfile.open(out/(stem+'-source-checks.tar.xz'),'w:xz')as t:
  for name in ['candidate-core.dll','candidate-identity.json','candidate-sources.tar.xz','freeze.py','freeze-build.log','catalog.json','allocation-reference-catalog.json','allocation-candidate-catalog.json','measure-allocation.py','allocation-summary.json','verify-workers.py','worker-reference-validation.json','worker-candidate-validation.json','worker-reference.stderr','worker-candidate.stderr']:
   if(source/name).exists():t.add(source/name,arcname=name)
  for pattern in ['*-allocation-*.*','*net11.0.log','*net10.0.log']:
   for p in source.glob(pattern):t.add(p,arcname=p.name)
  if stem=='first':
   for name in ['prepare-catalog.py','workload-python-goldens.json','verify-goldens.py','python-goldens.json','check.py','check-complete.py','prepare-checks.py','prepare-diagnostics.py','prepare-comparison.py','inspect-retirement.py','retirement-inspection-command.py','retirement-inspection.log','first-retirement-inspection.log','retirement-inspection.json','narrowing-decision.json','prepare-final.py','save-initial.py']:t.add(r/name,arcname=name)
   for p in(r/'b700').glob('*.py'):t.add(p,arcname='b700/'+p.name)
   for name in ['config.json','launch.log','observe-not-before.json']:t.add(r/'b700'/name,arcname='b700/'+name)
 shutil.copy2(source/'allocation-summary.json',out/(stem+'-allocation-summary.json'))
folder=out/'b700';folder.mkdir(exist_ok=True)
for name in ['observations.tgz','archive-receipt.json','terminal-status.json','summary.json']:shutil.copy2(r/'b700'/name,folder/name)
(out/'README.md').write_text('''# Native XML traversal: initial evidence

2026-11-13. Initial frozen53f3eb87 supports iter/itertext/alias-safe clear with a
funded fixed traversal stack. Reference is qualifiedR329/frozenc16b44f0. Complete
aggregation intentionally changes root.findall('.//row') to root.iter('row');
inputs, stdout/report bytes and stockCPython3.13.2 semantic goldens agree. The
unchanged XML settings script exposes parser-metadata cost. No external timing
comparison or whole-runtime improvement is claimed.

B700 on the quietF4as_v7 VM completes two jobs in151.952s, all identity/golden/
quiet/join/archive gates pass. Four fresh Lython processes per job,12-second
full-request wall warmup budgets and five rotating1s wall-sized batches. Guest
clocks include mediated RAM-file I/O, exact output/file checks and prior-result
cleanup; compile/startup/reset/protocol/final-cache cleanup are excluded. Wider
process CPU includes reset/protocol. Ranges pair process medians, not confidence
intervals. Observations stay persistent separately from RAM fixtures; users join
and fixtures are removed/unmounted before persistent archives are SHA-verified.

| Initial result | Allocated-byte change | Elapsed change | Wider process CPU change |
| --- | ---: | ---: | ---: |
| Aggregation, native iter versus materialized findall |−0.41%|+7.88..+9.86%|+6.60..+9.51%|
| Unchanged XML settings |+0.63%|−2.78..+0.67%|−3.03..+1.10%|

Settings allocation rises about12,288B/1,537elements, consistent with8B/object
for the depth bound. Narrowed1d15eb44 (ushort instead of int) still adds0.63%;
withdraw it and its casts. Do not pursue unsafe layout or a field-packing framework.
Both original and narrowed allocations use two fresh local.NET11 processes per
source, five64-invocation blocks after warmup, unchanged public-API tool, complete
goldens and per-run/final budget-baseline checks. Compilation/startup/final compiled
cleanup are excluded; these are allocated bytes, not live heap or latency.

The initial native pull unconditionally enters an async state machine. Development
now separates the shared synchronous native path from the constant-space async
user-equality loop. Its final timing and delivery are not established by B700.
The source snapshots and all adverse evidence remain; they are prototypes, not
full qualification. Focused checks cover graph/clear aliases, admission before
mutation, actual async tag equality, in-flight cancellation, terminal refusal,
budget reuse, lazy errors, text/order and deep trees. Six new public goldens match
isolated CPython. The first test compilation's target-typed-options ambiguity is
preserved; explicit LythonRunOptions fixes it without a runtime API change.

[Original source/checks](first-source-checks.tar.xz),
[narrowing source/checks](narrowed-source-checks.tar.xz),
[B700raw](b700/observations.tgz) preserve exact578production inputs and identities.
The retirement preflight initially rejected an unlisted second hard link for the
old ZIP manifest. It changed no VM files; both aliases were then independently
proved before retirement. Committed original evidence/currentc16images remain.
Incremental parsing remains separate. Publication is postponed.
''',encoding='utf-8',newline='\n')
print('Initial/narrowing source and allocation evidence archived; original adverse B700 remains explicit.',flush=True)
