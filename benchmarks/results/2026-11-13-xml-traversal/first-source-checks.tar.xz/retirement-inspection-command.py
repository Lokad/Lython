from pathlib import Path
import fcntl,hashlib,json,os,shutil,stat,subprocess
base=Path('/home/lokad/lython-bench-checks').resolve();proofs=[{'path': 'xml-utf8-input-b696-20261113/candidate/Lokad.Lython.dll', 'canonical': 'benchmarks/results/2026-11-13-xml-utf8-input/source-checks.tar.xz', 'member': 'candidate-core.dll', 'sha256': '316142ab117c0b9d0729200161d65f5902966be2c29c5c01dd23c8ee67c08768', 'bytes': 5706752}, {'path': 'positional-zip-b685-20261113/representative.json', 'canonical': 'benchmarks/results/2026-11-13-positional-zip/comparison/observations.tgz', 'member': 'representative.json', 'sha256': 'e008fd216b52446a395b063bfed333289b203419f2bc1fb61fd94c4bc4fa4b4a', 'bytes': 1596355}]
with(base/'comparison-vm.lock').open('a')as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[d]otnet.*complete-jobs.dll|[p]erf record|[p]ython3.*cpython-worker.py'],capture_output=True).returncode==1
 rows=[]
 for proof in proofs:
  p=base/proof['path'];s=p.lstat();assert p.resolve(strict=True)==p and p.is_relative_to(base)and stat.S_ISREG(s.st_mode)and s.st_uid==os.getuid()and s.st_size==proof['bytes']and hashlib.sha256(p.read_bytes()).hexdigest()==proof['sha256']
  aliases=[]
  for folder,dirs,files in os.walk(base,followlinks=False):
   for name in files:
    q=Path(folder)/name;t=q.lstat()
    if(t.st_dev,t.st_ino)==(s.st_dev,s.st_ino):aliases.append(str(q.relative_to(base)))
  assert len(aliases)==s.st_nlink
  assert all(any(prefix in name for prefix in ['xml-utf8-input-b696-','xml-utf8-input-b697-','xml-select-b698-','xml-select-b699-','positional-zip-b684-','positional-zip-b685-'])for name in aliases),(proof['path'],aliases)
  rows.append(dict(**proof,device=s.st_dev,inode=s.st_ino,links=s.st_nlink,allocatedBytes=s.st_blocks*512,aliases=aliases))
 print(json.dumps(dict(freshIdleLease=True,readOnly=True,freeBytes=shutil.disk_usage(base).free,retire=rows)))
