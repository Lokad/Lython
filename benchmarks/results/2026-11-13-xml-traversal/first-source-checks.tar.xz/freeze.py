from pathlib import Path
import hashlib, json, os, shutil, subprocess, tarfile
r=Path(__file__).parent;prior=r.parent/'xml-select-r329'
baseline=json.loads((prior/'candidate-identity.json').read_text(encoding='utf-8'));sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
sources={p:sha(p)for p in baseline['sources']};new='src/Lokad.Lython/Runtime/LythonRuntime.ElementTree.Traversal.cs';sources[new]=sha(new)
assert sorted(p for p in sources if sources[p]!=baseline['sources'].get(p))==sorted([new,'src/Lokad.Lython/Runtime/LythonRuntime.ElementTreeModule.cs'])
env=dict(os.environ);env['DOTNET_ROOT']='C:/Users/JoannesVermorel/.dotnet11';env['PATH']=env['DOTNET_ROOT']+';C:/Python313;'+env['PATH']
with(r/'freeze-build.log').open('w',encoding='utf-8')as f:done=subprocess.run([env['DOTNET_ROOT']+'/dotnet.exe','build','benchmarks/Lokad.Lython.Benchmarks/Lokad.Lython.Benchmarks.csproj','-c','Release','-f','net11.0','--no-restore','--no-incremental','--disable-build-servers','-m:1'],env=env,stdout=f,stderr=subprocess.STDOUT)
assert done.returncode==0,(r/'freeze-build.log').read_text(encoding='utf-8')[-3000:]
assert sources=={p:sha(p)for p in sources}
shutil.copyfile('src/Lokad.Lython/bin/Release/net11.0/Lokad.Lython.dll',r/'candidate-core.dll')
for role in['candidate','reference']:
 out=r/role;out.mkdir()
 for p in(prior/'candidate').iterdir():
  if p.is_file():shutil.copyfile(p,out/p.name)
 shutil.copyfile(r/'candidate-core.dll'if role=='candidate'else prior/'candidate-core.dll',out/'Lokad.Lython.dll')
identity=dict(headBeforeCommit=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),coreSHA256={role:sha(r/role/'Lokad.Lython.dll')for role in['reference','candidate']},sources=sources,productionFiles=len(sources),auxiliaryFiles={role:{p.name:sha(p)for p in(r/role).iterdir()if p.is_file()and p.name!='Lokad.Lython.dll'}for role in['reference','candidate']},catalogSHA256=sha(r/'catalog.json'),qualified=False)
assert identity['auxiliaryFiles']['candidate']==identity['auxiliaryFiles']['reference']
(r/'candidate-identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8')
with tarfile.open(r/'candidate-sources.tar.xz','w:xz')as t:
 for p in sources:t.add(p,arcname=p)
print('Frozen',identity['coreSHA256'],len(sources),'inputs; fixed worker/adapter copies.',flush=True)
