from pathlib import Path
r=Path(__file__).parent
s=(r.parent/'xml-select-r329/verify-goldens.py').read_text(encoding='utf-8').replace('XmlSelectionTests.cs','XmlTraversalTests.cs').replace('len(rows) == 4','len(rows) == 6').replace('Four exact public-test','Six exact public-test')
(r/'verify-goldens.py').write_text(s,encoding='utf-8',newline='\n')
s=(r.parent/'xml-select-r329/check.py').read_text(encoding='utf-8').replace('FullyQualifiedName~XmlSelectionOwnershipTests','FullyQualifiedName~XmlSelectionOwnershipTests|FullyQualifiedName~XmlTraversalOwnershipTests').replace('FullyQualifiedName~XmlSelectionTests','FullyQualifiedName~XmlSelectionTests|FullyQualifiedName~XmlTraversalTests')
(r/'check.py').write_text(s,encoding='utf-8',newline='\n')
