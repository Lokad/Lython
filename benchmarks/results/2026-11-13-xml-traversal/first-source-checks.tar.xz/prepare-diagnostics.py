from pathlib import Path
import ast
r=Path(__file__).parent;prior=r.parent/'xml-select-r329'
s=(prior/'verify-workers.py').read_text(encoding='utf-8').replace("for role in ['reference', 'candidate']:","for role in ['reference', 'candidate']:\n    case = catalog['cases'][0 if role == 'reference' else 1]")
ast.parse(s);(r/'verify-workers.py').write_text(s,encoding='utf-8',newline='\n')
s=(prior/'measure-allocation.py').read_text(encoding='utf-8').replace("str((r/'catalog.json').resolve())","str((r/('allocation-'+role+'-catalog.json')).resolve())")
s=s.replace('cpuOrElapsedImprovementNotMeasured=True','cpuOrElapsedImprovementNotMeasured=True, sourceAndScriptDifferIntentionally=True, roleCatalogSHA256={role:hashlib.sha256((r/(\'allocation-\'+role+\'-catalog.json\')).read_bytes()).hexdigest()for role in[\'reference\',\'candidate\']}')
ast.parse(s);(r/'measure-allocation.py').write_text(s,encoding='utf-8',newline='\n')
