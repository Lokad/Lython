from pathlib import Path
import ast, json
r=Path(__file__).parent;out=r/'native';out.mkdir()
s=(r/'refined/freeze.py').read_text(encoding='utf-8');ast.parse(s);(out/'freeze.py').write_text(s,encoding='utf-8',newline='\n')
for name in['catalog.json','allocation-reference-catalog.json','allocation-candidate-catalog.json','measure-allocation.py','verify-workers.py']:(out/name).write_bytes((r/name).read_bytes())
(out/'check.py').write_bytes((r/'check-complete.py').read_bytes())
(r/'narrowing-decision.json').write_text(json.dumps(dict(reference='c16b44f0',initial='53f3eb87',narrowed='1d15eb44',allocationNarrowingDidNotRemoveElementCost=True,action='Withdraw ushort and casts; use int depth. Preserve original/narrowed snapshots and allocation observations; no further field-packing campaign.',nextRefinement='Native synchronous pulls shared by sync/async APIs; dynamic tag equality retains its constant-space suspension loop.'),indent=2)+'\n',encoding='utf-8')
