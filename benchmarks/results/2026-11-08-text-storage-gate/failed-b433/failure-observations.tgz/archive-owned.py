from pathlib import Path
import fcntl,hashlib,json,os,subprocess,tarfile,time
root=Path('/home/lokad/lython-bench-checks/text-allocation-b433-20261108')
dotnet='/home/lokad/lython-bench-toolchains/dotnet/11.0.100-rc.3.26522.148/dotnet'
with (root.parent/'comparison-vm.lock').open('a') as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 time.sleep(5)
 for phase in ['before','after']:
  if phase=='after':
   subprocess.run(['python3',str(root/'profile.py')],check=True)
   time.sleep(5)
  subprocess.run([dotnet,str(root/'candidate/Lokad.Lython.Benchmarks.dll'),'--compare','check-machine','--out',str(root/('machine-'+phase+'.json'))],check=True)
  assert json.loads((root/('machine-'+phase+'.json')).read_text())['gate']['quiet']
 records=json.loads((root/'records.json').read_text());assert len(records)==1
 assert all(r['workerClosedAndJoined'] and r['collectorJoined'] and r['collector']['eventsLost']==0 for r in records)
 assert not list((root/'guest-fixtures').iterdir())
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[c]ollector.dll'],capture_output=True).returncode==1
 subprocess.run(['sudo','-n','umount',str(root/'guest-fixtures')],check=True)
 assert os.stat(root/'guest-fixtures').st_dev==os.stat(root).st_dev
 names=['text','records.json','reclaimed-extracts.json','identity.json','catalog.json','profile.py','selected-plan.md','machine-before.json','machine-after.json','setup.json','run.sh','archive-owned.py','started.utc','collector/Program.cs','collector/collector.csproj','collector/collector.dll','collector/collector.deps.json','collector/collector.runtimeconfig.json','current-core.dll','cpython-worker.py','original-failed-setup']
 with tarfile.open(root/'observations.tgz','w:gz') as t:
  for name in names:t.add((root/name).resolve(),arcname=name)
 with tarfile.open(root/'observations.tgz') as t:assert len(json.loads(t.extractfile('records.json').read()))==1
 receipt=dict(complete=True,jobs=1,allWorkersJoined=True,collectorJoined=True,guestFixtureDirectories=[],quietBeforeAndAfter=True,archivedAndVerifiedUnderLease=True,archiveSHA256=hashlib.sha256((root/'observations.tgz').read_bytes()).hexdigest())
 (root/'archive-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt),flush=True)
