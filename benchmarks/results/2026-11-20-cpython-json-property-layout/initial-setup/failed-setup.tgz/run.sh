set -eu
root=/home/lokad/lython-bench-checks/json-layout-delivery-cpython-b1233-20261120
trap 'result=$?; printf "%s\n" "$result" > "$root/exit-code.txt"' EXIT
python3 "$root/collect.py"
