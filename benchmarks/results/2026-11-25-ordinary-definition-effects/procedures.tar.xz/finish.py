from pathlib import Path
import difflib,hashlib,json,shutil,tarfile
p=Path(__file__).resolve().parent
repo=p.parents[3]
q=p/'external'
out=repo/'benchmarks/results/2026-11-25-ordinary-definition-effects'
obj=lambda x:json.loads(x.read_text(encoding='utf-8-sig'))
sha=lambda x:hashlib.sha256(x.read_bytes()).hexdigest()
image=obj(q/'identity.json')
summary=obj(q/'summary.json')
terminal=obj(q/'terminal-status.json')
assert summary['source']==image['sourceRevision'] and summary['timedBatches']==56 and len(summary['rows'])==2
assert not terminal['live'] and not terminal['fixtures'] and terminal['exitCode']=='0'
assert sha(q/'observations.tar.xz')==terminal['receipt']['archiveSHA256']
assert all(terminal['receipt'][key] for key in ('complete','allWorkersJoined','guestFixturesRemoved','quietBeforeAndAfter','archivedAndVerifiedUnderLease'))
assert {f.name:sha(f) for f in (p/'candidate').iterdir()}==image['imageFiles']['candidate']
old,new=obj(q/'representative.json')['cases']
delta=''.join(difflib.unified_diff(old['source'].splitlines(keepends=True),new['source'].splitlines(keepends=True),'complete.py','effects.py'))
(p/'workload.patch').write_text(delta,encoding='utf-8',newline='')
def span(before,after):
 values=[(a/b-1)*100 for a in after for b in before]
 return [min(values),max(values)]
old,new=summary['rows']
deltas={key:span(old[key],new[key]) for key in ('lythonMs','cpythonMs')}
out.mkdir(exist_ok=True)
for name in ('identity.json','terminal-status.json','summary.json','observations.tar.xz'):
 shutil.copyfile(q/name,out/name)
(out/'effects-summary.json').write_text(json.dumps(deltas,indent=2)+'\n',encoding='utf-8',newline='\n')
with tarfile.open(out/'procedures.tar.xz','w:xz') as archive:
 for name in ('prepare.py','finish.py','quiet.py','workload.patch','construction.json','launch-console.log','retrieve.log',
              'external/collect.py','external/summarize.py','external/run.sh','external/representative.json','external/candidate-verify.json',
              'external/jobs.json','external/storage-custody.json','external/upload.json'):
  archive.add(p/name,arcname=name,recursive=False)
print(deltas)
