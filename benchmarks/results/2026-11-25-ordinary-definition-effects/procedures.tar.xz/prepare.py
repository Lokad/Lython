from pathlib import Path
import hashlib,json,shutil,tarfile,subprocess,os
p=Path('.git/agent-notes/review-20261031/ordinary-definition-effects-20261125').resolve()
repo=p.parents[3]
d=p.with_name('formatted-report-cpython-20261125')
template=p.with_name('direct-record-cpython-20261125')
q=p/'external'
q.mkdir(exist_ok=True)
read=lambda path:json.loads(path.read_text(encoding='utf-8-sig'))
sha=lambda path:hashlib.sha256(path.read_bytes()).hexdigest()
def write(path,text): path.write_text(text,encoding='utf-8',newline='\n')
def save(path,value): write(path,json.dumps(value,ensure_ascii=False,indent=2)+'\n')
old=read(d/'external/identity.json')
assert old['sourceRevision'].startswith('857cc8001')
assert subprocess.check_output(['git','diff','--name-only',old['sourceRevision'],'HEAD','--','src','tests'],cwd=repo)==b''
files=old['imageFiles']['candidate']
assert len(files)==32 and {f.name:sha(f) for f in (d/'candidate').iterdir()}==files
image=p/'candidate'
image.mkdir(exist_ok=True)
for name in files: shutil.copyfile(d/'candidate'/name,image/name)
assert {f.name:sha(f) for f in image.iterdir()}==files
shutil.copyfile(p/'representative.json',q/'representative.json')
jobs=[(case['id'],'warm') for case in read(q/'representative.json')['cases']]
assert [name for name,_ in jobs]==['diagnostic.generated-ordinary-definitions','diagnostic.generated-ordinary-default-effects']
save(q/'jobs.json',jobs)
server='ordinary-definition-effects-b1728-20261125'
identity=old|{
 'frozenImage':'/home/lokad/lython-bench-checks/'+server+'/candidate',
 'catalogs':{name:dict(sha256=sha(q/name)) for name in ('representative.json','jobs.json')},
 'purpose':'Distinguish warm default effects from construction of unused functions in this controlled script'}
save(q/'identity.json',identity)
verified=read(p/'verify.json')
assert verified['caseCount']==2 and verified['catalogSha256']==identity['catalogs']['representative.json']['sha256']
assert verified['launched']['library']['sha256']==files['Lokad.Lython.dll']
shutil.copyfile(p/'verify.json',q/'candidate-verify.json')
assert sha(repo/'benchmarks/cpython-worker.py')==identity['cpythonWorkerSHA256']
old_terminal=read(d/'external/terminal-status.json')
assert old_terminal['receipt']['complete'] and sha(d/'external/observations.tar.xz')==old_terminal['receipt']['archiveSHA256']
for name in ('collect.py','summarize.py','run.sh'):
 s=(template/'external'/name).read_text(encoding='utf-8')
 s=s.replace('b1720-fixtures','b1728-fixtures').replace('Retained CSV record admission checkpoint against CPython','Generated definitions and preserved default effects against CPython')
 s=s.replace('len(jobs) == 11','len(jobs) == 2').replace('started<440','started<127')
 s=s.replace('len(raw["jobs"])==11 and receipt["warmJobs"]==11','len(raw["jobs"])==2 and receipt["warmJobs"]==2')
 if name.endswith('.py'): compile(s,name,'exec')
 write(q/name,s)
assert b'\r' not in (q/'run.sh').read_bytes()
s=(template/'quiet.py').read_text(encoding='utf-8')
s=s.replace('lython-b1720-direct-record-cpython','lython-b1728-ordinary-definition-effects').replace('b1720','b1728')
s=s.replace('seconds=390','seconds=100').replace('RuntimeMaxSec=490','RuntimeMaxSec=160')
a=s.index("assert donor['archiveSHA256']=='")
b=s.index('\n',a)
s=s[:a]+f"assert donor['archiveSHA256']=={old_terminal['receipt']['archiveSHA256']!r}"+s[b:]
compile(s,'quiet.py','exec')
write(p/'quiet.py',s)
save(p/'verified-raw-replicas.json',[])
bundle=q/'payload.tar.gz'
with tarfile.open(bundle,'w:gz',compresslevel=3) as tar:
 for name in ('identity.json','jobs.json','representative.json','collect.py','run.sh'):
  tar.add(q/name,arcname=name)
save(q/'upload.json',dict(root=server,reference=read(d/'external/upload.json')['root'],
 payloadSHA256=sha(bundle),payloadBytes=bundle.stat().st_size))
