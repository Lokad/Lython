from pathlib import Path
import gzip
import hashlib
import json
import shutil
import subprocess
import tarfile

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
past=lab.parent/"current-cpython-checkpoint-20261122/comparison"
programs=lab.parent/"combined-default-storage-20261122/comparison"
out=lab/"comparison"
quiet=out/"quiet"
quiet.mkdir(exist_ok=True)
base="/home/lokad/lython-bench-checks"
root=base+"/uniform-eager-annotation-b1398-20261122"
unit="lython-b1398-uniform-eager-annotation-20261122"
core="Lokad.Lython.dll"
def read(path):return json.loads(path.read_text(encoding="utf-8-sig"))
def sha(blob):return hashlib.sha256(blob).hexdigest()
def write(path,value):
    if path.suffix==".py":compile(value,str(path),"exec")
    path.write_text(value,encoding="utf-8",newline="\n")
def save(path,value):write(path,json.dumps(value,indent=2)+"\n")
def committed(relative):return subprocess.check_output(["git","show","origin/master:benchmarks/results/"+relative],cwd=repo)
refs=read(out/"images.json")
files=refs["imageFiles"]
previous=read(past/"quiet/config.json")
assert files["reference"]==previous["identity"]["imageFiles"]["candidate"]
for role,folder in (("reference",lab.parent/"current-cpython-checkpoint-20261122/frozen"),("candidate",out/"frozen-candidate")):
    expected=files[role]
    assert len(expected)==32 and expected=={name:sha((folder/name).read_bytes())for name in expected}
    evidence=read(out/(role+"-verify.json"))
    assert evidence["state"]=="Completed" and evidence["caseCount"]==4 and evidence["catalogSha256"]==refs["catalogSHA256"]
archive_dir="2026-11-22-retained-source-cpython"
receipt=json.loads(committed(archive_dir+"/archive-receipt.json"))
assert all(receipt[k] for k in ("complete","allWorkersJoined","archivedAndVerifiedUnderLease"))
assert sha(committed(archive_dir+"/observations.tgz"))==receipt["archiveSHA256"]
catalog=out/"catalog.json"
assert sha(catalog.read_bytes())==refs["catalogSHA256"]
identity=dict(sourceRevision=refs["reference"]+" versus "+refs["candidate"],reference=refs["reference"],candidate=refs["candidate"],
              purpose="Snapshot repeated eager annotations with one read and one stored value",
              normalAdapterPin="0.4.0",imageFiles=files,sourcePatchSHA256=refs["sourcePatchSHA256"],
              coreSHA256={role+suffix:values[core]for role,values in files.items()for suffix in ("","-control")},
              catalogs={"representative.json":{"sha256":refs["catalogSHA256"]}})
save(quiet/"identity.json",identity)
shutil.copyfile(catalog,quiet/"representative.json")
(quiet/"candidate").mkdir(exist_ok=True)
shutil.copyfile(out/"frozen-candidate"/core,quiet/"candidate"/core)
ids=[row["id"]for row in read(catalog)["cases"]]
eager=next(case for case in ids if case.endswith("nested-factories"))
postponed=next(case for case in ids if case.endswith("factories.postponed"))
observed=next(case for case in ids if "observed-defaults" in case)
helper=next(case for case in ids if "fully-supplied-helper" in case)
jobs=[(eager,"warm"),(eager,"compile-run"),(postponed,"warm"),(observed,"warm"),(helper,"warm")]
assert len(jobs)==5
program_config=read(programs/"quiet/config.json")
for name in ("collect.py","run.sh","archive-owned.py","retrieve.py"):
    data=(programs/"quiet"/name).read_text(encoding="utf-8").replace(program_config["root"],root).replace(program_config["unit"],unit).replace("B1396","B1398")
    if name=="collect.py":
        start,end=data.index("\njob_catalog = "),data.index("\nassert len(jobs)")
        data=data[:start]+"\njob_catalog = "+repr({case:"representative.json"for case in ids})+"\njobs = "+repr(jobs)+data[end:]
    if name=="collect.py":
        data=data.replace("if job_index % 2 != 0: labels.reverse()", "if job_index % 2 == 0: labels.reverse()")
    write(quiet/name,data)
assert b"\r" not in (quiet/"run.sh").read_bytes()
parts=("identity.json","representative.json","collect.py","run.sh","archive-owned.py","candidate/"+core)
payload=quiet/"payload.tgz"
with tarfile.open(payload,"w:gz")as archive:
    for name in parts:archive.add(quiet/name,arcname=name)
unpacked=sum((quiet/name).stat().st_size for name in parts)
threshold=176160768+unpacked+640*1024
older="2026-11-22-compiled-default-admission"
old_core=gzip.decompress(committed(older+"/reference-core.dll.gz"))
old_hash=sha(old_core)
assert old_hash==json.loads(committed(older+"/source.json"))["imageFiles"]["reference"][core]
assert old_hash!=files["reference"][core]
available={}
for path in (repo/"benchmarks/results").glob("*/observations.tgz"):
    if path.stat().st_size<100000:continue
    witness=path.parent/"archive-receipt.json"
    if not witness.exists():continue
    value=read(witness)
    if all(value.get(k)for k in ("complete","allWorkersJoined","archivedAndVerifiedUnderLease")):
        available.setdefault(path.stat().st_size,[]).append((value["archiveSHA256"],path.parent.name))
query=f"""
from pathlib import Path
import fcntl,hashlib,json,os,shutil,stat
b=Path({base!r})
known={available!r}
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
with (b/'comparison-vm.lock').open('a')as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert not any(p.is_mount() for p in b.glob('*/guest-fixtures'))
 core=b/'retained-source-cpython-b1397-20261122/reference/Lokad.Lython.dll'
 assert sha(core)=={old_hash!r}
 m=core.lstat()
 links=[]
 for folder,dirs,names in os.walk(b):
  for name in names:
   p=Path(folder)/name
   c=p.lstat()
   if (c.st_dev,c.st_ino)==(m.st_dev,m.st_ino):
    assert p.resolve()==p and stat.S_ISREG(c.st_mode)and c.st_uid==os.getuid()and p.name==core.name
    links.append(str(p.relative_to(b)))
 assert len(links)==m.st_nlink
 owners={{name.split('/')[0]for name in links}}
 receipts={{owner:json.loads((b/owner/'archive-receipt.json').read_text())['archiveSHA256']for owner in owners}}
 archives={{owner+'/observations.tgz':sha(b/owner/'observations.tgz')for owner in owners if (b/owner/'observations.tgz').exists()}}
 assert all(receipts[name.split('/')[0]]==digest for name,digest in archives.items())
 observations=[]
 for p in b.glob('*/observations.tgz'):
  info=p.lstat()
  if(info.st_size not in known or p.resolve()!=p or info.st_nlink!=1 or not stat.S_ISREG(info.st_mode) or info.st_uid!=os.getuid()
     or p.parent.name in owners or p.parent.name=={Path(previous["root"]).name!r}):continue
  digest=sha(p)
  for expected,canonical in known[info.st_size]:
   if digest==expected:observations.append((str(p.relative_to(b)),info.st_size,digest,canonical))
 print(json.dumps(dict(free=shutil.disk_usage(b).free,bytes=m.st_size,paths=sorted(links),links=m.st_nlink,
                       sha256=sha(core),archives=archives,receipts=receipts,redundant=observations)))
"""
ssh=["C:/Windows/System32/OpenSSH/ssh.exe","-i",str(Path.home()/".ssh/id_lython-bench.pem"),"-o","BatchMode=yes","-o","ConnectTimeout=15","lokad@20.166.121.73"]
proof=json.loads(subprocess.check_output(ssh+["python3 -"],input=query.encode(),timeout=35))
save(out/"inventory.json",proof)
history={
     "compiled-default-admission-b1396-20261122":older,
     "regex-escape-runs-b1394-20261122":"2026-11-22-regex-escape-runs",
     "regex-template-ranges-b1393-20261122":"2026-11-22-regex-template-source-ranges",
     "retained-source-cpython-b1397-20261122":archive_dir,
     "static-assignment-deltas-b1395-20261122":"2026-11-22-compiler-branch-edits",
}
def check_archive(folder,digest):
    info=json.loads(committed(folder+"/archive-receipt.json"))
    assert all(info[k] for k in ("complete","allWorkersJoined","archivedAndVerifiedUnderLease"))
    assert info["archiveSHA256"]==sha(committed(folder+"/observations.tgz"))==digest
for source,digest in proof["receipts"].items():check_archive(history[source],digest)
assert proof["bytes"]==len(old_core)and proof["sha256"]==old_hash
retire=[{key:proof[key]for key in ("paths","bytes","sha256","links","archives")}]
free=proof["free"]+proof["bytes"]
for name,size,digest,folder in sorted(proof["redundant"],key=lambda row:-row[1]):
    if free>threshold+300*1024:break
    check_archive(folder,digest)
    retire.append(dict(paths=[name],bytes=size,sha256=digest,links=1,archives={}))
    free+=size
assert free>threshold,(free,threshold)
config=dict(root=root,unit=unit,identity=identity,source=previous["root"],sourceRole="candidate",sourceFiles=files["reference"],
            sourceCatalogSHA256=previous["identity"]["catalogs"]["representative.json"]["sha256"],donorArchiveSHA256=receipt["archiveSHA256"],
            protocolSource=previous["protocolSource"],protocolSHA256=refs["protocolSHA256"],retireGroups=retire,
            payloadBytes=payload.stat().st_size,payloadSHA256=sha(payload.read_bytes()),unpackedBytes=unpacked)
save(quiet/"config.json",config)
data=(programs/"quiet/remote-launch.py").read_text(encoding="utf-8").replace("lython-b1396-fixtures","lython-b1398-fixtures")
start,end=data.index("\nc=")+1,data.index("\nb=Path(")
write(quiet/"remote-launch.py",data[:start]+"c="+repr(config)+data[end:])
write(out/"launch.py",(programs/"launch.py").read_text(encoding="utf-8").replace("Compiled default admission","Repeated eager annotations"))
write(out/"summarize.py",(programs/"summarize.py").read_text(encoding="utf-8"))
print("Staging verified frozen cores and four complete source goldens on the owned VM.",flush=True)
