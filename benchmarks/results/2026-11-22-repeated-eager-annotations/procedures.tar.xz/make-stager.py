from pathlib import Path

lab=Path(".git/agent-notes/review-20261031/uniform-eager-annotation-20261122")
past=lab.parent/"combined-default-storage-20261122"
source=(past/"stage-comparison.py").read_text(encoding="utf-8")
source=source.replace('past=lab.parent/"static-assignment-deltas-20261122/comparison"',
'''past=lab.parent/"current-cpython-checkpoint-20261122/comparison"
programs=lab.parent/"combined-default-storage-20261122/comparison"''')
source=source.replace('root=base+"/compiled-default-admission-b1396-20261122"','root=base+"/uniform-eager-annotation-b1398-20261122"')
source=source.replace('unit="lython-b1396-compiled-default-admission-20261122"','unit="lython-b1398-uniform-eager-annotation-20261122"')
source=source.replace('previous["identity"]["imageFiles"]["reference"]','previous["identity"]["imageFiles"]["candidate"]')
source=source.replace('lab.parent/"regex-template-source-ranges-20261122/refined/reference"','lab.parent/"current-cpython-checkpoint-20261122/frozen"')
source=source.replace('archive_dir="2026-11-22-compiler-branch-edits"','archive_dir="2026-11-22-retained-source-cpython"')
source=source.replace('older="2026-11-22-compiler-branch-edits"','older="2026-11-22-compiled-default-admission"')
source=source.replace('older+"/candidate-core.dll.gz"','older+"/reference-core.dll.gz"')
source=source.replace('committed(older+"/source.json"))["imageFiles"]["candidate"][core]','committed(older+"/source.json"))["imageFiles"]["reference"][core]')
source=source.replace('purpose="Admit executable positional and keyword default storage with one host resize",',
    'purpose="Snapshot repeated eager annotations with one read and one stored value",')
source=source.replace('jobs=[(eager,"warm"),(postponed,"warm"),(observed,"warm"),(helper,"warm"),(postponed,"compile-run")]',
    'jobs=[(eager,"warm"),(eager,"compile-run"),(postponed,"warm"),(observed,"warm"),(helper,"warm")]')
source=source.replace('for name in ("collect.py","run.sh","archive-owned.py","retrieve.py"):', 'program_config=read(programs/"quiet/config.json")\nfor name in ("collect.py","run.sh","archive-owned.py","retrieve.py"):')
source=source.replace('(past/"quiet"/name).read_text(encoding="utf-8").replace(previous["root"],root).replace(previous["unit"],unit).replace("B1395","B1396")',
    '(programs/"quiet"/name).read_text(encoding="utf-8").replace(program_config["root"],root).replace(program_config["unit"],unit).replace("B1396","B1398")')
source=source.replace('if path.stat().st_size<450000:', 'if path.stat().st_size<100000:')
source=source.replace("core=b/'static-assignment-deltas-b1395-20261122/candidate/Lokad.Lython.dll'",
    "core=b/'retained-source-cpython-b1397-20261122/reference/Lokad.Lython.dll'")
source=source.replace('history={"static-assignment-deltas-b1395-20261122":older}', '''history={
     "compiled-default-admission-b1396-20261122":older,
     "regex-escape-runs-b1394-20261122":"2026-11-22-regex-escape-runs",
     "regex-template-ranges-b1393-20261122":"2026-11-22-regex-template-source-ranges",
     "retained-source-cpython-b1397-20261122":archive_dir,
     "static-assignment-deltas-b1395-20261122":"2026-11-22-compiler-branch-edits",
}''')
source=source.replace('sourceRole="reference"','sourceRole="candidate"')
source=source.replace('(past/"quiet/remote-launch.py").read_text(encoding="utf-8").replace("lython-b1395-fixtures","lython-b1396-fixtures")',
    '(programs/"quiet/remote-launch.py").read_text(encoding="utf-8").replace("lython-b1396-fixtures","lython-b1398-fixtures")')
source=source.replace('(past/"launch.py").read_text(encoding="utf-8").replace("Compiler branch assignment edits","Compiled default admission")',
    '(programs/"launch.py").read_text(encoding="utf-8").replace("Compiled default admission","Repeated eager annotations")')
source=source.replace('(past/"summarize.py").read_text(encoding="utf-8")','(programs/"summarize.py").read_text(encoding="utf-8")')
compile(source,"B1398 stager","exec")
(lab/"stage-comparison.py").write_text(source,encoding="utf-8",newline="\n")
