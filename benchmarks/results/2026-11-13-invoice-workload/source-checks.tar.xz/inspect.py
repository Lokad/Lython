from pathlib import Path
import os, subprocess
r = Path(__file__).parent
sdk = Path('C:/Users/JoannesVermorel/.dotnet11')
env = os.environ.copy(); env['DOTNET_ROOT'] = str(sdk); env['PATH'] = str(sdk) + ';' + env['PATH']
with (r / 'inspect-build.log').open('w', encoding='utf-8') as log:
 done = subprocess.run([str(sdk / 'dotnet.exe'), 'build', str(r / 'inspect/inspect.csproj'), '-c', 'Release', '--disable-build-servers', '-m:1'], env=env, stdout=log, stderr=subprocess.STDOUT)
assert done.returncode == 0, (r / 'inspect-build.log').read_text(encoding='utf-8')
done = subprocess.run([str(sdk / 'dotnet.exe'), str(r / 'inspect/bin/Release/net11.0/Lokad.Lython.WhiteBox.Tests.dll'), str(Path('benchmarks/scripts/csv-invoice.py').resolve())], env=env, capture_output=True, text=True, encoding='utf-8')
assert done.returncode == 0, done.stderr
(r / 'compiled-functions.json').write_text(done.stdout, encoding='utf-8')
print(done.stdout, flush=True)
