using Lokad.Lython.Frontend;
using System.Text;
using System.Text.Json;

var frontend = LythonFrontend.Compile(File.ReadAllText(args[0], Encoding.UTF8));
if (frontend.Diagnostics.Any(d => d.Severity == Lokad.Lython.LythonDiagnosticSeverity.Error))
    throw new InvalidOperationException(string.Join(';', frontend.Diagnostics));
var code = ExecutableScript.Compile(LoweredScript.Lower(frontend.Script!)).EntryPoint;
Console.WriteLine(JsonSerializer.Serialize(code.Functions.Select(function => new
{
    function.Name,
    function.CodeObject.ValueStorageCapacity,
    function.CodeObject.CanInlineInstructions,
    calls = function.CodeObject.CallSites.Select(call => new { call.ArgumentCount, call.IsPositionalOnly }).ToArray(),
    instructions = function.CodeObject.Instructions.Select(i => i.OpCode.ToString()).ToArray(),
}), new JsonSerializerOptions { WriteIndented = true }));
