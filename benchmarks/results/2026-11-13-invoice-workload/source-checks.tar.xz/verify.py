from pathlib import Path
import json, os, subprocess
r = Path(__file__).parent
sdk = Path('C:/Users/JoannesVermorel/.dotnet11')
env = os.environ.copy(); env['DOTNET_ROOT'] = str(sdk); env['PATH'] = str(sdk) + ';C:/Python313;' + env['PATH']
dotnet = str(sdk / 'dotnet.exe')
worker = Path('benchmarks/Lokad.Lython.Benchmarks/bin/Release/net11.0/Lokad.Lython.Benchmarks.dll').resolve()
catalog = (r / 'invoice.json').resolve()
full = (r / 'catalog.json').resolve()
args = [dotnet, str(worker), '--compare', 'list', '--profile', 'representative', '--out', str(full)]
subprocess.run(args, env=env, check=True)
data = json.loads(full.read_text(encoding='utf-8'))
data['cases'] = [case for case in data['cases'] if case['id'].startswith('scripts.csv-invoice.')]
assert len(data['cases']) == 3
catalog.write_text(json.dumps(data, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
args = [dotnet, str(worker), '--compare', 'verify', '--catalog', str(catalog), '--dotnet', dotnet, '--python', 'C:/Python313/python.exe', '--python-worker', str(Path('benchmarks/cpython-worker.py').resolve()), '--out', str((r / 'correctness.json').resolve())]
with (r / 'verify.log').open('w', encoding='utf-8', newline='\n') as log:
 done = subprocess.run(args, env=env, stdout=log, stderr=subprocess.STDOUT)
print((r / 'verify.log').read_text(encoding='utf-8'), flush=True)
assert done.returncode == 0
receipt = json.loads((r / 'correctness.json').read_text(encoding='utf-8'))
assert receipt['state'] == 'Completed'
print('Three invoice scales agree with independent goldens under Lython and isolated CPython; compilation/warm/fresh smoke, no qualified timings.', flush=True)
