from pathlib import Path
import os, subprocess, sys
r = Path(__file__).parent
sdk = Path('C:/Users/JoannesVermorel/.dotnet11')
env = os.environ.copy(); env['DOTNET_ROOT'] = str(sdk); env['PATH'] = str(sdk) + ';C:/Python313;' + env['PATH']
phase, label = sys.argv[1:]
if phase == 'build':
 jobs = [(name, [str(sdk / 'dotnet.exe'), 'build', path, '-c', 'Release', '--disable-build-servers', '-m:1']) for name, path in [('benchmark', 'benchmarks/Lokad.Lython.Benchmarks/Lokad.Lython.Benchmarks.csproj'), ('public', 'tests/Lokad.Lython.PublicApi.Tests/Lokad.Lython.PublicApi.Tests.csproj')]]
else:
 jobs = [(framework, [str(sdk / 'dotnet.exe'), 'test', 'tests/Lokad.Lython.PublicApi.Tests/Lokad.Lython.PublicApi.Tests.csproj', '-c', 'Release', '-f', framework, '--no-build', '--disable-build-servers', '--filter', 'Category!=Stress&(FullyQualifiedName~NumericReportTests|FullyQualifiedName~ComparisonFileWorkerTests)']) for framework in ['net11.0', 'net10.0']]
for name, args in jobs:
 p = r / f'{phase}-{name}-{label}.log'; assert not p.exists()
 with p.open('w', encoding='utf-8', newline='\n') as log: done = subprocess.run(args, env=env, stdout=log, stderr=subprocess.STDOUT)
 text = p.read_text(encoding='utf-8'); print(p.name, 'exit', done.returncode, text[-12000:], flush=True)
 if done.returncode or 'No test matches' in text: sys.exit(done.returncode or 1)
