from hashlib import sha256
from pathlib import Path
from shutil import copy2
import json,tarfile

lab=Path(__file__).resolve().parent
prior=lab.parent/'matched-shipment-control-b1944-20261128'
old=lab.parent/'current-shipment-checkpoint-b1937-20261128/comparison/quiet'
new_lab=lab.parent/'sum-source-b1949-20261128'
new=new_lab/'comparison/quiet'
quiet=lab/'comparison/quiet'
read=lambda p:json.loads(p.read_bytes())
digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,s):
    p.write_text(s,encoding='utf-8',newline='\n')
    assert b'\r' not in p.read_bytes()
def js(p,v):write(p,json.dumps(v,indent=2)+'\n')
quiet.mkdir(parents=True)
identity=read(new/'identity.json')
images={}
for role,folder,image_path,proof in (
    ('reference',old,old/'local-image',prior/'comparison/quiet/reference-local-verify.json'),
    ('candidate',new,new_lab/'comparison/local/candidate',new_lab/'comparison/local/candidate-verify.json')):
    record=read(folder/'identity.json')
    image=record['imageFiles']['candidate']
    state=read(folder/'terminal-status.json')
    assert not state['live'] and not state['fixtures'] and state['exitCode']=='0'
    receipt=state['receipt']
    assert receipt['complete'] and receipt['allWorkersJoined'] and receipt['quietBeforeAndAfter']
    assert digest(folder/'observations.tar.xz')==receipt['archiveSHA256']
    assert len(image)==32 and {p.name:digest(p) for p in image_path.iterdir()}==image
    goldens=read(proof)
    assert goldens['state']=='Completed' and goldens['caseCount']==4
    assert goldens['catalogSha256']==identity['catalogs']['representative.json']['sha256']
    assert goldens['launched']['library']['sha256']==image['Lokad.Lython.dll']
    assert goldens['launched']['adapter']['sha256']==image['Lokad.Lython.Benchmarks.dll']
    assert goldens['launched']['python']['sha256']==identity['expectedCPythonSHA256']
    copy2(proof,quiet/f'{role}-local-verify.json')
    images[role]=dict(root=read(folder/'upload.json')['root'],archive=receipt['archiveSHA256'],files=image,revision=record['sourceRevision'])
assert images['reference']['revision'].startswith('e036d6597') and images['candidate']['revision'].startswith('df568572c')
for name in ('representative.json','cpython-worker.py','run.sh'):copy2(new/name,quiet/name)
assert digest(quiet/'representative.json')==identity['catalogs']['representative.json']['sha256']
assert digest(quiet/'cpython-worker.py')==identity['cpythonWorkerSHA256']
job=['diagnostic.shipment-file-fed-map','warm-async']
assert job in read(new/'jobs.json') and job in read(prior/'comparison/quiet/jobs.json')
js(quiet/'jobs.json',[job])
identity.pop('donorArchiveSHA256')
identity.update(referenceRevision=images['reference']['revision'],donorArchives={role:d['archive'] for role,d in images.items()},
    purpose='Compare current and original file-fed regression endpoints on the quiet VM.',
    frozenImage='/home/lokad/lython-bench-checks/script-file-fed-baseline-b1950-20261128/candidate',
    imageFiles={role:d['files'] for role,d in images.items()},
    coreSHA256={label:d['files']['Lokad.Lython.dll'] for role,d in images.items() for label in (role,role+'-control')})
identity['catalogs']['jobs.json']['sha256']=digest(quiet/'jobs.json')
js(quiet/'identity.json',identity)
collect=(new/'collect.py').read_text(encoding='utf-8')
assert collect.count('len(jobs) == 5')==1
write(quiet/'collect.py',collect.replace('len(jobs) == 5','len(jobs) == 1').replace('lython-b1949-sum-source-fixtures','lython-b1950-file-baseline-fixtures'))
paths={name:quiet/name for name in ('identity.json','jobs.json','representative.json','collect.py','run.sh','cpython-worker.py')}
payload=quiet/'stage.tar.gz'
with tarfile.open(payload,'w:gz') as bundle:
    for name,path in paths.items():bundle.add(path,arcname=name)
with tarfile.open(payload) as bundle:
    assert all(sha256(bundle.extractfile(name).read()).hexdigest()==digest(path) for name,path in paths.items())
js(quiet/'upload.json',dict(root='script-file-fed-baseline-b1950-20261128',donors=images,payloadSHA256=digest(payload),
    files={name:dict(length=p.stat().st_size,sha256=digest(p)) for name,p in paths.items()},
    expandedBytes=sum(p.stat().st_size for p in paths.values()),minimumAfterStageBytes=16*1024*1024,caseCount=4))
launch=(prior/'quiet-vm.py').read_text(encoding='utf-8')
write(lab/'quiet-vm.py',launch.replace('lython-b1944-matched-control','lython-b1950-file-baseline'))
print('Original and current frozen endpoints prepared for one lane.')
