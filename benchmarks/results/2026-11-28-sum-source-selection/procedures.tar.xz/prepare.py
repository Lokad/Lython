from hashlib import sha256
from pathlib import Path
from shutil import copy2,copytree
from subprocess import check_output
import json,sys,tarfile

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
prior=lab.parent/'module-surface-storage-b1947-20261128/comparison'
donor=lab.parent/'module-surface-confirmation-b1948-20261128/comparison/quiet'
catalog=lab.parent/'current-shipment-checkpoint-b1943-20261128/comparison/quiet'
procedures=lab.parent/'matched-shipment-control-b1944-20261128'
pair=lab/'comparison/local'
quiet=lab/'comparison/quiet'
build=lab/'ubuntu-artifacts/bin/Lokad.Lython/release_net11.0/Lokad.Lython.dll'
read=lambda p:json.loads(p.read_bytes())
digest=lambda p:sha256(p.read_bytes()).hexdigest()
files=lambda path:{p.name:digest(p) for p in path.iterdir()}
git=lambda *args:check_output(['git',*args],cwd=repo)
def write(p,s):
    p.write_text(s,encoding='utf-8',newline='\n')
    assert b'\r' not in p.read_bytes()
def js(p,data):write(p,json.dumps(data,indent=2)+'\n')

old=read(prior/'identity.json')
head=git('rev-parse','HEAD').decode().strip()
assert head.startswith('df568572c')
assert sha256(git('diff','--binary',old['sourceRevision'],head,'--','src/Lokad.Lython')).hexdigest()==old['sourcePatchSHA256']
assert not git('diff','--binary',head,'--','tests','Directory.Packages.props','src/Lokad.Lython.Utf8Regex')
original=old['imageFiles']['candidate']
assert len(original)==32 and files(prior/'candidate')==original
if sys.argv[1]=='freeze':
    pair.mkdir(parents=True)
    for role in ('reference','candidate'):copytree(prior/'candidate',pair/role)
    copy2(build,pair/'candidate/Lokad.Lython.dll')
    assert not (pair/'candidate/Lokad.Lython.dll').samefile(build)
    patch=git('diff','--binary',head,'--','src/Lokad.Lython')
    assert patch.count(b'diff --git ')==1
    (lab/'candidate.patch').write_bytes(patch)
    for name in ('representative.json','cpython-worker.py'):copy2(catalog/name,pair/name)
    verify=(lab.parent/'current-shipment-checkpoint-b1943-20261128/verify.sh').read_text(encoding='utf-8')
    verify=verify.replace('current-shipment-checkpoint-b1943-20261128/comparison/quiet',lab.name+'/comparison/local')
    verify=verify.replace('"$root/local-image/', '"$root/$1/').replace('candidate-local-verify.json','$1-verify.json')
    write(lab/'verify.sh',verify)
    allocation=(lab.parent/'private-generator-sum-b1940-20261128/measure-allocation.py').read_text(encoding='utf-8')
    write(lab/'measure-allocation.py',allocation.replace("comparison=root/'comparison'","comparison=root/'comparison/local'"))
    images={role:files(pair/role) for role in ('reference','candidate')}
    assert {name for name,sha in original.items() if images['candidate'][name]!=sha}=={'Lokad.Lython.dll'}
    assert images['reference']==original
    known=read(catalog/'identity.json')
    assert digest(pair/'representative.json')==known['catalogs']['representative.json']['sha256']
    assert digest(pair/'cpython-worker.py')==known['cpythonWorkerSHA256']
    js(pair/'identity.json',dict(sourceRevision=head,referenceRevision=head,sourcePatchSHA256=sha256(patch).hexdigest(),
        imageFiles=images,coreSHA256={role+suffix:hashes['Lokad.Lython.dll'] for role,hashes in images.items() for suffix in ('','-control')},
        expectedCPythonSHA256=known['expectedCPythonSHA256'],cpythonWorkerSHA256=known['cpythonWorkerSHA256'],
        catalogs={'representative.json':{'sha256':digest(pair/'representative.json')}}))
    print('Frozen exact reference and candidate, 32 files each.')
    sys.exit(0)

assert sys.argv[1]=='stage'
identity=read(pair/'identity.json')
assert digest(lab/'candidate.patch')==identity['sourcePatchSHA256']
assert (lab/'candidate.patch').read_bytes()==git('diff','--binary',head,'--','src/Lokad.Lython')
term=read(donor/'terminal-status.json')
assert term['exitCode']=='0' and not term['live'] and not term['fixtures']
receipt=term['receipt']
assert receipt['complete'] and receipt['allWorkersJoined'] and receipt['quietBeforeAndAfter']
assert digest(donor/'observations.tar.xz')==receipt['archiveSHA256']
assert original==read(donor/'identity.json')['imageFiles']['candidate']
for role,image in identity['imageFiles'].items():
    assert len(image)==32 and files(pair/role)==image
    proof=read(pair/f'{role}-verify.json')
    assert proof['state']=='Completed' and proof['caseCount']==4
    assert proof['catalogSha256']==identity['catalogs']['representative.json']['sha256']
    assert proof['launched']['library']['sha256']==image['Lokad.Lython.dll']
    assert proof['launched']['adapter']['sha256']==image['Lokad.Lython.Benchmarks.dll']
    assert proof['launched']['python']['sha256']==identity['expectedCPythonSHA256']
quiet.mkdir(parents=True)
for name in ('representative.json','cpython-worker.py'):copy2(pair/name,quiet/name)
copy2(donor/'run.sh',quiet/'run.sh')
file_map='diagnostic.shipment-file-fed-map'
ordinary='diagnostic.shipment-row-generator-reduction'
iterable='diagnostic.shipment-starmap-iterable-rows'
jobs=[(file_map,'warm'),(file_map,'warm-async'),(ordinary,'warm'),(ordinary,'warm-async'),(iterable,'warm-async')]
js(quiet/'jobs.json',jobs)
identity.update(purpose='Compare selecting sum generator input once and using one async pull await.',
    frozenImage='/home/lokad/lython-bench-checks/script-sum-source-b1949-20261128/candidate',donorArchiveSHA256=receipt['archiveSHA256'])
identity['catalogs']['jobs.json']={'sha256':digest(quiet/'jobs.json')}
js(quiet/'identity.json',identity)
collect=(procedures/'comparison/quiet/collect.py').read_text(encoding='utf-8')
assert collect.count('len(jobs) == 2')==1
write(quiet/'collect.py',collect.replace('len(jobs) == 2','len(jobs) == 5').replace('lython-b1944-matched-fixtures','lython-b1949-sum-source-fixtures'))
paths={name:quiet/name for name in ('identity.json','jobs.json','representative.json','collect.py','run.sh','cpython-worker.py')}
paths['candidate/Lokad.Lython.dll']=pair/'candidate/Lokad.Lython.dll'
payload=quiet/'stage.tar.gz'
with tarfile.open(payload,'w:gz') as bundle:
    for name,path in paths.items():bundle.add(path,arcname=name)
with tarfile.open(payload) as bundle:
    assert all(sha256(bundle.extractfile(name).read()).hexdigest()==digest(path) for name,path in paths.items())
js(quiet/'upload.json',dict(root='script-sum-source-b1949-20261128',donor=read(donor/'upload.json')['root'],donorFiles=original,
    donorArchive=receipt['archiveSHA256'],payloadSHA256=digest(payload),files={name:dict(length=p.stat().st_size,sha256=digest(p)) for name,p in paths.items()},
    expandedBytes=sum(p.stat().st_size for p in paths.values()),minimumAfterStageBytes=16*1024*1024,caseCount=4))
launch=(lab.parent/'module-surface-confirmation-b1948-20261128/quiet-vm.py').read_text(encoding='utf-8')
write(lab/'quiet-vm.py',launch.replace('lython-b1948-module-surfaces','lython-b1949-sum-source'))
print('Five lanes staged locally for an exact quiet comparison.')
