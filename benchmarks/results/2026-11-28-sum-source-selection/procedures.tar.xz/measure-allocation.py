from hashlib import sha256
from pathlib import Path
from shutil import copytree, copy2
from statistics import median
import json, os, subprocess

root=Path(__file__).resolve().parent
results=root/'allocation'
results.mkdir()
comparison=root/'comparison/local'
existing=root.parent/'regex-group-costs-b1931-20261128/allocation-corrected'
def read(p): return json.loads(p.read_bytes())
def write(p,v): p.write_text(json.dumps(v,indent=2)+'\n',encoding='utf-8',newline='\n')
def digest(p): return sha256(p.read_bytes()).hexdigest()
catalog=read(comparison/'representative.json')
assert len(catalog['cases'])==4
pair_identity=read(comparison/'identity.json')
witnesses=read(existing/'identity.json')['witness']
manifest={}
for role,image in pair_identity['imageFiles'].items():
    folder=results/role
    source=comparison/role
    manifest[role]={'source':pair_identity['sourceRevision'],'image':image}
    assert len(image)==32 and {p.name:digest(p) for p in source.iterdir()}==image
    copytree(source,folder)
    for name in witnesses:
        copy2(existing/'candidate'/name,folder/name)
    assert {p.name:digest(p) for p in folder.iterdir()}==image|witnesses
assert {k for k,sha in manifest['reference']['image'].items() if sha!=manifest['candidate']['image'][k]}=={'Lokad.Lython.dll'}
sdk=Path.home()/'.dotnet11'
env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk))
rows=[]
for mode in ('sync','async'):
    for case in catalog['cases']: case['runAsync']=mode=='async'
    selection=results/f'{mode}-catalog.json'
    write(selection,catalog)
    observations=[]
    for role in ('reference','candidate'):
        folder=results/role
        report=results/f'{role}-{mode}.json'
        assert {p.name:digest(p) for p in folder.iterdir()}==manifest[role]['image']|witnesses
        subprocess.run([sdk/'dotnet.exe',folder/'ValidatedAllocation.dll',folder,selection,report],env=env,check=True,timeout=55)
        observations.append(read(report)['rows'])
    for before,after in zip(*observations,strict=True):
        assert before['id']==after['id']
        assert before['sharedBudgetBaselineRestored'] and after['sharedBudgetBaselineRestored']
        row=dict(case=before['id'],mode=mode,
             clr=[median(r['allocatedBytesPerInvocation']) for r in (before,after)],
             admittedPeak=[r['peakExecutionMemoryBytes'] for r in (before,after)],
             compiled=[r['compiledReservedBytes'] for r in (before,after)])
        rows.append(row)
        print(row,flush=True)
write(results/'summary.json',rows)
write(results/'identity.json',dict(images=manifest,witness=witnesses))
