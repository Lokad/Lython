from collections import Counter
from pathlib import Path
import json

lab=Path(__file__).resolve().parent
profiles=lab.parent/'current-shipment-checkpoint-b1943-20261128/attribution/profile'
proof=json.loads((profiles/'managed-attribution.json').read_bytes())
rows=[]
for attribution in proof:
    role=attribution['role']
    capture=json.loads((profiles/role/'run.speedscope.json').read_bytes())
    frames=[record['name'].split('(',1)[0].split('!',1)[-1] for record in capture['shared']['frames']]
    waits=('WaitSubsystem+ThreadWaitInfo.Wait','LowLevelThreadBlocker.TimedWait','PollGCWorker','SynchronousWorkItem.Wait')
    parents=Counter(); runtime=0
    for stream in capture['profiles']:
        stack=[]; time=stream['startValue']
        for event in stream['events']:
            elapsed=event['at']-time
            active=[name for name in stack if name.startswith(('Lokad.Lython.Runtime.','Lokad.Lython.Frontend.','Lokad.Lython.LythonEngine','Lokad.Lython.Utf8Regex.','Lokad.Utf8Regex.'))]
            if elapsed>0 and active and stack[-1]!='UNMANAGED_CODE_TIME' and not any(mark in frame for frame in stack for mark in waits):
                runtime+=elapsed
                if active[-1]=='Lokad.Lython.Runtime.MemoryGovernor.Reserve':
                    parents[active[-2] if len(active)>1 else '(no caller)']+=elapsed
            if event['type']=='O':stack.append(frames[event['frame']])
            else:assert stack.pop()==frames[event['frame']]
            time=event['at']
        assert not stack
    assert abs(runtime-attribution['runtimeThreadMilliseconds'])<0.001
    expected=dict(attribution['nearestLythonMethods'])['Lokad.Lython.Runtime.MemoryGovernor.Reserve']
    assert abs(expected-sum(parents.values()))<0.001
    print(role,round(100*expected/runtime,2),[(name,round(100*duration/runtime,2)) for name,duration in parents.most_common(8)])
    rows.append(dict(role=role,runtimeMilliseconds=runtime,reserveMilliseconds=expected,callers=parents.most_common()))
(lab/'reserve-callers.json').write_text(json.dumps(dict(image='bf10eeaea',rows=rows),indent=2)+'\n',encoding='utf-8',newline='\n')
