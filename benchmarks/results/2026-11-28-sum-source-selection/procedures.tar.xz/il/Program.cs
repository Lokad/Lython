using System.Reflection;
using System.Reflection.Emit;
using System.Security.Cryptography;
using System.Text.Json;

var path = Path.GetFullPath(args[0]);
var assembly = Assembly.LoadFrom(path);
var runtime = assembly.GetType("Lokad.Lython.Runtime.LythonRuntime", throwOnError: true)!;
const BindingFlags privateStatic = BindingFlags.NonPublic | BindingFlags.Static;
const BindingFlags privateInstance = BindingFlags.NonPublic | BindingFlags.Instance;
var sum = runtime.GetMethod("Sum", privateStatic)!;
var asyncState = runtime.GetNestedTypes(BindingFlags.NonPublic).Single(t => t.Name.StartsWith("<SumAsync>d__", StringComparison.Ordinal));
var moveNext = asyncState.GetMethod("MoveNext", privateInstance)!;
var codes = typeof(OpCodes).GetFields(BindingFlags.Public | BindingFlags.Static)
    .Select(field => (OpCode)field.GetValue(null)!).ToDictionary(code => unchecked((ushort)code.Value));
var pulls = new List<string>();
var code = moveNext.GetMethodBody()!.GetILAsByteArray()!;
for (int i = 0; i < code.Length;)
{
    ushort prefix = code[i++];
    if (prefix == 0xfe) prefix = (ushort)(0xfe00 | code[i++]);
    var instruction = codes[prefix];
    if (instruction.OperandType == OperandType.InlineMethod)
    {
        var target = moveNext.Module.ResolveMethod(BitConverter.ToInt32(code, i)) as MethodInfo;
        if (target is { Name: "AwaitUnsafeOnCompleted" } && target.GetGenericArguments().First().ToString().Contains("PyIterationResult", StringComparison.Ordinal))
            pulls.Add(target.GetGenericArguments().First().ToString());
    }
    i += instruction.OperandType switch
    {
        OperandType.InlineNone => 0,
        OperandType.ShortInlineBrTarget or OperandType.ShortInlineI or OperandType.ShortInlineVar => 1,
        OperandType.InlineVar => 2,
        OperandType.ShortInlineR or OperandType.InlineBrTarget or OperandType.InlineField or OperandType.InlineI or OperandType.InlineMethod or
            OperandType.InlineSig or OperandType.InlineString or OperandType.InlineTok or OperandType.InlineType => 4,
        OperandType.InlineI8 or OperandType.InlineR => 8,
        OperandType.InlineSwitch => checked(4 + BitConverter.ToInt32(code, i) * 4),
        _ => throw new InvalidDataException(instruction.OperandType.ToString()),
    };
}
Console.WriteLine(JsonSerializer.Serialize(new
{
    core = Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(path))).ToLowerInvariant(),
    sumIL = sum.GetMethodBody()!.GetILAsByteArray()!.Length,
    asyncMoveNextIL = code.Length,
    asyncFields = asyncState.GetFields(privateInstance | BindingFlags.Public).Length,
    pullAwaitSites = pulls.Count,
}, new JsonSerializerOptions { WriteIndented = true }));
