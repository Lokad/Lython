from hashlib import sha256
from pathlib import Path
from shutil import copy2
from statistics import median, quantiles
from subprocess import check_output
import re
import json
import tarfile

lab = Path(__file__).resolve().parent
quiet = lab / 'comparison/quiet'
repo = lab.parents[3]
out = repo / 'benchmarks/results/2026-11-28-sum-source-selection'
read = lambda p: json.loads(p.read_bytes())
digest = lambda p: sha256(p.read_bytes()).hexdigest()
identity = read(quiet / 'identity.json')
local = lab / 'comparison/local'
assert digest(lab/'candidate.patch')==identity['sourcePatchSHA256']
assert check_output(['git','diff','--binary',identity['sourceRevision'],'--','src/Lokad.Lython'],cwd=repo)==(lab/'candidate.patch').read_bytes()
assert not check_output(['git','diff','--binary',identity['sourceRevision'],'--','tests'],cwd=repo)
for role,hashes in identity['imageFiles'].items():
    assert len(hashes)==32 and {p.name:digest(p) for p in (local/role).iterdir()}==hashes
    proof=read(local/f'{role}-verify.json')
    assert proof['state']=='Completed' and proof['caseCount']==4 and proof['catalogSha256']==identity['catalogs']['representative.json']['sha256']
    assert proof['launched']['library']['sha256']==hashes['Lokad.Lython.dll']
logs=sorted(lab.glob('*-Lokad.Lython.*Tests-net*.log'))
assert len(logs)==6
for log in logs:
    count=738 if 'PublicApi' in log.name else 193
    assert re.search(rf'Failed: +0, Passed: +{count}, Skipped: +0',log.read_text(encoding='utf-8-sig')),log
allocation=read(lab/'allocation/summary.json')
assert len(allocation)==8 and all(row['compiled'][0]==row['compiled'][1] and row['admittedPeak'][0]==row['admittedPeak'][1] for row in allocation)
il={role:read(lab/f'il/{role}.json') for role in ('reference','candidate')}
assert all(row['core']==identity['imageFiles'][role]['Lokad.Lython.dll'] for role,row in il.items())
assert il['reference']['pullAwaitSites']==3 and il['candidate']['pullAwaitSites']==1
terminal = read(quiet / 'terminal-status.json')
receipt = terminal['receipt']
archive = quiet / 'observations.tar.xz'
assert not terminal['live'] and not terminal['fixtures'] and terminal['exitCode'] == '0'
assert all(receipt[k] for k in ('complete','allWorkersJoined','guestFixturesRemoved','quietBeforeAndAfter','archivedAndVerifiedUnderLease'))
assert receipt['warmJobs'] == 5 and digest(archive) == receipt['archiveSHA256']
assert read(quiet/'stage-custody.json')['reused'] == {'donor':63,'paired':0}
for role,image in identity['imageFiles'].items():
    verified = read(quiet / f'{role}-remote-verify.json')
    assert verified['state'] == 'Completed' and verified['caseCount'] == 4
    assert verified['catalogSha256'] == identity['catalogs']['representative.json']['sha256']
    assert verified['launched']['library']['sha256'] == image['Lokad.Lython.dll']
    assert verified['launched']['adapter']['sha256'] == image['Lokad.Lython.Benchmarks.dll']
    assert verified['launched']['python']['sha256'] == identity['expectedCPythonSHA256']
with tarfile.open(archive) as a:
    assert json.load(a.extractfile('identity.json')) == identity
    for name,row in identity['catalogs'].items():
        assert sha256(a.extractfile(name).read()).hexdigest() == row['sha256']
    assert all(json.load(a.extractfile('confirmation/machine-'+phase+'.json'))['gate']['quiet'] for phase in ('before','after'))
    raw = json.load(a.extractfile('confirmation/confirmation.json'))
    jobs = json.load(a.extractfile('jobs.json'))
    assert raw['complete'] and jobs == read(quiet/'jobs.json')
cases = {case['id']:case for case in read(quiet/'representative.json')['cases']}
rows = []
for job,(case_id,lane) in zip(raw['jobs'],jobs,strict=True):
    assert job['case'] == case_id and job['lanes'] == [lane] and job['workersJoinedAndFixturesRemoved']
    case=cases[case_id]; elapsed={}; cpu={}; iqrs={}
    for label,worker in job['identities'].items():
        role=label.removesuffix('-control')
        libraries={Path(v['path']).name:v['sha256'] for v in worker['libraries']}
        assert libraries['Lokad.Lython.dll'] == identity['coreSHA256'][label]
        assert libraries['Lokad.Lython.Benchmarks.dll'] == identity['imageFiles'][role]['Lokad.Lython.Benchmarks.dll']
        assert worker['catalogSha256'] == identity['catalogs']['representative.json']['sha256']
        times=[]; active=[]
        samples = [s for s in job['samples'] if s['engine'] == label]
        assert len(samples) == 7 and {s['round'] for s in samples} == set(range(7))
        for sample in samples:
            r=sample['response']; count=r['completedInvocations']
            assert r['status'] == 'Completed' and count > 0 and sample['lane'] == lane
            assert all(r[k] == case[k] for k in ('sourceSha256','fixtureSha256','expectedOutputSha256'))
            assert r.get('actualOutputSha256') == (None if lane == 'compile' else case['expectedOutputSha256'])
            assert r.get('actualFilesSha256') == (None if lane == 'compile' else case.get('expectedFilesSha256'))
            times.append(1000*r['elapsedTicks']/r['clockFrequency']/count)
            active.append(1000*sample['externalProcessCpuTicks']/sample['externalCpuFrequency']/count)
        elapsed[label]=median(times); cpu[label]=median(active)
        quartiles=quantiles(times,n=4,method='inclusive')
        iqrs[label]=100*(quartiles[2]-quartiles[0])/elapsed[label]
    def span(values,role): return sorted([values[role],values[role+'-control']])
    def change(values): return [100*(a/b-1) for a,b in [(span(values,'candidate')[0],span(values,'reference')[1]),(span(values,'candidate')[1],span(values,'reference')[0])]]
    def spread(values,role):
        low,high=span(values,role)
        return 100*(high/low-1)
    row=dict(case=case_id,lane=lane,elapsedMilliseconds=elapsed,cpuMilliseconds=cpu,elapsedChangePercent=change(elapsed),
        cpuChangePercent=change(cpu),referenceElapsedSpreadPercent=spread(elapsed,'reference'),candidateElapsedSpreadPercent=spread(elapsed,'candidate'),
        referenceCpuSpreadPercent=spread(cpu,'reference'),candidateCpuSpreadPercent=spread(cpu,'candidate'),maxElapsedIqrPercent=max(iqrs.values()))
    rows.append(row)
    print(case_id,'elapsed',[round(n,2) for n in row['elapsedChangePercent']], 'CPU',[round(n,2) for n in row['cpuChangePercent']],
          'CPU spreads',round(row['referenceCpuSpreadPercent'],2),round(row['candidateCpuSpreadPercent'],2))
assert sum(len(job['samples']) for job in raw['jobs']) == 140
summary=dict(reference=identity['referenceRevision'],candidate=identity['sourceRevision'],collectionSeconds=raw['elapsedSeconds'],
    verifiedTimedBatches=140,quietGates=True,rows=rows)
out.mkdir(exist_ok=True)
copy2(lab/'allocation/summary.json',out/'allocation.json')
copy2(lab/'reserve-callers.json',out/'reserve-callers.json')
assert digest(lab/'reserve-callers.json')==digest(out/'reserve-callers.json')
(out/'il.json').write_text(json.dumps(il,indent=2)+'\n',encoding='utf-8',newline='\n')
(out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8',newline='\n')
for name in ('identity.json','observations.tar.xz','terminal-status.json','stage-custody.json'):
    copy2(quiet/name,out/name)
    assert digest(out/name)==digest(quiet/name)
files={name:quiet/name for name in ('reference-remote-verify.json','candidate-remote-verify.json',
          'launch.log','archive-receipt.json','upload.json')}
files.update({name:lab/name for name in ('prepare.py','quiet-vm.py','summarize.py','candidate.patch','reserve-attribution.py','verify.sh','measure-allocation.py','test-windows.ps1','test-ubuntu.sh','ubuntu-core-build.log')})
files.update({log.name:log for log in logs})
files.update({f'local/{role}-verify.json':local/f'{role}-verify.json' for role in ('reference','candidate')})
files.update({f'il/{name}':lab/'il'/name for name in ('Program.cs','InspectSum.csproj','build.log','reference.json','candidate.json')})
files.update({f'allocation/{p.name}':p for p in (lab/'allocation').glob('*.json')})
with tarfile.open(out/'procedures.tar.xz','w:xz') as bundle:
    for name,path in files.items(): bundle.add(path,arcname=name)
with tarfile.open(out/'procedures.tar.xz') as bundle:
    assert all(sha256(bundle.extractfile(name).read()).hexdigest()==digest(path) for name,path in files.items())
print('Quiet sum source comparison and archive verified.')
