from pathlib import Path
import json
p=Path('benchmarks/results/2026-11-17-completed-instruction-runner/attribution/attribution.json')
x=json.loads(p.read_text(encoding='utf-8'))
def walk(v, path=''):
    if isinstance(v,dict):
        for k,value in v.items():
            print(path+'/'+k, type(value).__name__, len(value) if isinstance(value,(dict,list)) else str(value)[:200])
            if isinstance(value,dict):walk(value,path+'/'+k)
    elif isinstance(v,list) and v: print(path,'first',str(v[0])[:600])
for row in x['rows']:
    walk(row)
