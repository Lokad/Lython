from pathlib import Path
import json,subprocess
r=Path(__file__).resolve().parent
code="""from pathlib import Path
import fcntl,json,os,shutil,subprocess
b=Path('/home/lokad/lython-bench-checks')
with(b/'comparison-vm.lock').open('a')as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record|[p]ython3.13.*cpython-worker.py'],capture_output=True).returncode==1
 print(json.dumps(dict(freeBytes=shutil.disk_usage(b).free,raw=[dict(path=str(p.relative_to(b)),bytes=p.stat().st_size)for p in b.glob('*/confirmation/confirmation.json')if p.stat().st_size>200000],archives=[dict(path=str(p.relative_to(b)),bytes=p.stat().st_size)for p in b.glob('*/observations.tgz')if p.stat().st_size>200000]),indent=2))
"""
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
p=subprocess.run(ssh+['python3 -'],input=code,text=True,encoding='utf-8',capture_output=True,timeout=30);assert p.returncode==0,p.stdout+p.stderr
(r/'space-probe.json').write_text(p.stdout,encoding='utf-8');print(p.stdout)
