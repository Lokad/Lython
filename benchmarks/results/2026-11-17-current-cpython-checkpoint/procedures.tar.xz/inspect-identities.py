from pathlib import Path
import json
r=Path(__file__).resolve().parent
x=json.loads((r/'quiet/retrieved/confirmation/confirmation.json').read_text(encoding='utf-8'))
for label,v in x['jobs'][0]['identities'].items():
    print(label,{k:value for k,value in v.items()if not isinstance(value,(list,dict))and k not in ['timingBoundary']})
