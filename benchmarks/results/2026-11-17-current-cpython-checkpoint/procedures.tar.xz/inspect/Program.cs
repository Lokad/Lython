using Lokad.Lython;
using Lokad.Lython.Frontend;

var sources = new[] {
    "N = 16384\ndef add(value):\n    return value + 3\ntotal = 0\nfor i in range(N):\n    total += add(i)\nprint(total)\n",
    "def aggregate(values, convert):\n    total=0\n    for value in values:\n        total += convert(value)\n    return total\n"
};
foreach (var source in sources)
{
    var frontend = LythonFrontend.Compile(source);
    if (frontend.Diagnostics.Any(d => d.Severity == LythonDiagnosticSeverity.Error)) throw new Exception(string.Join("\n", frontend.Diagnostics));
    Dump(ExecutableScript.Compile(LoweredScript.Lower(frontend.Script!)).EntryPoint);
}
static void Dump(ExecutableCodeObject code)
{
    Console.WriteLine($"CODE {code.Name} function={code.IsFunctionScope} mirror={code.RequiresLocalVariableMirroring} locals={string.Join(',', code.LocalNames)} firstTemp={code.FirstTemporarySlot}");
    for (int n = 0; n < code.Instructions.Length; n++)
    {
        var i = code.Instructions[n];
        var local = i.OpCode is ExecutableOpCode.LoadLocal or ExecutableOpCode.StoreLocal ? i.LocalSlot : -1;
        Console.WriteLine($"{n}: {i.OpCode} local={local} inputs={i.InputStart},{i.SecondInput} result={i.ResultSlot} extent={i.LiveExtent} localResult={i.HasLocalResult}");
    }
    foreach (var function in code.Functions) Dump(function.CodeObject);
}
