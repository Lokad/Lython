from pathlib import Path
import hashlib,io,json,shutil,subprocess,tarfile
r=Path(__file__).resolve().parent;q=r/'quiet';repo=Path('D:/code/Lython')
old=r/'first-staging-floor'
if not old.exists():
    old.mkdir()
    for n in ['config.json','remote-launch.py','launch.log']:shutil.copyfile(q/n,old/n)
canonical='benchmarks/results/2026-11-12-bulk-utf16/b631/observations.tgz'
blob=subprocess.check_output(['git','show','HEAD:'+canonical],cwd=repo);assert blob==(repo/canonical).read_bytes()
subjects=[]
with tarfile.open(fileobj=io.BytesIO(blob))as archive:
    for member in ['confirmation/confirmation.json']:
        data=blob if member=='whole-archive'else archive.extractfile(member).read()
        subjects.append(dict(kind='completed-replica',path='bulk-utf16-b631-20261112/'+member,bytes=len(data),sha256=hashlib.sha256(data).hexdigest(),canonical=canonical,canonicalSHA256=hashlib.sha256(blob).hexdigest(),member=member,committedBlobVerified=True))
s=(r.parent/'json-scalars-r492/prepare-quiet.py').read_text(encoding='utf-8');a=s.index("code = '''")+len("code = '''");b=s.index("'''.replace",a)
code=s[a:b].replace('SUBJECTS',repr(subjects)).replace("else[b/'numeric-json-cost-b909-20261117/observations.tgz']","else[b/item['path']]")
code=code.replace('json-cpython-b908-20261117','completed-operations-b918-20261117').replace("source/'candidate/Lokad.Lython.dll'","source/'reference/Lokad.Lython.dll'")
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
p=subprocess.run(ssh+['python3 -'],input=code,text=True,encoding='utf-8',capture_output=True,timeout=60);assert p.returncode==0,p.stdout+p.stderr
c=json.loads((q/'config.json').read_text(encoding='utf-8'));c['retireGroups']+=json.loads(p.stdout)
(q/'config.json').write_text(json.dumps(c,indent=2)+'\n',encoding='utf-8',newline='\n')
s=(q/'remote-launch.py').read_text(encoding='utf-8');a=s.index('c=');b=s.index('\nb=Path(',a);s=s[:a]+'c='+repr(c)+s[b:]
(q/'remote-launch.py').write_text(s,encoding='utf-8',newline='\n')
(q/'launch.log').rename(old/'original-launch.log')
(r/'setup-corrections.json').write_text(json.dumps(dict(workerMetadata='Fresh nonincremental committed build updates worker/adapter informational metadata. Initial unchanged-auxiliary assertion stopped before VM work; complete current32file image was copied and verified instead.',firstStaging='254MiB floor refused before mutation or workers. B875 raw path had already been retired; read-only verification refused, no deletion. Add exact committed B631 JSON replica after fresh lease/path/UID/hash/nlink/all-alias verification; preserve floor and original config/log. No measurement conditions changed.'),indent=2)+'\n',encoding='utf-8')
print('Additional B631 raw replica proved; original staging refused before mutation. Unchanged floors/collection.')
