from pathlib import Path
import ast,gzip,hashlib,io,json,os,shutil,subprocess,tarfile
r=Path(__file__).resolve().parent;repo=Path('D:/code/Lython');notes=r.parent
old=notes/'json-cpython-checkpoint-r491';donor=notes/'completed-runner-r495/flat-operations'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()
assert head=='0d2a6ab7a9aac2c3f80e0cd0c3dc670069b07bbc'
assert not subprocess.check_output(['git','status','--porcelain'],cwd=repo)
assert 'Build succeeded.'in(r/'checkpoint-build.log').read_text(encoding='utf-8-sig')
oldidentity=json.loads((donor/'frozen/identity.json').read_text(encoding='utf-8'))
frozen=r/'frozen';frozen.mkdir(exist_ok=False)
for name,h in oldidentity['imageFiles']['reference'].items():
    p=repo/'benchmarks/Lokad.Lython.Benchmarks/bin/Release/net11.0'/name
    shutil.copyfile(p,frozen/name)
files={n:sha(frozen/n)for n in oldidentity['imageFiles']['reference']};assert len(files)==32
changed=[n for n,h in files.items()if oldidentity['imageFiles']['reference'][n]!=h]
assert 'Lokad.Lython.dll'in changed
catalog=notes/'call-cost-gate-r488/checkpoint-catalog.json'
assert sha(catalog)==oldidentity['catalogSHA256']
shutil.copyfile(catalog,r/'representative.json')
inputs=json.loads((notes/'returned-loan-bound-r496/delivery/inputs.json').read_text(encoding='utf-8'))
assert inputs['head']==head and inputs['count']==2383 and inputs['production']==585
shutil.copyfile(notes/'returned-loan-bound-r496/delivery/inputs.tar.xz',r/'source-inputs.tar.xz')
identity=dict(sourceRevision='Committed0d2a6ab7; main R496 delivery44168196734, separately observed',purpose='Four representative complete scripts against stockCPython3.13.16; compilation, warm execution and compile-to-result separated. Existing workers/protocol, no causal change claim.',runtimeCommit=head,coreSHA256={v:files['Lokad.Lython.dll']for v in ['candidate','candidate-control']},imageFiles={'candidate':files},auxiliaryFiles={n:h for n,h in files.items()if n!='Lokad.Lython.dll'},catalogSHA256=sha(catalog),sourceInputsArchiveSHA256=sha(r/'source-inputs.tar.xz'),productionFiles=585,normalAdapterPin='0.4.0',publicationHeld=True)
(r/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8',newline='\n')
dotnet=Path('C:/Users/JoannesVermorel/.dotnet11/dotnet.exe');env=os.environ.copy();env.update(DOTNET_ROOT=str(dotnet.parent),DOTNET_ROOT_X64=str(dotnet.parent));env['PATH']=str(dotnet.parent)+os.pathsep+env['PATH']
with(r/'preflight.log').open('w',encoding='utf-8')as log:
    p=subprocess.run([str(dotnet),str(frozen/'Lokad.Lython.Benchmarks.dll'),'--compare','verify','--catalog',str(r/'representative.json'),'--dotnet',str(dotnet),'--python','C:/Python313/python.exe','--python-worker',str(repo/'benchmarks/cpython-worker.py'),'--out',str(r/'preflight.json')],env=env,stdout=log,stderr=subprocess.STDOUT)
assert p.returncode==0,(r/'preflight.log').read_text(encoding='utf-8')
print('Current committed image:32files/all5actual-worker goldens verified.',flush=True)
subjects=[]
canonical='benchmarks/results/2026-11-17-completed-instruction-runner/flat-operations/candidate-core.dll.gz'
blob=subprocess.check_output(['git','show','HEAD:'+canonical],cwd=repo);assert blob==(repo/canonical).read_bytes();data=gzip.decompress(blob)
subjects.append(dict(kind='superseded-core',sha256=hashlib.sha256(data).hexdigest(),bytes=len(data),canonical=canonical,canonicalSHA256=hashlib.sha256(blob).hexdigest(),member='gzip-payload',committedBlobVerified=True))
canonical='benchmarks/results/2026-11-17-completed-instruction-runner/flat-operations/observations.tgz'
blob=subprocess.check_output(['git','show','HEAD:'+canonical],cwd=repo);assert blob==(repo/canonical).read_bytes()
with tarfile.open(fileobj=io.BytesIO(blob))as archive:
    for member in ['confirmation/confirmation.json','whole-archive']:
        data=blob if member=='whole-archive'else archive.extractfile(member).read()
        subjects.append(dict(kind='completed-replica',path='completed-operations-b918-20261117/'+('observations.tgz'if member=='whole-archive'else member),bytes=len(data),sha256=hashlib.sha256(data).hexdigest(),canonical=canonical,canonicalSHA256=hashlib.sha256(blob).hexdigest(),member=member,committedBlobVerified=True))
assert subjects[0]['sha256']!=files['Lokad.Lython.dll']
s=(notes/'json-scalars-r492/prepare-quiet.py').read_text(encoding='utf-8');a=s.index("code = '''")+len("code = '''");b=s.index("'''.replace",a)
code=s[a:b].replace('SUBJECTS',repr(subjects)).replace("else[b/'numeric-json-cost-b909-20261117/observations.tgz']","else[b/item['path']]")
code=code.replace('json-cpython-b908-20261117','completed-operations-b918-20261117').replace("source/'candidate/Lokad.Lython.dll'","source/'reference/Lokad.Lython.dll'")
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
p=subprocess.run(ssh+['python3 -'],input=code,text=True,encoding='utf-8',capture_output=True,timeout=60);assert p.returncode==0,p.stdout+p.stderr
groups=json.loads(p.stdout);q=r/'quiet';q.mkdir(exist_ok=False)
(q/'retirement-proofs.json').write_text(json.dumps(groups,indent=2)+'\n',encoding='utf-8',newline='\n')
(q/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8',newline='\n')
remote='/home/lokad/lython-bench-checks/representative-cpython-b919-20261117'
jobs=[[case,lane]for case in ['scripts.csv-numeric-quality.large','scripts.text-normalization.large','scripts.json-summary-helpers.large','scripts.numeric-squared-error.floating.large']for lane in ['compile','warm','compile-run']]
s=(old/'quiet/collect.py').read_text(encoding='utf-8');a=s.index('jobs=');b=s.index('\nenv =',a)
s=s[:a]+'jobs='+repr(jobs)+'\nassert len(jobs)==12 and all(case in cases for case,lane in jobs)\n'+s[b:]
s=s.replace("time.monotonic()-started < 240, 'Reserve60seconds for final owned work/cleanup.'","time.monotonic()-started < 540, 'Reserve60seconds for final owned work/cleanup.'")
s=s.replace('warmupSeconds=5, compilationWarmupSeconds=5','warmupSeconds=6, compilationWarmupSeconds=6')
a=s.index('            counts=[]; warmups=[]');b=s.index('            time.sleep(1)',a)
rotated=(donor/'quiet/collect.py').read_text(encoding='utf-8');i=rotated.index('            counts=');j=rotated.index('            time.sleep(1)',i)
s=s[:a]+rotated[i:j]+s[b:]
(q/'collect.py').write_text(s,encoding='utf-8',newline='\n')
s=(old/'quiet/archive-owned.py').read_text(encoding='utf-8').replace("len(raw['jobs'])==6","len(raw['jobs'])==12").replace('jobs=6','jobs=12')
(q/'archive-owned.py').write_text(s,encoding='utf-8',newline='\n')
s=(old/'quiet/run.sh').read_text(encoding='utf-8').replace(json.loads((old/'quiet/config.json').read_text(encoding='utf-8'))['root'],remote)
(q/'run.sh').write_text(s,encoding='utf-8',newline='\n')
(q/'candidate').mkdir();shutil.copyfile(catalog,q/'representative.json')
names=['collect.py','archive-owned.py','run.sh','identity.json','representative.json']
for n in changed:
    shutil.copyfile(frozen/n,q/'candidate'/n);names.append('candidate/'+n)
with tarfile.open(q/'payload.tgz','w:gz')as archive:
    for n in names:archive.add(q/n,arcname=n)
c=dict(root=remote,unit='lython-b919-representative-cpython-20261117',source='/home/lokad/lython-bench-checks/completed-operations-b918-20261117',sourceRole='reference',sourceFiles=oldidentity['imageFiles']['reference'],sourceCatalogSHA256=sha(catalog),catalogSHA256=sha(catalog),identity=identity,retireGroups=groups,payloadBytes=(q/'payload.tgz').stat().st_size,payloadSHA256=sha(q/'payload.tgz'),unpackedBytes=sum((q/n).stat().st_size for n in names))
(q/'config.json').write_text(json.dumps(c,indent=2)+'\n',encoding='utf-8',newline='\n')
s=(old/'quiet/remote-launch.py').read_text(encoding='utf-8');a=s.index('c=');b=s.index('\nb=Path(',a);s=s[:a]+'c='+repr(c)+s[b:]
s=s.replace('lython-b908-fixtures','lython-b919-fixtures').replace('RuntimeMaxSec=300','RuntimeMaxSec=600')
(q/'remote-launch.py').write_text(s,encoding='utf-8',newline='\n')
s=(old/'launch.py').read_text(encoding='utf-8').replace('seconds=250','seconds=500').replace('before250seconds','before500seconds').replace('Six-job JSON CPython checkpoint','Twelve-job representative CPython checkpoint')
(r/'launch.py').write_text(s,encoding='utf-8',newline='\n')
s=(old/'quiet/retrieve.py').read_text(encoding='utf-8').replace("['jobs']==6","['jobs']==12").replace('B908','B919')
(q/'retrieve.py').write_text(s,encoding='utf-8',newline='\n')
s=(old/'summarize.py').read_text(encoding='utf-8').replace("len(raw['jobs'])==6","len(raw['jobs'])==12")
(r/'summarize.py').write_text(s,encoding='utf-8',newline='\n')
for p in list(q.glob('*.py'))+[r/'launch.py',r/'summarize.py']:ast.parse(p.read_text(encoding='utf-8'))
print('Twelve separated~40second jobs prepared; existing workers/catalog, rotated6second full-request warmup, five rounds, two processes per engine. Canonical-backed replicas only; no causal gain claim.',flush=True)
