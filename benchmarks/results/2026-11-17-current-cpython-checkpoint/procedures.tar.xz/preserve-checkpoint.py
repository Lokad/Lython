from pathlib import Path
import hashlib,json,re,shutil,tarfile
r=Path(__file__).resolve().parent;repo=Path('D:/code/Lython');q=r/'quiet'
out=repo/'benchmarks/results/2026-11-17-current-cpython-checkpoint';out.mkdir(exist_ok=False)
summary=json.loads((r/'summary.json').read_text(encoding='utf-8'));assert summary['complete']and len(summary['timing'])==12
status=json.loads((q/'terminal-status.json').read_text(encoding='utf-8'));assert status['exitCode']=='0'and not status['remainingWorkers']and not status['remainingTrace']
identity=json.loads((r/'identity.json').read_text(encoding='utf-8'))
assert hashlib.sha256((q/'observations.tgz').read_bytes()).hexdigest()==status['receipt']['archiveSHA256']
for src,dst in [(r/'identity.json','identity.json'),(r/'representative.json','catalog.json'),(r/'source-inputs.tar.xz','source-inputs.tar.xz'),(r/'summary.json','summary.json'),(r/'preflight.json','preflight.json'),(q/'observations.tgz','observations.tgz'),(q/'terminal-status.json','terminal-status.json'),(q/'archive-receipt.json','archive-receipt.json')]:shutil.copyfile(src,out/dst)
shutil.copyfile(repo/'docs/BENCHMARKS.md',out/'prior-BENCHMARKS.md')
old=json.loads((r.parent/'completed-runner-r495/flat-operations/frozen/identity.json').read_text(encoding='utf-8'))['imageFiles']['reference']
changed=[n for n,h in identity['imageFiles']['candidate'].items()if h!=old[n]]
with tarfile.open(out/'changed-image-files.tar.xz','w:xz')as a:
    for n in changed:a.add(r/'frozen'/n,arcname=n)
with tarfile.open(out/'procedures.tar.xz','w:xz')as a:
    for pattern in ['*.py','*.log','*.json','inspect/*','first-staging-floor/*']:
        for p in sorted(r.glob(pattern)):
            if p.is_file():a.add(p,arcname=p.relative_to(r).as_posix())
    for p in sorted(q.glob('*')):
        if p.is_file()and p.suffix in ['.py','.json','.sh','.log']:a.add(p,arcname=p.relative_to(r).as_posix())
names={
 'scripts.csv-numeric-quality.large':('Numeric CSV quality report','4,096 records / 127,031 B'),
 'scripts.text-normalization.large':('Text normalization','4,096 lines / 52,224 B'),
 'scripts.json-summary-helpers.large':('JSON-lines aggregation with a helper','4,096 records / 110,592 B'),
 'scripts.numeric-squared-error.floating.large':('Floating JSON numeric report','4,096 pairs / 56,495 B')}
def interval(v,precision):return f'{min(v):.{precision}f}–{max(v):.{precision}f}'
def row(x,phase=False):
    med=x['medianMilliseconds'];title,size=names[x['case']]
    status=f"Diagnostic; controls L/C {x['lythonControlPercent']:.2f}/{x['cpythonControlPercent']:.2f}%; IQR≤{x['maxIqrPercent']:.2f}%"
    label={'compile':'Compilation only','warm':'Warm execution','compile-run':'Compile and execute once'}[x['lane']]
    return f"| {title} | {label if phase else size} | {interval([med[k]for k in ['candidate','candidate-control']],3)} ms | {interval([med[k]for k in ['CPython','CPython-control']],3)} ms | {interval(x['ratioRange'],2)}× | {status} |"
warm='\n'.join(row(x)for x in summary['timing']if x['lane']=='warm')
phases='\n'.join(row(x,True)for x in summary['timing']if x['lane']!='warm')
guide=f'''# Performance against CPython

| Workload / warm execution | Input | Lython | CPython | Lython / CPython | Measurement status |
| --- | --- | ---: | ---: | ---: | --- |
{warm}

**Ratio = Lython elapsed / CPython elapsed; above one means slower.** Ranges cover
the combinations of two process medians per engine, not confidence intervals.
Controls L/C report the difference between the two Lython/CPython medians. These
complete scripts show substantial text/numeric gaps alongside faster CSV/JSON-lines.

Measured **2026-11-17 UTC**, committed **0d2a6ab7 / frozen8d26963c**, stock
**CPython3.13.16** (PGO/LTO, GIL enabled, no JIT), quiet **AzureF4as_v7**,4vCPU
AMD EPYC9V45/16GiB, Ubuntu24.04.4, .NET11RC3. Existing workers/catalog;12jobs,
447.28seconds, rotated6second full-request warmups/five rounds, natural GC/tiering.
All actual-image/golden/quiet/exit/join gates pass. Exact magnitudes remain
diagnostic; these measurements do not describe an unmeasured later HEAD.
[Sources, raw observations and procedures](../benchmarks/results/2026-11-17-current-cpython-checkpoint/README.md).

Warm clocks include Run, mediated RAM-backed file I/O, stdout/file golden checks
and previous-result cleanup. Lython's host supplies efficient range/append I/O;
CPython uses its native file APIs without Lython's containment/ownership checks.
Fixture reset, request framing, process startup and final cache teardown are outside
guest clocks. Wider process CPU includes reset/protocol and is preserved separately.
This is useful workload latency, not equivalent containment or cold startup.

## Compilation and compile-to-result

| Workload | Phase | Lython | CPython | Lython / CPython | Measurement status |
| --- | --- | ---: | ---: | ---: | --- |
{phases}

Compilation includes compiled-owner disposal. Compile-to-result includes compilation,
one execution and compiled-owner disposal. Separately warmed medians are not
additive. Compilation is a small part of these scripts' elapsed costs. Floating
compile-to-result's4.78%Lython control movement limits precision; no unchanged retiming
is needed to establish the remaining large gap. Process startup was not measured.

## Uncertainty and earlier measurements

The floating fresh control, text warm CPython control and other distributions stay
visible above. The [previous guide](../benchmarks/results/2026-11-17-current-cpython-checkpoint/prior-BENCHMARKS.md)
preserves earlier helper-text/report, configuration, file-search and CSV invoice
measurements with their named revisions, original adverse controls and unresolved
phase inversions. Those results are historical, not this checkpoint or today's HEAD.
The new ratios do not establish a source-change gain across collections.

The measured runtime's [first delivery](../benchmarks/results/2026-11-17-returned-loan-cleanup/README.md)
passed Ubuntu and both platforms' ordinary/package checks but failed a Windows10
stress fixture's post-return cancellation inference. A fixture correction is
committed; complete delivery qualification remains separate from benchmark gates.

## Improvements within Lython

These are separate source-pair observations; they cannot be added or substituted
for the CPython ratios above.

| Change | Established outcome | Limits / evidence |
| --- | --- | --- |
| Native helper returns | Allocation about19–20% lower; qualified | Original elapsed improvements diagnostic; no universal CPU claim. [History](../benchmarks/EXPERIMENTS.md). |
| Direct UTF-8 formatting/storage | Allocation8.67% lower; controlled report elapsed/CPU5–8% lower supports retention | Original adverse15.125ms remains unexplained. [Original/confirmation](../benchmarks/results/2026-11-02-formatting-confirmation/README.md). |
| Floating arithmetic-to-iteration transport | Warm/fresh elapsed23–27% lower with supporting CPU; allocation28.52% lower | Historical source pair; integer controls uncertain, original regression retained. [Evidence](../benchmarks/results/2026-11-17-float-transport/README.md). |
| Shared receiver calls | Helper text/report warm24–40% lower, fresh22–39% lower, supporting CPU | Historical workloads/source pair; numeric magnitude uncertain. [Evidence](../benchmarks/results/2026-11-17-receiver-calls/README.md). |
| Bulk CSV/shared-key/final-row construction | Earlier complete-script6–8% improvement is already integrated | Not new pending work. Detailed other improvements/debts remain in the [previous guide](../benchmarks/results/2026-11-17-current-cpython-checkpoint/prior-BENCHMARKS.md) and [history](../benchmarks/EXPERIMENTS.md). |

Rejected optimizations and qualification narratives stay behind the evidence links.
Use the [existing tooling](../benchmarks/README.md); keep current benchmark status
and source revision here. Measurements and qualification do not authorize publication.
'''
(repo/'docs/BENCHMARKS.md').write_text(guide,encoding='utf-8',newline='\n')
(out/'README.md').write_text(f'''# Representative CPython checkpoint

R497/B919,2026-11-17 UTC. Committed0d2a6ab7/frozen8d26963c against stockCPython3.13.16,
quiet AzureF4as_v7/Ubuntu24.04.4/.NET11RC3. Four existing trusted complete scripts,
three phases each;12jobs447.28seconds. Two independent processes per engine,
rotated6second full-request warmups/five rounds, natural GC/tiering. Same catalog
6a661e8e and command-v2 timing/protocol. No new comparison framework.

{warm}

CSV fresh0.90–0.94×, text1.66–1.67×, JSON-lines0.87–0.88×, floating1.69–1.78×;
floating fresh Lython control4.78%limits magnitude. Compilation ratios1.26×/0.96×/
0.99–1.00×/0.92–0.95× respectively. Do not add phase medians or infer causal source
gains versus prior collections. Raw medians/CPU/IQRs/all controls stay visible.

Boundary: warm includes Run/mediated RAM I/O/goldens/previous-result cleanup; fresh
adds compile/compiled-owner disposal; compile includes compiled-owner disposal.
Startup/reset/protocol/final cache teardown excluded; external CPU is wider.
CPython native I/O does not supply Lython's containment. All actual32file image,
golden/quiet/Closed/exit/join gates pass; archive SHAverified while lease held.
Guest fixtures removed and no workers remain. No startup/tail-latency/general CPU
claim. The runtime's failed Windows stress fixture/qualification remains separate.

Initial local freeze assumed unchanged worker metadata, but a fresh committed build
changes informational revision data. Copy/verify every actual changed image file
instead. Staging then refused the254MiB floor before mutation or workers. A proposed
B875 raw path was already absent; read-only proof refused. Add an exact committed
B631raw replica after fresh idle lease/path/UID/hash/nlink/all-alias proof; keep
original floor/config/logs. Only exact canonical-backed superseded core/raw replicas
retired. Qualified reference/current new image/catalog/toolchains remain. No
measurement conditions or resource guards relaxed. Final free265,588,736B>252MiB.

Changed image files: {', '.join(changed)}. Exact2383source inputs/585production
preserved; full32file manifest and actual Ready reports in raw evidence. This does
not imply rebuilt-binary equality with CI. Publication postponed/objective active.

[Summary](summary.json),[raw](observations.tgz),[identity](identity.json),
[changed binaries](changed-image-files.tar.xz),[source](source-inputs.tar.xz),
[goldens](preflight.json),[custody](archive-receipt.json),[procedures](procedures.tar.xz),
[previous guide](prior-BENCHMARKS.md). Current user-facing account: [BENCHMARKS](../../../docs/BENCHMARKS.md).
''',encoding='utf-8',newline='\n')
for target in re.findall(r'\]\(([^)]+)\)',guide):
    if not target.startswith(('https:','http:','#')):assert(repo/'docs'/target.split('#')[0]).resolve().exists(),target
with(repo/'benchmarks/EXPERIMENTS.md').open('a',encoding='utf-8',newline='\n')as h:
    h.write('\nR497/B919 [current named CPython checkpoint](results/2026-11-17-current-cpython-checkpoint/README.md),0d2a6ab7/frozen8d26963c versus stock3.13.16: four existing complete scripts/three phases,12jobs447.28s/all gates/users joined/SHAarchive. Warm CSV0.87–0.91×, text1.76–1.84×, JSON-lines0.86–0.89×, floating1.93–1.98×; fresh0.90–0.94/1.66–1.67/0.87–0.88/1.69–1.78×. Floating fresh reference movement4.78%limits magnitude; no source-gain inference or startup claim. Nonincremental actual32file image/current metadata validated; original freeze/staging/absent-replica conditions preserved. Exact canonical-backed retirement only, floors unchanged. Guide leads with four current named workloads; previous guide/all adversity retained behind links. Full runtime delivery separately pending after fixture correction. Publication held/broader objective active.\n')
print('Four-workload named guide refreshed; all12conditions, uncertainty, original failures and custody preserved.')
