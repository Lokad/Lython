from pathlib import Path
import hashlib,json,re,shutil,tarfile,zipfile
r=Path(__file__).resolve().parent;repo=Path('D:/code/Lython');old=r.parent/'returned-loan-bound-r496';d=old/'delivery'
out=repo/'benchmarks/results/2026-11-17-returned-loan-cleanup';out.mkdir(exist_ok=False)
for n in ['terminal.json','run-logs.zip','inputs.json','inputs.tar.xz']:shutil.copyfile(d/n,out/n)
for n in ['before-fix.log','before-build.log','checks.json','final-trim-build.log','final-trim-net11.0.log','final-trim-net10.0.log']:shutil.copyfile(old/n,out/n)
for n in ['cancellation-build.log','cancellation-net11.0.log','cancellation-net10.0.log']:shutil.copyfile(r/n,out/n)
rows=[]
with zipfile.ZipFile(d/'run-logs.zip')as a:
    for n in a.namelist():
        if '/'in n or not n.endswith('.txt'):continue
        text=a.read(n).decode('utf-8-sig')
        matches=re.findall(r'(?:Passed!|Failed!)\s+-\s+Failed:\s*(\d+).*?\bPassed:\s*([\d,]+).*?\bSkipped:\s*([\d,]+).*?\bTotal:\s*([\d,]+).*?\((net\d+\.\d+)\)',text)
        assert len(matches)==8,(n,len(matches))
        for m in matches:
            failed,passed,skipped,total=[int(v.replace(',',''))for v in m[:4]]
            assert skipped==0 and failed+passed==total
            rows.append(dict(log=n,framework=m[4],failed=failed,passed=passed,total=total))
assert len(rows)==16 and sum(v['failed']for v in rows)==1
receipt=dict(run=44168196734,head='0d2a6ab7a9aac2c3f80e0cd0c3dc670069b07bbc',conclusion='failure',summaries=rows,logsSHA256=hashlib.sha256((d/'run-logs.zip').read_bytes()).hexdigest(),fullQualificationComplete=False,productionUnchangedByFixtureCorrection=True,publicationHeld=True)
(out/'qualification.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8',newline='\n')
with tarfile.open(out/'focused-procedures.tar.xz','w:xz')as a:
    for root,prefix in [(old,'original'),(r,'fixture-correction')]:
        for p in sorted(root.glob('*.py')):a.add(p,arcname=prefix+'/'+p.name)
(out/'README.md').write_text('''# Returned private-loan cleanup: first delivery

Committed0d2a6ab7 fixes a compiler cleanup bound: consumed/forwarded helper calls
can own private iteration loans without a GetIter in the callee. Array-backed
cancellation cleanup omitted those results; the new regression fails before the
fix while native cleanup passes. Include those slots in the existing bound and
delete native cleanup's separate final full scan/proxy. Eight independent public
continuation cases retain effects, aliases, refusal, held I/O cleanup and reuse.

Focused actual11/10 each1,007internal/4,217public, then29affected internal checks,
pass. [Full44168196734](https://github.com/Lokad/Lython/actions/runs/44168196734)
**fails Windows.NET10stress**: CachedTextKeyProbeObservesConcurrentCancellation
(read). Both platforms' ordinary/package checks, Windows11stress and all Ubuntu
stress pass. All16summaries and the original exact inputs/logs are retained.
This is not full qualification; latest prior fully qualified runtime is33bd7efd.

The fixture read the token in a finally after the dictionary probe returned.
Cancellation can arrive between those events; that snapshot cannot order return
against cancellation. Source review confirms explicit context forwarding and4KiB
text scan checks. This explains a possible false positive, not a measured Windows
scheduling trace or proof of the exact triggering interleaving. Production stays
unchanged. Correct the invalid inference: allow completion to win, retain actual
cancelled results/provenance, join the canceller, then require a cached-key probe
to reject the cancelled caller without mutation. Keep large concurrent input,
timeouts, funding and cleanup assertions. Focused corrected4cases pass each actual
11/10. A subsequent coherent delivery must qualify the corrected fixture.

The tests demonstrate observable cancellation/side effects, not atomic cancellation
at return or exact checkpoint timing. Command-level cancellation remains unchanged.
No CPU gain or rebuilt-binary equality claimed. Publication held; performance
objective active. Three adverse shared-runner prototypes remain outside production.

[Receipt](qualification.json),[original inputs](inputs.tar.xz),[logs](run-logs.zip),
[before-fix failure](before-fix.log),[focused checks](checks.json),
[procedures](focused-procedures.tar.xz).
''',encoding='utf-8',newline='\n')
with(repo/'benchmarks/EXPERIMENTS.md').open('a',encoding='utf-8',newline='\n')as h:
    h.write('\nR496 [forwarded private-loan cleanup](results/2026-11-17-returned-loan-cleanup/README.md), committed0d2a6ab7: owned-storage cancellation regression fails before correction/native passes; bound includes directly consumed/returned call loans, native final full scan/proxy deleted. Focused11/10each1,007internal/4,217public plus29internal pass. Full44168196734 fails Windows10 cached text-key read stress; all ordinary/package, Windows11stress/Ubuntu pass. Preserve16summaries/inputs/logs. Post-return token snapshot cannot order cancellation/completion; fixture now keeps concurrent outcomes and requires a joined cancelled cached-key probe with no mutation.4focused cases pass each11/10; runtime unchanged by correction, new full delivery pending. No CPU claim/publication; broader objective active.\n')
print('Original failure, inputs and all16summaries preserved; no green claim.')
