from pathlib import Path
import gzip, hashlib, json, shutil, subprocess, tarfile

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
past = lab.parent / "module-leading-indentation-20261122"
programs = lab.parent / "current-cpython-checkpoint-20261122/comparison"
out = lab / "comparison"
quiet = out / "quiet"
quiet.mkdir(parents=True, exist_ok=True)
base = "/home/lokad/lython-bench-checks"
root = base + "/retained-current-cpython-b1406-20261122"
unit = "lython-b1406-retained-current-cpython-20261122"
core = "Lokad.Lython.dll"

def read(path): return json.loads(path.read_text(encoding="utf-8-sig"))
def sha(blob): return hashlib.sha256(blob).hexdigest()
def write(path, value):
    if path.suffix == ".py": compile(value, str(path), "exec")
    path.write_text(value, encoding="utf-8", newline="\n")
def save(path, value): write(path, json.dumps(value, indent=2) + "\n")
def committed(relative):
    return subprocess.check_output(["git", "show", "origin/master:benchmarks/results/" + relative], cwd=repo)

refs = read(lab / "images.json")
files = refs["imageFiles"]
previous = read(past / "comparison/quiet/config.json")
donor = previous["identity"]["imageFiles"]["reference"]
expected = files["candidate"]
assert len(expected) == 32 and expected == {name: sha((lab / "frozen" / name).read_bytes()) for name in expected}
assert all(h == donor[n] for n, h in expected.items() if n != core)
evidence = read(lab / "verify.json")
assert evidence["state"] == "Completed" and evidence["caseCount"] == 6 and evidence["catalogSha256"] == refs["catalogSHA256"]
archive_dir = "2026-11-22-module-leading-indentation"
receipt = json.loads(committed(archive_dir + "/archive-receipt.json"))
assert all(receipt[k] for k in ("complete", "allWorkersJoined", "archivedAndVerifiedUnderLease"))
assert sha(committed(archive_dir + "/observations.tgz")) == receipt["archiveSHA256"]
catalog = lab / "representative.json"
assert sha(catalog.read_bytes()) == refs["catalogSHA256"]
identity = dict(sourceRevision=refs["revision"] + " versus CPython 3.13.16",
    reference="CPython 3.13.16", candidate=refs["revision"],
    normalAdapterPin="0.4.0", imageFiles=files,
    coreSHA256={label: expected[core] for label in ("candidate", "candidate-control")},
    cpythonWorkerSHA256=refs["protocolSHA256"], auxiliaryFiles={n: h for n, h in expected.items() if n != core},
    catalogs={"representative.json": {"sha256": refs["catalogSHA256"]}})
save(quiet / "identity.json", identity)
shutil.copyfile(catalog, quiet / "representative.json")
(quiet / "candidate").mkdir(exist_ok=True)
shutil.copyfile(lab / "frozen" / core, quiet / "candidate" / core)
old = read(programs / "quiet/config.json")
for name in ("collect.py", "run.sh", "archive-owned.py", "retrieve.py"):
    data = (programs / "quiet" / name).read_text(encoding="utf-8")
    write(quiet / name, data.replace(old["root"], root).replace(old["unit"], unit).replace("B1397", "B1406"))

# The VM lease and byte-verified retirement use the preceding quiet run's procedure.
procedure = (past / "stage.py").read_text(encoding="utf-8")
start = procedure.index('assert b"\\r"')
end = procedure.index('data=(programs/', start)
procedure = procedure[start:end]
earlier = "2026-11-22-repeated-eager-annotations"
earlier_image = gzip.decompress(committed(earlier + "/candidate-core.dll.gz"))
earlier_hash = sha(earlier_image)
assert earlier_hash == json.loads(committed(earlier + "/source.json"))["imageFiles"]["candidate"][core]
earlier_path = "uniform-eager-annotation-b1398-20261122/candidate/" + core
assert earlier_hash not in (donor[core], expected[core])
before = ' print(json.dumps(dict(free=shutil.disk_usage(b).free,redundant=observations)))'
after = """
 p = b / {earlier_path!r}
 eligible = None
 if p.exists():
  m = p.lstat()
  assert p.resolve() == p and stat.S_ISREG(m.st_mode) and m.st_uid == os.getuid() and sha(p) == {earlier_hash!r}
  paths = []
  for folder, dirs, names in os.walk(b):
   for name in names:
    q = Path(folder) / name
    v = q.lstat()
    if (v.st_dev, v.st_ino) == (m.st_dev, m.st_ino):
     assert q.resolve() == q and q.name == p.name and stat.S_ISREG(v.st_mode) and v.st_uid == os.getuid()
     paths.append(str(q.relative_to(b)))
  assert len(paths) == m.st_nlink and {earlier_path!r} in paths
  eligible = dict(paths=sorted(paths), bytes=m.st_size, sha256={earlier_hash!r}, links=m.st_nlink, archives={{}})
 print(json.dumps(dict(free=shutil.disk_usage(b).free,redundant=observations,displacedComparisonCore=eligible)))
"""
assert before in procedure
procedure = procedure.replace(before, after.rstrip())
before = 'assert free>threshold,(free,threshold)'
after = """
if free <= threshold and proof["displacedComparisonCore"]:
    earlier_receipt = json.loads(committed(earlier + "/archive-receipt.json"))
    check_archive(earlier, earlier_receipt["archiveSHA256"])
    earlier_proof = proof["displacedComparisonCore"]
    assert earlier_proof["sha256"] == earlier_hash and earlier_proof["bytes"] == len(earlier_image)
    retire.append(earlier_proof)
    free += len(earlier_image)
"""
procedure = procedure.replace(before, after + before)
exec(compile(procedure, "quiet storage checks", "exec"), globals())
launcher = (past / "comparison/quiet/remote-launch.py").read_text(encoding="utf-8")
launcher = launcher.replace("lython-b1405-fixtures", "lython-b1406-fixtures")
launcher = launcher.replace("RuntimeMaxSec=365", "RuntimeMaxSec=525")
launcher = launcher.replace("for role in ['reference','candidate']:", "for role in ['candidate']:")
start, end = launcher.index("\nc=") + 1, launcher.index("\nb=Path(")
write(quiet / "remote-launch.py", launcher[:start] + "c=" + repr(config) + launcher[end:])
launch = (programs / "launch.py").read_text(encoding="utf-8")
write(out / "launch.py", launch.replace("Retained source vs CPython", "New retained source vs CPython"))
report = (programs.parent / "report-data.py").read_text(encoding="utf-8")
write(lab / "report-data.py", report.replace("current-cpython-checkpoint-20261122", lab.name))
print("Verified the six prior CPython-row fixtures and the exact 32-file image.")
