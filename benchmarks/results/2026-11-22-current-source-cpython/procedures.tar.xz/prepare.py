from pathlib import Path
import hashlib, json, os, shutil, subprocess, tarfile

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
past = lab.parent / "module-leading-indentation-20261122/comparison"
prior = repo / "benchmarks/results/2026-11-22-retained-source-cpython"

def read(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def git(*args):
    return subprocess.check_output(["git", *args], cwd=repo)

revision = (lab / "built-revision.txt").read_text(encoding="utf-8-sig").strip()
assert not git("status", "--porcelain")
assert git("merge-base", "--is-ancestor", revision, "origin/master") == b""
assert not git("diff", "--name-only", revision, "HEAD", "--", "src", "benchmarks/cpython-worker.py")

receipt = read(prior / "archive-receipt.json")
archive = prior / "observations.tgz"
assert receipt["complete"] and sha(archive) == receipt["archiveSHA256"]
catalog = lab / "representative.json"
with tarfile.open(archive) as bundle:
    catalog.write_bytes(bundle.extractfile("representative.json").read())
assert sha(catalog) == read(prior / "source.json")["catalogSHA256"]

source = past / "frozen-reference"
manifest = read(past / "images.json")
expected = manifest["imageFiles"]["reference"]
assert len(expected) == 32 and {name: sha(source / name) for name in expected} == expected
image = lab / "frozen"
image.mkdir(exist_ok=True)
core = "Lokad.Lython.dll"
built = lab / "build/bin/Lokad.Lython/release_net11.0" / core
for name in expected:
    shutil.copyfile(built if name == core else source / name, image / name)
actual = {p.name: sha(p) for p in image.iterdir() if p.is_file()}
assert actual == {**expected, core: sha(built)}

sdk = Path.home() / ".dotnet11"
dotnet = sdk / "dotnet.exe"
env = dict(os.environ, DOTNET_ROOT=str(sdk), DOTNET_ROOT_X64=str(sdk), PATH=str(sdk) + os.pathsep + os.environ["PATH"])
protocol = repo / "benchmarks/cpython-worker.py"
assert sha(protocol) == manifest["protocolSHA256"]
verified = lab / "verify.json"
subprocess.run([dotnet, image / "Lokad.Lython.Benchmarks.dll", "--compare", "verify",
    "--catalog", catalog, "--dotnet", dotnet, "--python", "C:/Python313/python.exe",
    "--python-worker", protocol, "--out", verified], env=env, check=True, timeout=125)
verify = read(verified)
ids = [case["id"] for case in read(catalog)["cases"]]
assert verify["state"] == "Completed" and verify["caseCount"] == len(ids) == 6
assert verify["catalogSha256"] == sha(catalog)
identity = dict(revision=revision, imageFiles={"candidate": actual}, catalogSHA256=sha(catalog),
    protocolSHA256=sha(protocol), catalogSources=[prior.name], verifiedWorkloads=ids)
(lab / "images.json").write_text(json.dumps(identity, indent=2) + "\n", encoding="utf-8", newline="\n")
