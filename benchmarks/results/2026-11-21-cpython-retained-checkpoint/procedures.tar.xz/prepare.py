from pathlib import Path
import gzip, hashlib, json, os, shutil, subprocess, tarfile

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
prior = lab.parent / "native-only-method-lookup-20261121"
template = lab.parent / "cpython-method-invoice-20261121"
quiet = lab / "quiet"
core = "Lokad.Lython.dll"
def load(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))
def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
def emit(path, source):
    if path.suffix == ".py": compile(source, str(path), "exec")
    path.write_text(source, encoding="utf-8", newline="\n")
def save(path, value):
    emit(path, json.dumps(value, indent=2) + "\n")

source_run = prior/"quiet"
configured = load(source_run/"config.json")
verified = load(source_run/"archive-receipt.json")
assert verified["complete"] and verified["archivedAndVerifiedUnderLease"]
assert sha(source_run/"observations.tgz") == verified["archiveSHA256"]
source_files = configured["identity"]["imageFiles"]["candidate"]
source_image = prior/"frozen/candidate"
assert len(source_files)==32 and {name:sha(source_image/name) for name in source_files} == source_files
protocol = repo/"benchmarks/cpython-worker.py"
assert sha(protocol) == configured["protocolSHA256"]
revision = subprocess.check_output(["git","rev-parse","HEAD"],cwd=repo,text=True).strip()
assert revision.startswith("4337b7765")
assert revision == subprocess.check_output(["git","rev-parse","origin/master"],cwd=repo,text=True).strip()
assert not subprocess.check_output(["git","status","--porcelain"],cwd=repo)
image = lab/"frozen"
image.mkdir()
for name in source_files:
    origin = repo/"src/Lokad.Lython/bin/Release/net11.0"/name if name==core else source_image/name
    shutil.copyfile(origin,image/name)
files = {name:sha(image/name) for name in source_files}
assert [name for name in source_files if files[name] != source_files[name]] == [core]

quiet.mkdir()
manifest = quiet/"representative.json"
catalog = load(lab.parent/"current-factories-cpython/representative.json")
invoice = load(template/"quiet/representative.json")["cases"]
assert len(catalog["cases"]) == 2 and len(invoice) == 1
catalog["cases"] += invoice
save(manifest,catalog)
dotnet = Path.home()/".dotnet11/dotnet.exe"
env = dict(os.environ,DOTNET_ROOT=str(dotnet.parent),DOTNET_ROOT_X64=str(dotnet.parent),
           PATH=str(dotnet.parent)+os.pathsep+os.environ["PATH"])
proof_path = lab/"verify.json"
subprocess.run([dotnet,image/"Lokad.Lython.Benchmarks.dll","--compare","verify","--catalog",manifest,
    "--dotnet",dotnet,"--python","C:/Python313/python.exe","--python-worker",protocol,"--out",proof_path],
    env=env,check=True,timeout=95)
proof=load(proof_path)
assert proof["state"]=="Completed" and proof["caseCount"]==3 and proof["catalogSha256"]==sha(manifest)
assert {name:sha(image/name) for name in files}==files

prior_run=lab.parent/"inline-keyword-default-20261121/quiet"
archive_prefix="benchmarks/results/2026-11-21-inline-keyword-default/"
retired_root="inline-keyword-default-b1305-20261121"
archived=gzip.decompress(subprocess.check_output(["git","show","origin/master:"+archive_prefix+"candidate-core.dll.gz"],cwd=repo))
raw=subprocess.check_output(["git","show","origin/master:"+archive_prefix+"observations.tgz"],cwd=repo)
prior_receipt=load(prior_run/"archive-receipt.json")
retired_digest=load(prior_run/"identity.json")["imageFiles"]["candidate"][core]
assert hashlib.sha256(archived).hexdigest()==retired_digest
assert hashlib.sha256(raw).hexdigest()==prior_receipt["archiveSHA256"]==sha(prior_run/"observations.tgz")
retire=[dict(paths=[retired_root+"/candidate/"+core],links=1,bytes=len(archived),sha256=retired_digest,
             archives={retired_root+"/observations.tgz":prior_receipt["archiveSHA256"]},optional=False)]

identity=dict(sourceRevision=revision,productionEquivalent=revision,imageSource=revision,
              purpose="Retained factories and CSV invoice checkpoint against stock CPython",
              imageFiles=dict(candidate=files),catalogSHA256=sha(manifest),
              cpythonWorkerSHA256=sha(protocol),auxiliaryFiles={name:h for name,h in files.items() if name!=core},
              coreSHA256={label:files[core] for label in ("candidate","candidate-control")})
save(quiet/"identity.json",identity)
root="/home/lokad/lython-bench-checks/checkpoint-cpython-b1307-20261121"
unit="lython-b1307-checkpoint-cpython-20261121"
old=load(template/"quiet/config.json")
postponed="scripts.annotated-rule-closures.nested-factories.postponed"
eager="scripts.annotated-rule-closures.nested-factories"
invoice="scripts.csv-invoice.method-policy"
jobs=[(postponed,"warm"),(postponed,"compile"),(postponed,"compile-run"),(eager,"warm"),(invoice,"warm")]
assert set(case for case,_ in jobs)=={case["id"] for case in catalog["cases"]}
for name in ("collect.py","archive-owned.py","run.sh","retrieve.py"):
    original=(template/"quiet"/name).read_text(encoding="utf-8").replace(old["root"],root).replace(old["unit"],unit)
    if name=="collect.py":
        start=original.index("    for case_id,lane in ")
        stop=original.index("        assert time.monotonic()",start)
        original=original[:start]+f"    for case_id,lane in {jobs!r}:\n"+original[stop:]
    elif name=="archive-owned.py":
        original=original.replace("len(raw['jobs'])==3","len(raw['jobs'])==5").replace("jobs=3,","jobs=5,")
    elif name=="retrieve.py":
        original=original.replace("['jobs']==3","['jobs']==5")
    emit(quiet/name,original.replace("B1298","B1307"))
assert b"\r" not in (quiet/"run.sh").read_bytes()
(quiet/"candidate").mkdir()
shutil.copyfile(image/core,quiet/"candidate"/core)
assert sha(quiet/"candidate"/core)==files[core]
parts=("identity.json","representative.json","collect.py","archive-owned.py","run.sh","candidate/"+core)
payload=quiet/"payload.tgz"
with tarfile.open(payload,"w:gz") as archive:
    for name in parts: archive.add(quiet/name,arcname=name)
config=dict(root=root,unit=unit,identity=identity,source=configured["root"],sourceRole="candidate",
            sourceFiles=source_files,sourceCatalogSHA256=configured["catalogSHA256"],
            donorArchiveSHA256=verified["archiveSHA256"],catalogSHA256=identity["catalogSHA256"],
            retireGroups=retire,cpythonWorkerSHA256=identity["cpythonWorkerSHA256"],
            payloadBytes=payload.stat().st_size,payloadSHA256=sha(payload),
            unpackedBytes=sum((quiet/name).stat().st_size for name in parts))
save(quiet/"config.json",config)
original=(template/"quiet/remote-launch.py").read_text(encoding="utf-8")
start,end=original.index("\nc=")+1,original.index("\nb=Path(")
original=original[:start]+"c="+repr(config)+original[end:]
emit(quiet/"remote-launch.py",original.replace("lython-b1298-fixtures","lython-b1307-fixtures"))
emit(lab/"launch.py",(template/"launch.py").read_text(encoding="utf-8")
     .replace("B1298 method invoice delivery","B1307 checkpoint CPython").replace("210","345"))
print("Prepared five lanes. Exact checkpoint and all three CPython goldens verified.")
