# R276: native UTF16 bulk encoding

Baselineae46f502; production same43541e78/1011ed0b, correction fullCI active.
R275 UTF16 report has5.69%WriteEncodedText leaf/6.63%write state, useful/inlined
work included. Source proves manual per-scalar UTF8 decode/surrogate/unit emission
and a separate file scalar count before UTF16 sizing. This is not a CLR-string
conversion. Fixed function/frame work already avoids duplicate context creation.

Replace the writer with System.Text.Unicode.Utf8.ToUtf16 into a bounded managed
Span<char> over the already-funded destination, using memory-safe MemoryMarshal
span APIs consistent with existing inline byte representation. No Unsafe APIs,
unsafe compilation, raw pointers, PInvoke, native probing or new dependency.
Chunks stay on scalar boundaries and observe active cancellation; explicit byte
order preserves both requested encodings on either host endianness. Newline/BOM
framing stays exact. Share existing sizing's scalar counter with file write result,
without adding string fields/caches or another buffer. Remove three unused
ReserveUtf16Output/Utf16EncodedByteCount helpers; preserve real encode consumers.

Acceptance: exact native/LE/BE, BMP/supplementary Unicode, UTF8 scalar chunk
boundaries, newlines/BOM, bytes.encode and file return counts; validation before
observable effects, preflight/capacity/overlap, refusal, pending I/O cancellation,
retained aliases and joined cleanup. Existing focused Release tests on both actual
targets, then complete UTF16report and UTF8control via existing tooling. One bounded
affected/control comparison decides/refines; no speedup forecast from sample share.
Final platform/stress/package at retained-source boundary. No further call-arena,
controller, universal value, builtin sharing or compiler rewrite inferred here.
