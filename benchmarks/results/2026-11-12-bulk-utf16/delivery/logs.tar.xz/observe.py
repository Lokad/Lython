from pathlib import Path
import datetime,hashlib,io,json,subprocess,tarfile
r=Path(__file__).parent
if(r/'terminal-status.json').exists():
    print('Terminal CI state cached; not querying again.');raise SystemExit(0)
now=datetime.datetime.now(datetime.timezone.utc)
bound=datetime.datetime.fromisoformat('2026-11-12T17:32:00+00:00')
config=json.loads((r/'dispatch.json').read_text(encoding='utf-8'))
assert now>=max(bound,datetime.datetime.fromisoformat(config['doNotQueryBeforeUTC']))
done=subprocess.run(['gh','run','view',str(config['run']),'--json','status,conclusion,headSha,jobs,url'],capture_output=True,text=True,encoding='utf-8');assert done.returncode==0,done.stderr
raw=json.loads(done.stdout)
(r/('observation-'+now.strftime('%Y%m%dT%H%M%SZ')+'.json')).write_text(done.stdout,encoding='utf-8',newline='\n')
config.update(lastObservationUTC=now.isoformat(),doNotQueryBeforeUTC=(now+datetime.timedelta(minutes=5)).isoformat())
(r/'dispatch.json').write_text(json.dumps(config,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps(dict(status=raw['status'],conclusion=raw['conclusion'],jobs=[dict(name=j['name'],status=j['status'],conclusion=j['conclusion'])for j in raw['jobs']])),flush=True)
if raw['status']!='completed':raise SystemExit(0)
(r/'terminal-status.json').write_text(done.stdout,encoding='utf-8',newline='\n')
assert raw['conclusion']=='success'
head='41bd869beee1bb53880da89124d4a1e98b2105df'
assert raw['headSha']==head
frozen=r.parent/'refined/candidate-sources.tar.xz'
identity=json.loads((r.parent/'refined/candidate-identity.json').read_text(encoding='utf-8'))
sources=identity['sources'];assert len(sources)==568
archive=subprocess.run(['git','archive',head,'src/Lokad.Lython'],capture_output=True,check=True).stdout
rows=[]
normalize=lambda b:b.replace(b'\r\n',b'\n')
with tarfile.open(frozen)as f,tarfile.open(fileobj=io.BytesIO(archive))as c:
    names={m.name for m in c.getmembers()if m.isfile()and m.name.endswith('.cs')}
    assert names==set(sources),len(names)
    for name,h in sources.items():
        a=f.extractfile(name).read();b=c.extractfile(name).read()
        assert hashlib.sha256(a).hexdigest()==h,name
        assert normalize(a)==normalize(b),name
        rows.append(dict(path=name,frozenSHA256=h,committedNormalizedSHA256=hashlib.sha256(normalize(b)).hexdigest()))
(r/'source-proof.json').write_text(json.dumps(dict(head=head,sourceCount=len(rows),allMatchWithExplicitNewlineNormalization=True,sources=rows),indent=2)+'\n',encoding='utf-8',newline='\n')
done=subprocess.run(['gh','run','view',str(config['run']),'--log'],capture_output=True);assert done.returncode==0,done.stderr.decode('utf-8',errors='replace')
(r/'ci-full.log').write_bytes(done.stdout)
print('Exact committed/frozen source proof and full terminal logs saved.',flush=True)
