from pathlib import Path
import hashlib,json,shutil,tarfile
r=Path(__file__).parent
out=Path('benchmarks/results/2026-11-12-bulk-utf16/delivery');out.mkdir(exist_ok=True)
terminal=json.loads((r/'terminal-status.json').read_text(encoding='utf-8'))
assert terminal['status']=='completed'and terminal['conclusion']=='success'
proof=json.loads((r/'source-proof.json').read_text(encoding='utf-8'))
assert proof['sourceCount']==568 and proof['allMatchWithExplicitNewlineNormalization']
for name in ['terminal-status.json','source-proof.json']:shutil.copyfile(r/name,out/name)
with tarfile.open(out/'logs.tar.xz','w:xz')as t:
    for name in ['ci-full.log','observe.py','dispatch.json','archive.py']:
        t.add(r/name,arcname=name)
manifest={p.name:dict(bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())for p in out.iterdir()if p.is_file()and p.name not in ('manifest.json','README.md')}
(out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8',newline='\n')
print('Terminal logs/source proof archived; no new qualification or performance claim.')
