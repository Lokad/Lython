from pathlib import Path
import ast
import hashlib
import json
import os
import shutil
import subprocess
import tarfile

lab = Path(__file__).resolve().parent
template = lab.parent/'postponed-cpython-b1156'
pair = lab.parent/'utf8-expanded-format'
profile = lab.parent/'lowered-default-values'
donor = pair/'quiet'
core = 'Lokad.Lython.dll'
read = lambda p: p.read_text(encoding='utf-8-sig')
load = lambda p: json.loads(read(p))
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()

def write(name, source):
    if name.endswith('.py'): ast.parse(source)
    (lab/name).write_text(source,encoding='utf-8',newline='\n')

def save(name, value): write(name,json.dumps(value,ensure_ascii=False,indent=2)+'\n')

old=load(donor/'config.json')
receipt=load(donor/'archive-receipt.json')
assert receipt['complete'] and receipt['archivedAndVerifiedUnderLease'] and receipt['allWorkersJoined']
assert sha(donor/'observations.tgz')==receipt['archiveSHA256']
identity=load(pair/'frozen-identity.json')
measured=identity['candidateCommit']
retained=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
assert not subprocess.check_output(['git','status','--porcelain'])
subprocess.run(['git','diff','--exit-code',measured,retained,'--','src/Lokad.Lython.Utf8Regex','Directory.Build.props','Directory.Packages.props',
                'benchmarks/Lokad.Lython.Benchmarks','benchmarks/cpython-worker.py','global.json'],check=True)
source=pair/'frozen'/'candidate'
image=lab/'frozen/candidate'
image.mkdir(parents=True,exist_ok=True)
donor_files=identity['images']['candidate']
assert len(donor_files)==32 and donor_files==old['identity']['imageFiles']['candidate']
assert {name:sha(source/name) for name in donor_files}==donor_files
sdk=Path.home()/'.dotnet11'
dotnet=sdk/'dotnet.exe'
env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk),PATH=str(sdk)+os.pathsep+os.environ['PATH'])
subprocess.run(['git','diff','--exit-code',measured,retained,'--','src'],check=True)
files=donor_files.copy()
for name in files: shutil.copyfile(source/name,image/name)
assert {name:sha(image/name) for name in files}==files

catalog=load(pair/'catalog.json')
cases={case['id']:case for case in load(profile/'catalog.json')['cases']+catalog['cases']}
ids=['scripts.report-render.format-selectors.large','scripts.report-forwarding.expanded',
     'scripts.config-generated-guards.medium','scripts.csv-invoice.large']
assert retained.startswith('c1c15c008') and all(case in cases for case in ids)
catalog['cases']=[cases[key] for key in ids]
save('representative.json',catalog)
catalog_hash=sha(lab/'representative.json')
shutil.copyfile(donor/'cpython-worker.py',lab/'cpython-worker.py')
protocol_hash=sha(lab/'cpython-worker.py')
assert protocol_hash==old['protocolSHA256']==sha(Path('benchmarks/cpython-worker.py'))
current=dict(sourceRevision=retained,imageSource=measured,purpose='Report and generated validator scripts against CPython',
    imageFiles={'candidate':files},auxiliaryFiles={name:digest for name,digest in files.items() if name!=core},
    coreSHA256={'candidate':files[core],'candidate-control':files[core]},catalogSHA256=catalog_hash,cpythonWorkerSHA256=protocol_hash)
save('identity.json',current)
save('build-revision.json',dict(sourceRevision=retained,imageSource=measured,coreSHA256=files[core]))
with (lab/'verify.log').open('wb') as log:
    subprocess.run([dotnet,image/'Lokad.Lython.Benchmarks.dll','--compare','verify','--catalog',lab/'representative.json',
         '--dotnet',dotnet,'--python','C:/Python313/python.exe','--python-worker',lab/'cpython-worker.py',
         '--out',lab/'verify.json'],env=env,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=120)
verified=load(lab/'verify.json')
assert verified['state']=='Completed' and verified['catalogSha256']==catalog_hash

print('Four CPython goldens and the complete c1c15c008 source-identical image verified.')
