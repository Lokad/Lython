from pathlib import Path
r=Path(__file__).resolve().parent
s=(r.parent/'returned-loan-bound-r496/finish-delivery.py').read_text(encoding='utf-8')
s=s[:s.index("out=repo/")]
s=s.replace('44168196734','44187816311').replace('0d2a6ab7a9aac2c3f80e0cd0c3dc670069b07bbc','4b975a44753eeef0a07d10c715bd046501605517').replace('18021','18032').replace('2383','2385')
s+='''identity=json.loads((r/'final/frozen/identity.json').read_text(encoding='utf-8'))
with tarfile.open(r/'final/candidate-sources.tar.xz')as frozen:
 for n,data in contents.items():
  if not n.startswith('src/Lokad.Lython/'):continue
  source=frozen.extractfile(n).read()
  assert hashlib.sha256(source).hexdigest()==identity['sourceInputs'][n],n
  assert source==data or source.decode('utf-8-sig').replace('\\r\\n','\\n')==data.decode('utf-8-sig').replace('\\r\\n','\\n'),n
v['all585ProductionInputsMatchMeasuredFinal5d9633a8']=True
(d/'qualification.json').write_text(json.dumps(v,indent=2)+'\\n',encoding='utf-8')
out=repo/'benchmarks/results/2026-11-17-function-container-construction/delivery';out.mkdir(exist_ok=False)
for name in ['terminal.json','qualification.json','inputs.json','inputs.tar.xz','run-logs.zip']:shutil.copyfile(d/name,out/name)
with tarfile.open(out/'procedures.tar.xz','w:xz')as a:
 for name in ['start-delivery.py','poll-delivery.py','prepare-finish.py','finish-delivery.py']:a.add(r/name,arcname=name)
print('Full construction qualification cached and verified; compare final frozen production separately before documenting.')
'''
(r/'finish-delivery.py').write_text(s,encoding='utf-8',newline='\n')
print('Prepared exact-head verifier for16summaries/2385inputs/585production; not executed until cachedGREEN.')
