from pathlib import Path
import ast,hashlib,io,json,subprocess,tarfile
r=Path(__file__).resolve().parent;repo=Path('D:/code/Lython');old=r/'quiet';q=r/'confirm/quiet';q.mkdir(parents=True,exist_ok=False)
canonical='benchmarks/results/2026-11-17-current-cpython-checkpoint/observations.tgz'
blob=subprocess.check_output(['git','show','HEAD:'+canonical],cwd=repo);assert blob==(repo/canonical).read_bytes();subjects=[]
with tarfile.open(fileobj=io.BytesIO(blob))as archive:
    for member in ['confirmation/confirmation.json','whole-archive']:
        data=blob if member=='whole-archive'else archive.extractfile(member).read()
        subjects.append(dict(kind='completed-replica',path='representative-cpython-b919-20261117/'+('observations.tgz'if member=='whole-archive'else member),bytes=len(data),sha256=hashlib.sha256(data).hexdigest(),canonical=canonical,canonicalSHA256=hashlib.sha256(blob).hexdigest(),member=member,committedBlobVerified=True))
s=(r.parent/'json-scalars-r492/prepare-quiet.py').read_text(encoding='utf-8');a=s.index("code = '''")+len("code = '''");b=s.index("'''.replace",a)
code=s[a:b].replace('SUBJECTS',repr(subjects)).replace("else[b/'numeric-json-cost-b909-20261117/observations.tgz']","else[b/item['path']]")
code=code.replace('json-cpython-b908-20261117','container-construction-b920-20261117').replace("source/'candidate/Lokad.Lython.dll'","source/'reference/Lokad.Lython.dll'")
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
p=subprocess.run(ssh+['python3 -'],input=code,text=True,encoding='utf-8',capture_output=True,timeout=60);assert p.returncode==0,p.stdout+p.stderr;groups=json.loads(p.stdout)
(q/'retirement-proofs.json').write_text(json.dumps(groups,indent=2)+'\n',encoding='utf-8',newline='\n')
prior=json.loads((old/'config.json').read_text(encoding='utf-8'));identity=prior['identity'].copy();identity['purpose']='Bounded unchanged-image floating warm/fresh confirmation:8second rotated full-request warmups, opposite preparation roles versus B920 floating jobs; same catalog, normal GC/tiering/protocol. Preserve all original adverse results; no causal recovery or source-change claim.'
(q/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8',newline='\n')
jobs=[['scripts.numeric-squared-error.floating.large','warm'],['scripts.numeric-squared-error.floating.large','compile-run']]
s=(old/'collect.py').read_text(encoding='utf-8');a=s.index('jobs=');b=s.index('\nenv =',a);s=s[:a]+'jobs='+repr(jobs)+'\nassert len(jobs)==2 and all(case in cases for case,lane in jobs)\n'+s[b:]
s=s.replace('warmupSeconds=6','warmupSeconds=8').replace('compilationWarmupSeconds=6','compilationWarmupSeconds=8').replace('min(warmed)<6','min(warmed)<8').replace('warmed[i]>=6','warmed[i]>=8').replace('time.monotonic()-started < 300','time.monotonic()-started < 100')
(q/'collect.py').write_text(s,encoding='utf-8',newline='\n')
s=(old/'archive-owned.py').read_text(encoding='utf-8').replace("len(raw['jobs'])==7","len(raw['jobs'])==2").replace('jobs=7','jobs=2');(q/'archive-owned.py').write_text(s,encoding='utf-8',newline='\n')
remote='/home/lokad/lython-bench-checks/container-confirm-b921-20261117'
(q/'run.sh').write_text((old/'run.sh').read_text(encoding='utf-8').replace(prior['root'],remote),encoding='utf-8',newline='\n')
names=['collect.py','archive-owned.py','run.sh','identity.json']
with tarfile.open(q/'payload.tgz','w:gz')as a:
    for n in names:a.add(q/n,arcname=n)
c=dict(root=remote,unit='lython-b921-container-confirm-20261117',source=prior['root'],sourceRole='reference',sourceFiles=identity['imageFiles']['reference'],sourceCatalogSHA256=identity['catalogSHA256'],catalogSHA256=identity['catalogSHA256'],identity=identity,retireGroups=groups,payloadBytes=(q/'payload.tgz').stat().st_size,payloadSHA256=hashlib.sha256((q/'payload.tgz').read_bytes()).hexdigest(),unpackedBytes=sum((q/n).stat().st_size for n in names))
(q/'config.json').write_text(json.dumps(c,indent=2)+'\n',encoding='utf-8',newline='\n')
s=(old/'remote-launch.py').read_text(encoding='utf-8');a=s.index('c=');b=s.index('\nb=Path(',a);s=s[:a]+'c='+repr(c)+s[b:]
s=s.replace("os.link(source/c['sourceRole']/n,p)","os.link(source/role/n,p)").replace(' # Six-case catalog payload verified by both actual images and CPython goldens.'," os.link(source/'representative.json',root/'representative.json')")
s=s.replace('lython-b920-fixtures','lython-b921-fixtures').replace('RuntimeMaxSec=360','RuntimeMaxSec=160');(q/'remote-launch.py').write_text(s,encoding='utf-8',newline='\n')
s=(r/'launch.py').read_text(encoding='utf-8').replace('seconds=300','seconds=120').replace('before300seconds','before120seconds').replace('Seven-job function/container source pair','Two-job unchanged floating confirmation');(q.parent/'launch.py').write_text(s,encoding='utf-8',newline='\n')
s=(old/'retrieve.py').read_text(encoding='utf-8').replace("['jobs']==7","['jobs']==2").replace('B920','B921');(q/'retrieve.py').write_text(s,encoding='utf-8',newline='\n')
s=(r/'summarize.py').read_text(encoding='utf-8').replace("len(raw['jobs'])==7","len(raw['jobs'])==2");s=s[:s.index('reference=json.loads')];(q.parent/'summarize.py').write_text(s,encoding='utf-8',newline='\n')
for p in list(q.glob('*.py'))+[q.parent/'launch.py',q.parent/'summarize.py']:ast.parse(p.read_text(encoding='utf-8'))
print('Two unchanged-image floating jobs prepared;8second warmup/opposite preparation roles, original first-condition adversity retained. Existing images/catalog hardlinked; only exact committed B919raw replicas retired, unchanged floors.')
