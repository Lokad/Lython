from pathlib import Path
import hashlib,io,json,subprocess,tarfile
r=Path(__file__).resolve().parent;repo=Path('D:/code/Lython');subjects=[]
def committed(name):
    blob=subprocess.check_output(['git','show','HEAD:'+name],cwd=repo);assert blob==(repo/name).read_bytes();return blob
def add(path,data,canonical,member,outer):
    subjects.append(dict(paths=[path],bytes=len(data),sha256=hashlib.sha256(data).hexdigest(),canonical=canonical,canonicalSHA256=hashlib.sha256(outer).hexdigest(),member=member,committedBlobVerified=True))
name='benchmarks/results/2026-11-08-string-receivers/observations.tar.xz';blob=committed(name)
with tarfile.open(fileobj=io.BytesIO(blob))as outer:data=outer.extractfile('b441/observations.tgz').read()
add('method-binding-b441-20261108/observations.tgz',data,name,'b441/observations.tgz',blob)
with tarfile.open(fileobj=io.BytesIO(data))as a:
    add('method-binding-b441-20261108/confirmation/confirmation.json',a.extractfile('confirmation/confirmation.json').read(),name,'b441/observations.tgz!confirmation/confirmation.json',blob)
for remote,canonical,member in [
 ('cpython-checkpoint-b143-20261103/confirmation/confirmation.json','benchmarks/results/2026-11-03-wildcard-cpython-checkpoint/raw-results.tar.gz','confirmation/confirmation.json'),
 ('current-cpython-b202-20261104/confirmation/confirmation.json','benchmarks/results/2026-11-04-executable-cpython-checkpoint/observations.tgz','confirmation/confirmation.json'),
 ('range-checkpoint-b747-20261114/confirmation/confirmation.json','benchmarks/results/2026-11-14-range-cpython-checkpoint/observations.tar.xz','retrieved/confirmation/confirmation.json'),
 ('bulk-utf16-b632-20261112/confirmation/confirmation.json','benchmarks/results/2026-11-12-bulk-utf16/b632/observations.tgz','confirmation/confirmation.json')]:
    blob=committed(canonical)
    with tarfile.open(fileobj=io.BytesIO(blob))as a:data=a.extractfile(member).read()
    add(remote,data,canonical,member,blob)
canonical='benchmarks/results/2026-11-17-json-token-scan/observations.tgz';blob=committed(canonical);add('json-token-scan-b875-20261117/observations.tgz',blob,canonical,'whole-archive',blob)
code='''from pathlib import Path
import fcntl,hashlib,json,os,stat,subprocess
b=Path('/home/lokad/lython-bench-checks');subjects=SUBJECTS
with(b/'comparison-vm.lock').open('a')as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record|[p]ython3.13.*cpython-worker.py'],capture_output=True).returncode==1
 assert not any(os.path.ismount(p)for p in b.glob('*/guest-fixtures'))
 proofs=[];unmatched=[];inodes={}
 for subject in subjects:
  p=b/subject['paths'][0]
  if not p.exists():unmatched.append(subject|dict(reason='absent'));continue
  m=p.lstat();assert p.resolve()==p and p.is_relative_to(b)and stat.S_ISREG(m.st_mode)and m.st_uid==os.getuid()
  h=hashlib.sha256(p.read_bytes()).hexdigest()
  if h!=subject['sha256']or m.st_size!=subject['bytes']:unmatched.append(subject|dict(reason='different bytes; preserve',actualSHA256=h,actualBytes=m.st_size));continue
  key=(m.st_dev,m.st_ino);assert key not in inodes;inodes[key]=[]
  proofs.append(subject|dict(links=m.st_nlink))
 for base,dirs,names in os.walk(b):
  for n in names:
   p=Path(base)/n;m=p.lstat();key=(m.st_dev,m.st_ino)
   if key in inodes:inodes[key].append(str(p.relative_to(b)))
 for proof in proofs:
  p=b/proof['paths'][0];m=p.lstat();aliases=inodes[(m.st_dev,m.st_ino)]
  assert len(aliases)==m.st_nlink==proof['links'];proof['paths']=aliases
 print(json.dumps(dict(proofs=proofs,unmatched=unmatched,eligibleBytes=sum(p['bytes']for p in proofs)),indent=2))
'''.replace('SUBJECTS',repr(subjects))
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
p=subprocess.run(ssh+['python3 -'],input=code,text=True,encoding='utf-8',capture_output=True,timeout=60);assert p.returncode==0,p.stdout+p.stderr
value=json.loads(p.stdout);(r/'retirement-candidates.json').write_text(p.stdout,encoding='utf-8');print(json.dumps(dict(eligibleBytes=value['eligibleBytes'],proved=[p['paths']for p in value['proofs']],unmatched=[dict(path=p['paths'],reason=p['reason'])for p in value['unmatched']])))
assert value['eligibleBytes']>8*1024*1024,'No mutation; find another exact canonical replica before staging.'
