from pathlib import Path
import hashlib,json,os,shutil,subprocess
r=Path(__file__).resolve().parent;work=Path('D:/code/Lython/.git/agent-worktrees/record-construction-r498')
image=r/'baseline-fixture';shutil.copytree(work/'tests/Lokad.Lython.PublicApi.Tests/bin/Release/net11.0',image)
base=r.parent/'operand-transport-r497/frozen/Lokad.Lython.dll'
assert hashlib.sha256(base.read_bytes()).hexdigest().startswith('8d26963c')
shutil.copyfile(base,image/'Lokad.Lython.dll')
shutil.copyfile(work/'tests/Lokad.Lython.PublicApi.Tests/ContainerDisplayPipelineTests.cs',r/'first-ContainerDisplayPipelineTests.cs')
dotnet=Path('C:/Users/JoannesVermorel/.dotnet11/dotnet.exe');env=os.environ.copy();env.update(DOTNET_ROOT=str(dotnet.parent),DOTNET_ROOT_X64=str(dotnet.parent));env['PATH']=str(dotnet.parent)+os.pathsep+env['PATH']
with(r/'baseline-fixture.log').open('w',encoding='utf-8')as log:
 p=subprocess.run([str(dotnet),'test',str(image/'Lokad.Lython.PublicApi.Tests.dll'),'--filter','FullyQualifiedName~ContainerDisplayPipelineTests'],env=env,stdout=log,stderr=subprocess.STDOUT)
text=(r/'baseline-fixture.log').read_text(encoding='utf-8');assert p.returncode!=0 and 'Failed:     2, Passed:     5'in text,text
(r/'baseline-fixture.json').write_text(json.dumps(dict(coreSHA256=hashlib.sha256(base.read_bytes()).hexdigest(),failed=2,passed=5,reason='Public CLR projection creates snapshots; Assert.Same on two projected mutable aliases is not the guest Python identity contract. Both unmodified production and prototype fail the new assertion. Move identity assertion into the guest and assert projected values plus owner funding at public boundary.'),indent=2)+'\n',encoding='utf-8')
print('Both old production and prototype fail the new projected-identity assumption; five other new cases pass baseline.')
