from pathlib import Path
r=Path('D:/code/Lython/.git/agent-worktrees/record-construction-r498');runtime=r/'src/Lokad.Lython/Runtime'
p=r/'src/Lokad.Lython/Frontend/ExecutableScript.cs';s=p.read_text(encoding='utf-8-sig')
s=s.replace('&& EntryIndex < NativePrefixEnd\n            && SupportsNativeInstructions();','&& EntryIndex < NativePrefixEnd;')
a=s.index('    private bool SupportsNativeInstructions()');b=s.index('    private bool CrossesExceptionBoundary',a);s=s[:a]+s[b:]
a=s.index('    private static bool IsInlineInstruction(');b=s.index('\n}',a);s=s[:a]+s[b:]
p.write_text(s,encoding='utf-8',newline='\n')
p=runtime/'LythonRuntime.Executable.NativePrefix.cs';s=p.read_text(encoding='utf-8-sig')
needle='                    case ExecutableOpCode.StartFormattedString or ExecutableOpCode.AppendFormattedText'
insert='''                    case ExecutableOpCode.MakeDict:
                    {
                        var inputs = Values.Slice(instruction.InputStart, checked(2 * instruction.PairCount));
                        if (!CanConstructClosedSlotKeys(inputs, 2)) return false;
                        var dictionary = CreateSlotDictionary(inputs, _scope, instruction.Span);
                        Trim(instruction.InputStart);
                        Publish(instruction, dictionary);
                        break;
                    }
                    case ExecutableOpCode.MakeSet:
                    {
                        var inputs = Values.Slice(instruction.InputStart, instruction.ItemCount);
                        if (!CanConstructClosedSlotKeys(inputs, 1)) return false;
                        var set = CreateSlotSet(inputs, _scope, instruction.Span);
                        Trim(instruction.InputStart);
                        Publish(instruction, set);
                        break;
                    }
'''
assert needle in s;s=s.replace(needle,insert+needle)
s=s.replace('throw new InvalidOperationException($"Unexpected inline opcode: {instruction.OpCode}");','// Preserve the current PC and values. The ordinary frame\n                        // owns protocols, handlers and actual suspension.\n                        return false;')
p.write_text(s,encoding='utf-8',newline='\n')
p=runtime/'LythonRuntime.Executable.Operations.cs';s=p.read_text(encoding='utf-8-sig')
a=s.index('        var valueCount = checked(pairCount * 2);');b=s.index('\n    private static IPyContextManager',a)
s=s[:a]+'''        var dictionary = CreateSlotDictionary(stack.Values.AsSpan(start, checked(pairCount * 2)), context, span);
        stack.RetireTo(start);
        return dictionary;
    }

    private static PySet ExecuteExecutableMakeSet(ref ExecutableValueStorage stack, int start, int count, LythonSourceSpan span, ExecutionContext context)
    {
        var set = CreateSlotSet(stack.Values.AsSpan(start, count), context, span);
        stack.RetireTo(start);
        return set;
    }
''' + s[b:]
a=s.index('        var bytes = PyList.EstimateCapacityBytes(count);',s.index('    private static PyList CreateListFromStack'))
b=s.index('\n    private static PyTuple CreateTupleFromStack',a)
s=s[:a]+'''        var list = CreateSlotList(stack.Values.AsSpan(start, count), context, span);
        stack.RetireTo(start);
        return list;
    }
''' + s[b:]
p.write_text(s,encoding='utf-8',newline='\n')
p=runtime/'LythonRuntime.Executable.Slot.cs';s=p.read_text(encoding='utf-8-sig');a=s.rindex('\n}')
s=s[:a]+'''

    // Prove a closed hash/equality path without traversing composite keys or
    // invoking an earlier key's protocol out of order. Other keys hand off
    // before construction; both runners then use the same final-slot kernel.
    private static bool CanConstructClosedSlotKeys(ReadOnlySpan<ExecutableSlot> values, int stride)
    {
        for (var i = 0; i < values.Length; i += stride)
        {
            ref readonly var key = ref values[i];
            if (key.Reference is PyString or PyBytes or BigInteger or double or bool or PyNone
                || key.TryGetInteger(out _) || key.TryGetDouble(out _)) continue;
            return false;
        }
        return true;
    }

    private static PyDict CreateSlotDictionary(Span<ExecutableSlot> values,
        ExecutionContext context, LythonSourceSpan span)
    {
        // Pair count conservatively bounds final capacity, including duplicates.
        // Admission precedes allocation and key callbacks; no growth copies.
        var dictionary = new PyDict(values.Length / 2, context.MemoryGovernor, span);
        using var ambient = PyStructuralGuard.PushAmbient(context, span);
        try
        {
            for (var i = 0; i < values.Length; i += 2)
            {
                context.CheckExecution(span);
                var key = ValidateDictionaryKey(values[i].Object.RequireNotNull(), span);
                dictionary.SetItem(key, values[i + 1].Object.RequireNotNull());
            }
            context.CheckExecution(span);
            return dictionary;
        }
        catch { dictionary.DiscardUnpublishedStorage(); throw; }
    }

    private static PySet CreateSlotSet(Span<ExecutableSlot> values,
        ExecutionContext context, LythonSourceSpan span)
    {
        var set = new PySet(context.MemoryGovernor, span);
        using var ambient = PyStructuralGuard.PushAmbient(context, span);
        try
        {
            set.EnsureCapacity(values.Length);
            for (var i = 0; i < values.Length; i++)
            {
                context.CheckExecution(span);
                set.Add(ValidateSetItem(values[i].Object.RequireNotNull(), span));
            }
            context.CheckExecution(span);
            return set;
        }
        catch { set.ReleaseUnpublishedStorage(); throw; }
    }
''' + s[a:]
p.write_text(s,encoding='utf-8',newline='\n')
assert 'SupportsNativeInstructions()'not in(r/'src/Lokad.Lython/Frontend/ExecutableScript.cs').read_text(encoding='utf-8')
print('Private four-file construction/prefix prototype implemented; qualification and timing pending.')
