from pathlib import Path
import json,statistics
r=Path(__file__).resolve().parent
reference=json.loads((r/'reference-allocation.json').read_text(encoding='utf-8'));candidate=json.loads((r/'candidate-allocation.json').read_text(encoding='utf-8'));rows=[]
for a,b in zip(reference['rows'],candidate['rows']):
    assert a['id']==b['id']and a['sharedBudgetBaselineRestored']and b['sharedBudgetBaselineRestored']
    before=statistics.median(a['allocatedBytesPerInvocation']);after=statistics.median(b['allocatedBytesPerInvocation'])
    rows.append(dict(case=a['id'],referenceBytes=before,candidateBytes=after,changePercent=100*(after/before-1),referencePeak=a['peakExecutionMemoryBytes'],candidatePeak=b['peakExecutionMemoryBytes'],sharedBudgetBaselineRestored=True))
(r/'early-allocation-summary.json').write_text(json.dumps(dict(boundary=reference['boundary'],rows=rows,CPUPending=True),indent=2)+'\n',encoding='utf-8')
for row in rows:print(json.dumps(row))
