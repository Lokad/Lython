from pathlib import Path
import gzip,hashlib,json,shutil,tarfile
r=Path(__file__).resolve().parent;repo=Path('D:/code/Lython');out=repo/'benchmarks/results/2026-11-17-function-container-construction';out.mkdir(exist_ok=False);first=out/'first';first.mkdir()
status=json.loads((r/'quiet/terminal-status.json').read_text(encoding='utf-8'));assert status['exitCode']=='0'and status['receipt']['complete']and not status['remainingWorkers']and not status['remainingTrace']
assert hashlib.sha256((r/'quiet/observations.tgz').read_bytes()).hexdigest()==status['receipt']['archiveSHA256']
for n in ['summary.json','allocation-summary.json','catalog.json','candidate-sources.tar.xz','prototype.patch.gz','checks.json','final-checks.json','baseline-fixture.json']:
    shutil.copyfile(r/n,out/n)
shutil.copyfile(r/'frozen/identity.json',out/'identity.json')
for role in ['reference','candidate']:
    (out/(role+'-core.dll.gz')).write_bytes(gzip.compress((r/'frozen'/role/'Lokad.Lython.dll').read_bytes(),mtime=0))
    for kind in ['preflight','allocation']:shutil.copyfile(r/(role+'-'+kind+'.json'),out/(role+'-'+kind+'.json'))
for n in ['observations.tgz','terminal-status.json','archive-receipt.json']:shutil.copyfile(r/'quiet'/n,first/n)
with tarfile.open(out/'procedures-and-checks.tar.xz','w:xz')as a:
    for p in sorted(r.glob('*')):
        if p.is_file()and p.suffix in ['.py','.log','.json','.cs']:a.add(p,arcname=p.name)
    for p in sorted((r/'quiet').glob('*')):
        if p.is_file()and p.suffix in ['.py','.json','.sh','.log']:a.add(p,arcname='quiet/'+p.name)
summary=json.loads((r/'summary.json').read_text(encoding='utf-8'));rows=[]
for x in summary['rows']:
    e=x['elapsedChangePercent'];c=x['cpuChangePercent']
    rows.append(f"| {x['case']} | {x['lane']} | {min(e):+.2f}..{max(e):+.2f}% | {min(c):+.2f}..{max(c):+.2f}% | {x['referenceSpreadPercent']:.2f}/{x['candidateSpreadPercent']:.2f}% |")
(out/'README.md').write_text('''# Complete helper/container construction

R498/B920,2026-11-17 UTC. **Private four-file prototype; retention pending.**
Qualified runtime0d2a6ab7/frozen8d26963c (fixture-only242ca284/fullGREEN44173843690)
versus private8e738bd7 onf5064aec. Same complete copied32file images/catalog,
only core differs; native16slot ABI/fast loop/cleanup frontier retained.

Remove SupportsNativeInstructions/IsInlineInstruction's duplicate whole-code
opcode inventory. Lexical/storage admission stays; the existing native loop
hands off untouched at the actual PC when a frame/protocol/handler is needed.
Shared final-slot list/set/dict kernels replace ordinary construction loops and
serve closed dict/set returns without a general call frame. Protocol/composite
keys hand off before traversal/callback; hashing/order/identity preserved.
Reserve maximum display capacity, including duplicates, before allocation;
earlier rejection is intentional. Unpublished backing refunds on construction
or input-cleanup failure; contained aliases retain independent funding. No new
dispatcher/ABI/arena/owner/identity ledger or resource policy.

The new complete JSON-lines record transform reuses existing input/output goldens:
4,096records/110,592B, helper returns an ordinary two-field dictionary. Before,
MakeDict rejected the whole helper's native route; after, the closed call
constructs directly from final slots. Existing floating report, normalization
and positional calls are controls. This is a new useful workload shape, not a
claim that it dominates all existing scripts or explains CPython gaps.

Actual11/10 each1,191internal/4,858public focused checks pass. After final explicit
rollback catches,401internal/47public pass each (overlap), plus7new observable
semantic/ownership/refusal cases. The same7pass unchanged production. Initial
projected-CLR-identity assumption fails both images: assert Python alias identity
inside the guest and snapshot values/charged owners at the public boundary.
Keep original source/failures; no production projection contract changed. Initial
build missed a namespace import; original failed build retained. Both actual
worker images pass6goldens and allocation/reuse; no full prototype delivery yet.

| Complete script | Phase | Elapsed change | Wider CPU change | Reference/candidate spread |
| --- | --- | ---: | ---: | ---: |
'''+'\n'.join(rows)+'''

New transform allocation4,806,562→2,905,606B/invocation(−39.55%); accounted peak
6,576,643→6,576,387B. Others effectively flat; all shared allowances restore.
Record fresh improvement has close controls/supporting CPU; warm reference
movement limits magnitude. Floating fresh is adverse, with moving controls;
warm is inconclusive. Text elapsed about1%higher without supporting CPU direction.
Do not promote yet. One unchanged-image floating warm/fresh confirmation with
8second rotated warmups is justified to decide debt/refinement. Keep original
adversity; do not infer recovery or permanently close a design from uncertainty.

Seven jobs267.50seconds, quiet AzureF4as_v7/Ubuntu24.04.4/.NET11RC3,6second rotated
full-request warmups/five rounds/four processes, natural GC/tiering. All actual
image/catalog/golden/quiet/Closed/exit/join gates pass. Warm includes Run/mediated
RAM I/O/goldens/prior-result cleanup; fresh adds compile/compiled-owner disposal;
compile includes compiled-owner disposal. Startup/reset/protocol/final cache
teardown excluded; external CPU wider. No refreshed CPython ratio/startup claim.

Staging uses only exact committed old raw replicas after fresh idle lease/path/
UID/hash/nlink/all-alias proof. Different B202raw preserved. Initial read-only
space probe's8MiB estimate was insufficient; actual existing254MiB staging/252MiB
archive guards pass without changes. Qualified/current images/catalog/toolchains
remain; RAM evidence SHAarchived persistently while lease held, all workers joined.
Terminal cached. Broader performance objective active; publication postponed.

[Summary](summary.json),[allocation](allocation-summary.json),[sources](candidate-sources.tar.xz),
[patch](prototype.patch.gz),[identity](identity.json),[checks](checks.json),
[final checks](final-checks.json),[raw](first/observations.tgz),
[procedures](procedures-and-checks.tar.xz).
''',encoding='utf-8',newline='\n')
with(repo/'benchmarks/EXPERIMENTS.md').open('a',encoding='utf-8',newline='\n')as h:
    h.write('\nR498/B920 [complete function/container construction](results/2026-11-17-function-container-construction/README.md), private8e738bd7 versus qualified0d/8d26963c: four files remove whole-code opcode whitelist/duplicate display loops, share final slots/upfront capacity/actual-PC handoff;16slot ABI/fast loop retained.11/10each1,191internal/4,858public, final401/47 and7new observable cases pass(overlap);7also pass unchanged runtime.6actual goldens/allocation/reuse pass. New complete JSON-record transform alloc−39.55%, peaks~flat, fresh elapsed−20.66..−19.65%/CPU−20.68..−20%, warm−20.32..−16.54%with3.92%reference movement. Floating fresh+2.65..+10.07%/CPU+1.77..+9.70%with2.32/4.80%controls, warm inconclusive; text+0.70..+1.57%without supportingCPU, calls favorable.7jobs267.50s/all gates/join/SHAarchive/floors pass; differentB202raw preserved. Original build/projected-identity fixture failures retained. No promotion yet; bounded unchanged floating warm/fresh confirmation justified, not broad retiming. Publication held/objective active.\n')
print('First source condition/all adverse results preserved; floating confirmation/debt pending.')
