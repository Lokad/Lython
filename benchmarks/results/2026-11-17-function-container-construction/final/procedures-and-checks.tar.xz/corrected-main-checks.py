from pathlib import Path
import json,os,re,subprocess
r=Path(__file__).resolve().parent;repo=Path('D:/code/Lython');assert 'Build succeeded.'in(r/'large-callback-build.log').read_text(encoding='utf-8-sig')
dotnet=Path('C:/Users/JoannesVermorel/.dotnet11/dotnet.exe');env=os.environ.copy();env.update(DOTNET_ROOT=str(dotnet.parent),DOTNET_ROOT_X64=str(dotnet.parent));env['PATH']=str(dotnet.parent)+os.pathsep+env['PATH'];records=[]
def run(name,args):
    with(r/(name+'.log')).open('w',encoding='utf-8')as log:p=subprocess.run([str(dotnet),*args],cwd=repo,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=180)
    text=(r/(name+'.log')).read_text(encoding='utf-8');assert p.returncode==0,text
    records.append(dict(name=name,args=args,exitCode=p.returncode));(r/'corrected-main-checks.json').write_text(json.dumps(records,indent=2)+'\n',encoding='utf-8');return text
for tfm in ['net11.0','net10.0']:
    text=run('corrected-main-new-cases-'+tfm,['test','tests/Lokad.Lython.PublicApi.Tests/Lokad.Lython.PublicApi.Tests.csproj','-c','Release','-f',tfm,'--no-build','--filter','FullyQualifiedName~ContainerDisplayPipelineTests|DisplayName~json-record-transform'])
    assert 'Total:    11'in text,text;print(tfm,text.splitlines()[-1],flush=True)
for category,expected in [('Category!=Stress',18032),('Category=Stress',406)]:
    name='ordinary'if category.endswith('!=Stress')else'stress'
    text=run('corrected-public-discovery-'+name,['test','tests/Lokad.Lython.PublicApi.Tests/Lokad.Lython.PublicApi.Tests.csproj','-c','Release','-f','net11.0','--no-build','--list-tests','--filter',category])
    count=len(re.findall(r'^\s+Lokad\.Lython\.',text,re.M));assert count==expected,(count,expected)
    print(name,'public discovered',count,flush=True)
print('Exact maintained-script/newcase checks pass both targets; delivery expects public18,031ordinary/406stress, internal4,831/14.')

