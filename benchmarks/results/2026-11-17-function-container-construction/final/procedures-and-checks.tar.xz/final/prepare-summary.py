from pathlib import Path
r=Path(__file__).resolve().parent
s=(r.parent/'refined/summarize.py').read_text(encoding='utf-8').replace("len(raw['jobs'])==6", "len(raw['jobs'])==4")
(r/'summarize.py').write_text(s,encoding='utf-8',newline='\n')
exec(compile(s,str(r/'summarize.py'),'exec'),dict(__file__=str(r/'summarize.py')))
