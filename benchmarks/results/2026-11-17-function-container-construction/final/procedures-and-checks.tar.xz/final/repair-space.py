from pathlib import Path
import hashlib,json,shutil,subprocess
r=Path(__file__).resolve().parent;q=r/'quiet';repo=Path('D:/code/Lython');old=r/'first-staging-floor';old.mkdir(exist_ok=False)
for n in ['config.json','remote-launch.py','launch.log']:shutil.copyfile(q/n,old/n)
canonical='benchmarks/results/2026-11-17-function-container-construction/catalog.json';blob=subprocess.check_output(['git','show','HEAD:'+canonical],cwd=repo);assert blob==(repo/canonical).read_bytes()
subjects=[dict(kind='completed-replica',path='container-construction-b920-20261117/representative.json',bytes=len(blob),sha256=hashlib.sha256(blob).hexdigest(),canonical=canonical,canonicalSHA256=hashlib.sha256(blob).hexdigest(),member='whole-file',committedBlobVerified=True)]
s=(r.parents[1]/'json-scalars-r492/prepare-quiet.py').read_text(encoding='utf-8');a=s.index("code = '''")+len("code = '''");b=s.index("'''.replace",a)
code=s[a:b].replace('SUBJECTS',repr(subjects)).replace("else[b/'numeric-json-cost-b909-20261117/observations.tgz']","else[b/item['path']]")
code=code.replace('json-cpython-b908-20261117','container-refined-b922-20261117').replace("source/'candidate/Lokad.Lython.dll'","source/'reference/Lokad.Lython.dll'")
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
p=subprocess.run(ssh+['python3 -'],input=code,text=True,encoding='utf-8',capture_output=True,timeout=60);assert p.returncode==0,p.stdout+p.stderr
extra=json.loads(p.stdout);assert all('container-refined-b922'not in n for v in extra for n in v['paths'])
c=json.loads((q/'config.json').read_text(encoding='utf-8'));c['retireGroups']+=extra
(q/'config.json').write_text(json.dumps(c,indent=2)+'\n',encoding='utf-8',newline='\n')
s=(q/'remote-launch.py').read_text(encoding='utf-8-sig');a=s.index('c=');b=s.index('\nb=Path(',a);s=s[:a]+'c='+repr(c)+s[b:];(q/'remote-launch.py').write_text(s,encoding='utf-8',newline='\n')
(q/'launch.log').rename(old/'original-launch.log')
(r/'staging-correction.json').write_text(json.dumps(dict(originalRefusedBeforeMutation=True,spaceGuardUnchanged=True,extraExactDuplicateCatalogAliases=extra,currentB922CatalogPreserved=True,retiredOnlyCommittedReplicas=True),indent=2)+'\n',encoding='utf-8')
print('Exact retired-catalog aliases proved; current donor catalog retained, floor unchanged.')
