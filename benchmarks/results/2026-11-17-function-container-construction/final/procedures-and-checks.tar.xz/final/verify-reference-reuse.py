from pathlib import Path
import hashlib,json
r=Path(__file__).resolve().parent
current=json.loads((r/'frozen/identity.json').read_text(encoding='utf-8'));prior=json.loads((r.parent/'refined/frozen/identity.json').read_text(encoding='utf-8'))
assert current['imageFiles']['reference']==prior['imageFiles']['reference']
assert current['catalogSHA256']==prior['catalogSHA256']==hashlib.sha256((r/'catalog.json').read_bytes()).hexdigest()
assert all(hashlib.sha256((r/'frozen/reference'/n).read_bytes()).hexdigest()==h for n,h in current['imageFiles']['reference'].items())
(r/'reference-reuse.json').write_text(json.dumps(dict(all32ReferenceFilesAndCatalogByteIdentical=True,reusedGoldensAndAllocationFrom='R498refined/reference',candidateNewlyVerified=True),indent=2)+'\n',encoding='utf-8')
print('Reused reference evidence proven against all32actual file hashes/catalog, not inferred from source.')
