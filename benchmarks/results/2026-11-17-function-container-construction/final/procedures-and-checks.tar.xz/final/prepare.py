from pathlib import Path
import ast,json
r=Path(__file__).resolve().parent
s=(r.parent/'refined/prepare-exact.py').read_text(encoding='utf-8')
core=json.loads((r/'frozen/identity.json').read_text(encoding='utf-8'))['imageFiles']['candidate']['Lokad.Lython.dll']
s=s.replace('cold-constructionR498/29964188','corrected-mainR498/'+core[:8])
a=s.index('jobs=');b=s.index('\ns=',a)
jobs=[['scripts.json-record-transform.large','warm'],['scripts.json-record-transform.large','compile-run'],['scripts.numeric-squared-error.floating.large','warm'],['scripts.numeric-squared-error.floating.large','compile-run']]
s=s[:a]+'jobs='+repr(jobs)+s[b:]
s=s.replace('len(jobs)==6','len(jobs)==4').replace('len(raw[\'jobs\'])==6','len(raw[\'jobs\'])==4').replace('jobs=6','jobs=4').replace("['jobs']==6","['jobs']==4")
# Existing source files have7jobs; retain the input selector, change only output4.
s=s.replace('time.monotonic()-started < 240','time.monotonic()-started < 180')
s=s.replace("remote='/home/lokad/lython-bench-checks/container-refined-b922-20261117'","remote='/home/lokad/lython-bench-checks/container-final-b923-20261117'")
s=s.replace("unit='lython-b922-container-refined-20261117'","unit='lython-b923-container-final-20261117'")
s=s.replace("source='/home/lokad/lython-bench-checks/container-construction-b920-20261117'","source='/home/lokad/lython-bench-checks/container-refined-b922-20261117'")
s=s.replace("shutil.copyfile(r/'catalog.json',q/'representative.json')", "assert f['catalogSHA256']==json.loads((old/'refined/quiet/config.json').read_text(encoding='utf-8'))['catalogSHA256']")
s=s.replace("'identity.json','representative.json','candidate/Lokad.Lython.dll'", "'identity.json','candidate/Lokad.Lython.dll'")
s=s.replace("' # Six-case catalog payload verified by both actual images and CPython goldens.'",'" os.link(source/\'representative.json\',root/\'representative.json\')"')
s=s.replace("'lython-b920-fixtures','lython-b922-fixtures'","'lython-b920-fixtures','lython-b923-fixtures'")
s=s.replace("'RuntimeMaxSec=360','RuntimeMaxSec=300'","'RuntimeMaxSec=360','RuntimeMaxSec=240'")
s=s.replace('seconds=260','seconds=200').replace('before260seconds','before200seconds').replace('Six-job refined function/container source pair','Four-job corrected integration source pair')
s=s.replace("'B920','B922'","'B920','B923'")
ast.parse(s);(r/'prepare-exact.py').write_text(s,encoding='utf-8',newline='\n')
exec(compile(s,str(r/'prepare-exact.py'),'exec'),dict(__file__=str(r/'prepare-exact.py')))
for name in ['archive-owned.py','retrieve.py']:
    text=(r/'quiet'/name).read_text(encoding='utf-8')
    assert "jobs']==4"in text or 'jobs=4'in text,(name,text)
launcher=r/'quiet/remote-launch.py'
text=launcher.read_text(encoding='utf-8')
catalogLink=" os.link(source/'representative.json',root/'representative.json')"
if catalogLink not in text:
    cpLink=" os.link(source/'cpython-worker.py',root/'cpython-worker.py')"
    assert cpLink in text
    text=text.replace(cpLink,cpLink+'\n'+catalogLink)
    launcher.write_text(text,encoding='utf-8',newline='\n')
