from pathlib import Path
import json,os,subprocess
r=Path(__file__).resolve().parent;repo=Path('D:/code/Lython');dotnet=Path('C:/Users/JoannesVermorel/.dotnet11/dotnet.exe');env=os.environ.copy();env.update(DOTNET_ROOT=str(dotnet.parent),DOTNET_ROOT_X64=str(dotnet.parent));env['PATH']=str(dotnet.parent)+os.pathsep+env['PATH']
rows=[]
for label,category,delta,knownRuntime in [('ordinary','Category!=Stress',4,18028),('stress','Category=Stress',0,406)]:
    counts={}
    for role in ['baseline','current']:
        path=r/('discovery-'+label+'-'+role+'.log')
        if role=='current'and label=='ordinary':text=(r/'corrected-public-discovery-ordinary.log').read_text(encoding='utf-8')
        else:
            assembly=r/'baseline-fixture/Lokad.Lython.PublicApi.Tests.dll'if role=='baseline'else repo/'tests/Lokad.Lython.PublicApi.Tests/bin/Release/net11.0/Lokad.Lython.PublicApi.Tests.dll'
            with path.open('w',encoding='utf-8')as log:p=subprocess.run([str(dotnet),'test',str(assembly),'--list-tests','--filter',category],env=env,stdout=log,stderr=subprocess.STDOUT,timeout=60)
            assert p.returncode==0; text=path.read_text(encoding='utf-8')
        assert 'The following Tests are available:'in text
        counts[role]=sum(line.startswith('    ')for line in text.split('The following Tests are available:',1)[1].splitlines())
    assert counts['current']-counts['baseline']==delta,(label,counts,delta)
    rows.append(dict(category=label,discovered=counts,addedRuntimeCases=delta,baselineRuntimeCases=knownRuntime,expectedRuntimeCases=knownRuntime+delta))
(r/'discovery-delta.json').write_text(json.dumps(dict(rows=rows,limitation='Discovery does not expand deferred theories; absolute discovered count is not executed count. Compare unchanged source baseline with7new cases against current baseline+large-callback1+maintained-script3. Full CI must verify actual executed totals.',previousDiagnosticFailedBeforeTests=False),indent=2)+'\n',encoding='utf-8')
print(json.dumps(rows));print('Full CI expected public18,032ordinary/406stress; discovery delta4/0 verified, deferred theory counts not relabelled.')
