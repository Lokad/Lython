from pathlib import Path
import json,re
r=Path(__file__).resolve().parent;out=[]
for role in ['reference','candidate']:
    text=(r/(role+'-jit.txt')).read_text(encoding='utf-8-sig')
    for match in re.finditer(r'; Assembly listing for method (.*?)\n(.*?); Total bytes of code (\d+)',text,re.S):
        header,body,size=match.groups()
        if 'NativeExecution:RunCore'not in header and 'PyExecutableFunction:StartInline'not in header and 'PyExecutableFunction:StartNativeCall'not in header:continue
        alloc=re.search(r'sub\s+rsp,\s+(0x[0-9A-Fa-f]+|\d+)',body)
        out.append(dict(role=role,method=header,codeBytes=int(size),initialStackSubtraction=int(alloc[1],0)if alloc else 0))
(r/'codegen-summary.json').write_text(json.dumps(dict(purpose='Windows11 JIT diagnostic on actual images; no Linux causal or portable CPU claim.',rows=out),indent=2)+'\n',encoding='utf-8')
for x in out:
    if 'Tier1'in x['method']:print(json.dumps(x))
