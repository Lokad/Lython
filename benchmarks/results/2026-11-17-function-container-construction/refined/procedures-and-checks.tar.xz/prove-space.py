from pathlib import Path
import gzip,hashlib,io,json,subprocess,tarfile
r=Path(__file__).resolve().parent;repo=Path('D:/code/Lython');subjects=[]
name='benchmarks/results/2026-11-17-function-container-construction/candidate-core.dll.gz';blob=subprocess.check_output(['git','show','HEAD:'+name],cwd=repo);assert blob==(repo/name).read_bytes();data=gzip.decompress(blob)
subjects.append(dict(kind='superseded-core',sha256=hashlib.sha256(data).hexdigest(),bytes=len(data),canonical=name,canonicalSHA256=hashlib.sha256(blob).hexdigest(),member='gzip-payload',committedBlobVerified=True))
for suffix,remote in [('first','container-construction-b920-20261117'),('confirmation','container-confirm-b921-20261117')]:
    name='benchmarks/results/2026-11-17-function-container-construction/'+suffix+'/observations.tgz';blob=subprocess.check_output(['git','show','HEAD:'+name],cwd=repo);assert blob==(repo/name).read_bytes()
    with tarfile.open(fileobj=io.BytesIO(blob))as a:
        for member in ['confirmation/confirmation.json','whole-archive']:
            data=blob if member=='whole-archive'else a.extractfile(member).read()
            subjects.append(dict(kind='completed-replica',path=remote+'/'+('observations.tgz'if member=='whole-archive'else member),bytes=len(data),sha256=hashlib.sha256(data).hexdigest(),canonical=name,canonicalSHA256=hashlib.sha256(blob).hexdigest(),member=member,committedBlobVerified=True))
s=(r.parents[1]/'json-scalars-r492/prepare-quiet.py').read_text(encoding='utf-8');a=s.index("code = '''")+len("code = '''");b=s.index("'''.replace",a)
code=s[a:b].replace('SUBJECTS',repr(subjects)).replace("else[b/'numeric-json-cost-b909-20261117/observations.tgz']","else[b/item['path']]")
code=code.replace('json-cpython-b908-20261117','container-construction-b920-20261117').replace("source/'candidate/Lokad.Lython.dll'","source/'reference/Lokad.Lython.dll'")
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
p=subprocess.run(ssh+['python3 -'],input=code,text=True,encoding='utf-8',capture_output=True,timeout=60);assert p.returncode==0,p.stdout+p.stderr
proofs=json.loads(p.stdout);out=dict(proofs=proofs,eligibleBytes=sum(p['bytes']for p in proofs),firstSourcesAndAllAdversityCommitted=True)
(r/'retirement-candidates.json').write_text(json.dumps(out,indent=2)+'\n',encoding='utf-8')
print(json.dumps(dict(eligibleBytes=out['eligibleBytes'],groups=len(proofs),originalCoreAliases=proofs[0]['paths'])))
