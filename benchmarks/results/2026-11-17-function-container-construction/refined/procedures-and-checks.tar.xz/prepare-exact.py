from pathlib import Path
import ast,hashlib,json,re,shutil,tarfile
r=Path(__file__).resolve().parent;old=r.parent;prior=r.parent.parent/'operand-transport-r497';q=r/'quiet';q.mkdir(exist_ok=False)
f=json.loads((r/'frozen/identity.json').read_text(encoding='utf-8'));base=json.loads((prior/'identity.json').read_text(encoding='utf-8'))
assert all(hashlib.sha256((r/'frozen'/role/n).read_bytes()).hexdigest()==h for role,files in f['imageFiles'].items()for n,h in files.items())
proof=json.loads((r/'retirement-candidates.json').read_text(encoding='utf-8'))
groups=proof['proofs'];assert proof['eligibleBytes']==sum(v['bytes']for v in groups)
identity=dict(sourceRevision='Committed0d2a6ab7/8d26963c versus cold-constructionR498/29964188 onf5064aec; actual-opcode native admission and final slot-based container construction',purpose='One complete helper/container construction milestone: remove whole-code opcode whitelist, use actual-PC handoff, shared final list/set/dict kernels and upfront capacity; no new ABI/owner/dispatcher. New JSON-record transform plus existing floating/text/call controls. Compile/warm/compile-to-result separate; no predicted gain.',coreSHA256={role:f['imageFiles']['candidate'if role.startswith('candidate')else'reference']['Lokad.Lython.dll']for role in ['reference','reference-control','candidate','candidate-control']},imageFiles=f['imageFiles'],auxiliaryFiles=base['auxiliaryFiles'],sourceInputsArchiveSHA256=hashlib.sha256((r/'candidate-sources.tar.xz').read_bytes()).hexdigest(),productionFiles=585,catalogSHA256=f['catalogSHA256'],normalAdapterPin='0.4.0',publicationHeld=True)
(q/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8',newline='\n')
jobs=[['scripts.json-record-transform.large', 'warm'], ['scripts.json-record-transform.large', 'compile-run'], ['scripts.numeric-squared-error.floating.large', 'warm'], ['scripts.numeric-squared-error.floating.large', 'compile-run'], ['scripts.text-normalization.large', 'warm'], ['calls.positional.large', 'warm']]
s=(old/'quiet/collect.py').read_text(encoding='utf-8');a=s.index('jobs=');b=s.index('\nenv =',a);s=s[:a]+'jobs='+repr(jobs)+'\nassert len(jobs)==6 and all(case in cases for case,lane in jobs)\n'+s[b:]
s=re.sub(r'time.monotonic\(\)-started < \d+', 'time.monotonic()-started < 240',s)
(q/'collect.py').write_text(s,encoding='utf-8',newline='\n')
s=(old/'quiet/archive-owned.py').read_text(encoding='utf-8').replace("len(raw['jobs'])==7","len(raw['jobs'])==6").replace('jobs=7','jobs=6');(q/'archive-owned.py').write_text(s,encoding='utf-8',newline='\n')
remote='/home/lokad/lython-bench-checks/container-refined-b922-20261117'
oldconfig=json.loads((old/'quiet/config.json').read_text(encoding='utf-8'))
(q/'run.sh').write_text((old/'quiet/run.sh').read_text(encoding='utf-8').replace(oldconfig['root'],remote),encoding='utf-8',newline='\n')
(q/'candidate').mkdir();shutil.copyfile(r/'frozen/candidate/Lokad.Lython.dll',q/'candidate/Lokad.Lython.dll');shutil.copyfile(r/'catalog.json',q/'representative.json')
names=['collect.py','archive-owned.py','run.sh','identity.json','representative.json','candidate/Lokad.Lython.dll']
with tarfile.open(q/'payload.tgz','w:gz')as a:
    for n in names:a.add(q/n,arcname=n)
c=dict(root=remote,unit='lython-b922-container-refined-20261117',source='/home/lokad/lython-bench-checks/container-construction-b920-20261117',sourceRole='reference',sourceFiles=base['imageFiles']['candidate'],sourceCatalogSHA256=f['catalogSHA256'],catalogSHA256=f['catalogSHA256'],identity=identity,retireGroups=groups,payloadBytes=(q/'payload.tgz').stat().st_size,payloadSHA256=hashlib.sha256((q/'payload.tgz').read_bytes()).hexdigest(),unpackedBytes=sum((q/n).stat().st_size for n in names))
(q/'config.json').write_text(json.dumps(c,indent=2)+'\n',encoding='utf-8',newline='\n')
s=(old/'quiet/remote-launch.py').read_text(encoding='utf-8');a=s.index('c=');b=s.index('\nb=Path(',a);s=s[:a]+'c='+repr(c)+s[b:]
s=s.replace(" os.link(source/'representative.json',root/'representative.json')",' # Six-case catalog payload verified by both actual images and CPython goldens.')
s=s.replace('lython-b920-fixtures','lython-b922-fixtures').replace('RuntimeMaxSec=360','RuntimeMaxSec=300');(q/'remote-launch.py').write_text(s,encoding='utf-8',newline='\n')
s=(prior/'launch.py').read_text(encoding='utf-8').replace('seconds=500','seconds=260').replace('before500seconds','before260seconds').replace('Twelve-job representative CPython checkpoint','Six-job refined function/container source pair');(r/'launch.py').write_text(s,encoding='utf-8',newline='\n')
s=(old/'quiet/retrieve.py').read_text(encoding='utf-8').replace("['jobs']==7","['jobs']==6").replace('B920','B922');(q/'retrieve.py').write_text(s,encoding='utf-8',newline='\n')
s=(old/'summarize.py').read_text(encoding='utf-8').replace("len(raw['jobs'])==7","len(raw['jobs'])==6");(r/'summarize.py').write_text(s,encoding='utf-8',newline='\n')
for p in list(q.glob('*.py'))+[r/'launch.py',r/'summarize.py']:ast.parse(p.read_text(encoding='utf-8'))
print(json.dumps(dict(jobs=jobs,unpackedBytes=c['unpackedBytes'],canonicalBackedReplicaBytes=proof['eligibleBytes'],preservedDifferentB202Bytes=True,stagingFloorMiB=254,archiveFloorMiB=252,sourcePairOnly=True)))
