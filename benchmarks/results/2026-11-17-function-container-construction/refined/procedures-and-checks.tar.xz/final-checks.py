from pathlib import Path
import hashlib,json,os,shutil,subprocess
r=Path(__file__).resolve().parent;work=Path('D:/code/Lython/.git/agent-worktrees/record-construction-r498')
assert 'Build succeeded.'in(r/'final-build.log').read_text(encoding='utf-8-sig')
dotnet=Path('C:/Users/JoannesVermorel/.dotnet11/dotnet.exe');env=os.environ.copy();env.update(DOTNET_ROOT=str(dotnet.parent),DOTNET_ROOT_X64=str(dotnet.parent));env['PATH']=str(dotnet.parent)+os.pathsep+env['PATH'];records=[]
filters={'internal':['Executable','NativeFunctionRefund','CasedSplitOwnership','CallablePacketOwnership','SequenceConstructionOwnership'], 'public':['ContainerDisplayPipeline','BufferedGeneratorContinuation','NativeReceiverPipeline','HelperLocalLifetime','ProtectedHelperExecution','BuiltinCancellation','RepresentativeProtocolCancellation']}
for tfm in ['net11.0','net10.0']:
    for kind,parts in filters.items():
        project='Lokad.Lython.Tests'if kind=='internal'else'Lokad.Lython.PublicApi.Tests'
        filt='('+'|'.join('FullyQualifiedName~'+p for p in parts)+')&Category!=Stress'
        cmd=[str(dotnet),'test',f'tests/{project}/{project}.csproj','-c','Release','-f',tfm,'--no-build','--filter',filt]
        path=r/('final-'+kind+'-'+tfm+'.log')
        with path.open('w',encoding='utf-8')as log:p=subprocess.run(cmd,cwd=work,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=180)
        records.append(dict(kind=kind,framework=tfm,command=cmd,exitCode=p.returncode));(r/'final-checks.json').write_text(json.dumps(records,indent=2)+'\n',encoding='utf-8')
        text=path.read_text(encoding='utf-8');assert p.returncode==0,text;print(kind,tfm,text.splitlines()[-1],flush=True)

