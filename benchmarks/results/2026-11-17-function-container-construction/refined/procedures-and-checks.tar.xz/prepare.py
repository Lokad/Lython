from pathlib import Path
import ast,json
r=Path(__file__).resolve().parent
s=(r.parent/'prepare-quiet.py').read_text(encoding='utf-8')
s=s.replace("old=r.parent/'completed-runner-r495/flat-operations';prior=r.parent/'operand-transport-r497'","old=r.parent;prior=r.parent.parent/'operand-transport-r497'")
core=json.loads((r/'frozen/identity.json').read_text(encoding='utf-8'))['imageFiles']['candidate']['Lokad.Lython.dll']
s=s.replace('privateR498/8e738bd7','cold-constructionR498/'+core[:8])
s=s.replace('same construction milestone', 'same refined construction milestone')
a=s.index('jobs=');b=s.index('\ns=',a)
jobs=[['scripts.json-record-transform.large','warm'],['scripts.json-record-transform.large','compile-run'],['scripts.numeric-squared-error.floating.large','warm'],['scripts.numeric-squared-error.floating.large','compile-run'],['scripts.text-normalization.large','warm'],['calls.positional.large','warm']]
s=s[:a]+'jobs='+repr(jobs)+s[b:]
s=s.replace('len(jobs)==7','len(jobs)==6').replace('len(raw[\'jobs\'])==7','len(raw[\'jobs\'])==6').replace('jobs=7','jobs=6')
s=s.replace('time.monotonic()-started < 300','time.monotonic()-started < 240')
s=s.replace("remote='/home/lokad/lython-bench-checks/container-construction-b920-20261117'","remote='/home/lokad/lython-bench-checks/container-refined-b922-20261117'")
s=s.replace("unit='lython-b920-container-construction-20261117'","unit='lython-b922-container-refined-20261117'")
s=s.replace("source='/home/lokad/lython-bench-checks/representative-cpython-b919-20261117',sourceRole='candidate'","source='/home/lokad/lython-bench-checks/container-construction-b920-20261117',sourceRole='reference'")
s=s.replace("sourceCatalogSHA256=base['catalogSHA256']","sourceCatalogSHA256=f['catalogSHA256']")
s=s.replace("'lython-b918-fixtures','lython-b920-fixtures'","'lython-b920-fixtures','lython-b922-fixtures'")
s=s.replace("'RuntimeMaxSec=300','RuntimeMaxSec=360'","'RuntimeMaxSec=360','RuntimeMaxSec=300'")
s=s.replace('seconds=300','seconds=260').replace('before300seconds','before260seconds').replace('Seven-job function/container source pair','Six-job refined function/container source pair')
s=s.replace("['jobs']==7","['jobs']==6").replace("len(raw['jobs'])==7","len(raw['jobs'])==6").replace("'B918','B920'","'B920','B922'")
s=s.replace("len(raw['jobs'])==5", "len(raw['jobs'])==7").replace("['jobs']==5", "['jobs']==7").replace('jobs=5', 'jobs=7')
ast.parse(s);(r/'prepare-exact.py').write_text(s,encoding='utf-8',newline='\n')
exec(compile(s,str(r/'prepare-exact.py'),'exec'),dict(__file__=str(r/'prepare-exact.py')))
