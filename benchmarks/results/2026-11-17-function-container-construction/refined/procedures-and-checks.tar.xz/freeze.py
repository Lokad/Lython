from pathlib import Path
import copy,gzip,hashlib,json,os,shutil,subprocess,tarfile
r=Path(__file__).resolve().parent;repo=Path('D:/code/Lython');work=repo/'.git/agent-worktrees/record-construction-r498';prior=r.parent.parent/'operand-transport-r497'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert 'Build succeeded.'in(r/'final-build.log').read_text(encoding='utf-8-sig')
base=json.loads((prior/'identity.json').read_text(encoding='utf-8'));frozen=r/'frozen';frozen.mkdir(exist_ok=False)
images={}
for role in ['reference','candidate']:
    image=frozen/role;image.mkdir()
    for n,h in base['imageFiles']['candidate'].items():
        assert sha(prior/'frozen'/n)==h,n
        shutil.copyfile(prior/'frozen'/n,image/n)
    if role=='candidate':shutil.copyfile(work/'src/Lokad.Lython/bin/Release/net11.0/Lokad.Lython.dll',image/'Lokad.Lython.dll')
    images[role]={n:sha(image/n)for n in base['imageFiles']['candidate']}
    for p in(r.parent.parent/'json-scalars-r492/frozen/reference').glob('ValidatedAllocation.*'):shutil.copyfile(p,image/p.name)
assert [n for n in images['reference']if images['reference'][n]!=images['candidate'][n]]==['Lokad.Lython.dll']
catalog=json.loads((prior/'representative.json').read_text(encoding='utf-8'));original=next(v for v in catalog['cases']if v['id']=='scripts.json-summary-helpers.large');case=copy.deepcopy(original)
case['id']='scripts.json-record-transform.large'
source=original['source'].replace("def record_amount(record:dict)->int:\n    return record['amount']", "def transform(record:dict)->dict:\n    return {'kind':record['kind'],'amount':record['amount']}")
source=source.replace('amount = record_amount(record)',"record = transform(record)\n            amount = record['amount']")
assert 'record_amount'not in source and "return {'kind':record['kind'],'amount':record['amount']}"in source
compile(source,'trusted-record-transform','exec')
case.update(source=source,sourceUtf8Bytes=len(source.encode('utf-8')),sourceSha256=hashlib.sha256(source.encode('utf-8')).hexdigest())
catalog['cases'].append(case)
(r/'catalog.json').write_text(json.dumps(catalog,indent=2,ensure_ascii=False)+'\n',encoding='utf-8',newline='\n')
oldinputs=json.loads((prior/'delivery/inputs.json').read_text(encoding='utf-8'))
newtest='tests/Lokad.Lython.PublicApi.Tests/ContainerDisplayPipelineTests.cs';names=sorted(list(oldinputs['inputs'])+[newtest]);assert len(names)==2384
inputs={n:sha(work/n)for n in names}
with tarfile.open(r/'candidate-sources.tar.xz','w:xz')as a:
    for n in inputs:a.add(work/n,arcname=n)
changed=subprocess.check_output(['git','diff','--name-only'],cwd=work,text=True).splitlines()
assert len(changed)==4 and all(n.startswith('src/Lokad.Lython/')for n in changed),changed
(r/'prototype.patch.gz').write_bytes(gzip.compress(subprocess.check_output(['git','diff','--']+changed,cwd=work),mtime=0))
identity=dict(referenceSource='Committed0d2a6ab7/frozen8d26963c; production unchanged by242ca284 fixture correction, delivery44173843690 independently pending',candidateSource='Private refined four-file R498 onf5064aec: cold container handling/publication and explicit unpublished rollback; same actual-PC admission/shared final kernels/upfront capacity/16slot ABI',imageFiles=images,sourceInputs=inputs,productionFiles=585,changedProductionFiles=changed,newObservableTest=newtest,catalogSHA256=sha(r/'catalog.json'),normalAdapterPin='0.4.0',publicationHeld=True)
(frozen/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8',newline='\n')
dotnet=Path('C:/Users/JoannesVermorel/.dotnet11/dotnet.exe');env=os.environ.copy();env.update(DOTNET_ROOT=str(dotnet.parent),DOTNET_ROOT_X64=str(dotnet.parent));env['PATH']=str(dotnet.parent)+os.pathsep+env['PATH']
for role in ['reference','candidate']:
    image=frozen/role
    commands=[('preflight',[str(dotnet),str(image/'Lokad.Lython.Benchmarks.dll'),'--compare','verify','--catalog',str(r/'catalog.json'),'--dotnet',str(dotnet),'--python','C:/Python313/python.exe','--python-worker',str(repo/'benchmarks/cpython-worker.py'),'--out',str(r/(role+'-preflight.json'))]),('allocation',[str(dotnet),str(image/'ValidatedAllocation.dll'),str(image),str(r/'catalog.json'),str(r/(role+'-allocation.json'))])]
    for label,cmd in commands:
        with(r/(role+'-'+label+'.log')).open('w',encoding='utf-8')as log:p=subprocess.run(cmd,env=env,stdout=log,stderr=subprocess.STDOUT)
        assert p.returncode==0,(r/(role+'-'+label+'.log')).read_text(encoding='utf-8');print(role,label,'pass',flush=True)
print('Six actual worker goldens and allocation/reuse checks pass on both complete copied images:',images['candidate']['Lokad.Lython.dll'])

