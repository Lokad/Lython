from pathlib import Path
import hashlib
import json
import os
import shutil
import subprocess
from textwrap import dedent

lab = Path(__file__).resolve().parent
source = Path('.git/agent-worktrees/single-lexical-class-cells/tools/LythonProbe/bin/Release/net11.0')
baseline = lab.parent/'format-continuation-scratch'
pair = json.loads((baseline/'frozen-identity.json').read_text(encoding='utf-8-sig'))
expected = pair['images']['candidate']
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
assert len(expected)==32 and {n:sha(baseline/'frozen/candidate'/n) for n in expected}==expected
cases = {
    'default-in-nested-class-body': '''
        class C:
            def make(self):
                class D:
                    def value(self, owner=__class__):
                        return owner, __class__
                return D
        D=C().make()
        print(D().value()[0] is C,D().value()[1] is D)
    ''',
    'sibling-class-shadow': '''
        class C:
            def make(self):
                class D:
                    def value(self):return __class__
                return D, '__class__' in locals()
        D, captured=C().make()
        print(D().value() is D,captured)
    ''',
    'local-enclosing-cell': '''
        class C:
            def make(self):
                __class__='local'
                def value():return __class__
                return value
        print(C().make()())
    ''',
    'direct-lazy-class-alias': '''
        class C:
            type Owner=__class__
        print(C.Owner.__value__ is C)
    ''',
    'method-lazy-class-alias': '''
        class C:
            def get(self):
                type Owner=__class__
                return Owner
        print(C().get().__value__ is C)
    ''',
    'type-bound-class-cell': '''
        class C:
            def identify[T: __class__](self):return T
        print(C.identify.__type_params__[0].__bound__ is C,C().identify() is C.identify.__type_params__[0])
    ''',
    'eager-comp-super-shadow': '''
        class C:
            def values(self):
                pairs=[super for __class__ in [1]]
                return '__class__' in locals(), len(pairs)
        print(C().values())
    ''',
    'postponed-lambda-class': '''
        from __future__ import annotations
        class C:
            def take(self, value: (lambda: __class__)):
                return value, '__class__' in locals()
        print(C().take(7),C.take.__annotations__)
    ''',
    'nested-class-reads-outer-class': '''
        __class__='global'
        class C:
            def make(self):
                class B:
                    actual=__class__
                    def owner(self):return __class__
                return B
        B=C().make()
        print(B.actual is C,B().owner() is B)
    ''',
    'eager-comp-in-nested-class': '''
        __class__='global'
        class C:
            def make(self):
                class B:
                    reader=[__class__ for _ in [1]]
                return B.reader[0]=='global','__class__' in locals()
        print(C().make())
    ''',
    'class-reference-in-pattern': '''
        class C:
            constant=7
            def identify(self,item):
                match item:
                    case __class__.constant: return 'yes'
                    case _: return 'no'
        try:print(C().identify(7),C().identify(8))
        except Exception as e:print(type(e).__name__)
    ''',
    'dead-read-still-captures': '''
        class C:
            def f(self):
                if False: print(__class__)
                return locals().get('__class__') is C
        print(C().f())
    ''',
}
old=json.loads((lab.parent/'eager-expression-qualification/probe-cases.json').read_text(encoding='utf-8-sig'))
cases.update({f'eager-expression-{i}':case for i,case in enumerate(old,1)})
cases={name:dedent(case) for name,case in cases.items()}
data=json.dumps(list(cases.values())).encode('utf-8')
(lab/'probe-cases.json').write_text(json.dumps(cases,indent=2)+'\n',encoding='utf-8')
sdk=Path.home()/'.dotnet11'
env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk),PATH=str(sdk)+os.pathsep+os.environ['PATH'])
for role in ('reference','candidate'):
    image = lab/'probe'/role
    shutil.copytree(source,image,dirs_exist_ok=True)
    if role=='reference':
        shutil.copyfile(baseline/'frozen/candidate/Lokad.Lython.dll',image/'Lokad.Lython.dll')
        assert sha(image/'Lokad.Lython.dll')==expected['Lokad.Lython.dll']
    for asynchronous in (False,True):
        cmd=[sdk/'dotnet.exe',image/'LythonProbe.dll','--batch-json','--compare-python','--python','C:/Python313/python.exe']
        if asynchronous: cmd.append('--async')
        p=subprocess.run(cmd,input=data,capture_output=True,timeout=55,env=env)
        (lab/f'probe-{role}-{asynchronous}.jsonl').write_bytes(p.stdout)
        rows=[json.loads(line) for line in p.stdout.splitlines()]
        print(role,asynchronous,p.returncode,len(rows),sha(image/'Lokad.Lython.dll'))
        assert len(rows)==len(cases), p.stderr.decode()
        for name,row in zip(cases,rows,strict=True):
            if not (row.get('Matches') and row.get('Compared')):
                print(name,json.dumps(row,ensure_ascii=False))
