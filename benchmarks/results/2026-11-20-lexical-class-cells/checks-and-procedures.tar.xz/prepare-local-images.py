from pathlib import Path
import shutil

lab=Path(__file__).resolve().parent
donor=lab.parent/'eager-expression-qualification'
fmt=lab.parent/'format-continuation-scratch'
read=lambda p:p.read_text(encoding='utf-8-sig')
def write(name, text):
    (lab/name).write_text(text,encoding='utf-8',newline='\n')
text=read(donor/'freeze-and-verify.py')
text=text.replace('agent-worktrees/eager-expression-emission','agent-worktrees/single-lexical-class-cells')
text=text.replace("prior = lab.parent / 'executable-class-suites/reuse-confirmation'","prior = lab.parent / 'format-continuation-scratch'")
text=text.replace('53d3b45d5','a4d11c189').replace("catalog=read(prior/'catalog.json')", "catalog=read(lab.parent/'eager-expression-qualification/catalog.json')")
write('freeze-and-verify.py',text)
text=read(fmt/'stage-quiet.py').replace("prior=lab.parent/'eager-expression-qualification'","prior=lab.parent/'format-continuation-scratch'")
text=text.replace('format-continuation-scratch-b1198','single-lexical-class-cells-b1199')
text=text.replace('lython-b1198-format-continuation-scratch','lython-b1199-single-lexical-class-cells')
text=text.replace('Inline method format state with retained nested scratch','Class-cell capture during lexical preparation')
text=text.replace('lython-b1197-fixtures','lython-b1198-fixtures').replace("'lython-b1198-fixtures')","'lython-b1199-fixtures')")
text=text.replace("len(rows)==3 and all(row['Matches']and row['Compared']for row in rows)", "len(rows)==23 and all(row['Compared']for row in rows)\n        assert sum(not row['Matches'] for row in rows)==(6 if role=='reference' else 0)")
a=text.index('jobs=['); b=text.index('\nidentity=',a)
jobs=[('scripts.dataclass-inherited-configuration.generated','compile'),('scripts.dataclass-inherited-configuration.generated','compile-run'),
      ('scripts.config-generated-guards.medium','compile-run'),('scripts.config-manifest.small','compile-run'),
      ('scripts.annotated-rule-closures','warm')]
text=text[:a]+'jobs='+repr(jobs)+text[b:]
text=text.replace("len(jobs)==5','len(jobs)==6","len(jobs)==6','len(jobs)==5")
text=text.replace("['jobs']==5\",\"['jobs']==6", "['jobs']==6\",\"['jobs']==5")
text=text.replace("len(raw['jobs'])==5\",\"len(raw['jobs'])==6", "len(raw['jobs'])==6\",\"len(raw['jobs'])==5")
text=text.replace("'jobs=5,','jobs=6,'", "'jobs=6,','jobs=5,'")
text=text.replace("seconds=305','seconds=285", "seconds=285','seconds=245").replace("before 305','before 285","before 285','before 245")
text=text.replace('Complete images and three CPython probes verified. Six warm lanes staged.',
                  'Complete images and 23 CPython probes verified. Five compilation and execution lanes staged.')
write('stage-quiet.py',text)
text=read(donor/'test-ubuntu.sh').replace('eager-expression-qualification','single-lexical-class-cells').replace('eager-expression-emission','single-lexical-class-cells')
text=text.replace('filter=$(cat "$lab/focused-public-filter.txt")','filter="Category!=Stress&($(cat "$lab/focused-filter.txt"))"')
write('test-ubuntu.sh',text)
assert b'\r' not in (lab/'test-ubuntu.sh').read_bytes()
initial=lab/'initial'
initial.mkdir(exist_ok=True)
for file in [*lab.glob('probe-*.jsonl'),lab/'probe-comparison.log',lab/'public-win.log',lab/'probe-final-win.log']:
    if file.exists():shutil.copyfile(file,initial/file.name)
