set -eu
root=/home/lokad/lython-bench-checks/single-lexical-class-cells-b1199-20261120
trap 'result=$?; printf "%s\n" "$result" > "$root/exit-code.txt"' EXIT
python3 "$root/collect.py"
