from pathlib import Path
import hashlib,json,os,re,subprocess
r=Path(__file__).parent;env=os.environ.copy();env['DOTNET_ROOT']='C:/Users/JoannesVermorel/.dotnet11';env['DOTNET_HOST_PATH']=env['DOTNET_ROOT']+'/dotnet.exe';env['PATH']=env['DOTNET_ROOT']+os.pathsep+'C:/Python313'+os.pathsep+env['PATH']
checks={}
def run(name,args):
    with (r/(name+'.log')).open('w',encoding='utf-8')as log:done=subprocess.run([env['DOTNET_HOST_PATH'],*args],env=env,stdout=log,stderr=subprocess.STDOUT)
    text=(r/(name+'.log')).read_text(encoding='utf-8');print(name,done.returncode,text[-850:],flush=True);assert done.returncode==0
    count=re.search(r'Passed!\s+- Failed:\s+0, Passed:\s+(\d+)',text);checks[name]=dict(exitCode=0,passed=int(count[1])if count else None)
for target in ['net11.0','net10.0']:
    suffix='net11'if target=='net11.0'else'net10'
    run('binding-probe-'+suffix,['build','tools/LythonProbe/LythonProbe.csproj','-c','Release','-f',target])
    run('binding-internal-'+suffix,['test','tests/Lokad.Lython.Tests/Lokad.Lython.Tests.csproj','-c','Release','-f',target,'--filter','(FullyQualifiedName~Function|FullyQualifiedName~Call|FullyQualifiedName~Binding|FullyQualifiedName~Closure|FullyQualifiedName~Generator|FullyQualifiedName~Ownership|FullyQualifiedName~Frame|FullyQualifiedName~InstructionFailure)&Category!=Stress','--logger','console;verbosity=minimal'])
    names=['FunctionDefaultMetadataTests','OrdinaryFunctionCallTests','OrdinaryMethodCallTests','NativeReturnFunctionTests','PreparedFunctionDefaultsTests','DeferredFunctionContextTests','AsyncFunctionHostingTests','ExecutableCallLifetimeTests','CallArgumentEvaluationTests','ExpandedCallExecutionTests','ComparisonFileWorkerTests','FunctionNamespaceLifetimeTests','FunctionDefinitionIsolationTests','GeneratorFunctionScenarioTests','RecursiveExceptionPropagationTests','RecursionDepthScenarioTests']
    run('binding-public-'+suffix,['test','tests/Lokad.Lython.PublicApi.Tests/Lokad.Lython.PublicApi.Tests.csproj','-c','Release','-f',target,'--filter','('+'|'.join('FullyQualifiedName~'+n for n in names)+')&Category!=Stress','--logger','console;verbosity=minimal'])
    core=Path('src/Lokad.Lython/bin/Release')/target/'Lokad.Lython.dll';probe=Path('tools/LythonProbe/bin/Release')/target/'Lokad.Lython.dll';assert hashlib.sha256(core.read_bytes()).digest()==hashlib.sha256(probe.read_bytes()).digest()
    checks[suffix+'-coreSHA256']=hashlib.sha256(core.read_bytes()).hexdigest()
(r/'binding-focused.json').write_text(json.dumps(dict(checks=checks,matchingProbes=True,baselinePublicDefaultChecks=20,sourceVariant='R71 managed readonly binding-descriptor transport correction; includes five new construction semantic/lifetime cases, production construction unchanged'),indent=2)+'\n',encoding='utf-8')
