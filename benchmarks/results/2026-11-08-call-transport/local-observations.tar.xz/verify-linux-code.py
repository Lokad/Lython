from pathlib import Path
import hashlib, io, json, shlex, subprocess, tarfile

r = Path(__file__).parent
assert json.loads((r/'terminal-status.json').read_text(encoding='utf-8'))['receipt']['complete'], 'Only after the controlled collection is closed and archived.'
out = r/'linux-code'
out.mkdir(exist_ok=False)
core = json.loads((r/'identity.json').read_text(encoding='utf-8'))['coreSHA256']['candidate']
source = (r.parent/'code-assessment/source.py').read_bytes()
run = r'''from pathlib import Path
import fcntl,hashlib,json,os,re,shutil,subprocess
root=Path('/home/lokad/lython-bench-checks/binding-transport-code-b427-20261108')
base=root.parent
with (base/'comparison-vm.lock').open('a') as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record'],capture_output=True).returncode==1
 donor=base/'binding-transport-b427-20261108/candidate'
 assert hashlib.sha256((donor/'Lokad.Lython.dll').read_bytes()).hexdigest()=='CORE'
 image=root/'image';shutil.copytree(donor,image,copy_function=os.link)
 for name in ['LythonProbe.dll','LythonProbe.deps.json','LythonProbe.runtimeconfig.json']:os.link(root/name,image/name)
 dotnet=Path('/home/lokad/lython-bench-toolchains/dotnet/11.0.100-rc.3.26522.148/dotnet')
 env={k:v for k,v in os.environ.items() if not k.startswith(('DOTNET_','COMPlus_'))}
 env.update(DOTNET_ROOT=str(dotnet.parent),DOTNET_JitDisasm='BeginPendingCall BeginBoundCall',DOTNET_JitStdOutFile=str(root/'current-jit.txt'))
 done=subprocess.run([str(dotnet),str(image/'LythonProbe.dll'),str(root/'source.py'),'--json'],env=env,cwd=root,capture_output=True,text=True,timeout=45)
 (root/'stdout.json').write_text(done.stdout);(root/'stderr.txt').write_text(done.stderr)
 assert done.returncode==0 and not done.stderr
 result=json.loads(done.stdout);assert result['Lython']['Success'] and result['Lython']['StandardOutput']==str(450000)+chr(10)
 text=(root/'current-jit.txt').read_text()
 part=next(p for p in re.split(r'(?=; Assembly listing for method )',text) if p.strip() and 'BeginPendingCall' in p.splitlines()[0] and '(Tier1)' in p.splitlines()[0])
 lines=part.splitlines();calls=[]
 for i,line in enumerate(lines):
  if 'call ' in line and 'BeginBoundCall' in line:
   assert 'BeginBoundCall(byref,bool,bool)' in line,line
   snippet='\n'.join(lines[max(0,i-8):i+1]);assert 'movsq' not in snippet
   calls.append(snippet)
 assert len(calls)==3
 receipt=dict(complete=True,coreSHA256='CORE',sourceSHA256=hashlib.sha256((root/'source.py').read_bytes()).hexdigest(),golden='450000\n',exitCode=done.returncode,managedReadonlyReferenceAtAllThreeTier1Entries=True,callSites=calls,jitSHA256=hashlib.sha256((root/'current-jit.txt').read_bytes()).hexdigest(),performanceQualified=False,purpose='Generated-code acceptance only, Linux x64; no causal/elapsed/CPU claim.')
 (root/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt))
'''.replace('CORE', core)
# Keep payload source out of process arguments, and do not stage over old evidence.
payload = io.BytesIO()
with tarfile.open(fileobj=payload, mode='w:gz') as archive:
    for name in ['LythonProbe.dll','LythonProbe.deps.json','LythonProbe.runtimeconfig.json']:
        archive.add(Path('tools/LythonProbe/bin/Release/net11.0')/name, arcname=name)
    for name, data in [('source.py',source),('run.py',run.encode())]:
        info=tarfile.TarInfo(name);info.size=len(data);archive.addfile(info,io.BytesIO(data))
(out/'payload.tgz').write_bytes(payload.getvalue())
remote = "from pathlib import Path; import io,runpy,sys,tarfile; r=Path('/home/lokad/lython-bench-checks/binding-transport-code-b427-20261108'); assert not r.exists(); r.mkdir(); a=tarfile.open(fileobj=io.BytesIO(sys.stdin.buffer.read()),mode='r:gz'); a.extractall(r,filter='data'); runpy.run_path(str(r/'run.py'))"
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
done=subprocess.run(ssh+['python3 -c '+shlex.quote(remote)],input=payload.getvalue(),capture_output=True,timeout=60)
(out/'run.log').write_bytes(done.stdout+done.stderr)
assert done.returncode==0,done.stderr.decode('utf-8')+done.stdout.decode('utf-8')
scp=['C:/Windows/System32/OpenSSH/scp.exe','-i',ssh[2],'-o','BatchMode=yes','-o','ConnectTimeout=15']
for name in ['receipt.json','current-jit.txt','stdout.json','stderr.txt','source.py','run.py']:
    done=subprocess.run(scp+['lokad@20.166.121.73:/home/lokad/lython-bench-checks/binding-transport-code-b427-20261108/'+name,str(out/name)],capture_output=True)
    assert done.returncode==0,done.stderr
receipt=json.loads((out/'receipt.json').read_text(encoding='utf-8'))
assert hashlib.sha256((out/'current-jit.txt').read_bytes()).hexdigest()==receipt['jitSHA256']
print('Linux Tier1: all three bound-body transitions use a managed readonly reference; old outgoing descriptor copy removed. No timing/causal CPU claim.')
