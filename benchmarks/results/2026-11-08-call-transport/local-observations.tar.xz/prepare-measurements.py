from pathlib import Path
import ast, hashlib, json, os, shutil, subprocess, tarfile

r = Path(__file__).parent
previous = r.parent
base = previous.parent
assert (r / 'binding-focused.json').exists()
focused = json.loads((r / 'binding-focused.json').read_text(encoding='utf-8'))
for target in ['net11', 'net10']:
    assert focused['checks']['binding-internal-' + target]['passed'] == 1366
    assert focused['checks']['binding-public-' + target]['passed'] == 244
shutil.copytree(previous / 'images/before', r / 'images/before', copy_function=os.link)
shutil.copytree(r / 'images/before', r / 'images/candidate', copy_function=os.link)
core = r / 'images/candidate/Lokad.Lython.dll'
core.unlink()
shutil.copyfile('src/Lokad.Lython/bin/Release/net11.0/Lokad.Lython.dll', core)
shutil.copyfile(core, r / 'current-core.dll')
assert hashlib.sha256(core.read_bytes()).hexdigest() == focused['checks']['net11-coreSHA256']
for name in ['catalog.json', 'representative.json', 'baseline.json', 'baseline-public.log', 'setup-contract.json']:
    shutil.copyfile(previous / name, r / name)
local = dict(sourceRevision='f88191f7 plus R71 managed readonly binding-descriptor transport correction',
    baseline=json.loads((r / 'baseline.json').read_text(encoding='utf-8')),
    coreSHA256={role:hashlib.sha256((r/'images'/role/'Lokad.Lython.dll').read_bytes()).hexdigest() for role in ['before','candidate']},
    productionSources={str(p).replace('\\','/'):hashlib.sha256(p.read_bytes()).hexdigest() for p in Path('src/Lokad.Lython').rglob('*.cs') if not any(x in ['bin','obj'] for x in p.parts)})
(r / 'identity.json').write_text(json.dumps(local, indent=2)+'\n', encoding='utf-8')
(r / 'source.patch').write_bytes(subprocess.check_output(['git','diff','--binary','--','src','tests']))
identity = json.loads((previous / 'vm-identity.json').read_text(encoding='utf-8'))
identity['sourceRevision'] = local['sourceRevision']
identity['productionSources'] = local['productionSources']
identity['originalVariant'] = 'B424/B425 source/timings and B426 attribution retained; this correction removes Linux-proven new 48-byte outgoing transport.'
identity['coreSHA256']['candidate'] = identity['coreSHA256']['candidate-control'] = local['coreSHA256']['candidate']
(r / 'vm-identity.json').write_text(json.dumps(identity, indent=2)+'\n', encoding='utf-8')

for name in ['collect.py', 'archive-owned.py', 'run.sh', 'launch.py', 'retrieve.py', 'assess-vm.py']:
    s = (previous / name).read_text(encoding='utf-8')
    s = s.replace('linear-keyword-b425-20261107', 'binding-transport-b427-20261108')
    s = s.replace('lython-b425-linear-keyword-20261107', 'lython-b427-binding-transport-20261108').replace('lython-b425-fixtures', 'lython-b427-fixtures')
    if name.endswith('.py'):ast.parse(s)
    (r / name).write_text(s, encoding='utf-8', newline='\n')
for name in ['measure.py', 'assess-local.py']:
    s = (previous / name).read_text(encoding='utf-8').replace("old=r.parent/'integer-utf8-r45'", "old=r.parent.parent/'integer-utf8-r45'")
    ast.parse(s)
    (r / name).write_text(s, encoding='utf-8')
shutil.copyfile('PLAN.md', r / 'pre-measurement-plan.md')
(r / 'contract.md').write_text('''R71/B427 concrete transport correction: actual Linux Tier1 copies the new 48-byte BoundCallArguments to outgoing stack storage; Windows optimized positional code does not. BeginBoundCall borrows the existing readonly local synchronously using managed in; no retained reference, new storage, policy, cancellation removal or signature behavior change. B424/B425 adverse results and B426 attribution preserved. No claim this explains the entire CSV gap. Focused1366internal/244public per actual11/10, matching probes; five sequence semantic/lifetime additions pass on unchanged construction runtime. Existing five-script allocation diagnostic separate. Controlled four jobs against fully qualified R70d6445fc5, two reference/two candidate processes,5s warmup/role/job,7rotated150ms, normalGC/tiering/quietF4as_v7; returned-record sync/async and ordinary CSV/text warm. Same worker7cf37ca5 and optional0.4adapter. Include invocation/RAM I/O/full goldens/prior cleanup; exclude compile/startup/reset/staging/protocol/final teardown. Source/actualReady/auxiliary/runtime/golden/quiet/Closed/exit/join/fixture/archive gates. Persistent records separate owned128MiB RAM fixtures,256MiB staging floor;150sowner+30stop+30margin, observe210s, never restart an observation timeout. Explicit residual-debt disposition at completion; original clocks/10ms external CPU limitations remain. No primary CPython refresh, final qualification, general CPU or publication claim.
''', encoding='utf-8')
with tarfile.open(r / 'payload.tgz', 'w:gz') as archive:
    for name in ['collect.py','archive-owned.py','run.sh','current-core.dll','representative.json','pre-measurement-plan.md','setup-contract.json','contract.md']:
        archive.add(r/name, arcname=name)
    for source, target in [('binding-focused.json','focused.json'),('vm-identity.json','identity.json'),('source.patch','source.patch')]:
        archive.add(r/source, arcname=target)
print('Transport correction frozen, focused checks and production inventories verified:', local['coreSHA256']['candidate'])
