from pathlib import Path
import hashlib, json, re, shutil, tarfile

r=Path(__file__).parent;debt=r.parent/'csv-debt-b426'
out=Path('benchmarks/results/2026-11-08-call-transport');out.mkdir(exist_ok=True)
assert not (out/'README.md').exists()
identity=json.loads((r/'identity.json').read_text(encoding='utf-8'))
assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==h for p,h in identity['productionSources'].items())
for source,prefix in [(r,''),(debt,'attribution-')]:
 receipt=json.loads((source/'archive-receipt.json').read_text(encoding='utf-8'));assert receipt['complete']
 assert hashlib.sha256((source/'observations.tgz').read_bytes()).hexdigest()==receipt['archiveSHA256']
 for name in ['observations.tgz','archive-receipt.json','terminal-status.json','identity.json','contract.md']:shutil.copyfile(source/name,out/(prefix+name))
for name in ['assessment.json','local-assessment.json','binding-focused.json','vm-identity.json','pre-code-plan.md']:shutil.copyfile(r/name,out/name)
shutil.copyfile(debt/'paired-chains.json',out/'paired-chains.json')
shutil.copyfile(r/'linux-code/receipt.json',out/'linux-code.json')
with tarfile.open(out/'local-observations.tar.xz','w:xz')as archive:
 for p in r.iterdir():
  if p.is_file()and p.suffix in ['.py','.json','.log','.md','.patch','.txt','.cs']:archive.add(p,arcname=p.name)
 for folder in ['warm-sync','warm-async','linux-code']:archive.add(r/folder,arcname=folder)
 archive.add(r.parent/'code-assessment',arcname='windows-code',filter=lambda m:None if '/baseline/'in m.name or '/current/'in m.name else m)
 for p in debt.iterdir():
  if p.is_file()and p.suffix in ['.py','.json','.log','.md']:archive.add(p,arcname='attribution/'+p.name)
 for name in ['sequence-baseline-net11.log','sequence-baseline-corrected-net11.log','sequence-baseline-final-net11.log']:archive.add(r.parent/name,arcname=name)
 archive.add(r/'current-core.dll',arcname='current-core.dll')
 archive.add('src/Lokad.Lython/bin/Release/net10.0/Lokad.Lython.dll',arcname='current-net10-core.dll')
raw=json.loads((r/'assessment.json').read_text(encoding='utf-8'))
table='| Complete job | Elapsed change, all process pairs | Baseline / current spread |\n| --- | ---: | ---: |\n'
for job in raw['jobs']:
 values=[v for pair in job['elapsedPercent'].values()for v in pair]
 table+=f"| {job['case'].removeprefix('scripts.')} / {job['lane']} | {min(values):+.2f} to {max(values):+.2f}% | {abs(job['baselineSpreadPercent']):.2f}% / {abs(job['candidateSpreadPercent']):.2f}% |\n"
(out/'README.md').write_text('''# Managed call-descriptor transport — R71 / B426–B427

2026-11-08. Retained correction on f88191f7. Measured cores bc30d424 (.NET 11) /
051865c7 (.NET 10); exact inventories/patch/binaries preserved. Public APIs and
Python semantics unchanged. Full delivery of this correction remains pending.

## Concrete source correction, bounded attribution

R71 consolidated nonmirrored keyword/variadic calls onto the linear frame runner
and reduced returned-record allocation about 13%, with adverse ordinary-CSV elapsed
and coarse CPU observations. B424/B425 sources and every original result remain
[separately preserved](../2026-11-08-linear-keyword-calls/README.md).

One unchanged-source baseline/current full-CSV attribution, B426: 1,124 guest
samples per role, 5.65/5.66 guest CPU seconds, unknown leaves 78/60, no malformed
maps or empty/single-frame chains. Call-preparation leaf samples are 36 in the old
method versus 15+13 in the split methods; inclusive stacks overlap and include
useful execution. This is not evidence of a dominant new call cost or a causal
timing explanation. Normal tiering/GC, diagnostic PerfMap/JIT overrides, perf
199 Hz/frame pointers; missing/inlined/native frames and sample skid remain.

Windows x64 Tier1 already elides the suspected positional descriptor copy. Actual
Linux Tier1 does not: all three new BeginBoundCall call sites copy the 48-byte
BoundCallArguments onto outgoing stack storage using reference stores/movsq.
The corrected synchronous entry borrows its existing readonly local with managed
`in`. Values/owners still transfer into existing work/frame fields; the reference
never survives this synchronous method. Actual async binding awaits first, then
enters the same method. No unsafe mechanism, new allocation/field/engine/policy,
removed cancellation check or duplicate positional path. A separate Linux code
acceptance run confirms **all three optimized call sites use the readonly reference
and the outgoing descriptor copy disappears**, with the full golden preserved.

## Focused checks and allocations

1,366 internal / 244 targeted public checks per actual .NET 11/10 pass with matching
probes. Function/default/method/native/deferred/argument-order/namespace/generator/
recursion/suspension/cancellation/refusal/lifetime tests remain. Five new sequence
identity/lifetime cases are included; production sequence construction is unchanged
in this source pair. All 16 deferred-context cases first pass on unchanged R71.
Initial fixture errors (tuple public projection is an array, then a misplaced test
edit causing compile failure) are retained; neither was a runtime failure or a
weakened assertion. Corrected tests verify withdrawn aliases through real pending
I/O/cancellation, escaping results and shared-budget baseline return.

Existing five-script diagnostic, both APIs, normal GC/tiering and independent
before/current/control assemblies: full goldens/balances/isolation/cleanup pass.
Returned-record allocations remain **−13.51–13.53% sync / −12.62–12.64% async**
versus R70, ordinary allocations essentially flat. Desktop clocks remain variable:
sync affected −1.90/−10.68% with 9.82% old drift; async ordinary CSV +10.65/−8.43%
with 20.84% old drift, async report +2.82/+9.49%. Preserve these adverse/contradictory
observations; no desktop CPU or causal improvement claim.

## Controlled corrected source pair — B427

Quiet F4as_v7/Ubuntu24.04.4/.NET11RC3, same fully qualified R70 baseline d6445fc5,
unchanged 7cf37ca5 manifest worker and normal optional 0.4 adapter. Two independent
baseline/two current processes, five-second warmup per role/job and seven rotated
150 ms rounds. Four complete jobs take **114.398 seconds**. Negative means faster.

'''+table+'''
Ordinary CSV now stays near baseline, with coarse process CPU flat across all four
pairs. The previous B425 +6.25–11.70% CPU/+0.07–5.09% elapsed is not reproduced
after the concrete transport correction. Retain the correction; this bounded
evidence disposes of the immediate large ordinary-CSV regression concern without
claiming its full cause is proven. Original adverse data stays visible. Returned-
record sync remains flat; async elapsed is favorable but between-process spread
limits precision. Text +2.10% and affected sync +1.17% remain adverse observations.
No universal CPU gain, exact causal percentage, debt repayment or CPython claim.
Remaining regression debt must still be considered at the combined checkpoint.

Warm includes public invocation, mediated RAM I/O, full stdout/file validation and
prior-result cleanup; compile/startup/reset/staging/protocol/final cached teardown
excluded. Async timing uses completed I/O; real suspension is correctness-tested.
Desktop includes reset/result disposal and absolute clocks cannot be compared.
No pending-I/O, RSS, startup or embedding-tail claim.

All source/actualReady/auxiliary/runtime/golden/quiet/Closed/exit/join/empty-fixture
gates pass. Persistent records remain outside owned 128 MiB RAM fixtures, users
join and mounts disappear before archive verification under lease and locally.
B426/B427 are terminal/archived/verified; never query again. B427 staging
274,960,384 B passes the 256 MiB floor without reclaim. 150 s owner + 30 s stop +
30 s margin; no measured timeout/restart. The first local launcher mistakenly
reused an old staging filename and refused before any collection setup; its
original condition is preserved and only the unique filename was corrected.

[Controlled assessment](assessment.json), [allocation/adverse desktop](local-assessment.json),
[paired diagnostic chains](paired-chains.json), [Linux acceptance](linux-code.json),
[focused checks](binding-focused.json), [identities](identity.json), [VM identities](vm-identity.json),
[pre-code gate](pre-code-plan.md), [VM archive](observations.tgz),
[attribution archive](attribution-observations.tgz),
[local raw/source/cores/tests/code](local-observations.tar.xz).
''',encoding='utf-8')
receipt=json.loads((out/'archive-receipt.json').read_text(encoding='utf-8'));receipt['localArchiveSHA256']=hashlib.sha256((out/'local-observations.tar.xz').read_bytes()).hexdigest()
(out/'archive-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8')
p=Path('docs/BENCHMARKS.md');s=p.read_text(encoding='utf-8');old=next(line for line in s.splitlines()if line.startswith('| Linear keyword/variadic calls'))
s=s.replace(old,'| Linear keyword/variadic calls / returned-record CSV | Allocation −13.5% sync/−12.6% async; corrected controlled sync flat, async elapsed −1.21–6.31% | Original adverse CSV preserved; after transport correction CSV −1.74 to +0.43%, coarse CPU flat. Full correction delivery pending. [R71](../benchmarks/results/2026-11-08-call-transport/README.md) |');p.write_text(s,encoding='utf-8')
p=Path('benchmarks/EXPERIMENTS.md');p.write_text(p.read_text(encoding='utf-8')+'''
## R71 ordinary-CSV transport correction

[B426/B427](results/2026-11-08-call-transport/README.md): bounded paired CPU
attribution does not establish a dominant new call cost. Actual Linux Tier1 proves
the split entry adds a 48-byte outgoing descriptor copy, elided in Windows Tier1.
Managed readonly borrowing removes that transport at all three optimized entries;
no new storage/policy/unsafe mechanism or cancellation deletion. 1,366 internal /
244 public per actual11/10 pass; five new sequence identity/pending-I/O/ownership
cases first pass with production construction unchanged. Allocation remains
−13.5% sync/−12.6% async. Controlled four-job pair114.398s: affected sync flat,
async−1.21–6.31%; ordinary CSV−1.74to+0.43% elapsed/coarseCPUflat. Retain concrete
correction; large B425 CSV concern not reproduced, no full causal explanation.
Text+2.10%, affected sync+1.17%, original B424/B425 and adverse desktop retained.
All source/golden/quiet/join/fixture/archive gates pass. Full corrected delivery
pending; publication postponed. Resume complete construction/frame milestone.
''',encoding='utf-8')
for p in [out/'README.md',Path('docs/BENCHMARKS.md')]:
 for target in re.findall(r'\]\(([^)]+)\)',p.read_text(encoding='utf-8')):
  if '://'not in target and not target.startswith('#'):assert(p.parent/target.split('#',1)[0]).exists(),(p,target)
print('B426/B427 original/adverse data, exact sources, generated code and corrected comparison preserved; immediate CSV debt disposition explicit.')
