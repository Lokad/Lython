# Lokad.Lython 0.11.0

Updated 2026-11-08. Git-ignored; never force-add. Publication and tagging postponed.
Objective: coherent design simplification and substantial complete-script performance.
An isolated experiment does not complete that objective. Historical narratives,
original failed conditions and raw measurements remain in benchmarks/EXPERIMENTS.md
and results; docs describe the current implementation.

## Delivery status

| Work | Actual status |
| --- | --- |
| Shared compiler facts, direct UTF-8 formatting/storage, native helper returns | Committed and fully qualified. Native-return allocation −19.92%/−19.31%; original elapsed diagnostic. Formatting allocation −8.67%; controlled B102 elapsed/CPU −5–8%, original adverse 15.125 ms preserved and unexplained. Do not repeat unchanged qualification. |
| R62 / 70267889 | Fully qualified CI42412531882, cached terminal green. |
| R65/R66 / 824fc6bb | Fully qualified CI42418518578: Windows/Ubuntu Release actual .NET 11/10, original Stress and installed core consumers. |
| R67 / 5076359c | Current CPython guide measures 824fc6bb/core15c04e2a, 23 jobs/478.32 s. Compile, warm and compile-to-result separate; I/O/validation/cleanup boundaries explicit. Original failed B406 and historical 55e510ff preserved. Not today's HEAD. |
| R68 / 5076359c | Exact immutable dev55/d6067925: 86 internal/514 public per actual 11/10, unchanged adapter bridge. Normal optional 0.4 pin/core unchanged. Development compatibility only. |
| R69 / fd5ab1c1 | Complete returned-record CSV script, independent goldens/CPython checks and current attribution committed; production unchanged. |
| R70 / 7a81a629 | Fully qualified CI42422556519: Windows/Ubuntu Release actual 11/10, original Stress and installed consumers. Cached terminal receipt; never requery. Immutable tuple unpacking removes iterator/list/copy/reservation work. Allocation −13.57% sync/−14.40% async; controlled affected elapsed −6.45–7.45% sync/−7.01–9.34% async. |
| R71 | Committed/pushed f88191f7; full delivery dispatched, not yet qualified. Final cores 40a4959e/a00c2ce7; 1,366 internal/239 targeted public per actual 11/10 with matching probes. Earlier initial/context-only variants separately passed 1,366/3,118 per target. B424/B425 complete, archived and verified. |

## Priority 1 — deliver R71 and resolve ordinary-call regression debt

Ordinary nonmirrored keyword/variadic executable calls now share positional calls'
linear runner, final workspace and existing binder. They avoid the recursive generic
InvokeFromOperands/InvokeBound/ExecuteBody route. Deferred lexical contexts no longer
depend on signature. Removed redundant local-storage state, impossible positional
selection and generic native-borrow attempts/flags without eligible production callers.
Real mirrored/lowered/callback entries and measured native helper optimizations stay.
Completed transitions/sync binding return directly; only actual pending defaults await.

Acceptance already demonstrated: live/replaced defaults, receivers, closures, varargs/
kwargs, exception origins, 301-frame keyword recursion, actual default suspension and
cancellation. New refusal regression retains withdrawn argument aliases, stops guest
suppression/finally return, awaits I/O and returns the shared budget to baseline.
Call admission/workspace/caller operands transfer exactly once and stay funded until
all users/cleanup finish. No new arena, binder, persistent fields, policy or engine.

Final B425 (114.478 s, four jobs/two baseline + two current processes): returned-record
allocation −13.5% sync/−12.6% async; controlled sync elapsed flat, async −1.57–4.37%.
**Ordinary CSV is adverse +0.07–5.09% elapsed/+6.25–11.70% coarse process CPU**;
baseline/current process spreads about 2.5%/2.3%. Original B424 and contradictory
adverse desktop/control data remain. No general CPU improvement or causal explanation.
[Source/observations/disposition](benchmarks/results/2026-11-08-linear-keyword-calls/README.md).

Deliverables and stopping criteria:
1. f88191f7 commits the consolidation and immutable original/refined evidence.
   Full Windows/Ubuntu actual 11/10, original Stress and installed-core checkpoint
   dispatched once; not yet observed. Continue independent work while CI runs; cached terminal runs are final.
2. Windows x64 Tier1 positional calls already pass the binder return buffer
   without the suspected extra descriptor copy. Both versions preserve the golden;
   no Linux causal claim. B426 is now terminal/verified: 1,124 guest samples per
   role / 5.65 and 5.66 CPU seconds. Actual Linux Tier1 copies the new 48-byte
   descriptor at every bound-body transition. Correct this proven added transport
   using a synchronous managed readonly borrow; no claim it explains the full gap.
   Focused token/refusal/lifetime checks and one controlled B427 confirmation
   against the original R70 baseline, preserving B424/B425/B426. Confirm Linux
   copy removal and explicitly decide residual debt before construction work. A by-value argument descriptor,
   added checks or changed inlining are hypotheses, not established causes. Correct
   concrete added work if justified. No blind byref/inlining/check deletion.
3. If source evidence is insufficient, select one focused current attribution or an
   explicit restoration/debt decision. Preserve the original conditions and adverse
   results. Do not repeatedly retime unchanged code. Stop at a concrete correction,
   insufficient causal evidence, or an explicit retained/restored debt disposition.
   Temporary regression remains visible until that decision, not silently repaid by
   unrelated gains. Final release acceptance must decide any remaining regression debt.

## Priority 2 — complete construction/frame simplification

Select only after the R71 debt assessment. Existing source gate finds plain list/
tuple opcodes force a lexical invocation although their existing admitted builders
need only scope/storage. Entire sequence-construction phase is the candidate; no
benchmark-only return shape. Set/dict hashing and starred protocols need real guest
context and remain outside this contained change.

Hypothesis: execute intrinsic list/tuple construction in the shared prefix and remove
the displaced ExecuteStructure cases/context promotion. Returned-record helpers and
collection-producing helpers benefit; do not predict a speedup before measurement.
Preserve evaluated input order, exact identity/aliasing, starred hooks, preflight/
replacement overlap, pending users, cancellation, errors and retained result funding.
Inspect post-admission cancellation before allocation. Focused semantic/token/refusal/
cleanup checks, then existing five-script allocation diagnostic and one bounded
controlled affected/control comparison if retained. Finish with source deletion,
measured allocation/elapsed distinction and an explicit regression decision.

## Following substantial redesign boundaries

| Boundary | Evidence / eliminated work / acceptance |
| --- | --- |
| Complete calls/frames and operand transport | Indexed operands/native returns/final slots/deferred contexts already exist. R63 text attribution includes useful arithmetic/dispatch; inclusive calls are not removable CPU. Select a complete remaining transport/activation phase, remove its displaced path. Preserve callbacks, exception state, exact integer promotion/identity, aliases and public projection. No universal tagged-value or arena rewrite without dominant-cost evidence. |
| Per-record storage | R20/R25 shared CSV keys/array transfer/direct JSON slots and R70 tuple borrow supersede the rigidly rejected bulk-CSV attempt. Its 6–8% benefit and adverse control remain historical. Reassess a real remaining construction/copy/capacity phase; no automatic revival. Preserve row mutation/reentry/hooks/order/retained aliases. |
| Bulk text/JSON | Direct UTF-8 casing/lower-split/formatting/native parsing, completed JSON loop and shared line scanner delivered. R61 measured ordinary JSON has no escaped tokens. Select a demonstrated whole conversion/storage phase, preserve Unicode/context/hooks/async I/O; no succession of narrow special cases. |
| Frontend facts | R55/R58/R62/R65 remove repeated lexical/graph/validity/module work. Remaining class/function demands have distinct scope/annotation rules. Require concrete repeated-walk deletion with exact diagnostics; no speculative visitor/cache/parser migration. |

For each selected milestone record the hypothesis, work/storage eliminated, affected
complete scripts, semantic/cancellation/admission acceptance and old implementation
removed. One bounded source/generated-code assessment; focused attribution only if
existing evidence cannot select. Stop at a concrete phase or insufficient evidence,
then choose another boundary. Prior call-arena/call-control slowdowns remain lessons,
not dormant alternatives. Architectural simplification, allocation reduction, elapsed
and CPU are distinct. Fixed improvement percentages inform judgment, never automatic
vetoes. A timeout or unstable unchanged control establishes uncertainty. Allow bounded
confirmation/refinement/measurement correction when justified, retaining all original
adverse and failed conditions. No blanket one-attempt/no-retiming/permanent closure.

At the next combined retained checkpoint refresh representative CPython comparisons:
compilation, warm execution and compile-to-result separately; identical full scripts/
goldens, explicit I/O/validation/cleanup and startup boundaries. Current R67 guide
remains accurate for its named source; do not rerun unchanged qualification after
every experiment or imply that its tables describe today's HEAD.

## Independent regex track

Core owns Python/native UTF-8 semantics, byte ranges/scalar positions/original-subject
windows, flags/captures/replacements/errors, cache ownership/current tokens and one
provider through frontend/runtime/imports. No Utf8Regex core dependency. Optional
adapter stays nonpackable, normal 0.4 pin. Contract tests, semantic compatibility and
actual backend performance are separate. Development producers/adapter-local bridges
support implementation; missing publication defers only affected final qualification.

Precise dev55 gaps: DetailedData has no separate preparation/working-owner input;
native name lookup lacks enumeration; cursor creation retains its token despite
current-move overloads. Existing bridges remain justified. No sibling edits/builds,
producer-CI replay, dialect fallback, quotas, memory subsystem or abandoned matching.
Released-package/managed-safety/backend-performance qualification remains outstanding;
it must not stop independent core development or performance work.

## Lasting validation and ownership constraints

AGENTS.md governs fully managed/memory-safe code and managed stack admission: no
unsafe/Unsafe/PInvoke/raw pointers/native probes. Preserve host capabilities, effective
cancellation, checked representation bounds, XML depth and bounded I/O chunks.
Borrow the shared allowance for coarse preflights, capacity/replacement overlap,
retained aliases and escaping caches/results. Scope creation reserves nothing; no
hidden allowances/caps/fuel/quotas/tracing/weak reclamation/forced GC. Initial long
streams use bounded host-driven executions. First structured refusal is terminal
through guest suppression/finally returns; native refunds/cleanup remain awaited.
Never retry admission or skip optional storage to recover.

Focused Release checks during iteration; build matching probes, exclude Stress
explicitly when a custom filter is supplied. No overlapping local builds/tests/
measurements. Force nonincremental builds after timestamp-preserving source restores.
Batch full Windows/Ubuntu actual 11/10, original Stress and installed core consumers
at coherent retained boundaries. Use explicit UTF-8. Only core Release pack via
tools/pack.ps1 into artifacts/nuget; no adapter packages/publication/tag promotion.

VM lokad@20.166.121.73, key ~/.ssh/id_lython-bench.pem. B385–B425 are terminal,
archived/locally verified; never query again. B426 attribution terminal/archived/verified; never query again. Persistent
workers/records remain separate from owned RAM fixtures; keep 256 MiB staging floor,
join all users/unmount/archive under lease and verify locally. Reclaim only verified
redundant extracts while retaining immutable evidence. No sole RAM evidence. Space
GitHub status observations at least five minutes apart; never requery cached terminal
runs or duplicate dispatch. Continue the roadmap while CI runs.
