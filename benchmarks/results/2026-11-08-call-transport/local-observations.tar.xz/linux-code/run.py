from pathlib import Path
import fcntl,hashlib,json,os,re,shutil,subprocess
root=Path('/home/lokad/lython-bench-checks/binding-transport-code-b427-20261108')
base=root.parent
with (base/'comparison-vm.lock').open('a') as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record'],capture_output=True).returncode==1
 donor=base/'binding-transport-b427-20261108/candidate'
 assert hashlib.sha256((donor/'Lokad.Lython.dll').read_bytes()).hexdigest()=='bc30d42431748799d8d792c995406eee163dbee423fc5caa4c37da7e906591d1'
 image=root/'image';shutil.copytree(donor,image,copy_function=os.link)
 for name in ['LythonProbe.dll','LythonProbe.deps.json','LythonProbe.runtimeconfig.json']:os.link(root/name,image/name)
 dotnet=Path('/home/lokad/lython-bench-toolchains/dotnet/11.0.100-rc.3.26522.148/dotnet')
 env={k:v for k,v in os.environ.items() if not k.startswith(('DOTNET_','COMPlus_'))}
 env.update(DOTNET_ROOT=str(dotnet.parent),DOTNET_JitDisasm='BeginPendingCall BeginBoundCall',DOTNET_JitStdOutFile=str(root/'current-jit.txt'))
 done=subprocess.run([str(dotnet),str(image/'LythonProbe.dll'),str(root/'source.py'),'--json'],env=env,cwd=root,capture_output=True,text=True,timeout=45)
 (root/'stdout.json').write_text(done.stdout);(root/'stderr.txt').write_text(done.stderr)
 assert done.returncode==0 and not done.stderr
 result=json.loads(done.stdout);assert result['Lython']['Success'] and result['Lython']['StandardOutput']==str(450000)+chr(10)
 text=(root/'current-jit.txt').read_text()
 part=next(p for p in re.split(r'(?=; Assembly listing for method )',text) if p.strip() and 'BeginPendingCall' in p.splitlines()[0] and '(Tier1)' in p.splitlines()[0])
 lines=part.splitlines();calls=[]
 for i,line in enumerate(lines):
  if 'call ' in line and 'BeginBoundCall' in line:
   assert 'BeginBoundCall(byref,bool,bool)' in line,line
   snippet='\n'.join(lines[max(0,i-8):i+1]);assert 'movsq' not in snippet
   calls.append(snippet)
 assert len(calls)==3
 receipt=dict(complete=True,coreSHA256='bc30d42431748799d8d792c995406eee163dbee423fc5caa4c37da7e906591d1',sourceSHA256=hashlib.sha256((root/'source.py').read_bytes()).hexdigest(),golden='450000\n',exitCode=done.returncode,managedReadonlyReferenceAtAllThreeTier1Entries=True,callSites=calls,jitSHA256=hashlib.sha256((root/'current-jit.txt').read_bytes()).hexdigest(),performanceQualified=False,purpose='Generated-code acceptance only, Linux x64; no causal/elapsed/CPU claim.')
 (root/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt))
