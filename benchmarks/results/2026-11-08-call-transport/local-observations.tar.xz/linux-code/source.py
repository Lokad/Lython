def accumulate(record, totals):
 amount = int(record['amount'])
 if amount < 0: return False
 kind = record['kind']
 totals[kind] = totals.get(kind, 0) + amount
 return True
record = {'amount':'3', 'kind':'red'}
totals = {}
for index in range(150000):
 accumulate(record, totals)
print(totals['red'])
