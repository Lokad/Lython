from pathlib import Path
import hashlib,json,subprocess,tarfile
root=Path('/home/lokad/lython-bench-checks/csv-call-debt-b426-20261108')
assert all(json.loads((root/n).read_text())['gate']['quiet'] for n in ['machine-before.json','machine-after.json'])
assert not list(Path('/dev/shm').glob('lython-comparison-files-*'))
fixtures=root/'guest-fixtures';assert fixtures.is_mount() and not list(fixtures.iterdir())
assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record'],capture_output=True).returncode==1
records=[]
for case in ['baseline','current']:
 folder=root/'profiles'/case;record=json.loads((folder/'record.json').read_text())
 assert record['exitCode']==0 and record['closed']['status']=='Closed'
 assert (folder/'worker.stderr').stat().st_size==0
 assert record['verificationBefore']['status']=='Equivalent' and record['verificationAfter']['status']=='Equivalent'
 records.append(record)
assert sum(r['response']['elapsedTicks']/r['response']['clockFrequency'] for r in records)<16
(root/'fixture-filesystem.txt').write_text(subprocess.check_output(['findmnt','-T',str(fixtures),'-o','TARGET,SOURCE,FSTYPE,OPTIONS'],text=True))
subprocess.run(['sudo','-n','umount',str(fixtures)],check=True);fixtures.rmdir()
with tarfile.open(root/'observations.tgz','w:gz',dereference=True) as archive:
 archive.add(root/'profiles',arcname='perf')
 for p in root.iterdir():
  if p.is_file() and p.name!='observations.tgz':archive.add(p,arcname=p.name)
with tarfile.open(root/'observations.tgz') as archive:
 for case in ['baseline','current']:assert json.loads(archive.extractfile('perf/'+case+'/record.json').read())['exitCode']==0
receipt=dict(complete=True,allWorkersJoined=True,guestFixturesRemoved=True,quietBeforeAndAfter=True,archivedAndVerifiedUnderLease=True,capturedSeconds=sum(r['response']['elapsedTicks']/r['response']['clockFrequency'] for r in records),archiveSHA256=hashlib.sha256((root/'observations.tgz').read_bytes()).hexdigest(),performanceQualified=False)
(root/'archive-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt))
