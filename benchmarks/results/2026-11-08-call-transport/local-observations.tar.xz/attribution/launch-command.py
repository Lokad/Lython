from pathlib import Path
import ast,fcntl,hashlib,io,json,os,shutil,subprocess,sys,tarfile
base=Path('/home/lokad/lython-bench-checks');root=base/'csv-call-debt-b426-20261108'
source=(base/'linear-keyword-b425-20261107').resolve()
with (base/'comparison-vm.lock').open('a') as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert not root.exists() and not Path('/dev/shm/lython-csv-call-debt-b426').exists()
 assert not list(Path('/dev/shm').glob('lython-comparison-files-*'))
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record|[o]ps-profile.py'],capture_output=True).returncode==1
 payload=sys.stdin.buffer.read(46833+1)
 assert len(payload)==46833 and hashlib.sha256(payload).hexdigest()=='e651253bdce98478b8220667b40489392dd2b33b2a84a5819728cb27c9c59cc4'
 with tarfile.open(fileobj=io.BytesIO(payload),mode='r:gz') as a:
  assert shutil.disk_usage(base).free>sum(((m.size+4095)//4096)*4096 for m in a.getmembers())+272*1024*1024
  root.mkdir();a.extractall(root,filter='data')
 for role, donor in [('baseline','reference'),('current','candidate')]:shutil.copytree(source/donor,root/role,copy_function=os.link)
 fixture=root/'guest-fixtures';fixture.mkdir()
 subprocess.run(['sudo','-n','mount','-t','tmpfs','-o','size=128m,mode=0700,uid=lokad,gid=lokad','lython-b426-fixtures',str(fixture)],check=True)
 identity=json.loads((root/'identity.json').read_text())
 for role in ['baseline','current']:
  for name,digest in {**identity['auxiliaryFiles'],'Lokad.Lython.dll':identity['coreSHA256'][role]}.items():assert hashlib.sha256((root/role/name).read_bytes()).hexdigest()==digest
 for name in ['ops-profile.py','analyze-cpu-guest.py','archive.py']:ast.parse((root/name).read_text())
 subprocess.run(['/bin/sh','-n',str(root/'run.sh')],check=True)
 setup=dict(freeBytes=shutil.disk_usage(base).free,coreAndAuxiliaryImagesVerified=True,
  ownerSeconds=120,stopSeconds=30,observationMarginSeconds=30)
 (root/'setup.json').write_text(json.dumps(setup,indent=2)+'\n');print(json.dumps(setup),flush=True)
subprocess.run(['sudo','-n','systemd-run','--unit=lython-b426-returned-record-20261108',
 '--property=User=lokad','--property=WorkingDirectory='+str(root),'--property=RuntimeMaxSec=120',
 '--property=TimeoutStopSec=30','--property=KillMode=control-group','/bin/sh',str(root/'run.sh')],check=True)
