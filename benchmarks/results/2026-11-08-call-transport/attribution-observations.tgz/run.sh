set -eu
root=/home/lokad/lython-bench-checks/csv-call-debt-b426-20261108
dotnet=/home/lokad/lython-bench-toolchains/dotnet/11.0.100-rc.3.26522.148/dotnet
export DOTNET_ROOT=/home/lokad/lython-bench-toolchains/dotnet/11.0.100-rc.3.26522.148
export TMPDIR="$root/guest-fixtures"
date -u +%FT%TZ > "$root/started.utc"
trap 'exit 143' TERM
trap 'result=$?; printf "%s\n" "$result" > "$root/exit-code.txt"; date -u +%FT%TZ > "$root/stopped.utc"' EXIT
exec 9>/home/lokad/lython-bench-checks/comparison-vm.lock
flock -n 9
sleep 5
"$dotnet" "$root/current/Lokad.Lython.Benchmarks.dll" --compare check-machine --out "$root/machine-before.json"
python3 "$root/ops-profile.py" "$root/profiles"
sleep 5
"$dotnet" "$root/current/Lokad.Lython.Benchmarks.dll" --compare check-machine --out "$root/machine-after.json"
for case in baseline current; do
 python3 "$root/analyze-cpu-guest.py" "$root/profiles/$case"
done
# All sudo perf reads have ended before transferring these owned files.
sudo -n chown lokad:lokad "$root/profiles/baseline/perf.data" "$root/profiles/current/perf.data"
python3 "$root/archive.py"
