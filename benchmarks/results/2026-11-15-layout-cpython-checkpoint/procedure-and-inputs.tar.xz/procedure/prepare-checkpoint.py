from pathlib import Path
import ast
r=Path(__file__).parent;s=(r.parent/'format-sinks-r416/prepare-checkpoint.py').read_text(encoding='utf-8')
s=s.replace('format-cpython-b810-20261115','layout-cpython-b813-20261115').replace('lython-b810-format-cpython-20261115','lython-b813-layout-cpython-20261115').replace('B810','B813')
s=s.replace('format-sinks-b809-20261115','format-layout-b812-20261115').replace('/frozen8afb146e','/frozen9d071eba')
s=s.replace('Committed/pushedb06b8593; focused actual11/10/full local11 pass; full43765117358 active','Committed/pushed58eeea6f;12internal/682public each actual11/10;593source inputs verified;full43771040409 active')
s=s.replace('2026-11-15-formatting-final-sink/observations.tgz','2026-11-15-method-format-layout/observations.tgz')
s=s.replace("r/'quiet/additional.json'","r/'quiet/retrieved/additional.json'")
s=s.replace('lython-b810-fixtures','lython-b813-fixtures')
ast.parse(s);(r/'launch-checkpoint.py').write_text(s,encoding='utf-8',newline='\n')
