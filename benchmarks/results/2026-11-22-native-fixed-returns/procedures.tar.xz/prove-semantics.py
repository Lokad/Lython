from pathlib import Path
import copy,hashlib,json,os,subprocess

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
template=json.loads((lab/"representative.json").read_text(encoding="utf-8"))
seed=template["cases"][4]
scripts=[
    ("ordered-targets","""def produce(value):return 'new',value,value,9
def store(table,value):
    key='old'
    key,table[key],alias,number=produce(value)
    return table['new'] is alias,number,'old' in table
record={'old':None}
print(store(record,[]),store(record,[]),len(record))
"""),
    ("keyword-defaults","""def produce(*, value=None):return value,value,9
def consume(value):
    first,second,n=produce(value=value)
    return first is value,second is first,n
print(consume([]),consume({}))
"""),
    ("declined-arity","""calls=[]
def produce(value, count):
    calls.append(count)
    if count==0:return value,2,3
    if count==1:return (value,)
    return [value,2,3]
def consume(value,count):
    first,a,b=produce(value,count)
    return first is value,a+b
value=[]
for count in range(3):
    try:print(consume(value,count))
    except ValueError:print('arity')
print(calls)
"""),
    ("namespace-after-store","""def produce(value):return value,value,10
def consume(table,value):
    first,second,n=produce(value)
    table['ready']=first
    snapshot=locals()
    return snapshot['second'] is table['ready'],snapshot['n']
print(consume({'ready':False},[]))
"""),
    ("dynamic-hash","""events=[]
class Key:
    def __hash__(self):
        events.append('hash')
        return 5
def produce(value):
    return value,value
def store(table,key,item):
    first,second=produce(item)
    table[key]=first
    return second is item
d={}
key=Key()
print(store(d,key,[]),len(d),events)
"""),
    ("nested-depth","""def produce(i,payload):
    if i==0:return payload,0
    value,n=produce(i-1,payload)
    return value,n+1
payload=[]
value,n=produce(128,payload)
print(value is payload,n)
"""),
]
def sha(contents):return hashlib.sha256(contents.encode("utf-8")).hexdigest()
python="C:/Python313/python.exe"
cases=[]
fixture='{"size":1,"text":null}'
for label,source in scripts:
    oracle=subprocess.run([python,"-I","-S","-X","utf8","-"],input=source,text=True,
        encoding="utf-8",capture_output=True,timeout=12,check=True)
    assert not oracle.stderr and oracle.stdout
    case=copy.deepcopy(seed)
    case.update(id="diagnostic.nested-fixed-tuple."+label,size=1,source=source,sourceUtf8Bytes=len(source.encode("utf-8")),
        sourceSha256=sha(source),fixtureJson=fixture,fixtureSha256=sha(fixture),expectedOutput=oracle.stdout,
        expectedOutputUtf8Bytes=len(oracle.stdout.encode("utf-8")),expectedOutputSha256=sha(oracle.stdout))
    cases.append(case)
manifest=lab/"semantics.json"
manifest.write_text(json.dumps(dict(template,cases=cases),indent=2)+"\n",encoding="utf-8",newline="\n")
sdk=Path.home()/".dotnet11"
dotnet=sdk/"dotnet.exe"
env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk),PATH=str(sdk)+os.pathsep+os.environ["PATH"])
id=json.loads((lab/"identity.json").read_text(encoding="utf-8"))
for role,files in id["imageFiles"].items():
    image=lab/"frozen"/role
    assert len(files)==32 and {n:hashlib.sha256((image/n).read_bytes()).hexdigest() for n in files}==files
    verify=lab/f"{role}-semantics-verify.json"
    subprocess.run([dotnet,image/"Lokad.Lython.Benchmarks.dll","--compare","verify","--catalog",manifest,
        "--dotnet",dotnet,"--python",python,"--python-worker",repo/"benchmarks/cpython-worker.py","--out",verify],
        env=env,timeout=95,check=True)
    proof=json.loads(verify.read_text(encoding="utf-8"))
    assert proof["state"]=="Completed" and proof["caseCount"]==len(scripts)
    assert proof["catalogSha256"]==hashlib.sha256(manifest.read_bytes()).hexdigest()
print("Exact images match six independent Python goldens, including dynamic writes and nested depth.")
