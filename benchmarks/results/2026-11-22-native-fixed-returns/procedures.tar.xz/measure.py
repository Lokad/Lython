from pathlib import Path
import gzip, hashlib, json, os, shutil, statistics, subprocess

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
worktree = repo / ".git/agent-worktrees/native-fixed-return-20261122"
donor = lab.parent / "checked-augmented-local-20261122"
donor_quiet = donor / "quiet"
shape_donor = lab.parent / "module-helper-placement-20261122"
core = "Lokad.Lython.dll"

def read(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def save(path, obj):
    path.write_text(json.dumps(obj, ensure_ascii=False, indent=2)+"\n", encoding="utf-8", newline="\n")

base_id = read(donor_quiet / "identity.json")
reference = donor / "frozen/candidate"
files = base_id["imageFiles"]["candidate"]
assert len(files) == 32 and {n: sha(reference / n) for n in files} == files
assert gzip.decompress((repo / "benchmarks/results/2026-11-22-checked-augmented-local/candidate-core.dll.gz").read_bytes()) == (reference / core).read_bytes()
candidate = subprocess.check_output(["git","rev-parse","HEAD"],cwd=worktree,text=True).strip()
assert candidate.startswith("2ae6b61c9")
assert not subprocess.check_output(["git","status","--porcelain"],cwd=worktree)
assert "0 Error(s)" in (lab / "build-committed-win.log").read_text(encoding="utf-8")
assert all("Passed:   715," in (lab / f"public-{p}-final.log").read_text(encoding="utf-8") for p in ("win","ubuntu"))
build = worktree / "benchmarks/Lokad.Lython.Benchmarks/bin/Release/net11.0"
default_catalog = read(donor_quiet/"representative.json")
selected = {case["id"]:case for case in default_catalog["cases"]}
for path in (donor/"invoice.json",lab.parent/"construction-csv-cpython-20261122/quiet/representative.json",
    lab.parent/"post-range-cpython-20261122/quiet/representative.json"):
    for case in read(path)["cases"]: selected.setdefault(case["id"],case)
catalog=lab/"representative.json"
cases=[selected[n] for n in (
    "scripts.csv-invoice.helper-accumulation","scripts.csv-invoice.large",
    "scripts.csv-invoice.method-policy.quoted-control","scripts.json-lines-shipment.expanded-options.large",
    "diagnostic.helper-placement.function-call","diagnostic.helper-placement.module-call",
    "scripts.annotated-rule-closures.literal-positional-dynamic-keyword","scripts.csv-meter-report.typed-ascii")]
save(catalog,dict(default_catalog,cases=cases,performanceQualified=False))
out = lab / "frozen"
inspect = shape_donor / "inspect"
allocation = shape_donor / "allocation-worker"
sdk = Path.home() / ".dotnet11"
dotnet = sdk / "dotnet.exe"
protocol = repo / "benchmarks/cpython-worker.py"
assert sha(protocol) == read(donor_quiet/"config.json")["protocolSHA256"]
env = dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk),PATH=str(sdk)+os.pathsep+os.environ["PATH"])
hashes = {}
for label, source in (("reference",reference),("candidate",build)):
    image = out / label
    image.mkdir(parents=True)
    for name in files:
        shutil.copyfile((source if name == core else reference)/name,image/name)
    hashes[label] = {name:sha(image/name) for name in files}
    for name in ("Inspect.dll","Inspect.deps.json","Inspect.runtimeconfig.json"):
        shutil.copyfile(inspect/name,image/name)
    for name in ("ValidatedAllocation.dll","ValidatedAllocation.deps.json","ValidatedAllocation.runtimeconfig.json"):
        shutil.copyfile(allocation/name,image/name)
    verify = lab / f"{label}-verify.json"
    subprocess.run([dotnet,image/"Lokad.Lython.Benchmarks.dll","--compare","verify","--catalog",catalog,
        "--dotnet",dotnet,"--python","C:/Python313/python.exe","--python-worker",protocol,"--out",verify],
        env=env,timeout=95,check=True)
    proof=read(verify)
    assert proof["state"]=="Completed" and proof["caseCount"]==len(cases) and proof["catalogSha256"]==sha(catalog)
    subprocess.run([dotnet,image/"Inspect.dll",catalog,lab/f"{label}-shape.json"],env=env,timeout=45,check=True)
    subprocess.run([dotnet,image/"ValidatedAllocation.dll",image,catalog,lab/f"{label}-allocation.json"],env=env,timeout=95,check=True)
    assert {name:sha(image/name) for name in files}==hashes[label]
assert hashes["reference"]==files
assert [n for n in files if hashes["reference"][n] != hashes["candidate"][n]]==[core]
identity=dict(reference=base_id["sourceRevision"].split()[-1],deliveryReference="3d88c8095",candidate=candidate,imageFiles=hashes,catalogSHA256=sha(catalog))
save(lab/"identity.json",identity)

old_shape,new_shape = (read(lab/f"{label}-shape.json") for label in ("reference","candidate"))
assert old_shape["coreSHA256"]==files[core] and new_shape["coreSHA256"]==hashes["candidate"][core]
assert old_shape["rows"] == new_shape["rows"]
shape=dict(cases=len(cases),codeObjects=sum(len(row["codes"]) for row in old_shape["rows"]),sameExecutableShape=True)
save(lab/"shape-summary.json",shape)

old_alloc,new_alloc = (read(lab/f"{label}-allocation.json")["rows"] for label in ("reference","candidate"))
changes = []
for left,right in zip(old_alloc,new_alloc,strict=True):
    assert left["id"]==right["id"] and left["sharedBudgetBaselineRestored"] and right["sharedBudgetBaselineRestored"]
    a,b=[statistics.median(x["allocatedBytesPerInvocation"]) for x in (left,right)]
    row=dict(case=left["id"],referenceBytes=a,candidateBytes=b,allocationChangePercent=100*(b/a-1),
        referencePeak=left["peakExecutionMemoryBytes"],candidatePeak=right["peakExecutionMemoryBytes"],allowanceRestored=True)
    changes.append(row)
    print(row)
assert changes[0]["referenceBytes"] > changes[0]["candidateBytes"]
save(lab/"allocation-summary.json",changes)
