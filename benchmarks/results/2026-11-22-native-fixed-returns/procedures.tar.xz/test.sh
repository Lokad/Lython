#!/bin/bash
set -euo pipefail
cd /mnt/d/code/Lython/.git/agent-worktrees/native-fixed-return-20261122
export DOTNET_ROOT="$HOME/.dotnet"
export PATH="$DOTNET_ROOT:$PATH"
dir=/mnt/d/code/Lython/.git/agent-notes/review-20261031/native-fixed-return-20261122
white='Category!=Stress&(FullyQualifiedName~ExecutableCallFrame|FullyQualifiedName~OrdinaryFunctionTransport|FullyQualifiedName~ExecutableUnpacking|FullyQualifiedName~NativeOperationAllocation|FullyQualifiedName~TupleConstructionFailure|FullyQualifiedName~ExecutableAsyncIteratorCleanup|FullyQualifiedName~NativeIntegerChain|FullyQualifiedName~LocalAugmentedLifetime|FullyQualifiedName~NativeDictionary|FullyQualifiedName~UnpackingBufferAdmission)'
api='Category!=Stress&(FullyQualifiedName~OrdinaryUnpacking|FullyQualifiedName~NativeReturnFunction|FullyQualifiedName~ReturnedIteration|FullyQualifiedName~NativeReceiverPipeline|FullyQualifiedName~ProtectedHelperExecution|FullyQualifiedName~AdmissionFailureCommand|FullyQualifiedName~BoundCall|FullyQualifiedName~Frame|FullyQualifiedName~Augmented|FullyQualifiedName~DictionarySubscript|FullyQualifiedName~DictionaryMutation|FullyQualifiedName~HelperLocalLifetime)'
dotnet test tests/Lokad.Lython.Tests -c Release -f net10.0 --filter "$white" --artifacts-path /tmp/lython-native-return-b1367 > "$dir/white-ubuntu.log" 2>&1 || { tail -90 "$dir/white-ubuntu.log"; exit 1; }
dotnet test tests/Lokad.Lython.PublicApi.Tests -c Release -f net10.0 --filter "$api" --artifacts-path /tmp/lython-native-return-b1367 > "$dir/public-ubuntu.log" 2>&1 || { tail -90 "$dir/public-ubuntu.log"; exit 1; }
awk '/Passed!/' "$dir/white-ubuntu.log" "$dir/public-ubuntu.log"
