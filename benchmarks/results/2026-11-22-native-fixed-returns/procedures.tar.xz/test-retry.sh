#!/bin/bash
set -euo pipefail
cd /mnt/d/code/Lython/.git/agent-worktrees/native-fixed-return-20261122
export DOTNET_ROOT="$HOME/.dotnet"
export PATH="$DOTNET_ROOT:$PATH"
dir=/mnt/d/code/Lython/.git/agent-notes/review-20261031/native-fixed-return-20261122
white='Category!=Stress&(FullyQualifiedName~ExecutableCallFrame|FullyQualifiedName~OrdinaryFunctionTransport|FullyQualifiedName~ExecutableUnpacking|FullyQualifiedName~NativeOperationAllocation|FullyQualifiedName~TupleConstructionFailure|FullyQualifiedName~ExecutableAsyncIteratorCleanup|FullyQualifiedName~NativeIntegerChain|FullyQualifiedName~LocalAugmentedLifetime|FullyQualifiedName~NativeDictionary|FullyQualifiedName~UnpackingBufferAdmission)'
api='Category!=Stress&(FullyQualifiedName~OrdinaryUnpacking|FullyQualifiedName~NativeReturnFunction|FullyQualifiedName~ReturnedIteration|FullyQualifiedName~NativeReceiverPipeline|FullyQualifiedName~ProtectedHelperExecution|FullyQualifiedName~AdmissionFailureCommand|FullyQualifiedName~BoundCall|FullyQualifiedName~Frame|FullyQualifiedName~Augmented|FullyQualifiedName~DictionarySubscript|FullyQualifiedName~DictionaryMutation|FullyQualifiedName~HelperLocalLifetime)'
dotnet test tests/Lokad.Lython.PublicApi.Tests -c Release -f net10.0 --no-build --no-restore --filter "$api" > "$dir/public-ubuntu-final.log" 2>&1 || { tail -90 "$dir/public-ubuntu-final.log"; exit 1; }
awk '/Passed!/' "$dir/public-ubuntu-final.log"
