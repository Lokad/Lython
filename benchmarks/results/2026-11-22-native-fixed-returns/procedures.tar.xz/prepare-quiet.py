from pathlib import Path
import hashlib, json, shutil, subprocess, tarfile

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
template_lab = lab.parent/"signed-integer-kernel-20261122"
template = template_lab/"quiet"
donor = lab.parent/"checked-augmented-local-20261122"/"quiet"
out = lab/"quiet"

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def read(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))

def write(path, text):
    if path.suffix == ".py":
        compile(text, str(path), "exec")
    path.write_text(text, encoding="utf-8", newline="\n")

def save(path, data):
    write(path, json.dumps(data, indent=2)+"\n")

out.mkdir()
config = read(donor/"config.json")
receipt = read(donor/"archive-receipt.json")
assert receipt["complete"] and receipt["allWorkersJoined"] and receipt["archivedAndVerifiedUnderLease"]
assert sha(donor/"observations.tgz")==receipt["archiveSHA256"]
local = read(lab/"identity.json")
files = local["imageFiles"]
assert files["reference"]==config["identity"]["imageFiles"]["candidate"]
assert len(files["reference"])==len(files["candidate"])==32
for role in files:
    image=lab/"frozen"/role
    assert {n:sha(image/n) for n in files[role]}==files[role]
    p=read(lab/f"{role}-verify.json")
    assert p["state"]=="Completed" and p["caseCount"]==8 and p["catalogSha256"]==local["catalogSHA256"]
shutil.copyfile(lab/"representative.json",out/"representative.json")
assert sha(out/"representative.json")==local["catalogSHA256"]
core="Lokad.Lython.dll"
identity=dict(sourceRevision=local["reference"]+" versus "+local["candidate"],
    purpose="Keep eligible native callers through fixed tuple unpack and funded exact dictionary writes", imageFiles=files,
    normalAdapterPin="0.4.0",catalogSHA256=local["catalogSHA256"],
    coreSHA256={role+suffix:hashes[core] for role,hashes in files.items() for suffix in ("","-control")})
save(out/"identity.json",identity)
previous=read(template/"config.json")
root="/home/lokad/lython-bench-checks/native-fixed-return-b1367-20261122"
unit="lython-b1367-native-fixed-return-20261122"
cases=[case["id"] for case in read(out/"representative.json")["cases"]]
assert cases[-1]=="scripts.csv-meter-report.typed-ascii"
jobs=[(case,"warm" if "literal-positional" not in case else "compile-run") for case in cases[:-1]]
for name in ("collect.py","archive-owned.py","run.sh","retrieve.py"):
    source=(template/name).read_text(encoding="utf-8").replace(previous["root"],root).replace(previous["unit"],unit)
    if name=="collect.py":
        start,end=source.index("\njobs = "),source.index("\nassert len(jobs)")
        source=source[:start]+"\njobs = "+repr(jobs)+source[end:]
    write(out/name,source.replace("B1360","B1367"))
assert b"\r" not in (out/"run.sh").read_bytes()
(out/"candidate").mkdir()
shutil.copyfile(lab/"frozen/candidate"/core,out/"candidate"/core)
assert sha(out/"candidate"/core)==files["candidate"][core]
parts=("identity.json","collect.py","archive-owned.py","run.sh","representative.json","candidate/"+core)
payload=out/"payload.tgz"
with tarfile.open(payload,"w:gz") as archive:
    for name in parts:
        archive.add(out/name,arcname=name)
unpacked=sum((out/name).stat().st_size for name in parts)
diagnostic=lab.parent/"post-checked-local-call-profile-20261122"
storage=read(diagnostic/"archive-receipt.json")
assert storage["complete"] and sha(diagnostic/"observations.tgz")==storage["archiveSHA256"]
assert storage["freeBytes"]>176160768+unpacked+640*1024
stage=dict(root=root,unit=unit,identity=identity,source=config["root"],sourceRole="candidate",
    sourceFiles=files["reference"],sourceCatalogSHA256=config["catalogSHA256"],
    donorArchiveSHA256=receipt["archiveSHA256"],protocolSource=config["root"]+"/cpython-worker.py",
    protocolSHA256=config["protocolSHA256"],payloadBytes=payload.stat().st_size,
    payloadSHA256=sha(payload),retireGroups=[],catalogSHA256=identity["catalogSHA256"],unpackedBytes=unpacked)
save(out/"config.json",stage)
remote=(template/"remote-launch.py").read_text(encoding="utf-8")
start,end=remote.index("\nc=")+1,remote.index("\nb=Path(")
remote=remote[:start]+"c="+repr(stage)+remote[end:]
write(out/"remote-launch.py",remote.replace("lython-b1360-fixtures","lython-b1367-fixtures"))
write(lab/"launch.py",(template_lab/"launch.py").read_text(encoding="utf-8").replace("Signed integer kernel comparison","Nested fixed return comparison"))
write(lab/"summarize.py",(template_lab/"summarize.py").read_text(encoding="utf-8"))
(lab/"measured-source.patch").write_bytes(subprocess.check_output(["git","diff",local["reference"],local["candidate"],"--","src","tests"],cwd=repo))
print("Staged seven complete-script phases, exact source and both image goldens.")
