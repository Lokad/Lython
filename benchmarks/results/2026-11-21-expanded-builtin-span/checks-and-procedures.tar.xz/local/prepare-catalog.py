from pathlib import Path
import base64
import hashlib
import json
import runpy

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
def load(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))

def sha(text):
    return hashlib.sha256(text.encode("utf-8")).hexdigest()

def pack(raw):
    return base64.b64encode(raw).decode("ascii")

catalog = load(lab.parent / "native-dict-item-cursor/representative.json")
previous = catalog["cases"][0]
assert previous["id"] == "scripts.json-normalized-records.large"
source_fixture = json.loads(previous["fixtureJson"])
records = json.loads(base64.b64decode(source_fixture["inputFiles"]["records.json"]))
assert len(records) == previous["size"] == 3072
# An independently produced golden for all records, including Unicode strings.
serialized = "".join(json.dumps({"name": row["name"].strip(),
                                 "state": row["state"].upper(),
                                 "amount": row["amount"]},
                                ensure_ascii=False, separators=(",", ":")) + "\n"
                     for row in records).encode("utf-8")
fixture = json.dumps(dict(size=len(records), text=None, inputFiles=source_fixture["inputFiles"],
                          outputFiles={"shipments.jsonl": pack(serialized)}), separators=(",", ":"))
print_result = f'{len(records)} {sum(row["amount"] for row in records)}\n'
protocol = runpy.run_path(str(repo / "benchmarks/cpython-worker.py"))
file_digest = protocol["file_digest"]({"shipments.jsonl": serialized})

source = '''import json

with open("records.json", encoding="utf-8") as source:
    records = json.load(source)
options = {"ensure_ascii": False, "separators": (",", ":")}
encode = json.dumps
amount = 0
with open("shipments.jsonl", "w", encoding="utf-8", newline="") as target:
    for row in records:
        record = {"name": row["name"].strip(), "state": row["state"].upper(), "amount": row["amount"]}
        target.write(encode(record, **options) + "\\n")
        amount += record["amount"]
print(len(records), amount)
'''
sources = {"expanded-options": source, "explicit-options": source.replace(
    "encode(record, **options)", 'encode(record, ensure_ascii=options["ensure_ascii"], separators=options["separators"])')}
forwards = load(lab.parent / "format-operands/quiet/representative.json")["cases"][0]
assert forwards["id"] == "scripts.report-forwarding.expanded"
catalog["cases"] = [dict(previous, id=f"scripts.json-lines-shipment.{variant}.large",
                         source=body, fixtureJson=fixture, expectedOutput=print_result,
                         sourceUtf8Bytes=len(body.encode("utf-8")), sourceSha256=sha(body),
                         fixtureSha256=sha(fixture), expectedOutputSha256=sha(print_result),
                         expectedOutputUtf8Bytes=len(print_result.encode("utf-8")),
                         expectedFilesSha256=file_digest) for variant, body in sources.items()] + [forwards]
(lab / "representative.json").write_text(json.dumps(catalog, ensure_ascii=False, indent=2) + "\n",
                                         encoding="utf-8", newline="\n")
print(len(serialized), 'golden output bytes per JSON-lines workload.')
