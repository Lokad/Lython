from pathlib import Path
import json, os, subprocess
p=Path(os.environ["LYTHON_CASE_LAB"])
src=p.parent/"native-callback-entry"
groups=json.loads((p/"reclaim-proof.json").read_text(encoding="utf-8"))
print("Selected", sum(g["bytes"] for g in groups), "rebuildable bytes from",
      sorted({v.split("/")[0] for g in groups for v in g["paths"]}))
content=(src/"check-reclaim.py").read_text(encoding="utf-8").replace(
    "groups=json.load(sys.stdin)", "groups="+repr(groups))
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i',str(Path.home()/'.ssh/id_lython-bench.pem'),
     '-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73','python3 -']
response=subprocess.check_output(ssh,input=content.encode("utf-8"),timeout=40)
p.joinpath("reclaim-remote-audit.json").write_bytes(response)
audit=json.loads(response)
assert len(audit["checked"])==len(groups)
assert not any(item["errors"] for item in audit["checked"]), audit
groups = [g for g, item in zip(groups, audit["checked"], strict=True) if not item["missingRemoteArchives"]][:2]
assert groups, audit
p.joinpath("retire-verified.json").write_text(json.dumps(groups,indent=2)+"\n",encoding="utf-8",newline="\n")
print("All selected inode aliases and persistent archives verified under the VM lease.")
