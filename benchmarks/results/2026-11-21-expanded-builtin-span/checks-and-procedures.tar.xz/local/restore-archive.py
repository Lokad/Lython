from pathlib import Path
import base64, hashlib, json, subprocess

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
groups=json.loads((lab/'reclaim-proof.json').read_text(encoding='utf-8'))
audit=json.loads((lab/'reclaim-remote-audit.json').read_text(encoding='utf-8'))
checked={item["imageSHA256"]:item for item in audit["checked"]}
assert all(not item["errors"] for item in checked.values())
selected=sorted(groups, key=lambda group:len(checked[group["sha256"]]["missingRemoteArchives"]))[:2]
restores={}
sha=lambda data:hashlib.sha256(data).hexdigest()
for group in selected:
    for remote in checked[group["sha256"]]["missingRemoteArchives"]:
        expected=group["archives"][remote]
        restores[remote]=(expected,None,None)
paths=subprocess.check_output(["git","ls-files","-z","benchmarks/results"], cwd=repo).decode().split("\0")
for path in (path for path in paths if path.endswith("/observations.tgz")):
    data = (repo/path).read_bytes()
    found=sha(data)
    for remote,(expected,_,_) in tuple(restores.items()):
        if found==expected:
            committed=subprocess.check_output(["git","show","HEAD:"+path],cwd=repo)
            assert committed==data
            restores[remote]=expected,path,base64.b64encode(committed).decode("ascii")
assert all(path and payload for _,path,payload in restores.values()), restores.keys()
remote_body="""from pathlib import Path
import base64, fcntl, hashlib, json, os, shutil
base=Path('/home/lokad/lython-bench-checks').resolve()
verified={}
with (base/'comparison-vm.lock').open('a') as lease:
    fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
    for name,(expected,origin,payload) in restores.items():
        p=base/name
        assert p.is_relative_to(base) and p.resolve()==p and p.name=='observations.tgz'
        assert p.parent.parent==base and p.parent.is_dir()
        data=base64.b64decode(payload,validate=True)
        assert hashlib.sha256(data).hexdigest()==expected
        if not p.exists():
            assert shutil.disk_usage(base).free>176160768+len(data)
            with p.open('xb') as dst:
                dst.write(data); dst.flush(); os.fsync(dst.fileno())
        assert p.is_file() and hashlib.sha256(p.read_bytes()).hexdigest()==expected
        verified[name]={'sha256':expected,'committedPath':origin,'bytes':len(data)}
    print(json.dumps(verified,indent=2))
"""
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i',str(Path.home()/'.ssh/id_lython-bench.pem'),
     '-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73','python3 -']
output=subprocess.check_output(ssh,input=('restores='+repr(restores)+'\n'+remote_body).encode('utf-8'),timeout=40)
assert set(json.loads(output))==set(restores)
(lab/'archive-restaging.json').write_bytes(output)
(lab/'retire-verified.json').write_text(json.dumps(selected,indent=2)+'\n',encoding='utf-8',newline='\n')
print('Restored and verified',len(restores),'previously committed observations. No measured data removed.')
