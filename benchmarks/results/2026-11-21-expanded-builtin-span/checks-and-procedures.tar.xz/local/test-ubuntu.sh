#!/usr/bin/env bash
set -euo pipefail
repo=/mnt/d/code/Lython
cd "$repo/.git/agent-worktrees/expanded-builtin-span"
export DOTNET_ROOT="$HOME/.dotnet"
export PATH="$DOTNET_ROOT:$PATH"
logs="$repo/.git/agent-notes/review-20261031/expanded-builtin-span"
dotnet test tests/Lokad.Lython.PublicApi.Tests -c Release -f net10.0 --filter '(FullyQualifiedName~Json|FullyQualifiedName~ExpandedCall|FullyQualifiedName~BindingPlanConstruction|FullyQualifiedName~CallArgumentEvaluation|FullyQualifiedName~CallBinderAccounting|FullyQualifiedName~BuiltinCallbackLifetime|FullyQualifiedName~CallableInstanceProtocol)&Category!=Stress' -v quiet 2>&1 | tee "$logs/public-ubuntu.log"
dotnet test tests/Lokad.Lython.Tests -c Release -f net10.0 --filter '(FullyQualifiedName~Call|FullyQualifiedName~Json|FullyQualifiedName~MemoryAdmission)&Category!=Stress' -v quiet 2>&1 | tee "$logs/white-ubuntu.log"
