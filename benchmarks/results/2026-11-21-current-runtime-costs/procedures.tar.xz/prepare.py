from pathlib import Path
import hashlib, json, os, shutil, subprocess, tarfile

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
template = lab.parent / 'validator-manifest-current-profile'
donor = lab.parent / 'expanded-builtin-span'
catalog_source = lab.parent / 'shared-annotation-boundaries/representative.json'
core = 'Lokad.Lython.dll'
head = subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()
assert head.startswith('31abfeb3c')
assert not subprocess.check_output(['git','status','--porcelain'],cwd=repo)
def read(path): return path.read_text(encoding='utf-8')
def load(path): return json.loads(read(path))
def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
def emit(name,content):
    p=lab/name
    if p.suffix=='.py': compile(content,str(p),'exec')
    p.write_text(content,encoding='utf-8',newline='\n')
def save(name,value): emit(name,json.dumps(value,indent=2,ensure_ascii=False)+'\n')

stage=load(donor/'quiet/config.json')
receipt=load(donor/'quiet/archive-receipt.json')
assert receipt['complete'] and receipt['archivedAndVerifiedUnderLease'] and sha(donor/'quiet/observations.tgz')==receipt['archiveSHA256']
old=load(template/'config.json')
files=stage['identity']['imageFiles']['candidate']
frozen=donor/'frozen/candidate'
assert len(files)==32 and {name:sha(frozen/name) for name in files}==files
image=lab/'candidate'
image.mkdir()
for name in files:
    path=repo/'src/Lokad.Lython/bin/Release/net11.0'/name if name==core else frozen/name
    shutil.copyfile(path,image/name)
hashes={name:sha(image/name) for name in files}
assert [name for name in files if files[name]!=hashes[name]]==[core]
catalog=load(catalog_source)
jobs=[
    ('candidate-postponed-nested','scripts.annotated-rule-closures.nested-factories.postponed','warm'),
    ('candidate-validator','scripts.config-generated-guards.medium.bad-0','warm'),
    ('candidate-validator-compile','scripts.config-generated-guards.medium.bad-0','compile'),
]
all_cases = {row['id']:row for row in catalog['cases']}
catalog['cases'] = [all_cases[case] for case in dict.fromkeys(case for _,case,_ in jobs)]
save('catalog.json',catalog)
sdk=Path.home()/'.dotnet11'
dotnet=sdk/'dotnet.exe'
env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk),PATH=str(sdk)+os.pathsep+os.environ['PATH'])
protocol=repo/'benchmarks/cpython-worker.py'
subprocess.run([dotnet,image/'Lokad.Lython.Benchmarks.dll','--compare','verify','--catalog',lab/'catalog.json',
                '--dotnet',dotnet,'--python','C:/Python313/python.exe','--python-worker',protocol,'--out',lab/'verify.json'],
               check=True,cwd=repo,env=env,timeout=90)
verified=load(lab/'verify.json')
assert verified['state']=='Completed' and verified['catalogSha256']==sha(lab/'catalog.json')
assert {name:sha(image/name) for name in hashes}==hashes
identity=dict(sourceRevision=head,purpose='Current factory and validator CPU attribution',
              coreSHA256=dict(candidate=hashes[core]),imageFiles=dict(candidate=hashes),
              catalogSHA256=sha(lab/'catalog.json'),diagnosticOnly=True)
save('identity.json',identity)
root='/home/lokad/lython-bench-checks/current-runtime-costs-b1262-20261121'
unit='lython-b1262-current-runtime-costs-20261121'
labels=[label for label,_,_ in jobs]
for name in ('ops-profile.py','collect.py','launch.py','retrieve.py','run.sh','analyze.py'):
    source=read(template/name).replace(old['root'],root).replace(old['unit'],unit)
    source=source.replace('Validator and guarded manifest CPU attribution','Current factory and validator CPU attribution')
    if name=='ops-profile.py':
        a=source.index('    for name, case_id, lane in ')
        b=source.index('\n',a)
        source=source[:a]+'    for name, case_id, lane in '+repr(jobs)+':'+source[b:]
        source=source.replace('count = 2048','count = 512 if name.endswith("nested") else 2048').replace('total_capture_seconds > 24','total_capture_seconds > 30')
    elif name in ('collect.py','analyze.py'):
        source=source.replace("['candidate-validator', 'candidate-manifest']",repr(labels)).replace('len(records)==2','len(records)==3')
    emit(name,source)
assert b'\r' not in (lab/'run.sh').read_bytes()
names=('identity.json','catalog.json','ops-profile.py','collect.py','run.sh','candidate/'+core)
payload=lab/'payload.tgz'
with tarfile.open(payload,'w:gz') as out:
    for name in names: out.add(lab/name,arcname=name)
config=dict(root=root,unit=unit,source=stage['root'],sourceFiles=dict(candidate=files),sourceCatalogSHA256=stage['catalogSHA256'],
            catalogSHA256=identity['catalogSHA256'],identity=identity,retireGroups=[],payloadBytes=payload.stat().st_size,
            payloadSHA256=sha(payload),unpackedBytes=sum((lab/name).stat().st_size for name in names),donorArchive=receipt['archiveSHA256'])
save('config.json',config)
source=read(template/'remote-launch.py')
a,b=source.index('\nc=')+1,source.index('\nb=Path(')
source=(source[:a]+'c='+repr(config)+source[b:]).replace('lython-b1262-fixtures','lython-b1262-fixtures')
source=source.replace("os.link(source/role/n,p)","os.link(source/'candidate'/n,p)")
source=source.replace("+1048576", "+8*1024*1024")
emit('remote-launch.py',source)
