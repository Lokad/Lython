from pathlib import Path
import json,subprocess
lab=Path('.git/agent-notes/review-20261031/retained-trim-cpython-r640')
original=next(lab.glob('observation-*.json'))
status=json.loads(original.read_text(encoding='utf-8'))
assert status['exitCode']=='1' and status['receipt'] is None and not status['remainingWorkers']
assert status['remainingTrace'] and 'cpython-worker.py' in status['journal']
config=json.loads((lab/'config.json').read_text(encoding='utf-8'))
remote=r'''
from pathlib import Path
import fcntl,hashlib,json,os,subprocess
c=CONFIG
root=Path(c['root']); base=Path('/home/lokad/lython-bench-checks')
assert root.resolve()==root and root.parent==base
with (base/'comparison-vm.lock').open('a') as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 state=subprocess.check_output(['systemctl','show',c['unit']+'.service','--property=MainPID,ActiveState,SubState'],text=True)
 assert 'MainPID=0' in state and 'ActiveState=failed' in state
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record|[p]ython3.13.*cpython-worker.py'],capture_output=True).returncode==1
 assert (root/'exit-code.txt').read_text().strip()=='1'
 assert (root/'confirmation').is_dir() and not any((root/'confirmation').iterdir())
 assert hashlib.sha256((root/'cpython-worker.py').read_bytes()).hexdigest()==c['cpythonWorkerSHA256']
 fixture=root/'guest-fixtures';assert fixture.resolve()==fixture and os.path.ismount(fixture)
 files=[(p.relative_to(fixture).as_posix(),p.stat().st_size) for p in fixture.rglob('*')]
 assert not files,files
 subprocess.run(['sudo','-n','umount',str(fixture)],check=True);fixture.rmdir()
 print(json.dumps(dict(service=state,workersStarted=False,removedEmptyFixture=True,
     sameStagedCPythonWorker=True,liveFiles=[],fullOriginalSourceAndStatusPreserved=True)))
'''.replace('CONFIG',repr(config))
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i',str(Path.home()/'.ssh/id_lython-bench.pem'),'-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73','python3 -']
p=subprocess.run(ssh,input=remote.encode(),capture_output=True,timeout=40)
assert p.returncode==0,p.stderr.decode()
(lab/'original-fixture-cleanup.json').write_bytes(p.stdout)
print(p.stdout.decode().strip())
