from pathlib import Path
import ast, hashlib, json, os, re, shutil, subprocess, tarfile

lab=Path(__file__).resolve().parent
repo=Path.cwd()
prior=lab.parent/'retained-capture-cpython-r626'
donor=lab.parent/'trim-policy-scan-r634'
read=lambda p:p.read_text(encoding='utf-8-sig')
load=lambda p:json.loads(read(p))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def write(name,s):
    if name.endswith('.py'):ast.parse(s)
    (lab/name).write_text(s,encoding='utf-8',newline='\n')
def save(name,x):write(name,json.dumps(x,ensure_ascii=False,indent=2)+'\n')
old=load(donor/'quiet/config.json');receipt=load(donor/'quiet/archive-receipt.json')
files=old['identity']['imageFiles']['candidate'];frozen=donor/'frozen/candidate'
assert len(files)==32 and {name:sha(frozen/name) for name in files}==files
assert not subprocess.check_output(['git','diff','--name-only','12fabffb1','ac175cc27','--','src'])
assert load(Path('benchmarks/results/2026-11-19-trim-policy-scan/summary.json'))['cores']['candidate']==files['Lokad.Lython.dll']
assert receipt['complete'] and receipt['archivedAndVerifiedUnderLease']
cat=load(prior/'representative.json')
all_cases=cat['cases']+load(lab.parent/'detached-cells-confirmation-r631/catalog.json')['cases']
case_ids=['scripts.report-forwarding.expanded','scripts.retained-nonlocal-factories',
    'scripts.report-render.format-selectors.large','scripts.csv-invoice.large']
cat['cases']=[next(case for case in all_cases if case['id']==name) for name in case_ids]
save('representative.json',cat);catalog=lab/'representative.json'
shutil.copyfile(repo/'benchmarks/cpython-worker.py',lab/'cpython-worker.py')
script_hash=sha(lab/'cpython-worker.py')
identity=dict(sourceRevision='12fabffb1',purpose='Retained closure and trim checkpoint against CPython',
    imageFiles={'candidate':files},auxiliaryFiles={k:v for k,v in files.items() if k!='Lokad.Lython.dll'},
    coreSHA256={role:files['Lokad.Lython.dll'] for role in ('candidate','candidate-control')},
    catalogSHA256=sha(catalog),cpythonWorkerSHA256=script_hash,normalAdapterPin='0.4.0')
save('identity.json',identity)
sdk=Path.home()/'.dotnet11';dotnet=sdk/'dotnet.exe'
env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk),PATH=str(sdk)+os.pathsep+os.environ['PATH'])
with (lab/'verify.log').open('wb') as log:
    subprocess.run([dotnet,frozen/'Lokad.Lython.Benchmarks.dll','--compare','verify','--catalog',catalog,
        '--dotnet',dotnet,'--python',Path('C:/Python313/python.exe'),'--python-worker',lab/'cpython-worker.py',
        '--out',lab/'verify.json'],env=env,stdout=log,stderr=subprocess.STDOUT,timeout=120,check=True)
assert load(lab/'verify.json')['state']=='Completed' and load(lab/'verify.json')['catalogSha256']==sha(catalog)
assert {name:sha(frozen/name) for name in files}==files
root='/home/lokad/lython-bench-checks/retained-trim-cpython-b1069-corrected-20261119'
unit='lython-b1069-retained-trim-cpython-corrected-20261119'
prior_root=load(prior/'config.json')['root']
for name in ('collect.py','archive-owned.py','launch.py','retrieve.py','run.sh','collect-evidence.py'):
    source=read(prior/name).replace(prior_root,root).replace('B1057','B1069')
    if name=='collect.py':
        source, replacements = re.subn(r"hexdigest\(\)=='[0-9a-f]{64}'", "hexdigest()==identity['cpythonWorkerSHA256']", source)
        assert replacements==1, replacements
        a=source.index('    for case_id,diagnostic in ');b=source.index('\n',a)
        source=source[:a]+f'    for case_id,diagnostic in {[(case,False) for case in case_ids]!r}:'+source[b:]
        source=source.replace('started<485','started<350')
    elif name=='archive-owned.py':
        source=source.replace("len(raw['jobs'])==7","len(raw['jobs'])==4").replace('jobs=7,','jobs=4,').replace('208*1024*1024','174*1024*1024')
    elif name=='launch.py':source=source.replace('485','291')
    elif name=='retrieve.py':source=source.replace("['jobs']==7","['jobs']==4")
    elif name=='collect-evidence.py':
        source=source.replace('2026-11-19-retained-capture-cpython','2026-11-19-retained-trim-cpython')
        source=source.replace('receipt["jobs"] == 7','receipt["jobs"] == 4').replace('len(cases) == 7','len(cases) == 4')
        source=source.replace('{".json",".py",".sh",".log"}','{".json",".py",".sh",".log"}')
    write(name,source)

payload=lab/'payload.tgz'
names=['representative.json','identity.json','collect.py','archive-owned.py','run.sh','cpython-worker.py']
with tarfile.open(payload,'w:gz') as gz:
    for name in names:gz.add(lab/name,arcname=name)
config=dict(root=root,unit=unit,source=old['root'],sourceRole='candidate',sourceFiles=files,
    sourceCatalogSHA256=old['catalogSHA256'],catalogSHA256=sha(catalog),identity=identity,retireGroups=[],
    donorArchiveSHA256=receipt['archiveSHA256'],payloadBytes=payload.stat().st_size,payloadSHA256=sha(payload),
    unpackedBytes=sum((lab/name).stat().st_size for name in names),cpythonWorkerSHA256=script_hash)
save('config.json',config)
launcher=read(donor/'quiet/remote-launch.py')
a,b=launcher.index('\nc=')+1,launcher.index('\nb=Path(')
launcher=launcher[:a]+'c='+repr(config)+launcher[b:]
launcher=re.sub(r'lython-b[0-9]+-fixtures','lython-b1069-fixtures',launcher)
launcher=launcher.replace("for role in ['reference','candidate']:","for role in ['candidate']:")
assert launcher.count(" os.link(source/'cpython-worker.py',root/'cpython-worker.py')")==1
launcher=launcher.replace(" os.link(source/'cpython-worker.py',root/'cpython-worker.py')", " assert sha(root/'cpython-worker.py')==c['cpythonWorkerSHA256']")
launcher=launcher.replace('RuntimeMaxSec=540','RuntimeMaxSec=410')
write('remote-launch.py',launcher)
print('Verified all 32 image files and four CPython goldens. Sized the external refresh to the changed reports and existing controls.')
