from pathlib import Path
import json

out=Path('benchmarks/results/2026-11-19-retained-trim-cpython')
summary=json.loads((out/'summary.json').read_text(encoding='utf-8'))
assert summary['source']=='12fabffb1' and summary['collection']=='B1069'
labels={
 'scripts.report-forwarding.expanded':('Expanded forwarding report','1,024 records / 26,112 B'),
 'scripts.retained-nonlocal-factories':('Retained nonlocal siblings','240 factories / 720 returned closures'),
 'scripts.report-render.format-selectors.large':('Shipment report with format selectors','3,072 records / 189,441 B'),
 'scripts.csv-invoice.large':('CSV invoice','4,096 data records / 127,031 B'),
}
rows={(row['case'],row['lane']):row for row in summary['rows']}
assert set(rows)=={(case,lane) for case in labels for lane in ('compile','warm','compile-run')}

def format_range(values, digits):
    low,high=(f'{v:.{digits}f}' for v in values)
    return f'{low}–{high}' if low!=high else low

def metrics(row, lane):
    digits=5 if lane=='compile' else 3
    lython=format_range(row['lythonMs'],digits)
    cpython=format_range(row['cpythonMs'],digits)
    ratio=format_range(row['ratio'],2)
    lc,rc,iqr=(row[name] for name in ('lythonControlPercent','cpythonControlPercent','maxIQRPercent'))
    status=f'B1069 diagnostic. Controls L/C {lc:.2f} / {rc:.2f}%. IQR ≤{iqr:.2f}%.'
    if max(lc,rc,iqr)>5:
        status+= ' Gap size uncertain.'
    return f'{lython} ms | {cpython} ms | {ratio}× | {status}'

warm_header='| Workload / warm execution | Input | Lython | CPython | Lython / CPython | Measurement status |\n| --- | --- | ---: | ---: | ---: | --- |'
compile_header='| Workload | Phase | Lython | CPython | Lython / CPython | Measurement status |\n| --- | --- | ---: | ---: | ---: | --- |'
warm_rows='\n'.join(f'| {label} | {size} | {metrics(rows[(case,"warm")],"warm")} |' for case,(label,size) in labels.items())
phase_rows='\n'.join(f'| {label} | {phase} | {metrics(rows[(case,lane)],lane)} |' for case,(label,_) in labels.items()
    for lane,phase in (('compile','Compilation only'),('compile-run','Compile-to-result')))
source=(f'B1069 measured **12fabffb1 / frozen {summary["coreSHA256"][:8]}** on\n'
    '**2026-11-19 UTC** against stock **CPython 3.13.16** on the quiet **Azure\n'
    'F4as_v7**, with Ubuntu 24.04.4 and .NET 11 RC3. Four workloads ran all three\n'
    'phases on duplicate processes per engine. These figures describe that\n'
    'checkpoint. [B1069 observations](../benchmarks/results/2026-11-19-retained-trim-cpython/README.md).')
path=Path('docs/BENCHMARKS.md')
text=path.read_text(encoding='utf-8-sig')
a=text.index('| Workload / warm execution')
b=text.index('\n\n**Ratio',a)
prev_warm=text[a:b]
old_names={label for label,_ in labels.values()}
prev_warm='\n'.join(line for line in prev_warm.splitlines() if not any(line.startswith(f'| {name} |') for name in old_names))
text=text[:a]+warm_header+'\n'+warm_rows+text[b:]
a=text.index('Rule closures have the largest execution gaps')
b=text.index('B1057 measured ',a)
text=text[:a]+'\n'+source+'\n\n'+text[b:]
a=text.index('B1057 measured ')
b=text.index('Warm clocks include ',a)
older_identities=text[a:b].strip()
text=text[:a]+text[b:]
a=text.index('| Workload | Phase |')
b=text.index('\n\nCompilation includes',a)
prev_phases=text[a:b]
prev_phases='\n'.join(line for line in prev_phases.splitlines() if not any(line.startswith(f'| {name} |') for name in old_names))
text=text[:a]+compile_header+'\n'+phase_rows+text[b:]
text=text.replace('B1057 excludes cold startup. Earlier startup measurements use separate boundaries.',
    'B1069 excludes cold startup. Earlier startup measurements use separate boundaries.')
a=text.index('## Uncertainty and earlier measurements')
b=text.index('## Improvements within Lython',a)
prev_uncertainty=text[a+len('## Uncertainty and earlier measurements\n\n'):b].strip()
text=text[:a]+'''## Earlier measured workloads

These rows retain the sources and uncertainties of earlier measurements.

<details>
<summary>Earlier warm, compilation and compile-to-result observations</summary>

'''+prev_warm+'\n\n'+prev_phases+'\n\n'+older_identities+'\n\n'+prev_uncertainty+'\n\n</details>\n\n'+text[b:]
path.write_text(text,encoding='utf-8',newline='\n')
