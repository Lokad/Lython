using Lokad.Lython.Frontend;

namespace Lokad.Lython.Runtime;

internal static class PyFunctionBinding
{
    public static LythonRuntime.ExecutionContext EnterInvocationFrame(
        LythonRuntime.ExecutionContext closure,
        ScopeDirectiveFacts scopeFacts,
        FunctionBindingPlan bindingPlan,
        BoundFunctionArguments boundArguments,
        bool mirrorBoundArguments,
        PyType? ownerType,
        LythonSourceSpan span,
        bool enterFunctionCall = true)
    {
        var frame = new LythonRuntime.ExecutionContext(closure, scopeFacts);
        frame.FunctionName = bindingPlan.CallableName;
        frame.FirstPositionalParameterName = bindingPlan.PositionalCount == 0
            ? null : bindingPlan.NameAt(0);
        if (mirrorBoundArguments)
        {
            var layoutNames = bindingPlan.LayoutParameterNames;
            for (var i = 0; i < layoutNames.Count; i++)
            {
                frame.Variables[layoutNames[i]] = boundArguments.Values[i].Object!;
            }
        }

        // A module-root closure cannot supply a lexical class cell. Ordinary
        // module functions therefore need no receiver or class-cell discovery.
        // Owner binding can happen later, and nested scopes have live __class__
        // barriers, so keep their existing discovery and unavailable-super path.
        var needsImplicitSuper = ownerType is not null || closure.ParentContext is not null ||
            closure.ClassCell is not null || closure.IsClassBody;
        if (needsImplicitSuper && scopeFacts.RequiresClassCell && frame.FirstPositionalParameterName is not null)
        {
            if (frame.TryGetLexicalClassCell(out var classCell)) frame.BindImplicitSuper(classCell);
            else if (ownerType is not null || closure.TryGetLexicalClassCell(out _)) frame.BindUnavailableImplicitSuper();
        }

        if (enterFunctionCall) frame.EnterFunctionCall(span);
        return frame;
    }

    /// <summary>
    /// Joins enclosing function names for nested qualnames (o.[locals.]i).
    /// Class bodies and modules contribute no segment; methods compose the
    /// defining class at read time instead. Returns null at module scope.
    /// </summary>
    internal static string? EnclosingFunctionPath(LythonRuntime.ExecutionContext context)
    {
        string? path = null;
        for (var current = context; current is not null; current = current.ParentContext)
        {
            if (current.FunctionName is { } name)
            {
                path = path is null ? name : name + ".<locals>." + path;
            }
        }

        return path;
    }

    public static void AnnotateException(
        LythonRuntimeException exception,
        LythonRuntime.ExecutionContext frame,
        string callableName,
        LythonSourceSpan span)
    {
        exception.SetSourcePathIfMissing(frame.SourcePath);
        exception.AddFrame(callableName, span, frame.SourcePath);
    }

}
