from pathlib import Path
import hashlib,json,shutil,subprocess,tarfile
r=Path(__file__).parent;out=Path('benchmarks/results/2026-11-15-file-call-construction-assessment');out.mkdir()
identity=json.loads((r/'identity.json').read_text(encoding='utf-8'));a=json.loads((r/'attribution-file.json').read_text(encoding='utf-8'));receipt=json.loads((r/'archive-receipt.json').read_text(encoding='utf-8'))
assert hashlib.sha256((r/'observations.tgz').read_bytes()).hexdigest()==receipt['archiveSHA256']
assert a['samples']==746 and a['ambiguousLeafSamples']==0
sources=['src/Lokad.Lython/Runtime/'+name for name in ['PyExecutableFunction.cs','PyFunctionBase.cs','PyFunctionBinding.cs','LythonRuntime.Calls.Binding.cs','LythonRuntime.Executable.Calls.Invoke.cs','LythonRuntime.Executable.Calls.cs','LythonRuntime.Executable.NativePrefix.cs','ExecutionState.Guards.cs','ExecutionState.Host.cs','LythonRuntime.TextFileHandle.Read.cs','LythonRuntime.CsvModule.cs','LythonRuntime.CsvObjects.cs','PyDict.Records.cs','Text/PyString.cs']]
with tarfile.open(out/'source-and-analysis.tar.xz','w:xz')as archive:
 for name in sources:archive.add(name,arcname=name)
 for p in sorted(r.iterdir()):
  if p.is_file() and p.name not in {'observations.tgz','payload.tgz'}:archive.add(p,arcname='procedure/'+p.name)
source=dict(runtimeCommit=identity['runtimeCommit'],frozenCore=identity['coreSHA256']['candidate'],inspectionCommit=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),files={p:hashlib.sha256(Path(p).read_bytes()).hexdigest()for p in sources},runtimeEdited=False,performanceComparison=False)
(out/'source-identity.json').write_text(json.dumps(source,indent=2)+'\n',encoding='utf-8',newline='\n')
for name in ['observations.tgz','identity.json','prospective.json','archive-receipt.json','attribution-file.json','terminal-status.json','deduplication-receipt.json']:shutil.copyfile(r/name,out/name)
(out/'README.md').write_text('''# Complete file-search call/construction assessment

R377/B769, 2026-11-15, ec6c0416 / frozen6164a933. One5s cpu-clock/fp capture
at199Hz after8guest-seconds warmup, unchanged complete protected file-search
script. Diagnostic JIT/perf-map overrides are explicit. This is CPU attribution,
not an elapsed comparison, CPython refresh or removable-share estimate.

746 guest leaves /3.79guest CPU seconds;149unknown (121kernel), zero ambiguous.
Ordinary dispatch71, StartNativeCall61, NativeRunCore49, TryExecuteNativeCall46,
input dispatch42, ForNext32 and NativeCall30 are substantial leaves; StartInline20
and managed stack guard19 remain visible. Nearest owners include89admission,
52file/iteration and49comparison-host path-resolution leaves. Wider thread CPU,
including1.20s thread-pool work, remains in raw evidence. Buckets overlap and
contain useful/inlined work; no speedup follows by summing them.

## Actual construction and displacement assessment

The helper already consumes evaluated executable operands into final typed slots.
Small native calls use one fixed managed16-slot buffer; bound calls reuse their
funded local array. Direct receivers, definition-owned binding layout, live defaults,
deferred contexts and exact suspension transfer already exist. StartNativeCall
still initializes working storage and binds the keyword-only default in this script.
These are real costs; the profile does not isolate a removable whole activation.

An exception-shell-only edit is declined: NativeRun itself has6leaf samples and
its snapshot/context attachment also serves protected-body transfer and nested
handler state. Removing it alone would be another narrow change, with no evidence
of a substantial whole-script benefit. Do not remove body-local managed stack
admission or equate logical depth admission with sufficient stack at a deeper body.
Current guards and actual callback/suspension/cleanup boundaries remain intact.

No call arena, new controller, duplicate binder, tagged-value rewrite, cached mutable
defaults or arity-specific frame families are selected. Previous slower arena/control
designs retain their evidence. A coherent replacement must eliminate the full
activation/transport work, preserve isolation, aliases and live default changes,
and displace its original entry/cleanup implementation. The present capture is
useful evidence for that roadmap, not proof that existing costs are irreducible.

## Record and text source gate

The historical6–8%bulk CSV opportunity is already delivered: final capacity/ambient
construction, duplicate/custom/short/wide behavior, funded array adoption and shared
record keys remain. [Earlier source assessment](../2026-11-10-record-construction-assessment/README.md)
explains why replaying B74 would duplicate production code. Header identity walks
before/after admission remain necessary under reentry; no global list-version
infrastructure is introduced to avoid them.

The parser already compacts native input in its owned working buffer and admits
row/field construction together. FinishRecord still copies independent field
payloads. Most ordinary short fields fit inline8byte storage; a shared row payload
would retain aggregate capacity and add window shells for those fields. The
[withdrawn raw-range design](../2026-11-14-owned-csv-field-ranges/README.md) removed
a copy but added position state/raw syntax retention, with flat allocation and
weak whole-script benefit. It remains a contextual tradeoff, not a permanent ban.
Do not prototype another range inventory without a changed ownership/storage
argument and a representative workload exposing that remaining copy cost.

The source gate closes by declining these unsupported patches. The broader
performance objective remains active: whole activation/transport and long-field
construction are roadmap questions with explicit semantic and measurement gates,
not claimed completed optimizations. No runtime, API or dependency change here.

All identity/golden/quiet/join/archive gates pass; traces were persistently archived
and verified under lease before RAM unmount. Initial staging refused the unchanged
254MiB floor without mutation. Two exact committed archived raw JSON duplicates
were then deduplicated with fresh local/Git/remote/member/path/UID/link proofs;
all compressed originals/images/toolchains remain,254/252MiB floors unchanged.
Original refusal and corrected custody receipts are preserved. No VM users remain.
Full runtime43669461343qualification proceeds independently; publication held.
''',encoding='utf-8',newline='\n')
p=Path('benchmarks/EXPERIMENTS.md');s=p.read_text(encoding='utf-8');s+='''

R377/B769 [complete file-call/construction gate](results/2026-11-15-file-call-construction-assessment/README.md)
closes without a runtime patch. Current6164 image has746guest leaves/3.79CPU s,
149unknown/0ambiguous; entry/dispatch, I/O/host resolution and admission are mixed.
Final slots/direct binding/deferred contexts already exist. Exception-shell-only
deletion is not a substantial redesign; native body-local managed stack admission
remains. Historical bulkCSVopportunity is already delivered; raw-range/aggregate
payload proposals need a changed storage/lifetime argument. No fresh arena,
controller, cached mutable defaults or global list versioning follows. One usable
gate is closed, not the broader objective. Raw traces/failed floor preflight/corrected
exact-duplicate custody persist; all users/RAM closed, floors unchanged. No CPU
comparison, pin/API/runtime change or unchanged qualification. Publication held.
''';p.write_text(s,encoding='utf-8',newline='\n')
p=Path('PLAN.md');s=p.read_text(encoding='utf-8');s=s.replace('2. **Whole call/frame construction and operand transport: next design gate.**','2. **Whole call/frame construction and operand transport: redesign gate.**')
s=s.replace('Hypothesis: complete helper boundaries still repeat context, exception or','[R377 current file gate](benchmarks/results/2026-11-15-file-call-construction-assessment/README.md)\n   is complete:746guest leaves,149unknown, entry/dispatch/I/O/admission mixed.\n   Decline exception-shell-only deletion and arena replay; no substantial removable\n   activation is proved. Preserve this map rather than resampling unchanged code.\n   Hypothesis: complete helper boundaries still repeat context, exception or')
s=s.replace('remaining file/report/helper path on the current image before selecting a\n   redesign; do not repeat current text attribution.','remaining report/long-field shape only if it resolves a specific design question;\n   do not repeat current file/text attribution.')
s=s.replace('missed rigid thresholds, not semantics. Remove real remaining storage/transport,','missed rigid thresholds, not semantics; that opportunity is already delivered\n   ([reassessment](benchmarks/results/2026-11-10-record-construction-assessment/README.md)).\n   R377confirms inline8-byte fields make aggregate row-payload sharing a tradeoff,\n   not a missing optimization. Remove real remaining storage/transport,')
p.write_text(s,encoding='utf-8',newline='\n')
print('Current file/record source gate preserved; no unjustified runtime patch, broader objective remains open.')
