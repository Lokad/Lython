from pathlib import Path
import fcntl,hashlib,json,os,shutil,stat,subprocess,tarfile
proof=[{'commit': 'e5d27565ba9eab35dd3978b86c43e248a792f33c', 'canonicalArchive': 'benchmarks/results/2026-11-15-shared-slots-cpython-checkpoint/observations.tgz', 'remoteRoot': 'slots-cpython-b764-20261115', 'archiveSHA256': 'a30d5a34db5bf698fcb0a92a66eefc6828ed3916133d62cd7afc3e05fd50ba5d', 'member': 'confirmation/confirmation.json', 'bytes': 403860, 'sha256': '6d6204486451453ead5eb69724e510e59947b0d1328af9e31b9089c54aa54262'}]
required=21278
base=Path('/home/lokad/lython-bench-checks').resolve()
with(base/'comparison-vm.lock').open('a')as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record|[p]ython3.*cpython-worker.py'],capture_output=True).returncode==1
 assert not any(p.is_mount()for p in base.glob('*/guest-fixtures'))
 paths=[];observations=[]
 for item in proof:
  root=base/item['remoteRoot'];p=root/item['member'];archive=root/'observations.tgz'
  assert root.resolve()==root and p.resolve()==p and archive.resolve()==archive and p.is_relative_to(base)
  s=p.lstat();assert stat.S_ISREG(s.st_mode)and s.st_uid==os.getuid()and s.st_nlink==1 and s.st_size==item['bytes']
  assert hashlib.sha256(p.read_bytes()).hexdigest()==item['sha256']
  assert hashlib.sha256(archive.read_bytes()).hexdigest()==item['archiveSHA256']
  with tarfile.open(archive)as a:assert hashlib.sha256(a.extractfile(item['member']).read()).hexdigest()==item['sha256']
  assert(root/'exit-code.txt').read_text().strip()=='0'and json.loads((root/'archive-receipt.json').read_text())['complete']
  paths.append(p);observations.append(dict(path=str(p),uid=s.st_uid,inode=s.st_ino,links=s.st_nlink,bytes=s.st_size,archiveStillPresent=str(archive)))
 before=shutil.disk_usage(base).free
 assert before+sum(item['bytes']for item in proof)>254*1024*1024+32768
 for p in paths:p.unlink()
 receipt=dict(committedProof=proof,metadata=observations,allPathsMetadataAndRawArchiveHashesVerifiedBeforeMutation=True,idleLease=True,retiredOnlyDuplicateJson=[str(p)for p in paths],beforeFreeBytes=before,afterFreeBytes=shutil.disk_usage(base).free,compressedRawArchivesAndLocalGitEvidenceRetained=True,currentImagesCatalogsToolchainsAndFloorsUnchanged=True)
 (base/'b769-proved-archived-json-deduplication.json').write_text(json.dumps(receipt,indent=2)+'\n')
 print(json.dumps(receipt),flush=True)
