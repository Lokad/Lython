set -eu
export DOTNET_ROOT="$HOME/.dotnet"
lab="$PWD/.git/agent-notes/review-20261031/exact-utf8-copy-20261126"
mkdir "$lab/linux-python"
ln -s "$HOME/.local/bin/python3.13" "$lab/linux-python/python"
export PATH="$lab/linux-python:$DOTNET_ROOT:$PATH"
export LYTHON_DIFFTEST_PYTHON="$lab/linux-python/python"
python --version
dotnet build tools/LythonProbe/LythonProbe.csproj -c Release -f net10.0 --no-incremental > "$lab/probe-build-ubuntu10.log" 2>&1
dotnet test tests/Lokad.Lython.PublicApi.Tests/Lokad.Lython.PublicApi.Tests.csproj -c Release -f net10.0 --no-build --artifacts-path "$lab/delivery-ubuntu" --filter 'Category!=Stress&FullyQualifiedName~PythonComparisonTransportsLiteralUnicodeAsUtf8' > "$lab/probe-recheck-ubuntu10.log" 2>&1
tail -5 "$lab/probe-recheck-ubuntu10.log"
