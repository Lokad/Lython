"""Complete-script hosting parity through unchanged comparison workers/protocol."""
import contextlib, fcntl, hashlib, importlib.util, json, math, os, shutil
import statistics, subprocess, tempfile, time, signal
from pathlib import Path

root = Path(__file__).resolve().parent
dotnet = Path('/home/lokad/lython-bench-toolchains/dotnet/11.0.100-rc.3.26522.148/dotnet')
python = Path('/home/lokad/lython-bench-toolchains/cpython/3.13.16/bin/python3.13')
catalog = root / 'representative.json'
worker = root / 'candidate/Lokad.Lython.Benchmarks.dll'
spec = importlib.util.spec_from_file_location('protocol', root / 'cpython-worker.py')
protocol = importlib.util.module_from_spec(spec); spec.loader.exec_module(protocol)
cases = {c['id']: c for c in json.loads(catalog.read_text())['cases']}
manifest_hash = hashlib.sha256(catalog.read_bytes()).hexdigest()
identity = json.loads((root / 'identity.json').read_text())
assert set(identity['coreSHA256']) == {'reference','reference-control','candidate','candidate-control'}
out = root / 'confirmation'; out.mkdir(exist_ok=False)
jobs = [('scripts.annotated-rule-closures.nested-factories.postponed', 'warm'), ('scripts.annotated-rule-closures.nested-factories.postponed', 'compile-run'), ('scripts.annotated-rule-closures.nested-factories', 'warm')]

env = os.environ.copy(); env['DOTNET_ROOT'] = str(dotnet.parent)
owned_ram=root/'guest-fixtures';assert owned_ram.is_dir()
env['TMPDIR']=str(owned_ram);tempfile.tempdir=str(owned_ram)
assert os.stat(owned_ram).st_dev != os.stat('/tmp').st_dev
assert not any(k.startswith(('DOTNET_', 'COMPlus_')) and k != 'DOTNET_ROOT' for k in env)
env['DOTNET_PerfMapEnabled']='3'

cpu_frequency = os.sysconf('SC_CLK_TCK')
def process_cpu_ticks(pid):
    text=Path(f'/proc/{pid}/stat').read_text()
    fields=text[text.rfind(')')+2:].split()
    return int(fields[11])+int(fields[12])

class Worker:
    def __init__(self, label, case, lane, stack):
        self.label, self.case, self.lane, self.sequence = label, case, lane, 0
        self.folder = Path(tempfile.mkdtemp(prefix='lython-comparison-files-'))
        self.errors = tempfile.TemporaryFile(); self.process = None
        stack.callback(self.close)
        command = [str(dotnet), str(root/('candidate' if label.startswith('candidate') else 'reference')/'Lokad.Lython.Benchmarks.dll'), '--compare', 'worker', '--catalog', str(catalog)]
        self.process = subprocess.Popen(command, cwd=self.folder, env=env, stdin=subprocess.PIPE,
                                        stdout=subprocess.PIPE, stderr=self.errors)
        self.identity = protocol.read_frame(self.process.stdout)
        if self.identity is None:
            self.errors.seek(0)
            (out / f'startup-{case["id"]}-{lane}-{label}.stderr').write_bytes(self.errors.read())
            raise RuntimeError('Worker exited before Ready; stderr preserved')
        assert self.identity['status'] == 'Ready' and self.identity['catalogSha256'] == manifest_hash
        assert self.identity['protocolVersion'] == 2 and self.identity['timingBoundary'].startswith('command-v2:')
        if not label.startswith('CPython'):
            core = next(v for v in self.identity['libraries'] if Path(v['path']).name == 'Lokad.Lython.dll')
            assert core['sha256'].lower() == identity['coreSHA256'][label].lower()
            for name, sha in identity['imageFiles']['candidate'if label.startswith('candidate')else'reference'].items():
                library = next((v for v in self.identity['libraries'] if Path(v['path']).name == name), None)
                if library is not None: assert library['sha256'].lower() == sha
            assert not self.identity['serverGc'] and not any(v for k,v in self.identity['runtimeOverrides'].items() if k!='DOTNET_PerfMapEnabled')
        else:
            assert self.identity['gcEnabled'] and self.identity['gilEnabled']
            assert not self.identity['freeThreaded'] and not self.identity['debug']
            assert self.identity['executableSha256'] == hashlib.sha256(python.read_bytes()).hexdigest()
        self.request('verify', 2)
        self.first_verification_seconds = self.last_request_seconds
    def request(self, operation, count):
        request_started = time.monotonic()
        self.sequence += 1
        request = {k:self.case[k] for k in ['sourceSha256','fixtureSha256','expectedOutputSha256']}
        request.update(protocolVersion=protocol.PROTOCOL_VERSION, requestId=self.sequence, operation=operation,
                       caseId=self.case['id'], lane=self.lane, iterations=count)
        before_cpu=process_cpu_ticks(self.process.pid) if operation == 'batch' else 0
        protocol.write_frame(self.process.stdin, request)
        response = protocol.read_frame(self.process.stdout)
        if operation == 'batch': self.last_cpu_ticks=process_cpu_ticks(self.process.pid)-before_cpu
        self.last_request_seconds = time.monotonic()-request_started
        assert response['requestId'] == self.sequence and response['caseId'] == self.case['id']
        assert response['status'] == ('Equivalent' if operation == 'verify' else 'Completed'), response
        assert response['completedInvocations'] == count
        for k in ['sourceSha256','fixtureSha256','expectedOutputSha256']: assert response[k] == self.case[k]
        compile_batch = self.lane == 'compile' and operation == 'batch'
        assert response.get('actualOutputSha256') == (None if compile_batch else self.case['expectedOutputSha256'])
        assert response.get('actualFilesSha256') == (None if compile_batch else self.case.get('expectedFilesSha256'))
        return response
    def close(self):
        try:
            if self.process is not None:
                if self.process.poll() is None:
                    self.sequence += 1
                    protocol.write_frame(self.process.stdin, dict(protocolVersion=protocol.PROTOCOL_VERSION, requestId=self.sequence, operation='quit'))
                    assert protocol.read_frame(self.process.stdout)['status'] == 'Closed'
                code = self.process.wait(timeout=5)
                self.errors.seek(0); errors = self.errors.read()
                if errors: (out / f'{self.case["id"]}-{self.lane}-{self.label}.stderr').write_bytes(errors)
                assert code == 0, code
                assert not errors
        finally:
            if self.process is not None:
                if self.process.poll() is None: self.process.kill(); self.process.wait()
                self.process.stdin.close(); self.process.stdout.close()
            self.errors.close()
            assert self.folder.parent == Path(tempfile.gettempdir()) and self.folder.name.startswith('lython-comparison-files-')
            shutil.rmtree(self.folder)

def stop(*_):raise InterruptedError('Owned checkpoint stopped; join all users before cleanup.')
signal.signal(signal.SIGTERM,stop)

from warm_probe import dump, medians, observe, preserve_maps, sample_profile, warm

with (root.parent/"comparison-vm.lock").open("a") as lease:
    fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
    def gate(name):
        subprocess.run([str(dotnet),str(worker),"--compare","check-machine","--out",str(out/name)],env=env,check=True)
        assert json.loads((out/name).read_text())["gate"]["quiet"]
    time.sleep(5)
    gate("machine-before.json")
    (out/"fixture-filesystem.txt").write_text(subprocess.check_output(
        ["findmnt","-T",str(owned_ram),"-o","TARGET,SOURCE,FSTYPE,OPTIONS"],text=True))
    started=time.monotonic()
    record=dict(sourceRevision=identity["sourceRevision"],purpose=identity["purpose"],
        warmupSeconds=8,perfMapMode=3,frequency=199,performanceQualified=False,complete=False,jobs=[])
    report=out/"confirmation.json"
    dump(report,record)
    labels=["reference","candidate"]
    for index,(case_id,lane) in enumerate(jobs):
        if index % 2: labels.reverse()
        job_folder=out/f"job-{index}"
        job_folder.mkdir()
        job=dict(case=case_id,lane=lane,profiles=[])
        record["jobs"].append(job)
        pids={}
        try:
            with contextlib.ExitStack() as stack:
                workers=[]
                for label in labels:
                    w=Worker(label,cases[case_id],lane,stack)
                    workers.append(w)
                    pids[label]=w.process.pid
                counts=[1]*len(workers)
                warmed=[0.0]*len(workers)
                warmups={label:[] for label in labels}
                warm(workers,counts,warmed,8,warmups,0)
                job.update(identities={w.label:w.identity for w in workers},warmupBatches=warmups)
                for w,count in zip(workers,counts,strict=True):
                    job["profiles"].append(sample_profile(w,count,job_folder/("profile-"+w.label),cpu_frequency))
                after=observe(workers,counts,2,cpu_frequency)
                job.update(postProfileBatches=after,postProfileMedians=medians(labels,after))
        finally:
            if pids:job["retiredTemporaryMaps"]=preserve_maps(pids,job_folder/"maps")
        job["workersJoinedAndFixturesRemoved"]=True
        dump(report,record)
    time.sleep(5)
    gate("machine-after.json")
    record.update(complete=True,elapsedSeconds=time.monotonic()-started)
    dump(report,record)
    assert not list(owned_ram.iterdir())
    subprocess.run(["sudo","-n","umount",str(owned_ram)],check=True)
    owned_ram.rmdir()
    subprocess.run(["python3",str(root/"archive-owned.py")],check=True)
