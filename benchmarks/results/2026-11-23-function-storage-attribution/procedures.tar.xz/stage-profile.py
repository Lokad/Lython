
from pathlib import Path
import hashlib
import io
import json
import subprocess
import tarfile

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
old=lab.parent/"factory-and-text-attribution-20261122"
donor=lab/"refined-comparison"/"quiet"
out=lab/"profile"
quiet=out/"quiet"
quiet.mkdir(parents=True)
core="Lokad.Lython.dll"
sha=lambda b:hashlib.sha256(b).hexdigest()
def read(p):return json.loads(p.read_text(encoding="utf-8-sig"))
def gitshow(folder,name):
    return subprocess.check_output(["git","show",f"origin/master:benchmarks/results/{folder}/{name}"],cwd=repo)
def receipt(folder):
    info=json.loads(gitshow(folder,"archive-receipt.json"))
    assert all(info[k] for k in ("complete","allWorkersJoined","archivedAndVerifiedUnderLease"))
    assert sha(gitshow(folder,"observations.tgz"))==info["archiveSHA256"]
    return info["archiveSHA256"]
def write(path,text):
    if path.suffix==".py":compile(text,str(path),"exec")
    path.write_text(text,encoding="utf-8",newline="\n")
def save(path,data):write(path,json.dumps(data,indent=2)+"\n")

base1425="2026-11-23-function-optional-attributes"
base1419="2026-11-22-callable-checkpoint-cpython"
config=read(donor/"config.json")
identity=config["identity"]
manifest=json.loads(gitshow(base1425,"source.json"))
assert identity["imageFiles"]==manifest["imageFiles"]
assert len(identity["imageFiles"]["candidate"])==len(identity["imageFiles"]["reference"])==32
catalog=(donor/"representative.json").read_bytes()
assert sha(catalog)==identity["catalogs"]["representative.json"]["sha256"]
(quiet/"representative.json").write_bytes(catalog)
for role,files in identity["imageFiles"].items():
    image=donor.parent/f"frozen-{role}"
    assert {name:sha((image/name).read_bytes())for name in files}==files
    verify=read(donor.parent/f"{role}-verify.json")
    assert verify["catalogSha256"]==sha(catalog) and verify["state"]=="Completed" and verify["caseCount"]==7

profiles=[
    ("scripts.annotated-rule-closures.nested-factories.postponed","warm"),
    ("scripts.annotated-rule-closures.nested-factories.postponed","compile-run"),
    ("scripts.annotated-rule-closures.nested-factories","warm"),
]
archive1419=receipt(base1419)
with tarfile.open(fileobj=io.BytesIO(gitshow(base1419,"changed-image-files.tar.xz"))) as t:
    retired_core=t.extractfile(core).read()
digest=sha(retired_core)
assert digest==json.loads(gitshow(base1419,"source.json"))["imageFiles"]["candidate"][core]
assert digest not in {m[core] for m in identity["imageFiles"].values()}
aliases=(
    ("retained-current-cpython-b1419-20261122","candidate",archive1419),
    ("short-borrowed-text-probe-b1420-20261122","reference",receipt("2026-11-22-short-borrowed-text-probe")),
    ("future-validation-b1421-20261122","reference",receipt("2026-11-22-future-validation-single-walk")),
    ("factory-text-attribution-b1422-20261122","reference",receipt("2026-11-22-factory-text-attribution")),
)
retire=[dict(paths=[str(Path(d)/role/core).replace("\\","/")for d,role,_ in aliases],
             bytes=len(retired_core),sha256=digest,links=len(aliases),
             archives={d+"/observations.tgz":h for d,_,h in aliases})]
identity=dict(identity,purpose="Attribute B1425 postponed factory costs at warm and compile-to-result boundaries. Include eager warm control.")
root="/home/lokad/lython-bench-checks/function-storage-attribution-b1426-20261123"
unit="lython-b1426-function-storage-attribution-20261123"
save(quiet/"identity.json",identity)
for name in ("collect.py","run.sh","archive-owned.py","retrieve.py","warm_probe.py"):
    prof=read(old/"quiet/config.json")
    code=(old/"quiet"/name).read_text(encoding="utf-8").replace(prof["root"],root).replace(prof["unit"],unit)
    if name=="collect.py":
        a,b=code.index("\njobs = "),code.index("\nenv = ")
        code=code[:a]+"\njobs = "+repr(profiles)+"\n"+code[b:]
        code=code.replace('labels=["candidate","candidate-control"]','labels=["reference","candidate"]')
        code=code.replace('        job_folder=out/f"job-{index}"','        if index % 2: labels.reverse()\n        job_folder=out/f"job-{index}"')
    if name in ("archive-owned.py","retrieve.py"):
        code=code.replace("len(raw['jobs'])==2","len(raw['jobs'])==3").replace("jobs=2,","jobs=3,").replace("['jobs']==2","['jobs']==3")
    write(quiet/name,code.replace("Factory and text attribution","Function storage attribution"))
assert b"\r" not in (quiet/"run.sh").read_bytes()
parts=("identity.json","representative.json","collect.py","run.sh","archive-owned.py","warm_probe.py")
with tarfile.open(quiet/"payload.tgz","w:gz") as t:
    for name in parts:t.add(quiet/name,arcname=name)
payload=(quiet/"payload.tgz").read_bytes()
cfg={**config,"root":root,"unit":unit,"identity":identity,"source":config["root"],
     "sourceFiles":identity["imageFiles"]["reference"],"sourceRole":"reference",
     "sourceCatalogSHA256":sha(catalog),"donorArchiveSHA256":receipt(base1425),
     "retireGroups":retire,"payloadBytes":len(payload),"payloadSHA256":sha(payload),
     "unpackedBytes":sum((quiet/name).stat().st_size for name in parts)}
save(quiet/"config.json",cfg)
code=(donor/"remote-launch.py").read_text(encoding="utf-8")
a,b=code.index("\nc=")+1,code.index("\nb=Path(")
code=(code[:a]+"c="+repr(cfg)+code[b:])
code=code.replace("2*1024*1024,(before","5*1024*1024,(before")
code=code.replace("os.link(source/c['sourceRole']/n,p)","os.link(source/role/n,p)")
code=code.replace("b1425-fixtures","b1426-fixtures").replace("RuntimeMaxSec=490","RuntimeMaxSec=175")
write(quiet/"remote-launch.py",code)
code=(donor.parent/"launch.py").read_text(encoding="utf-8")
code=code.replace("seconds=430","seconds=117").replace("before 430 seconds","before 117 seconds").replace("Function optional metadata","Function storage attribution")
write(out/"launch.py",code)
code=(old/"analyze-vm.py").read_text(encoding="utf-8").replace('len(record["jobs"])==2','len(record["jobs"])==3')
code=code.replace('("candidate","candidate-control")','("reference","candidate")')
code=code.replace('dict(case=job["case"],profiles=','dict(case=job["case"],lane=job["lane"],profiles=')
write(out/"analyze.py",code)
print(identity["sourceRevision"],root,cfg["unpackedBytes"],flush=True)

