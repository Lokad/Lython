# Lokad.Lython 0.11.0

Updated2026-11-06. Git-ignored; never force-add. Publication/tagging postponed.
Objective: coherent simplification and substantial complete-script performance.
Allocation reductions, source gates and individual experiments do not complete it.

## Actual state

- Last fully qualified runtime **62141d4d**, combined R13C+R14. Terminal CI
  **42243450458** is GREEN/all8 Windows/Ubuntu, .NET11/.NET10, original Stress
  and installed-package gates. Cached in benchmarks/results/2026-11-06-dictionary-context/;
  never query it again. Earlier terminal qualifications remain cached.
- Local installed Release consumers pass actual.NET11RC3/.NET10.0.8; core has no
  runtime package dependencies and adapter is nonpackable. Current artifacts in
  artifacts/nuget/ belong to b6650f09; both installed consumers pass. No publish.
- **R17 committed 1e9f53a9**: text birth spans/unused interface/constructor funding flag
  removed. Both-target builds0warnings; focused328internal/1,122public per actual
  runtime pass. Full public.NET11 passes16,187; original internal4260PASS/1FAIL
  has its obsolete fixture corrected and targeted-passing, with original evidence
  preserved. R17+P01 platform/original Stress qualification is running as CI42258608463;
  local installed-package consumers pass both actual runtimes.
- Private immutable **dev44** range/token adapter:84internal/421public per actual
  runtime pass against62141d4d. Separate development qualification; normal0.4 pin
  unchanged. Native cursor working admission is now a private active prototype, not yet qualified.
- B346–B351 are terminal/archived/hash-verified, all users joined/fixtures removed.
  No live VM collection; CI42258608463 is active. No source timestamp restoration was used.

Evidence: benchmarks/EXPERIMENTS.md and benchmarks/results/. Prior plans, raw
handoffs and source-gate decisions remain under .git/agent-notes/review-20261031/.
docs/ is current implementation only; no transient material or separate README.

## P01 committed b6650f09: numeric Excel formats

Handoff integrated/removed; original retained privately. Direct first-section
classification replaces normalized strings and misleading substring/prefix tests.
Colors/conditions/locale metadata and literals no longer turn numbers or formula
caches into dates/durations. Exact elapsed tokens and existing epochs remain.
Long scans receive the active cancellation token; no regex dependency required.
CPython/openpyxl3.1.5 reference passes60rows/120cells and9real formats. Focused
Release169public/45internal per actual11/10 pass, including shared-budget cleanup.
Evidence benchmarks/results/2026-11-06-openpyxl-number-formats/. Batch R17+P01
platform/original Stress/installed packages now; no broader workbook redesign.

## R17 closeout: explicit text-operation provenance

Retain the deletion: PyString64→56B actual shells on both runtimes; one explicit
payload admission path, no value birth-span reference or unused governing marker.
Owners/capacities/cache rollback and conservative128B+capacity estimates remain.
Source-less internal helpers can have no span; public operations use their current
instruction and cannot replace an established first refusal.

B351140.60s, complete CSV warm/fresh plus text/JSON/report warm, normal GC/tiering,
unchanged workers/goldens/ownership/quiet/cleanup. CSV warm+0.64/+1.17%, fresh
−0.40/−2.72%; text+2.22/+1.59%, JSON−1.56/−1.65%, report−0.91/−4.13%.
Accept text's1.6–2.2% elapsed debt explicitly; control-limited cases and coarse
CPU ticks do not prove broad improvement. No unchanged timing replay scheduled.

Separate existing whole-job allocation diagnostic, both APIs: text−4.28%, CSV
helpers−2.67/−2.43%, JSON−3.37%, report−1.77/−1.75%, config−3.49/−3.48%.
It includes reset/checking; Windows elapsed is diagnostic. Original failed witness
and fixture conditions remain. No RSS/live-heap/host-latency claim. Preserve source
and evidence, operation-origin contract documented and committed; full delivery with P01.

## Next independent U03: native cursor working admission

Continue from the qualified private dev44 source, exact package/DLL identities
in benchmarks/results/2026-11-06-adapter-dev44/. Core owns Python-specific UTF8
names/ranges/windows, flags, errors and current-operation tokens; no backend edges.

Bridge CreateMatchCursor's native working allowance to one existing Lython
reservation in the cursor child owner. Admit native/capture-conversion overlap;
replace only the cursor subject-size working heuristic. No per-buffer ledger,
new owner subsystem, policy, tracing, retry, GC or background matching.
Refused admission must throw terminal LythonRegexException, not return false
and permit optional-storage fallback. Native users finish before refunds/disposal.
Retain the local token bridge: producer creation tokens still govern advances.

Keep one-shot heuristics for now: DetailedData has no working-owner override;
funded-program default working ownership can differ from Prepare's supplied owner.
Do not silently use the wrong account or emulate fullmatch by filtering search.
UTF8 name lookup does not replace complete name enumeration; string bridge stays
adapter-local. These precise missing APIs defer only affected final integration.
Development pins/bridges remain allowed; no automatic normal-pin/safety promotion.

Acceptance: independent program/working roots, current-token in-flight creation/
advance cancellation, first refusal/no later guest effects, retained snapshots/
cache/input funding, awaited cleanup and shared-budget reuse. Existing focused
checks both runtimes plus one short same-producer cursor comparison. Full adapter
qualification against immutable released packages when available. No sibling edits.

## Active B352 delivery measurement

Refresh the CPython matrix for committed b6650f09 (combined R13C/R14/R17/P01),
using existing workers/fixtures and two identical current controls. Add the existing
16-path small configuration edit to the four large scripts so compile-to-result
decisions include a small agent task. Compilation, warm and fresh remain separate.
15 jobs, 5s warmups/role and seven150ms rotated rounds; 450s owned supervisor,
no SSH during collection. Preserve adverse results and require quiet/full goldens/
funding/joins/fixture cleanup plus persistent verified archives before adoption.
No new framework, startup/RSS/host-tail or broad allocation claim. Source contract
and original conditions are frozen under .git/agent-notes/.../delivery-comparison-b352/.
This is a coherent delivery refresh, not another unchanged R17 source-pair retime.

## Whole-script roadmap: source facts and stopping criteria

Primary docs/BENCHMARKS.md still measures **9a152ee0/B347**, not R17/HEAD: fresh
Lython/CPython CSV1.37–1.38x, text1.88–1.94x, JSON1.20–1.24x, report1.46–1.51x.
Compilation, warm execution and fresh are separate. Mediated RAM I/O, complete
validation and prior-result cleanup included; fresh adds compile/disposal.
Startup/staging/reset/transport/final teardown excluded. Actual suspended-I/O,
embedding latency and RSS remain unmeasured. Refresh the representative matrix
after the next substantial retained runtime redesign, not after every small edit.

- Calls/frames: final argument/local storage, separate receiver/function, shared
  instruction engine and deferred lexical contexts already exist. Text/JSON/report
  helpers already use NativeReturn. No new CFG inventory, copy arena or context swap.
- Operand transport: ForwardValues already folds adjacent immutable constants and
  proved initialized locals; adjacent local-result publication is fused. Preserve
  failable read order, liveness fences and pending cleanup. Do not recreate it.
- Imports/lambdas: already executable (imports840621405); keep real lowered class/
  annotation/opcode consumers. Fixed immutable builtin definitions/signatures are
  already shared; mutable per-run type objects must remain isolated.
- Record/text: bulk CSV field admission, direct parser input and fused casing/split
  exist. Typical text lines do not spill range scratch. Shared string payloads/
  windows and owner-capacity credit admission were tried with actual adverse and
  uncertain conditions; see history before reopening. No renamed repetitions.
- R16 scalar convention is deferred:45 direct BigInteger tests plus production,
  protocols/hash/identity/native proofs/canonical projection need one convention.
  Current samples do not justify an extra scalar subsystem or a lone long path.

Next non-regex design must identify actual eliminated work/storage and displaced
code across representative scripts before coding. Reuse current captures/source;
bounded new measurements only for a specific missing observation. Semantic checks
include closures/classes/generators, order/errors, refusal/cancellation, ownership
and real suspension. One short controlled source pair decides benefit/debt; larger
qualified milestones follow. No new framework or open-ended ownership/profile audit.
The performance objective remains open even when P01/U03 or R17 is complete.

## Completed milestones to preserve

| Delivered | Current result / historical evidence |
| --- | --- |
| Compiler facts, UTF8 formatting/storage, native returns | Class-cell/shared-fact corrections retained. Native returns allocation−19.92/−19.31%; formatting−8.67%, controlledB102 elapsed/CPU−5–8%; original adverse15.125ms remains unexplained. Qualified historical source pairs, not current-head claims. |
| K01, F02–F05, Q01/Q02, R02–R10 | Canonical dict/set storage; explicit ownership; final call/local slots; lexical facts; native iteration/text; actual builtin class patterns; contextual hash/async reads; class extraction/construction/common frame runner. No restored weak/scalar/collector machinery or duplicate backends. |
| R12/R13 | Allocation origins selected context work; frame base/constructors removed. One work state and instruction switch; context promotion adopts current IP/locals without replay. Native writes promote before growth/admission. Shared owned publication preserves NoInlining/lifetime fixes. |
| R14 | Explicit dictionary provenance, native no-growth writes and structural/protocol scopes; cancellation restores outer provenance. Combined source62141d4d fully qualified. |
| R15/R16 gates | Duplicate CSV input-copy/split-spill proposals and new scalar representation deferred on current evidence. This is a decision, not implementation or a permanent ban. |

## Working constraints

Timeouts/unstable controls/inconclusive observations establish uncertainty. Allow
bounded confirmation/refinement/correction for a stated reason; retain adverse
data and original conditions. Percentages inform rather than automatically veto.
Distinguish architectural deletion, physical allocation and measured CPU gains.

Follow AGENTS.md: fully managed/memory-safe, no unsafe/Unsafe/pointers/PInvoke/native
stack probing. Keep managed stack/recursion, host mediation/paths, cycles, active
CancellationToken and shared admission/capacity/replacement/retained aliases.
First refusal fails the command; no retry/fallback/optional-storage recovery.
No fuel, quotas, hidden caps/default allowance, tracing, weak reclamation or forced
GC. Await actual users/cleanup; initial streaming uses bounded host executions.

Use focused Release checks; batch both-platform/runtime/original Stress/package
qualification at delivery. No overlapping local builds/tests. Nonincremental build
after timestamp-preserving source restoration; reuse valid/cached qualification.
Quiet VM lokad@20.166.121.73, key~/.ssh/id_lython-bench.pem: lease, loaded hashes,
quiet/full-golden/funding/joins and persistent verified archives mandatory. Disk
nearly full; preflight. Remove only verified redundant owned transfers with retained
copies/terminal users, never sole evidence/dependencies/runtime images. No publication.
