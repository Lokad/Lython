from pathlib import Path
import ast,fcntl,hashlib,json,shutil,subprocess,tarfile
root=Path('/home/lokad/lython-bench-checks/delivery-comparison-b352-20261106');payload=root.parent/'b352-payload.tgz'
with (root.parent/'comparison-vm.lock').open('a') as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert not root.exists()
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record'],capture_output=True).returncode==1
 assert not list(Path('/dev/shm').glob('lython-comparison-files-*'))
 expected=json.loads((root.parent/'b352-transfer.json').read_text())
 assert hashlib.sha256(payload.read_bytes()).hexdigest()==expected['payloadSHA256']
 with tarfile.open(payload) as t:
  assert shutil.disk_usage(root.parent).free>sum(m.size for m in t.getmembers())+6*1024*1024
  root.mkdir();t.extractall(root,filter='data')
 for n in ['setup.py','collect.py','archive-owned.py']:ast.parse((root/n).read_text())
 assert b'\r' not in (root/'run.sh').read_bytes()
 subprocess.run(['/bin/sh','-n',str(root/'run.sh')],check=True)
 subprocess.run(['python3',str(root/'setup.py')],check=True)
subprocess.run(['sudo','-n','systemd-run','--unit=lython-b352-delivery-comparison-20261106','--property=User=lokad','--property=WorkingDirectory='+str(root),'--property=RuntimeMaxSec=450','--property=TimeoutStopSec=30','--property=KillMode=control-group','/bin/sh',str(root/'run.sh')],check=True)
