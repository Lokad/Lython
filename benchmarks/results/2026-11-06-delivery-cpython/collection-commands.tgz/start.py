from pathlib import Path
import hashlib,json,subprocess,tarfile
root=Path(__file__).parent;sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
repo=Path('D:/code/Lython')
p=repo/'PLAN.md';s=p.read_text(encoding='utf-8');marker='## Whole-script roadmap: source facts and stopping criteria'
s=s.replace(marker,'''## Active B352 delivery measurement

Refresh the CPython matrix for committed b6650f09 (combined R13C/R14/R17/P01),
using existing workers/fixtures and two identical current controls. Add the existing
16-path small configuration edit to the four large scripts so compile-to-result
decisions include a small agent task. Compilation, warm and fresh remain separate.
15 jobs, 5s warmups/role and seven150ms rotated rounds; 450s owned supervisor,
no SSH during collection. Preserve adverse results and require quiet/full goldens/
funding/joins/fixture cleanup plus persistent verified archives before adoption.
No new framework, startup/RSS/host-tail or broad allocation claim. Source contract
and original conditions are frozen under .git/agent-notes/.../delivery-comparison-b352/.
This is a coherent delivery refresh, not another unchanged R17 source-pair retime.

'''+marker)
p.write_text(s,encoding='utf-8');(root/'pre-measurement-plan.md').write_text(s,encoding='utf-8')
with tarfile.open(root/'payload.tgz','w:gz') as a:
    for name in ['Lokad.Lython.dll','identity.json','source.patch','source-snapshot.tgz','representative.json','focused-results.json','pre-measurement-plan.md','contract.md','setup.py','collect.py','run.sh','cpython-worker.py','archive-owned.py']:a.add(root/name,arcname=name)
with tarfile.open(root/'payload.tgz') as a:expanded=sum(m.size for m in a.getmembers())
transfer={'payloadBytes':(root/'payload.tgz').stat().st_size,'payloadSHA256':sha(root/'payload.tgz'),'expandedBytes':expanded,'requiredFreeBeforeTransfer':(root/'payload.tgz').stat().st_size+expanded+6*1024*1024}
(root/'transfer.json').write_text(json.dumps(transfer,indent=2)+'\n',encoding='utf-8')
items=[]
for local,folder,name in [(root.parent/'whole-script-cost-r14/b350','native-dictionary-context-b350-20261106','b350-payload.tgz'),(root.parent/'text-provenance-r17/b351','text-operation-provenance-b351-20261106','b351-payload.tgz')]:
    receipt=json.loads((local/'archive-receipt.json').read_text(encoding='utf-8'))
    assert receipt['complete'] and receipt['allWorkersJoined']
    assert sha(local/'observations.tgz')==receipt['archiveSHA256']
    expected=json.loads((local/'transfer.json').read_text(encoding='utf-8'))
    assert sha(local/'payload.tgz')==expected['payloadSHA256']
    items.append({'filename':name,'folder':folder,'payloadSHA256':expected['payloadSHA256'],'archiveSHA256':receipt['archiveSHA256']})
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
cleanup='''from pathlib import Path
import fcntl,hashlib,json,shutil,subprocess
root=Path('/home/lokad/lython-bench-checks')
items=ITEMS
with (root/'comparison-vm.lock').open('a') as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record'],capture_output=True).returncode==1
 assert not list(Path('/dev/shm').glob('lython-comparison-files-*'))
 for item in items:
  p=root/item['filename'];r=json.loads((root/item['folder']/'archive-receipt.json').read_text())
  assert r['complete'] and r['allWorkersJoined']
  assert hashlib.sha256((root/item['folder']/'observations.tgz').read_bytes()).hexdigest()==item['archiveSHA256']
  assert not p.is_symlink() and p.resolve().parent==root
  assert hashlib.sha256(p.read_bytes()).hexdigest()==item['payloadSHA256']
 for item in items:(root/item['filename']).unlink()
 print(json.dumps({'removedVerifiedRedundantTransfers':items,'freeBytes':shutil.disk_usage(root).free}))
'''.replace('ITEMS',repr(items))
r=subprocess.run([*ssh,'python3 -'],input=cleanup,text=True,encoding='utf-8',capture_output=True)
(root/'transfer-cleanup.log').write_text(r.stdout+r.stderr,encoding='utf-8');assert r.returncode==0,r.stderr
assert json.loads(r.stdout)['freeBytes']>transfer['requiredFreeBeforeTransfer']
scp=['C:/Windows/System32/OpenSSH/scp.exe','-i',ssh[2],'-o','BatchMode=yes','-o','ConnectTimeout=15']
for local,target in [('payload.tgz','b352-payload.tgz'),('transfer.json','b352-transfer.json'),('launch.py','b352-launch.py')]:
    r=subprocess.run([*scp,str(root/local),'lokad@20.166.121.73:/home/lokad/lython-bench-checks/'+target],capture_output=True,text=True,encoding='utf-8')
    assert r.returncode==0,r.stderr
r=subprocess.run([*ssh,'python3 /home/lokad/lython-bench-checks/b352-launch.py'],capture_output=True,text=True,encoding='utf-8')
(root/'launch.log').write_text(r.stdout+r.stderr,encoding='utf-8');print(r.stdout+r.stderr,flush=True);assert r.returncode==0
