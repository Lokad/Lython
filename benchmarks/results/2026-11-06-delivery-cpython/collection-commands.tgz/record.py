from pathlib import Path
import hashlib,json,shutil,tarfile
root=Path(__file__).parent;out=Path('benchmarks/results/2026-11-06-delivery-cpython');out.mkdir()
summary=json.loads((root/'summary.json').read_text(encoding='utf-8'))
ciroot=root.parent/'openpyxl-number-formats'
ci=json.loads((ciroot/'ci-final-candidate.json').read_text(encoding='utf-8-sig'));assert ci['status']=='completed' and ci['conclusion']=='success' and ci['headSha'].startswith('b6650f09')
assert len(ci['jobs'])==2 and all(j['conclusion']=='success' for j in ci['jobs'])
for name in ['identity.json','summary.json','archive-receipt.json','terminal-status.json','contract.md','observations.tgz']:shutil.copyfile(root/name,out/name)
(out/'delivery-ci.json').write_text(json.dumps(ci,indent=2)+'\n',encoding='utf-8')
with tarfile.open(out/'collection-commands.tgz','w:gz') as a:
    for p in sorted(root.iterdir()):
        if p.is_file() and p.name not in ['Lokad.Lython.dll','payload.tgz','catalog-full.json','catalog-representative.json','observations.tgz']:a.add(p,arcname=p.name)
    a.add(ciroot/'package-consumer.log',arcname='installed-package-consumer.log')
(out/'README.md').write_text('''# CPython comparison — coherent b6650f09 delivery

2026-11-06. Fully qualified runtime b6650f09 (R13C/R14/R17/P01); current-source
core54b53c7f matches the explicitly packed/installed-consumer package. Auxiliary
workerb94fa98c and normal0.4 adapter stay frozen/unchanged; private dev44 work is
outside these images. Exact identities, source snapshots and patches are in the
archives. This measures the combined delivery, not each constituent's CPU benefit.

Five existing scripts, three separate boundaries: compile/dispose, warm, and
compile-to-result in an already-running host. Same prior four large script/fixture
bytes plus existing small configuration edit(16paths,181B). CPython3.13.16 plus two
independent identical current Lython roles, normal GC/tiering. Five-second warmup
per role/job; seven rotated150ms samples.15jobs finish311.43s. Quiet endpoints,
full output/file checks, zero terminal balances, Closed/joins and fixture cleanup
pass. Persistent raw archive was created/hash-verified under the owned VM lease;
all processes are terminal. No repeated service query is needed.

Fresh Lython/CPython: CSV1.31x, text1.75–1.83x, JSON1.12x, report1.44–1.46x,
small config1.21–1.22x. Warm:1.34–1.39/1.80–1.82/1.18–1.20/1.59–1.60/1.29–1.31x.
Text fresh has4.44% identical-role difference; warm CSV3.50%. Report spread remains
variable. Preserve those observations, not a single optimistic point. Compile-only
is reported independently; do not subtract separate warm/fresh medians (JSON fresh
is slightly below warm in these distinct job blocks). Historical source-pair debts,
including R17's adverse text result and earlier formatting disagreement, remain.
This refresh cannot establish their cause or an additive speedup for the combined
changes. Exact process-CPU ticks are preserved; they are coarse/overlapping across
threads and are not guest-only or source-pair CPU attribution.

Includes mediated RAM-file I/O, full validation and previous-result cleanup;
fresh adds compilation/program disposal. Startup, fixture staging/reset, transport
and final teardown excluded. CPython keeps imported modules; Lython imports are
isolated per execution. Startup/RSS/embedding-tail/genuinely suspended-I/O latency
remain unmeasured. The reusable docs/BENCHMARKS.md guide records all three tables.

Separate delivery CI42258608463 completed GREEN: Windows/Ubuntu, actual.NET11/10,
original Stress and installed packages. Local installed consumers pass both
runtimes; core has zero runtime package dependencies and adapter is nonpackable.
This closes R17/P01 runtime qualification; publication/tagging remain postponed.

VM disk preflight required removal of two exact redundant payload transfer files.
Both retained local payloads and persistent raw archives were hash-verified before
unlinking; expanded images/dependencies and sole evidence were preserved. All
commands/failed or adverse conditions and cleanup proof remain archived here.
''',encoding='utf-8')
# One maintained primary comparison; older source pairs remain linked separately.
p=Path('docs/BENCHMARKS.md');old=p.read_text(encoding='utf-8');tail=old[old.index('## Improvements within Lython'):]
new='''# Performance against CPython

| Workload | Input | Lython | CPython | Lython / CPython | Measurement status |
| --- | --- | ---: | ---: | ---: | --- |
| CSV summary/ordinary helper | 4,096 records / 57,361 B | 4.446–4.451 ms | 3.403 ms | 1.31× | Diagnostic; control / IQR 0.12% / 0.55% |
| Text summary/helpers | 3,072 lines / 35,840 B | 2.220–2.324 ms | 1.267 ms | 1.75–1.83× | Variable; control / IQR 4.44% / 0.67% |
| JSON-lines/helpers | 4,096 records / 110,592 B | 4.750–4.765 ms | 4.238 ms | 1.12× | Diagnostic; control / IQR 0.31% / 0.68% |
| JSON-to-Markdown report | 3,072 records / 189,441 B | 3.929–3.963 ms | 2.720 ms | 1.44–1.46× | Variable; control / IQR 0.86% / 3.49% |
| Configuration read/edit/write | 16 paths / 181 B | 149.097–149.807 µs | 122.946 µs | 1.21–1.22× | Diagnostic; control / IQR 0.47% / 2.32% |

**2026-11-06; 0.11 development runtime source `b6650f09`; CPython 3.13.16; .NET 11 RC3.**
These are **compilation plus one execution in an already-running host**, including
mediated RAM-file I/O, complete validation and prior-result cleanup. Startup and
fixture staging/reset are excluded. **Ratio=Lython elapsed/CPython elapsed; above
one means slower.**

Ranges are medians from two independent identical-build processes, not confidence
intervals. Control is their absolute difference relative to candidate; IQR is the
larger Lython-role interquartile range/median. Text fresh and report remain variable.
These measurements describe the recorded source, not future HEAD. Frozen core
`54b53c7f` matches the explicitly packed/installed Release package; this runtime
also passed Windows/Ubuntu, both runtimes and original Stress. Private development
regex adapters are outside the comparison.
[Identity, observations and qualification](../benchmarks/results/2026-11-06-delivery-cpython/README.md).

## Warm execution, compilation and startup

Same source/input and execution/I/O/validation/cleanup boundary, reusing compiled code:

| Warm workload | Lython | CPython | Ratio | Current control / Lython IQR |
| --- | ---: | ---: | ---: | --- |
| CSV summary/ordinary helper | 4.354–4.512 ms | 3.244 ms | 1.34–1.39× | 3.50% / 1.15% |
| Text summary/helpers | 2.143–2.164 ms | 1.188 ms | 1.80–1.82× | 0.95% / 0.30% |
| JSON-lines/helpers | 4.816–4.905 ms | 4.097 ms | 1.18–1.20× | 1.81% / 0.85% |
| JSON-to-Markdown report | 3.769–3.808 ms | 2.375 ms | 1.59–1.60× | 1.02% / 4.77% |
| Configuration read/edit/write | 77.968–79.123 µs | 60.257 µs | 1.29–1.31× | 1.48% / 1.45% |

Compilation/program disposal alone; execution and I/O excluded. Do not subtract
warm and fresh medians to infer compilation: these are independent job blocks,
and JSON fresh is slightly below warm in this collection.

| Compile-only script | Lython | CPython | Ratio | Current control / Lython IQR |
| --- | ---: | ---: | ---: | --- |
| CSV summary/ordinary helper | 71.450–72.030 µs | 59.191 µs | 1.21–1.22× | 0.81% / 0.69% |
| Text summary/helpers | 53.554–54.654 µs | 41.573 µs | 1.29–1.31× | 2.05% / 1.26% |
| JSON-lines/helpers | 64.138–64.837 µs | 50.743 µs | 1.26–1.28× | 1.09% / 1.93% |
| JSON-to-Markdown report | 51.439–53.401 µs | 37.618 µs | 1.37–1.42× | 3.81% / 7.52% |
| Configuration read/edit/write | 44.483–45.147 µs | 34.341 µs | 1.30–1.31× | 1.47% / 0.94% |

**Startup, genuinely suspended-I/O latency, heap/RSS and embedding latency remain
unmeasured.** This refresh measures the combined delivery and does not isolate each
change's CPU benefit. Earlier source-pair regressions and unstable controls remain
in their evidence; later absolute timings do not explain them.
[Previous primary comparison, source `9a152ee0`](../benchmarks/results/2026-11-06-deferred-contexts/README.md),
[text-provenance source pair and accepted debt](../benchmarks/results/2026-11-06-text-operation-provenance/README.md).

## Machine, included work and fairness

Dedicated Azure Standard_F4as_v7, Ubuntu24.04.4 x86-64, four AMD EPYC9V45 vCPUs,
one thread/core,16GiB RAM/no swap. CPython GCC13.3 PGO/LTO, ordinary GIL/GC,
no JIT/debug, `-I -S -X utf8`. SDK/runtime11.0.100-rc.3.26522.148 /
11.0.0-rc.3.26522.148. Independent sequential processes, normal worker GC/tiering,
quiet endpoints; five-second warmup per role/job and seven rotated150ms rounds.
Fifteen jobs completed311.43s; all workers joined and fixtures were removed.

Both engines run identical scripts/fixtures, checking complete output/file digests
on every invocation. Efficient host overrides mediate Lython file access. RAM
fixtures include reads/writes; staging/reset is outside elapsed clocks. Warm
includes invocation and prior-result cleanup. Compile includes construction/
disposal; compile-to-result also executes a fresh script. Transport and final
program/result/process/fixture teardown are outside clocks. CPython retains imported
modules between invocations; Lython isolates execution imports. This is an embedding
comparison, not a claim of identical implementations or import caching.

These primary tables use `Run`. Historical `4ace68ff` `RunAsync` jobs use completed
mediated I/O: text2.630–2.636ms versus CPython1.203ms (2.19×), CSV5.586–5.670ms
versus3.220ms (1.74–1.76×). Async text elapsed is6.91–7.14% below Q02;
CSV is inconclusive. These do not measure genuinely pending-I/O latency.
[Historical async evidence](../benchmarks/results/2026-11-06-native-read-cpython/README.md),
[earlier async hash/read debt](../benchmarks/results/2026-11-06-async-key-reads/README.md)
and [original native-read comparison](../benchmarks/results/2026-11-06-native-read-prefix/README.md)
retain their distinct source pairs and adverse results.

'''
p.write_text(new+tail,encoding='utf-8')
p=Path('benchmarks/EXPERIMENTS.md');s=p.read_text(encoding='utf-8');pos=s.index('\n')+1
s=s[:pos]+'''
The [b6650f09 delivery comparison](results/2026-11-06-delivery-cpython/README.md)
refreshes compile/warm/fresh against CPython for four large scripts and the existing
small configuration edit.15jobs/311.43s, two identical current roles, all goldens,
quiet/funding/cleanup/archive gates pass. Fresh ratios1.31/1.75–1.83/1.12/1.44–1.46/
1.21–1.22x; text fresh/report/warm CSV remain variable. Separate Windows/Ubuntu,
both-runtime/original Stress/package qualification is GREEN as CI42258608463.
The current guide uses this source; earlier adverse source pairs remain separate.

'''+s[pos:];p.write_text(s,encoding='utf-8')
print('Recorded current comparison and maintained guide; terminal CI cached, never query42258608463 again.')
