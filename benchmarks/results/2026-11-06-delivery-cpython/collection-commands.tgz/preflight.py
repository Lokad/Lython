from pathlib import Path
import json,subprocess
root=Path(__file__).parent
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73','python3 -']
script='''from pathlib import Path
import fcntl,json,shutil,subprocess
root=Path('/home/lokad/lython-bench-checks')
with (root/'comparison-vm.lock').open('a') as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record'],capture_output=True).returncode==1
 assert not list(Path('/dev/shm').glob('lython-comparison-files-*'))
 print(json.dumps({'freeBytes':shutil.disk_usage(root).free,'transfers':[{ 'name':p.name,'bytes':p.stat().st_size} for p in root.glob('b35*-payload.tgz')]}))
'''
r=subprocess.run(ssh,input=script,text=True,encoding='utf-8',capture_output=True)
(root/'preflight.stdout.json').write_text(r.stdout,encoding='utf-8');(root/'preflight.stderr.log').write_text(r.stderr,encoding='utf-8')
assert r.returncode==0,r.stderr
print(r.stdout)
