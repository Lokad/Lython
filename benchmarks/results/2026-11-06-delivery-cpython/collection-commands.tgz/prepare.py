from pathlib import Path
import hashlib,json,shutil,subprocess,tarfile,zipfile
repo=Path('D:/code/Lython');root=Path(__file__).parent;old=root.parent/'text-provenance-r17/b351';matrix=root.parent/'context-materialization-r13/b347'
remote='/home/lokad/lython-bench-checks/delivery-comparison-b352-20261106';oldremote='/home/lokad/lython-bench-checks/text-operation-provenance-b351-20261106';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert not (root/'identity.json').exists()
def write(name,text):
    with (root/name).open('w',encoding='utf-8',newline='\n') as f:f.write(text)
revision=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();assert revision.startswith('b6650f09')
subprocess.run(['git','diff','--exit-code','--','src/Lokad.Lython'],check=True)
core=repo/'src/Lokad.Lython/bin/Release/net11.0/Lokad.Lython.dll'
with zipfile.ZipFile(repo/'artifacts/nuget/Lokad.Lython.0.11.0.nupkg') as a:assert hashlib.sha256(a.read('lib/net11.0/Lokad.Lython.dll')).hexdigest()==sha(core)
identity=json.loads((old/'identity.json').read_text(encoding='utf-8'))
identity.update(sourceRevision=revision,referenceSourceRevision='Unused historical reference image; primary measurement is CPython plus two identical current roles',coreSHA256=dict(candidate=sha(core),control=sha(core),reference=identity['coreSHA256']['reference']),purpose='Coherent R13C/R14/R17/P01 delivery CPython refresh, not a new source-pair optimization',qualification='Focused actual11/10 and installed package consumers pass; CI42258608463 in progress')
identity.pop('sourceFiles',None);identity.pop('baselineNormalizedSourceSHA256',None)
write('identity.json',json.dumps(identity,indent=2)+'\n');shutil.copyfile(core,root/'Lokad.Lython.dll')
catalog=json.loads((matrix/'representative.json').read_text(encoding='utf-8'))
allcases=json.loads((root/'catalog-representative.json').read_text(encoding='utf-8'))['cases']
catalog['cases'].append(next(c for c in allcases if c['id']=='scripts.config-edit.small'))
write('representative.json',json.dumps(catalog,indent=2,ensure_ascii=False)+'\n')
jobs=[(c['id'],lane) for c in catalog['cases'] for lane in ['compile','warm','compile-run']]
script=(matrix/'collect.py').read_text(encoding='utf-8').replace('/home/lokad/lython-bench-checks/context-materialization-b347-20261106',remote)
start=script.index('jobs=[');end=script.index('\n\nenv =',start)
script=script[:start]+'jobs='+repr(jobs)+'\nassert len(jobs)==15'+script[end:]
script=script.replace("labels=['CPython','candidate','reference','control']","labels=['CPython','candidate','control']").replace("< 380, 'Reserve30 seconds", "< 390, 'Reserve60 seconds")
script=script.replace('R13 shared instruction engine/context-on-demand versus qualified R10: representative compile, warm and fresh; CPython plus two identical candidate roles. No exact allocation/RSS/embedding latency claim','Committed b6650f09 delivery: representative compile, warm and fresh; CPython plus two identical current roles. No exact allocation/RSS/embedding latency claim')
script+='\n    subprocess.run(["python3",str(root/"archive-owned.py")],check=True)\n';write('collect.py',script)
for name in ['setup.py','run.sh','cpython-worker.py','archive-owned.py']:
    s=(old/name).read_text(encoding='utf-8').replace(oldremote,remote)
    if name=='archive-owned.py':s=s.replace("len(r['jobs'])==5","len(r['jobs'])==15").replace('jobs=5,','jobs=15,')
    write(name,s)
launch=(old/'launch.py').read_text(encoding='utf-8').replace(oldremote,remote).replace('b351','b352').replace('text-operation-provenance','delivery-comparison').replace('RuntimeMaxSec=200','RuntimeMaxSec=450')
write('launch.py',launch)
write('source.patch',subprocess.check_output(['git','diff','62141d4d..HEAD','--','src/Lokad.Lython','tests'],text=True,encoding='utf-8'))
paths=subprocess.check_output(['git','diff','--name-only','62141d4d..HEAD','--','src/Lokad.Lython','tests'],text=True).splitlines()
with tarfile.open(root/'source-snapshot.tgz','w:gz') as a:
    for name in paths:
        p=repo/name
        if p.exists():a.add(p,arcname=name)
write('focused-results.json',json.dumps(json.loads((root.parent/'openpyxl-number-formats/focused-results.json').read_text(encoding='utf-8')),indent=2)+'\n')
shutil.copyfile(repo/'PLAN.md',root/'pre-measurement-plan.md')
write('contract.md','''# B352 coherent delivery CPython refresh
Committed core b6650f09: R13C/R14/R17/P01; no candidate optimization or new framework.
Five complete scripts: existing large CSV/functions, text/helpers, JSON/helpers,
report plus existing small configuration edit (16 paths). Compile, warm and fresh
separate, 15 jobs. CPython plus two independent identical current roles; no hidden
source-pair CPU claim. Five-second warmup per role/job, seven rotating150ms rounds;
normal GC/tiering, existing unchanged worker/protocol/goldens. Source and binary
identities explicit; core matches the installed-consumer Release package bytes.
Includes invocation, mediated RAM I/O, full output/file validation and prior-result
cleanup. Compile adds construction/disposal; fresh adds compile to execution.
Startup, fixture staging/reset, transport and final teardown excluded. Module cache
differences remain explicit. Quiet endpoints, Closed/zero funding, joined workers
and removed fixtures required. Archive and verify raw persistent evidence under the
owned VM lease. 450s process-group supervisor, no SSH/profiling during collection.
Retain adverse/control-limited results; this is not tail latency, RSS, suspended-I/O
or exact allocation qualification. Current CI separately qualifies platforms/stress.
''')
names=['Lokad.Lython.dll','identity.json','source.patch','source-snapshot.tgz','representative.json','focused-results.json','pre-measurement-plan.md','contract.md','setup.py','collect.py','run.sh','cpython-worker.py','archive-owned.py']
with tarfile.open(root/'payload.tgz','w:gz') as a:
    for name in names:a.add(root/name,arcname=name)
with tarfile.open(root/'payload.tgz') as a:expanded=sum(m.size for m in a.getmembers())
transfer={'payloadBytes':(root/'payload.tgz').stat().st_size,'payloadSHA256':sha(root/'payload.tgz'),'expandedBytes':expanded,'requiredFreeBeforeTransfer':(root/'payload.tgz').stat().st_size+expanded+6*1024*1024}
write('transfer.json',json.dumps(transfer,indent=2)+'\n');print(transfer)
