from pathlib import Path
import hashlib
import json
import os
import shutil
import subprocess

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
comparison = lab.parent / "deferred-word-binding-20261122" / "comparison"
catalog = comparison / "catalog.json"
read = lambda path: json.loads(path.read_text(encoding="utf-8-sig"))
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
inventory = read(comparison/"images.json")
assert inventory["catalogSHA256"] == sha(catalog)
source = comparison / "frozen-reference"
sdk = Path.home()/".dotnet11"
env = dict(os.environ, DOTNET_ROOT=str(sdk), DOTNET_ROOT_X64=str(sdk),
           PATH=str(sdk) + os.pathsep + os.environ["PATH"])
core = "Lokad.Lython.dll"
candidate_core = (repo / ".git/agent-worktrees/histogram-total-slots-20261122/src/Lokad.Lython"
                  / "bin/Release/net11.0" / core)
for role in ("reference", "candidate"):
    image = lab / role
    image.mkdir(exist_ok=False)
    files = inventory["imageFiles"]["reference"].copy()
    for name, digest in files.items():
        assert sha(source / name) == digest
        shutil.copyfile(source / name, image / name)
    for name in ("ValidatedAllocation.dll", "ValidatedAllocation.deps.json", "ValidatedAllocation.runtimeconfig.json"):
        shutil.copyfile(source / name, image / name)
    if role == "candidate":
        shutil.copyfile(candidate_core, image / core)
        files[core] = sha(candidate_core)
    assert {name: sha(image / name) for name in files} == files
    report = lab / (role + "-allocation.json")
    subprocess.run([sdk / "dotnet.exe", image / "ValidatedAllocation.dll", image, catalog, report],
                   env=env, check=True, timeout=85)
    rows = read(report)["rows"]
    assert {row["id"] for row in rows} == {case["id"] for case in read(catalog)["cases"]}
    assert all(row["sharedBudgetBaselineRestored"] for row in rows)
    print(role, files[core], flush=True)
    for row in rows:
        print(row["id"], row["allocatedBytesPerInvocation"], row["peakExecutionMemoryBytes"], flush=True)
    assert {name: sha(image / name) for name in files} == files
