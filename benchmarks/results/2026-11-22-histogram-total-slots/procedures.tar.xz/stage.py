from pathlib import Path
import hashlib
import json
import os
import shutil
import subprocess
import tarfile

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
out = lab/"comparison"
quiet = out/"quiet"
quiet.mkdir(exist_ok=True)
template = lab.parent/"deferred-word-binding-20261122"/"comparison"
old_root = "/home/lokad/lython-bench-checks/deferred-word-binding-b1410-20261122"
old_unit = "lython-b1410-deferred-word-binding-20261122"
root = old_root.replace("deferred-word-binding-b1410","histogram-total-slots-b1411")
unit = old_unit.replace("b1410-deferred-word-binding","b1411-histogram-total-slots")
core = "Lokad.Lython.dll"
read = lambda p: json.loads(p.read_text(encoding="utf-8-sig"))
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
def write(path,text):
    if path.suffix==".py": compile(text,str(path),"exec")
    path.write_text(text,encoding="utf-8",newline="\n")
def save(path,value): write(path,json.dumps(value,indent=2)+"\n")

refs=read(out/"images.json")
files=refs["imageFiles"]
catalog=out/"catalog.json"
assert sha(catalog)==refs["catalogSHA256"]
for role, manifest in files.items():
    assert len(manifest)==32 and {n:sha(out/("frozen-"+role)/n) for n in manifest}==manifest
    verify=read(out/(role+"-verify.json"))
    assert verify["state"]=="Completed" and verify["caseCount"]==5 and verify["catalogSha256"]==sha(catalog)
identity=dict(sourceRevision=refs["reference"]+" versus "+refs["candidate"], reference=refs["reference"],
    candidate=refs["candidate"], imageFiles=files, purpose="Avoid boxing and reopening the total at both histogram loop boundaries",
    normalAdapterPin="0.4.0",sourcePatchSHA256=refs["sourcePatchSHA256"],
    coreSHA256={role+suffix:manifest[core] for role,manifest in files.items() for suffix in ("","-control")},
    catalogs={"representative.json":{"sha256":sha(catalog)}})
save(quiet/"identity.json",identity)
shutil.copyfile(catalog,quiet/"representative.json")
(quiet/"candidate").mkdir(exist_ok=True)
shutil.copyfile(out/"frozen-candidate"/core,quiet/"candidate"/core)
for name in ("collect.py","run.sh","archive-owned.py","retrieve.py"):
    program=(template/"quiet"/name).read_text(encoding="utf-8")
    program=program.replace(old_root,root).replace(old_unit,unit).replace("B1410","B1411")
    program=program.replace("len(jobs)==8","len(jobs)==6").replace("len(raw['jobs'])==8","len(raw['jobs'])==6")
    program=program.replace("jobs=8,","jobs=6,").replace("['jobs']==8","['jobs']==6")
    if name=="collect.py":
        jobs=[tuple(row) for row in read(out/"jobs.json")]
        ids={row["id"] for row in read(catalog)["cases"]}
        assert len(jobs)==6 and {case for case,lane in jobs}==ids
        first,end=program.index("\njob_catalog = "),program.index("\nassert len(jobs)")
        program=program[:first]+"\njob_catalog = "+repr({case:"representative.json" for case in sorted(ids)})+"\njobs = "+repr(jobs)+program[end:]
        program=program.replace("started < 455","started < 350").replace("job_index % 2 == 0","job_index % 2 != 0")
    write(quiet/name,program)
assert b"\r" not in (quiet/"run.sh").read_bytes()
parts=("identity.json","representative.json","collect.py","run.sh","archive-owned.py","candidate/"+core)
payload=quiet/"payload.tgz"
with tarfile.open(payload,"w:gz") as bundle:
    for name in parts:bundle.add(quiet/name,arcname=name)
unpacked=sum((quiet/n).stat().st_size for n in parts)
archived=repo/"benchmarks/results/2026-11-19-shared-record-keywords"
with tarfile.open(archived/"observations.tgz") as bundle: old_identity=json.load(bundle.extractfile("identity.json"))
receipt=read(archived/"archive-receipt.json")
assert receipt["complete"] and receipt["allWorkersJoined"] and sha(archived/"observations.tgz")==receipt["archiveSHA256"]
assert subprocess.check_output(["git","show","origin/master:"+str((archived/"observations.tgz").relative_to(repo)).replace(os.sep,"/")],cwd=repo)==(archived/"observations.tgz").read_bytes()
backup=lab/"canonical-remote-reference/B1123-reference-Lokad.Lython.dll"
digest="6e3604784844a645b7229ec269245909d3d785edfbd3d9e8848e0e6b4ee99f60"
assert sha(backup)==old_identity["imageFiles"]["reference"][core]==digest and backup.stat().st_size==5802496
retire=[dict(paths=["shared-record-keywords-b1123-20261119/reference/"+core],
    bytes=backup.stat().st_size,links=1,sha256=digest,archives={})]
old=read(template/"quiet/config.json")
config={**old,"root":root,"unit":unit,"identity":identity,"retireGroups":retire,
        "payloadBytes":payload.stat().st_size,"payloadSHA256":sha(payload),"unpackedBytes":unpacked}
assert config["sourceFiles"]==files["reference"]
save(quiet/"config.json",config)
launch=(template/"quiet/remote-launch.py").read_text(encoding="utf-8")
start,end=launch.index("\nc=")+1,launch.index("\nb=Path(")
launch=(launch[:start]+"c="+repr(config)+launch[end:]).replace("b1410-fixtures","b1411-fixtures").replace("RuntimeMaxSec=520","RuntimeMaxSec=415").replace("640*1024","2*1024*1024")
write(quiet/"remote-launch.py",launch)
for name in ("launch.py","summarize.py"):
    program=(template/name).read_text(encoding="utf-8").replace("seconds=475","seconds=366").replace("before 475 seconds","before 366 seconds")
    program=program.replace("Deferred short-word binding","Histogram total slots").replace("len(raw['jobs'])==8","len(raw['jobs'])==6")
    write(out/name,program)
