from pathlib import Path
import hashlib
import json
import os
import shutil
import subprocess

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
prior = lab.parent / "deferred-word-binding-20261122" / "comparison"
out = lab / "comparison"
out.mkdir(exist_ok=True)
read = lambda p: json.loads(p.read_text(encoding="utf-8-sig"))
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
def save(p, value):
    p.write_text(json.dumps(value, indent=2) + "\n", encoding="utf-8", newline="\n")

catalog = read(prior / "catalog.json")
prior_id = read(prior / "images.json")
assert sha(prior / "catalog.json") == prior_id["catalogSHA256"]
cases = [catalog["cases"][i] for i in (0, 1, 2, 3, 6)]
catalog["cases"] = cases
save(out/"catalog.json", catalog)
jobs = [[cases[0]["id"], "warm"], [cases[0]["id"], "compile-run"]] + [[case["id"], "warm"] for case in cases[1:]]
save(out/"jobs.json", jobs)
sdk = Path.home() / ".dotnet11"
dotnet = sdk / "dotnet.exe"
env = dict(os.environ, DOTNET_ROOT=str(sdk), DOTNET_ROOT_X64=str(sdk), PATH=str(sdk)+os.pathsep+os.environ["PATH"])
protocol = repo / "benchmarks/cpython-worker.py"
assert sha(protocol) == prior_id["protocolSHA256"]
source = "55424591f"
candidate = "38ae6465bf9f33755a328303382c0973dd1100bd"
reference = subprocess.check_output(["git","rev-parse",source],cwd=repo).decode().strip()
assert reference == prior_id["reference"]
core = "Lokad.Lython.dll"
manifest = prior_id["imageFiles"]["reference"]
expected = {"reference": manifest, "candidate": {**manifest,core:"2197110fe8dc42f49f7dcd1084690d233dc720395048ea1a067e24df65fd52f3"}}
patch = out / "source.patch"
patch.write_bytes(subprocess.check_output(["git","diff","--binary",reference,candidate,"--","src","tests"],cwd=repo))
for role, files in expected.items():
    image = out / ("frozen-" + role)
    image.mkdir(exist_ok=True)
    for name, value in files.items():
        assert sha(lab / role / name) == value
        shutil.copyfile(lab / role / name, image / name)
    catalog_path = out/"catalog.json"
    verified = out / (role + "-verify.json")
    subprocess.run([dotnet,image/"Lokad.Lython.Benchmarks.dll","--compare","verify",
        "--catalog",catalog_path,"--dotnet",dotnet,"--python","C:/Python313/python.exe",
        "--python-worker",protocol,"--out",verified],env=env,cwd=repo,check=True,timeout=100)
    result = read(verified)
    assert result["state"]=="Completed" and result["caseCount"]==len(cases)
    assert result["catalogSha256"]==sha(catalog_path)
    assert {p.name:sha(p) for p in image.iterdir()}==files
save(out/"images.json",dict(reference=reference,candidate=candidate,imageFiles=expected,
    catalogSHA256=sha(out/"catalog.json"),protocolSHA256=sha(protocol),sourcePatchSHA256=sha(patch)))
