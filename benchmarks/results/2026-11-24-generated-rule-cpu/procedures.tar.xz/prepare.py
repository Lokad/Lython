from pathlib import Path
import hashlib
import json
import subprocess
import tarfile

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
donor=lab.with_name('exact-unicode-float-20261124')
comparison=lab.with_name('current-rule-closures-cpython-20261124')/'external'
read=lambda path:json.loads(path.read_text(encoding='utf-8'))
digest=lambda path:hashlib.sha256(path.read_bytes()).hexdigest()
raw=donor/'comparison/quiet'
identity=read(comparison/'identity.json')
subprocess.run(['git','diff','--exit-code',identity['sourceRevision'],'566259ebc','--','src','tests'],cwd=repo,check=True)
receipt=read(raw/'terminal-status.json')['receipt']
assert receipt['complete'] and receipt['archivedAndVerifiedUnderLease'] and receipt['allWorkersJoined']
assert digest(raw/'observations.tar.xz')==receipt['archiveSHA256']
assert len(identity['imageFiles']['candidate'])==32
assert all(digest(donor/'candidate'/name)==checksum for name,checksum in identity['imageFiles']['candidate'].items())
catalog=comparison/'representative.json'
ids=['scripts.rule-default-closures','scripts.annotated-rule-closures','scripts.captured-rule-closures']
assert [case['id'] for case in read(catalog)['cases']]==ids
(lab/'catalog.json').write_bytes(catalog.read_bytes())
identity.update(purpose='B1565 attribute current whole-rule factory, frame and capture CPU',
    donorArchiveSHA256=receipt['archiveSHA256'],profileCatalogSHA256=digest(lab/'catalog.json'),
    externalTimingSHA256=digest(comparison/'observations.tar.xz'))
(lab/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8',newline='\n')

labels=['default-warm','annotated-warm','captured-warm']
source=repo/'benchmarks/results/2026-11-24-short-text-helper-cpu/procedures.tar.xz'
with tarfile.open(source) as prior:
    def adapt(name,replacements=()):
        text=prior.extractfile(name).read().decode('utf-8').replace('\r\n','\n')
        for old,new in replacements:
            assert text.count(old)==1,(name,old,text.count(old))
            text=text.replace(old,new)
        if name.endswith('.py'):compile(text,name,'exec')
        (lab/name).write_text(text,encoding='utf-8',newline='\n')
    adapt('run.sh')
    adapt('collect.py',(
        ('json-encoding-flags-b1553-20261124/candidate','exact-unicode-float-b1560-20261124/candidate'),
        ('b1556-fixtures','b1565-fixtures'),
    ))
    adapt('quiet.py',(
        ('current-text-helper-cpu-b1556-20261124','current-rule-cpu-b1565-20261124'),
        ('lython-b1556-current-text-helper-cpu-20261124','lython-b1565-current-rule-cpu-20261124'),
        ('json-encoding-flags-20261124/candidate','exact-unicode-float-20261124/candidate'),
        ('the three short text source shapes','the three generated rule scripts'),
    ))
    adapt('ops-profile.py',(
        ("[('nonlocal-warm', 'diagnostic.text-summary.nonlocal-computed-width.large', 'warm'), ('width-in-caller-warm', 'diagnostic.text-summary.computed-width-in-caller', 'warm'), ('inline-warm', 'diagnostic.text-summary.without-per-line-helper', 'warm')]",
         repr([(label,case,'warm') for label,case in zip(labels,ids,strict=True)])),
    ))
    adapt('analyze.py',(
        ("['nonlocal-warm', 'width-in-caller-warm', 'inline-warm']",repr(labels)),
        ("""     'word decoding and casing': ('Cased','CaseMapped','WhitespaceRange','StringWordCursor','SigmaPropertyContains','Rune'),
     'lookup and accumulation': ('NativeTextIndex','DictionaryLoop','PyDict::','TryAccumulate','ProbeString'),""",
         """     'lexical binding operations': ('CaptureExecutable','ExecutableCaptures::','ExecutableCell::','TryLoadClosure', 'TryStoreClosure','TryExecuteClosureArithmetic'),
     'function and defaults construction': ('ApplyDefinition','CreateInlineDefinition','CreateLexicalFunctionValue','CreateFunctionValue','FunctionDefaults','CreateClosedComputedDefinition','CreateClosedFunctionDefinition','CreatePreparedPositionalDefaults', 'PyFunctionBase::.ctor','PyExecutableFunction::.ctor'),
     'argument transport': ('BoundFunctionArguments','BindIntoSlots','RentFunctionArgumentStorage','ReturnBoundArguments','StoreSuppliedArguments','PrepareExecutableCallArguments'),
     'numeric arithmetic': ('TryIntegerChain','TryMachineBinary','EvaluateInteger','TryEvaluateDirectIntegerReturn'),"""),
    ))
assert b'\r' not in (lab/'run.sh').read_bytes()

