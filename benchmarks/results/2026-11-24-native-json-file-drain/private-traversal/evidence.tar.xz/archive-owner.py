from pathlib import Path
import hashlib,json,tarfile

lab=Path(__file__).resolve().parent
root=lab.parents[3]
source=lab/"owner-prototype"
out=root/"benchmarks/results/2026-11-24-native-json-file-drain/private-traversal"
old,new=[json.loads((source/f"{role}-owner.json").read_text(encoding="utf-8"))for role in ("reference","candidate")]
pairs=list(zip(old["rows"],new["rows"],strict=True))
assert all(a["id"]==b["id"] and a["ReturnValue"]==b["ReturnValue"] and a["async"]==b["async"] for a,b in pairs)
assert all((a["PeakExecutionMemoryBytes"],b["PeakExecutionMemoryBytes"])==(232704,3940)for a,b in pairs if a["id"]=="json-1024")
assert "Failed:     4" in (source/"reference-test.log").read_text(encoding="utf-8")
assert "Passed:     4" in (source/"candidate-test.log").read_text(encoding="utf-8")
for platform in ("windows","ubuntu"):
    assert "Passed:    85" in (lab/f"owner-prototype-{platform}.log").read_text(encoding="utf-8-sig")
out.mkdir(exist_ok=True)
sourcePatch=hashlib.sha256((source/"candidate.patch").read_bytes()).hexdigest()
summary=dict(reference=old["sha"],candidate=new["sha"],sourcePatch=sourcePatch,
               executionPeakBytes=[dict(case=a["id"],asynchronous=a["async"],bytes=[a["PeakExecutionMemoryBytes"],b["PeakExecutionMemoryBytes"]])for a,b in pairs])
(out/"ownership-summary.json").write_text(json.dumps(summary,indent=2)+"\n",encoding="utf-8",newline="\n")
paths=("archive-owner.py","prove-owner.py","owner.py","owner/Owner.csproj","owner/Program.cs","owner-build.log",
       "owner-prototype-windows.log","owner-prototype-ubuntu.log","test-owner-ubuntu.sh","file-chunk-oracle-source.py",
       "refined/candidate.patch","owner-prototype/candidate.patch","owner-prototype/reference-owner.json",
       "owner-prototype/candidate-owner.json","owner-prototype/reference-test.log","owner-prototype/candidate-test.log")
with tarfile.open(out/"evidence.tar.xz","w:xz") as bundle:
    for p in paths:bundle.add(lab/p,arcname=p)
with tarfile.open(out/"evidence.tar.xz") as bundle:
    assert all(hashlib.sha256(bundle.extractfile(p).read()).digest()==hashlib.sha256((lab/p).read_bytes()).digest()for p in paths)
print("Archived the private traversal prototype and reproduced admission refusal on the reference")
