from pathlib import Path
import hashlib
import os
import shutil
import subprocess
import json

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
tree=repo/".git/agent-worktrees/private-json-writer-owner-20261124"
tool=lab/"owner/bin/Release/net11.0"
sdk=Path.home()/".dotnet11"
source=lab/"file-chunk-oracle-source.py"
test=tree/"tests/Lokad.Lython.PublicApi.Tests/bin/Release/net11.0"
env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk))
out=lab/"owner-prototype"
out.mkdir(exist_ok=True)
(out/"candidate.patch").write_bytes(subprocess.check_output(["git","diff","--binary"],cwd=tree))
rows=[]
for role in ("reference","candidate"):
    runner=out/role
    runner.mkdir(exist_ok=True)
    for p in test.iterdir():
        if p.is_file() and p.suffix.lower() not in (".pdb",".exe"):
            shutil.copyfile(p,runner/p.name)
    for p in tool.glob("Owner.*"):
        if p.suffix.lower() not in (".pdb",".exe"):
            shutil.copyfile(p,runner/p.name)
    core=(lab/"refined/candidate" if role=="reference" else tree/"src/Lokad.Lython/bin/Release/net11.0")/"Lokad.Lython.dll"
    shutil.copyfile(core,runner/core.name)
    assert hashlib.sha256(core.read_bytes()).hexdigest()==hashlib.sha256((runner/core.name).read_bytes()).hexdigest()
    results=subprocess.run([sdk/"dotnet.exe",runner/"Owner.dll",runner/"Lokad.Lython.PublicApi.Tests.dll", source],
        env=env,check=True,capture_output=True,text=True,encoding="utf-8",timeout=30)
    result=json.loads(results.stdout)
    assert result["sha"]==hashlib.sha256(core.read_bytes()).hexdigest()
    (out/f"{role}-owner.json").write_text(json.dumps(result,indent=2)+"\n",encoding="utf-8")
    check=subprocess.run([sdk/"dotnet.exe","vstest",runner/"Lokad.Lython.PublicApi.Tests.dll",
                          "/TestCaseFilter:FullyQualifiedName~RepeatedExactBuiltinDumpsReleasePrivateTraversal"],
        env=env,capture_output=True,text=True,encoding="utf-8",timeout=45)
    (out/f"{role}-test.log").write_text(check.stdout+check.stderr,encoding="utf-8")
    assert check.returncode==(1 if role=="reference" else 0),(check.stdout,check.stderr)
    print(role,[(v["id"],v["async"],v["PeakExecutionMemoryBytes"])for v in result["rows"]],flush=True)
    print("\n".join(check.stdout.splitlines()[-4:]),flush=True)
    rows.append(result["rows"])
assert all(old["ReturnValue"]==new["ReturnValue"] for old,new in zip(*rows,strict=True))
assert max(row["PeakExecutionMemoryBytes"]for row in rows[1] if row["id"]=="json-1024") < 12000
