#!/bin/sh
set -eu
cd /mnt/d/code/Lython/.git/agent-worktrees/private-json-writer-owner-20261124
export DOTNET_ROOT="$HOME/.dotnet" PATH="$HOME/.dotnet:$PATH"
filter='Category!=Stress&(FullyQualifiedName~JsonEncoderIterationLifetimeTests|FullyQualifiedName~JsonBooleanOptionTests|FullyQualifiedName~JsonEncoderScenarioTests|FullyQualifiedName~JsonEscapeRenderingTests|FullyQualifiedName~JsonDictionaryCallbackLifetimeTests|FullyQualifiedName~ImplicitTextBatchesAwaitTheRealProducerBorrowAndCleanup)'
dotnet test tests/Lokad.Lython.PublicApi.Tests -c Release -f net11.0 --artifacts-path /mnt/d/code/Lython/.git/agent-notes/review-20261031/json-file-drain-20261124/owner-ubuntu --nologo --filter "$filter"
