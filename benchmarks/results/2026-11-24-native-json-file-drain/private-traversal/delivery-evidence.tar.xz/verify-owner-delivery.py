from pathlib import Path
import hashlib,json,shutil,subprocess,os

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
out=lab/"owner-delivery"
expected=out/"candidate.patch"
runner=(lab/"prove-owner.py").read_text(encoding="utf-8")
runner=runner.replace('tree=repo/".git/agent-worktrees/private-json-writer-owner-20261124"','tree=repo')
runner=runner.replace('out=lab/"owner-prototype"','out=lab/"owner-delivery"')
runner=runner.replace('(out/"candidate.patch").write_bytes(subprocess.check_output(["git","diff","--binary"],cwd=tree))',
                      'assert (out/"candidate.patch").read_bytes()==subprocess.check_output(["git","diff","--binary","--","src","tests"],cwd=tree)')
runner=runner.replace('lab/"refined/candidate"','lab/"boxed/candidate"')
exec(compile(runner,"frozen ownership and first refusal proof","exec"))

core="Lokad.Lython.dll"
identity=json.loads((lab/"boxed/quiet/identity.json").read_text(encoding="utf-8"))
manifest=identity["imageFiles"]["candidate"].copy()
current=repo/"src/Lokad.Lython/bin/Release/net11.0"/core
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert manifest[core]!=sha(current)
manifest[core]=sha(current)
image=out/"image"
image.mkdir(exist_ok=True)
for name in manifest: shutil.copyfile(current if name==core else lab/"boxed/candidate"/name,image/name)
assert len(manifest)==32 and {p.name:sha(p) for p in image.iterdir()}==manifest
sdk=Path.home()/".dotnet11"
dotnet=sdk/"dotnet.exe"
python=Path("C:/Python313/python.exe")
env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk))
catalog=lab/"boxed/quiet/representative.json"
report=out/"candidate-verify.json"
subprocess.run([dotnet,image/"Lokad.Lython.Benchmarks.dll","--compare","verify","--catalog",catalog,
                "--dotnet",dotnet,"--python",python,"--python-worker",lab/"comparison/cpython-worker.py","--out",report],
        check=True,cwd=repo,env=env,timeout=60)
proof=json.loads(report.read_text(encoding="utf-8"))
assert proof["state"]=="Completed" and proof["caseCount"]==5
assert proof["catalogSha256"]==sha(catalog) and proof["launched"]["library"]["sha256"]==manifest[core]
assert {p.name:sha(p)for p in image.iterdir()}==manifest
(out/"identity.json").write_text(json.dumps(dict(reference="e353ba446",sourcePatchSHA256=sha(expected),imageFiles=manifest,
                  catalogSHA256=sha(catalog)),indent=2)+"\n",encoding="utf-8",newline="\n")
