from pathlib import Path
import hashlib,json,shutil,tarfile

lab=Path(__file__).resolve().parent
root=lab.parents[3]
proof=lab/"owner-delivery"
out=root/"benchmarks/results/2026-11-24-native-json-file-drain/private-traversal"
read=lambda p:json.loads(p.read_text(encoding="utf-8-sig"))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
identity=read(proof/"identity.json")
assert sha(proof/"candidate.patch")==identity["sourcePatchSHA256"]
assert len(identity["imageFiles"])==32 and {file.name:sha(file) for file in (proof/"image").iterdir()}==identity["imageFiles"]
verify=read(proof/"candidate-verify.json")
assert verify["state"]=="Completed" and verify["caseCount"]==5 and verify["catalogSha256"]==identity["catalogSHA256"]
previous=read(proof/"reference-owner.json")
candidate=read(proof/"candidate-owner.json")
assert candidate["sha"]==identity["imageFiles"]["Lokad.Lython.dll"]==verify["launched"]["library"]["sha256"]
assert previous["sha"]==read(lab/"boxed/quiet/identity.json")["coreSHA256"]["candidate"]
for original,refined in zip(previous["rows"],candidate["rows"],strict=True):
    if original["id"]=="json-1024":
        assert original["PeakExecutionMemoryBytes"]==232704 and refined["PeakExecutionMemoryBytes"]==3940
    assert original["ReturnValue"]==refined["ReturnValue"] and original["id"]==refined["id"]
for role,count in (("reference","Failed:     4"),("candidate","Passed:     4")):
    assert count in (proof/f"{role}-test.log").read_text(encoding="utf-8-sig")
for platform in ("windows","ubuntu"):
    assert "Passed:  1013" in (proof/f"{platform}-public.log").read_text(encoding="utf-8-sig")
    assert "Passed:   329" in (proof/f"{platform}-white.log").read_text(encoding="utf-8-sig")
shutil.copyfile(proof/"identity.json",out/"delivery-identity.json")
files=["archive-owner-delivery.py","apply-owner-delivery.py","verify-owner-delivery.py","prove-owner.py",
       "owner/Program.cs","owner/Owner.csproj","file-chunk-oracle-source.py"]+["owner-delivery/"+file for file in (
        "candidate.patch","candidate-verify.json","reference-test.log","candidate-test.log","reference-owner.json",
        "candidate-owner.json","windows-public.log","ubuntu-public.log","windows-white.log","ubuntu-white.log",
        "test-ubuntu.sh","verify.log")]
with tarfile.open(out/"delivery-evidence.tar.xz","w:xz") as archive:
    for file in files:archive.add(lab/file,arcname=file)
with tarfile.open(out/"delivery-evidence.tar.xz") as archive:
    assert all(hashlib.sha256(archive.extractfile(file).read()).hexdigest()==sha(lab/file) for file in files)
print("Verified admission, failures, goldens and both platform logs for the delivered ownership patch")
