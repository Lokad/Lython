from pathlib import Path
import subprocess

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
source=repo/".git/agent-worktrees/private-json-writer-owner-20261124"
assert subprocess.check_output(["git","status","--porcelain","--untracked-files=no"],cwd=repo,text=True)==""
p=Path("src/Lokad.Lython/Runtime/LythonRuntime.Json.Encoder.cs")
old=(repo/p).read_text(encoding="utf-8")
new=(source/p).read_text(encoding="utf-8")
addition="""        internal void FinishPrivate()
        {
            try { Finish(); }
            finally { _context.MemoryGovernor.Release(StorageBytes); }
        }

"""
assert new.count(addition)==1 and new.replace(addition,"")==old
out=lab/"owner-delivery"
out.mkdir(exist_ok=True)
for name in (p,Path("src/Lokad.Lython/Runtime/LythonRuntime.JsonModule.cs"),
             Path("tests/Lokad.Lython.PublicApi.Tests/JsonEncoderIterationLifetimeTests.cs")):
    (repo/name).write_bytes((source/name).read_bytes())
(out/"candidate.patch").write_bytes(subprocess.check_output(["git","diff","--binary","--","src","tests"],cwd=repo))
