from pathlib import Path
import subprocess

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
runtime=Path("src/Lokad.Lython/Runtime")
out=lab/"boxed"
out.mkdir(exist_ok=True)
assert (lab/"refined/candidate.patch").read_bytes()==subprocess.check_output(["git","diff","--binary","--","src","tests"],cwd=repo)
for name in ("LythonRuntime.TextFileHandle.cs", "LythonRuntime.TextFileHandle.Write.cs"):
    path=runtime/name
    base=subprocess.check_output(["git","show",f"d7dd3d4bd:{path.as_posix()}"],cwd=repo)
    (repo/path).write_bytes(base)
p=repo/runtime/"LythonRuntime.Calls.cs"
source=p.read_text(encoding="utf-8")
old="try { await receiver.WriteUtf8ChunkAsync(utf8, asynchronous).ConfigureAwait(false); }"
assert source.count(old)==1
p.write_text(source.replace(old,old.replace("WriteUtf8ChunkAsync","WriteUtf8Async")),encoding="utf-8",newline="\n")
(out/"candidate.patch").write_bytes(subprocess.check_output(["git","diff","--binary","--","src","tests"],cwd=repo))
