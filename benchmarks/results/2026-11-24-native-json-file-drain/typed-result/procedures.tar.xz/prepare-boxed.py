from pathlib import Path

lab=Path(__file__).resolve().parent
template=(lab/"prepare-refined.py").read_text(encoding="utf-8")
template=template.replace('refined=lab/"refined"', 'refined=lab/"boxed"')
template=template.replace('for name in ("representative.json","jobs.json"):', 'for name in ("representative.json",):')
start=template.index('save(quiet/"identity.json",identity)')
template=template[:start]+"""jobs=read(prior/"jobs.json")
jobs["warm"]=[row for row in jobs["warm"] if row[0]!="scripts.json-summary-helpers.small"]
assert len(jobs["warm"])==5
save(quiet/"jobs.json",jobs)
identity["catalogs"]["jobs.json"]["sha256"]=sha(quiet/"jobs.json")
"""+template[start:]
template=template.replace('Native JSON output with no scalar count or discarded result; original traversal retained',
                          'Native JSON output discards typed write results before boxing; counted writer and traversal unchanged')
template=template.replace('.replace("b1617-fixtures","b1618-fixtures")',
                            '.replace("b1617-fixtures","b1619-fixtures").replace("len(jobs) == 6","len(jobs) == 5")')
template=template.replace('native-json-file-countless-b1618', 'unused-json-write-result-b1619')
template=template.replace('lython-b1618-native-json-file-countless-', 'lython-b1619-unused-json-write-result-')
template=template.replace('launch=launch.replace("b1617-","b1618-")','launch=launch.replace("b1617-","b1619-").replace("seconds=198","seconds=170").replace("RuntimeMaxSec=255","RuntimeMaxSec=230")')
exec(compile(template,"paired timing staging", "exec"))
