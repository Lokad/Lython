from pathlib import Path
import hashlib
import json
import shutil
import sys
import tarfile

lab=Path(__file__).resolve().parent
root=lab.parents[3]
variant=sys.argv[1]
paths={"refined":"isolated","boxed":"typed-result"}
folder=lab/variant
out=root/"benchmarks/results/2026-11-24-native-json-file-drain"/paths[variant]
read=lambda p:json.loads(p.read_text(encoding="utf-8-sig"))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
identity=read(folder/"quiet/identity.json")
assert sha(folder/"candidate.patch")==identity["sourcePatchSHA256"]
for image,expected in identity["imageFiles"].items():
    assert len(expected)==32 and {p.name:sha(p)for p in (folder/image).iterdir()}==expected
    verify=read(folder/f"{image}-verify.json")
    assert verify["launched"]["library"]["sha256"]==expected["Lokad.Lython.dll"]
    assert verify["catalogSha256"]==identity["catalogs"]["representative.json"]["sha256"]
    assert verify["state"]=="Completed" and verify["caseCount"]==5
for platform in ("windows","ubuntu"):
    for test,count in (("public",1009),("white",329)):
        assert f"Passed:  {count:4d}" in (folder/f"{platform}-{test}.log").read_text(encoding="utf-8-sig")
allocation=read(folder/"allocation-summary.json")
assert len(allocation)==5 and allocation[0]["allocationBytes"]==[99640,96536]
assert all(row["peakAdmission"][0]==row["peakAdmission"][1] for row in allocation)
assert read(out/"quiet-summary.json")["sourcePatch"]==identity["sourcePatchSHA256"]
shutil.copyfile(folder/"quiet/identity.json",out/"identity.json")
shutil.copyfile(folder/"allocation-summary.json",out/"allocation-summary.json")
artifacts=["archive-refinements.py","prepare-refined.py","refine.py",f"{variant}/quiet.py",
           f"{variant}/archive-quiet.py",f"{variant}/quiet/collect.py",f"{variant}/quiet/run.sh"]
if variant=="boxed":artifacts+=["prepare-boxed.py","isolate-result.py"]
artifacts+=[f"{variant}/{name}"for name in (
    "candidate.patch","reference-verify.json","candidate-verify.json","test-ubuntu.sh","windows-public.log",
    "ubuntu-public.log","windows-white.log","ubuntu-white.log","prepare.log","quiet-launch.log","quiet-retrieve.log",
    "allocations.py","allocations.log","reference-allocation.json","candidate-allocation.json","allocation-summary.json",
    "quiet/storage-custody.json")]
with tarfile.open(out/"procedures.tar.xz","w:xz") as bundle:
    for file in artifacts:bundle.add(lab/file,arcname=file)
with tarfile.open(out/"procedures.tar.xz") as bundle:
    assert all(hashlib.sha256(bundle.extractfile(file).read()).hexdigest()==sha(lab/file) for file in artifacts)
print("Archived exact",variant,"patch and verification procedures")
