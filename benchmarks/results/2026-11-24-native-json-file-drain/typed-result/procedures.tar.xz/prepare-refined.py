from pathlib import Path
import hashlib,json,shutil,subprocess,tarfile,os

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
refined=lab/"refined"
prior=lab/"comparison"
quiet=refined/"quiet"
quiet.mkdir(exist_ok=True)
read=lambda p:json.loads(p.read_text(encoding="utf-8-sig"))
save=lambda p,v:p.write_text(json.dumps(v,indent=2)+"\n",encoding="utf-8",newline="\n")
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
identity=read(prior/"quiet/identity.json")
core="Lokad.Lython.dll"
fresh=repo/"src/Lokad.Lython/bin/Release/net11.0"/core
assert sha(fresh) not in {a[core] for a in identity["imageFiles"].values()}
identity["imageFiles"]["candidate"][core]=sha(fresh)
identity["coreSHA256"]["candidate"]=identity["coreSHA256"]["candidate-control"]=sha(fresh)
assert (refined/"candidate.patch").read_bytes()==subprocess.check_output(["git","diff","--binary","--","src","tests"],cwd=repo)
identity["sourcePatchSHA256"]=sha(refined/"candidate.patch")
identity["purpose"]="Native JSON output with no scalar count or discarded result; original traversal retained"
for role,manifest in identity["imageFiles"].items():
    path=refined/role
    path.mkdir(exist_ok=True)
    assert len(manifest)==32
    for name in manifest:
        shutil.copyfile(fresh if role=="candidate" and name==core else prior/"reference"/name,path/name)
    assert {p.name:sha(p)for p in path.iterdir()}==manifest
for name in ("representative.json","jobs.json"):
    shutil.copyfile(prior/name,quiet/name)
    assert sha(quiet/name)==identity["catalogs"][name]["sha256"]
save(quiet/"identity.json",identity)
src=prior/"quiet"
shutil.copyfile(src/"run.sh",quiet/"run.sh")
assert b"\r" not in (quiet/"run.sh").read_bytes()
collector=(src/"collect.py").read_text(encoding="utf-8").replace("b1617-fixtures","b1618-fixtures")
compile(collector,"collect.py","exec")
(quiet/"collect.py").write_text(collector,encoding="utf-8",newline="\n")
sdk=Path.home()/".dotnet11"
dotnet=sdk/"dotnet.exe"
python=Path("C:/Python313/python.exe")
env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk))
worker=prior/"cpython-worker.py"
for role in ("reference","candidate"):
    verify=refined/f"{role}-verify.json"
    subprocess.run([dotnet,refined/role/"Lokad.Lython.Benchmarks.dll","--compare","verify","--catalog",quiet/"representative.json",
                    "--dotnet",dotnet,"--python",python,"--python-worker",worker,"--out",verify],env=env,cwd=repo,
                   check=True,timeout=60)
    result=read(verify)
    assert result["state"]=="Completed" and result["caseCount"]==5
    assert result["launched"]["library"]["sha256"]==identity["imageFiles"][role][core]
    assert result["catalogSha256"]==identity["catalogs"]["representative.json"]["sha256"]
payload=quiet/"payload.tar.gz"
with tarfile.open(payload,"w:gz",compresslevel=3) as archive:
    for name in ("identity.json","jobs.json","representative.json","collect.py","run.sh"):
        archive.add(quiet/name,arcname=name,recursive=False)
    archive.add(refined/"candidate"/core,arcname="candidate-core.dll",recursive=False)
save(quiet/"upload.json",dict(root="native-json-file-countless-b1618-20261124",
                             reference="native-json-file-drain-b1617-20261124",payloadSHA256=sha(payload),payloadBytes=payload.stat().st_size))
save(refined/"verified-raw-replicas.json",[])
launch=(lab/"quiet.py").read_text(encoding="utf-8")
launch=launch.replace('quiet=lab/"comparison/quiet"','quiet=lab/"quiet"')
launch=launch.replace("lython-b1617-native-json-file-drain-","lython-b1618-native-json-file-countless-")
launch=launch.replace("b1617-","b1618-")
launch=launch.replace("'candidate-core.dll','reference-core.dll'","'candidate-core.dll'")
launch=launch.replace("if name=='Lokad.Lython.dll':", "if name=='Lokad.Lython.dll' and role=='candidate':")
launch=launch.replace("reference/'candidate'/name","reference/'reference'/name")
old_donor=read(lab.with_name("abstract-collection-graphs-20261124")/"comparison/quiet/terminal-status.json")["receipt"]["archiveSHA256"]
new_donor=read(src/"terminal-status.json")["receipt"]["archiveSHA256"]
assert old_donor in launch
launch=launch.replace(old_donor,new_donor).replace("needs two cores","needs one core")
compile(launch,"quiet.py","exec")
(refined/"quiet.py").write_text(launch,encoding="utf-8",newline="\n")
print("Five CPython goldens pass on both sealed refinement images")
