from pathlib import Path
import subprocess
import shutil

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
comparison=lab/"comparison"
file="src/Lokad.Lython/Runtime/LythonRuntime.Json.Encoder.cs"
final=lab/"refined"
final.mkdir(exist_ok=True)
(final/"b1617-final-tests.patch").write_bytes(subprocess.check_output(["git","diff","--binary","--","tests"],cwd=repo))
(final/"first-encoder.cs").write_bytes((repo/file).read_bytes())
baseline=subprocess.check_output(["git","show","d7dd3d4bd:"+file],cwd=repo).decode("utf-8")
old="await InvokeFileWriteAsync(target, _builder!.WrittenMemory, writeSpan ?? _span, _context, asynchronous).ConfigureAwait(false);"
assert baseline.count(old)==1
replacement=old.replace("InvokeFileWriteAsync", "InvokeFileWriteChunkAsync")
(repo/file).write_text(baseline.replace(old,replacement),encoding="utf-8",newline="\n")
(final/"candidate.patch").write_bytes(subprocess.check_output(["git","diff","--binary","--","src","tests"],cwd=repo))
