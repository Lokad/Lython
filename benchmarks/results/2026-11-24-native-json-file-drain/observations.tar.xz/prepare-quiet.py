from pathlib import Path
import hashlib,json,shutil,tarfile

lab=Path(__file__).resolve().parent
prior=lab.with_name("abstract-collection-graphs-20261124")
comparison=lab/"comparison"
quiet=comparison/"quiet"
quiet.mkdir(exist_ok=True)
read=lambda p:json.loads(p.read_text(encoding="utf-8-sig"))
save=lambda p,obj:p.write_text(json.dumps(obj,indent=2)+"\n",encoding="utf-8",newline="\n")
sha=lambda path:hashlib.sha256(path.read_bytes()).hexdigest()
identity=read(comparison/"identity.json")
donor=read(prior/"comparison/identity.json")
expected=read(prior/"comparison/quiet/terminal-status.json")["receipt"]["archiveSHA256"]
core="Lokad.Lython.dll"
assert all(identity["imageFiles"]["reference"][name]==digest for name,digest in donor["imageFiles"]["candidate"].items() if name!=core)
identity["expectedCPythonSHA256"]=donor["expectedCPythonSHA256"]
identity["purpose"]="Native JSON file output without per-chunk traversal reentry and discarded character results"
save(quiet/"identity.json",identity)
collector=(prior/"comparison/quiet/collect.py").read_text(encoding="utf-8")
collector=collector.replace("('compile','compile-run','warm')","('compile','compile-run','warm','warm-async')")
collector=collector.replace("8 seconds","5 seconds").replace("warmupSeconds=8, targetBatchSeconds=.36","warmupSeconds=5, targetBatchSeconds=.28")
collector=collector.replace("b1613-fixtures","b1617-fixtures")
compile(collector,"collect.py","exec")
(quiet/"collect.py").write_text(collector,encoding="utf-8",newline="\n")
shutil.copyfile(prior/"comparison/quiet/run.sh",quiet/"run.sh")
assert b"\r" not in (quiet/"run.sh").read_bytes()
payload=quiet/"payload.tar.gz"
with tarfile.open(payload,"w:gz",compresslevel=3) as spool:
    for name in ("collect.py","run.sh","identity.json"):
        spool.add(quiet/name,arcname=name,recursive=False)
    for name in ("representative.json","jobs.json"):
        spool.add(comparison/name,arcname=name,recursive=False)
    for role,files in identity["imageFiles"].items():
        assert len(files)==32 and {p.name:sha(p) for p in (comparison/role).iterdir()}==files
        spool.add(comparison/role/core,arcname=role+"-core.dll",recursive=False)
save(quiet/"upload.json",dict(root="native-json-file-drain-b1617-20261124",reference="abstract-collection-graphs-b1613-20261124",
                             payloadSHA256=sha(payload),payloadBytes=payload.stat().st_size))
save(lab/"verified-raw-replicas.json",[])
launcher=(prior/"quiet.py").read_text(encoding="utf-8")
launcher=launcher.replace('lython-b1613-abstract-collection-graphs-','lython-b1617-native-json-file-drain-')
launcher=launcher.replace('b1613-', 'b1617-').replace('b1608-', 'b1617-reserved-unused-')
launcher=launcher.replace('seconds=306','seconds=198').replace('RuntimeMaxSec=368','RuntimeMaxSec=255')
launcher=launcher.replace("'collect.py','candidate-core.dll'", "'collect.py','candidate-core.dll','reference-core.dll'")
launcher=launcher.replace("if name=='Lokad.Lython.dll' and role=='candidate':", "if name=='Lokad.Lython.dll':")
launcher=launcher.replace("needs one core, receipts and working room","needs two cores, receipts and working room")
launcher=launcher.replace('b444f405c74f6e683881abe4bfed7035a909962168744492d56f74edc3be9b10',expected)
compile(launcher,"quiet.py","exec")
(lab/"quiet.py").write_text(launcher,encoding="utf-8",newline="\n")
print("Prepared six quiet lanes, verified source-paired 32-file staging")
