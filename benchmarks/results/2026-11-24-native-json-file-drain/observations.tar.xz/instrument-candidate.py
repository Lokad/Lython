import shutil
import subprocess
from pathlib import Path

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
worktree = repo / ".git/agent-worktrees/json-file-drain-diagnostic-20261124"
root = Path("src/Lokad.Lython/Runtime")
files = ["LythonRuntime.Json.Encoder.cs","LythonRuntime.TextFileHandle.cs","LythonRuntime.TextFileHandle.Write.cs","LythonRuntime.Calls.cs"]
(lab/"reference-census.patch").write_bytes(subprocess.check_output(["git","-C",worktree,"diff","--binary"]))
for name in files:
    shutil.copyfile(repo/root/name,worktree/root/name)
encoder=worktree/root/files[0]
s=encoder.read_text(encoding="utf-8")
s=s.replace("        private int _advancing;", "        private int _advancing;\n\n        internal static readonly long[] FileDrainDiagnostic = new long[10];")
old="""        internal async ValueTask WriteToAsync(ExecutionContext.TextFileHandle target, LythonSourceSpan span, bool asynchronous)
            => _ = await TryMoveNextCoreAsync(asynchronous, target, span).ConfigureAwait(false);"""
assert s.count(old)==1
s=s.replace(old,"""        internal async ValueTask WriteToAsync(ExecutionContext.TextFileHandle target, LythonSourceSpan span, bool asynchronous)
        {
            Interlocked.Increment(ref FileDrainDiagnostic[asynchronous ? 5 : 0]);
            _ = await TryMoveNextCoreAsync(asynchronous, target, span).ConfigureAwait(false);
        }""")
line="                if (await EmitAsync(asynchronous, stopAtChunk: true, target, writeSpan).ConfigureAwait(false))"
assert s.count(line)==1
s=s.replace(line,"                if (target is not null) Interlocked.Increment(ref FileDrainDiagnostic[asynchronous ? 6 : 1]);\n"+line)
line="                await InvokeFileWriteChunkAsync(target, builder.WrittenMemory, writeSpan ?? _span, _context, asynchronous).ConfigureAwait(false);"
assert s.count(line)==1
s=s.replace(line,"""                var start = asynchronous ? 5 : 0;
                Interlocked.Increment(ref FileDrainDiagnostic[start + 2]);
                Interlocked.Add(ref FileDrainDiagnostic[start + 4], builder.Length);
                var write = InvokeFileWriteChunkAsync(target, builder.WrittenMemory, writeSpan ?? _span, _context, asynchronous);
                if (!write.IsCompleted) Interlocked.Increment(ref FileDrainDiagnostic[start + 3]);
                await write.ConfigureAwait(false);""")
encoder.write_text(s,encoding="utf-8",newline="\n")
(lab/"candidate-census.patch").write_bytes(subprocess.check_output(["git","-C",worktree,"diff","--binary"]))
driver=(lab/"census.py").read_text(encoding="utf-8")
driver=driver.replace('"census-image"','"candidate-census-image"').replace('+".counts.json"', '+".candidate-counts.json"').replace('"census.json"','"candidate-census.json"')
(lab/"candidate-census.py").write_text(driver,encoding="utf-8",newline="\n")
