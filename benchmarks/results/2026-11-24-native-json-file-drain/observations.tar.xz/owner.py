from pathlib import Path
import hashlib
import os
import shutil
import subprocess
import json

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
tool=lab/"owner"
origin=tool/"bin/Release/net11.0"
sdk=Path.home()/".dotnet11"
test=repo/"tests/Lokad.Lython.PublicApi.Tests/bin/Release/net11.0"
env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk))
for role in ("reference","candidate"):
    folder=lab/(role+"-owner")
    folder.mkdir(exist_ok=True)
    for p in test.iterdir():
        if p.is_file() and p.suffix.lower() not in (".pdb",".exe"):
            shutil.copyfile(p,folder/p.name)
    for p in origin.glob("Owner.*"):
        if p.suffix.lower() not in (".pdb",".exe"):
            shutil.copyfile(p,folder/p.name)
    core=lab/"comparison"/role/"Lokad.Lython.dll"
    shutil.copyfile(core,folder/core.name)
    tested=subprocess.run([sdk/"dotnet.exe",folder/"Owner.dll",folder/"Lokad.Lython.PublicApi.Tests.dll",
                          lab/"file-chunk-oracle-source.py"],env=env,check=True,capture_output=True,text=True,encoding="utf-8",timeout=35)
    result=json.loads(tested.stdout)
    assert result["sha"]==hashlib.sha256(core.read_bytes()).hexdigest()
    (lab/(role+"-owner.json")).write_text(json.dumps(result,indent=2)+"\n",encoding="utf-8")
    print(role,[(row["id"],row["async"],row["ReturnValue"],row["PeakExecutionMemoryBytes"])for row in result["rows"]])
