import json
offsets=[]
def fallback(value):
    offsets.append(target.tell())
    if len(offsets)==1:
        return 'kept'
    raise TypeError('stop encoding')
with open('output', 'w', encoding='utf-8', newline='') as target:
    try:
        json.dump([1, {2}, {3}], target, default=fallback)
    except TypeError as error:
        assert str(error)=='stop encoding'
with open('output', encoding='utf-8') as source:
    print(offsets, repr(source.read()))
