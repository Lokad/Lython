#!/bin/sh
set -eu
cd /mnt/d/code/Lython
export DOTNET_ROOT="$HOME/.dotnet" PATH="$HOME/.dotnet:$PATH"
dotnet test tests/Lokad.Lython.PublicApi.Tests -c Release -f net11.0 --artifacts-path .git/agent-notes/review-20261031/callable-pair-rollback-20261124/ubuntu --nologo --filter 'FullyQualifiedName~JsonEncoderIterationLifetimeTests|FullyQualifiedName~ImplicitTextBatchesAwaitTheRealProducerBorrowAndCleanup'
