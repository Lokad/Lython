from pathlib import Path

repo = Path.cwd()
worktree = repo / ".git/agent-worktrees/json-file-drain-diagnostic-20261124"
encoder = worktree / "src/Lokad.Lython/Runtime/LythonRuntime.Json.Encoder.cs"
s = encoder.read_text(encoding="utf-8-sig")
field = "        private int _advancing;"
assert s.count(field) == 1
s = s.replace(field, field + "\n\n        internal static readonly long[] FileDrainDiagnostic = new long[10];")
entry = """        internal async ValueTask WriteToAsync(ExecutionContext.TextFileHandle target, LythonSourceSpan span, bool asynchronous)
            => _ = await TryMoveNextCoreAsync(asynchronous, target, span).ConfigureAwait(false);"""
assert s.count(entry) == 1
s = s.replace(entry, """        internal async ValueTask WriteToAsync(ExecutionContext.TextFileHandle target, LythonSourceSpan span, bool asynchronous)
        {
            Interlocked.Increment(ref FileDrainDiagnostic[asynchronous ? 5 : 0]);
            _ = await TryMoveNextCoreAsync(asynchronous, target, span).ConfigureAwait(false);
        }""")
stage = "                        if (!await EmitAsync(asynchronous, stopAtChunk: true).ConfigureAwait(false))"
assert s.count(stage) == 1
s = s.replace(stage, "                        if (target is not null) Interlocked.Increment(ref FileDrainDiagnostic[asynchronous ? 6 : 1]);\n" + stage)
sink = "                    await InvokeFileWriteAsync(target, _builder!.WrittenMemory, writeSpan ?? _span, _context, asynchronous).ConfigureAwait(false);"
assert s.count(sink) == 1
s = s.replace(sink, """                    var start = asynchronous ? 5 : 0;
                    Interlocked.Increment(ref FileDrainDiagnostic[start + 2]);
                    Interlocked.Add(ref FileDrainDiagnostic[start + 4], _builder!.Length);
                    var write = InvokeFileWriteAsync(target, _builder.WrittenMemory, writeSpan ?? _span, _context, asynchronous);
                    if (!write.IsCompleted) Interlocked.Increment(ref FileDrainDiagnostic[start + 3]);
                    _ = await write.ConfigureAwait(false);""")
encoder.write_text(s, encoding="utf-8", newline="\n")
worker = worktree / "benchmarks/Lokad.Lython.Benchmarks/Comparison/LythonComparisonWorker.cs"
s = worker.read_text(encoding="utf-8-sig")
entry = "        if (MemoryBudget.ReservedBytes != 0)"
assert s.count(entry) == 1
s = s.replace(entry, """        if (Environment.GetEnvironmentVariable("LYTHON_CENSUS_FILE") is { } censusFile)
        {
            var type = typeof(LythonEngine).Assembly.GetType("Lokad.Lython.Runtime.LythonRuntime+JsonEncodeIterator", throwOnError: true)!;
            var rows = (long[])type.GetField("FileDrainDiagnostic", BindingFlags.NonPublic | BindingFlags.Static)!.GetValue(null)!;
            File.WriteAllText(censusFile, JsonSerializer.Serialize(rows));
        }
""" + entry)
worker.write_text(s, encoding="utf-8", newline="\n")
