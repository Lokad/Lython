from pathlib import Path

lab = Path(__file__).resolve().parent
prior = lab.with_name("builtin-shadowing-20261124")
template = (prior/"prepare.py").read_text(encoding="utf-8")
template = template.replace('previous = lab.parent / "abstract-collection-graphs-20261124"', 'previous = lab.with_name("builtin-shadowing-20261124") / "comparison"')
template = template.replace('fresh = repo / "tools/LythonProbe/bin/Release/net11.0" / core','fresh = repo / "src/Lokad.Lython/bin/Release/net11.0" / core')
start = template.index('catalog = comparison / "representative.json"')
end = template.index("head = subprocess.check_output", start)
template = template[:start] + """catalog = comparison / "representative.json"
worker = comparison / "cpython-worker.py"
shutil.copyfile(repo / "benchmarks/cpython-worker.py", worker)
def workloads(path): return read(path/"representative.json")["cases"]
selected = [
    "scripts.config-manifest.small",
    "scripts.json-summary-helpers.small",
    "scripts.json-lines-shipment.expanded-options.large",
    "scripts.json-lines-shipment.default-options.large",
    "scripts.csv-invoice.method-policy.quoted-control",
]
cases=workloads(previous)+workloads(lab.with_name("json-traversal-20261124")/"comparison")
chosen=[next(case for case in cases if case["id"]==key) for key in selected]
save(catalog,read(previous/"representative.json")|{"cases":chosen})
save(comparison/"jobs.json", {"warm":[[case,"warm"] for case in selected]+[[selected[0],"warm-async"]]})

""" + template[end:]
template=template.replace('assert head.startswith("b65d6bd96")', 'assert head.startswith("d7dd3d4bd")')
template=template.replace('comparisonRevision="0bf516c798528ed4ecfa7d3ce78e867043e1b4fd"', 'comparisonRevision=head')
template=template.replace("for role in images:", "for role in images:")
template=template.replace('len(cases)', 'len(chosen)')
start = template.index('previous_collector=')
template=template[:start] + """previous_collector=previous/"collect.py"
collector=previous_collector.read_text(encoding="utf-8").replace("('compile','compile-run','warm')","('compile','compile-run','warm','warm-async')")
collector=collector.replace("lython-builtin-compare-", "lython-json-file-compare-")
(comparison/"collect.py").write_text(collector,encoding="utf-8",newline="\\n")
print("Both stable 32-file images passed all five complete CPython goldens")
"""
exec(compile(template, "derived existing worker staging", "exec"))
