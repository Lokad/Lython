using System.Reflection;
using System.Security.Cryptography;
using System.Text.Json;
using Lokad.Lython;

var mock = Assembly.LoadFrom(args[0]).GetType("Lokad.Lython.Tests.Harness.MockLythonHost", true)!;
var fileSource = File.ReadAllText(args[1]).Replace("print(offsets, repr(source.read()))", "return repr((offsets, source.read()))");
var rows = new List<object>();
Measure("callback", fileSource);
foreach (var count in new[] { 64, 256, 1024 })
foreach (var dump in new[] { true, false })
{
    var write = dump ? "json.dump(0, target)" : "target.write('0')";
    var source = $"import json\nwith open('/out', 'w') as target:\n    for i in range({count}):\n        {write}\n    return str(target.tell())";
    Measure($"{(dump ? "json" : "control")}-{count}", source);
}
var sha = Convert.ToHexStringLower(SHA256.HashData(File.ReadAllBytes(typeof(LythonEngine).Assembly.Location)));
Console.WriteLine(JsonSerializer.Serialize(new { sha, rows }));

void Measure(string id, string source)
{
    var budget = new LythonMemoryBudget();
    using (var script = new LythonEngine().Compile(source, budget))
    {
        if (!script.IsValid) throw new Exception(string.Join("\n", script.Diagnostics));
        var baseline = budget.ReservedBytes;
        foreach (var async in new[] { false, true })
        {
            var host = (ILythonHost)Activator.CreateInstance(mock, nonPublic: true)!;
            using (var result = async ? script.RunAsync(host).GetAwaiter().GetResult() : script.Run(host))
            {
                if (!result.Success) throw new Exception(result.Failure?.Message);
                rows.Add(new { id, async, result.ReturnValue, result.PeakExecutionMemoryBytes,
                               liveAtResult = budget.ReservedBytes - baseline });
            }
            if (budget.ReservedBytes != baseline) throw new Exception("Execution retained budget.");
        }
    }
    if (budget.ReservedBytes != 0) throw new Exception("Compilation retained budget.");
}
