from pathlib import Path
import hashlib, json, os, stat, fcntl

base=Path("/home/lokad/lython-bench-checks").resolve()
roots=(
    "abstract-compiler-cpython-b1614-20261124",
    "abstract-collection-graphs-b1613-20261124",
    "json-traversal-b1586-20261124",
    "eager-json-owner-b1588-20261124",
    "closed-capture-cpython-b1604-20261124",
    "closed-line-helper-cpython-b1609-20261124",
)
same={}
skipped=[]
read=lambda p:json.loads(p.read_text(encoding="utf-8"))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
with (base/"comparison-vm.lock").open("a") as lease:
    fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
    for name in roots:
        root=base/name
        if not all((root/f).is_file() for f in ("archive-receipt.json","observations.tar.xz","identity.json","exit-code.txt")):
            continue
        assert root.resolve()==root and (root/"exit-code.txt").read_text().strip()=="0"
        receipt=read(root/"archive-receipt.json")
        if not receipt["complete"]:continue
        assert sha(root/"observations.tar.xz")==receipt["archiveSHA256"]
        for role, files in read(root/"identity.json")["imageFiles"].items():
            directory=root/role
            if not directory.is_dir() or len(files)!=32:continue
            assert directory.resolve()==directory
            for file,digest in files.items():
                full=directory/file
                if full.resolve()!=full or full.parent!=directory or not full.is_file() or sha(full)!=digest:
                    skipped.append(str(full.relative_to(base)))
                    continue
                attributes=full.stat()
                assert stat.S_ISREG(attributes.st_mode) and sha(full)==digest
                if attributes.st_size<100000:continue
                same.setdefault((digest,attributes.st_mode,attributes.st_uid,attributes.st_gid),[]).append(
                    dict(path=str(full.relative_to(base)),blocks=attributes.st_blocks,size=attributes.st_size,
                         inode=attributes.st_ino,links=attributes.st_nlink,sha256=digest))
    groups=[]
    for entries in same.values():
        canonical=max(entries,key=lambda entry:entry["links"])
        targets=[entry for entry in entries if entry["inode"]!=canonical["inode"] and entry["links"]==1]
        if targets: groups.append([canonical,*targets])
    bytes=sum(p["blocks"]*512 for group in groups for p in group[1:])
    print(json.dumps(dict(available=os.statvfs(base).f_bavail*os.statvfs(base).f_frsize,recoverableBytes=bytes,groups=groups,skipped=skipped),indent=2))
