import json
import subprocess
import tempfile
from pathlib import Path

lab=Path(__file__).resolve().parent
source="""import json
offsets=[]
def fallback(value):
    offsets.append(target.tell())
    if len(offsets)==1:
        return 'kept'
    raise TypeError('stop encoding')
with open('output', 'w', encoding='utf-8', newline='') as target:
    try:
        json.dump([1, {2}, {3}], target, default=fallback)
    except TypeError as error:
        assert str(error)=='stop encoding'
with open('output', encoding='utf-8') as source:
    print(offsets, repr(source.read()))
"""
(lab/"file-chunk-oracle-source.py").write_text(source,encoding="utf-8",newline="\n")
with tempfile.TemporaryDirectory(prefix="lython-json-file-oracle-") as root:
    python=Path("C:/Python313/python.exe")
    version=subprocess.check_output([python,"--version"],encoding="utf-8").strip()
    command=subprocess.run([python,"-I","-X","utf8","-c",source],cwd=root,capture_output=True,text=True,encoding="utf-8",timeout=20)
    output={"cpython":version,"exitCode":command.returncode,"stdout":command.stdout,"stderr":command.stderr,
            "file":(Path(root)/"output").read_bytes().hex()}


(lab/"file-chunk-oracle.json").write_text(json.dumps(output,indent=2)+"\n",encoding="utf-8")
print(output)
