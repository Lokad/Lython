from pathlib import Path
import fcntl
import hashlib
import json
import os
import stat

base=Path("/home/lokad/lython-bench-checks").resolve()
project=base/"method-body-bytecode-20261011"
a=project/"baseline-full-catalog.json"
b=project/"candidate-full-catalog.json"
expected="c5031ac6bdc78d2218698c71d8aeb5a2f95277ffedffe572604597c5d633b6a6"
def digest(path): return hashlib.sha256(path.read_bytes()).hexdigest()
def available():
    stats=os.statvfs(base)
    return stats.f_bavail*stats.f_frsize

with (base/"comparison-vm.lock").open("a") as lease:
    fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
    before=available()
    details=[]
    for path in (a,b):
        assert path.resolve()==path and path.parent==project and digest(path)==expected
        s=path.stat()
        assert stat.S_ISREG(s.st_mode) and s.st_uid==os.getuid() and s.st_size==11863087
        details.append(dict(inode=s.st_ino,mode=s.st_mode,owner=s.st_uid,group=s.st_gid,
                            mtimeNs=s.st_mtime_ns,links=s.st_nlink))
    assert all(details[0][k]==details[1][k] for k in ("owner","group","mode"))
    if details[0]["inode"]!=details[1]["inode"]:
        assert details[1]["links"]==1
        temp=b.with_name(".lython-exact-catalog-"+str(os.getpid()))
        assert not temp.exists()
        os.link(a,temp)
        try:
            os.replace(temp,b)
        finally:
            if temp.exists(): temp.unlink()
    assert os.path.samefile(a,b) and digest(a)==expected and digest(b)==expected
    print(json.dumps(dict(before=before,after=available(),sha256=expected,originalMetadata=details,
                          preservedPaths=[str(a.relative_to(base)),str(b.relative_to(base))])))
