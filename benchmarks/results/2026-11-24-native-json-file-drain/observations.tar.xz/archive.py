from pathlib import Path
from statistics import median
import hashlib
import json
import shutil
import tarfile

lab=Path(__file__).resolve().parent
root=lab.parents[3]
comparison=lab/"comparison"
out=root/"benchmarks/results/2026-11-24-native-json-file-drain"
read=lambda path: json.loads(path.read_text(encoding="utf-8-sig"))
sha=lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
identity=read(comparison/"identity.json")
assert sha(lab/"candidate.patch")==identity["sourcePatchSHA256"]
for role,manifest in identity["imageFiles"].items():
    assert len(manifest)==32
    assert {p.name:sha(p) for p in (comparison/role).iterdir()}==manifest
    verification=read(comparison/f"{role}-verify.json")
    assert verification["state"]=="Completed" and verification["caseCount"]==5
    assert verification["launched"]["library"]["sha256"]==manifest["Lokad.Lython.dll"]
    assert verification["catalogSha256"]==identity["catalogs"]["representative.json"]["sha256"]

counts=(read(lab/"census.json"),read(lab/"candidate-census.json"))
assert counts[0]["catalogSHA256"]==counts[1]["catalogSHA256"]
for before,after in zip(counts[0]["rows"],counts[1]["rows"],strict=True):
    assert before["case"]==after["case"]
    for mode in ("sync","asynchronous"):
        a,b=before[mode],after[mode]
        assert len(a)==len(b)==5 and all(a[k]==b[k] for k in a if k!="emitEntries")
        assert b["emitEntries"]==b["drains"] and a["emitEntries"]==a["drains"]+a["writes"] and b["incompleteWrites"]==0
assert counts[0]["rows"][0]["sync"]["writes"]==97

raw=read(comparison/"confirmation/confirmation.json")
assert raw["sourceRevision"]==identity["sourceRevision"] and raw["complete"]
assert len(raw["jobs"])==6 and all(row["workersJoinedAndFixturesRemoved"] for row in raw["jobs"])
assert [[row["case"],row["lane"]] for row in raw["jobs"]]==read(comparison/"jobs.json")["warm"]
changes=[]
for job in raw["jobs"]:
    elapsed,cpu={},{}
    assert len(job["samples"])==20 and set(job["identities"])==set(identity["coreSHA256"])
    for worker,ready in job["identities"].items():
        own_core=next(entry["sha256"]for entry in ready["libraries"]if Path(entry["path"]).name=="Lokad.Lython.dll")
        assert own_core==identity["coreSHA256"][worker]
        assert ready["catalogSha256"]==identity["catalogs"]["representative.json"]["sha256"]
        samples=[sample for sample in job["samples"] if sample["engine"]==worker]
        assert len(samples)==5
        elapsed[worker]=median(sample["response"]["elapsedTicks"]*1000/sample["response"]["clockFrequency"]/sample["response"]["completedInvocations"] for sample in samples)
        cpu[worker]=median(sample["externalProcessCpuTicks"]*1000/sample["externalCpuFrequency"]/sample["response"]["completedInvocations"] for sample in samples)
    def span(values):
        pairs=[(values[c]/values[r]-1)*100 for c in ("candidate","candidate-control")for r in ("reference","reference-control")]
        return [min(pairs),max(pairs)]
    spreads=[(max(elapsed[r],elapsed[r+"-control"])/min(elapsed[r],elapsed[r+"-control"])-1)*100 for r in ("reference","candidate")]
    row=dict(case=job["case"],lane=job["lane"],elapsedPercent=span(elapsed),cpuPercent=span(cpu),
             elapsedMediansMs=elapsed,widerCpuMediansMs=cpu,sameSourceElapsedSpreadPercent=spreads)
    print(job["lane"],job["case"],*([f"{n:+.2f}%"for n in row[key]]for key in ("elapsedPercent","cpuPercent","sameSourceElapsedSpreadPercent")))
    changes.append(row)

allocation=read(lab/"allocation-summary.json")
assert len(allocation)==5
assert allocation[0]["allocationBytes"]==[99640,96536]
assert all(row["peakAdmission"][0]==row["peakAdmission"][1] for row in allocation)
for platform in ("windows","ubuntu"):
    for suite,number in (("public",1009),("white",329)):
        assert f"Passed:  {number:4d}" in (lab/f"{platform}-{suite}.log").read_text(encoding="utf-8-sig")

out.mkdir(exist_ok=True)
summary=dict(sourcePatch=identity["sourcePatchSHA256"],reference=identity["comparisonRevision"],timedBatches=120,
             performanceQualified=False,collectorSeconds=raw["elapsedSeconds"],rows=changes,allocations=allocation)
(out/"summary.json").write_text(json.dumps(summary,indent=2)+"\n",encoding="utf-8",newline="\n")
shutil.copyfile(comparison/"identity.json",out/"identity.json")
artifacts=("archive.py","candidate.patch","prepare.py","prepare.log","comparison/collect.py","comparison/representative.json",
           "comparison/jobs.json","comparison/reference-verify.json","comparison/candidate-verify.json",
           "comparison/confirmation/confirmation.json","comparison.log","test-ubuntu.sh","windows-public.log",
           "windows-white.log","ubuntu-public.log","ubuntu-white.log","census-build.log","candidate-census-build.log",
           "census.json","candidate-census.json","census.py","candidate-census.py","instrument.py","instrument-candidate.py",
           "reference-census.patch","candidate-census.patch","allocations.py","allocations.log","reference-allocation.json",
           "candidate-allocation.json","allocation-summary.json","inspect-quiet-storage.py","quiet-storage.json",
           "quiet-storage-dedup.json","compact-duplicate-catalogs.py","compact-related-catalogs.py",
           "catalog-custody.json","related-catalog-custody.json","prepare-quiet.py","quiet.py","archive-quiet.py",
           "quiet-launch.log","quiet-retrieve.log","comparison/quiet/identity.json","comparison/quiet/storage-custody.json",
           "file-chunk-oracle.py","file-chunk-oracle-source.py","file-chunk-oracle.json","file-chunk-oracle-original.py",
           "file-chunk-oracle-original.json","owner.py","owner/Program.cs","owner/Owner.csproj","owner-build.log",
           "reference-owner.json","candidate-owner.json","test-final-ubuntu.sh","windows-final-targeted.log",
           "ubuntu-final-targeted.log","refined/b1617-final-tests.patch")
with tarfile.open(out/"observations.tar.xz","w:xz") as bundle:
    for name in artifacts:bundle.add(lab/name,arcname=name)
with tarfile.open(out/"observations.tar.xz") as bundle:
    assert all(hashlib.sha256(bundle.extractfile(path).read()).hexdigest()==sha(lab/path) for path in artifacts)
print("Archived the frozen patch, original results and all 120 verified batches")
