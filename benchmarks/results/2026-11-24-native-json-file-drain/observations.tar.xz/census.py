import hashlib
import importlib.util
import json
import os
import shutil
import subprocess
import tempfile
from pathlib import Path

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
old = repo / ".git/agent-notes/review-20261031/builtin-shadowing-20261124" / "comparison"
origin = repo / ".git/agent-worktrees/json-file-drain-diagnostic-20261124" / "benchmarks/Lokad.Lython.Benchmarks/bin/Release/net11.0"
image = lab / "census-image"
image.mkdir(exist_ok=True)
for src in origin.iterdir():
    if src.is_file() and src.suffix.lower() not in (".pdb", ".exe"):
        shutil.copyfile(src,image/src.name)
assert len(list(image.iterdir()))==32
digest=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
manifest={file.name:digest(file) for file in image.iterdir()}
assert manifest["Lokad.Lython.dll"]!=json.loads((old/"identity.json").read_text(encoding="utf-8"))["imageFiles"]["candidate"]["Lokad.Lython.dll"]
catalog=old/"representative.json"
spec=importlib.util.spec_from_file_location("protocol",old/"cpython-worker.py")
protocol=importlib.util.module_from_spec(spec)
spec.loader.exec_module(protocol)
sdk=Path.home()/".dotnet11"
cases=json.loads(catalog.read_text(encoding="utf-8"))["cases"]
rows=[]
for case in (cases[0], cases[-1], cases[-2]):
    out=(lab/(case["id"]+".counts.json")).resolve()
    env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk),LYTHON_CENSUS_FILE=str(out))
    stdin=tempfile.TemporaryFile()
    expected={key:case[key] for key in ["sourceSha256","fixtureSha256","expectedOutputSha256"]}
    for serial,operation,lane in ((1,"verify","warm"),(2,"batch","warm-async"),(3,"quit","warm")):
        protocol.write_frame(stdin,dict(expected,requestId=serial,protocolVersion=protocol.PROTOCOL_VERSION,
                                       operation=operation,caseId=case["id"],lane=lane,iterations=1))
    stdin.seek(0)
    with tempfile.TemporaryDirectory(prefix="lython-comparison-files-") as fixtures:
        run=subprocess.run([sdk/"dotnet.exe",image/"Lokad.Lython.Benchmarks.dll","--compare","worker","--catalog",catalog],
            cwd=fixtures,env=env,stdin=stdin,capture_output=True,timeout=35)
    stdin.close()
    assert run.returncode==0,run.stderr.decode("utf-8",errors="replace")
    from io import BytesIO
    messages=BytesIO(run.stdout)
    ready=protocol.read_frame(messages)
    assert ready["status"]=="Ready" and ready["catalogSha256"]==digest(catalog)
    assert next(item["sha256"]for item in ready["libraries"] if item["path"].endswith("Lokad.Lython.dll"))==manifest["Lokad.Lython.dll"]
    verify=protocol.read_frame(messages)
    assert verify["status"]=="Equivalent" and verify["completedInvocations"]==2
    async_response=protocol.read_frame(messages)
    assert async_response["status"]=="Completed" and async_response["completedInvocations"]==1
    assert async_response["actualOutputSha256"]==case["expectedOutputSha256"]
    assert async_response.get("actualFilesSha256")==case.get("expectedFilesSha256")
    assert protocol.read_frame(messages)["status"]=="Closed" and not messages.read(1)
    values=json.loads(out.read_text(encoding="utf-8"))
    assert len(values)==10 and all(value%2==0 for value in values[:5])
    columns=["drains","emitEntries","writes","incompleteWrites","utf8Bytes"]
    sync={field:n//2 for field,n in zip(columns,values[:5])}
    asynchronous=dict(zip(columns,values[5:]))
    rows.append(dict(case=case["id"],sync=sync,asynchronous=asynchronous,verify=verify,asyncResponse=async_response))
    print(case["id"],sync,asynchronous)
assert [{file.name:digest(file) for file in image.iterdir()}]==[manifest]
summary=dict(qualifiesPerformance=False,diagnosticImage=manifest,catalogSHA256=digest(catalog),rows=rows)
(lab/"census.json").write_text(json.dumps(summary,indent=2)+"\n",encoding="utf-8",newline="\n")
