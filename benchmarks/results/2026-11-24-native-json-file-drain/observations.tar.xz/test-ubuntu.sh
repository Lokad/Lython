#!/bin/sh
set -eu
cd /mnt/d/code/Lython
export DOTNET_ROOT="$HOME/.dotnet" PATH="$HOME/.dotnet:$PATH"
lab=.git/agent-notes/review-20261031/json-file-drain-20261124
assets=.git/agent-notes/review-20261031/callable-pair-rollback-20261124/ubuntu
white='Category!=Stress&(FullyQualifiedName~Json|FullyQualifiedName~File)'
public='Category!=Stress&(FullyQualifiedName~Json|FullyQualifiedName~OwnedByteFileTests|FullyQualifiedName~CsvModule|FullyQualifiedName~GovernedAdmissionPreflightTests)'
dotnet test tests/Lokad.Lython.Tests -c Release -f net11.0 --artifacts-path "$assets" --nologo --filter "$white" > "$lab/ubuntu-white.log" 2>&1 || { tail -50 "$lab/ubuntu-white.log"; exit 1; }
dotnet test tests/Lokad.Lython.PublicApi.Tests -c Release -f net11.0 --artifacts-path "$assets" --nologo --filter "$public" > "$lab/ubuntu-public.log" 2>&1 || { tail -50 "$lab/ubuntu-public.log"; exit 1; }
awk '/Passed!/{n++;print} END{exit n!=2}' "$lab/ubuntu-white.log" "$lab/ubuntu-public.log"
