from pathlib import Path
lab=Path(__file__).resolve().parent
old=lab.with_name('private-definition-call-20261124')
source=(old/'prepare-route.py').read_text(encoding='utf-8-sig')
source=source.replace("donor = lab.parent / 'closed-factory-pairs-entry-20261124'","donor = lab.parent / 'private-call-isolation-20261124'")
source=source.replace("rev = '689ad2b7c'","rev = '97313e53b'").replace("reference = '722b49f2d'","reference = 'ad88474bb'")
a=source.index("    'LythonRuntime.Executable.NativeDefinitions.cs':(")
b=source.index("    'PyExecutableFunction.cs':(",a)
source=source[:a]+'''    'LythonRuntime.Executable.NativeDefinitions.cs':(
        '        destination[0].Object = second;',
        '        destination[0].Object = second;\\n        System.Console.Error.WriteLine("LYTHON_ROUTE captured-pair " + factory.Name);'),
''' + source[b:]
source=source.replace("routes=(donor/'routes.py').read_text(encoding='utf-8')\nstart=routes.index(\"assert all(row['routes']['direct-pair\")","routes=(lab.with_name('private-definition-call-20261124')/'routes.py').read_text(encoding='utf-8')\nstart=routes.index(\"affected='scripts.captured-rule-closures'\")")
source=source.replace("row['routes']['private-call alternate']","row['routes']['captured-pair make_rules']").replace("row['routes']['workspace make_rules']==8192","row['routes']['workspace make_rules']==0")
compile(source,'prepare-route.py','exec')
(lab/'prepare-route.py').write_text(source,encoding='utf-8',newline='\n')
