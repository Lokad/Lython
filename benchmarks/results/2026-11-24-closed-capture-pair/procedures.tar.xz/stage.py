from pathlib import Path
import ast
import hashlib
import json
import os
import re
import shutil
import subprocess
import tarfile

lab=Path(__file__).resolve().parent
root=lab.parents[3]
donor=lab.with_name('private-call-isolation-20261124')
old=lab.with_name('private-definition-call-20261124')
comparison=lab/'comparison'
quiet=comparison/'quiet'
quiet.mkdir(exist_ok=True)
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda payload:hashlib.sha256(payload).hexdigest()
digest=lambda p:sha(p.read_bytes())
write=lambda p,s:p.write_text(s,encoding='utf-8',newline='\n')
save=lambda p,data:write(p,json.dumps(data,indent=2)+'\n')
git=lambda p:subprocess.check_output(['git','show','origin/master:'+p.relative_to(root).as_posix()],cwd=root)
meta=read(comparison/'identity.json')
original=read(donor/'comparison/identity.json')
assert meta['candidate'].startswith('97313e53b') and meta['sourceRevision'].startswith('ad88474bb')
assert read(comparison/'candidate-verify.json')['state']=='Completed'
assert next(row for row in read(lab/'route-counts.json')['rows'] if row['case']=='scripts.captured-rule-closures')['routes']=={'captured-pair make_rules':8192}
ref=lab/'reference'
ref.mkdir(exist_ok=True)
core=lab.with_name('regex-pattern-hash-20261124')/'windows/bin/Lokad.Lython/release_net11.0/Lokad.Lython.dll'
subprocess.run(['git','diff','--exit-code','6341a1f87','ad88474bb','--','src'],cwd=root,check=True)
for name,expected in original['imageFiles']['candidate'].items():
    item=donor/'candidate'/name
    assert digest(item)==expected
    shutil.copyfile(core if name==core.name else item, ref/name)
meta['imageFiles']={role:{name:digest(lab/role/name) for name in original['imageFiles']['candidate']} for role in ('reference','candidate')}
for role,files in meta['imageFiles'].items():
    assert len(files)==len(list((lab/role).iterdir()))==32
    assert {n:h for n,h in files.items() if n!=core.name}=={n:h for n,h in original['imageFiles']['candidate'].items() if n!=core.name}
meta['coreSHA256']={name:meta['imageFiles'][role][core.name] for role in ('reference','candidate') for name in (role,role+'-control')}
meta['expectedCPythonSHA256']=original['expectedCPythonSHA256']
meta['purpose']='Complete both captured callables and the ordered return from four local slots before the outer activation'
catalog=comparison/'representative.json'
cases=[entry['id'] for entry in read(catalog)['cases']]
save(comparison/'jobs.json',dict(warm=[(case,'warm') for case in cases]+[('scripts.captured-rule-closures','compile-run')]))
meta['catalogs']={name:{'sha256':digest(comparison/name)} for name in ('representative.json','jobs.json')}
save(comparison/'identity.json',meta)

sdk=Path.home()/'.dotnet11'
dotnet=sdk/'dotnet.exe'
env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk),PATH=str(sdk)+os.pathsep+os.environ['PATH'])
protocol=root/'benchmarks/cpython-worker.py'
for role in ('reference','candidate'):
    checked=comparison/(role+'-verify.json')
    subprocess.run([dotnet,lab/role/'Lokad.Lython.Benchmarks.dll','--compare','verify','--catalog',catalog,'--dotnet',dotnet,
        '--python','C:/Python313/python.exe','--python-worker',protocol,'--out',checked],env=env,cwd=root,check=True,timeout=85)
    check=read(checked)
    assert check['state']=='Completed' and check['caseCount']==6 and check['launched']['library']['sha256']==meta['coreSHA256'][role]

collector=(donor/'comparison/quiet/collect.py').read_text(encoding='utf-8').replace('b1599-','b1602-')
compile(collector,'collect.py','exec')
write(quiet/'collect.py',collector)
shutil.copyfile(donor/'comparison/quiet/run.sh',quiet/'run.sh')
assert b'\r' not in (quiet/'run.sh').read_bytes()
payload=quiet/'payload.tar.gz'
with tarfile.open(payload,'w:gz',compresslevel=3) as package:
    for name in ('identity.json','representative.json','jobs.json'):package.add(comparison/name,arcname=name)
    for name in ('run.sh','collect.py'):package.add(quiet/name,arcname=name)
    for role in ('reference','candidate'):package.add(lab/role/core.name,arcname=role+'-core.dll')
save(quiet/'upload.json',dict(root='closed-capture-pair-b1602-20261124',reference='private-call-isolation-b1599-20261124',
    payloadSHA256=digest(payload),payloadBytes=payload.stat().st_size))

choices=[]
for archive in (root/'benchmarks/results').rglob('observations.tar.xz'):
    status=archive.with_name('terminal-status.json')
    if not status.is_file():continue
    terminal=read(status)
    receipt=terminal.get('receipt') or {}
    if terminal.get('live') or terminal.get('fixtures') or str(terminal.get('exitCode'))!='0' or not all(receipt.get(flag)
        for flag in ('complete','allWorkersJoined','guestFixturesRemoved','quietBeforeAndAfter','archivedAndVerifiedUnderLease')):continue
    paths=set(re.findall(r'/home/lokad/lython-bench-checks/([a-zA-Z0-9._-]+)/run\.sh',terminal.get('journal','')))
    if len(paths)!=1:continue
    location=paths.pop()
    if location in ('private-call-isolation-b1599-20261124','private-call-source-cpu-b1601-20261124'):continue
    with tarfile.open(archive) as packed:
        try: raw=packed.getmember('confirmation/confirmation.json')
        except KeyError: continue
        if raw.size<500000:continue
        raw_hash=sha(packed.extractfile(raw).read())
        choices.append((raw.size,archive,location,raw_hash,receipt['archiveSHA256']))
verified=[]
seen=set()
for size,archive,location,raw_hash,packed_hash in sorted(choices,reverse=True):
    if location in seen:continue
    seen.add(location)
    if len(verified)>=82:break
    if digest(archive)!=packed_hash or sha(git(archive))!=packed_hash:continue
    verified.append(dict(location=location,bytes=size,rawSHA256=raw_hash, archiveSHA256=packed_hash,
        durableArchive=archive.relative_to(root).as_posix()))
save(lab/'verified-raw-replicas.json',verified)

launcher=(old/'quiet.py').read_text(encoding='utf-8').replace('b1598-private-definition-call','b1602-closed-capture-pair').replace('b1598-','b1602-')
assert 'staged_bytes' in launcher and 'verified-raw-replicas.json' in launcher
compile(launcher,'quiet.py','exec')
write(lab/'quiet.py',launcher)
script=(donor/'summarize.py').read_text(encoding='utf-8')
compile(script,'summarize.py','exec')
write(lab/'summarize.py',script)
print('Prepared B1602',payload.stat().st_size,'compressed bytes and',len(verified),'archive-backed duplicate candidates')
