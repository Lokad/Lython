from pathlib import Path
import hashlib,json,os,shutil,subprocess
lab=Path(__file__).resolve().parent
root=lab.parents[3]
parent=lab.with_name('closed-capture-pair-20261124')
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
meta=read(parent/'comparison/identity.json')
rev=subprocess.check_output(['git','rev-parse','d6437c26f'],cwd=root,text=True).strip()
meta['candidate']=rev
meta['purpose']='Seed the capture binding accumulator while preserving the existing parameter and capture operand shape'
comparison=lab/'comparison';comparison.mkdir(exist_ok=True)
for name in ('representative.json','jobs.json'):
    shutil.copyfile(parent/'comparison'/name,comparison/name)
    assert sha(comparison/name)==meta['catalogs'][name]['sha256']
core=parent/'windows-seeded/bin/Lokad.Lython/release_net11.0/Lokad.Lython.dll'
for role,files in meta['imageFiles'].items():
    image=lab/role;image.mkdir(exist_ok=True)
    for name,expected in list(files.items()):
        item=parent/role/name
        assert sha(item)==expected
        shutil.copyfile(core if role=='candidate' and name==core.name else item,image/name)
    if role=='candidate':files[core.name]=sha(core)
    assert len(files)==32 and {p.name:sha(p) for p in image.iterdir()}==files
    for label in (role,role+'-control'):meta['coreSHA256'][label]=files[core.name]
(comparison/'identity.json').write_text(json.dumps(meta,indent=2)+'\n',encoding='utf-8',newline='\n')
sdk=Path.home()/'.dotnet11';dotnet=sdk/'dotnet.exe'
env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk),PATH=str(sdk)+os.pathsep+os.environ['PATH'])
protocol=root/'benchmarks/cpython-worker.py'
assert sha(protocol)==meta['cpythonWorkerSHA256']
for role in ('reference','candidate'):
    check=comparison/(role+'-verify.json')
    subprocess.run([dotnet,lab/role/'Lokad.Lython.Benchmarks.dll','--compare','verify','--catalog',comparison/'representative.json','--dotnet',dotnet,
       '--python','C:/Python313/python.exe','--python-worker',protocol,'--out',check],env=env,cwd=root,check=True,timeout=85)
    receipt=read(check)
    assert receipt['state']=='Completed' and receipt['caseCount']==6 and receipt['launched']['library']['sha256']==meta['coreSHA256'][role]
for name in ('prepare-allocation.py','inspect-jit.py'):
    shutil.copyfile(parent/name,lab/name)
    subprocess.run(['C:/Python313/python.exe','-I','-X','utf8',lab/name],cwd=root,check=True,timeout=110)
